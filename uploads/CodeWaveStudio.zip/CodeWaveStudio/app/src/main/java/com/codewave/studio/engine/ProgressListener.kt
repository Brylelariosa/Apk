package com.codewave.studio.engine

/** Receives render progress (0..1). Invoked from native code on the generation thread. */
interface ProgressListener {
    fun onProgress(fraction: Float)
}
