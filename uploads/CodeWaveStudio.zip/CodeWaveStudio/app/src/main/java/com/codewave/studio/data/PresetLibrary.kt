package com.codewave.studio.data

import android.content.Context

/** Procedural example scripts bundled as tiny text assets (assets/presets). No audio files are shipped. */
object PresetLibrary {

    data class Preset(val file: String, val name: String)

    /** Shown on first launch: the two-line "hello world" of CodeWave. */
    const val DEFAULT_SCRIPT = """// CodeWave Studio - press GENERATE, then PLAY
sound.begin(2.0);

oscillator.sine(
    frequency = 440,
    volume = 0.8
);

envelope.adsr(
    attack = 0.01,
    decay = 0.15,
    sustain = 0.6,
    release = 0.25
);

filter.lowpass(1200);

sound.end();
"""

    fun list(context: Context): List<Preset> {
        val text = readAsset(context, "presets/index.txt") ?: return emptyList()
        return text.lineSequence()
            .map { it.trim() }
            .filter { it.isNotEmpty() && it.contains('|') }
            .map { Preset(it.substringBefore('|').trim(), it.substringAfter('|').trim()) }
            .toList()
    }

    fun load(context: Context, preset: Preset): String = readAsset(context, "presets/${preset.file}") ?: ""

    internal fun readAsset(context: Context, path: String): String? = try {
        context.assets.open(path).bufferedReader(Charsets.UTF_8).use { it.readText() }
    } catch (e: Exception) {
        null
    }
}
