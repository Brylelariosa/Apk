package com.codewave.studio.ui

import java.util.Locale

object TimeFormat {
    /** 00:02.50 */
    fun clock(seconds: Double): String {
        val cs = (seconds * 100.0 + 0.5).toLong().coerceAtLeast(0L)
        return String.format(Locale.US, "%02d:%02d.%02d", cs / 6000, (cs / 100) % 60, cs % 100)
    }

    /** Short label for axis ticks: 0, 0.5s, 2s */
    fun tick(seconds: Double): String = when {
        seconds < 0.0005 -> "0"
        seconds >= 10.0 || Math.abs(seconds - Math.round(seconds)) < 0.001 -> String.format(Locale.US, "%.0fs", seconds)
        seconds >= 1.0 -> String.format(Locale.US, "%.1fs", seconds)
        else -> String.format(Locale.US, "%.2fs", seconds)
    }
}
