package com.codewave.studio.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.text.Editable
import android.text.TextWatcher
import android.util.AttributeSet
import android.view.MotionEvent
import android.widget.EditText
import com.codewave.studio.R

/**
 * Mobile code editor built on the platform EditText (so IME, selection handles and
 * clipboard just work). It adds a fixed line-number gutter, CodeWave syntax colors,
 * a highlighted error line, and scrolls in both directions without wrapping.
 */
class CodeEditorView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = android.R.attr.editTextStyle
) : EditText(context, attrs, defStyleAttr) {

    /** 1-based line to mark as the error line, or 0 for none. */
    var errorLine: Int = 0
        set(value) {
            if (field != value) {
                field = value
                invalidate()
            }
        }

    /** Called after every edit with the current line count. */
    var onContentChanged: (() -> Unit)? = null

    var lineCount1: Int = 1
        private set

    private val highlighter = SyntaxHighlighter(
        context.themeColor(R.attr.cwSynNamespace),
        context.themeColor(R.attr.cwSynMethod),
        context.themeColor(R.attr.cwSynNumber),
        context.themeColor(R.attr.cwSynString),
        context.themeColor(R.attr.cwSynComment),
        context.themeColor(R.attr.cwSynParam),
        context.themeColor(R.attr.cwSynKeyword)
    )

    private val gutterBg = Paint().apply { color = context.themeColor(R.attr.cwGutterBg) }
    private val divider = Paint().apply {
        color = context.themeColor(R.attr.cwOutline)
        strokeWidth = 1f
    }
    private val errorBand = Paint().apply { color = context.themeColor(R.attr.cwErrorLine) }
    private val numberPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.MONOSPACE
        textAlign = Paint.Align.RIGHT
    }
    private val gutterTextColor = context.themeColor(R.attr.cwGutterText)
    private val errorTextColor = context.themeColor(R.attr.cwError)

    private var gutterPx = 0
    private var dirtyStart = 0
    private var dirtyEnd = 0

    init {
        typeface = Typeface.MONOSPACE
        setHorizontallyScrolling(true)
        isHorizontalScrollBarEnabled = true
        isVerticalScrollBarEnabled = true
        addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                dirtyStart = start
                dirtyEnd = start + count
            }

            override fun afterTextChanged(s: Editable) {
                highlighter.highlight(s, dirtyStart, dirtyEnd)
                recountLines(s)
                onContentChanged?.invoke()
            }
        })
        updateGutter(true)
    }

    private fun recountLines(s: CharSequence) {
        var n = 1
        for (i in 0 until s.length) if (s[i] == '\n') n++
        if (n != lineCount1) {
            lineCount1 = n
            updateGutter(false)
        }
    }

    private fun updateGutter(force: Boolean) {
        numberPaint.textSize = textSize
        val digits = maxOf(2, lineCount1.toString().length)
        val w = (numberPaint.measureText("0") * digits + context.dp(14f)).toInt()
        if (force || w != gutterPx) {
            gutterPx = w
            setPadding(gutterPx + context.dp(8f).toInt(), paddingTop, paddingRight, paddingBottom)
        }
    }

    /** Scrolls so that [line] (1-based) is visible and puts the cursor at its start. */
    fun goToLine(line: Int) {
        val l = layout ?: return
        if (line < 1 || line > l.lineCount) return
        setSelection(l.getLineStart(line - 1))
        val max = maxOf(0, l.height + totalPaddingTop + totalPaddingBottom - height)
        scrollTo(0, (l.getLineTop(line - 1) - height / 3).coerceIn(0, max))
    }

    override fun onDraw(canvas: Canvas) {
        val l = layout
        if (l != null && errorLine in 1..l.lineCount) {
            val top = extendedPaddingTop + l.getLineTop(errorLine - 1)
            val bottom = extendedPaddingTop + l.getLineBottom(errorLine - 1)
            canvas.drawRect(scrollX.toFloat(), top.toFloat(), (scrollX + width).toFloat(), bottom.toFloat(), errorBand)
        }
        super.onDraw(canvas)
        if (l == null) return

        val left = scrollX.toFloat()
        val top = scrollY.toFloat()
        val bottom = (scrollY + height).toFloat()
        canvas.drawRect(left, top, left + gutterPx, bottom, gutterBg)
        canvas.drawLine(left + gutterPx, top, left + gutterPx, bottom, divider)

        val first = l.getLineForVertical(maxOf(0, scrollY - extendedPaddingTop))
        val last = l.getLineForVertical(maxOf(0, scrollY + height - extendedPaddingTop))
        val right = left + gutterPx - context.dp(6f)
        for (i in first..minOf(last, l.lineCount - 1)) {
            numberPaint.color = if (i + 1 == errorLine) errorTextColor else gutterTextColor
            canvas.drawText((i + 1).toString(), right, (extendedPaddingTop + l.getLineBaseline(i)).toFloat(), numberPaint)
        }
    }

    // Let the editor scroll itself when it is inside a scrolling page.
    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (canScrollVertically(-1) || canScrollVertically(1) || canScrollHorizontally(-1) || canScrollHorizontally(1)) {
                    parent?.requestDisallowInterceptTouchEvent(true)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> parent?.requestDisallowInterceptTouchEvent(false)
        }
        return super.onTouchEvent(event)
    }
}
