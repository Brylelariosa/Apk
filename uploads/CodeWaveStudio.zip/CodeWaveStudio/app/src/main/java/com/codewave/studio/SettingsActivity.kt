package com.codewave.studio

import android.app.Activity
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.SeekBar
import android.widget.TextView
import com.codewave.studio.data.AppSettings
import com.codewave.studio.data.Themes
import com.codewave.studio.ui.dp
import com.codewave.studio.ui.themeColor
import java.util.Locale

/** Plain settings screen: only safe, user-level options. */
class SettingsActivity : Activity() {

    private lateinit var settings: AppSettings

    override fun onCreate(savedInstanceState: Bundle?) {
        settings = AppSettings.get(this)
        setTheme(Themes.resolve(this, settings.theme))
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        findViewById<ImageButton>(R.id.btnBack).setOnClickListener { finish() }

        val box = findViewById<LinearLayout>(R.id.settingsContainer)
        buildAudio(box)
        buildPlayback(box)
        buildAppearance(box)
        buildAbout(box)
    }

    // ------------------------------------------------------------------ sections

    private fun buildAudio(box: LinearLayout) {
        val card = card(box, R.string.settings_audio)

        val rates = AppSettings.SAMPLE_RATES
        radioGroup(
            card, getString(R.string.settings_sample_rate),
            listOf("22,050 Hz  (smallest, fastest)", "44,100 Hz  (recommended)", "48,000 Hz"),
            rates.indexOf(settings.sampleRate).coerceAtLeast(0)
        ) { settings.sampleRate = rates[it] }

        radioGroup(
            card, getString(R.string.settings_channels), listOf("Stereo", "Mono"),
            if (settings.stereo) 0 else 1
        ) { settings.stereo = it == 0 }

        card.addView(rowLabel(getString(R.string.settings_duration)))
        val value = TextView(this).apply {
            setTextColor(themeColor(R.attr.cwTextPrimary))
            textSize = 15f
            typeface = android.graphics.Typeface.MONOSPACE
        }
        fun show(tenths: Int) {
            value.text = String.format(Locale.US, "%.1f s", tenths / 10f)
        }
        show(settings.defaultDurationTenths)
        card.addView(value)
        val seek = SeekBar(this).apply {
            max = 95 // 0.5 s .. 10.0 s in 0.1 s steps
            progress = settings.defaultDurationTenths - 5
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar, p: Int, fromUser: Boolean) = show(p + 5)
                override fun onStartTrackingTouch(seekBar: SeekBar) = Unit
                override fun onStopTrackingTouch(seekBar: SeekBar) {
                    settings.defaultDurationTenths = seekBar.progress + 5
                }
            })
        }
        card.addView(seek, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48f).toInt()))
        card.addView(note(getString(R.string.settings_duration_hint)))
        card.addView(note(getString(R.string.settings_note_regenerate)))
    }

    private fun buildPlayback(box: LinearLayout) {
        val card = card(box, R.string.settings_playback)
        radioGroup(
            card, getString(R.string.settings_buffer),
            listOf("Small  (lowest latency)", "Medium  (default)", "Large  (safest on slow devices)"),
            settings.bufferSize
        ) { settings.bufferSize = it }

        radioGroup(
            card, getString(R.string.settings_export_format),
            listOf("WAV  16-bit PCM  (recommended)", "WAV  32-bit float"),
            settings.exportFormat
        ) { settings.exportFormat = it }
        card.addView(note("OGG export is not included: it would need an extra encoder library and a bigger APK."))
    }

    private fun buildAppearance(box: LinearLayout) {
        val card = card(box, R.string.settings_appearance)
        radioGroup(
            card, getString(R.string.settings_theme), listOf("Dark", "Light", "Follow system"), settings.theme
        ) {
            settings.theme = it
            recreate()
        }
    }

    @Suppress("DEPRECATION")
    private fun buildAbout(box: LinearLayout) {
        val card = card(box, R.string.settings_about)
        val version = try {
            packageManager.getPackageInfo(packageName, 0).versionName ?: ""
        } catch (e: Exception) {
            ""
        }
        card.addView(TextView(this).apply {
            text = getString(R.string.app_name) + "  " + version
            setTextColor(themeColor(R.attr.cwTextPrimary))
            textSize = 17f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        card.addView(note("Procedural audio from short scripts, rendered by a native C++ engine."))
        card.addView(note("Works completely offline and needs no permissions. Scripts can only call the built-in audio commands - they cannot touch files, the network or other apps."))
        card.addView(note("Limits: sounds up to 30 seconds, WAV export through the system file picker."))
    }

    // ------------------------------------------------------------------- builders

    private fun card(parent: LinearLayout, titleRes: Int): LinearLayout {
        val title = TextView(this).apply {
            setText(titleRes)
            setTextAppearance(R.style.CW_Label)
            setPadding(dp(4f).toInt(), dp(16f).toInt(), 0, dp(8f).toInt())
        }
        parent.addView(title)
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = getDrawable(R.drawable.bg_card)
            val h = dp(16f).toInt()
            setPadding(h, dp(8f).toInt(), h, dp(12f).toInt())
        }
        parent.addView(card, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        return card
    }

    private fun rowLabel(text: String) = TextView(this).apply {
        this.text = text
        setTextColor(themeColor(R.attr.cwTextPrimary))
        textSize = 15f
        setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(0, dp(12f).toInt(), 0, dp(4f).toInt())
    }

    private fun note(text: String) = TextView(this).apply {
        this.text = text
        setTextColor(themeColor(R.attr.cwTextSecondary))
        textSize = 12f
        setPadding(0, dp(6f).toInt(), 0, 0)
    }

    private fun radioGroup(
        card: LinearLayout,
        title: String,
        options: List<String>,
        selected: Int,
        onSelect: (Int) -> Unit
    ) {
        card.addView(rowLabel(title))
        val group = RadioGroup(this)
        group.orientation = RadioGroup.VERTICAL
        for (text in options) {
            val rb = RadioButton(this)
            rb.id = View.generateViewId()
            rb.text = text
            rb.textSize = 15f
            rb.setTextColor(themeColor(R.attr.cwTextPrimary))
            rb.minHeight = dp(48f).toInt()
            group.addView(rb, RadioGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        (group.getChildAt(selected.coerceIn(0, options.size - 1)) as RadioButton).isChecked = true
        group.setOnCheckedChangeListener { g, checkedId ->
            for (i in 0 until g.childCount) {
                if (g.getChildAt(i).id == checkedId) onSelect(i)
            }
        }
        card.addView(group)
    }
}
