package com.codewave.studio.data

import android.content.Context

/** The CodeWave language reference (assets/reference.txt) and a ready-made prompt for AI assistants. */
object LanguageReference {

    fun load(context: Context): String = PresetLibrary.readAsset(context, "reference.txt") ?: "Reference not available."

    /** Paste this into Claude (or any assistant) before describing the sound you want. */
    fun aiPrompt(context: Context): String =
        "You write audio scripts for CodeWave Studio, an Android app that renders them with a native " +
            "C++ synthesizer. Reply with ONE code block that contains only a valid CodeWave script. " +
            "Use only commands from the reference below, start with sound.begin(...) and finish with " +
            "sound.end(); keep it under 80 lines and prefer named parameters.\n\n" +
            load(context) +
            "\n\nNow write a script for this sound: "
}
