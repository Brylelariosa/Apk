package com.codewave.studio

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.codewave.studio.data.AppSettings
import com.codewave.studio.engine.AudioEngine
import com.codewave.studio.engine.AudioEngine.Outcome
import com.codewave.studio.player.PcmPlayer

/**
 * Process-wide owner of the audio engine and player. It survives Activity re-creation
 * (rotation, theme change), so the generated sound, playback position and any running
 * generation are never lost. Activities attach as [Listener] between onStart and onStop and
 * are never referenced otherwise, so nothing leaks. [release] frees everything.
 *
 * Main thread only.
 */
object SoundSession {

    interface Listener {
        fun onGenerateStarted()
        fun onGenerateProgress(fraction: Float)
        fun onGenerateFinished(outcome: Outcome)
        fun onPlayerStateChanged(state: PcmPlayer.State)
        fun onPlayerError(message: String)
    }

    private val main = Handler(Looper.getMainLooper())
    private var token = 0

    var listener: Listener? = null

    var engine: AudioEngine? = null
        private set
    var player: PcmPlayer? = null
        private set

    var sound: AudioEngine.SoundInfo? = null
        private set
    var lastFailure: Outcome.Failure? = null
        private set
    var lastWarnings: String = ""
        private set
    var lastMillis: Int = 0
        private set
    var generating: Boolean = false
        private set
    var progress: Float = 0f
        private set

    private val playerListener = object : PcmPlayer.Listener {
        override fun onPlayerStateChanged(state: PcmPlayer.State) {
            listener?.onPlayerStateChanged(state)
        }

        override fun onPlayerError(message: String) {
            listener?.onPlayerError(message)
        }
    }

    fun acquire(context: Context) {
        if (engine != null) return
        val e = AudioEngine()
        engine = e
        player = PcmPlayer(e, AppSettings.get(context)).also { it.listener = playerListener }
    }

    fun generate(context: Context, script: String) {
        val e = engine ?: return
        if (generating) return
        val settings = AppSettings.get(context)
        player?.stop()
        generating = true
        progress = 0f
        val mine = ++token
        listener?.onGenerateStarted()
        e.generate(
            script = script,
            sampleRate = settings.sampleRate,
            channels = if (settings.stereo) 2 else 1,
            defaultDuration = settings.defaultDurationSeconds,
            progressCallback = { f ->
                main.post {
                    if (token == mine && generating) {
                        progress = f
                        listener?.onGenerateProgress(f)
                    }
                }
            },
            resultCallback = { outcome -> main.post { finishGeneration(mine, outcome) } }
        )
    }

    fun cancelGeneration() {
        engine?.cancel()
    }

    private fun finishGeneration(mine: Int, outcome: Outcome) {
        if (mine != token) return
        generating = false
        when (outcome) {
            is Outcome.Success -> {
                sound = outcome.info
                lastFailure = null
                lastWarnings = outcome.warnings
                lastMillis = outcome.millis
                player?.load(outcome.info)
            }
            is Outcome.Failure -> lastFailure = outcome
            Outcome.Cancelled -> Unit
        }
        listener?.onGenerateFinished(outcome)
    }

    /** Frees the player (joins its thread) first, then the native engine. */
    fun release() {
        token++
        listener = null
        player?.release()
        player = null
        engine?.close()
        engine = null
        sound = null
        lastFailure = null
        lastWarnings = ""
        generating = false
        progress = 0f
    }
}
