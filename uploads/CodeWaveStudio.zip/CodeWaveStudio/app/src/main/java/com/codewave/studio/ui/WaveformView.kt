package com.codewave.studio.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import com.codewave.studio.R

/**
 * Draws the real waveform of the generated sound: one min/max line per pixel column, computed
 * natively and drawn with a single drawLines() call per color. There is exactly one View -
 * no per-sample children. Drag across it to seek.
 */
class WaveformView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    interface Listener {
        /** Finger is moving: show this position, do not seek yet. */
        fun onScrub(fraction: Float)

        /** Finger lifted: seek here. */
        fun onSeek(fraction: Float)
    }

    var listener: Listener? = null

    /** Returns min/max pairs for the requested number of columns (or null when unavailable). */
    var peaksProvider: ((Int) -> FloatArray?)? = null

    var loopEnabled: Boolean = false
        set(value) {
            if (field != value) {
                field = value
                invalidate()
            }
        }

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = context.themeColor(R.attr.cwSurfaceHigh) }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = context.themeColor(R.attr.cwOutline)
        style = Paint.Style.STROKE
        strokeWidth = context.dp(1f)
    }
    private val gridPaint = Paint().apply {
        color = context.themeColor(R.attr.cwOutline)
        strokeWidth = 1f
    }
    private val centerPaint = Paint().apply {
        color = context.themeColor(R.attr.cwTextSecondary)
        strokeWidth = 1f
        alpha = 110
    }
    private val playedPaint = Paint().apply {
        color = context.themeColor(R.attr.cwWave)
        strokeWidth = 1f
        isAntiAlias = false
    }
    private val restPaint = Paint().apply {
        color = context.themeColor(R.attr.cwWaveDim)
        strokeWidth = 1f
        isAntiAlias = false
    }
    private val playheadPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = context.themeColor(R.attr.cwPlayhead)
        strokeWidth = context.dp(2f)
        style = Paint.Style.FILL_AND_STROKE
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = context.themeColor(R.attr.cwTextSecondary)
        textSize = context.sp(10f)
    }
    private val hintPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = context.themeColor(R.attr.cwTextSecondary)
        textSize = context.sp(13f)
        textAlign = Paint.Align.CENTER
    }
    private val loopPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = context.themeColor(R.attr.cwAccent)
        textSize = context.sp(10f)
        isFakeBoldText = true
        textAlign = Paint.Align.RIGHT
    }

    private val plot = RectF()
    private val round = context.dp(12f)
    private val trianglePath = Path()

    private var durationSec = 0.0
    private var hasSound = false
    private var lines: FloatArray? = null
    private var columns = 0
    private var peaksDirty = true
    private var playFraction = 0f
    private var scrubbing = false

    /** Call whenever a new sound was generated (or removed). */
    fun setSound(durationSeconds: Double, available: Boolean) {
        durationSec = durationSeconds
        hasSound = available
        peaksDirty = true
        playFraction = 0f
        invalidate()
    }

    /** Moves the playhead (0..1). Ignored while the user is scrubbing. */
    fun setPlayhead(fraction: Float) {
        if (scrubbing) return
        val f = fraction.coerceIn(0f, 1f)
        if (Math.abs(f - playFraction) * plot.width() < 0.5f && f != 0f && f != 1f) return
        playFraction = f
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        plot.set(context.dp(34f), context.dp(10f), w - context.dp(10f), h - context.dp(22f))
        peaksDirty = true
    }

    private fun rebuildLines() {
        peaksDirty = false
        lines = null
        columns = 0
        if (!hasSound || plot.width() < 2f) return
        val cols = plot.width().toInt()
        val peaks = peaksProvider?.invoke(cols) ?: return
        if (peaks.size < cols * 2) return
        val out = FloatArray(cols * 4)
        val mid = plot.centerY()
        val half = plot.height() / 2f * 0.94f
        for (c in 0 until cols) {
            val x = plot.left + c + 0.5f
            var yTop = mid - peaks[c * 2 + 1].coerceIn(-1f, 1f) * half
            var yBot = mid - peaks[c * 2].coerceIn(-1f, 1f) * half
            if (yBot - yTop < 1f) {
                yTop -= 0.5f
                yBot += 0.5f
            }
            out[c * 4] = x
            out[c * 4 + 1] = yTop
            out[c * 4 + 2] = x
            out[c * 4 + 3] = yBot
        }
        lines = out
        columns = cols
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        canvas.drawRoundRect(0f, 0f, w, h, round, round, bgPaint)
        canvas.drawRoundRect(0f, 0f, w, h, round, round, borderPaint)

        // amplitude grid: +1, +0.5, 0, -0.5, -1
        val mid = plot.centerY()
        val half = plot.height() / 2f * 0.94f
        for (k in -2..2) {
            val y = mid - k * 0.5f * half
            if (k == 0) canvas.drawLine(plot.left, y, plot.right, y, centerPaint) else canvas.drawLine(plot.left, y, plot.right, y, gridPaint)
        }
        textPaint.textAlign = Paint.Align.RIGHT
        val lx = plot.left - context.dp(5f)
        val fm = textPaint.fontMetrics
        val ty = -(fm.ascent + fm.descent) / 2f
        canvas.drawText("1.0", lx, mid - half + ty, textPaint)
        canvas.drawText("0", lx, mid + ty, textPaint)
        canvas.drawText("-1.0", lx, mid + half + ty, textPaint)

        if (!hasSound) {
            canvas.drawText(context.getString(R.string.waveform_empty), w / 2f, mid - context.dp(18f), hintPaint)
            return
        }
        if (peaksDirty) rebuildLines()

        val ln = lines
        if (ln != null && columns > 0) {
            val playedCols = (playFraction * columns).toInt().coerceIn(0, columns)
            if (playedCols > 0) canvas.drawLines(ln, 0, playedCols * 4, playedPaint)
            if (playedCols < columns) canvas.drawLines(ln, playedCols * 4, (columns - playedCols) * 4, restPaint)
        }

        drawTimeAxis(canvas)

        if (loopEnabled) canvas.drawText("LOOP", plot.right - context.dp(4f), plot.top + context.dp(12f), loopPaint)

        // playhead
        val x = plot.left + playFraction * plot.width()
        canvas.drawLine(x, plot.top, x, plot.bottom, playheadPaint)
        trianglePath.reset()
        val t = context.dp(5f)
        trianglePath.moveTo(x - t, plot.top - context.dp(1f))
        trianglePath.lineTo(x + t, plot.top - context.dp(1f))
        trianglePath.lineTo(x, plot.top + t)
        trianglePath.close()
        canvas.drawPath(trianglePath, playheadPaint)
    }

    private fun drawTimeAxis(canvas: Canvas) {
        if (durationSec <= 0.0) return
        val y = plot.bottom + context.dp(14f)
        val tickTop = plot.bottom
        val steps = doubleArrayOf(0.01, 0.02, 0.05, 0.1, 0.2, 0.25, 0.5, 1.0, 2.0, 5.0, 10.0)
        val minGap = context.dp(56f)
        var step = steps.last()
        for (s in steps) {
            if (s / durationSec * plot.width() >= minGap) {
                step = s
                break
            }
        }
        var t = 0.0
        var i = 0
        while (t <= durationSec + 1e-9 && i < 200) {
            val x = plot.left + (t / durationSec).toFloat() * plot.width()
            canvas.drawLine(x, tickTop, x, tickTop + context.dp(4f), gridPaint)
            textPaint.textAlign = if (i == 0) Paint.Align.LEFT else Paint.Align.CENTER
            val label = TimeFormat.tick(t)
            if (x + textPaint.measureText(label) / 2f < plot.right - context.dp(30f) || i == 0) {
                canvas.drawText(label, x, y, textPaint)
            }
            t += step
            i++
        }
        // end marker
        canvas.drawLine(plot.right, plot.top, plot.right, plot.bottom + context.dp(4f), gridPaint)
        textPaint.textAlign = Paint.Align.RIGHT
        canvas.drawText(TimeFormat.tick(durationSec), plot.right, y, textPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (!hasSound || plot.width() <= 0f) return super.onTouchEvent(event)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                scrubbing = true
                moveTo(event.x)
            }
            MotionEvent.ACTION_MOVE -> moveTo(event.x)
            MotionEvent.ACTION_UP -> {
                moveTo(event.x)
                scrubbing = false
                listener?.onSeek(playFraction)
                performClick()
            }
            MotionEvent.ACTION_CANCEL -> {
                scrubbing = false
                listener?.onSeek(playFraction)
            }
        }
        return true
    }

    override fun performClick(): Boolean = super.performClick()

    private fun moveTo(x: Float) {
        playFraction = ((x - plot.left) / plot.width()).coerceIn(0f, 1f)
        invalidate()
        listener?.onScrub(playFraction)
    }
}
