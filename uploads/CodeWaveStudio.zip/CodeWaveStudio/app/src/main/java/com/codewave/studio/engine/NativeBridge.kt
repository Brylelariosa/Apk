package com.codewave.studio.engine

/**
 * The complete JNI surface. Method names and signatures must match jni_bridge.cpp and are
 * protected from R8 in proguard-rules.pro. Scripts never reach anything except these calls.
 */
object NativeBridge {
    /** False when libcodewave.so could not be loaded (the UI then reports it instead of crashing). */
    @JvmField
    val available: Boolean = try {
        System.loadLibrary("codewave")
        true
    } catch (t: Throwable) {
        false
    }

    external fun create(): Long
    external fun destroy(handle: Long)
    external fun cancel(handle: Long)

    /** 0 ok, 1 script error, 2 out of memory, 3 cancelled, 4 internal error. */
    external fun generate(
        handle: Long,
        script: String,
        sampleRate: Int,
        channels: Int,
        defaultDuration: Float,
        listener: ProgressListener?
    ): Int

    external fun lastError(handle: Long): String
    external fun lastErrorLine(handle: Long): Int
    external fun lastWarnings(handle: Long): String
    external fun renderMillis(handle: Long): Int

    external fun frameCount(handle: Long): Int
    external fun channelCount(handle: Long): Int
    external fun sampleRate(handle: Long): Int

    external fun copyPcm16(handle: Long, dst: ShortArray, startFrame: Int, frames: Int): Int
    external fun peaks(handle: Long, columns: Int, out: FloatArray): Boolean

    /** Writes a WAV to an open file descriptor. 0 = success, otherwise an errno value. */
    external fun writeWav(handle: Long, fd: Int, bits: Int): Int
}
