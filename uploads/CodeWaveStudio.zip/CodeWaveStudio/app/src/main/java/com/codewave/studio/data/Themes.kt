package com.codewave.studio.data

import android.content.Context
import android.content.res.Configuration
import com.codewave.studio.R

object Themes {
    /** Maps the stored theme preference to a style resource. Call before super.onCreate(). */
    fun resolve(context: Context, preference: Int): Int {
        val light = when (preference) {
            AppSettings.THEME_LIGHT -> true
            AppSettings.THEME_SYSTEM ->
                (context.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) != Configuration.UI_MODE_NIGHT_YES
            else -> false
        }
        return if (light) R.style.Theme_CodeWave_Light else R.style.Theme_CodeWave
    }
}
