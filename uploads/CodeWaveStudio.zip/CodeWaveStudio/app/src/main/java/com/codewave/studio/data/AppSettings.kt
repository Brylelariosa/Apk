package com.codewave.studio.data

import android.content.Context
import android.content.SharedPreferences
import java.util.Locale

/** Typed access to the app's preferences. Cheap to create; always backed by the same file. */
class AppSettings private constructor(private val prefs: SharedPreferences) {

    /** Engine sample rate in Hz (22050, 44100 or 48000). */
    var sampleRate: Int
        get() = prefs.getInt(KEY_SAMPLE_RATE, 44100).takeIf { it in SAMPLE_RATES } ?: 44100
        set(value) = prefs.edit().putInt(KEY_SAMPLE_RATE, value).apply()

    var stereo: Boolean
        get() = prefs.getBoolean(KEY_STEREO, true)
        set(value) = prefs.edit().putBoolean(KEY_STEREO, value).apply()

    /** Used when a script calls sound.begin() without a duration. Stored in tenths of a second. */
    var defaultDurationTenths: Int
        get() = prefs.getInt(KEY_DURATION, 20).coerceIn(5, 100)
        set(value) = prefs.edit().putInt(KEY_DURATION, value.coerceIn(5, 100)).apply()

    val defaultDurationSeconds: Float get() = defaultDurationTenths / 10f

    var bufferSize: Int
        get() = prefs.getInt(KEY_BUFFER, BUFFER_MEDIUM).coerceIn(BUFFER_SMALL, BUFFER_LARGE)
        set(value) = prefs.edit().putInt(KEY_BUFFER, value).apply()

    var exportFormat: Int
        get() = prefs.getInt(KEY_EXPORT, FORMAT_WAV16).coerceIn(FORMAT_WAV16, FORMAT_WAV32F)
        set(value) = prefs.edit().putInt(KEY_EXPORT, value).apply()

    var theme: Int
        get() = prefs.getInt(KEY_THEME, THEME_DARK).coerceIn(THEME_DARK, THEME_SYSTEM)
        set(value) = prefs.edit().putInt(KEY_THEME, value).apply()

    var volume: Float
        get() = prefs.getFloat(KEY_VOLUME, 1f).coerceIn(0f, 1f)
        set(value) = prefs.edit().putFloat(KEY_VOLUME, value.coerceIn(0f, 1f)).apply()

    var loop: Boolean
        get() = prefs.getBoolean(KEY_LOOP, false)
        set(value) = prefs.edit().putBoolean(KEY_LOOP, value).apply()

    /** Auto-saved editor contents. */
    var script: String
        get() = prefs.getString(KEY_SCRIPT, "") ?: ""
        set(value) = prefs.edit().putString(KEY_SCRIPT, value).apply()

    var exportCounter: Int
        get() = prefs.getInt(KEY_COUNTER, 1).coerceAtLeast(1)
        set(value) = prefs.edit().putInt(KEY_COUNTER, value).apply()

    /** codewave_sound_001.wav, codewave_sound_002.wav, ... */
    fun suggestedFileName(): String = String.format(Locale.US, "codewave_sound_%03d.wav", exportCounter)

    companion object {
        private const val FILE = "codewave_settings"
        private const val KEY_SAMPLE_RATE = "sample_rate"
        private const val KEY_STEREO = "stereo"
        private const val KEY_DURATION = "default_duration_tenths"
        private const val KEY_BUFFER = "buffer_size"
        private const val KEY_EXPORT = "export_format"
        private const val KEY_THEME = "theme"
        private const val KEY_VOLUME = "volume"
        private const val KEY_LOOP = "loop"
        private const val KEY_SCRIPT = "script"
        private const val KEY_COUNTER = "export_counter"

        val SAMPLE_RATES = intArrayOf(22050, 44100, 48000)

        const val THEME_DARK = 0
        const val THEME_LIGHT = 1
        const val THEME_SYSTEM = 2

        const val BUFFER_SMALL = 0
        const val BUFFER_MEDIUM = 1
        const val BUFFER_LARGE = 2

        const val FORMAT_WAV16 = 0
        const val FORMAT_WAV32F = 1

        fun get(context: Context): AppSettings =
            AppSettings(context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE))
    }
}
