package com.codewave.studio.engine

import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Kotlin facade over one native engine instance. Generation runs on a private worker thread,
 * so the UI never blocks; the result of a failed generation never replaces the previous sound.
 */
class AudioEngine : AutoCloseable {

    data class SoundInfo(val frames: Int, val sampleRate: Int, val channels: Int) {
        val durationSeconds: Double get() = if (sampleRate > 0) frames.toDouble() / sampleRate else 0.0
    }

    enum class FailureKind { SCRIPT, MEMORY, INTERNAL }

    sealed class Outcome {
        class Success(val info: SoundInfo, val warnings: String, val millis: Int) : Outcome()
        class Failure(val kind: FailureKind, val message: String, val line: Int) : Outcome()
        object Cancelled : Outcome()
    }

    private val executor: ExecutorService = Executors.newSingleThreadExecutor { r ->
        Thread(r, "cw-generate").apply { isDaemon = true }
    }

    @Volatile
    private var handle: Long = if (NativeBridge.available) {
        try {
            NativeBridge.create()
        } catch (t: Throwable) {
            0L
        }
    } else {
        0L
    }

    @Volatile
    private var closed = false

    val available: Boolean get() = handle != 0L && !closed

    /** Callbacks run on the worker thread; post to the UI thread yourself. */
    fun generate(
        script: String,
        sampleRate: Int,
        channels: Int,
        defaultDuration: Float,
        progressCallback: (Float) -> Unit,
        resultCallback: (Outcome) -> Unit
    ) {
        val h = handle
        if (h == 0L || closed) {
            resultCallback(Outcome.Failure(FailureKind.INTERNAL, "The native audio engine is not available.", 0))
            return
        }
        val listener = object : ProgressListener {
            override fun onProgress(fraction: Float) = progressCallback(fraction)
        }
        try {
            executor.execute {
                val outcome = try {
                    when (NativeBridge.generate(h, script, sampleRate, channels, defaultDuration, listener)) {
                        0 -> Outcome.Success(
                            SoundInfo(
                                NativeBridge.frameCount(h),
                                NativeBridge.sampleRate(h),
                                NativeBridge.channelCount(h)
                            ),
                            NativeBridge.lastWarnings(h).trim(),
                            NativeBridge.renderMillis(h)
                        )
                        1 -> Outcome.Failure(FailureKind.SCRIPT, NativeBridge.lastError(h), NativeBridge.lastErrorLine(h))
                        2 -> Outcome.Failure(FailureKind.MEMORY, NativeBridge.lastError(h), 0)
                        3 -> Outcome.Cancelled
                        else -> Outcome.Failure(FailureKind.INTERNAL, NativeBridge.lastError(h), 0)
                    }
                } catch (e: OutOfMemoryError) {
                    Outcome.Failure(FailureKind.MEMORY, "Out of memory while generating.\n\nUse a shorter sound or a lower sample rate.", 0)
                } catch (t: Throwable) {
                    Outcome.Failure(FailureKind.INTERNAL, "Unexpected engine failure: ${t.javaClass.simpleName}", 0)
                }
                resultCallback(outcome)
            }
        } catch (e: java.util.concurrent.RejectedExecutionException) {
            resultCallback(Outcome.Cancelled)
        }
    }

    fun cancel() {
        val h = handle
        if (h != 0L && !closed) NativeBridge.cancel(h)
    }

    /** Writes the current sound as WAV (bits = 16 PCM or 32 float). 0 = success, else an errno value. */
    fun writeWav(fd: Int, bits: Int): Int {
        val h = handle
        return if (h == 0L || closed) -1 else NativeBridge.writeWav(h, fd, bits)
    }

    /** Interleaved 16-bit PCM for playback. Safe to call from the player thread. */
    fun copyPcm16(dst: ShortArray, startFrame: Int, frames: Int): Int {
        val h = handle
        return if (h == 0L || closed) 0 else NativeBridge.copyPcm16(h, dst, startFrame, frames)
    }

    /** min/max pairs for `columns` columns, or null when there is no sound. */
    fun peaks(columns: Int): FloatArray? {
        val h = handle
        if (h == 0L || closed || columns < 1) return null
        val out = FloatArray(columns * 2)
        return if (NativeBridge.peaks(h, columns, out)) out else null
    }

    /** Stop the player first: this frees the native engine once any running generation has ended. */
    override fun close() {
        if (closed) return
        closed = true
        val h = handle
        handle = 0L
        if (h != 0L) {
            NativeBridge.cancel(h)
            try {
                executor.execute { NativeBridge.destroy(h) }
            } catch (e: java.util.concurrent.RejectedExecutionException) {
                NativeBridge.destroy(h)
            }
        }
        executor.shutdown()
    }
}
