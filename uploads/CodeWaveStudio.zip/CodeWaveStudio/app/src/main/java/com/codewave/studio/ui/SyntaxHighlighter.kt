package com.codewave.studio.ui

import android.text.Editable
import android.text.Spanned
import android.text.style.ForegroundColorSpan

/** Colors CodeWave scripts. Works line by line, so typing only re-colors the edited lines. */
class SyntaxHighlighter(
    private val cNamespace: Int,
    private val cMethod: Int,
    private val cNumber: Int,
    private val cString: Int,
    private val cComment: Int,
    private val cParam: Int,
    private val cKeyword: Int
) {
    private class SynSpan(color: Int) : ForegroundColorSpan(color)

    /** Re-colors every line touched by [start, end). */
    fun highlight(text: Editable, start: Int, end: Int) {
        val len = text.length
        var s = start.coerceIn(0, len)
        var e = end.coerceIn(s, len)
        while (s > 0 && text[s - 1] != '\n') s--
        while (e < len && text[e] != '\n') e++
        for (old in text.getSpans(s, e, SynSpan::class.java)) text.removeSpan(old)

        var i = s
        while (i < e) {
            val c = text[i]
            when {
                c == '#' || (c == '/' && i + 1 < e && text[i + 1] == '/') -> {
                    paint(text, i, e, cComment)
                    i = e
                }
                c == '/' && i + 1 < e && text[i + 1] == '*' -> {
                    var j = i + 2
                    while (j + 1 < e && !(text[j] == '*' && text[j + 1] == '/')) j++
                    val close = if (j + 1 < e) j + 2 else e
                    paint(text, i, close, cComment)
                    i = close
                }
                c == '"' || c == '\'' -> {
                    var j = i + 1
                    while (j < e && text[j] != c) j++
                    val close = if (j < e) j + 1 else e
                    paint(text, i, close, cString)
                    i = close
                }
                c.isDigit() || (c == '.' && i + 1 < e && text[i + 1].isDigit()) -> {
                    var j = i + 1
                    while (j < e && (text[j].isDigit() || text[j] == '.')) j++
                    paint(text, i, j, cNumber)
                    i = j
                }
                c.isLetter() || c == '_' -> i = word(text, i, e)
                else -> i++
            }
        }
    }

    private fun word(text: Editable, from: Int, end: Int): Int {
        var j = from + 1
        while (j < end && (text[j].isLetterOrDigit() || text[j] == '_')) j++
        // sharp note names such as C#4
        if (j - from == 1 && j + 1 < end && text[j] == '#' && text[j + 1].isDigit() && text[from].uppercaseChar() in 'A'..'G') {
            j++
            while (j < end && text[j].isDigit()) j++
        }
        val w = text.subSequence(from, j).toString()
        val next = nextNonSpace(text, j, end)
        val prev = prevNonSpace(text, from)
        when {
            w.equals("let", ignoreCase = true) -> paint(text, from, j, cKeyword)
            next == '.' && isNamespace(w) -> paint(text, from, j, cNamespace)
            prev == '.' -> paint(text, from, j, cMethod)
            next == '=' && !(j < end && text[j] == '=') && followedByAssign(text, j, end) -> paint(text, from, j, cParam)
            isNoteName(w) -> paint(text, from, j, cNumber)
        }
        return j
    }

    private fun followedByAssign(text: Editable, from: Int, end: Int): Boolean {
        var k = from
        while (k < end && (text[k] == ' ' || text[k] == '\t')) k++
        return k < end && text[k] == '=' && !(k + 1 < end && text[k + 1] == '=')
    }

    private fun nextNonSpace(text: Editable, from: Int, end: Int): Char {
        var k = from
        while (k < end && (text[k] == ' ' || text[k] == '\t')) k++
        return if (k < end) text[k] else '\u0000'
    }

    private fun prevNonSpace(text: Editable, from: Int): Char {
        var k = from - 1
        while (k >= 0 && (text[k] == ' ' || text[k] == '\t')) k--
        return if (k >= 0) text[k] else '\u0000'
    }

    private fun paint(text: Editable, a: Int, b: Int, color: Int) {
        if (b > a) text.setSpan(SynSpan(color), a, b, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    private fun isNamespace(w: String) = w.lowercase() in NAMESPACES

    private fun isNoteName(w: String): Boolean {
        if (w.length < 2 || w.length > 4) return false
        if (w[0].uppercaseChar() !in 'A'..'G') return false
        var i = 1
        if (w[i] == '#' || w[i] == 'b' || w[i] == 'B') i++
        if (i >= w.length) return false
        while (i < w.length) {
            if (!w[i].isDigit()) return false
            i++
        }
        return true
    }

    companion object {
        private val NAMESPACES = setOf(
            "sound", "layer", "repeat", "oscillator", "noise", "voice", "fm", "vibrato", "sweep", "pitch",
            "am", "ring", "envelope", "filter", "distortion", "saturation", "bitcrush", "delay", "reverb",
            "tremolo", "chorus", "compressor", "mix"
        )
    }
}
