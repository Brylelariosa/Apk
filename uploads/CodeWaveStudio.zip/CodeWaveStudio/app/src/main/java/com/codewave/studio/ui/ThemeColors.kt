package com.codewave.studio.ui

import android.content.Context
import android.graphics.Color
import android.util.TypedValue

/** Resolves a color theme attribute (R.attr.cwXxx) for the current theme. */
fun Context.themeColor(attr: Int, fallback: Int = Color.MAGENTA): Int {
    val tv = TypedValue()
    return if (theme.resolveAttribute(attr, tv, true)) tv.data else fallback
}

fun Context.dp(value: Float): Float = value * resources.displayMetrics.density

fun Context.sp(value: Float): Float =
    TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, value, resources.displayMetrics)
