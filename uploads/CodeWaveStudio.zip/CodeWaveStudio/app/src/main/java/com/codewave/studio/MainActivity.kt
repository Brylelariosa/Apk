package com.codewave.studio

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputFilter
import android.text.TextWatcher
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.ImageButton
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import com.codewave.studio.data.AppSettings
import com.codewave.studio.data.LanguageReference
import com.codewave.studio.data.PresetLibrary
import com.codewave.studio.data.Themes
import com.codewave.studio.engine.AudioEngine.FailureKind
import com.codewave.studio.engine.AudioEngine.Outcome
import com.codewave.studio.engine.NativeBridge
import com.codewave.studio.player.PcmPlayer
import com.codewave.studio.ui.CodeEditorView
import com.codewave.studio.ui.TimeFormat
import com.codewave.studio.ui.WaveformView
import com.codewave.studio.ui.dp
import com.codewave.studio.ui.themeColor
import java.util.Locale

class MainActivity : Activity(), SoundSession.Listener, WaveformView.Listener {

    private lateinit var settings: AppSettings
    private lateinit var editor: CodeEditorView
    private lateinit var editorStats: TextView
    private lateinit var btnUndo: Button
    private lateinit var btnPaste: Button
    private lateinit var btnClear: Button
    private lateinit var btnExamples: Button
    private lateinit var btnGenerate: Button
    private lateinit var progress: ProgressBar
    private lateinit var errorPanel: View
    private lateinit var errorTitle: TextView
    private lateinit var errorText: TextView
    private lateinit var waveform: WaveformView
    private lateinit var soundMeta: TextView
    private lateinit var soundNote: TextView
    private lateinit var timeText: TextView
    private lateinit var btnPlay: Button
    private lateinit var btnPause: Button
    private lateinit var btnStop: Button
    private lateinit var btnLoop: ImageButton
    private lateinit var btnSave: Button
    private lateinit var volumeSeek: SeekBar

    private var appliedTheme = AppSettings.THEME_DARK
    private var undoText: String? = null
    private var programmatic = false
    private var scrubbing = false
    private var lastTime = ""
    private val ui = Handler(Looper.getMainLooper())

    private val ticker = object : Runnable {
        override fun run() {
            updatePlayback()
            if (SoundSession.player?.state == PcmPlayer.State.PLAYING) waveform.postOnAnimation(this)
        }
    }

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        settings = AppSettings.get(this)
        appliedTheme = settings.theme
        setTheme(Themes.resolve(this, appliedTheme))
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        bindViews()
        SoundSession.acquire(applicationContext)

        SoundSession.player?.let {
            it.loop = settings.loop
            it.volume = settings.volume
        }
        setupEditor(savedInstanceState)
        setupButtons()
        waveform.listener = this
        waveform.peaksProvider = { cols -> SoundSession.engine?.peaks(cols) }
        waveform.loopEnabled = settings.loop
        btnLoop.isSelected = settings.loop
        volumeSeek.progress = (settings.volume * 100f).toInt()
    }

    override fun onStart() {
        super.onStart()
        SoundSession.listener = this
        refreshAll()
        startTicker()
    }

    override fun onResume() {
        super.onResume()
        if (settings.theme != appliedTheme) recreate()
    }

    override fun onStop() {
        waveform.removeCallbacks(ticker)
        SoundSession.listener = null
        settings.script = editor.text.toString()
        if (!isChangingConfigurations) {
            SoundSession.player?.let { if (it.state == PcmPlayer.State.PLAYING) it.pause() }
        }
        super.onStop()
    }

    override fun onDestroy() {
        if (isFinishing) SoundSession.release()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_SAVE && resultCode == RESULT_OK) {
            data?.data?.let { exportTo(it) }
        }
    }

    // ---------------------------------------------------------------------- setup

    private fun bindViews() {
        editor = findViewById(R.id.editor)
        editorStats = findViewById(R.id.editorStats)
        btnUndo = findViewById(R.id.btnUndo)
        btnPaste = findViewById(R.id.btnPaste)
        btnClear = findViewById(R.id.btnClear)
        btnExamples = findViewById(R.id.btnExamples)
        btnGenerate = findViewById(R.id.btnGenerate)
        progress = findViewById(R.id.progress)
        errorPanel = findViewById(R.id.errorPanel)
        errorTitle = findViewById(R.id.errorTitle)
        errorText = findViewById(R.id.errorText)
        waveform = findViewById(R.id.waveform)
        soundMeta = findViewById(R.id.soundMeta)
        soundNote = findViewById(R.id.soundNote)
        timeText = findViewById(R.id.timeText)
        btnPlay = findViewById(R.id.btnPlay)
        btnPause = findViewById(R.id.btnPause)
        btnStop = findViewById(R.id.btnStop)
        btnLoop = findViewById(R.id.btnLoop)
        btnSave = findViewById(R.id.btnSave)
        volumeSeek = findViewById(R.id.volumeSeek)
    }

    private fun setupEditor(savedInstanceState: Bundle?) {
        editor.filters = arrayOf<InputFilter>(InputFilter.LengthFilter(MAX_SCRIPT_CHARS))
        if (savedInstanceState == null) {
            programmatic = true
            editor.setText(settings.script.ifEmpty { PresetLibrary.DEFAULT_SCRIPT })
            programmatic = false
        }
        editor.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
            override fun afterTextChanged(s: Editable?) {
                if (!programmatic) {
                    undoText = null
                    btnUndo.visibility = View.GONE
                    editor.errorLine = 0
                }
                updateStats()
            }
        })
        errorPanel.setOnClickListener {
            val line = SoundSession.lastFailure?.line ?: 0
            if (line > 0) editor.goToLine(line)
        }
        updateStats()
    }

    private fun setupButtons() {
        findViewById<ImageButton>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        findViewById<ImageButton>(R.id.btnHelp).setOnClickListener { showReference() }

        btnPaste.setOnClickListener { pasteFromClipboard() }
        btnClear.setOnClickListener {
            if (editor.text.isNotEmpty()) replaceScript("")
        }
        btnUndo.setOnClickListener {
            undoText?.let { previous ->
                programmatic = true
                editor.setText(previous)
                programmatic = false
                undoText = null
                btnUndo.visibility = View.GONE
            }
        }
        btnExamples.setOnClickListener { showExamples() }
        btnGenerate.setOnClickListener {
            if (SoundSession.generating) {
                SoundSession.cancelGeneration()
            } else {
                generate()
            }
        }

        btnPlay.setOnClickListener {
            SoundSession.player?.play()
            startTicker()
        }
        btnPause.setOnClickListener { SoundSession.player?.pause() }
        btnStop.setOnClickListener {
            SoundSession.player?.stop()
            updatePlayback()
        }
        btnLoop.setOnClickListener {
            val on = !btnLoop.isSelected
            btnLoop.isSelected = on
            settings.loop = on
            SoundSession.player?.loop = on
            waveform.loopEnabled = on
        }
        btnSave.setOnClickListener { startExport() }

        volumeSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, value: Int, fromUser: Boolean) {
                SoundSession.player?.volume = value / 100f
            }

            override fun onStartTrackingTouch(seekBar: SeekBar) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar) {
                settings.volume = seekBar.progress / 100f
            }
        })
    }

    // -------------------------------------------------------------------- editor

    private fun updateStats() {
        val chars = editor.text.length
        editorStats.text = String.format(Locale.US, "%d lines · %d chars", editor.lineCount1, chars)
    }

    private fun replaceScript(newText: String) {
        val previous = editor.text.toString()
        programmatic = true
        editor.setText(newText)
        editor.setSelection(0)
        editor.scrollTo(0, 0)
        programmatic = false
        editor.errorLine = 0
        if (previous.isNotEmpty() && previous != newText) {
            undoText = previous
            btnUndo.visibility = View.VISIBLE
        }
    }

    private fun pasteFromClipboard() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip: ClipData? = cm.primaryClip
        val text = if (clip != null && clip.itemCount > 0) clip.getItemAt(0).coerceToText(this).toString() else ""
        if (text.isBlank()) {
            toast("The clipboard is empty")
        } else {
            replaceScript(text.take(MAX_SCRIPT_CHARS))
        }
    }

    private fun showExamples() {
        val presets = PresetLibrary.list(this)
        if (presets.isEmpty()) {
            toast("No examples found")
            return
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.btn_examples)
            .setItems(presets.map { it.name }.toTypedArray()) { _, which ->
                replaceScript(PresetLibrary.load(this, presets[which]))
            }
            .setNegativeButton(R.string.btn_close, null)
            .show()
    }

    private fun showReference() {
        val text = TextView(this).apply {
            this.text = LanguageReference.load(this@MainActivity)
            typeface = Typeface.MONOSPACE
            textSize = 12f
            setTextIsSelectable(true)
            setTextColor(themeColor(R.attr.cwTextPrimary))
            val pad = dp(20f).toInt()
            setPadding(pad, dp(8f).toInt(), pad, dp(8f).toInt())
        }
        val scroll = ScrollView(this).apply { addView(text) }
        AlertDialog.Builder(this)
            .setTitle(R.string.cd_help)
            .setView(scroll)
            .setPositiveButton(R.string.btn_copy_ai) { _, _ ->
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("CodeWave AI prompt", LanguageReference.aiPrompt(this)))
                toast("Copied. Paste it into Claude and describe your sound.")
            }
            .setNegativeButton(R.string.btn_close, null)
            .show()
    }

    // ---------------------------------------------------------------- generation

    private fun generate() {
        hideKeyboard()
        val script = editor.text.toString()
        if (script.isBlank()) {
            showFailureText("The script is empty.\n\nPaste a CodeWave script, or pick one from Examples.", 0)
            return
        }
        SoundSession.generate(applicationContext, script)
    }

    override fun onGenerateStarted() {
        editor.errorLine = 0
        refreshGenerating()
        refreshError()
        refreshTransport()
    }

    override fun onGenerateProgress(fraction: Float) {
        progress.progress = (fraction * 1000f).toInt()
    }

    override fun onGenerateFinished(outcome: Outcome) {
        refreshAll()
        when (outcome) {
            is Outcome.Success -> {
                startTicker()
            }
            is Outcome.Failure -> {
                if (outcome.line > 0) editor.goToLine(outcome.line)
            }
            Outcome.Cancelled -> toast("Generation cancelled")
        }
    }

    // ------------------------------------------------------------------ UI refresh

    private fun refreshAll() {
        refreshGenerating()
        refreshError()
        refreshSound()
        refreshTransport()
        updatePlayback()
    }

    private fun refreshGenerating() {
        val gen = SoundSession.generating
        btnGenerate.setText(if (gen) R.string.btn_cancel else R.string.btn_generate)
        btnGenerate.setCompoundDrawablesRelativeWithIntrinsicBounds(
            if (gen) R.drawable.ic_stop else R.drawable.ic_generate, 0, 0, 0
        )
        progress.visibility = if (gen) View.VISIBLE else View.GONE
        progress.progress = (SoundSession.progress * 1000f).toInt()
    }

    private fun refreshError() {
        val failure = SoundSession.lastFailure
        if (failure == null || SoundSession.generating) {
            errorPanel.visibility = View.GONE
            editor.errorLine = 0
            return
        }
        showFailureText(failure.message, failure.line, failure.kind)
    }

    private fun showFailureText(
        message: String,
        line: Int,
        kind: FailureKind = FailureKind.SCRIPT,
        titleRes: Int = R.string.error_title
    ) {
        errorTitle.setText(titleRes)
        errorText.text =
            if (kind == FailureKind.INTERNAL && !NativeBridge.available) getString(R.string.error_native_missing) else message
        errorPanel.visibility = View.VISIBLE
        editor.errorLine = line
    }

    private fun refreshSound() {
        val info = SoundSession.sound
        waveform.setSound(info?.durationSeconds ?: 0.0, info != null)
        if (info == null) {
            soundMeta.text = ""
            soundNote.visibility = View.GONE
            return
        }
        soundMeta.text = String.format(
            Locale.US, "%.2f s · %.1f kHz · %s · %d ms",
            info.durationSeconds, info.sampleRate / 1000.0, if (info.channels == 1) "Mono" else "Stereo", SoundSession.lastMillis
        )
        val note = SoundSession.lastWarnings
        soundNote.text = note
        soundNote.visibility = if (note.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun refreshTransport() {
        val has = SoundSession.sound != null
        val gen = SoundSession.generating
        val st = SoundSession.player?.state ?: PcmPlayer.State.IDLE
        btnPlay.isEnabled = has && !gen && st != PcmPlayer.State.PLAYING
        btnPause.isEnabled = st == PcmPlayer.State.PLAYING
        btnStop.isEnabled = has && st != PcmPlayer.State.IDLE
        btnSave.isEnabled = has && !gen
        btnLoop.isSelected = settings.loop
    }

    private fun updatePlayback() {
        val info = SoundSession.sound
        val player = SoundSession.player
        if (info == null || player == null || info.frames <= 0) {
            setTime(0.0, 0.0)
            waveform.setPlayhead(0f)
            return
        }
        val frame = player.currentFrame()
        if (!scrubbing) waveform.setPlayhead(frame.toFloat() / info.frames)
        setTime(frame.toDouble() / info.sampleRate, info.durationSeconds)
    }

    private fun setTime(position: Double, duration: Double) {
        if (scrubbing) return
        val s = TimeFormat.clock(position) + " / " + TimeFormat.clock(duration)
        if (s != lastTime) {
            lastTime = s
            timeText.text = s
        }
    }

    private fun startTicker() {
        waveform.removeCallbacks(ticker)
        if (SoundSession.player?.state == PcmPlayer.State.PLAYING) waveform.postOnAnimation(ticker)
    }

    // ----------------------------------------------------------------- listeners

    override fun onPlayerStateChanged(state: PcmPlayer.State) {
        refreshTransport()
        updatePlayback()
        if (state == PcmPlayer.State.PLAYING) startTicker()
    }

    override fun onPlayerError(message: String) {
        refreshTransport()
        showFailureText(message, 0, FailureKind.SCRIPT, R.string.error_playback_title)
    }

    override fun onScrub(fraction: Float) {
        scrubbing = true
        val info = SoundSession.sound ?: return
        val seconds = fraction * info.durationSeconds
        val s = TimeFormat.clock(seconds) + " / " + TimeFormat.clock(info.durationSeconds)
        if (s != lastTime) {
            lastTime = s
            timeText.text = s
        }
    }

    override fun onSeek(fraction: Float) {
        scrubbing = false
        val info = SoundSession.sound ?: return
        SoundSession.player?.seekTo((fraction * info.frames).toInt())
        updatePlayback()
        startTicker()
    }

    // -------------------------------------------------------------------- export

    private fun startExport() {
        if (SoundSession.sound == null) return
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "audio/wav"
            putExtra(Intent.EXTRA_TITLE, settings.suggestedFileName())
        }
        try {
            @Suppress("DEPRECATION")
            startActivityForResult(intent, REQ_SAVE)
        } catch (e: ActivityNotFoundException) {
            toast("No file picker is available on this device")
        }
    }

    private fun exportTo(uri: Uri) {
        val engine = SoundSession.engine ?: return
        val resolver = contentResolver
        val app = applicationContext
        val name = settings.suggestedFileName()
        val bits = if (settings.exportFormat == AppSettings.FORMAT_WAV32F) 32 else 16
        Thread({
            val code = try {
                resolver.openFileDescriptor(uri, "wt")?.use { pfd -> engine.writeWav(pfd.fd, bits) } ?: -3
            } catch (e: Exception) {
                -4
            }
            ui.post {
                if (code == 0) {
                    val s = AppSettings.get(app)
                    s.exportCounter = s.exportCounter + 1
                    Toast.makeText(app, "Saved $name", Toast.LENGTH_LONG).show()
                } else {
                    val why = when (code) {
                        28 -> "not enough storage space"
                        -1 -> "there is no sound to export"
                        -3 -> "the file could not be opened"
                        else -> "write error $code"
                    }
                    Toast.makeText(app, "Export failed: $why", Toast.LENGTH_LONG).show()
                }
            }
        }, "cw-export").start()
    }

    // ------------------------------------------------------------------- helpers

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(editor.windowToken, 0)
    }

    companion object {
        private const val REQ_SAVE = 4001
        private const val MAX_SCRIPT_CHARS = 100_000
    }
}
