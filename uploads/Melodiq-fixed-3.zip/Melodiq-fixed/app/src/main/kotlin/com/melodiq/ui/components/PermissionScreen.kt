package com.melodiq.ui.components

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.melodiq.R

/**
 * Shown instead of the app until the audio permission is granted. Stateless: the screen that
 * owns the permission launcher passes the two actions in.
 */
@Composable
fun PermissionScreen(
    onRequestPermission: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier         = modifier
            .fillMaxSize()
            .systemBarsPadding(),
        contentAlignment = Alignment.Center
    ) {
        EmptyState(
            icon    = R.drawable.ic_library_music,
            title   = "Welcome to Melodiq",
            message = "Allow access to your audio files so Melodiq can build your music library. " +
                "Your music never leaves your phone."
        ) {
            MelodiqButton(
                text    = "Allow access",
                onClick = onRequestPermission,
                icon    = R.drawable.ic_music_note
            )
            Spacer(Modifier.height(12.dp))
            MelodiqButton(
                text    = "Open app settings",
                onClick = onOpenSettings,
                style   = ButtonStyle.Outlined
            )
        }
    }
}
