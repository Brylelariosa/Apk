package com.melodiq.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.melodiq.R
import com.melodiq.data.model.PlaybackProgress
import com.melodiq.data.model.PlayerState
import com.melodiq.data.model.RepeatMode
import com.melodiq.ui.theme.PrimaryPurple
import com.melodiq.ui.theme.TextMuted
import com.melodiq.ui.theme.TextSecondary
import com.melodiq.ui.theme.White20
import com.melodiq.util.TimeFormatter

@Composable
fun PlayerControls(
    state: PlayerState,
    progress: () -> PlaybackProgress,
    onTogglePlayPause: () -> Unit,
    onSeekToNext: () -> Unit,
    onSeekToPrevious: () -> Unit,
    onSeekTo: (Long) -> Unit,
    onToggleShuffle: () -> Unit,
    onCycleRepeat: () -> Unit,
    modifier: Modifier = Modifier,
    accentColor: Color = PrimaryPurple
) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        SeekBar(progress = progress, onSeekTo = onSeekTo, accentColor = accentColor)

        Spacer(Modifier.height(20.dp))

        Row(
            modifier              = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment     = Alignment.CenterVertically
        ) {
            val shuffleTint by animateColorAsState(
                if (state.shuffleEnabled) accentColor else TextSecondary, label = "shuffle_tint"
            )
            IconActionButton(
                icon               = R.drawable.ic_shuffle,
                contentDescription = if (state.shuffleEnabled) "Shuffle on" else "Shuffle off",
                onClick            = onToggleShuffle,
                tint               = shuffleTint,
                containerColor     = if (state.shuffleEnabled) accentColor.copy(alpha = 0.16f) else Color.Transparent
            )

            IconActionButton(
                icon               = R.drawable.ic_skip_previous,
                contentDescription = "Previous song",
                onClick            = onSeekToPrevious,
                tint               = Color.White,
                buttonSize         = 52.dp,
                iconSize           = 32.dp
            )

            FilledIconButton(
                onClick  = onTogglePlayPause,
                modifier = Modifier.size(68.dp),
                colors   = IconButtonDefaults.filledIconButtonColors(
                    containerColor = accentColor,
                    contentColor   = Color.White
                )
            ) {
                VectorIcon(
                    id                 = if (state.isPlaying) R.drawable.ic_pause else R.drawable.ic_play,
                    tint               = Color.White,
                    size               = 36.dp,
                    contentDescription = if (state.isPlaying) "Pause" else "Play"
                )
            }

            IconActionButton(
                icon               = R.drawable.ic_skip_next,
                contentDescription = "Next song",
                onClick            = onSeekToNext,
                tint               = Color.White,
                buttonSize         = 52.dp,
                iconSize           = 32.dp
            )

            val repeatActive = state.repeatMode != RepeatMode.OFF
            val repeatTint by animateColorAsState(
                if (repeatActive) accentColor else TextSecondary, label = "repeat_tint"
            )
            IconActionButton(
                icon = if (state.repeatMode == RepeatMode.ONE) R.drawable.ic_repeat_one else R.drawable.ic_repeat,
                contentDescription = when (state.repeatMode) {
                    RepeatMode.OFF -> "Repeat off"
                    RepeatMode.ALL -> "Repeat all"
                    RepeatMode.ONE -> "Repeat one"
                },
                onClick        = onCycleRepeat,
                tint           = repeatTint,
                containerColor = if (repeatActive) accentColor.copy(alpha = 0.16f) else Color.Transparent
            )
        }
    }
}

/**
 * Seek slider + time labels. Position is read here (through the [progress] lambda) rather
 * than in the parent, so only this composable recomposes while the song plays.
 */
@Composable
private fun SeekBar(
    progress: () -> PlaybackProgress,
    onSeekTo: (Long) -> Unit,
    accentColor: Color
) {
    var dragFraction by remember { mutableStateOf<Float?>(null) }

    val current  = progress()
    val dragging = dragFraction
    val fraction = dragging ?: current.fraction
    val shownMs  = if (dragging != null) (dragging * current.durationMs).toLong() else current.positionMs

    Slider(
        value                 = fraction.coerceIn(0f, 1f),
        onValueChange         = { dragFraction = it },
        onValueChangeFinished = {
            dragFraction?.let { onSeekTo((it * current.durationMs).toLong()) }
            dragFraction = null
        },
        colors = SliderDefaults.colors(
            thumbColor         = accentColor,
            activeTrackColor   = accentColor,
            inactiveTrackColor = White20
        ),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp)
    )

    Row(
        modifier              = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(TimeFormatter.formatMs(shownMs),              color = TextMuted, style = MaterialTheme.typography.labelSmall)
        Text(TimeFormatter.formatMs(current.durationMs),   color = TextMuted, style = MaterialTheme.typography.labelSmall)
    }
}
