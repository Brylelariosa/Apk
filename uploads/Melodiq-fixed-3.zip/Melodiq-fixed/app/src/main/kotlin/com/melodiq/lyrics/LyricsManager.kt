package com.melodiq.lyrics

import com.melodiq.crash.CrashReporter
import com.melodiq.data.model.LyricLine
import com.melodiq.data.model.LyricsCandidate
import com.melodiq.data.model.LyricsResult
import com.melodiq.data.model.LyricsSource
import com.melodiq.data.model.Song
import com.melodiq.data.model.VersionSearch
import com.melodiq.data.repository.LyricsRepository
import com.melodiq.player.PlayerManager
import com.melodiq.util.LrcParser
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

/**
 * The lyrics of the song that is playing, shared by everything that shows them: the Now Playing
 * screen and the floating lyrics window (which keeps working when the app is closed).
 *
 * Lyrics are only looked up when something asks for them ([ensureLoaded]), and the current line is
 * only tracked while somebody is collecting [activeLine] — a closed app with no floating window
 * does no lyrics work at all.
 */
@Singleton
class LyricsManager @Inject constructor(
    private val repository: LyricsRepository,
    private val playerManager: PlayerManager
) {
    private val scope = CoroutineScope(
        SupervisorJob() + Dispatchers.Main.immediate +
            CoroutineExceptionHandler { _, error -> CrashReporter.recordNonFatal("Lyrics tracking failed", error) }
    )

    private val _state = MutableStateFlow<LyricsResult>(LyricsResult.Loading)
    val state: StateFlow<LyricsResult> = _state.asStateFlow()

    private val _activeLine = MutableStateFlow(-1)
    /** Index of the line being sung (into the lines of a Synced result), -1 before the first line. */
    val activeLine: StateFlow<Int> = _activeLine.asStateFlow()

    private var song: Song? = null
    private var job: Job? = null

    init {
        trackActiveLine()
    }

    // ── Loading ──────────────────────────────────────────────────────────────

    /** Loads the lyrics of [song]; does nothing when they are already loaded (or loading) for it. */
    fun ensureLoaded(song: Song) {
        if (this.song?.id == song.id) return
        this.song = song
        load { repository.getLyrics(song) }
    }

    /** "Try again": skips the cache and asks the service again. */
    fun retry() {
        val current = song ?: return
        load { repository.getLyrics(current, forceRefresh = true) }
    }

    // ── The user's own choices ───────────────────────────────────────────────

    fun setOffset(offsetMs: Long) {
        val current = song ?: return
        load(showLoading = false) { repository.setOffset(current, offsetMs) }
    }

    fun applyVersion(candidate: LyricsCandidate) {
        val current = song ?: return
        load { repository.useVersion(current, candidate) }
    }

    fun saveText(text: String, source: LyricsSource) {
        val current = song ?: return
        load { repository.saveCustom(current, text, source) }
    }

    fun resetToAutomatic() {
        val current = song ?: return
        load { repository.resetToAutomatic(current) }
    }

    suspend fun editableText(): String {
        val current = song ?: return ""
        return repository.editableText(current)
    }

    suspend fun findVersions(title: String, artist: String): VersionSearch {
        val current = song ?: return VersionSearch.Empty
        return repository.findVersions(current, title, artist)
    }

    private fun load(showLoading: Boolean = true, block: suspend () -> LyricsResult) {
        job?.cancel()
        if (showLoading) {
            _state.value = LyricsResult.Loading
            _activeLine.value = -1
        }
        job = scope.launch {
            val result = try {
                block()
            } catch (e: CancellationException) {
                // Never swallow cancellation: a cancelled job must not overwrite the
                // Loading state the newer job just wrote.
                throw e
            } catch (e: Throwable) {
                // Lyrics are a bonus feature. Whatever goes wrong here — including an Error such as
                // a class that fails to initialise — must never crash the app or stop the music.
                CrashReporter.recordNonFatal("Lyrics lookup failed", e)
                LyricsResult.Failed
            }
            _state.value = result
        }
    }

    // ── Current line ─────────────────────────────────────────────────────────

    @OptIn(ExperimentalCoroutinesApi::class)
    private fun trackActiveLine() {
        // Collected only while the lyrics are synced AND somebody observes activeLine.
        val observed: Flow<Boolean> = _activeLine.subscriptionCount.map { it > 0 }.distinctUntilChanged()
        scope.launch {
            combine(_state, playerManager.isPlaying, observed) { lyrics, playing, watched ->
                Triple(lyrics, playing, watched)
            }.flatMapLatest { (lyrics, playing, watched) ->
                if (lyrics is LyricsResult.Synced && watched) lineTicker(lyrics.lines, playing) else emptyFlow<Int>()
            }.collect { index ->
                _activeLine.value = index
            }
        }
    }

    private fun lineTicker(lines: List<LyricLine>, playing: Boolean): Flow<Int> = flow {
        while (true) {
            emit(LrcParser.activeIndex(lines, playerManager.getCurrentPosition()))
            // a seek while paused is still picked up, just less often
            delay(if (playing) 100L else 400L)
        }
    }
}
