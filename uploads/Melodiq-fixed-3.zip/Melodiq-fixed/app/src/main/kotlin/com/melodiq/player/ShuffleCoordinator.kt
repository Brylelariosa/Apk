package com.melodiq.player

import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.ShuffleOrder
import com.melodiq.crash.AppLog
import com.melodiq.util.ShuffleDeck
import kotlin.random.Random

/**
 * Makes ExoPlayer's shuffle mode do what a listener expects.
 *
 * ExoPlayer's own shuffle order is a random permutation in which the song you tapped sits at a
 * random spot: with "repeat off" only the songs *after* that spot are ever played, the others are
 * skipped. This class replaces that order (ExoPlayer.setShuffleOrder) with a proper deck:
 *
 *  * every song in the queue appears exactly once, the song that is playing comes first;
 *  * songs already played in this pass stay behind it ("Previous" walks back through them) and
 *    switching shuffle on half-way only shuffles the songs that have NOT been played yet;
 *  * with "repeat all", when the last song of the deck starts a new random deck is made, so every
 *    pass has a different order; with "repeat off" playback stops after the last song.
 *
 * It lives in the service next to the player, so it works on the player directly: no round trips
 * and nothing that can arrive late. All callbacks run on the player's (main) thread.
 */
@OptIn(UnstableApi::class)
class ShuffleCoordinator(private val player: ExoPlayer) : Player.Listener {

    private class Snapshot(val order: IntArray, val currentIndex: Int)

    private val random = Random.Default

    /** Media ids that have started playing in the current pass, oldest first. */
    private val played = LinkedHashSet<String>()

    /** The order installed in the player while shuffle is on. */
    private var order = IntArray(0)

    /** The deck as it was before a new pass was started for the current song (undo for "repeat off"). */
    private var snapshot: Snapshot? = null

    override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
        snapshot = null
        val id = mediaItem?.mediaId ?: return

        if (reason == Player.MEDIA_ITEM_TRANSITION_REASON_PLAYLIST_CHANGED) {
            // A new queue was loaded: forget everything played before.
            played.clear()
            played.add(id)
            if (player.shuffleModeEnabled) installFreshDeck()
            return
        }

        played.add(id)
        if (player.shuffleModeEnabled) startNewPassIfLastSong()
    }

    override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
        snapshot = null
        if (shuffleModeEnabled) resumeFromHistory() else order = IntArray(0)
    }

    override fun onRepeatModeChanged(repeatMode: Int) {
        if (!player.shuffleModeEnabled) return
        if (repeatMode == Player.REPEAT_MODE_ALL) startNewPassIfLastSong() else restoreSnapshot()
    }

    // ── Deck building ────────────────────────────────────────────────────────

    /** New queue: the song that is playing first, everything else shuffled behind it. */
    private fun installFreshDeck() {
        val count = player.mediaItemCount
        if (count <= 1) {
            order = IntArray(count) { it }
            return
        }
        install(ShuffleDeck.fresh(count, player.currentMediaItemIndex, random))
    }

    /** Shuffle switched on while a queue is loaded: keep what was played, shuffle the rest. */
    private fun resumeFromHistory() {
        val count = player.mediaItemCount
        if (count <= 1) {
            order = IntArray(count) { it }
            return
        }
        val indexOfId = HashMap<String, Int>(count * 2)
        for (i in 0 until count) {
            indexOfId[player.getMediaItemAt(i).mediaId] = i
        }
        val playedPositions = ArrayList<Int>(played.size)
        for (id in played) {
            val position = indexOfId[id]
            if (position != null) playedPositions.add(position)
        }

        val deck = ShuffleDeck.resume(count, player.currentMediaItemIndex, playedPositions, random)
        if (deck.newPass) {
            // everything had been played: this is the start of a new pass
            played.clear()
            player.currentMediaItem?.mediaId?.let { played.add(it) }
        }
        install(deck.order)
    }

    /**
     * With "repeat all", ExoPlayer would loop back to the first song of the same order. When the
     * last song of the deck starts, build the next deck instead (current song first, the rest
     * freshly shuffled) so the following pass is a new random order.
     */
    private fun startNewPassIfLastSong() {
        if (player.repeatMode != Player.REPEAT_MODE_ALL) return
        val count = player.mediaItemCount
        if (count <= 1 || order.size != count) return

        val current = player.currentMediaItemIndex
        if (order[order.size - 1] != current) return

        snapshot = Snapshot(order, current)
        played.clear()
        player.currentMediaItem?.mediaId?.let { played.add(it) }
        install(ShuffleDeck.fresh(count, current, random))
    }

    /** "Repeat all" was switched off again while still on the song that triggered a new pass: undo it. */
    private fun restoreSnapshot() {
        val saved = snapshot ?: return
        snapshot = null
        if (player.currentMediaItemIndex == saved.currentIndex && player.mediaItemCount == saved.order.size) {
            install(saved.order)
        }
    }

    private fun install(newOrder: IntArray) {
        order = newOrder
        try {
            player.setShuffleOrder(ShuffleOrder.DefaultShuffleOrder(newOrder, random.nextLong()))
        } catch (e: Exception) {
            // Shuffling is a convenience; if the order cannot be applied playback must carry on.
            AppLog.w(TAG, "could not install shuffle order", e)
        }
    }

    private companion object {
        const val TAG = "Shuffle"
    }
}
