package com.melodiq.player

import android.content.ComponentName
import android.content.Context
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import com.melodiq.crash.AppLog
import com.melodiq.crash.CrashReporter
import com.melodiq.data.model.Song
import com.melodiq.util.MediaTags
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

/**
 * App-wide handle to the playback service.
 *
 * The MediaController is connected once and kept for the life of the process, so the
 * mini player, the Now Playing screen and the sleep timer all talk to the same player.
 * (Earlier versions released the controller whenever any screen's ViewModel was cleared,
 * which silently disconnected every other screen.)
 */
@Singleton
class PlayerManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private class PlayRequest(val items: List<MediaItem>, val startIndex: Int, val shuffle: Boolean?)

    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null

    // A tap that arrives before the controller finished connecting is replayed once it does.
    private var pendingPlay: PlayRequest? = null

    private val _connected = MutableStateFlow(false)
    val connected: StateFlow<Boolean> = _connected.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentMediaItem = MutableStateFlow<MediaItem?>(null)
    val currentMediaItem: StateFlow<MediaItem?> = _currentMediaItem.asStateFlow()

    private val _shuffleEnabled = MutableStateFlow(false)
    val shuffleEnabled: StateFlow<Boolean> = _shuffleEnabled.asStateFlow()

    private val _repeatMode = MutableStateFlow(Player.REPEAT_MODE_OFF)
    val repeatMode: StateFlow<Int> = _repeatMode.asStateFlow()

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            _isPlaying.value = isPlaying
        }
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            _currentMediaItem.value = mediaItem
        }
        override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
            _shuffleEnabled.value = shuffleModeEnabled
        }
        override fun onRepeatModeChanged(repeatMode: Int) {
            _repeatMode.value = repeatMode
        }
    }

    private val controllerListener = object : MediaController.Listener {
        override fun onDisconnected(controller: MediaController) {
            // The service went away (e.g. it stopped itself). Forget the controller so the
            // next connect() binds a fresh one instead of talking to a dead session.
            AppLog.w(TAG, "MediaController disconnected from MusicService")
            this@PlayerManager.controller = null
            controllerFuture = null
            _connected.value = false
            _isPlaying.value = false
            _currentMediaItem.value = null
        }
    }

    /** Safe to call any number of times. */
    fun connect() {
        if (controllerFuture != null) return        // connected, or connection in progress

        AppLog.i(TAG, "connecting to MusicService")
        val token  = SessionToken(context, ComponentName(context, MusicService::class.java))
        val future = MediaController.Builder(context, token)
            .setListener(controllerListener)
            .buildAsync()
        controllerFuture = future

        future.addListener({
            val ctrl = try {
                future.get()
            } catch (e: Exception) {
                controllerFuture = null              // allow a later connect() to retry
                CrashReporter.recordNonFatal("Could not connect to MusicService", e)
                return@addListener
            }
            AppLog.i(TAG, "connected to MusicService")
            controller = ctrl
            ctrl.addListener(playerListener)
            syncFrom(ctrl)
            _connected.value = true

            pendingPlay?.let { play(ctrl, it) }
            pendingPlay = null
        }, ContextCompat.getMainExecutor(context))
    }

    private fun syncFrom(ctrl: MediaController) {
        _isPlaying.value        = ctrl.isPlaying
        _currentMediaItem.value = ctrl.currentMediaItem
        _shuffleEnabled.value   = ctrl.shuffleModeEnabled
        _repeatMode.value       = ctrl.repeatMode
    }

    // ── Playback controls ────────────────────────────────────────────────────

    /**
     * Starts [songs] at [startIndex]. [shuffle] switches shuffle on or off for this queue; null keeps
     * the current setting. With shuffle on, the song at [startIndex] plays first and every other
     * song of [songs] follows exactly once in random order (see ShuffleCoordinator).
     */
    fun playSongs(songs: List<Song>, startIndex: Int = 0, shuffle: Boolean? = null) {
        if (songs.isEmpty()) return
        val request = PlayRequest(
            items      = songs.map { it.toMediaItem() },
            startIndex = startIndex.coerceIn(0, songs.lastIndex),
            shuffle    = shuffle
        )
        val ctrl = controller
        val first = songs[request.startIndex]
        AppLog.i(
            TAG,
            "playSongs: ${songs.size} songs, start=${request.startIndex}, id=${first.id}, " +
                "title=\"${first.title}\", uri=${first.uri}, " +
                (if (ctrl == null) "controller not connected yet" else "controller connected")
        )
        if (ctrl == null) {
            pendingPlay = request
            connect()
        } else {
            play(ctrl, request)
        }
    }

    private fun play(ctrl: MediaController, request: PlayRequest) {
        // Set the mode first: the service builds the shuffle deck when the queue arrives.
        request.shuffle?.let { ctrl.shuffleModeEnabled = it }
        ctrl.setMediaItems(request.items, request.startIndex, 0L)
        ctrl.prepare()
        ctrl.play()
    }

    fun togglePlayPause() {
        val ctrl = controller ?: return
        if (ctrl.isPlaying) ctrl.pause() else ctrl.play()
    }

    fun pause() { controller?.pause() }

    fun seekToNext() { controller?.seekToNextMediaItem() }

    fun seekToPrevious() {
        val ctrl = controller ?: return
        if (ctrl.currentPosition > 3000L) ctrl.seekTo(0L)
        else ctrl.seekToPreviousMediaItem()
    }

    fun seekTo(positionMs: Long) { controller?.seekTo(positionMs) }

    fun toggleShuffle() {
        val ctrl = controller ?: return
        ctrl.shuffleModeEnabled = !ctrl.shuffleModeEnabled
    }

    fun cycleRepeatMode() {
        val ctrl = controller ?: return
        ctrl.repeatMode = when (ctrl.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else                   -> Player.REPEAT_MODE_OFF
        }
    }

    fun getCurrentPosition(): Long = controller?.currentPosition ?: 0L
    fun getDuration(): Long = controller?.duration?.takeIf { it > 0L } ?: 0L
    fun isConnected(): Boolean = controller != null

    private fun Song.toMediaItem(): MediaItem =
        MediaItem.Builder()
            .setMediaId(id.toString())
            .setUri(uri)
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(title)
                    // leave artist/album empty instead of showing "Unknown artist" in the notification
                    .setArtist(if (hasArtist) artist else null)
                    .setAlbumTitle(if (MediaTags.isKnown(album)) album else null)
                    .setArtworkUri(artworkUri)
                    .build()
            )
            .build()

    private companion object {
        const val TAG = "PlayerManager"
    }
}
