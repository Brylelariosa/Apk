package com.melodiq.ui.components

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.melodiq.R

/**
 * Album art with a built-in fallback: a gradient tile with a music-note vector sits
 * underneath, so songs without artwork (untagged files) show a proper cover instead of
 * an empty box. If the image loads it simply covers the fallback.
 */
@Composable
fun ArtworkImage(
    uri: Uri?,
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(10.dp),
    contentDescription: String? = null
) {
    Box(
        modifier = modifier
            .clip(shape)
            .background(Brush.linearGradient(listOf(Color(0xFF3A2F6B), Color(0xFF1E1B2E)))),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            painter            = painterResource(R.drawable.ic_music_note),
            contentDescription = null,
            tint               = Color.White.copy(alpha = 0.35f),
            modifier           = Modifier.fillMaxSize(0.5f)
        )
        AsyncImage(
            model              = uri,
            contentDescription = contentDescription,
            contentScale       = ContentScale.Crop,
            modifier           = Modifier.fillMaxSize()
        )
    }
}
