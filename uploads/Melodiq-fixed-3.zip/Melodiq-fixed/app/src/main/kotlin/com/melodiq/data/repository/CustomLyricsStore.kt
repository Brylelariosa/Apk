package com.melodiq.data.repository

import android.content.Context
import com.melodiq.crash.AppLog
import com.melodiq.data.model.LyricsSource
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Lyrics the user chose for a song (another version, pasted text, an imported file) plus the song's
 * sync offset. They live in small JSON files in the app's private folder instead of the Room
 * database: the lyrics cache expires after 30 days and is replaced whenever the lookup is repeated,
 * but a choice the user made on purpose must stay until they reset it. (It also keeps the
 * database schema untouched, so no migration can wipe favourites or playlists.)
 */
@Singleton
class CustomLyricsStore @Inject constructor(
    @ApplicationContext private val context: Context
) {
    data class Entry(
        val synced: String? = null,
        val plain: String? = null,
        val source: LyricsSource = LyricsSource.AUTO,
        val offsetMs: Long = 0L
    ) {
        /** False for an entry that only remembers a sync offset. */
        val hasContent: Boolean get() = !synced.isNullOrBlank() || !plain.isNullOrBlank()
    }

    private val lock = Any()

    suspend fun get(key: String): Entry? = withContext(Dispatchers.IO) {
        synchronized(lock) {
            val file = fileFor(key)
            if (!file.exists()) return@synchronized null
            try {
                val json = JSONObject(file.readText())
                Entry(
                    synced   = json.optStringOrNull("synced"),
                    plain    = json.optStringOrNull("plain"),
                    source   = parseSource(json.optString("source", "")),
                    offsetMs = json.optLong("offsetMs", 0L)
                )
            } catch (e: Exception) {
                AppLog.w(TAG, "could not read custom lyrics", e)
                null
            }
        }
    }

    suspend fun put(key: String, entry: Entry) {
        withContext(Dispatchers.IO) {
            synchronized(lock) {
                try {
                    val json = JSONObject()
                    json.put("synced", entry.synced ?: JSONObject.NULL)
                    json.put("plain", entry.plain ?: JSONObject.NULL)
                    json.put("source", entry.source.name)
                    json.put("offsetMs", entry.offsetMs)
                    val file = fileFor(key)
                    file.parentFile?.mkdirs()
                    file.writeText(json.toString())
                } catch (e: Exception) {
                    AppLog.w(TAG, "could not save custom lyrics", e)
                }
            }
        }
    }

    suspend fun remove(key: String) {
        withContext(Dispatchers.IO) {
            synchronized(lock) {
                try {
                    fileFor(key).delete()
                } catch (e: Exception) {
                    AppLog.w(TAG, "could not delete custom lyrics", e)
                }
            }
        }
    }

    private fun fileFor(key: String): File = File(File(context.filesDir, DIR), sha1(key) + ".json")

    private fun JSONObject.optStringOrNull(name: String): String? =
        if (isNull(name)) null else optString(name, "").takeIf { it.isNotEmpty() }

    private fun parseSource(name: String): LyricsSource =
        LyricsSource.values().firstOrNull { it.name == name } ?: LyricsSource.AUTO

    private fun sha1(text: String): String {
        val digest = MessageDigest.getInstance("SHA-1").digest(text.toByteArray(Charsets.UTF_8))
        val out = StringBuilder(digest.size * 2)
        for (b in digest) {
            val v = b.toInt() and 0xFF
            if (v < 16) out.append('0')
            out.append(Integer.toHexString(v))
        }
        return out.toString()
    }

    private companion object {
        const val TAG = "CustomLyrics"
        const val DIR = "lyrics"
    }
}
