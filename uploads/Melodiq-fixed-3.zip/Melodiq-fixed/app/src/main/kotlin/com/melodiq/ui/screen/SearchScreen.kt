package com.melodiq.ui.screen

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.melodiq.R
import com.melodiq.ui.components.EmptyState
import com.melodiq.ui.components.IconActionButton
import com.melodiq.ui.components.SongItem
import com.melodiq.ui.components.VectorIcon
import com.melodiq.ui.theme.Divider
import com.melodiq.ui.theme.PrimaryPurple
import com.melodiq.ui.theme.TextMuted
import com.melodiq.ui.theme.TextPrimary
import com.melodiq.ui.theme.TextSecondary
import com.melodiq.ui.viewmodel.PlayerViewModel
import com.melodiq.ui.viewmodel.SearchViewModel

@Composable
fun SearchScreen(
    onNavigateToNowPlaying: () -> Unit,
    playerVm: PlayerViewModel,
    searchVm: SearchViewModel = hiltViewModel()
) {
    val query       by searchVm.query.collectAsStateWithLifecycle()
    val results     by searchVm.searchResults.collectAsStateWithLifecycle()
    val playerState by playerVm.state.collectAsStateWithLifecycle()
    val currentId   = playerState.currentSong?.id

    val focusRequester = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        try { focusRequester.requestFocus() } catch (_: Exception) {}
    }

    Column(modifier = Modifier.fillMaxSize().padding(top = 16.dp)) {
        OutlinedTextField(
            value         = query,
            onValueChange = searchVm::updateQuery,
            placeholder   = { Text("Songs, artists, albums…", color = TextMuted) },
            leadingIcon   = { VectorIcon(id = R.drawable.ic_search, tint = TextSecondary, size = 22.dp) },
            trailingIcon  = if (query.isNotEmpty()) ({
                IconActionButton(
                    icon               = R.drawable.ic_close,
                    contentDescription = "Clear search",
                    onClick            = searchVm::clearQuery,
                    tint               = TextSecondary,
                    buttonSize         = 40.dp,
                    iconSize           = 20.dp
                )
            }) else null,
            singleLine = true,
            shape      = RoundedCornerShape(16.dp),
            colors     = OutlinedTextFieldDefaults.colors(
                focusedBorderColor   = PrimaryPurple,
                unfocusedBorderColor = Divider,
                cursorColor          = PrimaryPurple,
                focusedTextColor     = TextPrimary,
                unfocusedTextColor   = TextPrimary
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .focusRequester(focusRequester)
        )

        Spacer(Modifier.height(8.dp))

        when {
            query.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                EmptyState(
                    icon    = R.drawable.ic_music_note,
                    title   = "Search your music",
                    message = "Find songs by title, artist or album."
                )
            }
            results.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                EmptyState(
                    icon    = R.drawable.ic_search,
                    title   = "No results",
                    message = "Nothing matches \"$query\"."
                )
            }
            else -> LazyColumn(
                modifier       = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 16.dp)
            ) {
                item {
                    Text(
                        text     = "${results.size} results",
                        style    = MaterialTheme.typography.labelMedium,
                        color    = TextMuted,
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
                    )
                }
                itemsIndexed(results, key = { _, s -> s.id }) { idx, song ->
                    SongItem(
                        song            = song,
                        isCurrent       = currentId == song.id,
                        isPlaying       = playerState.isPlaying,
                        onClick         = {
                            playerVm.playSongs(results, idx)
                            onNavigateToNowPlaying()
                        },
                        onFavoriteClick = { playerVm.toggleFavorite(song) }
                    )
                }
            }
        }
    }
}
