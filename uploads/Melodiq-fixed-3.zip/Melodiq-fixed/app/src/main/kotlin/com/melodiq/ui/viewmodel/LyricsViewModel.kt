package com.melodiq.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.melodiq.data.model.LyricsCandidate
import com.melodiq.data.model.LyricsResult
import com.melodiq.data.model.LyricsSource
import com.melodiq.data.model.Song
import com.melodiq.data.model.VersionSearch
import com.melodiq.lyrics.LyricsManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

/** What the "Choose another version" dialog shows. */
sealed interface VersionsUiState {
    object Idle : VersionsUiState
    object Loading : VersionsUiState
    data class Results(val items: List<LyricsCandidate>) : VersionsUiState
    object Empty : VersionsUiState
    object Offline : VersionsUiState
}

/**
 * Thin screen-level wrapper around [LyricsManager] (which owns the lyrics so the floating window
 * can share them). Only the state of the version picker lives here.
 */
@HiltViewModel
class LyricsViewModel @Inject constructor(
    private val manager: LyricsManager
) : ViewModel() {

    val lyricsResult: StateFlow<LyricsResult> = manager.state
    val activeLine: StateFlow<Int> = manager.activeLine

    private val _versions = MutableStateFlow<VersionsUiState>(VersionsUiState.Idle)
    val versions: StateFlow<VersionsUiState> = _versions.asStateFlow()
    private var versionsJob: Job? = null

    /** Loads lyrics for [song]; does nothing if they are already loaded for the same song. */
    fun loadLyrics(song: Song) = manager.ensureLoaded(song)

    fun retry() = manager.retry()

    fun setOffset(offsetMs: Long) = manager.setOffset(offsetMs)

    fun applyVersion(candidate: LyricsCandidate) {
        clearVersions()
        manager.applyVersion(candidate)
    }

    /** Text typed or pasted in the editor. */
    fun saveText(text: String) = manager.saveText(text, LyricsSource.EDITED)

    /** Text of an imported .lrc / .txt file. */
    fun importText(text: String) = manager.saveText(text, LyricsSource.FILE)

    fun resetToAutomatic() = manager.resetToAutomatic()

    suspend fun editableText(): String = manager.editableText()

    fun searchVersions(title: String, artist: String) {
        versionsJob?.cancel()
        _versions.value = VersionsUiState.Loading
        versionsJob = viewModelScope.launch {
            _versions.value = try {
                when (val found = manager.findVersions(title, artist)) {
                    is VersionSearch.Results -> VersionsUiState.Results(found.items)
                    VersionSearch.Empty      -> VersionsUiState.Empty
                    VersionSearch.Offline    -> VersionsUiState.Offline
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                VersionsUiState.Offline
            }
        }
    }

    fun clearVersions() {
        versionsJob?.cancel()
        _versions.value = VersionsUiState.Idle
    }

    override fun onCleared() {
        versionsJob?.cancel()
        super.onCleared()
    }
}
