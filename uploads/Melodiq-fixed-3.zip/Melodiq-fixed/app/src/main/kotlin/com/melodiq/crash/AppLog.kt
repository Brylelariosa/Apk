package com.melodiq.crash

import android.util.Log
import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale

/**
 * Drop-in for [android.util.Log] that also remembers the most recent lines in memory.
 *
 * Those lines ("breadcrumbs") are copied into every crash report, so the report shows what the
 * app was doing in the seconds before it failed, not only where it failed.
 *
 * Use it for discrete events (a song was started, the player changed state). Do not call it from
 * per-frame or per-tick code.
 */
object AppLog {

    private const val CAPACITY = 200

    private class Entry(val timeMs: Long, val text: String)

    private val entries = ArrayDeque<Entry>(CAPACITY)

    fun d(tag: String, message: String) = add(Log.DEBUG, tag, message, null)

    fun i(tag: String, message: String) = add(Log.INFO, tag, message, null)

    fun w(tag: String, message: String, error: Throwable? = null) = add(Log.WARN, tag, message, error)

    fun e(tag: String, message: String, error: Throwable? = null) = add(Log.ERROR, tag, message, error)

    /** The remembered lines, oldest first, each starting with its time of day. */
    fun snapshot(): List<String> {
        val copy = synchronized(entries) { entries.toList() }
        val clock = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
        return copy.map { entry -> "${clock.format(Date(entry.timeMs))}  ${entry.text}" }
    }

    private fun add(priority: Int, tag: String, message: String, error: Throwable?) {
        if (error == null) {
            Log.println(priority, tag, message)
        } else {
            Log.println(priority, tag, message + "\n" + Log.getStackTraceString(error))
        }

        val summary = if (error == null) message else "$message [${error.javaClass.simpleName}: ${error.message}]"
        val entry = Entry(System.currentTimeMillis(), "${levelOf(priority)} $tag: $summary")
        synchronized(entries) {
            if (entries.size >= CAPACITY) entries.pollFirst()
            entries.addLast(entry)
        }
    }

    private fun levelOf(priority: Int): Char = when (priority) {
        Log.ERROR -> 'E'
        Log.WARN -> 'W'
        Log.INFO -> 'I'
        else -> 'D'
    }
}
