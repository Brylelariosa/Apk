package com.melodiq.crash

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.annotation.RequiresApi
import androidx.core.content.ContextCompat
import java.io.File
import java.io.IOException

/**
 * Puts a text file into the public Download folder.
 *
 *  - Android 10+ : through MediaStore.Downloads. The app owns the file it creates, so no
 *                  permission is involved.
 *  - Android 7-9 : a plain file in /Download, which needs the storage permission the app
 *                  already asks for (declared as WRITE_EXTERNAL_STORAGE up to API 28).
 *
 * Throws [IOException] when the file could not be written; the caller decides what to do next.
 */
internal class DownloadsWriter(private val context: Context) {

    fun write(fileName: String, text: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            writeWithMediaStore(fileName, text)
        } else {
            writeToDownloadFolder(fileName, text)
        }
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    private fun writeWithMediaStore(fileName: String, text: String) {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
            put(MediaStore.MediaColumns.MIME_TYPE, MIME_TYPE)
            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            put(MediaStore.MediaColumns.IS_PENDING, 1)   // hidden from other apps until fully written
        }
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw IOException("MediaStore did not create $fileName")

        try {
            val stream = resolver.openOutputStream(uri)
                ?: throw IOException("Cannot open $uri for writing")
            stream.use { it.write(text.toByteArray(Charsets.UTF_8)) }

            values.clear()
            values.put(MediaStore.MediaColumns.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
        } catch (failure: Exception) {
            // Do not leave an empty, half-written entry behind.
            try {
                resolver.delete(uri, null, null)
            } catch (ignored: Exception) {
                // nothing more can be done
            }
            throw failure
        }
    }

    @Suppress("DEPRECATION")
    private fun writeToDownloadFolder(fileName: String, text: String) {
        val granted = ContextCompat.checkSelfPermission(
            context, Manifest.permission.WRITE_EXTERNAL_STORAGE
        ) == PackageManager.PERMISSION_GRANTED
        if (!granted) throw IOException("Storage permission has not been granted yet")

        val folder = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        if (!folder.isDirectory && !folder.mkdirs()) throw IOException("Cannot create ${folder.path}")

        File(folder, fileName).writeText(text, Charsets.UTF_8)
    }

    private companion object {
        const val MIME_TYPE = "text/plain"
    }
}
