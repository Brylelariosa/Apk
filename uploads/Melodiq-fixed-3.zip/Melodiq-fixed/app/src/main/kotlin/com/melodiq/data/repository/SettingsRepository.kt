package com.melodiq.data.repository

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import com.melodiq.data.model.AppSettings
import com.melodiq.data.model.FloatingLyricsSettings
import com.melodiq.data.model.LookSettings
import com.melodiq.data.model.LyricsStyleSettings
import com.melodiq.crash.AppLog
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Every customisation option, stored in DataStore.
 *
 * [settings] is the single source of truth: it is rebuilt from the stored values every time they
 * change, so the Settings screen, Now Playing and the floating-lyrics window (which runs inside
 * the music service) always agree. [update] changes the stored values atomically.
 */
@Singleton
class SettingsRepository @Inject constructor(
    private val dataStore: DataStore<Preferences>
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val settings: StateFlow<AppSettings> = dataStore.data
        .map { decode(it) }
        .catch { emit(AppSettings()) }
        .stateIn(scope, SharingStarted.Eagerly, AppSettings())

    /** Applies [transform] to the stored settings. Safe to call from any thread. */
    fun update(transform: (AppSettings) -> AppSettings) {
        scope.launch {
            try {
                dataStore.edit { prefs -> encode(prefs, transform(decode(prefs))) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                AppLog.w(TAG, "could not save settings", e)
            }
        }
    }

    // ── Keys ─────────────────────────────────────────────────────────────────

    private companion object {
        const val TAG = "Settings"
    }

    private object K {
        // look
        val bgStyle      = stringPreferencesKey("look_bg_style")
        val bgIntensity  = floatPreferencesKey("look_bg_intensity")
        val animSpeed    = floatPreferencesKey("look_anim_speed")
        val animPlaying  = booleanPreferencesKey("look_anim_only_playing")
        val coverStyle   = stringPreferencesKey("look_cover_style")
        val coverMotion  = stringPreferencesKey("look_cover_motion")
        val coverGlow    = booleanPreferencesKey("look_cover_glow")
        val coverSize    = intPreferencesKey("look_cover_size")

        // lyrics in the app
        val lySize       = floatPreferencesKey("ly_size")
        val lyAlign      = stringPreferencesKey("ly_align")
        val lyFont       = stringPreferencesKey("ly_font")
        val lyWeight     = stringPreferencesKey("ly_weight")
        val lyScale      = floatPreferencesKey("ly_active_scale")
        val lyDim        = floatPreferencesKey("ly_inactive_alpha")
        val lyFade       = booleanPreferencesKey("ly_fade_distant")
        val lyColor      = intPreferencesKey("ly_highlight")
        val lyGlow       = booleanPreferencesKey("ly_glow")
        val lySmooth     = booleanPreferencesKey("ly_smooth")
        val lySeek       = booleanPreferencesKey("ly_tap_seek")
        val lyAwake      = booleanPreferencesKey("ly_keep_awake")

        // floating lyrics
        val flEnabled    = booleanPreferencesKey("fl_enabled")
        val flPlaying    = booleanPreferencesKey("fl_only_playing")
        val flHideInApp  = booleanPreferencesKey("fl_hide_in_app")
        val flHideEmpty  = booleanPreferencesKey("fl_hide_no_lyrics")
        val flLines      = intPreferencesKey("fl_lines")
        val flSize       = floatPreferencesKey("fl_size")
        val flColor      = intPreferencesKey("fl_color")
        val flDim        = floatPreferencesKey("fl_inactive_alpha")
        val flFont       = stringPreferencesKey("fl_font")
        val flWeight     = stringPreferencesKey("fl_weight")
        val flAlign      = stringPreferencesKey("fl_align")
        val flShadow     = booleanPreferencesKey("fl_shadow")
        val flBg         = intPreferencesKey("fl_bg_color")
        val flBgAlpha    = floatPreferencesKey("fl_bg_alpha")
        val flRadius     = intPreferencesKey("fl_radius")
        val flAlpha      = floatPreferencesKey("fl_window_alpha")
        val flWidth      = floatPreferencesKey("fl_width")
        val flLocked     = booleanPreferencesKey("fl_locked")
        val flPosX       = floatPreferencesKey("fl_pos_x")
        val flPosY       = floatPreferencesKey("fl_pos_y")
        val flAnim       = stringPreferencesKey("fl_anim")
        val flAnimMs     = intPreferencesKey("fl_anim_ms")
        val flTitle      = booleanPreferencesKey("fl_show_title")
        val flControls   = booleanPreferencesKey("fl_show_controls")
    }

    // ── Reading ──────────────────────────────────────────────────────────────

    private inline fun <reified E : Enum<E>> Preferences.enumOf(key: Preferences.Key<String>, default: E): E {
        val name = this[key] ?: return default
        return enumValues<E>().firstOrNull { it.name == name } ?: default
    }

    private fun decode(p: Preferences): AppSettings {
        val d = AppSettings()
        return AppSettings(
            look = LookSettings(
                backgroundStyle         = p.enumOf(K.bgStyle, d.look.backgroundStyle),
                backgroundIntensity     = (p[K.bgIntensity] ?: d.look.backgroundIntensity).coerceIn(0f, 1f),
                animationSpeed          = (p[K.animSpeed] ?: d.look.animationSpeed).coerceIn(0.25f, 2f),
                animateOnlyWhilePlaying = p[K.animPlaying] ?: d.look.animateOnlyWhilePlaying,
                coverStyle              = p.enumOf(K.coverStyle, d.look.coverStyle),
                coverMotion             = p.enumOf(K.coverMotion, d.look.coverMotion),
                coverGlow               = p[K.coverGlow] ?: d.look.coverGlow,
                coverSizeDp             = (p[K.coverSize] ?: d.look.coverSizeDp).coerceIn(160, 360)
            ),
            lyrics = LyricsStyleSettings(
                textSizeSp     = (p[K.lySize] ?: d.lyrics.textSizeSp).coerceIn(14f, 40f),
                alignment      = p.enumOf(K.lyAlign, d.lyrics.alignment),
                font           = p.enumOf(K.lyFont, d.lyrics.font),
                weight         = p.enumOf(K.lyWeight, d.lyrics.weight),
                activeScale    = (p[K.lyScale] ?: d.lyrics.activeScale).coerceIn(1f, 1.3f),
                inactiveAlpha  = (p[K.lyDim] ?: d.lyrics.inactiveAlpha).coerceIn(0.1f, 1f),
                fadeDistant    = p[K.lyFade] ?: d.lyrics.fadeDistant,
                highlightColor = p[K.lyColor] ?: d.lyrics.highlightColor,
                glow           = p[K.lyGlow] ?: d.lyrics.glow,
                smoothScroll   = p[K.lySmooth] ?: d.lyrics.smoothScroll,
                tapToSeek      = p[K.lySeek] ?: d.lyrics.tapToSeek,
                keepScreenOn   = p[K.lyAwake] ?: d.lyrics.keepScreenOn
            ),
            floating = FloatingLyricsSettings(
                enabled              = p[K.flEnabled] ?: d.floating.enabled,
                showOnlyWhilePlaying = p[K.flPlaying] ?: d.floating.showOnlyWhilePlaying,
                hideInApp            = p[K.flHideInApp] ?: d.floating.hideInApp,
                hideWhenNoLyrics     = p[K.flHideEmpty] ?: d.floating.hideWhenNoLyrics,
                lines                = (p[K.flLines] ?: d.floating.lines).coerceIn(1, 5),
                textSizeSp           = (p[K.flSize] ?: d.floating.textSizeSp).coerceIn(10f, 40f),
                textColor            = p[K.flColor] ?: d.floating.textColor,
                inactiveAlpha        = (p[K.flDim] ?: d.floating.inactiveAlpha).coerceIn(0.1f, 1f),
                font                 = p.enumOf(K.flFont, d.floating.font),
                weight               = p.enumOf(K.flWeight, d.floating.weight),
                alignment            = p.enumOf(K.flAlign, d.floating.alignment),
                textShadow           = p[K.flShadow] ?: d.floating.textShadow,
                backgroundColor      = p[K.flBg] ?: d.floating.backgroundColor,
                backgroundAlpha      = (p[K.flBgAlpha] ?: d.floating.backgroundAlpha).coerceIn(0f, 1f),
                cornerRadiusDp       = (p[K.flRadius] ?: d.floating.cornerRadiusDp).coerceIn(0, 40),
                windowAlpha          = (p[K.flAlpha] ?: d.floating.windowAlpha).coerceIn(0.2f, 1f),
                widthFraction        = (p[K.flWidth] ?: d.floating.widthFraction).coerceIn(0.4f, 1f),
                locked               = p[K.flLocked] ?: d.floating.locked,
                posX                 = (p[K.flPosX] ?: d.floating.posX).coerceIn(0f, 1f),
                posY                 = (p[K.flPosY] ?: d.floating.posY).coerceIn(0f, 1f),
                animation            = p.enumOf(K.flAnim, d.floating.animation),
                animationMs          = (p[K.flAnimMs] ?: d.floating.animationMs).coerceIn(100, 800),
                showTitle            = p[K.flTitle] ?: d.floating.showTitle,
                showControls         = p[K.flControls] ?: d.floating.showControls
            )
        )
    }

    // ── Writing ──────────────────────────────────────────────────────────────

    private fun encode(p: MutablePreferences, s: AppSettings) {
        val l = s.look
        p[K.bgStyle]     = l.backgroundStyle.name
        p[K.bgIntensity] = l.backgroundIntensity
        p[K.animSpeed]   = l.animationSpeed
        p[K.animPlaying] = l.animateOnlyWhilePlaying
        p[K.coverStyle]  = l.coverStyle.name
        p[K.coverMotion] = l.coverMotion.name
        p[K.coverGlow]   = l.coverGlow
        p[K.coverSize]   = l.coverSizeDp

        val y = s.lyrics
        p[K.lySize]   = y.textSizeSp
        p[K.lyAlign]  = y.alignment.name
        p[K.lyFont]   = y.font.name
        p[K.lyWeight] = y.weight.name
        p[K.lyScale]  = y.activeScale
        p[K.lyDim]    = y.inactiveAlpha
        p[K.lyFade]   = y.fadeDistant
        p[K.lyColor]  = y.highlightColor
        p[K.lyGlow]   = y.glow
        p[K.lySmooth] = y.smoothScroll
        p[K.lySeek]   = y.tapToSeek
        p[K.lyAwake]  = y.keepScreenOn

        val f = s.floating
        p[K.flEnabled]   = f.enabled
        p[K.flPlaying]   = f.showOnlyWhilePlaying
        p[K.flHideInApp] = f.hideInApp
        p[K.flHideEmpty] = f.hideWhenNoLyrics
        p[K.flLines]     = f.lines
        p[K.flSize]      = f.textSizeSp
        p[K.flColor]     = f.textColor
        p[K.flDim]       = f.inactiveAlpha
        p[K.flFont]      = f.font.name
        p[K.flWeight]    = f.weight.name
        p[K.flAlign]     = f.alignment.name
        p[K.flShadow]    = f.textShadow
        p[K.flBg]        = f.backgroundColor
        p[K.flBgAlpha]   = f.backgroundAlpha
        p[K.flRadius]    = f.cornerRadiusDp
        p[K.flAlpha]     = f.windowAlpha
        p[K.flWidth]     = f.widthFraction
        p[K.flLocked]    = f.locked
        p[K.flPosX]      = f.posX
        p[K.flPosY]      = f.posY
        p[K.flAnim]      = f.animation.name
        p[K.flAnimMs]    = f.animationMs
        p[K.flTitle]     = f.showTitle
        p[K.flControls]  = f.showControls
    }
}
