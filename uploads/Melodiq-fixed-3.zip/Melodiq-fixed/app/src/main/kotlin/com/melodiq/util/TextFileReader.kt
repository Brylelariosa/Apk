package com.melodiq.util

import android.content.Context
import android.net.Uri
import com.melodiq.crash.AppLog
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Reads a small text file (an .lrc or .txt the user picked) from a content:// uri. */
object TextFileReader {

    private const val MAX_BYTES = 1_000_000

    /** Returns the text, or null when the file is too big, empty or unreadable. */
    suspend fun read(context: Context, uri: Uri): String? = withContext(Dispatchers.IO) {
        try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                val bytes = input.readBytes()
                if (bytes.isEmpty() || bytes.size > MAX_BYTES) null else decode(bytes)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            AppLog.w("TextFileReader", "could not read $uri", e)
            null
        }
    }

    private fun decode(bytes: ByteArray): String {
        // skip a UTF-8 byte-order mark
        var start = 0
        if (bytes.size >= 3 &&
            bytes[0] == 0xEF.toByte() && bytes[1] == 0xBB.toByte() && bytes[2] == 0xBF.toByte()
        ) {
            start = 3
        }
        val utf8 = String(bytes, start, bytes.size - start, Charsets.UTF_8)
        // Old .lrc files are often saved in a legacy 8-bit encoding; UTF-8 then shows replacement characters.
        return if (utf8.contains('\uFFFD')) {
            String(bytes, start, bytes.size - start, Charsets.ISO_8859_1)
        } else {
            utf8
        }
    }
}
