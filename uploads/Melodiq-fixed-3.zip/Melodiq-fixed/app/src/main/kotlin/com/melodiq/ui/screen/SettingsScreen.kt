package com.melodiq.ui.screen

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.melodiq.R
import com.melodiq.data.model.BackgroundStyle
import com.melodiq.data.model.CoverMotion
import com.melodiq.data.model.CoverStyle
import com.melodiq.data.model.FloatingLyricsSettings
import com.melodiq.data.model.LineAnimation
import com.melodiq.data.model.LookSettings
import com.melodiq.data.model.LyricLine
import com.melodiq.data.model.LyricsAlign
import com.melodiq.data.model.LyricsFont
import com.melodiq.data.model.LyricsStyleSettings
import com.melodiq.data.model.LyricsWeight
import com.melodiq.overlay.OverlayPermission
import com.melodiq.ui.components.ChoiceRow
import com.melodiq.ui.components.ColorRow
import com.melodiq.ui.components.FloatingLyricsCard
import com.melodiq.ui.components.IconActionButton
import com.melodiq.ui.components.MelodiqButton
import com.melodiq.ui.components.OnResumeEffect
import com.melodiq.ui.components.OverlayPermissionDialog
import com.melodiq.ui.components.ResetRow
import com.melodiq.ui.components.SettingsSection
import com.melodiq.ui.components.SliderRow
import com.melodiq.ui.components.SwitchRow
import com.melodiq.ui.components.buildLyricWindow
import com.melodiq.ui.theme.TextMuted
import com.melodiq.ui.theme.TextPrimary
import com.melodiq.ui.theme.TextSecondary
import com.melodiq.ui.viewmodel.SettingsViewModel
import kotlinx.coroutines.delay
import java.util.Locale

/** How Now Playing, the lyrics and the floating lyrics look and behave. Every change applies immediately. */
@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    viewModel: SettingsViewModel = hiltViewModel()
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var overlayAllowed by remember { mutableStateOf(OverlayPermission.isGranted(context)) }
    var showPermissionDialog by remember { mutableStateOf(false) }
    var waitingForPermission by remember { mutableStateOf(false) }

    // Back from the system "Display over other apps" screen: pick up the new permission and, if
    // that is why the user went there, finish switching the floating lyrics on.
    OnResumeEffect {
        overlayAllowed = OverlayPermission.isGranted(context)
        if (waitingForPermission && overlayAllowed) {
            waitingForPermission = false
            viewModel.updateFloating { it.copy(enabled = true) }
        }
    }

    if (showPermissionDialog) {
        OverlayPermissionDialog(
            onDismiss = { showPermissionDialog = false },
            onOpenSettings = {
                showPermissionDialog = false
                waitingForPermission = true
                OverlayPermission.openSettings(context)
            }
        )
    }

    Column(
        Modifier
            .fillMaxSize()
            .systemBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconActionButton(
                icon               = R.drawable.ic_arrow_back,
                contentDescription = "Back",
                onClick            = onBack,
                tint               = Color.White,
                buttonSize         = 48.dp,
                iconSize           = 24.dp
            )
            Text(
                text     = "Settings",
                style    = MaterialTheme.typography.titleLarge,
                color    = TextPrimary,
                modifier = Modifier.padding(start = 8.dp)
            )
        }

        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(bottom = 32.dp)
        ) {
            LookSection(
                look     = settings.look,
                update   = { transform -> viewModel.updateLook(transform) },
                onReset  = { viewModel.resetLook() }
            )
            LyricsSection(
                style    = settings.lyrics,
                update   = { transform -> viewModel.updateLyrics(transform) },
                onReset  = { viewModel.resetLyrics() }
            )
            FloatingSection(
                floating         = settings.floating,
                overlayAllowed   = overlayAllowed,
                onAskPermission  = { showPermissionDialog = true },
                update           = { transform -> viewModel.updateFloating(transform) },
                onReset          = { viewModel.resetFloating() }
            )
        }
    }
}

// ── Now Playing look ──────────────────────────────────────────────────────────

@Composable
private fun LookSection(
    look: LookSettings,
    update: ((LookSettings) -> LookSettings) -> Unit,
    onReset: () -> Unit
) {
    SettingsSection("Now Playing look") {
        ChoiceRow(
            title    = "Background",
            options  = BackgroundStyle.values().toList(),
            selected = look.backgroundStyle,
            label    = { it.label },
            onSelect = { choice -> update { it.copy(backgroundStyle = choice) } }
        )
        SliderRow(
            title      = "Glow strength",
            value      = look.backgroundIntensity,
            range      = 0f..1f,
            valueLabel = { percent(it) },
            onCommit   = { v -> update { it.copy(backgroundIntensity = v) } }
        )
        SliderRow(
            title      = "Animation speed",
            value      = look.animationSpeed,
            range      = 0.25f..2f,
            valueLabel = { String.format(Locale.US, "%.2fx", it) },
            onCommit   = { v -> update { it.copy(animationSpeed = v) } }
        )
        SwitchRow(
            title    = "Animate only while playing",
            subtitle = "Everything holds still when the music is paused, which saves battery.",
            checked  = look.animateOnlyWhilePlaying,
            onChange = { on -> update { it.copy(animateOnlyWhilePlaying = on) } }
        )
        ChoiceRow(
            title    = "Cover shape",
            options  = CoverStyle.values().toList(),
            selected = look.coverStyle,
            label    = { it.label },
            onSelect = { choice -> update { it.copy(coverStyle = choice) } }
        )
        ChoiceRow(
            title    = "Cover motion",
            options  = CoverMotion.values().toList(),
            selected = look.coverMotion,
            label    = { it.label },
            onSelect = { choice -> update { it.copy(coverMotion = choice) } }
        )
        SwitchRow(
            title    = "Cover glow",
            checked  = look.coverGlow,
            onChange = { on -> update { it.copy(coverGlow = on) } }
        )
        SliderRow(
            title      = "Cover size",
            value      = look.coverSizeDp.toFloat(),
            range      = 160f..360f,
            valueLabel = { it.toInt().toString() + " dp" },
            onCommit   = { v -> update { it.copy(coverSizeDp = v.toInt()) } }
        )
        ResetRow(text = "Reset look", onReset = onReset)
    }
}

// ── Lyrics in the app ─────────────────────────────────────────────────────────

@Composable
private fun LyricsSection(
    style: LyricsStyleSettings,
    update: ((LyricsStyleSettings) -> LyricsStyleSettings) -> Unit,
    onReset: () -> Unit
) {
    SettingsSection("Lyrics") {
        SliderRow(
            title      = "Text size",
            value      = style.textSizeSp,
            range      = 14f..40f,
            valueLabel = { it.toInt().toString() + " sp" },
            onCommit   = { v -> update { it.copy(textSizeSp = v) } }
        )
        ChoiceRow(
            title    = "Alignment",
            options  = LyricsAlign.values().toList(),
            selected = style.alignment,
            label    = { it.label },
            onSelect = { choice -> update { it.copy(alignment = choice) } }
        )
        ChoiceRow(
            title    = "Font",
            options  = LyricsFont.values().toList(),
            selected = style.font,
            label    = { it.label },
            onSelect = { choice -> update { it.copy(font = choice) } }
        )
        ChoiceRow(
            title    = "Weight",
            options  = LyricsWeight.values().toList(),
            selected = style.weight,
            label    = { it.label },
            onSelect = { choice -> update { it.copy(weight = choice) } }
        )
        SliderRow(
            title      = "Current line size",
            value      = style.activeScale,
            range      = 1f..1.3f,
            valueLabel = { percent(it) },
            onCommit   = { v -> update { it.copy(activeScale = v) } }
        )
        SliderRow(
            title      = "Other lines brightness",
            value      = style.inactiveAlpha,
            range      = 0.1f..1f,
            valueLabel = { percent(it) },
            onCommit   = { v -> update { it.copy(inactiveAlpha = v) } }
        )
        SwitchRow(
            title    = "Fade distant lines",
            checked  = style.fadeDistant,
            onChange = { on -> update { it.copy(fadeDistant = on) } }
        )
        ColorRow(
            title           = "Current line colour",
            selected        = style.highlightColor,
            allowAlbumColor = true,
            onSelect        = { argb -> update { it.copy(highlightColor = argb) } }
        )
        SwitchRow(
            title    = "Glow behind the current line",
            checked  = style.glow,
            onChange = { on -> update { it.copy(glow = on) } }
        )
        SwitchRow(
            title    = "Smooth scrolling",
            subtitle = "Off makes the lyrics jump to each line instead of gliding.",
            checked  = style.smoothScroll,
            onChange = { on -> update { it.copy(smoothScroll = on) } }
        )
        SwitchRow(
            title    = "Tap a line to jump to it",
            checked  = style.tapToSeek,
            onChange = { on -> update { it.copy(tapToSeek = on) } }
        )
        SwitchRow(
            title    = "Keep the screen on",
            subtitle = "While the lyrics are showing.",
            checked  = style.keepScreenOn,
            onChange = { on -> update { it.copy(keepScreenOn = on) } }
        )
        ResetRow(text = "Reset lyrics style", onReset = onReset)
    }
}

// ── Floating lyrics ───────────────────────────────────────────────────────────

@Composable
private fun FloatingSection(
    floating: FloatingLyricsSettings,
    overlayAllowed: Boolean,
    onAskPermission: () -> Unit,
    update: ((FloatingLyricsSettings) -> FloatingLyricsSettings) -> Unit,
    onReset: () -> Unit
) {
    SettingsSection("Floating lyrics") {
        SwitchRow(
            title    = "Show floating lyrics",
            subtitle = "The current line in a small window on top of other apps. Drag it to move it.",
            checked  = floating.enabled,
            onChange = { on ->
                if (on && !overlayAllowed) onAskPermission() else update { it.copy(enabled = on) }
            }
        )
        if (!overlayAllowed) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Text(
                    text  = "Android needs your permission to show a window above other apps.",
                    color = TextSecondary,
                    style = MaterialTheme.typography.bodySmall
                )
                Spacer(Modifier.height(8.dp))
                MelodiqButton(text = "Allow display over other apps", onClick = onAskPermission)
            }
        }

        FloatingPreview(floating)

        SubHeading("When to show")
        SwitchRow(
            title    = "Only while music plays",
            checked  = floating.showOnlyWhilePlaying,
            onChange = { on -> update { it.copy(showOnlyWhilePlaying = on) } }
        )
        SwitchRow(
            title    = "Hide while Melodiq is open",
            subtitle = "The lyrics are already on the Now Playing screen.",
            checked  = floating.hideInApp,
            onChange = { on -> update { it.copy(hideInApp = on) } }
        )
        SwitchRow(
            title    = "Hide when there are no synced lyrics",
            checked  = floating.hideWhenNoLyrics,
            onChange = { on -> update { it.copy(hideWhenNoLyrics = on) } }
        )

        SubHeading("Text")
        SliderRow(
            title      = "Lines shown",
            value      = floating.lines.toFloat(),
            range      = 1f..5f,
            steps      = 3,
            valueLabel = { it.toInt().toString() },
            onCommit   = { v -> update { it.copy(lines = v.toInt()) } }
        )
        SliderRow(
            title      = "Text size",
            value      = floating.textSizeSp,
            range      = 10f..40f,
            valueLabel = { it.toInt().toString() + " sp" },
            onCommit   = { v -> update { it.copy(textSizeSp = v) } }
        )
        ChoiceRow(
            title    = "Font",
            options  = LyricsFont.values().toList(),
            selected = floating.font,
            label    = { it.label },
            onSelect = { choice -> update { it.copy(font = choice) } }
        )
        ChoiceRow(
            title    = "Weight",
            options  = LyricsWeight.values().toList(),
            selected = floating.weight,
            label    = { it.label },
            onSelect = { choice -> update { it.copy(weight = choice) } }
        )
        ChoiceRow(
            title    = "Alignment",
            options  = LyricsAlign.values().toList(),
            selected = floating.alignment,
            label    = { it.label },
            onSelect = { choice -> update { it.copy(alignment = choice) } }
        )
        ColorRow(
            title    = "Text colour",
            selected = floating.textColor,
            onSelect = { argb -> update { it.copy(textColor = argb) } }
        )
        SliderRow(
            title      = "Other lines brightness",
            value      = floating.inactiveAlpha,
            range      = 0.1f..1f,
            valueLabel = { percent(it) },
            onCommit   = { v -> update { it.copy(inactiveAlpha = v) } }
        )
        SwitchRow(
            title    = "Text shadow",
            subtitle = "Keeps the words readable on any background.",
            checked  = floating.textShadow,
            onChange = { on -> update { it.copy(textShadow = on) } }
        )

        SubHeading("Window")
        ColorRow(
            title    = "Background colour",
            selected = floating.backgroundColor,
            onSelect = { argb -> update { it.copy(backgroundColor = argb) } }
        )
        SliderRow(
            title      = "Background opacity",
            value      = floating.backgroundAlpha,
            range      = 0f..1f,
            valueLabel = { percent(it) },
            onCommit   = { v -> update { it.copy(backgroundAlpha = v) } }
        )
        SliderRow(
            title      = "Corner radius",
            value      = floating.cornerRadiusDp.toFloat(),
            range      = 0f..40f,
            valueLabel = { it.toInt().toString() + " dp" },
            onCommit   = { v -> update { it.copy(cornerRadiusDp = v.toInt()) } }
        )
        SliderRow(
            title      = "Width",
            value      = floating.widthFraction,
            range      = 0.4f..1f,
            valueLabel = { percent(it) },
            onCommit   = { v -> update { it.copy(widthFraction = v) } }
        )
        SliderRow(
            title      = "Window opacity",
            value      = floating.windowAlpha,
            range      = 0.2f..1f,
            valueLabel = { percent(it) },
            onCommit   = { v -> update { it.copy(windowAlpha = v) } }
        )
        SwitchRow(
            title    = "Show song title",
            checked  = floating.showTitle,
            onChange = { on -> update { it.copy(showTitle = on) } }
        )
        SwitchRow(
            title    = "Show playback buttons",
            checked  = floating.showControls,
            onChange = { on -> update { it.copy(showControls = on) } }
        )
        SwitchRow(
            title    = "Lock position",
            subtitle = "Touches pass through the window to the app below. Unlock it here to move it again.",
            checked  = floating.locked,
            onChange = { on -> update { it.copy(locked = on) } }
        )
        ResetRow(
            text    = "Reset position",
            onReset = { update { it.copy(posX = 0.5f, posY = 0.14f) } }
        )

        SubHeading("Animation")
        ChoiceRow(
            title    = "When the line changes",
            options  = LineAnimation.values().toList(),
            selected = floating.animation,
            label    = { it.label },
            onSelect = { choice -> update { it.copy(animation = choice) } }
        )
        SliderRow(
            title      = "Animation length",
            value      = floating.animationMs.toFloat(),
            range      = 100f..800f,
            valueLabel = { it.toInt().toString() + " ms" },
            onCommit   = { v -> update { it.copy(animationMs = v.toInt()) } }
        )

        ResetRow(text = "Reset floating lyrics", onReset = onReset)
    }
}

@Composable
private fun SubHeading(text: String) {
    Text(
        text     = text,
        color    = TextMuted,
        style    = MaterialTheme.typography.labelLarge,
        modifier = Modifier.padding(start = 16.dp, top = 16.dp, bottom = 2.dp)
    )
}

/** The real floating window, drawn with the settings as they are right now, advancing by itself. */
@Composable
private fun FloatingPreview(floating: FloatingLyricsSettings) {
    val sample = remember {
        listOf(
            "Walking down the quiet street",
            "Streetlights painting gold on glass",
            "Every little thing I need",
            "Is right here while the moments pass",
            "So play the song again",
            "And let the night go slow"
        ).mapIndexed { index, text -> LyricLine(timeMs = index * 4_000L, text = text) }
    }
    var index by remember { mutableIntStateOf(1) }
    LaunchedEffect(sample.size) {
        while (true) {
            delay(2_800L)
            index = (index + 1) % sample.size
        }
    }
    val window = remember(index, floating.lines) { buildLyricWindow(sample, index, floating.lines) }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF3A2A6B), Color(0xFF1B6B7A))))
            .padding(vertical = 24.dp),
        contentAlignment = Alignment.Center
    ) {
        FloatingLyricsCard(
            window    = window,
            settings  = floating,
            modifier  = Modifier.fillMaxWidth(floating.widthFraction),
            title     = if (floating.showTitle) "Song title \u2014 Artist" else null,
            isPlaying = true
        )
    }
}

private fun percent(value: Float): String = (value * 100f).toInt().toString() + "%"
