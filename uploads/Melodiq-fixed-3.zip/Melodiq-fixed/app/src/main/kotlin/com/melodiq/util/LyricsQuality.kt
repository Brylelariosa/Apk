package com.melodiq.util

import com.melodiq.data.model.LyricLine

/**
 * Decides whether a set of lyrics looks complete, and repairs the most common way they are not:
 * LRCLIB records often carry a synced version that stops early while the plain-text version of the
 * same record still has every line.
 *
 * Pure functions only — no Android, no network.
 */
object LyricsQuality {

    class Assessment(
        val syncedLines: Int,
        val plainLines: Int,
        val possiblyIncomplete: Boolean
    )

    /** Lines of a plain-text lyric that are real words (blank lines and [Chorus]-style tags don't count). */
    fun plainLines(plain: String?): List<String> {
        if (plain.isNullOrBlank()) return emptyList()
        val out = ArrayList<String>()
        for (raw in plain.lines()) {
            val line = raw.trim()
            if (line.isEmpty()) continue
            if (line.startsWith("[") && line.endsWith("]")) continue
            out.add(line)
        }
        return out
    }

    fun plainLineCount(plain: String?): Int = plainLines(plain).size

    /**
     * @param timed    the synced lines (may be empty)
     * @param plain    the plain-text version (may be null)
     * @param durationMs length of the song, 0 when unknown
     */
    fun assess(timed: List<LyricLine>, plain: String?, durationMs: Long): Assessment {
        val syncedCount = timed.count { it.isTimed }
        val plainCount  = plainLineCount(plain)

        val incomplete = when {
            // Both versions exist: the synced one should cover (nearly) every line of the plain one.
            syncedCount > 0 && plainCount >= 8 -> syncedCount < plainCount * 0.8
            // Only timing is known: judge by how much of the song it covers.
            syncedCount > 0 -> durationMs >= 120_000L &&
                (syncedCount < 8 || coverage(timed, durationMs) < 0.5f)
            // Plain text only: a few lines for a long song is suspicious.
            plainCount > 0 -> durationMs >= 150_000L && plainCount < 8
            else -> false
        }
        return Assessment(syncedCount, plainCount, incomplete)
    }

    private fun coverage(timed: List<LyricLine>, durationMs: Long): Float {
        if (durationMs <= 0L) return 1f
        val last = timed.lastOrNull { it.isTimed } ?: return 0f
        return last.timeMs.toFloat() / durationMs.toFloat()
    }

    /**
     * When the synced lines are (mostly) a prefix of the plain-text lyrics, appends the plain lines
     * that come after them, without timing, so the song is shown in full. Returns [timed] unchanged
     * when the two versions don't line up well enough to trust the result.
     */
    fun withMissingTail(timed: List<LyricLine>, plain: String): List<LyricLine> {
        if (timed.isEmpty()) return timed
        val plainLines = plainLines(plain)
        if (plainLines.size <= timed.size) return timed

        val normalisedPlain = plainLines.map { TrackMatcher.normalize(it) }
        var cursor  = 0
        var matched = 0
        var checked = 0
        for (line in timed) {
            val target = TrackMatcher.normalize(line.text)
            if (target.isEmpty()) continue
            checked++
            var j = cursor
            while (j < normalisedPlain.size && normalisedPlain[j] != target) j++
            if (j < normalisedPlain.size) {
                matched++
                cursor = j + 1
            }
        }
        if (checked == 0 || matched < checked * 0.9) return timed

        val tail = plainLines.drop(cursor)
        if (tail.isEmpty()) return timed
        return timed + tail.map { LyricLine(timeMs = Long.MAX_VALUE, text = it, isTimed = false) }
    }
}
