package com.melodiq.util

import kotlin.random.Random

/**
 * Builds shuffle orders. Pure functions (no Android, no player) so the rules are easy to reason about:
 *
 *  * a "deck" is a random permutation of every position in the queue — each song appears exactly once,
 *    so nothing is skipped and nothing repeats until the whole deck has been played;
 *  * the song that is playing right now always comes first, so what you hear never changes when a
 *    deck is (re)built;
 *  * when shuffle is switched on half-way, songs that were already played stay behind the current
 *    song (that is what "Previous" walks back through) and only the unplayed ones are shuffled.
 */
object ShuffleDeck {

    class Deck(
        /** Queue positions in the order they will be played. */
        val order: IntArray,
        /** True when every song had already been played, so a brand-new pass was started. */
        val newPass: Boolean
    )

    /** A full random deck of [size] positions with [first] at the front (when it is a valid position). */
    fun fresh(size: Int, first: Int, random: Random): IntArray {
        val others = ArrayList<Int>(size)
        for (i in 0 until size) {
            if (i != first) others.add(i)
        }
        others.shuffle(random)

        val out = IntArray(size)
        var pos = 0
        if (first in 0 until size) {
            out[pos] = first
            pos++
        }
        for (i in others) {
            out[pos] = i
            pos++
        }
        return out
    }

    /**
     * Deck for "shuffle was just switched on": [playedInOrder] are the positions already played in
     * this pass (oldest first). They are kept in front of [current]; everything else is shuffled behind it.
     * If nothing is left to play, a new pass starts with [current] first.
     */
    fun resume(size: Int, current: Int, playedInOrder: List<Int>, random: Random): Deck {
        val history = LinkedHashSet<Int>()
        for (i in playedInOrder) {
            if (i in 0 until size && i != current) history.add(i)
        }
        val unplayed = ArrayList<Int>()
        for (i in 0 until size) {
            if (i != current && !history.contains(i)) unplayed.add(i)
        }
        if (unplayed.isEmpty()) {
            return Deck(fresh(size, current, random), newPass = size > 1)
        }
        unplayed.shuffle(random)

        val out = IntArray(size)
        var pos = 0
        for (i in history) {
            out[pos] = i
            pos++
        }
        if (current in 0 until size) {
            out[pos] = current
            pos++
        }
        for (i in unplayed) {
            out[pos] = i
            pos++
        }
        return Deck(out, newPass = false)
    }
}
