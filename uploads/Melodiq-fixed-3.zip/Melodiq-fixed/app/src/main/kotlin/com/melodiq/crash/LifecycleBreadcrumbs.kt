package com.melodiq.crash

import android.app.Activity
import android.app.Application
import android.os.Bundle
import java.util.concurrent.atomic.AtomicInteger

/** Lets a crash report say whether the user was looking at the app. Fed by [LifecycleBreadcrumbs]. */
internal object AppVisibility {

    private val startedActivities = AtomicInteger(0)

    fun isInForeground(): Boolean = startedActivities.get() > 0

    fun activityStarted() {
        startedActivities.incrementAndGet()
    }

    fun activityStopped() {
        if (startedActivities.decrementAndGet() < 0) startedActivities.set(0)
    }
}

/** Records every Activity lifecycle step as a breadcrumb, without touching the Activities themselves. */
internal class LifecycleBreadcrumbs : Application.ActivityLifecycleCallbacks {

    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {
        log(activity, if (savedInstanceState == null) "created" else "re-created")
    }

    override fun onActivityStarted(activity: Activity) {
        AppVisibility.activityStarted()
        log(activity, "started")
    }

    override fun onActivityResumed(activity: Activity) = log(activity, "resumed")

    override fun onActivityPaused(activity: Activity) = log(activity, "paused")

    override fun onActivityStopped(activity: Activity) {
        AppVisibility.activityStopped()
        log(activity, "stopped")
    }

    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) = Unit

    override fun onActivityDestroyed(activity: Activity) = log(activity, "destroyed")

    private fun log(activity: Activity, what: String) {
        AppLog.d("Lifecycle", "${activity.javaClass.simpleName} $what")
    }
}
