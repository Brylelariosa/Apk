package com.melodiq.data.model

import androidx.compose.runtime.Immutable

// ── Choices ──────────────────────────────────────────────────────────────────

enum class BackgroundStyle(val label: String) {
    /** Soft colour glows that drift slowly (no lines, no rotation). */
    AURORA("Aurora"),
    /** One glow behind the cover that breathes. */
    PULSE("Pulse"),
    /** A still gradient. */
    STATIC("Still"),
    /** One flat colour. */
    OFF("Plain")
}

enum class CoverStyle(val label: String) { ROUNDED("Rounded"), CIRCLE("Circle") }

enum class CoverMotion(val label: String) {
    /** Grows and shrinks very slightly while music plays. */
    BREATHE("Breathe"),
    /** Floats up and down a few pixels. */
    FLOAT("Float"),
    /** Turns like a record (the old behaviour). */
    SPIN("Spin"),
    NONE("None")
}

enum class LyricsFont(val label: String) {
    DEFAULT("Default"), SERIF("Serif"), MONO("Mono"), CURSIVE("Script")
}

enum class LyricsWeight(val label: String) { NORMAL("Regular"), MEDIUM("Medium"), BOLD("Bold") }

enum class LyricsAlign(val label: String) { START("Left"), CENTER("Center"), END("Right") }

/** How the floating lyrics change from one line to the next. */
enum class LineAnimation(val label: String) { NONE("None"), FADE("Fade"), SLIDE("Slide"), POP("Pop") }

// ── Settings groups ──────────────────────────────────────────────────────────

/** How the Now Playing screen looks and moves. */
@Immutable
data class LookSettings(
    val backgroundStyle: BackgroundStyle = BackgroundStyle.AURORA,
    /** 0..1 — how strong the glows are. */
    val backgroundIntensity: Float = 0.55f,
    /** 0.25..2 — speed of every ambient animation. */
    val animationSpeed: Float = 1f,
    /** When on, everything freezes while the music is paused (saves battery). */
    val animateOnlyWhilePlaying: Boolean = true,
    val coverStyle: CoverStyle = CoverStyle.ROUNDED,
    val coverMotion: CoverMotion = CoverMotion.BREATHE,
    val coverGlow: Boolean = true,
    val coverSizeDp: Int = 280
)

/** How lyrics look inside the app. Colours are ARGB ints; 0 means "use the album colour". */
@Immutable
data class LyricsStyleSettings(
    val textSizeSp: Float = 22f,
    val alignment: LyricsAlign = LyricsAlign.CENTER,
    val font: LyricsFont = LyricsFont.DEFAULT,
    val weight: LyricsWeight = LyricsWeight.MEDIUM,
    /** Size of the current line compared to the others (1 = same size). */
    val activeScale: Float = 1.12f,
    /** Opacity of the lines that are not playing (0..1). */
    val inactiveAlpha: Float = 0.45f,
    /** Lines further away from the current one fade out more. */
    val fadeDistant: Boolean = true,
    val highlightColor: Int = 0xFFFFFFFF.toInt(),
    val glow: Boolean = true,
    val smoothScroll: Boolean = true,
    val tapToSeek: Boolean = true,
    val keepScreenOn: Boolean = false
)

/** The lyrics window that floats above other apps. */
@Immutable
data class FloatingLyricsSettings(
    val enabled: Boolean = false,
    val showOnlyWhilePlaying: Boolean = true,
    /** Hide the window while Melodiq itself is open (it already shows the lyrics). */
    val hideInApp: Boolean = true,
    val hideWhenNoLyrics: Boolean = true,
    /** How many lines are visible: 1..5. */
    val lines: Int = 3,
    val textSizeSp: Float = 18f,
    val textColor: Int = 0xFFFFFFFF.toInt(),
    /** Opacity of the lines that are not playing (0..1). */
    val inactiveAlpha: Float = 0.55f,
    val font: LyricsFont = LyricsFont.DEFAULT,
    val weight: LyricsWeight = LyricsWeight.BOLD,
    val alignment: LyricsAlign = LyricsAlign.CENTER,
    val textShadow: Boolean = true,
    val backgroundColor: Int = 0xFF000000.toInt(),
    val backgroundAlpha: Float = 0.55f,
    val cornerRadiusDp: Int = 20,
    /** Opacity of the whole window (0.2..1). */
    val windowAlpha: Float = 1f,
    /** Width as a fraction of the screen (0.4..1). */
    val widthFraction: Float = 0.92f,
    /** Locked windows let touches pass through to the app below. */
    val locked: Boolean = false,
    /** Horizontal position, 0 = left edge … 1 = right edge. */
    val posX: Float = 0.5f,
    /** Vertical position of the top edge as a fraction of the screen height. */
    val posY: Float = 0.14f,
    val animation: LineAnimation = LineAnimation.SLIDE,
    val animationMs: Int = 300,
    val showTitle: Boolean = false,
    val showControls: Boolean = false
)

@Immutable
data class AppSettings(
    val look: LookSettings = LookSettings(),
    val lyrics: LyricsStyleSettings = LyricsStyleSettings(),
    val floating: FloatingLyricsSettings = FloatingLyricsSettings()
)
