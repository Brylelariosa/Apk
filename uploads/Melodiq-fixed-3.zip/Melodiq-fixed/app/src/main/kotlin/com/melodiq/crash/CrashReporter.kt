package com.melodiq.crash

import android.app.Application
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.annotation.RequiresApi
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

/**
 * Entry point of the crash-logging feature. No PC, root or Shizuku involved.
 *
 *  - [install] hooks the uncaught-exception handler (call it once, as early as possible).
 *  - A crash is written to private storage first, then copied to
 *    Download/Melodiq_crash_<date>_<time>.txt. If the copy fails it is retried on the next start.
 *  - [recordNonFatal] saves a report for an error the app survived (for example a song the
 *    player could not play), and the next start also reports runs that ended without any Java
 *    exception (native crash, ANR, killed by the system) on Android 11+.
 *  - [notice] tells the UI what was saved so the user can find and share it.
 */
object CrashReporter {

    private const val TAG = "CrashReporter"
    private const val MAX_NON_FATAL_REPORTS_PER_RUN = 5

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mainHandler = Handler(Looper.getMainLooper())

    private lateinit var app: Application
    private lateinit var builder: CrashReportBuilder
    private lateinit var downloads: DownloadsWriter
    private lateinit var store: CrashLogStore

    @Volatile
    private var installed = false

    private val nonFatalSaved = AtomicInteger(0)
    private val nonFatalSeen = ConcurrentHashMap.newKeySet<String>()

    private val _notice = MutableStateFlow<CrashNotice?>(null)

    /** Set when there is a report the user should know about; cleared by [dismissNotice]. */
    val notice: StateFlow<CrashNotice?> = _notice.asStateFlow()

    fun install(application: Application) {
        synchronized(this) {
            if (installed) return
            app = application
            builder = CrashReportBuilder(application)
            downloads = DownloadsWriter(application)
            store = CrashLogStore(application)

            application.registerActivityLifecycleCallbacks(LifecycleBreadcrumbs())
            Thread.setDefaultUncaughtExceptionHandler(
                FatalCrashHandler(Thread.getDefaultUncaughtExceptionHandler()) { thread, error ->
                    handleFatal(thread, error)
                }
            )
            installed = true
        }
        AppLog.i(TAG, "crash logger installed")
        scope.launch { recoverEarlierRuns() }
    }

    /** The user has seen the dialog; forget the reports it was about. */
    fun dismissNotice() {
        _notice.value = null
        scope.launch { store.clearUnseen() }
    }

    // ── A crash is happening right now ───────────────────────────────────────

    private fun handleFatal(thread: Thread, error: Throwable) {
        val now = System.currentTimeMillis()
        val fileName = fileNameFor(ReportKind.FATAL, now)
        val text = try {
            builder.fatal(now, thread, error)
        } catch (failure: Throwable) {
            // For example out of memory while building the full report: keep at least the stack trace.
            "Melodiq CRASH (short report)\n" + error.stackTraceToString()
        }

        // Private copy first: instant, no permission, and it is what makes a failed export retryable.
        val pending = store.savePending(fileName, text)
        exportToDownloads(pending, text)
    }

    // ── Errors the app survived ──────────────────────────────────────────────

    /**
     * Saves a report for a handled error. Rate-limited, so a playlist full of broken files
     * cannot flood the Download folder.
     */
    fun recordNonFatal(label: String, error: Throwable) {
        AppLog.e(TAG, label, error)
        if (!installed) return
        if (!nonFatalSeen.add("${error.javaClass.name}|${error.message}")) return
        if (nonFatalSaved.incrementAndGet() > MAX_NON_FATAL_REPORTS_PER_RUN) return

        val thread = Thread.currentThread()
        scope.launch {
            try {
                val now = System.currentTimeMillis()
                val fileName = fileNameFor(ReportKind.NON_FATAL, now)
                downloads.write(fileName, builder.nonFatal(now, thread, label, error))
                toast("Error log saved to Download/$fileName")
            } catch (failure: Throwable) {
                AppLog.w(TAG, "Could not save the error log", failure)
            }
        }
    }

    // ── Start of the next run ────────────────────────────────────────────────

    private fun recoverEarlierRuns() {
        try {
            retryPendingExports()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) saveEarlierExits()
            _notice.value = buildNotice()
        } catch (failure: Throwable) {
            // The logger must never be the reason the app dies.
            AppLog.w(TAG, "Could not recover reports from earlier runs", failure)
        }
    }

    private fun retryPendingExports() {
        for (file in store.pending()) {
            exportToDownloads(file, file.readText(Charsets.UTF_8))
        }
    }

    @RequiresApi(Build.VERSION_CODES.R)
    private fun saveEarlierExits() {
        for (exit in ExitInfoCollector(app).collectNew()) {
            val fileName = fileNameFor(ReportKind.PREVIOUS_RUN, exit.timeMs)
            val text = builder.previousRun(exit.timeMs, exit.details)
            exportToDownloads(store.savePending(fileName, text), text)
        }
    }

    private fun buildNotice(): CrashNotice? {
        val inDownloads = store.unseen()
        val stillPending = store.pending()
        val newest = (inDownloads + stillPending).maxByOrNull { it.lastModified() } ?: return null
        return CrashNotice(
            fileName = newest.name,
            savedToDownloads = newest in inDownloads,
            text = newest.readText(Charsets.UTF_8),
            moreReports = inDownloads.size + stillPending.size - 1
        )
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    /** Copies a pending report to Download and, once that worked, moves it to the "tell the user" list. */
    private fun exportToDownloads(pending: File, text: String) {
        try {
            downloads.write(pending.name, text)
            store.markExported(pending)
        } catch (failure: Exception) {
            AppLog.w(TAG, "Could not copy ${pending.name} to Download; will retry on the next start", failure)
        }
    }

    private fun fileNameFor(kind: ReportKind, timeMs: Long): String {
        val stamp = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(Date(timeMs))
        return "${kind.filePrefix}_$stamp.txt"
    }

    private fun toast(message: String) {
        mainHandler.post { Toast.makeText(app, message, Toast.LENGTH_LONG).show() }
    }
}
