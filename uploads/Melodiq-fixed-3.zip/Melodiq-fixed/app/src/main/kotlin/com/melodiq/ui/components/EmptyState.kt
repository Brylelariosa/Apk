package com.melodiq.ui.components

import androidx.annotation.DrawableRes
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.melodiq.ui.theme.PrimaryPurple
import com.melodiq.ui.theme.TextPrimary
import com.melodiq.ui.theme.TextSecondary

/** Icon + title + hint + optional action buttons. Replaces the emoji placeholders. */
@Composable
fun EmptyState(
    @DrawableRes icon: Int,
    title: String,
    modifier: Modifier = Modifier,
    message: String? = null,
    accent: Color = PrimaryPurple,
    actions: @Composable ColumnScope.() -> Unit = {}
) {
    Column(
        modifier            = modifier
            .fillMaxWidth()
            .padding(horizontal = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(88.dp)
                .clip(CircleShape)
                .background(
                    Brush.linearGradient(
                        listOf(accent.copy(alpha = 0.28f), accent.copy(alpha = 0.08f))
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            VectorIcon(id = icon, tint = accent, size = 40.dp)
        }

        Spacer(Modifier.height(20.dp))
        Text(
            text      = title,
            style     = MaterialTheme.typography.titleMedium,
            color     = TextPrimary,
            textAlign = TextAlign.Center
        )
        if (message != null) {
            Spacer(Modifier.height(6.dp))
            Text(
                text      = message,
                style     = MaterialTheme.typography.bodySmall,
                color     = TextSecondary,
                textAlign = TextAlign.Center
            )
        }
        Spacer(Modifier.height(24.dp))
        actions()
    }
}
