package com.melodiq.ui.screen

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.melodiq.R
import com.melodiq.ui.components.ButtonStyle
import com.melodiq.ui.components.EmptyState
import com.melodiq.ui.components.IconActionButton
import com.melodiq.ui.components.MelodiqButton
import com.melodiq.ui.components.SongItem
import com.melodiq.ui.theme.Divider
import com.melodiq.ui.theme.PrimaryPurple
import com.melodiq.ui.theme.TextMuted
import com.melodiq.ui.theme.TextPrimary
import com.melodiq.ui.theme.TextSecondary
import com.melodiq.ui.viewmodel.LibraryViewModel
import com.melodiq.ui.viewmodel.PlayerViewModel

@Composable
fun LibraryScreen(
    onNavigateToNowPlaying: () -> Unit,
    libraryVm: LibraryViewModel,
    playerVm: PlayerViewModel
) {
    val uiState     by libraryVm.uiState.collectAsStateWithLifecycle()
    val playerState by playerVm.state.collectAsStateWithLifecycle()
    val currentId   = playerState.currentSong?.id

    Column(modifier = Modifier.fillMaxSize()) {
        LibraryHeader(
            isLoading = uiState.isLoading,
            onRefresh = libraryVm::syncLibrary
        )

        if (uiState.allSongs.isEmpty() && !uiState.isLoading) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                EmptyState(
                    icon    = R.drawable.ic_library_music,
                    title   = "No songs found",
                    message = uiState.scanError ?: "Make sure storage permission is granted, then scan again."
                ) {
                    MelodiqButton(
                        text    = "Scan library",
                        onClick = libraryVm::syncLibrary,
                        icon    = R.drawable.ic_refresh
                    )
                }
            }
        } else {
            LazyColumn(
                modifier       = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 16.dp)
            ) {
                item {
                    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                        Text(
                            text     = "${uiState.allSongs.size} songs",
                            style    = MaterialTheme.typography.labelMedium,
                            color    = TextMuted,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp)
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            MelodiqButton(
                                text     = "Play all",
                                onClick  = {
                                    playerVm.playSongs(uiState.allSongs, 0)
                                    onNavigateToNowPlaying()
                                },
                                icon     = R.drawable.ic_play,
                                modifier = Modifier.weight(1f)
                            )
                            MelodiqButton(
                                text     = "Shuffle",
                                onClick  = {
                                    playerVm.shuffleAndPlay(uiState.allSongs)
                                    onNavigateToNowPlaying()
                                },
                                icon     = R.drawable.ic_shuffle,
                                style    = ButtonStyle.Outlined,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
                itemsIndexed(uiState.allSongs, key = { _, s -> s.id }) { idx, song ->
                    SongItem(
                        song            = song,
                        isCurrent       = currentId == song.id,
                        isPlaying       = playerState.isPlaying,
                        onClick         = {
                            playerVm.playSongs(uiState.allSongs, idx)
                            onNavigateToNowPlaying()
                        },
                        onFavoriteClick = { playerVm.toggleFavorite(song) }
                    )
                    if (idx < uiState.allSongs.lastIndex) {
                        HorizontalDivider(
                            modifier  = Modifier.padding(start = 80.dp, end = 16.dp),
                            thickness = 0.5.dp,
                            color     = Divider
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LibraryHeader(isLoading: Boolean, onRefresh: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 20.dp, end = 8.dp, top = 8.dp, bottom = 4.dp),
        verticalAlignment     = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text  = "Library",
            style = MaterialTheme.typography.titleLarge,
            color = TextPrimary
        )
        if (isLoading) {
            Box(Modifier.size(44.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(
                    modifier    = Modifier.size(22.dp),
                    strokeWidth = 2.dp,
                    color       = PrimaryPurple
                )
            }
        } else {
            IconActionButton(
                icon               = R.drawable.ic_refresh,
                contentDescription = "Scan library",
                onClick            = onRefresh,
                tint               = TextSecondary
            )
        }
    }
}
