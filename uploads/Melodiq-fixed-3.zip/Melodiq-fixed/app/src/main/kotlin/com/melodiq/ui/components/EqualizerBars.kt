package com.melodiq.ui.components

import androidx.compose.animation.core.InfiniteTransition
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color

/** Three bouncing bars drawn on a Canvas (vector, no text glyph). Frozen when [isAnimating] is false. */
@Composable
fun EqualizerBars(
    isAnimating: Boolean,
    modifier: Modifier = Modifier,
    color: Color = Color.White
) {
    val transition = rememberInfiniteTransition(label = "equalizer")
    val bar1 = transition.bar(durationMs = 520, from = 0.30f)
    val bar2 = transition.bar(durationMs = 380, from = 0.45f)
    val bar3 = transition.bar(durationMs = 610, from = 0.25f)

    // State is read inside the draw lambda, so the animation redraws without recomposing.
    Canvas(modifier) {
        val barWidth  = size.width / 5f
        val fractions = if (isAnimating) {
            floatArrayOf(bar1.value, bar2.value, bar3.value)
        } else {
            floatArrayOf(0.45f, 0.80f, 0.60f)
        }
        fractions.forEachIndexed { index, fraction ->
            val barHeight = size.height * fraction
            drawRoundRect(
                color        = color,
                topLeft      = Offset(index * 2f * barWidth, size.height - barHeight),
                size         = Size(barWidth, barHeight),
                cornerRadius = CornerRadius(barWidth / 2f)
            )
        }
    }
}

@Composable
private fun InfiniteTransition.bar(durationMs: Int, from: Float): State<Float> =
    animateFloat(
        initialValue  = from,
        targetValue   = 1f,
        animationSpec = infiniteRepeatable(
            animation  = tween(durationMs, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "bar"
    )
