package com.melodiq.data.model

/** Where the lyrics shown for a song came from. */
enum class LyricsSource {
    /** Found automatically on LRCLIB. */
    AUTO,
    /** The user picked another version from the list of search results. */
    PICKED,
    /** The user typed or pasted the lyrics. */
    EDITED,
    /** The user imported an .lrc / .txt file. */
    FILE
}

/** Extra facts about the lyrics that are currently shown. */
data class LyricsMeta(
    val source: LyricsSource = LyricsSource.AUTO,
    /** Sync offset applied to every timestamp (milliseconds, may be negative). */
    val offsetMs: Long = 0L,
    /** True when the lyrics look cut short (see LyricsQuality) and nothing could complete them. */
    val possiblyIncomplete: Boolean = false,
    /** Number of trailing lines that came from the plain-text version and have no timing. */
    val untimedTail: Int = 0,
    /** The complete plain-text version, when one exists. Used by the "Full text" view. */
    val plainText: String? = null
)

/** One search result in the "Choose another version" list. */
data class LyricsCandidate(
    val id: Int,
    val title: String,
    val artist: String,
    val album: String,
    val durationSec: Int?,
    /** Difference to the length of the song on this phone, in seconds (null when unknown). */
    val durationDiffSec: Int?,
    val syncedLines: Int,
    val plainLines: Int,
    /** First two lines, so the user can recognise the version. */
    val preview: String,
    val isBestMatch: Boolean,
    val syncedLyrics: String?,
    val plainLyrics: String?
)

sealed class VersionSearch {
    data class Results(val items: List<LyricsCandidate>) : VersionSearch()
    object Empty : VersionSearch()
    object Offline : VersionSearch()
}
