package com.melodiq.overlay

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.ComposeView
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.media3.common.MediaItem
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.melodiq.crash.AppLog
import com.melodiq.crash.CrashReporter
import com.melodiq.data.model.FloatingLyricsSettings
import com.melodiq.data.model.LyricsResult
import com.melodiq.data.repository.MusicRepository
import com.melodiq.data.repository.SettingsRepository
import com.melodiq.lyrics.LyricsManager
import com.melodiq.player.PlayerManager
import com.melodiq.ui.components.FloatingLyricsCard
import com.melodiq.ui.components.buildLyricWindow
import com.melodiq.ui.theme.MelodiqTheme
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.abs

/**
 * The lyrics window that floats above other apps.
 *
 * It is owned by [com.melodiq.player.MusicService]: that service is a foreground service while music
 * plays, so the window keeps working after the app is closed and Android does not kill it.
 *
 * The window is shown only when every condition holds: the user turned it on, "display over other
 * apps" is allowed, a song is loaded (and playing, unless the user chose otherwise), Melodiq itself
 * is not on screen (optional) and the song has synced lyrics (optional). Everything about how it
 * looks comes from [SettingsRepository], so changes in Settings apply immediately.
 */
@Singleton
class FloatingLyricsOverlay @Inject constructor(
    @ApplicationContext private val context: Context,
    private val settingsRepository: SettingsRepository,
    private val playerManager: PlayerManager,
    private val lyricsManager: LyricsManager,
    private val musicRepository: MusicRepository
) {
    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager

    private var scope: CoroutineScope? = null
    private var root: OverlayDragLayout? = null
    private var owner: OverlayLifecycleOwner? = null
    private var params: WindowManager.LayoutParams? = null

    // ── Lifecycle (called by MusicService) ───────────────────────────────────

    fun start() {
        if (scope != null) return
        // Floating lyrics are a bonus: whatever goes wrong in here is logged, never allowed to crash the app.
        val safely = CoroutineExceptionHandler { _, error ->
            AppLog.w(TAG, "floating lyrics failed", error)
            CrashReporter.recordNonFatal("Floating lyrics failed", error)
        }
        val newScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate + safely)
        scope = newScope
        // The service can be started by a media button before any screen opened the controller.
        playerManager.connect()

        newScope.launch { followCurrentSong() }
        newScope.launch { followVisibility() }
        newScope.launch { followSettings() }
    }

    fun stop() {
        scope?.cancel()
        scope = null
        hide()
    }

    /** The screen size changed (rotation, split screen): place the window again. */
    fun refreshLayout() {
        if (root != null) applyLayout(settingsRepository.settings.value.floating)
    }

    // ── What to show, and when ───────────────────────────────────────────────

    /** Loads lyrics for the playing song while the floating window is switched on. */
    private suspend fun followCurrentSong() {
        combine(
            settingsRepository.settings.map { it.floating.enabled }.distinctUntilChanged(),
            playerManager.currentMediaItem
        ) { enabled, item ->
            if (enabled) item?.mediaId?.toLongOrNull() else null
        }.distinctUntilChanged().collect { songId ->
            if (songId != null) {
                val song = musicRepository.getSongById(songId)
                if (song != null) lyricsManager.ensureLoaded(song)
            }
        }
    }

    private suspend fun followVisibility() {
        combine(
            settingsRepository.settings.map { it.floating }.distinctUntilChanged(),
            playerManager.isPlaying,
            AppForeground.inForeground,
            lyricsManager.state,
            playerManager.currentMediaItem
        ) { floating, playing, appOnScreen, lyrics, item ->
            val allowed = floating.enabled &&
                item != null &&
                (playing || !floating.showOnlyWhilePlaying) &&
                !(appOnScreen && floating.hideInApp)
            when {
                !allowed                         -> false
                !floating.hideWhenNoLyrics       -> true
                lyrics is LyricsResult.Synced    -> true
                // lyrics are being (re)loaded: keep the window as it is instead of flickering
                lyrics is LyricsResult.Loading   -> null
                else                             -> false
            }
        }.filterNotNull().distinctUntilChanged().collect { visible ->
            if (visible) show() else hide()
        }
    }

    private suspend fun followSettings() {
        settingsRepository.settings
            .map { it.floating }
            .distinctUntilChanged()
            .collect { applyLayout(it) }
    }

    // ── The window ───────────────────────────────────────────────────────────

    private fun show() {
        if (root != null) return
        if (!OverlayPermission.isGranted(context)) {
            AppLog.i(TAG, "not shown: 'Display over other apps' is not allowed")
            return
        }
        var lifecycleOwner: OverlayLifecycleOwner? = null
        try {
            val newOwner = OverlayLifecycleOwner()
            lifecycleOwner = newOwner
            newOwner.start()

            val container = OverlayDragLayout(
                context   = context,
                onDrag    = { dx, dy -> moveBy(dx, dy) },
                onDragEnd = { saveDraggedPosition() }
            )
            // A window added from a service has no Activity to take these from.
            container.setViewTreeLifecycleOwner(newOwner)
            container.setViewTreeSavedStateRegistryOwner(newOwner)

            val content = ComposeView(context)
            content.setContent { OverlayContent() }
            container.addView(
                content,
                FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            )

            val settings = settingsRepository.settings.value.floating
            val layout = buildLayoutParams(settings)
            container.draggable = !settings.locked
            windowManager.addView(container, layout)

            root = container
            owner = newOwner
            params = layout
        } catch (e: Exception) {
            AppLog.w(TAG, "could not show the floating lyrics", e)
            CrashReporter.recordNonFatal("Floating lyrics could not be shown", e)
            lifecycleOwner?.stop()
        }
    }

    private fun hide() {
        val view = root
        if (view != null) {
            try {
                windowManager.removeView(view)
            } catch (e: Exception) {
                AppLog.w(TAG, "could not remove the floating lyrics", e)
            }
        }
        owner?.stop()
        root = null
        owner = null
        params = null
    }

    private fun applyLayout(floating: FloatingLyricsSettings) {
        val view = root ?: return
        val layout = buildLayoutParams(floating)
        params = layout
        view.draggable = !floating.locked
        try {
            windowManager.updateViewLayout(view, layout)
        } catch (e: Exception) {
            AppLog.w(TAG, "could not update the floating lyrics", e)
        }
    }

    @Suppress("DEPRECATION")
    private fun buildLayoutParams(floating: FloatingLyricsSettings): WindowManager.LayoutParams {
        val metrics = context.resources.displayMetrics
        val width = (metrics.widthPixels * floating.widthFraction).toInt().coerceAtLeast(1)

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            WindowManager.LayoutParams.TYPE_PHONE
        }
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
        // a locked window lets every touch through to the app underneath
        if (floating.locked) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE

        val layout = WindowManager.LayoutParams(
            width,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            flags,
            PixelFormat.TRANSLUCENT
        )
        layout.gravity = Gravity.TOP or Gravity.START
        layout.x = (floating.posX * (metrics.widthPixels - width).coerceAtLeast(0)).toInt()
        val maxY = (metrics.heightPixels - (root?.height ?: 0)).coerceAtLeast(0)
        layout.y = (floating.posY * metrics.heightPixels).toInt().coerceIn(0, maxY)
        return layout
    }

    // ── Dragging ─────────────────────────────────────────────────────────────

    private fun moveBy(dx: Int, dy: Int) {
        val view = root ?: return
        val layout = params ?: return
        val metrics = context.resources.displayMetrics
        layout.x = (layout.x + dx).coerceIn(0, (metrics.widthPixels - layout.width).coerceAtLeast(0))
        layout.y = (layout.y + dy).coerceIn(0, (metrics.heightPixels - view.height).coerceAtLeast(0))
        try {
            windowManager.updateViewLayout(view, layout)
        } catch (e: Exception) {
            AppLog.w(TAG, "could not move the floating lyrics", e)
        }
    }

    /** Remembers where the user dropped the window (as fractions, so it survives rotation). */
    private fun saveDraggedPosition() {
        val layout = params ?: return
        val metrics = context.resources.displayMetrics
        val freeX = (metrics.widthPixels - layout.width).coerceAtLeast(1)
        val posX = (layout.x.toFloat() / freeX).coerceIn(0f, 1f)
        val posY = (layout.y.toFloat() / metrics.heightPixels.coerceAtLeast(1)).coerceIn(0f, 1f)
        settingsRepository.update { it.copy(floating = it.floating.copy(posX = posX, posY = posY)) }
    }

    // ── Content ──────────────────────────────────────────────────────────────

    @Composable
    private fun OverlayContent() {
        val settings by settingsRepository.settings.collectAsState()
        val lyrics by lyricsManager.state.collectAsState()
        val active by lyricsManager.activeLine.collectAsState()
        val playing by playerManager.isPlaying.collectAsState()
        val item by playerManager.currentMediaItem.collectAsState()

        val synced = lyrics as? LyricsResult.Synced
        if (synced != null) {
            val floating = settings.floating
            val window = remember(synced, active, floating.lines) {
                buildLyricWindow(synced.lines, active, floating.lines)
            }
            MelodiqTheme {
                FloatingLyricsCard(
                    window      = window,
                    settings    = floating,
                    modifier    = Modifier.fillMaxWidth(),
                    title       = if (floating.showTitle) titleOf(item) else null,
                    isPlaying   = playing,
                    onPrevious  = { playerManager.seekToPrevious() },
                    onPlayPause = { playerManager.togglePlayPause() },
                    onNext      = { playerManager.seekToNext() }
                )
            }
        }
    }

    private fun titleOf(item: MediaItem?): String? {
        val metadata = item?.mediaMetadata ?: return null
        val text = listOfNotNull(metadata.title?.toString(), metadata.artist?.toString())
            .filter { it.isNotBlank() }
            .joinToString(" \u2014 ")
        return text.ifBlank { null }
    }

    private companion object {
        const val TAG = "FloatingLyrics"
    }
}

/**
 * Root view of the floating window. It moves the window when the user drags it. It only takes over
 * a touch after the finger has moved past the touch slop, so the buttons inside still work.
 * Raw screen coordinates are used because the view itself moves under the finger.
 */
internal class OverlayDragLayout(
    context: Context,
    private val onDrag: (dx: Int, dy: Int) -> Unit,
    private val onDragEnd: () -> Unit
) : FrameLayout(context) {

    /** False while the window is locked (it is then not touchable at all). */
    var draggable: Boolean = true

    private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var dragging = false

    override fun onInterceptTouchEvent(event: MotionEvent): Boolean {
        if (!draggable) return false
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.rawX
                downY = event.rawY
                lastX = downX
                lastY = downY
                dragging = false
            }
            MotionEvent.ACTION_MOVE -> startDraggingIfMoved(event)
        }
        return dragging
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (!draggable) return false
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.rawX
                downY = event.rawY
                lastX = downX
                lastY = downY
                dragging = false
            }
            MotionEvent.ACTION_MOVE -> {
                startDraggingIfMoved(event)
                if (dragging) {
                    val dx = (event.rawX - lastX).toInt()
                    val dy = (event.rawY - lastY).toInt()
                    if (dx != 0 || dy != 0) {
                        // keep the sub-pixel remainder for the next event
                        lastX += dx
                        lastY += dy
                        onDrag(dx, dy)
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragging) onDragEnd()
                dragging = false
            }
        }
        return true
    }

    private fun startDraggingIfMoved(event: MotionEvent) {
        if (dragging) return
        if (abs(event.rawX - downX) > touchSlop || abs(event.rawY - downY) > touchSlop) {
            dragging = true
            lastX = event.rawX
            lastY = event.rawY
        }
    }
}
