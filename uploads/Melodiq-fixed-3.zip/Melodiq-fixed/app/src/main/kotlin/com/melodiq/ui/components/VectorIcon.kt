package com.melodiq.ui.components

import androidx.annotation.DrawableRes
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * The single way the app draws an icon: a vector drawable from res/drawable (ic_*.xml),
 * tinted with the surrounding content colour. No emoji, no text glyphs.
 */
@Composable
fun VectorIcon(
    @DrawableRes id: Int,
    modifier: Modifier = Modifier,
    tint: Color = LocalContentColor.current,
    size: Dp = 24.dp,
    contentDescription: String? = null
) {
    Icon(
        painter            = painterResource(id),
        contentDescription = contentDescription,
        tint               = tint,
        modifier           = modifier.size(size)
    )
}
