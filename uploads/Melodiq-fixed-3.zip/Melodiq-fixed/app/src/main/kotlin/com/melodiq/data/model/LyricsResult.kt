package com.melodiq.data.model

sealed class LyricsResult {
    object Loading : LyricsResult()
    /** The service answered, but has no lyrics for this song. */
    object NotFound : LyricsResult()
    /** We could not reach the service (offline, timeout, server error). Worth retrying. */
    object Offline : LyricsResult()
    /** Something unexpected went wrong while loading or reading lyrics. Lyrics are optional, so this never stops playback. */
    object Failed : LyricsResult()
    data class Synced(val lines: List<LyricLine>, val meta: LyricsMeta = LyricsMeta()) : LyricsResult()
    data class Plain(val text: String, val meta: LyricsMeta = LyricsMeta()) : LyricsResult()
}
