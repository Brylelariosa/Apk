package com.melodiq.player

import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import com.melodiq.crash.AppLog
import com.melodiq.crash.CrashReporter

/**
 * Writes what the player is doing into the crash-report breadcrumbs, and saves an error report
 * whenever playback fails (a file that cannot be decoded, a missing file, an audio output problem).
 *
 * It is attached to the ExoPlayer inside [MusicService], where the complete exception chain is
 * still available; the controller side only receives a reduced copy of the error.
 */
class PlaybackLogger : Player.Listener {

    override fun onPlaybackStateChanged(playbackState: Int) {
        AppLog.i(TAG, "state: ${stateName(playbackState)}")
    }

    override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
        AppLog.i(TAG, "playWhenReady=$playWhenReady (reason $reason)")
    }

    override fun onIsPlayingChanged(isPlaying: Boolean) {
        AppLog.i(TAG, "isPlaying=$isPlaying")
    }

    override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
        AppLog.i(TAG, "item: id=${mediaItem?.mediaId} (reason $reason)")
    }

    override fun onPlayerError(error: PlaybackException) {
        CrashReporter.recordNonFatal("Playback error ${error.errorCodeName}", error)
    }

    private fun stateName(state: Int): String = when (state) {
        Player.STATE_IDLE -> "IDLE"
        Player.STATE_BUFFERING -> "BUFFERING"
        Player.STATE_READY -> "READY"
        Player.STATE_ENDED -> "ENDED"
        else -> "UNKNOWN($state)"
    }

    private companion object {
        const val TAG = "Player"
    }
}
