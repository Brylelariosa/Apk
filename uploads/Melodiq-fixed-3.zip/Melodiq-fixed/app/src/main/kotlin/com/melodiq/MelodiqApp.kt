package com.melodiq

import android.app.Application
import android.content.Context
import com.melodiq.crash.CrashReporter
import com.melodiq.overlay.AppForeground
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class MelodiqApp : Application() {

    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(base)
        // Earliest hook the app has: a crash while Hilt or Room are starting up is logged too.
        CrashReporter.install(this)
    }

    override fun onCreate() {
        super.onCreate()
        // Lets the floating lyrics hide while one of the app's own screens is visible.
        AppForeground.install(this)
    }
}
