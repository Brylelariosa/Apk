package com.melodiq.crash

/** The three situations that produce a text report. [filePrefix] starts the file name in Download. */
internal enum class ReportKind(val title: String, val filePrefix: String) {
    /** An uncaught exception killed the app. */
    FATAL("CRASH", "Melodiq_crash"),

    /** Something failed but the app kept running (for example the player could not play a file). */
    NON_FATAL("ERROR (the app kept running)", "Melodiq_error"),

    /** The previous run ended without a Java exception: native crash, ANR, killed by the system. */
    PREVIOUS_RUN("PREVIOUS RUN ENDED UNEXPECTEDLY", "Melodiq_exit")
}

/**
 * What the "Melodiq closed unexpectedly" dialog shows.
 *
 * @property fileName         name of the newest report
 * @property savedToDownloads false while the copy into Download is still waiting for storage access
 * @property text             the full report, used by the dialog's Share button
 * @property moreReports      how many older reports are waiting besides this one
 */
data class CrashNotice(
    val fileName: String,
    val savedToDownloads: Boolean,
    val text: String,
    val moreReports: Int
)
