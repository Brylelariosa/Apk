package com.melodiq.crash

import java.util.concurrent.atomic.AtomicBoolean

/**
 * Runs when any thread dies from an uncaught exception.
 *
 * It first lets [onCrash] write the report, then hands the exception to the handler that was
 * installed before it, so Android still shows its usual "app stopped" behaviour and ends the
 * process. Nothing in here is allowed to throw: the logger must never make a crash worse.
 */
internal class FatalCrashHandler(
    private val previous: Thread.UncaughtExceptionHandler?,
    private val onCrash: (Thread, Throwable) -> Unit
) : Thread.UncaughtExceptionHandler {

    private val handling = AtomicBoolean(false)

    override fun uncaughtException(thread: Thread, error: Throwable) {
        // A second crash while the first report is being written is passed on without a second report.
        if (handling.compareAndSet(false, true)) {
            try {
                onCrash(thread, error)
            } catch (failure: Throwable) {
                // Out of options; fall through to the system handler.
            }
        }

        if (previous != null) {
            previous.uncaughtException(thread, error)
        } else {
            android.os.Process.killProcess(android.os.Process.myPid())
            System.exit(10)
        }
    }
}
