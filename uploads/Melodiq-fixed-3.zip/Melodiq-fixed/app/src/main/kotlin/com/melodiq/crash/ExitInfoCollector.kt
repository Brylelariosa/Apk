package com.melodiq.crash

import android.app.ActivityManager
import android.app.ApplicationExitInfo
import android.content.Context
import android.os.Build
import androidx.annotation.RequiresApi

/** One earlier run that ended without a Java exception the crash handler could have caught. */
internal class PreviousRunExit(val timeMs: Long, val details: String)

/**
 * Android 11+ remembers why each earlier process of this app ended. That is the only way to learn
 * about the crashes a Java handler never sees: native crashes inside a codec or audio library,
 * ANRs, and the system killing the app while it was playing.
 *
 * Every exit is handed out once. The very first call only sets a starting point, so an update or
 * an old exit from before this feature existed does not show up as a fresh problem.
 */
@RequiresApi(Build.VERSION_CODES.R)
internal class ExitInfoCollector(private val context: Context) {

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun collectNew(): List<PreviousRunExit> {
        val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val exits = manager.getHistoricalProcessExitReasons(context.packageName, 0, MAX_ENTRIES)

        // First call ever: remember "now" as the starting point, even when the history is empty,
        // so the very first crash after installing is still reported on the next start.
        val firstRun = !prefs.contains(KEY_LAST_HANDLED)
        val lastHandled = prefs.getLong(KEY_LAST_HANDLED, System.currentTimeMillis())
        val newest = exits.maxOfOrNull { it.timestamp } ?: lastHandled
        prefs.edit().putLong(KEY_LAST_HANDLED, maxOf(newest, lastHandled)).apply()
        if (firstRun) return emptyList()

        return exits
            .filter { it.timestamp > lastHandled && isWorthReporting(it) }
            .map { PreviousRunExit(it.timestamp, describe(it)) }
    }

    /** Normal endings (swipe away, force stop, the app's own exit) are not problems. */
    private fun isWorthReporting(info: ApplicationExitInfo): Boolean = when (info.reason) {
        ApplicationExitInfo.REASON_CRASH_NATIVE,
        ApplicationExitInfo.REASON_ANR,
        ApplicationExitInfo.REASON_INITIALIZATION_FAILURE,
        ApplicationExitInfo.REASON_EXCESSIVE_RESOURCE_USAGE -> true

        // Being killed is only a problem when the app was on screen or playing in the background.
        ApplicationExitInfo.REASON_LOW_MEMORY,
        ApplicationExitInfo.REASON_SIGNALED ->
            info.importance <= ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND_SERVICE

        else -> false
    }

    private fun describe(info: ApplicationExitInfo): String = buildString {
        appendLine("Reason:      ${reasonName(info.reason)}")
        appendLine("Signal/exit: ${info.status}")
        appendLine("Description: ${info.description}")
        appendLine("Process:     ${info.processName} (pid ${info.pid})")
        appendLine("State:       ${importanceName(info.importance)}")
        appendLine("Memory:      pss ${info.pss / KB_PER_MB} MB, rss ${info.rss / KB_PER_MB} MB")

        val trace = readTrace(info)
        if (trace.isNotBlank()) {
            appendLine()
            appendLine("----- SYSTEM TRACE -----")
            appendLine(trace)
        }
    }

    private fun reasonName(reason: Int): String {
        val name = when (reason) {
            ApplicationExitInfo.REASON_ANR -> "ANR (the app stopped responding)"
            ApplicationExitInfo.REASON_CRASH -> "CRASH (Java exception)"
            ApplicationExitInfo.REASON_CRASH_NATIVE -> "CRASH_NATIVE (native code crashed)"
            ApplicationExitInfo.REASON_EXCESSIVE_RESOURCE_USAGE -> "EXCESSIVE_RESOURCE_USAGE"
            ApplicationExitInfo.REASON_EXIT_SELF -> "EXIT_SELF"
            ApplicationExitInfo.REASON_INITIALIZATION_FAILURE -> "INITIALIZATION_FAILURE"
            ApplicationExitInfo.REASON_LOW_MEMORY -> "LOW_MEMORY (killed by the system to free RAM)"
            ApplicationExitInfo.REASON_OTHER -> "OTHER"
            ApplicationExitInfo.REASON_SIGNALED -> "SIGNALED (killed by a signal)"
            ApplicationExitInfo.REASON_USER_REQUESTED -> "USER_REQUESTED"
            else -> "UNKNOWN"
        }
        return "$name [code $reason]"
    }

    private fun importanceName(importance: Int): String {
        val name = when {
            importance <= ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND -> "foreground (on screen)"
            importance <= ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND_SERVICE -> "foreground service (playing in the background)"
            importance <= ActivityManager.RunningAppProcessInfo.IMPORTANCE_VISIBLE -> "visible"
            else -> "background / cached"
        }
        return "$name [importance $importance]"
    }

    /** ANR traces are text; native-crash dumps on Android 12+ are binary, so only readable strings are kept. */
    private fun readTrace(info: ApplicationExitInfo): String = try {
        info.traceInputStream?.use { stream ->
            val buffer = ByteArray(MAX_TRACE_BYTES)
            var total = 0
            while (total < buffer.size) {
                val read = stream.read(buffer, total, buffer.size - total)
                if (read < 0) break
                total += read
            }
            readableLines(String(buffer, 0, total, Charsets.ISO_8859_1))
        }.orEmpty()
    } catch (failure: Exception) {
        ""
    }

    private fun readableLines(raw: String): String =
        READABLE_RUN.findAll(raw)
            .map { it.value }
            .joinToString("\n")
            .take(MAX_TRACE_CHARS)

    private companion object {
        const val PREFS_NAME = "melodiq_crash_reporter"
        const val KEY_LAST_HANDLED = "last_handled_exit_ms"
        const val MAX_ENTRIES = 8
        const val MAX_TRACE_BYTES = 256 * 1024
        const val MAX_TRACE_CHARS = 60_000
        const val KB_PER_MB = 1024L

        /** A run of at least five printable characters; works for text traces and binary dumps alike. */
        val READABLE_RUN = Regex("[\\x20-\\x7E\\t]{5,}")
    }
}
