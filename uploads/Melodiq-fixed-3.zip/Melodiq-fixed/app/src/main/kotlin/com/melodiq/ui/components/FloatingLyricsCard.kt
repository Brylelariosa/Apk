package com.melodiq.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.melodiq.R
import com.melodiq.data.model.FloatingLyricsSettings
import com.melodiq.data.model.LineAnimation
import com.melodiq.data.model.LyricLine

/** The few lines shown in the floating window: [lines] with the current one at [active]. */
data class LyricWindow(
    /** Changes whenever the current line changes — what the line animation reacts to. */
    val key: Int,
    val lines: List<String>,
    val active: Int
)

/**
 * Cuts [count] lines (1..5) out of the lyrics around [activeIndex]. Missing neighbours at the start
 * or end of the song are blank lines, so the window keeps the same height all the time.
 * Before the first line the current line shows a note symbol.
 */
fun buildLyricWindow(lines: List<LyricLine>, activeIndex: Int, count: Int): LyricWindow {
    val timedCount = lines.count { it.isTimed }
    val total  = count.coerceIn(1, 5)
    val before = (total - 1) / 2
    val after  = total - 1 - before

    val texts = ArrayList<String>(total)
    var activePosition = 0
    for (i in (activeIndex - before)..(activeIndex + after)) {
        if (i == activeIndex) activePosition = texts.size
        val text = when {
            i in 0 until timedCount -> lines[i].text
            i == activeIndex        -> "♪"
            else                    -> " "
        }
        texts.add(text)
    }
    return LyricWindow(key = activeIndex, lines = texts, active = activePosition)
}

/**
 * The floating lyrics window: a rounded card with the lines, an optional title and optional
 * playback buttons. The same composable draws the real window (inside the music service) and the
 * live preview in Settings, so the preview is exactly what you get.
 */
@Composable
fun FloatingLyricsCard(
    window: LyricWindow,
    settings: FloatingLyricsSettings,
    modifier: Modifier = Modifier,
    title: String? = null,
    isPlaying: Boolean = true,
    onPrevious: () -> Unit = {},
    onPlayPause: () -> Unit = {},
    onNext: () -> Unit = {}
) {
    val shape = RoundedCornerShape(settings.cornerRadiusDp.dp)
    val textColor = Color(settings.textColor)
    val duration = settings.animationMs

    Column(
        modifier = modifier
            .alpha(settings.windowAlpha)
            .clip(shape)
            .background(Color(settings.backgroundColor).copy(alpha = settings.backgroundAlpha))
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalAlignment = settings.alignment.toHorizontal()
    ) {
        if (title != null) {
            Text(
                text     = title,
                color    = textColor.copy(alpha = 0.6f),
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 4.dp)
            )
        }

        AnimatedContent(
            targetState = window,
            transitionSpec = {
                when (settings.animation) {
                    LineAnimation.NONE ->
                        EnterTransition.None togetherWith ExitTransition.None
                    LineAnimation.FADE ->
                        fadeIn(tween(duration)) togetherWith fadeOut(tween(duration))
                    LineAnimation.SLIDE ->
                        (slideInVertically(tween(duration)) { it / 2 } + fadeIn(tween(duration))) togetherWith
                            (slideOutVertically(tween(duration)) { -it / 2 } + fadeOut(tween(duration)))
                    LineAnimation.POP ->
                        (scaleIn(tween(duration), initialScale = 0.85f) + fadeIn(tween(duration))) togetherWith
                            (scaleOut(tween(duration), targetScale = 1.1f) + fadeOut(tween(duration)))
                }
            },
            label = "floating_lyrics"
        ) { shown ->
            LyricLines(shown, settings)
        }

        if (settings.showControls) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconActionButton(
                    icon = R.drawable.ic_skip_previous,
                    contentDescription = "Previous song",
                    onClick = onPrevious,
                    tint = textColor,
                    buttonSize = 40.dp,
                    iconSize = 22.dp
                )
                IconActionButton(
                    icon = if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play,
                    contentDescription = if (isPlaying) "Pause" else "Play",
                    onClick = onPlayPause,
                    tint = textColor,
                    buttonSize = 44.dp,
                    iconSize = 26.dp
                )
                IconActionButton(
                    icon = R.drawable.ic_skip_next,
                    contentDescription = "Next song",
                    onClick = onNext,
                    tint = textColor,
                    buttonSize = 40.dp,
                    iconSize = 22.dp
                )
            }
        }
    }
}

@Composable
private fun LyricLines(window: LyricWindow, settings: FloatingLyricsSettings) {
    val family    = settings.font.toFontFamily()
    val weight    = settings.weight.toFontWeight()
    val textAlign = settings.alignment.toTextAlign()
    val color     = Color(settings.textColor)
    val shadow    = if (settings.textShadow) {
        Shadow(color = Color.Black.copy(alpha = 0.85f), offset = Offset(0f, 2f), blurRadius = 6f)
    } else {
        null
    }

    Column(horizontalAlignment = settings.alignment.toHorizontal()) {
        window.lines.forEachIndexed { index, text ->
            val isActive = index == window.active
            Text(
                text       = text,
                color      = if (isActive) color else color.copy(alpha = color.alpha * settings.inactiveAlpha),
                fontSize   = (if (isActive) settings.textSizeSp else settings.textSizeSp * 0.82f).sp,
                fontFamily = family,
                fontWeight = if (isActive) weight else FontWeight.Normal,
                textAlign  = textAlign,
                maxLines   = 3,
                overflow   = TextOverflow.Ellipsis,
                style      = TextStyle(shadow = shadow),
                modifier   = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 2.dp)
            )
        }
    }
}
