package com.melodiq.crash

import android.content.Context
import java.io.File

/**
 * Keeps reports in the app's private storage while they travel to the Download folder.
 *
 *   pending/  written at the moment of the crash; not yet confirmed in Download
 *   unseen/   confirmed in Download; kept only until the user has been told about it
 *
 * Writing here needs no permission and no IPC, so it works even when the app is dying.
 * Because a pending file survives, a failed copy into Download is retried on the next start.
 */
internal class CrashLogStore(context: Context) {

    private val root = File(context.filesDir, "crash_reports")
    private val pendingDir = File(root, "pending")
    private val unseenDir = File(root, "unseen")

    fun savePending(fileName: String, text: String): File {
        pendingDir.mkdirs()
        val file = File(pendingDir, fileName)
        file.writeText(text, Charsets.UTF_8)
        return file
    }

    /** The report is now safe in Download: move it to the "tell the user" list. */
    fun markExported(pending: File) {
        unseenDir.mkdirs()
        val target = File(unseenDir, pending.name)
        if (!pending.renameTo(target)) {
            pending.copyTo(target, overwrite = true)
            pending.delete()
        }
    }

    fun pending(): List<File> = reportsIn(pendingDir)

    fun unseen(): List<File> = reportsIn(unseenDir)

    fun clearUnseen() {
        unseen().forEach { it.delete() }
    }

    private fun reportsIn(dir: File): List<File> =
        dir.listFiles()
            ?.filter { it.isFile && it.name.endsWith(".txt") }
            ?.sortedBy { it.lastModified() }
            .orEmpty()
}
