package com.melodiq.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.lerp
import com.melodiq.data.model.BackgroundStyle
import com.melodiq.ui.theme.DeepPurple
import com.melodiq.ui.theme.MidnightBlue
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

// Slow drifting does not need 60 fps: 30 halves the GPU work, which matters on budget phones.
private const val FRAME_STEP_SECONDS = 1f / 30f

/**
 * The calm background behind the whole app.
 *
 * It replaces the old sweeping gradient (whose moving, rotating bands were distracting). The styles:
 *  - AURORA: three soft glows that drift very slowly and independently — no lines, no rotation;
 *  - PULSE:  one glow that breathes behind the cover;
 *  - STATIC: a still gradient;  OFF: one flat colour.
 *
 * The animation clock is a plain float that only the draw phase reads, so nothing is recomposed
 * while it runs, and it stops completely when [animated] is false (e.g. music is paused).
 */
@Composable
fun AmbientBackground(
    modifier: Modifier = Modifier,
    color1: Color = DeepPurple,
    color2: Color = Color(0xFF16213E),
    color3: Color = MidnightBlue,
    style: BackgroundStyle = BackgroundStyle.AURORA,
    intensity: Float = 0.55f,
    speed: Float = 1f,
    animated: Boolean = true,
    content: @Composable BoxScope.() -> Unit
) {
    val c1 = animateColorAsState(color1, tween(900, easing = FastOutSlowInEasing), label = "ambient_1")
    val c2 = animateColorAsState(color2, tween(900, easing = FastOutSlowInEasing), label = "ambient_2")
    val c3 = animateColorAsState(color3, tween(900, easing = FastOutSlowInEasing), label = "ambient_3")

    val clock = remember { mutableFloatStateOf(0f) }
    val moving = animated && (style == BackgroundStyle.AURORA || style == BackgroundStyle.PULSE)
    LaunchedEffect(moving, speed) {
        if (!moving) return@LaunchedEffect
        var last = withFrameNanos { it }
        while (true) {
            val now = withFrameNanos { it }
            val delta = (now - last) / 1_000_000_000f
            if (delta >= FRAME_STEP_SECONDS) {
                clock.floatValue += delta * speed
                last = now
            }
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .drawBehind {
                val top = c1.value
                val middle = c2.value
                val bottom = c3.value
                when (style) {
                    BackgroundStyle.OFF -> drawRect(bottom)
                    BackgroundStyle.STATIC -> drawRect(Brush.verticalGradient(listOf(top, middle, bottom)))
                    BackgroundStyle.AURORA -> {
                        drawRect(Brush.verticalGradient(listOf(top, middle, bottom)))
                        drawAurora(clock.floatValue, top, middle, intensity)
                    }
                    BackgroundStyle.PULSE -> {
                        drawRect(Brush.verticalGradient(listOf(top, middle, bottom)))
                        drawPulse(clock.floatValue, middle, intensity)
                    }
                }
            },
        content = content
    )
}

private fun DrawScope.glow(color: Color, cx: Float, cy: Float, radius: Float, alpha: Float) {
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(color.copy(alpha = alpha), Color.Transparent),
            center = Offset(cx, cy),
            radius = radius
        ),
        radius = radius,
        center = Offset(cx, cy)
    )
}

/** Three big, soft glows on slow, unrelated paths (periods between 25 and 50 seconds). */
private fun DrawScope.drawAurora(t: Float, top: Color, middle: Color, intensity: Float) {
    val w = size.width
    val h = size.height
    val reach = max(w, h)
    val alpha = 0.55f * intensity

    val a = lerp(middle, Color.White, 0.30f)
    val b = lerp(top, Color.White, 0.35f)
    val c = lerp(top, middle, 0.5f).let { lerp(it, Color.White, 0.25f) }

    glow(a, w * (0.30f + 0.22f * sin(t * 0.21f)),        h * (0.25f + 0.15f * cos(t * 0.17f)),        reach * 0.75f, alpha)
    glow(b, w * (0.75f + 0.20f * cos(t * 0.16f + 1.7f)), h * (0.55f + 0.20f * sin(t * 0.19f + 0.6f)), reach * 0.80f, alpha)
    glow(c, w * (0.45f + 0.25f * sin(t * 0.13f + 3.1f)), h * (0.85f + 0.10f * cos(t * 0.23f + 2.2f)), reach * 0.70f, alpha * 0.9f)
}

/** One glow behind the cover that swells and fades with a ~5 second rhythm. */
private fun DrawScope.drawPulse(t: Float, middle: Color, intensity: Float) {
    val w = size.width
    val h = size.height
    val reach = max(w, h)
    val breath = (sin(t * 1.25f) + 1f) / 2f              // 0..1
    val color = lerp(middle, Color.White, 0.30f)
    glow(
        color  = color,
        cx     = w / 2f,
        cy     = h * 0.34f,
        radius = reach * (0.55f + 0.08f * breath),
        alpha  = (0.40f + 0.20f * breath) * intensity * 1.4f
    )
}
