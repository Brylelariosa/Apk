package com.melodiq.data.model

import android.net.Uri
import androidx.compose.runtime.Immutable
import com.melodiq.util.MediaTags

@Immutable
data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val duration: Long,          // milliseconds
    val uri: Uri,
    val artworkUri: Uri?,
    val size: Long,
    val dateAdded: Long,
    val albumId: Long,
    val isFavorite: Boolean = false
) {
    /** False when the file has no artist tag (MediaStore reports "<unknown>"). */
    val hasArtist: Boolean get() = MediaTags.isKnown(artist)
}
