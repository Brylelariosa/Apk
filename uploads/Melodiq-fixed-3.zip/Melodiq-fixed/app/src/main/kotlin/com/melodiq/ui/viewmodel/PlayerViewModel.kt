package com.melodiq.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.Player
import com.melodiq.data.model.PlaybackProgress
import com.melodiq.data.model.PlayerState
import com.melodiq.data.model.RepeatMode
import com.melodiq.data.model.SleepTimer
import com.melodiq.data.model.Song
import com.melodiq.data.repository.MusicRepository
import com.melodiq.player.PlayerManager
import com.melodiq.util.SleepTimerManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject
import kotlin.random.Random

/**
 * One instance for the whole app (created in AppRoot and handed down to every screen),
 * so the mini player, lists and Now Playing always agree on what is playing.
 */
@HiltViewModel
class PlayerViewModel @Inject constructor(
    private val playerManager: PlayerManager,
    private val musicRepository: MusicRepository,
    private val sleepTimerManager: SleepTimerManager
) : ViewModel() {

    private companion object {
        const val POSITION_POLL_MS = 200L
    }

    private val _state = MutableStateFlow(PlayerState())
    val state: StateFlow<PlayerState> = _state.asStateFlow()

    val sleepTimer: StateFlow<SleepTimer?> = sleepTimerManager.timer

    // Bumped to force a position re-read while paused (seeking, skipping).
    private val progressRefresh = MutableStateFlow(0)

    /**
     * Position/duration, kept apart from [state] on purpose: while playing it changes
     * 5×/second and only the seek bar and mini-player bar should recompose for it.
     * The ticker only runs while someone is collecting AND the song is playing.
     */
    @OptIn(ExperimentalCoroutinesApi::class)
    val progress: StateFlow<PlaybackProgress> = combine(
        playerManager.isPlaying,
        playerManager.connected,
        playerManager.currentMediaItem,
        progressRefresh
    ) { playing, _, _, _ -> playing }
        .flatMapLatest { playing -> progressTicker(playing) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), PlaybackProgress())

    init {
        playerManager.connect()
        observePlayerState()
    }

    private fun progressTicker(playing: Boolean): Flow<PlaybackProgress> = flow {
        do {
            emit(PlaybackProgress(playerManager.getCurrentPosition(), playerManager.getDuration()))
            if (playing) delay(POSITION_POLL_MS)
        } while (playing)
    }

    private fun observePlayerState() {
        viewModelScope.launch {
            combine(
                playerManager.isPlaying,
                playerManager.shuffleEnabled,
                playerManager.repeatMode
            ) { playing, shuffle, repeat -> Triple(playing, shuffle, repeat) }
                .collect { (playing, shuffle, repeat) ->
                    _state.update {
                        it.copy(
                            isPlaying      = playing,
                            shuffleEnabled = shuffle,
                            repeatMode     = repeat.toRepeatMode()
                        )
                    }
                }
        }

        // Whenever ExoPlayer moves to another item (tap, next, previous, auto-advance)
        // look the full Song up in the database so currentSong is always accurate.
        viewModelScope.launch {
            playerManager.currentMediaItem.collectLatest { item ->
                val songId = item?.mediaId?.toLongOrNull()
                if (songId == null) {
                    // "null" before the controller connects is not "nothing playing"
                    if (playerManager.connected.value) {
                        _state.update { it.copy(currentSong = null) }
                    }
                    return@collectLatest
                }
                val song = musicRepository.getSongById(songId)
                _state.update { it.copy(currentSong = song) }
                musicRepository.markRecentlyPlayed(songId)
            }
        }
    }

    private fun Int.toRepeatMode(): RepeatMode = when (this) {
        Player.REPEAT_MODE_ONE -> RepeatMode.ONE
        Player.REPEAT_MODE_ALL -> RepeatMode.ALL
        else                   -> RepeatMode.OFF
    }

    private fun refreshProgress() = progressRefresh.update { it + 1 }

    // ── Public actions ───────────────────────────────────────────────────────

    fun playSongs(songs: List<Song>, startIndex: Int = 0, shuffle: Boolean? = null) {
        if (songs.isEmpty()) return
        val index = startIndex.coerceIn(0, songs.lastIndex)
        // show the new song immediately instead of waiting for the player callback
        _state.update {
            it.copy(queue = songs, currentIndex = index, currentSong = songs[index])
        }
        playerManager.playSongs(songs, index, shuffle)
    }

    fun togglePlayPause() = playerManager.togglePlayPause()

    fun seekToNext() {
        playerManager.seekToNext()
        refreshProgress()
    }

    fun seekToPrevious() {
        playerManager.seekToPrevious()
        refreshProgress()
    }

    fun seekTo(ms: Long) {
        playerManager.seekTo(ms)
        refreshProgress()
    }

    fun toggleShuffle()   = playerManager.toggleShuffle()
    fun cycleRepeatMode() = playerManager.cycleRepeatMode()

    fun toggleFavorite(song: Song) {
        val nowFavorite = !song.isFavorite
        viewModelScope.launch {
            musicRepository.toggleFavorite(song.id, nowFavorite)
            // Only touch currentSong when the toggled song IS the playing one — favouriting
            // another song from a list must not change what the mini player shows.
            _state.update { s ->
                val current = s.currentSong
                if (current != null && current.id == song.id) {
                    s.copy(currentSong = current.copy(isFavorite = nowFavorite))
                } else {
                    s
                }
            }
        }
    }

    /** "Shuffle" button: shuffle on, a random song first, every other song once after it. */
    fun shuffleAndPlay(songs: List<Song>) {
        if (songs.isEmpty()) return
        playSongs(songs, Random.nextInt(songs.size), shuffle = true)
    }

    fun setSleepTimer(minutes: Int) {
        // pause() — not togglePlayPause(): if you already paused, the timer must not restart the music
        sleepTimerManager.start(minutes) { playerManager.pause() }
    }

    fun cancelSleepTimer() = sleepTimerManager.cancel()
}
