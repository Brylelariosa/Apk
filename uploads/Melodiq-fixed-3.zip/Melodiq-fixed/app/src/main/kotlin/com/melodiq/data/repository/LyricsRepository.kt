package com.melodiq.data.repository

import com.melodiq.crash.AppLog
import com.melodiq.data.db.dao.LyricsDao
import com.melodiq.data.db.entity.LyricsEntity
import com.melodiq.data.model.LyricLine
import com.melodiq.data.model.LyricsCandidate
import com.melodiq.data.model.LyricsMeta
import com.melodiq.data.model.LyricsResult
import com.melodiq.data.model.LyricsSource
import com.melodiq.data.model.Song
import com.melodiq.data.model.VersionSearch
import com.melodiq.data.network.LrcLibResponse
import com.melodiq.data.network.LrcLibService
import com.melodiq.util.LrcParser
import com.melodiq.util.LyricsCleanup
import com.melodiq.util.LyricsQuality
import com.melodiq.util.MediaTags
import com.melodiq.util.TitleCleaner
import com.melodiq.util.TrackMatcher
import com.melodiq.util.TrackQuery
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import retrofit2.Response
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.abs

/**
 * Finds, stores and replaces the lyrics of a song.
 *
 * Lookup order for the automatic lyrics (stops at the first complete hit):
 *  1. LRCLIB exact lookup  (/api/get)     — only when the song has an artist tag
 *  2. LRCLIB field search  (/api/search)  — works with title only, results are scored by
 *     title + duration (+ artist when known) and, among the trusted ones, the FULLEST lyrics win
 *  3. LRCLIB free-text search (q=…)       — last resort
 *
 * A hit that looks cut short (see [LyricsQuality]) is kept only as a fallback while the remaining
 * steps look for a fuller version. Hits are cached 30 days, misses 1 day, network failures never.
 *
 * On top of that sit the user's own choices ([CustomLyricsStore]): another version, pasted text or
 * an imported file replace the automatic lyrics for that song until they are reset.
 */
@Singleton
class LyricsRepository @Inject constructor(
    private val lrcLibService: LrcLibService,
    private val lyricsDao: LyricsDao,
    private val customStore: CustomLyricsStore
) {
    companion object {
        private const val TAG = "Lyrics"
        private const val HIT_TTL_MS  = 30L * 24 * 60 * 60 * 1000   // 30 days — found lyrics
        private const val MISS_TTL_MS = 24L * 60 * 60 * 1000        // 1 day  — not found
        // Bumping this invalidates every cached entry. v3: lookups now prefer the fullest lyrics,
        // so lyrics cached by older versions (possibly cut short) are fetched again.
        private const val CACHE_VERSION = "v3"
        private const val MAX_VERSION_RESULTS = 25
    }

    private sealed interface Lookup {
        data class Found(val record: LrcLibResponse) : Lookup
        object Missing : Lookup        // service answered: nothing there
        object Unavailable : Lookup    // offline / timeout / server error: never cache
    }

    private sealed interface Reply<out T> {
        data class Body<T>(val value: T?) : Reply<T>
        object NotFound : Reply<Nothing>
        object Failed : Reply<Nothing>
    }

    // ── Public API ───────────────────────────────────────────────────────────

    suspend fun getLyrics(song: Song, forceRefresh: Boolean = false): LyricsResult =
        withContext(Dispatchers.IO) {
            val custom = customStore.get(customKey(song))
            if (custom != null && custom.hasContent) {
                return@withContext buildResult(song, custom.synced, custom.plain, custom.source, custom.offsetMs)
            }
            val offset = custom?.offsetMs ?: 0L

            val key    = cacheKey(song)
            val cached = lyricsDao.getByKey(key)
            if (cached != null && !forceRefresh && !cached.isStale()) {
                return@withContext fromEntity(song, cached, offset)
            }

            when (val lookup = lookUp(TrackMatcher.buildQueries(song), durationSeconds(song))) {
                is Lookup.Found -> {
                    val entity = song.toEntity(key, lookup.record)
                    lyricsDao.upsert(entity)
                    fromEntity(song, entity, offset)
                }
                Lookup.Missing -> {
                    lyricsDao.upsert(song.toEntity(key, record = null))
                    LyricsResult.NotFound
                }
                Lookup.Unavailable -> {
                    val fallback = cached?.let { fromEntity(song, it, offset) }
                    if (fallback != null && fallback !is LyricsResult.NotFound) fallback
                    else LyricsResult.Offline
                }
            }
        }

    /** Every LRCLIB version of the song that has lyrics, best match first — for the version picker. */
    suspend fun findVersions(song: Song, title: String, artist: String): VersionSearch =
        withContext(Dispatchers.IO) {
            val cleanTitle = TitleCleaner.clean(title).ifBlank { title.trim() }
            if (cleanTitle.isBlank()) return@withContext VersionSearch.Empty

            val wantedArtist = artist.trim().takeIf { MediaTags.isKnown(it) }
            val durationSec  = durationSeconds(song)

            val replies = ArrayList<Reply<List<LrcLibResponse>>>()
            replies.add(call { lrcLibService.search(trackName = cleanTitle, artistName = wantedArtist) })
            if (wantedArtist != null) {
                replies.add(call { lrcLibService.search(query = wantedArtist + " " + cleanTitle) })
            }

            val found = LinkedHashMap<Int, LrcLibResponse>()
            var answered = false
            for (reply in replies) {
                when (reply) {
                    is Reply.Body -> {
                        answered = true
                        for (record in reply.value.orEmpty()) {
                            val id = record.id ?: continue
                            if (record.hasLyrics() && !found.containsKey(id)) found[id] = record
                        }
                    }
                    Reply.NotFound -> answered = true
                    Reply.Failed   -> Unit
                }
            }
            if (found.isEmpty()) {
                return@withContext if (answered) VersionSearch.Empty else VersionSearch.Offline
            }

            val ranked = found.values
                .map { record -> record to TrackMatcher.rankLoosely(record, cleanTitle, wantedArtist, durationSec) }
                .sortedWith(
                    compareByDescending<Pair<LrcLibResponse, Int>> { it.second }
                        .thenByDescending { TrackMatcher.lineCount(it.first) }
                )
                .take(MAX_VERSION_RESULTS)

            val items = ArrayList<LyricsCandidate>(ranked.size)
            for ((index, entry) in ranked.withIndex()) {
                val record = entry.first
                val recordDuration = record.duration
                items.add(
                    LyricsCandidate(
                        id              = record.id ?: index,
                        title           = record.trackName.orEmpty(),
                        artist          = record.artistName.orEmpty(),
                        album           = record.albumName.orEmpty(),
                        durationSec     = recordDuration?.toInt(),
                        durationDiffSec = if (recordDuration != null && durationSec != null)
                            abs(recordDuration - durationSec).toInt() else null,
                        syncedLines     = parseTimed(record.syncedLyrics).size,
                        plainLines      = LyricsQuality.plainLineCount(record.plainLyrics),
                        preview         = previewOf(record),
                        isBestMatch     = index == 0,
                        syncedLyrics    = record.syncedLyrics,
                        plainLyrics     = record.plainLyrics
                    )
                )
            }
            VersionSearch.Results(items)
        }

    /** The user picked [candidate] from the version list. */
    suspend fun useVersion(song: Song, candidate: LyricsCandidate): LyricsResult =
        withContext(Dispatchers.IO) {
            storeChoice(song, candidate.syncedLyrics, candidate.plainLyrics, LyricsSource.PICKED)
        }

    /**
     * The user typed, pasted or imported lyrics. Text with timestamps (LRC) becomes synced lyrics,
     * anything else plain lyrics. Empty text means "go back to automatic".
     */
    suspend fun saveCustom(song: Song, text: String, source: LyricsSource): LyricsResult =
        withContext(Dispatchers.IO) {
            val clean = text.replace("\r\n", "\n").replace('\r', '\n').trim()
            if (clean.isEmpty()) return@withContext resetToAutomatic(song)

            val timed = LrcParser.parse(clean)
            if (timed.size >= 2) {
                val plain = timed.joinToString("\n") { it.text }
                storeChoice(song, clean, plain, source)
            } else {
                storeChoice(song, null, clean, source)
            }
        }

    /** Drops the user's choice for this song (the sync offset is kept) and looks the lyrics up again. */
    suspend fun resetToAutomatic(song: Song): LyricsResult = withContext(Dispatchers.IO) {
        val key = customKey(song)
        val existing = customStore.get(key)
        if (existing != null) {
            if (existing.offsetMs == 0L) {
                customStore.remove(key)
            } else {
                customStore.put(key, CustomLyricsStore.Entry(offsetMs = existing.offsetMs))
            }
        }
        getLyrics(song)
    }

    /** Remembers the sync offset for this song and returns the lyrics shifted by it. */
    suspend fun setOffset(song: Song, offsetMs: Long): LyricsResult = withContext(Dispatchers.IO) {
        val key = customKey(song)
        val updated = (customStore.get(key) ?: CustomLyricsStore.Entry()).copy(offsetMs = offsetMs)
        if (!updated.hasContent && offsetMs == 0L) customStore.remove(key) else customStore.put(key, updated)
        getLyrics(song)
    }

    /** The raw text for the lyrics editor: LRC when the lyrics are synced, plain text otherwise. */
    suspend fun editableText(song: Song): String = withContext(Dispatchers.IO) {
        val custom = customStore.get(customKey(song))
        if (custom != null && custom.hasContent) {
            return@withContext custom.synced?.takeIf { it.isNotBlank() } ?: custom.plain.orEmpty()
        }
        val cached = lyricsDao.getByKey(cacheKey(song))
        cached?.syncedLyrics?.takeIf { it.isNotBlank() } ?: cached?.plainLyrics.orEmpty()
    }

    suspend fun purgeOldCache() = withContext(Dispatchers.IO) {
        lyricsDao.purgeOlderThan(System.currentTimeMillis() - HIT_TTL_MS)
    }

    // ── Network ──────────────────────────────────────────────────────────────

    private suspend fun lookUp(queries: List<TrackQuery>, durationSec: Int?): Lookup {
        // A hit that looks cut short is only a fallback: the next steps may find a fuller version.
        var fallback: LrcLibResponse? = null

        for (query in queries) {
            // 1) exact signature — needs an artist
            if (query.artist != null) {
                val reply = call {
                    lrcLibService.getLyrics(query.artist, query.title, query.album, durationSec)
                }
                when (reply) {
                    is Reply.Body -> {
                        val hit = reply.value?.takeIf { it.hasLyrics() }
                        if (hit != null) {
                            if (!looksIncomplete(hit, durationSec)) return Lookup.Found(hit)
                            fallback = fuller(fallback, hit)
                        }
                    }
                    Reply.NotFound -> Unit
                    Reply.Failed   -> return foundOr(fallback, Lookup.Unavailable)
                }
            }

            // 2) field search — title only is fine
            val search = call {
                lrcLibService.search(trackName = query.title, artistName = query.artist)
            }
            when (search) {
                is Reply.Body -> {
                    val best = TrackMatcher.pickBest(search.value.orEmpty(), query, durationSec)
                    if (best != null) {
                        if (!looksIncomplete(best, durationSec)) return Lookup.Found(best)
                        fallback = fuller(fallback, best)
                    }
                }
                Reply.NotFound -> Unit
                Reply.Failed   -> return foundOr(fallback, Lookup.Unavailable)
            }
        }

        // 3) free-text search with the most specific query
        val first = queries.firstOrNull() ?: return foundOr(fallback, Lookup.Missing)
        val text  = listOfNotNull(first.artist, first.title).joinToString(" ")
        val free  = call { lrcLibService.search(query = text) }
        when (free) {
            is Reply.Body -> {
                val best = TrackMatcher.pickBest(free.value.orEmpty(), first, durationSec)
                if (best != null) {
                    if (!looksIncomplete(best, durationSec)) return Lookup.Found(best)
                    fallback = fuller(fallback, best)
                }
            }
            Reply.NotFound -> Unit
            Reply.Failed   -> return foundOr(fallback, Lookup.Unavailable)
        }
        return foundOr(fallback, Lookup.Missing)
    }

    private fun foundOr(record: LrcLibResponse?, otherwise: Lookup): Lookup =
        if (record != null) Lookup.Found(record) else otherwise

    private fun fuller(current: LrcLibResponse?, candidate: LrcLibResponse): LrcLibResponse =
        if (current == null || TrackMatcher.lineCount(candidate) > TrackMatcher.lineCount(current)) candidate else current

    private fun looksIncomplete(record: LrcLibResponse, durationSec: Int?): Boolean {
        val timed = parseTimed(record.syncedLyrics)
        val durationMs = (durationSec ?: 0) * 1000L
        return LyricsQuality.assess(timed, record.plainLyrics, durationMs).possiblyIncomplete
    }

    private suspend fun <T> call(block: suspend () -> Response<T>): Reply<T> = try {
        val response = block()
        when {
            response.isSuccessful  -> Reply.Body(response.body())
            response.code() == 404 -> Reply.NotFound
            else                   -> Reply.Failed          // 429 / 5xx — try again later
        }
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        AppLog.w(TAG, "LRCLIB request failed", e)
        Reply.Failed                                        // offline, DNS, timeout, bad JSON
    }

    // ── Building results ─────────────────────────────────────────────────────

    /** Stores the user's choice for [song] (keeping its sync offset) and returns the lyrics to show. */
    private suspend fun storeChoice(
        song: Song,
        synced: String?,
        plain: String?,
        source: LyricsSource
    ): LyricsResult {
        val key = customKey(song)
        val offset = customStore.get(key)?.offsetMs ?: 0L
        customStore.put(key, CustomLyricsStore.Entry(synced = synced, plain = plain, source = source, offsetMs = offset))
        return buildResult(song, synced, plain, source, offset)
    }

    private fun fromEntity(song: Song, entity: LyricsEntity, offsetMs: Long): LyricsResult =
        buildResult(song, entity.syncedLyrics, entity.plainLyrics, LyricsSource.AUTO, offsetMs)

    private fun buildResult(
        song: Song,
        synced: String?,
        plain: String?,
        source: LyricsSource,
        offsetMs: Long
    ): LyricsResult {
        val plainText = plain?.takeIf { it.isNotBlank() }
        val timed = parseTimed(synced)

        if (timed.isNotEmpty()) {
            val quality = LyricsQuality.assess(timed, plainText, song.duration)
            val merged  = if (plainText != null) LyricsQuality.withMissingTail(timed, plainText) else timed
            val tail    = merged.size - timed.size
            val shifted = if (offsetMs == 0L) merged else merged.map { line ->
                if (line.isTimed) line.copy(timeMs = (line.timeMs + offsetMs).coerceAtLeast(0L)) else line
            }
            return LyricsResult.Synced(
                lines = shifted,
                meta  = LyricsMeta(
                    source             = source,
                    offsetMs           = offsetMs,
                    possiblyIncomplete = quality.possiblyIncomplete && tail == 0,
                    untimedTail        = tail,
                    plainText          = plainText
                )
            )
        }

        if (plainText != null) {
            val quality = LyricsQuality.assess(emptyList(), plainText, song.duration)
            return LyricsResult.Plain(
                text = plainText,
                meta = LyricsMeta(
                    source             = source,
                    offsetMs           = offsetMs,
                    possiblyIncomplete = quality.possiblyIncomplete,
                    plainText          = plainText
                )
            )
        }
        return LyricsResult.NotFound
    }

    private fun parseTimed(synced: String?): List<LyricLine> {
        if (synced.isNullOrBlank()) return emptyList()
        return LrcParser.parse(synced)
            .map { it.copy(text = LyricsCleanup.clean(it.text)) }
            .filter { it.text.isNotBlank() }
    }

    private fun previewOf(record: LrcLibResponse): String {
        val timedTexts = parseTimed(record.syncedLyrics).map { it.text }
        val lines = if (timedTexts.isNotEmpty()) timedTexts else LyricsQuality.plainLines(record.plainLyrics)
        return lines.take(2).joinToString(" / ")
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    private fun durationSeconds(song: Song): Int? =
        (song.duration / 1000).toInt().takeIf { it > 0 }

    private fun cacheKey(song: Song): String =
        "$CACHE_VERSION|${song.title.lowercase()}|${song.artist.lowercase()}|${song.duration / 1000}"

    /** Not versioned: a choice made by the user must survive changes to the lookup logic. */
    private fun customKey(song: Song): String =
        "c|${song.title.lowercase()}|${song.artist.lowercase()}|${song.duration / 1000}"

    private fun LyricsEntity.isStale(): Boolean {
        val isHit = !syncedLyrics.isNullOrBlank() || !plainLyrics.isNullOrBlank()
        val ttl   = if (isHit) HIT_TTL_MS else MISS_TTL_MS
        return System.currentTimeMillis() - fetchedAt >= ttl
    }

    private fun Song.toEntity(key: String, record: LrcLibResponse?) = LyricsEntity(
        cacheKey     = key,
        syncedLyrics = record?.syncedLyrics,
        plainLyrics  = record?.plainLyrics,
        trackTitle   = title,
        artistName   = artist,
        albumName    = album
    )
}
