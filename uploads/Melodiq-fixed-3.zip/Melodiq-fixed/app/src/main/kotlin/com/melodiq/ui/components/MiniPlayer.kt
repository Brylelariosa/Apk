package com.melodiq.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.melodiq.R
import com.melodiq.data.model.PlaybackProgress
import com.melodiq.data.model.PlayerState
import com.melodiq.ui.theme.AccentPink
import com.melodiq.ui.theme.PrimaryPurple
import com.melodiq.ui.theme.TextPrimary
import com.melodiq.ui.theme.TextSecondary
import com.melodiq.ui.theme.White10

@Composable
fun MiniPlayer(
    state: PlayerState,
    progress: () -> PlaybackProgress,
    onTogglePlayPause: () -> Unit,
    onSkipNext: () -> Unit,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val song = state.currentSong ?: return

    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        GlassCard(
            modifier     = Modifier.fillMaxWidth(),
            cornerRadius = 18.dp,
            alpha        = 0.20f
        ) {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(onClick = onClick)
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ArtworkImage(
                        uri      = song.artworkUri,
                        modifier = Modifier.size(44.dp)
                    )

                    Spacer(Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text     = song.title,
                            style    = MaterialTheme.typography.titleSmall,
                            color    = TextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text     = song.artist,
                            style    = MaterialTheme.typography.bodySmall,
                            color    = TextSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    IconActionButton(
                        icon               = if (state.isPlaying) R.drawable.ic_pause else R.drawable.ic_play,
                        contentDescription = if (state.isPlaying) "Pause" else "Play",
                        onClick            = onTogglePlayPause,
                        tint               = Color.White,
                        containerColor     = PrimaryPurple.copy(alpha = 0.35f),
                        buttonSize         = 40.dp,
                        iconSize           = 22.dp
                    )

                    Spacer(Modifier.width(4.dp))

                    IconActionButton(
                        icon               = R.drawable.ic_skip_next,
                        contentDescription = "Next song",
                        onClick            = onSkipNext,
                        tint               = TextSecondary,
                        buttonSize         = 40.dp,
                        iconSize           = 22.dp
                    )
                }

                MiniProgressBar(progress)
            }
        }
    }
}

/** Its own composable so the 5×/second position updates recompose only this thin bar. */
@Composable
private fun MiniProgressBar(progress: () -> PlaybackProgress) {
    val fraction = progress().fraction
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(2.dp)
            .background(White10)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(fraction)
                .height(2.dp)
                .background(Brush.horizontalGradient(listOf(PrimaryPurple, AccentPink)))
        )
    }
}
