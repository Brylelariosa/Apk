package com.melodiq.ui.components

import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import com.melodiq.data.model.LyricsAlign
import com.melodiq.data.model.LyricsFont
import com.melodiq.data.model.LyricsWeight

/** Maps the stored lyrics options to Compose text styles. Shared by Now Playing and the floating window. */

fun LyricsFont.toFontFamily(): FontFamily = when (this) {
    LyricsFont.DEFAULT -> FontFamily.Default
    LyricsFont.SERIF   -> FontFamily.Serif
    LyricsFont.MONO    -> FontFamily.Monospace
    LyricsFont.CURSIVE -> FontFamily.Cursive
}

fun LyricsWeight.toFontWeight(): FontWeight = when (this) {
    LyricsWeight.NORMAL -> FontWeight.Normal
    LyricsWeight.MEDIUM -> FontWeight.Medium
    LyricsWeight.BOLD   -> FontWeight.Bold
}

fun LyricsAlign.toTextAlign(): TextAlign = when (this) {
    LyricsAlign.START  -> TextAlign.Start
    LyricsAlign.CENTER -> TextAlign.Center
    LyricsAlign.END    -> TextAlign.End
}

fun LyricsAlign.toHorizontal(): Alignment.Horizontal = when (this) {
    LyricsAlign.START  -> Alignment.Start
    LyricsAlign.CENTER -> Alignment.CenterHorizontally
    LyricsAlign.END    -> Alignment.End
}

/** Colour choices offered in the settings (a stored value of 0 means "album colour" where allowed). */
val LyricsColorPalette: List<Int> = listOf(
    0xFFFFFFFF.toInt(), // white
    0xFFFFE066.toInt(), // yellow
    0xFFFFA94D.toInt(), // orange
    0xFFFF6B9D.toInt(), // pink
    0xFFFF5252.toInt(), // red
    0xFFB197FC.toInt(), // violet
    0xFF74C0FC.toInt(), // sky
    0xFF63E6BE.toInt(), // mint
    0xFF8CE99A.toInt(), // green
    0xFF000000.toInt()  // black
)

/** Colour from an ARGB int, with a safe fallback when the value is the 0 "album colour" marker. */
fun colorOrElse(argb: Int, fallback: Color): Color = if (argb == 0) fallback else Color(argb)
