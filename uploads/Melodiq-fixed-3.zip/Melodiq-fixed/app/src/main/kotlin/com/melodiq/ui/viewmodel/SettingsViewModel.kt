package com.melodiq.ui.viewmodel

import androidx.lifecycle.ViewModel
import com.melodiq.data.model.AppSettings
import com.melodiq.data.model.FloatingLyricsSettings
import com.melodiq.data.model.LookSettings
import com.melodiq.data.model.LyricsStyleSettings
import com.melodiq.data.repository.SettingsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.StateFlow
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val repository: SettingsRepository
) : ViewModel() {

    val settings: StateFlow<AppSettings> = repository.settings

    fun updateLook(transform: (LookSettings) -> LookSettings) =
        repository.update { it.copy(look = transform(it.look)) }

    fun updateLyrics(transform: (LyricsStyleSettings) -> LyricsStyleSettings) =
        repository.update { it.copy(lyrics = transform(it.lyrics)) }

    fun updateFloating(transform: (FloatingLyricsSettings) -> FloatingLyricsSettings) =
        repository.update { it.copy(floating = transform(it.floating)) }

    fun resetLook() = repository.update { it.copy(look = LookSettings()) }

    fun resetLyrics() = repository.update { it.copy(lyrics = LyricsStyleSettings()) }

    /** Back to the default look; whether the window is switched on is kept. */
    fun resetFloating() = repository.update {
        it.copy(floating = FloatingLyricsSettings(enabled = it.floating.enabled))
    }
}
