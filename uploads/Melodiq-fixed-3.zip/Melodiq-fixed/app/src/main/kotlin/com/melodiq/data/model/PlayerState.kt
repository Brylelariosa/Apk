package com.melodiq.data.model

import androidx.compose.runtime.Immutable

enum class RepeatMode { OFF, ALL, ONE }

/** Everything about playback except the fast-changing position (see [PlaybackProgress]). */
@Immutable
data class PlayerState(
    val currentSong: Song? = null,
    val isPlaying: Boolean = false,
    val shuffleEnabled: Boolean = false,
    val repeatMode: RepeatMode = RepeatMode.OFF,
    val queue: List<Song> = emptyList(),
    val currentIndex: Int = 0,
    val isLoading: Boolean = false
)

/** Position/duration live in their own flow so ticking 5×/second doesn't recompose song lists. */
@Immutable
data class PlaybackProgress(
    val positionMs: Long = 0L,
    val durationMs: Long = 0L
) {
    val fraction: Float
        get() = if (durationMs > 0L) (positionMs.toFloat() / durationMs).coerceIn(0f, 1f) else 0f
}
