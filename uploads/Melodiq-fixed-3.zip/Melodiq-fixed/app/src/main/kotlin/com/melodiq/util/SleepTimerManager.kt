package com.melodiq.util

import com.melodiq.data.model.SleepTimer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

/**
 * App-wide sleep timer. It lives in a singleton (not a ViewModel) so it keeps counting
 * after you close the app while music is still playing in the background.
 */
@Singleton
class SleepTimerManager @Inject constructor() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var job: Job? = null

    private val _timer = MutableStateFlow<SleepTimer?>(null)
    val timer: StateFlow<SleepTimer?> = _timer.asStateFlow()

    fun start(minutes: Int, onExpire: () -> Unit) {
        cancel()
        if (minutes <= 0) return
        val newTimer = SleepTimer(durationMinutes = minutes)
        _timer.value = newTimer
        job = scope.launch {
            delay(newTimer.durationMinutes * 60_000L)
            _timer.value = null
            onExpire()
        }
    }

    fun cancel() {
        job?.cancel()
        job = null
        _timer.value = null
    }
}
