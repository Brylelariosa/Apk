package com.melodiq.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.melodiq.data.model.Song
import com.melodiq.data.repository.MusicRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class LibraryUiState(
    val allSongs:      List<Song> = emptyList(),
    val recentSongs:   List<Song> = emptyList(),
    val favoriteSongs: List<Song> = emptyList(),
    val isLoading:     Boolean    = false,
    // surfaced so the UI can explain a failed scan instead of staying empty forever
    val scanError:     String?    = null
)

@HiltViewModel
class LibraryViewModel @Inject constructor(
    private val musicRepository: MusicRepository
) : ViewModel() {

    private val _isLoading = MutableStateFlow(false)
    private val _scanError = MutableStateFlow<String?>(null)

    val uiState: StateFlow<LibraryUiState> = combine(
        musicRepository.allSongs,
        musicRepository.recentSongs,
        musicRepository.favoriteSongs,
        _isLoading,
        _scanError
    ) { all, recent, fav, loading, error ->
        LibraryUiState(
            allSongs      = all,
            recentSongs   = recent,
            favoriteSongs = fav,
            isLoading     = loading,
            scanError     = error
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), LibraryUiState())

    fun syncLibrary() {
        if (_isLoading.value) return          // prevent concurrent scans
        viewModelScope.launch {
            _isLoading.value = true
            _scanError.value = null
            try {
                musicRepository.syncLibrary()
            } catch (e: CancellationException) {
                throw e
            } catch (e: SecurityException) {
                // permission granted but MediaStore not ready yet — a retry normally works
                _scanError.value = "Storage permission error — please try again."
            } catch (e: Exception) {
                _scanError.value = "Could not scan library: ${e.message}"
            } finally {
                _isLoading.value = false
            }
        }
    }
}
