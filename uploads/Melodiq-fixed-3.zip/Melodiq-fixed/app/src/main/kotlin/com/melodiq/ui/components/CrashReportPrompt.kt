package com.melodiq.ui.components

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.melodiq.crash.CrashNotice
import com.melodiq.crash.CrashReporter

// Intents travel through a size-limited system channel, so very long reports are cut when shared.
// The complete report is always in the Download folder.
private const val MAX_SHARED_CHARS = 100_000

/**
 * Shown on the first start after a crash. It says which file was saved to the Download folder
 * and lets the user send the report without opening a file manager. Draws nothing otherwise.
 */
@Composable
fun CrashReportPrompt() {
    val notice by CrashReporter.notice.collectAsStateWithLifecycle()
    val current = notice ?: return
    val context = LocalContext.current

    AlertDialog(
        onDismissRequest = { CrashReporter.dismissNotice() },
        title = { Text("Melodiq closed unexpectedly") },
        text = { Text(messageFor(current)) },
        confirmButton = {
            TextButton(onClick = { shareReport(context, current) }) { Text("Share") }
        },
        dismissButton = {
            TextButton(onClick = { CrashReporter.dismissNotice() }) { Text("Close") }
        }
    )
}

private fun messageFor(notice: CrashNotice): String = buildString {
    if (notice.savedToDownloads) {
        append("A crash report was saved to your Download folder:\n\n")
        append(notice.fileName)
    } else {
        append("A crash report was saved inside the app. It will be copied to your Download folder once storage access is granted.")
    }
    if (notice.moreReports > 0) {
        append("\n\n(${notice.moreReports} older report(s) are waiting as well.)")
    }
    append("\n\nSend the file when you report the problem, or tap Share.")
}

private fun shareReport(context: Context, notice: CrashNotice) {
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_SUBJECT, notice.fileName)
        putExtra(Intent.EXTRA_TEXT, notice.text.take(MAX_SHARED_CHARS))
    }
    try {
        context.startActivity(Intent.createChooser(send, "Share crash report"))
    } catch (noApp: ActivityNotFoundException) {
        // No app can take plain text; the file in Download is still there.
    }
}
