package com.melodiq.ui.components

import androidx.annotation.DrawableRes
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.melodiq.R
import com.melodiq.data.model.LyricLine
import com.melodiq.data.model.LyricsAlign
import com.melodiq.data.model.LyricsResult
import com.melodiq.data.model.LyricsSource
import com.melodiq.data.model.LyricsStyleSettings
import com.melodiq.ui.theme.AccentViolet
import com.melodiq.ui.theme.PrimaryPurple
import com.melodiq.ui.theme.TextSecondary
import com.melodiq.util.LyricsCleanup
import com.melodiq.util.ProcessedLyric

/**
 * The lyrics area of Now Playing.
 *
 * @param hasArtist false when the song has no artist tag — the "not found" state then explains
 *                  that and nudges the user towards searching with a typed artist.
 * @param showFullText show the complete plain-text version instead of the synced one (for lyrics
 *                  whose synced version stops early).
 */
@Composable
fun LyricsView(
    result: LyricsResult,
    activeIndex: Int,
    hasArtist: Boolean,
    style: LyricsStyleSettings,
    accentColor: Color,
    showFullText: Boolean,
    onRetry: () -> Unit,
    onChooseVersion: () -> Unit,
    onOpenOptions: () -> Unit,
    onSeekTo: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    when (result) {
        is LyricsResult.Loading  -> LyricsLoading(modifier)
        is LyricsResult.NotFound -> LyricsNotFound(hasArtist, onRetry, onChooseVersion, onOpenOptions, modifier)
        is LyricsResult.Offline  -> LyricsRetryState(
            icon     = R.drawable.ic_refresh,
            title    = "Can't reach the lyrics service",
            message  = "Check your internet connection, then try again.",
            onRetry  = onRetry,
            modifier = modifier
        )
        is LyricsResult.Failed   -> LyricsRetryState(
            icon     = R.drawable.ic_lyrics,
            title    = "Couldn't load lyrics",
            message  = "Something went wrong while loading the lyrics for this song. Try again.",
            onRetry  = onRetry,
            modifier = modifier
        )
        is LyricsResult.Synced   -> {
            val fullText = result.meta.plainText
            if (showFullText && fullText != null) {
                PlainLyricsContent(fullText, style, modifier)
            } else {
                BannerFrame(result.meta.possiblyIncomplete, onChooseVersion, modifier) {
                    SyncedLyricsContent(
                        lines       = result.lines,
                        activeIndex = activeIndex,
                        style       = style,
                        accentColor = accentColor,
                        onSeekTo    = onSeekTo
                    )
                }
            }
        }
        is LyricsResult.Plain    -> BannerFrame(result.meta.possiblyIncomplete, onChooseVersion, modifier) {
            PlainLyricsContent(result.text, style, Modifier)
        }
    }
}

// ── Toolbar ───────────────────────────────────────────────────────────────────

/** Small row above the lyrics: what you are looking at, plus the lyrics tools. */
@Composable
fun LyricsToolbar(
    result: LyricsResult,
    showFullText: Boolean,
    floatingOn: Boolean,
    onToggleFullText: () -> Unit,
    onToggleFloating: () -> Unit,
    onOpenOptions: () -> Unit,
    modifier: Modifier = Modifier
) {
    val label = statusLabel(result)
    val canShowFullText = result is LyricsResult.Synced && result.meta.plainText != null

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text     = label ?: "Lyrics",
            color    = TextSecondary,
            style    = MaterialTheme.typography.labelMedium,
            modifier = Modifier
                .weight(1f)
                .padding(start = 8.dp)
        )
        if (canShowFullText) {
            ToolbarChip(
                text     = "Full text",
                selected = showFullText,
                onClick  = onToggleFullText
            )
        }
        IconActionButton(
            icon               = R.drawable.ic_floating,
            contentDescription = if (floatingOn) "Turn off floating lyrics" else "Turn on floating lyrics",
            onClick            = onToggleFloating,
            tint               = if (floatingOn) AccentViolet else TextSecondary,
            buttonSize         = 44.dp,
            iconSize           = 22.dp
        )
        IconActionButton(
            icon               = R.drawable.ic_more_vert,
            contentDescription = "Lyrics options",
            onClick            = onOpenOptions,
            tint               = Color.White,
            buttonSize         = 44.dp,
            iconSize           = 22.dp
        )
    }
}

@Composable
private fun ToolbarChip(text: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        text     = text,
        color    = if (selected) Color.White else TextSecondary,
        style    = MaterialTheme.typography.labelMedium,
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(if (selected) PrimaryPurple.copy(alpha = 0.55f) else Color.White.copy(alpha = 0.10f))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp)
    )
}

private fun statusLabel(result: LyricsResult): String? = when (result) {
    is LyricsResult.Synced -> "Synced" + sourceSuffix(result.meta.source)
    is LyricsResult.Plain  -> "Plain text" + sourceSuffix(result.meta.source)
    else                   -> null
}

private fun sourceSuffix(source: LyricsSource): String = when (source) {
    LyricsSource.AUTO   -> ""
    LyricsSource.PICKED -> " · version you chose"
    LyricsSource.EDITED -> " · edited by you"
    LyricsSource.FILE   -> " · imported file"
}

// ── Banner ────────────────────────────────────────────────────────────────────

@Composable
private fun BannerFrame(
    showBanner: Boolean,
    onChooseVersion: () -> Unit,
    modifier: Modifier,
    content: @Composable () -> Unit
) {
    Column(modifier.fillMaxSize()) {
        if (showBanner) IncompleteBanner(onChooseVersion)
        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
        ) { content() }
    }
}

@Composable
private fun IncompleteBanner(onChooseVersion: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(Color.White.copy(alpha = 0.08f))
            .padding(start = 14.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text     = "These lyrics may be incomplete.",
            color    = TextSecondary,
            style    = MaterialTheme.typography.bodySmall,
            modifier = Modifier.weight(1f)
        )
        TextButton(onClick = onChooseVersion) {
            Text("Find another version", color = AccentViolet)
        }
    }
}

// ── Synced lyrics ─────────────────────────────────────────────────────────────

@Composable
private fun SyncedLyricsContent(
    lines: List<LyricLine>,
    activeIndex: Int,
    style: LyricsStyleSettings,
    accentColor: Color,
    onSeekTo: (Long) -> Unit
) {
    val listState = rememberLazyListState()
    // 0 = the album colour, lightened so it reads on the dark background
    val highlight = colorOrElse(style.highlightColor, lerp(accentColor, Color.White, 0.45f))
    var pauseAutoScrollUntil by remember { mutableLongStateOf(0L) }

    // While the user drags the list themselves, don't fight them for a few seconds.
    LaunchedEffect(listState) {
        listState.interactionSource.interactions.collect { interaction ->
            if (interaction is DragInteraction.Start) {
                pauseAutoScrollUntil = System.currentTimeMillis() + 3_500L
            }
        }
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        // Half a screen of padding above and below lets even the first and last line sit in the middle.
        val verticalPadding = maxHeight / 2

        LaunchedEffect(activeIndex, style.smoothScroll) {
            if (activeIndex < 0 || lines.isEmpty()) return@LaunchedEffect
            if (System.currentTimeMillis() < pauseAutoScrollUntil) return@LaunchedEffect
            centerLine(listState, activeIndex, style.smoothScroll)
        }

        LazyColumn(
            state               = listState,
            modifier            = Modifier.fillMaxSize(),
            contentPadding      = PaddingValues(horizontal = 28.dp, vertical = verticalPadding),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            itemsIndexed(items = lines, key = { index, _ -> index }) { index, line ->
                val distance = if (activeIndex < 0) index + 1 else kotlin.math.abs(index - activeIndex)
                LyricRow(
                    line      = line,
                    distance  = distance,
                    isActive  = index == activeIndex,
                    style     = style,
                    highlight = highlight,
                    glowColor = accentColor,
                    onClick   = if (style.tapToSeek && line.isTimed) {
                        {
                            pauseAutoScrollUntil = 0L
                            onSeekTo(line.timeMs)
                        }
                    } else {
                        null
                    }
                )
            }
        }
    }
}

/** Scrolls so the line at [index] sits in the vertical middle of the list. */
private suspend fun centerLine(state: LazyListState, index: Int, animate: Boolean) {
    var target = state.layoutInfo.visibleItemsInfo.firstOrNull { it.index == index }
    if (target == null) {
        // Not on screen yet (a seek, or the first line): jump next to it, then centre it.
        state.scrollToItem(index)
        target = state.layoutInfo.visibleItemsInfo.firstOrNull { it.index == index } ?: return
    }
    val viewportCenter = state.layoutInfo.viewportSize.height / 2f
    val delta = target.offset + target.size / 2f - viewportCenter
    if (delta == 0f) return
    if (animate) {
        state.animateScrollBy(delta, tween(450, easing = FastOutSlowInEasing))
    } else {
        state.scrollBy(delta)
    }
}

@Composable
private fun LyricRow(
    line: LyricLine,
    distance: Int,
    isActive: Boolean,
    style: LyricsStyleSettings,
    highlight: Color,
    glowColor: Color,
    onClick: (() -> Unit)?
) {
    val family = remember(style.font) { style.font.toFontFamily() }
    val weight = remember(style.weight) { style.weight.toFontWeight() }

    val restingAlpha = when {
        !line.isTimed     -> 0.30f                      // tail that only exists as plain text
        style.fadeDistant -> (style.inactiveAlpha * (1f - 0.12f * minOf(distance, 4))).coerceAtLeast(0.12f)
        else              -> style.inactiveAlpha
    }
    val alpha = animateFloatAsState(if (isActive) 1f else restingAlpha, tween(300), label = "lyric_alpha")
    val scale = animateFloatAsState(
        targetValue   = if (isActive) style.activeScale else 1f,
        animationSpec = tween(350, easing = FastOutSlowInEasing),
        label         = "lyric_scale"
    )
    val color = animateColorAsState(if (isActive) highlight else Color.White, tween(250), label = "lyric_color")
    val glow  = animateFloatAsState(if (isActive && style.glow) 1f else 0f, tween(400), label = "lyric_glow")

    val pivotX = when (style.alignment) {
        LyricsAlign.START  -> 0f
        LyricsAlign.CENTER -> 0.5f
        LyricsAlign.END    -> 1f
    }
    val boxAlignment = when (style.alignment) {
        LyricsAlign.START  -> Alignment.CenterStart
        LyricsAlign.CENTER -> Alignment.Center
        LyricsAlign.END    -> Alignment.CenterEnd
    }

    val clickModifier = if (onClick != null) {
        Modifier.clickable(
            interactionSource = remember { MutableInteractionSource() },
            indication        = null,
            onClick           = onClick
        )
    } else {
        Modifier
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .then(clickModifier)
            .padding(vertical = (style.textSizeSp * 0.35f).dp),
        contentAlignment = boxAlignment
    ) {
        Text(
            text       = line.text,
            color      = color.value,
            fontSize   = style.textSizeSp.sp,
            lineHeight = (style.textSizeSp * 1.3f).sp,
            fontFamily = family,
            fontWeight = weight,
            textAlign  = style.alignment.toTextAlign(),
            // The text is laid out narrower so that, once the current line is scaled up, it
            // fills the width exactly instead of running past the edge.
            modifier   = Modifier
                .fillMaxWidth(1f / style.activeScale)
                .graphicsLayer {
                    scaleX = scale.value
                    scaleY = scale.value
                    this.alpha = alpha.value
                    transformOrigin = TransformOrigin(pivotX, 0.5f)
                }
                .drawBehind {
                    if (glow.value > 0f) {
                        drawRect(
                            brush = Brush.radialGradient(
                                colors = listOf(
                                    glowColor.copy(alpha = 0.18f * glow.value),
                                    Color.Transparent
                                ),
                                radius = size.width * 0.7f
                            )
                        )
                    }
                }
        )
    }
}

// ── Plain lyrics ──────────────────────────────────────────────────────────────

@Composable
private fun PlainLyricsContent(text: String, style: LyricsStyleSettings, modifier: Modifier) {
    val processed = remember(text) { LyricsCleanup.processPlainLyrics(text) }
    val family = remember(style.font) { style.font.toFontFamily() }
    val weight = remember(style.weight) { style.weight.toFontWeight() }
    val textAlign = style.alignment.toTextAlign()

    LazyColumn(
        modifier            = modifier.fillMaxSize(),
        contentPadding      = PaddingValues(horizontal = 28.dp, vertical = 24.dp),
        horizontalAlignment = style.alignment.toHorizontal()
    ) {
        itemsIndexed(processed, key = { i, _ -> i }) { _, item: ProcessedLyric ->
            if (item.isSection) {
                SectionLabel(item.text)
            } else {
                Text(
                    text       = item.text,
                    color      = Color.White.copy(alpha = 0.85f),
                    fontSize   = (style.textSizeSp * 0.85f).sp,
                    lineHeight = (style.textSizeSp * 1.2f).sp,
                    fontFamily = family,
                    fontWeight = weight,
                    textAlign  = textAlign,
                    modifier   = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                )
            }
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text          = text.uppercase(),
        color         = PrimaryPurple,
        style         = MaterialTheme.typography.labelSmall,
        letterSpacing = 3.sp,
        modifier      = Modifier.padding(top = 24.dp, bottom = 8.dp)
    )
}

// ── States ────────────────────────────────────────────────────────────────────

@Composable
private fun LyricsLoading(modifier: Modifier) {
    Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator(color = PrimaryPurple, modifier = Modifier.size(32.dp))
            Spacer(Modifier.height(16.dp))
            Text("Fetching lyrics…", color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun LyricsNotFound(
    hasArtist: Boolean,
    onRetry: () -> Unit,
    onChooseVersion: () -> Unit,
    onOpenOptions: () -> Unit,
    modifier: Modifier
) {
    Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        EmptyState(
            icon    = R.drawable.ic_lyrics,
            title   = "No lyrics found",
            message = if (hasArtist) {
                "We couldn't find lyrics for this song. Search with different words, or add them yourself."
            } else {
                "This song has no artist name saved in its file, so the search used the title only. " +
                    "Type the artist yourself to search more accurately."
            }
        ) {
            MelodiqButton(
                text    = "Search lyrics",
                onClick = onChooseVersion,
                icon    = R.drawable.ic_search
            )
            Spacer(Modifier.height(12.dp))
            MelodiqButton(
                text    = "Add lyrics yourself",
                onClick = onOpenOptions,
                icon    = R.drawable.ic_edit,
                style   = ButtonStyle.Tonal
            )
            Spacer(Modifier.height(12.dp))
            MelodiqButton(
                text    = "Try again",
                onClick = onRetry,
                icon    = R.drawable.ic_refresh,
                style   = ButtonStyle.Outlined
            )
        }
    }
}

/** A centred message with a single "Try again" button — used for every retryable failure. */
@Composable
private fun LyricsRetryState(
    @DrawableRes icon: Int,
    title: String,
    message: String,
    onRetry: () -> Unit,
    modifier: Modifier
) {
    Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        EmptyState(
            icon    = icon,
            title   = title,
            message = message
        ) {
            MelodiqButton(
                text    = "Try again",
                onClick = onRetry,
                icon    = R.drawable.ic_refresh
            )
        }
    }
}
