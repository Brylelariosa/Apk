package com.melodiq.util

/**
 * Android's MediaStore does not return null for a missing tag — it returns the literal
 * string "<unknown>". Every place that cares whether a song really has an artist/album
 * goes through this object so the placeholder never leaks into the UI or into lyric lookups.
 */
object MediaTags {
    const val UNKNOWN_ARTIST = "Unknown artist"
    const val UNKNOWN_ALBUM  = "Unknown album"
    const val UNKNOWN_TITLE  = "Untitled"

    private val PLACEHOLDERS = setOf(
        "<unknown>", "unknown", "unknown artist", "unknown album"
    )

    fun isKnown(tag: String?): Boolean =
        !tag.isNullOrBlank() && tag.trim().lowercase() !in PLACEHOLDERS

    fun clean(tag: String?, fallback: String): String =
        tag?.trim()?.takeIf { isKnown(it) } ?: fallback
}
