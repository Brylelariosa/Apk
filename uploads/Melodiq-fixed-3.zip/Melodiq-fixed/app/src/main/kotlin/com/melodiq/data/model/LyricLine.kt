package com.melodiq.data.model

data class LyricLine(
    val timeMs: Long,
    val text: String,
    /**
     * False for lines that exist only in the plain-text version of the lyrics (no timestamp).
     * They are appended after the last timed line when the synced version stops early.
     */
    val isTimed: Boolean = true
)
