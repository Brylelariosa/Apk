package com.melodiq.data.network

import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query

data class LrcLibResponse(
    val id: Int? = null,
    val trackName: String? = null,
    val artistName: String? = null,
    val albumName: String? = null,
    val duration: Double? = null,
    val instrumental: Boolean? = null,
    val plainLyrics: String? = null,
    val syncedLyrics: String? = null
) {
    fun hasLyrics(): Boolean =
        instrumental != true && (!syncedLyrics.isNullOrBlank() || !plainLyrics.isNullOrBlank())
}

interface LrcLibService {

    /** Exact lookup by signature. Fast and precise, but only matches when the tags agree with LRCLIB's. */
    @GET("api/get")
    suspend fun getLyrics(
        @Query("artist_name") artistName: String? = null,
        @Query("track_name") trackName: String,
        @Query("album_name") albumName: String? = null,
        @Query("duration") duration: Int? = null
    ): Response<LrcLibResponse>

    /** Fuzzy search. Works without an artist (use [trackName] or free-text [query]). */
    @GET("api/search")
    suspend fun search(
        @Query("track_name") trackName: String? = null,
        @Query("artist_name") artistName: String? = null,
        @Query("q") query: String? = null
    ): Response<List<LrcLibResponse>>
}
