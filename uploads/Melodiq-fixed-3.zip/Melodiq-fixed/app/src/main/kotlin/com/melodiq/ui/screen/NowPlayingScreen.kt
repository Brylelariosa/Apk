package com.melodiq.ui.screen

import android.graphics.drawable.BitmapDrawable
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.imageLoader
import coil.request.ImageRequest
import coil.request.SuccessResult
import com.melodiq.R
import com.melodiq.data.model.LyricsMeta
import com.melodiq.data.model.LyricsResult
import com.melodiq.data.model.LyricsSource
import com.melodiq.data.model.Song
import com.melodiq.overlay.OverlayPermission
import com.melodiq.ui.components.AmbientBackground
import com.melodiq.ui.components.ButtonStyle
import com.melodiq.ui.components.IconActionButton
import com.melodiq.ui.components.LyricsEditorDialog
import com.melodiq.ui.components.LyricsOptionsDialog
import com.melodiq.ui.components.LyricsToolbar
import com.melodiq.ui.components.LyricsVersionsDialog
import com.melodiq.ui.components.LyricsView
import com.melodiq.ui.components.MelodiqButton
import com.melodiq.ui.components.NowPlayingCover
import com.melodiq.ui.components.OnResumeEffect
import com.melodiq.ui.components.OverlayPermissionDialog
import com.melodiq.ui.components.PlayerControls
import com.melodiq.ui.components.SleepTimerDialog
import com.melodiq.ui.theme.AccentPink
import com.melodiq.ui.theme.TextSecondary
import com.melodiq.ui.viewmodel.LyricsViewModel
import com.melodiq.ui.viewmodel.PlayerViewModel
import com.melodiq.ui.viewmodel.SettingsViewModel
import com.melodiq.ui.viewmodel.VersionsUiState
import com.melodiq.util.ColorExtractor
import com.melodiq.util.ExtractedColors
import com.melodiq.util.TextFileReader
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

/** Which of the lyrics dialogs is open. */
private class LyricsDialogState {
    var options by mutableStateOf(false)
    var versions by mutableStateOf(false)
    /** Non-null while the editor is open: the text it starts with. */
    var editorText by mutableStateOf<String?>(null)
}

@Composable
fun NowPlayingScreen(
    onBack: () -> Unit,
    onOpenSettings: () -> Unit,
    playerVm: PlayerViewModel,
    lyricsVm: LyricsViewModel = hiltViewModel(),
    settingsVm: SettingsViewModel = hiltViewModel()
) {
    val state         by playerVm.state.collectAsStateWithLifecycle()
    val progressState = playerVm.progress.collectAsStateWithLifecycle()
    val lyricsResult  by lyricsVm.lyricsResult.collectAsStateWithLifecycle()
    val activeLine    by lyricsVm.activeLine.collectAsStateWithLifecycle()
    val versionsState by lyricsVm.versions.collectAsStateWithLifecycle()
    val sleepTimer    by playerVm.sleepTimer.collectAsStateWithLifecycle()
    val settings      by settingsVm.settings.collectAsStateWithLifecycle()

    var extractedColors      by remember { mutableStateOf(ExtractedColors()) }
    var showLyrics           by rememberSaveable { mutableStateOf(false) }
    var showFullText         by rememberSaveable { mutableStateOf(false) }
    var showSleepTimer       by remember { mutableStateOf(false) }
    var showPermissionDialog by remember { mutableStateOf(false) }
    var waitingForPermission by remember { mutableStateOf(false) }
    val lyricDialogs = remember { LyricsDialogState() }

    val context = LocalContext.current
    val view    = LocalView.current
    val song    = state.currentSong
    val accent  = extractedColors.vibrant

    // Pull accent colours out of the album art. Songs without art fall back to the default palette.
    LaunchedEffect(song?.artworkUri) {
        val uri = song?.artworkUri
        if (uri == null) {
            extractedColors = ExtractedColors()
            return@LaunchedEffect
        }
        try {
            val request = ImageRequest.Builder(context).data(uri).allowHardware(false).build()
            val result  = context.imageLoader.execute(request)
            val bitmap  = (result.drawable as? BitmapDrawable)?.bitmap
            extractedColors = if (result is SuccessResult && bitmap != null) {
                ColorExtractor.extract(bitmap)
            } else {
                ExtractedColors()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            extractedColors = ExtractedColors()
        }
    }

    // Load lyrics whenever the song changes
    LaunchedEffect(song?.id) {
        showFullText = false
        song?.let { lyricsVm.loadLyrics(it) }
    }

    // Optional: keep the display on while the lyrics are open.
    DisposableEffect(showLyrics, settings.lyrics.keepScreenOn) {
        view.keepScreenOn = showLyrics && settings.lyrics.keepScreenOn
        onDispose { view.keepScreenOn = false }
    }

    val turnOnFloating = {
        settingsVm.updateFloating { it.copy(enabled = true) }
        val message = if (settings.floating.hideInApp) {
            "Floating lyrics on. They appear when you leave Melodiq."
        } else {
            "Floating lyrics on."
        }
        Toast.makeText(context, message, Toast.LENGTH_LONG).show()
    }

    // Coming back from the system "Display over other apps" page: finish turning the window on.
    OnResumeEffect {
        if (waitingForPermission && OverlayPermission.isGranted(context)) {
            waitingForPermission = false
            turnOnFloating()
        }
    }

    val bg1 = ColorExtractor.darken(extractedColors.dominant, 0.4f)
    val bg2 = ColorExtractor.darken(extractedColors.vibrant, 0.35f)
    val bg3 = Color(0xFF0D0D1A)
    val look = settings.look

    AmbientBackground(
        color1    = bg1,
        color2    = bg2,
        color3    = bg3,
        style     = look.backgroundStyle,
        intensity = look.backgroundIntensity,
        speed     = look.animationSpeed,
        animated  = !look.animateOnlyWhilePlaying || state.isPlaying
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
        ) {
            TopBar(onBack = onBack, onOpenSettings = onOpenSettings)

            AnimatedContent(
                targetState    = showLyrics,
                modifier       = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                transitionSpec = {
                    (slideInHorizontally { if (targetState) it else -it } + fadeIn()) togetherWith
                        (slideOutHorizontally { if (targetState) -it else it } + fadeOut())
                },
                label = "now_playing_panels"
            ) { lyricsMode ->
                if (lyricsMode) {
                    Column(Modifier.fillMaxSize()) {
                        LyricsToolbar(
                            result           = lyricsResult,
                            showFullText     = showFullText,
                            floatingOn       = settings.floating.enabled,
                            onToggleFullText = { showFullText = !showFullText },
                            onToggleFloating = {
                                when {
                                    settings.floating.enabled ->
                                        settingsVm.updateFloating { it.copy(enabled = false) }
                                    OverlayPermission.isGranted(context) -> turnOnFloating()
                                    else -> {
                                        showPermissionDialog = true
                                    }
                                }
                            },
                            onOpenOptions    = { lyricDialogs.options = true }
                        )
                        LyricsView(
                            result          = lyricsResult,
                            activeIndex     = activeLine,
                            hasArtist       = song?.hasArtist ?: true,
                            style           = settings.lyrics,
                            accentColor     = accent,
                            showFullText    = showFullText,
                            onRetry         = lyricsVm::retry,
                            onChooseVersion = { lyricDialogs.versions = true },
                            onOpenOptions   = { lyricDialogs.options = true },
                            onSeekTo        = playerVm::seekTo,
                            modifier        = Modifier.weight(1f)
                        )
                    }
                } else {
                    Column(
                        modifier            = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        NowPlayingCover(
                            artworkUri = song?.artworkUri,
                            isPlaying  = state.isPlaying,
                            look       = look,
                            glowColor  = accent,
                            modifier   = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                        )
                        SongInfoSection(
                            song       = song,
                            onFavorite = { song?.let { playerVm.toggleFavorite(it) } }
                        )
                    }
                }
            }

            PlayerControls(
                state             = state,
                progress          = { progressState.value },
                onTogglePlayPause = playerVm::togglePlayPause,
                onSeekToNext      = playerVm::seekToNext,
                onSeekToPrevious  = playerVm::seekToPrevious,
                onSeekTo          = playerVm::seekTo,
                onToggleShuffle   = playerVm::toggleShuffle,
                onCycleRepeat     = playerVm::cycleRepeatMode,
                accentColor       = accent,
                modifier          = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp)
            )

            ActionRow(
                showingLyrics  = showLyrics,
                sleepActive    = sleepTimer != null,
                accent         = accent,
                onToggleLyrics = { showLyrics = !showLyrics },
                onSleepTimer   = { showSleepTimer = true }
            )
        }
    }

    if (showSleepTimer) {
        SleepTimerDialog(
            timer         = sleepTimer,
            onDismiss     = { showSleepTimer = false },
            onSetTimer    = { minutes ->
                playerVm.setSleepTimer(minutes)
                showSleepTimer = false
            },
            onCancelTimer = {
                playerVm.cancelSleepTimer()
                showSleepTimer = false
            }
        )
    }

    if (showPermissionDialog) {
        OverlayPermissionDialog(
            onDismiss      = { showPermissionDialog = false },
            onOpenSettings = {
                showPermissionDialog = false
                waitingForPermission = true
                OverlayPermission.openSettings(context)
            }
        )
    }

    LyricsDialogHost(
        dialogs       = lyricDialogs,
        song          = song,
        lyricsResult  = lyricsResult,
        versionsState = versionsState,
        lyricsVm      = lyricsVm
    )
}

/** The lyrics options, editor and version picker, plus the file picker they use. */
@Composable
private fun LyricsDialogHost(
    dialogs: LyricsDialogState,
    song: Song?,
    lyricsResult: LyricsResult,
    versionsState: VersionsUiState,
    lyricsVm: LyricsViewModel
) {
    val context = LocalContext.current
    val scope   = rememberCoroutineScope()

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                val text = TextFileReader.read(context, uri)
                if (text != null) {
                    lyricsVm.importText(text)
                } else {
                    Toast.makeText(context, "Couldn't read that file", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    if (dialogs.options) {
        val meta = metaOf(lyricsResult)
        LyricsOptionsDialog(
            offsetMs        = meta?.offsetMs ?: 0L,
            isCustom        = meta != null && meta.source != LyricsSource.AUTO,
            onDismiss       = { dialogs.options = false },
            onChooseVersion = {
                dialogs.options = false
                dialogs.versions = true
            },
            onEdit          = {
                dialogs.options = false
                scope.launch { dialogs.editorText = lyricsVm.editableText() }
            },
            onImport        = {
                dialogs.options = false
                importLauncher.launch(arrayOf("*/*"))
            },
            onReset         = {
                dialogs.options = false
                lyricsVm.resetToAutomatic()
            },
            onOffsetChange  = { offsetMs -> lyricsVm.setOffset(offsetMs) }
        )
    }

    val editing = dialogs.editorText
    if (editing != null) {
        LyricsEditorDialog(
            initialText = editing,
            onDismiss   = { dialogs.editorText = null },
            onSave      = { text ->
                dialogs.editorText = null
                lyricsVm.saveText(text)
            }
        )
    }

    if (dialogs.versions && song != null) {
        LyricsVersionsDialog(
            initialTitle  = song.title,
            initialArtist = if (song.hasArtist) song.artist else "",
            state         = versionsState,
            onSearch      = { title, artist -> lyricsVm.searchVersions(title, artist) },
            onPick        = { candidate ->
                dialogs.versions = false
                lyricsVm.applyVersion(candidate)
            },
            onDismiss     = {
                dialogs.versions = false
                lyricsVm.clearVersions()
            }
        )
    }
}

private fun metaOf(result: LyricsResult): LyricsMeta? = when (result) {
    is LyricsResult.Synced -> result.meta
    is LyricsResult.Plain  -> result.meta
    else                   -> null
}

@Composable
private fun TopBar(onBack: () -> Unit, onOpenSettings: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconActionButton(
            icon               = R.drawable.ic_chevron_down,
            contentDescription = "Close player",
            onClick            = onBack,
            tint               = Color.White,
            buttonSize         = 48.dp,
            iconSize           = 28.dp
        )
        Text(
            text      = "Now playing",
            style     = MaterialTheme.typography.titleMedium,
            color     = Color.White,
            textAlign = TextAlign.Center,
            modifier  = Modifier.weight(1f)
        )
        IconActionButton(
            icon               = R.drawable.ic_tune,
            contentDescription = "Settings",
            onClick            = onOpenSettings,
            tint               = Color.White,
            buttonSize         = 48.dp,
            iconSize           = 24.dp
        )
    }
}

@Composable
private fun SongInfoSection(song: Song?, onFavorite: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text     = song?.title ?: "No track",
                style    = MaterialTheme.typography.headlineSmall,
                color    = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text     = song?.artist ?: "",
                style    = MaterialTheme.typography.bodyMedium,
                color    = TextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        val isFavorite = song?.isFavorite == true
        IconActionButton(
            icon               = if (isFavorite) R.drawable.ic_favorite else R.drawable.ic_favorite_border,
            contentDescription = if (isFavorite) "Remove from favorites" else "Add to favorites",
            onClick            = onFavorite,
            tint               = if (isFavorite) AccentPink else TextSecondary,
            buttonSize         = 48.dp,
            iconSize           = 26.dp
        )
    }
}

@Composable
private fun ActionRow(
    showingLyrics: Boolean,
    sleepActive: Boolean,
    accent: Color,
    onToggleLyrics: () -> Unit,
    onSleepTimer: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterHorizontally)
    ) {
        MelodiqButton(
            text    = if (showingLyrics) "Hide lyrics" else "Lyrics",
            onClick = onToggleLyrics,
            icon    = R.drawable.ic_lyrics,
            style   = if (showingLyrics) ButtonStyle.Filled else ButtonStyle.Tonal,
            accent  = accent
        )
        MelodiqButton(
            text    = "Sleep timer",
            onClick = onSleepTimer,
            icon    = R.drawable.ic_sleep,
            style   = if (sleepActive) ButtonStyle.Filled else ButtonStyle.Tonal,
            accent  = accent
        )
    }
}
