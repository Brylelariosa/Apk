package com.melodiq.ui.components

import androidx.annotation.DrawableRes
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.melodiq.ui.theme.PrimaryPurple
import com.melodiq.ui.theme.TextPrimary
import com.melodiq.ui.theme.White20

enum class ButtonStyle { Filled, Tonal, Outlined }

/** Round icon-only button (play, skip, favourite, close …) with a ripple and an accessibility label. */
@Composable
fun IconActionButton(
    @DrawableRes icon: Int,
    contentDescription: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    tint: Color = TextPrimary,
    containerColor: Color = Color.Transparent,
    buttonSize: Dp = 44.dp,
    iconSize: Dp = 22.dp,
    enabled: Boolean = true
) {
    IconButton(
        onClick  = onClick,
        enabled  = enabled,
        modifier = modifier
            .size(buttonSize)
            .background(containerColor, CircleShape)
    ) {
        VectorIcon(
            id                 = icon,
            tint               = tint,
            size               = iconSize,
            contentDescription = contentDescription
        )
    }
}

/** Labelled button with an optional leading vector icon. Three looks: filled, tonal, outlined. */
@Composable
fun MelodiqButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    @DrawableRes icon: Int? = null,
    style: ButtonStyle = ButtonStyle.Filled,
    accent: Color = PrimaryPurple,
    enabled: Boolean = true
) {
    val shape   = RoundedCornerShape(14.dp)
    val padding = PaddingValues(horizontal = 20.dp, vertical = 12.dp)

    val content: @Composable RowScope.() -> Unit = {
        if (icon != null) {
            VectorIcon(id = icon, size = 18.dp)
            Spacer(Modifier.width(8.dp))
        }
        Text(text, style = MaterialTheme.typography.labelLarge)
    }

    when (style) {
        ButtonStyle.Filled -> Button(
            onClick        = onClick,
            modifier       = modifier,
            enabled        = enabled,
            shape          = shape,
            contentPadding = padding,
            colors         = ButtonDefaults.buttonColors(
                containerColor = accent,
                contentColor   = Color.White
            ),
            content        = content
        )
        ButtonStyle.Tonal -> FilledTonalButton(
            onClick        = onClick,
            modifier       = modifier,
            enabled        = enabled,
            shape          = shape,
            contentPadding = padding,
            colors         = ButtonDefaults.filledTonalButtonColors(
                containerColor = accent.copy(alpha = 0.18f),
                contentColor   = TextPrimary
            ),
            content        = content
        )
        ButtonStyle.Outlined -> OutlinedButton(
            onClick        = onClick,
            modifier       = modifier,
            enabled        = enabled,
            shape          = shape,
            contentPadding = padding,
            border         = BorderStroke(1.dp, White20),
            colors         = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimary),
            content        = content
        )
    }
}
