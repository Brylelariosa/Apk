package com.melodiq.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.melodiq.ui.theme.AccentViolet
import com.melodiq.ui.theme.PrimaryPurple
import com.melodiq.ui.theme.TextMuted
import com.melodiq.ui.theme.TextPrimary
import com.melodiq.ui.theme.TextSecondary
import com.melodiq.ui.theme.White10
import com.melodiq.ui.theme.White20

/*
 * Small building blocks for the Settings screen. Every row follows the same pattern:
 * it shows the stored value and reports changes through one callback, so a row never keeps its
 * own copy of the setting (sliders only hold the thumb position while it is being dragged).
 */

/** A titled group of rows inside one glass card. */
@Composable
fun SettingsSection(
    title: String,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(
            text          = title.uppercase(),
            color         = AccentViolet,
            style         = MaterialTheme.typography.labelMedium,
            letterSpacing = 1.5.sp,
            modifier      = Modifier.padding(start = 8.dp, bottom = 8.dp)
        )
        GlassCard(Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.padding(vertical = 8.dp),
                content  = content
            )
        }
    }
}

@Composable
fun SwitchRow(
    title: String,
    checked: Boolean,
    onChange: (Boolean) -> Unit,
    subtitle: String? = null
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onChange(!checked) }
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = TextPrimary, style = MaterialTheme.typography.bodyLarge)
            if (subtitle != null) {
                Text(subtitle, color = TextSecondary, style = MaterialTheme.typography.bodySmall)
            }
        }
        Switch(
            checked         = checked,
            onCheckedChange = onChange,
            colors          = SwitchDefaults.colors(
                checkedThumbColor    = Color.White,
                checkedTrackColor    = PrimaryPurple,
                uncheckedThumbColor  = TextSecondary,
                uncheckedTrackColor  = White20,
                uncheckedBorderColor = Color.Transparent
            )
        )
    }
}

/**
 * A slider that shows [value]. While the thumb is held it follows the finger; the new value is
 * reported once, when the finger is lifted ([onCommit]), so nothing is written on every pixel.
 */
@Composable
fun SliderRow(
    title: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    valueLabel: (Float) -> String,
    onCommit: (Float) -> Unit,
    steps: Int = 0
) {
    // restarts from the stored value whenever it changes; holds the thumb position in between
    var local by remember(value) { mutableStateOf(value) }
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text     = title,
                color    = TextPrimary,
                style    = MaterialTheme.typography.bodyLarge,
                modifier = Modifier.weight(1f)
            )
            Text(valueLabel(local), color = AccentViolet, style = MaterialTheme.typography.bodyMedium)
        }
        Slider(
            value                 = local,
            onValueChange         = { local = it },
            onValueChangeFinished = { onCommit(local) },
            valueRange            = range,
            steps                 = steps,
            colors                = SliderDefaults.colors(
                thumbColor         = PrimaryPurple,
                activeTrackColor   = PrimaryPurple,
                inactiveTrackColor = White20
            )
        )
    }
}

/** One option out of several, shown as a row of chips. */
@Composable
fun <T> ChoiceRow(
    title: String,
    options: List<T>,
    selected: T,
    label: (T) -> String,
    onSelect: (T) -> Unit
) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(title, color = TextPrimary, style = MaterialTheme.typography.bodyLarge)
        Spacer(Modifier.height(8.dp))
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            for (option in options) {
                OptionChip(
                    text     = label(option),
                    selected = option == selected,
                    onClick  = { onSelect(option) }
                )
            }
        }
    }
}

@Composable
fun OptionChip(text: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        text       = text,
        color      = if (selected) Color.White else TextSecondary,
        style      = MaterialTheme.typography.labelLarge,
        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
        modifier   = Modifier
            .clip(RoundedCornerShape(50))
            .background(if (selected) PrimaryPurple.copy(alpha = 0.55f) else White10)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp)
    )
}

/**
 * Colour choice: a row of ready-made colours, optionally "Album" (stored as 0, meaning the colour
 * of the current cover), and a custom colour made with a hue and a brightness slider.
 */
@Composable
fun ColorRow(
    title: String,
    selected: Int,
    onSelect: (Int) -> Unit,
    allowAlbumColor: Boolean = false,
    palette: List<Int> = LyricsColorPalette
) {
    var customOpen by remember { mutableStateOf(false) }
    val hsv = remember(selected) {
        val values = FloatArray(3)
        android.graphics.Color.colorToHSV(selected, values)
        values
    }
    val isCustom = selected != 0 && !palette.contains(selected)

    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(title, color = TextPrimary, style = MaterialTheme.typography.bodyLarge)
        Spacer(Modifier.height(8.dp))
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (allowAlbumColor) {
                OptionChip(text = "Album", selected = selected == 0, onClick = { onSelect(0) })
            }
            for (argb in palette) {
                ColorDot(argb = argb, selected = selected == argb, onClick = { onSelect(argb) })
            }
            OptionChip(
                text     = "Custom",
                selected = isCustom || customOpen,
                onClick  = { customOpen = !customOpen }
            )
        }
        if (customOpen || isCustom) {
            SliderRow(
                title      = "Hue",
                value      = hsv[0],
                range      = 0f..360f,
                valueLabel = { it.toInt().toString() + "°" },
                onCommit   = { hue -> onSelect(hsvToArgb(hue, 0.85f, hsvBrightness(hsv))) }
            )
            SliderRow(
                title      = "Brightness",
                value      = hsvBrightness(hsv),
                range      = 0.3f..1f,
                valueLabel = { (it * 100).toInt().toString() + "%" },
                onCommit   = { brightness -> onSelect(hsvToArgb(hsv[0], 0.85f, brightness)) }
            )
        }
    }
}

/** A custom colour has no brightness yet when it was never chosen: use full brightness then. */
private fun hsvBrightness(hsv: FloatArray): Float = if (hsv[2] < 0.3f) 1f else hsv[2]

private fun hsvToArgb(hue: Float, saturation: Float, brightness: Float): Int =
    android.graphics.Color.HSVToColor(floatArrayOf(hue.coerceIn(0f, 360f), saturation, brightness))

@Composable
private fun ColorDot(argb: Int, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .size(34.dp)
            .clip(CircleShape)
            .background(Color(argb))
            .border(
                width = if (selected) 3.dp else 1.dp,
                color = if (selected) Color.White else White20,
                shape = CircleShape
            )
            .clickable(onClick = onClick)
    ) {}
}

/** Right-aligned "reset" link at the bottom of a section. */
@Composable
fun ResetRow(text: String, onReset: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp),
        horizontalArrangement = Arrangement.End
    ) {
        TextButton(onClick = onReset) { Text(text, color = TextMuted) }
    }
}
