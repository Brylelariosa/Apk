package com.melodiq.crash

import kotlin.concurrent.thread

/**
 * Reads the tail of this app's own logcat. No permission is needed: an app can always read its
 * own log lines. The read is limited in time, so it is safe to call from a crash handler.
 */
internal object LogcatDump {

    fun read(maxLines: Int = 300, timeoutMs: Long = 1_500L): String {
        val process = ProcessBuilder("logcat", "-d", "-v", "threadtime", "-t", maxLines.toString())
            .redirectErrorStream(true)
            .start()

        val output = StringBuffer()
        val reader = thread(isDaemon = true, name = "melodiq-logcat") {
            try {
                process.inputStream.bufferedReader().useLines { lines ->
                    lines.forEach { line -> output.append(line).append('\n') }
                }
            } catch (ignored: Exception) {
                // The stream is closed by destroy() below; whatever was read so far is kept.
            }
        }
        reader.join(timeoutMs)
        process.destroy()

        return output.toString().ifBlank { "(logcat returned nothing)" }
    }
}
