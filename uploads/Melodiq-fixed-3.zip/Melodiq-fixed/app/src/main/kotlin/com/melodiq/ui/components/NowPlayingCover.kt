package com.melodiq.ui.components

import android.net.Uri
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import com.melodiq.data.model.CoverMotion
import com.melodiq.data.model.CoverStyle
import com.melodiq.data.model.LookSettings
import kotlin.math.sin

/**
 * The album cover on Now Playing.
 *
 * Instead of the old always-spinning record it eases up to full size when music plays and sinks
 * back when paused. On top of that the user can pick a motion (breathe, float, spin or none) and
 * a soft halo in the album colour. All motion is driven by one float that only the graphics layer
 * reads (no recomposition per frame) and it stops while paused.
 */
@Composable
fun NowPlayingCover(
    artworkUri: Uri?,
    isPlaying: Boolean,
    look: LookSettings,
    glowColor: Color,
    modifier: Modifier = Modifier
) {
    val motion = look.coverMotion
    val speed = look.animationSpeed
    val moving = isPlaying && motion != CoverMotion.NONE

    val phase = remember { mutableFloatStateOf(0f) }
    LaunchedEffect(moving, speed) {
        if (!moving) return@LaunchedEffect
        var last = withFrameNanos { it }
        while (true) {
            val now = withFrameNanos { it }
            phase.floatValue += (now - last) / 1_000_000_000f * speed
            last = now
        }
    }

    val restScale = animateFloatAsState(
        targetValue   = if (isPlaying) 1f else 0.9f,
        animationSpec = spring(dampingRatio = 0.75f, stiffness = Spring.StiffnessLow),
        label         = "cover_rest_scale"
    )
    val glowLevel = animateFloatAsState(
        targetValue   = if (isPlaying) 1f else 0.45f,
        animationSpec = tween(600),
        label         = "cover_glow_level"
    )
    val shape = if (look.coverStyle == CoverStyle.CIRCLE) CircleShape else RoundedCornerShape(28.dp)

    BoxWithConstraints(modifier = modifier, contentAlignment = Alignment.Center) {
        val halo = 28.dp
        val coverSize = maxOf(
            120.dp,
            minOf(look.coverSizeDp.dp, maxWidth - halo * 2, maxHeight - halo * 2)
        )

        Box(
            modifier = Modifier
                .size(coverSize)
                .graphicsLayer {
                    val p = phase.floatValue
                    var scale = restScale.value
                    if (motion == CoverMotion.BREATHE) scale *= 1f + 0.03f * sin(p * 1.6f)
                    scaleX = scale
                    scaleY = scale
                    if (motion == CoverMotion.SPIN) rotationZ = p * 18f
                    if (motion == CoverMotion.FLOAT) translationY = sin(p * 1.4f) * 6.dp.toPx()
                }
                .drawBehind {
                    if (!look.coverGlow) return@drawBehind
                    val half = size.minDimension / 2f
                    val reach = half + halo.toPx()
                    val breath = if (motion == CoverMotion.BREATHE) 0.85f + 0.15f * sin(phase.floatValue * 1.6f) else 0.92f
                    val strong = glowColor.copy(alpha = (0.50f * breath * glowLevel.value).coerceIn(0f, 1f))
                    drawCircle(
                        brush = Brush.radialGradient(
                            0f to strong,
                            (half / reach) to strong,
                            1f to Color.Transparent,
                            center = center,
                            radius = reach
                        ),
                        radius = reach,
                        center = center
                    )
                }
        ) {
            ArtworkImage(
                uri      = artworkUri,
                shape    = shape,
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}
