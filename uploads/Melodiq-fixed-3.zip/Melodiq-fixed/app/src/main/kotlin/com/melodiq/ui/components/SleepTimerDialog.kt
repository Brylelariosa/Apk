package com.melodiq.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.melodiq.R
import com.melodiq.data.model.SleepTimer
import com.melodiq.ui.theme.Divider
import com.melodiq.ui.theme.PrimaryPurple
import com.melodiq.ui.theme.SurfaceCard
import com.melodiq.ui.theme.TextSecondary
import com.melodiq.util.TimeFormatter
import kotlinx.coroutines.delay

@Composable
fun SleepTimerDialog(
    timer: SleepTimer?,
    onDismiss: () -> Unit,
    onSetTimer: (Int) -> Unit,
    onCancelTimer: () -> Unit
) {
    val options = listOf(5, 10, 15, 30, 45, 60, 90)

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor   = SurfaceCard,
        icon  = { VectorIcon(id = R.drawable.ic_sleep, tint = PrimaryPurple, size = 28.dp) },
        title = { Text("Sleep timer") },
        text  = {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                if (timer != null) {
                    SleepCountdown(timer)
                    Spacer(Modifier.height(12.dp))
                    MelodiqButton(
                        text    = "Cancel timer",
                        onClick = onCancelTimer,
                        icon    = R.drawable.ic_close,
                        style   = ButtonStyle.Outlined
                    )
                    HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp), color = Divider)
                }
                Text(
                    "Pause playback after",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
                Spacer(Modifier.height(8.dp))
                options.chunked(4).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { minutes ->
                            FilterChip(
                                selected = timer?.durationMinutes == minutes,
                                onClick  = { onSetTimer(minutes) },
                                label    = { Text(TimeFormatter.formatMinutes(minutes)) }
                            )
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        }
    )
}

@Composable
private fun SleepCountdown(timer: SleepTimer) {
    val remainingMs by produceState(initialValue = timer.remainingMs.coerceAtLeast(0L), key1 = timer) {
        while (true) {
            value = timer.remainingMs.coerceAtLeast(0L)
            delay(1_000L)
        }
    }
    Text(
        text  = "Pausing in ${TimeFormatter.formatMs(remainingMs)}",
        style = MaterialTheme.typography.titleMedium,
        color = PrimaryPurple
    )
}
