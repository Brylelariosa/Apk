package com.melodiq.overlay

import android.app.Activity
import android.app.Application
import android.os.Bundle
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Tells whether one of Melodiq's own screens is visible. The floating lyrics hide while it is,
 * because Now Playing already shows them. Install once from [com.melodiq.MelodiqApp].
 */
object AppForeground : Application.ActivityLifecycleCallbacks {

    private var started = 0
    private var installed = false

    private val _inForeground = MutableStateFlow(false)
    val inForeground: StateFlow<Boolean> = _inForeground.asStateFlow()

    fun install(application: Application) {
        if (installed) return
        installed = true
        application.registerActivityLifecycleCallbacks(this)
    }

    override fun onActivityStarted(activity: Activity) {
        started++
        _inForeground.value = true
    }

    override fun onActivityStopped(activity: Activity) {
        if (started > 0) started--
        _inForeground.value = started > 0
    }

    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) = Unit
    override fun onActivityResumed(activity: Activity) = Unit
    override fun onActivityPaused(activity: Activity) = Unit
    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) = Unit
    override fun onActivityDestroyed(activity: Activity) = Unit
}
