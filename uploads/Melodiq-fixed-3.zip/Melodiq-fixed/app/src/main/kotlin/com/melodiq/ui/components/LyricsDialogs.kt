package com.melodiq.ui.components

import androidx.annotation.DrawableRes
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.melodiq.R
import com.melodiq.data.model.LyricsCandidate
import com.melodiq.ui.theme.AccentViolet
import com.melodiq.ui.theme.Divider
import com.melodiq.ui.theme.PrimaryPurple
import com.melodiq.ui.theme.SurfaceCard
import com.melodiq.ui.theme.TextMuted
import com.melodiq.ui.theme.TextPrimary
import com.melodiq.ui.theme.TextSecondary
import com.melodiq.ui.viewmodel.VersionsUiState
import java.util.Locale

private const val OFFSET_STEP_MS = 100L
private const val OFFSET_LIMIT_MS = 10_000L

@Composable
private fun lyricsFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor   = PrimaryPurple,
    unfocusedBorderColor = Divider,
    cursorColor          = PrimaryPurple,
    focusedTextColor     = TextPrimary,
    unfocusedTextColor   = TextPrimary,
    focusedLabelColor    = PrimaryPurple,
    unfocusedLabelColor  = TextSecondary
)

// ── Options ───────────────────────────────────────────────────────────────────

/** Everything the user can do about the lyrics of the current song. */
@Composable
fun LyricsOptionsDialog(
    offsetMs: Long,
    isCustom: Boolean,
    onDismiss: () -> Unit,
    onChooseVersion: () -> Unit,
    onEdit: () -> Unit,
    onImport: () -> Unit,
    onReset: () -> Unit,
    onOffsetChange: (Long) -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(24.dp), color = SurfaceCard) {
            Column(Modifier.padding(vertical = 16.dp)) {
                Text(
                    text     = "Lyrics",
                    style    = MaterialTheme.typography.titleLarge,
                    color    = TextPrimary,
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
                )
                OptionRow(
                    icon     = R.drawable.ic_list,
                    title    = "Choose another version",
                    subtitle = "See every version found online and pick the full one",
                    onClick  = onChooseVersion
                )
                OptionRow(
                    icon     = R.drawable.ic_edit,
                    title    = "Edit or paste lyrics",
                    subtitle = "Type, paste or fix the lyrics yourself",
                    onClick  = onEdit
                )
                OptionRow(
                    icon     = R.drawable.ic_upload,
                    title    = "Import an .lrc or .txt file",
                    subtitle = "Use a lyrics file from your phone",
                    onClick  = onImport
                )
                if (isCustom) {
                    OptionRow(
                        icon     = R.drawable.ic_refresh,
                        title    = "Back to automatic lyrics",
                        subtitle = "Forget your choice for this song",
                        onClick  = onReset
                    )
                }

                OffsetRow(offsetMs = offsetMs, onOffsetChange = onOffsetChange)

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) { Text("Close", color = TextSecondary) }
                }
            }
        }
    }
}

@Composable
private fun OptionRow(
    @DrawableRes icon: Int,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 24.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        VectorIcon(id = icon, tint = AccentViolet, size = 24.dp)
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = TextPrimary, style = MaterialTheme.typography.bodyLarge)
            Text(subtitle, color = TextSecondary, style = MaterialTheme.typography.bodySmall)
        }
    }
}

/** Shifts every timestamp: lyrics that show up too early need "Later", too late need "Earlier". */
@Composable
private fun OffsetRow(offsetMs: Long, onOffsetChange: (Long) -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text     = "Sync timing",
                color    = TextPrimary,
                style    = MaterialTheme.typography.bodyLarge,
                modifier = Modifier.weight(1f)
            )
            Text(
                text  = formatOffset(offsetMs),
                color = if (offsetMs == 0L) TextSecondary else AccentViolet,
                style = MaterialTheme.typography.bodyMedium
            )
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            IconActionButton(
                icon               = R.drawable.ic_remove,
                contentDescription = "Show lyrics earlier",
                onClick            = { onOffsetChange((offsetMs - OFFSET_STEP_MS).coerceAtLeast(-OFFSET_LIMIT_MS)) },
                tint               = TextPrimary,
                containerColor     = Color.White.copy(alpha = 0.08f),
                buttonSize         = 40.dp,
                iconSize           = 20.dp
            )
            Text("Earlier", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.weight(1f))
            if (offsetMs != 0L) {
                TextButton(onClick = { onOffsetChange(0L) }) { Text("Reset", color = AccentViolet) }
            }
            Text("Later", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
            IconActionButton(
                icon               = R.drawable.ic_add,
                contentDescription = "Show lyrics later",
                onClick            = { onOffsetChange((offsetMs + OFFSET_STEP_MS).coerceAtMost(OFFSET_LIMIT_MS)) },
                tint               = TextPrimary,
                containerColor     = Color.White.copy(alpha = 0.08f),
                buttonSize         = 40.dp,
                iconSize           = 20.dp
            )
        }
    }
}

private fun formatOffset(offsetMs: Long): String =
    if (offsetMs == 0L) "In sync" else String.format(Locale.US, "%+.1f s", offsetMs / 1000f)

// ── Editor ────────────────────────────────────────────────────────────────────

/**
 * Free-form lyrics editor. Text with [mm:ss.xx] timestamps becomes synced lyrics, anything else is
 * shown as plain lyrics. Saving empty text goes back to the automatic lyrics.
 */
@Composable
fun LyricsEditorDialog(
    initialText: String,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit
) {
    // Deliberately not rememberSaveable: lyrics can be long and would overflow the saved-state bundle.
    var text by remember { mutableStateOf(initialText) }
    val clipboard = LocalClipboardManager.current

    Dialog(
        onDismissRequest = onDismiss,
        properties       = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .fillMaxHeight(0.88f),
            shape = RoundedCornerShape(24.dp),
            color = SurfaceCard
        ) {
            Column(Modifier.padding(20.dp)) {
                Text("Edit lyrics", style = MaterialTheme.typography.titleLarge, color = TextPrimary)
                Spacer(Modifier.height(4.dp))
                Text(
                    text  = "Paste or type the lyrics. Lines that start with a time like [01:23.45] stay synced; " +
                        "plain text is shown as normal lyrics.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value         = text,
                    onValueChange = { text = it },
                    placeholder   = { Text("Lyrics…", color = TextMuted) },
                    colors        = lyricsFieldColors(),
                    modifier      = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                )
                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = {
                        val pasted = clipboard.getText()?.text
                        if (!pasted.isNullOrEmpty()) text = pasted
                    }) { Text("Paste", color = AccentViolet) }
                    TextButton(onClick = { text = "" }) { Text("Clear", color = TextSecondary) }
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = onDismiss) { Text("Cancel", color = TextSecondary) }
                    MelodiqButton(
                        text    = "Save",
                        onClick = { onSave(text) },
                        icon    = R.drawable.ic_check
                    )
                }
            }
        }
    }
}

// ── Version picker ────────────────────────────────────────────────────────────

/**
 * Lists every version of the song found online. Different uploads of the same song often differ:
 * one is complete, another stops after the second verse. The user picks the right one.
 */
@Composable
fun LyricsVersionsDialog(
    initialTitle: String,
    initialArtist: String,
    state: VersionsUiState,
    onSearch: (title: String, artist: String) -> Unit,
    onPick: (LyricsCandidate) -> Unit,
    onDismiss: () -> Unit
) {
    var title  by rememberSaveable { mutableStateOf(initialTitle) }
    var artist by rememberSaveable { mutableStateOf(initialArtist) }
    val canSearch = title.isNotBlank()

    // search right away with what we already know about the song
    LaunchedEffect(Unit) { onSearch(initialTitle, initialArtist) }

    Dialog(
        onDismissRequest = onDismiss,
        properties       = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .fillMaxHeight(0.9f),
            shape = RoundedCornerShape(24.dp),
            color = SurfaceCard
        ) {
            Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text     = "Choose lyrics",
                        style    = MaterialTheme.typography.titleLarge,
                        color    = TextPrimary,
                        modifier = Modifier
                            .weight(1f)
                            .padding(start = 8.dp)
                    )
                    IconActionButton(
                        icon               = R.drawable.ic_close,
                        contentDescription = "Close",
                        onClick            = onDismiss,
                        tint               = TextSecondary,
                        buttonSize         = 44.dp,
                        iconSize           = 22.dp
                    )
                }

                OutlinedTextField(
                    value           = title,
                    onValueChange   = { title = it },
                    label           = { Text("Song title") },
                    singleLine      = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                    colors          = lyricsFieldColors(),
                    modifier        = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value           = artist,
                        onValueChange   = { artist = it },
                        label           = { Text("Artist (optional)") },
                        singleLine      = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { if (canSearch) onSearch(title, artist) }),
                        colors          = lyricsFieldColors(),
                        modifier        = Modifier.weight(1f)
                    )
                    Spacer(Modifier.width(8.dp))
                    MelodiqButton(
                        text    = "Search",
                        onClick = { onSearch(title, artist) },
                        icon    = R.drawable.ic_search,
                        enabled = canSearch
                    )
                }
                Spacer(Modifier.height(12.dp))

                Box(
                    Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    VersionsContent(state = state, onPick = onPick, onRetry = { onSearch(title, artist) })
                }
            }
        }
    }
}

@Composable
private fun VersionsContent(
    state: VersionsUiState,
    onPick: (LyricsCandidate) -> Unit,
    onRetry: () -> Unit
) {
    when (state) {
        is VersionsUiState.Idle -> Unit
        is VersionsUiState.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = PrimaryPurple, modifier = Modifier.size(32.dp))
        }
        is VersionsUiState.Empty -> CenteredNote(
            text = "No lyrics found for these words. Check the spelling or try the title only."
        )
        is VersionsUiState.Offline -> Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text  = "Can't reach the lyrics service. Check your connection.",
                color = TextSecondary,
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.height(12.dp))
            MelodiqButton(text = "Try again", onClick = onRetry, icon = R.drawable.ic_refresh)
        }
        is VersionsUiState.Results -> LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(state.items, key = { it.id }) { candidate ->
                CandidateCard(candidate = candidate, onClick = { onPick(candidate) })
            }
        }
    }
}

@Composable
private fun CenteredNote(text: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(
            text  = text,
            color = TextSecondary,
            style = MaterialTheme.typography.bodyMedium
        )
    }
}

@Composable
private fun CandidateCard(candidate: LyricsCandidate, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color.White.copy(alpha = 0.06f))
            .clickable(onClick = onClick)
            .padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text     = headlineOf(candidate),
                color    = TextPrimary,
                style    = MaterialTheme.typography.bodyMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            if (candidate.isBestMatch) {
                Text(
                    text     = "Best match",
                    color    = Color.White,
                    style    = MaterialTheme.typography.labelSmall,
                    modifier = Modifier
                        .padding(start = 8.dp)
                        .clip(RoundedCornerShape(50))
                        .background(PrimaryPurple.copy(alpha = 0.7f))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                )
            }
        }
        Text(
            text     = detailsOf(candidate),
            color    = TextSecondary,
            style    = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(top = 2.dp)
        )
        if (candidate.preview.isNotBlank()) {
            Text(
                text     = candidate.preview,
                color    = TextMuted,
                style    = MaterialTheme.typography.bodySmall,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}

private fun headlineOf(c: LyricsCandidate): String {
    val title = c.title.ifBlank { "Untitled" }
    return if (c.artist.isBlank()) title else title + " — " + c.artist
}

private fun detailsOf(c: LyricsCandidate): String {
    val parts = ArrayList<String>()
    if (c.album.isNotBlank()) parts.add(c.album)
    val duration = c.durationSec
    if (duration != null && duration > 0) {
        val diff = c.durationDiffSec
        val length = String.format(Locale.US, "%d:%02d", duration / 60, duration % 60)
        parts.add(if (diff != null && diff > 0) length + " (" + diff + " s off)" else length)
    }
    parts.add(
        if (c.syncedLines > 0) "Synced, " + c.syncedLines + " lines"
        else "Plain, " + c.plainLines + " lines"
    )
    return parts.joinToString("  ·  ")
}
