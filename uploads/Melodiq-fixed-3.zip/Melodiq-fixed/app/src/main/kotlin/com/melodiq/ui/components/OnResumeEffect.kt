package com.melodiq.ui.components

import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.melodiq.R
import com.melodiq.ui.theme.AccentViolet
import com.melodiq.ui.theme.PrimaryPurple
import com.melodiq.ui.theme.SurfaceCard
import com.melodiq.ui.theme.TextSecondary

/** Runs [onResume] every time the screen comes back to the foreground (e.g. from a system settings page). */
@Composable
fun OnResumeEffect(onResume: () -> Unit) {
    val owner = LocalLifecycleOwner.current
    val latest by rememberUpdatedState(onResume)
    DisposableEffect(owner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) latest()
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer) }
    }
}

/** Explains why Melodiq needs "Display over other apps" before sending the user to the system screen. */
@Composable
fun OverlayPermissionDialog(
    onDismiss: () -> Unit,
    onOpenSettings: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor   = SurfaceCard,
        icon  = { VectorIcon(id = R.drawable.ic_floating, tint = PrimaryPurple, size = 28.dp) },
        title = { Text("Allow floating lyrics") },
        text  = {
            Text(
                "Floating lyrics are shown on top of other apps, so Android needs your permission. " +
                    "On the next screen, switch on \"Allow display over other apps\" for Melodiq, then come back."
            )
        },
        confirmButton = {
            TextButton(onClick = onOpenSettings) { Text("Open settings", color = AccentViolet) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Not now", color = TextSecondary) }
        }
    )
}
