package com.melodiq.crash

import android.app.ActivityManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.os.Build
import android.os.SystemClock
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Turns "something went wrong" into the plain-text report that ends up in the Download folder. */
internal class CrashReportBuilder(private val context: Context) {

    fun fatal(timeMs: Long, thread: Thread, error: Throwable): String = buildString {
        appendHeader(ReportKind.FATAL, timeMs)
        appendLine("Thread:     ${thread.name} (id ${thread.id})")
        appendLine("Root cause: ${rootCauseOf(error)}")
        appendDevice()
        appendLiveState()
        appendSection("EXCEPTION", error.stackTraceToString())
        appendSection("RECENT EVENTS (oldest first)", recentEvents())
        appendSection("LOGCAT (last lines)", guarded { LogcatDump.read() })
    }

    fun nonFatal(timeMs: Long, thread: Thread, label: String, error: Throwable): String = buildString {
        appendHeader(ReportKind.NON_FATAL, timeMs)
        appendLine("What:       $label")
        appendLine("Thread:     ${thread.name} (id ${thread.id})")
        appendLine("Root cause: ${rootCauseOf(error)}")
        appendDevice()
        appendLiveState()
        appendSection("EXCEPTION", error.stackTraceToString())
        appendSection("RECENT EVENTS (oldest first)", recentEvents())
        appendSection("LOGCAT (last lines)", guarded { LogcatDump.read() })
    }

    /** [details] is what Android recorded about how the earlier process ended. */
    fun previousRun(timeMs: Long, details: String): String = buildString {
        appendHeader(ReportKind.PREVIOUS_RUN, timeMs)
        appendLine("Note:       The app was stopped without a Java exception (native crash, ANR or killed by the system).")
        appendDevice()
        appendSection("HOW THE PREVIOUS RUN ENDED", details)
        appendSection("LOGCAT (last lines, may include the end of the previous run)", guarded { LogcatDump.read(maxLines = 500) })
    }

    // ── Sections ─────────────────────────────────────────────────────────────

    private fun StringBuilder.appendHeader(kind: ReportKind, timeMs: Long) {
        appendLine("Melodiq ${kind.title}")
        appendLine("=".repeat(48))
        appendLine("Time:       ${formatTime(timeMs)}")
    }

    private fun StringBuilder.appendDevice() {
        appendLine("App:        ${guarded { appVersion() }}")
        appendLine("Android:    ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}), security patch ${Build.VERSION.SECURITY_PATCH}")
        appendLine("Device:     ${Build.MANUFACTURER} ${Build.MODEL} (${Build.DEVICE}), ABI ${Build.SUPPORTED_ABIS.joinToString()}")
    }

    /** Facts about the process that is running right now. Left out of previous-run reports. */
    private fun StringBuilder.appendLiveState() {
        val visibility = if (AppVisibility.isInForeground()) "in the foreground" else "in the background"
        appendLine("App state:  $visibility")
        appendLine("Uptime:     ${guarded { processUptime() }}")
        appendLine("Memory:     ${guarded { memorySummary() }}")
    }

    private fun StringBuilder.appendSection(title: String, body: String) {
        appendLine()
        appendLine("----- $title -----")
        appendLine(body.trimEnd())
    }

    // ── Facts ────────────────────────────────────────────────────────────────

    @Suppress("DEPRECATION")
    private fun appVersion(): String {
        val info = context.packageManager.getPackageInfo(context.packageName, 0)
        val code = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) info.longVersionCode else info.versionCode.toLong()
        val debuggable = (context.applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0
        val buildType = if (debuggable) "debug build" else "release build"
        return "${info.versionName} ($code), $buildType"
    }

    private fun processUptime(): String {
        val ms = SystemClock.elapsedRealtime() - android.os.Process.getStartElapsedRealtime()
        return "${ms / 1000} s since the process started"
    }

    private fun memorySummary(): String {
        val runtime = Runtime.getRuntime()
        val heapUsedMb = (runtime.totalMemory() - runtime.freeMemory()) / BYTES_PER_MB
        val heapMaxMb = runtime.maxMemory() / BYTES_PER_MB

        val system = ActivityManager.MemoryInfo()
        (context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(system)

        return "app heap $heapUsedMb of $heapMaxMb MB, " +
            "device RAM free ${system.availMem / BYTES_PER_MB} of ${system.totalMem / BYTES_PER_MB} MB, " +
            "low-memory=${system.lowMemory}"
    }

    private fun recentEvents(): String =
        AppLog.snapshot().joinToString("\n").ifBlank { "(nothing recorded)" }

    private fun rootCauseOf(error: Throwable): String {
        val root = generateSequence(error) { current -> current.cause?.takeIf { cause -> cause !== current } }
            .take(MAX_CAUSE_DEPTH)
            .last()
        return "${root.javaClass.name}: ${root.message}"
    }

    private fun formatTime(timeMs: Long): String =
        SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS Z", Locale.US).format(Date(timeMs))

    /** One failing section must never cost the whole report. */
    private inline fun guarded(block: () -> String): String =
        try {
            block()
        } catch (failure: Throwable) {
            "(unavailable: ${failure.javaClass.simpleName}: ${failure.message})"
        }

    private companion object {
        const val BYTES_PER_MB = 1024L * 1024L
        const val MAX_CAUSE_DEPTH = 20
    }
}
