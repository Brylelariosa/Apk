package com.melodiq.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.melodiq.R
import com.melodiq.data.model.Song
import com.melodiq.ui.theme.AccentPink
import com.melodiq.ui.theme.PrimaryPurple
import com.melodiq.ui.theme.TextMuted
import com.melodiq.ui.theme.TextPrimary
import com.melodiq.ui.theme.TextSecondary
import com.melodiq.util.TimeFormatter

/**
 * One row in a song list.
 * [isCurrent] = this is the loaded song (title highlighted, equalizer shown on the cover);
 * [isPlaying] = it is actually producing sound (bars animate, otherwise they freeze).
 */
@Composable
fun SongItem(
    song: Song,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    isCurrent: Boolean = false,
    isPlaying: Boolean = false,
    onFavoriteClick: (() -> Unit)? = null,
    onMoreClick: (() -> Unit)? = null
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(52.dp)
                .clip(RoundedCornerShape(10.dp))
        ) {
            ArtworkImage(
                uri      = song.artworkUri,
                modifier = Modifier.fillMaxSize()
            )
            if (isCurrent) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.45f)),
                    contentAlignment = Alignment.Center
                ) {
                    EqualizerBars(
                        isAnimating = isPlaying,
                        modifier    = Modifier.size(20.dp)
                    )
                }
            }
        }

        Spacer(Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text     = song.title,
                style    = MaterialTheme.typography.titleSmall,
                color    = if (isCurrent) PrimaryPurple else TextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(2.dp))
            Text(
                text     = "${song.artist} • ${TimeFormatter.formatMs(song.duration)}",
                style    = MaterialTheme.typography.bodySmall,
                color    = TextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        if (onFavoriteClick != null) {
            IconActionButton(
                icon               = if (song.isFavorite) R.drawable.ic_favorite else R.drawable.ic_favorite_border,
                contentDescription = if (song.isFavorite) "Remove from favorites" else "Add to favorites",
                onClick            = onFavoriteClick,
                tint               = if (song.isFavorite) AccentPink else TextMuted,
                buttonSize         = 40.dp,
                iconSize           = 20.dp
            )
        }

        if (onMoreClick != null) {
            IconActionButton(
                icon               = R.drawable.ic_more_vert,
                contentDescription = "More options",
                onClick            = onMoreClick,
                tint               = TextMuted,
                buttonSize         = 40.dp,
                iconSize           = 20.dp
            )
        }
    }
}
