# Changelog

## 1.4
### Added
- **Floating lyrics.** The current lyric line (plus the lines around it) in a small window on top of other
  apps, with a live preview in Settings. Everything about it is adjustable: how many lines (1–5), text size,
  font, weight, alignment, colour, brightness of the other lines, text shadow, background colour / opacity /
  corner radius, window opacity, width, line-change animation (none / fade / slide / pop) and its length,
  song title, playback buttons, "only while playing", "hide while Melodiq is open", and a lock that lets
  touches pass through. Drag it anywhere; the position is remembered. Needs Android's *Display over other
  apps* permission, which the app explains and asks for only when you switch the feature on.
- **Choose another version of the lyrics.** Lists every version found online (best match first, with length,
  line count and a preview) so you can pick the complete one.
- **Edit, paste or import lyrics.** Type or paste lyrics (with `[mm:ss.xx]` timestamps they stay synced), or
  import an `.lrc` / `.txt` file. The choice is kept for that song until you go back to automatic lyrics.
- **Sync timing.** Shift a song's lyrics earlier or later in 0.1 s steps; remembered per song.
- **Settings screen** (gear icon on Home and Now Playing) for the Now Playing look, the in-app lyrics style and
  the floating lyrics. Every change applies immediately.
- Tap a lyric line to jump to it; "Full text" view; optional keep-screen-on while lyrics are open.

### Fixed
- **Shuffle skipped songs and could repeat them.** ExoPlayer's own shuffle put the song you tapped at a random
  place in its order, so with *repeat off* only the songs after that place were ever played. Shuffle now builds
  a proper deck: every song of the queue exactly once, the playing song first, nothing repeats until the whole
  deck is played. Switching shuffle on half-way keeps what was already played behind you and shuffles only the
  rest. With *repeat all*, each new pass is a fresh random order. The *Shuffle* button starts at a random song.
- **Lyrics that stop halfway.** Lookups used to accept the first match, even when it was a cut-short upload.
  They now compare all trusted matches and take the fullest one; if the synced version ends early but the
  plain-text version continues, the missing lines are appended (without highlight). Lyrics that still look
  incomplete show a notice with a shortcut to the version list. Lyrics cached by older versions are fetched again.

### Changed
- **Animation.** The background used to sweep a gradient back and forth (the moving, rotating bands) and the
  cover spun like a record. Now: a calm *Aurora* of soft glows drifting slowly (or *Pulse*, *Still*, *Plain*), and a
  cover that eases to full size while playing, sinks slightly when paused, and *breathes* (or floats / spins /
  stays still — your choice) with an optional halo. All motion freezes while the music is paused, runs at 30 fps and
  is read only by the draw phase, so nothing recomposes per frame. Browsing screens now use a still gradient.
- Lyrics scroll smoothly to the middle of the screen, scale/fade by distance, and stop fighting you while you scroll.
- Lyrics are now owned by `LyricsManager` (one shared copy) instead of the Now Playing screen, so the floating
  window and the screen always agree. The old "Search manually" dialog is replaced by the version list.
- Dependencies: `lifecycle-runtime-ktx` and `savedstate-ktx` are now declared explicitly (already part of the app;
  the floating window needs their view-tree helpers).

## 1.3
### Fixed
- **Crash when tapping a song to play.** As soon as lyrics were found for the song, the app died with
  `PatternSyntaxException: Syntax error in regexp pattern near index 8  \{[^}]*}`. Android's regex engine
  (ICU) rejects an unescaped `}`, which a desktop JVM accepts. The pattern in `LyricsCleanup` now escapes it
  (`\{[^\}]*\}`), and the two neighbouring patterns escape their `]` the same way. Every other regex in the
  project was checked against a real ICU engine and compiles.
- **Lyrics can no longer crash the app.** The lyrics loader only caught `Exception`, so an `Error` (such as a
  class failing to initialise) escaped and killed the whole app. It now catches everything except
  cancellation, saves an error log, and shows a new *Couldn't load lyrics* state with a *Try again* button
  while the music keeps playing. (Before, any unexpected failure was shown as "Can't reach the lyrics
  service", which was misleading.)

### Changed
- The "message + Try again" layout used by the *offline* and *couldn't load* lyrics states is now one shared
  composable instead of two copies.

## 1.1
### Fixed
- **Lyrics never loaded for songs without an artist tag.** MediaStore reports a missing artist as the text
  `<unknown>`; that was sent to the lyrics service as if it were a real artist. Missing tags are now
  recognised, and lyrics are searched by title + length instead (see HOW_IT_WORKS.md §3).
- Lyrics failures caused by being offline were cached as "not found" for a day. Network errors are no
  longer cached and show a *Try again* button.
- **Player stopped responding after leaving Now Playing.** Every screen created its own PlayerViewModel and
  clearing any one of them disconnected the shared player. There is now one PlayerViewModel for the app and the
  controller is never released by a screen.
- Tapping a song before the player service had connected did nothing; the request is now queued.
- Sleep timer restarted the music if it was already paused, and stopped counting when the app was closed.
- Favouriting a song in a list changed the song shown in the mini player.
- Without audio permission the app showed an empty library; it now shows an *Allow access* screen
  (and re-checks when you return from Settings).
- The gradient background recomposed the whole app 60×/second; the song position recomposed every list 5×/second.
  Both are now draw-phase / isolated.

### Changed
- All emoji and text-glyph icons replaced with vector drawables; real buttons everywhere
  (Play all, Shuffle, Scan library, Lyrics, Sleep timer, Try again, Search manually, Allow access).
- Songs without artwork show a music-note cover instead of an empty box.
- Now Playing: lyrics/sleep timer are labelled buttons; the cover stops turning where it is when paused.
- Song rows show an animated equalizer on the current song.
- Scans SD cards too (Android 10+).

### Removed
- `material-icons-extended` dependency (large; every icon is now our own vector) — faster CI builds.
- Unused permissions `SYSTEM_ALERT_WINDOW` and `RECEIVE_BOOT_COMPLETED`.
