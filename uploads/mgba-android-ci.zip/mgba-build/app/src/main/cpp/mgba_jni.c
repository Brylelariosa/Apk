/*
 * mgba_jni.c — JNI bridge between mGBA core and Android/Kotlin.
 *
 * Fixes applied in this revision
 * ───────────────────────────────
 * FIX 1  pthread_mutex_t g_core_mutex protects g_core / g_fb.
 *         The original code had no synchronisation between nativeLoadROM
 *         (background thread) and nativeDestroy (UI thread via onDestroy),
 *         allowing concurrent destroy_core() calls — a double-free / use-
 *         after-free SIGSEGV.  Every JNI function that reads or writes the
 *         globals now takes the mutex.  g_core is only published after
 *         core->reset() completes, so nativeRunFrame never sees a half-
 *         initialised core.
 *
 * FIX 2  mCoreLoadConfig(core)  →  core->loadConfig(core).
 *         mCoreLoadConfig() tries to open $HOME/.config/mgba-android/config.ini.
 *         On Android, HOME / XDG_CONFIG_HOME are unset; VFileOpen() returns
 *         NULL and mCoreLoadConfig() returns false WITHOUT ever calling
 *         core->loadConfig().  Every option written by mCoreConfigLoadDefaults
 *         (skipBios, sampleRate, volume …) was silently discarded and
 *         core->opts stayed zeroed.  core->loadConfig() directly syncs
 *         core->config.opts → core->opts without touching the filesystem.
 *
 * FIX 3  nativeRunFrame pixel copy respects info.stride.
 *         The previous loop used dst[i] with a flat index i = 0 … w*h-1,
 *         treating the bitmap as a packed array.  Android bitmaps may have
 *         per-row padding (stride > width × 4), which caused every row after
 *         the first to be written at the wrong offset — a visible horizontal
 *         shift artefact.  The loop now addresses each row via
 *         (uint8_t*)pixels + row * info.stride.
 */

#include <jni.h>
#include <android/bitmap.h>
#include <android/log.h>
#include <pthread.h>

#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include <mgba/core/core.h>       /* mCoreLoadFile, mCoreInitConfig         */
#include <mgba/core/config.h>     /* mCoreOptions, mCoreConfigLoadDefaults  */
#include <mgba/core/log.h>        /* mLogSetDefaultLogger                   */
/* mColor is typedef uint32_t in every mGBA version.  We define it here
 * directly rather than including <mgba-util/image.h>, which is absent from
 * the mGBA 0.10.3 include tree and causes a fatal compile error.           */
#ifndef mColor
typedef uint32_t mColor;
#endif
#include <mgba/gba/core.h>        /* GBACoreCreate                          */

#define LOG_TAG "mGBA-JNI"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

/* ── Globals — all access must hold g_core_mutex ────────────────────────── */

static pthread_mutex_t g_core_mutex = PTHREAD_MUTEX_INITIALIZER;
static struct mCore   *g_core   = NULL;
static mColor         *g_fb     = NULL;
static int             g_width  = 240;
static int             g_height = 160;

/* ── Logger ─────────────────────────────────────────────────────────────── */

static void jni_log(struct mLogger *logger, int category,
                    enum mLogLevel level, const char *fmt, va_list args)
{
    (void)logger; (void)category; (void)level;
    char buf[512];
    vsnprintf(buf, sizeof(buf), fmt, args);
    LOGI("%s", buf);
}
static struct mLogger g_logger = { .log = jni_log };

/* ── Internal cleanup — CALLER MUST HOLD g_core_mutex ───────────────────── */

static void destroy_core(void)
{
    if (g_core) {
        g_core->deinit(g_core);
        g_core = NULL;
    }
    free(g_fb);
    g_fb = NULL;
}

/* ── nativeLoadROM ──────────────────────────────────────────────────────── */

JNIEXPORT jboolean JNICALL
Java_com_mgba_android_EmulatorEngine_nativeLoadROM(
        JNIEnv *env, jobject thiz, jstring jpath)
{
    /*
     * FIX 1 — tear down any previously loaded core while holding the lock
     * so that concurrent nativeRunFrame / nativeSetKeys calls see a clean
     * NULL and early-return rather than racing on a dangling pointer.
     */
    pthread_mutex_lock(&g_core_mutex);
    destroy_core();
    pthread_mutex_unlock(&g_core_mutex);

    mLogSetDefaultLogger(&g_logger);

    const char *path = (*env)->GetStringUTFChars(env, jpath, NULL);
    if (!path) return JNI_FALSE;
    LOGI("Loading ROM: %s", path);

    /* 1. Create GBA core — GBA-only build; no auto-detect needed */
    struct mCore *core = GBACoreCreate();
    if (!core) {
        LOGE("GBACoreCreate failed");
        (*env)->ReleaseStringUTFChars(env, jpath, path);
        return JNI_FALSE;
    }

    /* 2. Allocate core-internal structures */
    if (!core->init(core)) {
        LOGE("core->init failed");
        core->deinit(core);
        (*env)->ReleaseStringUTFChars(env, jpath, path);
        return JNI_FALSE;
    }

    /*
     * 3. ── REQUIRED ── initialise config BEFORE touching anything else.
     *    Without this call, mCoreLoadFile dereferences uninitialised config
     *    memory → SIGSEGV.  (Original crash; this fix was already present.)
     */
    mCoreInitConfig(core, "mgba-android");

    /*
     * 4. Apply options.
     *
     * FIX 2 — use core->loadConfig(core), NOT mCoreLoadConfig(core).
     *
     * mCoreLoadConfig() tries to open $HOME/.config/mgba-android/config.ini.
     * On Android that path does not exist; VFileOpen() returns NULL and
     * mCoreLoadConfig() returns false WITHOUT calling core->loadConfig().
     * Every value written below by mCoreConfigLoadDefaults() would then be
     * silently ignored (core->opts stays all-zero, skipBios never takes
     * effect at reset time).
     *
     * core->loadConfig() reads directly from core->config.opts and syncs
     * them into core->opts — no filesystem access, always succeeds.
     */
    struct mCoreOptions opts;
    memset(&opts, 0, sizeof(opts));
    opts.skipBios     = true;
    opts.useBios      = false;
    opts.sampleRate   = 44100;
    opts.audioBuffers = 1024;
    opts.volume       = 256;
    mCoreConfigLoadDefaults(&core->config, &opts);
    /* mGBA 0.10.3 changed loadConfig to take an explicit config pointer.
     * Old API: loadConfig(struct mCore*)
     * New API: loadConfig(struct mCore*, const struct mCoreConfig*)        */
    core->loadConfig(core, &core->config);

    /* 5. GBA screen is always 240x160.
     *    baseVideoSize() was removed from struct mCore in mGBA 0.10.3 —
     *    there is no need to query it for a GBA-only build.               */
    const unsigned w = 240, h = 160;

    mColor *fb = (mColor *)calloc((size_t)w * (size_t)h, sizeof(mColor));
    if (!fb) {
        LOGE("framebuffer alloc failed (%ux%u)", w, h);
        core->deinit(core);
        (*env)->ReleaseStringUTFChars(env, jpath, path);
        return JNI_FALSE;
    }
    core->setVideoBuffer(core, fb, (size_t)w);

    /* 6. Load the ROM from the cache-file path we were given */
    if (!mCoreLoadFile(core, path)) {
        LOGE("mCoreLoadFile failed: %s", path);
        free(fb);
        core->deinit(core);
        (*env)->ReleaseStringUTFChars(env, jpath, path);
        return JNI_FALSE;
    }
    (*env)->ReleaseStringUTFChars(env, jpath, path);

    /* 7. Reset into known-good state; now reads synced core->opts */
    core->reset(core);

    /*
     * 8. FIX 1 — publish the new core atomically.
     *    We only set g_core after reset() completes so that nativeRunFrame
     *    never observes a core that has been init()-ed but not yet reset().
     *    g_width / g_height are also updated here under the same lock so
     *    nativeGetWidth / nativeGetHeight are always consistent with g_fb.
     */
    pthread_mutex_lock(&g_core_mutex);
    g_core   = core;
    g_fb     = fb;
    g_width  = (int)w;
    g_height = (int)h;
    pthread_mutex_unlock(&g_core_mutex);

    LOGI("ROM loaded OK — core=%p  %dx%d", (void*)core, (int)w, (int)h);
    return JNI_TRUE;
}

/* ── nativeRunFrame ─────────────────────────────────────────────────────── */

JNIEXPORT void JNICALL
Java_com_mgba_android_EmulatorEngine_nativeRunFrame(
        JNIEnv *env, jobject thiz, jobject bitmap)
{
    /* FIX 1 — hold the lock for the entire frame so nativeDestroy cannot
     * free g_core / g_fb under us.                                       */
    pthread_mutex_lock(&g_core_mutex);
    if (!g_core || !g_fb) {
        pthread_mutex_unlock(&g_core_mutex);
        return;
    }

    /* Expose env to the SIO driver callbacks that fire inside runFrame */
    g_tl_env = env;
    g_core->runFrame(g_core);
    g_tl_env = NULL;

    /*
     * Convert mGBA native pixel format → Android ARGB_8888.
     *   mGBA GBA output: 0x00BBGGRR  (XBGR, X = unused/0)
     *   bswap32(0x00BBGGRR) = 0xRRGGBB00
     *   >> 8               = 0x00RRGGBB
     *   | 0xFF000000       = 0xFFRRGGBB   (Android ARGB_8888, fully opaque) ✓
     *
     * FIX 3 — address each destination row via info.stride rather than a
     * flat index.  When stride > width × 4 (padding for alignment), the
     * old loop wrote row N into the padding bytes of row N-1, causing a
     * one-row horizontal shift that accumulated across the whole screen.
     */
    AndroidBitmapInfo info;
    void *pixels = NULL;
    if (AndroidBitmap_getInfo(env, bitmap, &info) < 0) {
        pthread_mutex_unlock(&g_core_mutex);
        return;
    }
    if (AndroidBitmap_lockPixels(env, bitmap, &pixels) < 0) {
        pthread_mutex_unlock(&g_core_mutex);
        return;
    }

    /* mGBA 0.10.3 software renderer outputs XRGB8888 (0x00RRGGBB).
     * Android Bitmap ARGB_8888 is also 0xAARRGGBB.
     * Channel order already matches — only set alpha to 0xFF.
     *
     * The previous bswap formula assumed XBGR which swaps R↔B:
     *   red pixels appeared blue, blue appeared red.                      */
    for (int row = 0; row < g_height; row++) {
        const mColor *srcRow = g_fb + (size_t)row * (size_t)g_width;
        uint32_t     *dstRow = (uint32_t *)((uint8_t *)pixels
                                            + (size_t)row * info.stride);
        for (int col = 0; col < g_width; col++) {
            dstRow[col] = (srcRow[col] & 0x00FFFFFFu) | 0xFF000000u;
        }
    }

    AndroidBitmap_unlockPixels(env, bitmap);
    pthread_mutex_unlock(&g_core_mutex);
}

/* ── nativeSetKeys ──────────────────────────────────────────────────────── */

JNIEXPORT void JNICALL
Java_com_mgba_android_EmulatorEngine_nativeSetKeys(
        JNIEnv *env, jobject thiz, jint keys)
{
    pthread_mutex_lock(&g_core_mutex);
    if (g_core) g_core->setKeys(g_core, (uint32_t)keys);
    pthread_mutex_unlock(&g_core_mutex);
}

/* ── nativeGetWidth / nativeGetHeight ───────────────────────────────────── */

JNIEXPORT jint JNICALL
Java_com_mgba_android_EmulatorEngine_nativeGetWidth(JNIEnv *env, jobject thiz)
{
    pthread_mutex_lock(&g_core_mutex);
    jint w = (jint)g_width;
    pthread_mutex_unlock(&g_core_mutex);
    return w;
}

JNIEXPORT jint JNICALL
Java_com_mgba_android_EmulatorEngine_nativeGetHeight(JNIEnv *env, jobject thiz)
{
    pthread_mutex_lock(&g_core_mutex);
    jint h = (jint)g_height;
    pthread_mutex_unlock(&g_core_mutex);
    return h;
}

/* ── nativeDestroy ──────────────────────────────────────────────────────── */

JNIEXPORT void JNICALL
Java_com_mgba_android_EmulatorEngine_nativeDestroy(JNIEnv *env, jobject thiz)
{
    /* FIX 1 — mutex ensures we wait for any in-flight nativeRunFrame to
     * complete before freeing g_core / g_fb.                             */
    pthread_mutex_lock(&g_core_mutex);
    destroy_core();
    pthread_mutex_unlock(&g_core_mutex);
    LOGI("mGBA core destroyed");
}

/* ═══════════════════════════════════════════════════════════════════════════
 * GBA LINK CABLE MULTIPLAYER — SIO driver + JNI bridge
 *
 * Architecture
 * ────────────
 * The GBA link cable is emulated by hooking mGBA's SIO driver interface.
 * When the game writes to SIOCNT to start a serial transfer our driver
 * intercepts it, calls back into Kotlin (LinkMultiplayer.jniExchangeData)
 * over UDP or Bluetooth to swap data with the peer, writes the received
 * data into the GBA's SIO registers, then returns with the start bit STILL
 * SET so mGBA's own cycle scheduler fires the SIO IRQ naturally — no need
 * to call GBARaiseIRQ from internal headers.
 *
 * Thread safety
 * ─────────────
 * The SIO driver callbacks fire within g_core->runFrame() which itself
 * runs inside nativeRunFrame() under g_core_mutex.  g_tl_env is a
 * thread-local that stores the current JNIEnv* only for the duration of
 * that runFrame() call, giving the SIO callbacks a valid JNI environment
 * without requiring JavaVM->AttachCurrentThread on a background thread.
 * ═══════════════════════════════════════════════════════════════════════════ */

#include <mgba/gba/interface.h>   /* struct GBASIODriver, enum GBASIOMode */

/* Prototype from sio_link.c (compiled with internal mGBA src/ headers) */
void link_install_sio_driver(struct mCore *core, struct GBASIODriver *drv);
void link_remove_sio_driver (struct mCore *core);

/* ── Thread-local JNIEnv — valid only during nativeRunFrame ─────────────── */
static __thread JNIEnv *g_tl_env = NULL;

/* ── Link state ─────────────────────────────────────────────────────────── */
static struct GBASIODriver  g_link_drv;
static jobject              g_link_obj      = NULL; /* global ref              */
static jmethodID            g_link_xchg_mid = NULL; /* jniExchangeData(I)I    */
static bool                 g_link_active   = false;
static bool                 g_link_is_host  = false;

/* ── Core exchange: calls Kotlin LinkMultiplayer.jniExchangeData ─────────── */
static uint32_t link_exchange(uint32_t local_data)
{
    JNIEnv *env = g_tl_env;
    if (!env || !g_link_obj || !g_link_xchg_mid) return 0xFFFFFFFFu;
    jint result = (*env)->CallIntMethod(env, g_link_obj,
                                         g_link_xchg_mid, (jint)local_data);
    if ((*env)->ExceptionOccurred(env)) {
        (*env)->ExceptionClear(env);
        return 0xFFFFFFFFu;
    }
    return (uint32_t)result;
}

/* ── SIO driver callbacks ────────────────────────────────────────────────── */

static bool link_drv_init(struct GBASIODriver *d)   { (void)d; return true; }
static void link_drv_deinit(struct GBASIODriver *d)  { (void)d; }
static bool link_drv_load(struct GBASIODriver *d)    { (void)d; return true; }
static bool link_drv_unload(struct GBASIODriver *d)  { (void)d; return true; }

/*
 * writeSIOCNT — called for NORMAL_8 and NORMAL_32 SIO modes.
 *
 * SIOCNT bit layout (for NORMAL mode):
 *   [0]    SC state (shift clock: 0=external 1=internal)
 *   [1]    Internal clock speed (0=256 KHz 1=2 MHz)
 *   [7]    Start / busy
 *   [12]   Data length (0=8-bit  1=32-bit)
 *   [14]   IRQ on completion
 *
 * We let mGBA keep the start bit and schedule its own SIO completion event
 * (which raises the IRQ) — no need for GBARaiseIRQ from internal headers.
 */
static uint16_t link_drv_write_siocnt(struct GBASIODriver *drv, uint16_t value)
{
    (void)drv;
    /* Only act when a transfer is being initiated */
    if (!g_link_active) return value;

    /* Read local SIO data.
     * Bit 12 = 0 → 8-bit NORMAL (SIODATA8 at 0x0400012A)
     * Bit 12 = 1 → 32-bit NORMAL (SIODATA32 at 0x04000120) — used by Pokemon */
    uint32_t local_data;
    if (value & (1u << 12)) {
        /* 32-bit NORMAL */
        pthread_mutex_lock(&g_core_mutex);
        local_data = g_core ? g_core->rawRead32(g_core, 0x04000120, 0) : 0xFFFFFFFFu;
        pthread_mutex_unlock(&g_core_mutex);
    } else {
        /* 8-bit NORMAL */
        pthread_mutex_lock(&g_core_mutex);
        local_data = g_core ? (uint8_t)g_core->rawRead16(g_core, 0x0400012A, 0) : 0xFFu;
        pthread_mutex_unlock(&g_core_mutex);
    }

    /* Network exchange (blocks up to ~30 ms on local Wi-Fi / 50 ms on BT) */
    uint32_t remote_data = link_exchange(local_data);

    /* Write received data into the GBA SIO registers */
    pthread_mutex_lock(&g_core_mutex);
    if (g_core) {
        if (value & (1u << 12)) {
            g_core->rawWrite32(g_core, 0x04000120, 0, remote_data);
        } else {
            g_core->rawWrite16(g_core, 0x0400012A, 0, (uint16_t)(remote_data & 0xFFu));
        }
    }
    pthread_mutex_unlock(&g_core_mutex);

    /*
     * Return with bit 7 STILL SET → mGBA's GBASIOScheduleEvent fires the
     * SIO completion event after the correct number of cycles, which clears
     * bit 7 and raises the SIO IRQ if bit 14 (IRQ enable) is set.
     * The game's polling loop or IRQ handler then reads the data we wrote.
     */
    return value | 0x80u;
}

/*
 * writeMultiPlayer — called in GBA MULTI-PLAYER SIO mode.
 *
 * In MULTI mode each player sends 16 bits.  SIOMLT_SEND (0x0400012A) holds
 * our outgoing value; SIOMULTI0-3 (0x04000120-6) hold everyone's received
 * data.  We map: host = player 0, client = player 1 (2-player only).
 */
static uint16_t link_drv_write_multi(struct GBASIODriver *drv,
                                      uint16_t current_cnt, uint16_t value)
{
    (void)drv; (void)current_cnt;
    if (!g_link_active) return value;

    pthread_mutex_lock(&g_core_mutex);
    uint16_t local_data = g_core
        ? (uint16_t)g_core->rawRead16(g_core, 0x0400012A, 0)  /* SIOMLT_SEND */
        : 0xFFFFu;
    pthread_mutex_unlock(&g_core_mutex);

    uint32_t remote_data = link_exchange((uint32_t)local_data);

    pthread_mutex_lock(&g_core_mutex);
    if (g_core) {
        if (g_link_is_host) {
            /* Host = player 0: echo own data to SIOMULTI0, peer to SIOMULTI1 */
            g_core->rawWrite16(g_core, 0x04000120, 0, local_data);
            g_core->rawWrite16(g_core, 0x04000122, 0, (uint16_t)(remote_data & 0xFFFFu));
        } else {
            /* Client = player 1: peer's data to SIOMULTI0, own to SIOMULTI1 */
            g_core->rawWrite16(g_core, 0x04000120, 0, (uint16_t)(remote_data & 0xFFFFu));
            g_core->rawWrite16(g_core, 0x04000122, 0, local_data);
        }
        /* Mark remaining player slots as disconnected */
        g_core->rawWrite16(g_core, 0x04000124, 0, 0xFFFFu);
        g_core->rawWrite16(g_core, 0x04000126, 0, 0xFFFFu);
    }
    pthread_mutex_unlock(&g_core_mutex);

    return value | 0x80u;   /* trigger IRQ scheduling */
}

static bool link_drv_handles_mode(struct GBASIODriver *drv, enum GBASIOMode mode)
{
    (void)drv;
    return mode == GBA_SIO_NORMAL_8
        || mode == GBA_SIO_NORMAL_32
        || mode == GBA_SIO_MULTI;
}

/* ── nativeLinkStart ─────────────────────────────────────────────────────── */

JNIEXPORT jboolean JNICALL
Java_com_mgba_android_EmulatorEngine_nativeLinkStart(
        JNIEnv *env, jobject thiz, jobject link_obj, jboolean is_host)
{
    (void)thiz;

    /* Cache global ref and method ID */
    if (g_link_obj) { (*env)->DeleteGlobalRef(env, g_link_obj); g_link_obj = NULL; }

    jclass cls = (*env)->GetObjectClass(env, link_obj);
    g_link_xchg_mid = (*env)->GetMethodID(env, cls, "jniExchangeData", "(I)I");
    if (!g_link_xchg_mid) {
        LOGE("LinkMultiplayer.jniExchangeData(I)I not found");
        return JNI_FALSE;
    }
    g_link_obj     = (*env)->NewGlobalRef(env, link_obj);
    g_link_is_host = (bool)is_host;

    /* Build driver vtable */
    memset(&g_link_drv, 0, sizeof(g_link_drv));
    g_link_drv.init         = link_drv_init;
    g_link_drv.deinit       = link_drv_deinit;
    g_link_drv.load         = link_drv_load;
    g_link_drv.unload       = link_drv_unload;
    g_link_drv.writeSIOCNT  = link_drv_write_siocnt;
    g_link_drv.writeMultiPlayer = link_drv_write_multi;
    g_link_drv.handlesMode  = link_drv_handles_mode;

    /* Install into the running core */
    pthread_mutex_lock(&g_core_mutex);
    if (g_core) link_install_sio_driver(g_core, &g_link_drv);
    g_link_active = true;
    pthread_mutex_unlock(&g_core_mutex);

    LOGI("Link cable SIO driver installed (host=%d)", (int)is_host);
    return JNI_TRUE;
}

/* ── nativeLinkStop ──────────────────────────────────────────────────────── */

JNIEXPORT void JNICALL
Java_com_mgba_android_EmulatorEngine_nativeLinkStop(JNIEnv *env, jobject thiz)
{
    (void)thiz;
    pthread_mutex_lock(&g_core_mutex);
    g_link_active = false;
    if (g_core) link_remove_sio_driver(g_core);
    pthread_mutex_unlock(&g_core_mutex);

    if (g_link_obj) {
        (*env)->DeleteGlobalRef(env, g_link_obj);
        g_link_obj = NULL;
    }
    g_link_xchg_mid = NULL;
    LOGI("Link cable SIO driver removed");
}
