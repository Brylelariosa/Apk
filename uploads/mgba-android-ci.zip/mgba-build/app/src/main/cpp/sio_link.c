/*
 * sio_link.c — GBA SIO driver installation helpers.
 *
 * This file is the only translation unit that includes internal mGBA
 * headers (gba/gba.h).  All other C code uses the public mCore API only.
 * Keeping it isolated lets CMake add src/ to the include path just here.
 */

#include <mgba/core/core.h>
#include <mgba/gba/interface.h>
#include "gba/gba.h"     /* struct GBA → has struct GBASIO sio field */

void link_install_sio_driver(struct mCore *core, struct GBASIODriver *drv)
{
    if (!core || !drv) return;
    struct GBA *gba = (struct GBA *)core->board;

    /* Unload any existing driver gracefully */
    if (gba->sio.driver && gba->sio.driver->unload)
        gba->sio.driver->unload(gba->sio.driver);

    gba->sio.driver = drv;
    drv->p = &gba->sio;

    if (drv->init) drv->init(drv);
    if (drv->load) drv->load(drv);
}

void link_remove_sio_driver(struct mCore *core)
{
    if (!core) return;
    struct GBA *gba = (struct GBA *)core->board;
    if (!gba->sio.driver) return;

    if (gba->sio.driver->unload)
        gba->sio.driver->unload(gba->sio.driver);
    gba->sio.driver = NULL;
}
