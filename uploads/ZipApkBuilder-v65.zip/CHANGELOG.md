# Changelog — v65

v64 did not compile (GitHub Actions run 1966). Two comments I wrote contained the text
`.github/workflows/` followed by an asterisk. In Kotlin a block comment nests, so the slash-asterisk
inside opened a second comment that was never closed: `ZipSyncRunner.kt` and
`BuildFlowController.kt` stopped parsing, and every other error in the log (unresolved
`ensureRepo`, `triggerWorkflowDispatch`, `loadBuildHistory`, ...) followed from that. No code
changed, only those two comments.

## What the same log showed
- The workflow saw a plain Gradle project (`No Cargo.toml`) and `buildRustEngine` built the sync
  engine for both CPUs (arm64-v8a in 32 s, armeabi-v7a in 13 s). That includes the v64 Rust changes
  (paced uploads, batched commits), which had never been through a compiler before.
- `Unable to strip ... libzipsync.so, packaging them as they are` is harmless: the Rust profile
  already strips the binary.

## Fixed
- The two comments no longer contain a slash followed by an asterisk.
- `versionCode`/`versionName` 64 → 65.

## Rule for comments
Never write a slash followed by an asterisk inside a Kotlin comment, not even in a path such as a
workflow folder with a wildcard: write "the files under `.github/workflows`" instead.

## Checked — and not
- A string-aware scan of all 74 Kotlin files for nested or unclosed block comments: before the fix
  it flagged exactly the two files the compiler had flagged, after the fix none.
- **Not compiled.** The rest of the Kotlin in those two files could only be read, not compiled,
  because the parse errors hid it; the Kotlin changes since v63 are small and were read again.

# Changelog — v64

Two things about *Sync changes into repo*: it now replaces everything (changed files are replaced,
new files are added, `.github/` and the workflow `build.yml` included), and a big sync — a test
with about 900 files never finished — now gets through. Nothing else in the app changed.

## Changed
- The engine is always started with `--include-workflows`, so `.github/workflows/*` in the ZIP is
  synced like any other file (v62 and v63 skipped it).
- The app no longer refuses a `build.yml` it didn't write.
  - If the ZIP carries its own `build.yml`, the sync puts it in place and the app leaves the
    workflow alone. The log warns when that file isn't v3 or later: the run after the sync only
    works if it builds the repo's own files.
  - If the ZIP has none, a repo `build.yml` that is older than v3, or isn't the app's, is replaced
    by the bundled v3 before the sync. The old file stays in the repo's history.
- `ZipSyncRunner.readBuildWorkflow` looks into the ZIP (at its root, or inside the one folder that
  wraps the project) for that file. The build flow now copies the ZIP into the cache first, so the
  check can run before anything in the repo is changed.
- When GitHub refuses the workflow files, the error says the token needs the `workflow` scope.
- *Upload to › Sync changes into repo* describes the new behaviour.
- `versionCode`/`versionName` 63 → 64. No Rust code changed.

## Big syncs no longer stall
The engine sent every binary (and every text file past the first 4 MB) as its own request, four at
a time and as fast as they went. That runs straight into GitHub's limit for creating content (about
80 requests a minute, about 500 an hour). Each thread then slept 60-90 s on its own, tried again
and hit the limit again; and because nothing was committed until the very end, a run that finally
gave up lost everything.
- Write requests are paced: one every 0.75 s across all threads, just under 80 a minute. When GitHub
  still says *slow down*, all threads pause together for as long as it asks. If it asks for more
  than 3 minutes the run stops with a clear message instead of waiting.
- The sync is carried out in batches of at most 800 files, 40 separate uploads and 3 MB of text.
  Each batch is its own commit on top of the previous one, so it is a save point: when a run stops,
  the next one only does the rest. All commits but the last carry `[skip ci]`; the last one starts
  the build, and files that don't start a build on their own (`.github/**`, `*.md`) go first so that
  it does. A small sync is still a single commit.
- Text files no longer share one 4 MB budget: each batch carries up to 3 MB of text inside its tree
  request, so hundreds of text files cost a handful of requests.
- The log says up front how long the one-by-one uploads will take, and progress counts the files of
  the whole sync across the batches.
- Changed: `github.rs` (pacing, shared cool-down), `sync.rs` (batches). The ZIP-to-repo rules are
  the same.

## Unchanged
- A sync never deletes a file that only the repo has.
- Normal uploads (`uploads/`, repo root) work as before: the ZIP is only unpacked on the runner,
  and an existing `build.yml` is left as it is.

## Checked — and not
- The logic that looks for the ZIP's own `build.yml` was tested on sample ZIPs (root, wrapper
  folder, macOS junk, wrapper plus a root file, no workflow, backslash names, not a ZIP) with a
  Python copy of the algorithm. That is not the Kotlin itself.
- The batching (sizes, order, last commit starts a build, every file used once) was simulated with a
  Python copy of the algorithm on a 900-file plan: 8 commits, the last one with a build-starting file.
- **Not compiled.** I re-read the edited Kotlin and the edited Rust for compile errors and checked
  the brackets, but there is no Rust, Kotlin or Gradle here. If the Rust does not compile, the app's
  own build still succeeds (the engine step never fails it) and Sync reports that the engine is
  missing; the line to look for in the build log is `zipsync engine`.

# Changelog — v63

v62 did not build: GitHub Actions run 1962 stopped in the workflow's own Rust step, before Gradle
had even started. This fixes that; no app code changed.

## What went wrong
The repo's build workflow has a generic Rust step: it looks for a `Cargo.toml` up to two levels
below the project root and, if it finds one, builds that crate with `cargo ndk` as a JNI library
(a `cdylib` copied into `jniLibs`). v62 added `rust/Cargo.toml` — the sync engine — which is an
*executable* that Gradle builds itself (`buildRustEngine`). So the step found it, cargo compiled it
without a single error (34 s, arm64), and then cargo-ndk gave up: *No usable artifacts produced by
cargo — did you set the crate-type in Cargo.toml to include 'cdylib'?* The non-blocking test step
had printed *no library targets found in package `zipsync`* for the same reason.

## Fixed
- The crate moved from `rust/` to `app/src/main/rust/zipsync/` — deeper than that search goes — so
  the workflow sees a plain Gradle project and Gradle's `buildRustEngine` builds the engine as
  designed. `app/build.gradle` names the folder once (`rustEngineDir`); the script finds the crate
  from its own location. Why, and the rule of thumb, are in `RUST_ENGINE.md`.
- `build-android.sh` puts rustup's folder (`$CARGO_HOME/bin`) on `PATH` when Gradle started without it.
- The workflow's Rust cache step (`WorkflowTemplates.kt`; still v3, which has not shipped yet)
  follows the crate to its new folder.
- `versionCode`/`versionName` 62 → 63.

## How this was checked — and what was not
- The workflow's own `find … -maxdepth 2 -name Cargo.toml`, run on the unpacked v63 ZIP, finds nothing.
- `build-android.sh` run from the new location against stub cargo/rustup/NDK: both ABIs, one ABI,
  no cargo, no NDK, and recovering cargo through `CARGO_HOME` with a bare `PATH` — exit 0 and the
  right files every time.
- The v3 workflow rendered, parsed as YAML, every `run:` block through `bash -n`.
- **Not compiled.** No Rust, Kotlin or Gradle here. Run 1962 did compile the Rust code for arm64
  (armeabi-v7a is first built by the next run). The v62 Kotlin changes have still never been through
  a compiler: I read the new sync code and checked that every symbol it calls and every `R.*`
  resource it uses exists — nothing found, but that is not a build.

# Changelog — v62

Adds **Sync changes into repo** — a third choice on the main screen's *Upload to* row. The ZIP is
no longer uploaded at all: the phone unpacks it, compares every file with the repo, uploads only
the files that differ and makes **one commit**; the build then runs on the repo's own files. The
engine doing this is written in Rust (`rust/`, see `RUST_ENGINE.md`).

## What it does
- Same path in the ZIP and in the repo → the repo file is **replaced** (only if the content really
  differs — it is compared by Git blob id, so unchanged files cost nothing).
- Path only in the ZIP → **added**. Path only in the repo → **left alone** (nothing is ever deleted).
- A folder that wraps the whole ZIP (GitHub's "Download ZIP" gives `repo-main/…`) is cut off
  automatically when that makes the paths line up with the repo.
- `gradlew` and other executables keep their executable bit; `.git/`, `__MACOSX/`, `.DS_Store` and
  `.github/workflows/*` from the ZIP are skipped (the app manages `build.yml`).
- A branch that moves while syncing is re-read and the sync retried (up to 3×) instead of failing.

## Why a 7 MB ZIP could not be uploaded
Until now a project ZIP travelled to GitHub as ONE request — the ZIP encoded as base64, about 9.3 MB
for a 7 MB ZIP — and every failed try started again from byte 0 (see *Uploads cannot resume* in
`KNOWN_LIMITATIONS.md`). On a mobile connection, or when the phone's task cleaner kills the app
mid-upload, that is the part that breaks. I could not reproduce the failure here, so this is the
most likely cause, not a confirmed one. Sync mode removes it rather than tuning it: a typical
update uploads a few kilobytes, in small parallel requests that are each retried on their own.
(The uploads/ and repo-root choices still upload the whole ZIP exactly as before.)

## Changed
- `build.yml` is now **v3**: any push to `main`/`master` builds (except pushes that only touch
  `.github/**` or `*.md`). A push that adds a ZIP builds that ZIP as before; a push without a ZIP
  — a Sync commit, an edit made on GitHub — builds the repo's own files. A manual run has a new
  `source` input (`auto` / `zip` / `repo`). Sync mode updates an older copy the app wrote
  automatically; a `build.yml` the app didn't write is never touched (Settings › Update build
  workflow replaces it).
- The workflow caches Rust build output (only for projects that contain a `Cargo.toml`).
- Gradle: `buildRustEngine` runs before every build and puts `libzipsync.so` in the APK for
  arm64-v8a and armeabi-v7a; the APK now extracts native libraries at install (the engine is an
  executable and Android only runs those from the native-library folder).
- `versionCode`/`versionName` 61 → 62.

## If the Rust part does not compile
It cannot break the app: `rust/build-android.sh` always exits 0. A build problem shows up in the
GitHub Actions log as `zipsync engine: …` (and a `::warning::` annotation); the APK is then built
without the engine, every old feature works, and choosing *Sync changes into repo* says that the
engine is missing. Send me that part of the log and I'll fix it.

## How this was checked — and what was not
**Not compiled.** This environment has no Rust toolchain and no Kotlin compiler, so neither the
Rust code (about 900 lines) nor the Kotlin changes have been compiled, and nothing has run against
GitHub. Expect that the first build may need a round of fixes, like v60 did.
What was verified here:
- `rust/build-android.sh`: syntax-checked and run against stub `cargo`/`rustup`/NDK for success,
  one ABI failing, no cargo, no NDK, NDK found through the SDK folder, and no argument — it exits 0
  and produces the right files in every case.
- The v3 workflow: rendered from `WorkflowTemplates.kt`, parsed as YAML, every `run:` block checked
  with `bash -n`, and the new "Choose what to build" / "Find project directory" steps executed
  against simulated pushes and manual runs (ZIP added, push without ZIP while an old ZIP sits in
  the repo, `source` = auto / repo / zip, project at the root / in a subfolder / missing).
  `jq` was a stand-in locally; the runner has the real one.

# Changelog — v61

v60 did not compile (GitHub Actions run 1948: 6 Kotlin errors, all in `CodeEditorDialog.kt`). This
fixes them; nothing else changed.

## Fixed
- `ViewCompat.IMPORTANT_FOR_AUTOFILL_NO` does not exist — `ViewCompat` only has the setter, the
  constant is `View.IMPORTANT_FOR_AUTOFILL_NO` (2 places).
- `AppCompatEditText.text` is nullable in the real library, and 4 places treated it as non-null:
  pre-filling Find from the selection, scrolling to a match (2 places) and the "Go to line" range.

## How this was checked
v60's whole-project type-check used stand-ins I wrote for the androidx classes, and two of them
differed from the real library in exactly these two ways (one had a constant that doesn't exist,
the other a non-null `getText()`). The stand-ins are corrected; with them the v60 source reproduces
the real build's six errors at the same line and column, and v61 compiles with 0 errors on that
check. It has still not been built with Gradle here.
- `versionCode`/`versionName` 60 → 61.

# Changelog — v60

> **v60 failed to compile on GitHub Actions (run 1948) — fixed in v61.** The "0 errors" below was
> measured with androidx stand-ins that turned out to be wrong in two places; see v61.

Three changes: ZipApkBuilder now shows up in the share sheet (the up-arrow on a file or ZIP in the
Claude app), an upload's destination is chosen where the upload happens instead of in a Settings
switch, and the code editor is rebuilt.

How this was checked: the whole project was type-checked with Kotlin 2.0.21 (the project's own
version) against the real android-34 `android.jar`, with small stand-ins for the ~20 androidx /
Material classes the project uses — 0 errors. The pure logic (syntax coloring, undo history, auto-indent
and pairing, comment/indent transforms, upload-folder rules) was compiled and run on a JVM: 210
checks pass, and a 408-case matrix of hostile inputs (200 KB of unclosed quotes, brackets, dashes…)
across every language finishes in under 300 ms each. It was **not** built with Gradle/AGP or run on
a device — please run a build and try it on your phone before shipping.

## Added
### Share target — send a file or ZIP straight into the app
- ZipApkBuilder is listed in the system share sheet (and in "Open with" for ZIPs), next to
  ZArchiver and friends. Tap the up-arrow on a file or ZIP in the Claude app and pick it.
- The file is copied into the app's cache first (the sender's read permission only lasts as long as
  the receiving screen), so a ZIP you share now can still be built minutes later.
- A single ZIP becomes the project ZIP immediately, and a small dialog offers **Upload & build** or
  **Upload to repo…**. Other files, several files, and plain shared text (saved as a `.txt`) get
  **Upload to repo…**.
- `launchMode` is now `singleTask`, so a share always reaches the one running app instead of
  starting a second copy next to it. A share that arrives while a build or upload is running is
  declined with a message rather than racing it. `file://` links into the app's own private storage
  are refused.

### Upload destination — chosen at the upload, not in Settings
- The **Upload to** row on the main screen (above Upload & build) picks `uploads/` or the repo root
  for the build ZIP — the only two places the build workflow triggers on. The Settings switch
  "Upload ZIP to repo root" is gone; an install that had it on keeps that choice.
- File Manager → **Upload file** now ends in a confirm step listing the files and the destination
  folder (starting at the folder you were browsing) with a **Change folder** button.
- The folder chooser offers This folder, Repo root, `uploads/`, recent folders, **Browse repo
  folders…** (a live folder browser), and **Type a folder path…** (new folders are created by the
  upload).

### Code editor (File Manager → View / Edit) — rebuilt as a full-screen editor
- Live syntax coloring for Kotlin, Java, JS/TS, C-family, Gradle, Python, shell, YAML, config files,
  XML/HTML, JSON and Markdown; computed off the main thread and dropped if you typed meanwhile.
- Undo / redo (also Ctrl+Z / Ctrl+Y), merged so one undo takes back a word, not a letter.
- Auto-indent on Enter (one level deeper after `{` `(` `[`, or `:` in Python/YAML; Enter between a
  pair opens it), bracket and quote auto-pairing with type-over, Tab / Untab for the selected lines,
  and a comment toggle. The file's own indent (tabs or 2/4 spaces) and line endings (LF / CRLF) are
  detected and kept.
- A symbol row above the keyboard: `{ } ( ) [ ] < > " ' ; : = / \ | & # _ - + * ! ? $ % @ . ,`,
  cursor left/right, Tab.
- Find **and replace** (Replace / Replace all as one undo step), match counter, previous/next, match
  case, go to line (also by tapping the Ln/Col readout).
- Word wrap and text size (A− / A+), both remembered. The line-number gutter is drawn from the text
  layout, so it stays aligned on wrapped lines and costs the same on a 10,000-line file. The caret
  line is shaded, and Ln/Col, line ending and language are shown.

## Fixed (found while rebuilding the editor)
- **A binary file opened as editable garbage, and saving it would have corrupted it.**
  `String(bytes, UTF_8)` never fails — it swaps invalid bytes for U+FFFD. Files are now decoded
  strictly and anything that isn't valid UTF-8 opens read-only.
- An empty file was treated as "binary or empty — not editable", so a new empty file couldn't be
  filled in. It now opens as an empty editable file. (A file that has a size but came back empty
  still opens read-only, so it can never be saved over with nothing.)
- A failed save closed the editor and threw the edits away. The editor now stays open with the
  edits intact and says why (for a changed-on-GitHub 409/422: copy your text, reopen, paste).
  Save with nothing changed no longer sends a commit.
- Closing or Back no longer discards edits silently — you get Save / Discard / Keep editing.
- "Go to line" counted wrapped screen lines, not file lines.

## Changed
- `versionCode`/`versionName` 59 → 60.
- New files: `feature/share/IncomingShareController.kt`, `feature/upload/UploadDestination.kt`,
  `UploadDestinationPicker.kt`, `UploadConfirmDialog.kt`, `feature/filemanager/CodeEditorDialog.kt`,
  `core/CodeEditText.kt` (+ `GutterView`), `CodeEdits.kt`, `EditHistory.kt`, `SyntaxHighlighter.kt`,
  five small vector icons (undo, redo, search, wrap, tab).

## Not changed
- The build workflow and its triggers (`uploads/**`, root `*.zip`) are untouched, which is why the
  build ZIP only offers `uploads/` or the repo root; any folder is available for plain uploads.
- Binary files still can't be edited (they open read-only). Syntax coloring is skipped for text
  files over about 250,000 characters so typing stays responsive; everything else still works.

# Changelog — v59

Every time and date the app shows is now Philippines time (`Asia/Manila`) on a 12-hour clock with
AM/PM ("4:05 PM", never 16:05). Not compiled here — please run a build before shipping.

## Changed
- The build-log run list showed "Oct 19, 16:05" in 24-hour time in the phone's own time zone; it
  now shows "Oct 19, 4:05 PM" in Philippines time.
- Artifact built / expiry dates use Philippines time too (a date near midnight could differ).
- The saved build log's file name (`build_log_2026-10-19_4-05-12_PM.txt`) and the default
  keystore alias (`key-2026-10-19_4-05-12_PM`) use the same time instead of `HHmmss` / `HHmm`.
- All of it goes through `Formatters` (`fmtLocalTime`, `fmtLocalDate`, `fmtFileStamp`); no other
  file touches `SimpleDateFormat` or a time zone any more. History times were already
  Philippines 12-hour.
- `versionCode`/`versionName` 58 → 59.

## Not changed
- Notification timestamps are drawn by Android itself, so they follow the phone's own clock
  settings.

# Changelog — v58

Full code audit of v57 plus the fixes and features it led to. The audit itself is in
`AUDIT_REPORT_v58.md`. Not compiled here (no Android SDK or Kotlin compiler in the authoring
environment): the workflow YAML and its shell scripts were run against fixtures, the Kotlin was
checked by hand and with a bracket/resource/signature scan — please run a build before shipping.

## Security
- **The keystore workflow printed secrets into the Actions log.** The token and password typed in
  the app were written into the `run:` script with `${{ github.event.inputs.* }}` expressions and
  the keystore (base64) was passed between steps with a step output. Actions prints a step's
  script after expanding it, so the GitHub token, the keystore password and the whole keystore
  appeared in clear text in the job log (public for a public repo). A password containing `"`,
  `$` or a backtick also broke the script, and `$$` expanded differently in the two steps, so the
  saved secret could differ from the real keystore password. `keystore.yml` v2 is one step that
  reads the inputs from the event file with `jq`, masks them first and never puts a secret in an
  expression or output.
- The app now deletes the keystore run when it finishes (its dispatch inputs hold the token and
  password); a failed run's job log is copied into the app log first.
- Repos created as a side effect of Upload & build are now **private** (they were public).
  The New repository popup still offers public.
- `build.yml` passes the signing secrets through `env:` instead of splicing them into the Gradle
  command line.

## Fixed
- Upload & build straight after switching repository ran with an empty ZIP name (the v57 "not
  changed" item). Switching now clears the whole pick; creating a new repo keeps it.
- The repo picker listed collaborator repos; picking one created a same-named repo on your own
  account because the owner is always the signed-in user. It lists repos you own, up to 500
  (was the first 100).
- Keystore generation used `main` for the workflow commit, the dispatch and the run lookup; it
  uses the repo's default branch now.
- `build.yml` built the wrong ZIP when more than one was in the repo (it picked the file written
  last at checkout, i.e. the alphabetically last) and kept the ZIP after a failed build. It now
  builds the ZIP the pushed commit added, cleans up after success and failure, can't fail the
  job from the clean-up, rebases before pushing and deletes a stale `local.properties`.
- A ZIP name with spaces broke the run-to-ZIP-name lookup used to name downloaded logs.
- A 45-minute timeout now says so instead of "[error] Build ".
- The Activity is no longer recreated by dark-mode, fold or multi-window changes (they dropped the
  picked ZIP and the build's busy state); the picked ZIP's Uri also survives a recreation.

## Added
- **Cancel build**: while a build is waiting for its run or running, the main button turns red
  ("Cancel build", with a confirmation) and stops the GitHub run.
- The status line shows the running time while building ("Building… 2m 14s").
- The main card shows the target as `repo @ branch`; tap it to switch repository.
- Settings > GitHub > **Update build workflow** replaces `build.yml` with the bundled v2. Upload &
  build now says when a repo's `build.yml` is older than the bundled one (it never rewrites it on
  its own).
- The pre-upload check also warns when the ZIP has no `app/` module.

## Changed
- `versionCode`/`versionName` 32 → 58.
- `BuildRetryManager.poll`, `BuildRunMonitor.waitForRun/pollUntilComplete` take optional
  cancel/progress parameters (defaults keep every existing call as it was).

## Not changed (noticed while auditing)
- The token is still passed to the keystore run as a dispatch input: `GITHUB_TOKEN` cannot write
  repository secrets. Encrypting the secrets on the phone instead needs a libsodium dependency.
- The picked ZIP is still forgotten when the app is restarted (it uses `GetContent`, which gives
  no persistable permission).

# Changelog — v57

New repository: create a GitHub repo from inside the app and switch to it. Not compiled here (no
Android SDK or Kotlin compiler in the authoring environment) — please run a build before shipping.

## What was missing
- The only way to get a new repo was to type an unused name into Repository and run Upload & build:
  `BuildFlowController.ensureRepo` then created it silently — always public, always with the same
  description, and only once a ZIP was picked and a build was already under way.

## Changes
- New "New repository" popup (`feature/repo/RepoCreator`, `layout/dialog_new_repo`): name,
  optional description, and a Private switch (on by default; the line under it says who can see
  the repo and that private repos use the plan's Actions minutes). Reachable from:
  - Settings > GitHub: a green "New repository" action under "Switch repository";
  - the "Switch repository" list: its first row. File manager's "Switch" and Artifacts'
    "Switch repo" chips open that list, so it is one tap away from there too.
- The popup stays open while the request runs. A bad or taken name is shown on the name field
  (live while typing: letters, numbers, `-` `_` `.`, at most 100, not `.` / `..`, not ending
  `.git`; "already taken" comes back from GitHub); anything else — missing token scope, rate
  limit, no network — is shown in the popup too, so it can be fixed without starting over.
- On success the repo is created with a first commit (`auto_init`), the app waits (up to 20 s)
  until its default branch exists, then calls `RepoSwitcher.applySwitchRepo` with the repo name
  and default branch GitHub reports — not an assumed `main` — so all per-repo session state is
  reset exactly as for a normal switch. The console logs `[ok] Created owner/name (private) — url`.
  A timeout on the wait is only a warning; the repo exists either way. If the popup was closed
  mid-request the repo is still created and adopted, and a failure goes to the log instead.
- "Switch repository" no longer fails with "No repositories found for this token." on an empty
  account: the list opens with just the New repository row.

## Shared code
- New `net/GitHubRepos`: the one place a repo is created — `nameProblem` (pure name check),
  `create` (`POST /user/repos` with `auto_init`; returns `Created` or `Refused(message,
  isNameProblem)`, transport failures still throw like every `GitHubApi` call) and `isReady`
  (default branch exists). It parses GitHub's 422 `errors` list, so "name already exists on this
  account" becomes "You already have a repository with this name.", and a 404 becomes "the token
  is probably missing the repo scope".
- `BuildFlowController.ensureRepo` now goes through it. Same request as before (public, same
  description); it additionally rejects an invalid name up front instead of letting GitHub
  rewrite it. Its wait now checks that the default branch exists rather than that the repo
  exists (same 30 s cap, same warn-and-continue on timeout), since the next step writes to that
  branch.
- New `feature/repo/RepoDialogs.requireToken`: the "GitHub token needed" popup, extracted from
  `RepoSwitcher` and shared with `RepoCreator`.
- New drawable `bg_btn_tonal_green_ripple` (sibling of the violet and red tonal buttons).

## Needs from the token
- Creating a repo needs a token allowed to: a classic token with the `repo` scope (`public_repo`
  is enough for a public repo).

## Not changed (noticed while investigating)
- A repo created silently by Upload & build is still public. Only the new popup offers private.
- `RepoSwitcher.applySwitchRepo` clears the picked ZIP's name and label but keeps its Uri
  (`selectedZipUri`), so Upload & build straight after any switch — this new one included — runs
  with an empty ZIP name. Calling `clearSelectedZip()` there would fix it; left alone as it
  changes Switch behavior, not just creation.
- Repos are always created under the signed-in user. Organization repos are not offered: the
  rest of the app resolves the owner from `GET /user`, so it could not target one anyway.

# Changelog — v56

Faster ZIP extract and faster multi-select delete in the file manager. Not compiled here (no
Android SDK or Kotlin compiler in the authoring environment) — please run a build before shipping.

## Why they were slow
- Extract made one `POST /git/blobs` request per file, strictly one after another, and downloaded
  the ZIP itself as base64-inside-JSON. A 200-file archive was 200+ sequential round trips.
- Multi-select delete made one Contents-API commit per file, also sequential (those commits cannot
  run in parallel: each one moves the branch tip). A selected folder was first listed folder by
  folder, then deleted file by file.

## Changes
- New `net/GitBatchCommit`: applies any number of file changes as ONE commit through the Git Data
  API (read tip -> tree(s) -> commit -> ref update), with retry/back-off for 429/5xx/secondary rate
  limits and dropped connections. Used by both features below.
- New `net/BlobUploadPool`: uploads blobs on 4 threads with bounded memory (at most 8 files queued).
- Extract (`ZipExtractController`, new `ZipTreePlanner`):
  - the ZIP comes down as raw bytes (`GitHubApi.fetchBlobRaw`, `application/vnd.github.raw+json`),
    a third smaller and nothing to base64-decode; the old routes remain as fallbacks;
  - text files (valid UTF-8, no NUL, up to 512 KB each / 32 MB total) are sent INSIDE the tree
    request, so they cost no request at all; empty files and `.gitkeep` share one empty blob;
  - binary files upload as blobs in parallel while the rest of the archive is still being read;
  - still one tree, one commit (`chore: extract <zip> [skip ci]`), one ref update;
  - the log is written in groups instead of one UI append per file; it prints total time at the end;
  - duplicate entry names in an archive now overwrite instead of producing a duplicate tree entry,
    and entry names are cleaned (`\` -> `/`, `./`, empty segments; `..` entries are skipped + warned).
- Multi-select delete (`FileOperationController`):
  - folders, or 3+ files, are removed in ONE commit: one recursive tree listing, then a tree with
    those paths nulled out, one commit (`chore: delete N items via ZipApkBuilder [skip ci]`), one
    ref update. Atomic — a failure leaves the repo untouched instead of half a folder deleted;
  - items already gone from the repo are reported and skipped instead of failing the batch;
  - 1–2 plain files still use the per-file Contents API (one request each, cheaper than a batch);
  - if GitHub truncates the tree listing (100k+ entries) it falls back to the old per-item route;
  - the "forget this path" bookkeeping (`lastFileSha`, picked ZIP) moved into one helper shared by
    both routes.
- New small helpers: `core/TextBytes` (strict UTF-8 check), `core/LogBatcher`.
- New `GitHubApi` pieces: `apiTree`, `fetchBlobRaw`, `httpPostBlob` (streams base64, returns the
  rate-limit headers).

## Not changed
- File modes are still written as 100644 (the executable bit is not preserved), as before.
- Single-file "Delete" in the item menu is untouched.

# Changelog — v55

Settings dialog redesign. Not compiled here (no Android SDK in the authoring
environment) — please run a build before shipping.

## What was wrong (from a v54 screenshot)
- The "Save & close" bar was not visible: the scrolling body was `wrap_content` with an
  `android:maxHeight` that ScrollView ignores, so it took all the remaining height and pushed the
  bar off the bottom. The body is now `0dp` / weight 1, so the bar is always pinned.
- Every `<Button>` in Settings rendered as a violet, ALL-CAPS MaterialButton. In this theme a
  `<Button>` is inflated as a MaterialButton, which ignores `android:background`; so Change, Reset,
  Clear and Generate all came out the same violet (Clear was red text on violet), and
  "SWITCH REPOSITORY" / "GENERATE & SAVE KEYSTORE" were upper-cased.
- Floating labels and helper text were monospace in some fields and sans-serif in others (a
  TextInputLayout copies its EditText's typeface, and password fields are monospace).
- Helper text, the upload description and the history meta used `text_tertiary` (~2.3:1 contrast).
- Section headers were inconsistent (icon on one, none on another, small caps labels below).

## Changes
- Layout (`dialog_settings.xml`, rewritten; every view id kept): header with subtitle
  ("Changes are saved when you close"), one scrolling body, pinned Save bar with a hairline.
  Four sections with the same header (tonal icon tile, title, one-line subtitle): GitHub,
  Keystore signing, Downloads, Build history (its subtitle is the stats line).
- Actions are small clickable LinearLayouts (icon + label) using the tonal ripple drawables, the
  same construction as the popup pills, in sentence case: in-body actions are violet-tinted
  (`bg_btn_tonal_primary_ripple`), Reset is neutral, Clear is red-tinted
  (`bg_btn_tonal_red_ripple`). "Save & close" stays the one solid button. Buttons are `View`s in
  the controller now (they were `Button`).
- Keystore password and alias are stacked full width (the half-width password hint was cut to
  "Keystore password…"). The upload-destination switch, the download location and both history
  lists sit in grouped rows (`bg_setting_row`). The upload switch is a `SwitchMaterial`
  (violet when on) and is a `CompoundButton` in the controller.
- Fonts: labels, helper text and values are sans-serif. The password fields are declared
  sans-serif in XML (so the labels are) and set to monospace in code (so a pasted token is easy
  to read). Status chips (`@owner / repo`, keystore ready) are sans with a leading icon.
- New `text_muted` (#868EB0, ~5:1 on the dialog surfaces) for small secondary text.
  `text_tertiary` is untouched and still used elsewhere.
- History rows: a tonal tile (zip / package for downloads; check / warning / close for build
  outcome), a 13sp title and a muted meta line, hairlines between rows only. "1 build" instead
  of "1 build(s)". Helper text reads "Needs the repo scope" (it had two stray double spaces).
- Window: floats with a 10dp / 16dp margin and four rounded corners like the other popups
  (an `InsetDrawable` window background). A tap on the margin counts as tap-outside, so it
  still saves.
- New drawables: `bg_icon_tile_{orange,teal,blue,purple}`, `bg_btn_tonal_primary_ripple`,
  `bg_btn_tonal_red_ripple`, `bg_setting_row`; `bg_icon_tile` was already the violet one.

## Not changed (noticed while investigating)
- The same MaterialButton behavior affects the `<Button>`s on the main screen (Upload & build,
  Artifacts, Choose, Copy, Share…): they are violet/upper-case regardless of the tone drawables
  set on them. Left alone here; it is a separate, app-wide change.

# Changelog — v54

Popup and upload-logo polish. Not compiled here (no Android SDK in the authoring
environment) — please run a build before shipping.

## Upload logo
- The "Upload & build" button used `ic_rocket`, whose path data was malformed (it drew as a
  tangled swirl, not a rocket). It now uses a new cloud-with-arrow icon (`ic_cloud_upload`),
  which also replaces the plain arrow on the floating upload bubble and on "Upload file" in
  the file manager's Create menu. `ic_rocket.xml` is deleted (nothing else used it).
- New `ic_zip` (a page with a zipper, echoing the ZIP half of the launcher icon). It marks the
  project ZIP on the main screen, in the Extract ZIP popup and file menu, and on the
  Cancel upload popup.
- The project tile on the main screen is a dashed placeholder until a ZIP is picked, then turns
  solid brand color (`bg_file_tile` + `color/file_tile_icon`, driven by `isActivated`;
  `MainActivity.showSelectedZip()` sets it). "Choose" now has a folder icon.
- Notification small icon (`ic_notification`): the download arrow was white on a white page, so
  it never showed. It is now the zip page with the zipper cut out.

## Popups
- Window: 24dp corners and a 1dp border (was 20dp / 1.5dp), a slightly stronger dim, and a short
  fade + scale open/close (`Animation.App.Dialog`, `anim/dialog_enter|exit`). Settings' rounded
  header/footer/root drawables use the same 24dp radius.
- Title bars (`dialogTitleBar`) can show a tonal icon tile that says what kind of popup it is
  (red for delete, orange for keystore/stop-upload, blue for logs, green for create, violet for
  neutral), plus an optional one-line subtitle. Parameters are optional, so existing calls
  compile unchanged. New `core/IconTile.kt`; `ButtonTone` gained an `accent` color.
- The file manager, build log, artifact browser and download manager headers use the same
  tile and a top-rounded header background, so their corners sit inside the popup's.
- Body building blocks (`core/DialogBody.kt`): `dialogStack`, `dialogChip` (monospaced file/repo
  name with an icon and optional size), `dialogBullets` (real bullets, hanging indent) and
  `dialogLoading` (spinner + text).
- `dialogWithActions`: hairline between body and buttons, more padding, and larger pills when
  there are at most two actions with short labels. New `stacked = true` option for a three-way
  choice with long labels (full-width buttons, one per line).
- Rebuilt on the shared layout (they were on the platform button bar or plain text):
  Cancel upload, Keystore already set up (stacked), Generate keystore, Clear download history,
  Clear build history, GitHub token needed, Switch repository (loading + error), No artifacts
  found, Artifact expired. Cancel upload now shows the file name and size. Each of these
  dismisses itself before running its action.
- Still on the platform button bar (unchanged, see FileOperationController): the multi-select
  delete checklist, because `setMultiChoiceItems` can't be combined with a custom body.

# Changelog — v53

UI, wording, and a stale-listing bug. Not compiled here (no Android SDK in the
authoring environment) — please run a build before shipping.

## Fixed: deleted ZIP still showing after going back
- Root cause 1: every Contents API read (`GitHubApi.httpGet`) omitted `?ref=<branch>`, so
  GitHub answered from the repo's *default* branch while uploads/deletes target the branch
  selected in the app. On any other branch a deleted file kept appearing in the listing.
  `apiContents()` now takes a `ref`, and the browser, editor, copy, extract, move, recursive
  delete and SHA lookups all pass the selected branch.
- Root cause 2: GitHub sends `Cache-Control: max-age=60` on Contents reads, so a listing
  fetched right after a delete could be served from cache. `httpGet` now disables caching.
- Deleting the repo copy of the ZIP you picked also clears the main-screen selection
  (`MainActivity.clearSelectedZip()`), so the removed file's name is not shown any more.

## Emoji and symbol glyphs removed
- All emoji and symbol glyphs (check marks, crosses, warning signs, arrows used as icons,
  status bullets) are gone from dialogs, titles, buttons, notifications and the workflow YAML.
- Console lines use plain level tags instead: `[ok]`, `[warn]`, `[error]`, `[step]`, `[info]`,
  `[retry]`. `core/LogStyle.kt` colors the tag (errors tint the whole line) and dims rule
  lines. Tags stay in the text so copied/shared logs are still greppable.
- Run and build-history status markers are drawn dots (`core/StatusDot.kt`) instead of glyphs.

## UI
- Main screen: project card with a file tile, "Choose" and a full-width "Upload & build"
  button with an icon; right-aligned status row; three icon tiles for Artifacts, Build log
  and File manager; calmer console palette and slightly larger log text.
- Sentence case for buttons, dialog titles and settings labels; all-caps section titles
  removed. Clearer copy for delete confirmations and the upload-location hint.
- App name is now "ZIP to APK Builder".

# Changelog — v37

Stops fighting the platform's dialog button bar and replaces it outright.
v36 shrank its padding enough to stop the 3-button rows from stacking
vertically, but they still rendered as oversized, gap-heavy pills
(Delete/Close/New, View Log/Refresh/Trigger, Download/Trigger/Close) — the
`Widget.App.Button.Dialog` style's own baked-in min-height/padding was still
winning out over anything set from code via `getButton(...)`.

## The actual fix
New `core/DialogButtonRow.kt` (`dialogWithActions()` + `DialogAction`) builds
the button row ourselves as a plain `LinearLayout` of `pillButton()`s and
hands the whole thing to `.setView()`, instead of using
`.setPositiveButton()`/`.setNeutralButton()`/`.setNegativeButton()` at all.
This is the same `pillButton` already used for the Switch/Trigger chips and
the download row's Pause/Resume/Cancel — sizing nobody's flagged as wrong in
three rounds of screenshots — so it's a known-good look, not another guess
at the platform's button-bar internals.

New `core/BoundedListView.kt` lets a real scrolling list live inside that
same custom body (needed for the File Manager's browser dialog, which
combines a file list with the New/Delete/Up action row).

## Converted to the new pattern
File Manager's browser dialog (+ its nested Move/Rename and Delete-confirm
dialogs), New Folder, New File, Create Repository, the code editor's
Save/Copy/Cancel and Go-to-Line dialogs, the multi-select delete's nested
confirm step, Build Log's run picker and log viewer, Artifact Browser, and
the Download Manager's Close button.

## Also removed
The redundant Cancel button on every pure list-picker dialog (Switch
Repository, Create New…, the workflow-trigger picker, the "View log in
app / Download log ZIP" chooser) — these dismiss on outside-tap/back like
any Android dialog already, so the button was just extra oversized weight
for no functional gain.

## Known remaining gap
The multi-select delete picker's outer checklist still uses the platform
button bar (`styleButton`) — `setMultiChoiceItems()` can't be combined with
a custom `setView()` body, so giving it the same treatment would mean
hand-building a checkbox list too. Flagged in code; not done here since it
hasn't come up as visually broken yet.

# Changelog — v36

Fixes v35's dialog buttons ballooning into huge, vertically-stacked bars
(Artifact Browser's Download/Close/Trigger, Build Log's View Log/Refresh/
Trigger, File Manager's Delete/Close/New).

## Root cause
Android's dialog button-bar container (`ButtonBarLayout`) silently switches
from a horizontal row to one full-width button per line the moment the row
doesn't fit in one pass — v35's `styleButton()` padding (16dp/9dp) + margins
(5dp) + icon (16dp) was just wide enough to push 3-button rows like
"DOWNLOAD"/"CLOSE"/"TRIGGER" over that threshold on typical phone widths.

## Fixed
- `styleButton()`: padding 16dp/9dp → 9dp/5dp, icon 16dp → 12dp, margin
  5dp → 3dp, explicit 11.5sp text size, and `minWidth`/`minimumWidth`
  cleared — every 2–3-button combo now comfortably fits on one row as
  properly proportioned pills instead of stacking.
- Download Manager's "📥 Download Manager" title now uses a vector icon
  like every other dialog title, instead of an emoji.
- Two more `.setItems()` dialogs that were missed in v35 — the "View log in
  app / Download log ZIP" chooser (`MainActivity`) and the workflow picker
  (`BuildFlowController`) — now use `IconMenuAdapter` + styled Cancel,
  matching the rest of the app.

# Changelog — v35

Finishes the icon-button pass started in v34: every dialog/chip that still
looked like a bare default Android button (New Folder's Cancel/Create, the
file action menu, Switch Repository, the code editor's Save/Copy/Cancel and
find-in-file arrows, Create New…, and the Download Manager's
Pause/Resume/Cancel row) now gets the same filled, rounded, rippled look as
the handful of dialogs that already had it.

## Root cause
`Theme.App.Dialog` declares `buttonBarPositiveButtonStyle` /
`buttonBarNegativeButtonStyle` / `buttonBarNeutralButtonStyle` to style
dialog buttons via XML, but those attrs are only honored by
androidx.appcompat's own `AlertDialog`. Every dialog in this app is built
with the platform `android.app.AlertDialog`, which silently ignores them —
so any button that wasn't *also* styled in code fell back to the platform's
bare default look. That's why only the few dialogs that already had manual
`getButton(...).setTextColor(...)` calls looked right.

## New shared building blocks (`core/`)
- `ButtonTone` — one enum pairing each semantic action color (green/teal/
  orange/red/blue/purple/surface) with its pill background + text color.
- `styleButton()` — one call to style an `AlertDialog` button-bar button
  with a tone's pill background, vector icon, and spacing.
- `pillButton()` / `iconButton()` — factories for standalone chips/small
  buttons and circular icon-only nav buttons.
- `IconMenuAdapter` — icon-led, rippled row rendering for `setAdapter()`
  dialogs, replacing plain `.setItems()` emoji lists.

These replace five near-duplicate local closures (`actionChip`, `chip`,
`smallBtn`, `filterChip`) that had each drifted to a slightly different flat
rectangle/padding/color, plus the repeated per-dialog styling boilerplate in
FileManagerController/BuildLogViewer/ArtifactBrowser.

## Fixed
- New Folder / New File / Create Repository / Move-Rename / Delete
  (single + multi-select) dialogs: Cancel/Create/Delete now have proper
  filled buttons instead of bare text.
- File action menu (View/Edit, Copy content, Move/Rename, Delete) and
  "Create New…" (New Folder, New File, Upload File): rewritten from
  `.setItems()` emoji lists to icon-led rippled rows.
- Switch Repository: list rows now show a lock/folder icon + branch
  subtitle instead of an emoji-prefixed single line; Cancel is styled.
- Code editor: Save/Copy/Cancel are proper pill buttons; the find-in-file
  ◀ ▶ # controls are now real ripple-backed icon buttons instead of bare
  emoji text with no touch feedback.
- Build log: status filter chips (All/Success/Failed) and the run picker's
  View Log/Trigger/Refresh now match the rest of the app; the in-log search
  bar's prev/next/jump-to-error controls are icon buttons.
- Download Manager: Pause/Resume/Cancel/Retry/Remove are now rounded ripple
  pills with real vector icons instead of flat rectangles with emoji text;
  "Clear finished" and the dialog's Close button are styled too.
- Artifact Browser's Switch Repo/Trigger Build chips and Download/Trigger/
  Close buttons got the same treatment for consistency, even though it
  wasn't reported — it shared the exact same flat-chip code as the File
  Manager.

# Changelog — v31

Bug reports from screenshots, plus four requested improvements: a real
multi-download Download Manager, and UI/feature upgrades to the File
Manager, code editor, and Build Log viewer.

## Fixed
- **Floating label backgrounds looked wrong** on every outlined text field in
  Settings (Personal Access Token, Repository, Branch, Password, Key Alias).
  Root cause: the outlined box's floating-label "cutout" paints its notch
  using whatever background color the field itself is set to, and none of
  them had one set — so it fell back to a color that didn't match
  `dialog_settings.xml`'s real background, leaving a visible mismatched patch
  behind every label. Fixed once, at the style level.
- **The Settings X (close) button silently discarded unsaved edits** —
  only "Save & Close" (a sticky bar at the bottom) actually persisted
  changes; X, and also back-press/tap-outside, just dismissed. Edit your
  branch or repo, close with the far more prominent top-right X, and every
  subsequent action — including triggering a workflow — kept using the old
  values with no indication anything was lost. This is the most likely
  explanation for "can't trigger yml": X now saves too, exactly like
  "Switch Repository" already did.
- Trigger failures now explain *why* a 404 happens (GitHub requires
  `workflow_dispatch:` on the repo's default branch specifically, and can
  take a minute to notice a just-added/edited workflow file) instead of just
  printing the raw HTTP response.

## Added: Download Manager
- A real multi-download manager (📥 in the header): every artifact and
  build-log download is now a tracked, independent task — start several,
  pause/resume/cancel/retry each on its own, and watch live progress for all
  of them at once. Previously only one download could be tracked at a time.
- Downloads no longer block starting a build or another download while in
  progress — they run on their own dedicated 2-worker pool, separate from
  build/API calls.
- Built on the same resumable engine from earlier releases (byte-range
  resume, offline auto-pause, backoff retry, integrity verification) — this
  is a UI and concurrency upgrade around it, not a rewrite of the transfer
  logic itself.

## Improved: File Manager
- File rows now show size (e.g. "YML · 2.3 KB") instead of just the
  extension.
- File icons are now tinted by category (code / config / docs / images)
  instead of one flat color for every file.
- Added a filter box to narrow down a folder's contents by name — useful
  once a folder (e.g. `.github/workflows/`) has more than a few files.

## Improved: Code Editor
- Added lightweight syntax highlighting (comments, strings, numbers,
  `key:`/`key =` declarations) — applied once when a file opens, not live on
  every keystroke, to avoid lag on large files.
- Added find-in-file (next/prev match, match count) and Go to Line.

## Improved: Build Log Viewer
- Log lines are now color-coded — errors in red, warnings in amber — instead
  of one flat color for the entire log, plus a "jump to first error" shortcut.
- Added find-in-log (next/prev match, match count).
- The workflow-runs list can now be filtered to All / ✅ Success / ❌ Failed,
  useful once a repo has dozens of runs.

---

# Changelog — v30

A UI bug fix, reported with a screenshot: the "Clear" buttons in Settings
(Download History / Build History) were rendering with garbled, overlapping
text.

## Fixed
- **Root cause:** `Widget.App.Button.Chip` (used by these Clear buttons, plus
  Copy/Share on the main screen) is a `MaterialButton` style, which reserves
  its own vertical inset/padding space on top of whatever height it's given.
  Several buttons using this style had an explicit `layout_height` (26dp for
  Clear, 30dp for Copy/Share) *smaller* than the style's own declared
  `minHeight` (34dp) — squeezing the text into less space than it needed and
  corrupting how it drew. Fixed at the style level (explicit
  `insetTop`/`insetBottom`/`paddingTop`/`paddingBottom` = 0dp) and by changing
  all 4 affected buttons to `wrap_content`, so the style's own sizing applies
  cleanly instead of fighting a smaller forced height. Copy/Share weren't
  reported as broken, but shared the identical mismatch and were fixed
  alongside rather than left as a latent version of the same bug.

## Improved (while already in this section)
- **Clearing history had no confirmation at all** — a single tap permanently
  wiped every download or build history entry with no "are you sure?" and no
  undo. Both Clear buttons now confirm first, stating exactly how many
  entries will be removed.
- The two Clear buttons are now tinted with the app's existing muted-red
  `text_error` color (previously the same neutral gray as Copy/Share),
  visually distinguishing a destructive, irreversible action from a neutral
  utility one.

---

# Changelog — v29

One focused addition: background build tracking + notifications.

## Added
- **Background build tracking.** A build no longer needs the app to stay in
  the foreground to keep going — a low-priority "Building… [live status]"
  notification now runs for the duration of a build, which keeps the app
  process (and its existing polling) alive if you switch away. When the
  build finishes, that's replaced with a dismissible result notification
  ("✓ Build succeeded" / "✗ Build failed") that reopens the app when tapped.
  A user-cancelled build intentionally does *not* post a result notification
  — you're already looking at the app when you cancel something.
- New `BuildTrackingService` (a small foreground service — deliberately just
  a notification/keep-alive shell, not a second copy of the existing
  build-polling logic, which stays exactly where it was in `MainActivity`).
- Requests the Android 13+ notification permission contextually, the first
  time a build starts (not on app launch) — following the same
  request-lazily-with-a-stored-pending-action pattern already used for the
  Android 7–9 storage permission. If denied, the build proceeds exactly as
  before; only the notification itself is skipped.

## Changed
- `versionCode`/`versionName` 28 → 29.
- Manifest: added `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_DATA_SYNC`, and
  `POST_NOTIFICATIONS` permissions, and declared the new (non-exported)
  service.

No existing behavior, screen, or dialog changed — this only adds a system
notification, which sits outside the app's own UI. Full detail in
`FEATURES_ADDED.md` and `FILE_CHANGES.md`.

---

# Changelog — v28

A network-reliability and bug-review release. The headline change is a real
resumable download engine (byte-level HTTP Range resume, automatic pause/
resume on connectivity loss, exponential-backoff retry) replacing the v27
download loop, which had none of that. Everything else is a targeted fix or
addition on top of the existing single-Activity design — no rewrites.

## Fixed
- **A cold-start cleanup sweep could delete a download you were about to
  resume.** The same 2-minute-old sweep that correctly clears truly-orphaned
  temp files was, before this release, also applied to resumable download
  partials — so closing the app and coming back more than 2 minutes later
  could silently erase your progress before you ever saw a Resume option.
  Partial downloads now get a 7-day grace window; only the always-ephemeral
  APK-info scratch file keeps the short 2-minute sweep. See `BUGS_FIXED.md`.
- **A stale/mismatched partial download could get stuck failing forever.**
  If the server ever rejects a resume (`HTTP 416 Range Not Satisfiable` —
  e.g. the partial no longer matches what the server has), the download now
  discards that one partial file and restarts once, instead of failing with
  no path forward.
- **Two file-read paths crashed with a raw `NullPointerException`** (reading
  a user-picked project ZIP, and uploading a single file from the file
  browser) if the picked file had been moved/deleted/revoked since selection.
  Both now surface a clear, actionable message instead.
- **"Use Existing" on an already-configured keystore could store the wrong
  alias.** GitHub never reveals a Secret's value, so the app never actually
  knew the real alias of a keystore that already existed remotely — it was
  storing whatever was currently typed (or freshly generated) in the alias
  field instead, which could mislabel the Settings display. It now shows the
  verified filename instead of guessing an alias.
- **A stray, misplaced doc comment** (describing `saveZipToDownloads`) had
  ended up sitting in front of an unrelated function, `logApkInfoFromZip`,
  after an earlier refactor split that function apart. Moved back to the
  function it actually documents.
- Verified every v27 fix in `BUGS_FIXED.md` against the current source; all
  still hold (see `REVIEW_REPORT.md` for the specific checks performed).

## Network Reliability & Download Resume
This is the main focus of v28 — see `V28_RELEASE_NOTES.md` for the full
write-up. Summary:
- Byte-level resume via HTTP `Range` requests whenever the server supports
  them; deterministic per-artifact/per-run file naming so a retry — manual,
  automatic, or after fully restarting the app — continues the same partial
  file instead of starting at 0%.
- Automatic network-loss detection (`ConnectivityManager`): a download pauses
  itself, shows "Paused (No Internet)", and resumes the instant connectivity
  returns — no user action required.
- Exponential-backoff automatic retry (2s → 4s → 8s… capped at 30s, 5 attempts)
  for transient server errors (HTTP 429/500/502/503/504) and I/O errors that
  happen while the network still tests as reachable.
- A manual Retry button appears after retries are exhausted, reusing the same
  partial bytes rather than discarding them.
- Speed, ETA, and remaining-bytes now shown during download (previously just
  downloaded/total and instantaneous speed).
- The same reliability policy (offline-wait + backoff retry) now also covers
  **uploads** — previously any network hiccup during upload failed the whole
  build immediately with no retry at all. True byte-resume isn't meaningful
  for GitHub's upload APIs (no partial-request support), so a failed upload
  retries the attempt from scratch — safe here because blobs/trees are
  content-addressed and a retried commit just adds one small extra commit,
  never corrupting anything.
- New downloaded-ZIP integrity verification (full CRC-32 re-check) — see
  Features below.

## Performance
- The live build-log streamer's full-log print (which can be hundreds or
  thousands of lines for a verbose Gradle build) now cleans and joins every
  line into a single log append instead of one `Handler.post` per line —
  same resulting text, far fewer main-thread posts for a large build.
- Consolidated two independent copies of the same three log-cleaning regexes
  (ANSI-code strip, timestamp strip, group-marker match) — one in the live
  build streamer, one in the saved-run log viewer — into shared, compiled-
  once fields, used by both.
- Confirmed release-build R8 code shrinking + resource shrinking are enabled
  with a minimal, correct keep-rule set (see `PERFORMANCE_REPORT.md` and
  `proguard-rules.pro`) — this app has no reflection-based (de)serialization
  or WebView JS interface, so very little needed to be kept.

## Reliability & Quality of Life
- Downloaded ZIPs (both the build artifact and the build-log archive) are now
  verified byte-for-byte (CRC-32 per entry, via a full re-read) before being
  saved to Downloads or reported as successful. A corrupted/truncated result
  is deleted and offered for retry instead of being silently handed to the
  user as if it succeeded.
- Download progress now also shows remaining bytes alongside downloaded/total.

## Code Quality
- Removed the last 2 unguarded `!!` non-null assertions on user-file I/O in
  favor of a clear thrown message (`openInputStreamOrThrow` /
  `openOutputStreamOrThrow`), reused at all 4 call sites that previously each
  wrote their own `contentResolver.open*Stream(uri)!!`.
- Generalized `sleepCancellable()` and `waitForNetwork()` to take which
  cancellation flag to watch (defaulting to the download flag, so every
  existing call site is unaffected) instead of duplicating both functions for
  the new upload-retry path.
- Verified there are no unused imports or unreferenced private functions
  anywhere in the file (checked systematically — see `REVIEW_REPORT.md`).

See `BUGS_FIXED.md`, `PERFORMANCE_REPORT.md`, `FEATURES_ADDED.md`,
`FILE_CHANGES.md`, `REVIEW_REPORT.md`, and `KNOWN_LIMITATIONS.md` for full
detail on each item above.

---

# Changelog — v27

A performance, reliability, quality-of-life, and feature update. No architectural
rewrites — every change is a targeted fix or addition on top of the existing
single-Activity design.

## Fixed
- **Owner chip showed even when it shouldn't.** Missing braces on an `if` meant
  `tvOwnerInfo.visibility = VISIBLE` ran unconditionally instead of only when
  `savedOwner` was actually set. See `BUGS_FIXED.md`.
- **New-repo creation waited up to ~18s longer than necessary.** A
  `repeat(10) { return@repeat }` loop can't actually break early —
  `return@repeat` just skips to the next iteration — so after the repo became
  reachable, the code kept sleeping and polling anyway. Now breaks immediately.
- **File editor lagged while typing in any reasonably large file.** The
  line-number gutter recomputed the entire line count on every keystroke.
  Now it only recomputes when the edit actually spans a newline.
- **Downloaded-file path could be wrong.** On a filename collision, Android's
  MediaStore silently renames the file (`name (1).zip`); the app used to
  report the originally-requested name regardless. It now queries the name
  MediaStore actually used.
- **One failed item could silently cancel an entire batch delete.** Deleting
  multiple files/folders at once now continues through all selected items
  even if one fails, and reports a clear summary at the end.
- **A temp file leaked into the cache on every artifact download.** The
  downloaded artifact ZIP was copied to Downloads but never removed from
  `cacheDir` afterward — every download left a permanent copy behind.
- **Duplicate/inconsistent byte-formatting.** Four separate implementations
  of "format bytes as KB/MB/GB" existed with different rounding and no GB
  tier on three of them. Unified into one.

## Performance
- Replaced 25 ad hoc `thread { }` spawns with a single shared, bounded
  (4-thread) background executor — less thread-creation overhead and memory
  per action, with enough concurrency that a long build never blocks
  unrelated actions like Browse Artifacts.
- `appendLog()` no longer queues a separate scroll pass for every streamed
  build-log line — bursts now coalesce into a single pending scroll.
- The console log now has a length cap (~200k characters) so a very long or
  looping build, or a long multi-build session, can't grow it unbounded.
- Added `android:largeHeap="true"` — uploading a project ZIP can briefly hold
  several full in-memory copies (raw bytes, Base64 string, JSON payload, UTF-8
  bytes); for a large ZIP this can approach the default per-app heap ceiling
  on a low-RAM device.
- `downloadArtifact()` no longer hand-builds its own ~115-line copy of the
  download-progress dialog; it reuses the same builder `downloadLatestRunLogs()`
  already relies on.
- Reviewed the embedded GitHub Actions workflow for build-speed opportunities.
  It already uses `setup-gradle` dependency caching, dedicated NDK/CMake
  caching, hash-keyed incremental C++ build caching, and
  `--configuration-cache --build-cache --parallel` — left untouched rather
  than adding redundant caching on top of what's already there.

## Reliability & Quality of Life
- **Pre-upload ZIP validation**: peeks the ZIP's entry list (already in memory,
  no extra I/O) for `settings.gradle(.kts)` and `gradlew` before uploading, and
  warns if either is missing — catching the most common "wrong ZIP" mistake
  before spending an upload and a full CI run on it.
- **Storage space check** before artifact/log downloads start, so a large file
  fails fast with a clear message instead of partway through.
- **Friendlier network error messages** (no internet, timeout, TLS/date issue,
  unreachable host) for the main build flow.
- **Automatic cleanup of leftover temp files** from a previous session that was
  killed before its own cleanup ran — swept once on cold start.
- **`onDestroy()` added** — shuts the background executor down and stops the
  status-dot animations, where previously nothing was cleaned up at all.
- Large ZIP (>40MB) uploads now log an upfront note that the upload will hold
  the file fully in memory and may take a while.
- `versionCode`/`versionName` now actually track the app's real version history
  (was frozen at `1` / `"1.0"` since the very first release, through 26 prior
  versions).

## New Features
- **Build History** (Settings → Build History): the last 30 builds triggered
  from this device, with outcome, repo/branch, duration, and time — recorded
  locally, no network call needed to view it.
- **Build Statistics**: a one-line summary (success rate, average successful
  build duration) computed from that same local history.
- **Build Duration Timer**: every build now measures and logs its own
  end-to-end elapsed time.
- **APK Info Viewer**: after a successful artifact download, the app peeks
  inside the ZIP for the `.apk` and logs its package name, version, min/target
  SDK, and size — a quick sanity check without installing it first.

## Code Quality
- Removed 2 fields (`btnDownloadLogs`, `btnSavedRepos`) that were declared,
  always null, and never read anywhere.
- Removed 3 duplicate local `fmtBytes()` copies (kept the one class-level
  version; all call sites are unaffected).
- Removed ~115 lines of duplicated dialog-construction code from
  `downloadArtifact()`.
- Removed the now-unused `kotlin.concurrent.thread` import.
- Verified there are no unused imports anywhere in the file (checked
  systematically, not spot-checked).

See `BUGS_FIXED.md`, `PERFORMANCE_REPORT.md`, `FEATURES_ADDED.md`, and
`FILE_CHANGES.md` for full detail on each item above.
