package com.hazardyard.game.settings;

import android.content.SharedPreferences;

import com.hazardyard.game.core.MathUtil;

/** Reads and writes {@link GameSettings} with SharedPreferences. Unknown or missing keys keep their defaults. */
public final class SettingsStore {
    private static final String K_X = "ctl_x";
    private static final String K_Y = "ctl_y";
    private static final String K_SCALE = "ctl_scale";
    private static final String K_MOVE_FLOAT = "ctl_move_floating";
    private static final String K_AIM_FLOAT = "ctl_aim_floating";
    private static final String K_FIRE_MODE = "ctl_fire_mode";
    private static final String K_DEAD_ZONE = "ctl_dead_zone";
    private static final String K_OPACITY = "ctl_opacity";
    private static final String K_MODELS_3D = "gfx_models3d";
    private static final String K_SOUND_ON = "sfx_on";
    private static final String K_VOLUME = "sfx_volume";

    private SettingsStore() {}

    public static GameSettings load(SharedPreferences p) {
        GameSettings g = new GameSettings();
        ControlSettings c = g.controls;
        for (int i = 0; i < ControlSettings.COUNT; i++) {
            c.x[i] = p.getFloat(K_X + i, c.x[i]);
            c.y[i] = p.getFloat(K_Y + i, c.y[i]);
            c.scale[i] = p.getFloat(K_SCALE + i, c.scale[i]);
        }
        c.moveFloating = p.getBoolean(K_MOVE_FLOAT, c.moveFloating);
        c.aimFloating = p.getBoolean(K_AIM_FLOAT, c.aimFloating);
        c.fireMode = p.getInt(K_FIRE_MODE, c.fireMode);
        c.aimDeadZone = p.getFloat(K_DEAD_ZONE, c.aimDeadZone);
        c.opacity = p.getFloat(K_OPACITY, c.opacity);
        c.sanitize();
        g.models3d = p.getBoolean(K_MODELS_3D, g.models3d);
        g.soundOn = p.getBoolean(K_SOUND_ON, g.soundOn);
        float v = p.getFloat(K_VOLUME, g.volume);
        g.volume = MathUtil.isFinite(v) ? MathUtil.clamp(v, 0f, 1f) : 0.8f;
        return g;
    }

    public static void save(SharedPreferences p, GameSettings g) {
        ControlSettings c = g.controls;
        SharedPreferences.Editor e = p.edit();
        for (int i = 0; i < ControlSettings.COUNT; i++) {
            e.putFloat(K_X + i, c.x[i]);
            e.putFloat(K_Y + i, c.y[i]);
            e.putFloat(K_SCALE + i, c.scale[i]);
        }
        e.putBoolean(K_MOVE_FLOAT, c.moveFloating);
        e.putBoolean(K_AIM_FLOAT, c.aimFloating);
        e.putInt(K_FIRE_MODE, c.fireMode);
        e.putFloat(K_DEAD_ZONE, c.aimDeadZone);
        e.putFloat(K_OPACITY, c.opacity);
        e.putBoolean(K_MODELS_3D, g.models3d);
        e.putBoolean(K_SOUND_ON, g.soundOn);
        e.putFloat(K_VOLUME, g.volume);
        e.apply();
    }
}
