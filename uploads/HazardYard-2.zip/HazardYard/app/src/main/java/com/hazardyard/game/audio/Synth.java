package com.hazardyard.game.audio;

/**
 * Tiny sound-design toolkit: oscillators with pitch sweeps, filtered noise, envelopes, echo and soft
 * clipping, all working on mono float buffers. Everything is deterministic (the noise generator is
 * seeded) so a sound always comes out the same. Pure Java, no Android types.
 */
final class Synth {
    private Synth() {}

    static final int RATE = 44100;
    private static final float TWO_PI = (float) (Math.PI * 2.0);

    static float[] buffer(float seconds) {
        return new float[Math.max(1, Math.round(seconds * RATE))];
    }

    // ------------------------------------------------------------------ noise

    /** Seeded white noise in [-1, 1). */
    static final class Noise {
        private int s;

        Noise(int seed) {
            s = seed == 0 ? 0x2545F491 : seed;
        }

        float next() {
            s ^= s << 13;
            s ^= s >>> 17;
            s ^= s << 5;
            return (s >> 8) * (1f / 8388608f);
        }
    }

    // ------------------------------------------------------------------ envelopes

    /** Exponential decay with the given time constant (seconds) after {@code t0}. */
    static float decay(float t, float t0, float tau) {
        return t < t0 ? 0f : (float) Math.exp(-(t - t0) / tau);
    }

    /** Linear fade-in over {@code attack} seconds, then exponential decay. */
    static float attackDecay(float t, float attack, float tau) {
        float a = attack <= 0f ? 1f : Math.min(1f, t / attack);
        return a * (float) Math.exp(-t / tau);
    }

    // ------------------------------------------------------------------ filters (in place)

    static void lowPass(float[] b, float cutoffHz) {
        float a = 1f - (float) Math.exp(-TWO_PI * cutoffHz / RATE);
        float y = 0f;
        for (int i = 0; i < b.length; i++) {
            y += a * (b[i] - y);
            b[i] = y;
        }
    }

    static void highPass(float[] b, float cutoffHz) {
        float a = 1f - (float) Math.exp(-TWO_PI * cutoffHz / RATE);
        float y = 0f;
        for (int i = 0; i < b.length; i++) {
            y += a * (b[i] - y);
            b[i] -= y;
        }
    }

    static void bandPass(float[] b, float lowHz, float highHz) {
        lowPass(b, highHz);
        highPass(b, lowHz);
    }

    // ------------------------------------------------------------------ generators (added into dst)

    /**
     * Adds a noise burst shaped by an exponential decay, filtered to [lowHz, highHz]. Starts at
     * {@code t0} seconds into the buffer.
     */
    static void addNoise(float[] dst, Noise n, float t0, float tau, float amp, float lowHz, float highHz) {
        int start = Math.min(dst.length, Math.round(t0 * RATE));
        int len = Math.min(dst.length - start, Math.round(tau * 8f * RATE));
        if (len <= 0) return;
        float[] tmp = new float[len];
        for (int i = 0; i < len; i++) tmp[i] = n.next();
        if (highHz > 0f) lowPass(tmp, highHz);
        if (lowHz > 0f) highPass(tmp, lowHz);
        for (int i = 0; i < len; i++) {
            float t = i / (float) RATE;
            dst[start + i] += tmp[i] * amp * (float) Math.exp(-t / tau);
        }
    }

    /**
     * Adds a sine whose frequency glides exponentially from {@code f0} to {@code f1} (rate
     * {@code sweep} per second), with a decaying amplitude.
     */
    static void addSweep(float[] dst, float t0, float tau, float amp, float f0, float f1, float sweep) {
        int start = Math.min(dst.length, Math.round(t0 * RATE));
        int len = Math.min(dst.length - start, Math.round(tau * 8f * RATE));
        float phase = 0f;
        for (int i = 0; i < len; i++) {
            float t = i / (float) RATE;
            float f = f1 + (f0 - f1) * (float) Math.exp(-t * sweep);
            phase += TWO_PI * f / RATE;
            dst[start + i] += (float) Math.sin(phase) * amp * (float) Math.exp(-t / tau);
        }
    }

    /** Adds a steady tone (sine blended with a saw for a buzzier edge) with an attack/decay envelope. */
    static void addTone(float[] dst, float t0, float attack, float tau, float amp, float freq, float sawMix) {
        int start = Math.min(dst.length, Math.round(t0 * RATE));
        int len = Math.min(dst.length - start, Math.round((attack + tau * 8f) * RATE));
        float phase = 0f;
        for (int i = 0; i < len; i++) {
            float t = i / (float) RATE;
            phase += TWO_PI * freq / RATE;
            float cycle = (phase / TWO_PI) % 1f;
            float saw = 2f * cycle - 1f;
            float s = (float) Math.sin(phase) * (1f - sawMix) + saw * sawMix;
            dst[start + i] += s * amp * attackDecay(t, attack, tau);
        }
    }

    // ------------------------------------------------------------------ effects (in place)

    /** Feed-forward echo: adds delayed, attenuated copies of the signal. */
    static void echo(float[] b, float delaySeconds, float gain, int taps) {
        int d = Math.round(delaySeconds * RATE);
        for (int tap = taps; tap >= 1; tap--) {
            float g = (float) Math.pow(gain, tap);
            int shift = d * tap;
            for (int i = b.length - 1; i >= shift; i--) b[i] += b[i - shift] * g;
        }
    }

    /** Soft clipping: {@code drive} above 1 adds punch and harmonics. */
    static void saturate(float[] b, float drive) {
        float norm = 1f / (float) Math.tanh(drive);
        for (int i = 0; i < b.length; i++) b[i] = (float) Math.tanh(b[i] * drive) * norm;
    }

    /** Fades the last milliseconds to zero so the sound can never end with a click. */
    static void fadeOut(float[] b, float seconds) {
        int n = Math.min(b.length, Math.round(seconds * RATE));
        for (int i = 0; i < n; i++) b[b.length - 1 - i] *= i / (float) n;
    }

    /** Scales so the loudest sample is exactly {@code peak}. */
    static void normalize(float[] b, float peak) {
        float max = 0f;
        for (float v : b) max = Math.max(max, Math.abs(v));
        if (max < 1e-6f) return;
        float k = peak / max;
        for (int i = 0; i < b.length; i++) b[i] *= k;
    }

    static short[] toPcm(float[] b) {
        short[] out = new short[b.length];
        for (int i = 0; i < b.length; i++) {
            float v = Math.max(-1f, Math.min(1f, b[i]));
            out[i] = (short) Math.round(v * 32767f);
        }
        return out;
    }
}
