package com.hazardyard.game.ui;

import android.content.Context;
import android.content.res.ColorStateList;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import com.hazardyard.game.render.Palette;

/** A titled slider with a live value read-out, mapping a float range onto a SeekBar. */
final class SliderRow extends LinearLayout {
    interface OnValue {
        void onValue(float value);
    }

    interface Format {
        String of(float value);
    }

    private static final int STEPS = 1000;

    private final float min;
    private final float max;
    private final Format format;
    private final TextView titleText;
    private final TextView valueText;
    private final SeekBar bar;
    private final OnValue listener;

    SliderRow(Context c, String title, float min, float max, float value, Format format, OnValue listener) {
        super(c);
        this.min = min;
        this.max = max;
        this.format = format;
        this.listener = listener;
        setOrientation(VERTICAL);

        LinearLayout head = new LinearLayout(c);
        head.setOrientation(HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        titleText = Ui.label(c, title, 13f, Palette.TEXT_DIM, false);
        head.addView(titleText, Ui.lp(0, LayoutParams.WRAP_CONTENT, 1f, 0, 0, 0, 0, c));
        valueText = Ui.label(c, "", 13f, Palette.TEXT, true);
        valueText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f);
        head.addView(valueText);
        addView(head, Ui.fillWidth(c, 0));

        bar = new SeekBar(c);
        bar.setMax(STEPS);
        bar.setProgressTintList(ColorStateList.valueOf(Palette.ACCENT));
        bar.setThumbTintList(ColorStateList.valueOf(Palette.ACCENT));
        bar.setProgressBackgroundTintList(ColorStateList.valueOf(0xFF3A4757));
        setValue(value);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int progress, boolean fromUser) {
                float v = SliderRow.this.min + (SliderRow.this.max - SliderRow.this.min) * progress / STEPS;
                valueText.setText(SliderRow.this.format.of(v));
                if (fromUser) SliderRow.this.listener.onValue(v);
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {}

            @Override
            public void onStopTrackingTouch(SeekBar s) {}
        });
        addView(bar, Ui.lp(LayoutParams.MATCH_PARENT, Ui.dp(c, 36), 0f, 0, 2, 0, 0, c));
    }

    void setTitle(String title) {
        titleText.setText(title);
    }

    /** A disabled slider is dimmed and ignores touches. */
    void setSliderEnabled(boolean enabled) {
        bar.setEnabled(enabled);
        setAlpha(enabled ? 1f : 0.45f);
    }

    void setValue(float value) {
        float clamped = Math.max(min, Math.min(max, value));
        bar.setProgress(Math.round((clamped - min) / (max - min) * STEPS));
        valueText.setText(format.of(clamped));
    }

    /** "85%" style read-out for a 0..1 value. */
    static Format percent() {
        return new Format() {
            @Override
            public String of(float v) {
                return Math.round(v * 100f) + "%";
            }
        };
    }
}
