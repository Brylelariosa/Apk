package com.hazardyard.game.engine;

import com.hazardyard.game.bot.BotBrain;
import com.hazardyard.game.bot.BotDifficulty;
import com.hazardyard.game.bot.NavGrid;
import com.hazardyard.game.bot.PathFinder;
import com.hazardyard.game.core.GameConfig;
import com.hazardyard.game.core.GameState;
import com.hazardyard.game.core.GameWorld;
import com.hazardyard.game.core.LocalInput;
import com.hazardyard.game.core.MapLibrary;
import com.hazardyard.game.core.Player;
import com.hazardyard.game.core.WeaponDef;
import com.hazardyard.game.core.WorldListener;

/**
 * A match against computer opponents, no network involved. The player is slot 0 and the bots fill
 * the next slots. The rules run in the same {@link GameWorld} as a hosted game, so a solo match plays
 * exactly like a multiplayer one; pausing really freezes it.
 */
public final class SoloEngine implements GameEngine, WorldListener {
    private static final String[] BOT_NAMES = {"Rex", "Nova", "Viper", "Blitz"};

    private final GameState st;
    private final GameWorld world;
    private final BotBrain[] brains;
    private volatile boolean finished;
    private volatile boolean paused;

    /**
     * @param botCount   1..3 computer opponents
     * @param difficulty a {@link BotDifficulty} level
     */
    public SoloEngine(int mapId, int botCount, int difficulty, String playerName, int seed) {
        st = new GameState(MapLibrary.get(mapId), 0);
        world = new GameWorld(st, this);
        botCount = Math.max(1, Math.min(GameConfig.MAX_PLAYERS - 1, botCount));
        world.addPlayer(0, playerName);
        NavGrid nav = new NavGrid(st.map);
        PathFinder paths = new PathFinder(nav);
        BotDifficulty diff = BotDifficulty.of(difficulty);
        brains = new BotBrain[botCount];
        for (int i = 0; i < botCount; i++) {
            int slot = i + 1;
            world.addPlayer(slot, BOT_NAMES[i % BOT_NAMES.length]);
            brains[i] = new BotBrain(slot, st, world, nav, paths, diff, seed + i);
        }
        world.startMatch();
    }

    @Override
    public GameState state() {
        return st;
    }

    @Override
    public void fixedUpdate(float dt, LocalInput in) {
        if (finished) return;
        if (!paused) {
            world.setInput(0, in.moveX, in.moveY, in.aim, in.firing, 0);
            if (in.reload) world.requestReload(0);
            for (BotBrain b : brains) b.think(dt);
            world.step(dt);
        }
        for (int i = 0; i < st.players.length; i++) {
            Player p = st.players[i];
            if (!p.connected) continue;
            p.rx = p.x;
            p.ry = p.y;
            p.rAim = p.aim;
        }
        if (!paused) st.effects.update(dt);
        if (st.phase == GameState.PHASE_FINISHED) finished = true;
    }

    @Override
    public void frameUpdate(float dt) {
        // The authoritative state is also the drawn state; nothing to smooth.
    }

    @Override
    public boolean isFinished() {
        return finished;
    }

    @Override
    public String finishReason() {
        return null;
    }

    @Override
    public int pingMs() {
        return 0;
    }

    @Override
    public void setPaused(boolean p) {
        paused = p;
    }

    @Override
    public void close() {
        finished = true;
    }

    // ------------------------------------------------------------------ WorldListener

    @Override
    public void onShot(Player shooter, WeaponDef def, float x, float y, float angle, int seed, int baseId) {
        Presentation.shot(st, def.id, x, y, angle);
    }

    @Override
    public void onProjectileHit(int projectileId, int victimId, float x, float y, int damage, int weaponId) {
        Presentation.hit(st, victimId, x, y, weaponId, damage);
    }

    @Override
    public void onWallImpact(float x, float y, int weaponId) {
        Presentation.wallImpact(st, x, y, weaponId);
    }

    @Override
    public void onKill(int killerId, int victimId, int weaponId) {
        Presentation.kill(st, killerId, victimId, weaponId);
    }
}
