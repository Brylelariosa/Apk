package com.hazardyard.game.audio;

import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.os.Process;

import com.hazardyard.game.core.Sounds;
import com.hazardyard.game.core.SoundSink;
import com.hazardyard.game.settings.GameSettings;

import java.util.Random;

/**
 * Plays the synthesised sounds: a background thread keeps one low-latency {@link AudioTrack} fed with
 * whatever the {@link Mixer} produces. Sources are placed relative to the listener (quieter and
 * panned left/right by distance), and every shot gets a tiny random pitch change.
 *
 * <p>If the device refuses to open an audio track the engine silently stays mute: sound is never
 * worth crashing the game for.
 */
public final class SoundEngine implements SoundSink {
    private static final int CHUNK_FRAMES = 512;
    /** Distance at which a normal sound is half as loud. */
    private static final float HALF_VOLUME_DISTANCE = 230f;
    /** Horizontal distance at which a source is panned fully to one side. */
    private static final float FULL_PAN_DISTANCE = 380f;
    private static final float SQRT2 = 1.41421356f;

    private final Mixer mixer;
    private final GameSettings settings;
    private final Random pitch = new Random(7);
    private final Object lifecycle = new Object();
    private volatile boolean running;
    private volatile float listenerX;
    private volatile float listenerY;
    private AudioTrack track;
    private Thread thread;

    public SoundEngine(GameSettings settings) {
        this.settings = settings;
        int[] gaps = new int[Sounds.COUNT];
        gaps[Sounds.IMPACT] = 45;
        gaps[Sounds.HIT] = 30;
        gaps[Sounds.KILL] = 60;
        gaps[Sounds.RELOAD] = 120;
        gaps[Sounds.PICKUP] = 120;
        this.mixer = new Mixer(SoundBank.build(), gaps);
    }

    /** Opens the audio output and starts feeding it. Safe to call again after {@link #stop}. */
    public void start() {
        synchronized (lifecycle) {
            if (running) return;
            try {
                int rate = mixer.sampleRate();
                int minBytes = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT);
                int bytes = Math.max(minBytes, CHUNK_FRAMES * 4 * 3);
                track = new AudioTrack.Builder()
                        .setAudioAttributes(new AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_GAME)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                                .build())
                        .setAudioFormat(new AudioFormat.Builder()
                                .setSampleRate(rate)
                                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                                .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                                .build())
                        .setBufferSizeInBytes(bytes)
                        .setTransferMode(AudioTrack.MODE_STREAM)
                        .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
                        .build();
                track.play();
            } catch (RuntimeException | LinkageError e) {
                release();
                return;
            }
            running = true;
            final AudioTrack t = track;
            thread = new Thread(() -> pump(t), "hazardyard-audio");
            thread.setDaemon(true);
            thread.start();
        }
    }

    /** Stops the audio thread and releases the output. */
    public void stop() {
        Thread t;
        synchronized (lifecycle) {
            if (!running && track == null) return;
            running = false;
            t = thread;
            thread = null;
        }
        if (t != null) {
            try {
                t.join(500);
            } catch (InterruptedException ie) {
                Thread.currentThread().interrupt();
            }
        }
        synchronized (lifecycle) {
            release();
        }
        mixer.silence();
    }

    private void release() {
        AudioTrack t = track;
        track = null;
        if (t == null) return;
        try {
            t.stop();
        } catch (RuntimeException ignored) {
            // Already stopped or never started.
        }
        t.release();
    }

    private void pump(AudioTrack t) {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO);
        short[] buf = new short[CHUNK_FRAMES * 2];
        try {
            while (running) {
                mixer.mix(buf, CHUNK_FRAMES);
                int written = t.write(buf, 0, buf.length);
                if (written < 0) break;
            }
        } catch (RuntimeException e) {
            // The track was released under us (screen closing): just end the thread.
        }
    }

    // ------------------------------------------------------------------ SoundSink

    @Override
    public void setListener(float x, float y) {
        listenerX = x;
        listenerY = y;
    }

    @Override
    public void play(int sound, float x, float y, float volume) {
        if (!running || !settings.soundOn) return;
        float dx = x - listenerX;
        float dy = y - listenerY;
        float dist = (float) Math.sqrt(dx * dx + dy * dy);
        float k = dist / (HALF_VOLUME_DISTANCE * SoundBank.carry(sound));
        float gain = volume * SoundBank.level(sound) * settings.volume / (1f + k * k);
        if (gain < 0.01f) return;
        float pan = Math.max(-1f, Math.min(1f, dx / FULL_PAN_DISTANCE)) * 0.8f;
        float angle = (pan + 1f) * (float) (Math.PI / 4.0);
        float left = gain * (float) Math.cos(angle) * SQRT2;
        float right = gain * (float) Math.sin(angle) * SQRT2;
        float speed = 1f + (pitch.nextFloat() - 0.5f) * 0.08f;
        mixer.trigger(sound, left, right, speed);
    }
}
