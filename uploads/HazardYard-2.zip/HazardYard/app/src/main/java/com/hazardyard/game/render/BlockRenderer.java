package com.hazardyard.game.render;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;

import com.hazardyard.game.core.GameConfig;
import com.hazardyard.game.core.TileMap;
import com.hazardyard.game.render.model.Projection;

/**
 * Draws walls, crates and fences as boxes with real height, using the same oblique projection as the
 * 3D models: a lit top, a south face and a west face. Faces that touch a neighbouring wall are
 * skipped, so a long wall reads as one solid. Blocks must be drawn in {@link TileMap#blocks} order
 * (south edge first) so closer ones overlap farther ones.
 */
final class BlockRenderer {
    static final float WALL_H = 24f;
    static final float CRATE_H = 15f;
    static final float FENCE_H = 9f;
    private static final float T = GameConfig.TILE;
    private static final float SHADOW_X = 0.35f;
    private static final float SHADOW_Y = 0.28f;

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final float[] segs = new float[512];

    BlockRenderer() {
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.ROUND);
    }

    /** Kinds that are drawn as boxes here (pools are part of the floor). */
    static boolean isBox(int kind) {
        return kind == TileMap.WALL || kind == TileMap.CRATE || kind == TileMap.FENCE;
    }

    static float heightOf(int kind) {
        return kind == TileMap.WALL ? WALL_H : (kind == TileMap.CRATE ? CRATE_H : FENCE_H);
    }

    /** True when the block at index {@code b} can touch the visible rectangle (with room for its height). */
    static boolean inView(TileMap map, int b, float vx0, float vx1, float vy0, float vy1) {
        int o = b * 5;
        float h = heightOf(map.blocks[o + 4]);
        float x0 = map.blocks[o] * T;
        float y0 = map.blocks[o + 1] * T;
        float x1 = x0 + map.blocks[o + 2] * T + Projection.LEAN * h + SHADOW_X * h;
        float y1 = y0 + map.blocks[o + 3] * T + SHADOW_Y * h;
        return !(x1 < vx0 || x0 > vx1 || y1 < vy0 || y0 - Projection.TILT * h > vy1);
    }

    // ------------------------------------------------------------------ shadows

    void drawShadows(Canvas c, TileMap map, float vx0, float vx1, float vy0, float vy1) {
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(0x44000000);
        for (int b = 0; b < map.blockCount; b++) {
            int o = b * 5;
            int kind = map.blocks[o + 4];
            if (kind != TileMap.WALL && kind != TileMap.CRATE) continue;
            if (!inView(map, b, vx0, vx1, vy0, vy1)) continue;
            float h = heightOf(kind);
            float dx = SHADOW_X * h;
            float dy = SHADOW_Y * h;
            float x0 = map.blocks[o] * T;
            float y0 = map.blocks[o + 1] * T;
            float x1 = x0 + map.blocks[o + 2] * T;
            float y1 = y0 + map.blocks[o + 3] * T;
            path.reset();
            path.moveTo(x0, y0);
            path.lineTo(x1, y0);
            path.lineTo(x1 + dx, y0 + dy);
            path.lineTo(x1 + dx, y1 + dy);
            path.lineTo(x0 + dx, y1 + dy);
            path.lineTo(x0, y1);
            path.close();
            c.drawPath(path, fill);
        }
    }

    // ------------------------------------------------------------------ boxes

    void draw(Canvas c, TileMap map, MapTheme th, int b) {
        int o = b * 5;
        int bx = map.blocks[o];
        int by = map.blocks[o + 1];
        int bw = map.blocks[o + 2];
        int bh = map.blocks[o + 3];
        int kind = map.blocks[o + 4];
        if (kind == TileMap.WALL) drawWall(c, map, th, bx, by, bw, bh);
        else if (kind == TileMap.CRATE) {
            for (int yy = 0; yy < bh; yy++) {
                for (int xx = 0; xx < bw; xx++) drawCrate(c, th, (bx + xx) * T, (by + yy) * T);
            }
        } else if (kind == TileMap.FENCE) drawFence(c, th, bx, by, bw, bh);
    }

    private void drawWall(Canvas c, TileMap map, MapTheme th, int bx, int by, int bw, int bh) {
        final float h = WALL_H;
        final float lean = Projection.LEAN * h;
        final float rise = Projection.TILT * h;
        float x0 = bx * T;
        float y0 = by * T;
        float x1 = x0 + bw * T;
        float y1 = y0 + bh * T;
        fill.setStyle(Paint.Style.FILL);

        // West face, in runs of rows that are not hidden by a wall to the west.
        fill.setColor(th.wallSide);
        int r = 0;
        while (r < bh) {
            if (map.kindAt(bx - 1, by + r) == TileMap.WALL) {
                r++;
                continue;
            }
            int r0 = r;
            while (r < bh && map.kindAt(bx - 1, by + r) != TileMap.WALL) r++;
            float ya = y0 + r0 * T;
            float yb = y0 + r * T;
            quad(c, x0, ya, x0, yb, x0 + lean, yb - rise, x0 + lean, ya - rise, fill);
        }

        // South face, in runs of columns that are not hidden by a wall to the south.
        int col = 0;
        while (col < bw) {
            if (map.kindAt(bx + col, by + bh) == TileMap.WALL) {
                col++;
                continue;
            }
            int c0 = col;
            while (col < bw && map.kindAt(bx + col, by + bh) != TileMap.WALL) col++;
            float xa = x0 + c0 * T;
            float xb = x0 + col * T;
            fill.setColor(th.wallFront);
            quad(c, xa, y1, xb, y1, xb + lean, y1 - rise, xa + lean, y1 - rise, fill);
            // Darker foot and panel seams give the face some structure.
            fill.setColor(0x40000000);
            quad(c, xa, y1, xb, y1, xb + lean * 0.16f, y1 - rise * 0.16f, xa + lean * 0.16f, y1 - rise * 0.16f, fill);
            line.setColor(0x33101820);
            line.setStrokeWidth(1f);
            int n = 0;
            for (float x = xa + T; x < xb - 0.5f && n + 4 <= segs.length; x += T) {
                segs[n++] = x;
                segs[n++] = y1;
                segs[n++] = x + lean;
                segs[n++] = y1 - rise;
            }
            if (n > 0) c.drawLines(segs, 0, n, line);
        }

        // Top face: a lit slab with a bright lip along its exposed south edge.
        fill.setColor(th.wallTop);
        c.drawRect(x0 + lean, y0 - rise, x1 + lean + 0.4f, y1 - rise + 0.4f, fill);
        col = 0;
        while (col < bw) {
            if (map.kindAt(bx + col, by + bh) == TileMap.WALL) {
                col++;
                continue;
            }
            int c0 = col;
            while (col < bw && map.kindAt(bx + col, by + bh) != TileMap.WALL) col++;
            fill.setColor(0x40FFFFFF);
            c.drawRect(x0 + c0 * T + lean, y1 - rise - 2.4f, x0 + col * T + lean, y1 - rise, fill);
        }
        // A darker inset line marks the edge of the slab.
        line.setColor(th.wallTrim);
        line.setStrokeWidth(0.9f);
        c.drawRect(x0 + lean + 1.4f, y0 - rise + 1.4f, x1 + lean - 1.4f, y1 - rise - 1.4f, line);
    }

    private void drawCrate(Canvas c, MapTheme th, float tx, float ty) {
        final float h = CRATE_H;
        final float lean = Projection.LEAN * h;
        final float rise = Projection.TILT * h;
        final float g = 1.6f;
        float x0 = tx + g;
        float y0 = ty + g;
        float x1 = tx + T - g;
        float y1 = ty + T - g;
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(th.crateSide);
        quad(c, x0, y0, x0, y1, x0 + lean, y1 - rise, x0 + lean, y0 - rise, fill);
        fill.setColor(th.crateFront);
        quad(c, x0, y1, x1, y1, x1 + lean, y1 - rise, x0 + lean, y1 - rise, fill);
        fill.setColor(th.crateTop);
        c.drawRect(x0 + lean, y0 - rise, x1 + lean + 0.4f, y1 - rise + 0.4f, fill);

        // Frame, cross-bracing on top and planks on the front, all in one batched line call.
        float tx0 = x0 + lean, ty0 = y0 - rise, tx1 = x1 + lean, ty1 = y1 - rise;
        int n = 0;
        segs[n++] = tx0 + 3f; segs[n++] = ty0 + 3f; segs[n++] = tx1 - 3f; segs[n++] = ty1 - 3f;
        segs[n++] = tx1 - 3f; segs[n++] = ty0 + 3f; segs[n++] = tx0 + 3f; segs[n++] = ty1 - 3f;
        float fy = y1 - rise * 0.36f;
        segs[n++] = x0 + lean * 0.36f; segs[n++] = fy; segs[n++] = x1 + lean * 0.36f; segs[n++] = fy;
        fy = y1 - rise * 0.7f;
        segs[n++] = x0 + lean * 0.7f; segs[n++] = fy; segs[n++] = x1 + lean * 0.7f; segs[n++] = fy;
        line.setColor(Palette.withAlpha(th.crateDark, 190));
        line.setStrokeWidth(1.5f);
        c.drawLines(segs, 0, n, line);
        line.setColor(Palette.withAlpha(th.crateDark, 230));
        line.setStrokeWidth(1.1f);
        c.drawRect(tx0 + 1.2f, ty0 + 1.2f, tx1 - 1.2f, ty1 - 1.2f, line);
    }

    /**
     * Chain-link fence along the long side of the rectangle: translucent mesh between two rails and
     * posts, so players and bullets can be seen through it.
     */
    private void drawFence(Canvas c, MapTheme th, int bx, int by, int bw, int bh) {
        final float h = FENCE_H;
        final float lean = Projection.LEAN * h;
        final float rise = Projection.TILT * h;
        boolean horizontal = bw >= bh;
        int lines = horizontal ? bh : bw;
        for (int k = 0; k < lines; k++) {
            if (horizontal) {
                float y = (by + k + 0.5f) * T;
                float xa = bx * T + 2f;
                float xb = (bx + bw) * T - 2f;
                fenceRun(c, th, xa, y, xb, y, lean, rise);
            } else {
                float x = (bx + k + 0.5f) * T;
                float ya = by * T + 2f;
                float yb = (by + bh) * T - 2f;
                fenceRun(c, th, x, ya, x, yb, lean, rise);
            }
        }
    }

    private void fenceRun(Canvas c, MapTheme th, float xa, float ya, float xb, float yb, float lean, float rise) {
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(Palette.withAlpha(th.fence, 46));
        quad(c, xa, ya, xb, yb, xb + lean, yb - rise, xa + lean, ya - rise, fill);
        // Mesh: diagonal wires across the panel.
        int n = 0;
        float len = (float) Math.hypot(xb - xa, yb - ya);
        int cells = Math.max(1, (int) (len / 6f));
        for (int i = 0; i < cells && n + 8 <= segs.length; i++) {
            float t0 = i / (float) cells;
            float t1 = (i + 1) / (float) cells;
            segs[n++] = xa + (xb - xa) * t0;
            segs[n++] = ya + (yb - ya) * t0;
            segs[n++] = xa + (xb - xa) * t1 + lean;
            segs[n++] = ya + (yb - ya) * t1 - rise;
            segs[n++] = xa + (xb - xa) * t0 + lean;
            segs[n++] = ya + (yb - ya) * t0 - rise;
            segs[n++] = xa + (xb - xa) * t1;
            segs[n++] = ya + (yb - ya) * t1;
        }
        line.setColor(Palette.withAlpha(th.fence, 110));
        line.setStrokeWidth(0.7f);
        c.drawLines(segs, 0, n, line);
        // Top rail and ground rail.
        line.setColor(Palette.withAlpha(th.fence, 235));
        line.setStrokeWidth(1.7f);
        c.drawLine(xa + lean, ya - rise, xb + lean, yb - rise, line);
        line.setStrokeWidth(1.2f);
        c.drawLine(xa, ya, xb, yb, line);
        // Posts at both ends and every three tiles.
        line.setStrokeWidth(2.4f);
        int posts = Math.max(1, Math.round(len / (T * 3f)));
        for (int i = 0; i <= posts; i++) {
            float t = i / (float) posts;
            float px = xa + (xb - xa) * t;
            float py = ya + (yb - ya) * t;
            c.drawLine(px, py, px + lean * 1.15f, py - rise * 1.15f, line);
        }
    }

    private void quad(Canvas c, float x0, float y0, float x1, float y1, float x2, float y2, float x3, float y3, Paint p) {
        path.reset();
        path.moveTo(x0, y0);
        path.lineTo(x1, y1);
        path.lineTo(x2, y2);
        path.lineTo(x3, y3);
        path.close();
        c.drawPath(path, p);
    }
}
