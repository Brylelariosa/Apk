package com.hazardyard.game.render;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;

import com.hazardyard.game.core.Camera;
import com.hazardyard.game.core.Effects;
import com.hazardyard.game.core.GameConfig;
import com.hazardyard.game.core.GameState;
import com.hazardyard.game.core.Pickup;
import com.hazardyard.game.core.Player;
import com.hazardyard.game.core.PlayerColors;
import com.hazardyard.game.core.TileMap;
import com.hazardyard.game.core.Weapon;
import com.hazardyard.game.core.WeaponDef;
import com.hazardyard.game.input.InputController;

/**
 * Screen-space interface drawn over the world: match timer and scores, minimap, pause and reload
 * buttons, both joysticks, weapon/ammo/health panel, kill feed, off-screen player arrows and the
 * countdown / respawn / results overlays. Sizes are in dp (density scaled), so the layout holds on
 * any resolution or aspect ratio. Allocation-free per frame.
 */
public final class HudRenderer {
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final Path path = new Path();
    private final Typeface bold = Typeface.create("sans-serif-condensed", Typeface.BOLD);
    private final Typeface medium = Typeface.create("sans-serif-medium", Typeface.NORMAL);
    private final int[] order = new int[GameConfig.MAX_PLAYERS];
    private final ControlsRenderer controls = new ControlsRenderer();

    private int lastSeconds = -1;
    private String timerText = "0:00";
    private float d = 1f;
    private int w = 1;
    private int h = 1;
    // safe area (display cutout / system bars): the HUD keeps clear of it, the world draws under it
    private float sl, st_, sr, sb;
    /** Horizontal centre of the safe area. */
    private float mid;

    public HudRenderer() {
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
    }

    public void draw(Canvas c, GameState st, Camera cam, InputController in, int pingMs, float density, float time) {
        d = density;
        w = cam.viewW;
        h = cam.viewH;
        com.hazardyard.game.input.ControlGeometry geo = in.geometry();
        sl = geo.insetL;
        st_ = geo.insetT;
        sr = geo.insetR;
        sb = geo.insetB;
        mid = sl + (w - sl - sr) * 0.5f;
        Player me = st.local();

        drawDamageTint(c, me);
        drawOffscreenArrows(c, st, cam);
        drawMinimap(c, st, cam, pingMs);
        drawTopBar(c, st);
        drawKillFeed(c, st);
        controls.draw(c, in, me, d);
        drawWeaponPanel(c, me);
        drawCenterMessage(c, st, me, time);
        if (st.phase == GameState.PHASE_ENDED) drawResults(c, st);
    }

    // ------------------------------------------------------------------ helpers

    private void label(Canvas c, String s, float x, float y, float sizeDp, int color, Paint.Align align, Typeface tf) {
        text.setTypeface(tf);
        text.setTextSize(sizeDp * d);
        text.setColor(color);
        text.setTextAlign(align);
        c.drawText(s, x, y, text);
    }

    private float measure(String s, float sizeDp, Typeface tf) {
        text.setTypeface(tf);
        text.setTextSize(sizeDp * d);
        return text.measureText(s);
    }

    private void panel(Canvas c, float l, float t, float r, float b, float radiusDp) {
        rect.set(l, t, r, b);
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(Palette.PANEL);
        c.drawRoundRect(rect, radiusDp * d, radiusDp * d, fill);
    }

    // ------------------------------------------------------------------ overlays on the whole screen

    private void drawDamageTint(Canvas c, Player me) {
        if (me.hitFlash <= 0f) return;
        int a = (int) (80f * Math.min(1f, me.hitFlash / 0.15f));
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(Palette.withAlpha(Palette.BAD, a));
        c.drawRect(0f, 0f, w, h, fill);
    }

    private void drawOffscreenArrows(Canvas c, GameState st, Camera cam) {
        float margin = 30f * d;
        for (int i = 0; i < st.players.length; i++) {
            Player p = st.players[i];
            if (i == st.localId || !p.connected || !p.alive) continue;
            float sx = cam.screenX(p.rx);
            float sy = cam.screenY(p.ry);
            if (sx >= 0f && sx <= w && sy >= 0f && sy <= h) continue;
            float cx = mid;
            float cy = st_ + (h - st_ - sb) * 0.5f;
            float dx = sx - cx;
            float dy = sy - cy;
            float halfW = (w - sl - sr) * 0.5f - margin;
            float halfH = (h - st_ - sb) * 0.5f - margin;
            float kx = Math.abs(dx) > 1e-3f ? halfW / Math.abs(dx) : Float.MAX_VALUE;
            float ky = Math.abs(dy) > 1e-3f ? halfH / Math.abs(dy) : Float.MAX_VALUE;
            float k = Math.min(kx, ky);
            float ax = cx + dx * k;
            float ay = cy + dy * k;
            float ang = (float) Math.atan2(dy, dx);
            float ca = (float) Math.cos(ang);
            float sa = (float) Math.sin(ang);
            float s = 11f * d;
            int color = PlayerColors.of(i);
            path.reset();
            path.moveTo(ax + ca * s, ay + sa * s);
            path.lineTo(ax - ca * s * 0.6f - sa * s * 0.85f, ay - sa * s * 0.6f + ca * s * 0.85f);
            path.lineTo(ax - ca * s * 0.6f + sa * s * 0.85f, ay - sa * s * 0.6f - ca * s * 0.85f);
            path.close();
            fill.setStyle(Paint.Style.FILL);
            fill.setColor(Palette.withAlpha(color, 230));
            c.drawPath(path, fill);
            stroke.setColor(Palette.withAlpha(0xFF0B0F14, 200));
            stroke.setStrokeWidth(1.5f * d);
            c.drawPath(path, stroke);
        }
    }

    // ------------------------------------------------------------------ top of the screen

    private void drawMinimap(Canvas c, GameState st, Camera cam, int pingMs) {
        TileMap map = st.map;
        float mw = 132f * d;
        float mh = mw * map.worldH / map.worldW;
        float mx = sl + 14f * d;
        float my = st_ + 14f * d;
        panel(c, mx - 4f * d, my - 4f * d, mx + mw + 4f * d, my + mh + 4f * d, 8f);
        float s = mw / map.worldW;
        MapTheme th = MapTheme.of(map.id);
        fill.setStyle(Paint.Style.FILL);
        for (int b = 0; b < map.blockCount; b++) {
            int o = b * 5;
            float x0 = mx + map.blocks[o] * GameConfig.TILE * s;
            float y0 = my + map.blocks[o + 1] * GameConfig.TILE * s;
            float x1 = x0 + map.blocks[o + 2] * GameConfig.TILE * s;
            float y1 = y0 + map.blocks[o + 3] * GameConfig.TILE * s;
            int kind = map.blocks[o + 4];
            if (kind == TileMap.WATER) fill.setColor(Palette.withAlpha(th.waterLight, 190));
            else if (kind == TileMap.FENCE) fill.setColor(Palette.withAlpha(th.fence, 150));
            else if (kind == TileMap.CRATE) fill.setColor(0xFF9C6A2E);
            else fill.setColor(0xFF6F809A);
            c.drawRect(x0, y0, x1, y1, fill);
        }
        for (int i = 0; i < st.pickups.length; i++) {
            Pickup pk = st.pickups[i];
            if (!pk.active) continue;
            fill.setColor(WeaponDef.byId(pk.weaponId).color);
            c.drawCircle(mx + pk.x * s, my + pk.y * s, 1.7f * d, fill);
        }
        float vx0 = Math.max(0f, cam.x - cam.halfViewWorldW());
        float vy0 = Math.max(0f, cam.y - cam.halfViewWorldH());
        float vx1 = Math.min(map.worldW, cam.x + cam.halfViewWorldW());
        float vy1 = Math.min(map.worldH, cam.y + cam.halfViewWorldH());
        stroke.setColor(Palette.withAlpha(0xFFFFFFFF, 120));
        stroke.setStrokeWidth(1f * d);
        c.drawRect(mx + vx0 * s, my + vy0 * s, mx + vx1 * s, my + vy1 * s, stroke);
        for (int i = 0; i < st.players.length; i++) {
            Player p = st.players[i];
            if (!p.connected || !p.alive) continue;
            fill.setColor(PlayerColors.of(i));
            c.drawCircle(mx + p.rx * s, my + p.ry * s, 3f * d, fill);
            if (i == st.localId) {
                stroke.setColor(0xFFFFFFFF);
                stroke.setStrokeWidth(1.2f * d);
                c.drawCircle(mx + p.rx * s, my + p.ry * s, 5f * d, stroke);
            }
        }
        if (pingMs > 0) {
            float y = my + mh + 22f * d;
            float x = mx;
            label(c, "Ping ", x, y, 11f, Palette.TEXT_DIM, Paint.Align.LEFT, medium);
            x += measure("Ping ", 11f, medium);
            label(c, Txt.of(pingMs), x, y, 11f, pingMs > 120 ? Palette.WARN : Palette.TEXT_DIM, Paint.Align.LEFT, medium);
            x += measure(Txt.of(pingMs), 11f, medium);
            label(c, " ms", x, y, 11f, Palette.TEXT_DIM, Paint.Align.LEFT, medium);
        }
    }

    private void drawTopBar(Canvas c, GameState st) {
        float pw = 116f * d;
        float ph = 34f * d;
        float px = mid - pw * 0.5f;
        float py = st_ + 10f * d;
        panel(c, px, py, px + pw, py + ph, 10f);
        int secs = (int) Math.ceil(st.timeLeft);
        if (secs != lastSeconds) {
            lastSeconds = secs;
            int sec = secs % 60;
            timerText = Txt.of(secs / 60) + (sec < 10 ? ":0" : ":") + Txt.of(sec);
        }
        boolean urgent = st.phase == GameState.PHASE_PLAYING && secs <= 10;
        label(c, timerText, mid, py + ph * 0.72f, 22f, urgent ? Palette.BAD : Palette.TEXT, Paint.Align.CENTER, bold);

        int n = 0;
        for (int i = 0; i < st.players.length; i++) if (st.players[i].connected) n++;
        if (n == 0) return;
        float cw = 50f * d;
        float gap = 4f * d;
        float total = n * cw + (n - 1) * gap;
        float x = mid - total * 0.5f;
        float y = py + ph + 6f * d;
        for (int i = 0; i < st.players.length; i++) {
            Player p = st.players[i];
            if (!p.connected) continue;
            panel(c, x, y, x + cw, y + 22f * d, 8f);
            if (i == st.localId) {
                stroke.setColor(Palette.withAlpha(Palette.ACCENT, 200));
                stroke.setStrokeWidth(1.4f * d);
                c.drawRoundRect(rect, 8f * d, 8f * d, stroke);
            }
            fill.setStyle(Paint.Style.FILL);
            fill.setColor(PlayerColors.of(i));
            c.drawCircle(x + 11f * d, y + 11f * d, 5f * d, fill);
            label(c, Txt.of(p.kills), x + cw - 9f * d, y + 16f * d, 14f, Palette.TEXT, Paint.Align.RIGHT, bold);
            x += cw + gap;
        }
    }

    private void drawKillFeed(Canvas c, GameState st) {
        Effects fx = st.effects;
        float left = sl + 14f * d;
        float minimapBottom = st_ + 14f * d + 132f * d * st.map.worldH / st.map.worldW;
        float top = minimapBottom + 42f * d;
        for (int i = fx.feedCount - 1, k = 0; i >= 0 && k < 3; i--, k++) {
            int victim = fx.feedVictim[i];
            int killer = fx.feedKiller[i];
            if (victim < 0 || victim >= st.players.length) continue;
            float fade = Effects.FEED_LIFE - fx.feedAge[i];
            int alpha = fade < 0.8f ? (int) (255f * Math.max(0f, fade) / 0.8f) : 255;
            String vn = st.players[victim].name;
            boolean hasKiller = killer >= 0 && killer < st.players.length;
            String kn = hasKiller ? st.players[killer].name : "";
            String joint = hasKiller ? "  \u00BB  " : " was eliminated";
            float wk = hasKiller ? measure(kn, 13f, medium) : 0f;
            float wm = measure(joint, 13f, medium);
            float wv = hasKiller ? measure(vn, 13f, medium) : measure(vn, 13f, medium);
            float total = wk + wm + wv;
            float y = top + k * 26f * d;
            rect.set(left, y, left + total + 16f * d, y + 22f * d);
            fill.setStyle(Paint.Style.FILL);
            fill.setColor(Palette.withAlpha(0xFF131A22, (int) (alpha * 0.7f)));
            c.drawRoundRect(rect, 8f * d, 8f * d, fill);
            float x = left + 8f * d;
            float by = y + 16f * d;
            if (hasKiller) {
                label(c, kn, x, by, 13f, Palette.withAlpha(PlayerColors.of(killer), alpha), Paint.Align.LEFT, medium);
                x += wk;
                label(c, joint, x, by, 13f, Palette.withAlpha(Palette.TEXT_DIM, alpha), Paint.Align.LEFT, medium);
                x += wm;
                label(c, vn, x, by, 13f, Palette.withAlpha(PlayerColors.of(victim), alpha), Paint.Align.LEFT, medium);
            } else {
                label(c, vn, x, by, 13f, Palette.withAlpha(PlayerColors.of(victim), alpha), Paint.Align.LEFT, medium);
                x += wv;
                label(c, joint, x, by, 13f, Palette.withAlpha(Palette.TEXT_DIM, alpha), Paint.Align.LEFT, medium);
            }
        }
    }

    // ------------------------------------------------------------------ bottom panel

    private void drawWeaponPanel(Canvas c, Player me) {
        float pw = 250f * d;
        float ph = 70f * d;
        float px = mid - pw * 0.5f;
        float py = h - sb - ph - 14f * d;
        panel(c, px, py, px + pw, py + ph, 12f);
        Weapon wp = me.weapon;
        label(c, wp.def.name, px + 14f * d, py + 22f * d, 13f, Palette.TEXT_DIM, Paint.Align.LEFT, medium);
        float ax = px + pw - 14f * d;
        String mag = Txt.of(wp.def.magSize);
        label(c, mag, ax, py + 29f * d, 15f, Palette.TEXT_DIM, Paint.Align.RIGHT, bold);
        float mw = measure(mag, 15f, bold);
        label(c, "/", ax - mw - 2f * d, py + 29f * d, 15f, Palette.TEXT_DIM, Paint.Align.RIGHT, bold);
        float sw = measure("/", 15f, bold);
        int ammoColor = wp.ammo == 0 ? Palette.BAD : Palette.TEXT;
        label(c, Txt.of(wp.ammo), ax - mw - sw - 6f * d, py + 29f * d, 26f, ammoColor, Paint.Align.RIGHT, bold);

        float bx = px + 14f * d;
        float bw = pw - 28f * d;
        fill.setStyle(Paint.Style.FILL);
        if (wp.reloading) {
            fill.setColor(0x33FFFFFF);
            c.drawRect(bx, py + 36f * d, bx + bw, py + 40f * d, fill);
            fill.setColor(Palette.ACCENT);
            c.drawRect(bx, py + 36f * d, bx + bw * wp.reloadFraction, py + 40f * d, fill);
        }
        float frac = Math.max(0f, Math.min(1f, me.health / (float) GameConfig.PLAYER_MAX_HEALTH));
        rect.set(bx, py + 46f * d, bx + bw, py + 60f * d);
        fill.setColor(0x40FFFFFF);
        c.drawRoundRect(rect, 5f * d, 5f * d, fill);
        if (frac > 0f) {
            rect.set(bx, py + 46f * d, bx + bw * frac, py + 60f * d);
            fill.setColor(frac > 0.5f ? Palette.GOOD : (frac > 0.25f ? Palette.WARN : Palette.BAD));
            c.drawRoundRect(rect, 5f * d, 5f * d, fill);
        }
        label(c, Txt.of(Math.max(0, me.health)), bx + bw - 6f * d, py + 57f * d, 11f, 0xFF0B0F14, Paint.Align.RIGHT, bold);
    }

    // ------------------------------------------------------------------ centre messages

    private void drawCenterMessage(Canvas c, GameState st, Player me, float time) {
        float cx = mid;
        float cy = h * 0.5f;
        switch (st.phase) {
            case GameState.PHASE_LOBBY:
                label(c, "Waiting for the host\u2026", cx, cy, 20f, Palette.TEXT, Paint.Align.CENTER, medium);
                return;
            case GameState.PHASE_COUNTDOWN: {
                int n = Math.max(1, (int) Math.ceil(st.countdown));
                label(c, Txt.of(n), cx + 2f * d, cy + 34f * d + 2f * d, 96f, 0x66000000, Paint.Align.CENTER, bold);
                label(c, Txt.of(n), cx, cy + 34f * d, 96f, Palette.ACCENT, Paint.Align.CENTER, bold);
                label(c, "Get ready", cx, cy - 56f * d, 18f, Palette.TEXT, Paint.Align.CENTER, medium);
                return;
            }
            case GameState.PHASE_PLAYING:
                if (!me.alive) {
                    label(c, "Eliminated", cx, h * 0.34f, 30f, Palette.BAD, Paint.Align.CENTER, bold);
                    int s = Math.max(1, (int) Math.ceil(me.respawnTimer));
                    label(c, "Respawning in", cx - 12f * d, h * 0.34f + 28f * d, 16f, Palette.TEXT, Paint.Align.RIGHT, medium);
                    label(c, Txt.of(s), cx - 6f * d, h * 0.34f + 28f * d, 18f, Palette.ACCENT, Paint.Align.LEFT, bold);
                } else if (me.spawnProtect > 0f) {
                    label(c, "Spawn shield", cx, h * 0.27f, 13f, Palette.SHIELD, Paint.Align.CENTER, medium);
                }
                return;
            default:
                return;
        }
    }

    private boolean ranksAbove(GameState st, int a, int b) {
        Player pa = st.players[a];
        Player pb = st.players[b];
        return pa.kills > pb.kills || (pa.kills == pb.kills && pa.deaths < pb.deaths);
    }

    private void drawResults(Canvas c, GameState st) {
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(0x99000000);
        c.drawRect(0f, 0f, w, h, fill);

        int n = 0;
        for (int i = 0; i < st.players.length; i++) if (st.players[i].connected) order[n++] = i;
        for (int a = 1; a < n; a++) {
            int v = order[a];
            int b = a - 1;
            while (b >= 0 && ranksAbove(st, v, order[b])) {
                order[b + 1] = order[b];
                b--;
            }
            order[b + 1] = v;
        }

        float pw = 360f * d;
        float rowH = 38f * d;
        float ph = 138f * d + n * rowH;
        float px = mid - pw * 0.5f;
        float py = Math.max(10f * d, (h - ph) * 0.5f);
        rect.set(px, py, px + pw, py + ph);
        fill.setColor(Palette.PANEL_SOLID);
        c.drawRoundRect(rect, 14f * d, 14f * d, fill);
        stroke.setColor(Palette.PANEL_EDGE);
        stroke.setStrokeWidth(1.5f * d);
        c.drawRoundRect(rect, 14f * d, 14f * d, stroke);

        float cx = mid;
        if (st.winnerId == st.localId) {
            label(c, "Victory", cx, py + 44f * d, 34f, Palette.ACCENT, Paint.Align.CENTER, bold);
        } else if (st.winnerId >= 0 && st.winnerId < st.players.length) {
            label(c, st.players[st.winnerId].name, cx, py + 40f * d, 26f, PlayerColors.of(st.winnerId), Paint.Align.CENTER, bold);
            label(c, "wins the match", cx, py + 60f * d, 13f, Palette.TEXT_DIM, Paint.Align.CENTER, medium);
        } else {
            label(c, "Draw", cx, py + 44f * d, 34f, Palette.TEXT, Paint.Align.CENTER, bold);
        }
        float hy = py + 82f * d;
        label(c, "K", px + pw - 70f * d, hy, 12f, Palette.TEXT_DIM, Paint.Align.RIGHT, bold);
        label(c, "D", px + pw - 24f * d, hy, 12f, Palette.TEXT_DIM, Paint.Align.RIGHT, bold);
        for (int r = 0; r < n; r++) {
            int i = order[r];
            Player p = st.players[i];
            float y = py + 90f * d + r * rowH;
            if (i == st.localId) {
                rect.set(px + 8f * d, y + 2f * d, px + pw - 8f * d, y + rowH - 4f * d);
                fill.setColor(0x22FFFFFF);
                c.drawRoundRect(rect, 8f * d, 8f * d, fill);
            }
            float by = y + rowH * 0.62f;
            label(c, Txt.of(r + 1), px + 26f * d, by, 15f, Palette.TEXT_DIM, Paint.Align.CENTER, bold);
            fill.setColor(PlayerColors.of(i));
            c.drawCircle(px + 52f * d, y + rowH * 0.5f - 1f * d, 7f * d, fill);
            label(c, p.name, px + 68f * d, by, 16f, Palette.TEXT, Paint.Align.LEFT, medium);
            label(c, Txt.of(p.kills), px + pw - 70f * d, by, 18f, Palette.TEXT, Paint.Align.RIGHT, bold);
            label(c, Txt.of(p.deaths), px + pw - 24f * d, by, 18f, Palette.TEXT_DIM, Paint.Align.RIGHT, bold);
        }
        int secs = Math.max(0, (int) Math.ceil(st.resultsTimer));
        label(c, "Returning in", cx - 6f * d, py + ph - 14f * d, 12f, Palette.TEXT_DIM, Paint.Align.RIGHT, medium);
        label(c, Txt.of(secs), cx, py + ph - 14f * d, 13f, Palette.ACCENT, Paint.Align.LEFT, bold);
    }
}
