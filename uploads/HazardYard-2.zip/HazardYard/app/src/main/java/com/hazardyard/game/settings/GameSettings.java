package com.hazardyard.game.settings;

/** Everything the player can configure. One live instance is shared by the input, HUD and renderer. */
public final class GameSettings {
    public final ControlSettings controls = new ControlSettings();
    /** Draw the soldiers and weapons as lit 3D models (off = the simple flat look, cheaper on slow phones). */
    public volatile boolean models3d = true;
    /** Master switch for all sound effects. */
    public volatile boolean soundOn = true;
    /** Master volume, 0..1. */
    public volatile float volume = 0.8f;

    public GameSettings copy() {
        GameSettings g = new GameSettings();
        g.copyFrom(this);
        return g;
    }

    public void copyFrom(GameSettings o) {
        controls.copyFrom(o.controls);
        models3d = o.models3d;
        soundOn = o.soundOn;
        volume = o.volume;
    }
}
