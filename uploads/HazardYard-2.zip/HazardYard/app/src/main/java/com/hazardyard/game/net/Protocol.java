package com.hazardyard.game.net;

import java.io.DataInputStream;
import java.io.IOException;

/**
 * Wire constants. A TCP frame is [u16 length][u8 type][payload]; length counts the type byte and the
 * payload. All numbers are big-endian. Discovery datagrams use the same primitives without the length.
 */
public final class Protocol {
    private Protocol() {}

    public static final int VERSION = 2;
    public static final int DISCOVERY_PORT = 47820;
    public static final int GAME_PORT = 47821;
    /** "HYD1" */
    public static final int DISCOVERY_MAGIC = 0x48594431;
    public static final int MAX_FRAME = 2048;
    public static final int MAX_NAME = 12;

    // client -> host
    public static final int C_HELLO = 1;
    public static final int C_READY = 2;
    public static final int C_INPUT = 3;
    public static final int C_RELOAD = 4;
    public static final int C_PING = 5;
    public static final int C_LEAVE = 6;

    // host -> client
    public static final int S_WELCOME = 20;
    public static final int S_REJECT = 21;
    public static final int S_LOBBY = 22;
    public static final int S_START = 23;
    public static final int S_SNAPSHOT = 24;
    public static final int S_FIRE = 25;
    public static final int S_HIT = 26;
    public static final int S_KILL = 27;
    public static final int S_TO_LOBBY = 28;
    public static final int S_PONG = 29;

    /** Never sent on the wire: queued by the host when a client disconnects during a match. */
    public static final int I_PLAYER_LEFT = 100;

    // discovery datagrams
    public static final int D_PROBE = 1;
    public static final int D_REPLY = 2;

    // reject reasons
    public static final int REJECT_VERSION = 1;
    public static final int REJECT_IN_MATCH = 2;
    public static final int REJECT_FULL = 3;

    /** Reads one frame and returns type byte + payload. Blocks; throws on EOF, timeout or bad length. */
    public static byte[] readFrame(DataInputStream in) throws IOException {
        int len = in.readUnsignedShort();
        if (len < 1 || len > MAX_FRAME) throw new IOException("Bad frame length " + len);
        byte[] data = new byte[len];
        in.readFully(data);
        return data;
    }

    /** Trims, strips control characters and limits the length of a player name. */
    public static String sanitizeName(String raw) {
        if (raw == null) return "Player";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < raw.length() && sb.length() < MAX_NAME; i++) {
            char c = raw.charAt(i);
            if (c >= 32 && c != 127) sb.append(c);
        }
        String s = sb.toString().trim();
        return s.isEmpty() ? "Player" : s;
    }

    public static String rejectMessage(int reason) {
        switch (reason) {
            case REJECT_VERSION: return "This game version does not match the host.";
            case REJECT_IN_MATCH: return "A match is already in progress.";
            case REJECT_FULL: return "The lobby is full.";
            default: return "The host refused the connection.";
        }
    }
}
