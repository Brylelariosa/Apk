package com.hazardyard.game;

import android.app.Activity;
import android.graphics.Insets;
import android.os.Bundle;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.widget.FrameLayout;

import com.hazardyard.game.render.Palette;
import com.hazardyard.game.ui.AppController;

/**
 * Thin window host: sets up the full-screen root view and hands everything else (navigation, lobby,
 * network session, match) to {@link AppController}.
 */
public final class MainActivity extends Activity {
    private AppController app;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        goEdgeToEdge();
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Palette.BACKDROP);
        setContentView(root);
        app = new AppController(this, root);
        // The window now covers the camera cutout too; tell the app how much of each edge it takes.
        root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View v, WindowInsets insets) {
                Insets cut = insets.getInsets(WindowInsets.Type.displayCutout());
                app.setInsets(cut.left, cut.top, cut.right, cut.bottom);
                return insets;
            }
        });
        app.start();
        root.requestApplyInsets();
    }

    /**
     * Draws under the system bars and into the camera cutout area (notch / punch hole), so no black
     * strip is left beside the camera. The theme asks for the same; this also covers devices whose
     * theme handling differs.
     */
    private void goEdgeToEdge() {
        getWindow().setDecorFitsSystemWindows(false);
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
        getWindow().setAttributes(lp);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemBars();
    }

    /** Immersive mode: bars stay hidden and reappear only on an edge swipe. */
    private void hideSystemBars() {
        WindowInsetsController controller = getWindow().getInsetsController();
        if (controller == null) return;
        controller.hide(WindowInsets.Type.systemBars());
        controller.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (app != null && app.handleBack()) return;
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (app != null) app.shutdown();
        super.onDestroy();
    }
}
