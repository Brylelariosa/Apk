package com.hazardyard.game.core;

/**
 * Collision queries against the tile map. Results are returned through public scratch fields so the
 * hot paths never allocate. An instance must only be used from one thread.
 */
public final class CollisionSystem {
    private final TileMap map;
    /** Output of {@link #moveCircle} and {@link #pushOut}. */
    public float resX, resY;

    public CollisionSystem(TileMap map) {
        this.map = map;
    }

    /** Moves a circle by (dx, dy), sliding along walls. The new centre is left in resX/resY. */
    public void moveCircle(float x, float y, float dx, float dy, float r) {
        resX = x + dx;
        resY = y + dy;
        resolve(r);
    }

    /** Pushes a circle out of solid tiles. The new centre is left in resX/resY. */
    public boolean pushOut(float x, float y, float r) {
        resX = x;
        resY = y;
        return resolve(r);
    }

    private boolean resolve(float r) {
        final float t = GameConfig.TILE;
        boolean moved = false;
        for (int iter = 0; iter < 4; iter++) {
            boolean any = false;
            int minTx = (int) Math.floor((resX - r) / t);
            int maxTx = (int) Math.floor((resX + r) / t);
            int minTy = (int) Math.floor((resY - r) / t);
            int maxTy = (int) Math.floor((resY + r) / t);
            for (int ty = minTy; ty <= maxTy; ty++) {
                for (int tx = minTx; tx <= maxTx; tx++) {
                    if (!map.isSolid(tx, ty)) continue;
                    float left = tx * t;
                    float right = left + t;
                    float top = ty * t;
                    float bottom = top + t;
                    float cx = MathUtil.clamp(resX, left, right);
                    float cy = MathUtil.clamp(resY, top, bottom);
                    float dx = resX - cx;
                    float dy = resY - cy;
                    float d2 = dx * dx + dy * dy;
                    if (d2 >= r * r) continue;
                    if (d2 > 1e-8f) {
                        float d = (float) Math.sqrt(d2);
                        float push = (r - d) / d;
                        resX += dx * push;
                        resY += dy * push;
                    } else {
                        // Centre is inside the tile: leave through the nearest face that opens onto
                        // free space (never through the map border or into another solid tile).
                        float pl = resX - left + r;
                        float pr = right - resX + r;
                        float pt = resY - top + r;
                        float pb = bottom - resY + r;
                        float big = Float.MAX_VALUE;
                        float cl = map.isSolid(tx - 1, ty) ? big : pl;
                        float cr = map.isSolid(tx + 1, ty) ? big : pr;
                        float ct = map.isSolid(tx, ty - 1) ? big : pt;
                        float cb = map.isSolid(tx, ty + 1) ? big : pb;
                        if (cl == big && cr == big && ct == big && cb == big) {
                            cl = pl;
                            cr = pr;
                            ct = pt;
                            cb = pb;
                        }
                        float m = Math.min(Math.min(cl, cr), Math.min(ct, cb));
                        if (m == cl) resX -= pl;
                        else if (m == cr) resX += pr;
                        else if (m == ct) resY -= pt;
                        else resY += pb;
                    }
                    any = true;
                    moved = true;
                }
            }
            if (!any) break;
        }
        return moved;
    }

    /**
     * Walks the segment through the tile grid. Returns the fraction t (0..1) at which it first enters a
     * tile that stops bullets (wall or crate), or -1 when the segment is free. Fences and pools do not
     * stop bullets.
     */
    public float raycast(float x0, float y0, float x1, float y1) {
        final float t = GameConfig.TILE;
        float dx = x1 - x0;
        float dy = y1 - y0;
        int tx = (int) Math.floor(x0 / t);
        int ty = (int) Math.floor(y0 / t);
        if (map.blocksShots(tx, ty)) return 0f;
        int stepX = dx > 0f ? 1 : -1;
        int stepY = dy > 0f ? 1 : -1;
        float inf = Float.MAX_VALUE;
        float tDeltaX = dx != 0f ? t / Math.abs(dx) : inf;
        float tDeltaY = dy != 0f ? t / Math.abs(dy) : inf;
        float tMaxX = dx > 0f ? ((tx + 1) * t - x0) / dx : (dx < 0f ? (tx * t - x0) / dx : inf);
        float tMaxY = dy > 0f ? ((ty + 1) * t - y0) / dy : (dy < 0f ? (ty * t - y0) / dy : inf);
        while (true) {
            float hit;
            if (tMaxX < tMaxY) {
                hit = tMaxX;
                tx += stepX;
                tMaxX += tDeltaX;
            } else {
                hit = tMaxY;
                ty += stepY;
                tMaxY += tDeltaY;
            }
            if (hit > 1f) return -1f;
            if (map.blocksShots(tx, ty)) return hit;
        }
    }

    /** First intersection (fraction 0..1) of a segment with a circle, or -1. Starting inside returns 0. */
    public static float segmentCircle(float x0, float y0, float x1, float y1, float cx, float cy, float r) {
        float dx = x1 - x0;
        float dy = y1 - y0;
        float fx = x0 - cx;
        float fy = y0 - cy;
        float c = fx * fx + fy * fy - r * r;
        if (c <= 0f) return 0f;
        float a = dx * dx + dy * dy;
        if (a < 1e-9f) return -1f;
        float b = fx * dx + fy * dy;
        float disc = b * b - a * c;
        if (disc < 0f) return -1f;
        float t = (-b - (float) Math.sqrt(disc)) / a;
        return (t >= 0f && t <= 1f) ? t : -1f;
    }

    /**
     * Advances a bullet by dt. On return the bullet holds its new position (cut short at the impact
     * point when it hit a wall), the previous position for swept tests, and its remaining range.
     *
     * @return {@link #FLYING}, {@link #EXPIRED} (range used up) or {@link #HIT_WALL}
     */
    public int advance(Projectile b, float dt) {
        float dx = b.vx * dt;
        float dy = b.vy * dt;
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        boolean expired = false;
        if (len >= b.remaining) {
            float k = len > 0f ? b.remaining / len : 0f;
            dx *= k;
            dy *= k;
            len = b.remaining;
            expired = true;
        }
        b.px = b.x;
        b.py = b.y;
        float nx = b.x + dx;
        float ny = b.y + dy;
        float hit = raycast(b.x, b.y, nx, ny);
        if (hit >= 0f) {
            b.x += dx * hit;
            b.y += dy * hit;
            return HIT_WALL;
        }
        b.x = nx;
        b.y = ny;
        b.remaining -= len;
        return expired ? EXPIRED : FLYING;
    }

    public static final int FLYING = 0;
    public static final int EXPIRED = 1;
    public static final int HIT_WALL = 2;
}
