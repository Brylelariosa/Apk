package com.hazardyard.game.core;

/**
 * Built-in arenas, from the compact Hazard Yard up to the sprawling Ruined Outpost. Each map is
 * authored as a fraction (a quarter, or the top half) and mirrored, so no spawn point is favoured.
 *
 * <p>Maps are immutable once parsed, so one shared instance per id is handed out.
 */
public final class MapLibrary {
    private MapLibrary() {}

    public static final int HAZARD_YARD = 0;
    public static final int DOCKSIDE = 1;
    public static final int FOUNDRY = 2;
    public static final int OUTPOST = 3;
    public static final int BUNKER = 4;
    public static final int COUNT = 5;
    public static final int DEFAULT_ID = HAZARD_YARD;

    private static final String[] NAMES = {
        "Hazard Yard", "Dockside Warehouse", "Toxic Foundry", "Ruined Outpost", "Bunker Complex",
    };
    private static final String[] BLURBS = {
        "Compact arena. Fast duels around a toxic yard and a fenced centre pit.",
        "Long storage racks split by a canal. Three bridges, lots of sightlines.",
        "Pump rooms and conveyors around a reactor island ringed by a toxic moat.",
        "Huge open ruins with an oasis in the middle. Long-range fights, little cover.",
        "Tight corridors and rooms. Close combat around a central vault.",
    };

    private static final TileMap[] CACHE = new TileMap[COUNT];

    public static int clampId(int id) {
        return id < 0 || id >= COUNT ? DEFAULT_ID : id;
    }

    public static String name(int id) {
        return NAMES[clampId(id)];
    }

    public static String blurb(int id) {
        return BLURBS[clampId(id)];
    }

    /** "41 x 25 tiles" style size line. */
    public static String sizeText(int id) {
        TileMap m = get(id);
        return m.width + " \u00D7 " + m.height + " tiles  \u00B7  " + m.pickupX.length + " weapons";
    }

    /** The map with this id (an unknown id gives the default map). */
    public static synchronized TileMap get(int id) {
        id = clampId(id);
        if (CACHE[id] == null) CACHE[id] = build(id);
        return CACHE[id];
    }

    /** The default (smallest) arena. */
    public static TileMap arena() {
        return get(DEFAULT_ID);
    }

    private static TileMap build(int id) {
        switch (id) {
            case DOCKSIDE: return TileMap.parse(id, rotate180(DOCKSIDE_TOP));
            case FOUNDRY: return TileMap.parse(id, mirrorBoth(FOUNDRY_QUARTER));
            case OUTPOST: return TileMap.parse(id, mirrorBoth(OUTPOST_QUARTER));
            case BUNKER: return TileMap.parse(id, mirrorBoth(BUNKER_QUARTER));
            default: return TileMap.parse(id, mirrorBoth(HAZARD_YARD_QUARTER));
        }
    }

    /** Mirrors the top-left quarter (which includes the centre column and the centre row) on both axes. */
    private static String[] mirrorBoth(String[] quarter) {
        int qh = quarter.length;
        int qw = quarter[0].length();
        String[] rows = new String[qh * 2 - 1];
        for (int y = 0; y < qh; y++) {
            String q = quarter[y];
            StringBuilder sb = new StringBuilder(qw * 2 - 1);
            sb.append(q);
            for (int x = qw - 2; x >= 0; x--) sb.append(q.charAt(x));
            rows[y] = sb.toString();
            rows[rows.length - 1 - y] = rows[y];
        }
        return rows;
    }

    /** Completes the top half (which includes the centre row) by rotating it 180 degrees. */
    private static String[] rotate180(String[] top) {
        int th = top.length;
        String[] rows = new String[th * 2 - 1];
        for (int y = 0; y < th; y++) rows[y] = top[y];
        for (int y = th - 2; y >= 0; y--) {
            rows[th + (th - 2 - y)] = new StringBuilder(top[y]).reverse().toString();
        }
        return rows;
    }

    // Legend: # wall, C crate, + fence (bullets pass), ~ toxic pool (bullets pass), S spawn,
    // R rifle, G shotgun, M SMG, N sniper, V magnum, P plasma, K light MG.
    private static final String[] HAZARD_YARD_QUARTER = {
        "#####################",
        "#.....#.............V",
        "#.S...#...CC.........",
        "#.....#...CC..R......",
        "#............~~......",
        "#####.##.....~~.##...",
        "#....M.......+...#...",
        "#............+...#...",
        "#..S...CC....+.......",
        "#......CC............",
        "#.......G...#+++##...",
        "#...........#........",
        "#...........#...+++.P",
    };

    private static final String[] DOCKSIDE_TOP = {
        "#######################################################",
        "####++###++##.....................................CCCC#",
        "##..........#..............N..........CC..............#",
        "##.CC....S..#..................................#......#",
        "##...............############....############..#......#",
        "##.S......C....C...............................#..CC..#",
        "##........C.#..CR.............CC........M......#..CC..#",
        "######..#####..................................#......#",
        "#.............########...############...#####..#......#",
        "#....K.................G.........................+++++#",
        "#...................S...............S..........V......#",
        "#.########...#######..###....#####...######..CC.......#",
        "#..........C..............CC...M.............CC....C..#",
        "#~~~~~~~~...~~~~~~~~~~~~~.....~~~~~~~~~~~~~...~~~~~~~~#",
        "#~~~~~~~~...~~~~~~~~~~~~~.....~~~~~~~~~~~~~...~~~~~~~~#",
        "#...................CC...........CC...................#",
        "#...................CC.....P.....CC...................#",
    };

    private static final String[] FOUNDRY_QUARTER = {
        "##############################",
        "###########..................N",
        "##...CC...+........######.....",
        "##.S......+.CC.#............CC",
        "##..........CC.#..............",
        "##.....S.......#.~~.......~...",
        "##........#......~~.......~...",
        "###+#..####.....R.........~...",
        "#............................V",
        "#.............#######.........",
        "#..........G..#...............",
        "#..#..........#.......~~~~~~..",
        "#..#..++++....#.......~~~~~~..",
        "#..#..........#.......~~~~~~..",
        "#..#.............CC...~~~#....",
        "#..#....~~~~.....CC...~~~.C...",
        "#.......~~~~..................",
        "#.K..........................P",
    };

    private static final String[] OUTPOST_QUARTER = {
        "#################################",
        "#..#.CC..#.......................",
        "#..#...S.#......................N",
        "#....S...#...####.........#......",
        "#........#......#.........#......",
        "#..........R....#.........###....",
        "########.#.......................",
        "#................................",
        "#...........C........####.....C..",
        "#....................#........C..",
        "#....................#...........",
        "#....####............#..........P",
        "#.......#.........#..............",
        "#.......#....CC...#......#.......",
        "#............CC.....K....#.C.+...",
        "#..CC....................#.~~~~~~",
        "#..CC.G...................C~~~~~~",
        "#.................CC.......~~~~~~",
        "#.........#####............~~~~~~",
        "#..........................~~~~~~",
    };

    private static final String[] BUNKER_QUARTER = {
        "########################",
        "#............#..........",
        "#.###++###.C.#.....CC...",
        "#.#C...S.#...#..........",
        "#.#.S........#..#####...",
        "#.#.........R...#.......",
        "#.#......#......#.......",
        "#.###..###...#...####...",
        "#............#.C.#.....#",
        "#............#.C....C..#",
        "#######..#...#...#.....#",
        "#........#.......##+####",
        "#...CC...#.....M........",
        "#.G.CC...#####...#...CCV",
        "#................#......",
        "#...........CC...#.....P",
    };
}
