package com.hazardyard.game.bot;

import com.hazardyard.game.core.CollisionSystem;
import com.hazardyard.game.core.GameConfig;
import com.hazardyard.game.core.GameState;
import com.hazardyard.game.core.GameWorld;
import com.hazardyard.game.core.MathUtil;
import com.hazardyard.game.core.Pickup;
import com.hazardyard.game.core.Player;
import com.hazardyard.game.core.Weapon;
import com.hazardyard.game.core.WeaponDef;
import com.hazardyard.game.core.XorShift;

/**
 * The AI of one computer-controlled soldier. Every simulation tick it looks at the match, decides
 * what to do and feeds {@link GameWorld#setInput} exactly like a human's touch controls would, so
 * bots obey the same movement, turning, ammunition and reload rules as everybody else.
 *
 * <p>Behaviour in priority order: fight an enemy it can see (keep a sensible distance for the
 * weapon, strafe, lead the shot, wait out its reaction time); go after an enemy it just lost sight
 * of; collect a clearly better weapon; otherwise roam the map and hunt.
 */
public final class BotBrain {
    private static final float R = GameConfig.PLAYER_RADIUS - 1f;
    private static final float WAYPOINT_REACH = 12f;
    private static final float MEMORY_SECONDS = 2.5f;
    private static final float REPATH_SECONDS = 0.7f;
    private static final float[] STEER_OFFSETS = {0f, 0.6f, -0.6f, 1.2f, -1.2f, 1.9f, -1.9f};

    /** How much each weapon is worth to a bot (1.0 = assault rifle). */
    private static final float[] RATING = {0.45f, 1.00f, 0.85f, 0.80f, 0.95f, 0.90f, 1.10f, 1.05f};

    private final int id;
    private final GameState st;
    private final GameWorld world;
    private final NavGrid nav;
    private final PathFinder pathFinder;
    private final BotDifficulty diff;
    private final XorShift rng;

    // target tracking
    private int target = -1;
    private float lastSeenX, lastSeenY;
    private float sinceSeen = 99f;
    private float reactTimer;
    private float jitterX, jitterY, jitterTimer;
    private boolean hitLatch;

    // movement
    private final float[] routeX = new float[PathFinder.MAX_WAYPOINTS];
    private final float[] routeY = new float[PathFinder.MAX_WAYPOINTS];
    private int routeLen, routeIdx;
    private float routeGoalX, routeGoalY;
    private float repathTimer;
    private float strafeDir = 1f, strafeTimer;
    private boolean hasWander;
    private float wanderX, wanderY;
    private int pickupGoal = -1;
    private float pickupCheck;

    // fire control
    private boolean burstOpen = true;
    private float burstClock;
    private boolean semiPulse;

    // stuck detection
    private float stuckClock, lastX, lastY, wantedSpeed, unstickTimer, unstickAngle;

    // output of one tick
    private float outMX, outMY;

    public BotBrain(int id, GameState st, GameWorld world, NavGrid nav, PathFinder pathFinder,
                    BotDifficulty diff, int seed) {
        this.id = id;
        this.st = st;
        this.world = world;
        this.nav = nav;
        this.pathFinder = pathFinder;
        this.diff = diff;
        this.rng = new XorShift(seed * 7919 + id * 104729 + 13);
        strafeDir = rng.nextFloat() < 0.5f ? 1f : -1f;
        burstClock = diff.burstOn * (0.6f + rng.nextFloat() * 0.8f);
    }

    /** Runs one decision step; call once per simulation tick before {@link GameWorld#step}. */
    public void think(float dt) {
        Player me = st.players[id];
        if (!me.connected) return;
        if (!me.alive || st.phase != GameState.PHASE_PLAYING) {
            world.setInput(id, 0f, 0f, me.aim, false, 0);
            forgetEverything();
            return;
        }

        updateTarget(me, dt);
        outMX = 0f;
        outMY = 0f;
        boolean firing = false;
        float aim = me.aim;
        float speed = diff.speed;

        if (target >= 0) {
            Player en = st.players[target];
            float dx = en.x - me.x;
            float dy = en.y - me.y;
            float dist = (float) Math.sqrt(dx * dx + dy * dy);
            combatMove(me, en, dx, dy, dist, dt);
            aim = aimAt(me, en, dist, dt);
            firing = fireDecision(me, aim, dist, dt);
        } else {
            roam(me, dt);
            if (outMX != 0f || outMY != 0f) aim = (float) Math.atan2(outMY, outMX);
            maintainWeapon(me);
        }

        if (unstickTimer > 0f) {
            unstickTimer -= dt;
            outMX = (float) Math.cos(unstickAngle) * 0.9f;
            outMY = (float) Math.sin(unstickAngle) * 0.9f;
        }
        trackStuck(me, dt);
        world.setInput(id, outMX * speed, outMY * speed, aim, firing, 0);
    }

    private void forgetEverything() {
        target = -1;
        sinceSeen = 99f;
        routeLen = 0;
        routeIdx = 0;
        hasWander = false;
        pickupGoal = -1;
        unstickTimer = 0f;
    }

    // ------------------------------------------------------------------ perception

    private void updateTarget(Player me, float dt) {
        sinceSeen += dt;
        if (reactTimer > 0f) reactTimer -= dt;
        CollisionSystem col = st.collision;
        int best = -1;
        float bestD2 = diff.sightRange * diff.sightRange;
        float keepD2 = Float.MAX_VALUE;
        if (target >= 0 && visible(me, st.players[target], col)) {
            Player t = st.players[target];
            float dx = t.x - me.x;
            float dy = t.y - me.y;
            keepD2 = dx * dx + dy * dy;
        }
        for (int j = 0; j < st.players.length; j++) {
            if (j == id) continue;
            Player q = st.players[j];
            if (!q.connected || !q.alive) continue;
            float dx = q.x - me.x;
            float dy = q.y - me.y;
            float d2 = dx * dx + dy * dy;
            if (d2 >= bestD2 || !visible(me, q, col)) continue;
            if (j == target) {
                best = j;
                bestD2 = d2;
            } else if (best != target || d2 < keepD2 * 0.36f) {
                best = j;
                bestD2 = d2;
            }
        }
        if (best >= 0) {
            if (best != target) reactTimer = diff.reaction * (0.7f + rng.nextFloat() * 0.6f);
            target = best;
            Player t = st.players[best];
            lastSeenX = t.x;
            lastSeenY = t.y;
            sinceSeen = 0f;
        } else {
            if (target >= 0) {
                Player t = st.players[target];
                if (t.alive) {
                    lastSeenX = t.x;
                    lastSeenY = t.y;
                }
            }
            target = -1;
        }
    }

    private boolean visible(Player me, Player q, CollisionSystem col) {
        if (!q.connected || !q.alive) return false;
        float dx = q.x - me.x;
        float dy = q.y - me.y;
        if (dx * dx + dy * dy > diff.sightRange * diff.sightRange) return false;
        return col.raycast(me.x, me.y, q.x, q.y) < 0f;
    }

    // ------------------------------------------------------------------ combat

    private void combatMove(Player me, Player en, float dx, float dy, float dist, float dt) {
        WeaponDef def = me.weapon.def;
        float preferred = MathUtil.clamp(def.range * 0.5f, 120f, 380f);
        float inv = dist > 1e-3f ? 1f / dist : 0f;
        float ux = dx * inv;
        float uy = dy * inv;

        strafeTimer -= dt;
        if (me.hitFlash > 0.1f) {
            if (!hitLatch) {
                strafeDir = -strafeDir;
                hitLatch = true;
            }
        } else {
            hitLatch = false;
        }
        if (strafeTimer <= 0f) {
            if (rng.nextFloat() < 0.55f) strafeDir = -strafeDir;
            strafeTimer = 0.7f + rng.nextFloat() * 1.1f;
        }

        // Too far and no straight walk: follow a route to the enemy instead of pushing at a wall.
        if (dist > preferred + 50f && !nav.lineClear(me.x, me.y, en.x, en.y, R)) {
            followRoute(me, en.x, en.y, dt);
            return;
        }
        float radial = 0f;
        if (dist > preferred + 50f) radial = 1f;
        else if (dist < preferred - 50f) radial = -1f;
        float sx = -uy * strafeDir * 0.85f;
        float sy = ux * strafeDir * 0.85f;
        steer(me, ux * radial + sx, uy * radial + sy);
    }

    private float aimAt(Player me, Player en, float dist, float dt) {
        jitterTimer -= dt;
        if (jitterTimer <= 0f) {
            jitterTimer = 0.25f + rng.nextFloat() * 0.2f;
            float a = rng.nextFloat() * MathUtil.TWO_PI;
            float m = diff.aimError * (0.35f + rng.nextFloat() * 0.65f);
            jitterX = (float) Math.cos(a) * m;
            jitterY = (float) Math.sin(a) * m;
        }
        float t = dist / me.weapon.def.projectileSpeed;
        float vx = en.moveX * GameConfig.PLAYER_SPEED;
        float vy = en.moveY * GameConfig.PLAYER_SPEED;
        float px = en.x + vx * t * diff.lead + jitterX;
        float py = en.y + vy * t * diff.lead + jitterY;
        return (float) Math.atan2(py - me.y, px - me.x);
    }

    private boolean fireDecision(Player me, float desiredAim, float dist, float dt) {
        Weapon w = me.weapon;
        WeaponDef def = w.def;
        if (w.ammo <= 0 && !w.reloading) world.requestReload(id);
        if (reactTimer > 0f || w.reloading || w.ammo <= 0) return false;
        if (dist > def.range * 0.95f) return false;
        float err = Math.abs(MathUtil.angleDiff(me.aim, desiredAim));
        float bodyAngle = (float) Math.atan2(GameConfig.PLAYER_RADIUS, Math.max(dist, 40f));
        float tolerance = Math.min(diff.fireTolerance, Math.max(bodyAngle * 1.5f, 0.03f));
        if (err > tolerance) return false;
        if (def.automatic && diff.burstOff > 0f) {
            burstClock -= dt;
            if (burstClock <= 0f) {
                burstOpen = !burstOpen;
                float len = burstOpen ? diff.burstOn : diff.burstOff;
                burstClock = len * (0.7f + rng.nextFloat() * 0.6f);
            }
            if (!burstOpen) return false;
        }
        if (!def.automatic) {
            semiPulse = !semiPulse;
            return semiPulse;
        }
        return true;
    }

    private void maintainWeapon(Player me) {
        Weapon w = me.weapon;
        if (!w.reloading && w.ammo < w.def.magSize * 0.4f) world.requestReload(id);
    }

    // ------------------------------------------------------------------ roaming

    private void roam(Player me, float dt) {
        if (sinceSeen < MEMORY_SECONDS) {
            // Just lost sight of somebody: go where they were.
            if (dist2(me.x, me.y, lastSeenX, lastSeenY) > 30f * 30f) {
                followRoute(me, lastSeenX, lastSeenY, dt);
                return;
            }
        }
        pickupCheck -= dt;
        if (pickupCheck <= 0f) {
            pickupCheck = 1f + rng.nextFloat() * 0.5f;
            pickupGoal = choosePickup(me);
        }
        if (pickupGoal >= 0) {
            Pickup pk = st.pickups[pickupGoal];
            if (!pk.active) {
                pickupGoal = -1;
            } else {
                followRoute(me, pk.x, pk.y, dt);
                return;
            }
        }
        if (!hasWander || dist2(me.x, me.y, wanderX, wanderY) < 28f * 28f || routeIdx >= routeLen && routeLen > 0) {
            chooseWander(me);
        }
        followRoute(me, wanderX, wanderY, dt);
    }

    private int choosePickup(Player me) {
        float mine = rating(me.weapon.def.id) + (me.weapon.ammo < me.weapon.def.magSize * 0.25f ? 0.25f : 0f);
        int best = -1;
        float bestScore = 0f;
        for (int i = 0; i < st.pickups.length; i++) {
            Pickup pk = st.pickups[i];
            if (!pk.active) continue;
            float d = (float) Math.sqrt(dist2(me.x, me.y, pk.x, pk.y));
            if (d > diff.pickupRange) continue;
            float gain = rating(pk.weaponId) - mine;
            if (gain < 0.08f) continue;
            float score = gain * 700f - d;
            if (score > bestScore) {
                bestScore = score;
                best = i;
            }
        }
        return best;
    }

    private static float rating(int weaponId) {
        return weaponId >= 0 && weaponId < RATING.length ? RATING[weaponId] : 0.5f;
    }

    private void chooseWander(Player me) {
        hasWander = false;
        routeLen = 0;
        if (rng.nextFloat() < diff.aggression) {
            // Hunt: head for the general area of a random living enemy.
            int pick = -1;
            int seen = 0;
            for (int j = 0; j < st.players.length; j++) {
                Player q = st.players[j];
                if (j == id || !q.connected || !q.alive) continue;
                seen++;
                if (rng.nextFloat() * seen < 1f) pick = j;
            }
            if (pick >= 0) {
                Player q = st.players[pick];
                float gx = q.x + rng.nextSigned() * 140f;
                float gy = q.y + rng.nextSigned() * 140f;
                int tile = nav.nearestWalkable(nav.tileOf(gx, gy));
                if (tile >= 0) {
                    wanderX = nav.centerX(tile);
                    wanderY = nav.centerY(tile);
                    hasWander = true;
                    return;
                }
            }
        }
        for (int tries = 0; tries < 24; tries++) {
            int tx = (int) (rng.nextFloat() * nav.width);
            int ty = (int) (rng.nextFloat() * nav.height);
            if (!nav.walkable(tx, ty)) continue;
            float gx = (tx + 0.5f) * GameConfig.TILE;
            float gy = (ty + 0.5f) * GameConfig.TILE;
            if (dist2(me.x, me.y, gx, gy) < 250f * 250f) continue;
            wanderX = gx;
            wanderY = gy;
            hasWander = true;
            return;
        }
        int tile = nav.nearestWalkable(nav.tileOf(me.x, me.y));
        if (tile >= 0) {
            wanderX = nav.centerX(tile);
            wanderY = nav.centerY(tile);
            hasWander = true;
        }
    }

    // ------------------------------------------------------------------ path following and steering

    private void followRoute(Player me, float gx, float gy, float dt) {
        repathTimer -= dt;
        boolean goalMoved = dist2(gx, gy, routeGoalX, routeGoalY) > 48f * 48f;
        if (routeLen == 0 || goalMoved || repathTimer <= 0f) {
            repathTimer = REPATH_SECONDS + rng.nextFloat() * 0.4f;
            routeLen = 0;
            routeIdx = 0;
            routeGoalX = gx;
            routeGoalY = gy;
            if (pathFinder.find(me.x, me.y, gx, gy, R)) {
                routeLen = pathFinder.count;
                System.arraycopy(pathFinder.wx, 0, routeX, 0, routeLen);
                System.arraycopy(pathFinder.wy, 0, routeY, 0, routeLen);
            }
        }
        if (routeLen == 0) return;
        while (routeIdx < routeLen - 1 && dist2(me.x, me.y, routeX[routeIdx], routeY[routeIdx]) < WAYPOINT_REACH * WAYPOINT_REACH) {
            routeIdx++;
        }
        if (routeIdx + 1 < routeLen && nav.lineClear(me.x, me.y, routeX[routeIdx + 1], routeY[routeIdx + 1], R)) routeIdx++;
        float wx = routeX[routeIdx];
        float wy = routeY[routeIdx];
        float dx = wx - me.x;
        float dy = wy - me.y;
        float d = (float) Math.sqrt(dx * dx + dy * dy);
        if (routeIdx == routeLen - 1 && d < 8f) {
            routeIdx = routeLen;
            return;
        }
        if (routeIdx >= routeLen) return;
        steer(me, dx, dy);
    }

    /**
     * Walks in (roughly) the wanted direction, swinging aside when something is in the way. When every
     * direction looks blocked (a tight corner) it simply pushes ahead: the collision system slides the
     * body around the corner, and the stuck detector takes over if that does not work.
     */
    private void steer(Player me, float dx, float dy) {
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len < 1e-3f) return;
        if (len > 1f) {
            dx /= len;
            dy /= len;
            len = 1f;
        }
        float base = (float) Math.atan2(dy, dx);
        for (float off : STEER_OFFSETS) {
            float a = base + off;
            float cx = (float) Math.cos(a);
            float cy = (float) Math.sin(a);
            if (nav.lineClear(me.x, me.y, me.x + cx * 16f, me.y + cy * 16f, R * 0.75f)) {
                float k = off == 0f ? len : len * 0.8f;
                outMX = cx * k;
                outMY = cy * k;
                return;
            }
        }
        outMX = dx;
        outMY = dy;
    }

    private void trackStuck(Player me, float dt) {
        wantedSpeed = Math.max(wantedSpeed, (float) Math.sqrt(outMX * outMX + outMY * outMY));
        stuckClock += dt;
        if (stuckClock < 0.6f) return;
        float moved = (float) Math.sqrt(dist2(me.x, me.y, lastX, lastY));
        if (wantedSpeed > 0.5f && moved < 6f && unstickTimer <= 0f) {
            unstickTimer = 0.45f;
            unstickAngle = rng.nextFloat() * MathUtil.TWO_PI;
            routeLen = 0;
            hasWander = false;
            strafeDir = -strafeDir;
        }
        lastX = me.x;
        lastY = me.y;
        stuckClock = 0f;
        wantedSpeed = 0f;
    }

    private static float dist2(float ax, float ay, float bx, float by) {
        float dx = ax - bx;
        float dy = ay - by;
        return dx * dx + dy * dy;
    }
}
