package com.hazardyard.game.render;

import android.graphics.Canvas;
import android.graphics.Paint;

import com.hazardyard.game.core.GameConfig;
import com.hazardyard.game.core.GameState;
import com.hazardyard.game.core.Pickup;
import com.hazardyard.game.core.Player;
import com.hazardyard.game.core.PlayerColors;
import com.hazardyard.game.core.TileMap;
import com.hazardyard.game.core.WeaponDef;

/**
 * Everything that lies flat on the ground: floor slabs, grid, stains, spawn pads, weapon pads,
 * toxic pools / canals and the marks left by fallen soldiers. Only the visible tiles are drawn.
 */
final class FloorRenderer {
    private static final float T = GameConfig.TILE;

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float[] grid;
    private TileMap gridMap;

    FloorRenderer() {
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.ROUND);
    }

    void draw(Canvas c, GameState st, MapTheme th, float scale, float time, float vx0, float vx1, float vy0, float vy1) {
        TileMap map = st.map;
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(th.floorA);
        c.drawRect(0f, 0f, map.worldW, map.worldH, fill);

        int tx0 = Math.max(0, (int) Math.floor(vx0 / T));
        int tx1 = Math.min(map.width - 1, (int) Math.floor(vx1 / T));
        int ty0 = Math.max(0, (int) Math.floor(vy0 / T));
        int ty1 = Math.min(map.height - 1, (int) Math.floor(vy1 / T));

        // Two-by-two tile slabs in alternating shades.
        fill.setColor(th.floorB);
        for (int ty = ty0; ty <= ty1; ty++) {
            for (int tx = tx0; tx <= tx1; tx++) {
                if ((((tx >> 1) + (ty >> 1)) & 1) == 0) continue;
                c.drawRect(tx * T, ty * T, tx * T + T, ty * T + T, fill);
            }
        }

        drawGrid(c, map, th, scale);
        drawStains(c, map, th, tx0, tx1, ty0, ty1);
        drawWater(c, map, th, time, vx0, vx1, vy0, vy1);
        drawSpawnPads(c, map, th, vx0, vx1, vy0, vy1);
        drawPickupPads(c, st, time, vx0, vx1, vy0, vy1);
        drawCorpses(c, st, vx0, vx1, vy0, vy1);
    }

    private void drawGrid(Canvas c, TileMap map, MapTheme th, float scale) {
        if (gridMap != map) {
            gridMap = map;
            int vertical = map.width + 1;
            int horizontal = map.height + 1;
            grid = new float[(vertical + horizontal) * 4];
            int k = 0;
            for (int x = 0; x < vertical; x++) {
                grid[k++] = x * T;
                grid[k++] = 0f;
                grid[k++] = x * T;
                grid[k++] = map.worldH;
            }
            for (int y = 0; y < horizontal; y++) {
                grid[k++] = 0f;
                grid[k++] = y * T;
                grid[k++] = map.worldW;
                grid[k++] = y * T;
            }
        }
        line.setColor(th.grid);
        line.setStrokeWidth(1.2f / scale);
        c.drawLines(grid, 0, grid.length, line);
    }

    /** Sparse, deterministic grime: oil stains and hairline cracks, never the same tile twice. */
    private void drawStains(Canvas c, TileMap map, MapTheme th, int tx0, int tx1, int ty0, int ty1) {
        for (int ty = ty0; ty <= ty1; ty++) {
            for (int tx = tx0; tx <= tx1; tx++) {
                if (map.isSolid(tx, ty)) continue;
                int h = hash(tx, ty);
                int m = h % 31;
                float cx = tx * T + 6f + ((h >> 8) & 15);
                float cy = ty * T + 6f + ((h >> 12) & 15);
                if (m == 0) {
                    float r = 5f + ((h >> 16) & 5);
                    fill.setColor(0x16000000);
                    c.drawCircle(cx, cy, r, fill);
                    fill.setColor(0x10000000);
                    c.drawCircle(cx + 1.5f, cy + 1f, r * 0.55f, fill);
                } else if (m == 1 || m == 2) {
                    line.setColor(th.grid);
                    line.setStrokeWidth(1.1f);
                    float dx = ((h >> 5) & 15) - 7f;
                    c.drawLine(cx, cy, cx + dx, cy + 9f, line);
                    c.drawLine(cx + dx, cy + 9f, cx + dx * 0.4f + 6f, cy + 17f, line);
                }
            }
        }
    }

    private void drawWater(Canvas c, TileMap map, MapTheme th, float time, float vx0, float vx1, float vy0, float vy1) {
        for (int b = 0; b < map.blockCount; b++) {
            int o = b * 5;
            if (map.blocks[o + 4] != TileMap.WATER) continue;
            float x0 = map.blocks[o] * T;
            float y0 = map.blocks[o + 1] * T;
            float bw = map.blocks[o + 2] * T;
            float bh = map.blocks[o + 3] * T;
            float x1 = x0 + bw;
            float y1 = y0 + bh;
            if (x1 < vx0 || x0 > vx1 || y1 < vy0 || y0 > vy1) continue;

            fill.setColor(th.waterDeep);
            c.drawRect(x0, y0, x1, y1, fill);
            fill.setColor(0x33000000);                       // the far bank shades the water
            c.drawRect(x0, y0, x1, Math.min(y1, y0 + 6f), fill);
            fill.setColor(0x22FFFFFF);                       // soft light near the south bank
            c.drawRect(x0, Math.max(y0, y1 - 4f), x1, y1, fill);

            // Ripples.
            int rows = map.blocks[o + 3];
            line.setStrokeWidth(1.3f);
            for (int r = 0; r < rows; r++) {
                float y = y0 + (r + 0.5f) * T + (float) Math.sin(time * 1.6f + r * 1.7f + x0 * 0.03f) * 3f;
                if (y < vy0 - 4f || y > vy1 + 4f) continue;
                line.setColor(Palette.withAlpha(th.waterLight, 70));
                c.drawLine(x0 + 6f, y, x1 - 6f, y, line);
                line.setColor(Palette.withAlpha(th.waterLight, 40));
                float y2 = y + 9f;
                if (y2 < y1 - 3f) c.drawLine(x0 + bw * 0.25f, y2, x1 - bw * 0.15f, y2, line);
            }
            // Bubbles drifting up.
            int bubbles = Math.min(14, (int) (bw * bh / (T * T * 2f)) + 1);
            fill.setColor(Palette.withAlpha(th.waterEdge, 70));
            for (int k = 0; k < bubbles; k++) {
                int h = hash(b * 31 + k, k * 7 + 3);
                float fx = ((h & 0xFFFF) / 65535f);
                float fy = (time * (0.07f + 0.05f * ((h >> 16) & 3)) + ((h >> 8) & 255) / 255f) % 1f;
                c.drawCircle(x0 + 5f + fx * (bw - 10f), y1 - 3f - fy * (bh - 6f), 1.2f + ((h >> 20) & 3) * 0.5f, fill);
            }

            // Bank outline.
            line.setColor(Palette.withAlpha(th.waterEdge, 150));
            line.setStrokeWidth(1.6f);
            c.drawRect(x0 + 0.8f, y0 + 0.8f, x1 - 0.8f, y1 - 0.8f, line);

            if (th.stripes) drawHazardEdge(c, th, x0, y0, x1, y1);
        }
    }

    /** Yellow/black warning stripes inside the north and south bank of a pool. */
    private void drawHazardEdge(Canvas c, MapTheme th, float x0, float y0, float x1, float y1) {
        final float seg = 8f;
        final float band = 3.2f;
        for (int side = 0; side < 2; side++) {
            float yy = side == 0 ? y0 + 1.6f : y1 - 1.6f - band;
            int n = 0;
            for (float x = x0 + 1.6f; x < x1 - 1.6f; x += seg, n++) {
                fill.setColor((n & 1) == 0 ? th.stripeA : th.stripeB);
                c.drawRect(x, yy, Math.min(x + seg, x1 - 1.6f), yy + band, fill);
            }
        }
    }

    private void drawSpawnPads(Canvas c, TileMap map, MapTheme th, float vx0, float vx1, float vy0, float vy1) {
        line.setColor(Palette.withAlpha(th.accent, 90));
        line.setStrokeWidth(1.8f);
        fill.setColor(Palette.withAlpha(th.accent, 18));
        for (int i = 0; i < map.spawnX.length; i++) {
            float x = map.spawnX[i];
            float y = map.spawnY[i];
            if (x < vx0 - 30f || x > vx1 + 30f || y < vy0 - 30f || y > vy1 + 30f) continue;
            c.drawCircle(x, y, 13f, fill);
            c.drawCircle(x, y, 13f, line);
            c.drawCircle(x, y, 6.5f, line);
        }
    }

    private void drawPickupPads(Canvas c, GameState st, float time, float vx0, float vx1, float vy0, float vy1) {
        for (int i = 0; i < st.pickups.length; i++) {
            Pickup pk = st.pickups[i];
            if (pk.x < vx0 - 30f || pk.x > vx1 + 30f || pk.y < vy0 - 30f || pk.y > vy1 + 30f) continue;
            WeaponDef d = WeaponDef.byId(pk.weaponId);
            if (!pk.active) {
                line.setColor(Palette.withAlpha(d.color, 55));
                line.setStrokeWidth(1.4f);
                c.drawCircle(pk.x, pk.y, 10f, line);
                continue;
            }
            float pulse = 0.5f + 0.5f * (float) Math.sin(time * 3.4f + i);
            fill.setColor(Palette.withAlpha(d.color, 36 + (int) (34f * pulse)));
            c.drawCircle(pk.x, pk.y, 17f + 1.5f * pulse, fill);
            fill.setColor(0x55000000);
            c.drawCircle(pk.x, pk.y, 11f, fill);
            line.setColor(Palette.withAlpha(d.color, 190));
            line.setStrokeWidth(1.8f);
            c.drawCircle(pk.x, pk.y, 12.5f, line);
        }
    }

    private void drawCorpses(Canvas c, GameState st, float vx0, float vx1, float vy0, float vy1) {
        for (int i = 0; i < st.players.length; i++) {
            Player p = st.players[i];
            if (!p.connected || p.alive) continue;
            if (p.rx < vx0 - 24f || p.rx > vx1 + 24f || p.ry < vy0 - 24f || p.ry > vy1 + 24f) continue;
            int col = PlayerColors.of(i);
            fill.setColor(0x55000000);
            c.drawCircle(p.rx, p.ry, GameConfig.PLAYER_RADIUS * 0.95f, fill);
            fill.setColor(Palette.withAlpha(col, 60));
            c.drawCircle(p.rx, p.ry, GameConfig.PLAYER_RADIUS * 0.6f, fill);
            line.setColor(Palette.withAlpha(col, 190));
            line.setStrokeWidth(2.4f);
            c.drawLine(p.rx - 6f, p.ry - 6f, p.rx + 6f, p.ry + 6f, line);
            c.drawLine(p.rx + 6f, p.ry - 6f, p.rx - 6f, p.ry + 6f, line);
        }
    }

    /** Small, stable, well-mixed hash of two ints, always non-negative. */
    static int hash(int a, int b) {
        int h = a * 0x27D4EB2D + b * 0x165667B1;
        h ^= h >>> 15;
        h *= 0x2C1B3C6D;
        h ^= h >>> 12;
        return h & 0x7FFFFFFF;
    }
}
