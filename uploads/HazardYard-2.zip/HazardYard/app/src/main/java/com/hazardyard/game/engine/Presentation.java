package com.hazardyard.game.engine;

import com.hazardyard.game.core.Effects;
import com.hazardyard.game.core.GameConfig;
import com.hazardyard.game.core.GameState;
import com.hazardyard.game.core.PlayerColors;
import com.hazardyard.game.core.Player;
import com.hazardyard.game.core.WeaponDef;

/**
 * The visual and audible side of gameplay events, shared by every engine (host, solo, client) so a
 * muzzle flash or a kill looks and sounds the same wherever the match is simulated.
 */
final class Presentation {
    private Presentation() {}

    static void shot(GameState st, int weaponId, float x, float y, float angle) {
        WeaponDef d = WeaponDef.byId(weaponId);
        float reach = GameConfig.PLAYER_RADIUS + d.barrelLength;
        st.effects.muzzle(x + (float) Math.cos(angle) * reach, y + (float) Math.sin(angle) * reach, angle, d.color);
        st.audio.shot(d.id, x, y);
    }

    static void hit(GameState st, int victimId, float x, float y, int weaponId, int damage) {
        st.effects.impact(x, y, WeaponDef.byId(weaponId).color);
        if (damage > 0) st.audio.projectileHit(victimId, x, y);
    }

    static void wallImpact(GameState st, float x, float y, int weaponId) {
        st.effects.impact(x, y, WeaponDef.byId(weaponId).color);
        st.audio.wallImpact(x, y);
    }

    static void kill(GameState st, int killerId, int victimId, int weaponId) {
        Effects fx = st.effects;
        fx.addKill(killerId, victimId, weaponId);
        if (victimId < 0 || victimId >= st.players.length) return;
        Player v = st.players[victimId];
        fx.burst(v.rx, v.ry, PlayerColors.of(victimId));
        st.audio.kill(killerId, victimId, v.rx, v.ry);
    }
}
