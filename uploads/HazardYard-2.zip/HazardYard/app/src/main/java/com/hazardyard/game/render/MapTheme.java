package com.hazardyard.game.render;

import com.hazardyard.game.core.MapLibrary;

/** The colours and small style choices that give each arena its own look. */
public final class MapTheme {
    // ground
    public final int floorA, floorB, grid, decal, accent, backdrop;
    // walls (top face, south face, west face)
    public final int wallTop, wallFront, wallSide, wallTrim;
    // crates
    public final int crateTop, crateFront, crateSide, crateDark;
    // pools / canals
    public final int waterDeep, waterLight, waterEdge;
    /** Draw hazard stripes along the edge of the pools. */
    public final boolean stripes;
    public final int stripeA, stripeB;
    public final int fence;

    private MapTheme(int floorA, int floorB, int grid, int decal, int accent, int backdrop,
                     int wallTop, int wallFront, int wallSide, int wallTrim,
                     int crateTop, int crateFront, int crateSide, int crateDark,
                     int waterDeep, int waterLight, int waterEdge, boolean stripes, int stripeA, int stripeB, int fence) {
        this.floorA = floorA;
        this.floorB = floorB;
        this.grid = grid;
        this.decal = decal;
        this.accent = accent;
        this.backdrop = backdrop;
        this.wallTop = wallTop;
        this.wallFront = wallFront;
        this.wallSide = wallSide;
        this.wallTrim = wallTrim;
        this.crateTop = crateTop;
        this.crateFront = crateFront;
        this.crateSide = crateSide;
        this.crateDark = crateDark;
        this.waterDeep = waterDeep;
        this.waterLight = waterLight;
        this.waterEdge = waterEdge;
        this.stripes = stripes;
        this.stripeA = stripeA;
        this.stripeB = stripeB;
        this.fence = fence;
    }

    private static final MapTheme[] THEMES = new MapTheme[MapLibrary.COUNT];

    static {
        // Hazard Yard: cool concrete, yellow hazard markings, toxic green pools.
        THEMES[MapLibrary.HAZARD_YARD] = new MapTheme(
                0xFF27313C, 0xFF2C3744, 0xFF212A34, 0xFF3B4958, 0xFFF2C230, 0xFF0E1319,
                0xFF93A4BE, 0xFF566B88, 0xFF3D4D64, 0xFF2A3445,
                0xFFDDA760, 0xFFB27A35, 0xFF86571F, 0xFF603E14,
                0xFF1B6A3B, 0xFF3DC46E, 0xFF8DF2AB, true, 0xFFF2C230, 0xFF1A1D22, 0xFFC4CEDC);
        // Dockside Warehouse: dark slab, steel containers, blue canal.
        THEMES[MapLibrary.DOCKSIDE] = new MapTheme(
                0xFF2A2E37, 0xFF2F343E, 0xFF242831, 0xFF3D4452, 0xFF54B6F5, 0xFF0D1117,
                0xFF7E98B4, 0xFF4E6A89, 0xFF354B63, 0xFF273445,
                0xFFCFA063, 0xFFA87740, 0xFF7C5326, 0xFF593A18,
                0xFF123B66, 0xFF2F88CC, 0xFF93D2FF, false, 0xFF54B6F5, 0xFF1A1D22, 0xFFB5C3D6);
        // Toxic Foundry: warm dark metal, orange glow, bright toxic moat.
        THEMES[MapLibrary.FOUNDRY] = new MapTheme(
                0xFF2B2624, 0xFF312B28, 0xFF251F1D, 0xFF4B3B34, 0xFFFF8A3D, 0xFF0F0C0B,
                0xFFA39690, 0xFF6A5D58, 0xFF4B403C, 0xFF372E2B,
                0xFFE29C58, 0xFFB86A2F, 0xFF8A4A1F, 0xFF5E3112,
                0xFF135D2E, 0xFF55F585, 0xFFB9FFCC, true, 0xFFFF8A3D, 0xFF1A1512, 0xFFC9BCB4);
        // Ruined Outpost: sand and sandstone, turquoise oasis.
        THEMES[MapLibrary.OUTPOST] = new MapTheme(
                0xFF7A6A4A, 0xFF807050, 0xFF6E6043, 0xFF94835C, 0xFFE8C26A, 0xFF1A150D,
                0xFFDCC590, 0xFFB69E6C, 0xFF8D7751, 0xFF6B5A3B,
                0xFFA87444, 0xFF875A2C, 0xFF65411F, 0xFF472C12,
                0xFF0F6D72, 0xFF39C7C6, 0xFFB7F3F0, false, 0xFFE8C26A, 0xFF1A1D22, 0xFF584A33);
        // Bunker Complex: cold steel, green indicator lights.
        THEMES[MapLibrary.BUNKER] = new MapTheme(
                0xFF1F262D, 0xFF232B33, 0xFF1A2026, 0xFF334049, 0xFF6DD47E, 0xFF0A0E12,
                0xFF8393A4, 0xFF4F5D6C, 0xFF38444F, 0xFF27313B,
                0xFF8A9E57, 0xFF66773D, 0xFF4B5A2C, 0xFF343F1E,
                0xFF123B66, 0xFF2F88CC, 0xFF93D2FF, false, 0xFF6DD47E, 0xFF1A1D22, 0xFFB5C3D6);
    }

    public static MapTheme of(int mapId) {
        return THEMES[MapLibrary.clampId(mapId)];
    }
}
