package com.hazardyard.game.core;

import java.util.Arrays;

/**
 * Tile grid of the arena. Walls and crates block players and bullets; fences and toxic pools block
 * players only (bullets fly over them), which makes them useful low cover and map dividers. Also
 * holds spawn points, weapon pickup locations and a list of merged solid rectangles so the renderer
 * draws a few dozen rectangles instead of one per tile.
 */
public final class TileMap {
    public static final byte FLOOR = 0;
    public static final byte WALL = 1;
    public static final byte CRATE = 2;
    /** Chain-link fence: players cannot cross it, bullets pass through. */
    public static final byte FENCE = 3;
    /** Toxic pool / canal: players cannot cross it, bullets pass over it. */
    public static final byte WATER = 4;

    /** Which {@link MapLibrary} entry this is (the renderer picks its theme from it). */
    public final int id;
    public final int width;
    public final int height;
    public final byte[] tiles;
    public final float worldW;
    public final float worldH;

    public final float[] spawnX;
    public final float[] spawnY;
    public final float[] pickupX;
    public final float[] pickupY;
    public final int[] pickupWeapon;

    /**
     * Merged non-floor rectangles, 5 ints each: tileX, tileY, tilesW, tilesH, kind. Sorted by their
     * south edge (then by x), which is the order the renderer needs for correct overlap.
     */
    public final int[] blocks;
    public final int blockCount;

    private TileMap(int id, int width, int height, byte[] tiles, float[] sx, float[] sy,
                    float[] px, float[] py, int[] pw, int[] blocks, int blockCount) {
        this.id = id;
        this.width = width;
        this.height = height;
        this.tiles = tiles;
        this.worldW = width * GameConfig.TILE;
        this.worldH = height * GameConfig.TILE;
        this.spawnX = sx;
        this.spawnY = sy;
        this.pickupX = px;
        this.pickupY = py;
        this.pickupWeapon = pw;
        this.blocks = blocks;
        this.blockCount = blockCount;
    }

    /** Blocks player movement. Anything outside the grid counts as solid, so nothing can leave the arena. */
    public boolean isSolid(int tx, int ty) {
        if (tx < 0 || ty < 0 || tx >= width || ty >= height) return true;
        return tiles[ty * width + tx] != FLOOR;
    }

    public boolean isSolidAt(float wx, float wy) {
        return isSolid((int) Math.floor(wx / GameConfig.TILE), (int) Math.floor(wy / GameConfig.TILE));
    }

    /** Stops bullets: walls and crates only (and the outside of the grid). */
    public boolean blocksShots(int tx, int ty) {
        if (tx < 0 || ty < 0 || tx >= width || ty >= height) return true;
        byte k = tiles[ty * width + tx];
        return k == WALL || k == CRATE;
    }

    public byte kindAt(int tx, int ty) {
        if (tx < 0 || ty < 0 || tx >= width || ty >= height) return WALL;
        return tiles[ty * width + tx];
    }

    /** The weapon a map letter stands for, or -1 when the letter is not a weapon pickup. */
    public static int weaponForLetter(char c) {
        switch (c) {
            case 'R': return WeaponDef.RIFLE;
            case 'G': return WeaponDef.SHOTGUN;
            case 'M': return WeaponDef.SMG;
            case 'N': return WeaponDef.SNIPER;
            case 'V': return WeaponDef.MAGNUM;
            case 'P': return WeaponDef.PLASMA;
            case 'K': return WeaponDef.LMG;
            default: return -1;
        }
    }

    /**
     * Legend: {@code #} wall, {@code C} crate, {@code +} fence, {@code ~} toxic pool, {@code .} floor,
     * {@code S} spawn point, and one letter per weapon pickup (R rifle, G shotgun, M SMG, N sniper,
     * V magnum, P plasma, K light MG). All rows must have the same length; an unknown character is an error.
     */
    public static TileMap parse(int id, String[] rows) {
        int h = rows.length;
        int w = rows[0].length();
        byte[] tiles = new byte[w * h];
        int spawns = 0;
        int pickups = 0;
        int solid = 0;
        for (int y = 0; y < h; y++) {
            if (rows[y].length() != w) throw new IllegalArgumentException("Map row " + y + " has wrong length");
            for (int x = 0; x < w; x++) {
                char c = rows[y].charAt(x);
                byte kind = FLOOR;
                if (c == '#') kind = WALL;
                else if (c == 'C') kind = CRATE;
                else if (c == '+') kind = FENCE;
                else if (c == '~') kind = WATER;
                else if (c == 'S') spawns++;
                else if (weaponForLetter(c) >= 0) pickups++;
                else if (c != '.') throw new IllegalArgumentException("Unknown map tile '" + c + "' at " + x + "," + y);
                tiles[y * w + x] = kind;
                if (kind != FLOOR) solid++;
            }
        }
        float[] sx = new float[spawns];
        float[] sy = new float[spawns];
        float[] px = new float[pickups];
        float[] py = new float[pickups];
        int[] pw = new int[pickups];
        int si = 0;
        int pi = 0;
        float t = GameConfig.TILE;
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                char c = rows[y].charAt(x);
                float cx = (x + 0.5f) * t;
                float cy = (y + 0.5f) * t;
                if (c == 'S') {
                    sx[si] = cx;
                    sy[si] = cy;
                    si++;
                } else if (weaponForLetter(c) >= 0) {
                    px[pi] = cx;
                    py[pi] = cy;
                    pw[pi] = weaponForLetter(c);
                    pi++;
                }
            }
        }

        // Greedy rectangle merge of non-floor tiles of the same kind (used for drawing only).
        boolean[] used = new boolean[w * h];
        int[] raw = new int[5 * Math.max(1, solid)];
        int bc = 0;
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int i = y * w + x;
                byte kind = tiles[i];
                if (kind == FLOOR || used[i]) continue;
                int bw = 1;
                while (x + bw < w && tiles[i + bw] == kind && !used[i + bw]) bw++;
                int bh = 1;
                boolean grow = true;
                while (grow && y + bh < h) {
                    for (int k = 0; k < bw; k++) {
                        int j = (y + bh) * w + x + k;
                        if (tiles[j] != kind || used[j]) {
                            grow = false;
                            break;
                        }
                    }
                    if (grow) bh++;
                }
                for (int yy = 0; yy < bh; yy++) {
                    for (int xx = 0; xx < bw; xx++) used[(y + yy) * w + x + xx] = true;
                }
                raw[bc * 5] = x;
                raw[bc * 5 + 1] = y;
                raw[bc * 5 + 2] = bw;
                raw[bc * 5 + 3] = bh;
                raw[bc * 5 + 4] = kind;
                bc++;
            }
        }

        // Order by south edge, then x, so drawing back-to-front is a single pass.
        long[] keys = new long[bc];
        for (int b = 0; b < bc; b++) {
            long south = raw[b * 5 + 1] + raw[b * 5 + 3];
            keys[b] = (south << 40) | ((long) raw[b * 5] << 20) | b;
        }
        Arrays.sort(keys);
        int[] blocks = new int[bc * 5];
        for (int n = 0; n < bc; n++) {
            int b = (int) (keys[n] & 0xFFFFF);
            System.arraycopy(raw, b * 5, blocks, n * 5, 5);
        }
        return new TileMap(id, w, h, tiles, sx, sy, px, py, pw, blocks, bc);
    }
}
