package com.hazardyard.game.ui;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.hazardyard.game.net.DiscoveryScanner;
import com.hazardyard.game.net.Protocol;
import com.hazardyard.game.render.Palette;

import java.util.List;

/** Lists games found on the local network and offers joining by typing the host's address. */
final class JoinScreen implements Screen {
    private final Context ctx;
    private final Navigator nav;
    private final ScreenPadding padding;
    private final FrameLayout root;
    private final LinearLayout list;
    private final TextView status;
    private final EditText addressField;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private DiscoveryScanner scanner;
    private final Runnable refresh = new Runnable() {
        @Override
        public void run() {
            rebuildList();
        }
    };

    JoinScreen(Context c, Navigator navigator) {
        ctx = c;
        nav = navigator;
        root = new FrameLayout(c);
        root.addView(new BackdropView(c), new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout content = new LinearLayout(c);
        content.setOrientation(LinearLayout.HORIZONTAL);
        padding = new ScreenPadding(content, c, 40, 30, 40, 30);
        root.addView(content, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // ---- left: discovered games ----
        LinearLayout left = Ui.column(c);
        content.addView(left, Ui.lp(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f, 0, 0, 24, 0, c));
        left.addView(Ui.label(c, "Join a game", 32f, Palette.TEXT, true));
        left.addView(new BackdropView.StripeBar(c), Ui.lp(Ui.dp(c, 110), Ui.dp(c, 8), 0f, 0, 8, 0, 0, c));
        status = Ui.label(c, "Searching this network\u2026", 14f, Palette.TEXT_DIM, false);
        left.addView(status, Ui.fillWidth(c, 12));

        ScrollView scroll = new ScrollView(c);
        scroll.setVerticalScrollBarEnabled(false);
        left.addView(scroll, Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f, 0, 10, 0, 0, c));
        list = Ui.column(c);
        scroll.addView(list, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // ---- right: manual address + back ----
        ScrollView rightScroll = new ScrollView(c);
        rightScroll.setVerticalScrollBarEnabled(false);
        content.addView(rightScroll, Ui.lp(Ui.dp(c, 300), ViewGroup.LayoutParams.MATCH_PARENT, 0f, 0, 0, 0, 0, c));
        LinearLayout right = Ui.column(c);
        rightScroll.addView(right, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout panel = Ui.panel(c);
        right.addView(panel, Ui.fillWidth(c, 0));
        panel.addView(Ui.label(c, "Join by address", 16f, Palette.TEXT, true));
        TextView why = Ui.label(c, "If your game does not show up, type the address shown in the host's lobby.", 12f,
                Palette.TEXT_DIM, false);
        panel.addView(why, Ui.fillWidth(c, 6));
        addressField = new EditText(c);
        addressField.setSingleLine(true);
        addressField.setHint("192.168.1.23");
        addressField.setTextColor(Palette.TEXT);
        addressField.setHintTextColor(Palette.TEXT_DIM);
        addressField.setTypeface(Ui.MEDIUM);
        addressField.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 18f);
        addressField.setPadding(Ui.dp(c, 14), 0, Ui.dp(c, 14), 0);
        addressField.setBackground(Ui.rounded(c, 0xFF0F151C, 0xFF3A4757, 10f, 1.5f));
        addressField.setInputType(InputType.TYPE_CLASS_PHONE);
        addressField.setImeOptions(EditorInfo.IME_ACTION_DONE | EditorInfo.IME_FLAG_NO_EXTRACT_UI);
        panel.addView(addressField, Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(c, 48), 0f, 0, 10, 0, 0, c));
        Button connect = Ui.button(c, "Connect", true);
        connect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                connectManually();
            }
        });
        panel.addView(connect, Ui.fillWidth(c, 12));

        Button back = Ui.button(c, "Back", false);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nav.showMenu(null);
            }
        });
        right.addView(back, Ui.fillWidth(c, 14));
        rebuildList();
    }

    private void connectManually() {
        String text = addressField.getText().toString().trim();
        InputMethodManager imm = (InputMethodManager) ctx.getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(addressField.getWindowToken(), 0);
        if (text.isEmpty()) {
            nav.toast("Enter the host's address first.");
            return;
        }
        String host = text;
        int port = Protocol.GAME_PORT;
        int colon = text.lastIndexOf(':');
        if (colon > 0) {
            host = text.substring(0, colon);
            try {
                port = Integer.parseInt(text.substring(colon + 1).trim());
            } catch (NumberFormatException e) {
                port = -1;
            }
            if (port < 1 || port > 65535) {
                nav.toast("That port number is not valid.");
                return;
            }
        }
        nav.connectTo(host.trim(), port);
    }

    private void rebuildList() {
        list.removeAllViews();
        List<DiscoveryScanner.HostInfo> hosts = scanner == null ? null : scanner.snapshot();
        if (hosts == null || hosts.isEmpty()) {
            status.setText("Searching this network\u2026 ask the host to tap Create Game.");
            return;
        }
        status.setText(hosts.size() == 1 ? "1 game found" : hosts.size() + " games found");
        for (int i = 0; i < hosts.size(); i++) list.addView(hostRow(hosts.get(i)), Ui.fillWidth(ctx, i == 0 ? 0 : 10));
    }

    private View hostRow(final DiscoveryScanner.HostInfo h) {
        boolean full = h.players >= h.maxPlayers;
        final boolean joinable = h.versionOk && !h.inMatch && !full;
        LinearLayout row = Ui.row(ctx);
        row.setPadding(Ui.dp(ctx, 16), Ui.dp(ctx, 12), Ui.dp(ctx, 16), Ui.dp(ctx, 12));
        row.setBackground(Ui.rounded(ctx, joinable ? 0xFF1E2733 : 0xFF171E27, joinable ? Palette.ACCENT : 0xFF2B3542,
                12f, 1.5f));
        row.setAlpha(joinable ? 1f : 0.6f);
        LinearLayout names = Ui.column(ctx);
        row.addView(names, Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f, 0, 0, 0, 0, ctx));
        names.addView(Ui.label(ctx, h.name, 19f, Palette.TEXT, true));
        names.addView(Ui.label(ctx, h.address + ":" + h.port, 12f, Palette.TEXT_DIM, false));
        String state = !h.versionOk ? "Different version" : (h.inMatch ? "In a match" : (full ? "Full"
                : h.players + " / " + h.maxPlayers + " players"));
        TextView st = Ui.label(ctx, state, 14f, joinable ? Palette.ACCENT : Palette.TEXT_DIM, true);
        st.setGravity(Gravity.END);
        row.addView(st);
        if (joinable) {
            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    nav.connectTo(h.address, h.port);
                }
            });
        }
        return row;
    }

    @Override
    public View view() {
        return root;
    }

    @Override
    public void onInsets(int l, int t, int r, int b) {
        padding.apply(l, t, r, b);
    }

    @Override
    public void onShow() {
        scanner = new DiscoveryScanner(Protocol.DISCOVERY_PORT);
        scanner.start(new DiscoveryScanner.Listener() {
            @Override
            public void onHostsChanged() {
                ui.post(refresh);
            }
        });
    }

    @Override
    public void onHide() {
        if (scanner != null) scanner.stop();
        scanner = null;
        ui.removeCallbacksAndMessages(null);
    }

    @Override
    public boolean onBack() {
        nav.showMenu(null);
        return true;
    }
}
