package com.hazardyard.game.bot;

/** How sharp a bot is. All the knobs that make an opponent easier or harder live here. */
public final class BotDifficulty {
    public static final int EASY = 0;
    public static final int NORMAL = 1;
    public static final int HARD = 2;
    public static final int COUNT = 3;

    public final String name;
    /** Seconds between spotting an enemy and the first shot. */
    public final float reaction;
    /** Aim error at the target in world units (the angle shrinks with distance). */
    public final float aimError;
    /** How much of the target's motion is predicted (0 = aim where it is, 1 = full lead). */
    public final float lead;
    /** Aim must be this close to the target (radians) before the trigger is pulled. */
    public final float fireTolerance;
    public final float sightRange;
    /** Share of idle wandering that heads towards an enemy instead of a random spot. */
    public final float aggression;
    /** Strongest stick deflection the bot uses (1 = full speed). */
    public final float speed;
    /** Automatic weapons fire for this long, then pause (seconds); 0 pause = never lets go. */
    public final float burstOn;
    public final float burstOff;
    /** Furthest pickup (world units) a bot will walk to. */
    public final float pickupRange;

    private BotDifficulty(String name, float reaction, float aimError, float lead, float fireTolerance, float sightRange,
                          float aggression, float speed, float burstOn, float burstOff, float pickupRange) {
        this.name = name;
        this.reaction = reaction;
        this.aimError = aimError;
        this.lead = lead;
        this.fireTolerance = fireTolerance;
        this.sightRange = sightRange;
        this.aggression = aggression;
        this.speed = speed;
        this.burstOn = burstOn;
        this.burstOff = burstOff;
        this.pickupRange = pickupRange;
    }

    private static final BotDifficulty[] ALL = {
        //                      name      react  err   lead  tol    sight  aggr  speed on    off   pickup
        new BotDifficulty("Easy",   0.60f, 36f, 0.30f, 0.20f, 480f, 0.35f, 0.82f, 0.50f, 0.55f, 500f),
        new BotDifficulty("Normal", 0.35f, 17f, 0.70f, 0.12f, 700f, 0.60f, 0.94f, 1.20f, 0.20f, 800f),
        new BotDifficulty("Hard",   0.16f, 7f,  1.00f, 0.07f, 950f, 0.85f, 1.00f, 1.00f, 0.00f, 1300f),
    };

    public static BotDifficulty of(int level) {
        return ALL[level < 0 ? 0 : (level >= COUNT ? COUNT - 1 : level)];
    }
}
