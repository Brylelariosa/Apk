package com.hazardyard.game.engine;

import com.hazardyard.game.core.GameConfig;
import com.hazardyard.game.core.GameState;
import com.hazardyard.game.core.GameWorld;
import com.hazardyard.game.core.LocalInput;
import com.hazardyard.game.core.MapLibrary;
import com.hazardyard.game.core.MathUtil;
import com.hazardyard.game.core.Player;
import com.hazardyard.game.core.WeaponDef;
import com.hazardyard.game.core.WorldListener;
import com.hazardyard.game.net.HostManager;
import com.hazardyard.game.net.LobbyManager;
import com.hazardyard.game.net.NetworkManager;
import com.hazardyard.game.net.Packets;
import com.hazardyard.game.net.PacketReader;
import com.hazardyard.game.net.PacketWriter;
import com.hazardyard.game.net.Protocol;
import com.hazardyard.game.net.SnapshotCodec;

/**
 * Authoritative engine: applies client input, runs {@link GameWorld}, and publishes the result as
 * 20 Hz snapshots plus reliable fire/hit/kill events. The host's own player is slot 0.
 */
public final class HostEngine implements GameEngine, WorldListener {
    private final HostManager net;
    private final GameState st;
    private final GameWorld world;
    private final PacketWriter snapshotWriter = new PacketWriter(256);
    private final PacketWriter eventWriter = new PacketWriter(64);
    private final PacketReader reader = new PacketReader();
    private final Packets.Input inputPacket = new Packets.Input();
    private final Packets.Fire firePacket = new Packets.Fire();
    private final Packets.Hit hitPacket = new Packets.Hit();
    private final Packets.Kill killPacket = new Packets.Kill();
    private int tick;
    private volatile boolean finished;
    private volatile boolean paused;

    /** Creates the match for everybody currently in the lobby and starts the countdown. */
    public HostEngine(HostManager net) {
        this.net = net;
        st = new GameState(MapLibrary.get(net.lobby().getMapId()), net.localPlayerId());
        world = new GameWorld(st, this);
        LobbyManager.Entry[] roster = new LobbyManager.Entry[GameConfig.MAX_PLAYERS];
        for (int i = 0; i < roster.length; i++) roster[i] = new LobbyManager.Entry();
        net.lobby().copyTo(roster);
        for (int i = 0; i < roster.length; i++) {
            if (roster[i].used) world.addPlayer(i, roster[i].name);
        }
        world.startMatch();
    }

    @Override
    public GameState state() {
        return st;
    }

    @Override
    public void fixedUpdate(float dt, LocalInput in) {
        if (finished) return;
        tick++;
        NetworkManager.Inbound m;
        while ((m = net.poll()) != null) handle(m);
        if (net.isClosed()) {
            finished = true;
            return;
        }
        world.setInput(0, in.moveX, in.moveY, in.aim, in.firing, 0);
        if (in.reload) world.requestReload(0);

        boolean frozen = paused && net.clientCount() == 0;
        if (!frozen) {
            world.step(dt);
            if (tick % GameConfig.SNAPSHOT_EVERY_TICKS == 0) {
                net.broadcastDroppable(SnapshotCodec.encode(snapshotWriter, st, tick));
            }
        }
        for (int i = 0; i < st.players.length; i++) {
            Player p = st.players[i];
            if (!p.connected) continue;
            p.rx = p.x;
            p.ry = p.y;
            p.rAim = p.aim;
        }
        st.effects.update(dt);
        if (st.phase == GameState.PHASE_FINISHED) finished = true;
    }

    private void handle(NetworkManager.Inbound m) {
        try {
            reader.wrap(m.data, 0, m.data.length);
            int type = reader.u8();
            switch (type) {
                case Protocol.C_INPUT:
                    inputPacket.read(reader);
                    world.setInput(m.from, inputPacket.moveX / 127f, inputPacket.moveY / 127f,
                            MathUtil.u16ToAngle(inputPacket.aim16), inputPacket.firing, inputPacket.seq);
                    break;
                case Protocol.C_RELOAD:
                    world.requestReload(m.from);
                    break;
                case Protocol.I_PLAYER_LEFT:
                    world.removePlayer(m.from);
                    break;
                default:
                    break;
            }
        } catch (RuntimeException malformed) {
            // A broken packet from one client must never take the host down; it is simply ignored.
        }
    }

    @Override
    public void frameUpdate(float dt) {
        // The host renders its own authoritative state directly; nothing to smooth.
    }

    @Override
    public boolean isFinished() {
        return finished;
    }

    @Override
    public String finishReason() {
        return net.isClosed() ? "The lobby was closed." : null;
    }

    @Override
    public int pingMs() {
        return 0;
    }

    @Override
    public void setPaused(boolean p) {
        paused = p;
    }

    @Override
    public void close() {
        finished = true;
    }

    // ------------------------------------------------------------------ WorldListener

    @Override
    public void onShot(Player shooter, WeaponDef def, float x, float y, float angle, int seed, int baseId) {
        firePacket.owner = shooter.id;
        firePacket.weaponId = def.id;
        firePacket.x = x;
        firePacket.y = y;
        firePacket.angle = angle;
        firePacket.seed = seed;
        firePacket.baseId = baseId;
        net.broadcast(firePacket.encode(eventWriter));
        Presentation.shot(st, def.id, x, y, angle);
    }

    @Override
    public void onProjectileHit(int projectileId, int victimId, float x, float y, int damage, int weaponId) {
        hitPacket.projectileId = projectileId;
        hitPacket.victim = victimId;
        hitPacket.damage = damage;
        hitPacket.x = x;
        hitPacket.y = y;
        net.broadcast(hitPacket.encode(eventWriter));
        Presentation.hit(st, victimId, x, y, weaponId, damage);
    }

    @Override
    public void onWallImpact(float x, float y, int weaponId) {
        Presentation.wallImpact(st, x, y, weaponId);
    }

    @Override
    public void onKill(int killerId, int victimId, int weaponId) {
        killPacket.killer = killerId;
        killPacket.victim = victimId;
        killPacket.weaponId = weaponId;
        net.broadcast(killPacket.encode(eventWriter));
        Presentation.kill(st, killerId, victimId, weaponId);
    }
}
