package com.hazardyard.game.render;

import android.graphics.Canvas;
import android.graphics.Paint;

import com.hazardyard.game.core.Camera;
import com.hazardyard.game.core.Effects;
import com.hazardyard.game.core.Projectile;
import com.hazardyard.game.core.ProjectilePool;
import com.hazardyard.game.core.WeaponDef;
import com.hazardyard.game.render.model.Projection;

/** Bullets in flight and the short-lived effects: muzzle flashes, impact sparks and death bursts. */
final class ShotRenderer {
    /** Height at which bullets fly and muzzle flashes appear (the barrel). */
    private static final float BULLET_Z = 9f;
    private static final float MUZZLE_Z = 14.7f;

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float[] spokes = new float[64];

    ShotRenderer() {
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.ROUND);
    }

    void drawProjectiles(Canvas c, ProjectilePool pool, Camera cam) {
        final float ox = Projection.LEAN * BULLET_Z;
        final float oy = -Projection.TILT * BULLET_Z;
        for (int i = 0; i < pool.activeCount; i++) {
            Projectile b = pool.items[pool.activeList[i]];
            if (!cam.isVisible(b.x, b.y, 30f)) continue;
            WeaponDef def = WeaponDef.byId(b.weaponId);
            float hx = b.x + ox;
            float hy = b.y + oy;
            if (def.style == WeaponDef.STYLE_ENERGY) {
                float tail = 0.024f;
                fill.setStyle(Paint.Style.FILL);
                fill.setColor(Palette.withAlpha(def.color, 70));
                c.drawCircle(hx, hy, b.radius * 2.7f, fill);
                line.setColor(Palette.withAlpha(def.color, 200));
                line.setStrokeWidth(b.radius * 1.7f);
                c.drawLine(hx - b.vx * tail, hy - b.vy * tail, hx, hy, line);
                fill.setColor(def.color);
                c.drawCircle(hx, hy, b.radius * 1.35f, fill);
                fill.setColor(0xFFFFFFFF);
                c.drawCircle(hx, hy, b.radius * 0.8f, fill);
            } else {
                float tail = 0.030f;
                line.setColor(Palette.withAlpha(def.color, 170));
                line.setStrokeWidth(b.radius * 1.8f);
                c.drawLine(hx - b.vx * tail, hy - b.vy * tail, hx, hy, line);
                line.setColor(0xDDFFFFFF);
                line.setStrokeWidth(b.radius * 0.7f);
                c.drawLine(hx - b.vx * tail * 0.55f, hy - b.vy * tail * 0.55f, hx, hy, line);
                fill.setStyle(Paint.Style.FILL);
                fill.setColor(0xFFFFFFFF);
                c.drawCircle(hx, hy, b.radius * 0.9f, fill);
            }
        }
    }

    void drawEffects(Canvas c, Effects fx) {
        for (int i = 0; i < Effects.MAX; i++) {
            if (!fx.active[i]) continue;
            float t = fx.age[i] / fx.life[i];
            int alpha = (int) (255f * (1f - t));
            if (alpha <= 0) continue;
            int col = Palette.withAlpha(fx.color[i], alpha);
            switch (fx.kind[i]) {
                case Effects.KIND_FLASH:
                    muzzleFlash(c, fx, i, t, col, alpha);
                    break;
                case Effects.KIND_SPARK:
                    spark(c, fx, i, t, col);
                    break;
                default:
                    burst(c, fx, i, t, col, alpha);
                    break;
            }
        }
    }

    private void muzzleFlash(Canvas c, Effects fx, int i, float t, int col, int alpha) {
        float x = Projection.screenX(fx.x[i], MUZZLE_Z);
        float y = Projection.screenY(fx.y[i], MUZZLE_Z);
        float a = fx.angle[i];
        float len = 15f * (1f - 0.55f * t);
        line.setColor(col);
        line.setStrokeWidth(3.4f * (1f - t) + 0.8f);
        int n = 0;
        for (int k = -1; k <= 1; k++) {
            float ang = a + k * 0.62f;
            float l = k == 0 ? len : len * 0.55f;
            spokes[n++] = x;
            spokes[n++] = y;
            spokes[n++] = x + (float) Math.cos(ang) * l;
            spokes[n++] = y + (float) Math.sin(ang) * l;
        }
        c.drawLines(spokes, 0, n, line);
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(col);
        c.drawCircle(x, y, 6.5f - 3f * t, fill);
        fill.setColor(Palette.withAlpha(0xFFFFFFFF, alpha));
        c.drawCircle(x, y, 3.2f - 1.6f * t, fill);
    }

    private void spark(Canvas c, Effects fx, int i, float t, int col) {
        float x = Projection.screenX(fx.x[i], BULLET_Z);
        float y = Projection.screenY(fx.y[i], BULLET_Z);
        line.setColor(col);
        line.setStrokeWidth(1.8f);
        c.drawCircle(x, y, 2f + 8f * t, line);
        int n = 0;
        float r0 = 3f + 5f * t;
        float r1 = 6f + 10f * t;
        for (int k = 0; k < 6; k++) {
            float ang = (i * 0.9f) + k * 1.0472f;
            float cs = (float) Math.cos(ang);
            float sn = (float) Math.sin(ang);
            spokes[n++] = x + cs * r0;
            spokes[n++] = y + sn * r0;
            spokes[n++] = x + cs * r1;
            spokes[n++] = y + sn * r1;
        }
        line.setStrokeWidth(1.3f);
        c.drawLines(spokes, 0, n, line);
    }

    private void burst(Canvas c, Effects fx, int i, float t, int col, int alpha) {
        float x = Projection.screenX(fx.x[i], 10f);
        float y = Projection.screenY(fx.y[i], 10f);
        line.setColor(col);
        line.setStrokeWidth(3f * (1f - t) + 0.6f);
        c.drawCircle(x, y, 6f + 30f * t, line);
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(Palette.withAlpha(fx.color[i], alpha / 2));
        c.drawCircle(x, y, 12f * (1f - t), fill);
        int n = 0;
        float r0 = 6f + 16f * t;
        float r1 = 10f + 34f * t;
        for (int k = 0; k < 10; k++) {
            float ang = (i * 0.37f) + k * 0.6283f;
            float cs = (float) Math.cos(ang);
            float sn = (float) Math.sin(ang);
            spokes[n++] = x + cs * r0;
            spokes[n++] = y + sn * r0;
            spokes[n++] = x + cs * r1;
            spokes[n++] = y + sn * r1;
        }
        line.setStrokeWidth(2.2f * (1f - t) + 0.5f);
        c.drawLines(spokes, 0, n, line);
    }
}
