package com.hazardyard.game.core;

/** Sound ids. The first {@link WeaponDef#ALL} ids are the gun shots, so a weapon id is its shot sound. */
public final class Sounds {
    private Sounds() {}

    /** Shot sound of weapon {@code weaponId}: ids 0..7 are the eight guns. */
    public static int shot(int weaponId) {
        return weaponId >= 0 && weaponId < WeaponDef.ALL.length ? weaponId : WeaponDef.PISTOL;
    }

    public static final int RELOAD = 8;
    public static final int PICKUP = 9;
    public static final int HIT = 10;
    public static final int HURT = 11;
    public static final int KILL = 12;
    public static final int DEATH = 13;
    public static final int RESPAWN = 14;
    public static final int IMPACT = 15;
    public static final int COUNTDOWN = 16;
    public static final int GO = 17;
    public static final int WIN = 18;
    public static final int LOSE = 19;
    public static final int CONFIRM = 20;
    public static final int COUNT = 21;
}
