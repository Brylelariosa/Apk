package com.immortalascension

import kotlin.random.Random

object EventSystem {

    // ── ENEMY BUILDERS ────────────────────────────────────────────────────────

    private fun enemy(
        name: String, tier: RealmTier, stage: Int,
        hp: Int, atk: Int, def: Int, spd: Int,
        behavior: EnemyBehavior = EnemyBehavior.AGGRESSIVE,
        stones: IntRange = 0..3, killDesc: String = "", lootDesc: String = ""
    ) = Enemy(name, Realm(tier, stage), hp, hp, atk, def, spd, behavior, stones, lootDesc, killDesc)

    val ENEMIES_EARLY: List<Enemy> get() = listOf(
        enemy("Wild Wolf",             RealmTier.MORTAL,       1,  40,  8,  2, 14, EnemyBehavior.AGGRESSIVE, 0..1,  "The wolf collapses, spirit fading.",              "Wolf Pelt"),
        enemy("Qi-Infused Boar",       RealmTier.MORTAL,       1,  70, 12,  4, 10, EnemyBehavior.BERSERKER,  0..2,  "The boar crashes down with a thunderous thud.",   "Boar Tusk"),
        enemy("Outer Disciple",        RealmTier.QI_GATHERING, 2,  90, 14,  6, 12, EnemyBehavior.TACTICAL,   2..5,  "The disciple yields, fleeing into the forest.",   "Spirit Stones"),
        enemy("Forest Fiend",          RealmTier.QI_GATHERING, 3, 110, 18,  7, 15, EnemyBehavior.AGGRESSIVE, 1..4,  "The fiend shrieks as its corruption unravels.",   "Corrupted Core Fragment"),
        enemy("Rogue Cultivator",      RealmTier.QI_GATHERING, 4, 130, 22,  8, 11, EnemyBehavior.TACTICAL,   3..8,  "His path ends here, eyes empty.",                 "Spirit Stones, Technique Scroll"),
        enemy("Stone Golem Spirit",    RealmTier.QI_GATHERING, 5, 200, 28, 20,  5, EnemyBehavior.CAUTIOUS,   2..6,  "The golem shatters, releasing ancient earth Qi.", "Earth Core"),
        enemy("Thunder Hawk",          RealmTier.QI_GATHERING, 6, 160, 35, 10, 22, EnemyBehavior.AGGRESSIVE, 3..7,  "The hawk falls, lightning fading from its wings.", "Thunder Feather"),
        enemy("Crimson Spider Queen",  RealmTier.QI_GATHERING, 7, 250, 40, 12, 16, EnemyBehavior.TACTICAL,   5..12, "The queen's web dissolves into red mist.",        "Spiritual Silk"),
        enemy("Demonic Possessed",     RealmTier.QI_GATHERING, 8, 300, 55, 15, 18, EnemyBehavior.BERSERKER,  8..15, "The demonic influence leaves the broken body.",   "Demon Core Shard"),
    )

    val ENEMIES_FOUNDATION: List<Enemy> get() = listOf(
        enemy("Foundation Cultivator", RealmTier.FOUNDATION, 1,  500,  80, 40, 16, EnemyBehavior.TACTICAL,  15..30, "He nods with hollow eyes before the end.",  "Foundation Scroll"),
        enemy("Ancient Cave Demon",    RealmTier.FOUNDATION, 2,  800, 100, 50, 12, EnemyBehavior.AGGRESSIVE, 20..40, "Its roar cuts off mid-scream.",             "Demon Essence"),
        enemy("Cursed Sword Spirit",   RealmTier.FOUNDATION, 3,  700, 120, 35, 25, EnemyBehavior.BERSERKER,  30..60, "The sword shatters. The spirit dissipates.", "Cursed Shard"),
        enemy("Foundation Elder",      RealmTier.FOUNDATION, 4, 1200, 150, 60, 18, EnemyBehavior.TACTICAL,   50..100,"The elder closes his eyes, accepting fate.",  "Elder's Ring"),
    )

    val DEMONS: List<Enemy> get() = listOf(
        enemy("Twisted Wraith",        RealmTier.QI_GATHERING, 6, 180, 40, 8,  20, EnemyBehavior.AGGRESSIVE, 5..10, "The wraith screeches and dissolves.",          "Demonic Qi Crystal"),
        enemy("Corrupted Cultivator",  RealmTier.FOUNDATION,   1, 450, 75, 30, 14, EnemyBehavior.BERSERKER,  10..20,"His eyes clear for a moment before the end.", "Purified Core"),
        enemy("Demon General",         RealmTier.FOUNDATION,   2, 900, 110,45, 18, EnemyBehavior.TACTICAL,   25..45,"Its massive form collapses with the sound of breaking law.", "Demon Seal Fragment"),
    )

    fun enemiesForLocation(locationId: String, playerRealm: Realm): List<Enemy> {
        val base = when (locationId) {
            "demon_wastes"  -> DEMONS + ENEMIES_FOUNDATION
            "thunder_peak"  -> ENEMIES_EARLY.takeLast(4) + ENEMIES_FOUNDATION.take(2)
            "ancient_ruins" -> ENEMIES_EARLY.takeLast(3) + ENEMIES_FOUNDATION
            "verdant_forest"-> ENEMIES_EARLY.take(6)
            else            -> ENEMIES_EARLY
        }
        return base
    }

    fun pickEnemy(state: GameState): Enemy {
        val pool = enemiesForLocation(state.world.locationId, state.player.realm)
            .takeIf { it.isNotEmpty() } ?: ENEMIES_EARLY
        val nearby = pool.filter { kotlin.math.abs(it.realm.dominates(state.player.realm)) < 30 }
        val src = if (nearby.isNotEmpty() && Random.nextFloat() < 0.72f) nearby else pool
        val t = src.random()
        return t.copy(hp = t.maxHp, stunned = false, weakened = false, weakenedTurns = 0)
    }

    // ── EXPLORATION ───────────────────────────────────────────────────────────

    fun exploreEvent(state: GameState): ExploreResult {
        val p = state.player
        val location = LocationSystem.get(state.world.locationId)
        val lootMod  = WorldEventSystem.explorationLootBonus(state.world)

        // Danger level shifts combat weight
        val combatWeight = (25 + location.dangerLevel * 4).coerceIn(15, 70)
        val roll = Random.nextInt(100)
        val luckyShift = if (p.luck > 12) 6 else if (p.luck < 8) -6 else 0

        // NPC encounter chance if NPCs are in same location
        val npcInArea = state.npcs.any { it.alive && it.currentLocation == state.world.locationId }
        val npcRoll   = if (npcInArea) Random.nextFloat() < 0.2f else false

        // Weights after combat: treasure=20, resource=15, mystery=15, location=12, legendary=rest
        return when {
            npcRoll                            -> ExploreResult.NPCEncounter
            roll < combatWeight                -> ExploreResult.Combat(pickEnemy(state))
            roll < combatWeight + 20           -> treasureEvent(state, lootMod)
            roll < combatWeight + 35           -> resourceEvent(state)
            roll < combatWeight + 50           -> mysteryEvent(state)
            roll < combatWeight + 62           -> locationSpecificEvent(state)
            roll < combatWeight + 62 + luckyShift.coerceAtLeast(0) -> mysteryEvent(state)
            else                               -> legendaryEvent(state)
        }
    }

    private fun treasureEvent(state: GameState, lootMod: Float): ExploreResult {
        val p = state.player
        val roll = Random.nextFloat()
        val text: String

        if (roll < 0.4f) {
            val stones = (Random.nextInt(3, 18 + p.luck) * lootMod).toInt()
            p.spiritStones += stones
            text = "Hidden beneath roots: a cultivator's stash. $stones spirit stones."
        } else if (roll < 0.65f) {
            val item = InventorySystem.randomLootItem(p.realm)
            if (item != null) {
                addToInventory(p, item)
                text = "You find ${item.name} discarded near the path. (Added to inventory)"
            } else {
                p.qi = (p.qi + p.maxQi / 8).coerceAtMost(p.maxQi)
                text = "A vein of spirit jade. You absorb its ambient Qi. +${p.maxQi/8} Qi."
            }
        } else {
            val stones = (Random.nextInt(5, 25 + p.luck) * lootMod).toInt()
            p.spiritStones += stones
            p.comprehension++
            text = "A dead cultivator on the road. Their pouch holds $stones stones. Their journal yields a fragment of insight. +1 Comprehension."
        }

        return ExploreResult.Event(text, LogType.EVENT)
    }

    private fun resourceEvent(state: GameState): ExploreResult {
        val p = state.player
        val events = listOf(
            { val q = p.maxQi / 8; p.qi = (p.qi + q).coerceAtMost(p.maxQi); "A spirit jade vein in the cliff face. You absorb ambient Qi. +$q Qi." },
            { p.comprehension++; "A weathered technique manual, half-destroyed. One fragment survives. +1 Comprehension." },
            { val s = Random.nextInt(2, 10); p.spiritStones += s; "Spirit stones embedded in exposed rock. +$s stones." },
            { p.daoHeart = (p.daoHeart + 5).coerceAtMost(100); "A clearing where Qi flows in perfect balance. Brief meditation steadies your Dao Heart. +5." },
            { addToInventory(p, InventorySystem.WOLF_PELT.copy()); "You track and kill a wolf, taking its pelt for trade." }
        )
        return ExploreResult.Event(events.random()(), LogType.CULTIVATION)
    }

    private fun mysteryEvent(state: GameState): ExploreResult {
        val p = state.player
        val events = listOf<() -> String>(
            {
                if (Random.nextFloat() < 0.45f) {
                    val insight = DAO_INSIGHTS.random()
                    if (!p.daoInsights.contains(insight)) p.daoInsights.add(insight)
                    p.comprehension += 2
                    "A wordless vision. When it clears: new understanding. +2 Comprehension. Dao insight gained."
                } else {
                    p.innerDemonLevel = (p.innerDemonLevel + 8).coerceAtMost(100)
                    "Darkness bleeds through the land. Something follows it home into your mind. +8 Inner Demon."
                }
            },
            { p.luck += 2; "A Luck Stone — still warm with residual spirit. Your fortune lightens. +2 Luck." },
            {
                p.hp = p.maxHp; p.qi = p.maxQi
                "You fall into a strange dream during rest. When you wake: fully restored."
            },
            {
                p.innerDemonLevel = (p.innerDemonLevel - 12).coerceAtLeast(0)
                p.daoHeart = (p.daoHeart + 8).coerceAtMost(100)
                "A golden lotus floats at the center of a still pond, dissolving as you approach. Inner Demon -12, Dao Heart +8."
            },
            {
                if (p.spiritStones >= 10) {
                    p.spiritStones -= 10
                    p.comprehension += 3
                    p.daoHeart = (p.daoHeart + 5).coerceAtMost(100)
                    "A cracked altar. You offer 10 stones. Ancient energy rewards your faith. +3 Comprehension, +5 Dao Heart."
                } else "A cracked altar waits for an offering you cannot make. The silence here feels heavy."
            }
        )
        return ExploreResult.Event(events.random()(), LogType.EVENT)
    }

    private fun locationSpecificEvent(state: GameState): ExploreResult {
        val p = state.player
        val id = state.world.locationId
        val text = when (id) {
            "thunder_peak" -> {
                if (Random.nextFloat() < 0.5f) {
                    val qi = p.maxQi / 6
                    p.qi = (p.qi + qi).coerceAtMost(p.maxQi)
                    "You stand atop a peak during a storm and absorb the lightning Qi directly. Painful. Effective. +$qi Qi."
                } else {
                    p.daoHeart = (p.daoHeart - 5).coerceAtLeast(0)
                    p.comprehension++
                    "A bolt strikes ten feet away. In the ringing silence after, something about the Killing Dao becomes clear. -5 Dao Heart, +1 Comprehension."
                }
            }
            "ancient_ruins" -> {
                val insight = DAO_INSIGHTS.random()
                if (!p.daoInsights.contains(insight)) p.daoInsights.add(insight)
                p.comprehension += 2
                "A formation array still active after ten millennia suddenly pulses when you touch it. The ancient cultivator's last insight flows into you. +2 Comprehension, Dao insight."
            }
            "sacred_spring" -> {
                p.hp = p.maxHp; p.qi = p.maxQi
                p.daoHeart = (p.daoHeart + 10).coerceAtMost(100)
                "You immerse yourself in the Sacred Spring. HP and Qi restored to full. +10 Dao Heart."
            }
            "demon_wastes" -> {
                p.innerDemonLevel = (p.innerDemonLevel + 15).coerceAtMost(100)
                p.attack += 2
                "Bathing in corrupted Qi is dangerous. Your inner demons surge — but so does your killing intent. +2 Attack, +15 Inner Demon."
            }
            else -> {
                val s = Random.nextInt(3, 12)
                p.spiritStones += s
                "A traveling merchant camp. You trade information for $s spirit stones."
            }
        }
        return ExploreResult.Event(text, LogType.EVENT)
    }

    private fun legendaryEvent(state: GameState): ExploreResult {
        val p = state.player
        val events = listOf<() -> String>(
            {
                val tech = RARE_TECHNIQUES.filter { t -> p.techniques.none { it.id == t.id } }.randomOrNull()
                if (tech != null) {
                    p.techniques.add(tech.copy())
                    "⭐ LEGENDARY — A dying immortal reaches out. \"Take this.\" Technique learned: ${tech.name}."
                } else {
                    p.comprehension += 5; p.spiritStones += 60
                    "⭐ LEGENDARY — A vault behind a waterfall. Ancient artifacts. +60 stones, +5 Comprehension."
                }
            },
            {
                val insight = DAO_INSIGHTS.random()
                if (!p.daoInsights.contains(insight)) p.daoInsights.add(insight)
                p.comprehension += 5; p.daoHeart = (p.daoHeart + 10).coerceAtMost(100)
                "⭐ LEGENDARY — The sky darkens. Impossible constellations. Silent lightning. You stand motionless for hours. +5 Comprehension, +10 Dao Heart, Dao Insight."
            },
            {
                p.maxHp += 60; p.hp = (p.hp + 60).coerceAtMost(p.maxHp); p.maxQi += 120
                "⭐ LEGENDARY — A Heavenly Spring beneath a collapsed ruin. Hours of meditation. Foundation deepens permanently. +60 Max HP, +120 Max Qi."
            },
            {
                addToInventory(p, InventorySystem.SCROLL_VOID_STEP.copy())
                "⭐ LEGENDARY — A waterproof jade case wedged in ancient stone. Inside: a pristine technique scroll. (Added to inventory)"
            }
        )
        return ExploreResult.Event(events.random()(), LogType.BREAKTHROUGH)
    }

    // ── CULTIVATION ───────────────────────────────────────────────────────────

    fun cultivationEvent(state: GameState): CultivationResult {
        val p = state.player
        val location = LocationSystem.get(state.world.locationId)
        val worldMod = WorldEventSystem.cultivationBonus(state.world)

        val enlightenChance = (p.comprehension * 0.004f + p.daoHeart * 0.002f).coerceIn(0.01f, 0.25f)
        val deviationChance = (p.innerDemonLevel * 0.003f + (100 - p.daoHeart) * 0.002f).coerceIn(0f, 0.3f)
        val roll = Random.nextFloat()

        return when {
            roll < deviationChance -> qiDeviation(state)
            roll < deviationChance + enlightenChance -> enlightenment(state)
            else -> normalCultivation(state, location, worldMod)
        }
    }

    private fun normalCultivation(state: GameState, location: Location, worldMod: Float): CultivationResult {
        val p = state.player
        val baseGain = (p.realm.qiCap / 12).coerceAtLeast(10)
        val compBonus = 1f + p.comprehension * 0.02f
        val weatherBonus = when (state.world.weather) { "Serene" -> 1.3f; "Misty" -> 1.15f; "Stormy" -> 0.8f; "Rainy" -> 1.05f; else -> 1.0f }
        val gained = (baseGain * compBonus * weatherBonus * location.cultivationBonus * worldMod).toInt()

        p.qi = (p.qi + gained).coerceAtMost(p.maxQi)
        p.cultivationDays++
        p.innerDemonLevel = (p.innerDemonLevel + 1).coerceAtMost(100)

        // Sect mission progress
        SectSystem.onCultivateDay(state)

        val extra = when (state.world.weather) {
            "Serene" -> " The unusual calm amplifies your absorption."
            "Stormy" -> " Storm interference disrupts your focus."
            "Misty"  -> " Spiritual mist densifies around your body."
            else -> ""
        }

        return CultivationResult.Normal("${CULTIVATION_FLAVOUR.random()}$extra Absorbed $gained Qi. [${p.qi}/${p.maxQi}]", gained)
    }

    private fun enlightenment(state: GameState): CultivationResult {
        val p = state.player
        val bonusQi = p.maxQi / 4
        p.qi = (p.qi + bonusQi).coerceAtMost(p.maxQi)
        p.comprehension += Random.nextInt(1, 4)
        p.daoHeart = (p.daoHeart + Random.nextInt(3, 8)).coerceAtMost(100)
        p.innerDemonLevel = (p.innerDemonLevel - 5).coerceAtLeast(0)
        val insight = DAO_INSIGHTS.random()
        if (!p.daoInsights.contains(insight)) p.daoInsights.add(insight)
        val text = "✦ ENLIGHTENMENT ✦\n${ENLIGHTENMENT_EVENTS.random()}\nTime seems to stop. Reality becomes clear.\n+$bonusQi Qi · +Comprehension · +Dao Heart\nInsight: \"$insight\""
        return CultivationResult.Enlightenment(text)
    }

    private fun qiDeviation(state: GameState): CultivationResult {
        val p = state.player
        val severity = when { p.innerDemonLevel > 70 -> 3; p.innerDemonLevel > 40 -> 2; else -> 1 }
        val dmg = when (severity) {
            3 -> { p.daoHeart = (p.daoHeart - 15).coerceAtLeast(0); (p.maxHp * 0.35f).toInt() }
            2 -> { p.daoHeart = (p.daoHeart - 8).coerceAtLeast(0);  (p.maxHp * 0.20f).toInt() }
            else -> (p.maxHp * 0.10f).toInt()
        }
        p.hp = (p.hp - dmg).coerceAtLeast(1)
        p.innerDemonLevel = (p.innerDemonLevel - 15).coerceAtLeast(0)
        val text = "⚠ QI DEVIATION ⚠\n${DEVIATION_EVENTS[severity - 1]}\nYou suffer $dmg damage. Your Dao Heart weakens."
        return CultivationResult.Deviation(text, dmg)
    }

    // ── BREAKTHROUGH ──────────────────────────────────────────────────────────

    fun attemptBreakthrough(state: GameState): BreakthroughResult {
        val p = state.player
        val next = p.realm.next() ?: return BreakthroughResult.AtPeak
        val location = LocationSystem.get(state.world.locationId)
        val worldBonus = WorldEventSystem.breakthroughBonus(state.world)

        // Pill bonuses
        val pillBonus = try {
            p.inventory.filter { it.type == ItemType.PILL && it.breakthroughBonus > 0 }
                .sumOf { it.breakthroughBonus.toDouble() }.toFloat()
        } catch (e: Exception) { 0f }

        val base = 0.48f
        val compMod = p.comprehension * 0.015f
        val daoMod  = p.daoHeart * 0.004f
        val demonPenalty = p.innerDemonLevel * 0.006f
        val qiPurity = if (p.qi >= p.maxQi) 0.15f else p.qi.toFloat() / p.maxQi * 0.1f
        val locBonus = if (location.qiQuality == QiQuality.HEAVENLY) 0.1f else 0f

        val successChance = (base + compMod + daoMod + qiPurity - demonPenalty + worldBonus + pillBonus + locBonus)
            .coerceIn(0.08f, 0.95f)

        val roll = Random.nextFloat()

        return when {
            p.innerDemonLevel > 60 && Random.nextFloat() < 0.32f -> innerDemonTrial(state, next, successChance)
            roll < successChance * 0.22f -> perfectBreakthrough(state, next)
            roll < successChance         -> normalBreakthrough(state, next)
            roll < successChance + 0.12f -> flawedBreakthrough(state, next)
            roll < successChance + 0.28f -> failedBreakthrough(state)
            else                         -> deviationBreakthrough(state)
        }
    }

    private fun perfectBreakthrough(state: GameState, next: Realm): BreakthroughResult {
        applyRealmBonuses(state.player, next, perfect = true)
        return BreakthroughResult.Perfect("★ PERFECT BREAKTHROUGH ★\n${BREAKTHROUGH_PERFECT.random()}\nEntered: ${next.display}. All stats enhanced greatly.", next)
    }

    private fun normalBreakthrough(state: GameState, next: Realm): BreakthroughResult {
        applyRealmBonuses(state.player, next, perfect = false)
        return BreakthroughResult.Success("✦ BREAKTHROUGH SUCCESS ✦\n${BREAKTHROUGH_SUCCESS.random()}\nEntered: ${next.display}.", next)
    }

    private fun flawedBreakthrough(state: GameState, next: Realm): BreakthroughResult {
        applyRealmBonuses(state.player, next, perfect = false)
        val p = state.player
        p.maxHp = (p.maxHp * 0.92f).toInt()
        p.hp = p.hp.coerceAtMost(p.maxHp)
        return BreakthroughResult.Flawed("~ FLAWED BREAKTHROUGH ~\nYou force through — but the foundation carries a crack.\nEntered ${next.display}. Max HP permanently reduced slightly.", next)
    }

    private fun failedBreakthrough(state: GameState): BreakthroughResult {
        val p = state.player
        p.hp = (p.hp - p.maxHp * 0.25f).toInt().coerceAtLeast(1)
        p.qi = p.maxQi / 4
        return BreakthroughResult.Failed("✗ BREAKTHROUGH FAILED ✗\n${BREAKTHROUGH_FAIL.random()}\nYou take damage and lose most Qi. Rest and try again.")
    }

    private fun deviationBreakthrough(state: GameState): BreakthroughResult {
        val p = state.player
        p.hp = (p.hp - p.maxHp * 0.45f).toInt().coerceAtLeast(1)
        p.daoHeart = (p.daoHeart - 20).coerceAtLeast(0)
        p.innerDemonLevel = (p.innerDemonLevel + 20).coerceAtMost(100)
        p.qi = 0
        return BreakthroughResult.Deviation("⚠ CATASTROPHIC DEVIATION ⚠\n${BREAKTHROUGH_DEVIATION.random()}\nQi shattered. Dao Heart severely damaged. Inner demons surge.")
    }

    private fun innerDemonTrial(state: GameState, next: Realm, baseChance: Float): BreakthroughResult {
        val p = state.player
        val trial = innerDemonTrialText(p)
        val overcome = Random.nextFloat() < (p.daoHeart / 100f)
        return if (overcome) {
            p.innerDemonLevel = (p.innerDemonLevel - 30).coerceAtLeast(0)
            p.daoHeart = (p.daoHeart + 10).coerceAtMost(100)
            applyRealmBonuses(p, next, perfect = true)
            BreakthroughResult.Perfect("✦ INNER DEMON TRIAL ✦\n$trial\n\nYou do not flinch. They shatter.\n★ Perfect Breakthrough into ${next.display}. ★", next)
        } else {
            p.innerDemonLevel = (p.innerDemonLevel + 15).coerceAtMost(100)
            p.daoHeart = (p.daoHeart - 15).coerceAtLeast(0)
            p.hp = (p.hp - p.maxHp / 3).coerceAtLeast(1)
            p.mentalScars.add("Survived Inner Demon Trial — year ${state.world.year}")
            BreakthroughResult.Deviation("⚠ INNER DEMON TRIAL — FAILED ⚠\n$trial\n\nThe illusions break you. You retreat, wounded.")
        }
    }

    fun applyRealmBonuses(p: Player, next: Realm, perfect: Boolean) {
        val tier = next.tier
        val m = if (perfect) 1.4f else 1.0f
        p.realm  = next
        p.maxHp += (tier.hpBonus * m).toInt()
        p.maxQi  = next.qiCap
        p.attack += (tier.atkBonus * m).toInt()
        p.defense+= (tier.defBonus * m).toInt()
        p.hp     = p.maxHp
        p.qi     = 0
        p.innerDemonLevel = (p.innerDemonLevel - 10).coerceAtLeast(0)
    }

    // ── INVENTORY HELPER ──────────────────────────────────────────────────────

    fun addToInventory(p: Player, item: Item) {
        val existing = p.inventory.firstOrNull { it.id == item.id }
        if (existing != null) existing.quantity++
        else p.inventory.add(item)
    }

    // ── TEXT DATA ─────────────────────────────────────────────────────────────

    val DAO_INSIGHTS = listOf(
        "True stillness is not the absence of motion — it is its source.",
        "The sword that hesitates is already defeated.",
        "Water does not fight the stone. It outlasts it.",
        "To understand death is to understand what is worth living for.",
        "Lightning does not ask permission to strike.",
        "The mountain does not move. It does not need to.",
        "All things return. The question is what they return as.",
        "Silence is the loudest thing in the world.",
        "The self that seeks power is not the self that deserves it.",
        "A fracture in the foundation dooms the tower above.",
        "Heaven's will is not righteousness. It is inevitability.",
        "The strongest chains are the ones you forged yourself.",
        "Freedom is not the absence of limits. It is the ability to choose which ones bind you.",
        "Destruction is the most honest Dao. It never pretends.",
        "Time moves through you. You do not move through time.",
    )

    private val CULTIVATION_FLAVOUR = listOf(
        "Moonlight filters through the canopy.",
        "Wind carries traces of ancient Qi.",
        "Your breathing synchronizes with the earth's rhythm.",
        "Stars wheel overhead as hours pass unmarked.",
        "A distant waterfall fills the silence.",
        "Spirit beasts give your position a wide berth.",
        "Dawn breaks. You did not notice the hours pass.",
        "Frost forms on your eyelashes, unnoticed.",
        "A bird lands on your shoulder and sleeps.",
        "Your meridians pulse with increasing warmth.",
        "The dantian builds with slow, inevitable pressure.",
        "The spiritual pressure around you causes the grass to bend inward.",
    )

    private val ENLIGHTENMENT_EVENTS = listOf(
        "You watch snowfall in silence for seventeen days.",
        "A single drop of dew falls from a leaf. In that instant, something unlocks.",
        "You stare at a candle flame until it becomes the only thing in existence.",
        "A dying elder's last breath carries the weight of centuries.",
        "For three days you cannot stop weeping, though you do not know why.",
        "You watch a spider rebuild its destroyed web seventeen times.",
        "Rain falls. You simply watch it fall. For hours.",
    )

    private val DEVIATION_EVENTS = listOf(
        "Qi surges uncontrolled through a fractured meridian. You bite through your lip.",
        "Your inner demon rises, shattering focus. Corrupted Qi tears through you like fire.",
        "The technique fractures mid-cycle. Qi explodes outward from your dantian.",
    )

    private val BREAKTHROUGH_PERFECT = listOf(
        "The tribulation clouds part. Heaven itself bows to your advancement.",
        "Your Dao resonates with the universe. For one perfect moment, you understand everything.",
        "The golden path was always here. You simply needed to walk it without doubt.",
    )

    private val BREAKTHROUGH_SUCCESS = listOf(
        "The wall crumbles. You step through, breathing at a new depth.",
        "Lightning and thunder mark your passage. Birds go silent for miles.",
        "Your realm expands like a horizon. What once seemed vast now seems small.",
    )

    private val BREAKTHROUGH_FAIL = listOf(
        "The wall holds. You were not ready.",
        "Your Qi scatters like startled birds. The attempt ends in failure.",
        "Heaven refuses you passage. Not today.",
    )

    private val BREAKTHROUGH_DEVIATION = listOf(
        "Your Qi turns against itself. The backlash is catastrophic.",
        "The inner demon seizes your moment of vulnerability. Your meridians crack.",
        "Something in the heavens resists your advance with terrible force.",
    )

    private fun innerDemonTrialText(p: Player): String {
        val trials = mutableListOf(
            "In the silence of your mind, you hear every voice you have ever silenced.",
            "The faces of the dead gather around you. They are not angry. They are waiting.",
            "An illusion of your future self stands before you — hollow-eyed, endless, alone.",
            "You stand at the beginning again. Everything you have built is gone. Was it real?",
            "A version of yourself that chose differently watches from across an infinite gulf.",
        )
        if (p.kills > 5)    trials.add("${p.kills} pairs of eyes open in the dark. They do not blink.")
        if (p.karma < -30)  trials.add("Everything you destroyed lines the path behind you. It is longer than you remember.")
        if (p.mentalScars.isNotEmpty()) trials.add("The scars on your mind remember what your mind tried to forget.")
        return trials.random()
    }

    // ── TECHNIQUE DEFINITIONS ─────────────────────────────────────────────────

    val RARE_TECHNIQUES = listOf(
        Technique("void_step",      "Void Step",          "Brief phase through space.",                     TechniqueType.MOVEMENT, TechElement.VOID,      qiCost=40, damage=0,   cooldownMax=3),
        Technique("thunder_domain", "Thunder Domain",     "Call lightning across the field.",               TechniqueType.ATTACK,   TechElement.LIGHTNING, qiCost=60, damage=80, effect=TechEffect.STUN,  effectChance=0.4f, effectDuration=1, cooldownMax=4),
        Technique("blood_phoenix",  "Blood Phoenix Art",  "Qi-fueled devastating strike.",                 TechniqueType.ATTACK,   TechElement.FIRE,      qiCost=55, damage=120,effect=TechEffect.BURN,  effectChance=0.5f, effectDuration=2, cooldownMax=5),
        Technique("jade_body",      "Jade Body Sutra",    "Fortify the body — reduce incoming damage.",     TechniqueType.DEFENSE,  TechElement.EARTH,     qiCost=30, damage=0,  effect=TechEffect.SHIELD,effectChance=1.0f,effectDuration=2, cooldownMax=3),
        Technique("ice_domain",     "Frozen World Domain","Encase the battlefield in ice.",                 TechniqueType.ATTACK,   TechElement.ICE,       qiCost=70, damage=90, effect=TechEffect.WEAKEN,effectChance=0.6f,effectDuration=2, cooldownMax=5),
        Technique("void_slash",     "Void Annihilation Slash","A slash that cuts through spiritual defenses.",TechniqueType.ATTACK, TechElement.VOID,      qiCost=80, damage=150,cooldownMax=6),
    )

    val STARTING_TECHNIQUES = listOf(
        Technique("basic_strike",   "Qi Condensed Strike","Channel Qi into a powerful blow.",               TechniqueType.ATTACK,   TechElement.NONE,      qiCost=15, damage=28, cooldownMax=1),
        Technique("wind_step",      "Wind Step",          "Swift footwork — dodge and reposition.",         TechniqueType.MOVEMENT, TechElement.WIND,      qiCost=10, damage=18, cooldownMax=0),
        Technique("qi_heal",        "Qi Circulation Heal","Cycle Qi through meridians to restore HP.",      TechniqueType.SUPPORT,  TechElement.WOOD,      qiCost=20, healAmount=45, cooldownMax=3),
        Technique("iron_body",      "Iron Body Technique","Temporary defensive Qi reinforcement.",          TechniqueType.DEFENSE,  TechElement.EARTH,     qiCost=18, effect=TechEffect.SHIELD, effectChance=1f,effectDuration=2, cooldownMax=2),
        Technique("lightning_jab",  "Lightning Jab",      "Quick Qi strike with stun potential.",           TechniqueType.ATTACK,   TechElement.LIGHTNING, qiCost=25, damage=35, effect=TechEffect.STUN, effectChance=0.25f,effectDuration=1, cooldownMax=2),
    )
}

// ── RESULT TYPES ──────────────────────────────────────────────────────────────

sealed class ExploreResult {
    data class Combat(val enemy: Enemy) : ExploreResult()
    data class Event(val text: String, val type: LogType = LogType.EVENT) : ExploreResult()
    object NPCEncounter : ExploreResult()
}

sealed class CultivationResult {
    data class Normal(val text: String, val qiGained: Int) : CultivationResult()
    data class Enlightenment(val text: String) : CultivationResult()
    data class Deviation(val text: String, val damage: Int) : CultivationResult()
}

sealed class BreakthroughResult {
    data class Perfect(val text: String, val newRealm: Realm) : BreakthroughResult()
    data class Success(val text: String, val newRealm: Realm) : BreakthroughResult()
    data class Flawed(val text: String, val newRealm: Realm) : BreakthroughResult()
    data class Failed(val text: String) : BreakthroughResult()
    data class Deviation(val text: String) : BreakthroughResult()
    object AtPeak : BreakthroughResult()
}
