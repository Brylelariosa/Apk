package com.immortalascension

import kotlin.random.Random

/**
 * NPCSimulator — Every NPC lives their own life.
 *
 * Call tickDay() every in-game day. Each NPC:
 *   - Chooses and pursues goals autonomously
 *   - Cultivates, travels, fights other NPCs, trades, joins/leaves sects
 *   - Ages, advances realms, or dies
 *   - Forms alliances and rivalries with other NPCs
 *   - Can turn demonic, go rogue, seek revenge, take disciples
 *   - Leaves behind a narrative history the player can discover
 *
 * Returns a list of world news entries — notable things that happened
 * while the player wasn't watching.
 */
object NPCSimulator {

    // ── PUBLIC ENTRY POINT ────────────────────────────────────────────────────

    /**
     * Advance the world by [days] days.
     * Returns notable events that occurred (world news).
     */
    fun tick(state: GameState, days: Int): List<WorldNewsEntry> {
        val news = mutableListOf<WorldNewsEntry>()

        // Respawn if world is getting empty
        maintainWorldPopulation(state)

        repeat(days) {
            state.npcs.filter { it.alive }.forEach { npc ->
                npc.daysAlive++
                npc.daysInLocation++

                // Mortality
                val deathEvent = checkNaturalDeath(npc, state)
                if (deathEvent != null) { news += deathEvent; return@forEach }

                // Qi recovery (passive regen)
                npc.qi = (npc.qi + npc.maxQi / 20).coerceAtMost(npc.maxQi)

                // Decide or continue current activity
                if (npc.activityDaysLeft <= 0) {
                    chooseNextActivity(npc, state)
                } else {
                    npc.activityDaysLeft--
                }

                // Sanitize location - old saves may have invalid location IDs
                if (!LocationSystem.ALL_LOCATIONS.containsKey(npc.currentLocation)) {
                    npc.currentLocation = LocationSystem.ALL_LOCATIONS.keys.first()
                }

                // Execute activity
                val actNews = executeActivity(npc, state)
                if (actNews != null) news += actNews

                // NPC–NPC interaction (only when sharing location)
                val interNews = checkNPCInteraction(npc, state)
                if (interNews != null) news += interNews

                // Update disposition toward player
                npc.disposition = dispositionFromRelationship(npc.relationship)
            }
        }

        return news
    }

    // ── POPULATION MAINTENANCE ────────────────────────────────────────────────

    private fun maintainWorldPopulation(state: GameState) {
        val alive = state.npcs.count { it.alive }
        val target = 20
        if (alive < target) {
            val toSpawn = target - alive
            val locations = LocationSystem.ALL_LOCATIONS.keys.toList()
            repeat(toSpawn) { i ->
                val locId = locations.random()
                val loc   = LocationSystem.get(locId)
                val tier  = when (loc.dangerLevel) {
                    in 1..2 -> if (Random.nextBoolean()) RealmTier.MORTAL else RealmTier.QI_GATHERING
                    in 3..5 -> RealmTier.QI_GATHERING
                    in 6..8 -> if (Random.nextFloat() < 0.4f) RealmTier.FOUNDATION else RealmTier.QI_GATHERING
                    else    -> RealmTier.FOUNDATION
                }
                val newId = "npc_spawn_${state.world.year}_${state.world.day}_$i"
                state.npcs.add(NPCSystem.generateRandomNPC(newId, tier, locId))
            }
        }
    }

    // ── NATURAL DEATH ─────────────────────────────────────────────────────────

    private fun checkNaturalDeath(npc: NPC, state: GameState): WorldNewsEntry? {
        // Mortals: 70-year lifespan
        if (npc.realm.tier == RealmTier.MORTAL && npc.daysAlive > 365 * 65) {
            if (Random.nextFloat() < 0.003f) return killNPC(npc, state, "old age", npc.deathNote)
        }
        // Low HP death
        if (npc.hp <= 0) return killNPC(npc, state, "wounds", "")
        return null
    }

    private fun killNPC(npc: NPC, state: GameState, cause: String, note: String): WorldNewsEntry? {
        npc.alive = false
        npc.hp    = 0

        // Notify disciples / allies
        state.npcs.filter { it.alive }.forEach { other ->
            val rel = other.npcRelationships.firstOrNull { it.targetId == npc.id }
            if (rel != null && (rel.isAlly || rel.isMaster)) {
                other.npcRelationships.firstOrNull { it.targetId == npc.id }?.isRival = false
                // Disciple may seek revenge
                if (rel.isDisciple && Random.nextFloat() < 0.5f) {
                    other.goals.add("avenge the death of ${npc.name}")
                    other.activity = NPCActivity.SEEKING_REVENGE
                    other.activityDaysLeft = Random.nextInt(30, 120)
                }
            }
        }

        val desc = note.ifEmpty { "${npc.name} has died from $cause." }
        npc.lifeEvents.add("Died — $desc")

        return if (npc.metPlayer)
            WorldNewsEntry(
                "${npc.name} is dead.",
                desc,
                WorldNewsType.DEATH,
                state.world.timeDisplay
            )
        else null
    }

    // ── ACTIVITY SELECTION ────────────────────────────────────────────────────

    private fun chooseNextActivity(npc: NPC, state: GameState) {
        val candidates = buildActivityCandidates(npc, state)
        if (candidates.isEmpty()) {
            npc.activity = NPCActivity.IDLE
            npc.activityDaysLeft = Random.nextInt(1, 4)
            return
        }
        val chosen = weightedRandom(candidates)
        npc.activity = chosen.first
        npc.activityDaysLeft = chosen.second
    }

    private fun buildActivityCandidates(npc: NPC, state: GameState): List<Pair<Pair<NPCActivity, Int>, Int>> {
        // (activity, durationDays) to weight
        val opts = mutableListOf<Pair<Pair<NPCActivity, Int>, Int>>()
        val loc  = LocationSystem.get(npc.currentLocation)

        // Always possible
        opts += Pair(NPCActivity.IDLE to Random.nextInt(1, 4), 10)
        opts += Pair(NPCActivity.CULTIVATING to Random.nextInt(3, 15), cultivationWeight(npc))

        // Travel — move somewhere better if location doesn't suit goals
        if (shouldTravel(npc, loc)) {
            opts += Pair(NPCActivity.TRAVELING to 1, 25)
        }

        // Hunting — dangerous locations, or aggressive personalities
        if (loc.dangerLevel >= 3 || npc.personality == NPCPersonality.CHAOTIC) {
            opts += Pair(NPCActivity.HUNTING to Random.nextInt(1, 5), 20)
        }

        // Seeking sect — no sect, below Foundation
        if (npc.sectId.isEmpty() && npc.realm.tier.ordinal <= RealmTier.QI_GATHERING.ordinal) {
            opts += Pair(NPCActivity.SEEKING_SECT to Random.nextInt(5, 20), 15)
        }

        // Revenge — has goal containing "avenge"
        if (npc.goals.any { it.contains("avenge") || it.contains("revenge") }) {
            opts += Pair(NPCActivity.SEEKING_REVENGE to Random.nextInt(10, 30), 30)
        }

        // Seclusion — high-stage cultivator with enough qi
        if (npc.realm.stage >= 5 && npc.qi > npc.maxQi * 0.8f) {
            opts += Pair(NPCActivity.IN_SECLUSION to Random.nextInt(30, 100), 20)
        }

        // Trading — cunning, or low on stones
        if (npc.personality == NPCPersonality.CUNNING || npc.spiritStones < 20) {
            if (loc.hasShop) opts += Pair(NPCActivity.TRADING to Random.nextInt(1, 3), 15)
        }

        // Alliance forming — righteous/warm personalities
        if (npc.personality == NPCPersonality.RIGHTEOUS || npc.personality == NPCPersonality.WARM) {
            opts += Pair(NPCActivity.FORMING_ALLIANCE to Random.nextInt(3, 10), 12)
        }

        // Exploring ruins / peaks
        if (loc.qiQuality == QiQuality.ANCIENT || loc.qiQuality == QiQuality.HEAVENLY) {
            opts += Pair(NPCActivity.EXPLORING to Random.nextInt(3, 10), 18)
        }

        return opts
    }

    private fun cultivationWeight(npc: NPC): Int = when {
        npc.qi < npc.maxQi * 0.3f -> 40   // low qi — high priority
        npc.qi < npc.maxQi * 0.7f -> 25
        else                        -> 10
    }

    private fun shouldTravel(npc: NPC, loc: Location): Boolean {
        // Mortals rarely leave their area
        if (npc.realm.tier == RealmTier.MORTAL && npc.daysInLocation > 10) return Random.nextFloat() < 0.1f
        // Chaotic NPCs travel often
        if (npc.personality == NPCPersonality.CHAOTIC) return Random.nextFloat() < 0.4f
        // If location danger is too high for realm
        if (loc.dangerLevel > npc.realm.tier.ordinal * 2 + 2) return true
        // Revenge — seek target
        if (npc.activity == NPCActivity.SEEKING_REVENGE) return true
        // Sect seeker — move toward sect locations
        if (npc.sectId.isEmpty() && loc.hasSect.not()) return Random.nextFloat() < 0.3f
        return npc.daysInLocation > 30 && Random.nextFloat() < 0.2f
    }

    // ── ACTIVITY EXECUTION ────────────────────────────────────────────────────

    private fun executeActivity(npc: NPC, state: GameState): WorldNewsEntry? {
        return when (npc.activity) {
            NPCActivity.CULTIVATING    -> executeCultivation(npc, state)
            NPCActivity.TRAVELING      -> executeTravel(npc, state)
            NPCActivity.HUNTING        -> executeHunting(npc, state)
            NPCActivity.SEEKING_SECT   -> executeSeekSect(npc, state)
            NPCActivity.SEEKING_REVENGE-> executeRevenge(npc, state)
            NPCActivity.IN_SECLUSION   -> executeSeclusion(npc, state)
            NPCActivity.TRADING        -> executeTrading(npc)
            NPCActivity.FORMING_ALLIANCE -> executeAllianceForming(npc, state)
            NPCActivity.EXPLORING      -> executeExploring(npc, state)
            NPCActivity.DUELING        -> null  // resolved in NPC-NPC interaction
            NPCActivity.IDLE           -> null
        }
    }

    // CULTIVATION
    private fun executeCultivation(npc: NPC, state: GameState): WorldNewsEntry? {
        val loc  = LocationSystem.get(npc.currentLocation)
        val gain = (npc.maxQi / 15 * loc.cultivationBonus).toInt().coerceAtLeast(1)
        npc.qi   = (npc.qi + gain).coerceAtMost(npc.maxQi)

        // Attempt breakthrough when full
        if (npc.qi >= npc.maxQi && Random.nextFloat() < breakthroughChance(npc)) {
            return attemptNPCBreakthrough(npc, state)
        }
        return null
    }

    private fun breakthroughChance(npc: NPC): Float = when (npc.personality) {
        NPCPersonality.HUMBLE, NPCPersonality.RIGHTEOUS -> 0.04f
        NPCPersonality.ARROGANT -> 0.06f   // rushes
        NPCPersonality.MELANCHOLY -> 0.02f  // hesitates
        else -> 0.03f
    }

    private fun attemptNPCBreakthrough(npc: NPC, state: GameState): WorldNewsEntry? {
        val next = npc.realm.next() ?: return null
        npc.breakthroughsAttempted++
        val success = Random.nextFloat() < 0.55f

        return if (success) {
            val oldRealm = npc.realm.display
            npc.realm  = next
            npc.maxQi  = next.qiCap
            npc.maxHp += next.tier.hpBonus
            npc.hp     = npc.maxHp
            npc.qi     = 0
            npc.lifeEvents.add("Broke through to ${next.display} in ${npc.currentLocation} — Year ${state.world.year}")

            // Arrogant NPCs become more so; chaotic ones more dangerous
            if (npc.personality == NPCPersonality.ARROGANT) npc.relationship -= 3
            if (npc.isDemonic) npc.hp += 200  // demonic bonus

            // Notable if met player or high realm
            if (npc.metPlayer || next.tier.ordinal >= RealmTier.FOUNDATION.ordinal) {
                WorldNewsEntry(
                    "${npc.name} advanced.",
                    "${npc.name} broke through from $oldRealm to ${next.display}.",
                    WorldNewsType.ADVANCEMENT,
                    state.world.timeDisplay
                )
            } else null
        } else {
            // Failure — damage, possible deviation
            val dmg = npc.maxHp / 4
            npc.hp -= dmg
            if (npc.personality == NPCPersonality.ARROGANT && Random.nextFloat() < 0.15f) {
                // Devastating failure — goes demonic from desperation
                npc.isDemonic = true
                npc.isRogue   = true
                npc.lifeEvents.add("Turned demonic after catastrophic breakthrough failure — Year ${state.world.year}")
                if (npc.metPlayer) WorldNewsEntry(
                    "${npc.name} has turned demonic.",
                    "A failed breakthrough tore something loose in ${npc.name}. They have embraced the demonic path.",
                    WorldNewsType.WENT_DEMONIC, state.world.timeDisplay
                ) else null
            } else null
        }
    }

    // TRAVEL
    private fun executeTravel(npc: NPC, state: GameState): WorldNewsEntry? {
        val destination = chooseTravelDestination(npc, state)
        if (destination == npc.currentLocation) return null

        val old = npc.currentLocation
        npc.currentLocation = destination
        npc.daysInLocation  = 0

        // Qi quality effect on arrival
        val loc = LocationSystem.get(destination)
        when (loc.qiQuality) {
            QiQuality.CORRUPTED -> {
                npc.hp = (npc.hp - npc.maxHp / 10).coerceAtLeast(1)
                if (npc.personality == NPCPersonality.RIGHTEOUS && Random.nextFloat() < 0.05f) {
                    npc.isDemonic = true
                    npc.lifeEvents.add("Corrupted by the Demon Wastes — Year ${state.world.year}")
                }
            }
            QiQuality.HEAVENLY  -> npc.qi = (npc.qi + npc.maxQi / 5).coerceAtMost(npc.maxQi)
            else -> {}
        }

        return if (npc.metPlayer && loc.hasSect) WorldNewsEntry(
            "${npc.name} was spotted traveling.",
            "${npc.name} has moved from ${LocationSystem.get(old).name} to ${loc.name}.",
            WorldNewsType.MOVEMENT, state.world.timeDisplay
        ) else null
    }

    private fun chooseTravelDestination(npc: NPC, state: GameState): String {
        val all = LocationSystem.ALL_LOCATIONS.keys.toList()

        // Revenge seeker — go where target NPC or rival sect is
        if (npc.activity == NPCActivity.SEEKING_REVENGE) {
            val revengeTarget = npc.npcRelationships.firstOrNull { it.isRival }?.targetId
            if (revengeTarget != null) {
                val targetNPC = state.npcs.firstOrNull { it.id == revengeTarget && it.alive }
                if (targetNPC != null) return targetNPC.currentLocation
            }
        }

        // Sect seeker — go toward sect locations
        if (npc.sectId.isEmpty() && npc.activity == NPCActivity.SEEKING_SECT) {
            val sectLocs = SectSystem.SECTS.values.map { it.locationId }
            return sectLocs.random()
        }

        // High-realm cultivators seek better qi
        if (npc.realm.tier.ordinal >= RealmTier.FOUNDATION.ordinal) {
            val goodQiLocs = all.filter {
                val l = LocationSystem.get(it)
                l.qiQuality == QiQuality.ANCIENT || l.qiQuality == QiQuality.HEAVENLY || l.qiQuality == QiQuality.DENSE
            }
            if (goodQiLocs.isNotEmpty()) return goodQiLocs.random()
        }

        // Danger filter — don't walk into instadeath
        val safe = all.filter {
            val l = LocationSystem.get(it)
            l.minRealm.ordinal <= npc.realm.tier.ordinal && it != npc.currentLocation
        }
        return if (safe.isNotEmpty()) safe.random() else all.filter { it != npc.currentLocation }.random()
    }

    // HUNTING
    private fun executeHunting(npc: NPC, state: GameState): WorldNewsEntry? {
        val loc = LocationSystem.get(npc.currentLocation)
        // Hunting gives stones and kills, minor injury risk
        val stones = Random.nextInt(2, 10 + loc.dangerLevel * 3)
        npc.spiritStones += stones
        npc.kills++

        // Small injury chance
        if (Random.nextFloat() < 0.15f) npc.hp = (npc.hp - npc.maxHp / 8).coerceAtLeast(1)

        // Demonic NPC hunting might attack people
        if (npc.isDemonic && Random.nextFloat() < 0.1f) {
            val victim = state.npcs.firstOrNull {
                it.alive && it.id != npc.id &&
                it.currentLocation == npc.currentLocation &&
                it.realm.power < npc.realm.power
            }
            if (victim != null) {
                return npcFight(npc, victim, state, isDemonic = true)
            }
        }
        return null
    }

    // SECT SEEKING
    private fun executeSeekSect(npc: NPC, state: GameState): WorldNewsEntry? {
        val sectInArea = SectSystem.SECTS.values.firstOrNull { it.locationId == npc.currentLocation }
        if (sectInArea != null && npc.sectId.isEmpty()) {
            // Join the sect
            npc.sectId = sectInArea.id
            npc.lifeEvents.add("Joined ${sectInArea.name} — Year ${state.world.year}")
            npc.activity = NPCActivity.CULTIVATING
            return if (npc.metPlayer) WorldNewsEntry(
                "${npc.name} joined a sect.",
                "${npc.name} has sworn the disciple oath to ${sectInArea.name}.",
                WorldNewsType.JOINED_SECT, state.world.timeDisplay
            ) else null
        }
        // Not at sect location — keep traveling
        if (npc.currentLocation !in SectSystem.SECTS.values.map { it.locationId }) {
            npc.activity = NPCActivity.TRAVELING
            npc.activityDaysLeft = 1
        }
        return null
    }

    // REVENGE
    private fun executeRevenge(npc: NPC, state: GameState): WorldNewsEntry? {
        val revengeTargetId = npc.goals.firstOrNull { it.contains("avenge") }?.let {
            // Try to find an NPC whose name appears in the goal
            state.npcs.firstOrNull { target -> it.contains(target.name) }?.id
        } ?: npc.npcRelationships.firstOrNull { it.isRival }?.targetId

        val target = state.npcs.firstOrNull { it.id == revengeTargetId && it.alive } ?: run {
            // Target already dead or not found — goal complete
            npc.goals.removeAll { it.contains("avenge") || it.contains("revenge") }
            npc.activity = NPCActivity.IDLE
            npc.activityDaysLeft = 0
            return null
        }

        // Are they in the same location?
        if (npc.currentLocation == target.currentLocation) {
            return npcFight(npc, target, state, isDemonic = false)
        } else {
            // Travel toward them
            npc.currentLocation = target.currentLocation
            npc.daysInLocation  = 0
        }
        return null
    }

    // SECLUSION
    private fun executeSeclusion(npc: NPC, state: GameState): WorldNewsEntry? {
        // Intensive cultivation — bulk qi gain, possible breakthrough
        val gain = (npc.maxQi / 8).coerceAtLeast(5)
        npc.qi   = (npc.qi + gain).coerceAtMost(npc.maxQi)
        if (npc.qi >= npc.maxQi && Random.nextFloat() < 0.06f) {
            return attemptNPCBreakthrough(npc, state)
        }
        return null
    }

    // TRADING
    private fun executeTrading(npc: NPC): WorldNewsEntry? {
        // Buy or sell — just simulate stone flow
        val delta = Random.nextInt(-10, 20)
        npc.spiritStones = (npc.spiritStones + delta).coerceAtLeast(0)
        return null
    }

    // ALLIANCE FORMING
    private fun executeAllianceForming(npc: NPC, state: GameState): WorldNewsEntry? {
        val potential = state.npcs.filter {
            it.alive && it.id != npc.id &&
            it.currentLocation == npc.currentLocation &&
            it.disposition != NPCDisposition.HOSTILE &&
            npc.npcRelationships.none { r -> r.targetId == it.id }
        }.randomOrNull() ?: return null

        // Compatibility check
        val compatible = when {
            npc.personality == NPCPersonality.RIGHTEOUS && potential.isDemonic -> false
            npc.isDemonic && potential.personality == NPCPersonality.RIGHTEOUS  -> false
            else -> Random.nextFloat() < 0.55f
        }

        if (compatible) {
            npc.npcRelationships.add(NPCRelationship(potential.id, score = 30, isAlly = true))
            potential.npcRelationships.add(NPCRelationship(npc.id, score = 30, isAlly = true))
            npc.lifeEvents.add("Formed an alliance with ${potential.name} — Year ${state.world.year}")

            return if (npc.metPlayer || potential.metPlayer) WorldNewsEntry(
                "${npc.name} and ${potential.name} formed an alliance.",
                "The two cultivators were seen exchanging cultivation notes at ${LocationSystem.get(npc.currentLocation).name}.",
                WorldNewsType.ALLIANCE, state.world.timeDisplay
            ) else null
        }
        return null
    }

    // EXPLORING
    private fun executeExploring(npc: NPC, state: GameState): WorldNewsEntry? {
        val loc = LocationSystem.get(npc.currentLocation)
        when {
            loc.qiQuality == QiQuality.ANCIENT && Random.nextFloat() < 0.08f -> {
                // Found ancient technique
                npc.techniques.add("ancient_tech_${npc.id}")
                npc.lifeEvents.add("Discovered ancient technique in the ruins — Year ${state.world.year}")
                if (npc.metPlayer) return WorldNewsEntry(
                    "${npc.name} found something in the ruins.",
                    "${npc.name} emerged from the Shattered Heaven Ruins carrying something new.",
                    WorldNewsType.DISCOVERY, state.world.timeDisplay
                )
            }
            loc.qiQuality == QiQuality.HEAVENLY && Random.nextFloat() < 0.12f -> {
                npc.maxQi = (npc.maxQi * 1.1f).toInt()
                npc.lifeEvents.add("Foundation expanded at Sacred Spring — Year ${state.world.year}")
            }
        }
        // Small qi gain from ambient exposure
        npc.qi = (npc.qi + npc.maxQi / 12).coerceAtMost(npc.maxQi)
        return null
    }

    // ── NPC vs NPC COMBAT ─────────────────────────────────────────────────────

    private fun checkNPCInteraction(npc: NPC, state: GameState): WorldNewsEntry? {
        if (Random.nextFloat() > 0.04f) return null  // only 4% chance per day

        val others = state.npcs.filter {
            it.alive && it.id != npc.id && it.currentLocation == npc.currentLocation
        }
        val target = others.randomOrNull() ?: return null

        // Existing rivalry → fight
        val rel = npc.npcRelationships.firstOrNull { it.targetId == target.id }
        if (rel != null && rel.isRival) return npcFight(npc, target, state, false)

        // Demonic vs anyone
        if (npc.isDemonic && !target.isDemonic && Random.nextFloat() < 0.2f) {
            return npcFight(npc, target, state, true)
        }

        // Chaotic vs anyone
        if (npc.personality == NPCPersonality.CHAOTIC && Random.nextFloat() < 0.1f) {
            return npcFight(npc, target, state, false)
        }

        // Friendly interaction — strengthen bond
        if (npc.disposition != NPCDisposition.HOSTILE && target.disposition != NPCDisposition.HOSTILE) {
            if (rel == null) {
                val friendScore = Random.nextInt(5, 20)
                npc.npcRelationships.add(NPCRelationship(target.id, score = friendScore))
                target.npcRelationships.add(NPCRelationship(npc.id, score = friendScore))
            } else {
                rel.score = (rel.score + Random.nextInt(1, 5)).coerceAtMost(100)
            }
        }
        return null
    }

    private fun npcFight(attacker: NPC, defender: NPC, state: GameState, isDemonic: Boolean): WorldNewsEntry? {
        attacker.activity = NPCActivity.DUELING
        defender.activity = NPCActivity.DUELING

        val attackerPower = npcCombatPower(attacker)
        val defenderPower = npcCombatPower(defender)

        val attackerWins = Random.nextFloat() < (attackerPower.toFloat() / (attackerPower + defenderPower))

        val winner = if (attackerWins) attacker else defender
        val loser  = if (attackerWins) defender else attacker

        // Loser damage
        val dmg = (loser.maxHp * Random.nextFloat().let { if (it < 0.2f) 0.8f else if (it < 0.6f) 0.4f else 0.2f }).toInt()
        loser.hp -= dmg

        // Winner gains stones from loser
        val stolenStones = minOf(loser.spiritStones, Random.nextInt(0, 20 + winner.realm.power / 10))
        winner.spiritStones += stolenStones
        loser.spiritStones  -= stolenStones
        winner.kills++

        val locName = LocationSystem.get(attacker.currentLocation).name

        // Death?
        if (loser.hp <= 0) {
            val news = killNPC(loser, state, "combat with ${winner.name}", loser.deathNote)

            // Winner may go demonic after killing
            if (winner.kills > 10 && winner.personality == NPCPersonality.CHAOTIC && Random.nextFloat() < 0.1f) {
                winner.isDemonic = true
                winner.lifeEvents.add("Turned demonic after too many kills — Year ${state.world.year}")
            }

            // Record as rival (won't be needed anymore but keep for history)
            winner.npcRelationships.firstOrNull { it.targetId == loser.id }?.isRival = false
            winner.lifeEvents.add("Killed ${loser.name} at $locName — Year ${state.world.year}")
            loser.lifeEvents.add("Killed by ${winner.name} at $locName — Year ${state.world.year}")

            return if (winner.metPlayer || loser.metPlayer) WorldNewsEntry(
                "${loser.name} was killed by ${winner.name}.",
                "${winner.name} defeated ${loser.name} at $locName. The battle lasted only moments — the realm gap was decisive.",
                if (loser.metPlayer) WorldNewsType.DEATH else WorldNewsType.BATTLE,
                state.world.timeDisplay
            ) else news
        }

        // Survivor — mark as rivals if not already
        if (attacker.npcRelationships.none { it.targetId == defender.id }) {
            attacker.npcRelationships.add(NPCRelationship(defender.id, score = -50, isRival = true))
            defender.npcRelationships.add(NPCRelationship(attacker.id, score = -50, isRival = true))
        } else {
            attacker.npcRelationships.first { it.targetId == defender.id }.isRival = true
            defender.npcRelationships.first { it.targetId == attacker.id }.isRival = true
        }

        attacker.lifeEvents.add("${if (attackerWins) "Defeated" else "Lost to"} ${defender.name} at $locName — Year ${state.world.year}")

        return if (attacker.metPlayer || defender.metPlayer) WorldNewsEntry(
            "${attacker.name} and ${defender.name} clashed.",
            "${winner.name} won the exchange at $locName. ${loser.name} retreated with wounds.",
            WorldNewsType.BATTLE, state.world.timeDisplay
        ) else null
    }

    private fun npcCombatPower(npc: NPC): Int {
        val base = npc.realm.power * 10 + npc.kills * 2
        val personality = when (npc.personality) {
            NPCPersonality.CHAOTIC, NPCPersonality.ARROGANT -> 15
            NPCPersonality.COLD -> 10
            NPCPersonality.HUMBLE -> -5
            else -> 0
        }
        val demonic = if (npc.isDemonic) 30 else 0
        return base + personality + demonic + Random.nextInt(-10, 20)
    }

    // ── HELPERS ───────────────────────────────────────────────────────────────

    private fun dispositionFromRelationship(rel: Int) = when {
        rel > 60  -> NPCDisposition.DEVOTED
        rel > 25  -> NPCDisposition.FRIENDLY
        rel > -10 -> NPCDisposition.NEUTRAL
        rel > -40 -> NPCDisposition.WARY
        else      -> NPCDisposition.HOSTILE
    }

    private fun <T> weightedRandom(items: List<Pair<T, Int>>): T {
        if (items.isEmpty()) throw IllegalStateException("weightedRandom called with empty list")
        val total = items.sumOf { it.second }.coerceAtLeast(1)
        var r     = Random.nextInt(total)
        for ((item, weight) in items) {
            r -= weight
            if (r < 0) return item
        }
        return items.last().first
    }
}

// ── WORLD NEWS ────────────────────────────────────────────────────────────────

data class WorldNewsEntry(
    val headline: String,
    val detail: String,
    val type: WorldNewsType,
    val timestamp: String
)

enum class WorldNewsType {
    DEATH, BATTLE, ADVANCEMENT, WENT_DEMONIC,
    JOINED_SECT, ALLIANCE, DISCOVERY, MOVEMENT
}
