package com.jarry.novallm

import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    companion object {
        init {
            System.loadLibrary("novallm_core")
        }
    }

    external fun nativeRunMathCoreTest(): String
    external fun nativeRunTokenizerTest(): String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val resultView = TextView(this).apply {
            text = "NovaLLM \u2014 tap a button to run its on-device tests."
            textSize = 14f
            setPadding(32, 32, 32, 32)
        }

        val mathButton = Button(this).apply {
            text = "Run Math Core Test"
            setOnClickListener {
                resultView.text = try {
                    nativeRunMathCoreTest()
                } catch (e: Throwable) {
                    "Native call failed: ${e.message}"
                }
            }
        }

        val tokenizerButton = Button(this).apply {
            text = "Run Tokenizer Test"
            setOnClickListener {
                resultView.text = try {
                    nativeRunTokenizerTest()
                } catch (e: Throwable) {
                    "Native call failed: ${e.message}"
                }
            }
        }

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(mathButton)
            addView(tokenizerButton)
            addView(resultView)
        }

        setContentView(ScrollView(this).apply { addView(layout) })
    }
}
