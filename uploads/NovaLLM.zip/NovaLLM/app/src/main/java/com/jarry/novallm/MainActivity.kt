package com.jarry.novallm

import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    companion object {
        init {
            System.loadLibrary("novallm_core")
        }
    }

    external fun nativeRunMathCoreTest(): String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val resultView = TextView(this).apply {
            text = "NovaLLM \u2014 core/math subsystem\nTap the button to run on-device tests."
            textSize = 14f
            setPadding(32, 32, 32, 32)
        }

        val runButton = Button(this).apply {
            text = "Run Math Core Test"
            setOnClickListener {
                resultView.text = try {
                    nativeRunMathCoreTest()
                } catch (e: Throwable) {
                    "Native call failed: ${e.message}"
                }
            }
        }

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(runButton)
            addView(resultView)
        }

        setContentView(ScrollView(this).apply { addView(layout) })
    }
}
