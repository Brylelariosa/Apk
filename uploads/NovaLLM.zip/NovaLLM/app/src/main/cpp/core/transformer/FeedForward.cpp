#include "FeedForward.h"
#include <cmath>
#include <ostream>
#include <istream>

namespace novallm {

float gelu(float x) {
    // 0.5x(1 + tanh(sqrt(2/pi) * (x + 0.044715x^3)))
    constexpr float kSqrt2OverPi = 0.7978845608028654f;
    float inner = kSqrt2OverPi * (x + 0.044715f * x * x * x);
    return 0.5f * x * (1.0f + std::tanh(inner));
}

FeedForward::FeedForward(int embedDim, int hiddenDim, unsigned int seed)
    : fc1_(embedDim, hiddenDim, seed, /*useBias=*/true),
      fc2_(hiddenDim, embedDim, seed + 1, /*useBias=*/true) {}

Tensor FeedForward::forward(const Tensor& x) const {
    Tensor hidden = fc1_.forward(x);
    for (size_t i = 0; i < hidden.size(); ++i) {
        hidden.data()[i] = gelu(hidden.data()[i]);
    }
    return fc2_.forward(hidden);
}

void FeedForward::save(std::ostream& out) const {
    fc1_.save(out);
    fc2_.save(out);
}

void FeedForward::load(std::istream& in) {
    fc1_.load(in);
    fc2_.load(in);
}

} // namespace novallm
