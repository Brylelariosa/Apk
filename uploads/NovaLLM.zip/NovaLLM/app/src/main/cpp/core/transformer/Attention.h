#pragma once
#include "../math/Tensor.h"
#include "Linear.h"

namespace novallm {

// Causal (decoder-only) multi-head self-attention. Position i can only
// attend to positions <= i - this is what makes autoregressive generation
// valid at all. There is no non-causal mode: this is a text-generation
// engine, not a bidirectional encoder.
//
// No KV cache yet - every forward() call recomputes attention over the
// whole sequence from scratch. Caching belongs with the generation loop
// (core/runtime, subsystem 6), not here.
class MultiHeadAttention {
public:
    MultiHeadAttention(int embedDim, int numHeads, unsigned int seed = 42);

    // x: {seqLen, embedDim} -> {seqLen, embedDim}
    Tensor forward(const Tensor& x) const;

    int embedDim() const { return embedDim_; }
    int numHeads() const { return numHeads_; }
    int headDim() const { return headDim_; }

private:
    int embedDim_;
    int numHeads_;
    int headDim_;
    Linear wq_, wk_, wv_, wo_;
};

} // namespace novallm
