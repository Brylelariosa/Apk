#include "Generator.h"

namespace novallm {

Generator::Generator(Model& model, Tokenizer& tokenizer, unsigned int samplerSeed)
    : model_(model), tokenizer_(tokenizer), sampler_(samplerSeed) {}

std::string Generator::generate(const std::string& prompt, const GenerationParams& params) {
    std::vector<int> ids = tokenizer_.encode(prompt);
    size_t promptLen = ids.size();
    int eosId = tokenizer_.specialTokenId("eos");

    for (int step = 0; step < params.maxNewTokens; ++step) {
        if (static_cast<int>(ids.size()) >= model_.config().maxSeqLen) {
            break; // out of position-encoding room - stop rather than corrupt output
        }

        Tensor logits = model_.forward(ids); // {seqLen, vocabSize}, recomputed from scratch
        int lastPos = logits.dim(0) - 1;
        int vocabSize = logits.dim(1);

        std::vector<float> lastLogits(static_cast<size_t>(vocabSize));
        for (int v = 0; v < vocabSize; ++v) {
            lastLogits[static_cast<size_t>(v)] = logits.at({lastPos, v});
        }

        int nextId = sampler_.sample(lastLogits, params.sampling);
        ids.push_back(nextId);

        if (eosId != -1 && nextId == eosId) break;
    }

    std::vector<int> newIds(ids.begin() + static_cast<long>(promptLen), ids.end());
    return tokenizer_.decode(newIds);
}

} // namespace novallm
