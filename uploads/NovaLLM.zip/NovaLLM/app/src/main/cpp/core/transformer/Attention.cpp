#include "Attention.h"
#include "../math/Matrix.h"
#include <cmath>
#include <stdexcept>

namespace novallm {

MultiHeadAttention::MultiHeadAttention(int embedDim, int numHeads, unsigned int seed)
    : embedDim_(embedDim), numHeads_(numHeads), headDim_(embedDim / numHeads),
      wq_(embedDim, embedDim, seed, true),
      wk_(embedDim, embedDim, seed + 1, true),
      wv_(embedDim, embedDim, seed + 2, true),
      wo_(embedDim, embedDim, seed + 3, true) {
    if (embedDim % numHeads != 0) {
        throw std::invalid_argument("MultiHeadAttention: embedDim must be divisible by numHeads");
    }
}

Tensor MultiHeadAttention::forward(const Tensor& x) const {
    int seqLen = x.dim(0);

    Tensor q = wq_.forward(x); // {seqLen, embedDim}
    Tensor k = wk_.forward(x);
    Tensor v = wv_.forward(x);

    Tensor concatOut({seqLen, embedDim_});
    float scaleFactor = 1.0f / std::sqrt(static_cast<float>(headDim_));

    for (int h = 0; h < numHeads_; ++h) {
        Tensor qh = matrix::sliceColumns(q, h * headDim_, headDim_); // {seqLen, headDim}
        Tensor kh = matrix::sliceColumns(k, h * headDim_, headDim_);
        Tensor vh = matrix::sliceColumns(v, h * headDim_, headDim_);

        Tensor khT = matrix::transpose(kh);                 // {headDim, seqLen}
        Tensor scores = matrix::matmul(qh, khT);             // {seqLen, seqLen}
        scores = matrix::scale(scores, scaleFactor);

        // Causal mask: query position i must not see key position j > i.
        for (int i = 0; i < seqLen; ++i) {
            for (int j = i + 1; j < seqLen; ++j) {
                scores.at({i, j}) = -1e9f;
            }
        }

        matrix::softmaxRows(scores); // row-wise, in place

        Tensor headOut = matrix::matmul(scores, vh); // {seqLen, headDim}
        matrix::setColumns(concatOut, h * headDim_, headOut);
    }

    return wo_.forward(concatOut);
}

} // namespace novallm
