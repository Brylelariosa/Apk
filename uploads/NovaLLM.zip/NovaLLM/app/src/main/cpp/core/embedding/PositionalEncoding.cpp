#include "PositionalEncoding.h"
#include <cmath>
#include <stdexcept>

namespace novallm {

PositionalEncoding::PositionalEncoding(int maxSeqLen, int embedDim)
    : maxSeqLen_(maxSeqLen), embedDim_(embedDim), table_({maxSeqLen, embedDim}) {
    for (int pos = 0; pos < maxSeqLen; ++pos) {
        for (int i = 0; i < embedDim; ++i) {
            int pairIndex = i / 2;
            double exponent = static_cast<double>(2 * pairIndex) / static_cast<double>(embedDim);
            double freq = 1.0 / std::pow(10000.0, exponent);
            double angle = static_cast<double>(pos) * freq;
            float value = (i % 2 == 0) ? static_cast<float>(std::sin(angle))
                                        : static_cast<float>(std::cos(angle));
            table_.at({pos, i}) = value;
        }
    }
}

Tensor PositionalEncoding::encode(int seqLen) const {
    if (seqLen > maxSeqLen_) {
        throw std::out_of_range("PositionalEncoding::encode - seqLen exceeds maxSeqLen");
    }
    Tensor out({seqLen, embedDim_});
    for (int pos = 0; pos < seqLen; ++pos) {
        for (int i = 0; i < embedDim_; ++i) {
            out.at({pos, i}) = table_.at({pos, i});
        }
    }
    return out;
}

Tensor PositionalEncoding::applyTo(const Tensor& embeddings) const {
    if (embeddings.rank() != 2 || embeddings.dim(1) != embedDim_) {
        throw std::invalid_argument("PositionalEncoding::applyTo - shape mismatch");
    }
    int seqLen = embeddings.dim(0);
    Tensor pe = encode(seqLen);
    Tensor out({seqLen, embedDim_});
    for (size_t k = 0; k < embeddings.size(); ++k) {
        out.data()[k] = embeddings.data()[k] + pe.data()[k];
    }
    return out;
}

} // namespace novallm
