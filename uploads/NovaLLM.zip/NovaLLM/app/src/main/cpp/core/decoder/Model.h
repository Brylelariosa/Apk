#pragma once
#include <vector>
#include "../math/Tensor.h"
#include "../embedding/TokenEmbedding.h"
#include "../embedding/PositionalEncoding.h"
#include "../transformer/Block.h"
#include "../transformer/LayerNorm.h"
#include "../transformer/Linear.h"

namespace novallm {

// The full assembled model: embedding -> +positional encoding -> N
// transformer blocks -> final LayerNorm -> LM head -> logits over the
// vocabulary. "Logits" from the original component list isn't a separate
// class - it's just the shape {seqLen, vocabSize} this returns.
//
// Weights are random (untrained) until subsystem 7 exists. This class is
// the forward-pass machinery; it says nothing meaningful until training
// shapes those weights into something.
class Model {
public:
    struct Config {
        int vocabSize;
        int embedDim;
        int numLayers;
        int numHeads;
        int ffnHiddenDim;
        int maxSeqLen;
    };

    explicit Model(const Config& config, unsigned int seed = 42);

    // ids -> logits, shape {seqLen, vocabSize}.
    Tensor forward(const std::vector<int>& ids) const;

    const Config& config() const { return config_; }

private:
    Config config_;
    TokenEmbedding tokenEmbedding_;
    PositionalEncoding positionalEncoding_;
    std::vector<TransformerBlock> blocks_;
    LayerNorm finalNorm_;
    Linear lmHead_;
};

} // namespace novallm
