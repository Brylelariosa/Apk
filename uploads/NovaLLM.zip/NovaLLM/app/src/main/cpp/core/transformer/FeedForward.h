#pragma once
#include "../math/Tensor.h"
#include "Linear.h"

namespace novallm {

// Position-wise feed-forward network: fc2(gelu(fc1(x))).
// hiddenDim is conventionally 4x embedDim.
class FeedForward {
public:
    FeedForward(int embedDim, int hiddenDim, unsigned int seed = 42);

    // x: {seqLen, embedDim} -> {seqLen, embedDim}
    Tensor forward(const Tensor& x) const;

private:
    Linear fc1_; // embedDim -> hiddenDim
    Linear fc2_; // hiddenDim -> embedDim
};

// GELU activation (tanh approximation, same one GPT-2 uses).
float gelu(float x);

} // namespace novallm
