#include "Block.h"
#include "../math/Matrix.h"

namespace novallm {

TransformerBlock::TransformerBlock(int embedDim, int numHeads, int ffnHiddenDim, unsigned int seed)
    : ln1_(embedDim),
      attn_(embedDim, numHeads, seed),
      ln2_(embedDim),
      ffn_(embedDim, ffnHiddenDim, seed + 10) {}

Tensor TransformerBlock::forward(const Tensor& x) const {
    Tensor normed1 = ln1_.forward(x);
    Tensor attnOut = attn_.forward(normed1);
    Tensor residual1 = matrix::add(x, attnOut);

    Tensor normed2 = ln2_.forward(residual1);
    Tensor ffnOut = ffn_.forward(normed2);
    Tensor residual2 = matrix::add(residual1, ffnOut);

    return residual2;
}

} // namespace novallm
