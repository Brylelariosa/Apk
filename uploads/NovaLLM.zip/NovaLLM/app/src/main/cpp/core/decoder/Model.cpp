#include "Model.h"

namespace novallm {

Model::Model(const Config& config, unsigned int seed)
    : config_(config),
      tokenEmbedding_(config.vocabSize, config.embedDim, seed),
      positionalEncoding_(config.maxSeqLen, config.embedDim),
      finalNorm_(config.embedDim),
      lmHead_(config.embedDim, config.vocabSize, seed + 1000, /*useBias=*/true) {
    blocks_.reserve(static_cast<size_t>(config.numLayers));
    for (int i = 0; i < config.numLayers; ++i) {
        blocks_.emplace_back(config.embedDim, config.numHeads, config.ffnHiddenDim,
                              seed + 100 + static_cast<unsigned int>(i) * 10);
    }
}

Tensor Model::forward(const std::vector<int>& ids) const {
    Tensor x = positionalEncoding_.applyTo(tokenEmbedding_.lookupSequence(ids));
    for (const auto& block : blocks_) {
        x = block.forward(x);
    }
    x = finalNorm_.forward(x);
    return lmHead_.forward(x); // {seqLen, vocabSize}
}

} // namespace novallm
