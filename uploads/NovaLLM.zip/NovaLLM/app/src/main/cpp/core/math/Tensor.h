#pragma once
#include <vector>
#include <cstddef>
#include <string>
#include <stdexcept>

namespace novallm {

// A flat, row-major, N-dimensional float tensor.
// No autograd, no broadcasting magic - just a data buffer + shape.
// Kept intentionally simple: correctness first, SIMD/quantization come
// later as their own subsystem pass on top of this.
class Tensor {
public:
    Tensor() = default;
    explicit Tensor(const std::vector<int>& shape);
    Tensor(const std::vector<int>& shape, float fillValue);

    // Element access via multi-dimensional index, e.g. t.at({row, col})
    float& at(const std::vector<int>& indices);
    float at(const std::vector<int>& indices) const;

    float* data() { return data_.data(); }
    const float* data() const { return data_.data(); }

    size_t size() const { return data_.size(); }
    const std::vector<int>& shape() const { return shape_; }
    int dim(int axis) const { return shape_.at(axis); }
    int rank() const { return static_cast<int>(shape_.size()); }

    void fill(float value);
    void reshape(const std::vector<int>& newShape);

    std::string debugString(int maxElements = 16) const;

private:
    std::vector<int> shape_;
    std::vector<int> strides_;
    std::vector<float> data_;

    void computeStrides();
    size_t flattenIndex(const std::vector<int>& indices) const;
    static size_t product(const std::vector<int>& v);
};

} // namespace novallm
