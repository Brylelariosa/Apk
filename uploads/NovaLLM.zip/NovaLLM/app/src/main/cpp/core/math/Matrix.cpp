#include "Matrix.h"
#include <stdexcept>

namespace novallm {
namespace matrix {

Tensor matmul(const Tensor& a, const Tensor& b) {
    if (a.rank() != 2 || b.rank() != 2) {
        throw std::invalid_argument("matmul: both tensors must be rank 2");
    }
    int m = a.dim(0);
    int k = a.dim(1);
    int k2 = b.dim(0);
    int n = b.dim(1);
    if (k != k2) {
        throw std::invalid_argument("matmul: inner dimensions do not match");
    }

    Tensor out({m, n});
    const float* ad = a.data();
    const float* bd = b.data();
    float* od = out.data();

    // i-p-j loop order: walks B and the output row-wise (cache friendly),
    // and skips the inner loop entirely for zero entries in A.
    for (int i = 0; i < m; ++i) {
        float* orow = od + static_cast<size_t>(i) * n;
        for (int p = 0; p < k; ++p) {
            float av = ad[static_cast<size_t>(i) * k + p];
            if (av == 0.0f) continue;
            const float* brow = bd + static_cast<size_t>(p) * n;
            for (int j = 0; j < n; ++j) {
                orow[j] += av * brow[j];
            }
        }
    }
    return out;
}

Tensor add(const Tensor& a, const Tensor& b) {
    if (a.shape() != b.shape()) {
        throw std::invalid_argument("add: shape mismatch");
    }
    Tensor out(a.shape());
    for (size_t i = 0; i < a.size(); ++i) {
        out.data()[i] = a.data()[i] + b.data()[i];
    }
    return out;
}

Tensor addBias(const Tensor& a, const Tensor& bias) {
    if (a.rank() != 2) throw std::invalid_argument("addBias: a must be rank 2");
    int rows = a.dim(0);
    int cols = a.dim(1);
    if (static_cast<int>(bias.size()) != cols) {
        throw std::invalid_argument("addBias: bias size must equal column count");
    }
    Tensor out({rows, cols});
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            out.data()[static_cast<size_t>(i) * cols + j] =
                a.data()[static_cast<size_t>(i) * cols + j] + bias.data()[j];
        }
    }
    return out;
}

Tensor transpose(const Tensor& a) {
    if (a.rank() != 2) throw std::invalid_argument("transpose: a must be rank 2");
    int rows = a.dim(0);
    int cols = a.dim(1);
    Tensor out({cols, rows});
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            out.data()[static_cast<size_t>(j) * rows + i] =
                a.data()[static_cast<size_t>(i) * cols + j];
        }
    }
    return out;
}

Tensor scale(const Tensor& a, float scalar) {
    Tensor out(a.shape());
    for (size_t i = 0; i < a.size(); ++i) {
        out.data()[i] = a.data()[i] * scalar;
    }
    return out;
}

} // namespace matrix
} // namespace novallm
