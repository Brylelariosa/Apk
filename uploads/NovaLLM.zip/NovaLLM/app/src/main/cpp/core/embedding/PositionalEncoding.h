#pragma once
#include "../math/Tensor.h"

namespace novallm {

// Fixed (non-learned) sinusoidal positional encoding, as in "Attention Is
// All You Need". Precomputes a {maxSeqLen, embedDim} table once; add a
// slice of it to token embeddings to inject position information.
//
// RoPE is the planned upgrade from this - it rotates query/key vectors
// inside attention rather than adding a fixed vector at the embedding
// stage, so it belongs in core/transformer once attention exists, not
// here. Deferred on purpose, not forgotten.
class PositionalEncoding {
public:
    PositionalEncoding(int maxSeqLen, int embedDim);

    // Returns the {seqLen, embedDim} slice of the precomputed table for
    // positions [0, seqLen).
    Tensor encode(int seqLen) const;

    // Convenience: embeddings + positional encoding, both {seqLen, embedDim}.
    Tensor applyTo(const Tensor& embeddings) const;

    int maxSeqLen() const { return maxSeqLen_; }
    int embedDim() const { return embedDim_; }

private:
    int maxSeqLen_;
    int embedDim_;
    Tensor table_; // {maxSeqLen, embedDim}, precomputed at construction
};

} // namespace novallm
