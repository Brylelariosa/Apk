#include "Tensor.h"
#include <algorithm>

namespace novallm {

Tensor::Tensor(const std::vector<int>& shape) : shape_(shape) {
    computeStrides();
    data_.assign(product(shape_), 0.0f);
}

Tensor::Tensor(const std::vector<int>& shape, float fillValue) : shape_(shape) {
    computeStrides();
    data_.assign(product(shape_), fillValue);
}

void Tensor::computeStrides() {
    strides_.assign(shape_.size(), 1);
    for (int i = static_cast<int>(shape_.size()) - 2; i >= 0; --i) {
        strides_[i] = strides_[i + 1] * shape_[i + 1];
    }
}

size_t Tensor::product(const std::vector<int>& v) {
    size_t p = 1;
    for (int x : v) p *= static_cast<size_t>(x);
    return p;
}

size_t Tensor::flattenIndex(const std::vector<int>& indices) const {
    if (indices.size() != shape_.size()) {
        throw std::out_of_range("Tensor::flattenIndex - rank mismatch");
    }
    size_t idx = 0;
    for (size_t i = 0; i < indices.size(); ++i) {
        if (indices[i] < 0 || indices[i] >= shape_[i]) {
            throw std::out_of_range("Tensor::flattenIndex - index out of bounds");
        }
        idx += static_cast<size_t>(indices[i]) * static_cast<size_t>(strides_[i]);
    }
    return idx;
}

float& Tensor::at(const std::vector<int>& indices) {
    return data_[flattenIndex(indices)];
}

float Tensor::at(const std::vector<int>& indices) const {
    return data_[flattenIndex(indices)];
}

void Tensor::fill(float value) {
    for (auto& v : data_) v = value;
}

void Tensor::reshape(const std::vector<int>& newShape) {
    if (product(newShape) != data_.size()) {
        throw std::invalid_argument("Tensor::reshape - element count mismatch");
    }
    shape_ = newShape;
    computeStrides();
}

std::string Tensor::debugString(int maxElements) const {
    std::string s = "Tensor(shape=[";
    for (size_t i = 0; i < shape_.size(); ++i) {
        s += std::to_string(shape_[i]);
        if (i + 1 < shape_.size()) s += ",";
    }
    s += "], data=[";
    int n = static_cast<int>(std::min<size_t>(static_cast<size_t>(maxElements), data_.size()));
    for (int i = 0; i < n; ++i) {
        s += std::to_string(data_[i]);
        if (i + 1 < n) s += ",";
    }
    if (static_cast<size_t>(n) < data_.size()) s += ",...";
    s += "])";
    return s;
}

} // namespace novallm
