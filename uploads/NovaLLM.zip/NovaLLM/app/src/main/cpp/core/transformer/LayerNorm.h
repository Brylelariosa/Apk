#pragma once
#include "../math/Tensor.h"

namespace novallm {

// Normalizes each row (each token position) to zero mean / unit variance
// across the embedding dimension, then applies a learned per-dimension
// scale (gamma, init 1) and shift (beta, init 0).
class LayerNorm {
public:
    explicit LayerNorm(int dim, float eps = 1e-5f);

    // x: {seqLen, dim} -> {seqLen, dim}
    Tensor forward(const Tensor& x) const;

    int dim() const { return dim_; }
    Tensor& gamma() { return gamma_; }
    Tensor& beta() { return beta_; }

private:
    int dim_;
    float eps_;
    Tensor gamma_; // {dim}, initialized to 1
    Tensor beta_;  // {dim}, initialized to 0
};

} // namespace novallm
