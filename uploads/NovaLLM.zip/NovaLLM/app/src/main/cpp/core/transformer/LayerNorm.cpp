#include "LayerNorm.h"
#include <cmath>
#include <ostream>
#include <istream>

namespace novallm {

LayerNorm::LayerNorm(int dim, float eps)
    : dim_(dim), eps_(eps), gamma_({dim}, 1.0f), beta_({dim}, 0.0f) {}

Tensor LayerNorm::forward(const Tensor& x) const {
    int seqLen = x.dim(0);
    Tensor out({seqLen, dim_});

    for (int i = 0; i < seqLen; ++i) {
        const float* row = x.data() + static_cast<size_t>(i) * dim_;

        float mean = 0.0f;
        for (int j = 0; j < dim_; ++j) mean += row[j];
        mean /= static_cast<float>(dim_);

        float var = 0.0f;
        for (int j = 0; j < dim_; ++j) {
            float d = row[j] - mean;
            var += d * d;
        }
        var /= static_cast<float>(dim_);

        float invStd = 1.0f / std::sqrt(var + eps_);
        float* outRow = out.data() + static_cast<size_t>(i) * dim_;
        for (int j = 0; j < dim_; ++j) {
            float normed = (row[j] - mean) * invStd;
            outRow[j] = normed * gamma_.data()[j] + beta_.data()[j];
        }
    }
    return out;
}

void LayerNorm::save(std::ostream& out) const {
    gamma_.save(out);
    beta_.save(out);
}

void LayerNorm::load(std::istream& in) {
    gamma_.load(in);
    beta_.load(in);
    dim_ = gamma_.dim(0);
}

} // namespace novallm
