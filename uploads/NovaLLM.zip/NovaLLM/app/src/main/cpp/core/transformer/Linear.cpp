#include "Linear.h"
#include "../math/Matrix.h"
#include <random>
#include <ostream>
#include <istream>

namespace novallm {

Linear::Linear(int inDim, int outDim, unsigned int seed, bool useBias)
    : inDim_(inDim), outDim_(outDim), useBias_(useBias),
      weight_({inDim, outDim}), bias_({outDim}, 0.0f) {
    std::mt19937 rng(seed);
    std::normal_distribution<float> dist(0.0f, 0.02f); // GPT-2-style small init
    for (size_t i = 0; i < weight_.size(); ++i) {
        weight_.data()[i] = dist(rng);
    }
    // bias_ already zero-initialized via the fill-value constructor
}

Tensor Linear::forward(const Tensor& x) const {
    Tensor y = matrix::matmul(x, weight_);
    if (useBias_) {
        y = matrix::addBias(y, bias_);
    }
    return y;
}

void Linear::save(std::ostream& out) const {
    weight_.save(out);
    bias_.save(out);
    char useBiasFlag = useBias_ ? 1 : 0;
    out.write(&useBiasFlag, 1);
}

void Linear::load(std::istream& in) {
    weight_.load(in);
    bias_.load(in);
    char useBiasFlag = 0;
    in.read(&useBiasFlag, 1);
    useBias_ = (useBiasFlag != 0);
    inDim_ = weight_.dim(0);
    outDim_ = weight_.dim(1);
}

} // namespace novallm
