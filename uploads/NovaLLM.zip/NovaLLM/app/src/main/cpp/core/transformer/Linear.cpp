#include "Linear.h"
#include "../math/Matrix.h"
#include <random>

namespace novallm {

Linear::Linear(int inDim, int outDim, unsigned int seed, bool useBias)
    : inDim_(inDim), outDim_(outDim), useBias_(useBias),
      weight_({inDim, outDim}), bias_({outDim}, 0.0f) {
    std::mt19937 rng(seed);
    std::normal_distribution<float> dist(0.0f, 0.02f); // GPT-2-style small init
    for (size_t i = 0; i < weight_.size(); ++i) {
        weight_.data()[i] = dist(rng);
    }
    // bias_ already zero-initialized via the fill-value constructor
}

Tensor Linear::forward(const Tensor& x) const {
    Tensor y = matrix::matmul(x, weight_);
    if (useBias_) {
        y = matrix::addBias(y, bias_);
    }
    return y;
}

} // namespace novallm
