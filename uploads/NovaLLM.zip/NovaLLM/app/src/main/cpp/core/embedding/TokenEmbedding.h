#pragma once
#include <vector>
#include "../math/Tensor.h"

namespace novallm {

// Learned lookup table: token id -> embedding vector. Weight matrix is
// {vocabSize, embedDim}; row `id` is that token's embedding. Randomly
// initialized here (small Gaussian, GPT-2-style) - training (subsystem 7)
// is what actually shapes these into something meaningful.
class TokenEmbedding {
public:
    TokenEmbedding(int vocabSize, int embedDim, unsigned int seed = 42);

    // Single-token lookup: returns a copy of that row, shape {embedDim}.
    Tensor lookup(int tokenId) const;

    // Whole-sequence lookup: returns {seqLen, embedDim}.
    Tensor lookupSequence(const std::vector<int>& tokenIds) const;

    int vocabSize() const { return vocabSize_; }
    int embedDim() const { return embedDim_; }

    Tensor& weights() { return weights_; }
    const Tensor& weights() const { return weights_; }

private:
    int vocabSize_;
    int embedDim_;
    Tensor weights_; // {vocabSize, embedDim}
};

} // namespace novallm
