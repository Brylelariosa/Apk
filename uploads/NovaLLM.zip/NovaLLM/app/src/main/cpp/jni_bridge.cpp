// Thin JNI layer. Keep all real logic in core/ - this file should only ever
// marshal data in and out of the JVM boundary.
#include <jni.h>
#include <cmath>
#include <sstream>
#include "core/math/Tensor.h"
#include "core/math/Matrix.h"
#include "core/math/MemoryPool.h"

using namespace novallm;

extern "C" JNIEXPORT jstring JNICALL
Java_com_jarry_novallm_MainActivity_nativeRunMathCoreTest(JNIEnv* env, jobject /* this */) {
    std::ostringstream out;
    int failures = 0;

    // matmul: [1 2 3; 4 5 6] x [7 8; 9 10; 11 12] = [58 64; 139 154]
    Tensor a({2, 3});
    float av[] = {1, 2, 3, 4, 5, 6};
    for (int i = 0; i < 6; i++) a.data()[i] = av[i];

    Tensor b({3, 2});
    float bv[] = {7, 8, 9, 10, 11, 12};
    for (int i = 0; i < 6; i++) b.data()[i] = bv[i];

    Tensor c = matrix::matmul(a, b);
    float expected[] = {58, 64, 139, 154};
    bool matmulOk = true;
    for (int i = 0; i < 4; i++) {
        if (std::fabs(c.data()[i] - expected[i]) > 1e-4f) matmulOk = false;
    }
    out << "matmul(2x3, 3x2): " << (matmulOk ? "PASS" : "FAIL") << "\n";
    if (!matmulOk) failures++;

    // transpose
    Tensor t = matrix::transpose(a);
    bool transposeOk = (t.dim(0) == 3 && t.dim(1) == 2 &&
                         std::fabs(t.at({0, 0}) - 1.0f) < 1e-4f &&
                         std::fabs(t.at({2, 1}) - 6.0f) < 1e-4f);
    out << "transpose(2x3): " << (transposeOk ? "PASS" : "FAIL") << "\n";
    if (!transposeOk) failures++;

    // memory pool alloc/reset
    MemoryPool pool(4096);
    float* buf1 = pool.allocFloats(16);
    for (int i = 0; i < 16; i++) buf1[i] = 42.0f;
    size_t usedBefore = pool.used();
    pool.reset();
    bool poolOk = (usedBefore > 0) && (pool.used() == 0);
    out << "memory pool alloc/reset: " << (poolOk ? "PASS" : "FAIL") << "\n";
    if (!poolOk) failures++;

    out << "\n" << (failures == 0 ? "core/math: ALL PASS on-device" : "core/math: FAILURES");

    return env->NewStringUTF(out.str().c_str());
}
