// Thin JNI layer. Keep all real logic in core/ - this file should only ever
// marshal data in and out of the JVM boundary.
#include <jni.h>
#include <cmath>
#include <sstream>
#include <string>
#include <vector>
#include "core/math/Tensor.h"
#include "core/math/Matrix.h"
#include "core/math/MemoryPool.h"
#include "core/tokenizer/Tokenizer.h"
#include "core/embedding/TokenEmbedding.h"
#include "core/embedding/PositionalEncoding.h"

using namespace novallm;

extern "C" JNIEXPORT jstring JNICALL
Java_com_jarry_novallm_MainActivity_nativeRunMathCoreTest(JNIEnv* env, jobject /* this */) {
    std::ostringstream out;
    int failures = 0;

    // matmul: [1 2 3; 4 5 6] x [7 8; 9 10; 11 12] = [58 64; 139 154]
    Tensor a({2, 3});
    float av[] = {1, 2, 3, 4, 5, 6};
    for (int i = 0; i < 6; i++) a.data()[i] = av[i];

    Tensor b({3, 2});
    float bv[] = {7, 8, 9, 10, 11, 12};
    for (int i = 0; i < 6; i++) b.data()[i] = bv[i];

    Tensor c = matrix::matmul(a, b);
    float expected[] = {58, 64, 139, 154};
    bool matmulOk = true;
    for (int i = 0; i < 4; i++) {
        if (std::fabs(c.data()[i] - expected[i]) > 1e-4f) matmulOk = false;
    }
    out << "matmul(2x3, 3x2): " << (matmulOk ? "PASS" : "FAIL") << "\n";
    if (!matmulOk) failures++;

    // transpose
    Tensor t = matrix::transpose(a);
    bool transposeOk = (t.dim(0) == 3 && t.dim(1) == 2 &&
                         std::fabs(t.at({0, 0}) - 1.0f) < 1e-4f &&
                         std::fabs(t.at({2, 1}) - 6.0f) < 1e-4f);
    out << "transpose(2x3): " << (transposeOk ? "PASS" : "FAIL") << "\n";
    if (!transposeOk) failures++;

    // memory pool alloc/reset
    MemoryPool pool(4096);
    float* buf1 = pool.allocFloats(16);
    for (int i = 0; i < 16; i++) buf1[i] = 42.0f;
    size_t usedBefore = pool.used();
    pool.reset();
    bool poolOk = (usedBefore > 0) && (pool.used() == 0);
    out << "memory pool alloc/reset: " << (poolOk ? "PASS" : "FAIL") << "\n";
    if (!poolOk) failures++;

    out << "\n" << (failures == 0 ? "core/math: ALL PASS on-device" : "core/math: FAILURES");

    return env->NewStringUTF(out.str().c_str());
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_jarry_novallm_MainActivity_nativeRunTokenizerTest(JNIEnv* env, jobject /* this */) {
    std::ostringstream out;
    int failures = 0;

    Tokenizer tok;
    std::vector<std::string> corpus = {
        "the quick brown fox jumps over the lazy dog",
        "the quick brown fox runs past the lazy dog",
        "a quick fox and a lazy dog",
        "the dog barks at the quick fox"
    };
    tok.train(corpus, 40);

    std::string testStr = "the quick brown fox jumps over the lazy dog";
    std::vector<int> ids = tok.encode(testStr);
    std::string decoded = tok.decode(ids);
    bool roundtripOk = (decoded == testStr);
    out << "roundtrip: " << (roundtripOk ? "PASS" : "FAIL") << "\n";
    if (!roundtripOk) failures++;

    // Text never seen during training must still round-trip exactly,
    // via raw byte tokens - that's the whole point of byte-level BPE.
    std::string unseen = "zzqx this text was never in training!";
    std::vector<int> unseenIds = tok.encode(unseen);
    std::string unseenDecoded = tok.decode(unseenIds);
    bool unseenOk = (unseenDecoded == unseen);
    out << "unseen-text roundtrip: " << (unseenOk ? "PASS" : "FAIL") << "\n";
    if (!unseenOk) failures++;

    double ratio = static_cast<double>(testStr.size()) / static_cast<double>(ids.size());
    out << "vocab size: " << tok.vocabSize() << " (256 base + " << tok.mergeCount() << " merges)\n";
    out << "compression: " << testStr.size() << " bytes -> " << ids.size() << " tokens ("
        << ratio << "x)\n";

    out << "\n" << (failures == 0 ? "core/tokenizer: ALL PASS on-device" : "core/tokenizer: FAILURES");

    return env->NewStringUTF(out.str().c_str());
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_jarry_novallm_MainActivity_nativeRunEmbeddingTest(JNIEnv* env, jobject /* this */) {
    std::ostringstream out;
    int failures = 0;

    // Chains the real pipeline so far: text -> trained tokenizer -> token
    // ids -> embeddings -> + positional encoding.
    Tokenizer tok;
    std::vector<std::string> corpus = {
        "the quick brown fox jumps over the lazy dog",
        "the quick brown fox runs past the lazy dog"
    };
    tok.train(corpus, 30);

    std::string testStr = "the quick fox";
    std::vector<int> ids = tok.encode(testStr);

    const int embedDim = 16;
    TokenEmbedding emb(static_cast<int>(tok.vocabSize()), embedDim);
    PositionalEncoding pe(64, embedDim);

    Tensor tokenEmb = emb.lookupSequence(ids);
    bool shapeOk = (tokenEmb.dim(0) == static_cast<int>(ids.size()) && tokenEmb.dim(1) == embedDim);
    out << "embedding shape {" << ids.size() << "," << embedDim << "}: " << (shapeOk ? "PASS" : "FAIL") << "\n";
    if (!shapeOk) failures++;

    Tensor combined = pe.applyTo(tokenEmb);
    Tensor posTable = pe.encode(static_cast<int>(ids.size()));
    bool addOk = true;
    for (size_t k = 0; k < combined.size(); ++k) {
        float expected = tokenEmb.data()[k] + posTable.data()[k];
        if (std::fabs(combined.data()[k] - expected) > 1e-4f) addOk = false;
    }
    out << "embedding + positional encoding: " << (addOk ? "PASS" : "FAIL") << "\n";
    if (!addOk) failures++;

    out << "tokens: " << ids.size() << ", embedDim: " << embedDim
        << ", vocab: " << tok.vocabSize() << "\n";

    out << "\n" << (failures == 0 ? "core/embedding: ALL PASS on-device" : "core/embedding: FAILURES");

    return env->NewStringUTF(out.str().c_str());
}
