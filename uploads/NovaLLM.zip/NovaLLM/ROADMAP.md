# NovaLLM build order

Custom text-only LLM for Android. No TensorFlow, no ONNX, no third-party ML
framework — every piece below is hand-written C++, compiled via NDK, called
through a thin JNI bridge. Built one subsystem at a time, verified on-device
before moving to the next.

Name/package (`com.jarry.novallm`) is a placeholder — rename `applicationId`/
`namespace` in `app/build.gradle` and the `com/jarry/novallm` folder anytime.

## Status

- [x] **1. core/math** — Tensor, Matrix (matmul/add/transpose/addBias/scale), MemoryPool.
      Naive O(n^3) matmul, correctness-first. Verified with a standalone g++
      test suite (`tests/test_math.cpp`) AND on-device via the JNI test button
      in the shipped APK.
- [x] **2. core/tokenizer** — UTF8 (decode/validate), Vocabulary (256 base
      byte tokens + growable), BPE (train + greedy lowest-rank encode),
      Tokenizer facade (train/encode/decode/save/load). Byte-level, so
      there is no "unknown token" case - anything not covered by a learned
      merge just stays as raw byte tokens and still round-trips exactly.
      No pretokenization step yet (whole byte stream is one BPE sequence,
      not pre-split on whitespace) - simpler and still fully correct, just
      leaves some compression quality on the table; worth revisiting once
      the rest of the pipeline exists to actually benefit from it.
      Verified with a standalone g++ test suite (`tests/test_tokenizer.cpp`,
      24 checks) AND on-device via a second JNI test button.
- [x] **3. core/embedding** — TokenEmbedding (learned {vocabSize, embedDim}
      lookup table, GPT-2-style small Gaussian init, single + sequence
      lookup) and PositionalEncoding (fixed sinusoidal table, `applyTo()`
      adds it to embeddings). RoPE is intentionally NOT here - it rotates
      Q/K vectors inside attention, so it belongs in core/transformer once
      attention exists, not at the embedding stage. Verified with a
      standalone g++ suite (`tests/test_embedding.cpp`, 33 checks) AND
      on-device via a third JNI button that chains the real pipeline:
      text -> trained tokenizer -> ids -> embeddings -> +positional encoding.
- [x] **4. core/transformer** — Linear (shared weight+bias layer),
      LayerNorm, FeedForward (GELU, tanh approximation), MultiHeadAttention
      (causal, scaled dot-product, head split/merge via new
      `matrix::sliceColumns`/`setColumns`), TransformerBlock (pre-norm:
      x -> LN -> Attn -> +x -> LN -> FFN -> +). Residual connections are
      just `matrix::add()` calls, not a separate class - no Residual.cpp on
      purpose. KVCache is deferred to core/runtime (subsystem 6) since it's
      a generation-loop optimization, not a correctness requirement for a
      single forward pass.
      Verified with a standalone g++ suite (`tests/test_transformer.cpp`,
      19 checks) that includes the single most important correctness test
      in the project so far: changing only the LAST token in a sequence
      must leave every earlier position's output byte-for-byte identical.
      That held both at the raw attention level and end-to-end through the
      full block. Also verified by actually *executing* jni_bridge.cpp's
      real exported functions locally against a stubbed JNI env (not just
      compiling them) before this ever reached device, and on-device via a
      fourth JNI button running the same causal-leakage check with real
      random weights.
- [x] **5. core/decoder** — Model (stacks TokenEmbedding + N TransformerBlocks
      + final LayerNorm + LM head into one forward pass; "Logits" is just
      its {seqLen, vocabSize} output shape, not a separate class), Sampling
      (temperature -> softmax -> top-k -> top-p -> renormalize -> sample;
      temperature=0 is deterministic greedy argmax), Generator (the actual
      autoregressive loop: encode prompt, repeatedly forward+sample+append,
      decode). No KV cache yet (subsystem 6) - every new token recomputes
      the whole forward pass, correct but O(n^2). Text generation is now
      real and running end to end, but weights are untrained (random), so
      output is structurally correct gibberish until subsystem 7 exists -
      that's expected, not a bug.
      One real hazard caught here: sampling can select ANY byte-level
      token, so generated text can contain embedded nulls / invalid UTF-8.
      Handing that straight to JNI's `NewStringUTF` was unsafe (silent
      truncation at minimum, undefined behavior at worst) - added
      `escapeForDisplay()` in jni_bridge.cpp so raw bytes are always shown
      safely (confirmed necessary: the on-device run's output did contain
      non-printable bytes).
      Verified with a standalone g++ suite (`tests/test_decoder.cpp`, 8
      checks - including re-proving causality at the full multi-layer
      model level, greedy determinism, top-k/top-p edge behavior, and an
      empirical sampling-distribution check against known softmax
      probabilities) AND by actually executing all five JNI functions
      locally against the stub before this ever reached device.
- [ ] 6. **runtime** — model loading/saving (custom binary format), KV cache for fast generation
- [ ] 7. **training** — dataset loader, loss (cross-entropy), backprop, optimizer (start with plain SGD or Adam), checkpointing
- [ ] 8. **Android optimization pass** — quantization (int8), NEON SIMD, thread pool, memory pool wiring throughout

Items 2-6 get you a *working inference engine* that can run a model whose
weights come from somewhere else. Item 7 is what makes training actually
happen on-device — that's real but toy-scale only (small vocab, small
context, small param count); do not expect chat-quality output from
on-device training alone.

## Why matmul is naive right now

Correctness has to be provable before it's optimized. The i-p-j loop order
in `matrix::matmul` is cache-friendlier than the textbook i-j-p order and
skips zero entries in A, but it's still O(n^3) with no SIMD. NEON
intrinsics land in step 8, once every subsystem that depends on matmul
being *correct* already exists and can catch a regression.

## Testing loop

Two independent checks exist on purpose:

1. `tests/test_math.cpp` — compiles standalone with clang/g++ in Termux,
   no Android toolchain needed. Fastest iteration loop for pure logic bugs.
2. The JNI test button in the app — proves the same code actually builds
   and runs correctly through NDK/JNI on your Infinix Hot 11, which is a
   different (and historically more failure-prone, per the mgba JNI work)
   code path than plain Linux compilation.

## One CI gotcha worth fixing

Your `Build APK` workflow's C++ build cache is keyed on:

```
hashFiles('**/CMakeLists.txt', '**/core/*.cpp', '**/core/*.h', '**/jni_bridge.cpp')
```

`**/core/*.cpp` only matches files directly inside a `core/` folder, not
nested ones. This project's C++ lives in `core/math/*.cpp` (and will grow
into `core/tokenizer/`, `core/transformer/`, etc.) — one level deeper than
the glob reaches. That means edits to files under `core/math/` won't change
the cache key, so CI can restore a stale `.cxx` build cache instead of
picking up your change. Worth changing that line to:

```
hashFiles('**/CMakeLists.txt', '**/core/**/*.cpp', '**/core/**/*.h', '**/jni_bridge.cpp')
```

so nested subsystem folders actually invalidate the cache.
