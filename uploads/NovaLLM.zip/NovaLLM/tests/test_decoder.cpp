// Standalone correctness tests for core/decoder. No Android/JNI needed.
//
// Termux:
//   clang++ -std=c++17 -I../app/src/main/cpp \
//     test_decoder.cpp \
//     ../app/src/main/cpp/core/math/Tensor.cpp \
//     ../app/src/main/cpp/core/math/Matrix.cpp \
//     ../app/src/main/cpp/core/tokenizer/*.cpp \
//     ../app/src/main/cpp/core/embedding/*.cpp \
//     ../app/src/main/cpp/core/transformer/*.cpp \
//     ../app/src/main/cpp/core/decoder/*.cpp \
//     -o test_decoder && ./test_decoder
#include <cstdio>
#include <cmath>
#include <vector>
#include <string>
#include "core/decoder/Model.h"
#include "core/decoder/Sampling.h"
#include "core/decoder/Generator.h"
#include "core/tokenizer/Tokenizer.h"

using namespace novallm;

static int g_failures = 0;

void expectTrue(bool cond, const char* what) {
    if (!cond) { std::printf("FAIL  %s\n", what); g_failures++; }
    else { std::printf("pass  %s\n", what); }
}

Model::Config smallConfig(int vocabSize) {
    Model::Config cfg;
    cfg.vocabSize = vocabSize;
    cfg.embedDim = 16;
    cfg.numLayers = 2;
    cfg.numHeads = 4;
    cfg.ffnHiddenDim = 64;
    cfg.maxSeqLen = 64;
    return cfg;
}

void testModelOutputShape() {
    Model model(smallConfig(300), /*seed=*/1);
    std::vector<int> ids = {5, 10, 15, 20};
    Tensor logits = model.forward(ids);
    expectTrue(logits.dim(0) == 4 && logits.dim(1) == 300, "Model: logits shape {seqLen, vocabSize}");
}

// Re-verify causality at the FULL multi-layer model level (stacked blocks
// + final norm + LM head) - stacking could in principle introduce a leak
// even though each individual block is causal, so this is worth re-proving
// here rather than assuming composition is automatically safe.
void testModelCausality() {
    Model model(smallConfig(300), /*seed=*/1);
    std::vector<int> idsA = {5, 10, 15, 20, 25};
    std::vector<int> idsB = {5, 10, 15, 20, 99};

    Tensor logitsA = model.forward(idsA);
    Tensor logitsB = model.forward(idsB);

    bool identical = true;
    for (int i = 0; i < 4 && identical; ++i) {
        for (int v = 0; v < 300; ++v) {
            if (std::fabs(logitsA.at({i, v}) - logitsB.at({i, v})) > 1e-4f) { identical = false; break; }
        }
    }
    expectTrue(identical, "Model: causal mask holds through the full multi-layer stack");
}

void testGreedyIsDeterministic() {
    std::vector<float> logits = {1.0f, 5.0f, 2.0f, -3.0f, 0.5f};
    Sampler::Params greedy;
    greedy.temperature = 0.0f;

    Sampler s1(1);
    Sampler s2(999); // different seed must not matter for greedy
    int a = s1.sample(logits, greedy);
    int b = s2.sample(logits, greedy);
    expectTrue(a == 1 && b == 1, "Sampler: greedy always picks the argmax regardless of seed");
}

void testTopKOneMatchesGreedy() {
    std::vector<float> logits = {1.0f, 5.0f, 2.0f, -3.0f, 0.5f};
    Sampler::Params params;
    params.temperature = 1.0f;
    params.topK = 1;
    Sampler s(42);
    for (int i = 0; i < 10; ++i) {
        int picked = s.sample(logits, params);
        if (picked != 1) { expectTrue(false, "Sampler: topK=1 always returns the single highest-logit token"); return; }
    }
    expectTrue(true, "Sampler: topK=1 always returns the single highest-logit token");
}

void testTopPNearZeroMatchesArgmax() {
    std::vector<float> logits = {1.0f, 5.0f, 2.0f, -3.0f, 0.5f};
    Sampler::Params params;
    params.temperature = 1.0f;
    params.topP = 0.0001f; // nucleus should collapse to just the top token
    Sampler s(7);
    for (int i = 0; i < 10; ++i) {
        int picked = s.sample(logits, params);
        if (picked != 1) { expectTrue(false, "Sampler: topP near 0 collapses to the argmax token"); return; }
    }
    expectTrue(true, "Sampler: topP near 0 collapses to the argmax token");
}

void testSamplingDistributionRoughlyMatchesSoftmax() {
    // logits = [0, ln3] -> softmax = [0.25, 0.75]. Sample many times and
    // check the empirical split is in the right neighborhood (std dev of
    // Binomial(4000, 0.75) ~= 27, so +-150 is a very safe, non-flaky margin).
    std::vector<float> logits = {0.0f, std::log(3.0f)};
    Sampler::Params params; // temperature=1, no top-k/top-p
    Sampler s(123);
    int count1 = 0;
    const int trials = 4000;
    for (int i = 0; i < trials; ++i) {
        if (s.sample(logits, params) == 1) count1++;
    }
    bool inRange = (count1 > 2850 && count1 < 3150); // expected ~3000
    expectTrue(inRange, "Sampler: empirical distribution roughly matches softmax probabilities");
}

void testGeneratorRunsAndIsDeterministicWhenGreedy() {
    Tokenizer tok;
    std::vector<std::string> corpus = {
        "the quick brown fox jumps over the lazy dog",
        "the quick brown fox runs past the lazy dog"
    };
    tok.train(corpus, 30);
    tok.addSpecialToken("eos", "<eos>");

    Model model(smallConfig(static_cast<int>(tok.vocabSize())), /*seed=*/55);

    Generator::GenerationParams params;
    params.maxNewTokens = 8;
    params.sampling.temperature = 0.0f; // greedy - must be fully reproducible

    Generator gen1(model, tok, /*samplerSeed=*/1);
    Generator gen2(model, tok, /*samplerSeed=*/2); // seed shouldn't matter under greedy
    std::string out1 = gen1.generate("the quick", params);
    std::string out2 = gen2.generate("the quick", params);

    expectTrue(out1 == out2, "Generator: greedy generation is fully deterministic regardless of sampler seed");
    expectTrue(!out1.empty(), "Generator: produces non-empty output for maxNewTokens > 0");
}

int main() {
    testModelOutputShape();
    testModelCausality();
    testGreedyIsDeterministic();
    testTopKOneMatchesGreedy();
    testTopPNearZeroMatchesArgmax();
    testSamplingDistributionRoughlyMatchesSoftmax();
    testGeneratorRunsAndIsDeterministicWhenGreedy();

    std::printf("\n%s (%d failures)\n", g_failures == 0 ? "ALL PASS" : "FAILURES", g_failures);
    return g_failures == 0 ? 0 : 1;
}
