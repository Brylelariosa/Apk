package com.bru.gameboost.data.cpu

import com.bru.gameboost.domain.model.CpuLoad

/**
 * One way of measuring system-wide CPU load without root. Sources are stateful — delta-based ones
 * remember their previous sample — so every stats collection gets its own set (see
 * [CpuLoadMonitor.default]); never share an instance between collectors.
 */
interface CpuLoadSource {

    /** Short label shown in the on-screen diagnostic when this source can't be used. */
    val name: String

    /**
     * Takes one reading. The result is:
     *  - a [CpuLoad.Reading] when a figure is ready;
     *  - [CpuLoad.Unavailable] when this source can't work on this device at all, so the caller
     *    should stop asking it;
     *  - null when there's nothing yet: a delta-based source's first (baseline) read, or a one-off
     *    bad read. Ask again on the next tick.
     */
    fun read(): CpuLoad?
}
