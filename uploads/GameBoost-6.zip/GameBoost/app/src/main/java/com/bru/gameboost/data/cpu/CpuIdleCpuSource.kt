package com.bru.gameboost.data.cpu

import com.bru.gameboost.domain.model.CpuLoad
import java.io.File

/**
 * Real utilisation without /proc/stat: the kernel's cpuidle counters record how long each core has
 * spent idle, and those nodes are world-readable. Busy share over an interval is
 * `1 − idleTimeDelta / wallClockDelta`, averaged across the cores that stayed online.
 */
class CpuIdleCpuSource(
    private val cpuRoot: File = CpuSysfs.ROOT,
    private val nanoClock: () -> Long = System::nanoTime
) : CpuLoadSource {

    override val name = "cpuidle"

    private val cores by lazy(LazyThreadSafetyMode.NONE) { CpuSysfs.coreIndices(cpuRoot) }

    private var previousIdleMicros: LongArray? = null
    private var previousNanos = 0L
    private var hasSeenCounters = false

    override fun read(): CpuLoad? {
        val nowNanos = nanoClock()
        val idleMicros = LongArray(cores.size) { idleResidencyMicros(cores[it]) }
        val before = previousIdleMicros
        val beforeNanos = previousNanos
        previousIdleMicros = idleMicros
        previousNanos = nowNanos

        if (idleMicros.all { it == NOT_AVAILABLE }) {
            return if (hasSeenCounters) null else CpuLoad.Unavailable("not exposed")
        }
        hasSeenCounters = true
        if (before == null) return null // first read: baseline only

        val wallMicros = (nowNanos - beforeNanos) / NANOS_PER_MICRO
        if (wallMicros <= 0) return null

        var busySum = 0.0
        var counted = 0
        var idleAdvanced = false
        for (i in idleMicros.indices) {
            // A core that was offline at either end of the interval has no meaningful delta.
            if (idleMicros[i] == NOT_AVAILABLE || before[i] == NOT_AVAILABLE) continue
            val idleDelta = idleMicros[i] - before[i]
            if (idleDelta < 0) continue // counter went backwards: core was re-plugged mid-interval
            if (idleDelta > 0) idleAdvanced = true
            busySum += 1.0 - (idleDelta.toDouble() / wallMicros).coerceAtMost(1.0)
            counted++
        }
        // Not one core logged a microsecond of idle time. A counter that isn't live would read as a
        // CPU pinned at 100% forever, so report "no data" rather than that.
        if (counted == 0 || !idleAdvanced) return null
        return CpuLoad.Measured((busySum / counted * 100.0).toFloat().coerceIn(0f, 100f))
    }

    /** Total µs this core has spent in any idle state, or [NOT_AVAILABLE] if it's offline or has no cpuidle node. */
    private fun idleResidencyMicros(core: Int): Long {
        var total = 0L
        var state = 0
        while (state < MAX_IDLE_STATES) {
            val micros = File(cpuRoot, "cpu$core/cpuidle/state$state/time").readLongOrNull() ?: break
            total += micros
            state++
        }
        return if (state == 0) NOT_AVAILABLE else total
    }

    private companion object {
        const val NOT_AVAILABLE = -1L
        const val MAX_IDLE_STATES = 16
        const val NANOS_PER_MICRO = 1_000L
    }
}
