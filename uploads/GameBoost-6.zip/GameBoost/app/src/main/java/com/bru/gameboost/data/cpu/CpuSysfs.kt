package com.bru.gameboost.data.cpu

import java.io.File
import java.io.FileInputStream
import java.io.IOException

/** Shared plumbing for the sources that read per-core kernel files under /sys/devices/system/cpu. */
internal object CpuSysfs {

    val ROOT = File("/sys/devices/system/cpu")

    private val CORE_DIR = Regex("cpu(\\d+)")

    /**
     * Indices of every core the kernel knows about, offline ones included — a core that's parked
     * right now may be running at the next tick. Falls back to a plain count if the directory
     * can't be listed.
     */
    fun coreIndices(root: File = ROOT): List<Int> {
        val listed = root.list()
            ?.mapNotNull { CORE_DIR.matchEntire(it)?.groupValues?.get(1)?.toIntOrNull() }
            ?.sorted()
        return if (!listed.isNullOrEmpty()) {
            listed
        } else {
            (0 until Runtime.getRuntime().availableProcessors()).toList()
        }
    }
}

/**
 * Leading integer of a small kernel text file ("1704000\n"), or null if the file is missing,
 * unreadable, or doesn't start with a number. Reads into a tiny buffer instead of going through a
 * Reader: these files are polled every few seconds, once per core.
 */
internal fun File.readLongOrNull(): Long? {
    val buffer = ByteArray(MAX_NUMBER_BYTES)
    val length = try {
        FileInputStream(this).use { it.read(buffer) }
    } catch (e: IOException) {
        return null
    } catch (e: SecurityException) {
        return null
    }
    var value = 0L
    var digits = 0
    for (i in 0 until length) { // an empty file gives length -1, so the range is empty
        val c = buffer[i].toInt()
        if (c < '0'.code || c > '9'.code) break
        value = value * 10 + (c - '0'.code)
        digits++
    }
    return if (digits > 0) value else null
}

private const val MAX_NUMBER_BYTES = 32
