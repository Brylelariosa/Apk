package com.bru.gameboost.presentation

import com.bru.gameboost.domain.model.CleanResult
import com.bru.gameboost.domain.model.CpuLoad
import com.bru.gameboost.domain.model.DeviceSnapshot
import com.bru.gameboost.domain.model.ThermalStatus
import java.util.Locale
import kotlin.math.roundToInt

/** The one place snapshots become text, so the notification and the screens never disagree. */
object SnapshotFormatter {

    /** Notification body: stats on the first line, then what the RAM clean freed (if one ran). */
    fun notificationText(snapshot: DeviceSnapshot?, cleanResult: CleanResult?): String {
        val stats = if (snapshot == null) {
            "Starting up…"
        } else {
            listOfNotNull(
                "CPU ${cpu(snapshot)}",
                "RAM ${ram(snapshot)}",
                snapshot.batteryTempC?.let { temperature(it) },
                "Batt ${battery(snapshot)}",
                throttling(snapshot)
            ).joinToString(" · ")
        }
        return if (cleanResult == null) stats else "$stats\n${cleanSummary(cleanResult)}"
    }

    fun cleanSummary(result: CleanResult): String =
        if (result.freedMb > 0) {
            "Freed ≈ ${result.freedMb} MB · ${result.appsChecked} apps checked"
        } else {
            "Nothing left to free · ${result.appsChecked} apps checked"
        }

    /** Short form for the boost checklist, where the app count is noise. */
    fun freedShort(result: CleanResult): String =
        if (result.freedMb > 0) "Freed ≈ ${result.freedMb} MB" else "RAM already clean"

    fun temperature(tempC: Float): String = String.format(Locale.getDefault(), "%.1f°C", tempC)

    fun cpu(snapshot: DeviceSnapshot): String = when (val load = snapshot.cpuLoad) {
        is CpuLoad.Measured -> "${load.percent.roundToInt()}%"
        // Inferred from clock speeds, not true utilisation — the "~" keeps it honest.
        is CpuLoad.Estimated -> "~${load.percent.roundToInt()}%"
        else -> "—"
    }

    /** Why the CPU meter is empty, or null when it isn't (or the first reading is still on its way). */
    fun cpuUnavailableNote(snapshot: DeviceSnapshot): String? =
        (snapshot.cpuLoad as? CpuLoad.Unavailable)?.let { "CPU load isn't readable on this device (${it.reason})" }

    fun ram(snapshot: DeviceSnapshot): String {
        val used = snapshot.ramUsedMb
        val total = snapshot.ramTotalMb
        return if (used != null && total != null) "${gigabytes(used)}/${gigabytes(total)} GB" else "—"
    }

    fun battery(snapshot: DeviceSnapshot): String {
        val percent = snapshot.batteryPercent?.let { "$it%" } ?: "—"
        return if (snapshot.isCharging == true) "$percent (charging)" else percent
    }

    /** Only worth a mention once the platform itself reports throttling; null otherwise. */
    fun throttling(snapshot: DeviceSnapshot): String? {
        val status = snapshot.thermalStatus ?: return null
        if (status == ThermalStatus.NONE || status == ThermalStatus.UNKNOWN) return null
        return "Thermal ${status.name.lowercase()}"
    }

    private fun gigabytes(mb: Long): String = String.format(Locale.getDefault(), "%.1f", mb / 1024.0)
}
