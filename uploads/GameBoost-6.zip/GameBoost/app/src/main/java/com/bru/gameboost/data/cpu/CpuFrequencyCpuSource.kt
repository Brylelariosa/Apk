package com.bru.gameboost.data.cpu

import com.bru.gameboost.domain.model.CpuLoad
import java.io.File

/**
 * Last resort, for devices that expose neither /proc/stat nor cpuidle counters: estimates load from
 * how far up its allowed clock range each core is running. The governor ramps clocks as cores get
 * busy, so this tracks load — but it is an inference, hence [CpuLoad.Estimated]. Needs no baseline,
 * so it answers on the very first call.
 */
class CpuFrequencyCpuSource(
    cpuRoot: File = CpuSysfs.ROOT
) : CpuLoadSource {

    override val name = "cpufreq"

    private class CoreFiles(cpufreqDir: File) {
        val current = File(cpufreqDir, "scaling_cur_freq")
        val currentMax = File(cpufreqDir, "scaling_max_freq")
        val currentMin = File(cpufreqDir, "scaling_min_freq")
        val hardwareMax = File(cpufreqDir, "cpuinfo_max_freq")
        val hardwareMin = File(cpufreqDir, "cpuinfo_min_freq")
    }

    private val cores by lazy(LazyThreadSafetyMode.NONE) {
        CpuSysfs.coreIndices(cpuRoot).map { CoreFiles(File(cpuRoot, "cpu$it/cpufreq")) }
    }

    private var hasRead = false

    override fun read(): CpuLoad? {
        var fractionSum = 0.0
        var counted = 0
        for (core in cores) {
            fractionSum += loadFraction(core) ?: continue
            counted++
        }
        if (counted == 0) {
            return if (hasRead) null else CpuLoad.Unavailable("not readable")
        }
        hasRead = true
        return CpuLoad.Estimated((fractionSum / counted * 100.0).toFloat())
    }

    /**
     * How far up its allowed clock range this core is running, 0..1; null for an offline or
     * unreadable core. The ceiling is the *current* cap, so a thermally throttled core flat out at
     * its reduced maximum still counts as fully loaded.
     */
    private fun loadFraction(core: CoreFiles): Double? {
        val current = core.current.readLongOrNull() ?: return null
        val ceiling = core.currentMax.readLongOrNull() ?: core.hardwareMax.readLongOrNull() ?: return null
        val floor = core.hardwareMin.readLongOrNull() ?: core.currentMin.readLongOrNull() ?: 0L
        if (ceiling <= floor) return null
        return ((current - floor).toDouble() / (ceiling - floor)).coerceIn(0.0, 1.0)
    }
}
