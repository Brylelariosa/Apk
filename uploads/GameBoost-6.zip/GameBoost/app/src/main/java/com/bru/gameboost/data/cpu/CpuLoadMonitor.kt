package com.bru.gameboost.data.cpu

import com.bru.gameboost.domain.model.CpuLoad

/**
 * Picks the best CPU-load source this device allows. Sources are tried in order of accuracy; one
 * that proves unusable — or stays silent for too many ticks — is dropped for the rest of this
 * monitor's life and the next takes over. Not thread-safe: one collector drives one monitor.
 */
class CpuLoadMonitor(private val sources: List<CpuLoadSource>) {

    private var active = 0
    private var quietTicks = 0
    private val dropped = ArrayList<String>()

    /**
     * One tick. Returns a [CpuLoad.Reading] when a figure is ready, null while the active source is
     * still taking its baseline, or [CpuLoad.Unavailable] once every source has been ruled out.
     */
    fun sample(): CpuLoad? {
        while (active < sources.size) {
            val source = sources[active]
            when (val reading = source.read()) {
                is CpuLoad.Reading -> {
                    quietTicks = 0
                    return reading
                }
                is CpuLoad.Unavailable -> drop(source, reading.reason)
                null -> {
                    quietTicks++
                    if (quietTicks < MAX_QUIET_TICKS) return null
                    // Silent for the baseline plus several tries: a stuck counter, not a slow start.
                    drop(source, "no usable reading")
                }
            }
        }
        return CpuLoad.Unavailable(dropped.joinToString(" · "))
    }

    private fun drop(source: CpuLoadSource, reason: String) {
        dropped.add("${source.name}: $reason")
        active++
        quietTicks = 0
    }

    companion object {
        private const val MAX_QUIET_TICKS = 4

        /** Fresh sources, most accurate first: exact counters, then idle-time residency, then clock speeds. */
        fun default(): CpuLoadMonitor = CpuLoadMonitor(
            listOf(ProcStatCpuSource(), CpuIdleCpuSource(), CpuFrequencyCpuSource())
        )
    }
}
