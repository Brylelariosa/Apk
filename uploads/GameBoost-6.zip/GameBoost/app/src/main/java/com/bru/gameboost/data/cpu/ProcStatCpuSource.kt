package com.bru.gameboost.data.cpu

import com.bru.gameboost.domain.model.CpuLoad
import java.io.File
import java.io.IOException

/**
 * Exact system-wide utilisation from /proc/stat deltas. Android 8+ denies apps that file, so on most
 * current devices this reports itself unavailable and the monitor moves on. It stays first in line
 * because wherever it does work (older or looser ROMs) it's the best figure there is.
 */
class ProcStatCpuSource(
    private val statFile: File = File("/proc/stat")
) : CpuLoadSource {

    override val name = "proc/stat"

    private var previous: CpuTimes? = null
    private var hasRead = false
    private var failure = "unreadable"

    override fun read(): CpuLoad? {
        val current = readTimes()
        val before = previous
        previous = current

        if (current == null) {
            // Never worked: structural, give up. Worked before: a one-off glitch, try again.
            return if (hasRead) null else CpuLoad.Unavailable(failure)
        }
        hasRead = true
        if (before == null) return null // first read: baseline only

        val totalDelta = current.total - before.total
        if (totalDelta <= 0) return null
        val busyDelta = totalDelta - (current.idle - before.idle)
        return CpuLoad.Measured((busyDelta.toFloat() / totalDelta * 100f).coerceIn(0f, 100f))
    }

    private fun readTimes(): CpuTimes? = try {
        // use{} closes the stream; without it every poll leaves a file descriptor for the GC to reap.
        val line = statFile.bufferedReader().use { it.readLine() }
        parseAggregateLine(line) ?: run {
            failure = "unexpected format"
            null
        }
    } catch (e: IOException) {
        failure = if (e.message.orEmpty().contains("denied", ignoreCase = true)) "denied" else "unreadable"
        null
    } catch (e: SecurityException) {
        failure = "denied"
        null
    }

    /**
     * "cpu  user nice system idle iowait irq softirq steal guest guest_nice". Guest time is already
     * counted inside user/nice, so only the first eight counters go into the total.
     */
    private fun parseAggregateLine(line: String?): CpuTimes? {
        val fields = line?.trim()?.split(WHITESPACE) ?: return null
        if (fields.firstOrNull() != "cpu") return null
        val counters = fields.drop(1).take(SUMMED_COUNTERS).map { it.toLongOrNull() ?: return null }
        if (counters.size < MIN_COUNTERS) return null
        val idle = counters[3] + counters.getOrElse(4) { 0L } // idle + iowait
        return CpuTimes(total = counters.sum(), idle = idle)
    }

    private class CpuTimes(val total: Long, val idle: Long)

    private companion object {
        val WHITESPACE = Regex("\\s+") // built once, not on every poll
        const val SUMMED_COUNTERS = 8
        const val MIN_COUNTERS = 4 // user, nice, system, idle
    }
}
