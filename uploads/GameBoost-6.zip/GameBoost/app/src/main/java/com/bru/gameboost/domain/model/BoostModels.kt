package com.bru.gameboost.domain.model

/** An installed, launchable app the user has added to their boost list. */
data class BoostableGame(
    val packageName: String,
    val label: String
)

/**
 * PowerManager's thermal levels (API 29+), mirrored here so the domain layer
 * doesn't leak a platform enum. UNKNOWN covers API < 29 or a failed read —
 * callers should hide the thermal row rather than show a false reading.
 */
enum class ThermalStatus {
    NONE, LIGHT, MODERATE, SEVERE, CRITICAL, EMERGENCY, SHUTDOWN, UNKNOWN;

    /** True once the platform itself reports throttling heavy enough to cost frame rate. */
    val isSevere: Boolean get() = this in SEVERE..SHUTDOWN
}

/**
 * One tick of device stats. Every field is nullable and independently
 * optional — a read that fails (or isn't available on this API level)
 * degrades that one field rather than the whole snapshot.
 *
 * [cpuLoad] is null only while the first reading is still on its way; after
 * that it's a [CpuLoad] saying how good the figure is, or why there isn't one.
 *
 * [batteryTempC] is the dependable heat signal: not every vendor feeds
 * PowerManager's thermal status, while the battery sensor is always there.
 */
data class DeviceSnapshot(
    val cpuLoad: CpuLoad?,
    val ramUsedMb: Long?,
    val ramTotalMb: Long?,
    val batteryPercent: Int?,
    val batteryTempC: Float?,
    val isCharging: Boolean?,
    val thermalStatus: ThermalStatus?,
    val powerSaveMode: Boolean?
)

/** What a RAM clean achieved; [freedMb] is an estimate from before/after free-memory readings. */
data class CleanResult(
    val appsChecked: Int,
    val freedMb: Long
)

/** The user's choices for what a boost does and when it warns. */
data class BoostSettings(
    val silenceNotifications: Boolean = true,
    val freeRamOnBoost: Boolean = true,
    val overheatAlertC: Float = DEFAULT_OVERHEAT_ALERT_C
) {
    companion object {
        // Battery temperature at which the "running hot" alert fires; the user can move it within these bounds.
        const val DEFAULT_OVERHEAT_ALERT_C = 42f
        const val MIN_OVERHEAT_ALERT_C = 38f
        const val MAX_OVERHEAT_ALERT_C = 46f
    }
}

/** Which of the special, Settings-granted permissions this app currently holds. */
data class PermissionState(
    val notificationPolicyAccessGranted: Boolean,
    val usageAccessGranted: Boolean,
    val notificationsEnabled: Boolean
)

/**
 * How far a starting session has got, in the order the service does things —
 * so the UI can show real progress rather than a generic spinner.
 */
enum class BoostStage { PREPARING, CLEANING, LAUNCHING, ACTIVE }

/** Whether a boost session is currently applied, and for which game. */
sealed interface BoostSessionState {
    data object Idle : BoostSessionState
    data class Active(
        val game: BoostableGame,
        val stage: BoostStage = BoostStage.PREPARING,
        val cleanResult: CleanResult? = null
    ) : BoostSessionState
}
