package com.bru.gameboost.data

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import com.bru.gameboost.data.cpu.CpuLoadMonitor
import com.bru.gameboost.domain.DeviceStatsRepository
import com.bru.gameboost.domain.model.CpuLoad
import com.bru.gameboost.domain.model.DeviceSnapshot
import com.bru.gameboost.domain.model.ThermalStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn

class DeviceStatsRepositoryImpl(
    context: Context,
    // A factory, not an instance: monitors keep per-collector sample state (see observeSnapshot).
    private val newCpuMonitor: () -> CpuLoadMonitor = { CpuLoadMonitor.default() }
) : DeviceStatsRepository {

    private val appContext = context.applicationContext
    private val activityManager = appContext.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    private val powerManager = appContext.getSystemService(Context.POWER_SERVICE) as? PowerManager

    override fun observeSnapshot(intervalMs: Long): Flow<DeviceSnapshot> = flow {
        // One monitor per collection: delta-based sources remember their previous sample, so the
        // in-app preview and the boost service must each have their own.
        val cpu = newCpuMonitor()

        // Out right away so the card isn't blank for a whole interval. This first call also takes
        // the baseline delta-based sources need, so their figure is still empty here; the
        // clock-speed estimate needs no baseline and shows up immediately.
        emit(readSnapshot(cpu.sample()))

        // A short first gap, so a real reading lands half a second in rather than a full interval later.
        delay(minOf(FIRST_CPU_SAMPLE_DELAY_MS, intervalMs))
        emit(readSnapshot(cpu.sample()))

        while (true) {
            delay(intervalMs)
            emit(readSnapshot(cpu.sample()))
        }
    }.flowOn(Dispatchers.IO)

    private fun readSnapshot(cpuLoad: CpuLoad?): DeviceSnapshot {
        val ram = readRam()
        val battery = readBattery()
        return DeviceSnapshot(
            cpuLoad = cpuLoad,
            ramUsedMb = ram?.usedMb,
            ramTotalMb = ram?.totalMb,
            batteryPercent = battery?.percent,
            batteryTempC = battery?.tempC,
            isCharging = battery?.charging,
            thermalStatus = readThermalStatus(),
            powerSaveMode = powerManager?.isPowerSaveMode
        )
    }

    private data class RamReading(val usedMb: Long, val totalMb: Long)

    private fun readRam(): RamReading? = runCatching {
        val info = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(info)
        val totalMb = info.totalMem / (1024 * 1024)
        val usedMb = totalMb - (info.availMem / (1024 * 1024))
        RamReading(usedMb, totalMb)
    }.getOrNull()

    private data class BatteryReading(val percent: Int?, val tempC: Float?, val charging: Boolean)

    /**
     * Level, temperature and plug state all come from the one sticky battery
     * broadcast — a single cheap read, no permission, and more dependable across
     * vendors than BatteryManager's capacity property.
     */
    private fun readBattery(): BatteryReading? = runCatching {
        val intent = appContext.registerReceiver(null, BATTERY_FILTER)
        if (intent == null) {
            null
        } else {
            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
            val percent = if (level >= 0 && scale > 0) level * 100 / scale else null
            // EXTRA_TEMPERATURE is tenths of a degree Celsius; 0 or missing means "no sensor".
            val tempTenths = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0)
            val tempC = if (tempTenths > 0) tempTenths / 10f else null
            val charging = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
            BatteryReading(percent, tempC, charging)
        }
    }.getOrNull()

    // PowerManager.getCurrentThermalStatus is API 29+; older devices just
    // never show a thermal row rather than a fabricated reading.
    private fun readThermalStatus(): ThermalStatus? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        val pm = powerManager ?: return null
        return runCatching {
            when (pm.currentThermalStatus) {
                PowerManager.THERMAL_STATUS_NONE -> ThermalStatus.NONE
                PowerManager.THERMAL_STATUS_LIGHT -> ThermalStatus.LIGHT
                PowerManager.THERMAL_STATUS_MODERATE -> ThermalStatus.MODERATE
                PowerManager.THERMAL_STATUS_SEVERE -> ThermalStatus.SEVERE
                PowerManager.THERMAL_STATUS_CRITICAL -> ThermalStatus.CRITICAL
                PowerManager.THERMAL_STATUS_EMERGENCY -> ThermalStatus.EMERGENCY
                PowerManager.THERMAL_STATUS_SHUTDOWN -> ThermalStatus.SHUTDOWN
                else -> ThermalStatus.UNKNOWN
            }
        }.getOrElse { ThermalStatus.UNKNOWN }
    }

    private companion object {
        val BATTERY_FILTER = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        const val FIRST_CPU_SAMPLE_DELAY_MS = 500L
    }
}
