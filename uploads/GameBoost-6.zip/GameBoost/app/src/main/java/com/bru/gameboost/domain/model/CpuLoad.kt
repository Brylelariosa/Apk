package com.bru.gameboost.domain.model

/**
 * System-wide CPU load as this app could actually observe it. Android 8+ hides /proc/stat from
 * apps, so what's readable varies by device — the type says how far to trust a figure instead of
 * pretending every number is the same quality.
 */
sealed interface CpuLoad {

    /** A load figure, 0–100. */
    sealed interface Reading : CpuLoad {
        val percent: Float
    }

    /** True utilisation: the share of time the cores were busy, from kernel time counters. */
    data class Measured(override val percent: Float) : Reading

    /**
     * Inferred from core clock speeds. It tracks load (clocks ramp up when cores are busy) but isn't
     * a utilisation figure, so the UI shows it as approximate.
     */
    data class Estimated(override val percent: Float) : Reading

    /** No source could be read on this device; [reason] says why, for the on-screen diagnostic. */
    data class Unavailable(val reason: String) : CpuLoad
}
