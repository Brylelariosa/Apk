package com.game.topdown;

import java.util.*;

/**
 * BotAI — Tactical, human-feeling enemy AI engine.
 *
 * Fully separated from GameView.  GameView provides a {@link Context}
 * implementation; BotAI owns all state-machine logic and decision-making.
 *
 * States
 * ──────
 *   IDLE        Standing still; occasional look-around.
 *   PATROL      Wandering between random map points with natural waviness.
 *   INVESTIGATE Moving toward a heard gunshot or the last known player position.
 *   COMBAT      Engaged: strafe, maintain preferred range, burst-fire, reposition.
 *   PUSH        Aggressively closing in when player is weak or too close.
 *   RETREAT     Backing away (still shooting) when critically low HP.
 *   SEARCH      Sweeping nearby positions after losing visual on the player.
 *
 * Difficulty tuning (Easy / Normal / Hard) affects reaction speed, accuracy,
 * repositioning frequency, and aggression without making enemies feel unfair.
 */
public class BotAI {

    // ── State IDs ─────────────────────────────────────────────────────────────
    public static final int STATE_IDLE        = 0;
    public static final int STATE_PATROL      = 1;
    public static final int STATE_INVESTIGATE = 2;
    public static final int STATE_COMBAT      = 3;
    public static final int STATE_PUSH        = 4;
    public static final int STATE_RETREAT     = 5;
    public static final int STATE_SEARCH      = 6;

    // ── Per-bot persistent brain ──────────────────────────────────────────────
    public static class Brain {
        // ── State machine ────────────────────────────────────────────────────
        int   state          = STATE_PATROL;
        long  stateEnteredAt = 0;

        // ── Navigation / stuck detection ─────────────────────────────────────
        float lastX, lastY;
        int   stuckTicks;
        float forcedAngle;
        int   forcedTicks;
        // General 1-hop waypoint for around-wall routing
        float   wpX, wpY;
        boolean wpActive;

        // ── Patrol ───────────────────────────────────────────────────────────
        float   patrolX, patrolY;
        boolean patrolActive;
        long    nextPatrolMs;      // when to pick a new patrol point
        // Small sinusoidal offset so patrol paths look natural, not straight
        float   patrolWavePhase;

        // ── Awareness ────────────────────────────────────────────────────────
        float   lastKnownX, lastKnownY;     // last confirmed player position
        long    lastSeenMs       = -1;      // wall-clock ms when player last spotted
        boolean playerEverSeen   = false;
        long    investigateStartMs;         // when current investigation began

        // ── Search sweep ─────────────────────────────────────────────────────
        float[] searchPoints;               // interleaved [x0,y0, x1,y1, …]
        int     searchIdx;
        long    searchStartMs;

        // ── Combat: aim imperfection ──────────────────────────────────────────
        float aimNoise;          // current angular error added to shot (radians)
        float aimNoiseTarget;    // noise slowly drifts toward this
        long  reactionEndMs;     // may not fire until this timestamp passes

        // ── Combat: burst-fire ────────────────────────────────────────────────
        int  shotsFired;         // shots fired this burst
        int  maxBurst;           // burst length (randomised per burst)
        long burstPauseEnd;      // no firing during burst cooldown

        // ── Combat: repositioning ─────────────────────────────────────────────
        long    nextRepositionMs;
        float   repoX, repoY;
        boolean repositioning;

        // ── Combat: strafing ─────────────────────────────────────────────────
        float strafeSign       = 1f;
        long  nextStrafeFlipMs = 0;

        // ── Combat: flanking ─────────────────────────────────────────────────
        long    nextFlankMs    = 0;
        float   flankX, flankY;
        boolean flanking;

        // ── Bullet-dodge ─────────────────────────────────────────────────────
        int     dodgeCooldown;
        float   dodgeDirX, dodgeDirY;
        boolean dodging;

        // ── Smoothed movement velocity (for lerp) ────────────────────────────
        float velX, velY;

        // ── Idle timer ───────────────────────────────────────────────────────
        long idleUntilMs;
    }

    // ── Context interface (GameView implements this) ───────────────────────────
    public interface Context {
        List<Bullet>         getBullets();
        Player               getLocalPlayer();
        Map<Integer, Player> getRemote();
        int                  getDifficulty();
        int                  getTick();
        float                getPlayerVelX();
        float                getPlayerVelY();
        float[][]            getWalls();
        float[][]            getNavWaypoints();
        boolean              hasLos(float x1, float y1, float x2, float y2);
        void                 moveBotWithCollision(Player bot, float mx, float my, float spd, float dt);
        void                 spawnBotBullets(Player bot);
        void                 doBotShopping(Player bot);
        void                 doBotUseSkill(Player bot, Player lp, float dist);
        float[]              findNavWaypoint(float bx, float by, float tx, float ty);
    }

    // ── Difficulty tables  [easy=0, normal=1, hard=2] ─────────────────────────
    private static final long[]  REACTION_MS     = { 620, 290, 110 };
    private static final float[] NOISE_MAX       = { 0.34f, 0.19f, 0.08f };  // radians
    private static final float[] NOISE_SPEED     = { 0.55f, 1.3f, 2.8f };    // lerp rate
    private static final int[]   BURST_MIN       = { 2, 3, 4 };
    private static final int[]   BURST_MAX       = { 4, 6, 9 };
    private static final long[]  BURST_PAUSE_MS  = { 850, 520, 240 };
    private static final long[]  REPOSITION_MS   = { 4200, 2600, 1100 };
    private static final float[] SPEED_MULT      = { 1.00f, 1.00f, 1.12f };
    private static final float[] AGGRESSION      = { 0.35f, 0.60f, 0.88f };

    private static final float MAP_W = 3600f, MAP_H = 3600f;
    private static final float VISION_RANGE       = 1150f;
    private static final float SOUND_RANGE        = 920f;
    private static final float LOS_LOST_MS        = 3400f;
    private static final float SEARCH_TIMEOUT_MS  = 8500f;
    private static final float INVEST_TIMEOUT_MS  = 6000f;
    private static final float RETREAT_HP         = 28f;
    private static final float PUSH_HP_BASE       = 32f;

    // ── Per-bot brain storage ─────────────────────────────────────────────────
    private final Map<Integer, Brain> brains = new HashMap<>();
    private final Random rng = new Random();

    public Brain getBrain(int botId) {
        Brain b = brains.get(botId);
        if (b == null) { b = new Brain(); b.lastX = -1; brains.put(botId, b); }
        return b;
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  MAIN UPDATE  — called once per game-loop frame per bot
    // ══════════════════════════════════════════════════════════════════════════
    public void update(Player bot, Context ctx, float dt) {
        Player lp = ctx.getLocalPlayer();
        if (lp == null || !bot.alive) return;

        // Immobilised by a status effect — skip everything
        if (bot.isBeingPulled() || bot.isStunned()) return;

        Brain brain = getBrain(bot.id);
        int   diff  = clampI(ctx.getDifficulty(), 0, 2);
        long  now   = System.currentTimeMillis();

        // ── Gun housekeeping ─────────────────────────────────────────────────
        for (Gun g : bot.guns) g.tick();
        Gun gun = bot.currentGun();
        if (gun.ammo <= 0 && !gun.reloading) gun.startReload();

        // ── Shopping & skill use (Normal/Hard only) ──────────────────────────
        float distToLp = dist(bot.x, bot.y, lp.x, lp.y);
        if (diff >= 1) {
            ctx.doBotUseSkill(bot, lp, distToLp);
            if (ctx.getTick() % 300 == (bot.id * 37) % 300) ctx.doBotShopping(bot);
        }

        // ── Stuck detection ──────────────────────────────────────────────────
        detectAndEscapeStuck(bot, brain, now);

        // ── Perception ───────────────────────────────────────────────────────
        boolean canSee = canSeePlayer(bot, lp, ctx);
        boolean heard  = heardGunfire(bot, lp, ctx);

        // ── State-machine transitions ─────────────────────────────────────────
        updateState(bot, brain, lp, ctx, canSee, heard, diff, distToLp, now);

        // ── Directional movement ──────────────────────────────────────────────
        float[] move = computeMovement(bot, brain, lp, ctx, canSee, diff, distToLp, dt, now);

        // Apply movement (skip in pure idle)
        if (brain.state != STATE_IDLE || brain.dodging || brain.forcedTicks > 0) {
            float spd = 165f * SPEED_MULT[diff] * (bot.isSlowed() ? bot.slowSpeedMult : 1.0f);
            ctx.moveBotWithCollision(bot, move[0], move[1], spd, dt);
        }

        // ── Aim and fire ──────────────────────────────────────────────────────
        updateAimAndFire(bot, brain, lp, ctx, canSee, diff, distToLp, dt, now);
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  PERCEPTION
    // ══════════════════════════════════════════════════════════════════════════

    private boolean canSeePlayer(Player bot, Player lp, Context ctx) {
        if (!lp.alive || lp.isStealthed()) return false;
        float d = dist(bot.x, bot.y, lp.x, lp.y);
        if (d > VISION_RANGE) return false;
        return ctx.hasLos(bot.x, bot.y, lp.x, lp.y);
    }

    private boolean heardGunfire(Player bot, Player lp, Context ctx) {
        for (Bullet b : ctx.getBullets()) {
            if (b.ownerId != lp.id) continue;
            if (dist(bot.x, bot.y, b.x, b.y) < SOUND_RANGE) return true;
        }
        return false;
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  STATE MACHINE
    // ══════════════════════════════════════════════════════════════════════════

    private void updateState(Player bot, Brain brain, Player lp, Context ctx,
                             boolean canSee, boolean heard, int diff,
                             float distToLp, long now) {
        // Update awareness whenever player is visible
        if (canSee) {
            brain.lastKnownX   = lp.x;
            brain.lastKnownY   = lp.y;
            brain.lastSeenMs   = now;
            brain.playerEverSeen = true;
        }

        int desired = desiredState(bot, brain, lp, ctx, canSee, heard, diff, distToLp, now);

        if (desired != brain.state) {
            enterState(bot, brain, lp, ctx, desired, diff, distToLp, now);
        }
    }

    private int desiredState(Player bot, Brain brain, Player lp, Context ctx,
                             boolean canSee, boolean heard, int diff,
                             float distToLp, long now) {

        long timeSinceSeen = (brain.lastSeenMs < 0) ? Long.MAX_VALUE : now - brain.lastSeenMs;

        // ── RETREAT: survival always wins ─────────────────────────────────────
        if (bot.hp <= RETREAT_HP && canSee) return STATE_RETREAT;

        // ── Player in sight ───────────────────────────────────────────────────
        if (canSee) {
            float pushHpThresh = PUSH_HP_BASE * (1f + diff * 0.25f);
            boolean playerVeryWeak = lp.hp <= pushHpThresh;
            boolean tooClose       = distToLp < 190f && diff >= 1;
            if (playerVeryWeak || tooClose) return STATE_PUSH;
            return STATE_COMBAT;
        }

        // ── No LOS — decide based on time since last sighting ─────────────────
        if (brain.playerEverSeen && timeSinceSeen < LOS_LOST_MS)
            return STATE_INVESTIGATE;

        if (brain.playerEverSeen && timeSinceSeen < SEARCH_TIMEOUT_MS)
            return STATE_SEARCH;

        if (heard) return STATE_INVESTIGATE;

        if (now < brain.idleUntilMs) return STATE_IDLE;
        return STATE_PATROL;
    }

    private void enterState(Player bot, Brain brain, Player lp, Context ctx,
                            int newState, int diff, float distToLp, long now) {
        brain.state        = newState;
        brain.stateEnteredAt = now;
        brain.repositioning = false;
        brain.flanking      = false;
        brain.wpActive      = false;

        switch (newState) {
            case STATE_IDLE:
                brain.idleUntilMs = now + 700 + rng.nextInt(1100);
                break;
            case STATE_PATROL:
                pickPatrolPoint(bot, brain, ctx);
                break;
            case STATE_INVESTIGATE:
                brain.investigateStartMs = now;
                // Update target if we just heard a shot
                if (!brain.playerEverSeen) {
                    brain.lastKnownX = lp.x; brain.lastKnownY = lp.y;
                }
                break;
            case STATE_COMBAT:
                // Reaction delay — longer if this is a fresh engagement
                boolean freshEngage = brain.lastSeenMs < 0 || now - brain.lastSeenMs > 900;
                long baseDelay = REACTION_MS[diff];
                brain.reactionEndMs = now + (freshEngage ? baseDelay + rng.nextInt((int)(baseDelay * 0.6f)) : baseDelay / 3);
                brain.nextRepositionMs = now + REPOSITION_MS[diff] / 2 + rng.nextInt(600);
                resetBurst(brain, diff);
                break;
            case STATE_PUSH:
                brain.nextRepositionMs = now + 500 + rng.nextInt(300);
                resetBurst(brain, diff);
                break;
            case STATE_RETREAT:
                resetBurst(brain, diff);
                break;
            case STATE_SEARCH:
                buildSearchPoints(brain);
                brain.searchIdx    = 0;
                brain.searchStartMs = now;
                break;
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  MOVEMENT
    // ══════════════════════════════════════════════════════════════════════════

    private float[] computeMovement(Player bot, Brain brain, Player lp, Context ctx,
                                    boolean canSee, int diff, float distToLp, float dt, long now) {
        float dx   = lp.x - bot.x, dy = lp.y - bot.y;
        float nd   = distToLp > 0 ? distToLp : 1f;
        float nDx  = dx / nd, nDy = dy / nd;

        // ── Bullet-dodge overrides everything ────────────────────────────────
        checkDodge(bot, brain, lp, ctx, diff);
        if (brain.dodging) {
            return lerp(brain, brain.dodgeDirX, brain.dodgeDirY, 0.42f);
        }

        // ── Hard-stuck escape burst ───────────────────────────────────────────
        if (brain.forcedTicks > 0) {
            brain.forcedTicks--;
            return lerp(brain, (float) Math.cos(brain.forcedAngle),
                                (float) Math.sin(brain.forcedAngle), 0.22f);
        }

        // ── Per-state movement ────────────────────────────────────────────────
        switch (brain.state) {
            case STATE_IDLE:
                return lerp(brain, 0, 0, 0.14f);

            case STATE_PATROL: {
                float[] v = patrolMove(bot, brain, ctx, now);
                return lerp(brain, v[0], v[1], 0.08f);
            }

            case STATE_INVESTIGATE: {
                // If timed out: abandon and patrol
                if (now - brain.investigateStartMs > INVEST_TIMEOUT_MS) {
                    enterState(bot, brain, lp, ctx, STATE_PATROL, diff, distToLp, now);
                    return lerp(brain, 0, 0, 0.10f);
                }
                // Close enough to last-known: switch to search
                if (dist(bot.x, bot.y, brain.lastKnownX, brain.lastKnownY) < 85f) {
                    enterState(bot, brain, lp, ctx, STATE_SEARCH, diff, distToLp, now);
                    return lerp(brain, 0, 0, 0.10f);
                }
                float[] v = navigate(bot, brain, ctx, brain.lastKnownX, brain.lastKnownY);
                return lerp(brain, v[0], v[1], 0.10f);
            }

            case STATE_COMBAT: {
                float[] v = combatMove(bot, brain, lp, ctx, canSee, diff, distToLp, nDx, nDy, now);
                return lerp(brain, v[0], v[1], 0.13f);
            }

            case STATE_PUSH: {
                float[] v = pushMove(bot, brain, lp, ctx, distToLp, nDx, nDy);
                return lerp(brain, v[0], v[1], 0.18f);
            }

            case STATE_RETREAT: {
                float[] v = retreatMove(bot, brain, lp, ctx, distToLp, nDx, nDy);
                return lerp(brain, v[0], v[1], 0.15f);
            }

            case STATE_SEARCH: {
                float[] v = searchMove(bot, brain, lp, ctx, diff, distToLp, now);
                return lerp(brain, v[0], v[1], 0.10f);
            }
        }
        return lerp(brain, 0, 0, 0.10f);
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  STATE MOVEMENT IMPLEMENTATIONS
    // ─────────────────────────────────────────────────────────────────────────

    private float[] patrolMove(Player bot, Brain brain, Context ctx, long now) {
        // Pick a new destination if needed
        if (!brain.patrolActive || now >= brain.nextPatrolMs) {
            pickPatrolPoint(bot, brain, ctx);
        }

        float pdx = brain.patrolX - bot.x, pdy = brain.patrolY - bot.y;
        float pd  = (float) Math.sqrt(pdx * pdx + pdy * pdy);

        if (pd < 55f) {
            // Arrived — pause briefly before next point
            brain.patrolActive = false;
            brain.nextPatrolMs = now + 500 + rng.nextInt(1200);
            brain.idleUntilMs  = brain.nextPatrolMs;
            return new float[]{0, 0};
        }

        float[] dir = navigate(bot, brain, ctx, brain.patrolX, brain.patrolY);
        // Waviness — a gentle sinusoid perpendicular to travel so paths look organic
        brain.patrolWavePhase += 0.015f;
        float wave  = (float) Math.sin(brain.patrolWavePhase) * 0.30f;
        float perpX = -dir[1], perpY = dir[0];
        float mx = dir[0] + perpX * wave, my = dir[1] + perpY * wave;
        float len = (float) Math.sqrt(mx * mx + my * my);
        return len > 0.01f ? new float[]{mx / len, my / len} : dir;
    }

    private float[] combatMove(Player bot, Brain brain, Player lp, Context ctx,
                               boolean canSee, int diff, float distToLp,
                               float nDx, float nDy, long now) {
        Gun   gun   = bot.currentGun();
        float range = gun.range * bot.rangeMult();
        float pref  = preferredDist(gun, range);

        // ── Attempt reposition ────────────────────────────────────────────────
        if (canSee && now >= brain.nextRepositionMs) {
            tryReposition(bot, brain, lp, ctx, diff, distToLp, nDx, nDy, now);
        }
        if (brain.repositioning) {
            float rdx = brain.repoX - bot.x, rdy = brain.repoY - bot.y;
            float rd  = (float) Math.sqrt(rdx * rdx + rdy * rdy);
            boolean arrived    = rd < 50f;
            boolean losBlocked = !ctx.hasLos(bot.x, bot.y, brain.repoX, brain.repoY);
            if (arrived || losBlocked) {
                brain.repositioning   = false;
                brain.nextRepositionMs = now + REPOSITION_MS[diff] + rng.nextInt(700);
            } else {
                return new float[]{rdx / rd, rdy / rd};
            }
        }

        // ── Attempt flank ─────────────────────────────────────────────────────
        if (diff >= 1 && canSee && distToLp > 260f && now >= brain.nextFlankMs) {
            if (rng.nextFloat() < AGGRESSION[diff] * 0.28f) {
                tryFlank(bot, brain, lp, ctx, nDx, nDy, now);
            }
        }
        if (brain.flanking) {
            float fdx = brain.flankX - bot.x, fdy = brain.flankY - bot.y;
            float fd  = (float) Math.sqrt(fdx * fdx + fdy * fdy);
            if (fd < 65f || distToLp < 210f) {
                brain.flanking = false;
            } else {
                return navigate(bot, brain, ctx, brain.flankX, brain.flankY);
            }
        }

        // ── No LOS — route toward player ─────────────────────────────────────
        if (!canSee) return navigate(bot, brain, ctx, lp.x, lp.y);

        // ── Standard: strafe + range-maintain ────────────────────────────────
        return strafe(brain, distToLp, pref, range, nDx, nDy, diff, now);
    }

    private float[] pushMove(Player bot, Brain brain, Player lp, Context ctx,
                             float distToLp, float nDx, float nDy) {
        if (distToLp < 110f) {
            // Orbit at close range — keeps pressure while dodging return fire
            float sign = (System.currentTimeMillis() / 550) % 2 == 0 ? 1f : -1f;
            return new float[]{-nDy * sign * 0.7f + nDx * 0.3f,
                                nDx * sign * 0.7f + nDy * 0.3f};
        }
        return navigate(bot, brain, ctx, lp.x, lp.y);
    }

    private float[] retreatMove(Player bot, Brain brain, Player lp, Context ctx,
                                float distToLp, float nDx, float nDy) {
        // Look for a waypoint that breaks the player's LOS (cover)
        float[][] navWps = ctx.getNavWaypoints();
        if (navWps != null) {
            float bestScore = -Float.MAX_VALUE;
            float[] best    = null;
            for (float[] wp : navWps) {
                if (!ctx.hasLos(bot.x, bot.y, wp[0], wp[1])) continue;
                boolean safe   = !ctx.hasLos(lp.x, lp.y, wp[0], wp[1]);
                float   wpDist = dist(wp[0], wp[1], lp.x, lp.y);
                float   score  = wpDist * (safe ? 1.7f : 0.4f);
                if (score > bestScore) { bestScore = score; best = wp; }
            }
            if (best != null) {
                float bx = best[0] - bot.x, by = best[1] - bot.y;
                float bd = (float) Math.sqrt(bx * bx + by * by);
                return bd > 1f ? new float[]{bx / bd, by / bd} : new float[]{-nDx, -nDy};
            }
        }
        return new float[]{-nDx, -nDy};
    }

    private float[] searchMove(Player bot, Brain brain, Player lp, Context ctx,
                               int diff, float distToLp, long now) {
        // Time out → resume patrol
        if (now - brain.searchStartMs > SEARCH_TIMEOUT_MS) {
            enterState(bot, brain, lp, ctx, STATE_PATROL, diff, distToLp, now);
            return new float[]{0, 0};
        }
        if (brain.searchPoints == null || brain.searchIdx >= brain.searchPoints.length / 2) {
            enterState(bot, brain, lp, ctx, STATE_PATROL, diff, distToLp, now);
            return new float[]{0, 0};
        }

        float tx = brain.searchPoints[brain.searchIdx * 2];
        float ty = brain.searchPoints[brain.searchIdx * 2 + 1];

        if (dist(bot.x, bot.y, tx, ty) < 75f) {
            brain.searchIdx++;
            return new float[]{0, 0};
        }
        return navigate(bot, brain, ctx, tx, ty);
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  AIM & FIRE
    // ─────────────────────────────────────────────────────────────────────────

    private void updateAimAndFire(Player bot, Brain brain, Player lp, Context ctx,
                                  boolean canSee, int diff, float distToLp, float dt, long now) {
        // Point toward last known position when not in active combat
        if (!canSee) {
            if (brain.playerEverSeen) {
                float ldx = brain.lastKnownX - bot.x, ldy = brain.lastKnownY - bot.y;
                float ld  = (float) Math.sqrt(ldx * ldx + ldy * ldy);
                if (ld > 1f) bot.angle = (float) Math.atan2(ldy / ld, ldx / ld);
            }
            return;
        }

        if (!lp.alive || lp.isStealthed() || lp.isProtected()) return;

        // ── Compute raw aim toward predicted position ─────────────────────────
        float[] target  = predictedTarget(bot, lp, ctx, diff, distToLp);
        float   rawAngle = (float) Math.atan2(target[1] - bot.y, target[0] - bot.x);

        // ── Drift aim noise (imperfect human-like aim) ────────────────────────
        driftNoise(brain, diff, dt);

        // ── Smooth rotation toward noisy aim (can't snap instantly) ──────────
        float aimSpeed = 2.4f + diff * 2.0f;  // hard bots rotate aim faster
        bot.angle = lerpAngle(bot.angle, rawAngle + brain.aimNoise, Math.min(1f, aimSpeed * dt));

        // ── Reaction gate — can't fire before delay expires ───────────────────
        if (now < brain.reactionEndMs) return;

        // ── Range gate ────────────────────────────────────────────────────────
        Gun   gun   = bot.currentGun();
        float range = gun.range * bot.rangeMult();
        if (distToLp > range) return;

        // ── Burst-pause gate ─────────────────────────────────────────────────
        if (now < brain.burstPauseEnd) return;

        // ── Aim-stability gate: stop briefly to aim before firing ────────────
        float errorTolerance = NOISE_MAX[diff] * 0.65f;
        if (Math.abs(brain.aimNoise) > errorTolerance && diff < 2) return;

        // ── Fire ─────────────────────────────────────────────────────────────
        if (gun.canFireNow()) {
            ctx.spawnBotBullets(bot);
            gun.markFired();
            brain.shotsFired++;

            if (brain.shotsFired >= brain.maxBurst) {
                // End of burst — random pause before next
                long pause = BURST_PAUSE_MS[diff] + rng.nextInt((int)(BURST_PAUSE_MS[diff] * 0.7f));
                brain.burstPauseEnd = now + pause;
                resetBurst(brain, diff);

                // Trigger a reposition after a burst finishes (hard mode does this more)
                if (rng.nextFloat() < AGGRESSION[diff] * 0.55f) {
                    brain.nextRepositionMs = now;
                }
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  HELPERS
    // ─────────────────────────────────────────────────────────────────────────

    /** Predict where the player will be when the bullet arrives. */
    private float[] predictedTarget(Player bot, Player lp, Context ctx, int diff, float dist) {
        float vx = ctx.getPlayerVelX(), vy = ctx.getPlayerVelY();
        float velSq = vx * vx + vy * vy;
        if (velSq > 0.08f && diff >= 1) {
            float bulletSpd = Math.max(bot.currentGun().bulletSpeed, 1f);
            float travelSec = dist / bulletSpd;
            // Hard bots predict nearly perfectly; normal bots slightly under-lead
            float lead   = diff == 2 ? 62f : 44f;
            // Jitter makes prediction never perfect
            float jitter = NOISE_MAX[diff] * 90f;
            float px = lp.x + vx * lead * travelSec + (rng.nextFloat() - 0.5f) * jitter;
            float py = lp.y + vy * lead * travelSec + (rng.nextFloat() - 0.5f) * jitter;
            return new float[]{clamp(px, 0, MAP_W), clamp(py, 0, MAP_H)};
        }
        return new float[]{lp.x, lp.y};
    }

    /** Slowly drift angular aim noise so inaccuracy feels natural rather than static. */
    private void driftNoise(Brain brain, int diff, float dt) {
        float max   = NOISE_MAX[diff];
        float speed = NOISE_SPEED[diff];
        // Occasionally pick a new noise target
        if (Math.abs(brain.aimNoiseTarget - brain.aimNoise) < 0.005f) {
            brain.aimNoiseTarget = (rng.nextFloat() - 0.5f) * max * 2f;
        }
        brain.aimNoise += (brain.aimNoiseTarget - brain.aimNoise) * speed * dt;
        brain.aimNoise  = clamp(brain.aimNoise, -max, max);
    }

    /** Strafe perpendicular to player while maintaining preferred distance. */
    private float[] strafe(Brain brain, float dist, float pref, float range,
                           float nDx, float nDy, int diff, long now) {
        float perpX = -nDy, perpY = nDx;

        // Flip strafe direction periodically (more decisive on higher difficulty)
        if (now >= brain.nextStrafeFlipMs) {
            brain.strafeSign       = rng.nextBoolean() ? 1f : -1f;
            long interval          = 1400 - diff * 220 + rng.nextInt(700);
            brain.nextStrafeFlipMs = now + Math.max(350, interval);
        }

        float sx = perpX * brain.strafeSign, sy = perpY * brain.strafeSign;

        float mx, my;
        float dead = 65f;
        if (dist > pref + dead) {
            // Approach while strafing
            mx = nDx * 0.55f + sx * 0.45f;
            my = nDy * 0.55f + sy * 0.45f;
        } else if (dist < pref - dead && range < 530f) {
            // Short-range gun: back off
            mx = -nDx * 0.50f + sx * 0.50f;
            my = -nDy * 0.50f + sy * 0.50f;
        } else {
            // Ideal range: pure strafe + slight lean on hard
            mx = sx + (diff == 2 ? nDx * 0.12f : 0);
            my = sy + (diff == 2 ? nDy * 0.12f : 0);
        }

        float len = (float) Math.sqrt(mx * mx + my * my);
        return len > 0.01f ? new float[]{mx / len, my / len} : new float[]{sx, sy};
    }

    /** Navigate toward (tx,ty) using 1-hop waypoints when no direct LOS. */
    private float[] navigate(Player bot, Brain brain, Context ctx, float tx, float ty) {
        if (ctx.hasLos(bot.x, bot.y, tx, ty)) {
            float dx = tx - bot.x, dy = ty - bot.y;
            float d  = (float) Math.sqrt(dx * dx + dy * dy);
            return d > 1f ? new float[]{dx / d, dy / d} : new float[]{0, 0};
        }
        // Refresh waypoint if needed
        boolean needNew = !brain.wpActive;
        if (brain.wpActive) {
            float wdx = brain.wpX - bot.x, wdy = brain.wpY - bot.y;
            boolean reached  = wdx * wdx + wdy * wdy < 72f * 72f;
            boolean losGone  = !ctx.hasLos(bot.x, bot.y, brain.wpX, brain.wpY);
            if (reached || losGone) needNew = true;
        }
        if (needNew) {
            float[] wp = ctx.findNavWaypoint(bot.x, bot.y, tx, ty);
            if (wp != null) { brain.wpX = wp[0]; brain.wpY = wp[1]; brain.wpActive = true; }
            else              brain.wpActive = false;
        }
        float npx = brain.wpActive ? brain.wpX : tx;
        float npy = brain.wpActive ? brain.wpY : ty;
        float ndx = npx - bot.x, ndy = npy - bot.y;
        float nd  = (float) Math.sqrt(ndx * ndx + ndy * ndy);
        return nd > 1f ? new float[]{ndx / nd, ndy / nd} : new float[]{0, 0};
    }

    /** React to incoming bullets by sidestepping perpendicular to their travel. */
    private void checkDodge(Player bot, Brain brain, Player lp, Context ctx, int diff) {
        brain.dodging = false;
        if (diff == 0) return;
        if (brain.dodgeCooldown > 0) { brain.dodgeCooldown--; return; }

        float thresh = diff == 2 ? 250f : 190f;
        for (Bullet b : ctx.getBullets()) {
            if (b.ownerId != lp.id) continue;
            float bdx = bot.x - b.x, bdy = bot.y - b.y;
            float dSq = bdx * bdx + bdy * bdy;
            if (dSq > thresh * thresh) continue;

            float bspd = (float) Math.sqrt(b.dx * b.dx + b.dy * b.dy);
            if (bspd < 1f) continue;
            float bnx = b.dx / bspd, bny = b.dy / bspd;
            float dot  = bdx * (-bnx) + bdy * (-bny);
            if (dot > 0.50f * (float) Math.sqrt(dSq)) {
                // Pick the perpendicular direction that moves away from player
                float p1x = -bny, p1y = bnx;
                float p2x =  bny, p2y = -bnx;
                float d1  = p1x * (bot.x - lp.x) + p1y * (bot.y - lp.y);
                float d2  = p2x * (bot.x - lp.x) + p2y * (bot.y - lp.y);
                brain.dodgeDirX   = d1 >= d2 ? p1x : p2x;
                brain.dodgeDirY   = d1 >= d2 ? p1y : p2y;
                brain.dodging     = true;
                brain.dodgeCooldown = diff == 2 ? 30 : 46;
                break;
            }
        }
    }

    /** Choose a reposition point perpendicular to the player direction. */
    private void tryReposition(Player bot, Brain brain, Player lp, Context ctx,
                               int diff, float distToLp, float nDx, float nDy, long now) {
        float perpX = -nDy, perpY = nDx;
        float sign  = rng.nextBoolean() ? 1f : -1f;
        float repD  = 110f + rng.nextFloat() * 170f;
        float rx    = bot.x + perpX * sign * repD + nDx * (rng.nextFloat() - 0.5f) * 70f;
        float ry    = bot.y + perpY * sign * repD + nDy * (rng.nextFloat() - 0.5f) * 70f;
        rx = clamp(rx, 55, MAP_W - 55);
        ry = clamp(ry, 55, MAP_H - 55);

        if (ctx.hasLos(bot.x, bot.y, rx, ry)) {
            brain.repoX           = rx;
            brain.repoY           = ry;
            brain.repositioning   = true;
            brain.nextRepositionMs = now + REPOSITION_MS[diff] + rng.nextInt(600);
        }
    }

    /** Try to reach a flanking position beside the player. */
    private void tryFlank(Player bot, Brain brain, Player lp, Context ctx,
                          float nDx, float nDy, long now) {
        float perpX = -nDy, perpY = nDx;
        float sign  = rng.nextBoolean() ? 1f : -1f;
        float fd    = 360f + rng.nextFloat() * 260f;
        float fx    = lp.x + perpX * sign * fd;
        float fy    = lp.y + perpY * sign * fd;
        fx = clamp(fx, 55, MAP_W - 55);
        fy = clamp(fy, 55, MAP_H - 55);

        float[] wp = ctx.findNavWaypoint(bot.x, bot.y, fx, fy);
        if (wp != null || ctx.hasLos(bot.x, bot.y, fx, fy)) {
            brain.flankX      = fx;
            brain.flankY      = fy;
            brain.flanking    = true;
            brain.nextFlankMs = now + 5500 + rng.nextInt(4500);
        }
    }

    /** Build a small ring of search waypoints around the last-known position. */
    private void buildSearchPoints(Brain brain) {
        int count = 4 + rng.nextInt(2);
        brain.searchPoints = new float[count * 2];
        for (int i = 0; i < count; i++) {
            float angle = (float) (i * Math.PI * 2 / count) + rng.nextFloat() * 0.55f;
            float r     = 130f + rng.nextFloat() * 210f;
            brain.searchPoints[i * 2]     = clamp(brain.lastKnownX + (float) Math.cos(angle) * r, 55, MAP_W - 55);
            brain.searchPoints[i * 2 + 1] = clamp(brain.lastKnownY + (float) Math.sin(angle) * r, 55, MAP_H - 55);
        }
    }

    /** Pick a new patrol destination that avoids walls. */
    private void pickPatrolPoint(Player bot, Brain brain, Context ctx) {
        float[][] walls = ctx.getWalls();
        for (int attempt = 0; attempt < 10; attempt++) {
            float px = 120 + rng.nextFloat() * (MAP_W - 240);
            float py = 120 + rng.nextFloat() * (MAP_H - 240);
            boolean bad = false;
            for (float[] w : walls) {
                if (px > w[0] - 35 && px < w[2] + 35 && py > w[1] - 35 && py < w[3] + 35) {
                    bad = true; break;
                }
            }
            if (!bad) {
                brain.patrolX    = px;
                brain.patrolY    = py;
                brain.patrolActive = true;
                brain.nextPatrolMs = System.currentTimeMillis() + 9000 + rng.nextInt(5000);
                return;
            }
        }
        // Fall back to a random nav waypoint
        float[][] wps = ctx.getNavWaypoints();
        if (wps != null && wps.length > 0) {
            float[] wp = wps[rng.nextInt(wps.length)];
            brain.patrolX = wp[0]; brain.patrolY = wp[1];
        } else {
            brain.patrolX = 400 + rng.nextFloat() * 2800;
            brain.patrolY = 400 + rng.nextFloat() * 2800;
        }
        brain.patrolActive = true;
        brain.nextPatrolMs = System.currentTimeMillis() + 8000;
    }

    /** Detect if the bot is stuck and fire an escape burst if so. */
    private void detectAndEscapeStuck(Player bot, Brain brain, long now) {
        if (brain.lastX < 0) { brain.lastX = bot.x; brain.lastY = bot.y; return; }
        boolean moving = brain.state != STATE_IDLE;
        float moved = (bot.x - brain.lastX) * (bot.x - brain.lastX)
                    + (bot.y - brain.lastY) * (bot.y - brain.lastY);
        brain.stuckTicks = (moving && moved < 1.4f) ? brain.stuckTicks + 1 : 0;
        brain.lastX = bot.x; brain.lastY = bot.y;

        if (brain.stuckTicks > 48) {
            brain.stuckTicks    = 0;
            brain.wpActive      = false;
            brain.repositioning = false;
            brain.flanking      = false;
            brain.forcedAngle   = (float) (rng.nextDouble() * Math.PI * 2);
            brain.forcedTicks   = 58;
        }
    }

    private void resetBurst(Brain brain, int diff) {
        brain.shotsFired = 0;
        brain.maxBurst   = BURST_MIN[diff] + rng.nextInt(BURST_MAX[diff] - BURST_MIN[diff] + 1);
    }

    /** Preferred engagement distance based on the gun's effective range. */
    private float preferredDist(Gun gun, float range) {
        if (range > 1600f) return range * 0.58f; // snipers: stay back
        if (range > 950f)  return range * 0.63f; // assault-class
        if (range < 380f)  return range * 0.78f; // shotgun: close in
        return range * 0.70f;
    }

    /** Velocity-weighted lerp for smooth directional movement. */
    private float[] lerp(Brain brain, float tx, float ty, float rate) {
        brain.velX += (tx - brain.velX) * rate;
        brain.velY += (ty - brain.velY) * rate;
        float len = (float) Math.sqrt(brain.velX * brain.velX + brain.velY * brain.velY);
        if (len > 1f) { brain.velX /= len; brain.velY /= len; }
        return new float[]{brain.velX, brain.velY};
    }

    /** Shortest-path angle lerp (handles ±π wrap). */
    private float lerpAngle(float from, float to, float t) {
        float d = to - from;
        while (d >  Math.PI) d -= Math.PI * 2;
        while (d < -Math.PI) d += Math.PI * 2;
        return from + d * t;
    }

    private static float dist(float ax, float ay, float bx, float by) {
        float dx = ax - bx, dy = ay - by;
        return (float) Math.sqrt(dx * dx + dy * dy);
    }
    private static float clamp(float v, float lo, float hi) { return Math.max(lo, Math.min(hi, v)); }
    private static int   clampI(int v, int lo, int hi)      { return Math.max(lo, Math.min(hi, v)); }
}
