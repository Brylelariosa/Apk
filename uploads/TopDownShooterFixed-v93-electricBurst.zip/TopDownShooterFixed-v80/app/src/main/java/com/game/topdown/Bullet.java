package com.game.topdown;

import java.util.Set;

public class Bullet {
    public int   id, ownerId;
    public float x, y, dx, dy, damage;
    public float spawnX, spawnY, range;
    public long  spawnTime;

    // ── Special mechanics ────────────────────────────────────────────────────
    public int     bouncesLeft;  // >0: bounces off walls instead of dying
    public boolean piercing;     // passes through players (multi-hit)
    public boolean explosive;    // AOE detonation on wall/range expiry
    public boolean homing;       // curves toward nearest enemy
    public boolean ghost;        // travels through walls
    public boolean hookSpear;   // pull + stun on hit; chain drawn from spawn to bullet
    public boolean isSoulReaper; // fired from Soul Surge — kill credits back to gun's killCount
    public int     soulTier;     // Soul Surge tier at bullet spawn time (0 if not soul surge)
    public boolean isShadowBlade; // fired from Shadow Blade — drawn as a slash arc

    // ── Paint mechanics ───────────────────────────────────────────────────────
    // 0 = normal, 1 = blue (slows target), 2 = green (poisons target)
    public int   paintColor       = 0;
    public long  slowDurationMs   = StatusEffectConfig.SLOW_DURATION_MS;
    /** Speed multiplier applied to the target while slowed (e.g. 0.4 = 40% speed). */
    public float slowSpeedMult    = StatusEffectConfig.SLOW_SPEED_MULT;
    public long  poisonDurationMs = StatusEffectConfig.POISON_DURATION_MS;
    public float poisonTickDamage = StatusEffectConfig.POISON_TICK_DAMAGE;
    public long  stunBonusMs      = StatusEffectConfig.HOOK_STUN_BONUS_MS;
    /** AOE damage for explosive bullets — used by doExplosion() instead of b.damage. */
    public float explosionDmg     = StatusEffectConfig.EXPLOSION_DAMAGE;

    public Set<Integer> hitIds;  // piercing: tracks already-hit player IDs

    public Bullet(float x, float y, float dx, float dy,
                  int owner, float dmg, int id, float range) {
        this.x=x; this.y=y; this.dx=dx; this.dy=dy;
        this.ownerId=owner; this.damage=dmg; this.id=id;
        this.spawnX=x; this.spawnY=y; this.range=range;
        this.spawnTime=System.currentTimeMillis();
    }
}
