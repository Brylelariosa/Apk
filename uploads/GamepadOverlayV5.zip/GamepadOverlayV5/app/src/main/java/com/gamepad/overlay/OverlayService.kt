package com.gamepad.overlay

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.os.*
import android.util.DisplayMetrics
import android.view.*
import android.widget.TextView
import androidx.core.app.NotificationCompat
import kotlin.math.abs
import kotlin.math.sqrt

class OverlayService : Service() {

    companion object {
        private const val CHANNEL_ID = "gamepad_overlay_channel"
        private const val NOTIF_ID = 42
        const val PREFS = "gamepad_overlay_prefs"
    }

    private lateinit var wm: WindowManager
    private val uiHandler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences(PREFS, Context.MODE_PRIVATE) }

    private var screenW = 0f
    private var screenH = 0f

    private data class WinEntry(
        val tag: String,
        val view: View,
        val params: WindowManager.LayoutParams,
        var xPct: Float,
        var yPct: Float,
        val wPx: Int,
        val hPx: Int,
        val alwaysVisible: Boolean = false
    )

    private val windows = mutableListOf<WinEntry>()
    private var controlsVisible = true

    @Volatile private var joystickActive = false
    private var joystickThread: Thread? = null
    @Volatile private var joyNx = 0f
    @Volatile private var joyNy = 0f
    private var joystickEntry: WinEntry? = null

    private lateinit var displayManager: DisplayManager
    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayChanged(displayId: Int) { uiHandler.post { onRotation() } }
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) {}
    }

    override fun onBind(intent: Intent?) = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        displayManager = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        displayManager.registerDisplayListener(displayListener, uiHandler)
        resolveScreen()
        createChannel()
        startForeground(NOTIF_ID, buildNotif())
        spawnControls()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            "ACTION_STOP" -> stopSelf()
            "ACTION_REFRESH" -> {
                joystickActive = false
                joystickThread?.interrupt()
                windows.forEach { runCatching { wm.removeView(it.view) } }
                windows.clear()
                joystickEntry = null
                spawnControls()
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        joystickActive = false
        joystickThread?.interrupt()
        displayManager.unregisterDisplayListener(displayListener)
        windows.forEach { runCatching { wm.removeView(it.view) } }
        windows.clear()
        super.onDestroy()
    }

    private fun resolveScreen() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val b = wm.currentWindowMetrics.bounds
            screenW = b.width().toFloat(); screenH = b.height().toFloat()
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
            screenW = dm.widthPixels.toFloat(); screenH = dm.heightPixels.toFloat()
        }
    }

    private fun onRotation() {
        resolveScreen()
        windows.forEach { e ->
            e.params.x = (e.xPct * screenW).toInt()
                .coerceIn(0, (screenW - e.wPx).toInt().coerceAtLeast(0))
            e.params.y = (e.yPct * screenH).toInt()
                .coerceIn(0, (screenH - e.hPx).toInt().coerceAtLeast(0))
            runCatching { wm.updateViewLayout(e.view, e.params) }
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "Gamepad Overlay",
                NotificationManager.IMPORTANCE_LOW).apply { setShowBadge(false) }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(ch)
        }
    }

    private fun buildNotif(): Notification {
        val openPi = PendingIntent.getActivity(this, 0,
            Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stopPi = PendingIntent.getService(this, 1,
            Intent(this, OverlayService::class.java).apply { action = "ACTION_STOP" },
            PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Gamepad Overlay Active")
            .setContentText("Long-press any button to drag it to a new position")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(openPi)
            .addAction(android.R.drawable.ic_delete, "Stop", stopPi)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true).build()
    }

    private fun savedX(tag: String, default: Float) = prefs.getFloat("${tag}_x", default)
    private fun savedY(tag: String, default: Float) = prefs.getFloat("${tag}_y", default)
    private fun savePos(tag: String, xPct: Float, yPct: Float) {
        prefs.edit().putFloat("${tag}_x", xPct).putFloat("${tag}_y", yPct).apply()
    }

    private fun spawnControls() {
        val dp = resources.displayMetrics.density
        fun px(v: Float) = (v * dp).toInt()

        val showJoystick = prefs.getBoolean("show_joystick", true)
        val showDpad     = prefs.getBoolean("show_dpad",     true)
        val showABXY     = prefs.getBoolean("show_abxy",     true)
        val showShoulder = prefs.getBoolean("show_shoulder", true)
        val showCenter   = prefs.getBoolean("show_center",   true)

        // ── Joystick ──────────────────────────────────────────────────────────
        if (showJoystick) {
            val joyPx = px(160f)
            val defX = px(16f) / screenW
            val defY = (screenH - joyPx - px(60f)) / screenH
            val joyView = JoystickView(this).apply {
                onMoveListener = { nx, ny ->
                    joyNx = nx; joyNy = ny
                    val moving = abs(nx) > 0.12f || abs(ny) > 0.12f
                    if (!joystickActive && moving) { joystickActive = true; startJoystickLoop() }
                    else if (!moving) joystickActive = false
                }
                onReleaseListener = { joystickActive = false }
            }
            joystickEntry = addWin("joy", joyView, joyPx, joyPx,
                xPct = savedX("joy", defX),
                yPct = savedY("joy", defY),
                draggable = true)   // joystick is now repositionable
        }

        // ── D-Pad ─────────────────────────────────────────────────────────────
        if (showDpad) {
            val dSz = px(46f); val dGap = px(50f)
            val dcx = px(290f).toInt(); val dcy = (screenH - px(185f)).toInt()
            fun dBtn(tag: String, label: String, dx: Int, dy: Int) {
                val defX = (dcx + dx - dSz / 2f) / screenW
                val defY = (dcy + dy - dSz / 2f) / screenH
                addWin(tag, makeBtn(label, Color.argb(200, 70, 70, 100)) {
                    vibrate(18); tapAtSelf(tag) },
                    dSz, dSz, savedX(tag, defX), savedY(tag, defY), draggable = true)
            }
            dBtn("dpad_up", "▲",    0, -dGap)
            dBtn("dpad_dn", "▼",    0, +dGap)
            dBtn("dpad_lt", "◄", -dGap,    0)
            dBtn("dpad_rt", "►", +dGap,    0)
        }

        // ── ABXY ──────────────────────────────────────────────────────────────
        if (showABXY) {
            val aSz = px(54f); val aGap = px(56f)
            val acx = (screenW - px(90f)).toInt(); val acy = (screenH - px(130f)).toInt()
            fun aBtn(tag: String, label: String, color: Int, dx: Int, dy: Int) {
                val defX = (acx + dx - aSz / 2f) / screenW
                val defY = (acy + dy - aSz / 2f) / screenH
                addWin(tag, makeBtn(label, color) { vibrate(40); tapAtSelf(tag) },
                    aSz, aSz, savedX(tag, defX), savedY(tag, defY), draggable = true)
            }
            aBtn("btn_a", "A", Color.argb(220,   0, 160,  70),    0, +aGap)
            aBtn("btn_b", "B", Color.argb(220, 210,  40,  40), +aGap,    0)
            aBtn("btn_x", "X", Color.argb(220,  20, 100, 210), -aGap,    0)
            aBtn("btn_y", "Y", Color.argb(220, 200, 160,   0),    0, -aGap)
        }

        // ── Shoulder buttons ──────────────────────────────────────────────────
        if (showShoulder) {
            val bW = px(72f); val bH = px(36f)
            val ltW = px(60f); val ltH = px(30f)
            fun shBtn(tag: String, label: String, defXPx: Float, defYPx: Float, w: Int, h: Int) {
                addWin(tag, makeBtn(label, Color.argb(200, 60, 60, 160)) {
                    vibrate(25); tapAtSelf(tag) },
                    w, h, savedX(tag, defXPx / screenW), savedY(tag, defYPx / screenH),
                    draggable = true, alwaysVisible = true)
            }
            shBtn("btn_lb", "LB", px(16f).toFloat(),           px(24f).toFloat(), bW, bH)
            shBtn("btn_rb", "RB", screenW - bW - px(16f),      px(24f).toFloat(), bW, bH)
            shBtn("btn_lt", "LT", px(94f).toFloat(),           px(10f).toFloat(), ltW, ltH)
            shBtn("btn_rt", "RT", screenW - ltW - px(94f),     px(10f).toFloat(), ltW, ltH)
        }

        // ── Center (Start / Select) ───────────────────────────────────────────
        if (showCenter) {
            val sW = px(44f); val sH = px(28f)
            fun cenBtn(tag: String, label: String, defXPx: Float, defYPx: Float) {
                addWin(tag, makeBtn(label, Color.argb(160, 50, 50, 100)) {
                    vibrate(20); tapAtSelf(tag) },
                    sW, sH, savedX(tag, defXPx / screenW), savedY(tag, defYPx / screenH),
                    draggable = true, alwaysVisible = true)
            }
            cenBtn("btn_start",  "▶", screenW / 2f + px(10f),      px(20f).toFloat())
            cenBtn("btn_select", "☰", screenW / 2f - sW - px(10f), px(20f).toFloat())
        }

        // ── Custom extra buttons (added from MainActivity) ────────────────────
        val extraCount = prefs.getInt("extra_btn_count", 0)
        for (i in 0 until extraCount) {
            val tag   = "extra_$i"
            val label = prefs.getString("${tag}_label", "?") ?: "?"
            val color = prefs.getInt("${tag}_color", Color.argb(200, 90, 60, 160))
            val eSz   = px(54f)
            addWin(tag, makeBtn(label, color) { vibrate(40); tapAtSelf(tag) },
                eSz, eSz, savedX(tag, 0.5f), savedY(tag, 0.5f), draggable = true)
        }

        // ── Visibility toggle ─────────────────────────────────────────────────
        val tSz = px(46f)
        val togView = makeBtn("👁", Color.argb(200, 30, 30, 70)) {
            controlsVisible = !controlsVisible
            windows.forEach { e ->
                if (!e.alwaysVisible)
                    e.view.visibility = if (controlsVisible) View.VISIBLE else View.INVISIBLE
            }
        }
        addWin("toggle", togView, tSz, tSz,
            xPct = savedX("toggle", (screenW - tSz - px(16f)) / screenW),
            yPct = savedY("toggle", px(70f) / screenH),
            draggable = true, alwaysVisible = true)
    }

    // ── KEY FIX: tap at the button's own screen position ─────────────────────
    //
    // Each button taps exactly where it visually sits on screen.
    // The user drags the overlay button on top of the game's button → it works.
    // AccessibilityService.dispatchGesture goes to the focused (game) window,
    // bypassing the FLAG_NOT_FOCUSABLE overlay windows, so the gesture hits the
    // game even though the overlay button is drawn at that coordinate.

    private fun tapAtSelf(tag: String) {
        val e  = windows.find { it.tag == tag } ?: return
        val cx = e.params.x + e.wPx / 2f
        val cy = e.params.y + e.hPx / 2f
        InputService.instance?.performTap(cx, cy)
    }

    // ── Window factory ────────────────────────────────────────────────────────

    private fun addWin(
        tag: String,
        view: View,
        wPx: Int, hPx: Int,
        xPct: Float, yPct: Float,
        draggable: Boolean,
        alwaysVisible: Boolean = false
    ): WinEntry {
        val params = WindowManager.LayoutParams(
            wPx, hPx,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (xPct * screenW).toInt()
            y = (yPct * screenH).toInt()
        }
        val entry = WinEntry(tag, view, params, xPct, yPct, wPx, hPx, alwaysVisible)
        if (draggable) attachDrag(view, entry)
        windows.add(entry)
        wm.addView(view, params)
        return entry
    }

    private fun attachDrag(view: View, entry: WinEntry) {
        var dragging = false
        var downRawX = 0f; var downRawY = 0f
        var startX = 0;    var startY = 0

        view.isLongClickable = true
        view.setOnLongClickListener {
            dragging = true
            startX = entry.params.x; startY = entry.params.y
            vibrate(80); view.alpha = 0.55f; true
        }

        view.setOnTouchListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = ev.rawX; downRawY = ev.rawY; false
                }
                MotionEvent.ACTION_MOVE -> {
                    if (dragging) {
                        val nx = (startX + ev.rawX - downRawX).toInt()
                            .coerceIn(0, (screenW - entry.wPx).toInt().coerceAtLeast(0))
                        val ny = (startY + ev.rawY - downRawY).toInt()
                            .coerceIn(0, (screenH - entry.hPx).toInt().coerceAtLeast(0))
                        entry.params.x = nx; entry.params.y = ny
                        runCatching { wm.updateViewLayout(v, entry.params) }
                        true
                    } else false
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (dragging) {
                        dragging = false; view.alpha = 1f
                        entry.xPct = entry.params.x / screenW
                        entry.yPct = entry.params.y / screenH
                        savePos(entry.tag, entry.xPct, entry.yPct)
                        true
                    } else false
                }
                else -> false
            }
        }
    }

    private fun makeBtn(label: String, bgColor: Int, onClick: () -> Unit): TextView =
        TextView(this).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = if (label.length <= 2) 15f else 11f
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(bgColor)
                setStroke(3, Color.argb(140, 200, 200, 255))
            }
            isFocusable = false; isClickable = true
            setOnClickListener { onClick() }
        }

    private fun startJoystickLoop() {
        joystickThread?.interrupt()
        joystickThread = Thread {
            while (joystickActive && !Thread.currentThread().isInterrupted) {
                val nx = joyNx; val ny = joyNy
                val mag = sqrt(nx * nx + ny * ny)
                if (mag > 0.15f) {
                    // Swipe from the joystick's own window center so the overlay joystick
                    // aligns with the game's joystick after the user repositions it.
                    val e    = joystickEntry
                    val sx   = if (e != null) e.params.x + e.wPx / 2f else screenW * 0.5f
                    val sy   = if (e != null) e.params.y + e.hPx / 2f else screenH * 0.55f
                    val dist = (mag * 160f).coerceIn(30f, 200f)
                    swipe(sx, sy, nx * dist, ny * dist, 90)
                }
                try { Thread.sleep(110) } catch (_: InterruptedException) { break }
            }
        }.also { it.isDaemon = true; it.start() }
    }

    private fun swipe(sx: Float, sy: Float, dx: Float, dy: Float, dur: Long) {
        InputService.instance?.performSwipe(sx, sy, dx, dy, dur)
    }

    private fun vibrate(ms: Long) {
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager)
                    .defaultVibrator
                    .vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                    v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
                else @Suppress("DEPRECATION") v.vibrate(ms)
            }
        }
    }
}
