package com.photopuzzle.game.puzzle.render3d

import android.content.Context
import android.graphics.Bitmap
import android.opengl.GLSurfaceView
import android.util.AttributeSet
import android.view.MotionEvent
import com.photopuzzle.game.puzzle.PuzzlePiece

/**
 * Drop-in view that displays one [PuzzlePiece] as a lit, textured,
 * rotatable 3D solid -- drag to orbit it, or leave it alone for a slow
 * auto-rotate. Self-contained: owns its own GLES 2.0 renderer and touch
 * handling, entirely independent of
 * [com.photopuzzle.game.puzzle.PuzzleBoardView]'s own gesture/physics
 * system, so dropping this in (see
 * [com.photopuzzle.game.puzzle.PuzzleActivity] for the sample wiring)
 * can't interfere with it.
 *
 * Requires a device with OpenGL ES 2.0 (declared in the manifest as
 * `<uses-feature android:glEsVersion="0x00020000"/>`), which has been part
 * of the Android baseline since well before this app's minSdk.
 */
class Piece3DView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : GLSurfaceView(context, attrs) {

    private val renderer = Piece3DRenderer(context)

    private var lastTouchX = 0f
    private var lastTouchY = 0f
    private var isDragging = false

    init {
        setEGLContextClientVersion(2)
        // Explicit rather than relying on GLSurfaceView's own default
        // config choice, so a depth buffer (needed for GL_DEPTH_TEST) is
        // guaranteed rather than assumed.
        setEGLConfigChooser(8, 8, 8, 8, 16, 0)
        setRenderer(renderer)
        // Continuous rather than on-demand rendering: this view is a
        // short-lived, opt-in preview rather than something shown for
        // long stretches, so the simplicity of always-on rendering (it's
        // also what drives the idle auto-rotate) is worth more here than
        // the battery saving RENDERMODE_WHEN_DIRTY would give.
        renderMode = RENDERMODE_CONTINUOUSLY
    }

    /**
     * Builds a 3D mesh for [piece] and displays it, replacing whatever was
     * shown before. Safe to call from the main thread, as normal for a
     * View's public API -- the actual GL upload is handed off internally
     * to this view's own GL thread.
     */
    fun show(piece: PuzzlePiece) {
        val mesh = PieceMeshBuilder.build(piece)
        // A copy, not a reference to piece.bitmap itself: this fully
        // decouples the GL thread's texture upload from the original
        // bitmap's lifecycle, so showing a piece stays safe even if the
        // game recycles its bitmaps (e.g. starting a new game) before the
        // queued upload below actually runs.
        val textureCopy = piece.bitmap.copy(Bitmap.Config.ARGB_8888, false)
        queueEvent { renderer.setPiece(mesh, textureCopy) }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastTouchX = event.x
                lastTouchY = event.y
                isDragging = true
                renderer.recordInteraction()
            }
            MotionEvent.ACTION_MOVE -> {
                if (!isDragging) return true
                val dx = event.x - lastTouchX
                val dy = event.y - lastTouchY
                lastTouchX = event.x
                lastTouchY = event.y
                renderer.yaw += dx * DRAG_DEGREES_PER_PX
                renderer.pitch = (renderer.pitch - dy * DRAG_DEGREES_PER_PX)
                    .coerceIn(-MAX_PITCH_DEGREES, MAX_PITCH_DEGREES)
                renderer.recordInteraction()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                isDragging = false
            }
        }
        return true
    }

    companion object {
        private const val DRAG_DEGREES_PER_PX = 0.35f
        private const val MAX_PITCH_DEGREES = 75f
    }
}
