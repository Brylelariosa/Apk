package com.mangatool.app.util

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import androidx.core.content.FileProvider
import com.mangatool.app.model.ImageGroup
import java.io.File
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.Dispatchers

object ImageSaver {

    data class Progress(val message: String, val percent: Int)
    data class SaveResult(val uris: List<Uri>, val folderName: String)

    // ── Cache hygiene ─────────────────────────────────────────────────────────
    /**
     * Delete the entire share_temp cache. Call:
     *  - on app start (onCreate)
     *  - after the share intent is sent
     *  - when the user resets
     * This prevents the cache from growing indefinitely across sessions.
     */
    fun clearShareCache(context: Context) {
        File(context.cacheDir, "share_temp").deleteRecursively()
    }

    // ── Build share URIs (temp cache, no gallery save) ────────────────────────
    /**
     * Writes images to cache in PARALLEL — all files are written at the same
     * time instead of one by one. This is why ZArchiver feels instant: its files
     * are already on disk. We replicate that by parallelising the disk writes.
     *
     * JPEG originals: zero re-encode, just a byte copy (fastest possible).
     * PNG/WEBP: decoded + re-encoded in parallel across CPU cores.
     * Merged bitmaps: merged + encoded in parallel.
     */
    suspend fun buildShareUris(
        context: Context,
        groups: List<ImageGroup>,
        isMerge: Boolean,
        onProgress: (Progress) -> Unit
    ): List<Uri> = coroutineScope {
        val sessionDir = File(context.cacheDir, "share_temp/${System.currentTimeMillis()}").also { it.mkdirs() }
        val authority  = "${context.packageName}.fileprovider"

        if (isMerge) {
            data class PairTask(val groupRef: com.mangatool.app.model.ImageGroup, val pairIdx: Int, val pair: List<com.mangatool.app.model.ImageItem>)
            val tasks = mutableListOf<PairTask>()
            groups.forEach { group -> ImageMerger.pairImages(group.displayImages).forEachIndexed { i, pair -> tasks.add(PairTask(group, i, pair)) } }
            val total = tasks.size.coerceAtLeast(1)
            onProgress(Progress("Preparing 0/$total…", 0))

            val deferreds = tasks.mapIndexed { idx, task ->
                async(Dispatchers.IO) {
                    val swapped = task.groupRef.pairSwaps.contains(task.pairIdx)
                    val bm = ImageMerger.merge(task.pair, swapped) ?: return@async null
                    val file = File(sessionDir, "${(idx + 1).toString().padStart(4, '0')}.png")
                    file.writeBytes(bm.toPngBytes()); bm.recycle()
                    onProgress(Progress("Preparing ${idx + 1}/$total…", ((idx + 1) * 100) / total))
                    file
                }
            }
            deferreds.awaitAll()
                .filterNotNull()
                .map { FileProvider.getUriForFile(context, authority, it) }

        } else {
            val allImages = groups.flatMap { it.displayImages }
            val total     = allImages.size.coerceAtLeast(1)
            onProgress(Progress("Preparing 0/$total…", 0))

            val deferreds = allImages.mapIndexed { idx, img ->
                async(Dispatchers.IO) {
                    val ext  = img.ext.lowercase()
                    val isJpeg = ext == "jpg" || ext == "jpeg"
                    val outExt = if (isJpeg) "jpg" else img.ext.ifBlank { "png" }
                    val file = File(sessionDir, "${(idx + 1).toString().padStart(4, '0')}.$outExt")
                    if (isJpeg) {
                        file.writeBytes(java.io.File(img.filePath).readBytes())
                    } else {
                        val bm = BitmapUtils.decodeFull(img.filePath)
                        if (bm != null) { file.writeBytes(bm.toPngBytes()); bm.recycle() }
                        else file.writeBytes(java.io.File(img.filePath).readBytes())
                    }
                    onProgress(Progress("Preparing ${idx + 1}/$total…", ((idx + 1) * 100) / total))
                    file
                }
            }
            deferreds.awaitAll()
                .map { FileProvider.getUriForFile(context, authority, it) }
        }.also { onProgress(Progress("Ready", 100)) }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    private fun mimeForExt(ext: String) = when (ext.lowercase()) {
        "jpg", "jpeg" -> "image/jpeg"
        "png"         -> "image/png"
        "webp"        -> "image/webp"
        "gif"         -> "image/gif"
        else          -> "image/*"
    }

    private fun String.sanitize() =
        replace(Regex("""[\\/:"*?<>|]"""), "_").trim().ifBlank { "MIE_Export" }
}

// Top-level extension shared by ImageSaver and FolderSaver — lossless PNG
fun android.graphics.Bitmap.toPngBytes(): ByteArray {
    val out = java.io.ByteArrayOutputStream()
    compress(android.graphics.Bitmap.CompressFormat.PNG, 0, out)
    return out.toByteArray()
}

