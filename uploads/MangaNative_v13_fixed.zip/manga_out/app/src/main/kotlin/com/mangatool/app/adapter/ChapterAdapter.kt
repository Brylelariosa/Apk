package com.mangatool.app.adapter

import android.graphics.Bitmap
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import com.mangatool.app.AppMode
import com.mangatool.app.AppState
import com.mangatool.app.R
import com.mangatool.app.model.ImageGroup
import com.mangatool.app.model.ImageItem
import com.mangatool.app.util.BitmapUtils
import com.mangatool.app.util.ImageMerger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ChapterAdapter(
    private val groups: List<ImageGroup>,
    private val onImageClick: (groupIdx: Int, imageIdx: Int) -> Unit,
    private val onGroupRemove: (groupIdx: Int) -> Unit,
    private val onGroupShare: (groupIdx: Int) -> Unit,
    private val onGroupRename: (groupIdx: Int) -> Unit,
    private val onImageLongClick: ((ImageItem) -> Unit)? = null,
    private val onImageRestore: ((ImageItem) -> Unit)? = null,
    private val onFilteredPreview: ((groupIdx: Int, filteredImageIdx: Int) -> Unit)? = null,
    private val onBatchRestore: ((groupIdx: Int) -> Unit)? = null
) : RecyclerView.Adapter<ChapterAdapter.VH>() {

    private val expandedMain     = mutableSetOf<Int>()
    private val expandedFiltered = mutableSetOf<Int>()
    // Thumb adapters are NEVER destroyed on scroll — only on explicit remove/update.
    // This keeps in-flight coroutines alive and the LRU cache hot.
    private val thumbAdapters    = mutableMapOf<Long, ImageThumbAdapter>()
    private val filteredAdapters = mutableMapOf<Long, FilteredThumbAdapter>()
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    var touchHelper: ItemTouchHelper? = null

    // Shared RecycledViewPool — ViewHolder inflation is amortised across all
    // chapter grids instead of each grid paying the full inflation cost separately.
    private val sharedThumbPool = RecyclerView.RecycledViewPool().also {
        it.setMaxRecycledViews(0, 24)   // keep 24 thumb VHs ready
    }

    init { setHasStableIds(true) }
    override fun getItemId(position: Int): Long = groups[position].id

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val cover:           ImageView   = v.findViewById(R.id.chapter_cover)
        val numBadge:        TextView    = v.findViewById(R.id.chapter_num_badge)
        val name:            TextView    = v.findViewById(R.id.chapter_name)
        val count:           TextView    = v.findViewById(R.id.chapter_count)
        val filteredCount:   TextView    = v.findViewById(R.id.filtered_count)
        val arrow:           TextView    = v.findViewById(R.id.chapter_arrow)
        val removeBtn:       ImageButton = v.findViewById(R.id.chapter_remove)
        val renameBtn:       ImageButton = v.findViewById(R.id.chapter_rename)
        val shareBtn:        View        = v.findViewById(R.id.chapter_share)
        val dragHandle:      TextView    = v.findViewById(R.id.drag_handle)
        val header:          View        = v.findViewById(R.id.chapter_header)
        val grid:            RecyclerView= v.findViewById(R.id.chapter_grid)
        val filteredSection: View        = v.findViewById(R.id.filtered_section)
        val filteredHeader:  View        = v.findViewById(R.id.filtered_header)
        val filteredLabel:   TextView    = v.findViewById(R.id.filtered_section_label)
        val filteredArrow:   TextView    = v.findViewById(R.id.filtered_arrow)
        val filteredGrid:    RecyclerView= v.findViewById(R.id.filtered_grid)
        val btnRestoreAll:   Button      = v.findViewById(R.id.btn_restore_all)
        var coverJob: Job? = null
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_chapter, parent, false)
        return VH(v)
    }

    override fun getItemCount() = groups.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val group   = groups[position]
        val isMerge = AppState.currentMode == AppMode.MERGE
        val isExpanded = position in expandedMain

        // ── Number badge ──────────────────────────────────────────────────────
        holder.numBadge.text = "${position + 1}"

        // ── Cover thumbnail (first image, loaded async) ───────────────────────
        val coverImg = group.displayImages.firstOrNull()
        if (coverImg != null) {
            // Key on filePath — unique per temp file regardless of group position.
            // Old "cover_${position}_${coverImg.originalIdx}" collided when two
            // groups both have originalIdx=0 and the chapter list is rebound.
            val cacheKey = "cover:${coverImg.filePath}"
            val cached = AppState.thumbCache.get(cacheKey)
            if (cached != null) {
                // Already cached — set immediately, no flicker, no job needed
                holder.coverJob?.cancel()
                holder.cover.setImageBitmap(cached)
            } else {
                // Not cached — blank first then load async with limited dispatcher
                holder.coverJob?.cancel()
                holder.cover.setImageBitmap(null)
                holder.coverJob = scope.launch {
                    val bm = withContext(BitmapUtils.decodeDispatcher) {
                        runCatching { BitmapUtils.decodeThumbnail(coverImg.filePath, 160) }.getOrNull()
                    }
                    if (bm != null && isActive) {
                        AppState.thumbCache.put(cacheKey, bm)
                        holder.cover.setImageBitmap(bm)  // scope is Main — safe
                    }
                }
            }
        } else {
            holder.coverJob?.cancel()
            holder.cover.setImageBitmap(null)
        }

        // ── Name + count ──────────────────────────────────────────────────────
        holder.name.text = group.groupName

        if (isMerge) {
            val pairs = (group.displayImages.size + 1) / 2
            holder.count.text = "${group.displayImages.size} images · $pairs pairs"
            holder.dragHandle.visibility = View.GONE
            holder.filteredCount.visibility = View.GONE
            holder.filteredSection.visibility = View.GONE
            holder.removeBtn.visibility = if (groups.size > 1) View.VISIBLE else View.GONE
        } else {
            holder.dragHandle.visibility = View.VISIBLE
            holder.removeBtn.visibility  = View.VISIBLE
            holder.count.text = "${group.displayImages.size} images"
            val fCount = group.filteredImages.size
            holder.filteredCount.visibility = if (fCount > 0) View.VISIBLE else View.GONE
            if (fCount > 0) holder.filteredCount.text = "⚠ $fCount filtered"
        }

        holder.arrow.text = if (isExpanded) "▲" else "▼"

        // ── Drag to reorder ───────────────────────────────────────────────────
        holder.dragHandle.setOnTouchListener { _, event ->
            if (!isMerge && event.actionMasked == MotionEvent.ACTION_DOWN) touchHelper?.startDrag(holder)
            false
        }

        // ── Per-chapter actions — use bindingAdapterPosition to avoid stale pos ──
        holder.removeBtn.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_ID.toInt()) onGroupRemove(pos)
        }
        holder.renameBtn.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_ID.toInt()) onGroupRename(pos)
        }
        holder.shareBtn.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_ID.toInt()) onGroupShare(pos)
        }
        holder.name.setOnLongClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_ID.toInt()) onGroupRename(pos)
            true
        }

        // ── Expand / collapse ─────────────────────────────────────────────────
        holder.header.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos == RecyclerView.NO_ID.toInt()) return@setOnClickListener
            val grp = groups[pos]
            if (pos in expandedMain) {
                expandedMain.remove(pos)
                // Do NOT null the adapter — nulling corrupts the inner RecyclerView's
                // LayoutManager state so the next expand can fail to re-layout.
                // GONE hides the grid with zero rendering cost; the adapter stays warm.
                holder.grid.visibility = View.GONE
            } else {
                expandedMain.add(pos)
                attachMainGrid(holder, pos, grp)
                holder.grid.visibility = View.VISIBLE
            }
            holder.arrow.text = if (pos in expandedMain) "▲" else "▼"
        }

        if (isExpanded) {
            attachMainGrid(holder, position, group)
            holder.grid.visibility = View.VISIBLE
        } else {
            // Null the adapter when the VH is bound-collapsed (recycled from another
            // position). This stops the wrong group's grid from briefly flashing before
            // the GONE hides it, and releases the inner RecyclerView's scroll state.
            if (holder.grid.adapter !== thumbAdapters[group.id]) {
                holder.grid.adapter = null
            }
            holder.grid.visibility = View.GONE
        }

        // ── Filtered section ──────────────────────────────────────────────────
        if (!isMerge && group.filteredImages.isNotEmpty()) {
            holder.filteredSection.visibility = View.VISIBLE
            holder.filteredLabel.text = "${group.filteredImages.size} filtered — tap to review"
            holder.filteredArrow.text = if (position in expandedFiltered) "▲" else "▼"
            holder.btnRestoreAll.setOnClickListener {
                val pos = holder.bindingAdapterPosition
                if (pos != RecyclerView.NO_ID.toInt()) onBatchRestore?.invoke(pos)
            }
            holder.filteredHeader.setOnClickListener {
                val pos = holder.bindingAdapterPosition
                if (pos == RecyclerView.NO_ID.toInt()) return@setOnClickListener
                val grp = groups[pos]
                if (pos in expandedFiltered) {
                    expandedFiltered.remove(pos)
                    filteredAdapters.remove(grp.id)?.destroy()
                    holder.filteredGrid.adapter = null
                    holder.filteredGrid.visibility = View.GONE
                } else {
                    expandedFiltered.add(pos)
                    attachFilteredGrid(holder, pos, grp)
                    holder.filteredGrid.visibility = View.VISIBLE
                }
                holder.filteredArrow.text = if (pos in expandedFiltered) "▲" else "▼"
            }
            if (position in expandedFiltered) {
                attachFilteredGrid(holder, position, group)
                holder.filteredGrid.visibility = View.VISIBLE
            } else {
                holder.filteredGrid.visibility = View.GONE
            }
        } else {
            holder.filteredSection.visibility = View.GONE
        }
    }


        private fun attachMainGrid(holder: VH, position: Int, group: ImageGroup) {
        val isMerge = AppState.currentMode == AppMode.MERGE
        val items: List<Any> = if (isMerge) ImageMerger.pairImages(group.displayImages) else group.displayImages
        val cols = if (isMerge) 2 else 3

        val adapter = thumbAdapters.getOrPut(group.id) {
            ImageThumbAdapter(
                items, isMerge,
                group           = if (isMerge) group else null,
                groupIdx        = position,
                onItemClick     = { idx -> onImageClick(position, idx) },
                onItemLongClick = onImageLongClick,
                onSwapChanged   = null
            )
        }

        // Only set a new LayoutManager if the grid doesn't have one yet
        if (holder.grid.layoutManager == null) {
            holder.grid.layoutManager = GridLayoutManager(holder.grid.context, cols).apply {
                initialPrefetchItemCount = cols * 4  // pre-fetch 4 rows
            }
            holder.grid.overScrollMode = android.view.View.OVER_SCROLL_NEVER
        }
        // setHasFixedSize(true) is invalid here — chapter_grid uses wrap_content height
        holder.grid.setRecycledViewPool(sharedThumbPool)
        holder.grid.setItemViewCacheSize(12)
        // Only set adapter if it changed (avoids a full rebind on every scroll)
        if (holder.grid.adapter !== adapter) {
            holder.grid.adapter = adapter
        }
    }

    private fun attachFilteredGrid(holder: VH, position: Int, group: ImageGroup) {
        val adapter = filteredAdapters.getOrPut(group.id) {
            FilteredThumbAdapter(
                items     = group.filteredImages,
                groupIdx  = position,
                onPreview = { filtIdx -> onFilteredPreview?.invoke(position, filtIdx) },
                onRestore = { img -> img.forceKeep = true; img.userDeleted = false; onImageRestore?.invoke(img) }
            )
        }
        if (holder.filteredGrid.layoutManager == null) {
            holder.filteredGrid.layoutManager = GridLayoutManager(holder.filteredGrid.context, 3).apply {
                initialPrefetchItemCount = 9
            }
            holder.filteredGrid.overScrollMode = android.view.View.OVER_SCROLL_NEVER
        }
        // setHasFixedSize(true) is invalid here — filtered_grid uses wrap_content height
        holder.filteredGrid.setItemViewCacheSize(8)
        if (holder.filteredGrid.adapter !== adapter) {
            holder.filteredGrid.adapter = adapter
        }
    }

    // Snapshot of (id, groupName, displaySize, filteredSize) used by DiffUtil to
    // compute minimal diff — avoids full rebind (and cover thumbnail restart) on
    // every applyFiltersAndRefresh() call where most chapters are unchanged.
    private data class GroupSnapshot(val id: Long, val name: String, val displaySize: Int, val filteredSize: Int)
    private var prevSnapshot: List<GroupSnapshot> = emptyList()

    /**
     * Destroy the thumb/filtered adapters for a specific group id.
     * Called from MainActivity.onGroupRemove so the removed group's coroutine
     * scopes are cancelled immediately instead of leaking until destroy().
     */
    fun destroyGroupAdapters(groupId: Long) {
        thumbAdapters.remove(groupId)?.destroy()
        filteredAdapters.remove(groupId)?.destroy()
    }

    /**
     * Refresh the chapter list AND all open inner thumb/filtered adapters.
     *
     * Uses DiffUtil so only changed rows are rebound — avoids restarting
     * in-flight cover thumbnail decode jobs for chapters that didn't change.
     */
    fun update() {
        val newGroups = AppState.groups
        val isMerge = AppState.currentMode == AppMode.MERGE
        // Walk live groups and refresh any open adapter by its stable id.
        newGroups.forEach { group ->
            thumbAdapters[group.id]?.let { adapter ->
                val newItems: List<Any> = if (isMerge)
                    com.mangatool.app.util.ImageMerger.pairImages(group.displayImages)
                else
                    group.displayImages
                adapter.refreshItems(newItems)
            }
            filteredAdapters[group.id]?.refreshItems(group.filteredImages)
        }

        val newSnapshot = newGroups.map { GroupSnapshot(it.id, it.groupName, it.displayImages.size, it.filteredImages.size) }
        val oldSnapshot = prevSnapshot
        prevSnapshot = newSnapshot

        val diff = DiffUtil.calculateDiff(object : DiffUtil.Callback() {
            override fun getOldListSize() = oldSnapshot.size
            override fun getNewListSize() = newSnapshot.size
            override fun areItemsTheSame(o: Int, n: Int) = oldSnapshot[o].id == newSnapshot[n].id
            override fun areContentsTheSame(o: Int, n: Int) = oldSnapshot[o] == newSnapshot[n]
        })
        diff.dispatchUpdatesTo(this)
    }
    fun notifyImageDimsChanged(groupIdx: Int, displayIdx: Int) {
        // Look up by group identity (not position) so dims updates are routed
        // correctly even after a drag-to-reorder shuffles the group list.
        val id = groups.getOrNull(groupIdx)?.id ?: return
        thumbAdapters[id]?.notifyItemChanged(displayIdx, ImageThumbAdapter.PAYLOAD_DIMS)
    }

    fun destroy() {
        scope.cancel()
        thumbAdapters.values.forEach { it.destroy() }; thumbAdapters.clear()
        filteredAdapters.values.forEach { it.destroy() }; filteredAdapters.clear()
    }

    override fun onViewRecycled(holder: VH) {
        holder.coverJob?.cancel()
        // Do NOT null out holder.grid.adapter here — the adapter lives in thumbAdapters
        // and will be reattached on the next bind. Nulling it forces a full rebind.
        super.onViewRecycled(holder)
    }
}

// ── Filtered thumbnail adapter ─────────────────────────────────────────────────
class FilteredThumbAdapter(
    private var items: List<com.mangatool.app.model.ImageItem>,
    private val groupIdx: Int = 0,
    private val onPreview: (Int) -> Unit,
    private val onRestore: (com.mangatool.app.model.ImageItem) -> Unit
) : RecyclerView.Adapter<FilteredThumbAdapter.VH>() {

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val image:   ImageView = v.findViewById(R.id.thumb_image)
        val reason:  TextView  = v.findViewById(R.id.reason_text)
        val preview: View      = v.findViewById(R.id.btn_preview)
        val restore: View      = v.findViewById(R.id.btn_restore)
        var job:     Job?      = null
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_thumb_filtered, parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val img = items[position]
        holder.reason.text = img.filterReason ?: "Filtered"
        holder.image.setImageBitmap(null); holder.job?.cancel()
        val cacheKey = "filt:${img.filePath}"
        val cached = AppState.thumbCache.get(cacheKey)
        if (cached != null) {
            holder.image.setImageBitmap(cached)
        } else {
            holder.job = scope.launch {
                val bm = withContext(BitmapUtils.decodeDispatcher) { BitmapUtils.decodeThumbnail(img.filePath, 200) }
                if (bm != null) { AppState.thumbCache.put(cacheKey, bm); withContext(Dispatchers.Main) { holder.image.setImageBitmap(bm) } }
            }
        }
        holder.itemView.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_ID.toInt()) onPreview(pos)
        }
        holder.preview.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_ID.toInt()) onPreview(pos)
        }
        holder.restore.setOnClickListener  { onRestore(img) }
    }

    fun refreshItems(newItems: List<com.mangatool.app.model.ImageItem>) {
        items = newItems
        notifyDataSetChanged()
    }

    override fun onViewRecycled(holder: VH) { holder.job?.cancel(); super.onViewRecycled(holder) }
    fun destroy() = scope.cancel()
}
