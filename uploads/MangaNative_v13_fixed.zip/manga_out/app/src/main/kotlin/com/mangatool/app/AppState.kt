package com.mangatool.app

import android.content.ComponentCallbacks2
import android.graphics.Bitmap
import android.util.LruCache
import com.mangatool.app.model.ImageGroup
import java.io.File

// ── Mode enum ─────────────────────────────────────────────────────────────────
enum class AppMode { EXTRACT, MERGE }

object AppState {

    /** Extract mode has its own group list */
    val extractGroups: MutableList<ImageGroup> = mutableListOf()
    /** Merge mode has its own completely separate group list */
    val mergeGroups: MutableList<ImageGroup> = mutableListOf()

    /** Per-mode URI dedup sets — prevents the same file being imported twice */
    private val seenUrisExtract: MutableSet<String> = mutableSetOf()
    private val seenUrisMerge:   MutableSet<String> = mutableSetOf()
    val seenUris: MutableSet<String>
        get() = if (currentMode == AppMode.MERGE) seenUrisMerge else seenUrisExtract

    var currentMode: AppMode  = AppMode.EXTRACT
    var minSizeKb: Int        = 40
    var excludeGifs: Boolean  = true
    var reverseOrder: Boolean = false

    /** Convenience: returns the active mode's list */
    val groups: MutableList<ImageGroup>
        get() = if (currentMode == AppMode.MERGE) mergeGroups else extractGroups

    val thumbCache: LruCache<String, Bitmap> = object : LruCache<String, Bitmap>(
        (Runtime.getRuntime().maxMemory() / 1024 / 4).toInt()
    ) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount / 1024
    }

    /**
     * Respond to system memory pressure (call from Activity.onTrimMemory).
     * Avoids OOM by shrinking the thumbnail cache under pressure.
     */
    fun trimThumbCache(level: Int) {
        when {
            level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL -> thumbCache.evictAll()
            level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW      -> thumbCache.trimToSize(thumbCache.maxSize() / 2)
            level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_MODERATE -> thumbCache.trimToSize(thumbCache.maxSize() * 3 / 4)
        }
    }

    /** Set once in MainActivity.onCreate — used to clean up temp image files on reset. */
    var imgCacheDir: File? = null

    fun reset() {
        groups.clear()
        seenUris.clear()
        thumbCache.evictAll()
    }

    fun resetAll() {
        extractGroups.clear()
        mergeGroups.clear()
        seenUrisExtract.clear()
        seenUrisMerge.clear()
        thumbCache.evictAll()
        // Delete all cached image temp files — this is safe because no ByteArrays
        // remain in memory; all ImageItems referencing these files are gone too.
        imgCacheDir?.deleteRecursively()
        filterFingerprints.clear()
    }

    /**
     * Fingerprint of the last applyFilters() call per group.
     * If settings haven't changed and the group's allImages hasn't changed,
     * we skip the full rebuild. Eliminates redundant list allocations on
     * every slider drag when most groups haven't changed.
     */
    private val filterFingerprints = mutableMapOf<ImageGroup, Long>()

    private fun groupFingerprint(group: ImageGroup): Long =
        31L * (31L * (31L * minSizeKb.toLong() + excludeGifs.hashCode().toLong()) + reverseOrder.hashCode().toLong()) +
        group.allImages.sumOf { it.originalIdx.toLong() + (if (it.userDeleted) 1L else 0L) + (if (it.forceKeep) 2L else 0L) }

    fun applyFilters() {
        groups.forEach { group ->
            if (currentMode == AppMode.MERGE) {
                val fp = groupFingerprint(group)
                if (filterFingerprints[group] == fp) return@forEach
                filterFingerprints[group] = fp
                group.displayImages  = group.allImages.mapIndexed { i, img ->
                    img.copy(name = "${(i + 1).toString().padStart(3, '0')}.${img.ext}")
                }
                group.filteredImages = emptyList()
                return@forEach
            }

            val fp = groupFingerprint(group)
            if (filterFingerprints[group] == fp) return@forEach
            filterFingerprints[group] = fp

            val valid    = mutableListOf<com.mangatool.app.model.ImageItem>()
            val filtered = mutableListOf<com.mangatool.app.model.ImageItem>()
            val minBytes = minSizeKb * 1024

            group.allImages.forEach { img ->
                val reason = when {
                    img.userDeleted -> "Manually Deleted"
                    img.forceKeep  -> null
                    img.size < minBytes -> "Too Small (${img.size / 1024}KB)"
                    excludeGifs && img.ext.equals("gif", true) -> "GIF Excluded"
                    else -> null
                }
                if (reason != null) filtered.add(img.copy(filterReason = reason))
                else valid.add(img)
            }
            if (reverseOrder) valid.reverse()
            group.displayImages  = valid.mapIndexed { i, img ->
                img.copy(name = "${(i + 1).toString().padStart(3, '0')}.${img.ext}")
            }
            group.filteredImages = filtered
        }
    }

    /** Call when a group's allImages change so the fingerprint is invalidated. */
    fun invalidateFilter(group: ImageGroup) { filterFingerprints.remove(group) }

    /** Clear all fingerprints — forces full rebuild on next applyFilters(). */
    fun invalidateAllFilters() { filterFingerprints.clear() }
}
