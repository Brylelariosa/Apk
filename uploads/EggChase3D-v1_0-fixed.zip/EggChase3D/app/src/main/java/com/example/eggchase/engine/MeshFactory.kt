package com.example.eggchase.engine

import kotlin.math.sqrt

/** Builds the handful of primitive meshes this game needs. */
object MeshFactory {

    fun cube(size: Float): Mesh {
        val s = size / 2f
        val vertices = mutableListOf<Float>()

        fun face(normal: FloatArray, a: FloatArray, b: FloatArray, c: FloatArray, d: FloatArray) {
            for (v in arrayOf(a, b, c, a, c, d)) {
                vertices.add(v[0]); vertices.add(v[1]); vertices.add(v[2])
                vertices.add(normal[0]); vertices.add(normal[1]); vertices.add(normal[2])
            }
        }

        face(floatArrayOf(0f, 0f, 1f), floatArrayOf(-s, -s, s), floatArrayOf(s, -s, s), floatArrayOf(s, s, s), floatArrayOf(-s, s, s))
        face(floatArrayOf(0f, 0f, -1f), floatArrayOf(s, -s, -s), floatArrayOf(-s, -s, -s), floatArrayOf(-s, s, -s), floatArrayOf(s, s, -s))
        face(floatArrayOf(-1f, 0f, 0f), floatArrayOf(-s, -s, -s), floatArrayOf(-s, -s, s), floatArrayOf(-s, s, s), floatArrayOf(-s, s, -s))
        face(floatArrayOf(1f, 0f, 0f), floatArrayOf(s, -s, s), floatArrayOf(s, -s, -s), floatArrayOf(s, s, -s), floatArrayOf(s, s, s))
        face(floatArrayOf(0f, 1f, 0f), floatArrayOf(-s, s, s), floatArrayOf(s, s, s), floatArrayOf(s, s, -s), floatArrayOf(-s, s, -s))
        face(floatArrayOf(0f, -1f, 0f), floatArrayOf(-s, -s, -s), floatArrayOf(s, -s, -s), floatArrayOf(s, -s, s), floatArrayOf(-s, -s, s))

        return Mesh(vertices.toFloatArray())
    }

    fun ground(size: Float): Mesh {
        val s = size / 2f
        val n = floatArrayOf(0f, 1f, 0f)
        val data = floatArrayOf(
            -s, 0f, -s, n[0], n[1], n[2],
            s, 0f, -s, n[0], n[1], n[2],
            s, 0f, s, n[0], n[1], n[2],
            -s, 0f, -s, n[0], n[1], n[2],
            s, 0f, s, n[0], n[1], n[2],
            -s, 0f, s, n[0], n[1], n[2]
        )
        return Mesh(data)
    }

    /** A vertically-symmetric diamond shape - doubles as an egg/gem. */
    fun octahedron(size: Float): Mesh {
        val top = floatArrayOf(0f, size, 0f)
        val bottom = floatArrayOf(0f, -size, 0f)
        val px = floatArrayOf(size, 0f, 0f)
        val nx = floatArrayOf(-size, 0f, 0f)
        val pz = floatArrayOf(0f, 0f, size)
        val nz = floatArrayOf(0f, 0f, -size)

        val faces = listOf(
            Triple(top, px, pz), Triple(top, pz, nx), Triple(top, nx, nz), Triple(top, nz, px),
            Triple(bottom, pz, px), Triple(bottom, nx, pz), Triple(bottom, nz, nx), Triple(bottom, px, nz)
        )

        val vertices = mutableListOf<Float>()
        for ((a, b, c) in faces) {
            val normal = outwardNormal(a, b, c)
            for (v in arrayOf(a, b, c)) {
                vertices.add(v[0]); vertices.add(v[1]); vertices.add(v[2])
                vertices.add(normal[0]); vertices.add(normal[1]); vertices.add(normal[2])
            }
        }
        return Mesh(vertices.toFloatArray())
    }

    private fun outwardNormal(a: FloatArray, b: FloatArray, c: FloatArray): FloatArray {
        val ux = b[0] - a[0]; val uy = b[1] - a[1]; val uz = b[2] - a[2]
        val vx = c[0] - a[0]; val vy = c[1] - a[1]; val vz = c[2] - a[2]
        var nx = uy * vz - uz * vy
        var ny = uz * vx - ux * vz
        var nz = ux * vy - uy * vx
        val len = sqrt((nx * nx + ny * ny + nz * nz).toDouble()).toFloat()
        if (len > 0.0001f) { nx /= len; ny /= len; nz /= len }
        // Shape is star-convex from the origin, so this sign check is enough
        // to guarantee the normal points away from center rather than into it.
        if (nx * a[0] + ny * a[1] + nz * a[2] < 0f) { nx = -nx; ny = -ny; nz = -nz }
        return floatArrayOf(nx, ny, nz)
    }
}
