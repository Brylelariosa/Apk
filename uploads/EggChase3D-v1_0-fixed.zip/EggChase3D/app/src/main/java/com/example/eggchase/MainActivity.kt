package com.example.eggchase

import android.opengl.GLSurfaceView
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import android.app.Activity
import com.example.eggchase.engine.GameRenderer
import com.example.eggchase.game.GameController
import com.example.eggchase.game.Rarity
import com.example.eggchase.ui.JoystickView

class MainActivity : Activity() {

    private lateinit var glSurfaceView: GLSurfaceView
    private lateinit var controller: GameController

    private lateinit var currencyText: TextView
    private lateinit var mpsText: TextView
    private lateinit var petsText: TextView
    private lateinit var upgradeButton: Button

    private val hudHandler = Handler(Looper.getMainLooper())
    private val hudRefresher = object : Runnable {
        override fun run() {
            refreshHud()
            hudHandler.postDelayed(this, HUD_REFRESH_MS)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        controller = GameController()
        controller.onPetHatched = { rarity: Rarity ->
            runOnUiThread {
                Toast.makeText(this, "Hatched: ${rarity.displayName}!", Toast.LENGTH_SHORT).show()
            }
        }
        controller.onCaught = {
            runOnUiThread {
                Toast.makeText(this, "Caught! Lost some cash.", Toast.LENGTH_SHORT).show()
            }
        }

        glSurfaceView = GLSurfaceView(this).apply {
            setEGLContextClientVersion(2)
            setRenderer(GameRenderer(controller))
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        }
        findViewById<FrameLayout>(R.id.glContainer).addView(glSurfaceView, 0)

        currencyText = findViewById(R.id.currencyText)
        mpsText = findViewById(R.id.mpsText)
        petsText = findViewById(R.id.petsText)
        upgradeButton = findViewById(R.id.upgradeButton)

        findViewById<JoystickView>(R.id.joystick).onDirectionChanged = { x, z ->
            controller.inputX = x
            controller.inputZ = z
        }

        upgradeButton.setOnClickListener { controller.requestUpgrade() }
    }

    override fun onResume() {
        super.onResume()
        glSurfaceView.onResume()
        hudHandler.post(hudRefresher)
    }

    override fun onPause() {
        super.onPause()
        glSurfaceView.onPause()
        hudHandler.removeCallbacks(hudRefresher)
    }

    private fun refreshHud() {
        val state = controller.state
        currencyText.text = "Cash: ${formatMoney(state.currency)}"
        mpsText.text = "${formatMoney(state.moneyPerSecond.toDouble())}/sec"
        petsText.text = "Pets: ${state.pets.size}"
        upgradeButton.text = "Upgrade Speed\n${formatMoney(controller.upgradeCost().toDouble())}"
    }

    private fun formatMoney(value: Double): String = when {
        value >= 1_000_000 -> String.format("%.2fM", value / 1_000_000)
        value >= 1_000 -> String.format("%.2fK", value / 1_000)
        else -> String.format("%.0f", value)
    }

    private companion object {
        const val HUD_REFRESH_MS = 150L
    }
}
