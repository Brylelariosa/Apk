package com.example.eggchase.game

import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.random.Random

/**
 * Owns the game loop. [update] is meant to be called once per rendered
 * frame from a single thread (the GL render thread) - that is the only
 * place [state] is mutated. Other threads should only write [inputX] /
 * [inputZ] or call [requestUpgrade]; those are the plain volatile hand-off
 * points into the loop.
 */
class GameController {
    val state = GameState()

    @Volatile var inputX = 0f
    @Volatile var inputZ = 0f
    @Volatile private var upgradeRequested = false

    var onPetHatched: ((Rarity) -> Unit)? = null
    var onCaught: (() -> Unit)? = null

    private val playArea = 24f
    private val eggPickupRadius = 1.1f
    private val catchRadius = 1.3f
    private val maxEggs = 6
    private val eggSpawnIntervalSeconds = 2.5f
    private val catchPenaltyFraction = 0.10
    private val catchCooldownSeconds = 3f

    private var eggSpawnTimer = 0f
    private var nextId = 0L
    private val random = Random(System.currentTimeMillis())

    fun requestUpgrade() {
        upgradeRequested = true
    }

    fun upgradeCost(): Long {
        val level = state.player.speedLevel
        return (50 * Math.pow(1.18, level.toDouble())).toLong()
    }

    fun update(dt: Float) {
        if (dt <= 0f) return
        processUpgradeRequest()
        updatePlayer(dt)
        updateAnimal(dt)
        updateEggSpawning(dt)
        checkEggCollection()
        checkCatch()
        state.addCurrency(state.moneyPerSecond * dt.toDouble())
    }

    private fun processUpgradeRequest() {
        if (!upgradeRequested) return
        upgradeRequested = false
        if (state.spendCurrency(upgradeCost().toDouble())) {
            state.player.levelUp()
        }
    }

    private fun updatePlayer(dt: Float) {
        val len = hypot(inputX.toDouble(), inputZ.toDouble()).toFloat()
        if (len > 0.05f) {
            val nx = inputX / len
            val nz = inputZ / len
            val player = state.player
            player.x = (player.x + nx * player.speed * dt).coerceIn(-playArea, playArea)
            player.z = (player.z + nz * player.speed * dt).coerceIn(-playArea, playArea)
            player.yaw = atan2(nx.toDouble(), nz.toDouble()).toFloat()
        }
    }

    private fun updateAnimal(dt: Float) {
        val animal = state.animal
        val dx = state.player.x - animal.x
        val dz = state.player.z - animal.z
        val dist = hypot(dx.toDouble(), dz.toDouble()).toFloat()
        if (dist > 0.01f) {
            animal.x += dx / dist * animal.speed * dt
            animal.z += dz / dist * animal.speed * dt
            animal.yaw = atan2(dx.toDouble(), dz.toDouble()).toFloat()
        }
        if (animal.catchCooldown > 0f) {
            animal.catchCooldown -= dt
        }
    }

    private fun updateEggSpawning(dt: Float) {
        eggSpawnTimer -= dt
        if (eggSpawnTimer <= 0f && state.eggs.size < maxEggs) {
            eggSpawnTimer = eggSpawnIntervalSeconds
            val ex = (random.nextFloat() * 2f - 1f) * playArea
            val ez = (random.nextFloat() * 2f - 1f) * playArea
            state.eggs.add(EggEntity(nextId++, ex, ez))
        }
    }

    private fun checkEggCollection() {
        val iterator = state.eggs.iterator()
        while (iterator.hasNext()) {
            val egg = iterator.next()
            val dx = egg.x - state.player.x
            val dz = egg.z - state.player.z
            if (hypot(dx.toDouble(), dz.toDouble()) < eggPickupRadius) {
                iterator.remove()
                val rarity = Rarity.roll(random.nextFloat())
                state.pets.add(PetEntity(nextId++, rarity))
                onPetHatched?.invoke(rarity)
            }
        }
    }

    private fun checkCatch() {
        val animal = state.animal
        if (animal.catchCooldown > 0f) return
        val dx = animal.x - state.player.x
        val dz = animal.z - state.player.z
        if (hypot(dx.toDouble(), dz.toDouble()) < catchRadius) {
            state.applyCatchPenalty(catchPenaltyFraction)
            animal.catchCooldown = catchCooldownSeconds
            animal.x = (random.nextFloat() * 2f - 1f) * playArea
            animal.z = (random.nextFloat() * 2f - 1f) * playArea
            onCaught?.invoke()
        }
    }
}
