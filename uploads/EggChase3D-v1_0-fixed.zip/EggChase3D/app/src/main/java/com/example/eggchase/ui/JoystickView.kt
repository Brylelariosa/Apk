package com.example.eggchase.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin

/**
 * A simple two-circle virtual joystick. Reports normalized x/z in [-1, 1]
 * via [onDirectionChanged]; (0, 0) means "not touched."
 */
class JoystickView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var onDirectionChanged: ((x: Float, z: Float) -> Unit)? = null

    private val basePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x55FFFFFF.toInt() }
    private val knobPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xAAFFFFFF.toInt() }

    private var centerX = 0f
    private var centerY = 0f
    private var knobX = 0f
    private var knobY = 0f
    private var baseRadius = 0f

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        centerX = w / 2f
        centerY = h / 2f
        knobX = centerX
        knobY = centerY
        baseRadius = min(w, h) / 2f * 0.9f
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawCircle(centerX, centerY, baseRadius, basePaint)
        canvas.drawCircle(knobX, knobY, baseRadius * 0.4f, knobPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (baseRadius <= 0f) return true
        when (event.action) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                val dx = event.x - centerX
                val dy = event.y - centerY
                val dist = hypot(dx, dy)
                val clamped = min(dist, baseRadius)
                val angle = atan2(dy, dx)
                knobX = centerX + cos(angle) * clamped
                knobY = centerY + sin(angle) * clamped
                onDirectionChanged?.invoke((knobX - centerX) / baseRadius, (knobY - centerY) / baseRadius)
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                knobX = centerX
                knobY = centerY
                onDirectionChanged?.invoke(0f, 0f)
                invalidate()
            }
        }
        return true
    }
}
