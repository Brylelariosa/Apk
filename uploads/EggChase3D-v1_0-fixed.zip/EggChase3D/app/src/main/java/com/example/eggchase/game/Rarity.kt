package com.example.eggchase.game

/**
 * The tiers a hatched pet can come out as. [weight] controls how likely each
 * tier is to be rolled (higher = more common); [moneyPerSecond] is the
 * passive income a pet of that tier contributes once hatched.
 */
enum class Rarity(
    val displayName: String,
    val weight: Float,
    val moneyPerSecond: Float,
    val r: Float,
    val g: Float,
    val b: Float
) {
    COMMON("Common", 60f, 1f, 0.69f, 0.75f, 0.77f),
    UNCOMMON("Uncommon", 25f, 3f, 0.40f, 0.73f, 0.42f),
    RARE("Rare", 10f, 8f, 0.26f, 0.65f, 0.96f),
    EPIC("Epic", 4f, 20f, 0.67f, 0.28f, 0.74f),
    LEGENDARY("Legendary", 1f, 60f, 1.0f, 0.70f, 0.0f);

    companion object {
        private val TOTAL_WEIGHT = values().sumOf { it.weight.toDouble() }.toFloat()

        /** Rolls a rarity from a uniform random value in [0, 1). */
        fun roll(randomValue: Float): Rarity {
            var remaining = randomValue.coerceIn(0f, 1f) * TOTAL_WEIGHT
            for (rarity in values()) {
                if (remaining < rarity.weight) return rarity
                remaining -= rarity.weight
            }
            return COMMON
        }
    }
}
