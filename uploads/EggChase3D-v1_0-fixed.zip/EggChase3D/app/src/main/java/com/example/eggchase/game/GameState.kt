package com.example.eggchase.game

/** Live, mutable snapshot of everything happening in the game right now. */
class GameState {
    val player = PlayerState()
    val animal = AnimalState()
    val eggs = mutableListOf<EggEntity>()
    val pets = mutableListOf<PetEntity>()

    var currency = 0.0
        private set

    val moneyPerSecond: Float
        get() = pets.sumOf { it.rarity.moneyPerSecond.toDouble() }.toFloat()

    fun addCurrency(amount: Double) {
        if (amount <= 0.0) return
        currency += amount
    }

    fun spendCurrency(amount: Double): Boolean {
        if (currency < amount) return false
        currency -= amount
        return true
    }

    fun applyCatchPenalty(fraction: Double) {
        currency = (currency - currency * fraction).coerceAtLeast(0.0)
    }
}

class PlayerState {
    var x = 0f
    var z = 0f
    var yaw = 0f

    var speedLevel = 0
        private set

    private val baseSpeed = 3.0f
    private val speedPerLevel = 0.35f
    val speed: Float get() = baseSpeed + speedLevel * speedPerLevel

    fun levelUp() {
        speedLevel++
    }
}

class AnimalState {
    var x = 9f
    var z = 9f
    var yaw = 0f
    val speed = 3.6f
    var catchCooldown = 0f
}

data class EggEntity(val id: Long, val x: Float, val z: Float)

data class PetEntity(val id: Long, val rarity: Rarity)
