package com.example.eggchase.engine

import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import com.example.eggchase.game.GameController
import com.example.eggchase.game.Rarity
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.cos
import kotlin.math.sin

class GameRenderer(private val controller: GameController) : GLSurfaceView.Renderer {

    private lateinit var shader: ColorShader
    private lateinit var cubeMesh: Mesh
    private lateinit var groundMesh: Mesh
    private lateinit var eggMesh: Mesh

    private val projectionMatrix = FloatArray(16)
    private val viewMatrix = FloatArray(16)
    private val vpMatrix = FloatArray(16)
    private val modelMatrix = FloatArray(16)
    private val mvpMatrix = FloatArray(16)

    private var lastFrameNanos = 0L
    private var totalTime = 0f

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0.53f, 0.80f, 0.92f, 1f)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glDisable(GLES20.GL_CULL_FACE)

        shader = ColorShader()
        cubeMesh = MeshFactory.cube(1f)
        groundMesh = MeshFactory.ground(60f)
        eggMesh = MeshFactory.octahedron(0.4f)
        lastFrameNanos = 0L
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
        val aspect = width.toFloat() / height.coerceAtLeast(1)
        Matrix.perspectiveM(projectionMatrix, 0, 60f, aspect, 0.1f, 300f)
    }

    override fun onDrawFrame(gl: GL10?) {
        val now = System.nanoTime()
        val dt = if (lastFrameNanos == 0L) 0f
        else ((now - lastFrameNanos) / 1_000_000_000f).coerceIn(0f, 0.05f)
        lastFrameNanos = now
        totalTime += dt

        controller.update(dt)

        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)

        val state = controller.state
        val yaw = state.player.yaw
        val camX = state.player.x - sin(yaw) * CAM_DISTANCE
        val camZ = state.player.z - cos(yaw) * CAM_DISTANCE

        Matrix.setLookAtM(
            viewMatrix, 0,
            camX, CAM_HEIGHT, camZ,
            state.player.x, 1f, state.player.z,
            0f, 1f, 0f
        )
        Matrix.multiplyMM(vpMatrix, 0, projectionMatrix, 0, viewMatrix, 0)

        shader.use()

        draw(groundMesh, 0f, 0f, 0f, 0f, 1f, GROUND_COLOR)
        draw(cubeMesh, state.player.x, 0.5f, state.player.z, yaw, 1f, PLAYER_COLOR)
        draw(cubeMesh, state.animal.x, 0.55f, state.animal.z, state.animal.yaw, 1.1f, ANIMAL_COLOR)

        for (egg in state.eggs) {
            draw(eggMesh, egg.x, 0.55f, egg.z, totalTime * 2f, 1f, EGG_COLOR)
        }

        state.pets.forEachIndexed { index, pet ->
            val trailDistance = 1.2f + index * 0.7f
            val px = state.player.x - sin(yaw) * trailDistance
            val pz = state.player.z - cos(yaw) * trailDistance
            val c: Rarity = pet.rarity
            draw(cubeMesh, px, 0.3f, pz, yaw, 0.5f, floatArrayOf(c.r, c.g, c.b, 1f))
        }
    }

    private fun draw(mesh: Mesh, x: Float, y: Float, z: Float, yaw: Float, scale: Float, color: FloatArray) {
        Matrix.setIdentityM(modelMatrix, 0)
        Matrix.translateM(modelMatrix, 0, x, y, z)
        Matrix.rotateM(modelMatrix, 0, Math.toDegrees(yaw.toDouble()).toFloat(), 0f, 1f, 0f)
        Matrix.scaleM(modelMatrix, 0, scale, scale, scale)
        Matrix.multiplyMM(mvpMatrix, 0, vpMatrix, 0, modelMatrix, 0)
        shader.setMatrices(mvpMatrix, modelMatrix)
        shader.setColor(color[0], color[1], color[2], color[3])
        mesh.draw(shader)
    }

    private companion object {
        const val CAM_DISTANCE = 8f
        const val CAM_HEIGHT = 5.5f
        val GROUND_COLOR = floatArrayOf(0.38f, 0.71f, 0.35f, 1f)
        val PLAYER_COLOR = floatArrayOf(0.20f, 0.45f, 0.95f, 1f)
        val ANIMAL_COLOR = floatArrayOf(0.85f, 0.20f, 0.15f, 1f)
        val EGG_COLOR = floatArrayOf(0.95f, 0.85f, 0.35f, 1f)
    }
}
