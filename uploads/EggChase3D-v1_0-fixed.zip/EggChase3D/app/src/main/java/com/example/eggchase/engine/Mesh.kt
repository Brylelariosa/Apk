package com.example.eggchase.engine

import android.opengl.GLES20
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer

/**
 * A static triangle mesh: interleaved position (xyz) + normal (xyz) per
 * vertex, drawn with GL_TRIANGLES. No index buffer - simple and plenty fast
 * for the small number of low-poly shapes this game draws per frame.
 */
class Mesh(vertexData: FloatArray) {

    private val buffer: FloatBuffer = ByteBuffer
        .allocateDirect(vertexData.size * BYTES_PER_FLOAT)
        .order(ByteOrder.nativeOrder())
        .asFloatBuffer()
        .apply {
            put(vertexData)
            position(0)
        }

    private val vertexCount = vertexData.size / FLOATS_PER_VERTEX

    fun draw(shader: ColorShader) {
        buffer.position(0)
        GLES20.glVertexAttribPointer(
            shader.positionHandle, 3, GLES20.GL_FLOAT, false, STRIDE_BYTES, buffer
        )
        GLES20.glEnableVertexAttribArray(shader.positionHandle)

        buffer.position(3)
        GLES20.glVertexAttribPointer(
            shader.normalHandle, 3, GLES20.GL_FLOAT, false, STRIDE_BYTES, buffer
        )
        GLES20.glEnableVertexAttribArray(shader.normalHandle)

        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, vertexCount)
    }

    companion object {
        private const val BYTES_PER_FLOAT = 4
        const val FLOATS_PER_VERTEX = 6 // 3 position + 3 normal
        const val STRIDE_BYTES = FLOATS_PER_VERTEX * BYTES_PER_FLOAT
    }
}
