# Add project specific ProGuard rules here.

# JoystickView is instantiated by LayoutInflater via reflection from
# activity_main.xml, not from any direct code reference - keep its
# XML-inflation constructor so shrinking/obfuscation can't break that lookup.
-keep class com.example.eggchase.ui.JoystickView {
    <init>(android.content.Context, android.util.AttributeSet);
}
