#include "restoration_engine.h"
#include "tile_processor.h"
#include "blur_estimator.h"
#include "noise_estimator.h"
#include "frequency_analyzer.h"
#include "deconvolution.h"
#include "edge_aware_enhancer.h"
#include "artifact_detector.h"
#include "consensus_engine.h"
#include "reality_lock.h"
#include "convolution.h"
#include <chrono>
#include <cmath>
#include <algorithm>

namespace crystal {
namespace {

using Clock = std::chrono::steady_clock;
double elapsedMs(Clock::time_point start) {
    return std::chrono::duration<double, std::milli>(Clock::now() - start).count();
}

// Special-mode parameter tweaks (Stage-independent): applied once, before
// tiling, so every downstream stage just sees an already-tuned
// RestorationParams and doesn't need to know special modes exist.
RestorationParams applySpecialMode(RestorationParams p) {
    switch (p.specialMode) {
        case SpecialMode::DOCUMENT:
        case SpecialMode::TEXT_ENHANCEMENT:
            // Text wants crisp, high-frequency-trusting edges; halos matter
            // less than legibility, and there's rarely any texture worth
            // "recovering" on a document scan.
            p.haloSuppression = std::min(p.haloSuppression, 0.35f);
            p.frequencyStrength = std::max(p.frequencyStrength, 0.7f);
            p.textureRecovery = std::min(p.textureRecovery, 0.15f);
            p.sharpness = std::max(p.sharpness, 0.6f);
            break;
        case SpecialMode::OLD_PHOTO:
            // Old prints are usually noise- and softness-dominated, not
            // motion-blurred; lean on noise reduction and stay conservative
            // on sharpening to avoid amplifying film grain into speckle.
            p.noiseReduction = std::max(p.noiseReduction, 0.6f);
            p.conservativeMode = true;
            p.haloSuppression = std::max(p.haloSuppression, 0.6f);
            break;
        case SpecialMode::PORTRAIT:
            // Reality Lock already protects fine/high-contrast structure
            // (which correlates with eyes, hairlines, skin texture); bias
            // it slightly stronger here.
            p.haloSuppression = std::max(p.haloSuppression, 0.55f);
            break;
        case SpecialMode::SCREENSHOT:
            // Screenshots are already pixel-exact where sharp; restoration
            // should mostly repair scaling/compression softness, not add
            // texture that was never there.
            p.textureRecovery = std::min(p.textureRecovery, 0.1f);
            p.frequencyStrength = std::max(p.frequencyStrength, 0.6f);
            break;
        case SpecialMode::LANDSCAPE:
        case SpecialMode::AUTO:
        default:
            break;
    }
    return p;
}

} // namespace

PipelineOutput RestorationEngine::run(const FloatImage& inputRgb, const RestorationParams& rawParams) {
    auto totalStart = Clock::now();
    const RestorationParams params = applySpecialMode(rawParams);

    PipelineOutput output;
    const int w = inputRgb.width(), h = inputRgb.height();

    // --- Stage 1: whole-image analysis. Both the edge map and the Harris
    // corner response are computed once here, at full resolution, rather
    // than per-tile: Reality Lock (Stage 8) normalizes each pixel's
    // "importance" against the strongest structure found anywhere in the
    // image, and that only means something as a whole-image quantity — a
    // per-tile local max would make a plain, low-detail tile normalize its
    // own modest edges up to 1.0 and get locked down just as hard as a
    // tile with a genuinely strong silhouette. -------------------------
    FloatImage grayFull = inputRgb.toGrayscale();
    output.edgeMap = conv::sobelMagnitude(grayFull);
    FloatImage cornerResponseFull = RealityLock::computeCornerResponse(grayFull);

    float maxEdgeGlobal = 1e-6f;
    for (float v : output.edgeMap.raw()) maxEdgeGlobal = std::max(maxEdgeGlobal, v);
    float maxCornerGlobal = 1e-6f;
    for (float v : cornerResponseFull.raw()) maxCornerGlobal = std::max(maxCornerGlobal, v);

    // --- Stage 2: adaptive tiling ------------------------------------------
    const int overlap = std::max(8, params.tileSize / 4);
    auto tiles = TileProcessor::computeAdaptiveTiles(w, h, params.tileSize, overlap);
    output.stats.tileCount = static_cast<int>(tiles.size());

    FloatImage ycbcrFull = inputRgb.toYCbCr();

    FloatImage outputAccum(w, h, 3, 0.0f);
    FloatImage weightAccum(w, h, 1, 0.0f);
    output.blurMap = FloatImage(w, h, 1);
    output.noiseMap = FloatImage(w, h, 1);
    output.confidenceMap = FloatImage(w, h, 1);
    output.artifactMap = FloatImage(w, h, 1);

    double tileRealitySum = 0.0;
    double tileAreaSum = 0.0;

    for (const auto& tile : tiles) {
        FloatImage tileRgb = inputRgb.crop(tile.x, tile.y, tile.w, tile.h);
        FloatImage tileYCbCr = tileRgb.toYCbCr();
        FloatImage tileY = tileYCbCr.channel(0);

        // --- Stage 1/2 (per-tile): blur / noise / frequency analysis ---
        auto stageStart = Clock::now();
        BlurEstimator::Estimate blur = BlurEstimator::estimate(tileY);
        float noiseSigma = NoiseEstimator::estimateSigma(tileY);
        FrequencyAnalyzer::Bands bands = FrequencyAnalyzer::decompose(tileY);
        FloatImage bandAgreement = FrequencyAnalyzer::bandAgreementMap(bands);
        output.stats.analysisMs += elapsedMs(stageStart);

        // --- Stage 3: independent restoration candidates ---
        stageStart = Clock::now();
        float noiseToSignal = std::clamp(0.002f + noiseSigma * (0.5f + params.noiseReduction), 1e-4f, 0.6f);
        FloatImage candidateWiener = Deconvolution::wiener(
            tileY, blur.radius * params.blurStrength, blur.directionRad, blur.anisotropy, noiseToSignal);

        int rlIterations = static_cast<int>(std::round(
            params.richardsonLucyIterations * (0.4f + 0.6f * blur.confidence)));
        FloatImage candidateRichardsonLucy = Deconvolution::richardsonLucy(
            tileY, blur.radius * params.blurStrength, blur.directionRad, blur.anisotropy, rlIterations);

        FloatImage candidateEdgeAware = EdgeAwareEnhancer::sharpen(
            tileY, params.sharpness * (0.5f + blur.confidence * 0.5f), 2.0f + blur.radius, params.haloSuppression);

        FloatImage candidateTexture = EdgeAwareEnhancer::localContrast(candidateEdgeAware, params.textureRecovery * 0.6f);
        output.stats.candidateGenMs += elapsedMs(stageStart);

        // --- Stage 4: consensus ---
        stageStart = Clock::now();
        std::vector<FloatImage> candidates = {candidateWiener, candidateRichardsonLucy, candidateEdgeAware, candidateTexture};
        ConsensusEngine::Result consensus = ConsensusEngine::combine(candidates, tileY, params.conservativeMode);
        output.stats.consensusMs += elapsedMs(stageStart);

        // --- Stage 6: artifact detection + suppression ---
        stageStart = Clock::now();
        ArtifactDetector::ArtifactMap artifacts = ArtifactDetector::detect(tileY, consensus.image);
        FloatImage deArtifacted = ArtifactDetector::suppress(consensus.image, tileY, artifacts, params.haloSuppression);
        output.stats.artifactMs += elapsedMs(stageStart);

        // --- Stage 7: frequency-band-gated fine detail ---
        stageStart = Clock::now();
        FloatImage smoothBase = conv::gaussianBlur(deArtifacted, 1.2f);
        FloatImage restoredResidual(tile.w, tile.h, 1), originalResidual(tile.w, tile.h, 1);
        for (int i = 0; i < tile.w * tile.h; ++i) {
            restoredResidual.raw()[i] = deArtifacted.raw()[i] - smoothBase.raw()[i];
            originalResidual.raw()[i] = tileY.raw()[i] - smoothBase.raw()[i];
        }
        FloatImage gatedTileY(tile.w, tile.h, 1);
        for (int i = 0; i < tile.w * tile.h; ++i) {
            float gate = bandAgreement.raw()[i] * params.frequencyStrength + (1.0f - params.frequencyStrength);
            gate = std::clamp(gate, 0.0f, 1.0f);
            float residual = originalResidual.raw()[i] * (1.0f - gate) + restoredResidual.raw()[i] * gate;
            gatedTileY.raw()[i] = std::clamp(smoothBase.raw()[i] + residual, 0.0f, 1.0f);
        }
        output.stats.frequencyGateMs += elapsedMs(stageStart);

        // --- Stage 8: reality lock ---
        stageStart = Clock::now();
        FloatImage tileEdge = output.edgeMap.crop(tile.x, tile.y, tile.w, tile.h);
        FloatImage tileCornerResponse = cornerResponseFull.crop(tile.x, tile.y, tile.w, tile.h);
        float lockStrength = params.conservativeMode ? 0.55f : 0.3f;
        FloatImage lockedTileY = RealityLock::protect(
            gatedTileY, tileY, tileEdge, tileCornerResponse, lockStrength, maxEdgeGlobal, maxCornerGlobal);
        output.stats.realityLockMs += elapsedMs(stageStart);

        // --- Recombine luma with lightly-denoised chroma ---
        FloatImage chromaBlurred = tileYCbCr.clone();
        int chromaRadius = std::max(0, static_cast<int>(std::round(params.noiseReduction * 2.0f)));
        if (chromaRadius > 0) {
            FloatImage cb = tileYCbCr.channel(1);
            FloatImage cr = tileYCbCr.channel(2);
            cb = conv::boxBlur(cb, chromaRadius);
            cr = conv::boxBlur(cr, chromaRadius);
            chromaBlurred.setChannel(1, cb);
            chromaBlurred.setChannel(2, cr);
        }
        chromaBlurred.setChannel(0, lockedTileY);
        FloatImage tileResultRgb = FloatImage::fromYCbCr(chromaBlurred);

        // --- Reassembly ---
        stageStart = Clock::now();
        TileProcessor::accumulateTile(outputAccum, weightAccum, tileResultRgb, tile, overlap);
        output.stats.blendMs += elapsedMs(stageStart);

        // --- Diagnostic maps: write this tile's scalar estimates across
        // its footprint (blocky per-tile heatmap; upscaling/smoothing for
        // display, if desired, is left to the Kotlin-side colormap step). --
        float normalizedBlur = std::clamp(blur.radius / 6.0f, 0.0f, 1.0f);
        float normalizedNoise = std::clamp(noiseSigma * 4.0f, 0.0f, 1.0f);
        for (int j = 0; j < tile.h; ++j) {
            for (int i = 0; i < tile.w; ++i) {
                int gx = tile.x + i, gy = tile.y + j;
                output.blurMap.at(gx, gy, 0) = normalizedBlur;
                output.noiseMap.at(gx, gy, 0) = normalizedNoise;
                output.confidenceMap.at(gx, gy, 0) = consensus.confidenceMap.at(i, j, 0);
                output.artifactMap.at(gx, gy, 0) = artifacts.severity.at(i, j, 0);
            }
        }

        float tileReality = 0.4f * consensus.realityScore + 0.25f * blur.confidence +
                             0.2f * (1.0f - artifacts.overallSeverity) +
                             0.15f * std::clamp(1.0f - normalizedNoise, 0.0f, 1.0f);
        double area = static_cast<double>(tile.w) * tile.h;
        tileRealitySum += tileReality * area;
        tileAreaSum += area;
    }

    TileProcessor::finalizeBlend(outputAccum, weightAccum);
    outputAccum.clamp(0.0f, 1.0f);

    // --- Global tone adjustments (contrast/brightness/saturation/white
    // balance) — applied once on the fully-reassembled image so there's no
    // risk of a visible seam at tile boundaries from per-tile tone shifts. --
    for (int y = 0; y < h; ++y) {
        for (int x = 0; x < w; ++x) {
            float r = outputAccum.at(x, y, 0), g = outputAccum.at(x, y, 1), b = outputAccum.at(x, y, 2);

            r += params.temperature * 0.08f;
            b -= params.temperature * 0.08f;
            g += params.tint * 0.05f;

            float luma = 0.299f * r + 0.587f * g + 0.114f * b;
            r = luma + (r - luma) * (1.0f + params.saturation);
            g = luma + (g - luma) * (1.0f + params.saturation);
            b = luma + (b - luma) * (1.0f + params.saturation);

            float contrastFactor = 1.0f + params.contrast;
            r = (r - 0.5f) * contrastFactor + 0.5f + params.brightness * 0.3f;
            g = (g - 0.5f) * contrastFactor + 0.5f + params.brightness * 0.3f;
            b = (b - 0.5f) * contrastFactor + 0.5f + params.brightness * 0.3f;

            outputAccum.at(x, y, 0) = std::clamp(r, 0.0f, 1.0f);
            outputAccum.at(x, y, 1) = std::clamp(g, 0.0f, 1.0f);
            outputAccum.at(x, y, 2) = std::clamp(b, 0.0f, 1.0f);
        }
    }

    output.restored = outputAccum;
    output.realityScore = tileAreaSum > 0.0 ? static_cast<float>(tileRealitySum / tileAreaSum) : 0.0f;
    output.stats.totalMs = elapsedMs(totalStart);
    return output;
}

} // namespace crystal
