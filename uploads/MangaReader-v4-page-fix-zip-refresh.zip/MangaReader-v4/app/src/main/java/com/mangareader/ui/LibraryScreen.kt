package com.mangareader.ui

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.mangareader.data.LibrarySortOrder
import com.mangareader.data.ReadingProgress
import com.mangareader.data.Series
import com.mangareader.manager.formatBytes
import com.mangareader.viewmodel.LibraryViewModel
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LibraryScreen(
    viewModel: LibraryViewModel,
    onSeriesClick: (Series) -> Unit
) {
    val seriesList  by viewModel.series.collectAsStateWithLifecycle()
    val loading     by viewModel.loading.collectAsStateWithLifecycle()
    val error       by viewModel.error.collectAsStateWithLifecycle()
    val thumbnails  by viewModel.thumbnails.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val sortOrder   by viewModel.sortOrder.collectAsStateWithLifecycle()
    val cacheBytes  by viewModel.cacheBytes.collectAsStateWithLifecycle()

    var showAddMenu     by remember { mutableStateOf(false) }
    var showSortMenu    by remember { mutableStateOf(false) }
    var showSearchBar   by remember { mutableStateOf(false) }
    var showClearDialog by remember { mutableStateOf(false) }
    var deleteTarget    by remember { mutableStateOf<Series?>(null) }

    val recentSeries = remember(seriesList) { viewModel.getRecentSeries() }

    val folderPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri -> uri?.let { viewModel.addFolder(it) } }

    val zipPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> uri?.let { viewModel.addZip(it) } }

    // Close search on back press
    if (showSearchBar) {
        BackHandler { showSearchBar = false; viewModel.setSearchQuery("") }
    }

    Scaffold(
        topBar = {
            Column {
                TopAppBar(
                    title = {
                        if (!showSearchBar) {
                            Text("Manga Library")
                        }
                    },
                    navigationIcon = {
                        if (showSearchBar) {
                            IconButton(onClick = {
                                showSearchBar = false
                                viewModel.setSearchQuery("")
                            }) {
                                Icon(Icons.Default.ArrowBack, "Close search")
                            }
                        }
                    },
                    actions = {
                        if (showSearchBar) {
                            SearchField(
                                query    = searchQuery,
                                onQuery  = viewModel::setSearchQuery,
                                modifier = Modifier.weight(1f).padding(end = 8.dp)
                            )
                        } else {
                            IconButton(onClick = { showSearchBar = true }) {
                                Icon(Icons.Default.Search, "Search")
                            }
                            // Sort dropdown trigger
                            Box {
                                IconButton(onClick = { showSortMenu = true }) {
                                    Icon(Icons.Default.Sort, "Sort")
                                }
                                DropdownMenu(
                                    expanded         = showSortMenu,
                                    onDismissRequest = { showSortMenu = false }
                                ) {
                                    LibrarySortOrder.entries.forEach { order ->
                                        DropdownMenuItem(
                                            text = { Text(order.label()) },
                                            leadingIcon = {
                                                if (sortOrder == order) {
                                                    Icon(Icons.Default.Check, null,
                                                        tint = MaterialTheme.colorScheme.primary)
                                                }
                                            },
                                            onClick = {
                                                viewModel.setSortOrder(order)
                                                showSortMenu = false
                                            }
                                        )
                                    }
                                }
                            }
                            // Add manga
                            Box {
                                IconButton(onClick = { showAddMenu = true }) {
                                    Icon(Icons.Default.Add, "Add manga")
                                }
                                DropdownMenu(
                                    expanded         = showAddMenu,
                                    onDismissRequest = { showAddMenu = false }
                                ) {
                                    DropdownMenuItem(
                                        text        = { Text("Add folder") },
                                        leadingIcon = { Icon(Icons.Default.Folder, null) },
                                        onClick = { showAddMenu = false; folderPicker.launch(null) }
                                    )
                                    DropdownMenuItem(
                                        text        = { Text("Add ZIP file") },
                                        leadingIcon = { Icon(Icons.Default.Archive, null) },
                                        onClick = {
                                            showAddMenu = false
                                            zipPicker.launch(arrayOf("application/zip", "*/*"))
                                        }
                                    )
                                    HorizontalDivider()
                                    DropdownMenuItem(
                                        text        = { Text("Clear cache (${cacheBytes.formatBytes()})") },
                                        leadingIcon = { Icon(Icons.Default.DeleteSweep, null) },
                                        onClick     = { showAddMenu = false; showClearDialog = true }
                                    )
                                }
                            }
                        }
                    },
                    colors       = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    windowInsets = WindowInsets(0)
                )
            }
        },
        contentWindowInsets = WindowInsets(0)
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {

            if (seriesList.isEmpty() && !loading) {
                LibraryEmpty(
                    onAddFolder = { folderPicker.launch(null) },
                    onAddZip    = { zipPicker.launch(arrayOf("application/zip", "*/*")) }
                )
            } else {
                LazyVerticalGrid(
                    columns               = GridCells.Adaptive(160.dp),
                    contentPadding        = PaddingValues(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement   = Arrangement.spacedBy(12.dp),
                    flingBehavior         = rememberMomentumFlingBehavior(),
                    modifier              = Modifier.fillMaxSize()
                ) {
                    // "Continue Reading" strip — only when not searching
                    if (searchQuery.isBlank() && recentSeries.isNotEmpty()) {
                        item(key = "continue_header", span = { GridItemSpan(maxLineSpan) }) {
                            Text(
                                "Continue Reading",
                                style    = MaterialTheme.typography.titleSmall,
                                color    = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(start = 4.dp, bottom = 4.dp)
                            )
                        }
                        item(key = "continue_strip", span = { GridItemSpan(maxLineSpan) }) {
                            ContinueReadingStrip(
                                items      = recentSeries,
                                thumbnails = thumbnails,
                                onClick    = { series -> onSeriesClick(series) }
                            )
                        }
                        item(key = "divider", span = { GridItemSpan(maxLineSpan) }) {
                            HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                        }
                    }

                    items(seriesList, key = { it.id }) { series ->
                        SeriesCard(
                            series    = series,
                            progress  = viewModel.getProgress(series.id),
                            thumbnail = thumbnails[series.id],
                            onClick   = { onSeriesClick(series) },
                            onDelete  = { deleteTarget = series },
                            onRefresh = { viewModel.refreshSeries(series) },
                            onRequestThumbnail = { viewModel.ensureThumbnail(series) }
                        )
                    }
                }
            }

            if (loading) {
                Box(
                    Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.4f)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator()
                        Spacer(Modifier.height(12.dp))
                        Text("Importing…", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }

            error?.let { msg ->
                Snackbar(
                    modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp),
                    action = {
                        TextButton(onClick = { viewModel.clearError() }) { Text("OK") }
                    }
                ) { Text(msg) }
            }
        }
    }

    // Delete confirmation
    deleteTarget?.let { series ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Remove Series") },
            text  = { Text("Remove \"${series.title}\" from library?\nCached images will be deleted.") },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.deleteSeries(series.id)
                    deleteTarget = null
                }) { Text("Remove", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { deleteTarget = null }) { Text("Cancel") }
            }
        )
    }

    // Clear cache confirmation
    if (showClearDialog) {
        AlertDialog(
            onDismissRequest = { showClearDialog = false },
            title = { Text("Clear Cache") },
            text  = {
                Text("Delete all cached page images and thumbnails (${cacheBytes.formatBytes()})?\n\n" +
                    "Chapters will be re-extracted when opened again.")
            },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.clearAllCaches()
                    showClearDialog = false
                }) { Text("Clear", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { showClearDialog = false }) { Text("Cancel") }
            }
        )
    }
}

// ── Search field ───────────────────────────────────────────────────────────────

@Composable
private fun SearchField(query: String, onQuery: (String) -> Unit, modifier: Modifier) {
    val focus = remember { FocusRequester() }
    val fm    = LocalFocusManager.current

    LaunchedEffect(Unit) { focus.requestFocus() }

    TextField(
        value         = query,
        onValueChange = onQuery,
        placeholder   = { Text("Search library…") },
        singleLine    = true,
        leadingIcon   = { Icon(Icons.Default.Search, null) },
        trailingIcon  = if (query.isNotEmpty()) {{
            IconButton(onClick = { onQuery("") }) {
                Icon(Icons.Default.Clear, "Clear search")
            }
        }} else null,
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { fm.clearFocus() }),
        colors = TextFieldDefaults.colors(
            unfocusedContainerColor = Color.Transparent,
            focusedContainerColor   = Color.Transparent
        ),
        modifier = modifier.focusRequester(focus)
    )
}

// ── Continue Reading strip ─────────────────────────────────────────────────────

@Composable
private fun ContinueReadingStrip(
    items:      List<Pair<Series, ReadingProgress>>,
    thumbnails: Map<String, File>,
    onClick:    (Series) -> Unit
) {
    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding        = PaddingValues(horizontal = 4.dp)
    ) {
        items(items, key = { (s, _) -> "cr_${s.id}" }) { (series, progress) ->
            ContinueReadingCard(
                series    = series,
                progress  = progress,
                thumbnail = thumbnails[series.id],
                onClick   = { onClick(series) }
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ContinueReadingCard(
    series:    Series,
    progress:  ReadingProgress,
    thumbnail: File?,
    onClick:   () -> Unit
) {
    val chapterNum = progress.chapterIndex + 1
    val pageNum    = progress.pageIndex + 1
    val totalCh    = series.chapters.size

    Card(
        shape     = RoundedCornerShape(10.dp),
        colors    = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        modifier  = Modifier
            .width(130.dp)
            .combinedClickable(onClick = onClick)
    ) {
        Box(
            Modifier.fillMaxWidth().height(90.dp)
                .clip(RoundedCornerShape(topStart = 10.dp, topEnd = 10.dp))
                .background(MaterialTheme.colorScheme.primaryContainer)
        ) {
            if (thumbnail != null) {
                AsyncImage(thumbnail, null, contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize())
            }
            // Progress bar
            val fraction = if (totalCh > 0) (chapterNum.toFloat() / totalCh).coerceIn(0f, 1f) else 0f
            LinearProgressIndicator(
                progress   = { fraction },
                modifier   = Modifier.align(Alignment.BottomStart).fillMaxWidth().height(3.dp),
                color      = MaterialTheme.colorScheme.primary,
                trackColor = Color.White.copy(alpha = 0.2f)
            )
        }
        Column(Modifier.padding(8.dp)) {
            Text(series.title, style = MaterialTheme.typography.labelMedium,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("Ch $chapterNum · Pg $pageNum",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.secondary)
        }
    }
}

// ── Series card ────────────────────────────────────────────────────────────────

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun SeriesCard(
    series: Series,
    progress: ReadingProgress?,
    thumbnail: File?,
    onClick: () -> Unit,
    onDelete: () -> Unit,
    onRefresh: () -> Unit,
    onRequestThumbnail: () -> Unit
) {
    var showMenu by remember { mutableStateOf(false) }

    LaunchedEffect(series.id) { onRequestThumbnail() }

    val progressFraction = remember(progress, series.chapters.size) {
        if (progress != null && series.chapters.isNotEmpty()) {
            ((progress.chapterIndex + 1).toFloat() / series.chapters.size).coerceIn(0f, 1f)
        } else null
    }

    Card(
        shape     = RoundedCornerShape(14.dp),
        colors    = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        modifier  = Modifier
            .fillMaxWidth()
            .semantics { contentDescription = "${series.title}, ${series.chapters.size} chapters" }
            .combinedClickable(onClick = onClick, onLongClick = { showMenu = true })
    ) {
        Column {
            Box(
                Modifier.fillMaxWidth().height(140.dp)
                    .clip(RoundedCornerShape(topStart = 14.dp, topEnd = 14.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer)
            ) {
                if (thumbnail != null) {
                    AsyncImage(thumbnail, null, contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize())
                } else {
                    Icon(Icons.Default.MenuBook, null,
                        modifier = Modifier.size(36.dp).align(Alignment.Center),
                        tint = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f))
                }

                // Cover scrim so the chapter count badge stays readable
                Box(
                    Modifier.fillMaxWidth().height(40.dp).align(Alignment.BottomCenter)
                        .background(Brush.verticalGradient(
                            listOf(Color.Transparent, Color.Black.copy(alpha = 0.55f))
                        ))
                )

                Text("${series.chapters.size} ch",
                    style    = MaterialTheme.typography.labelSmall,
                    color    = Color.White,
                    modifier = Modifier.align(Alignment.BottomEnd).padding(6.dp))

                if (progressFraction != null) {
                    LinearProgressIndicator(
                        progress   = { progressFraction },
                        modifier   = Modifier.align(Alignment.BottomStart).fillMaxWidth().height(3.dp),
                        color      = MaterialTheme.colorScheme.primary,
                        trackColor = Color.White.copy(alpha = 0.25f)
                    )
                }
            }

            Column(Modifier.padding(10.dp)) {
                Text(series.title, style = MaterialTheme.typography.titleSmall,
                    maxLines = 2, overflow = TextOverflow.Ellipsis)
                if (progress != null) {
                    Spacer(Modifier.height(2.dp))
                    Text("Ch ${progress.chapterIndex + 1} · Pg ${progress.pageIndex + 1}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.secondary)
                }
            }
        }

        DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
            if (series.sourceFolderUri != null || series.sourceZipUri != null) {
                DropdownMenuItem(
                    text        = { Text("Refresh chapters") },
                    leadingIcon = { Icon(Icons.Default.Refresh, null) },
                    onClick     = { showMenu = false; onRefresh() }
                )
            }
            DropdownMenuItem(
                text        = { Text("Remove from library") },
                leadingIcon = { Icon(Icons.Default.Delete, null) },
                onClick     = { showMenu = false; onDelete() }
            )
        }
    }
}

@Composable
private fun LibraryEmpty(onAddFolder: () -> Unit, onAddZip: () -> Unit) {
    Column(Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Default.LibraryBooks, null,
            modifier = Modifier.size(80.dp),
            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f))
        Spacer(Modifier.height(20.dp))
        Text("No manga yet", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(8.dp))
        Text("Add a folder or ZIP containing .mhtml files",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(28.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = onAddFolder) {
                Icon(Icons.Default.Folder, null, Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp)); Text("Folder")
            }
            OutlinedButton(onClick = onAddZip) {
                Icon(Icons.Default.Archive, null, Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp)); Text("ZIP")
            }
        }
    }
}

/** Human-readable label for each sort order option. */
private fun LibrarySortOrder.label() = when (this) {
    LibrarySortOrder.RECENTLY_ADDED -> "Recently Added"
    LibrarySortOrder.LAST_READ      -> "Last Read"
    LibrarySortOrder.TITLE_AZ       -> "Title A → Z"
    LibrarySortOrder.TITLE_ZA       -> "Title Z → A"
    LibrarySortOrder.CHAPTER_COUNT  -> "Chapter Count"
}
