package com.mangareader.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.mangareader.data.Chapter
import com.mangareader.data.ReadingProgress
import com.mangareader.data.Series

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChapterListScreen(
    series: Series,
    progress: ReadingProgress?,
    readChapterIds: Set<String>,
    onChapterClick: (Chapter, Int) -> Unit,
    onBack: () -> Unit,
    isRefreshing: Boolean = false
) {
    BackHandler { onBack() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(series.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${series.chapters.size} chapters",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, "Back")
                    }
                },
                actions = {
                    // Quiet cue that the source folder is being checked for
                    // new chapters in the background. No error UI on
                    // failure (e.g. permission revoked, folder moved) — the
                    // list just stays as it was, same as before this existed.
                    if (isRefreshing) {
                        CircularProgressIndicator(
                            modifier    = Modifier.size(20.dp).padding(end = 12.dp),
                            strokeWidth = 2.dp
                        )
                    }
                },
                colors       = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                windowInsets = WindowInsets(0)
            )
        },
        contentWindowInsets = WindowInsets(0)
    ) { padding ->
        val listState = rememberLazyListState()

        // Resolve the active chapter index from progress (prefer chapterId match)
        val activeIdx = remember(progress, series.chapters) {
            if (progress == null) return@remember -1
            if (progress.chapterId != null) {
                val idx = series.chapters.indexOfFirst { it.id == progress.chapterId }
                if (idx >= 0) return@remember idx
            }
            progress.chapterIndex.coerceIn(0, series.chapters.size - 1)
        }

        // Auto-scroll to the active chapter
        LaunchedEffect(activeIdx) {
            if (activeIdx > 0) listState.scrollToItem(activeIdx)
        }

        LazyColumn(
            state          = listState,
            flingBehavior  = rememberMomentumFlingBehavior(),
            modifier       = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(vertical = 4.dp)
        ) {
            // "Continue reading" banner
            if (progress != null && series.chapters.isNotEmpty()) {
                item(key = "continue_banner") {
                    val ch = series.chapters.getOrNull(activeIdx)
                    if (ch != null) {
                        ContinueBanner(
                            chapterTitle = ch.title,
                            chapterIndex = activeIdx,
                            pageIndex    = progress.pageIndex,
                            onClick      = { onChapterClick(ch, activeIdx) }
                        )
                        HorizontalDivider()
                    }
                }
            }

            itemsIndexed(series.chapters, key = { _, c -> c.id }) { index, chapter ->
                val isCurrent = index == activeIdx
                val isRead    = chapter.id in readChapterIds

                ChapterRow(
                    chapter   = chapter,
                    index     = index,
                    isCurrent = isCurrent,
                    isRead    = isRead,
                    pageHint  = if (isCurrent) progress?.pageIndex else null,
                    onClick   = { onChapterClick(chapter, index) }
                )
                if (index < series.chapters.size - 1) {
                    HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp))
                }
            }
        }
    }
}

@Composable
private fun ContinueBanner(
    chapterTitle: String,
    chapterIndex: Int,
    pageIndex: Int,
    onClick: () -> Unit
) {
    Surface(
        color    = MaterialTheme.colorScheme.primaryContainer,
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)
    ) {
        Row(
            Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.PlayCircle, null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Continue reading",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f))
                Text("$chapterTitle · Page ${pageIndex + 1}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer)
            }
            Icon(Icons.Default.ChevronRight, null,
                tint = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.6f))
        }
    }
}

@Composable
private fun ChapterRow(
    chapter: Chapter,
    index: Int,
    isCurrent: Boolean,
    isRead: Boolean,
    pageHint: Int?,
    onClick: () -> Unit
) {
    val tint = when {
        isCurrent -> MaterialTheme.colorScheme.primary
        isRead    -> MaterialTheme.colorScheme.onSurface.copy(alpha = 0.45f)
        else      -> MaterialTheme.colorScheme.onSurface
    }

    ListItem(
        headlineContent = {
            Text(chapter.title, color = tint, maxLines = 1, overflow = TextOverflow.Ellipsis)
        },
        supportingContent = when {
            pageHint != null -> {{ Text("Page ${pageHint + 1} · In progress",
                color = MaterialTheme.colorScheme.secondary) }}
            isRead           -> {{ Text("Read",
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                style = MaterialTheme.typography.labelSmall) }}
            else             -> null
        },
        leadingContent = {
            Text("${index + 1}",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        },
        trailingContent = when {
            isCurrent -> {{ Icon(Icons.Default.PlayArrow, null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(20.dp)) }}
            isRead    -> {{ Icon(Icons.Default.CheckCircle, "Read",
                tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.3f),
                modifier = Modifier.size(18.dp)) }}
            else      -> null
        },
        colors = ListItemDefaults.colors(
            containerColor = if (isCurrent)
                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.15f)
            else MaterialTheme.colorScheme.background
        ),
        modifier = Modifier
            .clickable(onClick = onClick)
            .semantics { contentDescription = "${chapter.title}, chapter ${index + 1}" }
    )
}
