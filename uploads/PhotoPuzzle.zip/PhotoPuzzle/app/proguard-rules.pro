# Keep any class that declares a native method, and keep that method's name
# and signature exactly as-is. R8 renaming a class/method backing a JNI call
# would silently break System.loadLibrary/native binding at runtime, since
# the .so's exported symbol name is generated from the *original* Java/Kotlin
# name -- there's nothing else in this app that needs protecting from
# shrinking/obfuscation.
-keepclasseswithmembernames,includedescriptorclasses class * {
    native <methods>;
}
