package com.photopuzzle.game.puzzle

import android.graphics.Path

/**
 * Draws one edge of a puzzle piece: either a straight line (grid border,
 * `sign == 0`) or the classic interlocking "tab / blank" knob.
 *
 * This is deliberately the *only* place the knob's curve is defined. Every
 * side of every piece calls through here with different direction/normal
 * vectors (see [PuzzlePieceFactory]) rather than four hand-duplicated
 * copies of the curve -- so the shape only needs tuning in one spot, and
 * top/right/bottom/left can never quietly drift out of sync with each
 * other.
 *
 * The curve itself was designed and verified against a matplotlib
 * prototype (checked interlocking pieces, no self-intersections at any
 * jitter value) before being transcribed here; the control-point ratios
 * below are that exact formula.
 */
internal object PieceEdgeShape {

    private const val NECK = 0.075f
    private const val HEAD = 0.16f
    private const val AMPLITUDE = 0.24f

    /**
     * Appends one edge to [path], whose current point must already be at
     * (startX, startY). The edge runs `length` units in direction
     * (dirX, dirY) and its knob (if any) bulges toward (normalX, normalY)
     * when [sign] is positive, away from it when negative.
     *
     * @param sign -1f, 0f, or +1f. 0f draws a plain straight line (used for
     *   the grid's outer border, which never has a tab).
     * @param jitter small per-edge offset, roughly in [-0.06, 0.06], that
     *   shifts the knob off-center so pieces don't look mechanically
     *   identical. Must be the *same* value (with sign flipped -- see
     *   [PuzzlePieceFactory]) on both pieces that share this edge, or their
     *   outlines won't match.
     */
    fun addEdge(
        path: Path,
        startX: Float,
        startY: Float,
        dirX: Float,
        dirY: Float,
        normalX: Float,
        normalY: Float,
        length: Float,
        sign: Float,
        jitter: Float
    ) {
        if (sign == 0f) {
            path.lineTo(startX + dirX * length, startY + dirY * length)
            return
        }

        val c = 0.5f + jitter
        val amp = AMPLITUDE * sign

        // (t, d) -> world coordinates: t runs along the edge [0,1], d is the
        // perpendicular displacement (in units of `length`) toward the
        // (normalX, normalY) side.
        fun px(t: Float, d: Float) = startX + dirX * t * length + normalX * d * length
        fun py(t: Float, d: Float) = startY + dirY * t * length + normalY * d * length

        path.lineTo(px(c - HEAD - NECK, 0f), py(c - HEAD - NECK, 0f))

        path.cubicTo(
            px(c - HEAD - NECK * 0.25f, 0f), py(c - HEAD - NECK * 0.25f, 0f),
            px(c - HEAD, amp * 0.62f), py(c - HEAD, amp * 0.62f),
            px(c - HEAD, amp * 0.86f), py(c - HEAD, amp * 0.86f)
        )
        path.cubicTo(
            px(c - HEAD, amp * 1.05f), py(c - HEAD, amp * 1.05f),
            px(c - HEAD * 0.62f, amp * 1.24f), py(c - HEAD * 0.62f, amp * 1.24f),
            px(c, amp * 1.24f), py(c, amp * 1.24f)
        )
        path.cubicTo(
            px(c + HEAD * 0.62f, amp * 1.24f), py(c + HEAD * 0.62f, amp * 1.24f),
            px(c + HEAD, amp * 1.05f), py(c + HEAD, amp * 1.05f),
            px(c + HEAD, amp * 0.86f), py(c + HEAD, amp * 0.86f)
        )
        path.cubicTo(
            px(c + HEAD, amp * 0.62f), py(c + HEAD, amp * 0.62f),
            px(c + HEAD + NECK * 0.25f, 0f), py(c + HEAD + NECK * 0.25f, 0f),
            px(c + HEAD + NECK, 0f), py(c + HEAD + NECK, 0f)
        )

        path.lineTo(px(1f, 0f), py(1f, 0f))
    }
}
