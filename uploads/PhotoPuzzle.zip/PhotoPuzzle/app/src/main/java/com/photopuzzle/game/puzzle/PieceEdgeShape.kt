package com.photopuzzle.game.puzzle

import android.graphics.Path

/**
 * Draws one edge of a puzzle piece: either a straight line (grid border,
 * `sign == 0`) or the classic interlocking "tab / blank" knob.
 *
 * This is deliberately the *only* place the knob's curve is defined. Every
 * side of every piece calls through here with different direction/normal
 * vectors (see [PuzzlePieceFactory]) rather than four hand-duplicated
 * copies of the curve -- so the shape only needs tuning in one spot, and
 * top/right/bottom/left can never quietly drift out of sync with each
 * other.
 *
 * The knob's silhouette is described declaratively as a handful of
 * [Knot]s -- base, neck, head, tip, then the mirror image back down to the
 * base -- rather than as a pile of hand-tuned Bezier control points. [knots]
 * *is* the shape: to make the head rounder or the neck narrower, change a
 * number there and every edge of every piece picks it up. [appendSmoothSpline]
 * turns whatever knot sequence it's given into a smooth curve, so the
 * technique is reusable for any future knob shape too, not just this one.
 *
 * The critical property a knob needs -- and a naive single-bump curve
 * doesn't have -- is that the head is genuinely *wider* than the neck
 * (an overhang), the way a real puzzle piece's head is too wide to pull
 * back out through its own neck. [HEAD_HALF_WIDTH] > [NECK_HALF_WIDTH] is
 * what makes that true; verified against a matplotlib prototype (the head
 * silhouette widens past the neck at every jitter value, and no edge
 * self-intersects) before being transcribed here.
 */
internal object PieceEdgeShape {

    /** One point of the knob's silhouette, in edge-local units: [t] is
     * position along the edge (0 = start, 1 = end), [d] is perpendicular
     * displacement toward the tab side (0 = flush with the edge, 1 = the
     * knob's full [AMPLITUDE]). */
    private data class Knot(val t: Float, val d: Float) {
        operator fun plus(other: Knot) = Knot(t + other.t, d + other.d)
        operator fun minus(other: Knot) = Knot(t - other.t, d - other.d)
        operator fun times(scale: Float) = Knot(t * scale, d * scale)
    }

    private const val AMPLITUDE = 0.24f

    // Half-widths (along the edge) and depths (perpendicular into the tab)
    // describing the knob's silhouette, relative to its own center
    // (0.5 + jitter). BASE is where the straight edge bends into the curve;
    // NECK pinches in from there; HEAD flares back out *past* BASE, so the
    // head genuinely overhangs the neck instead of the whole thing just
    // being one smooth, neck-less bump.
    private const val BASE_HALF_WIDTH = 0.15f
    private const val NECK_HALF_WIDTH = 0.075f
    private const val HEAD_HALF_WIDTH = 0.205f
    private const val NECK_DEPTH = 0.38f
    private const val HEAD_DEPTH = 0.80f

    /** Handle length of the two clamped end tangents -- keeps the curve
     * perfectly flat (horizontal in t/d space) right where it meets the
     * straight part of the edge, so there's no visible kink at the join. */
    private const val END_CLAMP = 0.032f

    /** The knob's silhouette, left to right along the edge. Symmetric by
     * construction: mirror any change on one side to its counterpart. */
    private fun knots(center: Float): List<Knot> = listOf(
        Knot(center - BASE_HALF_WIDTH, 0f),
        Knot(center - NECK_HALF_WIDTH, NECK_DEPTH),
        Knot(center - HEAD_HALF_WIDTH, HEAD_DEPTH),
        Knot(center, 1f),
        Knot(center + HEAD_HALF_WIDTH, HEAD_DEPTH),
        Knot(center + NECK_HALF_WIDTH, NECK_DEPTH),
        Knot(center + BASE_HALF_WIDTH, 0f)
    )

    /**
     * Appends one edge to [path], whose current point must already be at
     * (startX, startY). The edge runs `length` units in direction
     * (dirX, dirY) and its knob (if any) bulges toward (normalX, normalY)
     * when [sign] is positive, away from it when negative.
     *
     * @param sign -1f, 0f, or +1f. 0f draws a plain straight line (used for
     *   the grid's outer border, which never has a tab).
     * @param jitter small per-edge offset, roughly in [-0.06, 0.06], that
     *   shifts the knob off-center so pieces don't look mechanically
     *   identical. Must be the *same* value (with sign flipped -- see
     *   [PuzzlePieceFactory]) on both pieces that share this edge, or their
     *   outlines won't match.
     */
    fun addEdge(
        path: Path,
        startX: Float,
        startY: Float,
        dirX: Float,
        dirY: Float,
        normalX: Float,
        normalY: Float,
        length: Float,
        sign: Float,
        jitter: Float
    ) {
        if (sign == 0f) {
            path.lineTo(startX + dirX * length, startY + dirY * length)
            return
        }

        val amp = AMPLITUDE * sign
        fun worldX(k: Knot) = startX + dirX * k.t * length + normalX * k.d * amp * length
        fun worldY(k: Knot) = startY + dirY * k.t * length + normalY * k.d * amp * length

        val silhouette = knots(0.5f + jitter)
        path.lineTo(worldX(silhouette.first()), worldY(silhouette.first()))
        appendSmoothSpline(path, silhouette, ::worldX, ::worldY)
        path.lineTo(startX + dirX * length, startY + dirY * length)
    }

    /**
     * Appends a smooth curve through [knots] (whose first point must
     * already be the path's current point) as a sequence of cubic Beziers.
     * Interior knots get a Catmull-Rom-derived tangent (each control point
     * leans toward its neighbors, giving a natural, non-self-intersecting
     * curve through the whole sequence); the two end knots get a tangent
     * clamped flat in [Knot.d] instead, since those are the points where
     * this curve meets a straight [Path.lineTo] and a mismatched tangent
     * there would show up as a kink.
     *
     * Generic over any knot sequence describing a silhouette this way, so
     * it isn't tied to this particular knob shape.
     */
    private fun appendSmoothSpline(
        path: Path,
        knots: List<Knot>,
        worldX: (Knot) -> Float,
        worldY: (Knot) -> Float
    ) {
        val lastIndex = knots.lastIndex
        for (i in 0 until lastIndex) {
            val start = knots[i]
            val end = knots[i + 1]

            val control1 = if (i == 0) {
                start + Knot(END_CLAMP, 0f)
            } else {
                start + (end - knots[i - 1]) * CATMULL_ROM_TANGENT_SCALE
            }
            val control2 = if (i == lastIndex - 1) {
                end - Knot(END_CLAMP, 0f)
            } else {
                end - (knots[i + 2] - start) * CATMULL_ROM_TANGENT_SCALE
            }

            path.cubicTo(
                worldX(control1), worldY(control1),
                worldX(control2), worldY(control2),
                worldX(end), worldY(end)
            )
        }
    }

    private const val CATMULL_ROM_TANGENT_SCALE = 1f / 6f
}
