package com.photopuzzle.game.puzzle

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.animation.LinearInterpolator
import androidx.core.content.ContextCompat
import com.photopuzzle.game.R
import com.photopuzzle.game.util.ImageUtils
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

class PuzzleBoardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var game: PuzzleGame? = null
    private var referenceBitmap: Bitmap? = null
    private var draggingPiece: PuzzlePiece? = null
    private var lastTouchX = 0f
    private var lastTouchY = 0f
    private var velocityTracker: VelocityTracker? = null

    // Swipe-to-throw: released fast enough, a piece keeps sailing in that
    // direction and decelerates on its own. Driven by FlingPhysics (a
    // constant-deceleration "kinetic friction" model tuned for a short
    // toss across a board a few hundred pixels wide) rather than
    // OverScroller, whose fling curve is built for scrolling through
    // screen-fuls of content and either barely nudges a piece or sends it
    // straight into a wall no matter how gently it was thrown.
    private val flingPhysics by lazy {
        FlingPhysics(FLING_DECELERATION_DP_PER_SEC2 * resources.displayMetrics.density)
    }
    private var flingPiece: PuzzlePiece? = null
    private var lastFlingFrameTimeNanos = 0L
    private val flingTicker = object : Runnable {
        override fun run() {
            val activeGame = game
            val piece = flingPiece
            if (activeGame == null || piece == null) {
                flingPiece = null
                return
            }

            val now = System.nanoTime()
            val deltaSeconds = ((now - lastFlingFrameTimeNanos) / 1_000_000_000f)
                .coerceIn(0f, MAX_FRAME_DELTA_SECONDS)
            lastFlingFrameTimeNanos = now

            val (dx, dy) = flingPhysics.step(deltaSeconds)
            activeGame.moveBy(piece, dx, dy)
            val clamp = clampToBounds(piece.group)
            if (clamp.hitX) flingPhysics.reflectX(WALL_RESTITUTION)
            if (clamp.hitY) flingPhysics.reflectY(WALL_RESTITUTION)

            if (flingPhysics.isRunning) {
                invalidate()
                postOnAnimation(this)
                return
            }

            // Only check for a connection once the piece has actually come
            // to rest. Checking on every in-flight frame would let a piece
            // connect while it's still sailing past at speed -- easy to
            // miss happening at all, and the opposite of the deliberate,
            // "I placed that" feeling a snap should have.
            flingPiece = null
            val connected = activeGame.tryConnect(piece)
            invalidate()
            if (connected) {
                onPiecePlaced?.invoke(activeGame.connectedCount, activeGame.pieceCount)
                triggerSnapPulse(piece.group)
            }
        }
    }

    private val piecePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val referencePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { alpha = REFERENCE_ALPHA }
    private val framePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }

    // Traces each unsolved piece's own jigsaw-cut silhouette so pieces read
    // clearly as individual pieces while assembling; fades away (see
    // [borderAlpha]) once the puzzle is solved, leaving a clean photo.
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = BORDER_STROKE_DP * resources.displayMetrics.density
        strokeJoin = Paint.Join.ROUND
        color = ContextCompat.getColor(context, R.color.colorTextPrimary)
    }

    private val colorFrameGlow = ContextCompat.getColor(context, R.color.colorFrameGlow)
    private val colorFrameBand = ContextCompat.getColor(context, R.color.colorFrameBand)
    private val colorFrameHighlight = ContextCompat.getColor(context, R.color.colorFrameHighlight)

    private val confetti = ConfettiBurst(
        intArrayOf(
            ContextCompat.getColor(context, R.color.colorConfettiGold),
            ContextCompat.getColor(context, R.color.colorConfettiPink),
            ContextCompat.getColor(context, R.color.colorConfettiMint),
            ContextCompat.getColor(context, R.color.colorConfettiSky),
            colorFrameHighlight
        )
    )

    // A quick, satisfying "pop" on the pieces that just connected -- makes
    // a snap read as something that just happened because of where *you*
    // placed the piece, not as the game quietly doing it for you.
    private var snapPulseGroup: PieceGroup? = null
    private var snapPulseScale = 1f
    private var snapPulseCenterX = 0f
    private var snapPulseCenterY = 0f
    private val snapPulseAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = SNAP_PULSE_DURATION_MS
        interpolator = LinearInterpolator()
        addUpdateListener {
            snapPulseScale = pulseScale(it.animatedValue as Float, SNAP_PULSE_PEAK_SCALE)
            invalidate()
        }
        addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                snapPulseGroup = null
                snapPulseScale = 1f
            }
        })
    }

    // The on-solve celebration: borders fade out, the finished picture
    // gives a small satisfied "pop", and confetti drifts down over it.
    private var borderAlpha = 1f
    private var completionScale = 1f
    private var celebrationProgress = 1f // 1f == no celebration in flight
    private val completionAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = COMPLETION_CELEBRATION_DURATION_MS
        interpolator = LinearInterpolator()
        addUpdateListener {
            val progress = it.animatedValue as Float
            celebrationProgress = progress
            borderAlpha = (1f - progress / BORDER_FADE_FRACTION).coerceIn(0f, 1f)
            completionScale = pulseScale(progress / COMPLETION_POP_FRACTION, COMPLETION_POP_PEAK_SCALE)
            invalidate()
        }
    }

    private val snapThresholdPx: Float
        get() = SNAP_THRESHOLD_DP * resources.displayMetrics.density

    private val viewConfiguration by lazy { ViewConfiguration.get(context) }

    var onSolved: (() -> Unit)? = null
    var onPiecePlaced: ((connected: Int, total: Int) -> Unit)? = null

    /**
     * Starts a new puzzle from [sourcePhoto]. This view takes ownership of
     * [sourcePhoto] from this call onward (and of everything derived from
     * it) -- the caller should not use or recycle it afterward; call
     * [recycleAll] (e.g. from `onDestroy`) to free it instead.
     *
     * Waits for layout if this view doesn't have a size yet, since pieces
     * are fit and scattered against the view's actual pixel dimensions.
     */
    fun start(sourcePhoto: Bitmap, rows: Int, cols: Int, seed: Long = System.nanoTime()) {
        if (width == 0 || height == 0) {
            post { start(sourcePhoto, rows, cols, seed) }
            return
        }

        recycleAll()
        resetCelebrationState()

        val fitted = ImageUtils.fitToBounds(sourcePhoto, width, height)
        if (fitted !== sourcePhoto) {
            sourcePhoto.recycle()
        }
        referenceBitmap = fitted

        val pieces = PuzzlePieceFactory.createPieces(fitted, rows, cols, seed).toMutableList()
        val newGame = PuzzleGame(pieces, snapThresholdPx)
        newGame.onSolved = {
            startCompletionCelebration()
            onSolved?.invoke()
        }
        newGame.scatter(width, height, seed)

        game = newGame
        invalidate()
    }

    /** Re-scatters the current puzzle's pieces without re-cutting the image. */
    fun shuffle(seed: Long = System.nanoTime()) {
        stopFling()
        resetCelebrationState()
        game?.scatter(width, height, seed)
        invalidate()
    }

    fun recycleAll() {
        stopFling()
        snapPulseAnimator.cancel()
        completionAnimator.cancel()
        game?.recycleAll()
        referenceBitmap?.takeIf { !it.isRecycled }?.recycle()
        game = null
        referenceBitmap = null
    }

    private fun resetCelebrationState() {
        completionAnimator.cancel()
        snapPulseAnimator.cancel()
        borderAlpha = 1f
        completionScale = 1f
        celebrationProgress = 1f
        snapPulseGroup = null
        snapPulseScale = 1f
    }

    private fun startCompletionCelebration() {
        referenceBitmap?.let { reference ->
            confetti.start(
                centerX = reference.width / 2f,
                topY = 0f,
                spreadWidth = reference.width.toFloat(),
                random = Random(System.nanoTime())
            )
        }
        completionAnimator.cancel()
        completionAnimator.start()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val activeGame = game ?: return
        val reference = referenceBitmap

        canvas.save()
        if (completionScale != 1f && reference != null) {
            canvas.scale(completionScale, completionScale, reference.width / 2f, reference.height / 2f)
        }

        reference?.let {
            drawFrame(canvas, it.width.toFloat(), it.height.toFloat())
            canvas.drawBitmap(it, 0f, 0f, referencePaint)
        }

        borderPaint.alpha = (255 * BORDER_BASE_OPACITY * borderAlpha).toInt().coerceIn(0, 255)
        val showBorders = borderAlpha > 0f
        val pulsingGroup = snapPulseGroup

        for (piece in activeGame.piecesInDrawOrder()) {
            val isPulsing = pulsingGroup != null && piece.group === pulsingGroup
            if (isPulsing) {
                canvas.save()
                canvas.scale(snapPulseScale, snapPulseScale, snapPulseCenterX, snapPulseCenterY)
            }

            canvas.drawBitmap(piece.bitmap, piece.currentX, piece.currentY, piecePaint)
            if (showBorders) {
                canvas.save()
                canvas.translate(piece.currentX, piece.currentY)
                piece.drawOutline(canvas, borderPaint)
                canvas.restore()
            }

            if (isPulsing) canvas.restore()
        }

        canvas.restore()

        if (celebrationProgress < 1f) {
            confetti.draw(
                canvas,
                elapsedSeconds = celebrationProgress * (COMPLETION_CELEBRATION_DURATION_MS / 1000f),
                lifeFraction = celebrationProgress
            )
        }
    }

    /**
     * Draws a simple layered picture frame -- a soft outer glow, a solid
     * band in the app's primary color, and a thin accent trim right at the
     * photo's edge -- around the [w] x [h] "home" area the solved picture
     * belongs in.
     */
    private fun drawFrame(canvas: Canvas, w: Float, h: Float) {
        val density = resources.displayMetrics.density
        val highlightWidth = FRAME_HIGHLIGHT_DP * density
        val bandWidth = FRAME_BAND_DP * density
        val glowWidth = FRAME_GLOW_DP * density
        val corner = FRAME_CORNER_DP * density

        val bandOffset = highlightWidth / 2f + bandWidth / 2f
        val glowOffset = highlightWidth / 2f + bandWidth + glowWidth / 2f

        framePaint.color = colorFrameGlow
        framePaint.strokeWidth = glowWidth
        canvas.drawRoundRect(-glowOffset, -glowOffset, w + glowOffset, h + glowOffset, corner, corner, framePaint)

        framePaint.color = colorFrameBand
        framePaint.strokeWidth = bandWidth
        canvas.drawRoundRect(-bandOffset, -bandOffset, w + bandOffset, h + bandOffset, corner, corner, framePaint)

        framePaint.color = colorFrameHighlight
        framePaint.strokeWidth = highlightWidth
        canvas.drawRoundRect(0f, 0f, w, h, corner, corner, framePaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val activeGame = game ?: return false
        return when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val piece = activeGame.findTopPieceAt(event.x, event.y) ?: return false
                stopFling()
                draggingPiece = piece
                activeGame.bringToFront(piece)
                lastTouchX = event.x
                lastTouchY = event.y
                velocityTracker = VelocityTracker.obtain().apply { addMovement(event) }
                invalidate()
                true
            }
            MotionEvent.ACTION_MOVE -> {
                val piece = draggingPiece ?: return false
                velocityTracker?.addMovement(event)
                activeGame.moveBy(piece, event.x - lastTouchX, event.y - lastTouchY)
                clampToBounds(piece.group)
                lastTouchX = event.x
                lastTouchY = event.y
                invalidate()
                true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val piece = draggingPiece
                draggingPiece = null
                if (piece != null) {
                    var flung = false
                    val tracker = velocityTracker
                    if (event.actionMasked == MotionEvent.ACTION_UP && tracker != null) {
                        val maxVelocity = viewConfiguration.scaledMaximumFlingVelocity.toFloat()
                        tracker.computeCurrentVelocity(1000, maxVelocity)
                        flung = maybeFling(piece, tracker.xVelocity, tracker.yVelocity)
                    }
                    if (!flung) {
                        val connected = activeGame.tryConnect(piece)
                        invalidate()
                        if (connected) {
                            onPiecePlaced?.invoke(activeGame.connectedCount, activeGame.pieceCount)
                            triggerSnapPulse(piece.group)
                        }
                    }
                }
                velocityTracker?.recycle()
                velocityTracker = null
                true
            }
            else -> false
        }
    }

    /**
     * Starts a physics-based fling of [piece]'s group if ([vx], [vy]) is
     * fast enough to count as a deliberate swipe-throw rather than a normal
     * drag release. Returns whether a fling was started.
     */
    private fun maybeFling(piece: PuzzlePiece, vx: Float, vy: Float): Boolean {
        if (sqrt(vx * vx + vy * vy) < viewConfiguration.scaledMinimumFlingVelocity) return false

        flingPiece = piece
        flingPhysics.start(vx, vy)
        lastFlingFrameTimeNanos = System.nanoTime()
        postOnAnimation(flingTicker)
        return true
    }

    private fun stopFling() {
        if (flingPiece != null) {
            flingPhysics.stop()
            flingPiece = null
        }
    }

    private fun triggerSnapPulse(group: PieceGroup) {
        val bounds = groupBounds(group)
        snapPulseCenterX = bounds.centerX()
        snapPulseCenterY = bounds.centerY()
        snapPulseGroup = group
        snapPulseAnimator.cancel()
        snapPulseAnimator.start()
    }

    private fun groupBounds(group: PieceGroup): RectF {
        var left = Float.MAX_VALUE
        var top = Float.MAX_VALUE
        var right = -Float.MAX_VALUE
        var bottom = -Float.MAX_VALUE
        for (member in group.members) {
            left = min(left, member.currentX)
            top = min(top, member.currentY)
            right = max(right, member.currentX + member.width)
            bottom = max(bottom, member.currentY + member.height)
        }
        return RectF(left, top, right, bottom)
    }

    /**
     * Rigidly translates [group] back within the board's pixel bounds if
     * dragging or flinging pushed any of its member pieces past an edge.
     * A group's own footprint is always <= the board (it's built from
     * pieces cut to fit the view), so only *position* ever needs
     * correcting here, never size. Reports which axis (if either) actually
     * hit a wall, so an in-progress fling can bounce off it -- see
     * [FlingPhysics.reflectX]/[FlingPhysics.reflectY].
     */
    private fun clampToBounds(group: PieceGroup): ClampResult {
        val bounds = groupBounds(group)

        var correctionX = 0f
        var correctionY = 0f
        var hitX = false
        var hitY = false
        if (bounds.width() <= width) {
            if (bounds.left < 0f) {
                correctionX = -bounds.left
                hitX = true
            } else if (bounds.right > width) {
                correctionX = width - bounds.right
                hitX = true
            }
        }
        if (bounds.height() <= height) {
            if (bounds.top < 0f) {
                correctionY = -bounds.top
                hitY = true
            } else if (bounds.bottom > height) {
                correctionY = height - bounds.bottom
                hitY = true
            }
        }
        if (correctionX != 0f || correctionY != 0f) group.moveBy(correctionX, correctionY)
        return ClampResult(hitX, hitY)
    }

    companion object {
        /** How long the on-solve celebration (border fade + picture pop +
         * confetti) plays. [PuzzleActivity] reads this too, to delay its
         * own win overlay until the celebration has had room to play out
         * -- kept in one place so the two can't drift apart. */
        const val COMPLETION_CELEBRATION_DURATION_MS = 1100L

        private const val SNAP_THRESHOLD_DP = 12f
        private const val REFERENCE_ALPHA = 36
        private const val FRAME_HIGHLIGHT_DP = 2f
        private const val FRAME_BAND_DP = 9f
        private const val FRAME_GLOW_DP = 14f
        private const val FRAME_CORNER_DP = 6f

        private const val BORDER_STROKE_DP = 1.3f
        private const val BORDER_BASE_OPACITY = 0.4f

        private const val FLING_DECELERATION_DP_PER_SEC2 = 6000f
        private const val WALL_RESTITUTION = 0.22f
        private const val MAX_FRAME_DELTA_SECONDS = 0.05f

        private const val SNAP_PULSE_DURATION_MS = 220L
        private const val SNAP_PULSE_PEAK_SCALE = 0.07f

        private const val BORDER_FADE_FRACTION = 0.4f
        private const val COMPLETION_POP_FRACTION = 0.35f
        private const val COMPLETION_POP_PEAK_SCALE = 0.05f
    }
}

/** Which axis (if either) [PuzzleBoardView] had to push a group back onto
 * the board for, the last time it checked. */
private data class ClampResult(val hitX: Boolean, val hitY: Boolean)

/** A symmetric "pop": 1f at [fraction] 0 and 1, rising to `1f + peak` at
 * the midpoint -- the shape behind both the snap and completion pulses. */
private fun pulseScale(fraction: Float, peak: Float): Float {
    val clamped = fraction.coerceIn(0f, 1f)
    return 1f + peak * sin(PI.toFloat() * clamped)
}
