package com.photopuzzle.game.puzzle

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.widget.OverScroller
import androidx.core.content.ContextCompat
import com.photopuzzle.game.R
import com.photopuzzle.game.util.ImageUtils
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

class PuzzleBoardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var game: PuzzleGame? = null
    private var referenceBitmap: Bitmap? = null
    private var draggingPiece: PuzzlePiece? = null
    private var lastTouchX = 0f
    private var lastTouchY = 0f
    private var velocityTracker: VelocityTracker? = null

    // Swipe-to-throw: released fast enough, a piece keeps sailing in that
    // direction and decelerates on its own, exactly like a fling-scrolled
    // list -- OverScroller already implements that deceleration curve, so
    // we reuse it instead of hand-rolling a physics loop.
    private val scroller = OverScroller(context)
    private var flingPiece: PuzzlePiece? = null
    private var lastFlingX = 0
    private var lastFlingY = 0
    private val flingTicker = object : Runnable {
        override fun run() {
            val activeGame = game
            val piece = flingPiece
            if (activeGame == null || piece == null) {
                flingPiece = null
                return
            }

            val stillMoving = scroller.computeScrollOffset()
            val dx = (scroller.currX - lastFlingX).toFloat()
            val dy = (scroller.currY - lastFlingY).toFloat()
            lastFlingX = scroller.currX
            lastFlingY = scroller.currY

            activeGame.moveBy(piece, dx, dy)
            clampToBounds(piece.group)
            val connected = activeGame.tryConnect(piece)
            invalidate()
            if (connected) {
                onPiecePlaced?.invoke(activeGame.connectedCount, activeGame.pieceCount)
            }

            // A connection stops the fling on the spot -- the piece has
            // somewhere to be now, it shouldn't keep sailing past it.
            if (stillMoving && !connected) {
                postOnAnimation(this)
            } else {
                flingPiece = null
            }
        }
    }

    private val piecePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val referencePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { alpha = REFERENCE_ALPHA }
    private val framePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }

    private val colorFrameGlow = ContextCompat.getColor(context, R.color.colorFrameGlow)
    private val colorFrameBand = ContextCompat.getColor(context, R.color.colorFrameBand)
    private val colorFrameHighlight = ContextCompat.getColor(context, R.color.colorFrameHighlight)

    private val snapThresholdPx: Float
        get() = SNAP_THRESHOLD_DP * resources.displayMetrics.density

    private val viewConfiguration by lazy { ViewConfiguration.get(context) }

    var onSolved: (() -> Unit)? = null
    var onPiecePlaced: ((connected: Int, total: Int) -> Unit)? = null

    /**
     * Starts a new puzzle from [sourcePhoto]. This view takes ownership of
     * [sourcePhoto] from this call onward (and of everything derived from
     * it) -- the caller should not use or recycle it afterward; call
     * [recycleAll] (e.g. from `onDestroy`) to free it instead.
     *
     * Waits for layout if this view doesn't have a size yet, since pieces
     * are fit and scattered against the view's actual pixel dimensions.
     */
    fun start(sourcePhoto: Bitmap, rows: Int, cols: Int, seed: Long = System.nanoTime()) {
        if (width == 0 || height == 0) {
            post { start(sourcePhoto, rows, cols, seed) }
            return
        }

        recycleAll()

        val fitted = ImageUtils.fitToBounds(sourcePhoto, width, height)
        if (fitted !== sourcePhoto) {
            sourcePhoto.recycle()
        }
        referenceBitmap = fitted

        val pieces = PuzzlePieceFactory.createPieces(fitted, rows, cols, seed).toMutableList()
        val newGame = PuzzleGame(pieces, snapThresholdPx)
        newGame.onSolved = { onSolved?.invoke() }
        newGame.scatter(width, height, seed)

        game = newGame
        invalidate()
    }

    /** Re-scatters the current puzzle's pieces without re-cutting the image. */
    fun shuffle(seed: Long = System.nanoTime()) {
        stopFling()
        game?.scatter(width, height, seed)
        invalidate()
    }

    fun recycleAll() {
        stopFling()
        game?.recycleAll()
        referenceBitmap?.takeIf { !it.isRecycled }?.recycle()
        game = null
        referenceBitmap = null
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        referenceBitmap?.let { reference ->
            drawFrame(canvas, reference.width.toFloat(), reference.height.toFloat())
            canvas.drawBitmap(reference, 0f, 0f, referencePaint)
        }
        game?.piecesInDrawOrder()?.forEach { piece ->
            canvas.drawBitmap(piece.bitmap, piece.currentX, piece.currentY, piecePaint)
        }
    }

    /**
     * Draws a simple layered picture frame -- a soft outer glow, a solid
     * band in the app's primary color, and a thin accent trim right at the
     * photo's edge -- around the [w] x [h] "home" area the solved picture
     * belongs in.
     */
    private fun drawFrame(canvas: Canvas, w: Float, h: Float) {
        val density = resources.displayMetrics.density
        val highlightWidth = FRAME_HIGHLIGHT_DP * density
        val bandWidth = FRAME_BAND_DP * density
        val glowWidth = FRAME_GLOW_DP * density
        val corner = FRAME_CORNER_DP * density

        val bandOffset = highlightWidth / 2f + bandWidth / 2f
        val glowOffset = highlightWidth / 2f + bandWidth + glowWidth / 2f

        framePaint.color = colorFrameGlow
        framePaint.strokeWidth = glowWidth
        canvas.drawRoundRect(-glowOffset, -glowOffset, w + glowOffset, h + glowOffset, corner, corner, framePaint)

        framePaint.color = colorFrameBand
        framePaint.strokeWidth = bandWidth
        canvas.drawRoundRect(-bandOffset, -bandOffset, w + bandOffset, h + bandOffset, corner, corner, framePaint)

        framePaint.color = colorFrameHighlight
        framePaint.strokeWidth = highlightWidth
        canvas.drawRoundRect(0f, 0f, w, h, corner, corner, framePaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val activeGame = game ?: return false
        return when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val piece = activeGame.findTopPieceAt(event.x, event.y) ?: return false
                stopFling()
                draggingPiece = piece
                activeGame.bringToFront(piece)
                lastTouchX = event.x
                lastTouchY = event.y
                velocityTracker = VelocityTracker.obtain().apply { addMovement(event) }
                invalidate()
                true
            }
            MotionEvent.ACTION_MOVE -> {
                val piece = draggingPiece ?: return false
                velocityTracker?.addMovement(event)
                activeGame.moveBy(piece, event.x - lastTouchX, event.y - lastTouchY)
                clampToBounds(piece.group)
                lastTouchX = event.x
                lastTouchY = event.y
                invalidate()
                true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val piece = draggingPiece
                draggingPiece = null
                if (piece != null) {
                    var flung = false
                    val tracker = velocityTracker
                    if (event.actionMasked == MotionEvent.ACTION_UP && tracker != null) {
                        val maxVelocity = viewConfiguration.scaledMaximumFlingVelocity.toFloat()
                        tracker.computeCurrentVelocity(1000, maxVelocity)
                        flung = maybeFling(piece, tracker.xVelocity, tracker.yVelocity)
                    }
                    if (!flung) {
                        val connected = activeGame.tryConnect(piece)
                        invalidate()
                        if (connected) {
                            onPiecePlaced?.invoke(activeGame.connectedCount, activeGame.pieceCount)
                        }
                    }
                }
                velocityTracker?.recycle()
                velocityTracker = null
                true
            }
            else -> false
        }
    }

    /**
     * Starts a physics-based fling of [piece]'s group if ([vx], [vy]) is
     * fast enough to count as a deliberate swipe-throw rather than a normal
     * drag release. Returns whether a fling was started.
     */
    private fun maybeFling(piece: PuzzlePiece, vx: Float, vy: Float): Boolean {
        if (sqrt(vx * vx + vy * vy) < viewConfiguration.scaledMinimumFlingVelocity) return false

        flingPiece = piece
        scroller.forceFinished(true)
        lastFlingX = 0
        lastFlingY = 0
        // start is (0, 0): we only ever read *deltas* between consecutive
        // frames off the scroller (see flingTicker) and apply those to the
        // piece's own position, so the scroller's own coordinate origin is
        // irrelevant. The min/max bounds are wide open -- real bounds come
        // from clampToBounds() every frame instead of OverScroller's own
        // edge behavior, which is built for scroll-and-bounce, not this.
        scroller.fling(
            0, 0,
            vx.toInt(), vy.toInt(),
            Int.MIN_VALUE / 2, Int.MAX_VALUE / 2,
            Int.MIN_VALUE / 2, Int.MAX_VALUE / 2
        )
        postOnAnimation(flingTicker)
        return true
    }

    private fun stopFling() {
        if (flingPiece != null) {
            scroller.forceFinished(true)
            flingPiece = null
        }
    }

    /**
     * Rigidly translates [group] back within the board's pixel bounds if
     * dragging or flinging pushed any of its member pieces past an edge.
     * A group's own footprint is always <= the board (it's built from
     * pieces cut to fit the view), so only *position* ever needs
     * correcting here, never size.
     */
    private fun clampToBounds(group: PieceGroup) {
        var left = Float.MAX_VALUE
        var top = Float.MAX_VALUE
        var right = -Float.MAX_VALUE
        var bottom = -Float.MAX_VALUE
        for (member in group.members) {
            left = min(left, member.currentX)
            top = min(top, member.currentY)
            right = max(right, member.currentX + member.width)
            bottom = max(bottom, member.currentY + member.height)
        }

        var correctionX = 0f
        var correctionY = 0f
        if (right - left <= width) {
            if (left < 0f) correctionX = -left
            else if (right > width) correctionX = width - right
        }
        if (bottom - top <= height) {
            if (top < 0f) correctionY = -top
            else if (bottom > height) correctionY = height - bottom
        }
        if (correctionX != 0f || correctionY != 0f) group.moveBy(correctionX, correctionY)
    }

    private companion object {
        const val SNAP_THRESHOLD_DP = 26f
        const val REFERENCE_ALPHA = 36
        const val FRAME_HIGHLIGHT_DP = 2f
        const val FRAME_BAND_DP = 9f
        const val FRAME_GLOW_DP = 14f
        const val FRAME_CORNER_DP = 6f
    }
}
