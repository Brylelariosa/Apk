package com.photopuzzle.game.puzzle

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import com.photopuzzle.game.util.ImageUtils

class PuzzleBoardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var game: PuzzleGame? = null
    private var referenceBitmap: Bitmap? = null
    private var draggingPiece: PuzzlePiece? = null
    private var lastTouchX = 0f
    private var lastTouchY = 0f

    private val piecePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val referencePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { alpha = REFERENCE_ALPHA }

    private val snapThresholdPx: Float
        get() = SNAP_THRESHOLD_DP * resources.displayMetrics.density

    var onSolved: (() -> Unit)? = null
    var onPiecePlaced: ((locked: Int, total: Int) -> Unit)? = null

    /**
     * Starts a new puzzle from [sourcePhoto]. This view takes ownership of
     * [sourcePhoto] from this call onward (and of everything derived from
     * it) -- the caller should not use or recycle it afterward; call
     * [recycleAll] (e.g. from `onDestroy`) to free it instead.
     *
     * Waits for layout if this view doesn't have a size yet, since pieces
     * are fit and scattered against the view's actual pixel dimensions.
     */
    fun start(sourcePhoto: Bitmap, rows: Int, cols: Int, seed: Long = System.nanoTime()) {
        if (width == 0 || height == 0) {
            post { start(sourcePhoto, rows, cols, seed) }
            return
        }

        recycleAll()

        val fitted = ImageUtils.fitToBounds(sourcePhoto, width, height)
        if (fitted !== sourcePhoto) {
            sourcePhoto.recycle()
        }
        referenceBitmap = fitted

        val pieces = PuzzlePieceFactory.createPieces(fitted, rows, cols, seed).toMutableList()
        val newGame = PuzzleGame(pieces, snapThresholdPx)
        newGame.onSolved = { onSolved?.invoke() }
        newGame.scatter(width, height, seed)

        game = newGame
        invalidate()
    }

    /** Re-scatters the current puzzle's pieces without re-cutting the image. */
    fun shuffle(seed: Long = System.nanoTime()) {
        game?.scatter(width, height, seed)
        invalidate()
    }

    fun recycleAll() {
        game?.recycleAll()
        referenceBitmap?.takeIf { !it.isRecycled }?.recycle()
        game = null
        referenceBitmap = null
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        referenceBitmap?.let { canvas.drawBitmap(it, 0f, 0f, referencePaint) }
        game?.piecesInDrawOrder()?.forEach { piece ->
            canvas.drawBitmap(piece.bitmap, piece.currentX, piece.currentY, piecePaint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val activeGame = game ?: return false
        return when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val piece = activeGame.findTopPieceAt(event.x, event.y) ?: return false
                draggingPiece = piece
                activeGame.bringToFront(piece)
                lastTouchX = event.x
                lastTouchY = event.y
                invalidate()
                true
            }
            MotionEvent.ACTION_MOVE -> {
                val piece = draggingPiece ?: return false
                activeGame.moveBy(piece, event.x - lastTouchX, event.y - lastTouchY)
                lastTouchX = event.x
                lastTouchY = event.y
                invalidate()
                true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val piece = draggingPiece
                draggingPiece = null
                if (piece != null) {
                    val snapped = activeGame.trySnap(piece)
                    invalidate()
                    if (snapped) {
                        onPiecePlaced?.invoke(activeGame.lockedCount, activeGame.pieceCount)
                    }
                }
                true
            }
            else -> false
        }
    }

    private companion object {
        const val SNAP_THRESHOLD_DP = 26f
        const val REFERENCE_ALPHA = 36
    }
}
