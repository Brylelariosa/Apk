package com.photopuzzle.game.puzzle

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import androidx.core.content.ContextCompat
import com.photopuzzle.game.R
import com.photopuzzle.game.util.ImageUtils
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

class PuzzleBoardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var game: PuzzleGame? = null
    private var referenceBitmap: Bitmap? = null
    private var draggingPiece: PuzzlePiece? = null
    private var lastTouchX = 0f
    private var lastTouchY = 0f
    private var velocityTracker: VelocityTracker? = null

    // Swipe-to-throw: released fast enough, a piece keeps sailing in that
    // direction and decelerates on its own. Driven by FlingPhysics (a
    // constant-deceleration "kinetic friction" model tuned for a short
    // toss across a board a few hundred pixels wide) rather than
    // OverScroller, whose fling curve is built for scrolling through
    // screen-fuls of content and either barely nudges a piece or sends it
    // straight into a wall no matter how gently it was thrown.
    private val flingPhysics by lazy {
        FlingPhysics(FLING_DECELERATION_DP_PER_SEC2 * resources.displayMetrics.density)
    }
    private var flingPiece: PuzzlePiece? = null
    private var lastFlingFrameTimeNanos = 0L
    private val flingTicker = object : Runnable {
        override fun run() {
            val activeGame = game
            val piece = flingPiece
            if (activeGame == null || piece == null) {
                flingPiece = null
                return
            }

            val now = System.nanoTime()
            val deltaSeconds = ((now - lastFlingFrameTimeNanos) / 1_000_000_000f)
                .coerceIn(0f, MAX_FRAME_DELTA_SECONDS)
            lastFlingFrameTimeNanos = now

            val (dx, dy) = flingPhysics.step(deltaSeconds)
            activeGame.moveBy(piece, dx, dy)
            val clamp = clampToBounds(piece.group)
            if (clamp.hitX) flingPhysics.reflectX(WALL_RESTITUTION)
            if (clamp.hitY) flingPhysics.reflectY(WALL_RESTITUTION)
            updateFlingTilt()

            if (flingPhysics.isRunning) {
                invalidate()
                postOnAnimation(this)
                return
            }

            // Only check for a connection once the piece has actually come
            // to rest. Checking on every in-flight frame would let a piece
            // connect while it's still sailing past at speed -- easy to
            // miss happening at all, and the opposite of the deliberate,
            // "I placed that" feeling a snap should have.
            flingPiece = null
            val connected = activeGame.tryConnect(piece)
            beginSettle()
            invalidate()
            if (connected) {
                onPiecePlaced?.invoke(activeGame.connectedCount, activeGame.pieceCount)
                triggerSnapPulse(piece.group)
            }
        }
    }

    /** Fling-driven counterpart to [updateDragTilt]: keeps the piece tilted
     * into its direction of travel while it's still sailing, scaled off
     * the fling's own current velocity instead of a per-event touch delta. */
    private fun updateFlingTilt() {
        val target = (flingPhysics.velocityX * TILT_DEGREES_PER_VELOCITY_PXPS)
            .coerceIn(-MAX_TILT_DEGREES, MAX_TILT_DEGREES)
        liftTiltDegrees += (target - liftTiltDegrees) * TILT_RESPONSIVENESS
    }

    private val piecePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val referencePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { alpha = REFERENCE_ALPHA }
    private val framePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }

    // Traces each unsolved piece's own jigsaw-cut silhouette so pieces read
    // clearly as individual pieces while assembling; fades away (see
    // [borderAlpha]) once the puzzle is solved, leaving a clean photo.
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = BORDER_STROKE_DP * resources.displayMetrics.density
        strokeJoin = Paint.Join.ROUND
        color = ContextCompat.getColor(context, R.color.colorTextPrimary)
    }

    // The always-visible sliver simulating each piece's own physical edge
    // (see drawThickness()), and the larger, fainter cast shadow shown only
    // under the piece currently being lifted. Both flat fills rather than a
    // blurred shadow -- BlurMaskFilter isn't reliably supported on a
    // hardware-accelerated Canvas -- with alpha set per-frame rather than
    // baked into the color, the same way [borderPaint] reuses an opaque
    // color at a runtime alpha above.
    private val thicknessPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = ContextCompat.getColor(context, R.color.colorPieceThickness)
    }
    private val elevationShadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = ContextCompat.getColor(context, R.color.colorPieceShadow)
    }

    private val colorFrameGlow = ContextCompat.getColor(context, R.color.colorFrameGlow)
    private val colorFrameBand = ContextCompat.getColor(context, R.color.colorFrameBand)
    private val colorFrameHighlight = ContextCompat.getColor(context, R.color.colorFrameHighlight)

    private val confetti = ConfettiBurst(
        intArrayOf(
            ContextCompat.getColor(context, R.color.colorConfettiGold),
            ContextCompat.getColor(context, R.color.colorConfettiPink),
            ContextCompat.getColor(context, R.color.colorConfettiMint),
            ContextCompat.getColor(context, R.color.colorConfettiSky),
            colorFrameHighlight
        )
    )

    // The piece (or connected group) currently being handled -- grabbed and
    // not yet released, or still sailing from a fling -- rendered enlarged,
    // tilted, and with an extra cast shadow (see drawPiece(),
    // drawThickness()) so it reads as having been lifted off the board.
    private var liftedGroup: PieceGroup? = null
    private var liftAmount = 0f
    private var liftTiltDegrees = 0f
    private var settleStartLift = 0f
    private var settleStartTilt = 0f

    private val liftUpAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = LIFT_UP_DURATION_MS
        interpolator = OvershootInterpolator(1.1f)
        addUpdateListener {
            liftAmount = it.animatedValue as Float
            invalidate()
        }
    }

    // Eases liftAmount/liftTiltDegrees back down from wherever they
    // currently are (not necessarily "fully lifted") to resting (0f/0f),
    // since a piece can be released mid pick-up animation or mid-tilt.
    private val settleAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = SETTLE_DURATION_MS
        interpolator = DecelerateInterpolator()
        addUpdateListener {
            val remaining = 1f - (it.animatedValue as Float)
            liftAmount = settleStartLift * remaining
            liftTiltDegrees = settleStartTilt * remaining
            invalidate()
        }
        addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                liftedGroup = null
                liftAmount = 0f
                liftTiltDegrees = 0f
            }
        })
    }

    /**
     * Starts the pick-up animation for [group] and marks it as the piece
     * currently being handled, so [drawPiece] renders it enlarged with a
     * cast shadow (see [drawThickness]) until it's released again.
     *
     * Deliberately keeps only one such group in flight at a time -- if a
     * different group was still mid-[beginSettle] when this is called (a
     * fast re-grab within roughly [SETTLE_DURATION_MS]), that older
     * group's settle is cut short rather than tracked to completion. In
     * practice this is a rare, sub-quarter-second edge case, and simpler
     * than threading a whole animation queue through what's otherwise a
     * single-piece-at-a-time interaction.
     */
    private fun beginLift(group: PieceGroup) {
        settleAnimator.cancel()
        liftedGroup = group
        liftTiltDegrees = 0f
        liftUpAnimator.cancel()
        liftUpAnimator.start()
    }

    /**
     * Starts animating the currently-lifted group back down to resting
     * size (and its tilt back to level) from wherever [liftAmount] /
     * [liftTiltDegrees] currently are -- called once a drag ends without a
     * fling, or a fling comes to rest.
     */
    private fun beginSettle() {
        liftUpAnimator.cancel()
        settleStartLift = liftAmount
        settleStartTilt = liftTiltDegrees
        settleAnimator.cancel()
        settleAnimator.start()
    }

    // A quick, satisfying "pop" on the pieces that just connected -- makes
    // a snap read as something that just happened because of where *you*
    // placed the piece, not as the game quietly doing it for you.
    private var snapPulseGroup: PieceGroup? = null
    private var snapPulseScale = 1f
    private var snapPulseCenterX = 0f
    private var snapPulseCenterY = 0f
    private val snapPulseAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = SNAP_PULSE_DURATION_MS
        interpolator = LinearInterpolator()
        addUpdateListener {
            snapPulseScale = pulseScale(it.animatedValue as Float, SNAP_PULSE_PEAK_SCALE)
            invalidate()
        }
        addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                snapPulseGroup = null
                snapPulseScale = 1f
            }
        })
    }

    // The on-solve celebration: borders fade out, the finished picture
    // gives a small satisfied "pop", and confetti drifts down over it.
    private var borderAlpha = 1f
    private var completionScale = 1f
    private var celebrationProgress = 1f // 1f == no celebration in flight
    private val completionAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = COMPLETION_CELEBRATION_DURATION_MS
        interpolator = LinearInterpolator()
        addUpdateListener {
            val progress = it.animatedValue as Float
            celebrationProgress = progress
            borderAlpha = (1f - progress / BORDER_FADE_FRACTION).coerceIn(0f, 1f)
            completionScale = pulseScale(progress / COMPLETION_POP_FRACTION, COMPLETION_POP_PEAK_SCALE)
            invalidate()
        }
    }

    private val snapThresholdPx: Float
        get() = SNAP_THRESHOLD_DP * resources.displayMetrics.density

    private val viewConfiguration by lazy { ViewConfiguration.get(context) }

    var onSolved: (() -> Unit)? = null
    var onPiecePlaced: ((connected: Int, total: Int) -> Unit)? = null

    /**
     * Starts a new puzzle from [sourcePhoto]. This view takes ownership of
     * [sourcePhoto] from this call onward (and of everything derived from
     * it) -- the caller should not use or recycle it afterward; call
     * [recycleAll] (e.g. from `onDestroy`) to free it instead.
     *
     * Waits for layout if this view doesn't have a size yet, since pieces
     * are fit and scattered against the view's actual pixel dimensions.
     */
    fun start(sourcePhoto: Bitmap, rows: Int, cols: Int, seed: Long = System.nanoTime()) {
        if (width == 0 || height == 0) {
            post { start(sourcePhoto, rows, cols, seed) }
            return
        }

        recycleAll()
        resetCelebrationState()

        val fitted = ImageUtils.fitToBounds(sourcePhoto, width, height)
        if (fitted !== sourcePhoto) {
            sourcePhoto.recycle()
        }
        referenceBitmap = fitted

        val pieces = PuzzlePieceFactory.createPieces(fitted, rows, cols, seed).toMutableList()
        val newGame = PuzzleGame(pieces, snapThresholdPx)
        newGame.onSolved = {
            startCompletionCelebration()
            onSolved?.invoke()
        }
        newGame.scatter(width, height, seed)

        game = newGame
        invalidate()
    }

    /** Re-scatters the current puzzle's pieces without re-cutting the image. */
    fun shuffle(seed: Long = System.nanoTime()) {
        stopFling()
        resetCelebrationState()
        game?.scatter(width, height, seed)
        invalidate()
    }

    fun recycleAll() {
        stopFling()
        snapPulseAnimator.cancel()
        completionAnimator.cancel()
        liftUpAnimator.cancel()
        settleAnimator.cancel()
        game?.recycleAll()
        referenceBitmap?.takeIf { !it.isRecycled }?.recycle()
        game = null
        referenceBitmap = null
    }

    private fun resetCelebrationState() {
        completionAnimator.cancel()
        snapPulseAnimator.cancel()
        borderAlpha = 1f
        completionScale = 1f
        celebrationProgress = 1f
        snapPulseGroup = null
        snapPulseScale = 1f
        resetInteractionState()
    }

    /** Clears any in-progress pick-up/settle/tilt state -- called whenever
     * a puzzle (re)starts, since a fresh (or reshuffled) board should
     * never inherit a "lifted" piece left over from whatever came before. */
    private fun resetInteractionState() {
        liftUpAnimator.cancel()
        settleAnimator.cancel()
        liftedGroup = null
        liftAmount = 0f
        liftTiltDegrees = 0f
    }

    private fun startCompletionCelebration() {
        referenceBitmap?.let { reference ->
            confetti.start(
                centerX = reference.width / 2f,
                topY = 0f,
                spreadWidth = reference.width.toFloat(),
                random = Random(System.nanoTime())
            )
        }
        completionAnimator.cancel()
        completionAnimator.start()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val activeGame = game ?: return
        val reference = referenceBitmap

        canvas.save()
        if (completionScale != 1f && reference != null) {
            canvas.scale(completionScale, completionScale, reference.width / 2f, reference.height / 2f)
        }

        reference?.let {
            drawFrame(canvas, it.width.toFloat(), it.height.toFloat())
            canvas.drawBitmap(it, 0f, 0f, referencePaint)
        }

        borderPaint.alpha = (255 * BORDER_BASE_OPACITY * borderAlpha).toInt().coerceIn(0, 255)
        thicknessPaint.alpha = (255 * THICKNESS_BASE_OPACITY * borderAlpha).toInt().coerceIn(0, 255)
        val showBorders = borderAlpha > 0f
        val pulsingGroup = snapPulseGroup
        val lifted = liftedGroup
        val liftBounds = if (lifted != null && liftAmount > 0f) groupBounds(lifted) else null
        val density = resources.displayMetrics.density

        for (piece in activeGame.piecesInDrawOrder()) {
            drawPiece(canvas, piece, pulsingGroup, lifted, liftBounds, showBorders, density)
        }

        canvas.restore()

        if (celebrationProgress < 1f) {
            confetti.draw(
                canvas,
                elapsedSeconds = celebrationProgress * (COMPLETION_CELEBRATION_DURATION_MS / 1000f),
                lifeFraction = celebrationProgress
            )
        }
    }

    /**
     * Draws one piece: its thickness/shadow, its bitmap, and (while
     * unsolved) its border -- enlarged and tilted about [liftBounds]'s
     * center first if it belongs to [liftedGroup], and/or pulsed about the
     * snap-pulse center if it belongs to [pulsingGroup]. A piece can be in
     * both at once (the group that was just dragged is usually the same
     * one that just snapped), in which case both transforms apply.
     */
    private fun drawPiece(
        canvas: Canvas,
        piece: PuzzlePiece,
        pulsingGroup: PieceGroup?,
        liftedGroup: PieceGroup?,
        liftBounds: RectF?,
        showBorders: Boolean,
        density: Float
    ) {
        val isPulsing = pulsingGroup != null && piece.group === pulsingGroup
        val isLifted = liftBounds != null && liftedGroup != null && piece.group === liftedGroup
        val needsTransform = isPulsing || isLifted

        if (needsTransform) canvas.save()
        if (isLifted && liftBounds != null) {
            val scale = 1f + liftAmount.coerceAtLeast(0f) * LIFT_SCALE_FACTOR
            canvas.scale(scale, scale, liftBounds.centerX(), liftBounds.centerY())
            canvas.rotate(liftTiltDegrees, liftBounds.centerX(), liftBounds.centerY())
        }
        if (isPulsing) {
            canvas.scale(snapPulseScale, snapPulseScale, snapPulseCenterX, snapPulseCenterY)
        }

        drawThickness(canvas, piece, if (isLifted) liftAmount.coerceAtLeast(0f) else 0f, density)
        canvas.drawBitmap(piece.bitmap, piece.currentX, piece.currentY, piecePaint)
        if (showBorders) {
            canvas.save()
            canvas.translate(piece.currentX, piece.currentY)
            piece.drawSilhouette(canvas, borderPaint)
            canvas.restore()
        }

        if (needsTransform) canvas.restore()
    }

    /**
     * Draws this piece's "physical" side: a thin sliver always visible
     * just behind it, simulating a piece with some real thickness rather
     * than a paper-flat cutout, plus -- while [liftAmount] is above zero
     * -- a larger, fainter cast shadow that grows as the piece rises off
     * the board.
     *
     * Both are flat, unblurred fills rather than a softened/blurred
     * shadow: [android.graphics.BlurMaskFilter] isn't reliably supported
     * on a hardware-accelerated [Canvas] (this view's default), so a
     * genuinely blurred shadow would need its own offscreen
     * software-rendered bitmap per piece for what's meant to be a subtle
     * touch. Growing a plain flat shape's size, offset, and alpha together
     * reads as "soft and lifting" at this scale without any of that.
     */
    private fun drawThickness(canvas: Canvas, piece: PuzzlePiece, liftAmount: Float, density: Float) {
        canvas.save()
        canvas.translate(piece.currentX, piece.currentY)

        if (liftAmount > 0f) {
            val shadowOffset = (THICKNESS_OFFSET_DP + liftAmount * ELEVATION_MAX_OFFSET_DP) * density
            val shadowScale = 1f + liftAmount * ELEVATION_MAX_SCALE_BONUS
            elevationShadowPaint.alpha =
                (ELEVATION_SHADOW_MAX_ALPHA * liftAmount).roundToInt().coerceIn(0, 255)
            canvas.save()
            canvas.translate(shadowOffset, shadowOffset)
            canvas.scale(shadowScale, shadowScale, piece.width / 2f, piece.height / 2f)
            piece.drawSilhouette(canvas, elevationShadowPaint)
            canvas.restore()
        }

        canvas.translate(THICKNESS_OFFSET_DP * density, THICKNESS_OFFSET_DP * density)
        piece.drawSilhouette(canvas, thicknessPaint)
        canvas.restore()
    }

    /**
     * Draws a simple layered picture frame -- a soft outer glow, a solid
     * band in the app's primary color, and a thin accent trim right at the
     * photo's edge -- around the [w] x [h] "home" area the solved picture
     * belongs in.
     */
    private fun drawFrame(canvas: Canvas, w: Float, h: Float) {
        val density = resources.displayMetrics.density
        val highlightWidth = FRAME_HIGHLIGHT_DP * density
        val bandWidth = FRAME_BAND_DP * density
        val glowWidth = FRAME_GLOW_DP * density
        val corner = FRAME_CORNER_DP * density

        val bandOffset = highlightWidth / 2f + bandWidth / 2f
        val glowOffset = highlightWidth / 2f + bandWidth + glowWidth / 2f

        framePaint.color = colorFrameGlow
        framePaint.strokeWidth = glowWidth
        canvas.drawRoundRect(-glowOffset, -glowOffset, w + glowOffset, h + glowOffset, corner, corner, framePaint)

        framePaint.color = colorFrameBand
        framePaint.strokeWidth = bandWidth
        canvas.drawRoundRect(-bandOffset, -bandOffset, w + bandOffset, h + bandOffset, corner, corner, framePaint)

        framePaint.color = colorFrameHighlight
        framePaint.strokeWidth = highlightWidth
        canvas.drawRoundRect(0f, 0f, w, h, corner, corner, framePaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val activeGame = game ?: return false
        return when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val piece = activeGame.findTopPieceAt(event.x, event.y) ?: return false
                stopFling()
                draggingPiece = piece
                activeGame.bringToFront(piece)
                lastTouchX = event.x
                lastTouchY = event.y
                velocityTracker = VelocityTracker.obtain().apply { addMovement(event) }
                beginLift(piece.group)
                invalidate()
                true
            }
            MotionEvent.ACTION_MOVE -> {
                val piece = draggingPiece ?: return false
                velocityTracker?.addMovement(event)
                val dx = event.x - lastTouchX
                activeGame.moveBy(piece, dx, event.y - lastTouchY)
                clampToBounds(piece.group)
                updateDragTilt(dx)
                lastTouchX = event.x
                lastTouchY = event.y
                invalidate()
                true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val piece = draggingPiece
                draggingPiece = null
                if (piece != null) {
                    var flung = false
                    val tracker = velocityTracker
                    if (event.actionMasked == MotionEvent.ACTION_UP && tracker != null) {
                        val maxVelocity = viewConfiguration.scaledMaximumFlingVelocity.toFloat()
                        tracker.computeCurrentVelocity(1000, maxVelocity)
                        flung = maybeFling(piece, tracker.xVelocity, tracker.yVelocity)
                    }
                    if (!flung) {
                        val connected = activeGame.tryConnect(piece)
                        beginSettle()
                        invalidate()
                        if (connected) {
                            onPiecePlaced?.invoke(activeGame.connectedCount, activeGame.pieceCount)
                            triggerSnapPulse(piece.group)
                        }
                    }
                }
                velocityTracker?.recycle()
                velocityTracker = null
                true
            }
            else -> false
        }
    }

    /** Nudges [liftTiltDegrees] toward a target derived from this move
     * event's horizontal delta -- eased rather than snapped straight to
     * it, so the piece reads as trailing behind the finger a beat, the
     * way something with real weight would, rather than rotating in
     * lockstep. */
    private fun updateDragTilt(dx: Float) {
        val target = (dx * TILT_DEGREES_PER_PX).coerceIn(-MAX_TILT_DEGREES, MAX_TILT_DEGREES)
        liftTiltDegrees += (target - liftTiltDegrees) * TILT_RESPONSIVENESS
    }

    /**
     * Starts a physics-based fling of [piece]'s group if ([vx], [vy]) is
     * fast enough to count as a deliberate swipe-throw rather than a normal
     * drag release. Returns whether a fling was started.
     */
    private fun maybeFling(piece: PuzzlePiece, vx: Float, vy: Float): Boolean {
        if (sqrt(vx * vx + vy * vy) < viewConfiguration.scaledMinimumFlingVelocity) return false

        flingPiece = piece
        flingPhysics.start(vx, vy)
        lastFlingFrameTimeNanos = System.nanoTime()
        postOnAnimation(flingTicker)
        return true
    }

    private fun stopFling() {
        if (flingPiece != null) {
            flingPhysics.stop()
            flingPiece = null
        }
    }

    private fun triggerSnapPulse(group: PieceGroup) {
        val bounds = groupBounds(group)
        snapPulseCenterX = bounds.centerX()
        snapPulseCenterY = bounds.centerY()
        snapPulseGroup = group
        snapPulseAnimator.cancel()
        snapPulseAnimator.start()
    }

    private fun groupBounds(group: PieceGroup): RectF {
        var left = Float.MAX_VALUE
        var top = Float.MAX_VALUE
        var right = -Float.MAX_VALUE
        var bottom = -Float.MAX_VALUE
        for (member in group.members) {
            left = min(left, member.currentX)
            top = min(top, member.currentY)
            right = max(right, member.currentX + member.width)
            bottom = max(bottom, member.currentY + member.height)
        }
        return RectF(left, top, right, bottom)
    }

    /**
     * Rigidly translates [group] back within the board's pixel bounds if
     * dragging or flinging pushed any of its member pieces past an edge.
     * A group's own footprint is always <= the board (it's built from
     * pieces cut to fit the view), so only *position* ever needs
     * correcting here, never size. Reports which axis (if either) actually
     * hit a wall, so an in-progress fling can bounce off it -- see
     * [FlingPhysics.reflectX]/[FlingPhysics.reflectY].
     */
    private fun clampToBounds(group: PieceGroup): ClampResult {
        val bounds = groupBounds(group)

        var correctionX = 0f
        var correctionY = 0f
        var hitX = false
        var hitY = false
        if (bounds.width() <= width) {
            if (bounds.left < 0f) {
                correctionX = -bounds.left
                hitX = true
            } else if (bounds.right > width) {
                correctionX = width - bounds.right
                hitX = true
            }
        }
        if (bounds.height() <= height) {
            if (bounds.top < 0f) {
                correctionY = -bounds.top
                hitY = true
            } else if (bounds.bottom > height) {
                correctionY = height - bounds.bottom
                hitY = true
            }
        }
        if (correctionX != 0f || correctionY != 0f) group.moveBy(correctionX, correctionY)
        return ClampResult(hitX, hitY)
    }

    companion object {
        /** How long the on-solve celebration (border fade + picture pop +
         * confetti) plays. [PuzzleActivity] reads this too, to delay its
         * own win overlay until the celebration has had room to play out
         * -- kept in one place so the two can't drift apart. */
        const val COMPLETION_CELEBRATION_DURATION_MS = 1100L

        private const val SNAP_THRESHOLD_DP = 12f
        private const val REFERENCE_ALPHA = 36
        private const val FRAME_HIGHLIGHT_DP = 2f
        private const val FRAME_BAND_DP = 9f
        private const val FRAME_GLOW_DP = 14f
        private const val FRAME_CORNER_DP = 6f

        private const val BORDER_STROKE_DP = 1.3f
        private const val BORDER_BASE_OPACITY = 0.4f

        private const val FLING_DECELERATION_DP_PER_SEC2 = 6000f
        private const val WALL_RESTITUTION = 0.22f
        private const val MAX_FRAME_DELTA_SECONDS = 0.05f

        private const val SNAP_PULSE_DURATION_MS = 220L
        private const val SNAP_PULSE_PEAK_SCALE = 0.07f

        private const val BORDER_FADE_FRACTION = 0.4f
        private const val COMPLETION_POP_FRACTION = 0.35f
        private const val COMPLETION_POP_PEAK_SCALE = 0.05f

        // Picking a piece up: how much bigger it renders at full lift, how
        // long the pop-up/settle-down take, and how far it tilts as it's
        // dragged or flung -- see beginLift()/beginSettle() and
        // updateDragTilt()/updateFlingTilt().
        private const val LIFT_SCALE_FACTOR = 0.16f
        private const val LIFT_UP_DURATION_MS = 160L
        private const val SETTLE_DURATION_MS = 220L
        private const val MAX_TILT_DEGREES = 6f
        private const val TILT_DEGREES_PER_PX = 0.6f
        private const val TILT_DEGREES_PER_VELOCITY_PXPS = 0.0018f
        private const val TILT_RESPONSIVENESS = 0.35f

        // The piece's always-on "thickness" sliver and the extra cast
        // shadow shown only while it's lifted -- see drawThickness().
        private const val THICKNESS_OFFSET_DP = 2f
        private const val THICKNESS_BASE_OPACITY = 0.55f
        private const val ELEVATION_MAX_OFFSET_DP = 12f
        private const val ELEVATION_MAX_SCALE_BONUS = 0.05f
        private const val ELEVATION_SHADOW_MAX_ALPHA = 130
    }
}

/** Which axis (if either) [PuzzleBoardView] had to push a group back onto
 * the board for, the last time it checked. */
private data class ClampResult(val hitX: Boolean, val hitY: Boolean)

/** A symmetric "pop": 1f at [fraction] 0 and 1, rising to `1f + peak` at
 * the midpoint -- the shape behind both the snap and completion pulses. */
private fun pulseScale(fraction: Float, peak: Float): Float {
    val clamped = fraction.coerceIn(0f, 1f)
    return 1f + peak * sin(PI.toFloat() * clamped)
}
