package com.photopuzzle.game.puzzle

import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Region

/**
 * One cut-out jigsaw piece.
 *
 * [homeX]/[homeY] and [outline] are in the same coordinate space as the
 * board's source bitmap (see [PuzzlePieceFactory]); [currentX]/[currentY]
 * are updated as the player drags the piece around the board.
 */
internal class PuzzlePiece(
    val row: Int,
    val col: Int,
    val bitmap: Bitmap,
    private val outline: Path,
    val homeX: Float,
    val homeY: Float
) {
    val width: Int get() = bitmap.width
    val height: Int get() = bitmap.height

    var currentX: Float = homeX
    var currentY: Float = homeY

    var locked: Boolean = false
        private set

    // Built lazily (and only once) since Region.setPath does real rasterization
    // work; most pieces are dragged/redrawn far more often than they're
    // hit-tested for the first time.
    private val hitRegion: Region by lazy {
        Region().apply { setPath(outline, Region(0, 0, width, height)) }
    }

    /** [localX]/[localY] are relative to this piece's own bitmap, i.e. already
     * had [currentX]/[currentY] subtracted out by the caller. */
    fun containsLocalPoint(localX: Int, localY: Int): Boolean =
        hitRegion.contains(localX, localY)

    fun distanceSqToHome(): Float {
        val dx = homeX - currentX
        val dy = homeY - currentY
        return dx * dx + dy * dy
    }

    fun lockAtHome() {
        currentX = homeX
        currentY = homeY
        locked = true
    }

    fun unlock() {
        locked = false
    }

    fun recycle() {
        if (!bitmap.isRecycled) bitmap.recycle()
    }
}
