package com.photopuzzle.game

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.RadioGroup
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import com.photopuzzle.game.puzzle.PuzzleActivity
import java.io.File
import java.io.IOException

/**
 * Deliberately extends [ComponentActivity] rather than AppCompatActivity:
 * `registerForActivityResult` only needs the Activity/Lifecycle libraries,
 * and this app's plain-Views UI has no reason to pull in AppCompat.
 */
class MainActivity : ComponentActivity() {

    private var selectedPhotoUri: Uri? = null

    private lateinit var photoPreview: ImageView
    private lateinit var photoPreviewHint: TextView
    private lateinit var startButton: Button
    private lateinit var difficultyGroup: RadioGroup

    private val pickPhoto = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            selectedPhotoUri = uri
            photoPreview.setImageURI(uri)
            photoPreview.visibility = ImageView.VISIBLE
            photoPreviewHint.visibility = TextView.GONE
            startButton.isEnabled = true
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        photoPreview = findViewById(R.id.photoPreview)
        photoPreviewHint = findViewById(R.id.photoPreviewHint)
        startButton = findViewById(R.id.startButton)
        difficultyGroup = findViewById(R.id.difficultyGroup)

        findViewById<Button>(R.id.choosePhotoButton).setOnClickListener {
            pickPhoto.launch("image/*")
        }

        startButton.setOnClickListener { startPuzzle() }
    }

    private fun startPuzzle() {
        val uri = selectedPhotoUri ?: return
        val cachedPath = copyToCache(uri) ?: return

        val (rows, cols) = when (difficultyGroup.checkedRadioButtonId) {
            R.id.difficultyMedium -> 4 to 4
            R.id.difficultyHard -> 5 to 5
            else -> 3 to 3
        }

        startActivity(
            Intent(this, PuzzleActivity::class.java).apply {
                putExtra(PuzzleActivity.EXTRA_IMAGE_PATH, cachedPath)
                putExtra(PuzzleActivity.EXTRA_ROWS, rows)
                putExtra(PuzzleActivity.EXTRA_COLS, cols)
            }
        )
    }

    /** Copies the picked image into our own cache dir as a plain file so the
     * next screen can load it by path -- no need to carry a content:// Uri
     * (and its temporary permission grant) across activities. */
    private fun copyToCache(uri: Uri): String? {
        val destination = File(cacheDir, "puzzle_source.jpg")
        return try {
            contentResolver.openInputStream(uri)?.use { input ->
                destination.outputStream().use { output -> input.copyTo(output) }
            } ?: return null
            destination.absolutePath
        } catch (error: IOException) {
            null
        }
    }
}
