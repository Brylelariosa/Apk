package com.photopuzzle.game.puzzle

import kotlin.math.sqrt

/**
 * A constant-deceleration ("kinetic friction") fling model: velocity bleeds
 * off at a fixed rate until it hits zero, exactly like a coin sliding
 * across a table. [PuzzleBoardView] used to hand this job to
 * `android.widget.OverScroller`, but that class's fling curve is tuned for
 * flicking through screen-fuls of scrollable content -- often thousands of
 * pixels -- so on a puzzle board a few hundred pixels wide it either barely
 * nudges the piece or sends it flying straight into a wall no matter how
 * gently it was thrown, then keeps commanding motion into that wall every
 * frame while [PuzzleBoardView] repeatedly clamps it back. The distance
 * here instead scales smoothly and predictably with how hard the piece was
 * thrown (`distance = velocity^2 / (2 * deceleration)`), the way an actual
 * toss across a table would.
 *
 * Pure math, no Android View/Canvas dependency, so it's easy to reason
 * about -- and reuse -- independent of how, or whether, it's being drawn.
 */
internal class FlingPhysics(private val decelerationPxPerSec2: Float) {

    /** One frame's worth of movement, in pixels. */
    data class Displacement(val dx: Float, val dy: Float)

    var velocityX: Float = 0f
        private set
    var velocityY: Float = 0f
        private set

    val isRunning: Boolean get() = speed() > MIN_SPEED_PX_PER_SEC

    fun start(vx: Float, vy: Float) {
        velocityX = vx
        velocityY = vy
    }

    fun stop() {
        velocityX = 0f
        velocityY = 0f
    }

    /**
     * Advances the simulation by [deltaSeconds] and returns how far the
     * piece should move this frame. Slows the current velocity by
     * [decelerationPxPerSec2] (direction unchanged, magnitude never past
     * zero) so repeated calls settle the piece to a natural stop rather
     * than coasting indefinitely.
     */
    fun step(deltaSeconds: Float): Displacement {
        val currentSpeed = speed()
        if (currentSpeed <= MIN_SPEED_PX_PER_SEC) {
            stop()
            return Displacement(0f, 0f)
        }

        val displacement = Displacement(velocityX * deltaSeconds, velocityY * deltaSeconds)

        val remainingSpeed = (currentSpeed - decelerationPxPerSec2 * deltaSeconds).coerceAtLeast(0f)
        val scale = remainingSpeed / currentSpeed
        velocityX *= scale
        velocityY *= scale

        return displacement
    }

    /** Reflects the horizontal velocity component -- a wall was just hit.
     * [restitution] 0f stops that component dead; 1f bounces it perfectly;
     * values in between (the realistic range) leave a small bounce. */
    fun reflectX(restitution: Float) {
        velocityX = -velocityX * restitution
    }

    /** Reflects the vertical velocity component; see [reflectX]. */
    fun reflectY(restitution: Float) {
        velocityY = -velocityY * restitution
    }

    private fun speed(): Float = sqrt(velocityX * velocityX + velocityY * velocityY)

    private companion object {
        /** Below this, residual motion is imperceptible -- stop rather than
         * asymptotically crawl toward zero forever. */
        const val MIN_SPEED_PX_PER_SEC = 40f
    }
}
