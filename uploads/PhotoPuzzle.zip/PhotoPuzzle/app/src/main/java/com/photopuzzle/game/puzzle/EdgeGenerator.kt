package com.photopuzzle.game.puzzle

/**
 * Produces the randomized tab/blank layout for a jigsaw grid: one
 * [sign, jitter] pair per internal edge, horizontal edges first (row-major),
 * then vertical edges (row-major). See [PuzzlePieceFactory] for how this
 * flat array is interpreted into each piece's four sides.
 */
internal interface EdgeGenerator {
    fun generate(rows: Int, cols: Int, seed: Long): FloatArray
}

/** JNI-backed generator using the CMake-built `puzzlecore` native library. */
internal object NativeEdgeGenerator : EdgeGenerator {

    val isAvailable: Boolean = try {
        System.loadLibrary("puzzlecore")
        true
    } catch (error: Throwable) {
        false
    }

    override fun generate(rows: Int, cols: Int, seed: Long): FloatArray {
        val out = FloatArray(EdgeGeometry.floatCountFor(rows, cols))
        nativeGenerate(rows, cols, seed, out)
        return out
    }

    /** Fills [out] in place; [out] must already be sized by the caller (see
     * [EdgeGeometry.floatCountFor]) since the native side does no allocation. */
    private external fun nativeGenerate(rows: Int, cols: Int, seed: Long, out: FloatArray)
}

/** Pure-Kotlin fallback implementing the identical SplitMix64-based
 * algorithm as core/edge_generator.cpp, used if the native library is
 * unavailable for any reason so the game still works either way. */
internal object KotlinEdgeGenerator : EdgeGenerator {

    override fun generate(rows: Int, cols: Int, seed: Long): FloatArray {
        val edgeCount = EdgeGeometry.edgeCountFor(rows, cols)
        val out = FloatArray(edgeCount * 2)
        val seedBits = seed.toULong()

        for (i in 0 until edgeCount) {
            val bits = splitmix64(seedBits xor (i.toULong() * INDEX_MIX_CONSTANT))

            out[i * 2] = if ((bits and 1UL) == 0UL) -1f else 1f

            val jitterBits = ((bits shr 32) and 0xFFFFUL).toInt()
            out[i * 2 + 1] = (jitterBits / 65535f - 0.5f) * 0.12f
        }
        return out
    }

    // SplitMix64 (public-domain step function, S. Vigna / S. Steele) -- kept
    // byte-for-byte identical to the C++ version so native and fallback
    // produce the same puzzles for the same seed.
    private fun splitmix64(input: ULong): ULong {
        var z = input + 0x9E3779B97F4A7C15UL
        z = (z xor (z shr 30)) * 0xBF58476D1CE4E5B9UL
        z = (z xor (z shr 27)) * 0x94D049BB133111EBUL
        return z xor (z shr 31)
    }

    private const val INDEX_MIX_CONSTANT = 0x9E3779B97F4A7C15UL
}

/** Shared sizing math so the native path, the fallback path, and
 * [PuzzlePieceFactory] can never disagree about array layout. */
internal object EdgeGeometry {
    fun edgeCountFor(rows: Int, cols: Int): Int {
        if (rows < 1 || cols < 1) return 0
        return (rows - 1) * cols + rows * (cols - 1)
    }

    fun floatCountFor(rows: Int, cols: Int): Int = edgeCountFor(rows, cols) * 2
}

/** Picks the native generator when it's genuinely working (loads *and*
 * successfully services a smoke-test call), falling back to the pure-Kotlin
 * one otherwise -- so a native/JNI problem degrades the game to "slightly
 * slower generation," never to a crash. */
internal object EdgeGeneratorProvider {
    private val resolved: EdgeGenerator by lazy {
        if (NativeEdgeGenerator.isAvailable) {
            try {
                NativeEdgeGenerator.generate(2, 2, 0L)
                NativeEdgeGenerator
            } catch (error: Throwable) {
                KotlinEdgeGenerator
            }
        } else {
            KotlinEdgeGenerator
        }
    }

    fun get(): EdgeGenerator = resolved
}
