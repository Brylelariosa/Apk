package com.photopuzzle.game.puzzle

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.activity.ComponentActivity
import com.photopuzzle.game.R
import com.photopuzzle.game.util.ImageUtils

class PuzzleActivity : ComponentActivity() {

    private lateinit var boardView: PuzzleBoardView
    private lateinit var progressLabel: TextView
    private lateinit var winOverlay: View

    private var rows = 3
    private var cols = 3

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_puzzle)

        boardView = findViewById(R.id.puzzleBoardView)
        progressLabel = findViewById(R.id.progressLabel)
        winOverlay = findViewById(R.id.winOverlay)

        val imagePath = intent.getStringExtra(EXTRA_IMAGE_PATH)
        if (imagePath == null) {
            finish()
            return
        }
        rows = intent.getIntExtra(EXTRA_ROWS, 3)
        cols = intent.getIntExtra(EXTRA_COLS, 3)

        val bitmap = ImageUtils.loadOrientedBitmap(imagePath, MAX_IMAGE_DIMENSION)
        if (bitmap == null) {
            finish()
            return
        }

        progressLabel.text = getString(R.string.progress_format, 0, rows * cols)

        boardView.onSolved = { showWinOverlay() }
        boardView.onPiecePlaced = { locked, total ->
            progressLabel.text = getString(R.string.progress_format, locked, total)
        }
        boardView.start(bitmap, rows, cols)

        findViewById<Button>(R.id.playAgainButton).setOnClickListener {
            winOverlay.animate().cancel()
            winOverlay.visibility = View.GONE
            progressLabel.text = getString(R.string.progress_format, 0, rows * cols)
            boardView.shuffle()
        }
        findViewById<Button>(R.id.newPhotoButton).setOnClickListener { finish() }
    }

    /**
     * Reveals the win overlay only after [PuzzleBoardView]'s own on-solve
     * celebration (border fade, picture pop, confetti) has had room to
     * play -- showing it immediately would instantly cover that animation
     * with an opaque overlay before the player ever sees it. Fades in
     * afterward rather than popping visible, to match.
     */
    private fun showWinOverlay() {
        winOverlay.postDelayed(revealWinOverlay, PuzzleBoardView.COMPLETION_CELEBRATION_DURATION_MS)
    }

    private val revealWinOverlay = Runnable {
        winOverlay.alpha = 0f
        winOverlay.visibility = View.VISIBLE
        winOverlay.animate().alpha(1f).setDuration(WIN_OVERLAY_FADE_MS).start()
    }

    override fun onDestroy() {
        super.onDestroy()
        winOverlay.removeCallbacks(revealWinOverlay)
        winOverlay.animate().cancel()
        boardView.recycleAll()
    }

    companion object {
        const val EXTRA_IMAGE_PATH = "com.photopuzzle.game.extra.IMAGE_PATH"
        const val EXTRA_ROWS = "com.photopuzzle.game.extra.ROWS"
        const val EXTRA_COLS = "com.photopuzzle.game.extra.COLS"
        private const val MAX_IMAGE_DIMENSION = 2048
        private const val WIN_OVERLAY_FADE_MS = 300L
    }
}
