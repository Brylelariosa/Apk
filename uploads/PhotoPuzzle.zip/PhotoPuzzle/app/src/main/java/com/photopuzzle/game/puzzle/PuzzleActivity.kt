package com.photopuzzle.game.puzzle

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.activity.ComponentActivity
import com.photopuzzle.game.R
import com.photopuzzle.game.util.ImageUtils

class PuzzleActivity : ComponentActivity() {

    private lateinit var boardView: PuzzleBoardView
    private lateinit var progressLabel: TextView
    private lateinit var winOverlay: View

    private var rows = 3
    private var cols = 3

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_puzzle)

        boardView = findViewById(R.id.puzzleBoardView)
        progressLabel = findViewById(R.id.progressLabel)
        winOverlay = findViewById(R.id.winOverlay)

        val imagePath = intent.getStringExtra(EXTRA_IMAGE_PATH)
        if (imagePath == null) {
            finish()
            return
        }
        rows = intent.getIntExtra(EXTRA_ROWS, 3)
        cols = intent.getIntExtra(EXTRA_COLS, 3)

        val bitmap = ImageUtils.loadOrientedBitmap(imagePath, MAX_IMAGE_DIMENSION)
        if (bitmap == null) {
            finish()
            return
        }

        progressLabel.text = getString(R.string.progress_format, 0, rows * cols)

        boardView.onSolved = { winOverlay.visibility = View.VISIBLE }
        boardView.onPiecePlaced = { locked, total ->
            progressLabel.text = getString(R.string.progress_format, locked, total)
        }
        boardView.start(bitmap, rows, cols)

        findViewById<Button>(R.id.playAgainButton).setOnClickListener {
            winOverlay.visibility = View.GONE
            progressLabel.text = getString(R.string.progress_format, 0, rows * cols)
            boardView.shuffle()
        }
        findViewById<Button>(R.id.newPhotoButton).setOnClickListener { finish() }
    }

    override fun onDestroy() {
        super.onDestroy()
        boardView.recycleAll()
    }

    companion object {
        const val EXTRA_IMAGE_PATH = "com.photopuzzle.game.extra.IMAGE_PATH"
        const val EXTRA_ROWS = "com.photopuzzle.game.extra.ROWS"
        const val EXTRA_COLS = "com.photopuzzle.game.extra.COLS"
        private const val MAX_IMAGE_DIMENSION = 2048
    }
}
