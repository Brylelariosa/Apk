package com.photopuzzle.game.puzzle

import kotlin.random.Random

/**
 * Holds one puzzle's pieces and the rules for moving/snapping/winning.
 * Deliberately has no Android View/Canvas dependency -- [PuzzleBoardView]
 * drives this and draws whatever it reports, but the rules themselves don't
 * care how (or whether) they're being rendered.
 */
internal class PuzzleGame(
    private val pieces: MutableList<PuzzlePiece>,
    private val snapThresholdPx: Float
) {
    var onSolved: (() -> Unit)? = null
    private var solved = false

    val pieceCount: Int get() = pieces.size
    val lockedCount: Int get() = pieces.count { it.locked }

    /** Back-to-front draw/z order; dragging a piece moves it to the end. */
    fun piecesInDrawOrder(): List<PuzzlePiece> = pieces

    fun findTopPieceAt(x: Float, y: Float): PuzzlePiece? {
        for (index in pieces.indices.reversed()) {
            val piece = pieces[index]
            if (piece.locked) continue

            val localX = (x - piece.currentX).toInt()
            val localY = (y - piece.currentY).toInt()
            if (localX in 0 until piece.width &&
                localY in 0 until piece.height &&
                piece.containsLocalPoint(localX, localY)
            ) {
                return piece
            }
        }
        return null
    }

    fun bringToFront(piece: PuzzlePiece) {
        if (pieces.remove(piece)) pieces.add(piece)
    }

    fun moveBy(piece: PuzzlePiece, dx: Float, dy: Float) {
        piece.currentX += dx
        piece.currentY += dy
    }

    /** Snaps [piece] home if it's close enough; returns whether it snapped. */
    fun trySnap(piece: PuzzlePiece): Boolean {
        if (piece.distanceSqToHome() > snapThresholdPx * snapThresholdPx) return false

        piece.lockAtHome()
        if (!solved && pieces.all { it.locked }) {
            solved = true
            onSolved?.invoke()
        }
        return true
    }

    /** Scatters every piece to a random spot within [areaWidth] x [areaHeight]
     * and unlocks them all -- used both for initial setup and "play again". */
    fun scatter(areaWidth: Int, areaHeight: Int, seed: Long) {
        if (areaWidth <= 0 || areaHeight <= 0) return
        val random = Random(seed)
        solved = false
        for (piece in pieces) {
            piece.unlock()
            val maxX = (areaWidth - piece.width).coerceAtLeast(0)
            val maxY = (areaHeight - piece.height).coerceAtLeast(0)
            piece.currentX = if (maxX > 0) random.nextInt(maxX + 1).toFloat() else 0f
            piece.currentY = if (maxY > 0) random.nextInt(maxY + 1).toFloat() else 0f
        }
    }

    fun recycleAll() {
        pieces.forEach { it.recycle() }
    }
}
