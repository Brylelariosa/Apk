package com.photopuzzle.game.puzzle

import android.graphics.Canvas
import android.graphics.Paint
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/**
 * A short-lived burst of colored rectangles that arc outward and fall,
 * fading out near the end of their life -- a small win celebration for
 * [PuzzleBoardView]. Pure simulation-and-draw, with no dependency on the
 * game or the view beyond a [Canvas] to draw into, so it's reusable
 * anywhere a brief celebration like this is useful.
 *
 * Each particle's position is computed directly from elapsed time rather
 * than integrated frame by frame, so [draw] can be driven by any
 * animation clock (a `ValueAnimator`'s progress, in [PuzzleBoardView]'s
 * case) without this class needing to track time itself.
 */
internal class ConfettiBurst(private val colors: IntArray) {

    private class Particle(
        val startX: Float,
        val startY: Float,
        val velocityX: Float,
        val velocityY: Float,
        val size: Float,
        val color: Int,
        val spinDegreesPerSecond: Float
    )

    private var particles: List<Particle> = emptyList()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    /**
     * Seeds a fresh burst centered horizontally on [centerX], starting at
     * [topY], scaled to [spreadWidth] (typically the puzzle's own width)
     * so it looks proportionate on any board size.
     */
    fun start(centerX: Float, topY: Float, spreadWidth: Float, random: Random) {
        particles = List(PARTICLE_COUNT) {
            val angle = -HALF_PI + (random.nextFloat() - 0.5f) * SPREAD_RADIANS
            val speed = spreadWidth * (MIN_SPEED_FACTOR + random.nextFloat() * SPEED_FACTOR_RANGE)
            Particle(
                startX = centerX + (random.nextFloat() - 0.5f) * spreadWidth * 0.5f,
                startY = topY,
                velocityX = cos(angle) * speed,
                velocityY = sin(angle) * speed,
                size = (spreadWidth * SIZE_FACTOR).coerceIn(MIN_SIZE_PX, MAX_SIZE_PX),
                color = colors[random.nextInt(colors.size)],
                spinDegreesPerSecond = (random.nextFloat() - 0.5f) * MAX_SPIN_DEGREES_PER_SEC
            )
        }
    }

    /**
     * Draws the burst as it looks [elapsedSeconds] after [start].
     * [lifeFraction] is 0f at the start of the burst and 1f at its end --
     * used only to fade particles out over the final stretch, independent
     * of whatever real duration the caller chose for that 0f..1f span.
     */
    fun draw(canvas: Canvas, elapsedSeconds: Float, lifeFraction: Float) {
        val fade = ((1f - lifeFraction) / FADE_OUT_FRACTION).coerceIn(0f, 1f)
        if (fade <= 0f) return

        for (particle in particles) {
            val x = particle.startX + particle.velocityX * elapsedSeconds
            val y = particle.startY + particle.velocityY * elapsedSeconds +
                0.5f * GRAVITY_PX_PER_SEC2 * elapsedSeconds * elapsedSeconds

            paint.color = particle.color
            paint.alpha = (255 * fade).toInt()
            canvas.save()
            canvas.translate(x, y)
            canvas.rotate(particle.spinDegreesPerSecond * elapsedSeconds)
            canvas.drawRect(-particle.size, -particle.size * 0.55f, particle.size, particle.size * 0.55f, paint)
            canvas.restore()
        }
    }

    private companion object {
        const val PARTICLE_COUNT = 28
        val HALF_PI = (PI / 2).toFloat()
        val SPREAD_RADIANS = (PI * 0.9).toFloat()
        const val MIN_SPEED_FACTOR = 0.55f
        const val SPEED_FACTOR_RANGE = 0.55f
        const val SIZE_FACTOR = 0.018f
        const val MIN_SIZE_PX = 6f
        const val MAX_SIZE_PX = 22f
        const val MAX_SPIN_DEGREES_PER_SEC = 620f
        const val GRAVITY_PX_PER_SEC2 = 1400f

        /** Particles stay fully opaque until the final 35% of their life,
         * then fade out -- avoids a washed-out look from the first frame. */
        const val FADE_OUT_FRACTION = 0.35f
    }
}
