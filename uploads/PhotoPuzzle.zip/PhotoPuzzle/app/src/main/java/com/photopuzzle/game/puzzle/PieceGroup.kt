package com.photopuzzle.game.puzzle

/**
 * A cluster of pieces that have connected to each other and now move --
 * and are brought to the front -- as one rigid unit. [PuzzleGame.tryConnect]
 * grows a group by [absorb]ing another into it when a piece meets a
 * correctly-adjacent neighbor from a different group; the puzzle is solved
 * once a single group holds every piece.
 */
internal class PieceGroup(initial: PuzzlePiece) {

    val members: MutableList<PuzzlePiece> = mutableListOf(initial)

    val size: Int get() = members.size

    fun moveBy(dx: Float, dy: Float) {
        if (dx == 0f && dy == 0f) return
        for (piece in members) {
            piece.currentX += dx
            piece.currentY += dy
        }
    }

    /**
     * Folds [other]'s members into this group and repoints them here.
     * No-op if [other] is already this group; otherwise [other] is left
     * empty and the caller should not keep using it.
     */
    fun absorb(other: PieceGroup) {
        if (other === this) return
        for (piece in other.members) piece.group = this
        members += other.members
        other.members.clear()
    }
}
