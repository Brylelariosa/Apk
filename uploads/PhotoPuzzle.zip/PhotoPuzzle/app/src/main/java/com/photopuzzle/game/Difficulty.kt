package com.photopuzzle.game

/**
 * The grid sizes offered on the picker screen. Kept as one small,
 * data-driven list rather than branching on a chosen RadioButton id
 * wherever rows/cols are needed, so adding another size later touches
 * only this file (plus its own option in activity_main.xml).
 */
internal enum class Difficulty(val rows: Int, val cols: Int) {
    EASY(3, 3),
    MEDIUM(4, 4),
    HARD(5, 5),
    EXPERT(10, 10);

    val pieceCount: Int get() = rows * cols
}
