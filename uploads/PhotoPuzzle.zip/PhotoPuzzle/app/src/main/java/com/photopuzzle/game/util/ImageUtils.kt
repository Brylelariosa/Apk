package com.photopuzzle.game.util

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import java.io.FileInputStream
import java.io.IOException
import kotlin.math.min

/**
 * Loading helpers kept separate from any Activity/View so they're easy to
 * reuse (and reason about) independent of the UI. Uses the platform
 * `android.media.ExifInterface` rather than the AndroidX one: minSdk 24
 * already supports the InputStream constructor we need, so pulling in the
 * androidx artifact would only add size for no benefit here.
 */
internal object ImageUtils {

    /**
     * Decodes the JPEG/PNG/etc. at [path], downsampled so neither dimension
     * exceeds [maxDimension] (memory safety against very large camera
     * photos), and rotated upright according to its EXIF orientation tag.
     * Returns null if the file can't be decoded as an image at all.
     */
    fun loadOrientedBitmap(path: String, maxDimension: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

        var sampleSize = 1
        while (bounds.outWidth / (sampleSize * 2) >= maxDimension &&
            bounds.outHeight / (sampleSize * 2) >= maxDimension
        ) {
            sampleSize *= 2
        }

        val decoded = BitmapFactory.decodeFile(path, BitmapFactory.Options().apply {
            inSampleSize = sampleSize
        }) ?: return null

        val rotationDegrees = readExifRotationDegrees(path)
        if (rotationDegrees == 0) return decoded

        val matrix = Matrix().apply { postRotate(rotationDegrees.toFloat()) }
        val rotated = Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, matrix, true)
        if (rotated !== decoded) decoded.recycle()
        return rotated
    }

    /** Scales [source] down to fit within [maxWidth] x [maxHeight], preserving
     * aspect ratio. Never scales up (returns [source] itself if it already
     * fits) so small photos don't come out blurry. */
    fun fitToBounds(source: Bitmap, maxWidth: Int, maxHeight: Int): Bitmap {
        if (maxWidth <= 0 || maxHeight <= 0) return source
        val scale = min(
            maxWidth.toFloat() / source.width,
            maxHeight.toFloat() / source.height
        ).coerceAtMost(1f)
        if (scale > 0.999f) return source

        val targetWidth = (source.width * scale).toInt().coerceAtLeast(1)
        val targetHeight = (source.height * scale).toInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(source, targetWidth, targetHeight, true)
    }

    private fun readExifRotationDegrees(path: String): Int = try {
        FileInputStream(path).use { stream ->
            val orientation = ExifInterface(stream).getAttributeInt(
                ExifInterface.TAG_ORIENTATION,
                ExifInterface.ORIENTATION_NORMAL
            )
            when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90
                ExifInterface.ORIENTATION_ROTATE_180 -> 180
                ExifInterface.ORIENTATION_ROTATE_270 -> 270
                else -> 0
            }
        }
    } catch (error: IOException) {
        0
    }
}
