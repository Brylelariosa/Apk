#include <jni.h>

#include "core/edge_generator.h"

// Bridges com.photopuzzle.game.puzzle.NativeEdgeGenerator.nativeGenerate.
// Keep this name in sync with that Kotlin `external fun` declaration --
// JNI resolves natives by this exact mangled name, not by any registration
// list, so a rename on either side needs the matching rename here.
//
// Deliberately takes a caller-allocated `outArr` rather than allocating and
// returning a new jfloatArray: the JVM side already knows the exact size it
// needs (rows/cols determine it exactly) and can allocate it trivially,
// which means this file never needs `new`/`std::vector`/etc. That keeps it
// compatible with ANDROID_STL=none (see CMakeLists.txt) and sidesteps any
// question of who owns/frees a native-allocated array.
extern "C" JNIEXPORT void JNICALL
Java_com_photopuzzle_game_puzzle_NativeEdgeGenerator_nativeGenerate(
        JNIEnv* env, jobject /*thiz*/, jint rows, jint cols, jlong seed, jfloatArray outArr) {

    if (outArr == nullptr) {
        return;
    }

    jsize length = env->GetArrayLength(outArr);
    jfloat* elements = env->GetFloatArrayElements(outArr, nullptr);
    if (elements == nullptr) {
        return;  // OutOfMemoryError already thrown by the JVM.
    }

    puzzlecore::generateEdgeSigns(
            rows, cols, static_cast<int64_t>(seed),
            reinterpret_cast<float*>(elements), static_cast<size_t>(length));

    env->ReleaseFloatArrayElements(outArr, elements, 0);
}
