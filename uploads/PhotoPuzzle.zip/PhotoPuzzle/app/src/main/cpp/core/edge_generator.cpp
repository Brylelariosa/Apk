#include "edge_generator.h"

namespace puzzlecore {

namespace {

// SplitMix64 (public-domain step function, S. Vigna / S. Steele). Used only
// to turn (seed, edge index) into a reproducible pseudo-random value -- this
// is puzzle-piece flavor, not anything security-sensitive.
uint64_t splitmix64(uint64_t x) {
    uint64_t z = x + 0x9E3779B97F4A7C15ULL;
    z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ULL;
    z = (z ^ (z >> 27)) * 0x94D049BB133111EBULL;
    return z ^ (z >> 31);
}

constexpr uint64_t kIndexMixConstant = 0x9E3779B97F4A7C15ULL;

}  // namespace

size_t edgeCountFor(int rows, int cols) {
    if (rows < 1 || cols < 1) {
        return 0;
    }
    const auto horizontal = static_cast<size_t>(rows - 1) * static_cast<size_t>(cols);
    const auto vertical = static_cast<size_t>(rows) * static_cast<size_t>(cols - 1);
    return horizontal + vertical;
}

void generateEdgeSigns(int rows, int cols, int64_t seed, float* out, size_t outCount) {
    if (out == nullptr) {
        return;
    }
    const size_t edgeCount = edgeCountFor(rows, cols);
    const size_t usableEdges = edgeCount < (outCount / 2) ? edgeCount : (outCount / 2);
    const auto seedBits = static_cast<uint64_t>(seed);

    for (size_t i = 0; i < usableEdges; ++i) {
        const uint64_t bits = splitmix64(seedBits ^ (static_cast<uint64_t>(i) * kIndexMixConstant));

        const float sign = (bits & 1ULL) == 0ULL ? -1.0f : 1.0f;

        const auto jitterBits = static_cast<uint32_t>((bits >> 32) & 0xFFFFULL);
        const float jitter = (static_cast<float>(jitterBits) / 65535.0f - 0.5f) * 0.12f;

        out[i * 2] = sign;
        out[i * 2 + 1] = jitter;
    }
}

}  // namespace puzzlecore
