#ifndef PHOTOPUZZLE_CORE_EDGE_GENERATOR_H
#define PHOTOPUZZLE_CORE_EDGE_GENERATOR_H

#include <cstdint>
#include <cstddef>

namespace puzzlecore {

// Total number of internal grid edges for a rows x cols piece grid:
// (rows-1)*cols horizontal edges + rows*(cols-1) vertical edges. Returns 0
// for a degenerate (rows<1 or cols<1) grid.
size_t edgeCountFor(int rows, int cols);

// Fills `out` with one [sign, jitter] pair per internal edge: all horizontal
// edges first in row-major order, then all vertical edges in row-major
// order (matching PuzzlePieceFactory.kt on the Kotlin side, and the pure-
// Kotlin fallback generator that mirrors this exact algorithm when the
// native library isn't available).
//
//   sign   : -1.0f or 1.0f, which side of the shared edge gets the tab.
//   jitter : offset in roughly [-0.06, 0.06] that shifts the knob off-center.
//
// Deterministic: the same (rows, cols, seed) always produces the same
// output. `out` must have room for at least edgeCountFor(rows, cols) * 2
// floats; `outCount` is a defensive bound (the number of floats actually
// available in `out`) in case the two ever disagree.
void generateEdgeSigns(int rows, int cols, int64_t seed, float* out, size_t outCount);

}  // namespace puzzlecore

#endif  // PHOTOPUZZLE_CORE_EDGE_GENERATOR_H
