package com.mgba.android

// Split out of MainActivity.kt (pass 46 — "refactor main activity into
// separate classes so organized") as internal extension functions on
// MainActivity, exactly the pattern already established in SharedUi.kt's
// own top-of-file comment (Thirty-second pass) for the same reason: every
// existing unqualified call site inside MainActivity.kt (and inside every
// other split-out file) keeps compiling completely unchanged, since Kotlin
// resolves an unqualified call to an internal extension function on the
// enclosing receiver type the same way it resolves a member call — no
// behavior change, purely a file-organization move. See MainActivity.kt's
// own top-of-file comment for the full file map.

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.text.InputType
import android.text.TextUtils
import android.text.format.DateFormat
import android.util.Log
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.Closeable
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.io.PrintWriter
import java.io.StringWriter
import java.util.concurrent.atomic.AtomicInteger
import java.util.zip.ZipInputStream
import kotlin.math.abs
import kotlin.math.roundToInt


// isZipSignature()/zipContainsGba() moved to RomZipUtils.kt this pass
// (Thirty-second) when the ROM browser became its own Activity —
// RomBrowserActivity needs zipContainsGba() too, and this way there's
// still only one copy of the byte comparison between it and
// stageRomFile() below, same as when both lived in this class.

/** Copies [uri] into [tmp]. If the source is a zip archive — detected by
 *  its real magic bytes (see RomZipUtils.isZipSignature()), not by file
 *  extension, so a misnamed archive still works and a .zip that somehow
 *  isn't a real zip is correctly rejected instead of handed to the core
 *  as garbage — the first .gba entry found inside is extracted instead
 *  of the raw archive bytes. This is what lets both the file browser
 *  and the classic system picker load a ROM straight out of a .zip with
 *  no separate extraction step. Returns false if nothing worth loading
 *  ended up in [tmp] (unreadable source, or a zip with no .gba entry). */
internal fun MainActivity.stageRomFile(uri: Uri, tmp: File): Boolean {
    val raw = contentResolver.openInputStream(uri) ?: return false
    raw.use { stream ->
        val input = stream.buffered()
        if (!RomZipUtils.isZipSignature(input)) {
            tmp.outputStream().use { o -> input.copyTo(o) }
            return true
        }
        ZipInputStream(input).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                if (!entry.isDirectory && entry.name.endsWith(".gba", ignoreCase = true)) {
                    tmp.outputStream().use { o -> zip.copyTo(o) }
                    return true
                }
                entry = zip.nextEntry
            }
        }
        return false
    }
}


/** Stages [uri] (transparently unzipping it first if needed — see
 *  stageRomFile()), swaps it into the running core, and updates the UI
 *  on success or failure. Shared by every ROM entry point — the classic
 *  system picker above and the in-app file browser's file rows below
 *  both just call this now, instead of each duplicating the load. */
internal fun MainActivity.loadRomFromUri(uri: Uri) {
    Thread {
        try {
            // FIX: nativeLoadROM() silently drops any active link session
            // as part of swapping the native core (see the "ROM swapped
            // while a link session was active" comment in mgba_jni.c) —
            // that side is careful to avoid leaving a dangling pointer,
            // but it has no way to tell the Kotlin side this happened.
            // Without this, link.isConnected and the ⬤ LINK overlay would
            // keep claiming "Connected" after a ROM swap even though the
            // native SIO driver backing the exchange no longer exists —
            // a silently broken multiplayer session with no indication
            // in the UI of why. Disconnect first so both sides agree.
            if (link.isConnected) stopLink()
            // FIX (Twenty-first pass): if a Storage folder is configured
            // and a ROM is already running, its battery save has only
            // ever been mirrored to internal storage (see
            // SaveEntry.batteryMirrorPath()) — the real document in the
            // chosen folder hasn't seen anything played since the last
            // sync point. Flush it out now, before that mirror file gets
            // reused for the ROM we're about to swap in, or whatever was
            // played this session never reaches the chosen folder at all.
            // mirrorToAutoFolder() alongside it: same flush moment, just
            // for the automatic own-folder mirror instead of a chosen
            // SAF folder — see the FEATURE block above dataFolderTree().
            if (romLoaded) {
                batterySaveEntry(currentRomBaseName).syncBatteryMirror()
                batterySaveEntry(currentRomBaseName).mirrorToAutoFolder()
            }
            // FIX: stop any in-progress game loop *before* touching the
            // native core, and reset transient input/FF state. Previously
            // there was no way to load a second ROM at all (loadRomBtn was
            // permanently hidden after the first successful load), so this
            // path was never exercised. nativeLoadROM() now builds the new
            // core fully before swapping it in, so a failed load here
            // leaves the previous session running rather than destroying
            // it (see mgba_jni.c).
            stopGameLoop()
            val tmp = cacheDir.resolve("rom_loaded.gba")
            if (!stageRomFile(uri, tmp)) {
                uiToast("Couldn't read that file (or found no .gba inside the zip)")
                return@Thread
            }
            // ROM SAVE: identify the ROM by its picked display name —
            // not the fixed "rom_loaded.gba" cache path above, which
            // every ROM shares — so its battery save persists under a
            // name stable across app restarts and re-picking the same
            // file later. See deriveRomBaseName()/batterySaveEntry().
            val baseName = deriveRomBaseName(uri)
            val saveEntry = batterySaveEntry(baseName)
            backupIfExists(saveEntry)   // FEATURE: auto save backup
            // FIX (Twenty-first pass): was saveEntry.nativePath(forWrite
            // = true).path — a /proc/self/fd bridge straight onto the SAF
            // document, mmap'd by the core for the whole session. See the
            // block comment above dataFolderTree() for why that doesn't
            // hold up on a real device. batteryMirrorPath() below is
            // always a plain local path; when a Storage folder is
            // configured it stages the existing save in from there first.
            val savePath = saveEntry.batteryMirrorPath()
            val ok = EmulatorEngine.nativeLoadROM(tmp.absolutePath, savePath)
            Handler(Looper.getMainLooper()).post romLoadDone@ {
                // FIX: onDestroy() may have already run and freed the
                // native core by the time this posts, if the load was
                // slow (large ROM, a slow SAF/cloud-backed URI) and the
                // user backed out of the app in the meantime. Without
                // this check, the block below would re-init AudioTrack
                // and start a brand new game thread + Choreographer
                // registration after teardown — resources nothing would
                // ever clean up, since onDestroy() has already run and
                // won't run again for this instance.
                if (isFinishing || isDestroyed) return@romLoadDone
                // BUG FIX: this whole block runs on the MAIN thread,
                // asynchronously, well after loadRomFromUri's own
                // try/catch — wrapping the background Thread body above
                // — has already finished and returned. That catch does
                // NOT protect anything in here despite the misleading
                // nesting; Handler.post() only schedules this lambda,
                // it doesn't run it, so by the time this body actually
                // executes the outer try is long gone. Any exception
                // here (Bitmap.createBitmap, AudioTrack init, the
                // thread/Choreographer setup in startGameLoop()) was
                // previously a genuine uncaught exception on the main
                // thread — a hard app crash, with the ROM having *just*
                // finished loading successfully.
                try {
                    if (ok) {
                        val w = EmulatorEngine.nativeGetWidth().coerceAtLeast(1)
                        val h = EmulatorEngine.nativeGetHeight().coerceAtLeast(1)
                        frameBuffers = Array(3) {
                            Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                        }
                        writeIdx = 0
                        readyIdx = -1
                        displayIdx = -1
                        romLoaded = true
                        // FIX (this pass): see applyScreenOrientationPref()'s
                        // own doc comment. This activity was Portrait the
                        // whole time RomBrowserActivity was open (idle —
                        // see that function) — now that a ROM is actually
                        // loaded, switch to the user's chosen gameplay
                        // orientation, before startGameLoop() below starts
                        // rendering.
                        applyScreenOrientationPref()
                        currentRomBaseName = baseName
                        clearPointerState()
                        currentKeys.set(0)
                        fastForwardActive = false
                        // FEATURE (direct report — Misc setting "Auto
                        // Save & Load": "...points load it back on
                        // start"): the other half of onPause()'s own
                        // autosave write — see that function's doc
                        // comment for why *that* half is synchronous.
                        // This half is synchronous for a related but
                        // different reason: it has to finish before
                        // startGameLoop() below starts rendering, or
                        // the very first frame(s) shown would briefly
                        // be the ROM's own boot state before snapping
                        // to the restored one. currentRomBaseName is
                        // already set above, so autoStateEntry() below
                        // resolves to *this* ROM's own autosave, not
                        // whichever ROM was playing last. Silent when
                        // there's nothing to load (no toast, no
                        // "nothing found" message) — this runs on
                        // literally every ROM load, and most of the
                        // time, especially the very first time this ROM
                        // is ever opened, there won't be one yet.
                        if (autoSaveLoadEnabled) {
                            val autoEntry = autoStateEntry()
                            if (autoEntry.exists()) {
                                val autoLocalPath = autoEntry.stageForRead()
                                if (autoLocalPath != null && EmulatorEngine.nativeLoadState(autoLocalPath)) {
                                    uiToast("Autosave loaded")
                                }
                            }
                        }
                        initAudioTrack()
                        startGameLoop()
                    } else {
                        romLoaded = false
                        uiToast("Unsupported ROM format")
                    }
                } catch (e: Throwable) {
                    // Leave the app in a state the user can recover from
                    // instead of a crash: no half-started game, surface
                    // wiped, and romLoaded left false so a tap on the
                    // idle screen (see onGameTouch()) reopens the ROM
                    // browser instead of leaving a dead screen behind.
                    Log.e(TAG, "ROM load post-processing failed", e)
                    uiToast("Load error: ${e.message ?: e.javaClass.simpleName}")
                    romLoaded = false
                    clearSurfaceToBlack()
                }
            }
        } catch (e: Throwable) {
            Log.e(TAG, "ROM load failed", e)
            uiToast("Load error: ${e.message ?: e.javaClass.simpleName}")
        }
    }.apply { name = "mGBA-load" }.start()
}


/** Entry point for loading/swapping the ROM — called from onCreate() on
 *  first launch, from closeGame() when backing out of a game, and from
 *  onGameTouch() when the idle (no-ROM-loaded) surface is tapped.
 *  Launches RomBrowserActivity (a separate Activity as of Thirty-second
 *  pass, not an overlay in this one — see its own top-of-file comment)
 *  and waits for a result; romBrowserLauncher above hands whatever it
 *  returns to loadRomFromUri(). Broad file access, the folder browsing
 *  itself, and the classic single-document SAF picker fallback are all
 *  that Activity's own concern now, not this one's. */
internal fun MainActivity.changeRom() {
    romBrowserLauncher.launch(Intent(this, RomBrowserActivity::class.java))
    // FIX (Fortieth pass — reported directly: opens in landscape,
    // "then it go to portrait instantly"). This app is normally in
    // landscape during play; RomBrowserActivity is manifest-locked to
    // portrait (see its own top-of-file comment for why that's a
    // static declaration and NOT a runtime requestedOrientation call —
    // this fix doesn't touch that at all, for the same reason).
    // Actually rotating the physical display for the new Activity is a
    // real reconfiguration, and the default slide/fade activity
    // transition gives it a couple of animated frames to be visible
    // mid-rotation, which is what reads as "opens landscape, then
    // snaps to portrait". overridePendingTransition(0, 0) collapses
    // that transition to nothing, so the swap is an instant cut
    // instead of an animated one with a wrong-orientation frame in the
    // middle. Deprecated as of API 34 (replaced by
    // overrideActivityTransition) but still fully functional at this
    // app's targetSdk 34 — kept as the plain call rather than a
    // version-gated branch since the two behave identically here and
    // there's nothing to verify a newer, unfamiliar signature against
    // in this sandbox (no compiler/device, as every pass). See
    // RomBrowserActivity's own finish() override for the matching
    // fix on the way back.
    @Suppress("DEPRECATION")
    overridePendingTransition(0, 0)
}


// ── Save / state file naming ─────────────────────────────────────────
// SAF (Storage Access Framework) URIs don't carry a real filesystem
// path, and the only identifier for "which ROM is this" that's stable
// across app restarts and re-picking the same file is the picked
// document's display name — queried via ContentResolver, since
// uri.lastPathSegment is often an opaque provider-specific ID rather
// than the actual filename on many document providers (Downloads,
// Google Drive, etc).

internal fun MainActivity.deriveRomBaseName(uri: Uri): String {
    var display: String? = null
    try {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { c ->
                val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && c.moveToFirst()) display = c.getString(idx)
            }
    } catch (_: Exception) {
        // Provider didn't support the query — fall through to the
        // URI-based fallback below.
    }
    val base = (display ?: uri.lastPathSegment ?: "rom").substringBeforeLast('.')
    // Keep only filesystem-safe characters — a display name can contain
    // spaces, parentheses, unicode, anything a user or provider chose.
    val sanitized = base.replace(Regex("[^A-Za-z0-9_-]"), "_").take(80)
    return sanitized.ifBlank { "rom" }
}

