package com.mgba.android

// Split out of MainActivity.kt (pass 46 — "refactor main activity into
// separate classes so organized") as internal extension functions on
// MainActivity, exactly the pattern already established in SharedUi.kt's
// own top-of-file comment (Thirty-second pass) for the same reason: every
// existing unqualified call site inside MainActivity.kt (and inside every
// other split-out file) keeps compiling completely unchanged, since Kotlin
// resolves an unqualified call to an internal extension function on the
// enclosing receiver type the same way it resolves a member call — no
// behavior change, purely a file-organization move. See MainActivity.kt's
// own top-of-file comment for the full file map.

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.text.InputType
import android.text.TextUtils
import android.text.format.DateFormat
import android.util.Log
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.Closeable
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.io.PrintWriter
import java.io.StringWriter
import java.util.concurrent.atomic.AtomicInteger
import java.util.zip.ZipInputStream
import kotlin.math.abs
import kotlin.math.roundToInt


// ── Lifecycle ──────────────────────────────────────────────────────────

/** FEATURE: new — self-service crash log. W can't pull logcat off this
 *  device for reasons neither of us has pinned down, which blocks the
 *  normal "send me the stack trace" loop entirely. This sidesteps that:
 *  it wraps whatever the default uncaught-exception handler already
 *  was, so a crash still behaves exactly as it always did (process
 *  dies, system shows its usual "stopped" behavior) — but first writes
 *  the full exception, stack trace, thread name, and device info to a
 *  plain file this app owns outright (File(filesDir, "crash_log.txt"),
 *  same pattern as the FIX 17 link-debug log). Exposed through the
 *  existing ⚙ menu's new "Copy crash log" row (see showGameMenu() /
 *  copyCrashLog() below) so it can be grabbed with nothing but a tap +
 *  paste, no PC/adb/logcat involved. Overwrites on each crash (not
 *  appended) so it always reflects the MOST RECENT crash, never a
 *  stale one from an already-fixed issue.
 *
 *  Everything in here is wrapped defensively — a crash handler that
 *  itself throws (e.g. disk full while writing the report) must still
 *  fall through to the real handler below, or the app would hang
 *  instead of dying cleanly, which is a worse failure mode than simply
 *  losing that one report. */
internal fun MainActivity.installCrashLogger() {
    val previous = Thread.getDefaultUncaughtExceptionHandler()
    Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
        try {
            val trace = StringWriter().also { throwable.printStackTrace(PrintWriter(it)) }.toString()
            val report = buildString {
                appendLine("mGBA crash report")
                appendLine("Time: ${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US).format(java.util.Date())}")
                appendLine("Thread: ${thread.name}")
                appendLine("Device: ${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})")
                appendLine()
                append(trace)
            }
            File(filesDir, "crash_log.txt").writeText(report)
        } catch (_: Throwable) {
            // See doc comment above — must not block the real handoff below.
        }
        if (previous != null) {
            previous.uncaughtException(thread, throwable)
        } else {
            android.os.Process.killProcess(android.os.Process.myPid())
            kotlin.system.exitProcess(10)
        }
    }
}


// ── Link debug log ───────────────────────────────────────────────────
// FEATURE: new (Twelfth pass). The multiplayer subsystem has a real,
// still-open issue (see KNOWN_LIMITATIONS.md / BUGS_FIXED.md, "Sixth"
// through "Seventeenth" passes): the app-level Wi-Fi/Bluetooth handshake
// can succeed while the ROM's own in-game link/multiplayer screen never
// reacts to it. mgba_jni.c's FIX 11 already added permanent trace
// logging for exactly this (tag mGBA-JNI, plus mGBA-Link on the Kotlin
// side) — every pass since concluded the *next* real step needs that
// actual log output, not another guess.
//
// FIX 17: this used to shell out to `logcat`, which works for reading
// back a process's own output without root or READ_LOGS on stock
// Android, but which W's own device split (real output on one phone,
// nothing at all on the other, both running this exact build) confirmed
// some OEM builds restrict further than that. Now reads a plain private
// file this app owns outright instead (see EmulatorEngine.
// nativeSetLinkLogPath, called once from onCreate) — every LOGI/LOGW/
// LOGE in mgba_jni.c, plus this class's own connection-lifecycle lines
// (see LinkMultiplayer.kt's FIX 17 entry), now mirrors into it. Needs no
// logcat/READ_LOGS access at all, on any OEM build, since it was never
// reading logcat to begin with — just a file in this app's own
// filesDir. The native side truncates it fresh at the start of every
// link session (see nativeLinkStart()'s own FIX 17 comment), so a
// capture reflects one connection attempt, not an accumulation.
//
// Meant to be opened right after reproducing the issue being chased —
// both phones' ROMs actually navigated into their in-game link menus,
// not just the app-level "Connected" toast, and (for a disconnect
// report specifically) after actually tapping Disconnect and giving the
// other phone a few seconds — so the log actually covers a real
// attempt. Whether *any* "SIO write addr=..." line shows up at all is
// the specific thing every recent pass has been unable to check: none
// at all points upstream of the SIO driver entirely (wrong mode
// selected, or the driver never truly took); several, with the exchange
// completing, points at the protocol logic instead. Copies to the
// clipboard automatically (paste it straight back) and also shows it
// on-screen in case the clipboard isn't available for some reason.
/** BUG FIX (real ANR, not a guess — caught via the Crash Log Viewer
 *  app): "Input dispatching timed out... Waited 5000ms", with the main
 *  thread's stack sitting inside TextView/Editor draw code under a
 *  ScrollView at the moment it hung — exactly the shape of
 *  showLinkDebugLogDialog()/showCrashLogDialog() below. A real link
 *  session logs a line (sometimes several) per SIO write and per child
 *  exchange — see LinkMultiplayer.kt's own log calls — which adds up to
 *  a genuinely huge file over a real testing session, especially on
 *  whichever side is host. Rendering that much text in a
 *  setTextIsSelectable(true) TextView is known to be catastrophically
 *  slow (selectable text needs a much heavier internal layout the
 *  plain non-selectable path doesn't), and that's exactly what froze
 *  the main thread long enough to trip Android's own ANR watchdog.
 *  Caps to the most recent [maxChars] — still tens of thousands of
 *  characters of context, plenty to debug from, but bounded — applied
 *  once here so it protects both the on-screen dialog and the
 *  clipboard copy, not just one of them. */
internal fun MainActivity.capLogText(text: String, maxChars: Int = 40_000): String =
    if (text.length <= maxChars) text
    else "…[${text.length - maxChars} earlier characters truncated — showing the most recent $maxChars]…\n\n" + text.takeLast(maxChars)


internal fun MainActivity.copyLinkDebugLog() {
    uiToast("Reading log…")
    Thread {
        val text = try {
            val f = File(filesDir, "link_debug.log")
            if (f.exists()) capLogText(f.readText()) else ""
        } catch (e: Exception) {
            Log.e(TAG, "link log file read failed", e)
            "Couldn't read the log file directly (${e.message})."
        }
        // FIX 19: stamp the exact moment THIS device's copy happened, in
        // the same MM-DD HH:MM:SS.mmm layout the log lines themselves
        // use (see link_log_write_locked()'s own comment in mgba_jni.c)
        // — two phones' copies never land at quite the same instant (a
        // human taps one button, then walks to the other phone and taps
        // its button too), and until now the only way to tell how far
        // apart two captures really were was comparing the last real SIO
        // line on each side, which only works if both sides were still
        // actively exchanging data right up to the tap — not during a
        // lull, and not at all if one side's tail is mostly idle
        // padding. This line answers "how far apart were these two
        // captures" directly, every time.
        val stamp = java.text.SimpleDateFormat("MM-dd HH:mm:ss.SSS", java.util.Locale.US)
            .format(java.util.Date())
        val stamped = if (text.isBlank()) text else "$text\n=== copied at $stamp ==="
        runOnUiThread { showLinkDebugLogDialog(stamped) }
    }.start()
}


internal fun MainActivity.showLinkDebugLogDialog(logText: String) {
    val shown = logText.ifBlank {
        "(empty — make sure both phones' ROMs were actually navigated " +
        "into their in-game link/multiplayer menu during this session, " +
        "not just the app-level Connected step; for a disconnect issue, " +
        "also actually tap Disconnect and wait a few seconds before " +
        "reading this log. If this stays empty even after a real " +
        // FIX (this pass): nativeSetLinkLogPath() no longer opens the
        // file itself (see its own KDoc in EmulatorEngine.kt) — it's
        // opened when a link session actually starts, so the relevant
        // Logcat line to check for moved too.
        "attempt, check Logcat for \"Link log path recorded\" around " +
        "app startup, and \"Link multiplayer started\" when connecting " +
        "— if neither appears, or the second one does but this is " +
        "still empty, that's the actual file-open failing.)"
    }
    try {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("mGBA link log", shown))
    } catch (e: Exception) {
        Log.w(TAG, "Clipboard copy failed (log is still shown below)", e)
    }
    // BUG FIX: was setTextIsSelectable(true) — see capLogText()'s doc
    // comment. The clipboard copy just above already covers "get this
    // text out of the phone"; on-screen selection was a nice-to-have
    // that turned out to cause a real ANR, so it's gone rather than
    // just gated behind a length check — not worth the risk twice.
    val textView = TextView(this).apply {
        text = shown
        textSize = 11f
        typeface = Typeface.MONOSPACE
        setTextColor(Color.WHITE)
        setPadding(dp(20), dp(16), dp(20), dp(16))
    }
    AlertDialog.Builder(this)
        .setTitle("Link debug log (copied to clipboard)")
        .setView(ScrollView(this).apply { addView(textView) })
        .setPositiveButton("Close", null)
        .show()
}


// ── Crash log ─────────────────────────────────────────────────────────
// See installCrashLogger()'s doc comment (near onCreate) for the why —
// this just reads back what that handler wrote, the same read-off-
// main-thread-then-show-a-dialog shape as copyLinkDebugLog() above.
internal fun MainActivity.copyCrashLog() {
    uiToast("Reading crash log…")
    Thread {
        val text = try {
            val f = File(filesDir, "crash_log.txt")
            if (f.exists()) capLogText(f.readText()) else ""
        } catch (e: Exception) {
            Log.e(TAG, "crash log file read failed", e)
            "Couldn't read the crash log file directly (${e.message})."
        }
        runOnUiThread { showCrashLogDialog(text) }
    }.start()
}


internal fun MainActivity.showCrashLogDialog(logText: String) {
    val shown = logText.ifBlank {
        "(empty — no crash recorded since this build was installed. If " +
        "it crashes again, come straight back here afterward; the next " +
        "launch will have written a fresh report before you even see " +
        "this menu again.)"
    }
    try {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("mGBA crash log", shown))
    } catch (e: Exception) {
        Log.w(TAG, "Clipboard copy failed (log is still shown below)", e)
    }
    // BUG FIX: see capLogText()'s doc comment — same reasoning as
    // showLinkDebugLogDialog() above.
    val textView = TextView(this).apply {
        text = shown
        textSize = 11f
        typeface = Typeface.MONOSPACE
        setTextColor(Color.WHITE)
        setPadding(dp(20), dp(16), dp(20), dp(16))
    }
    AlertDialog.Builder(this)
        .setTitle("Crash log (copied to clipboard)")
        .setView(ScrollView(this).apply { addView(textView) })
        .setPositiveButton("Close", null)
        .show()
}


// ── Screenshot ───────────────────────────────────────────────────────
// FEATURE: new — didn't exist before.
// FIX (this pass — direct report: "the png on save still capture
// button on game screen it should be only game screen no button even
// if there one on game screen and check if screenshot do the same"):
// used to PixelCopy the SurfaceView itself, then crop to
// gameScreenRect (cropToGameScreen(), deleted this pass) — correct
// for a button positioned outside the game area, but a no-op for one
// dragged on top of it, since PixelCopy captures the game and every
// on-screen button already composited together with nothing left to
// tell them apart. captureGameFrameBitmap() (below, shared with
// captureStateThumbnail()) copies the raw pre-controls frame instead
// — see its own doc comment for the full reasoning — so there's no
// longer a triple-buffer synchronization concern to avoid by staying
// on PixelCopy the way there used to be.
internal fun MainActivity.takeScreenshot() {
    if (!romLoaded) { uiToast("Load a ROM first"); return }
    val w = gameScreenRect.width().roundToInt()
    val h = gameScreenRect.height().roundToInt()
    val bmp = captureGameFrameBitmap(w, h)
    if (bmp == null) { uiToast("Screenshot failed"); return }
    // FIX: saveScreenshotBitmap() does real work — a PNG compress plus
    // a blocking file (or SAF) write, the latter potentially slow on a
    // cloud-backed Storage folder. captureGameFrameBitmap() above is
    // fast/synchronous (a small fixed-size buffer copy, not a
    // full-surface PixelCopy round trip), but the save itself still
    // gets the same "move the actual I/O off whatever thread happened
    // to call this" treatment as quickSaveState()/quickLoadState()'s
    // own lag-pass fix and the link-log dialog's ANR fix.
    Thread { saveScreenshotBitmap(bmp) }.apply { name = "mGBA-screenshot" }.start()
}


internal fun MainActivity.saveScreenshotBitmap(bmp: Bitmap) {
    val stamp = DateFormat.format("yyyyMMdd_HHmmss", System.currentTimeMillis())
    val name = "${currentRomBaseName}_$stamp.png"
    try {
        // FEATURE: Storage folder — see the block comment above
        // dataFolderTree(). Screenshots always create a brand-new,
        // uniquely-timestamped file, never look up an existing one, so
        // this doesn't need the full find-or-create SaveEntry
        // machinery the save/state files below do — just create it
        // directly in the "screenshot" subfolder when one's configured.
        val subDir = dataSubfolder("screenshot")
        if (subDir != null) {
            val doc = subDir.createFile("image/png", name)
                ?: throw IOException("Couldn't create $name in the chosen folder")
            contentResolver.openOutputStream(doc.uri)?.use { out ->
                bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
            } ?: throw IOException("openOutputStream failed for $name")
        } else {
            // FIX (pass 43): used to be a bare "Screenshots" folder
            // directly under getExternalFilesDir(null) — still correct
            // (zero permission, survives Settings → Storage → Clear
            // cache) but sitting apart from saves/states/layout instead
            // of alongside them under one obvious root. Now nested under
            // the same automatic mirror root those use — see
            // autoFolderRoot()/autoMirrorSubdir() above dataSubfolder().
            val dir = autoMirrorSubdir("Screenshots")
                ?: File(getExternalFilesDir(null), "Screenshots").apply { mkdirs() }
            File(dir, name).outputStream().use { out -> bmp.compress(Bitmap.CompressFormat.PNG, 100, out) }
        }
        uiToast("Saved $name")
    } catch (e: Exception) {
        Log.e(TAG, "Screenshot save failed", e)
        uiToast("Screenshot save failed")
    }
}


// ── Reset ────────────────────────────────────────────────────────────
// FEATURE: new. There's no standalone core-reset entry point on the
// native side — core->reset() is only ever called from inside
// nativeLoadROM() itself (see mgba_jni.c) — and this project's own
// history shows JNI signature mismatches only turning up once a real CI
// build ran against the actual pinned mGBA headers (see FIX 8 in
// mgba_jni.c). A brand-new hand-written JNI export isn't worth that
// build-and-pray risk just for this, so this reuses nativeLoadROM()
// instead: the last-loaded ROM's bytes are still sitting at the fixed
// cache path below (see the ROM-picker callback above — it's never
// deleted), so reloading from there with the same battery-save path is
// a full power-cycle — same user-visible effect as a hardware reset,
// save data intact — through a path that's already proven to build and
// work rather than a new, unverifiable one.

internal fun MainActivity.resetGame() {
    if (!romLoaded) { uiToast("Load a ROM first"); return }
    val tmp = cacheDir.resolve("rom_loaded.gba")
    if (!tmp.exists()) { uiToast("Can't reset — try Close, then Load ROM"); return }
    if (link.isConnected) stopLink()
    stopGameLoop()
    val baseName = currentRomBaseName
    Thread {
        val saveEntry = batterySaveEntry(baseName)
        backupIfExists(saveEntry)
        // FIX (Twenty-first pass): see loadRomFromUri's own comment on
        // batteryMirrorPath() replacing the /proc/self/fd bridge.
        val savePath = saveEntry.batteryMirrorPath()
        val ok = EmulatorEngine.nativeLoadROM(tmp.absolutePath, savePath)
        // FIX: onPause()/closeGame() both flush the battery-save mirror
        // (syncBatteryMirror()/mirrorToAutoFolder()) right after a
        // session ends; resetGame() didn't, so Reset → force-kill the
        // app before it's ever paused or closed again could leave the
        // opt-in Storage-folder/auto-folder mirror one session behind.
        // Local save data itself was never at risk (it's the same .sav
        // file the core writes to directly) — this only keeps the
        // mirror consistent with the rest of this class's own pattern.
        // Reuses the saveEntry already in scope above rather than
        // constructing a fresh batterySaveEntry(currentRomBaseName)
        // like the other two call sites — same underlying file, no
        // need for a second resolution. Already off the main thread
        // here (this whole block runs on the background Thread this
        // function starts below), unlike onPause()'s own main-thread
        // calls — strictly better for the same reason takeScreenshot()
        // was just moved off it too.
        if (ok) { saveEntry.syncBatteryMirror(); saveEntry.mirrorToAutoFolder() }
        Handler(Looper.getMainLooper()).post {
            if (isFinishing || isDestroyed) return@post
            if (ok) {
                val w = EmulatorEngine.nativeGetWidth().coerceAtLeast(1)
                val h = EmulatorEngine.nativeGetHeight().coerceAtLeast(1)
                frameBuffers = Array(3) { Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888) }
                writeIdx = 0; readyIdx = -1; displayIdx = -1
                clearPointerState(); currentKeys.set(0); fastForwardActive = false
                initAudioTrack()
                startGameLoop()
                uiToast("Game reset")
            } else {
                romLoaded = false
                uiToast("Reset failed — ROM may be missing from cache")
            }
        }
    }.apply { name = "mGBA-reset" }.start()
}


// ── Close ────────────────────────────────────────────────────────────
// FEATURE: new. Stops the current game and drops back to ROM selection.
// Nothing needs freeing on the native side for this — nativeLoadROM()
// already swaps cores cleanly on the next load (see the FIX comment
// above the ROM-picker callback) — so this just stops the loop/audio
// and restores the pre-load UI.
//
// BUG FIX (earlier pass): Close used to only flip the old floating
// "Load ROM" button back to VISIBLE and stop there, leaving the
// SurfaceView untouched. A SurfaceView just keeps showing whatever it
// last drew until something draws over it again, so the closed game's
// last frame stayed sitting there until a new ROM was loaded and
// rendered its own first frame. Fixed by wiping the surface to black
// immediately (clearSurfaceToBlack()) and handing off straight to
// changeRom(), which opens the file browser directly if a ROM folder's
// already been picked, otherwise prompts to pick one. That button is
// gone now (see the FIX comment in onCreate where it used to be built)
// — romLoaded is left false here, so if changeRom()'s own picker gets
// cancelled, a tap on the idle surface (see onGameTouch()) is the way
// back in instead.
internal fun MainActivity.closeGame() {
    if (!romLoaded) return
    if (link.isConnected) stopLink()
    stopGameLoop()
    try { audioTrack?.pause(); audioTrack?.flush() } catch (_: Exception) {}
    // FIX (Twenty-first pass): flush the battery-save mirror out to the
    // chosen Storage folder before this ROM's session is considered
    // over — see onPause()'s own copy of this call for the fuller
    // explanation. Closing back to the ROM browser is exactly the kind
    // of "I'm done with this game for now" moment that should sync,
    // same as backgrounding the app. mirrorToAutoFolder() alongside it
    // — see the FEATURE block above dataFolderTree() — same sync,
    // automatic own-folder mirror instead of a chosen SAF folder.
    batterySaveEntry(currentRomBaseName).syncBatteryMirror()
    batterySaveEntry(currentRomBaseName).mirrorToAutoFolder()
    romLoaded = false
    // FIX (this pass): see applyScreenOrientationPref()'s own doc
    // comment. Flips this activity back to Portrait right here, before
    // changeRom() below reopens RomBrowserActivity — stopGameLoop()
    // above has already halted rendering, so this is a clean single
    // rotation on this activity's own idle screen, not one smeared
    // across the browser's launch transition.
    applyScreenOrientationPref()
    clearSurfaceToBlack()
    uiToast("Game closed")
    changeRom()
}

