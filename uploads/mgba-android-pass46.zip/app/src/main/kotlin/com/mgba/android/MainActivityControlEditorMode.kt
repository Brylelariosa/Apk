package com.mgba.android

// Split out of MainActivity.kt (pass 46 — "refactor main activity into
// separate classes so organized") as internal extension functions on
// MainActivity, exactly the pattern already established in SharedUi.kt's
// own top-of-file comment (Thirty-second pass) for the same reason: every
// existing unqualified call site inside MainActivity.kt (and inside every
// other split-out file) keeps compiling completely unchanged, since Kotlin
// resolves an unqualified call to an internal extension function on the
// enclosing receiver type the same way it resolves a member call — no
// behavior change, purely a file-organization move. See MainActivity.kt's
// own top-of-file comment for the full file map.

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.text.InputType
import android.text.TextUtils
import android.text.format.DateFormat
import android.util.Log
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.Closeable
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.io.PrintWriter
import java.io.StringWriter
import java.util.concurrent.atomic.AtomicInteger
import java.util.zip.ZipInputStream
import kotlin.math.abs
import kotlin.math.roundToInt


internal fun MainActivity.enterEditMode() {
    if (!romLoaded) {
        uiToast("Load a ROM first — the editor previews live over the running game")
        return
    }
    editModeActive = true
    editSelectedId = null
    clearPointerState()  // else the finger that opened the editor stays "stuck" in
    currentKeys.set(0)   // pointerKeys and comes back held the instant the editor closes
    turboAHeld = false; turboBHeld = false
    editTopBar.visibility = View.VISIBLE
    editButtonBar.visibility = View.GONE
    uiToast("Drag to move • corner dot to resize • hold to remove")
}


internal fun MainActivity.exitEditMode(save: Boolean) {
    editModeActive = false
    editSelectedId = null
    editDragPointerId = -1
    editResizing = false
    cancelEditLongPress()
    editTopBar.visibility = View.GONE
    editButtonBar.visibility = View.GONE
    if (save) { saveCustomLayout(); uiToast("Layout saved") }
    else { loadCustomLayout(); uiToast("Changes discarded") }
    buildControlLayout(lastSw, lastSh)
}


internal fun MainActivity.confirmResetAllLayout() {
    AlertDialog.Builder(this)
        .setTitle("Reset layout?")
        .setMessage("This clears every custom position/size for this orientation, brings back any removed controls, and clears any extra controls you've added. You can still Cancel afterward to undo.")
        .setPositiveButton("Reset") { _, _ ->
            customLayout.clear()
            removedButtons.clear()
            addedExtraButtons.clear()
            editDirty = true
            editSelectedId = null
            editButtonBar.visibility = View.GONE
            buildControlLayout(lastSw, lastSh)
            uiToast("Reset — tap Done to save, or Cancel to undo")
        }
        .setNegativeButton("Keep", null)
        .show()
}


internal fun MainActivity.resetSingleButton(id: String) {
    customLayout.remove(id)
    editDirty = true
    // The sliders show a live value now (the old "-"/"+" chips didn't),
    // so a Reset needs to refresh them back to the default too, or
    // they'd keep showing whatever was selected right before the reset.
    //
    // FIX (this pass): that sync now runs BEFORE rebuilding/
    // repositioning, not after. Reset can also flip a locked control
    // back to unlocked, which changes editLockBtn's text ("Locked" ->
    // the wider "Unlocked") — syncing too late meant the toolbar got
    // measured+positioned for the shorter label it had *before* this
    // call, so the wider one (applied a moment later, but never
    // re-clamped against) could spill past where it was just placed.
    // buildControlLayout() below already repositions the toolbar
    // itself once editModeActive (see its own trailing
    // refreshEditToolbarPosition() call), so the old explicit call
    // after it was also just dead weight.
    syncEditButtonBarToSelection()
    buildControlLayout(lastSw, lastSh)
}


/** Sets the selected control's size directly to [percent] (50-800,
 *  matching the slider's own range) — replaces the old delta-based
 *  adjustSelectedScale() now that a real slider (drag, or type an
 *  exact number) replaced the "-"/"+" chip pair. Same 0.5x-8.0x clamp
 *  as before, for the same reason: still a real, finite ceiling rather
 *  than none at all, just far enough out it should be a rare,
 *  deliberate choice rather than a wall anyone runs into. */
internal fun MainActivity.setSelectedScalePercent(percent: Int) {
    val id = editSelectedId ?: return
    val e = entryFor(id)
    if (e.locked) { uiToast("Unlock this control first"); return }
    e.scale = (percent / 100f).coerceIn(0.5f, 8.0f)
    editDirty = true
    // buildControlLayout() already repositions the toolbar itself once
    // editModeActive (see its own trailing refreshEditToolbarPosition()
    // call) — the separate call this used to make right after was
    // redundant (harmless here, but see resetSingleButton() just above
    // for a case where the same redundant-call pattern actually mattered).
    buildControlLayout(lastSw, lastSh)
}


/** Sets the selected control's opacity directly to [percent] —
 *  replaces the old delta-based adjustSelectedAlpha(). */
internal fun MainActivity.setSelectedAlphaPercent(percent: Int) {
    val id = editSelectedId ?: return
    val e = entryFor(id)
    if (e.locked) { uiToast("Unlock this control first"); return }
    e.alphaOverride = percentToAlpha(percent)
    editDirty = true
}


internal fun MainActivity.toggleSelectedLock() {
    val id = editSelectedId ?: return
    val e = entryFor(id)
    e.locked = !e.locked
    editDirty = true
    syncEditButtonBarToSelection()
}


/** Refreshes every part of the per-item editor bar that depends on
 *  which control is selected and that control's own live state — label
 *  text (including the "Game Screen Size"/"Control Size" swap),
 *  Locked/Unlocked text, the opacity row's visibility (hidden for the
 *  game screen — see editOpacityRow's own field comment), and both
 *  sliders' position/enabled state.
 *
 *  FIX (this pass): folds in what used to be
 *  updateEditButtonBarLockIcon() (deleted — this is its one caller's
 *  replacement too) plus onEditTouch's own inline label/visibility
 *  lines — one place instead of three, and specifically the one that
 *  now needs to run after Reset and the lock toggle too, now that the
 *  sliders show a live value those two can change out from under them
 *  (the old chips had no live value that could ever go stale). Does
 *  nothing if nothing is selected. */
internal fun MainActivity.syncEditButtonBarToSelection() {
    val id = editSelectedId ?: return
    editButtonLabel.text = labelFor(id)
    editSizeLabel.text = if (id == "gamescreen") "Game Screen Size" else "Control Size"
    editOpacityRow.visibility = if (id == "gamescreen") View.GONE else View.VISIBLE
    val locked = isSelectedLocked(id)
    editLockBtn.text = if (locked) "Locked" else "Unlocked"
    editSizeSlider.setValue(currentScalePercent(id))
    editSizeSlider.setEnabled(!locked)
    if (id != "gamescreen") {
        editOpacitySlider.setValue(currentAlphaPercent(id))
        editOpacitySlider.setEnabled(!locked)
    }
    // FEATURE (this pass — see nudgeSelected()'s own doc comment):
    // same disabled-when-locked treatment as the sliders just above —
    // nudgeSelected() already refuses a locked control on its own,
    // this just keeps the four buttons from looking tappable when
    // they'd have nothing to do. Same explicit alpha dim as
    // SliderRow.setEnabled() in SharedUi.kt (see its own comment):
    // isEnabled alone doesn't visibly change a flat setBackgroundColor()
    // button the way it does a themed widget like SeekBar.
    val nudgeAlpha = if (locked) 0.5f else 1f
    for (btn in listOf(editNudgeUpBtn, editNudgeDownBtn, editNudgeLeftBtn, editNudgeRightBtn)) {
        btn.isEnabled = !locked
        btn.alpha = nudgeAlpha
    }
}


/** Repositions the per-button toolbar just above (or below, if that
 *  would collide with the top bar) the currently selected control.
 *
 *  FIX (an earlier pass — direct report: the popup "sometimes it get
 *  cut off its weird"): used to read editButtonBar.width/.height
 *  straight off the view — only accurate *after* a layout pass had
 *  actually measured it at its current content, which changes size
 *  every time a different control gets selected (see
 *  syncEditButtonBarToSelection() above: the opacity row alone can
 *  appear/disappear) — deferred via .post{} to try to land after that
 *  pass, with 480/110 as a guessed fallback for whenever it didn't.
 *  Calling measure() directly (still done below) sidesteps that race
 *  entirely: safe any time, no fallback guess left to be wrong, no
 *  post{} delay before the bar lands in the right place.
 *
 *  FIX (an earlier pass — same direct report, still reproducible after
 *  the above): the clamp was only ever as good as its margin, and that
 *  margin used to be a bare `4f`/`12f` inline — four and twelve *raw
 *  pixels*, sub-1dp and ~4dp respectively on anything past ~mdpi. Not a
 *  real margin, which is exactly what read as "cut off": dragging a
 *  control into a corner clamped the bar flush against the screen edge
 *  with no visible gap at all, even though w/h were already accurate
 *  and nothing was technically clipped. Same raw-px-vs-dp mistake
 *  resizeHandleTouchRadius() had; fixed the same way, via the named dp
 *  constants in the companion object and the shared clampToScreenAxis()
 *  helper (next to clampRectToScreen()) instead of two hand-rolled
 *  coerceIn() calls for tx/ty.
 *
 *  FIX (this pass — same direct report yet again: "still cut off
 *  specially if you move the button at the bottom of the screen"):
 *  both fixes above are still in effect and still correct, but neither
 *  one actually finished the job. measure() computes accurate w/h —
 *  fine for the tx/ty math right below it — but measure() alone never
 *  lays editButtonBar's children out at those sizes; that still only
 *  happens on Android's own next layout pass, scheduled asynchronously
 *  off the visibility flip in onEditTouch, i.e. the exact same
 *  "accurate only after a layout pass has run" race the very first fix
 *  above already named, just moved one step later instead of actually
 *  closed. A single tap-to-select usually has a frame of slack before
 *  anything's drawn, so that pass lands in time and looks fine — which
 *  is exactly why this kept slipping past testing. A resize/move drag
 *  calls this function on every ACTION_MOVE tick, competing with that
 *  same pending pass far more often, and whatever frame actually got
 *  drawn could still be showing editRow2/editOpacityRow laid out at an
 *  earlier, smaller state (or not laid out at all yet) — on screen,
 *  that reads as only row 1 rendering and the rest "cut off", worse
 *  the longer/more actively a control near an edge gets dragged.
 *  layout() below forces that pass to happen right here, synchronously,
 *  against the exact sizes just measured, so editButtonBar's own
 *  children can never lag a frame behind the number this function
 *  already computed.
 *
 *  FIX (this pass — same direct report yet again: "still get cut off
 *  if you move button down"): all three fixes above are still correct
 *  and still in effect, but none of them ever touched the actual
 *  placement *decision* — only how accurately w/h got measured before
 *  it. That decision was a one-sided threshold: "does placing the bar
 *  above the control get too close to the top bar?" It never asked the
 *  other half of the question — how much room *below* actually had —
 *  so a control dragged low enough that "above" barely cleared that
 *  one threshold still got the above placement even when below would
 *  have had far more room to give, and on this app's normal landscape
 *  orientation (a short screen) that's exactly the configuration where
 *  the trailing clampToScreenAxis() call had the least slack left to
 *  work with, reading on screen as the bar's own bottom rows running
 *  out of room. Replaced with an explicit comparison of the real room
 *  on both sides — whichever side has more wins, "above" kept as the
 *  tiebreak so a normal, comfortably-placed control looks unchanged —
 *  plus a hard coerceAtLeast(topBound) after the usual clamp, so the
 *  bar can never end up above the top bar even in the one remaining
 *  case (topBound+h doesn't fit below lastSh at all) neither placement
 *  choice can fully solve. Shrinking the panel itself this same pass
 *  (EDIT_TOOLBAR_ROW_GAP_DP/_SLIDER_WIDTH_DP here, SharedUi.kt's
 *  EDIT_TOOLBAR_VALUE_BOX_* for the readout boxes) is the other half
 *  of this fix — a smaller h/w makes that one remaining case
 *  correspondingly harder to ever reach on a real device.
 *
 *  FIX (pass 43 — same direct report yet again: "if you move it
 *  sometimes it disappears or get cutoff"): the fix directly above
 *  already named this gap by exact name ("the one remaining case
 *  (topBound+h doesn't fit below lastSh at all)") but only ever
 *  documented it, never closed it — clampToScreenAxis() provably
 *  keeps clampedTy within [margin, lastSh-h-margin] (see that
 *  function's own doc comment), but the trailing
 *  .coerceAtLeast(topBound) ran *after* that guarantee as a second,
 *  independent floor with no ceiling of its own, so on a short enough
 *  effective screen — a small/older phone in this app's normal
 *  landscape orientation, or a resizable/multi-window session,
 *  nothing exotic — topBound can legitimately exceed
 *  lastSh-h-margin, and coerceAtLeast doesn't know that: it pushes
 *  clampedTy up past the ceiling clampToScreenAxis() just
 *  established, out the bottom of the screen. That's "disappears" at
 *  the extreme (genuinely off-screen) and "get cutoff" for a milder
 *  overshoot — the same root cause either way. "If you move it" was
 *  never a coincidence: dragging low enough for roomBelow to shrink
 *  toward zero is exactly what lands ty in the branch this affects.
 *  Fixed below by making topBound a *preference* clamped alongside
 *  everything else in one coerceIn, not an independent floor applied
 *  after the fact — see the inline comment at the fix itself.
 *
 *  FIX (this pass — same direct report a fifth time): the clamp math
 *  itself, as of pass 43 directly above, is sound — every input it's
 *  given provably stays within bounds. What wasn't sound was one of
 *  those inputs: topBound read editTopBar.height alone, but editTopBar
 *  is wrapped in editTopBarScroll (a HorizontalScrollView, added so
 *  the row degrades to scrollable instead of clipping — see its own
 *  construction site) which is what's actually positioned in root with
 *  its own topMargin, a margin topBound never accounted for at all.
 *  That margin was *also* raw pixels rather than dp (editTopBarScroll's
 *  own fix, right where it's built) — on a high-density phone, small
 *  on its own, but compounding with topBound's separate blind spot to
 *  feed the exact same downstream clamp four previous fix attempts
 *  each re-tuned without ever checking. topBound now reads
 *  editTopBarScroll's own height plus the same margin constant that
 *  wrapper's topMargin actually uses (below), instead of the unwrapped
 *  child and an implicit assumption of zero. */
/** Applies a new fixed width to a sliderRow()'s root — mutates the
 *  existing LinearLayout.LayoutParams in place (the same object the
 *  parent already holds) rather than building a new one, so the
 *  measure()/layout() pair right after this call in
 *  refreshEditToolbarPosition() picks it up with nothing further to
 *  wire up: LinearLayout reads each child's current LayoutParams
 *  fresh on every measure pass, and the SeekBar inside (weight=1,
 *  width=0 — see sliderRow() in SharedUi.kt) re-flows into whatever
 *  total width this leaves it automatically, standard LinearLayout
 *  weight behavior, nothing bespoke needed here. */
internal fun MainActivity.setSliderRowWidth(row: SliderRow, widthPx: Int) {
    (row.root.layoutParams as? LinearLayout.LayoutParams)?.width = widthPx
}


internal fun MainActivity.refreshEditToolbarPosition() {
    val id = editSelectedId ?: return
    val rect = editRectFor(id) ?: return
    val margin = dp(EDIT_TOOLBAR_SCREEN_MARGIN_DP).toFloat()
    // FIX (direct report, still reproducible after every earlier fix
    // in this function's own history above: "the button customization
    // pop up still get cut off if you move around the button"): every
    // one of those earlier fixes only ever clamped where the bar gets
    // POSITIONED — none ever questioned whether the bar's own
    // intrinsic width could fit the screen at all. editRow2/
    // editOpacityRow's sliders were a *fixed*
    // EDIT_TOOLBAR_SLIDER_WIDTH_DP (190dp) regardless of screen size —
    // fine on a wide landscape screen (this app's normal orientation,
    // and clearly what that constant was tuned against), but on a
    // narrower one — a portrait phone's own width being the common
    // case, see buildControlLayout's own portrait fixes this same
    // pass — editRowLabelWidthPx (~110dp) plus that fixed 190dp
    // slider plus this bar's own horizontal padding can add up to
    // more than the screen has room for at all. No amount of
    // clamping *position* can fix a box that's simply wider than the
    // screen: clampToScreenAxis()'s own fallback (see its own doc
    // comment) only ever keeps it from sliding off one particular
    // side, but the excess width still has to go somewhere, and "off
    // the other side" is exactly what read as "cut off". Shrinking
    // the sliders themselves, right here, before the measure() below,
    // closes the gap those position-only fixes never could. On a
    // screen with room to spare (every existing landscape install)
    // maxSliderWidthPx below is never smaller than the 190dp design
    // width, so this is a no-op there — it only ever engages on a
    // screen too narrow to fit that design width, exactly the case
    // that was never actually fixed before.
    val maxBarWidthPx = (lastSw - 2 * margin).toInt()
    val contentWidthPx = maxBarWidthPx - editButtonBar.paddingLeft - editButtonBar.paddingRight
    val maxSliderWidthPx = (contentWidthPx - editRowLabelWidthPx)
        .coerceIn(dp(EDIT_TOOLBAR_SLIDER_MIN_WIDTH_DP), dp(EDIT_TOOLBAR_SLIDER_WIDTH_DP))
    setSliderRowWidth(editSizeSlider, maxSliderWidthPx)
    setSliderRowWidth(editOpacitySlider, maxSliderWidthPx)
    // FIX (see editRow1ChipsWidthPx's own field comment: editRow1 —
    // editButtonLabel + editLockBtn + editResetBtn — was never
    // width-constrained by any fix above, all of which only ever
    // touched row 2/3's slider). editLockBtn/editResetBtn are kept at
    // their full, fully-tappable natural width — editRow1ChipsWidthPx
    // reserves exactly that much — and editButtonLabel (not
    // interactive, and the one row-1 element with real text-length
    // variance — see labelFor()) absorbs whatever shrinking is needed
    // instead, the same "shrink the row that can afford it, leave
    // interactive controls alone" split the slider fix above already
    // uses.
    editButtonLabel.maxWidth = (contentWidthPx - editRow1ChipsWidthPx)
        .coerceAtLeast(dp(EDIT_TOOLBAR_LABEL_MIN_WIDTH_DP))
    editButtonBar.measure(
        View.MeasureSpec.makeMeasureSpec(lastSw.toInt().coerceAtLeast(1), View.MeasureSpec.AT_MOST),
        View.MeasureSpec.makeMeasureSpec(lastSh.toInt().coerceAtLeast(1), View.MeasureSpec.AT_MOST)
    )
    val w = editButtonBar.measuredWidth
    val h = editButtonBar.measuredHeight
    // See "this pass" above: measure() alone doesn't lay children out —
    // this does, synchronously, right now, against w/h. (0,0,w,h) is a
    // local/pre-translation rect, not a screen position; .x/.y below
    // (translation, applied on top of whatever left/top layout() just
    // set) is still what actually places the bar on screen, unchanged
    // from before.
    editButtonBar.layout(0, 0, w, h)
    val gap = dp(EDIT_TOOLBAR_GAP_DP).toFloat()
    // The bar must never render above this line on either side. Reads
    // editTopBarScroll — the actual view positioned in root, margin
    // and all — not editTopBar, the child it wraps (see this pass's
    // fix in the doc comment above): margin is the exact same
    // dp(EDIT_TOOLBAR_SCREEN_MARGIN_DP) editTopBarScroll's own
    // topMargin uses at its construction site, so this can never
    // silently drift out of sync with the real view again the way
    // editTopBar.height alone did.
    val topBound = margin + editTopBarScroll.height + gap
    val roomAbove = rect.top - gap - topBound
    val roomBelow = (lastSh - margin) - (rect.bottom + gap)
    // The actual fix: compare both sides instead of only ever checking
    // "does above avoid the top bar?". Above wins ties so an unmoved/
    // centered control is positioned exactly as before.
    val ty = if (roomAbove >= h || roomAbove >= roomBelow) {
        rect.top - h - gap
    } else {
        rect.bottom + gap
    }
    val tx = clampToScreenAxis(rect.centerX() - w / 2f, w.toFloat(), lastSw, margin)
    // FIX (pass 43): topBound is now honored only when there's room to
    // do so without ever pushing the bar past the bottom of the
    // screen (topBound <= maxTy) — otherwise this falls back to the
    // screen's own top margin instead, trading "the bar might touch
    // the top bar's own strip" (still fully visible and usable) for
    // "the bar might run off the bottom of the screen" (not visible
    // or usable at all). One coerceIn, not clamp-then-separately-
    // floor, so the result can never land outside [minTy, maxTy]
    // regardless of how topBound/h/lastSh relate to each other —
    // minTy <= maxTy always holds since maxTy is itself never below
    // margin, and minTy is only ever topBound when topBound already
    // fits under that same maxTy. See this function's own doc
    // comment for the full reasoning/report this closes.
    val maxTy = (lastSh - h - margin).coerceAtLeast(margin)
    val minTy = if (topBound <= maxTy) topBound else margin
    val clampedTy = ty.coerceIn(minTy, maxTy)
    editButtonBar.x = tx
    editButtonBar.y = clampedTy
}


internal fun MainActivity.onEditTouch(event: MotionEvent) {
    when (event.actionMasked) {
        MotionEvent.ACTION_DOWN -> {
            val x = event.x; val y = event.y
            val hitId = hitTestEditable(x, y)
            if (hitId == null) {
                editSelectedId = null
                editButtonBar.visibility = View.GONE
                return
            }
            editSelectedId = hitId
            editDragPointerId = event.getPointerId(0)
            editDownX = x; editDownY = y
            val rect = editRectFor(hitId) ?: return
            // BUG FIX: was resizeHandleRadius(rect) * 1.6f — a tiny,
            // non-dp-aware radius (see resizeHandleTouchRadius's own
            // comment for the full root-cause). This is the down-time
            // decision for "did this touch grab the resize handle", now
            // using the same generous, density-aware radius that
            // hitTestEditable() uses to even let the touch reach here.
            val handleR = resizeHandleTouchRadius(rect)
            editResizing = dist(x, y, rect.right, rect.bottom) <= handleR
            if (editResizing) {
                editResizeStartDist = dist(x, y, rect.centerX(), rect.centerY()).coerceAtLeast(1f)
                editResizeStartScale = customLayout[hitId]?.scale ?: 1f
            } else {
                editDragOffX = x - rect.centerX()
                editDragOffY = y - rect.centerY()
                // ADD/REMOVE CONTROL — hold-to-remove: armed only for a
                // plain grab (not a resize-grab, so holding the corner
                // handle still just resizes). Cancelled by real movement
                // (ACTION_MOVE below) or the finger lifting first.
                val pressedId = hitId
                val longPress = Runnable {
                    if (editSelectedId == pressedId && editDragPointerId != -1) {
                        editLongPressPending = null
                        editDragPointerId = -1   // gesture is now "consumed" by the menu, not a drag
                        showRemoveButtonMenu(pressedId)
                    }
                }
                editLongPressPending = longPress
                mainHandler.postDelayed(longPress, ViewConfiguration.getLongPressTimeout().toLong())
            }
            // CUSTOMIZATION UI: label text, "Game Screen Size" vs
            // "Control Size", opacity-row visibility, lock text, and
            // both sliders — everything that depends on which control
            // is now selected — all come from one place; see that
            // function's own comment for why.
            syncEditButtonBarToSelection()
            editButtonBar.visibility = View.VISIBLE
            refreshEditToolbarPosition()
        }
        MotionEvent.ACTION_MOVE -> {
            val id = editSelectedId ?: return
            // BUG FIX (this pass): gameScreenRect is a fixed box while
            // Stretch to Fit is on (see updateGameMatrix()) — it can
            // still be *selected* here if it was selected before
            // Settings > Video > Stretch to Fit got toggled on without
            // leaving the editor first, but dragging/resizing it any
            // further would only edit a customLayout entry that mode
            // never reads. hitTestEditable() already stops it from
            // being newly selected while stretched; this stops that
            // one narrow leftover path too.
            if (id == "gamescreen" && stretchToFit) return
            val ptr = event.findPointerIndex(editDragPointerId)
            if (ptr < 0) return
            val e = entryFor(id)
            if (e.locked) return
            val x = event.getX(ptr); val y = event.getY(ptr)
            if (editLongPressPending != null && dist(x, y, editDownX, editDownY) > editTouchSlop) {
                cancelEditLongPress()
            }
            if (editResizing) {
                val c = editRectFor(id)
                val d = dist(x, y, c?.centerX() ?: x, c?.centerY() ?: y)
                // Matches setSelectedScalePercent()'s own cap above —
                // see its comment for why 8x, not the old 2.5x/4x.
                var newScale = (editResizeStartScale * (d / editResizeStartDist)).coerceIn(0.5f, 8.0f)
                // GRID: snap AFTER computing the raw scale, so the
                // stored value is always exactly on-grid when enabled
                // — never "close" to a grid line, see
                // snapScaleToGrid()'s own comment for why width is the
                // single source of truth here.
                if (snapToGrid) newScale = snapScaleToGrid(id, newScale)
                e.scale = newScale
                // FIX (direct report: "moving button make it that it
                // can't go over the screen"): growing a control via
                // this handle never moved its position before — fine
                // while there was room on every side to grow into, but
                // a control resized-up near an edge (or corner) could
                // grow straight off-screen with nothing to stop it, the
                // same underlying bug as the plain-drag case just
                // below, just reached by resizing into an edge instead
                // of dragging into one. Re-clamps the *existing* center
                // against the newly-grown box so growing a control near
                // an edge gently pushes it back on-screen instead of
                // letting it run past — see clampControlCenterToScreen()
                // for the shared on-screen guarantee this and the drag
                // branch below now both go through.
                defaultGeometry[id]?.let { g ->
                    val (clampedCx, clampedCy) = clampControlCenterToScreen(
                        e.xFrac * lastSw, e.yFrac * lastSh,
                        g.w * newScale, g.h * newScale, lastSw, lastSh
                    )
                    e.xFrac = clampedCx / lastSw.coerceAtLeast(1f)
                    e.yFrac = clampedCy / lastSh.coerceAtLeast(1f)
                }
                // FIX (this pass): the Control Size slider needs to
                // track this corner-drag gesture too, not just its own
                // drag — otherwise it'd show a stale value the instant
                // this *other* resize gesture changes e.scale out from
                // under it. Only the size slider (not a full
                // syncEditButtonBarToSelection()) since that's the only
                // thing this particular gesture can change, and this
                // runs on every ACTION_MOVE tick.
                editSizeSlider.setValue(currentScalePercent(id))
            } else {
                // FIX (direct report: "moving button make it that it
                // can't go over the screen"): this used to be
                // (x - editDragOffX).coerceIn(lastSw*0.03f, lastSw*0.97f)
                // — a fixed 3–97% band on the CENTER point only, blind
                // to how big the control actually is. A large control
                // (or one resized up) dragged near an edge still had
                // its rendered box run well past the screen even
                // though its center obediently stayed inside that
                // band. clampControlCenterToScreen() clamps the center
                // against the control's actual current size (its
                // default w/h from defaultGeometry, times its current
                // scale) so the full box — not just its center point —
                // is what's kept on screen.
                val g = defaultGeometry[id]
                val fullW = (g?.w ?: 0f) * e.scale
                val fullH = (g?.h ?: 0f) * e.scale
                val (clampedCx, clampedCy) = clampControlCenterToScreen(
                    x - editDragOffX, y - editDragOffY, fullW, fullH, lastSw, lastSh
                )
                var cx = clampedCx
                var cy = clampedCy
                // GRID: snap AFTER the existing on-screen clamp (not
                // before) so snapping is always the last word on the
                // final position — clamping a snapped point could
                // nudge it back off-grid, snapping a clamped point
                // never does.
                if (snapToGrid) {
                    cx = snapPositionToGrid(cx)
                    cy = snapPositionToGrid(cy)
                }
                e.xFrac = cx / lastSw.coerceAtLeast(1f)
                e.yFrac = cy / lastSh.coerceAtLeast(1f)
            }
            editDirty = true
            buildControlLayout(lastSw, lastSh)
        }
        MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
            if (event.getPointerId(event.actionIndex) == editDragPointerId) {
                cancelEditLongPress()
                editDragPointerId = -1
                editResizing = false
            }
        }
        MotionEvent.ACTION_CANCEL -> {
            cancelEditLongPress()
            editDragPointerId = -1
            editResizing = false
        }
    }
}


/** Moves the selected control by ([dxPx], [dyPx]) — wired to the four
 *  ^/v/</> chips added this pass (direct report: "add a way to move
 *  button without swipe like arrow up down left right"). Deliberately
 *  goes through the exact same clampControlCenterToScreen()/
 *  snapPositionToGrid() calls onEditTouch's own ACTION_MOVE plain-drag
 *  branch above uses (down to reading the same e.locked/stretchToFit
 *  guards it checks first) rather than a simpler direct xFrac/yFrac
 *  write: one path for "the control's position changed" no matter
 *  whether it got there by drag or by tap, so a nudge can never place
 *  a control somewhere off-screen, off-grid (when Grid is on), or
 *  past a lock that a drag couldn't also have reached — and any
 *  future change to either guarantee only has one place to be made,
 *  not two that could quietly drift apart. */
internal fun MainActivity.nudgeSelected(dxPx: Float, dyPx: Float) {
    val id = editSelectedId ?: return
    if (id == "gamescreen" && stretchToFit) return
    val e = entryFor(id)
    if (e.locked) return
    val g = defaultGeometry[id]
    val fullW = (g?.w ?: 0f) * e.scale
    val fullH = (g?.h ?: 0f) * e.scale
    val (clampedCx, clampedCy) = clampControlCenterToScreen(
        e.xFrac * lastSw + dxPx, e.yFrac * lastSh + dyPx, fullW, fullH, lastSw, lastSh
    )
    var cx = clampedCx
    var cy = clampedCy
    if (snapToGrid) {
        cx = snapPositionToGrid(cx)
        cy = snapPositionToGrid(cy)
    }
    e.xFrac = cx / lastSw.coerceAtLeast(1f)
    e.yFrac = cy / lastSh.coerceAtLeast(1f)
    editDirty = true
    buildControlLayout(lastSw, lastSh)
    // Unlike a drag tick, a nudge tap doesn't already have another
    // frame about to redraw it — refreshEditToolbarPosition() is
    // otherwise only reached per-frame (see drawControls()) or from
    // inside onEditTouch itself, neither of which a plain button tap
    // goes through, so this is called directly to move the popup
    // along with the control it's now attached to, immediately.
    refreshEditToolbarPosition()
}


internal fun MainActivity.cancelEditLongPress() {
    editLongPressPending?.let { mainHandler.removeCallbacks(it) }
    editLongPressPending = null
}


/** Hold-to-remove popup — shown when [id]'s long-press timer fires in
 *  onEditTouch(). Deliberately a single tap-to-confirm action rather
 *  than a second confirmation dialog: removal is already low-stakes
 *  since "Add Control" (showAddControlMenu) and Cancel both undo it. */
internal fun MainActivity.showRemoveButtonMenu(id: String) {
    // "gamescreen" isn't a real, removable control the way every other
    // id here is — there's nothing sensible "remove the game screen"
    // would even mean. Guarded here rather than at the long-press
    // arming site so this stays the one choke point regardless of what
    // ends up calling it.
    if (editSelectedId != id || id == "gamescreen") return
    val dialog = AlertDialog.Builder(this)
        .setItems(arrayOf("Remove ${labelFor(id)}")) { _, _ -> removeButton(id) }
        .setNegativeButton("Cancel", null)
        .create()
    dialog.window?.setBackgroundDrawable(roundedDialogBackground())
    dialog.show()
}


internal fun MainActivity.removeButton(id: String) {
    if (id in extraControlIds) addedExtraButtons.remove(id) else removedButtons.add(id)
    if (editSelectedId == id) {
        editSelectedId = null
        editButtonBar.visibility = View.GONE
    }
    editDirty = true
    buildControlLayout(lastSw, lastSh)
    uiToast("${labelFor(id)} removed — tap Add Control to bring it back")
}


/** Every button id the editor knows how to draw — the source list for
 *  "+ Add control" (showAddControlMenu). extraControlIds (Turbo A/B,
 *  the shoulder/A-B combos, and the quick save/load/screenshot
 *  actions) are always listed here — each is independently opt-in via
 *  this same per-button add/remove system, with nothing else that has
 *  to be enabled first for any of them to work.
 *
 *  FIX (stale-comment cleanup, this pass): this used to say Turbo A/B
 *  only counted as "addable" while a separate Turbo setting (⚙
 *  Settings → Input) was on. PREF_TURBO was removed a previous pass —
 *  see the comment where extraControlIds is declared — and Turbo A/B
 *  moved into this exact opt-in-per-button system alongside everything
 *  else here; ta/tb work exactly like any other extraControlIds entry
 *  now, no separate gate left to describe. */
internal fun MainActivity.allControlIds(): List<String> {
    val ids = mutableListOf("dpad", "a", "b", "select", "start", "l", "r", "ff")
    ids += extraControlIds
    return ids
}


internal fun MainActivity.showAddControlMenu() {
    val hidden = allControlIds().filter { !isButtonVisible(it) }
    if (hidden.isEmpty()) { uiToast("Every control is already on screen"); return }
    val labels = hidden.map { labelFor(it) }.toTypedArray()
    val dialog = AlertDialog.Builder(this)
        .setTitle("Add control")
        .setItems(labels) { _, which ->
            val id = hidden[which]
            if (id in extraControlIds) addedExtraButtons.add(id) else removedButtons.remove(id)
            editDirty = true
            buildControlLayout(lastSw, lastSh)
            uiToast("${labelFor(id)} added")
        }
        .setNegativeButton("Cancel", null)
        .create()
    dialog.window?.setBackgroundDrawable(roundedDialogBackground())
    dialog.show()
}


/** Grid Size / Show Grid / Snap to Grid — reached from the "Grid" chip
 *  on the editor's own top bar (see editTopBar in onCreate) rather
 *  than buried in the Settings screens, since none of it means
 *  anything outside the editor. Same Save/Cancel shape as
 *  showLayoutsSettings() just below — applies together on Save,
 *  consistent with every other multi-control popup in this app.
 *  Grid Size offers presets rather than free-entry, matching the
 *  request directly ("Example: 4×4, 8×8, 16×16") and every other
 *  size-like setting in this app (Button size, Button opacity), which
 *  are already presets, not free text fields, for the same reason. */
internal fun MainActivity.showGridSettingsDialog() {
    val ctx = this
    val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    val layout = ctx.dialogContentLayout()

    layout.addView(TextView(ctx).apply {
        text = "Grid Size"; textSize = 12f; setTextColor(Color.WHITE)
    })
    // FIX (Fortieth pass): 64 added (was capped at 32 — "add more like
    // 60 not just 30", direct request) and labels are now the bare
    // number instead of "N×N" — cells are square (gridCellPx()), so an
    // N×N label would claim N columns AND N rows, which stopped being
    // true the moment the cell size started coming from just the
    // shorter dimension. The description text below spells out what
    // the number actually means instead.
    val gridOptions = listOf(4, 8, 16, 32, 64)
    val gridRadio = dlgRadioGroup(horizontal = false)
    gridOptions.forEach { n -> gridRadio.dlgAddOpt("$n") }
    val curGridIdx = gridOptions.indexOf(gridDivisions).takeIf { it >= 0 } ?: 1
    (gridRadio.getChildAt(curGridIdx) as RadioButton).isChecked = true
    layout.addView(gridRadio)

    val showGridCheck = CheckBox(ctx).apply {
        text = "Show Grid"
        isChecked = showGrid
        setTextColor(Color.WHITE)
        setPadding(0, dp(24), 0, 0)
    }
    layout.addView(showGridCheck)

    val snapGridCheck = CheckBox(ctx).apply {
        text = "Snap to Grid"
        isChecked = snapToGrid
        setTextColor(Color.WHITE)
        setPadding(0, dp(8), 0, 0)
    }
    layout.addView(snapGridCheck)

    layout.addView(TextView(ctx).apply {
        text = "Aligns buttons and the game screen while customizing. Doesn't change the actual gameplay display. " +
            "Cells are always square — the number is how many fit across the shorter side of the screen."
        textSize = 11f; setTextColor(Color.parseColor("#888892"))
        setPadding(0, dp(16), 0, 0)
    })

    AlertDialog.Builder(ctx)
        .setTitle("Grid Settings")
        .setView(ScrollView(ctx).also { it.addView(layout) })
        .setPositiveButton("Save") { _, _ ->
            val selIdx = (0 until gridRadio.childCount)
                .firstOrNull { (gridRadio.getChildAt(it) as RadioButton).isChecked } ?: curGridIdx
            gridDivisions = gridOptions[selIdx]
            showGrid   = showGridCheck.isChecked
            snapToGrid = snapGridCheck.isChecked
            prefs.edit()
                .putInt(PREF_GRID_SIZE, gridDivisions)
                .putBoolean(PREF_SHOW_GRID, showGrid)
                .putBoolean(PREF_SNAP_GRID, snapToGrid)
                .apply()
        }
        .setNegativeButton("Cancel", null)
        .show()
}


/** Draws the alignment grid — gridDivisions square cells across the
 *  shorter screen dimension, see gridCellPx() — over the whole screen.
 *  Purely a rendering aid — reads only gridDivisions/showGrid (via
 *  gridCellPx()/lastSw/lastSh), never writes anything, so it can never
 *  itself change what's actually saved for any control. Independent of
 *  editSelectedId on purpose: "visible while customizing if enabled"
 *  means visible any time the editor is open, not just while something
 *  is selected. FIX (Fortieth pass): draws lines a fixed cell-size
 *  apart instead of exactly N lines spanning the width and N spanning
 *  the height — see gridCellPx()'s own comment for why that's what
 *  makes the cells square instead of a w/N-by-h/N rectangle. */
internal fun MainActivity.drawGrid(canvas: Canvas) {
    if (!showGrid) return
    val cell = gridCellPx()
    if (cell <= 0f) return
    val w = canvas.width.toFloat(); val h = canvas.height.toFloat()
    var x = cell
    while (x < w) { canvas.drawLine(x, 0f, x, h, gridLinePaint); x += cell }
    var y = cell
    while (y < h) { canvas.drawLine(0f, y, w, y, gridLinePaint); y += cell }
}


internal fun MainActivity.drawEditOverlay(canvas: Canvas) {
    canvas.drawRect(0f, 0f, canvas.width.toFloat(), canvas.height.toFloat(), editDimPaint)
    drawGrid(canvas)
    val id = editSelectedId ?: return
    val rect = editRectFor(id) ?: return
    canvas.drawRoundRect(rect, 12f, 12f, editHighlightPaint)
    canvas.drawCircle(rect.right, rect.bottom, resizeHandleRadius(rect), editHandlePaint)
}

