package com.mgba.android

// Split out of MainActivity.kt (pass 46 — "refactor main activity into
// separate classes so organized") as internal extension functions on
// MainActivity, exactly the pattern already established in SharedUi.kt's
// own top-of-file comment (Thirty-second pass) for the same reason: every
// existing unqualified call site inside MainActivity.kt (and inside every
// other split-out file) keeps compiling completely unchanged, since Kotlin
// resolves an unqualified call to an internal extension function on the
// enclosing receiver type the same way it resolves a member call — no
// behavior change, purely a file-organization move. See MainActivity.kt's
// own top-of-file comment for the full file map.

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.text.InputType
import android.text.TextUtils
import android.text.format.DateFormat
import android.util.Log
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.Closeable
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.io.PrintWriter
import java.io.StringWriter
import java.util.concurrent.atomic.AtomicInteger
import java.util.zip.ZipInputStream
import kotlin.math.abs
import kotlin.math.roundToInt


/** Runs [action] immediately if Bluetooth permission is already granted
 *  (or not needed on this API level), otherwise requests it first. */
internal fun MainActivity.ensureBluetoothPermission(action: () -> Unit) {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) { action(); return }
    val granted = ContextCompat.checkSelfPermission(
        this, Manifest.permission.BLUETOOTH_CONNECT
    ) == PackageManager.PERMISSION_GRANTED
    if (granted) { action() }
    else { pendingBtAction = action; btPermissionLauncher.launch(Manifest.permission.BLUETOOTH_CONNECT) }
}


// ── Link cable UI ──────────────────────────────────────────────────────
// Split into two Settings rows — "Link remote" (Wi-Fi) and "Link local"
// (Bluetooth) — instead of one combined dialog behind the old floating
// 🔗 button (see buildSettingsMenu()). Nothing about the connect logic
// itself changed, just how it's reached. Status used to also update
// that floating button's label; now it's toasts only, plus the existing
// ⬤ LINK canvas overlay (drawLinkStatus, below) for "still connected".

internal fun MainActivity.showLinkRemoteDialog() {
    if (link.isConnected) { showLinkDisconnectDialog(); return }
    AlertDialog.Builder(this).setTitle("Link Remote — Wi-Fi")
        .setItems(arrayOf("Host", "Join")) { _, i ->
            when (i) {
                0 -> link.startWifiHost(
                    onReady     = { ip -> uiToast("Waiting…\nIP: $ip") },
                    onConnected = { onLinkConnected(true,  "Wi-Fi") },
                    onError     = { uiToast("Host error: $it") })
                1 -> {
                    uiToast("Scanning…")
                    link.discoverWifiHosts(
                        onFound = { hosts ->
                            if (hosts.isEmpty()) showIpDialog()
                            else AlertDialog.Builder(this)
                                .setTitle("Select host")
                                .setItems(hosts.toTypedArray()) { _, j -> joinWifi(hosts[j]) }
                                .setNegativeButton("Enter IP") { _, _ -> showIpDialog() }.show()
                        },
                        onError = { showIpDialog() })
                }
            }
        }.show()
}


internal fun MainActivity.showLinkLocalDialog() {
    if (link.isConnected) { showLinkDisconnectDialog(); return }
    AlertDialog.Builder(this).setTitle("Link Local — Bluetooth")
        .setItems(arrayOf("Host", "Join")) { _, i ->
            when (i) {
                // FIX: BLUETOOTH_CONNECT is a runtime-dangerous permission on API 31+.
                // It was declared in the manifest but never requested, so tapping either
                // of these two options crashed the app on Android 12+ with an uncaught
                // SecurityException from listenUsingInsecureRfcommWithServiceRecord() /
                // createInsecureRfcommSocketToServiceRecord() / getBondedDevices().
                0 -> ensureBluetoothPermission {
                    uiToast("Starting host…")
                    link.startBluetoothHost(
                        onConnected = { onLinkConnected(true,  "Bluetooth") },
                        onError     = { uiToast("BT error: $it") })
                }
                1 -> ensureBluetoothPermission {
                    val devs = link.getBondedDevices()
                    if (devs.isEmpty()) { uiToast("No paired devices"); return@ensureBluetoothPermission }
                    AlertDialog.Builder(this).setTitle("Choose device")
                        .setItems(devs.map { it.name ?: it.address }.toTypedArray()) { _, j ->
                            uiToast("Connecting…")
                            link.connectBluetooth(devs[j],
                                onConnected = { onLinkConnected(false, "Bluetooth") },
                                onError     = { uiToast("BT error: $it") })
                        }.show()
                }
            }
        }.show()
}


internal fun MainActivity.showLinkDisconnectDialog() {
    AlertDialog.Builder(this).setTitle("Link Connected ✓")
        .setItems(arrayOf("Disconnect")) { _, _ -> stopLink() }.show()
}


internal fun MainActivity.showIpDialog() {
    val et = EditText(this).apply { hint = "192.168.x.x" }
    AlertDialog.Builder(this).setTitle("Host IP").setView(et)
        .setPositiveButton("Connect") { _, _ -> joinWifi(et.text.toString().trim()) }.show()
}


internal fun MainActivity.joinWifi(ip: String) {
    if (ip.isBlank()) return
    uiToast("Connecting…")
    link.connectWifi(ip,
        onConnected = { onLinkConnected(false, "Wi-Fi") },
        onError     = { uiToast("Connect error: $it") })
}


internal fun MainActivity.onLinkConnected(isHost: Boolean, via: String) {
    val ok = EmulatorEngine.nativeLinkStart(link, isHost)
    uiToast("Link via $via${if (!ok) " (SIO error)" else ""}")
}


internal fun MainActivity.stopLink() {
    EmulatorEngine.nativeLinkStop(); link.disconnect()
    uiToast("Disconnected")
}

