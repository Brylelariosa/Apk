package com.mgba.android

// Split out of MainActivity.kt (pass 46 — "refactor main activity into
// separate classes so organized") as internal extension functions on
// MainActivity, exactly the pattern already established in SharedUi.kt's
// own top-of-file comment (Thirty-second pass) for the same reason: every
// existing unqualified call site inside MainActivity.kt (and inside every
// other split-out file) keeps compiling completely unchanged, since Kotlin
// resolves an unqualified call to an internal extension function on the
// enclosing receiver type the same way it resolves a member call — no
// behavior change, purely a file-organization move. See MainActivity.kt's
// own top-of-file comment for the full file map.

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.text.InputType
import android.text.TextUtils
import android.text.format.DateFormat
import android.util.Log
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.Closeable
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.io.PrintWriter
import java.io.StringWriter
import java.util.concurrent.atomic.AtomicInteger
import java.util.zip.ZipInputStream
import kotlin.math.abs
import kotlin.math.roundToInt


// ── Shared dialog-building helpers (used by several categories below) ──

internal fun MainActivity.dlgRadioGroup(horizontal: Boolean = true) = RadioGroup(this).apply {
    if (horizontal) orientation = LinearLayout.HORIZONTAL
}

internal fun RadioGroup.dlgAddOpt(label: String): RadioButton = RadioButton(context).apply {
    text = label
    id   = View.generateViewId()
    setTextColor(Color.WHITE)
    textSize = 13f
}.also { addView(it) }


/** Plain tappable row for the Video list — no icon, unlike settingsRow()
 *  above (that one's for the Settings category list one level up; this
 *  screen's own reference screenshot has no icons on its rows at all). */
internal fun MainActivity.videoListRow(title: String, subtitle: String?, onClick: () -> Unit): View {
    val ctx = this
    return LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        isClickable = true; isFocusable = true
        setBackgroundResource(rippleBackgroundResId())
        setPadding(dp(20), dp(14), dp(20), dp(14))
        addView(TextView(ctx).apply { text = title; textSize = 16f; setTextColor(Color.WHITE) })
        if (subtitle != null) {
            addView(TextView(ctx).apply {
                text = subtitle; textSize = 12f
                setTextColor(Color.parseColor("#888892"))
                setPadding(0, dp(2), 0, 0)
            })
        }
        setOnClickListener { onClick() }
    }
}


internal fun MainActivity.videoCheckRow(title: String, subtitle: String?, checked: Boolean, onToggle: (Boolean) -> Unit): View {
    val ctx = this
    val textCol = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        addView(TextView(ctx).apply { text = title; textSize = 16f; setTextColor(Color.WHITE) })
        if (subtitle != null) {
            addView(TextView(ctx).apply {
                text = subtitle; textSize = 12f
                setTextColor(Color.parseColor("#888892"))
                setPadding(0, dp(2), 0, 0)
            })
        }
    }
    val box = CheckBox(ctx).apply { isChecked = checked }
    box.setOnCheckedChangeListener { _, isChecked -> onToggle(isChecked) }
    return LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(20), dp(14), dp(20), dp(14))
        isClickable = true; isFocusable = true
        setOnClickListener { box.isChecked = !box.isChecked }
        addView(textCol, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        addView(box)
    }
}


internal fun MainActivity.videoDivider(): View = View(this).apply {
    setBackgroundColor(Color.parseColor("#22FFFFFF"))
}


// roundedDialogBackground() moved to SharedUi.kt — sliderRow() there
// needs it too, and it's exactly the kind of small/stateless/cosmetic
// helper that file already exists for. Every call site below is
// unchanged (still an unqualified same-package extension-function
// call).

// ── Video ────────────────────────────────────────────────────────────
//
// FEATURE (this pass): rebuilt to match a reference screenshot's plain
// list layout (title + optional gray subtitle per row, checkboxes on
// the boolean ones, thin dividers) instead of the previous single form
// with everything crammed into one Save/Cancel dialog. "Screen size"
// and "Screen orientation" now each open their own follow-on screen
// rather than showing inline controls here — showScreenOrientationDialog()
// and showMaxFrameSkipsDialog() below.
//
// "Enable OpenGL" and "GLSL Shader" from that same reference screenshot
// are deliberately NOT here. This app's renderer has only ever been a
// Canvas/SurfaceView pipeline (see updateGameMatrix()/renderFrame()) —
// there's no OpenGL rendering path to switch to at all, let alone a
// shader system to plug GLSL into. A checkbox that doesn't actually
// change anything is worse than no checkbox — building the real thing
// (an EGL/GLSurfaceView pipeline alongside or replacing the current
// one) would be a genuinely large, separate undertaking, not something
// to fake here alongside everything else this pass. "Linear filtering"
// doesn't need OpenGL to be real, so it's included and fully wired
// (see gamePaint/updateLinearFilterPaint() above) — just not gated
// behind an OpenGL toggle that doesn't exist.
internal fun MainActivity.showVideoSettings() {
    val ctx = this
    val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    var dialog: AlertDialog? = null
    val layout = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }

    layout.addView(videoCheckRow(
        "Stretch to fit screen",
        "Always stretch to fill the entire screen in landscape mode",
        stretchToFit
    ) { isChecked ->
        stretchToFit = isChecked
        prefs.edit().putBoolean(PREF_STRETCH, isChecked).apply()
        if (running) updateGameMatrix(lastSw, lastSh)
    })
    layout.addView(videoDivider())

    // FEATURE: used to open a 35/44/52/65% picker here, then (last
    // pass) just a navigation fix into the editor with nothing
    // resizable to do once there. This pass: the game screen is a
    // real drag-and-resize participant in that editor now, same as
    // any button — see gameScreenRect/resolvedRect("gamescreen", ...)
    // in updateGameMatrix(). Opening the editor is enough; nothing
    // more specific to navigate to.
    //
    // FIX (this pass): reported as not actually appearing until
    // Settings was closed first. dialog?.dismiss() only ever closed
    // this Video popup — settingsMenuOverlay (the Settings screen
    // *underneath* it, a separate full-screen opaque overlay) was
    // never touched, so it stayed covering the editor that had, in
    // fact, already started underneath it the whole time. Both need
    // to close for the editor to actually become visible/usable.
    layout.addView(videoListRow("Screen size", "Drag and resize the game screen directly") {
        dialog?.dismiss()
        settingsMenuOverlay.visibility = View.GONE
        enterEditMode()
    })
    layout.addView(videoDivider())

    layout.addView(videoListRow("Screen orientation", null) {
        showScreenOrientationDialog()
    })
    layout.addView(videoDivider())

    layout.addView(videoListRow("Max frame skips", "Maximum number of consecutive frame skips") {
        showMaxFrameSkipsDialog()
    })
    layout.addView(videoDivider())

    layout.addView(videoCheckRow(
        "Linear filtering",
        "Smooths the upscaled image instead of showing crisp pixels",
        linearFilterEnabled
    ) { isChecked ->
        linearFilterEnabled = isChecked
        prefs.edit().putBoolean(PREF_LINEAR_FILTER, isChecked).apply()
        updateLinearFilterPaint()
    })

    dialog = AlertDialog.Builder(ctx)
        .setTitle("🖥  Video")
        .setView(ScrollView(ctx).also { it.addView(layout) })
        .setNegativeButton("Close", null)
        .create()
    dialog.window?.setBackgroundDrawable(roundedDialogBackground())
    dialog.show()
}


/** Standalone orientation picker — a reference screenshot's own popup
 *  style (title + single-choice list + Cancel only, no separate
 *  Save/OK) rather than the inline radio group this used to be part
 *  of inside showVideoSettings(). Applies immediately on tap, same as
 *  that reference's own behavior reads: there's no reason to make
 *  someone confirm a second time for a single choice like this one. */
internal fun MainActivity.showScreenOrientationDialog() {
    val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    val options = listOf(
        "Auto rotate"       to ORIENTATION_AUTO,
        "Landscape"         to ORIENTATION_LANDSCAPE,
        "Reverse landscape" to ORIENTATION_REVERSE_LANDSCAPE,
        "Portrait"          to ORIENTATION_PORTRAIT,
        "System default"    to ORIENTATION_SYSTEM
    )
    val curIdx = options.indexOfFirst { it.second == screenOrientationChoice }.takeIf { it >= 0 } ?: 1
    val dialog = AlertDialog.Builder(this)
        .setTitle("Screen orientation")
        .setSingleChoiceItems(options.map { it.first }.toTypedArray(), curIdx) { d, which ->
            val newOrientation = options[which].second
            screenOrientationChoice = newOrientation
            prefs.edit().putInt(PREF_ORIENTATION, newOrientation).apply()
            applyScreenOrientationPref()
            d.dismiss()
        }
        .setNegativeButton("Cancel", null)
        .create()
    dialog.window?.setBackgroundDrawable(roundedDialogBackground())
    dialog.show()
}


/** Max frame skips picker — a reference screenshot's own slider-dialog
 *  style (title + centered number readout + slider + Cancel/OK).
 *  0 keeps every frame (default, previous behavior); 1–10 lets the
 *  game loop skip up to that many consecutive blits while genuinely
 *  behind — see maybeSkipRenderThisFrame's logic inline in
 *  startGameLoop(). */
internal fun MainActivity.showMaxFrameSkipsDialog() {
    val ctx = this
    val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    val layout = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(24), dp(4), dp(24), dp(0))
    }
    val valueText = TextView(ctx).apply {
        text = maxFrameSkips.toString()
        textSize = 16f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
    }
    layout.addView(valueText)
    val seek = SeekBar(ctx).apply {
        max = 10
        progress = maxFrameSkips
    }
    seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(sb: SeekBar, value: Int, fromUser: Boolean) { valueText.text = value.toString() }
        override fun onStartTrackingTouch(sb: SeekBar) {}
        override fun onStopTrackingTouch(sb: SeekBar) {}
    })
    layout.addView(seek)

    val dialog = AlertDialog.Builder(ctx)
        .setTitle("Max frame skips")
        .setView(layout)
        .setPositiveButton("OK") { _, _ ->
            maxFrameSkips = seek.progress
            prefs.edit().putInt(PREF_MAX_SKIPS, maxFrameSkips).apply()
        }
        .setNegativeButton("Cancel", null)
        .create()
    dialog.window?.setBackgroundDrawable(roundedDialogBackground())
    dialog.show()
}

