package com.mgba.android

// Split out of MainActivity.kt (pass 46 — "refactor main activity into
// separate classes so organized") as internal extension functions on
// MainActivity, exactly the pattern already established in SharedUi.kt's
// own top-of-file comment (Thirty-second pass) for the same reason: every
// existing unqualified call site inside MainActivity.kt (and inside every
// other split-out file) keeps compiling completely unchanged, since Kotlin
// resolves an unqualified call to an internal extension function on the
// enclosing receiver type the same way it resolves a member call — no
// behavior change, purely a file-organization move. See MainActivity.kt's
// own top-of-file comment for the full file map.

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.text.InputType
import android.text.TextUtils
import android.text.format.DateFormat
import android.util.Log
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.Closeable
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.io.PrintWriter
import java.io.StringWriter
import java.util.concurrent.atomic.AtomicInteger
import java.util.zip.ZipInputStream
import kotlin.math.abs
import kotlin.math.roundToInt


// ── Audio ──────────────────────────────────────────────────────────────
//
// AUDIO ARCHITECTURE (rewritten)
// ───────────────────────────────
// Old design: game thread ran nativeRunFrame() once, wrote PCM to
// AudioTrack with WRITE_NON_BLOCKING (return value discarded), then slept
// for a *fixed* 1/60 s to pace itself. Two compounding problems:
//   1. 1/60 s is not the GBA's real frame period (see GBA_CYCLES_PER_FRAME
//      above), so the loop fed audio ~0.46% faster than it could play.
//   2. WRITE_NON_BLOCKING silently drops whatever doesn't fit — so that
//      surplus was thrown away in little bursts instead of building
//      genuine latency, producing a small periodic glitch.
//
// New design: the game thread writes PCM with a genuine *blocking* write
// and does NOT sleep on its own for the normal-speed case — the blocking
// write against a real audio clock (the DAC/HAL drain rate) becomes the
// frame pacer. This is the same "audio-locked" sync strategy used by most
// well-engineered software emulators: the audio hardware clock is far more
// stable than Thread.sleep(), which is at the mercy of OS scheduling
// jitter, so tying video pacing to it removes drift entirely instead of
// approximating a fixed wall-clock rate. A short fallback sleep
// (FALLBACK_FRAME_NS) only kicks in for frames that produce zero audio
// samples (e.g. immediately after a ROM loads), so the loop never spins
// unpaced if audio is temporarily unavailable.
//
// Fast-forward now plays audio too, instead of dropping it outright.
// Each FF batch's sub-frame audio is accumulated (ffAccumBuffer) and
// then box-filter decimated down to roughly one frame's worth — see
// decimateForFastForward() below — before going through the same
// blocking writePcm() pacer as normal playback. That keeps the loop's
// real-time pacing (and therefore the actual speedup) intact while
// producing real, audible, pitched-up audio: the same "sped-up tape"
// effect classic emulators use for FF sound, not a pitch-accurate
// resample. A proper interpolating resampler would sound cleaner but is
// a substantially bigger DSP undertaking for a fairly small audible gain
// over this.
// (audioTrack / audioBuffer / audioDiagCounter fields are declared above,
// grouped with the rest of the class's mutable state.)

/**
 * (Re)creates the AudioTrack.
 *
 * Buffer size: minBuf * 3. This used to be minBuf * 2 for lower latency,
 * but that cut it too close: rendering used to run on this same thread
 * right after each writePcm() call, and a slow render (a GC pause, a
 * busy compositor) could stall the next write long enough for AudioTrack
 * to run dry — an underrun, heard as a click/pop. Rendering is now
 * decoupled onto its own Choreographer-driven loop (see the triple-buffer
 * fields near the top of this class and startGameLoop()), which removes
 * that particular stall, but minBuf*3 is left as-is: it's cheap headroom
 * against ordinary OS scheduling jitter on the write thread itself, and
 * there's no benefit to shaving it back down.
 *
 * PERFORMANCE_MODE_LOW_LATENCY (API 26+) opts into the platform's fast
 * mixer path when the device supports it. It's a request, not a
 * guarantee — unsupported devices silently fall back to the normal path
 * with no functional risk, so it's safe to always ask for it.
 */
internal fun MainActivity.initAudioTrack() {
    releaseAudio()
    // Any pending Sound-frequency-triggered rebuild is satisfied by
    // this call itself, whichever path actually triggered it — see
    // audioTrackRebuildPending's own field comment.
    audioTrackRebuildPending = false
    val minBuf = AudioTrack.getMinBufferSize(
        soundFrequencyHz,
        AudioFormat.CHANNEL_OUT_STEREO,
        AudioFormat.ENCODING_PCM_16BIT
    ).coerceAtLeast(4096)
    val bufferBytes = (minBuf * 3).coerceAtLeast(6144)

    val builder = AudioTrack.Builder()
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build()
        )
        .setAudioFormat(
            AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(soundFrequencyHz)
                .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                .build()
        )
        .setBufferSizeInBytes(bufferBytes)
        .setTransferMode(AudioTrack.MODE_STREAM)

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        builder.setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
    }

    audioTrack = try { builder.build() } catch (e: Exception) {
        Log.e(TAG, "AudioTrack.Builder failed, retrying without low-latency mode", e)
        // Some OEM audio HALs reject PERFORMANCE_MODE_LOW_LATENCY outright
        // instead of gracefully degrading. Retry once without it so a
        // quirky device still gets sound, even if not the fast path.
        try {
            AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build())
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(soundFrequencyHz)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                        .build())
                .setBufferSizeInBytes(bufferBytes)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
        } catch (e2: Exception) {
            Log.e(TAG, "AudioTrack unavailable on this device", e2)
            null
        }
    }
    // FIX (this pass): used to be a hardcoded setVolume(1.0f) — now
    // applies the actual Enable sound / Sound volume settings, the
    // same call the settings UI itself uses live (see
    // applyGameVolume()) so a freshly (re)built track always starts at
    // whatever the person last chose instead of momentarily full
    // volume regardless of it.
    applyGameVolume()
    requestAudioFocus()
    audioTrack?.play()
    audioDiagCounter = 0
    Log.d(TAG, "AudioTrack started (bufferBytes=$bufferBytes, minBuf=$minBuf, " +
            "sampleRate=$soundFrequencyHz, lowLatency=${Build.VERSION.SDK_INT >= Build.VERSION_CODES.O})")
}


/** Applies [soundEnabled]/[soundVolumePercent] to the live AudioTrack —
 *  called from initAudioTrack() itself (so a freshly built track always
 *  starts right) and directly from the settings UI on every change, for
 *  an immediate live update. Unlike a sample-rate change (see
 *  [audioTrackRebuildPending]'s own comment on why that one has to
 *  defer to the game thread), AudioTrack.setVolume() is explicitly
 *  documented as safe to call at any time from any thread while the
 *  track plays — a lightweight live parameter, not a lifecycle
 *  operation — so this can apply straight from the main thread with no
 *  special handling. */
internal fun MainActivity.applyGameVolume() {
    val gain = if (soundEnabled) soundVolumePercent / 100f else 0f
    try { audioTrack?.setVolume(gain.coerceIn(0f, 1f)) } catch (_: Exception) {}
}


/** Recomputes [soundFreqFactor]/[soundFreqAlpha] from [soundFrequencyHz]
 *  and resets the filter's continuous state — called once at startup
 *  (after loading the saved preference) and again whenever Sound
 *  frequency changes in settings, right alongside persisting the new
 *  value. See [applySoundFrequencyFilter] for what these actually
 *  drive. */
internal fun MainActivity.updateSoundFrequencyFactor() {
    soundFreqFactor = (44100 / soundFrequencyHz).coerceAtLeast(1)
    soundFreqAlpha = 2f / (soundFreqFactor + 1)
    soundFreqLpL = 0f
    soundFreqLpR = 0f
}


/** See the comment on [audioFocusRequest] for why this exists. */
internal fun MainActivity.requestAudioFocus() {
    val am = audioManager ?: return
    val granted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build())
            .setOnAudioFocusChangeListener(audioFocusListener)
            .build()
        audioFocusRequest = req
        am.requestAudioFocus(req) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
    } else {
        @Suppress("DEPRECATION")
        am.requestAudioFocus(
            audioFocusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN
        ) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
    }
    Log.d(TAG, "Audio focus granted=$granted")
}


internal fun MainActivity.abandonAudioFocus() {
    val am = audioManager ?: return
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        audioFocusRequest?.let { am.abandonAudioFocusRequest(it) }
        audioFocusRequest = null
    } else {
        @Suppress("DEPRECATION")
        am.abandonAudioFocus(audioFocusListener)
    }
}


internal fun MainActivity.releaseAudio() {
    try { audioTrack?.stop(); audioTrack?.release() } catch (_: Exception) {}
    audioTrack = null
    abandonAudioFocus()
}


/**
 * Blocking write of [count] interleaved stereo PCM pairs from
 * [audioBuffer] to the AudioTrack. Called from the game thread only.
 *
 * Unlike the old WRITE_NON_BLOCKING call (whose return value was
 * discarded), this checks the result:
 *   - a short write (0 < written < requested) retries the remainder —
 *     legitimate under blocking mode only if playback state changed
 *     mid-write (e.g. onPause() firing concurrently), in which case
 *     finishing the write is harmless and cheap.
 *   - ERROR_DEAD_OBJECT means the audio server died/restarted under us
 *     (e.g. mediaserver crash, or another app seized exclusive audio) —
 *     recreate the AudioTrack once and retry, rather than staying silent
 *     for the rest of the session.
 *   - any other negative error code is logged and the frame's audio is
 *     dropped; retrying indefinitely inside the game loop would risk
 *     hanging it.
 *
 * FEATURE (this pass): [applySoundFrequencyFilter] runs first, right
 * here, rather than at each of the game loop's 3 separate
 * nativeReadAudioSamples()/writePcm() call sites — one place applies
 * Sound frequency uniformly to all of them, including composing
 * correctly with decimateForFastForward()'s own output during fast-
 * forward automatically (its result is still 44100Hz-rate audio, same
 * as a normal frame's — see that function's own comment — so it needs
 * exactly the same treatment here, no special case).
 */
internal fun MainActivity.writePcm(count: Int) {
    if (count <= 0) return
    val pairs = applySoundFrequencyFilter(count)
    if (pairs <= 0) return
    val totalShorts = pairs * 2
    var track = audioTrack ?: return
    var offset = 0
    var attempts = 0
    while (offset < totalShorts && attempts < 2) {
        val n = try {
            track.write(audioBuffer, offset, totalShorts - offset, AudioTrack.WRITE_BLOCKING)
        } catch (e: Exception) {
            Log.e(TAG, "AudioTrack.write threw", e); return
        }
        when {
            n > 0 -> offset += n
            n == AudioTrack.ERROR_DEAD_OBJECT -> {
                Log.w(TAG, "AudioTrack died — reinitializing")
                initAudioTrack()
                track = audioTrack ?: return
                attempts++
            }
            n < 0 -> { Log.e(TAG, "AudioTrack.write error=$n"); return }
            else  -> return // n == 0: track not started / no progress possible right now
        }
    }
    // Lightweight real-device diagnostics: log the underrun counter every
    // ~5s (300 frames @ ~60Hz) rather than every frame, so it's cheap
    // enough to leave in a release build's logcat for field debugging.
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
        audioDiagCounter++
        if (audioDiagCounter >= 300) {
            audioDiagCounter = 0
            Log.d(TAG, "AudioTrack underrunCount=${audioTrack?.underrunCount}")
        }
    }
}


/**
 * Downsamples the first [count] stereo pairs of [audioBuffer] in place
 * to match [soundFrequencyHz] (see showSoundFrequencyDialog()) when
 * it's below the 44100Hz the core always produces, returning the new
 * (possibly smaller) pair count — a no-op returning [count] unchanged
 * at the default 44100Hz ([soundFreqFactor] == 1).
 *
 * Same "textbook" shape as decimateForFastForward() below — a one-pole
 * low-pass ahead of the downsample rather than plain box averaging, for
 * the same anti-aliasing reason — but with its own persistent
 * [soundFreqLpL]/[soundFreqLpR] state instead of resetting fresh every
 * call: decimateForFastForward() only ever runs once per accumulated
 * fast-forward batch, a genuinely fresh block each time, but this runs
 * on every single writePcm() call at normal speed — one real GBA
 * frame's worth of samples, back to back — so resetting the filter
 * every call would reintroduce a small transient at every frame
 * boundary instead of one continuous filter across the whole session.
 *
 * In place is safe here for the same reason it is in
 * decimateForFastForward(): the output index (i / [soundFreqFactor])
 * is never ahead of the input index i it's derived from, so a write
 * never clobbers a sample a later iteration still needs to read.
 *
 * IMPORTANT — why the AudioTrack's own configured rate has to match:
 * writePcm()'s blocking write is the game loop's actual frame pacer
 * (see its own doc comment and startGameLoop()'s) — it blocks until
 * the AudioTrack has room, and that room drains at whatever rate the
 * track is *configured* for (see initAudioTrack()'s own
 * setSampleRate(soundFrequencyHz)). Writing fewer samples at a
 * proportionally lower configured rate keeps the real-world duration
 * those samples represent the same either way, which is exactly what
 * keeps the core paced correctly — get the factor wrong (downsample
 * the data but leave the track at 44100, or vice versa) and the core
 * would end up running at the wrong *speed*, not just sounding wrong.
 * [soundFreqFactor] is always exactly 44100/soundFrequencyHz (1, 2, or
 * 4 — see updateSoundFrequencyFactor()), so this and initAudioTrack()
 * can never disagree.
 */
internal fun MainActivity.applySoundFrequencyFilter(count: Int): Int {
    val factor = soundFreqFactor
    if (factor <= 1) return count
    val outPairs = count / factor
    for (i in 0 until count) {
        soundFreqLpL += soundFreqAlpha * (audioBuffer[i * 2] - soundFreqLpL)
        soundFreqLpR += soundFreqAlpha * (audioBuffer[i * 2 + 1] - soundFreqLpR)
        if (i % factor == factor - 1) {
            val o = i / factor
            if (o < outPairs) {
                audioBuffer[o * 2] = soundFreqLpL.toInt().coerceIn(-32768, 32767).toShort()
                audioBuffer[o * 2 + 1] = soundFreqLpR.toInt().coerceIn(-32768, 32767).toShort()
            }
        }
    }
    return outPairs
}


/**
 * Fast-forward audio compression. Filters and downsamples [accumPairs]
 * stereo pairs in [ffAccumBuffer] (collected across [factor] emulated
 * sub-frames — see the game loop in startGameLoop) down into
 * `audioBuffer`, roughly [factor]x shorter, and returns how many pairs
 * it wrote there. Playing the shorter result back at the normal
 * 44.1kHz rate is what produces the audible pitch-up — expected,
 * inherent to speeding up audio this way, the same "chipmunk" effect
 * any sped-up tape/tune has, not something this function tries to
 * hide.
 *
 * FIX (this pass): reported as sounding "weird" during fast-forward —
 * on top of that expected pitch-up, there was a second, avoidable
 * problem. This used to be plain box-filter decimation (each output
 * pair the equal-weighted mean of one block of [factor] consecutive
 * input pairs), which the original version's own doc comment already
 * called "a cheap stand-in for a proper low-pass filter ahead of the
 * downsample." That stand-in has real weaknesses as an anti-aliasing
 * filter — weak stopband rejection lets high-frequency content fold
 * back down as audible harshness/grain on top of the pitch-up, and its
 * passband isn't flat either, adding a muffled quality. Replaced with
 * the textbook-standard shape instead — filter, then downsample,
 * rather than trying to make the averaging do both jobs at once: a
 * one-pole low-pass runs continuously across the whole accumulated
 * block first (cheap, one multiply-add per sample, so no heavier on
 * this thread than the box average it replaces), then every [factor]th
 * *filtered* sample is kept. alpha follows the standard
 * period-to-EMA-smoothing conversion (2/(period+1)) so the filter's
 * cutoff scales down as [factor] grows, same direction the box
 * average's own implicit cutoff moved, just with a real filter shape
 * behind it instead of a rectangular window's.
 */
internal fun MainActivity.decimateForFastForward(accumPairs: Int, factor: Int): Int {
    if (factor <= 1) {
        val n = accumPairs.coerceAtMost(audioBuffer.size / 2)
        System.arraycopy(ffAccumBuffer, 0, audioBuffer, 0, n * 2)
        return n
    }
    val outPairs = (accumPairs / factor).coerceAtMost(audioBuffer.size / 2)
    val alpha = 2f / (factor + 1)
    var lpL = ffAccumBuffer[0].toFloat()
    var lpR = ffAccumBuffer[1].toFloat()
    var out = 0
    for (i in 0 until accumPairs) {
        lpL += alpha * (ffAccumBuffer[i * 2]     - lpL)
        lpR += alpha * (ffAccumBuffer[i * 2 + 1] - lpR)
        if (out < outPairs && i % factor == factor - 1) {
            audioBuffer[out * 2]     = lpL.toInt().coerceIn(-32768, 32767).toShort()
            audioBuffer[out * 2 + 1] = lpR.toInt().coerceIn(-32768, 32767).toShort()
            out++
        }
    }
    return outPairs
}

