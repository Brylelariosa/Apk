package com.mgba.android

// Split out of MainActivity.kt (pass 46 — "refactor main activity into
// separate classes so organized") as internal extension functions on
// MainActivity, exactly the pattern already established in SharedUi.kt's
// own top-of-file comment (Thirty-second pass) for the same reason: every
// existing unqualified call site inside MainActivity.kt (and inside every
// other split-out file) keeps compiling completely unchanged, since Kotlin
// resolves an unqualified call to an internal extension function on the
// enclosing receiver type the same way it resolves a member call — no
// behavior change, purely a file-organization move. See MainActivity.kt's
// own top-of-file comment for the full file map.

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.text.InputType
import android.text.TextUtils
import android.text.format.DateFormat
import android.util.Log
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.Closeable
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.io.PrintWriter
import java.io.StringWriter
import java.util.concurrent.atomic.AtomicInteger
import java.util.zip.ZipInputStream
import kotlin.math.abs
import kotlin.math.roundToInt


// ── Audio ────────────────────────────────────────────────────────────
//
// FEATURE (this pass): rebuilt to match a reference screenshot's own
// list layout — Enable sound / Sound volume / Sound frequency — the
// same "list of rows, Close-only, each row applies immediately" shape
// showVideoSettings() above already moved to, replacing the old single
// Save/Cancel form this used to be (that old form held just one
// setting: the button-click sound toggle, removed this pass per a
// direct report — see the field comments near soundEnabled and
// updateGameKeys() above, which no longer has any click-sound logic at
// all).

internal fun MainActivity.showAudioSettings() {
    val ctx = this
    val layout = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }

    layout.addView(videoCheckRow(
        "Enable sound",
        "Plays game audio normally when on; muted when off",
        soundEnabled
    ) { isChecked ->
        soundEnabled = isChecked
        getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean(PREF_SOUND_ENABLED, isChecked).apply()
        applyGameVolume()
    })
    layout.addView(videoDivider())

    layout.addView(videoListRow(
        "Sound volume",
        "In-app volume, independent of the device's own media volume"
    ) { showSoundVolumeDialog() })
    layout.addView(videoDivider())

    layout.addView(videoListRow(
        "Sound frequency",
        "Lower rates use less CPU/battery at reduced audio quality"
    ) { showSoundFrequencyDialog() })

    val dialog = AlertDialog.Builder(ctx)
        .setTitle("🔊  Audio")
        .setView(ScrollView(ctx).also { it.addView(layout) })
        .setNegativeButton("Close", null)
        .create()
    dialog.window?.setBackgroundDrawable(roundedDialogBackground())
    dialog.show()
}


/** Sound volume picker — same reference screenshot's own slider-dialog
 *  style showMaxFrameSkipsDialog() above already uses (title + centered
 *  number readout + slider + Cancel/OK). Applies to the live
 *  AudioTrack immediately on OK via applyGameVolume() — same as
 *  Enable sound's own checkbox — rather than waiting for anything else
 *  to reload. */
internal fun MainActivity.showSoundVolumeDialog() {
    val ctx = this
    val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    val layout = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(24), dp(4), dp(24), dp(0))
    }
    val valueText = TextView(ctx).apply {
        text = soundVolumePercent.toString()
        textSize = 16f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
    }
    layout.addView(valueText)
    val seek = SeekBar(ctx).apply {
        max = 100
        progress = soundVolumePercent
    }
    seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(sb: SeekBar, value: Int, fromUser: Boolean) { valueText.text = value.toString() }
        override fun onStartTrackingTouch(sb: SeekBar) {}
        override fun onStopTrackingTouch(sb: SeekBar) {}
    })
    layout.addView(seek)

    val dialog = AlertDialog.Builder(ctx)
        .setTitle("Sound volume")
        .setView(layout)
        .setPositiveButton("OK") { _, _ ->
            soundVolumePercent = seek.progress
            prefs.edit().putInt(PREF_SOUND_VOLUME, soundVolumePercent).apply()
            applyGameVolume()
        }
        .setNegativeButton("Cancel", null)
        .create()
    dialog.window?.setBackgroundDrawable(roundedDialogBackground())
    dialog.show()
}


/** Sound frequency picker — same reference screenshot's own single-
 *  choice style showScreenOrientationDialog() above already uses
 *  (title + radio list + Cancel only, applies immediately on tap
 *  rather than needing a second confirm for a single choice like this
 *  one). 44100/22050/11025 Hz, matching MyBoy's own equivalent setting
 *  (direct reference) — output sample rate traded against CPU/battery
 *  use. See applySoundFrequencyFilter()'s own comment for how a lower
 *  choice here actually gets applied without breaking the emulator's
 *  own frame pacing. A rebuild is needed to actually change a live
 *  AudioTrack's rate (see audioTrackRebuildPending's field comment),
 *  but only while a game is actually running: while idle there's
 *  nothing audible to update anyway, and the persisted preference
 *  gets picked up regardless the next time a ROM loads — that path
 *  always calls initAudioTrack() fresh (see loadRomFromUri()). */
internal fun MainActivity.showSoundFrequencyDialog() {
    val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    val options = listOf("44100 Hz" to 44100, "22050 Hz" to 22050, "11025 Hz" to 11025)
    val curIdx = options.indexOfFirst { it.second == soundFrequencyHz }.takeIf { it >= 0 } ?: 0
    val dialog = AlertDialog.Builder(this)
        .setTitle("Sound frequency")
        .setSingleChoiceItems(options.map { it.first }.toTypedArray(), curIdx) { d, which ->
            soundFrequencyHz = options[which].second
            prefs.edit().putInt(PREF_SOUND_FREQ, soundFrequencyHz).apply()
            updateSoundFrequencyFactor()
            if (romLoaded) audioTrackRebuildPending = true
            d.dismiss()
        }
        .setNegativeButton("Cancel", null)
        .create()
    dialog.window?.setBackgroundDrawable(roundedDialogBackground())
    dialog.show()
}


// ── Input ────────────────────────────────────────────────────────────

internal fun MainActivity.showInputSettings() {
    val ctx = this
    val layout = ctx.dialogContentLayout().apply {
        addView(TextView(ctx).apply {
            text = "Drag any button to move it, or drag its corner handle to resize — live, over the running game."
            textSize = 12f; setTextColor(Color.WHITE)
        })
    }

    // Turbo A/B checkbox removed this pass — "⚡ Turbo A / Turbo B
    // buttons" used to live here, adding/removing both red rapid-fire
    // satellites together with no way to get just one. Now individually
    // reachable through "+ Add control" below instead (they're in
    // extraControlIds, same as every other opt-in extra), on request.

    // FEATURE #2: My Boy!-style per-button layout editor entry point.
    // Dismisses both this dialog and the settings menu behind it, then
    // opens the live drag/resize editor over the running game (see
    // enterEditMode()).
    val editLayoutBtn = Button(ctx).apply {
        text = "Edit Button Layout…"
        setPadding(0, dp(16), 0, 0)
        setTextColor(Color.WHITE)
        setBackgroundColor(Color.parseColor("#553A3A4A"))
    }
    layout.addView(editLayoutBtn)

    val dlg = AlertDialog.Builder(ctx)
        .setTitle("🕹  Input")
        .setView(layout)
        .setNegativeButton("Close", null)
        .show()
    editLayoutBtn.setOnClickListener {
        dlg.dismiss()
        settingsMenuOverlay.visibility = View.GONE
        enterEditMode()
    }
}


// ── Layouts ──────────────────────────────────────────────────────────

internal fun MainActivity.showLayoutsSettings() {
    val ctx = this
    val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    val layout = ctx.dialogContentLayout()

    layout.addView(TextView(ctx).apply {
        text = "Button size"; textSize = 12f; setTextColor(Color.WHITE)
    })
    val sizeOptions = listOf("Small" to 0.75f, "Normal" to 1.0f, "Large" to 1.25f)
    val sizeRadio   = dlgRadioGroup()
    sizeOptions.forEach { (label, _) -> sizeRadio.dlgAddOpt(label) }
    val curSizeIdx = sizeOptions.indexOfFirst { abs(it.second - buttonScaleMultiplier) < 0.05f }
        .takeIf { it >= 0 } ?: 1
    (sizeRadio.getChildAt(curSizeIdx) as RadioButton).isChecked = true
    layout.addView(sizeRadio)

    layout.addView(TextView(ctx).apply {
        text = "Button opacity"; textSize = 12f; setTextColor(Color.WHITE)
        setPadding(0, dp(16), 0, 0)
    })
    val alphaOptions = listOf("Low" to 90, "Normal" to 160, "High" to 220)
    val alphaRadio   = dlgRadioGroup()
    alphaOptions.forEach { (label, _) -> alphaRadio.dlgAddOpt(label) }
    val curAlphaIdx = alphaOptions.indexOfFirst { abs(it.second - buttonBaseAlpha) < 40 }
        .takeIf { it >= 0 } ?: 1
    (alphaRadio.getChildAt(curAlphaIdx) as RadioButton).isChecked = true
    layout.addView(alphaRadio)

    AlertDialog.Builder(ctx)
        .setTitle("▦  Layouts")
        .setView(ScrollView(ctx).also { it.addView(layout) })
        .setPositiveButton("Save") { _, _ ->
            val selSizeIdx = (0 until sizeRadio.childCount)
                .firstOrNull { (sizeRadio.getChildAt(it) as RadioButton).isChecked } ?: curSizeIdx
            val newScale = sizeOptions[selSizeIdx].second

            val selAlphaIdx = (0 until alphaRadio.childCount)
                .firstOrNull { (alphaRadio.getChildAt(it) as RadioButton).isChecked } ?: curAlphaIdx
            val newAlpha = alphaOptions[selAlphaIdx].second

            val needsRelayout = newScale != buttonScaleMultiplier
            buttonScaleMultiplier = newScale
            buttonBaseAlpha       = newAlpha

            prefs.edit()
                .putFloat(PREF_BTN_SCALE, newScale)
                .putInt(PREF_BTN_ALPHA,   newAlpha)
                .apply()

            if (needsRelayout) applyLayoutSettings()
        }
        .setNegativeButton("Cancel", null)
        .show()
}


// ── Misc ─────────────────────────────────────────────────────────────

internal fun MainActivity.showMiscSettings() {
    val ctx = this
    val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    val layout = ctx.dialogContentLayout()

    layout.addView(TextView(ctx).apply {
        text = "Fast-forward speed (0.5 – 16×)\nTap » on screen to activate"
        textSize = 12f; setTextColor(Color.WHITE)
    })
    val ffEdit = EditText(ctx).apply {
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        setText(formatSpeed(fastForwardSpeed))
        hint = "e.g. 2, 4, 4.5"
        setTextColor(Color.WHITE)
        setHintTextColor(Color.GRAY)
        setPadding(dp(8), dp(8), dp(8), dp(8))
    }
    layout.addView(ffEdit)

    val fpsCheck = CheckBox(ctx).apply {
        text = "Show performance overlay (FPS / audio underruns)"
        isChecked = showFpsOverlay
        setTextColor(Color.WHITE)
        setPadding(0, dp(24), 0, 0)
    }
    layout.addView(fpsCheck)

    // FEATURE (direct report: "add auto save & load toggle like
    // myboy... auto save game on exit points load it back on start"):
    // see autoSaveLoadEnabled's own field comment for what this
    // actually drives (onPause()/loadRomFromUri()).
    val autoSaveCheck = CheckBox(ctx).apply {
        text = "Auto Save & Load (saves your progress on exit, loads it back on start)"
        isChecked = autoSaveLoadEnabled
        setTextColor(Color.WHITE)
        setPadding(0, dp(12), 0, 0)
    }
    layout.addView(autoSaveCheck)

    AlertDialog.Builder(ctx)
        .setTitle("👤  Misc")
        .setView(layout)
        .setPositiveButton("Save") { _, _ ->
            val ffVal = ffEdit.text.toString().toFloatOrNull()
            if (ffVal != null) {
                when {
                    ffVal < 0.5f || ffVal > 16f -> uiToast("Speed must be 0.5 – 16")
                    else -> {
                        fastForwardSpeed = ffVal
                        prefs.edit().putFloat(PREF_FF_SPEED, fastForwardSpeed).apply()
                    }
                }
            } else {
                // FIX: empty/unparseable input used to fail silently —
                // the dialog just closed and quietly kept the old
                // speed, with no indication anything was wrong, unlike
                // the out-of-range case just above which already
                // toasts.
                uiToast("Enter a valid number")
            }
            showFpsOverlay = fpsCheck.isChecked
            prefs.edit().putBoolean(PREF_SHOW_FPS, showFpsOverlay).apply()
            autoSaveLoadEnabled = autoSaveCheck.isChecked
            prefs.edit().putBoolean(PREF_AUTO_SAVE_LOAD, autoSaveLoadEnabled).apply()
        }
        .setNegativeButton("Cancel", null)
        .show()
}


// ── Storage ──────────────────────────────────────────────────────────
// FEATURE: new. See the block comment above dataFolderTree() (right
// before batterySaveFile/stateSlotFile/etc.) for the full reasoning —
// this is just the settings screen that lets someone actually pick a
// folder, or go back to the app-internal default.

internal fun MainActivity.showStorageSettings() {
    val ctx = this
    lateinit var statusText: TextView
    lateinit var chooseBtn: Button
    lateinit var resetBtn: Button

    // FIX (spotted while reviewing this pass's own storage-text
    // changes just below): originally took no parameter and called
    // dataFolderTree() itself — correct on its own, but refresh()
    // right below *also* resolves dataFolderTree() into its own
    // `tree` local and calls this function too, so a single refresh()
    // call could trigger the exact repeated-resolution pattern item 7
    // elsewhere in this file (SaveEntry.usesDataFolder) was just fixed
    // for — the same DocumentFile round-trip, just here instead of
    // there. Takes the caller's already-resolved tree instead.
    fun currentFolderLabel(tree: DocumentFile?): String = when {
        tree != null -> tree.name ?: "(chosen folder)"
        hasBroadFileAccess() -> "\"mGBA\" folder (default — top-level storage)"
        else -> "\"mGBA\" folder (default — app-internal for now)"
    }

    fun refresh() {
        val tree = dataFolderTree()
        statusText.text = "Current folder: ${currentFolderLabel(tree)}\n\n" +
            (when {
                tree != null ->
                    "Holds three subfolders — save, cheat, screenshot — for " +
                    "battery saves, save-states and their thumbnails, the " +
                    "(future) cheat file feature, and screenshots. Visible in " +
                    "any file manager, not tucked away under Android/data."
                hasBroadFileAccess() ->
                    // FIX (this pass): now that autoFolderRoot() actually
                    // uses a top-level folder once storage access is
                    // granted, this can finally say so accurately — this
                    // branch replaces the old single "under this app's own
                    // storage" wording, which was true of the fallback
                    // below but not of this, the now-common case.
                    "No folder chosen, so saves/states/screenshots/layout " +
                    "are all kept automatically in an \"mGBA\" folder right " +
                    "alongside your phone's other folders — same idea as " +
                    "My Boy's own folder, no setup needed, visible in any " +
                    "file manager. Survives Settings → Storage → Clear " +
                    "cache *and* Clear storage/data, since — unlike the " +
                    "app-internal fallback below — it isn't app-private " +
                    "storage at all."
                else ->
                    "No folder chosen, so saves/states/screenshots/layout " +
                    "are all kept automatically in an \"mGBA\" folder under " +
                    "this app's own storage for now — no setup needed, and " +
                    "it survives Settings → Storage → Clear cache. Grant " +
                    "storage access (you'll be asked next time you browse " +
                    "for a ROM) to move this to a top-level folder any " +
                    "file manager can browse into directly, same as " +
                    "picking a folder below."
            }) +
            "\n\nSwitching folders does NOT move anything already saved — " +
            "only saves/states/screenshots made after switching go to the " +
            "new location. Nothing already there is deleted either; it's " +
            "just not used anymore until you switch back."
        resetBtn.visibility = if (tree != null) View.VISIBLE else View.GONE
    }

    val layout = ctx.dialogContentLayout().apply {
        statusText = TextView(ctx).apply { textSize = 12f; setTextColor(Color.WHITE) }
        addView(statusText)
        chooseBtn = Button(ctx).apply {
            text = "📁  Choose folder"
            setPadding(0, dp(16), 0, 0)
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#553A3A4A"))
        }
        addView(chooseBtn)
        resetBtn = Button(ctx).apply {
            // FIX: was "Use app-internal storage instead" — accurate
            // before this pass, since the automatic fallback really was
            // always internal storage. Now that autoFolderRoot() (see
            // its own fix) normally resolves to a top-level folder
            // instead, generic wording that's correct either way beats
            // re-explaining both cases on a button label — the full
            // explanation already lives in statusText above.
            text = "↺  Use the automatic folder instead"
            setPadding(0, dp(16), 0, 0)
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#553A3A4A"))
        }
        addView(resetBtn)
    }
    refresh()

    AlertDialog.Builder(ctx)
        .setTitle("💾  Storage")
        .setView(layout)
        .setNegativeButton("Close", null)
        .setOnDismissListener { refreshStorageSettingsUi = null }
        .show()
    refreshStorageSettingsUi = { refresh() }

    chooseBtn.setOnClickListener {
        // OpenDocumentTree's launch() takes an optional initial-location
        // Uri, not an Intent — read+write permission for whatever the
        // user picks comes back on the result URI automatically (that's
        // the whole point of a tree pick); dataFolderPicker's own
        // callback above is what persists it via
        // takePersistableUriPermission() so it survives app restarts.
        dataFolderPicker.launch(null)
    }
    resetBtn.setOnClickListener {
        AlertDialog.Builder(ctx)
            .setTitle("Use the automatic folder?")
            .setMessage("New saves/states/screenshots go back to the automatic \"mGBA\" folder described above. Nothing in the chosen folder is deleted.")
            .setPositiveButton("Switch back") { _, _ ->
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove(PREF_DATA_FOLDER_URI).apply()
                uiToast("Back to the automatic folder")
                refresh()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}


// ── Advanced ─────────────────────────────────────────────────────────

internal fun MainActivity.showAdvancedSettings() {
    val ctx = this
    val layout = ctx.dialogContentLayout().apply {
        addView(TextView(ctx).apply {
            text = "Resets game screen size, fullscreen, button size/opacity, sound settings, and fast-forward speed back to their defaults.\n\nThis does NOT clear custom button positions — reset those from Input → Edit Button Layout instead."
            textSize = 12f; setTextColor(Color.WHITE)
        })
    }
    val resetBtn = Button(ctx).apply {
        text = "↺  Reset settings to defaults"
        setPadding(0, dp(16), 0, 0)
        setTextColor(Color.WHITE)
        setBackgroundColor(Color.parseColor("#553A3A4A"))
    }
    layout.addView(resetBtn)

    val dlg = AlertDialog.Builder(ctx)
        .setTitle("🎚  Advanced")
        .setView(layout)
        .setNegativeButton("Close", null)
        .show()

    resetBtn.setOnClickListener {
        AlertDialog.Builder(ctx)
            .setTitle("Reset settings?")
            .setMessage("This resets Video/Audio/Layouts/Misc settings to defaults.")
            .setPositiveButton("Reset") { _, _ ->
                fastForwardSpeed      = 2.0f
                buttonScaleMultiplier = 1.0f
                buttonBaseAlpha       = 160
                gameScreenFraction    = GAME_FRAC_NORM
                // FIX: screenOrientationChoice/PREF_ORIENTATION was
                // missing from this reset entirely, even though the
                // confirm dialog above explicitly promises "Video"
                // settings reset and Screen orientation is one (🖥
                // Video → Screen orientation) — the exact same "added
                // later, never wired into this reset block" gap this
                // comment block already documents for
                // stretchToFit/maxFrameSkips/linearFilterEnabled just
                // below, just not caught the same pass.
                screenOrientationChoice = ORIENTATION_LANDSCAPE
                // FIX: stretchToFit/maxFrameSkips/linearFilterEnabled
                // (all added two passes ago) were missing from this
                // reset entirely — a gap from when they were added,
                // not something this pass changed on purpose. Included
                // now, alongside removing fullscreenMode, which no
                // longer exists at all (see the field comment where
                // gameScreenRect is declared).
                stretchToFit          = false
                maxFrameSkips         = 0
                linearFilterEnabled   = false
                // FIX (this pass): buttonSoundEnabled reset replaced —
                // that field is gone along with the rest of the old
                // button-click-sound feature (see showAudioSettings())
                // — with the three settings that took its place.
                soundEnabled          = true
                soundVolumePercent    = 100
                soundFrequencyHz      = 44100
                showFpsOverlay        = false
                // FIX (this pass): autoSaveLoadEnabled (added this
                // same pass) included here from the start, unlike
                // showFpsOverlay/gridDivisions/etc. just above and
                // below, each of which — per this block's own history
                // of comments — was added to the app before it was
                // added *here*, silently surviving a "Reset settings"
                // tap until a later pass noticed and backfilled it.
                // This dialog's own message already promises "Misc
                // settings" are included in the reset; a setting that
                // quietly isn't would be exactly that same gap again.
                autoSaveLoadEnabled   = false
                gridDivisions         = 8
                showGrid              = false
                snapToGrid            = false
                updateLinearFilterPaint()
                updateSoundFrequencyFactor()
                // Volume is always safe to (re)apply, live-idle or not
                // — a no-op via audioTrack's own ?. if nothing's built
                // yet. The frequency rebuild only matters while a game
                // is actually running; see showSoundFrequencyDialog()'s
                // own comment for why idle skips it.
                applyGameVolume()
                if (romLoaded) audioTrackRebuildPending = true
                // Safe to call unconditionally regardless of romLoaded
                // — applyScreenOrientationPref() already only applies
                // screenOrientationChoice while a game is actually
                // running, forcing Portrait otherwise (see its own doc
                // comment), same as every other call site.
                applyScreenOrientationPref()
                getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                    .putFloat(PREF_FF_SPEED, fastForwardSpeed)
                    .putFloat(PREF_BTN_SCALE, buttonScaleMultiplier)
                    .putInt(PREF_BTN_ALPHA, buttonBaseAlpha)
                    .putFloat(PREF_SCREEN_FRAC, gameScreenFraction)
                    .putInt(PREF_ORIENTATION, screenOrientationChoice)
                    .putBoolean(PREF_STRETCH, stretchToFit)
                    .putInt(PREF_MAX_SKIPS, maxFrameSkips)
                    .putBoolean(PREF_LINEAR_FILTER, linearFilterEnabled)
                    .putBoolean(PREF_SOUND_ENABLED, soundEnabled)
                    .putInt(PREF_SOUND_VOLUME, soundVolumePercent)
                    .putInt(PREF_SOUND_FREQ, soundFrequencyHz)
                    .putBoolean(PREF_SHOW_FPS, showFpsOverlay)
                    .putBoolean(PREF_AUTO_SAVE_LOAD, autoSaveLoadEnabled)
                    .putInt(PREF_GRID_SIZE, gridDivisions)
                    .putBoolean(PREF_SHOW_GRID, showGrid)
                    .putBoolean(PREF_SNAP_GRID, snapToGrid)
                    .apply()
                applyLayoutSettings()
                uiToast("Settings reset to defaults")
                dlg.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}

