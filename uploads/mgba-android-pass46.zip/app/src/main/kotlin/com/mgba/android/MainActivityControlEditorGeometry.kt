package com.mgba.android

// Split out of MainActivity.kt (pass 46 — "refactor main activity into
// separate classes so organized") as internal extension functions on
// MainActivity, exactly the pattern already established in SharedUi.kt's
// own top-of-file comment (Thirty-second pass) for the same reason: every
// existing unqualified call site inside MainActivity.kt (and inside every
// other split-out file) keeps compiling completely unchanged, since Kotlin
// resolves an unqualified call to an internal extension function on the
// enclosing receiver type the same way it resolves a member call — no
// behavior change, purely a file-organization move. See MainActivity.kt's
// own top-of-file comment for the full file map.

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.text.InputType
import android.text.TextUtils
import android.text.format.DateFormat
import android.util.Log
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.Closeable
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.io.PrintWriter
import java.io.StringWriter
import java.util.concurrent.atomic.AtomicInteger
import java.util.zip.ZipInputStream
import kotlin.math.abs
import kotlin.math.roundToInt


// ── Control layout editor ────────────────────────────────────────────────
//
// FEATURE #2 — a My Boy!-style layout editor. Scope for this pass: every
// button (D-pad × 4, A, B, Start, Select, L, R, Fast-Forward) can be
// freely dragged anywhere on screen and resized via a corner handle, with
// a per-button opacity override and a per-button lock, all live-previewed
// over the actual running game and persisted across sessions. Deliberately
// NOT built in this pass (flagged rather than silently skipped):
// per-button rotation/mirroring (unusual for a D-pad/AB layout — mostly
// relevant for decorative custom skins, low value here), snap-to-guides /
// alignment grid, and named/duplicatable layout profiles beyond the
// automatic portrait/landscape split already wired into the storage
// format. Per-game layouts are a storage-key change away (see
// orientationTag()/PREF_LAYOUT_PREFIX) but need a ROM-identity concept
// (hash or path) this codebase doesn't have yet, so it's out of scope
// until that exists rather than faked with a no-op toggle.

internal fun MainActivity.labelFor(id: String): String = when (id) {
    "dpad" -> "D-Pad"
    "a" -> "A Button"; "b" -> "B Button"; "start" -> "Start"; "select" -> "Select"
    "l" -> "L Shoulder"; "r" -> "R Shoulder"; "ff" -> "Fast-Forward"
    "ta" -> "Turbo A"; "tb" -> "Turbo B"
    "la" -> "TL+A"; "lb" -> "TL+B"; "ra" -> "TR+A"; "rb" -> "TR+B"
    "ab" -> "A/B"; "abturbo" -> "A/B Turbo"
    "quicksave" -> "Quick Save"; "quickload" -> "Quick Load"; "screenshot" -> "Screenshot"
    "gamescreen" -> "Game Screen"
    else -> id
}


internal fun MainActivity.editRectFor(id: String): RectF? = when (id) {
    "ff" -> ffBtnRect
    "gamescreen" -> gameScreenRect
    else -> buttons.find { it.id == id }?.rect
}


internal fun MainActivity.resizeHandleRadius(rect: RectF): Float =
    (minOf(rect.width(), rect.height()) * 0.22f).coerceIn(22f, 36f)


// BUG FIX ("hitbox for dragging to resize is not accurate", most
// noticeable in landscape): resizeHandleRadius() above is a *visual*
// size — deliberately small so the dot doesn't look oversized on a tiny
// button — but onEditTouch() used that exact same tiny radius as the
// TOUCH target too, and worse, in raw pixels rather than dp. Its
// 22–36f clamp is 22–36 *pixels*, which on a typical ~2.5–3x density
// phone is only a ~15–24dp hit diameter — well under Android's own
// 48dp minimum recommended touch target — and landscape specifically
// makes it worse: buttons sit in a vertically-squeezed strip there
// (see buildControlLayout's padH), so minOf(width,height) is smaller
// and the radius bottoms out at the 22px floor even more often.
// This is the touch-only hit radius: same visual dot, a much more
// generous invisible grab zone around it (standard "small glyph, big
// tap target" pattern), floored at a real 24dp regardless of how small
// the button itself has been resized down to.
internal fun MainActivity.resizeHandleTouchRadius(rect: RectF): Float =
    maxOf(resizeHandleRadius(rect), dp(24).toFloat())


internal fun MainActivity.dist(x1: Float, y1: Float, x2: Float, y2: Float): Float {
    val dx = x1 - x2; val dy = y1 - y2
    return kotlin.math.sqrt(dx * dx + dy * dy)
}


/** Gets-or-creates the override entry for [id], seeded from its current
 *  default geometry so a freshly-touched button starts exactly where it
 *  visually already is, not at some arbitrary origin. */
internal fun MainActivity.entryFor(id: String): LayoutEntry = customLayout.getOrPut(id) {
    val g = defaultGeometry[id]
    LayoutEntry(
        xFrac = (g?.cx ?: lastSw / 2f) / lastSw.coerceAtLeast(1f),
        yFrac = (g?.cy ?: lastSh / 2f) / lastSh.coerceAtLeast(1f)
    )
}


// ── Editor alignment grid — position/size snapping ──────────────────────
// FIX (Fortieth pass): grid cells are real squares now, not a w/N-by-h/N
// rectangle — see gridDivisions' own field comment above for the report
// this traces back to. gridCellPx() is the one place that size is
// computed; drawGrid() and both snap functions below all call it
// instead of each re-deriving a cell size from lastSw/lastSh
// independently — same idea as before (draw and snap must agree), just
// one shared square number now instead of two independent non-square
// ones.

/** Pixel size of one square grid cell. gridDivisions cells fit across
 *  whichever of lastSw/lastSh is smaller; the longer dimension gets
 *  however many whole cells happen to fit at that same size (see
 *  drawGrid()) — that's what makes the cells actual squares on a
 *  non-square screen instead of gridDivisions columns by gridDivisions
 *  rows. */
internal fun MainActivity.gridCellPx(): Float =
    (minOf(lastSw, lastSh) / gridDivisions.coerceAtLeast(1)).coerceAtLeast(0.01f)


/** Snaps a single pixel coordinate ([v], along either axis — the cell
 *  is square, so which axis it is no longer changes the math) to the
 *  nearest grid line. Used for the drag/position case — called on both
 *  X and Y independently, after the existing on-screen clamp, so a
 *  snapped point is always the true final value (never nudged again
 *  afterward) — see onEditTouch()'s own note on why clamp-then-snap,
 *  not the other way around. */
internal fun MainActivity.snapPositionToGrid(v: Float): Float {
    val cell = gridCellPx()
    return Math.round(v / cell) * cell
}


/** Snaps a resize so the element's WIDTH lands on a whole number of
 *  grid cells (at least 1), then derives the scale that produces
 *  exactly that width from [id]'s own default (unscaled) width.
 *  Deliberately width-only rather than snapping width and height
 *  independently: every entry (buttons and the game screen alike)
 *  resizes through one uniform `scale` float (see LayoutEntry) so its
 *  aspect ratio never distorts — snapping both dimensions separately
 *  would either break that invariant or leave one of the two
 *  dimensions off-grid, which is exactly the "slightly off-grid"
 *  outcome this is meant to avoid. Snapping the width consistently
 *  means every resize in this app now has one predictable rule,
 *  rather than a different one depending on which control it's
 *  dragged from. Height still follows it exactly (same scale, fixed
 *  aspect), it just isn't independently forced onto its own grid
 *  line. */
internal fun MainActivity.snapScaleToGrid(id: String, scale: Float): Float {
    val base = defaultGeometry[id] ?: return scale
    val cell = gridCellPx()
    if (cell <= 0f || base.w <= 0f) return scale
    val rawWidth = base.w * scale
    val cells = Math.round(rawWidth / cell).coerceAtLeast(1)
    return ((cells * cell) / base.w).coerceIn(0.5f, 8.0f)
}


internal fun MainActivity.hitTestEditable(x: Float, y: Float): String? {
    // BUG FIX (resize hitbox "not accurate"), part 2: the resize dot is
    // drawn CENTERED ON the button's corner (drawEditOverlay:
    // drawCircle(rect.right, rect.bottom, ...)), so roughly half of its
    // visible area sits outside the button's own rect. The plain
    // rect.contains() checks below reject any touch that lands outside
    // the rect — including a touch square on the visible dot — so
    // grabbing the *outer* half of a handle you can plainly see used to
    // just deselect the button instead of resizing it. Checking the
    // already-selected button's handle FIRST, with the expanded
    // touch-friendly radius above, and allowing that check to succeed
    // even outside the rect, fixes it — while unselected buttons still
    // use plain rect.contains() (no handle is drawn for them, so there's
    // nothing extra to grab yet).
    editSelectedId?.let { id ->
        if (isButtonVisible(id)) {   // a hidden button's rect is zero-size, not "small" — never treat it as a handle target
            val rect = editRectFor(id)
            if (rect != null && dist(x, y, rect.right, rect.bottom) <= resizeHandleTouchRadius(rect)) return id
        }
    }
    if (ffBtnRect.contains(x, y)) return "ff"
    for (b in buttons) if (b.rect.contains(x, y)) return b.id
    // Lowest priority, checked last: the screen occupies a much larger
    // area than any button, so anything that *did* land on an actual
    // button was already returned above — this is only reached for
    // taps that missed every one of them.
    // BUG FIX (an earlier pass): while Stretch to Fit is on,
    // gameScreenRect is a fixed box — the full screen, (0,0,sw,sh) as
    // of this pass, see updateGameMatrix() — recomputed every frame
    // from the screen size alone. Letting it be "selected" here used
    // to let SIZE+/SIZE- silently edit a customLayout entry that mode
    // never even reads, which looked like the size controls had just
    // stopped doing anything. Nothing useful to drag/resize while the
    // box is pinned to the full screen, so it's skipped entirely until
    // Stretch to Fit is turned back off.
    if (!stretchToFit && gameScreenRect.contains(x, y)) return "gamescreen"
    return null
}


// ── Control Size / Control Opacity — percent ↔ stored-unit conversion ──
// FIX (this pass): the old "-"/"+" chips only ever nudged by a fixed
// step (adjustSelectedScale()/adjustSelectedAlpha(), both replaced this
// pass), so they never needed to convert *to* a display unit — only
// ever read/wrote the stored float scale or raw alpha byte directly.
// The new slider (sliderRow() in SharedUi.kt) shows and accepts a
// plain percent either way — matching the direct report ("a slider
// with number or percent") — so conversion happens here, both
// directions, each used by exactly one function below.

/** Opacity percent (0-100, what the slider and its typed-value dialog
 *  show/accept) ↔ the raw alpha byte (60-255) LayoutEntry.alphaOverride
 *  actually stores. percentToAlpha() re-clamps to [60, 255] regardless
 *  of the percent passed in — the same floor adjustSelectedAlpha()
 *  always enforced (a control can be dimmed a lot, never made fully
 *  invisible/undiscoverable) — so it still holds even for a value a
 *  rounding hair below the slider's own displayed minimum. */
internal fun MainActivity.alphaToPercent(alpha: Int): Int = (alpha * 100) / 255

internal fun MainActivity.percentToAlpha(percent: Int): Int = (percent * 255 / 100).coerceIn(60, 255)


/** Pure reads for the sliders' own display — deliberately plain map
 *  lookups, not entryFor(id): simply *selecting* a control (to look
 *  at, not yet to change) should never create a customLayout override
 *  as a side effect the way entryFor()'s getOrPut would. */
internal fun MainActivity.currentScalePercent(id: String): Int =
    ((customLayout[id]?.scale ?: 1f) * 100).roundToInt()

internal fun MainActivity.currentAlphaPercent(id: String): Int =
    alphaToPercent(customLayout[id]?.alphaOverride?.takeIf { it >= 0 } ?: buttonBaseAlpha)

internal fun MainActivity.isSelectedLocked(id: String): Boolean = customLayout[id]?.locked == true

