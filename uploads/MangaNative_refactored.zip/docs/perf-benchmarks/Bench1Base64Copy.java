import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Random;

/**
 * Simulates MhtmlParser.parse()'s base64 body accumulation exactly:
 * read 76-char lines, encode each line to bytes, write into a reused
 * ByteArrayOutputStream (matching the real bodyStream.reset()+write() loop),
 * then decode.
 *
 * OLD path: bodyStream.toByteArray() [full copy] -> decode(copy)
 * NEW path: expose buf/count directly [no copy]   -> decode(view)
 *
 * java.util.Base64 has no offset/length decode(byte[]) overload (unlike
 * Android's android.util.Base64.decode(input, offset, len, flags), which is
 * what the real Kotlin fix uses) — ByteBuffer.wrap(buf, 0, count) is used
 * here as the zero-copy equivalent available on plain JVM: it wraps the
 * existing array as a view, no allocation, same principle being measured.
 */
public class Bench1Base64Copy {

    // Expose buf/count without copying — same trick used in the real fix.
    static class DirectBAOS extends ByteArrayOutputStream {
        DirectBAOS(int size) { super(size); }
        byte[] buf() { return buf; }
        int len() { return count; }
    }

    public static void main(String[] args) throws Exception {
        // typical extracted manga page: ~220 KB decoded -> ~294 KB base64 text
        int decodedSize = 220 * 1024;
        byte[] randomImageBytes = new byte[decodedSize];
        new Random(42).nextBytes(randomImageBytes);
        String base64Text = Base64.getEncoder().encodeToString(randomImageBytes);

        // split into 76-char lines, exactly like MIME base64 body lines
        int lineLen = 76;
        String[] lines = new String[(base64Text.length() + lineLen - 1) / lineLen];
        for (int i = 0; i < lines.length; i++) {
            int start = i * lineLen;
            int end = Math.min(start + lineLen, base64Text.length());
            lines[i] = base64Text.substring(start, end);
        }

        int warmup = 200, iters = 2000;
        DirectBAOS bodyStream = new DirectBAOS(128 * 1024);

        // ── Warmup both paths (JIT) ──────────────────────────────────────────
        for (int w = 0; w < warmup; w++) {
            bodyStream.reset();
            for (String line : lines) bodyStream.write(line.getBytes(StandardCharsets.ISO_8859_1));
            byte[] copy = bodyStream.toByteArray();
            Base64.getDecoder().decode(copy);

            bodyStream.reset();
            for (String line : lines) bodyStream.write(line.getBytes(StandardCharsets.ISO_8859_1));
            Base64.getDecoder().decode(ByteBuffer.wrap(bodyStream.buf(), 0, bodyStream.len()));
        }

        // ── OLD: accumulate + toByteArray() copy + decode ────────────────────
        long t0 = System.nanoTime();
        long sinkOld = 0;
        for (int i = 0; i < iters; i++) {
            bodyStream.reset();
            for (String line : lines) bodyStream.write(line.getBytes(StandardCharsets.ISO_8859_1));
            byte[] copy = bodyStream.toByteArray();          // <-- redundant full-size copy
            byte[] decoded = Base64.getDecoder().decode(copy);
            sinkOld += decoded.length;
        }
        long oldNanos = System.nanoTime() - t0;

        // ── NEW: accumulate + decode straight from buf/count (no copy) ───────
        long t1 = System.nanoTime();
        long sinkNew = 0;
        for (int i = 0; i < iters; i++) {
            bodyStream.reset();
            for (String line : lines) bodyStream.write(line.getBytes(StandardCharsets.ISO_8859_1));
            byte[] decoded = Base64.getDecoder().decode(ByteBuffer.wrap(bodyStream.buf(), 0, bodyStream.len())).array();
            sinkNew += decoded.length;
        }
        long newNanos = System.nanoTime() - t1;

        double oldMsPerImg = oldNanos / 1e6 / iters;
        double newMsPerImg = newNanos / 1e6 / iters;
        System.out.printf("Decoded image size:        %,d bytes (%d base64 lines)%n", decodedSize, lines.length);
        System.out.printf("Iterations:                 %d%n", iters);
        System.out.printf("OLD (with toByteArray copy): %.4f ms/image  (total %.1f ms)%n", oldMsPerImg, oldNanos / 1e6);
        System.out.printf("NEW (direct buffer decode):  %.4f ms/image  (total %.1f ms)%n", newMsPerImg, newNanos / 1e6);
        System.out.printf("Delta:                       %.4f ms/image saved  (%.1f%% faster on this step)%n",
                oldMsPerImg - newMsPerImg, 100.0 * (oldMsPerImg - newMsPerImg) / oldMsPerImg);
        System.out.println("(sinks: " + sinkOld + " " + sinkNew + ")");
    }
}
