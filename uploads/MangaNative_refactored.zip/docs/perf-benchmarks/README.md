# MHTML extraction pipeline — perf benchmarks

Real, executable microbenchmarks backing the v25 (extraction) and v26
(thumbnail resolution) optimizations in `MhtmlParser.kt`. Bench1-3 are JVM
(`java <file>.java`, JDK 11+, no build step); Bench4 is Python (see its own
section below for why).

**Why plain JVM, not the Android app:** `android.graphics.Bitmap` /
`BitmapFactory` and `android.util.Base64` aren't available outside an
Android runtime, so these isolate the parts of the pipeline that *are*
reproducible on a JVM — the redundant buffer copy and the redundant disk
reads — plus a real-threads simulation of the CPU/IO overlap structure.
None of these numbers are a substitute for on-device profiling
(Android Studio Profiler / Perfetto) on real target hardware; they're the
"prove the mechanism, not the exact device number" evidence referenced in
MhtmlParser.kt's v25 docstring.

| Benchmark | What it measures | Result on this run |
|---|---|---|
| `Bench1Base64Copy.java` | Cost of `bodyStream.toByteArray()` before `Base64.decode()` vs. decoding straight from the backing array | ~4–7% faster on this step |
| `Bench2DiskReread.java` | Cost of `BitmapFactory.decodeFile()`'s two reads of a file just written vs. decoding the bytes already in memory | ~70–75% faster on this step (disk-speed dependent — real device eMMC/UFS will likely show a *larger* relative win than this container's fast filesystem) |
| `Bench3Pipeline.java` | Real thread-scheduled simulation: serial (extract → block on thumbnail → repeat) vs. overlapped (extract continues immediately; thumbnail runs concurrently, `Semaphore(2)`-bounded) | ~1.75–2.3x speedup across a modeled 4–10ms thumbnail-cost range |

Bench3's per-image millisecond costs are modeled inputs (BitmapFactory
isn't available here to measure directly) — the concurrency/thread
scheduling itself is real, not simulated.

## Bench4ThumbnailSize.py — v26 thumbnail resolution fix

Unlike Bench1-3, this one is Python, not JVM. Pillow (with the system
libwebp) and OpenCV give **real WebP encoding and a real sharpness metric**
in this environment — more rigorous than modeling it, and worth the
different toolchain for that reason alone.

Run: `python3 Bench4ThumbnailSize.py` (requires `pillow`, `opencv-python`,
`numpy`).

It reproduces `MhtmlParser.kt`'s actual pipeline (adaptive coarse sample →
bilinear scale → WebP encode, quality=65 unchanged) against synthetic
manga-style test pages (halftone screentone, panel borders, text blocks —
real scans aren't available in a dev sandbox, but these are the features
that actually stress a downscale pipeline). It then simulates what the
*screen* shows — decode the thumbnail back, bilinear-upscale it to the real
on-screen grid-cell size (`item_thumb.xml`: 130dp cell, 3-column grid, at
xhdpi/xxhdpi densities), and scores it with variance-of-Laplacian against a
theoretical no-bottleneck ceiling.

**Result:** 140px thumbnails recovered only 0.1–1.1% of theoretical
sharpness — that gap *is* the reported blur, and no WebP quality setting
fixes a resolution problem downstream of the encode. 200px recovered
~16x more sharpness (18.5%/2.2% of ceiling) for +3–4ms encode time and
+3.4KB file size — both negligible per Bench3 above. Sizes beyond 200px
showed steeply diminishing returns (200→256 was only ~1.05–1.2x more
sharpness for 1.6x the file size), and an analytical sweep across
realistic source resolutions (800–4000px) confirmed 200px never gets
*less* coarse-decode headroom than 140px did — only equal or more. Full
numbers and reasoning are in the script's module docstring and in
`MhtmlParser.kt`'s v26 docstring.
