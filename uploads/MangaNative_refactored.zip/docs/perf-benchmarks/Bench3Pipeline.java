import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Demonstrates the actual structural claim: does running thumbnail
 * generation (CPU-bound) concurrently with the NEXT image's text-parse +
 * base64-decode (the "extraction" phase) beat running them serially,
 * given a bounded concurrency cap (Semaphore(2), matching the real fix)?
 *
 * This uses REAL threads and REAL OS scheduling — not arithmetic — so the
 * result reflects genuine overlap behavior, not a hand-computed estimate.
 *
 * What's modeled vs measured:
 *   - "extraction phase" duration: Thread.sleep(EXTRACT_MS) — legitimate
 *     stand-in for I/O wait, since sleeping genuinely frees the CPU core,
 *     the same property real disk I/O has.
 *   - "thumbnail phase" duration: a real CPU-burning loop calibrated to
 *     ~THUMB_MS of actual work — genuinely occupies a core, can't be
 *     skipped by the JIT, and genuinely contends with other CPU-bound work
 *     the way BitmapFactory decode/scale/WebP-encode would.
 *   - The actual millisecond COSTS (3ms extraction / 6ms thumbnail) are
 *     modeled estimates, NOT measured from real BitmapFactory/WebP calls —
 *     that Android API isn't available on a plain JVM. Run with the
 *     --thumb-ms flag to see how the result scales across plausible values.
 */
public class Bench3Pipeline {

    static long burnCpuMs(double ms) {
        long deadline = System.nanoTime() + (long) (ms * 1_000_000);
        long x = 1;
        while (System.nanoTime() < deadline) {
            // Real arithmetic work so the JIT can't dead-code-eliminate the loop
            // and so this genuinely occupies a CPU core, matching what a decode/
            // scale/compress pass would do.
            x = (x * 1103515245L + 12345L) ^ (x << 3);
        }
        return x;
    }

    public static void main(String[] args) throws Exception {
        int images = 40;              // representative chapter size (screenshot showed 21-54)
        double extractMs = 3.0;       // modeled: line-read + base64-decode + file-write per image
        double[] thumbCosts = {4.0, 6.0, 10.0}; // modeled range for decode+scale+WebP-encode per image
        int concurrency = 2;          // matches the real fix's thumbnailLimiter = Semaphore(2)

        System.out.printf("Images per chapter: %d   Extraction phase: %.1f ms/image (modeled)%n", images, extractMs);
        System.out.printf("Thumbnail concurrency cap: %d (matches Semaphore(2) in the real fix)%n%n", concurrency);

        for (double thumbMs : thumbCosts) {
            // ── SERIAL (current behavior): extract, then block on thumbnail, repeat ──
            long t0 = System.nanoTime();
            AtomicLong sink = new AtomicLong();
            for (int i = 0; i < images; i++) {
                Thread.sleep((long) extractMs);         // extraction phase (I/O-bound)
                sink.addAndGet(burnCpuMs(thumbMs));      // thumbnail phase (CPU-bound) — BLOCKS here today
            }
            long serialNanos = System.nanoTime() - t0;

            // ── OVERLAPPED (the fix): extraction continues immediately; thumbnail
            //    work runs concurrently on a bounded pool, awaited at the end ────
            ExecutorService pool = Executors.newFixedThreadPool(concurrency);
            Semaphore limiter = new Semaphore(concurrency);
            long t1 = System.nanoTime();
            java.util.List<Future<Long>> pending = new java.util.ArrayList<>();
            for (int i = 0; i < images; i++) {
                Thread.sleep((long) extractMs);          // extraction phase — main loop never blocks on thumbnail
                limiter.acquire();
                pending.add(pool.submit(() -> {
                    try { return burnCpuMs(thumbMs); }
                    finally { limiter.release(); }
                }));
            }
            long total = 0;
            for (Future<Long> f : pending) total += f.get(); // await stragglers, same as thumbJob.await()
            long overlappedNanos = System.nanoTime() - t1;
            pool.shutdown();

            double serialMs = serialNanos / 1e6;
            double overlappedMs = overlappedNanos / 1e6;
            System.out.printf("thumbMs=%.1f  ->  serial: %7.1f ms   overlapped: %7.1f ms   speedup: %.2fx  (%.0f%% faster)%n",
                    thumbMs, serialMs, overlappedMs, serialMs / overlappedMs, 100.0 * (serialMs - overlappedMs) / serialMs);
        }
        System.out.println("\n(sink values below only prevent JIT dead-code elimination, not meaningful output)");
    }
}
