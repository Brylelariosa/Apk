import java.io.*;
import java.nio.file.*;
import java.util.Random;

/**
 * generateThumbnail(imagePath, ...) calls BitmapFactory.decodeFile() TWICE
 * on the file MhtmlParser just wrote: once with inJustDecodeBounds=true
 * (header-only read, but still opens+reads the file), once for the real
 * coarse decode (reads the whole file). BitmapFactory isn't available on
 * plain JVM, so this can't replicate the actual decode CPU cost — but the
 * DISK I/O being eliminated (2 full file reads of a file we hold in memory
 * seconds after writing it) is real, measurable I/O regardless of what
 * happens to the bytes afterward. That's what this benchmark isolates.
 *
 * OLD: write file -> read file (bounds pass) -> read file (coarse pass)
 * NEW: write file -> reuse the ByteArray already held in memory (0 reads)
 */
public class Bench2DiskReread {
    public static void main(String[] args) throws Exception {
        int size = 220 * 1024;
        byte[] imageBytes = new byte[size];
        new Random(7).nextBytes(imageBytes);

        Path dir = Files.createTempDirectory("mhtml_bench");
        int warmup = 50, iters = 500;

        // Warmup — let the OS page cache and JIT settle for both paths
        for (int i = 0; i < warmup; i++) {
            Path f = dir.resolve("w" + i + ".jpg");
            Files.write(f, imageBytes);
            byte[] r1 = Files.readAllBytes(f);
            byte[] r2 = Files.readAllBytes(f);
            byte[] r3 = imageBytes;
            if (r1.length + r2.length + r3.length < 0) throw new AssertionError();
        }

        // ── OLD: write, then read twice from disk (bounds pass + coarse pass) ──
        long t0 = System.nanoTime();
        long sinkOld = 0;
        for (int i = 0; i < iters; i++) {
            Path f = dir.resolve("o" + i + ".jpg");
            Files.write(f, imageBytes);                 // the extraction write (same in both paths)
            byte[] boundsRead = Files.readAllBytes(f);   // decodeFile() bounds pass
            byte[] coarseRead = Files.readAllBytes(f);   // decodeFile() coarse pass
            sinkOld += boundsRead.length + coarseRead.length;
            Files.delete(f);
        }
        long oldNanos = System.nanoTime() - t0;

        // ── NEW: write, decode thumbnail from the bytes already in memory ──────
        long t1 = System.nanoTime();
        long sinkNew = 0;
        for (int i = 0; i < iters; i++) {
            Path f = dir.resolve("n" + i + ".jpg");
            Files.write(f, imageBytes);                  // the extraction write (unchanged, still happens)
            sinkNew += imageBytes.length;                // decodeByteArray(imageBytes, ...) — zero extra reads
            Files.delete(f);
        }
        long newNanos = System.nanoTime() - t1;

        double oldMsPerImg = oldNanos / 1e6 / iters;
        double newMsPerImg = newNanos / 1e6 / iters;
        System.out.printf("File size:                  %,d bytes%n", size);
        System.out.printf("Iterations:                  %d%n", iters);
        System.out.printf("OLD (write + 2 disk reads):  %.4f ms/image  (total %.1f ms)%n", oldMsPerImg, oldNanos / 1e6);
        System.out.printf("NEW (write + 0 disk reads):  %.4f ms/image  (total %.1f ms)%n", newMsPerImg, newNanos / 1e6);
        System.out.printf("Delta:                        %.4f ms/image saved  (%.1f%% faster on this step)%n",
                oldMsPerImg - newMsPerImg, 100.0 * (oldMsPerImg - newMsPerImg) / oldMsPerImg);
        System.out.println("(sinks: " + sinkOld + " " + sinkNew + ")");
        System.out.println("NOTE: sandbox disk is likely an SSD/tmpfs-backed container filesystem, much");
        System.out.println("faster and more cache-friendly than typical Android internal storage (eMMC/");
        System.out.println("UFS on mid/low-end devices). The relative win (reads eliminated) is real and");
        System.out.println("device-independent; the absolute ms number will understate the phone-side gain.");
    }
}
