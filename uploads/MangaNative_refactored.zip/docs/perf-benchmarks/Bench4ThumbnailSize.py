"""
Bench4ThumbnailSize.py — backs the v26 "140px was the real quality
bottleneck" fix in MhtmlParser.kt.

WHY PYTHON, NOT JVM (unlike Bench1-3): Bench1-3 use plain JVM because
android.graphics.Bitmap / WebP compression aren't available outside an
Android runtime, so they model per-image costs rather than measure real
compression output. Pillow (with the system libwebp) and OpenCV give REAL
WebP encoding and a REAL sharpness metric here, which is more rigorous than
modeling it — every number below is measured, not estimated.

Run: python3 Bench4ThumbnailSize.py
Requires: pillow, opencv-python, numpy (pip install --break-system-packages
pillow opencv-python numpy)

WHAT IT DOES
1. Synthesizes manga-style test pages (halftone screentone dot patterns,
   panel borders, dense text blocks, diagonal hatching) — real manga scans
   aren't available in a dev sandbox, but these features are exactly what
   stresses a downscale pipeline (aliasing/moiré risk), so they're a fair
   stand-in.
2. For each candidate thumbnail size, reproduces MhtmlParser.kt's actual
   pipeline shape: adaptiveSampleSize() coarse pass -> bilinear precise
   scale -> WebP encode (quality=65, UNCHANGED — resolution is the lever
   here, not compression).
3. Decodes the produced WebP back (as Glide does at scroll time) and
   bilinear-upscales it to the REAL on-screen grid-cell size for common
   device densities (item_thumb.xml: 130dp cell height, 3-column grid) —
   this is what centerCrop + the display actually show the user.
4. Scores that final on-screen image with variance-of-Laplacian (Pech-
   Pacheco et al.), a standard no-reference blur metric, against a
   theoretical ceiling (source resized directly to the cell in one
   high-quality pass, i.e. no small-thumbnail bottleneck at all).

RESULT (n=6 synthetic pages, this run):

  Display: xhdpi (2x) -> on-screen cell ~256x260px  (ceiling sharpness 5033)
    size   file KB  encode ms  sharpness  % of ceiling  upscale
     140      1.48      5.15       57.6          1.1%     2.75x  <- baseline
     160      2.94      6.54      298.5          5.9%     2.42x
     180      3.69      7.72      476.3          9.5%     2.13x
     200      4.86      7.84      929.7         18.5%     1.92x  <- chosen
     220      5.31      8.14      718.3         14.3%     1.75x
     256      6.86      9.45     1002.6         19.9%     1.51x

  Display: xxhdpi (3x) -> on-screen cell ~384x390px  (ceiling sharpness 12655)
    size   file KB  encode ms  sharpness  % of ceiling  upscale
     140      1.48      4.96       17.2          0.1%     4.13x  <- baseline
     160      2.94      8.01       86.0          0.7%     3.62x
     180      3.69     10.51      133.9          1.1%     3.20x
     200      4.86     10.11      273.9          2.2%     2.89x  <- chosen
     220      5.31     11.00      195.5          1.5%     2.63x
     256      6.86      9.26      340.3          2.7%     2.26x

TAKEAWAYS
  - 140px recovers ~0.1-1.1% of theoretical sharpness. This IS the blur —
    no WebP quality setting fixes a resolution problem downstream of encode.
  - 200px recovers ~16x more sharpness than 140px, for +3-4ms encode time
    and +3.4KB file size per thumbnail — both negligible (see Bench3).
  - Beyond 200px, returns diminish sharply: 200->256 is only ~1.05-1.2x
    more sharpness for 1.6x the file size. 200px is the smallest size that
    gives a clearly visible improvement, not just any improvement.
  - Robustness check (see adaptive_sample_size sweep at the bottom of
    main()): across realistic source resolutions (800-4000px longest
    axis), 200px NEVER gets less coarse-decode headroom than 140px did —
    only equal or more. This isn't fit to one synthetic test set.
"""
import glob
import io
import os
import random
import time

import cv2
import numpy as np
from PIL import Image

# ── Config ────────────────────────────────────────────────────────────────
SOURCE_DIR = "/tmp/bench4_sources"
PAGE_W, PAGE_H = 1600, 2400  # typical raw manga scan resolution
N_PAGES = 6
CANDIDATE_SIZES = [140, 160, 180, 200, 220, 256]  # 140 = current baseline
WEBP_QUALITY = 65  # UNCHANGED from MhtmlParser.kt — resolution is the lever
REPEATS = 30  # timing repeats per image per size, for stable ms numbers

# 3-column grid cell physical size (item_thumb.xml: match_parent x 130dp).
# ~128dp/column on a common 392dp-wide phone (~6.1") after grid margins.
CELL_W_DP, CELL_H_DP = 128, 130
DENSITIES = {"xhdpi (2x)": 2.0, "xxhdpi (3x)": 3.0}


# ── Step 0: synthesize manga-style test pages ───────────────────────────────
def make_test_page(seed: int) -> np.ndarray:
    """Portrait page with halftone screentone, panel borders, text blocks,
    and hatching — the features that actually stress a downscale pipeline."""
    rng = random.Random(seed)
    img = np.full((PAGE_H, PAGE_W, 3), 255, dtype=np.uint8)

    n_panels = rng.randint(2, 4)
    ys = sorted(rng.sample(range(200, PAGE_H - 200), n_panels - 1)) if n_panels > 1 else []
    bounds = [0] + ys + [PAGE_H]
    for i in range(len(bounds) - 1):
        y0, y1 = bounds[i] + 10, bounds[i + 1] - 10
        x0, x1 = 20, PAGE_W - 20
        cv2.rectangle(img, (x0, y0), (x1, y1), (0, 0, 0), 4)
        region_h = y1 - y0

        if rng.random() < 0.7:  # halftone screentone (classic manga shading)
            dot_spacing = rng.choice([6, 8, 10])
            dot_r = rng.choice([1, 2, 3])
            for yy in range(y0 + 30, y1 - 30, dot_spacing):
                for xx in range(x0 + 30, x1 - 30, dot_spacing):
                    if rng.random() < 0.9:
                        cv2.circle(img, (xx, yy), dot_r, (40, 40, 40), -1)

        if rng.random() < 0.5:  # diagonal hatching (speed lines / shading)
            for k in range(-region_h, x1 - x0, 5):
                p1 = (x0 + k, y0 + 20)
                p2 = (x0 + k + (region_h - 40), y1 - 20)
                cv2.line(img, p1, p2, (60, 60, 60), 1)

        for _ in range(rng.randint(1, 3)):  # dense small "text" blocks
            bx = rng.randint(x0 + 40, x1 - 200)
            by = rng.randint(y0 + 40, y1 - 150)
            bw, bh = rng.randint(120, 180), rng.randint(80, 130)
            cv2.rectangle(img, (bx, by), (bx + bw, by + bh), (255, 255, 255), -1)
            cv2.rectangle(img, (bx, by), (bx + bw, by + bh), (0, 0, 0), 2)
            for ty in range(by + 12, by + bh - 10, 14):
                tx = bx + 10
                while tx < bx + bw - 10:
                    seg = rng.randint(4, 14)
                    if rng.random() < 0.75:
                        cv2.line(img, (tx, ty), (tx + seg, ty), (0, 0, 0), 2)
                    tx += seg + rng.randint(3, 8)

        if rng.random() < 0.6:  # soft gradient blob (shading)
            cx, cy = rng.randint(x0 + 100, x1 - 100), rng.randint(y0 + 100, y1 - 100)
            rad = rng.randint(80, 180)
            yy, xx = np.ogrid[:PAGE_H, :PAGE_W]
            mask = (xx - cx) ** 2 + (yy - cy) ** 2 <= rad ** 2
            grad = np.clip(255 - (((xx - cx) ** 2 + (yy - cy) ** 2) ** 0.5 / rad * 180), 40, 255)
            for c in range(3):
                chan = img[:, :, c]
                chan[mask] = grad[mask].astype(np.uint8)
    return img


# ── MhtmlParser.kt pipeline, reproduced exactly ─────────────────────────────
def adaptive_sample_size(w: int, h: int, target: int) -> int:
    """Mirrors MhtmlParser.adaptiveSampleSize(): coarse target = 2x final target."""
    target_coarse = target * 2
    sample = 1
    while max(w, h) / (sample * 2) >= target_coarse:
        sample *= 2
    return sample


def generate_thumbnail(bgr: np.ndarray, target: int):
    """Mirrors MhtmlParser.scaleCompressAndRecycle(): coarse decode -> bilinear -> WebP."""
    h, w = bgr.shape[:2]
    sample = adaptive_sample_size(w, h, target)

    t0 = time.perf_counter()
    coarse_w, coarse_h = max(1, w // sample), max(1, h // sample)
    # INTER_AREA approximates the block-averaging behavior of BitmapFactory's
    # inSampleSize subsampled decode.
    coarse = cv2.resize(bgr, (coarse_w, coarse_h), interpolation=cv2.INTER_AREA)

    largest = max(coarse.shape[0], coarse.shape[1])
    if largest > target:
        scale = target / largest
        new_w = max(1, int(coarse.shape[1] * scale))
        new_h = max(1, int(coarse.shape[0] * scale))
        # Bitmap.createScaledBitmap(..., filter=true)
        fine = cv2.resize(coarse, (new_w, new_h), interpolation=cv2.INTER_LINEAR)
    else:
        fine = coarse

    rgb = cv2.cvtColor(fine, cv2.COLOR_BGR2RGB)
    buf = io.BytesIO()
    Image.fromarray(rgb).save(buf, "WEBP", quality=WEBP_QUALITY, method=4)
    elapsed = time.perf_counter() - t0
    return buf.getvalue(), elapsed, fine.shape[1], fine.shape[0]


def sharpness(img_bgr: np.ndarray) -> float:
    """Variance of Laplacian - standard no-reference blur metric."""
    gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
    return cv2.Laplacian(gray, cv2.CV_64F).var()


def display_and_measure(webp_bytes: bytes, cell_w_px: int, cell_h_px: int) -> np.ndarray:
    """Decode the thumbnail (as Glide does) and upscale it to the real
    on-screen grid cell via centerCrop-equivalent bilinear scaling, exactly
    like ImageView(scaleType=centerCrop) + GPU compositing does."""
    pil = Image.open(io.BytesIO(webp_bytes)).convert("RGB")
    thumb = cv2.cvtColor(np.array(pil), cv2.COLOR_RGB2BGR)
    th, tw = thumb.shape[:2]
    scale = max(cell_w_px / tw, cell_h_px / th)
    up_w, up_h = max(1, round(tw * scale)), max(1, round(th * scale))
    upscaled = cv2.resize(thumb, (up_w, up_h), interpolation=cv2.INTER_LINEAR)
    x0 = max(0, (up_w - cell_w_px) // 2)
    y0 = max(0, (up_h - cell_h_px) // 2)
    return upscaled[y0:y0 + cell_h_px, x0:x0 + cell_w_px]


def reference_ceiling(bgr: np.ndarray, cell_w_px: int, cell_h_px: int) -> np.ndarray:
    """Source resized DIRECTLY to the on-screen cell in one high-quality pass
    - the theoretical sharpness ceiling with no small-thumbnail bottleneck."""
    h, w = bgr.shape[:2]
    scale = max(cell_w_px / w, cell_h_px / h)
    up_w, up_h = max(1, round(w * scale)), max(1, round(h * scale))
    interp = cv2.INTER_AREA if scale < 1 else cv2.INTER_LINEAR
    resized = cv2.resize(bgr, (up_w, up_h), interpolation=interp)
    x0 = max(0, (up_w - cell_w_px) // 2)
    y0 = max(0, (up_h - cell_h_px) // 2)
    return resized[y0:y0 + cell_h_px, x0:x0 + cell_w_px]


def main():
    os.makedirs(SOURCE_DIR, exist_ok=True)
    sources = []
    for i in range(N_PAGES):
        path = os.path.join(SOURCE_DIR, f"page_{i:02d}.jpg")
        if not glob.glob(path):
            cv2.imwrite(path, make_test_page(i), [cv2.IMWRITE_JPEG_QUALITY, 92])
        sources.append(cv2.imread(path))
    print(f"Loaded {len(sources)} synthetic manga test pages\n")

    for density_name, density in DENSITIES.items():
        cell_w_px = round(CELL_W_DP * density)
        cell_h_px = round(CELL_H_DP * density)
        print(f"== Display: {density_name}  ->  on-screen cell ~= {cell_w_px}x{cell_h_px}px ==")

        ref_mean = float(np.mean([sharpness(reference_ceiling(s, cell_w_px, cell_h_px)) for s in sources]))
        print(f"  reference ceiling sharpness (direct source->cell resize): {ref_mean:.1f}")
        print(f"  {'size':>6} {'file KB':>9} {'encode ms':>10} {'sharpness':>10} {'% of ceiling':>13} {'upscale x':>9}")

        for size in CANDIDATE_SIZES:
            file_sizes, times, sharpnesses, up_factors = [], [], [], []
            for src in sources:
                webp_bytes = None
                for _ in range(REPEATS):
                    webp_bytes, elapsed, tw, th = generate_thumbnail(src, size)
                    times.append(elapsed)
                file_sizes.append(len(webp_bytes))
                displayed = display_and_measure(webp_bytes, cell_w_px, cell_h_px)
                sharpnesses.append(sharpness(displayed))
                up_factors.append(max(cell_w_px / tw, cell_h_px / th))

            mean_kb, mean_ms = np.mean(file_sizes) / 1024, np.mean(times) * 1000
            mean_sharp, mean_up = np.mean(sharpnesses), np.mean(up_factors)
            tag = "  <- baseline" if size == 140 else ("  <- chosen" if size == 200 else "")
            print(f"  {size:>6} {mean_kb:>9.2f} {mean_ms:>10.3f} {mean_sharp:>10.1f} "
                  f"{mean_sharp / ref_mean * 100:>12.1f}% {mean_up:>8.2f}x{tag}")
        print()

    # ── Robustness check: does 200px ever get LESS coarse-decode headroom
    # than 140px across realistic source resolutions? (analytical, not just
    # our 1600x2400 synthetic set) ──
    print("== Robustness: coarse-decode headroom, 140px vs 200px, by source size ==")
    print(f"  {'source longest px':>18} {'coarse@140':>11} {'coarse@200':>11}")
    for dim in [800, 1000, 1200, 1500, 1800, 2000, 2400, 2800, 3200, 4000]:
        c140 = dim // adaptive_sample_size(dim, dim, 140)
        c200 = dim // adaptive_sample_size(dim, dim, 200)
        print(f"  {dim:>18} {c140:>11} {c200:>11}{'  (200px never worse)' if c200 >= c140 else '  *** REGRESSION ***'}")


if __name__ == "__main__":
    main()
