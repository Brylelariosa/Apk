# MIE (Manga Image Extractor) — Architecture

This document describes the app's module structure and the two main data
flows (Extract and Merge). It is meant to orient a new contributor before
they touch a specific file, not to duplicate the detailed rationale already
written as doc comments in the source — where this document says "see
X.kt", that file's own comments are the source of truth and should be kept
in sync with the code by whoever changes it.

## Package layout

```
com.mangatool.app
├── MainActivity.kt            entry point; owns AppMode switching and view wiring
├── AppState.kt                single source of truth for the current library + filters
├── MhtmlParser.kt             MHTML decoding + WebP thumbnail generation
├── AllPhotosActivity.kt       "view all photos" gallery screen
├── ImagePreviewActivity.kt    full-screen pager (single image / delete / restore)
├── MergeImagePickerActivity.kt device-gallery picker for building Merge groups
├── InternalFileManagerActivity.kt built-in file browser (fallback when no external one exists)
├── model/
│   └── Models.kt              ImageItem, ImageGroup — plain data, no Android deps
├── manager/                   business-logic collaborators (see below)
├── adapter/                   RecyclerView adapters (UI layer)
└── util/                      stateless, reusable helpers (see below)
```

## The `manager` package

Each class here owns exactly one concern. `FileManager` is a thin facade
over four of them so `MainActivity`/`NavigationController` keep a single,
stable entry point:

| Class | Owns |
|---|---|
| `FileManager` | Facade — composes the four below; also the per-chapter rename dialog |
| `FileImportProcessor` | Turning picked-up URIs into `ImageGroup`s (MHTML parse + loose images); lazy per-group dimension decode |
| `FolderPreferenceManager` | The remembered Extract/Merge save-folder URIs |
| `SaveExportManager` | Save-to-folder/CBZ flow and its dialogs |
| `SharePrecacheManager` | Share URI caching, per-chapter/share-all actions, stale-cache cleanup |
| `NavigationController` | Launching other Activities and handling their results |
| `UiStateManager` | View-visibility state, stats line, scroll-fast tracking (`awaitScrollIdle`) |
| `SelectionManager<T>` | Generic multi-select bookkeeping (selection order, invert, select-all) — used by three different screens |

Why the `FileManager` split exists: it was previously a single ~1,080-line
class doing all five things above. Splitting it did not change any public
behavior — `MainActivity` and `NavigationController` call the exact same
methods on `FileManager` as before; internally it now delegates to the
right collaborator. See `FileManager`'s class doc comment for the full
rationale.

## The `util` package

Everything here is stateless (or, for a couple of small caches like
`ThumbnailWorker`, self-contained) and has no dependency on any Activity or
Adapter. Grouped by what they do:

**Image decoding / thumbnails**
- `BitmapUtils` — coarse-then-precise bitmap decode pipeline
- `SampleSizeCalculator` — the `inSampleSize` math shared by `BitmapUtils` and `MhtmlParser`
- `ThumbnailWorker` — background WebP thumbnail generation + in-memory path cache
- `ThumbnailGlideLoader` — the "load pre-built thumbnail, else placeholder + generate" pattern shared by every grid (`ChapterAdapter`, `ImageThumbAdapter`, `FilteredThumbAdapter`, `AllPhotosActivity`)
- `GlideMangaModule` — Glide's `AppGlideModule` configuration (disk cache size, decode format)

**Saving / naming**
- `FolderSaver`, `CbzCreator`, `ImageSaver` — the three save/export targets (SAF folder, CBZ zip, MediaStore share cache)
- `FileNameSanitizer` — the one place that decides "is this name safe to write to disk"
- `MimeTypes` — extension → MIME type lookup
- `ShareIntentLauncher` — builds and fires the share chooser Intent

**Merging**
- `ImageMerger` — pairs images and composites them side-by-side (used by both the full-quality save path and the thumbnail-preview path)

**Misc**
- `Prefs` — typed `SharedPreferences` wrapper
- `FileSorter` / `FileSortBy` — directory-listing sort, used by `InternalFileManagerActivity`
- `GridHeightCalculator` — fixed-height grid math for `ChapterAdapter`'s nested RecyclerViews
- `ByteSizeFormatter` — human-readable file-size strings
- `ActivityTransitions` — version-gated screen-transition helper (API 34's `overrideActivityTransition` vs the deprecated `overridePendingTransition`)

## Data flow: Extract

1. User picks one or more `.mhtml`/`.mht` files (or loose images) via a
   system picker or the built-in file manager.
2. `MainActivity` hands the resulting URIs to `FileManager.processFiles()`,
   which delegates to `FileImportProcessor`.
3. `FileImportProcessor` classifies each URI (MHTML vs loose image), then:
   - MHTML files are parsed concurrently (bounded by a `Semaphore(2)`) via
     `MhtmlParser.parse()`, which decodes each embedded image to a temp file
     and kicks off background WebP thumbnail generation for it.
   - Loose images are stream-copied into the app's cache and get the same
     thumbnail treatment.
4. Each successfully parsed file becomes one `ImageGroup` (a "chapter"),
   added to `AppState.groups`.
5. `AppState.applyFilters()` runs (size/GIF/dimension filters, per the
   user's settings) to split each group's images into `displayImages` and
   `filteredImages`.
6. `ChapterAdapter` renders the resulting groups. Expanding a chapter row
   lazily triggers `FileImportProcessor.launchDimsDecodeForGroup()` if pixel
   dimensions aren't known yet (needed for the dimension filter).
7. Saving (folder or CBZ) goes through `SaveExportManager`, sharing goes
   through `SharePrecacheManager` — both read the already-filtered
   `displayImages` from each group.

## Data flow: Merge

Same import pipeline, but `AppState.currentMode == AppMode.MERGE` changes
two things: `AppState.applyFilters()` is a no-op (merge mode never filters
pages out), and `ImageMerger.pairImages()`/`merge()` combine each group's
images two at a time into single composited pages before saving. Merge
groups can also be built manually via `MergeImagePickerActivity`, which
reads directly from the device's `MediaStore`.

## Testing

- `app/src/test` — JVM unit tests. Pure logic (filters, sanitizing, sample-size
  math, filename parsing) is tested directly; anything touching a real
  Android framework class the JVM can't fake (`SharedPreferences`,
  `Bitmap`/`Canvas`) either uses Robolectric or is left to the instrumented
  suite.
- `app/src/androidTest` — instrumented Espresso tests for critical UI flows
  (mode switching, settings panel, sort controls) that need a real
  Activity/View tree.

See the final refactor report for what is and isn't covered yet.
