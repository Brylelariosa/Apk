# Changelog

## v31 — Architecture refactor, test coverage, UI polish

Maintainability- and quality-focused pass. No intentional user-facing
behavior changes except where explicitly noted as a bug fix below.

### Refactors

- Split `FileManager` (~1,080 lines) into a thin facade over four
  single-responsibility collaborators: `FileImportProcessor`,
  `FolderPreferenceManager`, `SaveExportManager`, `SharePrecacheManager`.
  Public API on `FileManager` itself is unchanged.
- Split `ChapterAdapter` (~1,000 lines): extracted `FilteredThumbAdapter`
  to its own file; broke `onBindViewHolder` into five named helpers
  (`bindCover`, `bindNameAndCount`, `bindExpandState`, `bindFilteredSection`,
  `prefetchMissingThumbnails`).
- Refactored `MhtmlParser.parse()`'s ~185-line body into named helpers:
  `detectBoundary`, `readPartHeaders`, `consumeUntilBoundary`,
  `decodeBinaryBody`, `resolveImageExtension`.
- Extracted duplicated logic into new shared utilities: `ThumbnailGlideLoader`
  (4 copies of the same Glide-load pattern), `SampleSizeCalculator` (the
  `inSampleSize` loop, both axis variants), `FileNameSanitizer` (3 copies,
  one dead), `MimeTypes`, `ByteSizeFormatter`, `GridHeightCalculator`,
  `FileSorter`, `ShareIntentLauncher`.
- Deduplicated `ImageMerger.merge()`/`mergeThumbnail()` via a shared
  compositing helper.
- Moved `awaitScrollIdle()` onto `UiStateManager`, next to the
  `isScrollingFast` state it reads.

### Bug fixes

- `MhtmlParser`'s filename-cleanup regex (`smartRename`) never actually
  matched a plain `.mht` extension (only `.mhtm`/`.mhtml`), even though the
  app elsewhere accepts `.mht` as a valid MHTML file. A `.mht` import's
  chapter name would show a stray literal `.mht` suffix. Fixed the regex to
  match both.
- `ByteSizeFormatter`'s MB formatting now explicitly uses `Locale.US`
  instead of the device's default locale — previously a device set to a
  locale using `,` as the decimal separator (e.g. German) would render
  sizes like `1,5 MB`, which reads as a typo in an otherwise English UI.

### Dead code removed

- `BitmapUtils.decodeForDisplay()` and the `ByteArray` overload of
  `decodeThumbnail()` — confirmed unused anywhere in the codebase.
- `ImageSaver`'s private `sanitize()`/`mimeForExt()` — unused duplicates of
  what is now `FileNameSanitizer`/`MimeTypes`.
- The hidden, zero-size Facebook/WhatsApp share button stubs in
  `bottom_sheet_saved.xml` and their backing `fb_blue`/`wa_green` colors —
  never referenced from any Kotlin binding.
- The unused `btn_saved_ok` string resource.
- An unused `groupIdx` constructor parameter on `FilteredThumbAdapter`.

### UI

- Removed all emoji from UI text and layouts, replacing icon-as-emoji usage
  with proper vector drawables (`ic_folder_open`, `ic_book_open`,
  `ic_archive`, plus reuse of existing icons) or plain text.
- Added a real screen-transition (push/slide) between the main screen and
  every secondary Activity, using `overrideActivityTransition` on API 34+
  and the classic `overridePendingTransition` compat path below it — two
  previously-unused animation resources (`slide_in_right`/`slide_out_left`)
  are now wired up, and two new mirrored resources
  (`slide_in_left`/`slide_out_right`) complete the close-side transition.

### Testing

- Added JUnit/Robolectric/Mockito test infrastructure (none existed before).
- Added unit tests for `AppState` filtering, `SelectionManager`,
  `SampleSizeCalculator`, `FileNameSanitizer`, `MimeTypes`,
  `ByteSizeFormatter`, `GridHeightCalculator`, `FileSorter`, `ImageMerger`
  (pure logic), `MhtmlParser` (`smartRename`/`decodeQP`/`sniffImageExt`),
  and `Prefs` (Robolectric).
- Added instrumented Espresso tests for `MainActivity`'s mode-switching and
  settings-panel flows, and `InternalFileManagerActivity`'s sort controls.

### Maintenance

- Added the missing `-keep` proguard rule for `InternalFileManagerActivity`,
  for consistency with the app's other three manifest-declared activities.
