package com.mangatool.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.mangatool.app.util.ThumbnailGlideLoader
import com.mangatool.app.util.applyCloseSlideTransitionCompat
import com.mangatool.app.util.applyOpenSlideTransition

class AllPhotosActivity : AppCompatActivity() {

    sealed class GalleryItem {
        data class Header(val title: String, val count: Int) : GalleryItem()
        data class Photo(
            val groupIdx: Int,
            val imageIdx: Int,
            val groupName: String,
            val isMerge: Boolean,
            val sizeKb: Int
        ) : GalleryItem()
    }

    companion object {
        private const val COLS = 4
    }

    private lateinit var recycler: RecyclerView
    private lateinit var titleView: TextView
    private lateinit var countView: TextView

    // Set whenever ImagePreviewActivity reports a change (delete/restore) —
    // set on AppState directly, so it's visible immediately, but this
    // Activity's own gallery grid was built once in onCreate() and needs an
    // explicit rebuild to reflect it, and MainActivity (which launched this
    // Activity with a bare startActivity(), not through an ActivityResult
    // launcher) needs to be told too via this Activity's own result code.
    private var didModifyLibrary = false

    private val previewLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            didModifyLibrary = true
            buildGallery()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applyOpenSlideTransition()
        setContentView(R.layout.activity_all_photos)

        recycler  = findViewById(R.id.all_photos_grid)
        titleView = findViewById(R.id.all_photos_title)
        countView = findViewById(R.id.all_photos_count)

        findViewById<View>(R.id.btn_back).setOnClickListener { finish() }

        buildGallery()
    }

    override fun finish() {
        setResult(if (didModifyLibrary) Activity.RESULT_OK else Activity.RESULT_CANCELED)
        super.finish()
        applyCloseSlideTransitionCompat()
    }

    private fun buildGallery() {
        val isMerge = AppState.currentMode == AppMode.MERGE
        val items = mutableListOf<GalleryItem>()

        AppState.groups.forEachIndexed { gIdx, group ->
            val images = group.displayImages
            if (images.isNotEmpty()) {
                items.add(GalleryItem.Header(group.groupName, images.size))
                images.forEachIndexed { iIdx, img ->
                    items.add(GalleryItem.Photo(
                        groupIdx  = gIdx,
                        imageIdx  = iIdx,
                        groupName = group.groupName,
                        isMerge   = isMerge,
                        sizeKb    = img.size / 1024
                    ))
                }
            }
        }

        val totalPhotos = items.filterIsInstance<GalleryItem.Photo>().size
        titleView.text = "All Photos"
        countView.text = "$totalPhotos images"

        val spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int) =
                if (items[position] is GalleryItem.Header) COLS else 1
        }

        val lm = GridLayoutManager(this, COLS).apply { this.spanSizeLookup = spanSizeLookup }
        recycler.layoutManager = lm
        recycler.adapter = GalleryAdapter(items)
    }

    // ── Adapter ────────────────────────────────────────────────────────────────
    inner class GalleryAdapter(
        private val items: List<GalleryItem>
    ) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

        private val TYPE_HEADER = 0
        private val TYPE_PHOTO  = 1

        override fun getItemViewType(position: Int) =
            if (items[position] is GalleryItem.Header) TYPE_HEADER else TYPE_PHOTO

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            val inflater = LayoutInflater.from(parent.context)
            return if (viewType == TYPE_HEADER) {
                HeaderVH(inflater.inflate(R.layout.item_gallery_header, parent, false))
            } else {
                PhotoVH(inflater.inflate(R.layout.item_gallery_photo, parent, false))
            }
        }

        override fun getItemCount() = items.size

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
            when (val item = items[position]) {
                is GalleryItem.Header -> (holder as HeaderVH).bind(item)
                is GalleryItem.Photo  -> (holder as PhotoVH).bind(item)
            }
        }

        override fun onViewRecycled(holder: RecyclerView.ViewHolder) {
            if (holder is PhotoVH) Glide.with(holder.img).clear(holder.img)
            super.onViewRecycled(holder)
        }

        /**
         * Load a gallery thumbnail using the same pre-generated-thumbnail-first
         * pattern ChapterAdapter/ImageThumbAdapter already use (v29), instead of
         * decoding the full original page image via Glide — now shared via
         * [ThumbnailGlideLoader] instead of a fourth copy of the same Glide chain.
         *
         * Previous behavior here loaded `File(imgItem.filePath)` (the full
         * extracted page, 200–500 KB) at a stale `.override(140)` on every bind —
         * the same full-decode-on-scroll cost v29 removed elsewhere, since this
         * grid was never migrated to it.
         */
        private fun loadThumb(holder: PhotoVH, thumbnailPath: String?, fallbackPath: String) {
            ThumbnailGlideLoader.load(holder.img, Glide.with(holder.img), thumbnailPath, fallbackPath) {
                val pos = holder.bindingAdapterPosition
                if (pos != RecyclerView.NO_POSITION) notifyItemChanged(pos)
            }
        }

        inner class HeaderVH(v: View) : RecyclerView.ViewHolder(v) {
            private val title: TextView = v.findViewById(R.id.gallery_header_title)
            private val count: TextView = v.findViewById(R.id.gallery_header_count)
            fun bind(h: GalleryItem.Header) {
                title.text = h.title
                count.text = "${h.count} images"
            }
        }

        inner class PhotoVH(v: View) : RecyclerView.ViewHolder(v) {
            val img:  ImageView = v.findViewById(R.id.gallery_photo_image)
            val num:  TextView  = v.findViewById(R.id.gallery_photo_num)
            val size: TextView  = v.findViewById(R.id.gallery_photo_size)
            // No loadJob — Glide manages request lifecycle per ImageView target

            fun bind(photo: GalleryItem.Photo) {
                val group   = AppState.groups.getOrNull(photo.groupIdx) ?: return
                val imgItem = group.displayImages.getOrNull(photo.imageIdx) ?: return

                num.text  = "${photo.imageIdx + 1}"
                size.text = "${photo.sizeKb}KB"

                loadThumb(this, imgItem.thumbnailPath, imgItem.filePath)

                itemView.setOnClickListener {
                    val intent = Intent(this@AllPhotosActivity, ImagePreviewActivity::class.java).apply {
                        putExtra(ImagePreviewActivity.EXTRA_GROUP_IDX, photo.groupIdx)
                        putExtra(ImagePreviewActivity.EXTRA_IMAGE_IDX, photo.imageIdx)
                        putExtra(ImagePreviewActivity.EXTRA_IS_MERGE, photo.isMerge)
                    }
                    previewLauncher.launch(intent)
                }
            }
        }
    }
}
