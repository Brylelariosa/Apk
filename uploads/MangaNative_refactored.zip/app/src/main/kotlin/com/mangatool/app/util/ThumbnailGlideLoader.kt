package com.mangatool.app.util

import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.widget.ImageView
import com.bumptech.glide.RequestManager
import com.bumptech.glide.load.DecodeFormat
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.mangatool.app.MhtmlParser
import java.io.File

/**
 * Single implementation of MIE's "pre-generated-thumbnail-first" Glide load
 * pattern, shared by every grid/list that shows a manga-page thumbnail:
 * `ChapterAdapter`'s chapter cover, `ImageThumbAdapter`'s extract/merge
 * grids, `FilteredThumbAdapter`'s filtered strip, and `AllPhotosActivity`'s
 * gallery grid.
 *
 * ROOT CAUSE this pattern solves (see `ThumbnailWorker`'s doc comment for
 * the full history): loading the full original page image just to shrink it
 * to a ~200px thumbnail during scrolling caused visible jank on low-end
 * devices. The fix is always the same three steps, previously copy-pasted
 * at each of the four call sites above:
 *
 *  1. Prefer [thumbnailPath] (the pre-generated WebP) or a path
 *     [ThumbnailWorker] already generated for [fallbackPath] in this
 *     session — Glide loads that tiny file directly.
 *  2. If neither is available yet, show a neutral placeholder immediately
 *     (zero IO) and queue background generation via [ThumbnailWorker].
 *  3. When generation finishes, invoke [onThumbnailReady] so the caller can
 *     re-bind (each adapter has its own idea of "how to find my position
 *     again", so that part stays with the caller).
 *
 * [onThumbnailReady] is invoked whether generation succeeded or failed,
 * matching every original call site: a failed generation simply leaves
 * [ThumbnailWorker.getCached] returning null, so the next bind harmlessly
 * re-shows the placeholder instead of silently going stale.
 */
object ThumbnailGlideLoader {

    /**
     * Placeholder shown while a thumbnail is being generated in the
     * background. Dark gray matches every card/grid background in the app,
     * so it reads as an intentional empty state rather than a glitch.
     */
    val PLACEHOLDER = ColorDrawable(Color.parseColor("#2A2A2A"))

    /**
     * Loads a thumbnail into [target] using [glide], never loading the full
     * original image.
     *
     * @param glide the caller's [RequestManager] — callers that already cache
     *   one per adapter (to avoid repeated `Glide.with()` lookups) pass that;
     *   callers that don't, pass a fresh `Glide.with(view)`.
     * @param thumbnailPath the pre-generated WebP path, if already known.
     * @param fallbackPath the full-resolution source path — used only as a
     *   cache/generation key, never loaded directly.
     * @param onThumbnailReady called on the main thread once background
     *   generation completes (success or failure) when the placeholder path
     *   was taken; not called at all on the fast path.
     */
    fun load(
        target: ImageView,
        glide: RequestManager,
        thumbnailPath: String?,
        fallbackPath: String,
        onThumbnailReady: (() -> Unit)? = null
    ) {
        val effectivePath = thumbnailPath ?: ThumbnailWorker.getCached(fallbackPath)
        if (effectivePath != null) {
            glide.load(File(effectivePath))
                .override(MhtmlParser.THUMBNAIL_TARGET_PX)
                .format(DecodeFormat.PREFER_RGB_565)
                .dontAnimate()
                .diskCacheStrategy(DiskCacheStrategy.NONE)
                .skipMemoryCache(false)
                .into(target)
        } else {
            glide.clear(target)
            target.setImageDrawable(PLACEHOLDER)
            ThumbnailWorker.generate(fallbackPath) { onThumbnailReady?.invoke() }
        }
    }
}
