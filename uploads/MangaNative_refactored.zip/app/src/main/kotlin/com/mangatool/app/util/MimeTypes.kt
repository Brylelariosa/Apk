package com.mangatool.app.util

/**
 * Maps a manga page's file extension to its MIME type, for the SAF and
 * MediaStore APIs that require one (`DocumentFile.createFile()`,
 * `ContentValues.MIME_TYPE`).
 */
object MimeTypes {

    /**
     * Returns the MIME type for [ext] (case-insensitive, without a leading
     * dot). Defaults to `image/png` for any unrecognized extension — every
     * write path that calls this always has some image bytes to store, so a
     * generic image MIME degrades gracefully instead of failing the
     * `createFile()` call outright.
     */
    fun forImageExtension(ext: String): String = when (ext.lowercase()) {
        "jpg", "jpeg" -> "image/jpeg"
        "png"         -> "image/png"
        "webp"        -> "image/webp"
        "gif"         -> "image/gif"
        else          -> "image/png"
    }
}
