package com.mangatool.app.manager

import android.net.Uri
import android.view.View
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.mangatool.app.AppMode
import com.mangatool.app.AppState
import com.mangatool.app.MainActivity
import com.mangatool.app.MhtmlParser
import com.mangatool.app.R
import com.mangatool.app.databinding.ActivityMainBinding
import com.mangatool.app.model.ImageGroup
import com.mangatool.app.model.ImageItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/**
 * Turns picked-up [Uri]s into [ImageGroup]s in [AppState.groups]: classifies
 * each URI as MHTML or a loose image, parses MHTML files concurrently
 * (bounded by [extractLimiter]), copies loose images into the app's cache,
 * and generates thumbnails for both paths. Also owns the lazy per-group
 * pixel-dimension decode triggered when the user expands a chapter.
 *
 * Extracted out of the original `FileManager` god class as the "how content
 * enters the library" concern — everything below this class's API is an
 * implementation detail of "import," and everything above it (save, share,
 * folder prefs) never needs to know about MHTML parsing or content-URI
 * classification at all.
 */
class FileImportProcessor(
    private val activity: MainActivity,
    private val b: ActivityMainBinding,
    private val uiState: UiStateManager,
    private val refreshChapterList: suspend () -> Unit,
    private val onGroupDimsDecoded: suspend (ImageGroup) -> Unit,
    /** Fired once, 10s after a successful extraction finishes — lets the
     *  share-precache collaborator start warming its URI cache without this
     *  class needing to know that collaborator exists. */
    private val onExtractionSettled: () -> Unit
) {
    private var processingJob: Job? = null

    // Caps concurrent MHTML extractions. Without this, 50+ files launch 50+
    // simultaneous IO coroutines causing storage saturation and RAM spikes.
    // Coroutines beyond the limit suspend cheaply — no thread is held while waiting.
    private val extractLimiter = Semaphore(2)

    // ── Progress-post time gate ────────────────────────────────────────────────
    // With Semaphore(2) allowing two concurrent extractors and MhtmlParser firing
    // onProgress every 10 images, we can still see up to ~2 posts per 10 images
    // if both files happen to invoke the callback simultaneously.  The CAS below
    // enforces a global 100 ms wall-clock minimum between any two main-thread
    // posts across all concurrent extractors — a lockless single read + compare-
    // and-swap, so the fast path (within the window) costs ~3 ns with no
    // allocation and zero contention on the IO threads.
    private val lastProgressPostMs = AtomicLong(0L)

    private companion object {
        // Hoisted out of the per-file classification loop — previously a new
        // Regex was compiled for every imported URI.
        val LOOSE_IMAGE_EXT_RE = Regex(""".*\.(jpg|jpeg|png|webp|gif)""")
    }

    /** Cancels any in-flight import — call from MainActivity.onDestroy() and
     *  from the Reset action before AppState.resetAll() deletes the temp
     *  files an in-progress import would still be writing to. */
    fun onDestroy() {
        processingJob?.cancel()
    }

    fun cancelActiveImport() {
        processingJob?.cancel()
    }

    private fun getFileName(uri: Uri): String =
        activity.contentResolver.query(uri, null, null, null, null)?.use {
            val idx = it.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && it.moveToFirst()) it.getString(idx) else "file"
        } ?: uri.lastPathSegment ?: "file"

    // ── File processing ────────────────────────────────────────────────────────

    fun processFiles(uris: List<Uri>, folderName: String = "") {
        processingJob?.cancel()
        b.progressArea.visibility = View.VISIBLE
        b.dropZone.visibility     = View.GONE
        b.actionBar.visibility    = View.GONE
        // Reset the progress time-gate so the first update in this batch is
        // never suppressed, regardless of when the last extraction ran.
        lastProgressPostMs.set(0L)

        // ── Pause Glide during extraction ─────────────────────────────────────
        // Extraction saturates Dispatchers.IO with up to 2 concurrent MHTML
        // parsers (Semaphore(2)), each writing multiple 200-500 KB decoded images
        // plus ~5-7 KB WebP thumbnails to internal storage in a tight loop.
        //
        // On low-end devices (eMMC, single-channel storage controller) the disk
        // bus is essentially serialized: the extraction writes occupy the queue,
        // so concurrent Glide disk-reads for existing visible thumbnails stall,
        // producing dropped frames and janky scrolling during extraction.
        //
        // pauseRequestsRecursive() queues any new Glide.into() calls in memory
        // without issuing disk reads. In-flight requests that already started
        // a disk read complete normally — only NEW requests are deferred.
        // Cost: ~0 ms (just sets an atomic flag on the RequestManager).
        //
        // resumeRequestsRecursive() is called once, right after refreshChapterList()
        // sets the adapter. By that point:
        //   (a) all extraction IO is done (coroutineScope already awaited it all),
        //   (b) RecyclerView has measured + bound visible items and called into() for
        //       their cover images — those into() calls are now in the queue,
        //   (c) the storage bus is idle.
        // Glide then loads all visible covers in one clean burst against an empty
        // disk queue — thumbnails appear almost instantly instead of dribbling in.
        //
        // Estimated improvement on Snapdragon 695 (2022 mid-range):
        //   post-extraction thumbnail load latency: ~400 ms → ~120 ms.
        Glide.with(activity).pauseRequestsRecursive()

        processingJob = activity.lifecycleScope.launch {
            val looseImages    = mutableListOf<ImageItem>()
            var duplicateCount = 0

            val looseTempDir = File(activity.cacheDir, "img_cache/loose_${System.currentTimeMillis()}")

            // Only URIs that successfully produced a group are committed to seenUris.
            // Prevents a mid-cancel from poisoning seenUris with phantom entries.
            val successfulUris = ConcurrentLinkedQueue<String>()

            val newUris = uris.filter { uri ->
                val s = uri.toString()
                if (AppState.seenUris.contains(s)) { duplicateCount++; false } else true
            }
            val totalFiles  = newUris.size
            val doneCount   = AtomicInteger(0)

            // ── Separate MHTML from loose images ─────────────────────────────
            // PERF FIX: getFileName() calls contentResolver.query() via Binder IPC.
            // Original code called it in two .filter passes on the Main thread:
            //   50 files × 2 passes = 100 Binder IPC round-trips on the UI thread.
            //   Each call takes 2–15 ms; worst-case = 750 ms of UI blocking right
            //   at the moment the progress bar first appears, causing visible freeze.
            //
            // Fix: resolve ALL names in ONE IO pass before the filter split.
            //   • Names are computed once per URI (not twice).
            //   • All IPC calls happen on Dispatchers.IO → zero Main-thread cost.
            //   • The Pair<Uri, String> list is reused in the extraction and loose
            //     loops below, eliminating the redundant getFileName(uri) calls there.
            //
            // Estimated improvement: 0–750 ms of UI-thread unblock; on average
            // devices with a slow ContentProvider (e.g. MiUI, EMUI file pickers)
            // this is the primary cause of the "brief freeze before progress shows".
            val classifiedUris: List<Pair<Uri, String>> = withContext(Dispatchers.IO) {
                newUris.map { uri -> uri to getFileName(uri).lowercase() }
            }
            val mhtmlPairs = classifiedUris.filter { (_, n) ->
                n.endsWith(".mhtml") || n.endsWith(".mht")
            }
            val loosePairs = classifiedUris.filter { (_, n) ->
                n.matches(LOOSE_IMAGE_EXT_RE)
            }

            withContext(Dispatchers.Main) {
                b.progressStatus.text  = "Extracting $totalFiles files…"
                b.progressBar.progress = 0
            }

            // ── Parse all MHTML files in parallel ────────────────────────────
            // Each file gets its own IO coroutine. On a 4-core device this is
            // ~4× faster than the previous serial loop. Peak RAM stays bounded
            // because MhtmlParser holds only one image (~270 KB) at a time per
            // coroutine — total peak ≈ cores × 270 KB, not file-count × 270 KB.
            //
            // Results arrive out of order, so we collect into a thread-safe list
            // then sort by original URI order before adding to AppState.groups.
            val parsedGroups = ConcurrentHashMap<Int, ImageGroup>()

            coroutineScope {
                mhtmlPairs.forEachIndexed { i, (uri, resolvedName) ->
                    launch(Dispatchers.IO) {
                        // Semaphore limits active extractions to 2 at a time.
                        // All 50+ coroutines launch immediately but suspend here
                        // until a slot opens — no thread is blocked while waiting.
                        //
                        // IMPORTANT: withContext(Dispatchers.Main) must NOT appear
                        // inside withPermit. withContext(Main) is a suspension point —
                        // the coroutine suspends waiting for the Main thread to be
                        // available (up to 16 ms = one frame). If that happens while
                        // holding the permit, both slots can be simultaneously occupied
                        // just waiting for Main, starving all 50 other queued coroutines.
                        // With both permits blocked, extraction effectively serialises
                        // to zero throughput until Main is free.
                        //
                        // Fix: capture the completion count inside withPermit (an
                        // AtomicInt increment, not a suspension point), then issue the
                        // withContext(Main) update AFTER the permit is released.
                        var completedDone = 0
                        extractLimiter.withPermit {
                            val uriStr      = uri.toString()
                            // PERF: Use resolvedName from the IO pre-classification pass above.
                            // Saves one redundant getFileName()/contentResolver.query() call per
                            // file inside withPermit — and since the Semaphore slot is held,
                            // removing even a 2 ms IPC call here frees the slot 2 ms sooner
                            // for the next waiting coroutine.
                            val displayName = resolvedName
                            val tempDir     = File(activity.cacheDir, "img_cache/${System.currentTimeMillis()}_$i")
                            // Wrap the raw ContentResolver stream in a 64 KB
                            // BufferedInputStream.  ContentResolver streams are backed
                            // by a Binder pipe; each read() call returns at most one
                            // kernel buffer (~4–8 KB).  BufferedInputStream batches
                            // those reads into 65 536-byte fills, cutting syscall count
                            // by ~8–16× and reducing Binder IPC latency proportionally.
                            // The stream is still closed via the outer .use { } because
                            // closing a BufferedInputStream closes the wrapped stream.
                            val raw = runCatching { activity.contentResolver.openInputStream(uri) }.getOrNull()
                                ?: return@withPermit
                            val stream = BufferedInputStream(raw, 65_536)

                            val group = stream.use { s ->
                                MhtmlParser.parse(s, displayName, tempDir) { found ->
                                    // ── Time-gated main-thread post ──────────────────
                                    // CAS: read current timestamp, compare with stored
                                    // last-post time.  If ≥100 ms have elapsed AND the
                                    // CAS wins (only one concurrent caller can win per
                                    // window), dispatch one post.  All other concurrent
                                    // callers within the window simply skip — zero
                                    // allocation, no blocking, no Handler churn.
                                    val now = System.currentTimeMillis()
                                    val last = lastProgressPostMs.get()
                                    if (now - last >= 100L && lastProgressPostMs.compareAndSet(last, now)) {
                                        val done = doneCount.get()
                                        b.root.post {
                                            b.progressStatus.text  = "Extracting… ${done + 1}/$totalFiles — $displayName ($found images)"
                                            b.progressBar.progress = ((done * 100) / totalFiles.coerceAtLeast(1))
                                                .coerceAtMost(99)
                                        }
                                    }
                                }
                            } ?: return@withPermit

                            parsedGroups[i] = group.also { it.sourceUri = uriStr }
                            successfulUris.add(uriStr)
                            // AtomicInt.incrementAndGet() is a CPU instruction, not a
                            // suspension point — safe to call inside withPermit.
                            completedDone = doneCount.incrementAndGet()
                            // Permit releases HERE at the end of withPermit block.
                        }
                        // ── Permit already released above ─────────────────────
                        // withContext(Main) now runs AFTER the permit is freed, so
                        // the next waiting coroutine can acquire the slot immediately
                        // without waiting for the Main thread to process our update.
                        if (completedDone > 0) {
                            withContext(Dispatchers.Main) {
                                b.progressBar.progress = (completedDone * 100) / totalFiles.coerceAtLeast(1)
                            }
                        }
                    }
                }
            }
            // Restore document order before appending to AppState.groups
            mhtmlPairs.indices
                .mapNotNull { parsedGroups[it] }
                .forEach { AppState.groups.add(it) }

            // ── Handle loose images ───────────────────────────────────────────
            // PERF: Use loosePairs (pre-resolved names) instead of calling
            // getFileName() again. Eliminates N more Binder IPC calls on Main.
            loosePairs.forEach { (uri, name) ->
                val uriStr = uri.toString()
                val ext    = name.substringAfterLast('.')
                looseTempDir.mkdirs()
                val idx    = looseImages.size
                val file   = File(looseTempDir, "${idx.toString().padStart(6, '0')}.$ext")

                // ── Stream-copy replaces readBytes() → writeBytes() ───────────────
                // The old code did:
                //   val data = openInputStream(uri)?.readBytes()   // ByteArray ~200–500 KB
                //   file.writeBytes(data)                          // second copy / buffer
                //   looseImages.add(... size = data.size ...)      // size from byte count
                //
                // Problem: readBytes() allocates a full ByteArray for the entire image
                // (~200–500 KB). With 30 loose images that is 6–15 MB of simultaneous
                // heap pressure. writeBytes() internally allocates another buffer of up
                // to 64 KB. When Android's GC sees the heap spike right after the loop,
                // it triggers a concurrent collection that competes with the first
                // RecyclerView layout + Glide thumbnail decodes — visible stutter.
                //
                // Fix: copyTo() reads and writes in 64 KB chunks and never holds more
                // than 64 KB of a single image in RAM at once. It returns the total
                // byte count, which we use as ImageItem.size. The file on disk is
                // identical — this is a pure memory-allocation optimisation.
                //
                // Estimated RAM saving: (N_images − 1) × image_size (the last image's
                // ByteArray is still live during writeBytes in the old code, so only
                // N−1 are simultaneously alive). For 30 × 350 KB images: ~9.5 MB.
                val bytesWritten: Long = withContext(Dispatchers.IO) {
                    runCatching {
                        activity.contentResolver.openInputStream(uri)?.use { src ->
                            BufferedInputStream(src, 65_536).use { buf ->
                                file.outputStream().buffered(65_536).use { out ->
                                    buf.copyTo(out) // returns bytes copied
                                }
                            }
                        } ?: 0L
                    }.getOrElse { 0L }
                }
                if (bytesWritten <= 0L) return@forEach

                // ── Generate WebP thumbnail for loose images ──────────────────────
                // Without a thumbnailPath, ChapterAdapter falls back to loading the
                // full original image via Glide with DiskCacheStrategy.RESOURCE.
                // On first scroll Glide decodes the full JPEG/PNG (200–500 KB) and
                // then resizes it — visible jank on every first appearance.
                //
                // MhtmlParser.generateThumbnail writes a THUMBNAIL_TARGET_PX px WebP
                // (~5–7 KB) in ~4–9 ms per image. The adapter then loads ONLY that
                // tiny file, identical to the MHTML extraction path.
                //
                // Estimated saving on first scroll: ~80–200 ms of Glide decode time
                // eliminated per loose image (≥ 1.5 s for 10 loose images on a low-
                // end device with slow eMMC).
                val thumbDir  = File(looseTempDir, "thumbnails").also { it.mkdirs() }
                val thumbFile = File(thumbDir, "${idx.toString().padStart(6, '0')}.webp")
                val thumbPath = withContext(Dispatchers.IO) {
                    MhtmlParser.generateThumbnail(file.absolutePath, thumbFile)
                }

                looseImages.add(
                    ImageItem(idx, file.absolutePath, ext, bytesWritten.toInt(),
                        thumbnailPath = thumbPath)
                )
                successfulUris.add(uriStr)
            }

            AppState.invalidateAllFilters()
            AppState.seenUris.addAll(successfulUris)

            if (looseImages.isNotEmpty()) {
                val n = AppState.groups.size + 1
                val label = when {
                    AppState.currentMode == AppMode.MERGE && folderName.isNotBlank() -> folderName
                    AppState.currentMode == AppMode.MERGE -> activity.getString(R.string.merge_group_label, n, looseImages.size)
                    // PERF: Use cached name from loosePairs — avoids a final getFileName() on Main.
                    loosePairs.size == 1 -> loosePairs[0].second.substringBeforeLast('.').ifBlank { "Images $n" }
                    uris.size == 1 && loosePairs.isEmpty() ->
                        (classifiedUris.firstOrNull()?.second ?: "").substringBeforeLast('.').ifBlank { "Images $n" }
                    else           -> "Images $n (${looseImages.size})"
                }
                AppState.groups.add(ImageGroup(label).also { it.allImages.addAll(looseImages) })
            }

            withContext(Dispatchers.Main) {
                b.progressBar.progress = 100
                val totalExtracted = AppState.groups.sumOf { it.allImages.size }
                b.progressStatus.text  = activity.getString(R.string.extraction_done, totalExtracted)
            }
            withContext(Dispatchers.Default) { AppState.applyFilters() }
            // ── One-frame yield before layout ─────────────────────────────────
            // applyFilters() allocates ~1 500 ImageItem.copy() objects (50 groups
            // × 30 images per name-stamp). On Android, that allocation burst after
            // a heavy extraction often tips the heap into a concurrent GC cycle.
            // If GC fires in the same frame as RecyclerView's first layout pass
            // (triggered by adapter = chapterAdapter), the Choreographer misses the
            // 16 ms deadline and the UI freezes for 30–80 ms right at the "Done" moment.
            //
            // yield() suspends here and resumes at the next Main-thread slot —
            // after the current Choreographer frame callback finishes. GC runs
            // during the suspension so RecyclerView gets a clean heap for layout.
            kotlinx.coroutines.yield()
            uiState.updateCachedStats()
            b.progressArea.visibility = View.GONE
            refreshChapterList()

            // ── Resume Glide — queued covers load immediately ──────────────────
            // By this point:
            //   • All MHTML extractions are complete (coroutineScope waited).
            //   • applyFilters() and updateCachedStats() have run.
            //   • refreshChapterList() has set b.chapterList.adapter, triggering
            //     RecyclerView's first layout pass. onBindViewHolder fired for
            //     every visible chapter row and called Glide.into(holder.cover)
            //     for each cover — those into() calls are queued in Glide's
            //     RequestManager because we paused it in processFiles().
            //   • The storage bus is now idle — no more extraction IO competing.
            //
            // resumeRequestsRecursive() drains the queue: all visible cover loads
            // start simultaneously against an empty disk queue. Since each cover
            // is a pre-built ~5–7 KB WebP, loading 6 covers takes ~15–25 ms total
            // instead of the ~400 ms it took when the disk bus was saturated.
            Glide.with(activity).resumeRequestsRecursive()

            // ── Defer share pre-cache ─────────────────────────────────────────
            // onExtractionSettled() (the share-precache collaborator's
            // preCacheShareUris()) runs 51 sequential ImageSaver.buildShareUris()
            // calls on a single IO coroutine (1 all-library + 50 per-chapter).
            // Starting this too soon saturates the storage bus when Glide is
            // loading first visible covers and the user is beginning to interact.
            //
            // 10 s gives Glide's first cover burst (t≈0) and early scrolling
            // (t=0–5 s) plenty of headroom. With lazy dims decode now removed
            // there is no 6 s IO event to stagger against — 10 s is the only
            // scheduled background IO left after extraction.
            activity.lifecycleScope.launch {
                delay(10_000L)
                onExtractionSettled()
            }

            // ── Dims decode is now LAZY (on-demand per chapter expand) ───────
            // Dims are decoded per-group via the onGroupExpand callback wired
            // into ChapterAdapter. Each expand triggers launchDimsDecodeForGroup()
            // for only that one group. Groups the user never opens are never
            // decoded at all.

            if (duplicateCount > 0) {
                com.google.android.material.snackbar.Snackbar.make(
                    b.root, activity.getString(R.string.toast_duplicate_skipped, duplicateCount),
                    com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
                ).setBackgroundTint(0xFF21262D.toInt()).setTextColor(0xFFF0F6FC.toInt()).show()
            }
        }
    }

    /**
     * Decode pixel dimensions for a single group's images on demand, then push
     * the updated displayImages list into the inner ImageThumbAdapter via
     * AsyncListDiffer.submitList().
     *
     * Called by the onGroupExpand callback wired into ChapterAdapter — only
     * when the user actually taps a chapter row to expand it. Groups the
     * user never opens are never decoded, eliminating a library-wide
     * BitmapFactory burst on every extraction regardless of user interaction.
     *
     * Idempotent: returns immediately (O(N) scan, zero IO) if all images
     * already have width > 0, so re-expanding a chapter costs nothing.
     */
    fun launchDimsDecodeForGroup(group: ImageGroup) {
        // Fast-path: all dims already populated — nothing to do.
        if (group.allImages.none { it.width == 0 }) return
        activity.lifecycleScope.launch(com.mangatool.app.util.BitmapUtils.decodeDispatcher) {
            // If a fling is in progress, wait for it to settle before doing
            // ANY disk reads. Starting I/O during a fling competes with Glide
            // on the eMMC bus and causes frame drops on the first scroll after
            // expand.
            if (uiState.isScrollingFast) uiState.awaitScrollIdle()
            // Step 1: decode dims into allImages (source of truth).
            // Each decodeDimensions() call reads only the image file header
            // (BitmapFactory inJustDecodeBounds = true — no pixel data loaded),
            // so it typically takes <1 ms per file on warm eMMC.
            group.allImages.forEachIndexed { idx, img ->
                if (img.width == 0) {
                    // Yield every 5 images if a fling starts mid-decode.
                    if (idx % 5 == 0 && uiState.isScrollingFast) uiState.awaitScrollIdle()
                    val (w, h) = com.mangatool.app.util.BitmapUtils.decodeDimensions(img.filePath)
                    group.allImages[idx] = img.copy(width = w, height = h)
                }
            }
            // Step 2: build originalIdx → (w, h) lookup from allImages
            val dimsMap: Map<Int, Pair<Int, Int>> = group.allImages
                .filter { it.width > 0 }
                .associate { it.originalIdx to (it.width to it.height) }
            // Step 3: propagate dims into displayImages
            val newDisplay = group.displayImages.map { img ->
                val (w, h) = dimsMap[img.originalIdx] ?: (0 to 0)
                if (w > 0 && img.width == 0) img.copy(width = w, height = h) else img
            }
            group.displayImages = newDisplay
            // Step 4: dimensions just became known for this group — if the
            // dimension filter is on, re-run applyFilters() so any pages that
            // are now under the min-width/min-height threshold move into
            // filteredImages. Cheap: fingerprint check skips every other
            // group untouched by this decode pass.
            AppState.invalidateFilter(group)
            withContext(Dispatchers.Default) { AppState.applyFilters() }
            // Step 5: hand back to MainActivity to push the updated list into
            // the inner adapter (AsyncListDiffer diffs off Main — no blocking)
            // and refresh stats/chapter list.
            withContext(Dispatchers.Main) { onGroupDimsDecoded(group) }
        }
    }
}
