package com.mangatool.app.util

import android.app.Activity
import android.content.ClipData
import android.content.Intent
import android.net.Uri

/**
 * Builds and fires the "share these images" chooser Intent.
 *
 * Extracted as a standalone utility (rather than a method on one of the
 * file-operation collaborators) because it has no state of its own — it
 * only ever needs a [Uri] list and an [Activity] to start the chooser from —
 * and two independent collaborators need it: the save flow's "Share" button
 * on the post-save bottom sheet, and the share-precache flow's per-chapter
 * and share-all actions. Giving it its own home avoids either collaborator
 * depending on the other purely for this one call.
 */
object ShareIntentLauncher {

    fun launch(activity: Activity, uris: List<Uri>) {
        if (uris.isEmpty()) return
        val intent = if (uris.size == 1) {
            Intent(Intent.ACTION_SEND).apply {
                type = "image/*"
                putExtra(Intent.EXTRA_STREAM, uris[0])
            }
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                type = "image/*"
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(uris))
            }
        }
        // clipData is required on Android 10+ so every URI gets read permission,
        // not just the first one in EXTRA_STREAM.
        val clip = ClipData.newRawUri("", uris[0])
        for (i in 1 until uris.size) clip.addItem(ClipData.Item(uris[i]))
        intent.clipData = clip
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        activity.startActivity(Intent.createChooser(intent, "Share images via…"))
    }
}
