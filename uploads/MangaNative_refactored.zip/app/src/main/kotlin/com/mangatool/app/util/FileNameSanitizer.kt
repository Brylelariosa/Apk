package com.mangatool.app.util

/**
 * Sanitizes a user-typed or extracted name so it is always safe to use as a
 * single path segment across every destination this app writes to: a SAF
 * `DocumentFile` (folder save), a `ZipEntry` name (CBZ), and a chapter's
 * on-screen label. All of them reject the same set of reserved characters,
 * so this is the single source of truth for "is this name safe to write to
 * disk" instead of three near-identical copies of the same regex drifting
 * independently.
 *
 * The backing [Regex] is compiled once here rather than inside a function
 * body — the previous three copies each constructed a new `Regex` on every
 * call (every rename, every save, every CBZ entry), which is a measurable
 * cost for names generated in a loop (e.g. CBZ export over many chapters).
 */
object FileNameSanitizer {

    private val ILLEGAL_PATH_CHARS = Regex("""[\\/:*?"<>|]""")

    /**
     * Replaces every character illegal in a path segment with `_`, trims
     * surrounding whitespace, and substitutes [fallback] if the result is
     * blank (e.g. the input was only illegal characters or whitespace).
     */
    fun sanitize(input: String, fallback: String): String =
        input.trim().replace(ILLEGAL_PATH_CHARS, "_").ifBlank { fallback }
}
