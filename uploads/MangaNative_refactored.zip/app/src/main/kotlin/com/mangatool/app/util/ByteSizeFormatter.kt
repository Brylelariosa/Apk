package com.mangatool.app.util

import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale

/**
 * Human-readable file-size formatting, shared between the main screen's
 * stats line and the built-in file manager's per-file rows.
 *
 * Two variants are kept, rather than merged into one, because they serve
 * different displays with different existing conventions — this is a
 * consolidation of *where* the logic lives, not a forced unification of
 * *what* it outputs, so neither screen's displayed text changes:
 *
 *  - [formatKilobytes] mirrors the main screen's two-tier KB/MB summary.
 *    Kept coarse on purpose — the stats line recomputes on every filter
 *    change, so sub-KB precision would be noise, not signal.
 *  - [formatBytes] gives the built-in file manager's per-file row a precise
 *    three-tier B/KB/MB reading for a single file.
 */
object ByteSizeFormatter {

    /** e.g. `512L -> "512 KB"`, `2048L -> "2.0 MB"`. [totalKb] is already in KB. */
    fun formatKilobytes(totalKb: Long): String =
        if (totalKb > 1024) "%.1f MB".format(Locale.US, totalKb / 1024.0) else "$totalKb KB"

    // Built once, with an explicit Locale.US — the previous per-file-row call
    // site constructed a new DecimalFormat on every single invocation (i.e.
    // once per row per RecyclerView bind) using the DEFAULT locale, which
    // formats the decimal point as "," on some device locales (e.g. German),
    // producing text like "1,5 MB" that reads as a typo in an otherwise
    // English UI. Fixed here rather than left as a latent inconsistency.
    private val mbFormat = DecimalFormat("#.#", DecimalFormatSymbols(Locale.US))

    /** e.g. `512L -> "512 B"`, `2048L -> "2 KB"`, `3_145_728L -> "3 MB"`. */
    fun formatBytes(bytes: Long): String = when {
        bytes < 1_024L     -> "$bytes B"
        bytes < 1_048_576L -> "${bytes / 1_024} KB"
        else               -> "${mbFormat.format(bytes.toDouble() / 1_048_576.0)} MB"
    }
}
