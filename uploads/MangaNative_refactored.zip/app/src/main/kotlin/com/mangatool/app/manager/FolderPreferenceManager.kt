package com.mangatool.app.manager

import android.content.Intent
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import com.mangatool.app.MainActivity
import com.mangatool.app.util.Prefs

/**
 * Owns the "which SAF folder does Extract/Merge save to" preference: taking
 * persistable URI permission when the user picks a folder, validating that
 * permission is still granted before every save, and clearing the stored
 * choice (either because the user asked to, or because Android revoked
 * access behind our back — e.g. after an app reinstall or a ROM's storage
 * reset).
 *
 * Extracted out of the original `FileManager` god class as the "durable
 * save-destination" concern, separate from what actually gets written there
 * ([SaveExportManager]) and how files arrive in the library
 * ([FileImportProcessor]).
 */
class FolderPreferenceManager(
    private val activity: MainActivity,
    private val uiState: UiStateManager
) {

    fun persistAndRememberFolder(uri: Uri, isMerge: Boolean) {
        runCatching {
            activity.contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        }
        val name = runCatching {
            DocumentFile.fromTreeUri(activity, uri)?.name
        }.getOrNull() ?: uri.lastPathSegment ?: "Selected folder"

        if (isMerge) {
            Prefs.mergeFolderUri  = uri.toString()
            Prefs.mergeFolderName = name
        } else {
            Prefs.extractFolderUri  = uri.toString()
            Prefs.extractFolderName = name
        }
    }

    /**
     * Returns the stored URI if it is still accessible (permission not
     * revoked), otherwise clears it from prefs and returns null so the user
     * is asked to pick again.
     */
    fun getValidFolderUri(isMerge: Boolean): Uri? {
        val stored = if (isMerge) Prefs.mergeFolderUri else Prefs.extractFolderUri
            ?: return null
        val uri = runCatching { Uri.parse(stored) }.getOrNull() ?: return null

        // Check we still have write permission by trying to open the DocumentFile.
        val accessible = runCatching {
            val df = DocumentFile.fromTreeUri(activity, uri)
            df != null && df.canWrite()
        }.getOrDefault(false)

        return if (accessible) uri else {
            // Permission was revoked (e.g. app reinstall, ROM reset) — clear and re-ask.
            if (isMerge) { Prefs.mergeFolderUri = null; Prefs.mergeFolderName = null }
            else         { Prefs.extractFolderUri = null; Prefs.extractFolderName = null }
            uiState.updateSettingsFolderLabels()
            null
        }
    }

    fun clearExtractFolder() {
        Prefs.extractFolderUri = null; Prefs.extractFolderName = null
        uiState.updateSettingsFolderLabels()
    }

    fun clearMergeFolder() {
        Prefs.mergeFolderUri = null; Prefs.mergeFolderName = null
        uiState.updateSettingsFolderLabels()
    }
}
