package com.mangatool.app.adapter

import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DecodeFormat
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.mangatool.app.AppState
import com.mangatool.app.MhtmlParser
import com.mangatool.app.R
import com.mangatool.app.model.ImageGroup
import com.mangatool.app.model.ImageItem
import com.mangatool.app.model.MergeDirection
import com.mangatool.app.util.ImageMerger
import com.mangatool.app.util.ThumbnailWorker
import java.io.File

/**
 * Thumbnail adapter for extract-mode and merge-mode image grids.
 *
 * v19: Glide replaces all manual bitmap loading.
 * v21: Pre-generated thumbnail files eliminate all runtime resize.
 * v27: RGB_565 on the fast path; Glide RequestManager cached per adapter.
 * v28: initialPrefetchItemCount, itemAnimator=null, nested-scroll disabled.
 *
 * v29 — FULL-IMAGE FALLBACK REMOVED ──────────────────────────────────────────
 *
 * ROOT CAUSE OF BLANK-THUMBNAIL LAG:
 *   When thumbnailPath was null (thumbnail generation failed, picker import,
 *   or any edge case), loadThumb() called:
 *
 *     Glide.load(File(fullOriginalImage)).override(140)…
 *
 *   A full-resolution JPEG (200–500 KB) was decoded to produce a 140 px result.
 *   With no concurrency limit, 8–12 simultaneous decodes during a fast scroll
 *   saturated the storage bus and CPU decode pool → 60–300 ms frame drops.
 *
 * FIX — three-part:
 *
 *   1. PLACEHOLDER: when thumbnailPath is null AND ThumbnailWorker has no cached
 *      path for this filePath, Glide is NOT called at all. A ColorDrawable
 *      (#2A2A2A) is set directly on the ImageView — zero IO, zero BitmapFactory.
 *
 *   2. BACKGROUND GENERATION: ThumbnailWorker.generate(filePath, onReady) queues
 *      a bounded background job (Semaphore(3) max concurrent). The worker derives
 *      the thumb directory from filePath using the same convention as MhtmlParser,
 *      so it reuses existing thumbnail files if already written.
 *
 *   3. NOTIFY ON READY: when the thumbnail is ready, onReady fires on Main.
 *      findPosition(filePath) locates the item in the current differ list and
 *      calls notifyItemChanged(pos). The next bind hits getCached() fast path.
 *
 * NORMAL PATH (thumbnailPath != null) IS UNCHANGED:
 *   - Glide loads the pre-built ~5–7 KB WebP thumbnail, no resize required.
 *   - DiskCacheStrategy.NONE: the thumbnail file IS the cache.
 *   - RGB_565: halves decoded bitmap memory (~39 KB vs ~78 KB per thumbnail).
 *
 * MERGE DIRECTION (horizontal/vertical) ────────────────────────────────────
 *   Merge-mode pairs can be composited side by side (HORIZONTAL, the
 *   original/default behavior) or stacked top/bottom (VERTICAL). The two
 *   directions use separate item layouts (item_thumb_merge.xml /
 *   item_thumb_merge_vertical.xml) that share identical view IDs
 *   (thumb_left/thumb_right/btn_swap), so onBindViewHolder()'s binding logic
 *   below needs no direction-specific branching at all — only
 *   onCreateViewHolder()'s layout choice differs. "Left"/"right" in this
 *   file's naming refers to reading position 1/2, not literal screen sides —
 *   in the vertical layout thumb_left is the TOP panel and thumb_right is
 *   the BOTTOM panel.
 */
class ImageThumbAdapter(
    initialItems: List<Any>,
    private val isMerge: Boolean,
    private val group: ImageGroup? = null,
    private val groupIdx: Int = 0,
    /** Merge-mode-only: which item layout onCreateViewHolder inflates.
     *  Ignored entirely in extract mode. Fixed for this adapter instance's
     *  lifetime — see ChapterAdapter.attachMainGrid, which recreates (rather
     *  than reuses) a group's ImageThumbAdapter when its mergeDirection
     *  changes, since the two layouts need different inflated views. */
    private val mergeDirection: MergeDirection = MergeDirection.HORIZONTAL,
    val onItemClick: (Int) -> Unit,
    private val onItemLongClick: ((ImageItem) -> Unit)? = null,
    private val onSwapChanged: (() -> Unit)? = null
) : RecyclerView.Adapter<ImageThumbAdapter.VH>() {

    companion object {
        /** Payload token for dims-only rebind — does NOT cancel in-flight Glide request. */
        const val PAYLOAD_DIMS  = "dims"

        /**
         * Payload token for thumbnail-ready rebind (v30).
         * Fires from scheduleNotify() after ThumbnailWorker.generate() completes.
         * Triggers a partial bind that only reloads the thumbnail ImageView —
         * skipping overlay, dims badge, and other non-image state.
         */
        const val PAYLOAD_THUMB = "thumb"

        /** Thumbnail target size in pixels. Single source of truth: MhtmlParser.THUMBNAIL_TARGET_PX. */
        private const val THUMB_SIZE = MhtmlParser.THUMBNAIL_TARGET_PX

        /**
         * Distinct view types for extract vs the two merge layouts.
         *
         * RecyclerView's RecycledViewPool (shared across every chapter's
         * ImageThumbAdapter — see ChapterAdapter.sharedThumbPool) buckets
         * recycled ViewHolders by getItemViewType(). Before merge direction
         * existed, every item in a given adapter used the same layout, so
         * the default getItemViewType() (always 0) never caused a problem.
         * Now that a merge-mode adapter can be built with EITHER
         * item_thumb_merge.xml or item_thumb_merge_vertical.xml, returning 0
         * for both would let the pool hand a horizontal-inflated ViewHolder
         * to a vertical adapter's bind (or vice versa) — the content binds
         * correctly, but the recycled View's actual layout is now fixed at
         * inflation time and can't rearrange itself, so it would render with
         * the wrong (stale) side-by-side/stacked arrangement. Distinct
         * view types keep the pool's buckets separate, exactly as intended.
         */
        internal const val VIEW_TYPE_EXTRACT          = 0
        internal const val VIEW_TYPE_MERGE_HORIZONTAL = 1
        internal const val VIEW_TYPE_MERGE_VERTICAL   = 2

        /**
         * Placeholder color shown while a thumbnail is being generated.
         *
         * Dark gray (#2A2A2A) matches the chapter card background so the
         * placeholder blends into the UI rather than flashing a white void.
         * Shown only for items where thumbnailPath is null AND ThumbnailWorker
         * has not yet generated a thumbnail. MHTML-extracted chapters always
         * have thumbnailPath set, so this placeholder appears only for edge cases.
         */
        private val PLACEHOLDER = ColorDrawable(Color.parseColor("#2A2A2A"))

        val ITEM_CALLBACK = object : DiffUtil.ItemCallback<Any>() {
            override fun areItemsTheSame(oldItem: Any, newItem: Any): Boolean = when {
                oldItem is ImageItem && newItem is ImageItem ->
                    oldItem.originalIdx == newItem.originalIdx
                oldItem is List<*>   && newItem is List<*>   ->
                    (oldItem.firstOrNull() as? ImageItem)?.originalIdx ==
                    (newItem.firstOrNull() as? ImageItem)?.originalIdx
                else -> oldItem == newItem
            }
            override fun areContentsTheSame(oldItem: Any, newItem: Any): Boolean = when {
                oldItem is ImageItem && newItem is ImageItem ->
                    oldItem.filePath      == newItem.filePath     &&
                    oldItem.thumbnailPath == newItem.thumbnailPath &&
                    oldItem.userDeleted   == newItem.userDeleted  &&
                    oldItem.width         == newItem.width        &&
                    oldItem.height        == newItem.height
                oldItem is List<*>   && newItem is List<*>   ->
                    oldItem.size == newItem.size && oldItem.zip(newItem).all { (a, b) ->
                        a is ImageItem && b is ImageItem && a.filePath == b.filePath
                    }
                else -> oldItem == newItem
            }

            /**
             * v30: Return a payload token when only one field changed so the
             * payload-aware onBindViewHolder() can do a cheap partial rebind
             * instead of a full one (which reloads Glide + all overlays).
             *
             * PAYLOAD_DIMS  → dims decode finished; only update the badge text.
             * PAYLOAD_THUMB → thumbnail generation finished; only swap the image.
             * null          → something else changed; fall back to full rebind.
             *
             * Without this, refreshGroupDisplayImages() after dims decode fires
             * differ.submitList() → DiffUtil dispatches null payload → RecyclerView
             * calls onBindViewHolder(holder, pos) for every changed item → full
             * Glide reload for all 30 thumbnails in the chapter. With this override,
             * the same refresh dispatches PAYLOAD_DIMS → only the badge is updated.
             */
            override fun getChangePayload(oldItem: Any, newItem: Any): Any? {
                if (oldItem !is ImageItem || newItem !is ImageItem) return null
                if (oldItem.filePath != newItem.filePath) return null
                val deletedChanged = oldItem.userDeleted != newItem.userDeleted
                if (deletedChanged) return null   // fall back to full rebind
                val dimsChanged  = oldItem.width  != newItem.width ||
                                   oldItem.height != newItem.height
                val thumbChanged = oldItem.thumbnailPath != newItem.thumbnailPath
                return when {
                    dimsChanged  && !thumbChanged -> PAYLOAD_DIMS
                    thumbChanged && !dimsChanged  -> PAYLOAD_THUMB
                    else                          -> null  // multiple changes → full rebind
                }
            }
        }
    }

    private val differ = AsyncListDiffer(this, ITEM_CALLBACK)
    private val items: List<Any> get() = differ.currentList

    // Single RequestManager cached at adapter creation — avoids 30 synchronized
    // singleton lookups per chapter expand.
    private var glide: com.bumptech.glide.RequestManager? = null

    private fun glide(context: android.content.Context): com.bumptech.glide.RequestManager =
        glide ?: Glide.with(context).also { glide = it }

    // ── v30: Batch thumbnail-ready notifications ───────────────────────────────
    //
    // PROBLEM: ThumbnailWorker runs with Semaphore(3) — up to 3 thumbnails complete
    // simultaneously. Each completion immediately called notifyItemChanged(pos),
    // stacking 3 separate RecyclerView diff + rebind passes in the same frame.
    // Over 30 thumbnails per chapter this produced ~10 bursts of 3 rebinds each,
    // firing constantly while the user scrolled — causing frame budget overruns.
    //
    // FIX: collect all ready positions in a 60 ms window and flush in one pass.
    // 60 ms ≈ 3.6 frames at 60 Hz — imperceptible thumbnail-appear delay, but
    // converts 10 bursts × 3 rebinds = 30 notify calls into ~5 batched calls.
    private val pendingThumbPositions = mutableSetOf<Int>()
    private val thumbNotifyHandler    = Handler(Looper.getMainLooper())
    private val thumbNotifyRunnable   = Runnable {
        if (pendingThumbPositions.isEmpty()) return@Runnable
        val copy = pendingThumbPositions.toList()
        pendingThumbPositions.clear()
        copy.forEach { pos -> notifyItemChanged(pos, PAYLOAD_THUMB) }
    }

    private fun scheduleThumbNotify(pos: Int) {
        pendingThumbPositions.add(pos)
        thumbNotifyHandler.removeCallbacks(thumbNotifyRunnable)
        thumbNotifyHandler.postDelayed(thumbNotifyRunnable, 60L)
    }

    fun destroy() {
        glide = null
        // Cancel any pending batch notification — the adapter is being detached.
        thumbNotifyHandler.removeCallbacks(thumbNotifyRunnable)
        pendingThumbPositions.clear()
    }

    init {
        setHasStableIds(true)
        differ.submitList(initialItems)
    }

    override fun getItemId(position: Int): Long = when (val item = items[position]) {
        is ImageItem -> item.originalIdx.toLong()
        is List<*>   -> (item.firstOrNull() as? ImageItem)?.originalIdx?.toLong()
                            ?: position.toLong()
        else         -> position.toLong()
    }

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val image:      ImageView  = v.findViewById(R.id.thumb_image)
        val overlay:    View       = v.findViewById(R.id.thumb_overlay)
        val dims:       TextView?  = v.findViewById(R.id.thumb_dims)
        val thumbLeft:  ImageView? = v.findViewById(R.id.thumb_left)
        val thumbRight: ImageView? = v.findViewById(R.id.thumb_right)
        val btnSwap:    View?      = v.findViewById(R.id.btn_swap)
    }

    override fun getItemViewType(position: Int): Int = when {
        !isMerge -> VIEW_TYPE_EXTRACT
        mergeDirection == MergeDirection.VERTICAL -> VIEW_TYPE_MERGE_VERTICAL
        else -> VIEW_TYPE_MERGE_HORIZONTAL
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val layout = when (viewType) {
            VIEW_TYPE_MERGE_VERTICAL   -> R.layout.item_thumb_merge_vertical
            VIEW_TYPE_MERGE_HORIZONTAL -> R.layout.item_thumb_merge
            else                       -> R.layout.item_thumb
        }
        val v = LayoutInflater.from(parent.context).inflate(layout, parent, false)
        val holder = VH(v)

        v.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) onItemClick(pos)
        }
        v.setOnLongClickListener {
            val pos = holder.bindingAdapterPosition
            if (!isMerge && pos != RecyclerView.NO_POSITION)
                onItemLongClick?.invoke(items[pos] as ImageItem)
            true
        }
        holder.btnSwap?.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (group != null && pos != RecyclerView.NO_POSITION) {
                if (group.pairSwaps.contains(pos)) group.pairSwaps.remove(pos)
                else group.pairSwaps.add(pos)
                notifyItemChanged(pos)
                onSwapChanged?.invoke()
            }
        }
        return holder
    }

    override fun getItemCount() = items.size

    /** Payload-aware bind: lightweight partial rebinds for known payload types. */
    override fun onBindViewHolder(holder: VH, position: Int, payloads: MutableList<Any>) {
        // Only short-circuit if every payload is a known lightweight token.
        // Unknown payloads (e.g. from AsyncListDiffer) fall through to full rebind.
        if (payloads.isEmpty() || payloads.any { it != PAYLOAD_DIMS && it != PAYLOAD_THUMB }) {
            super.onBindViewHolder(holder, position, payloads)
            return
        }
        val img = items.getOrNull(position) as? ImageItem ?: return
        // PAYLOAD_DIMS: update only the dims badge — does NOT touch the Glide request.
        if (payloads.contains(PAYLOAD_DIMS) && img.width > 0 && img.height > 0) {
            holder.dims?.text = "${img.width}×${img.height}"
            holder.dims?.visibility = View.VISIBLE
        }
        // PAYLOAD_THUMB: thumbnail is now ready — reload only the image view.
        // getCached() will return the path because scheduleThumbNotify() is only
        // called from ThumbnailWorker.generate()'s onReady, after pathCache is set.
        if (payloads.contains(PAYLOAD_THUMB)) {
            loadThumb(holder.image, img.thumbnailPath, img.filePath)
        }
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.overlay.visibility = View.GONE
        holder.dims?.visibility   = View.GONE

        if (!isMerge) {
            // ── Extract mode ───────────────────────────────────────────────────
            val img = items[position] as ImageItem
            holder.overlay.visibility = if (img.userDeleted) View.VISIBLE else View.GONE

            if (img.width > 0 && img.height > 0) {
                holder.dims?.text = "${img.width}×${img.height}"
                holder.dims?.visibility = View.VISIBLE
            }

            loadThumb(holder.image, img.thumbnailPath, img.filePath)

        } else {
            // ── Merge mode ────────────────────────────────────────────────────
            @Suppress("UNCHECKED_CAST")
            val pair    = items[position] as List<ImageItem>
            val swapped = group?.pairSwaps?.contains(position) == true
            val leftImg  = if (swapped && pair.size > 1) pair[1] else pair[0]
            val rightImg = if (swapped && pair.size > 1) pair[0] else pair.getOrNull(1)

            holder.thumbLeft?.let  { loadThumb(it, leftImg.thumbnailPath,  leftImg.filePath)  }
            if (rightImg != null) {
                holder.thumbRight?.let { loadThumb(it, rightImg.thumbnailPath, rightImg.filePath) }
            } else {
                holder.thumbRight?.let { glide(it.context).clear(it) }
            }
        }
    }

    /**
     * Load a thumbnail into [target] — never loads the full original image.
     *
     * Priority order:
     *   1. [thumbnailPath] != null → Glide loads the pre-built WebP (fast path; normal case).
     *   2. ThumbnailWorker.getCached([fallbackPath]) != null → same Glide load, worker
     *      already generated it for a previous bind of this item.
     *   3. Neither → ColorDrawable placeholder + ThumbnailWorker.generate() queued.
     *      Zero IO on the calling thread. Glide is NOT called with the full original.
     *
     * v29 change: case 3 previously called Glide.load(File(fullOriginalImage)).
     * That has been REMOVED. The full original is never loaded during scrolling.
     */
    private fun loadThumb(target: ImageView, thumbnailPath: String?, fallbackPath: String) {
        // Resolve the best available thumbnail path
        val effectivePath = thumbnailPath ?: ThumbnailWorker.getCached(fallbackPath)

        if (effectivePath != null) {
            // ── Fast path: pre-built or worker-generated thumbnail available ──────
            // File is already THUMB_SIZE px WebP (~5–7 KB). override(THUMB_SIZE) is a no-op
            // resize signal to Glide; actual decode is nearly instantaneous.
            glide(target.context)
                .load(File(effectivePath))
                .override(THUMB_SIZE)
                .format(DecodeFormat.PREFER_RGB_565)   // 2 bytes/px vs 4; ~39 KB each
                .dontAnimate()
                .diskCacheStrategy(DiskCacheStrategy.NONE)  // file IS the cache
                .skipMemoryCache(false)                      // hot entries in LruCache
                .into(target)

        } else {
            // ── Placeholder path: thumbnail not yet generated ───────────────────
            //
            // CRITICAL: Glide.load(fullOriginalImage) is NOT called here.
            //
            // Previous behavior (REMOVED):
            //   Glide.load(File(fallbackPath)).override(140)…
            //   → Decoded 200–500 KB JPEG → 8–12 concurrent decodes on fast scroll
            //   → Storage bus saturation → frame drops → jank
            //
            // New behavior:
            //   1. Clear any stale Glide request on this recycled view.
            //   2. Set a dark-gray ColorDrawable directly (zero IO, zero BitmapFactory).
            //   3. Queue background generation via ThumbnailWorker (bounded by Semaphore(3)).
            //   4. When done, callback fires on Main → notifyItemChanged → next bind
            //      hits case 1 (getCached fast path) and shows the real thumbnail.
            glide(target.context).clear(target)
            target.setImageDrawable(PLACEHOLDER)

            ThumbnailWorker.generate(fallbackPath) { _ ->
                // onReady fires on Main thread.
                // Don't use a stale position captured at bind time — find the item
                // by filePath in the CURRENT differ list (safe after scroll/reorder).
                val pos = findPosition(fallbackPath)
                // v30: batch via scheduleThumbNotify instead of immediate
                // notifyItemChanged. Converts per-thumbnail rebind bursts into
                // a single pass every 60 ms. See scheduleThumbNotify() comments.
                if (pos >= 0) scheduleThumbNotify(pos)
            }
        }
    }

    /**
     * Find the adapter position of the item whose filePath matches [filePath].
     *
     * Handles both extract mode (List<ImageItem>) and merge mode (List<List<ImageItem>>).
     * Returns -1 if not found (item was removed while thumbnail was generating).
     *
     * Called on Main thread from ThumbnailWorker onReady callbacks.
     */
    private fun findPosition(filePath: String): Int {
        return items.indexOfFirst { item ->
            when (item) {
                is ImageItem -> item.filePath == filePath
                is List<*>   -> item.any { (it as? ImageItem)?.filePath == filePath }
                else         -> false
            }
        }
    }

    override fun onViewRecycled(holder: VH) {
        // Cancel in-flight Glide request and release bitmap back to BitmapPool.
        // Note: ThumbnailWorker callbacks are NOT cancelled here — they fire via
        // notifyItemChanged which is safe even if the VH has been recycled.
        glide(holder.itemView.context).clear(holder.image)
        holder.thumbLeft?.let  { glide(holder.itemView.context).clear(it) }
        holder.thumbRight?.let { glide(holder.itemView.context).clear(it) }
        super.onViewRecycled(holder)
    }

    /**
     * Submit a new item list to the differ.
     * AsyncListDiffer runs DiffUtil off Main and fires fine-grained notify* calls.
     */
    fun refreshItems(newItems: List<Any>) = differ.submitList(newItems)
}
