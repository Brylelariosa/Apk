package com.mangatool.app.util

import android.app.Activity
import android.os.Build
import com.mangatool.app.R

/**
 * Declares MIE's standard "push" screen transition for an Activity: the
 * incoming screen slides in from the right while the previous screen slides
 * out to the left, and the reverse happens on close (back navigation).
 * Call once from `onCreate()`.
 *
 * Two code paths are required because Android 14 (API 34) replaced the
 * per-call `overridePendingTransition(int, int)` — which must be invoked
 * again around every `startActivity()`/`finish()` — with a per-Activity
 * declaration, `overrideActivityTransition(...)`, made once and applied
 * automatically for the Activity's whole lifetime. The old API still works
 * on API 34 but is deprecated there, so this picks whichever is current for
 * the running device rather than using the deprecated call unconditionally.
 *
 * On API 24-33, this only declares the OPEN half — the CLOSE half still
 * needs [applyCloseSlideTransitionCompat] called from an overridden
 * `finish()`, since the old API has no "declare once" form:
 * ```
 * override fun onCreate(savedInstanceState: Bundle?) {
 *     super.onCreate(savedInstanceState)
 *     applyOpenSlideTransition()
 *     ...
 * }
 *
 * override fun finish() {
 *     super.finish()
 *     applyCloseSlideTransitionCompat()
 * }
 * ```
 */
fun Activity.applyOpenSlideTransition() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
        overrideActivityTransition(
            Activity.OVERRIDE_TRANSITION_OPEN, R.anim.slide_in_right, R.anim.slide_out_left
        )
        overrideActivityTransition(
            Activity.OVERRIDE_TRANSITION_CLOSE, R.anim.slide_in_left, R.anim.slide_out_right
        )
    } else {
        @Suppress("DEPRECATION")
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
    }
}

/**
 * Applies the closing half of the transition on API 24-33. Call from inside
 * an overridden `finish()`, right after `super.finish()`, so every exit path
 * (a Back button, the system back gesture, a result-returning finish() deep
 * in a callback) gets the transition — not just one hand-picked call site.
 *
 * A no-op on API 34+, where [applyOpenSlideTransition] already declared the
 * close transition once in `onCreate()` and the platform applies it to every
 * `finish()` call automatically.
 */
fun Activity.applyCloseSlideTransitionCompat() {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
        @Suppress("DEPRECATION")
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right)
    }
}
