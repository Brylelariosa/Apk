package com.mangatool.app.manager

import android.net.Uri
import android.view.View
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import com.mangatool.app.AppMode
import com.mangatool.app.AppState
import com.mangatool.app.MainActivity
import com.mangatool.app.databinding.ActivityMainBinding
import com.mangatool.app.util.ImageSaver
import com.mangatool.app.util.ShareCacheKey
import com.mangatool.app.util.ShareIntentLauncher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

/**
 * Warms and serves the share-URI cache used by every "Share" action (whole
 * library, single chapter): converting a chapter's images into
 * `FileProvider` URIs is IO-heavy (one file copy per image into a share-safe
 * location), so it is done once in the background and reused for every tap
 * afterward.
 *
 * Also owns the low-priority background dispatcher this pre-caching runs on
 * ([precacheDispatcher]), and the delayed stale-cache sweep that reclaims
 * disk space left behind by previous sessions — both exist to keep this
 * class's background IO from ever competing with Glide or scrolling on the
 * storage bus (see the dispatcher's doc comment below for the full
 * rationale).
 *
 * Extracted out of the original `FileManager` god class as the "share
 * delivery" concern, separate from how content enters the library
 * ([FileImportProcessor]) and how it's written out to permanent storage
 * ([SaveExportManager]).
 */
class SharePrecacheManager(
    private val activity: MainActivity,
    private val b: ActivityMainBinding,
    private val uiState: UiStateManager
) {

    // ConcurrentHashMap — NOT mutableMapOf(): preCacheShareUris() writes these
    // from the precacheDispatcher background thread while shareGroup() and
    // startShareAll() read them on the main thread. A plain LinkedHashMap
    // (what mutableMapOf() creates) gives no visibility or safety guarantee
    // across threads without external synchronization; ConcurrentHashMap
    // supports concurrent get/put/containsKey correctly with no locking
    // needed at the call sites, and with better read throughput than wrapping
    // a plain map in `synchronized`.
    private val shareCacheAll   = ConcurrentHashMap<String, List<Uri>>()
    private val shareCacheGroup = ConcurrentHashMap<String, List<Uri>>()
    private var preCacheJob: Job? = null

    // ── Low-priority pre-cache dispatcher ────────────────────────────────────
    // A dedicated single-threaded executor running at Thread.MIN_PRIORITY (1).
    //
    // WHY NOT Dispatchers.IO:
    //   Dispatchers.IO shares up to 64 threads at default priority (5). Running
    //   preCacheShareUris() there puts background file-copy IOs at the same OS
    //   scheduler priority as Glide thumbnail reads, so eMMC time slices are
    //   distributed equally. On a slow bus, Glide reads stall every 2nd or 3rd
    //   time slice — visible as cover pop-in during scrolling.
    //
    // WHY MIN_PRIORITY + single thread:
    //   Thread.MIN_PRIORITY (1) = Linux nice +19. The OS scheduler always prefers
    //   higher-priority threads (render thread = priority 0, Glide IO = priority 5)
    //   over this thread when the CPU or storage bus is contested. Only truly idle
    //   cycles are given to pre-caching.
    //
    //   Single thread serialises all precache IOs — at most one file-copy in
    //   flight at any moment from this job, so it can never saturate the bus.
    private val precacheDispatcher = Executors.newSingleThreadExecutor { r ->
        Thread(r, "share-precache").also { it.priority = Thread.MIN_PRIORITY }
    }.asCoroutineDispatcher()

    /** Cancels any in-flight precache and shuts down its dispatcher —
     *  call from MainActivity.onDestroy(). */
    fun onDestroy() {
        preCacheJob?.cancel()
        // Shut down the low-priority precache thread cleanly — prevents a thread
        // leak if the Activity is destroyed mid-precache (e.g. low-memory kill).
        precacheDispatcher.close()
    }

    // ── Stale cache cleanup ──────────────────────────────────────────────────────
    /**
     * Reclaims disk space left behind by previous sessions: leftover
     * cache/img_cache extraction folders (see AppState.sweepOrphanedImgCache)
     * and the entire cache/share_temp directory.
     *
     * WHY DELAYED instead of running immediately in onCreate (as this used to):
     *   Wiping share_temp/img_cache the instant the app opens risks deleting a
     *   file another app (e.g. Facebook) is still mid-upload from — if the user
     *   shared a chapter, backgrounded this app, then reopened it moments later
     *   while that share was still in flight, an immediate wipe would pull the
     *   file out from under it. Waiting gives any pending share from the
     *   previous session time to finish reading before cleanup touches
     *   anything, without ever leaving cache growth completely unchecked.
     *
     * WHY SAFE to delete what's left after the delay:
     *   Nothing about a chapter or a share session survives a process restart —
     *   AppState.groups and the shareCache* maps all start empty on a fresh
     *   launch. So anything found under img_cache/share_temp at this point
     *   cannot belong to the session that's now running; it can only be
     *   leftover from one that already ended.
     *
     * Runs on precacheDispatcher (MIN_PRIORITY, single thread — same one used
     * for share pre-caching) so this recursive disk-IO sweep never competes
     * with scrolling, extraction, or Glide's own reads.
     */
    fun scheduleStaleCacheCleanup() {
        activity.lifecycleScope.launch {
            delay(90_000L)
            withContext(precacheDispatcher) {
                runCatching { ImageSaver.clearShareCache(activity) }
                runCatching { AppState.sweepOrphanedImgCache(activity.cacheDir) }
            }
        }
    }

    // ── Share pre-cache ────────────────────────────────────────────────────────
    /**
     * Pre-populate share URI caches for the current library — scroll-aware, batched.
     *
     * FIXES APPLIED (v27):
     *   1. precacheDispatcher — MIN_PRIORITY single thread. Linux scheduler always
     *      gives time slices to higher-priority threads (UI, Glide) first.
     *   2. awaitScrollIdle() before each IO burst — suspends during flings so the
     *      storage bus is fully available to Glide between groups.
     *   3. 30 ms delay between groups — ~2 Choreographer frames of breathing room
     *      for Glide to drain any queued thumbnail reads before the next copy IO.
     *   4. One group at a time (serialised via single precacheDispatcher thread) —
     *      at most 1 file-copy in flight at any moment, never saturates the bus.
     */
    fun preCacheShareUris() {
        preCacheJob?.cancel()
        val isMerge = AppState.currentMode == AppMode.MERGE
        // Stable snapshot — this pass can run for seconds (awaitScrollIdle
        // suspensions + a 30 ms gap per group), during which the user could
        // switch Extract/Merge tabs. Re-reading the live AppState.groups
        // partway through would silently retarget the rest of this pass at
        // the other mode's groups while still using the isMerge/allKey
        // computed for the original mode.
        val groups = AppState.groups.toList()
        if (groups.isEmpty()) return
        val allKey = ShareCacheKey.forLibrary(groups, isMerge)

        preCacheJob = activity.lifecycleScope.launch {
            // ── Step 1: full-library URI cache ────────────────────────────────
            // This is the single largest IO burst: copies every image in all groups.
            // Always wait for the list to be completely idle before starting it.
            if (!shareCacheAll.containsKey(allKey)) {
                uiState.awaitScrollIdle()
                withContext(precacheDispatcher) {
                    runCatching {
                        ImageSaver.buildShareUris(activity, groups, isMerge) {}
                    }.onSuccess { shareCacheAll[allKey] = it }
                }
            }

            // ── Step 2: per-group URI caches, one group at a time ─────────────
            // Process ONE group per IO burst with a 30 ms gap between groups so
            // the storage bus isn't kept busy for the entire precache duration.
            groups.forEach { group ->
                val key = ShareCacheKey.forGroup(group, isMerge)
                if (!shareCacheGroup.containsKey(key)) {
                    // Pause during flings — only run when the storage bus is free.
                    uiState.awaitScrollIdle()

                    withContext(precacheDispatcher) {
                        runCatching {
                            ImageSaver.buildShareUris(activity, listOf(group), isMerge) {}
                        }.onSuccess { shareCacheGroup[key] = it }
                    }

                    // 30 ms = ~2 frames at 60 Hz. Gives Glide time to drain any
                    // thumbnail read requests queued from the last scroll before
                    // the next group's file-copy IO occupies the storage bus.
                    delay(30L)
                }
            }
        }
    }

    /** Called by MainActivity's Reset action — drops all cached share URIs
     *  (they refer to images that no longer exist) and cancels any precache
     *  still in flight for the library being cleared. */
    fun invalidateShareCache() {
        preCacheJob?.cancel()
        shareCacheAll.clear()
        shareCacheGroup.clear()
    }

    // ── Per-chapter share ──────────────────────────────────────────────────────
    fun shareGroup(groupIdx: Int) {
        val group   = AppState.groups.getOrNull(groupIdx) ?: return
        val isMerge = AppState.currentMode == AppMode.MERGE
        val key     = ShareCacheKey.forGroup(group, isMerge)

        shareCacheGroup[key]?.let { ShareIntentLauncher.launch(activity, it); return }

        b.progressArea.visibility = View.VISIBLE
        activity.lifecycleScope.launch(Dispatchers.IO) {
            runCatching {
                ImageSaver.buildShareUris(activity, listOf(group), isMerge) { p ->
                    activity.lifecycleScope.launch(Dispatchers.Main) {
                        b.progressStatus.text  = p.message
                        b.progressBar.progress = p.percent
                    }
                }
            }.onSuccess { uris ->
                shareCacheGroup[key] = uris
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE
                    ShareIntentLauncher.launch(activity, uris)
                }
            }.onFailure { e ->
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE
                    Toast.makeText(activity, "Share failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    // ── Share all ──────────────────────────────────────────────────────────────
    fun startShareAll() {
        val isMerge = AppState.currentMode == AppMode.MERGE
        // Snapshot for the same reason as preCacheShareUris — this suspends
        // across a coroutine dispatch, during which the user could switch modes.
        val groups = AppState.groups.toList()
        if (groups.isEmpty()) return
        val allKey = ShareCacheKey.forLibrary(groups, isMerge)

        shareCacheAll[allKey]?.let { ShareIntentLauncher.launch(activity, it); return }

        b.btnShareDirect.isEnabled = false
        b.progressArea.visibility  = View.VISIBLE
        activity.lifecycleScope.launch(Dispatchers.IO) {
            runCatching {
                ImageSaver.buildShareUris(activity, groups, isMerge) { p ->
                    activity.lifecycleScope.launch(Dispatchers.Main) {
                        b.progressStatus.text = p.message; b.progressBar.progress = p.percent
                    }
                }
            }.onSuccess { uris ->
                shareCacheAll[allKey] = uris
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE; b.btnShareDirect.isEnabled = true
                    ShareIntentLauncher.launch(activity, uris)
                }
            }.onFailure { e ->
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE; b.btnShareDirect.isEnabled = true
                    Toast.makeText(activity, "Failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }
}
