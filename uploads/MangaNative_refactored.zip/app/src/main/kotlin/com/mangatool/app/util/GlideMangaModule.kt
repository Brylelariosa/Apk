package com.mangatool.app.util

import android.content.Context
import com.bumptech.glide.Glide
import com.bumptech.glide.GlideBuilder
import com.bumptech.glide.Registry
import com.bumptech.glide.load.DecodeFormat
import com.bumptech.glide.load.engine.executor.GlideExecutor
import com.bumptech.glide.load.engine.bitmap_recycle.LruBitmapPool
import com.bumptech.glide.load.engine.cache.DiskLruCacheWrapper
import com.bumptech.glide.load.engine.cache.LruResourceCache
import com.bumptech.glide.request.RequestOptions
import java.io.File

/**
 * Custom Glide memory + disk configuration tuned for MangaTool's usage pattern.
 *
 * v25 changes vs v24:
 *
 * 1. DEFAULT_REQUEST_OPTIONS with PREFER_RGB_565:
 *    Any Glide load that does NOT explicitly call .format() will now decode in
 *    RGB_565 (2 bytes/px) instead of ARGB_8888 (4 bytes/px). Most Glide calls
 *    in the adapters DO set .format() explicitly, but this acts as a safety net
 *    for any future code paths that forget.
 *
 *    PERF NOTE: Adapters already pass .format(PREFER_RGB_565) explicitly, so this
 *    setting has zero double-decode cost. It only affects the rare paths that do
 *    not set format (e.g., preview images in AllPhotosActivity, AppPickerAdapter).
 *
 * 2. Disk cache size reduced from default (250 MB) to 48 MB:
 *    The app uses DiskCacheStrategy.NONE for pre-built thumbnails (they are their
 *    own cache) and DiskCacheStrategy.RESOURCE only for the fallback picker path.
 *    The default 250 MB disk cache wastes eMMC space that on low-end devices is
 *    on the same physical NAND as app storage — competing read/write channels.
 *    48 MB holds ~7 000 RESOURCE-cached 200 px thumbnails (48 MB ÷ 7 KB each)
 *    which is far more than any realistic picker import session.
 *
 * 3. Explicit disk cache directory in app's cache partition:
 *    Uses app-private cache dir to guarantee write permission on Android 11+
 *    (SAF restrictions prevent writes to arbitrary external paths). Glide's
 *    default path is also the cache dir, but specifying it explicitly ensures
 *    no regression if Glide changes its default in a future version.
 *
 * ── Memory cache (LruResourceCache) ──────────────────────────────────────────
 * Set to 15% of maxMemory, clamped to [16 MB, 56 MB]:
 *   • 16 MB floor: holds ~200 RGB_565 cover thumbnails — enough for 50 chapters.
 *   • 56 MB ceiling: prevents excessive heap usage on high-RAM devices.
 *   • Budget device (128 MB max heap): 15% × 128 MB = 19 MB — above the 12 MB
 *     active-set estimate for 50 chapters × 3 visible covers × ~80 KB/bitmap.
 *
 * ── Bitmap pool (LruBitmapPool) ───────────────────────────────────────────────
 * Set to 10% of maxMemory, clamped to [8 MB, 32 MB]:
 *   Glide reuses pooled Bitmaps via inBitmap to avoid GC-pressure allocations.
 *   200 px thumbnails are all the same dimensions — very high reuse rate.
 *   8 MB floor holds ~100 pooled RGB_565 slots (enough for a 3-column grid at
 *   any scroll depth). 32 MB ceiling prevents RAM waste on high-end devices.
 */
class GlideMangaModule : com.bumptech.glide.module.GlideModule {

    override fun applyOptions(context: Context, builder: GlideBuilder) {
        val maxMem = Runtime.getRuntime().maxMemory()

        // Memory cache: 15% of max heap, clamped [16 MB, 56 MB]
        val cacheSize = (maxMem * 0.15).toLong()
            .coerceIn(16L * 1024 * 1024, 56L * 1024 * 1024)
        builder.setMemoryCache(LruResourceCache(cacheSize))

        // Bitmap pool: 10% of max heap, clamped [8 MB, 32 MB]
        val poolSize = (maxMem * 0.10).toLong()
            .coerceIn(8L * 1024 * 1024, 32L * 1024 * 1024)
        builder.setBitmapPool(LruBitmapPool(poolSize))

        // ── Disk cache: 48 MB cap in app-private dir ──────────────────────────
        // Default is 250 MB — far more than this app needs. The primary thumbnail
        // path uses DiskCacheStrategy.NONE (thumbnails live as files on disk
        // already). Only the fallback picker path uses RESOURCE caching.
        // 48 MB = ~7 000 cached 7 KB thumbnails — far more than any picker session.
        // Smaller disk cache = less NAND wear on budget devices with limited eMMC.
        val diskCacheDir = File(context.cacheDir, "glide_cache")
        val diskCacheSizeBytes = 48L * 1024 * 1024  // 48 MB
        builder.setDiskCache {
            DiskLruCacheWrapper.create(diskCacheDir, diskCacheSizeBytes)
        }

        // ── Default RGB_565 for any request that omits .format() ──────────────
        // Adapters set .format(PREFER_RGB_565) explicitly. This default covers
        // any future callers that forget — prevents silent ARGB_8888 decodes.
        // For preview-only screens (AllPhotosActivity) that DO want full color,
        // they can override by adding .format(PREFER_ARGB_8888) to their request.
        builder.setDefaultRequestOptions(
            RequestOptions().format(DecodeFormat.PREFER_RGB_565)
        )

        // ── v29: Limit Glide's own decode thread pool ──────────────────────────
        // Glide's default source executor uses Runtime.availableProcessors() threads.
        // On an 8-core device that is 8 simultaneous full-image decodes — combined
        // with ThumbnailWorker's Semaphore(3) still allows 11 concurrent BitmapFactory
        // calls during fast scroll, saturating the storage bus on slow eMMC.
        //
        // Cap at 2 source threads + 1 disk-cache thread.
        // ThumbnailWorker's pre-built thumbnails are tiny (~5–7 KB); Glide can decode
        // 2 simultaneously in <8 ms total. The 3rd permits overlap with ThumbnailWorker.
        // For full-resolution previews (ImagePreviewActivity), the cap still provides
        // 2 parallel source decodes — enough to pre-load the next 2 pages smoothly.
        //
        // UncaughtThrowableStrategy.IGNORE: a single corrupt thumbnail file should not
        // crash the Glide executor thread and kill all remaining thumbnail loads.
        val sourceExecutor = GlideExecutor.newSourceBuilder()
            .setThreadCount(2)
            .setUncaughtThrowableStrategy(GlideExecutor.UncaughtThrowableStrategy.IGNORE)
            .build()
        val diskExecutor = GlideExecutor.newDiskCacheBuilder()
            .setThreadCount(1)
            .setUncaughtThrowableStrategy(GlideExecutor.UncaughtThrowableStrategy.IGNORE)
            .build()
        builder.setSourceExecutor(sourceExecutor)
        builder.setDiskCacheExecutor(diskExecutor)
    }

    override fun registerComponents(context: Context, glide: Glide, registry: Registry) {
        // No custom components needed — default Glide pipeline is sufficient.
    }
}
