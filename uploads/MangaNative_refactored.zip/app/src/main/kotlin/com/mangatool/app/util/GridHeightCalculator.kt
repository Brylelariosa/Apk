package com.mangatool.app.util

/**
 * Computes the fixed pixel height for a chapter card's inner thumbnail grid.
 *
 * `ChapterAdapter` gives each chapter's nested `RecyclerView` grid a fixed
 * height (rather than `wrap_content`) so the outer chapter list's item
 * heights are known up front — this avoids the layout-then-remeasure pass
 * `wrap_content` would otherwise force on every expand/collapse. The two
 * functions below compute that fixed height from the same three inputs
 * every row layout already fixes at design time (row height, column count,
 * and vertical padding), instead of measuring the actual inflated views.
 *
 * Extracted as a pure, dependency-free utility so this arithmetic can be
 * unit-tested without instantiating a `RecyclerView.Adapter` or any Android
 * view.
 */
object GridHeightCalculator {

    /**
     * Height of the main extract/merge thumbnail grid for [itemCount] items.
     *
     * @param isMerge true for the 2-column merge-pair grid (each row taller,
     *   at 156dp, to fit the pair-swap button); false for the 3-column plain
     *   extract grid (134dp/row).
     * @param density the display's `density` (`resources.displayMetrics.density`),
     *   used to convert the dp-based row math to pixels.
     */
    fun computeGridHeightPx(itemCount: Int, isMerge: Boolean, density: Float): Int {
        if (itemCount == 0) return 0
        val cols = if (isMerge) 2 else 3
        val rows = (itemCount + cols - 1) / cols
        val itemHeightDp = if (isMerge) 156 else 134
        val paddingDp = 12 // 6dp top + 6dp bottom
        return ((rows * itemHeightDp + paddingDp) * density + 0.5f).toInt()
    }

    /**
     * Height of the "N filtered — tap to review" strip's 3-column grid for
     * [itemCount] filtered items. Row height (136dp) matches
     * `item_thumb_filtered.xml`'s 130dp image plus its 3dp top/bottom margin.
     */
    fun computeFilteredHeightPx(itemCount: Int, density: Float): Int {
        if (itemCount == 0) return 0
        val rows = (itemCount + 2) / 3 // 3-col filtered grid
        val itemHeightDp = 136
        val paddingDp = 12
        return ((rows * itemHeightDp + paddingDp) * density + 0.5f).toInt()
    }
}
