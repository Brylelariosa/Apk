package com.mangatool.app.util

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import com.mangatool.app.model.ImageItem
import com.mangatool.app.model.MergeDirection

object ImageMerger {

    /**
     * Shared compositing used by both [merge] and [mergeThumbnail] — the two
     * differ only in which decode function and bitmap config they use, not in
     * how the pair is laid out on the canvas.
     *
     * @param direction HORIZONTAL places the pair side by side (left/right);
     *   VERTICAL stacks them top/bottom. In both cases, [swapped] means "show
     *   the second image in the first (top-left) reading position" — the
     *   same meaning regardless of direction, so toggling direction never
     *   changes what a pair's existing swap state means.
     * @param decode the per-image decode function (full-resolution for
     *   [merge], downsampled for [mergeThumbnail]).
     */
    private inline fun composePair(
        pair: List<ImageItem>,
        swapped: Boolean,
        direction: MergeDirection,
        config: Bitmap.Config,
        decode: (String) -> Bitmap?
    ): Bitmap? {
        val bm1 = decode(pair[0].filePath) ?: return null
        val bm2 = if (pair.size > 1) decode(pair[1].filePath) else null

        if (bm2 == null) return bm1

        val (w, h) = when (direction) {
            MergeDirection.HORIZONTAL -> (bm1.width + bm2.width) to maxOf(bm1.height, bm2.height)
            MergeDirection.VERTICAL   -> maxOf(bm1.width, bm2.width) to (bm1.height + bm2.height)
        }
        val result = Bitmap.createBitmap(w, h, config)
        val canvas = Canvas(result)
        canvas.drawColor(Color.WHITE)

        // "swapped" always means "second image goes first" (top-left reading
        // position), independent of direction.
        val first  = if (swapped) bm2 else bm1
        val second = if (swapped) bm1 else bm2

        when (direction) {
            MergeDirection.HORIZONTAL ->
                canvas.drawBitmap(second, first.width.toFloat(), 0f, null)
            MergeDirection.VERTICAL ->
                canvas.drawBitmap(second, 0f, first.height.toFloat(), null)
        }
        canvas.drawBitmap(first, 0f, 0f, null)

        bm1.recycle(); bm2.recycle()
        return result
    }

    /**
     * Merge a pair of images into a single Bitmap at full quality.
     * ARGB_8888 preserves colour accuracy for the lossless PNG output.
     * @param swapped true = second image shown in the first reading position
     * @param direction HORIZONTAL (side by side, default) or VERTICAL (stacked)
     */
    fun merge(
        pair: List<ImageItem>,
        swapped: Boolean = false,
        direction: MergeDirection = MergeDirection.HORIZONTAL
    ): Bitmap? =
        composePair(pair, swapped, direction, Bitmap.Config.ARGB_8888) { BitmapUtils.decodeFull(it) }

    /**
     * Merge thumbnail — reduced size for gallery preview.
     * RGB_565 halves memory; bit-perfect colour doesn't matter at thumb size.
     */
    fun mergeThumbnail(
        pair: List<ImageItem>,
        swapped: Boolean = false,
        maxPx: Int = 400,
        direction: MergeDirection = MergeDirection.HORIZONTAL
    ): Bitmap? =
        composePair(pair, swapped, direction, Bitmap.Config.RGB_565) { BitmapUtils.decodeThumbnail(it, maxPx) }

    /** Split display images into sequential pairs. */
    fun pairImages(images: List<ImageItem>): List<List<ImageItem>> = images.chunked(2)
}
