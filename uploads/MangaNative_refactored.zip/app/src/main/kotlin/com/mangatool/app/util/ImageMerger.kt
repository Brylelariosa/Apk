package com.mangatool.app.util

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import com.mangatool.app.model.ImageItem

object ImageMerger {

    /**
     * Shared side-by-side compositing used by both [merge] and
     * [mergeThumbnail] — the two differ only in which decode function and
     * bitmap config they use, not in how the pair is laid out on the canvas.
     *
     * @param decode the per-image decode function (full-resolution for
     *   [merge], downsampled for [mergeThumbnail]).
     */
    private inline fun composeSideBySide(
        pair: List<ImageItem>,
        swapped: Boolean,
        config: Bitmap.Config,
        decode: (String) -> Bitmap?
    ): Bitmap? {
        val bm1 = decode(pair[0].filePath) ?: return null
        val bm2 = if (pair.size > 1) decode(pair[1].filePath) else null

        if (bm2 == null) return bm1

        val w = bm1.width + bm2.width
        val h = maxOf(bm1.height, bm2.height)
        val result = Bitmap.createBitmap(w, h, config)
        val canvas = Canvas(result)
        canvas.drawColor(Color.WHITE)

        if (swapped) {
            canvas.drawBitmap(bm2, 0f, 0f, null)
            canvas.drawBitmap(bm1, bm2.width.toFloat(), 0f, null)
        } else {
            canvas.drawBitmap(bm1, 0f, 0f, null)
            canvas.drawBitmap(bm2, bm1.width.toFloat(), 0f, null)
        }

        bm1.recycle(); bm2.recycle()
        return result
    }

    /**
     * Merge a pair of images into a single Bitmap at full quality.
     * ARGB_8888 preserves colour accuracy for the lossless PNG output.
     * @param swapped  true = second image shown on left
     */
    fun merge(pair: List<ImageItem>, swapped: Boolean = false): Bitmap? =
        composeSideBySide(pair, swapped, Bitmap.Config.ARGB_8888) { BitmapUtils.decodeFull(it) }

    /**
     * Merge thumbnail — reduced size for gallery preview.
     * RGB_565 halves memory; bit-perfect colour doesn't matter at thumb size.
     */
    fun mergeThumbnail(pair: List<ImageItem>, swapped: Boolean = false, maxPx: Int = 400): Bitmap? =
        composeSideBySide(pair, swapped, Bitmap.Config.RGB_565) { BitmapUtils.decodeThumbnail(it, maxPx) }

    /** Split display images into sequential pairs. */
    fun pairImages(images: List<ImageItem>): List<List<ImageItem>> = images.chunked(2)
}
