package com.mangatool.app.util

/**
 * Computes `BitmapFactory.Options.inSampleSize` for a "coarse decode, then
 * precise bilinear scale" pipeline — the two-pass pattern used everywhere
 * this app produces a downscaled bitmap (manga-page thumbnails, WebP cover
 * generation, preview decoding).
 *
 * The coarse pass exists so `BitmapFactory` never allocates a full-resolution
 * bitmap just to immediately downscale it: `inSampleSize` lets the decoder
 * skip pixels while reading, so the "rough" bitmap is already close to the
 * final size before the precise [android.graphics.Bitmap.createScaledBitmap]
 * pass finishes the job.
 *
 * Two axis strategies are used across the app, kept distinct rather than
 * forced to agree, because each was tuned for a different pipeline:
 *
 *  - [computeMinAxis] (used by [BitmapUtils]' preview/thumbnail decode path):
 *      doubles the sample size only while BOTH the width AND the height
 *      would still decode at or above [targetPx] — i.e. driven by the
 *      SMALLER of the two dimensions. This guarantees neither axis ever
 *      drops below target before the final precise scale, at the cost of a
 *      larger intermediate "rough" bitmap for non-square sources.
 *
 *  - [computeMaxAxis] (used by `MhtmlParser`'s pre-generated WebP thumbnail
 *      path — see its v26 doc comment for the benchmarked rationale): driven
 *      by the LARGER dimension, since the final output is always fit to a
 *      target size on the longest axis. This produces a smaller
 *      intermediate bitmap for non-square sources.
 *
 * Both strategies produce byte-for-byte identical FINAL output for a given
 * source and target, because the eventual precise-scale step always fits
 * the longest axis to the target in both pipelines — only the size of the
 * transient coarse bitmap differs.
 */
object SampleSizeCalculator {

    /**
     * Largest power-of-two sample size such that decoding at `sample * 2`
     * would drop either [width] or [height] below [targetPx].
     * Returns 1 (no downsampling) if the source is already at or below target.
     */
    fun computeMinAxis(width: Int, height: Int, targetPx: Int): Int {
        if (width <= 0 || height <= 0 || targetPx <= 0) return 1
        var sample = 1
        while (width / (sample * 2) >= targetPx && height / (sample * 2) >= targetPx) {
            sample *= 2
        }
        return sample
    }

    /**
     * Largest power-of-two sample size such that decoding at `sample * 2`
     * would drop the longer of [width]/[height] below [targetPx].
     * Returns 1 (no downsampling) if the source is already at or below target.
     */
    fun computeMaxAxis(width: Int, height: Int, targetPx: Int): Int {
        if (width <= 0 || height <= 0 || targetPx <= 0) return 1
        var sample = 1
        while (maxOf(width, height) / (sample * 2) >= targetPx) {
            sample *= 2
        }
        return sample
    }
}
