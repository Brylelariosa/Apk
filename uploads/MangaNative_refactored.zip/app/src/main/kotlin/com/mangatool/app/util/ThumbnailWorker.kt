package com.mangatool.app.util

import com.mangatool.app.MhtmlParser
import kotlinx.coroutines.CoroutineName
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Bounded background thumbnail generator — eliminates full-image fallback decoding.
 *
 * ── THE PROBLEM THIS SOLVES ────────────────────────────────────────────────────
 * When [ImageItem.thumbnailPath] is null (thumbnail generation failed, extraction
 * edge-case, picker import, etc.) the old adapter code fell back to:
 *
 *   Glide.load(File(fullOriginalImage)).override(140)…
 *
 * Loading a 200–500 KB source JPEG to produce a 140 px thumbnail requires:
 *   1. Full BitmapFactory.decodeFile() of the original → ~1–4 MB decoded bitmap
 *   2. createScaledBitmap to 140 px → second allocation
 *   3. Glide encode to RESOURCE cache
 *
 * During a fast scroll with 8–12 blank thumbnails visible simultaneously, this
 * fires 8–12 concurrent full decodes. On low-end devices with slow eMMC this
 * saturates both the storage bus and the CPU decode threads, causing 60–300 ms
 * frame drops and visible RecyclerView jank.
 *
 * ── THE FIX ────────────────────────────────────────────────────────────────────
 * Adapters now call ThumbnailWorker.generate(filePath, onReady) instead of loading
 * the full image. The worker:
 *   1. Shows a lightweight ColorDrawable placeholder immediately (zero IO).
 *   2. Queues the generation job; Semaphore(3) caps concurrent decodes.
 *   3. Derives the thumbnail path from file structure (matches MhtmlParser convention).
 *   4. Fires onReady on Main thread → adapter calls notifyItemChanged → rebind shows thumb.
 *   5. Caches the result; scroll-back is instant (no re-generation).
 *
 * ── THREAD SAFETY ──────────────────────────────────────────────────────────────
 * generate() and getCached() may be called from any thread.
 * onReady callbacks are always dispatched on Main.
 *
 * ── DIRECTORY CONVENTION ───────────────────────────────────────────────────────
 * Thumbnails live at: {sourceFile.parent}/thumbnails/{sourceFile.nameWithoutExtension}.webp
 * This matches MhtmlParser.parse() and MainActivity loose-file import exactly.
 * If the file already exists (from a previous extraction), it is reused as-is.
 */
object ThumbnailWorker {

    // ── Concurrency limits ────────────────────────────────────────────────────

    /**
     * Maximum simultaneous BitmapFactory decode operations.
     *
     * 3 permits leaves the main thread and Glide's own decode pool headroom.
     * At 3 concurrent decodes on typical eMMC:
     *   • Each decode: ~15–40 ms for a 300 KB JPEG thumbnail
     *   • 3 parallel: ~50–120 ms total, well within a scroll pause
     *   • Without limit: 12+ concurrent on fast scroll → 300–600 ms stalls
     */
    private val semaphore = Semaphore(permits = 3)

    /**
     * Background scope. SupervisorJob: one failed generate() does not cancel siblings.
     * CoroutineName: visible in profiler traces.
     */
    private val scope = CoroutineScope(
        Dispatchers.Default + SupervisorJob() + CoroutineName("ThumbnailWorker")
    )

    // ── State ─────────────────────────────────────────────────────────────────

    /** filePath → generated thumbnailPath. Cleared on full app reset. */
    private val pathCache = ConcurrentHashMap<String, String>()

    /**
     * filePath → pending callbacks.
     *
     * Presence of a key means a job is queued or running.
     * CopyOnWriteArrayList: safe concurrent add from bind callbacks while the
     * job is completing on Default dispatcher.
     *
     * putIfAbsent atomicity: only the thread that creates the entry launches
     * the coroutine. All subsequent callers just append their callback.
     */
    private val inFlight = ConcurrentHashMap<String, CopyOnWriteArrayList<(String?) -> Unit>>()

    // ── Public API ────────────────────────────────────────────────────────────

    /**
     * Return the cached thumbnail path for [filePath], or null if not yet generated.
     *
     * Called during adapter bind to check ThumbnailWorker's generated-path cache
     * BEFORE deciding to show a placeholder. This covers the case where:
     *   • thumbnailPath was null at ImageItem creation time (generation failed)
     *   • ThumbnailWorker already generated it for a previous bind of this item
     *   → second bind skips the placeholder and shows the thumbnail immediately
     *
     * Safe to call on any thread.
     */
    fun getCached(filePath: String): String? = pathCache[filePath]

    /**
     * Generate a thumbnail for [filePath] in the background.
     *
     * Deduplication:
     *   • Already cached  → [onReady] invoked immediately on the calling thread.
     *   • Already in-flight → [onReady] appended to the callback list; no new coroutine.
     *   • New request     → new coroutine launched, bounded by Semaphore.
     *
     * [onReady] receives:
     *   • A non-null String (the thumbnail path) on success.
     *   • null on failure (disk error, corrupt source, OOM in BitmapFactory).
     *   Adapters should call notifyItemChanged only on non-null results.
     *
     * Safe to call on any thread (including RecyclerView onBindViewHolder on Main).
     */
    fun generate(filePath: String, onReady: ((String?) -> Unit)? = null) {
        // ── Fast path: already generated this session ──────────────────────────
        val cached = pathCache[filePath]
        if (cached != null) {
            onReady?.invoke(cached)
            return
        }

        // ── putIfAbsent: atomically determine if WE should launch the job ──────
        // If putIfAbsent returns null → we created the entry → we are the launcher.
        // If it returns the existing list → another caller already launched → append callback only.
        val existing = inFlight.putIfAbsent(filePath, CopyOnWriteArrayList())
        val callbacks = existing ?: inFlight[filePath] ?: return
        if (onReady != null) callbacks.add(onReady)

        if (existing != null) return  // already in-flight; callback registered above

        // ── Launch new generation job ──────────────────────────────────────────
        scope.launch {
            semaphore.withPermit {
                val result = withContext(Dispatchers.IO) {
                    runCatching { generateThumb(filePath) }.getOrNull()
                }

                if (result != null) pathCache[filePath] = result

                // Remove from inFlight BEFORE dispatching callbacks.
                // If a callback calls generate() again for the same path,
                // it will find the entry in pathCache (if success) or start fresh.
                val cbs = inFlight.remove(filePath) ?: return@withPermit
                withContext(Dispatchers.Main) {
                    cbs.forEach { cb -> cb(result) }
                }
            }
        }
    }

    /**
     * Pre-generate thumbnails for items around the scroll position.
     *
     * Called by ChapterAdapter when a chapter row becomes visible, to warm up
     * thumbnails for the next [count] non-null-thumbnail items starting at [startIdx].
     *
     * Low overhead: generate() short-circuits on already-cached or in-flight items.
     * No callback registered — fire-and-forget; the next onBindViewHolder will
     * hit the getCached() fast path.
     */
    fun prefetch(filePaths: List<String>, startIdx: Int, count: Int) {
        val end = (startIdx + count).coerceAtMost(filePaths.size)
        for (i in startIdx until end) {
            generate(filePaths[i])  // no callback — fire and forget
        }
    }

    /**
     * Clear the session path cache.
     *
     * Call alongside AppState.resetAll() when the user clears all chapters.
     * In-flight jobs are NOT cancelled — they complete harmlessly (their
     * generated files will be deleted by imgCacheDir.deleteRecursively() in resetAll).
     *
     * inFlight is cleared too, not just pathCache — clearing the map doesn't
     * cancel an already-running job (its captured callback list keeps working
     * fine regardless), but it does stop a *new* generate() call for the same
     * path from finding the old, effectively-abandoned entry and just
     * appending to it instead of starting a fresh generation.
     */
    fun clearCache() { pathCache.clear(); inFlight.clear() }

    // ── Private helpers ───────────────────────────────────────────────────────

    /**
     * Generate a thumbnail, reusing an existing file if already on disk.
     *
     * Directory convention (matches MhtmlParser.parse() and MainActivity import):
     *   source:    {dir}/00000001.jpg
     *   thumbnail: {dir}/thumbnails/00000001.webp
     *
     * If the thumbnail file already exists and is non-empty, its path is returned
     * immediately without re-generating. This handles the case where:
     *   • MhtmlParser generated the thumbnail but thumbnailPath was lost (e.g.
     *     ImageItem was reconstructed from a re-import of the same source).
     *   • ThumbnailWorker generated it in a previous session (before clearCache).
     */
    private fun generateThumb(filePath: String): String? {
        val srcFile   = File(filePath)
        val parentDir = srcFile.parent ?: return null
        val thumbDir  = File(parentDir, "thumbnails").also { it.mkdirs() }
        val thumbFile = File(thumbDir, "${srcFile.nameWithoutExtension}.webp")

        // Reuse existing file — avoids redundant BitmapFactory work
        if (thumbFile.exists() && thumbFile.length() > 0L) return thumbFile.absolutePath

        return MhtmlParser.generateThumbnail(filePath, thumbFile)
    }
}
