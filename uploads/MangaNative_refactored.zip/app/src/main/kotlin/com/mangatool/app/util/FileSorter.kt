package com.mangatool.app.util

import java.io.File

/**
 * Sort field for a directory listing in the built-in file browser
 * (`InternalFileManagerActivity`). Persisted by name via `Prefs.fileSortBy`
 * so the user's choice survives the next time the browser is opened.
 */
enum class FileSortBy { NAME, DATE, TYPE }

/**
 * Sorts a directory's file listing.
 *
 * Extracted out of `InternalFileManagerActivity` as a pure, dependency-free
 * function so the sort behavior — including the ascending/descending flip —
 * can be unit tested against real temp files without instantiating an
 * Activity.
 */
object FileSorter {

    fun sort(files: List<File>, sortBy: FileSortBy, ascending: Boolean): List<File> {
        val comparator: Comparator<File> = when (sortBy) {
            FileSortBy.NAME -> compareBy { it.name.lowercase() }
            FileSortBy.DATE -> compareBy { it.lastModified() }
            FileSortBy.TYPE -> compareBy { it.extension.lowercase() }
        }
        return if (ascending) files.sortedWith(comparator) else files.sortedWith(comparator.reversed())
    }
}
