package com.mangatool.app.adapter

import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.mangatool.app.R
import com.mangatool.app.model.ImageItem
import com.mangatool.app.util.ThumbnailGlideLoader

/**
 * Grid adapter for a chapter's "N filtered — tap to review" strip: the
 * pages [com.mangatool.app.AppState]'s filters (min dimensions, user
 * delete) have hidden from the main grid, shown here so the user can
 * preview or restore them individually.
 *
 * Extracted out of `ChapterAdapter.kt` — it was already a self-contained
 * `RecyclerView.Adapter` sharing no state with the outer chapter adapter
 * beyond the callbacks passed into its constructor, so giving it its own
 * file has no behavioral effect; it just makes both files smaller and lets
 * this one be read/tested independently of the 900-line outer adapter.
 */
class FilteredThumbAdapter(
    initialItems: List<ImageItem>,
    // PERF: val — set once at adapter creation in attachFilteredGrid, never reassigned.
    val onPreview: (Int) -> Unit,
    private val onRestore: (ImageItem) -> Unit
) : RecyclerView.Adapter<FilteredThumbAdapter.VH>() {

    companion object {
        // Filtered images are stable by originalIdx; content changes when filterReason
        // or filePath changes (edge case: restore-then-re-filter).
        val ITEM_CALLBACK = object : DiffUtil.ItemCallback<ImageItem>() {
            override fun areItemsTheSame(o: ImageItem, n: ImageItem) =
                o.originalIdx == n.originalIdx
            override fun areContentsTheSame(o: ImageItem, n: ImageItem) =
                o.filePath == n.filePath && o.filterReason == n.filterReason
        }
    }

    private val differ = AsyncListDiffer(this, ITEM_CALLBACK)
    private val items: List<ImageItem> get() = differ.currentList

    // ── Flicker fix: batch thumbnail-ready notifications ───────────────────────
    // ROOT CAUSE: ThumbnailWorker.generate() runs up to 3 concurrent decodes
    // (Semaphore(3)). Each completion used to call notifyItemChanged(pos)
    // immediately and individually. For a chapter with e.g. 18 filtered images,
    // that's up to 18 separate rebind passes arriving in rapid, uneven bursts
    // right as the filtered grid is expanded — each one re-triggering layout on
    // the fixed-height filtered RecyclerView, which reads as the whole "N
    // filtered — tap to review" strip flickering/re-rendering repeatedly.
    // FIX: same batching already used by ImageThumbAdapter.scheduleThumbNotify —
    // collect ready positions for 60 ms, then flush once. Mirrors that fix 1:1.
    private val pendingPositions   = mutableSetOf<Int>()
    private val notifyHandler      = Handler(Looper.getMainLooper())
    private val notifyRunnable     = Runnable {
        if (pendingPositions.isEmpty()) return@Runnable
        val copy = pendingPositions.toList()
        pendingPositions.clear()
        copy.forEach { pos -> notifyItemChanged(pos) }
    }
    private fun scheduleNotify(pos: Int) {
        pendingPositions.add(pos)
        notifyHandler.removeCallbacks(notifyRunnable)
        notifyHandler.postDelayed(notifyRunnable, 60L)
    }

    init {
        // Stable IDs let RecyclerView skip full rebind when only unrelated data
        // changes — same benefit as in ImageThumbAdapter. Uses originalIdx (assigned
        // once at parse time) as the stable ID, which is unique within each group.
        setHasStableIds(true)
        differ.submitList(initialItems)
    }

    override fun getItemId(position: Int): Long =
        items.getOrNull(position)?.originalIdx?.toLong() ?: position.toLong()

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val image:   ImageView = v.findViewById(R.id.thumb_image)
        val reason:  TextView  = v.findViewById(R.id.reason_text)
        val restore: View      = v.findViewById(R.id.btn_restore)
        // No Job — Glide manages lifecycle
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_thumb_filtered, parent, false)
        val holder = VH(v)

        // ── PERF: Click listeners registered ONCE at VH creation ──────────────
        // BEFORE (v26): onBindViewHolder registered new lambdas (itemView,
        // restore) on EVERY bind — allocating objects × N filtered
        // items × M filter passes. For a library with 5 chapters × 8 filtered
        // images × 3 filter changes = 120 lambda allocations in one interaction,
        // adding GC pressure at the moment the adapter is refreshing.
        //
        // AFTER (v27): zero allocations in onBindViewHolder. The restore listener
        // reads items[bindingAdapterPosition] at click time — safe because
        // bindingAdapterPosition always reflects the current differ state.
        holder.itemView.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) onPreview(pos)
        }
        holder.restore.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) onRestore(items[pos])
        }

        return holder
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val img = items[position]
        holder.reason.text = img.filterReason ?: "Filtered"

        // Loads the pre-built thumbnail (or queues background generation +
        // placeholder) instead of ever decoding the full original image —
        // see ThumbnailGlideLoader's doc comment for the full rationale.
        val originalIdx = img.originalIdx
        ThumbnailGlideLoader.load(
            holder.image, Glide.with(holder.itemView), img.thumbnailPath, img.filePath
        ) {
            val pos = items.indexOfFirst { it.originalIdx == originalIdx }
            if (pos >= 0) scheduleNotify(pos)
        }
        // Click listeners registered once in onCreateViewHolder — no allocations here.
    }

    /**
     * Submit updated filtered list to AsyncListDiffer.
     * Only items whose filterReason or filePath changed will rebind —
     * a restore action on item N no longer forces all other filtered
     * thumbnails to re-issue their Glide requests.
     */
    fun refreshItems(newItems: List<ImageItem>) = differ.submitList(newItems)

    override fun onViewRecycled(holder: VH) {
        Glide.with(holder.itemView).clear(holder.image)
        super.onViewRecycled(holder)
    }

    /** Cancels any pending batched notify — Glide itself needs no cleanup. */
    fun destroy() {
        notifyHandler.removeCallbacks(notifyRunnable)
        pendingPositions.clear()
    }
}
