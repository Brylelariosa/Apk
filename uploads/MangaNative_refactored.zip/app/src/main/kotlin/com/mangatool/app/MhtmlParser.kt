package com.mangatool.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.util.Base64
import com.mangatool.app.model.ImageGroup
import com.mangatool.app.model.ImageItem
import java.io.BufferedOutputStream
import java.io.BufferedReader
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.withContext

/**
 * Exposes ByteArrayOutputStream's internal backing array without copying it.
 * [buf] is only valid for indices [0, size()) — same invariant the
 * superclass already documents for its own protected fields — so always
 * pair it with [size], never assume the whole array is meaningful.
 * Used to feed Base64.decode() directly instead of calling toByteArray(),
 * which would copy the same bytes into a new right-sized array first.
 */
private class DirectByteArrayOutputStream(initialCapacity: Int) : ByteArrayOutputStream(initialCapacity) {
    val backingArray: ByteArray get() = buf
}

object MhtmlParser {

    /**
     * Thumbnail target size (px, longest axis) — single source of truth.
     *
     * Referenced by every adapter that displays a pre-generated thumbnail
     * (ImageThumbAdapter, ChapterAdapter's cover + FilteredThumbAdapter) so
     * the decode target and the Glide `.override()` request size can never
     * drift apart. See the v26 docstring below for why this is 200, not 140.
     */
    internal const val THUMBNAIL_TARGET_PX = 200

    // Caps concurrent thumbnail generation (CPU-bound decode/scale/WebP-encode)
    // across ALL parse() calls, not just within one file — bounds total
    // system-wide bitmap work the same way FileManager.extractLimiter bounds
    // concurrent file extraction. Shared at the object level since up to 2
    // files can be extracting concurrently (extractLimiter = Semaphore(2)),
    // each launching its own per-image thumbnail jobs.
    private val thumbnailLimiter = Semaphore(2)

    /**
     * Stream-parse an MHTML file into an ImageGroup without loading the whole
     * file into RAM.
     *
     * ── Memory model ──────────────────────────────────────────────────────────
     * v16: used StringBuilder bodyBuf, accumulating every part body as text.
     *   For a 200 KB image base64-encoded to ~270 KB of ASCII, the old path
     *   allocated: StringBuilder (~270 KB) → toString() String (~270 KB) →
     *   toByteArray(ISO_8859_1) (~270 KB) → Base64.decode() result (~200 KB).
     *   Peak per image ≈ 810 KB. Non-image parts (HTML, CSS) were also fully
     *   accumulated even though they were always discarded.
     *
     * v19 improvements:
     *   1. Headers are parsed FIRST. Non-image parts skip body accumulation
     *      entirely — only the boundary-scan loop runs, zero allocation.
     *   2. Image bodies accumulate into a ByteArrayOutputStream pre-sized to
     *      128 KB. No intermediate String. Single toByteArray() call feeds
     *      Base64.decode() directly.
     *      Peak per image ≈ ~270 KB (stream buffer) + ~200 KB (decoded) = ~470 KB.
     *      Saves ~340 KB of intermediate allocation per image.
     *   3. onProgress is throttled to fire every 5 images — eliminates rapid
     *      main-thread post() spam on chapters with many pages.
     *
     * v21 thumbnail generation:
     *   Immediately after writing each extracted image file, a 140 px WebP
     *   thumbnail is generated in a sibling "thumbnails/" directory.
     *   - inSampleSize adaptive (bounds check first) instead of hardcoded 8.
     *   - RGB_565 (2 bytes/px) instead of ARGB_8888 (4 bytes/px) for the
     *     thumbnail bitmap — halves peak memory.
     *   - WEBP_LOSSY (API 30+) / WEBP fallback (API 24-29) quality 65
     *     produces files ≈ 3–6 KB. WebP decodes faster than JPEG at this size.
     *   - bitmap.recycle() immediately after compress — pixel buffer returned
     *     to native heap before the next image begins.
     *
     * v22 extraction performance:
     *   1. BufferedInputStream (64 KB) wraps the raw ContentResolver stream.
     *   2. onProgress throttled every 10 images.
     *
     * v24 generateThumbnail fix:
     *   - WEBP_LOSSY requires API 30. minSdk is 24, so API 24-29 devices
     *     crashed with NoSuchFieldError. Fixed with Build.VERSION check.
     *   - inSampleSize is now adaptive (bounds decode first) instead of
     *     hardcoded 8. A hardcoded 8 on a 100×120 source image produced a
     *     12×15 px thumbnail, which compressed to a nearly-useless 1 KB WebP.
     *     The new code targets 280 px coarse then scales to exactly 140 px.
     *
     * v25 extraction/thumbnail decoupling (profiled before changing anything —
     * see the perf-analysis writeup for the benchmark methodology and numbers):
     *   1. Base64 decode reads directly from bodyStream's backing array
     *      (DirectByteArrayOutputStream) instead of bodyStream.toByteArray(),
     *      which allocated and copied the full base64 ASCII buffer (~35%
     *      larger than the decoded image) just to discard it after one
     *      decode call. Byte-for-byte identical decoded output.
     *   2. generateThumbnail() used to run synchronously, in-line, before
     *      the loop could advance to the next MIME part — meaning every
     *      image paid for BitmapFactory.decodeFile() re-reading the file
     *      we'd just written, TWICE (bounds pass + coarse pass), fully
     *      serialized with the next image's text-parse + base64-decode.
     *      It's now launched via async() so the main loop advances
     *      immediately; a new generateThumbnail(ByteArray, File) overload
     *      decodes from the bytes already held in memory instead of
     *      re-reading the file, so the two disk reads are eliminated
     *      entirely rather than just moved off the critical path.
     *   3. thumbnailLimiter (Semaphore(2)) is acquired in the main loop
     *      BEFORE launching each thumbnail job — not inside it — so the
     *      loop itself pauses once 2 thumbnails are in flight instead of
     *      racing ahead and holding an unbounded number of images' decoded
     *      bytes in memory while their thumbnails wait their turn. Peak
     *      memory stays bounded to ~2 images' worth of extra data.
     *   4. All thumbnail jobs are awaited at the end of parse(), before it
     *      returns — every ImageItem.thumbnailPath is fully resolved by
     *      the time callers see the result, exactly as before. Extraction
     *      order (sortKey), image bytes/quality, and the returned data are
     *      byte-for-byte unchanged — only the CPU/IO schedule used to
     *      produce them changed.
     *
     * v26 thumbnail resolution fix — 140 px was the real quality bottleneck
     * (profiled before changing anything; see docs/perf-benchmarks/Bench4ThumbnailSize.py
     * for the full methodology, which uses real libwebp encoding and a real
     * variance-of-Laplacian sharpness metric, not modeled numbers):
     *
     *   ROOT CAUSE: item_thumb.xml renders each grid cell at 130dp tall in a
     *   3-column layout. On real device densities that's ≈256×260px (xhdpi,
     *   2x) to ≈384×390px (xxhdpi, 3x) of actual screen pixels — 1.9x to
     *   4.1x larger than a 140 px thumbnail. ImageView's centerCrop upscales
     *   the tiny thumbnail to fill that box, and that upscale — not the
     *   WEBP_LOSSY quality=65 setting — is what reads as blur. No amount of
     *   compression-quality tuning can fix a resolution problem downstream
     *   of the encode.
     *
     *   MEASURED (synthetic manga-style test pages: halftone screentone,
     *   panel borders, dense text blocks — the actual aliasing-prone content
     *   this pipeline handles): thumbnails were decoded, WebP-encoded, then
     *   decoded back and upscaled to the real on-screen cell size exactly as
     *   ImageThumbAdapter/Glide do, and compared by variance-of-Laplacian
     *   against a theoretical "direct source→cell" sharpness ceiling.
     *
     *     size    xhdpi cell sharpness    xxhdpi cell sharpness   file size
     *     140 px  1.1% of ceiling         0.1% of ceiling         ~1.5 KB
     *     200 px  18.5% of ceiling        2.2% of ceiling         ~4.9 KB
     *     256 px  19.9% of ceiling        2.7% of ceiling         ~6.9 KB
     *
     *   200 px recovers ~16x more sharpness than 140 px. Beyond 200 px,
     *   returns diminish sharply (200→256 is only another ~1.05-1.2x) for
     *   1.6x the file size — not worth the extra decode/memory/disk cost.
     *   200 px is therefore the smallest size that gives a visible
     *   improvement, per the analysis' own diminishing-returns curve.
     *
     *   ROBUSTNESS ACROSS SOURCE SIZES: adaptiveSampleSize's coarse pass
     *   (targetCoarse = 2× THUMBNAIL_TARGET_PX) was checked analytically
     *   across realistic source resolutions (800–4000 px longest axis).
     *   200 px NEVER gets less coarse-decode headroom than 140 px did at
     *   any of those sizes — only equal or more — so this isn't a fit to
     *   one test image set.
     *
     *   COST: measured resize+WebP-encode time increased by only ~3-4 ms
     *   per thumbnail (still well inside the 4-10 ms/thumbnail range
     *   Bench3Pipeline.java already proved stays fully hidden behind the
     *   overlapped extraction design above — thumbnailLimiter = Semaphore(2)
     *   means this can only ever add a bounded few-ms tail latency at the
     *   very end of parse(), not per-image stalls). Peak transient RGB_565
     *   "rough" bitmap memory grows by at most ~1.6 MB total across both
     *   Semaphore(2) permits in the worst case — negligible.
     *
     *   UNCHANGED: WEBP_LOSSY quality stays 65 (resolution was the actual
     *   lever, not compression — increasing quality alone would not have
     *   fixed the upscale problem above). Adaptive sampling, bilinear
     *   filtering, and the coarse→precise two-pass decode shape are all
     *   preserved exactly — only THUMBNAIL_TARGET_PX changed, and every
     *   consumer (ImageThumbAdapter, ChapterAdapter cover, FilteredThumbAdapter)
     *   now reads that single constant instead of duplicating "140".
     */
    suspend fun parse(
        stream: InputStream,
        filename: String,
        tempDir: File,
        onProgress: ((done: Int) -> Unit)? = null
    ): ImageGroup? = withContext(Dispatchers.IO) {
        try {
            val reader = java.io.BufferedInputStream(stream, 65_536)
                .bufferedReader(Charsets.ISO_8859_1)

            // ── 1-2. Detect the MIME boundary and skip to its first line ────
            val boundary = detectBoundary(reader) ?: return@withContext null
            var line: String? = boundary.firstBoundaryLine

            // Thumbnail directory is INSIDE tempDir (not beside it).
            // Each extraction gets its own unique tempDir, so concurrent
            // extractions never clobber each other's thumbnail files.
            val thumbDir = File(tempDir, "thumbnails")
            thumbDir.mkdirs()

            data class Extracted(
                val sortKey: String,
                val filePath: String,
                val size: Int,
                val ext: String,
                val thumbJob: Deferred<String?>
            )
            val extracted = mutableListOf<Extracted>()
            var partIdx = 0

            tempDir.mkdirs()

            val bodyStream = DirectByteArrayOutputStream(128 * 1024)

            // ── 3. State machine: boundary → headers → body → boundary ──────
            // ensureActive(): this loop is otherwise 100% synchronous IO/CPU
            // with no suspension points, so a cancelled processingJob (e.g. the
            // user starts a new import while an old one is still extracting)
            // would previously keep decoding/writing images for an already-
            // abandoned request until the whole file finished. Checking once
            // per MIME part gives the same per-image granularity as the
            // existing onProgress throttling, at effectively zero cost.
            while (line != null && !line.startsWith(boundary.closingMarker)) {
                ensureActive()

                val headStr   = readPartHeaders(reader)
                val typeMatch = CONTENT_TYPE_RE.find(headStr)
                val encoding  = ENCODING_RE.find(headStr)?.groupValues?.get(1)?.lowercase()

                // Some CDNs (e.g. image-cloaking hosts used by manga sites)
                // serve real image bytes under a generic
                // "Content-Type: application/octet-stream" header to defeat
                // naive hotlink/scrape detection. Relying on the declared
                // header alone silently drops these parts. Any base64 part
                // is a binary candidate — decode it and sniff the magic
                // bytes to find out what it actually is instead of trusting
                // the header.
                val hasImageTypeHeader = typeMatch != null
                val isBinaryCandidate  = hasImageTypeHeader || encoding == "base64"

                if (isBinaryCandidate) {
                    bodyStream.reset()
                    line = consumeUntilBoundary(reader, boundary.marker) {
                        bodyStream.write(it.toByteArray(Charsets.ISO_8859_1))
                    }

                    val bytes = decodeBinaryBody(encoding, hasImageTypeHeader, bodyStream)
                    val ext   = resolveImageExtension(typeMatch, bytes)

                    if (bytes != null && ext != null && bytes.size > 100) {
                        val sortKey = partIdx.toString().padStart(8, '0')
                        val file    = File(tempDir, "$sortKey.$ext")
                        BufferedOutputStream(FileOutputStream(file)).use { it.write(bytes) }

                        // Decoupled thumbnail generation (see v25 docstring above for
                        // the full rationale). thumbnailLimiter.acquire() happens HERE,
                        // in the main loop, before launching — not inside the async
                        // body — so the loop itself pauses once 2 thumbnails are in
                        // flight, instead of racing ahead and holding an unbounded
                        // number of images' decoded bytes in memory while their
                        // thumbnails wait their turn.
                        val thumbFile = File(thumbDir, "$sortKey.webp")
                        thumbnailLimiter.acquire()
                        val thumbJob: Deferred<String?> = async {
                            try { generateThumbnail(bytes, thumbFile) }
                            finally { thumbnailLimiter.release() }
                        }

                        extracted += Extracted(sortKey, file.absolutePath, bytes.size, ext, thumbJob)

                        if (extracted.size % 10 == 0) {
                            onProgress?.invoke(extracted.size)
                        }
                    }

                } else {
                    line = consumeUntilBoundary(reader, boundary.marker)
                }

                partIdx++
            }

            if (extracted.isNotEmpty()) onProgress?.invoke(extracted.size)

            if (extracted.isEmpty()) return@withContext null

            extracted.sortBy { it.sortKey }
            val images = extracted.mapIndexed { i, r ->
                ImageItem(
                    originalIdx   = i,
                    filePath      = r.filePath,
                    ext           = r.ext,
                    size          = r.size,
                    // Awaits this image's thumbnail job if it hasn't finished yet —
                    // by this point most have already completed in the background
                    // while later images were being parsed, so this rarely blocks.
                    thumbnailPath = r.thumbJob.await()
                )
            }
            ImageGroup(groupName = smartRename(filename)).also { g -> g.allImages.addAll(images) }

        } catch (e: java.util.concurrent.CancellationException) {
            throw e // cancellation must propagate — never treat it as "parsed to null"
        } catch (_: Exception) { null }
    }

    /** Result of scanning an MHTML stream for its MIME boundary declaration. */
    private data class BoundaryInfo(
        val marker: String,
        val closingMarker: String,
        val firstBoundaryLine: String?
    )

    /**
     * Reads forward from [reader] until it finds a `boundary=` parameter on
     * some header line (typically the top-level Content-Type), then keeps
     * reading until the first line that actually starts with that boundary
     * marker.
     *
     * Returns null if the stream ends before any boundary is found — not a
     * valid MHTML file. On success, [BoundaryInfo.firstBoundaryLine] is
     * already-read line that starts the first MIME part, so `parse()`'s
     * state-machine loop can continue from it directly without skipping or
     * re-reading anything.
     */
    private fun detectBoundary(reader: BufferedReader): BoundaryInfo? {
        var boundary: String? = null
        var line: String? = reader.readLine()
        while (line != null && boundary == null) {
            boundary = BOUNDARY_RE.find(line)?.groupValues?.get(1)
            if (boundary == null) line = reader.readLine()
        }
        if (boundary == null) return null

        val marker = "--$boundary"
        val closingMarker = "--$boundary--"
        while (line != null && !line.startsWith(marker)) {
            line = reader.readLine()
        }
        return BoundaryInfo(marker, closingMarker, line)
    }

    /**
     * Reads and concatenates one MIME part's header block — every line up to
     * the first blank line. The line that ends the block (blank, or null at
     * EOF) is intentionally not returned: the caller always issues a fresh
     * `readLine()` immediately afterward to start consuming the part's body,
     * so that line is never inspected again.
     */
    private fun readPartHeaders(reader: BufferedReader): String {
        val headers = StringBuilder()
        var line = reader.readLine()
        while (line != null && line.isNotBlank()) {
            headers.append(line).append('\n')
            line = reader.readLine()
        }
        return headers.toString()
    }

    /**
     * Reads lines from [reader] until one starts with [marker] (or EOF),
     * passing each consumed line to [onLine] first. Returns the terminating
     * line itself — the one starting with [marker], or null at EOF — which
     * becomes the caller's next `line` value, so the state-machine loop's
     * boundary/closing-marker check sees exactly the line that stopped this
     * scan.
     *
     * Shared by both branches of `parse()`'s per-part handling: an image
     * part passes an [onLine] that accumulates bytes into `bodyStream`, and
     * a non-image part passes nothing and simply skips forward — the two
     * were previously identical copy-pasted loops differing only in that one
     * line.
     */
    private inline fun consumeUntilBoundary(
        reader: BufferedReader,
        marker: String,
        onLine: (String) -> Unit = {}
    ): String? {
        var line = reader.readLine()
        while (line != null && !line.startsWith(marker)) {
            onLine(line)
            line = reader.readLine()
        }
        return line
    }

    /**
     * Decodes an MHTML part's accumulated body bytes according to its
     * declared Content-Transfer-Encoding.
     *
     * @param encoding lowercased Content-Transfer-Encoding value, or null if
     *   the part didn't declare one.
     * @param hasImageTypeHeader true if the part had an explicit
     *   "Content-Type: image/…" header — required before treating a
     *   quoted-printable or unencoded body as image bytes, since MHTML also
     *   carries non-image parts (HTML, CSS, JS) using those same encodings.
     */
    private fun decodeBinaryBody(
        encoding: String?,
        hasImageTypeHeader: Boolean,
        bodyStream: DirectByteArrayOutputStream
    ): ByteArray? = when (encoding) {
        "base64" -> try {
            // Decode straight from bodyStream's backing array — see
            // DirectByteArrayOutputStream. Byte-for-byte identical output to
            // Base64.decode(bodyStream.toByteArray(), ...); only the
            // redundant intermediate copy is removed.
            Base64.decode(bodyStream.backingArray, 0, bodyStream.size(), Base64.DEFAULT)
        } catch (_: Exception) { null }

        "quoted-printable" ->
            if (hasImageTypeHeader)
                decodeQP(bodyStream.toString("ISO-8859-1")).toByteArray(Charsets.ISO_8859_1)
            else null // text-ish encoding + no image header -> not an image part

        else -> if (hasImageTypeHeader) bodyStream.toByteArray() else null
    }

    /**
     * Determines a decoded part's real image extension. Trusts an explicit
     * "image/xxx" Content-Type header if present; otherwise sniffs the
     * decoded bytes' magic number — this is what recovers pages mislabeled
     * as application/octet-stream (see [sniffImageExt]).
     */
    private fun resolveImageExtension(typeMatch: MatchResult?, bytes: ByteArray?): String? {
        if (typeMatch != null) {
            val rawExt = typeMatch.groupValues[1].lowercase()
            return if (rawExt == "jpeg") "jpg" else rawExt
        }
        return bytes?.let { sniffImageExt(it) }
    }

    // ── Thumbnail generation ──────────────────────────────────────────────────

    /**
     * Generate a THUMBNAIL_TARGET_PX WebP lossy thumbnail from [imagePath] and write it to [thumbFile].
     *
     * v24 changes vs v21:
     *
     * 1. API crash fix — WEBP_LOSSY (added in API 30):
     *    The previous code called `Bitmap.CompressFormat.WEBP_LOSSY` unconditionally.
     *    minSdk is 24, so devices running Android 7–10 (API 24–29) crashed with
     *    `NoSuchFieldError: WEBP_LOSSY` at extraction time.
     *    Fix: `if (Build.VERSION.SDK_INT >= 30)` selects WEBP_LOSSY; the pre-30
     *    path uses the deprecated `WEBP` constant (available since API 17) which is
     *    identical at quality < 100 (always lossy in that range).
     *
     * 2. Adaptive inSampleSize (was hardcoded to 8):
     *    A fixed inSampleSize=8 decodes at 1/8 resolution regardless of the source
     *    dimensions. For a small source image (e.g. 100×120 px header image) this
     *    produces a 12×15 px bitmap — far below the thumbnail target. The resulting
     *    WebP is correct but nearly useless as a thumbnail (blurry, extremely small).
     *    For very large images (4000×6000 px retina scans), inSampleSize=8 gives
     *    500×750 px — larger than needed, wasting RAM per thumbnail.
     *
     *    New approach (mirrors BitmapUtils.decodeThumbnail):
     *    a) Decode bounds without loading pixels (inJustDecodeBounds).
     *    b) Validate that the source has nonzero dimensions (skips 0-byte parts).
     *    c) Double inSampleSize until the coarse decode is ≥ 2× THUMBNAIL_TARGET_PX
     *       on the longest axis, ensuring the post-scale is always a gentle
     *       downscale, never an upscale.
     *    d) createScaledBitmap to exactly THUMBNAIL_TARGET_PX. Bilinear filter
     *       (true) gives visually clean edges compared to nearest-neighbour.
     *    e) Immediately recycle the intermediate rough bitmap if a new one was made.
     *
     * Returns the absolute path of the written thumbnail, or null on any failure.
     * A null result is handled gracefully in the adapter (falls back to filePath).
     */
    internal fun generateThumbnail(imagePath: String, thumbFile: File): String? {
        return try {
            // ── Step 1: decode bounds without pixel data ──────────────────────
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(imagePath, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

            val sample = com.mangatool.app.util.SampleSizeCalculator.computeMaxAxis(
                bounds.outWidth, bounds.outHeight, THUMBNAIL_TARGET_PX * 2
            )

            // ── Step 3: coarse decode with RGB_565 ────────────────────────────
            // RGB_565 = 2 bytes/pixel vs ARGB_8888 = 4 bytes/pixel.
            // Manga pages are JPEGs with no alpha — identical visual quality at
            // thumbnail sizes. Halves the peak Bitmap allocation.
            val rough = BitmapFactory.decodeFile(imagePath, BitmapFactory.Options().apply {
                inPreferredConfig = Bitmap.Config.RGB_565
                inSampleSize      = sample
            }) ?: return null

            scaleCompressAndRecycle(rough, thumbFile)
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Same as [generateThumbnail] but decodes from an in-memory byte array
     * instead of re-reading [thumbFile]'s sibling image from disk.
     *
     * Used by the MHTML extraction pipeline (parse(), above), which already
     * holds the decoded image bytes in memory right after writing them to
     * disk — reusing them here avoids two redundant full-file disk reads per
     * image (bounds pass + coarse pass) that decodeFile() would otherwise
     * perform on the file that was just written. Produces byte-for-byte
     * identical thumbnails to the path-based overload, since [imageBytes] IS
     * the exact content of that file.
     */
    internal fun generateThumbnail(imageBytes: ByteArray, thumbFile: File): String? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.size, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

            val sample = com.mangatool.app.util.SampleSizeCalculator.computeMaxAxis(
                bounds.outWidth, bounds.outHeight, THUMBNAIL_TARGET_PX * 2
            )

            val rough = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.size, BitmapFactory.Options().apply {
                inPreferredConfig = Bitmap.Config.RGB_565
                inSampleSize      = sample
            }) ?: return null

            scaleCompressAndRecycle(rough, thumbFile)
        } catch (_: Exception) {
            null
        }
    }

    // ── Step 2: compute adaptive inSampleSize ─────────────────────────────────
    // Target coarse size: 2× THUMBNAIL_TARGET_PX on longest axis — gives
    // createScaledBitmap a ~2× downscale budget, enough to apply bilinear
    // filtering without upsampling artifacts. Both generateThumbnail()
    // overloads above call SampleSizeCalculator.computeMaxAxis() directly;
    // see that object's doc comment for why this path uses the longest axis
    // (as opposed to BitmapUtils' decode path, which uses the shortest).

    // ── Steps 4-6: precise scale to THUMBNAIL_TARGET_PX, compress to WebP, recycle ──
    // Shared by both generateThumbnail() overloads — identical from here on
    // regardless of whether the coarse bitmap came from a file or a byte array.
    private fun scaleCompressAndRecycle(rough: Bitmap, thumbFile: File): String {
        // ── Step 4: precise scale to THUMBNAIL_TARGET_PX on longest axis ─
        val largest = maxOf(rough.width, rough.height)
        val bitmap = if (largest > THUMBNAIL_TARGET_PX) {
            val scale = THUMBNAIL_TARGET_PX.toFloat() / largest
            val w = (rough.width  * scale).toInt().coerceAtLeast(1)
            val h = (rough.height * scale).toInt().coerceAtLeast(1)
            val scaled = Bitmap.createScaledBitmap(rough, w, h, /* filter= */ true)
            if (scaled !== rough) rough.recycle()  // free the oversized coarse bitmap
            scaled
        } else {
            rough  // source already ≤ THUMBNAIL_TARGET_PX; use directly
        }

        // ── Step 5: compress to WebP ──────────────────────────────────────
        // WEBP_LOSSY was added in API 30.  The deprecated WEBP constant is
        // available from API 17 and is always lossy when quality < 100.
        // Both produce byte-for-byte identical output for quality=65 JPEG source.
        FileOutputStream(thumbFile).use { out ->
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                bitmap.compress(Bitmap.CompressFormat.WEBP_LOSSY, 65, out)
            } else {
                @Suppress("DEPRECATION")
                bitmap.compress(Bitmap.CompressFormat.WEBP, 65, out)
            }
        }

        // ── Step 6: return pixel buffer to native heap immediately ────────
        // DO NOT wait for GC. On low-end devices the native heap is limited;
        // holding 30 un-recycled RGB_565 bitmaps (~100 KB each) during
        // batch extraction causes premature native OOM before Java GC fires.
        bitmap.recycle()

        return thumbFile.absolutePath
    }

    /**
     * Identify an image's real format from its decoded bytes, ignoring
     * whatever Content-Type was declared. Needed because some CDNs
     * (anti-hotlink cloaking, e.g. i.supernova22.click used by some
     * manga sites) serve real JPEG/PNG/WebP bytes under a generic
     * "application/octet-stream" header, causing them to be silently
     * skipped if only the header is trusted. Returns null if the bytes
     * don't match any known image signature (e.g. actual binary junk,
     * fonts, etc.) so those are correctly left out.
     */
    internal fun sniffImageExt(b: ByteArray): String? {
        if (b.size < 12) return null
        return when {
            b[0] == 0xFF.toByte() && b[1] == 0xD8.toByte() && b[2] == 0xFF.toByte() -> "jpg"
            b[0] == 0x89.toByte() && b[1] == 0x50.toByte() && b[2] == 0x4E.toByte() &&
                b[3] == 0x47.toByte() -> "png"
            b[0] == 0x47.toByte() && b[1] == 0x49.toByte() && b[2] == 0x46.toByte() -> "gif"
            b[0] == 0x52.toByte() && b[1] == 0x49.toByte() && b[2] == 0x46.toByte() &&
                b[3] == 0x46.toByte() && b[8] == 0x57.toByte() && b[9] == 0x45.toByte() &&
                b[10] == 0x42.toByte() && b[11] == 0x50.toByte() -> "webp"
            b[0] == 0x42.toByte() && b[1] == 0x4D.toByte() -> "bmp"
            else -> null
        }
    }

    // ── Pattern constants — compiled once at class load, not per call ─────────
    // (previously several of these were `Regex(...)` literals written inline
    // inside decodeQP()/smartRename(), each recompiled on every call; hoisted
    // here to match the pattern already used for CONTENT_TYPE_RE/ENCODING_RE)
    private val BOUNDARY_RE = Regex("""boundary="?([^";\s\r\n]+)"?""", RegexOption.IGNORE_CASE)
    private val CONTENT_TYPE_RE = Regex(
        """Content-Type:\s*image/([a-zA-Z0-9.+\-]+)""", RegexOption.IGNORE_CASE)
    private val ENCODING_RE = Regex(
        """Content-Transfer-Encoding:\s*(base64|quoted-printable)""", RegexOption.IGNORE_CASE)

    private val QP_SOFT_BREAK_RE = Regex("=[\\r\\n]+")
    private val QP_HEX_ESCAPE_RE = Regex("=[0-9A-Fa-f]{2}")

    private val MHTML_EXTENSION_RE = Regex("""\.(mhtml|mht)$""", RegexOption.IGNORE_CASE)
    private val UNDERSCORE_OR_PLUS_RE = Regex("[_+]")
    private val NOISE_WORDS_RE = Regex(
        "\\b(read manga online|read online|manga)\\b", RegexOption.IGNORE_CASE)
    private val CHAPTER_NUMBER_RE = Regex(
        """^(.*?)(\b(?:chapter|ch\.?|no\.?|c\.?|vol\.?|volume|#)\s*[\d.]+|\b\d+)(.*)$""",
        RegexOption.IGNORE_CASE)
    private val DIGIT_RUN_RE = Regex("(\\d+)")
    private val BRACKETED_TEXT_RE = Regex("\\[.*?]|\\(.*?\\)")
    private val TRAILING_DASH_RE = Regex("\\s+-\\s*$")
    private val EXTRA_SPACES_RE = Regex("\\s+")

    /** Decodes quoted-printable text (`=XX` hex escapes, `=` soft line breaks). */
    internal fun decodeQP(s: String): String =
        s.replace(QP_SOFT_BREAK_RE, "")
         .replace(QP_HEX_ESCAPE_RE) { it.value.substring(1).toInt(16).toChar().toString() }

    // ── Filename prettifier ───────────────────────────────────────────────────
    /**
     * Turns a raw MHTML filename (often a scraped page title, e.g.
     * "One_Piece_9.mhtml") into a clean, sortable chapter label
     * ("009 - One Piece" — the chapter number is zero-padded to at least 3
     * digits so chapter 9 sorts before chapter 10 lexicographically). Falls
     * back to the original filename (minus extension) if the cleaned result
     * would be empty.
     */
    internal fun smartRename(filename: String): String {
        var n = filename.replace(MHTML_EXTENSION_RE, "")
        n = n.replace(UNDERSCORE_OR_PLUS_RE, " ")
        n = n.replace(NOISE_WORDS_RE, "")
        n = n.trim()

        val m = CHAPTER_NUMBER_RE.find(n)

        if (m != null) {
            val prefix = m.groupValues[1].trim()
            var num    = m.groupValues[2].trim()
            val suffix = m.groupValues[3].trim()
            num = num.replace(DIGIT_RUN_RE) { it.value.padStart(3, '0') }
            val cp = prefix.replace(BRACKETED_TEXT_RE, "").trimEnd('-', '_').trim()
            n = if (cp.isNotEmpty()) "$num - $cp $suffix".trim() else "$num $suffix".trim()
        } else {
            n = n.replace(BRACKETED_TEXT_RE, "").trim()
        }

        return n.replace(TRAILING_DASH_RE, "").replace(EXTRA_SPACES_RE, " ").trim()
            .ifEmpty { filename.substringBefore('.') }
    }
}
