package com.mangatool.app.adapter

import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.mangatool.app.AppMode
import com.mangatool.app.AppState
import com.mangatool.app.R
import com.mangatool.app.model.ImageGroup
import com.mangatool.app.model.ImageItem
import com.mangatool.app.model.MergeDirection
import com.mangatool.app.util.GridHeightCalculator
import com.mangatool.app.util.ImageMerger
import com.mangatool.app.util.ThumbnailGlideLoader
import com.mangatool.app.util.ThumbnailWorker
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Outer adapter: one row per ImageGroup. Each row can expand to show a grid of
 * thumbnails (via an inner ImageThumbAdapter) and a filtered-images section.
 *
 * v19 changes:
 *   • Cover thumbnail loading replaced with Glide — no CoroutineScope, no Job,
 *     no AppState.thumbCache. Glide handles cancellation, BitmapPool reuse,
 *     memory + disk caching automatically.
 *   • FilteredThumbAdapter similarly migrated to Glide.
 *   • VH.coverJob field removed — Glide.with(view).clear() in onViewRecycled.
 *   • ChapterAdapter.scope removed — only the inner ImageThumbAdapter/
 *     FilteredThumbAdapter scopes existed; both are now no-ops with Glide.
 */
class ChapterAdapter(
    private val groups: List<ImageGroup>,
    private val onImageClick: (groupIdx: Int, imageIdx: Int) -> Unit,
    private val onGroupRemove: (groupIdx: Int) -> Unit,
    private val onGroupShare: (groupIdx: Int) -> Unit,
    private val onGroupRename: (groupIdx: Int) -> Unit,
    private val onImageLongClick: ((ImageItem) -> Unit)? = null,
    private val onImageRestore: ((ImageItem) -> Unit)? = null,
    private val onFilteredPreview: ((groupIdx: Int, filteredImageIdx: Int) -> Unit)? = null,
    private val onBatchRestore: ((groupIdx: Int) -> Unit)? = null,
    // ── Lazy dims decode hook ─────────────────────────────────────────────────
    // Called the first time a chapter is expanded (and every subsequent expand,
    // but decodeDimsForGroup() is idempotent: it bails immediately if all images
    // already have width > 0). This keeps BitmapFactory.decodeBounds() work
    // strictly on-demand — no library-wide IO burst at the 6-second mark.
    private val onGroupExpand: ((ImageGroup) -> Unit)? = null
) : RecyclerView.Adapter<ChapterAdapter.VH>() {

    // ── Single-expand tracking ────────────────────────────────────────────────
    // ROOT CAUSE OF "3rd-row lag":
    //   expandedMain was a Set — all expanded chapters stayed alive simultaneously.
    //   Each expanded row keeps a live ImageThumbAdapter (~30 active Glide requests),
    //   a GridLayoutManager, and its RecycledViewPool in memory. By the 3rd expand:
    //     • 3 GridLayoutManagers measuring/laying out simultaneously
    //     • ~90 Glide thumbnail requests competing for the decoder thread pool
    //     • 3 × RecycledViewPool holding warm VHs (memory pressure)
    //   On a 2 GB device with slow eMMC, this saturates both RAM and storage bus.
    //
    // FIX: only ONE chapter can be expanded at a time.
    //   On expand: previous chapter is collapsed, its adapter destroyed, Glide
    //   requests cancelled. At most 30 active thumbnail loads at any moment.
    //
    // -1L = "no group expanded" sentinel (same value as RecyclerView.NO_ID).
    private var expandedGroupId         = -1L
    private var expandedFilteredGroupId = -1L

    // Weak reference to the host RecyclerView — used in cleanupAdapterForGroup()
    // to find and immediately update visible VHs without waiting for notifyItemChanged.
    // Set/cleared in onAttachedToRecyclerView / onDetachedFromRecyclerView.
    private var recyclerView: RecyclerView? = null

    // Thumb adapters are created on first expand and destroyed on collapse.
    // With single-expand, at most ONE adapter is alive in this map at any time.
    private val thumbAdapters    = mutableMapOf<Long, ImageThumbAdapter>()
    private val filteredAdapters = mutableMapOf<Long, FilteredThumbAdapter>()

    // v30: tracks groups whose thumbnails are fully present, so onBindViewHolder
    // skips the filter+map scan on repeat scrolling past an already-prefetched chapter.
    // Cleared per-group on destroyGroupAdapters() and fully on destroy().
    // Never cleared on update() — thumbnails are written once and persist for the session.
    private val fullyPrefetchedGroups = HashSet<Long>()
    var touchHelper: ItemTouchHelper? = null

    // Shared RecycledViewPool — ViewHolder inflation cost amortised across all chapter grids.
    // RULE: a pool only safely shares ViewHolders across adapters that use the SAME set of
    // view types for the SAME layouts — RecyclerView buckets recycled views by
    // getItemViewType(), so distinct view types (see ImageThumbAdapter.VIEW_TYPE_*) can
    // safely coexist in one pool without ever handing a wrong-layout view to a bind call.
    //   sharedThumbPool     → ImageThumbAdapter (item_thumb / item_thumb_merge / item_thumb_merge_vertical)
    //   sharedFilteredPool  → FilteredThumbAdapter (item_thumb_filtered — single view type)
    // Sharing a pool between adapters that DON'T distinguish their layouts by view type
    // (e.g. accidentally pooling two different ViewHolder classes under the same type)
    // causes a ClassCastException at rebind time — this is why FilteredThumbAdapter, whose
    // ViewHolder class differs entirely from ImageThumbAdapter's, gets its own pool below.
    private val sharedThumbPool = RecyclerView.RecycledViewPool().also {
        // v30: increased from 24 → 36.
        // Each expanded chapter shows up to 30 thumbnails (3-col grid × 10 rows).
        // With 24, the 3rd expand would exhaust the pool on chapters with >24 images,
        // forcing synchronous VH inflation for the remaining items — visible as a spike
        // in the layout pass. 36 covers a worst-case 30-image chapter with 6 VHs spare
        // for RecyclerView's own prefetch mechanism.
        it.setMaxRecycledViews(ImageThumbAdapter.VIEW_TYPE_EXTRACT, 36)
        // Merge mode shows PAIRS (2 images per item) in a 2-column grid, so a
        // chapter needs roughly half as many merge-item VHs as an extract
        // chapter needs image VHs for the same image count — 20 comfortably
        // covers a 30-image (15-pair) chapter with headroom to spare.
        //
        // Horizontal and vertical merge use distinct view types (see
        // ImageThumbAdapter's companion doc comment for why) because their
        // ViewHolders wrap structurally different inflated layouts —
        // RecyclerView.RecycledViewPool's default max-per-type is only 5,
        // which without this explicit call would silently cap BOTH merge
        // directions well below what a single expanded chapter needs,
        // forcing far more synchronous inflation than the 36 already
        // configured above for extract mode.
        it.setMaxRecycledViews(ImageThumbAdapter.VIEW_TYPE_MERGE_HORIZONTAL, 20)
        it.setMaxRecycledViews(ImageThumbAdapter.VIEW_TYPE_MERGE_VERTICAL, 20)
    }
    // PERF: Separate pool for filtered grids — all FilteredThumbAdapter instances
    // inflate item_thumb_filtered and can share ViewHolders across chapters.
    // Without this, each chapter's filtered section has its own pool → full
    // ViewHolder inflation cost each time the section is expanded.
    private val sharedFilteredPool = RecyclerView.RecycledViewPool().also {
        it.setMaxRecycledViews(0, 12)
    }

    // Placeholder + prewarm sizing constants live with their respective
    // helpers now (ThumbnailGlideLoader.PLACEHOLDER, GridHeightCalculator).


    init { setHasStableIds(true) }
    override fun getItemId(position: Int): Long = groups[position].id

    // ── RecyclerView lifecycle ─────────────────────────────────────────────────
    override fun onAttachedToRecyclerView(rv: RecyclerView) {
        super.onAttachedToRecyclerView(rv); recyclerView = rv
        // v30: pre-warm sharedThumbPool after the first layout pass.
        // On first expand, GridLayoutManager needs ~9 VHs for the visible rows.
        // Without pre-warming, each VH must be inflated synchronously on Main
        // during the grid layout pass — item_thumb has 4 views; each inflation
        // costs ~1–2 ms on a Helio G85. 9 inflations = up to ~18 ms, which alone
        // blows the 16 ms frame budget and causes a visible dropped frame.
        // rv.post() defers until after the current layout, when the Main thread
        // is idle — 12 inflations take ~14 ms total but happen before any expand.
        rv.post { prewarmThumbPool(rv) }
    }
    override fun onDetachedFromRecyclerView(rv: RecyclerView) {
        super.onDetachedFromRecyclerView(rv); recyclerView = null
    }

    /**
     * Pre-inflate 12 ImageThumbAdapter ViewHolders into sharedThumbPool.
     * 12 = 3 cols × 4 rows — enough to cover the first visible area of any
     * chapter without any on-demand inflation during the expand layout pass.
     *
     * Safe to call multiple times: bails out immediately if pool already has
     * enough recycled VHs.
     *
     * Uses the first group's mergeMode to select the correct item layout,
     * or defaults to extract layout (isMerge=false) if groups is empty yet.
     * Merge-mode adapters use item_thumb_merge which has different views —
     * mixing layouts in the pool would silently show blank thumbnails.
     */
    private fun prewarmThumbPool(rv: RecyclerView) {
        val isMerge  = AppState.currentMode == AppMode.MERGE
        val tempAdapter = ImageThumbAdapter(
            initialItems = emptyList(),
            isMerge      = isMerge,
            onItemClick  = {}
        )
        // getItemViewType() depends only on isMerge/mergeDirection (both fixed
        // at construction), never on the item at [position] — position 0 is
        // safe to query even with an empty initialItems list. Using the
        // adapter's own view type (rather than a hardcoded 0) keeps this
        // correct now that ImageThumbAdapter has three distinct view types;
        // hardcoding 0 would silently prewarm/query the extract-mode bucket
        // even when isMerge is true.
        val viewType = tempAdapter.getItemViewType(0)
        val alreadyWarmed = sharedThumbPool.getRecycledViewCount(viewType)
        val needed = 12 - alreadyWarmed
        if (needed > 0) {
            repeat(needed) {
                sharedThumbPool.putRecycledView(tempAdapter.createViewHolder(rv, viewType))
            }
        }
        tempAdapter.destroy()
    }

    /**
     * Collapse a group and immediately release all associated resources.
     *
     * Called BEFORE expanding a new row and on explicit collapse.
     *
     * Three-phase cleanup:
     *   1. Destroy the ImageThumbAdapter — cancels all 30 in-flight Glide decode
     *      requests for that chapter's thumbnails immediately, not when the GC runs.
     *   2. If the VH for this group is currently visible, null its grid adapter
     *      synchronously — RecyclerView calls onViewRecycled() on every thumbnail
     *      VH, which calls Glide.clear(imageView) on each one. This frees ~1–3 MB
     *      of decoded bitmap memory before the new chapter's thumbnails start loading.
     *   3. notifyItemChanged() for the collapsed position so RecyclerView's
     *      item-view cache is invalidated — prevents a stale VH (with an old
     *      adapter reference) from bypassing onBindViewHolder on scroll-back.
     *
     * Timing:
     *   Called on the Main thread synchronously before the new expand attaches its
     *   adapter. The storage bus is clear for the new chapter's thumbnail reads.
     */
    private fun cleanupAdapterForGroup(groupId: Long) {
        // Phase 1: destroy the adapter (cancels Glide requests via destroy → glide=null)
        thumbAdapters.remove(groupId)?.destroy()

        // Also destroy filtered adapter if it was open for this group
        if (expandedFilteredGroupId == groupId) {
            filteredAdapters.remove(groupId)?.destroy()
            expandedFilteredGroupId = -1L
        }

        // Phase 2: if the VH is currently on screen, null its adapter immediately.
        // findViewHolderForItemId works because setHasStableIds(true) is set.
        // If the VH is off-screen (recycled), this is a no-op — onBindViewHolder
        // will handle cleanup when the item comes back into view.
        (recyclerView?.findViewHolderForItemId(groupId) as? VH)?.let { vh ->
            // Null the adapter: RecyclerView calls onViewRecycled for all child VHs,
            // each of which calls Glide.clear(image). Decoded bitmaps return to
            // Glide's BitmapPool immediately instead of lingering until GC.
            vh.grid.adapter = null
            vh.grid.recycledViewPool.clear()  // free warm VHs from the pool too
            vh.grid.visibility = View.GONE
            vh.arrow.rotation = 0f
            // Clean up the filtered grid in the same VH if open
            if (expandedFilteredGroupId == groupId) {
                vh.filteredGrid.adapter = null
                vh.filteredGrid.recycledViewPool.clear()
                vh.filteredGrid.visibility = View.GONE
                vh.filteredArrow.rotation = 0f
                vh.btnRestoreAll.visibility = View.GONE
            }
        }
    }

    /**
     * Toggle expand/collapse for whichever group `holder` is currently bound to.
     *
     * Triggered ONLY by the dedicated arrow button (holder.arrow). The header
     * row itself is intentionally NOT clickable — tapping the cover, name, or
     * chips does nothing. That used to be the whole-row-is-one-giant-tap-target
     * behavior; per feedback that made it too easy to expand a chapter by
     * accident while aiming for something else nearby (the drag handle in
     * particular), so now there's exactly one explicit control for this.
     */
    private fun toggleExpand(holder: VH) {
        val pos = holder.bindingAdapterPosition
        if (pos == RecyclerView.NO_ID.toInt()) return
        val grp = groups[pos]

        if (grp.id == expandedGroupId) {
            // ── Collapsing the currently expanded row ─────────────────────
            expandedGroupId = -1L
            cleanupAdapterForGroup(grp.id)
            // notifyItemChanged so the view-cache knows this item's state changed.
            // Without this, a VH in the item-view cache (setItemViewCacheSize range)
            // would skip onBindViewHolder on scroll-back, showing a stale grid.
            notifyItemChanged(pos)
        } else {
            // ── Expanding a new row ──────────────────────────────────────
            // Step 1: collapse and release the previously expanded row.
            // This is the key change: previously the Set allowed unlimited
            // simultaneous expanded rows. Now we enforce max-1.
            val prevId  = expandedGroupId
            val prevPos = if (prevId != -1L) groups.indexOfFirst { it.id == prevId } else -1
            if (prevId != -1L) {
                cleanupAdapterForGroup(prevId)
                if (prevPos >= 0) notifyItemChanged(prevPos)
            }

            // Step 2: expand this row.
            expandedGroupId = grp.id
            // Trigger lazy dims decode for this group only. The callback is
            // idempotent — if dims are already decoded it returns in O(N) with
            // zero IO. Safe to call before attachMainGrid() since the decode
            // runs on decodeDispatcher and posts back to Main only when done.
            onGroupExpand?.invoke(grp)
            attachMainGrid(holder, pos, grp)
            holder.grid.visibility = View.VISIBLE
            holder.arrow.rotation = 180f
            // v30: notifyItemChanged(pos) REMOVED here.
            //
            // Previously this was called after direct VH manipulation, but
            // the VH is guaranteed on-screen (user just tapped it), so it
            // is NOT in the item-view cache. The notifyItemChanged scheduled
            // a second full onBindViewHolder → second attachMainGrid → second
            // inner grid layout measurement (30 child binds). On the 3rd expand
            // the sharedThumbPool is partially depleted, so those 30 binds
            // required fresh VH inflation — visible as a frame-drop spike.
            //
            // Without notifyItemChanged: the direct VH changes are immediately
            // visible. When the item scrolls off and returns via the view cache,
            // RecyclerView re-runs onBindViewHolder which handles the state.
            // When evicted to the recycled pool, onBindViewHolder also handles it.
        }
    }

    /**
     * Toggle the filtered-images strip for whichever group `holder` is bound to.
     * Same shared-method treatment as toggleExpand(), and for the same reason:
     * only the dedicated filtered_arrow button triggers this now, not the
     * whole "N filtered — tap to review" row.
     */
    private fun toggleFilteredExpand(holder: VH) {
        val pos = holder.bindingAdapterPosition
        if (pos == RecyclerView.NO_ID.toInt()) return
        val grp = groups[pos]

        if (grp.id == expandedFilteredGroupId) {
            // Collapse filtered section — destroy adapter and clear pool
            expandedFilteredGroupId = -1L
            filteredAdapters.remove(grp.id)?.destroy()
            holder.filteredGrid.adapter = null
            holder.filteredGrid.recycledViewPool.clear()
            holder.filteredGrid.visibility = View.GONE
            holder.btnRestoreAll.visibility = View.GONE
        } else {
            expandedFilteredGroupId = grp.id
            attachFilteredGrid(holder, pos, grp)
            holder.filteredGrid.visibility = View.VISIBLE
            holder.btnRestoreAll.visibility = View.VISIBLE
        }
        holder.filteredArrow.rotation = if (grp.id == expandedFilteredGroupId) 180f else 0f
    }

    /**
     * Expand the drag handle's actual touch-detection area beyond its visual
     * 34dp bounds via TouchDelegate, WITHOUT changing layout or stealing space
     * from neighboring views.
     *
     * ROOT CAUSE of "sometimes drag, sometimes not":
     *   The handle sits directly between the tap-anywhere header row (to its
     *   left) and the share button (to its right). A touch that lands even a
     *   few px outside the handle's own bounds falls through to whichever
     *   neighbor owns that pixel instead — landing a drag attempt as an
     *   expand toggle (or vice versa) depending on exactly where the finger
     *   lands. That's what "sometimes" actually means: it's not random, it's
     *   a too-small target.
     *
     * FIX: bias the extra hit area toward the LEFT/top/bottom, where the
     * neighbor is just open header space, and keep the RIGHT expansion small
     * so we don't start eating into the share button's own hit area and
     * simply move the same problem one button over.
     */
    private fun installDragHandleTouchDelegate(holder: VH) {
        val handle = holder.dragHandle
        val parent = handle.parent as? View ?: return
        handle.post {
            val density = handle.resources.displayMetrics.density
            val rect = android.graphics.Rect()
            handle.getHitRect(rect)
            rect.left   -= (16 * density).toInt()
            rect.right  += (4 * density).toInt()
            rect.top    -= (10 * density).toInt()
            rect.bottom += (10 * density).toInt()
            parent.touchDelegate = android.view.TouchDelegate(rect, handle)
        }
    }

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val cover:           ImageView   = v.findViewById(R.id.chapter_cover)
        val numBadge:        TextView    = v.findViewById(R.id.chapter_num_badge)
        val name:            TextView    = v.findViewById(R.id.chapter_name)
        val count:           TextView    = v.findViewById(R.id.chapter_count)
        val arrow:           ImageButton = v.findViewById(R.id.chapter_arrow)
        val removeBtn:       ImageButton = v.findViewById(R.id.chapter_remove)
        val renameBtn:       ImageButton = v.findViewById(R.id.chapter_rename)
        val shareBtn:        ImageButton = v.findViewById(R.id.chapter_share)
        val dragHandle:      ImageButton = v.findViewById(R.id.drag_handle)
        val mergeDirectionBtn: ImageButton = v.findViewById(R.id.chapter_merge_direction)
        val header:          View        = v.findViewById(R.id.chapter_header)
        val grid:            RecyclerView= v.findViewById(R.id.chapter_grid)
        val filteredSection: View        = v.findViewById(R.id.filtered_section)
        val filteredHeader:  View        = v.findViewById(R.id.filtered_header)
        val filteredLabel:   TextView    = v.findViewById(R.id.filtered_section_label)
        val filteredArrow:   ImageButton = v.findViewById(R.id.filtered_arrow)
        val filteredGrid:    RecyclerView= v.findViewById(R.id.filtered_grid)
        val btnRestoreAll:   TextView    = v.findViewById(R.id.btn_restore_all)
        // No coverJob — Glide.with(view).clear(cover) in onViewRecycled instead
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_chapter, parent, false)
        val holder = VH(v)

        // ── PERF: All click/touch listeners registered ONCE at creation ────────
        //
        // BEFORE (original): Every onBindViewHolder call registered 6–8 new lambda
        // objects per VH — one for each setOnClickListener / setOnTouchListener.
        // For 50 groups: 300–400 new lambda allocations per adapter update().
        // These ~250 KB of short-lived objects trigger a minor GC at the exact
        // moment the post-extraction layout pass needs the frame budget: causing
        // the brief stutter visible right as the chapter list appears.
        //
        // AFTER: Zero listener allocations in onBindViewHolder.
        // Each lambda is created once per VH (≈ 8 total for the full list).
        //
        // bindingAdapterPosition is always fresh at interaction time — same safe
        // pattern already used by ImageThumbAdapter.onCreateViewHolder.

        // Enlarge the actual tappable/drag-start area well beyond the handle's
        // small visual footprint — see installDragHandleTouchDelegate() for why.
        installDragHandleTouchDelegate(holder)

        holder.dragHandle.setOnTouchListener { _, event ->
            // Read mode at touch time (not bind time) — applyMode() can change it between binds.
            if (event.actionMasked == MotionEvent.ACTION_DOWN &&
                AppState.currentMode != AppMode.MERGE) {
                val pos = holder.bindingAdapterPosition
                if (pos != RecyclerView.NO_ID.toInt()) touchHelper?.startDrag(holder)
            }
            false
        }

        holder.removeBtn.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_ID.toInt()) onGroupRemove(pos)
        }

        holder.renameBtn.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_ID.toInt()) onGroupRename(pos)
        }

        holder.shareBtn.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_ID.toInt()) onGroupShare(pos)
        }

        holder.mergeDirectionBtn.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos == RecyclerView.NO_ID.toInt()) return@setOnClickListener
            val grp = groups.getOrNull(pos) ?: return@setOnClickListener
            grp.mergeDirection = if (grp.mergeDirection == MergeDirection.HORIZONTAL)
                MergeDirection.VERTICAL else MergeDirection.HORIZONTAL
            // The cached ImageThumbAdapter for this group was built with the
            // OLD direction's item layout (item_thumb_merge.xml vs
            // item_thumb_merge_vertical.xml) and picks its layout only once,
            // at construction — it can't be reused in place for the new
            // direction. Evict it so attachMainGrid() builds a fresh one on
            // the next bind, matching how the group's own displayed content
            // (below) is refreshed via notifyItemChanged either way.
            thumbAdapters.remove(grp.id)?.destroy()
            holder.grid.adapter = null
            notifyItemChanged(pos)
        }

        holder.name.setOnLongClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_ID.toInt()) onGroupRename(pos)
            true
        }

        // NEW: expand/collapse now lives ONLY on the arrow button. The header
        // row itself is no longer clickable — tapping the cover/name/chips
        // does nothing, so it can't be triggered by accident while reaching
        // for the drag handle or another button next to it.
        holder.arrow.setOnClickListener { toggleExpand(holder) }

        // Same idea for the filtered-images strip: only its own arrow button
        // toggles it now, not the whole "N filtered — tap to review" row.
        holder.filteredArrow.setOnClickListener { toggleFilteredExpand(holder) }

        holder.btnRestoreAll.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_ID.toInt()) onBatchRestore?.invoke(pos)
        }

        return holder
    }

    override fun getItemCount() = groups.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val group   = groups[position]
        val isMerge = AppState.currentMode == AppMode.MERGE
        // Merge groups have no collapse state at all — always shown expanded
        // (see bindNameAndCount, which also hides the now-unneeded arrow
        // button for them). Extract mode keeps the single-expand toggle:
        // at most one group ID matches expandedGroupId at any time.
        val isExpanded = isMerge || group.id == expandedGroupId

        holder.numBadge.text = "${position + 1}"

        bindCover(holder, group)
        bindNameAndCount(holder, group, isMerge)
        bindExpandState(holder, position, group, isExpanded)
        bindFilteredSection(holder, position, group, isMerge)
        prefetchMissingThumbnails(group, isMerge)
    }

    /**
     * Loads the chapter's cover thumbnail (its first display image).
     *
     * v29: full-image fallback REMOVED.
     *
     * Previous behavior when thumbnailPath == null:
     *   Glide.load(File(coverImg.filePath)) → decoded 200–500 KB JPEG
     *   → visible jank on first scroll past chapters with no pre-generated thumbnail.
     *
     * New behavior, via [ThumbnailGlideLoader]:
     *   Primary path (thumbnailPath != null OR ThumbnailWorker cache hit) → Glide
     *   loads the pre-built ~5–7 KB WebP; RGB_565 halves bitmap memory (~78 KB).
     *   Fallback path (no thumbnail yet) → ColorDrawable placeholder + queue
     *   background generation; notifyItemChanged when ready.
     */
    private fun bindCover(holder: VH, group: ImageGroup) {
        val coverImg = group.displayImages.firstOrNull()
        if (coverImg == null) {
            Glide.with(holder.itemView).clear(holder.cover)
            return
        }
        val groupId = group.id
        ThumbnailGlideLoader.load(
            holder.cover, Glide.with(holder.itemView), coverImg.thumbnailPath, coverImg.filePath
        ) {
            val pos = groups.indexOfFirst { it.id == groupId }
            if (pos >= 0) notifyItemChanged(pos)
        }
    }

    private fun bindNameAndCount(holder: VH, group: ImageGroup, isMerge: Boolean) {
        holder.name.text = group.groupName
        if (isMerge) {
            val pairs = (group.displayImages.size + 1) / 2
            holder.count.text = "${group.displayImages.size} images · $pairs pairs"
            holder.dragHandle.visibility = View.GONE
            holder.filteredSection.visibility = View.GONE
            holder.removeBtn.visibility = if (groups.size > 1) View.VISIBLE else View.GONE
            holder.mergeDirectionBtn.visibility = View.VISIBLE
            // Icon reflects the CURRENT direction — matches the same
            // convention as the expand arrow's rotation reflecting current
            // expand state, rather than depicting the action a tap performs.
            holder.mergeDirectionBtn.setImageResource(
                if (group.mergeDirection == MergeDirection.VERTICAL) R.drawable.ic_merge_vertical
                else R.drawable.ic_merge_horizontal
            )
            holder.mergeDirectionBtn.contentDescription =
                if (group.mergeDirection == MergeDirection.VERTICAL)
                    "Merge direction: vertical (stacked). Tap to switch to horizontal."
                else
                    "Merge direction: horizontal (side by side). Tap to switch to vertical."
            // Merge groups are always expanded (see onBindViewHolder) — the
            // arrow has nothing left to toggle.
            holder.arrow.visibility = View.GONE
        } else {
            holder.dragHandle.visibility = View.VISIBLE
            holder.removeBtn.visibility  = View.VISIBLE
            holder.mergeDirectionBtn.visibility = View.GONE
            holder.arrow.visibility = View.VISIBLE
            holder.count.text = "${group.displayImages.size} images"
        }
    }

    /** Applies the main thumbnail grid's expanded/collapsed visual state.
     *  Listeners (arrow tap) are registered once in onCreateViewHolder —
     *  only the current expand state is applied here. */
    private fun bindExpandState(holder: VH, position: Int, group: ImageGroup, isExpanded: Boolean) {
        holder.arrow.rotation = if (isExpanded) 180f else 0f
        if (isExpanded) {
            attachMainGrid(holder, position, group)
            holder.grid.visibility = View.VISIBLE
        } else {
            if (holder.grid.adapter !== thumbAdapters[group.id]) {
                holder.grid.adapter = null
            }
            holder.grid.visibility = View.GONE
        }
    }

    /** Applies the "N filtered — tap to review" strip's visibility and, if
     *  expanded, attaches its grid. Extract mode only — merge mode never
     *  filters images, so the section stays hidden (handled in
     *  [bindNameAndCount]). */
    private fun bindFilteredSection(holder: VH, position: Int, group: ImageGroup, isMerge: Boolean) {
        if (isMerge || group.filteredImages.isEmpty()) {
            holder.filteredSection.visibility = View.GONE
            return
        }
        holder.filteredSection.visibility = View.VISIBLE
        holder.filteredLabel.text = "${group.filteredImages.size} filtered — tap to review"
        holder.filteredArrow.rotation = if (group.id == expandedFilteredGroupId) 180f else 0f
        // Listener (filteredArrow) set in onCreateViewHolder.
        if (group.id == expandedFilteredGroupId) {
            attachFilteredGrid(holder, position, group)
            holder.filteredGrid.visibility = View.VISIBLE
            // Restore-all only makes sense once the person can actually see
            // what they're restoring — hidden until the strip is expanded.
            holder.btnRestoreAll.visibility = View.VISIBLE
        } else {
            holder.filteredGrid.visibility = View.GONE
            holder.btnRestoreAll.visibility = View.GONE
        }
    }

    /**
     * v29/v30: Prefetch thumbnails for this chapter's images.
     * When a chapter row is bound (about to scroll into view), queue background
     * thumbnail generation for any images missing thumbnailPath.
     *
     * v30: skip the scan entirely if we previously confirmed all thumbnails
     * were present (fullyPrefetchedGroups). Avoids 30 getCached() lookups per
     * bind for chapters whose thumbs are already fully generated — the common
     * case after the first scroll through the list.
     */
    private fun prefetchMissingThumbnails(group: ImageGroup, isMerge: Boolean) {
        if (isMerge || group.id in fullyPrefetchedGroups) return
        val missingPaths = group.displayImages
            .filter { it.thumbnailPath == null && ThumbnailWorker.getCached(it.filePath) == null }
            .map { it.filePath }
        if (missingPaths.isEmpty()) {
            // All thumbnails present — mark so future binds skip the scan.
            fullyPrefetchedGroups.add(group.id)
        } else {
            ThumbnailWorker.prefetch(missingPaths, 0, missingPaths.size)
        }
    }

    // Fixed-height grid math now lives in GridHeightCalculator (see its doc
    // comment for why the grid needs a pre-computed pixel height at all).

    private fun attachMainGrid(holder: VH, position: Int, group: ImageGroup) {
        val isMerge = AppState.currentMode == AppMode.MERGE
        val items: List<Any> = if (isMerge) ImageMerger.pairImages(group.displayImages) else group.displayImages
        val cols = if (isMerge) 2 else 3
        val groupId = group.id

        val adapter = thumbAdapters.getOrPut(group.id) {
            // ── PERF: onItemClick captured ONCE at adapter creation ─────────────
            // BEFORE: adapter.onItemClick was reassigned AFTER getOrPut() on every
            // attachMainGrid() call — allocating a new lambda every onBindViewHolder
            // for each expanded chapter. For 50 expanded chapters that is 50 new
            // lambda objects per update() pass, adding ~25 KB of short-lived heap.
            //
            // AFTER: onItemClick is captured inside the getOrPut block, which runs
            // only when the adapter is first created. Subsequent attachMainGrid()
            // calls return the cached adapter without any allocation.
            // groupId is captured at adapter-creation time; groups.indexOfFirst()
            // at click-time resolves the correct position after any drag-reorder.
            ImageThumbAdapter(
                items, isMerge,
                group           = if (isMerge) group else null,
                groupIdx        = position,
                mergeDirection  = group.mergeDirection,
                onItemClick     = { idx ->
                    val currentPos = groups.indexOfFirst { it.id == groupId }
                    if (currentPos != -1) onImageClick(currentPos, idx)
                },
                onItemLongClick = onImageLongClick,
                onSwapChanged   = null
            )
        }
        // NOTE: adapter.onItemClick NOT reassigned here — zero lambda allocation.

        if (holder.grid.layoutManager == null) {
            holder.grid.layoutManager = GridLayoutManager(holder.grid.context, cols).apply {
                // v30: increased from cols*2 (=6) to cols*3 (=9).
                // cols*2 pre-bound only the first row. cols*3 covers 1.5 rows so
                // RecyclerView can start showing content immediately without a
                // visible blank frame. Pre-binding runs on GapWorker — off Main.
                initialPrefetchItemCount = cols * 3
            }
            holder.grid.overScrollMode = View.OVER_SCROLL_NEVER
            // Null animator: eliminates 30 simultaneous ValueAnimator fade-ins on expand.
            holder.grid.itemAnimator = null
            // v28: disable nested scrolling on the inner grid.
            // By default, RecyclerView propagates unconsumed scroll events up the view
            // hierarchy via NestedScrollingChild. The inner grid never scrolls (it uses
            // wrap_content height to show all thumbnails), so every scroll event is
            // unconsumed and propagated to the outer list. Disabling this removes the
            // NestedScrolling dispatch overhead (a synchronized Dispatcher call per
            // scroll event) from the inner grids.
            holder.grid.isNestedScrollingEnabled = false
            // NOTE: setHasFixedSize(true) intentionally omitted.
            // Lint [InvalidSetHasFixedSize] flags it when the XML says wrap_content.
            // It's not needed — we set an explicit pixel height via layoutParams below,
            // which overrides wrap_content at runtime without triggering the lint rule.
        }

        // v30: set fixed height BEFORE visibility = VISIBLE so GridLayoutManager
        // knows the height immediately and only binds the visible rows.
        val density = holder.grid.context.resources.displayMetrics.density
        val fixedH  = GridHeightCalculator.computeGridHeightPx(items.size, isMerge, density, group.mergeDirection)
        if (fixedH > 0) {
            val lp = holder.grid.layoutParams
            if (lp.height != fixedH) {
                lp.height = fixedH
                holder.grid.layoutParams = lp
            }
        }
        holder.grid.setRecycledViewPool(sharedThumbPool)
        // v28: reduced from 12 to 6.
        // Item view cache stores recently detached VHs to avoid re-binding on short
        // scroll reversals. The inner grid is not scrollable (all items visible at once),
        // so a cache > 0 is only useful for RecyclerView's internal prefetch. Keeping 6
        // (instead of 12) halves the warm-VH memory held by the inner grid while still
        // giving the prefetch mechanism enough headroom for one row of anticipation.
        holder.grid.setItemViewCacheSize(6)
        if (holder.grid.adapter !== adapter) {
            holder.grid.adapter = adapter
        }
    }

    private fun attachFilteredGrid(holder: VH, position: Int, group: ImageGroup) {
        val groupId = group.id
        val adapter = filteredAdapters.getOrPut(group.id) {
            // ── PERF: onPreview captured ONCE at adapter creation ──────────────
            // Same pattern as attachMainGrid — prevents lambda re-allocation on
            // every onBindViewHolder for expanded filtered sections.
            FilteredThumbAdapter(
                initialItems = group.filteredImages,
                onPreview = { filtIdx ->
                    val currentPos = groups.indexOfFirst { it.id == groupId }
                    if (currentPos != -1) onFilteredPreview?.invoke(currentPos, filtIdx)
                },
                onRestore = { img ->
                    // BUGFIX: `img` here is a copy() snapshot that AppState.applyFilters()
                    // created for this filtered-grid item (needed so DiffUtil can tell old
                    // vs new reason apart). Mutating that copy did nothing useful — the
                    // very next invalidateAllFilters()+applyFiltersAndRefresh() re-reads
                    // group.allImages, sees the ORIGINAL item still has forceKeep=false,
                    // and immediately re-filters it right back into "Too Small". That's
                    // why tapping restore on a single photo looked like it did nothing.
                    // Fix: look up the real item by originalIdx and mutate that instead.
                    val original = group.allImages.find { it.originalIdx == img.originalIdx } ?: img
                    original.forceKeep = true
                    original.userDeleted = false
                    onImageRestore?.invoke(original)
                }
            )
        }
        // NOTE: adapter.onPreview NOT reassigned here — zero lambda allocation.

        if (holder.filteredGrid.layoutManager == null) {
            holder.filteredGrid.layoutManager = GridLayoutManager(holder.filteredGrid.context, 3).apply {
                initialPrefetchItemCount = 4
            }
            holder.filteredGrid.overScrollMode = View.OVER_SCROLL_NEVER
            holder.filteredGrid.itemAnimator = null
            holder.filteredGrid.isNestedScrollingEnabled = false
            // setHasFixedSize omitted — same reason as attachMainGrid.
        }
        // v30: same fixed-height trick as attachMainGrid.
        val density = holder.filteredGrid.context.resources.displayMetrics.density
        val fixedH  = GridHeightCalculator.computeFilteredHeightPx(group.filteredImages.size, density)
        if (fixedH > 0) {
            val lp = holder.filteredGrid.layoutParams
            if (lp.height != fixedH) {
                lp.height = fixedH
                holder.filteredGrid.layoutParams = lp
            }
        }
        // setHasFixedSize omitted — filtered grid also uses wrap_content height.
        // ── PERF: Share filtered ViewHolder pool across all chapters ───────────
        // BEFORE: each chapter's filteredGrid used its own isolated RecycledViewPool
        // (RecyclerView default). When a filtered section collapsed and re-expanded,
        // its ViewHolder pool was already cleared (filteredAdapters.remove() in
        // filteredArrow click), forcing full VH inflation on every expand.
        //
        // AFTER: all FilteredThumbAdapter instances share sharedFilteredPool.
        // A VH recycled when chapter A's filtered section collapses is reused when
        // chapter B's section expands — saves the inflate + findViewById cost.
        holder.filteredGrid.setRecycledViewPool(sharedFilteredPool)
        // v28: reduced from 8 to 4 — filtered section typically shows 3–6 items.
        holder.filteredGrid.setItemViewCacheSize(4)
        if (holder.filteredGrid.adapter !== adapter) {
            holder.filteredGrid.adapter = adapter
        }
    }

    private data class GroupSnapshot(val id: Long, val name: String, val displaySize: Int, val filteredSize: Int, val coverPath: String?)
    private var prevSnapshot: List<GroupSnapshot> = emptyList()

    fun destroyGroupAdapters(groupId: Long) {
        thumbAdapters.remove(groupId)?.destroy()
        filteredAdapters.remove(groupId)?.destroy()
        fullyPrefetchedGroups.remove(groupId)
        // Clear the expand sentinels if the removed group was the one expanded.
        if (expandedGroupId == groupId)         expandedGroupId         = -1L
        if (expandedFilteredGroupId == groupId) expandedFilteredGroupId = -1L
    }

    suspend fun update() {
        val newGroups = AppState.groups
        val isMerge = AppState.currentMode == AppMode.MERGE
        newGroups.forEach { group ->
            thumbAdapters[group.id]?.let { adapter ->
                val newItems: List<Any> = if (isMerge)
                    ImageMerger.pairImages(group.displayImages)
                else
                    group.displayImages
                adapter.refreshItems(newItems)
            }
            filteredAdapters[group.id]?.refreshItems(group.filteredImages)
        }

        val newSnapshot = newGroups.map {
            GroupSnapshot(it.id, it.groupName, it.displayImages.size, it.filteredImages.size, it.displayImages.firstOrNull()?.filePath)
        }
        val oldSnapshot = prevSnapshot
        prevSnapshot = newSnapshot

        // ── DiffUtil off the Main thread ───────────────────────────────────
        // DiffUtil.calculateDiff() is O(N + D²) where D is the edit distance.
        // For 50–100 groups this is fast (~1 ms) BUT it runs synchronously on
        // whatever thread calls update(). update() was always called from Main,
        // so the diff blocked the Main thread for 1–5 ms at the exact moment the
        // RecyclerView was starting its post-extraction layout pass.
        //
        // withContext(Default) offloads the diff computation to the CPU pool.
        // dispatchUpdatesTo() is then called back on Main (the coroutine resumes
        // here because update() is a suspend fun called from a Main-thread coroutine
        // in refreshChapterList()). The net result: Main is free for layout during
        // the diff, and the adapter patch arrives one frame later — imperceptible.
        val diff = withContext(Dispatchers.Default) {
            DiffUtil.calculateDiff(object : DiffUtil.Callback() {
                override fun getOldListSize() = oldSnapshot.size
                override fun getNewListSize() = newSnapshot.size
                override fun areItemsTheSame(o: Int, n: Int) = oldSnapshot[o].id == newSnapshot[n].id
                override fun areContentsTheSame(o: Int, n: Int) = oldSnapshot[o] == newSnapshot[n]
            })
        }
        diff.dispatchUpdatesTo(this)
    }

    fun notifyImageDimsChanged(groupIdx: Int, displayIdx: Int) {
        val id = groups.getOrNull(groupIdx)?.id ?: return
        thumbAdapters[id]?.notifyItemChanged(displayIdx, ImageThumbAdapter.PAYLOAD_DIMS)
    }

    /**
     * Push an updated displayImages list into the inner ImageThumbAdapter for
     * the given group via AsyncListDiffer.submitList().
     *
     * This is the correct way to surface dimension changes.  The old
     * notifyImageDimsChanged() called notifyItemChanged(pos, PAYLOAD_DIMS) but
     * the differ's currentList was never refreshed, so onBindViewHolder always
     * read width=0 and the badge never appeared.
     *
     * submitList() diffs old vs new on a background thread and fires only the
     * targeted notifyItemChanged calls for items whose data actually changed.
     * The PAYLOAD_DIMS partial-bind path then runs correctly because
     * differ.currentList now contains the updated ImageItem with non-zero dims.
     */
    fun refreshGroupDisplayImages(group: com.mangatool.app.model.ImageGroup) {
        thumbAdapters[group.id]?.refreshItems(group.displayImages)
    }

    fun destroy() {
        // No adapter-level scope to cancel — Glide manages request lifecycle.
        thumbAdapters.values.forEach { it.destroy() }; thumbAdapters.clear()
        filteredAdapters.values.forEach { it.destroy() }; filteredAdapters.clear()
        fullyPrefetchedGroups.clear()
        expandedGroupId = -1L
        expandedFilteredGroupId = -1L
        recyclerView = null
    }

    override fun onViewRecycled(holder: VH) {
        // Cancel any in-flight Glide request for the cover ImageView and return
        // the Bitmap to Glide's BitmapPool rather than letting it linger in the
        // VH until the next bind overwrites it.
        Glide.with(holder.itemView).clear(holder.cover)
        super.onViewRecycled(holder)
    }
}
