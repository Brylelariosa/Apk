package com.mangatool.app.util

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.util.concurrent.Executors
import kotlinx.coroutines.asCoroutineDispatcher

object BitmapUtils {

    /**
     * Adaptive thread pool for bitmap decode work.
     *
     * Old value was hardcoded 3 — left most phone cores idle.
     * New: half the available cores, clamped to [2, 6].
     * A Snapdragon 8-core gets 4 threads; a budget 4-core gets 2.
     * Dispatchers.IO (64 threads) was too aggressive — thrashes the CPU
     * and causes GC spikes when every thumbnail loads simultaneously.
     */
    val decodeDispatcher = Executors.newFixedThreadPool(
        (Runtime.getRuntime().availableProcessors() / 2).coerceIn(2, 6)
    ).asCoroutineDispatcher()

    // ── File path API — always prefer these ──────────────────────────────────
    // BitmapFactory.decodeFile() streams from the file descriptor and does NOT
    // allocate a ByteArray — only decoded pixel data hits the heap.

    /** Decode pixel dimensions without loading any pixel data. */
    fun decodeDimensions(filePath: String): Pair<Int, Int> {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(filePath, opts)
        return opts.outWidth to opts.outHeight
    }

    /**
     * Decode a thumbnail <= [maxPx] using RGB_565 (half the RAM of ARGB_8888).
     * Manga pages are JPEGs with no alpha — identical visual quality at 2x cache density.
     *
     * 1. inSampleSize coarse decode -> ~2x target (minimises pixel data loaded).
     *    See [SampleSizeCalculator.computeMinAxis] for why this path is driven
     *    by the smaller of the two dimensions.
     * 2. Bilinear createScaledBitmap -> smooth final size.
     */
    fun decodeThumbnail(filePath: String, maxPx: Int = 256): Bitmap? {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(filePath, opts)
        if (opts.outWidth <= 0 || opts.outHeight <= 0) return null

        val sample = SampleSizeCalculator.computeMinAxis(opts.outWidth, opts.outHeight, maxPx)

        val rough = BitmapFactory.decodeFile(filePath, BitmapFactory.Options().apply {
            inSampleSize      = sample
            inPreferredConfig = Bitmap.Config.RGB_565
        }) ?: return null

        val largest = maxOf(rough.width, rough.height)
        if (largest <= maxPx) return rough

        val scale = maxPx.toFloat() / largest
        val w = (rough.width  * scale).toInt().coerceAtLeast(1)
        val h = (rough.height * scale).toInt().coerceAtLeast(1)
        val scaled = Bitmap.createScaledBitmap(rough, w, h, true)
        if (scaled !== rough) rough.recycle()
        return scaled
    }

    /**
     * Decode at full resolution for merge compositing only (not preview).
     * Explicit ARGB_8888 rather than relying on BitmapFactory's default —
     * merge compositing's memory-budget comments elsewhere (ImageMerger,
     * ImageSaver) already assume this config; leaving it implicit meant the
     * actual footprint depended on whatever the platform happened to decode
     * to instead of a value those estimates were actually written against.
     */
    fun decodeFull(filePath: String): Bitmap? =
        BitmapFactory.decodeFile(filePath, BitmapFactory.Options().apply {
            inPreferredConfig = Bitmap.Config.ARGB_8888
        })
}
