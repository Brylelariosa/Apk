package com.mangatool.app.manager

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.view.Gravity
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import androidx.lifecycle.lifecycleScope
import com.mangatool.app.AppState
import com.mangatool.app.MainActivity
import com.mangatool.app.R
import com.mangatool.app.databinding.ActivityMainBinding
import com.mangatool.app.model.ImageGroup
import com.mangatool.app.util.FileNameSanitizer
import kotlinx.coroutines.launch

/**
 * Facade over everything "a file becomes part of, or leaves, the library":
 * MHTML/loose-image import, folder persistence, per-chapter rename, and
 * every save/share path (folder, CBZ, direct share).
 *
 * The actual work is split across four focused collaborators, each owning
 * one concern:
 *  - [FileImportProcessor] — turning picked-up URIs into [ImageGroup]s.
 *  - [FolderPreferenceManager] — the remembered Extract/Merge save folders.
 *  - [SaveExportManager] — the save-to-folder/CBZ flow and its dialogs.
 *  - [SharePrecacheManager] — share URI caching and the share actions.
 *
 * This class exists so MainActivity and NavigationController keep a single,
 * stable entry point (unchanged since before this split) instead of needing
 * to know which of the four collaborators owns a given action. It also owns
 * the one piece of behavior too small to deserve its own collaborator:
 * the per-chapter rename dialog.
 *
 * Talks back to MainActivity through two small callbacks instead of holding a
 * reference to ChapterAdapter directly — [refreshChapterList] and
 * [onGroupDimsDecoded] are the only two points where a file operation needs to
 * cause a chapter-list re-render, and both are called from inside the same
 * coroutine that did the underlying work (never fire-and-forget), preserving
 * the exact ordering the original single-class implementation relied on for
 * its frame-timing optimizations (see the yield() comment inside
 * [FileImportProcessor.processFiles]).
 */
class FileManager(
    private val activity: MainActivity,
    private val b: ActivityMainBinding,
    private val uiState: UiStateManager,
    private val refreshChapterList: suspend () -> Unit,
    private val onGroupDimsDecoded: suspend (ImageGroup) -> Unit
) {

    private val folderPrefs = FolderPreferenceManager(activity, uiState)
    private val sharePrecache = SharePrecacheManager(activity, b, uiState)
    private val saveExport = SaveExportManager(activity, b, folderPrefs)
    private val importProcessor = FileImportProcessor(
        activity, b, uiState, refreshChapterList, onGroupDimsDecoded,
        onExtractionSettled = { sharePrecache.preCacheShareUris() }
    )

    /** Cancels any in-flight work — call from MainActivity.onDestroy(). */
    fun onDestroy() {
        importProcessor.onDestroy()
        sharePrecache.onDestroy()
    }

    fun scheduleStaleCacheCleanup() = sharePrecache.scheduleStaleCacheCleanup()

    // ── Folder preferences ──────────────────────────────────────────────────
    fun persistAndRememberFolder(uri: Uri, isMerge: Boolean) = folderPrefs.persistAndRememberFolder(uri, isMerge)
    fun clearExtractFolder() = folderPrefs.clearExtractFolder()
    fun clearMergeFolder() = folderPrefs.clearMergeFolder()

    // ── Import ───────────────────────────────────────────────────────────────
    fun processFiles(uris: List<Uri>, folderName: String = "") = importProcessor.processFiles(uris, folderName)
    fun launchDimsDecodeForGroup(group: ImageGroup) = importProcessor.launchDimsDecodeForGroup(group)
    fun cancelActiveImport() = importProcessor.cancelActiveImport()

    // ── Share ────────────────────────────────────────────────────────────────
    fun preCacheShareUris() = sharePrecache.preCacheShareUris()
    fun invalidateShareCache() = sharePrecache.invalidateShareCache()
    fun shareGroup(groupIdx: Int) = sharePrecache.shareGroup(groupIdx)
    fun startShareAll() = sharePrecache.startShareAll()

    // ── Save ─────────────────────────────────────────────────────────────────
    fun onSaveClicked() = saveExport.onSaveClicked()

    // ── Per-chapter rename ─────────────────────────────────────────────────────
    fun renameGroup(groupIdx: Int) {
        val group = AppState.groups.getOrNull(groupIdx) ?: return
        val defaultName = group.groupName
            .removeSuffix(".mhtml").removeSuffix(".mht").trim()

        // Custom styled dialog — transparent window so the layout's rounded
        // card background shows through cleanly.
        val dialog = Dialog(activity, android.R.style.Theme_Translucent_NoTitleBar)
        val view = activity.layoutInflater.inflate(R.layout.dialog_rename, null)
        dialog.setContentView(view)
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setLayout(
                (activity.resources.displayMetrics.widthPixels * 0.88).toInt(),
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            setGravity(Gravity.CENTER)
            setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        }

        val input = view.findViewById<EditText>(R.id.rename_input)
        input.setText(defaultName)
        input.setSelection(0, defaultName.length)

        view.findViewById<Button>(R.id.btn_rename_cancel).setOnClickListener {
            dialog.dismiss()
        }
        view.findViewById<Button>(R.id.btn_rename_confirm).setOnClickListener {
            val newName = FileNameSanitizer.sanitize(input.text.toString(), defaultName)
            AppState.invalidateFilter(group)
            group.groupName = newName
            activity.lifecycleScope.launch { refreshChapterList() }
            dialog.dismiss()
        }
        // Trigger confirm on keyboard "Done"
        input.setOnEditorActionListener { _, _, _ ->
            val newName = FileNameSanitizer.sanitize(input.text.toString(), defaultName)
            AppState.invalidateFilter(group)
            group.groupName = newName
            activity.lifecycleScope.launch { refreshChapterList() }
            dialog.dismiss()
            true
        }

        dialog.show()
        input.post {
            (activity.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                .showSoftInput(input, InputMethodManager.SHOW_IMPLICIT)
        }
    }
}
