package com.mangatool.app

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.snackbar.Snackbar
import com.mangatool.app.adapter.PreviewPagerAdapter
import com.mangatool.app.databinding.ActivityImagePreviewBinding
import com.mangatool.app.model.ImageItem
import com.mangatool.app.model.MergePairDescriptor
import com.mangatool.app.util.ImageMerger
import com.mangatool.app.util.applyCloseSlideTransitionCompat
import com.mangatool.app.util.applyOpenSlideTransition
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ImagePreviewActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_GROUP_IDX   = "group_idx"
        const val EXTRA_IMAGE_IDX   = "image_idx"
        const val EXTRA_IS_MERGE    = "is_merge"
        const val EXTRA_IS_FILTERED = "is_filtered"
    }

    private lateinit var b: ActivityImagePreviewBinding
    private var groupIdx   = 0
    private var isMerge    = false
    private var isFiltered = false
    private var pagerAdapter: PreviewPagerAdapter? = null

    // Parallel list: pager index i ↔ originalIdx of that image
    private val originalIdxList = mutableListOf<Int>()

    // Pending undo — holds one uncommitted deletion/restore
    private data class Pending(
        val pagerPos: Int,
        val origIdx: Int,
        val itemData: Any,
        val wasFiltered: Boolean   // true = restore action, false = delete action
    )
    private var pending: Pending? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applyOpenSlideTransition()
        b = ActivityImagePreviewBinding.inflate(layoutInflater)
        setContentView(b.root)

        groupIdx   = intent.getIntExtra(EXTRA_GROUP_IDX, 0)
        isMerge    = intent.getBooleanExtra(EXTRA_IS_MERGE, false)
        isFiltered = intent.getBooleanExtra(EXTRA_IS_FILTERED, false)
        val startIdx = intent.getIntExtra(EXTRA_IMAGE_IDX, 0)

        val group = AppState.groups.getOrNull(groupIdx) ?: run { finish(); return }

        b.previewLoading.visibility = View.VISIBLE
        lifecycleScope.launch {
            val items: List<Any> = withContext(Dispatchers.IO) {
                when {
                    isFiltered -> {
                        originalIdxList.clear()
                        group.filteredImages.map { img ->
                            originalIdxList.add(img.originalIdx)
                            img.filePath
                        }
                    }
                    isMerge -> {
                        // Pass lightweight descriptors — actual merge decoding happens
                        // lazily in PreviewPagerAdapter.onBindViewHolder, one page at a time.
                        ImageMerger.pairImages(group.displayImages).mapIndexed { i, pair ->
                            MergePairDescriptor(pair, group.pairSwaps.contains(i), group.mergeDirection)
                        }
                    }
                    else -> {
                        originalIdxList.clear()
                        group.displayImages.map { img ->
                            originalIdxList.add(img.originalIdx)
                            img.filePath
                        }
                    }
                }
            }

            b.previewLoading.visibility = View.GONE
            pagerAdapter = PreviewPagerAdapter(items)
            b.viewPager.adapter = pagerAdapter
            b.viewPager.setCurrentItem(startIdx.coerceIn(0, (items.size - 1).coerceAtLeast(0)), false)
            updateCounter()
            updateActionBtn()

            b.viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
                override fun onPageSelected(position: Int) {
                    updateCounter()
                    updateActionBtn()
                }
            })
        }

        b.closeBtn.setOnClickListener { commitPending(); setResult(RESULT_OK); finish() }
        b.prevBtn.setOnClickListener  { b.viewPager.currentItem -= 1 }
        b.nextBtn.setOnClickListener  { b.viewPager.currentItem += 1 }
        b.deleteBtn.setOnClickListener { handleAction() }
    }

    private fun handleAction() {
        val adapter = pagerAdapter ?: return
        val pos     = b.viewPager.currentItem
        val group   = AppState.groups.getOrNull(groupIdx) ?: return

        // If a previous action is pending, commit it before processing the new one
        commitPending()

        if (isFiltered) {
            // ── Restore (with undo = "un-restore") ──────────────────────────
            val origIdx  = originalIdxList.getOrNull(pos) ?: return
            val itemData = adapter.items.getOrNull(pos) ?: return

            // Visually remove from pager immediately
            originalIdxList.removeAt(pos)
            adapter.removeAt(pos)
            setResult(RESULT_OK)

            val snackMsg  = "Image restored"
            val undoLabel = "Undo"

            pending = Pending(pos, origIdx, itemData, wasFiltered = true)

            val snack = Snackbar.make(b.root, snackMsg, Snackbar.LENGTH_LONG)
            snack.setAction(undoLabel) {
                // Re-insert into pager
                val p = pending ?: return@setAction
                originalIdxList.add(p.pagerPos.coerceAtMost(originalIdxList.size), p.origIdx)
                adapter.insertAt(p.pagerPos.coerceAtMost(adapter.itemCount), p.itemData)
                b.viewPager.setCurrentItem(p.pagerPos, false)
                pending = null
                updateCounter()
            }
            snack.addCallback(object : Snackbar.Callback() {
                override fun onDismissed(snackbar: Snackbar, event: Int) {
                    if (event != DISMISS_EVENT_ACTION) commitPending()
                    // Checked here — after any Undo action has already run —
                    // rather than immediately after the removal, so this always
                    // reflects the pager's true final state. An Undo tap that
                    // refilled the pager in the meantime is never raced by a
                    // premature finish() call.
                    if (adapter.itemCount == 0) finish()
                }
            })
            snack.show()

            updateCounter(); updateActionBtn()

        } else if (!isMerge) {
            // ── Delete (with undo) ───────────────────────────────────────────
            val origIdx  = originalIdxList.getOrNull(pos) ?: return
            val itemData = adapter.items.getOrNull(pos) ?: return

            originalIdxList.removeAt(pos)
            adapter.removeAt(pos)
            setResult(RESULT_OK)

            pending = Pending(pos, origIdx, itemData, wasFiltered = false)

            val snack = Snackbar.make(b.root, "Image deleted", Snackbar.LENGTH_LONG)
            snack.setAction("Undo") {
                val p = pending ?: return@setAction
                originalIdxList.add(p.pagerPos.coerceAtMost(originalIdxList.size), p.origIdx)
                adapter.insertAt(p.pagerPos.coerceAtMost(adapter.itemCount), p.itemData)
                b.viewPager.setCurrentItem(p.pagerPos, false)
                pending = null
                updateCounter()
            }
            snack.addCallback(object : Snackbar.Callback() {
                override fun onDismissed(snackbar: Snackbar, event: Int) {
                    if (event != DISMISS_EVENT_ACTION) commitPending()
                    // See the matching comment in the restore branch above —
                    // same reasoning applies to a delete of the last image.
                    if (adapter.itemCount == 0) finish()
                }
            })
            snack.show()

            updateCounter(); updateActionBtn()
        }
    }

    /** Actually apply the pending deletion/restore to AppState. */
    private fun commitPending() {
        val p = pending ?: return
        pending = null
        val group = AppState.groups.getOrNull(groupIdx) ?: return
        val orig  = group.allImages.find { it.originalIdx == p.origIdx } ?: return
        if (p.wasFiltered) {
            orig.forceKeep   = true
            orig.userDeleted = false
        } else {
            orig.userDeleted = true
            orig.forceKeep   = false
        }
        AppState.applyFilters()
    }

    private fun updateCounter() {
        val adapter = pagerAdapter ?: return
        val count = adapter.itemCount
        // Avoid a confusing "N / 0" during the brief window between the last
        // image being removed and the Activity actually finishing (see
        // handleAction()'s Snackbar dismiss callback).
        b.previewCounter.text = if (count == 0) "0 / 0" else "${b.viewPager.currentItem + 1} / $count"
    }

    private fun updateActionBtn() {
        when {
            isMerge    -> b.deleteBtn.visibility = View.GONE
            isFiltered -> {
                b.deleteBtn.visibility = View.VISIBLE
                b.deleteBtn.text = "Restore Image"
                b.deleteBtn.backgroundTintList =
                    android.content.res.ColorStateList.valueOf(0xFF16A34A.toInt())
            }
            else -> {
                b.deleteBtn.visibility = View.VISIBLE
                b.deleteBtn.text = "Delete Image"
                b.deleteBtn.backgroundTintList =
                    android.content.res.ColorStateList.valueOf(0xFFEF4444.toInt())
            }
        }
    }

    override fun onDestroy() {
        commitPending()
        pagerAdapter?.destroy()
        super.onDestroy()
    }

    override fun finish() {
        super.finish()
        applyCloseSlideTransitionCompat()
    }
}
