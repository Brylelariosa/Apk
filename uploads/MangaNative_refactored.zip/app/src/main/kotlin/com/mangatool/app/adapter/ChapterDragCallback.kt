package com.mangatool.app.adapter

import android.content.Context
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView

/**
 * Drag-to-reorder behavior for the chapter list, started from each row's
 * drag handle (see [ChapterAdapter]'s `dragHandle` touch listener, which
 * calls `touchHelper.startDrag(holder)`).
 *
 * This lives in its own class instead of an inline `SimpleCallback` for two
 * reasons:
 *
 *  1. **Reuse** — the actual reorder mutation is injected via [onMove], so
 *     this class has no dependency on `AppState`, `MainActivity`, or any
 *     particular adapter. Anything that hands it a RecyclerView and a
 *     "swap these two positions" lambda gets the same drag + auto-scroll
 *     behavior for free.
 *
 *  2. **Auto-scroll** — `ItemTouchHelper` ships with its own out-of-bounds
 *     auto-scroll, but its defaults are tuned in a way that reads as
 *     "dragging near the edge does nothing": [interpolateOutOfBoundsScroll]
 *     ramps up over a full two seconds (AOSP's
 *     `DRAG_SCROLL_ACCELERATION_LIMIT_TIME_MS`), and scrolling only starts
 *     once the dragged row's edge has fully left the RecyclerView's bounds.
 *     For a list of variable-height chapter cards, reordered in short holds
 *     near the top/bottom, that combination makes the built-in auto-scroll
 *     effectively invisible.
 *
 *     Overriding these two hooks keeps *all* of ItemTouchHelper's own
 *     scroll and position bookkeeping — so the swap target and final drop
 *     position stay exactly as accurate as stock behavior — while making
 *     the scroll itself immediate and smooth:
 *       • [getBoundingBoxMargin] starts considering the drag "out of
 *         bounds" while the card is still comfortably inside the list, i.e.
 *         as it *approaches* the edge rather than only once it has crossed
 *         it.
 *       • [interpolateOutOfBoundsScroll] reaches a responsive scroll speed
 *         almost immediately instead of easing in over two seconds.
 */
class ChapterDragCallback(
    context: Context,
    private val onMove: (from: Int, to: Int) -> Unit
) : ItemTouchHelper.SimpleCallback(ItemTouchHelper.UP or ItemTouchHelper.DOWN, 0) {

    private val density = context.resources.displayMetrics.density
    private val edgeTriggerPx = (EDGE_TRIGGER_DP * density).toInt()
    private val maxScrollPxPerFrame = (MAX_SCROLL_DP_PER_FRAME * density).toInt()
    private val restingElevationPx = RESTING_ELEVATION_DP * density
    private val draggedElevationPx = DRAGGED_ELEVATION_DP * density

    // Drag is only ever started explicitly from the handle (see class doc),
    // never from a long-press anywhere on the row.
    override fun isLongPressDragEnabled() = false

    override fun onMove(
        recyclerView: RecyclerView,
        viewHolder: RecyclerView.ViewHolder,
        target: RecyclerView.ViewHolder
    ): Boolean {
        val from = viewHolder.bindingAdapterPosition
        val to = target.bindingAdapterPosition
        if (from == RecyclerView.NO_POSITION || to == RecyclerView.NO_POSITION) return false
        onMove(from, to)
        return true
    }

    // Swiping is disabled (swipe flags = 0 above); nothing to animate.
    override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) = Unit

    override fun getBoundingBoxMargin(): Int = edgeTriggerPx

    override fun interpolateOutOfBoundsScroll(
        recyclerView: RecyclerView,
        viewSize: Int,
        viewSizeOutOfBounds: Int,
        totalSize: Int,
        msSinceStartScroll: Long
    ): Int {
        val direction = if (viewSizeOutOfBounds > 0) 1 else -1
        val rampRatio = (msSinceStartScroll.toFloat() / RAMP_UP_MS).coerceIn(MIN_SPEED_RATIO, 1f)
        return (maxScrollPxPerFrame * rampRatio).toInt() * direction
    }

    /** Lift the dragged card — elevation + a touch of transparency — so the
     *  active row clearly reads as "being dragged": one of the interactive
     *  states the design keeps accent/emphasis treatment for. */
    override fun onSelectedChanged(viewHolder: RecyclerView.ViewHolder?, actionState: Int) {
        super.onSelectedChanged(viewHolder, actionState)
        if (actionState == ItemTouchHelper.ACTION_STATE_DRAG) {
            viewHolder?.itemView?.apply {
                alpha = DRAGGED_ALPHA
                elevation = draggedElevationPx
            }
        }
    }

    override fun clearView(recyclerView: RecyclerView, viewHolder: RecyclerView.ViewHolder) {
        super.clearView(recyclerView, viewHolder)
        // Restore the card's normal resting elevation (item_chapter.xml's
        // own 2dp) rather than 0 — this view instance may be recycled and
        // rebound to a different chapter without ever going through
        // layout inflation again, so a hard 0 here would leave it flat.
        viewHolder.itemView.apply {
            alpha = 1f
            elevation = restingElevationPx
        }
    }

    companion object {
        private const val EDGE_TRIGGER_DP = 56
        private const val MAX_SCROLL_DP_PER_FRAME = 14
        private const val RAMP_UP_MS = 300L
        private const val MIN_SPEED_RATIO = 0.35f
        private const val DRAGGED_ALPHA = 0.94f
        private const val RESTING_ELEVATION_DP = 2f
        private const val DRAGGED_ELEVATION_DP = 8f
    }
}
