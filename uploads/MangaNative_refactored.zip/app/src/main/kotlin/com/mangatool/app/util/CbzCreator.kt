package com.mangatool.app.util

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import com.mangatool.app.model.ImageGroup
import kotlinx.coroutines.ensureActive
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.coroutines.coroutineContext

object CbzCreator {

    data class Progress(val message: String, val percent: Int)

    /**
     * Write all groups to a single CBZ in Downloads.
     *
     * Extract mode : images are stored verbatim (original bytes, lossless).
     * Merge mode   : paired bitmaps are saved as lossless PNG — no quality
     *                loss from re-compression, no JPEG artefacts.
     *
     * suspend + ensureActive(): this can run for a while on a large library,
     * and was previously a plain synchronous function with no cancellation
     * checks at all — cancelling the enclosing coroutine (e.g. the Activity
     * being destroyed mid-export) couldn't actually stop an in-progress
     * write, only prevent the *next* one from starting. Checked once per
     * image/pair, matching the granularity MhtmlParser.parse() already uses
     * for the same reason.
     */
    suspend fun create(
        context: Context,
        groups: List<ImageGroup>,
        filename: String = "Manga_Batch.cbz",
        isMerge: Boolean = false,
        onProgress: (Progress) -> Unit
    ): Uri {
        val (outStream, savedUri) = openOutputStream(context, filename)
            ?: throw IllegalStateException("Cannot open output stream")

        ZipOutputStream(outStream.buffered()).use { zip ->
            var totalImages = 0
            groups.forEach { g ->
                totalImages += if (isMerge) ImageMerger.pairImages(g.displayImages).size
                               else g.displayImages.size
            }
            var done = 0

            groups.forEach { group ->
                val safeName = FileNameSanitizer.sanitize(group.groupName, fallback = "Chapter")

                if (isMerge) {
                    val pairs = ImageMerger.pairImages(group.displayImages)
                    // Snapshotted once per group, before iterating its pairs —
                    // a direction/swap toggle mid-export can't produce a CBZ
                    // with some pairs composited one way and some another
                    // (same fix as FolderSaver.saveMergeToTree / ImageSaver.buildShareUris).
                    val direction = group.mergeDirection
                    val swaps = group.pairSwaps.toSet()
                    pairs.forEachIndexed { i, pair ->
                        coroutineContext.ensureActive()
                        onProgress(Progress(
                            "Merging ${group.groupName} ($i/${pairs.size})",
                            (done * 100) / totalImages
                        ))
                        val swapped = swaps.contains(i)
                        val bm = ImageMerger.merge(pair, swapped, direction)
                        if (bm != null) {
                            // PNG is lossless — no quality degradation on merged spreads
                            val bytes = bitmapToPngBytes(bm)
                            bm.recycle()
                            val entryName = "$safeName/${(i + 1).toString().padStart(4, '0')}.png"
                            zip.putNextEntry(ZipEntry(entryName))
                            zip.write(bytes)
                            zip.closeEntry()
                        }
                        done++
                    }
                } else {
                    group.displayImages.forEachIndexed { i, img ->
                        coroutineContext.ensureActive()
                        if (i % 20 == 0) onProgress(Progress(
                            "Compressing ${group.groupName} ($i/${group.displayImages.size})",
                            (done * 100) / totalImages
                        ))
                        val entryName = "$safeName/${img.name}"
                        zip.putNextEntry(ZipEntry(entryName))
                        java.io.File(img.filePath).inputStream().buffered(65_536).use { it.copyTo(zip) }
                        zip.closeEntry()
                        done++
                    }
                }
            }
        }

        onProgress(Progress("Done!", 100))
        return savedUri
    }

    /** Encode bitmap as lossless PNG. The quality parameter is ignored by the PNG encoder. */
    private fun bitmapToPngBytes(bm: Bitmap): ByteArray {
        val out = ByteArrayOutputStream()
        bm.compress(Bitmap.CompressFormat.PNG, 0, out)
        return out.toByteArray()
    }

    private fun openOutputStream(context: Context, filename: String): Pair<OutputStream, Uri>? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val cv = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, filename)
                put(MediaStore.Downloads.MIME_TYPE, "application/x-cbz")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val uri = context.contentResolver
                .insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv) ?: return null
            val stream = context.contentResolver.openOutputStream(uri)
            if (stream == null) {
                // insert() succeeded but the stream couldn't be opened — clean
                // up the now-orphaned pending row rather than leaving a
                // permanently invisible, empty entry in the user's Downloads
                // collection forever (IS_PENDING would never get cleared).
                runCatching { context.contentResolver.delete(uri, null, null) }
                return null
            }

            val wrappedStream = object : OutputStream() {
                override fun write(b: Int) = stream.write(b)
                override fun write(b: ByteArray, off: Int, len: Int) = stream.write(b, off, len)
                override fun flush() = stream.flush()
                override fun close() {
                    stream.close()
                    cv.clear()
                    cv.put(MediaStore.Downloads.IS_PENDING, 0)
                    context.contentResolver.update(uri, cv, null, null)
                }
            }
            wrappedStream to uri
        } else {
            val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            dir.mkdirs()

            // Avoid silently overwriting a same-named existing file — the Q+
            // path above auto-renames on collision via MediaStore; matched
            // here so the two code paths behave consistently.
            val finalFile = uniqueFile(dir, filename)
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", finalFile)

            // Write to a temp file and rename into place only once the ZIP is
            // fully written and closed. Without this, a crash or process kill
            // mid-write left a same-named, half-written, corrupt .cbz sitting
            // at the final path with nothing to indicate it was incomplete —
            // unlike the Q+ path above, which hides the file (IS_PENDING)
            // until writing finishes.
            val tempFile = File(dir, "${finalFile.name}.tmp")
            val wrappedStream = object : OutputStream() {
                private val stream = tempFile.outputStream()
                override fun write(b: Int) = stream.write(b)
                override fun write(b: ByteArray, off: Int, len: Int) = stream.write(b, off, len)
                override fun flush() = stream.flush()
                override fun close() {
                    stream.close()
                    if (!tempFile.renameTo(finalFile)) {
                        // Rare fallback (e.g. rename across filesystems) —
                        // same end state, just not a single atomic syscall.
                        tempFile.copyTo(finalFile, overwrite = true)
                        tempFile.delete()
                    }
                }
            }
            wrappedStream to uri
        }
    }

    /** Returns [filename] if free, otherwise the first "name (N).ext" that is. */
    private fun uniqueFile(dir: File, filename: String): File {
        val candidate = File(dir, filename)
        if (!candidate.exists()) return candidate
        val base = filename.substringBeforeLast('.', filename)
        val ext = filename.substringAfterLast('.', "")
        var n = 1
        var next: File
        do {
            next = File(dir, if (ext.isEmpty()) "$base ($n)" else "$base ($n).$ext")
            n++
        } while (next.exists())
        return next
    }
}
