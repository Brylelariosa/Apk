package com.mangatool.app.util

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import com.mangatool.app.model.ImageGroup
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.io.File
import java.util.concurrent.atomic.AtomicInteger

// Extension: save into a user-chosen folder (ACTION_OPEN_DOCUMENT_TREE URI)
object FolderSaver {

    data class Progress(val message: String, val percent: Int)
    data class SaveResult(val count: Int, val folderName: String)

    /**
     * Save extract groups into a user-picked folder tree URI — fast, lossless.
     *
     * Speed strategy — two-phase approach:
     *
     *   Phase 1 (sequential):  Create all DocumentFiles via SAF.
     *                          SAF's createFile() is an IPC round-trip that MUST be
     *                          sequential — DocumentFile is not thread-safe.
     *
     *   Phase 2 (parallel):    Write the actual bytes to each already-created URI.
     *                          Each URI is independent, so IO threads can blast all
     *                          files to disk simultaneously.
     *
     * Quality: raw byte-copy for every format (JPEG, PNG, WEBP, GIF).
     *          Zero decoding, zero re-encoding, zero quality loss.
     *
     * Unchanged from v30 — this function was already correct.
     */
    suspend fun saveExtractToTree(
        context: Context,
        treeUri: Uri,
        groups: List<ImageGroup>,
        onProgress: (Progress) -> Unit
    ): SaveResult {
        val root = DocumentFile.fromTreeUri(context, treeUri)
            ?: throw IllegalStateException("Cannot open folder")

        val totalImages = groups.sumOf { it.displayImages.size }.coerceAtLeast(1)
        onProgress(Progress("Creating folders…", 0))

        // ── Phase 1: create all DocumentFiles sequentially ────────────────────
        data class WriteTask(val uri: Uri, val srcPath: String)
        val tasks = mutableListOf<WriteTask>()

        var createsDone = 0
        groups.forEach { group ->
            val subName = FileNameSanitizer.sanitize(group.groupName, fallback = "MIE")
            val dir = root.findFile(subName)?.takeIf { it.isDirectory }
                ?: root.createDirectory(subName)
                ?: throw IllegalStateException("Cannot create folder: $subName")

            group.displayImages.forEach { img ->
                createsDone++
                onProgress(Progress(
                    "Creating files… $createsDone/$totalImages",
                    (createsDone * 10) / totalImages
                ))

                val mime     = MimeTypes.forImageExtension(img.ext)
                val baseName = img.name.substringBeforeLast('.')

                var file = dir.createFile(mime, baseName)

                if (file != null &&
                    file.name != img.name &&
                    file.name != "$baseName.${img.ext}") {
                    dir.findFile(img.name)?.delete()
                    dir.findFile(baseName)?.delete()
                    file.delete()
                    file = dir.createFile(mime, baseName)
                }

                file?.let { tasks.add(WriteTask(it.uri, img.filePath)) }
            }
        }

        // ── Phase 2: write all in parallel ────────────────────────────────────
        onProgress(Progress("Writing ${tasks.size} images (parallel)…", 10))
        val written = AtomicInteger(0)

        coroutineScope {
            tasks.map { task ->
                async(Dispatchers.IO) {
                    runCatching {
                        context.contentResolver.openOutputStream(task.uri)
                            ?.buffered(65_536)
                            ?.use { out ->
                                File(task.srcPath).inputStream().buffered(65_536)
                                    .use { it.copyTo(out) }
                                written.incrementAndGet()
                            }
                    }
                    val done = written.get()
                    if (done % 5 == 0 || done == tasks.size) {
                        onProgress(Progress(
                            "Writing $done/${tasks.size}…",
                            10 + (done * 90) / tasks.size
                        ))
                    }
                }
            }.awaitAll()
        }

        val finalCount = written.get()
        onProgress(Progress("Done! $finalCount images saved", 100))
        return SaveResult(finalCount, root.name ?: "Selected folder")
    }

    /**
     * Save merged pairs into a user-picked folder — lossless PNG, full resolution.
     *
     * Strategy — two-phase approach:
     *
     *   Phase 1 (sequential):
     *     Create all SAF DocumentFiles up-front via DocumentFile.createFile().
     *     This MUST be sequential: DocumentFile is not thread-safe across IPC.
     *     Side effect: files are created only for pairs that exist; if
     *     ImageMerger.merge() later returns null for a pair (e.g. corrupted source),
     *     that file will be left empty (0 bytes) — an acceptable edge case.
     *
     *   Phase 2 (bounded parallel):
     *     Merge + PNG-compress + stream directly into each pre-created SAF URI.
     *
     *     Bounded by Semaphore(2):
     *       Each merge holds ~20–32 MB in RAM (2 source Bitmaps + composite result).
     *       Semaphore(2) caps peak at ~64 MB regardless of how large the library is.
     *
     *     Bitmap.compress() streams directly into the SAF OutputStream.
     *       No intermediate ByteArray is allocated — eliminates the double-copy
     *       that the old toPngBytes() / out.write(bytes) pattern caused.
     *
     *     openOutputStream() on distinct pre-created URIs is thread-safe:
     *       each URI owns an independent Binder FD to a different file.
     */
    suspend fun saveMergeToTree(
        context: Context,
        treeUri: Uri,
        groups: List<ImageGroup>,
        photoName: String = "Merged",
        onProgress: (Progress) -> Unit
    ): SaveResult {
        val root     = DocumentFile.fromTreeUri(context, treeUri)
            ?: throw IllegalStateException("Cannot open folder")
        val safeName = FileNameSanitizer.sanitize(photoName, fallback = "Merged")

        data class Work(
            val group:   ImageGroup,
            val pairIdx: Int,
            val pair:    List<com.mangatool.app.model.ImageItem>
        )
        val allWork = groups.flatMap { g ->
            ImageMerger.pairImages(g.displayImages).mapIndexed { i, p -> Work(g, i, p) }
        }
        val total = allWork.size.coerceAtLeast(1)

        // ── Phase 1: create all SAF DocumentFiles sequentially ────────────────
        // DocumentFile.createFile() is an IPC round-trip; must not be called
        // from concurrent threads.
        data class WriteTarget(val work: Work, val uri: Uri)
        val targets = mutableListOf<WriteTarget>()

        onProgress(Progress("Creating files…", 0))
        allWork.forEachIndexed { idx, work ->
            val baseName = if (total == 1) safeName else "${safeName}_${idx + 1}"
            root.findFile("$baseName.png")?.delete()        // remove stale file if present
            val file = root.createFile("image/png", baseName)
            file?.let { targets.add(WriteTarget(work, it.uri)) }
            onProgress(Progress(
                "Creating ${idx + 1}/$total…",
                ((idx + 1) * 10) / total                   // Phase 1 = first 10%
            ))
        }

        // ── Phase 2: bounded parallel encode + stream into pre-created URIs ───
        val semaphore = Semaphore(2)
        val written   = AtomicInteger(0)

        onProgress(Progress("Encoding 0/${targets.size}…", 10))
        coroutineScope {
            targets.map { target ->
                async(Dispatchers.IO) {
                    semaphore.withPermit {
                        val swapped = target.work.group.pairSwaps.contains(target.work.pairIdx)
                        val bm = ImageMerger.merge(target.work.pair, swapped)
                            ?: return@withPermit          // merge failed; file stays empty

                        // Direct stream: Bitmap.compress() writes into the SAF OutputStream.
                        // No ByteArray is allocated — codec output flows straight to disk.
                        context.contentResolver.openOutputStream(target.uri)
                            ?.buffered(65_536)
                            ?.use { out ->
                                bm.compress(Bitmap.CompressFormat.PNG, 0, out)
                            }
                        bm.recycle()

                        val done = written.incrementAndGet()
                        onProgress(Progress(
                            "Encoding $done/${targets.size}…",
                            10 + (done * 90) / targets.size   // Phase 2 = remaining 90%
                        ))
                    }
                }
            }.awaitAll()
        }

        val finalCount = written.get()
        onProgress(Progress("Done! $finalCount photos saved", 100))
        return SaveResult(finalCount, root.name ?: "Selected folder")
    }
}
