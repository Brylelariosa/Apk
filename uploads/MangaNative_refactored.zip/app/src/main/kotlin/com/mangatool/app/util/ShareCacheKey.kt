package com.mangatool.app.util

import com.mangatool.app.model.ImageGroup

/**
 * Computes a cache key uniquely representing "what would
 * `ImageSaver.buildShareUris()` currently produce" for a group, or for the
 * whole library — used by `SharePrecacheManager`'s share-URI cache so a tap
 * on Share never hands back a stale set of URIs after the underlying images
 * changed.
 *
 * The previous key (`"$groupIdx" + groupName + displayImages.size`) had two
 * correctness problems this replaces:
 *
 *  1. It used the group's *list position* as its identifier. Chapters can be
 *     reordered (drag-to-reorder), so after a reorder the same chapter's
 *     cache entry would go stale under its old key, and — worse — a
 *     different chapter that happened to land on that same index could be
 *     handed the old chapter's cached URIs outright.
 *  2. It only counted images, never identified which ones or in what order,
 *     and never considered merge mode's pair-swap state at all. Reordering,
 *     filtering, deleting/restoring an image, or swapping a pair's left/right
 *     could all leave the count unchanged while the actual share output
 *     changes completely — every one of those was a stale-cache bug.
 *
 * Every property that changes `buildShareUris()`'s output for a group is
 * represented here:
 *  - the group's stable identity ([ImageGroup.id], not its position)
 *  - which images are in `displayImages`, and in what order (their
 *    `originalIdx` sequence — not just a count)
 *  - pair-swap state ([ImageGroup.pairSwaps]), which only affects — and must
 *    only be considered in — merge mode
 *  - merge direction ([ImageGroup.mergeDirection]) — horizontal vs vertical
 *    compositing produces a different image from the same two source pages
 *  - merge vs extract mode, since the two modes produce structurally
 *    different output from the same group data
 *
 * Deliberately NOT included: `groupName`. Renaming a chapter doesn't change
 * a single byte `buildShareUris()` writes or wraps, so including it would
 * only cause unnecessary cache invalidation on a plain rename.
 *
 * If a future feature adds a user-configurable compression/export option to
 * the share flow, it must be threaded into these keys too — this is the
 * single place that answers "what does the share cache depend on".
 */
object ShareCacheKey {

    /** Cache key for a single group's share URIs. */
    fun forGroup(group: ImageGroup, isMerge: Boolean): String {
        val imageSignature = group.displayImages.joinToString(",") { it.originalIdx.toString() }
        val swapSignature  = if (isMerge) group.pairSwaps.sorted().joinToString(",") else ""
        val directionSignature = if (isMerge) group.mergeDirection.name else ""
        return "${group.id}|$isMerge|$imageSignature|$swapSignature|$directionSignature"
    }

    /**
     * Cache key for a whole-library share (every group's images combined
     * into one chooser Intent). Joins each group's own [forGroup] signature
     * *in list order*, so reordering chapters — which changes the order
     * files are attached to the share Intent — also invalidates this entry,
     * even though no individual group's own signature changed.
     */
    fun forLibrary(groups: List<ImageGroup>, isMerge: Boolean): String =
        groups.joinToString("||") { forGroup(it, isMerge) }
}
