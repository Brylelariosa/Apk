package com.mangatool.app.manager

import android.content.Intent
import android.net.Uri
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.snackbar.Snackbar
import com.mangatool.app.AppMode
import com.mangatool.app.AppState
import com.mangatool.app.MainActivity
import com.mangatool.app.R
import com.mangatool.app.databinding.ActivityMainBinding
import com.mangatool.app.databinding.BottomSheetSaveChoiceBinding
import com.mangatool.app.databinding.BottomSheetSavedBinding
import com.mangatool.app.util.CbzCreator
import com.mangatool.app.util.FileNameSanitizer
import com.mangatool.app.util.FolderSaver
import com.mangatool.app.util.ImageMerger
import com.mangatool.app.util.ImageSaver
import com.mangatool.app.util.Prefs
import com.mangatool.app.util.ShareIntentLauncher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Owns the "write the current library out permanently" flow: choosing
 * Folder vs CBZ, prompting for a name, running the save on a background
 * thread, and presenting the post-save bottom sheet (open in reader /
 * share / done).
 *
 * Depends on [FolderPreferenceManager] rather than reading
 * [com.mangatool.app.util.Prefs] directly, so the "is a folder already
 * chosen, and is it still valid" logic has exactly one owner.
 *
 * Extracted out of the original `FileManager` god class as the "commit to
 * permanent storage" concern, separate from how content enters the library
 * ([FileImportProcessor]) and how it's shared without being permanently
 * saved ([SharePrecacheManager]).
 */
class SaveExportManager(
    private val activity: MainActivity,
    private val b: ActivityMainBinding,
    private val folderPrefs: FolderPreferenceManager
) {

    // ── Write-permission launcher (pre-Android-10 CBZ save) ───────────────────
    // The launcher's callback is fixed once at registration time and can't take
    // a parameter, so the action to run on success is stashed here by
    // checkWritePermission() and invoked from the callback. Previously this
    // callback only handled the denial case — on grant, nothing happened, so
    // saving as CBZ without pre-granted storage permission silently did
    // nothing the first time the user tapped it (only working on a second tap,
    // once permission was already granted from the first attempt).
    private var pendingPermissionGranted: (() -> Unit)? = null

    private val permLauncher = activity.registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
    ) { granted ->
        val action = pendingPermissionGranted
        pendingPermissionGranted = null
        if (granted) action?.invoke()
        else Toast.makeText(activity, activity.getString(R.string.permission_storage_needed), Toast.LENGTH_LONG).show()
    }

    /** Tapping the Save (folder) icon: Merge mode only ever saves to a folder,
     *  so it skips straight there. Extract mode can save either way, so it
     *  opens a bottom sheet to ask Folder vs CBZ. */
    fun onSaveClicked() {
        if (AppState.groups.isEmpty()) return
        if (AppState.currentMode == AppMode.MERGE) startSave(asCbz = false)
        else showSaveFormatSheet()
    }

    private fun showSaveFormatSheet() {
        val dialog = BottomSheetDialog(activity, com.google.android.material.R.style.Theme_Material3_Dark_BottomSheetDialog)
        val sheet  = BottomSheetSaveChoiceBinding.inflate(activity.layoutInflater)
        dialog.setContentView(sheet.root)

        sheet.btnSaveFolder.setOnClickListener { dialog.dismiss(); startSave(asCbz = false) }
        sheet.btnSaveCbz.setOnClickListener    { dialog.dismiss(); startSave(asCbz = true) }
        sheet.tvSaveChoiceCancel.setOnClickListener { dialog.dismiss() }
        dialog.show()
    }

    private fun startSave(asCbz: Boolean) {
        if (AppState.groups.isEmpty()) return
        when {
            asCbz -> checkWritePermission { showCbzNameDialog() }
            AppState.currentMode == AppMode.MERGE -> {
                // getValidFolderUri() calls DocumentFile.canWrite(), a real
                // Binder IPC round-trip to the DocumentsProvider — on a slow
                // or removable storage backend this can visibly stall the UI
                // if run directly on the thread that handled the click.
                activity.lifecycleScope.launch {
                    val savedUri = withContext(Dispatchers.IO) { folderPrefs.getValidFolderUri(isMerge = true) }
                    if (savedUri != null) showMergeNameDialog(savedUri)
                    else                  openSettingsToSetFolder(isMerge = true)
                }
            }
            else -> {
                activity.lifecycleScope.launch {
                    val savedUri = withContext(Dispatchers.IO) { folderPrefs.getValidFolderUri(isMerge = false) }
                    if (savedUri != null) performSaveExtract(savedUri)
                    else                  openSettingsToSetFolder(isMerge = false)
                }
            }
        }
    }

    /** No folder set yet — open Settings panel and highlight the right Choose button */
    private fun openSettingsToSetFolder(isMerge: Boolean) {
        // 1. Open the settings panel
        b.settingsPanel.visibility = View.VISIBLE

        // 2. Identify the row and button to highlight
        val row    = if (isMerge) b.rowMergeFolder    else b.rowExtractFolder
        val btn    = if (isMerge) b.btnSetMergeFolder else b.btnSetExtractFolder
        val label  = if (isMerge) "Merge"             else "Extract"

        // 3. Scroll the row into view (it may be offscreen)
        row.post { row.requestRectangleOnScreen(android.graphics.Rect(0, 0, row.width, row.height), true) }

        // 4. Pulse the row with an accent highlight 3× so the user sees it
        val accentColor  = androidx.core.content.ContextCompat.getColor(activity, R.color.primary)
        val transparent  = android.graphics.Color.TRANSPARENT
        val pulse = android.animation.ObjectAnimator.ofArgb(row, "backgroundColor", transparent, accentColor, transparent)
        pulse.duration      = 500
        pulse.repeatCount   = 2
        pulse.repeatMode    = android.animation.ValueAnimator.REVERSE
        pulse.startDelay    = 200
        pulse.start()

        // 5. Show a Snackbar anchored above the action bar
        Snackbar
            .make(b.root, activity.getString(R.string.set_save_folder_first, label), Snackbar.LENGTH_LONG)
            .setAction("Choose") { btn.performClick() }
            .setAnchorView(b.actionBar)
            .show()
    }

    /** Merge — folder already known: just ask for the photo name */
    private fun showMergeNameDialog(treeUri: Uri) {
        val default = if (AppState.groups.size == 1) AppState.groups[0].groupName else "Merged"
        val input = EditText(activity).apply {
            setText(default); setSelection(0, default.length)
            hint = "e.g. Chapter 1"; setPadding(48, 24, 48, 8)
        }
        val totalPairs = AppState.groups.sumOf { ImageMerger.pairImages(it.displayImages).size }
        val hint = if (totalPairs == 1) "Saves as: Name.png"
                   else "Saves as: Name_1.png, Name_2.png…"
        android.app.AlertDialog.Builder(activity)
            .setTitle(activity.getString(R.string.name_your_photos))
            .setMessage("Folder: ${Prefs.mergeFolderName}\n$hint")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val name = FileNameSanitizer.sanitize(input.text.toString(), default)
                performSaveMerge(treeUri, name)
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun showCbzNameDialog() {
        val default = if (AppState.groups.size == 1) AppState.groups[0].groupName else "Manga_Batch"
        val input = EditText(activity).apply {
            setText(default); setSelection(0, default.length)
            hint = "CBZ filename"; setPadding(48, 24, 48, 8)
        }
        android.app.AlertDialog.Builder(activity).setTitle("Save as CBZ").setView(input)
            .setPositiveButton(activity.getString(R.string.btn_save)) { _, _ ->
                val raw = FileNameSanitizer.sanitize(input.text.toString(), default)
                performSaveCbz(if (raw.endsWith(".cbz", true)) raw else "$raw.cbz")
            }
            .setNegativeButton(activity.getString(R.string.btn_cancel), null).show()
    }

    // ── Save workers ───────────────────────────────────────────────────────────
    private fun performSaveExtract(treeUri: Uri) {
        b.btnDownload.isEnabled = false
        b.progressArea.visibility = View.VISIBLE
        activity.lifecycleScope.launch(Dispatchers.IO) {
            runCatching {
                FolderSaver.saveExtractToTree(activity, treeUri, AppState.groups) { p ->
                    activity.lifecycleScope.launch(Dispatchers.Main) {
                        b.progressStatus.text = p.message; b.progressBar.progress = p.percent
                    }
                }
            }.onSuccess { result ->
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE
                    b.btnDownload.isEnabled = true
                    val subtitle = if (AppState.groups.size == 1)
                        "${result.count} images → ${result.folderName}/${AppState.groups[0].groupName}"
                    else
                        "${result.count} images → ${result.folderName}"
                    showSavedSheet(activity.getString(R.string.saved_exclamation), subtitle, emptyList(), saveFirst = true)
                }
            }.onFailure { e ->
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE
                    b.btnDownload.isEnabled = true
                    Toast.makeText(activity, activity.getString(R.string.toast_failed, e.message), Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun performSaveMerge(treeUri: Uri, photoName: String) {
        b.btnDownload.isEnabled = false
        b.progressArea.visibility = View.VISIBLE
        activity.lifecycleScope.launch(Dispatchers.IO) {
            runCatching {
                FolderSaver.saveMergeToTree(activity, treeUri, AppState.groups, photoName) { p ->
                    activity.lifecycleScope.launch(Dispatchers.Main) {
                        b.progressStatus.text = p.message; b.progressBar.progress = p.percent
                    }
                }
            }.onSuccess { result ->
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE
                    b.btnDownload.isEnabled   = true
                    showSavedSheet(
                        title     = "Saved ${result.count} photos",
                        subtitle  = "$photoName.png in ${result.folderName}",
                        shareUris = emptyList(),
                        saveFirst = true
                    )
                }
            }.onFailure { e ->
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE
                    b.btnDownload.isEnabled   = true
                    Toast.makeText(activity, activity.getString(R.string.toast_failed, e.message), Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun performSaveCbz(filename: String) {
        b.btnDownload.isEnabled = false
        b.progressArea.visibility = View.VISIBLE
        activity.lifecycleScope.launch(Dispatchers.IO) {
            runCatching {
                val uri = CbzCreator.create(activity, AppState.groups, filename, false) { p ->
                    activity.lifecycleScope.launch(Dispatchers.Main) {
                        b.progressStatus.text = p.message; b.progressBar.progress = p.percent
                    }
                }
                ImageSaver.SaveResult(listOf(uri), filename)
            }.onSuccess { result ->
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE
                    b.btnDownload.isEnabled = true
                    showSavedSheet("Saved: $filename", "Downloads/$filename", result.uris, saveFirst = true)
                }
            }.onFailure { e ->
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE
                    b.btnDownload.isEnabled = true
                    Toast.makeText(activity, activity.getString(R.string.toast_failed, e.message), Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    // ── Saved bottom sheet ─────────────────────────────────────────────────────
    private fun showSavedSheet(title: String, subtitle: String, shareUris: List<Uri>, saveFirst: Boolean) {
        val dialog = BottomSheetDialog(activity, com.google.android.material.R.style.Theme_Material3_Dark_BottomSheetDialog)
        val sheet  = BottomSheetSavedBinding.inflate(activity.layoutInflater)
        dialog.setContentView(sheet.root)
        sheet.tvSavedTitle.text    = title
        sheet.tvSavedFilename.text = subtitle

        // Open in reader — only for a single CBZ
        sheet.btnOpenReader.visibility = if (saveFirst && shareUris.size == 1) View.VISIBLE else View.GONE
        sheet.btnOpenReader.setOnClickListener {
            dialog.dismiss()
            runCatching {
                activity.startActivity(Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(shareUris[0], "application/x-cbz")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                })
            }.onFailure { Toast.makeText(activity, activity.getString(R.string.no_cbz_reader), Toast.LENGTH_SHORT).show() }
        }

        // Share button — only when there are URIs (folder saves have none)
        sheet.btnShare.visibility = if (shareUris.isNotEmpty()) View.VISIBLE else View.GONE
        sheet.btnShare.setOnClickListener { dialog.dismiss(); ShareIntentLauncher.launch(activity, shareUris) }

        sheet.btnDone.setOnClickListener { dialog.dismiss() }
        dialog.show()
    }

    private fun checkWritePermission(onGranted: () -> Unit) {
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.Q &&
            androidx.core.content.ContextCompat.checkSelfPermission(activity, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            pendingPermissionGranted = onGranted
            permLauncher.launch(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
        } else {
            onGranted()
        }
    }
}
