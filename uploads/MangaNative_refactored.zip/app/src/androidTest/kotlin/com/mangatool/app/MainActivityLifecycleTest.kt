package com.mangatool.app

import androidx.test.core.app.ActivityScenario
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.click
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.matcher.ViewMatchers.isDisplayed
import androidx.test.espresso.matcher.ViewMatchers.withId
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.mangatool.app.model.ImageGroup
import com.mangatool.app.model.ImageItem
import org.junit.After
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Instrumented tests for MainActivity's lifecycle behavior: surviving
 * Activity recreation (configuration changes such as rotation), the Reset
 * action's cache invalidation, and Extract/Merge mode switching.
 *
 * Written to standard AndroidX Test + Espresso conventions; run via
 * `./gradlew connectedAndroidTest` on a device or emulator.
 */
@RunWith(AndroidJUnit4::class)
class MainActivityLifecycleTest {

    @Before
    fun setUp() {
        AppState.resetAll()
    }

    @After
    fun tearDown() {
        AppState.resetAll()
    }

    private fun seedOneGroup() {
        val group = ImageGroup("Recreate Test")
        group.allImages.add(ImageItem(originalIdx = 0, filePath = "/nonexistent.jpg", ext = "jpg", size = 1))
        AppState.currentMode = AppMode.EXTRACT
        AppState.groups.add(group)
        AppState.applyFilters()
    }

    @Test
    fun activityRecreation_survivesWithLibraryStateIntact() {
        seedOneGroup()
        ActivityScenario.launch(MainActivity::class.java).use { scenario ->
            // AppState is a process-wide singleton, not Activity-scoped state,
            // so recreating the Activity (simulating a rotation or other
            // configuration change) must not lose or duplicate the library —
            // MainActivity's chapter list simply needs to rebind to the same
            // AppState.groups on the new instance.
            scenario.recreate()

            org.junit.Assert.assertEquals(1, AppState.groups.size)
            onView(withId(R.id.action_bar)).check(matches(isDisplayed()))
        }
    }

    @Test
    fun resetButton_clearsLibraryAndReturnsToEmptyState() {
        seedOneGroup()
        ActivityScenario.launch(MainActivity::class.java).use {
            onView(withId(R.id.btn_reset)).perform(click())

            org.junit.Assert.assertTrue(AppState.groups.isEmpty())
            onView(withId(R.id.drop_zone)).check(matches(isDisplayed()))
        }
    }

    @Test
    fun switchingToMergeModeAndBack_survivesActivityRecreation() {
        ActivityScenario.launch(MainActivity::class.java).use { scenario ->
            onView(withId(R.id.tab_merge)).perform(click())
            org.junit.Assert.assertEquals(AppMode.MERGE, AppState.currentMode)

            scenario.recreate()

            // Mode is process-wide AppState, not saved/restored Activity
            // instance state — it must still read as MERGE after recreation,
            // and the UI must rebuild without crashing against merge-mode
            // groups (which, e.g., never populate filteredImages).
            org.junit.Assert.assertEquals(AppMode.MERGE, AppState.currentMode)
            onView(withId(R.id.tab_merge)).check(matches(isDisplayed()))
        }
    }
}
