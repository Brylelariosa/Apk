package com.mangatool.app

import android.content.Intent
import androidx.lifecycle.Lifecycle
import androidx.test.core.app.ActivityScenario
import androidx.test.core.app.ApplicationProvider
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.click
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.matcher.ViewMatchers.isDisplayed
import androidx.test.espresso.matcher.ViewMatchers.withId
import androidx.test.espresso.matcher.ViewMatchers.withText
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.mangatool.app.model.ImageGroup
import com.mangatool.app.model.ImageItem
import org.junit.After
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File

/**
 * Instrumented tests for ImagePreviewActivity's delete/undo flow, covering
 * the Priority 2 fix: deleting the LAST image in a group must close the
 * Activity instead of leaving it open with an empty pager, while deleting
 * with images remaining — and Undo in either case — must behave exactly as
 * before.
 *
 * Written to standard AndroidX Test + Espresso conventions; run via
 * `./gradlew connectedAndroidTest` on a device or emulator. Real (empty)
 * files back each ImageItem so Glide has something to attempt loading
 * without crashing; the pixel content is irrelevant to this flow.
 */
@RunWith(AndroidJUnit4::class)
class ImagePreviewDeleteFlowTest {

    private lateinit var tempDir: File

    @Before
    fun setUp() {
        AppState.resetAll()
        val context = ApplicationProvider.getApplicationContext<android.content.Context>()
        tempDir = File(context.cacheDir, "preview_flow_test").apply { mkdirs() }
    }

    @After
    fun tearDown() {
        AppState.resetAll()
        tempDir.deleteRecursively()
    }

    private fun fakeImage(idx: Int): ImageItem {
        val file = File(tempDir, "$idx.jpg").apply { writeText("x") }
        return ImageItem(originalIdx = idx, filePath = file.absolutePath, ext = "jpg", size = 1)
    }

    private fun seedGroup(imageCount: Int): ImageGroup {
        val group = ImageGroup("Test Chapter")
        group.allImages.addAll((0 until imageCount).map { fakeImage(it) })
        AppState.currentMode = AppMode.EXTRACT
        AppState.groups.add(group)
        AppState.applyFilters()
        return group
    }

    private fun launchPreview(groupIdx: Int = 0): ActivityScenario<ImagePreviewActivity> {
        val intent = Intent(
            ApplicationProvider.getApplicationContext(), ImagePreviewActivity::class.java
        ).apply {
            putExtra(ImagePreviewActivity.EXTRA_GROUP_IDX, groupIdx)
        }
        return ActivityScenario.launch(intent)
    }

    @Test
    fun deletingOneOfSeveralImages_showsUndoSnackbarAndKeepsActivityOpen() {
        seedGroup(imageCount = 3)
        launchPreview().use { scenario ->
            onView(withId(R.id.delete_btn)).perform(click())

            onView(withText("Image deleted")).check(matches(isDisplayed()))
            assert(scenario.state == Lifecycle.State.RESUMED) {
                "Activity should remain open with 2 images left"
            }
        }
    }

    @Test
    fun undoAfterDelete_restoresTheImageAndDoesNotFinish() {
        seedGroup(imageCount = 2)
        launchPreview().use { scenario ->
            onView(withId(R.id.delete_btn)).perform(click())
            onView(withText("Undo")).perform(click())

            // Counter should reflect both images again — "1 / 2".
            onView(withId(R.id.preview_counter)).check(matches(withText("1 / 2")))
            assert(scenario.state == Lifecycle.State.RESUMED)
        }
    }

    @Test
    fun deletingTheLastRemainingImage_eventuallyFinishesTheActivity() {
        seedGroup(imageCount = 1)
        launchPreview().use { scenario ->
            onView(withId(R.id.delete_btn)).perform(click())

            // The Snackbar (LENGTH_LONG, ~2.75s) must resolve before the
            // finish() decision fires — see the dismiss-callback fix in
            // ImagePreviewActivity.handleAction(). This is the core Priority 2
            // regression check: previously the "pending == null" condition
            // guarding finish() was always false immediately after deletion,
            // so the Activity never closed at all, regardless of how long the
            // test waited.
            Thread.sleep(3_500L)

            assert(scenario.state == Lifecycle.State.DESTROYED) {
                "Activity should have finished after deleting its only image " +
                    "and letting the undo Snackbar resolve without interaction"
            }
        }
    }

    @Test
    fun undoingTheLastImageDeletion_keepsTheActivityOpen() {
        seedGroup(imageCount = 1)
        launchPreview().use { scenario ->
            onView(withId(R.id.delete_btn)).perform(click())
            onView(withText("Undo")).perform(click())

            // Give the (no-op, since Undo already resolved the pending state)
            // dismiss callback time to run, then confirm the Activity is
            // still open with its one image back.
            Thread.sleep(3_500L)

            assert(scenario.state == Lifecycle.State.RESUMED) {
                "Undo must keep the Activity open even for the last image"
            }
            onView(withId(R.id.preview_counter)).check(matches(withText("1 / 1")))
        }
    }
}
