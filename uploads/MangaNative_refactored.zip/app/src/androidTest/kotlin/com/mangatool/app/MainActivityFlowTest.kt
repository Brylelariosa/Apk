package com.mangatool.app

import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.click
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.matcher.ViewMatchers.isDisplayed
import androidx.test.espresso.matcher.ViewMatchers.withId
import androidx.test.ext.junit.rules.ActivityScenarioRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Instrumented tests for MainActivity's critical, always-available flows:
 * the empty-library state, Extract/Merge mode switching, and the settings
 * panel toggle. These do not depend on a real MHTML import (see
 * MhtmlImportFlowTest for that), so they exercise the same UI state every
 * run regardless of device/emulator storage contents.
 *
 * Written to standard AndroidX Test + Espresso conventions; run via
 * `./gradlew connectedAndroidTest` on a device or emulator.
 */
@RunWith(AndroidJUnit4::class)
class MainActivityFlowTest {

    @get:Rule
    val activityRule = ActivityScenarioRule(MainActivity::class.java)

    @Before
    fun resetLibraryState() {
        // A fresh AppState per test avoids one test's imported/merged groups
        // leaking into the next — AppState is a process-wide singleton.
        AppState.resetAll()
    }

    @Test
    fun emptyLibrary_showsDropZoneAndHidesActionBar() {
        onView(withId(R.id.drop_zone)).check(matches(isDisplayed()))
    }

    @Test
    fun tabExtract_isSelectedByDefault() {
        // Default AppMode is EXTRACT — the settings panel's folder rows and
        // the merge-only tip should reflect Extract mode from a cold start.
        onView(withId(R.id.tab_extract)).check(matches(isDisplayed()))
        onView(withId(R.id.tab_merge)).check(matches(isDisplayed()))
    }

    @Test
    fun tappingMergeTab_switchesModeWithoutCrashing() {
        onView(withId(R.id.tab_merge)).perform(click())
        onView(withId(R.id.tab_merge)).check(matches(isDisplayed()))
        // Switching back should also work cleanly — mode switches are
        // reversible and must not leave the UI in a broken state.
        onView(withId(R.id.tab_extract)).perform(click())
        onView(withId(R.id.tab_extract)).check(matches(isDisplayed()))
    }

    @Test
    fun settingsToggle_opensAndClosesSettingsPanel() {
        onView(withId(R.id.settings_toggle)).perform(click())
        onView(withId(R.id.settings_panel)).check(matches(isDisplayed()))

        // Toggling again closes it — the settings panel is a simple
        // show/hide, not a one-way navigation.
        onView(withId(R.id.settings_toggle)).perform(click())
    }
}
