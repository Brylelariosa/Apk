package com.mangatool.app

import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.click
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.matcher.ViewMatchers.isDisplayed
import androidx.test.espresso.matcher.ViewMatchers.withId
import androidx.test.espresso.matcher.ViewMatchers.withText
import androidx.test.ext.junit.rules.ActivityScenarioRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Instrumented tests for InternalFileManagerActivity's sort controls — the
 * built-in file browser used as a fallback when the user has no external
 * file manager app installed. Covers the FileSorter/FileSortBy integration:
 * tapping a sort button changes the active field, and tapping the same
 * button again flips the direction arrow.
 *
 * Written to standard AndroidX Test + Espresso conventions; run via
 * `./gradlew connectedAndroidTest` on a device or emulator.
 */
@RunWith(AndroidJUnit4::class)
class InternalFileManagerActivityTest {

    @get:Rule
    val activityRule = ActivityScenarioRule(InternalFileManagerActivity::class.java)

    @Test
    fun sortButtons_areVisibleOnLaunch() {
        onView(withId(R.id.btnSortName)).check(matches(isDisplayed()))
        onView(withId(R.id.btnSortDate)).check(matches(isDisplayed()))
        onView(withId(R.id.btnSortType)).check(matches(isDisplayed()))
    }

    @Test
    fun nameSortButton_showsAscendingArrowByDefault() {
        // Default sort is NAME ascending — see Prefs.fileSortBy/fileSortAscending
        // defaults, mirrored by FileSorter's default in InternalFileManagerActivity.
        onView(withId(R.id.btnSortName)).check(matches(withText("Name ▲")))
    }

    @Test
    fun tappingActiveSortButtonAgain_flipsDirectionArrow() {
        onView(withId(R.id.btnSortName)).perform(click())
        onView(withId(R.id.btnSortName)).check(matches(withText("Name ▼")))

        onView(withId(R.id.btnSortName)).perform(click())
        onView(withId(R.id.btnSortName)).check(matches(withText("Name ▲")))
    }

    @Test
    fun tappingDateSortButton_switchesActiveFieldToDate() {
        onView(withId(R.id.btnSortDate)).perform(click())
        onView(withId(R.id.btnSortDate)).check(matches(withText("Date ▲")))
        // Switching the active field resets the OTHER buttons' label back to
        // their plain (non-arrow) form.
        onView(withId(R.id.btnSortName)).check(matches(withText("Name")))
    }
}
