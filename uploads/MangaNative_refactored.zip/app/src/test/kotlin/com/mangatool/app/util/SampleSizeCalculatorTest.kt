package com.mangatool.app.util

import org.junit.Assert.assertEquals
import org.junit.Test

class SampleSizeCalculatorTest {

    // ── computeMinAxis ───────────────────────────────────────────────────────

    @Test
    fun `minAxis returns 1 when source is already at or below target`() {
        assertEquals(1, SampleSizeCalculator.computeMinAxis(200, 200, 256))
        assertEquals(1, SampleSizeCalculator.computeMinAxis(256, 256, 256))
    }

    @Test
    fun `minAxis doubles sample while BOTH dimensions stay above target`() {
        // 2048 / 2 = 1024 >= 256, 2048 / 4 = 512 >= 256, 2048 / 8 = 256 >= 256(false, stop before hitting exactly target via *2 rule)
        // Trace: sample=1 -> check 2048/2=1024>=256 true -> sample=2
        //        check 2048/4=512>=256 true -> sample=4
        //        check 2048/8=256>=256 true -> sample=8
        //        check 2048/16=128>=256 false -> stop
        assertEquals(8, SampleSizeCalculator.computeMinAxis(2048, 2048, 256))
    }

    @Test
    fun `minAxis is driven by the SMALLER of the two dimensions`() {
        // width=2048 (would allow sample=8), height=300 (only allows sample=1
        // since 300/2=150 < 256) -> the smaller dimension must govern, so the
        // result must respect height, not width.
        val sample = SampleSizeCalculator.computeMinAxis(2048, 300, 256)
        assertEquals(1, sample)
    }

    @Test
    fun `minAxis handles non-square images without dropping either axis below target`() {
        val sample = SampleSizeCalculator.computeMinAxis(1024, 512, 256)
        // Governed by height=512: 512/2=256>=256 true -> sample=2; 512/4=128>=256 false -> stop.
        assertEquals(2, sample)
    }

    @Test
    fun `minAxis returns 1 for degenerate zero or negative input instead of looping forever`() {
        assertEquals(1, SampleSizeCalculator.computeMinAxis(0, 0, 256))
        assertEquals(1, SampleSizeCalculator.computeMinAxis(100, 100, 0))
        assertEquals(1, SampleSizeCalculator.computeMinAxis(-5, 100, 256))
    }

    // ── computeMaxAxis ───────────────────────────────────────────────────────

    @Test
    fun `maxAxis returns 1 when source is already at or below target`() {
        assertEquals(1, SampleSizeCalculator.computeMaxAxis(300, 200, 400))
    }

    @Test
    fun `maxAxis is driven by the LARGER of the two dimensions`() {
        // width=2000 (large), height=100 (small). Governed by width: even
        // though height is tiny, sampling still proceeds based on width.
        val sample = SampleSizeCalculator.computeMaxAxis(2000, 100, 400)
        // 2000/2=1000>=400 true -> 2; 2000/4=500>=400 true -> 4; 2000/8=250>=400 false -> stop
        assertEquals(4, sample)
    }

    @Test
    fun `maxAxis and minAxis agree for square images`() {
        val target = 256
        val size = 4096
        assertEquals(
            SampleSizeCalculator.computeMinAxis(size, size, target),
            SampleSizeCalculator.computeMaxAxis(size, size, target)
        )
    }

    @Test
    fun `maxAxis returns 1 for degenerate input`() {
        assertEquals(1, SampleSizeCalculator.computeMaxAxis(0, 500, 400))
        assertEquals(1, SampleSizeCalculator.computeMaxAxis(500, 500, -1))
    }

    @Test
    fun `sample size is always a power of two`() {
        val sample = SampleSizeCalculator.computeMaxAxis(10000, 8000, 300)
        assertEquals(0, sample and (sample - 1)) // classic power-of-two check
    }
}
