package com.mangatool.app.util

import org.junit.Assert.assertEquals
import org.junit.Test

class ByteSizeFormatterTest {

    // ── formatKilobytes (main-screen stats line) ────────────────────────────

    @Test
    fun `formatKilobytes shows plain KB under the 1024 threshold`() {
        assertEquals("512 KB", ByteSizeFormatter.formatKilobytes(512))
        assertEquals("1024 KB", ByteSizeFormatter.formatKilobytes(1024)) // boundary: NOT > 1024
    }

    @Test
    fun `formatKilobytes switches to one-decimal MB above the threshold`() {
        assertEquals("2.0 MB", ByteSizeFormatter.formatKilobytes(2048))
        assertEquals("1.5 MB", ByteSizeFormatter.formatKilobytes(1536))
    }

    @Test
    fun `formatKilobytes handles zero`() {
        assertEquals("0 KB", ByteSizeFormatter.formatKilobytes(0))
    }

    // ── formatBytes (file-manager per-row size) ─────────────────────────────

    @Test
    fun `formatBytes shows plain bytes under 1024`() {
        assertEquals("512 B", ByteSizeFormatter.formatBytes(512))
        assertEquals("0 B", ByteSizeFormatter.formatBytes(0))
    }

    @Test
    fun `formatBytes shows whole KB between 1024 and 1 MB`() {
        assertEquals("2 KB", ByteSizeFormatter.formatBytes(2048))
        assertEquals("1 KB", ByteSizeFormatter.formatBytes(1024))
    }

    @Test
    fun `formatBytes shows decimal MB at and above 1 MB`() {
        assertEquals("3 MB", ByteSizeFormatter.formatBytes(3 * 1_048_576L))
        assertEquals("1.5 MB", ByteSizeFormatter.formatBytes((1.5 * 1_048_576).toLong()))
    }
}
