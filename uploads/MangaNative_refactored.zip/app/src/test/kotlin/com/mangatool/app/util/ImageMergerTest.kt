package com.mangatool.app.util

import com.mangatool.app.model.ImageItem
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Covers [ImageMerger.pairImages] only. [ImageMerger.merge] and
 * [ImageMerger.mergeThumbnail] decode real [android.graphics.Bitmap]s via
 * [BitmapUtils] and compose them with [android.graphics.Canvas] — both are
 * Android framework classes with no meaningful JVM-only fake, so those two
 * functions are exercised by the instrumented tests instead (see
 * ImageMergeFlowTest), which run against the real framework on a device.
 */
class ImageMergerTest {

    private fun img(idx: Int) = ImageItem(
        originalIdx = idx, filePath = "/tmp/$idx.jpg", ext = "jpg", size = 1024
    )

    @Test
    fun `pairs consecutive images two at a time`() {
        val images = (0..3).map { img(it) }

        val pairs = ImageMerger.pairImages(images)

        assertEquals(2, pairs.size)
        assertEquals(listOf(0, 1), pairs[0].map { it.originalIdx })
        assertEquals(listOf(2, 3), pairs[1].map { it.originalIdx })
    }

    @Test
    fun `odd count leaves a trailing single-item pair`() {
        val images = (0..4).map { img(it) }

        val pairs = ImageMerger.pairImages(images)

        assertEquals(3, pairs.size)
        assertEquals(1, pairs.last().size)
        assertEquals(4, pairs.last()[0].originalIdx)
    }

    @Test
    fun `empty list produces no pairs`() {
        assertTrue(ImageMerger.pairImages(emptyList()).isEmpty())
    }

    @Test
    fun `single image produces one pair of size one`() {
        val pairs = ImageMerger.pairImages(listOf(img(0)))
        assertEquals(1, pairs.size)
        assertEquals(1, pairs[0].size)
    }
}
