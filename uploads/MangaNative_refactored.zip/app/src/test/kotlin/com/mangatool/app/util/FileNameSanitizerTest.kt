package com.mangatool.app.util

import org.junit.Assert.assertEquals
import org.junit.Test

class FileNameSanitizerTest {

    @Test
    fun `leaves an already-safe name unchanged`() {
        assertEquals("Chapter 1", FileNameSanitizer.sanitize("Chapter 1", "fallback"))
    }

    @Test
    fun `replaces every illegal path character with underscore`() {
        val result = FileNameSanitizer.sanitize("""a\b/c:d*e?f"g<h>i|j""", "fallback")
        assertEquals("a_b_c_d_e_f_g_h_i_j", result)
    }

    @Test
    fun `trims surrounding whitespace`() {
        assertEquals("Chapter 1", FileNameSanitizer.sanitize("  Chapter 1  ", "fallback"))
    }

    @Test
    fun `falls back when input is blank`() {
        assertEquals("fallback", FileNameSanitizer.sanitize("", "fallback"))
        assertEquals("fallback", FileNameSanitizer.sanitize("   ", "fallback"))
    }

    @Test
    fun `falls back when input is only illegal characters`() {
        assertEquals("fallback", FileNameSanitizer.sanitize("///", "fallback"))
    }

    @Test
    fun `preserves internal spaces and unicode text`() {
        assertEquals("One Piece 第1話", FileNameSanitizer.sanitize("One Piece 第1話", "fallback"))
    }

    @Test
    fun `does not alter dots or hyphens which are legal path characters`() {
        assertEquals("v1.2-final", FileNameSanitizer.sanitize("v1.2-final", "fallback"))
    }
}
