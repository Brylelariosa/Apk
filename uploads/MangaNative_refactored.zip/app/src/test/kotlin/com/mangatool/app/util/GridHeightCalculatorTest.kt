package com.mangatool.app.util

import org.junit.Assert.assertEquals
import org.junit.Test

class GridHeightCalculatorTest {

    private val density = 2.0f // e.g. a 320dpi (xhdpi-ish) test device

    @Test
    fun `zero items yields zero height`() {
        assertEquals(0, GridHeightCalculator.computeGridHeightPx(0, isMerge = false, density = density))
        assertEquals(0, GridHeightCalculator.computeGridHeightPx(0, isMerge = true, density = density))
        assertEquals(0, GridHeightCalculator.computeFilteredHeightPx(0, density = density))
    }

    @Test
    fun `extract grid uses 3 columns`() {
        // 7 items / 3 cols = 3 rows (ceil). rows*134 + 12 = 3*134+12 = 414dp. *density(2) = 828px.
        val h = GridHeightCalculator.computeGridHeightPx(7, isMerge = false, density = density)
        assertEquals(828, h)
    }

    @Test
    fun `extract grid with an exact multiple of 3 needs no extra row`() {
        // 6 items / 3 cols = exactly 2 rows. 2*134+12 = 280dp * 2 = 560px.
        val h = GridHeightCalculator.computeGridHeightPx(6, isMerge = false, density = density)
        assertEquals(560, h)
    }

    @Test
    fun `merge grid uses 2 columns and a taller row height`() {
        // 5 items / 2 cols = 3 rows (ceil). 3*156+12 = 480dp * 2 = 960px.
        val h = GridHeightCalculator.computeGridHeightPx(5, isMerge = true, density = density)
        assertEquals(960, h)
    }

    @Test
    fun `vertical merge grid uses a taller row height than horizontal`() {
        // 5 items / 2 cols = 3 rows (ceil). 3*276+12 = 840dp * 2 = 1680px.
        val h = GridHeightCalculator.computeGridHeightPx(
            5, isMerge = true, density = density, mergeDirection = com.mangatool.app.model.MergeDirection.VERTICAL
        )
        assertEquals(1680, h)
    }

    @Test
    fun `merge direction is ignored in extract mode`() {
        val horizontal = GridHeightCalculator.computeGridHeightPx(6, isMerge = false, density = density)
        val vertical = GridHeightCalculator.computeGridHeightPx(
            6, isMerge = false, density = density, mergeDirection = com.mangatool.app.model.MergeDirection.VERTICAL
        )
        assertEquals(horizontal, vertical)
    }

    @Test
    fun `filtered strip uses 3 columns and its own row height`() {
        // 4 items / 3 cols = 2 rows (ceil). 2*136+12 = 284dp * 2 = 568px.
        val h = GridHeightCalculator.computeFilteredHeightPx(4, density = density)
        assertEquals(568, h)
    }

    @Test
    fun `scales linearly with density`() {
        val at1x = GridHeightCalculator.computeGridHeightPx(3, isMerge = false, density = 1.0f)
        val at3x = GridHeightCalculator.computeGridHeightPx(3, isMerge = false, density = 3.0f)
        assertEquals(at1x * 3, at3x)
    }

    @Test
    fun `single item still allocates one full row`() {
        // 1 item / 3 cols = 1 row. (134+12)*2 = 292px.
        assertEquals(292, GridHeightCalculator.computeGridHeightPx(1, isMerge = false, density = density))
    }
}
