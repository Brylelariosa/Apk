package com.mangatool.app.util

import org.junit.Assert.assertEquals
import org.junit.Test

class MimeTypesTest {

    @Test
    fun `maps common image extensions to their mime type`() {
        assertEquals("image/jpeg", MimeTypes.forImageExtension("jpg"))
        assertEquals("image/jpeg", MimeTypes.forImageExtension("jpeg"))
        assertEquals("image/png", MimeTypes.forImageExtension("png"))
        assertEquals("image/webp", MimeTypes.forImageExtension("webp"))
        assertEquals("image/gif", MimeTypes.forImageExtension("gif"))
    }

    @Test
    fun `is case-insensitive`() {
        assertEquals("image/jpeg", MimeTypes.forImageExtension("JPG"))
        assertEquals("image/png", MimeTypes.forImageExtension("PNG"))
    }

    @Test
    fun `falls back to image png for an unrecognized extension`() {
        assertEquals("image/png", MimeTypes.forImageExtension("bmp"))
        assertEquals("image/png", MimeTypes.forImageExtension(""))
    }
}
