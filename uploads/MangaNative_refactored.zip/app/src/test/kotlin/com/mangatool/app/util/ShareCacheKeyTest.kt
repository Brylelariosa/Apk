package com.mangatool.app.util

import com.mangatool.app.model.ImageGroup
import com.mangatool.app.model.ImageItem
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Test

class ShareCacheKeyTest {

    private fun img(idx: Int) = ImageItem(
        originalIdx = idx, filePath = "/tmp/$idx.jpg", ext = "jpg", size = 1024
    )

    private fun group(vararg idxs: Int): ImageGroup {
        val g = ImageGroup("Chapter")
        g.displayImages = idxs.map { img(it) }
        return g
    }

    @Test
    fun `same group state produces the same key`() {
        val g = group(0, 1, 2)
        assertEquals(ShareCacheKey.forGroup(g, isMerge = false), ShareCacheKey.forGroup(g, isMerge = false))
    }

    @Test
    fun `two distinct groups with identical content never collide`() {
        // Same images, same order, same mode — but different group identity.
        // This is exactly the reorder-collision case the old groupIdx-based
        // key was vulnerable to.
        val g1 = group(0, 1, 2)
        val g2 = group(0, 1, 2)
        assertNotEquals(ShareCacheKey.forGroup(g1, false), ShareCacheKey.forGroup(g2, false))
    }

    @Test
    fun `reordering the same images changes the key`() {
        val g = group(0, 1, 2)
        val keyBefore = ShareCacheKey.forGroup(g, isMerge = false)

        g.displayImages = listOf(g.displayImages[2], g.displayImages[0], g.displayImages[1])
        val keyAfter = ShareCacheKey.forGroup(g, isMerge = false)

        assertNotEquals(keyBefore, keyAfter)
    }

    @Test
    fun `swapping one image for another changes the key even with the same count`() {
        val g = group(0, 1, 2)
        val keyBefore = ShareCacheKey.forGroup(g, isMerge = false)

        // Replace image 1 with image 3 — same COUNT (3), different content.
        g.displayImages = listOf(g.displayImages[0], img(3), g.displayImages[2])
        val keyAfter = ShareCacheKey.forGroup(g, isMerge = false)

        assertNotEquals(keyBefore, keyAfter)
    }

    @Test
    fun `extract and merge mode never share a key for the same group state`() {
        val g = group(0, 1, 2)
        assertNotEquals(ShareCacheKey.forGroup(g, isMerge = true), ShareCacheKey.forGroup(g, isMerge = false))
    }

    @Test
    fun `pair swap state changes the merge-mode key`() {
        val g = group(0, 1, 2, 3)
        val keyBefore = ShareCacheKey.forGroup(g, isMerge = true)

        g.pairSwaps.add(0) // swap the first pair's left/right

        val keyAfter = ShareCacheKey.forGroup(g, isMerge = true)
        assertNotEquals(keyBefore, keyAfter)
    }

    @Test
    fun `pair swap state is ignored in extract mode, where it has no effect on output`() {
        val g = group(0, 1, 2, 3)
        val keyBefore = ShareCacheKey.forGroup(g, isMerge = false)

        g.pairSwaps.add(0) // irrelevant in extract mode — buildShareUris never reads it there

        val keyAfter = ShareCacheKey.forGroup(g, isMerge = false)
        assertEquals(keyBefore, keyAfter)
    }

    @Test
    fun `swap set insertion order does not affect the key, only membership`() {
        val g = group(0, 1, 2, 3)
        g.pairSwaps.addAll(listOf(1, 0))
        val key1 = ShareCacheKey.forGroup(g, isMerge = true)

        g.pairSwaps.clear()
        g.pairSwaps.addAll(listOf(0, 1)) // same membership, inserted in the opposite order
        val key2 = ShareCacheKey.forGroup(g, isMerge = true)

        assertEquals(key1, key2)
    }

    @Test
    fun `renaming a group does not change its key`() {
        val g = group(0, 1, 2)
        val keyBefore = ShareCacheKey.forGroup(g, isMerge = false)
        g.groupName = "A totally different name"
        val keyAfter = ShareCacheKey.forGroup(g, isMerge = false)
        assertEquals(keyBefore, keyAfter)
    }

    @Test
    fun `forLibrary changes when group order changes even if no group content changed`() {
        val a = group(0, 1)
        val b = group(2, 3)
        val forward  = ShareCacheKey.forLibrary(listOf(a, b), isMerge = false)
        val reversed = ShareCacheKey.forLibrary(listOf(b, a), isMerge = false)
        assertNotEquals(forward, reversed)
    }

    @Test
    fun `forLibrary changes when any one group's content changes`() {
        val a = group(0, 1)
        val b = group(2, 3)
        val before = ShareCacheKey.forLibrary(listOf(a, b), isMerge = false)

        b.displayImages = listOf(img(9))
        val after = ShareCacheKey.forLibrary(listOf(a, b), isMerge = false)

        assertNotEquals(before, after)
    }

    @Test
    fun `merge direction changes the merge-mode key`() {
        val g = group(0, 1, 2, 3)
        g.mergeDirection = com.mangatool.app.model.MergeDirection.HORIZONTAL
        val keyBefore = ShareCacheKey.forGroup(g, isMerge = true)

        g.mergeDirection = com.mangatool.app.model.MergeDirection.VERTICAL
        val keyAfter = ShareCacheKey.forGroup(g, isMerge = true)

        assertNotEquals(keyBefore, keyAfter)
    }

    @Test
    fun `merge direction is ignored in extract mode`() {
        val g = group(0, 1, 2, 3)
        g.mergeDirection = com.mangatool.app.model.MergeDirection.HORIZONTAL
        val keyBefore = ShareCacheKey.forGroup(g, isMerge = false)

        g.mergeDirection = com.mangatool.app.model.MergeDirection.VERTICAL
        val keyAfter = ShareCacheKey.forGroup(g, isMerge = false)

        assertEquals(keyBefore, keyAfter)
    }

    @Test
    fun `empty displayImages still produces a stable, non-crashing key`() {
        val g = ImageGroup("Empty chapter")
        val key = ShareCacheKey.forGroup(g, isMerge = false)
        assertEquals(key, ShareCacheKey.forGroup(g, isMerge = false))
    }
}
