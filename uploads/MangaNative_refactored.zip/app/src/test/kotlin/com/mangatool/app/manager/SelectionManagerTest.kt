package com.mangatool.app.manager

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class SelectionManagerTest {

    private lateinit var sel: SelectionManager<String>

    @Before
    fun setUp() {
        sel = SelectionManager()
    }

    @Test
    fun `new manager is empty`() {
        assertTrue(sel.isEmpty())
        assertEquals(0, sel.size)
    }

    @Test
    fun `select adds item and returns true`() {
        assertTrue(sel.select("a"))
        assertTrue(sel.contains("a"))
        assertEquals(1, sel.size)
    }

    @Test
    fun `select on already-selected item returns false and does not duplicate`() {
        sel.select("a")
        assertFalse(sel.select("a"))
        assertEquals(1, sel.size)
    }

    @Test
    fun `deselect removes item and returns true`() {
        sel.select("a")
        assertTrue(sel.deselect("a"))
        assertFalse(sel.contains("a"))
    }

    @Test
    fun `deselect on absent item returns false`() {
        assertFalse(sel.deselect("missing"))
    }

    @Test
    fun `toggle flips selection state and reports the new state`() {
        assertTrue(sel.toggle("a"))  // now selected
        assertTrue(sel.contains("a"))
        assertFalse(sel.toggle("a")) // now deselected
        assertFalse(sel.contains("a"))
    }

    @Test
    fun `orderOf reflects selection order, not insertion order of an unrelated list`() {
        sel.select("c")
        sel.select("a")
        sel.select("b")

        assertEquals(0, sel.orderOf("c"))
        assertEquals(1, sel.orderOf("a"))
        assertEquals(2, sel.orderOf("b"))
    }

    @Test
    fun `orderOf returns -1 for an unselected item`() {
        assertEquals(-1, sel.orderOf("nope"))
    }

    @Test
    fun `selectAll replaces the entire selection`() {
        sel.select("x")
        sel.selectAll(listOf("a", "b", "c"))

        assertFalse(sel.contains("x"))
        assertEquals(setOf("a", "b", "c"), sel.asSet())
    }

    @Test
    fun `clear empties the selection`() {
        sel.selectAll(listOf("a", "b"))
        sel.clear()
        assertTrue(sel.isEmpty())
    }

    @Test
    fun `isAllSelected is false for an empty selectable list`() {
        assertFalse(sel.isAllSelected(emptyList()))
    }

    @Test
    fun `isAllSelected is true only when every item in the list is selected`() {
        sel.select("a")
        assertFalse(sel.isAllSelected(listOf("a", "b")))
        sel.select("b")
        assertTrue(sel.isAllSelected(listOf("a", "b")))
    }

    @Test
    fun `invert flips only items within the given selectable list`() {
        sel.selectAll(listOf("a", "outside"))

        sel.invert(listOf("a", "b"))

        // "a" was selected -> now deselected; "b" was not -> now selected;
        // "outside" was never part of the selectable set -> untouched.
        assertFalse(sel.contains("a"))
        assertTrue(sel.contains("b"))
        assertTrue(sel.contains("outside"))
    }

    @Test
    fun `asSet is a defensive copy`() {
        sel.select("a")
        val snapshot = sel.asSet()
        sel.select("b")

        assertEquals(1, snapshot.size)
        assertEquals(2, sel.size)
    }
}
