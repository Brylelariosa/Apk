package com.mangatool.app.util

import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

/**
 * [Prefs] wraps [android.content.SharedPreferences], an Android framework
 * class with no meaningful JVM-only fake — Robolectric provides a simulated
 * SharedPreferences backed by an in-memory file so these round-trips can run
 * on the local JVM instead of a device.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [33])
class PrefsTest {

    @Before
    fun setUp() {
        Prefs.init(ApplicationProvider.getApplicationContext())
        // Each test gets a clean slate — SharedPreferences persists to disk
        // by default and Robolectric reuses the same app data dir per class.
        Prefs.extractFolderUri = null
        Prefs.mergeFolderUri = null
    }

    @Test
    fun `minSizeKb defaults to 40`() {
        assertEquals(40, Prefs.minSizeKb)
    }

    @Test
    fun `minSizeKb round-trips through SharedPreferences`() {
        Prefs.minSizeKb = 100
        assertEquals(100, Prefs.minSizeKb)
    }

    @Test
    fun `excludeGifs defaults to true`() {
        assertEquals(true, Prefs.excludeGifs)
    }

    @Test
    fun `boolean prefs round-trip correctly`() {
        Prefs.excludeGifs = false
        assertEquals(false, Prefs.excludeGifs)
        Prefs.reverseOrder = true
        assertEquals(true, Prefs.reverseOrder)
    }

    @Test
    fun `minDimsEnabled defaults to false and the width height defaults are 0`() {
        assertEquals(false, Prefs.minDimsEnabled)
        assertEquals(0, Prefs.minWidth)
        assertEquals(0, Prefs.minHeight)
    }

    @Test
    fun `fileSortBy defaults to NAME and fileSortAscending defaults to true`() {
        assertEquals("NAME", Prefs.fileSortBy)
        assertEquals(true, Prefs.fileSortAscending)
    }

    @Test
    fun `fileSortBy round-trips an arbitrary value`() {
        Prefs.fileSortBy = "DATE"
        assertEquals("DATE", Prefs.fileSortBy)
    }

    @Test
    fun `folder uri prefs default to null and can be cleared back to null`() {
        assertNull(Prefs.extractFolderUri)

        Prefs.extractFolderUri = "content://tree/example"
        assertEquals("content://tree/example", Prefs.extractFolderUri)

        Prefs.extractFolderUri = null
        assertNull(Prefs.extractFolderUri)
    }

    @Test
    fun `extract and merge folder prefs are independent`() {
        Prefs.extractFolderUri = "content://tree/extract"
        Prefs.mergeFolderUri   = "content://tree/merge"

        assertEquals("content://tree/extract", Prefs.extractFolderUri)
        assertEquals("content://tree/merge", Prefs.mergeFolderUri)
    }
}
