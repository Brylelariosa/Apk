package com.mangatool.app.model

import org.junit.Assert.assertEquals
import org.junit.Test

class MergeDirectionTest {

    @Test
    fun `ImageGroup defaults to horizontal merge direction`() {
        val group = ImageGroup("Chapter 1")
        assertEquals(MergeDirection.HORIZONTAL, group.mergeDirection)
    }

    @Test
    fun `ImageGroup mergeDirection is independently mutable per group`() {
        val a = ImageGroup("A")
        val b = ImageGroup("B")
        a.mergeDirection = MergeDirection.VERTICAL

        assertEquals(MergeDirection.VERTICAL, a.mergeDirection)
        assertEquals(MergeDirection.HORIZONTAL, b.mergeDirection)
    }

    @Test
    fun `MergePairDescriptor defaults to horizontal direction`() {
        val descriptor = MergePairDescriptor(pair = emptyList(), swapped = false)
        assertEquals(MergeDirection.HORIZONTAL, descriptor.direction)
    }

    @Test
    fun `MergePairDescriptor direction can be set explicitly`() {
        val descriptor = MergePairDescriptor(pair = emptyList(), swapped = true, direction = MergeDirection.VERTICAL)
        assertEquals(MergeDirection.VERTICAL, descriptor.direction)
        assertEquals(true, descriptor.swapped)
    }
}
