package com.mangatool.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

/**
 * Covers the parts of [MhtmlParser] that are pure functions of their
 * arguments: [MhtmlParser.smartRename], [MhtmlParser.decodeQP], and
 * [MhtmlParser.sniffImageExt]. The actual [MhtmlParser.parse] state machine
 * needs a real MHTML byte stream and writes real files, so it is covered by
 * the instrumented tests instead (see MhtmlImportFlowTest).
 */
class MhtmlParserTest {

    // ── smartRename ──────────────────────────────────────────────────────────

    @Test
    fun `plain filename with no chapter number is returned as-is`() {
        assertEquals("test", MhtmlParser.smartRename("test.mhtml"))
    }

    @Test
    fun `bare trailing number is extracted and zero-padded`() {
        assertEquals("005 - Naruto", MhtmlParser.smartRename("Naruto_5.mhtml"))
    }

    @Test
    fun `numbers already 3 or more digits are not truncated`() {
        assertEquals("1089 - One Piece", MhtmlParser.smartRename("One_Piece_1089.mhtml"))
    }

    @Test
    fun `chapter keyword is preserved, and its number is zero-padded like a bare number`() {
        // The pad step operates on whatever digit run appears in the captured
        // group, which for a "Chapter N" match includes both the keyword and
        // the number — so a 2-digit chapter number is padded here too.
        assertEquals("Chapter 042 - Bleach", MhtmlParser.smartRename("Bleach_Chapter_42.mhtml"))
    }

    @Test
    fun `underscores and plus signs become spaces`() {
        assertEquals("003 - My Hero Academia", MhtmlParser.smartRename("My+Hero_Academia_3.mhtml"))
    }

    @Test
    fun `noise phrase read manga online is stripped`() {
        // "Read Manga Online" matches the noise-word phrase and is removed
        // entirely before the chapter-number match runs.
        assertEquals("Chapter 012 - Solo Leveling",
            MhtmlParser.smartRename("Solo_Leveling_Chapter_12_Read_Manga_Online.mhtml"))
    }

    @Test
    fun `bracketed text in the title portion is dropped`() {
        // No digits at all -> falls to the else branch, which strips [..]/(..) groups.
        assertEquals("Trash", MhtmlParser.smartRename("[group] Trash.mhtml"))
    }

    @Test
    fun `falls back to the original filename when cleaning empties the result`() {
        assertEquals("[trash]", MhtmlParser.smartRename("[trash].mhtml"))
    }

    @Test
    fun `mht extension is also recognized, not just mhtml`() {
        assertEquals("005 - Naruto", MhtmlParser.smartRename("Naruto_5.mht"))
    }

    @Test
    fun `extension matching is case-insensitive`() {
        assertEquals("test", MhtmlParser.smartRename("test.MHTML"))
    }

    // ── decodeQP ──────────────────────────────────────────────────────────────

    @Test
    fun `decodeQP converts a hex escape to its character`() {
        assertEquals("Hello World", MhtmlParser.decodeQP("Hello=20World"))
    }

    @Test
    fun `decodeQP removes soft line breaks`() {
        assertEquals("line1line2", MhtmlParser.decodeQP("line1=\r\nline2"))
    }

    @Test
    fun `decodeQP handles multiple escapes in one string`() {
        assertEquals("50% off!", MhtmlParser.decodeQP("50=25 off!"))
    }

    @Test
    fun `decodeQP leaves plain text untouched`() {
        assertEquals("nothing to decode", MhtmlParser.decodeQP("nothing to decode"))
    }

    // ── sniffImageExt ─────────────────────────────────────────────────────────

    @Test
    fun `sniffs jpeg from its magic bytes`() {
        val bytes = byteArrayOf(0xFF.toByte(), 0xD8.toByte(), 0xFF.toByte()) + ByteArray(20)
        assertEquals("jpg", MhtmlParser.sniffImageExt(bytes))
    }

    @Test
    fun `sniffs png from its magic bytes`() {
        val bytes = byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47) + ByteArray(20)
        assertEquals("png", MhtmlParser.sniffImageExt(bytes))
    }

    @Test
    fun `sniffs gif from its magic bytes`() {
        val bytes = byteArrayOf(0x47, 0x49, 0x46) + ByteArray(20)
        assertEquals("gif", MhtmlParser.sniffImageExt(bytes))
    }

    @Test
    fun `sniffs webp from its RIFF WEBP container`() {
        val bytes = ByteArray(20)
        bytes[0] = 0x52; bytes[1] = 0x49; bytes[2] = 0x46; bytes[3] = 0x46 // "RIFF"
        bytes[8] = 0x57; bytes[9] = 0x45; bytes[10] = 0x42; bytes[11] = 0x50 // "WEBP"
        assertEquals("webp", MhtmlParser.sniffImageExt(bytes))
    }

    @Test
    fun `sniffs bmp from its magic bytes`() {
        val bytes = byteArrayOf(0x42, 0x4D) + ByteArray(20)
        assertEquals("bmp", MhtmlParser.sniffImageExt(bytes))
    }

    @Test
    fun `returns null for unrecognized bytes`() {
        val bytes = ByteArray(20) { 0x00 }
        assertNull(MhtmlParser.sniffImageExt(bytes))
    }

    @Test
    fun `returns null for input shorter than the minimum signature length`() {
        assertNull(MhtmlParser.sniffImageExt(byteArrayOf(0xFF.toByte(), 0xD8.toByte())))
    }
}
