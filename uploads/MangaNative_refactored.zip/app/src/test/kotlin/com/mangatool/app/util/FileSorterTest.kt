package com.mangatool.app.util

import org.junit.Assert.assertEquals
import org.junit.After
import org.junit.Before
import org.junit.Test
import java.io.File

class FileSorterTest {

    private lateinit var tempDir: File

    @Before
    fun setUp() {
        tempDir = File.createTempFile("filesorter_test", "").apply {
            delete(); mkdirs()
        }
    }

    @After
    fun tearDown() {
        tempDir.deleteRecursively()
    }

    private fun makeFile(name: String, lastModified: Long): File =
        File(tempDir, name).apply {
            writeText("x")
            setLastModified(lastModified)
        }

    @Test
    fun `sorts by name ascending, case-insensitively`() {
        val b = makeFile("banana.jpg", 1000)
        val a = makeFile("Apple.jpg", 1000)
        val c = makeFile("cherry.jpg", 1000)

        val sorted = FileSorter.sort(listOf(b, a, c), FileSortBy.NAME, ascending = true)

        assertEquals(listOf(a, b, c), sorted)
    }

    @Test
    fun `sorts by name descending`() {
        val a = makeFile("Apple.jpg", 1000)
        val b = makeFile("banana.jpg", 1000)

        val sorted = FileSorter.sort(listOf(a, b), FileSortBy.NAME, ascending = false)

        assertEquals(listOf(b, a), sorted)
    }

    @Test
    fun `sorts by date, oldest first when ascending`() {
        val newer = makeFile("newer.jpg", 2000)
        val older = makeFile("older.jpg", 1000)

        val sorted = FileSorter.sort(listOf(newer, older), FileSortBy.DATE, ascending = true)

        assertEquals(listOf(older, newer), sorted)
    }

    @Test
    fun `sorts by date, newest first when descending`() {
        val newer = makeFile("newer.jpg", 2000)
        val older = makeFile("older.jpg", 1000)

        val sorted = FileSorter.sort(listOf(newer, older), FileSortBy.DATE, ascending = false)

        assertEquals(listOf(newer, older), sorted)
    }

    @Test
    fun `sorts by type using file extension`() {
        val jpg = makeFile("a.jpg", 1000)
        val gif = makeFile("b.gif", 1000)
        val png = makeFile("c.png", 1000)

        val sorted = FileSorter.sort(listOf(jpg, gif, png), FileSortBy.TYPE, ascending = true)

        assertEquals(listOf(gif, jpg, png), sorted) // gif < jpg < png alphabetically
    }

    @Test
    fun `does not mutate the input list`() {
        val a = makeFile("b.jpg", 1000)
        val b = makeFile("a.jpg", 1000)
        val input = listOf(a, b)

        FileSorter.sort(input, FileSortBy.NAME, ascending = true)

        // Original list order must be untouched — sortedWith returns a new list.
        assertEquals(listOf(a, b), input)
    }

    @Test
    fun `empty list sorts to empty list`() {
        assertEquals(emptyList<File>(), FileSorter.sort(emptyList(), FileSortBy.NAME, true))
    }
}
