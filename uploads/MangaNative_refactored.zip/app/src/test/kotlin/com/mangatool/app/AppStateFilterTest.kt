package com.mangatool.app

import com.mangatool.app.model.ImageGroup
import com.mangatool.app.model.ImageItem
import org.junit.After
import org.junit.Before
import org.junit.Test
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue

/**
 * Unit tests for [AppState.applyFilters] — the core "which pages are shown
 * vs hidden" business logic. [AppState] is a singleton object that persists
 * for the whole JVM process, so every test resets it in [setUp]/[tearDown]
 * to avoid state leaking between tests (fingerprints, group lists, filter
 * settings).
 */
class AppStateFilterTest {

    @Before
    fun setUp() {
        AppState.resetAll()
        AppState.currentMode   = AppMode.EXTRACT
        AppState.minSizeKb     = 40
        AppState.excludeGifs   = true
        AppState.reverseOrder  = false
        AppState.minWidth      = 0
        AppState.minHeight     = 0
        AppState.minDimsEnabled = false
    }

    @After
    fun tearDown() {
        AppState.resetAll()
    }

    private fun img(
        idx: Int,
        sizeBytes: Int = 100 * 1024,
        ext: String = "jpg",
        width: Int = 0,
        height: Int = 0,
        userDeleted: Boolean = false,
        forceKeep: Boolean = false
    ) = ImageItem(
        originalIdx = idx,
        filePath = "/tmp/fake_$idx.$ext",
        ext = ext,
        size = sizeBytes,
        width = width,
        height = height,
        userDeleted = userDeleted,
        forceKeep = forceKeep
    )

    @Test
    fun `images above min size all pass through`() {
        val group = ImageGroup("Chapter 1")
        group.allImages.addAll(listOf(img(0), img(1), img(2)))
        AppState.groups.add(group)

        AppState.applyFilters()

        assertEquals(3, group.displayImages.size)
        assertTrue(group.filteredImages.isEmpty())
    }

    @Test
    fun `images below min size are filtered with a size reason`() {
        AppState.minSizeKb = 100
        val group = ImageGroup("Chapter 1")
        group.allImages.addAll(listOf(img(0, sizeBytes = 10 * 1024), img(1, sizeBytes = 200 * 1024)))
        AppState.groups.add(group)

        AppState.applyFilters()

        assertEquals(1, group.displayImages.size)
        assertEquals(1, group.filteredImages.size)
        assertTrue(group.filteredImages[0].filterReason!!.startsWith("Too Small"))
    }

    @Test
    fun `gif excluded when excludeGifs is enabled`() {
        AppState.excludeGifs = true
        val group = ImageGroup("Chapter 1")
        group.allImages.addAll(listOf(img(0, ext = "gif"), img(1, ext = "jpg")))
        AppState.groups.add(group)

        AppState.applyFilters()

        assertEquals(1, group.displayImages.size)
        assertEquals("gif", group.filteredImages[0].ext)
        assertEquals("GIF Excluded", group.filteredImages[0].filterReason)
    }

    @Test
    fun `gif kept when excludeGifs is disabled`() {
        AppState.excludeGifs = false
        val group = ImageGroup("Chapter 1")
        group.allImages.add(img(0, ext = "gif"))
        AppState.groups.add(group)

        AppState.applyFilters()

        assertEquals(1, group.displayImages.size)
        assertTrue(group.filteredImages.isEmpty())
    }

    @Test
    fun `dimension filter only applies once dimensions are known`() {
        AppState.minDimsEnabled = true
        AppState.minWidth  = 800
        AppState.minHeight = 1200
        val group = ImageGroup("Chapter 1")
        // width == 0 means "not decoded yet" — must NOT be treated as "too small".
        group.allImages.addAll(
            listOf(
                img(0, width = 0, height = 0),       // undecided -> passes
                img(1, width = 400, height = 600),    // too small -> filtered
                img(2, width = 1000, height = 1500)   // big enough -> passes
            )
        )
        AppState.groups.add(group)

        AppState.applyFilters()

        assertEquals(2, group.displayImages.size)
        assertEquals(1, group.filteredImages.size)
        assertEquals(1, group.filteredImages[0].originalIdx)
    }

    @Test
    fun `dimension filter is inactive when minDimsEnabled is false`() {
        AppState.minDimsEnabled = false
        AppState.minWidth  = 9999
        AppState.minHeight = 9999
        val group = ImageGroup("Chapter 1")
        group.allImages.add(img(0, width = 10, height = 10))
        AppState.groups.add(group)

        AppState.applyFilters()

        assertEquals(1, group.displayImages.size)
        assertTrue(group.filteredImages.isEmpty())
    }

    @Test
    fun `user-deleted image is always filtered regardless of size`() {
        val group = ImageGroup("Chapter 1")
        group.allImages.add(img(0, sizeBytes = 999 * 1024, userDeleted = true))
        AppState.groups.add(group)

        AppState.applyFilters()

        assertTrue(group.displayImages.isEmpty())
        assertEquals("Manually Deleted", group.filteredImages[0].filterReason)
    }

    @Test
    fun `forceKeep overrides every other filter reason`() {
        AppState.minSizeKb = 999_999 // would fail every image on size alone
        val group = ImageGroup("Chapter 1")
        group.allImages.add(img(0, sizeBytes = 1, ext = "gif", forceKeep = true))
        AppState.groups.add(group)

        AppState.applyFilters()

        assertEquals(1, group.displayImages.size)
        assertTrue(group.filteredImages.isEmpty())
    }

    @Test
    fun `reverseOrder reverses only the surviving display images`() {
        AppState.reverseOrder = true
        val group = ImageGroup("Chapter 1")
        group.allImages.addAll(listOf(img(0), img(1), img(2)))
        AppState.groups.add(group)

        AppState.applyFilters()

        assertEquals(listOf(2, 1, 0), group.displayImages.map { it.originalIdx })
    }

    @Test
    fun `display images are renamed sequentially by position`() {
        val group = ImageGroup("Chapter 1")
        group.allImages.addAll(listOf(img(0, ext = "png"), img(1, ext = "jpg")))
        AppState.groups.add(group)

        AppState.applyFilters()

        assertEquals("001.png", group.displayImages[0].name)
        assertEquals("002.jpg", group.displayImages[1].name)
    }

    @Test
    fun `merge mode never filters and clears filteredImages`() {
        AppState.currentMode = AppMode.MERGE
        val group = ImageGroup("Merge 1")
        // Even a tiny GIF must survive in merge mode — merge mode has no filters.
        group.allImages.add(img(0, sizeBytes = 1, ext = "gif"))
        AppState.groups.add(group)

        AppState.applyFilters()

        assertEquals(1, group.displayImages.size)
        assertTrue(group.filteredImages.isEmpty())
    }

    @Test
    fun `repeated applyFilters with unchanged settings is a no-op via fingerprint cache`() {
        val group = ImageGroup("Chapter 1")
        group.allImages.add(img(0))
        AppState.groups.add(group)

        AppState.applyFilters()
        val firstDisplay = group.displayImages

        AppState.applyFilters() // nothing changed — fingerprint should skip rebuild

        // Same list reference confirms the fingerprint cache short-circuited
        // the rebuild rather than allocating an equivalent-but-new list.
        assertTrue(firstDisplay === group.displayImages)
    }

    @Test
    fun `invalidateFilter forces a rebuild on next applyFilters call`() {
        val group = ImageGroup("Chapter 1")
        group.allImages.add(img(0))
        AppState.groups.add(group)
        AppState.applyFilters()
        val firstDisplay = group.displayImages

        AppState.invalidateFilter(group)
        AppState.applyFilters()

        // Rebuild ran again — list is a new (though equal-content) instance.
        assertTrue(firstDisplay !== group.displayImages)
    }

    @Test
    fun `too small by dimensions reason includes pixel dimensions`() {
        AppState.minDimsEnabled = true
        AppState.minWidth = 500
        val group = ImageGroup("Chapter 1")
        group.allImages.add(img(0, width = 100, height = 200))
        AppState.groups.add(group)

        AppState.applyFilters()

        assertEquals("Too Small (100×200px)", group.filteredImages[0].filterReason)
    }

    @Test
    fun `extract and merge groups are fully independent lists`() {
        AppState.currentMode = AppMode.EXTRACT
        AppState.groups.add(ImageGroup("Extract chapter"))
        AppState.currentMode = AppMode.MERGE
        AppState.groups.add(ImageGroup("Merge chapter"))

        assertEquals(1, AppState.extractGroups.size)
        assertEquals(1, AppState.mergeGroups.size)
        assertEquals("Extract chapter", AppState.extractGroups[0].groupName)
        assertEquals("Merge chapter", AppState.mergeGroups[0].groupName)
    }
}
