# JNI entry points are looked up by name from native code.
-keep class com.sunsetdownhill.game.NativeBridge { *; }
-keepclasseswithmembernames class * {
    native <methods>;
}
