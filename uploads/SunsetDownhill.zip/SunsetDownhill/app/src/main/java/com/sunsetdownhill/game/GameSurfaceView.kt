package com.sunsetdownhill.game

import android.content.Context
import android.opengl.GLSurfaceView
import android.view.MotionEvent
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

/**
 * OpenGL ES 3.0 surface. Rendering happens entirely in native code; this class forwards
 * lifecycle callbacks and multi-touch input to the engine on the GL thread.
 */
class GameSurfaceView(
    context: Context,
    private val onSettingsChanged: (best: Int, soundOn: Boolean) -> Unit
) : GLSurfaceView(context) {

    private var lastBest = -1
    private var lastSound: Boolean? = null

    init {
        setEGLContextClientVersion(3)
        preserveEGLContextOnPause = true
        setRenderer(object : GLSurfaceView.Renderer {
            override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
                NativeBridge.surfaceCreated()
            }

            override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
                NativeBridge.surfaceChanged(width, height)
            }

            override fun onDrawFrame(gl: GL10?) {
                NativeBridge.drawFrame()
                publishSettings()
            }
        })
        renderMode = RENDERMODE_CONTINUOUSLY
    }

    /** Persist the best score / sound toggle whenever the engine changes them. */
    private fun publishSettings() {
        val best = NativeBridge.bestScore()
        val sound = NativeBridge.soundEnabled()
        if (best != lastBest || sound != lastSound) {
            lastBest = best
            lastSound = sound
            onSettingsChanged(best, sound)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = event.actionIndex
                send(NativeBridge.TOUCH_DOWN, event.getPointerId(i), event.getX(i), event.getY(i))
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                val i = event.actionIndex
                send(NativeBridge.TOUCH_UP, event.getPointerId(i), event.getX(i), event.getY(i))
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until event.pointerCount) {
                    send(NativeBridge.TOUCH_MOVE, event.getPointerId(i), event.getX(i), event.getY(i))
                }
            }
            MotionEvent.ACTION_CANCEL -> send(NativeBridge.TOUCH_CANCEL, 0, 0f, 0f)
        }
        return true
    }

    private fun send(action: Int, id: Int, x: Float, y: Float) {
        queueEvent { NativeBridge.touch(action, id, x, y) }
    }
}
