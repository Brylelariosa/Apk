package com.sunsetdownhill.game

/**
 * Thin JNI surface of the native engine (see app/src/main/cpp/jni_bridge.cpp).
 * All game logic, rendering and audio synthesis live in C++; Kotlin only hosts the window,
 * forwards input and feeds the audio device.
 */
object NativeBridge {
    init {
        System.loadLibrary("sunset_downhill")
    }

    // Touch action codes, mirrored from core/input.h
    const val TOUCH_DOWN = 0
    const val TOUCH_MOVE = 1
    const val TOUCH_UP = 2
    const val TOUCH_CANCEL = 3

    @JvmStatic external fun create(best: Int, soundOn: Boolean)
    @JvmStatic external fun surfaceCreated()
    @JvmStatic external fun surfaceChanged(width: Int, height: Int)
    @JvmStatic external fun drawFrame()
    @JvmStatic external fun touch(action: Int, id: Int, x: Float, y: Float)
    @JvmStatic external fun pause()

    /** Returns true if the game consumed the back press (otherwise the Activity should finish). */
    @JvmStatic external fun back(): Boolean
    @JvmStatic external fun bestScore(): Int
    @JvmStatic external fun soundEnabled(): Boolean

    /** Fills [buffer] with [frames] mono 16-bit samples at 22050 Hz. Safe to call from any thread. */
    @JvmStatic external fun fillAudio(buffer: ShortArray, frames: Int)
}
