package com.sunsetdownhill.game

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack

/**
 * Streams the procedurally synthesised game audio (wind, wheels, slides, UI beeps) to the device.
 * The DSP itself lives in native code; this class only owns the AudioTrack and its feeder thread.
 */
class AudioEngine {
    @Volatile
    private var running = false
    private var thread: Thread? = null

    fun start() {
        if (running) return
        running = true
        thread = Thread({ pump() }, "audio-synth").apply {
            isDaemon = true
            start()
        }
    }

    fun stop() {
        running = false
        thread?.join(800)
        thread = null
    }

    private fun pump() {
        val minBytes = AudioTrack.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minBytes <= 0) return
        val track = try {
            AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(SAMPLE_RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(maxOf(minBytes, 4096) * 2)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
        } catch (e: Exception) {
            return  // no audio device: the game simply runs silently
        }

        val chunk = ShortArray(CHUNK_FRAMES)
        try {
            track.play()
            while (running) {
                NativeBridge.fillAudio(chunk, chunk.size)
                track.write(chunk, 0, chunk.size)
            }
        } finally {
            try {
                track.stop()
            } catch (e: IllegalStateException) {
                // already stopped
            }
            track.release()
        }
    }

    private companion object {
        const val SAMPLE_RATE = 22050
        const val CHUNK_FRAMES = 512
    }
}
