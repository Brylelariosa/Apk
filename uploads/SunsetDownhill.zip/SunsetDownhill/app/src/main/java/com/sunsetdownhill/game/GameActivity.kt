package com.sunsetdownhill.game

import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager

/** Hosts the native game: full-screen landscape GL surface plus the audio feeder. */
class GameActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var surface: GameSurfaceView
    private val audio = AudioEngine()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val attrs = window.attributes
            attrs.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = attrs
        }

        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        NativeBridge.create(prefs.getInt(KEY_BEST, 0), prefs.getBoolean(KEY_SOUND, true))

        surface = GameSurfaceView(this) { best, sound ->
            prefs.edit().putInt(KEY_BEST, best).putBoolean(KEY_SOUND, sound).apply()
        }
        setContentView(surface)
    }

    override fun onResume() {
        super.onResume()
        enterImmersiveMode()
        surface.onResume()
        audio.start()
    }

    override fun onPause() {
        audio.stop()
        NativeBridge.pause()
        surface.onPause()
        super.onPause()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) enterImmersiveMode()
    }

    @Deprecated("Deprecated in Java")
    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        // The game pauses / returns to the menu; only exit from the main menu.
        if (!NativeBridge.back()) super.onBackPressed()
    }

    @Suppress("DEPRECATION")
    private fun enterImmersiveMode() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.let {
                it.hide(WindowInsets.Type.systemBars())
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        }
    }

    private companion object {
        const val PREFS = "sunset_downhill"
        const val KEY_BEST = "best"
        const val KEY_SOUND = "sound"
    }
}
