// particles.h - small CPU particle pool (tyre smoke, sparks, dust).
#pragma once

#include <vector>

#include "color.h"
#include "math3d.h"
#include "scene_types.h"

namespace sd {

struct Particle {
    Vec3 pos, vel;
    float age = 0.0f, life = 1.0f;
    float size0 = 1.0f, size1 = 1.0f;
    Rgba8 color;
    float gravity = 0.0f, drag = 0.0f;
    bool additive = false;   // sparks
    bool alive = false;
};

class ParticleSystem {
public:
    static constexpr int kCapacity = 384;

    void clear();
    void emit(const Particle& p);
    void update(float dt);
    // Appends camera-relative instances.
    void build(const Vec3& origin, std::vector<ParticleInstance>& smoke, std::vector<ParticleInstance>& sparks) const;

private:
    Particle pool_[kCapacity];
    int next_ = 0;
};

}  // namespace sd
