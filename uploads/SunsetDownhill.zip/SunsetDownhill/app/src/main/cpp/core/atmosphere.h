// atmosphere.h - sky / light / fog parameters; drifts from golden hour to dusk as you ride.
#pragma once

#include "math3d.h"

namespace sd {

struct Atmosphere {
    Vec3 sunDir;                 // unit vector toward the sun
    Vec3 sunColor;               // direct light
    Vec3 ambSky, ambGround;      // hemisphere ambient
    Vec3 fogColor, fogSun;       // haze colour away from / toward the sun
    float fogDensity = 0.0055f;
    Vec3 skyTop, skyMid;         // sky gradient above the haze band
    Vec3 cloudLit, cloudShade;
    Vec3 mountainNear, mountainFar;
};

// progress 0 = golden hour, 1 = dusk. sunAzimuth is a heading angle (0 = toward -Z, + turns right).
Atmosphere makeAtmosphere(float progress, float sunAzimuth);

}  // namespace sd
