#include "camera.h"

#include <cmath>

namespace sd {

void ChaseCamera::reset(const Track& track, const Skater& sk) {
    sCam_ = std::max(0.0f, sk.s - 5.0f);
    xCam_ = sk.x * 0.7f;
    hCam_ = 1.95f;
    lookX_ = sk.x * 0.45f;
    roll_ = 0.0f;
    shake_ = 0.0f;
    fov_ = 62.0f * kDeg2Rad;
    update(0.0f, track, sk, 0.0f, 0.0f, 0.0f);
}

void ChaseCamera::update(float dt, const Track& track, const Skater& sk, float intro, float orbit, float time) {
    const float sp01 = saturate(sk.speed / 36.0f);
    const float crashBlend = sk.crashed ? saturate(sk.crashTime / 0.6f) : 0.0f;
    const float back = lerpf(4.6f, 6.2f, sp01) + 1.1f * sk.slide + 3.2f * crashBlend - 2.3f * intro;
    const float height = lerpf(1.95f, 1.5f, sk.tuck) - 0.75f * intro + 0.35f * orbit * std::sin(time * 0.31f);
    const float lateral = 0.70f * sk.x + 2.0f * intro + orbit * 1.7f * std::sin(time * 0.23f);

    sCam_ += ((sk.s - back) - sCam_) * smoothing(18.0f, dt);
    xCam_ += (lateral - xCam_) * smoothing(5.0f, dt);
    hCam_ += (height - hCam_) * smoothing(6.0f, dt);
    lookX_ += (sk.x * 0.45f - lookX_) * smoothing(6.0f, dt);
    if (sCam_ < 0.0f) sCam_ = 0.0f;

    const TrackSample fc = track.at(sCam_);
    Vec3 pos = Track::surfacePoint(fc, xCam_, hCam_);

    const float sLook = sk.s + 13.0f + 6.0f * sp01 - 4.0f * intro;
    const TrackSample fl = track.at(sLook);
    Vec3 target = Track::surfacePoint(fl, lookX_, lerpf(1.1f, 0.8f, sk.tuck) + 0.25f * intro);

    // shake: crash impulse + speed rumble + gravel rumble
    shake_ *= std::exp(-6.0f * dt);
    const float amp = shake_ * 0.35f + 0.012f * sp01 * sp01 + (sk.onShoulder ? 0.02f : 0.0f);
    const Vec3 jitter(std::sin(time * 41.0f) + 0.5f * std::sin(time * 97.0f), std::sin(time * 53.0f + 1.3f),
                      std::sin(time * 37.0f + 2.1f));
    pos += jitter * amp;
    target += jitter * (amp * 0.6f);

    Vec3 fwd = normalize(target - pos);
    Vec3 right = normalize(cross(fwd, Vec3(0.0f, 1.0f, 0.0f)));
    Vec3 up = cross(right, fwd);
    roll_ += (sk.lean * 0.10f - roll_) * smoothing(5.0f, dt);
    right = rotateAround(right, fwd, roll_);
    up = rotateAround(up, fwd, roll_);

    const float fovTarget = lerpf(60.0f, 82.0f, std::pow(sp01, 0.8f)) + 3.0f * sk.slide - 8.0f * intro;
    fov_ += (fovTarget * kDeg2Rad - fov_) * smoothing(4.0f, dt);

    view_.pos = pos;
    view_.fwd = fwd;
    view_.right = right;
    view_.up = up;
    view_.fovY = fov_;
}

}  // namespace sd
