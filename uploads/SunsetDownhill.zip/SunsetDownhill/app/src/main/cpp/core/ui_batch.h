// ui_batch.h - CPU-side 2D triangle batch for HUD / menus (pixel coordinates, origin top-left).
#pragma once

#include <cstdint>
#include <vector>

#include "color.h"
#include "math3d.h"

namespace sd {

struct UiVertex {
    float x, y;
    uint8_t r, g, b, a;
};
static_assert(sizeof(UiVertex) == 12, "UiVertex layout");

class UiBatch {
public:
    void clear() { v_.clear(); }
    void setScreen(float w, float h) { w_ = w; h_ = h; }
    float width() const { return w_; }
    float height() const { return h_; }

    void triangle(Vec2 a, Vec2 b, Vec2 c, Rgba8 col);
    void quad(Vec2 a, Vec2 b, Vec2 c, Vec2 d, Rgba8 col);
    void rect(float x, float y, float w, float h, Rgba8 c);
    void rectGradient(float x, float y, float w, float h, Rgba8 top, Rgba8 bottom);
    void roundRect(float x, float y, float w, float h, float radius, Rgba8 c);
    void circle(float cx, float cy, float r, Rgba8 c, int segments = 32);
    void ring(float cx, float cy, float r0, float r1, Rgba8 c, int segments = 40, float a0 = 0.0f, float a1 = kTwoPi);
    void line(Vec2 a, Vec2 b, float thickness, Rgba8 c, bool squareCaps = true);

    const UiVertex* data() const { return v_.data(); }
    size_t vertexCount() const { return v_.size(); }

private:
    void push(float x, float y, Rgba8 c) { v_.push_back({x, y, c.r, c.g, c.b, c.a}); }

    std::vector<UiVertex> v_;
    float w_ = 1.0f, h_ = 1.0f;
};

}  // namespace sd
