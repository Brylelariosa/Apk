#include "hud.h"

#include <cmath>
#include <cstdio>

#include "ui_font.h"

namespace sd {
namespace {

const Rgba8 kWhite = {255, 255, 255, 255};
const Rgba8 kAccent = {255, 170, 70, 255};
const Rgba8 kGold = {255, 220, 110, 255};
const Rgba8 kPanel = {22, 14, 42, 170};
const Rgba8 kShadow = {24, 8, 36, 150};
const Rgba8 kCyan = {110, 235, 255, 255};
const Rgba8 kRed = {255, 90, 70, 255};

Rgba8 alpha(Rgba8 c, float a) { c.a = to8(a * static_cast<float>(c.a) / 255.0f); return c; }

float text(UiBatch& ui, const char* s, float x, float y, float size, Rgba8 c, TextAlign a = TextAlign::Left) {
    const float o = std::max(1.5f, size * 0.055f);
    Rgba8 sh = kShadow;
    sh.a = to8(static_cast<float>(kShadow.a) / 255.0f * static_cast<float>(c.a) / 255.0f);   // shadow fades with the text
    drawText(ui, s, x + o, y + o, size, sh, a);
    return drawText(ui, s, x, y, size, c, a);
}

void arrow(UiBatch& ui, float cx, float cy, float s, int dir, Rgba8 c) {
    ui.triangle({cx + dir * s, cy}, {cx - dir * s * 0.7f, cy - s}, {cx - dir * s * 0.7f, cy + s}, c);
}

void button(UiBatch& ui, const Vec2& c, float r, bool down, const char* label, float labelSize, Rgba8 tint) {
    ui.circle(c.x, c.y, r, down ? alpha(tint, 0.55f) : Rgba8{30, 20, 60, 110});
    ui.ring(c.x, c.y, r * 0.92f, r, alpha(kWhite, down ? 0.9f : 0.45f), 48);
    ui.ring(c.x, c.y, r * 0.70f, r * 0.74f, alpha(tint, down ? 0.9f : 0.35f), 48);
    drawText(ui, label, c.x, c.y - labelSize * 0.5f, labelSize, alpha(kWhite, down ? 1.0f : 0.85f), TextAlign::Center);
}

void speedBlock(UiBatch& ui, const UiLayout& L, const HudModel& m) {
    const float u = L.u;
    char buf[32];
    std::snprintf(buf, sizeof(buf), "%d", static_cast<int>(m.speedKmh + 0.5f));
    const float size = 92.0f * u;
    const float w = text(ui, buf, L.margin, L.margin, size, kWhite);
    text(ui, "KM/H", L.margin + w + 14.0f * u, L.margin + size - 32.0f * u, 30.0f * u, kAccent);
    // speed bar
    const float bx = L.margin, by = L.margin + size + 24.0f * u, bw = 330.0f * u, bh = 16.0f * u;
    ui.roundRect(bx, by, bw, bh, bh * 0.5f, Rgba8{20, 10, 40, 150});
    const float f = saturate(m.speedKmh / 140.0f);
    if (f > 0.01f) {
        const Rgba8 cool = {255, 214, 120, 255}, hot = {255, 80, 60, 255};
        ui.roundRect(bx, by, std::max(bh, bw * f), bh, bh * 0.5f, mix(cool, hot, smoothstep(0.5f, 1.0f, f)));
    }
}

void drawControls(UiBatch& ui, const UiLayout& L, const HudModel& m) {
    const float u = L.u;
    button(ui, L.tuckC, L.tuckR, m.tuckDown, "TUCK", 34.0f * u, kCyan);
    button(ui, L.slideC, L.slideR, m.slideDown, "SLIDE", 30.0f * u, kAccent);
    if (m.steerActive) {
        ui.ring(m.stickOrigin.x, m.stickOrigin.y, L.stickRange * 1.0f, L.stickRange * 1.04f, alpha(kWhite, 0.30f), 56);
        arrow(ui, m.stickOrigin.x - L.stickRange - 26.0f * u, m.stickOrigin.y, 15.0f * u, -1, alpha(kWhite, 0.45f));
        arrow(ui, m.stickOrigin.x + L.stickRange + 26.0f * u, m.stickOrigin.y, 15.0f * u, 1, alpha(kWhite, 0.45f));
        ui.circle(m.stickKnob.x, m.stickKnob.y, 52.0f * u, alpha(kWhite, 0.55f), 36);
        ui.ring(m.stickKnob.x, m.stickKnob.y, 46.0f * u, 52.0f * u, alpha(kWhite, 0.9f), 36);
    } else {
        const float cx = L.margin + 200.0f * u, cy = L.h - L.margin - 130.0f * u;
        arrow(ui, cx - 110.0f * u, cy, 34.0f * u, -1, alpha(kWhite, 0.30f));
        arrow(ui, cx + 110.0f * u, cy, 34.0f * u, 1, alpha(kWhite, 0.30f));
        drawText(ui, "STEER", cx, cy - 15.0f * u, 30.0f * u, alpha(kWhite, 0.40f), TextAlign::Center);
    }
}

void pauseButton(UiBatch& ui, const UiLayout& L) {
    const Vec2 c = L.pauseC;
    ui.circle(c.x, c.y, L.pauseR, Rgba8{30, 20, 60, 120});
    ui.ring(c.x, c.y, L.pauseR * 0.92f, L.pauseR, alpha(kWhite, 0.5f), 40);
    const float bw = L.pauseR * 0.20f, bh = L.pauseR * 0.7f;
    ui.rect(c.x - bw * 1.7f, c.y - bh * 0.5f, bw, bh, alpha(kWhite, 0.9f));
    ui.rect(c.x + bw * 0.7f, c.y - bh * 0.5f, bw, bh, alpha(kWhite, 0.9f));
}

void soundButton(UiBatch& ui, const UiLayout& L, bool on) {
    const Vec2 c = L.soundC;
    const float r = L.soundR;
    ui.circle(c.x, c.y, r, Rgba8{30, 20, 60, 120});
    ui.ring(c.x, c.y, r * 0.92f, r, alpha(kWhite, 0.5f), 40);
    const Rgba8 w = alpha(kWhite, 0.95f);
    ui.rect(c.x - r * 0.40f, c.y - r * 0.16f, r * 0.22f, r * 0.32f, w);
    ui.triangle({c.x - r * 0.18f, c.y - r * 0.16f}, {c.x + r * 0.10f, c.y - r * 0.40f}, {c.x + r * 0.10f, c.y + r * 0.40f}, w);
    ui.triangle({c.x - r * 0.18f, c.y - r * 0.16f}, {c.x + r * 0.10f, c.y + r * 0.40f}, {c.x - r * 0.18f, c.y + r * 0.16f}, w);
    if (on) {
        ui.ring(c.x + r * 0.08f, c.y, r * 0.26f, r * 0.33f, w, 20, -0.9f, 0.9f);
        ui.ring(c.x + r * 0.08f, c.y, r * 0.44f, r * 0.51f, w, 20, -0.9f, 0.9f);
    } else {
        ui.line({c.x + r * 0.22f, c.y - r * 0.26f}, {c.x + r * 0.58f, c.y + r * 0.26f}, r * 0.10f, alpha(kRed, 1.0f));
        ui.line({c.x + r * 0.58f, c.y - r * 0.26f}, {c.x + r * 0.22f, c.y + r * 0.26f}, r * 0.10f, alpha(kRed, 1.0f));
    }
}

void menuButton(UiBatch& ui, const UiLayout& L) {
    ui.roundRect(L.menuX, L.menuY, L.menuW, L.menuH, L.menuH * 0.4f, Rgba8{30, 20, 60, 170});
    drawText(ui, "MENU", L.menuX + L.menuW * 0.5f, L.menuY + L.menuH * 0.5f - 18.0f * L.u, 36.0f * L.u, kWhite, TextAlign::Center);
}

void dim(UiBatch& ui, const UiLayout& L, float alpha255) {
    ui.rect(0, 0, L.w, L.h, Rgba8{10, 4, 24, static_cast<uint8_t>(clampf(alpha255, 0.0f, 255.0f))});
}

void drawMenu(UiBatch& ui, const UiLayout& L, const HudModel& m) {
    const float u = L.u;
    ui.rectGradient(0, 0, L.w, L.h * 0.55f, Rgba8{12, 4, 30, 110}, Rgba8{12, 4, 30, 0});
    ui.rectGradient(0, L.h * 0.60f, L.w, L.h * 0.40f, Rgba8{12, 4, 30, 0}, Rgba8{12, 4, 30, 140});
    const float cx = L.w * 0.5f;
    const float s1 = 118.0f * u;
    text(ui, "SUNSET", cx, L.h * 0.12f, s1, kGold, TextAlign::Center);
    const float w2 = textWidth("DOWNHILL", s1 * 1.25f);
    text(ui, "DOWNHILL", cx, L.h * 0.12f + s1 * 1.28f, s1 * 1.25f, kWhite, TextAlign::Center);
    // accent bar
    const float bw = w2, by = L.h * 0.12f + s1 * 1.28f + s1 * 1.25f + 26.0f * u;
    for (int i = 0; i < 24; ++i) {
        const float t0 = static_cast<float>(i) / 24.0f;
        ui.rect(cx - bw * 0.5f + bw * t0, by, bw / 24.0f + 1.0f, 7.0f * u,
                mix(Rgba8{255, 190, 80, 255}, Rgba8{230, 80, 170, 255}, t0));
    }
    const float blink = 0.6f + 0.4f * std::sin(m.time * 3.2f);
    text(ui, "TAP TO START", cx, L.h * 0.72f, 54.0f * u, alpha(kWhite, blink), TextAlign::Center);
    char buf[48];
    std::snprintf(buf, sizeof(buf), "BEST %d", m.best);
    text(ui, buf, cx, L.h * 0.84f, 36.0f * u, kAccent, TextAlign::Center);
    text(ui, "DRAG LEFT TO STEER   HOLD TUCK FOR SPEED   HOLD SLIDE TO BRAKE", cx, L.h * 0.93f, 22.0f * u, alpha(kWhite, 0.75f), TextAlign::Center);
    soundButton(ui, L, m.soundOn);
}

void drawRunning(UiBatch& ui, const UiLayout& L, const HudModel& m) {
    const float u = L.u;
    speedBlock(ui, L, m);
    char buf[48];
    std::snprintf(buf, sizeof(buf), "%d", m.score);
    const float rx = L.pauseC.x - L.pauseR - 28.0f * u;
    text(ui, "SCORE", rx, L.margin - 2.0f * u, 26.0f * u, kAccent, TextAlign::Right);
    text(ui, buf, rx, L.margin + 40.0f * u, 64.0f * u, kWhite, TextAlign::Right);
    std::snprintf(buf, sizeof(buf), "%.2f KM", m.distanceM / 1000.0f);
    text(ui, buf, L.w * 0.5f, L.margin + 6.0f * u, 38.0f * u, alpha(kWhite, 0.92f), TextAlign::Center);
    pauseButton(ui, L);
    drawControls(ui, L, m);

    if (m.popupAlpha > 0.01f && m.popup[0]) {
        const float rise = std::min(1.0f, m.popupAge * 4.0f);
        text(ui, m.popup, L.w * 0.5f, L.h * 0.26f - 28.0f * u * rise, 58.0f * u, alpha(kGold, m.popupAlpha), TextAlign::Center);
    }
    if (m.phaseTime < 0.9f) {
        const float a = 1.0f - smoothstep(0.35f, 0.9f, m.phaseTime);
        const float s = 230.0f * u * (1.0f + 0.25f * m.phaseTime);
        text(ui, "GO!", L.w * 0.5f, L.h * 0.30f, s, alpha(kAccent, a), TextAlign::Center);
    }
}

void drawCountdown(UiBatch& ui, const UiLayout& L, const HudModel& m) {
    const float u = L.u;
    drawControls(ui, L, m);
    pauseButton(ui, L);
    if (m.countdown >= 1) {
        char buf[16];
        std::snprintf(buf, sizeof(buf), "%d", m.countdown);
        const float p = m.countdownProgress;
        const float s = 260.0f * u * (1.0f + 0.35f * (1.0f - p));
        text(ui, buf, L.w * 0.5f, L.h * 0.28f, s, alpha(kWhite, 1.0f - 0.7f * p * p), TextAlign::Center);
    }
    text(ui, "GET READY", L.w * 0.5f, L.h * 0.14f, 40.0f * u, alpha(kGold, 0.9f), TextAlign::Center);
}

void drawCrashed(UiBatch& ui, const UiLayout& L, const HudModel& m) {
    const float u = L.u;
    if (m.phaseTime > 0.25f) {
        const float a = smoothstep(0.25f, 0.6f, m.phaseTime);
        const float sh = std::sin(m.phaseTime * 60.0f) * 5.0f * u * (1.0f - a);
        text(ui, "WIPEOUT!", L.w * 0.5f + sh, L.h * 0.18f, 130.0f * u, alpha(kRed, a), TextAlign::Center);
    }
}

void drawGameOver(UiBatch& ui, const UiLayout& L, const HudModel& m) {
    const float u = L.u;
    const float a = smoothstep(0.0f, 0.35f, m.phaseTime);
    dim(ui, L, 120.0f * a);
    const float pw = 760.0f * u, ph = 560.0f * u;
    const float px = L.w * 0.5f - pw * 0.5f, py = L.h * 0.45f - ph * 0.5f;
    ui.roundRect(px, py, pw, ph, 36.0f * u, alpha(kPanel, a));
    ui.roundRect(px, py, pw, 10.0f * u, 5.0f * u, alpha(kAccent, a));
    const float cx = L.w * 0.5f;
    text(ui, "RUN OVER", cx, py + 36.0f * u, 70.0f * u, alpha(kWhite, a), TextAlign::Center);
    char buf[64];
    float y = py + 150.0f * u;
    auto row = [&](const char* label, const char* value, Rgba8 vc) {
        text(ui, label, px + 56.0f * u, y + 8.0f * u, 30.0f * u, alpha(kAccent, a));
        text(ui, value, px + pw - 56.0f * u, y, 44.0f * u, alpha(vc, a), TextAlign::Right);
        y += 62.0f * u;
    };
    std::snprintf(buf, sizeof(buf), "%.2f KM", m.distanceM / 1000.0f);
    row("DISTANCE", buf, kWhite);
    std::snprintf(buf, sizeof(buf), "%d KM/H", static_cast<int>(m.topSpeedKmh + 0.5f));
    row("TOP SPEED", buf, kWhite);
    std::snprintf(buf, sizeof(buf), "%d", m.nearMisses);
    row("CLOSE CALLS", buf, kWhite);
    std::snprintf(buf, sizeof(buf), "%d", m.score);
    row("SCORE", buf, kGold);
    std::snprintf(buf, sizeof(buf), "%d", m.best);
    row("BEST", buf, kWhite);
    if (m.newBest) {
        const float b = 0.65f + 0.35f * std::sin(m.time * 7.0f);
        text(ui, "NEW BEST!", cx, py + ph - 70.0f * u, 54.0f * u, alpha(kGold, a * b), TextAlign::Center);
    } else if (m.phaseTime > 0.7f) {
        const float b = 0.6f + 0.4f * std::sin(m.time * 3.2f);
        text(ui, "TAP TO RETRY", cx, py + ph - 66.0f * u, 46.0f * u, alpha(kWhite, a * b), TextAlign::Center);
    }
    menuButton(ui, L);
}

void drawPaused(UiBatch& ui, const UiLayout& L, const HudModel& m) {
    const float u = L.u;
    dim(ui, L, 150.0f);
    text(ui, "PAUSED", L.w * 0.5f, L.h * 0.26f, 140.0f * u, kWhite, TextAlign::Center);
    const float blink = 0.6f + 0.4f * std::sin(m.time * 3.2f);
    text(ui, "TAP TO RESUME", L.w * 0.5f, L.h * 0.56f, 50.0f * u, alpha(kGold, blink), TextAlign::Center);
    menuButton(ui, L);
}

}  // namespace

void drawHud(UiBatch& ui, const UiLayout& L, const HudModel& m) {
    ui.setScreen(L.w, L.h);
    switch (m.phase) {
        case Phase::Menu: drawMenu(ui, L, m); break;
        case Phase::Countdown: drawCountdown(ui, L, m); break;
        case Phase::Running: drawRunning(ui, L, m); break;
        case Phase::Crashed: drawCrashed(ui, L, m); break;
        case Phase::GameOver: drawGameOver(ui, L, m); break;
        case Phase::Paused: drawRunning(ui, L, m); drawPaused(ui, L, m); break;
    }
}

UiAction hudHandleTap(const UiLayout& L, const HudModel& m, float x, float y) {
    switch (m.phase) {
        case Phase::Menu:
            if (UiLayout::inCircle(x, y, L.soundC, L.soundR * 1.4f)) return UiAction::ToggleSound;
            return UiAction::Start;
        case Phase::Countdown:
        case Phase::Running:
            if (UiLayout::inCircle(x, y, L.pauseC, L.pauseR * 1.5f)) return UiAction::Pause;
            return UiAction::None;
        case Phase::Paused:
            if (L.inMenuButton(x, y)) return UiAction::Menu;
            return UiAction::Resume;
        case Phase::GameOver:
            if (L.inMenuButton(x, y)) return UiAction::Menu;
            return m.phaseTime > 0.7f ? UiAction::Retry : UiAction::None;
        case Phase::Crashed: break;
    }
    return UiAction::None;
}

}  // namespace sd
