#include "particles.h"

#include <cmath>

namespace sd {

void ParticleSystem::clear() {
    for (Particle& p : pool_) p.alive = false;
    next_ = 0;
}

void ParticleSystem::emit(const Particle& p) {
    pool_[next_] = p;
    pool_[next_].alive = true;
    pool_[next_].age = 0.0f;
    next_ = (next_ + 1) % kCapacity;
}

void ParticleSystem::update(float dt) {
    for (Particle& p : pool_) {
        if (!p.alive) continue;
        p.age += dt;
        if (p.age >= p.life) {
            p.alive = false;
            continue;
        }
        p.vel *= std::exp(-p.drag * dt);
        p.vel.y -= p.gravity * dt;
        p.pos += p.vel * dt;
    }
}

void ParticleSystem::build(const Vec3& origin, std::vector<ParticleInstance>& smoke,
                           std::vector<ParticleInstance>& sparks) const {
    for (const Particle& p : pool_) {
        if (!p.alive) continue;
        const float t = p.age / p.life;
        const float fade = (1.0f - t) * (1.0f - t) * smoothstep(0.0f, 0.08f, t);
        ParticleInstance in;
        const Vec3 rel = p.pos - origin;
        in.x = rel.x; in.y = rel.y; in.z = rel.z;
        in.size = lerpf(p.size0, p.size1, t);
        in.r = p.color.r; in.g = p.color.g; in.b = p.color.b;
        in.a = to8(static_cast<float>(p.color.a) / 255.0f * fade);
        if (p.additive) {
            in.vx = p.vel.x; in.vy = p.vel.y; in.vz = p.vel.z;
            sparks.push_back(in);
        } else {
            in.vx = in.vy = in.vz = 0.0f;
            smoke.push_back(in);
        }
    }
}

}  // namespace sd
