// ui_layout.h - screen-size dependent placement of controls and buttons (landscape).
#pragma once

#include "math3d.h"

namespace sd {

struct UiLayout {
    float w = 1920.0f, h = 1080.0f;
    float u = 1.0f;         // scale unit: screen height / 1080
    float margin = 44.0f;
    Vec2 tuckC, slideC, pauseC, soundC;
    float tuckR = 120.0f, slideR = 92.0f, pauseR = 44.0f, soundR = 46.0f;
    float steerZoneRight = 0.0f;   // touches left of this x start a steering gesture
    float stickRange = 130.0f;
    float menuX = 0.0f, menuY = 0.0f, menuW = 0.0f, menuH = 0.0f;   // "MENU" button on overlays

    static UiLayout make(float w, float h) {
        UiLayout l;
        l.w = w;
        l.h = h;
        l.u = std::max(0.4f, h / 1080.0f);
        const float u = l.u;
        l.margin = std::max(36.0f * u, 0.05f * w);   // keeps the HUD clear of camera cut-outs and rounded corners
        l.tuckR = 120.0f * u;
        l.slideR = 92.0f * u;
        l.tuckC = Vec2(w - l.margin - l.tuckR - 10.0f * u, h - l.margin - l.tuckR);
        l.slideC = Vec2(l.tuckC.x - l.tuckR - l.slideR - 30.0f * u, h - l.margin - l.slideR - 20.0f * u);
        l.pauseR = 44.0f * u;
        l.pauseC = Vec2(w - l.margin - l.pauseR, l.margin + l.pauseR);
        l.soundR = 46.0f * u;
        l.soundC = Vec2(w - l.margin - l.soundR, l.margin + l.soundR);
        l.steerZoneRight = w * 0.52f;
        l.stickRange = 170.0f * u;
        l.menuW = 320.0f * u;
        l.menuH = 80.0f * u;
        l.menuX = w * 0.5f - l.menuW * 0.5f;
        l.menuY = h - l.margin - l.menuH - 10.0f * u;
        return l;
    }

    static bool inCircle(float x, float y, const Vec2& c, float r) {
        const float dx = x - c.x, dy = y - c.y;
        return dx * dx + dy * dy <= r * r;
    }
    bool inMenuButton(float x, float y) const { return x >= menuX && x <= menuX + menuW && y >= menuY && y <= menuY + menuH; }
};

}  // namespace sd
