// mesh_data.h - CPU-side mesh container with procedural primitives.
#pragma once

#include <cstdint>
#include <vector>

#include "color.h"
#include "math3d.h"

namespace sd {

struct MeshVertex {
    float px, py, pz;
    float nx, ny, nz;
    uint8_t r, g, b, a;
    uint8_t tint, emissive, foliage, sway;
};
static_assert(sizeof(MeshVertex) == 32, "MeshVertex must be tightly packed");

struct Material {
    uint8_t tint = 0;      // 255: multiply albedo by the per-instance tint
    uint8_t emissive = 0;  // self illumination
    uint8_t foliage = 0;   // wrap lighting + back-light translucency
    uint8_t sway = 0;      // wind sway weight
};

class MeshData {
public:
    std::vector<MeshVertex> vertices;
    std::vector<uint16_t> indices;

    void clear() { vertices.clear(); indices.clear(); }
    bool empty() const { return indices.empty(); }

    uint16_t addVertex(const Vec3& p, const Vec3& n, Rgba8 c, Material m);
    // Adds a triangle, flipping the winding if needed so it faces along the vertex normals.
    void addTriangle(uint16_t a, uint16_t b, uint16_t c);
    void addQuad(uint16_t a, uint16_t b, uint16_t c, uint16_t d);

    // Box centred on the origin (before xf); colour blends bottom -> top along local Y.
    void addBox(const Mat4& xf, const Vec3& half, Rgba8 bottom, Rgba8 top, Material m = {});
    void addBox(const Mat4& xf, const Vec3& half, Rgba8 c, Material m = {}) { addBox(xf, half, c, c, m); }
    // Frustum along +Y starting at the origin: radius r0 at y=0 to r1 at y=height.
    void addFrustum(const Mat4& xf, float r0, float r1, float height, int segments, Rgba8 bottom, Rgba8 top,
                    Material m, float normalLift = 0.0f, bool capBottom = false, bool capTop = false);
    // Displaced icosphere (rocks, tree crowns).
    void addBlob(const Mat4& xf, const Vec3& radii, uint32_t seed, int subdiv, float roughness, bool flatShaded,
                 Rgba8 bottom, Rgba8 top, Material m, float flatBottom = 0.0f);
    void append(const MeshData& other, const Mat4& xf);
};

}  // namespace sd
