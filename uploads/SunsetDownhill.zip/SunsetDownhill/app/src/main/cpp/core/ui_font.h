// ui_font.h - monoline stroke font (digits, A-Z and a little punctuation), drawn as quads.
#pragma once

#include "ui_batch.h"

namespace sd {

enum class TextAlign { Left, Center, Right };

// `size` is the cap height in pixels. (x, y) is the top of the text; returns the drawn width.
float drawText(UiBatch& ui, const char* text, float x, float y, float size, Rgba8 color, TextAlign align = TextAlign::Left);
float textWidth(const char* text, float size);

}  // namespace sd
