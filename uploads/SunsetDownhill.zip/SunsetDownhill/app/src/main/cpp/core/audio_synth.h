// audio_synth.h - procedural sound (wind, rumble, slides, crashes, UI beeps). No audio assets needed.
// The game thread publishes state through atomics; the audio thread calls render().
#pragma once

#include <atomic>
#include <cstdint>

namespace sd {

enum class AudioEvent : int { Tick = 0, Go, Crash, Scrape, NearMiss, ConeHit, NewBest, Count };

struct AudioState {
    float speed = 0.0f;    // m/s
    float slide = 0.0f;    // 0..1
    float offroad = 0.0f;  // 0..1
    float tuck = 0.0f;     // 0..1
    float master = 1.0f;   // 0 = silent
};

class AudioSynth {
public:
    static constexpr int kSampleRate = 22050;

    AudioSynth();
    // ---- game thread
    void setState(const AudioState& s);
    void trigger(AudioEvent e);
    // ---- audio thread
    void render(int16_t* out, int frames);

private:
    static constexpr int kEvents = static_cast<int>(AudioEvent::Count);
    float noise();

    std::atomic<float> speed_{0.0f}, slide_{0.0f}, offroad_{0.0f}, tuck_{0.0f}, master_{1.0f};
    std::atomic<uint32_t> counters_[kEvents];

    // audio-thread state
    uint32_t seen_[kEvents];
    uint32_t rng_ = 0x2545F491u;
    float speedS_ = 0.0f, slideS_ = 0.0f, offroadS_ = 0.0f, tuckS_ = 0.0f, masterS_ = 0.0f;
    float wind1_ = 0.0f, wind2_ = 0.0f, rum1_ = 0.0f, rum2_ = 0.0f, gravel_ = 0.0f;
    float svfLow_ = 0.0f, svfBand_ = 0.0f;
    float gustPhase_ = 0.0f, distAcc_ = 0.0f, seamEnv_ = 0.0f, seamT_ = 0.0f;
    float tickT_ = -1.0f, goT_ = -1.0f, crashT_ = -1.0f, missT_ = -1.0f, coneT_ = -1.0f, bestT_ = -1.0f;
    float scrapeEnv_ = 0.0f, scrapeLp_ = 0.0f, crashLp_ = 0.0f, missLp_ = 0.0f;
};

AudioSynth& audioSynth();

}  // namespace sd
