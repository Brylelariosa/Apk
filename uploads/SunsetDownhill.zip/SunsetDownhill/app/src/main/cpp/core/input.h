// input.h - multi-touch handling: floating steering stick, tuck/slide buttons, UI taps.
#pragma once

#include "math3d.h"
#include "skater.h"
#include "ui_layout.h"

namespace sd {

enum TouchAction { kTouchDown = 0, kTouchMove = 1, kTouchUp = 2, kTouchCancel = 3 };

class TouchController {
public:
    void setLayout(const UiLayout& layout) { layout_ = layout; }
    // In gameplay, touches become steer / tuck / slide; otherwise every touch is a UI tap.
    void setGameplay(bool on) { gameplay_ = on; }
    void onTouch(int action, int id, float x, float y);
    void releaseAll();

    SkaterInput input() const;
    // Taps (touch-down events that are not gameplay controls), oldest first.
    bool popTap(Vec2& out);

    bool steerActive() const { return steerPtr_ >= 0; }
    Vec2 stickOrigin() const { return stickOrigin_; }
    Vec2 stickKnob() const { return stickKnob_; }
    bool tuckDown() const { return role_(Role::Tuck); }
    bool slideDown() const { return role_(Role::Slide); }

private:
    enum class Role : uint8_t { None, Steer, Tuck, Slide, Tap };
    struct Pointer {
        bool active = false;
        int id = -1;
        Role role = Role::None;
    };
    static constexpr int kMaxPointers = 10;

    int find(int id) const;
    int allocate(int id);
    bool role_(Role r) const;
    void updateSteer(float x);

    UiLayout layout_;
    bool gameplay_ = false;
    Pointer ptr_[kMaxPointers];
    int steerPtr_ = -1;
    Vec2 stickOrigin_, stickKnob_;
    float steer_ = 0.0f;
    Vec2 taps_[8];
    int tapCount_ = 0;
};

}  // namespace sd
