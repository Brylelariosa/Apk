// skater_model.h - procedural blocky rider + longboard built from boxes each frame.
#pragma once

#include "math3d.h"
#include "mesh_data.h"

namespace sd {

struct SkaterPose {
    Vec3 origin;            // board centre on the road surface
    Vec3 right, up, fwd;    // board basis (orthonormal)
    float tuck = 0.0f;      // 0..1 crouch
    float lean = 0.0f;      // rider lean into the turn (rad, + right)
    float slide = 0.0f;     // 0..1
    float slideDir = 1.0f;  // side of the slide
    float push = 0.0f;      // 0..1 pushing animation strength
    float pushPhase = 0.0f;
    float time = 0.0f;
    bool crashed = false;
    float crashTime = 0.0f;
    float crashSpeed = 0.0f;
};

void buildSkaterMesh(const SkaterPose& pose, MeshData& out);

}  // namespace sd
