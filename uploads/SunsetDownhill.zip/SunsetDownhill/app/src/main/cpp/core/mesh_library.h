// mesh_library.h - procedural meshes for every instanced scenery batch.
#pragma once

#include "scene_types.h"

namespace sd {

// Builds the static mesh for a batch. +Y up, -Z is the object's forward direction.
MeshData buildBatchMesh(Batch batch);

}  // namespace sd
