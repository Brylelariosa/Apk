#include "game.h"

#include <chrono>
#include <cmath>
#include <cstdio>

namespace sd {

Game::Game() : fxRng_(4242u) {
    baseSeed_ = static_cast<uint32_t>(std::chrono::steady_clock::now().time_since_epoch().count());
    resetDemo();
}

// --------------------------------------------------------------------------------------
// Commands
// --------------------------------------------------------------------------------------

void Game::resetDemo() {
    world_.reset(hash2(baseSeed_, 7777u + demoCounter_++));
    world_.setObstaclesEnabled(false);
    skater_.reset(30.0f, 12.0f);
    autopilot_ = AutoPilot();
    autopilot_.speedCap = 19.0f;
    world_.update(0.0f, skater_.s);
    camera_.reset(world_.track(), skater_);
    fx_.clear();
    sunAz_ = world_.track().at(skater_.s + 260.0f).heading + 0.38f;
    atmo_ = makeAtmosphere(0.0f, sunAz_);
}

void Game::startRun() {
    if (phase_ != Phase::Menu && phase_ != Phase::GameOver) return;
    ++runCounter_;
    world_.reset(hash2(baseSeed_, runCounter_ * 2654435761u));
    world_.setObstaclesEnabled(true);
    skater_.reset(6.0f, 0.0f);
    world_.update(0.0f, skater_.s);
    camera_.reset(world_.track(), skater_);
    fx_.clear();
    style_ = 0.0f;
    driftPoints_ = 0.0f;
    nearMisses_ = 0;
    crashKind_ = -1;
    newBest_ = false;
    popupAge_ = 99.0f;
    flash_ = 0.0f;
    lastTick_ = 99;
    phase_ = Phase::Countdown;
    phaseTime_ = 0.0f;
    sunAz_ = world_.track().at(skater_.s + 260.0f).heading + 0.38f;
}

void Game::pause() {
    if (phase_ == Phase::Running || phase_ == Phase::Countdown) {
        pausedFrom_ = phase_;
        phase_ = Phase::Paused;
    }
}

void Game::resume() {
    if (phase_ == Phase::Paused) phase_ = pausedFrom_;
}

void Game::toMenu() {
    phase_ = Phase::Menu;
    phaseTime_ = 0.0f;
    resetDemo();
}

bool Game::handleBack() {
    switch (phase_) {
        case Phase::Running:
        case Phase::Countdown: pause(); return true;
        case Phase::Paused:
        case Phase::Crashed:
        case Phase::GameOver: toMenu(); return true;
        case Phase::Menu: break;
    }
    return false;
}

GameEvents Game::takeEvents() {
    GameEvents e = events_;
    events_ = GameEvents();
    return e;
}

int Game::countdownNumber() const {
    if (phase_ != Phase::Countdown && !(phase_ == Phase::Paused && pausedFrom_ == Phase::Countdown)) return 0;
    return std::max(0, 3 - static_cast<int>(phaseTime_ / cfg::kCountdownStep));
}

float Game::countdownProgress() const {
    const float t = std::fmod(phaseTime_, cfg::kCountdownStep) / cfg::kCountdownStep;
    return saturate(t);
}

float Game::popupAlpha() const {
    if (popupAge_ > 1.5f) return 0.0f;
    return popupAge_ < 1.0f ? 1.0f : 1.0f - (popupAge_ - 1.0f) / 0.5f;
}

void Game::showPopup(const char* text) {
    std::snprintf(popupText_, sizeof(popupText_), "%s", text);
    popupAge_ = 0.0f;
}

// --------------------------------------------------------------------------------------
// Simulation
// --------------------------------------------------------------------------------------

void Game::update(float dt, const SkaterInput& input) {
    dt = clampf(dt, 0.0f, 0.05f);
    if (phase_ == Phase::Paused) return;
    time_ += dt;
    phaseTime_ += dt;
    popupAge_ += dt;
    flash_ = std::max(0.0f, flash_ - dt * 2.2f);

    const int steps = std::max(1, static_cast<int>(std::ceil(dt / cfg::kMaxPhysicsStep)));
    const float h = dt / static_cast<float>(steps);
    bool scraping = false;
    float intro = 0.0f;

    switch (phase_) {
        case Phase::Menu: {
            for (int i = 0; i < steps; ++i) {
                world_.update(h, skater_.s);
                const SkaterInput in = autopilot_.compute(world_.track(), world_.obstacles(), skater_);
                skater_.step(in, world_.track(), h);
            }
            if (skater_.crashed || skater_.s > 3000.0f) resetDemo();
            break;
        }
        case Phase::Countdown: {
            world_.update(0.0f, skater_.s);
            const int num = 3 - static_cast<int>(phaseTime_ / cfg::kCountdownStep);
            if (num != lastTick_) {
                lastTick_ = num;
                if (num >= 1) events_.tick = num;
            }
            intro = 1.0f - smoothstep(0.0f, 3.0f * cfg::kCountdownStep, phaseTime_);
            if (phaseTime_ >= 3.0f * cfg::kCountdownStep) {
                phase_ = Phase::Running;
                phaseTime_ = 0.0f;
                skater_.startPush();
                events_.go = true;
            }
            break;
        }
        case Phase::Running: {
            for (int i = 0; i < steps; ++i) {
                world_.update(h, skater_.s);
                const SkaterEvent ev = skater_.step(input, world_.track(), h);
                if (ev == SkaterEvent::Scrape) scraping = true;
                if (!skater_.crashed) collide();
                if (skater_.crashed) break;
            }
            // scoring
            if (!skater_.crashed) {
                if (skater_.slide > 0.5f && skater_.speed > 9.0f) {
                    const float pts = dt * skater_.speed * 0.5f;
                    style_ += pts;
                    driftPoints_ += pts;
                } else if (skater_.slide < 0.25f && driftPoints_ > 0.0f) {
                    if (driftPoints_ > 18.0f) {
                        char buf[40];
                        std::snprintf(buf, sizeof(buf), "DRIFT +%d", static_cast<int>(driftPoints_));
                        showPopup(buf);
                    }
                    driftPoints_ = 0.0f;
                }
            }
            if (skater_.crashed) onCrash();
            break;
        }
        case Phase::Crashed: {
            for (int i = 0; i < steps; ++i) skater_.step(SkaterInput(), world_.track(), h);
            world_.update(dt, skater_.s);
            if (phaseTime_ > cfg::kCrashDuration) finishRun();
            break;
        }
        case Phase::GameOver: {
            for (int i = 0; i < steps; ++i) skater_.step(SkaterInput(), world_.track(), h);
            world_.update(dt, skater_.s);
            break;
        }
        case Phase::Paused: break;
    }

    if (scraping) events_.scrape = true;

    emitFx(dt, scraping);
    fx_.update(dt);

    const float orbitTarget = phase_ == Phase::Menu ? 1.0f : 0.0f;
    orbit_ += (orbitTarget - orbit_) * smoothing(1.5f, dt);
    camera_.update(dt, world_.track(), skater_, intro, orbit_, time_);

    // atmosphere: golden hour -> dusk over the first few kilometres; sun stays roughly ahead
    const float sunTarget = world_.track().at(skater_.s + 260.0f).heading + 0.38f;
    sunAz_ += (sunTarget - sunAz_) * smoothing(0.35f, dt);
    atmo_ = makeAtmosphere(smoothstep(0.0f, 4500.0f, skater_.distance), sunAz_);
}

void Game::collide() {
    for (Obstacle& o : world_.obstacles()) {
        if (o.hit) continue;
        const float ds = o.s - skater_.s;
        if (ds > 10.0f || ds < -10.0f) continue;
        const float dx = std::fabs(o.x - skater_.x);
        const float lim = o.hs + cfg::kSkaterHalfLength;
        if (std::fabs(ds) < lim) {
            const float gap = dx - (o.hx + cfg::kSkaterHalfWidth);
            if (gap < 0.0f) {
                if (o.kind == ObstacleKind::Cone) {
                    o.hit = true;
                    o.hitTime = 0.0f;
                    o.knockDir = (o.x - skater_.x) >= 0.0f ? 1.0f : -1.0f;
                    skater_.speed *= 0.88f;
                    events_.coneHit = true;
                    camera_.addShake(0.25f);
                    const TrackSample f = world_.track().at(o.s);
                    burst(Track::surfacePoint(f, o.x, 0.3f), 0, 8, f.up * 2.0f);
                } else {
                    crashKind_ = static_cast<int>(o.kind);
                    skater_.crash(CrashCause::Obstacle);
                    return;
                }
            } else {
                o.minGap = std::min(o.minGap, gap);
            }
        }
        if (!o.passed && ds < -(o.hs + 0.6f)) {
            o.passed = true;
            if (o.kind != ObstacleKind::Cone && o.minGap < 0.9f) {
                ++nearMisses_;
                style_ += 40.0f;
                events_.nearMiss = true;
                showPopup("CLOSE CALL +40");
            }
        }
    }
}

void Game::onCrash() {
    phase_ = Phase::Crashed;
    phaseTime_ = 0.0f;
    events_.crash = true;
    flash_ = 0.55f;
    camera_.addShake(1.0f);
    Vec3 pos, r, u, f;
    skaterFrame(pos, r, u, f);
    burst(pos + u * 0.5f, 22, 26, f * (skater_.speed * 0.3f) + u * 3.0f);
    driftPoints_ = 0.0f;
}

void Game::finishRun() {
    phase_ = Phase::GameOver;
    phaseTime_ = 0.0f;
    if (score() > best_) {
        best_ = score();
        newBest_ = true;
        events_.newBest = true;
    }
}

// --------------------------------------------------------------------------------------
// Presentation helpers
// --------------------------------------------------------------------------------------

void Game::skaterFrame(Vec3& pos, Vec3& right, Vec3& up, Vec3& fwd) const {
    const TrackSample f = world_.track().at(skater_.s);
    pos = Track::surfacePoint(f, skater_.x);
    fwd = rotateAround(f.fwd, f.up, -(skater_.alpha + skater_.yawVis));
    right = normalize(cross(fwd, f.up));
    up = cross(right, fwd);
    const float roll = skater_.lean * 0.35f;
    right = rotateAround(right, fwd, roll);
    up = rotateAround(up, fwd, roll);
}

SkaterPose Game::skaterPose(const Vec3& origin) const {
    SkaterPose p;
    Vec3 pos;
    skaterFrame(pos, p.right, p.up, p.fwd);
    p.origin = pos - origin;
    p.tuck = skater_.tuck;
    p.lean = skater_.lean;
    p.slide = skater_.slide;
    p.slideDir = skater_.slideDir;
    p.push = skater_.pushAmount;
    p.pushPhase = skater_.pushPhase;
    p.time = time_;
    p.crashed = skater_.crashed;
    p.crashTime = skater_.crashTime;
    p.crashSpeed = skater_.crashSpeed;
    return p;
}

void Game::burst(const Vec3& pos, int smoke, int sparks, const Vec3& dir) {
    for (int i = 0; i < smoke; ++i) {
        Particle p;
        p.pos = pos + Vec3(fxRng_.range(-0.3f, 0.3f), fxRng_.range(0.0f, 0.4f), fxRng_.range(-0.3f, 0.3f));
        p.vel = dir * 0.4f + Vec3(fxRng_.range(-2.5f, 2.5f), fxRng_.range(0.5f, 3.0f), fxRng_.range(-2.5f, 2.5f));
        p.life = fxRng_.range(0.8f, 1.6f);
        p.size0 = 0.5f;
        p.size1 = fxRng_.range(2.0f, 3.6f);
        p.color = rgba(0.82f, 0.72f, 0.64f, 0.55f);
        p.drag = 1.6f;
        fx_.emit(p);
    }
    for (int i = 0; i < sparks; ++i) {
        Particle p;
        p.pos = pos;
        p.vel = dir + Vec3(fxRng_.range(-5.0f, 5.0f), fxRng_.range(0.0f, 5.0f), fxRng_.range(-5.0f, 5.0f));
        p.life = fxRng_.range(0.3f, 0.7f);
        p.size0 = 0.05f;
        p.size1 = 0.03f;
        p.color = rgba(1.0f, 0.72f, 0.32f, 1.0f);
        p.gravity = 9.0f;
        p.additive = true;
        fx_.emit(p);
    }
}

void Game::emitFx(float dt, bool scraping) {
    if (phase_ == Phase::Paused) return;
    Vec3 pos, r, u, f;
    skaterFrame(pos, r, u, f);
    const TrackSample ts = world_.track().at(skater_.s);
    const Vec3 travel = ts.fwd;

    // tyre smoke + sparks while sliding
    if (!skater_.crashed && skater_.slide > 0.3f && skater_.speed > 6.0f) {
        smokeAcc_ += dt * 55.0f * skater_.slide;
        sparkAcc_ += dt * 30.0f * skater_.slide;
        while (smokeAcc_ >= 1.0f) {
            smokeAcc_ -= 1.0f;
            Particle p;
            p.pos = pos - f * 0.3f + r * (skater_.slideDir * 0.25f) + u * 0.08f;
            p.vel = -travel * (skater_.speed * 0.25f) + u * 0.8f + Vec3(fxRng_.range(-0.6f, 0.6f), fxRng_.range(0.0f, 0.8f), fxRng_.range(-0.6f, 0.6f));
            p.life = fxRng_.range(0.7f, 1.2f);
            p.size0 = 0.35f;
            p.size1 = fxRng_.range(1.6f, 2.4f);
            p.color = rgba(0.92f, 0.86f, 0.82f, 0.42f);
            p.drag = 1.4f;
            fx_.emit(p);
        }
        while (sparkAcc_ >= 1.0f) {
            sparkAcc_ -= 1.0f;
            Particle p;
            p.pos = pos + r * (skater_.slideDir * 0.3f) + u * 0.05f;
            p.vel = -travel * (skater_.speed * 0.2f) + u * fxRng_.range(0.5f, 2.5f) + r * fxRng_.range(-1.5f, 1.5f);
            p.life = fxRng_.range(0.2f, 0.45f);
            p.size0 = 0.05f;
            p.size1 = 0.03f;
            p.color = rgba(1.0f, 0.75f, 0.35f, 1.0f);
            p.gravity = 9.0f;
            p.additive = true;
            fx_.emit(p);
        }
    }

    // gravel dust on the shoulder
    if (!skater_.crashed && skater_.onShoulder && skater_.speed > 5.0f) {
        dustAcc_ += dt * 40.0f;
        while (dustAcc_ >= 1.0f) {
            dustAcc_ -= 1.0f;
            Particle p;
            p.pos = pos + u * 0.05f;
            p.vel = -travel * (skater_.speed * 0.2f) + Vec3(fxRng_.range(-1.0f, 1.0f), fxRng_.range(0.4f, 1.6f), fxRng_.range(-1.0f, 1.0f));
            p.life = fxRng_.range(0.8f, 1.4f);
            p.size0 = 0.3f;
            p.size1 = fxRng_.range(1.4f, 2.2f);
            p.color = rgba(0.62f, 0.5f, 0.36f, 0.42f);
            p.drag = 1.2f;
            fx_.emit(p);
        }
    }

    // sparks from rail contact
    if (scraping) {
        const Vec3 contact = Track::surfacePoint(ts, sign1(skater_.x) * cfg::kRailOffset, 0.35f);
        for (int i = 0; i < 5; ++i) {
            Particle p;
            p.pos = contact;
            p.vel = -travel * fxRng_.range(2.0f, 9.0f) + u * fxRng_.range(0.5f, 4.0f) - ts.right0 * (sign1(skater_.x) * fxRng_.range(0.0f, 3.0f));
            p.life = fxRng_.range(0.25f, 0.6f);
            p.size0 = 0.06f;
            p.size1 = 0.03f;
            p.color = rgba(1.0f, 0.8f, 0.4f, 1.0f);
            p.gravity = 9.0f;
            p.additive = true;
            fx_.emit(p);
        }
    }
}

}  // namespace sd
