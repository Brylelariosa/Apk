// scene_builder.h - converts the game state into renderer input (geometry + frame parameters).
#pragma once

#include "game.h"
#include "renderer.h"
#include "scene_types.h"

namespace sd {

// Clears and refills `geo`; returns the per-frame render parameters.
FrameParams buildScene(Game& game, float treeDensity, SceneGeometry& geo);

}  // namespace sd
