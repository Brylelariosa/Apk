// color.h - 8-bit RGBA colour used by meshes and UI.
#pragma once

#include <cstdint>

#include "math3d.h"

namespace sd {

struct Rgba8 {
    uint8_t r = 255, g = 255, b = 255, a = 255;
};

inline uint8_t to8(float v) { return static_cast<uint8_t>(saturate(v) * 255.0f + 0.5f); }
inline Rgba8 rgba(float r, float g, float b, float a = 1.0f) { return {to8(r), to8(g), to8(b), to8(a)}; }
inline Rgba8 withAlpha(Rgba8 c, float a) { c.a = to8(a); return c; }
inline Rgba8 mix(Rgba8 a, Rgba8 b, float t) {
    auto m = [t](uint8_t x, uint8_t y) { return static_cast<uint8_t>(x + (y - x) * t + 0.5f); };
    return {m(a.r, b.r), m(a.g, b.g), m(a.b, b.b), m(a.a, b.a)};
}

}  // namespace sd
