#include "engine.h"

#include <algorithm>

#include "audio_synth.h"
#include "log.h"

namespace sd {

Engine::Engine() {
    layout_ = UiLayout::make(1920.0f, 1080.0f);
}

void Engine::setSettings(int bestScore, bool soundOn) {
    game_.setBest(bestScore);
    best_.store(bestScore);
    soundOn_.store(soundOn);
}

void Engine::onSurfaceCreated() {
    renderer_.onContextCreated();
    haveLast_ = false;
    warmup_ = 4.0f;
    govTimer_ = govFrameTime_ = 0.0f;
    govFrames_ = 0;
    touch_.releaseAll();
}

void Engine::onSurfaceChanged(int width, int height) {
    width_ = std::max(1, width);
    height_ = std::max(1, height);
    layout_ = UiLayout::make(static_cast<float>(width_), static_cast<float>(height_));
    renderer_.onResize(width_, height_);
}

void Engine::onTouch(int action, int pointerId, float x, float y) {
    touch_.onTouch(action, pointerId, x, y);
}

bool Engine::requestBack() {
    if (phase_.load() == static_cast<int>(Phase::Menu)) return false;
    backRequested_.store(true);
    return true;
}

void Engine::onDrawFrame() {
    const auto now = std::chrono::steady_clock::now();
    float dt = 1.0f / 60.0f;
    if (haveLast_) dt = std::chrono::duration<float>(now - last_).count();
    last_ = now;
    haveLast_ = true;
    stepFrame(dt);
}

HudModel Engine::makeHudModel() const {
    HudModel m;
    m.phase = game_.phase();
    m.phaseTime = game_.phaseTime();
    m.time = game_.time();
    m.speedKmh = game_.speedKmh();
    m.distanceM = game_.distanceM();
    m.score = game_.score();
    m.best = game_.best();
    m.newBest = game_.newBest();
    m.topSpeedKmh = game_.topSpeedKmh();
    m.nearMisses = game_.nearMisses();
    m.countdown = game_.countdownNumber();
    m.countdownProgress = game_.countdownProgress();
    m.popup = game_.popupText();
    m.popupAlpha = game_.popupAlpha();
    m.popupAge = game_.popupAge();
    m.soundOn = soundOn_.load();
    m.steerActive = touch_.steerActive();
    m.stickOrigin = touch_.stickOrigin();
    m.stickKnob = touch_.stickKnob();
    m.tuckDown = touch_.tuckDown();
    m.slideDown = touch_.slideDown();
    return m;
}

void Engine::applyAction(UiAction action) {
    switch (action) {
        case UiAction::Start:
        case UiAction::Retry:
            touch_.releaseAll();
            game_.startRun();
            break;
        case UiAction::Pause: game_.pause(); break;
        case UiAction::Resume: game_.resume(); break;
        case UiAction::Menu:
            touch_.releaseAll();
            game_.toMenu();
            break;
        case UiAction::ToggleSound: soundOn_.store(!soundOn_.load()); break;
        case UiAction::None: break;
    }
}

void Engine::updateQuality(float dt) {
    if (!renderer_.ready() || game_.phase() == Phase::Paused) return;
    if (warmup_ > 0.0f) {
        warmup_ -= dt;
        return;
    }
    raiseLockout_ = std::max(0.0f, raiseLockout_ - dt);
    sinceRaise_ += dt;
    govFrameTime_ += dt;
    ++govFrames_;
    govTimer_ += dt;
    if (govTimer_ < 1.5f) return;
    const float avgMs = govFrameTime_ / static_cast<float>(govFrames_) * 1000.0f;
    govTimer_ = govFrameTime_ = 0.0f;
    govFrames_ = 0;
    const int tier = renderer_.qualityTier();
    if (avgMs > 24.0f && tier > 0) {
        if (sinceRaise_ < 20.0f) noRaise_ = true;   // the last increase was too much: stop trying
        renderer_.setQualityTier(tier - 1);
        raiseLockout_ = 25.0f;
        stableTime_ = 0.0f;
        SD_LOGI("quality -> tier %d (avg %.1f ms)", tier - 1, avgMs);
    } else if (avgMs < 17.8f && tier < kQualityTiers - 1 && !noRaise_) {
        stableTime_ += 1.5f;
        if (stableTime_ >= 7.5f && raiseLockout_ <= 0.0f) {
            renderer_.setQualityTier(tier + 1);
            raiseLockout_ = 25.0f;
            sinceRaise_ = 0.0f;
            stableTime_ = 0.0f;
            SD_LOGI("quality -> tier %d (avg %.1f ms)", tier + 1, avgMs);
        }
    } else {
        stableTime_ = 0.0f;
    }
}

void Engine::updateAudio(const GameEvents& ev) {
    AudioSynth& audio = audioSynth();
    if (ev.tick) audio.trigger(AudioEvent::Tick);
    if (ev.go) audio.trigger(AudioEvent::Go);
    if (ev.push) audio.trigger(AudioEvent::Push);
    if (ev.footOn) audio.trigger(AudioEvent::FootOn);
    if (ev.crash) audio.trigger(AudioEvent::Crash);
    if (ev.scrape) audio.trigger(AudioEvent::Scrape);
    if (ev.nearMiss) audio.trigger(AudioEvent::NearMiss);
    if (ev.coneHit) audio.trigger(AudioEvent::ConeHit);
    if (ev.newBest) audio.trigger(AudioEvent::NewBest);

    const Skater& sk = game_.skater();
    const Phase ph = game_.phase();
    AudioState s;
    const bool silent = !soundOn_.load() || ph == Phase::Paused;
    s.speed = ph == Phase::Paused ? 0.0f : sk.speed * (ph == Phase::Menu ? 0.7f : 1.0f);
    s.slide = sk.slide;
    s.offroad = sk.onShoulder && !sk.crashed ? 1.0f : 0.0f;
    s.tuck = sk.tuck;
    s.master = silent ? 0.0f : (ph == Phase::Menu ? 0.6f : 1.0f);
    audio.setState(s);
}

void Engine::stepFrame(float dt) {
    dt = clampf(dt, 0.0f, 0.1f);
    updateQuality(dt);

    if (pauseRequested_.exchange(false)) game_.pause();
    if (backRequested_.exchange(false)) game_.handleBack();

    touch_.setLayout(layout_);
    touch_.setGameplay(game_.phase() == Phase::Running);
    Vec2 tap;
    while (touch_.popTap(tap)) applyAction(hudHandleTap(layout_, makeHudModel(), tap.x, tap.y));

    const SkaterInput input = game_.phase() == Phase::Running ? touch_.input() : SkaterInput();
    game_.update(dt, input);
    updateAudio(game_.takeEvents());
    phase_.store(static_cast<int>(game_.phase()));
    best_.store(game_.best());

    const float density = qualityPreset(renderer_.qualityTier()).treeDensity;
    const FrameParams fp = buildScene(game_, density, geo_);
    ui_.clear();
    ui_.setScreen(layout_.w, layout_.h);
    drawHud(ui_, layout_, makeHudModel());
    renderer_.render(fp, geo_, ui_);
}

}  // namespace sd
