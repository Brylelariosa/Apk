// renderer.h - OpenGL ES 3 renderer: shadow pass, scene pass, post processing and UI.
#pragma once

#include <GLES3/gl3.h>

#include "atmosphere.h"
#include "camera.h"
#include "gl_util.h"
#include "scene_types.h"
#include "ui_batch.h"

namespace sd {

struct FrameParams {
    CameraView cam;
    Atmosphere atmo;
    float time = 0.0f;
    float speed01 = 0.0f;
    float slide = 0.0f;
    float flash = 0.0f;
    Vec3 shadowFocus;  // absolute world position the shadow map is centred on
};

struct QualitySettings {
    float renderScale;   // fraction of the display resolution used for the 3D scene
    int shadowSize;      // 0 = shadows off
    float treeDensity;   // fraction of trees drawn
    bool fxaa;
    int blurTaps;
};

constexpr int kQualityTiers = 4;
const QualitySettings& qualityPreset(int tier);

class Renderer {
public:
    // (Re)creates every GL object. Call from the GL thread whenever the context is (re)created.
    void onContextCreated();
    void onResize(int width, int height);
    void render(const FrameParams& fp, const SceneGeometry& geo, const UiBatch& ui);

    void setQualityTier(int tier);
    int qualityTier() const { return tier_; }
    bool ready() const { return ready_; }
    int width() const { return width_; }
    int height() const { return height_; }
    float aspect() const { return height_ > 0 ? static_cast<float>(width_) / static_cast<float>(height_) : 1.0f; }

private:
    struct GpuMesh {
        GLuint vao = 0, vbo = 0, ibo = 0, instanceVbo = 0;
        GLsizei indexCount = 0;
    };

    void forgetAll();
    bool buildPrograms();
    void buildGeometry();
    void applyQuality();
    void setupMeshAttribs(GLuint vao, GLuint vbo, GLuint ibo, GLuint instanceVbo);
    void uploadFrame(const SceneGeometry& geo, const UiBatch& ui);
    void computeShadow(const FrameParams& fp, Mat4& lightVP, Mat4& shadowMat) const;
    void drawShadowPass(const FrameParams& fp, const Mat4& lightVP, const SceneGeometry& geo);
    void setLitUniforms(ShaderProgram& p, const FrameParams& fp, bool shadowOn, const Mat4& shadowMat);
    void drawDynamicMesh();

    ShaderProgram sky_, terrain_, mesh_, shadowProg_, particle_, post_, ui_;
    GpuMesh batches_[kBatchCount];
    GLuint terrainVao_ = 0, terrainVbo_ = 0, terrainIbo_ = 0;
    GLsizei terrainIndexCount_ = 0, terrainVertexCount_ = 0;
    GLuint dynVao_ = 0, dynVbo_ = 0, dynIbo_ = 0;
    GLsizei dynIndexCount_ = 0;
    GLuint quadVbo_ = 0, smokeVao_ = 0, smokeVbo_ = 0, sparkVao_ = 0, sparkVbo_ = 0;
    GLsizei smokeCount_ = 0, sparkCount_ = 0;
    GLuint uiVao_ = 0, uiVbo_ = 0;
    GLsizei uiCount_ = 0;
    GLuint emptyVao_ = 0;
    GLuint dummyDepthTex_ = 0;
    GLsizei instanceCount_[kBatchCount] = {0};

    RenderTarget scene_;
    ShadowTarget shadow_;
    bool direct_ = false;   // scene target unavailable: render straight to the screen
    int width_ = 0, height_ = 0;
    int tier_ = 2;
    bool ready_ = false;
};

}  // namespace sd
