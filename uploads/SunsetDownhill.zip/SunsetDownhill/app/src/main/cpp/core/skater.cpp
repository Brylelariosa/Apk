#include "skater.h"

#include <algorithm>
#include <cmath>

namespace sd {

void Skater::reset(float s0, float speed0) {
    *this = Skater();
    s = s0;
    speed = speed0;
}

void Skater::startPush() {
    pushTimer = cfg::kPushTime;
}

void Skater::crash(CrashCause cause) {
    if (crashed) return;
    crashed = true;
    crashCause = cause;
    crashTime = 0.0f;
    crashSpeed = speed;
    slide = 0.0f;
    tuck = 0.0f;
}

float Skater::gripNow() const {
    return cfg::kGrip * (1.0f + cfg::kSlideGripBoost * slide) * (1.0f - cfg::kTuckGripCut * tuck) *
           (onShoulder ? 0.55f : 1.0f);
}

SkaterEvent Skater::step(const SkaterInput& in, const Track& track, float dt) {
    SkaterEvent ev = SkaterEvent::None;
    scrape = std::max(0.0f, scrape - dt * 4.0f);

    if (crashed) {
        crashTime += dt;
        speed *= std::exp(-1.1f * dt);
        s += speed * std::cos(alpha) * dt;
        x += speed * std::sin(alpha) * dt * 0.5f;
        x = clampf(x, -cfg::kRailOffset, cfg::kRailOffset);
        return ev;
    }

    const float curv = track.curvatureAt(s);
    const float pitch = track.pitchAt(s);

    // ---- controls
    const bool pushing = pushTimer > 0.0f;
    steer += (clampf(in.steer, -1.0f, 1.0f) - steer) * smoothing(cfg::kSteerResponse, dt);
    const float tuckTarget = (in.tuck && !pushing) ? 1.0f : 0.0f;
    tuck += (tuckTarget - tuck) * smoothing(7.0f, dt);
    const bool slideWanted = in.slide && speed > 3.0f && !pushing;
    slide += ((slideWanted ? 1.0f : 0.0f) - slide) * smoothing(slideWanted ? 12.0f : 6.0f, dt);

    // ---- heading
    const float wMax = std::min(cfg::kYawRateMax * (1.0f + 0.4f * slide), gripNow() / std::max(speed, 3.0f));
    const float omega = steer * wMax;
    const float follow = curv * speed * (1.0f - cfg::kAutoFollow);
    alpha += (omega - follow - cfg::kStability * (1.0f - 0.6f * slide) * alpha) * dt;
    alpha = clampf(alpha, -1.15f, 1.15f);

    // ---- speed
    const float aGrav = cfg::kGravity * std::sin(pitch) * cfg::kGravityScale;
    const float drag = cfg::kDragCoef * (1.0f - cfg::kTuckDragCut * tuck);
    float a = aGrav - drag * speed * speed - cfg::kRolling - std::fabs(omega) * speed * 0.02f;
    a -= slide * (cfg::kSlideDecelBase + cfg::kSlideDecelDrag * speed * speed);
    if (onShoulder) a -= cfg::kShoulderDrag * speed;
    if (pushing) {
        a += cfg::kPushAccel * saturate(pushTimer / 0.35f);
        pushTimer = std::max(0.0f, pushTimer - dt);
    }
    speed = std::max(0.0f, speed + a * dt);

    // ---- bail out if the rider has come to a halt
    if (!pushing && speed < 1.0f) {
        stallTime += dt;
        if (stallTime > cfg::kStallTime) {
            crash(CrashCause::Stall);
            return SkaterEvent::Crash;
        }
    } else {
        stallTime = 0.0f;
    }

    // ---- kinematics
    const float denom = std::max(0.35f, 1.0f - curv * x);
    s += speed * std::cos(alpha) / denom * dt;
    x += speed * std::sin(alpha) * dt;
    distance += speed * dt;
    topSpeed = std::max(topSpeed, speed);

    // ---- road edges
    onShoulder = std::fabs(x) > cfg::kRoadHalfWidth;
    if (std::fabs(x) > cfg::kRailOffset) {
        const float side = sign1(x);
        const float outSpeed = speed * std::sin(alpha) * side;
        if (outSpeed > cfg::kCrashLateralSpeed) {
            crash(CrashCause::Rail);
            return SkaterEvent::Crash;
        }
        x = side * cfg::kRailOffset;
        if (outSpeed > 0.0f) {
            alpha = -alpha * 0.35f;
            speed = std::max(0.0f, speed - outSpeed * 0.8f);
        }
        speed *= 1.0f - 1.5f * dt;
        scrape = 1.0f;
        railTime += dt;
        railClear = 0.0f;
        ev = SkaterEvent::Scrape;
        if (railTime > cfg::kRailGrindLimit) {  // grinding along the rail for too long
            crash(CrashCause::Rail);
            return SkaterEvent::Crash;
        }
    } else {
        railClear += dt;
        if (railClear > 0.5f) railTime = std::max(0.0f, railTime - dt * 0.8f);
    }

    // ---- visuals
    if (std::fabs(steer) > 0.15f) slideDir = sign1(steer);
    yawVis += (slide * slideDir * 0.95f - yawVis) * smoothing(14.0f, dt);
    const float leanTarget = clampf(steer * 0.40f + curv * speed * 0.25f, -0.55f, 0.55f);
    lean += (leanTarget - lean) * smoothing(9.0f, dt);
    pushAmount += ((pushing ? 1.0f : 0.0f) - pushAmount) * smoothing(8.0f, dt);
    if (pushing) pushPhase += dt * (kTwoPi / 0.8f);
    return ev;
}

}  // namespace sd
