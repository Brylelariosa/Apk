// config.h - every tunable gameplay / world constant in one place.
#pragma once

namespace sd {
namespace cfg {

// ---- Road geometry (metres) -------------------------------------------------
constexpr float kRoadHalfWidth = 3.6f;   // asphalt edge
constexpr float kShoulderOuter = 5.2f;   // end of gravel shoulder
constexpr float kRailOffset = 5.35f;     // lateral limit for the skater (rail / embankment)
constexpr float kLaneCenter = 1.8f;
constexpr float kTrackStep = 2.0f;       // distance between centre-line samples
constexpr float kMinCurveRadius = 54.0f;

// ---- Terrain window ---------------------------------------------------------
constexpr int kTerrainCols = 15;
inline constexpr float kTerrainOffsets[kTerrainCols] = {
    -62.0f, -36.0f, -21.0f, -12.5f, -8.0f, -5.2f, -3.6f, 0.0f,
    3.6f,   5.2f,   8.0f,   12.5f,  21.0f, 36.0f, 62.0f};
constexpr float kTerrainMaxOffset = 62.0f;
constexpr int kTerrainRings = 208;                            // rings drawn per frame
constexpr float kViewBehind = 36.0f;                          // metres of road kept behind the focus
constexpr float kViewAhead = kTerrainRings * kTrackStep - kViewBehind;
constexpr float kChunkLength = 30.0f;                         // scenery generation unit

// ---- Skater physics ---------------------------------------------------------
constexpr float kGravityScale = 3.0f;      // arcade multiplier on g * sin(pitch)
constexpr float kGravity = 9.81f;
constexpr float kDragCoef = 0.0031f;       // a = k v^2
constexpr float kRolling = 0.35f;          // constant rolling resistance (m/s^2)
constexpr float kTuckDragCut = 0.45f;      // fraction of drag removed at full tuck
constexpr float kGrip = 5.2f;              // lateral acceleration limit (m/s^2)
constexpr float kYawRateMax = 1.30f;       // rad/s at low speed
constexpr float kSteerResponse = 8.0f;     // 1/s
constexpr float kStability = 0.75f;        // board self-aligns with the road (1/s)
constexpr float kAutoFollow = 0.35f;       // fraction of road curvature the board follows on its own
constexpr float kSlideDecelBase = 4.5f;    // m/s^2
constexpr float kSlideDecelDrag = 0.0045f; // extra decel per v^2 while sliding
constexpr float kSlideGripBoost = 0.55f;
constexpr float kTuckGripCut = 0.30f;
constexpr float kShoulderDrag = 0.32f;     // gravel slows you proportionally to speed (never to a stop)
constexpr float kStallTime = 2.5f;         // seconds below 1 m/s before the rider bails
constexpr float kPushAccel = 4.2f;
constexpr float kPushTime = 1.6f;
constexpr float kRailGrindLimit = 1.1f;    // seconds of continuous rail contact before a wipe-out
constexpr float kCrashLateralSpeed = 4.2f; // m/s into the rail that causes a wipe-out
constexpr float kSkaterHalfLength = 0.45f;
constexpr float kSkaterHalfWidth = 0.35f;

// ---- Game flow --------------------------------------------------------------
constexpr float kCountdownStep = 0.85f;    // seconds per 3-2-1
constexpr float kCrashDuration = 2.1f;     // wipe-out before the results screen
constexpr float kMaxPhysicsStep = 1.0f / 120.0f;
constexpr float kDifficultyDistance = 6000.0f;   // metres until full difficulty

}  // namespace cfg
}  // namespace sd
