// rng.h - deterministic hashing, PRNG and value noise (no global state).
#pragma once

#include <cmath>
#include <cstdint>

#include "math3d.h"

namespace sd {

inline uint32_t hash32(uint32_t x) {
    x ^= x >> 16;
    x *= 0x7feb352dU;
    x ^= x >> 15;
    x *= 0x846ca68bU;
    x ^= x >> 16;
    return x;
}
inline uint32_t hash2(uint32_t a, uint32_t b) { return hash32(a * 0x9E3779B1U + hash32(b + 0x7F4A7C15U)); }
inline float hash01(uint32_t x) { return static_cast<float>(hash32(x) >> 8) * (1.0f / 16777216.0f); }

class Rng {
public:
    explicit Rng(uint32_t seed = 1u) { reseed(seed); }
    void reseed(uint32_t seed) {
        state_ = hash32(seed ^ 0xC0FFEEu);
        if (state_ == 0u) state_ = 0x1234567u;
    }
    uint32_t nextU32() {
        state_ ^= state_ << 13;
        state_ ^= state_ >> 17;
        state_ ^= state_ << 5;
        return state_;
    }
    float uniform() { return static_cast<float>(nextU32() >> 8) * (1.0f / 16777216.0f); }
    float range(float a, float b) { return a + (b - a) * uniform(); }
    int rangeInt(int a, int b) { return a + static_cast<int>(nextU32() % static_cast<uint32_t>(b - a + 1)); }
    bool chance(float p) { return uniform() < p; }

private:
    uint32_t state_ = 1u;
};

inline float latticeNoise(int xi, int yi, uint32_t seed) {
    const uint32_t h = hash32(seed ^ (static_cast<uint32_t>(xi) * 374761393U) ^ (static_cast<uint32_t>(yi) * 668265263U));
    return static_cast<float>(h >> 8) * (1.0f / 16777216.0f);
}

// Smooth value noise in [0,1].
inline float noise2(float x, float y, uint32_t seed) {
    const float fx = std::floor(x), fy = std::floor(y);
    const int xi = static_cast<int>(fx), yi = static_cast<int>(fy);
    float tx = x - fx, ty = y - fy;
    tx = tx * tx * (3.0f - 2.0f * tx);
    ty = ty * ty * (3.0f - 2.0f * ty);
    const float a = latticeNoise(xi, yi, seed), b = latticeNoise(xi + 1, yi, seed);
    const float c = latticeNoise(xi, yi + 1, seed), d = latticeNoise(xi + 1, yi + 1, seed);
    return lerpf(lerpf(a, b, tx), lerpf(c, d, tx), ty);
}

inline float fbm2(float x, float y, uint32_t seed, int octaves) {
    float amp = 0.5f, sum = 0.0f, norm = 0.0f;
    for (int i = 0; i < octaves; ++i) {
        sum += amp * noise2(x, y, seed + static_cast<uint32_t>(i) * 101U);
        norm += amp;
        x *= 2.03f;
        y *= 2.03f;
        amp *= 0.5f;
    }
    return sum / norm;
}

}  // namespace sd
