#include "input.h"

#include <cmath>

namespace sd {

int TouchController::find(int id) const {
    for (int i = 0; i < kMaxPointers; ++i)
        if (ptr_[i].active && ptr_[i].id == id) return i;
    return -1;
}

int TouchController::allocate(int id) {
    for (int i = 0; i < kMaxPointers; ++i) {
        if (!ptr_[i].active) {
            ptr_[i].active = true;
            ptr_[i].id = id;
            ptr_[i].role = Role::None;
            return i;
        }
    }
    return -1;
}

bool TouchController::role_(Role r) const {
    for (const Pointer& p : ptr_)
        if (p.active && p.role == r) return true;
    return false;
}

void TouchController::releaseAll() {
    for (Pointer& p : ptr_) p = Pointer();
    steerPtr_ = -1;
    steer_ = 0.0f;
}

void TouchController::updateSteer(float x) {
    const float range = layout_.stickRange;
    float dx = x - stickOrigin_.x;
    if (std::fabs(dx) > range) {            // drag the origin along so reversing direction is immediate
        stickOrigin_.x = x - sign1(dx) * range;
        dx = sign1(dx) * range;
    }
    stickKnob_ = Vec2(stickOrigin_.x + dx, stickOrigin_.y);
    float v = clampf(dx / range, -1.0f, 1.0f);
    const float mag = std::max(0.0f, (std::fabs(v) - 0.06f) / 0.94f);
    steer_ = sign1(v) * std::pow(mag, 1.25f);
}

void TouchController::onTouch(int action, int id, float x, float y) {
    if (action == kTouchCancel) {
        releaseAll();
        return;
    }
    if (action == kTouchDown) {
        const int slot = allocate(id);
        if (slot < 0) return;
        Pointer& p = ptr_[slot];
        if (!gameplay_) {
            p.role = Role::Tap;
            if (tapCount_ < 8) taps_[tapCount_++] = Vec2(x, y);
        } else if (UiLayout::inCircle(x, y, layout_.tuckC, layout_.tuckR * 1.15f)) {
            p.role = Role::Tuck;
        } else if (UiLayout::inCircle(x, y, layout_.slideC, layout_.slideR * 1.2f)) {
            p.role = Role::Slide;
        } else if (x < layout_.steerZoneRight && steerPtr_ < 0 && y > layout_.margin) {
            p.role = Role::Steer;
            steerPtr_ = slot;
            stickOrigin_ = Vec2(x, y);
            stickKnob_ = stickOrigin_;
            steer_ = 0.0f;
        } else {
            p.role = Role::Tap;
            if (tapCount_ < 8) taps_[tapCount_++] = Vec2(x, y);
        }
        return;
    }
    const int slot = find(id);
    if (slot < 0) return;
    if (action == kTouchMove) {
        if (slot == steerPtr_) updateSteer(x);
    } else if (action == kTouchUp) {
        if (slot == steerPtr_) {
            steerPtr_ = -1;
            steer_ = 0.0f;
        }
        ptr_[slot] = Pointer();
    }
}

SkaterInput TouchController::input() const {
    SkaterInput in;
    in.steer = steerPtr_ >= 0 ? steer_ : 0.0f;
    in.tuck = role_(Role::Tuck);
    in.slide = role_(Role::Slide);
    return in;
}

bool TouchController::popTap(Vec2& out) {
    if (tapCount_ == 0) return false;
    out = taps_[0];
    for (int i = 1; i < tapCount_; ++i) taps_[i - 1] = taps_[i];
    --tapCount_;
    return true;
}

}  // namespace sd
