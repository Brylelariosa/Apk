// shaders.h - GLSL ES 3.00 sources, composed from shared snippets.
#pragma once

#include <string>

namespace sd {
namespace shaders {

std::string skyVertex();
std::string skyFragment();
std::string terrainVertex();
std::string terrainFragment();
std::string meshVertex();       // instanced scenery; also draws the dynamic (skater) mesh with constant instance data
std::string meshFragment();
std::string shadowVertex();
std::string shadowFragment();
std::string particleVertex();
std::string particleFragment();
std::string postVertex();
std::string postFragment();
std::string uiVertex();
std::string uiFragment();

}  // namespace shaders
}  // namespace sd
