#include "audio_synth.h"

#include <algorithm>
#include <cmath>

#include "math3d.h"

namespace sd {

namespace {
constexpr float kFs = static_cast<float>(AudioSynth::kSampleRate);
inline float onePole(float fc) { return 1.0f - std::exp(-kTwoPi * fc / kFs); }
inline float sine(float freq, float t) { return std::sin(kTwoPi * freq * t); }
}  // namespace

AudioSynth::AudioSynth() {
    for (int i = 0; i < kEvents; ++i) {
        counters_[i].store(0u);
        seen_[i] = 0u;
    }
}

AudioSynth& audioSynth() {
    static AudioSynth instance;
    return instance;
}

void AudioSynth::setState(const AudioState& s) {
    speed_.store(s.speed, std::memory_order_relaxed);
    slide_.store(s.slide, std::memory_order_relaxed);
    offroad_.store(s.offroad, std::memory_order_relaxed);
    tuck_.store(s.tuck, std::memory_order_relaxed);
    master_.store(s.master, std::memory_order_relaxed);
}

void AudioSynth::trigger(AudioEvent e) {
    counters_[static_cast<int>(e)].fetch_add(1u, std::memory_order_relaxed);
}

float AudioSynth::noise() {
    rng_ ^= rng_ << 13;
    rng_ ^= rng_ >> 17;
    rng_ ^= rng_ << 5;
    return static_cast<float>(static_cast<int32_t>(rng_)) * (1.0f / 2147483648.0f);
}

void AudioSynth::render(int16_t* out, int frames) {
    const float speedT = speed_.load(std::memory_order_relaxed);
    const float slideT = slide_.load(std::memory_order_relaxed);
    const float offT = offroad_.load(std::memory_order_relaxed);
    const float tuckT = tuck_.load(std::memory_order_relaxed);
    const float masterT = master_.load(std::memory_order_relaxed);

    // one-shot events
    const float dt = 1.0f / kFs;
    for (int i = 0; i < kEvents; ++i) {
        const uint32_t c = counters_[i].load(std::memory_order_relaxed);
        if (c == seen_[i]) continue;
        seen_[i] = c;
        switch (static_cast<AudioEvent>(i)) {
            case AudioEvent::Tick: tickT_ = 0.0f; break;
            case AudioEvent::Go: goT_ = 0.0f; break;
            case AudioEvent::Crash: crashT_ = 0.0f; break;
            case AudioEvent::Scrape: scrapeEnv_ = 1.0f; break;
            case AudioEvent::NearMiss: missT_ = 0.0f; break;
            case AudioEvent::ConeHit: coneT_ = 0.0f; break;
            case AudioEvent::NewBest: bestT_ = 0.0f; break;
            default: break;
        }
    }

    const float smooth = 0.0016f;
    for (int n = 0; n < frames; ++n) {
        speedS_ += (speedT - speedS_) * smooth;
        slideS_ += (slideT - slideS_) * smooth * 2.0f;
        offroadS_ += (offT - offroadS_) * smooth;
        tuckS_ += (tuckT - tuckS_) * smooth;
        masterS_ += (masterT - masterS_) * 0.002f;
        const float sp = std::min(speedS_ / 38.0f, 1.3f);
        const float nz = noise();

        // wind: two-stage low-pass noise, brighter and louder with speed (tucking = more wind in the ears)
        const float aw = onePole(160.0f + 2400.0f * sp);
        wind1_ += (nz - wind1_) * aw;
        wind2_ += (wind1_ - wind2_) * aw;
        gustPhase_ += kTwoPi * 0.33f * dt;
        if (gustPhase_ > kTwoPi) gustPhase_ -= kTwoPi;
        const float gust = 0.86f + 0.14f * std::sin(gustPhase_);
        float mix = wind2_ * (0.02f + 3.4f * std::pow(sp, 1.6f)) * (1.0f + 0.3f * tuckS_) * gust * 0.50f;

        // wheel rumble on asphalt (low band) and gravel crunch off-road
        const float ar = onePole(150.0f);
        rum1_ += (nz - rum1_) * ar;
        rum2_ += (rum1_ - rum2_) * ar;
        mix += rum2_ * sp * (0.9f + 1.1f * offroadS_) * 0.75f;
        const float hp = nz - gravel_;
        gravel_ += (nz - gravel_) * onePole(1800.0f);
        mix += hp * offroadS_ * sp * 0.06f;

        // road seams: a soft thud every few metres of road
        distAcc_ += speedS_ * dt;
        if (distAcc_ >= 6.5f) {
            distAcc_ -= 6.5f;
            seamEnv_ = 1.0f;
            seamT_ = 0.0f;
        }
        if (seamEnv_ > 0.001f) {
            mix += sine(62.0f, seamT_) * seamEnv_ * 0.09f * std::min(1.0f, sp * 1.5f);
            seamEnv_ *= 0.99915f;
            seamT_ += dt;
        }

        // slide screech: band-passed noise (state variable filter)
        if (slideS_ > 0.002f) {
            const float f = 2.0f * std::sin(kPi * (1500.0f + 900.0f * sp) / kFs);
            const float high = nz - svfLow_ - 0.22f * svfBand_;
            svfBand_ += f * high;
            svfLow_ += f * svfBand_;
            mix += svfBand_ * slideS_ * (0.35f + 0.5f * sp) * 0.32f;
        }

        // rail scrape: crisp noise burst
        if (scrapeEnv_ > 0.001f) {
            scrapeLp_ += (nz - scrapeLp_) * onePole(2500.0f);
            mix += (nz - scrapeLp_) * scrapeEnv_ * 0.42f;
            scrapeEnv_ *= 0.9996f;
        }

        // events
        if (tickT_ >= 0.0f) {
            mix += sine(660.0f, tickT_) * std::exp(-tickT_ * 26.0f) * 0.55f;
            tickT_ += dt;
            if (tickT_ > 0.25f) tickT_ = -1.0f;
        }
        if (goT_ >= 0.0f) {
            mix += (sine(990.0f, goT_) + 0.5f * sine(1485.0f, goT_)) * std::exp(-goT_ * 7.0f) * 0.48f;
            goT_ += dt;
            if (goT_ > 0.7f) goT_ = -1.0f;
        }
        if (crashT_ >= 0.0f) {
            crashLp_ += (nz - crashLp_) * onePole(1100.0f * std::exp(-crashT_ * 2.5f) + 120.0f);
            mix += crashLp_ * std::exp(-crashT_ * 3.0f) * 1.7f + sine(52.0f, crashT_) * std::exp(-crashT_ * 4.5f) * 0.9f;
            crashT_ += dt;
            if (crashT_ > 1.6f) crashT_ = -1.0f;
        }
        if (missT_ >= 0.0f) {
            missLp_ += (nz - missLp_) * onePole(500.0f + 3500.0f * missT_ * 2.2f);
            const float bell = std::sin(kPi * std::min(missT_ / 0.5f, 1.0f));
            mix += missLp_ * bell * bell * 1.3f + sine(1760.0f, missT_) * std::exp(-missT_ * 14.0f) * 0.10f;
            missT_ += dt;
            if (missT_ > 0.5f) missT_ = -1.0f;
        }
        if (coneT_ >= 0.0f) {
            mix += sine(190.0f, coneT_) * std::exp(-coneT_ * 28.0f) * 0.85f + nz * std::exp(-coneT_ * 70.0f) * 0.5f;
            coneT_ += dt;
            if (coneT_ > 0.3f) coneT_ = -1.0f;
        }
        if (bestT_ >= 0.0f) {
            const float freqs[3] = {660.0f, 880.0f, 1320.0f};
            for (int k = 0; k < 3; ++k) {
                const float t = bestT_ - 0.12f * static_cast<float>(k);
                if (t >= 0.0f) mix += sine(freqs[k], t) * std::exp(-t * 9.0f) * 0.34f;
            }
            bestT_ += dt;
            if (bestT_ > 1.0f) bestT_ = -1.0f;
        }

        mix *= masterS_;
        mix = mix / (1.0f + std::fabs(mix));   // soft clip
        out[n] = static_cast<int16_t>(clampf(mix * 0.95f, -1.0f, 1.0f) * 32000.0f);
    }
}

}  // namespace sd
