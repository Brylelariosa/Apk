#include "ui_font.h"

#include <cctype>
#include <cstring>

namespace sd {
namespace {

// Glyphs live on a 4 x 6 grid (y up). Polylines are separated by ';', points by spaces, each point is "xy".
const char* glyphStrokes(char c) {
    switch (c) {
        case 'A': return "00 26 40;12 32";
        case 'B': return "00 06 36 45 44 33 03;33 42 41 30 00";
        case 'C': return "45 36 16 05 01 10 30 41";
        case 'D': return "00 06 36 45 41 30 00";
        case 'E': return "46 06 00 40;03 33";
        case 'F': return "46 06 00;03 33";
        case 'G': return "45 36 16 05 01 10 30 41 43 23";
        case 'H': return "00 06;40 46;03 43";
        case 'I': return "16 36;26 20;10 30";
        case 'J': return "46 41 30 10 01";
        case 'K': return "00 06;46 03 40";
        case 'L': return "06 00 40";
        case 'M': return "00 06 24 46 40";
        case 'N': return "00 06 40 46";
        case 'O': return "10 01 05 16 36 45 41 30 10";
        case 'P': return "00 06 36 45 44 33 03";
        case 'Q': return "10 01 05 16 36 45 41 30 10;22 40";
        case 'R': return "00 06 36 45 44 33 03;23 40";
        case 'S': return "45 36 16 05 04 13 33 42 41 30 10 01";
        case 'T': return "06 46;26 20";
        case 'U': return "06 01 10 30 41 46";
        case 'V': return "06 20 46";
        case 'W': return "06 10 23 30 46";
        case 'X': return "00 46;06 40";
        case 'Y': return "06 23 46;23 20";
        case 'Z': return "06 46 00 40";
        case '0': return "10 01 05 16 36 45 41 30 10";
        case '1': return "15 26 20;10 30";
        case '2': return "05 16 36 45 44 00 40";
        case '3': return "05 16 36 45 44 33 13;33 42 41 30 10 01";
        case '4': return "30 36 02 42";
        case '5': return "46 06 03 33 42 41 30 10 01";
        case '6': return "45 36 16 05 01 10 30 41 42 33 03";
        case '7': return "06 46 20";
        case '8': return "13 04 05 16 36 45 44 33 13;13 02 01 10 30 41 42 33";
        case '9': return "01 10 30 41 45 36 16 05 04 13 43";
        case '.': return "00 01";
        case ':': return "01 02;04 05";
        case '-': return "13 33";
        case '/': return "00 46";
        case '!': return "26 23;20 21";
        case '+': return "21 25;03 43";
        case '?': return "05 16 36 45 44 23 22;20 21";
        case '%': return "05 15 16 06 05;30 40 41 31 30;00 46";
        default: return nullptr;
    }
}

float advanceUnits(char c) {
    switch (c) {
        case '.': case ':': case '!': return 3.0f;
        case ' ': return 4.0f;
        default: return 6.0f;
    }
}

}  // namespace

float textWidth(const char* text, float size) {
    const float u = size / 6.0f;
    float w = 0.0f;
    for (const char* p = text; *p; ++p) w += advanceUnits(static_cast<char>(std::toupper(static_cast<unsigned char>(*p)))) * u;
    return w - 2.0f * u;  // no trailing letter spacing
}

float drawText(UiBatch& ui, const char* text, float x, float y, float size, Rgba8 color, TextAlign align) {
    const float u = size / 6.0f;
    const float th = u * 1.05f;
    const float width = textWidth(text, size);
    float cx = x;
    if (align == TextAlign::Center) cx = x - width * 0.5f;
    else if (align == TextAlign::Right) cx = x - width;
    cx += th * 0.5f;
    const float top = y + th * 0.5f;

    for (const char* p = text; *p; ++p) {
        const char ch = static_cast<char>(std::toupper(static_cast<unsigned char>(*p)));
        const char* g = glyphStrokes(ch);
        if (g) {
            Vec2 prev{0, 0};
            bool havePrev = false;
            for (const char* s = g; *s;) {
                if (*s == ';') { havePrev = false; ++s; continue; }
                if (*s == ' ') { ++s; continue; }
                const int gx = s[0] - '0', gy = s[1] - '0';
                s += 2;
                const Vec2 pt{cx + static_cast<float>(gx) * u, top + static_cast<float>(6 - gy) * u};
                // flat segments + a square patch on every vertex: fills corners without diagonal spurs
                if (havePrev) ui.line(prev, pt, th, color, false);
                ui.rect(pt.x - th * 0.5f, pt.y - th * 0.5f, th, th, color);
                prev = pt;
                havePrev = true;
            }
        }
        cx += advanceUnits(ch) * u;
    }
    return width;
}

}  // namespace sd
