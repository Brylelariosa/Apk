#include "mesh_library.h"

namespace sd {
namespace {

const Mat4 kId = Mat4::identity();

Mat4 at(float x, float y, float z) { return Mat4::translation(Vec3(x, y, z)); }

MeshData buildPine() {
    MeshData m;
    const Material trunk{0, 0, 0, 40};
    m.addFrustum(kId, 0.30f, 0.20f, 2.6f, 7, rgba(0.20f, 0.13f, 0.08f), rgba(0.16f, 0.10f, 0.06f), trunk, 0.0f);
    struct Tier { float y, r, h; };
    const Tier tiers[5] = {{1.5f, 2.15f, 3.4f}, {3.3f, 1.80f, 3.1f}, {5.0f, 1.45f, 2.8f}, {6.6f, 1.08f, 2.5f}, {8.1f, 0.68f, 2.1f}};
    const Material leaf{255, 0, 255, 255};
    for (int i = 0; i < 5; ++i) {
        const float k = static_cast<float>(i) / 4.0f;
        const Rgba8 lo = rgba(lerpf(0.05f, 0.09f, k), lerpf(0.15f, 0.22f, k), lerpf(0.08f, 0.10f, k));
        const Rgba8 hi = rgba(lerpf(0.13f, 0.20f, k), lerpf(0.30f, 0.40f, k), lerpf(0.11f, 0.13f, k));
        m.addFrustum(at(0.0f, tiers[i].y, 0.0f), tiers[i].r, 0.0f, tiers[i].h, 9, lo, hi, leaf, 0.55f);
    }
    return m;
}

MeshData buildAutumn() {
    MeshData m;
    m.addFrustum(kId, 0.32f, 0.18f, 3.6f, 7, rgba(0.24f, 0.15f, 0.09f), rgba(0.17f, 0.11f, 0.07f), Material{0, 0, 0, 30}, 0.0f);
    const Material leaf{255, 0, 255, 200};
    const Rgba8 lo = rgba(0.62f, 0.24f, 0.05f), hi = rgba(1.00f, 0.70f, 0.18f);
    m.addBlob(at(0.0f, 5.3f, 0.0f), Vec3(2.7f, 2.2f, 2.7f), 11u, 1, 0.14f, false, lo, hi, leaf);
    m.addBlob(at(1.2f, 6.5f, 0.6f), Vec3(1.8f, 1.5f, 1.8f), 23u, 1, 0.14f, false, lo, hi, leaf);
    m.addBlob(at(-1.1f, 6.9f, -0.5f), Vec3(1.6f, 1.4f, 1.6f), 37u, 1, 0.14f, false, lo, hi, leaf);
    return m;
}

MeshData buildRock() {
    MeshData m;
    m.addBlob(kId, Vec3(1.0f, 0.74f, 1.0f), 5u, 1, 0.30f, true, rgba(0.26f, 0.23f, 0.22f), rgba(0.52f, 0.47f, 0.43f),
              Material{255, 0, 0, 0}, 0.25f);
    return m;
}

MeshData buildPost() {
    MeshData m;
    m.addBox(at(0.0f, 0.5f, 0.0f), Vec3(0.045f, 0.5f, 0.045f), rgba(0.86f, 0.86f, 0.84f), Material{});
    m.addBox(at(0.0f, 0.78f, 0.0f), Vec3(0.05f, 0.07f, 0.05f), rgba(1.0f, 0.35f, 0.12f), Material{0, 190, 0, 0});
    return m;
}

MeshData buildRail() {
    MeshData m;
    const Rgba8 steel = rgba(0.62f, 0.64f, 0.68f);
    m.addBox(at(0.0f, 0.62f, 0.0f), Vec3(0.045f, 0.17f, 2.0f), steel, Material{});
    m.addBox(at(0.0f, 0.46f, 0.0f), Vec3(0.03f, 0.03f, 2.0f), steel, Material{});
    m.addBox(at(0.12f, 0.36f, -1.7f), Vec3(0.05f, 0.36f, 0.05f), rgba(0.40f, 0.30f, 0.20f), Material{});
    m.addBox(at(0.12f, 0.36f, 1.7f), Vec3(0.05f, 0.36f, 0.05f), rgba(0.40f, 0.30f, 0.20f), Material{});
    m.addBox(at(-0.05f, 0.62f, -1.0f), Vec3(0.012f, 0.05f, 0.05f), rgba(1.0f, 0.5f, 0.2f), Material{0, 150, 0, 0});
    return m;
}

MeshData buildCone() {
    MeshData m;
    const Material orange{255, 0, 0, 0};
    m.addBox(at(0.0f, 0.02f, 0.0f), Vec3(0.21f, 0.02f, 0.21f), rgba(0.95f, 0.30f, 0.05f), orange);
    m.addFrustum(at(0.0f, 0.04f, 0.0f), 0.17f, 0.135f, 0.20f, 10, rgba(1.0f, 0.36f, 0.06f), rgba(1.0f, 0.40f, 0.08f), orange, 0.1f);
    m.addFrustum(at(0.0f, 0.24f, 0.0f), 0.135f, 0.105f, 0.17f, 10, rgba(0.95f, 0.95f, 0.92f), rgba(0.95f, 0.95f, 0.92f), Material{}, 0.1f);
    m.addFrustum(at(0.0f, 0.41f, 0.0f), 0.105f, 0.035f, 0.29f, 10, rgba(1.0f, 0.36f, 0.06f), rgba(1.0f, 0.42f, 0.10f), orange, 0.1f);
    return m;
}

MeshData buildCar() {
    MeshData m;
    const Material paint{255, 0, 0, 0};
    const Rgba8 white = rgba(1.0f, 1.0f, 1.0f);
    const Rgba8 glass = rgba(0.07f, 0.09f, 0.13f);
    const Rgba8 dark = rgba(0.05f, 0.05f, 0.06f);
    m.addBox(at(0.0f, 0.55f, 0.0f), Vec3(0.88f, 0.27f, 2.15f), rgba(0.85f, 0.85f, 0.85f), white, paint);
    m.addBox(at(0.0f, 1.0f, 0.3f), Vec3(0.76f, 0.23f, 1.0f), glass, Material{});
    m.addBox(at(0.0f, 1.25f, 0.3f), Vec3(0.79f, 0.035f, 1.03f), white, paint);
    m.addBox(at(0.0f, 0.30f, -2.12f), Vec3(0.84f, 0.09f, 0.07f), dark, Material{});
    m.addBox(at(0.0f, 0.30f, 2.12f), Vec3(0.84f, 0.09f, 0.07f), dark, Material{});
    for (int sx = -1; sx <= 1; sx += 2) {
        for (int sz = -1; sz <= 1; sz += 2) {
            m.addBox(at(0.88f * static_cast<float>(sx), 0.30f, 1.35f * static_cast<float>(sz)), Vec3(0.12f, 0.30f, 0.30f), dark, Material{});
        }
        m.addBox(at(0.60f * static_cast<float>(sx), 0.64f, -2.17f), Vec3(0.17f, 0.08f, 0.03f), rgba(1.0f, 0.95f, 0.8f), Material{0, 255, 0, 0});
        m.addBox(at(0.62f * static_cast<float>(sx), 0.64f, 2.17f), Vec3(0.16f, 0.07f, 0.03f), rgba(1.0f, 0.1f, 0.05f), Material{0, 220, 0, 0});
    }
    return m;
}

}  // namespace

MeshData buildBatchMesh(Batch batch) {
    switch (batch) {
        case kBatchPine: return buildPine();
        case kBatchAutumn: return buildAutumn();
        case kBatchRock: return buildRock();
        case kBatchPost: return buildPost();
        case kBatchRail: return buildRail();
        case kBatchCone: return buildCone();
        case kBatchCar: return buildCar();
        default: break;
    }
    return MeshData();
}

}  // namespace sd
