// gl_util.h - thin OpenGL ES 3 helpers (shader programs, render targets).
#pragma once

#include <GLES3/gl3.h>

#include <string>
#include <unordered_map>

#include "math3d.h"

namespace sd {

class ShaderProgram {
public:
    bool build(const char* name, const char* vertexSrc, const char* fragmentSrc);
    // Forget the GL object without deleting it (the context that owned it is gone).
    void forget() { id_ = 0; cache_.clear(); }
    void destroy();

    bool valid() const { return id_ != 0; }
    void use() const { glUseProgram(id_); }
    GLint loc(const char* name);

    void set1f(const char* n, float v) { glUniform1f(loc(n), v); }
    void set2f(const char* n, float x, float y) { glUniform2f(loc(n), x, y); }
    void set3f(const char* n, float x, float y, float z) { glUniform3f(loc(n), x, y, z); }
    void set3f(const char* n, const Vec3& v) { glUniform3f(loc(n), v.x, v.y, v.z); }
    void set1i(const char* n, int v) { glUniform1i(loc(n), v); }
    void setMat4(const char* n, const Mat4& m) { glUniformMatrix4fv(loc(n), 1, GL_FALSE, m.m); }

private:
    GLuint id_ = 0;
    std::unordered_map<std::string, GLint> cache_;
};

// Colour texture + depth renderbuffer.
struct RenderTarget {
    GLuint fbo = 0, colorTex = 0, depthRb = 0;
    int width = 0, height = 0;
    bool valid() const { return fbo != 0; }
};

bool createColorTarget(RenderTarget& rt, int w, int h);
void destroyTarget(RenderTarget& rt);
void forgetTarget(RenderTarget& rt);

// Depth-only texture target used for the sun shadow map.
struct ShadowTarget {
    GLuint fbo = 0, depthTex = 0;
    int size = 0;
    bool valid() const { return fbo != 0; }
};
bool createShadowTarget(ShadowTarget& st, int size);
void destroyShadowTarget(ShadowTarget& st);
void forgetShadowTarget(ShadowTarget& st);

// Debug helper: logs and returns true when a GL error is pending.
bool glHasError(const char* where);

}  // namespace sd
