// engine.h - the single object the platform shell talks to.
// Owns the game simulation, input, HUD and renderer and runs one frame at a time.
#pragma once

#include <atomic>
#include <chrono>

#include "game.h"
#include "hud.h"
#include "input.h"
#include "renderer.h"
#include "scene_builder.h"
#include "ui_batch.h"
#include "ui_layout.h"

namespace sd {

class Engine {
public:
    Engine();

    // ---- configuration (before the first frame)
    void setSettings(int bestScore, bool soundOn);

    // ---- GL thread
    void onSurfaceCreated();
    void onSurfaceChanged(int width, int height);
    void onDrawFrame();                 // uses the wall clock
    void stepFrame(float dt);           // explicit time step (tests)
    void onTouch(int action, int pointerId, float x, float y);

    // ---- any thread
    void requestPause() { pauseRequested_.store(true); }
    bool requestBack();                 // true if the press was consumed by the game
    int bestScore() const { return best_.load(); }
    bool soundEnabled() const { return soundOn_.load(); }

    Game& game() { return game_; }
    Renderer& renderer() { return renderer_; }
    TouchController& touch() { return touch_; }

private:
    void applyAction(UiAction action);
    HudModel makeHudModel() const;
    void updateQuality(float dt);
    void updateAudio(const GameEvents& ev);

    Game game_;
    TouchController touch_;
    Renderer renderer_;
    SceneGeometry geo_;
    UiBatch ui_;
    UiLayout layout_;

    std::atomic<int> best_{0};
    std::atomic<bool> soundOn_{true};
    std::atomic<bool> pauseRequested_{false};
    std::atomic<bool> backRequested_{false};
    std::atomic<int> phase_{0};

    std::chrono::steady_clock::time_point last_;
    bool haveLast_ = false;
    int width_ = 0, height_ = 0;

    // adaptive quality
    float govTimer_ = 0.0f, govFrameTime_ = 0.0f;
    int govFrames_ = 0;
    float warmup_ = 4.0f, stableTime_ = 0.0f, raiseLockout_ = 0.0f, sinceRaise_ = 999.0f;
    bool noRaise_ = false;   // set when a quality increase immediately proved too heavy
};

}  // namespace sd
