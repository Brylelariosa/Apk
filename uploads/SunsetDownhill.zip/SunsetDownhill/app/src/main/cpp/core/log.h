// log.h - minimal logging that works on Android and on the desktop test host.
#pragma once

#ifdef __ANDROID__
#include <android/log.h>
#define SD_LOGI(...) __android_log_print(ANDROID_LOG_INFO, "SunsetDownhill", __VA_ARGS__)
#define SD_LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "SunsetDownhill", __VA_ARGS__)
#else
#include <cstdio>
#define SD_LOGI(...) do { std::fprintf(stderr, "[I] " __VA_ARGS__); std::fprintf(stderr, "\n"); } while (0)
#define SD_LOGE(...) do { std::fprintf(stderr, "[E] " __VA_ARGS__); std::fprintf(stderr, "\n"); } while (0)
#endif
