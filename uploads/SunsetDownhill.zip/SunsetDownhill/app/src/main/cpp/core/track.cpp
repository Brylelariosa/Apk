#include "track.h"

#include <algorithm>
#include <cmath>

namespace sd {

Track::Track(uint32_t seed) { reset(seed); }

void Track::reset(uint32_t seed) {
    seed_ = seed;
    rng_.reseed(seed * 2654435761U + 17U);
    samples_.clear();
    segments_.clear();
    planHeading_ = 0.0f;
    lastDir_ = 1.0f;
    for (float& p : phase_) p = rng_.range(0.0f, kTwoPi);

    TrackSample first;
    first.pitch = pitchAt(0.0f);
    buildFrame(first);
    samples_.push_back(first);

    segments_.push_back({0.0f, 120.0f, 0.0f});  // opening straight
    planEnd_ = 120.0f;
    lastWasStraight_ = true;
    ensureGenerated(64.0f);
}

void Track::ensureGenerated(float sMax) {
    while (generatedLength() < sMax) generateNext();
}

float Track::difficultyAt(float s) const { return saturate(s / cfg::kDifficultyDistance); }

float Track::pitchAt(float s) const {
    const float d = difficultyAt(s);
    const float base = lerpf(5.2f, 7.4f, d) * kDeg2Rad;
    float p = base + 2.4f * kDeg2Rad * std::sin(s / 210.0f + phase_[0]) +
              1.5f * kDeg2Rad * std::sin(s / 77.0f + phase_[1]);
    p = std::max(p, 2.2f * kDeg2Rad);
    return p * lerpf(0.6f, 1.0f, smoothstep(0.0f, 70.0f, s));  // already rolling at the start line
}

float Track::hillBias(float s) const {
    return clampf(0.85f * std::sin(s / 380.0f + phase_[2]) + 0.35f * std::sin(s / 113.0f + phase_[3]), -1.0f, 1.0f);
}

float Track::curvatureAt(float s) const {
    if (segments_.empty()) return 0.0f;
    auto it = std::upper_bound(segments_.begin(), segments_.end(), s,
                               [](float v, const Segment& seg) { return v < seg.s0; });
    if (it == segments_.begin()) return 0.0f;
    --it;
    if (it->k == 0.0f) return 0.0f;
    const float u = (s - it->s0) / it->len;
    if (u < 0.0f || u > 1.0f) return 0.0f;
    constexpr float r = 0.25f;  // clothoid-like ramps
    float e = 1.0f;
    if (u < r) e = smoothstep(0.0f, r, u);
    else if (u > 1.0f - r) e = smoothstep(1.0f, 1.0f - r, u);
    return it->k * e;
}

void Track::planUntil(float sTarget) {
    while (planEnd_ < sTarget) {
        const float diff = difficultyAt(planEnd_);
        if (!lastWasStraight_) {
            float len = lerpf(150.0f, 55.0f, diff) * rng_.range(0.55f, 1.4f);
            if (rng_.chance(0.25f)) len *= 0.35f;  // linked corners
            segments_.push_back({planEnd_, len, 0.0f});
            planEnd_ += len;
            lastWasStraight_ = true;
        } else {
            const float radius = std::max(cfg::kMinCurveRadius, lerpf(125.0f, 58.0f, diff) * rng_.range(0.8f, 1.3f));
            float angle = rng_.range(24.0f, 68.0f) * kDeg2Rad * lerpf(0.9f, 1.15f, diff);
            float dir;
            if (std::fabs(planHeading_) > 45.0f * kDeg2Rad) dir = -sign1(planHeading_);
            else dir = rng_.chance(0.72f) ? -lastDir_ : lastDir_;
            const float k = dir / radius;
            const float len = angle * radius / 0.75f;  // the smooth envelope averages 0.75
            segments_.push_back({planEnd_, len, k});
            planEnd_ += len;
            planHeading_ += dir * angle;
            lastDir_ = dir;
            lastWasStraight_ = false;
        }
    }
}

void Track::buildFrame(TrackSample& t) {
    const float ch = std::cos(t.heading), sh = std::sin(t.heading);
    const float cp = std::cos(t.pitch), sp = std::sin(t.pitch);
    t.fwd = Vec3(sh * cp, -sp, -ch * cp);
    t.right0 = Vec3(ch, 0.0f, sh);
    t.up0 = cross(t.right0, t.fwd);
    const float cb = std::cos(t.bank), sb = std::sin(t.bank);
    t.up = t.up0 * cb + t.right0 * sb;
    t.right = t.right0 * cb - t.up0 * sb;
}

void Track::generateNext() {
    const TrackSample cur = samples_.back();
    const float step = cfg::kTrackStep;
    const float sNext = cur.s + step;
    planUntil(sNext + 8.0f);
    const float sMid = cur.s + step * 0.5f;
    const float kMid = curvatureAt(sMid);
    const float headingMid = cur.heading + kMid * step * 0.5f;
    const float pitchMid = pitchAt(sMid);

    TrackSample n;
    n.s = sNext;
    n.heading = cur.heading + kMid * step;
    n.pitch = pitchAt(sNext);
    n.curvature = curvatureAt(sNext);
    n.bank = clampf(n.curvature * 46.0f, -0.10f, 0.10f);
    const Vec3 dir(std::sin(headingMid) * std::cos(pitchMid), -std::sin(pitchMid),
                   -std::cos(headingMid) * std::cos(pitchMid));
    n.pos = cur.pos + dir * step;
    buildFrame(n);
    samples_.push_back(n);
}

TrackSample Track::at(float s) const {
    const int n = static_cast<int>(samples_.size());
    float u = s / cfg::kTrackStep;
    int i = static_cast<int>(std::floor(u));
    float f = u - static_cast<float>(i);
    if (i < 0) { i = 0; f = 0.0f; }
    if (i >= n - 1) { i = n - 2; f = 1.0f; }
    const TrackSample& a = samples_[static_cast<size_t>(i)];
    const TrackSample& b = samples_[static_cast<size_t>(i) + 1];
    TrackSample r;
    r.s = lerpf(a.s, b.s, f);
    r.pos = lerp(a.pos, b.pos, f);
    r.fwd = normalize(lerp(a.fwd, b.fwd, f));
    r.right0 = normalize(lerp(a.right0, b.right0, f));
    r.up0 = normalize(lerp(a.up0, b.up0, f));
    r.right = normalize(lerp(a.right, b.right, f));
    r.up = normalize(lerp(a.up, b.up, f));
    r.heading = lerpf(a.heading, b.heading, f);
    r.pitch = lerpf(a.pitch, b.pitch, f);
    r.curvature = lerpf(a.curvature, b.curvature, f);
    r.bank = lerpf(a.bank, b.bank, f);
    return r;
}

float Track::bankDrop(float lateral, float bank) {
    return -clampf(lateral, -cfg::kShoulderOuter, cfg::kShoulderOuter) * bank;
}

float Track::insideLimit(float curvature) {
    const float k = std::fabs(curvature);
    return k > 1e-4f ? 0.82f / k : 1e6f;
}

float Track::terrainHeight(float s, float d) const {
    const float ad = std::fabs(d);
    if (ad <= cfg::kShoulderOuter) {
        return ad > cfg::kRoadHalfWidth ? -0.04f * (ad - cfg::kRoadHalfWidth) : 0.0f;
    }
    const float away = ad - cfg::kShoulderOuter;
    const float hill = hillBias(s) * (d >= 0.0f ? 1.0f : -1.0f);  // +1: this side is the uphill side
    const float slope = lerpf(-0.52f, 0.62f, hill * 0.5f + 0.5f);
    const float limit = slope > 0.0f ? 34.0f : 30.0f;
    float h = limit * std::tanh(away * slope / limit);
    const float n = fbm2(s * 0.018f + 11.0f, ad * 0.021f, seed_, 3) - 0.5f;
    const float amp = 2.0f * smoothstep(2.0f, 14.0f, away) + 11.0f * smoothstep(18.0f, 70.0f, away);
    h += n * 2.0f * amp;
    return h - 0.064f;
}

Vec3 Track::surfacePoint(const TrackSample& f, float lateral, float height) {
    return f.pos + f.right0 * lateral + f.up0 * (bankDrop(lateral, f.bank) + height);
}

Vec3 Track::ringVertex(int ring, int col) const {
    const TrackSample& f = samples_[static_cast<size_t>(ring)];
    const float dNom = cfg::kTerrainOffsets[col];
    float d = dNom;
    if ((d > 0.0f && f.curvature > 0.0f) || (d < 0.0f && f.curvature < 0.0f)) {
        const float lim = insideLimit(f.curvature);
        if (std::fabs(d) > lim) d = sign1(d) * lim;  // keep the inside of tight bends from folding over
    }
    const float h = terrainHeight(f.s, dNom);
    return f.pos + f.right0 * d + f.up0 * (bankDrop(d, f.bank) + h);
}

Vec3 Track::terrainPoint(float s, float d) const {
    const int n = static_cast<int>(samples_.size());
    const float u = s / cfg::kTrackStep;
    int i = static_cast<int>(std::floor(u));
    float fs = u - static_cast<float>(i);
    if (i < 0) { i = 0; fs = 0.0f; }
    if (i > n - 2) { i = n - 2; fs = 1.0f; }
    int j = 0;
    while (j < cfg::kTerrainCols - 2 && d > cfg::kTerrainOffsets[j + 1]) ++j;
    const float d0 = cfg::kTerrainOffsets[j], d1 = cfg::kTerrainOffsets[j + 1];
    const float fd = clampf((d - d0) / (d1 - d0), 0.0f, 1.0f);
    const Vec3 a = lerp(ringVertex(i, j), ringVertex(i, j + 1), fd);
    const Vec3 b = lerp(ringVertex(i + 1, j), ringVertex(i + 1, j + 1), fd);
    return lerp(a, b, fs);
}

}  // namespace sd
