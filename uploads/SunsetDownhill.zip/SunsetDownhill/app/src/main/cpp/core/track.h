// track.h - procedural mountain road: centre line, frames, curvature, terrain profile.
#pragma once

#include <cstdint>
#include <vector>

#include "config.h"
#include "math3d.h"
#include "rng.h"

namespace sd {

struct TrackSample {
    Vec3 pos;          // road centre line (road surface)
    Vec3 fwd;          // unit tangent, includes pitch
    Vec3 right0;       // horizontal right vector (unbanked)
    Vec3 up0;          // unbanked surface normal
    Vec3 right, up;    // banked frame
    float s = 0.0f;
    float heading = 0.0f;    // yaw, + turns right
    float pitch = 0.0f;      // + descends
    float curvature = 0.0f;  // 1/m, + right turn
    float bank = 0.0f;       // + lowers the right edge
};

class Track {
public:
    explicit Track(uint32_t seed = 1u);
    void reset(uint32_t seed);
    uint32_t seed() const { return seed_; }

    void ensureGenerated(float sMax);
    float generatedLength() const { return samples_.empty() ? 0.0f : samples_.back().s; }
    int sampleCount() const { return static_cast<int>(samples_.size()); }
    const TrackSample& sampleAt(int i) const { return samples_[static_cast<size_t>(i)]; }

    // Interpolated frame at distance s (clamped to the generated range).
    TrackSample at(float s) const;

    float curvatureAt(float s) const;
    float pitchAt(float s) const;
    float difficultyAt(float s) const;
    float hillBias(float s) const;   // -1..1, + means the right side is the uphill side

    static float bankDrop(float lateral, float bank);
    static float insideLimit(float curvature);

    // Height of the terrain above the road plane at lateral offset d.
    float terrainHeight(float s, float d) const;
    // World position of terrain-mesh vertex (ring, column).
    Vec3 ringVertex(int ring, int col) const;
    // World position on the terrain mesh at (s, d), consistent with the rendered mesh.
    Vec3 terrainPoint(float s, float d) const;
    // Point on the banked road surface at lateral offset, plus a height above it.
    static Vec3 surfacePoint(const TrackSample& f, float lateral, float height = 0.0f);

private:
    struct Segment {
        float s0, len, k;   // start, length, peak curvature (0 = straight)
    };

    void generateNext();
    void planUntil(float sTarget);
    static void buildFrame(TrackSample& t);

    uint32_t seed_ = 1u;
    Rng rng_;
    std::vector<TrackSample> samples_;
    std::vector<Segment> segments_;
    float planEnd_ = 0.0f;
    float planHeading_ = 0.0f;
    float lastDir_ = 1.0f;
    bool lastWasStraight_ = true;
    float phase_[6] = {0, 0, 0, 0, 0, 0};
};

}  // namespace sd
