// scene_types.h - plain data handed from the simulation side to the renderer.
#pragma once

#include <cstdint>
#include <vector>

#include "color.h"
#include "config.h"
#include "mesh_data.h"

namespace sd {

// Instanced scenery batches (each has one static mesh).
enum Batch : int {
    kBatchPine = 0,
    kBatchAutumn,
    kBatchRock,
    kBatchPost,
    kBatchRail,
    kBatchCone,
    kBatchCar,
    kBatchCount
};

struct Instance {          // 36 bytes, camera-relative position
    float x, y, z, yaw;    // yaw: heading (+ turns right)
    float sx, sy, phase, pitch;  // horizontal scale, vertical scale, wind phase, pitch (+ nose down)
    uint8_t r, g, b, a;    // tint rgb, a = extra lateral fog (0..255)
};
static_assert(sizeof(Instance) == 36, "Instance layout");

struct TerrainVertex {     // 36 bytes
    float px, py, pz;
    float nx, ny, nz;
    float d, s, edge;      // road-space lateral offset, distance along road, lateral fade (0..1)
};
static_assert(sizeof(TerrainVertex) == 36, "TerrainVertex layout");

struct ParticleInstance {  // 32 bytes
    float x, y, z, size;
    uint8_t r, g, b, a;
    float vx, vy, vz;      // non-zero velocity stretches the sprite (sparks)
};
static_assert(sizeof(ParticleInstance) == 32, "ParticleInstance layout");

struct SceneGeometry {
    std::vector<TerrainVertex> terrain;
    std::vector<Instance> instances[kBatchCount];
    MeshData dynamicMesh;                 // skater, start gate (camera-relative)
    std::vector<ParticleInstance> smoke;  // alpha-blended
    std::vector<ParticleInstance> sparks; // additive

    void clear() {
        for (auto& v : instances) v.clear();
        dynamicMesh.clear();
        smoke.clear();
        sparks.clear();
    }
};

}  // namespace sd
