// world.h - the road, obstacles/traffic and procedurally placed scenery.
#pragma once

#include <cstdint>
#include <unordered_map>
#include <vector>

#include "color.h"
#include "math3d.h"
#include "rng.h"
#include "scene_types.h"
#include "track.h"

namespace sd {

enum class ObstacleKind : uint8_t { Cone, Rock, Car };

struct Obstacle {
    ObstacleKind kind = ObstacleKind::Cone;
    float s = 0.0f, x = 0.0f;       // road space centre
    float hs = 0.3f, hx = 0.3f;     // collision half extents (along road, lateral)
    float yaw = 0.0f;               // visual yaw relative to the road tangent
    float scale = 1.0f;
    float vel = 0.0f;               // along-road velocity (cars); negative = oncoming
    Rgba8 tint;
    bool passed = false;            // near-miss already evaluated
    bool hit = false;               // cones: knocked away
    float hitTime = 0.0f;
    float knockDir = 1.0f;
    float minGap = 99.0f;           // smallest lateral clearance seen while overlapping in s
};

class World {
public:
    explicit World(uint32_t seed = 1u) { reset(seed); }
    void reset(uint32_t seed);

    void setObstaclesEnabled(bool on) { obstaclesEnabled_ = on; }
    // Extends the road, spawns / moves / culls obstacles around the player.
    void update(float dt, float playerS);

    Track& track() { return track_; }
    const Track& track() const { return track_; }
    std::vector<Obstacle>& obstacles() { return obstacles_; }
    const std::vector<Obstacle>& obstacles() const { return obstacles_; }

    // ---- render-side builders (positions are made camera relative with `origin`) ----
    void buildTerrain(float focusS, const Vec3& origin, SceneGeometry& out) const;
    void buildScenery(float focusS, const Vec3& origin, const Vec3& camFwd, float density, SceneGeometry& out);
    void buildObstacles(const Vec3& origin, SceneGeometry& out) const;
    void buildStartGate(float focusS, const Vec3& origin, SceneGeometry& out) const;

private:
    struct Placed {
        Instance inst;  // absolute position
        float rank;     // 0..1, drawn when rank <= density
    };
    struct Chunk {
        std::vector<Placed> items[kBatchCount];
    };

    void spawnUpTo(float sLimit);
    const Chunk& chunkAt(int index);
    void generateChunk(int index, Chunk& chunk);

    Track track_;
    Rng obstacleRng_;
    std::vector<Obstacle> obstacles_;
    float nextObstacleS_ = 0.0f;
    bool obstaclesEnabled_ = true;
    std::unordered_map<int, Chunk> chunks_;
    mutable std::vector<Vec3> scratch_;
};

}  // namespace sd
