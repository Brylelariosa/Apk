#include "scene_builder.h"

namespace sd {

FrameParams buildScene(Game& game, float treeDensity, SceneGeometry& geo) {
    geo.clear();
    const CameraView& cam = game.camera().view();
    const Vec3 origin = cam.pos;
    const Skater& sk = game.skater();
    World& world = game.world();

    world.buildTerrain(sk.s, origin, geo);
    world.buildScenery(sk.s, origin, cam.fwd, treeDensity, geo);
    world.buildObstacles(origin, geo);
    world.buildStartGate(sk.s, origin, geo);
    buildSkaterMesh(game.skaterPose(origin), geo.dynamicMesh);
    game.particles().build(origin, geo.smoke, geo.sparks);

    FrameParams fp;
    fp.cam = cam;
    fp.atmo = game.atmosphere();
    fp.time = game.time();
    fp.speed01 = game.speed01() * (game.phase() == Phase::Menu ? 0.75f : 1.0f);
    fp.slide = sk.slide;
    fp.flash = game.crashFlash();

    const TrackSample f = world.track().at(sk.s);
    fp.shadowFocus = Track::surfacePoint(f, sk.x) + f.fwd * 12.0f;
    return fp;
}

}  // namespace sd
