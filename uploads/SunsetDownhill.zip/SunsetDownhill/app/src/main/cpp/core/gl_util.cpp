#include "gl_util.h"

#include <vector>

#include "log.h"

namespace sd {

static GLuint compile(GLenum type, const char* src, const char* name) {
    const GLuint sh = glCreateShader(type);
    glShaderSource(sh, 1, &src, nullptr);
    glCompileShader(sh);
    GLint ok = 0;
    glGetShaderiv(sh, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        GLint len = 0;
        glGetShaderiv(sh, GL_INFO_LOG_LENGTH, &len);
        std::vector<char> log(static_cast<size_t>(len > 1 ? len : 1));
        glGetShaderInfoLog(sh, len, nullptr, log.data());
        SD_LOGE("shader compile failed (%s, %s): %s", name, type == GL_VERTEX_SHADER ? "vertex" : "fragment", log.data());
        glDeleteShader(sh);
        return 0;
    }
    return sh;
}

bool ShaderProgram::build(const char* name, const char* vertexSrc, const char* fragmentSrc) {
    destroy();
    const GLuint vs = compile(GL_VERTEX_SHADER, vertexSrc, name);
    const GLuint fs = compile(GL_FRAGMENT_SHADER, fragmentSrc, name);
    if (!vs || !fs) {
        if (vs) glDeleteShader(vs);
        if (fs) glDeleteShader(fs);
        return false;
    }
    const GLuint prog = glCreateProgram();
    glAttachShader(prog, vs);
    glAttachShader(prog, fs);
    glLinkProgram(prog);
    glDeleteShader(vs);
    glDeleteShader(fs);
    GLint ok = 0;
    glGetProgramiv(prog, GL_LINK_STATUS, &ok);
    if (!ok) {
        GLint len = 0;
        glGetProgramiv(prog, GL_INFO_LOG_LENGTH, &len);
        std::vector<char> log(static_cast<size_t>(len > 1 ? len : 1));
        glGetProgramInfoLog(prog, len, nullptr, log.data());
        SD_LOGE("program link failed (%s): %s", name, log.data());
        glDeleteProgram(prog);
        return false;
    }
    id_ = prog;
    return true;
}

void ShaderProgram::destroy() {
    if (id_) glDeleteProgram(id_);
    forget();
}

GLint ShaderProgram::loc(const char* name) {
    auto it = cache_.find(name);
    if (it != cache_.end()) return it->second;
    const GLint l = glGetUniformLocation(id_, name);
    cache_.emplace(name, l);
    return l;
}

bool createColorTarget(RenderTarget& rt, int w, int h) {
    destroyTarget(rt);
    rt.width = w;
    rt.height = h;
    glGenTextures(1, &rt.colorTex);
    glBindTexture(GL_TEXTURE_2D, rt.colorTex);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

    glGenRenderbuffers(1, &rt.depthRb);
    glBindRenderbuffer(GL_RENDERBUFFER, rt.depthRb);
    glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH_COMPONENT24, w, h);

    glGenFramebuffers(1, &rt.fbo);
    glBindFramebuffer(GL_FRAMEBUFFER, rt.fbo);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, rt.colorTex, 0);
    glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_RENDERBUFFER, rt.depthRb);
    const GLenum status = glCheckFramebufferStatus(GL_FRAMEBUFFER);
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    if (status != GL_FRAMEBUFFER_COMPLETE) {
        SD_LOGE("scene framebuffer incomplete (0x%x) at %dx%d", status, w, h);
        destroyTarget(rt);
        return false;
    }
    return true;
}

void destroyTarget(RenderTarget& rt) {
    if (rt.fbo) glDeleteFramebuffers(1, &rt.fbo);
    if (rt.colorTex) glDeleteTextures(1, &rt.colorTex);
    if (rt.depthRb) glDeleteRenderbuffers(1, &rt.depthRb);
    forgetTarget(rt);
}

void forgetTarget(RenderTarget& rt) {
    rt = RenderTarget();
}

bool createShadowTarget(ShadowTarget& st, int size) {
    destroyShadowTarget(st);
    st.size = size;
    glGenTextures(1, &st.depthTex);
    glBindTexture(GL_TEXTURE_2D, st.depthTex);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT24, size, size, 0, GL_DEPTH_COMPONENT, GL_UNSIGNED_INT, nullptr);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_MODE, GL_COMPARE_REF_TO_TEXTURE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_FUNC, GL_LEQUAL);

    glGenFramebuffers(1, &st.fbo);
    glBindFramebuffer(GL_FRAMEBUFFER, st.fbo);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D, st.depthTex, 0);
    const GLenum none = GL_NONE;
    glDrawBuffers(1, &none);
    glReadBuffer(GL_NONE);
    const GLenum status = glCheckFramebufferStatus(GL_FRAMEBUFFER);
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    if (status != GL_FRAMEBUFFER_COMPLETE) {
        SD_LOGE("shadow framebuffer incomplete (0x%x)", status);
        destroyShadowTarget(st);
        return false;
    }
    return true;
}

void destroyShadowTarget(ShadowTarget& st) {
    if (st.fbo) glDeleteFramebuffers(1, &st.fbo);
    if (st.depthTex) glDeleteTextures(1, &st.depthTex);
    forgetShadowTarget(st);
}

void forgetShadowTarget(ShadowTarget& st) {
    st = ShadowTarget();
}

bool glHasError(const char* where) {
    bool any = false;
    for (GLenum e = glGetError(); e != GL_NO_ERROR; e = glGetError()) {
        SD_LOGE("GL error 0x%x at %s", e, where);
        any = true;
    }
    return any;
}

}  // namespace sd
