// jni_bridge.cpp - thin JNI layer between the Kotlin shell and the native engine.
#include <jni.h>

#include <memory>
#include <vector>

#include "core/audio_synth.h"
#include "core/engine.h"

namespace {

std::shared_ptr<sd::Engine> g_engine;

std::shared_ptr<sd::Engine> engine() { return std::atomic_load(&g_engine); }

}  // namespace

#define JNI_FN(name) Java_com_sunsetdownhill_game_NativeBridge_##name

extern "C" {

JNIEXPORT void JNICALL JNI_FN(create)(JNIEnv*, jclass, jint best, jboolean soundOn) {
    auto e = std::make_shared<sd::Engine>();
    e->setSettings(static_cast<int>(best), soundOn == JNI_TRUE);
    std::atomic_store(&g_engine, e);
}

JNIEXPORT void JNICALL JNI_FN(surfaceCreated)(JNIEnv*, jclass) {
    if (auto e = engine()) e->onSurfaceCreated();
}

JNIEXPORT void JNICALL JNI_FN(surfaceChanged)(JNIEnv*, jclass, jint width, jint height) {
    if (auto e = engine()) e->onSurfaceChanged(static_cast<int>(width), static_cast<int>(height));
}

JNIEXPORT void JNICALL JNI_FN(drawFrame)(JNIEnv*, jclass) {
    if (auto e = engine()) e->onDrawFrame();
}

JNIEXPORT void JNICALL JNI_FN(touch)(JNIEnv*, jclass, jint action, jint id, jfloat x, jfloat y) {
    if (auto e = engine()) e->onTouch(static_cast<int>(action), static_cast<int>(id), x, y);
}

JNIEXPORT void JNICALL JNI_FN(pause)(JNIEnv*, jclass) {
    if (auto e = engine()) e->requestPause();
}

JNIEXPORT jboolean JNICALL JNI_FN(back)(JNIEnv*, jclass) {
    auto e = engine();
    return (e && e->requestBack()) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jint JNICALL JNI_FN(bestScore)(JNIEnv*, jclass) {
    auto e = engine();
    return e ? static_cast<jint>(e->bestScore()) : 0;
}

JNIEXPORT jboolean JNICALL JNI_FN(soundEnabled)(JNIEnv*, jclass) {
    auto e = engine();
    return (!e || e->soundEnabled()) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL JNI_FN(fillAudio)(JNIEnv* env, jclass, jshortArray buffer, jint frames) {
    static thread_local std::vector<int16_t> scratch;
    const int n = static_cast<int>(frames);
    if (n <= 0) return;
    scratch.resize(static_cast<size_t>(n));
    sd::audioSynth().render(scratch.data(), n);
    env->SetShortArrayRegion(buffer, 0, n, reinterpret_cast<const jshort*>(scratch.data()));
}

}  // extern "C"
