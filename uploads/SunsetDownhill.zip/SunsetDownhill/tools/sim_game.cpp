// sim_game: the autopilot plays complete runs through Game::update (cones, rocks, traffic) to check difficulty.
// Build: see tools/README.md
#include <cstdio>
#include "game.h"
using namespace sd;

int main() {
    printf("=== autopilot plays real runs (obstacles + traffic on)\n");
    int crashes = 0; float totalDist = 0;
    for (uint32_t seed = 1; seed <= 12; ++seed) {
        Game g; g.setBaseSeed(seed * 1000 + 17); g.startRun();
        AutoPilot ap; g.autopilot() = ap;
        const float dt = 1.0f / 60.0f; float t = 0;
        int cones = 0, near = 0; bool crashed = false;
        while (t < 300.0f) {
            SkaterInput in;
            if (g.phase() == Phase::Running) in = g.autopilot().compute(g.world().track(), g.world().obstacles(), g.skater());
            g.update(dt, in);
            GameEvents e = g.takeEvents();
            if (e.coneHit) ++cones; if (e.nearMiss) ++near; if (e.crash) crashed = true;
            if (g.phase() == Phase::GameOver) break;
            t += dt;
        }
        const Skater& s = g.skater();
        printf("seed %2u: t=%5.1f s=%6.0f m  top=%5.1f km/h  score=%5d  cones=%2d near=%2d  crashed=%d cause=%d kind=%d\n", seed, t, s.distance, s.topSpeed*3.6f, g.score(), cones, near, crashed, (int)s.crashCause, g.crashObstacleKind());
        crashes += crashed; totalDist += s.distance;
    }
    printf("crashed %d / 12, mean distance %.0f m\n", crashes, totalDist / 12);
    return 0;
}
