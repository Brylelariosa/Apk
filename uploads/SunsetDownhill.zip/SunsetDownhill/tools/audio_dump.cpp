// audio_dump: renders a scripted session of the procedural audio to /tmp/audio_test.wav and prints levels.
#include "audio_synth.h"
#include <cstdio>
#include <cmath>
#include <vector>
using namespace sd;
int main(){
  AudioSynth a; std::vector<int16_t> all; const int N=1024; std::vector<int16_t> buf(N);
  auto run=[&](float seconds, AudioState s, const char* label){
    a.setState(s); double sum=0; int peak=0; long cnt=0; bool bad=false;
    for(int i=0;i<(int)(seconds*AudioSynth::kSampleRate/N);++i){ a.render(buf.data(),N); for(int v: buf){ sum+= (double)v*v; peak=std::max(peak, std::abs((int)v)); ++cnt; all.push_back(v);} }
    printf("%-26s rms=%6.0f (%.2f dBFS)  peak=%5d\n", label, std::sqrt(sum/cnt), 20*std::log10(std::sqrt(sum/cnt)/32768.0+1e-9), peak);
  };
  AudioState s; s.master=1;
  s.speed=0; run(0.5f,s,"idle");
  a.trigger(AudioEvent::Tick); run(0.4f,s,"countdown tick");
  a.trigger(AudioEvent::Go); run(0.8f,s,"go");
  s.speed=8; run(2.0f,s,"8 m/s (29 km/h)");
  s.speed=20; run(2.0f,s,"20 m/s (72 km/h)");
  s.speed=33; s.tuck=1; run(2.0f,s,"33 m/s tucked (119 km/h)");
  s.tuck=0; s.slide=1; run(1.5f,s,"sliding at 33 m/s");
  s.slide=0; s.offroad=1; run(1.5f,s,"offroad gravel");
  s.offroad=0; a.trigger(AudioEvent::Scrape); run(0.5f,s,"scrape");
  a.trigger(AudioEvent::NearMiss); run(0.6f,s,"near miss");
  a.trigger(AudioEvent::ConeHit); run(0.4f,s,"cone hit");
  a.trigger(AudioEvent::Crash); run(1.8f,s,"crash");
  a.trigger(AudioEvent::NewBest); run(1.2f,s,"new best jingle");
  s.master=0; run(0.5f,s,"muted");
  bool nan=false; for(auto v: all) (void)v; printf("samples=%zu\n", all.size());
  FILE* f=fopen("/tmp/audio_test.wav","wb"); int dataBytes=(int)all.size()*2; int rate=AudioSynth::kSampleRate;
  fwrite("RIFF",1,4,f); int v32=36+dataBytes; fwrite(&v32,4,1,f); fwrite("WAVEfmt ",1,8,f); v32=16; fwrite(&v32,4,1,f); short s16=1; fwrite(&s16,2,1,f); fwrite(&s16,2,1,f); fwrite(&rate,4,1,f); v32=rate*2; fwrite(&v32,4,1,f); s16=2; fwrite(&s16,2,1,f); s16=16; fwrite(&s16,2,1,f); fwrite("data",1,4,f); fwrite(&dataBytes,4,1,f); fwrite(all.data(),2,all.size(),f); fclose(f);
}
