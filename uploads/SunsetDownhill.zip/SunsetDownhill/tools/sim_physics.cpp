// sim_physics: headless balance check of the skater physics (no GPU needed).
// Runs the autopilot and a "no input" rider over several seeds and prints speeds / crash times.
// Build: see tools/README.md
#include <cstdio>
#include <cstdlib>
#include "autopilot.h"
#include "skater.h"
#include "world.h"
using namespace sd;

struct Result { float t, s, topKmh, avgKmh; bool crashed; float slideTime; };

static Result run(uint32_t seed, bool pilot, float maxT, bool verbose, bool tuckAlways=false, float steerBias=0.f) {
    World w(seed); w.setObstaclesEnabled(false);
    Skater sk; sk.reset(6.0f, 0.0f); sk.startPush();
    AutoPilot ap;
    const float dt = 1.0f / 120.0f;
    float t = 0, slideT = 0, sumV = 0; int n = 0;
    Result r{};
    while (t < maxT) {
        w.update(dt, sk.s);
        SkaterInput in;
        if (pilot) in = ap.compute(w.track(), w.obstacles(), sk);
        else { in.tuck = tuckAlways; in.steer = steerBias; }
        SkaterEvent ev = sk.step(in, w.track(), dt);
        if (sk.slide > 0.5f) slideT += dt;
        sumV += sk.speed; ++n;
        if (verbose && (n % 240) == 0)
            printf("t=%5.1f s=%6.0f v=%5.1f km/h x=%5.2f a=%5.2f tuck=%.2f slide=%.2f curv=%+.4f pitch=%.1f\n", t, sk.s, sk.speed*3.6f, sk.x, sk.alpha, sk.tuck, sk.slide, w.track().curvatureAt(sk.s), w.track().pitchAt(sk.s)/kDeg2Rad);
        if (ev == SkaterEvent::Crash) { r.crashed = true; break; }
        t += dt;
    }
    r.t = t; r.s = sk.s; r.topKmh = sk.topSpeed * 3.6f; r.avgKmh = sumV / n * 3.6f; r.slideTime = slideT;
    return r;
}

int main(int argc, char** argv) {
    printf("=== autopilot, verbose, seed 7 (60 s)\n");
    run(7, true, 60.f, true);
    printf("\n=== autopilot, 8 seeds, up to 240 s\n");
    for (uint32_t seed = 1; seed <= 8; ++seed) {
        Result r = run(seed, true, 240.f, false);
        printf("seed %u: t=%6.1f dist=%6.0f m top=%5.1f avg=%5.1f km/h slide=%4.1f s crashed=%d\n", seed, r.t, r.s, r.topKmh, r.avgKmh, r.slideTime, r.crashed);
    }
    printf("\n=== no input at all (does the rider drift off / crash?)\n");
    for (uint32_t seed = 1; seed <= 4; ++seed) {
        Result r = run(seed, false, 120.f, false);
        printf("seed %u: t=%6.1f dist=%6.0f m top=%5.1f km/h crashed=%d\n", seed, r.t, r.s, r.topKmh, r.crashed);
    }
    printf("\n=== tuck held, no steering\n");
    for (uint32_t seed = 1; seed <= 4; ++seed) {
        Result r = run(seed, false, 120.f, false, true);
        printf("seed %u: t=%6.1f dist=%6.0f m top=%5.1f km/h crashed=%d\n", seed, r.t, r.s, r.topKmh, r.crashed);
    }
    return 0;
}
