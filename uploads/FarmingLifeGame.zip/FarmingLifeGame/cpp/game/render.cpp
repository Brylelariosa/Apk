// World rendering: terrain with seasonal tiles/fringes, y-sorted objects and entities, shadows, weather, lighting.
#include <algorithm>
#include "animation/animation.h"
#include "game/game.h"

namespace cf {
namespace {
struct Art {
  const Region *grass[4][4], *dirt[4][2], *path[4][2], *sand[4][2], *water[4][2], *deep[4][2], *cliff[2], *cliffface[2], *caveface[2], *wood[2], *stone[2], *bridge[2], *wall[2], *cavewall[2], *cave[4];
  const Region *soil[16], *soilw[16], *fringe[4][8], *shore[4][4], *fence[16], *shadow, *spikesOff, *treasureOpen;
  bool ready = false;
  void init() {
    if (ready) return; ready = true;
    auto g = [](const std::string& n) { return &Sprites::get(n); };
    static const char* e8[8] = {"n", "e", "s", "w", "ne", "se", "sw", "nw"};
    for (int s = 0; s < 4; ++s) {
      for (int v = 0; v < 4; ++v) grass[s][v] = g(fmt("t_grass_%s_%d", kSeasonNames[s], v));
      for (int v = 0; v < 2; ++v) { dirt[s][v] = g(fmt("t_dirt_%s_%d", kSeasonNames[s], v)); path[s][v] = g(fmt("t_path_%s_%d", kSeasonNames[s], v)); sand[s][v] = g(fmt("t_sand_%s_%d", kSeasonNames[s], v)); }
      for (int e = 0; e < 8; ++e) fringe[s][e] = g(fmt("fr_grass_%s_%s", kSeasonNames[s], e8[e]));
    }
    for (int f = 0; f < 4; ++f) for (int v = 0; v < 2; ++v) { water[f][v] = g(fmt("t_water_%d_%d", f, v)); deep[f][v] = g(fmt("t_deep_%d_%d", f, v)); }
    for (int v = 0; v < 2; ++v) { cliff[v] = g(fmt("t_cliff_%d", v)); cliffface[v] = g(fmt("t_cliffface_%d", v)); caveface[v] = g(fmt("t_cavewallface_%d", v)); wood[v] = g(fmt("t_wood_%d", v));
                                  stone[v] = g(fmt("t_stone_%d", v)); bridge[v] = g(fmt("t_bridge_%d", v)); wall[v] = g(fmt("t_wall_%d", v)); cavewall[v] = g(fmt("t_cavewall_%d", v)); }
    for (int v = 0; v < 4; ++v) cave[v] = g(fmt("t_cave_%d", v));
    for (int m = 0; m < 16; ++m) { soil[m] = g(fmt("soil_%d", m)); soilw[m] = g(fmt("soilw_%d", m)); fence[m] = g(fmt("o_fence_%d", m)); }
    static const char* e4[4] = {"n", "e", "s", "w"};
    for (int e = 0; e < 4; ++e) for (int f = 0; f < 4; ++f) shore[e][f] = g(fmt("shore_%s_%d", e4[e], f));
    shadow = g("fx_shadow"); spikesOff = g("o_spikes_off"); treasureOpen = g("o_treasure_open");
  }
};
Art art;

struct RItem { float sortY; const Region* spr; float x, y; bool flip; u32 color; int shadow; float shadowScale; int sway; };
std::vector<RItem> g_items;

bool isGrassN(const Map& m, int x, int y) { return m.terrain(x, y) == Terrain::Grass; }
u32 g_ambient = kWhite;
}  // namespace

void Game::drawTitleBackdrop() {
  art.init();
  r->beginWorld();
  SpriteBatch& b = r->batch; int vw = r->logicalW, vh = r->logicalH;
  float t = timeSec;
  int ox = (int)(std::sin(t * 0.07f) * 24.f) + 24;
  for (int y = 0; y < vh / kTile + 2; ++y) for (int x = 0; x < vw / kTile + 4; ++x) {
    int wx = x + ox / kTile; int v = (int)(Rng::hash((u32)wx, (u32)y, 3) & 3);
    bool horizon = y * kTile < vh * 0.42f;
    if (horizon) b.region(*art.grass[0][v], (float)(x * kTile - ox % kTile), (float)(y * kTile), kWhite);
    else b.region(*art.grass[0][v], (float)(x * kTile - ox % kTile), (float)(y * kTile), kWhite);
  }
  // sky gradient band, sun and drifting clouds
  for (int y = 0; y < (int)(vh * 0.42f); ++y) b.rect(0, (float)y, (float)vw, 1, col::lerp(col::rgba(255, 224, 170), col::rgba(138, 206, 240), 1.f - (float)y / (vh * 0.42f)));
  const Region& cloud = Sprites::ui.get("fx_fog");
  for (int i = 0; i < 5; ++i) { float cx = std::fmod(t * (4.f + i) + i * 90.f, (float)vw + 120.f) - 60.f; b.region(cloud, cx, 14.f + i * 11.f, col::rgba(255, 255, 255, 190), false, 2.2f + (float)(i % 2), 1.6f); }
  float baseY = vh * 0.42f;
  for (int i = 0; i < 14; ++i) { float x = (float)((i * 37) % (vw + 40)) - 20.f; b.region(Sprites::world.get(i % 3 ? "o_tree_pine_spring" : "o_tree_oak_spring"), x, baseY + 6.f + (float)((i * 13) % 8), kWhite); }
  float fx0 = vw * 0.5f - 40.f;
  b.region(Sprites::world.get("fx_shadow"), fx0 + 40.f, baseY + 74.f, col::withAlpha(kWhite, 0.8f), false, 6.f, 2.f);
  b.region(Sprites::world.get("b_farmhouse_2"), fx0, baseY + 74.f, kWhite);
  for (int i = 0; i < 6; ++i) { b.region(Sprites::world.get("o_fence_10"), fx0 - 20.f + (float)i * 16.f, baseY + 92.f); }
  for (int i = 0; i < 8; ++i) { b.region(Sprites::world.get(fmt("crop_%s_%d", i % 2 ? "turnip" : "cabbage", 2 + (i / 2) % 4)), fx0 + 100.f + (float)(i % 4) * 16.f, baseY + 100.f + (float)(i / 4) * 16.f); }
  b.region(Sprites::world.get("o_scarecrow"), fx0 + 120.f, baseY + 98.f);
  r->drawLighting(col::rgba(255, 244, 230), std::vector<Light>(), false, false);
  r->endWorld();
}

void Game::renderWorld() {
  art.init();
  Map& m = map(); SpriteBatch& b = r->batch;
  float vw = viewSize().x, vh = viewSize().y;
  Vec2 tl = cam.topLeft(vw, vh, (float)m.w * kTile, (float)m.h * kTile);
  r->setCameraOrigin(tl.x, tl.y);
  r->beginWorld();
  int season = s.cal.season;
  int x0 = std::max(0, (int)std::floor(tl.x / kTile)), y0 = std::max(0, (int)std::floor(tl.y / kTile));
  int x1 = std::min(m.w - 1, (int)std::floor((tl.x + vw) / kTile)), y1 = std::min(m.h - 1, (int)std::floor((tl.y + vh) / kTile));
  int wf = settings.waterFx ? ((int)(timeSec * 2.4f)) & 3 : 0;
  auto sx = [&](int tx) { return (float)(tx * kTile) - tl.x; };
  auto sy = [&](int ty) { return (float)(ty * kTile) - tl.y; };
  // ---------------------------------------------------------------- terrain
  for (int y = y0; y <= y1; ++y) for (int x = x0; x <= x1; ++x) {
    const Tile& t = m.at(x, y); int v = t.variant; float px = sx(x), py = sy(y);
    const Region* base = nullptr;
    switch (t.terrain) {
      case Terrain::Grass: base = art.grass[season][v]; break;
      case Terrain::Dirt: base = art.dirt[season][v & 1]; break;
      case Terrain::Path: base = art.path[season][v & 1]; break;
      case Terrain::Sand: base = art.sand[season][v & 1]; break;
      case Terrain::Water: base = art.water[wf][((x + y) & 1)]; break;
      case Terrain::Deep: base = art.deep[wf][((x * 3 + y) & 1)]; break;
      case Terrain::Cliff: base = m.terrain(x, y + 1) == Terrain::Cliff ? art.cliff[v & 1] : art.cliffface[v & 1]; break;
      case Terrain::CaveWall: base = m.terrain(x, y + 1) == Terrain::CaveWall ? art.cavewall[v & 1] : art.caveface[v & 1]; break;
      case Terrain::FloorWood: base = art.wood[v & 1]; break;
      case Terrain::FloorStone: base = art.stone[v & 1]; break;
      case Terrain::Cave: base = art.cave[v]; break;
      case Terrain::Bridge: base = art.bridge[v & 1]; break;
      case Terrain::Wall: base = m.terrain(x, y - 1) == Terrain::Wall ? art.wall[1] : art.wall[0]; break;
      default: break;
    }
    if (!base) continue;
    b.region(*base, px, py, kWhite);
    if (t.terrain == Terrain::Dirt || t.terrain == Terrain::Path || t.terrain == Terrain::Sand) {
      bool n = isGrassN(m, x, y - 1), e = isGrassN(m, x + 1, y), so = isGrassN(m, x, y + 1), w = isGrassN(m, x - 1, y);
      if (n) b.region(*art.fringe[season][0], px, py); if (e) b.region(*art.fringe[season][1], px, py);
      if (so) b.region(*art.fringe[season][2], px, py); if (w) b.region(*art.fringe[season][3], px, py);
      if (!n && !e && isGrassN(m, x + 1, y - 1)) b.region(*art.fringe[season][4], px, py);
      if (!so && !e && isGrassN(m, x + 1, y + 1)) b.region(*art.fringe[season][5], px, py);
      if (!so && !w && isGrassN(m, x - 1, y + 1)) b.region(*art.fringe[season][6], px, py);
      if (!n && !w && isGrassN(m, x - 1, y - 1)) b.region(*art.fringe[season][7], px, py);
    }
    if (terrainWater(t.terrain)) {
      auto land = [&](int ax, int ay) { Terrain o = m.terrain(ax, ay); return o != Terrain::Void && !terrainWater(o) && o != Terrain::Bridge; };
      int sf = settings.waterFx ? ((int)(timeSec * 3.f) & 3) : 0;
      if (land(x, y - 1)) b.region(*art.shore[0][sf], px, py); if (land(x + 1, y)) b.region(*art.shore[1][sf], px, py);
      if (land(x, y + 1)) b.region(*art.shore[2][sf], px, py); if (land(x - 1, y)) b.region(*art.shore[3][sf], px, py);
    }
    if (t.flags & TF_Tilled) {
      auto tilled = [&](int ax, int ay) { return m.inBounds(ax, ay) && (m.at(ax, ay).flags & TF_Tilled); };
      int mask = (tilled(x, y - 1) ? 1 : 0) | (tilled(x + 1, y) ? 2 : 0) | (tilled(x, y + 1) ? 4 : 0) | (tilled(x - 1, y) ? 8 : 0);
      b.region((t.flags & TF_Watered) ? *art.soilw[mask] : *art.soil[mask], px, py);
    }
  }
  // ---------------------------------------------------------------- collect sortable things
  g_items.clear(); lights.clear();
  bool night = s.cal.daylight() < 0.5f || m.dark;
  float wind = (s.wx.today == Weather::Wind || s.wx.today == Weather::Storm) ? 1.6f : 0.7f;
  int ox0 = std::max(0, x0 - 4), oy0 = std::max(0, y0 - 2), ox1 = std::min(m.w - 1, x1 + 4), oy1 = std::min(m.h - 1, y1 + 5);
  static std::vector<int> decals, tops; decals.clear(); tops.clear();
  for (int y = oy0; y <= oy1; ++y) for (int x = ox0; x <= ox1; ++x) {
    int oi = m.objectAt(x, y); if (oi < 0) continue;
    const MapObject& o = m.objs[(size_t)oi]; if (o.x != x || o.y != y) continue;
    if (o.kind == ObjKind::Ladder || o.kind == ObjKind::Hole || o.kind == ObjKind::Hazard || o.kind == ObjKind::Floor || o.kind == ObjKind::DecoWater) { decals.push_back(oi); continue; }
    if (o.kind == ObjKind::DecoTop) { tops.push_back(oi); continue; }
    const Region* sp = nullptr; float ax = (float)(o.x * kTile), ay = (float)((o.y + 1) * kTile); int shadow = 0; float shScale = 1.f; int sway = 0;
    if (o.kind == ObjKind::Crop) { const CropDef& c = C().crops[o.def]; sp = o.state == 9 ? c.dead : c.stage[std::min<int>(o.state, 5)]; ax += 8; }
    else if (o.kind == ObjKind::Forage) { sp = C().forageSpr[std::min<size_t>(o.aux, C().forageSpr.size() - 1)]; ax += 8; }
    else {
      const ObjDef& d = C().objs[o.def];
      sp = d.spr[d.seasonal ? season : 0]; ax += d.fw * 8.f; shadow = d.shadow; shScale = d.fw >= 2 ? 2.2f : (d.shadow == 2 ? 1.9f : 1.2f);
      if (o.kind == ObjKind::Fence) {
        auto fe = [&](int ax_, int ay_) { int k = m.objectAt(ax_, ay_); return k >= 0 && m.objs[(size_t)k].kind == ObjKind::Fence; };
        int mask = (fe(o.x, o.y - 1) ? 1 : 0) | (fe(o.x + 1, o.y) ? 2 : 0) | (fe(o.x, o.y + 1) ? 4 : 0) | (fe(o.x - 1, o.y) ? 8 : 0); sp = art.fence[mask];
      } else if (o.kind == ObjKind::Treasure && o.state) sp = art.treasureOpen;
      else if (o.kind == ObjKind::Tree && settings.treeSway) sway = (int)std::lround(std::sin(timeSec * 1.4f + o.x * 0.9f) * wind * 0.7f);
      if (d.lightR > 0 && (night || m.dark) && !(o.kind == ObjKind::Machine && o.state != 1)) lights.push_back({ax, ay - 8.f, d.lightR, d.lightCol});
      if (o.kind == ObjKind::Lantern && flag("lantern_restored")) lights.push_back({ax, ay - 20.f, 120.f, col::rgba(255, 214, 150)});
    }
    if (!sp) continue;
    g_items.push_back({ay - 0.01f, sp, ax - tl.x, ay - tl.y, false, kWhite, shadow, shScale, sway});
  }
  // buildings
  for (auto& bi : m.buildings) {
    const BuildingDef& bd = C().buildings[(size_t)bi.def]; const Region* sp = bd.spr[clampv(bi.level - 1, 0, 2)];
    float bx = (float)(bi.x * kTile), by = (float)((bi.y + 1) * kTile);
    if (bx - tl.x > vw + 8 || bx + bd.w * kTile - tl.x < -8 || by - tl.y < -8 || by - sp->h - tl.y > vh + 8) continue;
    g_items.push_back({by - 0.5f, sp, bx - tl.x, by - tl.y, false, kWhite, 0, 1.f, 0});
    if (night && m.outdoors) { lights.push_back({bx + (float)(bd.door * kTile) + 8.f, by - 10.f, 46.f, col::rgba(255, 200, 120)}); lights.push_back({bx + (float)(bd.w * kTile) * 0.2f, by - 22.f, 26.f, col::rgba(255, 210, 140)}); }
  }
  // entities
  auto pushChar = [&](const Region* sp, Vec2 pos, bool flip, bool shadow) {
    g_items.push_back({pos.y, sp, pos.x - tl.x, pos.y + 2.f - tl.y, flip, kWhite, shadow ? 1 : 0, 1.f, 0});
  };
  {
    Player& p = s.pl; const CharAnim& pa = playerAnim(p.look); int di = dirIdx(p.facing); bool flip = p.facing == Dir::Left;
    const Region* sp = pa.idle[di];
    int wi = ((int)p.walkT) & 3;
    if (p.moving) sp = pa.walk[di][wi];
    if (p.animKind == 1) sp = pa.swing[di][clampv((int)(p.animT / std::max(0.01f, p.animDur) * 3.f), 0, 2)];
    else if (p.animKind == 2) sp = pa.water[di][p.animT / std::max(0.01f, p.animDur) > 0.4f ? 1 : 0];
    else if (p.animKind == 3) sp = pa.fish[di][(top() == St::Fishing && fg.phase >= 2) ? 1 : 0];
    else if (p.animKind == 4) sp = pa.pick[di][p.animT / std::max(0.01f, p.animDur) > 0.5f ? 1 : 0];
    else if (p.animKind == 5) { sp = pa.eat[(int)(p.animT * 6) & 1]; flip = false; }
    else if (p.happyT > 0) { sp = pa.happy; flip = false; }
    pushChar(sp, p.pos, flip, true);
    if (m.dark || night) lights.push_back({p.pos.x, p.pos.y - 8.f, m.dark ? 96.f : 50.f, col::rgba(255, 226, 176)});
  }
  for (auto& n : s.npcs) {
    if (!npcIsPlaced(n)) continue;
    if (n.pos.x - tl.x < -16 || n.pos.x - tl.x > vw + 16 || n.pos.y - tl.y < -8 || n.pos.y - tl.y > vh + 40) continue;
    const CharAnim& a = npcAnim(n.def, season); int di = dirIdx(n.facing); bool flip = n.facing == Dir::Left;
    const Region* sp = a.idle[di];
    if (n.moving) sp = a.walk[di][((int)(n.animT * 8.f)) & 3];
    else if (n.talkT > 0) { sp = a.talk[((int)(n.animT * 6.f)) & 1]; flip = false; }
    else if (n.act == "work" || n.act == "forage") sp = a.swing[di][((int)(n.animT * 2.f)) % 3];
    pushChar(sp, n.pos, flip, true);
  }
  if (m.id == "farm") for (auto& an : s.animals) {
    if (an.inside) continue;
    const AnimalDef& d = C().animals[(size_t)an.def];
    std::string artName = d.art; if (d.art == "sheep" && !an.product) artName = "sheep_shorn";
    const AnimalAnim& aa = animalAnim(artName); const Region* sp = aa.idle[(int)(an.animT * 1.5f) & 1];
    if (an.moving) sp = aa.walk[((int)(an.animT * 7.f)) & 3];
    else if (an.act == 1) sp = aa.eat[((int)(an.animT * 3.f)) & 1];
    else if (an.act == 2) sp = aa.sleep[((int)(an.animT * 1.f)) & 1];
    else if (an.act == 3) sp = aa.play[((int)(an.animT * 5.f)) & 1];
    g_items.push_back({an.pos.y, sp, an.pos.x - tl.x, an.pos.y + 1.f - tl.y, an.facing == Dir::Left, kWhite, 1, d.art == "cow" ? 1.8f : (d.art == "chicken" || d.art == "duck" || d.art == "rabbit" ? 0.9f : 1.3f), 0});
  }
  if (festivalState == 2 && m.id == "village") for (auto& fp : festPickups) g_items.push_back({fp.y, &Sprites::world.get("o_fg_daffodil"), fp.x - tl.x, fp.y + 6.f - tl.y, false, kWhite, 0, 1.f, 0});
  // ---------------------------------------------------------------- decals, shadows, sorted draw
  for (int oi : decals) {
    const MapObject& o = m.objs[(size_t)oi]; const ObjDef& d = C().objs[o.def]; const Region* sp = d.spr[0];
    if (o.kind == ObjKind::Hazard && (((int)(timeSec * 0.55f) + o.x + o.y) & 1)) sp = art.spikesOff;
    b.region(*sp, (float)(o.x * kTile) + 8 - tl.x, (float)((o.y + 1) * kTile) - tl.y, kWhite);
    if (d.lightR > 0) lights.push_back({(float)(o.x * kTile) + 8, (float)(o.y * kTile) + 8, d.lightR, d.lightCol});
  }
  if (settings.shadows) for (const RItem& it : g_items) if (it.shadow) b.region(*art.shadow, it.x, it.y - 1.f, kWhite, false, it.shadowScale, it.shadowScale);
  std::sort(g_items.begin(), g_items.end(), [](const RItem& a, const RItem& c) { return a.sortY < c.sortY; });
  int visible = 0;
  for (const RItem& it : g_items) {
    if (it.sway) {   // sway only the canopy: split the sprite so the trunk stays planted
      const Region& rg = *it.spr; int cut = rg.h * 62 / 100;
      float x0 = it.x - rg.ax, y0 = it.y - rg.ay;
      b.regionPart(rg, 0, 0, rg.w, cut, x0 + (float)it.sway, y0, (float)rg.w, (float)cut, it.color);
      b.regionPart(rg, 0, cut, rg.w, rg.h - cut, x0, y0 + (float)cut, (float)rg.w, (float)(rg.h - cut), it.color);
    } else b.region(*it.spr, it.x, it.y, it.color, it.flip);
    ++visible;
  }
  r->stats.visibleSprites = visible;
  for (int oi : tops) { const MapObject& o = m.objs[(size_t)oi]; b.region(*C().objs[o.def].spr[0], (float)(o.x * kTile) - tl.x, (float)(o.y * kTile) - tl.y); }
  // machine / product bubbles
  for (auto& o : m.objs) {
    if (o.kind != ObjKind::Machine || o.state != 2) continue;
    if (o.x < (int)(tl.x / kTile) - 1 || o.x > (int)((tl.x + vw) / kTile) + 1) continue;
    float bx = (float)(o.x * kTile) + 8 - tl.x, by = (float)(o.y * kTile) - 4 - tl.y - std::sin(timeSec * 4.f) * 1.5f;
    b.region(Sprites::ui.get("ui_circle"), bx - 6.f, by - 12.f, col::rgba(255, 250, 235), false, 0.375f, 0.375f);
    b.regionRect(C().icon([&] { ItemStack st; st.id = (u16)(o.aux & 0xFFFF); st.count = 1; return st; }()), bx - 5.f, by - 11.f, 10.f, 10.f, kWhite);
  }
  if (m.id == "farm") for (auto& an : s.animals) if (an.product && !an.inside) {
    float bx = an.pos.x - tl.x, by = an.pos.y - 22.f - tl.y - std::sin(timeSec * 4.f + an.pos.x) * 1.5f;
    b.region(Sprites::ui.get("fx_exclaim"), bx, by, kWhite);
  }
  // ---------------------------------------------------------------- particles + weather
  fx.render(*r, tl.x, tl.y, settings.reducedMotion);
  b.flush();
  // ---------------------------------------------------------------- lighting
  float d = s.cal.daylight(); float tw = s.cal.twilight();
  float ar, ag, ab;
  if (m.mineFloor > 0 || m.dark) { ar = 0.33f; ag = 0.32f; ab = 0.46f; }
  else if (m.indoor) { ar = 1.0f; ag = 0.96f; ab = 0.90f; }
  else {
    ar = lerpf(0.30f, 1.f, d); ag = lerpf(0.36f, 1.f, d); ab = lerpf(0.62f, 1.f, d);
    float k = tw * 0.45f * (0.4f + 0.6f * (1.f - std::fabs(d - 0.5f) * 2.f)); ar = lerpf(ar, 1.0f, k * 0.3f); ag = lerpf(ag, 0.80f, k); ab = lerpf(ab, 0.62f, k);
    float wm = 1.f; switch (s.wx.today) { case Weather::Rain: wm = 0.86f; break; case Weather::HeavyRain: wm = 0.76f; break; case Weather::Storm: wm = 0.64f; break; case Weather::Cloudy: wm = 0.93f; break; case Weather::Fog: wm = 0.92f; break; case Weather::Snow: wm = 0.94f; break; default: break; }
    wm = lerpf(1.f, wm, s.wx.intensity > 0.01f || s.wx.today == Weather::Cloudy ? 1.f : 0.f);
    ar *= wm; ag *= wm; ab *= std::min(1.f, wm + 0.04f);
    if (s.cal.season == Autumn) { ag *= 0.985f; ab *= 0.95f; } if (s.cal.season == Winter) { ar *= 0.97f; ab = std::min(1.f, ab * 1.04f); }
  }
  bool needLight = ar < 0.985f || ag < 0.985f || ab < 0.985f || !lights.empty();
  if (needLight && settings.lighting) { g_ambient = col::rgba((int)(ar * 255), (int)(ag * 255), (int)(ab * 255)); r->drawLighting(g_ambient, lights, true, false); }
  else if (needLight && (ar < 0.985f || ag < 0.985f || ab < 0.985f)) r->drawLighting(col::rgba((int)(ar * 255), (int)(ag * 255), (int)(ab * 255)), lights, false, true);
  if (s.wx.flash > 0.01f && m.outdoors) { b.setBlend(BlendMode::Add); b.rect(0, 0, vw, vh, col::rgba(200, 210, 255, (int)(clampv(s.wx.flash, 0.f, 1.f) * 140))); b.flush(); b.setBlend(BlendMode::Alpha); }
  if (s.wx.today == Weather::Fog && m.outdoors) { b.rect(0, 0, vw, vh, col::rgba(225, 232, 238, (int)(60 * s.wx.intensity))); }
  b.region(Sprites::ui.get("fx_vignette"), 0, 0, col::withAlpha(kWhite, 0.55f), false, vw / 32.f, vh / 32.f);
  r->endWorld();
}

void Game::updateWeatherFx(float dt) {
  Map& m = map(); WeatherState& w = s.wx;
  float target = (!m.outdoors) ? 0.f : (w.today == Weather::Sunny || w.today == Weather::Cloudy) ? 0.f : 1.f;
  w.intensity += (target - w.intensity) * std::min(1.f, dt * 0.8f);
  w.flash = std::max(0.f, w.flash - dt * 2.6f);
  if (!m.outdoors) return;
  if (w.today == Weather::Storm) { w.nextBolt -= dt; if (w.nextBolt <= 0) { w.nextBolt = rng.rangef(6, 16); w.flash = 1.f; audio->play(Sfx::Thunder, 0.9f); if (!settings.reducedMotion) cam.shake(1.5f); } }
  float W = viewSize().x, H = viewSize().y, dens = (float)settings.weatherDensity / 2.f;
  auto rate = [&](float perSec) { float n = perSec * dt * dens * std::max(0.1f, w.intensity); int k = (int)n; if (rng.chance(n - (float)k)) ++k; return k; };
  switch (w.today) {
    case Weather::Rain: case Weather::HeavyRain: case Weather::Storm: {
      bool heavy = w.today != Weather::Rain;
      for (int i = 0, n = rate(heavy ? 200.f : 110.f); i < n; ++i) fx.emit(heavy ? Fx::RainHeavy : Fx::Rain, rng.rangef(-10, W + 30), -6, heavy ? -30.f : -14.f, heavy ? 230.f : 170.f, (H + 10) / (heavy ? 230.f : 170.f), kWhite, 0, true);
      for (int i = 0, n = rate(24.f); i < n; ++i) fx.emit(Fx::Splash, rng.rangef(0, W), rng.rangef(H * 0.3f, H), 0, 0, 0.3f, kWhite, 0, true);
      break;
    }
    case Weather::Snow:
      for (int i = 0, n = rate(55.f); i < n; ++i) { Particle* p = fx.emit(Fx::Snow, rng.rangef(-10, W + 10), -6, rng.rangef(-8, 8), rng.rangef(14, 28), (H + 12) / 20.f, kWhite, 0, true); if (p) p->frame = (u8)rng.range(0, 2); }
      break;
    case Weather::Wind:
      for (int i = 0, n = rate(7.f); i < n; ++i) fx.emit(s.cal.season == Spring ? Fx::Petal : Fx::Leaf, -6, rng.rangef(0, H), rng.rangef(60, 110), rng.rangef(-6, 10), 4.f, kWhite, 6, true);
      break;
    case Weather::Fog:
      if (fx.count() < 60 && rng.chance(dt * 0.6f)) { Particle* p = fx.emit(Fx::Fog, -30, rng.rangef(0, H), rng.rangef(5, 12), 0, 24.f, col::rgba(236, 240, 244), 0, true); if (p) p->size = rng.rangef(4.f, 7.f); }
      break;
    default: break;
  }
  // ambient life
  if (settings.particles >= 1 && w.today != Weather::Snow && !isRainy(w.today)) {
    float day = s.cal.daylight();
    if (s.cal.season == Autumn && rng.chance(dt * 1.6f)) fx.emit(Fx::Leaf, rng.rangef(0, W), -6, rng.rangef(-12, 18), rng.rangef(10, 22), 9.f, kWhite, 0, true);
    if (s.cal.season == Spring && day > 0.6f && rng.chance(dt * 1.2f)) fx.emit(Fx::Petal, rng.rangef(0, W), -6, rng.rangef(-6, 14), rng.rangef(10, 20), 9.f, kWhite, 0, true);
    if (s.cal.season != Winter && day > 0.7f && fx.count() < 90 && rng.chance(dt * 0.35f)) { Particle* p = fx.emit(Fx::Butterfly, rng.rangef(0, W), rng.rangef(H * 0.3f, H * 0.9f), rng.rangef(-9, 9), rng.rangef(-5, 5), 7.f, kWhite, 0, true); if (p) p->frame = (u8)rng.range(0, 2); }
    if (s.cal.season == Summer && day < 0.3f && fx.count() < 90 && rng.chance(dt * 1.5f)) fx.emit(Fx::Firefly, rng.rangef(0, W), rng.rangef(H * 0.4f, H), rng.rangef(-5, 5), rng.rangef(-5, 5), 5.f, kWhite, 0, true);
  }
}
}  // namespace cf
