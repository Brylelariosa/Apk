// Cached sprite lookups for characters and animals (no string building in the render loop).
#pragma once
#include "renderer/atlas.h"
#include "engine/types.h"
namespace cf {
struct CharAnim {
  const Region *idle[3] = {}, *walk[3][4] = {}, *swing[3][3] = {}, *water[3][2] = {}, *fish[3][2] = {}, *pick[3][2] = {}, *talk[2] = {}, *eat[2] = {}, *happy = nullptr;
};
struct AnimalAnim { const Region *idle[2] = {}, *walk[4] = {}, *eat[2] = {}, *sleep[2] = {}, *play[2] = {}; };
const CharAnim& playerAnim(int look);
const CharAnim& npcAnim(int npcDef, int season);
const AnimalAnim& animalAnim(const std::string& artName);
inline int dirIdx(Dir d) { return d == Dir::Down ? 0 : (d == Dir::Up ? 1 : 2); }
}  // namespace cf
