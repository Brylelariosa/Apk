"""World objects: trees, rocks, ores, plants, machines, decor and furniture -> world atlas (o_<art>[_season])."""
import math, random
from .common import *

WOOD, WOOD_L, WOOD_D = hx('#7a5230'), hx('#9a6c3e'), hx('#573820')


def blob(cv, cx, cy, rx, ry, c):
    cv.ell(int(cx - rx), int(cy - ry), int(cx + rx), int(cy + ry), c)


CANOPY = {
    'spring': ('#66bd48', '#8ed86a', '#3f9a3a'),
    'summer': ('#3f9e3a', '#62bf4f', '#2a7a2e'),
    'autumn': ('#d9792b', '#f0a040', '#a8481e'),
}


def oak(season):
    cv = Cv(32, 48)
    rng = random.Random('oak' + season)
    cv.rect(13, 28, 18, 46, WOOD); cv.vline(13, 28, 46, WOOD_L); cv.vline(18, 28, 46, WOOD_D); cv.vline(16, 32, 40, WOOD_D)
    cv.poly([(10, 47), (13, 41), (18, 41), (21, 47)], WOOD); cv.hline(10, 21, 47, WOOD_D); cv.px(11, 46, WOOD_L)
    if season == 'winter':
        br = hx('#6a4a30')
        for (a, b) in [((16, 30), (16, 18)), ((16, 24), (9, 15)), ((16, 22), (23, 13)), ((9, 15), (5, 8)), ((9, 15), (12, 6)), ((23, 13), (27, 8)), ((23, 13), (20, 5)), ((16, 18), (14, 10)), ((16, 18), (19, 9)), ((13, 27), (6, 22)), ((19, 27), (26, 21))]:
            cv.line(*a, *b, br)
        snow = (246, 250, 255, 255); sh = hx('#c4d8ea')
        for (x, y) in [(16, 17), (15, 17), (9, 14), (8, 14), (23, 12), (24, 12), (12, 5), (13, 5), (20, 4), (5, 7), (27, 7), (6, 21), (7, 21), (26, 20), (25, 20), (14, 9), (19, 8)]:
            cv.px(x, y, snow); cv.px(x, y + 1, sh)
        cv.ell(10, 43, 21, 47, snow); cv.hline(11, 20, 46, sh)
    else:
        base, hi, lo = [hx(c) for c in CANOPY[season]]
        blobs = [(16, 17, 13, 11), (8, 22, 8, 7), (24, 22, 8, 7), (16, 8, 9, 7), (9, 12, 7, 6), (23, 12, 7, 6), (16, 26, 10, 5)]
        for cx, cy, rx, ry in blobs: blob(cv, cx + 1, cy + 2, rx, ry, lo)
        for cx, cy, rx, ry in blobs: blob(cv, cx, cy, rx, ry, base)
        for cx, cy, rx, ry in blobs[:5]: blob(cv, cx - 2, cy - 3, rx * 0.55, ry * 0.5, hi)
        for _ in range(55):
            x, y = rng.randint(3, 28), rng.randint(2, 30)
            if cv.get(x, y)[3]: cv.px(x, y, hi if rng.random() < 0.5 else lo)
        if season == 'spring':
            for _ in range(46):
                x, y = rng.randint(3, 28), rng.randint(2, 30)
                if cv.get(x, y)[3]:
                    c = hx(rng.choice(['#ffd6e4', '#ffffff', '#ffb6cc']))
                    cv.px(x, y, c); cv.px(x + 1, y, c) if rng.random() < .5 else None
        if season == 'autumn':
            for _ in range(36):
                x, y = rng.randint(3, 28), rng.randint(2, 30)
                if cv.get(x, y)[3]:
                    c = hx(rng.choice(['#c9372a', '#e8c030', '#b8431f']))
                    cv.px(x, y, c); cv.px(x + 1, y, c); cv.px(x, y + 1, shade(c, .85))
    cv.outline()
    return cv


def pine(season):
    cv = Cv(24, 40)
    rng = random.Random('pine' + season)
    cv.rect(10, 33, 13, 39, WOOD); cv.vline(10, 33, 39, WOOD_L); cv.vline(13, 33, 39, WOOD_D)
    base, hi, lo = {'spring': ('#3f9158', '#5db06f', '#2a7048'), 'summer': ('#2f7a4a', '#4a9a5c', '#1f5c3a'),
                    'autumn': ('#3a7448', '#5a8f50', '#285a38'), 'winter': ('#2f7a4a', '#4a9a5c', '#1f5c3a')}[season]
    base, hi, lo = hx(base), hx(hi), hx(lo)
    tiers = [(12, 1, 15, 7), (12, 9, 25, 9), (12, 17, 35, 11)]
    for ax, ay, by, hw in tiers:
        cv.poly([(ax, ay), (ax + hw, by), (ax - hw, by)], lo)
        cv.poly([(ax, ay + 1), (ax + hw - 2, by - 1), (ax - hw + 1, by - 1)], base)
        cv.poly([(ax, ay + 2), (ax - 1, ay + 4), (ax - hw + 3, by - 2), (ax - 2, by - 4)], hi)
        for _ in range(6):
            x, y = rng.randint(ax - hw + 2, ax + hw - 2), rng.randint(ay + 3, by - 1)
            if cv.get(x, y)[3]: cv.px(x, y, lo if rng.random() < .6 else hi)
    if season == 'winter':
        snow = (246, 250, 255, 255); sh = hx('#c4d8ea')
        for ax, ay, by, hw in tiers:
            for y in range(ay + 1, by - 1):
                half = int((y - ay) * hw / (by - ay))
                if (y - ay) % 5 < 3:
                    cv.hline(ax - half + 2, ax + half - 5, y, snow)
            cv.hline(ax - hw + 1, ax + hw - 3, by - 1, sh)
    cv.outline()
    return cv


def bush(season):
    cv = Cv(16, 16)
    rng = random.Random('bush' + season)
    base, hi, lo = {'spring': ('#58b04a', '#7acf62', '#3a8a3a'), 'summer': ('#3f9a3a', '#5fb84c', '#2a7a2e'),
                    'autumn': ('#b8742a', '#d89a3c', '#8a4a1c'), 'winter': ('#8a7a5a', '#a89878', '#6a5a40')}[season]
    base, hi, lo = hx(base), hx(hi), hx(lo)
    blob(cv, 8, 10, 6.5, 4.5, lo); blob(cv, 7, 9, 6, 4.5, base); blob(cv, 5, 7, 3.5, 2.5, hi); blob(cv, 11, 8, 3, 2.5, hi)
    for _ in range(14):
        x, y = rng.randint(2, 13), rng.randint(4, 13)
        if cv.get(x, y)[3]: cv.px(x, y, hi if rng.random() < .5 else lo)
    if season == 'spring':
        for (x, y) in [(4, 8), (8, 6), (11, 9), (6, 11), (10, 5)]: cv.px(x, y, hx('#ff9ec0')); cv.px(x + 1, y, hx('#ffffff'))
    if season == 'summer':
        for (x, y) in [(4, 9), (9, 7), (11, 10), (7, 11)]: cv.px(x, y, hx('#e8334a'))
    if season == 'winter':
        snow = (246, 250, 255, 255)
        cv.hline(3, 11, 5, snow); cv.hline(4, 9, 6, snow); cv.px(11, 7, snow); cv.px(3, 7, snow)
    cv.outline()
    return cv


def stump():
    cv = Cv(16, 16)
    cv.rect(3, 6, 12, 13, WOOD); cv.vline(3, 6, 13, WOOD_L); cv.vline(12, 6, 13, WOOD_D)
    cv.ell(3, 3, 12, 8, hx('#d9b37a')); cv.ell(5, 4, 10, 7, hx('#c49858')); cv.ell(7, 5, 8, 6, hx('#a87a42'))
    cv.hline(2, 13, 13, WOOD_D); cv.poly([(1, 14), (3, 11), (4, 14)], WOOD); cv.poly([(14, 14), (12, 11), (11, 14)], WOOD)
    return cv.outline()


def log_big():
    cv = Cv(32, 16)
    cv.rect(5, 4, 29, 13, WOOD); cv.hline(5, 29, 4, WOOD_L); cv.hline(5, 29, 5, WOOD_L); cv.hline(5, 29, 13, WOOD_D)
    for x in range(8, 29, 5): cv.vline(x, 6, 12, hx('#6a4426'))
    cv.ell(1, 3, 10, 14, hx('#d9b37a')); cv.ell(3, 5, 8, 12, hx('#c49858')); cv.ell(5, 7, 6, 10, hx('#a87a42'))
    for (x, y) in [(14, 6), (15, 6), (22, 7), (23, 7)]: cv.px(x, y, hx('#5f9a3e'))
    return cv.outline()


def rock(kind):
    sizes = {'s': (16, 16, 6, 5), 'm': (16, 16, 7, 6), 'boulder': (32, 32, 14, 12), 'cave': (16, 16, 7, 6)}
    w, h, rx, ry = sizes[kind]
    cv = Cv(w, h)
    rng = random.Random('rock' + kind)
    base, hi, lo = (hx('#8e919c'), hx('#b4b8c4'), hx('#666977')) if kind != 'cave' else (hx('#6d6680'), hx('#8f88a6'), hx('#463f58'))
    cx, cy = w / 2, h - ry - 1
    pts = []
    for i in range(10):
        a = i / 10 * 2 * math.pi
        r = 1 + rng.uniform(-0.12, 0.1)
        pts.append((cx + math.cos(a) * rx * r, cy + math.sin(a) * ry * r * (0.85 if math.sin(a) < 0 else 1)))
    cv.poly(pts, lo)
    cv.poly([(x - 0.8, y - 0.8) for x, y in pts], base)
    cv.poly([(cx + (x - cx) * .55 - 1, cy + (y - cy) * .5 - 2) for x, y in pts], hi)
    for _ in range(int(rx)):
        x, y = rng.randint(int(cx - rx), int(cx + rx)), rng.randint(int(cy - ry), int(cy + ry))
        if cv.get(x, y)[3]: cv.px(x, y, lo if rng.random() < .5 else hi)
    return cv.outline()


def ore(base_hex, spec_hex, glow=False, coal=False, name=''):
    cv = rock('cave')
    rng = random.Random('ore' + name)
    spec, spec2 = hx(spec_hex), light(hx(spec_hex), .5)
    pts = [(5, 8), (9, 6), (11, 9), (7, 10), (4, 11), (10, 11), (8, 8)]
    for (x, y) in pts:
        if coal: cv.rect(x, y, x + 1, y + 1, hx(base_hex)); cv.px(x, y, hx(spec_hex))
        else:
            cv.px(x, y, spec); cv.px(x + 1, y, spec); cv.px(x, y + 1, shade(spec, .8)); cv.px(x, y - 1, spec2)
    return cv.outline()


def gem_cluster(c1, c2):
    cv = Cv(16, 16)
    cv.poly([(2, 14), (4, 10), (12, 10), (14, 14)], hx('#5a5470')); cv.hline(3, 13, 14, hx('#3a3550'))
    a, b = hx(c1), hx(c2)
    for (x, top, w) in [(4, 3, 2), (7, 1, 3), (10, 4, 2), (6, 6, 2)]:
        cv.poly([(x, 11), (x + w // 2, top), (x + w, 11)], a)
        cv.poly([(x + w // 2, top), (x + w, 11), (x + w // 2, 11)], shade(a, .78))
        cv.px(x + w // 2, top + 2, b); cv.px(x + w // 2, top + 3, b)
    return cv.outline()


def weed(season, tall=False):
    cv = Cv(16, 16)
    rng = random.Random('weed%s%d' % (season, tall))
    cols = {'spring': ('#5ab04a', '#7acf62'), 'summer': ('#3f9a3a', '#62bf4f'), 'autumn': ('#a8a040', '#c8c060'), 'winter': ('#9a8a60', '#c0b088')}[season]
    n = 7 if tall else 5
    for i in range(n):
        x = 3 + i * (10 // (n - 1)) + rng.randint(-1, 1)
        hgt = rng.randint(9, 13) if tall else rng.randint(4, 8)
        lean = rng.randint(-2, 2)
        cv.line(x, 14, x + lean, 14 - hgt, hx(cols[i % 2]))
        cv.px(x + lean, 14 - hgt, hx(cols[(i + 1) % 2]))
    if season == 'winter':
        for _ in range(4): cv.px(rng.randint(3, 12), rng.randint(8, 13), (246, 250, 255, 255))
    if season == 'spring' and tall:
        for (x, y) in [(5, 5), (10, 4)]: cv.px(x, y, hx('#fff0f4'))
    return cv.outline()


def twig():
    cv = Cv(16, 16)
    cv.line(3, 11, 12, 8, WOOD); cv.line(4, 10, 11, 12, WOOD_L); cv.line(8, 9, 10, 5, WOOD); cv.line(6, 10, 4, 6, WOOD_D)
    return cv.outline()


def clay_spot():
    cv = Cv(16, 16)
    cv.ell(2, 7, 13, 13, hx('#a85a3e')); cv.ell(3, 8, 12, 12, hx('#c8785a')); cv.ell(5, 9, 9, 11, hx('#e0987a'))
    return cv.outline()


def signpost():
    cv = Cv(16, 24)
    cv.rect(7, 8, 8, 22, WOOD); cv.rect(1, 3, 14, 10, hx('#c49858')); cv.rect(1, 3, 14, 3, hx('#d9b37a')); cv.hline(1, 14, 10, WOOD_D)
    for x in (3, 12): cv.px(x, 6, hx('#5a3a20'))
    cv.hline(3, 12, 6, hx('#8a5f34')); cv.hline(4, 10, 8, hx('#8a5f34'))
    return cv.outline()


def wisp(frame=0):
    cv = Cv(16, 16)
    for r, a in [(6, 50), (4, 110), (2, 230)]:
        blob(cv, 8, 8, r, r, (154, 216, 255, a))
    cv.px(8, 8, (255, 255, 255, 255)); cv.px(7, 7, (255, 255, 255, 255))
    return cv


def shrine():
    cv = Cv(32, 40)
    cv.rect(4, 30, 27, 38, hx('#8e919c')); cv.rect(4, 30, 27, 31, hx('#b4b8c4')); cv.rect(6, 22, 25, 30, hx('#a2a6b1'))
    cv.rect(10, 12, 21, 22, hx('#8e919c')); cv.poly([(8, 12), (16, 4), (24, 12)], hx('#666977'))
    for r, a in [(7, 60), (5, 120), (3, 230)]: blob(cv, 16, 17, r, r, (154, 216, 255, a))
    cv.px(16, 17, (255, 255, 255, 255))
    cv.hline(4, 27, 38, hx('#666977'))
    return cv.outline()


def ladder():
    cv = Cv(16, 16)
    cv.ell(1, 2, 14, 14, hx('#1e1a28')); cv.ell(2, 3, 13, 13, hx('#0e0b14'))
    cv.rect(5, 4, 6, 14, WOOD_L); cv.rect(10, 4, 11, 14, WOOD_L)
    for y in (6, 9, 12): cv.hline(5, 11, y, WOOD)
    return cv.outline()


def hole():
    cv = Cv(16, 16)
    cv.ell(1, 4, 14, 14, hx('#6a6280')); cv.ell(2, 5, 13, 13, hx('#0a0810')); cv.ell(4, 7, 11, 12, hx('#000000'))
    return cv.outline()


def spikes(on):
    cv = Cv(16, 16)
    cv.rect(1, 8, 14, 14, hx('#4a4558')); cv.rect(2, 9, 13, 13, hx('#3a3548'))
    for x in (3, 7, 11):
        for y in (9, 12):
            if on:
                cv.poly([(x, y + 2), (x + 1, y - 4), (x + 2, y + 2)], hx('#c8ccd8')); cv.px(x + 1, y - 3, (255, 255, 255, 255))
            else:
                cv.px(x + 1, y, hx('#9a9eaa'))
    return cv.outline()


def treasure(open_):
    cv = Cv(16, 16)
    cv.rect(2, 7, 13, 13, hx('#a8703a')); cv.hline(2, 13, 7, hx('#d09a58')); cv.hline(2, 13, 13, hx('#6a4526'))
    if open_:
        cv.rect(2, 3, 13, 6, hx('#8a5a2e')); cv.rect(3, 4, 12, 6, hx('#ffd23a')); cv.px(5, 4, (255, 255, 255, 255)); cv.px(9, 5, (255, 255, 255, 255))
    else:
        cv.rect(2, 3, 13, 7, hx('#b87a40')); cv.hline(2, 13, 3, hx('#d9a864')); cv.hline(3, 12, 4, hx('#c8924e'))
    cv.vline(5, 3, 13, hx('#ffd23a')); cv.vline(10, 3, 13, hx('#ffd23a')); cv.rect(7, 7, 8, 9, hx('#ffe680')); cv.px(7, 8, hx('#8a5a10'))
    return cv.outline()


def glow_crystal():
    cv = Cv(16, 24)
    for (x, top, w) in [(2, 12, 4), (6, 2, 5), (10, 9, 4)]:
        cv.poly([(x, 22), (x + w // 2, top), (x + w, 22)], hx('#5ab8e8'))
        cv.poly([(x + w // 2, top), (x + w, 22), (x + w // 2, 22)], hx('#3a88c8'))
        cv.vline(x + w // 2 - 1, top + 3, top + 8, hx('#d8f4ff'))
    cv.rect(1, 21, 14, 22, hx('#463f58'))
    return cv.outline()


def torch():
    cv = Cv(16, 16)
    cv.rect(7, 7, 8, 14, WOOD); cv.rect(6, 6, 9, 7, hx('#6a6a78'))
    cv.poly([(8, 1), (11, 5), (8, 7), (5, 5)], hx('#ff9a2a')); cv.poly([(8, 3), (10, 5), (8, 7), (6, 5)], hx('#ffd84a'))
    return cv.outline()


def fence(mask):
    cv = Cv(16, 16)
    post, rail, hi = hx('#9a6a3c'), hx('#b8864e'), hx('#d9aa6e')
    if mask & 2: cv.rect(8, 6, 15, 7, rail); cv.rect(8, 10, 15, 11, rail); cv.hline(8, 15, 6, hi); cv.hline(8, 15, 10, hi)
    if mask & 8: cv.rect(0, 6, 7, 7, rail); cv.rect(0, 10, 7, 11, rail); cv.hline(0, 7, 6, hi); cv.hline(0, 7, 10, hi)
    if mask & 1: cv.rect(6, 0, 9, 8, rail); cv.vline(6, 0, 8, hi)
    if mask & 4: cv.rect(6, 8, 9, 15, rail)
    cv.rect(6, 3, 9, 14, post); cv.vline(6, 3, 14, hi); cv.vline(9, 3, 14, WOOD_D); cv.hline(6, 9, 3, hi); cv.hline(5, 10, 14, WOOD_D)
    return cv.outline()


def sprinkler(q):
    cv = Cv(16, 16)
    body = hx('#b8623a') if not q else hx('#c8ccd8'); lt = hx('#e89a5a') if not q else hx('#ffffff')
    cv.rect(6, 7, 9, 13, body); cv.vline(6, 7, 13, lt); cv.rect(5, 5, 10, 7, shade(body, .85)); cv.rect(7, 3, 8, 5, hx('#6a6a78'))
    cv.hline(5, 10, 13, shade(body, .6)); cv.px(7, 2, hx('#8ad8ff')); cv.px(4, 4, hx('#8ad8ff')); cv.px(11, 4, hx('#8ad8ff'))
    if q: cv.rect(7, 9, 8, 10, hx('#ffd23a'))
    return cv.outline()


def scarecrow():
    cv = Cv(16, 24)
    cv.rect(7, 8, 8, 22, WOOD); cv.rect(1, 10, 14, 11, WOOD)
    cv.rect(4, 8, 11, 17, hx('#c0524a')); cv.rect(5, 9, 6, 16, hx('#a03a34'))
    for y in (10, 13, 16): cv.hline(4, 11, y, hx('#e8e0c0'))
    cv.ell(4, 1, 11, 8, hx('#e8c88a')); cv.px(6, 4, hx('#3a2a1a')); cv.px(9, 4, hx('#3a2a1a')); cv.hline(6, 9, 6, hx('#8a4a2a'))
    cv.rect(2, 3, 13, 4, hx('#c8a050')); cv.rect(5, 0, 10, 3, hx('#b8903c')); cv.hline(5, 10, 3, hx('#8a6a28'))
    for (x, y) in [(0, 11), (1, 12), (14, 11), (15, 12), (3, 18), (12, 18)]: cv.px(x, y, hx('#e0c060'))
    return cv.outline()


def machine(kind):
    cv = Cv(16, 24 if kind in ('furnace', 'loom', 'seedmaker', 'mayo', 'jar_machine', 'press') else 16)
    h = cv.h
    if kind == 'furnace':
        cv.rect(1, 6, 14, 22, hx('#8e919c')); cv.rect(1, 6, 14, 8, hx('#b4b8c4')); cv.rect(3, 12, 12, 20, hx('#3a3548'))
        cv.rect(5, 15, 10, 19, hx('#ff9a2a')); cv.rect(6, 16, 9, 19, hx('#ffd84a'))
        cv.rect(10, 1, 13, 6, hx('#6a6e7a')); cv.hline(1, 14, 22, hx('#5a5e6a'))
        for x in (3, 7, 11): cv.vline(x, 9, 11, hx('#7a7e8a'))
    elif kind == 'press':
        cv.rect(2, 10, 13, 22, hx('#a8703a')); cv.rect(2, 10, 13, 11, hx('#d09a58')); cv.rect(3, 18, 12, 21, hx('#f2c23a'))
        cv.rect(7, 2, 8, 10, hx('#8a8e9a')); cv.rect(3, 1, 12, 2, WOOD); cv.rect(1, 21, 14, 22, WOOD_D)
    elif kind == 'loom':
        cv.rect(1, 3, 2, 22, WOOD); cv.rect(13, 3, 14, 22, WOOD); cv.rect(1, 3, 14, 4, WOOD_L); cv.rect(1, 20, 14, 22, WOOD_D)
        for x in range(4, 13, 2): cv.vline(x, 5, 18, hx('#e8d8f4'))
        cv.rect(3, 12, 12, 14, hx('#c8a0e0')); cv.hline(3, 12, 12, hx('#e8c8f8'))
    elif kind == 'jar_machine':
        cv.rect(2, 8, 13, 22, hx('#a8703a')); cv.rect(2, 8, 13, 9, hx('#d09a58')); cv.hline(2, 13, 14, hx('#6a4526')); cv.hline(2, 13, 19, hx('#6a4526'))
        cv.rect(4, 2, 11, 8, hx('#bfe6f4')); cv.rect(5, 3, 10, 7, hx('#d8506a')); cv.rect(4, 1, 11, 2, hx('#8a8e9a'))
    elif kind == 'mayo':
        cv.rect(2, 8, 13, 22, hx('#c8ccd8')); cv.rect(2, 8, 4, 22, hx('#e8ecf4')); cv.rect(10, 8, 13, 22, hx('#9a9eaa'))
        cv.ell(5, 12, 10, 18, hx('#f6e8a8')); cv.ell(6, 13, 9, 17, hx('#fff6d0')); cv.rect(5, 2, 10, 8, hx('#8a8e9a')); cv.rect(3, 1, 12, 2, hx('#6a6e7a'))
    elif kind == 'seedmaker':
        cv.rect(2, 9, 13, 22, hx('#a8703a')); cv.rect(2, 9, 13, 10, hx('#d09a58')); cv.poly([(1, 2), (14, 2), (11, 9), (4, 9)], hx('#8a8e9a'))
        cv.rect(5, 13, 10, 18, hx('#3a2a1a')); cv.px(6, 15, hx('#8fd06a')); cv.px(8, 16, hx('#e8c860')); cv.px(7, 14, hx('#e8c860'))
    elif kind == 'feeder':
        cv.rect(1, 9, 14, 14, hx('#a8703a')); cv.rect(1, 9, 14, 10, hx('#d09a58')); cv.rect(2, 7, 13, 9, hx('#e0c060')); cv.poly([(3, 1), (12, 1), (14, 7), (1, 7)], hx('#b8864e'))
        cv.rect(3, 2, 12, 4, hx('#e8d070')); cv.hline(1, 14, 14, WOOD_D); cv.vline(2, 14, 15, WOOD); cv.vline(13, 14, 15, WOOD)
    elif kind == 'basket':
        cv.ell(1, 5, 14, 14, hx('#a8803a')); cv.ell(2, 6, 13, 13, hx('#c8a050')); cv.hline(2, 13, 9, hx('#a8803a')); cv.hline(2, 13, 11, hx('#a8803a'))
        cv.line(3, 6, 8, 1, hx('#a8803a')); cv.line(13, 6, 8, 1, hx('#a8803a')); cv.ell(5, 6, 10, 9, hx('#f6efe2'))
    elif kind == 'chest':
        cv.rect(2, 6, 13, 14, hx('#a8703a')); cv.rect(2, 6, 13, 8, hx('#c8924e')); cv.hline(2, 13, 14, hx('#6a4526'))
        cv.rect(2, 10, 13, 10, hx('#6a4526')); cv.rect(7, 9, 8, 11, hx('#d8d8e0')); cv.px(7, 10, hx('#6a6a78'))
        cv.vline(3, 6, 14, hx('#8a5a2e')); cv.vline(12, 6, 14, hx('#8a5a2e'))
    elif kind == 'lamp':
        cv.rect(7, 6, 8, 14, hx('#4a4a58')); cv.rect(5, 2, 10, 7, hx('#ffe08a')); cv.rect(6, 3, 9, 6, hx('#fff6c8')); cv.rect(4, 1, 11, 2, hx('#4a4a58')); cv.rect(5, 14, 10, 15, hx('#4a4a58'))
    elif kind == 'bin':
        cv = Cv(32, 24)
        cv.rect(1, 8, 30, 22, hx('#a8703a')); cv.rect(1, 8, 30, 9, hx('#d09a58'))
        for x in range(5, 30, 6): cv.vline(x, 10, 21, hx('#8a5a2e'))
        cv.rect(0, 5, 31, 8, hx('#8a5a2e')); cv.hline(0, 31, 5, hx('#c8924e')); cv.rect(10, 3, 21, 5, hx('#d0a060')); cv.hline(0, 31, 22, WOOD_D)
    return cv.outline()


def lamp_post():
    cv = Cv(16, 40)
    cv.rect(7, 12, 8, 38, hx('#3a3a48')); cv.rect(5, 37, 10, 39, hx('#2a2a38')); cv.rect(6, 34, 9, 36, hx('#4a4a58'))
    cv.rect(4, 3, 11, 12, hx('#ffe08a')); cv.rect(5, 4, 10, 11, hx('#fff6c8')); cv.rect(3, 2, 12, 3, hx('#3a3a48')); cv.poly([(4, 2), (8, 0), (11, 2)], hx('#3a3a48'))
    cv.vline(7, 4, 11, hx('#e8c860')); cv.hline(4, 11, 12, hx('#3a3a48'))
    return cv.outline()


def bench():
    cv = Cv(32, 16)
    cv.rect(2, 4, 29, 6, hx('#c28f56')); cv.rect(2, 8, 29, 10, hx('#b8864e')); cv.hline(2, 29, 4, hx('#e0b070'))
    cv.rect(4, 6, 5, 14, WOOD); cv.rect(26, 6, 27, 14, WOOD); cv.rect(3, 11, 28, 11, hx('#a87a42')); cv.hline(2, 29, 10, WOOD_D)
    return cv.outline()


def barrel():
    cv = Cv(16, 16)
    cv.ell(2, 1, 13, 14, hx('#8a5a2e')); cv.rect(2, 4, 13, 12, hx('#a8703a')); cv.vline(5, 3, 13, hx('#c8924e')); cv.vline(10, 3, 13, hx('#7a4a22'))
    cv.hline(2, 13, 5, hx('#5a5a68')); cv.hline(2, 13, 11, hx('#5a5a68')); cv.ell(3, 1, 12, 5, hx('#c8924e')); cv.ell(5, 2, 10, 4, hx('#8a5a2e'))
    return cv.outline()


def crate():
    cv = Cv(16, 16)
    cv.rect(1, 3, 14, 14, hx('#b8864e')); cv.rect(1, 3, 14, 4, hx('#d9aa6e'))
    cv.rect(1, 3, 3, 14, hx('#8a5a2e')); cv.rect(12, 3, 14, 14, hx('#8a5a2e')); cv.line(3, 4, 12, 13, hx('#8a5a2e')); cv.line(12, 4, 3, 13, hx('#8a5a2e'))
    return cv.outline()


def haybale():
    cv = Cv(16, 16)
    cv.rect(1, 4, 14, 14, hx('#e0c060')); cv.rect(1, 4, 14, 5, hx('#f2dc84'))
    for y in (7, 10, 13): cv.hline(1, 14, y, hx('#b8963a'))
    cv.vline(5, 4, 14, hx('#a8802a')); cv.vline(10, 4, 14, hx('#a8802a'))
    for (x, y) in [(2, 3), (6, 2), (11, 3), (13, 2)]: cv.px(x, y, hx('#e0c060'))
    return cv.outline()


def well():
    cv = Cv(16, 32)
    cv.rect(1, 18, 14, 30, hx('#8e919c')); cv.rect(1, 18, 14, 20, hx('#b4b8c4')); cv.ell(2, 16, 13, 22, hx('#2a5a8a')); cv.ell(3, 17, 12, 21, hx('#4aa5db'))
    for (x, y) in [(3, 24), (8, 27), (11, 23), (5, 28)]: cv.hline(x, x + 3, y, hx('#7a7e8a'))
    cv.rect(1, 6, 2, 22, WOOD); cv.rect(13, 6, 14, 22, WOOD); cv.poly([(0, 7), (8, 0), (15, 7)], hx('#b8503a')); cv.hline(0, 15, 7, hx('#8a3a2a'))
    cv.rect(7, 8, 8, 17, hx('#b8864e')); cv.rect(6, 17, 9, 19, hx('#8a5a2e'))
    return cv.outline()


def fountain():
    cv = Cv(32, 40)
    cv.rect(2, 22, 29, 38, hx('#a2a6b1')); cv.rect(2, 22, 29, 24, hx('#d0d4de')); cv.ell(3, 22, 28, 34, hx('#4aa5db')); cv.ell(5, 24, 26, 32, hx('#8fd6f6'))
    cv.rect(2, 30, 29, 38, hx('#8e919c')); cv.hline(2, 29, 38, hx('#666977')); cv.rect(14, 8, 17, 28, hx('#b4b8c4')); cv.ell(10, 7, 21, 12, hx('#d0d4de'))
    cv.ell(12, 8, 19, 11, hx('#8fd6f6'))
    for (x, y) in [(15, 2), (16, 4), (13, 5), (18, 5), (12, 8), (19, 8), (15, 6)]: cv.px(x, y, (200, 235, 255, 255))
    return cv.outline()


def flowerbed(season):
    cv = Cv(16, 16)
    rng = random.Random('fb' + season)
    cv.rect(1, 6, 14, 14, hx('#8a5a2e')); cv.rect(2, 7, 13, 13, hx('#5a3d26')); cv.hline(1, 14, 6, hx('#c28f56'))
    cols = {'spring': ['#ff9ec0', '#fff0f4', '#ffd23a'], 'summer': ['#ff5a78', '#ffd23a', '#c070ff', '#fff'], 'autumn': ['#e0782a', '#c8402a', '#e8b030'], 'winter': ['#ffffff', '#c8e4f4']}[season]
    for i in range(7):
        x, y = 3 + (i * 2) % 11, 4 + (i * 5) % 6
        cv.vline(x, y + 2, 11, hx('#4a9a3a') if season != 'winter' else hx('#8a7a5a'))
        cv.rect(x - 1, y, x + 1, y + 1, hx(cols[i % len(cols)])); cv.px(x, y, hx('#ffe680'))
    if season == 'winter': cv.hline(2, 13, 7, (246, 250, 255, 255))
    return cv.outline()


def mailbox():
    cv = Cv(16, 24)
    cv.rect(7, 12, 8, 22, WOOD); cv.rect(2, 4, 13, 12, hx('#4a7ab0')); cv.rect(2, 4, 13, 5, hx('#7aa8d8')); cv.ell(1, 3, 6, 12, hx('#4a7ab0'))
    cv.rect(11, 1, 12, 5, hx('#e8402a')); cv.rect(11, 1, 14, 2, hx('#e8402a')); cv.rect(5, 8, 10, 9, hx('#2a4a7a'))
    return cv.outline()


def noticeboard():
    cv = Cv(32, 32)
    cv.rect(2, 4, 3, 30, WOOD); cv.rect(28, 4, 29, 30, WOOD); cv.rect(2, 2, 29, 20, hx('#8a5a2e')); cv.rect(4, 4, 27, 18, hx('#c49858'))
    for (x, y, w, h, c) in [(6, 6, 7, 6, '#fff8e0'), (15, 5, 6, 8, '#f8e0b0'), (22, 7, 4, 5, '#fff8e0'), (8, 13, 6, 4, '#e0f0d8'), (17, 14, 8, 4, '#fff8e0')]:
        cv.rect(x, y, x + w, y + h, hx(c)); cv.px(x + w // 2, y, hx('#e8402a'))
        for k in range(2, h, 2): cv.hline(x + 1, x + w - 1, y + k, hx('#a89870'))
    cv.poly([(0, 3), (16, -1), (31, 3), (31, 4), (0, 4)], hx('#b8503a'))
    return cv.outline()


def great_lantern():
    cv = Cv(32, 56)
    cv.rect(4, 46, 27, 54, hx('#8e919c')); cv.rect(4, 46, 27, 48, hx('#b4b8c4')); cv.rect(8, 40, 23, 46, hx('#a2a6b1')); cv.hline(4, 27, 54, hx('#666977'))
    cv.rect(14, 18, 17, 40, hx('#3a3a48')); cv.vline(14, 18, 40, hx('#5a5a68'))
    cv.poly([(6, 14), (25, 14), (21, 4), (10, 4)], hx('#3a3a48'))
    cv.poly([(8, 14), (23, 14), (20, 6), (11, 6)], hx('#ffe08a')); cv.poly([(11, 13), (20, 13), (18, 8), (13, 8)], hx('#fff6d0'))
    cv.poly([(4, 4), (27, 4), (16, -4)], hx('#b8503a')) if False else None
    cv.rect(9, 1, 22, 4, hx('#4a4a58')); cv.rect(14, 0, 17, 1, hx('#d8a82a'))
    cv.rect(5, 14, 26, 17, hx('#4a4a58')); cv.hline(5, 26, 14, hx('#6a6a78'))
    for (x, y) in [(10, 42), (20, 42)]: cv.px(x, y, hx('#ffe08a'))
    return cv.outline()


def stall():
    cv = Cv(32, 32)
    cv.rect(2, 12, 3, 30, WOOD); cv.rect(28, 12, 29, 30, WOOD); cv.rect(3, 22, 28, 30, hx('#b8864e')); cv.rect(3, 22, 28, 23, hx('#d9aa6e'))
    for x in range(4, 28, 6): cv.vline(x, 24, 29, hx('#8a5a2e'))
    for i in range(8):
        cv.rect(i * 4, 3, i * 4 + 3, 12, hx('#e8402a') if i % 2 == 0 else hx('#fff6e0'))
    cv.hline(0, 31, 12, hx('#8a2a1a')); cv.hline(0, 31, 3, hx('#ff8a7a'))
    for i in range(8): cv.px(i * 4 + 1, 13, hx('#e8402a') if i % 2 == 0 else hx('#fff6e0'))
    for (x, c) in [(6, '#e8334a'), (12, '#f2d34a'), (18, '#8ed36f'), (24, '#a45bc2')]: cv.ell(x, 17, x + 4, 21, hx(c))
    return cv.outline()


def bunting():
    cv = Cv(16, 10)
    cv.line(0, 1, 15, 1, hx('#6a4526'))
    for i, c in enumerate(['#e8402a', '#ffd23a', '#4aa5db', '#8fd06a']):
        x = i * 4
        cv.poly([(x, 2), (x + 3, 2), (x + 1, 7)], hx(c))
    return cv


def lantern_string():
    cv = Cv(16, 12)
    cv.line(0, 1, 15, 1, hx('#6a4526'))
    for x, c in [(2, '#ff8a5a'), (8, '#ffd23a'), (14, '#ff6a8a')]:
        cv.ell(x - 2, 2, x + 2, 8, hx(c)); cv.px(x - 1, 4, (255, 255, 255, 200)); cv.hline(x - 1, x + 1, 9, hx('#5a3a20'))
    return cv.outline() if False else cv


def pier_post():
    cv = Cv(16, 24)
    cv.rect(5, 6, 10, 22, WOOD); cv.vline(5, 6, 22, WOOD_L); cv.vline(10, 6, 22, WOOD_D); cv.ell(4, 3, 11, 8, hx('#9a6c3e')); cv.rect(4, 14, 11, 15, hx('#c8c0a0'))
    return cv.outline()


def boat():
    cv = Cv(32, 20)
    cv.poly([(1, 8), (30, 8), (26, 17), (5, 17)], hx('#a8703a')); cv.poly([(2, 8), (29, 8), (28, 10), (3, 10)], hx('#d09a58'))
    cv.hline(5, 26, 15, hx('#6a4526')); cv.hline(6, 25, 12, hx('#8a5a2e')); cv.rect(14, 4, 17, 8, hx('#8a5a2e')); cv.line(4, 5, 27, 12, hx('#c8a060'))
    return cv.outline()


def driftlog():
    cv = Cv(32, 16)
    cv.ell(1, 5, 30, 13, hx('#a89880')); cv.ell(2, 5, 29, 10, hx('#c8b8a0')); cv.hline(4, 26, 11, hx('#8a7a64'))
    cv.line(10, 6, 14, 2, hx('#a89880')); cv.line(22, 6, 26, 3, hx('#a89880'))
    return cv.outline()


def reeds(season):
    cv = Cv(16, 24)
    rng = random.Random('reeds' + season)
    col = {'spring': '#6ab04a', 'summer': '#4a9a3a', 'autumn': '#b8a050', 'winter': '#a89868'}[season]
    for i in range(6):
        x = 3 + i * 2
        top = rng.randint(2, 10)
        cv.vline(x, top, 22, hx(col))
        if i % 2 == 0: cv.rect(x - 1, top - 2, x, top + 3, hx('#7a4a2a'))
    return cv.outline()


def lilypad():
    cv = Cv(16, 16)
    cv.ell(2, 5, 13, 12, hx('#3a8a3a')); cv.ell(3, 6, 12, 11, hx('#5ab04a')); cv.poly([(8, 8), (14, 5), (14, 8)], (0, 0, 0, 0))
    cv.ell(9, 6, 11, 8, hx('#ffb6cc'))
    return cv


def bed():
    cv = Cv(32, 40)
    cv.rect(2, 4, 29, 38, hx('#8a5a2e')); cv.rect(2, 2, 29, 12, hx('#a8703a')); cv.rect(3, 3, 28, 6, hx('#c8924e'))
    cv.rect(4, 14, 27, 36, hx('#4a7ab0')); cv.rect(4, 14, 27, 20, hx('#fff6e0')); cv.rect(5, 15, 14, 19, hx('#ffffff')); cv.rect(17, 15, 26, 19, hx('#ffffff'))
    cv.rect(4, 21, 27, 23, hx('#6a9ad0'))
    for x in range(6, 27, 5): cv.px(x, 28, hx('#6a9ad0')); cv.px(x + 2, 31, hx('#2a5a90'))
    cv.hline(4, 27, 36, hx('#2a5a90'))
    return cv.outline()


def kitchen():
    cv = Cv(32, 32)
    cv.rect(1, 10, 30, 30, hx('#c8924e')); cv.rect(1, 10, 30, 14, hx('#e8e0d0')); cv.hline(1, 30, 14, hx('#a8a090'))
    cv.rect(2, 2, 14, 12, hx('#4a4a58')); cv.rect(3, 3, 13, 5, hx('#6a6a78'))
    for (x, y) in [(5, 7), (10, 7)]: cv.ell(x, y, x + 2, y + 2, hx('#2a2a38'))
    cv.rect(16, 8, 29, 13, hx('#c8ccd8')); cv.rect(18, 10, 27, 12, hx('#8a96a8')); cv.rect(22, 5, 23, 9, hx('#8a8e9a'))
    for x in (3, 10, 17, 24): cv.rect(x, 17, x + 5, 28, hx('#b8864e')); cv.rect(x + 2, 22, x + 3, 23, hx('#e8e0d0'))
    cv.hline(1, 30, 30, WOOD_D)
    return cv.outline()


def table():
    cv = Cv(32, 24)
    cv.rect(1, 5, 30, 11, hx('#c8924e')); cv.rect(1, 5, 30, 6, hx('#e8b878')); cv.hline(1, 30, 11, hx('#8a5a2e'))
    cv.rect(3, 12, 5, 22, hx('#8a5a2e')); cv.rect(26, 12, 28, 22, hx('#8a5a2e'))
    cv.ell(11, 2, 16, 5, hx('#fff6e0')); cv.rect(19, 1, 22, 5, hx('#d84a3a'))
    return cv.outline()


def chair():
    cv = Cv(16, 20)
    cv.rect(4, 2, 11, 9, hx('#b8864e')); cv.rect(5, 3, 10, 8, hx('#c8924e')); cv.rect(3, 9, 12, 12, hx('#c8924e')); cv.rect(3, 9, 12, 9, hx('#e8b878'))
    cv.rect(3, 13, 4, 18, WOOD); cv.rect(11, 13, 12, 18, WOOD)
    return cv.outline()


def bookshelf():
    cv = Cv(32, 40)
    cv.rect(1, 2, 30, 38, hx('#8a5a2e')); cv.rect(3, 4, 28, 36, hx('#5a3a20'))
    for y0 in (4, 14, 24):
        cv.rect(3, y0 + 8, 28, y0 + 9, hx('#a8703a'))
        x = 4
        rng = random.Random('book%d' % y0)
        while x < 27:
            w = rng.randint(2, 3); h = rng.randint(5, 8)
            cv.rect(x, y0 + 8 - h, x + w - 1, y0 + 7, hx(rng.choice(['#c0524a', '#4a7ab0', '#e8b030', '#5aa045', '#8a5ac0', '#e8e0d0'])))
            x += w
    return cv.outline()


def rug():
    cv = Cv(48, 32)
    cv.rect(0, 0, 47, 31, hx('#b8433a')); cv.rect(2, 2, 45, 29, hx('#e8c27a')); cv.rect(4, 4, 43, 27, hx('#c8564a'))
    for x in range(8, 40, 6):
        cv.poly([(x, 16), (x + 3, 10), (x + 6, 16), (x + 3, 22)], hx('#f0d8a0'))
    cv.rect(0, 0, 47, 0, hx('#8a2a22')); cv.rect(0, 31, 47, 31, hx('#8a2a22'))
    return cv


def house_window():
    cv = Cv(16, 16)
    cv.rect(2, 2, 13, 13, hx('#8a5a2e')); cv.rect(3, 3, 12, 12, hx('#bfe6f4')); cv.vline(7, 3, 12, hx('#8a5a2e')); cv.vline(8, 3, 12, hx('#8a5a2e')); cv.hline(3, 12, 7, hx('#8a5a2e'))
    cv.px(4, 4, (255, 255, 255, 255)); cv.px(5, 4, (255, 255, 255, 255)); cv.rect(1, 13, 14, 14, hx('#c8924e'))
    return cv


def fireplace():
    cv = Cv(32, 32)
    cv.rect(1, 4, 30, 30, hx('#8e919c')); cv.rect(1, 2, 30, 6, hx('#b4b8c4')); cv.rect(6, 10, 25, 30, hx('#2a2530'))
    cv.poly([(10, 30), (16, 14), (22, 30)], hx('#ff9a2a')); cv.poly([(13, 30), (16, 19), (19, 30)], hx('#ffd84a'))
    cv.rect(3, 8, 5, 30, hx('#a2a6b1')); cv.rect(26, 8, 28, 30, hx('#a2a6b1'))
    return cv.outline()


def plant_pot():
    cv = Cv(16, 20)
    cv.rect(4, 11, 11, 18, hx('#c8664a')); cv.rect(3, 10, 12, 12, hx('#e0805a')); cv.hline(4, 11, 18, hx('#8a3a2a'))
    for (x, y, c) in [(8, 4, '#4a9a3a'), (5, 6, '#5ab04a'), (11, 6, '#5ab04a'), (8, 8, '#3a8a3a')]: cv.ell(x - 2, y - 2, x + 2, y + 2, hx(c))
    cv.px(5, 5, hx('#ff9ec0')); cv.px(11, 5, hx('#ffd23a'))
    return cv.outline()


def draw_objects(W):
    for s in SEASONS:
        W.add('o_tree_oak_' + s, oak(s), 16, 47)
        W.add('o_tree_pine_' + s, pine(s), 12, 39)
        W.add('o_bush_' + s, bush(s))
        W.add('o_weed_' + s, weed(s))
        W.add('o_tallgrass_' + s, weed(s, True))
        W.add('o_flowerbed_' + s, flowerbed(s))
        W.add('o_reeds_' + s, reeds(s), 8, 23)
    W.add('o_stump', stump()); W.add('o_log_big', log_big(), 16, 15)
    W.add('o_rock_s', rock('s')); W.add('o_rock_m', rock('m')); W.add('o_boulder', rock('boulder')); W.add('o_cave_rock', rock('cave'))
    W.add('o_ore_copper', ore('#6d6680', '#e8863a', name='cu')); W.add('o_ore_iron', ore('#6d6680', '#b8c4d4', name='fe'))
    W.add('o_ore_silver', ore('#6d6680', '#f2f6fc', name='ag')); W.add('o_ore_gold', ore('#6d6680', '#ffd23a', name='au'))
    W.add('o_ore_star', ore('#6d6680', '#b78cff', name='st')); W.add('o_coal_node', ore('#2a2a34', '#555566', coal=True, name='coal'))
    for nm, c1, c2 in [('quartz', '#e8eef4', '#ffffff'), ('amethyst', '#a45bd8', '#e8c8ff'), ('topaz', '#f2a63a', '#ffe8b0'), ('aqua', '#4ac8d8', '#c8fafc'), ('ruby', '#d8264a', '#ffb0c0'), ('moon', '#b8c8f0', '#ffffff')]:
        W.add('o_gem_' + nm, gem_cluster(c1, c2))
    W.add('o_crack_wall', crack_wall())
    W.add('o_twig', twig()); W.add('o_clay_spot', clay_spot()); W.add('o_signpost', signpost(), 8, 23)
    W.add('o_wisp', wisp(), 8, 8); W.add('o_wisp_shrine', shrine(), 16, 39)
    W.add('o_ladder', ladder()); W.add('o_hole', hole()); W.add('o_spikes', spikes(True)); W.add('o_spikes_off', spikes(False))
    W.add('o_treasure', treasure(False)); W.add('o_treasure_open', treasure(True))
    W.add('o_glow_crystal', glow_crystal(), 8, 23); W.add('o_torch', torch())
    for m in range(16): W.add('o_fence_%d' % m, fence(m))
    W.add('o_sprinkler', sprinkler(False)); W.add('o_sprinkler_q', sprinkler(True)); W.add('o_scarecrow', scarecrow(), 8, 23)
    for k, art in [('furnace', 'furnace'), ('press', 'press'), ('loom', 'loom'), ('jar_machine', 'jar_machine'), ('mayo', 'mayo'), ('seedmaker', 'seedmaker'), ('feeder', 'feeder'), ('basket', 'basket'), ('chest', 'chest'), ('lamp', 'lamp'), ('bin', 'bin')]:
        cv = machine(k)
        W.add('o_' + art, cv, cv.w / 2, cv.h - 1)
    W.add('o_lamp_post', lamp_post(), 8, 39); W.add('o_bench', bench()); W.add('o_barrel', barrel()); W.add('o_crate', crate()); W.add('o_haybale', haybale())
    W.add('o_well', well(), 8, 31); W.add('o_fountain', fountain(), 16, 39); W.add('o_mailbox', mailbox(), 8, 23)
    W.add('o_noticeboard', noticeboard(), 16, 31); W.add('o_great_lantern', great_lantern(), 16, 55); W.add('o_stall', stall(), 16, 31)
    W.add('o_bunting', bunting(), 0, 0); W.add('o_lantern_string', lantern_string(), 0, 0)
    W.add('o_pier_post', pier_post(), 8, 23); W.add('o_boat', boat(), 16, 19); W.add('o_driftlog', driftlog(), 16, 15); W.add('o_lilypad', lilypad())
    W.add('o_bed', bed(), 16, 39); W.add('o_kitchen', kitchen(), 16, 31); W.add('o_table', table(), 16, 23); W.add('o_chair', chair(), 8, 19)
    W.add('o_bookshelf', bookshelf(), 16, 39); W.add('o_rug', rug(), 0, 0); W.add('o_house_window', house_window())
    W.add('o_fireplace', fireplace(), 16, 31); W.add('o_plant_pot', plant_pot(), 8, 19)


def crack_wall():
    cv = rock('cave')
    for (a, b) in [((8, 4), (7, 8)), ((7, 8), (10, 11)), ((7, 8), (4, 10))]: cv.line(*a, *b, hx('#1a1624'))
    cv.px(8, 5, hx('#8f88a6'))
    return cv
