"""Procedurally authored village maps written to assets/maps/*.map (plain text, hand-editable)."""
import os, random
from .common import *

OBJDEFS = {}


def load_objdefs():
    for r in load_data('objects.cfd'):
        if r['_type'] == 'obj':
            OBJDEFS[r['id']] = (int(r.get('fw', 1)), int(r.get('fh', 1)), r.get('solid', '0') == '1', r.get('kind', ''))


BLD = {'farmhouse': (5, 4), 'barn': (5, 4), 'coop': (4, 3), 'general_store': (5, 4), 'workshop': (5, 4), 'lantern_hall': (6, 5), 'ranch_house': (4, 4),
       'fisher_hut': (3, 3), 'herb_hut': (3, 3), 'cottage_a': (3, 3), 'cottage_b': (3, 3), 'mine_entrance': (4, 3)}
WALK = set('GDPSFTCB')


class MapB:
    def __init__(s, name, w, h, fill='G', **props):
        s.name, s.w, s.h = name, w, h
        s.t = [[fill] * w for _ in range(h)]
        s.objs, s.blds, s.pts, s.warps, s.regs = [], [], [], [], []
        s.props = props
        s.occ = set()
        s.rng = random.Random('map' + name)

    # ---- terrain
    def set(s, x, y, c):
        if 0 <= x < s.w and 0 <= y < s.h: s.t[y][x] = c

    def get(s, x, y):
        return s.t[y][x] if 0 <= x < s.w and 0 <= y < s.h else '.'

    def rect(s, c, x, y, w, h):
        for yy in range(y, y + h):
            for xx in range(x, x + w): s.set(xx, yy, c)

    def disk(s, c, cx, cy, rx, ry, jitter=0.0):
        for yy in range(int(cy - ry - 2), int(cy + ry + 3)):
            for xx in range(int(cx - rx - 2), int(cx + rx + 3)):
                d = ((xx - cx) / rx) ** 2 + ((yy - cy) / ry) ** 2
                if d <= 1.0 + (s.rng.uniform(-jitter, jitter) if jitter else 0): s.set(xx, yy, c)

    def road(s, c, pts, width=2):
        for (x0, y0), (x1, y1) in zip(pts, pts[1:]):
            if x0 == x1:
                for y in range(min(y0, y1), max(y0, y1) + 1): s.rect(c, x0 - width // 2, y, width, 1)
            else:
                for x in range(min(x0, x1), max(x0, x1) + 1): s.rect(c, x, y0 - width // 2, 1, width)

    # ---- objects
    def free(s, x, y, fw=1, fh=1):
        for yy in range(y - fh + 1, y + 1):
            for xx in range(x, x + fw):
                if not (0 <= xx < s.w and 0 <= yy < s.h) or (xx, yy) in s.occ: return False
        return True

    def obj(s, oid, x, y, force=False, solid_override=None):
        fw, fh, solid, kind = OBJDEFS[oid]
        if not force and not s.free(x, y, fw, fh): return False
        s.objs.append((oid, x, y))
        if solid if solid_override is None else solid_override:
            for yy in range(y - fh + 1, y + 1):
                for xx in range(x, x + fw): s.occ.add((xx, yy))
        return True

    def building(s, bid, x, y, level=1):
        w, h = BLD[bid]
        s.blds.append((bid, x, y, level))
        for yy in range(y - h + 1, y + 1):
            for xx in range(x, x + w): s.occ.add((xx, yy))
        return w, h

    def block(s, x, y, w, h):
        for yy in range(y, y + h):
            for xx in range(x, x + w): s.occ.add((xx, yy))

    def point(s, name, x, y, d='d'): s.pts.append((name, x, y, d))
    def warp(s, x, y, w, h, to, tp): s.warps.append((x, y, w, h, to, tp))
    def region(s, name, x, y, w, h, **kv): s.regs.append((name, x, y, w, h, kv))

    def scatter(s, ids, count, rect, terrain='G', weights=None, margin=0, avoid_pts=()):
        x0, y0, w, h = rect
        placed = 0; tries = 0
        while placed < count and tries < count * 40:
            tries += 1
            x, y = s.rng.randint(x0, x0 + w - 1), s.rng.randint(y0, y0 + h - 1)
            if s.get(x, y) not in terrain: continue
            if any(abs(x - px) <= margin and abs(y - py) <= margin for px, py in avoid_pts): continue
            oid = s.rng.choices(ids, weights)[0] if weights else s.rng.choice(ids)
            if s.obj(oid, x, y): placed += 1
        return placed

    def trees(s, x, y, w, h, density, terrain='G'):
        n = 0
        for yy in range(y, y + h):
            for xx in range(x, x + w):
                if s.get(xx, yy) in terrain and s.rng.random() < density:
                    r = s.rng.random()
                    if s.obj('tree_oak' if r < 0.5 else ('tree_pine' if r < 0.88 else 'bush'), xx, yy): n += 1
        return n

    def save(s, directory):
        with open(os.path.join(directory, s.name + '.map'), 'w') as f:
            f.write('map %s %d %d\n' % (s.name, s.w, s.h))
            for k, v in s.props.items(): f.write('prop %s %s\n' % (k, v))
            f.write('terrain\n')
            for row in s.t: f.write(''.join(row) + '\n')
            for (o, x, y) in s.objs: f.write('obj %s %d %d\n' % (o, x, y))
            for (b, x, y, lv) in s.blds: f.write('building %s %d %d %d\n' % (b, x, y, lv))
            for (n, x, y, d) in s.pts: f.write('point %s %d %d %s\n' % (n, x, y, d))
            for (x, y, w, h, to, tp) in s.warps: f.write('warp %d %d %d %d %s %s\n' % (x, y, w, h, to, tp))
            for (n, x, y, w, h, kv) in s.regs: f.write('region %s %d %d %d %d %s\n' % (n, x, y, w, h, ' '.join('%s=%s' % kv_ for kv_ in kv.items())))
            f.write('end\n')


def border_trees(m, thick, gaps):
    """Dense tree/rock border, with gaps (list of (x,y,w,h)) kept open for exits."""
    def in_gap(x, y): return any(gx <= x < gx + gw and gy <= y < gy + gh for gx, gy, gw, gh in gaps)
    for y in range(m.h):
        for x in range(m.w):
            d = min(x, y, m.w - 1 - x, m.h - 1 - y)
            if d < thick and not in_gap(x, y) and m.get(x, y) in 'GD':
                p = 0.95 if d == 0 else (0.8 if d == 1 else 0.55)
                if m.rng.random() < p: m.obj('tree_oak' if (x + y) % 3 else 'tree_pine', x, y)


def farm():
    m = MapB('farm', 48, 36, title='"Brightbrook Farm"', music='farm', tillable=1, forage=8, outdoors=1, weedspawn=1)
    m.rect('D', 7, 12, 1, 1)
    m.road('D', [(7, 13), (7, 17), (47, 17)], 2)       # lane from house to the village road
    m.road('D', [(23, 17), (23, 0)], 2)                # lane north to the forest
    m.rect('D', 12, 5, 0, 0)
    m.disk('W', 17, 27, 3.5, 2.5, 0.1)                 # farm pond
    m.disk('S', 17, 27, 5.0, 4.0, 0.12)
    m.disk('W', 17, 27, 3.2, 2.2, 0.1)
    # buildings
    m.building('farmhouse', 5, 11, 1); m.building('barn', 30, 9, 1); m.building('coop', 36, 9, 1)
    m.point('farmhouse_door', 7, 12); m.point('barn_door', 32, 10); m.point('coop_door', 37, 10); m.point('from_house', 7, 12)
    m.warp(7, 11, 1, 1, 'house', 'door')
    m.obj('bin', 10, 12); m.point('bin', 10, 12)
    m.obj('mailbox', 4, 13); m.obj('signpost', 24, 16)
    # pasture fence
    for x in range(28, 44):
        if x not in (32, 37): m.obj('fence', x, 10)
        m.obj('fence', x, 18)
    for y in range(11, 18): m.obj('fence', 28, y); m.obj('fence', 43, y)
    m.region('pasture', 29, 11, 14, 7)
    m.region('field', 9, 13, 19, 14, tillable=1)
    m.region('pond', 12, 24, 11, 7, water='pond')
    m.point('spawn', 7, 13)
    m.point('from_village', 46, 17); m.point('from_forest', 23, 2)
    m.warp(47, 15, 1, 4, 'village', 'from_farm')
    m.warp(22, 0, 3, 1, 'forest', 'from_farm')
    border_trees(m, 3, [(45, 14, 3, 6), (21, 0, 5, 4)])
    # starter-clear patch + debris elsewhere
    clear = [(x, y) for x in range(11, 18) for y in range(14, 19)]
    for (x, y) in clear: m.occ.add((x, y))
    m.scatter(['rock_small', 'weed', 'weed', 'twig', 'tallgrass', 'tallgrass'], 80, (9, 13, 19, 14), terrain='GD', margin=0)
    m.scatter(['tree_oak', 'tree_pine', 'stump', 'rock_med', 'bush'], 24, (3, 3, 42, 30), terrain='G')
    m.scatter(['boulder'], 2, (19, 20, 8, 8), terrain='G')
    m.scatter(['tallgrass'], 26, (29, 11, 14, 7), terrain='G')
    for (x, y) in clear: m.occ.discard((x, y))
    m.obj('log_big', 38, 30); m.obj('clay_spot', 13, 30)
    m.obj('well', 12, 11) if False else None
    m.occ -= set()
    return m


def house(level):
    w, h = 12 + 2 * (level - 1), 10
    m = MapB('house_%d' % level, w, h, fill='F', title='"Your Farmhouse"', music='home', indoor=1)
    m.rect('L', 0, 0, w, 1); m.rect('L', 0, 1, w, 1)
    for x in range(w): m.set(x, 0, 'L'); m.set(x, 1, 'L')
    m.rect('V', 0, 0, 0, 0)
    m.obj('bed', 2, 4); m.point('bed', 2, 5); m.point('bedside', 4, 5)
    m.obj('kitchen', w - 5, 2); m.point('kitchen', w - 5, 3)
    m.obj('fireplace', 6, 2)
    m.obj('table', 5 if level == 1 else 6, 6); m.obj('chair', 4 if level == 1 else 5, 7); m.obj('chair', 8 if level == 1 else 9, 7)
    m.obj('rug', 4, 9, force=True, solid_override=False)
    m.obj('house_chest', w - 3, 4); m.point('storage', w - 3, 5)
    m.obj('bookshelf', 9 if level == 1 else 11, 3) if level >= 2 else None
    m.obj('plant_pot', 1, 3) if level >= 2 else None
    if level >= 3: m.obj('plant_pot', w - 2, 9); m.obj('bookshelf', 13 if w > 14 else 12, 3) if w > 14 else None
    for x in (3, 8 if w < 14 else 9): m.obj('house_window', x, 1, force=True, solid_override=False)
    dx = w // 2
    m.point('door', dx, h - 2); m.point('spawn', 3, 5)
    m.warp(dx, h - 1, 1, 1, 'farm', 'farmhouse_door')
    m.rect('F', dx, h - 1, 1, 1)
    m.region('indoors', 0, 2, w, h - 2)
    return m


def village():
    m = MapB('village', 56, 40, title='"Thistledown"', music='village', forage=7, outdoors=1)
    # mountain (NE) + cliffs
    m.rect('R', 40, 0, 16, 9)
    m.disk('R', 52, 6, 8, 7, 0.12)
    for y in range(0, 9):
        for x in range(36, 56):
            if m.get(x, y) == 'R' and y < 8 and x > 40 + y // 2: pass
    m.rect('R', 36, 0, 4, 4)
    # roads
    m.road('P', [(0, 19), (22, 19)], 2)
    m.road('P', [(34, 19), (46, 19)], 2)
    m.road('P', [(46, 19), (46, 10)], 2)
    m.road('P', [(27, 0), (27, 14)], 3)
    m.road('P', [(27, 25), (27, 39)], 3)
    m.rect('P', 20, 13, 16, 12)                     # plaza
    m.rect('P', 6, 13, 24, 1); m.rect('P', 9, 13, 3, 1)
    for bx in (10, 16): m.rect('P', bx - 1, 13, 3, 2)
    m.rect('P', 39 - 1, 12, 3, 3); m.rect('P', 38, 13, 1, 1)
    m.rect('P', 6, 32, 3, 3); m.road('P', [(7, 32), (7, 21)], 1); m.road('P', [(7, 21), (20, 21)], 1)
    m.rect('P', 15, 32, 1, 1)
    m.road('D', [(47, 10), (47, 11)], 2)
    # buildings
    m.building('general_store', 8, 12, 1)       # x8..12 rows 9..12   door tile (10,12)
    m.building('workshop', 14, 12, 1)           # x14..18             door (16,12)
    m.building('lantern_hall', 36, 11, 1)       # x36..41 rows 7..11  door (39,11)
    m.building('ranch_house', 6, 31, 1)         # x6..9 rows 28..31   door (7,31)
    m.building('cottage_a', 14, 31, 1)          # door (15,31)
    m.building('cottage_b', 42, 33, 1)
    m.building('mine_entrance', 45, 9, 1)       # x45..48 rows 7..9   door cols 46,47
    for nm, (dx, dy) in {'general': (10, 13), 'workshop': (16, 13), 'lantern': (39, 12), 'ranch': (7, 32)}.items():
        m.point(nm + '_door', dx, dy)
    m.point('general_post', 10, 15); m.point('workshop_post', 16, 15); m.point('lantern_post', 39, 14); m.point('ranch_post', 7, 34)
    m.warp(46, 9, 2, 1, 'mine_1', 'start')
    # plaza furniture
    m.obj('great_lantern', 27, 18); m.point('lantern_spot', 27, 20); m.point('lantern_front', 28, 20)
    m.obj('fountain', 31, 23); m.point('fountain_spot', 30, 24)
    m.obj('noticeboard', 22, 15); m.point('notice_spot', 23, 16)
    m.obj('bench', 22, 22); m.obj('bench', 33, 15); m.point('bench_a', 23, 23); m.point('bench_b', 34, 16)
    m.obj('stall', 33, 20); m.obj('stall', 22, 18) if False else None
    m.point('stall_spot', 34, 22)
    for (x, y) in [(20, 14), (35, 14), (20, 24), (35, 24), (6, 18), (6, 22), (44, 18), (44, 21)]: m.obj('lamp_post', x, y)
    for (x, y) in [(12, 14), (13, 14), (18, 14), (19, 14)]: m.obj('flowerbed', x, y)
    m.obj('well', 18, 24); m.point('well_spot', 17, 25)
    m.obj('barrel', 7, 12); m.obj('crate', 13, 12) if False else None
    m.obj('haybale', 10, 33); m.obj('haybale', 11, 33); m.obj('mailbox', 12, 15)
    m.obj('signpost', 25, 38)
    for (x, y, nm) in [(34, 12, 'fest_a'), (24, 12, 'fest_b'), (30, 17, 'fest_c'), (25, 23, 'fest_d'), (29, 21, 'fest_host')]: m.point(nm, x, y)
    m.point('from_farm', 1, 19); m.point('from_forest', 27, 2); m.point('from_shore', 27, 38); m.point('from_mine', 46, 11)
    m.warp(0, 18, 1, 4, 'farm', 'from_village')
    m.warp(26, 0, 4, 1, 'forest', 'from_village')
    m.warp(26, 39, 4, 1, 'shore', 'from_village')
    m.region('plaza', 20, 13, 16, 12)
    border_trees(m, 3, [(0, 17, 4, 6), (25, 0, 6, 4), (25, 36, 6, 4)])
    m.scatter(['tree_oak', 'tree_pine', 'bush', 'bush'], 36, (2, 2, 52, 36), terrain='G', margin=0)
    m.scatter(['flowerbed', 'bush', 'bench'], 6, (2, 26, 20, 11), terrain='G')
    return m


def forest():
    m = MapB('forest', 52, 40, title='"Hollowood Forest"', music='forest', forage=16, outdoors=1)
    m.road('D', [(27, 39), (27, 30), (14, 30), (11, 22)], 2)
    m.road('D', [(5, 39), (5, 36), (14, 33)], 2)
    m.road('D', [(27, 30), (40, 24), (47, 12), (47, 6)], 2)
    m.rect('D', 8, 17, 9, 5)
    m.disk('W', 36, 13, 5.0, 3.5, 0.1); m.disk('W', 36, 13, 3.4, 2.2, 0.1)
    m.building('herb_hut', 10, 17, 1)
    m.point('herb_door', 11, 18); m.point('herb_post', 11, 19); m.point('herb_garden', 14, 20)
    m.point('from_village', 27, 38); m.point('from_farm', 5, 38); m.point('pond_edge', 33, 16); m.point('glade', 22, 14); m.point('grove_gate', 47, 8)
    m.warp(26, 39, 4, 1, 'village', 'from_forest')
    m.warp(4, 39, 3, 1, 'farm', 'from_forest')
    m.region('pond', 30, 9, 13, 9, water='pond')
    m.region('woods', 2, 2, 46, 34)
    m.region('glade', 18, 10, 9, 8)
    m.point('wisp_1', 4, 6); m.point('wisp_2', 44, 33); m.point('wisp_3', 21, 5)
    border_trees(m, 3, [(25, 37, 6, 3), (3, 37, 5, 3)])
    # large log hides the path to the hidden grove
    m.rect('D', 46, 3, 2, 9)
    m.obj('log_big', 47, 6); m.obj('signpost', 45, 10)
    m.warp(50, 3, 1, 5, 'grove', 'from_forest')
    m.rect('D', 48, 3, 4, 3)
    m.block(46, 6, 2, 1)
    m.trees(3, 3, 46, 34, 0.30)
    m.scatter(['bush', 'rock_small', 'stump', 'twig', 'weed', 'tallgrass'], 70, (3, 3, 46, 34), terrain='G')
    m.scatter(['flowerbed'], 3, (18, 10, 9, 8), terrain='G')
    m.obj('stump', 24, 16); m.obj('bench', 24, 20)
    return m


def shore():
    m = MapB('shore', 56, 36, title='"Marlowe Shore"', music='shore', forage=12, outdoors=1)
    m.rect('S', 0, 22, 56, 14)
    for x in range(56):
        edge = 21 + int(1.5 * (1 + __import__('math').sin(x / 4.0)))
        m.rect('S', x, edge, 1, 2)
    m.rect('O', 0, 31, 56, 5)
    for x in range(56):
        m.rect('W', x, 30 + (1 if x % 7 < 3 else 0), 1, 1)
    m.disk('W', 14, 14, 11, 6, 0.08); m.disk('O', 14, 14, 7, 3.5, 0.08)
    m.disk('S', 14, 14, 13, 8, 0.0) if False else None
    for y in range(6, 24):
        for x in range(0, 30):
            if m.get(x, y) == 'W' and any(m.get(x + dx, y + dy) == 'G' for dx in (-1, 0, 1) for dy in (-1, 0, 1)):
                pass
    m.road('P', [(27, 0), (27, 10)], 3)
    m.road('P', [(27, 10), (27, 24)], 2)
    m.road('D', [(33, 10), (28, 10)], 1)
    m.rect('B', 36, 24, 2, 8)                              # pier into the ocean
    m.building('fisher_hut', 32, 10, 1)
    m.point('fisher_door', 33, 11); m.point('fisher_post', 33, 13); m.point('lake_dock', 24, 14); m.point('pier_end', 36, 31); m.point('pier_mid', 36, 27)
    m.point('beach_a', 20, 26); m.point('beach_b', 46, 27); m.point('from_village', 27, 2)
    m.warp(26, 0, 4, 1, 'village', 'from_shore')
    m.region('lake', 3, 7, 23, 15, water='lake')
    m.region('ocean', 0, 30, 56, 6, water='ocean')
    m.region('beach', 0, 22, 56, 8)
    border_trees(m, 2, [(25, 0, 6, 3)])
    m.scatter(['tree_oak', 'tree_pine', 'bush', 'reeds', 'tallgrass'], 40, (2, 2, 52, 22), terrain='G')
    m.scatter(['rock_small', 'driftlog'], 9, (2, 23, 52, 6), terrain='S')
    m.obj('boat', 44, 29); m.obj('pier_post', 35, 25); m.obj('pier_post', 38, 25); m.obj('pier_post', 35, 30); m.obj('pier_post', 38, 30)
    m.obj('bench', 30, 14); m.obj('lamp_post', 26, 12); m.obj('lamp_post', 30, 24)
    return m


def grove():
    m = MapB('grove', 24, 20, title='"The Hidden Grove"', music='grove', outdoors=1)
    m.disk('P', 12, 10, 6, 4.5, 0.1)
    m.road('D', [(0, 8), (12, 8)], 2)
    m.obj('wisp_shrine', 12, 9); m.point('shrine_spot', 12, 11)
    m.point('from_forest', 2, 8); m.warp(0, 6, 1, 4, 'forest', 'grove_gate')
    border_trees(m, 3, [(0, 6, 3, 4)])
    m.scatter(['flowerbed', 'bush'], 12, (3, 3, 18, 14), terrain='G', margin=0)
    m.obj('lamp_post', 9, 7); m.obj('lamp_post', 15, 7)
    return m


def write_all(outdir):
    load_objdefs()
    os.makedirs(outdir, exist_ok=True)
    for f in (farm(), village(), forest(), shore(), grove(), house(1), house(2), house(3)):
        f.save(outdir)
