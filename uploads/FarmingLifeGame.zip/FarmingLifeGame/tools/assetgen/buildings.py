"""Building sprites (front-facing, bottom-left anchored). Names b_<id>[_<level>]."""
import random
from PIL import Image, ImageDraw
from .common import *


def shingles(w, h, c1, c2, seed, pattern=3):
    cv = Cv(w, h)
    rng = random.Random(seed)
    a, b = hx(c1), hx(c2)
    for y in range(h):
        row = y // pattern
        base = a if row % 2 == 0 else shade(a, 0.93)
        cv.hline(0, w - 1, y, base)
        if y % pattern == pattern - 1:
            cv.hline(0, w - 1, y, b)
        else:
            off = (row % 2) * 3
            for x in range(off, w, 6):
                cv.px(x, y, b)
    for _ in range(w * h // 40):
        cv.px(rng.randint(0, w - 1), rng.randint(0, h - 1), light(a, .25))
    return cv


def clapboard(w, h, c1, c2, seed):
    cv = Cv(w, h)
    a, b = hx(c1), hx(c2)
    for y in range(h):
        band = y // 4
        cv.hline(0, w - 1, y, a if band % 2 == 0 else shade(a, .96))
        if y % 4 == 3: cv.hline(0, w - 1, y, b)
        if y % 4 == 0: cv.hline(0, w - 1, y, light(a, .12))
    return cv


def stone_base(w, h, seed):
    cv = Cv(w, h)
    rng = random.Random(seed)
    cv.rect(0, 0, w - 1, h - 1, hx('#7a7e8a'))
    x = 0
    while x < w:
        sw = rng.randint(4, 8)
        x0, x1 = x + 1, min(w - 1, x + sw - 1)
        if x1 >= x0 and h >= 2:
            cv.rect(x0, 0, x1, h - 2, hx('#9a9eaa') if rng.random() < .5 else hx('#8e929e'))
            cv.hline(x0, x1, 0, hx('#b4b8c4'))
        x += sw
    return cv


def paste_masked(dst, tex, mask_poly):
    mask = Image.new('L', (dst.w, dst.h), 0)
    ImageDraw.Draw(mask).polygon(mask_poly, fill=255)
    dst.im.paste(tex.im, (0, 0), mask)


def window(cv, x, y, trim, shutter=None, box=None, w=12, h=12, glow=False):
    t = hx(trim)
    cv.rect(x - 1, y - 1, x + w, y + h, t)
    cv.rect(x, y, x + w - 1, y + h - 1, hx('#7ab8d8'))
    cv.rect(x, y, x + w - 1, y + 2, hx('#a8dcf0'))
    cv.vline(x + w // 2, y, y + h - 1, t); cv.hline(x, x + w - 1, y + h // 2, t)
    cv.px(x + 1, y + 1, (255, 255, 255, 255)); cv.px(x + 2, y + 1, (255, 255, 255, 255))
    if glow: cv.rect(x, y, x + w - 1, y + h - 1, hx('#ffe08a'))
    if shutter:
        s = hx(shutter)
        cv.rect(x - 4, y - 1, x - 2, y + h, s); cv.rect(x + w + 2, y - 1, x + w + 4, y + h, s)
        for k in range(1, h, 3): cv.hline(x - 4, x - 2, y + k, shade(s, .8)); cv.hline(x + w + 2, x + w + 4, y + k, shade(s, .8))
    if box:
        cv.rect(x - 2, y + h + 1, x + w + 1, y + h + 3, hx('#8a5a2e')); cv.hline(x - 2, x + w + 1, y + h + 1, hx('#c28f56'))
        rng = random.Random(x * 7 + y)
        for i in range(x - 1, x + w + 1, 2):
            cv.px(i, y + h, hx(rng.choice(['#ff7a9a', '#ffd23a', '#fff0f4', '#c070ff']))); cv.px(i, y + h - 1, hx('#4a9a3a')) if i % 4 == 0 else None


def door_at(cv, col, H, w=14, hgt=24, dcol='#8a4a2a', trim='#fff4e0', arch=False, double=False):
    x0 = col * 16 + 1
    y0 = H - hgt
    t = hx(trim); d = hx(dcol)
    cv.rect(x0 - 1, y0 - 2, x0 + w, H - 1, t)
    cv.rect(x0, y0, x0 + w - 1, H - 1, d)
    cv.rect(x0 + 2, y0 + 2, x0 + w // 2 - 1, y0 + hgt // 2 - 2, shade(d, .82)); cv.rect(x0 + w // 2 + 1, y0 + 2, x0 + w - 3, y0 + hgt // 2 - 2, shade(d, .82))
    cv.rect(x0 + 2, y0 + hgt // 2 + 1, x0 + w // 2 - 1, H - 3, shade(d, .88)); cv.rect(x0 + w // 2 + 1, y0 + hgt // 2 + 1, x0 + w - 3, H - 3, shade(d, .88))
    cv.vline(x0 + w // 2, y0, H - 1, shade(d, .6))
    cv.px(x0 + w // 2 - 2, y0 + hgt // 2, hx('#ffd23a')); cv.px(x0 + w // 2 + 2, y0 + hgt // 2, hx('#ffd23a'))
    cv.hline(x0 - 2, x0 + w + 1, H - 1, hx('#b4b8c4'))


def house(wt, ht, wall=('#e6d2a4', '#cdb27c'), roof=('#b8503a', '#8a3a2a'), trim='#fff4e0', door='#8a4a2a', doorcol=1,
          win=True, shutters=None, flowerbox=True, chimney=True, awning=None, sign=None, base=True, lantern=True,
          roof_extra=12, ridge=0.2, seed='h', attic=False, porch=False, extra=None, tall_roof=0):
    W = wt * 16
    H = ht * 16 + roof_extra
    cv = Cv(W, H)
    roofH = int(ht * 16 * 0.48) + roof_extra + tall_roof
    wy = roofH - 4
    wallcv = clapboard(W - 4, H - wy, wall[0], wall[1], seed)
    cv.paste(wallcv, 2, wy)
    if base:
        sb = stone_base(W - 4, 5, seed + 'b'); cv.paste(sb, 2, H - 5)
    cv.rect(2, wy, 3, H - 1, hx(trim)); cv.rect(W - 4, wy, W - 3, H - 1, hx(trim))
    if chimney:
        cx = int(W * 0.66)
        cv.rect(cx, 1, cx + 7, roofH - 3, hx('#a8503a')); cv.rect(cx - 1, 0, cx + 8, 2, hx('#c8684a'))
        for y in range(4, roofH - 3, 4): cv.hline(cx, cx + 7, y, hx('#7a3a28'))
    inset = int(W * ridge)
    poly = [(0, roofH + 1), (W - 1, roofH + 1), (W - 1 - inset, roof_extra - 8 + 2), (inset, roof_extra - 8 + 2)]
    tex = shingles(W, H, roof[0], roof[1], seed + 'r')
    paste_masked(cv, tex, poly)
    cv.hline(0, W - 1, roofH + 1, hx(roof[1])); cv.hline(0, W - 1, roofH + 2, shade(hx(wall[1]), .6)); cv.hline(1, W - 2, roofH + 3, shade(hx(wall[1]), .8))
    cv.hline(inset, W - 1 - inset, roof_extra - 6, light(hx(roof[0]), .35))
    for i in range(0, 6):
        cv.px(i, roofH - i, light(hx(roof[0]), .3)) if False else None
    if awning:
        a1, a2 = hx(awning[0]), hx(awning[1])
        for i in range(wt * 4):
            cv.rect(2 + i * 4, wy + 2, 2 + i * 4 + 3, wy + 9, a1 if i % 2 == 0 else a2)
        cv.hline(2, W - 3, wy + 9, shade(a1, .7)); cv.hline(2, W - 3, wy + 2, light(a1, .3))
        for i in range(wt * 4): cv.px(3 + i * 4, wy + 10, a1 if i % 2 == 0 else a2)
    door_at(cv, doorcol, H, dcol=door, trim=trim)
    if win:
        for col in range(wt):
            if col == doorcol or (porch and abs(col - doorcol) == 0): continue
            if wt >= 5 and col in (1, 3) and doorcol == 2: continue
            window(cv, col * 16 + 2, wy + (12 if awning else 7), trim, shutter=shutters, box=flowerbox and not awning)
    if lantern:
        lx = doorcol * 16 + 16 + 3 if doorcol < wt - 1 else doorcol * 16 - 3
        cv.rect(lx, H - 24, lx + 2, H - 20, hx('#ffe08a')); cv.px(lx + 1, H - 25, hx('#3a3a48')); cv.px(lx + 1, H - 19, hx('#3a3a48'))
    if sign:
        draw_sign(cv, sign, doorcol * 16 + 8, wy + 14 if not awning else wy + 11)
    if attic:
        cv.ell(W // 2 - 4, roof_extra - 4 + 4, W // 2 + 3, roof_extra + 5 + 4, hx(trim)); cv.ell(W // 2 - 3, roof_extra - 3 + 4, W // 2 + 2, roof_extra + 4 + 4, hx('#7ab8d8'))
    if porch:
        cv.rect(doorcol * 16 - 6, wy + 4, doorcol * 16 + 22, wy + 6, hx('#a8703a')); cv.hline(doorcol * 16 - 6, doorcol * 16 + 22, wy + 4, hx('#d09a58'))
        cv.rect(doorcol * 16 - 6, wy + 6, doorcol * 16 - 5, H - 3, hx('#c28f56')); cv.rect(doorcol * 16 + 21, wy + 6, doorcol * 16 + 22, H - 3, hx('#c28f56'))
    if extra: extra(cv, W, H, roofH, wy)
    cv.outline()
    return cv


def draw_sign(cv, kind, cx, y):
    cv.rect(cx - 7, y - 1, cx + 7, y + 9, hx('#6a4526')); cv.rect(cx - 6, y, cx + 6, y + 8, hx('#e8d4a0'))
    if kind == 'coin':
        cv.ell(cx - 3, y + 1, cx + 3, y + 7, hx('#d8a82a')); cv.ell(cx - 2, y + 2, cx + 2, y + 6, hx('#ffd23a'))
    elif kind == 'anvil':
        cv.rect(cx - 4, y + 2, cx + 4, y + 4, hx('#4a4a58')); cv.rect(cx - 2, y + 5, cx + 2, y + 7, hx('#3a3a48')); cv.px(cx + 5, y + 3, hx('#4a4a58'))
    elif kind == 'leaf':
        cv.ell(cx - 4, y + 1, cx + 4, y + 7, hx('#5ab04a')); cv.line(cx - 3, y + 6, cx + 3, y + 2, hx('#2a7a2e'))
    elif kind == 'fish':
        cv.ell(cx - 4, y + 2, cx + 3, y + 6, hx('#4a86c6')); cv.poly([(cx + 3, y + 4), (cx + 6, y + 1), (cx + 6, y + 7)], hx('#4a86c6')); cv.px(cx - 2, y + 3, (255, 255, 255, 255))
    elif kind == 'cow':
        cv.rect(cx - 4, y + 2, cx + 3, y + 5, hx('#f4f1ea')); cv.rect(cx - 2, y + 3, cx, y + 4, hx('#3a3640')); cv.vline(cx - 3, y + 5, y + 7, hx('#3a3640')); cv.vline(cx + 2, y + 5, y + 7, hx('#3a3640'))
    elif kind == 'lantern':
        cv.rect(cx - 2, y + 1, cx + 2, y + 7, hx('#ffd23a')); cv.rect(cx - 1, y + 2, cx + 1, y + 6, hx('#fff6c8')); cv.hline(cx - 3, cx + 3, y, hx('#3a3a48'))


def barn(level):
    W, H = 80, 76
    cv = Cv(W, H)
    wall1, wall2 = ('#b8412e', '#8a2e22') if level < 3 else ('#c04a34', '#8a2e22')
    cv.paste(clapboard(W - 4, 44, wall1, wall2, 'barn'), 2, 32)
    roofc = ('#6e6a78', '#4a4658') if level < 3 else ('#5a7088', '#3e5068')
    poly = [(0, 36), (W - 1, 36), (W - 12, 8), (12, 8)]
    paste_masked(cv, shingles(W, H, roofc[0], roofc[1], 'barnroof'), poly)
    cv.poly([(W - 1, 36), (W - 12, 8), (W - 12, 8), (W - 1, 36)], hx(roofc[1]))
    cv.hline(0, W - 1, 36, hx(roofc[1])); cv.hline(12, W - 13, 7, light(hx(roofc[0]), .4)); cv.hline(1, W - 2, 38, shade(hx(wall2), .7))
    cv.rect(2, 32, 3, H - 1, hx('#fff4e0')); cv.rect(W - 4, 32, W - 3, H - 1, hx('#fff4e0'))
    # hayloft
    cv.rect(31, 40, 48, 52, hx('#fff4e0')); cv.rect(33, 42, 46, 52, hx('#3a2a22')); cv.rect(33, 42, 46, 43, hx('#e0c060')); cv.line(33, 42, 46, 52, hx('#fff4e0')); cv.line(46, 42, 33, 52, hx('#fff4e0'))
    # big doors
    cv.rect(23, 52, 56, H - 1, hx('#fff4e0')); cv.rect(25, 54, 54, H - 1, hx('#8a2e22'))
    cv.vline(39, 54, H - 1, hx('#fff4e0')); cv.vline(40, 54, H - 1, hx('#fff4e0'))
    cv.line(26, 55, 38, H - 2, hx('#fff4e0')); cv.line(38, 55, 26, H - 2, hx('#fff4e0')); cv.line(41, 55, 53, H - 2, hx('#fff4e0')); cv.line(53, 55, 41, H - 2, hx('#fff4e0'))
    cv.rect(2, H - 5, W - 3, H - 1, hx('#7a7e8a'))
    cv.rect(23, H - 2, 56, H - 1, hx('#b4b8c4'))
    window(cv, 8, 46, '#fff4e0', w=8, h=8); window(cv, 64, 46, '#fff4e0', w=8, h=8)
    if level >= 2:
        cv.rect(66, 4, 78, 40, hx('#c8ccd8')); cv.rect(66, 4, 70, 40, hx('#e8ecf4')); cv.rect(74, 4, 78, 40, hx('#9a9eaa'))
        cv.ell(65, 0, 79, 8, hx('#9a9eaa')); cv.ell(66, 1, 78, 6, hx('#c8ccd8'))
        for y in range(10, 40, 6): cv.hline(66, 78, y, hx('#8a8e9a'))
    if level >= 3:
        cv.line(40, 8, 40, 0, hx('#3a3a48')); cv.rect(37, 1, 43, 2, hx('#ffd23a')); cv.poly([(40, 0), (46, 2), (40, 3)], hx('#ffd23a'))
        cv.rect(10, 26, 20, 30, hx('#7ab8d8')) if False else None
    cv.outline()
    return cv


def coop(level):
    W, H = 64, 60
    cv = Cv(W, H)
    wc = ('#c8924e', '#a8703a') if level == 1 else (('#d8a860', '#b88848') if level == 2 else ('#e8d8b8', '#c8b088'))
    cv.paste(clapboard(W - 4, 30, wc[0], wc[1], 'coop'), 2, 30)
    rc = ('#b8503a', '#8a3a2a') if level < 3 else ('#4a7a8a', '#38606e')
    poly = [(0, 34), (W - 1, 34), (W - 10, 8), (10, 8)]
    paste_masked(cv, shingles(W, H, rc[0], rc[1], 'cooproof'), poly)
    cv.hline(0, W - 1, 34, hx(rc[1])); cv.hline(10, W - 11, 7, light(hx(rc[0]), .4))
    cv.rect(2, 30, 3, H - 1, hx('#fff4e0')); cv.rect(W - 4, 30, W - 3, H - 1, hx('#fff4e0')); cv.rect(2, H - 4, W - 3, H - 1, hx('#7a7e8a'))
    # pop-hole door with ramp
    cv.rect(17, 40, 30, H - 1, hx('#6a4526')); cv.rect(19, 42, 28, H - 1, hx('#2a1a10')); cv.ell(19, 40, 28, 48, hx('#2a1a10'))
    cv.poly([(16, H - 1), (31, H - 1), (28, 54), (19, 54)], hx('#b8864e')) if False else None
    for y in range(52, H - 1, 3): cv.hline(18, 29, y, hx('#b8864e'))
    window(cv, 40, 38, '#fff4e0', w=8, h=8, shutter='#d84a3a')
    if level >= 2: cv.rect(48, 50, 62, 58, hx('#a8703a')); cv.hline(48, 62, 50, hx('#d09a58')); cv.rect(51, 52, 59, 56, hx('#2a1a10'))
    if level >= 3:
        cv.rect(8, 2, 14, 12, hx('#a8503a')); cv.hline(7, 15, 1, hx('#c8684a'))
        cv.line(32, 8, 32, 1, hx('#3a3a48')); cv.rect(29, 1, 35, 2, hx('#ffd23a'))
    cv.outline()
    return cv


def mine_entrance():
    W, H = 64, 60
    cv = Cv(W, H)
    rng = random.Random('mine')
    cv.rect(0, 6, W - 1, H - 1, hx('#7b7e8a'))
    for y in range(6, H):
        for x in range(0, W, 1):
            if rng.random() < 0.18: cv.px(x, y, hx('#8e929e') if rng.random() < .5 else hx('#666977'))
    cv.poly([(0, 14), (10, 0), (54, 0), (63, 14)], hx('#8e929e'))
    for _ in range(40): cv.px(rng.randint(6, 56), rng.randint(1, 12), hx('#a2a6b1') if rng.random() < .5 else hx('#7b7e8a'))
    cv.rect(0, 6, W - 1, 8, hx('#a2a6b1')) if False else None
    cv.ell(14, 12, 49, 60, hx('#2a2530')); cv.rect(14, 36, 49, H - 1, hx('#0e0b14')); cv.ell(16, 14, 47, 58, hx('#0e0b14'))
    cv.rect(10, 22, 15, H - 1, hx('#8a5a2e')); cv.rect(48, 22, 53, H - 1, hx('#8a5a2e')); cv.rect(8, 18, 55, 23, hx('#a8703a')); cv.hline(8, 55, 18, hx('#d09a58'))
    cv.vline(10, 22, H - 1, hx('#a8703a')); cv.vline(48, 22, H - 1, hx('#a8703a'))
    for x in (12, 51):
        cv.rect(x - 1, 27, x + 1, 31, hx('#ffe08a')); cv.px(x, 26, hx('#3a3a48'))
    cv.line(28, H - 1, 28, H - 12, hx('#6a4526')); cv.line(36, H - 1, 36, H - 12, hx('#6a4526'))
    for y in range(H - 3, H - 14, -3): cv.hline(28, 36, y, hx('#8a8e9a'))
    cv.outline()
    return cv


def lantern_hall():
    W, H = 96, 100
    cv = Cv(W, H)
    cv.paste(clapboard(W - 4, 48, '#d8c8e0', '#b8a4c8', 'hall'), 2, 52)
    cv.paste(stone_base(W - 4, 8, 'hallb'), 2, H - 8)
    poly = [(0, 56), (W - 1, 56), (W - 18, 26), (18, 26)]
    paste_masked(cv, shingles(W, H, '#7a5ac0', '#5a3e98', 'hallroof'), poly)
    cv.hline(0, W - 1, 56, hx('#5a3e98')); cv.hline(18, W - 19, 25, light(hx('#7a5ac0'), .4))
    # tower
    cv.rect(38, 8, 57, 30, hx('#d8c8e0')); cv.rect(38, 8, 57, 9, hx('#fff4e0')); cv.hline(38, 57, 30, hx('#b8a4c8'))
    cv.rect(41, 12, 54, 26, hx('#3a3a48')); cv.rect(42, 13, 53, 25, hx('#ffe08a')); cv.rect(44, 15, 51, 23, hx('#fff6d0'))
    cv.vline(47, 13, 25, hx('#3a3a48')); cv.vline(48, 13, 25, hx('#3a3a48'))
    cv.poly([(35, 9), (60, 9), (48, -1)], hx('#5a3e98')) if False else cv.poly([(36, 9), (59, 9), (47, 0), (48, 0)], hx('#5a3e98'))
    cv.rect(46, 0, 49, 2, hx('#ffd23a'))
    window(cv, 10, 66, '#fff4e0', shutter='#9a7ac0', box=True); window(cv, 74, 66, '#fff4e0', shutter='#9a7ac0', box=True)
    window(cv, 26, 66, '#fff4e0', w=8, h=10); window(cv, 60, 66, '#fff4e0', w=8, h=10)
    door_at(cv, 3, H, w=14, hgt=28, dcol='#6a4a8a', trim='#fff4e0'); 
    cv.rect(46, 70, 49, 72, hx('#ffd23a'))
    for x in (40, 55): cv.rect(x, H - 26, x + 2, H - 21, hx('#ffe08a'))
    cv.outline()
    return cv


def draw_buildings(W):
    def add(name, cv):
        W.add(name, cv, 0, cv.h)
    for lv in (1, 2, 3):
        wallc = {1: ('#cfa878', '#b08858'), 2: ('#efe2bc', '#d2c394'), 3: ('#c4d8e8', '#a0bcd4')}[lv]
        roofc = {1: ('#8a5a3a', '#6a4028'), 2: ('#c0503a', '#8a3626'), 3: ('#56688a', '#3e4e6c')}[lv]
        add('b_farmhouse_%d' % lv, house(5, 4, wall=wallc, roof=roofc, doorcol=2, shutters='#4a7a5a' if lv > 1 else None, flowerbox=lv > 1,
                                         seed='farm%d' % lv, attic=lv == 3, porch=lv >= 2, win=True, lantern=lv >= 2,
                                         extra=(lambda cv, W_, H_, rh, wy: (cv.rect(8, 0, 15, rh - 6, hx('#a8503a')), cv.rect(7, 0, 16, 2, hx('#c8684a')))) if lv >= 2 else None))
        add('b_barn_%d' % lv, barn(lv))
        add('b_coop_%d' % lv, coop(lv))
    add('b_general_0', house(5, 4, wall=('#f0e2bc', '#d6c698'), roof=('#c8602a', '#9a4620'), doorcol=2, awning=('#4a9a52', '#fff4e0'), sign='coin', seed='gen', win=True, flowerbox=False))
    add('b_workshop_0', house(5, 4, wall=('#a8a4b0', '#8a8696'), roof=('#4a4658', '#34303e'), doorcol=2, sign='anvil', seed='wk', win=True, shutters='#6a4a2a', flowerbox=False,
                              extra=lambda cv, W_, H_, rh, wy: (cv.rect(W_ - 20, 0, W_ - 10, rh - 2, hx('#6a6e7a')), cv.rect(W_ - 21, 0, W_ - 9, 3, hx('#8a8e9a')))))
    add('b_lantern_0', lantern_hall())
    add('b_ranch_0', house(4, 4, wall=('#f4eedd', '#d8d0bc'), roof=('#4a7a5a', '#36604a'), doorcol=1, sign='cow', seed='rn', shutters='#4a7a5a', porch=True))
    add('b_hut_0', house(3, 3, wall=('#b8a078', '#9a8460'), roof=('#4a7ab0', '#385e90'), doorcol=1, sign='fish', seed='hut', win=True, flowerbox=False, chimney=False))
    add('b_herb_0', house(3, 3, wall=('#d8c8a0', '#b8a880'), roof=('#6a9a48', '#4a7a30'), doorcol=1, sign='leaf', seed='herb', win=True, shutters='#8a6a3a', chimney=True))
    add('b_cottage_a_0', house(3, 3, wall=('#f0e6cc', '#d4c8a8'), roof=('#5a78a8', '#425e88'), doorcol=1, seed='ca', shutters='#d84a3a'))
    add('b_cottage_b_0', house(3, 3, wall=('#e8c4b8', '#c8a498'), roof=('#8a6a58', '#6a4e40'), doorcol=1, seed='cb', shutters='#5a8a6a'))
    add('b_mine_0', mine_entrance())
