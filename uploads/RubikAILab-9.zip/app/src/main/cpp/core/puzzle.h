#pragma once
// Generic twisty puzzle model.
//
// A puzzle is a set of stickers (flat polygons with a colour) and a set of moves. A state is one byte
// per sticker holding its colour. Every move is a rotation about an axis through the origin of all
// the stickers whose centre projects into [lo, hi] on that axis; its permutation table is generated
// from this geometry (rotate every sticker of the layer, find the sticker at the rotated spot), and the
// renderer animates the very same rotation, so simulation and drawing cannot disagree.
//
// Puzzles: 2x2, 3x3, 4x4, 5x5 cubes, Pyraminx (tetrahedron) and Skewb. The learning solver supports the
// ones with a small state space (2x2, 3x3, Pyraminx, Skewb); 4x4 and 5x5 are play-only.
//
// Conventions
//   * Move index = base * 2 + direction. Direction 0 is clockwise seen from outside the turning layer
//     (a negative angle about the outward axis), direction 1 is the inverse. inverse(m) = m ^ 1.
//   * After a move: new[i] = old[perm[move][i]].
//   * Cube axes: x = R, y = U, z = F. Faces U R F D L B, N*N stickers each, row-major as seen from
//     outside (the Kociemba layout for 3x3).

#include <cstdint>
#include <string>
#include <vector>

namespace rubik {

enum PuzzleId {
  kCube2 = 0,
  kCube3 = 1,
  kCube4 = 2,
  kCube5 = 3,
  kPyraminx = 4,
  kSkewb = 5,
  kPuzzleCount = 6,
};

constexpr int kMaxStickers = 150;    // 5x5 cube
constexpr int kMaxAiStickers = 54;   // the learning solver never sees more than this
constexpr int kMaxMoves = 40;

struct MoveInfo {
  float axis[3] = {0.f, 0.f, 1.f};  // unit axis, pointing out of the turning layer
  float angleDeg = 0.f;             // signed rotation about the axis (clockwise from outside = negative)
  float lo = 0.f;                   // the layer holds every point whose projection on the axis is in [lo, hi]
  float hi = 0.f;
  int inverse = 0;
  std::string name;
};

// One physical piece position: the stickers that always travel together.
struct Slot {
  int cls = 0;                // orbit class: slots whose pieces can swap places share a class
  int n = 0;                  // stickers (1 to 3), ascending
  int stickers[3] = {0, 0, 0};
};

struct BodyPiece {
  float cls[3] = {0.f, 0.f, 0.f};  // point used to decide whether the piece is in a turning layer
  std::vector<float> tris;         // 12 floats per triangle: three vertices, then the outward normal
};

struct Puzzle {
  int id = 0;
  std::string name;
  std::string shortName;
  bool valid = false;  // false when the generated move tables are inconsistent (never happens in practice)

  int stickers = 0;
  int colors = 0;
  int faces = 0;
  std::vector<float> verts;     // stickers * 12: up to 4 corners, counter-clockwise seen from outside
  std::vector<uint8_t> vcount;  // corners per sticker (3 or 4)
  std::vector<float> normal;    // stickers * 3, outward
  std::vector<float> centroid;  // stickers * 3
  std::vector<uint8_t> solved;  // colour of every sticker in the solved puzzle
  std::vector<uint8_t> faceOf;  // face of every sticker
  std::vector<int> faceBegin;   // faces + 1 offsets into faceList
  std::vector<int> faceList;    // sticker indices grouped by face

  int moves = 0;
  // The moves of the real puzzle come first (scrambling, solving, hand play); any further moves are free extras that a
  // real puzzle could not make (the Skewb's single-corner twists). playMoves = how many moves are real.
  int playMoves = 0;
  std::vector<MoveInfo> move;
  std::vector<std::vector<uint8_t>> perm;  // [moves][stickers]

  // Learning solver.
  bool aiSupported = false;
  std::vector<int> aiMoves;      // the moves the solver and the trainer use
  bool needsCanon = false;       // true when aiMoves cannot reorient the whole puzzle
  int defaultMaxDepth = 12;
  int hidden1 = 192;
  int hidden2 = 96;
  std::vector<Slot> slots;
  std::vector<int> slotOf;       // slot of every sticker (empty when the solver is unsupported)
  int classCount = 0;
  std::vector<bool> slotFixed;   // never moved by any solver move
  std::vector<std::vector<uint8_t>> rotations;  // whole-puzzle rotations (same convention as perm)
  std::vector<std::vector<int>> conj;           // [rotation][move] -> move acting on the unrotated puzzle
  std::vector<int> refStickers;  // stickers whose colours identify the frame (needsCanon only)

  // Rendering hints and geometry.
  float radius = 3.f;        // bounding radius of the solid
  float stickerInset = 0.03f;   // dark margin around every sticker, in the puzzle's own units
  float stickerRound = 0.1f;    // corner radius of the drawn coloured tile
  float stickerLift = 0.006f;   // tile height above the piece, along its normal
  std::vector<BodyPiece> bodies;
  std::vector<float> core;   // static triangles (12 floats each); unused now that the pieces fill the solid

  bool aiMove(int m) const;

  void setSolved(uint8_t* s) const;
  bool isSolved(const uint8_t* s) const;
  void apply(const uint8_t* src, uint8_t* dst, int move) const;  // src and dst must not alias
  uint64_t hash(const uint8_t* s) const;

  // Whole-puzzle rotation r applied to a state: out[i] = s[rotations[r][i]].
  void rotate(const uint8_t* s, int r, uint8_t* out) const;
  // Index of the rotation that puts the reference piece home (needsCanon), 0 otherwise, -1 if none fits.
  int canonRotation(const uint8_t* s) const;
};

// Builds a puzzle once and keeps it for the lifetime of the process. Returns nullptr for a bad id.
const Puzzle* puzzleById(int id);

}  // namespace rubik
