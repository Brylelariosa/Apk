# Rubik AI Lab - NEXT TASK

Version 2.8 - 2026-10-24

## Do this next
1. Build v2.8 with CI. Nothing from v2.3 to v2.8 has been compiled yet (the authoring sandbox has no Kotlin compiler or Android SDK):
   if the Kotlin compile or R8 reports anything, fix exactly the reported lines. The CI builds assembleRelease when the keystore secrets
   exist, so R8 (minify + shrinkResources) runs too.
2. Play tab on the phone (v2.5 layout): the puzzle picker, timer / moves, turn pad, rotate view and settings are in one panel at the
   bottom above Scramble / Reset / AI solve; the top only has the face strip and short messages. Check that the puzzle stays centred between
   the face strip and the panel, that the panel's icon switches (pad, rotate view) light up, and that a drag on the panel does not spin the view.
3. Skewb corners (v2.8): the owner wanted a swipe on an edge corner piece to turn ONLY that piece (he saw "the whole thing" turn, which is what a real
   twist does). Check on the phone: swipe, tap and hold each corner piece of a face seen straight on (tap it in the face strip): only that corner's three
   colours should cycle, nothing else moves, and the move counter goes up by one. A swipe on the middle diamond still twists half the puzzle. Play
   settings > Skewb corners > "Corners turn on their own" switches back to real twists. After a single-corner turn "AI solve" refuses (the state is not
   reachable by real moves) until Reset or Scramble. If a corner still does not respond at all, Play settings > Troubleshooting > Show touch info
   writes what each touch did at the top of the screen (HIT / MISSED, the move chosen, applied / IGNORED).
3b. Sounds on the phone (media volume up): v2.6's click had a ringing "boing" at the end, v2.7's dry click was still "not like a real cube", v2.8 rebuilt both
   (bright-to-dark impact + shell formants for the click, crackle for the slide). A user turn gives a soft crackle then a click; a scramble is a quick rattle of clicks; the AI solution clicks too;
   Play settings > Sound > Turn sounds switches it off at once; the Train tab stays silent. Nobody has listened to the samples yet: retune
   tests/sound/make_sounds.py (decays, levels, brightness) if they sound too hissy or too clicky, then rerun it into app/src/main/res/raw.
4. Earlier checks still open: the 3x3 thin lines and pieces turning with their layer, the Pyraminx tip swipes, a drag on the puzzle never
   spinning the view, Train tab live view and thermal presets, Test tab sweeps (Learned AI vs Baseline).

## Ideas, not started
- Continuous finger-following turns (current swipes trigger an animated turn).
- Megaminx / other shapes; a "train only while charging" option; per-puzzle hidden sizes in the settings.

## Rules
- Never touch GitHub. Never claim a test or build happened unless a tool confirmed it.
- Keep CI layout: app/src/main/cpp/jni_bridge.cpp and app/src/main/cpp/core/*.cpp (flat).
