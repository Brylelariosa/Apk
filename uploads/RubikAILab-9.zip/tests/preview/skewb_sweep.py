"""Sweeps the camera over many views and checks the Skewb swipe rule (a Python port of Picker.kt, see picker_check.py):
a swipe on a corner piece (triangle) must always twist that corner, and no swipe on any visible sticker may be dead.
Usage: skewb_sweep.py <dir with geo_5.txt>   (make the geometry file with dump_geometry, see BUILD.md)"""
import sys, os, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import preview as P
import picker_check as PC

g = P.load(os.path.join(PC.GEO_DIR, 'geo_5.txt'))
W, H, FREE_TOP, FREE_BOTTOM = 810, 1800, 230, 335      # a tall phone with the bars in place
sizes = PC.layer_sizes(g)
ok = True
REAL = PC.real_moves(g)
for corner_only in (True, False):
    views = corner_drags = corner_own = corner_dead = centre_drags = centre_dead = centre_free = misses = 0
    for yaw in range(-180, 180, 15):
        for pitch in list(range(-85, 86, 15)) + [-90, 90]:      # 90 = looking straight at the top or bottom face, as the face strip does
            views += 1
            O = P.orbit(yaw, pitch); M = P.camera(W, H, g['radius'], FREE_TOP, FREE_BOTTOM) @ O; Minv = np.linalg.inv(M)
            for i, s in enumerate(g['stickers']):
                if np.dot(O[:3, :3] @ s['normal'], [0, 0, 1.0]) <= 0.05: continue          # not facing the camera
                sp = PC.project(M, s['centroid'], W, H)
                if PC.pick(g, M, Minv, sp[0], sp[1], W, H) != i: misses += 1; continue      # sliver at a grazing angle
                own = PC.own_corner_move(g, s['centroid'], {m: 0 for m in range(REAL) if P.in_layer(g, m, s['centroid'])}) if s['n'] == 3 else -1
                for k in range(36):
                    a = 2 * math.pi * (k + 0.5) / 36
                    mv = PC.swipe(g, M, W, H, i, 40 * math.cos(a), 40 * math.sin(a), sizes, corner_only)
                    if s['n'] == 3:
                        corner_drags += 1
                        want = (own + REAL, (own ^ 1) + REAL) if corner_only else (own, own ^ 1)
                        if mv < 0: corner_dead += 1
                        elif mv in want: corner_own += 1
                    else:
                        centre_drags += 1
                        if mv < 0: centre_dead += 1
                        elif mv >= REAL: centre_free += 1
    print(f"[corner swipes turn only the corner: {corner_only}] {views} camera views, 36 drag directions per visible sticker ({misses} grazing stickers skipped)")
    print(f"   corner drags: {corner_drags}, turn the touched corner {'alone' if corner_only else '(half twist)'}: {corner_own} ({corner_own / corner_drags * 100:.1f}%), dead {corner_dead}")
    print(f"   centre drags: {centre_drags}, dead {centre_dead}, wrongly a free single-corner move {centre_free}")
    ok = ok and corner_own == corner_drags and corner_dead == 0 and centre_dead == 0 and centre_free == 0

# ---- taps, holds and near misses, looking straight at a face (what tapping a face picture does) at every
# turn of the view about the line of sight; the finger reach is 16 dp, about 33 px on this 810 px wide test screen
REACH = 33.0
tap_bad = near_bad = near_total = tap_total = 0
for yaw in range(-180, 180, 15):
    for pitch in (-90, 0, 90):
        O = P.orbit(yaw, pitch); M = P.camera(W, H, g['radius'], FREE_TOP, FREE_BOTTOM) @ O; Minv = np.linalg.inv(M)
        faceon = [i for i, s in enumerate(g['stickers']) if np.dot(O[:3, :3] @ s['normal'], [0, 0, 1.0]) > 0.999]   # exactly face on
        if not faceon: continue
        centre = np.mean([PC.project(M, g['stickers'][i]['centroid'], W, H) for i in faceon], axis=0)
        for i in faceon:
            s = g['stickers'][i]
            if s['n'] != 3: continue
            own = PC.own_corner_move(g, s['centroid'], {m: 0 for m in range(REAL) if P.in_layer(g, m, s['centroid'])})
            tap_total += 1
            if PC.tap_move(g, i, False) != own or PC.tap_move(g, i, True) != (own ^ 1): tap_bad += 1
            if PC.tap_move(g, i, False, True) != own + REAL or PC.tap_move(g, i, True, True) != (own ^ 1) + REAL: tap_bad += 1
            # the outer tip of the corner piece: the vertex farthest from the middle of the face
            tips = [PC.project(M, s['corners'][k], W, H) for k in range(3)]
            tip = max(tips, key=lambda t: np.hypot(*(t - centre)))
            out = (tip - centre) / np.hypot(*(tip - centre))
            for dist in (8.0, 16.0, 24.0, 30.0):
                x, y = tip + out * dist
                near_total += 1
                if PC.pick(g, M, Minv, x, y, W, H) != -1 or PC.pick_near(g, M, O, x, y, W, H, REACH) != i: near_bad += 1
            # beyond the reach it must not grab the piece (the view orbits instead)
            x, y = tip + out * (REACH + 20)
            near_total += 1
            if PC.pick_near(g, M, O, x, y, W, H, REACH) != -1: near_bad += 1
print(f"tap/hold on corner pieces looking straight at a face: {tap_total}, wrong move {tap_bad}")
print(f"touches just outside the tip of a corner piece: {near_total}, wrong result {near_bad}")
ok = ok and tap_bad == 0 and near_bad == 0
print("OK" if ok else "FAILED")
sys.exit(0 if ok else 1)
