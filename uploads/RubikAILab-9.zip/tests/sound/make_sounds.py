#!/usr/bin/env python3
"""Synthesises the cube turn sounds (res/raw/turn_slide_*.wav and turn_click_*.wav). No recordings are used: every
sample is built here from damped resonances (the plastic shell), a short noise burst (the impact) and shaped noise
(the layer sliding), so the sounds are reproducible and carry no licence.

  python3 tests/sound/make_sounds.py app/src/main/res/raw          # writes the six WAV files
  python3 tests/sound/make_sounds.py /tmp/sounds --report          # also prints level / spectrum figures

Needs only numpy. 44.1 kHz, 16 bit, mono.
"""
import sys, os, wave
import numpy as np

SR = 44100


def band(x, lo, hi, soft=0.25):
    """Smooth band-pass by FFT masking: pass [lo, hi] Hz, edges eased over `soft` of their frequency."""
    n = len(x)
    f = np.fft.rfftfreq(n, 1.0 / SR)
    m = np.ones_like(f)
    if lo > 0:
        m *= np.clip((f - lo * (1 - soft)) / (lo * 2 * soft), 0, 1)
    if hi < SR / 2:
        m *= np.clip((hi * (1 + soft) - f) / (hi * 2 * soft), 0, 1)
    return np.fft.irfft(np.fft.rfft(x) * m, n)


def smooth(t, a, b):
    u = np.clip((t - a) / (b - a), 0, 1)
    return u * u * (3 - 2 * u)


def glide_lowpass(x, f0, f1, tau):
    """One-pole low-pass whose cutoff glides exponentially from f0 to f1 Hz (time constant tau s): a real impact starts
    bright and darkens within milliseconds, because the high frequencies die away first."""
    n = len(x)
    t = np.arange(n) / SR
    fc = f1 + (f0 - f1) * np.exp(-t / tau)
    a = 1 - np.exp(-2 * np.pi * fc / SR)
    y = np.empty(n)
    acc = 0.0
    for i in range(n):
        acc += a[i] * (x[i] - acc)
        y[i] = acc
    return y


def formant(x, f, q):
    """Two-pole resonator: colours noise around f Hz. Low q (5 to 8) gives a coloured burst, not a ringing tone."""
    w = 2 * np.pi * f / SR
    r = np.exp(-w / (2 * q))
    a1 = -2 * r * np.cos(w)
    a2 = r * r
    y = np.zeros(len(x))
    for i in range(len(x)):
        y[i] = x[i] * (1 - r) - a1 * (y[i - 1] if i > 0 else 0.0) - a2 * (y[i - 2] if i > 1 else 0.0)
    return y


def click(seed, shell=1.0, thock=1.0, length=0.07):
    """The dry plastic click of a layer seating. Two or three tiny knocks a few ms apart (the pieces touching and
    rebounding); each is noise that starts bright and darkens fast, coloured by two low-Q plastic-shell formants, over a
    short soft low-mid thock. Nothing rings, so it stays a click."""
    rng = np.random.default_rng(seed)
    n = int(length * SR)
    t = np.arange(n) / SR
    x = np.zeros(n)
    for delay, gain, dark in [(0.0, 1.00, 1.0), (0.0042 + rng.uniform(-0.0006, 0.0006), 0.50, 0.85), (0.0105 + rng.uniform(-0.001, 0.001), 0.22, 0.7)]:
        d = int(delay * SR)
        m = n - d
        tt = t[:m]
        noise = rng.standard_normal(m)
        bright = glide_lowpass(glide_lowpass(noise, 9500 * dark, 1500, 0.0045), 9500 * dark, 1500, 0.0045)
        body = 0.8 * formant(noise, 1150 * shell, 6.0) + 0.6 * formant(noise, 2350 * shell, 7.0)
        grain = bright / np.std(bright) + body / np.std(body)
        x[d:] += gain * grain * np.exp(-tt / 0.0042) * (1 - np.exp(-tt / 0.00007))
    thump = glide_lowpass(rng.standard_normal(n), 520, 260, 0.01)
    x += 0.4 * thock * thump / np.std(thump) * np.exp(-t / 0.007) * (1 - np.exp(-t / 0.0005))
    x = band(x, 220, 10500, 0.2)
    x *= 1 - smooth(t, length - 0.014, length)
    return x / np.max(np.abs(x)) * 0.8


def slide(seed, length=0.22, speed=1.0):
    """The layer sliding round: not a steady hiss but a gritty crackle of tiny random contacts (plastic on plastic
    sticks and slips), in three bands so no two grains have the same colour, over a faint low rumble."""
    rng = np.random.default_rng(seed)
    n = int(length * SR)
    t = np.arange(n) / SR
    sig = np.zeros(n)
    for lo, hi, rate, gain in [(700, 1600, 240, 0.8), (1600, 3200, 300, 1.0), (3200, 6500, 200, 0.6)]:
        train = np.zeros(n)
        for pos in rng.integers(0, n - 200, rng.poisson(rate * length * speed)):
            k = np.arange(180)
            train[pos:pos + 180] += rng.lognormal(0.0, 0.55) * rng.standard_normal(180) * np.exp(-k / rng.uniform(16, 44))
        train = band(train, lo, hi)
        sig += gain * train / (np.std(train) + 1e-9)
    rumble = band(rng.standard_normal(n), 120, 450)
    rumble = rumble / np.std(rumble) * 0.3 * (0.75 + 0.25 * np.sin(2 * np.pi * 66 * speed * t + rng.uniform(0, 6.28)))
    env = smooth(t, 0.0, 0.025) * (1 - smooth(t, length - 0.05, length)) * (0.7 + 0.3 * np.sin(np.pi * t / length))
    x = (sig + rumble) * env
    tick = click(seed + 100, shell=1.2, thock=0.3, length=0.03)     # the faint tick as the layer lets go of its seat
    x[: len(tick)] += 0.5 * tick * np.max(np.abs(x)) / 0.8
    return x / np.max(np.abs(x)) * 0.42


def write(path, x):
    pcm = np.clip(x, -1, 1)
    with wave.open(path, 'wb') as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes((pcm * 32767).astype('<i2').tobytes())


def main():
    out = sys.argv[1] if len(sys.argv) > 1 else '.'
    os.makedirs(out, exist_ok=True)
    clicks = [click(11, shell=1.00, thock=1.00),
              click(23, shell=0.86, thock=1.25),
              click(37, shell=1.16, thock=0.80)]
    slides = [slide(5, speed=1.0), slide(9, speed=0.9), slide(14, speed=1.1)]
    for i, x in enumerate(clicks, 1):
        write(os.path.join(out, f'turn_click_{i}.wav'), x)
    for i, x in enumerate(slides, 1):
        write(os.path.join(out, f'turn_slide_{i}.wav'), x)
    if '--report' in sys.argv:
        for name, x in [(f'click_{i}', c) for i, c in enumerate(clicks, 1)] + [(f'slide_{i}', s) for i, s in enumerate(slides, 1)]:
            f = np.fft.rfftfreq(len(x), 1 / SR)
            mag = np.abs(np.fft.rfft(x))
            cen = float((f * mag).sum() / mag.sum())
            rms = float(np.sqrt(np.mean(x ** 2)))
            print(f'{name}: {len(x) / SR * 1000:.0f} ms, peak {np.max(np.abs(x)):.2f}, rms {rms:.3f}, spectral centroid {cen:.0f} Hz')


if __name__ == '__main__':
    main()
