use std::fs::File;
use std::io::Read;

use zip::ZipArchive;

/// One regular file inside the ZIP.
pub struct Entry {
    /// Position in the archive (used to read the bytes again later).
    pub index: usize,
    /// Cleaned path inside the ZIP: forward slashes, no leading slash, no `.` or `..`.
    pub path: String,
    /// Uncompressed size in bytes, as the ZIP states it.
    pub size: u64,
    /// True when the ZIP marks the file as executable (`gradlew`, shell scripts).
    pub exec: bool,
}

pub struct Scan {
    pub entries: Vec<Entry>,
    /// Entries that were left out on purpose, each with the reason.
    pub skipped: Vec<String>,
}

pub fn open(path: &str) -> Result<ZipArchive<File>, String> {
    let f = File::open(path).map_err(|e| format!("cannot open {}: {}", path, e))?;
    ZipArchive::new(f).map_err(|e| format!("{} is not a readable ZIP file: {}", path, e))
}

/// Turns a stored entry name into a safe repo-relative path, or None when it can't be one
/// (parent-directory escapes, drive letters, nothing left after cleaning).
pub fn clean_name(raw: &str) -> Option<String> {
    let unified = raw.replace('\\', "/");
    let mut parts: Vec<&str> = Vec::new();
    for seg in unified.split('/') {
        if seg.is_empty() || seg == "." {
            continue;
        }
        if seg == ".." {
            return None;
        }
        parts.push(seg);
    }
    if parts.is_empty() {
        return None;
    }
    // A Windows drive letter such as "C:" as the first segment.
    if parts[0].len() == 2 && parts[0].ends_with(':') {
        return None;
    }
    Some(parts.join("/"))
}

/// Files that archive tools add on their own and that never belong in a repo.
fn is_junk(path: &str) -> bool {
    if path.starts_with("__MACOSX/") || path.contains("/__MACOSX/") {
        return true;
    }
    let name = match path.rsplit('/').next() {
        Some(n) => n,
        None => path,
    };
    name == ".DS_Store" || name == "Thumbs.db"
}

/// Lists the files of the ZIP without reading their contents.
pub fn scan(path: &str) -> Result<Scan, String> {
    let mut archive = open(path)?;
    let mut entries: Vec<Entry> = Vec::new();
    let mut skipped: Vec<String> = Vec::new();

    for i in 0..archive.len() {
        let f = archive
            .by_index(i)
            .map_err(|e| format!("cannot read entry {} of the ZIP: {}", i, e))?;
        if f.is_dir() {
            continue;
        }
        let raw = f.name().to_string();
        let mode = f.unix_mode();
        let size = f.size();

        if let Some(m) = mode {
            if (m & 0o170000) == 0o120000 {
                skipped.push(format!("{} (symbolic link)", raw));
                continue;
            }
        }
        let clean = match clean_name(&raw) {
            Some(p) => p,
            None => {
                skipped.push(format!("{} (unsafe path)", raw));
                continue;
            }
        };
        if is_junk(&clean) {
            continue;
        }
        if clean.split('/').any(|s| s == ".git") {
            skipped.push(format!("{} (inside .git)", clean));
            continue;
        }
        let exec = match mode {
            Some(m) => (m & 0o111) != 0,
            None => false,
        };
        entries.push(Entry { index: i, path: clean, size, exec });
    }

    Ok(Scan { entries, skipped })
}

/// Reads one entry completely into memory.
pub fn read_entry(archive: &mut ZipArchive<File>, index: usize) -> Result<Vec<u8>, String> {
    let mut f = archive
        .by_index(index)
        .map_err(|e| format!("cannot read entry {} of the ZIP: {}", index, e))?;
    let hint = std::cmp::min(f.size(), 64 * 1024 * 1024) as usize;
    let mut buf: Vec<u8> = Vec::with_capacity(hint);
    f.read_to_end(&mut buf)
        .map_err(|e| format!("cannot unpack entry {} of the ZIP: {}", index, e))?;
    Ok(buf)
}
