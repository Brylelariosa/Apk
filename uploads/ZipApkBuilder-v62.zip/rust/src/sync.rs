use std::collections::{HashMap, HashSet};
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::Mutex;
use std::time::Duration;

use serde_json::{json, Value};
use sha1::{Digest, Sha1};

use crate::github::{Gh, RefUpdate, Remote};
use crate::out::Out;
use crate::zipscan;

/// A text file up to this size travels inside the tree request itself (no extra round trip).
const INLINE_FILE_MAX: u64 = 256 * 1024;
/// ...as long as all such files together stay below this.
const INLINE_TOTAL_MAX: u64 = 4 * 1024 * 1024;
/// GitHub refuses single files above this size.
const GITHUB_FILE_MAX: u64 = 100 * 1024 * 1024;
/// How many changed files are named in the log (the rest is summarised).
const LIST_MAX: usize = 60;
/// How many changed paths are sent back in the final result.
const RESULT_LIST_MAX: usize = 3000;

/// What to do with a folder that wraps everything in the ZIP (GitHub's "Download ZIP" puts the
/// whole repo in `name-main/`).
pub enum Strip {
    /// Cut it when that makes the ZIP line up with the repo better.
    Auto,
    Never,
    /// Cut exactly this folder.
    Dir(String),
}

pub struct Opts {
    pub zip: String,
    pub token: String,
    pub owner: String,
    pub repo: String,
    pub branch: String,
    /// Commit message (the number of changed files is appended).
    pub message: Option<String>,
    /// Folder inside the repo the ZIP's root maps to ("" = the repo root).
    pub base: String,
    pub strip: Strip,
    pub dry_run: bool,
    /// Parallel uploads.
    pub jobs: usize,
    /// Also push `.github/workflows/*` files from the ZIP (off by default).
    pub include_workflows: bool,
}

pub struct Outcome {
    /// The new commit, or None when nothing changed (or on a dry run).
    pub commit: Option<String>,
    pub added: usize,
    pub modified: usize,
    pub unchanged: usize,
    pub skipped: usize,
    pub uploaded_bytes: u64,
    /// The wrapper folder that was cut off the ZIP's paths ("" when none).
    pub strip: String,
    pub dry_run: bool,
    pub changed: Vec<String>,
}

/// A file of the ZIP, ready to be compared with the repo.
struct Local {
    /// Position in the archive.
    index: usize,
    /// Path inside the repo.
    target: String,
    size: u64,
    exec: bool,
    /// Git blob id of the content.
    sha: String,
    /// Valid UTF-8 without NUL bytes.
    text: bool,
}

#[derive(Clone, Copy, PartialEq)]
enum Route {
    /// Content rides along in the tree request.
    Inline,
    /// Uploaded as its own blob first.
    Blob,
    /// GitHub already has this exact content (only the file mode changes).
    Existing,
}

struct Change {
    /// Index into the list of local files.
    local: usize,
    target: String,
    mode: String,
    is_new: bool,
    route: Route,
}

// ── Small helpers ────────────────────────────────────────────────────────────

/// The id Git gives a file: SHA-1 over "blob <size>\0" followed by the bytes.
pub fn git_blob_sha(data: &[u8]) -> String {
    let mut h = Sha1::new();
    h.update(format!("blob {}\0", data.len()).as_bytes());
    h.update(data);
    let digest = h.finalize();
    let mut s = String::with_capacity(40);
    for b in digest.iter() {
        s.push_str(&format!("{:02x}", b));
    }
    s
}

fn is_text(data: &[u8]) -> bool {
    !data.contains(&0u8) && std::str::from_utf8(data).is_ok()
}

fn join(base: &str, rel: &str) -> String {
    if base.is_empty() {
        rel.to_string()
    } else {
        format!("{}/{}", base, rel)
    }
}

fn fmt_bytes(b: u64) -> String {
    if b < 1024 {
        format!("{} B", b)
    } else if b < 1024 * 1024 {
        format!("{:.1} KB", b as f64 / 1024.0)
    } else {
        format!("{:.1} MB", b as f64 / (1024.0 * 1024.0))
    }
}

/// The one top-level folder that holds every file of the ZIP, if there is exactly one.
fn wrapper_of(paths: &[String]) -> Option<String> {
    let mut first: Option<&str> = None;
    for p in paths {
        let top = match p.split_once('/') {
            Some((t, _)) => t,
            None => return None, // a file at the top level: nothing wraps the ZIP
        };
        match first {
            None => first = Some(top),
            Some(f) => {
                if f != top {
                    return None;
                }
            }
        }
    }
    first.map(|s| s.to_string())
}

/// Decides which leading folder (with its trailing slash) is cut off every path of the ZIP.
fn choose_strip(opts: &Opts, paths: &[String], remote: &Remote, out: &Out) -> String {
    match &opts.strip {
        Strip::Never => String::new(),
        Strip::Dir(d) => {
            let prefix = format!("{}/", d.trim_matches('/'));
            if paths.iter().all(|p| p.starts_with(&prefix)) {
                out.log(&format!("Cutting the folder '{}' off the ZIP's paths", prefix));
                prefix
            } else {
                out.log(&format!(
                    "[warn] Not every file of the ZIP is inside '{}' — the folder is kept",
                    prefix
                ));
                String::new()
            }
        }
        Strip::Auto => {
            let w = match wrapper_of(paths) {
                Some(w) => w,
                None => return String::new(),
            };
            let prefix = format!("{}/", w);
            let cut = prefix.len();
            let hits = |strip: bool| -> usize {
                let mut n = 0usize;
                for p in paths {
                    let rel: &str = if strip { &p[cut..] } else { p.as_str() };
                    if remote.files.contains_key(&join(&opts.base, rel)) {
                        n += 1;
                    }
                }
                n
            };
            let with_cut = hits(true);
            let without_cut = hits(false);
            let has_gradle_root = paths.iter().any(|p| {
                let rel = &p[cut..];
                rel == "settings.gradle" || rel == "settings.gradle.kts"
            });
            let strip = if with_cut != without_cut {
                with_cut > without_cut
            } else {
                // No clear winner (a new repo, say): a Gradle project sitting directly inside the
                // wrapper is meant to be the repo root.
                has_gradle_root
            };
            if strip {
                out.log(&format!(
                    "The ZIP's top folder '{}' is not part of the repo paths — cutting it off",
                    prefix
                ));
                prefix
            } else {
                String::new()
            }
        }
    }
}

/// Reads every file once to get its Git id. Returns the files to compare and how many were skipped.
fn build_locals(
    opts: &Opts,
    scan: &zipscan::Scan,
    strip: &str,
    out: &Out,
) -> Result<(Vec<Local>, usize), String> {
    let mut archive = zipscan::open(&opts.zip)?;
    let mut locals: Vec<Local> = Vec::new();
    let mut at: HashMap<String, usize> = HashMap::new();
    let mut skipped = 0usize;
    let total = scan.entries.len();

    for (n, e) in scan.entries.iter().enumerate() {
        if n % 25 == 0 {
            out.progress("read", n as u64, total as u64);
        }
        let rel: &str = &e.path[strip.len()..];
        if rel.is_empty() {
            continue;
        }
        let target = join(&opts.base, rel);
        if !opts.include_workflows && target.starts_with(".github/workflows/") {
            out.log(&format!(
                "[warn] Skipped {} — workflow files are managed by the app",
                target
            ));
            skipped += 1;
            continue;
        }
        if e.size > GITHUB_FILE_MAX {
            out.log(&format!(
                "[warn] Skipped {} — {} is over GitHub's 100 MB file limit",
                target,
                fmt_bytes(e.size)
            ));
            skipped += 1;
            continue;
        }
        let data = zipscan::read_entry(&mut archive, e.index)?;
        let local = Local {
            index: e.index,
            target: target.clone(),
            size: data.len() as u64,
            exec: e.exec,
            sha: git_blob_sha(&data),
            text: is_text(&data),
        };
        let existing = at.get(&target).copied();
        match existing {
            Some(i) => {
                // The same path twice in one ZIP: the later entry wins, like when unzipping.
                locals[i] = local;
            }
            None => {
                at.insert(target, locals.len());
                locals.push(local);
            }
        }
    }
    out.progress("read", total as u64, total as u64);
    Ok((locals, skipped))
}

/// Compares every local file with the repo and lists what has to be written.
fn make_plan(locals: &[Local], remote: &Remote, uploaded: &HashMap<String, String>) -> Vec<Change> {
    let mut changes: Vec<Change> = Vec::new();
    let mut inline_total = 0u64;

    for (i, l) in locals.iter().enumerate() {
        let (is_new, same_content, remote_mode) = match remote.files.get(&l.target) {
            Some(r) => (false, r.sha == l.sha, Some(r.mode.as_str())),
            None => (true, false, None),
        };

        // An executable bit in the ZIP wins; otherwise an existing file keeps the mode it has
        // (a ZIP made on Windows carries no permissions and must not strip `gradlew`).
        let mode: String = if l.exec {
            "100755".to_string()
        } else {
            match remote_mode {
                Some("100755") => "100755".to_string(),
                _ => "100644".to_string(),
            }
        };

        if same_content && remote_mode == Some(mode.as_str()) {
            continue; // identical: nothing to do
        }

        let route = if same_content {
            Route::Existing
        } else if uploaded.contains_key(&l.sha) {
            Route::Blob
        } else if l.text && l.size <= INLINE_FILE_MAX && inline_total + l.size <= INLINE_TOTAL_MAX {
            inline_total += l.size;
            Route::Inline
        } else {
            Route::Blob
        };

        changes.push(Change {
            local: i,
            target: l.target.clone(),
            mode,
            is_new,
            route,
        });
    }
    changes
}

fn log_changes(out: &Out, locals: &[Local], changes: &[Change]) {
    for (n, c) in changes.iter().enumerate() {
        if n >= LIST_MAX {
            out.log(&format!("  … and {} more", changes.len() - LIST_MAX));
            break;
        }
        let mark = if c.is_new { "+" } else { "~" };
        out.log(&format!("  {} {} ({})", mark, c.target, fmt_bytes(locals[c.local].size)));
    }
}

fn set_failure(slot: &Mutex<Option<String>>, e: String) {
    let mut g = slot.lock().unwrap();
    if g.is_none() {
        *g = Some(e);
    }
}

/// Uploads the given files as blobs, several at a time. `jobs` holds (position in the archive,
/// local blob id, size). Returns the blob id GitHub reports for each job, in the same order.
fn upload_blobs(
    gh: &Gh,
    zip_path: &str,
    jobs: &[(usize, String, u64)],
    threads: usize,
    out: &Out,
) -> Result<Vec<String>, String> {
    let total = jobs.len();
    let next = AtomicUsize::new(0);
    let done = AtomicUsize::new(0);
    let failure: Mutex<Option<String>> = Mutex::new(None);
    let results: Mutex<Vec<String>> = Mutex::new(vec![String::new(); total]);
    let workers = std::cmp::max(1, std::cmp::min(threads, total));

    std::thread::scope(|scope| {
        for _ in 0..workers {
            scope.spawn(|| {
                let mut archive = match zipscan::open(zip_path) {
                    Ok(a) => a,
                    Err(e) => {
                        set_failure(&failure, e);
                        return;
                    }
                };
                loop {
                    if failure.lock().unwrap().is_some() {
                        return;
                    }
                    let i = next.fetch_add(1, Ordering::SeqCst);
                    if i >= total {
                        return;
                    }
                    let index = jobs[i].0;
                    let outcome =
                        zipscan::read_entry(&mut archive, index).and_then(|data| gh.create_blob(&data));
                    match outcome {
                        Ok(sha) => {
                            results.lock().unwrap()[i] = sha;
                            done.fetch_add(1, Ordering::SeqCst);
                        }
                        Err(e) => {
                            set_failure(&failure, e);
                            return;
                        }
                    }
                }
            });
        }
        // The calling thread only reports progress while the workers run.
        loop {
            let d = done.load(Ordering::SeqCst);
            out.progress("upload", d as u64, total as u64);
            if d >= total || failure.lock().unwrap().is_some() {
                break;
            }
            std::thread::sleep(Duration::from_millis(300));
        }
    });

    if let Some(e) = failure.into_inner().unwrap() {
        return Err(e);
    }
    Ok(results.into_inner().unwrap())
}

// ── The whole sync ───────────────────────────────────────────────────────────

pub fn run(opts: &Opts, out: &Out) -> Result<Outcome, String> {
    let zip_name = match std::path::Path::new(&opts.zip).file_name() {
        Some(n) => n.to_string_lossy().to_string(),
        None => "archive.zip".to_string(),
    };

    out.log(&format!("Reading {} …", zip_name));
    let scan = zipscan::scan(&opts.zip)?;
    if scan.entries.is_empty() {
        return Err("the ZIP contains no files".to_string());
    }
    out.log(&format!("{} file(s) in the ZIP", scan.entries.len()));
    for s in scan.skipped.iter().take(10) {
        out.log(&format!("[warn] Skipped {}", s));
    }
    if scan.skipped.len() > 10 {
        out.log(&format!("[warn] … and {} more skipped", scan.skipped.len() - 10));
    }

    let log_out = *out;
    let gh = Gh::new(
        &opts.token,
        &opts.owner,
        &opts.repo,
        Box::new(move |m: &str| log_out.log(m)),
    );

    out.log(&format!(
        "Reading github.com/{}/{} @ {} …",
        opts.owner, opts.repo, opts.branch
    ));
    let mut remote = gh.fetch_remote(&opts.branch)?;
    out.log(&format!("{} file(s) in the repo", remote.files.len()));
    if remote.truncated {
        out.log(
            "[warn] GitHub cut its file listing short (a very large repo). Some unchanged files may be \
             uploaded again, but the commit still only contains real changes.",
        );
    }

    let paths: Vec<String> = scan.entries.iter().map(|e| e.path.clone()).collect();
    let strip = choose_strip(opts, &paths, &remote, out);

    out.log("Comparing …");
    let (locals, skipped_here) = build_locals(opts, &scan, &strip, out)?;
    let skipped_total = scan.skipped.len() + skipped_here;
    if locals.is_empty() {
        return Err("nothing in the ZIP can be synced".to_string());
    }

    let mut archive = zipscan::open(&opts.zip)?;
    let mut uploaded: HashMap<String, String> = HashMap::new();
    let mut uploaded_bytes: u64 = 0;
    let mut attempt: u32 = 0;

    loop {
        attempt += 1;
        let changes = make_plan(&locals, &remote, &uploaded);
        let added = changes.iter().filter(|c| c.is_new).count();
        let modified = changes.len() - added;
        let unchanged = locals.len() - changes.len();
        let changed_paths: Vec<String> = changes
            .iter()
            .take(RESULT_LIST_MAX)
            .map(|c| c.target.clone())
            .collect();

        if changes.is_empty() {
            out.log("Nothing to do — the repo already matches the ZIP.");
            return Ok(Outcome {
                commit: None,
                added: 0,
                modified: 0,
                unchanged,
                skipped: skipped_total,
                uploaded_bytes,
                strip,
                dry_run: opts.dry_run,
                changed: Vec::new(),
            });
        }

        if attempt == 1 {
            out.log(&format!(
                "{} file(s) to sync: {} new, {} changed — {} already up to date",
                changes.len(),
                added,
                modified,
                unchanged
            ));
            log_changes(out, &locals, &changes);
        }

        if opts.dry_run {
            out.log("Dry run — nothing was uploaded.");
            return Ok(Outcome {
                commit: None,
                added,
                modified,
                unchanged,
                skipped: skipped_total,
                uploaded_bytes: 0,
                strip,
                dry_run: true,
                changed: changed_paths,
            });
        }

        // 1. Files that travel as their own blob (binaries and big files), uploaded in parallel.
        let mut jobs: Vec<(usize, String, u64)> = Vec::new();
        let mut queued: HashSet<String> = HashSet::new();
        for c in changes.iter().filter(|c| c.route == Route::Blob) {
            let l = &locals[c.local];
            if !uploaded.contains_key(&l.sha) && queued.insert(l.sha.clone()) {
                jobs.push((l.index, l.sha.clone(), l.size));
            }
        }
        if !jobs.is_empty() {
            let bytes: u64 = jobs.iter().map(|j| j.2).sum();
            out.log(&format!("Uploading {} file(s), {} …", jobs.len(), fmt_bytes(bytes)));
            let blob_ids = upload_blobs(&gh, &opts.zip, &jobs, opts.jobs, out)?;
            for (job, blob) in jobs.iter().zip(blob_ids.iter()) {
                uploaded.insert(job.1.clone(), blob.clone());
            }
            uploaded_bytes += bytes;
        }

        // 2. One tree that replaces exactly the changed paths and keeps everything else.
        let mut entries: Vec<Value> = Vec::with_capacity(changes.len());
        for c in &changes {
            let l = &locals[c.local];
            let entry = match c.route {
                Route::Inline => {
                    let data = zipscan::read_entry(&mut archive, l.index)?;
                    let text = String::from_utf8(data)
                        .map_err(|_| format!("{} changed while it was being read", c.target))?;
                    uploaded_bytes += l.size;
                    json!({ "path": c.target, "mode": c.mode, "type": "blob", "content": text })
                }
                Route::Existing => {
                    json!({ "path": c.target, "mode": c.mode, "type": "blob", "sha": l.sha })
                }
                Route::Blob => {
                    let sha = match uploaded.get(&l.sha) {
                        Some(s) => s.clone(),
                        None => l.sha.clone(),
                    };
                    json!({ "path": c.target, "mode": c.mode, "type": "blob", "sha": sha })
                }
            };
            entries.push(entry);
        }

        out.log("Creating the commit …");
        let new_tree = gh.create_tree(&remote.tree, &entries)?;
        if new_tree == remote.tree {
            out.log("Nothing to do — the repo already matches the ZIP.");
            return Ok(Outcome {
                commit: None,
                added: 0,
                modified: 0,
                unchanged: locals.len(),
                skipped: skipped_total,
                uploaded_bytes,
                strip,
                dry_run: false,
                changed: Vec::new(),
            });
        }

        let base_message = match &opts.message {
            Some(m) => m.clone(),
            None => format!("sync: {}", zip_name),
        };
        let message = format!("{} ({} changed)", base_message, changes.len());
        let commit = gh.create_commit(&message, &new_tree, &remote.head)?;

        match gh.update_ref(&opts.branch, &commit)? {
            RefUpdate::Done => {
                let short = std::cmp::min(7, commit.len());
                out.log(&format!(
                    "[ok] Committed {} — {} file(s) changed",
                    &commit[..short],
                    changes.len()
                ));
                return Ok(Outcome {
                    commit: Some(commit),
                    added,
                    modified,
                    unchanged,
                    skipped: skipped_total,
                    uploaded_bytes,
                    strip,
                    dry_run: false,
                    changed: changed_paths,
                });
            }
            RefUpdate::Moved(why) => {
                if attempt >= 3 {
                    return Err(format!(
                        "the branch keeps changing while syncing ({}) — try again in a moment",
                        why
                    ));
                }
                out.log("The branch moved while syncing — comparing again …");
                remote = gh.fetch_remote(&opts.branch)?;
            }
        }
    }
}
