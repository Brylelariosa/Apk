use std::io::Write;

use serde_json::json;

use crate::sync::Outcome;

/// Everything the engine says goes through here: one JSON object per line with `--json` (what the
/// Android app reads), plain text otherwise (for a terminal or a CI log).
///
/// `Out` is `Copy` so the GitHub client and the upload threads can each hold their own copy.
#[derive(Clone, Copy)]
pub struct Out {
    json: bool,
}

impl Out {
    pub fn new(json: bool) -> Out {
        Out { json }
    }

    pub fn log(&self, msg: &str) {
        if self.json {
            self.line(&json!({ "t": "log", "m": msg }).to_string());
        } else {
            self.line(msg);
        }
    }

    /// Progress is machine-readable only; in plain mode the log lines are enough.
    pub fn progress(&self, phase: &str, done: u64, total: u64) {
        if self.json {
            self.line(&json!({ "t": "progress", "phase": phase, "done": done, "total": total }).to_string());
        }
    }

    pub fn result_ok(&self, o: &Outcome) {
        if self.json {
            let v = json!({
                "t": "result",
                "ok": true,
                "commit": o.commit,
                "added": o.added,
                "modified": o.modified,
                "unchanged": o.unchanged,
                "skipped": o.skipped,
                "uploaded_bytes": o.uploaded_bytes,
                "strip": o.strip,
                "dry_run": o.dry_run,
                "changed": o.changed,
            });
            self.line(&v.to_string());
        } else {
            match &o.commit {
                Some(c) => self.line(&format!(
                    "Done: {} new, {} changed, {} unchanged. Commit {}",
                    o.added, o.modified, o.unchanged, c
                )),
                None => self.line(&format!(
                    "Done: {} new, {} changed, {} unchanged. No commit was made.",
                    o.added, o.modified, o.unchanged
                )),
            }
        }
    }

    pub fn result_err(&self, err: &str) {
        if self.json {
            self.line(&json!({ "t": "result", "ok": false, "error": err }).to_string());
        } else {
            self.line(&format!("Error: {}", err));
        }
    }

    fn line(&self, s: &str) {
        let stdout = std::io::stdout();
        let mut h = stdout.lock();
        let _ = writeln!(h, "{}", s);
        let _ = h.flush();
    }
}
