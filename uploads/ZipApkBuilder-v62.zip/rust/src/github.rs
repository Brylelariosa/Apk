use std::collections::HashMap;
use std::io::Read;
use std::time::Duration;

use base64::{engine::general_purpose::STANDARD, Engine as _};
use serde_json::{json, Value};

/// How often one request is tried before giving up (network hiccups, 5xx, rate limits).
const MAX_TRIES: u32 = 6;

pub struct RemoteFile {
    pub sha: String,
    pub mode: String,
}

/// What the branch looks like on GitHub right now.
pub struct Remote {
    /// Commit the branch points at.
    pub head: String,
    /// Tree of that commit.
    pub tree: String,
    /// Every file in the tree: path -> blob id and file mode.
    pub files: HashMap<String, RemoteFile>,
    /// True when GitHub cut the listing short (more than 100,000 entries or 7 MB).
    pub truncated: bool,
}

pub enum RefUpdate {
    Done,
    /// The branch moved since we read it (somebody else pushed). The text is GitHub's reason.
    Moved(String),
}

pub struct Gh {
    agent: ureq::Agent,
    token: String,
    base: String,
    log: Box<dyn Fn(&str) + Send + Sync>,
}

enum Reply {
    Http {
        status: u16,
        body: String,
        retry_after: Option<u64>,
        rl_remaining: Option<i64>,
        rl_reset: Option<i64>,
    },
    Down(String),
}

impl Gh {
    pub fn new(token: &str, owner: &str, repo: &str, log: Box<dyn Fn(&str) + Send + Sync>) -> Gh {
        let agent = ureq::AgentBuilder::new()
            .timeout_connect(Duration::from_secs(25))
            .timeout_read(Duration::from_secs(120))
            .timeout_write(Duration::from_secs(120))
            .user_agent("zipsync/0.1 (ZipApkBuilder)")
            .build();
        Gh {
            agent,
            token: token.to_string(),
            base: format!("https://api.github.com/repos/{}/{}", owner, repo),
            log,
        }
    }

    // ── One request, with retries ────────────────────────────────────────────

    fn attempt(&self, method: &str, url: &str, body: Option<&str>) -> Reply {
        let req = self
            .agent
            .request(method, url)
            .set("Authorization", &format!("Bearer {}", self.token))
            .set("Accept", "application/vnd.github+json")
            .set("X-GitHub-Api-Version", "2022-11-28");
        let res = match body {
            Some(b) => req.set("Content-Type", "application/json").send_string(b),
            None => req.call(),
        };
        match res {
            Ok(resp) => read_reply(resp),
            Err(ureq::Error::Status(_, resp)) => read_reply(resp),
            Err(ureq::Error::Transport(t)) => Reply::Down(t.to_string()),
            #[allow(unreachable_patterns)]
            Err(other) => Reply::Down(other.to_string()),
        }
    }

    /// Sends a request and returns (status, body). Network errors, 5xx answers and rate limits
    /// are retried with a growing pause; every other answer (including 4xx) is handed back.
    fn call(&self, method: &str, tail: &str, body: Option<&str>) -> Result<(u16, String), String> {
        let url = format!("{}/{}", self.base, tail);
        let mut tries: u32 = 0;
        loop {
            tries += 1;
            match self.attempt(method, &url, body) {
                Reply::Down(e) => {
                    if tries >= MAX_TRIES {
                        return Err(format!("network error: {}", e));
                    }
                    let wait = backoff(tries);
                    (self.log)(&format!("Network hiccup ({}) — retrying in {}s …", e, wait));
                    pause(wait);
                }
                Reply::Http { status, body: text, retry_after, rl_remaining, rl_reset } => {
                    let limited = status == 429
                        || (status == 403
                            && (retry_after.is_some()
                                || rl_remaining == Some(0)
                                || text.to_lowercase().contains("rate limit")));
                    if limited {
                        if tries >= MAX_TRIES {
                            return Err(describe(status, &text));
                        }
                        let from_reset = rl_reset.map(|r| {
                            let left = r - now_secs();
                            if left < 1 {
                                1u64
                            } else {
                                left as u64
                            }
                        });
                        let wait = std::cmp::min(retry_after.or(from_reset).unwrap_or_else(|| backoff(tries)), 90u64);
                        (self.log)(&format!("GitHub asked us to slow down — waiting {}s …", wait));
                        pause(wait);
                        continue;
                    }
                    if status >= 500 && status != 501 {
                        if tries >= MAX_TRIES {
                            return Err(describe(status, &text));
                        }
                        let wait = backoff(tries);
                        (self.log)(&format!("GitHub answered {} — retrying in {}s …", status, wait));
                        pause(wait);
                        continue;
                    }
                    return Ok((status, text));
                }
            }
        }
    }

    /// A call that must come back 2xx with a JSON body.
    fn json_ok(&self, method: &str, tail: &str, body: Option<&str>, what: &str) -> Result<Value, String> {
        let (status, text) = self.call(method, tail, body)?;
        if !(200..300).contains(&status) {
            return Err(format!("{} failed: {}", what, describe(status, &text)));
        }
        serde_json::from_str::<Value>(&text)
            .map_err(|e| format!("{}: GitHub sent an unexpected reply ({})", what, e))
    }

    // ── What the sync needs ──────────────────────────────────────────────────

    /// Commit id the branch points at.
    pub fn get_head(&self, branch: &str) -> Result<String, String> {
        let tail = format!("git/ref/heads/{}", enc_path(branch));
        let (status, text) = self.call("GET", &tail, None)?;
        if status == 404 {
            return Err(format!(
                "branch '{}' was not found on GitHub (or the token cannot see this repository)",
                branch
            ));
        }
        if status == 409 {
            return Err("the repository is empty — make its first commit on GitHub, then try again".to_string());
        }
        if !(200..300).contains(&status) {
            return Err(format!("reading the branch failed: {}", describe(status, &text)));
        }
        let v: Value = serde_json::from_str(&text)
            .map_err(|e| format!("reading the branch: GitHub sent an unexpected reply ({})", e))?;
        match v["object"]["sha"].as_str() {
            Some(s) => Ok(s.to_string()),
            None => Err("GitHub did not say which commit the branch points at".to_string()),
        }
    }

    pub fn commit_tree(&self, commit: &str) -> Result<String, String> {
        let v = self.json_ok("GET", &format!("git/commits/{}", commit), None, "reading the commit")?;
        match v["tree"]["sha"].as_str() {
            Some(s) => Ok(s.to_string()),
            None => Err("GitHub did not return the commit's file tree".to_string()),
        }
    }

    /// Every file of a tree, in one request.
    pub fn list_tree(&self, tree: &str) -> Result<(HashMap<String, RemoteFile>, bool), String> {
        let v = self.json_ok(
            "GET",
            &format!("git/trees/{}?recursive=1", tree),
            None,
            "listing the repository",
        )?;
        let truncated = v["truncated"].as_bool().unwrap_or(false);
        let mut files: HashMap<String, RemoteFile> = HashMap::new();
        if let Some(arr) = v["tree"].as_array() {
            for e in arr {
                if e["type"].as_str() != Some("blob") {
                    continue;
                }
                let path = match e["path"].as_str() {
                    Some(p) => p.to_string(),
                    None => continue,
                };
                let sha = e["sha"].as_str().unwrap_or("").to_string();
                let mode = e["mode"].as_str().unwrap_or("100644").to_string();
                files.insert(path, RemoteFile { sha, mode });
            }
        }
        Ok((files, truncated))
    }

    pub fn fetch_remote(&self, branch: &str) -> Result<Remote, String> {
        let head = self.get_head(branch)?;
        let tree = self.commit_tree(&head)?;
        let (files, truncated) = self.list_tree(&tree)?;
        Ok(Remote { head, tree, files, truncated })
    }

    /// Stores one file on GitHub and returns its blob id.
    pub fn create_blob(&self, data: &[u8]) -> Result<String, String> {
        let b64 = STANDARD.encode(data);
        let body = format!("{{\"content\":\"{}\",\"encoding\":\"base64\"}}", b64);
        let v = self.json_ok("POST", "git/blobs", Some(body.as_str()), "uploading a file")?;
        match v["sha"].as_str() {
            Some(s) => Ok(s.to_string()),
            None => Err("GitHub did not return an id for an uploaded file".to_string()),
        }
    }

    /// New tree = `base` plus (or replacing) the given entries. Returns the new tree id.
    pub fn create_tree(&self, base: &str, entries: &[Value]) -> Result<String, String> {
        let body = json!({ "base_tree": base, "tree": entries }).to_string();
        let v = self.json_ok("POST", "git/trees", Some(body.as_str()), "building the new file tree")?;
        match v["sha"].as_str() {
            Some(s) => Ok(s.to_string()),
            None => Err("GitHub did not return the new file tree".to_string()),
        }
    }

    pub fn create_commit(&self, message: &str, tree: &str, parent: &str) -> Result<String, String> {
        let body = json!({ "message": message, "tree": tree, "parents": [parent] }).to_string();
        let v = self.json_ok("POST", "git/commits", Some(body.as_str()), "creating the commit")?;
        match v["sha"].as_str() {
            Some(s) => Ok(s.to_string()),
            None => Err("GitHub did not return the new commit".to_string()),
        }
    }

    /// Moves the branch to `sha` (never forced, so nobody else's commit can be overwritten).
    pub fn update_ref(&self, branch: &str, sha: &str) -> Result<RefUpdate, String> {
        let tail = format!("git/refs/heads/{}", enc_path(branch));
        let body = json!({ "sha": sha, "force": false }).to_string();
        let (status, text) = self.call("PATCH", &tail, Some(body.as_str()))?;
        if (200..300).contains(&status) {
            return Ok(RefUpdate::Done);
        }
        if status == 422 {
            return Ok(RefUpdate::Moved(describe(status, &text)));
        }
        Err(format!("moving the branch failed: {}", describe(status, &text)))
    }
}

fn read_reply(resp: ureq::Response) -> Reply {
    let status = resp.status();
    let retry_after = resp.header("retry-after").and_then(|v| v.trim().parse::<u64>().ok());
    let rl_remaining = resp
        .header("x-ratelimit-remaining")
        .and_then(|v| v.trim().parse::<i64>().ok());
    let rl_reset = resp
        .header("x-ratelimit-reset")
        .and_then(|v| v.trim().parse::<i64>().ok());
    let mut body = String::new();
    let _ = resp.into_reader().take(64 * 1024 * 1024).read_to_string(&mut body);
    Reply::Http { status, body, retry_after, rl_remaining, rl_reset }
}

/// GitHub's own message plus a plain-language hint for the common failures.
fn describe(status: u16, text: &str) -> String {
    let msg = match serde_json::from_str::<Value>(text) {
        Ok(v) => match v["message"].as_str() {
            Some(m) => m.to_string(),
            None => text.chars().take(200).collect::<String>(),
        },
        Err(_) => text.chars().take(200).collect::<String>(),
    };
    let hint = match status {
        401 => " — the token was rejected (expired or mistyped)",
        403 => " — the token may lack the 'repo' scope, or GitHub is rate limiting",
        404 => " — not found (wrong repository or branch name, or the token cannot see it)",
        409 => " — the repository is empty or in conflict",
        422 => " — GitHub refused the request",
        _ => "",
    };
    format!("HTTP {}: {}{}", status, msg, hint)
}

/// Seconds to wait after the n-th failed try: 1, 2, 4, 8, 16, 20, …
fn backoff(n: u32) -> u64 {
    let shift = std::cmp::min(n.saturating_sub(1), 5);
    std::cmp::min(1u64 << shift, 20u64)
}

fn pause(secs: u64) {
    std::thread::sleep(Duration::from_secs(secs));
}

fn now_secs() -> i64 {
    match std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH) {
        Ok(d) => d.as_secs() as i64,
        Err(_) => 0,
    }
}

/// Percent-encodes a branch name for use in a URL path (slashes stay slashes).
fn enc_path(s: &str) -> String {
    let mut out = String::new();
    for b in s.bytes() {
        let c = b as char;
        if c.is_ascii_alphanumeric() || c == '-' || c == '.' || c == '_' || c == '~' || c == '/' {
            out.push(c);
        } else {
            out.push_str(&format!("%{:02X}", b));
        }
    }
    out
}
