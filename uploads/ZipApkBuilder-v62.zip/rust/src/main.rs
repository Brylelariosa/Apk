mod github;
mod out;
mod sync;
mod zipscan;

use std::process;

const USAGE: &str = "\
zipsync - compare a ZIP with a GitHub repository and push only what changed

USAGE:
  zipsync sync --zip FILE --repo OWNER/NAME [options]

The GitHub token is read from the ZIPSYNC_TOKEN (or GITHUB_TOKEN) environment variable.
It needs the 'repo' scope.

OPTIONS:
  --zip FILE             the ZIP to sync
  --repo OWNER/NAME      the target repository
  --branch NAME          target branch (default: main)
  --message TEXT         commit message (the number of changed files is appended)
  --prefix DIR           folder inside the repo the ZIP's root maps to (default: the repo root)
  --strip auto|none|DIR  what to do with a folder that wraps the whole ZIP (default: auto)
  --jobs N               parallel uploads, 1-8 (default: 4)
  --include-workflows    also push .github/workflows/* files from the ZIP
  --dry-run              only show what would change
  --json                 machine-readable output (used by the Android app)

Files with the same path in the ZIP and the repo are replaced, new files are added, files that
are only in the repo are left alone. Everything lands in one commit.
";

struct Parsed {
    opts: sync::Opts,
    json: bool,
}

fn value(it: &mut std::slice::Iter<'_, String>, flag: &str) -> Result<String, String> {
    match it.next() {
        Some(v) => Ok(v.clone()),
        None => Err(format!("{} needs a value", flag)),
    }
}

fn parse_args(args: &[String]) -> Result<Parsed, String> {
    let mut it = args.iter();
    match it.next() {
        Some(c) if c.as_str() == "sync" => {}
        Some(c) if c.as_str() == "--help" || c.as_str() == "-h" || c.as_str() == "help" => {
            return Err(String::new());
        }
        _ => return Err("expected the command 'sync'".to_string()),
    }

    let mut zip: Option<String> = None;
    let mut repo: Option<String> = None;
    let mut branch = "main".to_string();
    let mut message: Option<String> = None;
    let mut base = String::new();
    let mut strip = sync::Strip::Auto;
    let mut dry_run = false;
    let mut json = false;
    let mut jobs: usize = 4;
    let mut include_workflows = false;

    while let Some(a) = it.next() {
        match a.as_str() {
            "--zip" => zip = Some(value(&mut it, "--zip")?),
            "--repo" => repo = Some(value(&mut it, "--repo")?),
            "--branch" => branch = value(&mut it, "--branch")?,
            "--message" => message = Some(value(&mut it, "--message")?),
            "--prefix" => base = value(&mut it, "--prefix")?,
            "--strip" => {
                let v = value(&mut it, "--strip")?;
                strip = match v.as_str() {
                    "auto" => sync::Strip::Auto,
                    "none" => sync::Strip::Never,
                    other => sync::Strip::Dir(other.to_string()),
                };
            }
            "--jobs" => {
                let v = value(&mut it, "--jobs")?;
                jobs = v
                    .parse::<usize>()
                    .map_err(|_| format!("--jobs needs a number, got '{}'", v))?;
            }
            "--include-workflows" => include_workflows = true,
            "--dry-run" => dry_run = true,
            "--json" => json = true,
            other => return Err(format!("unknown option '{}'", other)),
        }
    }

    let zip = zip.ok_or_else(|| "--zip is required".to_string())?;
    let repo_full = repo.ok_or_else(|| "--repo is required".to_string())?;
    let (owner, name) = match repo_full.split_once('/') {
        Some((o, n)) if !o.is_empty() && !n.is_empty() => (o.to_string(), n.to_string()),
        _ => return Err("--repo must look like OWNER/NAME".to_string()),
    };

    let token = match std::env::var("ZIPSYNC_TOKEN") {
        Ok(t) if !t.trim().is_empty() => t.trim().to_string(),
        _ => match std::env::var("GITHUB_TOKEN") {
            Ok(t) if !t.trim().is_empty() => t.trim().to_string(),
            _ => {
                return Err(
                    "set the ZIPSYNC_TOKEN environment variable to a GitHub token with the 'repo' scope"
                        .to_string(),
                )
            }
        },
    };

    let base = if base.trim().is_empty() {
        String::new()
    } else {
        match zipscan::clean_name(&base) {
            Some(b) => b,
            None => return Err("--prefix is not a valid folder path".to_string()),
        }
    };

    let jobs = jobs.max(1).min(8);

    Ok(Parsed {
        opts: sync::Opts {
            zip,
            token,
            owner,
            repo: name,
            branch,
            message,
            base,
            strip,
            dry_run,
            jobs,
            include_workflows,
        },
        json,
    })
}

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let parsed = match parse_args(&args) {
        Ok(p) => p,
        Err(e) => {
            if !e.is_empty() {
                eprintln!("error: {}\n", e);
            }
            eprintln!("{}", USAGE);
            process::exit(2);
        }
    };

    let out = out::Out::new(parsed.json);
    match sync::run(&parsed.opts, &out) {
        Ok(res) => out.result_ok(&res),
        Err(e) => {
            out.result_err(&e);
            process::exit(1);
        }
    }
}
