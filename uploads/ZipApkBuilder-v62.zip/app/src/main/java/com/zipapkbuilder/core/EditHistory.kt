package com.zipapkbuilder.core

import android.text.Editable
import android.text.Selection
import android.text.TextWatcher

/**
 * Undo/redo for the code editor. Attached as a [TextWatcher], it records every change as the
 * exact text removed and added at a position, so undoing is just putting the old text back.
 *
 * Consecutive typing, backspacing and the growing of one IME composition are merged into a single
 * step (a pause of more than [MERGE_WINDOW_MS] starts a new one), so undo takes back a word at a
 * time instead of a letter at a time. Memory is bounded by [maxEdits] and [maxChars].
 *
 * Applying an undo or redo goes through [Editable.replace] while [applying] is set, so the
 * changes it makes are not recorded again. The editor wraps [undo]/[redo] in its own "raw edit"
 * switch so its input filters (auto-indent, auto-pairing) stay out of the way as well.
 */
class EditHistory(
    private val maxEdits: Int = 400,
    private val maxChars: Int = 400_000
) : TextWatcher {

    private class Edit(var start: Int, var removed: String, var added: String, var time: Long)

    private val undoStack = ArrayList<Edit>()
    private val redoStack = ArrayList<Edit>()
    private var pendingRemoved = ""
    private var applying = false
    private var totalChars = 0

    /** Called after the undo/redo availability may have changed. */
    var onChange: (() -> Unit)? = null

    val canUndo: Boolean get() = undoStack.isNotEmpty()
    val canRedo: Boolean get() = redoStack.isNotEmpty()

    /** Forgets everything — used when a file is (re)loaded so undo can't go back past its start. */
    fun clear() {
        undoStack.clear()
        redoStack.clear()
        totalChars = 0
        pendingRemoved = ""
        onChange?.invoke()
    }

    fun undo(target: Editable): Boolean {
        if (undoStack.isEmpty()) return false
        val edit = undoStack.removeAt(undoStack.size - 1)
        totalChars -= edit.removed.length + edit.added.length
        replaceQuietly(target, edit.start, edit.added.length, edit.removed)
        redoStack.add(edit)
        onChange?.invoke()
        return true
    }

    fun redo(target: Editable): Boolean {
        if (redoStack.isEmpty()) return false
        val edit = redoStack.removeAt(redoStack.size - 1)
        replaceQuietly(target, edit.start, edit.removed.length, edit.added)
        undoStack.add(edit)
        totalChars += edit.removed.length + edit.added.length
        onChange?.invoke()
        return true
    }

    private fun replaceQuietly(target: Editable, start: Int, length: Int, replacement: String) {
        applying = true
        try {
            val s = start.coerceIn(0, target.length)
            val e = (start + length).coerceIn(s, target.length)
            target.replace(s, e, replacement)
            Selection.setSelection(target, (s + replacement.length).coerceAtMost(target.length))
        } finally {
            applying = false
        }
    }

    // ── TextWatcher ───────────────────────────────────────────────────────────

    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
        if (applying || s == null) return
        pendingRemoved = if (count > 0) s.subSequence(start, start + count).toString() else ""
    }

    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
        if (applying || s == null) return
        val added = if (count > 0) s.subSequence(start, start + count).toString() else ""
        val removed = pendingRemoved
        pendingRemoved = ""
        // An IME re-committing identical text is not an edit.
        if (removed == added) return
        record(Edit(start, removed, added, System.currentTimeMillis()))
    }

    override fun afterTextChanged(s: Editable?) {}

    private fun record(edit: Edit) {
        redoStack.clear()
        val last = undoStack.lastOrNull()
        if (last != null && tryMerge(last, edit)) {
            onChange?.invoke()
            return
        }
        undoStack.add(edit)
        totalChars += edit.removed.length + edit.added.length
        while (undoStack.size > maxEdits || (totalChars > maxChars && undoStack.size > 1)) {
            val dropped = undoStack.removeAt(0)
            totalChars -= dropped.removed.length + dropped.added.length
        }
        onChange?.invoke()
    }

    /** Folds [next] into [last] when both are part of one burst of typing or deleting. */
    private fun tryMerge(last: Edit, next: Edit): Boolean {
        if (next.time - last.time > MERGE_WINDOW_MS) return false

        // Typing: one more character right after the text the last edit inserted.
        if (last.removed.isEmpty() && next.removed.isEmpty() &&
            next.start == last.start + last.added.length &&
            next.added.length == 1 && next.added[0] != '\n' &&
            last.added.length < MAX_MERGED_RUN && !last.added.endsWith("\n")
        ) {
            last.added += next.added
            last.time = next.time
            totalChars += 1
            return true
        }

        // An IME composition growing: the new text replaces exactly what the last edit inserted.
        if (next.start == last.start && next.removed == last.added && last.added.isNotEmpty() &&
            next.added.length <= MAX_MERGED_RUN
        ) {
            totalChars += next.added.length - last.added.length
            last.added = next.added
            last.time = next.time
            return true
        }

        // Backspacing: the character just before the previous deletion.
        if (last.added.isEmpty() && next.added.isEmpty() &&
            next.removed.length == 1 && next.start + 1 == last.start &&
            last.removed.length < MAX_MERGED_RUN
        ) {
            last.removed = next.removed + last.removed
            last.start = next.start
            last.time = next.time
            totalChars += 1
            return true
        }

        // Forward delete: the character that slid into the same spot.
        if (last.added.isEmpty() && next.added.isEmpty() &&
            next.removed.length == 1 && next.start == last.start &&
            last.removed.length < MAX_MERGED_RUN
        ) {
            last.removed += next.removed
            last.time = next.time
            totalChars += 1
            return true
        }
        return false
    }

    private companion object {
        const val MERGE_WINDOW_MS = 1200L
        const val MAX_MERGED_RUN = 80
    }
}
