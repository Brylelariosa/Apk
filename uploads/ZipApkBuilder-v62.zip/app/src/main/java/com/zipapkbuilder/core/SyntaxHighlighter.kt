package com.zipapkbuilder.core

import android.text.Editable
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import java.util.concurrent.ConcurrentHashMap
import java.util.regex.Pattern
import java.util.regex.PatternSyntaxException

/**
 * Per-language syntax coloring for the code editor.
 *
 * Each language is one regular expression made of prioritized alternatives (comments and strings
 * first, so a keyword inside a string or comment is never recolored), scanned in a single pass.
 * [compute] is pure — it only reads a String snapshot — so the editor runs it on a background
 * thread and applies the result with [applySpans] once back on the main thread (and only if the text
 * has not changed in the meantime).
 *
 * This is deliberately a lightweight tokenizer, not a parser: it gets comments, strings, numbers,
 * keywords, types, calls, annotations and markup right for everyday files, which is what an
 * on-device editor needs, without the cost or bulk of a real grammar.
 */
object SyntaxHighlighter {

    enum class Lang(
        /** Line-comment marker used by the editor's "toggle comment" action, or null if there is none. */
        val commentPrefix: String?,
        /** Code gets bracket/quote auto-pairing; prose (Markdown, plain text) does not. */
        val isCode: Boolean,
        /** A line ending in `:` opens an indented block (Python, YAML). */
        val colonBlocks: Boolean = false,
        /** Indent width used when the file itself does not show one. */
        val defaultIndent: Int = 4
    ) {
        KOTLIN("//", true),
        JAVA("//", true),
        JAVASCRIPT("//", true, defaultIndent = 2),
        C_LIKE("//", true),
        GRADLE("//", true, defaultIndent = 4),
        PYTHON("#", true, colonBlocks = true),
        SHELL("#", true, defaultIndent = 2),
        YAML("#", true, colonBlocks = true, defaultIndent = 2),
        PROPERTIES("#", true),
        XML(null, true, defaultIndent = 2),
        JSON(null, true, defaultIndent = 2),
        MARKDOWN(null, false, defaultIndent = 2),
        PLAIN(null, false)
    }

    /** Marks the spans this object adds, so [applySpans] can remove exactly its own and nothing else. */
    class TokenSpan(color: Int) : ForegroundColorSpan(color)

    // ── Palette (dark, VS Code-like) ──────────────────────────────────────────
    private val C_COMMENT    = 0xFF6A9955.toInt()
    private val C_STRING     = 0xFFCE9178.toInt()
    private val C_NUMBER     = 0xFFB5CEA8.toInt()
    private val C_KEYWORD    = 0xFF569CD6.toInt()
    private val C_TYPE       = 0xFF4EC9B0.toInt()
    private val C_FUNCTION   = 0xFFDCDCAA.toInt()
    private val C_ANNOTATION = 0xFFD7BA7D.toInt()
    private val C_ATTRIBUTE  = 0xFF9CDCFE.toInt()
    private val C_KEY        = 0xFF7EC4E8.toInt()

    private const val Q = "\""

    private class Rule(val regex: String, val color: Int)

    private class Spec(val pattern: Pattern, val colors: IntArray)

    private val EMPTY = IntArray(0)
    private val cache = ConcurrentHashMap<Lang, Spec>()
    private val broken = ConcurrentHashMap.newKeySet<Lang>()

    fun languageFor(fileName: String): Lang {
        val lower = fileName.lowercase()
        val ext = lower.substringAfterLast('.', "")
        return when {
            lower == "dockerfile" || lower == "makefile" || lower == "cmakelists.txt" -> Lang.SHELL
            lower.endsWith(".gradle") -> Lang.GRADLE
            ext == "kt" || ext == "kts" -> Lang.KOTLIN
            ext == "java" -> Lang.JAVA
            ext in setOf("js", "mjs", "cjs", "jsx", "ts", "tsx") -> Lang.JAVASCRIPT
            ext == "py" -> Lang.PYTHON
            ext in setOf("c", "h", "cpp", "cc", "cxx", "hpp", "hh", "cs", "go", "rs", "swift", "dart", "scala", "php", "glsl", "frag", "vert") -> Lang.C_LIKE
            ext in setOf("sh", "bash", "zsh", "cmake") -> Lang.SHELL
            ext in setOf("yml", "yaml") -> Lang.YAML
            ext in setOf("properties", "toml", "ini", "cfg", "conf", "env") -> Lang.PROPERTIES
            ext in setOf("xml", "html", "htm", "svg", "xhtml", "plist") -> Lang.XML
            ext in setOf("json", "json5", "jsonc") -> Lang.JSON
            ext in setOf("md", "markdown") -> Lang.MARKDOWN
            else -> Lang.PLAIN
        }
    }

    /**
     * The indent the file already uses — a tab if tabs lead its indented lines, otherwise the
     * smallest space indent among the first indented lines — or the language's usual width.
     */
    fun detectIndent(text: String, lang: Lang): String {
        var tabLines = 0
        var spaceLines = 0
        var smallest = Int.MAX_VALUE
        var scanned = 0
        var pos = 0
        while (pos < text.length && scanned < 400) {
            val end = text.indexOf('\n', pos).let { if (it < 0) text.length else it }
            if (end > pos) {
                val first = text[pos]
                if (first == '\t') {
                    tabLines++
                } else if (first == ' ') {
                    var n = 0
                    while (pos + n < end && text[pos + n] == ' ') n++
                    // A line of nothing but spaces says nothing about the indent.
                    if (pos + n < end && n in 2..8) {
                        spaceLines++
                        if (n < smallest) smallest = n
                    }
                }
            }
            scanned++
            pos = end + 1
        }
        return when {
            tabLines > spaceLines -> "\t"
            spaceLines > 0 -> " ".repeat(smallest)
            else -> " ".repeat(lang.defaultIndent)
        }
    }

    /** Flat triples `start, end, color` for every colored token in [text]. */
    fun compute(text: String, lang: Lang): IntArray {
        val spec = specFor(lang) ?: return EMPTY
        val matcher = spec.pattern.matcher(text)
        var out = IntArray(3 * 512)
        var n = 0
        try {
            while (matcher.find()) {
                val start = matcher.start()
                val end = matcher.end()
                if (end <= start) continue
                var group = 1
                while (group <= spec.colors.size && matcher.start(group) < 0) group++
                if (group > spec.colors.size) continue
                if (n + 3 > out.size) out = out.copyOf(out.size * 2)
                out[n++] = start
                out[n++] = end
                out[n++] = spec.colors[group - 1]
            }
        } catch (_: StackOverflowError) {
            // A pathological line exhausted the regex engine's stack: keep what was found so far.
        } catch (_: RuntimeException) {
            // Same for any other engine failure — a partly colored file beats a crashed editor.
        }
        return out.copyOf(n)
    }

    /** Replaces this object's previous spans on [editable] with [spans] (as returned by [compute]). */
    fun applySpans(editable: Editable, spans: IntArray) {
        for (old in editable.getSpans(0, editable.length, TokenSpan::class.java)) editable.removeSpan(old)
        val length = editable.length
        var i = 0
        while (i + 2 < spans.size) {
            val start = spans[i]
            val end = minOf(spans[i + 1], length)
            if (start in 0 until end) {
                editable.setSpan(TokenSpan(spans[i + 2]), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            i += 3
        }
    }

    /** Removes every span this object added. */
    fun clear(editable: Editable) {
        for (old in editable.getSpans(0, editable.length, TokenSpan::class.java)) editable.removeSpan(old)
    }

    // ── Rule sets ─────────────────────────────────────────────────────────────

    private fun specFor(lang: Lang): Spec? {
        if (lang == Lang.PLAIN || lang in broken) return null
        cache[lang]?.let { return it }
        val rules = rulesFor(lang)
        if (rules.isEmpty()) return null
        return try {
            val pattern = Pattern.compile(rules.joinToString("|") { "(${it.regex})" })
            Spec(pattern, IntArray(rules.size) { rules[it].color }).also { cache[lang] = it }
        } catch (_: PatternSyntaxException) {
            // A rule that fails to compile must never take the editor down — that language just goes uncolored.
            broken.add(lang)
            null
        }
    }

    private fun words(list: String) = "\\b(?:" + list.trim().split(Regex("\\s+")).joinToString("|") + ")\\b"

    private val blockComment = """/\*[\s\S]*?(?:\*/|\z)"""
    private val lineComment  = """//[^\n]*"""
    private val tripleDq     = "$Q$Q$Q[\\s\\S]*?(?:$Q$Q$Q|\\z)"
    // Strings use the "unrolled loop" form (plain run, then escape + plain run, all possessive) rather
    // than (?:[^"\\]|\\.)*: the same match, but no group recursion per character (a 100 KB minified line
    // can't overflow the regex stack) and no backtracking. The closing quote is optional, so an
    // unterminated string colors to the end of its line instead of failing and rescanning.
    private val doubleQuoted = "$Q[^$Q\\\\\\n]*+(?:\\\\.[^$Q\\\\\\n]*+)*+$Q?"
    private val singleQuoted = """'[^'\\\n]*+(?:\\.[^'\\\n]*+)*+'?"""
    private val backtick     = """`[^`\\]*+(?:\\[\s\S][^`\\]*+)*+`?"""
    private val annotation   = """@[A-Za-z_][A-Za-z0-9_.]*"""
    private val number       = """\b(?:0[xX][0-9a-fA-F_]+|0[bB][01_]+|\d[\d_]*(?:\.\d+)?(?:[eE][+-]?\d+)?)[fFdDlLuU]*\b"""
    private val typeName     = """\b[A-Z][A-Za-z0-9_]*\b"""
    private val call         = """\b[a-z_][A-Za-z0-9_]*(?=\s*\()"""

    private fun cLike(keywords: String, extra: List<Rule> = emptyList()): List<Rule> = listOf(
        Rule(blockComment, C_COMMENT),
        Rule(lineComment, C_COMMENT),
        Rule(tripleDq, C_STRING),
        Rule(doubleQuoted, C_STRING),
        Rule(singleQuoted, C_STRING),
    ) + extra + listOf(
        Rule(annotation, C_ANNOTATION),
        Rule(number, C_NUMBER),
        Rule(words(keywords), C_KEYWORD),
        Rule(typeName, C_TYPE),
        Rule(call, C_FUNCTION)
    )

    private fun rulesFor(lang: Lang): List<Rule> = when (lang) {
        Lang.KOTLIN -> cLike(KOTLIN_KEYWORDS)
        Lang.JAVA -> cLike(JAVA_KEYWORDS)
        Lang.GRADLE -> cLike(GROOVY_KEYWORDS)
        Lang.JAVASCRIPT -> cLike(JS_KEYWORDS, listOf(Rule(backtick, C_STRING)))
        Lang.C_LIKE -> cLike(C_KEYWORDS, listOf(Rule("""(?m:^[ \t]*#[ \t]*[A-Za-z_]+)""", C_ANNOTATION)))

        Lang.PYTHON -> listOf(
            Rule("""#[^\n]*""", C_COMMENT),
            Rule(tripleDq + "|'''[\\s\\S]*?(?:'''|\\z)", C_STRING),
            Rule(doubleQuoted, C_STRING),
            Rule(singleQuoted, C_STRING),
            Rule("""(?m:^[ \t]*@[A-Za-z_][\w.]*)""", C_ANNOTATION),
            Rule(number, C_NUMBER),
            Rule(words(PYTHON_KEYWORDS), C_KEYWORD),
            Rule(typeName, C_TYPE),
            Rule(call, C_FUNCTION)
        )

        Lang.SHELL -> listOf(
            Rule("""(?<![\w$])#[^\n]*""", C_COMMENT),
            Rule(doubleQuoted, C_STRING),
            Rule("""'[^']*'?""", C_STRING),
            Rule("""[$](?:\{[^}\n]*\}?|[A-Za-z_][A-Za-z0-9_]*|[0-9@#?*!-])""", C_ATTRIBUTE),
            Rule(number, C_NUMBER),
            Rule(words(SHELL_KEYWORDS), C_KEYWORD)
        )

        Lang.YAML -> listOf(
            Rule("""(?m:(?:^|(?<=[ \t]))#[^\n]*)""", C_COMMENT),
            Rule(doubleQuoted, C_STRING),
            Rule("""'[^'\n]*+(?:''[^'\n]*+)*+'?""", C_STRING),
            // Leading "- " list markers, then the key; written so a long run of dashes can't be split two ways.
            Rule("""(?m:^[ \t]*(?:-[ \t]+)*+[A-Za-z0-9_./-]++(?=[ \t]*:(?:[ \t]|$)))""", C_KEY),
            Rule("""[&*][A-Za-z0-9_-]+""", C_ANNOTATION),
            Rule("""(?m:^(?:---|\.\.\.)[ \t]*$)""", C_KEYWORD),
            Rule("""\b(?:true|false|null|yes|no|on|off|True|False|Null)\b""", C_KEYWORD),
            Rule("""\b\d+(?:\.\d+)?\b""", C_NUMBER)
        )

        Lang.PROPERTIES -> listOf(
            Rule("""(?m:^[ \t]*[#;!][^\n]*)""", C_COMMENT),
            Rule("""(?m:^[ \t]*\[[^\]\n]*\])""", C_TYPE),
            Rule("""(?m:^[ \t]*[A-Za-z0-9_.-]+(?=[ \t]*[=:]))""", C_KEY),
            Rule(doubleQuoted, C_STRING),
            Rule("""\b(?:true|false)\b""", C_KEYWORD),
            Rule("""\b\d+(?:\.\d+)?\b""", C_NUMBER)
        )

        Lang.JSON -> listOf(
            Rule(blockComment, C_COMMENT),
            Rule(lineComment, C_COMMENT),
            Rule("$Q[^$Q\\\\\\n]*+(?:\\\\.[^$Q\\\\\\n]*+)*+$Q(?=\\s*:)", C_KEY),
            Rule(doubleQuoted, C_STRING),
            Rule("""-?\b\d+(?:\.\d+)?(?:[eE][+-]?\d+)?\b""", C_NUMBER),
            Rule("""\b(?:true|false|null)\b""", C_KEYWORD)
        )

        Lang.XML -> listOf(
            Rule("""<!--[\s\S]*?(?:-->|\z)""", C_COMMENT),
            Rule("""<!\[CDATA\[[\s\S]*?(?:\]\]>|\z)""", C_STRING),
            Rule("""<[?!][^>]*>?""", C_ANNOTATION),
            Rule("""</?[A-Za-z_][\w:.-]*""", C_KEYWORD),
            Rule("(?<==)(?:$Q[^$Q]*$Q?|'[^']*'?)", C_STRING),
            Rule("""(?<![\w:.-])[A-Za-z_][\w:.-]*+(?=\s*=)""", C_ATTRIBUTE),
            Rule("""/?>""", C_KEYWORD),
            Rule("""&#?\w+;""", C_NUMBER)
        )

        Lang.MARKDOWN -> listOf(
            Rule("""```[\s\S]*?(?:```|\z)""", C_STRING),
            Rule("""(?m:^#{1,6}[ \t].*$)""", C_KEYWORD),
            Rule("""`[^`\n]+`""", C_STRING),
            Rule("""\*\*[^*\n]+\*\*|__[^_\n]+__""", C_FUNCTION),
            Rule("""!?\[[^\]\[\n]*+\]\([^)\n]*+\)""", C_TYPE),
            Rule("""(?m:^[ \t]*(?:[-*+]|\d+\.)[ \t])""", C_KEYWORD),
            Rule("""(?m:^>.*$)""", C_COMMENT)
        )

        Lang.PLAIN -> emptyList()
    }

    private const val KOTLIN_KEYWORDS = """
        abstract annotation as break by catch class companion const constructor continue crossinline data do else
        enum external false final finally for fun get if import in infix init inline inner interface internal is
        it lateinit lazy noinline null object open operator out override package private protected public reified
        return sealed set super suspend tailrec this throw true try typealias typeof val value var vararg when where while
    """

    private const val JAVA_KEYWORDS = """
        abstract assert boolean break byte case catch char class const continue default do double else enum extends
        final finally float for goto if implements import instanceof int interface long native new null package
        private protected public return short static strictfp super switch synchronized this throw throws transient
        true false try var void volatile while record sealed permits yield
    """

    private const val GROOVY_KEYWORDS = """
        def if else for while return class interface import package new null true false in as try catch finally
        throw static final void boolean int long String it this super extends implements switch case default
        break continue
    """

    private const val JS_KEYWORDS = """
        async await break case catch class const continue debugger default delete do else enum export extends false
        finally for from function get if implements import in instanceof interface let new null of package private
        protected public return set static super switch this throw true try type typeof undefined var void while
        with yield as readonly declare namespace abstract
    """

    private const val PYTHON_KEYWORDS = """
        and as assert async await break class continue def del elif else except finally for from global if import in
        is lambda nonlocal not or pass raise return try while with yield True False None match case self
    """

    private const val C_KEYWORDS = """
        alignas alignof and asm auto bool break case catch char class const constexpr const_cast continue decltype
        default delete do double dynamic_cast else enum explicit export extern false float for friend goto if inline
        int long mutable namespace new noexcept nullptr operator private protected public register reinterpret_cast
        return short signed sizeof static static_assert static_cast struct switch template this throw true try
        typedef typeid typename union unsigned using virtual void volatile while NULL fn mut pub impl trait
        func var interface package defer async await readonly
    """

    private const val SHELL_KEYWORDS = """
        if then else elif fi for while do done case esac in function select until return exit export local readonly
        declare unset echo cd set shift source alias eval exec trap test true false
    """
}
