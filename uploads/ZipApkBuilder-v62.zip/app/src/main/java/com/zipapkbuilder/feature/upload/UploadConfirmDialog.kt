package com.zipapkbuilder.feature.upload

import android.app.AlertDialog
import android.net.Uri
import android.view.View
import com.zipapkbuilder.MainActivity
import com.zipapkbuilder.R
import com.zipapkbuilder.core.ButtonTone
import com.zipapkbuilder.core.DialogAction
import com.zipapkbuilder.core.Formatters
import com.zipapkbuilder.core.UriUtils
import com.zipapkbuilder.core.dialogChip
import com.zipapkbuilder.core.dialogMessage
import com.zipapkbuilder.core.dialogStack
import com.zipapkbuilder.core.dialogTitleBar
import com.zipapkbuilder.core.dialogWithActions

/**
 * The last step before files picked in the File Manager are uploaded: shows what is about to be
 * sent and which repo folder it goes to, with a "Change folder" action — so the destination is a
 * choice made at the upload itself rather than a preference tucked away in Settings.
 */
class UploadConfirmDialog(private val activity: MainActivity) {

    /**
     * [folder] is the starting destination (the folder the File Manager was showing); the person
     * can swap it through [UploadDestinationPicker], which reopens this dialog with the new folder.
     * [onConfirm] gets the folder to upload into.
     */
    fun show(uris: List<Uri>, folder: String, onConfirm: (folder: String) -> Unit) {
        if (activity.isFinishing || activity.isDestroyed) return
        val resolver = activity.contentResolver

        val parts = uris.take(4).map { uri ->
            val size = UriUtils.querySize(resolver, uri)
            activity.dialogChip(
                UriUtils.resolveUploadFileName(resolver, uri),
                R.drawable.ic_file,
                ButtonTone.PRIMARY,
                meta = if (size != null) Formatters.fmtBytes(size) else null
            )
        }.toMutableList<View>()
        if (uris.size > 4) parts.add(activity.dialogMessage("…and ${uris.size - 4} more"))
        parts.add(activity.dialogMessage("Upload to this folder of the repo:"))
        parts.add(activity.dialogChip(UploadDestination.label(folder), R.drawable.ic_folder, ButtonTone.ORANGE))

        lateinit var dlg: AlertDialog
        val content = activity.dialogWithActions(
            activity.dialogStack(*parts.toTypedArray()),
            DialogAction("Upload", ButtonTone.GREEN, R.drawable.ic_cloud_upload) {
                dlg.dismiss()
                onConfirm(folder)
            },
            DialogAction("Change folder", ButtonTone.BLUE, R.drawable.ic_folder) {
                dlg.dismiss()
                activity.uploadDestinationPicker.showFolderChooser("Upload to…", folder) { picked ->
                    show(uris, picked, onConfirm)
                }
            },
            DialogAction("Cancel", ButtonTone.SURFACE, R.drawable.ic_close) { dlg.dismiss() },
            stacked = true
        )
        val title = if (uris.size == 1) "Upload file" else "Upload ${uris.size} files"
        dlg = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
            .setCustomTitle(activity.dialogTitleBar(title, R.drawable.ic_cloud_upload, ButtonTone.PRIMARY) { dlg.dismiss() })
            .setView(content)
            .show()
    }
}
