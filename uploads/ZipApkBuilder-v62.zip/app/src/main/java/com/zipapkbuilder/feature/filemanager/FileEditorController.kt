package com.zipapkbuilder.feature.filemanager

import com.zipapkbuilder.MainActivity
import com.zipapkbuilder.core.Formatters
import com.zipapkbuilder.core.TextBytes
import com.zipapkbuilder.model.RepoItem
import com.zipapkbuilder.net.GitHubApi

/**
 * Views, edits, saves, and copies the content of a single repo file — the
 * GitHub reads/writes behind the code editor ([CodeEditorDialog] is the editor
 * UI itself: full screen, live syntax coloring, undo/redo, find & replace…).
 * Split out of [FileManagerController] so the file's fetch/commit logic doesn't
 * share a file with browsing or file-operation concerns.
 *
 * [refreshBrowser] re-opens the browser dialog at a given path after a save
 * completes — passed in rather than depending on [FileBrowserController]
 * directly, since that class in turn depends on this one to handle the
 * "View / Edit" menu action; a plain callback avoids a circular class
 * reference between the two.
 */
class FileEditorController(
    private val activity: MainActivity,
    private val refreshBrowser: (token: String, owner: String, repo: String, branch: String, path: String) -> Unit
) {

    /** Fetches file content from GitHub and opens the editor dialog. */
    fun fetchAndViewFile(
        token: String, owner: String, repo: String, branch: String,
        item: RepoItem, currentPath: String
    ) {
        activity.setBusy(true)
        activity.appendLog("Loading ${item.name} …")
        activity.bgExecutor.execute {
            try {
                val bytes: ByteArray
                var sha = item.sha
                if (item.size >= GitHubApi.CONTENTS_API_SIZE_LIMIT) {
                    // The Contents API omits `content` entirely for files this large —
                    // go straight to the Git Data API's blob endpoint, which has no such
                    // limit. A file this size can never legitimately decode to zero
                    // bytes, so a null here is a real fetch failure, not "binary/empty".
                    bytes = GitHubApi.fetchBlobBytes(token, owner, repo, item.sha)
                        ?: throw Exception("Could not fetch ${item.path} (${Formatters.fmtBytes(item.size)}) from blob storage")
                    // sha is unchanged — it's exactly what was requested by.
                } else {
                    val (code, body) = GitHubApi.httpGet(token, GitHubApi.apiContents(owner, repo, item.path, branch))
                    if (code != 200) throw Exception("HTTP $code fetching ${item.path}")
                    val obj = org.json.JSONObject(body)
                    sha = obj.optString("sha", item.sha)
                    // GitHub wraps base64 at 60 chars — strip all whitespace before decoding
                    val raw  = obj.optString("content", "").replace("\n", "").replace("\r", "")
                    bytes = try { android.util.Base64.decode(raw, android.util.Base64.DEFAULT) } catch (e: Exception) { ByteArray(0) }
                }
                // Strict decoding: String(bytes, UTF_8) never fails, it silently swaps invalid bytes for
                // U+FFFD — so a binary file would open as editable garbage and saving it would corrupt
                // it. null here means "not valid UTF-8 text", and the file opens read-only instead.
                // A zero-byte file is a perfectly good (empty) text file; empty bytes for a file that
                // has a size means the content could not be read, which must never be saved over.
                val decoded = TextBytes.decodeUtf8OrNull(bytes)
                val unreadable = when {
                    bytes.isEmpty() && item.size > 0L -> "This file's content could not be read, so it can't be edited here."
                    decoded == null -> "This looks like a binary file, so it can't be edited as text."
                    else -> null
                }
                val text = if (unreadable == null) decoded ?: "" else ""
                activity.mainHandler.post {
                    activity.setBusy(false)
                    if (activity.isFinishing || activity.isDestroyed) return@post
                    showFileEditorDialog(token, owner, repo, branch, item.copy(sha = sha), text, unreadable, currentPath)
                }
            } catch (e: Exception) {
                activity.appendLog("[error] ${e.message}")
                activity.mainHandler.post { activity.setBusy(false) }
            }
        }
    }

    /**
     * Opens [CodeEditorDialog] for the file. Saving commits through [saveFileContent]; the dialog
     * stays open (edits intact) until that reports success, and shows the reason if it fails.
     * [unreadableReason] is set for a file that can't be edited as text, which opens read-only.
     */
    private fun showFileEditorDialog(
        token: String, owner: String, repo: String, branch: String,
        item: RepoItem, content: String, unreadableReason: String?, currentPath: String
    ) {
        CodeEditorDialog(
            activity = activity,
            fileName = item.name,
            branch = branch,
            original = content,
            unreadableReason = unreadableReason
        ) { newText, done ->
            activity.setBusy(true)
            activity.bgExecutor.execute { saveFileContent(token, owner, repo, branch, item, newText, currentPath, done) }
        }.show()
    }

    /** Encodes and PUTs the new file content to GitHub. */
    private fun saveFileContent(
        token: String, owner: String, repo: String, branch: String,
        item: RepoItem, newContent: String, refreshPath: String,
        done: (error: String?) -> Unit
    ) {
        try {
            val encoded = android.util.Base64.encodeToString(
                newContent.toByteArray(Charsets.UTF_8), android.util.Base64.NO_WRAP
            )
            val payload = org.json.JSONObject().apply {
                put("message", "edit: update ${item.path} via ZipApkBuilder [skip ci]")
                put("content", encoded)
                put("sha",     item.sha)
                put("branch",  branch)
            }.toString()
            val (code, body) = GitHubApi.httpPut(token, GitHubApi.apiContents(owner, repo, item.path), payload)
            if (code in 200..201) {
                activity.appendLog("[ok] Saved: ${item.path}")
                activity.mainHandler.post {
                    done(null)
                    refreshBrowser(token, owner, repo, branch, refreshPath)
                }
            } else {
                activity.appendLog("[error] Save failed ($code): ${body.take(150)}")
                activity.mainHandler.post {
                    activity.setBusy(false)
                    done(saveFailureMessage(code))
                }
            }
        } catch (e: Exception) {
            activity.appendLog("[error] ${e.message}")
            activity.mainHandler.post {
                activity.setBusy(false)
                done(e.message ?: "Save failed.")
            }
        }
    }

    /** What the editor shows (with the edits kept) when GitHub refuses a save. */
    private fun saveFailureMessage(code: Int): String = when (code) {
        409, 422 -> "the file changed on GitHub since you opened it. Tap Copy, reopen the file and paste your text in."
        401, 403 -> "GitHub refused the save. Check that your token can write to this repo."
        404 -> "the file or repo was not found."
        else -> "GitHub returned HTTP $code."
    }

    /** Fetches a file's content from GitHub and copies it to the clipboard. */
    fun fetchAndCopyFile(token: String, owner: String, repo: String, branch: String, item: RepoItem) {
        activity.setBusy(true)
        activity.appendLog("Fetching ${item.name} for copy …")
        activity.bgExecutor.execute {
            try {
                val bytes: ByteArray = if (item.size >= GitHubApi.CONTENTS_API_SIZE_LIMIT) {
                    // Same >=1MB Contents-API gap as fetchAndViewFile — see its comment.
                    GitHubApi.fetchBlobBytes(token, owner, repo, item.sha)
                        ?: throw Exception("Could not fetch ${item.path} (${Formatters.fmtBytes(item.size)}) from blob storage")
                } else {
                    val (code, body) = GitHubApi.httpGet(token, GitHubApi.apiContents(owner, repo, item.path, branch))
                    if (code != 200) throw Exception("HTTP $code")
                    val raw = org.json.JSONObject(body).optString("content", "")
                        .replace("\n", "").replace("\r", "")
                    android.util.Base64.decode(raw, android.util.Base64.DEFAULT)
                }
                val text  = String(bytes, Charsets.UTF_8)
                activity.mainHandler.post {
                    activity.setBusy(false)
                    val cm = activity.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    cm.setPrimaryClip(android.content.ClipData.newPlainText(item.name, text))
                    activity.appendLog("Copied ${item.name} to clipboard (${text.length} chars).")
                }
            } catch (e: Exception) {
                activity.appendLog("[error] ${e.message}")
                activity.mainHandler.post { activity.setBusy(false) }
            }
        }
    }
}
