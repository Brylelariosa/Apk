package com.zipapkbuilder.feature.upload

import android.app.AlertDialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import com.zipapkbuilder.MainActivity
import com.zipapkbuilder.R
import com.zipapkbuilder.core.BoundedListView
import com.zipapkbuilder.core.ButtonTone
import com.zipapkbuilder.core.DialogAction
import com.zipapkbuilder.core.IconMenuAdapter
import com.zipapkbuilder.core.IconMenuRow
import com.zipapkbuilder.core.dialogMessage
import com.zipapkbuilder.core.dialogTitleBar
import com.zipapkbuilder.core.dialogWithActions
import com.zipapkbuilder.feature.build.BuildFlowController
import com.zipapkbuilder.net.GitHubApi
import org.json.JSONArray

/**
 * The dialogs for choosing where an upload goes inside the repo — the replacement for the
 * old "Upload ZIP to repo root" switch in Settings, so the choice is made at the moment of
 * uploading instead of in a preference screen.
 *
 * - [showBuildZipChooser]: the main screen's "Upload to" row. The two folders the build
 *   workflow triggers on (`uploads/` and the repo root), plus "Sync changes into repo", which
 *   uploads no ZIP at all (see [UploadDestination.SYNC]).
 * - [showFolderChooser]: a plain "Upload to repo" (a file received from another app, or the
 *   File Manager's Upload file) — quick picks, recent folders, a typed path, or browsing the
 *   repo's real folders.
 *
 * Everything reports through the `onPicked` callback with a folder path from
 * [UploadDestination] (`""` is the repo root); nothing here uploads anything itself.
 */
class UploadDestinationPicker(private val activity: MainActivity) {

    /** True while a folder listing is being fetched, so a double tap can't open two browsers. */
    @Volatile private var loadingFolders = false

    // ── Build ZIP: uploads/ or repo root ──────────────────────────────────────

    fun showBuildZipChooser(current: String, onPicked: (String) -> Unit) {
        val green  = 0xFF2ECC71.toInt()
        val orange = 0xFFFF9F43.toInt()
        val blue   = 0xFF4DA6FF.toInt()
        val isSync = UploadDestination.isSync(current)
        val isRoot = current.isEmpty()
        val isUploads = !isSync && !isRoot
        val rows = listOf(
            IconMenuRow(
                "uploads/ folder",
                if (isUploads) R.drawable.ic_check else R.drawable.ic_folder,
                if (isUploads) green else orange,
                subtitle = "Default · works with every existing build.yml",
                labelColor = if (isUploads) green else null
            ),
            IconMenuRow(
                "Repo root",
                if (isRoot) R.drawable.ic_check else R.drawable.ic_folder,
                if (isRoot) green else orange,
                subtitle = "Top level of the repo · older repos may need a workflow update",
                labelColor = if (isRoot) green else null
            ),
            IconMenuRow(
                "Sync changes into repo",
                if (isSync) R.drawable.ic_check else R.drawable.ic_refresh,
                if (isSync) green else blue,
                subtitle = "Unpacks the ZIP on your phone, uploads only the files that differ (no big upload), then builds the repo",
                labelColor = if (isSync) green else null
            )
        )
        lateinit var dlg: AlertDialog
        dlg = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
            .setCustomTitle(activity.dialogTitleBar("Upload ZIP to…", R.drawable.ic_cloud_upload, ButtonTone.PRIMARY) { dlg.dismiss() })
            .setAdapter(IconMenuAdapter(activity, rows)) { _, which ->
                onPicked(
                    when (which) {
                        1 -> ""
                        2 -> UploadDestination.SYNC
                        else -> UploadDestination.DEFAULT_FOLDER
                    }
                )
            }
            .show()
    }

    // ── Any file: any folder in the repo ──────────────────────────────────────

    /**
     * [suggested] is the folder offered first as "This folder" (the one the File Manager is
     * showing, say); pass null when there isn't one.
     */
    fun showFolderChooser(title: String, suggested: String?, onPicked: (String) -> Unit) {
        val orange = 0xFFFF9F43.toInt()
        val blue   = 0xFF4DA6FF.toInt()
        val entries = mutableListOf<Pair<IconMenuRow, () -> Unit>>()
        val offered = mutableSetOf<String>()

        fun addFolder(folder: String, label: String, subtitle: String) {
            if (!offered.add(folder)) return
            entries.add(IconMenuRow(label, R.drawable.ic_folder, orange, subtitle = subtitle) to { pick(folder, onPicked) })
        }

        if (suggested != null) addFolder(suggested, "This folder", UploadDestination.label(suggested))
        addFolder("", "Repo root", "Top level of the repo")
        addFolder(UploadDestination.DEFAULT_FOLDER, "uploads/", "The folder the build workflow watches")
        UploadDestination.recentFolders(activity.prefs).forEach { addFolder(it, UploadDestination.label(it), "Recent") }

        entries.add(IconMenuRow("Browse repo folders…", R.drawable.ic_search, blue, subtitle = "Pick any folder that already exists") to {
            browseFolders(suggested ?: "", onPicked)
        })
        entries.add(IconMenuRow("Type a folder path…", R.drawable.ic_edit, blue, subtitle = "Created automatically if it's new") to {
            promptTypedFolder(suggested ?: "", onPicked)
        })

        lateinit var dlg: AlertDialog
        dlg = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
            .setCustomTitle(activity.dialogTitleBar(title, R.drawable.ic_cloud_upload, ButtonTone.PRIMARY) { dlg.dismiss() })
            .setAdapter(IconMenuAdapter(activity, entries.map { it.first })) { _, which -> entries[which].second() }
            .show()
    }

    private fun pick(folder: String, onPicked: (String) -> Unit) {
        UploadDestination.rememberFolder(activity.prefs, folder)
        onPicked(folder)
    }

    // ── Typed path ────────────────────────────────────────────────────────────

    private fun promptTypedFolder(initial: String, onPicked: (String) -> Unit) {
        val input = EditText(activity).apply {
            hint = "folder/sub-folder"
            setText(initial)
            setSelection(text.length)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
            setPadding(64, 24, 64, 24)
        }
        val body = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            addView(activity.dialogMessage("Leave it empty for the repo root. Folders that don't exist yet are created by the upload."))
            addView(input)
        }
        lateinit var dlg: AlertDialog
        val content = activity.dialogWithActions(
            body,
            DialogAction("Use folder", ButtonTone.GREEN, R.drawable.ic_check) {
                val folder = UploadDestination.normalize(input.text.toString())
                dlg.dismiss()
                pick(folder, onPicked)
            },
            DialogAction("Cancel", ButtonTone.SURFACE, R.drawable.ic_close) { dlg.dismiss() }
        )
        dlg = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
            .setCustomTitle(activity.dialogTitleBar("Folder path", R.drawable.ic_edit, ButtonTone.BLUE) { dlg.dismiss() })
            .setView(content)
            .show()
    }

    // ── Repo folder browser ───────────────────────────────────────────────────

    private fun browseFolders(startPath: String, onPicked: (String) -> Unit) {
        val token  = activity.etToken.text.toString().trim()
        val repo   = activity.etRepo.text.toString().trim()
        val branch = activity.etBranch.text.toString().trim().ifEmpty { "main" }
        if (token.isEmpty() || repo.isEmpty()) {
            activity.appendLog("[warn] Set your GitHub token and repository in Settings first.")
            return
        }
        loadAndShow(token, repo, branch, startPath, onPicked)
    }

    /** Lists [path]'s subfolders on the background executor, then opens the browser dialog for it. */
    private fun loadAndShow(token: String, repo: String, branch: String, path: String, onPicked: (String) -> Unit) {
        if (loadingFolders) return
        loadingFolders = true
        activity.appendLog("Loading ${UploadDestination.label(path)} …")
        activity.bgExecutor.execute {
            try {
                val owner = activity.lastOwner.ifEmpty {
                    BuildFlowController.fetchOwner(token) ?: throw Exception("Token invalid or no network.")
                }
                activity.lastOwner = owner
                val folders = listSubfolders(token, owner, repo, branch, path)
                activity.mainHandler.post {
                    if (activity.isFinishing || activity.isDestroyed) return@post
                    showFolderBrowser(token, repo, branch, path, folders, onPicked)
                }
            } catch (e: Exception) {
                activity.appendLog("[error] ${e.message}")
            } finally {
                loadingFolders = false
            }
        }
    }

    private fun listSubfolders(token: String, owner: String, repo: String, branch: String, path: String): List<String> {
        val (code, body) = GitHubApi.httpGet(token, GitHubApi.apiContents(owner, repo, path, branch))
        if (code == 404) return emptyList()
        if (code != 200) throw Exception("HTTP $code listing ${UploadDestination.label(path)}")
        val arr = JSONArray(body)
        val names = ArrayList<String>()
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            if (obj.optString("type") == "dir") names.add(obj.getString("name"))
        }
        names.sortBy { it.lowercase() }
        return names
    }

    private fun showFolderBrowser(
        token: String, repo: String, branch: String,
        path: String, folders: List<String>, onPicked: (String) -> Unit
    ) {
        val rows = mutableListOf<IconMenuRow>()
        val opens = mutableListOf<String>()          // folder each row navigates to
        if (path.isNotEmpty()) {
            val parent = path.substringBeforeLast('/', "")
            rows.add(IconMenuRow("Up one level", R.drawable.ic_chevron_left, 0xFF9AA0B8.toInt(), subtitle = UploadDestination.label(parent)))
            opens.add(parent)
        }
        folders.forEach { name ->
            rows.add(IconMenuRow(name, R.drawable.ic_folder, 0xFFFF9F43.toInt()))
            opens.add(if (path.isEmpty()) name else "$path/$name")
        }

        lateinit var dlg: AlertDialog
        val maxListHeight = (activity.resources.displayMetrics.heightPixels * 0.4f).toInt()
        val menuAdapter = IconMenuAdapter(activity, rows)
        val body: View = if (rows.isEmpty()) {
            activity.dialogMessage("No subfolders here. Use this folder, or cancel and type a path.")
        } else {
            BoundedListView(activity, maxListHeight).apply {
                adapter = menuAdapter
                setBackgroundColor(Color.parseColor("#13162A"))
                divider = ColorDrawable(Color.parseColor("#1C2038"))
                dividerHeight = 1
                setOnItemClickListener { _, _, which, _ ->
                    dlg.dismiss()
                    loadAndShow(token, repo, branch, opens[which], onPicked)
                }
            }
        }
        val content = activity.dialogWithActions(
            body,
            DialogAction("Use this folder", ButtonTone.GREEN, R.drawable.ic_check) {
                dlg.dismiss()
                pick(path, onPicked)
            },
            DialogAction("Cancel", ButtonTone.SURFACE, R.drawable.ic_close) { dlg.dismiss() }
        )
        dlg = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
            .setCustomTitle(activity.dialogTitleBar("Choose folder", R.drawable.ic_folder, ButtonTone.ORANGE, subtitle = UploadDestination.label(path)) { dlg.dismiss() })
            .setView(content)
            .show()
    }
}
