package com.zipapkbuilder.feature.upload

import android.content.SharedPreferences
import com.zipapkbuilder.core.PrefKeys
import org.json.JSONArray

/**
 * Where an upload lands inside the repo, as a folder path: `""` is the repo root, anything
 * else is a folder like `uploads` or `app/src/main/assets` (no leading/trailing slash).
 *
 * Replaces the old Settings switch "Upload ZIP to repo root". The destination is now picked
 * where the upload happens instead — on the main screen's "Upload to" row for the build ZIP,
 * and in [UploadDestinationPicker] for received files and File Manager uploads.
 */
object UploadDestination {

    /** The folder every existing `build.yml` watches, and the default for the build ZIP. */
    const val DEFAULT_FOLDER = "uploads"

    /**
     * Not a folder: the third choice of the main screen's "Upload to" row. The ZIP is not uploaded
     * at all — the phone unpacks it, compares every file with the repo and uploads only what
     * differs (the Rust sync engine), and the build then runs on the repo's own files.
     */
    const val SYNC = "@sync"

    fun isSync(folder: String): Boolean = folder == SYNC

    private const val RECENT_CAP = 5

    /**
     * Folder the build ZIP is uploaded to: [DEFAULT_FOLDER] or the repo root (`""`) — the only two
     * places the committed workflow triggers on (a ZIP pushed into the uploads folder, or a ZIP at
     * the top level of the repo), so those are the only two the build flow offers. An install that only has the old Settings switch saved keeps its
     * choice: the switch's value is read here until the new row has been used once.
     */
    fun buildZipFolder(prefs: SharedPreferences): String {
        if (prefs.contains(PrefKeys.PREF_UPLOAD_DEST)) {
            val saved = prefs.getString(PrefKeys.PREF_UPLOAD_DEST, DEFAULT_FOLDER) ?: DEFAULT_FOLDER
            return when {
                saved == SYNC -> SYNC
                saved.isEmpty() -> ""
                else -> DEFAULT_FOLDER
            }
        }
        return if (prefs.getBoolean(PrefKeys.PREF_UPLOAD_TO_ROOT, false)) "" else DEFAULT_FOLDER
    }

    /** Saves the build ZIP's destination: the repo root, [SYNC], or (anything else) [DEFAULT_FOLDER]. */
    fun setBuildZipFolder(prefs: SharedPreferences, folder: String) {
        val saved = when {
            folder == SYNC -> SYNC
            folder.isEmpty() -> ""
            else -> DEFAULT_FOLDER
        }
        prefs.edit().putString(PrefKeys.PREF_UPLOAD_DEST, saved).apply()
    }

    /** Repo path for [fileName] inside [folder]. */
    fun remotePath(folder: String, fileName: String): String =
        if (folder.isEmpty()) fileName else "$folder/$fileName"

    /** Human label for a folder: "Repo root" or "uploads/" (or the sync mode's name). */
    fun label(folder: String): String = when {
        isSync(folder) -> "Sync changes into repo"
        folder.isEmpty() -> "Repo root"
        else -> "$folder/"
    }

    /**
     * Cleans a typed or stored folder path: backslashes become slashes, blank, `.` and `..`
     * segments are dropped, and no leading or trailing slash is left. `""` means the repo root.
     */
    fun normalize(raw: String): String =
        raw.replace('\\', '/')
            .split('/')
            .map { it.trim() }
            .filter { it.isNotEmpty() && it != "." && it != ".." }
            .joinToString("/")

    /** The folders last picked for a plain upload, newest first (at most [RECENT_CAP]). */
    fun recentFolders(prefs: SharedPreferences): List<String> {
        val raw = prefs.getString(PrefKeys.PREF_RECENT_UPLOAD_DIRS, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { arr.optString(it, "") }.filter { it.isNotEmpty() }
        } catch (_: Exception) {
            emptyList()
        }
    }

    /** Puts [folder] first in the recent list. The repo root and [DEFAULT_FOLDER] are always offered anyway. */
    fun rememberFolder(prefs: SharedPreferences, folder: String) {
        if (folder.isEmpty() || folder == DEFAULT_FOLDER) return
        val updated = (listOf(folder) + recentFolders(prefs).filter { it != folder }).take(RECENT_CAP)
        val arr = JSONArray()
        updated.forEach { arr.put(it) }
        prefs.edit().putString(PrefKeys.PREF_RECENT_UPLOAD_DIRS, arr.toString()).apply()
    }
}
