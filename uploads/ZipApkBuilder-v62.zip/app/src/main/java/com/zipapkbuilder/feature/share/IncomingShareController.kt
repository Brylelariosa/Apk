package com.zipapkbuilder.feature.share

import android.app.AlertDialog
import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.core.content.IntentCompat
import com.zipapkbuilder.MainActivity
import com.zipapkbuilder.R
import com.zipapkbuilder.core.ButtonTone
import com.zipapkbuilder.core.DialogAction
import com.zipapkbuilder.core.Formatters
import com.zipapkbuilder.core.UriUtils
import com.zipapkbuilder.core.dialogChip
import com.zipapkbuilder.core.dialogMessage
import com.zipapkbuilder.core.dialogStack
import com.zipapkbuilder.core.dialogTitleBar
import com.zipapkbuilder.core.dialogWithActions
import java.io.File

/** A file another app sent to this one, already copied into this app's cache. */
data class ReceivedFile(val uri: Uri, val name: String, val size: Long, val isZip: Boolean)

/**
 * Reads what a share or "open with" intent carries and copies it into `cacheDir/incoming/`.
 *
 * The copy is deliberate: the read permission a sender grants through a share lasts only as
 * long as the receiving Activity, so a ZIP picked from the share sheet and built a few minutes
 * later (or after the system recreated the Activity) would otherwise fail with a permission
 * error. The copies are handed out as this app's own FileProvider URIs, which stay readable.
 */
object IncomingShare {

    private const val DIR = "incoming"
    private const val KEEP_MS = 3L * 24 * 60 * 60 * 1000

    private val ZIP_MIME_TYPES = setOf("application/zip", "application/x-zip-compressed", "application/x-zip")

    /** True for an intent that is a file/text share or an "open with" of a file. */
    fun isShare(intent: Intent): Boolean =
        intent.action == Intent.ACTION_SEND ||
            intent.action == Intent.ACTION_SEND_MULTIPLE ||
            (intent.action == Intent.ACTION_VIEW && intent.data != null)

    /** Blocking — call from a background thread. Throws only when nothing at all could be read. */
    fun importFrom(context: Context, intent: Intent): List<ReceivedFile> {
        val resolver = context.contentResolver
        val dir = File(File(context.cacheDir, DIR), System.currentTimeMillis().toString())
        if (!dir.mkdirs() && !dir.isDirectory) throw Exception("Could not create a temporary folder for the shared file.")

        val received = ArrayList<ReceivedFile>()
        var firstError: Exception? = null
        for (uri in collectUris(context, intent)) {
            try {
                received.add(copyIn(context, resolver, uri, dir))
            } catch (e: Exception) {
                if (firstError == null) firstError = e
            }
        }

        // Plain text with no file attached (a "Share" of a selection or a code block).
        if (received.isEmpty() && firstError == null && intent.action == Intent.ACTION_SEND) {
            val text = intent.getStringExtra(Intent.EXTRA_TEXT)
            if (!text.isNullOrEmpty()) {
                val file = File(dir, "shared_text_${Formatters.fmtFileStamp()}.txt")
                file.writeText(text)
                received.add(ReceivedFile(toProviderUri(context, file), file.name, file.length(), false))
            }
        }

        if (received.isEmpty()) {
            dir.deleteRecursively()
            throw firstError ?: Exception("The share did not contain a file.")
        }
        return received
    }

    /** Removes received files older than a few days; called once at startup. */
    fun sweepOld(context: Context) {
        try {
            val cutoff = System.currentTimeMillis() - KEEP_MS
            File(context.cacheDir, DIR).listFiles()?.forEach { if (it.lastModified() < cutoff) it.deleteRecursively() }
        } catch (_: Exception) {
            // Housekeeping only.
        }
    }

    private fun collectUris(context: Context, intent: Intent): List<Uri> {
        val found = LinkedHashSet<Uri>()
        when (intent.action) {
            Intent.ACTION_SEND ->
                IntentCompat.getParcelableExtra(intent, Intent.EXTRA_STREAM, Uri::class.java)?.let { found.add(it) }
            Intent.ACTION_SEND_MULTIPLE ->
                IntentCompat.getParcelableArrayListExtra(intent, Intent.EXTRA_STREAM, Uri::class.java)?.let { found.addAll(it) }
            Intent.ACTION_VIEW ->
                intent.data?.let { found.add(it) }
        }
        intent.clipData?.let { clip ->
            for (i in 0 until clip.itemCount) clip.getItemAt(i).uri?.let { found.add(it) }
        }
        return found.filter { isAllowed(context, it) }
    }

    /**
     * Another app could aim a `file://` URI at this app's own private storage (saved settings,
     * the encrypted token) and hope the person uploads it to a repo. Those are never accepted.
     */
    private fun isAllowed(context: Context, uri: Uri): Boolean {
        if (uri.scheme != "file") return true
        val path = uri.path ?: return false
        val canonical = try { File(path).canonicalPath } catch (_: Exception) { return false }
        val dataDir = context.applicationInfo.dataDir
        return !canonical.startsWith(dataDir) && !canonical.contains("/data/data/") && !canonical.contains("/data/user/")
    }

    private fun copyIn(context: Context, resolver: ContentResolver, uri: Uri, dir: File): ReceivedFile {
        var name = UriUtils.resolveUploadFileName(resolver, uri)
        if (uri.scheme == "file" && name.startsWith("upload_")) {
            uri.lastPathSegment?.let { name = it.replace(Regex("[^a-zA-Z0-9._ \\-]"), "_") }
        }
        // A sender that names the file without an extension but declares it a ZIP.
        val mime = try { resolver.getType(uri) } catch (_: Exception) { null }
        if (!name.contains('.') && mime != null && mime in ZIP_MIME_TYPES) name += ".zip"

        var dest = File(dir, name)
        var n = 2
        while (dest.exists()) {
            val stem = name.substringBeforeLast('.', name)
            val ext = name.substringAfterLast('.', "")
            dest = File(dir, if (ext.isEmpty()) "$stem ($n)" else "$stem ($n).$ext")
            n++
        }

        UriUtils.openInputStreamOrThrow(resolver, uri).use { input ->
            dest.outputStream().use { out -> input.copyTo(out, 64 * 1024) }
        }
        return ReceivedFile(
            uri = toProviderUri(context, dest),
            name = dest.name,
            size = dest.length(),
            isZip = dest.name.lowercase().endsWith(".zip")
        )
    }

    private fun toProviderUri(context: Context, file: File): Uri =
        FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
}

/**
 * Handles a file sent to the app through the share sheet (the up-arrow on a file or ZIP in the
 * Claude app, Share in a file manager) or an "Open with". The file is copied in, a single ZIP
 * is selected as the project ZIP straight away, and a small dialog offers the next step:
 * build it, or upload it into the repo at a folder chosen right there.
 */
class IncomingShareController(private val activity: MainActivity) {

    /** The last intent handled, so handing the same one over twice can't import it twice. */
    private var lastHandled: Intent? = null

    fun handle(intent: Intent?) {
        if (intent == null || intent === lastHandled || !IncomingShare.isShare(intent)) return
        // Android re-delivers the original launch intent when a task is resumed from Recents.
        if (intent.flags and Intent.FLAG_ACTIVITY_LAUNCHED_FROM_HISTORY != 0) return
        lastHandled = intent

        if (activity.isBusy) {
            activity.appendLog("[warn] A task is running — share the file again once it has finished.")
            return
        }
        activity.appendLog("Receiving shared file…")
        activity.bgExecutor.execute {
            val received = try {
                IncomingShare.importFrom(activity.applicationContext, intent)
            } catch (e: Exception) {
                activity.appendLog("[error] Could not read the shared file: ${e.message}")
                return@execute
            }
            activity.mainHandler.post { onReceived(received) }
        }
    }

    private fun onReceived(files: List<ReceivedFile>) {
        if (activity.isFinishing || activity.isDestroyed) return
        files.forEach { activity.appendLog("[ok] Received ${it.name} (${Formatters.fmtBytes(it.size)})") }

        // One ZIP is the project ZIP right away — no dialog needed to just have it ready.
        val zip = if (files.size == 1 && files[0].isZip) files[0] else null
        if (zip != null) activity.selectProjectZip(zip.uri, zip.name)
        showReceivedDialog(files, zip)
    }

    private fun showReceivedDialog(files: List<ReceivedFile>, zip: ReceivedFile?) {
        val single = files.size == 1
        val chips = files.take(4).map {
            activity.dialogChip(
                it.name,
                if (it.isZip) R.drawable.ic_zip else R.drawable.ic_file,
                ButtonTone.PRIMARY,
                meta = Formatters.fmtBytes(it.size)
            )
        }.toMutableList<android.view.View>()
        if (files.size > 4) chips.add(activity.dialogMessage("…and ${files.size - 4} more"))
        chips.add(activity.dialogMessage(
            when {
                zip != null -> "Selected as your project ZIP, ready for Upload & build."
                single      -> "Choose what to do with it."
                else        -> "Choose where to send them."
            }
        ))
        val body = activity.dialogStack(*chips.toTypedArray())

        lateinit var dlg: AlertDialog
        val actions = mutableListOf<DialogAction>()
        if (zip != null) {
            actions.add(DialogAction("Upload & build", ButtonTone.GREEN, R.drawable.ic_cloud_upload) {
                dlg.dismiss()
                if (!activity.isBusy) activity.buildFlowController.startFlow(activity)
            })
        }
        actions.add(DialogAction("Upload to repo…", ButtonTone.BLUE, R.drawable.ic_folder) {
            dlg.dismiss()
            activity.uploadDestinationPicker.showFolderChooser("Upload to…", null) { folder ->
                activity.uploadSharedFiles(files.map { it.uri }, folder)
            }
        })
        actions.add(DialogAction(if (zip != null) "Keep as project ZIP" else "Close", ButtonTone.SURFACE, R.drawable.ic_close) { dlg.dismiss() })

        val content = activity.dialogWithActions(body, *actions.toTypedArray(), stacked = true)
        val title = when {
            zip != null -> "ZIP received"
            single      -> "File received"
            else        -> "${files.size} files received"
        }
        dlg = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
            .setCustomTitle(activity.dialogTitleBar(title, if (zip != null) R.drawable.ic_zip else R.drawable.ic_download, ButtonTone.GREEN) { dlg.dismiss() })
            .setView(content)
            .show()
    }
}
