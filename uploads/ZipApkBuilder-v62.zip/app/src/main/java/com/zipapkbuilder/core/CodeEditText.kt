package com.zipapkbuilder.core

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import android.text.InputFilter
import android.text.Selection
import android.view.KeyEvent
import android.view.View
import androidx.appcompat.widget.AppCompatEditText

/**
 * The editor's text field: an EditText that knows it holds code.
 *
 *  - undo/redo through its own [history] (also Ctrl+Z / Ctrl+Y on a hardware keyboard)
 *  - Enter keeps the previous line's indentation and adds one level after `{`, `(`, `[` (or `:`
 *    for Python/YAML); Enter between a bracket pair opens it onto its own line
 *  - typing `(`, `[`, `{` or a quote adds the closing one, and typing the closer steps over it
 *  - Tab / Shift+Tab indent and outdent the selected lines; [toggleComment] comments them
 *  - the line with the caret is shaded
 *
 * Auto-indent and auto-pairing are an [InputFilter], which sees every one-character change from
 * the keyboard — and, since Editable filters run for any replace, from the symbol row too. The
 * editor's own programmatic edits (undo, replace, loading a file) go through [replaceRaw] /
 * [setCode], which switch the filter off so they are applied exactly as given.
 *
 * Line numbers are drawn by [GutterView], which sits beside this view and reads its Layout, so
 * they stay aligned with wrapped lines.
 */
class CodeEditText(context: Context) : AppCompatEditText(context) {

    /** Fires whenever the caret or selection moves. May fire while the view is still being built. */
    var onCursorMoved: (() -> Unit)? = null

    /** Hardware shortcuts the editor can't handle itself (`'s'` save, `'f'` find); true if handled. */
    var onShortcut: ((Char) -> Boolean)? = null

    var indentUnit: String = "    "

    /** What Enter inserts: `"\n"`, or `"\r\n"` in a file that already uses Windows line endings. */
    var lineEnding: String = "\n"
    var autoIndent: Boolean = true
    var autoPair: Boolean = false
    var colonBlocks: Boolean = false
    var highlightCurrentLine: Boolean = true
    var currentLineColor: Int = 0x14FFFFFF

    val history = EditHistory()

    private var rawEdit = false
    private val lineShade = Paint()

    private val codeFilter = InputFilter { source, start, end, dest, dstart, dend ->
        if (rawEdit || end - start != 1) return@InputFilter null
        val typed = source[start]
        when {
            typed == '\n' && autoIndent -> {
                val edit = CodeEdits.newline(dest, dstart, dend, indentUnit, lineEnding, colonBlocks)
                placeCaret(dstart, edit)
                edit.text
            }
            dstart != dend -> null
            autoPair -> CodeEdits.pairOrStepOver(dest, dstart, typed)?.also { placeCaret(dstart, it) }?.text
            else -> null
        }
    }

    init {
        filters = arrayOf(codeFilter)
        addTextChangedListener(history)
    }

    // ── Typing behavior ───────────────────────────────────────────────────────

    /**
     * An InputFilter can't move the caret, so when the caret belongs somewhere other than after the
     * inserted text (between a new pair, past a stepped-over closer) it is placed once the change
     * has been applied.
     */
    private fun placeCaret(at: Int, edit: CodeEdits.Insertion) {
        if (edit.caretOffset == edit.text.length) return
        post {
            val target = at + edit.caretOffset
            if (target <= (text?.length ?: 0)) setSelection(target)
        }
    }

    // ── Programmatic edits ────────────────────────────────────────────────────

    /** Loads [content] as the whole document: no filtering, and undo starts from here. */
    fun setCode(content: String) {
        rawEdit = true
        try {
            setText(content)
        } finally {
            rawEdit = false
        }
        history.clear()
        setSelection(0)
    }

    /** Replaces `[start, end)` exactly as given, bypassing auto-indent and auto-pairing. */
    fun replaceRaw(start: Int, end: Int, replacement: CharSequence) {
        val editable = text ?: return
        val s = start.coerceIn(0, editable.length)
        val e = end.coerceIn(s, editable.length)
        rawEdit = true
        try {
            editable.replace(s, e, replacement)
        } finally {
            rawEdit = false
        }
    }

    fun undo(): Boolean {
        val editable = text ?: return false
        rawEdit = true
        try {
            return history.undo(editable)
        } finally {
            rawEdit = false
        }
    }

    fun redo(): Boolean {
        val editable = text ?: return false
        rawEdit = true
        try {
            return history.redo(editable)
        } finally {
            rawEdit = false
        }
    }

    /** Types [symbol] at the caret (over a selection) the way the keyboard would, auto-pairing included. */
    fun insertAtCaret(symbol: String) {
        val editable = text ?: return
        val a = minOf(selectionStart, selectionEnd).coerceAtLeast(0)
        val b = maxOf(selectionStart, selectionEnd).coerceAtLeast(0)
        editable.replace(a, b, symbol)
    }

    /** Moves the caret by [delta] characters. */
    fun moveCaret(delta: Int) {
        val length = text?.length ?: return
        setSelection((selectionEnd + delta).coerceIn(0, length))
    }

    /** Tab: a tab stop at a bare caret, otherwise indent every selected line (Shift+Tab: outdent). */
    fun tab(outdent: Boolean) {
        val editable = text ?: return
        if (!outdent && selectionStart == selectionEnd) {
            val at = selectionStart.coerceAtLeast(0)
            replaceRaw(at, at, CodeEdits.tabStop(editable, at, indentUnit))
            return
        }
        editLines { lines -> CodeEdits.indentLines(lines, indentUnit, outdent) }
    }

    /** Comments the selected lines with [prefix], or uncomments them if they all already are. */
    fun toggleComment(prefix: String) {
        editLines { lines -> CodeEdits.toggleComment(lines, prefix) }
    }

    /** Rewrites the whole lines the selection touches; one change, so one undo step. */
    private fun editLines(transform: (List<String>) -> List<String>) {
        val editable = text ?: return
        val whole = editable.toString()
        val a = minOf(selectionStart, selectionEnd).coerceIn(0, whole.length)
        val b = maxOf(selectionStart, selectionEnd).coerceIn(0, whole.length)
        val block = CodeEdits.lineBlock(whole, a, b)
        val lineStart = block[0]
        val lineEnd = block[1]
        val before = whole.substring(lineStart, lineEnd)
        val after = transform(before.split('\n')).joinToString("\n")
        if (after == before) return
        replaceRaw(lineStart, lineEnd, after)
        if (a != b) {
            Selection.setSelection(text, lineStart, lineStart + after.length)
        } else {
            val caret = (a + after.length - before.length).coerceIn(lineStart, lineStart + after.length)
            Selection.setSelection(text, caret)
        }
    }

    // ── Hardware keyboard ─────────────────────────────────────────────────────

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (event != null) {
            if (event.isCtrlPressed) {
                when (keyCode) {
                    KeyEvent.KEYCODE_Z -> { if (event.isShiftPressed) redo() else undo(); return true }
                    KeyEvent.KEYCODE_Y -> { redo(); return true }
                    KeyEvent.KEYCODE_S -> if (onShortcut?.invoke('s') == true) return true
                    KeyEvent.KEYCODE_F -> if (onShortcut?.invoke('f') == true) return true
                }
            }
            if (keyCode == KeyEvent.KEYCODE_TAB) {
                tab(event.isShiftPressed)
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    // ── Drawing / callbacks ───────────────────────────────────────────────────

    override fun onSelectionChanged(selStart: Int, selEnd: Int) {
        super.onSelectionChanged(selStart, selEnd)
        onCursorMoved?.invoke()
    }

    override fun onDraw(canvas: Canvas) {
        val textLayout = layout
        if (highlightCurrentLine && textLayout != null && selectionStart >= 0 && selectionStart == selectionEnd) {
            val line = textLayout.getLineForOffset(selectionStart)
            lineShade.color = currentLineColor
            canvas.drawRect(
                0f, (extendedPaddingTop + textLayout.getLineTop(line)).toFloat(),
                width.toFloat(), (extendedPaddingTop + textLayout.getLineBottom(line)).toFloat(),
                lineShade
            )
        }
        super.onDraw(canvas)
    }
}

/**
 * The line-number column beside a [CodeEditText]. It reads the editor's Layout and draws only the
 * lines currently on screen, numbering logical lines (a wrapped line carries one number), so it
 * costs the same on a 10-line file as on a 10,000-line one. The editor dialog invalidates it on
 * scroll, text and cursor changes and calls [fitWidth] when the line count or text size changes.
 */
class GutterView(context: Context, private val editor: CodeEditText) : View(context) {

    var textColor: Int = 0xFF495570.toInt()
    var currentColor: Int = 0xFFB0B8D0.toInt()
    var gutterColor: Int = 0xFF161B22.toInt()
    var dividerColor: Int = 0xFF232747.toInt()

    /** Number of lines in the document — only used to size the column. */
    var totalLines: Int = 1

    private val numberPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.MONOSPACE
        textAlign = Paint.Align.RIGHT
    }
    private val fillPaint = Paint()
    private val visible = Rect()
    private val sidePad = context.resources.displayMetrics.density * 8f

    /** Sizes the column to fit [totalLines] digits at the editor's current text size. */
    fun fitWidth() {
        numberPaint.textSize = editor.textSize * 0.85f
        val digits = maxOf(2, totalLines.toString().length)
        val needed = Math.ceil((numberPaint.measureText("0") * digits + sidePad * 2).toDouble()).toInt()
        val params = layoutParams ?: return
        if (params.width != needed) {
            params.width = needed
            layoutParams = params
        }
    }

    override fun onDraw(canvas: Canvas) {
        fillPaint.color = gutterColor
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), fillPaint)
        fillPaint.color = dividerColor
        canvas.drawRect(width - 1f, 0f, width.toFloat(), height.toFloat(), fillPaint)

        val textLayout = editor.layout ?: return
        val text = editor.text ?: return
        if (textLayout.lineCount == 0 || !getLocalVisibleRect(visible)) return

        numberPaint.textSize = editor.textSize * 0.85f
        val top = editor.extendedPaddingTop
        val firstLine = textLayout.getLineForVertical((visible.top - top).coerceAtLeast(0))
        val lastLine = textLayout.getLineForVertical((visible.bottom - top).coerceAtLeast(0))

        // The logical number of the first visible line: one more than the logical lines before it.
        var number = 1
        for (i in 1..firstLine) {
            val start = textLayout.getLineStart(i)
            if (start > 0 && text[start - 1] == '\n') number++
        }

        val caretLine = if (editor.selectionStart >= 0) textLayout.getLineForOffset(editor.selectionStart) else -1
        val right = width - sidePad
        for (i in firstLine..lastLine) {
            val start = textLayout.getLineStart(i)
            val startsLogicalLine = start == 0 || text[start - 1] == '\n'
            if (i > firstLine && startsLogicalLine) number++
            if (startsLogicalLine) {
                numberPaint.color = if (i == caretLine) currentColor else textColor
                canvas.drawText(number.toString(), right, (top + textLayout.getLineBaseline(i)).toFloat(), numberPaint)
            }
        }
    }
}
