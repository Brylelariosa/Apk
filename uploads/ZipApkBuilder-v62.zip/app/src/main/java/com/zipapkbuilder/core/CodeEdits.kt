package com.zipapkbuilder.core

/**
 * The text transformations behind the code editor's typing aids, free of any Android class so each
 * rule can be read — and exercised — on its own. [CodeEditText] feeds them the document and applies
 * what they return.
 */
object CodeEdits {

    /** What to insert, and where the caret goes: [caretOffset] characters after the insertion point. */
    class Insertion(val text: String, val caretOffset: Int)

    /**
     * Enter at [at]: a new line that keeps the current line's indentation, one level deeper after
     * `{`, `(`, `[` (or `:` when [colonBlocks]). Pressing Enter between a bracket pair opens it onto
     * its own line and leaves the caret on the indented middle one. [selectionEnd] is the end of the
     * selection being replaced (equal to [at] when there is none).
     */
    fun newline(
        doc: CharSequence, at: Int, selectionEnd: Int,
        indentUnit: String, lineEnding: String, colonBlocks: Boolean
    ): Insertion {
        var lineStart = at
        while (lineStart > 0 && doc[lineStart - 1] != '\n') lineStart--
        var indentEnd = lineStart
        while (indentEnd < at && (doc[indentEnd] == ' ' || doc[indentEnd] == '\t')) indentEnd++
        val indent = doc.subSequence(lineStart, indentEnd).toString()

        var k = at - 1
        while (k >= lineStart && (doc[k] == ' ' || doc[k] == '\t')) k--
        val prev = if (k >= lineStart) doc[k] else ' '
        val next = if (selectionEnd < doc.length) doc[selectionEnd] else ' '
        val opens = prev == '{' || prev == '(' || prev == '[' || (colonBlocks && prev == ':')
        val extra = if (opens) indentUnit else ""

        val first = lineEnding + indent + extra
        val between = (prev == '{' && next == '}') || (prev == '(' && next == ')') || (prev == '[' && next == ']')
        return if (between) Insertion(first + lineEnding + indent, first.length) else Insertion(first, first.length)
    }

    /**
     * Typing [typed] at [at] with auto-pairing on: `(`, `[`, `{` and quotes insert their closing
     * partner with the caret between; typing a closer that is already next to the caret just steps
     * over it. Returns null when the character should be typed as-is (a quote after a letter is an
     * apostrophe, a third quote opens a raw string, and a pair is never opened right in front of a
     * word).
     */
    fun pairOrStepOver(doc: CharSequence, at: Int, typed: Char): Insertion? {
        val next = if (at < doc.length) doc[at] else '\u0000'
        val prev = if (at > 0) doc[at - 1] else '\u0000'
        val isQuote = typed == '"' || typed == '\'' || typed == '`'

        if ((typed == ')' || typed == ']' || typed == '}' || isQuote) && next == typed) return Insertion("", 1)

        val closer = when (typed) {
            '(' -> ')'
            '[' -> ']'
            '{' -> '}'
            '"', '\'', '`' -> typed
            else -> return null
        }
        if (isQuote && (prev.isLetterOrDigit() || prev == typed)) return null
        val blankAhead = next == '\u0000' || next.isWhitespace() ||
            next == ')' || next == ']' || next == '}' || next == ',' || next == ';' || next == '>'
        if (!blankAhead) return null
        return Insertion("$typed$closer", 1)
    }

    /** The spaces (or the tab) that move the caret at [at] to the next tab stop. */
    fun tabStop(doc: CharSequence, at: Int, indentUnit: String): String {
        if (indentUnit == "\t") return "\t"
        var lineStart = at
        while (lineStart > 0 && doc[lineStart - 1] != '\n') lineStart--
        val width = indentUnit.length.coerceAtLeast(1)
        return " ".repeat(width - ((at - lineStart) % width))
    }

    /** Indents each non-blank line by [indentUnit], or removes one level of indentation when [outdent]. */
    fun indentLines(lines: List<String>, indentUnit: String, outdent: Boolean): List<String> =
        lines.map { line ->
            if (outdent) unindent(line, indentUnit) else if (line.isBlank()) line else indentUnit + line
        }

    /** Removes one level of leading indentation: a tab, or up to one [indentUnit] of spaces. */
    fun unindent(line: String, indentUnit: String): String {
        if (line.startsWith("\t")) return line.substring(1)
        val most = if (indentUnit == "\t") 4 else indentUnit.length
        var n = 0
        while (n < most && n < line.length && line[n] == ' ') n++
        return line.substring(n)
    }

    /**
     * Comments the lines with [prefix] (at the shallowest indent among them), or — when every
     * non-blank line already starts with it — removes it, together with the space after it.
     */
    fun toggleComment(lines: List<String>, prefix: String): List<String> {
        val filled = lines.filter { it.isNotBlank() }
        val allCommented = filled.isNotEmpty() && filled.all { it.trimStart().startsWith(prefix) }
        if (allCommented) {
            return lines.map { line ->
                val at = line.indexOf(prefix)
                if (line.isBlank() || at < 0 || line.substring(0, at).isNotBlank()) {
                    line
                } else {
                    var after = at + prefix.length
                    if (after < line.length && line[after] == ' ') after++
                    line.substring(0, at) + line.substring(after)
                }
            }
        }
        val margin = filled.minOfOrNull { it.length - it.trimStart().length } ?: 0
        return lines.map { line ->
            if (line.isBlank()) line else line.substring(0, margin) + prefix + " " + line.substring(margin)
        }
    }

    /**
     * The whole lines a selection `a..b` touches, as `[start, end)` offsets into [doc] (end is the
     * line break after the last one, or the end of the text). A selection that ends right after a
     * line break does not take in the line that follows.
     */
    fun lineBlock(doc: String, a: Int, b: Int): IntArray {
        var last = b
        if (last > a && doc[last - 1] == '\n') last--
        val start = doc.lastIndexOf('\n', a - 1) + 1
        val end = doc.indexOf('\n', last).let { if (it < 0) doc.length else it }
        return intArrayOf(start, end)
    }
}
