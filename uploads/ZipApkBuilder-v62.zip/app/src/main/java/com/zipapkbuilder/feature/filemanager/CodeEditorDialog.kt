package com.zipapkbuilder.feature.filemanager

import android.app.AlertDialog
import android.app.Dialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.text.Editable
import android.text.InputType
import android.text.Spanned
import android.text.TextUtils
import android.text.TextWatcher
import android.text.style.BackgroundColorSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.widget.NestedScrollView
import com.zipapkbuilder.MainActivity
import com.zipapkbuilder.R
import com.zipapkbuilder.core.ButtonTone
import com.zipapkbuilder.core.CodeEditText
import com.zipapkbuilder.core.DialogAction
import com.zipapkbuilder.core.GutterView
import com.zipapkbuilder.core.PrefKeys
import com.zipapkbuilder.core.SyntaxHighlighter
import com.zipapkbuilder.core.SyntaxHighlighter.Lang
import com.zipapkbuilder.core.dialogMessage
import com.zipapkbuilder.core.dialogTitleBar
import com.zipapkbuilder.core.dialogWithActions
import com.zipapkbuilder.core.iconButton
import com.zipapkbuilder.core.pillButton
import kotlin.math.abs

/**
 * The full-screen code editor behind the File Manager's View / Edit.
 *
 * Compared with the old fixed-height dialog it adds live syntax coloring for the common languages,
 * undo/redo, auto-indent and bracket/quote pairing, Tab/Shift+Tab and comment toggling, a symbol
 * row above the keyboard (the characters a phone keyboard buries), find *and replace*, a gutter
 * that stays aligned with wrapped lines, word wrap and text zoom (both remembered), a
 * line/column readout that doubles as "go to line", and a guard against losing unsaved edits.
 * A failed save keeps the editor open with the edits intact.
 *
 * It owns no GitHub logic: [onSave] receives the new text and reports back through `done`
 * (`null` on success, otherwise a message to show), which is how [FileEditorController] plugs the
 * commit in. A file that can't be edited as text ([unreadableReason] set) opens read-only with
 * that reason instead of its content.
 */
class CodeEditorDialog(
    private val activity: MainActivity,
    private val fileName: String,
    private val branch: String,
    private val original: String,
    private val unreadableReason: String?,
    private val onSave: (newText: String, done: (error: String?) -> Unit) -> Unit
) {

    // ── Look ──────────────────────────────────────────────────────────────────
    private val density = activity.resources.displayMetrics.density
    private fun px(n: Int): Int = (n * density).toInt()

    private val bgEditor        = 0xFF0D1117.toInt()
    private val bgBar           = 0xFF161B22.toInt()
    private val bgTitle         = 0xFF1C2038.toInt()
    private val clrCode         = 0xFFE6EDF3.toInt()
    private val clrMuted        = 0xFF9AA0B8.toInt()
    private val clrDivider      = 0xFF232747.toInt()
    private val clrAccent       = 0xFF00D4AA.toInt()
    private val clrError        = 0xFFFF6B6B.toInt()
    private val clrMatch        = 0x66F2CC60
    private val clrMatchCurrent = 0xCCFF9F43.toInt()

    // ── State ─────────────────────────────────────────────────────────────────
    private val lang = SyntaxHighlighter.languageFor(fileName)
    private val readOnly = unreadableReason != null
    private var fontSp = activity.prefs.getFloat(PrefKeys.PREF_EDITOR_FONT_SP, 12f).coerceIn(MIN_FONT_SP, MAX_FONT_SP)
    private var wrap = activity.prefs.getBoolean(PrefKeys.PREF_EDITOR_WRAP, false)
    private var saving = false
    private var editCounter = 0
    private var searchOpen = false
    private var caseSensitive = false
    private var searchLength = 0
    private var currentMatch = -1
    private val matchStarts = ArrayList<Int>()
    private val matchSpans = ArrayList<BackgroundColorSpan>()

    private lateinit var dialog: Dialog
    private lateinit var etContent: CodeEditText
    private lateinit var gutter: GutterView
    private lateinit var nsv: NestedScrollView
    private lateinit var hScroll: HorizontalScrollView
    private lateinit var tvSub: TextView
    private lateinit var tvPos: TextView
    private lateinit var btnUndo: ImageView
    private lateinit var btnRedo: ImageView
    private lateinit var btnWrap: ImageView
    private lateinit var btnSave: TextView
    private lateinit var searchPanel: LinearLayout
    private lateinit var etFind: EditText
    private lateinit var etReplace: EditText
    private lateinit var tvMatches: TextView
    private lateinit var tvCase: TextView

    private val afterEditRunnable = Runnable { afterEdit() }
    private val statusRunnable = Runnable { updateStatus() }

    @Suppress("DEPRECATION") // SOFT_INPUT_ADJUST_RESIZE: still the way to resize a non-edge-to-edge dialog above the keyboard
    fun show() {
        val root = buildRoot()
        dialog = object : Dialog(activity, R.style.Theme_App_Dialog) {
            override fun onBackPressed() {
                requestClose()
            }
        }
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(root, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        dialog.setCanceledOnTouchOutside(false)
        dialog.setOnDismissListener { onDismissed() }
        dialog.show()
        dialog.window?.apply {
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            setBackgroundDrawable(ColorDrawable(bgEditor))
            setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN)
        }
        if (readOnly) updateStatus() else {
            afterEdit()
            updateStatus()
            updateUndoRedo()
        }
    }

    // ── Layout ────────────────────────────────────────────────────────────────

    private fun buildRoot(): LinearLayout {
        val root = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bgEditor)
        }
        root.addView(buildTopBar())
        root.addView(divider())
        if (!readOnly) {
            searchPanel = buildSearchPanel()
            root.addView(searchPanel)
        }
        root.addView(buildEditorArea(), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        if (!readOnly) root.addView(buildKeyRow())
        root.addView(divider())
        root.addView(buildStatusBar())
        return root
    }

    private fun divider(): View = View(activity).apply {
        setBackgroundColor(clrDivider)
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1)
    }

    private fun buildTopBar(): LinearLayout {
        val bar = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(bgTitle)
            setPadding(px(4), px(6), px(10), px(6))
        }
        bar.addView(activity.iconButton(R.drawable.ic_close, clrMuted, 18, 9) { requestClose() }
            .apply { contentDescription = "Close editor" })

        val titles = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = px(2)
                marginEnd = px(6)
            }
        }
        titles.addView(TextView(activity).apply {
            text = fileName
            textSize = 15f
            setTextColor(clrCode)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.MIDDLE
        })
        tvSub = TextView(activity).apply {
            textSize = 11f
            setTextColor(clrMuted)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            text = branch
        }
        titles.addView(tvSub)
        bar.addView(titles)

        if (!readOnly) {
            btnUndo = activity.iconButton(R.drawable.ic_undo, clrCode, 18, 8) { etContent.undo() }
                .apply { contentDescription = "Undo" }
            btnRedo = activity.iconButton(R.drawable.ic_redo, clrCode, 18, 8) { etContent.redo() }
                .apply { contentDescription = "Redo" }
            bar.addView(btnUndo)
            bar.addView(btnRedo)
            bar.addView(activity.iconButton(R.drawable.ic_search, clrCode, 18, 8) { toggleSearch(!searchOpen) }
                .apply { contentDescription = "Find and replace" })
            bar.addView(activity.iconButton(R.drawable.ic_copy, clrCode, 18, 8) { copyAll() }
                .apply { contentDescription = "Copy all" })
            btnSave = activity.pillButton("Save", ButtonTone.TEAL, R.drawable.ic_save, 12.5f, 15, 14, 8) { save() }.apply {
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                    .apply { marginStart = px(6) }
            }
            bar.addView(btnSave)
        }
        return bar
    }

    private fun fieldBackground(): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = px(8).toFloat()
        setColor(bgEditor)
        setStroke(1, clrDivider)
    }

    private fun field(hint: String): EditText = EditText(activity).apply {
        this.hint = hint
        textSize = 13f
        setTextColor(clrCode)
        setHintTextColor(0xFF50587A.toInt())
        background = fieldBackground()
        setPadding(px(10), px(8), px(10), px(8))
        isSingleLine = true
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        imeOptions = EditorInfo.IME_ACTION_SEARCH or EditorInfo.IME_FLAG_NO_EXTRACT_UI
        typeface = Typeface.MONOSPACE
        ViewCompat.setImportantForAutofill(this, View.IMPORTANT_FOR_AUTOFILL_NO)
    }

    private fun buildSearchPanel(): LinearLayout {
        val panel = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bgBar)
            setPadding(px(10), px(6), px(6), px(8))
            visibility = View.GONE
        }

        // Row 1: find, match counter, previous / next, case, go to line, close
        val findRow = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        etFind = field("Find in file…").apply {
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: Editable?) { runSearch(etContent.selectionStart, reveal = true) }
            })
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_SEARCH) { stepMatch(1); true } else false
            }
        }
        findRow.addView(etFind)
        tvMatches = TextView(activity).apply {
            textSize = 11.5f
            setTextColor(clrMuted)
            gravity = Gravity.CENTER
            minWidth = px(46)
        }
        findRow.addView(tvMatches)
        findRow.addView(activity.iconButton(R.drawable.ic_chevron_left, clrCode, 16, 8) { stepMatch(-1) }
            .apply { contentDescription = "Previous match" })
        findRow.addView(activity.iconButton(R.drawable.ic_chevron_right, clrCode, 16, 8) { stepMatch(1) }
            .apply { contentDescription = "Next match" })
        tvCase = TextView(activity).apply {
            text = "Aa"
            textSize = 12.5f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(px(8), px(6), px(8), px(6))
            contentDescription = "Match case"
            setOnClickListener {
                caseSensitive = !caseSensitive
                styleCaseToggle()
                runSearch(etContent.selectionStart, reveal = true)
            }
        }
        styleCaseToggle()
        findRow.addView(tvCase)
        findRow.addView(activity.iconButton(R.drawable.ic_hash, clrCode, 16, 8) { promptGoToLine() }
            .apply { contentDescription = "Go to line" })
        findRow.addView(activity.iconButton(R.drawable.ic_close, clrMuted, 16, 8) { toggleSearch(false) }
            .apply { contentDescription = "Close find" })
        panel.addView(findRow)

        // Row 2: replacement text, Replace, All
        val replaceRow = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { topMargin = px(6) }
        }
        etReplace = field("Replace with…").apply {
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            imeOptions = EditorInfo.IME_ACTION_DONE or EditorInfo.IME_FLAG_NO_EXTRACT_UI
        }
        replaceRow.addView(etReplace)
        replaceRow.addView(activity.pillButton("Replace", ButtonTone.SURFACE, null, 11.5f, 14, 12, 9) { replaceCurrent() }.apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { marginStart = px(6) }
        })
        replaceRow.addView(activity.pillButton("All", ButtonTone.SURFACE, null, 11.5f, 14, 12, 9) { replaceAll() }.apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { marginStart = px(6) }
        })
        panel.addView(replaceRow)
        return panel
    }

    private fun styleCaseToggle() {
        tvCase.setTextColor(if (caseSensitive) clrAccent else clrMuted)
        tvCase.background = if (caseSensitive) GradientDrawable().apply {
            cornerRadius = px(8).toFloat()
            setColor(0xFF00251F.toInt())
        } else null
    }

    private fun buildEditorArea(): View {
        etContent = CodeEditText(activity).apply {
            typeface = Typeface.MONOSPACE
            textSize = fontSp
            setTextColor(clrCode)
            setBackgroundColor(Color.TRANSPARENT)
            gravity = Gravity.TOP or Gravity.START
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            imeOptions = EditorInfo.IME_FLAG_NO_EXTRACT_UI
            setLineSpacing(0f, 1.3f)
            setPadding(px(8), px(8), px(32), px(8))
            setHorizontallyScrolling(!wrap)
            isSaveEnabled = false
            ViewCompat.setImportantForAutofill(this, View.IMPORTANT_FOR_AUTOFILL_NO)
        }
        gutter = GutterView(activity, etContent).apply {
            gutterColor = bgBar
            dividerColor = clrDivider
            totalLines = countLines(original)
            layoutParams = LinearLayout.LayoutParams(px(40), ViewGroup.LayoutParams.MATCH_PARENT)
            if (readOnly) visibility = View.GONE
        }

        if (readOnly) {
            etContent.setText(unreadableReason)
            etContent.isEnabled = false
            etContent.setTextColor(clrMuted)
        } else {
            etContent.indentUnit = SyntaxHighlighter.detectIndent(original, lang)
            etContent.lineEnding = if (original.contains("\r\n")) "\r\n" else "\n"
            etContent.autoPair = lang.isCode
            etContent.colonBlocks = lang.colonBlocks
            etContent.setCode(original)
            etContent.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    editCounter++
                    gutter.invalidate()
                    scheduleAfterEdit()
                    scheduleStatus()
                }
            })
            etContent.onCursorMoved = {
                scheduleStatus()
                gutter.invalidate()
            }
            etContent.history.onChange = { updateUndoRedo() }
            etContent.onShortcut = { key ->
                when (key) {
                    's' -> { save(); true }
                    'f' -> { toggleSearch(true); true }
                    else -> false
                }
            }
        }
        gutter.fitWidth()

        hScroll = HorizontalScrollView(activity).apply {
            isFillViewport = true
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(etContent, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            // The wrap width is the viewport's, so it has to follow the viewport (rotation, split screen).
            addOnLayoutChangeListener { _, left, _, right, _, oldLeft, _, oldRight, _ ->
                if (right - left != oldRight - oldLeft) post { applyWrap() }
            }
        }

        val row = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(gutter)
            addView(hScroll)
        }
        nsv = NestedScrollView(activity).apply {
            isFillViewport = true
            setBackgroundColor(bgEditor)
            addView(row, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            setOnScrollChangeListener(NestedScrollView.OnScrollChangeListener { _, _, _, _, _ -> gutter.invalidate() })
            // Tapping the empty area under a short file should still place the caret, so the field
            // is always at least as tall as the viewport.
            addOnLayoutChangeListener { _, _, top, _, bottom, _, _, _, _ ->
                val viewport = bottom - top
                if (viewport > 0 && etContent.minHeight != viewport) post { etContent.minHeight = viewport }
            }
        }
        return nsv
    }

    private fun applyWrap() {
        val viewport = hScroll.width
        if (viewport <= 0) return
        etContent.setHorizontallyScrolling(!wrap)
        val params = etContent.layoutParams as FrameLayout.LayoutParams
        if (wrap) {
            params.width = viewport
            etContent.minWidth = 0
        } else {
            params.width = ViewGroup.LayoutParams.WRAP_CONTENT
            etContent.minWidth = viewport
        }
        etContent.layoutParams = params
        hScroll.scrollTo(0, 0)
        gutter.invalidate()
    }

    private fun keyText(label: String, onClick: () -> Unit): TextView = TextView(activity).apply {
        text = label
        textSize = 15f
        typeface = Typeface.MONOSPACE
        setTextColor(clrCode)
        gravity = Gravity.CENTER
        background = ContextCompat.getDrawable(activity, R.drawable.bg_btn_surface_ripple)
        minWidth = px(40)
        setPadding(px(10), 0, px(10), 0)
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, px(38))
            .apply { setMargins(px(3), px(4), px(3), px(4)) }
        isClickable = true
        isFocusable = false          // tapping a key must not take focus (and the keyboard) from the editor
        setOnClickListener { onClick() }
    }

    private fun keyIcon(iconRes: Int, description: String, onClick: () -> Unit): ImageView = ImageView(activity).apply {
        setImageResource(iconRes)
        imageTintList = ColorStateList.valueOf(clrCode)
        background = ContextCompat.getDrawable(activity, R.drawable.bg_btn_surface_ripple)
        scaleType = ImageView.ScaleType.CENTER
        contentDescription = description
        layoutParams = LinearLayout.LayoutParams(px(40), px(38)).apply { setMargins(px(3), px(4), px(3), px(4)) }
        isClickable = true
        isFocusable = false
        setOnClickListener { onClick() }
    }

    private fun buildKeyRow(): View {
        val row = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(px(4), px(2), px(4), px(2))
        }
        row.addView(keyIcon(R.drawable.ic_tab, "Tab") { etContent.tab(false) })
        row.addView(keyText("Untab") { etContent.tab(true) })
        row.addView(keyIcon(R.drawable.ic_chevron_left, "Cursor left") { etContent.moveCaret(-1) })
        row.addView(keyIcon(R.drawable.ic_chevron_right, "Cursor right") { etContent.moveCaret(1) })
        lang.commentPrefix?.let { prefix -> row.addView(keyText("Cmt") { etContent.toggleComment(prefix) }) }
        for (symbol in SYMBOLS) row.addView(keyText(symbol) { etContent.insertAtCaret(symbol) })
        return HorizontalScrollView(activity).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            setBackgroundColor(bgBar)
            addView(row)
        }
    }

    private fun buildStatusBar(): LinearLayout {
        val bar = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(bgBar)
            setPadding(px(12), px(2), px(6), px(2))
        }
        tvPos = TextView(activity).apply {
            textSize = 11.5f
            setTextColor(clrMuted)
            typeface = Typeface.MONOSPACE
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            gravity = Gravity.CENTER_VERTICAL
            minHeight = px(36)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            if (!readOnly) setOnClickListener { promptGoToLine() }
        }
        bar.addView(tvPos)
        if (!readOnly) {
            btnWrap = activity.iconButton(R.drawable.ic_wrap, if (wrap) clrAccent else clrMuted, 16, 8) {
                wrap = !wrap
                activity.prefs.edit().putBoolean(PrefKeys.PREF_EDITOR_WRAP, wrap).apply()
                btnWrap.imageTintList = ColorStateList.valueOf(if (wrap) clrAccent else clrMuted)
                applyWrap()
            }.apply { contentDescription = "Word wrap" }
            bar.addView(btnWrap)
            bar.addView(textButton("A−", "Smaller text") { changeFont(-1f) })
            bar.addView(textButton("A+", "Larger text") { changeFont(1f) })
        }
        return bar
    }

    private fun textButton(label: String, description: String, onClick: () -> Unit): TextView = TextView(activity).apply {
        text = label
        textSize = 13f
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        setTextColor(clrMuted)
        gravity = Gravity.CENTER
        contentDescription = description
        background = ContextCompat.getDrawable(activity, R.drawable.bg_icon_btn_ripple)
        minWidth = px(40)
        minHeight = px(36)
        isClickable = true
        isFocusable = false
        setOnClickListener { onClick() }
    }

    private fun changeFont(delta: Float) {
        fontSp = (fontSp + delta).coerceIn(MIN_FONT_SP, MAX_FONT_SP)
        etContent.textSize = fontSp
        gutter.fitWidth()
        gutter.invalidate()
        activity.prefs.edit().putFloat(PrefKeys.PREF_EDITOR_FONT_SP, fontSp).apply()
    }

    // ── Derived state ─────────────────────────────────────────────────────────

    private fun scheduleAfterEdit() {
        activity.mainHandler.removeCallbacks(afterEditRunnable)
        activity.mainHandler.postDelayed(afterEditRunnable, AFTER_EDIT_DELAY_MS)
    }

    private fun scheduleStatus() {
        activity.mainHandler.removeCallbacks(statusRunnable)
        activity.mainHandler.postDelayed(statusRunnable, 60)
    }

    /**
     * Runs shortly after typing stops: refreshes the line count, the modified marker, the syntax
     * coloring (computed on the background executor from a String snapshot, and dropped if the
     * text changed again before it finished) and the find results.
     */
    private fun afterEdit() {
        if (readOnly || !dialog.isShowing) return
        val snapshot = etContent.text.toString()
        val counter = editCounter
        val lines = countLines(snapshot)
        if (lines != gutter.totalLines) {
            gutter.totalLines = lines
            gutter.fitWidth()
        }
        tvSub.text = buildString {
            append(branch).append("  ·  ").append(lines).append(if (lines == 1) " line" else " lines")
            if (snapshot != original) append("  ·  ● modified")
        }
        if (snapshot.length <= MAX_HIGHLIGHT_CHARS) {
            activity.bgExecutor.execute {
                val spans = SyntaxHighlighter.compute(snapshot, lang)
                activity.mainHandler.post {
                    if (counter == editCounter && dialog.isShowing) {
                        etContent.text?.let { SyntaxHighlighter.applySpans(it, spans) }
                    }
                }
            }
        } else {
            etContent.text?.let { SyntaxHighlighter.clear(it) }
        }
        if (searchOpen) runSearch(etContent.selectionStart, reveal = false)
    }

    private fun updateStatus() {
        if (readOnly) {
            tvPos.text = unreadableReason
            return
        }
        val text = etContent.text ?: return
        val start = etContent.selectionStart.coerceIn(0, text.length)
        val end = etContent.selectionEnd.coerceIn(0, text.length)
        var line = 1
        var lineStart = 0
        for (i in 0 until start) {
            if (text[i] == '\n') {
                line++
                lineStart = i + 1
            }
        }
        val selected = if (end != start) "  ·  ${abs(end - start)} selected" else ""
        val endings = if (etContent.lineEnding == "\n") "LF" else "CRLF"
        tvPos.setTextColor(clrMuted)
        tvPos.text = "Ln $line, Col ${start - lineStart + 1}$selected  ·  $endings  ·  ${langLabel(lang)}"
    }

    private fun updateUndoRedo() {
        if (readOnly) return
        btnUndo.alpha = if (etContent.history.canUndo) 1f else 0.35f
        btnRedo.alpha = if (etContent.history.canRedo) 1f else 0.35f
    }

    private fun countLines(text: CharSequence): Int {
        var lines = 1
        for (i in text.indices) if (text[i] == '\n') lines++
        return lines
    }

    private fun langLabel(l: Lang): String = when (l) {
        Lang.KOTLIN -> "Kotlin"
        Lang.JAVA -> "Java"
        Lang.JAVASCRIPT -> "JS/TS"
        Lang.C_LIKE -> "C-family"
        Lang.GRADLE -> "Gradle"
        Lang.PYTHON -> "Python"
        Lang.SHELL -> "Shell"
        Lang.YAML -> "YAML"
        Lang.PROPERTIES -> "Config"
        Lang.XML -> "XML/HTML"
        Lang.JSON -> "JSON"
        Lang.MARKDOWN -> "Markdown"
        Lang.PLAIN -> "Plain text"
    }

    // ── Find & replace ────────────────────────────────────────────────────────

    private fun toggleSearch(open: Boolean) {
        if (readOnly) return
        searchOpen = open
        searchPanel.visibility = if (open) View.VISIBLE else View.GONE
        if (open) {
            val a = etContent.selectionStart
            val b = etContent.selectionEnd
            if (a >= 0 && b > a && b - a <= 80) {
                val selected = etContent.text?.subSequence(a, b)?.toString()
                if (selected != null && !selected.contains('\n')) etFind.setText(selected)
            }
            etFind.requestFocus()
            etFind.setSelection(etFind.text.length)
            etFind.post {
                val imm = activity.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showSoftInput(etFind, InputMethodManager.SHOW_IMPLICIT)
            }
            runSearch(etContent.selectionStart, reveal = true)
        } else {
            clearMatches()
            tvMatches.text = ""
            etContent.requestFocus()
        }
    }

    private fun clearMatches() {
        etContent.text?.let { text -> for (span in matchSpans) text.removeSpan(span) }
        matchSpans.clear()
        matchStarts.clear()
        currentMatch = -1
    }

    /** Finds every occurrence of the query; the current match is the first one at or after [from]. */
    private fun runSearch(from: Int, reveal: Boolean) {
        clearMatches()
        val query = etFind.text.toString()
        searchLength = query.length
        if (query.isEmpty()) {
            tvMatches.text = ""
            return
        }
        val hay = etContent.text.toString()
        var at = hay.indexOf(query, 0, ignoreCase = !caseSensitive)
        while (at >= 0 && matchStarts.size < MAX_MATCHES) {
            matchStarts.add(at)
            at = hay.indexOf(query, at + query.length, ignoreCase = !caseSensitive)
        }
        if (matchStarts.isEmpty()) {
            tvMatches.text = "0/0"
            return
        }
        val firstAfter = matchStarts.indexOfFirst { it >= from }
        currentMatch = if (firstAfter < 0) 0 else firstAfter
        paintMatches()
        if (reveal) scrollToOffset(matchStarts[currentMatch])
    }

    private fun paintMatches() {
        val text = etContent.text ?: return
        for (span in matchSpans) text.removeSpan(span)
        matchSpans.clear()
        for (i in matchStarts.indices) {
            val start = matchStarts[i]
            if (start + searchLength > text.length) continue
            val span = BackgroundColorSpan(if (i == currentMatch) clrMatchCurrent else clrMatch)
            text.setSpan(span, start, start + searchLength, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            matchSpans.add(span)
        }
        val more = if (matchStarts.size >= MAX_MATCHES) "+" else ""
        tvMatches.text = "${currentMatch + 1}/${matchStarts.size}$more"
    }

    private fun stepMatch(direction: Int) {
        if (matchStarts.isEmpty()) return
        currentMatch = (currentMatch + direction + matchStarts.size) % matchStarts.size
        paintMatches()
        scrollToOffset(matchStarts[currentMatch])
    }

    private fun replaceCurrent() {
        val query = etFind.text.toString()
        if (query.isEmpty() || currentMatch !in matchStarts.indices) return
        val start = matchStarts[currentMatch]
        val hay = etContent.text.toString()
        // The text may have been edited since the search ran: only replace what is really there.
        if (!hay.regionMatches(start, query, 0, query.length, ignoreCase = !caseSensitive)) {
            runSearch(etContent.selectionStart, reveal = true)
            return
        }
        val replacement = etReplace.text.toString()
        etContent.replaceRaw(start, start + query.length, replacement)
        runSearch(start + replacement.length, reveal = true)
    }

    private fun replaceAll() {
        val query = etFind.text.toString()
        if (query.isEmpty()) return
        val hay = etContent.text.toString()
        val positions = ArrayList<Int>()
        var at = hay.indexOf(query, 0, ignoreCase = !caseSensitive)
        while (at >= 0) {
            positions.add(at)
            at = hay.indexOf(query, at + query.length, ignoreCase = !caseSensitive)
        }
        if (positions.isEmpty()) {
            tvMatches.text = "0/0"
            return
        }
        val replacement = etReplace.text.toString()
        // One edit spanning first to last occurrence, so "Replace all" is a single undo step.
        val rebuilt = StringBuilder()
        var cursor = positions.first()
        for (position in positions) {
            rebuilt.append(hay, cursor, position).append(replacement)
            cursor = position + query.length
        }
        etContent.replaceRaw(positions.first(), positions.last() + query.length, rebuilt)
        runSearch(0, reveal = false)
        activity.appendLog("Replaced ${positions.size} occurrence${if (positions.size == 1) "" else "s"} in $fileName (not saved yet).")
    }

    private fun scrollToOffset(offset: Int) {
        val layout = etContent.layout ?: return
        val at = offset.coerceIn(0, etContent.text?.length ?: 0)
        val line = layout.getLineForOffset(at)
        val y = layout.getLineTop(line)
        nsv.post { nsv.smoothScrollTo(0, (y - nsv.height / 3).coerceAtLeast(0)) }
        if (!wrap) {
            val x = layout.getPrimaryHorizontal(at).toInt()
            hScroll.post { hScroll.smoothScrollTo((x - hScroll.width / 3).coerceAtLeast(0), 0) }
        }
    }

    private fun promptGoToLine() {
        if (readOnly) return
        val input = EditText(activity).apply {
            hint = "Line number"
            inputType = InputType.TYPE_CLASS_NUMBER
            setPadding(px(24), px(8), px(24), px(8))
        }
        val body = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            addView(activity.dialogMessage("Go to line (1 – ${countLines(etContent.text ?: "")})"))
            addView(input)
        }
        lateinit var dlg: AlertDialog
        val content = activity.dialogWithActions(
            body,
            DialogAction("Go", ButtonTone.TEAL, R.drawable.ic_hash) {
                val n = input.text.toString().toIntOrNull()
                dlg.dismiss()
                if (n != null && n >= 1) goToLine(n)
            },
            DialogAction("Cancel", ButtonTone.SURFACE, R.drawable.ic_close) { dlg.dismiss() }
        )
        dlg = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
            .setCustomTitle(activity.dialogTitleBar("Go to line", R.drawable.ic_hash, ButtonTone.TEAL) { dlg.dismiss() })
            .setView(content)
            .show()
    }

    private fun goToLine(n: Int) {
        val text = etContent.text ?: return
        var line = 1
        var offset = 0
        while (line < n && offset < text.length) {
            if (text[offset] == '\n') line++
            offset++
        }
        etContent.requestFocus()
        etContent.setSelection(offset.coerceIn(0, text.length))
        scrollToOffset(offset)
    }

    // ── Save / close ──────────────────────────────────────────────────────────

    private fun isDirty(): Boolean = !readOnly && etContent.text.toString() != original

    private fun copyAll() {
        val cm = activity.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText(fileName, etContent.text.toString()))
        activity.appendLog("Copied $fileName to clipboard.")
    }

    private fun save() {
        if (saving || readOnly) return
        val newText = etContent.text.toString()
        if (newText == original) {
            activity.appendLog("No changes to save in $fileName.")
            dialog.dismiss()
            return
        }
        saving = true
        setSavingUi(true)
        onSave(newText) { error ->
            activity.mainHandler.post {
                saving = false
                if (error == null) {
                    if (dialog.isShowing) dialog.dismiss()
                } else if (dialog.isShowing) {
                    // The edits are all still here — say why it failed instead of closing on them.
                    setSavingUi(false)
                    tvPos.setTextColor(clrError)
                    tvPos.text = "Not saved — $error"
                }
            }
        }
    }

    private fun setSavingUi(inProgress: Boolean) {
        btnSave.text = if (inProgress) "Saving…" else "Save"
        btnSave.isEnabled = !inProgress
        etContent.isEnabled = !inProgress
    }

    private fun requestClose() {
        if (saving) return
        if (isDirty()) confirmDiscard() else dialog.dismiss()
    }

    private fun confirmDiscard() {
        lateinit var dlg: AlertDialog
        val content = activity.dialogWithActions(
            activity.dialogMessage("You have unsaved changes to $fileName. Leave without saving them?"),
            DialogAction("Save", ButtonTone.TEAL, R.drawable.ic_save) {
                dlg.dismiss()
                save()
            },
            DialogAction("Discard changes", ButtonTone.RED, R.drawable.ic_delete) {
                dlg.dismiss()
                dialog.dismiss()
            },
            DialogAction("Keep editing", ButtonTone.SURFACE, R.drawable.ic_edit) { dlg.dismiss() },
            stacked = true
        )
        dlg = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
            .setCustomTitle(activity.dialogTitleBar("Unsaved changes", R.drawable.ic_warning, ButtonTone.ORANGE) { dlg.dismiss() })
            .setView(content)
            .show()
    }

    private fun onDismissed() {
        activity.mainHandler.removeCallbacks(afterEditRunnable)
        activity.mainHandler.removeCallbacks(statusRunnable)
        if (!readOnly) {
            etContent.onCursorMoved = null
            etContent.onShortcut = null
            etContent.history.onChange = null
        }
    }

    private companion object {
        const val MIN_FONT_SP = 8f
        const val MAX_FONT_SP = 24f
        const val AFTER_EDIT_DELAY_MS = 350L
        const val MAX_HIGHLIGHT_CHARS = 250_000
        const val MAX_MATCHES = 2000

        /** The characters a phone keyboard buries, in rough order of how often code needs them. */
        val SYMBOLS = listOf(
            "{", "}", "(", ")", "[", "]", "<", ">", "\"", "'", ";", ":", "=", "/", "\\", "|",
            "&", "#", "_", "-", "+", "*", "!", "?", "\$", "%", "@", ".", ","
        )
    }
}
