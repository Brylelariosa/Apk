package com.zipapkbuilder.net

import android.util.Base64
import android.util.Base64OutputStream
import org.json.JSONObject
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * Thin, stateless wrapper around `HttpURLConnection` for the handful of
 * GitHub REST endpoints this app calls (Contents API, Actions API, Git Data
 * API). Every call takes the token explicitly rather than the client holding
 * one, since the token can change between calls (the user may edit the token
 * field between actions) — this mirrors how the endpoints were called before
 * this was split out of the Activity, just without the duplication of
 * `HttpURLConnection` boilerplate across five near-identical functions.
 */
object GitHubApi {

    /**
     * Always bypasses every HTTP cache layer. GitHub answers Contents API reads with
     * `Cache-Control: private, max-age=60`, so without these headers a directory listing
     * fetched right after a delete/upload/move can be served from cache and show the
     * file as if the change never happened.
     */
    fun httpGet(token: String, urlStr: String) =
        readResponse((URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            useCaches = false
            setRequestProperty("Authorization", "token $token")
            setRequestProperty("Accept", "application/vnd.github.v3+json")
            setRequestProperty("Cache-Control", "no-cache")
            setRequestProperty("Pragma", "no-cache")
            connectTimeout = 30_000; readTimeout = 30_000
        })

    fun httpPut(token: String, urlStr: String, body: String) =
        readResponse((URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = "PUT"
            setRequestProperty("Authorization", "token $token")
            setRequestProperty("Accept", "application/vnd.github.v3+json")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            doOutput = true; connectTimeout = 120_000; readTimeout = 120_000
        }.also { it.outputStream.bufferedWriter().use { w -> w.write(body) } })

    fun httpPost(token: String, urlStr: String, body: String) =
        readResponse((URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            setRequestProperty("Authorization", "token $token")
            setRequestProperty("Accept", "application/vnd.github.v3+json")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            doOutput = true; connectTimeout = 30_000; readTimeout = 30_000
        }.also { it.outputStream.bufferedWriter().use { w -> w.write(body) } })

    fun httpDelete(token: String, urlStr: String, body: String) =
        readResponse((URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = "DELETE"
            setRequestProperty("Authorization", "token $token")
            setRequestProperty("Accept", "application/vnd.github.v3+json")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            doOutput = true; connectTimeout = 30_000; readTimeout = 30_000
        }.also { it.outputStream.bufferedWriter().use { w -> w.write(body) } })

    /**
     * PATCH via POST + X-HTTP-Method-Override so it works on Android's
     * HttpURLConnection which may not support PATCH natively on API < 29.
     */
    fun httpPatch(token: String, urlStr: String, body: String) =
        readResponse((URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            setRequestProperty("X-HTTP-Method-Override", "PATCH")
            setRequestProperty("Authorization", "token $token")
            setRequestProperty("Accept", "application/vnd.github.v3+json")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            doOutput = true; connectTimeout = 30_000; readTimeout = 30_000
        }.also { it.outputStream.bufferedWriter().use { w -> w.write(body) } })

    /**
     * GitHub's rate-limit response headers, captured once per request so
     * callers can react to them without touching [HttpURLConnection] headers
     * themselves. Every field is null when the header wasn't present — true
     * for the overwhelming majority of responses, which aren't rate-limited
     * at all.
     */
    data class RateLimitInfo(
        val remaining: Long? = null,
        val resetEpochSeconds: Long? = null,
        val retryAfterSeconds: Long? = null
    )

    /**
     * One GitHub HTTP response. Deliberately shaped so every existing
     * `val (code, body) = GitHubApi.httpX(...)` call site (there are several
     * dozen) keeps compiling and behaving exactly as before: Kotlin
     * destructuring only needs `component1()`/`component2()` to match by
     * position, and doesn't care that a third component ([rateLimitInfo]) now
     * also exists. Only the handful of call sites that already call
     * [describeHttpError] need to change at all, to also pass it through.
     */
    data class HttpResult(val code: Int, val body: String, val rateLimitInfo: RateLimitInfo)

    /** Reads GitHub's rate-limit headers off [conn] — safe to call on any
     *  response, successful or not; every field is simply null if the header
     *  wasn't sent. Must be called before [HttpURLConnection.disconnect]. */
    private fun extractRateLimitInfo(conn: HttpURLConnection): RateLimitInfo = RateLimitInfo(
        remaining          = conn.getHeaderField("X-RateLimit-Remaining")?.toLongOrNull(),
        resetEpochSeconds  = conn.getHeaderField("X-RateLimit-Reset")?.toLongOrNull(),
        retryAfterSeconds  = conn.getHeaderField("Retry-After")?.toLongOrNull()
    )

    fun readResponse(conn: HttpURLConnection): HttpResult =
        try {
            val code = conn.responseCode
            val body = (if (code < 400) conn.inputStream else conn.errorStream)
                ?.bufferedReader()?.readText() ?: ""
            HttpResult(code, body, extractRateLimitInfo(conn))
        } finally { conn.disconnect() }

    // ── URL / path encoding ─────────────────────────────────────────────────
    //
    // GitHub REST paths and query values can legitimately contain characters
    // that are unsafe to drop straight into a URL: branch names with slashes
    // ("feature/test", "release/v2"), file/folder names with spaces, '#', '?',
    // '%', or non-ASCII characters, etc. Every URL builder below routes
    // through one of these three encoders instead of raw string
    // interpolation, so a request can never be built from an un-encoded
    // component. This intentionally does NOT get applied character-by-character
    // by every caller — the builder functions are the single choke point.

    /** Percent-encodes one path/query segment (RFC 3986-ish): letters, digits,
     *  and `. _ - ~` pass through unchanged; everything else — including
     *  spaces — is percent-escaped. `+` from [java.net.URLEncoder]'s
     *  form-encoding is normalized to `%20` since this is a URL path/query
     *  segment, not an HTML form body. */
    private fun encodeSegment(raw: String): String =
        java.net.URLEncoder.encode(raw, "UTF-8").replace("+", "%20")

    /**
     * Encodes a repo-relative content path (e.g. `src/main/AndroidManifest.xml`)
     * for the Contents API: every segment between `/`s is percent-encoded on
     * its own, and the `/` separators themselves are preserved so the path
     * still reads as a directory hierarchy to GitHub's router. Empty segments
     * (a leading/trailing/duplicate slash) are left empty rather than encoded
     * to `""`→anything, so `apiContents(o, r, "")` (repo root) still works.
     */
    fun encodeContentPath(path: String): String =
        if (path.isEmpty()) "" else path.split("/").joinToString("/") { seg ->
            if (seg.isEmpty()) seg else encodeSegment(seg)
        }

    /**
     * Encodes a git ref (branch/tag name) for use as a URL *path* segment
     * under `.../heads/…` or `.../tags/…`. Branch names are themselves
     * allowed to contain `/` as a real hierarchy separator (`feature/test`,
     * `release/v2`) — those must stay unescaped for GitHub to parse the ref
     * correctly — while any other unsafe character within a single ref
     * segment is still escaped. Shares [encodeContentPath]'s exact
     * segment-preserving behavior.
     */
    fun encodeRefPath(ref: String): String = encodeContentPath(ref)

    /**
     * Encodes a value for use as a URL *query string* value (e.g.
     * `?branch=…`). Unlike [encodeContentPath]/[encodeRefPath], `/` is NOT
     * preserved here — a query value is one opaque string, not a path, so an
     * embedded `/` (e.g. a branch named `feature/test` passed as `?branch=`)
     * must itself be escaped to `%2F` or GitHub would see it as ending early.
     */
    fun encodeQueryValue(value: String): String = encodeSegment(value)

    /** Encodes an owner or repo name. GitHub restricts these to a fairly safe
     *  alphanumeric/hyphen/underscore/dot set already, but every request still
     *  routes through this rather than raw interpolation, both for defense in
     *  depth and so every builder below has one consistent story. */
    fun encodeOwnerOrRepo(value: String): String = encodeSegment(value)

    // ── URL builders ──────────────────────────────────────────────────────────
    // Every GitHub endpoint this app calls is built here, not via ad-hoc
    // string interpolation at the call site — centralizing this is what makes
    // the encoding above actually apply everywhere instead of only where a
    // caller remembered to ask for it.

    private fun repoBase(owner: String, repo: String) =
        "https://api.github.com/repos/${encodeOwnerOrRepo(owner)}/${encodeOwnerOrRepo(repo)}"

    fun apiUser() = "https://api.github.com/user"

    fun apiUserRepos() = "https://api.github.com/user/repos"

    fun apiRepo(owner: String, repo: String) = repoBase(owner, repo)

    /**
     * Contents API URL. Reads ([httpGet]) MUST pass [ref]: without it GitHub answers from
     * the repo's default branch, while every write in this app targets the branch the
     * user selected. On any non-default branch that made deleted or moved files keep
     * showing up in listings, and returned stale SHAs for edits. Writes (PUT/DELETE)
     * carry the branch in their JSON body instead, so they leave [ref] null.
     */
    fun apiContents(owner: String, repo: String, path: String, ref: String? = null): String {
        val base = "${repoBase(owner, repo)}/contents/${encodeContentPath(path)}"
        return if (ref.isNullOrBlank()) base else "$base?ref=${encodeQueryValue(ref)}"
    }

    fun apiRuns(owner: String, repo: String) = "${repoBase(owner, repo)}/actions/runs"

    fun apiRun(owner: String, repo: String, runId: Long) = "${apiRuns(owner, repo)}/$runId"

    fun apiRunJobs(owner: String, repo: String, runId: Long) = "${apiRun(owner, repo, runId)}/jobs"

    fun apiRunArtifacts(owner: String, repo: String, runId: Long) = "${apiRun(owner, repo, runId)}/artifacts"

    fun apiRunLogs(owner: String, repo: String, runId: Long) = "${apiRun(owner, repo, runId)}/logs"

    fun apiJobLogs(owner: String, repo: String, jobId: Long) =
        "${repoBase(owner, repo)}/actions/jobs/$jobId/logs"

    fun apiArtifacts(owner: String, repo: String) = "${repoBase(owner, repo)}/actions/artifacts"

    fun apiArtifactZip(owner: String, repo: String, artifactId: Long) =
        "${apiArtifacts(owner, repo)}/$artifactId/zip"

    /** Appends `?branch=<encoded>&per_page=…` etc. onto [apiRuns] — [branch] is
     *  query-encoded (not path-encoded), matching where it's actually placed.
     *  [event] is unfiltered (any trigger type) by default; pass `"push"` or
     *  `"workflow_dispatch"` to narrow to runs GitHub created that way — e.g.
     *  [BuildRunMonitor.waitForRun]'s fallback match (a push-triggered build)
     *  vs. [com.zipapkbuilder.feature.keystore.KeystoreController]'s
     *  keystore-generation run (manually dispatched). */
    fun apiRunsForBranch(owner: String, repo: String, branch: String, perPage: Int, page: Int? = null, event: String? = null): String =
        buildString {
            append(apiRuns(owner, repo))
            append("?branch=").append(encodeQueryValue(branch))
            append("&per_page=").append(perPage)
            if (page != null) append("&page=").append(page)
            if (event != null) append("&event=").append(encodeQueryValue(event))
        }

    /** Filters workflow runs by exact head commit SHA — the strongest available
     *  signal for "which run did *my* push actually create", used instead of a
     *  timestamp/branch heuristic wherever the pushed commit's SHA is known. */
    fun apiRunsForHeadSha(owner: String, repo: String, branch: String, headSha: String, perPage: Int = 10): String =
        "${apiRunsForBranch(owner, repo, branch, perPage)}&head_sha=${encodeQueryValue(headSha)}"

    fun apiRefHeads(owner: String, repo: String, branch: String) =
        "${repoBase(owner, repo)}/git/ref/heads/${encodeRefPath(branch)}"

    fun apiRefsHeads(owner: String, repo: String, branch: String) =
        "${repoBase(owner, repo)}/git/refs/heads/${encodeRefPath(branch)}"

    fun apiCommit(owner: String, repo: String, sha: String) =
        "${repoBase(owner, repo)}/git/commits/${encodeSegment(sha)}"

    fun apiCommits(owner: String, repo: String) = "${repoBase(owner, repo)}/git/commits"

    fun apiTrees(owner: String, repo: String) = "${repoBase(owner, repo)}/git/trees"

    fun apiBlobs(owner: String, repo: String) = "${repoBase(owner, repo)}/git/blobs"

    /** A single blob by its sha — `GET`s the base64 content directly, with no
     *  1MB limit the way the Contents API's inline `content` field has. */
    fun apiBlob(owner: String, repo: String, sha: String) = "${apiBlobs(owner, repo)}/${encodeSegment(sha)}"

    /** The Contents API's inline `content` field is only populated for files
     *  under this size; at or above it, only the Git Data API's blob-by-sha
     *  endpoint ([apiBlob]/[fetchBlobBytes]) can retrieve a file's bytes. */
    const val CONTENTS_API_SIZE_LIMIT = 1024 * 1024L

    /**
     * Fetches one blob's raw bytes by its git object [sha] via the Git Data
     * API, decoding its base64 `content` field. Unlike the Contents API's
     * inline `content` (populated only for files under [CONTENTS_API_SIZE_LIMIT]),
     * this endpoint has no size ceiling, so it's the correct source for any
     * file at or above that limit — see
     * [com.zipapkbuilder.feature.filemanager.FileEditorController] and
     * [com.zipapkbuilder.feature.filemanager.ZipExtractController], the two
     * callers that need this. Returns null on any HTTP failure or if the
     * blob has no content field; callers decide how to surface each case,
     * since a real fetch failure and a legitimately-empty blob mean
     * different things depending on context.
     */
    fun fetchBlobBytes(token: String, owner: String, repo: String, sha: String): ByteArray? {
        if (sha.isEmpty()) return null
        val (code, body) = httpGet(token, apiBlob(owner, repo, sha))
        if (code != 200) return null
        val content = JSONObject(body).optString("content", "")
        if (content.isEmpty()) return null
        return Base64.decode(content.replace("\n", ""), Base64.DEFAULT)
    }

    fun apiWorkflows(owner: String, repo: String) = "${repoBase(owner, repo)}/actions/workflows"

    fun apiWorkflowRuns(owner: String, repo: String, workflowFile: String, perPage: Int) =
        "${apiWorkflows(owner, repo)}/${encodeSegment(workflowFile)}/runs?per_page=$perPage"

    fun apiWorkflowDispatches(owner: String, repo: String, workflowIdOrFile: String) =
        "${apiWorkflows(owner, repo)}/${encodeSegment(workflowIdOrFile)}/dispatches"

    fun apiActionsSecret(owner: String, repo: String, name: String) =
        "${repoBase(owner, repo)}/actions/secrets/${encodeSegment(name)}"

    fun apiActionsVariable(owner: String, repo: String, name: String) =
        "${repoBase(owner, repo)}/actions/variables/${encodeSegment(name)}"

    fun apiActionsVariables(owner: String, repo: String) = "${repoBase(owner, repo)}/actions/variables"

    /**
     * Turns a failed HTTP response into a specific, actionable hint instead of
     * a bare status code — distinguishes an invalid/expired token, a generic
     * permissions problem, "not found", and the three-way split within
     * 403/429 that matters most for a client hitting GitHub's API from a
     * single mobile device: an exhausted primary rate limit (wait until a
     * known reset time), a secondary/abuse-detection limit (slow down —
     * these fire from request *pattern*, not quota, so they can happen with
     * plenty of primary quota left), or a plain permissions 403 that has
     * nothing to do with rate limiting at all.
     *
     * [rateLimitInfo] is optional — every existing call site that doesn't
     * pass one gets exactly the same text this returned before headers were
     * read anywhere (falling back to matching GitHub's own rate-limit wording
     * in [body]), so nothing regresses for a caller that hasn't been updated.
     * Never throws, never returns null.
     */
    fun describeHttpError(code: Int, body: String, rateLimitInfo: RateLimitInfo? = null): String {
        if (code != 403 && code != 429) {
            return when (code) {
                401 -> "GitHub token invalid or expired (401) — check it in Settings."
                404 -> "Not found (404) — check the repository, path, or branch."
                422 -> "GitHub rejected the request (422) — the resource may not be ready yet."
                else -> "HTTP $code"
            }
        }

        // From here on, code is 403 or 429 — the two statuses GitHub uses for both
        // of its rate limits (and, for 403 only, plain permission failures too).
        val retryAfter = rateLimitInfo?.retryAfterSeconds
        val remaining  = rateLimitInfo?.remaining
        val resetIn    = rateLimitInfo?.resetEpochSeconds?.minus(System.currentTimeMillis() / 1000)
        val bodyMentionsRateLimit = body.contains("rate limit", ignoreCase = true)
        val waitSuffix = (retryAfter ?: resetIn)?.takeIf { it > 0 }?.let { " — try again in ${formatWaitTime(it)}" } ?: ""

        return when {
            // Retry-After is GitHub's own documented signal specifically for a
            // secondary (abuse-detection) limit — it isn't sent for a plain
            // permissions 403, and a secondary limit can fire even with primary
            // quota still remaining, so this check comes first.
            retryAfter != null ->
                "GitHub secondary rate limit hit ($code) — too many requests in a short time$waitSuffix."
            remaining == 0L ->
                "GitHub API rate limit reached ($code)$waitSuffix."
            // No rate-limit headers to go on (an older/unspecified caller, or an
            // endpoint that doesn't send them) — fall back to the same body-text
            // match the original implementation used, so a call site that hasn't
            // been updated to pass rateLimitInfo sees no change in behavior.
            code == 429 -> "GitHub API rate limit reached (429) — wait a while and try again."
            bodyMentionsRateLimit -> "GitHub API rate limit reached (403) — wait a while and try again."
            else -> "Permission denied (403) — check the token has the required scopes."
        }
    }

    /** Formats a wait duration for [describeHttpError] — "45s", "3m 12s". */
    private fun formatWaitTime(totalSeconds: Long): String {
        val s = totalSeconds.coerceAtLeast(1)
        return if (s >= 60) "${s / 60}m ${s % 60}s" else "${s}s"
    }

    /**
     * The base64-encoded length (no line wrapping, padding included) that
     * [rawByteCount] raw bytes will produce — i.e. what
     * `Base64.encodeToString(bytes, Base64.NO_WRAP).length` would return for
     * a byte array of that size, computed without touching any actual data.
     * Used to size the HTTP request body up front so [uploadStreamingBase64]
     * can stream straight into a fixed-length connection instead of
     * buffering the encoded form to measure it.
     */
    fun base64EncodedLength(rawByteCount: Long): Long = ((rawByteCount + 2) / 3) * 4

    /**
     * Builds the (prefix, suffix) JSON fragments that sandwich a streamed
     * `"content":"…"` field for a Contents API create/update PUT — the same
     * envelope [BuildFlowController][com.zipapkbuilder.feature.build.BuildFlowController]
     * and [FileManagerController][com.zipapkbuilder.feature.filemanager.FileManagerController]
     * both need, kept in one place instead of each building its own
     * `JSONObject`. [message] is escaped via [JSONObject.quote]; the content
     * itself is never touched here since [uploadStreamingBase64] streams it
     * separately — base64 output uses no character JSON would need to escape,
     * so it can be written straight into the body between these two pieces.
     */
    fun contentsApiEnvelope(message: String, branch: String, existingSha: String?): Pair<String, String> {
        val prefix = "{\"message\":${JSONObject.quote(message)},\"content\":\""
        val suffix = buildString {
            append("\",\"branch\":").append(JSONObject.quote(branch))
            if (existingSha != null) append(",\"sha\":").append(JSONObject.quote(existingSha))
            append("}")
        }
        return prefix to suffix
    }

    /**
     * Uploads [source] to GitHub as base64-encoded JSON content, streaming
     * the whole way through: raw bytes are read from [source] in small
     * chunks, base64-encoded on the fly by [Base64OutputStream], and written
     * straight into the HTTP request body between [jsonPrefix] and
     * [jsonSuffix]. At no point do the raw file, its base64 form, or the
     * full JSON body exist as one in-memory object — peak extra memory is a
     * single [STREAM_CHUNK_BYTES]-sized read buffer plus whatever small
     * internal buffer `Base64OutputStream` reuses across calls, regardless
     * of how large [source] is. This is what replaces the old
     * `readBytes()` → `Base64.encodeToString()` → `JSONObject` →
     * `toByteArray()` pipeline, which could hold up to four full-size
     * copies of the same data in memory at once.
     *
     * [rawLength] must be the exact byte count [source] will yield — needed
     * up front to compute the fixed `Content-Length` GitHub's API expects
     * (its gateway has been observed to reject large bodies sent without
     * one, so chunked transfer encoding is avoided here).
     *
     * [source] is always closed before this function returns, success,
     * failure, or cancellation — as is the connection's output stream and
     * the `Base64OutputStream` wrapping it (via `use {}`), so no stream is
     * ever left dangling in a field or a callback.
     *
     * [isCancelled] is polled once per chunk — the same granularity the old
     * chunked writers used — so a caller's cancel flag can abort mid-flight.
     */
    fun uploadStreamingBase64(
        token: String,
        urlStr: String,
        method: String,
        jsonPrefix: String,
        source: InputStream,
        rawLength: Long,
        jsonSuffix: String,
        isCancelled: () -> Boolean,
        onProgress: (written: Long, total: Long) -> Unit
    ): Pair<Int, String> {
        val prefixBytes = jsonPrefix.toByteArray(Charsets.UTF_8)
        val suffixBytes = jsonSuffix.toByteArray(Charsets.UTF_8)
        val totalBodyLength = prefixBytes.size + base64EncodedLength(rawLength) + suffixBytes.size

        val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            setRequestProperty("Authorization", "token $token")
            setRequestProperty("Accept", "application/vnd.github.v3+json")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            doOutput = true
            connectTimeout = 120_000; readTimeout = 300_000
            setFixedLengthStreamingMode(totalBodyLength)
        }
        return try {
            conn.connect()
            source.use { rawSource ->
                conn.outputStream.use { rawOut ->
                    rawOut.write(prefixBytes)
                    var rawSoFar = 0L
                    val buffer = ByteArray(STREAM_CHUNK_BYTES)
                    // NO_CLOSE: closing this flushes the final (possibly padded)
                    // base64 group into rawOut without closing rawOut itself —
                    // the JSON suffix still needs to be written after it.
                    Base64OutputStream(rawOut, Base64.NO_WRAP or Base64.NO_CLOSE).use { b64Out ->
                        while (true) {
                            if (isCancelled()) { conn.disconnect(); throw Exception("Cancelled by user") }
                            val n = rawSource.read(buffer)
                            if (n == -1) break
                            b64Out.write(buffer, 0, n)
                            rawSoFar += n
                            onProgress(prefixBytes.size + base64EncodedLength(rawSoFar), totalBodyLength)
                        }
                    }
                    rawOut.write(suffixBytes)
                    rawOut.flush()
                }
            }
            val code = conn.responseCode
            Pair(code, (if (code < 400) conn.inputStream else conn.errorStream)
                ?.bufferedReader()?.readText() ?: "")
        } finally { conn.disconnect() }
    }

    /** Raw bytes read (and base64-encoded) per streaming step in [uploadStreamingBase64] —
     *  small enough to be a negligible, constant memory cost regardless of file size,
     *  large enough to keep I/O overhead low. */
    private const val STREAM_CHUNK_BYTES = 128 * 1024
}
