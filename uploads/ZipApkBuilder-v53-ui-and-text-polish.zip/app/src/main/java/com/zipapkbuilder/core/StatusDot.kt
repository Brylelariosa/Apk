package com.zipapkbuilder.core

import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.widget.LinearLayout
import androidx.annotation.ColorInt

/**
 * A small filled circle used as a status marker in list rows (build runs, build history).
 * Replaces the old text glyphs (check mark, cross, bullets), which rendered differently
 * across device fonts and could not be sized or aligned reliably.
 */
fun Context.statusDot(@ColorInt color: Int, sizeDp: Int = 10, marginEndDp: Int = 12): View {
    val dp = resources.displayMetrics.density
    return View(this).apply {
        background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
        }
        layoutParams = LinearLayout.LayoutParams((sizeDp * dp).toInt(), (sizeDp * dp).toInt()).also {
            it.marginEnd = (marginEndDp * dp).toInt()
            it.gravity = android.view.Gravity.CENTER_VERTICAL
        }
    }
}
