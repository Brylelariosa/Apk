package com.zipapkbuilder.core

import android.graphics.Typeface
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan

/**
 * Console line styling. Log producers prefix a line with a plain-text level tag
 * (`[ok]`, `[warn]`, `[error]`, `[step]`, `[info]`, `[retry]`) instead of an emoji or symbol
 * glyph. The tag stays in the text, so copied and shared logs remain greppable and read the
 * same on every device font; here it is only colored. Lines without a tag are plain output.
 */
object LogStyle {

    private const val COLOR_OK    = 0xFF3DDC97.toInt()
    private const val COLOR_WARN  = 0xFFFFB454.toInt()
    private const val COLOR_ERROR = 0xFFFF6B6B.toInt()
    private const val COLOR_STEP  = 0xFF6CB6FF.toInt()
    private const val COLOR_INFO  = 0xFF8B93B8.toInt()
    private const val COLOR_DIM   = 0xFF4A5170.toInt()

    private val tagRegex = Regex("""^(\s*)\[(ok|warn|error|step|info|retry)]""")
    private val ruleRegex = Regex("""^\s*-{6,}\s*$""")

    private fun colorFor(tag: String): Int = when (tag) {
        "ok"    -> COLOR_OK
        "warn"  -> COLOR_WARN
        "error" -> COLOR_ERROR
        "step"  -> COLOR_STEP
        "retry" -> COLOR_WARN
        else    -> COLOR_INFO
    }

    /** Returns [line] plus a trailing newline as a styled [CharSequence] ready for `TextView.append`. */
    fun style(line: String): CharSequence {
        val sb = SpannableStringBuilder(line).append('\n')
        val m = tagRegex.find(line)
        if (m != null) {
            val tagTag = m.groupValues[2]
            val start = m.groups[1]!!.range.let { it.last + 1 }
            val end = m.range.last + 1
            sb.setSpan(ForegroundColorSpan(colorFor(tagTag)), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            sb.setSpan(StyleSpan(Typeface.BOLD), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            // Errors keep their whole message tinted so they stand out while scrolling.
            if (tagTag == "error") {
                sb.setSpan(ForegroundColorSpan(COLOR_ERROR), end, line.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
        } else if (ruleRegex.matches(line)) {
            sb.setSpan(ForegroundColorSpan(COLOR_DIM), 0, line.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        return sb
    }
}
