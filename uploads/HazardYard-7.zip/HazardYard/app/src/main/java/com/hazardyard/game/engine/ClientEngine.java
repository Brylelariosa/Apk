package com.hazardyard.game.engine;

import com.hazardyard.game.bot.BotSquad;
import com.hazardyard.game.core.CollisionSystem;
import com.hazardyard.game.core.Dodge;
import com.hazardyard.game.core.GameConfig;
import com.hazardyard.game.core.GameMode;
import com.hazardyard.game.core.GameState;
import com.hazardyard.game.core.LocalInput;
import com.hazardyard.game.core.MapLibrary;
import com.hazardyard.game.core.MathUtil;
import com.hazardyard.game.core.Pickups;
import com.hazardyard.game.core.Player;
import com.hazardyard.game.core.Projectile;
import com.hazardyard.game.core.ProjectilePool;
import com.hazardyard.game.core.Weapon;
import com.hazardyard.game.core.WeaponDef;
import com.hazardyard.game.net.ClientManager;
import com.hazardyard.game.net.LobbyManager;
import com.hazardyard.game.net.NetworkManager;
import com.hazardyard.game.net.Packets;
import com.hazardyard.game.net.PacketReader;
import com.hazardyard.game.net.PacketWriter;
import com.hazardyard.game.net.Protocol;
import com.hazardyard.game.net.SnapshotCodec;
import com.hazardyard.game.net.SurvivalCodec;
import com.hazardyard.game.survival.Car;
import com.hazardyard.game.survival.SurvivalSim;
import com.hazardyard.game.survival.SurvivalState;
import com.hazardyard.game.survival.Zombie;

/**
 * Mirrors the host's match. Remote players are interpolated between snapshots; the local player moves
 * immediately (client-side prediction) and is nudged back only when the host's authoritative position,
 * matched to the input it acknowledged, disagrees noticeably. Bullets are simulated locally from fire
 * events for display, but only the host decides who gets hit.
 */
public final class ClientEngine implements GameEngine {
    /** Errors below this (world units) are ignored: they are timing noise, not disagreement. */
    static final float CORRECTION_DEADZONE = 10f;
    /** Errors above this snap instantly instead of gliding. */
    static final float SNAP_DISTANCE = 64f;
    private static final int HISTORY = 64;

    private final ClientManager net;
    private final GameState st;
    private final int myId;
    private final CollisionSystem col;
    private final SnapshotCodec.Data snap = new SnapshotCodec.Data();
    private final PacketReader reader = new PacketReader();
    private final PacketWriter writer = new PacketWriter(64);
    private final Packets.Input inputPacket = new Packets.Input();
    private final Packets.Fire firePacket = new Packets.Fire();
    private final Packets.Hit hitPacket = new Packets.Hit();
    private final Packets.Kill killPacket = new Packets.Kill();
    private final LocalInput quantized = new LocalInput();

    // prediction bookkeeping
    private final float[] sentX = new float[HISTORY];
    private final float[] sentY = new float[HISTORY];
    private int sendSeq;
    private float sendTimer;
    private int lastMx, lastMy, lastAim16;
    private boolean lastFiring;
    private boolean sentOnce;

    private final float[] dir = new float[2];
    /** How long each player's current reload takes, so the progress can run smoothly between snapshots. */
    private final float[] reloadSeconds = new float[GameConfig.MAX_PLAYERS];
    /** How long snapshots really take to arrive, smoothed; remote players are blended over this time so a jittery link does not make them stop and go. */
    private float interpInterval = GameConfig.SNAPSHOT_INTERVAL;
    private long lastSnapshotNanos;

    private boolean hasSnapshot;
    private volatile boolean finished;
    private String reason;
    /** Number of position corrections applied so far (exposed for tests and diagnostics). */
    public int correctionCount;

    public ClientEngine(ClientManager net) {
        this.net = net;
        this.myId = net.localPlayerId();
        GameMode mode = GameMode.byId(net.lobby().getModeId());
        if (mode.survival) {
            SurvivalState sv = new SurvivalState(net.lobby().getSeed());
            st = new GameState(MapLibrary.get(mode.mapId), sv.terrain, myId, mode);
            st.survival = sv;
        } else {
            st = new GameState(MapLibrary.get(net.lobby().getMapId()), myId, mode);
        }
        col = st.collision;
        LobbyManager.Entry[] roster = new LobbyManager.Entry[GameConfig.MAX_HUMANS];
        for (int i = 0; i < roster.length; i++) roster[i] = new LobbyManager.Entry();
        net.lobby().copyTo(roster);
        for (int i = 0; i < st.players.length; i++) {
            // A slot without a lobby row is a bot; its name is a function of the slot, so it matches the host's.
            st.players[i].name = i < roster.length && roster[i].used ? roster[i].name : BotSquad.nameFor(i);
        }
    }

    @Override
    public GameState state() {
        return st;
    }

    @Override
    public void fixedUpdate(float dt, LocalInput in) {
        if (finished) return;
        NetworkManager.Inbound m;
        while ((m = net.poll()) != null) handle(m);
        if (net.consumeReturnToLobby()) {
            finished = true;
            return;
        }
        if (net.isClosed()) {
            finished = true;
            reason = "Connection to the host was lost.";
            return;
        }
        if (!hasSnapshot) return;

        quantized.moveX = in.moveX;
        quantized.moveY = in.moveY;
        quantized.aim = in.aim;
        quantized.firing = in.firing;
        quantized.quantizeMove();

        if (in.dodge && !isDriving()) startLocalDodge();
        if (in.pickup) sendPickup();
        for (int k = 0; k < in.cmdCount; k++) net.sendSurvivalCommand(in.cmdType[k], in.cmdA[k], in.cmdB[k]);
        predictLocal(dt);
        sendInput(dt, in);
        advanceProjectiles(dt);
        st.zone.advance(dt);
        if (st.survival != null) smoothSurvival(dt);
        for (int i = 0; i < st.players.length; i++) {
            Player p = st.players[i];
            if (p.hitFlash > 0f) p.hitFlash -= dt;
            if (p.swingT < 1f) p.swingT = Math.min(1f, p.swingT + dt / Math.max(0.05f, p.swingDur));
            if (p.muzzleFlash > 0f) p.muzzleFlash -= dt;
            Weapon w = p.weapon;
            if (p.connected && w.reloading && reloadSeconds[i] > 0f) {
                w.reloadFraction = Math.min(0.995f, w.reloadFraction + dt / reloadSeconds[i]);
            }
        }
        st.effects.update(dt);
        st.ragdolls.update(dt, st.terrain);
    }

    /**
     * The local player rolls at once, using the same steps as the host, and the request goes out with
     * the direction so the host rolls the same way. When the host has to refuse (it almost never
     * does) the position correction simply puts the player back.
     */
    private void startLocalDodge() {
        Player me = st.players[myId];
        if (!me.connected || st.phase != GameState.PHASE_PLAYING || !Dodge.canStart(me, 0f)) return;
        Dodge.pickDirection(quantized.moveX, quantized.moveY, me.aim, dir);
        int angle16 = MathUtil.angleToU16((float) Math.atan2(dir[1], dir[0]));
        float a = MathUtil.u16ToAngle(angle16);
        Dodge.start(me, (float) Math.cos(a), (float) Math.sin(a));
        me.weapon.cancelReload();      // the host cancels the reload too; this just shows it at once
        net.sendDodge(angle16);
    }

    /** The Pick Up button: asks the host for the weapon the prompt is offering. The weapon arrives with the next snapshot. */
    private void sendPickup() {
        Player me = st.players[myId];
        if (!me.connected || !me.alive) return;
        if (st.survival != null) {          // survival has no pads: the host works out what the button does
            net.sendPickup(-1);
            return;
        }
        int pad = Pickups.offered(st, me);
        if (pad >= 0) net.sendPickup(pad);
    }

    private boolean isDriving() {
        return st.survival != null && st.survival.drivingCar[myId] >= 0;
    }

    /** Survival: the clock keeps running between messages and zombies and cars glide to where the host says they are. */
    private void smoothSurvival(float dt) {
        SurvivalState sv = st.survival;
        sv.time += dt;
        if (sv.toastTimer > 0f) sv.toastTimer -= dt;
        float k = 1f - (float) Math.exp(-14f * dt);
        for (Zombie z : sv.zombies) {
            if (!z.active) continue;
            float dx = z.x - z.rx, dy = z.y - z.ry;
            float d2 = dx * dx + dy * dy;
            if (d2 > 200f * 200f) {
                z.rx = z.x;
                z.ry = z.y;
            } else {
                z.rx += dx * k;
                z.ry += dy * k;
                z.walk += (float) Math.sqrt(d2) * k * 0.08f;
            }
            z.rAim = MathUtil.rotateToward(z.rAim, z.aim, 10f * dt);
            if (z.hurt > 0f) z.hurt -= dt;
            if (z.stateLock > 0f) z.stateLock -= dt;
            z.stateT += dt;
            z.hitT += dt;
        }
        for (Car c : sv.cars) {
            if (!c.active) continue;
            float dx = c.x - c.rx, dy = c.y - c.ry;
            if (dx * dx + dy * dy > 300f * 300f) {
                c.rx = c.x;
                c.ry = c.y;
            } else {
                c.rx += dx * k;
                c.ry += dy * k;
            }
            c.rHeading = MathUtil.rotateToward(c.rHeading, c.heading, 8f * dt);
        }
    }

    // ------------------------------------------------------------------ inbound messages

    private void onSurvivalEvent() {
        int kind = reader.u8();
        if (kind == 0) {
            int sound = reader.u8();
            float x = reader.i32() / GameConfig.POS_SCALE;
            float y = reader.i32() / GameConfig.POS_SCALE;
            float vol = reader.u8() / 100f;
            int pitch = reader.u8();
            if (sound < com.hazardyard.game.core.Sounds.COUNT) {
                if (pitch > 0) st.audio.playAt(sound, x, y, vol, pitch / 50f);
                else st.audio.playAt(sound, x, y, vol);
            }
        } else if (kind == 1) {
            int who = reader.u8();
            int code = reader.u8();
            if (who == myId && code < SurvivalSim.TOASTS.length) {
                st.survival.toast = code;
                st.survival.toastTimer = 2.4f;
            }
        } else if (kind == 2) {
            int id = reader.u16();
            int kt = reader.u8();
            float x = reader.i32() / GameConfig.POS_SCALE;
            float y = reader.i32() / GameConfig.POS_SCALE;
            float angle = MathUtil.u8ToAngle(reader.u8());
            float strength = reader.u8() / 100f;
            int dmg = reader.u8();
            Presentation.zombieEvent(st, id, (kt >> 4) & 3, kt & 15, x, y, angle, strength, dmg);
        }
    }

    private void handle(NetworkManager.Inbound m) {
        try {
            reader.wrap(m.data, 0, m.data.length);
            switch (reader.u8()) {
                case Protocol.S_SNAPSHOT:
                    SnapshotCodec.decode(reader, snap, st.pickups.length, st.mode.royale);
                    applySnapshot();
                    break;
                case Protocol.S_FIRE:
                    firePacket.read(reader);
                    onFire();
                    break;
                case Protocol.S_HIT:
                    hitPacket.read(reader);
                    onHit();
                    break;
                case Protocol.S_KILL:
                    killPacket.read(reader);
                    onKill();
                    break;
                case Protocol.S_SURV:
                    if (st.survival != null) SurvivalCodec.decodeState(reader, st);
                    break;
                case Protocol.S_SURV_EVENT:
                    if (st.survival != null) onSurvivalEvent();
                    break;
                case Protocol.S_SURV_EDIT:
                    if (st.survival != null) {
                        int layer = reader.u8();
                        int tx = reader.i32(), ty = reader.i32();
                        int value = reader.u8(), meta = reader.u8();
                        if (layer == 0) st.survival.terrain.setObj(tx, ty, (byte) value, meta);
                        else st.survival.terrain.setGround(tx, ty, (byte) value);
                    }
                    break;
                case Protocol.S_SURV_INV:
                    if (st.survival != null) SurvivalCodec.decodeInventory(reader, st.survival.inv[myId]);
                    break;
                default:
                    break;
            }
        } catch (RuntimeException malformed) {
            // Ignore a damaged packet; the next snapshot replaces whatever it carried.
        }
    }

    private void applySnapshot() {
        long now = System.nanoTime();
        if (hasSnapshot) {
            float gap = (now - lastSnapshotNanos) * 1e-9f;
            float target = MathUtil.clamp(gap, GameConfig.SNAPSHOT_INTERVAL, 0.12f);
            interpInterval += (target - interpInterval) * 0.12f;
        }
        lastSnapshotNanos = now;
        hasSnapshot = true;
        st.phase = MathUtil.clamp(snap.phase, GameState.PHASE_LOBBY, GameState.PHASE_FINISHED);
        st.timeLeft = snap.timeLeftDs / 10f;
        st.countdown = snap.countdownDs / 10f;
        st.winnerId = snap.winner;
        for (int i = 0; i < st.pickups.length && i < snap.padActive.length; i++) {
            boolean active = snap.padActive[i];
            if (st.pickups[i].active && !active) Presentation.pickup(st, i, st.pickups[i].item);
            st.pickups[i].active = active;
        }
        if (st.mode.royale) {
            st.zone.load(snap.zoneShrinks, (snap.zoneFlags & SnapshotCodec.Z_SHRINKING) != 0,
                    (snap.zoneFlags & SnapshotCodec.Z_COLLAPSED) != 0, snap.zoneCx, snap.zoneCy, snap.zoneR,
                    snap.zoneToCx, snap.zoneToCy, snap.zoneToR, snap.zoneTimer, snap.zoneStage);
        }
        for (int i = 0; i < GameConfig.MAX_PLAYERS; i++) {
            Player p = st.players[i];
            if ((snap.presentMask & (1 << i)) == 0) {
                p.connected = false;
                p.alive = false;
                continue;
            }
            if (!p.connected) {
                p.connected = true;
                p.interpValid = false;
            }
            int flags = snap.flags[i];
            boolean wasAlive = p.alive;
            p.alive = (flags & SnapshotCodec.F_ALIVE) != 0;
            p.health = snap.health[i];
            p.armor = snap.armor[i];
            p.placement = snap.placement[i];
            p.kills = snap.kills[i];
            p.deaths = snap.deaths[i];
            p.respawnTimer = snap.respawnDs[i] / 10f;
            p.spawnProtect = (flags & SnapshotCodec.F_PROTECTED) != 0 ? 1f : 0f;
            Weapon w = p.weapon;
            if (w.def.id != snap.weapon[i]) w.equip(WeaponDef.byId(snap.weapon[i]));
            w.ammo = snap.ammo[i];
            if (st.mode.royale) {
                // the gear: which slot is in hand, what each slot holds and its own supply
                int g = snap.gear[i];
                p.activeSlot = g & 1;
                p.backpack = (g >> 1) & 3;
                p.switchTimer = (g & 8) != 0 ? com.hazardyard.game.core.GameWorld.SWITCH_TIME * 0.5f : 0f;
                p.slotWeapon[0] = snap.slot0[i] == 255 ? -1 : snap.slot0[i];
                p.slotWeapon[1] = snap.slot1[i] == 255 ? -1 : snap.slot1[i];
                p.slotReserve[0] = snap.reserve0[i] == 65535 ? Integer.MAX_VALUE : snap.reserve0[i];
                p.slotReserve[1] = snap.reserve1[i];
                p.slotAmmo[p.activeSlot] = snap.ammo[i];
                p.slotAmmo[1 - p.activeSlot] = snap.otherAmmo[i];
                w.reserve = p.slotReserve[p.activeSlot];
            }
            boolean wasReloading = w.reloading;
            w.reloading = (flags & SnapshotCodec.F_RELOADING) != 0;
            float hostFraction = snap.reload[i] / 255f;
            if (!w.reloading) {
                w.reloadFraction = 0f;
                reloadSeconds[i] = 0f;
            } else if (!wasReloading) {
                w.reloadFraction = hostFraction;
                reloadSeconds[i] = Math.max(0.2f, w.def.reloadDuration(w.ammo));
            } else {
                // Between snapshots the progress runs on by itself (see fixedUpdate); the host's value pulls it back in line.
                w.reloadFraction += (hostFraction - w.reloadFraction) * 0.5f;
            }
            if (i == myId) {
                reconcileLocal(p, i, wasAlive);
            } else {
                boolean rolling = (flags & SnapshotCodec.F_ROLLING) != 0;
                if (rolling && p.rollTimer <= 0f) p.rollTimer = GameConfig.DODGE_DURATION;
                else if (!rolling) p.rollTimer = 0f;
                updateRemote(p, i, wasAlive);
            }
        }
    }

    private void updateRemote(Player p, int i, boolean wasAlive) {
        float nx = snap.x[i];
        float ny = snap.y[i];
        float na = snap.aim[i];
        p.x = nx;
        p.y = ny;
        p.aim = na;
        float dx = nx - p.rx;
        float dy = ny - p.ry;
        if (p.rollTimer > 0f) {
            float len2 = dx * dx + dy * dy;
            if (len2 > 1f) {
                float inv = 1f / (float) Math.sqrt(len2);
                p.rollDirX = dx * inv;
                p.rollDirY = dy * inv;
            } else if (p.rollDirX == 0f && p.rollDirY == 0f) {
                p.rollDirX = (float) Math.cos(na);
                p.rollDirY = (float) Math.sin(na);
            }
        }
        boolean teleport = !p.interpValid || !p.alive || !wasAlive || dx * dx + dy * dy > 100f * 100f;
        if (teleport) {
            p.fromX = p.toX = p.rx = nx;
            p.fromY = p.toY = p.ry = ny;
            p.fromAim = p.toAim = p.rAim = na;
            p.interpT = 1f;
            p.interpValid = true;
        } else {
            p.fromX = p.rx;
            p.fromY = p.ry;
            p.fromAim = p.rAim;
            p.toX = nx;
            p.toY = ny;
            p.toAim = na;
            p.interpT = 0f;
        }
    }

    /**
     * Compares the host's position with where this client was when it sent the input the host had
     * applied last. The difference is the real disagreement; the time the packet spent travelling
     * cancels out.
     */
    private void reconcileLocal(Player p, int i, boolean wasAlive) {
        float sx = snap.x[i];
        float sy = snap.y[i];
        if (p.alive && st.survival != null && st.survival.drivingCar[i] >= 0) {
            // In a car the host moves us: follow it, gliding over the jump instead of predicting.
            float ox = p.x + p.visX, oy = p.y + p.visY;
            p.x = sx;
            p.y = sy;
            p.visX = ox - sx;
            p.visY = oy - sy;
            if (p.visX * p.visX + p.visY * p.visY > 250f * 250f) {
                p.visX = 0f;
                p.visY = 0f;
            }
            p.rollTimer = 0f;
            p.interpValid = true;
            return;
        }
        boolean predicting = p.alive && wasAlive && st.phase == GameState.PHASE_PLAYING && p.interpValid;
        // The host is the judge of the cooldown: only a clearly longer wait than the predicted one is adopted
        // (the small difference is just snapshot delay, and adopting it would make the button flicker).
        float hostCooldown = snap.dodgeCdCs[i] / 100f;
        if (hostCooldown > p.dodgeCooldown + 0.35f) p.dodgeCooldown = hostCooldown;
        if (!predicting) {
            p.rollTimer = 0f;
            p.x = sx;
            p.y = sy;
            p.visX = 0f;
            p.visY = 0f;
            p.rx = sx;
            p.ry = sy;
            if (p.alive && !wasAlive) {
                p.aim = snap.aim[i];
                p.rAim = p.aim;
            }
            p.interpValid = true;
            return;
        }
        if (!sentOnce) return;
        int ack = snap.ack[i];
        if (((sendSeq - ack) & 0xFF) >= HISTORY) return;
        int slot = ack & (HISTORY - 1);
        float ex = sx - sentX[slot];
        float ey = sy - sentY[slot];
        float err2 = ex * ex + ey * ey;
        if (err2 < CORRECTION_DEADZONE * CORRECTION_DEADZONE) return;
        correctionCount++;
        p.x += ex;
        p.y += ey;
        if (err2 > SNAP_DISTANCE * SNAP_DISTANCE) {
            p.visX = 0f;
            p.visY = 0f;
        } else {
            p.visX -= ex;
            p.visY -= ey;
        }
        col.pushOut(p.x, p.y, GameConfig.PLAYER_RADIUS);
        p.x = col.resX;
        p.y = col.resY;
        // Inputs sent before this correction carry stale positions; shift them so the next
        // snapshot does not see (and apply) the same disagreement a second time.
        for (int k = 0; k < HISTORY; k++) {
            sentX[k] += ex;
            sentY[k] += ey;
        }
    }

    private void onFire() {
        WeaponDef d = WeaponDef.byId(firePacket.weaponId);
        int owner = firePacket.owner;
        float fx = firePacket.x;
        float fy = firePacket.y;
        if (owner == myId) {
            // The host's position is a little behind what this player sees; start the bullets at the
            // barrel the player is looking at (a small difference only, so a big correction is ignored).
            Player me = st.players[myId];
            float ex = me.rx - fx;
            float ey = me.ry - fy;
            if (me.alive && ex * ex + ey * ey < 24f * 24f) {
                fx = me.rx;
                fy = me.ry;
            }
        }
        if (!d.melee) {
            d.spawn(st.projectiles, col, owner, fx, fy, firePacket.angle, firePacket.seed, firePacket.baseId);
            if (owner >= 0 && owner < st.players.length) st.players[owner].muzzleFlash = 0.06f;
        }
        Presentation.shot(st, owner, d.id, fx, fy, firePacket.angle, firePacket.seed);
    }

    private void onHit() {
        Projectile b = st.projectiles.findById(hitPacket.projectileId);
        int weaponId = b != null ? b.weaponId : WeaponDef.PISTOL;
        if (b == null && (hitPacket.projectileId & 0xFF00) == 0xFF00) weaponId = hitPacket.projectileId & 0xFF;   // a melee blow
        if (b != null) st.projectiles.release(b);
        Presentation.hit(st, hitPacket.victim, hitPacket.x, hitPacket.y, weaponId, hitPacket.damage);
        if (hitPacket.victim >= 0 && hitPacket.victim < st.players.length && hitPacket.damage > 0) {
            st.players[hitPacket.victim].hitFlash = 0.15f;
        }
    }

    private void onKill() {
        Presentation.kill(st, killPacket.killer, killPacket.victim, killPacket.weaponId);
    }

    // ------------------------------------------------------------------ local prediction + output

    private void predictLocal(float dt) {
        Player me = st.players[myId];
        if (!me.connected) return;
        me.fromX = me.x + me.visX;
        me.fromY = me.y + me.visY;
        me.fromAim = me.aim;
        me.aim = MathUtil.rotateToward(me.aim, quantized.aim, GameConfig.PLAYER_TURN_RATE * dt);
        me.rAim = me.aim;
        if (me.alive && st.phase == GameState.PHASE_PLAYING) Dodge.tickCooldown(me, dt);
        boolean driving = isDriving();
        if (me.alive && st.phase == GameState.PHASE_PLAYING && me.isRolling() && !driving) {
            Dodge.step(me, col, dt);
            pushOutOfRemotePlayers(me);
        } else if (me.alive && st.phase == GameState.PHASE_PLAYING && !driving) {
            float mx = quantized.moveX;
            float my = quantized.moveY;
            float len2 = mx * mx + my * my;
            if (len2 > 1f) {
                float inv = 1f / (float) Math.sqrt(len2);
                mx *= inv;
                my *= inv;
                len2 = 1f;
            }
            if (len2 > 0f) {
                float step = GameConfig.PLAYER_SPEED * dt;
                col.moveCircle(me.x, me.y, mx * step, my * step, GameConfig.PLAYER_RADIUS);
                me.x = col.resX;
                me.y = col.resY;
                pushOutOfRemotePlayers(me);
            }
        }
        float decay = (float) Math.exp(-12f * dt);
        me.visX *= decay;
        me.visY *= decay;
        me.rx = me.x + me.visX;
        me.ry = me.y + me.visY;
        me.toX = me.rx;
        me.toY = me.ry;
        me.toAim = me.aim;
    }

    /** Players are solid to each other; remote players are taken at the position they are drawn at. */
    private void pushOutOfRemotePlayers(Player me) {
        float minDist = 2f * GameConfig.PLAYER_RADIUS;
        boolean moved = false;
        for (int i = 0; i < st.players.length; i++) {
            Player o = st.players[i];
            if (o == me || !o.connected || !o.alive) continue;
            float dx = me.x - o.rx;
            float dy = me.y - o.ry;
            float d2 = dx * dx + dy * dy;
            if (d2 >= minDist * minDist) continue;
            float d = (float) Math.sqrt(d2);
            if (d < 1e-4f) continue;
            float push = (minDist - d) / d;
            me.x += dx * push * 0.5f;
            me.y += dy * push * 0.5f;
            moved = true;
        }
        if (moved) {
            col.pushOut(me.x, me.y, GameConfig.PLAYER_RADIUS);
            me.x = col.resX;
            me.y = col.resY;
        }
    }

    private void sendInput(float dt, LocalInput in) {
        Player me = st.players[myId];
        sendTimer += dt;
        int mx = Math.round(quantized.moveX * 127f);
        int my = Math.round(quantized.moveY * 127f);
        int aim16 = MathUtil.angleToU16(in.aim);
        boolean moving = mx != 0 || my != 0;
        boolean dirty = mx != lastMx || my != lastMy || aim16 != lastAim16;
        boolean flagChanged = in.firing != lastFiring;
        float interval = (moving || dirty) ? GameConfig.INPUT_SEND_INTERVAL_MOVING : GameConfig.INPUT_SEND_INTERVAL_IDLE;
        if (sentOnce && !flagChanged && sendTimer < interval - 0.001f) {
            if (in.reload) net.sendReload();
            if (in.switchWeapon) net.sendSwitch();
            return;
        }
        sendSeq = (sendSeq + 1) & 0xFF;
        inputPacket.seq = sendSeq;
        inputPacket.moveX = mx;
        inputPacket.moveY = my;
        inputPacket.aim16 = aim16;
        inputPacket.firing = in.firing;
        net.send(inputPacket.encode(writer));
        sentX[sendSeq & (HISTORY - 1)] = me.x;
        sentY[sendSeq & (HISTORY - 1)] = me.y;
        lastMx = mx;
        lastMy = my;
        lastAim16 = aim16;
        lastFiring = in.firing;
        sendTimer = 0f;
        sentOnce = true;
        if (in.reload) net.sendReload();
        if (in.switchWeapon) net.sendSwitch();
    }

    private void advanceProjectiles(float dt) {
        ProjectilePool pool = st.projectiles;
        for (int i = pool.activeCount - 1; i >= 0; i--) {
            Projectile b = pool.items[pool.activeList[i]];
            int status = col.advance(b, dt);
            if (status == CollisionSystem.HIT_WALL) {
                Presentation.wallImpact(st, b.x, b.y, b.weaponId);
                pool.release(b);
            } else if (status == CollisionSystem.EXPIRED) {
                pool.release(b);
            }
        }
    }

    // ------------------------------------------------------------------ per frame

    @Override
    public void frameUpdate(float dt, float alpha) {
        float blend = MathUtil.clamp(alpha, 0f, 1f);
        st.renderAlpha = blend;
        Player me = st.players[myId];
        if (me.connected && hasSnapshot) {
            me.rx = me.fromX + (me.toX - me.fromX) * blend;
            me.ry = me.fromY + (me.toY - me.fromY) * blend;
            me.rAim = MathUtil.lerpAngle(me.fromAim, me.toAim, blend);
            me.rollU = Interpolation.rollProgress(me, blend);
        }
        for (int i = 0; i < st.players.length; i++) {
            Player p = st.players[i];
            if (i == myId || !p.connected || !p.interpValid) continue;
            if (p.rollTimer > 0f) p.rollTimer = Math.max(0f, p.rollTimer - dt);
            p.rollU = p.rollTimer > 0f ? Dodge.progress(p) : 0f;
            p.interpT += dt;
            float a = Math.min(p.interpT / interpInterval, 1.35f);
            p.rx = p.fromX + (p.toX - p.fromX) * a;
            p.ry = p.fromY + (p.toY - p.fromY) * a;
            p.rAim = MathUtil.lerpAngle(p.fromAim, p.toAim, Math.min(a, 1f));
        }
    }

    @Override
    public boolean isFinished() {
        return finished;
    }

    @Override
    public String finishReason() {
        return reason;
    }

    @Override
    public int pingMs() {
        return net.pingMs;
    }

    @Override
    public void close() {
        finished = true;
    }
}
