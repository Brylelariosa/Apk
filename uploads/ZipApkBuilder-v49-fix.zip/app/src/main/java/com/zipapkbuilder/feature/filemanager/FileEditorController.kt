package com.zipapkbuilder.feature.filemanager

import android.app.AlertDialog
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import com.zipapkbuilder.MainActivity
import com.zipapkbuilder.R
import com.zipapkbuilder.core.ButtonTone
import com.zipapkbuilder.core.DialogAction
import com.zipapkbuilder.core.Formatters
import com.zipapkbuilder.core.dialogWithActions
import com.zipapkbuilder.core.iconButton
import com.zipapkbuilder.model.RepoItem
import com.zipapkbuilder.net.GitHubApi

/**
 * Views, edits, saves, and copies the content of a single repo file — the
 * code-editor dialog (line numbers, horizontal scroll, search, syntax
 * coloring) and the GitHub reads/writes behind it. Split out of
 * [FileManagerController] so the editor's fairly large self-contained UI
 * doesn't share a file with browsing or file-operation concerns.
 *
 * [refreshBrowser] re-opens the browser dialog at a given path after a save
 * completes — passed in rather than depending on [FileBrowserController]
 * directly, since that class in turn depends on this one to handle the
 * "View / Edit" menu action; a plain callback avoids a circular class
 * reference between the two.
 */
class FileEditorController(
    private val activity: MainActivity,
    private val refreshBrowser: (token: String, owner: String, repo: String, branch: String, path: String) -> Unit
) {

    /** Fetches file content from GitHub and opens the editor dialog. */
    fun fetchAndViewFile(
        token: String, owner: String, repo: String, branch: String,
        item: RepoItem, currentPath: String
    ) {
        activity.setBusy(true)
        activity.appendLog("Loading ${item.name} …")
        activity.bgExecutor.execute {
            try {
                val bytes: ByteArray
                var sha = item.sha
                if (item.size >= GitHubApi.CONTENTS_API_SIZE_LIMIT) {
                    // The Contents API omits `content` entirely for files this large —
                    // go straight to the Git Data API's blob endpoint, which has no such
                    // limit. A file this size can never legitimately decode to zero
                    // bytes, so a null here is a real fetch failure, not "binary/empty".
                    bytes = GitHubApi.fetchBlobBytes(token, owner, repo, item.sha)
                        ?: throw Exception("Could not fetch ${item.path} (${Formatters.fmtBytes(item.size)}) from blob storage")
                    // sha is unchanged — it's exactly what was requested by.
                } else {
                    val (code, body) = GitHubApi.httpGet(token, GitHubApi.apiContents(owner, repo, item.path))
                    if (code != 200) throw Exception("HTTP $code fetching ${item.path}")
                    val obj = org.json.JSONObject(body)
                    sha = obj.optString("sha", item.sha)
                    // GitHub wraps base64 at 60 chars — strip all whitespace before decoding
                    val raw  = obj.optString("content", "").replace("\n", "").replace("\r", "")
                    bytes = try { android.util.Base64.decode(raw, android.util.Base64.DEFAULT) } catch (e: Exception) { ByteArray(0) }
                }
                val text = if (bytes.isEmpty()) "(binary or empty file — not editable)" else {
                    try { String(bytes, Charsets.UTF_8) } catch (e: Exception) { "(binary file — not editable as text)" }
                }
                activity.mainHandler.post {
                    activity.setBusy(false)
                    if (activity.isFinishing || activity.isDestroyed) return@post
                    showFileEditorDialog(token, owner, repo, branch, item.copy(sha = sha), text, currentPath)
                }
            } catch (e: Exception) {
                activity.appendLog("✗ ${e.message}")
                activity.mainHandler.post { activity.setBusy(false) }
            }
        }
    }

    /**
     * Applies lightweight, generic syntax coloring to [editable] — comments,
     * quoted strings, numbers, and `key:` / `key =` style declarations. This
     * editor opens whatever text file a project happens to contain (YAML,
     * Gradle, Kotlin, XML, JSON, Markdown…), so rather than a real per-language
     * parser (well beyond what's practical here), the rules below are the
     * handful of patterns that read reasonably across all of them.
     *
     * Applied once when a file is opened, not on every keystroke: re-running
     * these regexes across the whole document on every character typed would
     * add real, visible lag on a large file (the same reasoning the line-number
     * gutter sync already applies) for a cosmetic feature that doesn't need to
     * track edits live. Freshly typed text simply stays the default color until
     * the file is reopened — a reasonable trade-off for a settings/config
     * editor that's read far more often than typed into character-by-character.
     */
    private fun applySyntaxHighlighting(editable: android.text.Editable) {
        val text = editable.toString()
        fun color(regex: Regex, colorInt: Int) {
            for (m in regex.findAll(text)) {
                editable.setSpan(
                    android.text.style.ForegroundColorSpan(colorInt),
                    m.range.first, m.range.last + 1,
                    android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                )
            }
        }
        // Order matters: later calls painting over earlier ones is fine since
        // comments/strings are checked first and rarely overlap with the rest.
        color(Regex("""(?m)^\s*#.*$"""), 0xFF6A9955.toInt())               // YAML/shell/gradle-kts comments
        color(Regex("""(?m)^\s*//.*$"""), 0xFF6A9955.toInt())               // C-style comments
        color(Regex("""<!--[\s\S]*?-->"""), 0xFF6A9955.toInt())            // XML comments
        color(Regex("\"(?:[^\"\\\\]|\\\\.)*\""), 0xFFCE9178.toInt())         // "double-quoted strings"
        color(Regex("""'(?:[^'\\]|\\.)*'"""), 0xFFCE9178.toInt())         // 'single-quoted strings'
        color(Regex("""\b\d+(\.\d+)?\b"""), 0xFFB5CEA8.toInt())            // numbers
        color(Regex("""(?m)^\s*[A-Za-z0-9_.\-]+(?=\s*:)"""), 0xFF7EC4E8.toInt()) // yaml `key:` / gradle `key =`
    }

    /** Shows the improved file editor dialog — line numbers, horizontal scroll, status bar. */
    private fun showFileEditorDialog(
        token: String, owner: String, repo: String, branch: String,
        item: RepoItem, content: String, currentPath: String
    ) {
        val dp       = activity.resources.displayMetrics.density
        val screenH  = activity.resources.displayMetrics.heightPixels
        val screenW  = activity.resources.displayMetrics.widthPixels
        val isBinary = content.startsWith("(binary")

        // ── Colour palette (GitHub dark) ─────────────────────────────────
        val bgEditor   = 0xFF0D1117.toInt()
        val bgGutter   = 0xFF161B22.toInt()
        val bgTitleBar = 0xFF1C2038.toInt()
        val bgStatus   = 0xFF161B22.toInt()
        val clrCode    = 0xFFE6EDF3.toInt()
        val clrGutter  = 0xFF495570.toInt()
        val clrInfo    = 0xFF9AA0B8.toInt()
        val clrBadge   = 0xFF7C6BFF.toInt()

        val lines = content.lines()
        val lineCount = lines.size

        // ── Top info bar ─────────────────────────────────────────────────
        val infoBar = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setBackgroundColor(bgTitleBar)
            setPadding((12*dp).toInt(), (8*dp).toInt(), (12*dp).toInt(), (8*dp).toInt())
        }
        val ext = item.name.substringAfterLast(".", "").uppercase().takeIf { it.isNotEmpty() } ?: "TXT"
        val extBadge = TextView(activity).apply {
            text = ext
            textSize = 9.5f
            setTextColor(0xFFFFFFFF.toInt())
            typeface = android.graphics.Typeface.MONOSPACE
            setBackgroundColor(clrBadge)
            setPadding((6*dp).toInt(), (2*dp).toInt(), (6*dp).toInt(), (2*dp).toInt())
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { it.marginEnd = (10*dp).toInt() }
        }
        val infoTv = TextView(activity).apply {
            val sizeStr = when {
                content.length >= 1024 -> "${content.length / 1024} KB"
                else -> "${content.length} B"
            }
            text = "$lineCount lines  ·  $sizeStr  ·  UTF-8"
            textSize = 11f
            setTextColor(clrInfo)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val branchBadge = TextView(activity).apply {
            text = "  $branch  "
            textSize = 9.5f
            setTextColor(0xFF2ECC71.toInt())
            typeface = android.graphics.Typeface.MONOSPACE
        }
        infoBar.addView(extBadge); infoBar.addView(infoTv); infoBar.addView(branchBadge)

        // ── Line numbers ─────────────────────────────────────────────────
        val lineNumberStr = (1..lineCount).joinToString("\n")
        val lineNumTv = TextView(activity).apply {
            text = lineNumberStr
            textSize = 11.5f
            setTextColor(clrGutter)
            typeface = android.graphics.Typeface.MONOSPACE
            setBackgroundColor(bgGutter)
            setPadding((10*dp).toInt(), (14*dp).toInt(), (10*dp).toInt(), (14*dp).toInt())
            gravity = android.view.Gravity.TOP or android.view.Gravity.END
            setLineSpacing(0f, 1.35f)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.MATCH_PARENT
            )
        }

        // ── Code EditText ─────────────────────────────────────────────────
        val etContent = EditText(activity).apply {
            setText(content)
            inputType = if (isBinary) android.text.InputType.TYPE_CLASS_TEXT
                        else android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
            isEnabled = !isBinary
            typeface = android.graphics.Typeface.MONOSPACE
            textSize = 11.5f
            setTextColor(clrCode)
            setHintTextColor(clrGutter)
            setBackgroundColor(bgEditor)
            setPadding((14*dp).toInt(), (14*dp).toInt(), (24*dp).toInt(), (14*dp).toInt())
            gravity = android.view.Gravity.TOP or android.view.Gravity.START
            minLines = 5
            setLineSpacing(0f, 1.35f)
            isSingleLine = false
            maxLines = Integer.MAX_VALUE
            // Make wide enough for horizontal scroll to be useful
            minWidth = (screenW * 2.5f).toInt()
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            // Sync line numbers on edit — but only actually rebuild the gutter (an
            // O(file size) pass over the whole document) when the edit could have
            // changed the line count. Typing/deleting an ordinary character never
            // does; only a newline being inserted or removed can. Without this
            // guard, every single keystroke in a large file re-split the entire
            // document and rebuilt the whole "1\n2\n3\n…\nN" gutter string —
            // visible typing lag on any file with more than a few hundred lines.
            var oldChunkHasNewline = false
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                    oldChunkHasNewline = s?.subSequence(start, start + count)?.contains('\n') == true
                }
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    val newChunkHasNewline = s?.subSequence(start, start + count)?.contains('\n') == true
                    if (oldChunkHasNewline || newChunkHasNewline) {
                        val n = (s?.toString() ?: "").lines().size
                        lineNumTv.text = (1..n).joinToString("\n")
                    }
                }
                override fun afterTextChanged(s: android.text.Editable?) {}
            })

            // One-time pass, not on every keystroke — see applySyntaxHighlighting's
            // kdoc. Size-guarded: a huge file (rare, but possible) would make even
            // a one-time regex pass over the whole document noticeably slow, and
            // this is a cosmetic feature not worth that cost.
            if (!isBinary && content.length < 200_000) {
                applySyntaxHighlighting(this.text)
            }
        }

        // Horizontal scroll wraps the code EditText only
        val hScroll = HorizontalScrollView(activity).apply {
            setBackgroundColor(bgEditor)
            isHorizontalScrollBarEnabled = true
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            addView(etContent)
        }

        // Side-by-side: gutter + hScroll
        val editorRow = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(bgEditor)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }
        editorRow.addView(lineNumTv)
        editorRow.addView(hScroll)

        // Outer vertical scroll for the code area
        val nsv = androidx.core.widget.NestedScrollView(activity).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                (screenH * 0.54f).toInt()
            )
            isFillViewport = true
            setBackgroundColor(bgEditor)
            addView(editorRow)
        }

        // ── Status bar ────────────────────────────────────────────────────
        val statusBar = TextView(activity).apply {
            text = if (isBinary) "Binary file — read only" else "Tap to edit  ·  Save commits to $branch"
            textSize = 10.5f
            setTextColor(clrGutter)
            typeface = android.graphics.Typeface.MONOSPACE
            setBackgroundColor(bgStatus)
            setPadding((12*dp).toInt(), (6*dp).toInt(), (12*dp).toInt(), (6*dp).toInt())
        }

        // ── Search bar: find in file, next/prev match, go to line ──────────
        val searchMatches = mutableListOf<Int>()
        var currentMatch = -1
        var searchSpans: List<Any> = emptyList()

        fun clearSearchHighlights() {
            val editable = etContent.text
            for (span in searchSpans) editable.removeSpan(span)
            searchSpans = emptyList()
        }

        fun scrollToOffset(offset: Int) {
            val layout = etContent.layout ?: return
            val line = layout.getLineForOffset(offset)
            val y = layout.getLineTop(line)
            nsv.post { nsv.scrollTo(0, y) }
        }

        val tvMatchCount = TextView(activity).apply {
            text = ""; textSize = 10.5f; setTextColor(clrInfo)
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding((8*dp).toInt(), 0, (8*dp).toInt(), 0)
        }

        fun runSearch(query: String) {
            clearSearchHighlights()
            searchMatches.clear()
            currentMatch = -1
            if (query.isEmpty()) { tvMatchCount.text = ""; return }
            val text = etContent.text.toString()
            var idx = text.indexOf(query, 0, ignoreCase = true)
            while (idx >= 0) {
                searchMatches.add(idx)
                idx = text.indexOf(query, idx + 1, ignoreCase = true)
            }
            if (searchMatches.isEmpty()) { tvMatchCount.text = "0/0"; return }
            val editable = etContent.text
            searchSpans = searchMatches.map { pos ->
                android.text.style.BackgroundColorSpan(0xFF5A4E1F.toInt()).also { span ->
                    editable.setSpan(span, pos, pos + query.length, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
            }
            currentMatch = 0
            tvMatchCount.text = "1/${searchMatches.size}"
            scrollToOffset(searchMatches[0])
        }

        val etSearch = EditText(activity).apply {
            hint = "Find in file…"; textSize = 11f; isSingleLine = true
            setTextColor(clrCode); setHintTextColor(clrGutter)
            setBackgroundColor(bgGutter)
            setPadding((10*dp).toInt(), (6*dp).toInt(), (10*dp).toInt(), (6*dp).toInt())
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: android.text.Editable?) { runSearch(s?.toString() ?: "") }
            })
        }
        val btnPrevMatch = activity.iconButton(R.drawable.ic_chevron_left, clrInfo, sizeDp = 16, paddingDp = 6) {
            if (searchMatches.isEmpty()) return@iconButton
            currentMatch = (currentMatch - 1 + searchMatches.size) % searchMatches.size
            tvMatchCount.text = "${currentMatch + 1}/${searchMatches.size}"
            scrollToOffset(searchMatches[currentMatch])
        }
        val btnNextMatch = activity.iconButton(R.drawable.ic_chevron_right, clrInfo, sizeDp = 16, paddingDp = 6) {
            if (searchMatches.isEmpty()) return@iconButton
            currentMatch = (currentMatch + 1) % searchMatches.size
            tvMatchCount.text = "${currentMatch + 1}/${searchMatches.size}"
            scrollToOffset(searchMatches[currentMatch])
        }
        val btnGoToLine = activity.iconButton(R.drawable.ic_hash, clrInfo, sizeDp = 16, paddingDp = 6) {
            val input = EditText(activity).apply {
                hint = "Line 1–$lineCount"
                inputType = android.text.InputType.TYPE_CLASS_NUMBER
            }
            lateinit var goDlg: AlertDialog
            val goContent = activity.dialogWithActions(
                input,
                DialogAction("Go", ButtonTone.TEAL, R.drawable.ic_hash) {
                    val n = input.text.toString().toIntOrNull()
                    if (n != null && n in 1..lineCount) {
                        goDlg.dismiss()
                        etContent.layout?.let { nsv.post { nsv.scrollTo(0, it.getLineTop(n - 1)) } }
                    } else {
                        activity.appendLog("⚠ Line must be between 1 and $lineCount.")
                    }
                },
                DialogAction("Cancel", ButtonTone.SURFACE, R.drawable.ic_close) { goDlg.dismiss() }
            )
            goDlg = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
                .setTitle("Go to Line")
                .setView(goContent)
                .show()
        }
        val searchBar = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setBackgroundColor(bgGutter)
            setPadding((8*dp).toInt(), (4*dp).toInt(), (4*dp).toInt(), (4*dp).toInt())
            addView(etSearch); addView(tvMatchCount)
            addView(btnPrevMatch); addView(btnNextMatch); addView(btnGoToLine)
        }

        // ── Container ─────────────────────────────────────────────────────
        val editorRoot = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bgEditor)
        }
        editorRoot.addView(infoBar)
        // Thin separator
        editorRoot.addView(android.view.View(activity).apply {
            setBackgroundColor(0xFF232747.toInt())
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1)
        })
        if (!isBinary) editorRoot.addView(searchBar)
        editorRoot.addView(nsv)
        editorRoot.addView(statusBar)

        lateinit var editorDlg: AlertDialog
        val editorContent = activity.dialogWithActions(
            editorRoot,
            DialogAction(if (isBinary) "Close" else "Save", ButtonTone.TEAL, if (isBinary) R.drawable.ic_close else R.drawable.ic_save) {
                editorDlg.dismiss()
                if (!isBinary) {
                    val newText = etContent.text.toString()
                    activity.setBusy(true)
                    activity.bgExecutor.execute { saveFileContent(token, owner, repo, branch, item, newText, currentPath) }
                }
            },
            DialogAction("Copy", ButtonTone.BLUE, R.drawable.ic_copy) {
                editorDlg.dismiss()
                val cm = activity.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText(item.name, etContent.text.toString()))
                activity.appendLog("📋 Copied ${item.name} to clipboard.")
            },
            DialogAction("Cancel", ButtonTone.SURFACE, R.drawable.ic_close) { editorDlg.dismiss() }
        )
        editorDlg = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
            .setTitle("📄  ${item.name}")
            .setView(editorContent)
            .show()
    }

    /** Encodes and PUTs the new file content to GitHub. */
    private fun saveFileContent(
        token: String, owner: String, repo: String, branch: String,
        item: RepoItem, newContent: String, refreshPath: String
    ) {
        try {
            val encoded = android.util.Base64.encodeToString(
                newContent.toByteArray(Charsets.UTF_8), android.util.Base64.NO_WRAP
            )
            val payload = org.json.JSONObject().apply {
                put("message", "edit: update ${item.path} via ZipApkBuilder [skip ci]")
                put("content", encoded)
                put("sha",     item.sha)
                put("branch",  branch)
            }.toString()
            val (code, body) = GitHubApi.httpPut(token, GitHubApi.apiContents(owner, repo, item.path), payload)
            if (code in 200..201) {
                activity.appendLog("✓ Saved: ${item.path}")
                activity.mainHandler.post { refreshBrowser(token, owner, repo, branch, refreshPath) }
            } else {
                activity.appendLog("✗ Save failed ($code): ${body.take(150)}")
                activity.mainHandler.post { activity.setBusy(false) }
            }
        } catch (e: Exception) {
            activity.appendLog("✗ ${e.message}")
            activity.mainHandler.post { activity.setBusy(false) }
        }
    }

    /** Fetches a file's content from GitHub and copies it to the clipboard. */
    fun fetchAndCopyFile(token: String, owner: String, repo: String, item: RepoItem) {
        activity.setBusy(true)
        activity.appendLog("Fetching ${item.name} for copy …")
        activity.bgExecutor.execute {
            try {
                val bytes: ByteArray = if (item.size >= GitHubApi.CONTENTS_API_SIZE_LIMIT) {
                    // Same >=1MB Contents-API gap as fetchAndViewFile — see its comment.
                    GitHubApi.fetchBlobBytes(token, owner, repo, item.sha)
                        ?: throw Exception("Could not fetch ${item.path} (${Formatters.fmtBytes(item.size)}) from blob storage")
                } else {
                    val (code, body) = GitHubApi.httpGet(token, GitHubApi.apiContents(owner, repo, item.path))
                    if (code != 200) throw Exception("HTTP $code")
                    val raw = org.json.JSONObject(body).optString("content", "")
                        .replace("\n", "").replace("\r", "")
                    android.util.Base64.decode(raw, android.util.Base64.DEFAULT)
                }
                val text  = String(bytes, Charsets.UTF_8)
                activity.mainHandler.post {
                    activity.setBusy(false)
                    val cm = activity.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    cm.setPrimaryClip(android.content.ClipData.newPlainText(item.name, text))
                    activity.appendLog("📋 Copied ${item.name} to clipboard (${text.length} chars).")
                }
            } catch (e: Exception) {
                activity.appendLog("✗ ${e.message}")
                activity.mainHandler.post { activity.setBusy(false) }
            }
        }
    }
}
