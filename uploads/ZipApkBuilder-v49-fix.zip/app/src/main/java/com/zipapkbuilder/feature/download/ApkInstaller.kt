package com.zipapkbuilder.feature.download

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import com.zipapkbuilder.MainActivity
import java.io.File

/**
 * Closes the loop the app's own `REQUEST_INSTALL_PACKAGES` permission and
 * `FileProvider` config already anticipated but nothing previously drove:
 * hands an already-extracted APK straight to the system Package Installer
 * right after a successful artifact download, instead of leaving "saved to
 * Downloads" as the last step. Split out of [DownloadIntegrity] (which owns
 * *verifying* a download, not acting on it) so this class's one job stays
 * "offer this APK for install."
 *
 * The special "install unknown apps" permission this needs isn't a normal
 * runtime permission — [android.content.pm.PackageManager.canRequestPackageInstalls]
 * is granted per-app from one specific Settings screen, not through the
 * `ActivityResultContracts.RequestPermission` launcher
 * [MainActivity.withStoragePermission]/[MainActivity.withNotificationPermission]
 * use — so this checks and redirects to that screen directly instead of
 * trying to force it through the same runtime-permission machinery.
 */
class ApkInstaller(private val activity: MainActivity) {

    /**
     * Requests install of [apkFile] via [Intent.ACTION_VIEW] at a FileProvider
     * URI — the system's own Package Installer still shows its own
     * confirmation UI before anything is actually installed; this only opens
     * that screen, it never silently replaces anything. On API 26+, if the
     * app doesn't yet hold the install-packages permission for itself, this
     * instead sends the user to the one Settings screen that grants it
     * ([Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES]) and logs a hint to try
     * again afterward, the same "ask once, explain if not granted" shape
     * [MainActivity.withStoragePermission] uses for its own permission.
     *
     * Safe to call from any thread — [apkFile] normally arrives straight
     * from a download's `onSuccess` callback, which runs on a background
     * download-worker thread (see [com.zipapkbuilder.model.DownloadTask]'s
     * kdoc), so the actual `startActivity` call is always posted to the main
     * thread internally rather than requiring every caller to remember to.
     */
    fun requestInstall(apkFile: File) {
        activity.mainHandler.post {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
                !activity.packageManager.canRequestPackageInstalls()
            ) {
                activity.appendLog("ℹ To install directly from the app, allow \"Install unknown apps\" for ZipApkBuilder — opening Settings…")
                try {
                    activity.startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                            Uri.parse("package:${activity.packageName}")
                        )
                    )
                } catch (e: Exception) {
                    activity.appendLog("✗ Could not open install-permission settings: ${e.message}")
                }
                return@post
            }
            try {
                val uri = FileProvider.getUriForFile(activity, "${activity.packageName}.provider", apkFile)
                activity.appendLog("📲 Opening installer…")
                activity.startActivity(
                    Intent(Intent.ACTION_VIEW).apply {
                        setDataAndType(uri, "application/vnd.android.package-archive")
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                )
            } catch (e: Exception) {
                activity.appendLog("✗ Could not launch installer: ${e.message}")
            }
        }
    }
}
