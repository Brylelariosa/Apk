package com.zipapkbuilder.feature.download

import android.content.ContentValues
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.zipapkbuilder.MainActivity
import com.zipapkbuilder.core.JsonPrefsList
import com.zipapkbuilder.core.PrefKeys
import com.zipapkbuilder.core.UriUtils
import org.json.JSONObject
import java.io.File

/**
 * Finalizes a completed download: saves the ZIP into the public Downloads
 * folder (or a user-picked custom folder, via [PrefKeys.PREF_DOWNLOAD_URI])
 * and records it in persisted history. Split out of [DownloadManager] as the
 * "what happens to a file once its transfer is done" concern — [saveZipToDownloads]
 * is the single entry point [DownloadManager]'s two `onSuccess` callbacks
 * call, saving and recording together since a saved download with no history
 * entry (or vice versa) would be an inconsistent, half-done result.
 */
class DownloadHistory(private val activity: MainActivity) {

    private fun addDownloadToHistory(name: String, path: String, sizeBytes: Long) {
        val entry = JSONObject().apply {
            put("name", name)
            put("path", path)
            put("size", sizeBytes)
            put("time", System.currentTimeMillis())
        }
        JsonPrefsList.prepend(activity.prefs, PrefKeys.PREF_DOWNLOAD_HISTORY, entry, cap = 30)
    }

    fun loadDownloadHistory(): List<JSONObject> =
        JsonPrefsList.loadList(activity.prefs, PrefKeys.PREF_DOWNLOAD_HISTORY)

    /** Saves [zipFile] to Downloads as [fileName] and records it in history;
     *  returns the saved path. The single entry point download success handlers call. */
    fun saveZipToDownloads(zipFile: File, fileName: String): String {
        val savedPath = saveZipToDownloadsInternal(zipFile, fileName)
        addDownloadToHistory(fileName, savedPath, zipFile.length())
        return savedPath
    }

    /**
     * Saves [zipFile] to the public Downloads directory as [fileName] (a .zip).
     *
     * Android 10+ (API 29+): MediaStore API — no storage permission required.
     * Android 7–9  (API 24–28): direct file write (needs WRITE_EXTERNAL_STORAGE).
     *
     * Returns the absolute path of the saved file.
     */
    private fun saveZipToDownloadsInternal(zipFile: File, fileName: String): String {
        // Use custom folder if the user picked one
        val customUriStr = activity.prefs.getString(PrefKeys.PREF_DOWNLOAD_URI, null)
        if (!customUriStr.isNullOrEmpty()) {
            val treeUri = Uri.parse(customUriStr)
            try {
                val docUri = androidx.documentfile.provider.DocumentFile
                    .fromTreeUri(activity, treeUri)
                    ?.createFile("application/zip", fileName)
                    ?.uri
                    ?: throw Exception("Cannot create file in selected folder")
                UriUtils.openOutputStreamOrThrow(activity.contentResolver, docUri).use { out ->
                    zipFile.inputStream().use { it.copyTo(out) }
                }
                return docUri.toString()
            } catch (e: SecurityException) {
                // The saved folder permission (a persisted URI grant) can be revoked out
                // from under us — a device storage cleanup, the user manually revoking it
                // in Settings, or the folder itself being deleted — surface that plainly
                // rather than a bare SecurityException, since "clear it in Settings" is a
                // concrete, actionable next step the generic message wouldn't suggest.
                throw Exception("Selected download folder is no longer accessible — clear it in Settings and try again.", e)
            }
        }

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // Android 10+ — MediaStore.Downloads (no permission needed)
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                put(MediaStore.Downloads.MIME_TYPE, "application/zip")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val collection = MediaStore.Downloads
                .getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val itemUri = activity.contentResolver.insert(collection, values)
                ?: throw Exception("MediaStore insert failed.")

            UriUtils.openOutputStreamOrThrow(activity.contentResolver, itemUri).use { out ->
                zipFile.inputStream().use { it.copyTo(out) }
            }

            // Clear IS_PENDING so it appears in Downloads app right away
            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            activity.contentResolver.update(itemUri, values, null, null)

            // On a filename collision (e.g. downloading the same artifact twice),
            // MediaStore silently renames to "name (1).zip" rather than overwriting —
            // query back the name it actually used instead of assuming our request
            // was honoured verbatim, so the path we report/log/save to history is real.
            val actualName = activity.contentResolver.query(
                itemUri, arrayOf(MediaStore.Downloads.DISPLAY_NAME), null, null, null
            )?.use { c -> if (c.moveToFirst()) c.getString(0) else null } ?: fileName

            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                .absolutePath + "/$actualName"

        } else {
            // Android 7–9 — direct file write (needs WRITE_EXTERNAL_STORAGE)
            val dir  = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            dir.mkdirs()
            val dest = File(dir, fileName)
            zipFile.copyTo(dest, overwrite = true)
            dest.absolutePath
        }
    }
}
