package com.zipapkbuilder.feature.settings

import android.app.AlertDialog
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.zipapkbuilder.MainActivity
import com.zipapkbuilder.R
import com.zipapkbuilder.core.ButtonTone
import com.zipapkbuilder.core.Formatters
import com.zipapkbuilder.core.PrefKeys
import com.zipapkbuilder.core.TokenCrypto
import com.zipapkbuilder.core.styleButton

/**
 * The Settings dialog: a second, larger set of fields mirroring the main
 * screen's token/repo/branch/keystore inputs (handy for editing without the
 * compact main layout), plus download/build history and shortcuts into
 * [com.zipapkbuilder.feature.repo.RepoSwitcher] and
 * [com.zipapkbuilder.feature.keystore.KeystoreController].
 */
class SettingsDialogController(private val activity: MainActivity) {

    private val Int.dp get() = (this * activity.resources.displayMetrics.density).toInt()

    fun showSettingsDialog() {
        val view = activity.layoutInflater.inflate(R.layout.dialog_settings, null)

        // Grab settings dialog views
        val sEtToken        = view.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.sEtToken)
        val sEtRepo         = view.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.sEtRepo)
        val sEtBranch       = view.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.sEtBranch)
        val sEtKeystorePass = view.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.sEtKeystorePass)
        val sEtKeyAlias     = view.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.sEtKeyAlias)
        val sTvOwnerInfo    = view.findViewById<TextView>(R.id.sTvOwnerInfo)
        val sTvKeystoreStatus = view.findViewById<TextView>(R.id.sTvKeystoreStatus)
        val sBtnSwitchRepo  = view.findViewById<Button>(R.id.sBtnSwitchRepo)
        val sSwitchUploadRoot = view.findViewById<android.widget.Switch>(R.id.sSwitchUploadRoot)
        val sBtnGenerate    = view.findViewById<Button>(R.id.sBtnGenerateKeystore)
        val sBtnClose       = view.findViewById<android.widget.ImageButton>(R.id.btnCloseSettings)
        val sBtnSave        = view.findViewById<Button>(R.id.sBtnSave)
        val tvDownloadPath    = view.findViewById<TextView>(R.id.tvDownloadPath)
        val sBtnPickFolder    = view.findViewById<Button>(R.id.sBtnPickFolder)
        val sBtnClearFolder   = view.findViewById<Button>(R.id.sBtnClearFolder)
        val sBtnClearHistory  = view.findViewById<Button>(R.id.sBtnClearHistory)
        val layoutDlHistory   = view.findViewById<LinearLayout>(R.id.layoutDownloadHistory)
        val sBtnClearBuildHistory = view.findViewById<Button>(R.id.sBtnClearBuildHistory)
        val layoutBuildHistory    = view.findViewById<LinearLayout>(R.id.layoutBuildHistory)
        val tvBuildStats          = view.findViewById<TextView>(R.id.tvBuildStats)

        // Show current download path
        fun refreshDownloadPath() {
            val uri = activity.prefs.getString(PrefKeys.PREF_DOWNLOAD_URI, null)
            tvDownloadPath.text = if (uri != null) {
                Uri.parse(uri).lastPathSegment ?: uri
            } else {
                "Default (Downloads)"
            }
        }
        refreshDownloadPath()

        // Populate download history
        fun refreshHistory() {
            layoutDlHistory.removeAllViews()
            val entries = activity.downloadManager.loadDownloadHistory()
            if (entries.isEmpty()) {
                val empty = TextView(activity).apply {
                    text = "No downloads yet"
                    textSize = 12f
                    setTextColor(activity.getColor(R.color.text_tertiary))
                    setPadding(4.dp, 6.dp, 4.dp, 6.dp)
                }
                layoutDlHistory.addView(empty)
            } else {
                entries.forEach { entry ->
                    val name = entry.optString("name", "unknown")
                    val path = entry.optString("path", "")
                    val size = entry.optLong("size", 0L)
                    val time = entry.optLong("time", 0L)
                    val timeStr = Formatters.fmtLocalTime(time)
                    val sizeStr = Formatters.fmtBytes(size)

                    val row = LinearLayout(activity).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                        setPadding(0, 5.dp, 0, 5.dp)
                    }

                    val icon = TextView(activity).apply {
                        text = "📥"
                        textSize = 14f
                        setPadding(0, 0, 8.dp, 0)
                    }

                    val info = LinearLayout(activity).apply {
                        orientation = LinearLayout.VERTICAL
                        layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                    }
                    val tvName = TextView(activity).apply {
                        text = name
                        textSize = 12f
                        typeface = android.graphics.Typeface.MONOSPACE
                        setTextColor(activity.getColor(R.color.text_primary))
                        isSingleLine = true
                        ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
                    }
                    val tvMeta = TextView(activity).apply {
                        text = "$sizeStr  ·  $timeStr"
                        textSize = 10f
                        setTextColor(activity.getColor(R.color.text_tertiary))
                    }
                    info.addView(tvName)
                    info.addView(tvMeta)

                    // Long-press copies path
                    row.setOnLongClickListener {
                        val clip = android.content.ClipData.newPlainText("path", path)
                        (activity.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(clip)
                        android.widget.Toast.makeText(activity, "Path copied", android.widget.Toast.LENGTH_SHORT).show()
                        true
                    }

                    row.addView(icon)
                    row.addView(info)
                    layoutDlHistory.addView(row)

                    // Divider
                    val div = View(activity).apply {
                        layoutParams = LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT, 1
                        ).also { it.setMargins(0, 2.dp, 0, 2.dp) }
                        setBackgroundColor(activity.getColor(R.color.divider))
                    }
                    layoutDlHistory.addView(div)
                }
            }
        }
        refreshHistory()

        // Populate build history — outcome icon, repo/branch, duration, and a
        // one-line stats summary computed straight from what's stored locally
        // (no network call needed, unlike the live Build Log run browser).
        fun refreshBuildHistory() {
            layoutBuildHistory.removeAllViews()
            val entries = activity.buildFlowController.loadBuildHistory()
            if (entries.isEmpty()) {
                tvBuildStats.text = "No builds recorded yet"
                val empty = TextView(activity).apply {
                    text = "No builds yet"
                    textSize = 12f
                    setTextColor(activity.getColor(R.color.text_tertiary))
                    setPadding(4.dp, 6.dp, 4.dp, 6.dp)
                }
                layoutBuildHistory.addView(empty)
            } else {
                val successEntries = entries.filter { it.optString("outcome") == "success" }
                val pct = (successEntries.size * 100) / entries.size
                val avgMs = if (successEntries.isNotEmpty())
                    successEntries.sumOf { it.optLong("durationMs", 0L) } / successEntries.size else 0L
                tvBuildStats.text = "${entries.size} build(s) · $pct% success" +
                    if (successEntries.isNotEmpty()) " · avg ${Formatters.fmtDuration(avgMs)}" else ""

                entries.forEach { entry ->
                    val repo       = entry.optString("repo", "?")
                    val branch     = entry.optString("branch", "")
                    val outcome    = entry.optString("outcome", "failed")
                    val durationMs = entry.optLong("durationMs", 0L)
                    val time       = entry.optLong("time", 0L)
                    val timeStr = Formatters.fmtLocalTime(time)
                    val icon = when (outcome) { "success" -> "✓"; "cancelled" -> "⊘"; else -> "✗" }
                    val iconColorRes = when (outcome) {
                        "success" -> R.color.text_success
                        "cancelled" -> R.color.text_tertiary
                        else -> R.color.text_error
                    }

                    val row = LinearLayout(activity).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                        setPadding(0, 5.dp, 0, 5.dp)
                    }
                    val iconTv = TextView(activity).apply {
                        text = icon
                        textSize = 14f
                        setTextColor(activity.getColor(iconColorRes))
                        setPadding(0, 0, 8.dp, 0)
                    }
                    val info = LinearLayout(activity).apply {
                        orientation = LinearLayout.VERTICAL
                        layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                    }
                    val tvName = TextView(activity).apply {
                        text = if (branch.isNotEmpty()) "$repo  ($branch)" else repo
                        textSize = 12f
                        setTextColor(activity.getColor(R.color.text_primary))
                        isSingleLine = true
                        ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
                    }
                    val tvMeta = TextView(activity).apply {
                        text = "${Formatters.fmtDuration(durationMs)}  ·  $timeStr"
                        textSize = 10f
                        setTextColor(activity.getColor(R.color.text_tertiary))
                    }
                    info.addView(tvName)
                    info.addView(tvMeta)
                    row.addView(iconTv)
                    row.addView(info)
                    layoutBuildHistory.addView(row)

                    val div = View(activity).apply {
                        layoutParams = LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT, 1
                        ).also { it.setMargins(0, 2.dp, 0, 2.dp) }
                        setBackgroundColor(activity.getColor(R.color.divider))
                    }
                    layoutBuildHistory.addView(div)
                }
            }
        }
        refreshBuildHistory()

        // Pre-populate from main activity fields
        sEtToken.setText(activity.etToken.text)
        sEtRepo.setText(activity.etRepo.text)
        sEtBranch.setText(activity.etBranch.text)
        sEtKeystorePass.setText(activity.etKeystorePass.text)
        sEtKeyAlias.setText(activity.etKeyAlias.text)
        val uploadToRootWasOn = activity.prefs.getBoolean(PrefKeys.PREF_UPLOAD_TO_ROOT, false)
        sSwitchUploadRoot.isChecked = uploadToRootWasOn

        // Mirror owner chip if visible
        if (activity.tvOwnerInfo.visibility == View.VISIBLE && activity.tvOwnerInfo.text.isNotEmpty()) {
            sTvOwnerInfo.text = activity.tvOwnerInfo.text
            sTvOwnerInfo.visibility = View.VISIBLE
        }
        // Mirror keystore status if visible
        if (activity.tvKeystoreStatus.visibility == View.VISIBLE && activity.tvKeystoreStatus.text.isNotEmpty()) {
            sTvKeystoreStatus.text = activity.tvKeystoreStatus.text
            sTvKeystoreStatus.visibility = View.VISIBLE
        }

        val dialog = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
            .setView(view)
            .setCancelable(true)
            .create()
        dialog.window?.setBackgroundDrawable(
            ColorDrawable(android.graphics.Color.TRANSPARENT)
        )

        fun saveAndClose() {
            // Write back to main activity fields
            activity.etToken.setText(sEtToken.text)
            activity.etRepo.setText(sEtRepo.text)
            activity.etBranch.setText(sEtBranch.text)
            activity.etKeystorePass.setText(sEtKeystorePass.text)
            activity.etKeyAlias.setText(sEtKeyAlias.text)
            // Persist to prefs
            activity.securePrefs.edit()
                .putString(PrefKeys.PREF_TOKEN, TokenCrypto.encrypt(sEtToken.text.toString().trim()))
                .apply()
            activity.prefs.edit()
                .putString(PrefKeys.PREF_REPO,   sEtRepo.text.toString().trim())
                .putString(PrefKeys.PREF_BRANCH, sEtBranch.text.toString().trim().ifEmpty { "main" })
                .putBoolean(PrefKeys.PREF_UPLOAD_TO_ROOT, sSwitchUploadRoot.isChecked)
                .apply()
            // Only note this the moment it's actually switched on, not every save while it
            // happens to already be on — the caveat is worth surfacing once, not repeating.
            if (sSwitchUploadRoot.isChecked && !uploadToRootWasOn) {
                activity.appendLog(
                    "ℹ Upload destination set to repo root. A brand-new repo's workflow " +
                        "already watches for this; an existing repo's committed build.yml may " +
                        "still only watch uploads/ — if a root upload doesn't trigger a build, " +
                        "delete and let the app recommit build.yml, or update its trigger paths yourself."
                )
            }
            dialog.dismiss()
        }

        // Back-press and tap-outside both go through this (setCancelable(true) above),
        // which otherwise defaults to a bare dismiss — the same silent-discard gap the
        // X button had. Routing it through saveAndClose() closes that gap too, so every
        // way of leaving this dialog behaves the same, consistent way.
        dialog.setOnCancelListener { saveAndClose() }

        sBtnSave.setOnClickListener     { saveAndClose() }
        // X used to just dismiss() — silently discarding any edits made in this
        // session, since only "Save & Close" (a sticky bar the user has to scroll
        // to see) actually persisted them. That's a real correctness trap: edit the
        // branch/repo/token, close with the far more prominent top-right X, and every
        // subsequent action (including triggering a workflow) would keep using the
        // OLD values with no indication anything was lost. X now saves too, exactly
        // like the "Switch Repository" button below already does.
        sBtnClose.setOnClickListener     { saveAndClose() }
        sBtnSwitchRepo.setOnClickListener {
            saveAndClose()
            activity.repoSwitcher.showSavedReposDialog()
        }
        sBtnGenerate.setOnClickListener {
            // Copy pass/alias back first so generateKeystore() reads correct values
            activity.etKeystorePass.setText(sEtKeystorePass.text)
            activity.etKeyAlias.setText(sEtKeyAlias.text)
            dialog.dismiss()
            activity.keystoreController.generateKeystore()
        }

        sBtnPickFolder.setOnClickListener {
            activity.onFolderPicked = { refreshDownloadPath() }
            activity.pickFolderLauncher.launch(null)
        }

        sBtnClearFolder.setOnClickListener {
            activity.prefs.edit().remove(PrefKeys.PREF_DOWNLOAD_URI).apply()
            refreshDownloadPath()
        }

        sBtnClearHistory.setOnClickListener {
            val count = activity.downloadManager.loadDownloadHistory().size
            if (count == 0) { refreshHistory(); return@setOnClickListener }
            val clearDlg = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
                .setTitle("Clear Download History?")
                .setMessage("This will permanently remove all $count download history ${if (count == 1) "entry" else "entries"}. " +
                    "The downloaded files themselves aren't touched — only this list.\n\nThis can't be undone.")
                .setPositiveButton("Clear") { _, _ ->
                    activity.prefs.edit().remove(PrefKeys.PREF_DOWNLOAD_HISTORY).apply()
                    refreshHistory()
                }
                .setNegativeButton("Cancel", null)
                .show()
            clearDlg.styleButton(activity, AlertDialog.BUTTON_POSITIVE, ButtonTone.RED, R.drawable.ic_delete)
            clearDlg.styleButton(activity, AlertDialog.BUTTON_NEGATIVE, ButtonTone.SURFACE, R.drawable.ic_close)
        }

        sBtnClearBuildHistory.setOnClickListener {
            val count = activity.buildFlowController.loadBuildHistory().size
            if (count == 0) { refreshBuildHistory(); return@setOnClickListener }
            val clearDlg = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
                .setTitle("Clear Build History?")
                .setMessage("This will permanently remove all $count build history ${if (count == 1) "entry" else "entries"} " +
                    "(the local success/fail/duration record — not anything on GitHub).\n\nThis can't be undone.")
                .setPositiveButton("Clear") { _, _ ->
                    activity.prefs.edit().remove(PrefKeys.PREF_BUILD_HISTORY).apply()
                    refreshBuildHistory()
                }
                .setNegativeButton("Cancel", null)
                .show()
            clearDlg.styleButton(activity, AlertDialog.BUTTON_POSITIVE, ButtonTone.RED, R.drawable.ic_delete)
            clearDlg.styleButton(activity, AlertDialog.BUTTON_NEGATIVE, ButtonTone.SURFACE, R.drawable.ic_close)
        }

        dialog.show()

        // Make dialog width match screen
        dialog.window?.setLayout(
            android.view.ViewGroup.LayoutParams.MATCH_PARENT,
            android.view.ViewGroup.LayoutParams.WRAP_CONTENT
        )
    }
}
