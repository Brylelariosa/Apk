package com.voxelsandbox.game.world.generation

import com.voxelsandbox.game.world.BlockType
import com.voxelsandbox.game.world.Chunk
import com.voxelsandbox.game.world.ChunkPos
import com.voxelsandbox.game.world.WorldConfig
import kotlin.math.ceil
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Deterministic seeded terrain generator: the same (seed, chunkX, chunkZ) always
 * produces the same chunk, which is what lets SaveManager store only player-modified
 * chunks and regenerate everything else from the seed on load.
 *
 * Trees are placed without any neighbour coordination and still cross chunk borders
 * cleanly: every chunk independently evaluates the (pure, position-hashed) tree
 * candidates in its own area *plus a margin*, and writes only the tree blocks that fall
 * inside itself. A canopy that straddles a border is therefore assembled from the same
 * deterministic tree by both chunks, with no cross-chunk writes and no races. The
 * terrain height itself is a pure function of (x, z), so a chunk can also ask "how high
 * is the ground under that neighbouring tree" without the neighbour existing.
 */
class TerrainGenerator(private val seed: Long) {
    private val continentNoise = NoiseGenerator(seed xor 0x9E3779B97F4A7C15UL.toLong())
    private val detailNoise = NoiseGenerator(seed xor 0x1000193L)
    private val oreNoise = NoiseGenerator(seed xor 0x123456789ABCDEFL)
    private val forestNoise = NoiseGenerator(seed xor 0x5DEECE66DL)
    private val climateNoise = NoiseGenerator(seed xor 0x2545F4914F6CDD1DL)

    private val seedMix: Int = seed.toInt() * 1274126177

    fun generate(pos: ChunkPos): Chunk {
        val chunk = Chunk(pos)
        val baseX = pos.x * WorldConfig.CHUNK_SIZE
        val baseZ = pos.z * WorldConfig.CHUNK_SIZE
        val size = WorldConfig.CHUNK_SIZE

        for (lx in 0 until size) {
            for (lz in 0 until size) {
                val wx = baseX + lx
                val wz = baseZ + lz
                fillColumn(chunk, lx, lz, wx, wz, columnHeight(wx, wz))
            }
        }
        placeTrees(chunk, baseX, baseZ)
        return chunk
    }

    /** Y of the topmost solid block at (wx, wz). Pure function of position; the
     *  distant-terrain builder samples it directly without generating any chunk. */
    fun surfaceHeight(wx: Int, wz: Int): Int = columnHeight(wx, wz)

    /** Forest-ness in 0..1 (0 = open plains, 1 = dense forest). Drives tree density and
     *  the darker green the distant terrain uses over forests. */
    fun forestFactor(wx: Int, wz: Int): Double {
        val f = forestNoise.fbm2D(wx * 0.011, wz * 0.011, 2, 0.5, 2.0)
        return ((f + 0.05) / 0.45).coerceIn(0.0, 1.0)
    }

    private fun columnHeight(wx: Int, wz: Int): Int {
        val continent = continentNoise.fbm2D(wx * 0.004, wz * 0.004, 3, 0.5, 2.0) // -1..1, broad regions
        val detail = detailNoise.fbm2D(wx * 0.02, wz * 0.02, 4, 0.5, 2.0) // -1..1, local shape
        val amplitude = 6.0 + (continent + 1.0) / 2.0 * 34.0 // plains(~6) .. mountains(~40)
        val height = WorldConfig.SEA_LEVEL + (detail * amplitude).roundToInt() + 4
        return height.coerceIn(1, WorldConfig.WORLD_HEIGHT - 1)
    }

    private fun fillColumn(chunk: Chunk, lx: Int, lz: Int, wx: Int, wz: Int, height: Int) {
        val isBeach = height in (WorldConfig.SEA_LEVEL - 1)..(WorldConfig.SEA_LEVEL + 2)
        for (y in 0 until WorldConfig.WORLD_HEIGHT) {
            val block = when {
                y > height -> if (y <= WorldConfig.SEA_LEVEL) BlockType.WATER else BlockType.AIR
                y == height -> if (isBeach) BlockType.SAND else BlockType.GRASS
                y == 0 -> BlockType.STONE
                y >= height - 3 -> if (isBeach) BlockType.SAND else BlockType.DIRT
                else -> if (isCoalOre(wx, y, wz)) BlockType.COAL_ORE else BlockType.STONE
            }
            if (block != BlockType.AIR) chunk.setBlock(lx, y, lz, block)
        }
    }

    private fun isCoalOre(wx: Int, y: Int, wz: Int): Boolean {
        if (y > WorldConfig.SEA_LEVEL - 2) return false
        val n = oreNoise.noise2D(wx * 0.35 + y * 0.7, wz * 0.35 - y * 0.4)
        return n > 0.72
    }

    // ---- Trees ----------------------------------------------------------------------------

    private fun placeTrees(chunk: Chunk, baseX: Int, baseZ: Int) {
        val size = WorldConfig.CHUNK_SIZE
        val minCellX = Math.floorDiv(baseX - TREE_REACH, CELL)
        val maxCellX = Math.floorDiv(baseX + size - 1 + TREE_REACH, CELL)
        val minCellZ = Math.floorDiv(baseZ - TREE_REACH, CELL)
        val maxCellZ = Math.floorDiv(baseZ + size - 1 + TREE_REACH, CELL)

        for (cz in minCellZ..maxCellZ) {
            for (cx in minCellX..maxCellX) {
                // Deterministic per-4x4 cell: at most one tree candidate at a hash-chosen spot.
                val th = hash(cx, cz, seed)
                val wx = cx * CELL + ((th ushr 8) and 3)
                val wz = cz * CELL + ((th ushr 10) and 3)
                if (wx < baseX - TREE_REACH || wx >= baseX + size + TREE_REACH) continue
                if (wz < baseZ - TREE_REACH || wz >= baseZ + size + TREE_REACH) continue

                val forest = forestFactor(wx, wz)
                val chance = 0.02 + 0.30 * forest * forest // sparse in plains, thick in forests
                if ((th and 0xFF) >= (chance * 256.0).toInt()) continue

                val ground = columnHeight(wx, wz)
                if (ground <= WorldConfig.SEA_LEVEL + 2) continue // beaches / shallows stay bare
                growTree(chunk, baseX, baseZ, wx, wz, ground, th)
            }
        }
    }

    private fun growTree(chunk: Chunk, baseX: Int, baseZ: Int, wx: Int, wz: Int, ground: Int, th: Int) {
        val climate = climateNoise.fbm2D(wx * 0.007 + 31.7, wz * 0.007 - 17.3, 2, 0.5, 2.0)
        val roll = (th ushr 12) and 0xFF
        val species = when {
            ground >= WorldConfig.SEA_LEVEL + 20 -> SPRUCE // high ground is conifer country
            climate > 0.22 -> if (roll < 205) BIRCH else OAK
            climate < -0.25 -> if (roll < 218) SPRUCE else OAK
            else -> if (roll < 235) OAK else BIRCH
        }
        val wood = when (species) {
            BIRCH -> BlockType.BIRCH_WOOD
            SPRUCE -> BlockType.SPRUCE_WOOD
            else -> BlockType.WOOD
        }
        val leaf = when (species) {
            BIRCH -> BlockType.BIRCH_LEAVES
            SPRUCE -> BlockType.SPRUCE_LEAVES
            else -> BlockType.LEAVES
        }

        if (species != SPRUCE && ((th ushr 20) and 15) == 0) {
            // a low leafy bush: one log and a small rounded cluster of leaves
            put(chunk, baseX, baseZ, wx, ground + 1, wz, wood, true)
            blob(chunk, baseX, baseZ, wx, ground + 2, wz, leaf, 1.7, 1.3)
            return
        }

        when (species) {
            SPRUCE -> growSpruce(chunk, baseX, baseZ, wx, wz, ground, th, wood, leaf)
            BIRCH -> {
                val trunk = 6 + ((th ushr 4) % 3) // 6..8, tall and slim
                trunkAndBlob(chunk, baseX, baseZ, wx, wz, ground, trunk, wood, leaf, 2.0, 2.8)
            }
            else -> {
                val big = ((th ushr 24) and 7) == 0 // roughly one in eight is a broad old oak
                if (big) {
                    trunkAndBlob(chunk, baseX, baseZ, wx, wz, ground, 6 + ((th ushr 4) % 3), wood, leaf, 3.2, 2.7)
                } else {
                    trunkAndBlob(chunk, baseX, baseZ, wx, wz, ground, 5 + ((th ushr 4) % 3), wood, leaf, 2.5, 2.2)
                }
            }
        }
    }

    private fun trunkAndBlob(
        chunk: Chunk, baseX: Int, baseZ: Int, wx: Int, wz: Int, ground: Int,
        trunk: Int, wood: BlockType, leaf: BlockType, rH: Double, rV: Double
    ) {
        val topY = ground + trunk
        for (y in (ground + 1)..topY) put(chunk, baseX, baseZ, wx, y, wz, wood, true)
        blob(chunk, baseX, baseZ, wx, topY - 1, wz, leaf, rH, rV)
    }

    /** A rough ellipsoid of leaves around (cx, cy, cz). Each boundary block is nudged in or
     *  out by a position hash, which is what makes canopies look organic instead of
     *  like perfect spheres. */
    private fun blob(
        chunk: Chunk, baseX: Int, baseZ: Int, cx: Int, cy: Int, cz: Int,
        leaf: BlockType, rH: Double, rV: Double
    ) {
        val ex = ceil(rH).toInt()
        val ey = ceil(rV).toInt()
        for (dy in -ey..ey) {
            for (dx in -ex..ex) {
                for (dz in -ex..ex) {
                    val e = (dx * dx + dz * dz) / (rH * rH) + (dy * dy) / (rV * rV)
                    val jitter = ((hash3(cx + dx, cy + dy, cz + dz) ushr 6) and 15) / 15.0 * 0.5 - 0.15
                    if (e <= 1.0 + jitter) put(chunk, baseX, baseZ, cx + dx, cy + dy, cz + dz, leaf, false)
                }
            }
        }
    }

    private fun growSpruce(
        chunk: Chunk, baseX: Int, baseZ: Int, wx: Int, wz: Int, ground: Int, th: Int,
        wood: BlockType, leaf: BlockType
    ) {
        val trunk = 6 + ((th ushr 4) and 3) // 6..9
        val topY = ground + trunk
        for (y in (ground + 1)..topY) put(chunk, baseX, baseZ, wx, y, wz, wood, true)

        // Tiered cone: layer 0 is the single-block tip, radius grows toward the bottom.
        for (y in (ground + 3)..(topY + 1)) {
            val t = topY + 1 - y
            val r = SPRUCE_RADII[min(t, SPRUCE_RADII.size - 1)]
            if (r == 0) {
                put(chunk, baseX, baseZ, wx, y, wz, leaf, false)
                continue
            }
            val lim = r * r + r
            for (dx in -r..r) {
                for (dz in -r..r) {
                    val d2 = dx * dx + dz * dz
                    if (d2 > lim) continue
                    // thin out the outer rim a little so the cone isn't machine-perfect
                    if (d2 >= r * r && (hash3(wx + dx, y, wz + dz) and 3) == 0) continue
                    put(chunk, baseX, baseZ, wx + dx, y, wz + dz, leaf, false)
                }
            }
        }
    }

    /** Writes [block] at world (wx, y, wz) if that cell lies inside this chunk and is free.
     *  Logs may replace another tree's leaves; leaves only ever fill empty air. */
    private fun put(
        chunk: Chunk, baseX: Int, baseZ: Int, wx: Int, y: Int, wz: Int,
        block: BlockType, replaceFoliage: Boolean
    ) {
        if (y < 0 || y >= WorldConfig.WORLD_HEIGHT) return
        val lx = wx - baseX
        val lz = wz - baseZ
        if (lx < 0 || lx >= WorldConfig.CHUNK_SIZE || lz < 0 || lz >= WorldConfig.CHUNK_SIZE) return
        val existing = chunk.getBlock(lx, y, lz)
        if (existing == BlockType.AIR || (replaceFoliage && existing.cutout)) {
            chunk.setBlock(lx, y, lz, block)
        }
    }

    private fun hash3(x: Int, y: Int, z: Int): Int {
        var h = x * 374761393 + y * 668265263 + z * 1274126177 + seedMix
        h = (h xor (h ushr 13)) * -1028477387
        return h xor (h ushr 16)
    }

    companion object {
        private const val CELL = 4
        /** Widest a canopy ever reaches from its trunk, plus one block of slack. */
        private const val TREE_REACH = 4

        private const val OAK = 0
        private const val BIRCH = 1
        private const val SPRUCE = 2

        /** Cone radius by distance below the tip. */
        private val SPRUCE_RADII = intArrayOf(0, 1, 1, 2, 2, 3, 2, 3, 3, 3)

        private fun hash(x: Int, z: Int, seed: Long): Int {
            var h = x * 374761393 + z * 668265263 + seed.toInt() * 1274126177
            h = (h xor (h ushr 13)) * -1028477387
            return h xor (h ushr 16)
        }
    }
}
