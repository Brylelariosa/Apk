package com.voxelsandbox.game.gl

/**
 * Two programs share one vertex format (position + uv + shade):
 *
 *  - [VERTEX]/[FRAGMENT]: chunk terrain, particles, highlight and the cloud layer. The
 *    fragment stage alpha-tests (leaf textures have real transparent holes) and fades
 *    to the fog colour with distance.
 *  - [FAR_VERTEX]/[FAR_FRAGMENT]: the distant-terrain heightfield tiles. Identical
 *    shading, plus a circular clip around the player so the far mesh never draws on top
 *    of the full-detail chunks that already cover that area (no z-fighting, no wasted
 *    fill-rate), whatever the depth-buffer precision of the device happens to be.
 */
object Shaders {
    const val VERTEX = """#version 300 es
layout(location = 0) in vec3 aPosition;
layout(location = 1) in vec2 aTexCoord;
layout(location = 2) in float aShade;

uniform mat4 uViewProj;

out vec2 vTexCoord;
out float vShade;
out float vFogDist;

void main() {
    gl_Position = uViewProj * vec4(aPosition, 1.0);
    vTexCoord = aTexCoord;
    vShade = aShade;
    vFogDist = gl_Position.w;
}
"""

    const val FRAGMENT = """#version 300 es
precision mediump float;

in highp vec2 vTexCoord;
in float vShade;
in float vFogDist;

uniform sampler2D uTexture;
uniform vec3 uFogColor;
uniform float uFogStart;
uniform float uFogEnd;
uniform float uAlpha;

out vec4 fragColor;

void main() {
    vec4 texColor = texture(uTexture, vTexCoord);
    // Leaf tiles carry transparent holes; every other tile (and the white cloud cell)
    // has alpha 1.0, so this only ever discards actual foliage gaps.
    if (texColor.a < 0.5) discard;
    vec3 shaded = texColor.rgb * vShade;
    float fogFactor = clamp((vFogDist - uFogStart) / (uFogEnd - uFogStart), 0.0, 1.0);
    vec3 finalColor = mix(shaded, uFogColor, fogFactor);
    fragColor = vec4(finalColor, texColor.a * uAlpha);
}
"""

    const val FAR_VERTEX = """#version 300 es
layout(location = 0) in vec3 aPosition;
layout(location = 1) in vec2 aTexCoord;
layout(location = 2) in float aShade;

uniform mat4 uViewProj;

out vec2 vTexCoord;
out float vShade;
out float vFogDist;
out vec2 vWorldXZ;

void main() {
    gl_Position = uViewProj * vec4(aPosition, 1.0);
    vTexCoord = aTexCoord;
    vShade = aShade;
    vFogDist = gl_Position.w;
    vWorldXZ = aPosition.xz;
}
"""

    /** uClip: xy = centre of the clipped circle (world X/Z), z = its radius SQUARED.
     *  Fragments inside the circle belong to full-detail chunks and are dropped. */
    const val FAR_FRAGMENT = """#version 300 es
precision mediump float;

in highp vec2 vTexCoord;
in float vShade;
in float vFogDist;
in highp vec2 vWorldXZ;

uniform sampler2D uTexture;
uniform vec3 uFogColor;
uniform float uFogStart;
uniform float uFogEnd;
uniform highp vec3 uClip;

out vec4 fragColor;

void main() {
    highp vec2 d = vWorldXZ - uClip.xy;
    if (dot(d, d) < uClip.z) discard;
    vec4 texColor = texture(uTexture, vTexCoord);
    vec3 shaded = texColor.rgb * vShade;
    float fogFactor = clamp((vFogDist - uFogStart) / (uFogEnd - uFogStart), 0.0, 1.0);
    vec3 finalColor = mix(shaded, uFogColor, fogFactor);
    fragColor = vec4(finalColor, 1.0);
}
"""
}
