package com.voxelsandbox.game.gl

import android.opengl.GLES30
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.sin
import kotlin.math.sqrt

data class UVRect(val u0: Float, val v0: Float, val u1: Float, val v1: Float)

/**
 * Every block texture is generated procedurally at startup (16x16 pixel-art tiles built
 * from seeded hash noise) rather than shipped as an image asset, so the project stays
 * asset-free. The atlas is plain ARGB int arrays: no Bitmap/Canvas, which means it can be
 * built on any thread, needs no GL context, and keeps *straight* (non-premultiplied)
 * alpha. That matters for the leaf tiles, whose transparent holes would otherwise darken
 * the colour of their neighbours when mip-mapped.
 *
 * The mip chain is built by hand (alpha-weighted box filter) and capped at the level
 * where one tile is exactly one texel, so tiles can never bleed into each other however
 * far away a surface is. [uploadToGL] needs the GL context and is called from the
 * renderer on the GL thread.
 *
 * Image row 0 is the TOP of a tile and maps to the smallest v; the mesher relies on that
 * to put grass fringes / bark streaks the right way up on side faces.
 */
class TextureAtlas {
    companion object {
        const val GRID = 8
        const val CELL_PX = 16
        const val SIZE_PX = GRID * CELL_PX

        /** 128, 64, 32, 16, 8 px. At the last level one 16px tile is a single texel. */
        const val MIP_LEVELS = 5

        const val WATER_CELL = 9

        /** A plain white cell, reused (tinted via the shader's fog/shade/alpha
         *  uniforms) for clouds and the highlight so no extra texture is needed. */
        const val WHITE_CELL = 10

        /** 16 colour columns (sand -> grass -> dirt -> stone, plus water) that the
         *  distant-terrain mesh samples by U; see [rampU]. */
        const val RAMP_CELL = 15
        const val RAMP_WATER = 14f

        /** Keeps sampling just inside a tile so rounding at a tile edge can never pull
         *  in a texel from the neighbouring tile. */
        private const val UV_INSET = 0.15f / SIZE_PX

        private val EMPTY_UV = UVRect(0f, 0f, 0f, 0f)

        /** Every in-grid cell's rect, computed once: uvFor runs per emitted mesh face on
         *  the mesh-worker threads and per particle per frame, and a UVRect depends on
         *  nothing but the cell index. */
        private val UV_TABLE: Array<UVRect> = Array(GRID * GRID) { computeUv(it) }

        private fun computeUv(cell: Int): UVRect {
            val cx = cell % GRID
            val cy = cell / GRID
            val u0 = cx.toFloat() / GRID + UV_INSET
            val v0 = cy.toFloat() / GRID + UV_INSET
            val u1 = (cx + 1).toFloat() / GRID - UV_INSET
            val v1 = (cy + 1).toFloat() / GRID - UV_INSET
            return UVRect(u0, v0, u1, v1)
        }

        /** U coordinate at the centre of ramp column [t] (0..15, fractional allowed). */
        fun rampU(t: Float): Float {
            val c = if (t < 0f) 0f else if (t > 15f) 15f else t
            val cx = RAMP_CELL % GRID
            return cx.toFloat() / GRID + (c + 0.5f) / 16f / GRID
        }

        /** V coordinate of the vertical middle of the ramp cell. */
        fun rampV(): Float {
            val cy = RAMP_CELL / GRID
            return (cy.toFloat() + 0.5f) / GRID
        }

        // ---- procedural pixel helpers (all ARGB ints, straight alpha) --------------------

        private fun rgb(r: Int, g: Int, b: Int): Int = (255 shl 24) or (r shl 16) or (g shl 8) or b

        private fun mul(c: Int, f: Float): Int {
            val a = c ushr 24
            val r = (((c shr 16) and 0xFF) * f).toInt().coerceIn(0, 255)
            val g = (((c shr 8) and 0xFF) * f).toInt().coerceIn(0, 255)
            val b = ((c and 0xFF) * f).toInt().coerceIn(0, 255)
            return (a shl 24) or (r shl 16) or (g shl 8) or b
        }

        private fun hash(x: Int, y: Int, salt: Int): Int {
            var h = x * 374761393 + y * 668265263 + salt * 1274126177
            h = (h xor (h ushr 13)) * 1274126177
            return h xor (h ushr 16)
        }

        /** 0..255 hash noise. */
        private fun rnd(x: Int, y: Int, salt: Int): Int = (hash(x, y, salt) ushr 8) and 0xFF

        /** Blocky value noise: constant over cell x cell squares (coordinates are never negative). */
        private fun vnoise(x: Int, y: Int, cell: Int, salt: Int): Int = rnd(x / cell, y / cell, salt)

        private fun pick(palette: IntArray, v: Int): Int = palette[v * palette.size / 256]

        private fun tile(f: (Int, Int) -> Int): IntArray {
            val out = IntArray(CELL_PX * CELL_PX)
            for (y in 0 until CELL_PX) {
                for (x in 0 until CELL_PX) out[y * CELL_PX + x] = f(x, y)
            }
            return out
        }

        private val GRASS = intArrayOf(rgb(66, 128, 48), rgb(80, 146, 56), rgb(94, 162, 64), rgb(108, 176, 74), rgb(124, 190, 86))
        private val DIRT = intArrayOf(rgb(88, 60, 40), rgb(104, 74, 48), rgb(118, 86, 56), rgb(132, 98, 64))
        private val STONE = intArrayOf(rgb(98, 98, 102), rgb(114, 114, 118), rgb(128, 128, 132), rgb(142, 142, 146))
        private val SAND = intArrayOf(rgb(198, 182, 130), rgb(212, 196, 144), rgb(224, 209, 158), rgb(234, 221, 172))
        private val OAK_BARK = intArrayOf(rgb(70, 49, 29), rgb(88, 62, 36), rgb(104, 75, 44), rgb(120, 88, 54))
        private val SPRUCE_BARK = intArrayOf(rgb(48, 34, 22), rgb(60, 43, 28), rgb(72, 52, 34), rgb(86, 63, 41))
        private val BIRCH_BARK = intArrayOf(rgb(206, 203, 192), rgb(222, 219, 208), rgb(234, 231, 221), rgb(242, 240, 232))
        private val OAK_LEAF = intArrayOf(rgb(34, 92, 38), rgb(46, 112, 46), rgb(62, 134, 54), rgb(84, 158, 68))
        private val BIRCH_LEAF = intArrayOf(rgb(66, 120, 40), rgb(84, 142, 48), rgb(104, 162, 58), rgb(128, 184, 72))
        private val SPRUCE_LEAF = intArrayOf(rgb(22, 58, 42), rgb(30, 74, 52), rgb(40, 92, 62), rgb(56, 112, 76))

        private val RAMP = intArrayOf(
            rgb(228, 213, 164), rgb(214, 198, 146), rgb(196, 184, 128),                      // 0-2 sand
            rgb(124, 176, 80), rgb(102, 160, 68), rgb(92, 150, 62), rgb(80, 136, 56), rgb(62, 112, 48), // 3-7 grass
            rgb(126, 104, 66), rgb(112, 84, 54), rgb(96, 70, 46),                            // 8-10 dirt
            rgb(150, 150, 152), rgb(128, 128, 132), rgb(108, 108, 112),                      // 11-13 stone
            rgb(60, 116, 206),                                                               // 14 water
            rgb(108, 108, 112)                                                               // 15 spare
        )

        // ---- individual tiles ---------------------------------------------------------

        private fun grassTop(): IntArray = tile { x, y ->
            val v = (vnoise(x, y, 2, 11) * 3 + rnd(x, y, 12)) / 4
            var c = pick(GRASS, v)
            val r = rnd(x, y, 13)
            if (r < 16) c = mul(c, 0.80f) else if (r > 240) c = mul(c, 1.16f)
            c
        }

        private fun dirtPixel(x: Int, y: Int): Int {
            val v = (vnoise(x, y, 2, 21) * 2 + rnd(x, y, 22) * 2) / 4
            var c = pick(DIRT, v)
            val r = rnd(x, y, 23)
            if (r < 14) c = mul(c, 0.76f) else if (r > 246) c = rgb(150, 128, 100)
            return c
        }

        private fun dirt(): IntArray = tile { x, y -> dirtPixel(x, y) }

        private fun grassSide(): IntArray = tile { x, y ->
            val depth = 3 + (rnd(x, 0, 31) % 3)
            if (y < depth) {
                val v = (vnoise(x, y, 2, 11) * 3 + rnd(x, y, 12)) / 4
                val c = pick(GRASS, v)
                if (y == depth - 1) mul(c, 0.78f) else c
            } else if (y == depth && rnd(x, 1, 32) < 90) {
                mul(pick(GRASS, rnd(x, 2, 33)), 0.7f)
            } else {
                dirtPixel(x, y)
            }
        }

        private fun stone(): IntArray = tile { x, y ->
            val v = (vnoise(x, y, 4, 41) * 2 + rnd(x, y, 42) * 2) / 4
            var c = pick(STONE, v)
            val r = rnd(x, y, 43)
            if (r < 14) c = mul(c, 0.74f) else if (r > 244) c = mul(c, 1.14f)
            if ((x + y * 2 + rnd(x / 8, y / 8, 44)) % 11 == 0 && rnd(x, y, 45) < 120) c = mul(c, 0.84f)
            c
        }

        private fun sand(): IntArray = tile { x, y ->
            val v = (vnoise(x, y, 2, 51) + rnd(x, y, 52) * 3) / 4
            var c = pick(SAND, v)
            val r = rnd(x, y, 53)
            if (r < 12) c = mul(c, 0.9f) else if (r > 246) c = mul(c, 1.05f)
            c
        }

        private fun bark(palette: IntArray, salt: Int, groove: Float): IntArray = tile { x, y ->
            val col = rnd(x, 0, salt)
            val streak = rnd(x, y / 5, salt + 1)
            var c = pick(palette, (col * 2 + streak) / 3)
            if (x % 4 == 0 && rnd(x, y, salt + 2) < 150) c = mul(c, groove)
            if (rnd(x, y, salt + 3) < 12) c = mul(c, 0.86f)
            c
        }

        private fun birchSide(): IntArray {
            val px = tile { x, y ->
                val v = (rnd(x, y / 4, 111) * 2 + rnd(x, y, 112)) / 3
                pick(BIRCH_BARK, v)
            }
            // the dark horizontal scars birches are known for
            for (y in 0 until CELL_PX) {
                if (rnd(0, y, 113) < 84) {
                    val mx = rnd(1, y, 113) % 11
                    val len = 2 + rnd(2, y, 113) % 4
                    for (k in 0 until len) {
                        val xx = (mx + k) % CELL_PX
                        px[y * CELL_PX + xx] = if (rnd(xx, y, 114) > 50) rgb(58, 56, 52) else rgb(92, 90, 84)
                    }
                }
            }
            return px
        }

        private fun rings(outer: Int, ringA: Int, ringB: Int, core: Int, edge: Int): IntArray = tile { x, y ->
            val dx = x - 7.5f
            val dy = y - 7.5f
            val d = sqrt(dx * dx + dy * dy)
            if (d > 6.7f) {
                if (rnd(x, y, 71) < 70) edge else outer
            } else {
                var c = if ((d * 1.15f).toInt() % 2 == 0) ringA else ringB
                if (d < 1.2f) c = core
                if (rnd(x, y, 72) < 18) c = mul(c, 0.92f)
                c
            }
        }

        private fun leaves(palette: IntArray, salt: Int, holeThr: Int, dark: Int, bright: Int): IntArray = tile { x, y ->
            val blob = vnoise(x + (y % 2), y, 3, salt)
            val v = (blob * 2 + rnd(x, y, salt + 1)) / 3
            var c = pick(palette, v)
            val r = rnd(x, y, salt + 2)
            if (r > 238) c = bright
            // Holes are clumped in 2x2 cells, then eroded per pixel, so foliage gets a
            // ragged leafy silhouette instead of salt-and-pepper noise.
            val hole = rnd(x / 2, y / 2, salt + 3) < holeThr && rnd(x, y, salt + 5) >= 90
            if (hole) {
                dark and 0x00FFFFFF // same colour, alpha 0
            } else {
                if (r < 28) c = dark
                c
            }
        }

        private fun coalOre(): IntArray {
            val px = stone()
            val blobs = intArrayOf(3, 4, 10, 3, 6, 10, 12, 11, 2, 12)
            val coal = rgb(28, 28, 32)
            val coalHi = rgb(66, 66, 72)
            for (i in 0 until 5) {
                val ox = blobs[i * 2] + (rnd(i, 0, 91) % 3) - 1
                val oy = blobs[i * 2 + 1] + (rnd(i, 1, 91) % 3) - 1
                val w = 2 + (rnd(i, 2, 91) % 2)
                for (dy in 0 until 2) {
                    for (dx in 0 until w) {
                        px[((oy + dy) and 15) * CELL_PX + ((ox + dx) and 15)] = coal
                    }
                }
                px[(oy and 15) * CELL_PX + (ox and 15)] = coalHi
            }
            return px
        }

        private fun water(): IntArray = tile { x, y ->
            val w = sin((x + y * 0.6f) * 0.9f) + sin(y * 1.1f + x * 0.3f)
            var c = if (w > 1.0f) rgb(92, 148, 226) else if (w < -1.0f) rgb(46, 98, 184) else rgb(60, 116, 206)
            if (rnd(x, y, 101) < 10) c = rgb(104, 158, 232)
            c
        }

        private fun white(): IntArray = tile { _, _ -> rgb(255, 255, 255) }

        private fun ramp(): IntArray = tile { x, _ -> RAMP[x] }

        private fun blit(atlas: IntArray, cell: Int, pixels: IntArray) {
            val ox = (cell % GRID) * CELL_PX
            val oy = (cell / GRID) * CELL_PX
            for (y in 0 until CELL_PX) {
                for (x in 0 until CELL_PX) atlas[(oy + y) * SIZE_PX + ox + x] = pixels[y * CELL_PX + x]
            }
        }

        private fun buildBase(): IntArray {
            val atlas = IntArray(SIZE_PX * SIZE_PX)
            // Unused cells are loud magenta so a wrong cell index is obvious, never silently dark.
            java.util.Arrays.fill(atlas, rgb(255, 0, 255))
            blit(atlas, 0, grassTop())
            blit(atlas, 1, grassSide())
            blit(atlas, 2, dirt())
            blit(atlas, 3, stone())
            blit(atlas, 4, sand())
            blit(atlas, 5, bark(OAK_BARK, 61, 0.78f))
            blit(atlas, 6, rings(rgb(96, 68, 40), rgb(184, 146, 96), rgb(158, 120, 76), rgb(132, 98, 60), rgb(80, 56, 33)))
            blit(atlas, 7, leaves(OAK_LEAF, 81, 36, rgb(22, 62, 28), rgb(110, 184, 86)))
            blit(atlas, 8, coalOre())
            blit(atlas, WATER_CELL, water())
            blit(atlas, WHITE_CELL, white())
            blit(atlas, 11, birchSide())
            blit(atlas, 12, leaves(BIRCH_LEAF, 121, 36, rgb(44, 86, 30), rgb(160, 208, 96)))
            blit(atlas, 13, leaves(SPRUCE_LEAF, 141, 30, rgb(14, 40, 30), rgb(86, 142, 100)))
            blit(atlas, 14, bark(SPRUCE_BARK, 161, 0.74f))
            blit(atlas, RAMP_CELL, ramp())
            blit(atlas, 16, rings(rgb(226, 223, 212), rgb(214, 196, 150), rgb(190, 168, 122), rgb(160, 138, 96), rgb(190, 187, 176)))
            blit(atlas, 17, rings(rgb(70, 50, 32), rgb(160, 122, 78), rgb(134, 98, 60), rgb(110, 78, 46), rgb(54, 38, 24)))
            return atlas
        }

        /** Alpha-weighted 2x2 box filter: transparent texels (leaf holes) don't drag the
         *  colour of the surviving texels toward black, while alpha itself is a plain
         *  average so distant foliage keeps its coverage. */
        private fun halve(src: IntArray, srcSize: Int): IntArray {
            val s = srcSize / 2
            val out = IntArray(s * s)
            for (y in 0 until s) {
                for (x in 0 until s) {
                    var rs = 0
                    var gs = 0
                    var bs = 0
                    var asum = 0
                    for (dy in 0 until 2) {
                        for (dx in 0 until 2) {
                            val p = src[(y * 2 + dy) * srcSize + (x * 2 + dx)]
                            val a = p ushr 24
                            rs += ((p shr 16) and 0xFF) * a
                            gs += ((p shr 8) and 0xFF) * a
                            bs += (p and 0xFF) * a
                            asum += a
                        }
                    }
                    out[y * s + x] = if (asum == 0) {
                        0
                    } else {
                        ((asum / 4) shl 24) or ((rs / asum) shl 16) or ((gs / asum) shl 8) or (bs / asum)
                    }
                }
            }
            return out
        }
    }

    private val mips: Array<IntArray> = buildMips()
    private var textureId: Int = 0

    private fun buildMips(): Array<IntArray> {
        val levels = ArrayList<IntArray>(MIP_LEVELS)
        var cur = buildBase()
        var size = SIZE_PX
        levels.add(cur)
        for (i in 1 until MIP_LEVELS) {
            cur = halve(cur, size)
            size /= 2
            levels.add(cur)
        }
        return levels.toTypedArray()
    }

    fun uvFor(cell: Int): UVRect {
        if (cell < 0) return EMPTY_UV
        // Out-of-grid cells (never used by any block) keep the original computed
        // result rather than indexing past the table.
        return if (cell < UV_TABLE.size) UV_TABLE[cell] else computeUv(cell)
    }

    fun uploadToGL() {
        val ids = IntArray(1)
        GLES30.glGenTextures(1, ids, 0)
        textureId = ids[0]
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textureId)
        // Crisp pixels up close, smooth blend between mip levels in the distance (this is
        // what removes the shimmering/noise on far terrain).
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_NEAREST_MIPMAP_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_NEAREST)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_BASE_LEVEL, 0)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAX_LEVEL, MIP_LEVELS - 1)

        var size = SIZE_PX
        for (level in 0 until MIP_LEVELS) {
            val pixels = mips[level]
            val buf = ByteBuffer.allocateDirect(size * size * 4).order(ByteOrder.nativeOrder())
            for (p in pixels) {
                buf.put(((p shr 16) and 0xFF).toByte())
                buf.put(((p shr 8) and 0xFF).toByte())
                buf.put((p and 0xFF).toByte())
                buf.put((p ushr 24).toByte())
            }
            buf.position(0)
            GLES30.glTexImage2D(
                GLES30.GL_TEXTURE_2D, level, GLES30.GL_RGBA, size, size, 0,
                GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, buf
            )
            size /= 2
        }
    }

    fun bind(unit: Int = 0) {
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0 + unit)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textureId)
    }
}
