package com.voxelsandbox.game.world

import com.voxelsandbox.game.gl.TextureAtlas
import com.voxelsandbox.game.world.generation.TerrainGenerator
import com.voxelsandbox.game.world.mesh.ChunkMesher
import com.voxelsandbox.game.world.mesh.MeshData
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.PriorityBlockingQueue
import kotlin.math.max
import kotlin.math.min

data class ChunkStats(val loadedChunks: Int, val genQueueSize: Int, val meshQueueSize: Int, val chunkBudget: Int)

/**
 * Owns chunk lifecycle end-to-end: deciding which chunks should exist for the
 * player's position and render distance, generating and meshing them off the main
 * thread with small bounded worker pools, and unloading chunks that fall out of
 * range. Player-driven edits (break/place) get top scheduling priority so they feel
 * instant even while the background streaming system is busy.
 *
 * GPU work (uploading a finished mesh, deleting a mesh for an unloaded chunk) cannot
 * happen on these worker threads — only the GL thread owns the EGL context — so
 * finished work is handed off via [pendingMeshUploads] / [pendingUnloads], which
 * GameRenderer drains once per frame from onDrawFrame.
 */
class WorldManager(
    private val world: World,
    private val generator: TerrainGenerator,
    private val atlas: TextureAtlas,
    private val savedChunkOverrides: Map<ChunkPos, ByteArray> = emptyMap()
) {
    /** [priority] carries the same value its MeshJob was built with, so an edit's
     *  top-priority (Long.MIN_VALUE) status survives the hand-off to the GPU upload
     *  queue instead of being flattened to FIFO order — see pendingMeshUploads. */
    data class MeshResult(val pos: ChunkPos, val subY: Int, val data: MeshData, val priority: Long)

    private data class GenJob(val pos: ChunkPos, val priority: Long)
    private data class MeshJob(val pos: ChunkPos, val subY: Int, val priority: Long)

    private val chunkStates = ConcurrentHashMap<ChunkPos, ChunkState>()
    // Plain Long.compare comparators: the compareBy { } lambda form boxes both priorities
    // into java.lang.Long objects on every single comparison (several per queue
    // insert/poll), which was a steady stream of garbage on every thread touching these.
    private val genQueue = PriorityBlockingQueue<GenJob>(
        64, Comparator<GenJob> { a, b -> java.lang.Long.compare(a.priority, b.priority) }
    )
    private val meshQueue = PriorityBlockingQueue<MeshJob>(
        64, Comparator<MeshJob> { a, b -> java.lang.Long.compare(a.priority, b.priority) }
    )
    private val queuedMeshKeys = ConcurrentHashMap.newKeySet<Long>()

    /** Priority-ordered, not FIFO: at high render distance thousands of streaming
     *  chunk uploads can be queued at once, and GameRenderer only drains a handful
     *  per frame. A plain FIFO queue here would let a player's own top-priority
     *  edit (already meshed first, above) sit behind that entire backlog before its
     *  upload is ever drained — the finished mesh existing but never reaching the
     *  GPU is exactly what reads as "I placed a block and it's invisible." Ordering
     *  by the same priority the mesh job carried keeps edits jumping the line here
     *  too. */
    val pendingMeshUploads = PriorityBlockingQueue<MeshResult>(
        64, Comparator<MeshResult> { a, b -> java.lang.Long.compare(a.priority, b.priority) }
    )
    val pendingUnloads = LinkedBlockingQueue<ChunkPos>()

    val maxLoadedChunks: Int = computeChunkBudget()

    @Volatile private var running = false
    @Volatile private var playerX = 0f
    @Volatile private var playerZ = 0f
    @Volatile private var renderDistance = 8
    @Volatile private var lastSchedCenter: ChunkPos? = null
    @Volatile private var lastSchedRadius: Int = -1

    private var lastRebuildMs = 0L

    private val workerCount = max(1, min(2, Runtime.getRuntime().availableProcessors() / 2))
    private val threads = ArrayList<Thread>()

    /** Streaming work (generation, meshing, scheduling) is latency-tolerant, so these
     *  threads run just below background priority: still in the foreground cpu group (so
     *  they can't be starved to a crawl) but with a much lower scheduling weight than the
     *  render and UI threads. At the default priority they competed with the GL thread on
     *  equal terms for the phone's few fast cores, which is exactly when frames hitched
     *  while new terrain streamed in. */
    private fun runAsBackgroundWorker() {
        try {
            android.os.Process.setThreadPriority(
                android.os.Process.THREAD_PRIORITY_BACKGROUND + android.os.Process.THREAD_PRIORITY_MORE_FAVORABLE
            )
        } catch (t: Throwable) {
            // Best effort only: if a ROM refuses the change the game just runs as before.
        }
    }

    fun start() {
        if (running) return
        running = true
        repeat(workerCount) { i ->
            Thread({ genWorkerLoop() }, "voxel-gen-$i").apply { isDaemon = true; start() }.also { threads.add(it) }
        }
        repeat(workerCount) { i ->
            Thread({ meshWorkerLoop() }, "voxel-mesh-$i").apply { isDaemon = true; start() }.also { threads.add(it) }
        }
        Thread({ schedulerLoop() }, "voxel-scheduler").apply { isDaemon = true; start() }.also { threads.add(it) }
    }

    fun shutdown() {
        running = false
        threads.forEach { it.interrupt() }
        threads.clear()
    }

    /** Cheap: just records the latest position/setting for the scheduler thread to
     *  pick up. Safe to call every frame from the game loop. */
    fun updatePlayerPosition(x: Float, z: Float, renderDistanceChunks: Int) {
        playerX = x
        playerZ = z
        renderDistance = renderDistanceChunks
    }

    fun stats(): ChunkStats = ChunkStats(world.chunkCount(), genQueue.size, meshQueue.size, maxLoadedChunks)

    /** The full-detail chunk radius currently being maintained around the player. */
    val activeRadius: Int get() = renderDistance

    fun isChunkGenerated(pos: ChunkPos): Boolean = chunkStates[pos] == ChunkState.GENERATED

    /** Forces a chunk to the very front of the generation queue. Used once at world
     *  start/load so the spawn column is ready quickly instead of waiting its turn. */
    fun requestImmediateChunk(pos: ChunkPos) {
        if ((chunkStates[pos] ?: ChunkState.UNLOADED) == ChunkState.UNLOADED) {
            chunkStates[pos] = ChunkState.QUEUED
            genQueue.put(GenJob(pos, Long.MIN_VALUE))
        }
    }

    /** Applies a player-driven block edit and schedules the minimal set of remeshes
     *  (this subchunk, plus neighbors across any boundary the edit touched) at top
     *  priority. */
    fun setBlockAndRemesh(x: Int, y: Int, z: Int, type: BlockType): Boolean {
        if (!world.setBlock(x, y, z, type)) return false
        markDirtyAround(x, y, z)
        return true
    }

    private fun markDirtyAround(x: Int, y: Int, z: Int) {
        val cx = Math.floorDiv(x, WorldConfig.CHUNK_SIZE)
        val cz = Math.floorDiv(z, WorldConfig.CHUNK_SIZE)
        val lx = Math.floorMod(x, WorldConfig.CHUNK_SIZE)
        val lz = Math.floorMod(z, WorldConfig.CHUNK_SIZE)
        val subY = (y / WorldConfig.SUBCHUNK_HEIGHT).coerceIn(0, WorldConfig.SUBCHUNKS_PER_CHUNK - 1)
        val ly = y % WorldConfig.SUBCHUNK_HEIGHT

        val affected = LinkedHashSet<Pair<ChunkPos, Int>>()
        affected.add(ChunkPos(cx, cz) to subY)
        if (lx == 0) affected.add(ChunkPos(cx - 1, cz) to subY)
        if (lx == WorldConfig.CHUNK_SIZE - 1) affected.add(ChunkPos(cx + 1, cz) to subY)
        if (lz == 0) affected.add(ChunkPos(cx, cz - 1) to subY)
        if (lz == WorldConfig.CHUNK_SIZE - 1) affected.add(ChunkPos(cx, cz + 1) to subY)
        if (ly == 0 && subY > 0) affected.add(ChunkPos(cx, cz) to subY - 1)
        if (ly == WorldConfig.SUBCHUNK_HEIGHT - 1 && subY < WorldConfig.SUBCHUNKS_PER_CHUNK - 1) {
            affected.add(ChunkPos(cx, cz) to subY + 1)
        }

        for ((pos, sy) in affected) {
            if (chunkStates[pos] == ChunkState.GENERATED) enqueueMesh(pos, sy, Long.MIN_VALUE)
        }
    }

    // ---- Scheduler: decides the wanted chunk set and drives load/unload ----------

    private fun schedulerLoop() {
        runAsBackgroundWorker()
        while (running) {
            try {
                val center = ChunkPos.fromWorld(playerX, playerZ)
                val radius = renderDistance
                // Re-run whenever EITHER changes. Gating on center alone means
                // changing the render-distance setting while standing still (the
                // normal way to change it, via the pause menu) never gets picked
                // up until the player happens to cross into a new chunk — which
                // reads as "I changed render distance and nothing new generates."
                //
                // The periodic re-run (every couple of seconds even when nothing moved)
                // is a safety net: any chunk whose generation failed or got cancelled
                // mid-flight is simply re-queued, so a hole can never be permanent.
                val now = System.currentTimeMillis()
                if (center != lastSchedCenter || radius != lastSchedRadius || now - lastRebuildMs > REBUILD_INTERVAL_MS) {
                    lastSchedCenter = center
                    lastSchedRadius = radius
                    lastRebuildMs = now
                    rebuildWantedSet(center, radius)
                }
                Thread.sleep(150)
            } catch (e: InterruptedException) {
                return
            }
        }
    }

    private fun rebuildWantedSet(center: ChunkPos, radius: Int) {
        val offsets = ChunkRing.offsets(radius)
        val cap = min(offsets.size, maxLoadedChunks)
        val wanted = LinkedHashSet<ChunkPos>(cap * 2)
        for (i in 0 until cap) {
            val o = offsets[i]
            wanted.add(ChunkPos(center.x + o[0], center.z + o[1]))
        }

        for (pos in wanted) {
            val state = chunkStates[pos] ?: ChunkState.UNLOADED
            if (state == ChunkState.UNLOADED) {
                chunkStates[pos] = ChunkState.QUEUED
                genQueue.put(GenJob(pos, pos.distanceSquaredTo(center)))
            }
        }

        // The unload boundary must track whichever constraint is tighter right now:
        // the radius setting, or the memory budget cutting the wanted set off
        // earlier. Using only a fixed radius here would let already-loaded chunks
        // beyond the budget rank linger forever once render distance exceeds what
        // the budget allows — exactly the extreme (60-chunk) case the budget exists
        // for. A little hysteresis beyond the cutoff avoids thrashing chunks right
        // at the boundary in and out of existence every scheduler tick.
        val cutoffDistSq = if (cap > 0) {
            val o = offsets[cap - 1]
            (o[0] * o[0] + o[1] * o[1]).toLong()
        } else 0L
        val hysteresisDist = kotlin.math.sqrt(cutoffDistSq.toDouble()) + 2.0
        val hysteresisDistSq = (hysteresisDist * hysteresisDist).toLong()

        val toUnload = ArrayList<ChunkPos>()
        for (pos in chunkStates.keys) {
            if (wanted.contains(pos)) continue
            if (pos.distanceSquaredTo(center) > hysteresisDistSq) toUnload.add(pos)
        }
        for (pos in toUnload) unloadChunk(pos)
    }

    private fun unloadChunk(pos: ChunkPos) {
        chunkStates[pos] = ChunkState.UNLOADING
        world.removeChunk(pos)
        chunkStates.remove(pos)
        pendingUnloads.put(pos)
    }

    // ---- Generation ---------------------------------------------------------------

    private fun genWorkerLoop() {
        runAsBackgroundWorker()
        while (running) {
            val job = try {
                genQueue.take()
            } catch (e: InterruptedException) {
                return
            }
            if (chunkStates[job.pos] != ChunkState.QUEUED) continue // cancelled/obsolete
            chunkStates[job.pos] = ChunkState.GENERATING

            val chunk = try {
                val override = savedChunkOverrides[job.pos]
                if (override != null) {
                    Chunk(job.pos).apply {
                        deserializeBlocks(override)
                        hasPlayerEdits = true
                    }
                } else {
                    generator.generate(job.pos)
                }
            } catch (t: Throwable) {
                chunkStates.remove(job.pos)
                continue
            }

            if (chunkStates[job.pos] != ChunkState.GENERATING) continue // unloaded mid-generation

            world.putChunk(chunk)
            chunkStates[job.pos] = ChunkState.GENERATED
            onChunkGenerated(job.pos)
        }
    }

    private fun onChunkGenerated(pos: ChunkPos) {
        val center = lastSchedCenter ?: pos
        for (subY in 0 until WorldConfig.SUBCHUNKS_PER_CHUNK) {
            enqueueMesh(pos, subY, pos.distanceSquaredTo(center))
        }
        // Neighbors that already exist assumed "unknown" (non-opaque) across this
        // shared boundary; now that real data exists, they need to remesh too.
        val neighbors = arrayOf(
            ChunkPos(pos.x - 1, pos.z), ChunkPos(pos.x + 1, pos.z),
            ChunkPos(pos.x, pos.z - 1), ChunkPos(pos.x, pos.z + 1)
        )
        for (n in neighbors) {
            if (chunkStates[n] == ChunkState.GENERATED) {
                for (subY in 0 until WorldConfig.SUBCHUNKS_PER_CHUNK) {
                    enqueueMesh(n, subY, n.distanceSquaredTo(center))
                }
            }
        }
    }

    /** Re-queues mesh jobs for every currently generated chunk. Used when the GL
     *  surface/context is recreated (e.g. after the app is backgrounded) and any
     *  previously uploaded GPU meshes are now invalid handles — the CPU-side block
     *  data itself is untouched, so this only needs to remesh, not regenerate. */
    fun remeshAllLoaded() {
        val center = lastSchedCenter
        for (chunk in world.allChunks()) {
            if (chunkStates[chunk.pos] != ChunkState.GENERATED) continue
            for (subY in 0 until WorldConfig.SUBCHUNKS_PER_CHUNK) {
                val priority = center?.let { chunk.pos.distanceSquaredTo(it) } ?: 0L
                enqueueMesh(chunk.pos, subY, priority)
            }
        }
    }

    // ---- Meshing --------------------------------------------------------------

    private fun enqueueMesh(pos: ChunkPos, subY: Int, priority: Long) {
        val key = meshKey(pos, subY)
        if (!queuedMeshKeys.add(key)) return
        meshQueue.put(MeshJob(pos, subY, priority))
    }

    private fun meshKey(pos: ChunkPos, subY: Int): Long =
        (pos.x.toLong() and 0xFFFFFL) or ((pos.z.toLong() and 0xFFFFFL) shl 20) or (subY.toLong() shl 40)

    private fun meshWorkerLoop() {
        runAsBackgroundWorker()
        while (running) {
            val job = try {
                meshQueue.take()
            } catch (e: InterruptedException) {
                return
            }
            queuedMeshKeys.remove(meshKey(job.pos, job.subY))
            if (chunkStates[job.pos] != ChunkState.GENERATED) continue

            val chunk = world.getChunk(job.pos) ?: continue
            val sub = chunk.subChunks.getOrNull(job.subY) ?: continue
            sub.meshDirty = false

            val data = try {
                ChunkMesher.buildSubChunkMesh(world, job.pos.x, job.pos.z, job.subY, atlas)
            } catch (t: Throwable) {
                continue
            }
            sub.isEmpty = data.isEmpty()

            if (chunkStates[job.pos] == ChunkState.GENERATED) {
                // Backpressure: GameRenderer only drains a bounded number of these
                // per frame (see GameRenderer.drainMeshUploads), but pendingMeshUploads
                // itself has no size limit — so without this wait, a burst of terrain
                // needing meshing (a large render distance, falling/teleporting into a
                // wide swath of new chunks) lets these worker threads produce finished
                // MeshData — real vertex/index float/int arrays, which for a dense
                // subchunk run well into the hundreds of KB, not the compact 16KB raw
                // block data the memory budget above actually accounts for — far
                // faster than the GL thread can ever drain them. That backlog was free
                // to grow completely unbounded: the real, unaccounted-for cause of the
                // "everything gets slower and slower, then OOM crashes" pattern under
                // heavy streaming. Waiting here doesn't lose the finished mesh, it just
                // holds this worker until there's headroom, which naturally paces
                // meshing to match how fast the GPU side actually drains it.
                while (running && pendingMeshUploads.size >= MAX_PENDING_UPLOADS) {
                    try {
                        Thread.sleep(4)
                    } catch (e: InterruptedException) {
                        return
                    }
                }
                pendingMeshUploads.put(MeshResult(job.pos, job.subY, data, job.priority))
            }
        }
    }

    companion object {
        /** Backpressure ceiling for pendingMeshUploads — see meshWorkerLoop for why an
         *  unbounded queue there was a real, direct path to a crash. 128 comfortably
         *  smooths over normal frame-to-frame variance in GPU upload timing while
         *  still bounding worst-case transient mesh memory to a level a large-heap
         *  budget phone can actually sustain, rather than the unlimited backlog this
         *  replaces. */
        private const val MAX_PENDING_UPLOADS = 128

        /** How often the wanted set is re-evaluated even if the player hasn't moved. */
        private const val REBUILD_INTERVAL_MS = 2000L

        /** Budgets chunk-column memory against a slice of this app's OWN heap
         *  ceiling, not the device's total RAM: maxMemory() respects
         *  android:largeHeap and whatever this specific device actually grants the
         *  process, which is the real wall the game can hit — a device can have
         *  several GB of total RAM while still handing this app a heap ceiling of a
         *  few hundred MB, and 3% of the former can ask for far more than 100% of
         *  the latter could ever hold. This is what keeps a 60-chunk render
         *  distance from trying to hold hundreds of MB of voxel data on a device
         *  whose actual heap can't sustain that: far corners beyond the budget
         *  simply don't load, no matter how far the visual setting is cranked.
         *
         *  perChunk is deliberately more than BYTES_PER_CHUNK's raw 16 KB of block
         *  bytes: columnMeshData (see GameRenderer) intentionally keeps every
         *  subchunk's full, uncompressed CPU-side vertex/index arrays cached for as
         *  long as the column stays loaded — specifically so editing one subchunk
         *  doesn't force re-meshing its untouched neighbors — and for real terrain
         *  that cache routinely runs several times the size of the raw block data
         *  it was built from. Budgeting off the raw size alone was the real,
         *  unaccounted-for gap that let "chunk count" look safely within budget
         *  while actual resident memory was already several times higher. The 4x
         *  here is a deliberately conservative stand-in for "raw block data plus
         *  its cached mesh," not a measurement of any specific chunk. */
        private fun computeChunkBudget(): Int {
            return try {
                val budgetBytes = (Runtime.getRuntime().maxMemory() * 0.20).toLong()
                val perChunk = WorldConfig.BYTES_PER_CHUNK.toLong() * 4
                (budgetBytes / perChunk).toInt().coerceIn(300, 6000)
            } catch (t: Throwable) {
                1200
            }
        }
    }
}
