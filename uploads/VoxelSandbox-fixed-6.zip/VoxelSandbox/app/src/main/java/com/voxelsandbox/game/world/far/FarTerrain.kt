package com.voxelsandbox.game.world.far

import com.voxelsandbox.game.gl.TextureAtlas
import com.voxelsandbox.game.world.WorldConfig
import com.voxelsandbox.game.world.generation.TerrainGenerator
import com.voxelsandbox.game.world.mesh.MeshData
import java.util.concurrent.LinkedBlockingQueue
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

/** Tile add ([tile] != null) or removal ([tile] == null) for [key], delivered to the GL
 *  thread strictly in the order the worker produced them. A single ordered stream matters:
 *  with separate "ready" and "unload" queues a tile that was built, unloaded and rebuilt
 *  could be applied in the wrong order and leave a ghost mesh behind. */
class FarEvent(val key: Long, val tile: FarTile?)

/** One finished distant-terrain tile, ready for the GL thread to upload. */
class FarTile(
    val key: Long,
    val mesh: MeshData,
    val minY: Float,
    val maxY: Float
) {
    /** World-space X/Z of the tile's lower corner. */
    val x0: Float get() = (key shr 32).toInt() * FarTerrain.TILE_BLOCKS.toFloat()
    val z0: Float get() = key.toInt() * FarTerrain.TILE_BLOCKS.toFloat()
}

/**
 * Distant terrain: a cheap heightfield that fills the space between the full-detail voxel
 * chunks and the horizon, so the view distance can be many times larger than what voxel
 * chunks could ever afford (memory- or draw-call-wise).
 *
 * Nothing here touches the voxel world. Heights come straight from the terrain
 * generator's pure height function, so a tile can exist for terrain that no chunk has
 * generated yet — which is also why the horizon is there instantly at start-up and why
 * it fills any gap while real chunks are still streaming in.
 *
 * The world is cut into square tiles of [TILE_CHUNKS] x [TILE_CHUNKS] chunks, one mesh and
 * one draw call each. A tile is a grid of vertices every [STEP] blocks; neighbouring tiles
 * sample exactly the same heights along their shared edge, so there are no cracks. A single
 * flat water quad per tile covers the sea. Colour comes from a one-row "ramp" in the
 * texture atlas (sand -> grass -> dirt -> stone) chosen from height, slope and forest
 * density, so a tile needs no per-block textures.
 *
 * Everything is built on one background thread, nearest tile first. [coveredRadiusBlocks]
 * reports how far from the player the tiles are contiguously complete, which the renderer
 * uses to keep the fog in front of any still-missing ground.
 */
class FarTerrain(private val generator: TerrainGenerator) {

    @Volatile private var running = false
    @Volatile private var enabled = true
    @Volatile private var playerX = 0f
    @Volatile private var playerZ = 0f
    @Volatile private var radiusBlocks = 0f
    @Volatile private var resetRequested = false

    /** Tiles to add / remove, in order, for the GL thread to apply. */
    val events = LinkedBlockingQueue<FarEvent>()

    /** Distance from the player out to which every wanted tile has been built. */
    @Volatile var coveredRadiusBlocks: Float = 0f
        private set

    private var thread: Thread? = null

    fun start() {
        if (running) return
        running = true
        thread = Thread({ workerLoop() }, "voxel-far").apply {
            isDaemon = true
            start()
        }
    }

    fun shutdown() {
        running = false
        thread?.interrupt()
        thread = null
    }

    /** Cheap; safe to call every frame. [radius] is the render distance in blocks. */
    fun updatePlayer(x: Float, z: Float, radius: Float, enable: Boolean) {
        playerX = x
        playerZ = z
        radiusBlocks = radius
        enabled = enable
    }

    /** The renderer lost its GL objects (context recreated): everything must be rebuilt
     *  and re-sent, since the CPU copies are not kept after upload. */
    fun invalidateAll() {
        resetRequested = true
    }

    // ---- worker ---------------------------------------------------------------------------

    private class Candidate(val tx: Int, val tz: Int, val key: Long, val nearDist: Float)

    private fun workerLoop() {
        try {
            android.os.Process.setThreadPriority(
                android.os.Process.THREAD_PRIORITY_BACKGROUND + android.os.Process.THREAD_PRIORITY_MORE_FAVORABLE
            )
        } catch (t: Throwable) {
            // best effort only
        }

        val built = HashSet<Long>()
        while (running) {
            try {
                if (resetRequested) {
                    resetRequested = false
                    built.clear()
                    events.clear()
                    coveredRadiusBlocks = 0f
                }

                val radius = radiusBlocks
                if (!enabled || radius < 32f) {
                    if (built.isNotEmpty()) {
                        for (k in built) events.put(FarEvent(k, null))
                        built.clear()
                    }
                    coveredRadiusBlocks = 0f
                    Thread.sleep(250)
                    continue
                }

                val px = playerX
                val pz = playerZ
                val wanted = planTiles(px, pz, radius)
                unloadStale(built, px, pz, radius)

                var replan = false
                for (cand in wanted) {
                    if (!running) return
                    if (built.contains(cand.key)) continue

                    // Wanted tiles are sorted nearest-first and every nearer one is already
                    // built, so contiguous coverage ends exactly where this tile begins.
                    coveredRadiusBlocks = cand.nearDist

                    // Backpressure: the GL thread uploads only a couple per frame.
                    while (running && events.size >= MAX_QUEUED_EVENTS) Thread.sleep(4)

                    val tile = buildTile(cand.tx, cand.tz)
                    events.put(FarEvent(tile.key, tile))
                    built.add(cand.key)

                    if (resetRequested || !enabled || radiusBlocks != radius ||
                        abs(playerX - px) > REPLAN_DISTANCE || abs(playerZ - pz) > REPLAN_DISTANCE
                    ) {
                        replan = true
                        break
                    }
                }
                if (!replan) {
                    coveredRadiusBlocks = radius
                    Thread.sleep(120)
                }
            } catch (e: InterruptedException) {
                return
            } catch (t: Throwable) {
                // A bad tile must never kill the whole horizon; back off briefly and retry.
                try {
                    Thread.sleep(250)
                } catch (e: InterruptedException) {
                    return
                }
            }
        }
    }

    private fun planTiles(px: Float, pz: Float, radius: Float): ArrayList<Candidate> {
        val minTx = Math.floorDiv(floor(px - radius).toInt(), TILE_BLOCKS)
        val maxTx = Math.floorDiv(floor(px + radius).toInt(), TILE_BLOCKS)
        val minTz = Math.floorDiv(floor(pz - radius).toInt(), TILE_BLOCKS)
        val maxTz = Math.floorDiv(floor(pz + radius).toInt(), TILE_BLOCKS)
        val out = ArrayList<Candidate>()
        for (tz in minTz..maxTz) {
            for (tx in minTx..maxTx) {
                val d = nearestDistance(tx, tz, px, pz)
                if (d <= radius) out.add(Candidate(tx, tz, tileKey(tx, tz), d))
            }
        }
        out.sortBy { it.nearDist }
        return out
    }

    private fun unloadStale(built: HashSet<Long>, px: Float, pz: Float, radius: Float) {
        var stale: ArrayList<Long>? = null
        for (key in built) {
            val d = nearestDistance((key shr 32).toInt(), key.toInt(), px, pz)
            if (d > radius + TILE_BLOCKS) {
                if (stale == null) stale = ArrayList()
                stale.add(key)
            }
        }
        if (stale != null) {
            for (key in stale) {
                built.remove(key)
                events.put(FarEvent(key, null))
            }
        }
    }

    private fun nearestDistance(tx: Int, tz: Int, px: Float, pz: Float): Float {
        val x0 = (tx * TILE_BLOCKS).toFloat()
        val z0 = (tz * TILE_BLOCKS).toFloat()
        val cx = if (px < x0) x0 else if (px > x0 + TILE_BLOCKS) x0 + TILE_BLOCKS else px
        val cz = if (pz < z0) z0 else if (pz > z0 + TILE_BLOCKS) z0 + TILE_BLOCKS else pz
        val dx = px - cx
        val dz = pz - cz
        return sqrt(dx * dx + dz * dz)
    }

    // ---- tile construction ----------------------------------------------------------------

    private fun buildTile(tx: Int, tz: Int): FarTile {
        val x0 = tx * TILE_BLOCKS
        val z0 = tz * TILE_BLOCKS

        // Heights on the vertex grid plus one extra ring on every side (for edge slopes).
        val n = VERTS + 2
        val heights = IntArray(n * n)
        var lowest = Int.MAX_VALUE
        var highest = Int.MIN_VALUE
        for (j in 0 until n) {
            for (i in 0 until n) {
                val h = generator.surfaceHeight(x0 + (i - 1) * STEP, z0 + (j - 1) * STEP)
                heights[j * n + i] = h
                if (i in 1..VERTS && j in 1..VERTS) {
                    if (h < lowest) lowest = h
                    if (h > highest) highest = h
                }
            }
        }

        val water = lowest + 1f < WATER_TOP + 0.5f
        // A tile that is entirely under water needs no land mesh at all, just the sea quad.
        val land = highest + 1f > WATER_Y

        val landVerts = if (land) VERTS * VERTS else 0
        val waterVerts = if (water) 4 else 0
        val vertexData = FloatArray((landVerts + waterVerts) * MeshData.FLOATS_PER_VERTEX)
        val indices = IntArray((if (land) CELLS * CELLS * 6 else 0) + (if (water) 6 else 0))

        var minY = Float.MAX_VALUE
        var maxY = -Float.MAX_VALUE
        var vi = 0

        if (land) {
            val rampV = TextureAtlas.rampV()
            val span = 2f * STEP
            for (j in 0 until VERTS) {
                for (i in 0 until VERTS) {
                    val c = (j + 1) * n + (i + 1)
                    val h = heights[c]
                    val dhdx = (heights[c + 1] - heights[c - 1]) / span
                    val dhdz = (heights[c + n] - heights[c - n]) / span
                    val wx = x0 + i * STEP
                    val wz = z0 + j * STEP

                    val y = h + 0.75f // voxel top face is at h + 1; sit just under it
                    val t = rampIndex(wx, wz, h, dhdx, dhdz)

                    // Directional shading from the slope normal; flat ground ~= 1.0 like
                    // the top face of a voxel block, slopes facing away from the light darker.
                    val inv = 1f / sqrt(dhdx * dhdx + 1f + dhdz * dhdz)
                    val nx = -dhdx * inv
                    val ny = inv
                    val nz = -dhdz * inv
                    val lit = nx * LIGHT_X + ny * LIGHT_Y + nz * LIGHT_Z
                    val shade = (0.5f + 0.6f * max(0f, lit)).coerceAtMost(1f) * 0.97f

                    vertexData[vi++] = wx.toFloat()
                    vertexData[vi++] = y
                    vertexData[vi++] = wz.toFloat()
                    vertexData[vi++] = TextureAtlas.rampU(t)
                    vertexData[vi++] = rampV
                    vertexData[vi++] = shade
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                }
            }
        }

        var ii = 0
        if (land) {
            for (j in 0 until CELLS) {
                for (i in 0 until CELLS) {
                    val a = j * VERTS + i // (x0, z0)
                    val b = a + 1 // (x1, z0)
                    val d = a + VERTS // (x0, z1)
                    val c = d + 1 // (x1, z1)
                    // counter-clockwise seen from above, same as a voxel TOP face
                    indices[ii++] = a; indices[ii++] = c; indices[ii++] = b
                    indices[ii++] = a; indices[ii++] = d; indices[ii++] = c
                }
            }
        }

        if (water) {
            val base = landVerts
            val u = TextureAtlas.rampU(TextureAtlas.RAMP_WATER)
            val v = TextureAtlas.rampV()
            val xa = x0.toFloat()
            val xb = (x0 + TILE_BLOCKS).toFloat()
            val za = z0.toFloat()
            val zb = (z0 + TILE_BLOCKS).toFloat()
            val shade = 0.97f
            vertexData[vi++] = xa; vertexData[vi++] = WATER_Y; vertexData[vi++] = za; vertexData[vi++] = u; vertexData[vi++] = v; vertexData[vi++] = shade
            vertexData[vi++] = xb; vertexData[vi++] = WATER_Y; vertexData[vi++] = za; vertexData[vi++] = u; vertexData[vi++] = v; vertexData[vi++] = shade
            vertexData[vi++] = xb; vertexData[vi++] = WATER_Y; vertexData[vi++] = zb; vertexData[vi++] = u; vertexData[vi++] = v; vertexData[vi++] = shade
            vertexData[vi++] = xa; vertexData[vi++] = WATER_Y; vertexData[vi++] = zb; vertexData[vi++] = u; vertexData[vi++] = v; vertexData[vi] = shade
            indices[ii++] = base; indices[ii++] = base + 2; indices[ii++] = base + 1
            indices[ii++] = base; indices[ii++] = base + 3; indices[ii] = base + 2
            if (WATER_Y < minY) minY = WATER_Y
            if (WATER_Y > maxY) maxY = WATER_Y
        }

        val mesh = MeshData(vertexData, indices, landVerts + waterVerts, minY, maxY)
        return FarTile(tileKey(tx, tz), mesh, minY, maxY)
    }

    /** Position on the atlas colour ramp (see TextureAtlas): 0-2 sand, 3-7 grass (light to
     *  forest-dark), 8-10 dirt, 11-13 stone. Matches what the full-detail terrain shows:
     *  sand on the beach band, grass elsewhere, dirt/stone where the ground is steep. */
    private fun rampIndex(wx: Int, wz: Int, h: Int, dhdx: Float, dhdz: Float): Float {
        val sea = WorldConfig.SEA_LEVEL
        if (h >= sea - 1 && h <= sea + 2) {
            return if (h <= sea) 2f else if (h == sea + 1) 1f else 0f
        }
        if (h < sea - 1) return 2f // sea floor; hidden under the water quad anyway

        val patch = (0.5f + 0.25f * sin(wx * 0.043f + 1.7f) * cos(wz * 0.057f) + 0.25f * sin((wx + wz) * 0.021f))
            .coerceIn(0f, 1f)
        val forest = generator.forestFactor(wx, wz).toFloat()
        var t = 3.3f + patch * 2.0f + forest * 1.9f

        val slope = max(abs(dhdx), abs(dhdz))
        if (slope > 0.55f) {
            val k = ((slope - 0.55f) / 0.9f).coerceIn(0f, 1f)
            t += (9.3f - t) * k
            if (slope > 1.45f) {
                val k2 = ((slope - 1.45f) / 1.0f).coerceIn(0f, 1f)
                t += (12.2f - t) * k2
            }
        }
        return t
    }

    companion object {
        const val TILE_CHUNKS = 8
        const val TILE_BLOCKS = TILE_CHUNKS * WorldConfig.CHUNK_SIZE // 128

        /** Distance between vertices, in blocks. */
        const val STEP = 4
        const val CELLS = TILE_BLOCKS / STEP // 32
        const val VERTS = CELLS + 1 // 33

        /** Top surface of voxel water is SEA_LEVEL + 1; the far plane sits a touch under it
         *  so real water, where it exists, always wins the depth test. */
        const val WATER_TOP = WorldConfig.SEA_LEVEL + 1f
        const val WATER_Y = WATER_TOP - 0.2f

        private const val MAX_QUEUED_EVENTS = 24
        private const val REPLAN_DISTANCE = 24f

        // Fixed sun direction (normalised), used to shade slopes.
        private const val LIGHT_X = 0.35f
        private const val LIGHT_Y = 0.85f
        private const val LIGHT_Z = 0.39f

        fun tileKey(tx: Int, tz: Int): Long = (tx.toLong() shl 32) or (tz.toLong() and 0xFFFFFFFFL)
    }
}
