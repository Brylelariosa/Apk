package com.outcrop.app.navigation

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.weight
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.outcrop.core.designsystem.NavDestination
import com.outcrop.core.designsystem.OutcropBottomNav
import com.outcrop.feature.chat.ChatScreen
import com.outcrop.feature.diagnostics.DiagnosticsScreen
import com.outcrop.feature.discoverycenter.DiscoveryCenterScreen
import com.outcrop.feature.learningdashboard.LearningDashboardScreen
import com.outcrop.feature.memoryexplorer.MemoryExplorerScreen
import com.outcrop.feature.onboarding.WelcomeScreen
import com.outcrop.feature.settings.SettingsScreen

private object Routes {
    const val WELCOME = "welcome"
    const val CHAT = "chat"
    const val MEMORY = "memory"
    const val LEARN = "learn"
    const val DISCOVER = "discover"
    const val DIAGNOSTICS = "diagnostics"
    const val SETTINGS = "settings"
    // Knowledge Graph is specified in the app spec S2 but not wired here
    // yet -- its module exists and builds independently. A dedicated
    // Data I/O screen (real file picker/share sheet) also remains future
    // work; basic export/import lives inside Settings for now.
}

private val mainDestinations = listOf(
    NavDestination(Routes.CHAT, "Chat"),
    NavDestination(Routes.MEMORY, "Memory"),
    NavDestination(Routes.LEARN, "Learn"),
    NavDestination(Routes.DISCOVER, "Discover"),
    NavDestination(Routes.DIAGNOSTICS, "Insights"),
    NavDestination(Routes.SETTINGS, "Settings")
)

@Composable
fun OutcropNavHost(navController: NavHostController = rememberNavController()) {
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    // Bottom nav is hidden on Welcome (a first-run intro, not part of the
    // main app shell) and shown everywhere else.
    Column(modifier = Modifier.fillMaxSize()) {
        Box(modifier = Modifier.weight(1f)) {
            NavHost(navController = navController, startDestination = Routes.WELCOME) {
                composable(Routes.WELCOME) {
                    WelcomeScreen(onContinue = {
                        navController.navigate(Routes.CHAT) {
                            popUpTo(Routes.WELCOME) { inclusive = true }
                        }
                    })
                }
                composable(Routes.CHAT) { ChatScreen() }
                composable(Routes.MEMORY) { MemoryExplorerScreen() }
                composable(Routes.LEARN) { LearningDashboardScreen() }
                composable(Routes.DISCOVER) { DiscoveryCenterScreen() }
                composable(Routes.DIAGNOSTICS) { DiagnosticsScreen() }
                composable(Routes.SETTINGS) { SettingsScreen() }
            }
        }
        if (currentRoute != null && currentRoute != Routes.WELCOME) {
            OutcropBottomNav(
                destinations = mainDestinations,
                currentRoute = currentRoute,
                onNavigate = { route ->
                    navController.navigate(route) {
                        popUpTo(navController.graph.startDestinationId) { saveState = true }
                        launchSingleTop = true
                        restoreState = true
                    }
                }
            )
        }
    }
}
