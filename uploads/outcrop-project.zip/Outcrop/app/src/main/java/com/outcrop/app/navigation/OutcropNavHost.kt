package com.outcrop.app.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.outcrop.feature.chat.ChatScreen
import com.outcrop.feature.onboarding.WelcomeScreen

private object Routes {
    const val WELCOME = "welcome"
    const val CHAT = "chat"
    // Knowledge Graph, Discovery Center, Learning Dashboard, Diagnostics,
    // Settings, and Data I/O are specified in the Outcrop app spec §2 but
    // not yet wired here. Their modules exist and build independently —
    // see settings.gradle.kts and the stub modules under feature/.
}

@Composable
fun OutcropNavHost(navController: NavHostController = rememberNavController()) {
    NavHost(navController = navController, startDestination = Routes.WELCOME) {
        composable(Routes.WELCOME) {
            WelcomeScreen(onContinue = { navController.navigate(Routes.CHAT) })
        }
        composable(Routes.CHAT) {
            ChatScreen()
        }
    }
}
