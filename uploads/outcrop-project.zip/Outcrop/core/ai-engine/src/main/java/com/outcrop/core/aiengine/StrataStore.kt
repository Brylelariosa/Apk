package com.outcrop.core.aiengine

import java.time.LocalDate
import kotlin.math.exp

private const val MERGE_THRESHOLD = 0.55
private const val CEMENT_CONFIDENCE = 0.75
private const val MIN_EVIDENCE = 3.0
private const val CORRECTION_AUTHORITY = 3.0
private const val DORMANT_FLOOR = 0.05
private const val MIN_RULE_INSTANCES = 3

/**
 * The real Strata learning loop, in-memory. This logic was written and
 * verified as a Java port first (compiled and run outside Android -- no
 * Kotlin toolchain was available to test this file directly) before being
 * translated here; the translation preserves that verified behavior
 * rather than introducing new untested logic in a less forgiving runtime.
 *
 * Known simplifications vs the full Strata V1/V2 spec:
 *  - In-memory only. No mmap/tiered binary storage (V1 S6) yet.
 *  - crystallize() finds single-relation majority-object rules, not the
 *    full cross-relation Category Induction (V2 S4.4).
 *  - simulate() does single-hop rule application, not bounded multi-hop
 *    frontier expansion (V2 S4.8).
 *  - No Twin-Axis Placement, Undertow scheduling, Combinator Evolution,
 *    Curiosity Sweep, or Fault Attribution yet -- those remain design,
 *    not code, for now.
 */
class StrataStore {
    private val grains = linkedMapOf<Int, Grain>()
    private var nextId = 1

    fun allGrains(): List<Grain> = grains.values.toList()

    fun ingest(subject: String, relation: String, obj: String, authorityWeight: Double = 1.0): IngestResult {
        val sig = Resonance.encode(subject, relation, obj)
        val today = LocalDate.now().toEpochDay()

        // Primary match: EXACT (subject, relation) identity -- ground truth,
        // not an estimate, so it always qualifies as a reinforce/arbitrate
        // candidate regardless of resonance similarity. (Found during testing:
        // relying on vector similarity alone here could let same-subject-
        // same-relation contradictions slip past on vector-distance
        // coincidence -- this two-tier structure closes that gap.)
        val exactMatch = grains.values.firstOrNull {
            it.subject.equals(subject, ignoreCase = true) && it.relation.equals(relation, ignoreCase = true)
        }

        if (exactMatch != null) {
            return if (exactMatch.obj.equals(obj, ignoreCase = true)) {
                reinforce(exactMatch, authorityWeight, today)
                IngestResult.Reinforced(exactMatch)
            } else {
                arbitrate(exactMatch, subject, relation, obj, sig, authorityWeight, today)
            }
        }

        // Secondary match: fuzzy resonance similarity, for near-duplicates
        // when subject/relation strings aren't identical.
        val best = grains.values.maxByOrNull { Resonance.similarity(it.signature, sig) }
        if (best != null && Resonance.similarity(best.signature, sig) > MERGE_THRESHOLD &&
            best.subject.equals(subject, ignoreCase = true) && best.obj.equals(obj, ignoreCase = true)
        ) {
            reinforce(best, authorityWeight, today)
            return IngestResult.Reinforced(best)
        }

        val grain = Grain(
            id = nextId++, subject = subject, relation = relation, obj = obj,
            lastTouchedEpochDay = today, signature = sig
        )
        grain.touchedDays.add(today)
        grains[grain.id] = grain
        return IngestResult.Created(grain)
    }

    private fun reinforce(grain: Grain, weight: Double, today: Long) {
        grain.alpha += weight
        grain.vitality = minOf(1.0, grain.vitality + 0.2)
        grain.lastTouchedEpochDay = today
        grain.touchedDays.add(today)
        if (grain.tier == Tier.SEED && meetsCementation(grain)) grain.tier = Tier.LATTICE
    }

    /** Requires evidence spread across >=2 distinct days on purpose, so one
     *  enthusiastic session can't over-commit a fact (Strata V1 S4). */
    private fun meetsCementation(grain: Grain): Boolean =
        grain.confidence() >= CEMENT_CONFIDENCE &&
            grain.touchedDays.size >= 2 &&
            (grain.alpha + grain.beta) >= MIN_EVIDENCE

    private fun arbitrate(
        existing: Grain, subject: String, relation: String, obj: String,
        sig: TritVector, weight: Double, today: Long
    ): IngestResult {
        return if (weight >= CORRECTION_AUTHORITY) {
            existing.beta += weight
            val challenger = Grain(
                id = nextId++, subject = subject, relation = relation, obj = obj,
                alpha = weight, lastTouchedEpochDay = today, signature = sig
            )
            challenger.touchedDays.add(today)
            grains[challenger.id] = challenger
            IngestResult.Disputed(existing, challenger, resolved = true)
        } else {
            existing.beta += weight * 0.5
            IngestResult.Disputed(existing, null, resolved = false)
        }
    }

    /** Keyword-overlap x confidence ranking -- NOT semantic search. The
     *  resonance vectors here support structural similarity between
     *  stored triples (used above, in ingest's dedup check), not
     *  open-ended free-text understanding, which would need a real
     *  embedding model this reference implementation doesn't include. */
    fun query(text: String, k: Int = 5): List<Grain> {
        val tokens = text.lowercase().split(Regex("\\W+")).filter { it.length > 2 }
        return grains.values
            .filter { it.tier != Tier.DORMANT }
            .map { grain ->
                val haystack = "${grain.subject} ${grain.relation} ${grain.obj}".lowercase()
                val matches = tokens.count { haystack.contains(it) }
                grain to matches * grain.confidence()
            }
            .filter { it.second > 0 }
            .sortedByDescending { it.second }
            .take(k)
            .map { it.first }
    }

    /** Two-stage decay: SEED tier fades fastest, LATTICE slower -- crossing
     *  DORMANT_FLOOR moves a grain to Tier.DORMANT rather than deleting it
     *  outright (Strata V1 S9 Weathering). True deletion isn't implemented
     *  in this reference pass. */
    fun weatherTick() {
        val today = LocalDate.now().toEpochDay()
        for (g in grains.values) {
            val age = today - g.lastTouchedEpochDay
            val decay = if (g.tier == Tier.LATTICE) 0.02 else 0.08
            g.vitality *= exp(-decay * age)
            if (g.vitality < DORMANT_FLOOR) g.tier = Tier.DORMANT
        }
    }

    /** Simplified rule induction: within one relation, if enough distinct
     *  subjects confidently share the same object, propose a rule. Not the
     *  full cross-relation Category Induction from Strata V2 S4.4. */
    fun crystallize(): List<Grain> {
        val newRules = mutableListOf<Grain>()
        val byRelation = grains.values.filter { it.type == GrainType.FACT }.groupBy { it.relation }
        for ((relation, members) in byRelation) {
            val (topObject, group) = members.groupBy { it.obj }.maxByOrNull { it.value.size } ?: continue
            if (group.size >= MIN_RULE_INSTANCES && group.all { it.confidence() > 0.6 }) {
                val today = LocalDate.now().toEpochDay()
                val rule = Grain(
                    id = nextId++, subject = "*", relation = relation, obj = topObject,
                    alpha = group.size.toDouble(), beta = 1.0,
                    lastTouchedEpochDay = today, signature = Resonance.encode("*", relation, topObject),
                    type = GrainType.RULE, tier = Tier.LATTICE
                )
                rule.touchedDays.add(today)
                grains[rule.id] = rule
                newRules.add(rule)
            }
        }
        return newRules
    }

    /** Single-hop rule application. Returns a DERIVED grain, marked
     *  GrainType.HYPOTHESIS with derivedFromRuleId set -- never silently
     *  conflated with an observed fact (the provenance discipline Strata
     *  V2 S4.8's Simulation Engine requires). Real bounded multi-hop
     *  frontier expansion is not implemented in this reference pass. */
    fun simulate(subject: String, relation: String): Grain? {
        val rule = grains.values.firstOrNull {
            it.type == GrainType.RULE && it.relation.equals(relation, ignoreCase = true) &&
                (it.subject == "*" || it.subject.equals(subject, ignoreCase = true))
        } ?: return null

        val conf = rule.confidence()
        return Grain(
            id = -1, subject = subject, relation = relation, obj = rule.obj,
            alpha = conf, beta = 1 - conf,
            lastTouchedEpochDay = LocalDate.now().toEpochDay(), signature = rule.signature,
            type = GrainType.HYPOTHESIS, tier = Tier.SEED, derivedFromRuleId = rule.id
        )
    }
}
