package com.outcrop.core.aiengine

/**
 * Toy pattern-based extraction. This is deliberately NOT real NLU --
 * Strata V2 S4.3 (Fault Attribution) exists specifically because this
 * pipeline stage is unreliable, and a phone-sized on-device model is
 * meaningfully weaker at this than a large cloud model. This is a
 * stand-in that makes the ingest pipeline demonstrable end to end, not a
 * solved extraction problem. Single-word subjects only -- "tom likes
 * kotlin" works, "my favorite language is kotlin" does not.
 */
object Prospector {
    private val patterns: List<Pair<Regex, (MatchResult) -> Triple<String, String, String>>> = listOf(
        Regex("(?i)^my (\\w+) is (.+)$") to { m -> Triple("user", m.groupValues[1], m.groupValues[2].trim()) },
        Regex("(?i)^(\\w+) likes (.+)$") to { m -> Triple(m.groupValues[1], "likes", m.groupValues[2].trim()) },
        Regex("(?i)^(\\w+) chases (.+)$") to { m -> Triple(m.groupValues[1], "chases", m.groupValues[2].trim()) },
        Regex("(?i)^(\\w+) lives ?in (.+)$") to { m -> Triple(m.groupValues[1], "livesIn", m.groupValues[2].trim()) },
        Regex("(?i)^(\\w+) is (.+)$") to { m -> Triple(m.groupValues[1], "is", m.groupValues[2].trim()) }
    )

    fun extract(text: String): List<Triple<String, String, String>> {
        val trimmed = text.trim()
        for ((pattern, extractor) in patterns) {
            pattern.find(trimmed)?.let { return listOf(extractor(it)) }
        }
        return emptyList()
    }
}
