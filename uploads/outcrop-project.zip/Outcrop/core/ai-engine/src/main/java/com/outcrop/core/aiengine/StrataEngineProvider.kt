package com.outcrop.core.aiengine

/**
 * Shared StrataEngine instance so Chat, Memory Explorer, and Diagnostics
 * all see the same in-memory grains instead of each screen's ViewModel
 * quietly spinning up its own isolated engine. Without this, Memory
 * Explorer would show an empty store no matter what got ingested in Chat
 * -- caught before shipping any of the new screens, not after.
 *
 * A proper DI setup (Hilt) is the natural next step once there are more
 * shared dependencies to justify introducing that machinery -- this is
 * the minimal thing that's actually correct today.
 */
object StrataEngineProvider {
    val engine: StrataEngine by lazy { StrataEngine() }
}
