package com.outcrop.core.designsystem

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

data class OutcropColors(
    val background: Color,
    val strataDark: Color
)

val LocalOutcropColors = staticCompositionLocalOf {
    OutcropColors(background = OutcropPalette.Surface, strataDark = OutcropPalette.StrataDark)
}

/**
 * Root theme composable. Deliberately does NOT wrap MaterialTheme —
 * see spec §3: no Material3 widgets anywhere in this app. Every screen
 * builds on Compose Foundation primitives plus these tokens directly.
 */
@Composable
fun OutcropTheme(content: @Composable () -> Unit) {
    val colors = OutcropColors(
        background = OutcropPalette.Surface,
        strataDark = OutcropPalette.StrataDark
    )
    CompositionLocalProvider(LocalOutcropColors provides colors) {
        content()
    }
}
