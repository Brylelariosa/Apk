package com.outcrop.feature.onboarding

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.outcrop.core.designsystem.OutcropPalette

/** First-run screen (app spec §2.2, §5). Real Compose Foundation UI, no
 *  Material3 — matches the "no generic Material look" design constraint. */
@Composable
fun WelcomeScreen(onContinue: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(OutcropPalette.Surface),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            BasicText(text = "Outcrop")
            Spacer(modifier = Modifier.height(16.dp))
            Box(
                modifier = Modifier
                    .background(OutcropPalette.StrataBand2)
                    .clickable { onContinue() }
                    .padding(horizontal = 24.dp, vertical = 12.dp)
            ) {
                BasicText(text = "Get started")
            }
        }
    }
}
