package com.outcrop.feature.discoverycenter

// Placeholder module -- see app spec S4.4.
// Not yet implemented. Exists so the module graph matches the designed
// architecture and the project builds as a whole (settings.gradle.kts
// includes this module; ./gradlew assembleDebug touches every module).
object DiscoveryCenterPlaceholder
