package com.outcrop.feature.chat

import androidx.lifecycle.ViewModel
import com.outcrop.core.aiengine.EngineSnapshot
import com.outcrop.core.aiengine.IngestResult
import com.outcrop.core.aiengine.Prospector
import com.outcrop.core.aiengine.StrataEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

data class ChatMessage(
    val id: String,
    val isUser: Boolean,
    val text: String,
    val grainCount: Int = 0
)

/**
 * Wires real Strata ingest/retrieval into the chat loop (app spec S4.1).
 * There is still no base LLM here -- Strata V1 S0 is explicit that Strata
 * is the memory/reasoning layer, not the language model, and that hasn't
 * changed. What you type gets genuinely extracted (see Prospector),
 * deduplicated, confidence-scored, and stored; the "response" is a
 * transparent readout of what the memory system actually did, not a
 * simulated conversation.
 */
class ChatViewModel : ViewModel() {
    private val engine = StrataEngine()

    private val _messages = MutableStateFlow(
        listOf(
            ChatMessage(
                id = "intro", isUser = false,
                text = "Try \"max chases ball\" a few times, \"my favorite language is kotlin\", " +
                    "or \"tom doesn't like java\" -- multi-word subjects and negation both work " +
                    "now. I'll show exactly what gets learned, reinforced, or disputed."
            )
        )
    )
    val messages: StateFlow<List<ChatMessage>> = _messages

    private val _telemetry = MutableStateFlow(EngineSnapshot(0, 0, 0))
    val telemetry: StateFlow<EngineSnapshot> = _telemetry

    fun send(text: String) {
        if (text.isBlank()) return
        appendMessage(isUser = true, text = text)

        val triples = Prospector.extract(text)
        val ingestNotes = triples.map { (s, r, o) ->
            when (val result = engine.ingest(s, r, o)) {
                is IngestResult.Created ->
                    "learned: $s $r $o (conf ${format(result.grain.confidence())})"
                is IngestResult.Reinforced ->
                    "reinforced: $s $r $o (conf ${format(result.grain.confidence())})"
                is IngestResult.Disputed ->
                    if (result.resolved) "correction accepted for $s $r"
                    else "noted a conflict on $s $r — not enough authority to override yet"
            }
        }

        val related = engine.query(text, k = 3)
        val newRules = engine.crystallize()
        engine.weatherTick()

        val response = buildString {
            append(
                if (ingestNotes.isEmpty())
                    "Didn't extract a clear fact from that — try a short \"X verb Y\" sentence."
                else ingestNotes.joinToString("; ")
            )
            if (newRules.isNotEmpty()) {
                append(". New rule crystallized: * ${newRules.first().relation} ${newRules.first().obj}")
            }
            if (related.isNotEmpty()) {
                append(". Related in memory: ")
                append(related.joinToString("; ") { "${it.subject} ${it.relation} ${it.obj} (${format(it.confidence())})" })
            }
        }

        appendMessage(isUser = false, text = response, grainCount = related.size)
        _telemetry.value = engine.telemetry()
    }

    private fun appendMessage(isUser: Boolean, text: String, grainCount: Int = 0) {
        _messages.value = _messages.value + ChatMessage(
            id = (_messages.value.size + 1).toString(), isUser = isUser, text = text, grainCount = grainCount
        )
    }

    private fun format(v: Double) = "%.2f".format(v)
}
