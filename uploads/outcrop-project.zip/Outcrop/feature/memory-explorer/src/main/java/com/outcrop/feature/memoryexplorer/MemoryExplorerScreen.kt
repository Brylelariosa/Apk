package com.outcrop.feature.memoryexplorer

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.outcrop.core.aiengine.Grain
import com.outcrop.core.aiengine.GrainType
import com.outcrop.core.aiengine.Tier
import com.outcrop.core.designsystem.OutcropPalette

/** Browse every ingested Grain (app spec S4.5). Tapping a row expands it
 *  inline into a minimal Grain Inspector rather than a separate detail
 *  screen, to keep this round's scope real and finishable. */
@Composable
fun MemoryExplorerScreen(viewModel: MemoryExplorerViewModel = viewModel()) {
    val grains by viewModel.grains.collectAsState()
    val filter by viewModel.filter.collectAsState()
    var expandedId by remember { mutableStateOf<Int?>(null) }

    val visible = grains.filter { filter == null || it.type == filter }

    Column(modifier = Modifier.fillMaxSize()) {
        FilterRow(current = filter, onSelect = viewModel::setFilter)

        if (visible.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize().padding(24.dp)) {
                BasicText(
                    text = "Nothing here yet. Ingest something in Chat, then come back " +
                        "and tap Refresh below."
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(visible, key = { it.id }) { grain ->
                    GrainRow(
                        grain = grain,
                        expanded = expandedId == grain.id,
                        onToggle = { expandedId = if (expandedId == grain.id) null else grain.id }
                    )
                }
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(OutcropPalette.StrataDark)
                .clickable { viewModel.refresh() }
                .padding(12.dp)
        ) {
            BasicText(text = "Refresh (${visible.size} shown / ${grains.size} total)")
        }
    }
}

@Composable
private fun FilterRow(current: GrainType?, onSelect: (GrainType?) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(12.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        FilterChip("All", current == null) { onSelect(null) }
        FilterChip("Facts", current == GrainType.FACT) { onSelect(GrainType.FACT) }
        FilterChip("Rules", current == GrainType.RULE) { onSelect(GrainType.RULE) }
        FilterChip("Hypotheses", current == GrainType.HYPOTHESIS) { onSelect(GrainType.HYPOTHESIS) }
    }
}

@Composable
private fun FilterChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .background(if (selected) OutcropPalette.StrataBand2 else OutcropPalette.StrataBand3)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        BasicText(text = label)
    }
}

@Composable
private fun GrainRow(grain: Grain, expanded: Boolean, onToggle: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(tierColor(grain.tier))
            .clickable(onClick = onToggle)
            .padding(12.dp)
    ) {
        BasicText(text = "${grain.subject} ${grain.relation} ${grain.obj}")
        BasicText(text = "conf ${"%.2f".format(grain.confidence())} \u00b7 ${grain.tier} \u00b7 ${grain.type}")
        if (expanded) {
            Spacer(modifier = Modifier.height(6.dp))
            BasicText(
                text = "alpha=${"%.1f".format(grain.alpha)}  beta=${"%.1f".format(grain.beta)}  " +
                    "vitality=${"%.3f".format(grain.vitality)}"
            )
            BasicText(text = "touched on ${grain.touchedDays.size} distinct day(s)")
            grain.derivedFromRuleId?.let {
                BasicText(text = "derived from rule #$it \u2014 not directly observed")
            }
        }
    }
}

private fun tierColor(tier: Tier) = when (tier) {
    Tier.SEED -> OutcropPalette.StrataBand3
    Tier.LATTICE -> OutcropPalette.StrataBand1
    Tier.DORMANT -> OutcropPalette.StrataDark
}
