package com.outcrop.feature.memoryexplorer

// Placeholder module -- see app spec S4.5.
// Not yet implemented. Exists so the module graph matches the designed
// architecture and the project builds as a whole (settings.gradle.kts
// includes this module; ./gradlew assembleDebug touches every module).
object MemoryExplorerPlaceholder
