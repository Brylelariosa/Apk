package com.outcrop.feature.settings

// Placeholder module -- see app spec S1.8.
// Not yet implemented. Exists so the module graph matches the designed
// architecture and the project builds as a whole (settings.gradle.kts
// includes this module; ./gradlew assembleDebug touches every module).
object SettingsPlaceholder
