package com.outcrop.feature.learningdashboard

// Placeholder module -- see app spec S4.6.
// Not yet implemented. Exists so the module graph matches the designed
// architecture and the project builds as a whole (settings.gradle.kts
// includes this module; ./gradlew assembleDebug touches every module).
object LearningDashboardPlaceholder
