package com.voxelsandbox.game.settings

import android.content.Context
import android.content.SharedPreferences

/** [resolutionScale] is Graphics Quality's actual lever: the GL surface renders at
 *  this fraction of the physical display and the compositor upscales it (see
 *  GameActivity.applyResolutionScale). Roughly halving pixel count per step because
 *  fragment/fill-rate cost is the dominant GPU cost on the low-end targets this game
 *  runs on — the block textures and shader are already about as cheap as they get
 *  (small 16px tiles, one texture fetch per pixel; see TextureAtlas), so resolution is
 *  what's left to cut. */
enum class GraphicsQuality(val label: String, val resolutionScale: Float) {
    LOW("Low", 0.65f), MEDIUM("Medium", 0.85f), HIGH("High", 1.0f);

    companion object {
        fun fromOrdinalSafe(i: Int): GraphicsQuality = values().getOrElse(i) { MEDIUM }
    }
}

/**
 * Thin SharedPreferences wrapper. Values load once into memory at construction;
 * WorldManager/GameEngine read the in-memory fields every frame (no disk I/O in the
 * hot path). [persist] writes them back and is only called when the player taps
 * Apply in the settings screen.
 */
class GameSettings(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("voxel_settings", Context.MODE_PRIVATE)

    /** How far the world is drawn, in chunks (16 blocks each). With [farTerrain] on, the
     *  part beyond [detailDistanceChunks] is a cheap distant-terrain mesh, so this can be
     *  far larger than the number of full voxel chunks the device could ever hold. */
    var renderDistanceChunks: Int =
        prefs.getInt(KEY_RENDER_CHUNKS, DEFAULT_RENDER_CHUNKS).coerceIn(MIN_RENDER_CHUNKS, MAX_RENDER_CHUNKS)

    /** Radius (chunks) of full-detail, textured, editable voxel terrain around the player
     *  (the memory budget in WorldManager may still hold it back on a small-heap device). */
    var detailDistanceChunks: Int = loadDetailDistance()

    /** Version 9 moved the default from [OLD_DEFAULT_DETAIL_CHUNKS] out to
     *  [DEFAULT_DETAIL_CHUNKS] (the distant terrain started too close). A saved value equal
     *  to the old default is almost certainly "never touched", so it follows the new default,
     *  once: [persist] records that the migration is done, after which any value the player
     *  picks, including 16, is kept as chosen. */
    private fun loadDetailDistance(): Int {
        val stored = prefs.getInt(KEY_DETAIL_CHUNKS, DEFAULT_DETAIL_CHUNKS)
        val migrated = prefs.getBoolean(KEY_DETAIL_MIGRATED, false)
        val value = if (!migrated && stored == OLD_DEFAULT_DETAIL_CHUNKS) DEFAULT_DETAIL_CHUNKS else stored
        return value.coerceIn(MIN_DETAIL_CHUNKS, MAX_DETAIL_CHUNKS)
    }

    /** Draws a low-detail heightfield out to the render distance, past the voxel chunks. */
    var farTerrain: Boolean = prefs.getBoolean(KEY_FAR_TERRAIN, true)

    var graphicsQuality: GraphicsQuality =
        GraphicsQuality.fromOrdinalSafe(prefs.getInt(KEY_GRAPHICS_QUALITY, GraphicsQuality.MEDIUM.ordinal))
    var showFps: Boolean = prefs.getBoolean(KEY_SHOW_FPS, false)
    var touchSensitivity: Float = prefs.getFloat(KEY_TOUCH_SENS, 0.5f)
    var lookSensitivity: Float = prefs.getFloat(KEY_LOOK_SENS, 0.5f)
    var viewBobbing: Boolean = prefs.getBoolean(KEY_BOBBING, true)
    var cloudsEnabled: Boolean = prefs.getBoolean(KEY_CLOUDS, true)
    var particlesEnabled: Boolean = prefs.getBoolean(KEY_PARTICLES, true)
    var autoJump: Boolean = prefs.getBoolean(KEY_AUTO_JUMP, true)

    /** Creative mode: free flight (double-tap jump toggles it), unlimited blocks and the
     *  destroy laser, for testing and fast travel. */
    var creativeMode: Boolean = prefs.getBoolean(KEY_CREATIVE, false)

    /** Creative flight speed in blocks per second. */
    var flySpeed: Float = prefs.getFloat(KEY_FLY_SPEED, DEFAULT_FLY_SPEED).coerceIn(MIN_FLY_SPEED, MAX_FLY_SPEED)

    /** Auto-tunes fog/draw distance: only ever pulls it in (down to 65%) while the frame
     *  rate is low, and gives it back as soon as there's headroom. See GameRenderer. */
    var adaptiveDistance: Boolean = prefs.getBoolean(KEY_ADAPTIVE_DISTANCE, true)

    /** Radius (chunks) of real voxel chunks to keep loaded. Without the distant terrain
     *  the voxel chunks have to reach the whole render distance themselves (still capped by
     *  the memory budget in WorldManager). */
    fun nearChunks(): Int =
        if (farTerrain) minOf(detailDistanceChunks, renderDistanceChunks) else renderDistanceChunks

    fun persist() {
        prefs.edit()
            .putInt(KEY_RENDER_CHUNKS, renderDistanceChunks)
            .putInt(KEY_DETAIL_CHUNKS, detailDistanceChunks)
            .putBoolean(KEY_DETAIL_MIGRATED, true)
            .putBoolean(KEY_FAR_TERRAIN, farTerrain)
            .putInt(KEY_GRAPHICS_QUALITY, graphicsQuality.ordinal)
            .putBoolean(KEY_SHOW_FPS, showFps)
            .putFloat(KEY_TOUCH_SENS, touchSensitivity)
            .putFloat(KEY_LOOK_SENS, lookSensitivity)
            .putBoolean(KEY_BOBBING, viewBobbing)
            .putBoolean(KEY_CLOUDS, cloudsEnabled)
            .putBoolean(KEY_PARTICLES, particlesEnabled)
            .putBoolean(KEY_AUTO_JUMP, autoJump)
            .putBoolean(KEY_CREATIVE, creativeMode)
            .putFloat(KEY_FLY_SPEED, flySpeed)
            .putBoolean(KEY_ADAPTIVE_DISTANCE, adaptiveDistance)
            .apply()
    }

    companion object {
        // (The old "render_distance" key stored a preset index; it is simply ignored now.)
        private const val KEY_RENDER_CHUNKS = "render_distance_chunks"
        private const val KEY_DETAIL_CHUNKS = "detail_distance_chunks"
        private const val KEY_DETAIL_MIGRATED = "detail_default_v9"
        private const val KEY_FAR_TERRAIN = "far_terrain"

        const val MIN_RENDER_CHUNKS = 4
        const val MAX_RENDER_CHUNKS = 400
        const val DEFAULT_RENDER_CHUNKS = 64
        const val MIN_DETAIL_CHUNKS = 4
        const val MAX_DETAIL_CHUNKS = 300
        const val DEFAULT_DETAIL_CHUNKS = 20

        /** Resolution of the two distance sliders (see [renderFromSlider]). */
        const val DISTANCE_SLIDER_STEPS = 1000

        /** Slider position -> render distance in chunks. The scale is quadratic, so the low
         *  end (where each chunk matters) stays finely adjustable while the whole range up to
         *  [MAX_RENDER_CHUNKS] fits on one slider; large values snap to 2 / 5 / 10 chunks. */
        fun renderFromSlider(progress: Int): Int = fromSlider(progress, MIN_RENDER_CHUNKS, MAX_RENDER_CHUNKS)

        fun renderToSlider(chunks: Int): Int = toSlider(chunks, MIN_RENDER_CHUNKS, MAX_RENDER_CHUNKS)

        /** Slider position -> detail distance in chunks (same scale, up to [MAX_DETAIL_CHUNKS]). */
        fun detailFromSlider(progress: Int): Int = fromSlider(progress, MIN_DETAIL_CHUNKS, MAX_DETAIL_CHUNKS)

        fun detailToSlider(chunks: Int): Int = toSlider(chunks, MIN_DETAIL_CHUNKS, MAX_DETAIL_CHUNKS)

        private fun fromSlider(progress: Int, min: Int, max: Int): Int {
            val t = progress.coerceIn(0, DISTANCE_SLIDER_STEPS) / DISTANCE_SLIDER_STEPS.toDouble()
            val raw = min + (max - min) * t * t
            val step = if (raw >= 200.0) 10 else if (raw >= 100.0) 5 else if (raw >= 40.0) 2 else 1
            val snapped = Math.round(raw / step).toInt() * step
            return snapped.coerceIn(min, max)
        }

        private fun toSlider(value: Int, min: Int, max: Int): Int {
            val fraction = (value - min).coerceAtLeast(0).toDouble() / (max - min).toDouble()
            return Math.round(Math.sqrt(fraction) * DISTANCE_SLIDER_STEPS).toInt().coerceIn(0, DISTANCE_SLIDER_STEPS)
        }
        private const val OLD_DEFAULT_DETAIL_CHUNKS = 16
        const val MIN_FLY_SPEED = 8f
        const val MAX_FLY_SPEED = 200f
        const val DEFAULT_FLY_SPEED = 30f
        private const val KEY_CREATIVE = "creative_mode"
        private const val KEY_FLY_SPEED = "fly_speed"
        private const val KEY_GRAPHICS_QUALITY = "graphics_quality"
        private const val KEY_SHOW_FPS = "show_fps"
        private const val KEY_TOUCH_SENS = "touch_sensitivity"
        private const val KEY_LOOK_SENS = "look_sensitivity"
        private const val KEY_BOBBING = "view_bobbing"
        private const val KEY_CLOUDS = "clouds"
        private const val KEY_PARTICLES = "particles"
        private const val KEY_AUTO_JUMP = "auto_jump"
        private const val KEY_ADAPTIVE_DISTANCE = "adaptive_distance"
    }
}
