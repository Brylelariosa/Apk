package com.voxelsandbox.game.gl

import android.opengl.GLES30
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * The water tile: 16x16 pixel art in four blues with a few light flecks, in the same style as
 * the block textures. It is baked below (a palette plus 16 rows of palette digits), periodic in
 * both directions so the shader can scroll it freely, and low in contrast so that one repeat
 * per block never reads as a grid. Its average colour is what the water shader fades to far
 * away (see Shaders.WATER_FRAGMENT).
 *
 * Nearest-texel magnification (crisp square pixels up close) with trilinear mip-mapping in the
 * distance, where the pattern smoothly averages out instead of aliasing.
 */
class WaterTexture {
    private var textureId = 0

    fun upload() {
        val ids = IntArray(1)
        GLES30.glGenTextures(1, ids, 0)
        textureId = ids[0]
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textureId)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR_MIPMAP_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_NEAREST)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_REPEAT)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_REPEAT)

        val buf = ByteBuffer.allocateDirect(SIZE * SIZE * 4).order(ByteOrder.nativeOrder())
        buf.put(generate())
        buf.position(0)
        GLES30.glTexImage2D(
            GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGBA, SIZE, SIZE, 0,
            GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, buf
        )
        GLES30.glGenerateMipmap(GLES30.GL_TEXTURE_2D)
        enableAnisotropy()
    }

    fun bind(unit: Int) {
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0 + unit)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textureId)
    }

    /** RGBA bytes of the tile, row by row (alpha is always 255; the shader sets its own). */
    private fun generate(): ByteArray {
        val parts = PALETTE.split(' ')
        val r = IntArray(parts.size)
        val g = IntArray(parts.size)
        val b = IntArray(parts.size)
        for (i in parts.indices) {
            val rgb = parts[i].toInt(16)
            r[i] = (rgb shr 16) and 0xFF
            g[i] = (rgb shr 8) and 0xFF
            b[i] = rgb and 0xFF
        }
        val out = ByteArray(SIZE * SIZE * 4)
        for (i in 0 until SIZE * SIZE) {
            val ch = if (i < ROWS.length) ROWS[i] else '0'
            var d = if (ch <= '9') ch - '0' else ch - 'a' + 10
            if (d < 0 || d >= parts.size) d = 0
            out[i * 4] = r[d].toByte()
            out[i * 4 + 1] = g[d].toByte()
            out[i * 4 + 2] = b[d].toByte()
            out[i * 4 + 3] = 255.toByte()
        }
        return out
    }

    /** A little anisotropy keeps the water from smearing at grazing angles; skipped silently
     *  where the driver does not offer it. */
    private fun enableAnisotropy() {
        try {
            val extensions = GLES30.glGetString(GLES30.GL_EXTENSIONS) ?: return
            if (!extensions.contains("GL_EXT_texture_filter_anisotropic")) return
            val limit = FloatArray(1)
            GLES30.glGetFloatv(GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT, limit, 0)
            if (limit[0] > 1f) {
                GLES30.glTexParameterf(GLES30.GL_TEXTURE_2D, GL_TEXTURE_MAX_ANISOTROPY_EXT, minOf(ANISOTROPY, limit[0]))
            }
        } catch (t: Throwable) {
            // purely cosmetic; ignore
        }
    }

    private companion object {
        const val SIZE = 16

        /** Blues, dark to light, as RRGGBB. */
        const val PALETTE = "3a72cf 467fd8 5590e0 78aaea"

        /** SIZE * SIZE palette digits, row by row. */
        const val ROWS =
        "1121210100111111" +
        "1212211000010111" +
        "2111111111010111" +
        "3211221111110113" +
        "1112122221100111" +
        "2111111212111012" +
        "1111111122111111" +
        "1331111131111111" +
        "1111011112111111" +
        "1111331111112111" +
        "0110111111112111" +
        "0000011011111110" +
        "0000010101122110" +
        "0001101100112210" +
        "1001111100111111" +
        "3111111000011111"

        const val GL_TEXTURE_MAX_ANISOTROPY_EXT = 0x84FE
        const val GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT = 0x84FF
        const val ANISOTROPY = 4f
    }
}
