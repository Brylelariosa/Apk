package com.quickshare

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.Uri
import android.net.wifi.WifiConfiguration
import android.net.wifi.WifiManager
import android.net.wifi.WifiNetworkSpecifier
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pDevice
import android.net.wifi.p2p.WifiP2pInfo
import android.net.wifi.p2p.WifiP2pManager
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.InputType
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.CheckedTextView
import android.widget.EditText
import android.widget.ImageView
import android.widget.ListView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import android.content.pm.ResolveInfo
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanIntentResult
import com.journeyapps.barcodescanner.ScanOptions
import com.quickshare.databinding.ActivityMainBinding
import kotlinx.coroutines.*
import org.json.JSONObject
import java.io.*
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.UUID
import java.util.zip.CRC32

class MainActivity : AppCompatActivity(), WifiP2pManager.ChannelListener {

    override fun attachBaseContext(newBase: Context) {
        val config = Configuration(newBase.resources.configuration)
        if (config.fontScale > 1.0f) {
            config.fontScale = 1.0f
            super.attachBaseContext(newBase.createConfigurationContext(config))
        } else {
            super.attachBaseContext(newBase)
        }
    }

    private lateinit var binding: ActivityMainBinding
    private lateinit var manager: WifiP2pManager
    private lateinit var channel: WifiP2pManager.Channel
    private lateinit var receiver: BroadcastReceiver

    private var isWifiP2pEnabled = false
    private var connectedDeviceInfo: WifiP2pInfo? = null
    private val peers = mutableListOf<WifiP2pDevice>()
    private lateinit var deviceAdapter: DeviceAdapter

    private var isReceiverMode = false
    private var isHotspotMode  = false
    private var boundNetwork: Network? = null
    private var localHotspotReservation: WifiManager.LocalOnlyHotspotReservation? = null
    private var detectedGoIp: String? = null
    private var wifiNetworkCallback: ConnectivityManager.NetworkCallback? = null

    // Multi-file selection
    private val selectedFiles = mutableListOf<SelectedFile>()
    private lateinit var selectedFilesAdapter: SelectedFilesAdapter

    private val SERVER_PORT = 8988
    private val BUFFER_SIZE = 1024 * 512   // 512 KB — fewer syscalls, higher throughput

    private var serverJob: Job? = null
    private var isReceiving   = false
    private var hotspotConnectJob: Job? = null
    private var discoveryRetryJob: Job?  = null

    // Cancel support
    @Volatile private var transferCancelled = false
    private var currentReceiveSocket: Socket? = null

    // Rolling speed tracking
    private val speedSamples = ArrayDeque<Pair<Long, Long>>() // (timestamp_ms, totalBytes)
    @Volatile private var lastProgressUpdateMs = 0L           // throttle UI redraws

    // Peer name for history
    private var peerDeviceName = "Unknown"

    companion object {
        private const val TAG        = "QuickShare"
        private const val QR_PREFIX  = "QS:"
        private const val GO_IP      = "192.168.49.1"
        private const val NOTIF_CHANNEL = "qs_transfers"
    }

    // ── Activity Result Launchers ─────────────────────────────────────────────

    private val qrScanLauncher = registerForActivityResult(ScanContract()) { result: ScanIntentResult ->
        result.contents?.let { parseAndConnectQR(it) }
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        if (permissions.values.all { it }) initWifiDirect()
        else showToast("Some permissions denied — features may be limited")
    }

    private val imagePickerLauncher = registerForActivityResult(
        ActivityResultContracts.GetMultipleContents()
    ) { uris -> addSelectedFiles(uris) }

    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.GetMultipleContents()
    ) { uris -> addSelectedFiles(uris) }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        createNotificationChannel()
        setupUI()
        checkPermissionsAndInit()
    }

    override fun onResume() {
        super.onResume()
        if (::receiver.isInitialized) {
            try { registerWifiReceiver() } catch (_: Exception) {}
        }
    }

    override fun onPause() {
        super.onPause()
        if (::receiver.isInitialized) {
            try { unregisterReceiver(receiver) } catch (_: Exception) {}
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        serverJob?.cancel()
        discoveryRetryJob?.cancel()
        hotspotConnectJob?.cancel()
        localHotspotReservation?.close()
        releaseNetworkCallback()
    }

    // ── UI Setup ──────────────────────────────────────────────────────────────

    private fun setupUI() {
        deviceAdapter = DeviceAdapter(peers) { device -> connectToDevice(device) }
        binding.rvDevices.layoutManager = LinearLayoutManager(this)
        binding.rvDevices.adapter = deviceAdapter

        selectedFilesAdapter = SelectedFilesAdapter(selectedFiles) { position ->
            selectedFiles.removeAt(position)
            selectedFilesAdapter.notifyItemRemoved(position)
            updateSelectedFilesUI()
        }
        binding.rvSelectedFiles.layoutManager = LinearLayoutManager(this)
        binding.rvSelectedFiles.adapter = selectedFilesAdapter
        binding.rvSelectedFiles.isNestedScrollingEnabled = false

        binding.btnReceive.setOnClickListener {
            if (isReceiving) { stopReceiveMode(); return@setOnClickListener }
            if (!isWifiEnabled()) { showWifiOffDialog("Receiving requires WiFi to be on."); return@setOnClickListener }
            startReceiveMode()
        }

        binding.btnScanQR.setOnClickListener { scanQR() }

        // ── Fixed: Discover was a broken placeholder ──
        binding.btnDiscover.setOnClickListener {
            if (!isWifiEnabled()) { showWifiOffDialog("Discovery requires WiFi."); return@setOnClickListener }
            if (!isWifiP2pEnabled) { showToast("WiFi Direct not ready — enable WiFi"); return@setOnClickListener }
            discoverPeers()
        }

        binding.btnPickImages.setOnClickListener { imagePickerLauncher.launch("image/*") }
        binding.btnPickFiles.setOnClickListener  { filePickerLauncher.launch("*/*") }

        // ── APK picker: async icon loading + search ────────────────────────────
        binding.btnPickApk.setOnClickListener { launchAppPicker() }

        // ── Text sender ───────────────────────────────────────────────────────
        binding.btnPickText.setOnClickListener { showTextInputDialog() }

        // ── History ───────────────────────────────────────────────────────────
        binding.btnHistory.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }

        binding.btnClearFiles.setOnClickListener {
            selectedFiles.clear()
            selectedFilesAdapter.notifyDataSetChanged()
            updateSelectedFilesUI()
        }

        binding.btnSendFile.setOnClickListener {
            if (selectedFiles.isEmpty())      { showToast("Pick at least one file first"); return@setOnClickListener }
            if (!isConnectedInAnyMode())      { showToast("Connect to a receiver first");  return@setOnClickListener }
            sendFiles()
        }

        binding.btnDisconnect.setOnClickListener { disconnect() }

        // ── Cancel transfer button ────────────────────────────────────────────
        binding.btnCancelTransfer.setOnClickListener {
            transferCancelled = true
            try { currentReceiveSocket?.close() } catch (_: Exception) {}
            showToast("Cancelling…")
            binding.btnCancelTransfer.isEnabled = false
        }

        updateStatus("Ready — tap 📥 Receive on the receiver, 📷 Scan QR on the sender")
        updateConnectionUI(false)
    }

    // ── App Picker (async icons + search) ────────────────────────────────────

    private fun launchAppPicker() {
        showToast("Loading apps…")
        lifecycleScope.launch {
            val pm = packageManager
            val launcherIntent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
            }

            // Query + load icons off main thread
            val resolveInfos = withContext(Dispatchers.IO) {
                pm.queryIntentActivities(launcherIntent, PackageManager.GET_META_DATA)
                    .filter { it.activityInfo.packageName != packageName }
                    .sortedBy { it.loadLabel(pm).toString() }
            }
            val icons = withContext(Dispatchers.IO) {
                resolveInfos.map { info ->
                    try { info.loadIcon(pm) } catch (_: Exception) { null }
                }
            }

            if (resolveInfos.isEmpty()) { showToast("No apps found"); return@launch }

            val checked     = BooleanArray(resolveInfos.size)
            val allLabels   = resolveInfos.map { it.loadLabel(pm).toString() }

            // ── Build dialog with search ─────────────────────────────────
            val dialogView  = LayoutInflater.from(this@MainActivity)
                .inflate(android.R.layout.list_content, null, false)

            // Search box
            val searchBox = EditText(this@MainActivity).apply {
                hint = "Search apps…"
                inputType = InputType.TYPE_CLASS_TEXT
                setPadding(40, 20, 40, 10)
                setTextColor(Color.WHITE)
                setHintTextColor(Color.GRAY)
            }

            val container = android.widget.LinearLayout(this@MainActivity).apply {
                orientation = android.widget.LinearLayout.VERTICAL
            }

            val listView = ListView(this@MainActivity)
            val adapter = object : ArrayAdapter<ResolveInfo>(this@MainActivity, 0, resolveInfos.toMutableList()) {
                override fun getView(pos: Int, convertView: View?, parent: ViewGroup): View {
                    val view = convertView ?: LayoutInflater.from(context)
                        .inflate(android.R.layout.simple_list_item_multiple_choice, parent, false)
                    val tv   = view.findViewById<CheckedTextView>(android.R.id.text1)
                    val info = getItem(pos) ?: return view
                    val originalIndex = resolveInfos.indexOf(info)
                    tv.text    = if (originalIndex >= 0) allLabels[originalIndex] else info.loadLabel(pm)
                    val icon   = if (originalIndex >= 0) icons[originalIndex] else null
                    if (icon != null) {
                        icon.setBounds(0, 0, 80, 80)
                        tv.setCompoundDrawables(icon, null, null, null)
                    } else {
                        tv.setCompoundDrawables(null, null, null, null)
                    }
                    tv.compoundDrawablePadding = 20
                    tv.isChecked = if (originalIndex >= 0) checked[originalIndex] else false
                    return view
                }
            }

            listView.adapter     = adapter
            listView.choiceMode  = ListView.CHOICE_MODE_MULTIPLE
            listView.setOnItemClickListener { _, _, pos, _ ->
                val info          = adapter.getItem(pos) ?: return@setOnItemClickListener
                val originalIndex = resolveInfos.indexOf(info)
                if (originalIndex >= 0) {
                    checked[originalIndex] = !checked[originalIndex]
                    listView.setItemChecked(pos, checked[originalIndex])
                }
            }

            searchBox.addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: android.text.Editable?) {
                    val query = s.toString().trim().lowercase()
                    adapter.clear()
                    if (query.isEmpty()) {
                        adapter.addAll(resolveInfos)
                    } else {
                        adapter.addAll(resolveInfos.filter {
                            it.loadLabel(pm).toString().lowercase().contains(query)
                        })
                    }
                    adapter.notifyDataSetChanged()
                }
            })

            container.addView(searchBox)
            container.addView(listView)

            AlertDialog.Builder(this@MainActivity)
                .setTitle("Select Apps to Send")
                .setView(container)
                .setPositiveButton("Add") { _, _ ->
                    var added = 0
                    for (i in resolveInfos.indices) {
                        if (checked[i]) {
                            val appInfo = resolveInfos[i].activityInfo.applicationInfo
                            val apkFile = File(appInfo.sourceDir)
                            val uri     = Uri.fromFile(apkFile)
                            val name    = allLabels[i] + ".apk"
                            val size    = apkFile.length()
                            if (selectedFiles.none { it.uri == uri }) {
                                selectedFiles.add(SelectedFile(uri, name, size))
                                added++
                            }
                        }
                    }
                    if (added > 0) {
                        selectedFilesAdapter.notifyDataSetChanged()
                        updateSelectedFilesUI()
                        showToast("$added app(s) added")
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    // ── Text input dialog ─────────────────────────────────────────────────────

    private fun showTextInputDialog() {
        val editText = EditText(this).apply {
            hint      = "Enter text to send…"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines  = 4
            maxLines  = 10
            setPadding(40, 20, 40, 20)
        }
        AlertDialog.Builder(this)
            .setTitle("📝 Send Text")
            .setView(editText)
            .setPositiveButton("Add to Queue") { _, _ ->
                val text = editText.text.toString()
                if (text.isBlank()) { showToast("Text is empty"); return@setPositiveButton }
                val fileName = "text_${System.currentTimeMillis()}.txt"
                val file     = File(cacheDir, fileName)
                file.writeText(text, Charsets.UTF_8)
                val uri = Uri.fromFile(file)
                selectedFiles.add(SelectedFile(uri, fileName, file.length()))
                selectedFilesAdapter.notifyDataSetChanged()
                updateSelectedFilesUI()
                showToast("Text added to queue")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ── Speed helpers ─────────────────────────────────────────────────────────

    private fun recordSpeed(totalTransferred: Long) {
        val now = System.currentTimeMillis()
        speedSamples.addLast(Pair(now, totalTransferred))
        while (speedSamples.size > 1 && now - speedSamples.first().first > 2000) {
            speedSamples.removeFirst()
        }
    }

    private fun rollingSpeedMBps(): Double {
        if (speedSamples.size < 2) return 0.0
        val (t0, b0) = speedSamples.first()
        val (t1, b1) = speedSamples.last()
        val elapsed  = (t1 - t0) / 1000.0
        return if (elapsed > 0) (b1 - b0).toDouble() / elapsed / 1024 / 1024 else 0.0
    }

    // ── Notifications ─────────────────────────────────────────────────────────

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIF_CHANNEL, "File Transfers", NotificationManager.IMPORTANCE_DEFAULT
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notifyReceiveComplete(fileCount: Int, totalBytes: Long) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED) return

        val notif = NotificationCompat.Builder(this, NOTIF_CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle("QuickShare — Files Received")
            .setContentText("✅ $fileCount file(s) · ${Utils.formatSize(totalBytes)} → Downloads")
            .setAutoCancel(true)
            .build()

        getSystemService(NotificationManager::class.java)
            .notify(System.currentTimeMillis().toInt() and 0xFFFF, notif)
    }

    // ── Shared helpers ────────────────────────────────────────────────────────

    private fun isConnectedInAnyMode() = connectedDeviceInfo != null || isHotspotMode

    private fun isWifiEnabled(): Boolean {
        val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
        return wm.isWifiEnabled
    }

    private fun showWifiOffDialog(message: String) {
        AlertDialog.Builder(this)
            .setTitle("WiFi is Off")
            .setMessage("$message\n\nOpen WiFi settings?")
            .setPositiveButton("Open Settings") { _, _ -> startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ── Selected Files ────────────────────────────────────────────────────────

    private fun addSelectedFiles(uris: List<Uri>) {
        var added = 0
        for (uri in uris) {
            if (selectedFiles.none { it.uri == uri }) {
                val (name, size) = getFileInfo(uri)
                selectedFiles.add(SelectedFile(uri, name, size))
                added++
            }
        }
        if (added > 0) selectedFilesAdapter.notifyDataSetChanged()
        updateSelectedFilesUI()
    }

    private fun updateSelectedFilesUI() {
        if (selectedFiles.isEmpty()) {
            binding.cardSelectedFiles.visibility = View.GONE
        } else {
            binding.cardSelectedFiles.visibility = View.VISIBLE
            val totalSize = selectedFiles.sumOf { it.size }
            binding.tvSelectedFilesHeader.text =
                "${selectedFiles.size} file(s) selected • ${Utils.formatSize(totalSize)}"
        }
        binding.btnSendFile.isEnabled = selectedFiles.isNotEmpty() && isConnectedInAnyMode()
    }

    // ── Permissions ───────────────────────────────────────────────────────────

    private fun checkPermissionsAndInit() {
        val perms = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.CAMERA
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms += listOf(
                Manifest.permission.NEARBY_WIFI_DEVICES,
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_AUDIO,
                Manifest.permission.POST_NOTIFICATIONS
            )
        } else {
            perms.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        val missing = perms.filter {
            ActivityCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) initWifiDirect() else permissionLauncher.launch(missing.toTypedArray())
    }

    // ── WiFi Direct ───────────────────────────────────────────────────────────

    private fun initWifiDirect() {
        manager  = getSystemService(Context.WIFI_P2P_SERVICE) as WifiP2pManager
        channel  = manager.initialize(this, mainLooper, this)
        receiver = WiFiDirectBroadcastReceiver(manager, channel, this)
        registerWifiReceiver()
    }

    private fun registerWifiReceiver() {
        val filter = IntentFilter().apply {
            addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION)
        }
        registerReceiver(receiver, filter)
    }

    fun setWifiP2pEnabled(enabled: Boolean) {
        isWifiP2pEnabled = enabled
        if (!enabled) {
            updateStatus("WiFi is OFF — please enable WiFi")
            updateConnectionUI(false)
        }
    }

    private fun discoverPeers() {
        discoveryRetryJob?.cancel()
        updateStatus("🔍 Scanning for nearby devices…")
        binding.progressBar.visibility = View.VISIBLE
        if (!hasLocationPerm()) { showToast("Location permission needed"); return }

        manager.discoverPeers(channel, object : WifiP2pManager.ActionListener {
            override fun onSuccess() {
                updateStatus("Scanning… (auto-retry if nothing found)")
                discoveryRetryJob = lifecycleScope.launch {
                    delay(8000)
                    if (peers.isEmpty() && isWifiP2pEnabled) {
                        updateStatus("Nothing found yet — retrying…")
                        discoverPeers()
                    }
                }
            }
            override fun onFailure(reason: Int) {
                binding.progressBar.visibility = View.GONE
                val msg = when (reason) {
                    WifiP2pManager.P2P_UNSUPPORTED -> "WiFi Direct not supported on this device"
                    WifiP2pManager.BUSY            -> {
                        // System still has an active scan running — reschedule instead of giving up
                        discoveryRetryJob = lifecycleScope.launch {
                            delay(5000)
                            if (peers.isEmpty() && isWifiP2pEnabled) discoverPeers()
                        }
                        "System busy — retrying scan in 5 s…"
                    }
                    else                           -> "Discovery failed (code $reason)"
                }
                updateStatus(msg); showToast(msg)
            }
        })
    }

    fun updatePeerList(deviceList: Collection<WifiP2pDevice>) {
        binding.progressBar.visibility = View.GONE
        peers.clear(); peers.addAll(deviceList)
        deviceAdapter.notifyDataSetChanged()
        if (peers.isEmpty()) {
            updateStatus("No devices found — make sure receiver tapped 📥 Receive")
            binding.tvNoPeers.visibility = View.VISIBLE
        } else {
            discoveryRetryJob?.cancel()
            updateStatus("Found ${peers.size} device(s) — tap to connect")
            binding.tvNoPeers.visibility = View.GONE
        }
    }

    private fun connectToDevice(device: WifiP2pDevice) {
        peerDeviceName = device.deviceName.ifEmpty { "Unknown Device" }
        val config = WifiP2pConfig().apply {
            deviceAddress    = device.deviceAddress
            groupOwnerIntent = if (isReceiverMode) 15 else 0
        }
        if (!hasLocationPerm()) return
        updateStatus("Connecting to ${device.deviceName}…")
        binding.progressBar.visibility = View.VISIBLE

        manager.connect(channel, config, object : WifiP2pManager.ActionListener {
            override fun onSuccess() { showToast("Connection request sent to ${device.deviceName}") }
            override fun onFailure(reason: Int) {
                binding.progressBar.visibility = View.GONE
                showToast("Connection failed: $reason")
                updateStatus("Connection failed — try again")
            }
        })
    }

    fun onConnectionInfoAvailable(info: WifiP2pInfo) {
        binding.progressBar.visibility = View.GONE
        connectedDeviceInfo = info

        if (info.groupFormed) {
            val role = if (info.isGroupOwner) "Host (GO)" else "Client"
            val goIp = info.groupOwnerAddress?.hostAddress ?: "?"
            updateStatus("✓ P2P Connected as $role — GO IP: $goIp")
            updateConnectionUI(true)

            if (info.isGroupOwner && isReceiverMode && !isReceiving) {
                startReceiveServer()
            }
        }
    }

    private fun disconnect() {
        discoveryRetryJob?.cancel()
        releaseNetworkCallback()
        if (connectedDeviceInfo != null) {
            manager.removeGroup(channel, object : WifiP2pManager.ActionListener {
                override fun onSuccess()    = resetConnectionState()
                override fun onFailure(r: Int) = resetConnectionState()
            })
        } else {
            resetConnectionState()
        }
    }

    private fun resetConnectionState() {
        connectedDeviceInfo = null
        isHotspotMode       = false
        boundNetwork        = null
        detectedGoIp        = null
        isReceiverMode      = false
        localHotspotReservation?.close()
        localHotspotReservation = null
        stopReceiveServer()
        updateConnectionUI(false)
        updateStatus("Disconnected — Ready")
        updateSelectedFilesUI()
    }

    override fun onChannelDisconnected() {
        showToast("WiFi Direct channel lost — reconnecting…")
        if (::manager.isInitialized) channel = manager.initialize(this, mainLooper, this)
    }

    // ── Receive Mode ──────────────────────────────────────────────────────────

    private fun startReceiveMode() {
        if (!::manager.isInitialized) { showToast("WiFi not ready yet — try again"); return }
        isReceiverMode = true
        binding.btnReceive.text = "⏹ Stop Receiving"
        binding.btnReceive.setBackgroundColor(getColor(R.color.red))
        binding.progressBar.visibility = View.VISIBLE

        // Prefer LocalOnlyHotspot (real WiFi AP → always visible in WiFi settings on ANY device).
        // Fall back to WiFi Direct createGroup if the system rejects LocalOnlyHotspot
        // (e.g. device already running a regular hotspot or API < 26).
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startLocalOnlyHotspotReceive()
        } else {
            updateStatus("Setting up hotspot…")
            manager.removeGroup(channel, object : WifiP2pManager.ActionListener {
                override fun onSuccess()       = createGroupForReceiving()
                override fun onFailure(r: Int) = createGroupForReceiving()
            })
        }
    }

    /**
     * API 26+: start a real WiFi access point via LocalOnlyHotspot.
     * This creates a network that IS visible in WiFi Settings on every Android device —
     * unlike a WiFi Direct group (createGroup) which XOS and many budget ROMs hide
     * from the normal WiFi scanner.
     */
    @RequiresApi(Build.VERSION_CODES.O)
    private fun startLocalOnlyHotspotReceive() {
        updateStatus("Starting hotspot…")
        val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
        try {
            wm.startLocalOnlyHotspot(object : WifiManager.LocalOnlyHotspotCallback() {

                override fun onStarted(reservation: WifiManager.LocalOnlyHotspotReservation) {
                    localHotspotReservation = reservation

                    // Read SSID / passphrase from the reservation
                    val (ssid, pass) = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        val soft = reservation.softApConfiguration
                        Pair(soft.ssid ?: "QuickShare", soft.passphrase ?: "")
                    } else {
                        @Suppress("DEPRECATION")
                        val cfg = reservation.wifiConfiguration
                        Pair(
                            cfg?.SSID?.trim('"') ?: "QuickShare",
                            cfg?.preSharedKey?.trim('"') ?: ""
                        )
                    }

                    runOnUiThread {
                        binding.progressBar.visibility = View.GONE
                        startReceiveServer()
                        updateStatus("📥 Ready — connect to \"$ssid\" then scan QR")
                        showQRDialog(ssid, pass)
                    }
                }

                override fun onFailed(reason: Int) {
                    // Common reasons: ERROR(0)=system busy, INCOMPATIBLE_MODE(1)=regular hotspot
                    // already running, TETHERING_DISALLOWED(2)=carrier restriction.
                    // In all cases fall back to WiFi Direct group.
                    runOnUiThread {
                        showToast("Local hotspot unavailable ($reason) — trying WiFi Direct…")
                        updateStatus("Trying WiFi Direct fallback…")
                        manager.removeGroup(channel, object : WifiP2pManager.ActionListener {
                            override fun onSuccess()       = createGroupForReceiving()
                            override fun onFailure(r: Int) = createGroupForReceiving()
                        })
                    }
                }

                override fun onStopped() {
                    localHotspotReservation = null
                    runOnUiThread {
                        if (isReceiverMode) updateStatus("Hotspot stopped externally — tap Receive again")
                    }
                }
            }, null)
        } catch (e: Exception) {
            showToast("Hotspot error: ${e.message} — trying WiFi Direct…")
            manager.removeGroup(channel, object : WifiP2pManager.ActionListener {
                override fun onSuccess()       = createGroupForReceiving()
                override fun onFailure(r: Int) = createGroupForReceiving()
            })
        }
    }

    private fun createGroupForReceiving() {
        if (!hasLocationPerm()) {
            binding.progressBar.visibility = View.GONE
            showToast("Location permission needed")
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            createGroupWithConfig()
        } else {
            createGroupLegacy()
        }
    }

    /**
     * API 29+: supply explicit SSID + passphrase so the network is always
     * visible in other devices' WiFi scanner — fixes budget ROMs (XOS, MIUI,
     * itel) that silently hide the auto-generated P2P group.
     * API 33+: also pin to 2.4 GHz so budget radios that struggle on 5 GHz
     * can always see and join the network.
     */
    @RequiresApi(Build.VERSION_CODES.Q)
    private fun createGroupWithConfig() {
        val suffix     = (1000..9999).random()
        val ssid       = "DIRECT-QS-$suffix"
        val passphrase = buildString {
            val pool = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789"
            repeat(12) { append(pool.random()) }
        }

        val configBuilder = WifiP2pConfig.Builder()
            .setNetworkName(ssid)
            .setPassphrase(passphrase)

        // Force 2.4 GHz if available — better range + compat on budget devices
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            try {
                configBuilder.setGroupOperatingBand(WifiP2pConfig.GROUP_OWNER_BAND_2GHZ)
            } catch (_: Exception) { /* ignore if ROM rejects it */ }
        }

        val config = configBuilder.build()

        // We know the credentials before the group forms → show QR immediately
        binding.progressBar.visibility = View.GONE
        startReceiveServer()
        updateStatus("📥 Ready to receive — my IP: ${getLocalIpAddress()}")
        showQRDialog(ssid, passphrase)

        manager.createGroup(channel, config, object : WifiP2pManager.ActionListener {
            override fun onSuccess() { Log.d(TAG, "createGroup(config) OK") }
            override fun onFailure(reason: Int) {
                Log.w(TAG, "createGroup(config) failed ($reason) — trying legacy")
                // Fall back: launch legacy without dismissing QR (server already running)
                manager.createGroup(channel, object : WifiP2pManager.ActionListener {
                    override fun onSuccess() {}
                    override fun onFailure(r: Int) {
                        runOnUiThread { showToast("Hotspot setup issue ($r) — try WiFi Direct discover") }
                    }
                })
            }
        })
    }

    /** Pre-API-29 path: ask Android to create the group and read back the credentials. */
    private fun createGroupLegacy() {
        manager.createGroup(channel, object : WifiP2pManager.ActionListener {
            override fun onSuccess() {
                lifecycleScope.launch {
                    delay(600)
                    manager.requestGroupInfo(channel) { group ->
                        binding.progressBar.visibility = View.GONE
                        startReceiveServer()
                        val myIp = getLocalIpAddress()
                        if (group != null) {
                            updateStatus("📥 Ready to receive — my IP: $myIp")
                            showQRDialog(group.networkName, group.passphrase)
                        } else {
                            updateStatus("📥 Server active — my IP: $myIp — sender can use Discover")
                        }
                    }
                }
            }
            override fun onFailure(reason: Int) {
                manager.requestGroupInfo(channel) { group ->
                    binding.progressBar.visibility = View.GONE
                    startReceiveServer()
                    val myIp = getLocalIpAddress()
                    if (group != null) {
                        updateStatus("📥 Ready to receive — my IP: $myIp")
                        showQRDialog(group.networkName, group.passphrase)
                    } else {
                        updateStatus("📥 Server active (createGroup failed: $reason) — my IP: $myIp")
                        showToast("Hotspot setup issue — try WiFi Direct discovery")
                    }
                }
            }
        })
    }

    private fun stopReceiveMode() {
        isReceiverMode = false
        stopReceiveServer()
        // Release local hotspot if we used that path
        localHotspotReservation?.close()
        localHotspotReservation = null
        // Also clean up any WiFi Direct group (no-op if none exists)
        manager.removeGroup(channel, object : WifiP2pManager.ActionListener {
            override fun onSuccess()       {}
            override fun onFailure(r: Int) {}
        })
        binding.btnReceive.text = "📥 Receive"
        binding.btnReceive.setBackgroundColor(getColor(R.color.green))
        updateStatus("Receive mode stopped")
    }

    // ── QR Code ───────────────────────────────────────────────────────────────

    private fun showQRDialog(ssid: String, passphrase: String) {
        val json    = JSONObject().apply { put("s", ssid); put("p", passphrase) }.toString()
        val content = QR_PREFIX + json
        val size    = 600
        val hints   = mapOf(
            EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.M,
            EncodeHintType.MARGIN to 2
        )
        val matrix = QRCodeWriter().encode(content, BarcodeFormat.QR_CODE, size, size, hints)
        val bmp    = Bitmap.createBitmap(size, size, Bitmap.Config.RGB_565)
        for (x in 0 until size) for (y in 0 until size)
            bmp.setPixel(x, y, if (matrix[x, y]) Color.BLACK else Color.WHITE)

        val iv = ImageView(this).apply { setImageBitmap(bmp); setPadding(40, 40, 40, 8) }

        // Show credentials as text so sender can connect manually if QR scan fails
        val tvCreds = android.widget.TextView(this).apply {
            text = "Network: $ssid\nPassword: $passphrase"
            setPadding(48, 0, 48, 32)
            textSize = 13f
            setTextIsSelectable(true)
            setTextColor(android.graphics.Color.DKGRAY)
        }

        val layout = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            addView(iv)
            addView(tvCreds)
        }

        AlertDialog.Builder(this)
            .setTitle("📥 Ready to Receive")
            .setMessage("Have the sender scan this QR — or connect to the network shown below it manually")
            .setView(layout)
            .setPositiveButton("Keep Active") { d, _ -> d.dismiss() }
            .setNegativeButton("Stop Receiving") { d, _ -> d.dismiss(); stopReceiveMode() }
            .setCancelable(false)
            .show()
    }

    private fun scanQR() {
        val options = ScanOptions()
            .setDesiredBarcodeFormats(ScanOptions.QR_CODE)
            .setPrompt("Scan the receiver's QR code")
            .setCameraId(0)
            .setBeepEnabled(true)
            .setBarcodeImageEnabled(false)
        qrScanLauncher.launch(options)
    }

    private fun parseAndConnectQR(content: String) {
        try {
            val json       = content.removePrefix(QR_PREFIX)
            val obj        = JSONObject(json)
            val ssid       = obj.getString("s")
            val passphrase = obj.getString("p")
            peerDeviceName = "QR Connection"
            showManualConnectDialog(ssid, passphrase)
        } catch (e: Exception) {
            showToast("Invalid QR code")
            Log.e(TAG, "QR parse error: ${e.message}")
        }
    }

    /**
     * Shows SSID/password so user can connect from WiFi settings if auto-connect
     * fails (common on budget devices like itel/Tecno running Android Go).
     * Auto-connect runs in the background simultaneously.
     */
    private fun showManualConnectDialog(ssid: String, passphrase: String) {
        connectViaHotspot(ssid, passphrase) // start auto-connect in background

        AlertDialog.Builder(this)
            .setTitle("Connect to Receiver")
            .setMessage(
                "Trying to connect automatically…\n\n" +
                "If nothing happens in 10 seconds:\n" +
                "1. Open your WiFi Settings\n" +
                "2. Connect to:  $ssid\n" +
                "3. Password:  $passphrase\n" +
                "4. Come back here and tap ✅ I'm Connected"
            )
            .setPositiveButton("✅ I'm Connected") { d, _ ->
                d.dismiss()
                handleManualWifiConnect()
            }
            .setNegativeButton("Cancel") { d, _ ->
                d.dismiss()
                hotspotConnectJob?.cancel()
                releaseNetworkCallback()
                binding.progressBar.visibility = View.GONE
                updateStatus("Cancelled — tap 📷 Scan QR to try again")
            }
            .setCancelable(false)
            .show()
    }

    /** Called after user manually joined receiver's hotspot from WiFi settings. */
    @Suppress("DEPRECATION")
    private fun handleManualWifiConnect() {
        hotspotConnectJob?.cancel()
        releaseNetworkCallback()
        binding.progressBar.visibility = View.GONE

        val wm   = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
        val dhcp = wm.dhcpInfo
        if (dhcp.gateway != 0) {
            detectedGoIp  = intToIp(dhcp.gateway)
            isHotspotMode = true
            boundNetwork  = null
            updateStatus("✅ Connected! (GO: $detectedGoIp) — Pick files and tap 🚀 Send Files")
            updateConnectionUI(true)
        } else {
            // DHCP not ready — ask user to enter IP manually as last resort
            showManualIpDialog()
        }
    }

    /** Last-resort: user types the receiver's IP directly. */
    private fun showManualIpDialog() {
        val input = android.widget.EditText(this).apply {
            hint      = "e.g. 192.168.49.1"
            setText(GO_IP)
            inputType = android.text.InputType.TYPE_CLASS_TEXT
            setPadding(48, 24, 48, 24)
        }
        AlertDialog.Builder(this)
            .setTitle("Enter Receiver IP")
            .setMessage("Couldn't detect IP automatically.\nEnter the IP shown on the receiver's screen:")
            .setView(input)
            .setPositiveButton("Connect") { d, _ ->
                val ip = input.text.toString().trim()
                if (ip.isNotEmpty()) {
                    detectedGoIp  = ip
                    isHotspotMode = true
                    boundNetwork  = null
                    updateStatus("✅ Ready — tap 🚀 Send Files")
                    updateConnectionUI(true)
                }
                d.dismiss()
            }
            .setNegativeButton("Cancel") { d, _ -> d.dismiss() }
            .show()
    }

    // ── Hotspot Connection ────────────────────────────────────────────────────

    private fun connectViaHotspot(ssid: String, passphrase: String) {
        binding.progressBar.visibility = View.VISIBLE
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            connectViaNetworkSpecifier(ssid, passphrase)
        } else {
            @Suppress("DEPRECATION")
            connectLegacyWifi(ssid, passphrase)
        }
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    private fun connectViaNetworkSpecifier(ssid: String, passphrase: String) {
        val specifier = WifiNetworkSpecifier.Builder().setSsid(ssid).setWpa2Passphrase(passphrase).build()
        val request   = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .setNetworkSpecifier(specifier).build()
        val cm = getSystemService(ConnectivityManager::class.java)
        releaseNetworkCallback()

        hotspotConnectJob?.cancel()
        hotspotConnectJob = lifecycleScope.launch {
            delay(15_000)
            if (!isHotspotMode) {
                releaseNetworkCallback()
                binding.progressBar.visibility = View.GONE
                updateStatus("⏱ Connection timed out — make sure receiver's QR is still active")
                showToast("Timed out — try scanning QR again")
            }
        }

        wifiNetworkCallback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                hotspotConnectJob?.cancel()
                boundNetwork  = network
                isHotspotMode = true

                // Detect actual GO gateway IP — XOS/custom ROMs may not use 192.168.49.1
                val cm = getSystemService(ConnectivityManager::class.java)
                val linkProps = cm.getLinkProperties(network)
                detectedGoIp = linkProps?.routes
                    ?.firstOrNull { it.gateway != null && !it.gateway!!.isLoopbackAddress }
                    ?.gateway?.hostAddress
                    ?: GO_IP  // fallback to standard Android GO IP

                runOnUiThread {
                    binding.progressBar.visibility = View.GONE
                    updateStatus("✅ Connected! (GO: $detectedGoIp) — Pick files and tap 🚀 Send Files")
                    updateConnectionUI(true)
                }
            }
            override fun onUnavailable() {
                hotspotConnectJob?.cancel()
                runOnUiThread {
                    binding.progressBar.visibility = View.GONE
                    updateStatus("❌ Could not connect — receiver may need to restart Receive mode")
                    showToast("Connection failed — try again")
                }
            }
            override fun onLost(network: Network) {
                if (boundNetwork == network) {
                    boundNetwork = null; isHotspotMode = false
                    runOnUiThread { updateStatus("Connection lost") }
                }
            }
        }
        cm.requestNetwork(request, wifiNetworkCallback!!)
        updateStatus("Connecting to receiver's hotspot…")
    }

    @Suppress("DEPRECATION")
    private fun connectLegacyWifi(ssid: String, passphrase: String) {
        val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
        val cfg = WifiConfiguration().apply {
            SSID           = "\"$ssid\""
            preSharedKey   = "\"$passphrase\""
            allowedKeyManagement.set(WifiConfiguration.KeyMgmt.WPA_PSK)
        }
        val id = wm.addNetwork(cfg)
        if (id == -1) {
            binding.progressBar.visibility = View.GONE
            showToast("Failed to configure WiFi — connect manually to: $ssid")
            return
        }
        wm.disconnect(); wm.enableNetwork(id, true); wm.reconnect()

        lifecycleScope.launch {
            val deadline = System.currentTimeMillis() + 12_000
            while (System.currentTimeMillis() < deadline) {
                delay(1000)
                @Suppress("DEPRECATION")
                val currentSsid = wm.connectionInfo?.ssid?.trim('"') ?: ""
                if (currentSsid == ssid) {
                    isHotspotMode = true; boundNetwork = null
                    // Detect actual GO IP from DHCP gateway — don't assume 192.168.49.1
                    @Suppress("DEPRECATION")
                    val dhcp = wm.dhcpInfo
                    detectedGoIp = if (dhcp.gateway != 0) intToIp(dhcp.gateway) else GO_IP
                    withContext(Dispatchers.Main) {
                        binding.progressBar.visibility = View.GONE
                        updateStatus("✅ Connected! (GO: $detectedGoIp) — Pick files and tap 🚀 Send Files")
                        updateConnectionUI(true)
                    }
                    return@launch
                }
            }
            withContext(Dispatchers.Main) {
                binding.progressBar.visibility = View.GONE
                isHotspotMode = true; boundNetwork = null
                updateStatus("⚠️ Connection unconfirmed — try tapping 🚀 Send Files")
                updateConnectionUI(true)
            }
        }
    }

    /** Convert Android's little-endian int IP (from DhcpInfo) to dotted string. */
    private fun intToIp(i: Int) =
        "${i and 0xFF}.${i shr 8 and 0xFF}.${i shr 16 and 0xFF}.${i shr 24 and 0xFF}"

    /** Returns this device's WiFi/P2P IP address, or GO_IP as fallback. */
    private fun getLocalIpAddress(): String {
        try {
            val interfaces = java.net.NetworkInterface.getNetworkInterfaces()
            for (iface in interfaces) {
                if (!iface.isUp || iface.isLoopback) continue
                for (addr in iface.inetAddresses) {
                    if (addr.isLoopbackAddress) continue
                    if (addr is java.net.Inet4Address) {
                        val ip = addr.hostAddress ?: continue
                        // Prefer p2p or wlan interface addresses
                        if (iface.name.startsWith("p2p") || iface.name.startsWith("wlan"))
                            return ip
                    }
                }
            }
        } catch (_: Exception) {}
        return GO_IP
    }

    private fun releaseNetworkCallback() {
        wifiNetworkCallback?.let {
            try { getSystemService(ConnectivityManager::class.java).unregisterNetworkCallback(it) }
            catch (_: Exception) {}
            wifiNetworkCallback = null
        }
    }

    // ── TCP Receive Server ────────────────────────────────────────────────────

    private fun startReceiveServer() {
        if (isReceiving) return
        isReceiving = true

        serverJob?.cancel()
        serverJob = lifecycleScope.launch(Dispatchers.IO) {
            var serverSocket: ServerSocket? = null
            try {
                serverSocket = ServerSocket(SERVER_PORT)
                serverSocket.reuseAddress     = true
                serverSocket.receiveBufferSize = BUFFER_SIZE * 4  // 2 MB kernel recv window
                Log.d(TAG, "Server listening on :$SERVER_PORT")

                while (isActive && isReceiving) {
                    try {
                        val client = serverSocket.accept()
                        client.soTimeout = 60_000   // unblock reads if sender goes silent
                        client.receiveBufferSize = BUFFER_SIZE * 4  // 2 MB recv window
                        launch { handleIncomingFiles(client) }
                    } catch (e: Exception) {
                        if (isActive && isReceiving) Log.e(TAG, "Accept error: ${e.message}")
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Server error: ${e.message}")
                withContext(Dispatchers.Main) { showToast("Server error: ${e.message}") }
            } finally {
                serverSocket?.close()
            }
        }
    }

    private fun stopReceiveServer() {
        isReceiving = false
        serverJob?.cancel()
        serverJob = null
    }

    // Protocol: [int: fileCount] then for each file:
    //   [int: nameLen][bytes: name][long: size][bytes: data][int: crc32]
    private suspend fun handleIncomingFiles(socket: Socket) {
        currentReceiveSocket = socket
        val fileNames = mutableListOf<String>()
        var allReceived = 0L
        var status = "success"

        try {
            val input     = DataInputStream(BufferedInputStream(socket.getInputStream(), BUFFER_SIZE))
            val fileCount = input.readInt()

            withContext(Dispatchers.Main) {
                transferCancelled = false
                speedSamples.clear()
                updateStatus("Receiving $fileCount file(s)…")
            }

            val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            downloadsDir.mkdirs()

            for (i in 1..fileCount) {
                if (transferCancelled) { status = "cancelled"; break }

                val nameLen   = input.readInt()
                val nameBytes = ByteArray(nameLen)
                input.readFully(nameBytes)
                val fileName  = String(nameBytes, Charsets.UTF_8)
                val fileSize  = input.readLong()
                fileNames.add(fileName)

                withContext(Dispatchers.Main) {
                    showProgressUI(true, fileName, fileSize, i, fileCount)
                    updateStatus("Receiving $i/$fileCount: $fileName (${Utils.formatSize(fileSize)})")
                }

                val outFile = File(downloadsDir, getUniqueFileName(downloadsDir, fileName))
                val output  = BufferedOutputStream(FileOutputStream(outFile), BUFFER_SIZE)
                val buffer  = ByteArray(BUFFER_SIZE)
                val crc     = CRC32()
                var received = 0L

                while (received < fileSize) {
                    if (transferCancelled) break
                    val toRead = minOf(buffer.size.toLong(), fileSize - received).toInt()
                    val read   = input.read(buffer, 0, toRead)
                    if (read == -1) break
                    output.write(buffer, 0, read)
                    crc.update(buffer, 0, read)
                    received    += read
                    allReceived += read

                    recordSpeed(allReceived)
                    val nowMs = System.currentTimeMillis()
                    if (nowMs - lastProgressUpdateMs >= 200) {
                        lastProgressUpdateMs = nowMs
                        val pct = if (fileSize > 0) ((received * 100) / fileSize).toInt() else 0
                        withContext(Dispatchers.Main) { updateProgress(pct, received, fileSize, rollingSpeedMBps()) }
                    }
                }
                output.flush(); output.close()

                if (transferCancelled) {
                    outFile.delete()
                    status = "cancelled"
                    break
                }

                // Verify CRC32
                val senderCrc = input.readInt()
                val ourCrc    = crc.value.toInt()
                if (senderCrc != ourCrc) {
                    val corruptedFile = File(outFile.parent, "CORRUPTED_${outFile.name}")
                    outFile.renameTo(corruptedFile)
                    withContext(Dispatchers.Main) { showToast("⚠️ $fileName may be corrupted (CRC mismatch)") }
                }
            }

            input.close()

            withContext(Dispatchers.Main) {
                showProgressUI(false, "", 0)
                when (status) {
                    "cancelled" -> updateStatus("⛔ Transfer cancelled")
                    else -> {
                        updateStatus("✅ Received ${fileNames.size} file(s) — ${Utils.formatSize(allReceived)} total → Downloads")
                        showToast("${fileNames.size} file(s) saved to Downloads")
                        notifyReceiveComplete(fileNames.size, allReceived)
                    }
                }
            }

        } catch (e: java.net.SocketTimeoutException) {
            status = "failed"
            Log.e(TAG, "Receive timeout: ${e.message}")
            withContext(Dispatchers.Main) {
                showProgressUI(false, "", 0)
                updateStatus("❌ Receive timed out — sender may have disconnected")
                showToast("Transfer timed out")
            }
        } catch (e: Exception) {
            status = "failed"
            Log.e(TAG, "Receive error: ${e.message}")
            withContext(Dispatchers.Main) {
                showProgressUI(false, "", 0)
                updateStatus("❌ Receive failed: ${e.message}")
            }
        } finally {
            currentReceiveSocket = null
            try { socket.close() } catch (_: Exception) {}

            // Save to history
            HistoryManager.add(this@MainActivity, TransferRecord(
                id         = UUID.randomUUID().toString(),
                timestamp  = System.currentTimeMillis(),
                direction  = "received",
                fileNames  = fileNames,
                totalBytes = allReceived,
                peerName   = peerDeviceName,
                status     = status
            ))
        }
    }

    // ── TCP Send ──────────────────────────────────────────────────────────────

    private fun sendFiles() {
        val hostIp: String = when {
            isHotspotMode -> detectedGoIp ?: GO_IP
            connectedDeviceInfo?.isGroupOwner == false ->
                connectedDeviceInfo?.groupOwnerAddress?.hostAddress ?: run {
                    showToast("Cannot determine receiver IP"); return
                }
            else -> {
                showToast("Role conflict — tap Disconnect and let the other device Discover you"); return
            }
        }

        val filesToSend = selectedFiles.toList()

        lifecycleScope.launch(Dispatchers.IO) {
            var socket: Socket? = null
            var totalBytesSent  = 0L
            var status          = "success"

            try {
                withContext(Dispatchers.Main) {
                    transferCancelled = false
                    speedSamples.clear()
                    updateStatus("Connecting to $hostIp…")
                    showProgressUI(true, filesToSend.first().name, filesToSend.first().size, 1, filesToSend.size)
                }

                socket = connectToHost(hostIp)
                val output = DataOutputStream(BufferedOutputStream(socket.getOutputStream(), BUFFER_SIZE))

                output.writeInt(filesToSend.size)

                for ((index, file) in filesToSend.withIndex()) {
                    if (transferCancelled) { status = "cancelled"; break }

                    // Resolve true size via file descriptor — content URIs can report 0
                    val actualSize = resolveActualSize(file)

                    withContext(Dispatchers.Main) {
                        showProgressUI(true, file.name, actualSize, index + 1, filesToSend.size)
                        updateStatus("Sending ${index + 1}/${filesToSend.size}: ${file.name}")
                    }

                    val nameBytes = file.name.toByteArray(Charsets.UTF_8)
                    output.writeInt(nameBytes.size)
                    output.write(nameBytes)
                    output.writeLong(actualSize)

                    val inputStream = openFileStream(file)
                        ?: throw IOException("Cannot open: ${file.name}")
                    val buffer = ByteArray(BUFFER_SIZE)
                    val crc    = CRC32()
                    var sent   = 0L

                    while (true) {
                        if (transferCancelled) break
                        val read = inputStream.read(buffer)
                        if (read == -1) break
                        output.write(buffer, 0, read)
                        crc.update(buffer, 0, read)
                        sent           += read
                        totalBytesSent += read

                        recordSpeed(totalBytesSent)
                        val nowMs = System.currentTimeMillis()
                        if (nowMs - lastProgressUpdateMs >= 200) {
                            lastProgressUpdateMs = nowMs
                            val pct = if (actualSize > 0) ((sent * 100) / actualSize).toInt() else 0
                            withContext(Dispatchers.Main) { updateProgress(pct, sent, actualSize, rollingSpeedMBps()) }
                        }
                    }
                    inputStream.close()

                    if (transferCancelled) { status = "cancelled"; break }

                    // Send CRC32 for verification
                    output.writeInt(crc.value.toInt())
                }
                output.flush()

                withContext(Dispatchers.Main) {
                    showProgressUI(false, "", 0)
                    when (status) {
                        "cancelled" -> updateStatus("⛔ Transfer cancelled")
                        else -> {
                            updateStatus("✅ Sent ${filesToSend.size} file(s) — ${Utils.formatSize(totalBytesSent)} total")
                            showToast("${filesToSend.size} file(s) sent!")
                        }
                    }
                }

            } catch (e: Exception) {
                status = "failed"
                Log.e(TAG, "Send error: ${e.message}")
                withContext(Dispatchers.Main) {
                    showProgressUI(false, "", 0)
                    updateStatus("❌ Send failed: ${e.message}")
                    showToast("Send failed: ${e.message}")
                }
            } finally {
                try { socket?.close() } catch (_: Exception) {}

                // Delete temp text snippets written to cacheDir
                filesToSend.forEach { f ->
                    if (f.uri.scheme == "file" &&
                        f.uri.path?.startsWith(cacheDir.path) == true) {
                        try { File(f.uri.path!!).delete() } catch (_: Exception) {}
                    }
                }

                // Save to history
                HistoryManager.add(this@MainActivity, TransferRecord(
                    id         = UUID.randomUUID().toString(),
                    timestamp  = System.currentTimeMillis(),
                    direction  = "sent",
                    fileNames  = filesToSend.map { it.name },
                    totalBytes = totalBytesSent,
                    peerName   = peerDeviceName,
                    status     = status
                ))
            }
        }
    }

    private fun openFileStream(file: SelectedFile): InputStream? {
        return if (file.uri.scheme == "file") {
            try { FileInputStream(File(file.uri.path!!)) } catch (_: Exception) { null }
        } else {
            contentResolver.openInputStream(file.uri)
        }
    }

    /**
     * Resolves the true file size before sending.
     * OpenableColumns.SIZE can return 0 for some content providers (Downloads,
     * cloud files, Files by Google). openFileDescriptor.statSize is reliable.
     */
    private fun resolveActualSize(file: SelectedFile): Long {
        if (file.uri.scheme == "file") return File(file.uri.path!!).length()
        return try {
            contentResolver.openFileDescriptor(file.uri, "r")?.use { it.statSize } ?: file.size
        } catch (_: Exception) { file.size }
    }

    private suspend fun connectToHost(hostIp: String): Socket {
        val maxAttempts = 3
        var lastException: Exception? = null
        for (attempt in 1..maxAttempts) {
            try {
                val s = Socket()
                s.sendBufferSize    = BUFFER_SIZE * 4  // 2 MB send window
                s.receiveBufferSize = BUFFER_SIZE * 4
                s.tcpNoDelay        = true
                s.setPerformancePreferences(0, 0, 1)   // bandwidth over latency/connection-time
                boundNetwork?.bindSocket(s)
                s.connect(InetSocketAddress(hostIp, SERVER_PORT), 6000)
                return s
            } catch (e: Exception) {
                lastException = e
                if (attempt < maxAttempts) {
                    withContext(Dispatchers.Main) { updateStatus("Attempt $attempt failed — retrying…") }
                    delay(2000)
                }
            }
        }
        throw lastException ?: IOException("Could not connect after $maxAttempts attempts")
    }

    // ── UI Helpers ────────────────────────────────────────────────────────────

    private fun updateStatus(msg: String) { binding.tvStatus.text = msg }

    private fun updateConnectionUI(connected: Boolean) {
        binding.btnDisconnect.visibility = if (connected) View.VISIBLE else View.GONE
        binding.btnSendFile.isEnabled    = connected && selectedFiles.isNotEmpty()
        if (!connected) {
            connectedDeviceInfo = null; isHotspotMode = false; boundNetwork = null
        }
    }

    private fun showProgressUI(
        show: Boolean, fileName: String, fileSize: Long,
        fileIndex: Int = 1, fileCount: Int = 1
    ) {
        binding.cardProgress.visibility      = if (show) View.VISIBLE else View.GONE
        binding.btnCancelTransfer.visibility = if (show) View.VISIBLE else View.GONE
        binding.btnCancelTransfer.isEnabled  = show

        if (show) {
            binding.tvProgressFile.text      = fileName
            binding.tvProgressSize.text      = Utils.formatSize(fileSize)
            binding.progressTransfer.progress = 0
            binding.tvProgressPercent.text   = "0%"
            binding.tvProgressSpeed.text     = ""
            if (fileCount > 1) {
                binding.tvProgressFileCount.text       = "File $fileIndex / $fileCount"
                binding.tvProgressFileCount.visibility = View.VISIBLE
            } else {
                binding.tvProgressFileCount.visibility = View.GONE
            }
        }
    }

    private fun updateProgress(percent: Int, transferred: Long, total: Long, speedMBps: Double) {
        binding.progressTransfer.progress     = percent
        binding.tvProgressPercent.text        = "$percent%"
        binding.tvProgressTransferred.text    = "${Utils.formatSize(transferred)} / ${Utils.formatSize(total)}"
        binding.tvProgressSpeed.text          = "${String.format("%.1f", speedMBps)} MB/s"
    }

    private fun getFileInfo(uri: Uri): Pair<String, Long> {
        if (uri.scheme == "file") {
            val f = File(uri.path!!); return Pair(f.name, f.length())
        }
        var name = "unknown_file"; var size = 0L
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val ni = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val si = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (ni >= 0) name = cursor.getString(ni) ?: name
                if (si >= 0) size = cursor.getLong(si)
            }
        }
        return Pair(name, size)
    }

    private fun getUniqueFileName(dir: File, name: String): String {
        var result = name; var counter = 1
        while (File(dir, result).exists()) {
            val dot = name.lastIndexOf('.')
            result  = if (dot > 0) "${name.substring(0, dot)}($counter)${name.substring(dot)}" else "$name($counter)"
            counter++
        }
        return result
    }

    private fun hasLocationPerm(): Boolean {
        val hasLocation = ActivityCompat.checkSelfPermission(
            this, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        val hasNearby = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ActivityCompat.checkSelfPermission(
                this, Manifest.permission.NEARBY_WIFI_DEVICES
            ) == PackageManager.PERMISSION_GRANTED
        } else true
        return hasLocation && hasNearby
    }

    private fun showToast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
