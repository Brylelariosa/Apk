/* AI Empire Tycoon - isometric campus renderer (canvas 2D, sprite cached, mobile friendly) */
(function () {
  'use strict';
  const G = window.G, D = G.D, U = G.U, A = G.art;
  const S = (G.scene = {});
  const P = A.P;
  const clamp = U.clamp;
  let cv = null, c = null, W = 300, H = 300, dpr = 1;
  let cache = {}, items = [], land = null, landSig = '', roads = [], sites = [], decor = null;
  let people = [], sig = '', lastT = 0, T = 0, frames = 0;
  let pickObj = null, pickT = 0;
  const cam = { x: 0, y: 0, z: 1, tx: 0, ty: 0, tz: 1, manual: false };
  S.q = 1;
  S.view = 'all';
  S.onPick = null;
  S.visible = false;
  const popAt = {};
  const SKIN = () => G.state.pres.skin || 'midnight';
  const PLOTS = {
    hq: [1, 1, 5, 5], lab: [8.1, 1.3, 5, 4.4], cool: [A.COOLX, 7.6, 1.2, 4.8], net: [6.3, 5.0, 1.0, 1.0]
  };
  const PWR = { 1: [14.3, 1.1, 2, 2], 2: [16.9, 1.0, 4, 3.2], 3: [14.3, 3.7, 2.6, 2.6], 4: [17.4, 4.4, 3, 3] };
  const TREES = [[0.4, 6.2], [0.5, 12.6], [6.6, 20], [0.4, 19.4], [8.4, 6.5], [13.6, 6.6], [20.8, 6.6], [14.1, 14.6], [21.4, 15.4], [18.1, 21.8], [21.2, 20.6], [0.6, 3.4], [7.4, 4.4], [13.8, 0.5], [21.3, 0.8]];

  /* ---------- setup ---------- */
  S.init = function (canvas) {
    cv = canvas; c = cv.getContext('2d');
    bindInput();
    S.resize();
  };
  S.resize = function () {
    if (!cv) return;
    const r = cv.parentElement.getBoundingClientRect();
    if (r.width < 10 || r.height < 10) return;
    const nd = Math.min(window.devicePixelRatio || 1, S.q === 0 ? 1.25 : 2);
    if (r.width === W && r.height === H && nd === dpr) return;
    W = r.width; H = r.height; dpr = nd;
    cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr);
    cv.style.width = W + 'px'; cv.style.height = H + 'px';
    const res = clamp(dpr * (S.q === 0 ? 0.7 : 0.8), 1, 1.75);
    if (Math.abs(res - A.res) > 0.01) { A.res = res; cache = {}; land = null; decor = null; sig = ''; }
    S.fit(true);
  };
  S.setQuality = function (q) {
    if (q === S.q) return;
    S.q = q;
    S.resize();
    sig = '';
  };

  /* ---------- state -> items ---------- */
  function mixOf(s) { return D.hw.map((h) => s.inf[h.k] || 0); }
  function quant(mix) { const t = mix.reduce((a, b) => a + b, 0) || 1; return mix.map((m) => Math.round((m / t) * 8)).join(''); }
  function signature() {
    const s = G.state, i = s.inf;
    return [SKIN(), i.hq, i.lab, i.dc, i.cool, i.pwr, i.net, i.racks, D.hw.map((h) => i[h.k]).join(','), s.build.map((b) => b.k + b.to).join(','), S.q].join('|');
  }
  function mk(id, sg, make) {
    const e = cache[id];
    if (e && e.sig === sg) return e;
    const obj = make();
    const spr = A.sprite(obj.b, obj.draw);
    let led = null;
    if (obj.leds && S.q > 0) led = [0, 1, 2].map((k) => A.sprite(obj.ledB, (cc) => obj.leds(cc, k), Math.min(A.res, 1.0)));
    const poly = hitPoly(obj.fp);
    return (cache[id] = { sig: sg, obj, spr, led, poly, depth: obj.fp[0] + obj.fp[2] + obj.fp[1] + obj.fp[3] });
  }
  function hitPoly(fp) {
    const [x, y, w, d, h] = fp;
    return [P(x, y, h), P(x + w, y, h), P(x + w, y, 0), P(x + w, y + d, 0), P(x, y + d, 0), P(x, y + d, h)];
  }
  S.sync = function (force) {
    if (!cv) return;
    const sg = signature();
    if (sg === sig && !force) return;
    sig = sg;
    build();
  };
  function build() {
    const s = G.state, pal = A.palette(SKIN()), inf = s.inf, sk = SKIN();
    const list = [];
    const keep = {};
    const add = (id, sg, make) => { const e = mk(id, sg, make); keep[id] = 1; list.push(e); return e; };
    add('hq', 'hq' + inf.hq + sk, () => A.hq(inf.hq, pal));
    if (inf.lab >= 1) add('lab', 'lab' + inf.lab + sk, () => A.lab(inf.lab, pal));
    add('dc0', 'shed' + sk, () => A.shed(pal));
    const mix = mixOf(s), mq = quant(mix), caps = D.ladders.dc.map((t) => t.racks);
    for (let lv = 1; lv <= inf.dc; lv++) {
      const lo = caps[lv - 1], cap = caps[lv] - lo, n = clamp(inf.racks - lo, 0, cap);
      const g = A.hallGrid(lv), pos = g.cols * g.rows, draw = n <= 0 ? 0 : Math.max(1, Math.min(pos, Math.round(pos * Math.min(1, n / cap))));
      add('dc' + lv, ['hall', lv, draw, mq, inf.cool, sk].join('|'), () => A.hall(lv, n, cap, mix, inf.cool, pal));
    }
    if (inf.dc >= 1) add('cool', 'cool' + inf.cool + sk, () => A.cooling(inf.cool, pal));
    for (let lv = 1; lv <= Math.min(4, inf.pwr); lv++) add('pwr' + lv, 'pwr' + lv + sk, () => A.power(lv, pal));
    if (inf.net >= 1) add('net', 'net' + inf.net + sk, () => A.tower(inf.net, pal));
    // construction sites (new buildings) and crane overlays (upgrades)
    sites = [];
    for (const b of s.build) {
      let fp = null, isNew = false;
      if (b.k === 'dc') { const h = A.HALLS[b.to]; fp = [h.x, h.y, h.w, h.d]; isNew = true; }
      else if (b.k === 'lab') { fp = PLOTS.lab; isNew = b.to === 1; }
      else if (b.k === 'pwr') { fp = PWR[b.to] || null; isNew = !!fp; }
      else if (PLOTS[b.k]) fp = PLOTS[b.k];
      if (!fp) continue;
      let e = null;
      if (isNew) e = add('site' + b.k + b.to, 'site' + fp.join(','), () => A.site(fp));
      sites.push({ b, fp, e });
    }
    for (const id in cache) if (!keep[id]) delete cache[id];
    items = list.sort((a, b) => a.depth - b.depth);
    // land and roads
    let lx = 9.2, ly = 7.8;
    for (const e of items) { lx = Math.max(lx, e.obj.fp[0] + e.obj.fp[2] + 1.3); ly = Math.max(ly, e.obj.fp[1] + e.obj.fp[3] + 1.3); }
    roads = [[2.4, 6.9, inf.lab >= 1 ? 12.2 : 7.9, 6.9]];
    if (inf.dc >= 2) roads.push([7.9, 6.9, 7.9, inf.dc >= 3 ? 13.2 : 12.6]);
    if (inf.dc >= 3) roads.push([7.9, 13.2, inf.dc >= 5 ? 15.6 : 8.5, 13.2]);
    if (inf.dc >= 4) roads.push([8.5, 13.2, 8.5, 19.6]);
    const ls = lx.toFixed(1) + ',' + ly.toFixed(1) + sk + roads.join(';');
    if (!land || ls !== landSig) { landSig = ls; land = A.land(lx, ly, pal, roads); land.lx = lx; land.ly = ly; }
    // decor trees
    if (!decor) decor = TREES.map((t, i) => ({ x: t[0], y: t[1], s: 0.8 + (i % 3) * 0.14, col: ['#3fa37a', '#4bb58a', '#37966f'][i % 3] }));
    if (!cam.manual) S.fit(false);
  }

  /* ---------- camera ---------- */
  S.fit = function (snap) {
    if (!items.length) { sig = ''; if (G.state) S.sync(true); if (!items.length) return; }
    let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
    const use = S.view === 'dc' ? items.filter((e) => e.obj.kind === 'dc' || e.obj.kind === 'cool') : items;
    for (const e of (use.length ? use : items)) { const b = e.obj.b; x0 = Math.min(x0, b[0]); y0 = Math.min(y0, b[1]); x1 = Math.max(x1, b[2]); y1 = Math.max(y1, b[3]); }
    for (const sx of sites) { const f = sx.fp; x0 = Math.min(x0, P(f[0], f[1] + f[3])[0] - 10); x1 = Math.max(x1, P(f[0] + f[2], f[1])[0] + 10); y1 = Math.max(y1, P(f[0] + f[2], f[1] + f[3])[1] + 10); y0 = Math.min(y0, P(f[0], f[1], 90)[1]); }
    const pad = 30, bw = x1 - x0 + pad * 2, bh = y1 - y0 + pad * 2;
    cam.tz = clamp(Math.min(W / bw, H / bh), 0.22, S.view === 'dc' ? 1.25 : 1.15);
    let cx = (x0 + x1) / 2, cy = (y0 + y1) / 2;
    if (land && S.view !== 'dc') { const lcy = (P(0, 0)[1] + P(land.lx, land.ly)[1]) / 2; cy = (cy + lcy) / 2; }
    cam.tx = cx; cam.ty = cy;
    if (snap || !cam.init) { cam.x = cam.tx; cam.y = cam.ty; cam.z = cam.tz; cam.init = true; }
    cam.manual = false;
  };
  S.setView = function (v) { if (S.view !== v) { S.view = v; S.fit(false); } };
  S.recenter = function () { S.fit(false); };
  S.pop = function (id) { popAt[id] = T; S.sync(true); };

  /* ---------- input ---------- */
  function bindInput() {
    const ptr = new Map();
    let down = null, pinch = 0;
    const rel = (e) => { const r = cv.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; };
    cv.addEventListener('pointerdown', (e) => {
      cv.setPointerCapture(e.pointerId);
      ptr.set(e.pointerId, rel(e));
      down = { p: rel(e), moved: false, t: performance.now() };
      if (ptr.size === 2) { const a = [...ptr.values()]; pinch = Math.hypot(a[0][0] - a[1][0], a[0][1] - a[1][1]); down.moved = true; }
    });
    cv.addEventListener('pointermove', (e) => {
      if (!ptr.has(e.pointerId)) return;
      const p = rel(e), old = ptr.get(e.pointerId);
      ptr.set(e.pointerId, p);
      if (ptr.size === 2) {
        const a = [...ptr.values()], d = Math.hypot(a[0][0] - a[1][0], a[0][1] - a[1][1]);
        if (pinch > 0) zoomAt((a[0][0] + a[1][0]) / 2, (a[0][1] + a[1][1]) / 2, d / pinch);
        pinch = d; cam.manual = true;
      } else if (ptr.size === 1) {
        if (!down.moved && Math.hypot(p[0] - down.p[0], p[1] - down.p[1]) > 6) down.moved = true;
        if (down.moved) { cam.x -= (p[0] - old[0]) / cam.z; cam.y -= (p[1] - old[1]) / cam.z; cam.tx = cam.x; cam.ty = cam.y; cam.manual = true; }
      }
    });
    const up = (e) => {
      const had = ptr.has(e.pointerId);
      ptr.delete(e.pointerId);
      if (had && ptr.size === 0 && down && !down.moved && performance.now() - down.t < 500) S.tap(down.p[0], down.p[1]);
      if (ptr.size < 2) pinch = 0;
    };
    cv.addEventListener('pointerup', up); cv.addEventListener('pointercancel', up);
    cv.addEventListener('wheel', (e) => { e.preventDefault(); const p = rel(e); zoomAt(p[0], p[1], Math.exp(-e.deltaY * 0.0015)); cam.manual = true; }, { passive: false });
    cv.addEventListener('dblclick', () => S.recenter());
  }
  function zoomAt(sx, sy, f) {
    const nz = clamp(cam.z * f, 0.2, 2.2);
    const ix = (sx - W / 2) / cam.z + cam.x, iy = (sy - H / 2) / cam.z + cam.y;
    cam.z = cam.tz = nz;
    cam.x = cam.tx = ix - (sx - W / 2) / nz; cam.y = cam.ty = iy - (sy - H / 2) / nz;
  }
  function inPoly(p, poly) {
    let ins = false;
    for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
      const a = poly[i], b = poly[j];
      if ((a[1] > p[1]) !== (b[1] > p[1]) && p[0] < ((b[0] - a[0]) * (p[1] - a[1])) / (b[1] - a[1]) + a[0]) ins = !ins;
    }
    return ins;
  }
  S.tap = function (sx, sy) {
    const p = [(sx - W / 2) / cam.z + cam.x, (sy - H / 2) / cam.z + cam.y];
    for (let i = items.length - 1; i >= 0; i--) {
      const e = items[i];
      if (e.obj.kind === 'site') continue;
      if (inPoly(p, e.poly)) { pickObj = e; pickT = T; if (S.onPick) S.onPick(e.obj); return e.obj; }
    }
    pickObj = null;
    if (S.onPick) S.onPick(null);
    return null;
  };

  /* ---------- drawing helpers ---------- */
  function fan(x, y, r, spin) {
    c.save(); c.translate(x, y); c.scale(1, 0.55); c.rotate(T * spin);
    c.fillStyle = 'rgba(14,22,44,.9)'; c.beginPath(); c.arc(0, 0, r, 0, 6.283); c.fill();
    c.strokeStyle = 'rgba(200,218,245,.9)'; c.lineWidth = 1.8; c.beginPath();
    for (let i = 0; i < 3; i++) { const a = i * 2.094; c.moveTo(0, 0); c.lineTo(Math.cos(a) * r * 0.92, Math.sin(a) * r * 0.92); }
    c.stroke(); c.restore();
  }
  function puffs(x, y, n, col, rise, size, speed) {
    for (let k = 0; k < n; k++) {
      const ph = (T * (speed || 0.3) + k / n) % 1;
      c.globalAlpha = (1 - ph) * 0.4; c.fillStyle = col;
      c.beginPath(); c.ellipse(x + Math.sin(ph * 6 + k * 2) * 4, y - ph * rise, size * (0.6 + ph), size * (0.42 + ph * 0.6), 0, 0, 6.283); c.fill();
    }
    c.globalAlpha = 1;
  }
  function glow(x, y, r, hex, a) {
    c.globalAlpha = a; c.drawImage(A.glow(hex), x - r, y - r, r * 2, r * 2); c.globalAlpha = 1;
  }
  function orb(o, active) {
    const x = o.p[0], y = o.p[1], r = o.r, pts = [];
    for (let i = 0; i < 7; i++) { const a = T * (active ? 1.3 : 0.6) + i * 0.9; pts.push([x + Math.cos(a) * r, y + Math.sin(a) * r * 0.55 + Math.sin(T * 1.3 + i) * 2.5]); }
    c.strokeStyle = U.rgba('#9be7ff', 0.55); c.lineWidth = 1; c.beginPath();
    for (let i = 0; i < 7; i++) { c.moveTo(pts[i][0], pts[i][1]); c.lineTo(pts[(i + 1) % 7][0], pts[(i + 1) % 7][1]); c.moveTo(pts[i][0], pts[i][1]); c.lineTo(pts[(i + 3) % 7][0], pts[(i + 3) % 7][1]); }
    c.stroke();
    c.fillStyle = '#eafcff';
    for (const p of pts) { c.beginPath(); c.arc(p[0], p[1], 1.8, 0, 6.283); c.fill(); }
  }
  function ring(o, spd) {
    const p = o.c;
    c.strokeStyle = U.rgba(G.art.palette(SKIN()).acc, 0.95); c.lineWidth = 2.4;
    for (let k = 0; k < 2; k++) { const a = T * spd + k * Math.PI; c.beginPath(); c.ellipse(p[0], p[1], o.rx, o.ry, 0, a, a + 1.9); c.stroke(); }
  }
  function ground(e) {
    const dt = T - (popAt[e.obj.id] || -9);
    return dt >= 0 && dt < 1.2 ? dt / 1.2 : 1;
  }
  S.popAt = (id) => popAt[id];

  function drawItem(e) {
    const o = e.obj, k = ground(e);
    const spr = e.spr;
    if (k < 1) {
      const ez = U.ease.out(k);
      c.globalAlpha = Math.min(1, ez * 1.4); c.save(); c.translate(0, (1 - ez) * -26);
      c.drawImage(spr.cv, spr.x, spr.y, spr.w, spr.h); c.restore(); c.globalAlpha = 1;
      const f = o.fp, cp = P(f[0] + f[2] / 2, f[1] + f[3] / 2), rr = (f[2] + f[3]) * 24 * ez;
      c.strokeStyle = 'rgba(160,240,230,' + (0.6 * (1 - k)) + ')'; c.lineWidth = 2; c.beginPath(); c.ellipse(cp[0], cp[1], rr, rr * 0.5, 0, 0, 6.283); c.stroke();
    } else c.drawImage(spr.cv, spr.x, spr.y, spr.w, spr.h);
    if (e.led && S.q > 0) {
      const L = e.led[S.q === 1 ? (Math.floor(T * 2.5 + o.lv) % 3) : (Math.floor(T * 4 + o.lv * 1.7) % 3)];
      c.drawImage(L.cv, L.x, L.y, L.w, L.h);
    }
    if (S.q === 0) return;
    if (o.fans) for (const f of o.fans) fan(f.p[0], f.p[1], f.r, 7 + (G.C ? G.C.util * 4 : 0));
    if (o.screens) { c.fillStyle = 'rgba(150,240,255,' + (0.25 + 0.2 * Math.sin(T * 5)) + ')'; for (const q of o.screens) { c.beginPath(); c.moveTo(q[0][0], q[0][1]); for (let i = 1; i < 4; i++) c.lineTo(q[i][0], q[i][1]); c.closePath(); c.fill(); } }
    if (o.ledPts) for (let i = 0; i < o.ledPts.length; i++) { c.fillStyle = Math.sin(T * 6 + i * 2) > 0 ? '#2be3b8' : '#1a4f4a'; c.fillRect(o.ledPts[i][0] - 1.5, o.ledPts[i][1] - 1, 3, 2); }
    if (o.lights) o.lights.forEach((p, i) => { c.fillStyle = 'rgba(255,214,150,' + (0.55 + 0.4 * Math.sin(T * 3 + i)) + ')'; c.beginPath(); c.arc(p[0], p[1], 1.6, 0, 6.283); c.fill(); });
    if (o.smoke) for (const sm of o.smoke) puffs(sm.p[0], sm.p[1], S.q === 2 ? 4 : 2, 'rgba(210,220,235,1)', 40, 7 * sm.s, 0.25);
    if (o.bubbles) for (const b of o.bubbles) {
      if (b.mist) puffs(b.p[0], b.p[1], 3, 'rgba(190,225,255,1)', 26, 6, 0.35);
      else { c.fillStyle = 'rgba(200,245,255,.7)'; for (let i = 0; i < 4; i++) { const ph = (T * 0.6 + i / 4) % 1; c.beginPath(); c.arc(b.p[0] - 6 + i * 4, b.p[1] + 10 - ph * 16, 1.4, 0, 6.283); c.fill(); } }
    }
    if (o.ring) ring(o.ring, o.ring.small ? 1.4 : 0.9);
    if (o.ringC) { const rc = { c: o.ringC, rx: 62, ry: 24 }; ring(rc, 0.7); }
    if (o.orb) orb(o.orb, G.state.res.q.length > 0);
    if (o.beacon) { c.fillStyle = Math.sin(T * 3) > 0.1 ? '#ff4d5e' : '#5a2430'; c.beginPath(); c.arc(o.beacon[0], o.beacon[1], 2.2, 0, 6.283); c.fill(); }
    if (o.top) { c.fillStyle = Math.sin(T * 4 + 1) > 0 ? '#ff4d5e' : '#5a2430'; c.beginPath(); c.arc(o.top[0], o.top[1], 2, 0, 6.283); c.fill(); }
    if (o.seats && S.q > 0) o.seats.forEach((s, i) => { const p = P(s[0], s[1], 4 + 3); A.person(c, p[0], p[1] + 2, T * 7 + i, ['#ff9f6b', '#6bb8ff', '#b78cff', '#6be3b0', '#ffd16b', '#ff7f9e'][i % 6], true); });
  }
  function drawGlows() {
    c.globalCompositeOperation = 'lighter';
    const pulse = 0.75 + 0.25 * Math.sin(T * 1.6);
    for (const e of items) {
      const gl = e.obj.glow;
      if (!gl) continue;
      for (const g of gl) glow(g.p[0], g.p[1], g.r, g.c, g.a * pulse * (e.obj.kind === 'dc' && G.C ? 0.6 + 0.6 * Math.min(1, G.C.util) : 1));
    }
    if (S.q === 2) {
      for (const e of items) if (e.obj.kind === 'dc' && e.obj.racks) { /* extra soft floor light */ }
    }
    c.globalCompositeOperation = 'source-over';
  }

  /* ---------- people and data flow ---------- */
  function ensurePeople() {
    const s = G.state, staff = D.ladders.hq[s.inf.hq].staff;
    const want = S.q === 0 ? 0 : Math.min(S.q === 1 ? 6 : 12, Math.max(1, Math.round(staff / 8) + (s.inf.dc >= 1 ? 1 : 0) + s.inf.hq));
    while (people.length < want) people.push({ r: Math.floor(Math.random() * 99), u: Math.random(), d: Math.random() < 0.5 ? 1 : -1, v: 0.035 + Math.random() * 0.04, col: ['#ff9f6b', '#6bb8ff', '#b78cff', '#6be3b0', '#ffd16b', '#ff7f9e', '#e9eef8'][people.length % 7], ph: Math.random() * 6 });
    while (people.length > want) people.pop();
  }
  function roadPos(r, u) { const a = roads[r % roads.length]; return [U.lerp(a[0], a[2], u), U.lerp(a[1], a[3], u)]; }
  function drawFlow(dt) {
    if (!roads.length) return;
    const nl = G.state.inf.net;
    c.strokeStyle = U.rgba(A.palette(SKIN()).acc, 0.22); c.lineWidth = 1.4;
    c.beginPath();
    for (const r of roads) { const a = P(r[0], r[1]), b = P(r[2], r[3]); c.moveTo(a[0], a[1] - 1); c.lineTo(b[0], b[1] - 1); }
    c.stroke();
    if (S.q === 0) return;
    const n = (S.q === 1 ? 6 : 12) + nl * 2;
    c.globalCompositeOperation = 'lighter';
    const col = A.palette(SKIN()).acc;
    for (let i = 0; i < n; i++) {
      const r = roads[i % roads.length], u = (T * (0.14 + nl * 0.03) + i * 0.37) % 1;
      const p = P(U.lerp(r[0], r[2], u), U.lerp(r[1], r[3], u));
      glow(p[0], p[1] - 2, 7, col, 0.9);
    }
    c.globalCompositeOperation = 'source-over';
  }
  function drawPerson(pe) {
    const [x, y] = roadPos(pe.r, pe.u), p = P(x, y + (pe.r % 2 ? 0.25 : -0.25));
    A.person(c, p[0], p[1], pe.ph, pe.col, false);
  }

  /* ---------- construction ---------- */
  function drawSites() {
    for (const sx of sites) {
      const f = sx.fp, frac = 1 - sx.b.left / Math.max(1, sx.b.total);
      const top = P(f[0] + f[2] - 0.5, f[1] + f[3] - 0.5, 90);
      if (!sx.e) {
        const base = P(f[0] + f[2] - 0.4, f[1] + f[3] + 0.4, 2);
        c.strokeStyle = '#e8b030'; c.lineWidth = 2.2; c.beginPath(); c.moveTo(base[0], base[1]); c.lineTo(base[0], base[1] - 88); c.stroke();
        top[0] = base[0]; top[1] = base[1] - 88;
      }
      const a = T * 0.6 + sx.b.to, jx = Math.cos(a) * 34, jy = Math.sin(a) * 17;
      c.strokeStyle = '#e8b030'; c.lineWidth = 2; c.beginPath(); c.moveTo(top[0], top[1]); c.lineTo(top[0] + jx, top[1] + jy); c.stroke();
      c.strokeStyle = 'rgba(255,255,255,.5)'; c.lineWidth = 1; c.beginPath(); c.moveTo(top[0] + jx, top[1] + jy); c.lineTo(top[0] + jx, top[1] + jy + 14 + Math.sin(T * 2) * 3); c.stroke();
      // scaffold rising with progress
      if (sx.e) {
        const hh = 8 + 40 * frac, x = f[0], y = f[1], w = f[2], d = f[3];
        c.strokeStyle = 'rgba(255,200,90,.65)'; c.lineWidth = 1;
        for (const [px, py] of [[x, y + d], [x + w, y + d], [x + w, y]]) { const p0 = P(px, py, 2), p1 = P(px, py, 2 + hh); c.beginPath(); c.moveTo(p0[0], p0[1]); c.lineTo(p1[0], p1[1]); c.stroke(); }
        const q0 = P(x, y + d, 2 + hh), q1 = P(x + w, y + d, 2 + hh), q2 = P(x + w, y, 2 + hh); c.beginPath(); c.moveTo(q0[0], q0[1]); c.lineTo(q1[0], q1[1]); c.lineTo(q2[0], q2[1]); c.stroke();
      }
      // progress bar
      const bx = P(f[0] + f[2] / 2, f[1] + f[3] / 2, 70);
      const bw = 62;
      c.fillStyle = 'rgba(8,14,30,.85)'; rrect(bx[0] - bw / 2 - 2, bx[1] - 18, bw + 4, 14, 7); c.fill();
      c.fillStyle = '#3dd6c6'; rrect(bx[0] - bw / 2, bx[1] - 16, Math.max(6, bw * frac), 10, 5); c.fill();
      c.fillStyle = '#fff'; c.font = '600 8px system-ui, sans-serif'; c.textAlign = 'center'; c.fillText(Math.floor(frac * 100) + '%', bx[0], bx[1] - 8.4);
    }
  }
  function rrect(x, y, w, h, r) { c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath(); }

  /* ---------- frame ---------- */
  S.render = function (nowMs) {
    if (!cv || !c || !G.state) return 0;
    const t0 = performance.now();
    const dt = lastT ? Math.min(0.1, (nowMs - lastT) / 1000) : 0.033;
    lastT = nowMs; T += dt; frames++;
    S.resize();
    if (frames % 15 === 1) S.sync();
    const k = 1 - Math.exp(-dt * 5);
    cam.x += (cam.tx - cam.x) * (cam.manual ? 0 : k); cam.y += (cam.ty - cam.y) * (cam.manual ? 0 : k); cam.z += (cam.tz - cam.z) * (cam.manual ? 0 : k);
    ensurePeople();
    for (const pe of people) { pe.u += pe.d * pe.v * dt * 4; pe.ph += dt * 9; if (pe.u > 1 || pe.u < 0) { pe.d *= -1; pe.u = clamp(pe.u, 0, 1); if (Math.random() < 0.4) pe.r = Math.floor(Math.random() * 99); } }
    c.setTransform(1, 0, 0, 1, 0, 0);
    c.clearRect(0, 0, cv.width, cv.height);
    const z = cam.z * dpr;
    c.setTransform(z, 0, 0, z, dpr * W / 2 - cam.x * z, dpr * H / 2 - cam.y * z);
    c.imageSmoothingQuality = 'medium';
    if (land) {
      const w = P(0, land.ly), sP = P(land.lx, land.ly);
      const gx = (P(land.lx, 0)[0] + P(0, land.ly)[0]) / 2, gy = (P(0, 0)[1] + sP[1]) / 2 + 30, gr = (land.lx + land.ly) * 20;
      const gg = c.createRadialGradient(gx, gy, 0, gx, gy, gr);
      gg.addColorStop(0, 'rgba(61,214,198,.16)'); gg.addColorStop(1, 'rgba(61,214,198,0)');
      c.fillStyle = gg; c.fillRect(gx - gr, gy - gr, gr * 2, gr * 2);
      c.drawImage(land.cv, land.x, land.y, land.w, land.h);
    }
    drawFlow(dt);
    // sorted draw of buildings, trees and people
    const dl = [];
    for (const e of items) dl.push([e.depth, 0, e]);
    if (decor) for (const d of decor) if (land && d.x < land.lx - 0.3 && d.y < land.ly - 0.3 && !blocked(d.x, d.y)) dl.push([d.x + d.y + 0.3, 1, d]);
    for (const pe of people) { const [x, y] = roadPos(pe.r, pe.u); dl.push([x + y + 0.45 + (pe.r % 2 ? 0.25 : -0.25), 2, pe]); }
    dl.sort((a, b) => a[0] - b[0]);
    for (const [, kind, o] of dl) {
      if (kind === 0) drawItem(o);
      else if (kind === 1) { const p = P(o.x, o.y); A.tree(c, p[0], p[1], o.s, o.col); }
      else drawPerson(o);
    }
    drawSites();
    if (S.q > 0) drawGlows();
    if (pickObj && T - pickT < 4) {
      const e = pickObj, a = 0.5 + 0.3 * Math.sin(T * 5);
      c.strokeStyle = 'rgba(120,255,235,' + a + ')'; c.lineWidth = 2.2; c.beginPath();
      e.poly.forEach((p, i) => (i ? c.lineTo(p[0], p[1]) : c.moveTo(p[0], p[1]))); c.closePath(); c.stroke();
    }
    return performance.now() - t0;
  };
  function blocked(x, y) {
    for (const e of items) { const f = e.obj.fp; if (x > f[0] - 0.9 && x < f[0] + f[2] + 0.9 && y > f[1] - 0.9 && y < f[1] + f[3] + 0.9) return true; }
    for (const r of roads) { if (Math.abs(r[1] - r[3]) < 0.01 ? (Math.abs(y - r[1]) < 0.9 && x > r[0] - 0.5 && x < r[2] + 0.5) : (Math.abs(x - r[0]) < 0.9 && y > r[1] - 0.5 && y < r[3] + 0.5)) return true; }
    for (const sx of sites) { const f = sx.fp; if (x > f[0] - 1 && x < f[0] + f[2] + 1 && y > f[1] - 1 && y < f[1] + f[3] + 1) return true; }
    return false;
  }
  S.itemInfo = function (obj) { return obj; };
  S.getCam = () => cam;
  S.__dbg = () => { let px = 0, n = 0; for (const k in cache) { const e = cache[k]; px += e.spr.cv.width * e.spr.cv.height; n++; if (e.led) for (const l of e.led) { px += l.cv.width * l.cv.height; n++; } } if (land) { px += land.cv.width * land.cv.height; n++; } return { sprites: n, megapixels: +(px / 1e6).toFixed(2), mb: +(px * 4 / 1048576).toFixed(1), res: A.res, q: S.q, dpr }; };
})();
