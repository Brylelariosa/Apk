/* AI Empire Tycoon - UI core */
(function () {
  'use strict';
  const G = window.G, D = G.D, U = G.U, S = G.scene, h = U.h;
  const UI = (G.ui = {});
  const $ = (s, r) => (r || document).querySelector(s);
  const I = (n, s, c) => { const e = document.createElement('span'); e.className = 'icw'; e.innerHTML = U.ic(n, s || 18, c); return e; };
  UI.I = I; UI.$ = $;
  let tab = 'hq', binds = [], tabEl = null, modals = [], vp = null;
  const AN = {};
  UI.tabs = {};
  UI.st = { sheet: false, hqSeg: 'campus', bizSeg: 'overview', achSeg: 'missions', rSel: null, region: 'na', pick: null };
  UI.tab = () => tab;
  const LOGO = '<svg viewBox="0 0 48 48"><path d="M24 3l17.3 10v22L24 45 6.7 35V13z" fill="#0f1a3a" stroke="#4fe3d3" stroke-width="2.4" stroke-linejoin="round"/><path d="M24 24V12M24 24l10.5 6M24 24l-10.5 6" stroke="#4fe3d3" stroke-width="2" stroke-linecap="round" fill="none"/><circle cx="24" cy="24" r="4.6" fill="#f6b84a"/><circle cx="24" cy="11.5" r="2.8" fill="#8af0e6"/><circle cx="35" cy="30.5" r="2.8" fill="#8af0e6"/><circle cx="13" cy="30.5" r="2.8" fill="#8af0e6"/></svg>';
  UI.LOGO = LOGO;

  /* ---------- binding helpers ---------- */
  UI.bind = function (node, fn) { binds.push([node, fn]); try { fn(node); } catch (e) { if (G.err) G.err(e); } return node; };
  UI.slow = function () { for (let i = 0; i < binds.length; i++) { try { binds[i][1](binds[i][0]); } catch (e) { if (G.err) G.err(e); } } };
  const T = (n, s) => { if (n._t !== s) { n._t = s; n.textContent = s; } };
  const CL = (n, c, on) => { on = !!on; if (n['_c' + c] !== on) { n['_c' + c] = on; n.classList.toggle(c, on); } };
  const ST = (n, p, v) => { if (n['_s' + p] !== v) { n['_s' + p] = v; n.style[p] = v; } };
  const DIS = (n, on) => { on = !!on; if (n._d !== on) { n._d = on; n.disabled = on; n.classList.toggle('dis', on); } };
  UI.T = T; UI.CL = CL; UI.ST = ST; UI.DIS = DIS;
  function anim(id, node, get, fmt) { AN[id] = { node, get, fmt, cur: get() }; T(node, fmt(AN[id].cur)); }
  UI.fast = function (dt) {
    for (const k in AN) {
      const a = AN[k], t = a.get();
      a.cur += (t - a.cur) * (1 - Math.exp(-dt * 7));
      if (Math.abs(t - a.cur) <= Math.abs(t) * 1e-4 + 1e-9) a.cur = t;
      T(a.node, a.fmt(a.cur));
    }
  };

  /* ---------- components ---------- */
  UI.btn = function (label, o) {
    o = o || {};
    const b = h('button', { class: 'btn ' + (o.cls || ''), type: 'button' });
    if (o.icon) b.append(I(o.icon, 16));
    const l = h('span', { class: 'bl' }, label);
    b.append(l);
    b._l = l;
    if (o.onclick) b.addEventListener('click', (e) => { if (b.disabled) return; G.audio.init(); o.onclick(e); });
    return b;
  };
  UI.bar = function (cls) { const i = h('i'); const b = h('div', { class: 'bar ' + (cls || '') }, i); b._i = i; return b; };
  UI.setBar = function (b, f) { ST(b._i, 'width', Math.round(U.clamp(f, 0, 1) * 1000) / 10 + '%'); };
  UI.tile = function (label, node, cls) { return h('div', { class: 'tile ' + (cls || '') }, h('div', { class: 'tl' }, label), node); };
  UI.act = function (fn, sfx) {
    G.audio.init();
    const r = fn();
    G.audio.sfx(r && r.ok ? sfx || 'buy' : 'err');
    if (r && r.ok) { UI.refresh(); S.sync(true); }
    return r;
  };
  UI.sec = function (title, right) { return h('div', { class: 'sec' }, h('span', { class: 'micro' }, title), right || null); };
  const ago = (t) => { const s = Math.max(1, (Date.now() - t) / 1000); return s < 60 ? Math.floor(s) + 's ago' : s < 3600 ? Math.floor(s / 60) + 'm ago' : s < 86400 ? Math.floor(s / 3600) + 'h ago' : Math.floor(s / 86400) + 'd ago'; };

  /* ---------- top bar and navigation ---------- */
  function chip(label, icon, valNode, extra) {
    return h('div', { class: 'chip' }, h('span', { class: 'ci' }, I(icon, 16)), h('div', { class: 'grow' }, h('div', { class: 'cl' }, label), valNode, extra || null));
  }
  function buildTop() {
    const top = $('#top');
    top.textContent = '';
    const val = h('div', { class: 'valv' }), cash = h('div', { class: 'cashv' });
    const rev = h('div', { class: 'cv' }), users = h('div', { class: 'cv' }), model = h('div', { class: 'cv' }), cap = h('div', { class: 'cv' });
    const mini = h('div', { class: 'mini' }, h('i'));
    const gear = h('button', { class: 'gear', 'aria-label': 'Settings', onclick: () => { G.audio.init(); UI.settings(); }, html: U.ic('gear', 20) });
    top.append(
      h('div', { class: 'tb1' },
        h('div', { class: 'tbL' }, h('div', { class: 'logo', html: LOGO }), h('div', {}, h('div', { class: 'lbl' }, 'Company valuation'), val)),
        h('div', { class: 'tbR' }, h('div', { class: 'tbC' }, h('div', { class: 'lbl' }, 'Cash'), cash), gear)),
      h('div', { class: 'tb2' }, chip('Revenue', 'cash', rev), chip('Users', 'users', users), chip('Model', 'ai', model), chip('Servers', 'cpu', cap, mini))
    );
    anim('val', val, () => G.C.val, U.money);
    anim('cash', cash, () => G.state.cash, U.money);
    anim('rev', rev, () => G.C.rev.total, (v) => '$' + U.num(v) + '/s');
    anim('users', users, () => G.state.users, U.num);
    UI.topBind = () => {
      T(model, (D.mmap[G.state.active] || D.models[0]).name);
      T(cap, U.tf(G.C.capEff));
      const u = G.C.util;
      ST(mini._i0 || (mini._i0 = mini.firstChild), 'width', Math.min(100, u * 100).toFixed(0) + '%');
      ST(mini.firstChild, 'background', u > 1 ? 'var(--bad)' : u > 0.8 ? 'var(--warn)' : 'var(--good)');
      CL(rev, 'neg', G.C.net < 0);
    };
  }
  UI.buildChrome = function () { buildTop(); buildNav(); };
  const TABS = [['hq', 'HQ', 'hq', 'Headquarters'], ['models', 'Models', 'ai', 'AI Models'], ['research', 'Research', 'research', 'Research'], ['infra', 'Infra', 'infra', 'Infrastructure'], ['business', 'Business', 'business', 'Business'], ['global', 'Global', 'globe', 'Global Expansion'], ['achv', 'Goals', 'trophy', 'Achievements']];
  UI.TABS = TABS;
  function buildNav() {
    const nav = $('#nav');
    nav.textContent = '';
    for (const t of TABS) {
      const b = h('button', { class: 'nb', 'data-t': t[0], 'aria-label': t[3], onclick: () => { G.audio.init(); UI.go(t[0]); } }, I(t[2], 22), h('span', { class: 't' }, t[1]), h('i', { class: 'dot', hidden: true }));
      nav.append(b);
    }
  }
  UI.navDots = function () {
    const s = G.state, C = G.C;
    const trained = D.models.some((m) => (s.models[m.id] || {}).st === 'trained');
    const claim = s.daily.list.some((it) => !it.claimed && G.missionProg(it) >= it.goal);
    const flags = { models: trained, achv: claim || G.canReinvent(), research: s.res.q.length < C.resSlots && D.research.some((n) => G.researchStatus(n.id) === 'ready' && G.researchCost(n) <= s.cash) };
    document.querySelectorAll('#nav .nb').forEach((b) => { const d = b.querySelector('.dot'), on = !!flags[b.dataset.t]; if (d._o !== on) { d._o = on; d.hidden = !on; } });
  };

  /* ---------- tab router ---------- */
  UI.go = function (id, soft, keep) {
    if (!UI.tabs[id]) return;
    const prev = tab;
    tab = id;
    UI.tabChanged = prev !== id;
    binds = [];
    if (vp && vp.parentNode) vp.parentNode.removeChild(vp);
    S.visible = false;
    G.lab.visible = false; G.map.visible = false;
    const stage = $('#stage');
    stage.textContent = '';
    const el = h('section', { class: 'tab on tab-' + id, id: 'tab-' + id });
    if (soft) el.style.animation = 'none';
    el.append(UI.tabs[id]());
    stage.append(el);
    tabEl = el;
    document.querySelectorAll('#nav .nb').forEach((b) => b.classList.toggle('on', b.dataset.t === id));
    if (keep) el.querySelectorAll('[data-keep]').forEach((e) => { const k = keep[e.dataset.keep]; if (k) { e.scrollTop = k[0]; e.scrollLeft = k[1]; } });
    if (!soft && prev !== id) G.audio.sfx('tap');
    UI.slow();
  };
  let rq = 0;
  UI.refresh = function () {
    if (rq) return;
    rq = requestAnimationFrame(() => {
      rq = 0;
      if (!tabEl) return;
      const keep = {};
      tabEl.querySelectorAll('[data-keep]').forEach((e) => (keep[e.dataset.keep] = [e.scrollTop, e.scrollLeft]));
      UI.go(tab, true, keep);
    });
  };
  UI.mountVp = function (slot, view) {
    if (!vp) {
      vp = h('div', { class: 'vp', id: 'vp' }, h('canvas', { id: 'sc' }));
      S.init(vp.firstChild);
      S.onPick = UI.onPick;
    }
    slot.appendChild(vp);
    S.visible = true;
    const keepCam = !UI.tabChanged && S.getCam().manual && S.view === view;
    S.view = view;
    requestAnimationFrame(() => { S.resize(); S.sync(true); if (!keepCam) S.fit(true); });
  };
  UI.vp = () => vp;

  /* ---------- toasts, floats, banners ---------- */
  const TI = { research: 'research', build: 'build', train: 'ai', release: 'rocket', ach: 'trophy', comp: 'warn', event: 'sparkle', contract: 'doc', region: 'globe', warn: 'warn', reward: 'cash' };
  UI.toast = function (t) {
    const box = $('#toasts');
    while (box.children.length >= 3) box.removeChild(box.firstChild);
    const el = h('div', { class: 'toast k-' + t.kind }, h('div', { class: 'ti' }, I(TI[t.kind] || 'info', 16)), h('div', {}, t.text));
    box.append(el);
    setTimeout(() => { el.classList.add('out'); setTimeout(() => el.remove(), 320); }, 3300);
  };
  UI.floatText = function (text, x, y) {
    const f = h('div', { class: 'float', style: { left: x + 'px', top: y + 'px' } }, text);
    $('#fx').append(f);
    setTimeout(() => f.remove(), 1500);
  };
  UI.banner = function (icon, title, sub) {
    const b = h('div', { class: 'banner' }, h('div', { class: 'bi' }, I(icon, 22)), h('div', {}, h('div', { class: 'micro gold' }, sub), h('div', { class: 'h3' }, title)));
    $('#fx').append(b);
    setTimeout(() => b.remove(), 4300);
  };

  /* ---------- modals ---------- */
  UI.modal = function (node, opt) {
    opt = opt || {};
    const wrap = h('div', { class: 'mwrap', style: { position: 'absolute', inset: 0 } });
    const o = { el: wrap };
    const close = () => { if (!wrap.parentNode) return; wrap.remove(); modals = modals.filter((x) => x !== o); if (opt.onclose) opt.onclose(); };
    o.close = close;
    const m = h('div', { class: 'modal' + (opt.center ? ' center' : '') }, node);
    if (!opt.lock) m.prepend(h('button', { class: 'closex', 'aria-label': 'Close', onclick: close, html: U.ic('close', 18) }));
    wrap.append(h('div', { class: 'scrim', onclick: () => { if (!opt.lock) close(); } }), m);
    $('#modals').append(wrap);
    modals.push(o);
    return o;
  };
  UI.confirm = function (title, text, ok, cb, cls) {
    let m;
    const body = h('div', { class: 'col gap12' }, h('h2', {}, title), h('div', { class: 'mut' }, text),
      h('div', { class: 'row' }, UI.btn('Cancel', { cls: 'grow', onclick: () => m.close() }), UI.btn(ok, { cls: 'grow ' + (cls || 'pri'), onclick: () => { m.close(); cb(); } })));
    m = UI.modal(body, { center: true });
  };
  UI.back = function () {
    if (document.querySelector('.launch')) return true;
    if (modals.length) { modals[modals.length - 1].close(); return true; }
    if (tab !== 'hq') { UI.go('hq'); return true; }
    return false;
  };

  /* ---------- model launch ---------- */
  UI.launch = function (info) {
    const m = D.mmap[info.id], s = G.state, lowfx = (s.set.anim || 0) === 0;
    G.audio.sfx('release');
    const cvs = h('canvas');
    const ov = h('div', { class: 'launch' }, lowfx ? null : cvs);
    const rows = [['Intelligence', G.C.intel, 1800], ['Speed', G.C.speed, 300], ['Appeal', G.C.appeal * 100, 80]];
    const fills = [];
    const stats = h('div', { class: 'ls' }, rows.map((r) => {
      const f = UI.bar('vio'); fills.push([f, U.clamp(Math.log10(1 + r[1]) / Math.log10(1 + r[2]), 0.05, 1)]);
      return h('div', { class: 'lsr' }, h('span', {}, r[0]), f, h('b', {}, r[0] === 'Appeal' ? r[1].toFixed(1) + '%' : U.num(r[1])));
    }));
    const dl = h('div', { class: 'stat-delta' },
      UI.tile('Users', h('div', { class: 'tv', style: { fontSize: '12.5px' } }, U.num(info.before.users) + ' → ' + U.num(info.after.users))),
      UI.tile('Revenue/s', h('div', { class: 'tv pos', style: { fontSize: '12.5px' } }, U.money(info.before.rev) + ' → ' + U.money(info.after.rev))),
      UI.tile('Hype', h('div', { class: 'tv vio' }, '+' + Math.round(100 * (1 + 0.12 * m.gen)) + '%')));
    const done = UI.btn('Continue', { cls: 'pri lbtn', onclick: () => { ov.remove(); stop(); G.save(); UI.refresh(); } });
    ov.append(h('div', { class: 'ico vio', style: { width: '58px', height: '58px', borderRadius: '18px' } }, I(m.icon, 30)),
      h('div', { class: 'lk' }, 'GENERATION ' + m.gen + ' · NOW LIVE'),
      h('div', { class: 'ln' }, m.name.split('').map((ch, i) => h('span', { style: { animationDelay: 0.45 + i * 0.07 + 's' } }, ch))),
      h('div', { class: 'lt' }, m.tag), stats, dl, done);
    $('#modals').append(ov);
    setTimeout(() => fills.forEach((f) => UI.setBar(f[0], f[1])), 1900);
    let raf = 0, run = !lowfx;
    function stop() { run = false; cancelAnimationFrame(raf); }
    if (run) {
      const c = cvs.getContext('2d'), W = (cvs.width = window.innerWidth), H = (cvs.height = window.innerHeight), ps = [];
      for (let i = 0; i < 90; i++) { const a = Math.random() * 6.283, v = 40 + Math.random() * 260; ps.push({ x: W / 2, y: H * 0.38, vx: Math.cos(a) * v, vy: Math.sin(a) * v, l: 1.4 + Math.random() * 1.6, c: i % 3 ? '#8af0e6' : '#b9aeff' }); }
      let last = performance.now();
      const loop = (n) => {
        if (!run) return;
        const dt = Math.min(0.05, (n - last) / 1000); last = n;
        c.clearRect(0, 0, W, H); c.globalCompositeOperation = 'lighter';
        for (const p of ps) { p.x += p.vx * dt; p.y += p.vy * dt; p.vx *= 0.985; p.vy = p.vy * 0.985 + 18 * dt; p.l -= dt; if (p.l > 0) { c.globalAlpha = Math.min(1, p.l); c.drawImage(G.art.glow(p.c), p.x - 9, p.y - 9, 18, 18); } }
        c.globalAlpha = 1; c.globalCompositeOperation = 'source-over';
        raf = requestAnimationFrame(loop);
      };
      raf = requestAnimationFrame(loop);
    }
  };

  /* ---------- achievements ---------- */
  UI.achievement = function (o) {
    G.audio.sfx('ach');
    if (o.a.long) UI.banner(o.a.icon, o.a.name, 'MILESTONE REACHED');
    else UI.toast({ kind: 'ach', text: o.a.name + (o.reward > 0 ? ' · +' + U.money(o.reward) : '') });
    if (tab === 'achv') UI.refresh();
  };

  /* ---------- offline summary ---------- */
  UI.offline = function (r) {
    const s = G.state;
    const cnt = (v, f) => { const n = h('b', {}, f(0)); const t0 = performance.now(); (function k(t) { const p = U.clamp((t - t0) / 1400, 0, 1); n.textContent = f(v * U.ease.out(p)); if (p < 1) requestAnimationFrame(k); })(t0); return n; };
    const lines = [], nComp = r.events.filter((e) => e.k === 'comp').length, nPress = r.events.filter((e) => e.k === 'event').length;
    for (const e of r.events) if (e.k !== 'comp' && e.k !== 'event' && lines.length < 6) lines.push({ k: e.k, x: e.x });
    if (nComp) lines.push({ k: 'comp', x: 'Rivals launched ' + nComp + ' new product' + (nComp > 1 ? 's' : '') + '.' });
    if (nPress) lines.push({ k: 'event', x: 'Press coverage boosted interest ' + nPress + ' time' + (nPress > 1 ? 's' : '') + '.' });
    const ev = lines.length ? lines.map((e) => h('div', { class: 'req ok' }, I(TI[e.k] || 'info', 14), e.x)) : [h('div', { class: 'dimt sm' }, 'A quiet while. Nothing major happened.')];
    let m;
    const body = h('div', { class: 'col gap12' },
      h('div', { class: 'row' }, h('div', { class: 'ico gold' }, I('clock', 20)), h('div', {}, h('h2', {}, 'Welcome back'), h('div', { class: 'mut sm' }, 'Away for ' + U.dur(r.away) + (r.capped ? ' · earnings capped at ' + U.dur(r.cap) : '') + ' · ' + Math.round(r.eff * 100) + '% offline efficiency'))),
      h('div', { class: 'grid3' },
        UI.tile('Revenue', h('div', { class: 'tv pos' }, cnt(r.rev, U.money))),
        UI.tile('Expenses', h('div', { class: 'tv neg' }, cnt(r.exp, U.money))),
        UI.tile('Net profit', h('div', { class: 'tv gold' }, cnt(r.net, U.money)))),
      h('div', { class: 'row between sm' }, h('span', { class: 'mut' }, 'Users'), h('b', {}, U.num(r.users0) + ' → ' + U.num(r.users1))),
      UI.sec('WHILE YOU WERE AWAY'), h('div', { class: 'col' }, ev),
      UI.btn('Collect', { cls: 'pri blk', onclick: () => { G.audio.sfx('coin'); m.close(); } }));
    m = UI.modal(body, { lock: true });
    G.audio.sfx('coin');
  };

  /* ---------- settings ---------- */
  UI.applyAnim = function () {
    const a = G.state.set.anim;
    document.body.classList.toggle('lowfx', a === 0);
    UI.maxQ = a;
    S.setQuality(Math.min(a, UI.autoQ === undefined ? 2 : UI.autoQ));
    G.lab.quality = Math.min(a, 1);
  };
  UI.settings = function () {
    const s = G.state;
    const slider = (key, label, icon) => {
      const v = h('b', {}, Math.round(s.set[key] * 100) + '%');
      const inp = h('input', { type: 'range', min: 0, max: 100, value: Math.round(s.set[key] * 100) });
      inp.addEventListener('input', () => { s.set[key] = inp.value / 100; v.textContent = inp.value + '%'; G.audio.vol[key === 'music' ? 'music' : 'sfx'] = s.set[key]; G.audio.init(); G.audio.apply(); });
      inp.addEventListener('change', () => G.audio.sfx('tap'));
      return h('div', { class: 'col gap4' }, h('div', { class: 'row between sm' }, h('span', { class: 'row' }, I(icon, 16), label), v), inp);
    };
    const seg = h('div', { class: 'seg' }, ['Low', 'Medium', 'High'].map((n, i) => h('button', { class: s.set.anim === i ? 'on' : '', onclick: (e) => { s.set.anim = i; UI.autoQ = undefined; UI.applyAnim(); seg.querySelectorAll('button').forEach((b, j) => b.classList.toggle('on', j === i)); } }, n)));
    const name = h('input', { type: 'text', maxlength: 22, value: s.name });
    name.addEventListener('change', () => { s.name = (name.value || 'Lumora AI').trim().slice(0, 22) || 'Lumora AI'; });
    const io = h('textarea', { placeholder: 'Paste a backup code here to import', spellcheck: 'false' });
    let m;
    const body = h('div', { class: 'col gap12' },
      h('h2', {}, 'Settings'),
      slider('music', 'Music', 'music'), slider('sfx', 'Sound effects', 'vol'),
      h('div', { class: 'col gap4' }, h('div', { class: 'sm row' }, I('sparkle', 16), 'Animation intensity'), seg, h('div', { class: 'xs dimt' }, 'Lower settings save battery and help older phones. The game also lowers effects by itself if it runs slowly.')),
      h('div', { class: 'col gap4' }, h('div', { class: 'sm' }, 'Company name'), name),
      h('div', { class: 'row' }, UI.btn('Save now', { icon: 'save', cls: 'grow', onclick: () => { G.save(); UI.toast({ kind: 'reward', text: 'Game saved.' }); } }),
        UI.btn('Backup code', { icon: 'copy', cls: 'grow', onclick: () => { const code = G.exportSave(); io.value = code; UI.copy(code); UI.toast({ kind: 'reward', text: 'Backup code copied.' }); } })),
      io,
      h('div', { class: 'row' }, UI.btn('Import', { cls: 'grow', onclick: () => { if (G.importSave(io.value)) { UI.toast({ kind: 'reward', text: 'Backup restored.' }); m.close(); UI.initState(); } else UI.toast({ kind: 'warn', text: 'That backup code is not valid.' }); } }),
        UI.btn('Diagnostics', { cls: 'grow', onclick: () => UI.diagnostics() }),
        UI.btn('Reset', { cls: 'grow', onclick: () => UI.confirm('Erase everything?', 'This deletes your company and all progress, including Legacy Patents. It cannot be undone.', 'Erase', () => { G.reset(); G.save(); m.close(); UI.initState(); }, 'gold') })),
      h('div', { class: 'xs dimt tc' }, 'AI Empire Tycoon ' + G.VER + ' · One game month lasts ten real minutes · All companies and products are fictional.'));
    m = UI.modal(body, { onclose: () => G.save() });
  };
  UI.copy = function (txt) {
    try { if (window.NativeBridge && window.NativeBridge.copy) { window.NativeBridge.copy(txt); return; } } catch (e) { /* ignore */ }
    try { navigator.clipboard.writeText(txt); } catch (e) { /* ignore */ }
  };
  UI.diagnostics = function () {
    let native = '';
    try { if (window.NativeBridge && window.NativeBridge.getLog) native = window.NativeBridge.getLog() || ''; } catch (e) { /* ignore */ }
    const txt = (G.errors || []).map((e) => e.t + '  ' + e.m).join('\n') + (native ? '\n--- native ---\n' + native : '');
    const body = h('div', { class: 'col gap12' }, h('h2', {}, 'Diagnostics'), h('div', { class: 'mut sm' }, 'If something looks wrong, copy this log and share it.'), h('div', { class: 'crash' }, txt || 'No errors recorded.'),
      UI.btn('Copy log', { icon: 'copy', cls: 'blk', onclick: () => { UI.copy(txt || 'No errors recorded.'); UI.toast({ kind: 'reward', text: 'Log copied.' }); } }));
    UI.modal(body);
  };

  /* ---------- ladder (building) cards, shared by HQ and Infrastructure ---------- */
  UI.ladderCard = function (k) {
    const s = G.state, meta = D.ladderMeta[k], lad = D.ladders[k];
    const card = h('div', { class: 'card' });
    const lvl = s.inf[k], cur = lad[lvl], next = lad[lvl + 1];
    const head = h('div', { class: 'row' }, h('div', { class: 'ico' }, I(meta.icon, 20)), h('div', { class: 'grow' }, h('div', { class: 'h3' }, meta.name), h('div', { class: 'xs mut' }, cur.name + ' · ' + meta.stat(cur))), h('span', { class: 'badge acc' }, 'LV ' + (lvl + 1) + '/' + lad.length));
    card.append(head);
    if (cur.desc) card.append(h('div', { class: 'xs dimt', style: { marginTop: '6px' } }, cur.desc));
    const b = G.building(k);
    if (b) {
      const pb = UI.bar('gold anim'), eta = h('span', { class: 'xs gold' });
      card.append(h('div', { class: 'col', style: { marginTop: '10px' } }, h('div', { class: 'row between sm' }, h('span', {}, 'Building ' + lad[b.to].name), eta), pb));
      UI.bind(pb, () => { UI.setBar(pb, 1 - b.left / b.total); T(eta, U.dur(b.left)); });
    } else if (next) {
      const cost = G.ladderCost(next);
      const miss = next.req && !s.res.done[next.req];
      const fx = next.eff ? D.effText(next.eff) : [];
      card.append(h('div', { class: 'col', style: { marginTop: '10px', gap: '4px' } }, h('div', { class: 'row between' }, h('span', { class: 'sm b' }, 'Next: ' + next.name), h('span', { class: 'xs mut' }, meta.stat(next))), fx.length ? h('div', { class: 'xs acc' }, fx.join(' · ')) : null,
        miss ? h('div', { class: 'req' }, I('lock', 13), 'Research ' + D.rmap[next.req].name) : null));
      const bt = UI.btn('Build  ' + U.money(cost), { cls: 'pri blk', onclick: () => UI.act(() => G.act.build(k), 'build') });
      bt.style.marginTop = '10px';
      bt._l.after(h('span', { class: 'sub' }, '· ' + U.dur(next.time)));
      UI.bind(bt, () => DIS(bt, G.state.cash < cost || miss && !G.state.res.done[next.req]));
      card.append(bt);
    } else card.append(h('div', { style: { marginTop: '8px' } }, h('span', { class: 'badge good' }, 'MAX LEVEL')));
    return card;
  };

  /* ---------- HQ tab ---------- */
  const KINDS = { hq: 'hq', lab: 'research', dc: 'infra', cool: 'snow', pwr: 'bolt', net: 'net', site: 'build' };
  UI.onPick = function (obj) {
    UI.st.pick = obj ? { kind: obj.kind, id: obj.id, lv: obj.lv } : null;
    if (tab === 'hq') drawInfo();
    else if (tab === 'infra') { const n = tabEl && tabEl.querySelector('.infocard'); if (n) drawInfoInto(n); }
  };
  let infoEl = null;
  function infoBody(p) {
    const s = G.state, C = G.C, kind = p.kind;
    const k = kind === 'dc' ? 'dc' : kind;
    const card = h('div', { class: 'col' });
    const row = (icon, title, sub) => h('div', { class: 'row' }, h('div', { class: 'ico' }, I(icon, 20)), h('div', { class: 'grow' }, h('h4', {}, title), h('div', { class: 'xs mut' }, sub)));
    if (kind === 'hq') card.append(row('hq', D.ladders.hq[s.inf.hq].name, D.ladders.hq[s.inf.hq].staff + ' staff · ' + D.ladders.hq[s.inf.hq].desc));
    else if (kind === 'lab') card.append(row('research', D.ladders.lab[s.inf.lab].name, 'Research speed x' + C.M.resSpeed.toFixed(2) + ' · ' + C.resSlots + ' slot' + (C.resSlots > 1 ? 's' : '')));
    else if (kind === 'dc') {
      const hall = D.ladders.dc[p.lv || 0];
      card.append(row('infra', hall.name, hall.racks + ' rack spaces · ' + s.inf.racks + ' racks owned · ' + C.nServers + ' servers · ' + U.tf(C.capEff) + ' online'));
    } else if (kind === 'cool') card.append(row('snow', D.ladders.cool[s.inf.cool].name, 'Heat ' + U.mw(C.heat) + ' of ' + U.mw(C.coolCap)));
    else if (kind === 'pwr') card.append(row('bolt', D.ladders.pwr[s.inf.pwr].name, 'Draw ' + U.mw(C.powerDraw) + ' of ' + U.mw(C.powerCap)));
    else if (kind === 'net') card.append(row('net', D.ladders.net[s.inf.net].name, Math.round(C.netEff * 100) + '% network efficiency'));
    else card.append(row('build', 'Under construction', 'This will be ready soon.'));
    const go = { hq: null, lab: null, dc: 'infra', cool: 'infra', pwr: 'infra', net: 'infra' }[kind];
    const acts = h('div', { class: 'row', style: { marginTop: '10px' } });
    if (kind === 'hq' || kind === 'lab') acts.append(UI.btn('Upgrade', { cls: 'pri grow', onclick: () => { UI.st.sheet = true; UI.st.hqSeg = 'campus'; UI.st.pick = null; UI.refresh(); } }));
    if (go) acts.append(UI.btn('Open Infrastructure', { cls: 'pri grow', onclick: () => UI.go(go) }));
    acts.append(UI.btn('Close', { cls: 'ghost', onclick: () => { UI.st.pick = null; if (infoEl) infoEl.remove(); infoEl = null; } }));
    card.append(acts);
    return card;
  }
  function drawInfoInto(node) { node.textContent = ''; if (UI.st.pick) node.append(infoBody(UI.st.pick)); else node.hidden = true; if (UI.st.pick) node.hidden = false; }
  function drawInfo() {
    if (infoEl) { infoEl.remove(); infoEl = null; }
    if (!UI.st.pick || !tabEl) return;
    infoEl = h('div', { class: 'info' }, infoBody(UI.st.pick));
    tabEl.querySelector('.tab-hq-in').append(infoEl);
  }
  UI.tabs.hq = function () {
    const s = G.state;
    const root = h('div', { class: 'tab-hq-in', style: { position: 'absolute', inset: 0 } });
    const slot = h('div', { class: 'vpslot' });
    const hint = h('button', { class: 'hint', type: 'button' }, h('div', { class: 'hi' }, I('target', 16)), h('div', { class: 'ht' }, h('div', { class: 'hl' }, 'NEXT STEP'), h('div', { class: 'hx' })), h('span', { class: 'hc' }, I('chev', 16)));
    UI.bind(hint, () => { const t = G.hint(); hint.hidden = !t; if (t) { T(hint.querySelector('.hx'), t.text); hint._tab = t.tab; } });
    hint.addEventListener('click', () => { G.audio.init(); if (hint._tab) UI.go(hint._tab); });
    const tools = h('div', { class: 'vtools' },
      h('button', { class: 'vt', 'aria-label': 'Recenter', onclick: () => { G.audio.sfx('tap'); S.recenter(); }, html: U.ic('target', 20) }),
      h('button', { class: 'vt', 'aria-label': 'Feed', onclick: () => { UI.st.sheet = true; UI.st.hqSeg = 'news'; UI.refresh(); }, html: U.ic('list', 20) }));
    // campus sheet
    const sheet = h('div', { class: 'sheet' + (UI.st.sheet ? '' : ' closed') });
    const head = h('button', { class: 'sheet-h', type: 'button', onclick: () => { UI.st.sheet = !UI.st.sheet; sheet.classList.toggle('closed', !UI.st.sheet); G.audio.sfx('tap'); } },
      h('div', { style: { textAlign: 'left' } }, h('div', { class: 'micro' }, 'Campus'), h('div', { class: 'b' }, D.ladders.hq[s.inf.hq].name)),
      h('span', { class: 'mut' }, I('up', 18)));
    const body = h('div', { class: 'sheet-b', 'data-keep': 'hqs' });
    const segs = [['campus', 'Upgrades'], ['look', 'Look'], ['news', 'News']];
    const seg = h('div', { class: 'seg' }, segs.map((x) => h('button', { class: UI.st.hqSeg === x[0] ? 'on' : '', onclick: () => { UI.st.hqSeg = x[0]; UI.refresh(); } }, x[1])));
    body.append(seg);
    if (UI.st.hqSeg === 'campus') {
      if (G.canReinvent()) body.append(h('div', { class: 'card vio' }, h('div', { class: 'row' }, h('div', { class: 'ico vio' }, I('refresh', 20)), h('div', { class: 'grow' }, h('div', { class: 'h3' }, 'Corporate Reinvention'), h('div', { class: 'xs mut' }, 'Your company is ready to be reinvented for ' + G.reinventGain() + ' Legacy Patents.'))), UI.btn('Learn more', { cls: 'vio blk', onclick: () => { UI.st.achSeg = 'legacy'; UI.go('achv'); } })));
      body.append(UI.ladderCard('hq'), UI.ladderCard('lab'));
    } else if (UI.st.hqSeg === 'look') {
      body.append(h('div', { class: 'xs mut' }, 'Choose a look for your campus. Some are unlocked by achievements and reinventions.'),
        h('div', { class: 'row wrap gap12' }, Object.keys(D.skins).map((id) => {
          const k = D.skins[id], has = !!s.pres.skins[id];
          const c = h('button', { class: 'skin' + (s.pres.skin === id ? ' on' : '') + (has ? '' : ' lock'), type: 'button', onclick: () => { if (UI.act(() => G.act.setSkin(id), 'tap').ok) S.sync(true); } }, h('i', { style: { background: 'linear-gradient(135deg,' + k.glass + ',' + k.accent + ')' } }), k.name);
          return c;
        })),
        h('div', { class: 'xs dimt' }, Object.keys(D.skins).filter((id) => !s.pres.skins[id]).map((id) => D.skins[id].name + ': ' + D.skins[id].how).join(' · ') || 'Every look is unlocked.'));
    } else {
      const list = s.feed.length ? s.feed.slice(0, 20).map((f) => h('div', { class: 'row' }, h('div', { class: 'ico dim' }, I(TI[f.k] || 'info', 16)), h('div', { class: 'grow sm' }, f.x), h('span', { class: 'xs dimt' }, ago(f.t)))) : [h('div', { class: 'empty' }, 'No news yet. Grow your company and the headlines will follow.')];
      body.append(h('div', { class: 'col gap12' }, list));
    }
    sheet.append(head, body);
    root.append(slot, hint, tools, sheet);
    setTimeout(() => { UI.mountVp(slot, 'all'); drawInfo(); }, 0);
    return root;
  };
})();
