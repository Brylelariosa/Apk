/* AI Empire Tycoon - boot, game loops and lifecycle */
(function () {
  'use strict';
  const G = window.G, U = G.U;
  G.errors = [];
  G.err = function (e) {
    const m = (e && (e.stack || e.message)) || String(e);
    G.errors.push({ t: new Date().toLocaleTimeString(), m: String(m).slice(0, 700) });
    if (G.errors.length > 40) G.errors.shift();
    try { if (window.NativeBridge && window.NativeBridge.logError) window.NativeBridge.logError(String(m).slice(0, 900)); } catch (x) { /* ignore */ }
  };
  window.addEventListener('error', (ev) => G.err(ev.error || ev.message));
  window.addEventListener('unhandledrejection', (ev) => G.err(ev.reason));

  function fatal(e) {
    const boot = document.getElementById('boot');
    if (!boot) return;
    boot.classList.remove('off');
    boot.innerHTML = '<div style="padding:24px;max-width:520px"><div style="font-weight:700;font-size:16px;margin-bottom:8px">AI Empire Tycoon could not start</div><div style="color:#93a3cc;font-size:12px;margin-bottom:10px">Please send this message to the developer. Your save was not touched.</div><div style="font:11px/1.4 monospace;background:#0006;border-radius:10px;padding:10px;white-space:pre-wrap;word-break:break-all;max-height:50vh;overflow:auto;user-select:text">' + String((e && (e.stack || e.message)) || e).replace(/</g, '&lt;') + '</div></div>';
  }

  function intro() {
    const s = G.state;
    if (s.set.intro) return;
    const UI = G.ui, h = U.h;
    let m;
    const li = (ic, t) => h('div', { class: 'row' }, h('div', { class: 'ico' }, UI.I(ic, 18)), h('div', { class: 'sm' }, t));
    m = UI.modal(h('div', { class: 'col gap12' }, h('h2', {}, 'Welcome, founder'), h('div', { class: 'mut' }, 'You run a tiny AI startup. Grow it into a global empire.'),
      li('users', 'Users arrive on their own and pay you, even while the game is closed.'),
      li('research', 'Research new technology, then train smarter models and release them.'),
      li('infra', 'Add servers, power and cooling so your AI can serve everyone.'),
      li('globe', 'Open new regions, beat rival companies and reinvent your company for permanent bonuses.'),
      UI.btn('Let’s go', { cls: 'pri blk', onclick: () => { s.set.intro = 1; m.close(); G.audio.init(); } })), { center: true, lock: true });
  }

  function start() {
    const UI = G.ui;
    const b = G.boot();
    UI.init();
    UI.initState();
    document.getElementById('app').hidden = false;
    setTimeout(() => { const bt = document.getElementById('boot'); if (bt) { bt.classList.add('off'); setTimeout(() => bt.remove(), 600); } }, 250);
    if (b.offline) setTimeout(() => UI.offline(b.offline), 400); else if (!b.had) setTimeout(intro, 500);
    // pending native crash report from a previous session
    try {
      if (window.NativeBridge && window.NativeBridge.getCrash) {
        const c = window.NativeBridge.getCrash();
        if (c) { G.errors.push({ t: 'previous session', m: c }); window.NativeBridge.clearCrash(); setTimeout(() => UI.diagnostics(), 900); }
      }
    } catch (e) { /* ignore */ }
    loops();
  }

  function loops() {
    const UI = G.ui, S = G.scene;
    setInterval(() => { try { const r = G.frame(); if (r) UI.offline(r); } catch (e) { G.err(e); } }, 250);
    setInterval(() => { try { UI.slow(); if (UI.topBind) UI.topBind(); UI.navDots(); } catch (e) { G.err(e); } }, 500);
    setInterval(() => { try { G.save(); } catch (e) { G.err(e); } }, 10000);
    let last = 0, acc = 0, n = 0, lastAdj = 0;
    function raf(ts) {
      requestAnimationFrame(raf);
      if (document.hidden) { last = ts; return; }
      const cap = S.q === 0 ? 22 : 30;
      if (ts - last < 1000 / cap - 3) return;
      const dt = ts - last; last = ts;
      try {
        UI.fast(Math.min(0.25, dt / 1000));
        const tab = UI.tab();
        if (S.visible && (tab === 'hq' || tab === 'infra')) S.render(ts);
        else if (G.lab.visible && tab === 'models') G.lab.render(ts);
        else if (G.map.visible && tab === 'global') G.map.render(ts);
        // performance governor: lower effects by itself on slow phones
        if (S.visible && dt < 400) {
          acc += dt; n++;
          if (n >= 90) {
            const avg = acc / n; acc = 0; n = 0;
            if (avg > (1000 / cap) * 1.6 && S.q > 0 && ts - lastAdj > 20000) {
              lastAdj = ts; UI.autoQ = S.q - 1; S.setQuality(UI.autoQ);
              UI.toast({ kind: 'warn', text: 'Running slowly, so effects were reduced.' });
            }
          }
        }
      } catch (e) { G.err(e); }
    }
    requestAnimationFrame(raf);
    const pause = () => { try { G.save(); G.audio.suspend(); } catch (e) { G.err(e); } };
    const resume = () => { try { G.audio.resume(); } catch (e) { G.err(e); } };
    document.addEventListener('visibilitychange', () => (document.hidden ? pause() : resume()));
    window.addEventListener('pagehide', pause);
    window.__gamePause = pause; window.__gameResume = resume;
    const unlock = () => { try { G.audio.init(); } catch (e) { /* ignore */ } };
    document.addEventListener('pointerdown', unlock, { capture: true, passive: true });
    document.addEventListener('touchstart', unlock, { capture: true, passive: true });
    window.addEventListener('resize', () => { try { S.resize(); G.lab.resize(); G.map.resize(); } catch (e) { G.err(e); } });
  }

  function ready() { try { start(); } catch (e) { G.err(e); fatal(e); } }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', ready); else ready();
})();
