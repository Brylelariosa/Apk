/* AI Empire Tycoon - animated neural network for the AI Laboratory */
(function () {
  'use strict';
  const G = window.G, U = G.U;
  const L = (G.lab = {});
  let cv = null, c = null, W = 300, H = 200, dpr = 1, T = 0, last = 0;
  const st = { gen: 1, prog: 0, active: false, burstT: -9, nodes: [], edges: [], pulses: [], layers: 3 };
  const THEMES = [['#3dd6c6', '#8af0e6'], ['#3dd6c6', '#8af0e6'], ['#45b8f2', '#9be7ff'], ['#5b9bf2', '#a9d4ff'], ['#8b7cf6', '#cfc6ff'], ['#a56cf0', '#e3c2ff'], ['#d46cd8', '#ffc2f3'], ['#f07ab0', '#ffcfe0'], ['#f6b84a', '#ffeaaa'], ['#fff0a8', '#ffffff']];
  L.quality = 1;

  L.init = function (canvas) { cv = canvas; c = cv.getContext('2d'); L.resize(); };
  L.resize = function () {
    if (!cv || !cv.parentElement) return;
    const r = cv.parentElement.getBoundingClientRect();
    if (r.width < 10 || r.height < 10) return;
    const nd = Math.min(window.devicePixelRatio || 1, 2);
    if (Math.abs(r.width - W) < 1 && Math.abs(r.height - H) < 1 && nd === dpr && st.nodes.length) return;
    W = r.width; H = r.height; dpr = nd;
    cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr);
    cv.style.width = W + 'px'; cv.style.height = H + 'px';
    layout();
  };
  function layout() {
    const gen = st.gen, layers = 3 + Math.min(5, Math.floor((gen + 1) / 2) + (gen > 4 ? 1 : 0));
    st.layers = layers; st.nodes = []; st.edges = [];
    const mx = 26, my = 22, rnd = U.rng(gen * 977 + 13);
    const base = 3 + Math.floor(gen / 3), extra = 2 + Math.floor(gen / 2);
    const cols = [];
    for (let l = 0; l < layers; l++) {
      const n = base + Math.round(Math.sin((l / Math.max(1, layers - 1)) * Math.PI) * extra);
      const col = [];
      for (let i = 0; i < n; i++) {
        const x = mx + ((W - mx * 2) * l) / Math.max(1, layers - 1) + (rnd() - 0.5) * 8;
        const y = my + ((H - my * 2) * (i + 0.5)) / n + (rnd() - 0.5) * 6;
        const nd = { x, y, l, a: rnd() * 6.28, r: 2.2 + rnd() * 1.6 + (gen > 6 ? 0.8 : 0) };
        st.nodes.push(nd); col.push(nd);
      }
      cols.push(col);
    }
    for (let l = 0; l < layers - 1; l++) {
      for (const a of cols[l]) {
        const sorted = cols[l + 1].slice().sort((p, q) => Math.abs(p.y - a.y) - Math.abs(q.y - a.y));
        for (let k = 0; k < Math.min(3, sorted.length); k++) st.edges.push([a, sorted[k]]);
      }
    }
  }
  L.set = function (o) {
    let re = false;
    if (o.gen && o.gen !== st.gen) { st.gen = o.gen; re = true; }
    if (o.prog !== undefined) st.prog = o.prog;
    if (o.active !== undefined) st.active = o.active;
    if (re) layout();
  };
  L.burst = function () { st.burstT = T; };
  L.render = function (nowMs) {
    if (!cv || !c) return;
    L.resize();
    const dt = last ? Math.min(0.1, (nowMs - last) / 1000) : 0.033;
    last = nowMs; T += dt;
    const th = THEMES[Math.min(9, st.gen - 1)], a1 = th[0], a2 = th[1];
    c.setTransform(dpr, 0, 0, dpr, 0, 0);
    const bg = c.createLinearGradient(0, 0, 0, H);
    bg.addColorStop(0, '#0b1230'); bg.addColorStop(1, '#070b1c');
    c.fillStyle = bg; c.fillRect(0, 0, W, H);
    const rg = c.createRadialGradient(W / 2, H / 2, 0, W / 2, H / 2, Math.max(W, H) * 0.65);
    rg.addColorStop(0, U.rgba(a1, 0.17)); rg.addColorStop(1, U.rgba(a1, 0));
    c.fillStyle = rg; c.fillRect(0, 0, W, H);
    c.strokeStyle = 'rgba(150,180,240,.05)'; c.lineWidth = 1; c.beginPath();
    for (let x = 0; x < W; x += 28) { c.moveTo(x, 0); c.lineTo(x, H); }
    for (let y = 0; y < H; y += 28) { c.moveTo(0, y); c.lineTo(W, y); }
    c.stroke();
    const wf = st.active ? st.prog * (W + 60) - 30 : -999;
    const since = T - st.burstT;
    // edges
    c.lineWidth = 1; c.strokeStyle = U.rgba(a1, 0.17); c.beginPath();
    for (const e of st.edges) { c.moveTo(e[0].x, e[0].y); c.lineTo(e[1].x, e[1].y); }
    c.stroke();
    if (st.active || st.prog > 0) {
      c.strokeStyle = U.rgba(a2, 0.34); c.beginPath();
      for (const e of st.edges) if (e[1].x < wf) { c.moveTo(e[0].x, e[0].y); c.lineTo(e[1].x, e[1].y); }
      c.stroke();
    }
    // pulses
    const rate = (st.active ? 5 + st.prog * 14 : 1.2) * (L.quality === 0 ? 0.5 : 1);
    if (Math.random() < rate * dt && st.edges.length && st.pulses.length < 70) st.pulses.push({ e: st.edges[Math.floor(Math.random() * st.edges.length)], t: 0, v: 0.6 + Math.random() * 0.7 });
    c.globalCompositeOperation = 'lighter';
    for (let i = st.pulses.length - 1; i >= 0; i--) {
      const p = st.pulses[i]; p.t += p.v * dt;
      if (p.t >= 1) { st.pulses.splice(i, 1); continue; }
      const x = U.lerp(p.e[0].x, p.e[1].x, p.t), y = U.lerp(p.e[0].y, p.e[1].y, p.t);
      c.globalAlpha = 0.9 * Math.sin(p.t * Math.PI);
      c.drawImage(A().glow(a2), x - 7, y - 7, 14, 14);
    }
    c.globalAlpha = 1; c.globalCompositeOperation = 'source-over';
    // nodes
    for (const n of st.nodes) {
      const trained = n.x < wf, near = Math.abs(n.x - wf) < 26 && st.active;
      const pulse = 0.5 + 0.5 * Math.sin(T * 2 + n.a);
      const flash = since < 1.3 ? Math.max(0, 1 - since / 1.3) : 0;
      const lit = trained || (!st.active && st.prog === 0 && st.gen > 0) ? 0.55 + 0.35 * pulse : 0.25 + 0.2 * pulse;
      const rr = n.r + (near ? 2.2 : 0) + flash * 2;
      c.fillStyle = trained || flash > 0 ? U.rgba(a2, Math.min(1, lit + flash)) : U.rgba(a1, lit * 0.8);
      c.beginPath(); c.arc(n.x, n.y, rr, 0, 6.283); c.fill();
      if (near || flash > 0.2) { c.globalCompositeOperation = 'lighter'; c.globalAlpha = 0.7; c.drawImage(A().glow(a2), n.x - 16, n.y - 16, 32, 32); c.globalAlpha = 1; c.globalCompositeOperation = 'source-over'; }
    }
    // wavefront line
    if (st.active && st.prog > 0 && st.prog < 1) {
      const g = c.createLinearGradient(wf - 28, 0, wf + 4, 0);
      g.addColorStop(0, U.rgba(a2, 0)); g.addColorStop(1, U.rgba(a2, 0.28));
      c.fillStyle = g; c.fillRect(wf - 28, 0, 32, H);
    }
    if (since < 1.4) {
      const k = since / 1.4;
      c.strokeStyle = U.rgba(a2, 0.8 * (1 - k)); c.lineWidth = 3 * (1 - k) + 1;
      c.beginPath(); c.arc(W / 2, H / 2, k * Math.max(W, H) * 0.6, 0, 6.283); c.stroke();
    }
  };
  function A() { return G.art; }
})();
