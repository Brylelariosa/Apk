/* AI Empire Tycoon - static data. All names, brands and numbers are fictional. */
(function () {
  'use strict';
  const G = window.G, U = G.U;
  const D = (G.D = {});

  /* Cost model: costs are written as [stage, minutes] = "minutes of the net income a healthy company has at that
     stage", so the whole economy can be re-tuned by editing one table. */
  D.NT = [0.2, 120, 1500, 8000, 3e4, 1e5, 3.5e5, 1.2e6, 3e6, 7e6];
  D.N = function (st) {
    const i = Math.max(0, Math.min(9, st - 1)), a = Math.floor(i), b = Math.min(9, a + 1), f = i - a;
    return Math.exp(Math.log(D.NT[a]) * (1 - f) + Math.log(D.NT[b]) * f);
  };
  const $ = function (c) {
    if (typeof c === 'number') return c;
    const v = D.N(c[0]) * c[1] * 60;
    if (v < 100) return Math.round(v);
    const p = Math.pow(10, Math.floor(Math.log10(v)) - 1);
    return Math.round(v / p) * p;
  };
  D.$ = $;

  /* ================= AI MODELS ================= */
  // cost: training cash, time: seconds, tf: compute reserved while training, cpu: inference TF per user,
  // adopt: share of the online population that adopts an assistant of this quality, op: serving $/s per user
  D.models = [
    { id: 'basic', name: 'BasicBot', gen: 1, icon: 'chat', tag: 'Simple text responses', cost: 0, time: 0, tf: 0, intel: 10, speed: 30, cpu: 0.0004, adopt: 0.0004, fair: 6, op: 0.0001, req: [] },
    { id: 'smart', name: 'SmartBot', gen: 2, icon: 'bulb', tag: 'Improved conversation quality', cost: 2500, time: 75, tf: 4, intel: 24, speed: 42, cpu: 0.0006, adopt: 0.0011, fair: 8, op: 0.00014, req: ['ai1'] },
    { id: 'logic', name: 'LogicAI', gen: 3, icon: 'logic', tag: 'Advanced reasoning', cost: 45e3, time: 240, tf: 30, intel: 55, speed: 55, cpu: 0.0011, adopt: 0.003, fair: 12, op: 0.0002, req: ['ai2'] },
    { id: 'vision', name: 'VisionAI', gen: 4, icon: 'eye', tag: 'Image understanding', cost: 700e3, time: 480, tf: 300, intel: 100, speed: 70, cpu: 0.0024, adopt: 0.008, fair: 15, op: 0.00035, req: ['ai3'] },
    { id: 'creator', name: 'CreatorAI', gen: 5, icon: 'image', tag: 'Image generation', cost: $([4, 8]), time: 840, tf: 3000, intel: 170, speed: 85, cpu: 0.005, adopt: 0.02, fair: 18, op: 0.0006, req: ['ai4'] },
    { id: 'voice', name: 'VoiceAI', gen: 6, icon: 'mic', tag: 'Voice conversations', cost: $([5, 8]), time: 1320, tf: 2e4, intel: 260, speed: 105, cpu: 0.008, adopt: 0.045, fair: 20, op: 0.0009, req: ['ai5'] },
    { id: 'code', name: 'CodeAI', gen: 7, icon: 'code', tag: 'Programming assistance', cost: $([6, 8]), time: 2100, tf: 85e3, intel: 400, speed: 130, cpu: 0.013, adopt: 0.09, fair: 24, op: 0.0013, req: ['ai6'] },
    { id: 'agent', name: 'AgentAI', gen: 8, icon: 'bot', tag: 'Autonomous task execution', cost: $([7, 8]), time: 3300, tf: 280e3, intel: 600, speed: 160, cpu: 0.021, adopt: 0.17, fair: 28, op: 0.0019, req: ['ai7'] },
    { id: 'omni', name: 'OmniAI', gen: 9, icon: 'omni', tag: 'Multiple advanced capabilities', cost: $([8, 8]), time: 4800, tf: 1.3e6, intel: 900, speed: 200, cpu: 0.034, adopt: 0.32, fair: 32, op: 0.0028, req: ['ai8'] },
    { id: 'super', name: 'SuperAI', gen: 10, icon: 'atom', tag: 'Extremely advanced fictional intelligence', cost: $([9, 8]), time: 7200, tf: 4.3e6, intel: 1500, speed: 260, cpu: 0.06, adopt: 0.6, fair: 40, op: 0.004, req: ['ai9'] }
  ];
  D.mmap = {};
  D.models.forEach((m) => (D.mmap[m.id] = m));
  D.modelFlags = { creator: 'img', voice: 'voice', code: 'code', agent: 'agent' };

  /* ================= RESEARCH TREE ================= */
  D.lanes = [
    { id: 'ai', name: 'AI Intelligence', color: '#9b8cff', y: 0, rows: 2, icon: 'ai' },
    { id: 'cmp', name: 'Computing', color: '#45c1f2', y: 2, rows: 2, icon: 'cpu' },
    { id: 'prod', name: 'AI Products', color: '#f6a35c', y: 4, rows: 2, icon: 'sparkle' },
    { id: 'biz', name: 'Business', color: '#4fd6a0', y: 6, rows: 2, icon: 'business' },
    { id: 'inf', name: 'Infrastructure', color: '#6aa7ff', y: 8, rows: 2, icon: 'infra' }
  ];
  const lane = {};
  D.lanes.forEach((l) => (lane[l.id] = l));
  D.laneMap = lane;
  D.research = [];
  function R(id, name, ln, x, y, cost, time, req, eff, desc, extra) {
    const n = Object.assign({ id, name, lane: ln, x, y, cost: $(cost), time, req: req || [], eff: eff || {}, desc }, extra || {});
    D.research.push(n);
  }
  // AI Intelligence
  R('ai1', 'Language Foundations', 'ai', 0, 0, 250, 20, [], {}, 'Core language-modelling research. Unlocks SmartBot training.', { icon: 'bulb' });
  R('ai2', 'Reasoning Chains', 'ai', 1, 0, 6e3, 90, ['ai1'], { intel: 0.05 }, 'Step-by-step reasoning. Unlocks LogicAI training.', { icon: 'logic' });
  R('ai3', 'Multimodal Encoders', 'ai', 2, 0, 90e3, 240, ['ai2'], { intel: 0.05 }, 'Teach models to see. Unlocks VisionAI training.', { icon: 'eye' });
  R('ai4', 'Generative Diffusion', 'ai', 3, 0, [4, 3], 480, ['ai3'], {}, 'Image synthesis research. Unlocks CreatorAI training.', { icon: 'image' });
  R('ai5', 'Speech Synthesis', 'ai', 4, 0, [5, 3], 900, ['ai4'], {}, 'Natural-sounding speech. Unlocks VoiceAI training.', { icon: 'mic' });
  R('ai6', 'Program Synthesis', 'ai', 5, 0, [6, 3], 1500, ['ai5'], {}, 'Models that write and run code. Unlocks CodeAI training.', { icon: 'code' });
  R('ai7', 'Tool-Use Planning', 'ai', 6, 0, [7, 3], 2400, ['ai6'], {}, 'Planning and tool use. Unlocks AgentAI training.', { icon: 'bot' });
  R('ai8', 'Unified Multimodality', 'ai', 7, 0, [8, 3], 3600, ['ai7'], {}, 'One model for every modality. Unlocks OmniAI training.', { icon: 'omni' });
  R('ai9', 'Recursive Self-Improvement', 'ai', 8, 0, [9, 4], 5400, ['ai8', 'c11'], { intel: 0.1 }, 'Models that improve themselves. Unlocks SuperAI training.', { icon: 'atom' });
  R('rl', 'Preference Tuning', 'ai', 1, 1, 3e3, 60, ['ai1'], { intel: 0.06, sat: 3 }, 'Human feedback makes answers friendlier.', { icon: 'heart' });
  R('ctx', 'Long Context Windows', 'ai', 2, 1, 60e3, 200, ['ai2'], { appeal: 0.08 }, 'Longer memory makes the assistant far more useful.', { icon: 'layers' });
  R('tr1', 'Efficient Training Recipes', 'ai', 3, 1, [4, 1.5], 420, ['ctx'], { trainSpeed: 0.15, trainCost: 0.08 }, 'Cut waste in every training run.', { icon: 'gauge' });
  R('tr2', 'Curriculum Learning', 'ai', 5, 1, [6, 1.5], 1200, ['tr1', 'ai5'], { trainSpeed: 0.2, trainCost: 0.1 }, 'Smarter data ordering speeds up learning.', { icon: 'trend' });
  R('dist', 'Model Distillation', 'ai', 7, 1, [8, 2], 3000, ['tr2', 'ai7'], { intel: 0.08, dem: 0.1 }, 'Distil giant models into leaner ones.', { icon: 'sparkle' });
  // Computing
  R('c1', 'Faster Accelerators', 'cmp', 0, 2, 1.2e3, 45, ['ai1'], { cap: 0.1 }, 'Next-gen GPUs. Unlocks High-Performance GPU Servers.', { icon: 'cpu' });
  R('c2', 'Inference Optimization', 'cmp', 1, 2, 20e3, 120, ['c1'], { dem: 0.15 }, 'Serve more users with the same hardware.', { icon: 'bolt' });
  R('c3', 'Cluster Scheduler', 'cmp', 2, 2, 250e3, 300, ['c2'], { util: 0.08 }, 'Pack workloads tighter across the cluster.', { icon: 'layers' });
  R('c4', 'Tensor Accelerators', 'cmp', 3, 2, [3.7, 3], 600, ['c3'], { cap: 0.1 }, 'Custom silicon. Unlocks Advanced AI Accelerators.', { icon: 'cpu' });
  R('c5', 'Distributed Training', 'cmp', 4, 2, [4.4, 2], 1000, ['c4'], { trainSpeed: 0.2 }, 'Train across thousands of chips at once.', { icon: 'net' });
  R('c6', 'Neuromorphic Pods', 'cmp', 5, 2, [4.9, 2.5], 1800, ['c5'], { cap: 0.1 }, 'Brain-inspired chips. Unlocks Neuromorphic Pods.', { icon: 'ai' });
  R('c7', 'Quantization & Sparsity', 'cmp', 6, 3, [5.8, 2], 2800, ['c6'], { dem: 0.2 }, 'Smaller numbers, same answers.', { icon: 'gauge' });
  R('c8', 'Photonic Compute', 'cmp', 7, 2, [6.4, 3], 3000, ['c7'], { cap: 0.15, pw: 0.1 }, 'Compute with light. Unlocks Photonic Compute Cores.', { icon: 'sun' });
  R('c9', 'Elastic Autoscaling', 'cmp', 3, 3, [4, 1.5], 500, ['c3'], { util: 0.06 }, 'Scale capacity with demand and waste less.', { icon: 'up' });
  R('c10', 'Quantum Tensor Arrays', 'cmp', 8, 2, [7.8, 3], 3600, ['c8'], { cap: 0.1 }, 'Tensor arrays that exploit quantum effects. Unlocks Quantum Tensor Arrays.', { icon: 'atom' });
  R('c11', 'Stellar Compute Shards', 'cmp', 9, 2, [9.2, 3], 4800, ['c10'], { cap: 0.15, pw: 0.1 }, 'Star-scale compute fabric. Unlocks Stellar Compute Shards.', { icon: 'star' });
  // AI Products
  R('p1', 'Subscription Plans', 'prod', 0, 4, 200, 15, [], { flag: 'premium' }, 'Offer a paid tier. Unlocks premium subscriptions.', { icon: 'tag' });
  R('p2', 'Developer API', 'prod', 1, 4, 4e3, 90, ['p1', 'ai1'], { flag: 'api' }, 'Let developers build on your models. Unlocks API revenue.', { icon: 'code' });
  R('p3', 'Image Studio', 'prod', 3, 4, [5, 2], 420, ['ai4'], { flag: 'img' }, 'Sell image generation. Needs CreatorAI released.', { icon: 'image', reqModel: 'creator' });
  R('p4', 'Voice Assistant', 'prod', 4, 4, [6, 2], 800, ['ai5'], { flag: 'voice', conv: 0.15 }, 'Voice mode lifts conversion and price tolerance. Needs VoiceAI released.', { icon: 'mic', reqModel: 'voice' });
  R('p5', 'Coding Assistants', 'prod', 5, 4, [7, 2], 1400, ['ai6'], { flag: 'code', api: 0.5 }, 'Coding tools boost API revenue. Needs CodeAI released.', { icon: 'code', reqModel: 'code' });
  R('p6', 'Video Generation', 'prod', 6, 4, [8, 3], 2400, ['p3', 'ai7'], { flag: 'video', img: 0.8 }, 'Turn prompts into video. Big boost to image revenue.', { icon: 'video' });
  R('p7', 'Autonomous Agents', 'prod', 7, 4, [8.5, 3], 3000, ['ai7'], { flag: 'agent' }, 'Businesses automate whole tasks. Needs AgentAI released.', { icon: 'bot', reqModel: 'agent' });
  // Business
  R('b1', 'Growth Marketing', 'biz', 0, 6, 400, 30, ['p1'], { growth: 0.12 }, 'Faster user growth.', { icon: 'mega' });
  R('b2', 'Brand Identity', 'biz', 1, 6, 9e3, 100, ['b1'], { appeal: 0.08 }, 'A recognisable brand attracts more users.', { icon: 'star' });
  R('b3', 'Enterprise Sales', 'biz', 2, 6, 120e3, 240, ['b2', 'ai2'], { flag: 'ent', entSlots: 1 }, 'Hire a sales team. Unlocks enterprise partnerships.', { icon: 'doc' });
  R('b4', 'Customer Success', 'biz', 3, 6, [4, 2], 480, ['b3'], { sat: 5 }, 'Happier customers stay longer.', { icon: 'heart' });
  R('b5', 'Pricing Analytics', 'biz', 4, 6, [5, 2.5], 900, ['b4'], { conv: 0.2 }, 'Higher premium conversion.', { icon: 'chart' });
  R('b6', 'Partner Network', 'biz', 5, 6, [6.5, 3], 1500, ['b5'], { ent: 0.25, entSlots: 2 }, 'More partners and bigger contracts.', { icon: 'users' });
  R('b7', 'Global Brand Campaigns', 'biz', 6, 6, [8, 3], 2400, ['b6'], { growth: 0.2, appeal: 0.1 }, 'Worldwide campaigns raise growth and appeal.', { icon: 'globe' });
  R('b8', 'Market Intelligence', 'biz', 7, 6, [9, 3], 3600, ['b7'], { compRes: 0.2 }, 'Blunt the impact of rival launches.', { icon: 'eye' });
  R('b9', 'Referral Program', 'biz', 2, 7, 60e3, 180, ['b2'], { growth: 0.1 }, 'Users invite users.', { icon: 'users' });
  // Infrastructure
  R('i1', 'Advanced Cooling', 'inf', 0, 8, 3e3, 60, ['c1'], { cool: 0.05 }, 'Better airflow. Unlocks Chilled Air cooling.', { icon: 'snow' });
  R('i2', 'Energy Efficiency', 'inf', 1, 8, 35e3, 150, ['i1'], { pw: 0.1 }, 'Cuts the electricity bill. Unlocks Solar + Battery power.', { icon: 'bolt' });
  R('i3', 'Network Optimization', 'inf', 2, 8, 400e3, 360, ['i2'], { net: 0.04 }, 'Cleaner routing. Unlocks Liquid Loops and InfiniBand.', { icon: 'net' });
  R('i4', 'Data Center Automation', 'inf', 3, 8, [4.5, 3], 700, ['i3'], { offCap: 6, offEff: 0.1, opex: 0.05 }, 'Robots work the night shift: longer, richer offline earnings.', { icon: 'wrench' });
  R('i5', 'Liquid Cooling Tech', 'inf', 4, 8, [5.5, 3], 1100, ['i4'], { cool: 0.1 }, 'Cold plates on every chip. Unlocks Immersion Tanks.', { icon: 'temp' });
  R('i6', 'Smart Power Grid', 'inf', 5, 8, [6.5, 3], 1800, ['i5'], { pw: 0.15 }, 'Grid-scale efficiency. Unlocks Cryo Chillers and Fusion power.', { icon: 'bolt' });
  R('i7', 'Autonomous Operations', 'inf', 6, 8, [7.5, 3], 3000, ['i6'], { offCap: 12, offEff: 0.15, opex: 0.1 }, 'Lights-out data centers: far longer offline earnings.', { icon: 'wrench' });
  R('i8', 'Self-Healing Fabric', 'inf', 7, 8, [9, 3], 4200, ['i7'], { net: 0.02, cool: 0.1 }, 'Hardware that repairs itself. Unlocks Quantum Link.', { icon: 'shield' });
  D.rmap = {};
  D.research.forEach((n) => (D.rmap[n.id] = n));

  /* human readable effect lines */
  D.effText = function (e) {
    const out = [];
    const P = (v) => Math.round(v * 100) + '%';
    for (const k in e) {
      const v = e[k];
      switch (k) {
        case 'intel': out.push('+' + P(v) + ' model intelligence'); break;
        case 'appeal': out.push('+' + P(v) + ' user appeal'); break;
        case 'trainSpeed': out.push('+' + P(v) + ' training speed'); break;
        case 'trainCost': out.push('-' + P(v) + ' training cost'); break;
        case 'dem': out.push('-' + P(v) + ' compute per user'); break;
        case 'cap': out.push('+' + P(v) + ' compute capacity'); break;
        case 'util': out.push('+' + P(v) + ' cluster utilization'); break;
        case 'serve': out.push('-' + P(v) + ' serving cost'); break;
        case 'conv': out.push('+' + P(v) + ' subscription conversion'); break;
        case 'growth': out.push('+' + P(v) + ' user growth'); break;
        case 'sat': out.push('+' + v + ' satisfaction'); break;
        case 'ent': out.push('+' + P(v) + ' enterprise revenue'); break;
        case 'entSlots': out.push('+' + v + ' enterprise slot' + (v > 1 ? 's' : '')); break;
        case 'api': out.push('+' + P(v) + ' API revenue'); break;
        case 'img': out.push('+' + P(v) + ' image revenue'); break;
        case 'agent': out.push('+' + P(v) + ' agent revenue'); break;
        case 'resSpeed': out.push('+' + P(v) + ' research speed'); break;
        case 'resSlots': out.push('+' + v + ' research slot' + (v > 1 ? 's' : '')); break;
        case 'net': out.push('+' + P(v) + ' network efficiency'); break;
        case 'cool': out.push('+' + P(v) + ' cooling capacity'); break;
        case 'pw': out.push('-' + P(v) + ' power cost'); break;
        case 'opex': out.push('-' + P(v) + ' operating costs'); break;
        case 'offCap': out.push('+' + v + 'h offline cap'); break;
        case 'offEff': out.push('+' + P(v) + ' offline efficiency'); break;
        case 'compRes': out.push('-' + P(v) + ' rival pressure'); break;
        case 'rev': out.push('+' + P(v) + ' all revenue'); break;
        case 'flag': out.push(D.flagText[v] || ''); break;
      }
    }
    return out.filter(Boolean);
  };
  D.flagText = {
    premium: 'Unlocks premium subscriptions', api: 'Unlocks developer API revenue', ent: 'Unlocks enterprise partnerships',
    img: 'Unlocks image generation revenue', voice: 'Unlocks voice add-ons', code: 'Unlocks coding assistants',
    video: 'Unlocks video generation', agent: 'Unlocks AI agent revenue'
  };

  /* ================= INFRASTRUCTURE ================= */
  D.hw = [
    { k: 'g1', name: 'Entry GPU Server', tf: 4, mw: 0.004, cost: 900, g: 1.075, req: null, color: '#2be3b8', desc: 'Four-GPU rack server for light inference.' },
    { k: 'g2', name: 'High-Performance GPU Server', tf: 70, mw: 0.01, cost: 9e3, g: 1.08, req: 'c1', color: '#4da3ff', desc: 'Eight data-center GPUs with fast interconnect.' },
    { k: 'g3', name: 'Advanced AI Accelerator', tf: 1100, mw: 0.03, cost: 280e3, g: 1.085, req: 'c4', color: '#b58cff', desc: 'Custom tensor silicon built for AI.' },
    { k: 'g4', name: 'Neuromorphic Accelerator Pod', tf: 18e3, mw: 0.4, cost: 4.5e6, g: 1.09, req: 'c6', color: '#ff8fb1', desc: 'Brain-inspired pods with extreme efficiency.' },
    { k: 'g5', name: 'Photonic Compute Core', tf: 300e3, mw: 2.5, cost: 30e6, g: 1.095, req: 'c8', color: '#ffd166', desc: 'Light-based compute at industrial scale.' },
    { k: 'g6', name: 'Quantum Tensor Array', tf: 5e6, mw: 15, cost: 345e6, g: 1.1, req: 'c10', color: '#7df9ff', desc: 'Quantum-assisted tensor arrays.' },
    { k: 'g7', name: 'Stellar Compute Shard', tf: 80e6, mw: 100, cost: 2.9e9, g: 1.1, req: 'c11', color: '#fff0a8', desc: 'A slice of a star-powered compute fabric.' }
  ];
  D.hwmap = {};
  D.hw.forEach((h) => (D.hwmap[h.k] = h));
  D.rack = { name: 'Server Rack', slots: 4, cost: 1800, g: 1.012, tier: 3, desc: 'Holds four servers. Needs data-center floor space; racks cost more in bigger halls.' };

  D.ladders = {
    hq: [
      { name: 'Garage Startup', staff: 3, eff: {}, desc: 'Three founders, a whiteboard and a lot of coffee.' },
      { name: 'Startup Office', cost: 9e3, time: 60, staff: 9, eff: { resSpeed: 0.05, growth: 0.03 }, desc: 'A real office with a meeting room and a team.' },
      { name: 'Office Block', cost: 300e3, time: 240, staff: 30, eff: { resSpeed: 0.1, growth: 0.06, entSlots: 1 }, desc: 'A glass-fronted block with space for 30 people.' },
      { name: 'Corporate Tower', cost: $([5, 5]), time: 900, staff: 120, eff: { resSpeed: 0.2, growth: 0.1, sat: 2 }, desc: 'A landmark tower for 120 staff and a rooftop garden.' },
      { name: 'Futuristic HQ Spire', cost: $([7.5, 8]), time: 2400, staff: 400, eff: { resSpeed: 0.35, growth: 0.15, entSlots: 1, appeal: 0.1 }, desc: 'A glowing spire that defines the skyline.' }
    ],
    lab: [
      { name: 'Research Corner', eff: {}, desc: 'A desk and a borrowed GPU.' },
      { name: 'AI Research Lab', cost: 20e3, time: 120, eff: { resSpeed: 0.2 }, desc: 'A dedicated lab with a training cluster.' },
      { name: 'AI Research Campus', cost: $([4, 3]), time: 480, eff: { resSpeed: 0.45, resSlots: 1 }, desc: 'Two wings, a holo-dome and a second research team.' },
      { name: 'Quantum Research Institute', cost: $([6.5, 5]), time: 1500, eff: { resSpeed: 0.8, resSlots: 1, intel: 0.05 }, desc: 'A ringed institute at the edge of what is possible.' }
    ],
    dc: [
      { name: 'Server Closet', racks: 3, bonus: 0, desc: 'A cooled closet behind the office.' },
      { name: 'Server Room', racks: 8, bonus: 0.04, cost: 15e3, time: 60, desc: 'A dedicated room with raised floors.' },
      { name: 'Data Hall', racks: 24, bonus: 0.09, cost: 450e3, time: 180, desc: 'A proper hall with hot and cold aisles.' },
      { name: 'Hyperscale Hall', racks: 64, bonus: 0.15, cost: $([4.5, 8]), time: 420, desc: 'A hyperscale hall with overhead cable trays.' },
      { name: 'AI Supercampus', racks: 160, bonus: 0.22, cost: $([6, 10]), time: 900, desc: 'A campus of halls built around AI training.' },
      { name: 'Planetary Compute Grid', racks: 400, bonus: 0.3, cost: $([8, 12]), time: 1800, desc: 'A domed grid that powers the planet.' }
    ],
    cool: [
      { name: 'Air Fans', cap: 0.04, pue: 1.8, desc: 'Plain fans. Fine for a few servers.' },
      { name: 'Chilled Air', cap: 0.4, pue: 1.55, cost: 6e3, time: 30, req: 'i1', desc: 'Chilled-air units on the roof.' },
      { name: 'Liquid Loops', cap: 3, pue: 1.35, cost: 90e3, time: 90, req: 'i3', desc: 'Liquid loops carry heat to cooling towers.' },
      { name: 'Immersion Tanks', cap: 20, pue: 1.2, cost: $([4.3, 4]), time: 240, req: 'i5', desc: 'Servers bathe in dielectric fluid.' },
      { name: 'Cryo Chillers', cap: 160, pue: 1.1, cost: $([5.5, 5]), time: 600, req: 'i6', desc: 'Cryogenic chillers keep it frosty.' },
      { name: 'Zero-Point Exchangers', cap: 1200, pue: 1.04, cost: $([8.5, 6]), time: 1200, req: 'i8', desc: 'Near-perfect heat exchange.' }
    ],
    pwr: [
      { name: 'Grid Tap', cap: 0.05, price: 1, desc: 'A basic connection to the grid.' },
      { name: 'Transformer Yard', cap: 0.5, price: 0.9, cost: 10e3, time: 40, desc: 'Your own transformer yard.' },
      { name: 'Solar + Battery Farm', cap: 4, price: 0.7, cost: 150e3, time: 120, req: 'i2', desc: 'Solar panels and battery containers.' },
      { name: 'Gas Turbine Plant', cap: 25, price: 0.5, cost: $([4.5, 5]), time: 300, desc: 'A turbine plant for steady power.' },
      { name: 'Fusion Microreactor', cap: 200, price: 0.3, cost: $([6.5, 6]), time: 700, req: 'i6', desc: 'A compact fusion reactor.' },
      { name: 'Orbital Solar Array', cap: 1500, price: 0.2, cost: $([9, 8]), time: 1500, req: 'c10', desc: 'Beamed power from orbit.' }
    ],
    net: [
      { name: 'Gigabit Switches', eff: 0.72, desc: 'Basic switches. Wastes a lot of compute.' },
      { name: '10G Fabric', eff: 0.8, cost: 4e3, time: 20, desc: 'Ten-gigabit links between racks.' },
      { name: 'InfiniBand Mesh', eff: 0.88, cost: 70e3, time: 60, req: 'i3', desc: 'Low-latency mesh for clusters.' },
      { name: 'Optical Mesh', eff: 0.94, cost: $([4, 2.5]), time: 180, req: 'c5', desc: 'All-optical switching.' },
      { name: 'Photonic Fabric', eff: 0.98, cost: $([5.5, 3]), time: 480, req: 'c8', desc: 'Light-speed fabric between chips.' },
      { name: 'Quantum Link', eff: 1.0, cost: $([8.5, 4]), time: 1000, req: 'i8', desc: 'Entangled links with zero waste.' }
    ]
  };
  D.ladderMeta = {
    hq: { name: 'Headquarters', icon: 'hq', stat: (t) => t.staff + ' staff' },
    lab: { name: 'Research Labs', icon: 'research', stat: (t) => (t.eff.resSpeed ? '+' + Math.round(t.eff.resSpeed * 100) + '% research speed' : 'Base research') },
    dc: { name: 'Data Center Buildings', icon: 'infra', stat: (t) => t.racks + ' rack spaces' + (t.bonus ? ', +' + Math.round(t.bonus * 100) + '% compute' : '') },
    cool: { name: 'Cooling Systems', icon: 'snow', stat: (t) => 'Removes ' + U.mw(t.cap) + ' of heat' },
    pwr: { name: 'Power Infrastructure', icon: 'bolt', stat: (t) => 'Supplies ' + U.mw(t.cap) },
    net: { name: 'Networking Equipment', icon: 'net', stat: (t) => Math.round(t.eff * 100) + '% network efficiency' }
  };

  /* ================= REGIONS ================= */
  // pop in millions of potential users, arpu/opex/infra multipliers, comp = competition intensity
  D.regions = [
    { id: 'na', name: 'North America', pop: 350, arpu: 1.25, opex: 1.1, infra: 1.0, growth: 1.0, comp: 1.0, cost: 0, time: 0, up: [$([3, 0.7]), $([4.5, 2])], req: {}, lon: -98, lat: 40, blurb: 'Home market. Wealthy early adopters and fierce competition.' },
    { id: 'eu', name: 'Europe', pop: 450, arpu: 1.1, opex: 1.2, infra: 1.15, growth: 0.9, comp: 0.9, cost: 45e3, time: 120, up: [$([4, 3]), $([6, 4])], req: { model: 'smart' }, lon: 10, lat: 50, blurb: 'Large, regulated market with strong privacy expectations.' },
    { id: 'ea', name: 'East Asia', pop: 1000, arpu: 0.8, opex: 0.8, infra: 0.9, growth: 1.3, comp: 1.4, cost: $([3.5, 8]), time: 300, up: [$([5, 6]), $([7, 8])], req: { model: 'logic' }, lon: 115, lat: 34, blurb: 'Huge population and powerful local rivals.' },
    { id: 'sea', name: 'Southeast Asia', pop: 450, arpu: 0.55, opex: 0.6, infra: 0.75, growth: 1.5, comp: 0.8, cost: $([4.5, 8]), time: 480, up: [$([6, 6]), $([8, 8])], req: { model: 'vision' }, lon: 106, lat: 8, blurb: 'Fast-growing, mobile-first and price sensitive.' },
    { id: 'sa', name: 'South America', pop: 300, arpu: 0.6, opex: 0.7, infra: 0.8, growth: 1.2, comp: 0.7, cost: $([5.5, 8]), time: 720, up: [$([7, 6]), $([9, 8])], req: { model: 'creator' }, lon: -60, lat: -15, blurb: 'Creative, social and eager for image tools.' },
    { id: 'gl', name: 'Global Markets', pop: 1500, arpu: 0.4, opex: 0.55, infra: 0.7, growth: 1.6, comp: 0.6, cost: $([7, 10]), time: 1200, up: [$([8.5, 8]), $([10, 10])], req: { model: 'voice', regions: 4 }, lon: 22, lat: 4, blurb: 'Africa, the Middle East and Oceania: the last frontier.' }
  ];
  D.rgmap = {};
  D.regions.forEach((r) => (D.rgmap[r.id] = r));
  D.hubReach = [0, 0.5, 0.75, 1];

  /* ================= COMPETITORS ================= */
  // rivals follow a growth curve (their intelligence at game time t) and launch in steps
  D.compCurve = (t) => 14 * Math.pow(1 + t / 2400, 1.3);
  D.comps = [
    { id: 'helix', name: 'Helix Dynamics', color: '#5b9bf2', f: 1.3, mkt: 2.2, every: [1200, 1900], style: 'The incumbent' },
    { id: 'quasar', name: 'Quasar Minds', color: '#f59e6b', f: 1.1, mkt: 1.8, every: [900, 1500], style: 'The fast follower' },
    { id: 'orbit', name: 'Orbitron', color: '#b08cf5', f: 0.95, mkt: 1.6, every: [1300, 2200], style: 'Enterprise specialist' },
    { id: 'sable', name: 'Sable Open Labs', color: '#4fd1a5', f: 0.8, mkt: 1.2, every: [700, 1300], style: 'Open-source challenger' }
  ];
  D.comps.forEach((c) => { c.intel0 = D.compCurve(0) * c.f; });
  D.compProducts = ['Atlas', 'Nova', 'Prism', 'Vertex', 'Cobalt', 'Ember', 'Zenith', 'Mirage', 'Cipher', 'Aurora'];
  D.hypeNews = [
    'A viral thread praises {m} and signups spike.',
    'A popular podcast host raves about {m}.',
    'A tech blog names {m} the assistant to beat.',
    'Students are sharing {m} study tips everywhere.'
  ];

  /* ================= ENTERPRISE PARTNERS ================= */
  D.partners = [
    { id: 'marlowe', name: 'Marlowe Retail', sector: 'Retail', st: 2, tf: 3, intel: 20 },
    { id: 'castor', name: 'Castor Bank', sector: 'Finance', st: 3, tf: 40, intel: 45 },
    { id: 'helio', name: 'Helio Health', sector: 'Healthcare', st: 4, tf: 400, intel: 90 },
    { id: 'tundra', name: 'Tundra Logistics', sector: 'Logistics', st: 5, tf: 3e3, intel: 150 },
    { id: 'aurora', name: 'Aurora Energy', sector: 'Energy', st: 6, tf: 12e3, intel: 250 },
    { id: 'meridian', name: 'Meridian Motors', sector: 'Automotive', st: 7, tf: 40e3, intel: 380 },
    { id: 'solace', name: 'Solace Telecom', sector: 'Telecom', st: 8, tf: 180e3, intel: 560 },
    { id: 'atlas', name: 'Atlas Aerospace', sector: 'Aerospace', st: 9, tf: 600e3, intel: 850 }
  ];
  D.partners.forEach((p) => { p.mrr = $([p.st, 1]); p.fee = $([p.st, 2.5]); });

  /* ================= LEGACY (PRESTIGE) ================= */
  D.legacy = [
    { id: 'rapid', name: 'Rapid Prototyping', icon: 'research', desc: '+12% research speed per level.', max: 10, eff: { resSpeed: 0.12 } },
    { id: 'viral', name: 'Viral Growth Engine', icon: 'users', desc: '+15% user growth per level.', max: 10, eff: { growth: 0.15 } },
    { id: 'lean', name: 'Lean Operations', icon: 'wrench', desc: '-5% operating costs per level.', max: 10, eff: { opex: 0.05, serve: 0.03 } },
    { id: 'train', name: 'Training Efficiency', icon: 'gauge', desc: '+10% training speed and -5% training cost per level.', max: 10, eff: { trainSpeed: 0.1, trainCost: 0.05 } },
    { id: 'seed', name: 'Seed Capital', icon: 'cash', desc: '2.2x more starting cash per level, paid out right away and in every new company.', max: 8, eff: {} },
    { id: 'arch', name: 'Sparse Architectures', icon: 'atom', desc: 'Exclusive architecture: +5% intelligence and -4% compute per user per level.', max: 5, eff: { intel: 0.05, dem: 0.04 }, base: 3, step: 2 },
    { id: 'founder', name: 'Founder Knowledge', icon: 'bulb', desc: 'Early research starts out complete: now and in every new company.', max: 3, eff: {}, base: 2, step: 2 }
  ];
  D.legacyMap = {};
  D.legacy.forEach((l) => (D.legacyMap[l.id] = l));
  D.legacyCost = (l, lvl) => (l.base || 1) + lvl * (l.step || 1);
  D.founderKit = [['ai1', 'p1', 'c1'], ['ai2', 'b1', 'p2', 'rl'], ['ai3', 'c2', 'b2', 'i1']];
  D.skins = {
    midnight: { name: 'Midnight', accent: '#3dd6c6', glass: '#4b78b0', roof: '#2d3b5e', wall: '#3a4a6b', lamp: '#ffd28a', how: 'Default' },
    aurora: { name: 'Aurora', accent: '#6ee7b7', glass: '#3f9c95', roof: '#235055', wall: '#2f5a62', lamp: '#d6fff0', how: 'Unlocked by the Million Club achievement' },
    solaris: { name: 'Solaris', accent: '#fbbf24', glass: '#b98a4a', roof: '#6b4a24', wall: '#7a5a38', lamp: '#fff0c2', how: 'Unlocked by Unicorn Status' },
    crystal: { name: 'Crystal', accent: '#8ecbff', glass: '#8aa9d6', roof: '#5b6f96', wall: '#7487ad', lamp: '#eaf4ff', how: 'Unlocked by Industry Leader' },
    obsidian: { name: 'Obsidian', accent: '#a78bfa', glass: '#5b4b93', roof: '#2a2347', wall: '#3b3361', lamp: '#e6d9ff', how: 'Unlocked by Corporate Reinvention' }
  };

  /* ================= ACHIEVEMENTS ================= */
  // t: unlock test (s = state, C = calc snapshot), p: progress 0..1, min: reward in minutes of net income, floor: minimum reward
  D.ach = [];
  function A(id, name, desc, icon, t, o) { D.ach.push(Object.assign({ id, name, desc, icon, t, min: 4, floor: 1000 }, o || {})); }
  const usersAch = (id, name, n, icon, o) => A(id, name, 'Reach ' + U.num(n) + ' users.', icon, (s) => s.users >= n, Object.assign({ p: (s) => s.users / n }, o));
  A('first_rev', 'First Revenue', 'Earn your first dollar.', 'cash', (s) => s.stats.rev >= 1, { floor: 500 });
  usersAch('users_1k', 'First 1,000 Users', 1e3, 'users', { floor: 1500 });
  A('first_sub', 'First Premium Subscriber', 'Get a paying subscriber.', 'star', (s, C) => C.subs >= 1, { floor: 2000 });
  usersAch('users_100k', 'Rising Platform', 1e5, 'users', { min: 6 });
  usersAch('users_1m', 'Million Club', 1e6, 'users', { long: true, skin: 'aurora', min: 10 });
  usersAch('users_100m', 'Hundred Million', 1e8, 'users', { min: 12 });
  usersAch('users_1b', 'One Billion Users', 1e9, 'globe', { long: true, min: 20, patents: 3 });
  A('gpu10', 'First GPU Cluster', 'Run 10 GPU servers at once.', 'cpu', (s, C) => C.nServers >= 10, { p: (s, C) => C.nServers / 10 });
  A('gpu100', 'Server Farm', 'Run 100 servers at once.', 'cpu', (s, C) => C.nServers >= 100, { p: (s, C) => C.nServers / 100, min: 6 });
  A('model_1m', 'First Million-Dollar Model', 'Have one model earn $1M in total.', 'ai', (s) => Object.values(s.models).some((m) => m.rev >= 1e6), { min: 8 });
  A('ent1', 'First Enterprise Contract', 'Sign an enterprise partner.', 'doc', (s, C) => C.nContracts >= 1, { floor: 5000 });
  A('ent5', 'Enterprise Portfolio', 'Hold five enterprise contracts.', 'doc', (s, C) => C.nContracts >= 5, { p: (s, C) => C.nContracts / 5, min: 10 });
  A('reg3', 'Going Global', 'Open three regions.', 'globe', (s, C) => C.nRegions >= 3, { p: (s, C) => C.nRegions / 3, min: 6 });
  A('reg6', 'Global AI Expansion', 'Open all six regions.', 'globe', (s, C) => C.nRegions >= 6, { long: true, p: (s, C) => C.nRegions / 6, min: 15 });
  A('leader', 'Industry Leader', 'Hold half of the market.', 'crown', (s, C) => C.share >= 0.5, { long: true, skin: 'crystal', p: (s, C) => C.share / 0.5, min: 15, patents: 2 });
  A('val_10m', 'Series A', 'Reach a $10M valuation.', 'trend', (s, C) => C.val >= 1e7, { p: (s, C) => C.val / 1e7 });
  A('val_1b', 'Unicorn Status', 'Reach a $1B valuation.', 'crown', (s, C) => C.val >= 1e9, { long: true, skin: 'solaris', p: (s, C) => C.val / 1e9, min: 10, patents: 1 });
  A('val_1t', 'Trillion Club', 'Reach a $1T valuation.', 'crown', (s, C) => C.val >= 1e12, { p: (s, C) => C.val / 1e12, min: 20, patents: 5 });
  A('dc_hall', 'Large Data Center', 'Operate your first large data center.', 'infra', (s) => s.inf.dc >= 2, { long: true, min: 8 });
  A('dc_hyper', 'Hyperscaler', 'Build a Hyperscale Hall.', 'infra', (s) => s.inf.dc >= 3, { min: 10 });
  A('fusion', 'Power Pioneer', 'Switch on a fusion microreactor.', 'bolt', (s) => s.inf.pwr >= 4, { min: 10 });
  A('res_1', 'Eureka', 'Finish your first research project.', 'research', (s) => s.stats.research >= 1, { floor: 800 });
  A('res_10', 'Research Powerhouse', 'Finish ten research projects.', 'research', (s) => s.stats.research >= 10, { p: (s) => s.stats.research / 10 });
  A('res_all', 'Tech Tree Master', 'Complete the entire research tree.', 'research', (s) => D.research.every((n) => s.res.done[n.id]), { p: (s) => Object.keys(s.res.done).length / D.research.length, min: 20, patents: 2 });
  A('rel_3', 'Model Lineup', 'Release three different models.', 'ai', (s) => Object.values(s.models).filter((m) => m.st === 'rel').length >= 3, { min: 5 });
  A('rel_logic', 'Advanced Reasoning', 'Release your first advanced reasoning model.', 'logic', (s) => (s.models.logic || {}).st === 'rel', { long: true, min: 6 });
  A('rel_super', 'The Ultimate AI', 'Release SuperAI.', 'atom', (s) => (s.models.super || {}).st === 'rel', { long: true, min: 30, patents: 5 });
  A('tune_5', 'Fine Tuner', 'Complete five fine-tunes.', 'gauge', (s) => s.stats.tunes >= 5, { p: (s) => s.stats.tunes / 5, min: 5 });
  A('sat_95', 'Customer Delight', 'Reach 95% satisfaction.', 'heart', (s) => s.sat >= 95, { p: (s) => s.sat / 95, min: 6 });
  A('hype3', 'Viral Launch', 'Push launch hype past 3x.', 'sparkle', (s) => s.hype >= 3, { min: 6 });
  A('profit_1k', 'Profit Engine', 'Earn $1,000 net profit per second.', 'cash', (s, C) => C.net >= 1000, { p: (s, C) => C.net / 1000, min: 6 });
  A('lab3', 'Quantum Institute', 'Build the Quantum Research Institute.', 'research', (s) => s.inf.lab >= 3, { min: 8 });
  A('hq4', 'Skyline Defined', 'Build the Futuristic HQ Spire.', 'hq', (s) => s.inf.hq >= 4, { min: 8 });
  A('offline', 'Dreaming of Profits', 'Earn $10K while you are away.', 'clock', (s) => s.stats.offlineEarned >= 1e4, { p: (s) => s.stats.offlineEarned / 1e4 });
  A('reinvent_1', 'Corporate Reinvention', 'Reinvent your company for the first time.', 'refresh', (s) => s.pres.count >= 1, { skin: 'obsidian', min: 0, floor: 0, patents: 1 });
  D.amap = {};
  D.ach.forEach((a) => (D.amap[a.id] = a));

  /* ================= DAILY MISSIONS ================= */
  D.missions = [
    { id: 'jobs', text: 'Start a training or fine-tune job', stat: 'jobs', goal: () => 1, min: 6 },
    { id: 'research', text: 'Complete 2 research projects', stat: 'research', goal: () => 2, min: 8 },
    { id: 'servers', text: 'Install 8 servers', stat: 'servers', goal: () => 8, min: 6 },
    { id: 'users', text: 'Attract new users', stat: 'userGain', goal: (s) => Math.max(300, Math.round(s.users * 0.12)), min: 8, fmt: 'num' },
    { id: 'earn', text: 'Earn revenue', stat: 'rev', goal: (s, C) => Math.max(500, Math.round(C.rev.total * 900)), min: 10, fmt: 'money' },
    { id: 'build', text: 'Finish a construction project', stat: 'builds', goal: () => 1, min: 8 },
    { id: 'contract', text: 'Sign an enterprise contract', stat: 'contracts', goal: () => 1, min: 10, need: (s, C) => !!C.F.ent }
  ];
  D.mimap = {};
  D.missions.forEach((m) => (D.mimap[m.id] = m));

  /* ================= PRESTIGE ================= */
  D.prestige = { min: 2e10, name: 'Corporate Reinvention' };
  D.patentsFor = (val) => Math.floor(5 * Math.pow(Math.max(0, val) / 1e10, 0.5));
})();
