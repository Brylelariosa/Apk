# AI Empire Tycoon

An original idle tycoon for Android. You found **Lumora AI**, a tiny fictional AI startup, and grow it into a global
corporation: research new technology, train and release ten generations of AI models (BasicBot to SuperAI), earn from six
revenue streams, build data centers, open new regions, outpace four rival companies and finally reinvent your company for
permanent bonuses. Every name, brand and number is fictional.

The whole game is HTML/JavaScript in `app/src/main/assets/web` running inside a full-screen WebView. Everything, including all art
(isometric campus, icons, map) and all sound, is generated in code, so the game needs no internet and no permissions.

## Build the APK with the "Build APK" workflow

1. Upload `AIEmpireTycoon-1.zip` to the `uploads/` folder of your repository and commit it.
2. The workflow unzips it, downloads `gradle-wrapper.jar`, runs `./gradlew assembleDebug` and uploads the APK as an artifact
   named `AIEmpireTycoon-1-debug-v<run number>`. Set the `KEYSTORE_BASE64`, `STORE_PASSWORD`, `KEY_ALIAS` and `KEY_PASSWORD`
   secrets if you want a signed release build instead.
3. Open the finished run, download the artifact, unzip it and install `app-debug.apk`.

Requirements are the ones your workflow already provides: JDK 17, Gradle 8.6 (wrapper), Android Gradle Plugin 8.2.2,
compileSdk 34, minSdk 24 (Android 7.0+). There is no native code, no external dependency and no `INTERNET` permission.

To build locally: `./gradlew assembleDebug` (needs `gradle/wrapper/gradle-wrapper.jar`; copy it from any Gradle 8.6 project).

## Playing

* **HQ** - your evolving, animated campus. Pinch and drag to explore, tap a building to inspect it, open the Campus sheet to upgrade
  the office and lab, change the look, or read the news. The "Next step" chip always points at something useful.
* **AI Models** - the laboratory. Train a new model (timed, reserves compute while it trains), fine-tune an existing one,
  release it (launch animation, user surge, hype), or deploy an older model to save serving costs.
* **Research** - a 49-node tree in five branches (AI, Computing, Products, Business, Infrastructure) with prerequisites, costs,
  timers and meaningful effects. More labs mean faster research and more parallel projects.
* **Infrastructure** - seven server tiers, racks and floor space, data-center buildings, cooling, power and networking. Every
  purchase changes the campus view at the top of the screen. Construction takes real time.
* **Business** - pricing, ads, marketing, R&D budget, revenue/expense breakdown, market share against rivals, enterprise partnerships.
* **Global** - an interactive world map. Each region has its own population, spending, costs, growth and competition, and a hub
  you can upgrade to reach more people.
* **Goals** - daily missions, a long-term roadmap, 35 achievements and **Corporate Reinvention** (prestige).

### How the economy works (short version)

`users x quality x share` decides how many people want your AI. Your servers must be able to serve them: if demand exceeds
compute capacity, overheats or runs out of power, uptime and satisfaction fall and revenue is lost. Revenue comes from ads,
premium subscriptions, the developer API, enterprise contracts, image generation and AI agents. Net profit is revenue minus
payroll, serving, power, upkeep, marketing and R&D. One in-game month lasts ten real minutes.

Offline: progress continues while the app is closed (training, research and construction finish on time). Earnings run at 50%
efficiency (more with automation research) up to 6 hours (more with automation research). A summary is shown on return.

Corporate Reinvention unlocks at a $20B valuation. It resets the company but keeps achievements, looks and *Legacy Patents*,
which buy permanent upgrades (research speed, user growth, lower costs, training efficiency, seed capital, sparse
architectures, founder knowledge) and add a permanent revenue bonus.

## Settings, saving and safety

* Autosave every 10 s and whenever the app is paused; manual save and an export/import backup code in Settings.
* Saves are written natively with an atomic write plus a backup copy (`save.json` / `save.bak`) and mirrored in `localStorage`.
* Music, sound effects and animation intensity (Low / Medium / High) are separate. The game lowers effects by itself on slow phones.
* If the game ever crashes, the next start shows the crash report (Settings > Diagnostics also shows recent errors), which can be
  copied with one tap. Useful because phones make logcat hard to reach.

## Project layout

```
settings.gradle, build.gradle, gradle.properties, gradlew, gradle/wrapper/gradle-wrapper.properties
app/build.gradle
app/src/main/AndroidManifest.xml
app/src/main/java/com/lumora/aiempire/MainActivity.java   WebView host, native save, crash log
app/src/main/res/                                          launcher icons, theme
app/src/main/assets/web/
  index.html, css/style.css
  js/util.js     number formatting, colour helpers, original SVG icon set
  js/data.js     models, research tree, infrastructure, regions, rivals, partners, achievements, legacy
  js/game.js     economy, tick, offline progression, actions, missions, prestige, save/load (no DOM)
  js/art.js      procedural isometric art (HQ tiers, lab tiers, server halls, cooling, power, network)
  js/scene.js    campus renderer: sprite cache, camera, input, animation, construction
  js/lab.js      animated neural network for the AI laboratory
  js/map.js      dot-matrix world map
  js/audio.js    synthesized effects and generative ambient music
  js/ui.js, js/panels.js, js/main.js   interface, tabs, boot and loops
```

## Tuning the economy

All costs are written as `[stage, minutes]` in `data.js`: "this much of the net income a healthy company has at that stage".
Change `D.NT` (net income per stage) to rebalance everything at once. Constants such as revenue per user, expenses and growth speed
are in `G.K` at the top of `game.js`.
