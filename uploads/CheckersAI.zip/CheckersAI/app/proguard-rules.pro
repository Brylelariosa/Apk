# Add project specific ProGuard rules here.
# Minification is disabled by default for this project (see app/build.gradle),
# so these rules only take effect if you later enable minifyEnabled true.
