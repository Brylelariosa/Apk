# Add project-specific ProGuard/R8 rules here.
#
# This app doesn't use reflection, dynamic resource-name lookups, or any
# serialization library that inspects classes at runtime (our JSON
# persistence in ai/FileQTable.kt and ai/FileStatsStore.kt is hand-written
# JSONObject get/put calls), so the default R8 rules need very little help.
#
# Belt-and-suspenders: AGP's aapt2 step already auto-generates keep rules for
# custom Views referenced from XML layouts (BoardView, RewardChartView are
# each named in activity_main.xml), but they're kept explicitly here too so
# that's never a silent point of failure after shrinking.
-keep class com.example.checkersai.ui.BoardView { <init>(...); }
-keep class com.example.checkersai.ui.RewardChartView { <init>(...); }
