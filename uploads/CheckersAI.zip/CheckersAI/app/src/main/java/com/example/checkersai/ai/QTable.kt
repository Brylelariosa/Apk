package com.example.checkersai.ai

/** Persistence + storage abstraction for the AI's learned state-action values. */
interface QTable {
    fun get(stateKey: String, actionKey: String): Double
    fun set(stateKey: String, actionKey: String, value: Double)
    fun size(): Int
    fun save()
    fun clear()
}
