package com.example.checkersai.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import com.example.checkersai.core.Board
import com.example.checkersai.core.Move
import com.example.checkersai.core.Piece
import com.example.checkersai.core.PieceColor
import com.example.checkersai.core.Position

/**
 * Renders the checkers board and translates touches into move attempts.
 * Owns only presentation state (which square is currently selected, and any
 * illegal-attempt flash in progress); all rules and game-state decisions
 * live in [com.example.checkersai.game.GameController].
 */
class BoardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    fun interface MoveAttemptListener {
        fun onMoveAttempt(from: Position, to: Position)
    }

    var moveAttemptListener: MoveAttemptListener? = null

    private var board: Board = Board.initial()
    private var legalMoves: List<Move> = emptyList()
    private var interactive: Boolean = true
    private var selected: Position? = null
    private var illegalFlash: Pair<Position, Position>? = null

    private val lightPaint = Paint().apply { color = Color.parseColor("#EDE0D4") }
    private val darkPaint = Paint().apply { color = Color.parseColor("#5C3A21") }
    private val highlightPaint = Paint().apply { color = Color.parseColor("#88FFD54F") }
    private val selectedPaint = Paint().apply { color = Color.parseColor("#AA4CAF50") }
    private val blackPieceFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#212121") }
    private val redPieceFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#C1272D") }
    private val pieceRim = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 5f
        color = Color.parseColor("#E0E0E0")
    }
    private val kingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FFD54F")
        textAlign = Paint.Align.CENTER
    }
    private val illegalSquarePaint = Paint().apply { color = Color.parseColor("#66FF1744") }
    private val illegalLinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FF1744")
        style = Paint.Style.STROKE
        strokeWidth = 6f
    }

    /**
     * Updates what's shown. [interactive] disables selection/taps while it isn't the
     * human's turn. [autoSelect], if set, pre-selects a piece (used to keep a forced
     * multi-jump piece selected between hops without the user re-tapping it).
     */
    fun render(board: Board, legalMoves: List<Move>, interactive: Boolean, autoSelect: Position? = null) {
        this.board = board
        this.legalMoves = legalMoves
        this.interactive = interactive
        this.selected = autoSelect
        invalidate()
    }

    /**
     * Briefly highlights a move the AI attempted but wasn't allowed to make — a red
     * flash on both squares plus a line between them — so illegal guesses are
     * actually visible instead of happening invisibly inside the AI's decision loop.
     */
    fun flashIllegalAttempt(from: Position, to: Position) {
        illegalFlash = from to to
        invalidate()
        postDelayed({
            illegalFlash = null
            invalidate()
        }, 650L)
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val size = minOf(MeasureSpec.getSize(widthMeasureSpec), MeasureSpec.getSize(heightMeasureSpec))
        setMeasuredDimension(size, size)
    }

    override fun onDraw(canvas: Canvas) {
        val cell = width / Board.SIZE.toFloat()
        kingPaint.textSize = cell * 0.5f

        for (row in 0 until Board.SIZE) {
            for (col in 0 until Board.SIZE) {
                val pos = Position(row, col)
                val paint = if (pos.isDarkSquare()) darkPaint else lightPaint
                canvas.drawRect(col * cell, row * cell, (col + 1) * cell, (row + 1) * cell, paint)
            }
        }

        selected?.let { sel ->
            drawSquareOverlay(canvas, sel, cell, selectedPaint)
            legalMoves.filter { it.from == sel }.forEach { drawSquareOverlay(canvas, it.to, cell, highlightPaint) }
        }

        for (row in 0 until Board.SIZE) {
            for (col in 0 until Board.SIZE) {
                val pos = Position(row, col)
                val piece = board.pieceAt(pos) ?: continue
                drawPiece(canvas, pos, cell, piece)
            }
        }

        illegalFlash?.let { (from, to) ->
            drawSquareOverlay(canvas, from, cell, illegalSquarePaint)
            drawSquareOverlay(canvas, to, cell, illegalSquarePaint)
            val fx = from.col * cell + cell / 2f
            val fy = from.row * cell + cell / 2f
            val tx = to.col * cell + cell / 2f
            val ty = to.row * cell + cell / 2f
            canvas.drawLine(fx, fy, tx, ty, illegalLinePaint)
        }
    }

    private fun drawSquareOverlay(canvas: Canvas, pos: Position, cell: Float, paint: Paint) {
        canvas.drawRect(pos.col * cell, pos.row * cell, (pos.col + 1) * cell, (pos.row + 1) * cell, paint)
    }

    private fun drawPiece(canvas: Canvas, pos: Position, cell: Float, piece: Piece) {
        val cx = pos.col * cell + cell / 2f
        val cy = pos.row * cell + cell / 2f
        val radius = cell * 0.38f
        val fill = if (piece.color == PieceColor.BLACK) blackPieceFill else redPieceFill
        canvas.drawCircle(cx, cy, radius, fill)
        canvas.drawCircle(cx, cy, radius, pieceRim)
        if (piece.isKing) {
            val fm = kingPaint.fontMetrics
            val textY = cy - (fm.ascent + fm.descent) / 2f
            canvas.drawText("K", cx, textY, kingPaint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (!interactive || event.action != MotionEvent.ACTION_DOWN) return super.onTouchEvent(event)
        val cell = width / Board.SIZE.toFloat()
        val col = (event.x / cell).toInt().coerceIn(0, Board.SIZE - 1)
        val row = (event.y / cell).toInt().coerceIn(0, Board.SIZE - 1)
        val tapped = Position(row, col)

        val current = selected
        if (current != null && legalMoves.any { it.from == current && it.to == tapped }) {
            moveAttemptListener?.onMoveAttempt(current, tapped)
            return true
        }

        val hasMovesFromTapped = legalMoves.any { it.from == tapped }
        selected = if (hasMovesFromTapped) tapped else null
        invalidate()
        return true
    }
}
