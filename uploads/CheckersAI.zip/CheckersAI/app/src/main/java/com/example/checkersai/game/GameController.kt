package com.example.checkersai.game

import com.example.checkersai.ai.QLearningAgent
import com.example.checkersai.core.CheckersRules
import com.example.checkersai.core.GameState
import com.example.checkersai.core.GameStatus
import com.example.checkersai.core.Move
import com.example.checkersai.core.PieceColor
import com.example.checkersai.core.Position

/** UI-facing callback contract. Implemented by the Activity. */
interface GameListener {
    fun onStateChanged(state: GameState, legalMoves: List<Move>)
    fun onAiThinking()
    fun onAiIllegalAttempt(count: Int)
    fun onGameOver(status: GameStatus)
}

/**
 * Wires the pure [CheckersRules] engine together with the human player and
 * the [QLearningAgent], and notifies a [GameListener] (the Activity/UI) of
 * every state change. All game-flow orchestration lives here, out of the UI
 * layer; all rules live in [CheckersRules], out of both the UI and the AI.
 */
class GameController(
    private val agent: QLearningAgent,
    private val listener: GameListener,
    val humanColor: PieceColor = PieceColor.BLACK
) {
    var state: GameState = GameState.new()
        private set

    val aiColor: PieceColor get() = humanColor.opposite()

    fun startNewGame() {
        state = GameState.new()
        publish()
    }

    fun legalMoves(): List<Move> = CheckersRules.legalMoves(state)

    /** Attempts a human move; returns false (and does nothing) if it isn't legal right now. */
    fun tryHumanMove(from: Position, to: Position): Boolean {
        if (state.status != GameStatus.InProgress || state.turn != humanColor) return false
        val move = legalMoves().find { it.from == from && it.to == to } ?: return false
        applyAndContinue(move)
        return true
    }

    /** Drives one AI decision. If a forced multi-jump continues, the UI schedules the next call. */
    fun runAiTurn() {
        if (state.status != GameStatus.InProgress || state.turn != aiColor) return
        listener.onAiThinking()
        val moves = legalMoves()
        if (moves.isEmpty()) return // defensive; InProgress already implies at least one legal move
        val decision = agent.decideMove(state, moves)
        if (decision.illegalAttempts > 0) listener.onAiIllegalAttempt(decision.illegalAttempts)
        applyAndContinue(decision.move)
    }

    private fun applyAndContinue(move: Move) {
        val mover = state.turn
        val result = CheckersRules.applyMove(state, move)

        if (mover == aiColor) {
            val shaped = result.capturedCount * QLearningAgent.CAPTURE_REWARD +
                (if (result.promoted) QLearningAgent.KING_REWARD else 0.0)
            agent.reportShapedReward(shaped)
        } else if (result.capturedCount > 0) {
            // The human just captured one of the AI's pieces: negative signal for the AI.
            agent.reportShapedReward(-result.capturedCount * QLearningAgent.CAPTURE_REWARD)
        }

        state = result.state
        publish()

        val status = state.status
        if (status != GameStatus.InProgress) {
            finishGame(status)
        }
    }

    private fun finishGame(status: GameStatus) {
        val outcome = when {
            status is GameStatus.Won && status.winner == aiColor -> QLearningAgent.WIN_REWARD
            status is GameStatus.Won -> QLearningAgent.LOSE_REWARD
            else -> QLearningAgent.DRAW_REWARD
        }
        agent.finishGame(outcome)
        listener.onGameOver(status)
    }

    private fun publish() {
        listener.onStateChanged(state, if (state.status == GameStatus.InProgress) legalMoves() else emptyList())
    }
}
