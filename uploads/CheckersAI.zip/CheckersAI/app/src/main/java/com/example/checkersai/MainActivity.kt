package com.example.checkersai

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.checkersai.ai.FileQTable
import com.example.checkersai.ai.FileStatsStore
import com.example.checkersai.ai.QLearningAgent
import com.example.checkersai.core.CheckersRules
import com.example.checkersai.core.GameState
import com.example.checkersai.core.GameStatus
import com.example.checkersai.core.Move
import com.example.checkersai.core.PieceColor
import com.example.checkersai.databinding.ActivityMainBinding
import com.example.checkersai.game.GameController
import com.example.checkersai.game.GameListener
import com.example.checkersai.ui.BoardView

class MainActivity : AppCompatActivity(), GameListener {

    private lateinit var binding: ActivityMainBinding
    private lateinit var controller: GameController
    private lateinit var agent: QLearningAgent
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val qTable = FileQTable(applicationContext)
        val statsStore = FileStatsStore(applicationContext)
        agent = QLearningAgent(qTable, statsStore, color = PieceColor.RED)
        controller = GameController(agent, listener = this, humanColor = PieceColor.BLACK)

        binding.boardView.moveAttemptListener = BoardView.MoveAttemptListener { from, to ->
            controller.tryHumanMove(from, to)
        }
        binding.newGameButton.setOnClickListener { controller.startNewGame() }
        binding.resetAiButton.setOnClickListener {
            agent.resetLearning()
            updateStatsLabel()
            updateBrainPanel()
            Toast.makeText(this, getString(R.string.ai_reset_message), Toast.LENGTH_SHORT).show()
        }

        controller.startNewGame()
        updateStatsLabel()
        updateBrainPanel()
    }

    override fun onStateChanged(state: GameState, legalMoves: List<Move>) {
        val humanTurn = state.turn == controller.humanColor
        val autoSelect = if (humanTurn) state.mustContinueFrom else null
        binding.boardView.render(state.board, legalMoves, interactive = humanTurn, autoSelect = autoSelect)

        if (state.status == GameStatus.InProgress) {
            binding.statusText.text =
                if (humanTurn) getString(R.string.status_your_turn) else getString(R.string.status_ai_turn)
        }

        if (state.status == GameStatus.InProgress && !humanTurn) {
            handler.postDelayed({ controller.runAiTurn() }, AI_MOVE_DELAY_MS)
        }
    }

    override fun onAiThinking() {
        binding.statusText.text = getString(R.string.status_ai_turn)
    }

    override fun onAiIllegalAttempt(attempts: List<Move>, stateAtAttempt: GameState) {
        binding.boardView.flashIllegalAttempt(attempts.last().from, attempts.last().to)

        val last = attempts.last()
        val reason = CheckersRules.explainIllegal(stateAtAttempt, last)
        val message = if (attempts.size == 1) {
            getString(
                R.string.status_ai_illegal_one,
                last.from.row + 1, last.from.col + 1, last.to.row + 1, last.to.col + 1, reason
            )
        } else {
            getString(
                R.string.status_ai_illegal_many,
                attempts.size, last.from.row + 1, last.from.col + 1, last.to.row + 1, last.to.col + 1, reason
            )
        }
        // A Toast rather than the status label: the label gets overwritten by the
        // very next state update before a status-label change would be visible.
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    override fun onGameOver(status: GameStatus) {
        updateStatsLabel()
        updateBrainPanel()
        val message = when {
            status is GameStatus.Won && status.winner == controller.humanColor -> getString(R.string.result_you_win)
            status is GameStatus.Won -> getString(R.string.result_ai_wins)
            else -> getString(R.string.result_draw)
        }
        binding.statusText.text = message
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.game_over_title))
            .setMessage(message)
            .setPositiveButton(getString(R.string.new_game)) { _, _ -> controller.startNewGame() }
            .setCancelable(false)
            .show()
    }

    private fun updateStatsLabel() {
        val s = agent.stats
        binding.statsText.text = getString(R.string.stats_format, s.gamesPlayed, s.wins, s.losses, s.draws)
    }

    /** Refreshes the "AI Brain" panel: exploration rate, average reward trend, and table size. */
    private fun updateBrainPanel() {
        val percent = (agent.epsilon * 100).toInt()
        binding.epsilonBar.progress = percent
        binding.epsilonText.text = getString(R.string.epsilon_format, percent)

        val s = agent.stats
        binding.rewardText.text = getString(R.string.reward_format, s.averageRewardPerGame(), agent.learnedPositionCount)
        binding.rewardChartView.setValues(s.recentGameRewards)
    }

    companion object {
        private const val AI_MOVE_DELAY_MS = 550L
    }
}
