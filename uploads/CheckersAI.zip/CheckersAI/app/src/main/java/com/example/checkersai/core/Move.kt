package com.example.checkersai.core

/**
 * A single ply: either a simple diagonal step or one jump that captures
 * exactly one enemy piece. Multi-jump sequences are represented as a chain
 * of consecutive single-jump Moves (handled by [CheckersRules] / the game
 * controller), not as one combined Move object.
 */
data class Move(
    val from: Position,
    val to: Position,
    val captured: Position? = null
) {
    val isJump: Boolean get() = captured != null

    /** Stable key used for AI action lookups; independent of legality. */
    fun actionKey(): String = "${from.row}${from.col}${to.row}${to.col}"
}
