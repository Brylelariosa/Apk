package com.example.checkersai.ai

import android.content.Context
import org.json.JSONObject
import java.io.File

/**
 * Simple tabular [QTable] backed by a JSON file in app-private storage.
 * The whole table is kept in memory (it stays small for a tabular checkers
 * agent trained through normal play) and flushed to disk on [save], which
 * copies the map synchronously and writes it off the main thread so it never
 * blocks gameplay or the UI.
 */
class FileQTable(context: Context) : QTable {

    private val file = File(context.filesDir, "checkers_qtable.json")
    private val table = HashMap<String, Double>()

    init {
        load()
    }

    private fun key(stateKey: String, actionKey: String) = "$stateKey|$actionKey"

    override fun get(stateKey: String, actionKey: String): Double =
        table[key(stateKey, actionKey)] ?: 0.0

    override fun set(stateKey: String, actionKey: String, value: Double) {
        table[key(stateKey, actionKey)] = value
    }

    override fun size(): Int = table.size

    private fun load() {
        if (!file.exists()) return
        try {
            val json = JSONObject(file.readText())
            val keys = json.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                table[k] = json.getDouble(k)
            }
        } catch (e: Exception) {
            // Corrupt or unreadable save file: start fresh rather than crash.
            table.clear()
        }
    }

    override fun save() {
        val snapshot = HashMap(table)
        Thread {
            try {
                val json = JSONObject()
                for ((k, v) in snapshot) json.put(k, v)
                file.writeText(json.toString())
            } catch (e: Exception) {
                // Best-effort persistence; a failed save just costs this many
                // steps of learning progress on the next launch.
            }
        }.start()
    }

    override fun clear() {
        table.clear()
        if (file.exists()) file.delete()
    }
}
