package com.example.checkersai.ai

/** Persistence abstraction for [AiStats], mirroring [QTable]'s role for the Q-table. */
interface StatsStore {
    fun load(): AiStats
    fun save(stats: AiStats)
    fun clear()
}
