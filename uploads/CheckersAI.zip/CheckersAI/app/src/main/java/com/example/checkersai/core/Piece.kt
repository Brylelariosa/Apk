package com.example.checkersai.core

data class Piece(
    val color: PieceColor,
    val isKing: Boolean = false
) {
    fun promoted(): Piece = if (isKing) this else copy(isKing = true)
}
