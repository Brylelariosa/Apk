package com.example.checkersai.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import kotlin.math.abs

/**
 * A minimal sparkline: one bar per recent game's total reward, green above
 * the zero line and red below it, auto-scaled to the largest magnitude
 * currently in view.
 *
 * This agent is tabular Q-learning, not a deep neural network — there are no
 * weights or layers to draw. This chart is the honest visual for what it
 * actually has: a trend of what it's earning as it plays.
 */
class RewardChartView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var values: List<Double> = emptyList()

    private val positivePaint = Paint().apply { color = Color.parseColor("#4CAF50") }
    private val negativePaint = Paint().apply { color = Color.parseColor("#C1272D") }
    private val axisPaint = Paint().apply {
        color = Color.parseColor("#55000000")
        strokeWidth = 2f
    }
    private val emptyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#99000000")
        textAlign = Paint.Align.CENTER
        textSize = 28f
    }

    /** Replaces the chart's data (oldest to newest) and redraws. */
    fun setValues(values: List<Double>) {
        this.values = values
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val midY = h / 2f
        canvas.drawLine(0f, midY, w, midY, axisPaint)

        if (values.isEmpty()) {
            canvas.drawText("Play a game to start charting reward", w / 2f, midY - 10f, emptyPaint)
            return
        }

        val maxAbs = values.maxOf { abs(it) }.coerceAtLeast(0.01)
        val barWidth = w / values.size
        values.forEachIndexed { i, v ->
            val ratio = (abs(v) / maxAbs).toFloat()
            val barHeight = ratio * (h / 2f - 4f)
            val left = i * barWidth + barWidth * 0.15f
            val right = (i + 1) * barWidth - barWidth * 0.15f
            if (v >= 0) {
                canvas.drawRect(left, midY - barHeight, right, midY, positivePaint)
            } else {
                canvas.drawRect(left, midY, right, midY + barHeight, negativePaint)
            }
        }
    }
}
