package com.example.checkersai.core

import kotlin.math.abs

/**
 * Stateless rules engine: legal move generation, mandatory capture / multi-jump
 * enforcement, promotion, and win/draw detection. Has no Android dependencies
 * so it can be unit tested and reused (including by the AI) in isolation.
 */
object CheckersRules {

    /** Consecutive non-capturing moves after which the game is called a draw. */
    private const val DRAW_MOVE_LIMIT = 80

    private val KING_DIRECTIONS = listOf(
        Position(-1, -1), Position(-1, 1), Position(1, -1), Position(1, 1)
    )

    private fun forwardDirections(color: PieceColor): List<Position> = when (color) {
        // BLACK advances toward row 0, RED advances toward row 7.
        PieceColor.BLACK -> listOf(Position(-1, -1), Position(-1, 1))
        PieceColor.RED -> listOf(Position(1, -1), Position(1, 1))
    }

    private fun directionsFor(piece: Piece): List<Position> =
        if (piece.isKing) KING_DIRECTIONS else forwardDirections(piece.color)

    /**
     * All legal moves for the player to move in [state]. If [GameState.mustContinueFrom]
     * is set, only further jumps from that piece are returned (multi-jump rule).
     * Otherwise, if any capture is available anywhere on the board, only capture
     * moves are legal (mandatory capture rule); simple moves are returned only
     * when no capture exists for the side to move.
     */
    fun legalMoves(state: GameState): List<Move> {
        val board = state.board
        val color = state.turn

        state.mustContinueFrom?.let { pos ->
            return jumpsFrom(board, pos)
        }

        val allPositions = board.positionsOf(color)
        val jumps = allPositions.flatMap { jumpsFrom(board, it) }
        if (jumps.isNotEmpty()) return jumps

        return allPositions.flatMap { simpleMovesFrom(board, it) }
    }

    private fun simpleMovesFrom(board: Board, pos: Position): List<Move> {
        val piece = board.pieceAt(pos) ?: return emptyList()
        val moves = ArrayList<Move>(4)
        for (dir in directionsFor(piece)) {
            val to = pos + dir
            if (to.isOnBoard() && board.isEmpty(to)) {
                moves.add(Move(pos, to))
            }
        }
        return moves
    }

    private fun jumpsFrom(board: Board, pos: Position): List<Move> {
        val piece = board.pieceAt(pos) ?: return emptyList()
        val moves = ArrayList<Move>(4)
        for (dir in directionsFor(piece)) {
            val over = pos + dir
            val to = over + dir
            if (!to.isOnBoard()) continue
            val overPiece = board.pieceAt(over)
            if (overPiece != null && overPiece.color != piece.color && board.isEmpty(to)) {
                moves.add(Move(pos, to, captured = over))
            }
        }
        return moves
    }

    /** Result of applying a move: the resulting state plus reward-relevant details. */
    data class ApplyResult(
        val state: GameState,
        val capturedCount: Int,
        val promoted: Boolean
    )

    /**
     * Applies [move] (which must come from [legalMoves] for [state]) and returns
     * the resulting state, correctly handling capture removal, promotion,
     * mandatory multi-jump continuation, turn switching, and win/draw detection.
     */
    fun applyMove(state: GameState, move: Move): ApplyResult {
        var board = state.board
        val mover = board.pieceAt(move.from) ?: error("No piece at ${move.from}")

        val reachedBackRow = when (mover.color) {
            PieceColor.BLACK -> move.to.row == 0
            PieceColor.RED -> move.to.row == Board.SIZE - 1
        }
        val resultingPiece = if (reachedBackRow) mover.promoted() else mover
        val promoted = reachedBackRow && !mover.isKing

        board = board.withMoved(move.from, move.to, resultingPiece)
        move.captured?.let { board = board.with(it, null) }

        val capturedCount = if (move.isJump) 1 else 0
        val movesSinceCapture = if (move.isJump) 0 else state.movesSinceCapture + 1

        // Multi-jump: the same player continues if this piece has another jump
        // available, unless it just promoted (a jump landing on the king row
        // ends the turn even if a further jump would otherwise be possible).
        val mustContinue = move.isJump && !promoted && jumpsFrom(board, move.to).isNotEmpty()

        val nextState = if (mustContinue) {
            state.copy(
                board = board,
                mustContinueFrom = move.to,
                movesSinceCapture = movesSinceCapture
            )
        } else {
            state.copy(
                board = board,
                turn = state.turn.opposite(),
                mustContinueFrom = null,
                movesSinceCapture = movesSinceCapture
            )
        }

        val finalState = nextState.copy(status = computeStatus(nextState))
        return ApplyResult(finalState, capturedCount, promoted)
    }

    private fun computeStatus(state: GameState): GameStatus {
        if (state.board.countPieces(PieceColor.BLACK) == 0) return GameStatus.Won(PieceColor.RED)
        if (state.board.countPieces(PieceColor.RED) == 0) return GameStatus.Won(PieceColor.BLACK)
        if (state.movesSinceCapture >= DRAW_MOVE_LIMIT) return GameStatus.Draw
        if (legalMoves(state).isEmpty()) return GameStatus.Won(state.turn.opposite())
        return GameStatus.InProgress
    }

    /** Whether [move] is one of the currently legal moves for [state]. */
    fun isLegal(state: GameState, move: Move): Boolean =
        legalMoves(state).any { it.from == move.from && it.to == move.to }

    /**
     * A short, human-readable reason [move] is illegal for [state]. Intended for
     * diagnostics/UI (e.g. showing why one of the AI's blind guesses was
     * rejected) — not exhaustive of every edge case, but covers the common ones.
     */
    fun explainIllegal(state: GameState, move: Move): String {
        val board = state.board
        val piece = board.pieceAt(move.from)
            ?: return "there's no piece on the square it guessed as the start"
        if (piece.color != state.turn)
            return "that square doesn't hold one of its own pieces"
        if (!move.to.isOnBoard() || !move.to.isDarkSquare())
            return "the destination isn't a playable square"
        if (!board.isEmpty(move.to))
            return "the destination square is already occupied"

        state.mustContinueFrom?.let { forced ->
            if (move.from != forced) return "it must keep jumping with the piece that just captured"
        }

        val rowDiff = move.to.row - move.from.row
        val colDiff = move.to.col - move.from.col
        val forward = if (piece.color == PieceColor.BLACK) -1 else 1

        if (rowDiff == 0 || abs(rowDiff) != abs(colDiff)) {
            return "that isn't a diagonal move"
        }

        return when (abs(rowDiff)) {
            1 -> when {
                !piece.isKing && rowDiff != forward -> "a regular piece can't move backward"
                legalMoves(state).any { it.isJump } -> "a capture is available, so it's mandatory this turn"
                else -> "not a legal move from here"
            }
            2 -> {
                val overPos = Position(move.from.row + rowDiff / 2, move.from.col + colDiff / 2)
                val overPiece = board.pieceAt(overPos)
                when {
                    !piece.isKing && rowDiff != forward * 2 -> "a regular piece can't jump backward"
                    overPiece == null -> "there's no piece to jump over"
                    overPiece.color == piece.color -> "it can't jump its own piece"
                    else -> "not a legal jump from here"
                }
            }
            else -> "that's more than one diagonal step away"
        }
    }
}
