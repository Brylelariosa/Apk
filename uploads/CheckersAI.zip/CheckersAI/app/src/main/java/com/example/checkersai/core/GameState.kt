package com.example.checkersai.core

/**
 * Full snapshot of a game in progress: the board, whose turn it is, whether
 * that player is mid mandatory multi-jump, and a move-without-capture
 * counter used for the practical draw rule.
 */
data class GameState(
    val board: Board,
    val turn: PieceColor,
    val mustContinueFrom: Position? = null,
    val movesSinceCapture: Int = 0,
    val status: GameStatus = GameStatus.InProgress
) {
    companion object {
        fun new(): GameState = GameState(board = Board.initial(), turn = PieceColor.BLACK)
    }
}
