package com.example.checkersai.ai

data class AiStats(
    var gamesPlayed: Int = 0,
    var wins: Int = 0,
    var losses: Int = 0,
    var draws: Int = 0
) {
    fun record(outcome: Double) {
        gamesPlayed++
        when {
            outcome > 0.0 -> wins++
            outcome < 0.0 -> losses++
            else -> draws++
        }
    }
}
