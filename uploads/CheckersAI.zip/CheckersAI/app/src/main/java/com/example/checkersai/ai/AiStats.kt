package com.example.checkersai.ai

/**
 * Running record of how the AI has done, including a bounded history of
 * per-game total reward so the UI can chart a trend over recent games.
 */
data class AiStats(
    var gamesPlayed: Int = 0,
    var wins: Int = 0,
    var losses: Int = 0,
    var draws: Int = 0,
    var cumulativeReward: Double = 0.0,
    val recentGameRewards: MutableList<Double> = mutableListOf()
) {
    companion object {
        const val HISTORY_LIMIT = 30
    }

    fun recordGame(outcome: Double, totalGameReward: Double) {
        gamesPlayed++
        when {
            outcome > 0.0 -> wins++
            outcome < 0.0 -> losses++
            else -> draws++
        }
        cumulativeReward += totalGameReward
        recentGameRewards.add(totalGameReward)
        while (recentGameRewards.size > HISTORY_LIMIT) recentGameRewards.removeAt(0)
    }

    fun averageRewardPerGame(): Double = if (gamesPlayed == 0) 0.0 else cumulativeReward / gamesPlayed

    fun reset() {
        gamesPlayed = 0
        wins = 0
        losses = 0
        draws = 0
        cumulativeReward = 0.0
        recentGameRewards.clear()
    }
}
