package com.example.checkersai.ai

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Persists [AiStats] as a small JSON file in app-private storage. */
class FileStatsStore(context: Context) : StatsStore {

    private val file = File(context.filesDir, "checkers_ai_stats.json")

    override fun load(): AiStats {
        if (!file.exists()) return AiStats()
        return try {
            val json = JSONObject(file.readText())
            val history = ArrayList<Double>()
            val arr = json.optJSONArray("recentGameRewards")
            if (arr != null) {
                for (i in 0 until arr.length()) history.add(arr.getDouble(i))
            }
            AiStats(
                gamesPlayed = json.optInt("gamesPlayed", 0),
                wins = json.optInt("wins", 0),
                losses = json.optInt("losses", 0),
                draws = json.optInt("draws", 0),
                cumulativeReward = json.optDouble("cumulativeReward", 0.0),
                recentGameRewards = history
            )
        } catch (e: Exception) {
            // Corrupt or unreadable save file: start fresh rather than crash.
            AiStats()
        }
    }

    override fun save(stats: AiStats) {
        // Serialize synchronously (cheap: a handful of numbers) so the write
        // reflects exactly this call's snapshot, then flush off the main thread.
        val json = JSONObject()
        json.put("gamesPlayed", stats.gamesPlayed)
        json.put("wins", stats.wins)
        json.put("losses", stats.losses)
        json.put("draws", stats.draws)
        json.put("cumulativeReward", stats.cumulativeReward)
        val arr = JSONArray()
        for (v in stats.recentGameRewards) arr.put(v)
        json.put("recentGameRewards", arr)
        val text = json.toString()

        Thread {
            try {
                file.writeText(text)
            } catch (e: Exception) {
                // Best-effort persistence.
            }
        }.start()
    }

    override fun clear() {
        if (file.exists()) file.delete()
    }
}
