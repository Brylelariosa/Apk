package com.example.checkersai.core

/**
 * Immutable 8x8 checkers board. Only dark squares are ever occupied.
 * Every mutating operation returns a new [Board] instance so game states can
 * be freely shared/cached (e.g. as Q-learning keys) without defensive copying
 * or aliasing bugs.
 */
class Board private constructor(private val cells: Array<Piece?>) {

    companion object {
        const val SIZE = 8

        fun empty(): Board = Board(arrayOfNulls(SIZE * SIZE))

        /** Standard starting position: 12 pieces per side on the first three rows. */
        fun initial(): Board {
            val cells = arrayOfNulls<Piece>(SIZE * SIZE)
            for (row in 0..2) {
                for (col in 0 until SIZE) {
                    val pos = Position(row, col)
                    if (pos.isDarkSquare()) cells[index(row, col)] = Piece(PieceColor.RED)
                }
            }
            for (row in 5..7) {
                for (col in 0 until SIZE) {
                    val pos = Position(row, col)
                    if (pos.isDarkSquare()) cells[index(row, col)] = Piece(PieceColor.BLACK)
                }
            }
            return Board(cells)
        }

        private fun index(row: Int, col: Int) = row * SIZE + col
    }

    fun pieceAt(pos: Position): Piece? {
        if (!pos.isOnBoard()) return null
        return cells[index(pos.row, pos.col)]
    }

    fun isEmpty(pos: Position): Boolean = pieceAt(pos) == null

    /** Returns a new board with [pos] set to [piece] (null clears the square). */
    fun with(pos: Position, piece: Piece?): Board {
        val copy = cells.copyOf()
        copy[index(pos.row, pos.col)] = piece
        return Board(copy)
    }

    /** Returns a new board with a piece moved from [from] to [to]. */
    fun withMoved(from: Position, to: Position, resultingPiece: Piece): Board {
        val copy = cells.copyOf()
        copy[index(from.row, from.col)] = null
        copy[index(to.row, to.col)] = resultingPiece
        return Board(copy)
    }

    fun positionsOf(color: PieceColor): List<Position> {
        val result = ArrayList<Position>(12)
        for (row in 0 until SIZE) {
            for (col in 0 until SIZE) {
                val p = cells[index(row, col)]
                if (p != null && p.color == color) result.add(Position(row, col))
            }
        }
        return result
    }

    fun countPieces(color: PieceColor): Int = positionsOf(color).size

    /**
     * Compact, deterministic string encoding of the 32 dark squares, used as
     * the Q-table's state key: '.' empty, 'b'/'B' black man/king, 'r'/'R' red
     * man/king.
     */
    fun encode(): String {
        val sb = StringBuilder(32)
        for (row in 0 until SIZE) {
            for (col in 0 until SIZE) {
                val pos = Position(row, col)
                if (!pos.isDarkSquare()) continue
                val p = cells[index(row, col)]
                sb.append(
                    when {
                        p == null -> '.'
                        p.color == PieceColor.BLACK && !p.isKing -> 'b'
                        p.color == PieceColor.BLACK -> 'B'
                        !p.isKing -> 'r'
                        else -> 'R'
                    }
                )
            }
        }
        return sb.toString()
    }
}
