package com.example.checkersai.core

/**
 * The two sides in a game of checkers.
 *
 * BLACK is the traditional "dark" side and always moves first. BLACK starts
 * near the bottom of the board (rows 5-7) and advances toward row 0. RED
 * starts near the top (rows 0-2) and advances toward row 7.
 */
enum class PieceColor {
    BLACK,
    RED;

    fun opposite(): PieceColor = if (this == BLACK) RED else BLACK
}
