package com.example.checkersai.core

sealed class GameStatus {
    object InProgress : GameStatus()
    data class Won(val winner: PieceColor) : GameStatus()
    object Draw : GameStatus()
}
