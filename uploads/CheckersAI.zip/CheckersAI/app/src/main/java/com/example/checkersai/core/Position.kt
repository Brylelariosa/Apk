package com.example.checkersai.core

data class Position(val row: Int, val col: Int) {
    fun isOnBoard(): Boolean = row in 0 until Board.SIZE && col in 0 until Board.SIZE

    fun isDarkSquare(): Boolean = (row + col) % 2 == 1

    operator fun plus(other: Position) = Position(row + other.row, col + other.col)
}
