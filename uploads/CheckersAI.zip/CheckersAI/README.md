# Checkers AI (Android)

A native Android checkers game with a Q-learning AI opponent, structured to
be dropped straight into your existing "Build APK" GitHub Actions workflow.

## Rules implemented
- 8x8 board, only dark squares used, 12 pieces per side on the first three rows.
- Black moves first.
- Regular pieces move one diagonal step forward only.
- Captures are mandatory: if any capture is available anywhere on the board,
  only capture moves may be played that turn.
- Multi-jumps are mandatory: if the piece that just captured can capture
  again, it must keep jumping with that same piece before the turn passes.
- Reaching the back row promotes a piece to King (movement in all four
  diagonal directions, forward and backward). A jump that lands on the king
  row ends the turn even if another jump would otherwise be available.
- Win by capturing all enemy pieces or leaving the opponent with no legal
  move. 80 plies without a capture is called a draw (a common practical
  stand-in for official "no forced win" draw adjudication).

All of this lives in `core/CheckersRules.kt`, which has no Android
dependency at all and is the single source of truth for legality — the UI
and the AI both go through it, so neither can ever make an illegal move
stick on the board.

## How the AI works (`ai/QLearningAgent.kt`)
It's a small **tabular Q-learning** agent — a lookup table of
(board position, move) → learned value, *not* a deep neural network. Kept
weak on purpose:

- **Mostly explores.** With probability `epsilon` (starts at 85%, floored at
  35%) it guesses a from/to square pair the way a beginner blindly guessing
  would — with no idea what's legal. Illegal guesses are rejected by the
  rules engine and immediately recorded as a **negative reward** against
  that (board position, attempted move) pair, then it guesses again (up to
  25 tries, after which it just plays a random *legal* move so the game
  always keeps moving).
- **Sometimes exploits.** The rest of the time it plays whichever of its
  currently legal moves has the highest learned value.
- Captures, king promotions, illegal-guess penalties, and the eventual
  win/loss/draw all feed a reward back into the Q-table entry they apply to,
  via a standard Q-learning backup (`reward + γ·future − old`, learning
  rate α).
- `epsilon` decays slowly after each game but never drops below 35%, so it
  keeps learning without turning into a strong player.
- Learning **and** stats persist between games *and app restarts*, in two
  small JSON files in app-private storage (`ai/FileQTable.kt`,
  `ai/FileStatsStore.kt`). "Reset AI Brain" wipes both and starts over.

### Seeing what it's doing
Two things used to be invisible and now aren't:

- **Illegal attempts.** Every rejected guess the AI makes flashes red on the
  two squares involved (`ui/BoardView.flashIllegalAttempt`) with a line
  between them, and a toast explains *why* it was rejected — not diagonal,
  destination occupied, backward move, mandatory capture available
  elsewhere, must continue the jump chain, etc. (`CheckersRules.explainIllegal`).
- **The "AI Brain" panel** under the board shows, live: exploration rate
  (with a progress bar), average reward per completed game, a bar-chart
  sparkline of the last 30 games' total reward (green above zero, red
  below), and how many distinct board-position/action pairs it has learned
  a value for so far.

## Project layout
```
core/    Board, Piece, Move, GameState, CheckersRules — pure Kotlin, no Android
ai/      QLearningAgent, QTable/FileQTable, StatsStore/FileStatsStore, AiStats — pure Kotlin, no Android
game/    GameController — orchestrates rules + human input + AI turns
ui/      BoardView, RewardChartView — rendering and touch handling
MainActivity.kt — wires it all to the screen
```

## APK size
- Only `androidx.appcompat` is a real dependency (`AppCompatActivity` +
  `AlertDialog` + Day/Night theming). Material Components was previously
  listed but nothing in the app actually used a Material widget — only its
  theme — so it's been dropped in favor of `Theme.AppCompat.DayNight.NoActionBar`,
  which supports the same `AlertDialog` and theme attributes. `core-ktx` was
  also unused and dropped.
- `resConfigs "en"` keeps the build from bundling AppCompat's own internal
  strings translated into dozens of languages the app doesn't otherwise localize into.
- The release build type has `minifyEnabled true` + `shrinkResources true`
  (R8), with two defensive `-keep` rules in `proguard-rules.pro` for the
  custom Views inflated from XML (`BoardView`, `RewardChartView`) — belt and
  suspenders on top of AGP's automatic keep-rule generation for views
  referenced in layouts.
- No NDK/native code at all, so there's nothing to strip there either.
- Debug builds are left unminified, per normal convention, in case you ever
  want to build/inspect one for troubleshooting.

## Building via your workflow
Zip the contents of this folder (so `settings.gradle` sits at the top of the
zip, or a shallow subfolder) and push it into `uploads/` on `main` or
`master`. Your workflow will build a debug APK (or a signed, shrunk release
APK if you've set the `KEYSTORE_BASE64`/`STORE_PASSWORD`/`KEY_ALIAS`/`KEY_PASSWORD`
secrets), upload it as a build artifact, then delete the zip automatically.

Gradle 8.6 + Android Gradle Plugin 8.3.2 + Kotlin 1.9.23 + JDK 17,
`compileSdk`/`targetSdk` 34, `minSdk` 26 — matches the toolchain your
workflow already sets up.

## Tuning
Reward shaping and learning-rate constants (`CAPTURE_REWARD`, `KING_REWARD`,
`EPSILON_MIN`, `ALPHA`, `GAMMA`, etc.) live at the top of `QLearningAgent`'s
companion object if you want to make the AI stronger, weaker, or faster or
slower to learn.
