# Checkers AI (Android)

A native Android checkers game with a Q-learning AI opponent, structured to
be dropped straight into your existing "Build APK" GitHub Actions workflow.

## Rules implemented
- 8x8 board, only dark squares used, 12 pieces per side on the first three rows.
- Black moves first.
- Regular pieces move one diagonal step forward only.
- Captures are mandatory: if any capture is available anywhere on the board,
  only capture moves may be played that turn.
- Multi-jumps are mandatory: if the piece that just captured can capture
  again, it must keep jumping with that same piece before the turn passes.
- Reaching the back row promotes a piece to King (movement in all four
  diagonal directions, forward and backward). A jump that lands on the king
  row ends the turn even if another jump would otherwise be available.
- Win by capturing all enemy pieces or leaving the opponent with no legal
  move. 80 plies without a capture is called a draw (a common practical
  stand-in for official "no forced win" draw adjudication).

All of this lives in `core/CheckersRules.kt`, which has no Android
dependency at all and is the single source of truth for legality — the UI
and the AI both go through it, so neither can ever make an illegal move
stick on the board.

## How the AI works (`ai/QLearningAgent.kt`)
It's a small tabular Q-learning agent, on purpose kept weak:

- **Mostly explores.** With probability `epsilon` (starts at 85%, floored at
  35%) it guesses a from/to square pair the way a beginner blindly guessing
  would — with no idea what's legal. Illegal guesses are rejected by the
  rules engine and immediately recorded as a **negative reward** against
  that (board position, attempted move) pair, then it guesses again (up to
  25 tries, after which it just plays a random *legal* move so the game
  always keeps moving).
- **Sometimes exploits.** The rest of the time it plays whichever of its
  currently legal moves has the highest learned value.
- Captures, king promotions, and the eventual win/loss/draw all feed a
  reward back into the Q-table entry it just used, via a standard Q-learning
  backup (`reward + γ·future − old`, applied with learning rate α).
- `epsilon` decays slowly after each game but never drops below 35%, so it
  keeps learning without turning into a strong player — it should stay
  beatable.
- Learning persists between games *and app restarts*, in a small JSON file
  in app-private storage (`ai/FileQTable.kt`). Use the "Reset AI Brain"
  button to wipe it and watch it start over from scratch.

## Project layout
```
core/    Board, Piece, Move, GameState, CheckersRules — pure Kotlin, no Android
ai/      QLearningAgent, QTable, FileQTable, AiStats — pure Kotlin, no Android
game/    GameController — orchestrates rules + human input + AI turns
ui/      BoardView — rendering and touch handling
MainActivity.kt — wires it all to the screen
```

## Building via your workflow
Zip the contents of this folder (so `settings.gradle` sits at the top of the
zip, or a shallow subfolder) and push it into `uploads/` on `main` or
`master`. Your workflow will build a debug APK (or a signed release APK if
you've set the `KEYSTORE_BASE64`/`STORE_PASSWORD`/`KEY_ALIAS`/`KEY_PASSWORD`
secrets), upload it as a build artifact, then delete the zip automatically.

Gradle 8.6 + Android Gradle Plugin 8.3.2 + Kotlin 1.9.23 + JDK 17,
`compileSdk`/`targetSdk` 34, `minSdk` 26 — matches the toolchain your
workflow already sets up.

## Tuning
Reward shaping and learning-rate constants (`CAPTURE_REWARD`, `KING_REWARD`,
`EPSILON_MIN`, `ALPHA`, `GAMMA`, etc.) live at the top of `QLearningAgent`'s
companion object if you want to make the AI stronger, weaker, or faster or
slower to learn.
