package com.game.topdown;

import android.graphics.*;
import java.util.*;
import java.util.concurrent.*;
import org.json.*;
import static com.game.topdown.MapData.*;
import static com.game.topdown.PhysicsSystem.*;
import static com.game.topdown.GameConstants.*;

/** Bomb and air-strike logic. Receives GameState, mutates it in place. */
public class BombSystem {

private void startBombThrow(GameState state) {
    Player lp = state.localPlayer;
    if (lp == null || !lp.alive || lp.bombs <= 0) return;
    // Only one active bomb allowed at a time
    for (Bomb b : state.activeBombs) { if (b.ownerId == lp.id && !b.isDone() && b.explodedAt < 0) return; }
    if (state.throwingBomb) { state.throwingBomb = false; return; }  // tap again to cancel
    state.throwingBomb = true;
}

private void executeThrow(GameState state, float ax, float ay) {
    state.throwingBomb = false;
    Player lp = state.localPlayer;
    if (lp == null || !lp.alive || lp.bombs <= 0) return;
    float mag = (float) Math.sqrt(ax * ax + ay * ay);
    if (mag < 0.08f) return;
    for (Bomb b : state.activeBombs) { if (b.ownerId == lp.id && !b.isDone() && b.explodedAt < 0) return; }
    lp.bombs--;
    float vx = ax * Bomb.THROW_SPEED;
    float vy = ay * Bomb.THROW_SPEED;
    float maxRange = mag * Bomb.THROW_RANGE;
    if (state.isHost) {
        // Host owns all bombs — create directly
        Bomb bomb = new Bomb(lp.x, lp.y, lp.id);
        bomb.vx = vx; bomb.vy = vy; bomb.maxRange = maxRange;
        state.activeBombs.add(bomb);
    } else {
        // Client: queue for next sendInput so host creates the authoritative bomb
        pendingBombSend = new float[]{vx, vy, maxRange};
    }
}

private void updateBombs(GameState state, Player lp, float dt) {
    if (!state.isHost) return;
    long now = System.currentTimeMillis();
    Iterator<Bomb> it = state.activeBombs.iterator();
    while (it.hasNext()) {
        Bomb b = it.next();
        if (b.isDone()) { it.remove(); continue; }

        // ── Move the bomb while in flight ─────────────────────────────────
        if (!b.hasLanded) {
            float nx = b.x + b.vx * dt;
            float ny = b.y + b.vy * dt;
            boolean outOfRange = b.traveledSq() >= b.maxRange * b.maxRange;
            boolean outOfMap   = nx < 0 || nx > MAP_W || ny < 0 || ny > MAP_H;

            if (outOfRange || outOfMap) {
                // Clamp to map and land with a roll in current travel direction
                nx = Math.max(0, Math.min(MAP_W, nx));
                ny = Math.max(0, Math.min(MAP_H, ny));
                b.x = nx; b.y = ny;
                b.rollVx = b.vx * Bomb.LAND_ROLL_FACTOR;
                b.rollVy = b.vy * Bomb.LAND_ROLL_FACTOR;
                b.hasLanded = true; b.vx = 0; b.vy = 0;
            } else {
                // Axis-separated wall bounce so the reflection axis is correct
                boolean xBlocked = false, yBlocked = false;
                for (float[] w : WALLS) {
                    if (!xBlocked && nx >= w[0] && nx <= w[2] && b.y >= w[1] && b.y <= w[3]) xBlocked = true;
                    if (!yBlocked && b.x >= w[0] && b.x <= w[2] && ny >= w[1] && ny <= w[3]) yBlocked = true;
                }
                if (xBlocked) b.vx = -b.vx * Bomb.BOUNCE_RESTITUTION;
                if (yBlocked) b.vy = -b.vy * Bomb.BOUNCE_RESTITUTION;
                if (xBlocked || yBlocked) {
                    // Bounced off a wall — land and give roll velocity in reflected direction
                    b.rollVx = b.vx * Bomb.LAND_ROLL_FACTOR;
                    b.rollVy = b.vy * Bomb.LAND_ROLL_FACTOR;
                    b.hasLanded = true; b.vx = 0; b.vy = 0;
                } else {
                    b.x = nx; b.y = ny;
                }
            }
        }

        // ── Roll the bomb along the ground with friction ───────────────────
        if (b.hasLanded && (b.rollVx != 0 || b.rollVy != 0)) {
            float speed = (float) Math.sqrt(b.rollVx * b.rollVx + b.rollVy * b.rollVy);
            float decel = Bomb.ROLL_FRICTION * dt;
            if (decel >= speed) {
                b.rollVx = 0; b.rollVy = 0;
            } else {
                float factor = (speed - decel) / speed;
                b.rollVx *= factor;
                b.rollVy *= factor;
                float rnx = b.x + b.rollVx * dt;
                float rny = b.y + b.rollVy * dt;
                // Axis-separated wall bounce while rolling (damped)
                boolean rxBlocked = false, ryBlocked = false;
                for (float[] w : WALLS) {
                    if (!rxBlocked && rnx >= w[0] && rnx <= w[2] && b.y >= w[1] && b.y <= w[3]) rxBlocked = true;
                    if (!ryBlocked && b.x >= w[0] && b.x <= w[2] && rny >= w[1] && rny <= w[3]) ryBlocked = true;
                }
                if (rxBlocked) b.rollVx = -b.rollVx * Bomb.BOUNCE_RESTITUTION;
                if (ryBlocked) b.rollVy = -b.rollVy * Bomb.BOUNCE_RESTITUTION;
                // Apply map boundary bounce
                if (rnx < 0 || rnx > MAP_W) { b.rollVx = -b.rollVx * Bomb.BOUNCE_RESTITUTION; rnx = Math.max(0, Math.min(MAP_W, rnx)); }
                if (rny < 0 || rny > MAP_H) { b.rollVy = -b.rollVy * Bomb.BOUNCE_RESTITUTION; rny = Math.max(0, Math.min(MAP_H, rny)); }
                if (!rxBlocked) b.x = rnx;
                if (!ryBlocked) b.y = rny;
                // Kill negligible roll after bouncing
                float newSpeed = (float) Math.sqrt(b.rollVx * b.rollVx + b.rollVy * b.rollVy);
                if (newSpeed < Bomb.MIN_ROLL_SPEED) { b.rollVx = 0; b.rollVy = 0; }
            }
        }

        // ── Explode when fuse burns out ───────────────────────────────────
        if (b.shouldExplode()) {
            b.explodedAt = now;
            // Damage local player (no friendly fire)
            if (lp.alive && b.ownerId != lp.id
                    && d2(b.x, b.y, lp.x, lp.y) < Bomb.RADIUS * Bomb.RADIUS) {
                if(!lp.isProtected()){
                    float dmg = Bomb.DAMAGE;
                    if(lp.isShielded()){
                        float reduced=dmg*0.5f;float abs=Math.min(reduced,lp.shieldHp); lp.shieldHp-=abs; dmg-=abs;
                        if(lp.shieldHp<=0) lp.skillActiveUntil=0;
                    }
                    lp.hp = Math.max(0, lp.hp - dmg);
                    if (lp.hp == 0) {
                        lp.alive = false; deathTime = now;
                        addFeed(nameOf(b.ownerId) + " \uD83D\uDCA3 " + lp.name);
                        onKill(state.remote.get(b.ownerId), lp);
                    }
                }
            }
            // Damage state.remote players
            for (Player rp : state.remote.values()) {
                if (!rp.alive || b.ownerId == rp.id) continue;
                if (d2(b.x, b.y, rp.x, rp.y) < Bomb.RADIUS * Bomb.RADIUS) {
                    if(!rp.isProtected()){
                        float dmg = Bomb.DAMAGE;
                        if(rp.isShielded()){
                            float reduced=dmg*0.5f;float abs=Math.min(reduced,rp.shieldHp); rp.shieldHp-=abs; dmg-=abs;
                            if(rp.shieldHp<=0) rp.skillActiveUntil=0;
                        }
                        rp.hp = Math.max(0, rp.hp - dmg);
                        if (rp.hp == 0) {
                            rp.alive = false; state.deadAtMs.put(rp.id, now);
                            if (!state.dummyIds.contains(rp.id)) {
                                addFeed(nameOf(b.ownerId) + " \uD83D\uDCA3 " + rp.name);
                                if (b.ownerId == lp.id) {
                                    onKill(lp, rp);
                                } else {
                                    Player killer = state.remote.get(b.ownerId);
                                    onKill(killer, rp);
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private void updateAirStrikes(GameState state, Player lp) {
    if (!state.isHost) return;
    long now = System.currentTimeMillis();
    Iterator<double[]> it = state.airStrikes.iterator();
    while (it.hasNext()) {
        double[] as = it.next();
        float sx = (float) as[0], sy = (float) as[1];
        long triggerMs = (long) as[2];
        int ownerId = (int) as[3];
        long flashUntil = (long) as[4];

        // Not yet triggered
        if (now < (long) triggerMs) continue;

        // Trigger: do damage once (flashUntil == 0 means not yet exploded)
        if (flashUntil == 0L) {
            as[4] = now + AS_FLASH_MS;
            // Damage local player
            if (lp != null && lp.alive && ownerId != lp.id
                    && d2(sx, sy, lp.x, lp.y) < AS_RADIUS * AS_RADIUS) {
                if (!lp.isProtected()) {
                    float dmg = AS_DAMAGE;
                    if (lp.isShielded()) {
                        float reduced = dmg * 0.5f;
                        float abs = Math.min(reduced, lp.shieldHp);
                        lp.shieldHp -= abs; dmg -= abs;
                        if (lp.shieldHp <= 0) lp.skillActiveUntil = 0;
                    }
                    lp.hp = Math.max(0, lp.hp - dmg);
                    if (lp.hp == 0) {
                        lp.alive = false; deathTime = now;
                        addFeed(nameOf(ownerId) + " ✈ " + lp.name);
                        onKill(state.remote.get(ownerId), lp);
                    }
                }
            }
            // Damage bots and state.remote players
            for (Player p : state.remote.values()) {
                if (p.id == ownerId || !p.alive) continue;
                if (d2(sx, sy, p.x, p.y) < AS_RADIUS * AS_RADIUS) {
                    if(!p.isProtected()){
                        float dmg = AS_DAMAGE;
                        if(p.isShielded()){
                            float reduced=dmg*0.5f;float abs=Math.min(reduced,p.shieldHp);p.shieldHp-=abs;dmg-=abs;
                            if(p.shieldHp<=0) p.skillActiveUntil=0;
                        }
                        p.hp = Math.max(0, p.hp - dmg);
                        if (p.hp == 0) {
                            p.alive = false;
                            state.deadAtMs.put(p.id, now); // FIX Bug1: air strike kills now trigger respawn
                            if (!state.dummyIds.contains(p.id)) {
                                addFeed(nameOf(ownerId) + " ✈ " + p.name);
                                Player asKiller = (lp != null && lp.id == ownerId) ? lp : state.remote.get(ownerId);
                                onKill(asKiller, p);
                            }
                        }
                    }
                }
            }
        }

        // Chain next explosion if remaining, else remove when flash is done
        if (now > (long) as[4] && as[4] > 0f) {
            int remaining = (as.length > 5) ? (int) as[5] : 0;
            if (remaining > 0) {
                // Scatter next explosion randomly near original target
                float scatter = AS_RADIUS * 0.9f; // scatter up to ~1 explosion radius away
                float nx = (float)(as[0] + (Math.random() - 0.5) * 2.0 * scatter);
                float ny = (float)(as[1] + (Math.random() - 0.5) * 2.0 * scatter);
                as[0] = Math.max(0, Math.min(MAP_W, nx));
                as[1] = Math.max(0, Math.min(MAP_H, ny));
                as[2] = now + 550L;  // next trigger in 550ms
                as[4] = 0L;           // reset flash (not yet exploded)
                as[5] = remaining - 1;
            } else {
                it.remove();
            }
        }
    }
}

}
