# PROJECT_STATE - Shadowborn Part 1

## Status
First playable foundation, complete Android Studio project (Java, Canvas, no AndroidX).
Delivered as `Shadowborn_Part1_Playable.zip`; combat / movement polish pass delivered as `Shadowborn_Part1_CombatPolish_*.zip`
(see POLISH_REPORT.md).

## Verification actually performed
- All Java sources compile with zero errors against minimal Android API stubs (JDK 21, `-source 11`). The stubs only
  cover the Android calls the game uses, so this proves the game code is internally consistent, not that it
  links against the real SDK.
- Headless scripted simulation (tools/headless): 40+ checks pass. Menu and settings flow, start, room 0 cleared
  by a bot with single jumps, checkpoint, jump-reach checks for every platform, secret ledge and chasm are
  NOT reachable without the double jump but are with it, shrine unlock, room transitions, boss fight and gate,
  Umbral Edge pickup, death and respawn, pause, vitality purchase, save and load, collected shards stay collected.
- Random-input soak test: 720,000 frames over 6 seeds (random buttons, taps, Back, resizes, warps, deaths,
  boss fights, rendering every frame) with no exceptions.
- Polish pass (see POLISH_REPORT.md): 134 more headless checks (tools/headless/sim/.../Mechanics.java) plus a gating search,
  an invariant fuzz and real-frame renders through a Java2D stand-in. Still headless only. The latest pass (v6) made the hero's sword
  short and light, put it on the back until the first blow draws it, and extended the ground combo to 5 hits.
- NOT done: Gradle was not run (no Android SDK or network here), no APK was built, nothing was run on a device
  or emulator. Visual quality, touch feel and performance on real phones are unverified.

## Implemented (spec sections A-F)
- A Gameplay: run, jump, variable-height jump, coyote time and jump buffer, gravity and tile collision, smoothed
  camera with look-ahead, 3 linked rooms, platforms, walls (incl. a hanging wall), pits, spikes, room transitions
  with fade, ember-shrine checkpoints, last-safe-ground respawn when falling into a pit.
- B Combat: 3-stage sword combo (horizontal slash, thrust, spin slash; startup/active/recovery frame tables, keyframed poses,
  damage 10/12/22, auto-spacing lunge, swept-blade hit detection, hit-stop, knockback), aerial combo (horizontal slash,
  spin slash, plunge), low dash slash,
  dash with i-frames, full-figure afterimages and speed streaks (air dash needs Wraith Stride), damage numbers, enemy and player health, death effects.
  Enemies: Husk (patrol, chase, telegraphed lunge, 34 HP) and Wraith (hovers, charges, fires homing-aim orbs, 22 HP).
  Mini-boss The Ashen Warden (280 HP, health bar, phase 2 at 50%): sweep, leap-slam with ground shockwaves,
  blade fan, and (phase 2) charge; attacks are telegraphed in red; the arena gate seals during the fight.
- C Progression: double jump (Wraith Stride shrine), shard currency, Umbral Edge upgrade (+50% damage, longer reach)
  dropped by the boss, Vitality purchases in the pause menu (cost 40 + 35 per level, max 5), SharedPreferences save.
- D Touch controls: custom-drawn LEFT, RIGHT, JUMP, ATTACK, DODGE with multi-touch and finger sliding between buttons.
- E Visuals: procedural glowing stickman with scarf and a real steel sword (trailing behind when running), weapon trails, impact sparks and rings, 3-layer parallax
  backdrops per room theme, moon, stars, mist, embers, vignette, screen shake. No emoji anywhere.
- F Interface: main menu (PLAY, SETTINGS), pause menu, settings (screen shake, control opacity, FPS counter, reset
  save), HP bar with damage ghost, shard counter, boss bar, room banners, death screen with respawn.

## Layout and tuning
Rooms: ASHEN GATE 64x12 tiles, GLOOM CRYPT 72x12, HOLLOW SANCTUM 30x12 (tile = 32 units, screen is 360 units tall).
Single jump ~87 units high / ~133 wide (86.6 / 133 measured); double jump total ~165 high, descent after it is floatier. Player 100 HP, run 190.
Rewards: Husk 4 shards, Wraith 3, boss 100, each pickup 1. Enemies respawn whenever a room is (re)entered.
Save file: SharedPreferences `shadowborn_save` (shards, vit, checkpoint, dj, edge, boss, collected-shard ids, settings).
Room maps are built with `Room.rect/put` calls in `World.build()`; legend is in the World.java header comment.

## Movement and combat tuning (Player.java constants)
RUN 190, JUMP_V 520, DJ_V 520, gravity 1500 rising / 2150 falling / 1000 near the apex / 5000 after the jump button is released,
coyote 0.10 s, jump buffer 0.14 s, attack buffer 0.22 s, dash buffer 0.18 s. Dash: 510 units/s eased out to 170, 0.24 s
(0.20 s in the air), cooldown 0.55 s, i-frames 0.30 s. Attack tables ST/AC/RC (all move data lives in Moves.java) are in frames at 60 Hz; the sword carry timings are in Sheath.java; the air dash and the
aerial hover are tied to progression on purpose: see the gating search in Mechanics.java before loosening any of them.

## Known limitations
- No audio. No minimap. One save slot. The hero can walk through the boss. Husks and Wraiths do not deal contact damage.
- Checkpoint heals only the first time each shrine is lit. Back button pauses; from the menu it exits.
- Backdrop bitmaps are 3 x 1024x360 ARGB (about 4.4 MB) rebuilt per theme change; tile drawing is one rect per tile.
- Camera cutout handling is a fixed 28-unit margin on HUD and buttons, not real display-cutout insets.

## Remaining tasks
See NEXT_TASK.md.
