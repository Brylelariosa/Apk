package com.shadowborn.game;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.Typeface;
import java.util.Random;

/** Procedural art: parallax backdrops, stick figures and glow helpers. No image assets are used. */
final class Art {
    private Art() {}

    static final Paint P = new Paint(Paint.ANTI_ALIAS_FLAG);
    static final Path PA = new Path();
    static final float PI = (float) Math.PI;
    static final Typeface FONT = Typeface.create("sans-serif-condensed", Typeface.BOLD);

    /** 0 sky top, 1 sky bottom, 2 far, 3 mid, 4 near, 5 stone, 6 stone edge, 7 window glow. */
    static final int[][] PAL = {
        {0xFF0A0618, 0xFF3A1442, 0xFF1A1030, 0xFF120A22, 0xFF0A0614, 0xFF2A2438, 0xFF7A68A8, 0xFFFFA860},
        {0xFF040A10, 0xFF0E2A30, 0xFF0C1E26, 0xFF08141A, 0xFF040A0E, 0xFF1F2C33, 0xFF4A9AA4, 0xFF60E0FF},
        {0xFF12040A, 0xFF4A0F1A, 0xFF2A0A14, 0xFF1A060E, 0xFF0C0206, 0xFF2C1C24, 0xFFB04A5A, 0xFFFF6040}
    };

    static final Paint GLOW_CYAN = glowPaint(0xFF58E0FF);
    static final Paint GLOW_ORANGE = glowPaint(0xFFFF9A40);
    static final Paint GLOW_VIOLET = glowPaint(0xFFB070FF);
    static final Paint GLOW_RED = glowPaint(0xFFFF3050);
    static final Paint GLOW_WHITE = glowPaint(0xFFFFFFFF);

    private static Paint glowPaint(int rgb) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        int only = rgb & 0x00FFFFFF;
        p.setShader(new RadialGradient(0f, 0f, 64f, 0xC0000000 | only, only, Shader.TileMode.CLAMP));
        return p;
    }

    /** Soft radial glow centred on (x, y) with radius r. */
    static void glow(Canvas c, Paint gp, float x, float y, float r, float a) {
        if (a <= 0f) return;
        gp.setAlpha((int) (255f * Math.min(1f, a)));
        c.save();
        c.translate(x, y);
        float k = r / 64f;
        c.scale(k, k);
        c.drawCircle(0f, 0f, 64f, gp);
        c.restore();
    }

    static void dot(Canvas c, float x, float y, float r, int col, int a) {
        P.setStyle(Paint.Style.FILL);
        P.setColor(col);
        P.setAlpha(a);
        c.drawCircle(x, y, r, P);
    }

    static int mix(int a, int b, float t) {
        if (t <= 0f) return a;
        int ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        int r = (int) (ar + (br - ar) * t), g = (int) (ag + (bg - ag) * t), bl = (int) (ab + (bb - ab) * t);
        return (a & 0xFF000000) | (r << 16) | (g << 8) | bl;
    }

    // ------------------------------------------------------------------ stick figures

    /** Pose + colours of one stick figure. Angles are radians from "straight down", forward positive. */
    static final class Fig {
        float x, y, s = 1f, vx, vy, t, lean, legF, legB, kneeF, kneeB, armB, swordAng, bladeLen = 24f, flash;
        /** wrist: blade angle relative to the sword arm (cocked back for wind-ups, snapped forward on strikes);
         *  reach: sword-arm length multiplier; rot: whole-body rotation in radians (clockwise), used for flips. */
        float wrist = 0.12f, reach = 1f, rot;
        /** az: the sword arm's turn about the vertical axis through the shoulder, in radians. 0 = in the screen plane
         *  (the classic side view), PI/2 = arm and blade pointing at the camera (end-on), PI = in the screen plane but
         *  pointing backwards. Sweeping az from PI to 0 is a horizontal slash. aura: 0..1 faint rim light on the blade. */
        float az, aura = 0.2f;
        int dir = 1, alpha = 255;
        int core = 0xFF05070C, glow = 0xFF3CD8FF, eye = 0xFFFFFFFF, scarfCol = 0xFFE0304C;
        /** Sword colours: blade = steel, hi = lit edge (0 = derived from blade), bladeGlow = rim light, guard = cross-guard and pommel, grip = leather. */
        int blade = 0xFFC9D3E2, hi, bladeGlow = 0xFF58E0FF, guard = 0xFFC9A24C, grip = 0xFF2A1A12, sheath = 0xFF2A2030;
        /** stow: where the sword is, 0 = in the hand, 1 = sheathed on the back (animated by the Player; see SwordArt). scabbard: the figure
         *  wears one. bladeW: blade and guard thickness (1 = the broad enemy sword). fullLen: blade length that ignores the floor clamp
         *  (the stowed sword never shrinks), 0 = use bladeLen. */
        float stow, bladeW = 1f, fullLen;
        boolean scabbard;
        /** Where the sheathed sword sits for the current torso (see SwordArt.mount): hilt x,y, tip x,y, pommel x,y, blade direction x,y. */
        final float[] m = new float[8];
        boolean scarf, horns, chest;
        /** Joints as x,y pairs: 0 hip, 1 neck, 2 head, 3 kneeF, 4 footF, 5 kneeB, 6 footB, 7 elbowB, 8 handB, 9 elbowF, 10 handF, 11 tip, 12 pommel. */
        final float[] j = new float[26];
    }

    static void hero(Fig f, boolean edge) {
        f.core = 0xFF05070C;
        f.glow = 0xFF3CD8FF;
        f.eye = 0xFFE8FFFF;
        // an ordinary steel sword; the Umbral Edge is a dark blade with a crimson lit edge
        f.blade = edge ? 0xFF6A5878 : 0xFFC9D3E2;
        f.hi = edge ? 0xFFFF6A80 : 0xFFFFFFFF;
        f.bladeGlow = edge ? 0xFFFF3050 : 0xFF58E0FF;
        f.guard = edge ? 0xFF8A6A9A : 0xFFC9A24C;
        f.grip = edge ? 0xFF1A1020 : 0xFF2A1A12;
        f.aura = edge ? 0.5f : 0.12f;
        // a light blade that suits the quick strikes: short and slim, with the scabbard on the back
        f.bladeLen = f.fullLen = edge ? 19f : 16f;
        f.bladeW = 0.62f;
        f.scabbard = true;
        f.stow = 1f;
        f.sheath = edge ? 0xFF1C1228 : 0xFF2A2030;
        f.scarf = true;
        f.scarfCol = 0xFFE0304C;
        f.horns = false;
        f.chest = false;
        f.alpha = 255;
        f.flash = 0f;
        f.wrist = 0.12f;
        f.reach = 1f;
        f.rot = 0f;
        f.az = 0f;
    }

    static void idle(Fig f, float t) {
        float b = (float) Math.sin(t * 2.2f);
        f.lean = 0.06f;
        f.legF = 0.14f; f.legB = -0.14f;
        f.kneeF = 0.12f + 0.06f * b; f.kneeB = 0.1f - 0.05f * b;
        f.armB = 0.25f + 0.05f * b;
        if (f.stow > 0.5f) {      // sword on the back: the arm just hangs
            f.swordAng = 0.12f - 0.05f * b;
            f.wrist = 0.2f;
        } else {
            f.swordAng = 0.55f + 0.05f * b;
        }
    }

    static void solve(Fig f) {
        float s = f.s, d = f.dir, len = 7f * s, torso = 10f * s, arm = 5.5f * s;
        float kfx = len * (float) Math.sin(f.legF) * d, kfy = len * (float) Math.cos(f.legF);
        float ffx = kfx + len * (float) Math.sin(f.legF - f.kneeF) * d, ffy = kfy + len * (float) Math.cos(f.legF - f.kneeF);
        float kbx = len * (float) Math.sin(f.legB) * d, kby = len * (float) Math.cos(f.legB);
        float fbx = kbx + len * (float) Math.sin(f.legB - f.kneeB) * d, fby = kby + len * (float) Math.cos(f.legB - f.kneeB);
        float hx = f.x, hy = f.y - Math.max(ffy, fby);
        float[] j = f.j;
        j[0] = hx; j[1] = hy;
        float lx = (float) Math.sin(f.lean) * d, ly = -(float) Math.cos(f.lean);
        float nx = hx + torso * lx, ny = hy + torso * ly;
        j[2] = nx; j[3] = ny;
        j[4] = nx + (float) Math.sin(f.lean * 1.3f) * d * 3.5f * s;
        j[5] = ny - 5.2f * s;
        j[6] = hx + kfx; j[7] = hy + kfy; j[8] = hx + ffx; j[9] = hy + ffy;
        j[10] = hx + kbx; j[11] = hy + kby; j[12] = hx + fbx; j[13] = hy + fby;
        float ay = ny + 1.5f * s;
        j[14] = nx + arm * (float) Math.sin(f.armB) * d; j[15] = ay + arm * (float) Math.cos(f.armB);
        j[16] = j[14] + arm * (float) Math.sin(f.armB + 0.5f) * d; j[17] = j[15] + arm * (float) Math.cos(f.armB + 0.5f);
        // Sword arm: elbow, hand and blade are laid out in the screen plane, then the whole arm is turned about the vertical axis
        // through the shoulder by az. The horizontal part of every segment is scaled by cos(az) (foreshortening) and its depth
        // part (sin(az)) shows as a small vertical shift, because the camera looks slightly down. With az = 0 this is exactly
        // the old flat solver; sweeping az from PI to 0 gives a flat horizontal slash whose tip traces a shallow smile.
        float sa = f.swordAng, ra = arm * f.reach;
        float ba = sa + f.wrist, bl = f.bladeLen * s;
        float ca = (float) Math.cos(f.az), sz = (float) Math.sin(f.az) * DEPTH;
        float droop = 0.25f * ca;      // the elbow hangs a little below the forearm; mirrored exactly when the arm points backwards (az = PI)
        float eh = ra * (float) Math.sin(sa - droop), ev = ra * (float) Math.cos(sa - droop);
        float fh = eh + ra * (float) Math.sin(sa), fv = ev + ra * (float) Math.cos(sa);
        float th = fh + bl * (float) Math.sin(ba), tv = fv + bl * (float) Math.cos(ba);
        float ph = fh - 3f * s * (float) Math.sin(ba), pv = fv - 3f * s * (float) Math.cos(ba);
        j[18] = nx + eh * ca * d; j[19] = ay + ev + eh * sz;
        j[20] = nx + fh * ca * d; j[21] = ay + fv + fh * sz;
        j[22] = nx + th * ca * d; j[23] = ay + tv + th * sz;
        j[24] = nx + ph * ca * d; j[25] = ay + pv + ph * sz;
        if (f.scabbard) SwordArt.mount(f);
    }

    /** How strongly depth shows as a vertical shift for a turned sword arm (sine of the camera's downward tilt). */
    private static final float DEPTH = 0.3f;

    /** Vertical screen component of the blade per unit of its length (positive = pointing down), for cutting it short at the floor. */
    static float bladeDrop(Fig f) {
        final float ba = f.swordAng + f.wrist;
        return (float) (Math.cos(ba) + Math.sin(ba) * Math.sin(f.az) * DEPTH);
    }

    private static final int[] SA = {0, 0, 3, 0, 5, 1, 7, 1, 9};
    private static final int[] SB = {1, 3, 4, 5, 6, 7, 8, 9, 10};
    private static final float[] SEG = new float[36];

    private static void limbs(Canvas c, float[] j, Paint p) {
        for (int i = 0; i < 9; i++) {
            SEG[i * 4] = j[SA[i] * 2];
            SEG[i * 4 + 1] = j[SA[i] * 2 + 1];
            SEG[i * 4 + 2] = j[SB[i] * 2];
            SEG[i * 4 + 3] = j[SB[i] * 2 + 1];
        }
        c.drawLines(SEG, 0, 36, p);
    }

    private static void scarf(Canvas c, Fig f, float a) {
        float[] j = f.j;
        float s = f.s, d = f.dir;
        float back = -d * (4.5f + Math.min(7f, Math.abs(f.vx) * 0.03f)) * s;
        float amp = Math.min(1f, 0.4f + Math.abs(f.vx) * 0.01f);
        float px = j[2], py = j[3] + s;
        float lift = -Math.max(-6f, Math.min(6f, f.vy * 0.016f)) * s;
        P.setStyle(Paint.Style.STROKE);
        P.setColor(f.scarfCol);
        for (int i = 1; i <= 4; i++) {
            float nx = px + back * 0.9f;
            float ny = py + (1.2f + (float) Math.sin(f.t * 9f + i * 1.3f) * 1.6f * amp) * s + lift * 0.5f;
            P.setStrokeWidth((3.4f - i * 0.5f) * s);
            P.setAlpha((int) ((235 - i * 25) * a));
            c.drawLine(px, py, nx, ny, P);
            px = nx;
            py = ny;
        }
    }

    /** Draws a figure: bloom + glow passes, a dark core, eye, optional horns/chest core and the sword. */
    static void draw(Canvas c, Fig f) {
        solve(f);
        final float[] j = f.j;
        final float s = f.s, a = f.alpha / 255f, d = f.dir;
        final Paint p = P;
        int core = mix(f.core, 0xFFFFFFFF, f.flash), gc = mix(f.glow, 0xFFFFFFFF, f.flash);
        final boolean rotated = f.rot != 0f;
        if (rotated) {
            float rx = (j[0] + j[2]) * 0.5f, ry = (j[1] + j[3]) * 0.5f;
            c.save();
            c.translate(rx, ry);
            c.rotate((float) Math.toDegrees(f.rot));
            c.translate(-rx, -ry);
        }
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
        // the sword is drawn behind the body while it hangs on the back, and while the sword arm has turned to the far side (second half of a spin)
        final boolean swordBehind = f.az < -0.6f || f.stow > 0.55f;
        if (f.scabbard) SwordArt.scabbard(c, f, a);
        if (swordBehind) SwordArt.sword(c, f, a);
        if (f.scarf) scarf(c, f, a);
        p.setStyle(Paint.Style.STROKE);
        p.setColor(gc);
        p.setAlpha((int) (40f * a)); p.setStrokeWidth(8.5f * s); limbs(c, j, p);
        p.setAlpha((int) (140f * a)); p.setStrokeWidth(4.8f * s); limbs(c, j, p);
        p.setStyle(Paint.Style.FILL);
        p.setAlpha((int) (40f * a)); c.drawCircle(j[4], j[5], 8f * s, p);
        p.setAlpha((int) (150f * a)); c.drawCircle(j[4], j[5], 6.2f * s, p);
        p.setStyle(Paint.Style.STROKE);
        p.setColor(core);
        p.setAlpha((int) (255f * a)); p.setStrokeWidth(2.7f * s); limbs(c, j, p);
        p.setStyle(Paint.Style.FILL);
        c.drawCircle(j[4], j[5], 4.7f * s, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.7f * s);
        p.setColor(f.eye);
        p.setAlpha((int) (255f * a));
        c.drawLine(j[4] + d * 1.2f * s, j[5] - 0.6f * s, j[4] + d * 4f * s, j[5] - 0.6f * s, p);
        if (f.horns) {
            p.setColor(gc);
            p.setAlpha((int) (230f * a));
            p.setStrokeWidth(2.2f * s);
            c.drawLine(j[4] - 2f * s, j[5] - 4f * s, j[4] - 4.5f * s, j[5] - 9f * s, p);
            c.drawLine(j[4] + 2f * s, j[5] - 4f * s, j[4] + 4.5f * s, j[5] - 9f * s, p);
        }
        if (f.chest) {
            float mx = (j[0] + j[2]) * 0.5f, my = (j[1] + j[3]) * 0.5f;
            glow(c, GLOW_RED, mx, my, 10f * s, a);
            dot(c, mx, my, 1.7f * s, 0xFFFFC0B0, (int) (255f * a));
        }
        if (!swordBehind) SwordArt.sword(c, f, a);
        if (rotated) c.restore();
    }

    /** Translucent silhouette of a previously solved pose (dash and double-jump afterimages). */
    static void ghost(Canvas c, float[] j, float s, float rot, int col, int alpha, boolean sword) {
        if (alpha <= 0) return;
        final Paint p = P;
        final boolean rotated = rot != 0f;
        if (rotated) {
            float rx = (j[0] + j[2]) * 0.5f, ry = (j[1] + j[3]) * 0.5f;
            c.save();
            c.translate(rx, ry);
            c.rotate((float) Math.toDegrees(rot));
            c.translate(-rx, -ry);
        }
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
        p.setStyle(Paint.Style.STROKE);
        p.setColor(col);
        p.setAlpha(alpha);
        p.setStrokeWidth(3.6f * s);
        limbs(c, j, p);
        p.setStyle(Paint.Style.FILL);
        c.drawCircle(j[4], j[5], 4.8f * s, p);
        p.setStyle(Paint.Style.STROKE);
        p.setAlpha((int) (alpha * 0.8f));
        p.setStrokeWidth(2.2f * s);
        if (sword) c.drawLine(j[20], j[21], j[22], j[23], p);
        if (rotated) c.restore();
    }

    static void wraith(Canvas c, float x, float y, float t, int dir, float charge, float flash, float alpha) {
        glow(c, GLOW_VIOLET, x, y, 36f + 14f * charge, (0.45f + 0.5f * charge) * alpha);
        float wv = (float) Math.sin(t * 6f) * 2f;
        Path pa = PA;
        pa.reset();
        pa.moveTo(x - 8f, y - 4f);
        pa.quadTo(x - 8f, y - 15f, x, y - 15f);
        pa.quadTo(x + 8f, y - 15f, x + 8f, y - 4f);
        pa.lineTo(x + 11f, y + 10f + wv);
        pa.lineTo(x + 6f, y + 6f - wv);
        pa.lineTo(x + 3f, y + 13f + wv);
        pa.lineTo(x - 2f, y + 7f - wv);
        pa.lineTo(x - 6f, y + 14f + wv);
        pa.lineTo(x - 11f, y + 9f - wv);
        pa.close();
        P.setStyle(Paint.Style.FILL);
        P.setColor(mix(0xFF140A26, 0xFFFFFFFF, flash));
        P.setAlpha((int) (255f * alpha));
        c.drawPath(pa, P);
        P.setStyle(Paint.Style.STROKE);
        P.setStrokeWidth(1.6f);
        P.setColor(mix(0xFFB070FF, 0xFFFFFFFF, flash));
        P.setAlpha((int) (210f * alpha));
        c.drawPath(pa, P);
        dot(c, x + dir * 2f - 2.4f, y - 7f, 1.5f, 0xFFF0E0FF, (int) (255f * alpha));
        dot(c, x + dir * 2f + 2.6f, y - 7f, 1.5f, 0xFFF0E0FF, (int) (255f * alpha));
        if (charge > 0f) {
            float ox = x + dir * 15f;
            glow(c, GLOW_VIOLET, ox, y, 12f + 20f * charge, 0.95f);
            dot(c, ox, y, 2f + 3.5f * charge, 0xFFFFFFFF, 255);
        }
    }

    static void shard(Canvas c, float x, float y, float t) {
        glow(c, GLOW_CYAN, x, y, 20f, 0.8f);
        float w = 2.5f + 2.5f * Math.abs((float) Math.cos(t * 3f));
        PA.reset();
        PA.moveTo(x, y - 6f);
        PA.lineTo(x + w, y);
        PA.lineTo(x, y + 6f);
        PA.lineTo(x - w, y);
        PA.close();
        P.setStyle(Paint.Style.FILL);
        P.setColor(0xFF9AF0FF);
        c.drawPath(PA, P);
        P.setStyle(Paint.Style.STROKE);
        P.setStrokeWidth(0.8f);
        P.setColor(0xFFFFFFFF);
        c.drawPath(PA, P);
    }

    // ------------------------------------------------------------------ parallax backdrop

    private static final int LW = 1024, LH = 360;
    private static final float[] FACT = {0.12f, 0.32f, 0.6f};
    private static final Bitmap[][] CACHE = new Bitmap[3][];
    private static final LinearGradient[] SKY = new LinearGradient[3];
    private static final LinearGradient[] MIST = new LinearGradient[3];
    private static final float[] STARS = new float[80];
    private static final Paint LP = new Paint(Paint.FILTER_BITMAP_FLAG);

    static {
        Random r = new Random(5);
        for (int i = 0; i < STARS.length; i++) STARS[i] = r.nextFloat();
    }

    /** Sky, moon, three parallax layers and ground mist. camX scrolls the layers. */
    static void backdrop(Canvas c, int theme, float camX, float vw, float vh, float time) {
        int[] pal = PAL[theme];
        if (SKY[theme] == null) {
            SKY[theme] = new LinearGradient(0f, 0f, 0f, vh, pal[0], pal[1], Shader.TileMode.CLAMP);
            int tint = pal[1] & 0x00FFFFFF;
            MIST[theme] = new LinearGradient(0f, vh * 0.5f, 0f, vh, tint, 0x80000000 | tint, Shader.TileMode.CLAMP);
        }
        Paint p = P;
        p.setStyle(Paint.Style.FILL);
        p.setShader(SKY[theme]);
        c.drawRect(0f, 0f, vw, vh, p);
        p.setShader(null);
        p.setColor(0xFFFFFFFF);
        for (int i = 0; i < 40; i++) {
            p.setAlpha((int) (70f + 70f * Math.sin(time * 1.3f + i)));
            c.drawCircle(STARS[i * 2] * vw, STARS[i * 2 + 1] * vh * 0.55f, 0.9f, p);
        }
        float mx = vw * 0.78f - camX * 0.02f;
        if (theme == 2) {
            glow(c, GLOW_RED, mx, 78f, 150f, 0.5f);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(3f);
            p.setColor(0xFFB02840);
            c.drawCircle(mx, 78f, 46f, p);
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF3A0A14);
            c.drawCircle(mx, 78f, 44f, p);
        } else {
            glow(c, GLOW_WHITE, mx, 70f, 120f, 0.30f);
            p.setStyle(Paint.Style.FILL);
            p.setColor(theme == 0 ? 0xFFE8DCF0 : 0xFFCFE8F0);
            c.drawCircle(mx, 70f, 26f, p);
            p.setColor(0xFF000000);
            p.setAlpha(28);
            c.drawCircle(mx - 8f, 64f, 6f, p);
            c.drawCircle(mx + 9f, 78f, 4f, p);
        }
        Bitmap[] ls = layers(theme);
        for (int i = 0; i < 3; i++) {
            float off = -((camX * FACT[i]) % LW);
            c.drawBitmap(ls[i], off, 0f, LP);
            c.drawBitmap(ls[i], off + LW, 0f, LP);
        }
        p.setStyle(Paint.Style.FILL);
        p.setShader(MIST[theme]);
        c.drawRect(0f, vh * 0.5f, vw, vh, p);
        p.setShader(null);
    }

    private static Bitmap[] layers(int theme) {
        if (CACHE[theme] != null) return CACHE[theme];
        for (int k = 0; k < 3; k++) if (k != theme) CACHE[k] = null;
        int[] pal = PAL[theme];
        Random r = new Random(7919L * (theme + 1));
        Bitmap[] out = new Bitmap[3];
        for (int i = 0; i < 3; i++) {
            Bitmap b = Bitmap.createBitmap(LW, LH, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(b);
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            if (i == 0) far(c, p, pal, r);
            else if (i == 1) mid(c, p, pal, r);
            else near(c, p, pal, r);
            out[i] = b;
        }
        CACHE[theme] = out;
        return out;
    }

    private static void far(Canvas c, Paint p, int[] pal, Random r) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(pal[2]);
        Path pa = new Path();
        pa.moveTo(0f, LH);
        for (int x = 0; x <= LW; x += 16) {
            double k = 2.0 * Math.PI * x / LW;
            pa.lineTo(x, (float) (250.0 - 28.0 * Math.sin(2 * k + 1) - 16.0 * Math.sin(5 * k + 2) - 9.0 * Math.sin(11 * k)));
        }
        pa.lineTo(LW, LH);
        pa.close();
        c.drawPath(pa, p);
        for (int i = 0; i < 7; i++) {
            float x = 50f + r.nextFloat() * (LW - 100f);
            float w = 14f + r.nextFloat() * 18f, h = 50f + r.nextFloat() * 90f, base = 262f;
            p.setColor(pal[2]);
            c.drawRect(x - w / 2f, base - h, x + w / 2f, LH, p);
            Path roof = new Path();
            roof.moveTo(x - w / 2f - 3f, base - h);
            roof.lineTo(x, base - h - 24f - r.nextFloat() * 20f);
            roof.lineTo(x + w / 2f + 3f, base - h);
            roof.close();
            c.drawPath(roof, p);
            p.setColor(pal[7]);
            p.setAlpha(140);
            c.drawRect(x - 1.5f, base - h + 12f, x + 1.5f, base - h + 20f, p);
        }
    }

    private static void mid(Canvas c, Paint p, int[] pal, Random r) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(pal[3]);
        Path pa = new Path();
        pa.moveTo(0f, LH);
        for (int x = 0; x <= LW; x += 24) {
            double k = 2.0 * Math.PI * x / LW;
            pa.lineTo(x, (float) (296.0 - 6.0 * Math.sin(3 * k) - 4.0 * Math.sin(8 * k + 1)));
        }
        pa.lineTo(LW, LH);
        pa.close();
        c.drawPath(pa, p);
        for (int i = 0; i < 9; i++) {
            float x = 30f + i * 104f + r.nextFloat() * 24f;
            float h = 70f + r.nextFloat() * 120f, w = 12f + r.nextFloat() * 10f;
            c.drawRect(x, 300f - h, x + w, LH, p);
            Path t = new Path();
            t.moveTo(x, 300f - h);
            t.lineTo(x + w * 0.3f, 300f - h - 9f);
            t.lineTo(x + w * 0.6f, 300f - h - 2f);
            t.lineTo(x + w, 300f - h - 10f);
            t.lineTo(x + w, 300f - h);
            t.close();
            c.drawPath(t, p);
        }
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        for (int i = 0; i < 4; i++) tree(c, p, 90f + r.nextFloat() * (LW - 180f), 300f, -PI / 2f, 34f + r.nextFloat() * 22f, 4, r);
        p.setStyle(Paint.Style.FILL);
    }

    private static void tree(Canvas c, Paint p, float x, float y, float ang, float len, int depth, Random r) {
        if (depth == 0) return;
        float nx = x + (float) Math.cos(ang) * len, ny = y + (float) Math.sin(ang) * len;
        p.setStrokeWidth(depth * 1.5f);
        c.drawLine(x, y, nx, ny, p);
        tree(c, p, nx, ny, ang - 0.45f - r.nextFloat() * 0.3f, len * 0.72f, depth - 1, r);
        tree(c, p, nx, ny, ang + 0.45f + r.nextFloat() * 0.3f, len * 0.72f, depth - 1, r);
    }

    private static void near(Canvas c, Paint p, int[] pal, Random r) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(pal[4]);
        for (int i = 0; i < 4; i++) {
            float x = 40f + i * 250f + r.nextFloat() * 40f, w = 34f + r.nextFloat() * 22f;
            c.drawRect(x, 0f, x + w, LH, p);
            c.drawRect(x - 6f, 0f, x + w + 6f, 16f, p);
            c.drawRect(x - 4f, 40f, x + w + 4f, 48f, p);
        }
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.4f);
        for (int i = 0; i < 5; i++) {
            float x = 20f + r.nextFloat() * (LW - 40f), len = 40f + r.nextFloat() * 90f;
            c.drawLine(x, 0f, x, len, p);
            for (float yy = 8f; yy < len; yy += 9f) c.drawCircle(x, yy, 2.2f, p);
        }
        p.setStyle(Paint.Style.FILL);
    }
}
