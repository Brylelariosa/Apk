package com.shadowborn.game;

/**
 * The hero's sword moves as data: ids, frame tables, hit properties, keyframed poses and the combo graph. Player runs whatever is in
 * here, so adding a move means adding one entry to every table (and a NEXT link) and nothing else.
 *
 * Ground combo:   (draw cut when the sword is on the back, else slash) -> backhand -> thrust -> rising slash -> spin slash
 * Aerial combo:   air slash -> air spin -> plunge
 * Dash slash:     low slash out of a dash, chains into the thrust
 */
final class Moves {
    private Moves() {}

    static final int NONE = 0, SLASH = 1, THRUST = 2, SPIN = 3, AIR_SLASH = 4, AIR_SPIN = 5, PLUNGE = 6, DASH = 7, DRAW = 8, BACKHAND = 9, RISING = 10;
    static final int COUNT = 11;

    // ------------------------------------------------------------------ frame tables (60 Hz frames; index = move id)
    /** Startup frames: the blade winds up, no damage. */
    static final int[] ST = {0, 3, 3, 8, 3, 3, 6, 3, 6, 2, 4};
    /** Active frames: the blade sweeps and the hit test runs (the plunge is active until it lands). */
    static final int[] AC = {0, 5, 5, 9, 5, 8, 30, 6, 7, 5, 6};
    /** Recovery frames: follow-through; the next move, a jump or a dash may cancel it. */
    static final int[] RC = {0, 9, 10, 16, 8, 9, 9, 10, 12, 8, 12};

    // ------------------------------------------------------------------ hit properties
    static final int[] DMG = {0, 10, 12, 22, 10, 12, 22, 12, 12, 11, 14};
    static final float[] KB = {0f, 190f, 190f, 300f, 170f, 170f, 300f, 230f, 230f, 190f, 290f};
    /** Forward speed added when the active frames begin (the hero steps into the blow). */
    static final float[] LUNGE = {0f, 140f, 190f, 200f, 70f, 40f, 0f, 330f, 220f, 130f, 150f};
    /** How far the visible slash arc (and the hit region) extends beyond the blade tip. The blade is short and light, so this is modest. */
    static final float[] EXT = {0f, 8f, 10f, 11f, 8f, 10f, 10f, 10f, 10f, 8f, 10f};
    static final float[] STOP = {0f, 0.045f, 0.055f, 0.10f, 0.045f, 0.055f, 0.10f, 0.06f, 0.06f, 0.045f, 0.07f};
    static final float[] SHK = {0f, 2.5f, 3f, 5.5f, 2.5f, 3f, 6f, 3.5f, 3.5f, 2.5f, 4f};

    // ------------------------------------------------------------------ move properties
    /** Slashes that start behind the hero's back only count while the blade is in front of the hero (a thrust is forward anyway). */
    static final boolean[] FRONT_ONLY = flags(SLASH, THRUST, AIR_SLASH, DASH, DRAW, BACKHAND, RISING);
    /** Flat sweeps (blade foreshortened, tip moving sideways) draw their arc as a band hanging off the tip's path. */
    static final boolean[] RIBBON = flags(SLASH, SPIN, AIR_SLASH, AIR_SPIN, DASH, BACKHAND);
    static final float[] RIBBON_W = {0f, 5.5f, 0f, 6.5f, 5.5f, 6.5f, 0f, 5.5f, 0f, 5.5f, 0f};
    /** Heavy blows: brighter trail, bigger impact. */
    static final boolean[] BIG = flags(SPIN, PLUNGE);
    /** A long wind-up that keeps coiling while it holds (the finisher, the plunge). */
    static final boolean[] COIL = flags(SPIN, PLUNGE);
    /** Moves that fold the sword elbow as the hand passes the body, so the arm runs straight instead of scooping. */
    static final boolean[] FOLD = flags(THRUST);
    /** Aerial slashes: a hit holds the hero up briefly, and landing ends them. */
    static final boolean[] AERIAL = flags(AIR_SLASH, AIR_SPIN);
    /** Moves that swing in a vertical plane on purpose (the plunge is a downward stab; the draw cut comes over the head; the rising slash
     *  scoops upward). Everything else is a flat sweep, which the tests check. */
    static final boolean[] VERTICAL = flags(PLUNGE, DRAW, RISING);
    /** Moves that start with the hand on the scabbard: the arm reaches back, then draws the blade as part of the start-up. */
    static final boolean[] FROM_SCABBARD = flags(DRAW);

    /** Next move in a chain (0 = none); allowed once the current move's active frames are over. */
    static final int[] NEXT = new int[COUNT];
    static {
        NEXT[SLASH] = BACKHAND;
        NEXT[DRAW] = BACKHAND;
        NEXT[BACKHAND] = THRUST;
        NEXT[THRUST] = RISING;
        NEXT[RISING] = SPIN;
        NEXT[DASH] = THRUST;
        NEXT[AIR_SLASH] = AIR_SPIN;
        NEXT[AIR_SPIN] = PLUNGE;
    }

    private static boolean[] flags(int... ids) {
        final boolean[] o = new boolean[COUNT];
        for (int id : ids) o[id] = true;
        return o;
    }

    // ------------------------------------------------------------------ pose keyframes
    /** Pose vector: lean, legF, kneeF, legB, kneeB, armB, sword, wrist, reach, plant, hipH, footF, footB, az.
     *  plant 0 = the legs follow the four angle values (running, air); plant 1 = both feet are planted on the ground
     *  at the given stance (hip height above the floor, front foot forward, back foot behind) and the leg angles come
     *  from two-bone IK, so no foot ever hovers during a grounded move.
     *  sword is the sword arm's angle from straight down (forward positive) and wrist the blade's angle relative to the arm.
     *  az turns the whole sword arm about the vertical axis through the shoulder (0 = in the screen plane, PI = pointing
     *  backwards, PI/2 = end-on to the camera): sweeping it from PI to 0 is a flat horizontal slash. Angles are not wrapped: a keyframe
     *  may go the long way round (the draw cut takes the sword over the head), so a move's start and end are normalised in Player. */
    static final int NP = 14;
    static final int P_LEAN = 0, P_ARMB = 5, P_SWORD = 6, P_WRIST = 7, P_REACH = 8, P_PLANT = 9, P_HIP = 10, P_FF = 11, P_FB = 12, P_AZ = 13;
    static final float PI = (float) Math.PI;

    /** Builds a pose vector; a 13-value keyframe (no az) keeps az = 0. */
    private static float[] k(float... v) {
        if (v.length >= NP) return v;
        final float[] o = new float[NP];
        System.arraycopy(v, 0, o, 0, v.length);
        return o;
    }

    /** KEY[move] = {wind-up (end of startup), strike (end of active), follow-through}. */
    static final float[][][] KEY = {
        {},
        // 1: horizontal slash: the sword is drawn back behind the shoulder, then sweeps flat across the front at chest height
        {k(-0.12f, 0.55f, 0.70f, -0.60f, 0.50f, 1.10f, 1.45f, 0.15f, 0.95f, 1f, 12.0f, 5.0f, -7.0f, 2.95f),
         k(0.45f, 0.95f, 0.55f, -0.95f, 0.25f, -0.70f, 1.40f, 0.10f, 1.30f, 1f, 10.6f, 9.6f, -9.0f, -0.25f),
         k(0.38f, 0.80f, 0.60f, -0.80f, 0.35f, -0.25f, 1.20f, 0.12f, 1.15f, 1f, 10.8f, 8.8f, -8.2f, -0.10f)},
        // 2: lunging thrust: the hand is pulled back to the hip with the blade levelled at the target, then the arm shoots straight out
        {k(-0.05f, 0.70f, 0.60f, -0.80f, 0.40f, 1.80f, -0.65f, 2.15f, 1.00f, 1f, 10.6f, 8.0f, -10.0f, 0f),
         k(0.60f, 1.00f, 0.55f, -1.05f, 0.30f, -1.60f, 1.38f, 0.14f, 1.35f, 1f, 9.0f, 11.0f, -10.2f, 0f),
         k(0.50f, 0.90f, 0.60f, -0.95f, 0.35f, -1.30f, 1.30f, 0.16f, 1.20f, 1f, 9.6f, 10.0f, -9.4f, 0f)},
        // 3: spin slash (finisher): crouch and coil, then one full turn with the blade held out flat; hits front and back
        {k(-0.15f, 0.60f, 0.90f, -0.60f, 0.80f, 1.60f, 1.45f, 0.10f, 0.95f, 1f, 9.0f, 6.5f, -6.5f, PI),
         k(0.35f, 0.80f, 0.70f, -0.80f, 0.60f, 1.00f, 1.45f, 0.10f, 1.20f, 1f, 9.8f, 8.0f, -7.5f, -PI),
         k(0.30f, 0.70f, 0.70f, -0.70f, 0.60f, 0.50f, 0.60f, 0.10f, 1.00f, 1f, 10.5f, 7.0f, -7.0f, -PI)},
        // 4: aerial horizontal slash
        {k(0.00f, 0.60f, 1.30f, -0.20f, 1.10f, 1.10f, 1.45f, 0.15f, 0.95f, 0f, 11f, 3f, -3f, 2.95f),
         k(0.35f, 0.70f, 1.00f, -0.40f, 0.90f, -0.60f, 1.40f, 0.10f, 1.30f, 0f, 11f, 3f, -3f, -0.25f),
         k(0.30f, 0.60f, 0.90f, -0.35f, 0.80f, -0.20f, 1.20f, 0.12f, 1.15f, 0f, 11f, 3f, -3f, -0.10f)},
        // 5: aerial spin slash
        {k(0.05f, 0.50f, 0.90f, -0.50f, 0.80f, 1.40f, 1.45f, 0.10f, 0.95f, 0f, 11f, 3f, -3f, PI),
         k(0.20f, 0.60f, 1.10f, -0.30f, 1.00f, 0.80f, 1.45f, 0.10f, 1.15f, 0f, 11f, 3f, -3f, -PI),
         k(0.10f, 0.55f, 1.10f, -0.30f, 1.00f, 0.40f, 0.60f, 0.10f, 1.00f, 0f, 11f, 3f, -3f, -PI)},
        // 6: plunge (wind-up in the air, dive, planted landing crouch)
        {k(0.00f, 0.50f, 1.40f, -0.30f, 1.30f, 2.20f, 3.00f, -0.30f, 0.90f, 0f, 11f, 3f, -3f),
         k(0.90f, 0.10f, 0.10f, -0.35f, 0.20f, -1.00f, 0.45f, 0.25f, 1.30f, 0f, 11f, 3f, -3f),
         k(0.50f, 0.90f, 1.60f, -0.70f, 1.40f, 0.60f, 0.10f, 0.10f, 1.00f, 1f, 8.6f, 6.0f, -5.5f)},
        // 7: dash slash (low, planted slide): the dash pose already is the wind-up (blade trailing behind), the blade sweeps flat across at knee height
        {k(0.95f, 1.15f, 0.35f, -1.35f, 0.25f, -1.30f, 1.20f, 0.35f, 1.00f, 1f, 8.4f, 9.0f, -11.2f, PI),
         k(0.72f, 1.00f, 0.50f, -1.10f, 0.40f, -0.60f, 1.32f, 0.10f, 1.50f, 1f, 9.0f, 9.5f, -11.0f, -0.20f),
         k(0.55f, 0.85f, 0.50f, -0.90f, 0.40f, -0.30f, 1.25f, 0.12f, 1.20f, 1f, 10.0f, 8.0f, -9.0f, -0.10f)},
        // 8: draw cut (the opener when the sword is on the back): the hand reaches over the shoulder and takes the hilt (start-up), the blade
        //    comes out and the arm whips over the head in one big diagonal chop that ends forward and low
        {k(-0.12f, 0.50f, 0.70f, -0.50f, 0.60f, 1.25f, -2.80f, 2.40f, 1.22f, 1f, 11.4f, 5.5f, -7.0f, 0f),
         k(0.50f, 0.90f, 0.60f, -1.00f, 0.30f, -0.85f, -5.05f, -0.35f, 1.35f, 1f, 10.2f, 10.0f, -9.5f, 0f),
         k(0.38f, 0.80f, 0.60f, -0.80f, 0.35f, -0.30f, -5.40f, -0.20f, 1.15f, 1f, 10.8f, 8.6f, -8.2f, 0f)},
        // 9: backhand: the blade comes back across the front by the far side, at chest height; quick flick, the body turns with it
        {k(0.40f, 0.95f, 0.55f, -0.95f, 0.25f, -0.40f, 1.40f, 0.10f, 1.25f, 1f, 10.6f, 9.4f, -8.8f, -0.25f),
         k(0.12f, 0.70f, 0.60f, -0.70f, 0.40f, 1.35f, 1.40f, 0.10f, 1.25f, 1f, 10.8f, 7.5f, -9.5f, -2.95f),
         k(0.05f, 0.60f, 0.60f, -0.60f, 0.40f, 0.90f, 1.25f, 0.12f, 1.10f, 1f, 11.2f, 7.0f, -7.5f, -3.10f)},
        // 10: rising slash: crouch with the blade trailing low behind, then stand into a scooping upward cut that ends with the blade high in front
        {k(0.55f, 0.95f, 0.70f, -1.10f, 0.40f, 1.00f, -1.05f, -0.40f, 1.15f, 1f, 8.8f, 8.0f, -9.5f, 0f),
         k(-0.18f, 0.80f, 0.50f, -0.60f, 0.30f, -1.30f, 2.55f, -0.25f, 1.35f, 1f, 12.8f, 8.0f, -7.5f, 0f),
         k(-0.10f, 0.70f, 0.55f, -0.55f, 0.35f, -0.80f, 2.75f, -0.20f, 1.20f, 1f, 12.4f, 7.5f, -7.0f, 0f)},
    };
}
