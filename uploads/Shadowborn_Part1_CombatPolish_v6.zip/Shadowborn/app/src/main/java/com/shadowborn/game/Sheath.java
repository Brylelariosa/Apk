package com.shadowborn.game;

/**
 * Where the hero keeps the sword: on the back, or in the hand for a while after a fight.
 *
 * It owns one number, stow (0 = in the hand, 1 = sheathed on the back; SwordArt turns it into pictures) and the clock that moves it:
 * a blow draws the sword, and it is put away again after KEEP_T seconds of calm. Player decides what the body does meanwhile.
 */
final class Sheath {
    /** Seconds the sword stays out after the last blow; the clock only runs while the hero stands calmly on the ground. */
    static final float KEEP_T = 2.2f;
    /** Draw times: the ground draw cut takes as long as its start-up, a draw in the middle of another move is quicker; putting it away is slower and visible. */
    static final float DRAW_T = 0.10f, QUICK_T = 0.05f, STOW_T = 0.40f;
    /** Events for the effects: the blade has just cleared the scabbard / has just slid home. */
    static final int EV_DRAWN = 1, EV_SHEATHED = 2;

    /** 0 = in the hand, 1 = on the back. */
    float stow = 1f;
    /** Seconds the sword stays out after the last blow (a field, not just the constant, so that tests can hold it out). */
    float keepFor = KEEP_T;
    private boolean wantOut;
    private float keep, drawRate = 1f / DRAW_T;
    private int event;

    /** True from the moment the sword is called for until it starts going back (the sword is, or is being, drawn). */
    boolean out() {
        return wantOut;
    }

    /** Combat starts or goes on: the sword comes out (quickly for moves that cannot wait) and stays out for KEEP_T. */
    void draw(boolean quick) {
        if (!wantOut) {
            wantOut = true;
            drawRate = 1f / (quick ? QUICK_T : DRAW_T);
        }
        keep = keepFor;
    }

    /** Puts the sword in the hand or on the back at once, without any animation (tests, respawns). */
    void reset(boolean drawn) {
        wantOut = drawn;
        stow = drawn ? 0f : 1f;
        keep = drawn ? keepFor : 0f;
        event = 0;
    }

    /**
     * Advances the clock one step. busy: the hero is attacking (the sword stays out and the countdown restarts); calm: the hero is
     * standing about, so the countdown runs and the sword may go back on the back.
     */
    void update(float dt, boolean busy, boolean calm) {
        if (wantOut) {
            if (busy) keep = keepFor;
            else if (calm && (keep -= dt) <= 0f) wantOut = false;
        }
        final float before = SwordArt.bladeOut(stow);
        final float r = (wantOut ? drawRate : 1f / STOW_T) * dt, d = (wantOut ? 0f : 1f) - stow;
        stow += d > r ? r : d < -r ? -r : d;
        final float after = SwordArt.bladeOut(stow);
        if (before < 0.9f && after >= 0.9f) event = EV_DRAWN;
        else if (before > 0.02f && after <= 0.02f) event = EV_SHEATHED;
    }

    /** Returns the latest effect event (0 = none) and clears it. */
    int takeEvent() {
        final int e = event;
        event = 0;
        return e;
    }

    /**
     * 0..1: how strongly the sword arm is pulled to the scabbard while the sword is put away: it reaches over the shoulder (stow 0..0.25),
     * holds the hilt as the blade slides in, and lets go (stow 0.65..1). Zero while the sword is out.
     */
    float reach() {
        if (wantOut) return 0f;
        return ease(stow / 0.25f) * (1f - ease((stow - 0.65f) / 0.35f));
    }

    private static float ease(float u) {
        u = u < 0f ? 0f : u > 1f ? 1f : u;
        return u * u * (3f - 2f * u);
    }
}
