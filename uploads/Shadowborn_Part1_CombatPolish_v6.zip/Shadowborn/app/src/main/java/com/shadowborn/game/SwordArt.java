package com.shadowborn.game;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;

/**
 * The sword and its scabbard.
 *
 * A figure's sword is in one of three places: in the hand (it follows the sword arm exactly as the solver placed it, so what you see is
 * what the hit test uses), sheathed on the back (the hilt shows above the shoulder, the blade is hidden in the scabbard), or somewhere
 * in between while it is being drawn or put away. Fig.stow (0 = in the hand, 1 = on the back) says which; the blend lives here so that
 * Player only has to animate one number.
 *
 * Drawing out of the scabbard is a two-part illusion that needs no clipping: the hilt travels from the scabbard mouth to the hand
 * (g), and the visible part of the blade grows out of the guard (out), which is how a blade looks when it slides out of a sheath.
 */
final class SwordArt {
    private SwordArt() {}

    /** Where the hilt sits on the back: units from the shoulder up the torso and towards the back, and how far the sheath tilts away from the spine. */
    static final float MOUNT_UP = 8.8f, MOUNT_BACK = 5.6f, MOUNT_TILT = 0.42f;
    /** Distance from the hand to the guard and from the hand to the pommel along the blade (units). */
    private static final float GUARD = 1.5f, POMMEL = 3f;
    /** The sword arm's elbow droop (see Art.solve): the hand sits at 2 * reach * cos(DROOP / 2) along a direction DROOP / 2 behind the arm angle. */
    private static final float DROOP_HALF = 0.125f;

    /** Displayed sword: hand x,y, tip x,y, pommel x,y, fraction of the blade that is out of the scabbard. */
    private static final float[] D = new float[7];

    private static float eio(float u) {
        u = u < 0f ? 0f : u > 1f ? 1f : u;
        return u * u * (3f - 2f * u);
    }

    /** 0..1: how much of the sword has left the back and is following the hand (1 = in the hand). */
    static float inHand(float stow) {
        return 1f - eio((stow - 0.25f) / 0.40f);
    }

    /** 0..1: how much of the blade is out of the scabbard. */
    static float bladeOut(float stow) {
        return 1f - eio((stow - 0.25f) / 0.55f);
    }

    // ------------------------------------------------------------------ geometry

    /** Computes where the sheathed sword sits for the figure's current torso: m = hilt hand point, tip, pommel, blade direction. */
    static void mount(Art.Fig f) {
        final float[] j = f.j, m = f.m;
        final float s = f.s, d = f.dir;
        float tx = j[2] - j[0], ty = j[3] - j[1];
        final float tl = (float) Math.sqrt(tx * tx + ty * ty) + 1e-6f;
        tx /= tl;
        ty /= tl;                                // up the torso
        final float bx = d * ty, by = -d * tx;   // towards the back (perpendicular to the torso, away from the way the hero faces)
        final float sx = j[2], sy = j[3] + 1.5f * s;      // shoulder: the base of the sword arm
        final float hx = sx + (tx * MOUNT_UP + bx * MOUNT_BACK) * s, hy = sy + (ty * MOUNT_UP + by * MOUNT_BACK) * s;
        final float ct = (float) Math.cos(MOUNT_TILT), st = (float) Math.sin(MOUNT_TILT);
        final float ux = -tx * ct + bx * st, uy = -ty * ct + by * st;      // down the back, tilted away from the spine
        final float len = (f.fullLen > 0f ? f.fullLen : f.bladeLen) * s;
        m[0] = hx;
        m[1] = hy;
        m[2] = hx + ux * len;
        m[3] = hy + uy * len;
        m[4] = hx - ux * POMMEL * s;
        m[5] = hy - uy * POMMEL * s;
        m[6] = ux;
        m[7] = uy;
    }

    /**
     * The sword-arm pose (angle, wrist, reach) that puts the hand on the sheathed hilt with the blade lying along the scabbard.
     * Valid for az = 0 (the arm in the screen plane). out = {swordAng, wrist, reach}.
     */
    static void gripPose(Art.Fig f, float[] out) {
        final float s = f.s, d = f.dir;
        final float rx = (f.m[0] - f.j[2]) * d, ry = f.m[1] - (f.j[3] + 1.5f * s);
        final float dist = (float) Math.sqrt(rx * rx + ry * ry);
        final float sa = (float) Math.atan2(rx, ry) + DROOP_HALF;
        final float ba = (float) Math.atan2(f.m[6] * d, f.m[7]);
        out[0] = sa;
        out[1] = ba - sa;
        out[2] = dist / (2f * (float) Math.cos(DROOP_HALF) * 5.5f * s);
    }

    /** World position of the scabbard mouth (where the blade slides in and out). */
    static float mouthX(Art.Fig f) {
        return f.m[0] + f.m[6] * (GUARD + 0.7f) * f.s;
    }

    static float mouthY(Art.Fig f) {
        return f.m[1] + f.m[7] * (GUARD + 0.7f) * f.s;
    }

    /** Fills D with where the sword is drawn right now. */
    private static void display(Art.Fig f) {
        final float[] j = f.j, m = f.m;
        if (f.stow <= 0f) {
            D[0] = j[20]; D[1] = j[21]; D[2] = j[22]; D[3] = j[23]; D[4] = j[24]; D[5] = j[25];
            D[6] = 1f;
            return;
        }
        final float g = inHand(f.stow);
        for (int i = 0; i < 3; i++) {
            D[i * 2] = m[i * 2] + (j[20 + i * 2] - m[i * 2]) * g;
            D[i * 2 + 1] = m[i * 2 + 1] + (j[21 + i * 2] - m[i * 2 + 1]) * g;
        }
        D[6] = bladeOut(f.stow);
    }

    // ------------------------------------------------------------------ drawing

    /**
     * Sword: tapered steel blade (lit upper edge, darker lower face, fuller), cross-guard, leather grip and pommel, plus only a faint rim
     * light. With the blade (partly) in the scabbard only the hilt and the part that has come out are drawn.
     */
    static void sword(Canvas c, Art.Fig f, float a) {
        display(f);
        final Paint p = Art.P;
        final float s = f.s, bw = f.bladeW, thick = 0.5f + 0.5f * bw, fine = 0.55f + 0.45f * bw;
        final float hx = D[0], hy = D[1];
        float ux = D[2] - hx, uy = D[3] - hy;
        float len = (float) Math.sqrt(ux * ux + uy * uy);
        if (len < 0.5f) {      // blade end-on to the camera (middle of a horizontal sweep): keep a stub pointing where the hero faces
            ux = f.dir;
            uy = 0f;
            len = 0.5f;
        } else {
            ux /= len;
            uy /= len;
        }
        float nx = -uy, ny = ux;
        if (ny > 0f) {      // light comes from above: the normal always points up the screen, so the upper edge is the lit one
            nx = -nx;
            ny = -ny;
        }
        final float gx = hx + ux * GUARD * s, gy = hy + uy * GUARD * s;      // cross-guard centre
        final float bx = gx + ux * 0.7f * s, by = gy + uy * 0.7f * s;      // blade base
        final float lb = Math.max(0f, len - 2.2f * s) * D[6];
        final float tx = bx + ux * lb, ty = by + uy * lb;
        final float kx = bx + ux * lb * 0.86f, ky = by + uy * lb * 0.86f;      // where the taper turns into the point
        final float w0 = 1.65f * s * bw, w1 = 1.1f * s * bw;
        final float mx = hx - ux * POMMEL * s, my = hy - uy * POMMEL * s;      // pommel
        final int steel = Art.mix(f.blade, 0xFFFFFFFF, f.flash);
        final int lit = Art.mix(steel, 0xFFFFFFFF, 0.28f), shade = Art.mix(steel, 0xFF000000, 0.38f);
        final int edge = f.hi != 0 ? f.hi : Art.mix(steel, 0xFFFFFFFF, 0.8f);
        final boolean blade = lb > 0.6f * s;

        if (blade && f.aura > 0f) {      // faint rim light, not a beam
            p.setStyle(Paint.Style.STROKE);
            p.setColor(f.bladeGlow);
            p.setAlpha((int) (34f * f.aura * a));
            p.setStrokeWidth(5.2f * s * thick);
            c.drawLine(bx, by, tx, ty, p);
            p.setAlpha((int) (95f * f.aura * a));
            p.setStrokeWidth(2.6f * s * thick);
            c.drawLine(bx, by, tx, ty, p);
        }
        // leather grip and pommel
        p.setStyle(Paint.Style.STROKE);
        p.setColor(f.grip);
        p.setAlpha((int) (255f * a));
        p.setStrokeWidth(1.9f * s * thick);
        c.drawLine(mx + ux * 1f * s, my + uy * 1f * s, gx, gy, p);
        p.setStyle(Paint.Style.FILL);
        p.setColor(Art.mix(f.guard, 0xFF000000, 0.55f));
        c.drawCircle(mx, my, 1.7f * s * thick, p);
        p.setColor(f.guard);
        c.drawCircle(mx, my, 1.25f * s * thick, p);
        if (blade) {
            // blade: lit upper half and shaded lower half meet on the centre ridge
            final Path pa = Art.PA;
            p.setStyle(Paint.Style.FILL);
            pa.reset();
            pa.moveTo(bx, by);
            pa.lineTo(bx + nx * w0, by + ny * w0);
            pa.lineTo(kx + nx * w1, ky + ny * w1);
            pa.lineTo(tx, ty);
            pa.close();
            p.setColor(lit);
            p.setAlpha((int) (255f * a));
            c.drawPath(pa, p);
            pa.reset();
            pa.moveTo(bx, by);
            pa.lineTo(bx - nx * w0, by - ny * w0);
            pa.lineTo(kx - nx * w1, ky - ny * w1);
            pa.lineTo(tx, ty);
            pa.close();
            p.setColor(shade);
            p.setAlpha((int) (255f * a));
            c.drawPath(pa, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(0.55f * s * fine);
            p.setColor(edge);      // bright cutting edge on the lit side
            p.setAlpha((int) (235f * a));
            c.drawLine(bx + nx * w0, by + ny * w0, kx + nx * w1, ky + ny * w1, p);
            c.drawLine(kx + nx * w1, ky + ny * w1, tx, ty, p);
            p.setColor(Art.mix(steel, 0xFF000000, 0.62f));      // dark edge on the shaded side
            p.setAlpha((int) (210f * a));
            p.setStrokeWidth(0.45f * s * fine);
            c.drawLine(bx - nx * w0, by - ny * w0, kx - nx * w1, ky - ny * w1, p);
            c.drawLine(kx - nx * w1, ky - ny * w1, tx, ty, p);
            if (lb > 6f * s) {      // fuller (groove down the middle)
                p.setColor(Art.mix(steel, 0xFF000000, 0.5f));
                p.setAlpha((int) (150f * a));
                p.setStrokeWidth(0.5f * s * fine);
                c.drawLine(bx + ux * lb * 0.14f, by + uy * lb * 0.14f, bx + ux * lb * 0.7f, by + uy * lb * 0.7f, p);
            }
        }
        // cross-guard
        final float gl = 3.5f * s * (0.45f + 0.55f * bw);
        p.setStyle(Paint.Style.STROKE);
        p.setColor(Art.mix(f.guard, 0xFF000000, 0.6f));
        p.setAlpha((int) (255f * a));
        p.setStrokeWidth(2.7f * s * thick);
        c.drawLine(gx + nx * (gl + 0.2f * s), gy + ny * (gl + 0.2f * s), gx - nx * (gl + 0.2f * s), gy - ny * (gl + 0.2f * s), p);
        p.setColor(f.guard);
        p.setStrokeWidth(1.7f * s * thick);
        c.drawLine(gx + nx * gl, gy + ny * gl, gx - nx * gl, gy - ny * gl, p);
    }

    /**
     * The scabbard on the hero's back: a slim sheath running from the mouth (at the guard of the stowed sword) down the back to a metal tip,
     * lit with a faint rim like the limbs so it reads against a dark backdrop. It is there whether or not the sword is in it.
     */
    static void scabbard(Canvas c, Art.Fig f, float a) {
        final float[] m = f.m;
        final Paint p = Art.P;
        final float s = f.s, bw = f.bladeW, ux = m[6], uy = m[7];
        final float len = (f.fullLen > 0f ? f.fullLen : f.bladeLen) * s;
        final float x0 = m[0] + ux * (GUARD + 0.5f) * s, y0 = m[1] + uy * (GUARD + 0.5f) * s;      // mouth
        final float x1 = m[0] + ux * (len + 1.2f * s), y1 = m[1] + uy * (len + 1.2f * s);      // chape (metal tip)
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setColor(f.glow);
        p.setAlpha((int) (36f * a));
        p.setStrokeWidth(5.6f * s);
        c.drawLine(x0, y0, x1, y1, p);
        p.setAlpha((int) (96f * a));
        p.setStrokeWidth(3.4f * s);
        c.drawLine(x0, y0, x1, y1, p);
        p.setColor(f.sheath);
        p.setAlpha((int) (255f * a));
        p.setStrokeWidth(2.3f * s);
        c.drawLine(x0, y0, x1, y1, p);
        // strap: a thin cord from the sheath up over the shoulder keeps the sword on the back
        p.setColor(Art.mix(f.sheath, 0xFFFFFFFF, 0.18f));
        p.setAlpha((int) (200f * a));
        p.setStrokeWidth(0.8f * s);
        final float t = 0.38f;
        c.drawLine(x0 + (x1 - x0) * t, y0 + (y1 - y0) * t, f.j[2], f.j[3] + 1.5f * s, p);
        // brass fittings: the throat at the mouth and the chape at the tip
        p.setColor(f.guard);
        p.setAlpha((int) (235f * a));
        p.setStrokeWidth(2.7f * s * (0.5f + 0.5f * bw));
        c.drawLine(x0, y0, x0 + ux * 1.3f * s, y0 + uy * 1.3f * s, p);
        p.setStrokeWidth(2.5f * s * (0.5f + 0.5f * bw));
        c.drawLine(x1 - ux * 1.2f * s, y1 - uy * 1.2f * s, x1, y1, p);
    }
}
