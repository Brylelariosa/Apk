package com.shadowborn.game;

import android.graphics.Canvas;
import android.graphics.Paint;

/**
 * The black stickman hero.
 *
 * Movement: run, variable-height jump (asymmetric gravity, apex hang, coyote time, jump buffer, ceiling-corner and
 * ledge assists), double jump with a somersault, ground dash and (after Wraith Stride) air dash.
 * Combat: a 5-hit ground combo, a 3-hit aerial combo that ends in a plunge, and a dash slash (see Moves for the data and the combo
 * graph). Every move has startup / active / recovery frames; hits are tested against the swept blade, so damage lands when the sword
 * visibly passes through the enemy. The sword lives on the back (see Sheath): the first blow draws it, a few calm seconds put it away.
 * Animation: every state writes a target pose, and a blend system moves the displayed pose towards it, so no state
 * change pops.
 */
final class Player extends Body {
    // ------------------------------------------------------------------ locomotion tuning (units/s, fixed 60 Hz step)
    static final float RUN = 190f;
    private static final float JUMP_V = 520f, DJ_V = 520f;
    private static final float G_RISE = 1500f, G_FALL = 2150f, G_APEX = 1000f, G_CUT = 5000f, APEX_V = 80f, V_MAX = 900f;
    /** After a double jump the descent is floatier (Wraith Stride): keeps the DJ-gated gaps comfortably crossable. */
    private static final float G_FALL_DJ = 1300f;
    private static final float ACC_GROUND = 2600f, ACC_AIR = 1900f, ACC_TURN = 2400f, DRAG_AIR = 700f;
    private static final float COYOTE = 0.10f, JUMP_BUF = 0.14f, ATK_BUF = 0.22f, DASH_BUF = 0.18f, MIN_JUMP_T = 0.04f;
    private static final float STEP_UP = 7f, NUDGE = 6f;
    private static final float FLIP_T = 0.36f;

    // ------------------------------------------------------------------ dash tuning
    static final float DASH_V = 510f, DASH_EXIT = 170f, DASH_HOLD = 0.55f, DASH_CD = 0.55f, DASH_IFR = 0.30f;
    static final float DASH_T_GROUND = 0.24f, DASH_T_AIR = 0.20f;
    private static final float DASH_JUMP_VX = RUN, GHOST_LIFE = 0.26f;

    // ------------------------------------------------------------------ combat tables
    // The move data (frame tables, hit properties, flags, keyframes, combo graph) lives in Moves; these are the names the tests and Game use.
    static final int M_PLUNGE = Moves.PLUNGE, M_DASH = Moves.DASH, M_DRAW = Moves.DRAW;
    static final float FRAME = 1f / 60f;
    static final int[] ST = Moves.ST, AC = Moves.AC, RC = Moves.RC, DMG = Moves.DMG;
    static final float[] KB = Moves.KB, EXT = Moves.EXT, STOP = Moves.STOP;
    private static final float[] LUNGE = Moves.LUNGE, SHK = Moves.SHK;
    /** Slashes that start behind the hero's back only count while the blade is in front of the hero (a thrust is forward anyway). */
    static boolean frontOnly(int m) {
        return Moves.FRONT_ONLY[m];
    }
    /** How far behind the hero's centre line (units) a blade point may be and still count for a front-only move. */
    static final float FRONT_SLACK = 3f;
    static final float BLADE_R = 6f;
    private static final float PLUNGE_V = 640f, HIT_HOVER = 0.14f, HOVER_G = 0.3f;

    // ------------------------------------------------------------------ pose vector (see Moves for the meaning of each value)
    private static final int NP = Moves.NP;
    private static final int P_SWORD = Moves.P_SWORD, P_WRIST = Moves.P_WRIST, P_REACH = Moves.P_REACH;
    private static final int P_PLANT = Moves.P_PLANT, P_HIP = Moves.P_HIP, P_FF = Moves.P_FF, P_FB = Moves.P_FB, P_AZ = Moves.P_AZ;
    private static final float PI = Moves.PI;
    private static final float[][][] KEY = Moves.KEY;

    // ------------------------------------------------------------------ public state (read by Game, enemies and tests)
    int hp = 100, maxHp = 100, facing = 1, atk, swing;
    boolean dead, hasDJ, edge;
    float invuln, hurtT, dodgeT, dodgeCd, atkT, atkDur, lastSafeX, lastSafeY;
    final Art.Fig fig = new Art.Fig();
    /** Where the sword is: on the back until a blow draws it, put away again after a few calm seconds. */
    final Sheath sheath = new Sheath();

    // ------------------------------------------------------------------ private state
    private float moveDir, groundW = 1f, t, phase, coyote, jumpBuf, atkBuf, dashBuf, landT, landPow, takeoffT, flipT, flickerT, jumpT, postDash, skidT;
    private float runDustT, hitHover, dashLen, dashDir, dashVy, ghostAcc, poseRate;
    private int airJumps, gi;
    private boolean usedDJ, jumping, cutting, airDashUsed, dashAir, active, plunging, trailStart, hasBlade, dashSlashed;
    private float pHx, pHy, pTx, pTy, ppTx, ppTy;
    private final float[] cur = new float[NP], tgt = new float[NP], from = new float[NP], prevCur = new float[NP], ik = new float[2];
    private boolean landBlend;
    private static final int GN = 7;
    private final float[][] gj = new float[GN][26];
    private final float[] ga = new float[GN], gl = new float[GN], gr = new float[GN], gaa = new float[GN];
    private final int[] gc = new int[GN];
    private final boolean[] gs = new boolean[GN];      // afterimage shows the sword (it was in the hand)
    private final float[] grip = new float[3];      // scratch: arm pose that puts the hand on the scabbard

    Player() {
        w = 14f;
        h = 34f;
        resetPose();
    }

    private void resetPose() {
        set(cur, 0.06f, 0.14f, 0.12f, -0.14f, 0.10f, 0.25f, 1.0f, 0.12f, 1f);
        ground(cur, 13.75f, 1.2f, -1.2f);
        groundW = 1f;
        haveTip = false;
        System.arraycopy(cur, 0, tgt, 0, NP);
        System.arraycopy(cur, 0, prevCur, 0, NP);
    }

    /** Puts the hero at a position without touching health. */
    void place(float px, float py) {
        x = px;
        y = py;
        vx = 0f;
        vy = 0f;
        lastSafeX = px;
        lastSafeY = py;
        snap();
        atk = 0;
        dodgeT = 0f;
        hurtT = 0f;
        onGround = false;
        clearActions();
        for (int i = 0; i < GN; i++) ga[i] = 0f;
        resetPose();
    }

    /** Drops every transient action (used when teleporting, taking a hit or respawning). */
    private void clearActions() {
        usedDJ = false;
        hitHover = 0f;
        atk = 0;
        active = false;
        plunging = false;
        hasBlade = false;
        dodgeT = 0f;
        flipT = 0f;
        jumping = false;
        cutting = false;
        jumpBuf = 0f;
        atkBuf = 0f;
        dashBuf = 0f;
        postDash = 0f;
        skidT = 0f;
        landT = 0f;
        takeoffT = 0f;
    }

    void revive() {
        dead = false;
        hp = maxHp;
        invuln = 1.2f;
        flickerT = 1.2f;
    }

    /** Air jumps still available (0 or 1); read by the headless tests. */
    int jumpsLeft() {
        return airJumps;
    }

    /** 0..1: how recharged the dash is (1 = ready). */
    float dashReady() {
        return dodgeCd <= 0f ? 1f : Math.max(0f, 1f - dodgeCd / DASH_CD);
    }

    /** False while a dash is impossible regardless of cooldown (mid-air before Wraith Stride, or after the air dash is spent). */
    boolean dashAvailable() {
        return !dead && hurtT <= 0f && (onGround || coyote > 0f || (hasDJ && !airDashUsed));
    }

    private boolean canDash() {
        if (dead || dodgeCd > 0f || hurtT > 0f) return false;
        return onGround || coyote > 0f || (hasDJ && !airDashUsed);
    }

    // ================================================================== update

    void update(Game g, Input in, float dt) {
        t += dt;
        if (invuln > 0f) invuln -= dt;
        if (hurtT > 0f) hurtT -= dt;
        if (dodgeCd > 0f) dodgeCd -= dt;
        if (coyote > 0f) coyote -= dt;
        if (jumpBuf > 0f) jumpBuf -= dt;
        if (atkBuf > 0f) atkBuf -= dt;
        if (dashBuf > 0f) dashBuf -= dt;
        if (landT > 0f) landT -= dt;
        if (takeoffT > 0f) takeoffT -= dt;
        if (flickerT > 0f) flickerT -= dt;
        if (postDash > 0f) postDash -= dt;
        if (skidT > 0f) skidT -= dt;
        for (int i = 0; i < GN; i++) if (ga[i] > 0f) ga[i] -= dt;
        if (in.takeJump()) jumpBuf = JUMP_BUF;
        if (in.takeAttack()) atkBuf = ATK_BUF;
        if (in.takeDodge()) dashBuf = DASH_BUF;

        final float dir = (in.right ? 1f : 0f) - (in.left ? 1f : 0f);
        moveDir = dir;
        final boolean stunned = hurtT > 0f;
        final boolean was = onGround;
        final float vyBefore = vy;

        if (!stunned && dodgeT <= 0f && dashBuf > 0f && canDash()) startDash(g, dir);
        if (stunned) {
            vx = approach(vx, 0f, 700f * dt);
            gravity = vy < 0f ? G_RISE : G_FALL;
        } else if (dodgeT > 0f) {
            dashStep(g, in, dir, dt);
        } else {
            freeStep(g, in, dir, dt);
        }

        stepPhysics(g.world, dt);
        afterPhysics(g, was, vyBefore, dir);

        phase += Math.abs(vx) * dt * 0.075f;
        sheath.update(dt, atk > 0, onGround && atk == 0 && dodgeT <= 0f && hurtT <= 0f && landT <= 0f);
        pose(g, dt);
        carryFx(g);
        Art.solve(fig);
        bladeStep(g);
        ghosts(dt);
    }

    // ================================================================== dash

    private void startDash(Game g, float dir) {
        final boolean grounded = onGround || coyote > 0f;
        dashAir = !grounded;
        if (dashAir) airDashUsed = true;
        dashDir = dir != 0f ? dir : facing;
        facing = dashDir > 0f ? 1 : -1;
        dashLen = dashAir ? DASH_T_AIR : DASH_T_GROUND;
        dodgeT = dashLen;
        dodgeCd = DASH_CD;
        dashBuf = 0f;
        dashVy = Math.min(0f, vy) * 0.3f;
        invuln = Math.max(invuln, DASH_IFR);
        atk = 0;
        active = false;
        plunging = false;
        hasBlade = false;
        flipT = 0f;
        jumping = false;
        cutting = false;
        dashSlashed = false;
        ghostAcc = 30f;
        vy = 0f;
        g.fx.dustTrail(cx(), y + h, dashDir, 6);
        g.fx.ring(cx() - dashDir * 6f, y + h * 0.5f, 22f, 0xFF58E0FF);
        g.fx.kick(-dashDir * 2.5f, 0f);
    }

    private void dashStep(Game g, Input in, float dir, float dt) {
        dodgeT -= dt;
        final float k = Math.min(1f, (dashLen - dodgeT) / dashLen);
        float sp = DASH_V;
        if (k > DASH_HOLD) sp = DASH_V + (DASH_EXIT - DASH_V) * eio((k - DASH_HOLD) / (1f - DASH_HOLD));
        vx = dashDir * sp;
        vy = 0f;
        gravity = 0f;
        g.fx.streak(cx() - dashDir * 5f, y + 5f + g.fx.rnd.nextFloat() * (h - 10f), 14f + g.fx.rnd.nextFloat() * 22f, dashDir, g.fx.rnd.nextFloat() < 0.5f ? 0xFFE8FFFF : 0xFF58E0FF);
        runDustT -= dt;
        if (!dashAir && onGround && runDustT <= 0f) {
            runDustT = 0.05f;
            g.fx.dustTrail(cx(), y + h, dashDir, 2);
        }
        // attack input: the dash turns into a dash slash once it is past its first half
        if (atkBuf > 0f && k >= 0.45f && !dashSlashed) {
            dashSlashed = true;
            dodgeT = 0f;
            postDash = 0f;
            vx = dashDir * Math.max(DASH_EXIT, sp * 0.8f);
            startMove(g, M_DASH, dashDir);
            return;
        }
        // a jump cancels a grounded dash into a long hop (speed capped so it cannot out-jump a normal run-jump by much)
        if (jumpBuf > 0f && onGround && k >= 0.25f) {
            dodgeT = 0f;
            vx = Body.clamp(vx, -DASH_JUMP_VX, DASH_JUMP_VX);
            postDash = 0f;
            groundJump(g, dir);
            gravity = G_RISE;
            return;
        }
        if (dodgeT <= 0f) endDash();
    }

    private void endDash() {
        dodgeT = 0f;
        postDash = 0.12f;
        vx = dashDir * DASH_EXIT;
        vy = dashVy;
        skidT = 0f;
    }

    // ================================================================== free movement, jumping, attacking

    private void freeStep(Game g, Input in, float dir, float dt) {
        // ---- jumps: a jump press cancels any attack
        if (jumpBuf > 0f) {
            if (onGround || coyote > 0f) groundJump(g, dir);
            else if (hasDJ && airJumps > 0 && !groundSoon(g.world)) doubleJump(g, dir);
        }
        if (jumping) {
            jumpT += dt;
            if (!in.jump && vy < -150f && jumpT >= MIN_JUMP_T) {
                jumping = false;
                cutting = true;
            }
        }
        if (vy >= 0f) {
            jumping = false;
            cutting = false;
        }

        // ---- attacks
        if (atkBuf > 0f) tryAttack(g, dir);
        if (atk > 0) advanceAttack(g, dir, dt);

        // ---- horizontal control
        if (atk == 0) {
            if (onGround && dir != 0f && vx * dir < -100f && skidT <= 0f) {
                skidT = 0.12f;
                g.fx.dustTrail(cx(), y + h, -dir, 4);
            }
            horizontal(dir, dt, 1f);
            if (onGround && Math.abs(vx) > 120f) {
                runDustT -= dt;
                if (runDustT <= 0f) {
                    runDustT = 0.16f;
                    g.fx.dustTrail(cx() - facing * 3f, y + h, facing, 1);
                }
            }
        }

        // ---- gravity
        float gv;
        if (vy < 0f) gv = cutting ? G_CUT : G_RISE;
        else gv = usedDJ ? G_FALL_DJ : G_FALL;
        if (!cutting && Math.abs(vy) < APEX_V && !onGround) gv = G_APEX;
        if (atk > 0 && !onGround) gv = attackGravity(gv, dt);
        if (hitHover > 0f) {
            // a slash that connects holds the hero up for a moment so the combo can continue; it only slows a fall, never a rise
            hitHover -= dt;
            if (vy >= 0f) {
                gv = G_RISE * HOVER_G;
                if (vy > 60f) vy = approach(vy, 60f, 3200f * dt);
            }
        }
        gravity = gv;
    }

    private void horizontal(float dir, float dt, float scale) {
        final float target = dir * RUN;
        if (onGround) {
            vx = approach(vx, target, ACC_GROUND * scale * dt);
        } else if (dir == 0f) {
            vx = approach(vx, 0f, DRAG_AIR * scale * dt);
        } else if (vx * dir < 0f) {
            vx = approach(vx, target, ACC_TURN * scale * dt);
        } else {
            vx = approach(vx, target, ACC_AIR * scale * dt);
        }
        if (dir != 0f) facing = dir > 0f ? 1 : -1;
    }

    private void groundJump(Game g, float dir) {
        vy = -JUMP_V;
        vx = Body.clamp(vx, -RUN, RUN);      // a jump never launches faster than a run (no banking dash or lunge speed)
        jumping = true;
        cutting = false;
        jumpT = 0f;
        jumpBuf = 0f;
        coyote = 0f;
        onGround = false;
        takeoffT = 0.09f;
        landT = 0f;
        flipT = 0f;
        atk = 0;
        active = false;
        plunging = false;
        hasBlade = false;
        g.fx.dust(cx(), y + h);
    }

    private void doubleJump(Game g, float dir) {
        vy = -DJ_V;
        usedDJ = true;
        airJumps--;
        jumpBuf = 0f;
        jumping = true;
        cutting = false;
        jumpT = 0f;
        flipT = FLIP_T;
        atk = 0;
        active = false;
        plunging = false;
        hasBlade = false;
        ghostAcc = 0f;
        // a double jump may redirect the hero: grab the held direction at once
        if (dir != 0f) {
            if (vx * dir < 0f) vx = dir * RUN * 0.6f;
            else vx = dir * Math.max(Math.abs(vx), RUN * 0.6f);
            facing = dir > 0f ? 1 : -1;
        }
        g.fx.ring(cx(), y + h, 34f, 0xFF58E0FF);
        g.fx.ring(cx(), y + h + 4f, 20f, 0xFFFFFFFF);
        g.fx.burst(cx(), y + h, 9, 0xFF9AF0FF, 100f, 0.35f, 2f);
        for (int i = 0; i < 7; i++) {
            g.fx.emit(cx() + (g.fx.rnd.nextFloat() - 0.5f) * 14f, y + h - 2f, (g.fx.rnd.nextFloat() - 0.5f) * 60f, 90f + g.fx.rnd.nextFloat() * 120f, 0.35f + 0.2f * g.fx.rnd.nextFloat(), 2.2f, 0xFF9AF0FF, 0f);
        }
        g.fx.kick(0f, 1.2f);
    }

    /** True when the ground is about to arrive: a buffered jump should wait for it instead of burning the double jump. */
    private boolean groundSoon(World wd) {
        if (vy <= 0f) return false;
        final float feet = y + h, reach = vy * 0.12f + 6f;
        final int tl = (int) Math.floor(x / World.TS), tr = (int) Math.floor((x + w - 0.01f) / World.TS);
        for (int row = (int) Math.floor(feet / World.TS); row * World.TS <= feet + reach; row++) {
            if (wd.solid(tl, row) || wd.solid(tr, row)) return row * World.TS - feet <= reach;
        }
        return false;
    }

    // ------------------------------------------------------------------ attacks

    private void tryAttack(Game g, float dir) {
        final boolean air = !onGround;
        if (atk == 0) {
            int m = air ? Moves.AIR_SLASH : Moves.SLASH;
            if (postDash > 0f && !air) m = M_DASH;
            // the ground opener with the sword on the back is the draw cut; any other opener draws the sword quickly as part of its wind-up
            if (m == Moves.SLASH && !sheath.out()) m = M_DRAW;
            startMove(g, m, dir);
            return;
        }
        // chain (see Moves.NEXT): allowed once the active frames are over
        final int next = Moves.NEXT[atk];
        if (next != 0 && atkT / FRAME >= ST[atk] + AC[atk] - 0.001f) startMove(g, next, dir);
    }

    private void startMove(Game g, int m, float dir) {
        atk = m;
        atkT = 0f;
        active = false;
        plunging = false;
        hasBlade = false;
        atkDur = (ST[m] + AC[m] + RC[m]) * FRAME;
        landBlend = false;
        swing++;
        atkBuf = 0f;
        trailStart = true;
        sheath.draw(m != M_DRAW);
        // a move that winds up with the blade behind the back starts from a trailing blade (running, dashing) without the arm swinging round
        final float az0 = KEY[m][0][P_AZ];
        if (Math.abs(az0) > 2.5f && Math.cos(cur[P_AZ]) * Math.sin(cur[6] + cur[7]) < -0.3f) flipAz(cur, prevCur);
        // the arm turns the short way round to the wind-up (az is periodic, so shifting it by a full turn changes nothing on screen)
        while (cur[P_AZ] - az0 > PI) { cur[P_AZ] -= 2f * PI; prevCur[P_AZ] -= 2f * PI; }
        while (az0 - cur[P_AZ] > PI) { cur[P_AZ] += 2f * PI; prevCur[P_AZ] += 2f * PI; }
        wrapSword(KEY[m][0][P_SWORD]);
        System.arraycopy(cur, 0, from, 0, NP);
        if (dir != 0f) facing = dir > 0f ? 1 : -1;
    }

    private void advanceAttack(Game g, float dir, float dt) {
        final int m = atk;
        atkT += dt;
        final float fr = atkT / FRAME + 0.001f;
        if (!active && dir != 0f) facing = dir > 0f ? 1 : -1;     // can still turn while the blade winds up
        if (!active && fr >= ST[m]) beginActive(g, m);
        final boolean recovering = fr >= ST[m] + AC[m] && !plunging;
        if (onGround) {
            vx = approach(vx, 0f, (active && !recovering ? 650f : 900f) * dt);
            if (Math.abs(vx) > 70f) {
                runDustT -= dt;
                if (runDustT <= 0f) {
                    runDustT = 0.06f;
                    g.fx.dustTrail(cx() - facing * 5f, y + h, facing, 1);
                }
            }
        } else if (m == M_PLUNGE) {
            if (!active) vx = approach(vx, 0f, 900f * dt);
        } else if (recovering) {
            horizontal(dir, dt, 0.6f);
        } else {
            vx = approach(vx, 0f, 220f * dt);
        }
        if (fr >= (ST[m] + AC[m] + RC[m]) - 0.001f) {
            atk = 0;
            active = false;
            plunging = false;
            hasBlade = false;
            return;
        }
        // an aerial slash that finishes after touching down hands control back immediately
        if (onGround && Moves.AERIAL[m] && recovering) {
            atk = 0;
            active = false;
            hasBlade = false;
        }
    }

    private float attackGravity(float gv, float dt) {
        if (atk == M_PLUNGE) {
            if (!active) vy = approach(vy, 0f, 2600f * dt);
            return 0f;
        }
        return gv;
    }

    private void beginActive(Game g, int m) {
        active = true;
        if (m == M_PLUNGE) {
            plunging = true;
            vy = PLUNGE_V;
            vx *= 0.15f;
            g.fx.burst(cx(), y + h * 0.5f, 6, 0xFFFFFFFF, 120f, 0.25f, 2f);
            return;
        }
        final float lunge = LUNGE[m];
        if (onGround || m == M_DASH) {
            float v = lunge;
            final float dx = targetDx(g);
            if (dx >= 0f) v = Body.clamp((float) Math.sqrt(2f * 650f * Math.max(0f, dx - 34f)), 0.4f * lunge, 1.25f * lunge);
            final float cv = vx * facing;
            vx = facing * Math.max(v, cv > 0f ? cv * 0.9f : 0f);
            if (onGround) g.fx.dustTrail(cx(), y + h, facing, 2);
        } else {
            vx = Body.clamp(vx + facing * lunge, -RUN, RUN);
        }
    }

    /** Distance (centre to centre) to the nearest enemy in front within reach, or -1. Used to land the lunge at striking range. */
    private float targetDx(Game g) {
        float best = -1f;
        for (int i = 0; i < g.enemies.size(); i++) {
            final Enemy e = g.enemies.get(i);
            if (e.dead) continue;
            best = nearer(best, (e.cx() - cx()) * facing, e.cy() - cy());
        }
        final Boss b = g.boss;
        if (b != null && b.vulnerable()) best = nearer(best, (b.cx() - cx()) * facing, b.cy() - cy());
        return best;
    }

    private static float nearer(float best, float dx, float dy) {
        if (dx < -4f || dx > 130f || Math.abs(dy) > 50f) return best;
        return best < 0f || dx < best ? Math.max(0f, dx) : best;
    }

    // ------------------------------------------------------------------ blade: hit detection and slash trail

    /** Runs after the pose is solved: tests the swept blade against enemies and lays down the slash trail. */
    private void bladeStep(Game g) {
        if (atk == 0 || dead) {
            hasBlade = false;
            return;
        }
        final float[] j = fig.j;
        final float hx = j[20], hy = j[21], tx = j[22], ty = j[23];
        final float fr = atkT / FRAME, end = ST[atk] + AC[atk];
        if (active && (plunging || fr < end)) {
            trailSamples(g, hx, hy, tx, ty);
            hitCheck(g, hx, hy, tx, ty);
        } else if (active && fr < end + 1.5f) {
            trailSamples(g, hx, hy, tx, ty);      // a short fade-out so the end of the arc has no gap
        }
        ppTx = hasBlade ? pTx : tx;
        ppTy = hasBlade ? pTy : ty;
        pHx = hx;
        pHy = hy;
        pTx = tx;
        pTy = ty;
        hasBlade = true;
    }

    /** Where along the blade (plus extension) the slash band starts: the outer half, so a short light sword leaves a thin swoosh, not a wide fan. */
    private static final float TRAIL_IN = 0.5f;

    private void trailSamples(Game g, float hx, float hy, float tx, float ty) {
        final int col = bladeColor();
        final float ext = EXT[atk];
        final int steps = hasBlade ? 3 : 1;
        if (Moves.RIBBON[atk]) {
            // the tip's path between last frame and this one is a Hermite arc through the neighbouring samples, so a fast sweep
            // draws a smooth swoosh instead of a polyline
            final float floorY = onGround ? y + h : 1e9f;
            final int n = hasBlade ? 6 : 1;
            final float m0x = (tx - ppTx) * 0.5f, m0y = (ty - ppTy) * 0.5f, m1x = tx - pTx, m1y = ty - pTy;
            for (int s = 1; s <= n; s++) {
                final float u = s / (float) n, u2 = u * u, u3 = u2 * u;
                final float h00 = 2f * u3 - 3f * u2 + 1f, h10 = u3 - 2f * u2 + u, h01 = -2f * u3 + 3f * u2, h11 = u3 - u2;
                final float ix = hasBlade ? h00 * pTx + h10 * m0x + h01 * tx + h11 * m1x : tx;
                final float iy = Math.min(floorY, hasBlade ? h00 * pTy + h10 * m0y + h01 * ty + h11 * m1y : ty);
                g.fx.trail(ix, iy - Moves.RIBBON_W[atk], ix, iy, trailStart, col);
                trailStart = false;
            }
            return;
        }
        final float a0 = (float) Math.atan2(pTy - pHy, pTx - pHx), a1 = (float) Math.atan2(ty - hy, tx - hx);
        float da = a1 - a0;
        while (da > Math.PI) da -= 2f * (float) Math.PI;
        while (da < -Math.PI) da += 2f * (float) Math.PI;
        final float l0 = (float) Math.hypot(pTx - pHx, pTy - pHy), l1 = (float) Math.hypot(tx - hx, ty - hy);
        for (int s = 1; s <= steps; s++) {
            final float u = s / (float) steps;
            final float ox = hasBlade ? pHx + (hx - pHx) * u : hx, oy = hasBlade ? pHy + (hy - pHy) * u : hy;
            final float a = hasBlade ? a0 + da * u : a1, len = (hasBlade ? l0 + (l1 - l0) * u : l1) + ext;
            final float ca = (float) Math.cos(a), sa = (float) Math.sin(a);
            final float floorY = onGround ? y + h : 1e9f;      // while standing the arc is cut off by the floor instead of cutting into it
            g.fx.trail(ox + ca * len * TRAIL_IN, Math.min(floorY, oy + sa * len * TRAIL_IN), ox + ca * len, Math.min(floorY, oy + sa * len), trailStart, col);
            trailStart = false;
        }
    }

    private int bladeColor() {
        final int base = edge ? 0xFFFF3050 : 0xFFA6EEFF;      // cold steel-white swoosh; crimson for the Umbral Edge
        return Moves.BIG[atk] ? Art.mix(base, 0xFFFFFFFF, 0.35f) : base;
    }

    private void hitCheck(Game g, float hx, float hy, float tx, float ty) {
        final int m = atk;
        final float ext = EXT[m] + (edge ? 10f : 0f);
        final int dmg = Math.round(DMG[m] * (edge ? 1.5f : 1f));
        boolean hitAny = false;
        float ix = 0f, iy = 0f;
        for (int i = 0; i < g.enemies.size(); i++) {
            final Enemy e = g.enemies.get(i);
            if (e.dead || e.lastSwing == swing) continue;
            if (bladeHits(hx, hy, tx, ty, ext, e.x, e.y, e.w, e.h)) {
                e.lastSwing = swing;
                e.hurt(g, dmg, cx(), KB[m]);
                hitAny = true;
                ix = e.cx();
                iy = e.cy();
            }
        }
        final Boss b = g.boss;
        if (b != null && b.vulnerable() && b.lastSwing != swing && bladeHits(hx, hy, tx, ty, ext, b.x, b.y, b.w, b.h)) {
            b.lastSwing = swing;
            b.hurt(g, dmg);
            hitAny = true;
            ix = b.cx();
            iy = b.cy();
        }
        if (hitAny) impact(g, m, ix, iy, tx, ty);
    }

    /** Feedback for a landed hit: hit-stop, shake, camera shove, flash and sparks thrown along the swing. */
    private void impact(Game g, int m, float ix, float iy, float tx, float ty) {
        final float big = Moves.BIG[m] ? 1f : 0f;
        g.fx.freeze = Math.max(g.fx.freeze, STOP[m]);
        if (!onGround && Moves.AERIAL[m]) hitHover = HIT_HOVER;
        g.fx.shake(SHK[m]);
        g.fx.kick(facing * (2.2f + 2.4f * big), m == M_PLUNGE ? 2.5f : 0f);
        final float px = Body.clamp(ix, tx - 18f, tx + 18f), py = Body.clamp(iy, ty - 18f, ty + 18f);
        g.fx.flash(px, py, 26f + 22f * big);
        g.fx.sparksAng(px, py, facing > 0 ? -0.35f : (float) Math.PI + 0.35f, 6 + (int) (6 * big), 0xFFFFE8B0);
        g.fx.ring(px, py, 20f + 16f * big, 0xFFFFFFFF);
    }

    /** Swept test: the blade (hilt to tip, extended by ext) between last frame and this one touches the box. */
    private boolean bladeHits(float hx, float hy, float tx, float ty, float ext, float bx, float by, float bw, float bh) {
        final float l = bx - BLADE_R, t0 = by - BLADE_R, r = bx + bw + BLADE_R, b = by + bh + BLADE_R;
        final int steps = hasBlade ? 4 : 1;
        for (int s = 0; s < steps; s++) {
            final float u = hasBlade ? (s + 1f) / steps : 1f;
            float h0x = hasBlade ? pHx + (hx - pHx) * u : hx, h0y = hasBlade ? pHy + (hy - pHy) * u : hy;
            float t0x = hasBlade ? pTx + (tx - pTx) * u : tx, t0y = hasBlade ? pTy + (ty - pTy) * u : ty;
            final float[] seg = blade(h0x, h0y, t0x, t0y, ext, atk, cx(), facing, bladeBuf);
            if (seg != null && segBox(seg[0], seg[1], seg[2], seg[3], l, t0, r, b)) return true;
        }
        return false;
    }

    private final float[] bladeBuf = new float[4];

    /**
     * The part of the blade (hilt h to tip t, lengthened by ext) that counts for hits for a move: written to out as x0,y0,x1,y1, or null if
     * none of it counts. The extension fades while the blade is foreshortened (end-on in a flat sweep, where its direction means nothing),
     * and a front-only move ignores whatever is behind the hero's centre line, so a slash that starts behind the back cannot hit
     * what stands behind. Shared with the tests so they judge exactly what the game does.
     */
    static float[] blade(float hx, float hy, float tx, float ty, float ext, int move, float centreX, int facing, float[] out) {
        final float dx = tx - hx, dy = ty - hy, len = (float) Math.sqrt(dx * dx + dy * dy) + 0.0001f;
        final float k = Math.min(1f, len / 10f);
        float x0 = hx, y0 = hy, x1 = tx + dx / len * ext * k, y1 = ty + dy / len * ext * k;
        if (frontOnly(move)) {
            final float lim = centreX - facing * FRONT_SLACK;
            final float f0 = (x0 - lim) * facing, f1 = (x1 - lim) * facing;
            if (f0 < 0f && f1 < 0f) return null;
            if (f0 < 0f) {
                final float u = f0 / (f0 - f1);
                x0 += (x1 - x0) * u;
                y0 += (y1 - y0) * u;
            } else if (f1 < 0f) {
                final float u = f1 / (f1 - f0);
                x1 += (x0 - x1) * u;
                y1 += (y0 - y1) * u;
            }
        }
        out[0] = x0;
        out[1] = y0;
        out[2] = x1;
        out[3] = y1;
        return out;
    }

    /** Liang-Barsky segment against an axis-aligned box. */
    static boolean segBox(float x0, float y0, float x1, float y1, float l, float t, float r, float b) {
        float tmin = 0f, tmax = 1f;
        final float dx = x1 - x0, dy = y1 - y0;
        if (Math.abs(dx) < 1e-6f) {
            if (x0 < l || x0 > r) return false;
        } else {
            float ta = (l - x0) / dx, tb = (r - x0) / dx;
            if (ta > tb) { float s = ta; ta = tb; tb = s; }
            tmin = Math.max(tmin, ta);
            tmax = Math.min(tmax, tb);
            if (tmin > tmax) return false;
        }
        if (Math.abs(dy) < 1e-6f) {
            if (y0 < t || y0 > b) return false;
        } else {
            float ta = (t - y0) / dy, tb = (b - y0) / dy;
            if (ta > tb) { float s = ta; ta = tb; tb = s; }
            tmin = Math.max(tmin, ta);
            tmax = Math.min(tmax, tb);
            if (tmin > tmax) return false;
        }
        return true;
    }

    // ================================================================== physics

    private void stepPhysics(World wd, float dt) {
        vy += gravity * dt;
        if (vy > V_MAX) vy = V_MAX;
        hitWall = false;
        final float dx = vx * dt;
        int n = Math.max(1, (int) Math.ceil(Math.abs(dx) / 8f));
        final float sdx = dx / n;
        for (int i = 0; i < n; i++) {
            final float ox = x, svx = vx;
            moveX(wd, sdx);
            if (hitWall && sdx != 0f && vy > -200f && dodgeT <= 0f) {
                // ledge assist: a corner that is only a few units above the feet is stepped onto instead of bonked into
                for (float up = 1f; up <= STEP_UP; up += 1f) {
                    if (free(wd, ox + sdx, y - up)) {
                        x = ox + sdx;
                        y -= up;
                        vx = svx;
                        hitWall = false;
                        break;
                    }
                }
            }
            if (hitWall) break;
        }
        onGround = false;
        final float dy = vy * dt;
        n = Math.max(1, (int) Math.ceil(Math.abs(dy) / 8f));
        final float sdy = dy / n;
        for (int i = 0; i < n; i++) {
            if (sdy < 0f) cornerNudge(wd, sdy);
            moveY(wd, sdy);
        }
    }

    /** Rising into the edge of a ceiling block by a few units slides the hero past it instead of stopping the jump. */
    private void cornerNudge(World wd, float sdy) {
        final float ny = y + sdy;
        final int ty = (int) Math.floor(ny / World.TS);
        final int tl = (int) Math.floor(x / World.TS), tr = (int) Math.floor((x + w - 0.01f) / World.TS);
        final boolean sl = wd.solid(tl, ty), sr = wd.solid(tr, ty);
        if (sl == sr) return;
        if (sl) {
            final float ov = (tl + 1) * World.TS - x;
            if (ov <= NUDGE && free(wd, x + ov + 0.05f, ny)) x += ov + 0.05f;
        } else {
            final float ov = x + w - tr * World.TS;
            if (ov <= NUDGE && free(wd, x - ov - 0.05f, ny)) x -= ov + 0.05f;
        }
    }

    private void afterPhysics(Game g, boolean was, float vyBefore, float dir) {
        if (dodgeT > 0f && hitWall && dodgeT > 0.03f) {
            // the dash ends against a wall: bump instead of grinding along it
            g.fx.sparksAng(cx() + dashDir * 8f, y + h * 0.5f, dashDir > 0f ? (float) Math.PI : 0f, 5, 0xFFB8E8FF);
            g.fx.kick(-dashDir * 2f, 0f);
            dodgeT = 0f;
            postDash = 0f;
            vx = 0f;
            vy = dashVy;
        }
        if (onGround) {
            coyote = COYOTE;
            airJumps = hasDJ ? 1 : 0;
            airDashUsed = false;
            usedDJ = false;
            hitHover = 0f;
            jumping = false;
            cutting = false;
            flipT = 0f;
            if (!was && vyBefore > 140f) land(g, vyBefore);
            if (plunging) plungeLand(g);
            if (dodgeT <= 0f && g.world.safeSpot(this)) {
                lastSafeX = x;
                lastSafeY = y;
            }
        }
        // coyote time forgives walking off a ledge; it is not a movement option, so it is void when the hero leaves the
        // ground mid-dash or at lunge speed (otherwise dash -> dash slash -> coyote jump would launch from mid-air)
        if (!onGround && (dodgeT > 0f || Math.abs(vx) > RUN * 1.1f)) coyote = 0f;
        if (flipT > 0f) flipT -= FRAME;
    }

    private void land(Game g, float vyBefore) {
        landPow = Body.clamp((vyBefore - 140f) / 480f, 0f, 1f);
        landT = 0.05f + 0.07f * landPow;
        g.fx.dustLand(cx(), y + h, landPow);
        if (landPow > 0.85f) g.fx.kick(0f, 1.6f);
        skidT = 0f;
    }

    private void plungeLand(Game g) {
        plunging = false;
        System.arraycopy(cur, 0, from, 0, NP);      // the landing crouch blends from the pose on screen
        landBlend = true;
        atkT = (ST[M_PLUNGE] + AC[M_PLUNGE]) * FRAME;     // jump straight to the recovery phase
        final float gx = cx(), gy = y + h;
        g.fx.ring(gx, gy - 2f, 48f, 0xFFB8E8FF);
        g.fx.ring(gx, gy - 2f, 30f, 0xFF58E0FF);
        g.fx.dustLand(gx, gy, 1f);
        g.fx.burst(gx, gy - 4f, 10, 0xFFB8E8FF, 160f, 0.35f, 2.2f);
        g.fx.shake(SHK[M_PLUNGE]);
        g.fx.kick(0f, 3.2f);
        // ground slam: anything near the landing spot that the dive did not already hit takes a lighter blow
        boolean any = false;
        for (int i = 0; i < g.enemies.size(); i++) {
            final Enemy e = g.enemies.get(i);
            if (e.dead || e.lastSwing == swing) continue;
            if (overlap(gx - 46f, gy - 36f, 92f, 44f, e.x, e.y, e.w, e.h)) {
                e.lastSwing = swing;
                e.hurt(g, Math.round(12 * (edge ? 1.5f : 1f)), gx, 240f);
                any = true;
            }
        }
        final Boss b = g.boss;
        if (b != null && b.vulnerable() && b.lastSwing != swing && overlap(gx - 46f, gy - 36f, 92f, 44f, b.x, b.y, b.w, b.h)) {
            b.lastSwing = swing;
            b.hurt(g, Math.round(12 * (edge ? 1.5f : 1f)));
            any = true;
        }
        if (any) g.fx.freeze = Math.max(g.fx.freeze, 0.07f);
    }

    // ================================================================== damage

    void hurt(Game g, int dmg, float srcX) {
        if (invuln > 0f || dead) return;
        hp -= dmg;
        if (hp < 0) hp = 0;
        invuln = 0.9f;
        flickerT = 0.9f;
        hurtT = 0.3f;
        clearActions();
        float d = cx() < srcX ? -1f : 1f;
        vx = d * 230f;
        vy = -240f;
        onGround = false;
        g.fx.shake(6f);
        g.fx.freeze = Math.max(g.fx.freeze, 0.07f);
        g.fx.flashA = 0.4f;
        g.fx.flashC = 0xFFFF2040;
        g.fx.burst(cx(), cy(), 10, 0xFFFF4060, 150f, 0.4f, 2.4f);
        g.fx.text(cx(), y - 6f, "-" + dmg, 0xFFFF6070);
    }

    /** Falling into a pit: small damage, then back to the last safe ground. */
    void pitReset(Game g) {
        if (dead) return;
        x = lastSafeX;
        y = lastSafeY;
        snap();
        vx = 0f;
        vy = 0f;
        if (invuln <= 0f) {
            hp = Math.max(0, hp - 15);
            g.fx.shake(5f);
            g.fx.flashA = 0.3f;
            g.fx.flashC = 0xFFFF2040;
            g.fx.text(cx(), y - 6f, "-15", 0xFFFF6070);
        }
        invuln = 1.2f;
        flickerT = 1.2f;
        hurtT = 0f;
        clearActions();
        g.fx.burst(cx(), cy(), 12, 0xFF58E0FF, 120f, 0.4f, 2f);
    }

    // ================================================================== animation

    /** Sets the nine angle parameters and un-plants the feet. */
    private static void set(float[] o, float a0, float a1, float a2, float a3, float a4, float a5, float a6, float a7, float a8) {
        o[0] = a0; o[1] = a1; o[2] = a2; o[3] = a3; o[4] = a4; o[5] = a5; o[6] = a6; o[7] = a7; o[8] = a8;
        o[P_PLANT] = 0f;
        o[P_AZ] = 0f;
    }

    /** Plants both feet: hip height above the floor and how far in front of / behind the hip each foot stands. */
    private static void ground(float[] o, float hip, float footF, float footB) {
        o[P_PLANT] = 1f;
        o[P_HIP] = hip;
        o[P_FF] = footF;
        o[P_FB] = footB;
    }

    /** Two-bone IK for one 7+7 unit leg: out = {thigh angle, knee bend} so the foot lands dx ahead of a hip hipH above the floor. */
    private static void ikLeg(float hipH, float dx, float[] out) {
        final float maxD = 13.95f;
        final float hh = Body.clamp(hipH, 3f, 13.9f);
        float d = (float) Math.hypot(dx, hh);
        if (d > maxD) {
            dx = Math.copySign((float) Math.sqrt(maxD * maxD - hh * hh), dx);
            d = maxD;
        }
        final float alpha = (float) Math.acos(Math.min(1f, d / 14f));
        out[0] = (float) Math.atan2(dx, hh) + alpha;
        out[1] = 2f * alpha;
    }

    /** Smooth-start, slightly fast-middle curve used for wind-ups and sweeps: no frame covers more than ~30% of the move. */
    private static float sw(float u) {
        u = Body.clamp(u, 0f, 1f);
        final float q = 1f - (1f - u) * (1f - u);
        return 0.5f * q + 0.5f * (u * u * (3f - 2f * u));
    }

    /** Same on-screen pose in the other representation: (az, sword, wrist) == (az +- PI, -sword, -wrist), exactly, for any az
     *  (the elbow droop mirrors with cos(az)). Lets a pose with the blade trailing behind start or end a sweep without the arm
     *  swinging round. The previous-frame copy is flipped by the same delta so the slew limiter sees no jump. */
    private static void flipAz(float[] v, float[] prev) {
        final float d = prev[P_AZ] - v[P_AZ];
        v[P_AZ] += v[P_AZ] > 0f ? -PI : PI;
        prev[P_AZ] = v[P_AZ] + d;
        v[6] = -v[6];
        v[7] = -v[7];
        prev[6] = -prev[6];
        prev[7] = -prev[7];
    }

    private static float eo(float u) {
        u = Body.clamp(u, 0f, 1f);
        final float v = 1f - u;
        return 1f - v * v * v;
    }

    private static float eio(float u) {
        u = Body.clamp(u, 0f, 1f);
        return u * u * (3f - 2f * u);
    }

    /** Fills tgt with the pose the current locomotion state wants and sets poseRate (how fast cur chases it). */
    private void locomotionTarget() {
        final float[] o = tgt;
        final float sp = Math.min(1f, Math.abs(vx) / RUN);
        if (hurtT > 0f) {
            set(o, -0.3f, 0.25f, 0.3f, -0.5f, 0.6f, 2.4f, 2.6f, 0.12f, 1f);
            poseRate = 60f;
        } else if (dodgeT > 0f) {
            if (dashAir) {
                set(o, 0.9f, 0.95f, 0.9f, -1.2f, 0.8f, -1.3f, -1.2f, -0.3f, 1f);
            } else {
                set(o, 0.95f, 1.15f, 0.35f, -1.35f, 0.25f, -1.3f, -1.2f, -0.35f, 1f);      // blade streaming straight back
                ground(o, 8.4f, 9.0f, -11.2f);      // a low slide: both feet stay on the floor
            }
            poseRate = 42f;
        } else if (!onGround) {
            if (flipT > 0f) {
                set(o, 0.5f, 1.5f, 2.2f, 1.2f, 2.0f, 1.2f, 1.3f, 0.12f, 1f);
                poseRate = 45f;
            } else if (takeoffT > 0f && vy < 0f) {
                set(o, 0.02f, 0.15f, 0.15f, -0.55f, 0.95f, -0.5f, 2.3f, 0.12f, 1f);
                poseRate = 40f;
            } else if (vy < -APEX_V) {
                set(o, 0.10f, 0.65f, 1.35f, -0.35f, 0.65f, 2.3f, 2.0f, 0.12f, 1f);
                poseRate = 18f;
            } else if (vy <= APEX_V) {
                set(o, 0.06f, 0.80f, 1.50f, -0.10f, 1.20f, 1.5f, 2.1f, 0.12f, 1f);
                poseRate = 14f;
            } else {
                final float f = Body.clamp((vy - 200f) / 500f, 0f, 1f);
                set(o, 0.0f, 0.30f - 0.15f * f, 0.30f - 0.2f * f, -0.50f + 0.2f * f, 0.40f - 0.3f * f, 2.6f + 0.2f * f, 2.45f, 0.12f, 1f);
                poseRate = 14f;
            }
        } else if (landT > 0f && sp < 0.7f) {
            final float p = landPow;
            set(o, 0.15f + 0.25f * p, 0.70f + 0.25f * p, 1.0f + 0.7f * p, -0.5f - 0.15f * p, 0.9f + 0.5f * p, 0.6f, 0.9f, 0.12f, 1f);
            ground(o, 11.6f - 2.6f * p, 5.0f, -4.5f);
            poseRate = 50f;
        } else if (skidT > 0f) {
            set(o, -0.15f, 0.5f, 0.2f, -0.9f, 0.6f, 1.0f, 0.25f, -1.6f, 0.9f);      // sword trailing behind, like the run
            ground(o, 11.6f, 9.0f, -2.5f);
            poseRate = 40f;
        } else if (sp > 0.1f && (moveDir != 0f || sp > 0.55f)) {      // coasting to a stop after a lunge keeps the planted stance
            final float cs = (float) Math.cos(phase), sn = (float) Math.sin(phase);
            // sword in hand: it is carried low and streams back behind the hip instead of poking out in front; the arm only pumps a little.
            // Sword on the back: both arms pump, in opposite phase.
            final boolean out = sheath.out();
            set(o, 0.3f * sp, sn * 0.95f, 0.15f + Math.max(0f, cs) * 0.9f, -sn * 0.95f, 0.15f + Math.max(0f, -cs) * 0.9f,
                0.3f - sn * 0.9f, out ? 0.12f + 0.3f * sn : 0.3f + sn * 0.9f, out ? -1.6f - 0.3f * sp - 0.15f * sn : 0.5f, out ? 0.9f : 1f);
            poseRate = 24f;
        } else {
            final float b = (float) Math.sin(t * 2.2f);
            // sword in hand: a relaxed low guard with the blade down by the leg (not out in front); sword on the back: both arms hang,
            // one a little forward and one a little back
            if (sheath.out()) set(o, 0.06f, 0.14f, 0.12f + 0.06f * b, -0.14f, 0.1f - 0.05f * b, 0.25f + 0.05f * b, 0.55f + 0.05f * b, 0.08f, 1f);
            else set(o, 0.06f, 0.14f, 0.12f + 0.06f * b, -0.14f, 0.1f - 0.05f * b, 0.28f + 0.05f * b, -0.10f - 0.04f * b, 0.25f, 1f);
            ground(o, 13.75f + 0.12f * b, 1.2f, -1.2f);
            poseRate = 18f;
        }
    }

    /** Most the blade tip may travel (relative to the hero) between two frames outside a strike sweep, in units. */
    private static final float TIP_MAX = 40f;
    private float tipRx, tipRy;
    private boolean haveTip;

    private void pose(Game g, float dt) {
        locomotionTarget();
        if (atk > 0) attackPose(dt);
        else {
            final float kk = 1f - (float) Math.exp(-poseRate * dt);
            for (int i = 0; i < NP; i++) cur[i] += (tgt[i] - cur[i]) * kk;
            reachSheath();
        }
        groundW += ((onGround ? 1f : 0f) - groundW) * (1f - (float) Math.exp(-45f * dt));
        final boolean strike = atk > 0 && active && atkT / FRAME < ST[atk] + (plunging ? 3 : AC[atk]) + 0.001f;
        final Art.Fig f = fig;
        // no pose parameter may jump further than a human limb could in one frame, except inside the blade's strike sweep
        if (!strike) {
            for (int i = 0; i < NP; i++) {
                final float lim = i == 8 ? 0.3f : i == P_AZ ? 1.3f : i >= P_HIP ? 3f : i == P_PLANT ? 0.6f : i == 6 || i == 7 ? 0.9f : 1.2f;
                final float d = cur[i] - prevCur[i];
                if (d > lim) cur[i] = prevCur[i] + lim;
                else if (d < -lim) cur[i] = prevCur[i] - lim;
            }
        }
        for (int it = 0; ; it++) {
            applyPose(f);
            // The blade never pokes through the floor while the hero stands: when it would, it is cut short at the floor line. That is
            // continuous (a blade swinging through "straight down", e.g. from the idle guard to the trailing run carry, never snaps
            // from one side to the other) and the hit test sees the same shortened blade.
            if (onGround && f.rot == 0f) {
                final float floorY = y + h - (strike || atk == M_PLUNGE ? 0f : 2.5f);
                final float drop = Art.bladeDrop(f);
                if (f.j[23] > floorY && drop > 0.05f) {
                    f.bladeLen = Body.clamp((floorY - f.j[21]) / drop, 3f, f.bladeLen);
                    Art.solve(f);
                }
            }
            // whatever the pose is chasing (say a dash that cancels a wind-up), the tip of the blade never travels further than a
            // limb could between two frames: the sword arm just takes a few frames longer to get there
            if (strike || !haveTip || it >= 3) break;
            final float dx = (f.j[22] - cx()) * facing - tipRx, dy = (f.j[23] - (y + h)) - tipRy;
            final float dd = (float) Math.sqrt(dx * dx + dy * dy);
            if (dd <= TIP_MAX) break;
            final float k = TIP_MAX / dd;
            for (int i = 6; i <= 8; i++) cur[i] = prevCur[i] + (cur[i] - prevCur[i]) * k;
            cur[P_AZ] = prevCur[P_AZ] + (cur[P_AZ] - prevCur[P_AZ]) * k;
        }
        haveTip = true;      // joint positions are never rotated by a somersault (that happens at draw time), so this holds through flips
        tipRx = (f.j[22] - cx()) * facing;
        tipRy = f.j[23] - (y + h);
        System.arraycopy(cur, 0, prevCur, 0, NP);
    }

    /** Writes the current pose vector into the figure (planted feet by IK) and solves its joints. */
    private void applyPose(Art.Fig f) {
        Art.hero(f, edge);
        f.stow = sheath.stow;
        f.x = cx();
        f.y = y + h;
        f.s = 1f;
        f.dir = facing;
        f.t = t;
        f.vx = vx;
        f.vy = vy;
        f.lean = cur[0];
        f.legF = cur[1];
        f.kneeF = cur[2];
        f.legB = cur[3];
        f.kneeB = cur[4];
        // planted stance: while standing on something, both feet are placed by IK so neither one hovers
        final float pw = Body.clamp(cur[P_PLANT], 0f, 1f) * groundW;
        if (pw > 0.001f) {
            ikLeg(cur[P_HIP], cur[P_FF], ik);
            f.legF += (ik[0] - f.legF) * pw;
            f.kneeF += (ik[1] - f.kneeF) * pw;
            ikLeg(cur[P_HIP], cur[P_FB], ik);
            f.legB += (ik[0] - f.legB) * pw;
            f.kneeB += (ik[1] - f.kneeB) * pw;
        }
        f.armB = cur[5];
        f.swordAng = cur[6];
        f.wrist = cur[7];
        f.reach = cur[8];
        f.az = cur[P_AZ];
        f.rot = flipT > 0f ? eio(1f - flipT / FLIP_T) * 2f * (float) Math.PI * facing : 0f;
        Art.solve(f);
    }

    /** Pose while a move is playing: keyframed wind-up, strike and follow-through, then handed back to locomotion. */
    private void attackPose(float dt) {
        final int m = atk;
        final float fr = atkT / FRAME;
        final float[][] kf = KEY[m];
        final int st = ST[m];
        final int ac = plunging ? 3 : AC[m];
        final float[] a = kf[0], b = kf[1], c = kf[2];
        // a long wind-up (the finisher, the plunge) keeps coiling while it holds: lean back, blade back, hips sink
        final boolean coil = Moves.COIL[m];
        final float creep = coil ? Body.clamp((fr / st - 0.4f) / 0.6f, 0f, 1f) : 0f;
        if (fr < st) {
            final float u = sw(fr / st), up = sw(Math.min(1f, fr / (st * 0.5f)));
            for (int i = 0; i < NP; i++) cur[i] = from[i] + (a[i] - from[i]) * (i == P_PLANT ? up : u);
            cur[0] -= 0.07f * creep;
            cur[P_SWORD] += 0.25f * creep;
            cur[P_HIP] -= 0.7f * creep * cur[P_PLANT];
            if (Moves.FROM_SCABBARD[m]) reachScabbard(fr / st);
        } else if (fr < st + ac) {
            final float u = sw((fr - st) / ac);
            for (int i = 0; i < NP; i++) cur[i] = a[i] + (b[i] - a[i]) * u;
            if (Moves.FOLD[m]) cur[P_REACH] -= 0.5f * (float) Math.sin(Math.PI * u);      // the elbow folds as the hand passes the body: the thrust runs straight, it does not scoop
            if (coil) {      // the coil unwinds into the strike instead of snapping back
                final float rel = Math.max(0f, 1f - u * 5f);
                cur[0] -= 0.07f * rel;
                cur[P_SWORD] += 0.25f * rel;
                cur[P_HIP] -= 0.7f * rel * cur[P_PLANT];
            }
        } else {
            final float rc = RC[m];
            final float u = (fr - st - AC[m]) / rc;
            if (u < 0.35f) {
                final float v = sw(u / 0.35f);
                final float[] start = landBlend ? from : b;
                for (int i = 0; i < NP; i++) cur[i] = start[i] + (c[i] - start[i]) * v;
            } else {
                // a spin ends with the arm turned right round (az = +-PI): switch to the identical in-plane pose so the arm
                // settles by lowering instead of sweeping across the front a second time
                if (Math.abs(cur[P_AZ]) > 3f) flipAz(cur, prevCur);
                wrapSword(tgt[P_SWORD]);      // a cut that went over the head ends a turn or so away: unwind it invisibly, then settle
                final float kk = 1f - (float) Math.exp(-9f * dt);
                for (int i = 0; i < NP; i++) cur[i] += (tgt[i] - cur[i]) * kk;
            }
        }
    }

    /** Shifts the sword-arm angle by whole turns (invisible: angles are periodic) until it is within half a turn of target, so the arm travels the short way. */
    private void wrapSword(float target) {
        while (cur[P_SWORD] - target > PI) { cur[P_SWORD] -= 2f * PI; prevCur[P_SWORD] -= 2f * PI; }
        while (target - cur[P_SWORD] > PI) { cur[P_SWORD] += 2f * PI; prevCur[P_SWORD] += 2f * PI; }
    }

    /** Pulls the sword arm to the scabbard grip with the given weight (the hand on the hilt, the blade along the sheath). */
    private void gripScabbard(float w) {
        SwordArt.gripPose(fig, grip);
        cur[P_SWORD] += (grip[0] - cur[P_SWORD]) * w;
        cur[P_WRIST] += (grip[1] - cur[P_WRIST]) * w;
        cur[P_REACH] += (grip[2] - cur[P_REACH]) * w;
        cur[P_AZ] *= 1f - w;
    }

    /** Start-up of a move that begins at the scabbard: the arm reaches over the shoulder, takes the hilt, then draws the sword up into the wind-up. */
    private void reachScabbard(float k) {
        final float w = eio(k / 0.3f) * (1f - eio((k - 0.4f) / 0.45f));
        if (w > 0f) gripScabbard(w);
    }

    /** While the sword is put away, the idle arm reaches over the shoulder to the scabbard, holds the hilt as the blade slides in, then lets go. */
    private void reachSheath() {
        if (!onGround || dodgeT > 0f || hurtT > 0f || Math.abs(vx) > 60f) return;
        final float w = sheath.reach();
        if (w > 0f) gripScabbard(w);
    }

    /** A glint at the scabbard mouth when the blade clears it or slides home, with a few short sparks along the blade's line. */
    private void carryFx(Game g) {
        final int ev = sheath.takeEvent();
        if (ev == 0 || dead) return;
        final float mx = SwordArt.mouthX(fig), my = SwordArt.mouthY(fig), ux = fig.m[6], uy = fig.m[7];
        final boolean drawn = ev == Sheath.EV_DRAWN;
        g.fx.flash(mx, my, drawn ? 11f : 7f);
        for (int i = drawn ? 4 : 2; i > 0; i--) {
            final float along = 90f + 90f * g.fx.rnd.nextFloat(), across = (g.fx.rnd.nextFloat() - 0.5f) * 60f;
            g.fx.emit(mx, my, -ux * along - uy * across, -uy * along + ux * across, 0.12f + 0.08f * g.fx.rnd.nextFloat(), 1.4f, 0xFFE8FFFF, 0f);
        }
    }

    /** Puts the sword in the hand at once, without the draw (tests, and moves that must not start with one). */
    void drawNow() {
        sheath.reset(true);
    }

    /** Puts the sword on the back at once. */
    void stowNow() {
        sheath.reset(false);
    }

    // ------------------------------------------------------------------ afterimages

    private void ghosts(float dt) {
        if (dodgeT > 0f) {
            ghostAcc += Math.abs(vx) * dt;
            if (ghostAcc >= 30f) {
                ghostAcc -= 30f;
                addGhost(0xFF58E0FF, 130);
            }
        } else if (flipT > FLIP_T * 0.3f) {
            ghostAcc += Math.abs(vy) * dt;
            if (ghostAcc >= 30f) {
                ghostAcc -= 30f;
                addGhost(0xFF9AF0FF, 95);
            }
        } else {
            ghostAcc = 0f;
        }
    }

    private void addGhost(int col, int alpha) {
        System.arraycopy(fig.j, 0, gj[gi], 0, 26);
        ga[gi] = GHOST_LIFE;
        gl[gi] = GHOST_LIFE;
        gaa[gi] = alpha;
        gr[gi] = fig.rot;
        gc[gi] = col;
        gs[gi] = sheath.stow < 0.5f;
        gi = (gi + 1) % GN;
    }

    // ================================================================== draw

    /** Draws the hero between last step's position and this step's (alpha 0..1) so motion stays smooth on any display rate. */
    void draw(Canvas c, float alpha) {
        if (!hasPrev || alpha >= 1f) {
            draw(c);
            return;
        }
        final float ox = x, oy = y, fx0 = fig.x, fy0 = fig.y;
        x = this.px + (ox - this.px) * alpha;
        y = this.py + (oy - this.py) * alpha;
        fig.x = fx0 + (x - ox);
        fig.y = fy0 + (y - oy);
        draw(c);
        x = ox;
        y = oy;
        fig.x = fx0;
        fig.y = fy0;
    }

    void draw(Canvas c) {
        for (int i = 0; i < GN; i++) {
            if (ga[i] <= 0f) continue;
            Art.ghost(c, gj[i], 1f, gr[i], gc[i], (int) (gaa[i] * ga[i] / gl[i]), gs[i]);
        }
        if (dead) return;
        final float boost = dodgeT > 0f ? 0.35f : 0f;
        Art.glow(c, Art.GLOW_CYAN, cx(), y + h * 0.5f, 56f + 16f * boost / 0.35f * (dodgeT > 0f ? 1f : 0f), 0.5f + boost);
        fig.alpha = (flickerT > 0f && ((int) (t * 24f) & 1) == 0) ? 110 : 255;
        fig.flash = hurtT > 0f ? 1f : 0f;
        Art.draw(c, fig);
    }
}
