# mGBA Android — ProGuard / R8 rules
#
# Keep all JNI-called classes and their native method declarations so R8
# does not rename or strip them.  The native side resolves methods by
# their mangled Java names at runtime; any rename → UnsatisfiedLinkError.

-keep class com.mgba.android.EmulatorEngine {
    native <methods>;
    public static final int KEY_*;
}

# jniExchangeData is looked up by literal name/signature from native code
# via GetMethodID(env, cls, "jniExchangeData", "(II)I") in mgba_jni.c
# (Java_..._nativeLinkStart) — R8 can't see that reflective call, so without
# this rule it strips or renames the method and link-cable multiplayer can
# never connect in a minified (release) build.
#
# The rule must match the CURRENT signature: two ints (the SIO word and the
# host's tick stamp). It used to name the older one-int form, which no
# longer exists, so it matched nothing, the real method was removed as
# unused, GetMethodID failed, and the NoSuchMethodError it leaves pending
# was thrown into Kotlin the moment a link connected — a crash on the main
# thread, host and child alike. If this signature ever changes again, change
# it here too (and in mgba_jni.c).
-keepclassmembers class com.mgba.android.LinkMultiplayer {
    public int jniExchangeData(int, int);
    # Smooth link (split-phase exchange): also looked up by name from nativeLinkStart(). They are optional
    # there (a missing one just keeps the link on the blocking jniExchangeData), but without these lines a
    # release build would silently strip them and smooth link could never switch on.
    public int jniExchangeBegin(int, int);
    public int jniExchangeEnd();
    public int jniLastRttUs();
}

# Keep MainActivity so the OS can instantiate it via the manifest class name.
-keep class com.mgba.android.MainActivity { *; }
# The second game window of "Link local" (a MainActivity running in its own process).
-keep class com.mgba.android.PlayerTwoActivity { *; }

# Preserve line numbers in stack traces for production crash reports.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
