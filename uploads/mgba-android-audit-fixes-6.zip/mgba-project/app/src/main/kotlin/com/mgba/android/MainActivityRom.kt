package com.mgba.android

// Split out of MainActivity.kt (pass 46 — "refactor main activity into
// separate classes so organized") as internal extension functions on
// MainActivity, exactly the pattern already established in SharedUi.kt's
// own top-of-file comment (Thirty-second pass) for the same reason: every
// existing unqualified call site inside MainActivity.kt (and inside every
// other split-out file) keeps compiling completely unchanged, since Kotlin
// resolves an unqualified call to an internal extension function on the
// enclosing receiver type the same way it resolves a member call — no
// behavior change, purely a file-organization move. See MainActivity.kt's
// own top-of-file comment for the full file map.

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.text.InputType
import android.text.TextUtils
import android.text.format.DateFormat
import android.util.Log
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.Closeable
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.io.PrintWriter
import java.io.StringWriter
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference
import java.util.zip.ZipInputStream
import kotlin.math.abs
import kotlin.math.roundToInt


// isZipSignature()/zipContainsGba() moved to RomZipUtils.kt this pass
// (Thirty-second) when the ROM browser became its own Activity —
// RomBrowserActivity needs zipContainsGba() too, and this way there's
// still only one copy of the byte comparison between it and
// stageRomFile() below, same as when both lived in this class.

/** Copies [uri] into [tmp]. If the source is a zip archive — detected by
 *  its real magic bytes (see RomZipUtils.isZipSignature()), not by file
 *  extension, so a misnamed archive still works and a .zip that somehow
 *  isn't a real zip is correctly rejected instead of handed to the core
 *  as garbage — the first .gba entry found inside is extracted instead
 *  of the raw archive bytes. This is what lets both the file browser
 *  and the classic system picker load a ROM straight out of a .zip with
 *  no separate extraction step. Returns false if nothing worth loading
 *  ended up in [tmp] (unreadable source, or a zip with no .gba entry). */
internal fun MainActivity.stageRomFile(uri: Uri, tmp: File): Boolean {
    val raw = contentResolver.openInputStream(uri) ?: return false
    raw.use { stream ->
        val input = stream.buffered()
        if (!RomZipUtils.isZipSignature(input)) {
            val ok = tmp.outputStream().use { o -> copyCapped(input, o, MAX_ROM_BYTES) }
            if (!ok) tmp.delete()
            return ok
        }
        ZipInputStream(input).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                if (!entry.isDirectory && entry.name.endsWith(".gba", ignoreCase = true)) {
                    val ok = tmp.outputStream().use { o -> copyCapped(zip, o, MAX_ROM_BYTES) }
                    if (!ok) tmp.delete()
                    return ok
                }
                entry = zip.nextEntry
            }
        }
        return false
    }
}

/** AUDIT FIX: ceiling on how many bytes stageRomFile() will write. A GBA
 *  cartridge tops out at 32 MiB; 64 MiB leaves room for odd dumps while
 *  keeping a wrong pick — a huge file renamed .gba, or a zip bomb whose one
 *  .gba entry inflates to gigabytes — from filling the app's cache. */
private const val MAX_ROM_BYTES = 64L * 1024 * 1024

/** Copies [input] to [output], stopping with false (and logging) as soon as
 *  more than [limit] bytes would be written. */
private fun copyCapped(input: java.io.InputStream, output: java.io.OutputStream, limit: Long): Boolean {
    val buf = ByteArray(64 * 1024)
    var total = 0L
    while (true) {
        val n = input.read(buf)
        if (n < 0) return true
        total += n
        if (total > limit) {
            Log.w(TAG, "stageRomFile: source exceeds $limit bytes — refusing to stage it as a ROM")
            return false
        }
        output.write(buf, 0, n)
    }
}


/** Stages [uri] (transparently unzipping it first if needed — see
 *  stageRomFile()), swaps it into the running core, and updates the UI
 *  on success or failure. Shared by every ROM entry point — the classic
 *  system picker above and the in-app file browser's file rows below
 *  both just call this now, instead of each duplicating the load. */
internal fun MainActivity.loadRomFromUri(uri: Uri) {
    // AUDIT FIX (ROM-swap races): capture whether a session exists and mark
    // it gone for the duration of the swap, synchronously, before the loader
    // thread even starts. romLoaded used to stay true all the way through, so
    // an onPause() landing between the native core swap and the UI-thread
    // post below would autosave the NEW ROM's state under the OLD ROM's name
    // (currentRomBaseName isn't updated until that post), and an onResume()
    // in the same window could restart the old core's loop mid-swap. With it
    // false, both skip — there is no consistent session to save or resume
    // until the post below (or resumeSessionAfterFailedSwap()) says so.
    val hadSession = romLoaded
    if (hadSession) romLoaded = false
    Thread {
        // Set once nativeLoadROM() has actually replaced the old core; before
        // that point any failure leaves the previous session intact and
        // resumable (see resumeSessionAfterFailedSwap()).
        var swapped = false
        try {
            // FIX: nativeLoadROM() silently drops any active link session
            // as part of swapping the native core (see the "ROM swapped
            // while a link session was active" comment in mgba_jni.c) —
            // that side is careful to avoid leaving a dangling pointer,
            // but it has no way to tell the Kotlin side this happened.
            // Without this, link.isConnected and the ⬤ LINK overlay would
            // keep claiming "Connected" after a ROM swap even though the
            // native SIO driver backing the exchange no longer exists —
            // a silently broken multiplayer session with no indication
            // in the UI of why. Disconnect first so both sides agree.
            if (link.isConnected) stopLink()
            // FIX (Twenty-first pass): if a Storage folder is configured
            // and a ROM is already running, its battery save has only
            // ever been mirrored to internal storage (see
            // SaveEntry.batteryMirrorPath()) — the real document in the
            // chosen folder hasn't seen anything played since the last
            // sync point. Flush it out now, before that mirror file gets
            // reused for the ROM we're about to swap in, or whatever was
            // played this session never reaches the chosen folder at all.
            // mirrorToAutoFolder() alongside it: same flush moment, just
            // for the automatic own-folder mirror instead of a chosen
            // SAF folder — see the FEATURE block above dataFolderTree().
            // AUDIT FIX: the game thread is stopped FIRST and the flush
            // happens after. It used to be the other way round, so SRAM
            // writes the still-running game made between the flush and the
            // stop never reached the Storage-folder mirror.
            //
            // FIX: stop any in-progress game loop *before* touching the
            // native core, and reset transient input/FF state. Previously
            // there was no way to load a second ROM at all (loadRomBtn was
            // permanently hidden after the first successful load), so this
            // path was never exercised. nativeLoadROM() now builds the new
            // core fully before swapping it in, so a failed load here
            // leaves the previous session running rather than destroying
            // it (see mgba_jni.c).
            stopGameLoop()
            if (hadSession) {
                batterySaveEntry(currentRomBaseName).syncBatteryMirror()
                batterySaveEntry(currentRomBaseName).mirrorToAutoFolder()
            }
            // AUDIT FIX: stage into its OWN file, not rom_loaded.gba. The
            // running core memory-maps its ROM file for its whole lifetime
            // (mGBA's GBALoadROM maps the VFile), and stageRomFile()
            // truncates and rewrites whatever file it is given — doing that
            // to rom_loaded.gba rewrote the live core's ROM out from under
            // it, and left a corrupt copy behind for resetGame() whenever
            // staging or loading then failed. The staged file is only
            // renamed over rom_loaded.gba once the new core has loaded it.
            val tmp = cacheDir.resolve("rom_loading$instanceFileTag.gba")
            if (!stageRomFile(uri, tmp)) {
                tmp.delete()
                uiToast("Couldn't read that file (or found no .gba inside the zip)")
                resumeSessionAfterFailedSwap(hadSession)
                return@Thread
            }
            // ROM SAVE: identify the ROM by its picked display name —
            // not the fixed "rom_loaded.gba" cache path above, which
            // every ROM shares — so its battery save persists under a
            // name stable across app restarts and re-picking the same
            // file later. See deriveRomBaseName()/batterySaveEntry().
            val ownKey = deriveRomBaseName(uri, tmp)
            migrateLegacyRomFiles(legacyRomBaseName(uri), ownKey)
            // FEATURE (link saves to another version of this ROM): the key everything below files its saves under
            // is the ROM's own — unless an alias (or a first-load offer) sends it to another version's files.
            // Nothing is copied or moved either way. The second game window of Link local keeps strictly to its
            // own key. May show a dialog and wait for the answer: this is the loader thread, never the UI thread.
            val baseName = if (isPlayerTwo) ownKey else resolveSaveKey(uri, ownKey)
            val saveEntry = batterySaveEntry(baseName)
            backupBatteryIfExists(saveEntry)   // AUDIT FIX: copy, not rename — see SaveEntry.copyInto()
            // FIX (Twenty-first pass): was saveEntry.nativePath(forWrite
            // = true).path — a /proc/self/fd bridge straight onto the SAF
            // document, mmap'd by the core for the whole session. See the
            // block comment above dataFolderTree() for why that doesn't
            // hold up on a real device. batteryMirrorPath() below is
            // always a plain local path; when a Storage folder is
            // configured it stages the existing save in from there first.
            val savePath = saveEntry.batteryMirrorPath()
            val ok = EmulatorEngine.nativeLoadROM(tmp.absolutePath, savePath)
            if (ok) {
                swapped = true
                // The new core now has tmp mapped; renaming keeps that
                // mapping valid (same inode) while making this the ROM copy
                // resetGame() reloads from. The old core, already torn down
                // inside nativeLoadROM(), held the previous inode.
                val canonical = cacheDir.resolve("rom_loaded$instanceFileTag.gba")
                canonical.delete()
                if (!tmp.renameTo(canonical)) {
                    Log.w(TAG, "Couldn't publish ${tmp.name} as ${canonical.name} — Reset Game may not find the ROM")
                }
            } else {
                tmp.delete()
            }
            Handler(Looper.getMainLooper()).post romLoadDone@ {
                // FIX: onDestroy() may have already run and freed the
                // native core by the time this posts, if the load was
                // slow (large ROM, a slow SAF/cloud-backed URI) and the
                // user backed out of the app in the meantime. Without
                // this check, the block below would re-init AudioTrack
                // and start a brand new game thread + Choreographer
                // registration after teardown — resources nothing would
                // ever clean up, since onDestroy() has already run and
                // won't run again for this instance.
                if (isFinishing || isDestroyed) return@romLoadDone
                // BUG FIX: this whole block runs on the MAIN thread,
                // asynchronously, well after loadRomFromUri's own
                // try/catch — wrapping the background Thread body above
                // — has already finished and returned. That catch does
                // NOT protect anything in here despite the misleading
                // nesting; Handler.post() only schedules this lambda,
                // it doesn't run it, so by the time this body actually
                // executes the outer try is long gone. Any exception
                // here (Bitmap.createBitmap, AudioTrack init, the
                // thread/Choreographer setup in startGameLoop()) was
                // previously a genuine uncaught exception on the main
                // thread — a hard app crash, with the ROM having *just*
                // finished loading successfully.
                try {
                    if (ok) {
                        val w = EmulatorEngine.nativeGetWidth().coerceAtLeast(1)
                        val h = EmulatorEngine.nativeGetHeight().coerceAtLeast(1)
                        frameBuffers = Array(3) {
                            Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                        }
                        writeIdx = 0
                        readyIdx = -1
                        displayIdx = -1
                        // AUDIT FIX: the name is set BEFORE romLoaded flips
                        // true, so no reader can ever see "a ROM is loaded"
                        // paired with the previous ROM's save key.
                        currentRomBaseName = baseName
                        currentRomOwnKey = ownKey
                        romLoaded = true
                        // FIX (this pass): see applyScreenOrientationPref()'s
                        // own doc comment. This activity was Portrait the
                        // whole time RomBrowserActivity was open (idle —
                        // see that function) — now that a ROM is actually
                        // loaded, switch to the user's chosen gameplay
                        // orientation, before startGameLoop() below starts
                        // rendering.
                        applyScreenOrientationPref()
                        clearPointerState()
                        currentKeys.set(0)
                        fastForwardActive = false
                        // FEATURE (direct report — Misc setting "Auto
                        // Save & Load": "...points load it back on
                        // start"): the other half of onPause()'s own
                        // autosave write — see that function's doc
                        // comment for why *that* half is synchronous.
                        // This half is synchronous for a related but
                        // different reason: it has to finish before
                        // startGameLoop() below starts rendering, or
                        // the very first frame(s) shown would briefly
                        // be the ROM's own boot state before snapping
                        // to the restored one. currentRomBaseName is
                        // already set above, so autoStateEntry() below
                        // resolves to *this* ROM's own autosave, not
                        // whichever ROM was playing last. Silent when
                        // there's nothing to load (no toast, no
                        // "nothing found" message) — this runs on
                        // literally every ROM load, and most of the
                        // time, especially the very first time this ROM
                        // is ever opened, there won't be one yet.
                        if (autoSaveLoadEnabled) {
                            val autoEntry = autoStateEntry()
                            if (autoEntry.exists()) {
                                val autoLocalPath = autoEntry.stageForRead()
                                if (autoLocalPath != null && EmulatorEngine.nativeLoadState(autoLocalPath)) {
                                    uiToast("Autosave loaded")
                                }
                            }
                        }
                        // A freshly built core has no cheats: put this game's list back (it is
                        // applied by the core itself from the first frame on).
                        applyCheatsToCore()
                        initAudioTrack()
                        startGameLoop()
                        // FEATURE (Link local): the second window links to the first one by itself as soon as
                        // its game is running — see PlayerTwoActivity / joinLocalHost().
                        if (pendingLocalLinkJoin) {
                            pendingLocalLinkJoin = false
                            joinLocalHost()
                        }
                    } else {
                        uiToast("Unsupported ROM format")
                        if (hadSession) {
                            // AUDIT FIX: nativeLoadROM() builds the new core
                            // off to the side and leaves the old one
                            // untouched on failure, but this used to leave
                            // the loop stopped and romLoaded false anyway —
                            // a dead screen on top of a perfectly good
                            // session. Put the old one back.
                            romLoaded = true
                            startGameLoop()
                        } else {
                            romLoaded = false
                        }
                    }
                } catch (e: Throwable) {
                    // Leave the app in a state the user can recover from
                    // instead of a crash: no half-started game, surface
                    // wiped, and romLoaded left false so a tap on the
                    // idle screen (see onGameTouch()) reopens the ROM
                    // browser instead of leaving a dead screen behind.
                    Log.e(TAG, "ROM load post-processing failed", e)
                    uiToast("Load error: ${e.message ?: e.javaClass.simpleName}")
                    romLoaded = false
                    clearSurfaceToBlack()
                }
            }
        } catch (e: Throwable) {
            Log.e(TAG, "ROM load failed", e)
            uiToast("Load error: ${e.message ?: e.javaClass.simpleName}")
            // Only safe to resume if the old core is still the live one.
            if (!swapped) resumeSessionAfterFailedSwap(hadSession)
        }
    }.apply { name = "mGBA-load" }.start()
}

/**
 * AUDIT FIX: a ROM swap (or Reset) that fails BEFORE the native core is
 * replaced — unreadable file, no .gba in the zip, a thrown exception —
 * leaves the previous core alive and untouched, so the previous session
 * should simply carry on. It used to be left with its loop stopped and
 * romLoaded false, i.e. a dead screen. No-op when there was no session to
 * go back to. Posts to the UI thread because it restarts the game loop.
 */
internal fun MainActivity.resumeSessionAfterFailedSwap(hadSession: Boolean) {
    if (!hadSession) return
    Handler(Looper.getMainLooper()).post {
        if (isFinishing || isDestroyed) return@post
        romLoaded = true
        startGameLoop()
    }
}


/** Entry point for loading/swapping the ROM — called from onCreate() on
 *  first launch, from closeGame() when backing out of a game, and from
 *  onGameTouch() when the idle (no-ROM-loaded) surface is tapped.
 *  Launches RomBrowserActivity (a separate Activity as of Thirty-second
 *  pass, not an overlay in this one — see its own top-of-file comment)
 *  and waits for a result; romBrowserLauncher above hands whatever it
 *  returns to loadRomFromUri(). Broad file access, the folder browsing
 *  itself, and the classic single-document SAF picker fallback are all
 *  that Activity's own concern now, not this one's. */
internal fun MainActivity.changeRom() {
    romBrowserLauncher.launch(Intent(this, RomBrowserActivity::class.java))
    // FIX (Fortieth pass — reported directly: opens in landscape,
    // "then it go to portrait instantly"). This app is normally in
    // landscape during play; RomBrowserActivity is manifest-locked to
    // portrait (see its own top-of-file comment for why that's a
    // static declaration and NOT a runtime requestedOrientation call —
    // this fix doesn't touch that at all, for the same reason).
    // Actually rotating the physical display for the new Activity is a
    // real reconfiguration, and the default slide/fade activity
    // transition gives it a couple of animated frames to be visible
    // mid-rotation, which is what reads as "opens landscape, then
    // snaps to portrait". overridePendingTransition(0, 0) collapses
    // that transition to nothing, so the swap is an instant cut
    // instead of an animated one with a wrong-orientation frame in the
    // middle. Deprecated as of API 34 (replaced by
    // overrideActivityTransition) but still fully functional at this
    // app's targetSdk 34 — kept as the plain call rather than a
    // version-gated branch since the two behave identically here and
    // there's nothing to verify a newer, unfamiliar signature against
    // in this sandbox (no compiler/device, as every pass). See
    // RomBrowserActivity's own finish() override for the matching
    // fix on the way back.
    @Suppress("DEPRECATION")
    overridePendingTransition(0, 0)
}


// ── Save / state file naming ─────────────────────────────────────────
// SAF (Storage Access Framework) URIs don't carry a real filesystem
// path, and the only identifier for "which ROM is this" that's stable
// across app restarts and re-picking the same file is the picked
// document's display name — queried via ContentResolver, since
// uri.lastPathSegment is often an opaque provider-specific ID rather
// than the actual filename on many document providers (Downloads,
// Google Drive, etc).

/** The ROM's display name minus its extension, exactly as the provider
 *  reported it (or the URI's last path segment as a fallback) — not yet
 *  sanitized. Shared by deriveRomBaseName() and legacyRomBaseName(). */
private fun MainActivity.romRawBaseName(uri: Uri): String {
    var display: String? = null
    try {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { c ->
                val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && c.moveToFirst()) display = c.getString(idx)
            }
    } catch (_: Exception) {
        // Provider didn't support the query — fall through to the
        // URI-based fallback below.
    }
    return (display ?: uri.lastPathSegment ?: "rom").substringBeforeLast('.')
}

/** CRC32 of the staged ROM file as 8 lowercase hex digits, or null if it
 *  can't be read. java.util.zip.CRC32 is intrinsified on arm64, so even a
 *  32 MB ROM takes a few tens of milliseconds. */
private fun romCrc32Hex(file: File): String? = try {
    val crc = java.util.zip.CRC32()
    val buf = ByteArray(64 * 1024)
    file.inputStream().use { input ->
        while (true) {
            val n = input.read(buf)
            if (n < 0) break
            crc.update(buf, 0, n)
        }
    }
    "%08x".format(crc.value)
} catch (e: Exception) {
    Log.w(TAG, "romCrc32Hex(${file.name}) failed — falling back to a name-only save key", e)
    null
}

/**
 * AUDIT FIX (save collisions): the key every battery save, state slot,
 * quicksave, autosave and thumbnail is filed under.
 *
 * It used to be only the sanitized file name, so two different ROMs with
 * the same name (a ROM hack and its base game, "Pokemon.gba" in two
 * folders, ...) silently shared one .sav and one set of states — and any
 * title that sanitized away entirely (an all-Japanese name became "____")
 * collided with every other such title. The key is now
 * `<sanitized name>_<CRC32 of the ROM>`: same file = same saves, different
 * ROM = different saves, even under an identical name. Unicode letters and
 * digits are kept in the readable part (modern Android filesystems are fine
 * with them), so non-Latin titles stay distinguishable by name too.
 *
 * [stagedRom] is the local copy stageRomFile() already produced (already
 * unzipped if the source was a .zip), so the hash is of the actual ROM
 * bytes, not of the archive around them.
 *
 * Existing installs: files saved under the old name-only key are copied
 * across by migrateLegacyRomFiles(), called right after this.
 */
internal fun MainActivity.deriveRomBaseName(uri: Uri, stagedRom: File): String {
    val readable = romReadableName(uri)
    val crc = romCrc32Hex(stagedRom)
    return if (crc != null) "${readable}_$crc" else readable
}

/** The readable half of the save key, split out of deriveRomBaseName() so findSaveSibling() can match other
 *  versions of the same ROM by it: the display name, sanitized (Unicode letters/digits, '_' and '-' kept) and
 *  cut to 48 characters. The second game window of Link local (PlayerTwoActivity) gets a "p2-" prefix, which is
 *  what keeps its saves apart from the first window's even for the very same ROM file — a trade between two
 *  copies of a game needs two saves. */
internal fun MainActivity.romReadableName(uri: Uri): String {
    val name = romRawBaseName(uri)
        .replace(Regex("[^\\p{L}\\p{N}_-]"), "_")
        .take(48)
        .ifBlank { "rom" }
    return if (isPlayerTwo) "p2-$name" else name
}

/** The key saves were filed under BEFORE the CRC suffix was added — the
 *  old sanitizer, verbatim. Only used to find files to migrate. */
internal fun MainActivity.legacyRomBaseName(uri: Uri): String =
    romRawBaseName(uri).replace(Regex("[^A-Za-z0-9_-]"), "_").take(80).ifBlank { "rom" }

/**
 * One-time carry-over of saves filed under the old name-only key
 * ([legacyBase]) to the new CRC-suffixed one ([newBase]): every
 * `<legacyBase>.*` file in the local saves/ and states/ folders, and — best
 * effort — in the chosen Storage folder's "save" subfolder.
 *
 * COPIES, never moves. Which ROM a legacy file "really" belongs to can't be
 * known (that is the collision this change ends), and a file that merely
 * shares a name — a corrupt download, an unsupported ROM that then fails to
 * load — must not be able to take saves away from the real one. The old
 * files are left in place, so the worst case is some duplicated bytes, never
 * a lost save; once you've confirmed everything carried over they are safe
 * to delete by hand.
 *
 * Only copies when the destination doesn't exist yet, so it can never
 * overwrite saves made under the new key, and each copy goes through a temp
 * file + rename so a crash can't leave a truncated file that then blocks the
 * real migration. The exact "<legacyBase>." prefix (sanitized names contain
 * no dots) means one ROM's migration can't pick up another ROM's files.
 *
 * Call from a background thread: it does file and SAF I/O.
 */
internal fun MainActivity.migrateLegacyRomFiles(legacyBase: String, newBase: String) {
    if (legacyBase == newBase) return
    // First ROM to load under a given legacy key claims it; every later ROM
    // that used to share that key starts clean instead of also inheriting a
    // copy of the shared save (which is exactly the collision being fixed).
    val claimKey = "legacy_saves_claimed_$legacyBase"
    val claims = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    if (claims.contains(claimKey)) return
    val legacyPrefix = "$legacyBase."
    val newPrefix = "$newBase."
    for (dir in listOf(savesDir(), statesDir())) {
        dir.listFiles { f -> f.isFile && f.name.startsWith(legacyPrefix) && !f.name.contains(".tmp-") }
            ?.forEach { old ->
                val dest = File(dir, newPrefix + old.name.substring(legacyPrefix.length))
                if (dest.exists()) return@forEach
                val tmp = File(dir, "${dest.name}.tmp-mig")
                try {
                    old.copyTo(tmp, overwrite = true)
                    if (tmp.renameTo(dest)) Log.i(TAG, "Carried over ${old.name} -> ${dest.name}")
                    else Log.w(TAG, "Couldn't carry over ${old.name} -> ${dest.name}")
                } catch (e: Exception) {
                    Log.w(TAG, "Couldn't carry over ${old.name} -> ${dest.name}", e)
                } finally {
                    tmp.delete()   // no-op once the rename succeeded
                }
            }
    }
    val folder = dataSubfolder("save")
    try {
        if (folder != null) for (doc in folder.listFiles()) {
            val n = doc.name ?: continue
            if (!n.startsWith(legacyPrefix)) continue
            val newName = newPrefix + n.substring(legacyPrefix.length)
            if (folder.findFile(newName) != null) continue
            val dst = folder.createFile("application/octet-stream", newName) ?: continue
            contentResolver.openInputStream(doc.uri)?.use { input ->
                contentResolver.openOutputStream(dst.uri, "wt")?.use { out -> input.copyTo(out) }
            }
        }
    } catch (e: Exception) {
        Log.w(TAG, "Storage-folder carry-over skipped", e)
    }
    claims.edit().putString(claimKey, newBase).apply()
}



// ── SAVE LINKS: use another version of this ROM's saves ───────────────────
//
// BUG (direct report): patch a ROM and give the patched file exactly the same name as the original, and the
// emulator starts a NEW GAME — the in-game save, save states, quicksave and autosave are all ignored.
//
// ROOT CAUSE: deriveRomBaseName() (AUDIT FIX, save collisions) files everything under
// "<sanitized name>_<CRC32 of the ROM>". A patched ROM has a different CRC32, so it gets a brand-new key even
// under an identical name ("..._a228ff3e" original, "..._3632fca4" patched). migrateLegacyRomFiles() cannot
// help: it only maps the OLD name-only key to one new key, and the first ROM to load claims it
// (legacy_saves_claimed_<legacyBase>).
//
// The CRC key stays the DEFAULT — it is what stops two different ROMs with one name from sharing a save, and
// guessing "same game" from the name alone would bring that collision straight back. What this adds is an
// explicit, per-ROM ALIAS: "file my saves under that other version's key". Two entries in SharedPreferences(PREFS):
//   "save_alias_<ownKey>"          = <otherKey>   the FINAL key — one hop, never a chain
//   "save_alias_declined_<ownKey>" = true         "Keep separate": never ask again
// loadRomFromUri() resolves the key once (resolveSaveKey()) and hands that to everything downstream — battery
// save, state slots, quicksave, autosave, thumbnails, SaveEntry's Storage folder, resetGame() — which all use
// currentRomBaseName already. No file is ever moved, copied, deleted or overwritten: an alias only changes which
// existing files are opened, and removing it (Settings -> Storage -> Unlink) puts the ROM's own back.

private enum class SaveLinkChoice { USE_SAME, KEEP_SEPARATE, NOT_NOW }

/** Another version of this ROM that has saves: [key] is its full save key "<readable>_<crc>". */
private class SaveSibling(val key: String, val crc: String, val lastModified: Long)

private class SiblingAcc(var flags: Int = 0, var newest: Long = 0L)

private const val SIBLING_BATTERY = 1
private const val SIBLING_STATE   = 2

/** What follows "<readable>_" in a sibling's file name: "<8 hex digits>.<extension>". Name-only keys
 *  ("<readable>.sav", from before the CRC suffix) don't match and are ignored. */
private val SIBLING_REST = Regex("^([0-9a-f]{8})\\.(.+)$")

private fun saveAliasPrefKey(ownKey: String) = "save_alias_$ownKey"
private fun saveAliasDeclinedPrefKey(ownKey: String) = "save_alias_declined_$ownKey"

/** True if [input] holds battery-save bytes that have actually been played into: not empty, and not entirely
 *  0x00 (fresh SRAM) or entirely 0xFF (erased Flash/EEPROM). Reads at most 256 KiB — a GBA save is ≤ 128 KiB. */
private fun streamHasRealSaveData(input: InputStream): Boolean {
    val buf = ByteArray(8192)
    var allZero = true
    var allFF = true
    var total = 0
    while (total < 256 * 1024) {
        val n = input.read(buf)
        if (n < 0) break
        for (i in 0 until n) {
            val b = buf[i].toInt() and 0xFF
            if (b != 0x00) allZero = false
            if (b != 0xFF) allFF = false
        }
        if (!allZero && !allFF) return true
        total += n
    }
    return !allZero && !allFF
}

private fun fileHasRealSave(f: File): Boolean = try {
    f.isFile && f.length() > 0L && f.inputStream().use { streamHasRealSaveData(it) }
} catch (_: Exception) {
    false
}

/** Does this ROM already have a battery save worth keeping? Local file first; when a Storage folder is
 *  configured the real document may live there (the local file is only staged in at load time), so look there
 *  too — best effort, any failure just means "no". */
private fun MainActivity.hasRealBatterySave(key: String): Boolean {
    if (fileHasRealSave(File(savesDir(), "$key.sav"))) return true
    return try {
        val doc = dataSubfolder("save")?.findFile("$key.sav")
        doc != null && doc.length() > 0L &&
            contentResolver.openInputStream(doc.uri)?.use { streamHasRealSaveData(it) } == true
    } catch (_: Exception) {
        false
    }
}

/** Do files of any kind still exist under [key] ("<key>." prefix: .sav, .stateN, .quicksave, .autosave and their
 *  thumbnails) — locally, or by name in the Storage folder's "save" subfolder? */
private fun MainActivity.saveFilesExist(key: String): Boolean {
    val prefix = "$key."
    for (dir in listOf(savesDir(), statesDir())) {
        val hit = dir.listFiles { f -> f.isFile && f.name.startsWith(prefix) && !f.name.contains(".tmp-") }
        if (hit != null && hit.isNotEmpty()) return true
    }
    return try {
        dataSubfolder("save")?.listFiles()?.any { (it.name ?: "").startsWith(prefix) } == true
    } catch (_: Exception) {
        false
    }
}

private fun noteSiblingFile(
    into: HashMap<String, SiblingAcc>, readablePrefix: String, ownCrc: String,
    name: String, size: Long, modified: Long, realBattery: () -> Boolean
) {
    if (!name.startsWith(readablePrefix) || name.contains(".tmp-")) return
    val m = SIBLING_REST.matchEntire(name.substring(readablePrefix.length)) ?: return
    val crc = m.groupValues[1]
    if (crc == ownCrc) return
    val ext = m.groupValues[2]
    val flag = when {
        ext == "sav" -> if (size > 0L && realBattery()) SIBLING_BATTERY else 0
        ext.endsWith(".png") -> 0                                    // thumbnails say nothing by themselves
        ext.startsWith("state") || ext == "quicksave" || ext == "autosave" -> if (size > 0L) SIBLING_STATE else 0
        else -> 0
    }
    if (flag == 0) return
    val acc = into.getOrPut(crc) { SiblingAcc() }
    acc.flags = acc.flags or flag
    if (modified > acc.newest) acc.newest = modified
}

/** Other versions of this ROM (same readable name, a DIFFERENT crc) that have a real battery save or any state
 *  file, in the local saves/ and states/ folders and — names and sizes only, nothing is read — the Storage
 *  folder's "save" subfolder. The one that was written most recently, or null. */
private fun MainActivity.findSaveSibling(readable: String, ownCrc: String): SaveSibling? {
    val found = HashMap<String, SiblingAcc>()
    val prefix = "${readable}_"
    for (dir in listOf(savesDir(), statesDir())) {
        dir.listFiles()?.forEach { f ->
            if (f.isFile) noteSiblingFile(found, prefix, ownCrc, f.name, f.length(), f.lastModified()) { fileHasRealSave(f) }
        }
    }
    try {
        dataSubfolder("save")?.listFiles()?.forEach { doc ->
            val n = doc.name ?: return@forEach
            if (doc.isFile) noteSiblingFile(found, prefix, ownCrc, n, doc.length(), doc.lastModified()) { true }
        }
    } catch (e: Exception) {
        Log.w(TAG, "Storage-folder sibling scan skipped", e)
    }
    val best = found.entries.maxByOrNull { it.value.newest } ?: return null
    return SaveSibling("${prefix}${best.key}", best.key, best.value.newest)
}

/** One hop only: if [key] is itself linked to a third version whose files still exist, point at THAT. */
private fun MainActivity.finalAliasKey(prefs: android.content.SharedPreferences, key: String): String {
    val next = prefs.getString(saveAliasPrefKey(key), null)
    return if (next != null && next != key && saveFilesExist(next)) next else key
}

/**
 * The key this ROM's saves go under: its own ([ownKey]) unless an alias says otherwise. Called by
 * loadRomFromUri() on its LOADER THREAD, right after migrateLegacyRomFiles(), and may block on a dialog — never
 * call it on the main thread.
 *
 *  1. An alias exists and files under "<aliasKey>." are still there -> use it. Otherwise it is stale: dropped.
 *  2. Not declined, and this ROM has no real battery save of its own yet (.sav missing, empty, or all 0x00 /
 *     all 0xFF) -> look for another version with saves (findSaveSibling()); if there is one, ask:
 *       "Use same saves" -> store the alias, use that key;  "Keep separate" -> store "declined", own key;
 *       "Not now" / Back / tap outside -> own key for THIS load only, nothing stored.
 *  3. Otherwise the own key — exactly the behaviour from before this feature.
 */
internal fun MainActivity.resolveSaveKey(uri: Uri, ownKey: String): String {
    return try {
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val aliasPref = saveAliasPrefKey(ownKey)
        val declinedPref = saveAliasDeclinedPrefKey(ownKey)

        val alias = prefs.getString(aliasPref, null)
        if (alias != null) {
            if (alias != ownKey && saveFilesExist(alias)) return alias
            prefs.edit().remove(aliasPref).apply()   // stale: the files it pointed at are gone
        }
        if (prefs.getBoolean(declinedPref, false)) return ownKey
        if (hasRealBatterySave(ownKey)) return ownKey

        // A name-only key (the CRC could not be computed) has no "different crc" to compare — nothing to offer.
        val readable = romReadableName(uri)
        val ownCrc = ownKey.removePrefix("${readable}_")
        if (ownCrc.length != 8 || !ownCrc.all { it in '0'..'9' || it in 'a'..'f' }) return ownKey

        val sibling = findSaveSibling(readable, ownCrc) ?: return ownKey
        when (askUseSameSaves(sibling)) {
            SaveLinkChoice.USE_SAME -> {
                val target = finalAliasKey(prefs, sibling.key)
                if (target == ownKey) return ownKey
                prefs.edit().putString(aliasPref, target).remove(declinedPref).apply()
                target
            }
            SaveLinkChoice.KEEP_SEPARATE -> {
                prefs.edit().putBoolean(declinedPref, true).apply()
                ownKey
            }
            SaveLinkChoice.NOT_NOW -> ownKey
        }
    } catch (e: Exception) {
        Log.w(TAG, "save-link lookup failed — using this ROM's own saves", e)
        ownKey
    }
}

/**
 * The "Same game, different version?" question. Runs on the UI thread, while the caller — the ROM loader
 * thread — waits for the answer on a latch that EVERY way out of the dialog releases (a button, Back, a tap
 * outside, and any exception while showing it). The wait is a loop of 500 ms slices that gives up as "Not now"
 * once the activity is finishing or destroyed, so a vanished dialog can never leave the loader hanging.
 */
private fun MainActivity.askUseSameSaves(sibling: SaveSibling): SaveLinkChoice {
    // Waiting here would block the very thread that has to show the dialog. Only ever called from the loader
    // thread (resolveSaveKey()); if that ever changes, fail safe instead of freezing the app.
    if (Looper.myLooper() == Looper.getMainLooper()) return SaveLinkChoice.NOT_NOW
    val latch = CountDownLatch(1)
    val answer = AtomicReference(SaveLinkChoice.NOT_NOW)
    runOnUiThread {
        try {
            if (isFinishing || isDestroyed) {
                latch.countDown()
                return@runOnUiThread
            }
            val ctx = this
            val date = DateFormat.getMediumDateFormat(ctx).format(java.util.Date(sibling.lastModified))
            val body = ctx.dialogContentLayout().apply {
                addView(TextView(ctx).apply {
                    text = "Found saves from another version of this ROM (${sibling.crc}, last played $date). " +
                        "Use the same saves? In-game saves are safe; save states from another version can glitch " +
                        "if the patch changed game code. Your current files for this version are kept untouched."
                    textSize = 14f
                    setTextColor(Color.WHITE)
                })
            }
            val dlg = AlertDialog.Builder(ctx)
                .setTitle("Same game, different version?")
                .setView(ScrollView(ctx).apply { addView(body) })
                .setPositiveButton("Use same saves") { _, _ -> answer.set(SaveLinkChoice.USE_SAME) }
                .setNegativeButton("Keep separate") { _, _ -> answer.set(SaveLinkChoice.KEEP_SEPARATE) }
                .setNeutralButton("Not now") { _, _ -> answer.set(SaveLinkChoice.NOT_NOW) }
                .setOnCancelListener { answer.set(SaveLinkChoice.NOT_NOW) }   // Back / tap outside
                .setOnDismissListener { latch.countDown() }                   // fires on every way out
                .create()
            dlg.window?.setBackgroundDrawable(roundedDialogBackground())
            dlg.show()
        } catch (t: Throwable) {
            Log.w(TAG, "save-link dialog failed", t)
            latch.countDown()
        }
    }
    while (!latch.await(500, TimeUnit.MILLISECONDS)) {
        if (isFinishing || isDestroyed) return SaveLinkChoice.NOT_NOW
    }
    return answer.get()
}

/** What Settings -> Storage shows in its "Saves for this ROM" row. */
internal class SaveLinkStatus(val linkedCrc: String?, val unlinkedPending: Boolean)

/** null when no game is loaded. [linkedCrc] != null: this ROM is using another version's saves right now.
 *  [unlinkedPending]: it still is, but the link has been removed — applies the next time the ROM is loaded. */
internal fun MainActivity.currentSaveLinkStatus(): SaveLinkStatus? {
    if (!romLoaded || currentRomOwnKey.isEmpty()) return null
    val usingOtherKey = currentRomBaseName != currentRomOwnKey
    if (!usingOtherKey) return SaveLinkStatus(null, false)
    val alias = getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(saveAliasPrefKey(currentRomOwnKey), null)
    val crc = currentRomBaseName.substringAfterLast('_')
    return if (alias != null) SaveLinkStatus(crc, false) else SaveLinkStatus(crc, true)
}

/** Settings -> Storage -> Unlink: removes the alias and records "declined" so the first-load question does not
 *  come back. Files are untouched; the game keeps using the linked saves until it is loaded again. */
internal fun MainActivity.unlinkSavesForCurrentRom() {
    val own = currentRomOwnKey
    if (own.isEmpty()) return
    getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
        .remove(saveAliasPrefKey(own))
        .putBoolean(saveAliasDeclinedPrefKey(own), true)
        .apply()
}
