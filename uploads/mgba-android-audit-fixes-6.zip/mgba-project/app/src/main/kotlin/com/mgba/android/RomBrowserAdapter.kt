package com.mgba.android

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.drawable.GradientDrawable
import android.text.Spannable
import android.text.SpannableString
import android.text.TextUtils
import android.text.format.DateUtils
import android.text.format.Formatter
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File

private const val KIND_FOLDER = 0
private const val KIND_ROM = 1
private const val KIND_ZIP = 2

/** Backs the ROM browser's ListView (audit-fix pass 5; row design refreshed in the
 *  file-manager UI pass).
 *
 *  The old screen built one View tree per directory entry up front inside a
 *  ScrollView: a folder with a few thousand files meant a few thousand
 *  eagerly-inflated rows, all measured and held in memory at once. A
 *  ListView only ever creates the handful of rows that fit on screen and
 *  recycles them as you scroll — and it gets fast-scroll for free. It's the
 *  platform's own list, deliberately: RecyclerView would be one more
 *  dependency in build.gradle.kts for what is a flat, single-type list.
 *
 *  Rows carry no click handling or background of their own — the ListView
 *  owns item clicks (and long-presses) and draws the press ripple through its
 *  selector (see RomBrowserActivity.buildUi()). A clickable row would swallow
 *  the tap before onItemClick ever fired.
 *
 *  A row is a tile (a drawn glyph on a small rounded square, coloured by kind —
 *  see [BrowserStyle]), the file's name without its extension, and one line of
 *  "type · size · date". The extension is dropped from the title because the
 *  tile and the type tag already say it; the full name is still what a
 *  long-press shows and what the filter matches against. */
internal class RomBrowserAdapter(private val ctx: Context) : BaseAdapter() {

    private var items: List<BrowserEntry> = emptyList()

    // The text typed in the filter box, so the matching part of each title can
    // be tinted. Blank when nothing is being filtered.
    private var highlight: String = ""

    // The size/date text is the only per-row work that isn't trivial
    // (locale-aware formatting), and ListView calls getView() constantly
    // while scrolling, so each subtitle is built once per listing.
    private val subtitles = HashMap<File, String>()

    fun submit(newItems: List<BrowserEntry>, query: String = "") {
        items = newItems
        highlight = query.trim()
        subtitles.clear()
        notifyDataSetChanged()
    }

    override fun getCount(): Int = items.size

    override fun getItem(position: Int): BrowserEntry = items[position]

    override fun getItemId(position: Int): Long = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val row = convertView as? RowView ?: RowView(ctx)
        val entry = items[position]
        row.bind(entry, subtitleFor(entry), highlight)
        return row
    }

    private fun subtitleFor(e: BrowserEntry): String = subtitles.getOrPut(e.file) {
        val parts = ArrayList<String>(3)
        if (!e.isDirectory) {
            parts.add(if (e.isZip) "ZIP" else "GBA")
            parts.add(Formatter.formatShortFileSize(ctx, e.sizeBytes))
        }
        if (e.modifiedMs > 0L) {
            parts.add(
                DateUtils.formatDateTime(
                    ctx, e.modifiedMs,
                    DateUtils.FORMAT_SHOW_DATE or DateUtils.FORMAT_ABBREV_MONTH or DateUtils.FORMAT_SHOW_YEAR
                )
            )
        }
        parts.joinToString(" · ")
    }

    private class RowView(ctx: Context) : LinearLayout(ctx) {
        private val tileFill = GradientDrawable()
        private val glyph = ImageView(ctx)
        private val title = TextView(ctx)
        private val subtitle = TextView(ctx)
        private val chevron = ImageView(ctx)
        private var boundKind = -1

        init {
            orientation = LinearLayout.VERTICAL

            // ── Leading tile: a rounded square holding the glyph ──────────
            tileFill.shape = GradientDrawable.RECTANGLE
            tileFill.cornerRadius = ctx.dp(11).toFloat()
            val tile = FrameLayout(ctx)
            tile.background = tileFill
            glyph.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            tile.addView(glyph, FrameLayout.LayoutParams(ctx.dp(22), ctx.dp(22), Gravity.CENTER))

            // ── Name + one line of details ────────────────────────────────
            // Two lines for a long ROM name ("Pokemon - Emerald Version
            // (USA, Europe) (Rev 1)") instead of cutting it off at one.
            title.textSize = 15f
            title.typeface = BrowserStyle.medium
            title.setTextColor(BrowserStyle.textPrimary)
            title.maxLines = 2
            title.ellipsize = TextUtils.TruncateAt.END
            subtitle.textSize = 12f
            subtitle.setTextColor(BrowserStyle.textSecondary)
            subtitle.maxLines = 1
            subtitle.ellipsize = TextUtils.TruncateAt.END
            subtitle.setPadding(0, ctx.dp(2), 0, 0)
            val textColumn = LinearLayout(ctx)
            textColumn.orientation = LinearLayout.VERTICAL
            textColumn.addView(title)
            textColumn.addView(subtitle)

            chevron.setImageResource(R.drawable.ic_fm_chevron)
            chevron.imageTintList = ColorStateList.valueOf(BrowserStyle.textTertiary)
            chevron.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO

            val content = LinearLayout(ctx)
            content.orientation = LinearLayout.HORIZONTAL
            content.gravity = Gravity.CENTER_VERTICAL
            content.minimumHeight = ctx.dp(64)
            content.setPadding(ctx.dp(16), ctx.dp(8), ctx.dp(10), ctx.dp(8))
            content.addView(tile, LinearLayout.LayoutParams(ctx.dp(40), ctx.dp(40)))
            content.addView(
                textColumn,
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginStart = ctx.dp(14)
                    marginEnd = ctx.dp(6)
                }
            )
            content.addView(chevron, LinearLayout.LayoutParams(ctx.dp(20), ctx.dp(20)))

            // A hairline under the text (not under the tile), as most file managers draw it.
            val divider = View(ctx)
            divider.setBackgroundColor(BrowserStyle.hairline)

            addView(content, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
            addView(divider, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1).apply {
                marginStart = ctx.dp(70)
            })
        }

        fun bind(entry: BrowserEntry, subtitleText: String, query: String) {
            val kind = when {
                entry.isDirectory -> KIND_FOLDER
                entry.isZip -> KIND_ZIP
                else -> KIND_ROM
            }
            // The tile only changes when a recycled row switches kind.
            if (kind != boundKind) {
                boundKind = kind
                val glyphColor: Int
                val tileColor: Int
                val glyphRes: Int
                when (kind) {
                    KIND_FOLDER -> {
                        glyphRes = R.drawable.ic_fm_folder
                        glyphColor = BrowserStyle.folderGlyph
                        tileColor = BrowserStyle.folderTile
                    }
                    KIND_ZIP -> {
                        glyphRes = R.drawable.ic_fm_archive
                        glyphColor = BrowserStyle.zipGlyph
                        tileColor = BrowserStyle.zipTile
                    }
                    else -> {
                        glyphRes = R.drawable.ic_fm_cartridge
                        glyphColor = BrowserStyle.romGlyph
                        tileColor = BrowserStyle.romTile
                    }
                }
                glyph.setImageResource(glyphRes)
                glyph.imageTintList = ColorStateList.valueOf(glyphColor)
                tileFill.setColor(tileColor)
                chevron.visibility = if (kind == KIND_FOLDER) View.VISIBLE else View.GONE
            }

            // Folders keep their whole name ("v1.5" is not an extension); files
            // show the name without ".gba" / ".zip".
            title.text = highlighted(if (entry.isDirectory) entry.name else entry.sortStem, query)
            subtitle.text = subtitleText
            subtitle.visibility = if (subtitleText.isEmpty()) View.GONE else View.VISIBLE
            contentDescription = when {
                entry.isDirectory -> "${entry.name}, folder"
                subtitleText.isNotEmpty() -> "${entry.name}, $subtitleText"
                else -> entry.name
            }
        }

        /** [text] with the first occurrence of [query] tinted in the accent colour. */
        private fun highlighted(text: String, query: String): CharSequence {
            if (query.isEmpty()) return text
            val at = text.indexOf(query, ignoreCase = true)
            if (at < 0) return text
            val span = SpannableString(text)
            span.setSpan(
                ForegroundColorSpan(BrowserStyle.accent),
                at, at + query.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            return span
        }
    }
}
