package com.mgba.android

import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.text.InputType
import android.util.Log
import android.view.Gravity
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

// ── Cheats ────────────────────────────────────────────────────────────────
//
// FEATURE (direct report: "implement cheat" — the ▤ menu's Cheats row used to say "not implemented yet").
//
// The cheat ENGINE is mGBA's own (GameShark / Action Replay v1-v3 / CodeBreaker, including master-code
// hooks): see the "Cheats" block in mgba_jni.c. Once a set is handed to the core it applies it itself, once
// per frame, for as long as the game runs. All this file does is the part around it:
//
//   • a per-game list (name, code lines, code type, on/off) kept in filesDir/cheats/<game>.json;
//   • a list screen (tap a cheat to switch it on/off, ⋮ to edit or delete) and an add/edit screen that
//     accepts pasted codes — several cheats at once if each name sits on its own line above its codes
//     (or "# name" as in mGBA's own .cheats files);
//   • re-applying the list whenever it changes and after every ROM load / reset, because a freshly built core
//     starts with no cheats (see applyCheatsToCore()).
//
// Only ENABLED cheats are handed to the core. The list screen shows a warning under any enabled cheat whose
// lines the core did not accept (most often the wrong code type — GameShark v3 and Action Replay v3 codes
// are encrypted and must be told apart from the plain ones).

internal val CHEAT_TYPE_LABELS = arrayOf(
    "Auto-detect",
    "GameShark v3 (encrypted)",
    "Action Replay v3 (encrypted)",
    "CodeBreaker"
)

/** One cheat in a game's list. [codes] holds one code per line, already normalised to the form mGBA's parser
 *  takes ("XXXXXXXX YYYYYYYY" or "XXXXXXXX YYYY"); [type] indexes [CHEAT_TYPE_LABELS] and is what
 *  EmulatorEngine.nativeCheatAdd() expects. */
internal class CheatEntry(var name: String, var codes: String, var type: Int, var enabled: Boolean) {
    fun codeLines(): List<String> = codes.split('\n').map { it.trim() }.filter { it.isNotEmpty() }
}

/** The codes found under one name by [parseCheatText]; [name] is null when the text gave none. */
internal class ParsedCheat(val name: String?, val lines: MutableList<String>)

/** [cheats] are the groups found; [badLines] are lines that look like a code (8+ hex digits) but aren't 12
 *  or 16 digits long — reported to the person instead of being silently taken for a name. */
internal class CheatParseResult(val cheats: List<ParsedCheat>, val badLines: List<String>)

private val CHEAT_CODE_CHARS = Regex("[0-9A-Fa-f\\s:\\-+]+")

/** The hex digits of [line] (upper-case) when the line is made only of hex digits and separators, else null. */
private fun cheatHexDigits(line: String): String? {
    if (!CHEAT_CODE_CHARS.matches(line)) return null
    val hex = line.filter { it.isLetterOrDigit() }.uppercase()
    return if (hex.isEmpty()) null else hex
}

/** "82025B4C 0063", "82025B4C-0063", "82025B4C0063" and "82025B4C:0063" all become "82025B4C 0063".
 *  16 digits is a GameShark / Action Replay code, 12 a CodeBreaker one; anything else is not a code. */
internal fun normalizeCheatCode(line: String): String? {
    val hex = cheatHexDigits(line.trim()) ?: return null
    return if (hex.length == 16 || hex.length == 12) hex.substring(0, 8) + " " + hex.substring(8) else null
}

/** Splits pasted text into cheats. A line of code belongs to the cheat above it; a line of plain text (or
 *  "# name") starts a new one and names it; "//" and ";" lines are comments, and a trailing ";" or "//" after
 *  a code is ignored. */
internal fun parseCheatText(text: String): CheatParseResult {
    val cheats = ArrayList<ParsedCheat>()
    val bad = ArrayList<String>()
    var cur: ParsedCheat? = null
    var pendingName: String? = null
    for (rawLine in text.split('\n')) {
        var line = rawLine.trim()
        if (line.isEmpty()) continue
        if (line.startsWith("//") || line.startsWith(";")) continue
        if (line.startsWith("#")) {
            val n = line.trimStart('#').trim()
            pendingName = if (n.isEmpty()) null else n
            cur = null
            continue
        }
        val semi = line.indexOf(';')
        if (semi > 0) line = line.substring(0, semi).trim()
        val slashes = line.indexOf("//")
        if (slashes > 0) line = line.substring(0, slashes).trim()

        val code = normalizeCheatCode(line)
        if (code != null) {
            val target: ParsedCheat = cur ?: ParsedCheat(pendingName, ArrayList<String>()).also {
                cheats.add(it)
                cur = it
                pendingName = null
            }
            target.lines.add(code)
        } else {
            val hex = cheatHexDigits(line)
            if (hex != null && hex.length >= 8) {
                bad.add(line)                 // looks like a code, but the digit count is wrong
            } else {
                pendingName = line            // plain text: the name of the codes that follow
                cur = null
            }
        }
    }
    return CheatParseResult(cheats, bad)
}

// ── Storage ─────────────────────────────────────────────────────────────────

/** filesDir/cheats/<game>.json — one file per game, named after the loaded ROM the same way its save is. */
private fun MainActivity.cheatsFile(): File {
    val dir = File(filesDir, "cheats")
    if (!dir.isDirectory) dir.mkdirs()
    val safe = currentRomBaseName.replace(Regex("[^A-Za-z0-9._ \\-]"), "_").trim().take(80).ifEmpty { "rom" }
    return File(dir, "$safe.json")
}

/** The current game's cheats (empty when it has none, or the file can't be read). */
internal fun MainActivity.loadCheats(): MutableList<CheatEntry> {
    val out = ArrayList<CheatEntry>()
    try {
        val f = cheatsFile()
        if (!f.isFile) return out
        val arr = JSONObject(f.readText(Charsets.UTF_8)).optJSONArray("cheats") ?: return out
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            out.add(
                CheatEntry(
                    o.optString("n", "Cheat ${i + 1}"),
                    o.optString("c", ""),
                    o.optInt("t", 0).coerceIn(0, CHEAT_TYPE_LABELS.size - 1),
                    o.optBoolean("e", true)
                )
            )
        }
    } catch (e: Exception) {
        Log.w(TAG, "cheat list unreadable", e)
    }
    return out
}

internal fun MainActivity.saveCheats(list: List<CheatEntry>) {
    try {
        val f = cheatsFile()
        if (list.isEmpty()) {
            f.delete()
            return
        }
        val arr = JSONArray()
        for (c in list) {
            arr.put(JSONObject().put("n", c.name).put("c", c.codes).put("t", c.type).put("e", c.enabled))
        }
        val text = JSONObject().put("v", 1).put("game", currentRomBaseName).put("cheats", arr).toString()
        val tmp = File(f.parentFile, f.name + ".tmp")
        tmp.writeText(text, Charsets.UTF_8)
        if (!tmp.renameTo(f)) {
            f.writeText(text, Charsets.UTF_8)
            tmp.delete()
        }
    } catch (e: Exception) {
        Log.w(TAG, "cheat list not saved", e)
        uiToast("Couldn't save the cheat list: ${e.message ?: e.javaClass.simpleName}")
    }
}

/**
 * Rebuilds the running core's cheats from [list] (default: the current game's saved list). Called when the
 * list changes and after every ROM load / reset. Returns one value per entry: -2 = not handed to the core
 * (switched off, or no code lines), -1 = the core couldn't take it, otherwise the nativeCheatAdd() result
 * (bits 0-15 lines accepted, bits 16-30 first rejected line).
 */
internal fun MainActivity.applyCheatsToCore(list: List<CheatEntry> = loadCheats()): IntArray {
    val results = IntArray(list.size) { -2 }
    try {
        EmulatorEngine.nativeCheatsClear()
        for (i in list.indices) {
            val c = list[i]
            if (!c.enabled) continue
            val lines = c.codeLines()
            if (lines.isEmpty()) continue
            results[i] = EmulatorEngine.nativeCheatAdd(c.name, lines.joinToString("\n"), c.type, true)
        }
    } catch (t: Throwable) {
        Log.e(TAG, "applying cheats failed", t)
    }
    return results
}

// ── Screens ─────────────────────────────────────────────────────────────────

/** The ▤ menu's Cheats screen. Every change is saved and applied to the running game straight away. */
internal fun MainActivity.showCheatsDialog() {
    if (!romLoaded) {
        uiToast("Load a game first")
        return
    }
    val ctx = this
    val cheats: MutableList<CheatEntry> = loadCheats()
    var results: IntArray = applyCheatsToCore(cheats)

    val listBox = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }

    fun commit() {
        saveCheats(cheats)
        results = applyCheatsToCore(cheats)
    }

    fun refresh() {
        listBox.removeAllViews()
        if (cheats.isEmpty()) {
            listBox.addView(TextView(ctx).apply {
                text = "No cheats for this game yet.\n\nTap \"Add cheat\" and paste GameShark, Action Replay or " +
                    "CodeBreaker codes. They are saved for this game and switched on whenever it runs."
                textSize = 14f
                setTextColor(Color.parseColor("#AAAAB4"))
                setPadding(dp(20), dp(16), dp(20), dp(16))
            })
            return
        }
        for (i in cheats.indices) {
            val c = cheats[i]
            if (i > 0) {
                listBox.addView(
                    videoDivider(),
                    LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1).coerceAtLeast(1))
                )
            }
            val r = if (i < results.size) results[i] else -2
            val rejectedLine = if (r >= 0) ((r ushr 16) and 0x7FFF) else 0
            val acceptedLines = if (r >= 0) (r and 0xFFFF) else 0
            val n = c.codeLines().size
            val base = "$n code${if (n == 1) "" else "s"} · ${CHEAT_TYPE_LABELS[c.type.coerceIn(0, CHEAT_TYPE_LABELS.size - 1)]}"
            var warn = false
            val subtitle: String = when {
                !c.enabled || r == -2 -> base
                r == -1 -> { warn = true; "⚠ Not applied — no game is running" }
                acceptedLines == 0 -> { warn = true; "⚠ No line was accepted — try another code type" }
                rejectedLine != 0 -> { warn = true; "⚠ Line $rejectedLine was not accepted — try another code type" }
                else -> base
            }

            val box = CheckBox(ctx).apply {
                isChecked = c.enabled
                isClickable = false      // the whole row is the tap target
                isFocusable = false
            }
            val textCol = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                addView(TextView(ctx).apply { text = c.name; textSize = 16f; setTextColor(Color.WHITE) })
                addView(TextView(ctx).apply {
                    text = subtitle
                    textSize = 12f
                    setTextColor(Color.parseColor(if (warn) "#FFB74D" else "#888892"))
                    setPadding(0, dp(2), 0, 0)
                })
            }
            val menuBtn = TextView(ctx).apply {
                text = "⋮"
                textSize = 22f
                gravity = Gravity.CENTER
                setTextColor(Color.parseColor("#C8C8D0"))
                setPadding(dp(14), dp(6), dp(14), dp(6))
                isClickable = true
                setOnClickListener {
                    val d = AlertDialog.Builder(ctx)
                        .setTitle(c.name)
                        .setItems(arrayOf("Edit", "Delete")) { _, which ->
                            if (which == 0) {
                                showCheatEditor(c) { edited ->
                                    val idx = cheats.indexOf(c)
                                    if (idx >= 0 && edited.isNotEmpty()) cheats[idx] = edited[0]
                                    commit()
                                    refresh()
                                }
                            } else {
                                cheats.remove(c)
                                commit()
                                refresh()
                            }
                        }
                        .create()
                    d.window?.setBackgroundDrawable(roundedDialogBackground())
                    d.show()
                }
            }
            listBox.addView(LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(16), dp(10), dp(4), dp(10))
                isClickable = true
                isFocusable = true
                setBackgroundResource(rippleBackgroundResId())
                setOnClickListener {
                    c.enabled = !c.enabled
                    commit()
                    refresh()
                }
                addView(box)
                addView(textCol, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    leftMargin = dp(6)
                })
                addView(menuBtn)
            })
        }
    }
    refresh()

    val dlg = AlertDialog.Builder(ctx)
        .setTitle("Cheats")
        .setView(ScrollView(ctx).apply { addView(listBox) })
        .setPositiveButton("Add cheat", null)
        .setNegativeButton("Done", null)
        .create()
    dlg.window?.setBackgroundDrawable(roundedDialogBackground())
    dlg.show()
    // Set after show() so tapping "Add cheat" opens the editor without closing this list.
    dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
        showCheatEditor(null) { added ->
            val firstNew = cheats.size
            var unnamed = firstNew
            for (e in added) {
                unnamed++
                if (e.name.isBlank()) e.name = "Cheat $unnamed"
            }
            cheats.addAll(added)
            commit()
            refresh()
            // Say so straight away when the core did not take the codes — the list shows it too, but a
            // fresh cheat that silently does nothing is the most confusing outcome there is.
            for (k in firstNew until cheats.size) {
                val r = if (k < results.size) results[k] else -2
                if (r >= 0 && ((r and 0xFFFF) == 0 || ((r ushr 16) and 0x7FFF) != 0)) {
                    uiToast("\"${cheats[k].name}\": the game core did not accept every line — try another code type")
                    break
                }
            }
        }
    }
}

/**
 * Add ([existing] = null) or edit one cheat. Pasted text may hold several cheats (a name on its own line above
 * each group of codes); [onSaved] gets one entry per cheat found — for an edit always exactly one. Names may
 * come back blank; the caller numbers those.
 */
internal fun MainActivity.showCheatEditor(existing: CheatEntry?, onSaved: (List<CheatEntry>) -> Unit) {
    val ctx = this
    var type = existing?.type ?: 0

    val nameField = EditText(ctx).apply {
        hint = "Name (optional), e.g. Infinite HP"
        setText(existing?.name ?: "")
        setTextColor(Color.WHITE)
        setHintTextColor(Color.parseColor("#77777F"))
        textSize = 15f
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        maxLines = 1
    }
    val codesField = EditText(ctx).apply {
        hint = "Codes, one per line\n82025B4C 0063"
        setText(existing?.codes ?: "")
        setTextColor(Color.WHITE)
        setHintTextColor(Color.parseColor("#77777F"))
        typeface = Typeface.MONOSPACE
        textSize = 14f
        minLines = 4
        gravity = Gravity.TOP or Gravity.START
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
            InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
    }
    val typeView = TextView(ctx).apply {
        textSize = 14f
        setTextColor(colorAccentLight)
        setPadding(0, dp(12), 0, dp(4))
        isClickable = true
    }
    fun refreshType() {
        typeView.text = "Code type: ${CHEAT_TYPE_LABELS[type]}  ▾"
    }
    refreshType()
    typeView.setOnClickListener {
        val d = AlertDialog.Builder(ctx)
            .setTitle("Code type")
            .setSingleChoiceItems(CHEAT_TYPE_LABELS, type) { dialog, which ->
                type = which
                refreshType()
                dialog.dismiss()
            }
            .create()
        d.window?.setBackgroundDrawable(roundedDialogBackground())
        d.show()
    }

    val body = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(20), dp(8), dp(20), dp(4))
        addView(nameField)
        addView(codesField, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(8) })
        addView(typeView)
        addView(TextView(ctx).apply {
            text = "Auto-detect handles plain GameShark / Action Replay codes and CodeBreaker. Pick GameShark v3 " +
                "or Action Replay v3 only for encrypted codes. To add several cheats at once, put each name on " +
                "its own line above its codes."
            textSize = 11f
            setTextColor(Color.parseColor("#888892"))
            setPadding(0, dp(6), 0, 0)
        })
    }

    val dlg = AlertDialog.Builder(ctx)
        .setTitle(if (existing == null) "Add cheat" else "Edit cheat")
        .setView(ScrollView(ctx).apply { addView(body) })
        .setPositiveButton("Save", null)
        .setNeutralButton("Paste", null)
        .setNegativeButton("Cancel", null)
        .create()
    dlg.window?.setBackgroundDrawable(roundedDialogBackground())
    dlg.show()

    dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        val clip = cm?.primaryClip
        val pasted = if (clip != null && clip.itemCount > 0) {
            clip.getItemAt(0).coerceToText(ctx)?.toString().orEmpty()
        } else ""
        if (pasted.isBlank()) {
            uiToast("The clipboard is empty")
        } else {
            val cur = codesField.text.toString()
            codesField.setText(if (cur.isBlank()) pasted else cur.trimEnd() + "\n" + pasted)
            codesField.setSelection(codesField.text.length)
        }
    }

    dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener save@{
        val parsed = parseCheatText(codesField.text.toString())
        if (parsed.badLines.isNotEmpty()) {
            uiToast("\"${parsed.badLines[0]}\" is not a valid code. A code is 12 or 16 hex digits, like 82025B4C 0063")
            return@save
        }
        if (parsed.cheats.isEmpty()) {
            uiToast("No codes found. A code looks like 82025B4C 0063")
            return@save
        }
        val typed = nameField.text.toString().trim()
        val out = ArrayList<CheatEntry>()
        if (existing != null) {
            // An edit stays ONE cheat, whatever the text now looks like.
            val lines = parsed.cheats.flatMap { it.lines }
            out.add(CheatEntry(typed.ifEmpty { existing.name }, lines.joinToString("\n"), type, existing.enabled))
        } else if (parsed.cheats.size == 1) {
            val p = parsed.cheats[0]
            out.add(CheatEntry(typed.ifEmpty { p.name ?: "" }, p.lines.joinToString("\n"), type, true))
        } else {
            for (k in parsed.cheats.indices) {
                val p = parsed.cheats[k]
                val nm = p.name ?: (if (typed.isNotEmpty()) "$typed ${k + 1}" else "")
                out.add(CheatEntry(nm, p.lines.joinToString("\n"), type, true))
            }
        }
        onSaved(out)
        dlg.dismiss()
    }
}
