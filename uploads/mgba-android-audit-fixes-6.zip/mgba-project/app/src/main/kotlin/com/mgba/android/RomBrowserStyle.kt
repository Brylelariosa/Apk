package com.mgba.android

import android.graphics.Color
import android.graphics.Typeface

/** Colours and type for the file manager (RomBrowserActivity + its list rows), in one
 *  place so the screen and the rows can't drift apart.
 *
 *  The window colour is the one the browser always had (#17171B). Everything else is
 *  built around the app icon's palette: the lavender of its cartridge is the single
 *  accent (current folder, search highlight, the sort glyph, the progress bar), and the
 *  three kinds of row each get their own quiet tile — neutral for folders, lavender for
 *  games, cyan for ZIP archives — so a long list can be scanned by colour alone. */
internal object BrowserStyle {
    // Surfaces
    val bg       = Color.parseColor("#17171B")
    val surface  = Color.parseColor("#202027")   // path bar, filter field, sort chip
    val hairline = Color.parseColor("#1AFFFFFF") // row dividers

    // Text
    val textPrimary   = Color.parseColor("#F4F2FA")
    val textSecondary = Color.parseColor("#9A98A8")
    val textTertiary  = Color.parseColor("#6C6A7A")

    // The one accent
    val accent    = Color.parseColor("#C9AEFF")
    val accentInk = Color.parseColor("#1B1236")  // text on a filled accent button

    // Row tiles: glyph colour + tile fill
    val folderGlyph = Color.parseColor("#B9B7C9")
    val folderTile  = Color.parseColor("#26262F")
    val romGlyph    = Color.parseColor("#C9AEFF")
    val romTile     = Color.parseColor("#2B2350")
    val zipGlyph    = Color.parseColor("#7FDDFF")
    val zipTile     = Color.parseColor("#14303B")

    /** A step between regular and bold for titles — no extra font files. */
    val medium: Typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
}
