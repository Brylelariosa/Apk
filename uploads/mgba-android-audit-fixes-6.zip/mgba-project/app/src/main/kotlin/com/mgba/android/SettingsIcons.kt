package com.mgba.android

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import kotlin.math.cos
import kotlin.math.sin

// ─────────────────────────────────────────────────────────────────────────
// FIX — direct report: "on setting there a lot of emoji stuff remove those
// add real button like vector." Every settings-menu row icon (and a
// couple of standalone row glyphs elsewhere — Layouts' delete row,
// Storage's folder-picker button) used a plain emoji character, which
// renders as a full-color pictograph pulled from the system's own emoji
// font — completely different visual language from the rest of this
// app's controls, which are all hand-drawn stroke-only vector shapes (see
// MainActivityControlLayout.kt's drawOutlineButton()/drawActionButtonIcon()
// for the controller overlay's own version of the same idea). This file
// is that same approach adapted for ordinary Android Views (Settings is
// built from LinearLayout/TextView/AlertDialog, not the game's own
// per-frame Canvas), so a Settings row's icon and a controller button's
// icon are drawn by the same hand, just through two different entry
// points (one a live game Canvas, one a small View's onDraw).
//
// Dialog *titles* (showAudioSettings() etc.) and a few purely-decorative
// inline glyphs (the ↺ reset/undo arrows) are deliberately left alone:
// those are Unicode symbols with a plain, monochrome default rendering
// already, not the colorful emoji-block pictographs this fix targets —
// see this app's other ⚙/✕ glyphs, already exactly the "real button, not
// emoji" look this report is asking for. Only the actual emoji go away;
// a matching vector glyph replaces each one that anchored an interactive
// row (a settings-menu entry, a delete/choose-folder action).
// ─────────────────────────────────────────────────────────────────────────

// REDRAW (direct report: "improve the icon like the advanced icon, all of them for
// setting"): the nine Settings-row glyphs (Video, Audio, Input, Layouts, Gameplay,
// Storage, Advanced, Debug, About) were redrawn to be bolder and easier to tell
// apart. Advanced is now a gear (it used to be two slider lines that looked like
// Gameplay's), Gameplay a joystick, Storage a folder, Debug a bug. CLOSE is a plain
// X for the Settings header's Close button. Same hand-drawn, no-resources approach.

internal enum class SettingsGlyph {
    VIDEO, AUDIO, GAMEPAD, LAYOUTS, MISC, STORAGE, WIFI, BLUETOOTH, ADVANCED, DEBUG, INFO, CLOSE,
    TRASH, EDIT, PLAY, PAUSE, SHUFFLE, NEXT, STOP
}

// Outline of one gear tooth, used by SettingsGlyph.ADVANCED in SettingsIconView.onDraw():
// angle offsets from the tooth's centre (radians) and radii (in units of the icon's
// half-size s) for its four points: base, tip, tip, base.
private val GEAR_DA = floatArrayOf(-0.24f, -0.15f, 0.15f, 0.24f)
private val GEAR_R = floatArrayOf(0.72f, 0.98f, 0.98f, 0.72f)

/** A single small vector glyph, drawn fresh in onDraw() rather than
 *  loaded from a drawable resource — this app has no drawable icon
 *  resources at all (see MainActivityControlLayout.kt's own equivalent),
 *  everything is hand-drawn shapes, so a Settings icon follows the same
 *  convention instead of introducing a second, bitmap/XML-drawable-based
 *  icon system alongside it. Square by construction: draws into
 *  whatever box the caller's LayoutParams give it, centered, with a
 *  fixed proportion of padding — callers just need to size the View,
 *  never the glyph coordinates themselves. */
internal class SettingsIconView(
    context: Context,
    glyph: SettingsGlyph,
    tint: Int = colorAccentLight
) : View(context) {

    private var glyph: SettingsGlyph = glyph

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = context.dp(2).toFloat().coerceAtLeast(2f)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = tint
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = tint }
    private val scratchRect = RectF()
    private val scratchPath = Path()

    /** Swaps the tint at runtime — used for the music-control row (play/
     *  pause and shuffle need to reflect live playback state) rather than
     *  rebuilding the View. */
    fun setTint(color: Int) {
        paint.color = color
        fillPaint.color = color
        invalidate()
    }

    /** Swaps the glyph itself at runtime — the music row's Play/Pause
     *  button is one View whose shape flips with playback state, rather
     *  than two Views swapped in and out. */
    fun setGlyph(newGlyph: SettingsGlyph) {
        glyph = newGlyph
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val s = minOf(width, height) / 2f * 0.72f
        if (s <= 0f) return
        when (glyph) {
            SettingsGlyph.VIDEO -> {
                // Monitor with a play mark: screen, neck, base.
                canvas.drawRoundRect(cx - s, cy - s * 0.86f, cx + s, cy + s * 0.4f, s * 0.24f, s * 0.24f, paint)
                canvas.drawLine(cx, cy + s * 0.4f, cx, cy + s * 0.7f, paint)
                canvas.drawLine(cx - s * 0.52f, cy + s * 0.86f, cx + s * 0.52f, cy + s * 0.86f, paint)
                scratchPath.reset()
                scratchPath.moveTo(cx - s * 0.2f, cy - s * 0.5f)
                scratchPath.lineTo(cx + s * 0.4f, cy - s * 0.23f)
                scratchPath.lineTo(cx - s * 0.2f, cy + s * 0.04f)
                scratchPath.close()
                canvas.drawPath(scratchPath, fillPaint)
            }
            SettingsGlyph.AUDIO -> {
                // Speaker cone plus two sound-wave arcs.
                scratchPath.reset()
                scratchPath.moveTo(cx - s, cy - s * 0.3f)
                scratchPath.lineTo(cx - s * 0.58f, cy - s * 0.3f)
                scratchPath.lineTo(cx - s * 0.02f, cy - s * 0.82f)
                scratchPath.lineTo(cx - s * 0.02f, cy + s * 0.82f)
                scratchPath.lineTo(cx - s * 0.58f, cy + s * 0.3f)
                scratchPath.lineTo(cx - s, cy + s * 0.3f)
                scratchPath.close()
                canvas.drawPath(scratchPath, paint)
                scratchRect.set(cx - s * 0.48f, cy - s * 0.5f, cx + s * 0.52f, cy + s * 0.5f)
                canvas.drawArc(scratchRect, -42f, 84f, false, paint)
                scratchRect.set(cx - s * 0.9f, cy - s * 0.92f, cx + s * 0.94f, cy + s * 0.92f)
                canvas.drawArc(scratchRect, -42f, 84f, false, paint)
            }
            SettingsGlyph.GAMEPAD -> {
                // Controller silhouette (two grips), d-pad on the left, two face buttons on the right.
                scratchPath.reset()
                scratchPath.moveTo(cx - s * 0.5f, cy - s * 0.7f)
                scratchPath.lineTo(cx + s * 0.5f, cy - s * 0.7f)
                scratchPath.cubicTo(cx + s * 0.84f, cy - s * 0.7f, cx + s, cy - s * 0.44f, cx + s, cy - s * 0.1f)
                scratchPath.cubicTo(cx + s, cy + s * 0.22f, cx + s * 0.98f, cy + s * 0.5f, cx + s * 0.9f, cy + s * 0.68f)
                scratchPath.cubicTo(cx + s * 0.82f, cy + s * 0.9f, cx + s * 0.54f, cy + s * 0.9f, cx + s * 0.47f, cy + s * 0.68f)
                scratchPath.cubicTo(cx + s * 0.42f, cy + s * 0.52f, cx + s * 0.36f, cy + s * 0.42f, cx + s * 0.22f, cy + s * 0.42f)
                scratchPath.lineTo(cx - s * 0.22f, cy + s * 0.42f)
                scratchPath.cubicTo(cx - s * 0.36f, cy + s * 0.42f, cx - s * 0.42f, cy + s * 0.52f, cx - s * 0.47f, cy + s * 0.68f)
                scratchPath.cubicTo(cx - s * 0.54f, cy + s * 0.9f, cx - s * 0.82f, cy + s * 0.9f, cx - s * 0.9f, cy + s * 0.68f)
                scratchPath.cubicTo(cx - s * 0.98f, cy + s * 0.5f, cx - s, cy + s * 0.22f, cx - s, cy - s * 0.1f)
                scratchPath.cubicTo(cx - s, cy - s * 0.44f, cx - s * 0.84f, cy - s * 0.7f, cx - s * 0.5f, cy - s * 0.7f)
                scratchPath.close()
                canvas.drawPath(scratchPath, paint)
                canvas.drawLine(cx - s * 0.5f, cy - s * 0.34f, cx - s * 0.5f, cy + s * 0.04f, paint)
                canvas.drawLine(cx - s * 0.69f, cy - s * 0.15f, cx - s * 0.31f, cy - s * 0.15f, paint)
                canvas.drawCircle(cx + s * 0.36f, cy - s * 0.3f, s * 0.13f, fillPaint)
                canvas.drawCircle(cx + s * 0.64f, cy - s * 0.02f, s * 0.13f, fillPaint)
            }
            SettingsGlyph.LAYOUTS -> {
                // Dashboard: one tall panel and two stacked panels.
                canvas.drawRoundRect(cx - s, cy - s * 0.95f, cx - s * 0.22f, cy + s * 0.95f, s * 0.16f, s * 0.16f, paint)
                canvas.drawRoundRect(cx + s * 0.22f, cy - s * 0.95f, cx + s, cy - s * 0.2f, s * 0.16f, s * 0.16f, paint)
                canvas.drawRoundRect(cx + s * 0.22f, cy + s * 0.2f, cx + s, cy + s * 0.95f, s * 0.16f, s * 0.16f, paint)
            }
            SettingsGlyph.MISC -> {
                // Gameplay: arcade joystick (ball, shaft, flared base).
                canvas.drawCircle(cx, cy - s * 0.58f, s * 0.38f, fillPaint)
                canvas.drawLine(cx, cy - s * 0.24f, cx, cy + s * 0.3f, paint)
                scratchPath.reset()
                scratchPath.moveTo(cx - s * 0.63f, cy + s * 0.42f)
                scratchPath.quadTo(cx - s * 0.55f, cy + s * 0.3f, cx - s * 0.41f, cy + s * 0.3f)
                scratchPath.lineTo(cx + s * 0.41f, cy + s * 0.3f)
                scratchPath.quadTo(cx + s * 0.55f, cy + s * 0.3f, cx + s * 0.63f, cy + s * 0.42f)
                scratchPath.lineTo(cx + s * 0.92f, cy + s * 0.84f)
                scratchPath.quadTo(cx + s, cy + s * 0.96f, cx + s * 0.86f, cy + s * 0.96f)
                scratchPath.lineTo(cx - s * 0.86f, cy + s * 0.96f)
                scratchPath.quadTo(cx - s, cy + s * 0.96f, cx - s * 0.92f, cy + s * 0.84f)
                scratchPath.close()
                canvas.drawPath(scratchPath, fillPaint)
            }
            SettingsGlyph.STORAGE -> {
                // Folder with a tab.
                scratchPath.reset()
                scratchPath.moveTo(cx - s, cy - s * 0.5f)
                scratchPath.quadTo(cx - s, cy - s * 0.66f, cx - s * 0.84f, cy - s * 0.66f)
                scratchPath.lineTo(cx - s * 0.46f, cy - s * 0.66f)
                scratchPath.quadTo(cx - s * 0.3f, cy - s * 0.66f, cx - s * 0.19f, cy - s * 0.54f)
                scratchPath.lineTo(cx - s * 0.07f, cy - s * 0.42f)
                scratchPath.quadTo(cx + s * 0.04f, cy - s * 0.3f, cx + s * 0.2f, cy - s * 0.3f)
                scratchPath.lineTo(cx + s * 0.84f, cy - s * 0.3f)
                scratchPath.quadTo(cx + s, cy - s * 0.3f, cx + s, cy - s * 0.14f)
                scratchPath.lineTo(cx + s, cy + s * 0.64f)
                scratchPath.quadTo(cx + s, cy + s * 0.8f, cx + s * 0.84f, cy + s * 0.8f)
                scratchPath.lineTo(cx - s * 0.84f, cy + s * 0.8f)
                scratchPath.quadTo(cx - s, cy + s * 0.8f, cx - s, cy + s * 0.64f)
                scratchPath.close()
                canvas.drawPath(scratchPath, paint)
            }
            SettingsGlyph.WIFI -> {
                canvas.drawCircle(cx, cy + s * 0.68f, s * 0.10f, fillPaint)
                for (i in 1..3) {
                    val r = s * 0.32f * i
                    scratchRect.set(cx - r, cy + s * 0.68f - r, cx + r, cy + s * 0.68f + r)
                    canvas.drawArc(scratchRect, 215f, 110f, false, paint)
                }
            }
            SettingsGlyph.BLUETOOTH -> {
                canvas.drawLine(cx, cy - s, cx, cy + s, paint)
                scratchPath.reset()
                scratchPath.moveTo(cx, cy - s)
                scratchPath.lineTo(cx + s * 0.55f, cy - s * 0.42f)
                scratchPath.lineTo(cx - s * 0.55f, cy + s * 0.42f)
                scratchPath.lineTo(cx, cy + s)
                canvas.drawPath(scratchPath, paint)
                scratchPath.reset()
                scratchPath.moveTo(cx, cy - s)
                scratchPath.lineTo(cx - s * 0.55f, cy - s * 0.42f)
                scratchPath.lineTo(cx + s * 0.55f, cy + s * 0.42f)
                scratchPath.lineTo(cx, cy + s)
                canvas.drawPath(scratchPath, paint)
            }
            SettingsGlyph.ADVANCED -> {
                // Gear: 8 teeth around a ring, with a hole in the middle. GEAR_DA / GEAR_R
                // give each tooth's four outline points (angle offset from the tooth's
                // centre, radius in units of s): base, tip, tip, base.
                scratchPath.reset()
                for (k in 0 until 8) {
                    val a = (2.0 * Math.PI * k / 8).toFloat()
                    for (j in 0..3) {
                        val ang = a + GEAR_DA[j]
                        val px = cx + s * GEAR_R[j] * cos(ang)
                        val py = cy + s * GEAR_R[j] * sin(ang)
                        if (k == 0 && j == 0) scratchPath.moveTo(px, py) else scratchPath.lineTo(px, py)
                    }
                }
                scratchPath.close()
                canvas.drawPath(scratchPath, paint)
                canvas.drawCircle(cx, cy, s * 0.30f, paint)
            }
            SettingsGlyph.DEBUG -> {
                // Bug: head, body with a centre seam, three legs and two antennae per side.
                canvas.drawCircle(cx, cy - s * 0.66f, s * 0.28f, paint)
                canvas.drawOval(cx - s * 0.56f, cy - s * 0.3f, cx + s * 0.56f, cy + s * 0.94f, paint)
                canvas.drawLine(cx, cy - s * 0.3f, cx, cy + s * 0.94f, paint)
                canvas.drawLine(cx - s * 0.54f, cy - s * 0.02f, cx - s, cy - s * 0.3f, paint)
                canvas.drawLine(cx + s * 0.54f, cy - s * 0.02f, cx + s, cy - s * 0.3f, paint)
                canvas.drawLine(cx - s * 0.58f, cy + s * 0.34f, cx - s, cy + s * 0.34f, paint)
                canvas.drawLine(cx + s * 0.58f, cy + s * 0.34f, cx + s, cy + s * 0.34f, paint)
                canvas.drawLine(cx - s * 0.5f, cy + s * 0.68f, cx - s * 0.94f, cy + s * 0.96f, paint)
                canvas.drawLine(cx + s * 0.5f, cy + s * 0.68f, cx + s * 0.94f, cy + s * 0.96f, paint)
                canvas.drawLine(cx - s * 0.12f, cy - s * 0.9f, cx - s * 0.36f, cy - s * 1.08f, paint)
                canvas.drawLine(cx + s * 0.12f, cy - s * 0.9f, cx + s * 0.36f, cy - s * 1.08f, paint)
            }
            SettingsGlyph.INFO -> {
                // Circled "i".
                canvas.drawCircle(cx, cy, s, paint)
                canvas.drawCircle(cx, cy - s * 0.44f, s * 0.13f, fillPaint)
                canvas.drawLine(cx, cy - s * 0.08f, cx, cy + s * 0.52f, paint)
            }
            SettingsGlyph.CLOSE -> {
                // Plain X, used by the Settings header's Close button.
                canvas.drawLine(cx - s * 0.7f, cy - s * 0.7f, cx + s * 0.7f, cy + s * 0.7f, paint)
                canvas.drawLine(cx + s * 0.7f, cy - s * 0.7f, cx - s * 0.7f, cy + s * 0.7f, paint)
            }
            SettingsGlyph.TRASH -> {
                canvas.drawLine(cx - s * 0.5f, cy - s * 0.75f, cx + s * 0.5f, cy - s * 0.75f, paint)
                canvas.drawLine(cx - s * 0.2f, cy - s * 0.9f, cx + s * 0.2f, cy - s * 0.9f, paint)
                canvas.drawRoundRect(cx - s * 0.65f, cy - s * 0.6f, cx + s * 0.65f, cy + s, s * 0.08f, s * 0.08f, paint)
                canvas.drawLine(cx - s * 0.25f, cy - s * 0.3f, cx - s * 0.25f, cy + s * 0.65f, paint)
                canvas.drawLine(cx + s * 0.25f, cy - s * 0.3f, cx + s * 0.25f, cy + s * 0.65f, paint)
            }
            SettingsGlyph.EDIT -> {
                // FIX (direct report: "there emoji on layout setting") —
                // replaces a literal "✎" pencil character (see
                // layoutPresetRow(), MainActivityLayoutPresets.kt) with a
                // hand-drawn one: a diagonal shaft, a small angled tip at
                // one end, and a short perpendicular cap at the other —
                // simple strokes, matching this file's own established
                // style (see e.g. BLUETOOTH just above) rather than a
                // filled pencil silhouette.
                canvas.drawLine(cx - s * 0.75f, cy + s * 0.75f, cx + s * 0.55f, cy - s * 0.55f, paint)
                canvas.drawLine(cx - s * 0.88f, cy + s * 0.62f, cx - s * 0.62f, cy + s * 0.88f, paint)
                canvas.drawLine(cx + s * 0.55f, cy - s * 0.55f, cx + s * 0.85f, cy - s * 0.30f, paint)
                canvas.drawLine(cx + s * 0.55f, cy - s * 0.55f, cx + s * 0.30f, cy - s * 0.85f, paint)
            }
            SettingsGlyph.PLAY -> {
                scratchPath.reset()
                scratchPath.moveTo(cx - s * 0.55f, cy - s * 0.8f)
                scratchPath.lineTo(cx + s * 0.85f, cy)
                scratchPath.lineTo(cx - s * 0.55f, cy + s * 0.8f)
                scratchPath.close()
                canvas.drawPath(scratchPath, fillPaint)
            }
            SettingsGlyph.PAUSE -> {
                canvas.drawRoundRect(cx - s * 0.75f, cy - s * 0.8f, cx - s * 0.2f, cy + s * 0.8f, s * 0.12f, s * 0.12f, fillPaint)
                canvas.drawRoundRect(cx + s * 0.2f, cy - s * 0.8f, cx + s * 0.75f, cy + s * 0.8f, s * 0.12f, s * 0.12f, fillPaint)
            }
            SettingsGlyph.STOP -> canvas.drawRoundRect(cx - s * 0.72f, cy - s * 0.72f, cx + s * 0.72f, cy + s * 0.72f, s * 0.14f, s * 0.14f, fillPaint)
            SettingsGlyph.NEXT -> {
                scratchPath.reset()
                scratchPath.moveTo(cx - s * 0.75f, cy - s * 0.8f)
                scratchPath.lineTo(cx + s * 0.15f, cy)
                scratchPath.lineTo(cx - s * 0.75f, cy + s * 0.8f)
                scratchPath.close()
                canvas.drawPath(scratchPath, fillPaint)
                canvas.drawRoundRect(cx + s * 0.35f, cy - s * 0.8f, cx + s * 0.62f, cy + s * 0.8f, s * 0.08f, s * 0.08f, fillPaint)
            }
            SettingsGlyph.SHUFFLE -> {
                scratchPath.reset()
                scratchPath.moveTo(cx - s, cy - s * 0.55f)
                scratchPath.lineTo(cx + s * 0.35f, cy - s * 0.55f)
                scratchPath.lineTo(cx + s * 0.85f, cy + s * 0.55f)
                canvas.drawPath(scratchPath, paint)
                scratchPath.reset()
                scratchPath.moveTo(cx - s, cy + s * 0.55f)
                scratchPath.lineTo(cx - s * 0.35f, cy + s * 0.55f)
                scratchPath.lineTo(cx + s * 0.85f, cy - s * 0.55f)
                canvas.drawPath(scratchPath, paint)
                val headSize = s * 0.22f
                canvas.drawLine(cx + s * 0.85f, cy + s * 0.55f, cx + s * 0.85f - headSize, cy + s * 0.55f - headSize * 0.4f, paint)
                canvas.drawLine(cx + s * 0.85f, cy + s * 0.55f, cx + s * 0.85f - headSize * 0.4f, cy + s * 0.55f - headSize, paint)
                canvas.drawLine(cx + s * 0.85f, cy - s * 0.55f, cx + s * 0.85f - headSize, cy - s * 0.55f + headSize * 0.4f, paint)
                canvas.drawLine(cx + s * 0.85f, cy - s * 0.55f, cx + s * 0.85f - headSize * 0.4f, cy - s * 0.55f + headSize, paint)
            }
        }
    }
}
