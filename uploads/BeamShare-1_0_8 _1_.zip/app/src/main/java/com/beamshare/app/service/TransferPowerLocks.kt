package com.beamshare.app.service

import android.content.Context
import android.net.wifi.WifiManager
import android.os.Build
import android.os.PowerManager

/**
 * Keeps the CPU and the WiFi radio out of power-save while a transfer is moving bytes.
 *
 * A foreground service stops the process being killed, but not the CPU napping or the radio dropping
 * into power-save the moment the screen turns off - which is exactly what throttles a long transfer
 * (and makes the last gigabytes crawl). Both locks are held only while something is actually
 * transferring, and the wake lock carries a timeout so a bug elsewhere can never pin it forever.
 */
internal class TransferPowerLocks(context: Context) {

    private val wakeLock: PowerManager.WakeLock?
    private val wifiLock: WifiManager.WifiLock?

    init {
        val app = context.applicationContext
        wakeLock = app.getSystemService(PowerManager::class.java)
            ?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "BeamShare:transfer")
            ?.apply { setReferenceCounted(false) }
        wifiLock = app.getSystemService(WifiManager::class.java)
            ?.createWifiLock(wifiLockMode(), "BeamShare:transfer")
            ?.apply { setReferenceCounted(false) }
    }

    /** Takes both locks; harmless to call again while they are already held. */
    fun acquire() {
        runCatching { wakeLock?.let { if (!it.isHeld) it.acquire(MAX_HOLD_MS) } }
        runCatching { wifiLock?.let { if (!it.isHeld) it.acquire() } }
    }

    fun release() {
        runCatching { wakeLock?.let { if (it.isHeld) it.release() } }
        runCatching { wifiLock?.let { if (it.isHeld) it.release() } }
    }

    @Suppress("DEPRECATION")
    private fun wifiLockMode(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            WifiManager.WIFI_MODE_FULL_LOW_LATENCY
        } else {
            WifiManager.WIFI_MODE_FULL_HIGH_PERF
        }

    private companion object {
        /** Longer than any single transfer; the lock is re-taken on the next progress update. */
        const val MAX_HOLD_MS = 2L * 60L * 60L * 1000L
    }
}
