package com.beamshare.app.core.transfer

import com.beamshare.app.core.files.FileIo
import com.beamshare.app.core.files.IncomingSink
import com.beamshare.app.core.model.TransferDirection
import com.beamshare.app.core.model.TransferFailure
import com.beamshare.app.core.model.TransferItem
import com.beamshare.app.core.model.TransferProgress
import com.beamshare.app.core.model.TransferState
import kotlinx.coroutines.CancellableContinuation
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.IOException
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap
import kotlin.coroutines.resume

/**
 * One live connection to a peer: handshake, offers, and file streaming in both directions.
 *
 * All blocking socket work runs on [Dispatchers.IO]. Writes are serialised by [writeMutex] so a
 * file stream is never interleaved with control frames, and exactly one coroutine ([readLoop])
 * ever reads from the socket.
 *
 * File bytes move through [PipelinedCopy] (storage and socket overlapped) and are reported through a
 * per-file [ProgressMeter], which is what keeps the speed readout honest and the UI cheap.
 *
 * @param approveIncomingImmediately the end that dialled out has implicitly agreed to the
 *  session; the end that was dialled holds incoming offers back until [approveIncoming] is called.
 */
class TransferSession(
    private val socket: Socket,
    private val fileIo: FileIo,
    private val sessionScope: CoroutineScope,
    approveIncomingImmediately: Boolean
) {
    private val input = DataInputStream(socket.getInputStream().buffered(TransferProtocol.IO_BUFFER_SIZE))
    private val output = DataOutputStream(socket.getOutputStream().buffered(TransferProtocol.IO_BUFFER_SIZE))
    private val writeMutex = Mutex()

    @Volatile
    private var incomingApproved = approveIncomingImmediately

    private val pendingAcks = ConcurrentHashMap<String, CancellableContinuation<Boolean>>()
    private val pendingOffers = ConcurrentHashMap<String, TransferProtocol.OfferPayload>()

    /** Why the peer turned an offer down, keyed by offer id, when it said. */
    private val declineReasons = ConcurrentHashMap<String, String>()

    private val _progress = MutableStateFlow<List<TransferProgress>>(emptyList())
    val progress: StateFlow<List<TransferProgress>> = _progress.asStateFlow()

    private val _peerHello = MutableStateFlow<TransferProtocol.Hello?>(null)
    /** The peer's greeting, once received. */
    val peerHello: StateFlow<TransferProtocol.Hello?> = _peerHello.asStateFlow()

    private val _peerReady = MutableStateFlow(false)
    /** True once the peer's user accepted this session (only meaningful for the end that dialled out). */
    val peerReady: StateFlow<Boolean> = _peerReady.asStateFlow()

    private val _closed = MutableStateFlow(false)
    val closed: StateFlow<Boolean> = _closed.asStateFlow()

    private var readJob: Job? = null

    /** Sends our greeting and starts reading. Call once. */
    fun start(localDeviceName: String) {
        readJob = sessionScope.launch(Dispatchers.IO) {
            try {
                sendFrame(TransferProtocol.TYPE_HELLO, TransferProtocol.encodeHello(localDeviceName))
                readLoop()
            } catch (e: Exception) {
                close()
            }
        }
    }

    /** Lets the peer send us files, and tells the dialling end the session is live. */
    fun approveIncoming() {
        incomingApproved = true
        sessionScope.launch(Dispatchers.IO) {
            try {
                sendFrame(TransferProtocol.TYPE_READY)
            } catch (e: Exception) {
                close()
            }
        }
    }

    /** Puts [items] in the progress list as QUEUED so the user sees everything that's coming. */
    fun enqueue(items: List<TransferItem>) {
        _progress.update { current ->
            current + items.filter { item -> current.none { it.itemId == item.id } }.map { item ->
                TransferProgress(
                    itemId = item.id,
                    name = item.displayName,
                    direction = TransferDirection.SEND,
                    totalBytes = item.sizeBytes,
                    state = TransferState.QUEUED,
                    isApk = item.isApk,
                    mimeType = item.mimeType
                )
            }
        }
    }

    /**
     * Offers [item], waits for the peer to accept, then streams it.
     * Returns normally for an accepted-and-finished or declined item; throws if the transfer broke.
     */
    suspend fun send(item: TransferItem) {
        enqueue(listOf(item))
        try {
            val accepted = withTimeoutOrNull(ACK_TIMEOUT_MS) { offerAndAwait(item) } ?: false
            if (!accepted) {
                val noSpace = declineReasons.remove(item.id) == TransferProtocol.REJECT_NO_SPACE
                mutate(item.id) {
                    it.copy(
                        state = TransferState.CANCELLED,
                        speedBytesPerSec = 0L,
                        failure = if (noSpace) TransferFailure.NO_SPACE else null
                    )
                }
                return
            }
            setState(item.id, TransferState.IN_PROGRESS)
            streamFileOut(item)
            setState(item.id, TransferState.COMPLETED)
        } catch (e: Exception) {
            markFailed(item.id, e)
            throw e
        }
    }

    private suspend fun offerAndAwait(item: TransferItem): Boolean = suspendCancellableCoroutine { cont ->
        pendingAcks[item.id] = cont
        cont.invokeOnCancellation { pendingAcks.remove(item.id) }
        sessionScope.launch(Dispatchers.IO) {
            try {
                val offer = TransferProtocol.OfferPayload(item.id, item.displayName, item.sizeBytes, item.mimeType, item.isApk)
                sendFrame(TransferProtocol.TYPE_OFFER, TransferProtocol.encodeOffer(offer))
            } catch (e: Exception) {
                pendingAcks.remove(item.id)?.resume(false)
                close()
            }
        }
    }

    private suspend fun sendFrame(type: Int, payload: ByteArray = ByteArray(0)) {
        writeMutex.withLock {
            withContext(Dispatchers.IO) { TransferProtocol.writeFrame(output, type, payload) }
        }
    }

    /**
     * Streams exactly [TransferItem.sizeBytes] raw bytes. The receiver reads that same count, so if
     * anything goes wrong once FILE_START is on the wire the stream can't be resynchronised and the
     * session is closed rather than left in an undefined state.
     */
    private suspend fun streamFileOut(item: TransferItem) = withContext(Dispatchers.IO) {
        // Open the source first: failing here leaves the wire untouched and the session usable.
        val source = fileIo.openInputStream(item)
        try {
            writeMutex.withLock {
                TransferProtocol.writeFrame(output, TransferProtocol.TYPE_FILE_START, item.id.toByteArray(Charsets.UTF_8))
                val meter = ProgressMeter()
                PipelinedCopy.copy(
                    source = source,
                    sink = output,
                    length = item.sizeBytes,
                    endedEarly = { SourceEndedEarlyException("${item.displayName} ended before its expected size") },
                    onAbort = { this@TransferSession.close() },
                    onWritten = { sent -> publishProgress(item.id, sent, meter) }
                )
                output.flush()
                TransferProtocol.writeFrame(output, TransferProtocol.TYPE_FILE_DONE, item.id.toByteArray(Charsets.UTF_8))
            }
        } catch (e: Exception) {
            close()
            throw e
        } finally {
            runCatching { source.close() }
        }
        mutate(item.id) { it.copy(transferredBytes = item.sizeBytes, speedBytesPerSec = 0L) }
    }

    private suspend fun readLoop() {
        try {
            while (true) {
                val frame = TransferProtocol.readFrame(input)
                when (frame.type) {
                    TransferProtocol.TYPE_HELLO -> _peerHello.value = TransferProtocol.decodeHello(frame.payload)
                    TransferProtocol.TYPE_READY -> _peerReady.value = true
                    TransferProtocol.TYPE_OFFER -> handleOffer(TransferProtocol.decodeOffer(frame.payload))
                    TransferProtocol.TYPE_ACCEPT -> pendingAcks.remove(idOf(frame))?.resume(true)
                    TransferProtocol.TYPE_REJECT -> {
                        val reject = TransferProtocol.decodeReject(frame.payload)
                        // Record why before waking the sender, so it reads the reason when it resumes.
                        reject.reason?.let { declineReasons[reject.id] = it }
                        pendingAcks.remove(reject.id)?.resume(false)
                    }
                    TransferProtocol.TYPE_FILE_START -> receiveFile(idOf(frame))
                    TransferProtocol.TYPE_FILE_DONE -> Unit
                    TransferProtocol.TYPE_CANCEL -> Unit
                    TransferProtocol.TYPE_BYE -> {
                        close()
                        return
                    }
                }
            }
        } catch (e: Exception) {
            close()
        }
    }

    private fun idOf(frame: TransferProtocol.Frame): String = String(frame.payload, Charsets.UTF_8)

    private suspend fun handleOffer(offer: TransferProtocol.OfferPayload) {
        if (!incomingApproved) {
            sendFrame(TransferProtocol.TYPE_REJECT, TransferProtocol.encodeReject(offer.id))
            return
        }

        // Turn a file away before it starts if it can't fit. Without this a 6 GB file onto a phone
        // with 4 GB free would stream happily until the storage filled, then die at "4 GB".
        val free = withContext(Dispatchers.IO) {
            runCatching { fileIo.availableBytes() }.getOrDefault(Long.MAX_VALUE)
        }
        if (offer.sizeBytes > free - SPACE_MARGIN_BYTES) {
            _progress.update { current ->
                current + TransferProgress(
                    itemId = offer.id,
                    name = offer.name,
                    direction = TransferDirection.RECEIVE,
                    totalBytes = offer.sizeBytes,
                    state = TransferState.FAILED,
                    isApk = offer.isApk,
                    mimeType = offer.mimeType,
                    failure = TransferFailure.NO_SPACE
                )
            }
            sendFrame(TransferProtocol.TYPE_REJECT, TransferProtocol.encodeReject(offer.id, TransferProtocol.REJECT_NO_SPACE))
            return
        }

        pendingOffers[offer.id] = offer
        _progress.update { current ->
            current + TransferProgress(
                itemId = offer.id,
                name = offer.name,
                direction = TransferDirection.RECEIVE,
                totalBytes = offer.sizeBytes,
                state = TransferState.QUEUED,
                isApk = offer.isApk,
                mimeType = offer.mimeType
            )
        }
        sendFrame(TransferProtocol.TYPE_ACCEPT, offer.id.toByteArray(Charsets.UTF_8))
    }

    /**
     * Runs on the read loop, so nothing else touches [input] while the file's bytes are consumed.
     * Reading exactly the offered size keeps the control stream in sync; a short read means the
     * connection died, which the caller handles by closing the session.
     */
    private suspend fun receiveFile(id: String) {
        val offer = pendingOffers.remove(id) ?: throw IOException("File data arrived for an unknown offer")
        setState(id, TransferState.IN_PROGRESS)

        val sink: IncomingSink? = withContext(Dispatchers.IO) {
            try {
                fileIo.createIncomingSink(offer.name, offer.mimeType)
            } catch (e: Exception) {
                null
            }
        }
        if (sink == null) {
            // Nowhere to put it (storage full, no permission...). The bytes are still coming, so
            // consume them to stay in sync, then report just this file as failed.
            withContext(Dispatchers.IO) { discardBytes(offer.sizeBytes) }
            markFailed(id, null)
            return
        }

        try {
            withContext(Dispatchers.IO) {
                val meter = ProgressMeter()
                sink.outputStream.use { out ->
                    PipelinedCopy.copy(
                        source = input,
                        sink = out,
                        length = offer.sizeBytes,
                        endedEarly = { ConnectionLostException("Connection lost while receiving ${offer.name}") },
                        onAbort = { this@TransferSession.close() },
                        onWritten = { received -> publishProgress(id, received, meter) }
                    )
                }
                sink.finalize()
            }
            mutate(id) {
                it.copy(
                    transferredBytes = it.totalBytes,
                    speedBytesPerSec = 0L,
                    savedUri = sink.uri,
                    state = TransferState.COMPLETED
                )
            }
        } catch (e: Exception) {
            markFailed(id, e)
            runCatching { sink.discard() }
            throw e
        }
    }

    private fun discardBytes(count: Long) {
        val scratch = ByteArray(TransferProtocol.IO_BUFFER_SIZE)
        var remaining = count
        while (remaining > 0) {
            val read = input.read(scratch, 0, minOf(scratch.size.toLong(), remaining).toInt())
            if (read < 0) throw IOException("Connection lost")
            remaining -= read
        }
    }

    /** Tells the peer we're leaving (best effort, briefly) and then closes. */
    suspend fun goodbye() {
        withTimeoutOrNull(GOODBYE_TIMEOUT_MS) {
            try {
                sendFrame(TransferProtocol.TYPE_BYE)
            } catch (e: IOException) {
                // already broken - closing below is all that's left to do
            }
        }
        close()
    }

    fun close() {
        if (!_closed.compareAndSet(false, true)) return
        runCatching { socket.close() }
        readJob?.cancel()
        pendingAcks.values.forEach { runCatching { it.resume(false) } }
        pendingAcks.clear()
        _progress.update { list ->
            list.map {
                if (it.state == TransferState.IN_PROGRESS || it.state == TransferState.QUEUED) {
                    it.copy(
                        state = TransferState.FAILED,
                        speedBytesPerSec = 0L,
                        failure = it.failure ?: TransferFailure.CONNECTION_LOST
                    )
                } else {
                    it
                }
            }
        }
    }

    private fun setState(id: String, state: TransferState) {
        mutate(id) { it.copy(state = state, speedBytesPerSec = if (state == TransferState.IN_PROGRESS) it.speedBytesPerSec else 0L) }
    }

    /** Marks [id] failed with the most specific reason [error] allows. */
    private fun markFailed(id: String, error: Throwable?) {
        val failure = classifyFailure(error)
        mutate(id) { it.copy(state = TransferState.FAILED, speedBytesPerSec = 0L, failure = failure) }
    }

    /** Hands the screen a fresh byte count and speed, but only when [meter] says one is due. */
    private fun publishProgress(id: String, transferred: Long, meter: ProgressMeter) {
        val speed = meter.poll(transferred) ?: return
        mutate(id) { it.copy(transferredBytes = transferred, speedBytesPerSec = speed) }
    }

    private fun mutate(id: String, transform: (TransferProgress) -> TransferProgress) {
        _progress.update { list -> list.map { if (it.itemId == id) transform(it) else it } }
    }

    private companion object {
        const val ACK_TIMEOUT_MS = 120_000L
        const val GOODBYE_TIMEOUT_MS = 800L

        /** Headroom kept free when deciding whether an incoming file fits. */
        const val SPACE_MARGIN_BYTES = 64L * 1024L * 1024L
    }
}
