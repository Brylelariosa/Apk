package com.beamshare.app.core.transfer

/**
 * Turns "this many bytes so far" into a speed that matches what a stopwatch would show, and decides
 * when the screen needs to hear about it.
 *
 * Speed is bytes moved divided by time elapsed over a sliding window of a few seconds. It is
 * deliberately not an average of per-chunk rates: chunks arrive in bursts (a socket that stalled
 * hands over several at once), and averaging each chunk's own rate lets a few milliseconds of burst
 * outweigh a long stall, so the number comes out many times too high and jumps around.
 *
 * Publishing is throttled by time too. At WiFi speeds a block lands every few milliseconds, and
 * pushing each one through the UI costs real CPU on a mid-range phone - slowing the very transfer
 * it is reporting on.
 *
 * One meter per file transfer. Not thread-safe: call it from the one coroutine moving the bytes.
 * The clock is injectable so the arithmetic can be unit-tested without sleeping.
 */
internal class ProgressMeter(
    private val clock: () -> Long = System::nanoTime,
    private val windowNanos: Long = WINDOW_NANOS,
    private val publishIntervalNanos: Long = PUBLISH_INTERVAL_NANOS
) {
    private val startNanos = clock()
    private val sampleTimes = ArrayDeque<Long>().apply { addLast(startNanos) }
    private val sampleTotals = ArrayDeque<Long>().apply { addLast(0L) }
    private var lastPublishNanos = startNanos
    private var speed = 0L

    /**
     * Records that [totalBytes] have moved so far. Returns the current speed in bytes per second when
     * an update is due, or null while the last one is still fresh. [force] publishes regardless.
     */
    fun poll(totalBytes: Long, force: Boolean = false): Long? {
        val now = clock()
        if (!force && now - lastPublishNanos < publishIntervalNanos) return null
        lastPublishNanos = now

        sampleTimes.addLast(now)
        sampleTotals.addLast(totalBytes)
        // Forget samples that fell out of the window, but keep the newest one outside it as the
        // baseline so the measured span always covers the whole window once there is that much history.
        while (sampleTimes.size > 2 && now - sampleTimes[1] >= windowNanos) {
            sampleTimes.removeFirst()
            sampleTotals.removeFirst()
        }

        val spanNanos = now - sampleTimes.first()
        val bytes = totalBytes - sampleTotals.first()
        if (spanNanos >= MIN_SPAN_NANOS && bytes >= 0L) {
            speed = (bytes.toDouble() * NANOS_PER_SECOND / spanNanos.toDouble()).toLong()
        }
        return speed
    }

    private companion object {
        const val WINDOW_NANOS = 3_000_000_000L
        const val PUBLISH_INTERVAL_NANOS = 250_000_000L
        const val MIN_SPAN_NANOS = 250_000_000L
        const val NANOS_PER_SECOND = 1_000_000_000.0
    }
}
