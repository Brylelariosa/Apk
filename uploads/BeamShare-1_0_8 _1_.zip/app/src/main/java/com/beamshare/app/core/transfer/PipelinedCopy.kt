package com.beamshare.app.core.transfer

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream

/**
 * Copies an exact number of bytes with reading and writing overlapped instead of taking turns.
 *
 * A plain read-then-write loop leaves one side idle while the other works: when sending, the file
 * isn't being read while the socket is busy; when receiving, the socket isn't being drained while
 * flash storage finishes a slow write - and a socket nobody is draining closes the TCP window and
 * throttles the sender. Here one coroutine reads into a small pool of reusable blocks while another
 * writes the filled ones, so a stall on either side is absorbed by the blocks in between (about 2 MB
 * for a large file) instead of stopping the other.
 *
 * Exactly [length] bytes move. Pools are sized to the file so a small picture doesn't allocate 2 MB.
 *
 * Failure handling: the stream can't be resynchronised once bytes are mid-flight, so any failure
 * calls [onAbort] before it propagates. Callers pass something that closes the connection - that is
 * what wakes a read stuck on a quiet socket, which would otherwise keep this call from ever returning.
 */
internal object PipelinedCopy {

    private class Block(val data: ByteArray) {
        var length: Int = 0
    }

    /**
     * @param endedEarly builds the exception thrown when [source] ends before [length] bytes
     * @param onAbort called (possibly more than once, so it must be idempotent) when either side fails
     * @param onWritten called after each block is written, with the running total handed to [sink]
     */
    suspend fun copy(
        source: InputStream,
        sink: OutputStream,
        length: Long,
        endedEarly: () -> IOException,
        onAbort: () -> Unit,
        onWritten: (totalBytes: Long) -> Unit
    ): Unit = withContext(Dispatchers.IO) {
        val blockSize = minOf(TransferProtocol.BLOCK_SIZE.toLong(), length).toInt().coerceAtLeast(1)
        val blockCount = minOf(
            TransferProtocol.BLOCK_POOL.toLong(),
            (length + blockSize - 1L) / blockSize
        ).toInt().coerceAtLeast(1)

        val free = Channel<Block>(blockCount)
        val filled = Channel<Block>(blockCount)
        repeat(blockCount) { free.trySend(Block(ByteArray(blockSize))) }

        try {
            coroutineScope {
                launch {
                    try {
                        var remaining = length
                        while (remaining > 0L) {
                            val block = free.receive()
                            val wanted = minOf(block.data.size.toLong(), remaining).toInt()
                            val read = source.read(block.data, 0, wanted)
                            if (read < 0) throw endedEarly()
                            block.length = read
                            remaining -= read
                            filled.send(block)
                        }
                        filled.close()
                    } catch (e: Throwable) {
                        onAbort()
                        throw e
                    }
                }

                try {
                    var written = 0L
                    for (block in filled) {
                        sink.write(block.data, 0, block.length)
                        written += block.length
                        onWritten(written)
                        free.trySend(block)
                    }
                } catch (e: Throwable) {
                    onAbort()
                    throw e
                }
            }
        } finally {
            free.cancel()
            filled.cancel()
        }
    }
}
