package com.beamshare.app.core.files

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.os.StatFs
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import androidx.annotation.RequiresApi
import androidx.core.content.FileProvider
import com.beamshare.app.core.model.TransferItem
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID

/**
 * A writable destination for an incoming transfer.
 * [finalize] publishes a fully written file; [discard] removes a partial one after a failure.
 */
data class IncomingSink(
    val outputStream: OutputStream,
    val uri: Uri,
    val finalize: () -> Unit = {},
    val discard: () -> Unit = {}
)

/** Abstraction boundary so [com.beamshare.app.core.transfer.TransferSession] never touches Context/ContentResolver directly. */
interface FileIo {
    @Throws(IOException::class)
    fun openInputStream(item: TransferItem): InputStream

    @Throws(IOException::class)
    fun createIncomingSink(name: String, mimeType: String): IncomingSink

    /**
     * Bytes free where incoming files are stored. Lets the receiver turn down a file that can't fit
     * up front, instead of filling the storage and failing part-way through. [Long.MAX_VALUE] means
     * "can't tell", which never turns anything down.
     */
    fun availableBytes(): Long = Long.MAX_VALUE
}

class FileRepository(private val context: Context) : FileIo {

    private val providerAuthority get() = "${context.packageName}.fileprovider"

    override fun openInputStream(item: TransferItem): InputStream {
        item.sourceUri?.let { uri -> return openSourceStream(uri, item.displayName) }
        item.sourceFilePath?.let { path ->
            return FileInputStream(File(path))
        }
        throw IOException("${item.displayName} has no source")
    }

    override fun availableBytes(): Long = runCatching {
        // App-specific external storage sits on the same volume as Downloads, and asking about it
        // needs no permission.
        val dir = context.getExternalFilesDir(null) ?: context.filesDir
        StatFs(dir.path).availableBytes
    }.getOrDefault(Long.MAX_VALUE)

    /**
     * Opens a picked document through its file descriptor when the provider hands one out.
     * `ContentResolver.openInputStream` can wrap that descriptor in `AssetFileDescriptor`'s stream,
     * which tracks the bytes still to read with an int cast - fine for small files, wrong for the
     * multi-gigabyte ones this app is for. A plain descriptor stream has no such limit. Providers
     * that only serve a stream (virtual documents) fall back to the resolver.
     */
    private fun openSourceStream(uri: Uri, displayName: String): InputStream {
        val resolver = context.contentResolver
        val descriptor = try {
            resolver.openFileDescriptor(uri, "r")
        } catch (e: Exception) {
            null
        }
        if (descriptor != null) return ParcelFileDescriptor.AutoCloseInputStream(descriptor)
        return resolver.openInputStream(uri) ?: throw IOException("Could not open $displayName")
    }

    override fun createIncomingSink(name: String, mimeType: String): IncomingSink {
        val safeName = sanitizeFileName(name)
        val safeMime = mimeType.ifBlank { "application/octet-stream" }
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            createMediaStoreSink(safeName, safeMime)
        } else {
            createLegacySink(safeName)
        }
    }

    /**
     * Resolves an SAF-picked document URI into a queueable [TransferItem].
     *
     * The size is what the sender promises the receiver up front, and the receiver reads exactly
     * that many raw bytes, so it has to be exact. The file's real length (fstat on its descriptor,
     * 64-bit) wins over what the provider reports, because that column can be missing or wrong - a
     * wrong one is how a 6 GB file ends up offered as something smaller. Only when there is no
     * descriptor length is the reported size used, and as a last resort the document is staged into
     * the cache so its true length is known.
     */
    fun transferItemFromUri(uri: Uri, mimeTypeHint: String? = null): TransferItem {
        // Best effort: keep read access beyond the picker's temporary grant.
        runCatching {
            context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val (name, reportedSize) = queryDisplayNameAndSize(uri)
        val mimeType = resolveMimeType(uri, name, mimeTypeHint)
        val measuredSize = measureSize(uri)
        val size = when {
            measuredSize > 0L -> measuredSize
            reportedSize > 0L -> reportedSize
            else -> maxOf(measuredSize, reportedSize) // 0 for a genuinely empty file, -1 when unknown
        }
        if (size >= 0L) {
            return TransferItem(displayName = name, sizeBytes = size, mimeType = mimeType, sourceUri = uri)
        }
        val staged = stageToCache(uri, name)
        return TransferItem(
            displayName = name,
            sizeBytes = staged.length(),
            mimeType = mimeType,
            sourceFilePath = staged.absolutePath
        )
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    private fun createMediaStoreSink(name: String, mimeType: String): IncomingSink {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.MIME_TYPE, mimeType)
            put(MediaStore.Downloads.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/BeamShare")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw IOException("Could not create destination for $name")
        val stream = try {
            resolver.openOutputStream(uri)
        } catch (e: Exception) {
            null
        }
        if (stream == null) {
            runCatching { resolver.delete(uri, null, null) }
            throw IOException("Could not open destination for $name")
        }
        return IncomingSink(
            outputStream = stream,
            uri = uri,
            finalize = {
                resolver.update(uri, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null)
            },
            discard = { runCatching { resolver.delete(uri, null, null) } }
        )
    }

    private fun createLegacySink(name: String): IncomingSink {
        val dir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: context.filesDir
        if (!dir.exists()) dir.mkdirs()
        val file = uniqueFile(dir, name)
        val contentUri = FileProvider.getUriForFile(context, providerAuthority, file)
        return IncomingSink(
            outputStream = FileOutputStream(file),
            uri = contentUri,
            discard = { runCatching { file.delete() } }
        )
    }

    private fun uniqueFile(dir: File, name: String): File {
        val dot = name.lastIndexOf('.')
        val base = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var candidate = File(dir, name)
        var index = 1
        while (candidate.exists()) {
            candidate = File(dir, "$base ($index)$ext")
            index++
        }
        return candidate
    }

    /** Strips path separators and other characters providers reject, and keeps the extension when shortening. */
    private fun sanitizeFileName(name: String): String {
        val cleaned = name.replace(INVALID_NAME_CHARS, "_").trim().trimStart('.')
        if (cleaned.isEmpty()) return "beamshare_file"
        val dot = cleaned.lastIndexOf('.')
        val extension = if (dot > 0 && cleaned.length - dot <= MAX_EXTENSION_LENGTH) cleaned.substring(dot) else ""
        val base = cleaned.substring(0, cleaned.length - extension.length).take(MAX_NAME_LENGTH - extension.length)
        return base.ifBlank { "beamshare_file" } + extension
    }

    private fun queryDisplayNameAndSize(uri: Uri): Pair<String, Long> {
        var displayName: String? = null
        var size = -1L
        runCatching {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor: Cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (cursor.moveToFirst()) {
                    if (nameIndex >= 0) displayName = cursor.getString(nameIndex)
                    if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) size = cursor.getLong(sizeIndex)
                }
            }
        }
        val name = displayName?.takeIf { it.isNotBlank() } ?: uri.lastPathSegment ?: "file"
        return name to size
    }

    /** Exact length from fstat on the file descriptor, or -1 when it isn't a plain file (or can't be opened). */
    private fun measureSize(uri: Uri): Long = runCatching {
        context.contentResolver.openFileDescriptor(uri, "r")?.use { it.statSize } ?: -1L
    }.getOrDefault(-1L)

    private fun resolveMimeType(uri: Uri, name: String, hint: String?): String {
        if (!hint.isNullOrBlank()) return hint
        val reported = context.contentResolver.getType(uri)
        if (!reported.isNullOrBlank() && reported != GENERIC_MIME) return reported
        val extension = name.substringAfterLast('.', "").lowercase()
        val guessed = if (extension.isNotEmpty()) MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension) else null
        return guessed ?: reported ?: GENERIC_MIME
    }

    private fun stageToCache(uri: Uri, name: String): File {
        val dir = File(context.cacheDir, OUTGOING_CACHE_DIR).apply { mkdirs() }
        val cutoff = System.currentTimeMillis() - OUTGOING_CACHE_TTL_MS
        dir.listFiles()?.forEach { if (it.lastModified() < cutoff) it.delete() }

        val target = File(dir, "${UUID.randomUUID()}-${sanitizeFileName(name)}")
        val input = context.contentResolver.openInputStream(uri) ?: throw IOException("Could not read $name")
        input.use { source -> FileOutputStream(target).use { sink -> source.copyTo(sink) } }
        return target
    }

    private companion object {
        const val GENERIC_MIME = "application/octet-stream"
        const val OUTGOING_CACHE_DIR = "outgoing"
        const val OUTGOING_CACHE_TTL_MS = 24L * 60L * 60L * 1000L
        const val MAX_NAME_LENGTH = 120
        const val MAX_EXTENSION_LENGTH = 10
        val INVALID_NAME_CHARS = Regex("[/\\\\:*?\"<>|\\p{Cntrl}]")
    }
}
