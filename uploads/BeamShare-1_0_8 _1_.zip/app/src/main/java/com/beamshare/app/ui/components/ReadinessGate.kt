package com.beamshare.app.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.unit.dp
import com.beamshare.app.R
import com.beamshare.app.ui.util.OnResumeEffect
import com.beamshare.app.util.PermissionHelper
import com.beamshare.app.util.Readiness

/** Live snapshot of what WiFi Direct needs; refreshed whenever the screen resumes. */
@Stable
class ReadinessState(private val context: Context) {
    var value by mutableStateOf(PermissionHelper.readiness(context))
        private set

    fun refresh() {
        value = PermissionHelper.readiness(context)
    }
}

@Composable
fun rememberReadinessState(): ReadinessState {
    val context = LocalContext.current
    val state = remember { ReadinessState(context) }
    OnResumeEffect { state.refresh() }
    return state
}

/**
 * Shows [content] only once the nearby-devices permission is granted and WiFi (and, on Android 12
 * and older, Location) is on. Until then it lists exactly what's missing, each with a button that
 * fixes it, and re-checks automatically when the user returns from Settings.
 */
@Composable
fun ReadinessGate(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    val readiness = rememberReadinessState()
    var permissionDenied by rememberSaveable { mutableStateOf(false) }
    var autoRequested by rememberSaveable { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        readiness.refresh()
        if (!granted) permissionDenied = true
    }

    val current = readiness.value
    LaunchedEffect(current.permissionGranted) {
        if (current.wifiDirectSupported && !current.permissionGranted && !autoRequested) {
            autoRequested = true
            permissionLauncher.launch(PermissionHelper.nearbyPermission())
        }
    }

    if (current.isReady) {
        // The caller's modifier carries the Scaffold's inner padding (status bar + top bar). It used to
        // be dropped here once everything was ready, which let the screen's content slide up under
        // the status bar; the requirements list below always honoured it, hiding the difference.
        Box(modifier = modifier.fillMaxSize()) { content() }
    } else {
        Requirements(
            readiness = current,
            permissionDenied = permissionDenied,
            onAllow = { permissionLauncher.launch(PermissionHelper.nearbyPermission()) },
            modifier = modifier
        )
    }
}

@Composable
private fun Requirements(
    readiness: Readiness,
    permissionDenied: Boolean,
    onAllow: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(stringResource(R.string.ready_title), style = MaterialTheme.typography.headlineSmall)
        Text(
            stringResource(R.string.ready_subtitle),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        if (!readiness.wifiDirectSupported) {
            // Nothing the user can switch on fixes this, so it gets a plain notice instead of a card with a button.
            InfoBanner(
                text = stringResource(R.string.ready_unsupported),
                icon = ImageVector.vectorResource(R.drawable.ic_error_outline),
                tone = MaterialTheme.colorScheme.error
            )
            return@Column
        }
        if (!readiness.permissionGranted) {
            RequirementCard(
                icon = ImageVector.vectorResource(R.drawable.ic_phone_android),
                title = stringResource(R.string.ready_permission_title),
                body = stringResource(R.string.ready_permission_body),
                actionLabel = stringResource(R.string.ready_permission_action),
                onAction = onAllow,
                secondaryLabel = if (permissionDenied) stringResource(R.string.ready_permission_settings) else null,
                onSecondary = { openAppSettings(context) }
            )
        }
        if (!readiness.wifiEnabled) {
            RequirementCard(
                icon = ImageVector.vectorResource(R.drawable.ic_wifi),
                title = stringResource(R.string.ready_wifi_title),
                body = stringResource(R.string.ready_wifi_body),
                actionLabel = stringResource(R.string.ready_wifi_action),
                onAction = { openSettings(context, Settings.ACTION_WIFI_SETTINGS) }
            )
        }
        if (!readiness.locationEnabled) {
            RequirementCard(
                icon = ImageVector.vectorResource(R.drawable.ic_location_on),
                title = stringResource(R.string.ready_location_title),
                body = stringResource(R.string.ready_location_body),
                actionLabel = stringResource(R.string.ready_location_action),
                onAction = { openSettings(context, Settings.ACTION_LOCATION_SOURCE_SETTINGS) }
            )
        }
    }
}

@Composable
private fun RequirementCard(
    icon: ImageVector,
    title: String,
    body: String,
    actionLabel: String,
    onAction: () -> Unit,
    modifier: Modifier = Modifier,
    secondaryLabel: String? = null,
    onSecondary: () -> Unit = {}
) {
    BeamCard(modifier = modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                IconBadge(icon, size = 48.dp)
                Text(title, style = MaterialTheme.typography.titleMedium)
            }
            Text(body, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            BeamPrimaryButton(text = actionLabel, onClick = onAction, modifier = Modifier.fillMaxWidth())
            if (secondaryLabel != null) {
                TextButton(onClick = onSecondary, modifier = Modifier.fillMaxWidth()) { Text(secondaryLabel) }
            }
        }
    }
}

private fun openSettings(context: Context, action: String) {
    runCatching { context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
}

internal fun openAppSettings(context: Context) {
    runCatching {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.packageName, null))
        context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
