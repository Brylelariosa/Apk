package com.beamshare.app.core.transfer

import com.beamshare.app.core.model.TransferFailure
import java.io.IOException
import java.net.SocketException

/** The file being sent ran out before the size promised in the offer. */
internal class SourceEndedEarlyException(message: String) : IOException(message)

/** The connection ended before the promised number of bytes arrived. */
internal class ConnectionLostException(message: String) : IOException(message)

private const val MAX_CAUSE_DEPTH = 6

/**
 * Maps whatever a transfer threw to something worth telling the user. The OS reports a full disk or
 * an oversized file as a plain IOException whose message carries the errno name, so that is what is
 * matched on; anything unrecognised stays [TransferFailure.OTHER].
 */
internal fun classifyFailure(error: Throwable?): TransferFailure {
    var cause: Throwable? = error
    var depth = 0
    while (cause != null && depth < MAX_CAUSE_DEPTH) {
        val text = cause.message.orEmpty()
        when {
            "ENOSPC" in text || "No space left" in text -> return TransferFailure.NO_SPACE
            "EFBIG" in text || "File too large" in text -> return TransferFailure.FILE_TOO_LARGE
            cause is SourceEndedEarlyException -> return TransferFailure.SOURCE_CHANGED
            cause is ConnectionLostException || cause is SocketException -> return TransferFailure.CONNECTION_LOST
        }
        cause = cause.cause
        depth++
    }
    return TransferFailure.OTHER
}
