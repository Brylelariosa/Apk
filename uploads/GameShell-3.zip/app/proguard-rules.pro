# Add project specific ProGuard rules here.

# Minification + resource shrinking are now on for release builds
# (app/build.gradle). Nothing here needed that yet — no reflection,
# no JS interface, no XML-inflated custom views. If a WebView JS
# bridge gets added later (addJavascriptInterface), keep it explicit
# or R8 will strip/rename the bridge methods and break the JS side
# silently:
#   -keepclassmembers class com.gameshell.YourBridgeClass {
#       @android.webkit.JavascriptInterface <methods>;
#   }
