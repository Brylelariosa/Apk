package com.gameshell

import android.os.Handler
import android.os.Looper
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/**
 * Thread-safe tracker for real network downloads of confirmed-static game
 * assets, as reported by [CachingWebViewClient]. Holds no reference to any
 * Activity/View - observers register through [attach] and must call
 * [detach] (e.g. from Activity.onDestroy) so nothing keeps an Activity
 * alive and no stray callback fires after teardown.
 *
 * Cache hits ([onCacheHit]) are counted separately and never contribute to
 * download progress or bytes. Dynamic/authenticated/unknown requests are
 * never reported here at all - only assets [CachingWebViewClient] has
 * already confirmed are static, and which actually required a network
 * fetch, ever reach this class.
 *
 * Stats reset at the start of each new "burst" (the first download after
 * a fully idle period), so the numbers shown always describe the current
 * loading episode rather than an ever-growing lifetime total.
 */
class DownloadTracker {

    enum class Phase { IDLE, ACTIVE, FINISHING }

    data class Stats(
        val phase: Phase,
        val activeCount: Int,
        val completedCount: Int,
        val totalSeenCount: Int,
        val failedCount: Int,
        val cachedCount: Int,
        val downloadedBytes: Long,
        val knownTotalBytes: Long,
        val allSizesKnown: Boolean,
        val bytesPerSecond: Long,
        val currentAssetLabel: String?
    )

    fun interface Listener {
        fun onDownloadStatsChanged(stats: Stats)
    }

    private class AssetDownload(val label: String, val totalBytes: Long?) {
        val downloadedBytes = AtomicLong(0)
        @Volatile var lastProgressAtMs: Long = System.currentTimeMillis()
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private val active = ConcurrentHashMap<String, AssetDownload>()
    private val burstLock = Any()

    private val completedCount = AtomicInteger(0)
    private val totalSeenCount = AtomicInteger(0)
    private val failedCount = AtomicInteger(0)
    private val cachedCount = AtomicInteger(0)
    private val completedBytes = AtomicLong(0)
    private val completedKnownBytes = AtomicLong(0)
    @Volatile private var unknownSizeSeen = false
    @Volatile private var idle = true

    @Volatile private var listener: Listener? = null
    private val isTicking = AtomicBoolean(false)

    // Only ever touched from the main thread, inside tick()/buildStats().
    private var lastSampleAtMs = 0L
    private var lastSampleBytes = 0L
    private var smoothedBps = 0L

    private val tickRunnable = Runnable { tick() }
    private val finishRunnable = Runnable { finishIfStillIdle() }

    /** Registers [newListener] and immediately delivers the current snapshot. */
    fun attach(newListener: Listener) {
        listener = newListener
        notifyListener()
        if (active.isNotEmpty()) startTicking()
    }

    /** Stops delivering updates and cancels any pending callbacks. Call from onDestroy. */
    fun detach() {
        listener = null
        mainHandler.removeCallbacks(tickRunnable)
        mainHandler.removeCallbacks(finishRunnable)
        isTicking.set(false)
    }

    /** A confirmed-static asset was not in cache and a network fetch is starting. */
    fun onDownloadStarted(key: String, label: String, totalBytes: Long?) {
        mainHandler.removeCallbacks(finishRunnable)
        synchronized(burstLock) {
            if (idle) {
                resetBurstCounters()
                idle = false
            }
            if (totalBytes == null) unknownSizeSeen = true
            totalSeenCount.incrementAndGet()
        }
        active[key] = AssetDownload(label, totalBytes)
        startTicking()
    }

    /** Call as bytes are read from the response for [key]. */
    fun onProgress(key: String, bytesReadDelta: Int) {
        val entry = active[key] ?: return
        entry.downloadedBytes.addAndGet(bytesReadDelta.toLong())
        entry.lastProgressAtMs = System.currentTimeMillis()
    }

    /** The download for [key] finished and was stored in the cache. */
    fun onDownloadCompleted(key: String) {
        val entry = active.remove(key) ?: return
        completedCount.incrementAndGet()
        completedBytes.addAndGet(entry.downloadedBytes.get())
        entry.totalBytes?.let { completedKnownBytes.addAndGet(it) }
        if (active.isEmpty()) scheduleFinish()
    }

    /** The download for [key] failed; its partial bytes are discarded, not counted as progress. */
    fun onDownloadFailed(key: String) {
        if (active.remove(key) == null) return
        failedCount.incrementAndGet()
        if (active.isEmpty()) scheduleFinish()
    }

    /** A resource was already in GameAssetStore and required no network fetch. */
    fun onCacheHit() {
        cachedCount.incrementAndGet()
    }

    private fun resetBurstCounters() {
        completedCount.set(0)
        totalSeenCount.set(0)
        failedCount.set(0)
        cachedCount.set(0)
        completedBytes.set(0)
        completedKnownBytes.set(0)
        unknownSizeSeen = false
        lastSampleAtMs = 0L
        lastSampleBytes = 0L
        smoothedBps = 0L
    }

    private fun startTicking() {
        if (isTicking.compareAndSet(false, true)) {
            mainHandler.post(tickRunnable)
        }
    }

    private fun scheduleFinish() {
        mainHandler.postDelayed(finishRunnable, FINISH_DELAY_MS)
    }

    private fun finishIfStillIdle() {
        if (active.isEmpty()) {
            idle = true
            isTicking.set(false)
            notifyListener(forceIdle = true)
        }
    }

    private fun tick() {
        notifyListener()
        if (active.isNotEmpty()) {
            mainHandler.postDelayed(tickRunnable, TICK_INTERVAL_MS)
        } else {
            isTicking.set(false)
        }
    }

    private fun notifyListener(forceIdle: Boolean = false) {
        listener?.onDownloadStatsChanged(buildStats(forceIdle))
    }

    private fun buildStats(forceIdle: Boolean): Stats {
        val activeSnapshot = active.values.toList()
        val activeDownloadedNow = activeSnapshot.sumOf { it.downloadedBytes.get() }
        val activeKnownNow = activeSnapshot.mapNotNull { it.totalBytes }.sum()
        val downloadedBytes = completedBytes.get() + activeDownloadedNow
        val knownTotalBytes = completedKnownBytes.get() + activeKnownNow

        val now = System.currentTimeMillis()
        if (lastSampleAtMs != 0L) {
            val elapsedMs = (now - lastSampleAtMs).coerceAtLeast(1)
            val deltaBytes = (downloadedBytes - lastSampleBytes).coerceAtLeast(0)
            val instantBps = deltaBytes * 1000 / elapsedMs
            // Light smoothing (70/30) so the displayed number doesn't jump every tick.
            smoothedBps = if (smoothedBps == 0L) instantBps else (smoothedBps * 7 + instantBps * 3) / 10
        }
        lastSampleAtMs = now
        lastSampleBytes = downloadedBytes

        val phase = when {
            forceIdle || (active.isEmpty() && !isTicking.get()) -> Phase.IDLE
            active.isEmpty() -> Phase.FINISHING
            else -> Phase.ACTIVE
        }

        return Stats(
            phase = phase,
            activeCount = activeSnapshot.size,
            completedCount = completedCount.get(),
            totalSeenCount = totalSeenCount.get(),
            failedCount = failedCount.get(),
            cachedCount = cachedCount.get(),
            downloadedBytes = downloadedBytes,
            knownTotalBytes = knownTotalBytes,
            allSizesKnown = !unknownSizeSeen,
            bytesPerSecond = smoothedBps.coerceAtLeast(0L),
            currentAssetLabel = activeSnapshot.maxByOrNull { it.lastProgressAtMs }?.label
        )
    }

    companion object {
        private const val TICK_INTERVAL_MS = 200L
        private const val FINISH_DELAY_MS = 1500L
    }
}
