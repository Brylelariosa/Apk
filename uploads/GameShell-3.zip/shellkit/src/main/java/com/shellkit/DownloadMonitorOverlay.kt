package com.shellkit

import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import kotlin.math.roundToInt

/**
 * Renders [DownloadTracker.Stats] into the download-monitor overlay Views.
 * A pure presentation layer: owns no tracking state and does no networking
 * or caching. [DownloadTracker] pushes state in via [render], always from
 * the main thread (see [DownloadTracker.attach]).
 *
 * Does not own whether the panel itself is shown or hidden - that's
 * [DownloadButtonController]'s job, driven by the button tap rather than by
 * download activity. [render] only ever updates content, so whatever was
 * last downloaded is still there to read the next time the panel is opened.
 */
class DownloadMonitorOverlay(
    private val status: TextView,
    private val progress: ProgressBar,
    private val percent: TextView,
    private val bytes: TextView,
    private val speed: TextView,
    private val eta: TextView,
    private val current: TextView,
    private val assets: TextView,
    private val cached: TextView,
    private val failed: TextView,
    private val activeCount: TextView,
    private val recent: TextView
) {

    fun render(stats: DownloadTracker.Stats) {
        val neverDownloaded = stats.phase == DownloadTracker.Phase.IDLE && stats.totalSeenCount == 0

        status.text = when {
            stats.phase == DownloadTracker.Phase.ACTIVE -> "Downloading..."
            stats.phase == DownloadTracker.Phase.FINISHING -> "Done"
            neverDownloaded -> "No downloads yet"
            else -> "Done"
        }

        if (neverDownloaded) {
            progress.visibility = View.GONE
            percent.visibility = View.GONE
            bytes.visibility = View.GONE
            speed.visibility = View.GONE
            eta.visibility = View.GONE
            current.visibility = View.GONE
            assets.visibility = View.GONE
            cached.visibility = View.GONE
            failed.visibility = View.GONE
            activeCount.visibility = View.GONE
            recent.visibility = View.GONE
            return
        }

        progress.visibility = View.VISIBLE
        bytes.visibility = View.VISIBLE
        assets.visibility = View.VISIBLE
        activeCount.visibility = View.VISIBLE

        val fraction = if (stats.allSizesKnown && stats.knownTotalBytes > 0) {
            (stats.downloadedBytes.toDouble() / stats.knownTotalBytes).coerceIn(0.0, 1.0)
        } else {
            null
        }

        if (fraction != null) {
            progress.isIndeterminate = false
            progress.max = PROGRESS_MAX
            progress.progress = (fraction * PROGRESS_MAX).roundToInt()
            percent.visibility = View.VISIBLE
            percent.text = "${(fraction * 100).roundToInt()}%"
            bytes.text = "${formatBytes(stats.downloadedBytes)} / ${formatBytes(stats.knownTotalBytes)}"
        } else {
            // Unknown total size(s) in the mix: no invented percentage, indeterminate bar instead.
            progress.isIndeterminate = stats.phase == DownloadTracker.Phase.ACTIVE
            percent.visibility = View.GONE
            bytes.text = "${formatBytes(stats.downloadedBytes)} downloaded"
        }

        speed.visibility = if (stats.bytesPerSecond > 0) View.VISIBLE else View.GONE
        speed.text = "${formatBytes(stats.bytesPerSecond)}/s"

        val etaSeconds = etaSecondsFor(stats)
        eta.visibility = if (etaSeconds != null) View.VISIBLE else View.GONE
        if (etaSeconds != null) eta.text = "ETA: ${formatEta(etaSeconds)}"

        current.visibility = if (stats.currentAssetLabel != null) View.VISIBLE else View.GONE
        current.text = "Current: ${stats.currentAssetLabel}"

        assets.text = "Assets: ${format(stats.completedCount)} / ${format(stats.totalSeenCount)}"

        cached.visibility = if (stats.cachedCount > 0) View.VISIBLE else View.GONE
        cached.text = "Cached: ${format(stats.cachedCount)}"

        failed.visibility = if (stats.failedCount > 0) View.VISIBLE else View.GONE
        failed.text = "Failed: ${format(stats.failedCount)}"

        activeCount.text = "Active: ${stats.activeCount}"

        recent.visibility = if (stats.recentCompleted.isEmpty()) View.GONE else View.VISIBLE
        recent.text = stats.recentCompleted.joinToString(separator = "\n", prefix = "Recent:\n") { "• $it" }
    }

    /** Null unless every active/completed size is known and speed is stable enough to trust. */
    private fun etaSecondsFor(stats: DownloadTracker.Stats): Long? {
        if (!stats.allSizesKnown || stats.bytesPerSecond <= 0) return null
        val remaining = stats.knownTotalBytes - stats.downloadedBytes
        if (remaining <= 0) return null
        return remaining / stats.bytesPerSecond
    }

    private fun formatEta(totalSeconds: Long): String {
        val minutes = totalSeconds / 60
        val seconds = totalSeconds % 60
        return if (minutes > 0) "~${minutes}m ${seconds}s" else "~$seconds sec"
    }

    private fun format(value: Int): String = "%,d".format(value)

    private fun formatBytes(value: Long): String = when {
        value >= 1_000_000_000L -> "%.1f GB".format(value / 1_000_000_000.0)
        value >= 1_000_000L -> "%.1f MB".format(value / 1_000_000.0)
        value >= 1_000L -> "%.1f KB".format(value / 1_000.0)
        else -> "$value B"
    }

    companion object {
        private const val PROGRESS_MAX = 1000
    }
}
