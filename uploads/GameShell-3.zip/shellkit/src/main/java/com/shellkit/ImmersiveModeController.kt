package com.shellkit

import android.app.Activity
import android.os.Build
import android.view.WindowManager
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

/**
 * Hides the status bar and navigation bar and keeps them hidden,
 * including after focus is lost and regained (a dialog, the
 * notification shade being pulled down, switching apps and coming
 * back). Also keeps the screen from timing out during play and lets
 * content draw under the display cutout on notched devices.
 */
class ImmersiveModeController(private val activity: Activity) {

    fun apply() {
        val window = activity.window
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }

        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).let { controller ->
            controller.hide(WindowInsetsCompat.Type.systemBars())
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    /** Call from Activity.onWindowFocusChanged so the bars stay hidden after any interruption. */
    fun onWindowFocusChanged(hasFocus: Boolean) {
        if (hasFocus) apply()
    }
}
