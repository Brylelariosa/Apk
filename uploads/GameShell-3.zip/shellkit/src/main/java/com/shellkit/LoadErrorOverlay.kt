package com.shellkit

import android.view.View
import android.widget.Button
import android.widget.TextView

/**
 * Full-screen "couldn't load the game" state. Shown only for a main-frame
 * load failure - see [CachingWebViewClient]'s onMainFrameError callback,
 * keyed off [android.webkit.WebResourceRequest.isForMainFrame] - never for
 * one failed sub-resource among many.
 *
 * Retry just calls [onRetry]; a later successful load is the host
 * Activity's job to signal back via [hide] (typically from the same
 * onMainFrameLoaded callback [CachingWebViewClient] already exposes).
 */
class LoadErrorOverlay(
    private val root: View,
    message: TextView,
    retryButton: Button,
    onRetry: () -> Unit
) {
    init {
        message.text = "Can't load the game. Check your connection and try again."
        retryButton.setOnClickListener { onRetry() }
    }

    fun show() {
        root.visibility = View.VISIBLE
    }

    fun hide() {
        root.visibility = View.GONE
    }
}
