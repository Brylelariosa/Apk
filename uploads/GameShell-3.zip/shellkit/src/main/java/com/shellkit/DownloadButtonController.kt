package com.shellkit

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.view.View

/**
 * Owns the corner download button, its red "activity" badge, and whether
 * [panel] is shown - the single source of truth for that visibility, now
 * that [DownloadMonitorOverlay] only ever renders content. A tap on
 * [button] toggles [panel]; [onDownloadPhaseChanged] only ever touches the
 * badge, so the panel never pops open on its own while a download runs.
 */
class DownloadButtonController(
    private val button: View,
    private val badge: View,
    private val panel: View
) {
    private var blinkAnimator: ObjectAnimator? = null
    private var panelVisible = false

    init {
        button.setOnClickListener { togglePanel() }
        applyPanelVisibility()
    }

    /** Call whenever [DownloadTracker.Stats.phase] changes - drives only the badge. */
    fun onDownloadPhaseChanged(isActive: Boolean) {
        if (isActive) startBlinking() else stopBlinking()
    }

    /** Stops the blink animator. Call from onDestroy so nothing keeps animating past teardown. */
    fun detach() = stopBlinking()

    private fun togglePanel() {
        panelVisible = !panelVisible
        applyPanelVisibility()
    }

    private fun applyPanelVisibility() {
        panel.visibility = if (panelVisible) View.VISIBLE else View.GONE
    }

    private fun startBlinking() {
        if (blinkAnimator != null) return
        badge.visibility = View.VISIBLE
        badge.alpha = 1f
        blinkAnimator = ObjectAnimator.ofFloat(badge, View.ALPHA, 1f, MIN_BLINK_ALPHA).apply {
            duration = BLINK_DURATION_MS
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            start()
        }
    }

    private fun stopBlinking() {
        blinkAnimator?.cancel()
        blinkAnimator = null
        badge.alpha = 1f
        badge.visibility = View.GONE
    }

    companion object {
        private const val BLINK_DURATION_MS = 600L
        private const val MIN_BLINK_ALPHA = 0.15f
    }
}
