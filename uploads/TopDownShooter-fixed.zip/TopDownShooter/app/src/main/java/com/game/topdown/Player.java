package com.game.topdown;

public class Player {
    public int    id;
    public String name   = "";
    public float  x, y, angle;
    public float  hp     = 100;
    public int    gunIndex;
    public boolean alive = true;
    public Gun[]  guns;
    public Gun currentGun() { return guns[gunIndex]; }
}
