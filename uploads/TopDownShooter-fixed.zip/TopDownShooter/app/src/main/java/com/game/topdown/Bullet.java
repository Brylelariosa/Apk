package com.game.topdown;

public class Bullet {
    public int id, ownerId;
    public float x, y, dx, dy, damage;
    public long spawnTime;

    public Bullet(float x,float y,float dx,float dy,int owner,float dmg,int id){
        this.x=x; this.y=y; this.dx=dx; this.dy=dy;
        this.ownerId=owner; this.damage=dmg; this.id=id;
        this.spawnTime=System.currentTimeMillis();
    }
}
