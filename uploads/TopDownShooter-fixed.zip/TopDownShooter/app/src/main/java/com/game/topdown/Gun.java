package com.game.topdown;

public class Gun {
    public String name;
    public int    maxAmmo, ammo;
    public float  fireRate, damage, bulletSpeed, spread;
    public int    pellets, color;
    public long   reloadMs;

    // runtime state
    public boolean reloading;
    public long    reloadStart, lastFireTime;

    public boolean canFireNow() {
        if (ammo <= 0 || reloading) return false;
        return System.currentTimeMillis() - lastFireTime >= (long)(1000f / fireRate);
    }
    public void markFired() { lastFireTime = System.currentTimeMillis(); }

    public void startReload() {
        if (!reloading && ammo < maxAmmo) { reloading = true; reloadStart = System.currentTimeMillis(); }
    }
    public void tick() {
        if (reloading && System.currentTimeMillis() - reloadStart >= reloadMs) {
            ammo = maxAmmo; reloading = false;
        }
    }

    public static Gun[] createAll() { return new Gun[]{pistol(), smg(), shotgun()}; }

    public static Gun pistol() {
        Gun g = new Gun(); g.name="Pistol"; g.maxAmmo=12; g.ammo=12;
        g.fireRate=3f; g.damage=34f; g.bulletSpeed=640f;
        g.pellets=1; g.spread=0.04f; g.reloadMs=1200; g.color=0xFF4FC3F7; return g;
    }
    public static Gun smg() {
        Gun g = new Gun(); g.name="SMG"; g.maxAmmo=30; g.ammo=30;
        g.fireRate=10f; g.damage=14f; g.bulletSpeed=520f;
        g.pellets=1; g.spread=0.12f; g.reloadMs=2000; g.color=0xFF81C784; return g;
    }
    public static Gun shotgun() {
        Gun g = new Gun(); g.name="Shotgun"; g.maxAmmo=8; g.ammo=8;
        g.fireRate=1.1f; g.damage=18f; g.bulletSpeed=480f;
        g.pellets=6; g.spread=0.32f; g.reloadMs=2400; g.color=0xFFFF8A65; return g;
    }
}
