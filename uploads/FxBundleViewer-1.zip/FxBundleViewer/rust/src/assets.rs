//! Decoders that turn generic `Value` trees of Unity objects into plain render-ready data:
//! meshes (including Unity's compressed mesh format and blend shapes), textures and materials.

use crate::bundle::BundleFile;
use crate::util::*;
use crate::value::Value;

// =============================================================================================
// Mesh
// =============================================================================================

#[derive(Clone)]
pub struct BlendFrame {
    pub weight: f32,
    pub deltas: Vec<(u32, [f32; 3])>,
}

#[derive(Clone)]
pub struct BlendChannel {
    pub name: String,
    pub frames: Vec<BlendFrame>,
}

#[derive(Clone)]
pub struct MeshData {
    pub name: String,
    pub positions: Vec<[f32; 3]>,
    pub uvs: Vec<[f32; 2]>,
    pub colors: Vec<[f32; 4]>,
    /// Triangle lists, one per submesh.
    pub submeshes: Vec<Vec<u32>>,
    pub blend: Vec<BlendChannel>,
    pub bmin: [f32; 3],
    pub bmax: [f32; 3],
    pub compressed: bool,
}

/// Unpacks `PackedFloatVector` data: `item_count` floats per chunk, `chunks` chunks (None = all).
fn unpack_floats(pv: &Value, item_count: usize, start: usize, chunks: Option<usize>) -> Vec<f32> {
    let mut out: Vec<f32> = Vec::new();
    let n = pv.get("m_NumItems").i64().max(0) as usize;
    let bs = pv.get("m_BitSize").i64().max(0) as usize;
    let data = pv.get("m_Data").bytes();
    let range = pv.get("m_Range").f32();
    let start_v = pv.get("m_Start").f32();
    if bs == 0 || bs > 32 || item_count == 0 {
        return out;
    }
    let num_chunks = match chunks {
        Some(c) => c,
        None => n / item_count,
    };
    let bitpos = bs * start;
    let mut ip = bitpos / 8;
    let mut bp = bitpos % 8;
    let mask: u64 = (1u64 << bs) - 1;
    let total = num_chunks * item_count;
    out.reserve(total);
    for _ in 0..total {
        let mut x: u64 = 0;
        let mut bits = 0usize;
        while bits < bs {
            if ip >= data.len() {
                return out;
            }
            x |= ((data[ip] as u64) >> bp) << bits;
            let take = std::cmp::min(bs - bits, 8 - bp);
            bp += take;
            bits += take;
            if bp == 8 {
                ip += 1;
                bp = 0;
            }
        }
        x &= mask;
        out.push((x as f32) * range / (mask as f32) + start_v);
    }
    out
}

/// Unpacks `PackedIntVector` data.
fn unpack_ints(pv: &Value) -> Vec<u32> {
    let mut out: Vec<u32> = Vec::new();
    let n = pv.get("m_NumItems").i64().max(0) as usize;
    let bs = pv.get("m_BitSize").i64().max(0) as usize;
    let data = pv.get("m_Data").bytes();
    if bs == 0 || bs > 32 {
        return out;
    }
    let mask: u64 = (1u64 << bs) - 1;
    let mut ip = 0usize;
    let mut bp = 0usize;
    out.reserve(n);
    for _ in 0..n {
        let mut x: u64 = 0;
        let mut bits = 0usize;
        while bits < bs {
            if ip >= data.len() {
                return out;
            }
            x |= ((data[ip] as u64) >> bp) << bits;
            let take = std::cmp::min(bs - bits, 8 - bp);
            bp += take;
            bits += take;
            if bp == 8 {
                ip += 1;
                bp = 0;
            }
        }
        out.push((x & mask) as u32);
    }
    out
}

#[derive(Clone, Copy, PartialEq)]
enum VKind {
    F32,
    F16,
    Un8,
    Sn8,
    Un16,
    Sn16,
    U8,
    S8,
    U16,
    S16,
    U32,
    S32,
}

fn vertex_kind(format: i64, major: u32) -> (VKind, usize) {
    if major >= 2019 {
        match format {
            0 => (VKind::F32, 4),
            1 => (VKind::F16, 2),
            2 => (VKind::Un8, 1),
            3 => (VKind::Sn8, 1),
            4 => (VKind::Un16, 2),
            5 => (VKind::Sn16, 2),
            6 => (VKind::U8, 1),
            7 => (VKind::S8, 1),
            8 => (VKind::U16, 2),
            9 => (VKind::S16, 2),
            10 => (VKind::U32, 4),
            _ => (VKind::S32, 4),
        }
    } else {
        match format {
            0 => (VKind::F32, 4),
            1 => (VKind::F16, 2),
            2 | 3 => (VKind::Un8, 1),
            4 => (VKind::Sn8, 1),
            5 => (VKind::Un16, 2),
            6 => (VKind::Sn16, 2),
            7 => (VKind::U8, 1),
            8 => (VKind::S8, 1),
            9 => (VKind::U16, 2),
            10 => (VKind::S16, 2),
            11 => (VKind::U32, 4),
            _ => (VKind::S32, 4),
        }
    }
}

fn f16_to_f32(h: u16) -> f32 {
    let s = ((h >> 15) & 1) as u32;
    let e = ((h >> 10) & 0x1F) as u32;
    let m = (h & 0x3FF) as u32;
    let bits: u32 = if e == 0 {
        if m == 0 {
            s << 31
        } else {
            let mut mm = m;
            let mut ee: i32 = -14;
            while (mm & 0x400) == 0 {
                mm <<= 1;
                ee -= 1;
            }
            mm &= 0x3FF;
            (s << 31) | (((ee + 127) as u32) << 23) | (mm << 13)
        }
    } else if e == 31 {
        (s << 31) | (0xFFu32 << 23) | (m << 13)
    } else {
        (s << 31) | ((e + 112) << 23) | (m << 13)
    };
    f32::from_bits(bits)
}

fn read_attr(data: &[u8], p: usize, kind: VKind, dim: usize) -> [f32; 4] {
    let mut out = [0.0f32; 4];
    let size = match kind {
        VKind::F32 | VKind::U32 | VKind::S32 => 4,
        VKind::F16 | VKind::Un16 | VKind::Sn16 | VKind::U16 | VKind::S16 => 2,
        _ => 1,
    };
    for d in 0..dim.min(4) {
        let o = p + d * size;
        if o + size > data.len() {
            break;
        }
        out[d] = match kind {
            VKind::F32 => f32::from_le_bytes([data[o], data[o + 1], data[o + 2], data[o + 3]]),
            VKind::F16 => f16_to_f32(u16::from_le_bytes([data[o], data[o + 1]])),
            VKind::Un8 => data[o] as f32 / 255.0,
            VKind::Sn8 => ((data[o] as i8) as f32 / 127.0).max(-1.0),
            VKind::Un16 => u16::from_le_bytes([data[o], data[o + 1]]) as f32 / 65535.0,
            VKind::Sn16 => ((i16::from_le_bytes([data[o], data[o + 1]])) as f32 / 32767.0).max(-1.0),
            VKind::U8 => data[o] as f32,
            VKind::S8 => (data[o] as i8) as f32,
            VKind::U16 => u16::from_le_bytes([data[o], data[o + 1]]) as f32,
            VKind::S16 => i16::from_le_bytes([data[o], data[o + 1]]) as f32,
            VKind::U32 => u32::from_le_bytes([data[o], data[o + 1], data[o + 2], data[o + 3]]) as f32,
            VKind::S32 => i32::from_le_bytes([data[o], data[o + 1], data[o + 2], data[o + 3]]) as f32,
        };
    }
    out
}

/// Returns (stream, offset, kind, dimension) of a vertex channel, if present.
fn channel_info(chans: &[Value], ci: usize, major: u32) -> Option<(usize, usize, VKind, usize)> {
    if ci >= chans.len() {
        return None;
    }
    let c = &chans[ci];
    let dim = (c.get("dimension").i64() & 0xF) as usize;
    if dim == 0 {
        return None;
    }
    let (kind, _) = vertex_kind(c.get("format").i64(), major);
    Some((
        c.get("stream").i64().max(0) as usize,
        c.get("offset").i64().max(0) as usize,
        kind,
        dim,
    ))
}

fn kind_size(kind: VKind) -> usize {
    match kind {
        VKind::F32 | VKind::U32 | VKind::S32 => 4,
        VKind::F16 | VKind::Un16 | VKind::Sn16 | VKind::U16 | VKind::S16 => 2,
        _ => 1,
    }
}

fn push_triangles(out: &mut Vec<u32>, idx: &[u32], topology: i64, base: i64, vcount: usize) {
    let mut tri = |a: u32, b: u32, c: u32| {
        let a2 = (a as i64 + base) as u32;
        let b2 = (b as i64 + base) as u32;
        let c2 = (c as i64 + base) as u32;
        if (a2 as usize) < vcount && (b2 as usize) < vcount && (c2 as usize) < vcount {
            out.push(a2);
            out.push(b2);
            out.push(c2);
        }
    };
    match topology {
        0 => {
            for ch in idx.chunks(3) {
                if ch.len() == 3 {
                    tri(ch[0], ch[1], ch[2]);
                }
            }
        }
        1 => {
            if idx.len() >= 3 {
                for i in 0..idx.len() - 2 {
                    let (a, b, c) = (idx[i], idx[i + 1], idx[i + 2]);
                    if a == b || b == c || a == c {
                        continue;
                    }
                    if i % 2 == 0 {
                        tri(a, b, c);
                    } else {
                        tri(b, a, c);
                    }
                }
            }
        }
        2 => {
            for ch in idx.chunks(4) {
                if ch.len() == 4 {
                    tri(ch[0], ch[1], ch[2]);
                    tri(ch[0], ch[2], ch[3]);
                }
            }
        }
        _ => {}
    }
}

pub fn decode_mesh(v: &Value, major: u32) -> Res<MeshData> {
    let name = v.get("m_Name").str().to_string();
    let cm = v.get("m_CompressedMesh");
    let mut positions: Vec<[f32; 3]> = Vec::new();
    let mut uvs: Vec<[f32; 2]> = Vec::new();
    let mut colors: Vec<[f32; 4]> = Vec::new();
    let mut all_indices: Vec<u32> = Vec::new();
    let mut index_elem: usize = 2;
    let compressed = cm.get("m_Vertices").get("m_NumItems").i64() > 0;

    if compressed {
        let pf = unpack_floats(cm.get("m_Vertices"), 3, 0, None);
        let mut i = 0usize;
        while i + 2 < pf.len() {
            positions.push([pf[i], pf[i + 1], pf[i + 2]]);
            i += 3;
        }
        let nv = positions.len();

        let uvpv = cm.get("m_UV");
        if uvpv.get("m_NumItems").i64() > 0 {
            let info = cm.get("m_UVInfo").u32();
            if info != 0 {
                let mut src = 0usize;
                for ch in 0..8u32 {
                    let bits = (info >> (ch * 4)) & 0xF;
                    if bits & 4 != 0 {
                        let dim = 1 + (bits & 3) as usize;
                        let arr = unpack_floats(uvpv, dim, src, Some(nv));
                        if ch == 0 {
                            for k in 0..nv {
                                if k * dim + 1 < arr.len() {
                                    uvs.push([arr[k * dim], arr[k * dim + 1]]);
                                } else if k * dim < arr.len() {
                                    uvs.push([arr[k * dim], 0.0]);
                                }
                            }
                        }
                        src += dim * nv;
                    }
                }
            } else {
                let arr = unpack_floats(uvpv, 2, 0, Some(nv));
                for k in 0..nv {
                    if k * 2 + 1 < arr.len() {
                        uvs.push([arr[k * 2], arr[k * 2 + 1]]);
                    }
                }
            }
        }

        let cpv = cm.get("m_FloatColors");
        if cpv.get("m_NumItems").i64() > 0 {
            let arr = unpack_floats(cpv, 1, 0, None);
            for k in 0..nv {
                if k * 4 + 3 < arr.len() {
                    colors.push([arr[k * 4], arr[k * 4 + 1], arr[k * 4 + 2], arr[k * 4 + 3]]);
                }
            }
        }

        all_indices = unpack_ints(cm.get("m_Triangles"));
        index_elem = 2;
    } else {
        let vd = v.get("m_VertexData");
        let nv = vd.get("m_VertexCount").i64().max(0) as usize;
        let chans = vd.get("m_Channels").list();
        let data = vd.get("m_DataSize").bytes();
        if nv == 0 || chans.is_empty() || data.is_empty() {
            return Err(format!("mesh '{}' has no vertex data", name));
        }
        let mut nstreams = 0usize;
        for c in chans.iter() {
            if (c.get("dimension").i64() & 0xF) > 0 {
                let s = c.get("stream").i64().max(0) as usize + 1;
                if s > nstreams {
                    nstreams = s;
                }
            }
        }
        if nstreams == 0 || nstreams > 8 {
            return Err(format!("mesh '{}' has an unexpected stream layout", name));
        }
        let mut strides = vec![0usize; nstreams];
        for c in chans.iter() {
            let dim = (c.get("dimension").i64() & 0xF) as usize;
            if dim > 0 {
                let s = c.get("stream").i64().max(0) as usize;
                let (kind, _) = vertex_kind(c.get("format").i64(), major);
                strides[s] += dim * kind_size(kind);
            }
        }
        let mut offs = vec![0usize; nstreams];
        let mut o = 0usize;
        for s in 0..nstreams {
            offs[s] = o;
            o += strides[s] * nv;
            o = (o + 15) & !15usize;
        }

        if let Some((stream, off, kind, dim)) = channel_info(chans, 0, major) {
            for i in 0..nv {
                let p = offs[stream] + i * strides[stream] + off;
                let a = read_attr(data, p, kind, dim);
                positions.push([a[0], a[1], a[2]]);
            }
        } else {
            return Err(format!("mesh '{}' has no position channel", name));
        }
        if let Some((stream, off, kind, dim)) = channel_info(chans, 3, major) {
            for i in 0..nv {
                let p = offs[stream] + i * strides[stream] + off;
                let a = read_attr(data, p, kind, dim);
                colors.push([a[0], a[1], a[2], if dim >= 4 { a[3] } else { 1.0 }]);
            }
        }
        if let Some((stream, off, kind, dim)) = channel_info(chans, 4, major) {
            for i in 0..nv {
                let p = offs[stream] + i * strides[stream] + off;
                let a = read_attr(data, p, kind, dim);
                uvs.push([a[0], a[1]]);
            }
        }

        let ib = v.get("m_IndexBuffer").bytes();
        let fmt = v.get("m_IndexFormat").i64();
        if fmt == 1 {
            index_elem = 4;
            let mut i = 0usize;
            while i + 4 <= ib.len() {
                all_indices.push(u32::from_le_bytes([ib[i], ib[i + 1], ib[i + 2], ib[i + 3]]));
                i += 4;
            }
        } else {
            index_elem = 2;
            let mut i = 0usize;
            while i + 2 <= ib.len() {
                all_indices.push(u16::from_le_bytes([ib[i], ib[i + 1]]) as u32);
                i += 2;
            }
        }
    }

    let nv = positions.len();
    let mut submeshes: Vec<Vec<u32>> = Vec::new();
    for s in v.get("m_SubMeshes").list().iter() {
        let first_byte = s.get("firstByte").i64().max(0) as usize;
        let count = s.get("indexCount").i64().max(0) as usize;
        let topology = s.get("topology").i64();
        let base_vertex = s.get("baseVertex").i64();
        let first = first_byte / index_elem;
        let end = std::cmp::min(first.saturating_add(count), all_indices.len());
        let mut tris: Vec<u32> = Vec::new();
        if first < end {
            push_triangles(&mut tris, &all_indices[first..end], topology, base_vertex, nv);
        }
        submeshes.push(tris);
    }
    if submeshes.is_empty() && !all_indices.is_empty() {
        let mut tris: Vec<u32> = Vec::new();
        push_triangles(&mut tris, &all_indices[..], 0, 0, nv);
        submeshes.push(tris);
    }

    let mut bmin = [f32::MAX; 3];
    let mut bmax = [f32::MIN; 3];
    for p in positions.iter() {
        for k in 0..3 {
            if p[k] < bmin[k] {
                bmin[k] = p[k];
            }
            if p[k] > bmax[k] {
                bmax[k] = p[k];
            }
        }
    }
    if positions.is_empty() {
        bmin = [0.0; 3];
        bmax = [0.0; 3];
    }

    // blend shapes
    let shapes = v.get("m_Shapes");
    let sverts = shapes.get("vertices").list();
    let sh = shapes.get("shapes").list();
    let fw = shapes.get("fullWeights").list();
    let mut blend: Vec<BlendChannel> = Vec::new();
    for c in shapes.get("channels").list().iter() {
        let cname = c.get("name").str().to_string();
        let fi = c.get("frameIndex").i64().max(0) as usize;
        let fc = c.get("frameCount").i64().max(0) as usize;
        let mut frames: Vec<BlendFrame> = Vec::new();
        for f in 0..fc {
            let si = fi + f;
            if si >= sh.len() {
                break;
            }
            let first = sh[si].get("firstVertex").i64().max(0) as usize;
            let cnt = sh[si].get("vertexCount").i64().max(0) as usize;
            let last = std::cmp::min(first.saturating_add(cnt), sverts.len());
            let mut deltas: Vec<(u32, [f32; 3])> = Vec::new();
            let mut k = first;
            while k < last {
                let sv = &sverts[k];
                let d = sv.get("vertex");
                deltas.push((sv.get("index").u32(), [d.get("x").f32(), d.get("y").f32(), d.get("z").f32()]));
                k += 1;
            }
            let weight = if si < fw.len() { fw[si].f32() } else { 100.0 };
            frames.push(BlendFrame { weight, deltas });
        }
        blend.push(BlendChannel { name: cname, frames });
    }

    Ok(MeshData { name, positions, uvs, colors, submeshes, blend, bmin, bmax, compressed })
}

/// Applies blend shape weights (0-100) to the base positions. None when nothing changes.
pub fn apply_blend(mesh: &MeshData, weights: &[f32]) -> Option<Vec<[f32; 3]>> {
    if mesh.blend.is_empty() {
        return None;
    }
    let mut any = false;
    for w in weights.iter() {
        if w.abs() > 1e-4 {
            any = true;
        }
    }
    if !any {
        return None;
    }
    let mut out = mesh.positions.clone();
    for (ci, ch) in mesh.blend.iter().enumerate() {
        let w = if ci < weights.len() { weights[ci] } else { 0.0 };
        if w.abs() <= 1e-4 || ch.frames.is_empty() {
            continue;
        }
        let n = ch.frames.len();
        let mut parts: Vec<(usize, f32)> = Vec::new();
        if n == 1 || w <= ch.frames[0].weight {
            let fw = ch.frames[0].weight;
            parts.push((0, if fw.abs() > 1e-6 { w / fw } else { 0.0 }));
        } else if w >= ch.frames[n - 1].weight {
            let fw = ch.frames[n - 1].weight;
            parts.push((n - 1, if fw.abs() > 1e-6 { w / fw } else { 1.0 }));
        } else {
            let mut i = 0usize;
            while i + 1 < n && ch.frames[i + 1].weight < w {
                i += 1;
            }
            let a = ch.frames[i].weight;
            let b = ch.frames[i + 1].weight;
            let t = if (b - a).abs() > 1e-6 { (w - a) / (b - a) } else { 0.0 };
            parts.push((i, 1.0 - t));
            parts.push((i + 1, t));
        }
        for (fi, f) in parts.iter() {
            for (vi, d) in ch.frames[*fi].deltas.iter() {
                let k = *vi as usize;
                if k < out.len() {
                    out[k][0] += d[0] * *f;
                    out[k][1] += d[1] * *f;
                    out[k][2] += d[2] * *f;
                }
            }
        }
    }
    Some(out)
}

// =============================================================================================
// Texture
// =============================================================================================

pub enum TexPayload {
    /// RGBA8, bottom row first (OpenGL order).
    Raw(Vec<u8>),
    /// Block-compressed data uploaded as-is with glCompressedTexImage2D.
    Compressed { gl_format: u32, data: Vec<u8> },
    Unsupported(String),
}

pub struct TexData {
    pub name: String,
    pub width: i32,
    pub height: i32,
    pub format: i32,
    pub has_alpha: bool,
    pub wrap_u: i32,
    pub wrap_v: i32,
    pub payload: TexPayload,
}

pub fn texture_format_name(f: i32) -> String {
    let s = match f {
        1 => "Alpha8",
        2 => "ARGB4444",
        3 => "RGB24",
        4 => "RGBA32",
        5 => "ARGB32",
        7 => "RGB565",
        9 => "R16",
        10 => "DXT1",
        12 => "DXT5",
        13 => "RGBA4444",
        14 => "BGRA32",
        28 => "DXT1Crunched",
        29 => "DXT5Crunched",
        30 => "PVRTC_RGB2",
        31 => "PVRTC_RGBA2",
        32 => "PVRTC_RGB4",
        33 => "PVRTC_RGBA4",
        34 => "ETC_RGB4",
        41 => "EAC_R",
        42 => "EAC_R_SIGNED",
        43 => "EAC_RG",
        44 => "EAC_RG_SIGNED",
        45 => "ETC2_RGB",
        46 => "ETC2_RGBA1",
        47 => "ETC2_RGBA8",
        48 => "ASTC_RGB_4x4",
        49 => "ASTC_RGB_5x5",
        50 => "ASTC_RGB_6x6",
        51 => "ASTC_RGB_8x8",
        52 => "ASTC_RGB_10x10",
        53 => "ASTC_RGB_12x12",
        54 => "ASTC_RGBA_4x4",
        55 => "ASTC_RGBA_5x5",
        56 => "ASTC_RGBA_6x6",
        57 => "ASTC_RGBA_8x8",
        58 => "ASTC_RGBA_10x10",
        59 => "ASTC_RGBA_12x12",
        62 => "RG16",
        63 => "R8",
        64 => "ETC_RGB4Crunched",
        65 => "ETC2_RGBA8Crunched",
        _ => "",
    };
    if s.is_empty() {
        format!("format{}", f)
    } else {
        s.to_string()
    }
}

pub fn texture_has_alpha(f: i32) -> bool {
    matches!(f, 1 | 2 | 4 | 5 | 12 | 13 | 14 | 17 | 29 | 31 | 33 | 46 | 47 | 54..=59 | 61 | 65)
}

fn block_count(w: usize, h: usize, bw: usize, bh: usize) -> usize {
    let bx = std::cmp::max((w + bw - 1) / bw, 1);
    let by = std::cmp::max((h + bh - 1) / bh, 1);
    bx * by
}

fn astc_block(f: i32) -> Option<(usize, usize, u32)> {
    match f {
        48 | 54 => Some((4, 4, 0x93B0)),
        49 | 55 => Some((5, 5, 0x93B2)),
        50 | 56 => Some((6, 6, 0x93B4)),
        51 | 57 => Some((8, 8, 0x93B7)),
        52 | 58 => Some((10, 10, 0x93BB)),
        53 | 59 => Some((12, 12, 0x93BD)),
        _ => None,
    }
}

fn rgb565(c: u16) -> [u8; 3] {
    let r = ((c >> 11) & 31) as u32;
    let g = ((c >> 5) & 63) as u32;
    let b = (c & 31) as u32;
    [((r * 255 + 15) / 31) as u8, ((g * 255 + 31) / 63) as u8, ((b * 255 + 15) / 31) as u8]
}

fn bc_color_palette(block: &[u8], four_color: bool) -> [[u8; 4]; 4] {
    let c0 = u16::from_le_bytes([block[0], block[1]]);
    let c1 = u16::from_le_bytes([block[2], block[3]]);
    let a = rgb565(c0);
    let b = rgb565(c1);
    let mut pal = [[0u8; 4]; 4];
    pal[0] = [a[0], a[1], a[2], 255];
    pal[1] = [b[0], b[1], b[2], 255];
    if c0 > c1 || four_color {
        for k in 0..3 {
            pal[2][k] = ((2 * a[k] as u32 + b[k] as u32) / 3) as u8;
            pal[3][k] = ((a[k] as u32 + 2 * b[k] as u32) / 3) as u8;
        }
        pal[2][3] = 255;
        pal[3][3] = 255;
    } else {
        for k in 0..3 {
            pal[2][k] = ((a[k] as u32 + b[k] as u32) / 2) as u8;
        }
        pal[2][3] = 255;
        pal[3] = [0, 0, 0, 0];
    }
    pal
}

fn decode_dxt(w: usize, h: usize, d: &[u8], dxt5: bool) -> Option<Vec<u8>> {
    let bw = (w + 3) / 4;
    let bh = (h + 3) / 4;
    let bsz = if dxt5 { 16 } else { 8 };
    if d.len() < bw * bh * bsz {
        return None;
    }
    let mut out = vec![0u8; w * h * 4];
    for by in 0..bh {
        for bx in 0..bw {
            let off = (by * bw + bx) * bsz;
            let cb = if dxt5 { &d[off + 8..off + 16] } else { &d[off..off + 8] };
            let pal = bc_color_palette(cb, dxt5);
            let idx = u32::from_le_bytes([cb[4], cb[5], cb[6], cb[7]]);
            let mut apal = [255u8; 8];
            let mut abits: u64 = 0;
            if dxt5 {
                let a0 = d[off] as u32;
                let a1 = d[off + 1] as u32;
                apal[0] = a0 as u8;
                apal[1] = a1 as u8;
                if a0 > a1 {
                    for i in 2..8u32 {
                        apal[i as usize] = (((8 - i) * a0 + (i - 1) * a1) / 7) as u8;
                    }
                } else {
                    for i in 2..6u32 {
                        apal[i as usize] = (((6 - i) * a0 + (i - 1) * a1) / 5) as u8;
                    }
                    apal[6] = 0;
                    apal[7] = 255;
                }
                for i in 0..6 {
                    abits |= (d[off + 2 + i] as u64) << (8 * i);
                }
            }
            for py in 0..4usize {
                for px in 0..4usize {
                    let x = bx * 4 + px;
                    let y = by * 4 + py;
                    if x >= w || y >= h {
                        continue;
                    }
                    let n = py * 4 + px;
                    let ci = ((idx >> (2 * n)) & 3) as usize;
                    let mut c = pal[ci];
                    if dxt5 {
                        c[3] = apal[((abits >> (3 * n)) & 7) as usize];
                    }
                    let o = (y * w + x) * 4;
                    out[o] = c[0];
                    out[o + 1] = c[1];
                    out[o + 2] = c[2];
                    out[o + 3] = c[3];
                }
            }
        }
    }
    Some(out)
}

/// Converts the uncompressed Unity texture formats to RGBA8.
fn to_rgba(format: i32, w: usize, h: usize, d: &[u8]) -> Option<Vec<u8>> {
    let n = w * h;
    let mut out = vec![255u8; n * 4];
    match format {
        1 => {
            if d.len() < n {
                return None;
            }
            for i in 0..n {
                out[i * 4 + 3] = d[i];
            }
        }
        63 => {
            if d.len() < n {
                return None;
            }
            for i in 0..n {
                out[i * 4] = d[i];
                out[i * 4 + 1] = d[i];
                out[i * 4 + 2] = d[i];
            }
        }
        2 | 13 | 7 | 9 | 62 => {
            if d.len() < n * 2 {
                return None;
            }
            for i in 0..n {
                let v = u16::from_le_bytes([d[i * 2], d[i * 2 + 1]]);
                let r: u8;
                let g: u8;
                let b: u8;
                let a: u8;
                match format {
                    2 => {
                        a = (((v >> 12) & 15) * 17) as u8;
                        r = (((v >> 8) & 15) * 17) as u8;
                        g = (((v >> 4) & 15) * 17) as u8;
                        b = ((v & 15) * 17) as u8;
                    }
                    13 => {
                        r = (((v >> 12) & 15) * 17) as u8;
                        g = (((v >> 8) & 15) * 17) as u8;
                        b = (((v >> 4) & 15) * 17) as u8;
                        a = ((v & 15) * 17) as u8;
                    }
                    7 => {
                        let c = rgb565(v);
                        r = c[0];
                        g = c[1];
                        b = c[2];
                        a = 255;
                    }
                    9 => {
                        let hi = (v >> 8) as u8;
                        r = hi;
                        g = hi;
                        b = hi;
                        a = 255;
                    }
                    _ => {
                        r = d[i * 2];
                        g = d[i * 2 + 1];
                        b = 0;
                        a = 255;
                    }
                }
                out[i * 4] = r;
                out[i * 4 + 1] = g;
                out[i * 4 + 2] = b;
                out[i * 4 + 3] = a;
            }
        }
        3 => {
            if d.len() < n * 3 {
                return None;
            }
            for i in 0..n {
                out[i * 4] = d[i * 3];
                out[i * 4 + 1] = d[i * 3 + 1];
                out[i * 4 + 2] = d[i * 3 + 2];
            }
        }
        4 => {
            if d.len() < n * 4 {
                return None;
            }
            out.copy_from_slice(&d[..n * 4]);
        }
        5 => {
            if d.len() < n * 4 {
                return None;
            }
            for i in 0..n {
                out[i * 4] = d[i * 4 + 1];
                out[i * 4 + 1] = d[i * 4 + 2];
                out[i * 4 + 2] = d[i * 4 + 3];
                out[i * 4 + 3] = d[i * 4];
            }
        }
        14 => {
            if d.len() < n * 4 {
                return None;
            }
            for i in 0..n {
                out[i * 4] = d[i * 4 + 2];
                out[i * 4 + 1] = d[i * 4 + 1];
                out[i * 4 + 2] = d[i * 4];
                out[i * 4 + 3] = d[i * 4 + 3];
            }
        }
        10 => return decode_dxt(w, h, d, false),
        12 => return decode_dxt(w, h, d, true),
        _ => return None,
    }
    Some(out)
}

pub fn decode_texture(v: &Value, files: &[BundleFile]) -> TexData {
    let name = v.get("m_Name").str().to_string();
    let width = v.get("m_Width").i32();
    let height = v.get("m_Height").i32();
    let format = v.get("m_TextureFormat").i32();
    let ts = v.get("m_TextureSettings");
    let wrap_u = if ts.has("m_WrapU") { ts.get("m_WrapU").i32() } else { ts.get("m_WrapMode").i32() };
    let wrap_v = if ts.has("m_WrapV") { ts.get("m_WrapV").i32() } else { ts.get("m_WrapMode").i32() };
    let has_alpha = texture_has_alpha(format);

    let mk = |payload: TexPayload| TexData {
        name: name.clone(),
        width,
        height,
        format,
        has_alpha,
        wrap_u,
        wrap_v,
        payload,
    };

    if width <= 0 || height <= 0 || width > 16384 || height > 16384 {
        return mk(TexPayload::Unsupported(format!("invalid size {}x{}", width, height)));
    }

    let mut data: Vec<u8> = v.get("image data").bytes().to_vec();
    if data.is_empty() {
        let sd = v.get("m_StreamData");
        let size = sd.get("size").i64().max(0) as usize;
        let off = sd.get("offset").i64().max(0) as usize;
        let path = sd.get("path").str();
        if size > 0 && !path.is_empty() {
            let fname = path.rsplit('/').next().unwrap_or("");
            let mut found = false;
            for f in files.iter() {
                if f.name.eq_ignore_ascii_case(fname) {
                    found = true;
                    if off + size <= f.data.len() {
                        data = f.data[off..off + size].to_vec();
                    } else {
                        return mk(TexPayload::Unsupported(format!("stream range outside '{}'", fname)));
                    }
                    break;
                }
            }
            if !found {
                return mk(TexPayload::Unsupported(format!("streamed resource '{}' not in bundle", fname)));
            }
        }
    }
    if data.is_empty() {
        return mk(TexPayload::Unsupported("texture has no pixel data".to_string()));
    }

    let w = width as usize;
    let h = height as usize;
    // block-compressed formats are uploaded directly
    let compressed: Option<(u32, usize)> = match format {
        34 | 45 => Some((0x9274, block_count(w, h, 4, 4) * 8)),
        46 => Some((0x9276, block_count(w, h, 4, 4) * 8)),
        47 => Some((0x9278, block_count(w, h, 4, 4) * 16)),
        41 => Some((0x9270, block_count(w, h, 4, 4) * 8)),
        42 => Some((0x9271, block_count(w, h, 4, 4) * 8)),
        43 => Some((0x9272, block_count(w, h, 4, 4) * 16)),
        44 => Some((0x9273, block_count(w, h, 4, 4) * 16)),
        48..=59 => match astc_block(format) {
            Some((bw, bh, gl)) => Some((gl, block_count(w, h, bw, bh) * 16)),
            None => None,
        },
        _ => None,
    };
    if let Some((gl_format, size)) = compressed {
        if data.len() < size {
            return mk(TexPayload::Unsupported(format!(
                "pixel data too short ({} < {} bytes)",
                data.len(),
                size
            )));
        }
        data.truncate(size);
        return mk(TexPayload::Compressed { gl_format, data });
    }
    match to_rgba(format, w, h, &data) {
        Some(rgba) => mk(TexPayload::Raw(rgba)),
        None => mk(TexPayload::Unsupported(format!(
            "texture format {} ({}) is not supported",
            format,
            texture_format_name(format)
        ))),
    }
}

// =============================================================================================
// Material
// =============================================================================================

#[derive(Clone)]
pub struct TexSlot {
    pub name: String,
    pub tex_path_id: i64,
    pub tex: Option<usize>,
    pub scale: [f32; 2],
    pub offset: [f32; 2],
}

#[derive(Clone)]
pub struct MaterialData {
    pub name: String,
    pub shader_file: i32,
    pub shader_id: i64,
    pub keywords: String,
    pub queue: i32,
    pub slots: Vec<TexSlot>,
    pub floats: Vec<(String, f32)>,
    pub colors: Vec<(String, [f32; 4])>,
}

impl MaterialData {
    /// First texture slot (in priority order) that has a texture assigned.
    pub fn slot(&self, names: &[&str]) -> Option<&TexSlot> {
        for n in names.iter() {
            for s in self.slots.iter() {
                if s.name == *n && s.tex.is_some() {
                    return Some(s);
                }
            }
        }
        None
    }

    pub fn float(&self, name: &str) -> Option<f32> {
        for (k, v) in self.floats.iter() {
            if k == name {
                return Some(*v);
            }
        }
        None
    }

    pub fn color(&self, name: &str) -> Option<[f32; 4]> {
        for (k, v) in self.colors.iter() {
            if k == name {
                return Some(*v);
            }
        }
        None
    }
}

pub fn decode_material(v: &Value) -> MaterialData {
    let sp = v.get("m_SavedProperties");
    let mut slots: Vec<TexSlot> = Vec::new();
    for t in sp.get("m_TexEnvs").list().iter() {
        let sec = t.get("second");
        let sc = sec.get("m_Scale");
        let of = sec.get("m_Offset");
        slots.push(TexSlot {
            name: t.get("first").str().to_string(),
            tex_path_id: sec.get("m_Texture").pptr_local(),
            tex: None,
            scale: [
                if sc.has("x") { sc.get("x").f32() } else { 1.0 },
                if sc.has("y") { sc.get("y").f32() } else { 1.0 },
            ],
            offset: [of.get("x").f32(), of.get("y").f32()],
        });
    }
    let mut floats: Vec<(String, f32)> = Vec::new();
    for t in sp.get("m_Floats").list().iter() {
        floats.push((t.get("first").str().to_string(), t.get("second").f32()));
    }
    let mut colors: Vec<(String, [f32; 4])> = Vec::new();
    for t in sp.get("m_Colors").list().iter() {
        colors.push((t.get("first").str().to_string(), t.get("second").rgba()));
    }
    let shader = v.get("m_Shader");
    MaterialData {
        name: v.get("m_Name").str().to_string(),
        shader_file: shader.get("m_FileID").i32(),
        shader_id: shader.get("m_PathID").i64(),
        keywords: v.get("m_ShaderKeywords").str().to_string(),
        queue: v.get("m_CustomRenderQueue").i32(),
        slots,
        floats,
        colors,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn half_float_conversion() {
        assert_eq!(f16_to_f32(0x3C00), 1.0);
        assert_eq!(f16_to_f32(0xC000), -2.0);
        assert_eq!(f16_to_f32(0x0000), 0.0);
    }

    #[test]
    fn unpack_ints_reads_bit_packed_values() {
        // three 6-bit values: 1, 2, 63 -> bits LSB first
        let v = (1u32) | (2u32 << 6) | (63u32 << 12);
        let data = vec![(v & 0xFF) as u8, ((v >> 8) & 0xFF) as u8, ((v >> 16) & 0xFF) as u8];
        let pv = Value::Map(vec![
            ("m_NumItems".to_string(), Value::UInt(3)),
            ("m_BitSize".to_string(), Value::UInt(6)),
            ("m_Data".to_string(), Value::Bytes(data)),
        ]);
        assert_eq!(unpack_ints(&pv), vec![1, 2, 63]);
    }

    #[test]
    fn astc_8x8_size_matches_sample_texture() {
        // 128x128 ASTC 8x8 = 256 blocks of 16 bytes = 4096 bytes (as in the sample bundles)
        assert_eq!(block_count(128, 128, 8, 8) * 16, 4096);
    }

    #[test]
    fn blend_weights_scale_deltas() {
        let mesh = MeshData {
            name: "m".to_string(),
            positions: vec![[0.0, 0.0, 0.0], [1.0, 0.0, 0.0]],
            uvs: vec![],
            colors: vec![],
            submeshes: vec![],
            blend: vec![BlendChannel {
                name: "s".to_string(),
                frames: vec![BlendFrame { weight: 100.0, deltas: vec![(1, [0.0, 2.0, 0.0])] }],
            }],
            bmin: [0.0; 3],
            bmax: [0.0; 3],
            compressed: false,
        };
        let r = apply_blend(&mesh, &[50.0]).unwrap();
        assert!((r[1][1] - 1.0).abs() < 1e-6);
        assert!(apply_blend(&mesh, &[0.0]).is_none());
    }
}
