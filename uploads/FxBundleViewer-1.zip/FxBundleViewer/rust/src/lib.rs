//! FxView core: reads Unity 2017.4-2022 AssetBundles (UnityFS) that contain visual effects
//! (meshes, materials, textures, legacy/Animator clips, particle systems) and renders them
//! with OpenGL ES 3.0. Everything except `gles`, `render` and `jni_api` is plain Rust that
//! also builds (and is unit tested) on the host.
#![allow(dead_code, unused_variables, unused_mut, unused_imports, unused_assignments, unused_macros)]

// Logging macros must be defined before the modules that use them.
macro_rules! log_i {
    ($($arg:tt)*) => { $crate::util::log('I', &format!($($arg)*)) };
}
macro_rules! log_w {
    ($($arg:tt)*) => { $crate::util::log('W', &format!($($arg)*)) };
}
macro_rules! log_e {
    ($($arg:tt)*) => { $crate::util::log('E', &format!($($arg)*)) };
}

pub mod util;
pub mod reader;
pub mod compress;
pub mod bundle;
pub mod value;
pub mod serialized;
pub mod assets;
pub mod anim;
pub mod particles;
pub mod effect;
pub mod camera;
pub mod app;

#[cfg(target_os = "android")]
mod gles;
#[cfg(target_os = "android")]
mod render;
#[cfg(target_os = "android")]
mod jni_api;
