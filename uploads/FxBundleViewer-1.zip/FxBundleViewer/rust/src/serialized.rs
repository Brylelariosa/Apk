//! Unity SerializedFile reader (format versions 17-22, i.e. Unity 2017.4 - 2022.x). Objects are
//! decoded generically through the embedded type trees into `Value`s.

use crate::reader::Reader;
use crate::util::Res;
use crate::value::Value;

const COMMON_STRINGS: &str = "\
    AABB\0AnimationClip\0AnimationCurve\0AnimationState\0Array\0Base\0BitField\0bitset\0bool\0\
    char\0ColorRGBA\0Component\0data\0deque\0double\0dynamic_array\0FastPropertyName\0first\0\
    float\0Font\0GameObject\0Generic Mono\0GradientNEW\0GUID\0GUIStyle\0int\0list\0long long\0\
    map\0Matrix4x4f\0MdFour\0MonoBehaviour\0MonoScript\0m_ByteSize\0m_Curve\0\
    m_EditorClassIdentifier\0m_EditorHideFlags\0m_Enabled\0m_ExtensionPtr\0m_GameObject\0\
    m_Index\0m_IsArray\0m_IsStatic\0m_MetaFlag\0m_Name\0m_ObjectHideFlags\0m_PrefabInternal\0\
    m_PrefabParentObject\0m_Script\0m_StaticEditorFlags\0m_Type\0m_Version\0Object\0pair\0\
    PPtr<Component>\0PPtr<GameObject>\0PPtr<Material>\0PPtr<MonoBehaviour>\0PPtr<MonoScript>\0\
    PPtr<Object>\0PPtr<Prefab>\0PPtr<Sprite>\0PPtr<TextAsset>\0PPtr<Texture>\0\
    PPtr<Texture2D>\0PPtr<Transform>\0Prefab\0Quaternionf\0Rectf\0RectInt\0RectOffset\0\
    second\0set\0short\0size\0SInt16\0SInt32\0SInt64\0SInt8\0staticvector\0string\0TextAsset\0\
    TextMesh\0Texture\0Texture2D\0Transform\0TypelessData\0UInt16\0UInt32\0UInt64\0UInt8\0\
    unsigned int\0unsigned long long\0unsigned short\0vector\0Vector2f\0Vector3f\0Vector4f\0\
    m_ScriptingClassIdentifier\0Gradient\0Type*\0int2_storage\0int3_storage\0BoundsInt\0\
    m_CorrespondingSourceObject\0m_PrefabInstance\0m_PrefabAsset\0FileSize\0Hash128\0";

pub struct TypeNode {
    pub type_name: String,
    pub name: String,
    pub meta_flag: u32,
    pub is_array: bool,
    pub children: Vec<TypeNode>,
}

pub struct SerType {
    pub class_id: i32,
    pub root: Option<TypeNode>,
}

pub struct ObjInfo {
    pub path_id: i64,
    pub offset: usize,
    pub size: usize,
    pub type_index: usize,
    pub class_id: i32,
}

pub struct SerializedFile {
    pub version: u32,
    pub unity_version: String,
    pub platform: i32,
    pub has_type_tree: bool,
    pub big_endian: bool,
    pub types: Vec<SerType>,
    pub objects: Vec<ObjInfo>,
    pub externals: Vec<String>,
    data: Vec<u8>,
}

struct Meta {
    version: u32,
    unity_version: String,
    platform: i32,
    has_type_tree: bool,
    big_endian: bool,
    types: Vec<SerType>,
    objects: Vec<ObjInfo>,
    externals: Vec<String>,
}

struct FlatNode {
    level: u8,
    is_array: bool,
    type_off: u32,
    name_off: u32,
    meta: u32,
}

fn tree_string(sbuf: &[u8], off: u32) -> String {
    let (src, start): (&[u8], usize) = if off & 0x8000_0000 != 0 {
        (COMMON_STRINGS.as_bytes(), (off & 0x7FFF_FFFF) as usize)
    } else {
        (sbuf, off as usize)
    };
    if start >= src.len() {
        return String::from("?");
    }
    let mut end = start;
    while end < src.len() && src[end] != 0 {
        end += 1;
    }
    String::from_utf8_lossy(&src[start..end]).to_string()
}

fn build_tree(flat: &Vec<FlatNode>, names: &Vec<(String, String)>, idx: &mut usize) -> TypeNode {
    let i = *idx;
    let level = flat[i].level;
    let mut node = TypeNode {
        type_name: names[i].0.clone(),
        name: names[i].1.clone(),
        meta_flag: flat[i].meta,
        is_array: flat[i].is_array,
        children: Vec::new(),
    };
    *idx += 1;
    while *idx < flat.len() && flat[*idx].level > level {
        let child = build_tree(flat, names, idx);
        node.children.push(child);
    }
    node
}

fn read_type_tree(r: &mut Reader, version: u32) -> Res<TypeNode> {
    let count = r.i32()?;
    let sbs = r.i32()?;
    if count <= 0 || count > 500_000 || sbs < 0 || sbs > 64_000_000 {
        return Err(format!("bad type tree header ({} nodes, {} string bytes)", count, sbs));
    }
    let mut flat: Vec<FlatNode> = Vec::with_capacity(count as usize);
    for _ in 0..count {
        let _node_version = r.u16()?;
        let level = r.u8()?;
        let type_flags = r.u8()?;
        let type_off = r.u32()?;
        let name_off = r.u32()?;
        let _byte_size = r.i32()?;
        let _index = r.i32()?;
        let meta = r.u32()?;
        if version >= 19 {
            r.skip(8)?;
        }
        flat.push(FlatNode { level, is_array: (type_flags & 1) != 0, type_off, name_off, meta });
    }
    let sbuf = r.bytes(sbs as usize)?;
    let mut names: Vec<(String, String)> = Vec::with_capacity(flat.len());
    for f in flat.iter() {
        names.push((tree_string(sbuf, f.type_off), tree_string(sbuf, f.name_off)));
    }
    let mut idx = 0usize;
    Ok(build_tree(&flat, &names, &mut idx))
}

fn read_type(r: &mut Reader, version: u32, has_tree: bool) -> Res<SerType> {
    let class_id = r.i32()?;
    if version >= 16 {
        let _stripped = r.u8()?;
    }
    if version >= 17 {
        let _script_index = r.i16()?;
    }
    if version >= 13 {
        if class_id == 114 {
            r.skip(16)?; // script id hash
        }
        r.skip(16)?; // old type hash
    }
    let mut root: Option<TypeNode> = None;
    if has_tree {
        root = Some(read_type_tree(r, version)?);
        if version >= 21 {
            let deps = r.i32()?;
            if deps < 0 || deps > 1_000_000 {
                return Err("bad type dependency count".to_string());
            }
            r.skip((deps as usize) * 4)?;
        }
    }
    Ok(SerType { class_id, root })
}

fn parse_meta(data: &[u8]) -> Res<Meta> {
    if data.len() < 32 {
        return Err("serialized file too small".to_string());
    }
    let mut r = Reader::new_be(data);
    let _meta_size = r.u32()?;
    let _file_size = r.u32()?;
    let version = r.u32()?;
    let mut data_offset = r.u32()? as u64;
    if version < 17 || version > 22 {
        return Err(format!(
            "unsupported serialized file version {} (supported: 17-22, Unity 2017.4+)",
            version
        ));
    }
    let endian = r.u8()?;
    r.skip(3)?;
    if version >= 22 {
        let _meta_size = r.u32()?;
        let _file_size = r.i64()?;
        data_offset = r.i64()? as u64;
        let _unknown = r.i64()?;
    }
    r.big = endian != 0;

    let unity_version = r.cstr()?;
    let platform = r.i32()?;
    let has_tree = r.u8()? != 0;
    let type_count = r.i32()?;
    if type_count < 0 || type_count > 100_000 {
        return Err("bad type count".to_string());
    }
    let mut types: Vec<SerType> = Vec::with_capacity(type_count as usize);
    for _ in 0..type_count {
        types.push(read_type(&mut r, version, has_tree)?);
    }

    let obj_count = r.i32()?;
    if obj_count < 0 || obj_count > 5_000_000 {
        return Err("bad object count".to_string());
    }
    let mut objects: Vec<ObjInfo> = Vec::with_capacity(obj_count as usize);
    for _ in 0..obj_count {
        r.align(4);
        let path_id = r.i64()?;
        let start = if version >= 22 { r.i64()? as u64 } else { r.u32()? as u64 };
        let size = r.u32()? as usize;
        let type_index = r.i32()?;
        if type_index < 0 || (type_index as usize) >= types.len() {
            return Err(format!("object {} has invalid type index {}", path_id, type_index));
        }
        let class_id = types[type_index as usize].class_id;
        objects.push(ObjInfo {
            path_id,
            offset: (start + data_offset) as usize,
            size,
            type_index: type_index as usize,
            class_id,
        });
    }

    // script types (unused) and external file references
    let script_count = r.i32()?;
    if script_count < 0 || script_count > 1_000_000 {
        return Err("bad script type count".to_string());
    }
    for _ in 0..script_count {
        let _file_index = r.i32()?;
        r.align(4);
        let _local_id = r.i64()?;
    }
    let ext_count = r.i32()?;
    if ext_count < 0 || ext_count > 100_000 {
        return Err("bad external count".to_string());
    }
    let mut externals: Vec<String> = Vec::new();
    for _ in 0..ext_count {
        let _temp = r.cstr()?;
        r.skip(16)?; // guid
        let _kind = r.i32()?;
        let path = r.cstr()?;
        externals.push(path);
    }

    Ok(Meta {
        version,
        unity_version,
        platform,
        has_type_tree: has_tree,
        big_endian: endian != 0,
        types,
        objects,
        externals,
    })
}

const MAX_DEPTH: usize = 48;

fn read_value(node: &TypeNode, r: &mut Reader, depth: usize) -> Res<Value> {
    if depth > MAX_DEPTH {
        return Err("type tree nesting too deep".to_string());
    }
    let mut align = (node.meta_flag & 0x4000) != 0;
    let v: Value = match node.type_name.as_str() {
        "SInt8" => Value::Int(r.i8()? as i64),
        "UInt8" | "char" => Value::UInt(r.u8()? as u64),
        "SInt16" | "short" => Value::Int(r.i16()? as i64),
        "UInt16" | "unsigned short" => Value::UInt(r.u16()? as u64),
        "SInt32" | "int" => Value::Int(r.i32()? as i64),
        "UInt32" | "unsigned int" | "Type*" => Value::UInt(r.u32()? as u64),
        "SInt64" | "long long" => Value::Int(r.i64()?),
        "UInt64" | "unsigned long long" | "FileSize" => Value::UInt(r.u64()?),
        "float" => Value::Float(r.f32()? as f64),
        "double" => Value::Float(r.f64()?),
        "bool" => Value::Bool(r.u8()? != 0),
        "string" => {
            let n = r.i32()?;
            if n < 0 || (n as usize) > r.remaining() {
                return Err("bad string length".to_string());
            }
            let b = r.bytes(n as usize)?;
            r.align(4);
            align = false;
            Value::Str(String::from_utf8_lossy(b).to_string())
        }
        "TypelessData" => {
            let n = r.i32()?;
            if n < 0 || (n as usize) > r.remaining() {
                return Err("bad data length".to_string());
            }
            Value::Bytes(r.bytes(n as usize)?.to_vec())
        }
        _ => {
            if node.children.len() == 1 && node.children[0].is_array {
                let arr = &node.children[0];
                if (arr.meta_flag & 0x4000) != 0 {
                    align = true;
                }
                if arr.children.len() < 2 {
                    return Err("malformed array node".to_string());
                }
                let n = r.i32()?;
                if n < 0 {
                    return Err("negative array length".to_string());
                }
                let n = n as usize;
                let el = &arr.children[1];
                if (el.type_name == "UInt8" || el.type_name == "SInt8") && el.children.is_empty() {
                    if n > r.remaining() {
                        return Err("byte array longer than data".to_string());
                    }
                    Value::Bytes(r.bytes(n)?.to_vec())
                } else {
                    if n > 20_000_000 {
                        return Err("array too large".to_string());
                    }
                    let mut list: Vec<Value> = Vec::with_capacity(if n < 4096 { n } else { 4096 });
                    for _ in 0..n {
                        list.push(read_value(el, r, depth + 1)?);
                    }
                    Value::List(list)
                }
            } else {
                let mut fields: Vec<(String, Value)> = Vec::with_capacity(node.children.len());
                for c in node.children.iter() {
                    let cv = read_value(c, r, depth + 1)?;
                    fields.push((c.name.clone(), cv));
                }
                Value::Map(fields)
            }
        }
    };
    if align {
        r.align(4);
    }
    Ok(v)
}

impl SerializedFile {
    pub fn parse(data: &[u8]) -> Res<SerializedFile> {
        let m = parse_meta(data)?;
        Ok(SerializedFile {
            version: m.version,
            unity_version: m.unity_version,
            platform: m.platform,
            has_type_tree: m.has_type_tree,
            big_endian: m.big_endian,
            types: m.types,
            objects: m.objects,
            externals: m.externals,
            data: data.to_vec(),
        })
    }

    /// Major Unity version, e.g. 2019 for "2019.4.33f1".
    pub fn unity_major(&self) -> u32 {
        let digits: String = self.unity_version.chars().take_while(|c| c.is_ascii_digit()).collect();
        digits.parse::<u32>().unwrap_or(2019)
    }

    /// Root type name of an object (e.g. "GameObject"), or "class<id>" without a type tree.
    pub fn type_name(&self, obj: &ObjInfo) -> String {
        if let Some(t) = self.types.get(obj.type_index) {
            if let Some(root) = &t.root {
                return root.type_name.clone();
            }
        }
        format!("class{}", obj.class_id)
    }

    pub fn read_object(&self, obj: &ObjInfo) -> Res<Value> {
        let t = match self.types.get(obj.type_index) {
            Some(t) => t,
            None => return Err("invalid type index".to_string()),
        };
        let root = match &t.root {
            Some(r) => r,
            None => return Err("bundle has no type tree (cannot read object layout)".to_string()),
        };
        let end = match obj.offset.checked_add(obj.size) {
            Some(e) => e,
            None => return Err("object range overflow".to_string()),
        };
        if end > self.data.len() {
            return Err("object lies outside the file".to_string());
        }
        let mut r = Reader::new(&self.data[obj.offset..end]);
        r.big = self.big_endian;
        read_value(root, &mut r, 0)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn common_string_table_resolves_names() {
        // "Array" sits at a known offset of the table
        let off = COMMON_STRINGS.find("Array").unwrap() as u32;
        assert_eq!(tree_string(&[], off | 0x8000_0000), "Array");
        let off = COMMON_STRINGS.find("m_Name").unwrap() as u32;
        assert_eq!(tree_string(&[], off | 0x8000_0000), "m_Name");
        assert_eq!(tree_string(b"abc\0def\0", 4), "def");
    }

    #[test]
    fn rejects_old_versions() {
        let mut data = vec![0u8; 64];
        data[11] = 9; // version 9
        assert!(parse_meta(&data).is_err());
    }
}
