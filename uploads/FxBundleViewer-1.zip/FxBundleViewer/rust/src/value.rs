//! Dynamic value tree. Unity objects are read through their serialized type trees into
//! `Value`s, which makes the asset decoders independent of the exact Unity version.

#[derive(Clone, Debug)]
pub enum Value {
    None,
    Bool(bool),
    Int(i64),
    UInt(u64),
    Float(f64),
    Str(String),
    Bytes(Vec<u8>),
    List(Vec<Value>),
    Map(Vec<(String, Value)>),
}

static NONE_VALUE: Value = Value::None;

impl Value {
    /// Field lookup on a map; missing fields (or non-maps) yield `Value::None`.
    pub fn get(&self, key: &str) -> &Value {
        if let Value::Map(m) = self {
            for (k, v) in m.iter() {
                if k == key {
                    return v;
                }
            }
        }
        &NONE_VALUE
    }

    pub fn has(&self, key: &str) -> bool {
        if let Value::Map(m) = self {
            for (k, _) in m.iter() {
                if k == key {
                    return true;
                }
            }
        }
        false
    }

    pub fn at(&self, i: usize) -> &Value {
        if let Value::List(l) = self {
            if i < l.len() {
                return &l[i];
            }
        }
        &NONE_VALUE
    }

    pub fn is_none(&self) -> bool {
        matches!(self, Value::None)
    }

    pub fn len(&self) -> usize {
        match self {
            Value::List(l) => l.len(),
            Value::Bytes(b) => b.len(),
            Value::Map(m) => m.len(),
            _ => 0,
        }
    }

    pub fn f32(&self) -> f32 {
        match self {
            Value::Float(f) => *f as f32,
            Value::Int(i) => *i as f32,
            Value::UInt(u) => *u as f32,
            Value::Bool(b) => {
                if *b {
                    1.0
                } else {
                    0.0
                }
            }
            _ => 0.0,
        }
    }

    pub fn i64(&self) -> i64 {
        match self {
            Value::Int(i) => *i,
            Value::UInt(u) => *u as i64,
            Value::Float(f) => *f as i64,
            Value::Bool(b) => {
                if *b {
                    1
                } else {
                    0
                }
            }
            _ => 0,
        }
    }

    pub fn i32(&self) -> i32 {
        self.i64() as i32
    }

    pub fn u32(&self) -> u32 {
        self.i64() as u32
    }

    pub fn bool(&self) -> bool {
        match self {
            Value::Bool(b) => *b,
            Value::Int(i) => *i != 0,
            Value::UInt(u) => *u != 0,
            _ => false,
        }
    }

    pub fn str(&self) -> &str {
        match self {
            Value::Str(s) => s.as_str(),
            _ => "",
        }
    }

    pub fn bytes(&self) -> &[u8] {
        match self {
            Value::Bytes(b) => &b[..],
            _ => &[],
        }
    }

    pub fn list(&self) -> &[Value] {
        match self {
            Value::List(l) => &l[..],
            _ => &[],
        }
    }

    /// Path id of a PPtr that points into the same file (file id 0); 0 otherwise.
    pub fn pptr_local(&self) -> i64 {
        if self.get("m_FileID").i64() == 0 {
            self.get("m_PathID").i64()
        } else {
            0
        }
    }

    /// Reads a Vector2f/Vector3f/Vector4f-like map (x, y, z, w) into an array, missing -> 0.
    pub fn vec4(&self) -> [f32; 4] {
        [
            self.get("x").f32(),
            self.get("y").f32(),
            self.get("z").f32(),
            self.get("w").f32(),
        ]
    }

    pub fn vec3(&self) -> [f32; 3] {
        [self.get("x").f32(), self.get("y").f32(), self.get("z").f32()]
    }

    /// ColorRGBA map -> [r, g, b, a]
    pub fn rgba(&self) -> [f32; 4] {
        [
            self.get("r").f32(),
            self.get("g").f32(),
            self.get("b").f32(),
            self.get("a").f32(),
        ]
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn missing_fields_are_none() {
        let v = Value::Map(vec![("a".to_string(), Value::Int(3))]);
        assert_eq!(v.get("a").i64(), 3);
        assert!(v.get("b").is_none());
        assert_eq!(v.get("b").get("c").f32(), 0.0);
        assert_eq!(v.at(0).i64(), 0);
    }
}
