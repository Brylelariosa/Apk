//! Shared helpers: error type, in-memory log (shown in the app's diagnostics screen),
//! small vector/matrix/quaternion math on plain arrays, RNG and CRC32.

use std::sync::Mutex;

pub type Res<T> = Result<T, String>;
pub type V3 = [f32; 3];
/// Quaternion as x, y, z, w.
pub type Quat = [f32; 4];
/// 4x4 matrix, column-major (OpenGL layout).
pub type M4 = [f32; 16];

// ---------------------------------------------------------------------------------------------
// Logging
// ---------------------------------------------------------------------------------------------

static LOG: Mutex<Vec<String>> = Mutex::new(Vec::new());
const LOG_MAX: usize = 4000;

#[cfg(target_os = "android")]
mod android {
    use std::ffi::CString;
    use std::os::raw::{c_char, c_int};

    #[link(name = "log")]
    extern "C" {
        fn __android_log_write(prio: c_int, tag: *const c_char, text: *const c_char) -> c_int;
    }

    pub fn write(level: char, msg: &str) {
        let prio: c_int = match level {
            'E' => 6,
            'W' => 5,
            'I' => 4,
            _ => 3,
        };
        let tag = match CString::new("FxView") {
            Ok(t) => t,
            Err(_) => return,
        };
        let clean: String = msg.chars().map(|c| if c == '\0' { ' ' } else { c }).collect();
        let text = match CString::new(clean) {
            Ok(t) => t,
            Err(_) => return,
        };
        unsafe {
            __android_log_write(prio, tag.as_ptr(), text.as_ptr());
        }
    }
}

/// Appends a line to the in-memory log (and to logcat on Android).
pub fn log(level: char, msg: &str) {
    #[cfg(target_os = "android")]
    android::write(level, msg);
    if let Ok(mut g) = LOG.lock() {
        if g.len() >= LOG_MAX {
            let n = LOG_MAX / 4;
            g.drain(0..n);
        }
        g.push(format!("{} {}", level, msg));
    }
}

pub fn log_text() -> String {
    match LOG.lock() {
        Ok(g) => g.join("\n"),
        Err(_) => String::new(),
    }
}

pub fn log_clear() {
    if let Ok(mut g) = LOG.lock() {
        g.clear();
    }
}

// ---------------------------------------------------------------------------------------------
// Scalar / vector helpers
// ---------------------------------------------------------------------------------------------

pub fn lerp(a: f32, b: f32, t: f32) -> f32 {
    a + (b - a) * t
}

pub fn clamp01(x: f32) -> f32 {
    if x < 0.0 {
        0.0
    } else if x > 1.0 {
        1.0
    } else {
        x
    }
}

pub fn clampf(x: f32, lo: f32, hi: f32) -> f32 {
    if x < lo {
        lo
    } else if x > hi {
        hi
    } else {
        x
    }
}

pub fn v3_add(a: V3, b: V3) -> V3 {
    [a[0] + b[0], a[1] + b[1], a[2] + b[2]]
}

pub fn v3_sub(a: V3, b: V3) -> V3 {
    [a[0] - b[0], a[1] - b[1], a[2] - b[2]]
}

pub fn v3_scale(a: V3, s: f32) -> V3 {
    [a[0] * s, a[1] * s, a[2] * s]
}

pub fn v3_dot(a: V3, b: V3) -> f32 {
    a[0] * b[0] + a[1] * b[1] + a[2] * b[2]
}

pub fn v3_cross(a: V3, b: V3) -> V3 {
    [
        a[1] * b[2] - a[2] * b[1],
        a[2] * b[0] - a[0] * b[2],
        a[0] * b[1] - a[1] * b[0],
    ]
}

pub fn v3_len(a: V3) -> f32 {
    v3_dot(a, a).sqrt()
}

pub fn v3_norm(a: V3) -> V3 {
    let l = v3_len(a);
    if l > 1e-12 {
        v3_scale(a, 1.0 / l)
    } else {
        [0.0, 0.0, 0.0]
    }
}

// ---------------------------------------------------------------------------------------------
// Quaternions
// ---------------------------------------------------------------------------------------------

pub fn quat_identity() -> Quat {
    [0.0, 0.0, 0.0, 1.0]
}

pub fn quat_normalize(q: Quat) -> Quat {
    let l = (q[0] * q[0] + q[1] * q[1] + q[2] * q[2] + q[3] * q[3]).sqrt();
    if l < 1e-8 {
        quat_identity()
    } else {
        [q[0] / l, q[1] / l, q[2] / l, q[3] / l]
    }
}

/// Hamilton product a * b (b is applied first).
pub fn quat_mul(a: Quat, b: Quat) -> Quat {
    [
        a[3] * b[0] + a[0] * b[3] + a[1] * b[2] - a[2] * b[1],
        a[3] * b[1] - a[0] * b[2] + a[1] * b[3] + a[2] * b[0],
        a[3] * b[2] + a[0] * b[1] - a[1] * b[0] + a[2] * b[3],
        a[3] * b[3] - a[0] * b[0] - a[1] * b[1] - a[2] * b[2],
    ]
}

pub fn quat_axis_angle(axis: V3, rad: f32) -> Quat {
    let h = rad * 0.5;
    let s = h.sin();
    [axis[0] * s, axis[1] * s, axis[2] * s, h.cos()]
}

/// Unity's Quaternion.Euler: rotate about Z, then X, then Y (angles in radians).
pub fn quat_euler_rad(x: f32, y: f32, z: f32) -> Quat {
    let qx = quat_axis_angle([1.0, 0.0, 0.0], x);
    let qy = quat_axis_angle([0.0, 1.0, 0.0], y);
    let qz = quat_axis_angle([0.0, 0.0, 1.0], z);
    quat_mul(quat_mul(qy, qx), qz)
}

pub fn quat_euler_deg(x: f32, y: f32, z: f32) -> Quat {
    quat_euler_rad(x.to_radians(), y.to_radians(), z.to_radians())
}

pub fn quat_rotate(q: Quat, v: V3) -> V3 {
    let u = [q[0], q[1], q[2]];
    let t = v3_scale(v3_cross(u, v), 2.0);
    v3_add(v3_add(v, v3_scale(t, q[3])), v3_cross(u, t))
}

// ---------------------------------------------------------------------------------------------
// Matrices (column-major)
// ---------------------------------------------------------------------------------------------

pub fn mat_identity() -> M4 {
    [
        1.0, 0.0, 0.0, 0.0, //
        0.0, 1.0, 0.0, 0.0, //
        0.0, 0.0, 1.0, 0.0, //
        0.0, 0.0, 0.0, 1.0,
    ]
}

/// Returns a * b (b is applied first).
pub fn mat_mul(a: &M4, b: &M4) -> M4 {
    let mut r = [0.0f32; 16];
    for c in 0..4 {
        for row in 0..4 {
            let mut s = 0.0f32;
            for k in 0..4 {
                s += a[k * 4 + row] * b[c * 4 + k];
            }
            r[c * 4 + row] = s;
        }
    }
    r
}

/// Translation * Rotation * Scale.
pub fn mat_from_trs(p: V3, q: Quat, s: V3) -> M4 {
    let q = quat_normalize(q);
    let (x, y, z, w) = (q[0], q[1], q[2], q[3]);
    let xx = x * x;
    let yy = y * y;
    let zz = z * z;
    let xy = x * y;
    let xz = x * z;
    let yz = y * z;
    let wx = w * x;
    let wy = w * y;
    let wz = w * z;
    let r00 = 1.0 - 2.0 * (yy + zz);
    let r01 = 2.0 * (xy - wz);
    let r02 = 2.0 * (xz + wy);
    let r10 = 2.0 * (xy + wz);
    let r11 = 1.0 - 2.0 * (xx + zz);
    let r12 = 2.0 * (yz - wx);
    let r20 = 2.0 * (xz - wy);
    let r21 = 2.0 * (yz + wx);
    let r22 = 1.0 - 2.0 * (xx + yy);
    [
        r00 * s[0], r10 * s[0], r20 * s[0], 0.0, //
        r01 * s[1], r11 * s[1], r21 * s[1], 0.0, //
        r02 * s[2], r12 * s[2], r22 * s[2], 0.0, //
        p[0], p[1], p[2], 1.0,
    ]
}

pub fn mat_translation(m: &M4) -> V3 {
    [m[12], m[13], m[14]]
}

pub fn mat_transform_point(m: &M4, p: V3) -> V3 {
    [
        m[0] * p[0] + m[4] * p[1] + m[8] * p[2] + m[12],
        m[1] * p[0] + m[5] * p[1] + m[9] * p[2] + m[13],
        m[2] * p[0] + m[6] * p[1] + m[10] * p[2] + m[14],
    ]
}

pub fn mat_transform_dir(m: &M4, d: V3) -> V3 {
    [
        m[0] * d[0] + m[4] * d[1] + m[8] * d[2],
        m[1] * d[0] + m[5] * d[1] + m[9] * d[2],
        m[2] * d[0] + m[6] * d[1] + m[10] * d[2],
    ]
}

/// Lengths of the three basis columns.
pub fn mat_column_scale(m: &M4) -> V3 {
    [
        (m[0] * m[0] + m[1] * m[1] + m[2] * m[2]).sqrt(),
        (m[4] * m[4] + m[5] * m[5] + m[6] * m[6]).sqrt(),
        (m[8] * m[8] + m[9] * m[9] + m[10] * m[10]).sqrt(),
    ]
}

/// Copy of `m` with the basis columns normalised (rotation + translation only).
pub fn mat_remove_scale(m: &M4) -> M4 {
    let s = mat_column_scale(m);
    let mut r = *m;
    for c in 0..3 {
        let inv = if s[c] > 1e-12 { 1.0 / s[c] } else { 1.0 };
        for k in 0..3 {
            r[c * 4 + k] = m[c * 4 + k] * inv;
        }
    }
    r
}

pub fn mat_perspective(fovy_rad: f32, aspect: f32, near: f32, far: f32) -> M4 {
    let f = 1.0 / (fovy_rad * 0.5).tan();
    let mut m = [0.0f32; 16];
    m[0] = f / aspect;
    m[5] = f;
    m[10] = (far + near) / (near - far);
    m[11] = -1.0;
    m[14] = 2.0 * far * near / (near - far);
    m
}

/// View matrix for Unity's left-handed world: camera space looks down -Z (OpenGL), x to the right.
pub fn mat_look_at_lh(eye: V3, target: V3, up: V3) -> M4 {
    let f = v3_norm(v3_sub(target, eye));
    let mut r = v3_norm(v3_cross(up, f));
    if v3_len(r) < 1e-6 {
        r = [1.0, 0.0, 0.0];
    }
    let u = v3_cross(f, r);
    let mut m = [0.0f32; 16];
    m[0] = r[0];
    m[4] = r[1];
    m[8] = r[2];
    m[12] = -v3_dot(r, eye);
    m[1] = u[0];
    m[5] = u[1];
    m[9] = u[2];
    m[13] = -v3_dot(u, eye);
    m[2] = -f[0];
    m[6] = -f[1];
    m[10] = -f[2];
    m[14] = v3_dot(f, eye);
    m[15] = 1.0;
    m
}

// ---------------------------------------------------------------------------------------------
// RNG and hashing
// ---------------------------------------------------------------------------------------------

/// Small xorshift64* generator; deterministic so particle effects replay identically.
#[derive(Clone)]
pub struct Rng {
    s: u64,
}

impl Rng {
    pub fn new(seed: u64) -> Rng {
        Rng {
            s: if seed == 0 { 0x9E37_79B9_7F4A_7C15 } else { seed },
        }
    }

    pub fn next_u32(&mut self) -> u32 {
        let mut x = self.s;
        x ^= x >> 12;
        x ^= x << 25;
        x ^= x >> 27;
        self.s = x;
        (x.wrapping_mul(0x2545_F491_4F6C_DD1D) >> 32) as u32
    }

    /// Uniform in [0, 1).
    pub fn f32(&mut self) -> f32 {
        (self.next_u32() >> 8) as f32 / 16_777_216.0
    }

    pub fn range(&mut self, a: f32, b: f32) -> f32 {
        a + (b - a) * self.f32()
    }
}

/// Standard CRC-32 (the hash Unity uses for animation paths and property names).
pub fn crc32(data: &[u8]) -> u32 {
    let mut crc: u32 = 0xFFFF_FFFF;
    for &b in data {
        crc ^= b as u32;
        for _ in 0..8 {
            let mask = (!(crc & 1)).wrapping_add(1);
            crc = (crc >> 1) ^ (0xEDB8_8320 & mask);
        }
    }
    !crc
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn crc32_matches_unity_hash_of_is_active() {
        assert_eq!(crc32(b"m_IsActive"), 2086281974);
        assert_eq!(crc32(b""), 0);
    }

    #[test]
    fn matrix_identity_multiply() {
        let m = mat_from_trs([1.0, 2.0, 3.0], quat_identity(), [2.0, 2.0, 2.0]);
        let r = mat_mul(&mat_identity(), &m);
        for i in 0..16 {
            assert!((r[i] - m[i]).abs() < 1e-6);
        }
        let p = mat_transform_point(&m, [1.0, 1.0, 1.0]);
        assert!((p[0] - 3.0).abs() < 1e-6 && (p[1] - 4.0).abs() < 1e-6 && (p[2] - 5.0).abs() < 1e-6);
    }

    #[test]
    fn euler_matches_axis_rotation() {
        let q = quat_euler_deg(0.0, 90.0, 0.0);
        let v = quat_rotate(q, [0.0, 0.0, 1.0]);
        assert!((v[0] - 1.0).abs() < 1e-5 && v[2].abs() < 1e-5);
    }
}
