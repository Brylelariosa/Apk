//! JNI entry points for `com.fxview.app.nativebridge.NativeBridge`.
//!
//! Only primitives, file descriptors and strings cross the boundary. Heavy work (reading and
//! parsing a bundle) happens outside the global lock; every entry point is wrapped in
//! `catch_unwind` so a bug can never take the whole app down - it is written to the log instead.

use std::io::Read;
use std::os::unix::io::FromRawFd;
use std::panic::{catch_unwind, AssertUnwindSafe};
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::Mutex;
use std::time::Instant;

use jni::objects::JObject;
use jni::sys::{jfloat, jint, jstring};
use jni::JNIEnv;

use crate::app::App;
use crate::effect::load_effect;
use crate::render::Renderer;
use crate::util;

struct State {
    app: App,
    renderer: Option<Renderer>,
    last: Option<Instant>,
}

impl State {
    fn new() -> State {
        State { app: App::new(), renderer: None, last: None }
    }

    fn surface_created(&mut self) {
        self.renderer = match Renderer::new() {
            Ok(r) => Some(r),
            Err(e) => {
                log_e!("renderer init failed: {}", e);
                None
            }
        };
        self.last = None;
    }

    fn surface_changed(&mut self, w: i32, h: i32) {
        if let Some(r) = self.renderer.as_mut() {
            r.resize(w, h);
        }
        log_i!("surface {}x{}", w, h);
    }

    fn draw(&mut self) {
        let now = Instant::now();
        let dt = match self.last {
            Some(t) => now.duration_since(t).as_secs_f32(),
            None => 0.0,
        };
        self.last = Some(now);
        let dt = if dt > 0.1 { 0.1 } else { dt };
        self.app.step(dt);
        if let Some(r) = self.renderer.as_mut() {
            r.draw(&mut self.app, dt);
        }
    }
}

static STATE: Mutex<Option<State>> = Mutex::new(None);
static PANICS: AtomicUsize = AtomicUsize::new(0);

fn with_state<T>(f: impl FnOnce(&mut State) -> T) -> T {
    let mut lock = match STATE.lock() {
        Ok(g) => g,
        Err(p) => p.into_inner(),
    };
    if lock.is_none() {
        *lock = Some(State::new());
    }
    let state = lock.as_mut().expect("state initialised");
    f(state)
}

fn guard<T>(default: T, f: impl FnOnce() -> T) -> T {
    match catch_unwind(AssertUnwindSafe(f)) {
        Ok(v) => v,
        Err(_) => default,
    }
}

fn make_jstring(env: &mut JNIEnv, s: &str) -> jstring {
    match env.new_string(s) {
        Ok(js) => js.into_raw(),
        Err(_) => std::ptr::null_mut(),
    }
}

// ---------------------------------------------------------------------------------------------
// Lifecycle
// ---------------------------------------------------------------------------------------------

#[no_mangle]
pub extern "system" fn Java_com_fxview_app_nativebridge_NativeBridge_nativeInit(_env: JNIEnv, _this: JObject) {
    // A panic is caught in `guard`; log the first few in full, then only every 120th so that a
    // panic repeating every frame cannot flood the log and hide its origin.
    std::panic::set_hook(Box::new(|info| {
        let n = PANICS.fetch_add(1, Ordering::Relaxed);
        if n < 8 || n % 120 == 0 {
            log_e!("PANIC #{}: {}", n + 1, info);
        }
    }));
    guard((), || {
        with_state(|_st| {
            log_i!("FxView native core {} ready", env!("CARGO_PKG_VERSION"));
        });
    });
}

#[no_mangle]
pub extern "system" fn Java_com_fxview_app_nativebridge_NativeBridge_nativeSurfaceCreated(_env: JNIEnv, _this: JObject) {
    guard((), || with_state(|st| st.surface_created()));
}

#[no_mangle]
pub extern "system" fn Java_com_fxview_app_nativebridge_NativeBridge_nativeSurfaceChanged(
    _env: JNIEnv,
    _this: JObject,
    w: jint,
    h: jint,
) {
    guard((), || with_state(|st| st.surface_changed(w, h)));
}

#[no_mangle]
pub extern "system" fn Java_com_fxview_app_nativebridge_NativeBridge_nativeDrawFrame(_env: JNIEnv, _this: JObject) {
    guard((), || with_state(|st| st.draw()));
}

// ---------------------------------------------------------------------------------------------
// Effects
// ---------------------------------------------------------------------------------------------

/// Reads the bundle from a file descriptor (ownership is transferred to native code), parses it
/// and adds the effect to the scene. Returns the effect id or -1.
#[no_mangle]
pub extern "system" fn Java_com_fxview_app_nativebridge_NativeBridge_nativeLoadBundleFd(
    _env: JNIEnv,
    _this: JObject,
    fd: jint,
) -> jint {
    guard(-1, || {
        let mut file = unsafe { std::fs::File::from_raw_fd(fd) };
        let mut buf: Vec<u8> = Vec::new();
        if let Err(e) = file.read_to_end(&mut buf) {
            log_e!("could not read bundle from file descriptor: {}", e);
            return -1;
        }
        drop(file);
        log_i!("read {} bytes", buf.len());
        match load_effect(&buf) {
            Ok(fx) => {
                let name = fx.name.clone();
                let id = with_state(|st| st.app.add_effect(fx));
                log_i!("loaded '{}' as effect #{}", name, id);
                id
            }
            Err(e) => {
                log_e!("load failed: {}", e);
                -1
            }
        }
    })
}

#[no_mangle]
pub extern "system" fn Java_com_fxview_app_nativebridge_NativeBridge_nativeEffectInfo(
    mut env: JNIEnv,
    _this: JObject,
    id: jint,
) -> jstring {
    let s = guard(String::new(), || with_state(|st| st.app.effect_info(id)));
    make_jstring(&mut env, &s)
}

#[no_mangle]
pub extern "system" fn Java_com_fxview_app_nativebridge_NativeBridge_nativeRemoveEffect(
    _env: JNIEnv,
    _this: JObject,
    id: jint,
) {
    guard((), || with_state(|st| st.app.remove_effect(id)));
}

#[no_mangle]
pub extern "system" fn Java_com_fxview_app_nativebridge_NativeBridge_nativeClear(_env: JNIEnv, _this: JObject) {
    guard((), || with_state(|st| st.app.clear()));
}

#[no_mangle]
pub extern "system" fn Java_com_fxview_app_nativebridge_NativeBridge_nativeSetVisible(
    _env: JNIEnv,
    _this: JObject,
    id: jint,
    visible: jint,
) {
    guard((), || with_state(|st| st.app.set_visible(id, visible != 0)));
}

// ---------------------------------------------------------------------------------------------
// Playback
// ---------------------------------------------------------------------------------------------

#[no_mangle]
pub extern "system" fn Java_com_fxview_app_nativebridge_NativeBridge_nativeSetPlaying(
    _env: JNIEnv,
    _this: JObject,
    playing: jint,
) {
    guard((), || with_state(|st| st.app.set_playing(playing != 0)));
}

#[no_mangle]
pub extern "system" fn Java_com_fxview_app_nativebridge_NativeBridge_nativeIsPlaying(_env: JNIEnv, _this: JObject) -> jint {
    guard(0, || with_state(|st| if st.app.playing { 1 } else { 0 }))
}

#[no_mangle]
pub extern "system" fn Java_com_fxview_app_nativebridge_NativeBridge_nativeRestart(_env: JNIEnv, _this: JObject) {
    guard((), || {
        with_state(|st| {
            st.app.restart();
            st.app.playing = true;
        })
    });
}

#[no_mangle]
pub extern "system" fn Java_com_fxview_app_nativebridge_NativeBridge_nativeSeek(
    _env: JNIEnv,
    _this: JObject,
    t: jfloat,
) {
    guard((), || with_state(|st| st.app.seek(t)));
}

#[no_mangle]
pub extern "system" fn Java_com_fxview_app_nativebridge_NativeBridge_nativeGetTime(_env: JNIEnv, _this: JObject) -> jfloat {
    guard(0.0, || with_state(|st| st.app.time))
}

#[no_mangle]
pub extern "system" fn Java_com_fxview_app_nativebridge_NativeBridge_nativeGetDuration(_env: JNIEnv, _this: JObject) -> jfloat {
    guard(1.0, || with_state(|st| st.app.duration()))
}

#[no_mangle]
pub extern "system" fn Java_com_fxview_app_nativebridge_NativeBridge_nativeSetSpeed(
    _env: JNIEnv,
    _this: JObject,
    speed: jfloat,
) {
    guard((), || with_state(|st| st.app.speed = util::clampf(speed, 0.05, 4.0)));
}

#[no_mangle]
pub extern "system" fn Java_com_fxview_app_nativebridge_NativeBridge_nativeSetLoop(
    _env: JNIEnv,
    _this: JObject,
    looping: jint,
) {
    guard((), || with_state(|st| st.app.looping = looping != 0));
}

// ---------------------------------------------------------------------------------------------
// View options and camera
// ---------------------------------------------------------------------------------------------

#[no_mangle]
pub extern "system" fn Java_com_fxview_app_nativebridge_NativeBridge_nativeSetBlend(
    _env: JNIEnv,
    _this: JObject,
    mode: jint,
) {
    guard((), || with_state(|st| st.app.opts.blend = mode));
}

#[no_mangle]
pub extern "system" fn Java_com_fxview_app_nativebridge_NativeBridge_nativeSetMask(
    _env: JNIEnv,
    _this: JObject,
    on: jint,
) {
    guard((), || with_state(|st| st.app.opts.use_mask = on != 0));
}

#[no_mangle]
pub extern "system" fn Java_com_fxview_app_nativebridge_NativeBridge_nativeSetVertexColor(
    _env: JNIEnv,
    _this: JObject,
    on: jint,
) {
    guard((), || with_state(|st| st.app.opts.vertex_color = on != 0));
}

#[no_mangle]
pub extern "system" fn Java_com_fxview_app_nativebridge_NativeBridge_nativeSetBackground(
    _env: JNIEnv,
    _this: JObject,
    bg: jint,
) {
    guard((), || with_state(|st| st.app.opts.bg = bg));
}

#[no_mangle]
pub extern "system" fn Java_com_fxview_app_nativebridge_NativeBridge_nativeSetGrid(
    _env: JNIEnv,
    _this: JObject,
    on: jint,
) {
    guard((), || with_state(|st| st.app.opts.show_grid = on != 0));
}

#[no_mangle]
pub extern "system" fn Java_com_fxview_app_nativebridge_NativeBridge_nativeOrbit(
    _env: JNIEnv,
    _this: JObject,
    dx: jfloat,
    dy: jfloat,
) {
    guard((), || with_state(|st| st.app.camera.orbit(dx, dy)));
}

#[no_mangle]
pub extern "system" fn Java_com_fxview_app_nativebridge_NativeBridge_nativeZoom(
    _env: JNIEnv,
    _this: JObject,
    factor: jfloat,
) {
    guard((), || with_state(|st| st.app.camera.zoom(factor)));
}

#[no_mangle]
pub extern "system" fn Java_com_fxview_app_nativebridge_NativeBridge_nativePan(
    _env: JNIEnv,
    _this: JObject,
    dx: jfloat,
    dy: jfloat,
) {
    guard((), || with_state(|st| st.app.camera.pan(dx, dy)));
}

#[no_mangle]
pub extern "system" fn Java_com_fxview_app_nativebridge_NativeBridge_nativeResetCamera(_env: JNIEnv, _this: JObject) {
    guard((), || {
        with_state(|st| {
            st.app.camera.yaw = 0.6;
            st.app.camera.pitch = 0.35;
            st.app.frame_camera();
        })
    });
}

// ---------------------------------------------------------------------------------------------
// Diagnostics
// ---------------------------------------------------------------------------------------------

#[no_mangle]
pub extern "system" fn Java_com_fxview_app_nativebridge_NativeBridge_nativeGetLog(mut env: JNIEnv, _this: JObject) -> jstring {
    let s = guard(String::new(), || util::log_text());
    make_jstring(&mut env, &s)
}

#[no_mangle]
pub extern "system" fn Java_com_fxview_app_nativebridge_NativeBridge_nativeClearLog(_env: JNIEnv, _this: JObject) {
    guard((), || util::log_clear());
}

#[no_mangle]
pub extern "system" fn Java_com_fxview_app_nativebridge_NativeBridge_nativeStatus(mut env: JNIEnv, _this: JObject) -> jstring {
    let s = guard(String::new(), || with_state(|st| st.app.status_line()));
    make_jstring(&mut env, &s)
}
