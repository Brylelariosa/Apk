//! UnityFS container parsing (format versions 6 and 7). A bundle is a header, a compressed
//! block/directory table and compressed data blocks that together hold named files: one
//! serialized file ("CAB-...") plus optional streamed resources (".resS").

use crate::compress;
use crate::reader::Reader;
use crate::util::Res;

pub struct BundleFile {
    pub name: String,
    pub data: Vec<u8>,
}

pub struct Bundle {
    pub format_version: u32,
    pub unity_version: String,
    pub engine_version: String,
    pub compression: u32,
    pub files: Vec<BundleFile>,
}

fn printable(s: &str) -> String {
    s.chars()
        .map(|c| if c.is_ascii_graphic() { c } else { '.' })
        .take(16)
        .collect()
}

pub fn compression_name(ctype: u32) -> &'static str {
    match ctype {
        0 => "none",
        1 => "LZMA",
        2 => "LZ4",
        3 => "LZ4HC",
        4 => "LZHAM",
        _ => "unknown",
    }
}

pub fn parse_bundle(data: &[u8]) -> Res<Bundle> {
    if data.len() < 32 {
        return Err("file is too small to be a Unity bundle".to_string());
    }
    let mut r = Reader::new_be(data);
    let sig = r.cstr()?;
    if sig != "UnityFS" {
        return Err(format!(
            "not a UnityFS bundle (signature '{}'); UnityWeb/UnityRaw and encrypted bundles are not supported",
            printable(&sig)
        ));
    }
    let version = r.u32()?;
    let unity_version = r.cstr()?;
    let engine_version = r.cstr()?;
    let _total_size = r.i64()?;
    let ci_size = r.u32()? as usize;
    let ui_size = r.u32()? as usize;
    let flags = r.u32()?;
    if version >= 7 {
        r.align(16);
    }
    if ci_size == 0 || ci_size > data.len() || ui_size > 64 * 1024 * 1024 {
        return Err("corrupt bundle header (block table size)".to_string());
    }

    let info_raw: &[u8];
    if flags & 0x80 != 0 {
        // block table stored at the end of the file
        let start = data.len() - ci_size;
        info_raw = &data[start..];
    } else {
        let start = r.pos;
        if start + ci_size > data.len() {
            return Err("bundle block table runs past end of file".to_string());
        }
        info_raw = &data[start..start + ci_size];
        r.pos = start + ci_size;
    }
    let compression = flags & 0x3F;
    let info = compress::decompress(info_raw, ui_size, compression)
        .map_err(|e| format!("block table: {}", e))?;

    let mut ir = Reader::new_be(&info);
    ir.skip(16)?; // hash
    let block_count = ir.i32()?;
    if block_count < 0 || block_count > 100_000 {
        return Err("corrupt block count".to_string());
    }
    let mut blocks: Vec<(usize, usize, u32)> = Vec::new();
    let mut total_out: usize = 0;
    for _ in 0..block_count {
        let usz = ir.u32()? as usize;
        let csz = ir.u32()? as usize;
        let fl = ir.u16()? as u32;
        total_out += usz;
        blocks.push((usz, csz, fl));
    }
    if total_out > 256 * 1024 * 1024 {
        return Err("bundle too large (over 256 MB uncompressed)".to_string());
    }
    let node_count = ir.i32()?;
    if node_count < 0 || node_count > 100_000 {
        return Err("corrupt node count".to_string());
    }
    let mut nodes: Vec<(usize, usize, String)> = Vec::new();
    for _ in 0..node_count {
        let off = ir.i64()?;
        let size = ir.i64()?;
        let _node_flags = ir.u32()?;
        let path = ir.cstr()?;
        if off < 0 || size < 0 {
            return Err("corrupt directory entry".to_string());
        }
        nodes.push((off as usize, size as usize, path));
    }

    // data blocks follow the header (and the block table when it is not stored at the end)
    let mut all: Vec<u8> = Vec::with_capacity(total_out);
    let mut pos = r.pos;
    for (i, b) in blocks.iter().enumerate() {
        let (usz, csz, fl) = *b;
        if pos + csz > data.len() {
            return Err(format!("data block {} runs past end of file", i));
        }
        let chunk = compress::decompress(&data[pos..pos + csz], usz, fl & 0x3F)
            .map_err(|e| format!("data block {}: {}", i, e))?;
        all.extend_from_slice(&chunk);
        pos += csz;
    }

    let mut files: Vec<BundleFile> = Vec::new();
    for (off, size, path) in nodes.into_iter() {
        if off + size > all.len() {
            return Err(format!("file '{}' lies outside the decompressed data", path));
        }
        files.push(BundleFile { name: path, data: all[off..off + size].to_vec() });
    }

    Ok(Bundle { format_version: version, unity_version, engine_version, compression, files })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn rejects_garbage() {
        let data = vec![0u8; 64];
        assert!(parse_bundle(&data).is_err());
    }

    #[test]
    fn rejects_other_signature() {
        let mut data = b"UnityWeb\0".to_vec();
        data.resize(64, 0);
        assert!(parse_bundle(&data).is_err());
    }
}
