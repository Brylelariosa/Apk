//! Unity ParticleSystem support: parsing of the serialized modules and a small deterministic CPU
//! simulation (emission, shape, start values, size/rotation/color/velocity over lifetime and
//! texture-sheet animation). Rendering is done elsewhere from `ps_render_list`.

use crate::anim::{eval_hermite, HKey};
use crate::util::*;
use crate::value::Value;

// ---------------------------------------------------------------------------------------------
// Curves and gradients
// ---------------------------------------------------------------------------------------------

#[derive(Clone, Debug)]
pub struct MinMaxCurve {
    /// 0 = constant, 1 = curve, 2 = two curves, 3 = two constants
    pub state: i32,
    pub scalar: f32,
    pub min_scalar: f32,
    pub max_keys: Vec<HKey>,
    pub min_keys: Vec<HKey>,
}

fn keys_of(c: &Value) -> Vec<HKey> {
    c.get("m_Curve")
        .list()
        .iter()
        .map(|k| HKey {
            t: k.get("time").f32(),
            v: k.get("value").f32(),
            in_s: k.get("inSlope").f32(),
            out_s: k.get("outSlope").f32(),
        })
        .collect()
}

impl MinMaxCurve {
    pub fn constant(x: f32) -> MinMaxCurve {
        MinMaxCurve { state: 0, scalar: x, min_scalar: x, max_keys: Vec::new(), min_keys: Vec::new() }
    }

    pub fn from_value(v: &Value) -> MinMaxCurve {
        MinMaxCurve {
            state: v.get("minMaxState").i32(),
            scalar: v.get("scalar").f32(),
            min_scalar: v.get("minScalar").f32(),
            max_keys: keys_of(v.get("maxCurve")),
            min_keys: keys_of(v.get("minCurve")),
        }
    }

    /// Parses either a MinMaxCurve map or a plain number.
    pub fn from_any(v: &Value) -> MinMaxCurve {
        if v.has("minMaxState") {
            MinMaxCurve::from_value(v)
        } else {
            MinMaxCurve::constant(v.f32())
        }
    }

    fn curve_at(keys: &Vec<HKey>, t: f32) -> f32 {
        if keys.is_empty() {
            1.0
        } else {
            eval_hermite(keys, t)
        }
    }

    /// `t` is the normalised time the curve is sampled at, `rnd` a random number in [0, 1).
    pub fn eval(&self, t: f32, rnd: f32) -> f32 {
        match self.state {
            1 => self.scalar * MinMaxCurve::curve_at(&self.max_keys, t),
            2 => {
                let a = self.scalar * MinMaxCurve::curve_at(&self.min_keys, t);
                let b = self.scalar * MinMaxCurve::curve_at(&self.max_keys, t);
                a + (b - a) * rnd
            }
            3 => self.min_scalar + (self.scalar - self.min_scalar) * rnd,
            _ => self.scalar,
        }
    }

    /// Rough upper bound of the value (used for duration estimates).
    pub fn max_value(&self) -> f32 {
        match self.state {
            3 => self.scalar.max(self.min_scalar),
            1 | 2 => {
                let mut m = 0.0f32;
                for k in self.max_keys.iter() {
                    if k.v > m {
                        m = k.v;
                    }
                }
                if self.max_keys.is_empty() {
                    m = 1.0;
                }
                self.scalar * m
            }
            _ => self.scalar,
        }
    }
}

#[derive(Clone, Debug)]
pub struct Gradient {
    pub fixed: bool,
    pub color_keys: Vec<(f32, [f32; 3])>,
    pub alpha_keys: Vec<(f32, f32)>,
}

fn eval_keys3(keys: &[(f32, [f32; 3])], t: f32, fixed: bool) -> [f32; 3] {
    if keys.is_empty() {
        return [1.0, 1.0, 1.0];
    }
    let n = keys.len();
    if t <= keys[0].0 {
        return keys[0].1;
    }
    if t >= keys[n - 1].0 {
        return keys[n - 1].1;
    }
    for i in 0..n - 1 {
        let (t0, c0) = keys[i];
        let (t1, c1) = keys[i + 1];
        if t >= t0 && t <= t1 {
            if fixed {
                return c1;
            }
            let u = if t1 - t0 > 1e-6 { (t - t0) / (t1 - t0) } else { 0.0 };
            return [lerp(c0[0], c1[0], u), lerp(c0[1], c1[1], u), lerp(c0[2], c1[2], u)];
        }
    }
    keys[n - 1].1
}

fn eval_keys1(keys: &[(f32, f32)], t: f32, fixed: bool) -> f32 {
    if keys.is_empty() {
        return 1.0;
    }
    let n = keys.len();
    if t <= keys[0].0 {
        return keys[0].1;
    }
    if t >= keys[n - 1].0 {
        return keys[n - 1].1;
    }
    for i in 0..n - 1 {
        let (t0, a0) = keys[i];
        let (t1, a1) = keys[i + 1];
        if t >= t0 && t <= t1 {
            if fixed {
                return a1;
            }
            let u = if t1 - t0 > 1e-6 { (t - t0) / (t1 - t0) } else { 0.0 };
            return lerp(a0, a1, u);
        }
    }
    keys[n - 1].1
}

impl Gradient {
    pub fn white() -> Gradient {
        Gradient { fixed: false, color_keys: Vec::new(), alpha_keys: Vec::new() }
    }

    pub fn from_value(v: &Value) -> Gradient {
        let nc = std::cmp::min(v.get("m_NumColorKeys").i64().max(0) as usize, 8);
        let na = std::cmp::min(v.get("m_NumAlphaKeys").i64().max(0) as usize, 8);
        let mut color_keys: Vec<(f32, [f32; 3])> = Vec::new();
        let mut alpha_keys: Vec<(f32, f32)> = Vec::new();
        for i in 0..nc {
            let k = v.get(&format!("key{}", i));
            let t = v.get(&format!("ctime{}", i)).f32() / 65535.0;
            color_keys.push((t, [k.get("r").f32(), k.get("g").f32(), k.get("b").f32()]));
        }
        for i in 0..na {
            let k = v.get(&format!("key{}", i));
            let t = v.get(&format!("atime{}", i)).f32() / 65535.0;
            alpha_keys.push((t, k.get("a").f32()));
        }
        Gradient { fixed: v.get("m_Mode").i32() == 1, color_keys, alpha_keys }
    }

    pub fn eval(&self, t: f32) -> [f32; 4] {
        let c = eval_keys3(&self.color_keys, t, self.fixed);
        let a = eval_keys1(&self.alpha_keys, t, self.fixed);
        [c[0], c[1], c[2], a]
    }
}

#[derive(Clone, Debug)]
pub struct MinMaxGradient {
    /// 0 = color, 1 = gradient, 2 = two colors, 3 = two gradients, 4 = random color
    pub state: i32,
    pub min_color: [f32; 4],
    pub max_color: [f32; 4],
    pub min_grad: Gradient,
    pub max_grad: Gradient,
}

impl MinMaxGradient {
    pub fn white() -> MinMaxGradient {
        MinMaxGradient {
            state: 0,
            min_color: [1.0; 4],
            max_color: [1.0; 4],
            min_grad: Gradient::white(),
            max_grad: Gradient::white(),
        }
    }

    pub fn from_value(v: &Value) -> MinMaxGradient {
        if v.is_none() {
            return MinMaxGradient::white();
        }
        MinMaxGradient {
            state: v.get("minMaxState").i32(),
            min_color: v.get("minColor").rgba(),
            max_color: v.get("maxColor").rgba(),
            min_grad: Gradient::from_value(v.get("minGradient")),
            max_grad: Gradient::from_value(v.get("maxGradient")),
        }
    }

    pub fn eval(&self, t: f32, rnd: f32) -> [f32; 4] {
        match self.state {
            1 => self.max_grad.eval(t),
            2 => {
                let a = self.min_color;
                let b = self.max_color;
                [lerp(a[0], b[0], rnd), lerp(a[1], b[1], rnd), lerp(a[2], b[2], rnd), lerp(a[3], b[3], rnd)]
            }
            3 => {
                let a = self.min_grad.eval(t);
                let b = self.max_grad.eval(t);
                [lerp(a[0], b[0], rnd), lerp(a[1], b[1], rnd), lerp(a[2], b[2], rnd), lerp(a[3], b[3], rnd)]
            }
            4 => self.max_grad.eval(rnd),
            _ => self.max_color,
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Definition
// ---------------------------------------------------------------------------------------------

#[derive(Clone, Debug)]
pub struct Burst {
    pub time: f32,
    pub count: MinMaxCurve,
    pub cycles: i32,
    pub interval: f32,
}

#[derive(Clone, Debug)]
pub struct ShapeDef {
    pub kind: i32,
    pub radius: f32,
    pub angle: f32,
    pub arc: f32,
    pub radius_thickness: f32,
    pub pos: V3,
    pub scale: V3,
}

#[derive(Clone, Debug)]
pub struct SizeOver {
    pub x: MinMaxCurve,
    pub y: MinMaxCurve,
    pub z: MinMaxCurve,
}

#[derive(Clone, Debug)]
pub struct RotOver {
    pub x: MinMaxCurve,
    pub y: MinMaxCurve,
    pub z: MinMaxCurve,
}

#[derive(Clone, Debug)]
pub struct VelOver {
    pub x: MinMaxCurve,
    pub y: MinMaxCurve,
    pub z: MinMaxCurve,
}

#[derive(Clone, Debug)]
pub struct UvDef {
    pub tiles_x: i32,
    pub tiles_y: i32,
    /// 0 = whole sheet, 1 = single row
    pub anim_type: i32,
    pub row: i32,
    pub random_row: bool,
    pub frame_over_time: MinMaxCurve,
    pub start_frame: MinMaxCurve,
    pub cycles: f32,
}

#[derive(Clone, Debug)]
pub struct PsDef {
    pub name: String,
    pub duration: f32,
    pub looping: bool,
    pub prewarm: bool,
    pub start_delay: MinMaxCurve,
    /// 0 = local, 1 = world, 2 = custom
    pub sim_space: i32,
    /// 0 = hierarchy, 1 = local, 2 = shape
    pub scaling_mode: i32,
    pub speed: f32,
    pub seed: i64,
    pub max_particles: usize,
    pub start_lifetime: MinMaxCurve,
    pub start_speed: MinMaxCurve,
    pub start_size: MinMaxCurve,
    pub start_size_y: MinMaxCurve,
    pub start_size_z: MinMaxCurve,
    pub size_3d: bool,
    pub start_rot: MinMaxCurve,
    pub start_rot_x: MinMaxCurve,
    pub start_rot_y: MinMaxCurve,
    pub rot_3d: bool,
    pub start_color: MinMaxGradient,
    pub gravity: MinMaxCurve,
    pub emission_enabled: bool,
    pub rate: MinMaxCurve,
    pub bursts: Vec<Burst>,
    pub shape: Option<ShapeDef>,
    pub size_over: Option<SizeOver>,
    pub rot_over: Option<RotOver>,
    pub color_over: Option<MinMaxGradient>,
    pub vel_over: Option<VelOver>,
    pub uv: Option<UvDef>,
    /// modules that exist in the data but are not simulated (reported in the log)
    pub unsupported: Vec<String>,
    // renderer settings
    /// 0 billboard, 1 stretched, 2 horizontal, 3 vertical, 4 mesh, 5 none
    pub render_mode: i32,
    pub length_scale: f32,
    pub velocity_scale: f32,
    pub render_alignment: i32,
    pub renderer_enabled: bool,
    pub mesh_path_id: i64,
}

fn module_enabled(v: &Value, key: &str) -> bool {
    v.get(key).get("enabled").bool()
}

pub fn parse_ps_def(v: &Value, name: &str) -> PsDef {
    let ini = v.get("InitialModule");
    let em = v.get("EmissionModule");

    let mut bursts: Vec<Burst> = Vec::new();
    for b in em.get("m_Bursts").list().iter() {
        bursts.push(Burst {
            time: b.get("time").f32(),
            count: MinMaxCurve::from_value(b.get("countCurve")),
            cycles: b.get("cycleCount").i32(),
            interval: b.get("repeatInterval").f32(),
        });
    }

    let sm = v.get("ShapeModule");
    let shape = if module_enabled(v, "ShapeModule") {
        let scale = if sm.get("m_Scale").has("x") { sm.get("m_Scale").vec3() } else { [1.0, 1.0, 1.0] };
        let radius = if sm.get("radius").has("value") { sm.get("radius").get("value").f32() } else { sm.get("radius").f32() };
        let arc = if sm.get("arc").has("value") { sm.get("arc").get("value").f32() } else { 360.0 };
        Some(ShapeDef {
            kind: sm.get("type").i32(),
            radius,
            angle: sm.get("angle").f32(),
            arc,
            radius_thickness: if sm.has("radiusThickness") { sm.get("radiusThickness").f32() } else { 1.0 },
            pos: sm.get("m_Position").vec3(),
            scale,
        })
    } else {
        None
    };

    let size_over = if module_enabled(v, "SizeModule") {
        let m = v.get("SizeModule");
        let x = MinMaxCurve::from_value(m.get("curve"));
        if m.get("separateAxes").bool() {
            Some(SizeOver { x: x.clone(), y: MinMaxCurve::from_value(m.get("y")), z: MinMaxCurve::from_value(m.get("z")) })
        } else {
            Some(SizeOver { x: x.clone(), y: x.clone(), z: x })
        }
    } else {
        None
    };

    let rot_over = if module_enabled(v, "RotationModule") {
        let m = v.get("RotationModule");
        let z = MinMaxCurve::from_value(m.get("curve"));
        if m.get("separateAxes").bool() {
            Some(RotOver { x: MinMaxCurve::from_value(m.get("x")), y: MinMaxCurve::from_value(m.get("y")), z })
        } else {
            Some(RotOver { x: MinMaxCurve::constant(0.0), y: MinMaxCurve::constant(0.0), z })
        }
    } else {
        None
    };

    let color_over = if module_enabled(v, "ColorModule") {
        Some(MinMaxGradient::from_value(v.get("ColorModule").get("gradient")))
    } else {
        None
    };

    let vel_over = if module_enabled(v, "VelocityModule") {
        let m = v.get("VelocityModule");
        Some(VelOver {
            x: MinMaxCurve::from_value(m.get("x")),
            y: MinMaxCurve::from_value(m.get("y")),
            z: MinMaxCurve::from_value(m.get("z")),
        })
    } else {
        None
    };

    let uv = if module_enabled(v, "UVModule") && v.get("UVModule").get("mode").i32() == 0 {
        let m = v.get("UVModule");
        Some(UvDef {
            tiles_x: std::cmp::max(m.get("tilesX").i32(), 1),
            tiles_y: std::cmp::max(m.get("tilesY").i32(), 1),
            anim_type: m.get("animationType").i32(),
            row: m.get("rowIndex").i32(),
            random_row: m.get("randomRow").bool(),
            frame_over_time: MinMaxCurve::from_value(m.get("frameOverTime")),
            start_frame: MinMaxCurve::from_value(m.get("startFrame")),
            cycles: if m.get("cycles").f32() > 0.0 { m.get("cycles").f32() } else { 1.0 },
        })
    } else {
        None
    };

    let mut unsupported: Vec<String> = Vec::new();
    for (key, label) in [
        ("CustomDataModule", "custom data"),
        ("SubModule", "sub emitters"),
        ("TrailModule", "trails"),
        ("NoiseModule", "noise"),
        ("ForceModule", "force over lifetime"),
        ("InheritVelocityModule", "inherit velocity"),
        ("CollisionModule", "collision"),
        ("LightsModule", "lights"),
        ("ClampVelocityModule", "limit velocity"),
        ("ExternalForcesModule", "external forces"),
        ("SizeBySpeedModule", "size by speed"),
        ("RotationBySpeedModule", "rotation by speed"),
        ("ColorBySpeedModule", "color by speed"),
    ]
    .iter()
    {
        if module_enabled(v, key) {
            unsupported.push(label.to_string());
        }
    }

    let max_particles = {
        let m = ini.get("maxNumParticles").i64();
        if m <= 0 {
            1000
        } else if m > 5000 {
            5000
        } else {
            m as usize
        }
    };

    PsDef {
        name: name.to_string(),
        duration: v.get("lengthInSec").f32(),
        looping: v.get("looping").bool(),
        prewarm: v.get("prewarm").bool(),
        start_delay: MinMaxCurve::from_any(v.get("startDelay")),
        sim_space: v.get("moveWithTransform").i32(),
        scaling_mode: v.get("scalingMode").i32(),
        speed: if v.has("simulationSpeed") { v.get("simulationSpeed").f32() } else { 1.0 },
        seed: v.get("randomSeed").i64(),
        max_particles,
        start_lifetime: MinMaxCurve::from_value(ini.get("startLifetime")),
        start_speed: MinMaxCurve::from_value(ini.get("startSpeed")),
        start_size: MinMaxCurve::from_value(ini.get("startSize")),
        start_size_y: MinMaxCurve::from_value(ini.get("startSizeY")),
        start_size_z: MinMaxCurve::from_value(ini.get("startSizeZ")),
        size_3d: ini.get("size3D").bool(),
        start_rot: MinMaxCurve::from_value(ini.get("startRotation")),
        start_rot_x: MinMaxCurve::from_value(ini.get("startRotationX")),
        start_rot_y: MinMaxCurve::from_value(ini.get("startRotationY")),
        rot_3d: ini.get("rotation3D").bool(),
        start_color: MinMaxGradient::from_value(ini.get("startColor")),
        gravity: MinMaxCurve::from_any(ini.get("gravityModifier")),
        emission_enabled: em.get("enabled").bool(),
        rate: MinMaxCurve::from_value(em.get("rateOverTime")),
        bursts,
        shape,
        size_over,
        rot_over,
        color_over,
        vel_over,
        uv,
        unsupported,
        render_mode: 0,
        length_scale: 2.0,
        velocity_scale: 0.0,
        render_alignment: 0,
        renderer_enabled: true,
        mesh_path_id: 0,
    }
}

/// Copies the ParticleSystemRenderer settings into the definition.
pub fn apply_renderer(def: &mut PsDef, r: &Value) {
    def.render_mode = r.get("m_RenderMode").i32();
    def.length_scale = r.get("m_LengthScale").f32();
    def.velocity_scale = r.get("m_VelocityScale").f32();
    def.render_alignment = r.get("m_RenderAlignment").i32();
    def.renderer_enabled = r.get("m_Enabled").bool();
    def.mesh_path_id = r.get("m_Mesh").pptr_local();
}

/// Time (seconds) after which the system has no more visible particles, or a default for looping systems.
pub fn ps_estimate_duration(def: &PsDef) -> f32 {
    if def.looping {
        return 4.0;
    }
    let delay = def.start_delay.max_value().max(0.0);
    let mut last_burst = 0.0f32;
    for b in def.bursts.iter() {
        let cycles = if b.cycles > 1 { b.cycles - 1 } else { 0 };
        let t = b.time + b.interval * cycles as f32;
        if t > last_burst {
            last_burst = t;
        }
    }
    let emit_end = if def.rate.max_value() > 0.0 { def.duration } else { last_burst };
    let spawn_end = if def.duration > emit_end && def.rate.max_value() > 0.0 { def.duration } else { emit_end };
    (delay + spawn_end + def.start_lifetime.max_value().max(0.0)) / if def.speed > 0.01 { def.speed } else { 1.0 }
}

// ---------------------------------------------------------------------------------------------
// Simulation
// ---------------------------------------------------------------------------------------------

#[derive(Clone, Debug)]
pub struct Particle {
    pub pos: V3,
    pub vel: V3,
    pub age: f32,
    pub life: f32,
    pub rot: V3,
    pub size: V3,
    pub color: [f32; 4],
    pub rnd: f32,
    pub start_frame: f32,
    pub row: i32,
}

#[derive(Clone)]
pub struct PsState {
    pub particles: Vec<Particle>,
    pub time: f32,
    pub emit_acc: f32,
    pub rng: Rng,
    pub seed: u64,
    pub was_active: bool,
    pub delay: f32,
    pub finished: bool,
}

impl PsState {
    pub fn new(seed: u64) -> PsState {
        PsState {
            particles: Vec::new(),
            time: 0.0,
            emit_acc: 0.0,
            rng: Rng::new(seed),
            seed,
            was_active: false,
            delay: 0.0,
            finished: false,
        }
    }
}

fn random_unit(rng: &mut Rng) -> V3 {
    let c = rng.f32() * 2.0 - 1.0;
    let phi = rng.f32() * std::f32::consts::PI * 2.0;
    let s = (1.0 - c * c).max(0.0).sqrt();
    [s * phi.cos(), s * phi.sin(), c]
}

/// Returns (local position, unit direction) for a new particle.
fn sample_shape(sh: Option<&ShapeDef>, rng: &mut Rng) -> (V3, V3) {
    let sh = match sh {
        Some(s) => s,
        None => return ([0.0, 0.0, 0.0], [0.0, 0.0, 1.0]),
    };
    let mut p = [0.0f32; 3];
    let mut d = [0.0f32, 0.0, 1.0];
    let arc_rad = (if sh.arc > 0.0 { sh.arc } else { 360.0 }).to_radians();
    let radius = if sh.radius > 0.0 { sh.radius } else { 1.0 };
    match sh.kind {
        0 | 1 | 2 | 3 => {
            let mut dir = random_unit(rng);
            if (sh.kind == 2 || sh.kind == 3) && dir[2] < 0.0 {
                dir[2] = -dir[2];
            }
            let shell = sh.kind == 1 || sh.kind == 3;
            let r = if shell {
                1.0
            } else {
                let th = clamp01(sh.radius_thickness);
                lerp(1.0 - th, 1.0, rng.f32().cbrt())
            };
            p = v3_scale(dir, radius * r);
            d = dir;
        }
        4 | 7 | 8 | 9 => {
            let ang = rng.f32() * arc_rad;
            let shell = sh.kind == 7 || sh.kind == 9;
            let rr = if shell { 1.0 } else { rng.f32().sqrt() };
            let x = ang.cos() * rr;
            let y = ang.sin() * rr;
            p = [x * radius, y * radius, 0.0];
            let a = sh.angle.to_radians() * rr.max(0.05);
            d = v3_norm([x * a.sin() / rr.max(0.05), y * a.sin() / rr.max(0.05), a.cos()]);
        }
        5 | 15 | 16 => {
            p = [rng.f32() - 0.5, rng.f32() - 0.5, rng.f32() - 0.5];
            d = [0.0, 0.0, 1.0];
        }
        10 | 11 => {
            let ang = rng.f32() * arc_rad;
            let rr = if sh.kind == 11 { 1.0 } else { rng.f32().sqrt() };
            let x = ang.cos() * rr;
            let y = ang.sin() * rr;
            p = [x * radius, y * radius, 0.0];
            d = v3_norm([x, y, 0.0]);
        }
        12 => {
            p = [(rng.f32() * 2.0 - 1.0) * radius, 0.0, 0.0];
            d = [0.0, 1.0, 0.0];
        }
        _ => {}
    }
    let q = [
        p[0] * sh.scale[0] + sh.pos[0],
        p[1] * sh.scale[1] + sh.pos[1],
        p[2] * sh.scale[2] + sh.pos[2],
    ];
    (q, d)
}

fn spawn(def: &PsDef, st: &mut PsState, emitter: &M4, norm: f32) {
    if st.particles.len() >= def.max_particles {
        return;
    }
    let r_life = st.rng.f32();
    let r_speed = st.rng.f32();
    let r_size = st.rng.f32();
    let r_rot = st.rng.f32();
    let r_col = st.rng.f32();
    let rnd = st.rng.f32();

    let life = def.start_lifetime.eval(norm, r_life).max(0.001);
    let speed = def.start_speed.eval(norm, r_speed);
    let size: V3 = if def.size_3d {
        [
            def.start_size.eval(norm, r_size),
            def.start_size_y.eval(norm, r_size),
            def.start_size_z.eval(norm, r_size),
        ]
    } else {
        let s = def.start_size.eval(norm, r_size);
        [s, s, s]
    };
    let rot: V3 = if def.rot_3d {
        [
            def.start_rot_x.eval(norm, r_rot),
            def.start_rot_y.eval(norm, r_rot),
            def.start_rot.eval(norm, r_rot),
        ]
    } else {
        [0.0, 0.0, def.start_rot.eval(norm, r_rot)]
    };
    let color = def.start_color.eval(norm, r_col);

    let (pos_local, dir) = sample_shape(def.shape.as_ref(), &mut st.rng);
    let (pos, vel) = if def.sim_space == 1 {
        (
            mat_transform_point(emitter, pos_local),
            v3_scale(v3_norm(mat_transform_dir(emitter, dir)), speed),
        )
    } else {
        (pos_local, v3_scale(dir, speed))
    };
    let (start_frame, row) = match &def.uv {
        Some(uv) => {
            let sf = uv.start_frame.eval(norm, st.rng.f32());
            let row = if uv.random_row { (st.rng.f32() * uv.tiles_y as f32) as i32 } else { uv.row };
            (sf, row)
        }
        None => (0.0, 0),
    };
    st.particles.push(Particle { pos, vel, age: 0.0, life, rot, size, color, rnd, start_frame, row });
}

fn emit(def: &PsDef, st: &mut PsState, s0_in: f32, s1: f32, emitter: &M4) {
    if !def.emission_enabled || s1 <= 0.0 {
        return;
    }
    let s0 = if s0_in < 0.0 { 0.0 } else { s0_in };
    let dur = if def.duration > 1e-4 { def.duration } else { 1e-4 };
    let w0 = s0;
    let w1;
    if def.looping {
        w1 = s1;
    } else {
        if s0 >= dur {
            st.finished = true;
            return;
        }
        w1 = if s1 > dur { dur } else { s1 };
    }
    if w1 < w0 {
        return;
    }
    let norm = clamp01((w0 % dur) / dur);

    let rate = def.rate.eval(norm, 0.5);
    if rate > 0.0 {
        st.emit_acc += rate * (w1 - w0);
        let whole = st.emit_acc.floor();
        st.emit_acc -= whole;
        let count = if whole > 500.0 { 500 } else { whole as i32 };
        for _ in 0..count {
            spawn(def, st, emitter, norm);
        }
    }

    for b in def.bursts.iter() {
        let cycles = if b.cycles > 1 { b.cycles } else { 1 };
        let (from, to) = if def.looping {
            ((w0 / dur).floor() as i32, (w1 / dur).floor() as i32)
        } else {
            (0, 0)
        };
        for lp in from..=to {
            for c in 0..cycles {
                let bt = lp as f32 * dur + b.time + c as f32 * b.interval;
                if bt >= w0 && bt < w1 {
                    let rnd = st.rng.f32();
                    let n = b.count.eval(norm, rnd).round() as i32;
                    let n = if n > 1000 { 1000 } else { n };
                    for _ in 0..n.max(0) {
                        spawn(def, st, emitter, norm);
                    }
                }
            }
        }
    }
}

/// Advances one particle system by `dt_in` seconds. `emitter` is the world matrix of the system's node.
pub fn ps_update(def: &PsDef, st: &mut PsState, dt_in: f32, emitter: &M4, active: bool) {
    if !active {
        if st.was_active {
            st.particles.clear();
            st.time = 0.0;
            st.emit_acc = 0.0;
            st.finished = false;
        }
        st.was_active = false;
        return;
    }
    if !st.was_active {
        st.was_active = true;
        st.time = 0.0;
        st.emit_acc = 0.0;
        st.finished = false;
        st.particles.clear();
        st.rng = Rng::new(st.seed);
        let r = st.rng.f32();
        st.delay = def.start_delay.eval(0.0, r).max(0.0);
    }
    let dt = dt_in * def.speed.max(0.0);
    if dt <= 0.0 {
        return;
    }

    // integrate existing particles
    let old = std::mem::take(&mut st.particles);
    let mut keep: Vec<Particle> = Vec::with_capacity(old.len());
    for mut p in old.into_iter() {
        p.age += dt;
        if p.age >= p.life {
            continue;
        }
        let nt = p.age / p.life;
        let g = def.gravity.eval(nt, p.rnd);
        p.vel[1] -= g * 9.81 * dt;
        let mut v = p.vel;
        if let Some(vo) = &def.vel_over {
            v = v3_add(v, [vo.x.eval(nt, p.rnd), vo.y.eval(nt, p.rnd), vo.z.eval(nt, p.rnd)]);
        }
        p.pos = v3_add(p.pos, v3_scale(v, dt));
        if let Some(ro) = &def.rot_over {
            p.rot[0] += ro.x.eval(nt, p.rnd) * dt;
            p.rot[1] += ro.y.eval(nt, p.rnd) * dt;
            p.rot[2] += ro.z.eval(nt, p.rnd) * dt;
        }
        keep.push(p);
    }
    st.particles = keep;

    // emission
    let t0 = st.time;
    let t1 = t0 + dt;
    st.time = t1;
    let delay = st.delay;
    emit(def, st, t0 - delay, t1 - delay, emitter);
}

// ---------------------------------------------------------------------------------------------
// Render data
// ---------------------------------------------------------------------------------------------

pub struct RenderParticle {
    pub pos: V3,
    pub rot: V3,
    pub size: V3,
    pub color: [f32; 4],
    /// u0, v0, du, dv of the sprite-sheet frame
    pub uv: [f32; 4],
    pub vel: V3,
    /// Full world matrix for mesh particles.
    pub model: M4,
}

pub fn ps_render_list(def: &PsDef, st: &PsState, emitter: &M4) -> Vec<RenderParticle> {
    let mut out: Vec<RenderParticle> = Vec::with_capacity(st.particles.len());
    let em_ns = mat_remove_scale(emitter);
    let es = mat_column_scale(emitter);
    let local = def.sim_space != 1;
    let mut rot_only = em_ns;
    rot_only[12] = 0.0;
    rot_only[13] = 0.0;
    rot_only[14] = 0.0;
    if def.render_alignment == 1 {
        rot_only = mat_identity();
    }

    for p in st.particles.iter() {
        let nt = if p.life > 1e-6 { clamp01(p.age / p.life) } else { 1.0 };
        let mut size = p.size;
        if let Some(so) = &def.size_over {
            size = [
                size[0] * so.x.eval(nt, p.rnd),
                size[1] * so.y.eval(nt, p.rnd),
                size[2] * so.z.eval(nt, p.rnd),
            ];
        }
        let mut color = p.color;
        if let Some(co) = &def.color_over {
            let c = co.eval(nt, p.rnd);
            color = [color[0] * c[0], color[1] * c[1], color[2] * c[2], color[3] * c[3]];
        }
        let mut uv = [0.0f32, 0.0, 1.0, 1.0];
        if let Some(u) = &def.uv {
            let tx = u.tiles_x as f32;
            let ty = u.tiles_y as f32;
            let t = if u.cycles > 1.0 { (nt * u.cycles) % 1.0 } else { nt };
            let frac = u.frame_over_time.eval(t, p.rnd) + p.start_frame;
            let total = if u.anim_type == 1 { u.tiles_x } else { u.tiles_x * u.tiles_y };
            let mut f = (frac * total as f32).floor() as i32;
            f = ((f % total) + total) % total;
            let col = f % u.tiles_x;
            let row = if u.anim_type == 1 { u.row } else { f / u.tiles_x };
            let row = if row < 0 { 0 } else if row >= u.tiles_y { u.tiles_y - 1 } else { row };
            uv = [col as f32 / tx, 1.0 - (row as f32 + 1.0) / ty, 1.0 / tx, 1.0 / ty];
        }

        let (wpos, wvel, scale_mult) = if local {
            (
                mat_transform_point(emitter, p.pos),
                mat_transform_dir(emitter, p.vel),
                if def.scaling_mode == 2 { [1.0f32, 1.0, 1.0] } else { es },
            )
        } else {
            (p.pos, p.vel, [1.0f32, 1.0, 1.0])
        };

        let size_final = [size[0] * scale_mult[0], size[1] * scale_mult[1], size[2] * scale_mult[2]];
        let rq = quat_euler_rad(p.rot[0], p.rot[1], p.rot[2]);
        let part_m = mat_from_trs([0.0, 0.0, 0.0], rq, size_final);
        let model = mat_mul(
            &mat_from_trs(wpos, quat_identity(), [1.0, 1.0, 1.0]),
            &mat_mul(&rot_only, &part_m),
        );
        out.push(RenderParticle {
            pos: wpos,
            rot: p.rot,
            size: size_final,
            color,
            uv,
            vel: wvel,
            model,
        });
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    fn burst_def() -> PsDef {
        let mut d = parse_ps_def(&Value::None, "test");
        d.duration = 0.1;
        d.looping = false;
        d.max_particles = 10;
        d.emission_enabled = true;
        d.start_lifetime = MinMaxCurve::constant(0.5);
        d.bursts = vec![Burst { time: 0.0, count: MinMaxCurve::constant(1.0), cycles: 1, interval: 0.01 }];
        d
    }

    #[test]
    fn single_burst_spawns_one_particle_that_expires() {
        let def = burst_def();
        let mut st = PsState::new(1);
        let id = mat_identity();
        ps_update(&def, &mut st, 0.016, &id, true);
        assert_eq!(st.particles.len(), 1);
        for _ in 0..40 {
            ps_update(&def, &mut st, 0.016, &id, true);
        }
        assert_eq!(st.particles.len(), 0);
    }

    #[test]
    fn gradient_interpolates_alpha() {
        let g = Gradient {
            fixed: false,
            color_keys: vec![(0.0, [1.0, 1.0, 1.0]), (1.0, [0.0, 0.0, 0.0])],
            alpha_keys: vec![(0.0, 1.0), (1.0, 0.0)],
        };
        let c = g.eval(0.5);
        assert!((c[0] - 0.5).abs() < 1e-5 && (c[3] - 0.5).abs() < 1e-5);
    }

    #[test]
    fn min_max_curve_two_constants() {
        let c = MinMaxCurve { state: 3, scalar: 4.0, min_scalar: 2.0, max_keys: vec![], min_keys: vec![] };
        assert!((c.eval(0.0, 0.5) - 3.0).abs() < 1e-6);
    }
}
