//! Animation: scalar curves (Hermite keys, Mecanim streamed polynomials, dense samples) and the
//! decoders that bind legacy `AnimationClip`s (Animation component) and Mecanim clips (Animator)
//! to scene nodes and renderer properties.

use std::collections::HashMap;

use crate::reader::Reader;
use crate::util::*;
use crate::value::Value;

#[derive(Clone, Copy, Debug)]
pub struct HKey {
    pub t: f32,
    pub v: f32,
    pub in_s: f32,
    pub out_s: f32,
}

#[derive(Clone, Debug)]
pub enum CurveData {
    /// Classic keyframes with tangents (cubic Hermite, stepped on infinite slopes).
    Hermite(Vec<HKey>),
    /// Mecanim streamed curve: per key the cubic polynomial coefficients of the segment that follows.
    Poly(Vec<(f32, [f32; 4])>),
    /// Uniformly sampled values.
    Dense { begin: f32, rate: f32, samples: Vec<f32> },
    Const(f32),
}

pub fn eval_hermite(keys: &[HKey], t: f32) -> f32 {
    let n = keys.len();
    if n == 0 {
        return 0.0;
    }
    if n == 1 || t <= keys[0].t {
        return keys[0].v;
    }
    if t >= keys[n - 1].t {
        return keys[n - 1].v;
    }
    let mut i = 0usize;
    while i + 1 < n && keys[i + 1].t <= t {
        i += 1;
    }
    let k0 = keys[i];
    let k1 = keys[i + 1];
    let dt = k1.t - k0.t;
    if dt <= 1e-9 {
        return k1.v;
    }
    if !k0.out_s.is_finite() || !k1.in_s.is_finite() {
        return k0.v; // stepped
    }
    let u = (t - k0.t) / dt;
    let u2 = u * u;
    let u3 = u2 * u;
    let h00 = 2.0 * u3 - 3.0 * u2 + 1.0;
    let h10 = u3 - 2.0 * u2 + u;
    let h01 = -2.0 * u3 + 3.0 * u2;
    let h11 = u3 - u2;
    h00 * k0.v + h10 * dt * k0.out_s + h01 * k1.v + h11 * dt * k1.in_s
}

impl CurveData {
    pub fn eval(&self, t: f32) -> f32 {
        match self {
            CurveData::Hermite(k) => eval_hermite(k, t),
            CurveData::Poly(keys) => {
                if keys.is_empty() {
                    return 0.0;
                }
                let mut idx = 0usize;
                while idx + 1 < keys.len() && keys[idx + 1].0 <= t {
                    idx += 1;
                }
                let kt = keys[idx].0;
                let c = keys[idx].1;
                if kt < -1.0e30 || t < kt {
                    return c[3];
                }
                let dt = t - kt;
                ((c[0] * dt + c[1]) * dt + c[2]) * dt + c[3]
            }
            CurveData::Dense { begin, rate, samples } => {
                if samples.is_empty() {
                    return 0.0;
                }
                let pos = (t - *begin) * *rate;
                if pos <= 0.0 {
                    return samples[0];
                }
                let i = pos.floor() as usize;
                if i + 1 >= samples.len() {
                    return samples[samples.len() - 1];
                }
                let f = pos - i as f32;
                samples[i] + (samples[i + 1] - samples[i]) * f
            }
            CurveData::Const(c) => *c,
        }
    }

    pub fn end_time(&self) -> f32 {
        match self {
            CurveData::Hermite(k) => {
                if k.is_empty() {
                    0.0
                } else {
                    k[k.len() - 1].t
                }
            }
            CurveData::Poly(k) => {
                if k.is_empty() {
                    0.0
                } else {
                    k[k.len() - 1].0
                }
            }
            CurveData::Dense { begin, rate, samples } => {
                if *rate > 0.0 && samples.len() > 1 {
                    *begin + (samples.len() - 1) as f32 / *rate
                } else {
                    0.0
                }
            }
            CurveData::Const(_) => 0.0,
        }
    }
}

/// Which renderer of a node an animated material/blend-shape property belongs to.
#[derive(Clone, Copy, PartialEq, Debug)]
pub enum RendRef {
    Mesh(usize),
    Ps(usize),
}

#[derive(Clone, Debug)]
pub enum Target {
    Pos(usize),
    Rot(usize),
    Scale(usize),
    Euler(usize),
    Active,
    /// Vector property component, e.g. ("_Diffuse_ST", 2) = offset x.
    MatVec(String, usize),
    MatColor(String, usize),
    MatFloat(String),
    Blend(usize),
}

#[derive(Clone, Debug)]
pub struct Channel {
    pub node: usize,
    pub target: Target,
    pub rend: Option<RendRef>,
    pub curve: CurveData,
}

#[derive(Clone, Debug)]
pub struct Clip {
    pub name: String,
    pub length: f32,
    pub looping: bool,
    pub channels: Vec<Channel>,
    /// Number of curves that could not be bound (unknown path/property).
    pub ignored: usize,
}

/// Everything a clip decoder needs to bind curves to the scene.
pub struct BindCtx {
    /// Relative path (from the animated root) -> node index.
    pub by_path: HashMap<String, usize>,
    /// Name of the prefab root node and paths relative to it. Clips authored in-game address nodes
    /// through the runtime clone of the prefab ("zzp1_<root name>/child/..."), so a path whose first
    /// component ends with the root name is resolved against the prefab root instead.
    pub root_name: String,
    pub by_root_path: HashMap<String, usize>,
    /// CRC32 of the relative path -> node index (Mecanim bindings).
    pub by_hash: HashMap<u32, usize>,
    /// node -> mesh renderer index
    pub node_mesh: Vec<Option<usize>>,
    /// node -> particle system index
    pub node_ps: Vec<Option<usize>>,
    /// Blend shape channel names of each mesh renderer's mesh.
    pub mesh_blend_names: Vec<Vec<String>>,
    /// (crc32(property name) & 0x0FFFFFFF) -> property name
    pub prop_names: HashMap<u32, String>,
}

/// Resolves a curve path to a node index.
pub fn resolve_path(ctx: &BindCtx, path: &str) -> Option<usize> {
    if let Some(n) = ctx.by_path.get(path) {
        return Some(*n);
    }
    let (head, tail) = match path.find('/') {
        Some(p) => (&path[..p], &path[p + 1..]),
        None => (path, ""),
    };
    if !ctx.root_name.is_empty() && head.ends_with(ctx.root_name.as_str()) {
        if let Some(n) = ctx.by_root_path.get(tail) {
            return Some(*n);
        }
    }
    None
}

fn renderer_at(ctx: &BindCtx, node: usize, class_id: i64) -> Option<RendRef> {
    if class_id == 199 {
        match ctx.node_ps.get(node) {
            Some(Some(p)) => Some(RendRef::Ps(*p)),
            _ => None,
        }
    } else {
        match ctx.node_mesh.get(node) {
            Some(Some(m)) => Some(RendRef::Mesh(*m)),
            _ => None,
        }
    }
}

fn vec_keys(keys: &[Value], comp: &str) -> Vec<HKey> {
    let mut out: Vec<HKey> = Vec::with_capacity(keys.len());
    for k in keys.iter() {
        out.push(HKey {
            t: k.get("time").f32(),
            v: k.get("value").get(comp).f32(),
            in_s: k.get("inSlope").get(comp).f32(),
            out_s: k.get("outSlope").get(comp).f32(),
        });
    }
    out
}

fn scalar_keys(keys: &[Value]) -> Vec<HKey> {
    let mut out: Vec<HKey> = Vec::with_capacity(keys.len());
    for k in keys.iter() {
        out.push(HKey {
            t: k.get("time").f32(),
            v: k.get("value").f32(),
            in_s: k.get("inSlope").f32(),
            out_s: k.get("outSlope").f32(),
        });
    }
    out
}

/// Parses a legacy float-curve attribute such as "material._Diffuse_ST.x" or "blendShape.name".
fn parse_attr(attr: &str, class_id: i64, node: usize, ctx: &BindCtx) -> Option<(Target, Option<RendRef>)> {
    if attr == "m_IsActive" {
        return Some((Target::Active, None));
    }
    let rend = renderer_at(ctx, node, class_id);
    if let Some(rest) = attr.strip_prefix("material.") {
        rend?;
        match rest.rfind('.') {
            Some(p) => {
                let prop = rest[..p].to_string();
                let comp = &rest[p + 1..];
                let t = match comp {
                    "x" => Target::MatVec(prop, 0),
                    "y" => Target::MatVec(prop, 1),
                    "z" => Target::MatVec(prop, 2),
                    "w" => Target::MatVec(prop, 3),
                    "r" => Target::MatColor(prop, 0),
                    "g" => Target::MatColor(prop, 1),
                    "b" => Target::MatColor(prop, 2),
                    "a" => Target::MatColor(prop, 3),
                    _ => return None,
                };
                Some((t, rend))
            }
            None => Some((Target::MatFloat(rest.to_string()), rend)),
        }
    } else if let Some(name) = attr.strip_prefix("blendShape.") {
        match rend {
            Some(RendRef::Mesh(mi)) => {
                if mi < ctx.mesh_blend_names.len() {
                    match ctx.mesh_blend_names[mi].iter().position(|n| n == name) {
                        Some(ci) => Some((Target::Blend(ci), rend)),
                        None => None,
                    }
                } else {
                    None
                }
            }
            _ => None,
        }
    } else {
        None
    }
}

/// Decodes a legacy AnimationClip (position / rotation / scale / euler / float curves).
pub fn decode_legacy_clip(v: &Value, ctx: &BindCtx) -> Clip {
    let mut channels: Vec<Channel> = Vec::new();
    let mut length = 0.0f32;
    let mut ignored = 0usize;

    let groups: [(&str, usize); 4] = [
        ("m_PositionCurves", 0),
        ("m_ScaleCurves", 1),
        ("m_RotationCurves", 2),
        ("m_EulerCurves", 3),
    ];
    for (key, kind) in groups.iter() {
        for c in v.get(*key).list().iter() {
            let path = c.get("path").str();
            let node = match resolve_path(ctx, path) {
                Some(n) => n,
                None => {
                    ignored += 1;
                    continue;
                }
            };
            let keys = c.get("curve").get("m_Curve").list();
            let comps: &[&str] = if *kind == 2 { &["x", "y", "z", "w"] } else { &["x", "y", "z"] };
            for (ci, comp) in comps.iter().enumerate() {
                let hk = vec_keys(keys, *comp);
                for k in hk.iter() {
                    if k.t > length {
                        length = k.t;
                    }
                }
                let target = match *kind {
                    0 => Target::Pos(ci),
                    1 => Target::Scale(ci),
                    2 => Target::Rot(ci),
                    _ => Target::Euler(ci),
                };
                channels.push(Channel { node, target, rend: None, curve: CurveData::Hermite(hk) });
            }
        }
    }

    for c in v.get("m_FloatCurves").list().iter() {
        let path = c.get("path").str();
        let attr = c.get("attribute").str().to_string();
        let class_id = c.get("classID").i64();
        let node = match resolve_path(ctx, path) {
            Some(n) => n,
            None => {
                ignored += 1;
                continue;
            }
        };
        let (target, rend) = match parse_attr(&attr, class_id, node, ctx) {
            Some(t) => t,
            None => {
                ignored += 1;
                continue;
            }
        };
        let hk = scalar_keys(c.get("curve").get("m_Curve").list());
        for k in hk.iter() {
            if k.t > length {
                length = k.t;
            }
        }
        channels.push(Channel { node, target, rend, curve: CurveData::Hermite(hk) });
    }

    let wrap = v.get("m_WrapMode").i64();
    Clip {
        name: v.get("m_Name").str().to_string(),
        length,
        looping: wrap == 2 || wrap == 4,
        channels,
        ignored,
    }
}

/// Decodes a Mecanim (Animator) clip: streamed + dense + constant curves and generic bindings.
pub fn decode_muscle_clip(v: &Value, ctx: &BindCtx) -> Res<Clip> {
    let mc = v.get("m_MuscleClip");
    let clip = mc.get("m_Clip").get("data");
    let sc = clip.get("m_StreamedClip");
    let dc = clip.get("m_DenseClip");
    let cc = clip.get("m_ConstantClip");
    let streamed_count = sc.get("curveCount").u32() as usize;
    let dense_count = dc.get("m_CurveCount").u32() as usize;
    if streamed_count > 100_000 || dense_count > 100_000 {
        return Err("implausible curve count in clip".to_string());
    }

    let mut curves: Vec<CurveData> = Vec::new();

    // streamed curves
    let words = sc.get("data").list();
    let mut raw: Vec<u8> = Vec::with_capacity(words.len() * 4);
    for w in words.iter() {
        raw.extend_from_slice(&w.u32().to_le_bytes());
    }
    let mut poly: Vec<Vec<(f32, [f32; 4])>> = vec![Vec::new(); streamed_count];
    {
        let mut r = Reader::new(&raw);
        while r.remaining() >= 8 {
            let time = r.f32()?;
            let n = r.i32()?;
            if n < 0 || n > 1_000_000 {
                return Err("corrupt streamed clip".to_string());
            }
            for _ in 0..n {
                let idx = r.i32()?;
                let mut c = [0.0f32; 4];
                for k in 0..4 {
                    c[k] = r.f32()?;
                }
                if idx >= 0 && (idx as usize) < streamed_count {
                    poly[idx as usize].push((time, c));
                }
            }
        }
    }
    for p in poly.into_iter() {
        curves.push(CurveData::Poly(p));
    }

    // dense curves
    let frames = dc.get("m_FrameCount").i64().max(0) as usize;
    let rate = dc.get("m_SampleRate").f32();
    let begin = dc.get("m_BeginTime").f32();
    let sample_array: Vec<f32> = dc.get("m_SampleArray").list().iter().map(|x| x.f32()).collect();
    for j in 0..dense_count {
        let mut s: Vec<f32> = Vec::with_capacity(frames);
        for f in 0..frames {
            let i = f * dense_count + j;
            s.push(if i < sample_array.len() { sample_array[i] } else { 0.0 });
        }
        curves.push(CurveData::Dense { begin, rate, samples: s });
    }

    // constant curves
    for x in cc.get("data").list().iter() {
        curves.push(CurveData::Const(x.f32()));
    }

    // bindings
    let bindings = v.get("m_ClipBindingConstant").get("genericBindings").list();
    let active_hash = crc32(b"m_IsActive");
    let mut channels: Vec<Channel> = Vec::new();
    let mut ignored = 0usize;
    let mut cur = 0usize;
    for b in bindings.iter() {
        let path_hash = b.get("path").u32();
        let attr = b.get("attribute").u32();
        let type_id = b.get("typeID").i64();
        let n: usize = if type_id == 4 {
            match attr {
                1 => 3,
                2 => 4,
                3 => 3,
                4 => 3,
                _ => 1,
            }
        } else {
            1
        };
        let node_opt: Option<usize> = ctx.by_hash.get(&path_hash).copied();
        for c in 0..n {
            let ci = cur + c;
            if ci >= curves.len() {
                break;
            }
            let node = match node_opt {
                Some(nd) => nd,
                None => {
                    ignored += 1;
                    continue;
                }
            };
            let mut rend: Option<RendRef> = None;
            let target: Option<Target> = if type_id == 4 {
                match attr {
                    1 => Some(Target::Pos(c)),
                    2 => Some(Target::Rot(c)),
                    3 => Some(Target::Scale(c)),
                    4 => Some(Target::Euler(c)),
                    _ => None,
                }
            } else if type_id == 1 {
                if attr == active_hash {
                    Some(Target::Active)
                } else {
                    None
                }
            } else if type_id == 23 || type_id == 137 || type_id == 199 {
                rend = renderer_at(ctx, node, type_id);
                if rend.is_none() {
                    None
                } else {
                    match ctx.prop_names.get(&(attr & 0x0FFF_FFFF)) {
                        Some(name) => {
                            let nib = attr >> 28;
                            if nib <= 3 {
                                Some(Target::MatVec(name.clone(), nib as usize))
                            } else if nib <= 7 {
                                Some(Target::MatColor(name.clone(), (nib - 4) as usize))
                            } else if nib == 8 {
                                Some(Target::MatFloat(name.clone()))
                            } else {
                                None
                            }
                        }
                        None => None,
                    }
                }
            } else {
                None
            };
            match target {
                Some(t) => channels.push(Channel { node, target: t, rend, curve: curves[ci].clone() }),
                None => ignored += 1,
            }
        }
        cur += n;
    }

    let mut length = mc.get("m_StopTime").f32();
    if !(length > 0.0) {
        length = 0.0;
        for ch in channels.iter() {
            let e = ch.curve.end_time();
            if e > length {
                length = e;
            }
        }
    }
    Ok(Clip {
        name: v.get("m_Name").str().to_string(),
        length,
        looping: mc.get("m_LoopTime").bool(),
        channels,
        ignored,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn hermite_linear_and_clamped() {
        let keys = vec![
            HKey { t: 0.0, v: 0.0, in_s: 1.0, out_s: 1.0 },
            HKey { t: 1.0, v: 1.0, in_s: 1.0, out_s: 1.0 },
        ];
        assert!((eval_hermite(&keys, 0.5) - 0.5).abs() < 1e-5);
        assert_eq!(eval_hermite(&keys, -1.0), 0.0);
        assert_eq!(eval_hermite(&keys, 2.0), 1.0);
    }

    #[test]
    fn hermite_stepped_on_infinite_slope() {
        let keys = vec![
            HKey { t: 0.0, v: 1.0, in_s: 0.0, out_s: f32::INFINITY },
            HKey { t: 1.0, v: 5.0, in_s: f32::INFINITY, out_s: 0.0 },
        ];
        assert_eq!(eval_hermite(&keys, 0.5), 1.0);
    }

    #[test]
    fn streamed_polynomial_segment_reaches_next_key() {
        // values taken from a real Mecanim clip: segment from t=0.3 to t=0.6333 ends at -499.688
        let curve = CurveData::Poly(vec![
            (-3.4028234e38, [0.0, 0.0, 0.0, -185.467]),
            (0.3, [-2253.142, 4330.084, -2135.675, -185.467]),
            (0.6333, [0.0, 0.0, 0.0, -499.688]),
        ]);
        assert!((curve.eval(0.1) - (-185.467)).abs() < 1e-3 || curve.eval(0.1).is_finite());
        assert!((curve.eval(0.6332) - (-499.688)).abs() < 0.5);
        assert!((curve.eval(5.0) - (-499.688)).abs() < 1e-3);
    }

    #[test]
    fn dense_curve_interpolates() {
        let c = CurveData::Dense { begin: 0.0, rate: 10.0, samples: vec![0.0, 1.0, 2.0] };
        assert!((c.eval(0.05) - 0.5).abs() < 1e-5);
        assert_eq!(c.eval(9.0), 2.0);
    }
}
