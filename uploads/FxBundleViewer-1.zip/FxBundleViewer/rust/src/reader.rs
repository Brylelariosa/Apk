//! Bounds-checked binary reader used by the bundle and serialized-file parsers.

use crate::util::Res;

pub struct Reader<'a> {
    pub data: &'a [u8],
    pub pos: usize,
    pub big: bool,
}

impl<'a> Reader<'a> {
    pub fn new(data: &'a [u8]) -> Reader<'a> {
        Reader { data, pos: 0, big: false }
    }

    pub fn new_be(data: &'a [u8]) -> Reader<'a> {
        Reader { data, pos: 0, big: true }
    }

    pub fn remaining(&self) -> usize {
        if self.pos >= self.data.len() {
            0
        } else {
            self.data.len() - self.pos
        }
    }

    fn take(&mut self, n: usize) -> Res<&'a [u8]> {
        let end = match self.pos.checked_add(n) {
            Some(e) => e,
            None => return Err("read overflow".to_string()),
        };
        if end > self.data.len() {
            return Err(format!(
                "read past end of data (pos {} + {} > {})",
                self.pos,
                n,
                self.data.len()
            ));
        }
        let d: &'a [u8] = self.data;
        let s = &d[self.pos..end];
        self.pos = end;
        Ok(s)
    }

    pub fn u8(&mut self) -> Res<u8> {
        let s = self.take(1)?;
        Ok(s[0])
    }

    pub fn i8(&mut self) -> Res<i8> {
        Ok(self.u8()? as i8)
    }

    pub fn u16(&mut self) -> Res<u16> {
        let s = self.take(2)?;
        let a = [s[0], s[1]];
        Ok(if self.big { u16::from_be_bytes(a) } else { u16::from_le_bytes(a) })
    }

    pub fn i16(&mut self) -> Res<i16> {
        Ok(self.u16()? as i16)
    }

    pub fn u32(&mut self) -> Res<u32> {
        let s = self.take(4)?;
        let a = [s[0], s[1], s[2], s[3]];
        Ok(if self.big { u32::from_be_bytes(a) } else { u32::from_le_bytes(a) })
    }

    pub fn i32(&mut self) -> Res<i32> {
        Ok(self.u32()? as i32)
    }

    pub fn u64(&mut self) -> Res<u64> {
        let s = self.take(8)?;
        let a = [s[0], s[1], s[2], s[3], s[4], s[5], s[6], s[7]];
        Ok(if self.big { u64::from_be_bytes(a) } else { u64::from_le_bytes(a) })
    }

    pub fn i64(&mut self) -> Res<i64> {
        Ok(self.u64()? as i64)
    }

    pub fn f32(&mut self) -> Res<f32> {
        Ok(f32::from_bits(self.u32()?))
    }

    pub fn f64(&mut self) -> Res<f64> {
        Ok(f64::from_bits(self.u64()?))
    }

    pub fn bytes(&mut self, n: usize) -> Res<&'a [u8]> {
        self.take(n)
    }

    pub fn skip(&mut self, n: usize) -> Res<()> {
        self.take(n)?;
        Ok(())
    }

    /// Reads a NUL-terminated UTF-8 string.
    pub fn cstr(&mut self) -> Res<String> {
        let d: &'a [u8] = self.data;
        let start = self.pos;
        let mut i = start;
        while i < d.len() && d[i] != 0 {
            i += 1;
        }
        if i >= d.len() {
            return Err("unterminated string".to_string());
        }
        let s = String::from_utf8_lossy(&d[start..i]).to_string();
        self.pos = i + 1;
        Ok(s)
    }

    pub fn align(&mut self, n: usize) {
        let r = self.pos % n;
        if r != 0 {
            self.pos += n - r;
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn reads_both_endians() {
        let data = [0x01u8, 0x02, 0x03, 0x04];
        let mut be = Reader::new_be(&data);
        assert_eq!(be.u32().unwrap(), 0x0102_0304);
        let mut le = Reader::new(&data);
        assert_eq!(le.u32().unwrap(), 0x0403_0201);
        assert!(le.u8().is_err());
    }

    #[test]
    fn reads_cstring_and_aligns() {
        let data = b"abc\0xyz";
        let mut r = Reader::new(data);
        assert_eq!(r.cstr().unwrap(), "abc");
        r.align(4);
        assert_eq!(r.pos, 4);
    }
}
