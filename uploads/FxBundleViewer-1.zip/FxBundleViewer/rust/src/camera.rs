//! Orbit camera. World space follows Unity's left-handed convention.

use crate::util::*;

#[derive(Clone, Debug)]
pub struct Camera {
    pub target: V3,
    pub dist: f32,
    pub yaw: f32,
    pub pitch: f32,
    pub fov_deg: f32,
}

impl Camera {
    pub fn new() -> Camera {
        Camera { target: [0.0, 1.0, 0.0], dist: 9.0, yaw: 0.6, pitch: 0.35, fov_deg: 45.0 }
    }

    pub fn eye(&self) -> V3 {
        let cp = self.pitch.cos();
        [
            self.target[0] + self.dist * cp * self.yaw.sin(),
            self.target[1] + self.dist * self.pitch.sin(),
            self.target[2] - self.dist * cp * self.yaw.cos(),
        ]
    }

    pub fn view(&self) -> M4 {
        mat_look_at_lh(self.eye(), self.target, [0.0, 1.0, 0.0])
    }

    pub fn proj(&self, aspect: f32) -> M4 {
        mat_perspective(self.fov_deg.to_radians(), if aspect > 0.01 { aspect } else { 1.0 }, 0.05, 400.0)
    }

    /// Camera right, up and forward vectors in world space.
    pub fn axes(&self) -> (V3, V3, V3) {
        let v = self.view();
        ([v[0], v[4], v[8]], [v[1], v[5], v[9]], [-v[2], -v[6], -v[10]])
    }

    /// `dx`, `dy` are finger movements in pixels.
    pub fn orbit(&mut self, dx: f32, dy: f32) {
        self.yaw -= dx * 0.008;
        self.pitch = clampf(self.pitch + dy * 0.008, -1.5, 1.5);
    }

    /// factor > 1 zooms in.
    pub fn zoom(&mut self, factor: f32) {
        if factor > 0.01 {
            self.dist = clampf(self.dist / factor, 0.3, 150.0);
        }
    }

    pub fn pan(&mut self, dx: f32, dy: f32) {
        let (right, up, _) = self.axes();
        let k = self.dist * 0.0016;
        self.target = v3_add(self.target, v3_add(v3_scale(right, -dx * k), v3_scale(up, dy * k)));
    }

    /// Fits the camera around an axis-aligned box without changing the viewing angle.
    pub fn frame(&mut self, bmin: V3, bmax: V3) {
        let c = [
            (bmin[0] + bmax[0]) * 0.5,
            (bmin[1] + bmax[1]) * 0.5,
            (bmin[2] + bmax[2]) * 0.5,
        ];
        let ext = v3_sub(bmax, bmin);
        let radius = (0.5 * v3_len(ext)).max(0.5);
        self.target = c;
        let half_fov = (self.fov_deg.to_radians() * 0.5).sin().max(0.1);
        self.dist = clampf(radius / half_fov * 1.15, 2.0, 120.0);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn view_matrix_puts_target_in_front() {
        let cam = Camera::new();
        let v = cam.view();
        let p = mat_transform_point(&v, cam.target);
        // target must lie on the -Z axis of camera space at distance `dist`
        assert!(p[0].abs() < 1e-4 && p[1].abs() < 1e-4);
        assert!((p[2] + cam.dist).abs() < 1e-3);
    }

    #[test]
    fn zoom_clamps() {
        let mut cam = Camera::new();
        cam.zoom(1000.0);
        assert!(cam.dist >= 0.3);
        cam.zoom(0.0001);
        assert!(cam.dist <= 150.0);
    }
}
