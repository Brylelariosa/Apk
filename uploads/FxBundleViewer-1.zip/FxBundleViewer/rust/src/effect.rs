//! Builds a renderable `Effect` (node hierarchy, mesh renderers, particle systems, clips) from an
//! AssetBundle, and provides the `Runtime` that animates it frame by frame.

use std::collections::HashMap;

use crate::anim::*;
use crate::assets::*;
use crate::bundle::{compression_name, parse_bundle, Bundle, BundleFile};
use crate::particles::*;
use crate::serialized::SerializedFile;
use crate::util::*;
use crate::value::Value;

// =============================================================================================
// Static description
// =============================================================================================

pub struct Node {
    pub name: String,
    pub parent: i32,
    pub pos: V3,
    pub rot: Quat,
    pub scale: V3,
    pub active: bool,
}

pub struct MeshRend {
    pub node: usize,
    pub mesh: Option<usize>,
    pub materials: Vec<Option<usize>>,
    pub enabled: bool,
    pub skinned: bool,
    pub init_blend: Vec<f32>,
}

pub struct PsEntry {
    pub node: usize,
    pub def: PsDef,
    pub material: Option<usize>,
    pub mesh: Option<usize>,
}

pub struct Effect {
    pub name: String,
    pub container: String,
    pub nodes: Vec<Node>,
    pub meshes: Vec<MeshData>,
    pub textures: Vec<TexData>,
    pub materials: Vec<MaterialData>,
    pub mesh_rends: Vec<MeshRend>,
    pub systems: Vec<PsEntry>,
    pub clips: Vec<Clip>,
    pub duration: f32,
    pub bmin: V3,
    pub bmax: V3,
    pub has_prop_anim: bool,
    pub info: String,
}

impl Effect {
    /// Minimal single-node effect (used by tests and as a safe fallback).
    pub fn empty(name: &str) -> Effect {
        Effect {
            name: name.to_string(),
            container: String::new(),
            nodes: vec![Node {
                name: name.to_string(),
                parent: -1,
                pos: [0.0; 3],
                rot: [0.0, 0.0, 0.0, 1.0],
                scale: [1.0; 3],
                active: true,
            }],
            meshes: Vec::new(),
            textures: Vec::new(),
            materials: Vec::new(),
            mesh_rends: Vec::new(),
            systems: Vec::new(),
            clips: Vec::new(),
            duration: 1.0,
            bmin: [-1.0, 0.0, -1.0],
            bmax: [1.0, 2.0, 1.0],
            has_prop_anim: false,
            info: String::new(),
        }
    }
}

// =============================================================================================
// Material parameters
// =============================================================================================

/// Material properties that animation can override at runtime.
#[derive(Clone)]
pub struct PropSet {
    pub vecs: Vec<(String, [f32; 4])>,
    pub colors: Vec<(String, [f32; 4])>,
    pub floats: Vec<(String, f32)>,
}

impl PropSet {
    pub fn empty() -> PropSet {
        PropSet { vecs: Vec::new(), colors: Vec::new(), floats: Vec::new() }
    }

    pub fn from_material(m: &MaterialData) -> PropSet {
        let mut vecs: Vec<(String, [f32; 4])> = Vec::new();
        for s in m.slots.iter() {
            vecs.push((format!("{}_ST", s.name), [s.scale[0], s.scale[1], s.offset[0], s.offset[1]]));
        }
        PropSet { vecs, colors: m.colors.clone(), floats: m.floats.clone() }
    }

    pub fn set_vec(&mut self, name: &str, comp: usize, v: f32) {
        if comp > 3 {
            return;
        }
        for e in self.vecs.iter_mut() {
            if e.0 == name {
                e.1[comp] = v;
                return;
            }
        }
        let mut a = [1.0f32, 1.0, 0.0, 0.0];
        a[comp] = v;
        self.vecs.push((name.to_string(), a));
    }

    pub fn set_color(&mut self, name: &str, comp: usize, v: f32) {
        if comp > 3 {
            return;
        }
        for e in self.colors.iter_mut() {
            if e.0 == name {
                e.1[comp] = v;
                return;
            }
        }
        let mut a = [1.0f32, 1.0, 1.0, 1.0];
        a[comp] = v;
        self.colors.push((name.to_string(), a));
    }

    pub fn set_float(&mut self, name: &str, v: f32) {
        for e in self.floats.iter_mut() {
            if e.0 == name {
                e.1 = v;
                return;
            }
        }
        self.floats.push((name.to_string(), v));
    }

    pub fn vec(&self, name: &str) -> Option<[f32; 4]> {
        for e in self.vecs.iter() {
            if e.0 == name {
                return Some(e.1);
            }
        }
        None
    }

    pub fn color(&self, name: &str) -> Option<[f32; 4]> {
        for e in self.colors.iter() {
            if e.0 == name {
                return Some(e.1);
            }
        }
        None
    }

    pub fn float(&self, name: &str) -> Option<f32> {
        for e in self.floats.iter() {
            if e.0 == name {
                return Some(e.1);
            }
        }
        None
    }
}

#[derive(Clone, Copy, PartialEq, Debug)]
pub enum Blend {
    Additive,
    Alpha,
    Opaque,
}

pub struct DrawParams {
    pub diffuse: Option<usize>,
    pub mask: Option<usize>,
    pub diff_st: [f32; 4],
    pub mask_st: [f32; 4],
    pub tint: [f32; 4],
    pub intensity: f32,
    pub blend: Blend,
    pub queue: i32,
}

const DIFFUSE_SLOTS: [&str; 5] = ["_Diffuse", "_diffuse", "_MainTex", "_BaseMap", "_BaseColorMap"];
const MASK_SLOTS: [&str; 3] = ["_Mask", "_mask", "_MaskTex"];
const TINT_NAMES: [&str; 4] = ["_DiffuseColor", "_TintColor", "_Color", "_BaseColor"];
const INTENSITY_NAMES: [&str; 4] = ["_Intensity", "_intensity", "_ColorIntensity", "_DiffuseIntensity"];

/// Guesses the blend mode of a material. The effect shaders live in a separate bundle that is
/// usually not available, so this relies on leftover blend properties and on whether the
/// diffuse texture carries alpha (RGB-only effect textures are almost always additive).
pub fn auto_blend(fx: &Effect, m: &MaterialData, diffuse: Option<usize>) -> Blend {
    if let (Some(s), Some(d)) = (m.float("_SrcBlend"), m.float("_DstBlend")) {
        let _src = s.round() as i32;
        let dst = d.round() as i32;
        if dst == 1 {
            return Blend::Additive;
        }
        if dst == 10 {
            return Blend::Alpha;
        }
    }
    match diffuse {
        Some(ti) => {
            if ti < fx.textures.len() && fx.textures[ti].has_alpha {
                Blend::Alpha
            } else {
                Blend::Additive
            }
        }
        None => Blend::Alpha,
    }
}

pub fn resolve_params(fx: &Effect, mat: Option<usize>, props: Option<&PropSet>, blend_override: i32) -> DrawParams {
    let m: &MaterialData = match mat {
        Some(i) if i < fx.materials.len() => &fx.materials[i],
        _ => {
            return DrawParams {
                diffuse: None,
                mask: None,
                diff_st: [1.0, 1.0, 0.0, 0.0],
                mask_st: [1.0, 1.0, 0.0, 0.0],
                tint: [1.0, 1.0, 1.0, 1.0],
                intensity: 1.0,
                blend: match blend_override {
                    1 => Blend::Additive,
                    3 => Blend::Opaque,
                    _ => Blend::Alpha,
                },
                queue: 3000,
            }
        }
    };
    let dslot = m.slot(&DIFFUSE_SLOTS);
    let mslot = m.slot(&MASK_SLOTS);
    let diffuse = match dslot {
        Some(s) => s.tex,
        None => None,
    };
    let mask = match mslot {
        Some(s) => s.tex,
        None => None,
    };

    let st_for = |slot: Option<&TexSlot>| -> [f32; 4] {
        match slot {
            Some(s) => {
                let name = format!("{}_ST", s.name);
                let over = match props {
                    Some(p) => p.vec(&name),
                    None => None,
                };
                match over {
                    Some(v) => v,
                    None => [s.scale[0], s.scale[1], s.offset[0], s.offset[1]],
                }
            }
            None => [1.0, 1.0, 0.0, 0.0],
        }
    };
    let diff_st = st_for(dslot);
    let mask_st = st_for(mslot);

    let mut tint = [1.0f32, 1.0, 1.0, 1.0];
    for name in TINT_NAMES.iter() {
        let over = match props {
            Some(p) => p.color(name),
            None => None,
        };
        let c = match over {
            Some(c) => Some(c),
            None => m.color(name),
        };
        if let Some(c) = c {
            tint = c;
            break;
        }
    }

    let mut intensity = 1.0f32;
    for name in INTENSITY_NAMES.iter() {
        let over = match props {
            Some(p) => p.float(name),
            None => None,
        };
        let f = match over {
            Some(f) => Some(f),
            None => m.float(name),
        };
        if let Some(f) = f {
            intensity = f;
            break;
        }
    }

    let blend = match blend_override {
        1 => Blend::Additive,
        2 => Blend::Alpha,
        3 => Blend::Opaque,
        _ => auto_blend(fx, m, diffuse),
    };
    DrawParams {
        diffuse,
        mask,
        diff_st,
        mask_st,
        tint,
        intensity,
        blend,
        queue: if m.queue > 0 { m.queue } else { 3000 },
    }
}

// =============================================================================================
// Building
// =============================================================================================

type ObjMap = HashMap<i64, (String, Value)>;

struct Builder<'a> {
    objs: ObjMap,
    files: &'a [BundleFile],
    major: u32,
    meshes: Vec<MeshData>,
    textures: Vec<TexData>,
    materials: Vec<MaterialData>,
    mesh_map: HashMap<i64, usize>,
    tex_map: HashMap<i64, usize>,
    mat_map: HashMap<i64, usize>,
}

impl<'a> Builder<'a> {
    fn value_of(&self, pid: i64) -> Value {
        match self.objs.get(&pid) {
            Some((_, v)) => v.clone(),
            None => Value::None,
        }
    }

    fn mesh(&mut self, pid: i64) -> Option<usize> {
        if pid == 0 {
            return None;
        }
        if let Some(i) = self.mesh_map.get(&pid) {
            return Some(*i);
        }
        let decoded = match self.objs.get(&pid) {
            Some((t, v)) if t == "Mesh" => decode_mesh(v, self.major),
            _ => return None,
        };
        match decoded {
            Ok(m) => {
                let i = self.meshes.len();
                self.meshes.push(m);
                self.mesh_map.insert(pid, i);
                Some(i)
            }
            Err(e) => {
                log_w!("mesh {}: {}", pid, e);
                None
            }
        }
    }

    fn texture(&mut self, pid: i64) -> Option<usize> {
        if pid == 0 {
            return None;
        }
        if let Some(i) = self.tex_map.get(&pid) {
            return Some(*i);
        }
        let tex = match self.objs.get(&pid) {
            Some((t, v)) if t == "Texture2D" => decode_texture(v, self.files),
            _ => return None,
        };
        let i = self.textures.len();
        self.textures.push(tex);
        self.tex_map.insert(pid, i);
        Some(i)
    }

    fn material(&mut self, pid: i64) -> Option<usize> {
        if pid == 0 {
            return None;
        }
        if let Some(i) = self.mat_map.get(&pid) {
            return Some(*i);
        }
        let mut mat = match self.objs.get(&pid) {
            Some((t, v)) if t == "Material" => decode_material(v),
            _ => return None,
        };
        for k in 0..mat.slots.len() {
            let tp = mat.slots[k].tex_path_id;
            let ti = self.texture(tp);
            mat.slots[k].tex = ti;
        }
        let i = self.materials.len();
        self.materials.push(mat);
        self.mat_map.insert(pid, i);
        Some(i)
    }
}

fn add_node(
    objs: &ObjMap,
    go_id: i64,
    parent: i32,
    nodes: &mut Vec<Node>,
    comps: &mut Vec<Vec<(String, i64)>>,
    depth: usize,
) {
    let gv: &Value = match objs.get(&go_id) {
        Some((t, v)) if t == "GameObject" => v,
        _ => return,
    };
    let name = gv.get("m_Name").str().to_string();
    let active = gv.get("m_IsActive").bool();
    let mut comp_list: Vec<(String, i64)> = Vec::new();
    let mut tf_id = 0i64;
    for c in gv.get("m_Component").list().iter() {
        let pid = c.get("component").pptr_local();
        if let Some((t, _)) = objs.get(&pid) {
            if t == "Transform" || t == "RectTransform" {
                tf_id = pid;
            }
            comp_list.push((t.clone(), pid));
        }
    }
    let mut pos = [0.0f32; 3];
    let mut rot = [0.0f32, 0.0, 0.0, 1.0];
    let mut scale = [1.0f32; 3];
    let mut children: Vec<i64> = Vec::new();
    if let Some((_, tv)) = objs.get(&tf_id) {
        pos = tv.get("m_LocalPosition").vec3();
        rot = tv.get("m_LocalRotation").vec4();
        if tv.get("m_LocalScale").has("x") {
            scale = tv.get("m_LocalScale").vec3();
        }
        for c in tv.get("m_Children").list().iter() {
            children.push(c.pptr_local());
        }
    }
    let idx = nodes.len();
    nodes.push(Node { name, parent, pos, rot, scale, active });
    comps.push(comp_list);
    if depth < 64 {
        for ctf in children.iter() {
            if let Some((_, ctv)) = objs.get(ctf) {
                let cgo = ctv.get("m_GameObject").pptr_local();
                add_node(objs, cgo, idx as i32, nodes, comps, depth + 1);
            }
        }
    }
}

fn find_root_go(objs: &ObjMap) -> (i64, String) {
    let mut container = String::new();
    let mut root: i64 = 0;
    for (_, (t, v)) in objs.iter() {
        if t == "AssetBundle" {
            let c = v.get("m_Container").list();
            if !c.is_empty() {
                container = c[0].get("first").str().to_string();
                root = c[0].get("second").get("asset").pptr_local();
            }
        }
    }
    if root != 0 && objs.contains_key(&root) {
        // the container may point at a Transform-less asset; require a GameObject
        if let Some((t, _)) = objs.get(&root) {
            if t == "GameObject" {
                return (root, container);
            }
        }
    }
    // fallback: the GameObject (lowest path id) whose transform has no parent
    let mut best: i64 = 0;
    for (pid, (t, v)) in objs.iter() {
        if t == "Transform" && v.get("m_Father").pptr_local() == 0 {
            let go = v.get("m_GameObject").pptr_local();
            if go != 0 && (best == 0 || go < best) {
                best = go;
            }
        }
    }
    (best, container)
}

fn rel_path(nodes: &Vec<Node>, root: usize, i: usize) -> Option<String> {
    let mut parts: Vec<String> = Vec::new();
    let mut cur: i32 = i as i32;
    let mut guard = 0;
    while cur >= 0 && guard < 256 {
        if cur as usize == root {
            parts.reverse();
            return Some(parts.join("/"));
        }
        parts.push(nodes[cur as usize].name.clone());
        cur = nodes[cur as usize].parent;
        guard += 1;
    }
    None
}

fn base_world(nodes: &Vec<Node>) -> Vec<M4> {
    let mut world: Vec<M4> = Vec::with_capacity(nodes.len());
    for i in 0..nodes.len() {
        let local = mat_from_trs(nodes[i].pos, nodes[i].rot, nodes[i].scale);
        let p = nodes[i].parent;
        if p >= 0 && (p as usize) < world.len() {
            let m = mat_mul(&world[p as usize], &local);
            world.push(m);
        } else {
            world.push(local);
        }
    }
    world
}

pub fn effect_from_bundle(bundle: &Bundle) -> Res<Effect> {
    // 1. locate the serialized file
    let mut sf_opt: Option<SerializedFile> = None;
    for f in bundle.files.iter() {
        let lower = f.name.to_lowercase();
        if lower.ends_with(".ress") || lower.ends_with(".resource") {
            continue;
        }
        match SerializedFile::parse(&f.data) {
            Ok(s) => {
                sf_opt = Some(s);
                break;
            }
            Err(e) => log_w!("{}: {}", f.name, e),
        }
    }
    let sf = match sf_opt {
        Some(s) => s,
        None => return Err("no readable serialized file inside the bundle".to_string()),
    };
    if !sf.has_type_tree {
        return Err("bundle was built without type trees; its object layout cannot be read".to_string());
    }

    // 2. read the objects we care about
    let mut objs: ObjMap = HashMap::new();
    let mut counts: HashMap<String, usize> = HashMap::new();
    for o in sf.objects.iter() {
        let tname = sf.type_name(o);
        *counts.entry(tname.clone()).or_insert(0) += 1;
        let wanted = matches!(
            tname.as_str(),
            "GameObject"
                | "Transform"
                | "RectTransform"
                | "Material"
                | "MeshRenderer"
                | "MeshFilter"
                | "Mesh"
                | "Texture2D"
                | "AnimationClip"
                | "Animation"
                | "Animator"
                | "AnimatorController"
                | "SkinnedMeshRenderer"
                | "ParticleSystem"
                | "ParticleSystemRenderer"
                | "AssetBundle"
        );
        if wanted {
            match sf.read_object(o) {
                Ok(v) => {
                    objs.insert(o.path_id, (tname, v));
                }
                Err(e) => {
                    log_w!("object {} ({}): {}", o.path_id, tname, e);
                }
            }
        }
    }

    // 3. hierarchy
    let (root_go, container) = find_root_go(&objs);
    if root_go == 0 {
        return Err("bundle contains no prefab/GameObject hierarchy to render".to_string());
    }
    let mut nodes: Vec<Node> = Vec::new();
    let mut node_comps: Vec<Vec<(String, i64)>> = Vec::new();
    add_node(&objs, root_go, -1, &mut nodes, &mut node_comps, 0);
    if nodes.is_empty() {
        return Err("prefab hierarchy is empty".to_string());
    }
    let n = nodes.len();

    // 4. components
    let mut b = Builder {
        objs,
        files: &bundle.files,
        major: sf.unity_major(),
        meshes: Vec::new(),
        textures: Vec::new(),
        materials: Vec::new(),
        mesh_map: HashMap::new(),
        tex_map: HashMap::new(),
        mat_map: HashMap::new(),
    };
    let mut mesh_rends: Vec<MeshRend> = Vec::new();
    let mut systems: Vec<PsEntry> = Vec::new();
    let mut node_mesh: Vec<Option<usize>> = vec![None; n];
    let mut node_ps: Vec<Option<usize>> = vec![None; n];
    // (node, clip object id, uses controller)
    let mut anim_sources: Vec<(usize, i64)> = Vec::new();

    for ni in 0..n {
        let comps = node_comps[ni].clone();
        let mut filter_mesh: i64 = 0;
        let mut renderer: Option<(String, i64)> = None;
        let mut ps_pid: i64 = 0;
        let mut psr_pid: i64 = 0;
        for (t, pid) in comps.iter() {
            match t.as_str() {
                "MeshFilter" => {
                    filter_mesh = b.value_of(*pid).get("m_Mesh").pptr_local();
                }
                "MeshRenderer" | "SkinnedMeshRenderer" => {
                    renderer = Some((t.clone(), *pid));
                }
                "ParticleSystem" => ps_pid = *pid,
                "ParticleSystemRenderer" => psr_pid = *pid,
                "Animation" => {
                    let av = b.value_of(*pid);
                    let mut clip = av.get("m_Animation").pptr_local();
                    if clip == 0 {
                        for c in av.get("m_Animations").list().iter() {
                            let p = c.pptr_local();
                            if p != 0 {
                                clip = p;
                                break;
                            }
                        }
                    }
                    if clip != 0 {
                        anim_sources.push((ni, clip));
                    }
                }
                "Animator" => {
                    let av = b.value_of(*pid);
                    let ctrl = av.get("m_Controller").pptr_local();
                    if ctrl != 0 {
                        let cv = b.value_of(ctrl);
                        let mut first = 0i64;
                        for c in cv.get("m_AnimationClips").list().iter() {
                            let p = c.pptr_local();
                            if p != 0 {
                                first = p;
                                break;
                            }
                        }
                        if first != 0 {
                            anim_sources.push((ni, first));
                        }
                    }
                }
                _ => {}
            }
        }

        if let Some((rtype, rpid)) = renderer {
            let rv = b.value_of(rpid);
            let skinned = rtype == "SkinnedMeshRenderer";
            let mesh_pid = if skinned { rv.get("m_Mesh").pptr_local() } else { filter_mesh };
            let mesh = b.mesh(mesh_pid);
            let mut mats: Vec<Option<usize>> = Vec::new();
            for m in rv.get("m_Materials").list().iter() {
                let mp = m.pptr_local();
                mats.push(b.material(mp));
            }
            let init_blend: Vec<f32> = rv.get("m_BlendShapeWeights").list().iter().map(|x| x.f32()).collect();
            node_mesh[ni] = Some(mesh_rends.len());
            mesh_rends.push(MeshRend {
                node: ni,
                mesh,
                materials: mats,
                enabled: rv.get("m_Enabled").bool(),
                skinned,
                init_blend,
            });
        }

        if ps_pid != 0 {
            let pv = b.value_of(ps_pid);
            let mut def = parse_ps_def(&pv, &nodes[ni].name);
            let mut material: Option<usize> = None;
            if psr_pid != 0 {
                let rv = b.value_of(psr_pid);
                apply_renderer(&mut def, &rv);
                if let Some(m) = rv.get("m_Materials").list().first() {
                    let mp = m.pptr_local();
                    material = b.material(mp);
                }
            }
            let mesh = if def.render_mode == 4 { b.mesh(def.mesh_path_id) } else { None };
            node_ps[ni] = Some(systems.len());
            systems.push(PsEntry { node: ni, def, material, mesh });
        }
    }

    // 5. animation clips
    let mut prop_names: HashMap<u32, String> = HashMap::new();
    for m in b.materials.iter() {
        for (k, _) in m.floats.iter() {
            prop_names.insert(crc32(k.as_bytes()) & 0x0FFF_FFFF, k.clone());
        }
        for (k, _) in m.colors.iter() {
            prop_names.insert(crc32(k.as_bytes()) & 0x0FFF_FFFF, k.clone());
        }
        for s in m.slots.iter() {
            let st = format!("{}_ST", s.name);
            prop_names.insert(crc32(st.as_bytes()) & 0x0FFF_FFFF, st);
        }
    }
    let mut mesh_blend_names: Vec<Vec<String>> = Vec::new();
    for mr in mesh_rends.iter() {
        let names: Vec<String> = match mr.mesh {
            Some(mi) => b.meshes[mi].blend.iter().map(|c| c.name.clone()).collect(),
            None => Vec::new(),
        };
        mesh_blend_names.push(names);
    }

    let mut clips: Vec<Clip> = Vec::new();
    let mut has_prop_anim = false;
    for (root, clip_pid) in anim_sources.iter() {
        let cv = b.value_of(*clip_pid);
        if cv.is_none() {
            log_w!("animation clip {} not found in bundle", clip_pid);
            continue;
        }
        let mut by_path: HashMap<String, usize> = HashMap::new();
        let mut by_hash: HashMap<u32, usize> = HashMap::new();
        for i in 0..n {
            if let Some(p) = rel_path(&nodes, *root, i) {
                let h = crc32(p.as_bytes());
                by_hash.entry(h).or_insert(i);
                by_path.entry(p).or_insert(i);
            }
        }
        let mut by_root_path: HashMap<String, usize> = HashMap::new();
        for i in 0..n {
            if let Some(p) = rel_path(&nodes, 0, i) {
                by_root_path.entry(p).or_insert(i);
            }
        }
        let ctx = BindCtx {
            by_path,
            root_name: nodes[0].name.clone(),
            by_root_path,
            by_hash,
            node_mesh: node_mesh.clone(),
            node_ps: node_ps.clone(),
            mesh_blend_names: mesh_blend_names.clone(),
            prop_names: prop_names.clone(),
        };
        let legacy = cv.get("m_Legacy").bool();
        let clip = if legacy {
            decode_legacy_clip(&cv, &ctx)
        } else {
            match decode_muscle_clip(&cv, &ctx) {
                Ok(c) => c,
                Err(e) => {
                    log_w!("clip '{}': {}", cv.get("m_Name").str(), e);
                    continue;
                }
            }
        };
        for ch in clip.channels.iter() {
            match ch.target {
                Target::MatVec(_, _) | Target::MatColor(_, _) | Target::MatFloat(_) => has_prop_anim = true,
                _ => {}
            }
        }
        clips.push(clip);
    }

    // 6. bounds and duration
    let world = base_world(&nodes);
    let mut bmin = [f32::MAX; 3];
    let mut bmax = [f32::MIN; 3];
    let mut any_bounds = false;
    for mr in mesh_rends.iter() {
        if let Some(mi) = mr.mesh {
            let mesh = &b.meshes[mi];
            if mesh.positions.is_empty() {
                continue;
            }
            for cx in 0..2 {
                for cy in 0..2 {
                    for cz in 0..2 {
                        let p = [
                            if cx == 0 { mesh.bmin[0] } else { mesh.bmax[0] },
                            if cy == 0 { mesh.bmin[1] } else { mesh.bmax[1] },
                            if cz == 0 { mesh.bmin[2] } else { mesh.bmax[2] },
                        ];
                        let w = mat_transform_point(&world[mr.node], p);
                        for k in 0..3 {
                            if w[k] < bmin[k] {
                                bmin[k] = w[k];
                            }
                            if w[k] > bmax[k] {
                                bmax[k] = w[k];
                            }
                        }
                        any_bounds = true;
                    }
                }
            }
        }
    }
    for e in systems.iter() {
        let c = mat_translation(&world[e.node]);
        let r = 0.5 + e.def.start_size.max_value().abs();
        for k in 0..3 {
            if c[k] - r < bmin[k] {
                bmin[k] = c[k] - r;
            }
            if c[k] + r > bmax[k] {
                bmax[k] = c[k] + r;
            }
        }
        any_bounds = true;
    }
    if !any_bounds {
        bmin = [-1.0, 0.0, -1.0];
        bmax = [1.0, 2.0, 1.0];
    }

    let mut duration = 0.0f32;
    for c in clips.iter() {
        if c.length > duration {
            duration = c.length;
        }
    }
    for e in systems.iter() {
        let d = ps_estimate_duration(&e.def);
        if d > duration {
            duration = d;
        }
    }
    if duration < 0.5 {
        duration = 0.5;
    }

    // 7. diagnostics
    let mut info: Vec<String> = Vec::new();
    let root_name = nodes[0].name.clone();
    info.push(format!(
        "prefab '{}'  container: {}",
        root_name,
        if container.is_empty() { "-".to_string() } else { container.clone() }
    ));
    info.push(format!(
        "unity {} | bundle format {} ({}) | serialized v{} | externals: {}",
        sf.unity_version,
        bundle.format_version,
        compression_name(bundle.compression),
        sf.version,
        if sf.externals.is_empty() { "none".to_string() } else { sf.externals.join(", ") }
    ));
    let mut cnt: Vec<String> = counts.iter().map(|(k, v)| format!("{} x{}", k, v)).collect();
    cnt.sort();
    info.push(format!("objects: {}", cnt.join(", ")));
    info.push(format!(
        "nodes={} meshes={} materials={} textures={} mesh_renderers={} particle_systems={} clips={} duration={:.2}s",
        nodes.len(),
        b.meshes.len(),
        b.materials.len(),
        b.textures.len(),
        mesh_rends.len(),
        systems.len(),
        clips.len(),
        duration
    ));
    for m in b.materials.iter() {
        let tex_names: Vec<String> = m
            .slots
            .iter()
            .map(|s| match s.tex {
                Some(t) => format!("{}={}", s.name, b.textures[t].name),
                None => format!("{}=none", s.name),
            })
            .collect();
        info.push(format!(
            "material '{}': shader {}/{} queue={} keywords='{}' [{}]",
            m.name,
            m.shader_file,
            m.shader_id,
            m.queue,
            m.keywords.trim(),
            tex_names.join(", ")
        ));
    }
    for t in b.textures.iter() {
        let st = match &t.payload {
            TexPayload::Raw(_) => "raw RGBA".to_string(),
            TexPayload::Compressed { gl_format, .. } => format!("compressed 0x{:X}", gl_format),
            TexPayload::Unsupported(why) => format!("UNSUPPORTED: {}", why),
        };
        info.push(format!(
            "texture '{}': {}x{} {} ({}) alpha={}",
            t.name,
            t.width,
            t.height,
            texture_format_name(t.format),
            st,
            t.has_alpha
        ));
    }
    for m in b.meshes.iter() {
        let tris: usize = m.submeshes.iter().map(|s| s.len() / 3).sum();
        info.push(format!(
            "mesh '{}': {} verts, {} tris, {} submeshes, {} blend shapes{}",
            m.name,
            m.positions.len(),
            tris,
            m.submeshes.len(),
            m.blend.len(),
            if m.compressed { " (compressed)" } else { "" }
        ));
    }
    for e in systems.iter() {
        let d = &e.def;
        info.push(format!(
            "particle system '{}': dur={:.2} loop={} max={} render_mode={} bursts={} rate={:.1}{}",
            d.name,
            d.duration,
            d.looping,
            d.max_particles,
            d.render_mode,
            d.bursts.len(),
            d.rate.max_value(),
            if d.unsupported.is_empty() {
                String::new()
            } else {
                format!(" | not simulated: {}", d.unsupported.join(", "))
            }
        ));
    }
    for c in clips.iter() {
        info.push(format!(
            "clip '{}': {:.2}s, {} channels bound, {} curves ignored",
            c.name,
            c.length,
            c.channels.len(),
            c.ignored
        ));
    }

    Ok(Effect {
        name: root_name,
        container,
        nodes,
        meshes: b.meshes,
        textures: b.textures,
        materials: b.materials,
        mesh_rends,
        systems,
        clips,
        duration,
        bmin,
        bmax,
        has_prop_anim,
        info: info.join("\n"),
    })
}

/// Parses a bundle file's bytes and builds the effect.
pub fn load_effect(data: &[u8]) -> Res<Effect> {
    let bundle = parse_bundle(data)?;
    log_i!(
        "bundle: unity {} / {}, format {}, {} file(s)",
        bundle.unity_version,
        bundle.engine_version,
        bundle.format_version,
        bundle.files.len()
    );
    effect_from_bundle(&bundle)
}

// =============================================================================================
// Runtime
// =============================================================================================

pub struct RendRt {
    pub base_props: Vec<PropSet>,
    pub props: Vec<PropSet>,
    pub blend0: Vec<f32>,
    pub blend: Vec<f32>,
}

pub struct Runtime {
    pub time: f32,
    pub pos: Vec<V3>,
    pub rot: Vec<Quat>,
    pub scale: Vec<V3>,
    pub active: Vec<bool>,
    pub world: Vec<M4>,
    pub world_active: Vec<bool>,
    pub mr: Vec<RendRt>,
    pub ps_base: Vec<PropSet>,
    pub ps_props: Vec<PropSet>,
    pub ps: Vec<PsState>,
}

impl Runtime {
    pub fn new(fx: &Effect) -> Runtime {
        let n = fx.nodes.len();
        let mut mr: Vec<RendRt> = Vec::new();
        for r in fx.mesh_rends.iter() {
            let mut base: Vec<PropSet> = Vec::new();
            for m in r.materials.iter() {
                base.push(match m {
                    Some(i) if *i < fx.materials.len() => PropSet::from_material(&fx.materials[*i]),
                    _ => PropSet::empty(),
                });
            }
            let nch = match r.mesh {
                Some(mi) => fx.meshes[mi].blend.len(),
                None => 0,
            };
            let mut blend0 = vec![0.0f32; nch];
            for (i, w) in r.init_blend.iter().enumerate() {
                if i < nch {
                    blend0[i] = *w;
                }
            }
            mr.push(RendRt { props: base.clone(), base_props: base, blend: blend0.clone(), blend0 });
        }
        let mut ps_base: Vec<PropSet> = Vec::new();
        let mut ps: Vec<PsState> = Vec::new();
        for (i, e) in fx.systems.iter().enumerate() {
            ps_base.push(match e.material {
                Some(mi) if mi < fx.materials.len() => PropSet::from_material(&fx.materials[mi]),
                _ => PropSet::empty(),
            });
            let seed = if e.def.seed != 0 {
                (e.def.seed as u64) ^ 0x9E37_79B9
            } else {
                1234567u64 + i as u64
            };
            ps.push(PsState::new(seed));
        }
        let mut rt = Runtime {
            time: 0.0,
            pos: fx.nodes.iter().map(|x| x.pos).collect(),
            rot: fx.nodes.iter().map(|x| x.rot).collect(),
            scale: fx.nodes.iter().map(|x| x.scale).collect(),
            active: fx.nodes.iter().map(|x| x.active).collect(),
            world: vec![mat_identity(); n],
            world_active: vec![true; n],
            mr,
            ps_props: ps_base.clone(),
            ps_base,
            ps,
        };
        rt.apply_animation(fx);
        rt.compute_world(fx);
        rt
    }

    pub fn update(&mut self, fx: &Effect, dt: f32) {
        self.time += dt;
        self.apply_animation(fx);
        self.compute_world(fx);
        for (i, e) in fx.systems.iter().enumerate() {
            let active = self.world_active[e.node];
            let m = self.world[e.node];
            ps_update(&e.def, &mut self.ps[i], dt, &m, active);
        }
    }

    fn prop_slot(&mut self, r: RendRef) -> Option<&mut PropSet> {
        match r {
            RendRef::Mesh(mi) => match self.mr.get_mut(mi) {
                Some(x) => x.props.get_mut(0),
                None => None,
            },
            RendRef::Ps(pi) => self.ps_props.get_mut(pi),
        }
    }

    fn apply_animation(&mut self, fx: &Effect) {
        let n = fx.nodes.len();
        for i in 0..n {
            self.pos[i] = fx.nodes[i].pos;
            self.rot[i] = fx.nodes[i].rot;
            self.scale[i] = fx.nodes[i].scale;
            self.active[i] = fx.nodes[i].active;
        }
        if fx.has_prop_anim {
            for r in self.mr.iter_mut() {
                r.props = r.base_props.clone();
            }
            self.ps_props = self.ps_base.clone();
        }
        for r in self.mr.iter_mut() {
            if !r.blend0.is_empty() {
                r.blend = r.blend0.clone();
            }
        }

        let mut rot_touched = vec![false; n];
        let mut euler = vec![[0.0f32; 3]; n];
        let mut euler_touched = vec![false; n];
        for clip in fx.clips.iter() {
            let t = if clip.length <= 1e-6 {
                0.0
            } else if clip.looping {
                self.time % clip.length
            } else if self.time > clip.length {
                clip.length
            } else {
                self.time
            };
            for ch in clip.channels.iter() {
                let v = ch.curve.eval(t);
                let ni = ch.node;
                if ni >= n {
                    continue;
                }
                match &ch.target {
                    Target::Pos(c) => self.pos[ni][*c] = v,
                    Target::Scale(c) => self.scale[ni][*c] = v,
                    Target::Rot(c) => {
                        self.rot[ni][*c] = v;
                        rot_touched[ni] = true;
                    }
                    Target::Euler(c) => {
                        euler[ni][*c] = v;
                        euler_touched[ni] = true;
                    }
                    Target::Active => self.active[ni] = v > 0.5,
                    Target::MatVec(name, c) => {
                        if let Some(r) = ch.rend {
                            if let Some(p) = self.prop_slot(r) {
                                p.set_vec(name, *c, v);
                            }
                        }
                    }
                    Target::MatColor(name, c) => {
                        if let Some(r) = ch.rend {
                            if let Some(p) = self.prop_slot(r) {
                                p.set_color(name, *c, v);
                            }
                        }
                    }
                    Target::MatFloat(name) => {
                        if let Some(r) = ch.rend {
                            if let Some(p) = self.prop_slot(r) {
                                p.set_float(name, v);
                            }
                        }
                    }
                    Target::Blend(ci) => {
                        if let Some(RendRef::Mesh(mi)) = ch.rend {
                            if let Some(rt) = self.mr.get_mut(mi) {
                                if *ci < rt.blend.len() {
                                    rt.blend[*ci] = v;
                                }
                            }
                        }
                    }
                }
            }
        }
        for i in 0..n {
            if rot_touched[i] {
                self.rot[i] = quat_normalize(self.rot[i]);
            } else if euler_touched[i] {
                self.rot[i] = quat_euler_deg(euler[i][0], euler[i][1], euler[i][2]);
            }
        }
    }

    fn compute_world(&mut self, fx: &Effect) {
        for i in 0..fx.nodes.len() {
            let local = mat_from_trs(self.pos[i], self.rot[i], self.scale[i]);
            let p = fx.nodes[i].parent;
            if p >= 0 && (p as usize) < i {
                let pi = p as usize;
                let w = mat_mul(&self.world[pi], &local);
                self.world[i] = w;
                self.world_active[i] = self.world_active[pi] && self.active[i];
            } else {
                self.world[i] = local;
                self.world_active[i] = self.active[i];
            }
        }
    }

    pub fn particle_count(&self) -> usize {
        let mut c = 0usize;
        for p in self.ps.iter() {
            c += p.particles.len();
        }
        c
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn tiny_effect() -> Effect {
        Effect {
            name: "t".to_string(),
            container: String::new(),
            nodes: vec![
                Node { name: "root".to_string(), parent: -1, pos: [0.0; 3], rot: [0.0, 0.0, 0.0, 1.0], scale: [1.0; 3], active: true },
                Node { name: "child".to_string(), parent: 0, pos: [1.0, 0.0, 0.0], rot: [0.0, 0.0, 0.0, 1.0], scale: [1.0; 3], active: true },
            ],
            meshes: vec![],
            textures: vec![],
            materials: vec![],
            mesh_rends: vec![],
            systems: vec![],
            clips: vec![Clip {
                name: "c".to_string(),
                length: 1.0,
                looping: false,
                channels: vec![Channel {
                    node: 0,
                    target: Target::Pos(1),
                    rend: None,
                    curve: CurveData::Hermite(vec![
                        HKey { t: 0.0, v: 0.0, in_s: 2.0, out_s: 2.0 },
                        HKey { t: 1.0, v: 2.0, in_s: 2.0, out_s: 2.0 },
                    ]),
                }],
                ignored: 0,
            }],
            duration: 1.0,
            bmin: [0.0; 3],
            bmax: [1.0; 3],
            has_prop_anim: false,
            info: String::new(),
        }
    }

    #[test]
    fn runtime_animates_and_propagates_to_children() {
        let fx = tiny_effect();
        let mut rt = Runtime::new(&fx);
        rt.update(&fx, 0.5);
        let w = mat_translation(&rt.world[1]);
        assert!((w[0] - 1.0).abs() < 1e-4);
        assert!((w[1] - 1.0).abs() < 1e-3);
    }

    #[test]
    fn rel_path_builds_slash_paths() {
        let fx = tiny_effect();
        assert_eq!(rel_path(&fx.nodes, 0, 1).unwrap(), "child");
        assert_eq!(rel_path(&fx.nodes, 0, 0).unwrap(), "");
        assert!(rel_path(&fx.nodes, 1, 0).is_none());
    }

    #[test]
    fn auto_blend_uses_blend_factors_then_alpha_channel() {
        let fx = tiny_effect();
        let m = MaterialData {
            name: "m".to_string(),
            shader_file: 1,
            shader_id: 1,
            keywords: String::new(),
            queue: 3000,
            slots: vec![],
            floats: vec![("_SrcBlend".to_string(), 5.0), ("_DstBlend".to_string(), 1.0)],
            colors: vec![],
        };
        assert_eq!(auto_blend(&fx, &m, None), Blend::Additive);
        let m2 = MaterialData { floats: vec![("_SrcBlend".to_string(), 5.0), ("_DstBlend".to_string(), 10.0)], ..m.clone() };
        assert_eq!(auto_blend(&fx, &m2, None), Blend::Alpha);
    }
}
