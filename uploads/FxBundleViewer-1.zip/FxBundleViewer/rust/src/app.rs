//! Application state that does not depend on OpenGL: loaded effects, playback control, camera and
//! view options. The renderer and the JNI layer drive this.

use crate::camera::Camera;
use crate::effect::*;
use crate::util::*;

pub struct LoadedEffect {
    pub id: i32,
    pub visible: bool,
    pub fx: Effect,
    pub rt: Runtime,
}

pub struct ViewOptions {
    /// 0 = auto, 1 = additive, 2 = alpha, 3 = opaque
    pub blend: i32,
    pub use_mask: bool,
    pub show_grid: bool,
    /// 0 = dark, 1 = grey, 2 = light
    pub bg: i32,
    pub vertex_color: bool,
}

#[derive(Clone, Default)]
pub struct Stats {
    pub fps: f32,
    pub draw_calls: u32,
    pub triangles: u32,
    pub particles: usize,
}

pub struct App {
    pub effects: Vec<LoadedEffect>,
    pub next_id: i32,
    pub playing: bool,
    pub looping: bool,
    pub speed: f32,
    pub time: f32,
    pub camera: Camera,
    pub opts: ViewOptions,
    /// Effect ids whose GL resources must be freed by the renderer.
    pub removed: Vec<i32>,
    pub stats: Stats,
}

const END_HOLD: f32 = 0.4;

impl App {
    pub fn new() -> App {
        App {
            effects: Vec::new(),
            next_id: 1,
            playing: true,
            looping: true,
            speed: 1.0,
            time: 0.0,
            camera: Camera::new(),
            opts: ViewOptions { blend: 0, use_mask: true, show_grid: true, bg: 0, vertex_color: true },
            removed: Vec::new(),
            stats: Stats::default(),
        }
    }

    pub fn add_effect(&mut self, fx: Effect) -> i32 {
        let id = self.next_id;
        self.next_id += 1;
        let rt = Runtime::new(&fx);
        self.effects.push(LoadedEffect { id, visible: true, fx, rt });
        self.restart();
        self.frame_camera();
        id
    }

    pub fn remove_effect(&mut self, id: i32) {
        if let Some(pos) = self.effects.iter().position(|e| e.id == id) {
            self.effects.remove(pos);
            self.removed.push(id);
        }
    }

    pub fn clear(&mut self) {
        for e in self.effects.iter() {
            self.removed.push(e.id);
        }
        self.effects.clear();
        self.time = 0.0;
    }

    pub fn set_visible(&mut self, id: i32, visible: bool) {
        for e in self.effects.iter_mut() {
            if e.id == id {
                e.visible = visible;
            }
        }
        self.restart();
    }

    pub fn restart(&mut self) {
        self.time = 0.0;
        for e in self.effects.iter_mut() {
            e.rt = Runtime::new(&e.fx);
        }
    }

    /// Longest duration among the visible effects.
    pub fn duration(&self) -> f32 {
        let mut d = 0.0f32;
        for e in self.effects.iter() {
            if e.visible && e.fx.duration > d {
                d = e.fx.duration;
            }
        }
        if d < 0.5 {
            0.5
        } else {
            d
        }
    }

    pub fn set_playing(&mut self, playing: bool) {
        if playing && self.time >= self.duration() + END_HOLD - 1e-3 {
            self.restart();
        }
        self.playing = playing;
    }

    pub fn step(&mut self, dt: f32) {
        if !self.playing {
            return;
        }
        let d = dt * self.speed;
        if d <= 0.0 {
            return;
        }
        self.time += d;
        for e in self.effects.iter_mut() {
            e.rt.update(&e.fx, d);
        }
        let end = self.duration() + END_HOLD;
        if self.time >= end {
            if self.looping {
                self.restart();
            } else {
                self.playing = false;
            }
        }
    }

    /// Jumps to time `t` by re-simulating from the start in fixed steps.
    pub fn seek(&mut self, t: f32) {
        let target = clampf(t, 0.0, self.duration());
        self.restart();
        let step = 1.0 / 60.0;
        let mut cur = 0.0f32;
        let mut guard = 0;
        while cur + step <= target && guard < 1500 {
            for e in self.effects.iter_mut() {
                e.rt.update(&e.fx, step);
            }
            cur += step;
            guard += 1;
        }
        let rem = target - cur;
        if rem > 1e-5 {
            for e in self.effects.iter_mut() {
                e.rt.update(&e.fx, rem);
            }
        }
        self.time = target;
    }

    pub fn frame_camera(&mut self) {
        let mut bmin = [f32::MAX; 3];
        let mut bmax = [f32::MIN; 3];
        let mut any = false;
        for e in self.effects.iter() {
            if !e.visible {
                continue;
            }
            for k in 0..3 {
                if e.fx.bmin[k] < bmin[k] {
                    bmin[k] = e.fx.bmin[k];
                }
                if e.fx.bmax[k] > bmax[k] {
                    bmax[k] = e.fx.bmax[k];
                }
            }
            any = true;
        }
        if any {
            self.camera.frame(bmin, bmax);
        } else {
            self.camera = Camera::new();
        }
    }

    pub fn effect_info(&self, id: i32) -> String {
        for e in self.effects.iter() {
            if e.id == id {
                return format!("{}\nduration {:.2}s\n{}", e.fx.name, e.fx.duration, e.fx.info);
            }
        }
        String::new()
    }

    pub fn status_line(&self) -> String {
        format!(
            "t {:.2}/{:.2}s  fps {:.0}  draws {}  tris {}  particles {}",
            self.time.min(self.duration()),
            self.duration(),
            self.stats.fps,
            self.stats.draw_calls,
            self.stats.triangles,
            self.stats.particles
        )
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn add_step_and_loop() {
        let mut app = App::new();
        let id = app.add_effect(Effect::empty("a"));
        assert_eq!(id, 1);
        assert!((app.duration() - 1.0).abs() < 1e-6);
        for _ in 0..200 {
            app.step(0.016);
        }
        // looping keeps the clock inside the effect length
        assert!(app.time <= app.duration() + END_HOLD + 0.05);
        app.looping = false;
        for _ in 0..200 {
            app.step(0.016);
        }
        assert!(!app.playing);
        app.set_playing(true);
        assert!(app.playing && app.time < 0.01);
    }

    #[test]
    fn seek_sets_time() {
        let mut app = App::new();
        app.add_effect(Effect::empty("a"));
        app.seek(0.5);
        assert!((app.time - 0.5).abs() < 1e-4);
    }

    #[test]
    fn remove_marks_gl_cleanup() {
        let mut app = App::new();
        let id = app.add_effect(Effect::empty("a"));
        app.remove_effect(id);
        assert!(app.effects.is_empty());
        assert_eq!(app.removed, vec![id]);
    }
}
