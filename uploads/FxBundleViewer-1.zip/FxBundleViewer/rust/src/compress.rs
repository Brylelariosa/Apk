//! Decompression for UnityFS blocks: LZ4 / LZ4HC block format and Unity's raw LZMA streams.
//! Both decoders are dependency free. The LZMA decoder follows the reference "LzmaSpec"
//! algorithm and was cross-checked against Python's `lzma` module on real bundles.

use crate::util::Res;

/// Decompresses a block according to the UnityFS compression type
/// (0 = none, 1 = LZMA, 2 = LZ4, 3 = LZ4HC).
pub fn decompress(data: &[u8], out_size: usize, ctype: u32) -> Res<Vec<u8>> {
    match ctype {
        0 => Ok(data.to_vec()),
        1 => lzma_unity(data, out_size),
        2 | 3 => lz4_block(data, out_size),
        other => Err(format!("unsupported compression type {}", other)),
    }
}

// ---------------------------------------------------------------------------------------------
// LZ4
// ---------------------------------------------------------------------------------------------

pub fn lz4_block(src: &[u8], out_size: usize) -> Res<Vec<u8>> {
    let mut dst: Vec<u8> = Vec::with_capacity(out_size);
    let n = src.len();
    let mut i = 0usize;
    while i < n {
        let token = src[i];
        i += 1;
        let mut lit = (token >> 4) as usize;
        if lit == 15 {
            loop {
                if i >= n {
                    return Err("lz4: truncated literal length".to_string());
                }
                let b = src[i] as usize;
                i += 1;
                lit += b;
                if b != 255 {
                    break;
                }
            }
        }
        if i + lit > n {
            return Err("lz4: literal run past end of input".to_string());
        }
        dst.extend_from_slice(&src[i..i + lit]);
        i += lit;
        if i >= n {
            break;
        }
        if i + 2 > n {
            return Err("lz4: truncated match offset".to_string());
        }
        let off = (src[i] as usize) | ((src[i + 1] as usize) << 8);
        i += 2;
        if off == 0 || off > dst.len() {
            return Err("lz4: bad match offset".to_string());
        }
        let mut ml = (token & 15) as usize;
        if ml == 15 {
            loop {
                if i >= n {
                    return Err("lz4: truncated match length".to_string());
                }
                let b = src[i] as usize;
                i += 1;
                ml += b;
                if b != 255 {
                    break;
                }
            }
        }
        ml += 4;
        let start = dst.len() - off;
        for k in 0..ml {
            let b = dst[start + k];
            dst.push(b);
        }
    }
    if dst.len() != out_size {
        return Err(format!("lz4: produced {} bytes, expected {}", dst.len(), out_size));
    }
    Ok(dst)
}

// ---------------------------------------------------------------------------------------------
// LZMA
// ---------------------------------------------------------------------------------------------

struct RangeDec<'a> {
    data: &'a [u8],
    pos: usize,
    range: u32,
    code: u32,
}

impl<'a> RangeDec<'a> {
    fn new(data: &'a [u8], pos: usize) -> Res<RangeDec<'a>> {
        if pos + 5 > data.len() {
            return Err("lzma: truncated stream".to_string());
        }
        if data[pos] != 0 {
            return Err("lzma: bad range coder header".to_string());
        }
        let mut code: u32 = 0;
        for i in 0..4 {
            code = (code << 8) | (data[pos + 1 + i] as u32);
        }
        Ok(RangeDec { data, pos: pos + 5, range: 0xFFFF_FFFF, code })
    }

    fn norm(&mut self) {
        if self.range < (1u32 << 24) {
            self.range <<= 8;
            let b = if self.pos < self.data.len() { self.data[self.pos] } else { 0 };
            self.pos += 1;
            self.code = (self.code << 8) | (b as u32);
        }
    }

    fn bit(&mut self, probs: &mut [u16], i: usize) -> u32 {
        let p = probs[i] as u32;
        let bound = (self.range >> 11).wrapping_mul(p);
        if self.code < bound {
            self.range = bound;
            probs[i] = (p + ((2048 - p) >> 5)) as u16;
            self.norm();
            0
        } else {
            self.range = self.range.wrapping_sub(bound);
            self.code = self.code.wrapping_sub(bound);
            probs[i] = (p - (p >> 5)) as u16;
            self.norm();
            1
        }
    }

    fn direct(&mut self, n: u32) -> u32 {
        let mut res: u32 = 0;
        for _ in 0..n {
            self.range >>= 1;
            self.code = self.code.wrapping_sub(self.range);
            let t = 0u32.wrapping_sub(self.code >> 31);
            self.code = self.code.wrapping_add(self.range & t);
            self.norm();
            res = (res << 1).wrapping_add(t).wrapping_add(1);
        }
        res
    }
}

fn bit_tree(rc: &mut RangeDec, probs: &mut [u16], base: usize, nbits: u32) -> u32 {
    let mut m: usize = 1;
    for _ in 0..nbits {
        let b = rc.bit(probs, base + m);
        m = (m << 1) + (b as usize);
    }
    (m - (1usize << nbits)) as u32
}

fn bit_tree_rev(rc: &mut RangeDec, probs: &mut [u16], base: usize, nbits: u32) -> u32 {
    let mut m: usize = 1;
    let mut sym: u32 = 0;
    for i in 0..nbits {
        let b = rc.bit(probs, base + m);
        m = (m << 1) + (b as usize);
        sym |= b << i;
    }
    sym
}

struct LenDec {
    choice: Vec<u16>,
    choice2: Vec<u16>,
    low: Vec<u16>,
    mid: Vec<u16>,
    high: Vec<u16>,
}

impl LenDec {
    fn new() -> LenDec {
        LenDec {
            choice: vec![1024u16; 1],
            choice2: vec![1024u16; 1],
            low: vec![1024u16; 16 << 3],
            mid: vec![1024u16; 16 << 3],
            high: vec![1024u16; 256],
        }
    }

    fn decode(&mut self, rc: &mut RangeDec, ps: usize) -> u32 {
        if rc.bit(&mut self.choice, 0) == 0 {
            return bit_tree(rc, &mut self.low, ps << 3, 3);
        }
        if rc.bit(&mut self.choice2, 0) == 0 {
            return 8 + bit_tree(rc, &mut self.mid, ps << 3, 3);
        }
        16 + bit_tree(rc, &mut self.high, 0, 8)
    }
}

/// Decodes a raw Unity LZMA block: 5 property bytes (lc/lp/pb + dictionary size) followed by
/// the range-coded stream. The uncompressed size comes from the bundle's block table.
pub fn lzma_unity(src: &[u8], out_size: usize) -> Res<Vec<u8>> {
    if src.len() < 6 {
        return Err("lzma: input too short".to_string());
    }
    let mut d = src[0] as u32;
    if d >= 9 * 5 * 5 {
        return Err("lzma: invalid properties byte".to_string());
    }
    let lc = d % 9;
    d /= 9;
    let lp = d % 5;
    let pb = d / 5;
    let mut rc = RangeDec::new(src, 5)?;

    let mut lit = vec![1024u16; 0x300usize << (lc + lp)];
    let mut pos_slot = vec![1024u16; 4 * 64];
    let mut pos_dec = vec![1024u16; 115];
    let mut align = vec![1024u16; 16];
    let mut is_match = vec![1024u16; 12 << 4];
    let mut is_rep = vec![1024u16; 12];
    let mut is_rep_g0 = vec![1024u16; 12];
    let mut is_rep_g1 = vec![1024u16; 12];
    let mut is_rep_g2 = vec![1024u16; 12];
    let mut is_rep0_long = vec![1024u16; 12 << 4];
    let mut len_dec = LenDec::new();
    let mut rep_len_dec = LenDec::new();

    let mut out: Vec<u8> = Vec::with_capacity(out_size);
    let mut state: usize = 0;
    let mut rep0: usize = 0;
    let mut rep1: usize = 0;
    let mut rep2: usize = 0;
    let mut rep3: usize = 0;

    while out.len() < out_size {
        let pos_state = out.len() & ((1usize << pb) - 1);
        if rc.bit(&mut is_match, (state << 4) + pos_state) == 0 {
            // literal
            let prev = if out.is_empty() { 0usize } else { out[out.len() - 1] as usize };
            let ls = ((out.len() & ((1usize << lp) - 1)) << lc) + (prev >> (8 - lc));
            let base = 0x300 * ls;
            let mut sym: usize = 1;
            if state >= 7 {
                if rep0 >= out.len() {
                    return Err("lzma: bad match byte distance".to_string());
                }
                let mut mb = out[out.len() - rep0 - 1] as usize;
                while sym < 0x100 {
                    let mbit = (mb >> 7) & 1;
                    mb = (mb << 1) & 0xFF;
                    let b = rc.bit(&mut lit, base + ((1 + mbit) << 8) + sym) as usize;
                    sym = (sym << 1) | b;
                    if mbit != b {
                        break;
                    }
                }
            }
            while sym < 0x100 {
                let b = rc.bit(&mut lit, base + sym) as usize;
                sym = (sym << 1) | b;
            }
            out.push((sym & 0xFF) as u8);
            state = if state < 4 {
                0
            } else if state < 10 {
                state - 3
            } else {
                state - 6
            };
            continue;
        }

        let len: usize;
        if rc.bit(&mut is_rep, state) != 0 {
            if out.is_empty() {
                return Err("lzma: repeat match at start of stream".to_string());
            }
            if rc.bit(&mut is_rep_g0, state) == 0 {
                if rc.bit(&mut is_rep0_long, (state << 4) + pos_state) == 0 {
                    // short rep: a single byte at distance rep0
                    state = if state < 7 { 9 } else { 11 };
                    if rep0 >= out.len() {
                        return Err("lzma: bad short-rep distance".to_string());
                    }
                    let b = out[out.len() - rep0 - 1];
                    out.push(b);
                    continue;
                }
            } else {
                let dist: usize;
                if rc.bit(&mut is_rep_g1, state) == 0 {
                    dist = rep1;
                } else {
                    if rc.bit(&mut is_rep_g2, state) == 0 {
                        dist = rep2;
                    } else {
                        dist = rep3;
                        rep3 = rep2;
                    }
                    rep2 = rep1;
                }
                rep1 = rep0;
                rep0 = dist;
            }
            len = rep_len_dec.decode(&mut rc, pos_state) as usize;
            state = if state < 7 { 8 } else { 11 };
        } else {
            rep3 = rep2;
            rep2 = rep1;
            rep1 = rep0;
            let l = len_dec.decode(&mut rc, pos_state) as usize;
            state = if state < 7 { 7 } else { 10 };
            let len_state = if l < 3 { l } else { 3 };
            let slot = bit_tree(&mut rc, &mut pos_slot, len_state * 64, 6) as usize;
            let dist: u64;
            if slot < 4 {
                dist = slot as u64;
            } else {
                let nd = ((slot >> 1) - 1) as u32;
                let mut dd: u64 = ((2 | (slot & 1)) as u64) << nd;
                if slot < 14 {
                    let base_idx = (dd as usize) - slot;
                    dd += bit_tree_rev(&mut rc, &mut pos_dec, base_idx, nd) as u64;
                } else {
                    dd += (rc.direct(nd - 4) as u64) << 4;
                    dd += bit_tree_rev(&mut rc, &mut align, 0, 4) as u64;
                }
                dist = dd;
            }
            if dist == 0xFFFF_FFFF {
                break; // end-of-stream marker
            }
            rep0 = dist as usize;
            if rep0 >= out.len() {
                return Err("lzma: match distance beyond decoded data".to_string());
            }
            len = l;
        }
        let total = len + 2;
        for _ in 0..total {
            if out.len() >= out_size {
                break;
            }
            let b = out[out.len() - rep0 - 1];
            out.push(b);
        }
    }
    if out.len() != out_size {
        return Err(format!("lzma: produced {} bytes, expected {}", out.len(), out_size));
    }
    Ok(out)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn lz4_literal_only_block() {
        let src = [0x50u8, b'h', b'e', b'l', b'l', b'o'];
        assert_eq!(lz4_block(&src, 5).unwrap(), b"hello".to_vec());
    }

    #[test]
    fn lz4_overlapping_match() {
        // literal 'a', then a match of length 8 at offset 1 => 9 x 'a'
        let src = [0x14u8, b'a', 0x01, 0x00];
        assert_eq!(lz4_block(&src, 9).unwrap(), vec![b'a'; 9]);
    }

    #[test]
    fn lz4_rejects_wrong_size() {
        let src = [0x50u8, b'h', b'e', b'l', b'l', b'o'];
        assert!(lz4_block(&src, 7).is_err());
    }
}
