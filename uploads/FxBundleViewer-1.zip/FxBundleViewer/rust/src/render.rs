//! OpenGL ES 3.0 renderer. All effect geometry is rebuilt on the CPU every frame (the meshes are
//! tiny), uploaded through one streaming vertex/index buffer pair and drawn with a single
//! unlit "FX" shader: diffuse * tint * vertex colour * intensity, optional mask on alpha.

use std::collections::HashMap;
use std::ffi::{CStr, CString};
use std::os::raw::{c_char, c_void};

use crate::app::{App, LoadedEffect, Stats};
use crate::assets::*;
use crate::effect::*;
use crate::gles::*;
use crate::particles::*;
use crate::util::*;

const VERT_SRC: &str = r#"#version 300 es
precision highp float;
layout(location = 0) in vec3 aPos;
layout(location = 1) in vec2 aUV;
layout(location = 2) in vec4 aCol;
uniform mat4 uMVP;
uniform vec4 uDiffST;
uniform vec4 uMaskST;
out vec2 vUV;
out vec2 vUV2;
out vec4 vCol;
void main() {
    gl_Position = uMVP * vec4(aPos, 1.0);
    vUV = aUV * uDiffST.xy + uDiffST.zw;
    vUV2 = aUV * uMaskST.xy + uMaskST.zw;
    vCol = aCol;
}
"#;

const FRAG_SRC: &str = r#"#version 300 es
precision highp float;
in vec2 vUV;
in vec2 vUV2;
in vec4 vCol;
uniform sampler2D uDiffuse;
uniform sampler2D uMask;
uniform vec4 uTint;
uniform float uIntensity;
uniform float uHasDiffuse;
uniform float uHasMask;
uniform float uOpaque;
out vec4 outColor;
void main() {
    vec4 d = vec4(1.0);
    if (uHasDiffuse > 0.5) {
        d = texture(uDiffuse, vUV);
    }
    vec4 c = d * uTint * vCol;
    c.rgb *= uIntensity;
    if (uHasMask > 0.5) {
        c.a *= texture(uMask, vUV2).r;
    }
    if (uOpaque > 0.5) {
        c.a = 1.0;
    }
    outColor = c;
}
"#;

const STRIDE_FLOATS: usize = 9; // pos3 + uv2 + color4

struct DrawItem {
    fx_index: Option<usize>,
    queue: i32,
    depth: f32,
    verts: Vec<f32>,
    idx: Vec<u32>,
    mvp: M4,
    params: DrawParams,
    mode: GLenum,
}

struct CamInfo {
    eye: V3,
    right: V3,
    up: V3,
    fwd: V3,
    vp: M4,
}

pub struct Renderer {
    prog: GLuint,
    vao: GLuint,
    vbo: GLuint,
    ibo: GLuint,
    u_mvp: GLint,
    u_diff_st: GLint,
    u_mask_st: GLint,
    u_tint: GLint,
    u_intensity: GLint,
    u_has_diffuse: GLint,
    u_has_mask: GLint,
    u_opaque: GLint,
    u_diffuse: GLint,
    u_mask: GLint,
    white: GLuint,
    placeholder: GLuint,
    tex: HashMap<(i32, usize), GLuint>,
    astc: bool,
    width: i32,
    height: i32,
    fps: f32,
}

// ---------------------------------------------------------------------------------------------
// GL helpers
// ---------------------------------------------------------------------------------------------

unsafe fn gl_string(name: GLenum) -> String {
    let p = glGetString(name);
    if p.is_null() {
        return String::new();
    }
    CStr::from_ptr(p as *const c_char).to_string_lossy().to_string()
}

unsafe fn compile(kind: GLenum, src: &str) -> Res<GLuint> {
    let sh = glCreateShader(kind);
    let c = match CString::new(src) {
        Ok(c) => c,
        Err(_) => return Err("shader source contains NUL".to_string()),
    };
    let ptr: *const c_char = c.as_ptr();
    glShaderSource(sh, 1, &ptr, std::ptr::null());
    glCompileShader(sh);
    let mut ok: GLint = 0;
    glGetShaderiv(sh, GL_COMPILE_STATUS, &mut ok);
    if ok == 0 {
        let mut len: GLint = 0;
        glGetShaderiv(sh, GL_INFO_LOG_LENGTH, &mut len);
        let cap = if len > 1 { len } else { 1 };
        let mut buf = vec![0u8; cap as usize];
        let mut written: GLsizei = 0;
        glGetShaderInfoLog(sh, cap, &mut written, buf.as_mut_ptr() as *mut c_char);
        let n = std::cmp::min(written.max(0) as usize, buf.len());
        let msg = String::from_utf8_lossy(&buf[..n]).to_string();
        glDeleteShader(sh);
        return Err(format!("shader compile failed: {}", msg));
    }
    Ok(sh)
}

unsafe fn link(vs: GLuint, fs: GLuint) -> Res<GLuint> {
    let p = glCreateProgram();
    glAttachShader(p, vs);
    glAttachShader(p, fs);
    glLinkProgram(p);
    let mut ok: GLint = 0;
    glGetProgramiv(p, GL_LINK_STATUS, &mut ok);
    if ok == 0 {
        let mut len: GLint = 0;
        glGetProgramiv(p, GL_INFO_LOG_LENGTH, &mut len);
        let cap = if len > 1 { len } else { 1 };
        let mut buf = vec![0u8; cap as usize];
        let mut written: GLsizei = 0;
        glGetProgramInfoLog(p, cap, &mut written, buf.as_mut_ptr() as *mut c_char);
        let n = std::cmp::min(written.max(0) as usize, buf.len());
        let msg = String::from_utf8_lossy(&buf[..n]).to_string();
        return Err(format!("program link failed: {}", msg));
    }
    Ok(p)
}

unsafe fn uniform(prog: GLuint, name: &str) -> GLint {
    match CString::new(name) {
        Ok(c) => glGetUniformLocation(prog, c.as_ptr()),
        Err(_) => -1,
    }
}

fn wrap_gl(w: i32) -> GLint {
    match w {
        1 | 3 => GL_CLAMP_TO_EDGE as GLint,
        2 => GL_MIRRORED_REPEAT as GLint,
        _ => GL_REPEAT as GLint,
    }
}

unsafe fn tex_params(ws: GLint, wt: GLint) {
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR as GLint);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR as GLint);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, ws);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, wt);
}

unsafe fn new_texture_rgba(w: i32, h: i32, rgba: &[u8], ws: GLint, wt: GLint) -> GLuint {
    let mut id: GLuint = 0;
    glGenTextures(1, &mut id);
    glBindTexture(GL_TEXTURE_2D, id);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    glTexImage2D(
        GL_TEXTURE_2D,
        0,
        GL_RGBA as GLint,
        w,
        h,
        0,
        GL_RGBA,
        GL_UNSIGNED_BYTE,
        rgba.as_ptr() as *const c_void,
    );
    tex_params(ws, wt);
    id
}

fn push_vertex(v: &mut Vec<f32>, p: V3, uv: [f32; 2], c: [f32; 4]) {
    v.push(p[0]);
    v.push(p[1]);
    v.push(p[2]);
    v.push(uv[0]);
    v.push(uv[1]);
    v.push(c[0]);
    v.push(c[1]);
    v.push(c[2]);
    v.push(c[3]);
}

fn plain_params(blend: Blend, queue: i32) -> DrawParams {
    DrawParams {
        diffuse: None,
        mask: None,
        diff_st: [1.0, 1.0, 0.0, 0.0],
        mask_st: [1.0, 1.0, 0.0, 0.0],
        tint: [1.0, 1.0, 1.0, 1.0],
        intensity: 1.0,
        blend,
        queue,
    }
}

// ---------------------------------------------------------------------------------------------
// Renderer
// ---------------------------------------------------------------------------------------------

impl Renderer {
    /// Creates all GL objects. Must be called on the GL thread with a current context.
    pub fn new() -> Res<Renderer> {
        unsafe {
            let version = gl_string(GL_VERSION);
            let renderer = gl_string(GL_RENDERER);
            let vendor = gl_string(GL_VENDOR);
            let exts = gl_string(GL_EXTENSIONS);
            let astc = exts.contains("GL_KHR_texture_compression_astc_ldr");
            log_i!("GL: {} | {} | {}", vendor, renderer, version);
            log_i!(
                "GL texture support: ASTC LDR={} PVRTC={} S3TC={} (ETC2/EAC are core in ES3)",
                astc,
                exts.contains("GL_IMG_texture_compression_pvrtc"),
                exts.contains("GL_EXT_texture_compression_s3tc")
            );

            let vs = compile(GL_VERTEX_SHADER, VERT_SRC)?;
            let fs = compile(GL_FRAGMENT_SHADER, FRAG_SRC)?;
            let prog = link(vs, fs)?;
            glDeleteShader(vs);
            glDeleteShader(fs);

            let mut vao: GLuint = 0;
            glGenVertexArrays(1, &mut vao);
            glBindVertexArray(vao);
            let mut bufs = [0u32; 2];
            glGenBuffers(2, bufs.as_mut_ptr());

            let white = new_texture_rgba(1, 1, &[255, 255, 255, 255], GL_CLAMP_TO_EDGE as GLint, GL_CLAMP_TO_EDGE as GLint);
            let checker: [u8; 16] = [
                255, 0, 255, 255, 40, 40, 40, 255, //
                40, 40, 40, 255, 255, 0, 255, 255,
            ];
            let placeholder = new_texture_rgba(2, 2, &checker, GL_REPEAT as GLint, GL_REPEAT as GLint);

            let r = Renderer {
                prog,
                vao,
                vbo: bufs[0],
                ibo: bufs[1],
                u_mvp: uniform(prog, "uMVP"),
                u_diff_st: uniform(prog, "uDiffST"),
                u_mask_st: uniform(prog, "uMaskST"),
                u_tint: uniform(prog, "uTint"),
                u_intensity: uniform(prog, "uIntensity"),
                u_has_diffuse: uniform(prog, "uHasDiffuse"),
                u_has_mask: uniform(prog, "uHasMask"),
                u_opaque: uniform(prog, "uOpaque"),
                u_diffuse: uniform(prog, "uDiffuse"),
                u_mask: uniform(prog, "uMask"),
                white,
                placeholder,
                tex: HashMap::new(),
                astc,
                width: 1,
                height: 1,
                fps: 60.0,
            };
            let e = glGetError();
            if e != GL_NO_ERROR {
                log_w!("GL error 0x{:X} during renderer setup", e);
            }
            log_i!("renderer ready");
            Ok(r)
        }
    }

    pub fn resize(&mut self, w: i32, h: i32) {
        self.width = if w > 0 { w } else { 1 };
        self.height = if h > 0 { h } else { 1 };
    }

    /// Frees the textures of a removed effect.
    pub fn purge_effect(&mut self, id: i32) {
        let keys: Vec<(i32, usize)> = self.tex.keys().filter(|k| k.0 == id).cloned().collect();
        for k in keys.iter() {
            if let Some(t) = self.tex.remove(k) {
                if t != self.placeholder {
                    unsafe {
                        glDeleteTextures(1, &t);
                    }
                }
            }
        }
    }

    fn texture_for(&mut self, eid: i32, ti: usize, tex: &TexData) -> GLuint {
        if let Some(t) = self.tex.get(&(eid, ti)) {
            return *t;
        }
        let id = unsafe { self.upload(tex) };
        self.tex.insert((eid, ti), id);
        id
    }

    unsafe fn upload(&mut self, tex: &TexData) -> GLuint {
        let ws = wrap_gl(tex.wrap_u);
        let wt = wrap_gl(tex.wrap_v);
        match &tex.payload {
            TexPayload::Raw(rgba) => {
                let id = new_texture_rgba(tex.width, tex.height, rgba, ws, wt);
                log_i!("texture '{}' uploaded ({}x{} RGBA)", tex.name, tex.width, tex.height);
                id
            }
            TexPayload::Compressed { gl_format, data } => {
                let is_astc = *gl_format >= 0x93B0 && *gl_format <= 0x93BD;
                if is_astc && !self.astc {
                    log_w!("texture '{}': ASTC is not supported by this GPU, using placeholder", tex.name);
                    return self.placeholder;
                }
                let mut id: GLuint = 0;
                glGenTextures(1, &mut id);
                glBindTexture(GL_TEXTURE_2D, id);
                glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
                for _ in 0..8 {
                    if glGetError() == GL_NO_ERROR {
                        break;
                    }
                }
                glCompressedTexImage2D(
                    GL_TEXTURE_2D,
                    0,
                    *gl_format,
                    tex.width,
                    tex.height,
                    0,
                    data.len() as GLsizei,
                    data.as_ptr() as *const c_void,
                );
                let e = glGetError();
                if e != GL_NO_ERROR {
                    log_w!(
                        "texture '{}': glCompressedTexImage2D(0x{:X}, {}x{}) failed with GL error 0x{:X}",
                        tex.name,
                        *gl_format,
                        tex.width,
                        tex.height,
                        e
                    );
                    glDeleteTextures(1, &id);
                    return self.placeholder;
                }
                tex_params(ws, wt);
                log_i!(
                    "texture '{}' uploaded ({}x{} {} compressed, 0x{:X})",
                    tex.name,
                    tex.width,
                    tex.height,
                    texture_format_name(tex.format),
                    *gl_format
                );
                id
            }
            TexPayload::Unsupported(why) => {
                log_w!("texture '{}': {} - using placeholder", tex.name, why);
                self.placeholder
            }
        }
    }

    /// Draws one frame and returns the statistics. `app` is only mutated for removed-effect cleanup.
    pub fn draw(&mut self, app: &mut App, dt: f32) {
        let removed = std::mem::take(&mut app.removed);
        for id in removed.iter() {
            self.purge_effect(*id);
        }
        if dt > 1e-5 {
            self.fps = self.fps * 0.9 + (1.0 / dt) * 0.1;
        }
        let mut stats = {
            let a: &App = &*app;
            self.draw_inner(a)
        };
        stats.fps = self.fps;
        app.stats = stats;
    }

    fn draw_inner(&mut self, app: &App) -> Stats {
        let mut stats = Stats::default();
        unsafe {
            let bg = match app.opts.bg {
                0 => [0.06f32, 0.07, 0.09],
                1 => [0.32f32, 0.33, 0.36],
                _ => [0.82f32, 0.84, 0.88],
            };
            glViewport(0, 0, self.width, self.height);
            glClearColor(bg[0], bg[1], bg[2], 1.0);
            glDepthMask(GL_TRUE);
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
            glEnable(GL_DEPTH_TEST);
            glDepthFunc(GL_LEQUAL);
            glDisable(GL_CULL_FACE);
        }

        let aspect = self.width as f32 / (if self.height > 0 { self.height as f32 } else { 1.0 });
        let view = app.camera.view();
        let proj = app.camera.proj(aspect);
        let (right, up, fwd) = app.camera.axes();
        let cam = CamInfo {
            eye: app.camera.eye(),
            right,
            up,
            fwd,
            vp: mat_mul(&proj, &view),
        };

        let mut items: Vec<DrawItem> = Vec::new();
        if app.opts.show_grid {
            items.push(grid_item(&cam));
        }
        for (i, le) in app.effects.iter().enumerate() {
            if le.visible {
                collect_effect(app, i, le, &cam, &mut items, &mut stats);
            }
        }
        items.sort_by(|a, b| {
            a.params
                .queue
                .cmp(&b.params.queue)
                .then_with(|| b.depth.partial_cmp(&a.depth).unwrap_or(std::cmp::Ordering::Equal))
        });

        let mut calls = 0u32;
        let mut tris = 0u32;
        for it in items.iter() {
            if it.idx.is_empty() {
                continue;
            }
            self.draw_item(app, it);
            calls += 1;
            tris += (it.idx.len() / 3) as u32;
        }
        stats.draw_calls = calls;
        stats.triangles = tris;
        unsafe {
            glDepthMask(GL_TRUE);
        }
        stats
    }

    fn draw_item(&mut self, app: &App, it: &DrawItem) {
        // resolve textures first (needs &mut self)
        let mut diff_id = self.white;
        let mut mask_id = self.white;
        if let Some(fi) = it.fx_index {
            let le = &app.effects[fi];
            if let Some(ti) = it.params.diffuse {
                if ti < le.fx.textures.len() {
                    diff_id = self.texture_for(le.id, ti, &le.fx.textures[ti]);
                }
            }
            if let Some(ti) = it.params.mask {
                if ti < le.fx.textures.len() {
                    mask_id = self.texture_for(le.id, ti, &le.fx.textures[ti]);
                }
            }
        }
        let p = &it.params;
        unsafe {
            glUseProgram(self.prog);
            match p.blend {
                Blend::Additive => {
                    glEnable(GL_BLEND);
                    glBlendFunc(GL_SRC_ALPHA, GL_ONE);
                    glDepthMask(GL_FALSE);
                }
                Blend::Alpha => {
                    glEnable(GL_BLEND);
                    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
                    glDepthMask(GL_FALSE);
                }
                Blend::Opaque => {
                    glDisable(GL_BLEND);
                    glDepthMask(GL_TRUE);
                }
            }
            glActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D, diff_id);
            glActiveTexture(GL_TEXTURE0 + 1);
            glBindTexture(GL_TEXTURE_2D, mask_id);
            glUniform1i(self.u_diffuse, 0);
            glUniform1i(self.u_mask, 1);
            glUniform1f(self.u_has_diffuse, if p.diffuse.is_some() { 1.0 } else { 0.0 });
            glUniform1f(self.u_has_mask, if p.mask.is_some() { 1.0 } else { 0.0 });
            glUniform1f(self.u_opaque, if p.blend == Blend::Opaque { 1.0 } else { 0.0 });
            glUniform4f(self.u_diff_st, p.diff_st[0], p.diff_st[1], p.diff_st[2], p.diff_st[3]);
            glUniform4f(self.u_mask_st, p.mask_st[0], p.mask_st[1], p.mask_st[2], p.mask_st[3]);
            glUniform4f(self.u_tint, p.tint[0], p.tint[1], p.tint[2], p.tint[3]);
            glUniform1f(self.u_intensity, p.intensity);
            glUniformMatrix4fv(self.u_mvp, 1, GL_FALSE, it.mvp.as_ptr());

            glBindVertexArray(self.vao);
            glBindBuffer(GL_ARRAY_BUFFER, self.vbo);
            glBufferData(
                GL_ARRAY_BUFFER,
                (it.verts.len() * 4) as GLsizeiptr,
                it.verts.as_ptr() as *const c_void,
                GL_STREAM_DRAW,
            );
            glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, self.ibo);
            glBufferData(
                GL_ELEMENT_ARRAY_BUFFER,
                (it.idx.len() * 4) as GLsizeiptr,
                it.idx.as_ptr() as *const c_void,
                GL_STREAM_DRAW,
            );
            let stride = (STRIDE_FLOATS * 4) as GLsizei;
            glEnableVertexAttribArray(0);
            glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, 0usize as *const c_void);
            glEnableVertexAttribArray(1);
            glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, stride, 12usize as *const c_void);
            glEnableVertexAttribArray(2);
            glVertexAttribPointer(2, 4, GL_FLOAT, GL_FALSE, stride, 20usize as *const c_void);
            glDrawElements(it.mode, it.idx.len() as GLsizei, GL_UNSIGNED_INT, std::ptr::null());
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Draw list construction (pure CPU, no GL calls)
// ---------------------------------------------------------------------------------------------

fn grid_item(cam: &CamInfo) -> DrawItem {
    let mut verts: Vec<f32> = Vec::new();
    let mut idx: Vec<u32> = Vec::new();
    let mut add_line = |a: V3, b: V3, c: [f32; 4]| {
        let base = (verts.len() / STRIDE_FLOATS) as u32;
        push_vertex(&mut verts, a, [0.0, 0.0], c);
        push_vertex(&mut verts, b, [0.0, 0.0], c);
        idx.push(base);
        idx.push(base + 1);
    };
    let n = 10i32;
    for i in -n..=n {
        let f = i as f32;
        let a = if i % 5 == 0 { 0.30 } else { 0.14 };
        let c = [0.65, 0.68, 0.75, a];
        add_line([f, 0.0, -(n as f32)], [f, 0.0, n as f32], c);
        add_line([-(n as f32), 0.0, f], [n as f32, 0.0, f], c);
    }
    add_line([0.0, 0.0, 0.0], [2.0, 0.0, 0.0], [1.0, 0.25, 0.25, 0.9]);
    add_line([0.0, 0.0, 0.0], [0.0, 2.0, 0.0], [0.3, 1.0, 0.3, 0.9]);
    add_line([0.0, 0.0, 0.0], [0.0, 0.0, 2.0], [0.35, 0.5, 1.0, 0.9]);
    DrawItem {
        fx_index: None,
        queue: i32::MIN,
        depth: 1.0e9,
        verts,
        idx,
        mvp: cam.vp,
        params: plain_params(Blend::Alpha, i32::MIN),
        mode: GL_LINES,
    }
}

fn collect_effect(app: &App, fi: usize, le: &LoadedEffect, cam: &CamInfo, items: &mut Vec<DrawItem>, stats: &mut Stats) {
    let fx = &le.fx;
    let rt = &le.rt;

    // ---- mesh renderers --------------------------------------------------------------------
    for (ri, mr) in fx.mesh_rends.iter().enumerate() {
        if !mr.enabled || !rt.world_active[mr.node] {
            continue;
        }
        let mi = match mr.mesh {
            Some(m) => m,
            None => continue,
        };
        let mesh = &fx.meshes[mi];
        if mesh.positions.is_empty() {
            continue;
        }
        let blended = if mr.skinned { apply_blend(mesh, &rt.mr[ri].blend) } else { None };
        let pos: &[[f32; 3]] = match &blended {
            Some(v) => &v[..],
            None => &mesh.positions[..],
        };
        let model = rt.world[mr.node];
        let mvp = mat_mul(&cam.vp, &model);
        let depth = v3_dot(v3_sub(mat_translation(&model), cam.eye), cam.fwd);

        let nv = pos.len();
        let mut base: Vec<f32> = Vec::with_capacity(nv * STRIDE_FLOATS);
        for i in 0..nv {
            let uv = if i < mesh.uvs.len() { mesh.uvs[i] } else { [0.0, 0.0] };
            let col = if app.opts.vertex_color && i < mesh.colors.len() { mesh.colors[i] } else { [1.0, 1.0, 1.0, 1.0] };
            push_vertex(&mut base, pos[i], uv, col);
        }
        for (si, tris) in mesh.submeshes.iter().enumerate() {
            if tris.is_empty() {
                continue;
            }
            let slot = if mr.materials.is_empty() { 0 } else { std::cmp::min(si, mr.materials.len() - 1) };
            let mat = if mr.materials.is_empty() { None } else { mr.materials[slot] };
            let props = rt.mr[ri].props.get(slot);
            let mut params = resolve_params(fx, mat, props, app.opts.blend);
            if !app.opts.use_mask {
                params.mask = None;
            }
            let queue = params.queue;
            items.push(DrawItem {
                fx_index: Some(fi),
                queue,
                depth,
                verts: base.clone(),
                idx: tris.clone(),
                mvp,
                params,
                mode: GL_TRIANGLES,
            });
        }
    }

    // ---- particle systems ------------------------------------------------------------------
    for (pi, e) in fx.systems.iter().enumerate() {
        let d = &e.def;
        if !d.renderer_enabled || d.render_mode == 5 {
            continue;
        }
        let st = &rt.ps[pi];
        if st.particles.is_empty() {
            continue;
        }
        let em = rt.world[e.node];
        let list = ps_render_list(d, st, &em);
        if list.is_empty() {
            continue;
        }
        stats.particles += list.len();
        let props = rt.ps_props.get(pi);
        let mut params = resolve_params(fx, e.material, props, app.opts.blend);
        if !app.opts.use_mask {
            params.mask = None;
        }
        let queue = params.queue;
        let depth = v3_dot(v3_sub(mat_translation(&em), cam.eye), cam.fwd);
        let mut verts: Vec<f32> = Vec::new();
        let mut idx: Vec<u32> = Vec::new();

        let mesh_opt = if d.render_mode == 4 {
            match e.mesh {
                Some(mi) => Some(&fx.meshes[mi]),
                None => None,
            }
        } else {
            None
        };

        if let Some(mesh) = mesh_opt {
            for p in list.iter() {
                let base_index = (verts.len() / STRIDE_FLOATS) as u32;
                for i in 0..mesh.positions.len() {
                    let w = mat_transform_point(&p.model, mesh.positions[i]);
                    let muv = if i < mesh.uvs.len() { mesh.uvs[i] } else { [0.0, 0.0] };
                    let uv = [p.uv[0] + muv[0] * p.uv[2], p.uv[1] + muv[1] * p.uv[3]];
                    let vc = if app.opts.vertex_color && i < mesh.colors.len() { mesh.colors[i] } else { [1.0, 1.0, 1.0, 1.0] };
                    let col = [vc[0] * p.color[0], vc[1] * p.color[1], vc[2] * p.color[2], vc[3] * p.color[3]];
                    push_vertex(&mut verts, w, uv, col);
                }
                for sub in mesh.submeshes.iter() {
                    for t in sub.iter() {
                        idx.push(base_index + *t);
                    }
                }
            }
        } else {
            for p in list.iter() {
                let speed = v3_len(p.vel);
                let side_len_x: f32;
                let side_len_y: f32;
                let ax: V3;
                let ay: V3;
                match d.render_mode {
                    1 if speed > 1e-3 => {
                        let dir = v3_norm(p.vel);
                        let mut wdir = v3_cross(dir, cam.fwd);
                        if v3_len(wdir) < 1e-5 {
                            wdir = cam.right;
                        }
                        ax = dir;
                        ay = v3_norm(wdir);
                        side_len_x = (p.size[1] * d.length_scale + speed * d.velocity_scale) * 0.5;
                        side_len_y = p.size[0] * 0.5;
                    }
                    2 => {
                        let a = p.rot[2];
                        ax = [a.cos(), 0.0, a.sin()];
                        ay = [-a.sin(), 0.0, a.cos()];
                        side_len_x = p.size[0] * 0.5;
                        side_len_y = p.size[1] * 0.5;
                    }
                    3 => {
                        let up = [0.0f32, 1.0, 0.0];
                        let mut r = v3_cross(up, cam.fwd);
                        if v3_len(r) < 1e-5 {
                            r = cam.right;
                        }
                        ax = v3_norm(r);
                        ay = up;
                        side_len_x = p.size[0] * 0.5;
                        side_len_y = p.size[1] * 0.5;
                    }
                    _ => {
                        let a = p.rot[2];
                        let (s, c) = (a.sin(), a.cos());
                        ax = v3_add(v3_scale(cam.right, c), v3_scale(cam.up, s));
                        ay = v3_add(v3_scale(cam.right, -s), v3_scale(cam.up, c));
                        side_len_x = p.size[0] * 0.5;
                        side_len_y = p.size[1] * 0.5;
                    }
                }
                let base_index = (verts.len() / STRIDE_FLOATS) as u32;
                let corners: [(f32, f32, f32, f32); 4] = [(-1.0, -1.0, 0.0, 0.0), (1.0, -1.0, 1.0, 0.0), (1.0, 1.0, 1.0, 1.0), (-1.0, 1.0, 0.0, 1.0)];
                for (cx, cy, u, v) in corners.iter() {
                    let wp = v3_add(
                        p.pos,
                        v3_add(v3_scale(ax, *cx * side_len_x), v3_scale(ay, *cy * side_len_y)),
                    );
                    let uv = [p.uv[0] + *u * p.uv[2], p.uv[1] + *v * p.uv[3]];
                    push_vertex(&mut verts, wp, uv, p.color);
                }
                idx.push(base_index);
                idx.push(base_index + 1);
                idx.push(base_index + 2);
                idx.push(base_index);
                idx.push(base_index + 2);
                idx.push(base_index + 3);
            }
        }
        if idx.is_empty() {
            continue;
        }
        items.push(DrawItem {
            fx_index: Some(fi),
            queue,
            depth,
            verts,
            idx,
            mvp: cam.vp,
            params,
            mode: GL_TRIANGLES,
        });
    }
}
