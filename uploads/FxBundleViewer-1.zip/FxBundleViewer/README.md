# FX Bundle Viewer

Android viewer for Unity effect bundles (`*.unity3d`, UnityFS, Unity 2017.4 - 2022): meshes, materials,
textures (ASTC / ETC1 / ETC2 / raw / DXT), legacy and Animator clips, blend shapes and particle systems.
Parsing, animation, particle simulation and the OpenGL ES 3 renderer are written in **Rust**
(`rust/`, built with cargo-ndk); the UI, file access and diagnostics are **Kotlin** (`app/`).

## Build
Upload the ZIP to `uploads/` of the GitHub repository. The workflow detects `rust/Cargo.toml`, builds
`libfxview.so` for the ABIs in `gradle.properties` (`rustAbis=`) and then packages the APK.

## Use
* **Files** - pick one or more `.unity3d` files (e.g. `fanny_attack01` + `fanny_attack01_skin06_add`
  to see a skin's base and additional effect together).
* **Folder** - pick a folder; every bundle below it is listed under **Library**.
  (Android 11 hides `Android/data`; copy the bundles to Downloads first.)
* Drag = orbit, pinch = zoom, two-finger drag = pan, **Frame** = reset camera.
* Playback: play/pause, restart, loop, speed, time slider.
* The effect shaders live in a separate bundle that is normally not available, so blending is guessed
  (**Blend: auto/add/alpha/opaque**); **Mask** and **Vertex color** toggles help when a look is off.
* **Log** shows what was parsed (objects, materials, textures, clips, ignored curves) plus native
  warnings and the last crash; **Copy** / **Save** (Downloads) it to share.

## Layout
```
rust/src/  bundle.rs compress.rs   UnityFS container, LZ4 + LZMA
           serialized.rs value.rs  SerializedFile + type-tree reader
           assets.rs               Mesh (compressed/raw, blend shapes), Texture2D, Material
           anim.rs                 curves, legacy + Mecanim (streamed/dense) clips, binding
           particles.rs            ParticleSystem definition + CPU simulation
           effect.rs app.rs        prefab assembly, runtime state, playback
           camera.rs render.rs gles.rs jni_api.rs   (Android only) renderer + JNI
app/       Kotlin UI (MainActivity), NativeBridge, scanner, logging, crash log
```
