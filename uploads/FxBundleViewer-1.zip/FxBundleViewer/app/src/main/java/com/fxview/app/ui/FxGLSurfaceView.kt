package com.fxview.app.ui

import android.content.Context
import android.opengl.GLSurfaceView
import android.view.MotionEvent
import com.fxview.app.nativebridge.NativeBridge
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.hypot

/**
 * GLSurfaceView whose rendering is entirely done by the Rust core. One finger orbits the camera,
 * two fingers pinch-zoom and pan.
 */
class FxGLSurfaceView(context: Context) : GLSurfaceView(context) {
    private var mode = 0 // 0 = none, 1 = orbit, 2 = pinch
    private var lastX = 0f
    private var lastY = 0f
    private var lastSpan = 0f
    private var lastMidX = 0f
    private var lastMidY = 0f

    init {
        setEGLContextClientVersion(3)
        setEGLConfigChooser(8, 8, 8, 8, 16, 0)
        preserveEGLContextOnPause = true
        setRenderer(object : GLSurfaceView.Renderer {
            override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
                NativeBridge.nativeSurfaceCreated()
            }

            override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
                NativeBridge.nativeSurfaceChanged(width, height)
            }

            override fun onDrawFrame(gl: GL10?) {
                NativeBridge.nativeDrawFrame()
            }
        })
        renderMode = RENDERMODE_CONTINUOUSLY
    }

    private fun span(e: MotionEvent): Float = hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1))
    private fun midX(e: MotionEvent): Float = (e.getX(0) + e.getX(1)) * 0.5f
    private fun midY(e: MotionEvent): Float = (e.getY(0) + e.getY(1)) * 0.5f

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                mode = 1
                lastX = e.x
                lastY = e.y
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                if (e.pointerCount >= 2) {
                    mode = 2
                    lastSpan = span(e)
                    lastMidX = midX(e)
                    lastMidY = midY(e)
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (mode == 1 && e.pointerCount == 1) {
                    val dx = e.x - lastX
                    val dy = e.y - lastY
                    lastX = e.x
                    lastY = e.y
                    NativeBridge.nativeOrbit(dx, dy)
                } else if (mode == 2 && e.pointerCount >= 2) {
                    val s = span(e)
                    if (lastSpan > 10f) {
                        NativeBridge.nativeZoom(s / lastSpan)
                    }
                    lastSpan = s
                    val mx = midX(e)
                    val my = midY(e)
                    NativeBridge.nativePan(mx - lastMidX, my - lastMidY)
                    lastMidX = mx
                    lastMidY = my
                }
            }
            MotionEvent.ACTION_POINTER_UP -> {
                if (e.pointerCount - 1 < 2) {
                    mode = 1
                    val idx = if (e.actionIndex == 0) 1 else 0
                    lastX = e.getX(idx)
                    lastY = e.getY(idx)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                mode = 0
            }
        }
        return true
    }
}
