package com.fxview.app.nativebridge

/**
 * Thin JNI facade over the Rust core (libfxview.so). Every call is cheap and thread-safe on the
 * native side; heavy work (bundle parsing) happens inside [nativeLoadBundleFd] and must therefore
 * be called from a background thread.
 */
object NativeBridge {
    /** Non-null when libfxview.so could not be loaded (wrong ABI, missing file, ...). */
    @Volatile
    var loadError: String? = null
        private set

    init {
        try {
            System.loadLibrary("fxview")
        } catch (t: Throwable) {
            loadError = t.toString()
        }
    }

    val isAvailable: Boolean get() = loadError == null

    // lifecycle / GL thread
    external fun nativeInit()
    external fun nativeSurfaceCreated()
    external fun nativeSurfaceChanged(width: Int, height: Int)
    external fun nativeDrawFrame()

    // scene
    /** Takes ownership of [fd]; returns the effect id or -1. */
    external fun nativeLoadBundleFd(fd: Int): Int
    external fun nativeEffectInfo(id: Int): String?
    external fun nativeRemoveEffect(id: Int)
    external fun nativeClear()
    external fun nativeSetVisible(id: Int, visible: Int)

    // playback
    external fun nativeSetPlaying(playing: Int)
    external fun nativeIsPlaying(): Int
    external fun nativeRestart()
    external fun nativeSeek(t: Float)
    external fun nativeGetTime(): Float
    external fun nativeGetDuration(): Float
    external fun nativeSetSpeed(speed: Float)
    external fun nativeSetLoop(looping: Int)

    // view options
    external fun nativeSetBlend(mode: Int)
    external fun nativeSetMask(on: Int)
    external fun nativeSetVertexColor(on: Int)
    external fun nativeSetBackground(bg: Int)
    external fun nativeSetGrid(on: Int)

    // camera
    external fun nativeOrbit(dx: Float, dy: Float)
    external fun nativeZoom(factor: Float)
    external fun nativePan(dx: Float, dy: Float)
    external fun nativeResetCamera()

    // diagnostics
    external fun nativeGetLog(): String?
    external fun nativeClearLog()
    external fun nativeStatus(): String?
}
