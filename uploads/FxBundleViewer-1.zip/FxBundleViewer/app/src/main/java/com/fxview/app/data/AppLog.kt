package com.fxview.app.data

import android.util.Log
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** In-memory log for the Kotlin side; shown together with the native log in the diagnostics dialog. */
object AppLog {
    private const val TAG = "FxView"
    private const val MAX_LINES = 1500
    private val lines = ArrayList<String>()
    private val clock = SimpleDateFormat("HH:mm:ss", Locale.US)

    @Synchronized
    fun add(level: Char, msg: String) {
        if (lines.size >= MAX_LINES) {
            for (i in 0 until MAX_LINES / 4) {
                lines.removeAt(0)
            }
        }
        lines.add(clock.format(Date()) + " " + level + " " + msg)
        when (level) {
            'E' -> Log.e(TAG, msg)
            'W' -> Log.w(TAG, msg)
            else -> Log.i(TAG, msg)
        }
    }

    fun i(msg: String) = add('I', msg)
    fun w(msg: String) = add('W', msg)
    fun e(msg: String) = add('E', msg)

    @Synchronized
    fun text(): String = lines.joinToString("\n")

    @Synchronized
    fun clear() {
        lines.clear()
    }
}
