package com.fxview.app.data

import android.content.Context
import com.fxview.app.nativebridge.NativeBridge
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.util.Date

/**
 * Persists uncaught Kotlin exceptions (together with the native and app logs) so that the cause of
 * a crash can be read in the diagnostics dialog after the next start - no adb needed.
 */
object CrashLog {
    private const val FILE_NAME = "last_crash.txt"

    fun install(context: Context) {
        val appContext = context.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            try {
                val sw = StringWriter()
                error.printStackTrace(PrintWriter(sw))
                val nativeLog = try {
                    if (NativeBridge.isAvailable) NativeBridge.nativeGetLog() ?: "" else "(native library not loaded)"
                } catch (t: Throwable) {
                    "(native log unavailable: $t)"
                }
                val text = "Crash on thread '" + thread.name + "' at " + Date() + "\n" + sw.toString() +
                    "\n--- native log ---\n" + nativeLog + "\n--- app log ---\n" + AppLog.text()
                File(appContext.filesDir, FILE_NAME).writeText(text)
            } catch (ex: Throwable) {
                // nothing sensible left to do
            }
            previous?.uncaughtException(thread, error)
        }
    }

    fun read(context: Context): String? {
        val f = File(context.filesDir, FILE_NAME)
        return if (f.exists()) {
            try {
                f.readText()
            } catch (ex: Exception) {
                null
            }
        } else {
            null
        }
    }

    fun clear(context: Context) {
        File(context.filesDir, FILE_NAME).delete()
    }
}
