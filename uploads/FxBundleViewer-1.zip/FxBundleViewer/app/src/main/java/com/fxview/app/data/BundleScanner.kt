package com.fxview.app.data

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.OpenableColumns

/** A bundle file the user can load (a document URI, not a path - works with scoped storage). */
data class BundleRef(val name: String, val uri: Uri, val size: Long)

object BundleScanner {
    private val EXTENSIONS = listOf(".unity3d", ".bundle", ".assetbundle", ".ab")

    fun isBundleName(name: String): Boolean {
        val n = name.lowercase()
        return EXTENSIONS.any { n.endsWith(it) }
    }

    /** Recursively lists bundle files below a document tree URI (chosen with the folder picker). */
    fun scanTree(context: Context, treeUri: Uri, maxDepth: Int = 4, maxFiles: Int = 3000): List<BundleRef> {
        val out = ArrayList<BundleRef>()
        val rootId = DocumentsContract.getTreeDocumentId(treeUri)
        walk(context, treeUri, rootId, 0, maxDepth, maxFiles, out)
        out.sortBy { it.name.lowercase() }
        return out
    }

    private fun walk(
        context: Context,
        tree: Uri,
        docId: String,
        depth: Int,
        maxDepth: Int,
        maxFiles: Int,
        out: MutableList<BundleRef>
    ) {
        if (out.size >= maxFiles) return
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
        val columns = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_SIZE
        )
        val subDirs = ArrayList<String>()
        try {
            val cursor = context.contentResolver.query(children, columns, null, null, null)
            if (cursor != null) {
                cursor.use { c ->
                    while (c.moveToNext()) {
                        val id = c.getString(0)
                        val name = c.getString(1)
                        val mime = c.getString(2)
                        if (id == null || name == null) continue
                        val size = if (c.isNull(3)) 0L else c.getLong(3)
                        if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                            subDirs.add(id)
                        } else if (isBundleName(name)) {
                            out.add(BundleRef(name, DocumentsContract.buildDocumentUriUsingTree(tree, id), size))
                        }
                    }
                }
            }
        } catch (e: Exception) {
            AppLog.w("folder scan failed: $e")
        }
        if (depth < maxDepth) {
            for (d in subDirs) {
                walk(context, tree, d, depth + 1, maxDepth, maxFiles, out)
            }
        }
    }

    /** Describes a single document returned by the file picker. */
    fun describe(context: Context, uri: Uri): BundleRef {
        var name = uri.lastPathSegment ?: "bundle"
        var size = 0L
        try {
            val cursor = context.contentResolver.query(uri, null, null, null, null)
            if (cursor != null) {
                cursor.use { c ->
                    if (c.moveToFirst()) {
                        val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        val si = c.getColumnIndex(OpenableColumns.SIZE)
                        if (ni >= 0 && !c.isNull(ni)) name = c.getString(ni)
                        if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
                    }
                }
            }
        } catch (e: Exception) {
            AppLog.w("could not query $uri: $e")
        }
        return BundleRef(name, uri, size)
    }
}
