package com.fxview.app

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import com.fxview.app.data.AppLog
import com.fxview.app.data.BundleRef
import com.fxview.app.data.BundleScanner
import com.fxview.app.data.CrashLog
import com.fxview.app.nativebridge.NativeBridge
import com.fxview.app.ui.FxGLSurfaceView
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/**
 * Single-screen viewer: a full-screen GL view (rendered by the Rust core) with an overlay for
 * opening bundles, playback control, view options and the diagnostics dialog.
 */
class MainActivity : Activity() {

    private class LoadedFx(val id: Int, val name: String, var visible: Boolean)

    private val handler = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private val loaded = ArrayList<LoadedFx>()
    private var library: List<BundleRef> = emptyList()

    private var glView: FxGLSurfaceView? = null
    private lateinit var statusText: TextView
    private lateinit var titleText: TextView
    private lateinit var seekBar: SeekBar
    private lateinit var playButton: Button
    private lateinit var speedButton: Button
    private lateinit var loopButton: Button
    private lateinit var blendButton: Button
    private lateinit var maskButton: Button
    private lateinit var colorButton: Button
    private lateinit var bgButton: Button
    private lateinit var gridButton: Button

    private var nativeReady = false
    private var dragging = false
    private var speedIdx = 2
    private var blendIdx = 0
    private var bgIdx = 0
    private var looping = true
    private var maskOn = true
    private var vertexColorOn = true
    private var gridOn = true

    private val speedValues = floatArrayOf(0.25f, 0.5f, 1f, 2f)
    private val blendLabels = arrayOf("Blend: auto", "Blend: add", "Blend: alpha", "Blend: opaque")
    private val bgLabels = arrayOf("BG: dark", "BG: grey", "BG: light")

    // ---------------------------------------------------------------------------------------
    // lifecycle
    // ---------------------------------------------------------------------------------------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        if (!NativeBridge.isAvailable) {
            showFatal(
                "The native Rust library (libfxview.so) could not be loaded.\n\n" +
                    NativeBridge.loadError + "\n\n" +
                    "Device ABIs: " + Build.SUPPORTED_ABIS.joinToString(", ") + "\n\n" +
                    "Check that the build log contains the 'cargo-ndk' step output for these ABIs " +
                    "(rustAbis in gradle.properties)."
            )
            return
        }
        NativeBridge.nativeInit()
        nativeReady = true
        AppLog.i("FX Bundle Viewer started (Android " + Build.VERSION.RELEASE + ", " + Build.MODEL + ")")

        buildUi()
        val crash = CrashLog.read(this)
        if (crash != null) {
            AppLog.w("A crash was recorded during the previous run - open Log to read it.")
        }
        handler.post(ticker)
    }

    override fun onResume() {
        super.onResume()
        glView?.onResume()
    }

    override fun onPause() {
        glView?.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        super.onDestroy()
    }

    private fun showFatal(message: String) {
        val tv = TextView(this)
        tv.text = message
        tv.setTextColor(Color.WHITE)
        tv.setPadding(dp(20), dp(40), dp(20), dp(20))
        tv.setTextIsSelectable(true)
        val sv = ScrollView(this)
        sv.setBackgroundColor(Color.rgb(20, 20, 26))
        sv.addView(tv)
        setContentView(sv)
    }

    // ---------------------------------------------------------------------------------------
    // UI construction
    // ---------------------------------------------------------------------------------------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun roundRect(color: Int, radiusDp: Int): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(color)
        d.cornerRadius = dp(radiusDp).toFloat()
        return d
    }

    private fun makeButton(label: String, onClick: (Button) -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.textSize = 12f
        b.minWidth = 0
        b.minimumWidth = 0
        b.minHeight = 0
        b.minimumHeight = 0
        b.setPadding(dp(11), dp(7), dp(11), dp(7))
        b.setTextColor(Color.WHITE)
        b.background = roundRect(Color.argb(215, 46, 52, 66), 9)
        b.setOnClickListener { onClick(b) }
        return b
    }

    private fun rowParams(): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        p.setMargins(dp(3), 0, dp(3), 0)
        return p
    }

    private fun buildUi() {
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)

        val gl = FxGLSurfaceView(this)
        glView = gl
        root.addView(gl, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // ---- top bar -------------------------------------------------------------------
        val top = LinearLayout(this)
        top.orientation = LinearLayout.VERTICAL
        top.setPadding(dp(6), dp(6), dp(6), dp(4))

        val topRow = LinearLayout(this)
        topRow.orientation = LinearLayout.HORIZONTAL
        topRow.addView(makeButton("Files") { pickFiles() }, rowParams())
        topRow.addView(makeButton("Folder") { pickFolder() }, rowParams())
        topRow.addView(makeButton("Library") { showLibrary() }, rowParams())
        topRow.addView(makeButton("Effects") { showEffects() }, rowParams())
        topRow.addView(makeButton("Log") { showLog() }, rowParams())
        topRow.addView(makeButton("Frame") { NativeBridge.nativeResetCamera() }, rowParams())
        val topScroll = HorizontalScrollView(this)
        topScroll.isHorizontalScrollBarEnabled = false
        topScroll.addView(topRow)
        top.addView(topScroll)

        titleText = TextView(this)
        titleText.setTextColor(Color.WHITE)
        titleText.textSize = 13f
        titleText.setPadding(dp(8), dp(6), dp(8), dp(2))
        titleText.setShadowLayer(4f, 0f, 0f, Color.BLACK)
        titleText.text = "Open one or more .unity3d bundles to start"
        top.addView(titleText)

        statusText = TextView(this)
        statusText.setTextColor(Color.rgb(190, 200, 215))
        statusText.textSize = 11f
        statusText.typeface = Typeface.MONOSPACE
        statusText.setPadding(dp(8), 0, dp(8), 0)
        statusText.setShadowLayer(4f, 0f, 0f, Color.BLACK)
        top.addView(statusText)

        root.addView(
            top,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP)
        )

        // ---- bottom controls -----------------------------------------------------------
        val bottom = LinearLayout(this)
        bottom.orientation = LinearLayout.VERTICAL
        bottom.setPadding(dp(8), dp(4), dp(8), dp(8))
        bottom.setBackgroundColor(Color.argb(120, 0, 0, 0))

        seekBar = SeekBar(this)
        seekBar.max = 1000
        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser && nativeReady) {
                    NativeBridge.nativeSeek(progress / 1000f * NativeBridge.nativeGetDuration())
                }
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {
                dragging = true
                NativeBridge.nativeSetPlaying(0)
            }

            override fun onStopTrackingTouch(sb: SeekBar?) {
                dragging = false
            }
        })
        bottom.addView(seekBar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val controls = LinearLayout(this)
        controls.orientation = LinearLayout.HORIZONTAL

        playButton = makeButton("Pause") {
            val playing = NativeBridge.nativeIsPlaying() != 0
            NativeBridge.nativeSetPlaying(if (playing) 0 else 1)
        }
        controls.addView(playButton, rowParams())
        controls.addView(makeButton("Restart") { NativeBridge.nativeRestart() }, rowParams())

        loopButton = makeButton("Loop: on") {
            looping = !looping
            NativeBridge.nativeSetLoop(if (looping) 1 else 0)
            refreshLabels()
        }
        controls.addView(loopButton, rowParams())

        speedButton = makeButton("1x") {
            speedIdx = (speedIdx + 1) % speedValues.size
            NativeBridge.nativeSetSpeed(speedValues[speedIdx])
            refreshLabels()
        }
        controls.addView(speedButton, rowParams())

        blendButton = makeButton(blendLabels[0]) {
            blendIdx = (blendIdx + 1) % blendLabels.size
            NativeBridge.nativeSetBlend(blendIdx)
            refreshLabels()
        }
        controls.addView(blendButton, rowParams())

        maskButton = makeButton("Mask: on") {
            maskOn = !maskOn
            NativeBridge.nativeSetMask(if (maskOn) 1 else 0)
            refreshLabels()
        }
        controls.addView(maskButton, rowParams())

        colorButton = makeButton("Vertex color: on") {
            vertexColorOn = !vertexColorOn
            NativeBridge.nativeSetVertexColor(if (vertexColorOn) 1 else 0)
            refreshLabels()
        }
        controls.addView(colorButton, rowParams())

        bgButton = makeButton(bgLabels[0]) {
            bgIdx = (bgIdx + 1) % bgLabels.size
            NativeBridge.nativeSetBackground(bgIdx)
            refreshLabels()
        }
        controls.addView(bgButton, rowParams())

        gridButton = makeButton("Grid: on") {
            gridOn = !gridOn
            NativeBridge.nativeSetGrid(if (gridOn) 1 else 0)
            refreshLabels()
        }
        controls.addView(gridButton, rowParams())

        val controlScroll = HorizontalScrollView(this)
        controlScroll.isHorizontalScrollBarEnabled = false
        controlScroll.addView(controls)
        bottom.addView(controlScroll)

        root.addView(
            bottom,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM)
        )

        setContentView(root)
        refreshLabels()
    }

    private fun refreshLabels() {
        loopButton.text = if (looping) "Loop: on" else "Loop: off"
        speedButton.text = speedLabel(speedValues[speedIdx])
        blendButton.text = blendLabels[blendIdx]
        maskButton.text = if (maskOn) "Mask: on" else "Mask: off"
        colorButton.text = if (vertexColorOn) "Vertex color: on" else "Vertex color: off"
        bgButton.text = bgLabels[bgIdx]
        gridButton.text = if (gridOn) "Grid: on" else "Grid: off"
    }

    private fun speedLabel(v: Float): String = if (v == 1f) "1x" else if (v == 2f) "2x" else v.toString() + "x"

    /** Refreshes the status line, seek bar and play button ten times a second. */
    private val ticker = object : Runnable {
        override fun run() {
            if (nativeReady) {
                statusText.text = NativeBridge.nativeStatus() ?: ""
                if (!dragging) {
                    val d = NativeBridge.nativeGetDuration()
                    val t = NativeBridge.nativeGetTime()
                    val p = if (d > 0f) (t / d * 1000f).toInt() else 0
                    seekBar.progress = if (p < 0) 0 else if (p > 1000) 1000 else p
                }
                playButton.text = if (NativeBridge.nativeIsPlaying() != 0) "Pause" else "Play"
            }
            handler.postDelayed(this, 100)
        }
    }

    // ---------------------------------------------------------------------------------------
    // opening bundles
    // ---------------------------------------------------------------------------------------

    private fun pickFiles() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        try {
            startActivityForResult(i, REQ_FILES)
        } catch (e: Exception) {
            toast("No file picker available: $e")
        }
    }

    private fun pickFolder() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        try {
            startActivityForResult(i, REQ_FOLDER)
        } catch (e: Exception) {
            toast("No folder picker available: $e")
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        if (requestCode == REQ_FILES) {
            val uris = ArrayList<Uri>()
            val clip = data.clipData
            if (clip != null) {
                for (k in 0 until clip.itemCount) {
                    uris.add(clip.getItemAt(k).uri)
                }
            } else {
                val single = data.data
                if (single != null) uris.add(single)
            }
            val refs = ArrayList<BundleRef>()
            for (u in uris) {
                try {
                    contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (e: Exception) {
                    // not every provider allows persistable permission; reading now still works
                }
                refs.add(BundleScanner.describe(this, u))
            }
            loadBundles(refs)
        } else if (requestCode == REQ_FOLDER) {
            val tree = data.data ?: return
            try {
                contentResolver.takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
                AppLog.w("could not persist folder permission: $e")
            }
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(PREF_TREE, tree.toString()).apply()
            scanFolder(tree, true)
        }
    }

    private fun scanFolder(tree: Uri, openDialog: Boolean) {
        toast("Scanning folder...")
        io.execute {
            val found = try {
                BundleScanner.scanTree(this, tree)
            } catch (e: Exception) {
                AppLog.e("scan failed: $e")
                emptyList<BundleRef>()
            }
            handler.post {
                library = found
                AppLog.i("folder scan: " + found.size + " bundle file(s)")
                if (found.isEmpty()) {
                    toast("No .unity3d files found (Android 11 hides Android/data - copy the files to Downloads first)")
                } else if (openDialog) {
                    showLibrary()
                }
            }
        }
    }

    private fun showLibrary() {
        if (library.isEmpty()) {
            val saved = getSharedPreferences(PREFS, MODE_PRIVATE).getString(PREF_TREE, null)
            if (saved != null) {
                scanFolder(Uri.parse(saved), true)
            } else {
                toast("Pick a folder first")
            }
            return
        }
        val names = Array(library.size) { k -> library[k].name + "  (" + (library[k].size / 1024) + " KB)" }
        val checked = BooleanArray(library.size) { library.size <= 3 }
        AlertDialog.Builder(this)
            .setTitle("Bundles (" + library.size + ")")
            .setMultiChoiceItems(names, checked) { _, which, isChecked -> checked[which] = isChecked }
            .setPositiveButton("Load selected") { _, _ ->
                val sel = ArrayList<BundleRef>()
                for (k in library.indices) {
                    if (checked[k]) sel.add(library[k])
                }
                loadBundles(sel)
            }
            .setNeutralButton("Load all") { _, _ -> loadBundles(library) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun loadBundles(refs: List<BundleRef>) {
        if (refs.isEmpty()) {
            toast("Nothing selected")
            return
        }
        NativeBridge.nativeClear()
        loaded.clear()
        titleText.text = "Loading " + refs.size + " bundle(s)..."
        io.execute {
            val results = ArrayList<LoadedFx>()
            for (r in refs) {
                AppLog.i("Loading " + r.name + " (" + (r.size / 1024) + " KB)")
                var id = -1
                try {
                    val pfd = contentResolver.openFileDescriptor(r.uri, "r")
                    if (pfd != null) {
                        id = NativeBridge.nativeLoadBundleFd(pfd.detachFd())
                    } else {
                        AppLog.e("could not open " + r.name)
                    }
                } catch (e: Throwable) {
                    AppLog.e("failed to open " + r.name + ": " + e)
                }
                if (id >= 0) {
                    val info = NativeBridge.nativeEffectInfo(id) ?: ""
                    AppLog.i("--- " + r.name + " ---\n" + info)
                    results.add(LoadedFx(id, r.name, true))
                } else {
                    AppLog.e("Could not load " + r.name + " - see the native log lines for the reason")
                }
            }
            handler.post {
                loaded.addAll(results)
                updateTitle()
                if (results.size < refs.size) {
                    toast((refs.size - results.size).toString() + " bundle(s) failed - open Log")
                }
            }
        }
    }

    private fun updateTitle() {
        val shown = loaded.filter { it.visible }.map { it.name.removeSuffix(".unity3d") }
        titleText.text = if (shown.isEmpty()) "Open one or more .unity3d bundles to start" else shown.joinToString("  +  ")
    }

    private fun showEffects() {
        if (loaded.isEmpty()) {
            toast("Nothing loaded yet")
            return
        }
        val names = Array(loaded.size) { k -> loaded[k].name }
        val checked = BooleanArray(loaded.size) { k -> loaded[k].visible }
        AlertDialog.Builder(this)
            .setTitle("Loaded effects")
            .setMultiChoiceItems(names, checked) { _, which, isChecked ->
                loaded[which].visible = isChecked
                NativeBridge.nativeSetVisible(loaded[which].id, if (isChecked) 1 else 0)
                updateTitle()
            }
            .setPositiveButton("Close", null)
            .setNegativeButton("Clear all") { _, _ ->
                NativeBridge.nativeClear()
                loaded.clear()
                updateTitle()
            }
            .show()
    }

    // ---------------------------------------------------------------------------------------
    // diagnostics
    // ---------------------------------------------------------------------------------------

    private fun buildLogText(): String {
        val sb = StringBuilder()
        val crash = CrashLog.read(this)
        if (crash != null) {
            sb.append("=== PREVIOUS CRASH ===\n").append(crash).append("\n\n")
        }
        sb.append("=== App ===\n").append(AppLog.text()).append("\n\n")
        sb.append("=== Native (Rust) ===\n").append(NativeBridge.nativeGetLog() ?: "").append("\n")
        return sb.toString()
    }

    private fun showLog() {
        val text = buildLogText()
        val tv = TextView(this)
        tv.typeface = Typeface.MONOSPACE
        tv.textSize = 10.5f
        tv.setTextColor(Color.rgb(222, 228, 238))
        tv.setTextIsSelectable(true)
        tv.setPadding(dp(12), dp(8), dp(12), dp(8))
        tv.text = text
        val sv = ScrollView(this)
        sv.addView(tv)
        AlertDialog.Builder(this)
            .setTitle("Diagnostics")
            .setView(sv)
            .setPositiveButton("Save") { _, _ -> saveLog(text) }
            .setNeutralButton("Copy") { _, _ ->
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("FxView log", text))
                toast("Log copied")
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun saveLog(text: String) {
        val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
        val name = "FxViewer-log-" + stamp + ".txt"
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues()
                values.put(MediaStore.Downloads.DISPLAY_NAME, name)
                values.put(MediaStore.Downloads.MIME_TYPE, "text/plain")
                values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                if (uri != null) {
                    val out = contentResolver.openOutputStream(uri)
                    if (out != null) {
                        out.use { it.write(text.toByteArray()) }
                    }
                    toast("Saved to Downloads/" + name)
                } else {
                    toast("Could not create the log file")
                }
            } else {
                val dir = getExternalFilesDir(null)
                if (dir != null) {
                    val f = File(dir, name)
                    f.writeText(text)
                    toast("Saved to " + f.absolutePath)
                }
            }
        } catch (e: Exception) {
            toast("Save failed: $e")
        }
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    companion object {
        private const val REQ_FILES = 101
        private const val REQ_FOLDER = 102
        private const val PREFS = "fxview"
        private const val PREF_TREE = "last_tree"
    }
}
