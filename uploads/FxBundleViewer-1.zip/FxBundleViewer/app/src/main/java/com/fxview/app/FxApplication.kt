package com.fxview.app

import android.app.Application
import com.fxview.app.data.CrashLog

class FxApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        CrashLog.install(this)
    }
}
