package com.particlelife

import android.app.AlertDialog
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.core.view.setPadding
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment

class SettingsSheet : BottomSheetDialogFragment() {

    private val simView get() = (activity as? MainActivity)?.simView
    private val eng     get() = simView?.engine

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun px(v: Float) = (v * resources.displayMetrics.density)

    override fun onCreateDialog(saved: Bundle?) = (super.onCreateDialog(saved) as BottomSheetDialog).also { d ->
        d.setOnShowListener {
            val bs = d.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)
            bs?.let {
                it.setBackgroundColor(Color.parseColor("#0D0D1E"))
                val beh = BottomSheetBehavior.from(it)
                beh.state         = BottomSheetBehavior.STATE_EXPANDED
                beh.skipCollapsed = true
                beh.peekHeight    = 0
            }
        }
    }

    override fun onCreateView(inf: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val scroll = ScrollView(requireContext()).apply {
            setBackgroundColor(Color.parseColor("#0D0D1E"))
        }
        val root = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16))
        }
        scroll.addView(root)
        buildUI(root)
        return scroll
    }

    private fun buildUI(root: LinearLayout) {
        val e  = eng     ?: return
        val sv = simView ?: return

        // ── Handle bar ────────────────────────────────────────
        root.addView(View(requireContext()).apply {
            background = roundRect(Color.parseColor("#2A2A4A"), dp(2))
            layoutParams = LinearLayout.LayoutParams(dp(40), dp(4)).also {
                it.gravity    = Gravity.CENTER_HORIZONTAL
                it.bottomMargin = dp(14)
                it.topMargin    = dp(4)
            }
        })

        // ── Section header helper ─────────────────────────────
        fun sectionLabel(text: String) = TextView(requireContext()).apply {
            this.text = text
            textSize  = 9f
            setTextColor(Color.parseColor("#334455"))
            letterSpacing = 0.2f
            typeface  = Typeface.MONOSPACE
            layoutParams = linLP(margin_b = dp(6))
        }

        // ── Slider helper ─────────────────────────────────────
        fun sliderRow(label: String, initial: String, max: Int,
                      prog: Int, onChange: (Int) -> String): View {
            val row = LinearLayout(requireContext()).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = linLP(margin_b = dp(10))
            }
            val header = LinearLayout(requireContext()).apply { orientation = LinearLayout.HORIZONTAL }
            val lbl = TextView(requireContext()).apply {
                text = label; textSize = 11f
                setTextColor(Color.parseColor("#667788"))
                layoutParams = LinearLayout.LayoutParams(0, wc(), 1f)
            }
            val tv = TextView(requireContext()).apply {
                text = initial; textSize = 11f
                setTextColor(Color.parseColor("#8899aa"))
                gravity = Gravity.END
                layoutParams = LinearLayout.LayoutParams(dp(70), wc())
            }
            header.addView(lbl); header.addView(tv)
            val sb = SeekBar(requireContext()).apply {
                this.max = max
                progress  = prog
                progressTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#4499ff"))
                thumbTintList    = android.content.res.ColorStateList.valueOf(Color.parseColor("#4499ff"))
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) { tv.text = onChange(p) }
                    override fun onStartTrackingTouch(s: SeekBar) {}
                    override fun onStopTrackingTouch(s: SeekBar) {}
                })
            }
            row.addView(header); row.addView(sb)
            return row
        }

        // ── Toggle helper ─────────────────────────────────────
        fun toggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit): View {
            val row = LinearLayout(requireContext()).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity     = Gravity.CENTER_VERTICAL
                layoutParams = linLP(margin_b = dp(8))
            }
            val lbl = TextView(requireContext()).apply {
                text = label; textSize = 12f
                setTextColor(Color.parseColor("#667788"))
                layoutParams = LinearLayout.LayoutParams(0, wc(), 1f)
            }
            val sw = Switch(requireContext()).apply {
                isChecked = checked
                thumbTintList = android.content.res.ColorStateList.valueOf(
                    if (checked) Color.parseColor("#44ee77") else Color.parseColor("#445566"))
                trackTintList = android.content.res.ColorStateList.valueOf(
                    if (checked) Color.parseColor("#1a3a22") else Color.parseColor("#1a1a2a"))
                setOnCheckedChangeListener { _, c ->
                    thumbTintList = android.content.res.ColorStateList.valueOf(
                        if (c) Color.parseColor("#44ee77") else Color.parseColor("#445566"))
                    trackTintList = android.content.res.ColorStateList.valueOf(
                        if (c) Color.parseColor("#1a3a22") else Color.parseColor("#1a1a2a"))
                    onChange(c)
                }
            }
            row.addView(lbl); row.addView(sw)
            return row
        }

        // ── Button helper ─────────────────────────────────────
        fun actionBtn(label: String, colorHex: String, onClick: () -> Unit): Button {
            return Button(requireContext()).apply {
                text = label; textSize = 12f
                setTextColor(Color.parseColor(colorHex))
                background = roundRect(Color.parseColor(colorHex + "22"), dp(6),
                    Color.parseColor(colorHex + "55"), dp(1))
                layoutParams = linLP(margin_b = dp(6))
                setPadding(dp(12), dp(8), dp(12), dp(8))
                setOnClickListener { onClick() }
            }
        }

        // ════════ PRESETS ════════
        root.addView(sectionLabel("PRESETS"))
        val presetScroll = HorizontalScrollView(requireContext()).apply {
            layoutParams = linLP(margin_b = dp(14)); isHorizontalScrollBarEnabled = false
        }
        val presetRow = LinearLayout(requireContext()).apply { orientation = LinearLayout.HORIZONTAL }
        for (p in Presets.ALL) {
            presetRow.addView(Button(requireContext()).apply {
                text = "${p.emoji} ${p.name}"; textSize = 11f
                setTextColor(Color.parseColor("#7aafee"))
                background = roundRect(Color.parseColor("#0f1a2a"), dp(6),
                    Color.parseColor("#1a3a5a"), dp(1))
                layoutParams = LinearLayout.LayoutParams(wc(), wc()).also { it.marginEnd = dp(6) }
                setPadding(dp(10), dp(6), dp(10), dp(6))
                setOnClickListener {
                    synchronized(e) { e.loadPreset(p) }
                    sv.resetCamera()
                    (activity as? MainActivity)?.refreshSpeciesList()
                    Toast.makeText(requireContext(), "Loaded: ${p.name}", Toast.LENGTH_SHORT).show()
                }
            })
        }
        presetScroll.addView(presetRow)
        root.addView(presetScroll)

        // ════════ PHYSICS ════════
        root.addView(sectionLabel("PHYSICS"))
        root.addView(sliderRow("Friction", fmt2(e.friction), 49,
            ((e.friction - 0.5f) * 100).toInt()) { p ->
            val v = 0.5f + p * 0.01f; synchronized(e) { e.friction = v }; fmt2(v) })
        root.addView(sliderRow("Force Multiplier", fmt1(e.forceMul), 39,
            ((e.forceMul - 0.5f) / 0.5f).toInt()) { p ->
            val v = 0.5f + p * 0.5f; synchronized(e) { e.forceMul = v }; fmt1(v) })
        root.addView(sliderRow("Interaction Radius", "${e.radius.toInt()}", 36,
            ((e.radius - 20f) / 5f).toInt()) { p ->
            val v = 20f + p * 5f; synchronized(e) { e.radius = v }; "${v.toInt()}" })
        root.addView(sliderRow("Speed", fmt2(e.speed), 58,
            ((e.speed - 0.1f) / 0.05f).toInt()) { p ->
            val v = 0.1f + p * 0.05f; synchronized(e) { e.speed = v }; fmt2(v) })
        root.addView(sliderRow("Repulsion Zone β", fmt2(e.beta), 45,
            ((e.beta - 0.05f) / 0.01f).toInt()) { p ->
            val v = 0.05f + p * 0.01f; synchronized(e) { e.beta = v }; fmt2(v) })

        // ════════ VISUAL ════════
        root.addView(sectionLabel("VISUAL"))
        root.addView(toggleRow("Particle Trails", sv.showTrails) { sv.showTrails = it })
        root.addView(toggleRow("Wrap Edges", e.wrap) { synchronized(e) { e.wrap = it } })

        // ════════ ACTIONS ════════
        root.addView(sectionLabel("ACTIONS"))
        root.addView(actionBtn("⚡  Randomize Matrix", "#ffaa33") {
            synchronized(e) { e.randomizeMatrix() }
            Toast.makeText(requireContext(), "Matrix randomized!", Toast.LENGTH_SHORT).show()
        })
        root.addView(actionBtn("⊞  Edit Interaction Matrix", "#7aafee") { showMatrixEditor() })
        root.addView(actionBtn("+  Add Species", "#44ee77") {
            synchronized(e) {
                val colors = listOf("#ff4455","#44ff77","#4488ff","#ffcc22","#cc44ff",
                    "#ff8833","#00ffcc","#ff44bb","#88ff44","#44ccff")
                val col = Color.parseColor(colors[e.species.size % colors.size])
                val s   = Species(e.species.size + 100, "Species ${e.species.size+1}", col, 4f, 100)
                e.addSpecies(s); e.spawn(s.id, 100)
            }
            (activity as? MainActivity)?.refreshSpeciesList()
            dismiss()
        })
        root.addView(actionBtn("↺  Reset Simulation", "#8888ff") {
            synchronized(e) { e.clear(); for (s in e.species) e.spawn(s.id, s.count) }
            Toast.makeText(requireContext(), "Reset", Toast.LENGTH_SHORT).show()
        })
        root.addView(actionBtn("⌖  Reset Camera", "#667788") { sv.resetCamera() })

        // ════════ SPECIES LIST ════════
        root.addView(sectionLabel("SPECIES"))
        val spContainer = LinearLayout(requireContext()).apply {
            id          = R.id.speciesContainer
            orientation = LinearLayout.VERTICAL
        }
        root.addView(spContainer)
        populateSpecies(spContainer)
    }

    private fun populateSpecies(container: LinearLayout) {
        val e = eng ?: return
        container.removeAllViews()
        val speciesCopy = synchronized(e) { e.species.toList() }
        val counts      = HashMap<Int,Int>()
        synchronized(e) { for (p in e.particles) counts[p.sid] = (counts[p.sid] ?: 0) + 1 }

        for (s in speciesCopy) {
            val row = LinearLayout(requireContext()).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity     = Gravity.CENTER_VERTICAL
                setPadding(0, dp(5), 0, dp(5))
            }
            // Color dot
            val dot = View(requireContext()).apply {
                background = roundRect(s.color, dp(6))
                layoutParams = LinearLayout.LayoutParams(dp(16), dp(16)).also { it.marginEnd = dp(10) }
            }
            // Name
            val name = TextView(requireContext()).apply {
                text = s.name; textSize = 13f
                setTextColor(Color.parseColor("#bbccdd"))
                layoutParams = LinearLayout.LayoutParams(0, wc(), 1f)
            }
            // Count
            val cnt = TextView(requireContext()).apply {
                text = "${counts[s.id] ?: 0}"; textSize = 10f
                setTextColor(Color.parseColor("#334455"))
                layoutParams = LinearLayout.LayoutParams(dp(45), wc()).also { it.marginEnd = dp(6) }
                gravity = Gravity.END
            }
            // Remove
            val rem = TextView(requireContext()).apply {
                text = "✕"; textSize = 14f
                setTextColor(Color.parseColor("#553333"))
                setPadding(dp(6), 0, 0, 0)
                setOnClickListener {
                    synchronized(e) { e.removeSpecies(s.id) }
                    (activity as? MainActivity)?.refreshSpeciesList()
                    populateSpecies(container)
                }
            }
            row.addView(dot); row.addView(name); row.addView(cnt); row.addView(rem)
            container.addView(row)
            // Divider
            container.addView(View(requireContext()).apply {
                setBackgroundColor(Color.parseColor("#141428"))
                layoutParams = LinearLayout.LayoutParams(mp(), dp(1)).also { it.bottomMargin = dp(2) }
            })
        }
    }

    // ── Matrix editor dialog ──────────────────────────────────
    private fun showMatrixEditor() {
        val e = eng ?: return
        val scroll = ScrollView(requireContext()).apply {
            setBackgroundColor(Color.parseColor("#0D0D1E"))
        }
        val container = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16))
        }
        scroll.addView(container)

        val speciesCopy = synchronized(e) { e.species.toList() }
        val matCopy     = synchronized(e) {
            HashMap(e.matrix.mapValues { HashMap(it.value) })
        }

        for (a in speciesCopy) {
            // Species group header
            container.addView(TextView(requireContext()).apply {
                text = a.name; textSize = 11f; setTextColor(a.color)
                setPadding(0, dp(10), 0, dp(4)); typeface = Typeface.DEFAULT_BOLD
            })
            for (b in speciesCopy) {
                val curVal = matCopy[a.id]?.get(b.id) ?: 0f
                val rowV   = LinearLayout(requireContext()).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = linLP(margin_b = dp(6))
                }
                val hdr = LinearLayout(requireContext()).apply { orientation = LinearLayout.HORIZONTAL }
                val lbl = TextView(requireContext()).apply {
                    text = "  → ${b.name}"; textSize = 10f
                    setTextColor(Color.parseColor("#667788"))
                    layoutParams = LinearLayout.LayoutParams(0, wc(), 1f)
                }
                val tvVal = TextView(requireContext()).apply {
                    text = fmtMx(curVal); textSize = 10f
                    setTextColor(if (curVal >= 0) Color.parseColor("#44ee77") else Color.parseColor("#ff5555"))
                    gravity = Gravity.END
                    layoutParams = LinearLayout.LayoutParams(dp(55), wc())
                }
                hdr.addView(lbl); hdr.addView(tvVal)
                val sb = SeekBar(requireContext()).apply {
                    max = 200; progress = ((curVal + 1f) * 100).toInt().coerceIn(0, 200)
                    progressTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#4499ff"))
                    thumbTintList    = android.content.res.ColorStateList.valueOf(Color.parseColor("#4499ff"))
                    setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                        override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) {
                            val v = p / 100f - 1f
                            synchronized(e) { e.matrix.getOrPut(a.id){HashMap()}[b.id] = v }
                            tvVal.text = fmtMx(v)
                            tvVal.setTextColor(if (v >= 0) Color.parseColor("#44ee77") else Color.parseColor("#ff5555"))
                        }
                        override fun onStartTrackingTouch(s: SeekBar) {}
                        override fun onStopTrackingTouch(s: SeekBar) {}
                    })
                }
                rowV.addView(hdr); rowV.addView(sb)
                container.addView(rowV)
            }
        }

        AlertDialog.Builder(requireContext())
            .setTitle("Interaction Matrix")
            .setView(scroll)
            .setPositiveButton("Done", null)
            .show()
            .window?.decorView?.setBackgroundColor(Color.parseColor("#0D0D1E"))
    }

    // ── Helpers ───────────────────────────────────────────────
    private fun roundRect(fill: Int, radius: Int,
                           stroke: Int = Color.TRANSPARENT, sw: Int = 0) =
        GradientDrawable().apply {
            shape         = GradientDrawable.RECTANGLE
            cornerRadius  = radius.toFloat()
            setColor(fill)
            if (sw > 0) setStroke(sw, stroke)
        }

    private fun linLP(margin_b: Int = 0) = LinearLayout.LayoutParams(mp(), wc()).also {
        it.bottomMargin = margin_b
    }

    private fun mp() = ViewGroup.LayoutParams.MATCH_PARENT
    private fun wc() = ViewGroup.LayoutParams.WRAP_CONTENT
    private fun fmt2(v: Float) = "%.2f".format(v)
    private fun fmt1(v: Float) = "%.1f".format(v)
    private fun fmtMx(v: Float) = (if (v >= 0) "+" else "") + "%.2f".format(v)

    companion object { fun newInstance() = SettingsSheet() }
}
