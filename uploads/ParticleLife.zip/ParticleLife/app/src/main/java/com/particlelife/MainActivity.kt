package com.particlelife

import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

class MainActivity : AppCompatActivity() {

    lateinit var simView: SimulationView
    private lateinit var tvFps:   TextView
    private lateinit var tvCount: TextView
    private lateinit var btnPause: Button
    private lateinit var speciesBar: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        hideSystemUI()
        setContentView(buildLayout())

        simView.onStats = { fps, cnt ->
            runOnUiThread {
                tvFps.text   = "FPS $fps"
                tvCount.text = "N=${cnt.toString().padStart(4)}"
                refreshSpeciesList()
            }
        }
    }

    // ── Full-screen immersive ─────────────────────────────────
    private fun hideSystemUI() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val ctrl = WindowInsetsControllerCompat(window, window.decorView)
        ctrl.hide(WindowInsetsCompat.Type.systemBars())
        ctrl.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    // ── Build layout programmatically ─────────────────────────
    private fun buildLayout(): View {
        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.rgb(8, 8, 18))
        }

        // Simulation canvas
        simView = SimulationView(this).apply {
            layoutParams = FrameLayout.LayoutParams(mp(), mp())
        }
        root.addView(simView)

        // Top HUD bar
        val hud = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity     = Gravity.CENTER_VERTICAL
            background  = roundRect(Color.parseColor("#CC090912"), dp(10),
                Color.parseColor("#1C1C30"), dp(1))
            setPadding(dp(14), dp(5), dp(14), dp(5))
            layoutParams = FrameLayout.LayoutParams(wc(), wc()).apply {
                gravity     = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                topMargin   = dp(10)
            }
        }

        // Title
        hud.addView(TextView(this).apply {
            text      = "⬡ PARTICLE LIFE"
            textSize  = 13f
            setTextColor(Color.parseColor("#58aef8"))
            typeface  = Typeface.MONOSPACE
            letterSpacing = 0.15f
        })
        hud.addView(divider())

        // FPS
        tvFps = TextView(this).apply {
            text = "FPS --"; textSize = 11f
            setTextColor(Color.parseColor("#445566"))
            typeface = Typeface.MONOSPACE
            layoutParams = LinearLayout.LayoutParams(dp(72), wc())
        }
        hud.addView(tvFps)

        // Particle count
        tvCount = TextView(this).apply {
            text = "N=----"; textSize = 11f
            setTextColor(Color.parseColor("#445566"))
            typeface = Typeface.MONOSPACE
            layoutParams = LinearLayout.LayoutParams(dp(80), wc())
        }
        hud.addView(tvCount)
        hud.addView(divider())

        // Pause button
        btnPause = hudButton("⏸") {
            simView.paused = !simView.paused
            btnPause.text  = if (simView.paused) "▶" else "⏸"
        }
        hud.addView(btnPause)

        // Reset button
        hud.addView(hudButton("↺") {
            val e = simView.engine
            synchronized(e) { e.clear(); for (s in e.species) e.spawn(s.id, s.count) }
        })

        // Settings button
        hud.addView(hudButton("⚙") {
            SettingsSheet.newInstance().show(supportFragmentManager, "settings")
        })

        root.addView(hud)

        // Species indicator bar (bottom)
        val bottomBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity     = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(4), dp(12), dp(4))
            background  = roundRect(Color.parseColor("#AA090912"), dp(8))
            layoutParams = FrameLayout.LayoutParams(wc(), wc()).apply {
                gravity      = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                bottomMargin = dp(10)
            }
        }
        speciesBar = bottomBar
        root.addView(bottomBar)

        return root
    }

    // Called from SettingsSheet and stats callback
    fun refreshSpeciesList() {
        val e = simView.engine
        val counts = HashMap<Int, Int>()
        synchronized(e) { for (p in e.particles) counts[p.sid] = (counts[p.sid] ?: 0) + 1 }
        val specCopy = synchronized(e) { e.species.toList() }

        speciesBar.removeAllViews()
        for (s in specCopy) {
            val dot = View(this).apply {
                background = roundCircle(s.color)
                layoutParams = LinearLayout.LayoutParams(dp(10), dp(10)).apply { marginEnd = dp(4) }
            }
            val lbl = TextView(this).apply {
                text = "${s.name} ${counts[s.id] ?: 0}"
                textSize = 9f; setTextColor(s.color); typeface = Typeface.MONOSPACE
                layoutParams = LinearLayout.LayoutParams(wc(), wc()).apply { marginEnd = dp(10) }
            }
            speciesBar.addView(dot); speciesBar.addView(lbl)
        }
    }

    // ── Helpers ───────────────────────────────────────────────
    private fun hudButton(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label; textSize = 16f
        setTextColor(Color.parseColor("#8899aa"))
        background = null; minWidth = dp(36); minHeight = 0
        setPadding(dp(6), dp(2), dp(6), dp(2))
        setOnClickListener { onClick() }
    }

    private fun divider() = View(this).apply {
        setBackgroundColor(Color.parseColor("#1a1a3a"))
        layoutParams = LinearLayout.LayoutParams(dp(1), dp(16)).apply {
            marginStart = dp(10); marginEnd = dp(10)
        }
    }

    private fun roundRect(fill: Int, r: Int, stroke: Int = Color.TRANSPARENT, sw: Int = 0) =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE; cornerRadius = r.toFloat(); setColor(fill)
            if (sw > 0) setStroke(sw, stroke)
        }

    private fun roundCircle(fill: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL; setColor(fill)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun mp()       = ViewGroup.LayoutParams.MATCH_PARENT
    private fun wc()       = ViewGroup.LayoutParams.WRAP_CONTENT
}
