package com.particlelife

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import kotlin.math.sqrt

class SimulationView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : SurfaceView(context, attrs), SurfaceHolder.Callback {

    val engine = ParticleEngine()

    @Volatile var paused     = false
    @Volatile var showTrails = false

    var onStats: ((fps: Int, count: Int) -> Unit)? = null

    private val paintPool  = HashMap<Int, Paint>()
    private val trailPaint = Paint().apply { color = Color.argb(52, 8, 8, 18) }
    private val bgColor    = Color.rgb(8, 8, 18)

    @Volatile private var running = false
    private var simThread: Thread? = null

    // Camera
    @Volatile private var camX    = 0f
    @Volatile private var camY    = 0f
    @Volatile private var camZoom = 1f

    // Touch tracking
    private var lastX     = 0f; private var lastY    = 0f
    private var lastDist  = 1f; private var touchMode = 0

    init { holder.addCallback(this) }

    // ── Surface lifecycle ────────────────────────────────────
    override fun surfaceCreated(h: SurfaceHolder) {
        synchronized(engine) {
            engine.resize(width.toFloat(), height.toFloat())
            if (engine.species.isEmpty()) engine.loadPreset(Presets.SWARM)
            else if (engine.particles.isEmpty())
                for (s in engine.species) engine.spawn(s.id, s.count)
        }
        running = true
        simThread = Thread(::renderLoop, "sim-thread").also { it.start() }
    }

    override fun surfaceChanged(h: SurfaceHolder, fmt: Int, w: Int, hh: Int) {
        synchronized(engine) { engine.resize(w.toFloat(), hh.toFloat()) }
    }

    override fun surfaceDestroyed(h: SurfaceHolder) {
        running = false
        try { simThread?.join(2000) } catch (_: InterruptedException) {}
    }

    // ── Render loop ──────────────────────────────────────────
    private fun renderLoop() {
        var frames  = 0
        var lastFps = System.currentTimeMillis()

        while (running) {
            val t0 = System.nanoTime()

            synchronized(engine) { if (!paused) engine.step() }

            // Snapshot for rendering (outside lock)
            val specSnap: List<Species>
            val partSnap: List<ParticleEngine.Particle>
            synchronized(engine) {
                specSnap = engine.species.toList()
                partSnap = ArrayList(engine.particles)
            }

            val canvas = try { holder.lockCanvas() } catch (_: Exception) { null }
            if (canvas != null) {
                try { drawFrame(canvas, specSnap, partSnap) }
                finally { try { holder.unlockCanvasAndPost(canvas) } catch (_: Exception) {} }
            }

            frames++
            val now = System.currentTimeMillis()
            if (now - lastFps >= 1000L) {
                val fps = frames; val cnt = partSnap.size
                post { onStats?.invoke(fps, cnt) }
                frames = 0; lastFps = now
            }

            val elapsed = System.nanoTime() - t0
            val sleep   = (16_000_000L - elapsed) / 1_000_000L
            if (sleep > 1L) Thread.sleep(sleep)
        }
    }

    // ── Draw ─────────────────────────────────────────────────
    private fun drawFrame(
        canvas: Canvas,
        specSnap: List<Species>,
        partSnap: List<ParticleEngine.Particle>
    ) {
        if (showTrails) {
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), trailPaint)
        } else {
            canvas.drawColor(bgColor)
        }

        canvas.save()
        canvas.translate(camX, camY)
        canvas.scale(camZoom, camZoom)

        // Group particles by species for batched draw
        val groups = HashMap<Int, ArrayList<ParticleEngine.Particle>>(specSnap.size * 2)
        for (s in specSnap) groups[s.id] = ArrayList()
        for (p in partSnap) groups[p.sid]?.add(p)

        for (s in specSnap) {
            val pts = groups[s.id] ?: continue
            if (pts.isEmpty()) continue
            val paint = paintPool.getOrPut(s.id) {
                Paint().apply { isAntiAlias = true; style = Paint.Style.FILL }
            }
            paint.color = s.color
            for (p in pts) canvas.drawCircle(p.x, p.y, s.size, paint)
        }
        canvas.restore()
    }

    // ── Camera ────────────────────────────────────────────────
    fun resetCamera() { camX = 0f; camY = 0f; camZoom = 1f }

    // ── Touch ─────────────────────────────────────────────────
    override fun onTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                touchMode = 1; lastX = ev.x; lastY = ev.y
            }
            MotionEvent.ACTION_POINTER_DOWN -> if (ev.pointerCount >= 2) {
                touchMode = 2
                val dx = ev.getX(1) - ev.getX(0); val dy = ev.getY(1) - ev.getY(0)
                lastDist = sqrt(dx * dx + dy * dy).coerceAtLeast(1f)
                lastX = (ev.getX(0) + ev.getX(1)) * 0.5f
                lastY = (ev.getY(0) + ev.getY(1)) * 0.5f
            }
            MotionEvent.ACTION_MOVE -> {
                if (touchMode == 1 && ev.pointerCount == 1) {
                    camX += ev.x - lastX; camY += ev.y - lastY
                    lastX = ev.x; lastY = ev.y
                } else if (touchMode == 2 && ev.pointerCount >= 2) {
                    val dx   = ev.getX(1) - ev.getX(0); val dy = ev.getY(1) - ev.getY(0)
                    val dist = sqrt(dx * dx + dy * dy).coerceAtLeast(1f)
                    val mx   = (ev.getX(0) + ev.getX(1)) * 0.5f
                    val my   = (ev.getY(0) + ev.getY(1)) * 0.5f
                    val s    = dist / lastDist
                    camX = mx - (mx - camX) * s; camY = my - (my - camY) * s
                    camZoom = (camZoom * s).coerceIn(0.05f, 20f)
                    lastDist = dist; lastX = mx; lastY = my
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> touchMode = 0
        }
        return true
    }
}
