package com.particlelife

import kotlin.math.abs
import kotlin.math.sqrt
import kotlin.random.Random

class ParticleEngine {

    data class Particle(
        @JvmField var x: Float, @JvmField var y: Float,
        @JvmField var vx: Float = 0f, @JvmField var vy: Float = 0f,
        @JvmField val sid: Int
    )

    var width  = 1000f
    var height = 600f

    val particles = ArrayList<Particle>(2000)
    val species   = ArrayList<Species>()
    val matrix    = HashMap<Int, HashMap<Int, Float>>()

    // Physics parameters
    var friction = 0.85f
    var radius   = 80f
    var beta     = 0.3f
    var forceMul = 5f
    var speed    = 1f
    var wrap     = true

    private var nextId = 0

    fun resize(w: Float, h: Float) {
        width = w; height = h
        for (p in particles) {
            p.x = p.x.coerceIn(0f, w - 1f)
            p.y = p.y.coerceIn(0f, h - 1f)
        }
    }

    // Particle Life force kernel
    private fun forceKernel(r: Float, alpha: Float): Float = when {
        r < beta -> r / beta - 1f
        r < 1f   -> alpha * (1f - abs(2f * (r - beta) / (1f - beta) - 1f))
        else     -> 0f
    }

    fun addSpecies(s: Species) {
        species.add(s)
        matrix.getOrPut(s.id) { HashMap() }
        for (o in species) {
            matrix[s.id]!!.getOrPut(o.id) { Random.nextFloat() * 2f - 1f }
            matrix.getOrPut(o.id) { HashMap() }.getOrPut(s.id) { Random.nextFloat() * 2f - 1f }
        }
    }

    fun removeSpecies(id: Int) {
        species.removeAll { it.id == id }
        particles.removeAll { it.sid == id }
        matrix.remove(id)
        matrix.values.forEach { it.remove(id) }
    }

    fun spawn(sid: Int, n: Int) {
        repeat(n) {
            particles.add(Particle(
                x   = Random.nextFloat() * width,
                y   = Random.nextFloat() * height,
                sid = sid
            ))
        }
    }

    fun clear() { particles.clear() }

    fun randomizeMatrix() {
        for (a in species) for (b in species)
            matrix.getOrPut(a.id) { HashMap() }[b.id] = Random.nextFloat() * 2f - 1f
    }

    fun loadPreset(preset: Presets.PresetData) {
        species.clear(); particles.clear(); matrix.clear()
        for (tmpl in preset.species) {
            val s = Species(nextId++, tmpl.name, tmpl.color, tmpl.size, tmpl.count)
            species.add(s)
            matrix[s.id] = HashMap()
        }
        for ((i, a) in species.withIndex())
            for ((j, b) in species.withIndex())
                matrix[a.id]!![b.id] =
                    if (i < preset.matrix.size && j < preset.matrix[i].size) preset.matrix[i][j]
                    else 0f
        for (s in species) spawn(s.id, s.count)
    }

    fun step() {
        val ps = particles
        val n  = ps.size
        if (n == 0) return

        val R  = radius; val F = friction; val FM = forceMul
        val SP = speed;  val WR = wrap;    val B  = beta
        val W  = width;  val H  = height;  val cs = R

        // Build spatial hash grid
        val grid = HashMap<Long, ArrayList<Int>>(n / 4 + 8)
        for (i in 0 until n) {
            val p  = ps[i]
            val gx = (p.x / cs).toInt()
            val gy = (p.y / cs).toInt()
            val k  = gx.toLong() shl 17 or (gy.toLong() and 0x1FFFFL)
            grid.getOrPut(k) { ArrayList(8) }.add(i)
        }

        // Accumulate forces
        val fx = FloatArray(n)
        val fy = FloatArray(n)
        for (i in 0 until n) {
            val a   = ps[i]
            val row = matrix[a.sid] ?: continue
            val gx  = (a.x / cs).toInt()
            val gy  = (a.y / cs).toInt()
            for (dgx in -1..1) for (dgy in -1..1) {
                val k    = (gx + dgx).toLong() shl 17 or ((gy + dgy).toLong() and 0x1FFFFL)
                val cell = grid[k] ?: continue
                for (ci in 0 until cell.size) {
                    val j = cell[ci]; if (j == i) continue
                    val b = ps[j]
                    var ex = b.x - a.x; var ey = b.y - a.y
                    if (WR) {
                        if (ex >  W * 0.5f) ex -= W else if (ex < -W * 0.5f) ex += W
                        if (ey >  H * 0.5f) ey -= H else if (ey < -H * 0.5f) ey += H
                    }
                    val d2 = ex * ex + ey * ey
                    if (d2 >= R * R || d2 < 0.0001f) continue
                    val d     = sqrt(d2)
                    val r     = d / R
                    val alpha = row[b.sid] ?: 0f
                    val f     = forceKernel(r, alpha)
                    fx[i] += ex / d * f
                    fy[i] += ey / d * f
                }
            }
        }

        // Apply forces, update positions, handle boundaries
        for (i in 0 until n) {
            val p = ps[i]
            p.vx = (p.vx + fx[i] * FM) * F
            p.vy = (p.vy + fy[i] * FM) * F
            p.x += p.vx * SP
            p.y += p.vy * SP
            if (WR) {
                if (p.x < 0f) p.x += W else if (p.x >= W) p.x -= W
                if (p.y < 0f) p.y += H else if (p.y >= H) p.y -= H
            } else {
                if (p.x < 0f)  { p.x = 0f;     p.vx = -p.vx * 0.5f }
                else if (p.x >= W) { p.x = W-1f; p.vx = -p.vx * 0.5f }
                if (p.y < 0f)  { p.y = 0f;     p.vy = -p.vy * 0.5f }
                else if (p.y >= H) { p.y = H-1f; p.vy = -p.vy * 0.5f }
            }
        }
    }
}
