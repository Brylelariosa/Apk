package com.particlelife

data class Species(
    val id: Int,
    var name: String,
    var color: Int,
    var size: Float = 4f,
    var count: Int = 200
)
