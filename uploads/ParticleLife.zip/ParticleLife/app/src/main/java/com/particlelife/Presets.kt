package com.particlelife

import android.graphics.Color

object Presets {

    data class SpeciesTemplate(
        val name: String, val color: Int, val count: Int = 200, val size: Float = 4f
    )

    data class PresetData(
        val name: String,
        val emoji: String,
        val desc: String,
        val species: List<SpeciesTemplate>,
        val matrix: Array<FloatArray>
    )

    private fun c(hex: String) = Color.parseColor(hex)

    val SWARM = PresetData(
        name = "Swarm", emoji = "🐝", desc = "Cyclic 3-species attraction ring",
        species = listOf(
            SpeciesTemplate("Red",   c("#ff4455"), 300),
            SpeciesTemplate("Green", c("#44ff77"), 300),
            SpeciesTemplate("Blue",  c("#4488ff"), 300)
        ),
        matrix = arrayOf(
            floatArrayOf( 0.5f, -0.3f,  0.1f),
            floatArrayOf( 0.1f,  0.5f, -0.3f),
            floatArrayOf(-0.3f,  0.1f,  0.5f)
        )
    )

    val PREDATOR_PREY = PresetData(
        name = "Predator-Prey", emoji = "🐺", desc = "Prey flees, predator hunts",
        species = listOf(
            SpeciesTemplate("Prey",     c("#44ff88"), 450),
            SpeciesTemplate("Predator", c("#ff4444"), 100)
        ),
        matrix = arrayOf(
            floatArrayOf( 0.4f, -0.95f),
            floatArrayOf( 0.8f,  0.05f)
        )
    )

    val GALAXY = PresetData(
        name = "Galaxy", emoji = "🌌", desc = "6 star types with orbital clustering",
        species = listOf(
            SpeciesTemplate("Crimson", c("#ff6b6b"), 150),
            SpeciesTemplate("Amber",   c("#ffd93d"), 150),
            SpeciesTemplate("Verdant", c("#6bcb77"), 150),
            SpeciesTemplate("Azure",   c("#4d96ff"), 150),
            SpeciesTemplate("Violet",  c("#c77dff"), 150),
            SpeciesTemplate("Blush",   c("#ff9ff3"), 150)
        ),
        matrix = arrayOf(
            floatArrayOf( 0.80f,  0.35f,  0.05f, -0.20f, -0.20f, -0.20f),
            floatArrayOf( 0.35f,  0.80f,  0.35f,  0.05f, -0.20f, -0.20f),
            floatArrayOf( 0.05f,  0.35f,  0.80f,  0.35f,  0.05f, -0.20f),
            floatArrayOf(-0.20f,  0.05f,  0.35f,  0.80f,  0.35f,  0.05f),
            floatArrayOf(-0.20f, -0.20f,  0.05f,  0.35f,  0.80f,  0.35f),
            floatArrayOf(-0.20f, -0.20f, -0.20f,  0.05f,  0.35f,  0.80f)
        )
    )

    val CELLS = PresetData(
        name = "Cells", emoji = "🔵", desc = "4 species rotational dominance",
        species = listOf(
            SpeciesTemplate("Alpha", c("#ff7777"), 220),
            SpeciesTemplate("Beta",  c("#77ff77"), 220),
            SpeciesTemplate("Gamma", c("#7777ff"), 220),
            SpeciesTemplate("Delta", c("#ffff77"), 220)
        ),
        matrix = arrayOf(
            floatArrayOf( 0.9f, -0.6f,  0.2f, -0.2f),
            floatArrayOf(-0.2f,  0.9f, -0.6f,  0.2f),
            floatArrayOf( 0.2f, -0.2f,  0.9f, -0.6f),
            floatArrayOf(-0.6f,  0.2f, -0.2f,  0.9f)
        )
    )

    val CHAOS = PresetData(
        name = "Chaos", emoji = "🌪️", desc = "6 species turbulent emergence",
        species = listOf(
            SpeciesTemplate("Alpha",   c("#ff4444"), 150),
            SpeciesTemplate("Beta",    c("#ff8844"), 150),
            SpeciesTemplate("Gamma",   c("#ffcc44"), 150),
            SpeciesTemplate("Delta",   c("#44ff44"), 150),
            SpeciesTemplate("Epsilon", c("#44ccff"), 150),
            SpeciesTemplate("Zeta",    c("#cc44ff"), 150)
        ),
        matrix = arrayOf(
            floatArrayOf( 0.8f,  0.3f, -0.5f,  0.7f, -0.3f,  0.1f),
            floatArrayOf(-0.2f,  0.8f,  0.6f, -0.4f,  0.5f, -0.7f),
            floatArrayOf( 0.5f, -0.8f,  0.8f,  0.2f, -0.6f,  0.4f),
            floatArrayOf(-0.6f,  0.4f, -0.3f,  0.8f,  0.7f, -0.5f),
            floatArrayOf( 0.3f, -0.5f,  0.8f, -0.7f,  0.8f,  0.6f),
            floatArrayOf(-0.7f,  0.6f, -0.4f,  0.3f, -0.8f,  0.8f)
        )
    )

    val ECOSYSTEM = PresetData(
        name = "Ecosystem", emoji = "🌿", desc = "Plant → Herbivore → Carnivore",
        species = listOf(
            SpeciesTemplate("Plant",     c("#44ff44"), 450),
            SpeciesTemplate("Herbivore", c("#ffcc44"), 180),
            SpeciesTemplate("Carnivore", c("#ff4444"),  60)
        ),
        matrix = arrayOf(
            floatArrayOf( 0.3f, -0.5f,  0.0f),
            floatArrayOf( 0.7f,  0.2f, -0.9f),
            floatArrayOf(-0.1f,  0.8f,  0.1f)
        )
    )

    val ALL = listOf(SWARM, PREDATOR_PREY, GALAXY, CELLS, CHAOS, ECOSYSTEM)
}
