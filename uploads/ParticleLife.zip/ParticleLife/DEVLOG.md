# PARTICLE LIFE — DEVLOG

> A browser-based artificial life sandbox where particle species interact
> through configurable attraction/repulsion rules, producing emergent behaviors
> like swarming, orbiting, predator-prey dynamics, and cellular clustering.

---

## Completed Features

### Core Engine
- [x] `Engine` class fully decoupled from rendering and UI
- [x] Spatial hash grid for O(n·k) neighbor lookup (vs naïve O(n²))
- [x] Particle Life force function — repulsion zone [0,β] + triangle attraction [β,1]
- [x] Velocity + acceleration + friction physics per particle
- [x] Wrapping (toroidal) boundary mode
- [x] Solid boundary mode (elastic bounce)
- [x] Per-step speed multiplier

### Species System
- [x] Unlimited color species with unique IDs
- [x] N×N interaction matrix (float in range [-1.0, +1.0])
- [x] Positive = attract, Negative = repel, Zero = ignore
- [x] Dynamic species add at runtime
- [x] Dynamic species remove (cleans particles + matrix rows/cols)
- [x] Custom species names, colors, particle sizes
- [x] Species count displayed in editor

### Rendering
- [x] Canvas 2D with `alpha: false` for compositor efficiency
- [x] Batched rendering per species (one `beginPath/fill` per species)
- [x] Trail effect (semi-transparent overlay each frame)
- [x] Camera zoom (scroll wheel, zooms toward cursor)
- [x] Camera pan (click + drag)
- [x] Camera reset
- [x] Live FPS counter (500ms rolling average)
- [x] Live particle count display
- [x] Notification toast for user actions

### Editor UI
- [x] **Sim tab** — playback controls, physics sliders, spawn tool, camera
- [x] **Species tab** — add/rename/recolor/resize/delete species
- [x] **Matrix tab** — visual N×N matrix, click cell to select, slider to edit
- [x] **Presets tab** — load built-in presets, export/import JSON

### Built-in Presets
- [x] **Swarm** — 3 species in cyclic attraction ring
- [x] **Predator-Prey** — prey flees, predator chases
- [x] **Galaxy** — 6 star types with orbital clustering
- [x] **Cells** — 4 species in rotational dominance pattern
- [x] **Chaos** — 6 species with sinusoidal interaction matrix
- [x] **Ecosystem** — Plant → Herbivore → Carnivore food chain

### Data & Import/Export
- [x] Export full simulation state (species + matrix + params) as JSON
- [x] Import JSON to restore any saved simulation
- [x] Preset ecosystem loading with spawn counts per species

---

## Current Bugs

| # | Description | Severity | Status |
|---|-------------|----------|--------|
| 1 | Matrix visual overflows sidebar with 8+ species (horizontal scroll shown but narrow) | Low | Open |
| 2 | Canvas cursor flickers on rapid mouse-up/leave events | Low | Open |
| 3 | Trail ghosting persists for 1 extra frame when switching trail mode off | Very Low | Open |
| 4 | Importing JSON with unknown species IDs may leave orphaned matrix keys | Low | Open |

---

## Performance Notes

### What's Fast
- Spatial grid reduces 2000-particle simulation from ~4M comparisons/frame to ~300K
- Per-species batched rendering reduces canvas state changes from n to k (species count)
- `alpha: false` canvas context skips alpha compositing in the browser compositor
- All simulation state lives in refs — no React re-renders during physics loop

### What's Slow
- `new Map()` allocated every step for the spatial grid causes GC pressure at 5000+ particles
- Large interaction radius (>150px) collapses the grid benefit back toward O(n²)
- JS single-threaded — no parallelism; force loop blocks the main thread
- `beginPath()` per species still expensive at 10+ species × 500+ particles

### Benchmarks (approximate, 1080p canvas)
| Particles | Radius | FPS |
|-----------|--------|-----|
| 500       | 80     | 60  |
| 1500      | 80     | 55  |
| 3000      | 80     | 35  |
| 1500      | 150    | 28  |

---

## Planned Features

### Near Term
- [ ] Keyboard shortcuts: Space=pause, R=reset, T=trails, 1-6=load preset
- [ ] Mobile touch support: pinch-to-zoom, two-finger pan
- [ ] Per-pair interaction visualizer (draw force curve on matrix cell hover)
- [ ] "Clear particles" button (keep species/matrix, empty canvas)
- [ ] Drag-to-spawn particles directly on canvas
- [ ] Right-click canvas context menu: spawn here, clear area
- [ ] Species population graph (stacked area chart over time)
- [ ] Collision detection option (hard-sphere, energy-conserving)
- [ ] Max velocity clamp per species
- [ ] Undo/redo stack for matrix edits

### Medium Term
- [ ] Force field overlay (vector field visualization of net forces)
- [ ] Heatmap layer (particle density over time)
- [ ] Timeline replay: record last 30s, scrub and replay
- [ ] Screenshot export (PNG with current frame)
- [ ] Per-species interaction radius (not just global)
- [ ] Environmental zones (gravity wells, temperature regions)
- [ ] Food/energy resource nodes on canvas

### Long Term
- [ ] WebGL renderer for 20,000+ particles at 60fps
- [ ] WebGPU compute shader for force calculation
- [ ] Web Worker physics thread (off-main-thread simulation)
- [ ] Video recording via `MediaRecorder` API
- [ ] Preset browser with thumbnails (generated at load time)
- [ ] Share presets via URL hash (base64-encoded JSON)

---

## Future Experiments

- **Particle evolution** — genetic algorithm on interaction matrices; fit = cluster density
- **Mutation** — small random perturbations to matrix values over time
- **Reproduction** — particles spawn offspring when energy threshold met
- **Neural behavior** — tiny NN per species decides velocity adjustments
- **Multiplayer sandbox** — WebRTC peer sharing of particle state
- **3D mode** — Three.js renderer, 3D spatial grid, spherical boundaries
- **Markov preset generator** — probabilistic transitions between preset states
- **Ecosystem simulator** — energy flows between species trophic levels

---

## Version History

### v1.0.0 — Initial Release
**Date:** 2026-06-15

**Features shipped:**
- Full simulation engine with spatial grid
- 6 curated presets (Swarm, Predator-Prey, Galaxy, Cells, Chaos, Ecosystem)
- Complete editor UI (4 tabs: Sim, Species, Matrix, Presets)
- Import/export JSON
- Camera zoom and pan
- Particle trails toggle
- Real-time physics sliders (friction, force, radius, speed, β)
- Species management (add, remove, rename, recolor, resize)
- N×N interaction matrix visual editor

---

## Optimization Log

| Date       | Change | Impact |
|------------|--------|--------|
| 2026-06-15 | Spatial hash grid (Map-based) | ~15× speedup for force calculation at n=2000 |
| 2026-06-15 | Batched canvas rendering per species | ~4× rendering speedup |
| 2026-06-15 | `canvas.getContext('2d', {alpha: false})` | Reduces compositor overhead |
| 2026-06-15 | Simulation in ref, not state | Eliminates React re-render on every frame |
| 2026-06-15 | Inline force math (no function call) | ~5% speedup in hot loop |

---

## Architecture Notes

```
Engine (class)
├── particles[]       — flat array of {x, y, vx, vy, sid}
├── species[]         — array of {id, name, color, size, count}
├── matrix{}          — nested object: matrix[sid_a][sid_b] = float [-1,1]
├── p{}               — physics params (friction, radius, beta, force, speed, wrap)
└── step()            — one simulation tick
    ├── build spatial grid (Map: key → particle indices)
    ├── for each particle: accumulate forces from neighbors
    └── update positions + boundary handling

Renderer (inline in useEffect loop)
├── fillRect (background or trail overlay)
├── camera transform (translate + scale)
└── per-species batched arc drawing

React UI (App component)
├── 4 tabs: Sim | Species | Matrix | Presets
├── All simulation state in refs (engRef, camRef, pausedRef, trailsRef)
└── UI state (species[], matrix{}, params{}) synced from engine on change
```

### Force Function
```
f(r, α):
  if r < β:       return r/β − 1              # repulsion: −1 at r=0, 0 at r=β
  if r < 1:       return α · (1 − |2(r−β)/(1−β) − 1|)  # triangle peak at r=(1+β)/2
  else:           return 0
```
- `β` (beta) — inner repulsion zone fraction of max radius (default 0.3)
- `α` (alpha) — matrix interaction value for this species pair (−1 to +1)
- Peak force magnitude = |α| at r = (1+β)/2

---

## Notes

- Species IDs are monotonically incrementing strings (`s1`, `s2`, …) assigned at definition time
- Preset species get IDs assigned when the module loads; user-added species continue the sequence
- The force function is **asymmetric**: `matrix[A][B] ≠ matrix[B][A]` by design — enables predator-prey
- With `wrap: true`, wrapping is applied to the distance vector (not particle position during force calc), then to absolute position during movement — both necessary for correct toroidal behavior
- The simulation dt is implicit (one step per frame) — vary `speed` to change temporal scale
