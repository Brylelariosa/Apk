package com.claudemanager.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.claudemanager.app.data.Account
import com.claudemanager.app.data.ActivityStatus
import com.claudemanager.app.data.Project
import com.claudemanager.app.util.ProjectTitle

/** Label shown for a status: the typed label for CUSTOM, the enum name otherwise. */
fun statusLabel(status: ActivityStatus, customLabel: String): String =
    if (status == ActivityStatus.CUSTOM && customLabel.isNotBlank()) {
        customLabel.uppercase()
    } else {
        status.name
    }

fun accountLine(account: Account): String =
    if (account.email.isBlank()) account.label else "${account.label} - ${account.email}"

/** What a list row is called: the account on top, the project's own name under it. */
fun projectTitle(project: Project, account: Account?): ProjectTitle =
    ProjectTitle.of(project.name, account?.label)

/** The name block of a list row. Shared by the project cards and the CURRENTLY ACTIVE strip. */
@Composable
fun ProjectTitleText(
    title: ProjectTitle,
    modifier: Modifier = Modifier,
    primaryStyle: TextStyle = MaterialTheme.typography.titleMedium,
    primaryWeight: FontWeight = FontWeight.Bold,
    secondaryStyle: TextStyle = MaterialTheme.typography.bodyMedium
) {
    Column(modifier) {
        Text(
            text = title.primary,
            style = primaryStyle,
            fontWeight = primaryWeight,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        title.secondary?.let { projectName ->
            Text(
                text = projectName,
                style = secondaryStyle,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun StatusDot(color: Color, dotSize: Dp = 10.dp) {
    Box(
        Modifier
            .size(dotSize)
            .clip(CircleShape)
            .background(color)
    )
}

/** The tappable status chip on every card. Tapping opens the radio list. */
@Composable
fun StatusPill(label: String, color: Color, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Row(
        modifier = Modifier
            .clip(shape)
            .background(color.copy(alpha = 0.16f))
            .border(1.dp, color.copy(alpha = 0.6f), shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        StatusDot(color, 8.dp)
        Spacer(Modifier.width(6.dp))
        // A long custom label shrinks with an ellipsis instead of pushing the buttons away.
        Text(
            text = label,
            modifier = Modifier.weight(1f, fill = false),
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(Modifier.width(4.dp))
        Text(
            text = "\u25BE",
            fontSize = 10.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun QuickButton(label: String, color: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    Box(
        modifier = modifier
            .height(32.dp)
            .widthIn(min = 52.dp)
            .clip(shape)
            .background(color.copy(alpha = 0.16f))
            .border(1.dp, color.copy(alpha = 0.55f), shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            fontWeight = FontWeight.SemiBold,
            fontSize = 12.sp,
            maxLines = 1,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
fun FilterPill(label: String, selected: Boolean, color: Color, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    val background = if (selected) color.copy(alpha = 0.22f) else Color.Transparent
    val outline = if (selected) color else MaterialTheme.colorScheme.outlineVariant
    Row(
        modifier = Modifier
            .clip(shape)
            .background(background)
            .border(1.dp, outline, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

/** Thin bar showing how much of the timer window has elapsed. */
@Composable
fun TimerBar(fraction: Float, color: Color, modifier: Modifier = Modifier, barHeight: Dp = 6.dp) {
    val shape = RoundedCornerShape(50)
    Box(
        modifier
            .fillMaxWidth()
            .height(barHeight)
            .clip(shape)
            .background(MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Box(
            Modifier
                .fillMaxHeight()
                .fillMaxWidth(fraction.coerceIn(0f, 1f))
                .background(color)
        )
    }
}

@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    Text(
        text = text,
        modifier = modifier,
        style = MaterialTheme.typography.labelMedium,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}

/** Green chip for an account that has no project, so a free account is easy to spot. */
@Composable
fun IdleBadge(modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(50)
    Text(
        text = "IDLE",
        modifier = modifier
            .clip(shape)
            .background(ResetGreen.copy(alpha = 0.16f))
            .border(1.dp, ResetGreen.copy(alpha = 0.6f), shape)
            .padding(horizontal = 10.dp, vertical = 3.dp),
        style = MaterialTheme.typography.labelMedium,
        fontWeight = FontWeight.Bold,
        color = ResetGreen
    )
}
