package com.voxelsandbox.game.creative

import com.voxelsandbox.game.world.BlockType

/**
 * Draws the creative inventory's icon of a block, [SIZE] x [SIZE] ARGB pixels, straight from the block's
 * own 16 x 16 textures so an icon can never disagree with the block in the world.
 *
 * - Solid blocks are drawn as a small isometric cube (2:1 pixel-art projection): top face, left face, right
 *   face, each sampled 1:1 from its texture (a 16 x 16 face is 16 x 16 icon pixels, no resampling blur) and
 *   shaded the way the world shades faces. Leaves keep their holes, filled with the dark inside of the block.
 * - Water is a translucent cube with a few lighter wave pixels (its own texture is one flat colour).
 * - Plants are drawn flat, their 16 x 16 sprite enlarged exactly 2x with no smoothing.
 *
 * No smoothing anywhere: every pixel of an icon is a texel of the real texture or a shade of one.
 * Pure Kotlin so it runs in unit tests; the UI turns the result into a bitmap.
 */
object BlockIcons {
    const val SIZE = 32
    private const val TILE = 16

    /** Face shading of the cube: the top is lit, the left a little darker, the right darkest. */
    private const val SHADE_TOP = 1.00f
    private const val SHADE_LEFT = 0.80f
    private const val SHADE_RIGHT = 0.62f

    /** The inside of a leaf block seen through its holes, relative to the face it is seen through. */
    private const val HOLE_DARKNESS = 0.32f

    private const val WATER_ALPHA = 205
    private const val WATER_RGB = 0x3C74CE // the water tile's colour
    private const val SEAGRASS_BACKDROP_ALPHA = 120

    /**
     * The icon of [block] using [tileOf] to fetch the tile (atlas cell -> 16 x 16 ARGB pixels) of each
     * texture, or null when a texture the block needs does not exist (the catalogue reports that as a
     * problem; no placeholder is drawn in its place).
     */
    fun render(block: BlockType, tileOf: (Int) -> IntArray?): IntArray? {
        if (block == BlockType.AIR) return null
        return if (block.plant) renderSprite(block, tileOf) else renderCube(block, tileOf)
    }

    // ---- sprites (plants) --------------------------------------------------------------------

    private fun renderSprite(block: BlockType, tileOf: (Int) -> IntArray?): IntArray? {
        val tile = tileOf(block.topCell) ?: return null
        if (tile.size != TILE * TILE) return null
        val out = IntArray(SIZE * SIZE)
        // Seagrass only exists under water: a faint blue backdrop says so (its dark blades alone vanish on a panel).
        val backdrop = if (block == BlockType.SEAGRASS) (SEAGRASS_BACKDROP_ALPHA shl 24) or WATER_RGB else 0
        val scale = SIZE / TILE
        for (y in 0 until SIZE) {
            for (x in 0 until SIZE) {
                val c = tile[(y / scale) * TILE + (x / scale)]
                out[y * SIZE + x] = if ((c ushr 24) >= 128) c or (0xFF shl 24) else backdrop
            }
        }
        return if (isEmpty(out)) null else out
    }

    // ---- cubes -------------------------------------------------------------------------------

    private fun renderCube(block: BlockType, tileOf: (Int) -> IntArray?): IntArray? {
        val top = tileOf(block.topCell) ?: return null
        val side = tileOf(block.sideCell) ?: return null
        if (top.size != TILE * TILE || side.size != TILE * TILE) return null
        val water = block == BlockType.WATER
        val holeTop = if (block.cutout) darkFill(top) else 0
        val holeSide = if (block.cutout) darkFill(side) else 0
        val out = IntArray(SIZE * SIZE)
        val h = SIZE / 2f // half the cube's width: the top diamond's half width
        val q = SIZE / 4f // the top diamond's half height
        for (py in 0 until SIZE) {
            val cy = py + 0.5f
            for (px in 0 until SIZE) {
                val cx = px + 0.5f
                var color = 0
                // Top face: the diamond around (h, q).
                if (Math.abs(cx - h) / h + Math.abs(cy - q) / q <= 1f) {
                    val s = ((cx - h) / h + cy / q) * 0.5f
                    val t = (cy / q - (cx - h) / h) * 0.5f
                    color = sample(top, s, t, SHADE_TOP, holeTop)
                    if (water) color = waterTop(color, (s * TILE).toInt(), (t * TILE).toInt())
                } else if (cx < h) {
                    // Left face: its top edge runs from (0, q) down to (h, 2q).
                    val v = cy - (q + cx * 0.5f)
                    if (v >= 0f && v < h) color = sample(side, cx / h, v / h, SHADE_LEFT, holeSide)
                } else {
                    // Right face: its top edge runs from (h, 2q) up to (SIZE, q).
                    val v = cy - (q * 3f - cx * 0.5f)
                    if (v >= 0f && v < h) color = sample(side, (cx - h) / h, v / h, SHADE_RIGHT, holeSide)
                }
                if (water && color != 0) color = (WATER_ALPHA shl 24) or (color and 0xFFFFFF)
                out[py * SIZE + px] = color
            }
        }
        applyRim(out)
        return if (isEmpty(out)) null else out
    }

    /** The texel at fractional face coordinates ([u], [v] in 0..1), shaded by [shade]; a transparent texel
     *  becomes [hole] (0 = stays see-through). */
    private fun sample(tile: IntArray, u: Float, v: Float, shade: Float, hole: Int): Int {
        val tx = (u * TILE).toInt().coerceIn(0, TILE - 1)
        val ty = (v * TILE).toInt().coerceIn(0, TILE - 1)
        val c = tile[ty * TILE + tx]
        if ((c ushr 24) < 128) return if (hole != 0) scale(hole, shade) else 0
        return scale(c or (0xFF shl 24), shade)
    }

    /** What the inside of a leaf block looks like through its holes: the tile's average colour, dark. */
    private fun darkFill(tile: IntArray): Int {
        var r = 0L
        var g = 0L
        var b = 0L
        var n = 0
        for (c in tile) {
            if ((c ushr 24) < 128) continue
            r += (c shr 16) and 0xFF
            g += (c shr 8) and 0xFF
            b += c and 0xFF
            n++
        }
        if (n == 0) return 0xFF101010.toInt()
        return scale(rgb((r / n).toInt(), (g / n).toInt(), (b / n).toInt()), HOLE_DARKNESS)
    }

    /** A few lighter wave pixels on the top of the (otherwise single-coloured) water cube. */
    private fun waterTop(color: Int, tx: Int, ty: Int): Int {
        if (color == 0) return 0
        val wave = ((tx + ty * 3) % 11 == 0) || ((tx * 2 + ty) % 13 == 5 && ty % 2 == 0)
        return if (wave) lighten(color, 0.22f) else color
    }

    /**
     * Gives the silhouette a 1 pixel rim so a dark block stays readable on the dark panel and a bright one
     * on a bright slot: pixels on the upper left edge are lightened, those on the lower right darkened.
     */
    private fun applyRim(px: IntArray) {
        val copy = px.copyOf()
        fun solid(x: Int, y: Int): Boolean =
            x in 0 until SIZE && y in 0 until SIZE && (copy[y * SIZE + x] ushr 24) != 0
        for (y in 0 until SIZE) {
            for (x in 0 until SIZE) {
                val c = copy[y * SIZE + x]
                if ((c ushr 24) == 0) continue
                val openAbove = !solid(x, y - 1)
                val openLeft = !solid(x - 1, y)
                val openBelow = !solid(x, y + 1)
                val openRight = !solid(x + 1, y)
                if (!(openAbove || openLeft || openBelow || openRight)) continue
                px[y * SIZE + x] = if (openBelow || openRight) scale(c, 0.72f) else lighten(c, 0.20f)
            }
        }
    }

    private fun isEmpty(px: IntArray): Boolean {
        for (c in px) if ((c ushr 24) != 0) return false
        return true
    }

    private fun rgb(r: Int, g: Int, b: Int): Int = (0xFF shl 24) or (r shl 16) or (g shl 8) or b

    /** Multiplies the colour channels by [f], keeping alpha. */
    private fun scale(c: Int, f: Float): Int {
        val r = (((c shr 16) and 0xFF) * f).toInt().coerceIn(0, 255)
        val g = (((c shr 8) and 0xFF) * f).toInt().coerceIn(0, 255)
        val b = ((c and 0xFF) * f).toInt().coerceIn(0, 255)
        return (c and (0xFF shl 24)) or (r shl 16) or (g shl 8) or b
    }

    /** Moves the colour channels [f] of the way to white, keeping alpha. */
    private fun lighten(c: Int, f: Float): Int {
        val r = ((c shr 16) and 0xFF).let { (it + (255 - it) * f).toInt().coerceIn(0, 255) }
        val g = ((c shr 8) and 0xFF).let { (it + (255 - it) * f).toInt().coerceIn(0, 255) }
        val b = (c and 0xFF).let { (it + (255 - it) * f).toInt().coerceIn(0, 255) }
        return (c and (0xFF shl 24)) or (r shl 16) or (g shl 8) or b
    }
}
