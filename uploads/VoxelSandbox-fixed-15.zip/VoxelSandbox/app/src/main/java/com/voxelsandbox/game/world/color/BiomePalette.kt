package com.voxelsandbox.game.world.color

import com.voxelsandbox.game.gl.BlockTextures
import com.voxelsandbox.game.gl.TileSources
import com.voxelsandbox.game.world.AtlasCell

/**
 * The colours the ground cover of the world is drawn in, one per climate, in 0..255 per channel.
 *
 * They are not chosen here: each is the average colour of the block texture that stands for that climate
 * (the lime of plain grass, the straw of dry grass, the olive of swamp grass), read from the same tiles the
 * texture atlas is built from. So in the middle of a plain, a savanna or a swamp the colour field says
 * exactly what the texture already looks like, and the world looks as it always did there; the field only
 * has something new to say in between. The distant terrain reads the same palette, which is what makes a
 * hillside the same colour from far away as it is up close.
 *
 * [cold] is the cool, bluish green of the grass of a taiga and of high ground: plain grass with its red
 * taken down and its blue raised ([COLD_SHIFT]).
 */
class BiomePalette(
    val grassR: Float, val grassG: Float, val grassB: Float,
    val dryR: Float, val dryG: Float, val dryB: Float,
    val swampR: Float, val swampG: Float, val swampB: Float
) {
    /** Cool grass: [grass] times [COLD_SHIFT] per channel. */
    val coldR: Float = grassR * COLD_SHIFT_R
    val coldG: Float = grassG * COLD_SHIFT_G
    val coldB: Float = grassB * COLD_SHIFT_B

    companion object {
        /** How plain grass is shifted towards the cold colour (red, green, blue factors). */
        const val COLD_SHIFT_R = 0.86f
        const val COLD_SHIFT_G = 0.92f
        const val COLD_SHIFT_B = 1.40f

        /** The palette of the game's own tiles. */
        fun fromTiles(): BiomePalette {
            fun mean(cell: Int): IntArray {
                val c = BlockTextures.averageColor(TileSources.requirePixels(cell))
                return intArrayOf((c shr 16) and 0xFF, (c shr 8) and 0xFF, c and 0xFF)
            }
            val grass = mean(AtlasCell.GRASS_TOP)
            val dry = mean(AtlasCell.DRY_GRASS_TOP)
            val swamp = mean(AtlasCell.SWAMP_GRASS_TOP)
            return BiomePalette(
                grass[0].toFloat(), grass[1].toFloat(), grass[2].toFloat(),
                dry[0].toFloat(), dry[1].toFloat(), dry[2].toFloat(),
                swamp[0].toFloat(), swamp[1].toFloat(), swamp[2].toFloat()
            )
        }
    }
}
