package com.voxelsandbox.game.gl

/**
 * Per-frame values the render passes share. GameRenderer fills one instance in place
 * each frame (no per-frame allocation) and hands it to the passes, so a pass never has to
 * be told about fog, camera or time one uniform at a time.
 */
class FrameState {
    /** Combined view-projection matrix of the pass being drawn (a copy, see GameRenderer). */
    val viewProj = FloatArray(16)

    var eyeX = 0f
    var eyeY = 0f
    var eyeZ = 0f

    /** Camera-relative rendering. [originX]..[originZ] is the whole-block position of the eye (exact
     *  in float32 however far from the world origin the player is), and [viewProj] was built for an
     *  eye at ([eyeRelX], [eyeRelY], [eyeRelZ]) = eye - origin, i.e. within one block of (0, 0, 0).
     *  Every vertex shader subtracts the origin from the world position it is given, so the sums
     *  inside the matrix product stay small and exact (see Shaders, top). Anything compared against
     *  world coordinates on the CPU (frustum boxes, distances) keeps using [eyeX]..[eyeZ]. */
    var originX = 0f
    var originY = 0f
    var originZ = 0f
    var eyeRelX = 0f
    var eyeRelY = 0f
    var eyeRelZ = 0f

    /** Where the biome colour map (see BiomeColorMap) is read: texture coordinates are
     *  `x_relative_to_origin * biomeScale + biomeU / biomeV` (one value per axis). */
    var biomeU = 0f
    var biomeV = 0f
    var biomeScale = 0f

    // Camera basis (unit vectors) and field of view, for the sky gradient.
    var forwardX = 0f
    var forwardY = 0f
    var forwardZ = -1f
    var rightX = 1f
    var rightY = 0f
    var rightZ = 0f
    var upX = 0f
    var upY = 1f
    var upZ = 0f

    /** tan(vertical fov / 2) and the same times the aspect ratio. */
    var tanHalfFovY = 0.7f
    var tanHalfFovX = 1.2f

    var fogR = 0f
    var fogG = 0f
    var fogB = 0f
    var fogStart = 0f
    var fogEnd = 0f

    /** Seconds, wrapped every [TEXTURE_TIME_PERIOD] so float precision never degrades;
     *  drives the clouds and the flow of running water. */
    var textureTime = 0f

    /** The water pattern for this frame (see WaterAnimation): which frame of the wave loop shows, the
     *  camera origin modulo the wave tile along each axis (what keeps the pattern fixed to the world),
     *  and the same for the large-scale tone texture along X and Z (that one also drifts slowly). */
    var waterLayer = 0f
    var waterPhaseX = 0f
    var waterPhaseY = 0f
    var waterPhaseZ = 0f
    var tonePhaseX = 0f
    var tonePhaseZ = 0f

    /** The hand-over from voxel terrain to distant terrain (see [Handover]), measured from the eye:
     *  the voxel terrain starts dissolving [fadeStart] blocks away and is gone [fadeWidth] further out
     *  (a [fadeWidth] of 0 means no dissolve and no distant terrain behind it). The distant ground
     *  stands behind the dissolving terrain from [fadeStart] outwards, and inside it only fills the
     *  chunk columns that have no terrain yet (see [CoverageMask]). */
    var fadeStart = 0f
    var fadeWidth = 0f

    /** Radius around the eye inside which the voxel terrain is certainly complete and opaque: whole
     *  distant-terrain tiles within it are not drawn at all. */
    var clipRadius = 0f

    /** Radius around the eye inside which every chunk column is known to have its terrain (so
     *  there is no hole to fill); [clipRadius] is this, limited to where the dissolve begins. */
    var provenRadius = 0f

    companion object {
        /** The period the texture clock wraps at. Every rate that is driven by it (the frames of the water
         *  animation, the flow of running water, the drift of the water's tone patches, the clouds) completes
         *  a whole number of cycles in it, so nothing visibly jumps when the clock wraps (see WaterAnimation
         *  and the unit tests that check each of them). */
        const val TEXTURE_TIME_PERIOD = 1000.0
    }
}
