package com.voxelsandbox.game.world.far

/**
 * The vertex of a distant land mesh: six floats, and what each one carries.
 *
 *  - 0..2  position (world X, Y, Z);
 *  - 3     the colour of the vertex, 0xRRGGBB, with the brightness of its face already applied;
 *  - 4     the colour it slides to as its level's ring ends (what the next coarser level paints at that point);
 *  - 5     the height it slides to.
 *
 * The vertex shader blends all three towards their targets by the same amount, a function of the vertex's
 * distance from the player (see Shaders.FAR_VERTEX), so a level looks, at the end of its ring, exactly like the
 * level that takes over from it: same shape, same colour, same brightness. A face that does not slide (the
 * coarsest level's) simply names its own colour and height again.
 *
 * Every colour is an integer below 2^24, which a float holds exactly, so nothing is rounded on the way.
 */
internal object FarVertex {
    /** Floats per vertex (see [FarLevels.LAND_FLOATS]). */
    const val FLOATS = FarLevels.LAND_FLOATS

    /** The colour [rgb] (0xRRGGBB) as it is stored in a vertex, a float. */
    fun colorOf(rgb: Int): Float = rgb.toFloat()

    /** The colour (0xRRGGBB) a vertex slot holds. */
    fun rgbOf(slot: Float): Int = slot.toInt()

    /** The colour [rgb] under the brightness [shade] (0..1, 1 = unchanged), each channel rounded to the nearest. */
    fun shaded(rgb: Int, shade: Float): Int {
        if (shade >= 1f) return rgb
        val r = (((rgb shr 16) and 0xFF) * shade + 0.5f).toInt()
        val g = (((rgb shr 8) and 0xFF) * shade + 0.5f).toInt()
        val b = ((rgb and 0xFF) * shade + 0.5f).toInt()
        return (r shl 16) or (g shl 8) or b
    }
}
