package com.voxelsandbox.game.world.far

import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/**
 * Which part of the picture each level of the distant terrain is responsible for: a ring around the player per
 * level, from [FarLevels.ringOuter] of the level before to its own. The edges are exact distances from the eye,
 * cut with the same formula in the shader of every level, so neighbouring levels partition the ground without a
 * seam or an overlap (see FarTerrainRenderer); the tile planner builds, for each level, the tiles that touch its ring.
 *
 * The finest ring (level 0) is the exception: it is optional and thin, laid just behind the voxel terrain wherever
 * that currently ends ([configureFineRing]), so its edges move, and level 1, which is always built from the player
 * outwards, stands in for it wherever it is missing.
 */
internal object FarRings {
    /** Width of the finest ring. A step-2 column is four times the triangles per block of the next level, so the
     *  ring is kept thin: its job is the first stretch behind the voxel terrain, where the dissolve needs a good
     *  backdrop. */
    private const val FINE_RING_WIDTH = 56f
    private const val FINE_MIN_START = 96f

    @Volatile private var fineIn = 0f
    @Volatile private var fineOut = 0f

    /**
     * Places the thin finest ring (level 0) just behind the voxel area, or takes it away ([allowed] = false, e.g.
     * while the adaptive-distance governor is saving work). [voxelFadeStart] is where the voxel terrain begins to
     * dissolve. The ring only moves when that changes by a good margin, so it does not make tiles come and go.
     */
    fun configureFineRing(voxelFadeStart: Float, allowed: Boolean) {
        if (!allowed || voxelFadeStart < FINE_MIN_START) {
            fineOut = 0f
            return
        }
        val raw = voxelFadeStart - 8f
        if (fineOut > 0f && abs(raw - fineIn) < 40f) return
        val a0 = max(0f, floor(raw / 32f) * 32f)
        val a1 = min(a0 + FINE_RING_WIDTH, FarLevels.ringOuter(1) - 96f)
        if (a1 - a0 < 24f) {
            fineOut = 0f
            return
        }
        fineIn = a0
        fineOut = a1
    }

    fun fineInner(): Float = fineIn
    fun fineOuter(): Float = fineOut

    /** Inner edge of the area a level's tiles are built for. Level 1 is always built from the player outwards: it
     *  is the ground that shows (the ring of level 0 aside) and the stand-in for level 0 whenever the voxel area
     *  is not loaded yet. */
    fun planInner(level: Int): Float = when (level) {
        0 -> fineIn
        1 -> 0f
        else -> FarLevels.ringOuter(level - 1)
    }

    /** Where a level is drawn from. (Level 1 also covers the ring that level 0 improves; the renderer takes that
     *  ring out of it, per tile, once the level-0 tiles for it are on the GPU.) */
    fun drawInner(level: Int): Float = planInner(level)

    /** Exact outer edge of a level's ring (the next level starts there). */
    fun drawOuter(level: Int): Float = if (level == 0) fineOut else FarLevels.ringOuter(level)

    /** Distance from the player at which a level starts sliding to its parent's shape and colours. */
    fun morphStart(level: Int): Float = drawOuter(level) - FarLevels.morphWidth(level)
}
