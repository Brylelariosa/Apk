package com.voxelsandbox.game.world.far

import com.voxelsandbox.game.world.WorldConfig

/**
 * The ladder of levels of the distant terrain, as plain tables: how many columns a tile has along an edge, how wide
 * a column is, which detail setting of the terrain generator a level samples, how coarsely its heights are
 * rounded, where its ring of the picture begins and ends, and the few heights that every mesher agrees on (the
 * surface of the sea, the top of a block, how deep soil is). Pure data, no state: the builders of the columns
 * ([FarColumnMesher]) and of the water ([FarWaterMesher]) all read the same numbers from here, so a tile and the
 * tile of the next level (which its vertices slide to, see [FarTerrain]) are built on the same grid.
 *
 * Every step is a power of two and the grids are aligned, so the columns of one level are exactly 2 x 2 of the
 * level below it.
 *
 * The look is the one of the voxel world, kept all the way out: every level is made of blocky columns, only wider
 * with distance (the "bricks" of Distant Horizons, which this ladder is modelled on), and each ring is as wide as
 * its columns can be while they still stay a few pixels across (see [RING_OUTER]), so a distant mountain is a
 * stack of small bricks and not a handful of huge boxes.
 */
internal object FarLevels {
    /** Number of levels (0 = finest). */
    const val COUNT = 8

    /** Most columns along a tile edge. */
    const val MAX_CELLS = 64

    /** Floats per vertex of the land meshes: position (3), colour (1), the colour it slides to (1) and the height
     *  it slides to (1); see [FarVertex]. */
    const val LAND_FLOATS = 6

    /** Real trees stand on the ground of the levels below this; the coarser ones raise forested ground into a
     *  canopy instead. */
    const val TREE_LEVELS = 2
    const val CANOPY_FROM_LEVEL = 2

    /** Columns along a tile edge, per level. Fine levels have small tiles (a thin ring does not waste triangles
     *  on ground it never draws); the coarse ones have few columns because beyond a kilometre a column is a
     *  handful of pixels, and what a weak GPU chokes on is the *number of triangles* of the distant terrain. */
    private val LEVEL_CELLS = intArrayOf(32, 64, 64, 32, 32, 32, 32, 32)

    /** Column size per level, in blocks. */
    private val LEVEL_STEP = intArrayOf(2, 4, 8, 16, 32, 64, 128, 256)

    /** The terrain generator's detail setting per level (see TerrainShape.height): the finest levels keep the
     *  voxel world's full shape, the coarse ones drop the features that sparse sampling would only alias. */
    private val LEVEL_LOD = intArrayOf(0, 0, 1, 2, 2, 3, 3, 3)

    /** Far-terrain slopes are measured over a coarser baseline than the voxel terrain's, which smooths them;
     *  these gains restore the rock / scree coverage the voxel generator would give, so a mountainside keeps
     *  its colour with distance. */
    private val SLOPE_GAIN = floatArrayOf(1.0f, 1.2f, 1.5f, 1.9f, 2.4f, 3.4f, 4.4f, 5.6f)

    /** The step, in blocks, that the heights of a level are rounded to (see [snapHeight]): about one pixel of
     *  the picture at the level's inner edge, so the rounding is a texture and not a shape. Neighbouring columns
     *  that round to the same height merge into one flat top, which is most of what keeps a wide ring cheap. */
    private val HEIGHT_QUANTUM = intArrayOf(1, 1, 1, 2, 4, 8, 16, 32)

    /**
     * Outer edge of each level's ring around the player, in blocks. Entry 0 is a placeholder: the finest ring is
     * placed just behind the voxel area (see [FarRings.configureFineRing]). The last level has no outer edge (it
     * reaches the render distance).
     *
     * Every ring ends at twice the distance the previous one did, and its columns are twice as wide, so a column
     * is about the same size on screen wherever a level is looked at (128 to 256 columns fit between the eye and
     * the ring's end): the detail of the picture is the same at every distance, and every doubling of the render
     * distance adds the same number of columns.
     */
    private val RING_OUTER = floatArrayOf(0f, 512f, 1024f, 2048f, 4096f, 8192f, 16384f, 1.0e9f)

    /** How far in from its outer edge each level starts sliding to the next coarser level's shape and colours. */
    private val MORPH_WIDTH = floatArrayOf(32f, 96f, 200f, 400f, 800f, 1600f, 3200f, 0f)

    fun cellsOf(level: Int): Int = LEVEL_CELLS[level]
    fun step(level: Int): Int = LEVEL_STEP[level]
    fun lodOf(level: Int): Int = LEVEL_LOD[level]
    fun slopeGain(level: Int): Float = SLOPE_GAIN[level]
    fun heightQuantum(level: Int): Int = HEIGHT_QUANTUM[level]
    fun ringOuter(level: Int): Float = RING_OUTER[level]
    fun morphWidth(level: Int): Float = MORPH_WIDTH[level]

    /** Tile edge in blocks: 64, 256, 512, 512, 1024, 2048, 4096, 8192. */
    fun tileBlocks(level: Int): Int = LEVEL_CELLS[level] * LEVEL_STEP[level]

    /** Short names for the on-screen statistics and the diagnostic log. */
    fun levelName(level: Int): String = when (level) {
        0 -> "LOD1"
        1 -> "LOD2"
        2 -> "LOD3"
        3 -> "far16"
        4 -> "far32"
        5 -> "far64"
        6 -> "far128"
        else -> "far256"
    }

    /** Voxel water surfaces sit at SEA_LEVEL + 0.875 (see ChunkMesher). */
    const val WATER_Y = WorldConfig.SEA_LEVEL + 0.875f

    /** True for every level but the coarsest, whose columns slide to those of the next coarser level at the end
     *  of their ring; the coarsest has nothing to slide to. */
    fun hasParent(level: Int): Boolean = level < COUNT - 1

    /** Land vertices of the columns sit this far above the top block's floor: exactly at the voxel top face (+1).
     *  A column is then as high as the block it stands for, the shore falls where the voxel shore does (ground at
     *  sea level is land, ground below it is under water exactly as deep as the voxel water is), and distant ground
     *  that fills in for a chunk which has not loaded yet is not a hair lower than the chunks around it. */
    const val LAND_Y_OFFSET = 1.0f

    /** How deep the soil of a column is: the top block and the three layers of dirt the generator puts under it. */
    const val SOIL_DEPTH = 4f

    /** Water at least this deep is drawn (near-)opaque, so ground beneath it is skipped. */
    const val DEEP_WATER = 10f

    /** Ground within this many blocks above the sea keeps its exact height at every level: the shore, whose
     *  position must not move with the level (it would show as the coast creeping in and out as the rings change). */
    const val SHORE_BAND = 4

    /**
     * The height a column of [level] is drawn at for a ground height of [h] blocks: land more than [SHORE_BAND]
     * above the sea is rounded to a multiple of the level's [heightQuantum] (counted up from the top of the shore
     * band, so the rounding never moves the coast), everything else is exact.
     */
    fun snapHeight(level: Int, h: Int): Int {
        val q = HEIGHT_QUANTUM[level]
        val base = WorldConfig.SEA_LEVEL + SHORE_BAND
        if (q == 1 || h <= base) return h
        return base + Math.floorDiv(h - base + (q shr 1), q) * q
    }

    /** Ground below this height is not built for a level at all. Water is at least ~90 % opaque in a slanted view
     *  through 3.5 blocks of it, and drawn solid beyond 300 blocks (see the water shader), so only the finest ring
     *  needs the sea floor in full; coarser levels keep just the shore. This is also what keeps seabed steps from
     *  ever outlining themselves through the surface. */
    fun landFloor(level: Int): Float = when (level) {
        0 -> WATER_Y - DEEP_WATER
        1 -> WATER_Y - 3.5f
        else -> WATER_Y - 0.9f
    }
}
