package com.voxelsandbox.game.ui

import android.content.res.Resources
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import com.voxelsandbox.game.creative.BlockIcons
import com.voxelsandbox.game.gl.TileSources
import com.voxelsandbox.game.world.BlockType

/**
 * Turns [BlockIcons] pixels into drawables for the creative inventory and the hotbar. Each icon is
 * enlarged by a whole number (nearest neighbour, never smoothed) chosen so it fills about the requested
 * size, which keeps every icon pixel the same size on screen; the drawable is exactly that many pixels, so
 * the ImageView needs no scaling of its own. Main thread only; a bitmap is built once per block and size.
 */
class BlockIconCache(private val resources: Resources) {
    private val density = resources.displayMetrics.density
    private val bitmaps = HashMap<Int, Bitmap?>()

    /** The whole-number enlargement of the [BlockIcons.SIZE]-pixel icon that is closest to [dp]. */
    fun scaleFor(dp: Float): Int = Math.max(1, Math.round(dp * density / BlockIcons.SIZE))

    /**
     * The icon of [block] enlarged [scale] times, or null if the block has no icon. Every call returns a
     * drawable of its own (over one shared bitmap): a drawable instance holds the bounds of the one view
     * it is shown in, so two views must not share one.
     */
    fun drawable(block: BlockType, scale: Int): Drawable? {
        val key = (block.id.toInt() shl 8) or scale
        val bitmap = if (bitmaps.containsKey(key)) {
            bitmaps[key]
        } else {
            val px = BlockIcons.render(block) { TileSources.pixelsFor(it) }
            val made = px?.let { toBitmap(it, scale) }
            bitmaps[key] = made
            made
        }
        return bitmap?.let { BitmapDrawable(resources, it).apply { setFilterBitmap(false) } }
    }

    private fun toBitmap(px: IntArray, scale: Int): Bitmap {
        val size = BlockIcons.SIZE
        val w = size * scale
        val out = IntArray(w * w)
        for (y in 0 until w) {
            val srcRow = (y / scale) * size
            val dstRow = y * w
            for (x in 0 until w) out[dstRow + x] = px[srcRow + x / scale]
        }
        return Bitmap.createBitmap(out, w, w, Bitmap.Config.ARGB_8888)
    }
}
