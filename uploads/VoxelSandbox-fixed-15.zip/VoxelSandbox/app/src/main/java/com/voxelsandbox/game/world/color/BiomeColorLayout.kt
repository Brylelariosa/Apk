package com.voxelsandbox.game.world.color

import kotlin.math.floor

/**
 * How the colour field is laid out in the GPU's colour map (see gl/BiomeColorMap), as plain arithmetic so that
 * a unit test can check it without a GL context: a square of [TEXELS] x [TEXELS] texels holds the field in
 * tiles ([BiomeColorTiles.TILE] texels square); the tile (tx, tz) lives in slot (tx mod [TILES], tz mod [TILES]),
 * so the map is a torus that always holds the [TILES] x [TILES] tiles around the eye, whichever they are.
 * One texel stands for `spacing` x `spacing` blocks and holds the field at the centre of that cell.
 */
object BiomeColorLayout {
    const val TILES = 16
    const val TEXELS = TILES * BiomeColorTiles.TILE
    const val MIN_SPACING = 4

    /**
     * Blocks per texel needed for a voxel area of [radiusBlocks] around the eye: the smallest power of two (from
     * [MIN_SPACING]) whose torus reaches that far with two tiles of margin to spare (one for the bilinear
     * footprint, one for the tile the eye is in being only partly around it).
     */
    fun spacingFor(radiusBlocks: Float): Int {
        var s = MIN_SPACING
        while ((TILES / 2 - 2) * BiomeColorTiles.TILE * s < radiusBlocks && s < 1024) s *= 2
        return s
    }

    /** The tile (along one axis) that holds the world coordinate [w]. */
    fun tileOf(w: Double, spacing: Int): Int = floor(w / (BiomeColorTiles.TILE * spacing)).toInt()

    /** The slot (index into the [TILES] x [TILES] grid, row-major) the tile ([tx], [tz]) lives in. */
    fun slot(tx: Int, tz: Int): Int = Math.floorMod(tz, TILES) * TILES + Math.floorMod(tx, TILES)

    /** The texel (x, z) of a place [wx], [wz]: where a nearest-neighbour read of the map would look. */
    fun texelX(wx: Double, spacing: Int): Int = Math.floorMod(floor(wx / spacing).toInt(), TEXELS)

    /** What the shader adds to `(position - eye origin) / worldSize` so that texture coordinates address the
     *  torus by world position: the fractional part of `origin / worldSize`, from a whole-block [origin]. */
    fun frameOffset(origin: Float, spacing: Int): Float {
        val v = origin.toDouble() / worldSize(spacing)
        return (v - floor(v)).toFloat()
    }

    /** The torus is `TEXELS * spacing` blocks wide. */
    fun worldSize(spacing: Int): Double = spacing.toDouble() * TEXELS

    fun inverseWorldSize(spacing: Int): Float = (1.0 / worldSize(spacing)).toFloat()

    /**
     * The whole map as the GL class would hold it after every tile within [radiusTiles] of the eye's tile has
     * arrived: RGBA bytes, row-major, [TEXELS] x [TEXELS] (slots not covered keep the neutral colour). For
     * tests and for the rendering rig, which has no worker thread to wait for.
     */
    fun fullTexture(field: BiomeColorField, eyeX: Double, eyeZ: Double, spacing: Int, radiusTiles: Int): ByteArray {
        val out = ByteArray(TEXELS * TEXELS * 4)
        val n = field.neutral
        for (i in 0 until TEXELS * TEXELS) {
            out[i * 4] = (n shr 16).toByte(); out[i * 4 + 1] = (n shr 8).toByte(); out[i * 4 + 2] = n.toByte(); out[i * 4 + 3] = -1
        }
        val etx = tileOf(eyeX, spacing)
        val etz = tileOf(eyeZ, spacing)
        val rgb = IntArray(BiomeColorTiles.TILE * BiomeColorTiles.TILE)
        val scratch = DoubleArray(1)
        for (tz in etz - radiusTiles..etz + radiusTiles) for (tx in etx - radiusTiles..etx + radiusTiles) {
            BiomeColorTiles.compute(field, tx, tz, spacing, rgb, scratch)
            val sx = Math.floorMod(tx, TILES) * BiomeColorTiles.TILE
            val sz = Math.floorMod(tz, TILES) * BiomeColorTiles.TILE
            for (j in 0 until BiomeColorTiles.TILE) for (i in 0 until BiomeColorTiles.TILE) {
                val c = rgb[j * BiomeColorTiles.TILE + i]
                val o = ((sz + j) * TEXELS + sx + i) * 4
                out[o] = (c shr 16).toByte(); out[o + 1] = (c shr 8).toByte(); out[o + 2] = c.toByte(); out[o + 3] = -1
            }
        }
        return out
    }
}
