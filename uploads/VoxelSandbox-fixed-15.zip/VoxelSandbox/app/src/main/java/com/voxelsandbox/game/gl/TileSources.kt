package com.voxelsandbox.game.gl

import com.voxelsandbox.game.world.AtlasCell

/**
 * Every block texture of the game in one table: which atlas cell it lives in, its 16 x 16 pixels, and
 * whether it repeats seamlessly (so the atlas may fill the gutter around it with its own pattern).
 *
 * The atlas ([TextureAtlas]) copies these tiles into its grid and the creative inventory
 * ([com.voxelsandbox.game.creative.BlockIcons]) draws its icons from them, so what the player sees in a
 * menu is by construction the texture the block has in the world. Plain Kotlin, no Android classes: it runs
 * in a unit test as well as on the phone.
 */
object TileSources {
    /** One 16 x 16 texture: [pixels] are ARGB, row-major, [CELL_PX] x [CELL_PX]. Treat as read-only. */
    class Tile(val cell: Int, val name: String, val pixels: IntArray, val wrap: Boolean)

    /** All tiles, built once (about 36 small arrays) the first time anything asks. */
    val tiles: List<Tile> by lazy { build() }

    private val byCell: Map<Int, Tile> by lazy { tiles.associateBy { it.cell } }

    /** The pixels of the tile in atlas cell [cell], or null when no texture is drawn for that cell. */
    fun pixelsFor(cell: Int): IntArray? = byCell[cell]?.pixels

    /** Like [pixelsFor] for cells that must exist (the atlas builder's own references). */
    fun requirePixels(cell: Int): IntArray =
        pixelsFor(cell) ?: throw IllegalStateException("no tile is drawn for atlas cell $cell")

    private fun build(): List<Tile> {
        val out = ArrayList<Tile>(40)
        // Tiles that are periodic by construction wrap into their gutter; the rest extend their edge.
        fun add(cell: Int, name: String, pixels: IntArray, wrap: Boolean = false) {
            out.add(Tile(cell, name, pixels, wrap))
        }
        add(AtlasCell.GRASS_TOP, "grass_top", BlockTextures.grassTop(), true)
        add(AtlasCell.GRASS_SIDE, "grass_side", BlockTextures.grassSide())
        add(AtlasCell.DIRT, "dirt", BlockTextures.dirt(), true)
        add(AtlasCell.STONE, "stone", BlockTextures.stone(), true)
        add(AtlasCell.SAND, "sand", BlockTextures.sand(), true)
        add(AtlasCell.OAK_BARK, "oak_bark", BlockTextures.oakBark(), true)
        add(AtlasCell.OAK_RINGS, "oak_rings", BlockTextures.oakRings())
        add(AtlasCell.OAK_LEAVES, "oak_leaves", BlockTextures.oakLeaves(), true)
        add(AtlasCell.COAL_ORE, "coal_ore", BlockTextures.coalOre())
        add(AtlasCell.WATER, "water", BlockTextures.water(), true)
        add(AtlasCell.WHITE, "white", BlockTextures.white(), true)
        add(AtlasCell.BIRCH_BARK, "birch_bark", BlockTextures.birchBark(), true)
        add(AtlasCell.BIRCH_LEAVES, "birch_leaves", BlockTextures.birchLeaves(), true)
        add(AtlasCell.SPRUCE_LEAVES, "spruce_leaves", BlockTextures.spruceLeaves(), true)
        add(AtlasCell.SPRUCE_BARK, "spruce_bark", BlockTextures.spruceBark(), true)
        add(AtlasCell.BIRCH_RINGS, "birch_rings", BlockTextures.birchRings())
        add(AtlasCell.SPRUCE_RINGS, "spruce_rings", BlockTextures.spruceRings())
        add(AtlasCell.SNOW, "snow", BlockTextures.snow(), true)
        add(AtlasCell.SNOW_SIDE, "snow_side", BlockTextures.snowSide())
        add(AtlasCell.GRAVEL, "gravel", BlockTextures.gravel(), true)
        add(AtlasCell.SANDSTONE_SIDE, "sandstone_side", BlockTextures.sandstoneSide())
        add(AtlasCell.SANDSTONE_TOP, "sandstone_top", BlockTextures.sandstoneTop(), true)
        add(AtlasCell.DRY_GRASS_TOP, "dry_grass_top", BlockTextures.dryGrassTop(), true)
        add(AtlasCell.DRY_GRASS_SIDE, "dry_grass_side", BlockTextures.dryGrassSide())
        add(AtlasCell.TALL_GRASS, "tall_grass", BlockTextures.tallGrass())
        add(AtlasCell.POPPY, "poppy", BlockTextures.poppy())
        add(AtlasCell.DANDELION, "dandelion", BlockTextures.dandelion())
        add(AtlasCell.DEAD_BUSH, "dead_bush", BlockTextures.deadBush())
        add(AtlasCell.CACTUS_SIDE, "cactus_side", BlockTextures.cactusSide())
        add(AtlasCell.CACTUS_TOP, "cactus_top", BlockTextures.cactusTop())
        add(AtlasCell.LILY_PAD, "lily_pad", BlockTextures.lilyPad())
        add(AtlasCell.SEAGRASS_A, "seagrass_short", BlockTextures.seagrassShort())
        add(AtlasCell.SEAGRASS_B, "seagrass_tall", BlockTextures.seagrassTall())
        add(AtlasCell.SWAMP_GRASS_TOP, "swamp_grass_top", BlockTextures.swampGrassTop(), true)
        add(AtlasCell.SWAMP_GRASS_SIDE, "swamp_grass_side", BlockTextures.swampGrassSide())
        add(AtlasCell.DEEP_STONE, "deep_stone", BlockTextures.deepStone(), true)
        return out
    }
}
