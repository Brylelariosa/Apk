package com.voxelsandbox.game.gl

import android.opengl.GLES30
import android.os.Handler
import android.os.Looper
import com.voxelsandbox.game.engine.GameEngine
import com.voxelsandbox.game.player.Raycaster
import com.voxelsandbox.game.world.ChunkPos
import com.voxelsandbox.game.world.ChunkRing
import com.voxelsandbox.game.world.Fluid
import com.voxelsandbox.game.diag.DiagLog
import com.voxelsandbox.game.world.WorldConfig
import com.voxelsandbox.game.world.far.FarTerrain
import com.voxelsandbox.game.world.mesh.MeshData
import com.voxelsandbox.game.world.streaming.ColumnKeys
import java.util.Arrays
import java.util.Locale
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

/**
 * All GL work lives here and only here — GameEngine (physics/streaming/inventory) is
 * completely GL-agnostic, so this class's job is: call engine.update(dt), move
 * finished background work (mesh uploads, unloads) onto the GPU, and draw.
 *
 * Frame-cost levers (all visually lossless unless noted):
 *  - far plane == fog end: everything at/after fog end is 100% fog colour (== clear
 *    colour), so clipping it changes nothing on screen, but the CPU frustum test then
 *    also skips every column past it;
 *  - back-face culling (see ChunkMesher for the winding fix that makes it safe);
 *  - opaque and alpha-tested geometry are separate draws: the bulk of the terrain is drawn
 *    by a fragment shader with no `discard` (so the GPU may reject hidden pixels early),
 *    and only leaves and plants pay for alpha testing, afterwards; plants are single
 *    quads drawn with culling off instead of two quads each;
 *  - columns drawn front-to-back so the depth test rejects hidden fragments early;
 *  - tight per-column culling boxes (real min/max terrain height, not 0..64);
 *  - mesh uploads arrive pre-packed from the streaming threads (the concatenation that used to run
 *    here is done off the GL thread), prioritised by how soon the region is needed, and budgeted
 *    per frame in bytes and time (see RegionGpuStore and WorkBudget);
 *  - the view distance is never shortened to save frame time: the work budgets adapt instead;
 *  - distant terrain tiles (few, large, cheap, several levels of detail) instead of voxel
 *    chunks past the detail radius, clipped in the shader so they never overdraw the
 *    chunks that cover that area (see FarTerrainRenderer);
 *  - two depth ranges: distant terrain is drawn first with a far larger near plane (so its
 *    depth precision stays excellent out to thousands of blocks), then the depth buffer is
 *    cleared and the voxel world is drawn over it with the usual tight near plane.
 *
 * Pass order per frame: sky -> distant land -> distant water -> clouds -> [clear depth] ->
 * voxel terrain (opaque, then leaves, then plants) -> voxel water -> block outline ->
 * particles -> laser (-> clouds, when there is no distant-terrain pass to draw them in).
 *
 * Where the voxel area ends, the voxel terrain dissolves (an ordered-noise screen door, see
 * VoxelShader.opaqueFade) into the distant terrain drawn behind it, instead of
 * stopping in a hard line.
 *
 * Voxel chunk meshes are batched per REGION of 4x4 chunk columns (one GPU buffer, one draw
 * call): on the phones this game targets the cost of a frame is dominated by the number of
 * draw calls, not the number of triangles.
 */
class GameRenderer(
    private val engine: GameEngine,
    /** Invoked ~2-3x/sec on the main thread regardless of the FPS-counter setting
     *  (the HUD uses every tick to refresh the hotbar); the string argument is the
     *  formatted FPS/debug text when showFps is on, or null when it's off. */
    private val onPeriodicTick: (String?) -> Unit
) : android.opengl.GLSurfaceView.Renderer {

    /** When true, onDrawFrame keeps rendering the last state (so the world stays
     *  visible, frozen, behind a menu overlay) but stops calling engine.update —
     *  set by GameActivity whenever a menu is shown over active gameplay. */
    @Volatile var paused = false

    private val atlas = engine.atlas

    /** The biome colour field as a texture around the eye (see BiomeColorMap). */
    private val biomeMap = BiomeColorMap(engine.biomeColors)
    // The three programs that draw voxel-chunk geometry (see Shaders and TerrainProgram).
    private lateinit var terrainOpaque: TerrainProgram
    private lateinit var terrainOpaqueFade: TerrainProgram
    private lateinit var terrainCutout: TerrainProgram

    // The other render passes; each owns its own program and GPU objects.
    private val sky = SkyRenderer()
    private val water = WaterRenderer()
    private val far = FarTerrainRenderer()
    private val frame = FrameState()
    private val startNanos = System.nanoTime()

    private val camera = Camera()
    private val frustum = Frustum()
    private var aspect = 1f

    // The GPU buffers of the voxel terrain, one per REGION of 4x4 chunk columns (one draw call for
    // up to sixteen columns), and the set of columns that are on screen. The data arrives packed
    // from the streaming threads (WorldManager.readyRegions).
    private val gpuRegions = RegionGpuStore()

    // How far the full-detail chunks around the player are really complete (in chunks, measured from
    // the centre of the chunk the player is in), and how far (blocks, from that centre) the voxel area
    // reaches once everything wanted is loaded: the edge the voxel terrain dissolves towards. Rescanned
    // every frame from the coverage mask (see updateNearCoverage).
    private var nearCoveredChunks = 0f
    private var nearEdgeBlocks = 0f
    private var nearCenterX = 0f
    private var nearCenterZ = 0f

    /** Where the voxel terrain hands over to the distant terrain, and how far the fog reaches. */
    private val handover = Handover()

    private val particleMesh = ChunkGpuMesh()
    private val highlightMesh = ChunkGpuMesh()
    private val laserMesh = ChunkGpuMesh()
    private val clouds = CloudRenderer()

    private var highlightValid = false
    private var highlightX = 0
    private var highlightY = 0
    private var highlightZ = 0
    private var highlightShape = 0 // 0 = whole block, 1 = plant, 2 = flat plant (lily pad)

    private val laserFloats = FloatArray(8 * 6)
    private val laserIndices = intArrayOf(0, 1, 2, 0, 2, 3, 4, 5, 6, 4, 6, 7)

    private var particleFloats = FloatArray(0)
    private var particleIndices = IntArray(0)
    private var particleVerts = 0
    private var particleIdx = 0

    // Draw list scratch (visible columns sorted front-to-back), reused every frame.
    private var sortKeys = LongArray(512)
    private var sortMeshes = arrayOfNulls<ChunkGpuMesh>(512)
    private var sortFade = BooleanArray(512) // parallel to sortMeshes: region touches the dissolve rim
    private var waterSortKeys = LongArray(128)
    private var waterSortMeshes = arrayOfNulls<ChunkGpuMesh>(128)

    // Frame stats (shown in the FPS overlay).
    private var lastFrameTimeNanos = 0L
    private var fpsAccumTime = 0f
    private var fpsAccumFrames = 0
    private var currentFps = 0f
    private var statWorstDt = 0f
    private var statCpuAccumMs = 0f
    private var statCpuMaxMs = 0f
    private var statUploadAccumNs = 0L

    /** Time the chunk-region uploads took this frame, and how many frames in a row the distant tiles have
     *  stood back for them (see [drainFarUploads]). */
    private var lastRegionUploadNs = 0L
    private var farWaitedFrames = 0
    private var statDrawnCols = 0
    private var statTotalCols = 0
    private var statTris = 0
    private var statWaterTris = 0
    private val mainHandler = Handler(Looper.getMainLooper())

    companion object {
        // Camera inside a water block: short blue fog instead of the sky colour.
        private const val UNDERWATER_FOG_START = 2f
        private const val UNDERWATER_FOG_END = 26f

        // A distant tile is a big mesh (up to 64x64 columns, ~1.6 MB), so tiles are uploaded under a byte and time
        // budget (see drainFarUploads) instead of a fixed number per frame: at least this many bytes per frame, and
        // never more than this many frames in a row postponed for the chunk uploads.
        private const val FAR_MIN_UPLOAD_BYTES = 400_000
        private const val FAR_MAX_WAIT_FRAMES = 2

        /**
         * Chunk columns per side of one batched region (4 -> 4x4 columns = 64x64 blocks). The
         * GL thread's frame time is dominated by the driver cost of draw calls and buffer binds
         * (hundreds of calls with the old 2x2 regions); a region is one buffer and about three
         * calls however many columns it holds, so bigger regions cut the call count about
         * fourfold. The price is coarser frustum culling and a bigger re-upload when one column
         * changes, which the debounce in drainMeshUploads absorbs.
         */
        private const val REGION_SIZE = ColumnKeys.REGION_SIZE

        /** Longest the cloud layer reaches from the eye, however far the fog is (the 3 x 3 tiles
         *  of the cloud mesh cover at least one tile, 2048 blocks, in every direction). */
        private const val MAX_CLOUD_RADIUS = 2000f

        /** Plants (tall grass, flowers, seagrass, lily pads) are only drawn this close: beyond
         *  it they are a pixel or two, and skipping them saves a draw call per region and
         *  a lot of alpha-tested overdraw in meadows. Trees (leaves) are drawn at any distance. */
        private const val PLANT_DRAW_DISTANCE = 120f

        /** Length of the drawn laser beam (matches GameEngine's laser range). */
        private const val LASER_LENGTH = 96f

        /** Near plane for the voxel world: close enough to stand against a wall. */
        private const val NEAR_PLANE = 0.15f

        /** Blocks the biome colour map reaches past the edge of the voxel area. */
        private const val BIOME_MAP_MARGIN = 64f
    }

    /** True when the voxel-terrain programs use the pixel-exact atlas lookup (see [VoxelShader]),
     *  which needs the atlas bound with its trilinear sampler ([bindVoxelAtlas]). */
    private var crispAtlas = true

    /**
     * Builds the three voxel-terrain programs with the pixel-exact atlas lookup. If a driver ever
     * rejects that shader, all three fall back to the plain lookup (and the texture's own sampling
     * state), so the game still starts, with its textures as they were before.
     */
    private fun buildTerrainPrograms() {
        val tint = TintTable.shaderTable(engine.biomeColors.palette)
        try {
            terrainOpaque = TerrainProgram(VoxelShader.VERTEX, VoxelShader.opaque(true), tint)
            terrainOpaqueFade = TerrainProgram(VoxelShader.VERTEX, VoxelShader.opaqueFade(true), tint)
            terrainCutout = TerrainProgram(VoxelShader.VERTEX, VoxelShader.cutout(true), tint)
            crispAtlas = true
        } catch (e: RuntimeException) {
            android.util.Log.w("GameRenderer", "pixel-exact atlas sampling rejected, using the plain shaders: " + e.message)
            DiagLog.note("pixel-exact atlas sampling was rejected by the driver; using the plain texture lookup")
            terrainOpaque = TerrainProgram(VoxelShader.VERTEX, VoxelShader.opaque(false), tint)
            terrainOpaqueFade = TerrainProgram(VoxelShader.VERTEX, VoxelShader.opaqueFade(false), tint)
            terrainCutout = TerrainProgram(VoxelShader.VERTEX, VoxelShader.cutout(false), tint)
            crispAtlas = false
        }
    }

    /** Binds the block atlas for the voxel-terrain programs (unit 0). */
    private fun bindVoxelAtlas() {
        if (crispAtlas) atlas.bindFiltered(0) else atlas.bind(0)
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        buildTerrainPrograms()

        sky.init()
        water.init()
        far.init()
        clouds.init()

        atlas.uploadToGL()
        biomeMap.create()

        GLES30.glEnable(GLES30.GL_DEPTH_TEST)
        GLES30.glDepthFunc(GLES30.GL_LEQUAL)
        // Every terrain face is wound counter-clockwise as seen from outside (see
        // ChunkMesher), so back faces can be dropped before rasterization.
        GLES30.glEnable(GLES30.GL_CULL_FACE)
        GLES30.glCullFace(GLES30.GL_BACK)
        GLES30.glFrontFace(GLES30.GL_CCW)
        GLES30.glClearColor(Atmosphere.HORIZON_R, Atmosphere.HORIZON_G, Atmosphere.HORIZON_B, 1f)

        // The context (and any GPU handles in it) may have just been recreated
        // (e.g. after backgrounding) while world/chunk state persisted — drop our
        // now-invalid mesh handles and ask WorldManager to re-pack everything it
        // still has loaded (its CPU-side meshes are intact) so the terrain reappears
        // instead of staying blank.
        // particle/cloud/highlight are long-lived instances reused across frames, so
        // each needs telling explicitly that its old handles no longer mean anything.
        gpuRegions.invalidateForContextLoss()
        particleMesh.invalidateForContextLoss()
        highlightMesh.invalidateForContextLoss()
        laserMesh.invalidateForContextLoss()
        highlightValid = false
        far.invalidateForContextLoss()
        gpuRegions.coverage.init() // after the invalidation above, which forgets the old texture
        handover.reset()
        engine.farTerrain.invalidateAll()
        engine.worldManager.remeshAllLoaded()
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES30.glViewport(0, 0, width, height)
        aspect = if (height > 0) width.toFloat() / height.toFloat() else 1f
    }

    override fun onDrawFrame(gl: GL10?) {
        DiagLog.frame()
        val now = System.nanoTime()
        val dt = if (lastFrameTimeNanos == 0L) 0.016f else ((now - lastFrameTimeNanos) / 1_000_000_000f).coerceIn(0f, 0.1f)
        lastFrameTimeNanos = now

        if (!paused) engine.update(dt)
        engine.worldManager.reportFrameTime(dt * 1000f)
        drainUnloads()
        drainMeshUploads(engine.player.eyeX(), engine.player.eyeZ(), engine.player.yaw)
        drainFarUploads()

        val p = engine.player
        val eyeX = p.eyeX()
        val eyeY = p.eyeY() + engine.bobOffset
        val eyeZ = p.eyeZ()
        // Underwater = the eye is inside a water cell AND below that water's surface. How high the
        // surface sits depends on how full the cell is (see Fluid.heightOf), so an eye in the top
        // sliver of a cell, or in a shallow trickle, is already above it.
        val eyeBlockX = floor(eyeX).toInt()
        val eyeBlockY = floor(eyeY).toInt()
        val eyeBlockZ = floor(eyeZ).toInt()
        val eyeWater = Fluid.amountOf(engine.world.getRaw(eyeBlockX, eyeBlockY, eyeBlockZ))
        val underwater = eyeWater > 0 &&
            (eyeY - eyeBlockY < Fluid.heightOf(eyeWater) ||
                Fluid.amountOf(engine.world.getRaw(eyeBlockX, eyeBlockY + 1, eyeBlockZ)) > 0)

        val settings = engine.settings
        val farOn = settings.farTerrain

        // Automatic Render Distance. With the setting off this is a no-op and every number below is
        // exactly what the player selected; with it on, the governor decides how much of the selected
        // distance is worth drawing right now (it only keeps a reduction that measurably helps).
        val governor = engine.distanceGovernor
        val selectedBlocks = settings.renderDistanceChunks * WorldConfig.CHUNK_SIZE.toFloat()
        governor.update(dt, settings.autoRenderDistance, !paused && !underwater && !engine.player.waitingForSpawn, selectedBlocks)

        // What is on the GPU, for the shaders (the distant terrain and the water fill exactly the columns
        // the voxel terrain does not have) and for the scan below.
        gpuRegions.coverage.flush()
        gpuRegions.coverage.bind()
        updateNearCoverage(eyeX, eyeZ, settings.nearChunks())

        // The fog may only reach as far as there is actually something behind it: the contiguous area
        // covered by finished chunk meshes (and, if enabled, distant terrain tiles), capped by the
        // chosen render distance. That is what keeps not-yet-loaded ground from ever showing as a
        // hole in the world: it simply sits in the fog until it arrives. The fog grows smoothly, holds
        // still through a dip that does not last and closes in smoothly when one does (see Handover).
        val renderBlocks = governor.effectiveBlocks(selectedBlocks)
        val farPass = farOn && !underwater
        val eyeOffset = hypot(eyeX - nearCenterX, eyeZ - nearCenterZ)
        // The edge is fixed by the chosen detail distance: with Automatic Render Distance off it never
        // moves in and out with the frame rate. With the setting on, and only while the governor has
        // measured that pulling the view in pays off (a block of voxel terrain costs roughly ten times
        // the triangles of the distant terrain behind it), the voxel area shrinks with it, and only once
        // the distant terrain is proven to exist all the way out there. With the setting off the factor
        // is exactly 1.
        handover.update(
            dt, farOn, farPass, renderBlocks, nearEdgeBlocks, eyeOffset, nearCoveredChunks,
            engine.farTerrain.coveredRadiusBlocks, governor.detailFactor()
        )

        val fogEnd: Float
        val fogStart: Float
        val fogR: Float
        val fogG: Float
        val fogB: Float
        if (underwater) {
            fogEnd = UNDERWATER_FOG_END
            fogStart = UNDERWATER_FOG_START
            fogR = Atmosphere.UNDERWATER_R; fogG = Atmosphere.UNDERWATER_G; fogB = Atmosphere.UNDERWATER_B
        } else {
            // The fog reaches as far as the terrain that is really there (and the render distance in
            // use: the selected one, or less while Automatic Render Distance is on and has found
            // that pulling the view in pays off). Nothing else ever shortens it: slow streaming is
            // what the work budgets (uploads, worker threads) are for.
            fogEnd = max(24f, handover.fogCover * 0.95f)
            fogStart = fogEnd * 0.6f
            fogR = Atmosphere.HORIZON_R; fogG = Atmosphere.HORIZON_G; fogB = Atmosphere.HORIZON_B
        }

        GLES30.glClearColor(fogR, fogG, fogB, 1f)
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)

        // ---- shared per-frame state -------------------------------------------------------
        // The voxel terrain dissolves into the distant terrain over the last stretch before the edge of
        // the area it covers (Handover.fadeStart .. edge, around the eye): the distant mesh is drawn
        // behind the voxel terrain from fadeStart outwards, and the voxel terrain gets sparser until it is
        // gone at the edge. Inside fadeStart the distant ground is drawn only where a chunk column has no
        // terrain yet (the coverage mask), which is what fills a chunk that is still loading.
        // The finest ring of the distant terrain (LOD 1) sits just behind where the voxel terrain starts
        // to dissolve. It is placed from the nominal edge, whether or not the player is under water, so
        // it does not move (and tiles do not come and go) when diving.
        FarTerrain.configureFineRing(handover.ringReference, farOn && governor.fineRingAllowed())
        fillFrameState(eyeX, eyeY, eyeZ, p.yaw, p.pitch, fogR, fogG, fogB, fogStart, fogEnd)
        // The biome colour map covers the voxel area (its edge plus the dissolve width and a little more).
        biomeMap.update(eyeX.toDouble(), eyeZ.toDouble(), nearEdgeBlocks + BIOME_MAP_MARGIN)
        frame.biomeU = biomeMap.frameOffsetU(frame.originX)
        frame.biomeV = biomeMap.frameOffsetV(frame.originZ)
        frame.biomeScale = biomeMap.inverseWorldSize()
        biomeMap.bind()

        val cloudRadius = min(fogEnd * 0.92f, MAX_CLOUD_RADIUS)
        // Clouds are split between the two depth ranges by distance: everything at least this far
        // from the eye is drawn in the distant-terrain pass, the rest in the voxel pass (see
        // CloudRenderer.draw). Without a distant-terrain pass the voxel pass draws them all.
        val cloudSplit = if (farPass) max(0f, handover.fadeStart - 20f) else Float.MAX_VALUE
        if (!underwater) sky.draw(frame)

        // ---- pass 1: distant terrain, in its own depth range --------------------------------
        // Nothing here is closer than the edge of the voxel-covered circle, so the near plane
        // can sit far out; that keeps the depth buffer precise even 3000+ blocks away. (Safe
        // limit: see Handover.farNearPlane.)
        // (Anything at or beyond fogEnd is already 100% fog colour == the horizon colour, so
        // putting the far plane just past it removes nothing visible.)
        if (farPass) {
            atlas.bind(0) // the far-terrain colour ramp lives in the block atlas (nearest-sampled)
            applyProjection(handover.farNearPlane, fogEnd + 1f, p.yaw, p.pitch)
            far.drawLand(frame, frustum)
            water.begin(frame)
            far.drawWater(frame, frustum, water)
            water.end()
            // Clouds are drawn here, in the distant-terrain depth range (its far plane reaches the
            // fog), so they are depth-tested against the far land and never clipped early.
            if (settings.cloudsEnabled) clouds.draw(frame, cloudRadius, cloudSplit, Float.MAX_VALUE)
            // The voxel world is always in front of distant terrain, so it may simply be
            // drawn over it with fresh depth values.
            GLES30.glClear(GLES30.GL_DEPTH_BUFFER_BIT)
        } else {
            far.clearStats()
        }

        // ---- pass 2: the voxel world --------------------------------------------------------
        val voxelFar = if (farPass) min(fogEnd, settings.nearChunks() * WorldConfig.CHUNK_SIZE + 40f) else fogEnd
        applyProjection(NEAR_PLANE, voxelFar + 1f, p.yaw, p.pitch)

        bindVoxelAtlas()
        GLES30.glEnable(GLES30.GL_CULL_FACE)
        drawChunks(eyeX, eyeZ, farPass)
        statWaterTris = 0
        if (!underwater) drawNearWater(eyeX, eyeZ, farPass)
        // The overlay passes below (outline, particles, laser) use the alpha-tested program,
        // without the rim dissolve.
        terrainCutout.use(frame.viewProj, frame, false)
        bindVoxelAtlas()
        drawHighlight()

        // Particle cubes and the laser beam aren't wound for culling: draw them as-is.
        GLES30.glDisable(GLES30.GL_CULL_FACE)
        if (engine.settings.particlesEnabled) drawParticles()
        if (engine.laserActive) drawLaser(eyeX, eyeY, eyeZ)
        if (!underwater && settings.cloudsEnabled) clouds.draw(frame, cloudRadius, 0f, cloudSplit)

        // Leave no VAO bound between frames. (Mesh uploads now bind their own VAO, but
        // stale bindings are exactly how the old corruption bug crept in.)
        GLES30.glBindVertexArray(0)

        val cpuMs = (System.nanoTime() - now) / 1_000_000f
        updateFps(dt, cpuMs, underwater)
        DiagLog.glCheck("frame")
    }

    /** Sets the camera for one depth range and mirrors the result into [frame] and [frustum]. The
     *  eye is the camera-relative one (see [FrameState.originX]); [fillFrameState] must have run. */
    private fun applyProjection(nearPlane: Float, farPlane: Float, yaw: Float, pitch: Float) {
        camera.nearPlane = nearPlane
        // The fog distance can briefly lag behind the (immediately updated) voxel coverage while
        // the world is loading; never let the far plane fall to or below the near plane.
        camera.farPlane = max(farPlane, nearPlane + 1f)
        camera.setPerspective(aspect)
        camera.updateView(frame.eyeRelX, frame.eyeRelY, frame.eyeRelZ, yaw, pitch)
        System.arraycopy(camera.viewProjMatrix, 0, frame.viewProj, 0, 16)
        frustum.update(frame.viewProj, frame.originX, frame.originY, frame.originZ)
    }

    private fun fillFrameState(
        eyeX: Float, eyeY: Float, eyeZ: Float, yaw: Float, pitch: Float,
        fogR: Float, fogG: Float, fogB: Float, fogStart: Float, fogEnd: Float
    ) {
        frame.eyeX = eyeX
        frame.eyeY = eyeY
        frame.eyeZ = eyeZ
        // Whole-block origin (exact in float32) and the eye relative to it, see FrameState.
        frame.originX = floor(eyeX)
        frame.originY = floor(eyeY)
        frame.originZ = floor(eyeZ)
        frame.eyeRelX = eyeX - frame.originX
        frame.eyeRelY = eyeY - frame.originY
        frame.eyeRelZ = eyeZ - frame.originZ

        // Camera basis; see Camera.updateView for the convention (yaw 0 looks down -Z).
        val cp = cos(pitch)
        val sp = sin(pitch)
        val cy = cos(yaw)
        val sy = sin(yaw)
        frame.forwardX = cp * sy
        frame.forwardY = sp
        frame.forwardZ = -cp * cy
        frame.rightX = cy
        frame.rightY = 0f
        frame.rightZ = sy
        frame.upX = -sy * sp
        frame.upY = cp
        frame.upZ = cy * sp
        val tanHalf = tan(Math.toRadians(camera.fovYDegrees.toDouble()) / 2.0).toFloat()
        frame.tanHalfFovY = tanHalf
        frame.tanHalfFovX = tanHalf * aspect

        frame.fogR = fogR
        frame.fogG = fogG
        frame.fogB = fogB
        frame.fogStart = fogStart
        frame.fogEnd = fogEnd

        val seconds = (System.nanoTime() - startNanos) / 1_000_000_000.0
        val wrapped = seconds % FrameState.TEXTURE_TIME_PERIOD
        frame.textureTime = wrapped.toFloat()
        WaterAnimation.fill(frame, wrapped)

        frame.fadeStart = handover.fadeStart
        frame.fadeWidth = handover.fadeWidth
        frame.clipRadius = handover.clipRadius
        frame.provenRadius = handover.provenRadius
    }

    // ---- Streaming hand-off (background threads -> GPU) ---------------------------

    /**
     * Hands whatever the streaming threads have packed to the driver, within this frame's budget
     * (bytes and time, set by WorldManager's work budget from the recent frame times). The regions
     * come in the order they are needed: player edits first, then by distance and by how much they
     * are in front of the camera, with a region that has nothing on screen yet counting as closer
     * than a re-upload of one that has.
     */
    private fun drainMeshUploads(eyeX: Float, eyeZ: Float, yaw: Float) {
        val startNs = System.nanoTime()
        val wm = engine.worldManager
        val uploaded = gpuRegions.drain(
            wm.readyRegions, wm.bufferPool, eyeX, eyeZ,
            sin(yaw), -cos(yaw),
            wm.uploadBytesPerFrame(), wm.uploadNanosPerFrame(), startNs
        )
        val uploadNs = System.nanoTime() - startNs
        lastRegionUploadNs = uploadNs
        statUploadAccumNs += uploadNs
        if (uploaded > 0 && DiagLog.isActive()) DiagLog.upload(DiagLog.UP_CHUNK, uploaded, uploadNs / 1_000_000f)
    }

    /**
     * Uploads finished distant-terrain tiles. They share the frame's upload budget with the chunk regions (a
     * tile is a copy of up to ~1.6 MB, a region up to a few MB): they get what the regions left of the frame's
     * time, half of its bytes and never less than a fifth of its time, and when the regions used it all they wait
     * a frame or two, never more than [FAR_MAX_WAIT_FRAMES] in a row, so neither can starve the other.
     */
    private fun drainFarUploads() {
        val wm = engine.worldManager
        val startNs = System.nanoTime()
        val frameBudgetNs = wm.uploadNanosPerFrame()
        val leftNs = frameBudgetNs - lastRegionUploadNs
        if (leftNs <= 0L && farWaitedFrames < FAR_MAX_WAIT_FRAMES && engine.farTerrain.events.isNotEmpty()) {
            farWaitedFrames++
            return
        }
        farWaitedFrames = 0
        val bytes = max(FAR_MIN_UPLOAD_BYTES, wm.uploadBytesPerFrame() / 2)
        val nanos = max(frameBudgetNs / 5, leftNs)
        val uploaded = far.drain(engine.farTerrain.events, bytes, nanos, startNs)
        if (uploaded > 0) {
            val ns = System.nanoTime() - startNs
            statUploadAccumNs += ns
            if (DiagLog.isActive()) DiagLog.upload(DiagLog.UP_FAR, uploaded, ns / 1_000_000f)
        }
    }

    private fun packColumn(cx: Int, cz: Int): Long = ColumnKeys.column(cx, cz)

    private fun drainUnloads() {
        while (true) {
            val pos = engine.worldManager.pendingUnloads.poll() ?: break
            // The region is re-packed without this column by the streaming threads; until that
            // arrives the column no longer counts as covered.
            gpuRegions.forgetColumn(packColumn(pos.x, pos.z))
        }
    }

    // ---- Distant terrain & coverage ---------------------------------------------------

    /** Walks the chunks around the player nearest-first and finds the first one with no
     *  finished mesh; everything closer than that is guaranteed to be on screen. It reads the
     *  coverage mask (a plain byte array), so it costs no allocation and is cheap enough to run
     *  every frame, which keeps the numbers derived from it in step with the eye. */
    private fun updateNearCoverage(eyeX: Float, eyeZ: Float, nearRadius: Int) {
        val chunk = WorldConfig.CHUNK_SIZE
        val cx = Math.floorDiv(floor(eyeX).toInt(), chunk)
        val cz = Math.floorDiv(floor(eyeZ).toInt(), chunk)
        val mask = gpuRegions.coverage
        val limit = engine.worldManager.maxLoadedChunks // read once: the budget can change under memory pressure
        val offsets = ChunkRing.offsets(nearRadius, limit)
        val cap = min(offsets.size, limit)
        var covered = -1f
        for (i in 0 until cap) {
            val o = offsets[i]
            if (!mask.isCovered(cx + o[0], cz + o[1])) {
                covered = sqrt((o[0] * o[0] + o[1] * o[1]).toFloat())
                break
            }
        }
        if (covered < 0f) {
            val last = offsets[max(0, cap - 1)]
            covered = sqrt((last[0] * last[0] + last[1] * last[1]).toFloat())
        }
        nearCoveredChunks = covered
        // Where the voxel area ends once everything wanted is loaded: the farthest chunk of the
        // ring (the memory budget may cut it short of the chosen distance) plus half a chunk.
        val edge = offsets[max(0, cap - 1)]
        nearEdgeBlocks = (sqrt((edge[0] * edge[0] + edge[1] * edge[1]).toFloat()) + 0.5f) * chunk
        nearCenterX = (cx + 0.5f) * chunk
        nearCenterZ = (cz + 0.5f) * chunk
    }

    // ---- Drawing --------------------------------------------------------------

    /**
     * Draws the voxel terrain in three steps, each with the GPU state it needs:
     *  1. every visible region's opaque cubes, front to back, with the shader that has no
     *     `discard` (regions on the dissolve rim use the variant that dissolves);
     *  2. the alpha-tested leaf cubes, back-face culling on;
     *  3. plants and lily pads, back-face culling off (they are single quads, see ChunkMesher).
     * Regions entirely past the dissolve edge are skipped: nothing of them would survive.
     */
    private fun drawChunks(eyeX: Float, eyeZ: Float, farPass: Boolean) {
        var n = 0
        var total = 0
        val regionBlocks = (REGION_SIZE * WorldConfig.CHUNK_SIZE).toFloat()
        val cx = frame.eyeX
        val cz = frame.eyeZ
        val fadeOn = farPass && frame.fadeWidth > 0f
        val fadeStart = frame.fadeStart
        val edge = fadeStart + frame.fadeWidth
        for ((key, mesh) in gpuRegions.solid) {
            if (!mesh.hasContent) continue // skip the frustum test too: nothing to draw here
            total++
            val baseX = (key shr 32).toInt() * regionBlocks
            val baseZ = key.toInt() * regionBlocks
            val endX = baseX + regionBlocks
            val endZ = baseZ + regionBlocks

            var fade = false
            if (fadeOn) {
                // Distance from the eye (the centre of the dissolve) to the region's nearest and
                // farthest corner.
                val nearX = if (cx < baseX) baseX else if (cx > endX) endX else cx
                val nearZ = if (cz < baseZ) baseZ else if (cz > endZ) endZ else cz
                val nearDx = nearX - cx
                val nearDz = nearZ - cz
                // Entirely past the edge: fully dissolved, the distant terrain shows there.
                if (nearDx * nearDx + nearDz * nearDz >= edge * edge) continue
                val farDx = max(abs(cx - baseX), abs(cx - endX))
                val farDz = max(abs(cz - baseZ), abs(cz - endZ))
                fade = farDx * farDx + farDz * farDz > fadeStart * fadeStart
            }

            // Box hugs the region's real geometry (its actual min/max height), so a
            // region whose terrain sits entirely outside the view's vertical range is
            // culled even though the full world-height box would still poke in.
            if (!frustum.isBoxVisible(baseX, mesh.minY, baseZ, endX, mesh.maxY, endZ)) continue

            if (n == sortKeys.size) {
                sortKeys = sortKeys.copyOf(n * 2)
                sortMeshes = sortMeshes.copyOf(n * 2)
                sortFade = sortFade.copyOf(n * 2)
            }
            val dx = baseX + regionBlocks * 0.5f - eyeX
            val dz = baseZ + regionBlocks * 0.5f - eyeZ
            val d2 = (dx * dx + dz * dz).toInt()
            sortKeys[n] = (d2.toLong() shl 32) or n.toLong()
            sortMeshes[n] = mesh
            sortFade[n] = fade
            n++
        }

        // Front-to-back: nearest terrain first means the depth test throws away the
        // fragments of everything hidden behind it before they're ever shaded.
        Arrays.sort(sortKeys, 0, n)

        // 1) opaque cubes
        terrainOpaque.use(frame.viewProj, frame, false)
        for (i in 0 until n) {
            val slot = (sortKeys[i] and 0xFFFFFFFFL).toInt()
            if (sortFade[slot]) continue
            sortMeshes[slot]?.drawOpaque()
        }
        if (fadeOn) {
            terrainOpaqueFade.use(frame.viewProj, frame, true)
            for (i in 0 until n) {
                val slot = (sortKeys[i] and 0xFFFFFFFFL).toInt()
                if (!sortFade[slot]) continue
                sortMeshes[slot]?.drawOpaque()
            }
        }

        // 2) leaves (alpha-tested, culling on)
        terrainCutout.use(frame.viewProj, frame, fadeOn)
        var tris = 0
        for (i in 0 until n) {
            val mesh = sortMeshes[(sortKeys[i] and 0xFFFFFFFFL).toInt()] ?: continue
            mesh.drawCutout()
            tris += mesh.triangleCount
        }

        // 3) plants and lily pads (alpha-tested, culling off), only for the regions close enough
        //    for them to matter. The list is sorted nearest-first, so stop at the first far one.
        GLES30.glDisable(GLES30.GL_CULL_FACE)
        val plantReach = PLANT_DRAW_DISTANCE + regionBlocks * 0.71f
        val plantLimit = (plantReach * plantReach).toLong()
        for (i in 0 until n) {
            if ((sortKeys[i] ushr 32) > plantLimit) break
            sortMeshes[(sortKeys[i] and 0xFFFFFFFFL).toInt()]?.drawDoubleSided()
        }
        GLES30.glEnable(GLES30.GL_CULL_FACE)

        statDrawnCols = n
        statTotalCols = total
        statTris = tris
    }

    /** The translucent voxel-chunk water, farthest region first so blending composes correctly. */
    private fun drawNearWater(eyeX: Float, eyeZ: Float, farPass: Boolean) {
        var n = 0
        val regionBlocks = (REGION_SIZE * WorldConfig.CHUNK_SIZE).toFloat()
        for ((key, mesh) in gpuRegions.water) {
            if (!mesh.hasContent) continue
            val baseX = (key shr 32).toInt() * regionBlocks
            val baseZ = key.toInt() * regionBlocks
            // a hair of vertical padding so a surface lying exactly on the box edge is kept
            if (!frustum.isBoxVisible(baseX, mesh.minY - 0.1f, baseZ, baseX + regionBlocks, mesh.maxY + 0.1f, baseZ + regionBlocks)) continue
            if (farPass) {
                // Voxel water has faded out completely by the edge of the voxel area: skip what lies beyond.
                val nearX = if (eyeX < baseX) baseX else if (eyeX > baseX + regionBlocks) baseX + regionBlocks else eyeX
                val nearZ = if (eyeZ < baseZ) baseZ else if (eyeZ > baseZ + regionBlocks) baseZ + regionBlocks else eyeZ
                val edge = frame.fadeStart + frame.fadeWidth
                if ((nearX - eyeX) * (nearX - eyeX) + (nearZ - eyeZ) * (nearZ - eyeZ) >= edge * edge) continue
            }

            if (n == waterSortKeys.size) {
                waterSortKeys = waterSortKeys.copyOf(n * 2)
                waterSortMeshes = waterSortMeshes.copyOf(n * 2)
            }
            val dx = baseX + regionBlocks * 0.5f - eyeX
            val dz = baseZ + regionBlocks * 0.5f - eyeZ
            waterSortKeys[n] = ((dx * dx + dz * dz).toInt().toLong() shl 32) or n.toLong()
            waterSortMeshes[n] = mesh
            n++
        }
        if (n == 0) return
        Arrays.sort(waterSortKeys, 0, n)

        water.begin(frame)
        water.useNearArea(farPass)
        var tris = 0
        for (i in n - 1 downTo 0) {
            val mesh = waterSortMeshes[(waterSortKeys[i] and 0xFFFFFFFFL).toInt()] ?: continue
            mesh.draw()
            tris += mesh.triangleCount
        }
        water.end()
        statWaterTris = tris
    }

    private fun drawHighlight() {
        val hit = engine.lastHit
        if (hit == null) {
            highlightValid = false
            return
        }
        val block = engine.world.getBlock(hit.blockX, hit.blockY, hit.blockZ)
        val shape = if (block.flat) 2 else if (block.plant) 1 else 0
        if (!highlightValid || hit.blockX != highlightX || hit.blockY != highlightY || hit.blockZ != highlightZ ||
            shape != highlightShape
        ) {
            highlightValid = true
            highlightX = hit.blockX
            highlightY = hit.blockY
            highlightZ = hit.blockZ
            highlightShape = shape
            uploadHighlightBox(hit.blockX.toFloat(), hit.blockY.toFloat(), hit.blockZ.toFloat(), shape)
        }
        highlightMesh.draw(GLES30.GL_LINES)
    }

    /** Outline of the targeted block: the whole cell for a solid block, the small selection
     *  box (see Raycaster) for a plant. */
    private fun uploadHighlightBox(x: Float, y: Float, z: Float, shape: Int) {
        val e = 0.002f // tiny outward expansion avoids z-fighting with the block's own faces
        var minX = 0f
        var maxX = 1f
        var maxY = 1f
        var minZ = 0f
        var maxZ = 1f
        if (shape == 1) {
            minX = Raycaster.PLANT_MIN
            maxX = Raycaster.PLANT_MAX
            minZ = Raycaster.PLANT_MIN
            maxZ = Raycaster.PLANT_MAX
            maxY = Raycaster.PLANT_HEIGHT
        } else if (shape == 2) {
            maxY = Raycaster.FLAT_HEIGHT
        }
        val x0 = x + minX - e; val x1 = x + maxX + e
        val y0 = y - e; val y1 = y + maxY + e
        val z0 = z + minZ - e; val z1 = z + maxZ + e
        val corners = arrayOf(
            floatArrayOf(x0, y0, z0), floatArrayOf(x1, y0, z0), floatArrayOf(x1, y0, z1), floatArrayOf(x0, y0, z1),
            floatArrayOf(x0, y1, z0), floatArrayOf(x1, y1, z0), floatArrayOf(x1, y1, z1), floatArrayOf(x0, y1, z1)
        )
        val edges = arrayOf(
            0 to 1, 1 to 2, 2 to 3, 3 to 0,
            4 to 5, 5 to 6, 6 to 7, 7 to 4,
            0 to 4, 1 to 5, 2 to 6, 3 to 7
        )
        val uv = atlas.uvFor(TextureAtlas.WHITE_CELL)
        val floats = FloatArray(edges.size * 2 * 6)
        var fi = 0
        for ((a, b) in edges) {
            for (idx in intArrayOf(a, b)) {
                val c = corners[idx]
                floats[fi++] = c[0]; floats[fi++] = c[1]; floats[fi++] = c[2]
                floats[fi++] = uv.u0; floats[fi++] = uv.v0
                floats[fi++] = 1.3f // >1 shade reads as a bright, unmistakable outline
            }
        }
        val indices = IntArray(edges.size * 2) { it }
        highlightMesh.upload(MeshData(floats, indices, edges.size * 2))
    }

    private fun drawParticles() {
        val ps = engine.particles
        val n = ps.count()
        if (n == 0) return

        val neededFloats = n * 24 * 6
        val neededIndices = n * 36
        if (particleFloats.size < neededFloats) particleFloats = FloatArray(neededFloats)
        if (particleIndices.size < neededIndices) particleIndices = IntArray(neededIndices)
        particleVerts = 0
        particleIdx = 0

        for (p in 0 until n) {
            val cx = ps.x(p); val cy = ps.y(p); val cz = ps.z(p)
            val half = ps.scale(p)
            val uv = atlas.uvFor(ps.cellOf(p))
            val x0 = cx - half; val x1 = cx + half
            val y0 = cy - half; val y1 = cy + half
            val z0 = cz - half; val z1 = cz + half

            addParticleFace(x0, y1, z0, x1, y1, z0, x1, y1, z1, x0, y1, z1, uv) // top
            addParticleFace(x0, y0, z1, x1, y0, z1, x1, y0, z0, x0, y0, z0, uv) // bottom
            addParticleFace(x1, y0, z0, x0, y0, z0, x0, y1, z0, x1, y1, z0, uv) // north
            addParticleFace(x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1, uv) // south
            addParticleFace(x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0, uv) // west
            addParticleFace(x1, y0, z1, x1, y0, z0, x1, y1, z0, x1, y1, z1, uv) // east
        }

        particleMesh.uploadRaw(particleFloats, particleVerts * 6, particleIndices, particleIdx)
        particleMesh.draw()
    }

    /** Appends one particle quad straight into the shared scratch arrays (no per-face
     *  or per-particle allocation, unlike the arrays-of-arrays this replaced). */
    private fun addParticleFace(
        ax: Float, ay: Float, az: Float,
        bx: Float, by: Float, bz: Float,
        cx: Float, cy: Float, cz: Float,
        dx: Float, dy: Float, dz: Float,
        uv: UVRect
    ) {
        val f = particleFloats
        var fi = particleVerts * 6
        f[fi++] = ax; f[fi++] = ay; f[fi++] = az; f[fi++] = uv.u0; f[fi++] = uv.v0; f[fi++] = 1f
        f[fi++] = bx; f[fi++] = by; f[fi++] = bz; f[fi++] = uv.u1; f[fi++] = uv.v0; f[fi++] = 1f
        f[fi++] = cx; f[fi++] = cy; f[fi++] = cz; f[fi++] = uv.u1; f[fi++] = uv.v1; f[fi++] = 1f
        f[fi++] = dx; f[fi++] = dy; f[fi++] = dz; f[fi++] = uv.u0; f[fi++] = uv.v1; f[fi] = 1f

        val base = particleVerts
        val ix = particleIndices
        var k = particleIdx
        ix[k++] = base; ix[k++] = base + 1; ix[k++] = base + 2
        ix[k++] = base; ix[k++] = base + 2; ix[k++] = base + 3
        particleIdx = k
        particleVerts += 4
    }

    /** The creative destroy-laser beam: two crossed quads from just right of and below the eye
     *  out to [LASER_LENGTH] blocks along the view direction, in bright light blue. */
    private fun drawLaser(eyeX: Float, eyeY: Float, eyeZ: Float) {
        val fx = frame.forwardX
        val fy = frame.forwardY
        val fz = frame.forwardZ
        val sx = eyeX + frame.rightX * 0.22f - frame.upX * 0.18f + fx * 0.5f
        val sy = eyeY + frame.rightY * 0.22f - frame.upY * 0.18f + fy * 0.5f
        val sz = eyeZ + frame.rightZ * 0.22f - frame.upZ * 0.18f + fz * 0.5f
        val ex = eyeX + fx * LASER_LENGTH
        val ey = eyeY + fy * LASER_LENGTH
        val ez = eyeZ + fz * LASER_LENGTH
        val r = 0.07f
        val uv = atlas.uvFor(TextureAtlas.WATER_CELL)
        val f = laserFloats
        var i = 0
        // quad A, spread along the camera's right vector; quad B, along its up vector
        for (q in 0 until 2) {
            val ox = if (q == 0) frame.rightX * r else frame.upX * r
            val oy = if (q == 0) frame.rightY * r else frame.upY * r
            val oz = if (q == 0) frame.rightZ * r else frame.upZ * r
            f[i++] = sx - ox; f[i++] = sy - oy; f[i++] = sz - oz; f[i++] = uv.u0; f[i++] = uv.v0; f[i++] = 1.6f
            f[i++] = sx + ox; f[i++] = sy + oy; f[i++] = sz + oz; f[i++] = uv.u0; f[i++] = uv.v0; f[i++] = 1.6f
            f[i++] = ex + ox; f[i++] = ey + oy; f[i++] = ez + oz; f[i++] = uv.u0; f[i++] = uv.v0; f[i++] = 1.6f
            f[i++] = ex - ox; f[i++] = ey - oy; f[i++] = ez - oz; f[i++] = uv.u0; f[i++] = uv.v0; f[i++] = 1.6f
        }
        laserMesh.uploadRaw(f, 8 * 6, laserIndices, laserIndices.size)
        laserMesh.draw()
    }

    // ---- Stats overlay ----------------------------------------------------------------

    private fun updateFps(dt: Float, cpuMs: Float, underwater: Boolean) {
        fpsAccumTime += dt
        fpsAccumFrames++
        if (dt > statWorstDt) statWorstDt = dt
        statCpuAccumMs += cpuMs
        if (cpuMs > statCpuMaxMs) statCpuMaxMs = cpuMs

        if (fpsAccumTime >= 0.4f) {
            currentFps = fpsAccumFrames / fpsAccumTime
            val showStats = engine.settings.showFps
            val showPanel = engine.settings.diagPanel && DiagLog.isActive()
            val statsText = if (showStats || showPanel) {
                val base = if (showStats) buildStatsText(underwater) else ""
                if (showPanel) (if (base.isEmpty()) "" else base + "\n") + DiagLog.panelText() else base
            } else {
                null
            }
            if (DiagLog.isActive()) feedDiagnostics()
            fpsAccumTime = 0f
            fpsAccumFrames = 0
            statWorstDt = 0f
            statCpuAccumMs = 0f
            statCpuMaxMs = 0f
            statUploadAccumNs = 0L
            mainHandler.post { onPeriodicTick(statsText) }
        }
    }

    /** Selected vs effective render distance, only while Automatic Render Distance is on (a line of its
     *  own for the stats overlay, including its newline; empty otherwise). */
    private fun distanceStatusText(): String {
        val settings = engine.settings
        if (!settings.autoRenderDistance) return ""
        return engine.distanceGovernor.statusLine(settings.renderDistanceChunks, WorldConfig.CHUNK_SIZE) + "\n"
    }

    /** Hands the logger what it needs to notice missing terrain and to record the level-of-detail
     *  load (a few times a second; the logger rate-limits itself). */
    private fun feedDiagnostics() {
        val chunk = WorldConfig.CHUNK_SIZE.toFloat()
        val wanted = max(0f, nearEdgeBlocks / chunk - 0.5f)
        val waiting = paused || engine.player.waitingForSpawn
        DiagLog.coverage(
            nearCoveredChunks, wanted, engine.farTerrain.coveredRadiusBlocks,
            far.drawnTiles, far.totalTiles, engine.settings.farTerrain, waiting
        )
        val lt = far.levelTriangles
        var veryFar = 0
        for (i in 3 until lt.size) veryFar += lt[i]
        DiagLog.lodStats(
            statTris, lt[0] + lt[1] + lt[2], veryFar, statWaterTris
        )
    }

    /** cpu = time the GL thread spent building this frame's commands (NOT gpu time):
     *  low cpu but low FPS means the GPU is the bottleneck; high cpu means the game
     *  thread is. worst = longest single frame in the window (hitches). up = time spent
     *  in mesh uploads per frame. ready = regions packed and waiting for the GPU. */
    private fun buildStatsText(underwater: Boolean): String {
        val frames = max(1, fpsAccumFrames)
        val cpuAvg = statCpuAccumMs / frames
        val upAvgMs = (statUploadAccumNs / 1_000_000f) / frames
        val ready = engine.worldManager.readyRegions.count
        val dist = if (underwater) "water" else "$ready"
        return String.format(
            Locale.US,
            "FPS: %d  worst: %dms\ncpu: %.1fms (max %.1f)  up: %.1fms\nreg: %d/%d  tris: %dk  ready: %s\nfar: %d/%d  tris: %dk  water: %dk  cover: %dm  mem: %dMB%s\nlod tris(k): %d %d %d | %d %d %d | %d %d\n%s",
            currentFps.toInt(), (statWorstDt * 1000f).toInt(),
            cpuAvg, statCpuMaxMs, upAvgMs,
            statDrawnCols, statTotalCols, statTris / 1000, dist,
            far.drawnTiles, far.totalTiles, far.drawnTriangles / 1000, statWaterTris / 1000, handover.fogCover.toInt(),
            (engine.farTerrain.residentTileBytes shr 20).toInt(),
            (if (engine.farTerrain.budgetLimited) " (at ceiling)" else "") + (if (far.standIns > 0) "  fill: ${far.standIns}" else ""),
            far.levelTriangles[0] / 1000, far.levelTriangles[1] / 1000, far.levelTriangles[2] / 1000,
            far.levelTriangles[3] / 1000, far.levelTriangles[4] / 1000, far.levelTriangles[5] / 1000,
            far.levelTriangles[6] / 1000, far.levelTriangles[7] / 1000,
            distanceStatusText() + engine.debugStats()
        )
    }
}
