package com.voxelsandbox.game.engine

import com.voxelsandbox.game.player.Player
import com.voxelsandbox.game.world.BlockType
import com.voxelsandbox.game.world.World
import com.voxelsandbox.game.world.WorldConfig

/**
 * Where each kind of block may be put down. Almost every block goes into any cell that is empty, water or a
 * plant; the plants that need something to grow on or in follow the rules of the world generator, so what a
 * player places looks like what the terrain would have made:
 *
 *  - tall grass, flowers and dead bushes stand on a solid block, in the open air (not in water);
 *  - a lily pad floats on water: aimed at water (or at the bed below it) it goes on the surface above;
 *  - seagrass grows from a solid bed, in a cell that is full of water.
 *
 * Pure functions over [World]; nothing here changes the world.
 */
object PlacementRules {
    /** How far up a lily pad looks for the water surface (a column of water this tall is deeper than any sea here). */
    private const val MAX_WATER_COLUMN = 96

    /**
     * The height of the cell [block] really goes into when the player aims at cell ([x], [y], [z]): the same
     * cell for everything except a lily pad, which rises through the water to the first cell above it.
     */
    fun targetY(world: World, block: BlockType, x: Int, y: Int, z: Int): Int {
        if (block != BlockType.LILY_PAD) return y
        var cy = y
        var steps = 0
        while (steps < MAX_WATER_COLUMN && cy + 1 < WorldConfig.WORLD_HEIGHT && world.getBlock(x, cy, z).holdsWater) {
            cy++
            steps++
        }
        return cy
    }

    /** Whether [block] may be put into the cell ([x], [y], [z]) as it is now. */
    fun canPlace(world: World, block: BlockType, x: Int, y: Int, z: Int): Boolean {
        if (block == BlockType.AIR) return false
        if (y < 1 || y >= WorldConfig.WORLD_HEIGHT) return false
        val existing = world.getBlock(x, y, z)
        if (!existing.replaceable) return false
        val below = world.getBlock(x, y - 1, z)
        return when {
            block == BlockType.LILY_PAD -> existing == BlockType.AIR && below.holdsWater
            block == BlockType.SEAGRASS -> existing.holdsWater && below.solid
            block.plant -> (existing == BlockType.AIR || existing.plant) && !existing.holdsWater && below.solid
            else -> true
        }
    }

    /** True if putting [block] into the cell ([x], [y], [z]) would trap the player inside it. Only blocks
     *  that stop movement matter: plants and water can share a cell with the player. */
    fun trapsPlayer(player: Player, block: BlockType, x: Int, y: Int, z: Int): Boolean {
        if (!block.solid) return false
        val hw = Player.WIDTH / 2f
        val px = player.position.x
        val py = player.position.y
        val pz = player.position.z
        return px + hw > x && px - hw < x + 1f &&
            py + Player.HEIGHT > y && py < y + 1f &&
            pz + hw > z && pz - hw < z + 1f
    }
}
