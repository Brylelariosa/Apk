package com.voxelsandbox.game.world.far

import kotlin.math.max

/**
 * What the columns of a tile slide to as their ring ends: the height and the colours of the column of the next
 * coarser level that stands over them. The vertex shader blends from a vertex's own height and colour to these by
 * the vertex's distance from the player (see Shaders.FAR_VERTEX), so at the end of the ring a fine column *is* the
 * coarse column that takes over from it: the ground changes level through a continuous change of shape and colour,
 * not through a step.
 *
 * The coarse columns are computed by exactly the code that builds that level ([FarColumnSampler]), over the window
 * of coarse columns that covers the tile (columns are twice as wide one level up and the grids are aligned, so the
 * window has half the columns per edge), which is why the two meshes coincide there. The coarsest level has
 * nothing to slide to and slides to itself.
 */
internal class ColumnSlide(
    private val own: CellField,
    private val parent: CellField?,
    floorY: Float
) {
    private val cells = own.cells
    private val n = own.n
    private val half = cells / 2
    private val np = half + 2
    private val parentCorners = parent?.corners()

    /** The height each column of the window (ring included) slides to. A level whose columns are not drawn below
     *  [floorY] does not slide below it either. */
    val y = FloatArray(n * n)

    /** The colour (0xRRGGBB) the walls under each column of the window (ring included) slide to: the walls of the
     *  coarse column over it (the column's own, if there is no such column). */
    val wallRgb = IntArray(n * n)

    /** True where the coarse column over a column has walls of soil over rock (see [FarPalette.soilWallKey]). */
    val wallSoil = BooleanArray(n * n)

    init {
        for (j in 0 until n) {
            val pj = ((j - 1) shr 1) + 1
            for (i in 0 until n) {
                val c = j * n + i
                val pi = ((i - 1) shr 1) + 1
                val pc = pj * np + pi
                if (parent == null) {
                    y[c] = own.topY[c]
                } else {
                    y[c] = max(parent.topY[pc], floorY)
                }
                val wallKey = if (parent != null && !parent.skip[pc]) parent.wallCol[pc] else own.wallCol[c]
                wallRgb[c] = FarPalette.rgbOf(wallKey)
                wallSoil[c] = wallKey == FarPalette.soilWallKey
            }
        }
    }

    /** Index in the parent's arrays of the coarse column over window cell ([wi], [wj]) (-1 .. cells). */
    private fun parentCell(wi: Int, wj: Int): Int = ((wj shr 1) + 1) * np + (wi shr 1) + 1

    /**
     * The colour (0xRRGGBB) the top of window cell ([wi], [wj]) slides to at its corner ([dx], [dz]) (each 0 or 1): what
     * the coarse level paints at that point. For grass that is the smooth biome colour, interpolated between the
     * corners of the coarse column; the coarse columns are twice as wide, so a fine corner is a corner, an edge
     * midpoint or the middle of its coarse column. A coarse column that is not drawn leaves the fine one nothing to
     * take its colour from: it keeps its own.
     */
    fun topRgb(wi: Int, wj: Int, dx: Int, dz: Int): Int {
        val p = parent ?: return own.cornerRgb(wi, wj, dx, dz)
        val pc = parentCell(wi, wj)
        if (p.skip[pc]) return own.cornerRgb(wi, wj, dx, dz)
        if (p.grass[pc] < 0) return FarPalette.rgbOf(p.col[pc])
        val k = half + 1
        val pw = wi shr 1
        val pj = wj shr 1
        val corners = parentCorners!!
        val c00 = corners[pj * k + pw]
        val c10 = corners[pj * k + pw + 1]
        val c01 = corners[(pj + 1) * k + pw]
        val c11 = corners[(pj + 1) * k + pw + 1]
        val fx = (wi and 1) + dx // position in the coarse column, in halves
        val fz = (wj and 1) + dz
        return blend(c00, c10, c01, c11, fx, fz)
    }

    private companion object {
        /** The colour at ([fx], [fz]) halves of a column whose corners are [c00], [c10] (+x), [c01] (+z) and [c11]. */
        fun blend(c00: Int, c10: Int, c01: Int, c11: Int, fx: Int, fz: Int): Int {
            val w00 = (2 - fx) * (2 - fz)
            val w10 = fx * (2 - fz)
            val w01 = (2 - fx) * fz
            val w11 = fx * fz
            val r = (w00 * ((c00 shr 16) and 0xFF) + w10 * ((c10 shr 16) and 0xFF) + w01 * ((c01 shr 16) and 0xFF) + w11 * ((c11 shr 16) and 0xFF) + 2) shr 2
            val g = (w00 * ((c00 shr 8) and 0xFF) + w10 * ((c10 shr 8) and 0xFF) + w01 * ((c01 shr 8) and 0xFF) + w11 * ((c11 shr 8) and 0xFF) + 2) shr 2
            val b = (w00 * (c00 and 0xFF) + w10 * (c10 and 0xFF) + w01 * (c01 and 0xFF) + w11 * (c11 and 0xFF) + 2) shr 2
            return (r shl 16) or (g shl 8) or b
        }
    }
}
