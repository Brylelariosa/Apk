package com.voxelsandbox.game.world.far

import com.voxelsandbox.game.gl.TextureAtlas
import com.voxelsandbox.game.gl.TintTable
import com.voxelsandbox.game.world.color.BiomeColorField
import com.voxelsandbox.game.world.color.BiomePalette
import com.voxelsandbox.game.world.generation.SurfaceKind

/**
 * The colours the distant terrain gives to everything that is green: grass tops and leaves.
 *
 * The rest of the distant ground is painted from the atlas palette, one flat colour per cell (see
 * TextureAtlas.rampU). Grass is the exception, because its colour is not a property of a kind of
 * ground: it is a smooth field ([BiomeColorField]) that the voxel terrain tints its grass with. If the
 * distant grass kept reading three fixed palette rows (plain, dry, swamp) it would keep the hard
 * lines between them that the voxel terrain has lost, and a meadow would change colour where the
 * chunks end. So a grass cell takes the field's colour instead, times the brightness step it would have
 * had from the palette (the patch and forest noise are unchanged, only the hue now follows the climate),
 * and the colour of every corner of a cell is the average over the grass cells that meet there, so the
 * quads shade smoothly into each other (see [corner]). Away from the borders between climates the field
 * is exactly the palette's own colour, so the ground looks as it always did there.
 *
 * Leaves take a part of the same shift, as they do on the voxel terrain ([TintTable.LEAF_STRENGTH]).
 *
 * A colour travels in a vertex as a *negative* number in the slot of the palette's u coordinate:
 * `-(0xRRGGBB + 1)`, which a float holds exactly (it is at most 2^24); the vertex shader tells the two apart
 * by the sign. [directKey] / [rgbOfKey] convert, and the mesh builder treats such a key like a palette key
 * everywhere (equal keys merge).
 */
class FarGroundColor(private val palette: BiomePalette) {

    /**
     * The colour of a grass cell: the field's colour [fieldRgb] times the brightness step of the ramp
     * column [rampColumn] (the column the cell's patch and forest noise picked in the group of [kind]).
     */
    fun grass(fieldRgb: Int, kind: SurfaceKind, rampColumn: Int): Int {
        val steps: FloatArray
        val first: Int
        when (kind) {
            SurfaceKind.DRY_GRASS -> { steps = TextureAtlas.DRY_STEPS; first = TextureAtlas.RAMP_DRY.toInt() }
            SurfaceKind.SWAMP -> { steps = TextureAtlas.SWAMP_STEPS; first = TextureAtlas.RAMP_SWAMP.toInt() }
            else -> { steps = TextureAtlas.GRASS_STEPS; first = TextureAtlas.RAMP_GRASS.toInt() }
        }
        val s = steps[(rampColumn - first).coerceIn(0, steps.size - 1)]
        return BiomeColorField.pack(
            ((fieldRgb shr 16) and 0xFF) * s,
            ((fieldRgb shr 8) and 0xFF) * s,
            (fieldRgb and 0xFF) * s
        )
    }

    /**
     * A leaf colour: the palette colour [rampRgb] of the tree, shifted the way the voxel leaves are: by
     * [TintTable.LEAF_STRENGTH] of the factor between the field's colour [fieldRgb] and the colour plain
     * grass has (the factor is 1 in the middle of a plain, so leaves are unchanged there).
     */
    fun leaf(rampRgb: Int, fieldRgb: Int): Int {
        val k = TintTable.LEAF_STRENGTH
        val fr = 1f + (((fieldRgb shr 16) and 0xFF) / palette.grassR - 1f) * k
        val fg = 1f + (((fieldRgb shr 8) and 0xFF) / palette.grassG - 1f) * k
        val fb = 1f + ((fieldRgb and 0xFF) / palette.grassB - 1f) * k
        return BiomeColorField.pack(
            ((rampRgb shr 16) and 0xFF) * fr,
            ((rampRgb shr 8) and 0xFF) * fg,
            (rampRgb and 0xFF) * fb
        )
    }

    companion object {
        /** Marks a grid position that has no grass colour (not a grass cell). */
        const val NONE = -1

        /** The key (a negative int) that stands for the colour [rgb] in a vertex. */
        fun directKey(rgb: Int): Int = -(rgb + 1)

        /** The colour of a [directKey]. */
        fun rgbOfKey(key: Int): Int = -key - 1

        fun isDirect(key: Int): Boolean = key < 0

        /**
         * The colour of a corner of the grid, given the colours of the (up to four) grass cells that meet
         * there (`NONE` for a cell that is not grass): their per-channel average, rounded; `NONE` if none is
         * grass. Cells that are not grass do not take part, so the colour of grass never runs into the sand,
         * snow or rock beside it, and every grass cell around a corner agrees on its colour.
         */
        fun corner(a: Int, b: Int, c: Int, d: Int): Int {
            var n = 0
            var r = 0
            var g = 0
            var bl = 0
            if (a >= 0) { n++; r += (a shr 16) and 0xFF; g += (a shr 8) and 0xFF; bl += a and 0xFF }
            if (b >= 0) { n++; r += (b shr 16) and 0xFF; g += (b shr 8) and 0xFF; bl += b and 0xFF }
            if (c >= 0) { n++; r += (c shr 16) and 0xFF; g += (c shr 8) and 0xFF; bl += c and 0xFF }
            if (d >= 0) { n++; r += (d shr 16) and 0xFF; g += (d shr 8) and 0xFF; bl += d and 0xFF }
            if (n == 0) return NONE
            val h = n shr 1
            return (((r + h) / n) shl 16) or (((g + h) / n) shl 8) or ((bl + h) / n)
        }
    }
}
