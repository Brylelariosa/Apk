package com.voxelsandbox.game.save

import com.voxelsandbox.game.inventory.Hotbar
import com.voxelsandbox.game.world.ChunkPos
import com.voxelsandbox.game.world.WorldConfig
import java.io.DataInputStream
import java.io.DataOutputStream

/** What the game restores from a save besides the edited chunks. */
class SaveHeader(
    val seed: Long,
    val playerX: Float, val playerY: Float, val playerZ: Float,
    val yaw: Float, val pitch: Float,
    /** The block id of every hotbar slot, in order (see [Hotbar.exportIds]). */
    val hotbarIds: ByteArray,
    val hotbarSelected: Int,
    val flying: Boolean
)

/** A loaded save: the header fields plus the chunks the player edited, by position. */
class LoadedSave(
    val seed: Long,
    val playerX: Float, val playerY: Float, val playerZ: Float,
    val yaw: Float, val pitch: Float,
    /** Null for a save from before the creative hotbar existed: the default hotbar is used then. */
    val hotbarIds: ByteArray?,
    val hotbarSelected: Int,
    val flying: Boolean,
    val chunkOverrides: Map<ChunkPos, ByteArray>
)

/**
 * The save file's byte layout, apart from the file handling (see [SaveManager]), so it can be tested on
 * its own. Layout, big-endian as written by [DataOutputStream]:
 *
 *     int magic, int version, long seed, float x, y, z, yaw, pitch,
 *     version 5:  int slotCount, slotCount x byte blockId, int selectedSlot, boolean flying
 *     version 4:  int countSize, countSize x int count          (the survival-style stack counts, dropped)
 *     int chunkCount, chunkCount x (int chunkX, int chunkZ, BYTES_PER_CHUNK bytes of blocks)
 *
 * Version 4 saves (everything before the creative-only game) still load: their world, position and view are
 * kept, the stack counts are ignored and the hotbar starts at its default. Files are always written as the
 * newest version. Anything unreadable gives null, never an exception.
 */
object SaveCodec {
    const val MAGIC = 0x56534158 // "VSAX"

    // 2: 128-block-tall chunks and a new terrain generator (v1 saves would not line up with the terrain
    //    generated around them, so they are rejected on load).
    // 4: 256-block-tall chunks, sea level 64, new biomes / mountains / caves and new blocks (older saves
    //    would not line up with the terrain generated around them either).
    // 5: creative-only game: the hotbar's block ids and the selected slot replace the survival-style counts;
    //    the flight state is saved. Chunks are unchanged, so a version 4 save loads.
    const val VERSION = 5
    const val OLDEST_READABLE_VERSION = 4

    private const val MAX_SLOTS = 64
    private const val MAX_CHUNKS = 200_000

    /** Writes the header, then [chunkCount] chunks taken one at a time from [chunks] (so only one chunk's
     *  bytes are in memory at once). */
    fun write(
        out: DataOutputStream,
        header: SaveHeader,
        chunkCount: Int,
        chunks: Iterator<Pair<ChunkPos, ByteArray>>
    ) {
        out.writeInt(MAGIC)
        out.writeInt(VERSION)
        out.writeLong(header.seed)
        out.writeFloat(header.playerX)
        out.writeFloat(header.playerY)
        out.writeFloat(header.playerZ)
        out.writeFloat(header.yaw)
        out.writeFloat(header.pitch)

        out.writeInt(header.hotbarIds.size)
        out.write(header.hotbarIds)
        out.writeInt(header.hotbarSelected)
        out.writeBoolean(header.flying)

        out.writeInt(chunkCount)
        var written = 0
        while (chunks.hasNext() && written < chunkCount) {
            val (pos, bytes) = chunks.next()
            require(bytes.size == WorldConfig.BYTES_PER_CHUNK) { "chunk ${pos.x},${pos.z} has ${bytes.size} bytes" }
            out.writeInt(pos.x)
            out.writeInt(pos.z)
            out.write(bytes)
            written++
        }
        check(written == chunkCount) { "announced $chunkCount chunks but wrote $written" }
    }

    /** Reads a save, or null when it is not a readable save of this game (wrong magic or version, truncated,
     *  damaged numbers). Never throws. */
    fun read(input: DataInputStream): LoadedSave? {
        return try {
            readUnchecked(input)
        } catch (t: Throwable) {
            // Corrupted or partial save: treat as "no usable save" rather than crashing.
            null
        }
    }

    private fun readUnchecked(input: DataInputStream): LoadedSave? {
        val magic = input.readInt()
        val version = input.readInt()
        if (magic != MAGIC || version < OLDEST_READABLE_VERSION || version > VERSION) return null

        val seed = input.readLong()
        val px = input.readFloat(); val py = input.readFloat(); val pz = input.readFloat()
        val yaw = input.readFloat(); val pitch = input.readFloat()
        if (!px.isFinite() || !py.isFinite() || !pz.isFinite() || !yaw.isFinite() || !pitch.isFinite()) return null

        var hotbarIds: ByteArray? = null
        var selected = 0
        var flying = false
        if (version >= 5) {
            val slots = input.readInt()
            if (slots < 0 || slots > MAX_SLOTS) return null
            hotbarIds = ByteArray(slots).also { input.readFully(it) }
            selected = input.readInt()
            flying = input.readBoolean()
        } else {
            val countSize = input.readInt()
            if (countSize < 0 || countSize > MAX_SLOTS) return null
            repeat(countSize) { input.readInt() } // survival-style stack counts: no longer used
        }

        val chunkCount = input.readInt()
        if (chunkCount < 0 || chunkCount > MAX_CHUNKS) return null
        val overrides = HashMap<ChunkPos, ByteArray>(chunkCount * 2)
        repeat(chunkCount) {
            val cx = input.readInt()
            val cz = input.readInt()
            val bytes = ByteArray(WorldConfig.BYTES_PER_CHUNK)
            input.readFully(bytes)
            overrides[ChunkPos(cx, cz)] = bytes
        }
        return LoadedSave(seed, px, py, pz, yaw, pitch, hotbarIds, selected, flying, overrides)
    }
}
