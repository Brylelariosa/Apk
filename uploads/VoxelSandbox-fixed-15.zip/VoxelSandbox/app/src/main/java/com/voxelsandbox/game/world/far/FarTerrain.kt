package com.voxelsandbox.game.world.far

import com.voxelsandbox.game.diag.DiagLog
import com.voxelsandbox.game.world.color.BiomeColorField
import com.voxelsandbox.game.world.far.FarLevels.LAND_Y_OFFSET
import com.voxelsandbox.game.world.far.FarLevels.landFloor
import com.voxelsandbox.game.world.generation.TerrainGenerator
import com.voxelsandbox.game.world.mesh.MeshData
import java.util.concurrent.Callable
import java.util.concurrent.ExecutionException
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.LinkedBlockingQueue
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** Tile add ([tile] != null) or removal ([tile] == null) for [key], delivered to the GL
 *  thread strictly in the order the worker produced them. A single ordered stream matters:
 *  with separate "ready" and "unload" queues a tile that was built, unloaded and rebuilt
 *  could be applied in the wrong order and leave a ghost mesh behind. */
class FarEvent(val key: Long, val tile: FarTile?)

/** One finished distant-terrain tile, ready for the GL thread to upload: the opaque land
 *  mesh (six floats per vertex, see [FarTerrain.LAND_FLOATS]) and (where the tile touches
 *  water) the translucent water mesh (six floats per vertex). */
class FarTile(
    val key: Long,
    val land: MeshData,
    val water: MeshData,
    val minY: Float,
    val maxY: Float
) {
    val level: Int get() = FarTerrain.levelOf(key)

    /** Edge length of the (square) tile in blocks. */
    val size: Float get() = FarTerrain.tileBlocks(level).toFloat()

    /** World-space X/Z of the tile's lower corner. */
    val x0: Float get() = FarTerrain.tileX(key) * size
    val z0: Float get() = FarTerrain.tileZ(key) * size
}

/**
 * Distant terrain: blocky "voxel-style" columns (with little trees) that fill the space between the full-detail
 * voxel chunks and the horizon, so the view distance can be many times larger than what voxel chunks could ever
 * afford (memory- or draw-call-wise). It looks like the voxel world, only built of bigger bricks the farther out
 * it is, the way the distant LODs of the Distant Horizons mod do.
 *
 * Nothing here touches the voxel world. Heights come straight from the terrain generator's pure height
 * function, so a tile can exist for terrain that no chunk has generated yet -- which is also why the horizon is
 * there instantly at start-up and why it fills any gap while real chunks are still streaming in.
 *
 * Levels of detail. LOD 0 is the voxel world itself (real chunks, see GameRenderer). Beyond it there are [LEVELS]
 * levels of column terrain, finest first; every level has columns twice as wide as the one before and its own ring
 * of distance around the player, twice as far out as the one before (see [FarLevels] and [FarRings]):
 *
 *  - level 0 = LOD 1 (high):   2-block columns, a thin ring right behind the voxel area
 *  - level 1 = LOD 2 (medium): 4-block columns
 *  - level 2 = LOD 3 (low):    8-block columns
 *  - levels 3 .. 7:            16- to 256-block columns, out to the render distance
 *
 * A column keeps about the same size on screen at every distance, so the detail of the picture is the same
 * everywhere and every doubling of the render distance adds a roughly constant number of columns instead of four
 * times as many. Heights are rounded to a step that grows with the level (about a pixel of the picture), and
 * neighbouring columns that end up with the same height and colour are merged into one flat rectangle, which is
 * what keeps the wide rings cheap; the walls between columns that differ are merged along their edge.
 *
 * Levels meet WITHOUT cracks, overlaps, or popping. The columns of a level slide, over the outer part of
 * their ring, to the height and colour of the *parent* column of the next coarser level (the 2 x 2 columns of a
 * fine level share one parent: all steps are powers of two on a common grid; the vertex shader does the blend from
 * per-vertex targets, see [ColumnSlide]). At the ring's edge a fine mesh is exactly the coarse mesh, so the two
 * can meet on a plain distance cut with nothing to hide, and a point of ground changes level only through a
 * continuous change of shape and colour.
 *
 * Tiles of one level sample exactly the same heights along their shared edges, so there are no cracks inside a
 * level either. Colour comes from a palette in the texture atlas chosen from the surface type (see
 * [FarStyler]) and, for grass, from the smooth biome colour field, so a tile needs no per-block textures. Where
 * the ground is below sea level the tile also gets a water mesh whose vertices carry the water depth, drawn by the
 * animated-water shader.
 *
 * Everything is built on background threads, nearest tile first: one coordinator that plans, unloads and publishes
 * in order, plus (on devices with enough cores) a couple of builders that construct tiles side by side.
 * [coveredRadiusBlocks] reports how far from the player the tiles are contiguously complete, which the renderer
 * uses to keep the fog in front of any still-missing ground. A missing tile that a built coarser tile stands in for
 * (see [FarStandIns]; the renderer draws the coarser ground in the hole until the real tile arrives) leaves no hole,
 * so it does not count against that radius: the fog stays where it is while the tile is built.
 */
class FarTerrain(private val generator: TerrainGenerator, colorField: BiomeColorField) {

    /** What the ground looks like at a sample (colour, canopy), and the mesher that turns it into geometry. */
    private val styler = FarStyler(generator, colorField, FarGroundColor(colorField.palette))
    private val columns = FarColumnMesher(generator, styler)

    @Volatile private var running = false
    @Volatile private var enabled = true
    @Volatile private var playerX = 0f
    @Volatile private var playerZ = 0f
    @Volatile private var radiusBlocks = 0f
    @Volatile private var resetRequested = false

    /** Tiles to add / remove, in order, for the GL thread to apply. */
    val events = LinkedBlockingQueue<FarEvent>()

    /** Distance from the player out to which every wanted tile has been built. */
    @Volatile var coveredRadiusBlocks: Float = 0f
        private set

    /** Upper bound of the GPU memory the published tiles occupy (bytes), and the ceiling the builder
     *  keeps it under. Hitting the ceiling is not an error: the horizon is simply drawn in at the
     *  distance the budget reaches (see [FarBudget]), with the fog in front of it, and the ground
     *  near the player is never given up for ground far away. */
    @Volatile var residentTileBytes: Long = 0L
        private set
    val tileByteBudget: Long = budgetForThisDevice()

    /** True while the byte budget, not the render distance, decides how far the horizon reaches. */
    @Volatile var budgetLimited: Boolean = false
        private set

    /** Share of [tileByteBudget] in use right now: the OS asking apps to give memory back lowers it
     *  (see [setBudgetScale]); the farthest tiles go first and come back when it is restored. */
    @Volatile private var budgetScale = 1f

    // Coordinator-thread only: the size of every published tile, so unloading gives its bytes back.
    private val tileBytes = HashMap<Long, Int>()

    // Coordinator-thread only: what a tile of each level has weighed so far (an average), which is
    // what the budget assumes for a tile that has not been built yet.
    private val levelBytes = FloatArray(LEVELS) { DEFAULT_TILE_BYTES[it].toFloat() }
    private val budget = FarBudget()

    // The player's velocity (blocks per second, smoothed), for where to prefetch tiles: the plan covers the
    // rings around where the player is and around where they will be PREFETCH_SECONDS from now.
    @Volatile private var velX = 0f
    @Volatile private var velZ = 0f
    private var speedNs = 0L
    private var speedX = 0f
    private var speedZ = 0f

    /** How many tiles were unloaded because they left the plan, and how many were evicted to stay within
     *  the memory budget (statistics; the second should stay near zero in normal play). */
    @Volatile var staleUnloads = 0L
        private set
    @Volatile var budgetEvictions = 0L
        private set
    @Volatile var tilesBuilt = 0L
        private set

    private var thread: Thread? = null

    /** How many tiles are built at the same time. One builder (the coordinator thread itself)
     *  on small CPUs; two or three on bigger ones, leaving cores for the chunk workers and the
     *  render thread. */
    private val builderCount: Int = (Runtime.getRuntime().availableProcessors() / 3).coerceIn(1, 3)
    private var builderPool: ExecutorService? = null

    fun start() {
        if (running) return
        running = true
        if (builderCount > 1) {
            builderPool = Executors.newFixedThreadPool(builderCount) { task ->
                Thread({
                    lowerPriority()
                    task.run()
                }, "voxel-far-build").apply { isDaemon = true }
            }
        }
        thread = Thread({ workerLoop() }, "voxel-far").apply {
            isDaemon = true
            start()
        }
    }

    fun shutdown() {
        running = false
        thread?.interrupt()
        thread = null
        builderPool?.shutdownNow()
        builderPool = null
    }

    private fun lowerPriority() {
        try {
            android.os.Process.setThreadPriority(
                android.os.Process.THREAD_PRIORITY_BACKGROUND + android.os.Process.THREAD_PRIORITY_MORE_FAVORABLE
            )
        } catch (t: Throwable) {
            // best effort only
        }
    }

    /** Scales the memory the tiles may use (1 = all of [tileByteBudget]); lowering it is how the
     *  distant terrain gives memory back when the OS asks for it. Safe from any thread. */
    fun setBudgetScale(scale: Float) {
        budgetScale = scale.coerceIn(MIN_BUDGET_SCALE, 1f)
    }

    private fun effectiveBudget(): Long = (tileByteBudget * budgetScale).toLong()

    /** Cheap; safe to call every frame. [radius] is the render distance in blocks. */
    fun updatePlayer(x: Float, z: Float, radius: Float, enable: Boolean) {
        val now = System.nanoTime()
        if (speedNs == 0L) {
            speedNs = now
            speedX = x
            speedZ = z
        } else if (now - speedNs >= SPEED_WINDOW_NS) {
            val dt = (now - speedNs) / 1.0e9f
            velX += ((x - speedX) / dt - velX) * 0.5f
            velZ += ((z - speedZ) / dt - velZ) * 0.5f
            speedNs = now
            speedX = x
            speedZ = z
        }
        playerX = x
        playerZ = z
        // Bounded on purpose: the tile planner loops over every tile of every level out to this radius,
        // so a stray huge (or NaN) value must never reach it. 20,000 blocks covers the largest
        // selectable render distance (1000 chunks = 16,000 blocks) with room to spare.
        radiusBlocks = if (radius.isNaN()) 0f else radius.coerceIn(0f, MAX_RADIUS_BLOCKS)
        enabled = enable
    }

    /** The renderer lost its GL objects (context recreated): everything must be rebuilt
     *  and re-sent, since the CPU copies are not kept after upload. */
    fun invalidateAll() {
        resetRequested = true
    }

    // ---- worker ---------------------------------------------------------------------------

    /**
     * One tile the plan wants. [near] is the distance to the nearest point of the tile that is
     * actually drawn (the part inside its level's band): how far the picture is complete once every
     * tile before this one is built. Not the distance to the tile's footprint, which for a big coarse
     * tile can be hundreds of blocks nearer than anything of it that is ever on screen, and which
     * used to drag the whole horizon in whenever such a tile was missing.
     */
    private class Candidate(val level: Int, val tx: Int, val tz: Int, val key: Long, val near: Float, val rank: Int) {
        /** Tiles whose absence leaves a hole in the picture; the others are an improvement
         *  (the finest ring) or a prefetch and never hold back the fog. */
        val required: Boolean get() = rank == FarBudget.RANK_REQUIRED

        /** A coarser tile that contains this one is already built: the renderer draws it in the hole until this
         *  tile arrives (see [FarStandIns]), so the picture is complete without it. Set by [buildPass]. */
        var standIn = false

        /** True while the absence of this tile is what limits how far the picture is complete. */
        val limitsCoverage: Boolean get() = required && !standIn
    }

    /** A tile that is being built on a builder thread; kept in plan order. */
    private class Pending(val cand: Candidate, val job: Future<FarTile>)

    private fun workerLoop() {
        lowerPriority()

        val built = HashSet<Long>()
        while (running) {
            try {
                if (resetRequested) {
                    resetRequested = false
                    built.clear()
                    clearBytes()
                    budget.reset()
                    events.clear()
                    coveredRadiusBlocks = 0f
                }

                val radius = radiusBlocks
                if (!enabled || radius < 32f) {
                    if (built.isNotEmpty()) {
                        for (k in built) events.put(FarEvent(k, null))
                        built.clear()
                        clearBytes()
                    }
                    coveredRadiusBlocks = 0f
                    Thread.sleep(250)
                    continue
                }

                val px = playerX
                val pz = playerZ
                val ahead = predictedPosition(px, pz)
                val ax = ahead[0]
                val az = ahead[1]
                val plan = planTiles(px, pz, ax, az, radius)
                unloadStale(built, px, pz, ax, az, radius)

                // How much of the plan the memory budget allows (see FarBudget), and what to give up
                // when the resident tiles are over it. A horizon that has to come in is published BEFORE
                // any tile is evicted, so the fog is already in front of ground that is about to go.
                val limit = effectiveBudget()
                val fit = budget.fit(planEntries(plan), limit)
                if (fit.horizon < coveredRadiusBlocks) coveredRadiusBlocks = fit.horizon
                if (residentTileBytes > limit * FarBudget.EVICT_ABOVE) {
                    evictDownTo(built, fit.keep, px, pz, (limit * FarBudget.EVICT_TO).toLong())
                }

                val replan = buildPass(plan, fit, built, px, pz, radius)
                noteBudgetLimit(fit.horizon < radius, fit.horizon)
                if (!replan) Thread.sleep(120)
            } catch (e: InterruptedException) {
                return
            } catch (t: Throwable) {
                // A bad tile must never kill the whole horizon; back off briefly and retry.
                DiagLog.error("far", "tile build failed: " + t)
                try {
                    Thread.sleep(250)
                } catch (e: InterruptedException) {
                    return
                }
            }
        }
    }

    /**
     * Builds what the plan still lacks, nearest first, and publishes the tiles to the GL thread in plan
     * order, keeping [coveredRadiusBlocks] honest as it goes. Returns true if the player has moved so far
     * that the plan is stale and should be redone at once.
     */
    private fun buildPass(plan: List<Candidate>, fit: FarBudget.Fit, built: HashSet<Long>, px: Float, pz: Float, radius: Float): Boolean {
        var replan = false
        var limitedAt = -1f // where the first required tile the budget leaves out would have begun
        val pool = builderPool
        // Tiles being built right now, oldest first. Their results are published in exactly the order the
        // tiles were planned, so the event stream (and the coverage radius) behaves as if one thread
        // had built them one after another.
        val pending = ArrayDeque<Pending>()
        try {
            for (cand in plan) {
                if (!running) return false
                if (built.contains(cand.key)) continue
                if (!fit.keep.contains(cand.key)) {
                    if (cand.required && limitedAt < 0f) limitedAt = cand.near
                    continue
                }

                // A tile that a built coarser tile stands in for does not leave a hole, so it does not shorten
                // the covered radius (which is what pulls the fog in).
                cand.standIn = cand.required && FarStandIns.find(cand.key) { built.contains(it) } != FarStandIns.NONE

                // Plan order is nearest first and every nearer required tile is already built (or is the
                // oldest one still in flight), so contiguous coverage ends exactly where the oldest
                // unfinished tile that leaves a hole begins.
                if (cand.limitsCoverage) {
                    coveredRadiusBlocks = if (pending.isEmpty()) cand.near else firstRequiredNear(pending, cand.near)
                }

                // Room for it? What the plan does not keep goes first, farthest first; if that is not
                // enough the budget really is full and this tile is beyond the horizon.
                val estimate = estimateBytes(cand.level).toLong()
                val limit = effectiveBudget()
                if (residentTileBytes + estimate > limit) {
                    evictDownTo(built, fit.keep, px, pz, limit - estimate)
                    if (residentTileBytes + estimate > limit) {
                        if (cand.required && limitedAt < 0f) limitedAt = cand.near
                        continue
                    }
                }

                // Backpressure: the GL thread uploads only a couple per frame.
                while (running && events.size >= MAX_QUEUED_EVENTS) Thread.sleep(4)

                if (pool == null) {
                    val tile = timedBuild(cand)
                    events.put(FarEvent(tile.key, tile))
                    built.add(cand.key)
                    addBytes(tile)
                    tilesBuilt++
                } else {
                    pending.addLast(Pending(cand, pool.submit(Callable<FarTile> { timedBuild(cand) })))
                    if (pending.size < builderCount) continue // keep every builder busy first
                    publish(pending.removeFirst(), built)
                }

                if (resetRequested || !enabled || radiusBlocks != radius ||
                    abs(playerX - px) > REPLAN_DISTANCE || abs(playerZ - pz) > REPLAN_DISTANCE
                ) {
                    replan = true
                    break
                }
            }

            // Whatever is still in flight is finished and published too (unless everything is being
            // thrown away anyway).
            while (pending.isNotEmpty()) {
                val p = pending.removeFirst()
                if (resetRequested) {
                    p.job.cancel(true)
                } else {
                    if (p.cand.limitsCoverage) coveredRadiusBlocks = p.cand.near
                    publish(p, built)
                }
            }
        } finally {
            for (p in pending) p.job.cancel(true)
        }
        if (!replan) coveredRadiusBlocks = if (limitedAt >= 0f) limitedAt else radius
        return replan
    }

    private fun noteBudgetLimit(limited: Boolean, horizon: Float) {
        if (limited && !budgetLimited) {
            DiagLog.note(
                "far terrain: memory budget (%d of %d MB in use) limits the horizon to %.0f blocks"
                    .format(residentTileBytes shr 20, effectiveBudget() shr 20, horizon)
            )
        }
        budgetLimited = limited
    }

    /** Where the player will be [PREFETCH_SECONDS] from now if they keep their velocity (at most
     *  [MAX_PREFETCH] blocks away): the plan also covers the rings around that point, so a tile is
     *  there before the player is whatever the speed, without carrying a prefetch margin on all sides
     *  of the player, including behind them. */
    private fun predictedPosition(px: Float, pz: Float): FloatArray {
        var dx = velX * PREFETCH_SECONDS
        var dz = velZ * PREFETCH_SECONDS
        val len = sqrt(dx * dx + dz * dz)
        if (len > MAX_PREFETCH) {
            dx *= MAX_PREFETCH / len
            dz *= MAX_PREFETCH / len
        }
        return floatArrayOf(px + dx, pz + dz)
    }

    private fun planEntries(plan: List<Candidate>): ArrayList<FarBudget.Entry> {
        val out = ArrayList<FarBudget.Entry>(plan.size)
        for (c in plan) out.add(FarBudget.Entry(c.key, c.near, c.rank, tileBytes[c.key] ?: estimateBytes(c.level)))
        return out
    }

    private fun estimateBytes(level: Int): Int = levelBytes[level].toInt()

    /** Evicts resident tiles the plan does not keep (stale ones, and planned ones beyond the horizon),
     *  farthest first, until the resident bytes are at most [target] or none is left to evict. */
    private fun evictDownTo(built: HashSet<Long>, keep: Set<Long>, px: Float, pz: Float, target: Long) {
        if (residentTileBytes <= target) return
        var victims: ArrayList<Long>? = null
        for (key in built) {
            if (keep.contains(key)) continue
            if (victims == null) victims = ArrayList()
            victims.add(key)
        }
        if (victims == null) return
        victims.sortByDescending { nearestDistance(tileX(it), tileZ(it), tileBlocks(levelOf(it)), px, pz) }
        for (key in victims) {
            if (residentTileBytes <= target) break
            built.remove(key)
            removeBytes(key)
            events.put(FarEvent(key, null))
            budgetEvictions++
        }
    }

    private fun firstRequiredNear(pending: ArrayDeque<Pending>, fallback: Float): Float {
        for (p in pending) {
            if (p.cand.limitsCoverage) return p.cand.near
        }
        return fallback
    }

    /** Builds one tile and reports how long it took (and how big it came out) to the
     *  diagnostic log, which is a no-op while logging is off. */
    private fun timedBuild(cand: Candidate): FarTile {
        val t0 = System.nanoTime()
        val tile = buildTile(cand.level, cand.tx, cand.tz)
        if (DiagLog.isActive()) {
            val ms = (System.nanoTime() - t0) / 1_000_000f
            DiagLog.farTile(cand.level, ms, tile.land.indices.size / 3, tile.water.indices.size / 3)
        }
        return tile
    }

    /** Waits for [p]'s tile and hands it to the GL thread. A tile that failed to build is
     *  reported as the original exception (the coordinator backs off and retries). */
    private fun publish(p: Pending, built: HashSet<Long>) {
        val tile = try {
            p.job.get()
        } catch (e: ExecutionException) {
            throw e.cause ?: e
        }
        events.put(FarEvent(tile.key, tile))
        built.add(p.cand.key)
        addBytes(tile)
        tilesBuilt++
    }

    private fun addBytes(tile: FarTile) {
        val bytes = tileSizeBytes(tile)
        val old = tileBytes.put(tile.key, bytes)
        residentTileBytes += bytes - (old ?: 0)
        // What a tile of this level weighs, for the budget's estimate of the ones not built yet.
        val level = tile.level
        levelBytes[level] += (bytes - levelBytes[level]) * 0.15f
    }

    private fun removeBytes(key: Long) {
        val old = tileBytes.remove(key) ?: return
        residentTileBytes -= old
    }

    private fun clearBytes() {
        tileBytes.clear()
        residentTileBytes = 0L
    }

    /** Every tile that must exist for the current position and render distance, across all
     *  levels, in the order they are to be built: first the tiles whose ground is on screen (nearest
     *  first, by the nearest part of them that is drawn), then the optional finest ring, then the
     *  tiles that are only prefetched: those that the player will need within [PREFETCH_SECONDS] ([ax],
     *  [az] is where they will be), or that are just outside the band they belong to (a margin, on the
     *  inner side as well as the outer, so a band that the player walks into is already built). */
    private fun planTiles(px: Float, pz: Float, ax: Float, az: Float, radius: Float): ArrayList<Candidate> {
        val out = ArrayList<Candidate>()
        val moving = abs(ax - px) + abs(az - pz) > 1f
        for (level in 0 until LEVELS) {
            val inner = planInner(level)
            if (inner - PLAN_MARGIN > radius) continue
            val visibleOuter = min(drawOuter(level), radius)
            val outer = min(drawOuter(level) + PLAN_MARGIN, radius)
            if (outer <= inner + 1f) continue
            val size = tileBlocks(level)
            val minTx = Math.floorDiv(floor(min(px, ax) - outer).toInt(), size)
            val maxTx = Math.floorDiv(floor(max(px, ax) + outer).toInt(), size)
            val minTz = Math.floorDiv(floor(min(pz, az) - outer).toInt(), size)
            val maxTz = Math.floorDiv(floor(max(pz, az) + outer).toInt(), size)
            for (tz in minTz..maxTz) {
                for (tx in minTx..maxTx) {
                    val near = nearestDistance(tx, tz, size, px, pz)
                    val far = farthestDistance(tx, tz, size, px, pz)
                    val visible = near < visibleOuter && (inner <= 0f || far >= inner)
                    var priority = near
                    var planned = visible || (near <= outer && (inner <= 0f || far >= inner - PLAN_MARGIN))
                    if (!planned && moving) {
                        val nearAhead = nearestDistance(tx, tz, size, ax, az)
                        val farAhead = farthestDistance(tx, tz, size, ax, az)
                        if (nearAhead <= outer && (inner <= 0f || farAhead >= inner - PLAN_MARGIN)) {
                            planned = true
                            priority = nearAhead
                        }
                    }
                    if (!planned) continue
                    val rank = when {
                        !visible -> FarBudget.RANK_PREFETCH
                        level == 0 -> FarBudget.RANK_FINE
                        else -> FarBudget.RANK_REQUIRED
                    }
                    out.add(Candidate(level, tx, tz, tileKey(level, tx, tz), max(priority, inner), rank))
                }
            }
        }
        out.sortWith(compareBy<Candidate>({ it.rank }, { it.near }))
        return out
    }

    /** True if the tile is outside the plan around ([x], [z]) by more than [UNLOAD_SLACK]. */
    private fun outOfPlan(level: Int, tx: Int, tz: Int, x: Float, z: Float, radius: Float): Boolean {
        val size = tileBlocks(level)
        val near = nearestDistance(tx, tz, size, x, z)
        val outer = min(drawOuter(level) + PLAN_MARGIN, radius)
        if (near > outer + UNLOAD_SLACK) return true
        val inner = planInner(level)
        return inner > 0f && farthestDistance(tx, tz, size, x, z) < inner - PLAN_MARGIN - UNLOAD_SLACK
    }

    /** Drops tiles that are well outside the plan, both where the player is and where they are heading.
     *  The slack is the hysteresis that stops a tile on the edge of a band being rebuilt back and forth. */
    private fun unloadStale(built: HashSet<Long>, px: Float, pz: Float, ax: Float, az: Float, radius: Float) {
        var stale: ArrayList<Long>? = null
        for (key in built) {
            val level = levelOf(key)
            val tx = tileX(key)
            val tz = tileZ(key)
            if (outOfPlan(level, tx, tz, px, pz, radius) && outOfPlan(level, tx, tz, ax, az, radius)) {
                if (stale == null) stale = ArrayList()
                stale.add(key)
            }
        }
        if (stale != null) {
            for (key in stale) {
                built.remove(key)
                removeBytes(key)
                events.put(FarEvent(key, null))
                staleUnloads++
            }
        }
    }

    private fun nearestDistance(tx: Int, tz: Int, size: Int, px: Float, pz: Float): Float =
        FarTileMath.nearest((tx * size).toFloat(), (tz * size).toFloat(), size.toFloat(), px, pz)

    private fun farthestDistance(tx: Int, tz: Int, size: Int, px: Float, pz: Float): Float =
        FarTileMath.farthest((tx * size).toFloat(), (tz * size).toFloat(), size.toFloat(), px, pz)

    // ---- tile construction ----------------------------------------------------------------

    private fun buildTile(level: Int, tx: Int, tz: Int): FarTile {
        val size = tileBlocks(level)
        val x0 = tx * size
        val z0 = tz * size
        val cells = cellsOf(level)

        // The ground of every column of the tile plus a one-column ring around it, so the walls along the tile's
        // edges know their neighbours.
        val field = columns.buildField(level, tx * cells, tz * cells, cells)
        val hasLand = field.highest + LAND_Y_OFFSET > landFloor(level)
        val hasWater = field.lowest + LAND_Y_OFFSET < WATER_Y
        val land = if (hasLand) columns.buildLandMesh(level, tx, tz, x0, z0, field) else MeshData.EMPTY
        val water = if (hasWater) FarWaterMesher.build(level, x0, z0, field.heights) else MeshData.EMPTY

        var minY = Float.MAX_VALUE
        var maxY = -Float.MAX_VALUE
        if (!land.isEmpty()) {
            minY = land.minY
            maxY = land.maxY
        }
        if (!water.isEmpty()) {
            minY = min(minY, WATER_Y)
            maxY = max(maxY, WATER_Y)
        }
        if (minY > maxY) {
            minY = WATER_Y
            maxY = WATER_Y
        }
        return FarTile(tileKey(level, tx, tz), land, water, minY, maxY)
    }

    companion object {
        /** Number of levels of distant terrain (0 = finest). */
        const val LEVELS = FarLevels.COUNT

        /** Most columns along a tile edge. */
        const val MAX_CELLS = FarLevels.MAX_CELLS

        /** Floats per vertex of the land meshes (see [FarLevels.LAND_FLOATS]). */
        const val LAND_FLOATS = FarLevels.LAND_FLOATS

        /** Voxel water surfaces sit at SEA_LEVEL + 0.875 (see ChunkMesher). */
        const val WATER_Y = FarLevels.WATER_Y

        fun cellsOf(level: Int): Int = FarLevels.cellsOf(level)
        fun step(level: Int): Int = FarLevels.step(level)

        /** Tile edge in blocks: 64, 256, 512, 512, 1024, 2048, 4096, 8192. */
        fun tileBlocks(level: Int): Int = FarLevels.tileBlocks(level)

        /** Short names for the on-screen statistics and the diagnostic log. */
        fun levelName(level: Int): String = FarLevels.levelName(level)

        // ---- the rings (see FarRings) ----

        /** Places the thin finest ring (level 0) just behind the voxel area, or takes it away. */
        fun configureFineRing(voxelFadeStart: Float, allowed: Boolean) = FarRings.configureFineRing(voxelFadeStart, allowed)

        fun fineInner(): Float = FarRings.fineInner()
        fun fineOuter(): Float = FarRings.fineOuter()

        /** Inner edge of the area a level's tiles are built for. */
        fun planInner(level: Int): Float = FarRings.planInner(level)

        /** Where a level is drawn from. */
        fun drawInner(level: Int): Float = FarRings.drawInner(level)

        /** Exact outer edge of a level's distance band (the next level starts there). */
        fun drawOuter(level: Int): Float = FarRings.drawOuter(level)

        /** Distance from the player at which a level starts sliding to its parent's shape and colours. */
        fun morphStart(level: Int): Float = FarRings.morphStart(level)

        /** Tiles are planned this much beyond a band's edge, so walking on between replans
         *  never uncovers the ring. Moving fast is covered separately: the plan also reaches to where
         *  the player will be in [PREFETCH_SECONDS] (see [predictedPosition]). */
        private const val PLAN_MARGIN = 24f

        /** How many seconds ahead of the player the plan reaches (at their current velocity), and at most
         *  how many blocks. */
        private const val PREFETCH_SECONDS = 2f
        private const val MAX_PREFETCH = 360f

        /** A tile is unloaded only this far (blocks) beyond the edge of the plan. */
        private const val UNLOAD_SLACK = 96f

        /** The player's speed is measured over windows of this length. */
        private const val SPEED_WINDOW_NS = 100_000_000L

        /** The tile budget never shrinks below this share, whatever the OS asks for: below it the
         *  horizon would start to come in over ground that is on screen. */
        private const val MIN_BUDGET_SCALE = 0.4f

        /** What a tile of each level weighs on the GPU, as a first guess for the budget until real
         *  tiles have been built (the running average takes over). Measured with the real generator on rough
         *  mountain terrain, the heaviest kind (about 0.20, 1.05, 0.88, 0.24, 0.24, 0.28 and 0.29 MB for levels
         *  0 to 6; level 7 has no tile in a normal view and is taken as level 6), plus about a tenth of headroom. */
        private val DEFAULT_TILE_BYTES = intArrayOf(220_000, 1_150_000, 970_000, 260_000, 265_000, 310_000, 320_000, 320_000)

        /** Distant water of a level keeps drawing this far past its band's outer edge, so
         *  the flat translucent rings overlap by a sliver instead of leaving a hairline gap. */
        const val WATER_OVERLAP = 1.5f

        private const val MAX_QUEUED_EVENTS = 12

        /** Hard bound for the render distance the planner will work with (blocks). */
        const val MAX_RADIUS_BLOCKS = 20_000f

        /** What a published tile occupies on the GPU: 32-bit indices and float vertices (land and water: 6 floats
         *  per vertex), both layers. */
        fun tileSizeBytes(tile: FarTile): Int {
            val land = tile.land.vertexCount.toLong() * LAND_FLOATS * 4 + tile.land.indices.size.toLong() * 4
            val water = tile.water.vertexCount.toLong() * 6 * 4 + tile.water.indices.size.toLong() * 4
            return (land + water).coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
        }

        /** The most GPU memory the distant terrain may hold: a quarter of the app's heap ceiling (a proxy
         *  for how much memory the device has to share between CPU and GPU), between 96 and 192 MB. The
         *  two finest rings alone need ~45 MB and the level ladder keeps the 1000-chunk maximum around
         *  90 MB on ordinary terrain, so this is a safety ceiling (rough, mountainous worlds produce more
         *  wall geometry), not a limit the normal case meets. */
        fun budgetForThisDevice(): Long = try {
            (Runtime.getRuntime().maxMemory() / 4).coerceIn(96L * 1024 * 1024, 192L * 1024 * 1024)
        } catch (t: Throwable) {
            128L * 1024 * 1024
        }

        private const val REPLAN_DISTANCE = 24f

        // Tile key = level (3 bits) | tx (29 bits, signed) | tz (29 bits, signed).
        private const val COORD_MASK = 0x1FFFFFFFL

        fun tileKey(level: Int, tx: Int, tz: Int): Long =
            (level.toLong() shl 58) or ((tx.toLong() and COORD_MASK) shl 29) or (tz.toLong() and COORD_MASK)

        fun levelOf(key: Long): Int = (key ushr 58).toInt()
        fun tileX(key: Long): Int = (((key ushr 29) and COORD_MASK).toInt() shl 3) shr 3
        fun tileZ(key: Long): Int = ((key and COORD_MASK).toInt() shl 3) shr 3
    }
}
