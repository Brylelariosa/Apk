package com.voxelsandbox.game.gl

import com.voxelsandbox.game.world.AtlasCell
import com.voxelsandbox.game.world.color.BiomePalette

/**
 * Which atlas tiles take the colour of the ground they stand on, and how: the one place that decides what is
 * "grass-coloured" and what is not. A tile that is not listed here (sand, stone, snow, gravel, dirt, water,
 * wood, ore, flowers, cacti...) is never touched by the biome colour field, which is what keeps sand from
 * going green and stone from taking the colour of the meadow next to it: the field says what green *is*
 * at a place, the table says what is painted green.
 *
 * A tinted tile is multiplied, texel by texel, by `field colour / anchor colour` (the shader does it, see
 * VoxelShader.applyTint), where the anchor is the climate colour the tile was drawn for: the lime of plain
 * grass, the straw of dry grass, the olive of swamp grass ([BiomePalette]). In the middle of that climate the
 * factor is 1, so the tile looks exactly as drawn; elsewhere its pattern stays, and its colour follows the field.
 *
 * Two kinds:
 *  - [Kind.WHOLE]: every opaque texel is tinted (the top of a grass block, leaves, tufts of tall grass).
 *  - [Kind.FRINGE]: only the grass part of the tile is tinted, the dirt below it is not (the side of a grass
 *    block). Which texels are grass is found by colour ([isGrassTexel], checked by a test); the atlas stores
 *    it in the alpha channel of the tile, which the opaque shaders do not otherwise read: grass texels get
 *    alpha 255 - [MASK_ALPHA_DROP], all others 255 (a drop small enough that the alpha-weighted mip
 *    chain barely shifts the colours, and large enough to survive the 8 bits and the filtering).
 *
 * [strength] is how much of the shift is applied (1 = all of it). Leaves take a part only: a spruce must
 * stay a spruce, and an oak in a swamp should be a little dark, not the colour of the mud.
 */
object TintTable {
    enum class Kind { WHOLE, FRINGE }

    /** The climate colour a tile was drawn for. */
    enum class Anchor { GRASS, DRY, SWAMP }

    class Entry(val cell: Int, val kind: Kind, val anchor: Anchor, val strength: Float)

    /** The alpha that marks a tinted texel of a [Kind.FRINGE] tile is 255 minus this. */
    const val MASK_ALPHA_DROP = 20

    /** How much of the climate shift leaves take (see the class comment); the distant terrain's trees use
     *  the same number (see world/far/FarGroundColor). */
    const val LEAF_STRENGTH = 0.7f

    val entries: List<Entry> = listOf(
        Entry(AtlasCell.GRASS_TOP, Kind.WHOLE, Anchor.GRASS, 1f),
        Entry(AtlasCell.GRASS_SIDE, Kind.FRINGE, Anchor.GRASS, 1f),
        Entry(AtlasCell.DRY_GRASS_TOP, Kind.WHOLE, Anchor.DRY, 1f),
        Entry(AtlasCell.DRY_GRASS_SIDE, Kind.FRINGE, Anchor.DRY, 1f),
        Entry(AtlasCell.SWAMP_GRASS_TOP, Kind.WHOLE, Anchor.SWAMP, 1f),
        Entry(AtlasCell.SWAMP_GRASS_SIDE, Kind.FRINGE, Anchor.SWAMP, 1f),
        Entry(AtlasCell.TALL_GRASS, Kind.WHOLE, Anchor.GRASS, 1f),
        Entry(AtlasCell.OAK_LEAVES, Kind.WHOLE, Anchor.GRASS, LEAF_STRENGTH),
        Entry(AtlasCell.BIRCH_LEAVES, Kind.WHOLE, Anchor.GRASS, LEAF_STRENGTH),
        Entry(AtlasCell.SPRUCE_LEAVES, Kind.WHOLE, Anchor.GRASS, LEAF_STRENGTH)
    )

    private val byCell: Map<Int, Entry> = entries.associateBy { it.cell }

    fun entryFor(cell: Int): Entry? = byCell[cell]

    /** True for a texel of a grass side tile that belongs to the grass and not to the soil under it: the
     *  green of grass leans towards green (or, for dry grass, is as red as it is green), the browns and
     *  greys of dirt and pebbles lean towards red. */
    fun isGrassTexel(argb: Int): Boolean {
        if ((argb ushr 24) < 128) return false
        return ((argb shr 8) and 0xFF) >= ((argb shr 16) and 0xFF) - 4
    }

    /** The tile as the atlas stores it: unchanged, except that the grass texels of a [Kind.FRINGE] tile carry
     *  their mask in the alpha channel (see the class comment). */
    fun atlasPixels(cell: Int, pixels: IntArray): IntArray {
        val entry = byCell[cell]
        if (entry == null || entry.kind != Kind.FRINGE) return pixels
        return IntArray(pixels.size) { i ->
            val p = pixels[i]
            if (isGrassTexel(p)) ((255 - MASK_ALPHA_DROP) shl 24) or (p and 0xFFFFFF) else p
        }
    }

    /** Number of cells of the atlas (the shader's table has one entry for each). */
    const val CELLS = TextureAtlas.GRID * TextureAtlas.GRID

    /**
     * The shader's table, [CELLS] entries of four floats: red, green and blue are 255 / anchor colour per
     * channel (so that `field colour (0..1) * entry = factor`), alpha is the strength, negative for a
     * [Kind.FRINGE] tile (the shader then also multiplies it by the texel's mask), 0 for a tile that is not
     * tinted at all.
     */
    fun shaderTable(palette: BiomePalette): FloatArray {
        val out = FloatArray(CELLS * 4)
        for (e in entries) {
            val (r, g, b) = when (e.anchor) {
                Anchor.GRASS -> Triple(palette.grassR, palette.grassG, palette.grassB)
                Anchor.DRY -> Triple(palette.dryR, palette.dryG, palette.dryB)
                Anchor.SWAMP -> Triple(palette.swampR, palette.swampG, palette.swampB)
            }
            val i = e.cell * 4
            out[i] = 255f / r
            out[i + 1] = 255f / g
            out[i + 2] = 255f / b
            out[i + 3] = if (e.kind == Kind.FRINGE) -e.strength else e.strength
        }
        return out
    }
}
