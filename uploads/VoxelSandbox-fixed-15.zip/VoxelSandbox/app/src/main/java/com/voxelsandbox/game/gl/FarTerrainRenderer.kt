package com.voxelsandbox.game.gl

import android.opengl.GLES30
import com.voxelsandbox.game.world.far.FarEvent
import com.voxelsandbox.game.world.far.FarStandIns
import com.voxelsandbox.game.world.far.FarTileMath
import com.voxelsandbox.game.world.far.FarTerrain
import com.voxelsandbox.game.world.streaming.UploadBudget
import java.util.concurrent.LinkedBlockingQueue
import kotlin.math.abs
import kotlin.math.max

/**
 * The GPU side of the distant terrain (see [FarTerrain] for how tiles are built): holds the
 * uploaded tile meshes and draws them, level by level, as an opaque land pass and a
 * translucent water pass. Everything here is GL-thread only.
 *
 * Every level is drawn inside its own ring around the player (the shader discards what lies
 * outside it); the columns of a level slide to the next level's heights as its ring ends (see
 * FarTerrain), so the rings meet with no overlap, no sinking and no step. The one place two
 * levels can claim the same ground is the thin finest ring (level 0) over level 1: level 1 is
 * the ground that is always built, level 0 only improves a ring of it, so each level-1 tile
 * hands that ring over to level 0 only once *all* the level-0 tiles it needs are on the GPU
 * (see [updateFineCoverage]), and takes it back otherwise. Never a hole, never two surfaces.
 *
 * Inside the voxel area the shader draws distant ground only in the chunk columns that have no
 * terrain on the GPU (the [CoverageMask]): a missing chunk shows distant ground, a loaded one
 * does not. Level 1 therefore also draws inside the ring it has handed over to level 0 (the
 * "skip" ring takes that part out), so such a hole is filled whether or not the ring is active.
 *
 * A tile of a ring that has not been built yet (the player moved faster than the builders, or a tile was just
 * evicted) is no hole in the picture either: the coarser tile of a level above that contains its footprint, if one is
 * on the GPU, is drawn in its place, clipped to the footprint and to the ring of the missing tile (see
 * [updateStandIns] and [FarStandIns]). When the real tile arrives it fades in over its stand-in by a dither (the two
 * draws share the pixels of the footprint, one the noise range [0, f), the other [f, 1)), so there is no second
 * surface to fight with and nothing in the geometry changes: the picture goes from the coarse bricks to the fine
 * ones without a pop.
 */
class FarTerrainRenderer {
    private class GpuTile(
        val key: Long,
        val land: ChunkGpuMesh?,
        val water: ChunkGpuMesh?,
        val level: Int,
        val x0: Float,
        val z0: Float,
        val size: Float,
        val minY: Float,
        val maxY: Float
    ) {
        /** When the tile arrived in a hole of the picture, for its fade-in; 0 for a tile that needs none (it arrived
         *  ahead of its ring, or replaced itself, or is of the optional finest level). */
        var fadeStartNs = 0L

        /** The coarser tile that stood in for this one while it was missing, or [FarStandIns.NONE]. */
        var standInKey = FarStandIns.NONE

        /** The share of the tile that is drawn at [now]: 0 .. 1 (1 for a tile that is not fading). */
        fun fade(now: Long): Float {
            if (fadeStartNs == 0L) return 1f
            val t = (now - fadeStartNs).toFloat() / FADE_NS
            return if (t >= 1f) 1f else if (t <= 0f) 0f else t
        }

        fun dispose() {
            land?.dispose()
            water?.dispose()
        }
    }

    private val tiles = HashMap<Long, GpuTile>()

    private lateinit var program: ShaderProgram
    private lateinit var clipDither: ClipDither
    private val noise = FarNoiseTexture()
    private var uViewProj = 0
    private var uCamOrigin = 0
    private var uNoise = 0
    private var uFogColor = 0
    private var uFogStart = 0
    private var uFogEnd = 0
    private var uCenter = 0
    private var uBand = 0
    private var uSkip = 0
    private var uVoxel = 0
    private var uCover = 0

    // Which level-1 tiles currently hand the finest ring over to level 0 (see the class note).
    private var coveredKeys = LongArray(64)
    private var coveredCount = 0
    private var coverageDirty = true
    private var coverageEyeX = 0f
    private var coverageEyeZ = 0f
    private var coverageFineIn = -1f
    private var coverageFineOut = -1f

    // The tiles of the rings that are on screen but not on the GPU, each with the coarser tile that stands in for it
    // (null: none is there either); see updateStandIns. Rebuilt when tiles come or go, or the player has moved.
    private var holeKeys = LongArray(32)
    private var holeSources = arrayOfNulls<GpuTile>(32)
    private var holeCount = 0
    private var holesDirty = true
    private var holeEyeX = 0f
    private var holeEyeZ = 0f
    private var holeFogEnd = 0f
    private var holeClipRadius = 0f

    // The tiles that arrived in a hole and are still fading in.
    private val fading = ArrayList<GpuTile>()

    // Stats for the FPS overlay and the diagnostic log.
    var drawnTiles = 0
        private set
    var totalTiles = 0
        private set
    var drawnTriangles = 0
        private set

    /** Stand-in draws of last frame's land pass (holes filled by a coarser tile, plus tiles fading in). */
    var standIns = 0
        private set

    /** Land triangles drawn last frame, per level (level 0 = LOD 1 ... level 7 = far256). */
    val levelTriangles = IntArray(FarTerrain.LEVELS)

    /** Tiles drawn last frame, per level. */
    val levelTiles = IntArray(FarTerrain.LEVELS)

    /** Zeroes the overlay statistics (used on frames where distant terrain is not drawn). */
    fun clearStats() {
        drawnTiles = 0
        totalTiles = 0
        drawnTriangles = 0
        standIns = 0
        for (i in levelTriangles.indices) {
            levelTriangles[i] = 0
            levelTiles[i] = 0
        }
    }

    fun init() {
        program = ShaderProgram(Shaders.FAR_VERTEX, Shaders.FAR_FRAGMENT)
        uViewProj = program.uniform("uViewProj")
        uCamOrigin = program.uniform("uCamOrigin")
        uNoise = program.uniform("uNoise")
        uFogColor = program.uniform("uFogColor")
        uFogStart = program.uniform("uFogStart")
        uFogEnd = program.uniform("uFogEnd")
        uCenter = program.uniform("uCenter")
        uBand = program.uniform("uBand")
        uSkip = program.uniform("uSkip")
        uVoxel = program.uniform("uVoxel")
        uCover = program.uniform("uCover")
        clipDither = ClipDither(program.uniform("uClip"), program.uniform("uDither"))
        noise.upload()
        coverageDirty = true
        holesDirty = true
    }

    /** The GL context was recreated: every handle is dead, forget them (no GL calls). */
    fun invalidateForContextLoss() {
        for (tile in tiles.values) {
            tile.land?.invalidateForContextLoss()
            tile.water?.invalidateForContextLoss()
        }
        tiles.clear()
        fading.clear()
        coveredCount = 0
        holeCount = 0
        coverageDirty = true
        holesDirty = true
    }

    /** Bytes handed to the driver by the last [drain] (for the stats overlay and the log). */
    var lastUploadBytes = 0
        private set

    /**
     * Applies tile adds/removals in the order the builder produced them. A removal costs nothing and is always
     * applied. A tile upload is a copy of up to a couple of megabytes (the biggest are about 1.6 MB), so uploads
     * stop once [byteBudget] bytes have gone to the driver or [nanoBudget] nanoseconds have passed since
     * [startNs]; the first upload of a call always goes, so a tile bigger than the whole budget is slow, never
     * stuck. A rebuilt tile replaces its predecessor in the same call, so there is no frame without it.
     * A tile that arrives where the picture had a hole starts a fade-in (see the class note).
     * Returns how many tiles were uploaded.
     */
    fun drain(events: LinkedBlockingQueue<FarEvent>, byteBudget: Int, nanoBudget: Long, startNs: Long): Int {
        var uploads = 0
        var bytes = 0L
        while (true) {
            val event = events.peek() ?: break // (only this thread takes events, so the one polled below is this one)
            val tile = event.tile
            val size = if (tile != null) FarTerrain.tileSizeBytes(tile) else 0
            if (tile != null && !UploadBudget.admits(uploads, bytes, size, byteBudget, System.nanoTime() - startNs, nanoBudget)) break
            events.poll()
            val old = tiles.remove(event.key)
            if (old != null) {
                old.dispose()
                if (old.fadeStartNs != 0L) fading.remove(old)
            }
            coverageDirty = true
            holesDirty = true
            if (tile == null) continue

            var land: ChunkGpuMesh? = null
            if (!tile.land.isEmpty()) {
                land = ChunkGpuMesh()
                land.upload(tile.land)
            }
            var water: ChunkGpuMesh? = null
            if (!tile.water.isEmpty()) {
                water = ChunkGpuMesh()
                water.upload(tile.water)
            }
            val gpu = GpuTile(event.key, land, water, tile.level, tile.x0, tile.z0, tile.size, tile.minY, tile.maxY)
            val hole = holeIndexOf(event.key)
            if (hole >= 0) {
                // It was missing from the picture: fade in over what stood in for it (if anything did).
                gpu.fadeStartNs = System.nanoTime()
                gpu.standInKey = holeSources[hole]?.key ?: FarStandIns.NONE
                fading.add(gpu)
            }
            tiles[event.key] = gpu
            bytes += size
            uploads++
        }
        lastUploadBytes = bytes.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
        return uploads
    }

    // ---- the finest ring ------------------------------------------------------------------

    /**
     * Decides which level-1 tiles give the finest ring (level 0) their ground this frame: those for
     * which every level-0 tile of the ring inside them has been uploaded. The answer only changes
     * when tiles arrive or leave or the player has moved a few blocks, so it is cached.
     *
     * It does not depend on what the voxel terrain covers (it used to, which switched the whole ring
     * on and off whenever one chunk was momentarily missing): the shader fills holes in the voxel
     * area itself, from the coverage mask, with level 1.
     */
    private fun updateFineCoverage(frame: FrameState) {
        val fineIn = FarTerrain.fineInner()
        val fineOut = FarTerrain.fineOuter()
        if (fineOut <= 0f) {
            coveredCount = 0
            return
        }
        val moved = abs(frame.eyeX - coverageEyeX) + abs(frame.eyeZ - coverageEyeZ)
        if (!coverageDirty && moved < 6f && coverageFineIn == fineIn && coverageFineOut == fineOut) return
        coverageDirty = false
        coverageEyeX = frame.eyeX
        coverageEyeZ = frame.eyeZ
        coverageFineIn = fineIn
        coverageFineOut = fineOut

        coveredCount = 0
        val sizeFine = FarTerrain.tileBlocks(0)
        val ratio = FarTerrain.tileBlocks(1) / sizeFine
        for (tile in tiles.values) {
            if (tile.level != 1) continue
            val tx1 = FarTerrain.tileX(tile.key)
            val tz1 = FarTerrain.tileZ(tile.key)
            var covered = true
            var needed = 0
            for (b in 0 until ratio) {
                for (a in 0 until ratio) {
                    val cx = tx1 * ratio + a
                    val cz = tz1 * ratio + b
                    val x0 = (cx * sizeFine).toFloat()
                    val z0 = (cz * sizeFine).toFloat()
                    val near = FarTileMath.nearest(x0, z0, sizeFine.toFloat(), frame.eyeX, frame.eyeZ)
                    if (near >= fineOut) continue
                    val far = FarTileMath.farthest(x0, z0, sizeFine.toFloat(), frame.eyeX, frame.eyeZ)
                    if (far <= fineIn) continue
                    needed++
                    if (!tiles.containsKey(FarTerrain.tileKey(0, cx, cz))) covered = false
                }
            }
            if (covered && needed > 0) {
                if (coveredCount == coveredKeys.size) coveredKeys = coveredKeys.copyOf(coveredCount * 2)
                coveredKeys[coveredCount++] = tile.key
            }
        }
    }

    private fun isCovered(level1Key: Long): Boolean {
        for (i in 0 until coveredCount) {
            if (coveredKeys[i] == level1Key) return true
        }
        return false
    }

    /** Key of the level-1 tile that contains a level-0 tile (tiles are aligned). */
    private fun parentKeyOf(tile: GpuTile): Long {
        val ratio = FarTerrain.tileBlocks(1) / FarTerrain.tileBlocks(0)
        return FarTerrain.tileKey(
            1,
            Math.floorDiv(FarTerrain.tileX(tile.key), ratio),
            Math.floorDiv(FarTerrain.tileZ(tile.key), ratio)
        )
    }

    // ---- holes and their stand-ins --------------------------------------------------------

    /**
     * Finds the tiles of levels 1 and up that the picture needs (their ring is on screen: inside the fog, outside the
     * circle the voxel terrain covers completely) but that are not on the GPU, and the finest coarser tile that
     * contains each (see [FarStandIns]). The result changes only when tiles arrive or leave, or the player has
     * moved a few blocks, so it is cached, like the finest ring's coverage.
     *
     * Level 0 is not among them: it only improves ground that level 1 already draws (see [updateFineCoverage]).
     */
    private fun updateStandIns(frame: FrameState) {
        val moved = abs(frame.eyeX - holeEyeX) + abs(frame.eyeZ - holeEyeZ)
        if (!holesDirty && moved < HOLE_RECHECK_BLOCKS &&
            abs(frame.fogEnd - holeFogEnd) < HOLE_RECHECK_BLOCKS && abs(frame.clipRadius - holeClipRadius) < HOLE_RECHECK_BLOCKS
        ) return
        holesDirty = false
        holeEyeX = frame.eyeX
        holeEyeZ = frame.eyeZ
        holeFogEnd = frame.fogEnd
        holeClipRadius = frame.clipRadius
        holeCount = 0

        val reach = frame.fogEnd + 2f
        val clip2 = frame.clipRadius * frame.clipRadius
        for (level in 1 until FarTerrain.LEVELS) {
            val outer = FarTerrain.drawOuter(level)
            if (outer <= 0f) continue
            val inner = FarTerrain.drawInner(level)
            if (inner >= reach) break // this ring and every one after it begins beyond what can be seen
            val size = FarTerrain.tileBlocks(level).toFloat()
            FarStandIns.forEachRingTile(level, frame.eyeX, frame.eyeZ, inner, outer, reach) { key ->
                if (tiles.containsKey(key)) return@forEachRingTile
                val x0 = FarTerrain.tileX(key) * size
                val z0 = FarTerrain.tileZ(key) * size
                // entirely inside the circle the voxel terrain covers: nothing of it is ever drawn
                val cx = max(abs(frame.eyeX - x0), abs(frame.eyeX - (x0 + size)))
                val cz = max(abs(frame.eyeZ - z0), abs(frame.eyeZ - (z0 + size)))
                if (cx * cx + cz * cz < clip2) return@forEachRingTile
                if (holeCount == holeKeys.size) {
                    holeKeys = holeKeys.copyOf(holeCount * 2)
                    holeSources = holeSources.copyOf(holeCount * 2)
                }
                val source = FarStandIns.find(key) { tiles.containsKey(it) }
                holeKeys[holeCount] = key
                holeSources[holeCount] = if (source == FarStandIns.NONE) null else tiles[source]
                holeCount++
            }
        }
    }

    private fun holeIndexOf(key: Long): Int {
        for (i in 0 until holeCount) {
            if (holeKeys[i] == key) return i
        }
        return -1
    }

    // ---- drawing --------------------------------------------------------------------------

    /** Sets the ring [inner], [outer] (and the ring [skipIn], [skipOut] another level draws) for a draw of a tile of
     *  [level]: the tile slides to its parent's shape from its own morph range, whatever ring it is drawn in. */
    private fun applyBand(level: Int, inner: Float, outer: Float, skipIn: Float, skipOut: Float) {
        // The coarsest level has nothing to slide to: park the slide range far out of reach
        // (smoothstep needs edge0 < edge1, and 1e9 + 1 is not representable).
        val last = level == FarTerrain.LEVELS - 1
        val mStart = if (last) 2.0e9f else FarTerrain.morphStart(level)
        val mEnd = if (last) 3.0e9f else max(FarTerrain.drawOuter(level), mStart + 1f)
        GLES30.glUniform4f(uBand, inner, outer, mStart, mEnd)
        GLES30.glUniform2f(uSkip, skipIn, skipOut)
    }

    /** Opaque ground. Each level draws only inside its own ring (enforced in the shader). */
    fun drawLand(frame: FrameState, frustum: Frustum) {
        drawnTiles = 0
        drawnTriangles = 0
        totalTiles = tiles.size
        standIns = 0
        for (i in levelTriangles.indices) {
            levelTriangles[i] = 0
            levelTiles[i] = 0
        }
        updateFineCoverage(frame)
        updateStandIns(frame)
        if (tiles.isEmpty()) return
        val now = System.nanoTime()

        program.use()
        GLES30.glUniformMatrix4fv(uViewProj, 1, false, frame.viewProj, 0)
        GLES30.glUniform3f(uCamOrigin, frame.originX, frame.originY, frame.originZ)
        GLES30.glUniform3f(uFogColor, frame.fogR, frame.fogG, frame.fogB)
        GLES30.glUniform1f(uFogStart, frame.fogStart)
        GLES30.glUniform1f(uFogEnd, frame.fogEnd)
        noise.bind(NOISE_UNIT)
        GLES30.glUniform1i(uNoise, NOISE_UNIT)
        GLES30.glUniform1i(uCover, CoverageMask.UNIT) // bound once per frame by GameRenderer
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        // Inside this radius real chunks stand alone; the shader fills only the columns that have no
        // terrain yet. From it outwards the voxel terrain dissolves, with this ground behind it.
        GLES30.glUniform2f(uVoxel, frame.fadeStart, frame.fadeStart + frame.fadeWidth)
        GLES30.glUniform2f(uCenter, frame.eyeX, frame.eyeZ)
        clipDither.reset()

        val fineIn = FarTerrain.fineInner()
        val fineOut = FarTerrain.fineOuter()
        for (level in 0 until FarTerrain.LEVELS) {
            if (level == 0 && fineOut <= 0f) continue
            val outer = FarTerrain.drawOuter(level)
            if (outer <= 0f) continue
            var lastInner = -1f
            var lastSkip = -1f
            for (tile in tiles.values) {
                if (tile.level != level) continue
                val land = tile.land ?: continue
                val inner = FarTerrain.drawInner(level)
                // A level-1 tile whose part of the finest ring is complete leaves that ring to level 0.
                val skip = level == 1 && isCovered(tile.key)
                if (level == 0 && !isCovered(parentKeyOf(tile))) continue
                // A handed-over tile has nothing to show inside the finest ring's inner edge unless a column
                // there is missing its terrain; when every column up to that edge is known to be covered
                // (the usual case) it is culled the way a tile of the ring's own band is.
                val cullInner = if (skip && frame.provenRadius >= fineIn) fineOut else inner
                if (!isVisible(tile, frame, frustum, cullInner, outer, frame.clipRadius)) continue
                val share = tile.fade(now)
                if (share <= 0f) continue
                val skipIn = if (skip) fineIn else 0f
                if (inner != lastInner || skipIn != lastSkip) {
                    applyBand(level, inner, outer, skipIn, if (skip) fineOut else 0f)
                    lastInner = inner
                    lastSkip = skipIn
                }
                if (share < 1f) clipDither.dither(0f, share) else clipDither.undither()
                land.draw()
                drawnTiles++
                drawnTriangles += land.triangleCount
                levelTiles[level]++
                levelTriangles[level] += land.triangleCount
            }
        }
        clipDither.undither()
        drawLandStandIns(frame, frustum, now)
        clipDither.reset()
        GLES30.glUniform2f(uSkip, 0f, 0f)
    }

    /** Draws, for every hole of the picture, the coarser tile that stands in for it, and, under every tile that is
     *  still fading in, the coarser tile that stood in for it (through the pixels the tile does not take). */
    private fun drawLandStandIns(frame: FrameState, frustum: Frustum, now: Long) {
        for (i in 0 until holeCount) {
            val source = holeSources[i] ?: continue
            val key = holeKeys[i]
            val level = FarTerrain.levelOf(key)
            val size = FarTerrain.tileBlocks(level).toFloat()
            drawLandStandIn(frame, frustum, level, FarTerrain.tileX(key) * size, FarTerrain.tileZ(key) * size, size, source, 0f, 1f, false)
        }
        var i = 0
        while (i < fading.size) {
            val tile = fading[i]
            val share = tile.fade(now)
            if (share >= 1f || tiles[tile.key] !== tile) {
                tile.fadeStartNs = 0L
                fading.removeAt(i)
                continue
            }
            i++
            val source = tiles[tile.standInKey] ?: continue
            val skip = tile.level == 1 && isCovered(tile.key)
            drawLandStandIn(frame, frustum, tile.level, tile.x0, tile.z0, tile.size, source, share, 1f, skip)
        }
        clipDither.unclip()
        clipDither.undither()
    }

    /** One stand-in draw: [source] (a tile of a coarser level) shown through the square ([x0], [z0], [size]) in the
     *  ring of [level], on the pixels with noise in [lo, hi). */
    private fun drawLandStandIn(
        frame: FrameState, frustum: Frustum, level: Int, x0: Float, z0: Float, size: Float,
        source: GpuTile, lo: Float, hi: Float, skip: Boolean
    ) {
        val land = source.land ?: return
        val inner = FarTerrain.drawInner(level)
        val outer = FarTerrain.drawOuter(level)
        if (!isVisible(x0, z0, size, source.minY, source.maxY, frame, frustum, inner, outer, frame.clipRadius)) return
        applyBand(source.level, inner, outer, if (skip) FarTerrain.fineInner() else 0f, if (skip) FarTerrain.fineOuter() else 0f)
        clipDither.clip(x0, z0, x0 + size, z0 + size)
        clipDither.dither(lo, hi)
        land.draw()
        standIns++
        drawnTriangles += land.triangleCount
    }

    /** Translucent sea / lake surfaces, to be drawn between [WaterRenderer.begin] and
     *  [WaterRenderer.end] after [drawLand]. */
    fun drawWater(frame: FrameState, frustum: Frustum, water: WaterRenderer) {
        if (tiles.isEmpty()) return
        water.useFarArea()
        val now = System.nanoTime()
        val dither = water.clipDither
        // The rings of flat water overlap by a sliver (FarTerrain.WATER_OVERLAP): a hairline gap
        // would show the dark ground under the sea as a ring, and the sliver is invisible
        // because far water is drawn all but solid.
        val fineIn = FarTerrain.fineInner()
        val fineOut = FarTerrain.fineOuter()
        for (level in FarTerrain.LEVELS - 1 downTo 0) {
            if (level == 0 && fineOut <= 0f) continue
            val outer = FarTerrain.drawOuter(level)
            if (outer <= 0f) continue
            var lastInner = -1f
            var lastSkip = -1f
            for (tile in tiles.values) {
                if (tile.level != level) continue
                val mesh = tile.water ?: continue
                val inner = FarTerrain.drawInner(level)
                val skip = level == 1 && isCovered(tile.key)
                if (level == 0 && !isCovered(parentKeyOf(tile))) continue
                val outerDrawn = waterOuter(level, outer)
                val cullInner = if (skip && frame.provenRadius >= fineIn) fineOut else inner
                if (!isVisible(tile, frame, frustum, cullInner, outerDrawn, frame.clipRadius)) continue
                val share = tile.fade(now)
                if (share <= 0f) continue
                val skipIn = if (skip) fineIn else 0f
                if (inner != lastInner || skipIn != lastSkip) {
                    water.setBand(inner, outerDrawn, skipIn, if (skip) fineOut else 0f)
                    lastInner = inner
                    lastSkip = skipIn
                }
                if (share < 1f) dither.dither(0f, share) else dither.undither()
                mesh.draw()
                drawnTriangles += mesh.triangleCount
            }
        }
        dither.undither()
        drawWaterStandIns(frame, frustum, water, now)
        dither.unclip()
        dither.undither()
        water.setBand(0f, 1.0e9f)
    }

    /** The water counterpart of [drawLandStandIns]. */
    private fun drawWaterStandIns(frame: FrameState, frustum: Frustum, water: WaterRenderer, now: Long) {
        for (i in 0 until holeCount) {
            val source = holeSources[i] ?: continue
            val key = holeKeys[i]
            val level = FarTerrain.levelOf(key)
            val size = FarTerrain.tileBlocks(level).toFloat()
            drawWaterStandIn(frame, frustum, water, level, FarTerrain.tileX(key) * size, FarTerrain.tileZ(key) * size, size, source, 0f, 1f, false)
        }
        for (i in 0 until fading.size) {
            val tile = fading[i]
            val share = tile.fade(now)
            if (share >= 1f || tiles[tile.key] !== tile) continue // (pruned by the land pass)
            val source = tiles[tile.standInKey] ?: continue
            val skip = tile.level == 1 && isCovered(tile.key)
            drawWaterStandIn(frame, frustum, water, tile.level, tile.x0, tile.z0, tile.size, source, share, 1f, skip)
        }
    }

    private fun drawWaterStandIn(
        frame: FrameState, frustum: Frustum, water: WaterRenderer, level: Int, x0: Float, z0: Float, size: Float,
        source: GpuTile, lo: Float, hi: Float, skip: Boolean
    ) {
        val mesh = source.water ?: return
        val inner = FarTerrain.drawInner(level)
        val outerDrawn = waterOuter(level, FarTerrain.drawOuter(level))
        if (!isVisible(x0, z0, size, source.minY, source.maxY, frame, frustum, inner, outerDrawn, frame.clipRadius)) return
        water.setBand(inner, outerDrawn, if (skip) FarTerrain.fineInner() else 0f, if (skip) FarTerrain.fineOuter() else 0f)
        water.clipDither.clip(x0, z0, x0 + size, z0 + size)
        water.clipDither.dither(lo, hi)
        mesh.draw()
        drawnTriangles += mesh.triangleCount
    }

    private fun waterOuter(level: Int, outer: Float): Float =
        if (level == FarTerrain.LEVELS - 1) outer else outer + FarTerrain.WATER_OVERLAP

    /** True if some part of the tile can be on screen: inside the ring, outside the circle of radius
     *  [clipRadius] around the eye (where the voxel terrain is certainly complete) and inside the
     *  view frustum. */
    private fun isVisible(tile: GpuTile, frame: FrameState, frustum: Frustum, inner: Float, outer: Float, clipRadius: Float): Boolean =
        isVisible(tile.x0, tile.z0, tile.size, tile.minY, tile.maxY, frame, frustum, inner, outer, clipRadius)

    /** [isVisible] for the square ([x0], [z0], [size]) whose ground reaches from [minY] to [maxY]. */
    private fun isVisible(
        x0: Float, z0: Float, size: Float, minY: Float, maxY: Float,
        frame: FrameState, frustum: Frustum, inner: Float, outer: Float, clipRadius: Float
    ): Boolean {
        val x1 = x0 + size
        val z1 = z0 + size

        // distance from the player to the nearest / farthest point of the tile
        val near = FarTileMath.nearest(x0, z0, size, frame.eyeX, frame.eyeZ)
        if (near > outer) return false
        // A tile that starts beyond the fog's end is pure fog colour (which is also what the
        // sky is at and below the horizon), so drawing it would only cost triangles.
        if (near > frame.fogEnd + 2f) return false
        if (FarTileMath.farthest(x0, z0, size, frame.eyeX, frame.eyeZ) < inner) return false

        // entirely inside the circle real chunks cover?
        val cx = max(abs(frame.eyeX - x0), abs(frame.eyeX - x1))
        val cz = max(abs(frame.eyeZ - z0), abs(frame.eyeZ - z1))
        if (cx * cx + cz * cz < clipRadius * clipRadius) return false

        return frustum.isBoxVisible(x0, minY - 2f, z0, x1, maxY + 2f, z1)
    }

    private companion object {
        /** Texture unit of the far-terrain noise (0 = block atlas, 1 = water tile). */
        const val NOISE_UNIT = 2

        /** How long a tile that arrived in a hole takes to fade in over its stand-in. */
        const val FADE_NS = 450_000_000L

        /** The holes are looked for again once the eye (or the fog, or the circle the voxel terrain covers) has
         *  changed by this much. */
        const val HOLE_RECHECK_BLOCKS = 6f
    }
}
