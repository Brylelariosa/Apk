package com.voxelsandbox.game.engine

import com.voxelsandbox.game.diag.DiagLog
import com.voxelsandbox.game.engine.fx.ParticleSystem
import com.voxelsandbox.game.gl.TextureAtlas
import com.voxelsandbox.game.input.InputState
import com.voxelsandbox.game.inventory.Hotbar
import com.voxelsandbox.game.player.Player
import com.voxelsandbox.game.player.FlightMath
import com.voxelsandbox.game.player.PhysicsController
import com.voxelsandbox.game.player.Raycaster
import com.voxelsandbox.game.player.RaycastHit
import com.voxelsandbox.game.save.LoadedSave
import com.voxelsandbox.game.settings.GameSettings
import com.voxelsandbox.game.world.BlockType
import com.voxelsandbox.game.world.ChunkPos
import com.voxelsandbox.game.world.Fluid
import com.voxelsandbox.game.world.FluidSimulator
import com.voxelsandbox.game.world.World
import com.voxelsandbox.game.world.WorldConfig
import com.voxelsandbox.game.world.WorldManager
import com.voxelsandbox.game.world.far.FarTerrain
import com.voxelsandbox.game.world.color.BiomeColorField
import com.voxelsandbox.game.world.color.BiomePalette
import com.voxelsandbox.game.world.generation.TerrainGenerator
import java.util.Locale
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.random.Random

/**
 * The GL-agnostic game loop: physics, input interpretation, world-streaming input,
 * and break/place actions. GameRenderer calls [update] once per frame from the GL
 * thread and then reads the exposed state (player, world, particles, ...) to draw.
 */
class GameEngine(val settings: GameSettings, savedGame: LoadedSave?) {
    val world = World()
    val seed: Long = savedGame?.seed ?: Random.nextLong()
    private val generator = TerrainGenerator(seed)
    val atlas = TextureAtlas()
    val worldManager = WorldManager(world, generator, atlas, savedGame?.chunkOverrides ?: emptyMap())
    /** The colour of grass over the whole world (see BiomeColorField): the voxel shaders read it as a texture
     *  around the eye, the distant terrain evaluates it per vertex, so both agree. */
    val biomeColors = BiomeColorField(generator.climate, generator.shape, BiomePalette.fromTiles())
    val farTerrain = FarTerrain(generator, biomeColors)

    /** Automatic Render Distance (only does anything while the setting is on; see [DistanceGovernor]).
     *  Fed frame times by the renderer; the settings screen reads the effective distance from it. */
    val distanceGovernor = DistanceGovernor().apply {
        listener = DistanceGovernor.Listener { scale, text ->
            DiagLog.governor(scale)
            DiagLog.note("auto distance: $text")
        }
    }

    /** Makes water flow: spreads into holes the player digs, falls down shafts, recedes when
     *  its source is covered. Driven by block edits (see [FluidSimulator]). */
    private val fluid = FluidSimulator(world, worldManager)

    val player = Player()
    private val physics = PhysicsController(world)
    val hotbar = Hotbar()
    val particles = ParticleSystem()
    val input = InputState()

    private val spawnPos: ChunkPos
    private var breakCooldown = 0f
    private var placeCooldown = 0f
    private var bobPhase = 0f

    // flight and the destroy laser
    private var timeSec = 0f
    private var lastJumpPress = -10f
    private var lastJumpHeld = false
    private var landedFor = 0f
    private var laserTimer = 0f
    private val flightVelocity = FloatArray(3)
    private val flightTarget = FloatArray(3)

    /** True while the destroy laser is firing (the renderer draws the beam). */
    var laserActive = false
        private set

    var bobOffset = 0f
        private set
    var lastHit: RaycastHit? = null
        private set

    init {
        if (savedGame != null) {
            player.position.set(savedGame.playerX, savedGame.playerY, savedGame.playerZ)
            player.yaw = savedGame.yaw
            player.pitch = savedGame.pitch
            hotbar.restore(savedGame.hotbarIds, savedGame.hotbarSelected)
            player.flying = savedGame.flying
            player.waitingForSpawn = false // saved position is already known-good ground
        }
        if (savedGame == null) {
            // New world: start on dry, gentle ground rather than wherever (0, 0) happens to be
            // (it could be the middle of an ocean). The search is a pure function of the seed.
            val spawn = generator.findSpawn()
            player.position.set(spawn.x + 0.5f, player.position.y, spawn.z + 0.5f)
        }
        spawnPos = ChunkPos.fromWorld(player.position.x, player.position.z)
        worldManager.requestImmediateChunk(spawnPos)
        worldManager.start()
        pushFarTerrainState()
        farTerrain.start()
    }

    fun shutdown() {
        worldManager.shutdown()
        farTerrain.shutdown()
    }

    /** Feeds the distant-terrain builder the player position and the current settings.
     *  Called every frame (it only stores a few volatile fields), including while the
     *  spawn chunk is still generating, so the horizon appears immediately. */
    private fun pushFarTerrainState() {
        // The distant terrain gives memory back in step with the chunks (see MemoryPolicy): only when
        // memory really is short, and by the same slow, rate-limited amount.
        farTerrain.setBudgetScale(worldManager.memoryFactor)
        farTerrain.updatePlayer(
            player.position.x,
            player.position.z,
            settings.renderDistanceChunks * WorldConfig.CHUNK_SIZE.toFloat(),
            settings.farTerrain
        )
    }

    private val lookDelta = FloatArray(2)

    fun update(dt: Float) {
        val clampedDt = dt.coerceAtMost(0.05f) // guards against a huge dt after e.g. resuming from background

        pushFarTerrainState()
        if (player.waitingForSpawn) {
            if (worldManager.isChunkGenerated(spawnPos)) {
                dropPlayerToSurface()
                player.waitingForSpawn = false
            } else {
                return // hold everything until the spawn column actually exists
            }
        }

        input.consumeLookDelta(lookDelta)
        // A full-screen menu covers the controls: nothing it still reports may move or turn the player.
        val blocked = input.uiBlocked
        if (!blocked) {
            val lookSens = 0.0022f + settings.lookSensitivity * 0.0035f
            player.addLook(lookDelta[0] * lookSens, -lookDelta[1] * lookSens)
        }
        val moveForward = if (blocked) 0f else input.moveForward
        val moveStrafe = if (blocked) 0f else input.moveStrafe
        val jumpHeld = !blocked && input.jumpHeld
        val descendHeld = !blocked && input.descendHeld

        timeSec += clampedDt
        // The fly button, or a double tap on jump, starts and stops flight.
        var toggleFlight = input.consumeFlightToggle() && !blocked
        if (jumpHeld && !lastJumpHeld) {
            if (timeSec - lastJumpPress < DOUBLE_TAP_SECONDS) {
                toggleFlight = true
                lastJumpPress = -10f
            } else {
                lastJumpPress = timeSec
            }
        }
        lastJumpHeld = jumpHeld
        if (toggleFlight) setFlying(!player.flying)

        if (player.flying) {
            flyMove(clampedDt, moveForward, moveStrafe, jumpHeld, descendHeld)
            updateViewBob(0f, 0f, clampedDt)
        } else {
            // Slider sits at 1.0x speed in its default middle position rather than at a
            // fraction of walking speed, which would otherwise feel like a bug.
            val moveSens = 0.6f + settings.touchSensitivity.coerceIn(0f, 1f) * 0.8f
            val forward = moveForward * moveSens
            val strafe = moveStrafe * moveSens
            val yaw = player.yaw
            val worldMoveX = forward * sin(yaw) + strafe * cos(yaw)
            val worldMoveZ = -forward * cos(yaw) + strafe * sin(yaw)
            physics.step(player, worldMoveX, worldMoveZ, jumpHeld, settings.autoJump, clampedDt)
            updateViewBob(worldMoveX, worldMoveZ, clampedDt)
        }

        worldManager.updatePlayerPosition(player.position.x, player.position.z, settings.nearChunks(), player.yaw)
        publishDeepModes()
        particles.update(clampedDt)
        handleBreakPlace(clampedDt, blocked)
        handleLaser(clampedDt, blocked)
        fluid.update(clampedDt)
    }

    /** Starts or stops flying. The velocity restarts from rest either way, so neither the fall of walking
     *  nor the glide of flight carries over. */
    private fun setFlying(flying: Boolean) {
        player.flying = flying
        player.velocity.set(0f, 0f, 0f)
        flightVelocity.fill(0f)
        landedFor = 0f
    }

    /**
     * Creative flight: the joystick moves along the horizontal direction the camera faces (and sideways),
     * jump climbs and the fly-down button sinks (see [FlightMath]). Holding fly-down until the player rests
     * on the ground lands them and ends the flight.
     */
    private fun flyMove(dt: Float, forward: Float, strafe: Float, ascend: Boolean, descend: Boolean) {
        FlightMath.targetVelocity(forward, strafe, ascend, descend, player.yaw, settings.flySpeed, flightTarget)
        val dx = FlightMath.advance(flightVelocity, 0, flightTarget[0], dt)
        val dy = FlightMath.advance(flightVelocity, 1, flightTarget[1], dt)
        val dz = FlightMath.advance(flightVelocity, 2, flightTarget[2], dt)
        val hit = physics.flyMove(player, dx, dy, dz)
        // Whatever the terrain stopped must not stay in the velocity, or the player would lurch after it.
        if (hit and PhysicsController.BLOCKED_X != 0) flightVelocity[0] = 0f
        if (hit and PhysicsController.BLOCKED_Z != 0) flightVelocity[2] = 0f
        if (hit and (PhysicsController.BLOCKED_UP or PhysicsController.BLOCKED_DOWN) != 0) flightVelocity[1] = 0f
        val ceiling = WorldConfig.WORLD_HEIGHT + 200f
        if (player.position.y > ceiling) player.position.y = ceiling

        if (descend && (hit and PhysicsController.BLOCKED_DOWN) != 0) {
            landedFor += dt
            if (landedFor >= LANDING_SECONDS) setFlying(false)
        } else {
            landedFor = 0f
        }
    }

    /** Destroy laser: while held, every [LASER_INTERVAL] seconds it removes every
     *  breakable block in a tube of [LASER_RADIUS] around the view ray, out to [LASER_RANGE]
     *  blocks (it pierces everything), for stress-testing chunk edits and remeshing. */
    private fun handleLaser(dt: Float, blocked: Boolean) {
        laserActive = !blocked && input.laserHeld
        if (!laserActive) {
            laserTimer = 0f
            return
        }
        laserTimer -= dt
        if (laserTimer > 0f) return
        laserTimer = LASER_INTERVAL

        val cp = cos(player.pitch)
        val dirX = cp * sin(player.yaw)
        val dirY = sin(player.pitch)
        val dirZ = -cp * cos(player.yaw)
        val ex = player.eyeX()
        val ey = player.eyeY()
        val ez = player.eyeZ()
        val r = LASER_RADIUS
        val reach2 = r * r + 1
        var step = 2
        while (step <= LASER_RANGE) {
            val cx = floor(ex + dirX * step).toInt()
            val cy = floor(ey + dirY * step).toInt()
            val cz = floor(ez + dirZ * step).toInt()
            for (ox in -r..r) for (oy in -r..r) for (oz in -r..r) {
                if (ox * ox + oy * oy + oz * oz > reach2) continue
                val by = cy + oy
                if (by < 1 || by >= WorldConfig.WORLD_HEIGHT) continue
                val bx = cx + ox
                val bz = cz + oz
                val block = world.getBlock(bx, by, bz)
                if (block != BlockType.AIR && block.breakable) {
                    if (worldManager.setBlockBatched(bx, by, bz, leftBehind(block))) {
                        fluid.onBlockChanged(bx, by, bz)
                    }
                }
            }
            step++
        }
        worldManager.flushBatchedEdits()
    }

    /** Tells the world manager whether the player's eye is in water / well under the ground: those
     *  are the two situations in which the hidden geometry (deep sea floor, cave walls) can be
     *  seen, so it is only meshed then (see WorldManager.refreshDeepMeshing). */
    private fun publishDeepModes() {
        val ex = Math.floor(player.eyeX().toDouble()).toInt()
        val ey = Math.floor(player.eyeY().toDouble()).toInt()
        val ez = Math.floor(player.eyeZ().toDouble()).toInt()
        worldManager.playerUnderwater = Fluid.amountOf(world.getRaw(ex, ey, ez)) > 0
        val size = WorldConfig.CHUNK_SIZE
        val chunk = world.getChunk(ChunkPos(Math.floorDiv(ex, size), Math.floorDiv(ez, size)))
        val ground = if (chunk == null) 0 else chunk.heightMap[(ez and (size - 1)) * size + (ex and (size - 1))].toInt()
        worldManager.playerUnderground = ground > 0 && ey < ground - 2
    }

    /** What a broken block leaves in its cell: water for a water-logged plant (seagrass),
     *  air for everything else. */
    private fun leftBehind(block: BlockType): BlockType =
        if (block == BlockType.SEAGRASS) BlockType.WATER else BlockType.AIR

    private fun updateViewBob(worldMoveX: Float, worldMoveZ: Float, dt: Float) {
        if (!settings.viewBobbing) {
            bobOffset = 0f
            return
        }
        val speed = hypot(worldMoveX.toDouble(), worldMoveZ.toDouble()).toFloat()
        if (player.onGround && speed > 0.05f) {
            bobPhase += dt * 9f
            bobOffset = sin(bobPhase) * 0.045f
        } else {
            bobOffset *= 0.85f
        }
    }

    private fun handleBreakPlace(dt: Float, blocked: Boolean) {
        breakCooldown -= dt
        placeCooldown -= dt
        if (blocked) {
            lastHit = null
            return
        }

        val dirX = cos(player.pitch) * sin(player.yaw)
        val dirY = sin(player.pitch)
        val dirZ = -cos(player.pitch) * cos(player.yaw)
        val hit = Raycaster.cast(world, player.eyeX(), player.eyeY(), player.eyeZ(), dirX, dirY, dirZ, WorldConfig.MAX_INTERACT_REACH)
        lastHit = hit
        if (hit == null) return

        val target = world.getBlock(hit.blockX, hit.blockY, hit.blockZ)

        if (input.breakHeld && breakCooldown <= 0f) {
            if (target.breakable) {
                if (worldManager.setBlockAndRemesh(hit.blockX, hit.blockY, hit.blockZ, leftBehind(target))) {
                    fluid.onBlockChanged(hit.blockX, hit.blockY, hit.blockZ)
                    if (settings.particlesEnabled) {
                        particles.spawnBurst(hit.blockX + 0.5f, hit.blockY + 0.5f, hit.blockZ + 0.5f, target)
                    }
                }
            }
            breakCooldown = BREAK_INTERVAL
        }

        if (input.placeHeld && placeCooldown <= 0f) {
            // Aiming at a plant places into the plant's own cell (replacing it); otherwise
            // the block goes onto the face that was hit.
            var px = hit.blockX
            var py = hit.blockY
            var pz = hit.blockZ
            var canTry = target.plant
            if (!target.plant && (hit.faceX != 0 || hit.faceY != 0 || hit.faceZ != 0)) {
                px += hit.faceX
                py += hit.faceY
                pz += hit.faceZ
                canTry = true
            }
            if (canTry) {
                // Creative: the hotbar's block is placed as often as the player likes, nothing is used up.
                val selected = hotbar.selectedBlock()
                py = PlacementRules.targetY(world, selected, px, py, pz)
                if (PlacementRules.canPlace(world, selected, px, py, pz) &&
                    !PlacementRules.trapsPlayer(player, selected, px, py, pz)
                ) {
                    if (worldManager.setBlockAndRemesh(px, py, pz, selected)) {
                        fluid.onBlockChanged(px, py, pz)
                    }
                }
            }
            placeCooldown = PLACE_INTERVAL
        }
    }

    /** Puts the player on the ground at the spawn column, or at the nearest column that has
     *  real standing room (not under a tree trunk, not on a canopy, cactus or water). */
    private fun dropPlayerToSurface() {
        val bx = floor(player.position.x).toInt()
        val bz = floor(player.position.z).toInt()
        for (ring in 0..SPAWN_SEARCH_RADIUS) {
            for (dz in -ring..ring) {
                for (dx in -ring..ring) {
                    if (maxOf(abs(dx), abs(dz)) != ring) continue
                    val feetY = standingHeight(bx + dx, bz + dz)
                    if (feetY >= 0) {
                        player.position.set(bx + dx + 0.5f, feetY.toFloat(), bz + dz + 0.5f)
                        return
                    }
                }
            }
        }
        // Nothing suitable nearby (practically impossible): fall back to the topmost block.
        var y = WorldConfig.WORLD_HEIGHT - 1
        while (y > 0 && world.getBlock(bx, y, bz) == BlockType.AIR) y--
        player.position.set(player.position.x, (y + 1).toFloat(), player.position.z)
    }

    /** Feet Y for standing in column (x, z): on top of the highest solid, non-foliage block
     *  that has two clear cells above it. -1 if the column has no such place. */
    private fun standingHeight(x: Int, z: Int): Int {
        var y = WorldConfig.WORLD_HEIGHT - 3
        while (y > 0) {
            val block = world.getBlock(x, y, z)
            if (block.solid && !block.cutout && block != BlockType.CACTUS &&
                isClear(x, y + 1, z) && isClear(x, y + 2, z)
            ) {
                return y + 1
            }
            y--
        }
        return -1
    }

    private fun isClear(x: Int, y: Int, z: Int): Boolean {
        val block = world.getBlock(x, y, z)
        return block == BlockType.AIR || block.plant
    }

    /** Short HUD status line: the biome the player is standing in, plus "Flying" while they fly. */
    fun statusLine(): String {
        val biome = generator.biomeAt(floor(player.position.x).toInt(), floor(player.position.z).toInt()).displayName
        return if (player.flying) "$biome   |   Flying" else biome
    }

    fun debugStats(): String {
        val s = worldManager.stats()
        return String.format(
            Locale.US,
            "chunks:%d/%d  genQ:%d  meshQ:%d%s\npos: %.1f, %.1f, %.1f  particles:%d",
            s.loadedChunks, s.chunkBudget, s.genQueueSize, s.meshQueueSize,
            if (s.failures > 0) "  errors:${s.failures}" else "",
            player.position.x, player.position.y, player.position.z, particles.count()
        )
    }

    private companion object {
        /** How far (in columns) from the spawn point to look for real standing room. */
        const val SPAWN_SEARCH_RADIUS = 7

        /** Two taps on jump this close together toggle flight. */
        const val DOUBLE_TAP_SECONDS = 0.3f

        /** Seconds the player must rest on the ground, holding fly-down, before the flight ends. */
        const val LANDING_SECONDS = 0.12f

        /** Seconds between two blocks broken / placed while the button is held. */
        const val BREAK_INTERVAL = 0.12f
        const val PLACE_INTERVAL = 0.22f

        /** Destroy laser: tube radius (blocks), reach (blocks), seconds between pulses. */
        const val LASER_RADIUS = 2
        const val LASER_RANGE = 96
        const val LASER_INTERVAL = 0.1f
    }
}
