package com.voxelsandbox.game.world.far

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Distances from a point to the square a tile covers, in the ground plane: the one place the planner, the
 * stand-in logic and the renderer take them from, so they cannot disagree about which tiles a ring touches.
 */
internal object FarTileMath {
    /** Distance from ([px], [pz]) to the nearest point of the square with corner ([x0], [z0]) and edge [size]. */
    @JvmStatic
    fun nearest(x0: Float, z0: Float, size: Float, px: Float, pz: Float): Float {
        val x1 = x0 + size
        val z1 = z0 + size
        val nx = if (px < x0) x0 else if (px > x1) x1 else px
        val nz = if (pz < z0) z0 else if (pz > z1) z1 else pz
        val dx = px - nx
        val dz = pz - nz
        return sqrt(dx * dx + dz * dz)
    }

    /** Distance from ([px], [pz]) to the farthest corner of the same square. */
    @JvmStatic
    fun farthest(x0: Float, z0: Float, size: Float, px: Float, pz: Float): Float {
        val fx = max(abs(px - x0), abs(px - (x0 + size)))
        val fz = max(abs(pz - z0), abs(pz - (z0 + size)))
        return sqrt(fx * fx + fz * fz)
    }

    /** [nearest] for tile ([tx], [tz]) of [level]. */
    @JvmStatic
    fun nearest(level: Int, tx: Int, tz: Int, px: Float, pz: Float): Float {
        val size = FarLevels.tileBlocks(level)
        return nearest((tx * size).toFloat(), (tz * size).toFloat(), size.toFloat(), px, pz)
    }

    /** [farthest] for tile ([tx], [tz]) of [level]. */
    @JvmStatic
    fun farthest(level: Int, tx: Int, tz: Int, px: Float, pz: Float): Float {
        val size = FarLevels.tileBlocks(level)
        return farthest((tx * size).toFloat(), (tz * size).toFloat(), size.toFloat(), px, pz)
    }
}
