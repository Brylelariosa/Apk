package com.voxelsandbox.game.gl

/**
 * The pixel art of the water surface, generated here instead of drawn by hand because it is an
 * animation: [FRAMES] frames of a [SIZE] x [SIZE] pixel tile that wraps seamlessly in both
 * directions *and* in time (frame [FRAMES] is frame 0 again). Pure Kotlin with no GL in it, so the
 * shader's texture array ([WaterTexture]), the unit tests and the desktop test rig all use the very
 * same pixels.
 *
 * What it draws: 16 pixels to the block like every block texture, [PERIOD_BLOCKS] blocks to the
 * repeat, four close blues. Mostly one calm base blue, with lighter ripples that are longer along X
 * than across (the way wind-driven ripples are), darker troughs, and a few lighter crests. A ripple
 * is always a run of pixels, never a lone speck: single pixels flicker and read as noise, so every
 * frame is cleaned of them. The frames differ little from one to the next (the field underneath
 * is smooth, so an edge moves a pixel at a time), which is what keeps the animation calm instead of
 * shimmering.
 *
 * How it is made: two octaves of gradient noise whose lattice gradients each rotate a whole number
 * of turns over the loop (so the field evolves smoothly and closes on itself), seen through a small
 * periodic wobble of the sampling position. The height field is cut into the four colours by fixed
 * shares of the pixels ([SHARES]), not by fixed thresholds, so the look cannot drift when a
 * constant is tuned. Everything is a pure function of the constants below: the same pixels on
 * every device, every run.
 *
 * Trigonometry is only used on tiny tables (lattice gradients, the wobble), through StrictMath so
 * those tables are bit-identical on every JVM and on ART; the per-pixel work is adds and multiplies.
 */
object WaterPattern {
    /** Pixels along one side of a frame. */
    const val SIZE = 128

    /** Frames in the loop. Even (see [generate]); 1000 s of game time (the wrap of the texture clock) holds a whole
     *  number of loops, see WaterAnimation. */
    const val FRAMES = 40

    /** Pixels per block: the same as every block texture. */
    const val PIXELS_PER_BLOCK = 16

    /** Blocks along one side of the tile: the pattern repeats every this many blocks. */
    const val PERIOD_BLOCKS = SIZE / PIXELS_PER_BLOCK

    /** Colour index in [PALETTE]: the darker troughs, the calm base, the lighter ripples and the crests. */
    const val DARK = 0
    const val BASE = 1
    const val LIGHT = 2
    const val CREST = 3

    /** The four blues, RRGGBB, dark to light. Close together on purpose: the water is calm. The mix of
     *  [SHARES] averages out near (73, 126, 211), the colour of the old flat tile, so the sea keeps
     *  its overall colour. */
    val PALETTE = intArrayOf(0x3D6CC3, 0x4579D0, 0x5088DB, 0x6BA2E9)

    /** Share of the pixels that get each colour (they add up to 1). */
    val SHARES = doubleArrayOf(0.06, 0.62, 0.28, 0.04)

    /** What the alpha channel says about a pixel: 0 for the calm colours, 128 for a ripple, 255 for a
     *  crest. The shader uses it as the mask of the foam where the waves lap a shore. */
    val CREST_ALPHA = intArrayOf(0, 0, 128, 255)

    // ---- The height field ----

    /** Lattice spacing in pixels of the two noise octaves (x, y): wide along X, narrower across. */
    private const val A_SPACING_X = 32
    private const val A_SPACING_Y = 16
    private const val B_SPACING_X = 16
    private const val B_SPACING_Y = 8

    /** Whole turns every gradient makes over the loop: the sign is each lattice point's own. */
    private const val A_TURNS = 1
    private const val B_TURNS = 1

    private const val A_WEIGHT = 0.7
    private const val B_WEIGHT = 0.3

    /** The wobble of the sampling position, in pixels, and how many cycles it has across the tile. */
    private const val WOBBLE_X = 3.0
    private const val WOBBLE_Y = 2.0
    private const val WOBBLE_CYCLES_X = 3
    private const val WOBBLE_CYCLES_Y = 2

    private const val SEED_A = 0x51A7
    private const val SEED_B = 0x2B3D
    private const val SEED_TONE = 0x7E11

    private const val TWO_PI = 6.283185307179586

    private const val HASH_1 = -2048144789 // 0x85EBCA6B
    private const val HASH_2 = -1028477387 // 0xC2B2AE35

    private const val HISTOGRAM_BINS = 4096

    // ---- The result, computed once ----

    /** The frames, [FRAMES] arrays of SIZE * SIZE ARGB ints (alpha = [CREST_ALPHA]). Generated on first
     *  use (a few tens of milliseconds) and kept: the GL texture can be rebuilt after the surface is
     *  lost without doing it all again. */
    val frames: Array<IntArray> by lazy(LazyThreadSafetyMode.SYNCHRONIZED) { generate() }

    /** The mean RGB (0..1 per channel) of every pixel of every frame: what the water shader fades to far
     *  away, where the pattern is too small to see. */
    val average: FloatArray by lazy(LazyThreadSafetyMode.SYNCHRONIZED) { computeAverage(frames) }

    /** Colour index (see [PALETTE]) of an ARGB pixel of [frames]; -1 if it is none of them. */
    fun classOf(argb: Int): Int {
        val rgb = argb and 0xFFFFFF
        for (i in PALETTE.indices) if (PALETTE[i] == rgb) return i
        return -1
    }

    private val prewarmStarted = java.util.concurrent.atomic.AtomicBoolean(false)

    /**
     * Generates the pattern on a background thread, so that the first time the water is drawn the GL thread
     * finds the pixels ready instead of stalling for the generation time (tens of milliseconds on a desktop,
     * probably a few hundred on a phone). The app calls it at start-up, while the main menu is showing.
     * Safe to call any number of times from any thread; if the GL thread asks for the pixels first it simply
     * waits for the same work (the lazies are synchronized), so nothing is ever generated twice.
     */
    fun prewarm() {
        if (!prewarmStarted.compareAndSet(false, true)) return
        val worker = Thread({ warm() }, "water-pattern")
        worker.isDaemon = true
        worker.priority = Thread.MIN_PRIORITY
        worker.start()
    }

    /** Forces everything lazy, in the order the GL upload needs it; returns a number only so it is not optimised away. */
    private fun warm(): Int = frames.size + average.size + tone.size

    // ---- Generation ----

    private fun generate(): Array<IntArray> {
        // The height field is only evaluated for every second frame: it turns smoothly (a gradient moves
        // 9 degrees between frames) so the frame in between is the mean of its two neighbours to a hair, and
        // that halves the work, which matters on a phone's first start. Even FRAMES, and the last in-between
        // frame reads key frame 0 again, so the loop closes exactly as it would have anyway.
        val keys = FRAMES / 2
        val octaveA = Octave(A_SPACING_X, A_SPACING_Y, A_TURNS, SEED_A)
        val octaveB = Octave(B_SPACING_X, B_SPACING_Y, B_TURNS, SEED_B)
        val wobbleX = DoubleArray(SIZE)
        val wobbleY = DoubleArray(SIZE)
        val key = Array(keys) { FloatArray(SIZE * SIZE) }
        var lo = Double.MAX_VALUE
        var hi = -Double.MAX_VALUE

        for (k in 0 until keys) {
            val f = 2 * k
            val phase = TWO_PI * f / FRAMES
            octaveA.setFrame(f)
            octaveB.setFrame(f)
            // Row y is shifted sideways by wobbleX[y], column x vertically by wobbleY[x].
            for (i in 0 until SIZE) {
                wobbleX[i] = WOBBLE_X * StrictMath.sin(TWO_PI * WOBBLE_CYCLES_X * i / SIZE + phase + 0.9)
                wobbleY[i] = WOBBLE_Y * StrictMath.sin(TWO_PI * WOBBLE_CYCLES_Y * i / SIZE - phase + 2.1)
            }
            val h = key[k]
            for (y in 0 until SIZE) {
                for (x in 0 until SIZE) {
                    val sx = x + 0.5 + wobbleX[y]
                    val sy = y + 0.5 + wobbleY[x]
                    val v = A_WEIGHT * octaveA.sample(sx, sy) + B_WEIGHT * octaveB.sample(sx, sy)
                    h[y * SIZE + x] = v.toFloat()
                    if (v < lo) lo = v
                    if (v > hi) hi = v
                }
            }
        }

        // Thresholds that give each colour its share of all the pixels of all the frames.
        val thresholds = thresholdsForShares(key, lo, hi)

        val out = Array(FRAMES) { IntArray(SIZE * SIZE) }
        val classes = IntArray(SIZE * SIZE)
        val scratch = IntArray(SIZE * SIZE)
        for (f in 0 until FRAMES) {
            val a = key[f / 2]
            val b = if (f % 2 == 0) a else key[(f / 2 + 1) % keys]
            for (i in 0 until SIZE * SIZE) {
                val v = (a[i] + b[i]) * 0.5f
                classes[i] = when {
                    v < thresholds[0] -> DARK
                    v > thresholds[2] -> CREST
                    v > thresholds[1] -> LIGHT
                    else -> BASE
                }
            }
            removeSpecks(classes, scratch)
            val frame = out[f]
            for (i in 0 until SIZE * SIZE) {
                val c = classes[i]
                frame[i] = (CREST_ALPHA[c] shl 24) or PALETTE[c]
            }
        }
        return out
    }

    /** Cut points [dark/base, base/light, light/crest] of the height field that split the values of all the
     *  frames (the key frames and the means between them) into [SHARES]. */
    private fun thresholdsForShares(key: Array<FloatArray>, lo: Double, hi: Double): DoubleArray {
        val bins = IntArray(HISTOGRAM_BINS)
        val scale = (HISTOGRAM_BINS - 1) / (hi - lo)
        var total = 0L
        for (f in 0 until FRAMES) {
            val a = key[f / 2]
            val b = if (f % 2 == 0) a else key[(f / 2 + 1) % key.size]
            for (i in a.indices) {
                bins[(((a[i] + b[i]) * 0.5f - lo) * scale).toInt()]++
                total++
            }
        }
        // Cumulative share of the three cuts: dark | base | light | crest.
        val targets = doubleArrayOf(SHARES[DARK], SHARES[DARK] + SHARES[BASE], SHARES[DARK] + SHARES[BASE] + SHARES[LIGHT])
        val cuts = DoubleArray(3)
        var seen = 0L
        var t = 0
        for (b in 0 until HISTOGRAM_BINS) {
            seen += bins[b]
            while (t < 3 && seen >= targets[t] * total) {
                cuts[t] = lo + (b + 1) / scale
                t++
            }
        }
        while (t < 3) cuts[t++] = hi
        return cuts
    }

    /**
     * Gets rid of lone pixels: one that has no 4-neighbour of its own colour (the tile wraps) takes the
     * colour its neighbours agree on, or the left one if they do not agree. Two passes, since fixing
     * one can leave a neighbour alone.
     */
    private fun removeSpecks(classes: IntArray, scratch: IntArray) {
        repeat(2) {
            System.arraycopy(classes, 0, scratch, 0, classes.size)
            for (y in 0 until SIZE) {
                val up = ((y + SIZE - 1) % SIZE) * SIZE
                val down = ((y + 1) % SIZE) * SIZE
                val row = y * SIZE
                for (x in 0 until SIZE) {
                    val left = (x + SIZE - 1) % SIZE
                    val right = (x + 1) % SIZE
                    val c = scratch[row + x]
                    val l = scratch[row + left]
                    val r = scratch[row + right]
                    val u = scratch[up + x]
                    val d = scratch[down + x]
                    if (c == l || c == r || c == u || c == d) continue
                    classes[row + x] = if (l == r) l else if (u == d) u else l
                }
            }
        }
    }

    private fun computeAverage(frames: Array<IntArray>): FloatArray {
        var r = 0.0
        var g = 0.0
        var b = 0.0
        for (f in frames) {
            for (p in f) {
                r += (p shr 16) and 0xFF
                g += (p shr 8) and 0xFF
                b += p and 0xFF
            }
        }
        val n = frames.size.toDouble() * SIZE * SIZE * 255.0
        return floatArrayOf((r / n).toFloat(), (g / n).toFloat(), (b / n).toFloat())
    }

    // ---- The slow, large-scale tone ----

    /** Texels along one side of the tone texture. */
    const val TONE_SIZE = 64

    /** Blocks along one side of the tone texture: it repeats this far (so a texel is 4 blocks). */
    const val TONE_PERIOD_BLOCKS = 256

    /**
     * A seamlessly tiling field of soft, slowly varying patches (three octaves of value noise, 8, 16 and 32
     * cells to the tile), as TONE_SIZE * TONE_SIZE bytes stretched to use the whole 0..255 range. The
     * shader turns it into a few percent of brightness and hue shift: wind patches on the sea. It is
     * what keeps a calm sea from looking like one flat colour, and what stops the wave tile from reading
     * as a repeat. One byte per texel, filtered linearly, 4 KB.
     */
    val tone: ByteArray by lazy(LazyThreadSafetyMode.SYNCHRONIZED) { generateTone() }

    private fun generateTone(): ByteArray {
        val field = DoubleArray(TONE_SIZE * TONE_SIZE)
        var amplitude = 1.0
        var cells = 8
        var octave = 0
        while (cells <= 32) {
            val lattice = DoubleArray(cells * cells) { (hash(it % cells, it / cells, SEED_TONE + octave) ushr 8) / 16777216.0 }
            val per = TONE_SIZE.toDouble() / cells
            for (y in 0 until TONE_SIZE) {
                val v = y / per
                val j0 = v.toInt()
                val fv = smooth(v - j0)
                for (x in 0 until TONE_SIZE) {
                    val u = x / per
                    val i0 = u.toInt()
                    val fu = smooth(u - i0)
                    val i1 = (i0 + 1) % cells
                    val j1 = (j0 + 1) % cells
                    val a = lattice[j0 * cells + i0] * (1 - fu) + lattice[j0 * cells + i1] * fu
                    val b = lattice[j1 * cells + i0] * (1 - fu) + lattice[j1 * cells + i1] * fu
                    field[y * TONE_SIZE + x] += amplitude * (a * (1 - fv) + b * fv)
                }
            }
            amplitude *= 0.5
            cells *= 2
            octave++
        }
        var lo = Double.MAX_VALUE
        var hi = -Double.MAX_VALUE
        for (v in field) {
            if (v < lo) lo = v
            if (v > hi) hi = v
        }
        val out = ByteArray(TONE_SIZE * TONE_SIZE)
        for (i in out.indices) out[i] = ((field[i] - lo) / (hi - lo) * 255.0 + 0.5).toInt().toByte()
        return out
    }

    private fun smooth(t: Double): Double = t * t * (3.0 - 2.0 * t)

    // ---- Gradient noise on a wrapping lattice, with rotating gradients ----

    private fun hash(i: Int, j: Int, seed: Int): Int {
        var h = i * 0x27D4EB2D + j * 0x165667B1 + seed * 0x3C6EF372
        h = (h xor (h ushr 15)) * HASH_1
        h = (h xor (h ushr 13)) * HASH_2
        return h xor (h ushr 16)
    }

    private fun fade(t: Double): Double = t * t * t * (t * (t * 6.0 - 15.0) + 10.0)

    /** One octave: a wrapping lattice of unit gradients, each turning [turns] whole turns per loop. The
     *  lattice sizes are powers of two, so wrapping is a mask. */
    private class Octave(val spacingX: Int, val spacingY: Int, val turns: Int, seed: Int) {
        val cellsX = SIZE / spacingX
        val cellsY = SIZE / spacingY
        private val maskX = cellsX - 1
        private val maskY = cellsY - 1
        private val invX = 1.0 / spacingX
        private val invY = 1.0 / spacingY
        private val baseAngle = DoubleArray(cellsX * cellsY)
        private val spin = IntArray(cellsX * cellsY)
        private val gx = DoubleArray(cellsX * cellsY)
        private val gy = DoubleArray(cellsX * cellsY)

        init {
            check(cellsX and maskX == 0 && cellsY and maskY == 0) { "lattice sizes must be powers of two" }
            for (j in 0 until cellsY) {
                for (i in 0 until cellsX) {
                    val h = hash(i, j, seed)
                    baseAngle[j * cellsX + i] = (h ushr 8) / 16777216.0 * TWO_PI
                    spin[j * cellsX + i] = if ((h and 1) == 0) 1 else -1
                }
            }
        }

        fun setFrame(frame: Int) {
            val turn = TWO_PI * turns * frame / FRAMES
            for (k in gx.indices) {
                val a = baseAngle[k] + spin[k] * turn
                gx[k] = StrictMath.cos(a)
                gy[k] = StrictMath.sin(a)
            }
        }

        /** Noise at pixel position (x, y), which may lie a little outside the tile (the lattice wraps). */
        fun sample(x: Double, y: Double): Double {
            // Shifted by a whole number of tiles so the position is positive and truncation is floor.
            val u = (x + SIZE) * invX
            val v = (y + SIZE) * invY
            val iu = u.toInt()
            val iv = v.toInt()
            val fu = u - iu
            val fv = v - iv
            val i0 = iu and maskX
            val j0 = iv and maskY
            val i1 = (i0 + 1) and maskX
            val j1 = (j0 + 1) and maskY
            val k00 = j0 * cellsX + i0
            val k10 = j0 * cellsX + i1
            val k01 = j1 * cellsX + i0
            val k11 = j1 * cellsX + i1
            val n00 = gx[k00] * fu + gy[k00] * fv
            val n10 = gx[k10] * (fu - 1.0) + gy[k10] * fv
            val n01 = gx[k01] * fu + gy[k01] * (fv - 1.0)
            val n11 = gx[k11] * (fu - 1.0) + gy[k11] * (fv - 1.0)
            val su = fade(fu)
            val sv = fade(fv)
            val a = n00 + (n10 - n00) * su
            val b = n01 + (n11 - n01) * su
            return a + (b - a) * sv
        }
    }
}
