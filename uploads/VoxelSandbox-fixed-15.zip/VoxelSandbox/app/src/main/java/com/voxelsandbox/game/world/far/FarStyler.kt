package com.voxelsandbox.game.world.far

import com.voxelsandbox.game.gl.TextureAtlas
import com.voxelsandbox.game.world.WorldConfig
import com.voxelsandbox.game.world.color.BiomeColorField
import com.voxelsandbox.game.world.generation.Biome
import com.voxelsandbox.game.world.generation.Climate
import com.voxelsandbox.game.world.generation.SurfaceKind
import com.voxelsandbox.game.world.generation.TerrainGenerator
import kotlin.math.min

/**
 * What the ground of the distant terrain looks like at one sample point: its colour (a palette ramp, or for grass
 * and leaves the biome colour field's own smooth colour), the colour of the walls under it, and whether a canopy of
 * trees stands on it. The one place that turns "height, slope and climate at a position" into a look, shared by
 * every column level ([FarColumnSampler], one sample per column), so a mountain does not change colour where one
 * level hands over to the next.
 *
 * Everything is a pure function of the arguments: the same position gives the same look from every tile and at
 * every distance.
 */
internal class FarStyler(
    private val generator: TerrainGenerator,
    private val grassField: BiomeColorField,
    private val groundColor: FarGroundColor
) {
    private val climate = generator.climate

    /** The answer of [style] (reused from call to call: only valid until the next call that is given it). */
    class Style {
        /** Colour key of the top (a palette key, or a direct key: see [FarPalette]). */
        @JvmField var color = 0

        /** Colour key of the walls under the top. */
        @JvmField var wall = 0

        /** The colour (0xRRGGBB) of a grass top, [FarGroundColor.NONE] for every other ground. */
        @JvmField var grass = FarGroundColor.NONE

        /** The biome colour field's colour where leaves or grass can grow, [FarGroundColor.NONE] elsewhere. */
        @JvmField var tint = FarGroundColor.NONE

        /** The height (blocks) of the canopy of trees that raises the ground, 0 where there is none. [color] is then
         *  the colour of the leaves and the grass is hidden under them. */
        @JvmField var raise = 0f

        fun clear() {
            color = 0
            wall = 0
            grass = FarGroundColor.NONE
            tint = FarGroundColor.NONE
            raise = 0f
        }
    }

    /**
     * The look of the ground at world position ([wx], [wz]), the centre of the sample of global grid index
     * ([gx], [gz]) of [level]. [h] is the whole-block height of the ground there, [slope] its (already scaled, see
     * [FarLevels.slopeGain]) steepness and [coast] the smooth base elevation of the position. With [colors] false
     * the biome colour field is not asked (the colours of ground that is only needed for its shape do not need to be smooth).
     */
    fun style(
        level: Int, gx: Int, gz: Int, wx: Double, wz: Double, h: Int, slope: Double, coast: Double,
        colors: Boolean, out: Style
    ) {
        out.clear()
        val sea = WorldConfig.SEA_LEVEL
        if (h < sea) {
            val cold = climate.baseTemperature(wx, wz) < Climate.COLD
            val deep = sea - h > 8
            val bed = if (deep || cold) TextureAtlas.RAMP_GRAVEL + 1f else TextureAtlas.RAMP_SAND + 2f
            out.color = FarPalette.colorKey(TextureAtlas.RAMP_ROW_SURFACE, bed)
            out.wall = out.color
            return
        }

        val hd = h.toDouble()
        val t0 = climate.baseTemperature(wx, wz)
        val hum = climate.humidity(wx, wz)
        val biome = climate.biome(wx, wz, hd, slope, coast, t0, hum)
        val kind = climate.surfaceFor(biome, wx, wz, hd, slope)
        val fx = wx.toFloat()
        val fz = wz.toFloat()
        val forest = climate.forest(wx, wz).toFloat()
        // Large soft patches (coherent noise, never a regular wave), so a field of one
        // surface type is not one flat colour and has no stripes or repeats.
        val patch = FarNoise.patch(fx, fz, FarLevels.step(level))
        val t = when (kind) {
            SurfaceKind.BEACH -> TextureAtlas.RAMP_SAND + (if (h <= sea) 2f else if (h == sea + 1) 1f else 0f)
            SurfaceKind.GRASS -> TextureAtlas.RAMP_GRASS + 0.3f + patch * 2.0f + forest * 1.9f
            SurfaceKind.DRY_GRASS -> TextureAtlas.RAMP_DRY + patch * 1.8f + forest * 0.6f
            SurfaceKind.DESERT -> TextureAtlas.RAMP_DESERT + patch * 2.0f
            SurfaceKind.SNOW -> TextureAtlas.RAMP_SNOW + patch * 1.8f
            SurfaceKind.ROCK -> TextureAtlas.RAMP_STONE + patch * 2.0f
            SurfaceKind.GRAVEL -> TextureAtlas.RAMP_GRAVEL + patch * 2.0f
            SurfaceKind.SWAMP -> TextureAtlas.RAMP_SWAMP + patch * 2.0f
        }
        out.color = FarPalette.colorKey(TextureAtlas.RAMP_ROW_SURFACE, t)
        out.wall = if (kind.soilSides) FarPalette.soilWallKey else out.color

        // Grass (and the leaves of the trees that stand on it) takes its colour from the biome colour
        // field instead of a palette row, so it is as smooth here as it is on the voxel terrain.
        val treed = generator.treeDensity(biome) > 0.0
        val grassy = kind == SurfaceKind.GRASS || kind == SurfaceKind.DRY_GRASS || kind == SurfaceKind.SWAMP
        if (colors && (grassy || treed)) {
            val fieldRgb = grassField.grass(wx, wz, hd, coast, t0, hum)
            if (treed) out.tint = fieldRgb
            if (grassy) out.grass = groundColor.grass(fieldRgb, kind, FarPalette.rampColumnOf(t))
        }

        // Coarse levels: forested ground is raised into a canopy layer.
        if (level >= FarLevels.CANOPY_FROM_LEVEL && h >= sea + 2 && treed) {
            val cover = min(0.92, generator.treeChance(biome, forest.toDouble()) * 2.4)
            if (FarNoise.cellRandom(gx, gz, level).toDouble() < cover) {
                val rr = FarNoise.cellRandom(gx, gz, level + 7)
                val leafBase = when (biome) {
                    Biome.TAIGA, Biome.SNOWY_TAIGA, Biome.SNOWY_PLAINS, Biome.MOUNTAINS -> TextureAtlas.RAMP_SPRUCE_LEAF
                    Biome.BIRCH_FOREST -> TextureAtlas.RAMP_BIRCH_LEAF
                    else -> TextureAtlas.RAMP_OAK_LEAF
                }
                out.raise = (if (leafBase == TextureAtlas.RAMP_SPRUCE_LEAF) 7f else 4.5f) + 3f * rr
                out.color = leafKey(leafBase + (if (rr < 0.5f) 0f else 1f), out.tint)
                out.wall = out.color // a canopy is leaves all the way down
                out.grass = FarGroundColor.NONE // the canopy covers the grass
            }
        }
    }

    /**
     * The key of a leaf colour (a column of the foliage palette). With a [tint] (the biome colour field's colour
     * where the tree stands) it is the palette colour shifted like the voxel leaves are; without, the palette
     * entry itself.
     */
    fun leafKey(column: Float, tint: Int): Int {
        val key = FarPalette.colorKey(TextureAtlas.RAMP_ROW_FOLIAGE, column)
        if (tint < 0) return key
        val rgb = TextureAtlas.rampFoliageRgb(FarPalette.rampColumnOf(column))
        return FarGroundColor.directKey(groundColor.leaf(rgb, tint))
    }
}
