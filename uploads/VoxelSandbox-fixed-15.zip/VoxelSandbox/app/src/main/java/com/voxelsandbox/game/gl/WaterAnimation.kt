package com.voxelsandbox.game.gl

/**
 * Everything about *when* and *where* the water pattern is, as plain functions of the time and of the
 * camera's whole-block origin, so the maths the shader depends on can be tested without a GPU.
 *
 * The pattern is attached to the world, never to the camera:
 *  - [WaterPattern]'s tile is [WaterPattern.PERIOD_BLOCKS] blocks wide and the shader reads it at
 *    (camera-relative position + [phase]). The camera origin is a whole number of blocks, so [phase]
 *    (the origin modulo the tile) is an exact small integer and the texel under a given world
 *    position is the same whichever origin the frame happens to use. Nothing slides when the camera
 *    moves, and nothing jumps when the origin steps from one block to the next.
 *  - Still water is animated by the frame alone, which is picked on the CPU (one integer per frame, [frameAt]);
 *    only running water also carries its pattern along its flow (in the shader, [FLOW_SPEED]).
 *  - The large patches of tone drift very slowly ([TONE_DRIFT]) so a calm sea does not look painted on.
 *
 * Every rate divides the time wrap of [FrameState.TEXTURE_TIME_PERIOD] into whole loops, so nothing
 * jumps when that time wraps around (see the unit tests).
 */
object WaterAnimation {
    /** Frames of the wave animation per second: a calm, deliberate pace (40 frames, a 6.67 second loop). */
    const val FPS = 6

    /** Blocks per second running water carries its pattern at full flow (a flow vector of length 1).
     *  100 whole tiles per time wrap, so a river at full speed does not jump when the time wraps. */
    const val FLOW_SPEED = 0.8f

    /** Blocks per second the tone patches drift along +X: one whole tone texture per time wrap. */
    const val TONE_DRIFT = 0.256f

    /** Which frame of the loop is showing [seconds] into the (wrapped) texture time. */
    fun frameAt(seconds: Double): Int {
        val n = Math.floor(seconds * FPS).toLong()
        return Math.floorMod(n, WaterPattern.FRAMES.toLong()).toInt()
    }

    /** The tile offset of a whole-block camera [origin] (see the class comment): 0 until PERIOD_BLOCKS, exact. */
    fun phase(origin: Float): Float = Math.floorMod(origin.toLong(), WaterPattern.PERIOD_BLOCKS.toLong()).toFloat()

    /** Where the tone texture is read for a whole-block camera [origin] at [seconds] on one axis, in blocks
     *  (the shader adds the camera-relative position and divides by the tone texture's size): the origin
     *  modulo the texture's size, moved back by the drift along X ([drifts]) so the patches travel +X. */
    fun tonePhase(origin: Float, seconds: Double, drifts: Boolean): Float {
        val base = Math.floorMod(origin.toLong(), WaterPattern.TONE_PERIOD_BLOCKS.toLong()).toDouble()
        val shifted = if (drifts) base - seconds * TONE_DRIFT else base
        return Math.floorMod(Math.floor(shifted).toLong(), WaterPattern.TONE_PERIOD_BLOCKS.toLong()).toFloat() +
            (shifted - Math.floor(shifted)).toFloat()
    }

    /** Fills the water fields of [frame] for the camera origin it already holds and the wrapped time [seconds]. */
    fun fill(frame: FrameState, seconds: Double) {
        frame.waterLayer = frameAt(seconds).toFloat()
        frame.waterPhaseX = phase(frame.originX)
        frame.waterPhaseY = phase(frame.originY)
        frame.waterPhaseZ = phase(frame.originZ)
        frame.tonePhaseX = tonePhase(frame.originX, seconds, true)
        frame.tonePhaseZ = tonePhase(frame.originZ, seconds, false)
    }
}
