package com.voxelsandbox.game.world.far

import kotlin.math.floor

/**
 * The deterministic noise of the distant terrain's colouring, as pure functions of the position (and a salt), so a
 * tile and every tile of every other level agree on it and nothing is ever re-rolled.
 */
internal object FarNoise {
    /** Deterministic 0..1 value for a cell of the LOD grid. */
    fun cellRandom(gx: Int, gz: Int, salt: Int): Float {
        var h = gx * 73856093 xor gz * 19349663 xor salt * 83492791
        h = h xor (h ushr 15)
        h *= 739982445
        h = h xor (h ushr 13)
        return ((h ushr 8) and 0xFFFF) / 65536f
    }

    /** Smooth value noise (0..1) on an integer lattice, deterministic in the lattice coordinates and [salt]. */
    fun valueNoise(x: Float, z: Float, salt: Int): Float {
        val xf = floor(x)
        val zf = floor(z)
        val fx = x - xf
        val fz = z - zf
        val ix = xf.toInt()
        val iz = zf.toInt()
        val sx = fx * fx * (3f - 2f * fx)
        val sz = fz * fz * (3f - 2f * fz)
        val a = cellRandom(ix, iz, salt)
        val b = cellRandom(ix + 1, iz, salt)
        val c = cellRandom(ix, iz + 1, salt)
        val d = cellRandom(ix + 1, iz + 1, salt)
        return a + (b - a) * sx + (c - a) * sz + (a - b - c + d) * sx * sz
    }

    /**
     * The soft patchiness of a surface (0..1) at a world position: domain-warped fractal value noise, so it forms
     * irregular clusters at several scales instead of repeating waves, and is a pure function of the position (the
     * same at every level and from every tile, never re-rolled). The finest octave is dropped on coarse levels,
     * where a column is wider than its wavelength and the octave would only turn into random speckle.
     */
    fun patch(wx: Float, wz: Float, step: Int): Float {
        val qx = wx + 55f * (valueNoise(wx * 0.011f, wz * 0.011f, 11) - 0.5f)
        val qz = wz + 55f * (valueNoise(wx * 0.011f + 17.3f, wz * 0.011f - 9.1f, 12) - 0.5f)
        val fine = if (step <= 4) 0.20f else if (step <= 8) 0.10f else 0f
        val v = (0.50f * valueNoise(qx * 0.0065f, qz * 0.0065f, 21) +
            0.30f * valueNoise(qx * 0.019f, qz * 0.019f, 22) +
            fine * valueNoise(qx * 0.057f, qz * 0.057f, 23)) / (0.80f + fine)
        // Sums of noise bunch up around the middle; stretch them so patches are distinct.
        return ((v - 0.5f) * 1.8f + 0.5f).coerceIn(0f, 1f)
    }
}
