package com.voxelsandbox.game.gl

import android.opengl.GLES30
import com.voxelsandbox.game.world.AtlasCell
import java.nio.ByteBuffer
import java.nio.ByteOrder

data class UVRect(val u0: Float, val v0: Float, val u1: Float, val v1: Float)

/**
 * Packs the procedural block textures ([BlockTextures]) into one atlas and uploads it.
 * Every block texture is generated at startup rather than shipped as an image asset, so
 * the project stays asset-free. The atlas is plain ARGB int arrays: no Bitmap/Canvas,
 * which means it can be built on any thread, needs no GL context, and keeps *straight*
 * (non-premultiplied) alpha. That matters for the leaf tiles, whose transparent holes
 * would otherwise darken the colour of their neighbours when mip-mapped.
 *
 * Every tile sits in a larger "pitch" cell with a [PAD_PX] gutter all around it. The
 * gutter is filled with the tile's own pattern (wrapped for seamless ground tiles,
 * edge-extended for the rest), so mip filtering that reaches past a tile
 * edge samples more of the same block instead of a neighbouring tile of the atlas. That
 * is what used to draw thin dark/odd lines along the edges of sand, grass and other
 * blocks seen at a low angle. The mip chain is built by hand (alpha-weighted box
 * filter). [uploadToGL] needs the GL context and is called from the renderer on the GL
 * thread.
 *
 * Image row 0 is the TOP of a tile and maps to the smallest v; the mesher relies on that
 * to put grass fringes / bark streaks the right way up on side faces.
 *
 * Two ways to sample it, both on texture unit 0 (see [bind] and [bindFiltered]):
 *  - [bind]: the texture's own state, nearest texels. The distant terrain reads its colour ramp
 *    that way (it wants exact palette entries, not blends of neighbours).
 *  - [bindFiltered]: a sampler object with trilinear mip-mapping and linear magnification, for the
 *    voxel-terrain shaders (see VoxelShader), which turn linear filtering into crisp pixel art up
 *    close and into stable, flicker-free averages at a distance. That needs the colour of every
 *    fully transparent texel to be sensible ([bleedTransparent]), or a sample that straddles a leaf
 *    hole would blend towards black.
 */
class TextureAtlas {
    companion object {
        const val GRID = 8

        /** Content size of one tile: 16 x 16 texels, like the classic voxel games. */
        const val CELL_PX = 16

        /** Gutter around every tile (texels at mip level 0). */
        const val PAD_PX = 8

        /** Distance between two tiles in the atlas: content plus a gutter on each side. */
        const val PITCH_PX = CELL_PX + 2 * PAD_PX
        const val SIZE_PX = GRID * PITCH_PX

        /** 256, 128, 64, 32, 16 px. */
        const val MIP_LEVELS = 5

        const val WATER_CELL = AtlasCell.WATER

        /** A plain white cell, reused (tinted via the shader's fog/shade/alpha
         *  uniforms) for clouds and the highlight so no extra texture is needed. */
        const val WHITE_CELL = AtlasCell.WHITE

        /** A palette the distant-terrain mesh samples by U (colour column) and V (colour
         *  row, see [rampV]). Row [RAMP_ROW_SURFACE] holds ground colours, row
         *  [RAMP_ROW_FOLIAGE] holds tree colours. The columns are grouped by type (first
         *  column of each group below, two to five shades light -> dark) and are derived
         *  from the average colour of the matching block texture.
         *
         *  A tile is only [CELL_PX] texels wide but the ground palette has more colours than
         *  that, so the surface row is stored as two stacked halves: columns 0..15 in texel rows
         *  0..3 of the cell, columns 16..31 in texel rows 4..7 (see [rampU] / [rampV]). No group
         *  straddles the split. */
        const val RAMP_CELL = AtlasCell.RAMP
        const val RAMP_ROW_SURFACE = 0
        const val RAMP_ROW_FOLIAGE = 1
        const val RAMP_COLUMNS = 32
        const val RAMP_SPLIT = 15f
        const val RAMP_SAND = 0f
        const val RAMP_GRASS = 3f
        const val RAMP_DIRT = 8f
        const val RAMP_STONE = 11f
        const val RAMP_DRY = 16f
        const val RAMP_DESERT = 19f
        const val RAMP_SNOW = 22f
        const val RAMP_GRAVEL = 25f
        const val RAMP_SWAMP = 28f

        /** How much lighter or darker than the mean colour of its block each column of the grass groups is,
         *  light -> dark. The distant terrain picks a column from the patch / forest noise; its smooth
         *  grass colours (see world/far/FarGroundColor) take the same factor, so the brightness pattern of
         *  the ground does not change when the hue starts to follow the biome colour field. */
        @JvmField val GRASS_STEPS = floatArrayOf(1.10f, 1.03f, 0.96f, 0.86f, 0.72f)
        @JvmField val DRY_STEPS = floatArrayOf(1.10f, 1.0f, 0.88f)
        @JvmField val SWAMP_STEPS = floatArrayOf(1.10f, 1.0f, 0.88f)

        // columns of the foliage row
        const val RAMP_OAK_LEAF = 0f
        const val RAMP_BIRCH_LEAF = 3f
        const val RAMP_SPRUCE_LEAF = 6f
        const val RAMP_OAK_WOOD = 9f
        const val RAMP_BIRCH_WOOD = 11f
        const val RAMP_SPRUCE_WOOD = 13f

        /** Keeps sampling just inside a tile (in texels). */
        private const val UV_INSET_PX = 0.15f

        /** How many texels deep the colour of a visible texel is spread into the transparent ones around it. */
        private const val BLEED_PASSES = 2

        private val EMPTY_UV = UVRect(0f, 0f, 0f, 0f)

        /** Every in-grid cell's rect, computed once: uvFor runs per emitted mesh face on
         *  the mesh-worker threads and per particle per frame, and a UVRect depends on
         *  nothing but the cell index. */
        private val UV_TABLE: Array<UVRect> = Array(GRID * GRID) { computeUv(it) }

        private fun computeUv(cell: Int): UVRect {
            val cx = cell % GRID
            val cy = cell / GRID
            val ox = cx * PITCH_PX + PAD_PX
            val oy = cy * PITCH_PX + PAD_PX
            val u0 = (ox + UV_INSET_PX) / SIZE_PX
            val v0 = (oy + UV_INSET_PX) / SIZE_PX
            val u1 = (ox + CELL_PX - UV_INSET_PX) / SIZE_PX
            val v1 = (oy + CELL_PX - UV_INSET_PX) / SIZE_PX
            return UVRect(u0, v0, u1, v1)
        }

        /** U coordinate at the centre of ramp column [t] (0 until [RAMP_COLUMNS], fractional
         *  allowed). Columns from [RAMP_SPLIT] up live in the second half of the surface row. */
        fun rampU(t: Float): Float {
            val max = (RAMP_COLUMNS - 1).toFloat()
            val c = if (t < 0f) 0f else if (t > max) max else t
            val col = if (c >= RAMP_SPLIT) c - CELL_PX else c
            val cx = RAMP_CELL % GRID
            return (cx * PITCH_PX + PAD_PX + col + 0.5f) / SIZE_PX
        }

        /** V coordinate inside the ramp cell for colour row [row] (RAMP_ROW_*) and, for the
         *  surface row, column [t] (which half of the row it is in). The surface palette owns
         *  texel rows 0..7 of the cell (two halves of four rows) and the foliage palette rows
         *  8..15. */
        fun rampV(row: Int = 0, t: Float = 0f): Float {
            val cy = RAMP_CELL / GRID
            val y = if (row == RAMP_ROW_SURFACE) (if (t >= RAMP_SPLIT) 6f else 2f) else row * 8f + 4f
            return (cy * PITCH_PX + PAD_PX + y) / SIZE_PX
        }

        /** The column the nearest-texel sampler picks at ramp position [t] (see [rampU]). */
        fun rampColumn(t: Float): Int {
            val c = Math.floor((t + 0.5f).toDouble()).toInt()
            return if (c < 0) 0 else if (c >= RAMP_COLUMNS) RAMP_COLUMNS - 1 else c
        }

        /** The palette of the surface row as plain 0xRRGGBB colours: exactly what [buildBase] writes into the
         *  atlas, for code that needs the colour itself and not a place to sample it from. */
        fun rampSurfaceRgb(column: Int): Int = RAMP_COLORS[column] and 0xFFFFFF

        /** The same for the foliage row (leaves and wood). */
        fun rampFoliageRgb(column: Int): Int = FOLIAGE_COLORS[column] and 0xFFFFFF

        private fun average(cell: Int): Int = BlockTextures.averageColor(TileSources.requirePixels(cell))

        private val RAMP_COLORS: IntArray by lazy(LazyThreadSafetyMode.PUBLICATION) {
            ramp(
                average(AtlasCell.GRASS_TOP),
                average(AtlasCell.DIRT),
                average(AtlasCell.STONE),
                average(AtlasCell.SAND),
                average(AtlasCell.DRY_GRASS_TOP),
                average(AtlasCell.SNOW),
                average(AtlasCell.GRAVEL),
                average(AtlasCell.SWAMP_GRASS_TOP)
            )
        }

        private val FOLIAGE_COLORS: IntArray by lazy(LazyThreadSafetyMode.PUBLICATION) {
            foliageRamp(
                average(AtlasCell.OAK_LEAVES),
                average(AtlasCell.BIRCH_LEAVES),
                average(AtlasCell.SPRUCE_LEAVES),
                average(AtlasCell.OAK_BARK),
                average(AtlasCell.BIRCH_BARK),
                average(AtlasCell.SPRUCE_BARK)
            )
        }

        // ---- atlas assembly -----------------------------------------------------------

        private fun rgb(r: Int, g: Int, b: Int): Int = (255 shl 24) or (r shl 16) or (g shl 8) or b

        /** Copies [pixels] (a CELL_PX x CELL_PX tile) into grid cell [cell] of [atlas] and
         *  fills the gutter around it: with the tile's own pattern repeated when [wrap]
         *  (tiles that are seamless by construction), otherwise with its edge texels. */
        private fun blit(atlas: IntArray, cell: Int, pixels: IntArray, wrap: Boolean = false) {
            val ox = (cell % GRID) * PITCH_PX
            val oy = (cell / GRID) * PITCH_PX
            for (y in 0 until PITCH_PX) {
                val ty = y - PAD_PX
                val sy = if (wrap) Math.floorMod(ty, CELL_PX) else if (ty < 0) 0 else if (ty >= CELL_PX) CELL_PX - 1 else ty
                val rowBase = sy * CELL_PX
                val dstBase = (oy + y) * SIZE_PX + ox
                for (x in 0 until PITCH_PX) {
                    val tx = x - PAD_PX
                    val sx = if (wrap) Math.floorMod(tx, CELL_PX) else if (tx < 0) 0 else if (tx >= CELL_PX) CELL_PX - 1 else tx
                    atlas[dstBase + x] = pixels[rowBase + sx]
                }
            }
        }

        /**
         * The distant-terrain colour ramp. Each group is the average colour of the real block
         * texture it stands in for, scaled light -> dark, so far-away terrain matches the
         * voxel terrain it fades into.
         */
        private fun ramp(
            grass: Int, dirt: Int, stone: Int, sand: Int, dryGrass: Int, snow: Int, gravel: Int, swamp: Int
        ): IntArray {
            val out = IntArray(RAMP_COLUMNS)
            java.util.Arrays.fill(out, BlockTextures.scaleColor(stone, 0.8f))
            fun put(first: Float, color: Int, factors: FloatArray) {
                for (i in factors.indices) out[first.toInt() + i] = BlockTextures.scaleColor(color, factors[i])
            }
            put(RAMP_SAND, sand, floatArrayOf(1.06f, 0.99f, 0.90f))
            put(RAMP_GRASS, grass, GRASS_STEPS)
            put(RAMP_DIRT, dirt, floatArrayOf(1.10f, 1.0f, 0.86f))
            put(RAMP_STONE, stone, floatArrayOf(1.12f, 1.0f, 0.86f))
            put(RAMP_DRY, dryGrass, DRY_STEPS)
            // Desert ground is the same sand, nudged warmer so it reads as a region of its own.
            val warmSand = rgb(
                (((sand shr 16) and 0xFF) * 1.03f).toInt().coerceAtMost(255),
                (((sand shr 8) and 0xFF) * 0.97f).toInt(),
                ((sand and 0xFF) * 0.86f).toInt()
            )
            put(RAMP_DESERT, warmSand, floatArrayOf(1.04f, 0.97f, 0.90f))
            put(RAMP_SNOW, snow, floatArrayOf(1.0f, 0.95f, 0.88f))
            put(RAMP_GRAVEL, gravel, floatArrayOf(1.10f, 1.0f, 0.88f))
            put(RAMP_SWAMP, swamp, SWAMP_STEPS)
            return out
        }

        /** Tree colours for the distant-terrain mesh (leaf and wood averages, light -> dark). */
        private fun foliageRamp(
            oakLeaf: Int, birchLeaf: Int, spruceLeaf: Int, oakWood: Int, birchWood: Int, spruceWood: Int
        ): IntArray {
            val out = IntArray(CELL_PX)
            java.util.Arrays.fill(out, BlockTextures.scaleColor(oakLeaf, 0.8f))
            fun put(first: Float, color: Int, factors: FloatArray) {
                for (i in factors.indices) out[first.toInt() + i] = BlockTextures.scaleColor(color, factors[i])
            }
            put(RAMP_OAK_LEAF, oakLeaf, floatArrayOf(1.0f, 0.88f, 0.74f))
            put(RAMP_BIRCH_LEAF, birchLeaf, floatArrayOf(1.0f, 0.88f, 0.74f))
            put(RAMP_SPRUCE_LEAF, spruceLeaf, floatArrayOf(1.1f, 0.95f, 0.8f))
            put(RAMP_OAK_WOOD, oakWood, floatArrayOf(1.0f, 0.8f))
            put(RAMP_BIRCH_WOOD, birchWood, floatArrayOf(1.0f, 0.85f))
            put(RAMP_SPRUCE_WOOD, spruceWood, floatArrayOf(1.0f, 0.8f))
            return out
        }

        private fun buildBase(): IntArray {
            val atlas = IntArray(SIZE_PX * SIZE_PX)
            // Unused cells are loud magenta so a wrong cell index is obvious, never silently dark.
            java.util.Arrays.fill(atlas, rgb(255, 0, 255))

            // Every drawn tile, with its own "repeats seamlessly" flag (see TileSources).
            for (tile in TileSources.tiles) blit(atlas, tile.cell, TintTable.atlasPixels(tile.cell, tile.pixels), tile.wrap)

            val rampColors = RAMP_COLORS
            val foliageColors = FOLIAGE_COLORS
            // Texel rows 0-3 of the cell: surface colours 0..15; rows 4-7: surface colours 16..31;
            // rows 8-15: the foliage palette (see rampU / rampV).
            val rampTile = IntArray(CELL_PX * CELL_PX)
            for (y in 0 until CELL_PX) {
                val first = when {
                    y < 4 -> 0
                    y < 8 -> CELL_PX
                    else -> -1
                }
                for (x in 0 until CELL_PX) {
                    rampTile[y * CELL_PX + x] = if (first >= 0) rampColors[first + x] else foliageColors[x]
                }
            }
            blit(atlas, RAMP_CELL, rampTile)
            return atlas
        }

        /**
         * Gives each fully transparent texel (alpha 0, colour 0 as the tables leave it) the average colour of the
         * visible texels around it, a couple of texels deep, keeping its alpha at 0. Texture filtering blends
         * the colours of neighbouring texels without looking at alpha, so a sample on the edge of a leaf hole
         * would otherwise be pulled towards black: a dark fringe on every leaf and plant, exactly where the
         * alpha test cuts them out.
         */
        private fun bleedTransparent(level: IntArray, size: Int) {
            val known = BooleanArray(size * size) { (level[it] ushr 24) != 0 }
            repeat(BLEED_PASSES) {
                val newlyKnown = ArrayList<Int>()
                val colours = ArrayList<Int>()
                for (y in 0 until size) {
                    for (x in 0 until size) {
                        val i = y * size + x
                        if (known[i]) continue
                        var r = 0
                        var g = 0
                        var b = 0
                        var n = 0
                        for (dy in -1..1) {
                            val yy = y + dy
                            if (yy < 0 || yy >= size) continue
                            for (dx in -1..1) {
                                val xx = x + dx
                                if (xx < 0 || xx >= size) continue
                                val j = yy * size + xx
                                if (!known[j]) continue
                                val p = level[j]
                                r += (p shr 16) and 0xFF
                                g += (p shr 8) and 0xFF
                                b += p and 0xFF
                                n++
                            }
                        }
                        if (n > 0) {
                            newlyKnown.add(i)
                            colours.add(((r / n) shl 16) or ((g / n) shl 8) or (b / n)) // alpha 0
                        }
                    }
                }
                for (k in newlyKnown.indices) {
                    level[newlyKnown[k]] = colours[k]
                    known[newlyKnown[k]] = true
                }
            }
        }

        /** Alpha-weighted 2x2 box filter: transparent texels (leaf holes) don't drag the
         *  colour of the surviving texels toward black, while alpha itself is a plain
         *  average so distant foliage keeps its coverage. */
        private fun halve(src: IntArray, srcSize: Int): IntArray {
            val s = srcSize / 2
            val out = IntArray(s * s)
            for (y in 0 until s) {
                for (x in 0 until s) {
                    var rs = 0
                    var gs = 0
                    var bs = 0
                    var asum = 0
                    for (dy in 0 until 2) {
                        for (dx in 0 until 2) {
                            val p = src[(y * 2 + dy) * srcSize + (x * 2 + dx)]
                            val a = p ushr 24
                            rs += ((p shr 16) and 0xFF) * a
                            gs += ((p shr 8) and 0xFF) * a
                            bs += (p and 0xFF) * a
                            asum += a
                        }
                    }
                    out[y * s + x] = if (asum == 0) {
                        0
                    } else {
                        ((asum / 4) shl 24) or ((rs / asum) shl 16) or ((gs / asum) shl 8) or (bs / asum)
                    }
                }
            }
            return out
        }
    }

    private val mips: Array<IntArray> = buildMips()
    private var textureId: Int = 0
    private var filteredSampler: Int = 0

    private fun buildMips(): Array<IntArray> {
        val levels = ArrayList<IntArray>(MIP_LEVELS)
        var cur = buildBase()
        var size = SIZE_PX
        levels.add(cur)
        for (i in 1 until MIP_LEVELS) {
            cur = halve(cur, size)
            size /= 2
            levels.add(cur)
        }
        // Colours only matter for filtering, so this comes last: the levels above were averaged from the
        // true texels (alpha-weighted), not from invented colours.
        var s = SIZE_PX
        for (level in levels) {
            bleedTransparent(level, s)
            s /= 2
        }
        return levels.toTypedArray()
    }

    fun uvFor(cell: Int): UVRect {
        if (cell < 0) return EMPTY_UV
        // Out-of-grid cells (never used by any block) keep the original computed
        // result rather than indexing past the table.
        return if (cell < UV_TABLE.size) UV_TABLE[cell] else computeUv(cell)
    }

    fun uploadToGL() {
        val ids = IntArray(1)
        GLES30.glGenTextures(1, ids, 0)
        textureId = ids[0]
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textureId)
        // Crisp pixels up close, smooth blend between mip levels in the distance (this is
        // what removes the shimmering/noise on far terrain).
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_NEAREST_MIPMAP_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_NEAREST)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_BASE_LEVEL, 0)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAX_LEVEL, MIP_LEVELS - 1)
        // No anisotropic filtering, on purpose: on many mobile GPUs it is built on bilinear
        // probes and silently overrides the NEAREST filters above, which turns 16x16 pixel
        // art into a smeared blur (worst on ground seen at a low angle).

        // The sampler the voxel-terrain shaders use (see bindFiltered): trilinear down the mip chain,
        // linear up close. The shader makes the pixels crisp again where they are magnified (a remap of
        // the coordinate that leaves a blend only one pixel wide at texel edges).
        GLES30.glGenSamplers(1, ids, 0)
        filteredSampler = ids[0]
        GLES30.glSamplerParameteri(filteredSampler, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR_MIPMAP_LINEAR)
        GLES30.glSamplerParameteri(filteredSampler, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glSamplerParameteri(filteredSampler, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glSamplerParameteri(filteredSampler, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)

        var size = SIZE_PX
        for (level in 0 until MIP_LEVELS) {
            val pixels = mips[level]
            val buf = ByteBuffer.allocateDirect(size * size * 4).order(ByteOrder.nativeOrder())
            for (p in pixels) {
                buf.put(((p shr 16) and 0xFF).toByte())
                buf.put(((p shr 8) and 0xFF).toByte())
                buf.put((p and 0xFF).toByte())
                buf.put((p ushr 24).toByte())
            }
            buf.position(0)
            GLES30.glTexImage2D(
                GLES30.GL_TEXTURE_2D, level, GLES30.GL_RGBA, size, size, 0,
                GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, buf
            )
            size /= 2
        }
    }

    /** Binds the atlas to [unit] with the texture's own sampling state (nearest texels). */
    fun bind(unit: Int = 0) {
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0 + unit)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textureId)
        GLES30.glBindSampler(unit, 0)
    }

    /** Binds the atlas to [unit] with the trilinear sampler for the voxel-terrain shaders. Any later
     *  [bind] of the same unit goes back to the texture's own state. */
    fun bindFiltered(unit: Int = 0) {
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0 + unit)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textureId)
        GLES30.glBindSampler(unit, filteredSampler)
    }
}
