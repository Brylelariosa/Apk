package com.voxelsandbox.game.world.far

import com.voxelsandbox.game.gl.TextureAtlas

/**
 * The colour keys of the distant terrain. A land vertex says what colour it is in the slot of the palette's u
 * coordinate, in one of two ways:
 *
 *  - a *palette key* (>= 0): a row and a ramp position of the block atlas' colour ramp ([TextureAtlas.rampU]),
 *    `row * 256 + quarter columns`; the fragment shader samples it from the atlas;
 *  - a *direct key* (< 0): the colour itself, `-(0xRRGGBB + 1)` (see [FarGroundColor.directKey]); the vertex
 *    shader decodes it and the three corners of a triangle blend it.
 *
 * Both kinds merge by equality in the mesh builders, and [rgbOf] says what either of them paints, which is what
 * lets the continuous surface (which blends colours from vertex to vertex) use the very same ground colours as
 * the columns do.
 */
internal object FarPalette {
    /** The key of the ramp position [column] of colour [row] (one of the TextureAtlas.RAMP_ROW_* rows). */
    fun colorKey(row: Int, column: Float): Int {
        val q = (column * 4f + 0.5f).toInt()
        return row * 256 + (if (q < 0) 0 else if (q > 124) 124 else q)
    }

    /** The colour of the walls over soil (see SurfaceKind.soilSides): the middle shade of the palette's dirt. */
    val soilWallKey: Int = colorKey(TextureAtlas.RAMP_ROW_SURFACE, TextureAtlas.RAMP_DIRT + 1f)

    /** What a soil-sided column is made of below its soil: the middle shade of the palette's stone. */
    val rockWallKey: Int = colorKey(TextureAtlas.RAMP_ROW_SURFACE, TextureAtlas.RAMP_STONE + 1f)

    /** The u of a key: a palette column, or (a direct colour) the colour itself, negative. */
    fun keyU(key: Int): Float =
        if (key < 0) key.toFloat() else TextureAtlas.rampU((key and 255) / 4f)

    fun keyV(key: Int): Float =
        if (key < 0) 0f else TextureAtlas.rampV(key shr 8, (key and 255) / 4f)

    /** The palette column the sampler picks for the ramp position [t] once it has gone through [colorKey]. */
    fun rampColumnOf(t: Float): Int {
        val q = (t * 4f + 0.5f).toInt()
        return TextureAtlas.rampColumn((if (q < 0) 0 else if (q > 124) 124 else q) / 4f)
    }

    /** What a key paints: its colour as 0xRRGGBB. For a palette key, the colour of the ramp column the sampler
     *  picks for it. */
    fun rgbOf(key: Int): Int {
        if (key < 0) return FarGroundColor.rgbOfKey(key)
        val column = TextureAtlas.rampColumn((key and 255) / 4f)
        return if ((key shr 8) == TextureAtlas.RAMP_ROW_SURFACE) TextureAtlas.rampSurfaceRgb(column)
        else TextureAtlas.rampFoliageRgb(column)
    }
}
