package com.voxelsandbox.game.world.far

import com.voxelsandbox.game.world.far.FarLevels.LAND_Y_OFFSET
import com.voxelsandbox.game.world.far.FarLevels.landFloor
import com.voxelsandbox.game.world.far.FarLevels.lodOf
import com.voxelsandbox.game.world.far.FarLevels.slopeGain
import com.voxelsandbox.game.world.far.FarLevels.step
import com.voxelsandbox.game.world.generation.TerrainGenerator
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max

/**
 * The ground of a window of [cells] x [cells] columns of one level, plus a one-column ring around the window: for
 * every column its height, the top it is drawn with, its colours and whether it is drawn at all. Array index
 * (i, j) is window cell (i - 1, j - 1). A function of the global column indices only, so a tile and the finer tiles
 * that blend into it agree on it exactly (see [FarColumnSampler]).
 */
internal class CellField(val cells: Int) {
    /** Cells along an edge of the array (the window and its ring). */
    val n = cells + 2

    /** The ground height of each column (whole blocks, as the terrain generator gives it). */
    val heights = IntArray(n * n)

    /** The height the top of each column is drawn at: its ground height, rounded to the level's height quantum (see
     *  [FarLevels.snapHeight]), plus a block (the top face), plus the canopy that stands on it. */
    val topY = FloatArray(n * n)

    /** The colour key of each column's top (see [FarPalette]). */
    val col = IntArray(n * n)

    /** The colour key of the walls that stand under each column's top (the same as [col] except over soil). */
    val wallCol = IntArray(n * n)

    /** True for the columns that are not drawn (hidden under water that is nearly opaque from the level's distance). */
    val skip = BooleanArray(n * n)

    /** The colour (0xRRGGBB) of each grass column's top, [FarGroundColor.NONE] for every other column. */
    val grass = IntArray(n * n) { FarGroundColor.NONE }

    /** The biome colour field's colour at each column that can carry grass or trees, the shift that leaves take (see
     *  [FarGroundColor.leaf]); [FarGroundColor.NONE] elsewhere. */
    val tint = IntArray(n * n) { FarGroundColor.NONE }

    var hasGrass = false
    var lowest = Int.MAX_VALUE
    var highest = Int.MIN_VALUE

    private var cornerCache: IntArray? = null

    /**
     * The colour at every corner of the window's [cells] x [cells] columns (`(cells + 1)^2` of them, row by row): the
     * average over the grass columns that meet there ([FarGroundColor.corner]). A corner depends on nothing but the
     * four columns around it, so the two tiles (or the two columns) that share it agree. Null if no column is grass.
     */
    fun corners(): IntArray? {
        if (!hasGrass) return null
        cornerCache?.let { return it }
        val k = cells + 1
        val out = IntArray(k * k)
        for (cj in 0 until k) {
            for (ci in 0 until k) {
                val a = cj * n + ci
                out[cj * k + ci] = FarGroundColor.corner(grass[a], grass[a + 1], grass[a + n], grass[a + n + 1])
            }
        }
        cornerCache = out
        return out
    }

    /** [corners], or an array of [FarGroundColor.NONE] if no column is grass (for callers that index it blindly). */
    fun cornerArray(): IntArray = corners() ?: IntArray((cells + 1) * (cells + 1)) { FarGroundColor.NONE }

    /** The colour (0xRRGGBB) the top of window cell ([wi], [wj]) has at its corner ([dx], [dz]) (each 0 or 1): the
     *  smooth biome colour for grass, the flat colour of the column for everything else. */
    fun cornerRgb(wi: Int, wj: Int, dx: Int, dz: Int): Int {
        val c = (wj + 1) * n + (wi + 1)
        if (grass[c] >= 0) return corners()!![(wj + dz) * (cells + 1) + wi + dx]
        return FarPalette.rgbOf(col[c])
    }
}

/**
 * Samples the ground of the column levels: heights from the terrain generator's pure height function, colours from
 * the [FarStyler]. Everything it returns is a pure function of the global column indices.
 */
internal class FarColumnSampler(
    private val generator: TerrainGenerator,
    private val styler: FarStyler
) {
    /** The ground of the window of [cells] x [cells] columns of [level] whose first column is the global column
     *  ([gx0], [gz0]). With [colors] false the biome colour field is not asked (for ground that is only needed for
     *  its shape). */
    fun build(level: Int, gx0: Int, gz0: Int, cells: Int, colors: Boolean = true): CellField {
        val step = step(level)
        val lod = lodOf(level)
        val shape = generator.shape
        val f = CellField(cells)
        val n = f.n
        val heights = f.heights
        val topY = f.topY
        val col = f.col
        val wallCol = f.wallCol
        val skip = f.skip
        val grassRgb = f.grass
        val tintRgb = f.tint
        // Heights are sampled one column beyond the ring too, so that every column of the window (the ring
        // included) gets its slope from its true neighbours, not from a clamped edge: the ring's colour, biome
        // and canopy are then exactly what the neighbouring tile computes for the same column, and the walls
        // along a tile's edge agree on both sides.
        val m = cells + 4
        val big = IntArray(m * m)
        // The smooth base elevation of each column, a by-product of its height (see
        // TerrainShape.heightAndCoast), for the biome rules.
        val coast = DoubleArray(m * m)
        for (j in 0 until m) {
            val wz = (gz0 + j - 1.5) * step
            for (i in 0 until m) {
                val wx = (gx0 + i - 1.5) * step
                big[j * m + i] = floor(shape.heightAndCoast(wx, wz, lod, coast, j * m + i)).toInt()
            }
        }
        for (j in 0 until n) {
            for (i in 0 until n) {
                val h = big[(j + 1) * m + (i + 1)]
                heights[j * n + i] = h
                if (i in 1..cells && j in 1..cells) {
                    if (h < f.lowest) f.lowest = h
                    if (h > f.highest) f.highest = h
                }
            }
        }

        val span = 2f * step
        val slopeGain = slopeGain(level)
        val floorY = landFloor(level)
        val style = FarStyler.Style()
        for (j in 0 until n) {
            val wz = (gz0 + j - 0.5) * step
            for (i in 0 until n) {
                val c = j * n + i
                val bc = (j + 1) * m + (i + 1) // the same column in the larger window
                val h = heights[c]
                val wx = (gx0 + i - 0.5) * step
                val groundTop = FarLevels.snapHeight(level, h) + LAND_Y_OFFSET // the top face of the voxel column
                topY[c] = groundTop
                if (groundTop <= floorY) {
                    skip[c] = true // hidden under water that is (nearly) opaque from here
                    continue
                }
                val dhdx = (big[bc + 1] - big[bc - 1]) / span
                val dhdz = (big[bc + m] - big[bc - m]) / span
                val slope = max(abs(dhdx), abs(dhdz)) * slopeGain
                styler.style(level, gx0 + (i - 1), gz0 + (j - 1), wx, wz, h, slope.toDouble(), coast[bc], colors, style)
                col[c] = style.color
                wallCol[c] = style.wall
                tintRgb[c] = style.tint
                if (style.grass >= 0) {
                    grassRgb[c] = style.grass
                    f.hasGrass = true
                }
                if (style.raise > 0f) topY[c] = groundTop + style.raise
            }
        }
        return f
    }
}
