package com.voxelsandbox.game.gl

import android.opengl.GLES30
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * The GPU side of the water pattern (see [WaterPattern] for the pixels and [WaterAnimation] for how the
 * shader finds its way around them): the wave animation as a 2D texture array, one layer per frame, and the
 * small tone texture.
 *
 * The wave array is read with nearest-texel magnification (crisp square pixels up close, like the block
 * textures) and trilinear mip-mapping in the distance, where the ripples smoothly average out instead of
 * aliasing. Repeat wrapping in both directions: the tile is seamless. The tone texture is filtered
 * linearly (it is a soft field, four blocks to the texel) and mip-mapped too.
 *
 * Nothing in here knows about frames in time: the renderer picks the layer with a uniform.
 */
class WaterTexture {
    private var waveId = 0
    private var toneId = 0

    /** Builds both textures in the current GL context (a new context needs a fresh upload). Works on a texture
     *  unit of its own, so the block atlas bound to unit 0 is not disturbed. */
    fun upload() {
        val ids = IntArray(2)
        GLES30.glGenTextures(2, ids, 0)
        waveId = ids[0]
        toneId = ids[1]
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0 + UPLOAD_UNIT)
        uploadWaves()
        uploadTone()
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
    }

    /** Binds the wave array to texture unit [waveUnit] and the tone texture to [toneUnit]. */
    fun bind(waveUnit: Int, toneUnit: Int) {
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0 + waveUnit)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D_ARRAY, waveId)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0 + toneUnit)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, toneId)
    }

    private fun uploadWaves() {
        val size = WaterPattern.SIZE
        var levels = 1
        while ((size shr levels) > 0) levels++
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D_ARRAY, waveId)
        GLES30.glTexStorage3D(GLES30.GL_TEXTURE_2D_ARRAY, levels, GLES30.GL_RGBA8, size, size, WaterPattern.FRAMES)

        // One layer at a time through a reusable buffer: the whole animation is 2.6 MB, no need to hold it twice.
        val buf = ByteBuffer.allocateDirect(size * size * 4).order(ByteOrder.nativeOrder())
        val frames = WaterPattern.frames
        for (f in 0 until WaterPattern.FRAMES) {
            buf.clear()
            for (argb in frames[f]) {
                buf.put((argb shr 16).toByte())
                buf.put((argb shr 8).toByte())
                buf.put(argb.toByte())
                buf.put((argb ushr 24).toByte())
            }
            buf.position(0)
            GLES30.glTexSubImage3D(
                GLES30.GL_TEXTURE_2D_ARRAY, 0, 0, 0, f, size, size, 1,
                GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, buf
            )
        }
        GLES30.glGenerateMipmap(GLES30.GL_TEXTURE_2D_ARRAY)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D_ARRAY, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR_MIPMAP_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D_ARRAY, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_NEAREST)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D_ARRAY, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_REPEAT)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D_ARRAY, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_REPEAT)
    }

    private fun uploadTone() {
        val size = WaterPattern.TONE_SIZE
        val buf = ByteBuffer.allocateDirect(size * size).order(ByteOrder.nativeOrder())
        buf.put(WaterPattern.tone)
        buf.position(0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, toneId)
        GLES30.glPixelStorei(GLES30.GL_UNPACK_ALIGNMENT, 1)
        GLES30.glTexImage2D(
            GLES30.GL_TEXTURE_2D, 0, GLES30.GL_R8, size, size, 0,
            GLES30.GL_RED, GLES30.GL_UNSIGNED_BYTE, buf
        )
        GLES30.glPixelStorei(GLES30.GL_UNPACK_ALIGNMENT, 4)
        GLES30.glGenerateMipmap(GLES30.GL_TEXTURE_2D)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR_MIPMAP_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_REPEAT)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_REPEAT)
    }

    private companion object {
        /** A texture unit nothing else samples from, used while uploading. */
        const val UPLOAD_UNIT = 6
    }
}
