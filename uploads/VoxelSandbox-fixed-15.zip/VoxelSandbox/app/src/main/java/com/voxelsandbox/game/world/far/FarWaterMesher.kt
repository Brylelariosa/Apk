package com.voxelsandbox.game.world.far

import com.voxelsandbox.game.world.far.FarLevels.DEEP_WATER
import com.voxelsandbox.game.world.far.FarLevels.LAND_Y_OFFSET
import com.voxelsandbox.game.world.far.FarLevels.WATER_Y
import com.voxelsandbox.game.world.far.FarLevels.cellsOf
import com.voxelsandbox.game.world.far.FarLevels.step
import com.voxelsandbox.game.world.mesh.MeshData

/** The sea, lake and river surfaces of the distant terrain: see [build]. */
internal object FarWaterMesher {
    /** Smallest block of deep water cells merged into one fan (a tile holds at most one fan
     *  per aligned block of that size). */
    private const val MIN_FAN_BLOCK = 4

    /** The water of a tile: the depth at each vertex is the mean over the four columns that meet there
     *  ([heights] are the ground heights of the tile's columns with their ring, see [CellField]). */
    fun build(level: Int, x0: Int, z0: Int, heights: IntArray): MeshData {
        val cells = cellsOf(level)
        val verts = cells + 1
        val n = cells + 2
        val depths = FloatArray(verts * verts)
        for (j in 0 until verts) {
            for (i in 0 until verts) {
                // The four cells meeting at vertex (i, j) are array cells (i, j) .. (i + 1, j + 1).
                val c = j * n + i
                depths[j * verts + i] = (cellDepth(heights[c]) + cellDepth(heights[c + 1]) +
                    cellDepth(heights[c + n]) + cellDepth(heights[c + n + 1])) * 0.25f
            }
        }
        return build(level, x0, z0, depths)
    }

    /** The sea / lake / river surface of a tile: a flat grid at [WATER_Y] whose vertices
     *  carry the [depths] of the water (one per vertex of the tile's lattice, row by row), and only the cells
     *  that touch water.
     *
     *  Open sea is the bulk of it, and over deep water every vertex has the same attributes
     *  (the water shader's depth tint has long saturated), so those cells would all draw
     *  identically. Instead of two triangles per cell, any aligned block of 4x4 up to 64x64
     *  cells whose every vertex is deep becomes a fan of triangles from one extra vertex at its
     *  centre to the vertices around its edge: the edge keeps every grid vertex, so the block
     *  still meets its neighbours (merged or not) exactly, with no cracks, while a whole deep
     *  tile costs 256 triangles instead of 8192. */
    private fun build(level: Int, x0: Int, z0: Int, depths: FloatArray): MeshData {
        val step = step(level)
        val cells = cellsOf(level)
        val verts = cells + 1
        val stride = MeshData.FLOATS_PER_VERTEX
        val gridVerts = verts * verts
        val vertexData = FloatArray((gridVerts + (cells / MIN_FAN_BLOCK) * (cells / MIN_FAN_BLOCK)) * stride)
        var vi = 0
        for (j in 0 until verts) {
            for (i in 0 until verts) {
                vertexData[vi++] = (x0 + i * step).toFloat()
                vertexData[vi++] = WATER_Y
                vertexData[vi++] = (z0 + j * step).toFloat()
                vertexData[vi++] = depths[j * verts + i] // the water shader reads depth from the first data slot
                vertexData[vi++] = 0f // flow X: distant water is always still
                vertexData[vi++] = 0f // flow Z
            }
        }

        // Prefix sums of the deep vertices: "is this whole block deep" in O(1).
        val w = verts + 1
        val deepSum = IntArray(w * w)
        for (j in 0 until verts) {
            var row = 0
            for (i in 0 until verts) {
                if (depths[j * verts + i] >= DEEP_WATER) row++
                deepSum[(j + 1) * w + (i + 1)] = deepSum[j * w + (i + 1)] + row
            }
        }

        val indices = IntArray(cells * cells * 6)
        var ii = 0
        var fans = 0

        fun emit(i0: Int, j0: Int, size: Int) {
            if (size >= MIN_FAN_BLOCK) {
                val s1 = size + 1
                val deepCount = deepSum[(j0 + s1) * w + (i0 + s1)] - deepSum[j0 * w + (i0 + s1)] -
                    deepSum[(j0 + s1) * w + i0] + deepSum[j0 * w + i0]
                if (deepCount == s1 * s1) {
                    val center = gridVerts + fans
                    fans++
                    val o = center * stride
                    vertexData[o] = (x0 + (i0 + size / 2) * step).toFloat()
                    vertexData[o + 1] = WATER_Y
                    vertexData[o + 2] = (z0 + (j0 + size / 2) * step).toFloat()
                    vertexData[o + 3] = DEEP_WATER
                    vertexData[o + 4] = 0f
                    vertexData[o + 5] = 0f
                    // Walk the block's edge: along the top (+i), the right (+j), the bottom (-i)
                    // and the left (-j); each edge step with the centre is one upward-facing triangle.
                    val count = 4 * size
                    for (k in 0 until count) {
                        val p = edgeVertex(i0, j0, size, k, verts)
                        val q = edgeVertex(i0, j0, size, if (k + 1 == count) 0 else k + 1, verts)
                        indices[ii++] = center
                        indices[ii++] = q
                        indices[ii++] = p
                    }
                    return
                }
            }
            if (size == 1) {
                val a = j0 * verts + i0
                val b = a + 1
                val d = a + verts
                val c = d + 1
                if (depths[a] <= 0f && depths[b] <= 0f && depths[c] <= 0f && depths[d] <= 0f) return
                indices[ii++] = a; indices[ii++] = c; indices[ii++] = b
                indices[ii++] = a; indices[ii++] = d; indices[ii++] = c
                return
            }
            val half = size / 2
            emit(i0, j0, half)
            emit(i0 + half, j0, half)
            emit(i0, j0 + half, half)
            emit(i0 + half, j0 + half, half)
        }
        emit(0, 0, cells)

        if (ii == 0) return MeshData.EMPTY
        val total = gridVerts + fans
        return MeshData(vertexData.copyOf(total * stride), indices.copyOf(ii), total, WATER_Y, WATER_Y)
    }

    /** Grid vertex number [k] (0 until 4 * size) when walking round the edge of the block of
     *  [size] cells at (i0, j0): top edge left to right, right edge top to bottom, bottom
     *  edge right to left, left edge bottom to top. */
    private fun edgeVertex(i0: Int, j0: Int, size: Int, k: Int, verts: Int): Int {
        val side = k / size
        val t = k - side * size
        return when (side) {
            0 -> j0 * verts + (i0 + t)
            1 -> (j0 + t) * verts + (i0 + size)
            2 -> (j0 + size) * verts + (i0 + size - t)
            else -> (j0 + size - t) * verts + i0
        }
    }

    private fun cellDepth(h: Int): Float = (WATER_Y - (h + LAND_Y_OFFSET)).coerceIn(0f, DEEP_WATER)
}
