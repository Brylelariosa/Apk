package com.voxelsandbox.game.save

import android.content.Context
import com.voxelsandbox.game.inventory.Hotbar
import com.voxelsandbox.game.player.Player
import com.voxelsandbox.game.world.World
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream

/**
 * Single-slot world save to app-private internal storage (no storage permission
 * needed — nothing here is written anywhere the OS would prompt for access). Only
 * chunks the player has actually modified are written; everything else regenerates
 * deterministically from the seed, which is what keeps the save small no matter how
 * much of the world has been explored. The byte layout is [SaveCodec]'s.
 *
 * Call from a background thread only (see GameEngine) — this does blocking file I/O.
 */
class SaveManager(context: Context) {
    private val saveFile = File(context.filesDir, "world1.sav")

    fun hasSave(): Boolean = saveFile.exists()

    fun save(seed: Long, player: Player, hotbar: Hotbar, world: World) {
        val tmp = File(saveFile.parentFile, saveFile.name + ".tmp")
        val header = SaveHeader(
            seed,
            player.position.x, player.position.y, player.position.z,
            player.yaw, player.pitch,
            hotbar.exportIds(), hotbar.selectedIndex,
            player.flying
        )
        val modified = world.allChunks().filter { it.hasPlayerEdits }
        DataOutputStream(GZIPOutputStream(tmp.outputStream().buffered())).use { out ->
            SaveCodec.write(
                out, header, modified.size,
                modified.asSequence().map { it.pos to it.serializeBlocks() }.iterator()
            )
        }
        // Write to a temp file and swap it in only once fully written, so a crash or
        // low-battery kill mid-save can't leave a half-written, corrupt save file.
        tmp.copyTo(saveFile, overwrite = true)
        tmp.delete()
    }

    fun load(): LoadedSave? {
        if (!saveFile.exists()) return null
        return try {
            DataInputStream(GZIPInputStream(saveFile.inputStream().buffered())).use { SaveCodec.read(it) }
        } catch (t: Throwable) {
            // Not even a readable gzip stream: same as any other unusable save.
            null
        }
    }
}
