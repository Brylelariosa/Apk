package com.voxelsandbox.game.ui

import android.content.Context
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.GridView
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.voxelsandbox.game.R
import com.voxelsandbox.game.creative.BlockCategory
import com.voxelsandbox.game.creative.CatalogEntry
import com.voxelsandbox.game.creative.CreativeCatalog
import com.voxelsandbox.game.inventory.Hotbar
import com.voxelsandbox.game.world.BlockType

/**
 * The creative inventory screen: a category rail, a search box and a scrolling grid of every block of the
 * registry ([CreativeCatalog]). Tapping a block makes it the selected hotbar slot's block at once (or just
 * selects the slot that already has it). Views are the ones of overlay_hud.xml; the grid recycles its cells,
 * so the whole catalogue scrolls smoothly however large it grows.
 *
 * While it is open a full-screen scrim sits between it and the game controls, so a touch can neither move
 * the player nor turn the camera nor place a block (see [onOpenChanged], which also tells the HUD to drop
 * whatever input was held when it opened).
 */
class CreativeInventoryController(
    root: View,
    private val hotbar: Hotbar,
    private val icons: BlockIconCache,
    private val onOpenChanged: (Boolean) -> Unit,
    private val onPicked: (BlockType) -> Unit
) {
    private val context: Context = root.context
    private val scrim: View = root.findViewById(R.id.creative_scrim)
    private val panel: View = root.findViewById(R.id.creative_panel)
    private val search: EditText = root.findViewById(R.id.creative_search)
    private val countText: TextView = root.findViewById(R.id.creative_count)
    private val closeButton: ImageButton = root.findViewById(R.id.creative_close)
    private val categoryRail: LinearLayout = root.findViewById(R.id.creative_categories)
    private val grid: GridView = root.findViewById(R.id.creative_grid)
    private val emptyText: TextView = root.findViewById(R.id.creative_empty)

    private val density = context.resources.displayMetrics.density
    private val iconScale = icons.scaleFor(ICON_DP)
    private val adapter = EntryAdapter()
    private val chips = ArrayList<Pair<BlockCategory?, TextView>>()

    private var category: BlockCategory? = null
    private var results: List<CatalogEntry> = emptyList()

    /** What the grid last showed of the hotbar (selection and contents), so it is only redrawn when that changed. */
    private var shownHotbarKey = 0L

    var isOpen: Boolean = false
        private set

    init {
        buildCategoryRail()
        grid.adapter = adapter
        grid.setOnItemClickListener { _, view, position, _ ->
            val entry = results.getOrNull(position) ?: return@setOnItemClickListener
            hotbar.pick(entry.block)
            view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            shownHotbarKey = hotbarKey()
            adapter.notifyDataSetChanged()
            onPicked(entry.block)
        }
        grid.setOnScrollListener(object : AbsListView.OnScrollListener {
            override fun onScrollStateChanged(view: AbsListView, scrollState: Int) {
                if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_TOUCH_SCROLL) hideKeyboard()
            }

            override fun onScroll(view: AbsListView, first: Int, visible: Int, total: Int) {}
        })
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) = refresh()
        })
        search.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH || actionId == EditorInfo.IME_ACTION_DONE) {
                hideKeyboard()
                true
            } else {
                false
            }
        }
        closeButton.setOnClickListener { close() }
        scrim.setOnClickListener { close() }
    }

    fun open() {
        if (isOpen) return
        isOpen = true
        scrim.visibility = View.VISIBLE
        panel.visibility = View.VISIBLE
        shownHotbarKey = hotbarKey()
        refresh()
        onOpenChanged(true)
    }

    fun close() {
        if (!isOpen) return
        isOpen = false
        hideKeyboard()
        search.clearFocus()
        // The next visit starts from the whole catalogue again, not from the last search.
        search.setText("")
        category = null
        updateChipSelection()
        panel.visibility = View.GONE
        scrim.visibility = View.GONE
        onOpenChanged(false)
    }

    fun toggle() = if (isOpen) close() else open()

    /** Redraws the cells' selection marks when the hotbar changed from outside (e.g. a slot was tapped);
     *  cheap to call often, it does nothing while the hotbar is as the grid last drew it. */
    fun refreshSelection() {
        if (!isOpen) return
        val key = hotbarKey()
        if (key == shownHotbarKey) return
        shownHotbarKey = key
        adapter.notifyDataSetChanged()
    }

    /** A number that changes whenever the hotbar's selection or any slot's block does (no allocation). */
    private fun hotbarKey(): Long {
        var key = hotbar.selectedIndex.toLong()
        for (i in 0 until Hotbar.SIZE) key = key * 61 + hotbar.blockAt(i).id
        return key
    }

    // ---- categories and search ---------------------------------------------------------------

    private fun buildCategoryRail() {
        categoryRail.removeAllViews()
        chips.clear()
        addChip(null, context.getString(R.string.creative_all))
        for (c in CreativeCatalog.categories) addChip(c, c.label)
        updateChipSelection()
    }

    private fun addChip(c: BlockCategory?, label: String) {
        val chip = TextView(context).apply {
            text = label
            textSize = 13f
            setTextColor(context.getColor(R.color.text_primary))
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), 0, dp(8), 0)
            setBackgroundResource(R.drawable.bg_chip)
            minHeight = dp(42)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42)).apply {
                bottomMargin = dp(6)
            }
            isClickable = true
            setOnClickListener {
                category = c
                updateChipSelection()
                refresh()
                grid.setSelection(0)
            }
        }
        chips.add(c to chip)
        categoryRail.addView(chip)
    }

    private fun updateChipSelection() {
        for ((c, chip) in chips) chip.isSelected = (c == category)
    }

    private fun refresh() {
        val query = search.text?.toString().orEmpty()
        results = CreativeCatalog.search(query, category)
        adapter.notifyDataSetChanged()
        val total = CreativeCatalog.entries.size
        countText.text = if (results.size == total) {
            context.getString(R.string.creative_count, total)
        } else {
            context.getString(R.string.creative_count_filtered, results.size, total)
        }
        if (results.isEmpty()) {
            emptyText.text = context.getString(R.string.creative_empty, query.trim())
            emptyText.visibility = View.VISIBLE
        } else {
            emptyText.visibility = View.GONE
        }
    }

    private fun hideKeyboard() {
        val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(search.windowToken, 0)
    }

    private fun dp(v: Int): Int = (v * density).toInt()

    // ---- the grid ----------------------------------------------------------------------------

    private inner class EntryAdapter : BaseAdapter() {
        override fun getCount(): Int = results.size
        override fun getItem(position: Int): Any = results[position]
        override fun getItemId(position: Int): Long = results[position].block.id.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val cell = (convertView as? Cell) ?: Cell(context)
            cell.bind(results[position])
            return cell
        }
    }

    /** One block of the grid: its icon above its name. */
    private inner class Cell(context: Context) : LinearLayout(context) {
        private val icon = ImageView(context)
        private val name = TextView(context)

        init {
            orientation = VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(4), dp(6), dp(4), dp(4))
            minimumHeight = dp(84)
            layoutParams = AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(88))
            icon.scaleType = ImageView.ScaleType.CENTER
            addView(icon, LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            name.textSize = 10.5f
            name.gravity = Gravity.CENTER
            name.maxLines = 2
            name.ellipsize = android.text.TextUtils.TruncateAt.END
            addView(name, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }

        fun bind(entry: CatalogEntry) {
            icon.setImageDrawable(icons.drawable(entry.block, iconScale))
            name.text = entry.name
            contentDescription = entry.name
            val selected = entry.block == hotbar.selectedBlock()
            val inHotbar = hotbar.indexOf(entry.block) >= 0
            setBackgroundResource(if (selected) R.drawable.bg_hotbar_slot_selected else R.drawable.bg_hotbar_slot)
            name.setTextColor(
                context.getColor(if (inHotbar) R.color.slot_selected else R.color.text_primary)
            )
        }
    }

    private companion object {
        /** About how big a block icon is drawn in the grid; the real size is a whole multiple of its 32 pixels. */
        const val ICON_DP = 44f
    }
}
