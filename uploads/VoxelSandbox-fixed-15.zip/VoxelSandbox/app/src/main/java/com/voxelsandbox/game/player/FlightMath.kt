package com.voxelsandbox.game.player

import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.sin

/**
 * The arithmetic of creative flight, kept apart from the game loop so it can be tested on its own.
 *
 * Controls: the joystick moves the player horizontally, forward being the way the camera faces (looking up
 * or down does not climb or sink: height is changed only by the ascend and descend buttons). Sideways is
 * perpendicular to that. The result is a target velocity; the real velocity eases towards it with an
 * exponential approach, which feels responsive but never jerks.
 *
 * Frame-rate independence: the approach is integrated exactly over each frame (not stepped with Euler), so
 * flying for a second covers the same distance at 20 fps as at 120 fps for the same controls.
 */
object FlightMath {
    /** Time constant (seconds) while speeding up or turning, and while slowing down or stopping. */
    const val ACCEL_TIME = 0.10f
    const val BRAKE_TIME = 0.06f

    /** Vertical speed of the ascend / descend buttons relative to the horizontal fly speed, within limits. */
    private const val CLIMB_FRACTION = 0.6f
    private const val CLIMB_MIN = 8f
    private const val CLIMB_MAX = 60f

    fun climbSpeed(flySpeed: Float): Float = (flySpeed * CLIMB_FRACTION).coerceIn(CLIMB_MIN, CLIMB_MAX)

    /**
     * The velocity the controls ask for, in blocks per second, written to [out] (x, y, z).
     * [forward] and [strafe] are the joystick (each -1..1, the pair limited to length 1), [yaw] the
     * camera's heading in radians (0 looks down -Z, see [Player]).
     */
    fun targetVelocity(
        forward: Float, strafe: Float, ascend: Boolean, descend: Boolean,
        yaw: Float, flySpeed: Float, out: FloatArray
    ) {
        var f = forward
        var s = strafe
        val len = hypot(f.toDouble(), s.toDouble()).toFloat()
        if (len > 1f) {
            f /= len
            s /= len
        }
        out[0] = (f * sin(yaw) + s * cos(yaw)) * flySpeed
        out[2] = (-f * cos(yaw) + s * sin(yaw)) * flySpeed
        out[1] = ((if (ascend) 1f else 0f) - (if (descend) 1f else 0f)) * climbSpeed(flySpeed)
    }

    /**
     * Eases one velocity component towards [target] over [dt] seconds. Returns the distance travelled in that
     * time and stores the new velocity in [velocity] (index [axis]). Exact for a constant target.
     */
    fun advance(velocity: FloatArray, axis: Int, target: Float, dt: Float): Float {
        val v0 = velocity[axis]
        val tau = if (abs(target) < abs(v0)) BRAKE_TIME else ACCEL_TIME
        val k = exp(-dt / tau)
        velocity[axis] = target + (v0 - target) * k
        return target * dt + (v0 - target) * tau * (1f - k)
    }
}
