package com.voxelsandbox.game.gl

import android.opengl.GLES30

/**
 * The two uniforms every fragment shader of the distant terrain shares, `uClip` and `uDither` (see
 * Shaders.CLIP_AND_DITHER for what they mean): one object per program that owns their locations and their current
 * values, so the land renderer and the water renderer set them the same way, and a value that has not changed is
 * never sent to the driver again (a frame with a few stand-ins would otherwise set them for every tile).
 *
 * GL-thread only; the owning program must be bound whenever a setter is called.
 */
internal class ClipDither(private val clipLocation: Int, private val ditherLocation: Int) {
    private var x0 = -UNBOUNDED
    private var z0 = -UNBOUNDED
    private var x1 = UNBOUNDED
    private var z1 = UNBOUNDED
    private var lo = 0f
    private var hi = 1f

    /** Draw everything, and upload that whatever was set before (call once per use of the program: uniforms keep
     *  their values from the previous frame, and the context may be new). */
    fun reset() {
        x0 = -UNBOUNDED
        z0 = -UNBOUNDED
        x1 = UNBOUNDED
        z1 = UNBOUNDED
        lo = 0f
        hi = 1f
        GLES30.glUniform4f(clipLocation, x0, z0, x1, z1)
        GLES30.glUniform2f(ditherLocation, lo, hi)
    }

    /** Show only the ground inside the world rectangle [nx0, nx1) x [nz0, nz1). */
    fun clip(nx0: Float, nz0: Float, nx1: Float, nz1: Float) {
        if (nx0 == x0 && nz0 == z0 && nx1 == x1 && nz1 == z1) return
        x0 = nx0
        z0 = nz0
        x1 = nx1
        z1 = nz1
        GLES30.glUniform4f(clipLocation, x0, z0, x1, z1)
    }

    fun unclip() = clip(-UNBOUNDED, -UNBOUNDED, UNBOUNDED, UNBOUNDED)

    /** Draw only the pixels whose fixed screen-space noise lies in [nlo, nhi) (0..1). */
    fun dither(nlo: Float, nhi: Float) {
        if (nlo == lo && nhi == hi) return
        lo = nlo
        hi = nhi
        GLES30.glUniform2f(ditherLocation, lo, hi)
    }

    fun undither() = dither(0f, 1f)

    companion object {
        /** Bounds that clip nothing (far beyond any world coordinate, and exact in a float). */
        const val UNBOUNDED = 1.0e9f
    }
}
