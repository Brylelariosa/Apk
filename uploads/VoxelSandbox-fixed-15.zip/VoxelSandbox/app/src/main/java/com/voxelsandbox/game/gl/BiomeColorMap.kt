package com.voxelsandbox.game.gl

import android.opengl.GLES30
import com.voxelsandbox.game.world.color.BiomeColorField
import com.voxelsandbox.game.world.color.BiomeColorLayout
import com.voxelsandbox.game.world.color.BiomeColorLayout.TEXELS
import com.voxelsandbox.game.world.color.BiomeColorLayout.TILES
import com.voxelsandbox.game.world.color.BiomeColorTiles
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.ceil

/**
 * The biome colour field ([BiomeColorField]) as a texture the voxel shaders read: one texel per cell of
 * [spacing] x [spacing] blocks, [TEXELS] x [TEXELS] texels wrapping around (a torus), so that the texel of a
 * place is the same wherever the camera is and nothing ever moves in it: the texture is addressed by world
 * position, bilinearly filtered, and holds only values that are pure functions of position. That is what
 * makes the colour of the ground stable as the camera moves, continuous over chunk borders and untouched by
 * meshing: no vertex carries a colour, so there is nothing that could change when a chunk is rebuilt or
 * merged differently.
 *
 * The texture is filled in tiles of 16 x 16 texels (see [BiomeColorTiles]) on a background thread, nearest
 * to the eye first, and uploaded a few tiles per frame. Only tiles within the voxel area (the radius the
 * caller passes to [update], plus a margin) are ever computed. A place whose tile has not arrived yet shows
 * the neutral grass colour (what the texture itself looks like), never black or garbage.
 *
 * [spacing] starts at 4 blocks and doubles when a larger voxel area needs it (see [BiomeColorLayout], which
 * also holds the arithmetic of where a place lives in the texture, so that it can be tested without a GL context).
 *
 * All methods but the worker's own run on the GL thread.
 */
class BiomeColorMap(private val field: BiomeColorField) {
    private var textureId = 0
    private var spacing = BiomeColorLayout.MIN_SPACING

    /** For each texture slot, the tile it shows: key = ([ReadyTile.key]), or NONE. */
    private val shown = LongArray(SLOTS) { NONE }

    private val requested = HashSet<Long>()
    private val ready = ConcurrentLinkedQueue<ReadyTile>()
    private var executor: ExecutorService? = null

    /** Bumped whenever the meaning of the texels changes (new spacing, new GL context): results of older
     *  jobs are dropped. */
    @Volatile private var epoch = 0

    private var lastEyeTileX = Int.MIN_VALUE
    private var lastEyeTileZ = Int.MIN_VALUE
    private var lastRadiusTiles = -1
    private var inFlight = 0

    private val uploadBuffer: ByteBuffer =
        ByteBuffer.allocateDirect(BiomeColorTiles.TILE * BiomeColorTiles.TILE * 4).order(ByteOrder.nativeOrder())

    private class ReadyTile(val epoch: Int, val tx: Int, val tz: Int, val rgb: IntArray) {
        val key: Long get() = key(tx, tz)
    }

    /** Creates the texture (every texel the neutral colour). Call on the GL thread, once per GL context. */
    fun create() {
        val ids = IntArray(1)
        GLES30.glGenTextures(1, ids, 0)
        textureId = ids[0]
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0 + UNIT)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textureId)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_REPEAT)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_REPEAT)
        fillNeutral()
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        resetTiles()
    }

    /** Frees the GL texture and stops the worker. */
    fun release() {
        if (textureId != 0) {
            GLES30.glDeleteTextures(1, intArrayOf(textureId), 0)
            textureId = 0
        }
        executor?.shutdownNow()
        executor = null
        ready.clear()
        requested.clear()
        epoch++
    }

    /** Binds the map to its texture unit. */
    fun bind() {
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0 + UNIT)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textureId)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
    }

    /** The shader's view of the map: texture coordinates are `x / worldSize + offset` for a position `x`
     *  blocks from the eye's whole-block position [originX] / [originZ]. */
    fun frameOffsetU(originX: Float): Float = BiomeColorLayout.frameOffset(originX, spacing)
    fun frameOffsetV(originZ: Float): Float = BiomeColorLayout.frameOffset(originZ, spacing)
    fun inverseWorldSize(): Float = BiomeColorLayout.inverseWorldSize(spacing)

    /**
     * Once per frame: keeps the tiles around the eye ([eyeX], [eyeZ], world blocks) up to date for a voxel
     * area of [radiusBlocks] blocks, asks the worker for the ones that are missing and uploads those that
     * have arrived.
     */
    fun update(eyeX: Double, eyeZ: Double, radiusBlocks: Float) {
        if (textureId == 0) return
        val wanted = BiomeColorLayout.spacingFor(radiusBlocks)
        if (wanted != spacing) {
            spacing = wanted
            fillNeutral()
            resetTiles()
        }
        val tileBlocks = (BiomeColorTiles.TILE * spacing).toDouble()
        val etx = BiomeColorLayout.tileOf(eyeX, spacing)
        val etz = BiomeColorLayout.tileOf(eyeZ, spacing)
        // Tiles within the radius (to the farthest corner of the square that holds it), plus one for the
        // bilinear footprint at its rim.
        val rt = ceil(radiusBlocks / tileBlocks).toInt() + 1
        if (etx != lastEyeTileX || etz != lastEyeTileZ || rt != lastRadiusTiles || inFlight > 0 || requested.isNotEmpty()) {
            lastEyeTileX = etx
            lastEyeTileZ = etz
            lastRadiusTiles = rt
            request(etx, etz, rt)
        }
        drain(etx, etz, rt)
    }

    /** Asks for every tile of the square of radius [rt] around ([etx], [etz]) that is neither shown nor
     *  requested, nearest first (ring by ring), keeping only a few in the worker's queue at a time. */
    private fun request(etx: Int, etz: Int, rt: Int) {
        for (ring in 0..rt) {
            for (dz in -ring..ring) {
                for (dx in -ring..ring) {
                    if (maxOf(kotlin.math.abs(dx), kotlin.math.abs(dz)) != ring) continue
                    if (inFlight >= MAX_IN_FLIGHT) return
                    val tx = etx + dx
                    val tz = etz + dz
                    val k = key(tx, tz)
                    if (shown[BiomeColorLayout.slot(tx, tz)] == k || k in requested) continue
                    requested.add(k)
                    inFlight++
                    submit(tx, tz)
                }
            }
        }
    }

    private fun submit(tx: Int, tz: Int) {
        val ex = executor ?: Executors.newSingleThreadExecutor { r ->
            Thread(r, "biome-colors").apply { isDaemon = true; priority = Thread.NORM_PRIORITY - 1 }
        }.also { executor = it }
        val e = epoch
        val s = spacing
        ex.execute {
            if (e != epoch) return@execute
            val rgb = IntArray(BiomeColorTiles.TILE * BiomeColorTiles.TILE)
            BiomeColorTiles.compute(field, tx, tz, s, rgb, scratch.get()!!)
            ready.add(ReadyTile(e, tx, tz, rgb))
        }
    }

    private val scratch = object : ThreadLocal<DoubleArray>() {
        override fun initialValue() = DoubleArray(1)
    }

    /** Uploads up to [MAX_UPLOADS_PER_FRAME] finished tiles that are still wanted. */
    private fun drain(etx: Int, etz: Int, rt: Int) {
        var uploads = 0
        while (uploads < MAX_UPLOADS_PER_FRAME) {
            val t = ready.poll() ?: break
            inFlight--
            requested.remove(t.key)
            if (t.epoch != epoch) continue
            // A tile that fell out of the area while it was being computed would only take the slot of one that
            // is wanted.
            if (kotlin.math.abs(t.tx - etx) > rt || kotlin.math.abs(t.tz - etz) > rt) continue
            upload(t)
            uploads++
        }
        if (inFlight < 0) inFlight = 0
    }

    private fun upload(t: ReadyTile) {
        val buf = uploadBuffer
        buf.clear()
        for (c in t.rgb) {
            buf.put(((c shr 16) and 0xFF).toByte())
            buf.put(((c shr 8) and 0xFF).toByte())
            buf.put((c and 0xFF).toByte())
            buf.put(255.toByte())
        }
        buf.position(0)
        val sx = Math.floorMod(t.tx, TILES)
        val sz = Math.floorMod(t.tz, TILES)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0 + UNIT)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textureId)
        GLES30.glTexSubImage2D(
            GLES30.GL_TEXTURE_2D, 0, sx * BiomeColorTiles.TILE, sz * BiomeColorTiles.TILE,
            BiomeColorTiles.TILE, BiomeColorTiles.TILE, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, buf
        )
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        shown[BiomeColorLayout.slot(t.tx, t.tz)] = t.key
    }

    private fun resetTiles() {
        epoch++
        java.util.Arrays.fill(shown, NONE)
        requested.clear()
        ready.clear()
        inFlight = 0
        lastEyeTileX = Int.MIN_VALUE
        lastEyeTileZ = Int.MIN_VALUE
        lastRadiusTiles = -1
    }

    private fun fillNeutral() {
        val c = field.neutral
        val buf = ByteBuffer.allocateDirect(TEXELS * TEXELS * 4).order(ByteOrder.nativeOrder())
        val r = ((c shr 16) and 0xFF).toByte()
        val g = ((c shr 8) and 0xFF).toByte()
        val b = (c and 0xFF).toByte()
        repeat(TEXELS * TEXELS) { buf.put(r); buf.put(g); buf.put(b); buf.put(255.toByte()) }
        buf.position(0)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0 + UNIT)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textureId)
        GLES30.glTexImage2D(
            GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGBA, TEXELS, TEXELS, 0,
            GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, buf
        )
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
    }

    companion object {
        /** Texture unit of the map (0 = block atlas, 1 = water tile, 2 = far-terrain noise, 3 = coverage mask). */
        const val UNIT = 4

        private const val SLOTS = TILES * TILES
        private const val NONE = Long.MIN_VALUE
        private const val MAX_IN_FLIGHT = 8
        private const val MAX_UPLOADS_PER_FRAME = 6

        private fun key(tx: Int, tz: Int): Long = (tx.toLong() shl 32) or (tz.toLong() and 0xFFFFFFFFL)
    }
}
