package com.voxelsandbox.game.world.color

import com.voxelsandbox.game.world.WorldConfig
import com.voxelsandbox.game.world.generation.Climate
import com.voxelsandbox.game.world.generation.TerrainShape

/**
 * The colour of grass, as a smooth pure function of position: what the ground cover of every place would
 * look like, whatever blocks happen to stand there. The voxel terrain tints its grass, leaves and plants
 * with it (see gl/BiomeColorMap) and the distant terrain colours its grass quads with it, so a meadow is the
 * same green near and far, and the colour of the ground never jumps where one biome's rule gives way to the
 * next.
 *
 * Where the blocks change at a hard line (grass here, dry grass there, swamp grass over there), the colour
 * does not: it is a blend of four climate colours (temperate, cold, dry, swamp; see [BiomePalette]) whose
 * weights come from the *soft* versions of the biome table's own rules ([Climate.dryness],
 * [Climate.coldness], [Climate.swampiness]). Those weights are built from the very same climate fields,
 * wobble and height-dependent temperature the table uses, so the soft borders lie on the hard ones: the
 * block on either side of a border has the colour half-way between the two climates, and the colour moves
 * to either side of it over some hundred blocks. Because the weights are smooth functions of (x, z) and the
 * height of the ground there, and nothing about chunks or meshes enters, the result is the same wherever and
 * whenever it is asked for: across chunk borders, after a chunk is reloaded, from the voxel side and from
 * the distant side.
 *
 * The field says nothing about *which surface* a place has: only things that are grass in the first place
 * are painted with it (the texture tables decide that, see gl/TintTable), so sand, stone, snow and gravel
 * keep their own colour wherever the field says "green".
 *
 * Thread-safe: it only reads the (immutable) noise tables of the [Climate] and [TerrainShape].
 */
class BiomeColorField(
    private val climate: Climate,
    private val shape: TerrainShape,
    val palette: BiomePalette
) {
    /**
     * The grass colour (0xRRGGBB) at ([wx], [wz]) for ground at height [ground] (the surface height there),
     * given what the caller already knows: the base elevation [coast] there ([TerrainShape.coastElevation]),
     * the sea-level temperature [t0] and the humidity [hum].
     */
    fun grass(wx: Double, wz: Double, ground: Double, coast: Double, t0: Double, hum: Double): Int {
        val alt = ground - SEA
        val te = climate.groundTemperature(t0, climate.temperatureJitter(wx, wz), ground)
        val hu = hum + climate.humidityJitter(wx, wz)

        val cold = climate.coldness(te).toFloat()
        val dry = climate.dryness(te, hu).toFloat()
        val swamp = climate.swampiness(climate.swampWeight(wx, wz, coast, hum, t0), alt).toFloat()

        // Plain grass, cooled by the cold, dried out by the dryness, soaked by the swamp, in that order: a
        // swamp stays a swamp however cold or dry the rest says it is, and the dry and the cold (which
        // never meet in the table) cannot fight.
        var r = palette.grassR
        var g = palette.grassG
        var b = palette.grassB
        r += (palette.coldR - r) * cold; g += (palette.coldG - g) * cold; b += (palette.coldB - b) * cold
        r += (palette.dryR - r) * dry; g += (palette.dryG - g) * dry; b += (palette.dryB - b) * dry
        r += (palette.swampR - r) * swamp; g += (palette.swampG - g) * swamp; b += (palette.swampB - b) * swamp
        return pack(r, g, b)
    }

    /** [grass] for a caller that has only the position: it works out the ground height, the base elevation
     *  and the two climate samples itself (a few microseconds). [scratch] is any array of at least one
     *  double the caller owns (it is overwritten); passing one keeps a loop over many points free of garbage. */
    fun grassAt(wx: Double, wz: Double, scratch: DoubleArray = DoubleArray(1)): Int {
        val ground = shape.heightAndCoast(wx, wz, 0, scratch, 0)
        return grass(wx, wz, ground, scratch[0], climate.baseTemperature(wx, wz), climate.humidity(wx, wz))
    }

    /** The colour grass has in the middle of plains (what the texture itself looks like): the neutral
     *  colour, for places where nothing is known yet. */
    val neutral: Int get() = pack(palette.grassR, palette.grassG, palette.grassB)

    companion object {
        private val SEA = WorldConfig.SEA_LEVEL.toDouble()

        /** Packs 0..255 channels (rounded, clamped) into 0xRRGGBB. */
        fun pack(r: Float, g: Float, b: Float): Int =
            (channel(r) shl 16) or (channel(g) shl 8) or channel(b)

        private fun channel(v: Float): Int {
            val i = (v + 0.5f).toInt()
            return if (i < 0) 0 else if (i > 255) 255 else i
        }
    }
}
