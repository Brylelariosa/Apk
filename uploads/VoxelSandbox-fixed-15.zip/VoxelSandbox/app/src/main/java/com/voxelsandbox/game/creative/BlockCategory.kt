package com.voxelsandbox.game.creative

import com.voxelsandbox.game.world.BlockType

/**
 * The tabs of the creative inventory. A category only appears in the inventory when at least one real
 * registered block belongs to it (see [CreativeCatalog.categories]); nothing here is a placeholder.
 */
enum class BlockCategory(val label: String) {
    TERRAIN("Terrain"),
    STONE("Stone & Ore"),
    TREES("Trees"),
    PLANTS("Plants"),
    LIQUIDS("Liquids"),

    /** A block that nobody has sorted into one of the tabs above yet; it still shows up under "All". */
    OTHER("Other");

    companion object {
        /**
         * The tab a block belongs to. Every block of the registry is listed explicitly on purpose: a block
         * added later falls into [OTHER] (and a test fails) until somebody decides where it belongs.
         */
        fun of(block: BlockType): BlockCategory = when (block) {
            BlockType.GRASS, BlockType.DRY_GRASS, BlockType.SWAMP_GRASS,
            BlockType.DIRT, BlockType.SAND, BlockType.SANDSTONE,
            BlockType.GRAVEL, BlockType.SNOW -> TERRAIN

            BlockType.STONE, BlockType.DEEP_STONE, BlockType.COAL_ORE -> STONE

            BlockType.WOOD, BlockType.BIRCH_WOOD, BlockType.SPRUCE_WOOD,
            BlockType.LEAVES, BlockType.BIRCH_LEAVES, BlockType.SPRUCE_LEAVES -> TREES

            BlockType.TALL_GRASS, BlockType.POPPY, BlockType.DANDELION, BlockType.DEAD_BUSH,
            BlockType.CACTUS, BlockType.LILY_PAD, BlockType.SEAGRASS -> PLANTS

            BlockType.WATER -> LIQUIDS

            BlockType.AIR -> OTHER
        }
    }
}
