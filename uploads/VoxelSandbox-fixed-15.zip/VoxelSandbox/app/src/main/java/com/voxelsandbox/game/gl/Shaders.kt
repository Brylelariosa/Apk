package com.voxelsandbox.game.gl

/**
 * The GLSL programs of everything that is not voxel-block geometry (that one has its own file, [VoxelShader]:
 * it is the only part that draws with the per-block texture lookup).
 *
 * Camera-relative positions. Vertex data holds world coordinates, but a float32 world coordinate
 * has only so many bits: at x = 20,000 the smallest step is 0.002 of a block, and the sums inside
 * `projection * view * position` (a translation of tens of thousands cancelling against the position)
 * lose even more, so far from the origin walls shimmer and the ground crawls. Every vertex shader
 * therefore subtracts `uCamOrigin`, the whole-block position of the eye (exact in float32), before
 * the matrix, and the matrix is built for an eye that is within one block of the origin. Everything
 * the vertex shader hands on that must stay a *world* position (the distance bands and clips, the
 * world-anchored grain) is still passed on unshifted; the rest are exact and tiny.
 *
 *  - [FAR_VERTEX]/[FAR_FRAGMENT]: the distant-terrain tiles: a circular clip around the
 *    player, a distance band per level of detail, and (close to the voxel area) the same
 *    per-block brightness grain the voxel shader applies, so flat LOD colour does not look
 *    like a different material next to textured blocks.
 *  - [WATER_VERTEX]/[WATER_FRAGMENT]: every water surface (voxel chunks and distant water).
 *    Pixel-art water: one frame of a looping, seamlessly tiling wave animation (see WaterPattern),
 *    read with nearest-texel filtering and pinned to the world, plus the flow direction carried in
 *    the vertices for running water. No lighting model at all: just pattern colours, a few percent
 *    of large-scale tone, a depth tint, shoreline foam and fog.
 *  - [SKY_VERTEX]/[SKY_FRAGMENT]: a full-screen gradient with a sun, drawn first.
 *  - [CLOUD_VERTEX]/[CLOUD_FRAGMENT]: the blocky cloud layer.
 */
object Shaders {
    /** Blocks over which the distant ground's tonal patches grow from nothing (at the edge of the voxel terrain) to
     *  full strength, and that strength (see [FAR_FRAGMENT]). */
    private const val TONE_RAMP = 220.0f
    private const val TONE_STRENGTH = 0.20f

    /**
     * The two things a stand-in draw needs of a fragment shader of the distant terrain (land and water share this text,
     * so they cannot drift apart):
     *  - uClip = (x0, z0, x1, z1): the only ground (world X/Z) the draw may show. A coarser tile that stands in for a
     *    missing one is drawn through the missing tile's footprint and nowhere else; an ordinary draw has the whole
     *    world (+-1e9).
     *  - uDither = (lo, hi): the pixels the draw covers, picked by a fixed screen-space noise in [0, 1) (interleaved
     *    gradient noise, a pure function of the pixel): a pixel is drawn if its noise is in [lo, hi). A tile fading in
     *    is drawn with (0, f) and the stand-in under it with (f, 1), so every pixel belongs to exactly one of the two at
     *    every moment of the fade, there is never a second surface to fight with, and nothing in the geometry moves.
     *    An ordinary draw has (0, 1) and skips the noise.
     * (highp on purpose: the noise multiplies fragment coordinates in the thousands.)
     */
    private const val CLIP_AND_DITHER = """
uniform highp vec4 uClip;
uniform highp vec2 uDither;

bool clippedOut(highp vec2 world) {
    return world.x < uClip.x || world.y < uClip.y || world.x >= uClip.z || world.y >= uClip.w;
}

bool ditheredOut() {
    if (uDither.x <= 0.0 && uDither.y >= 1.0) return false;
    highp float n = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));
    return n < uDither.x || n >= uDither.y;
}
"""

    /** The vertex of a distant land tile (see FarVertex for the layout, which is the contract of this shader):
     *  aColors.x is the colour of the vertex and aColors.y the colour it slides to, each 0xRRGGBB with the brightness
     *  of its face already applied (an integer below 2^24 is exact in a float), constant over a quad; aMorph is the
     *  height it slides to.
     *
     *  uCenter: world X/Z the ring radii are measured from (the player).
     *  uBand: x = inner radius, y = outer radius of this level's ring (used by the fragment
     *  shader), z..w = the distance range over which this level slides to the next coarser level: height and
     *  colour, each from its own value to the value the coarser level has at that very point.
     *
     *  The slide is a pure function of the vertex's distance from the player, so the mesh
     *  itself is static and cached; at w (the ring's outer edge) every vertex has reached its
     *  parent's shape and colour, which is exactly where the coarser level takes over: the ground changes
     *  level without a step in shape or in colour, whichever way the player walks. (An older arrangement
     *  overlapped the levels and sank the coarse one by a distance-dependent amount, which made the ground
     *  heave as the player walked.) A tile that arrives late does not slide into place either: it is faded in
     *  over the coarser tile that stood in for it, by a dither in the fragment shader (see [CLIP_AND_DITHER]),
     *  so no vertex ever moves except along the distance-only slide above. */
    const val FAR_VERTEX = """#version 300 es
layout(location = 0) in vec3 aPosition;
layout(location = 1) in vec2 aColors;
layout(location = 2) in float aMorph;

uniform mat4 uViewProj;
uniform highp vec3 uCamOrigin;
uniform highp vec2 uCenter;
uniform highp vec4 uBand;

out vec3 vColor;
out float vFogDist;
out highp vec3 vWorld;

vec3 unpackColor(float packed) {
    int rgb = int(packed);
    return vec3(float((rgb >> 16) & 255), float((rgb >> 8) & 255), float(rgb & 255)) * (1.0 / 255.0);
}

void main() {
    highp float dist = length(aPosition.xz - uCenter);
    highp float m = smoothstep(uBand.z, uBand.w, dist);
    vec3 p = vec3(aPosition.x, mix(aPosition.y, aMorph, m), aPosition.z);
    gl_Position = uViewProj * vec4(p - uCamOrigin, 1.0);
    vColor = mix(unpackColor(aColors.x), unpackColor(aColors.y), m);
    vFogDist = gl_Position.w;
    vWorld = p;
}
"""

    /** Where the distant ground is drawn:
     *   - uBand.xy = inner / outer radius (from uCenter, the eye) of this level's ring (see FAR_VERTEX),
     *     and uSkip = a ring of it that another level draws instead (x = y = 0: none). All the edges are
     *     cut with the same formula on the same world position, so neighbouring levels partition the
     *     ground exactly;
     *   - uVoxel.x = the radius inside which the voxel terrain stands alone: there the distant ground
     *     is drawn only in the chunk columns that have no terrain yet (uCover: one texel per column,
     *     see CoverageMask), so a chunk that is still loading, or was just unloaded, shows distant
     *     ground instead of a hole, and a loaded one never has a second surface under it. From that
     *     radius out, where the voxel terrain dissolves, the distant ground is always drawn behind it;
     *     uVoxel.y = the radius where the voxel terrain is gone;
     *   - uClip / uDither: see [CLIP_AND_DITHER] (a stand-in for a missing tile, and a tile fading in).
     *
     *  Two kinds of variation are added to the flat palette colours, both functions of the world
     *  position alone (so they stay fixed to the ground and are identical at every level):
     *   - a grain: exactly the per-block brightness variation of the voxel terrain (same range, same
     *     fade, see [BlockGrain]), from a hash of the ground cell (2-D, offset by 0.37 so that vertical
     *     walls, which sit exactly on cell boundaries, are not decided by the last bit of an
     *     interpolated coordinate), so the two layers are equally grainy where they overlap;
     *   - soft tonal patches from a tileable noise texture (uNoise, one repeat = 1024 blocks;
     *     two taps at different scales and axes so the repeat never shows): far columns are flat
     *     palette colours and this is what breaks them up. The voxel terrain has no such patches, so
     *     they are zero at the edge of the voxel terrain and grow to full strength over [TONE_RAMP]
     *     blocks beyond it, measured from the eye (not along the view axis, so turning the camera never
     *     changes them). Before, they started 40 blocks from the eye and the distant ground next to the
     *     voxel terrain was up to 12 % darker or lighter than it, a ring all the way round.
     *  The hash is done on highp integers on purpose: mediump ints are 16 bit on some GPUs. */
    @JvmField
    val FAR_FRAGMENT: String = """#version 300 es
precision mediump float;
precision highp int;

#define GRAIN_NEAR ${BlockGrain.NEAR}
#define GRAIN_FAR ${BlockGrain.FAR}
#define GRAIN_RANGE ${BlockGrain.SOLID_RANGE}
#define TONE_RAMP $TONE_RAMP
#define TONE_STRENGTH $TONE_STRENGTH

in vec3 vColor;
in float vFogDist;
in highp vec3 vWorld;

uniform sampler2D uNoise;
uniform sampler2D uCover;
uniform vec3 uFogColor;
uniform float uFogStart;
uniform float uFogEnd;
uniform highp vec2 uVoxel;
uniform highp vec2 uCenter;
uniform highp vec4 uBand;
uniform highp vec2 uSkip;
$CLIP_AND_DITHER
out vec4 fragColor;

void main() {
    if (clippedOut(vWorld.xz)) discard;
    highp vec2 db = vWorld.xz - uCenter;
    highp float d2 = dot(db, db);
    if (d2 < uBand.x * uBand.x || d2 >= uBand.y * uBand.y) discard;
    if (d2 >= uSkip.x * uSkip.x && d2 < uSkip.y * uSkip.y) discard;
    if (d2 < uVoxel.x * uVoxel.x &&
        texelFetch(uCover, ivec2(floor(vWorld.xz * 0.0625)) & 255, 0).r > 0.5) discard;
    if (ditheredOut()) discard;

    vec3 shaded = vColor;
    if (vFogDist < GRAIN_FAR) {
        highp vec2 q = floor(vWorld.xz + vec2(0.37));
        uvec2 u = uvec2(ivec2(q));
        uint h = (u.x * 73856093u) ^ (u.y * 19349663u);
        h ^= h >> 15u;
        h *= 739982445u;
        h ^= h >> 13u;
        float g = float((h >> 8u) & 255u) * (1.0 / 255.0);
        shaded *= 1.0 - GRAIN_RANGE * g * (1.0 - smoothstep(GRAIN_NEAR, GRAIN_FAR, vFogDist));
    }
    float n1 = texture(uNoise, vWorld.xz * 0.0009765625).r;
    float n2 = texture(uNoise, vWorld.zx * 0.0006105 + vec2(0.37, 0.61)).r;
    float tone = (n1 + n2) - 1.0;
    float k = smoothstep(uVoxel.y, uVoxel.y + TONE_RAMP, sqrt(d2)) * TONE_STRENGTH;
    shaded *= vec3(1.0 + tone * k * 1.15, 1.0 + tone * k, 1.0 + tone * k * 0.8);
    float fogFactor = clamp((vFogDist - uFogStart) / (uFogEnd - uFogStart), 0.0, 1.0);
    fragColor = vec4(mix(shaded, uFogColor, fogFactor), 1.0);
}
"""

    /**
     * Water vertex data (see ChunkMesher): position, then in the "uv" slots (x = depth of the
     * water below the vertex in blocks, or -1 for a side face; y = flow X) and in the shade
     * slot the flow Z. Flow is a vector of length 0..1 pointing the way the water runs.
     * There is no vertex swell: water is flat and animated by its texture only, like
     * the rest of the blocky world.
     */
    const val WATER_VERTEX = """#version 300 es
layout(location = 0) in vec3 aPosition;
layout(location = 1) in vec2 aData;
layout(location = 2) in float aFlowZ;

uniform mat4 uViewProj;
uniform highp vec3 uCamOrigin;

out highp vec3 vWorld;
out highp vec3 vRel;
out float vDepth;
out vec2 vFlow;
out float vFogDist;

void main() {
    vRel = aPosition - uCamOrigin;
    gl_Position = uViewProj * vec4(vRel, 1.0);
    vWorld = aPosition;
    vDepth = aData.x;
    vFlow = vec2(aData.y, aFlowZ);
    vFogDist = gl_Position.w;
}
"""

    /** uBand / uSkip / uCover: same meaning as in FAR_FRAGMENT (the voxel water passes a band that spans
     *  everything). uSide says which of the two water layers is being drawn: +1 = the voxel chunks' water,
     *  -1 = the distant water, 0 = no seam. They meet at uVoxel.y, the radius (from the eye) where the
     *  voxel terrain is fully dissolved, over a seam SEAM_WIDTH (8) blocks wide: the voxel water fades out
     *  across it as the distant water fades in, in the proportions that keep the combined opacity what a
     *  single layer would have (so there is no lighter ring), and where a column has no voxel terrain the
     *  distant water is drawn whole.
     *
     *  The pattern: uWaterTex is one frame of WaterPattern's animation per layer (a seamless tile
     *  [WaterPattern.PERIOD_BLOCKS] blocks wide, pixel art at 16 pixels to the block, read with nearest-texel
     *  magnification and mip-mapped in the distance); the layer is picked on the CPU (uWaterLayer), so the waves
     *  move by changing frame, not by scrolling, and a still pond stays exactly where it is however long you
     *  look at it. uWaterPhase is the camera's whole-block origin modulo the tile: with it the pattern is
     *  pinned to the world, so it cannot slide when the camera moves (see WaterAnimation). Running water carries
     *  the pattern along its flow on top of that, a waterfall pulls it down its face (the tile's ripples run
     *  along one axis, so on a wall they become streaks that run down it).
     *
     *  uWaterTone is a very soft, tiling patch field, read in world coordinates and drifting a few
     *  blocks a minute: a few percent of brightness and hue (wind patches on the sea) that keep a calm sea from
     *  being one flat colour and hide that the tile repeats. The alpha of the tile marks its ripple crests; where
     *  the water is shallow (the first block off a shore) they turn pale: foam that follows the waves.
     *  Nothing here knows about biomes: water is the same colour everywhere, so it cannot change at a biome
     *  border, and it never touches the sand or land beside it (only its own opacity lets them show through).
     *
     *  Two texture fetches per pixel, no per-pixel trigonometry: water covers a large part of the screen
     *  over an ocean, and it is the one translucent layer, so it has to be cheap on weak GPUs.
     *
     *  The pattern is the same at every distance: the tile's own mip chain averages it away where it gets
     *  smaller than a pixel, and between 90 and 240 blocks it is faded to uWaterAvg (the mean colour of all the
     *  tile's frames) so that what the mip chain cannot calm down at grazing angles does not shimmer. */
    const val WATER_FRAGMENT = """#version 300 es
precision mediump float;

#define SEAM_WIDTH 8.0
#define TILE_BLOCKS ${WaterPattern.PERIOD_BLOCKS}.0
#define TONE_BLOCKS ${WaterPattern.TONE_PERIOD_BLOCKS}.0
#define FLOW_SPEED ${WaterAnimation.FLOW_SPEED}

in highp vec3 vWorld;
in highp vec3 vRel;
in float vDepth;
in vec2 vFlow;
in float vFogDist;

uniform mediump sampler2DArray uWaterTex;
uniform sampler2D uWaterTone;
uniform sampler2D uCover;
uniform highp float uTime;
uniform highp float uWaterLayer;
uniform highp vec3 uWaterPhase;
uniform highp vec2 uTonePhase;
uniform vec3 uWaterAvg;
uniform highp vec3 uEyeRel;
uniform vec3 uFogColor;
uniform float uFogStart;
uniform float uFogEnd;
uniform highp vec2 uVoxel;
uniform highp float uSide;
uniform highp vec2 uCenter;
uniform highp vec4 uBand;
uniform highp vec2 uSkip;
$CLIP_AND_DITHER
out vec4 fragColor;

void main() {
    if (clippedOut(vWorld.xz)) discard;
    highp vec2 db = vWorld.xz - uCenter;
    highp float d2 = dot(db, db);
    if (d2 < uBand.x * uBand.x || d2 >= uBand.y * uBand.y) discard;
    if (d2 >= uSkip.x * uSkip.x && d2 < uSkip.y * uSkip.y) discard;
    if (ditheredOut()) discard;
    // The seam between the voxel water and the distant water: 0 inside, 1 beyond.
    highp float seam = clamp((sqrt(d2) - (uVoxel.y - SEAM_WIDTH)) * (1.0 / SEAM_WIDTH), 0.0, 1.0);
    bool columnLoaded = false;
    if (uSide < 0.0 && seam < 1.0) {
        columnLoaded = texelFetch(uCover, ivec2(floor(vWorld.xz * 0.0625)) & 255, 0).r > 0.5;
        if (columnLoaded && seam <= 0.0) discard;
    }

    // Where the pixel is on the wave tile, in blocks: world X/Z for a top; for a side face (depth marker -1)
    // (down the face, along it), so the ripples that run along X on a top become streaks that run down a
    // waterfall. The camera origin is a whole number of blocks and uWaterPhase is that origin modulo the
    // tile, so this is the world position modulo the tile, with all the precision of camera-relative maths.
    float side = step(vDepth, -0.5);
    highp vec2 at = mix(vRel.xz + uWaterPhase.xz,
                        vec2(vRel.y + uWaterPhase.y, vRel.x + vRel.z + uWaterPhase.x + uWaterPhase.z), side);
    // Running water carries the pattern along its flow, a waterfall pulls it down; still water does not
    // move at all, its waves come from the change of frame. (Full-speed flow carries the pattern a whole
    // number of tiles in the time the clock wraps in, so it does not jump when uTime wraps.)
    highp vec2 vel = mix(vFlow * FLOW_SPEED, vec2(-FLOW_SPEED, 0.0), side);
    at -= vel * uTime;
    vec4 wave = texture(uWaterTex, vec3(at * (1.0 / TILE_BLOCKS), uWaterLayer));

    // Far away only the tile's mean colour is left.
    float near = 1.0 - smoothstep(90.0, 240.0, vFogDist);
    vec3 col = mix(uWaterAvg, wave.rgb, near);

    // Foam where the water is shallow: the crests of the pattern turn pale in the first block off a shore.
    float shore = (1.0 - smoothstep(0.1, 0.9, vDepth)) * (1.0 - side);
    col = mix(col, vec3(0.80, 0.90, 1.0), shore * wave.a * near * 0.55);

    // Soft large patches: a few percent brighter or darker, a little greener or bluer.
    float tone = texture(uWaterTone, (vRel.xz + uTonePhase) * (1.0 / TONE_BLOCKS)).r - 0.5;
    col *= vec3(1.0 + tone * 0.06, 1.0 + tone * 0.09, 1.0 + tone * 0.04);

    // Depth tint: bright azure in the shallows, deep blue over deep water (saturates at 8
    // blocks, which is what lets the mesher merge flat deep water into big quads).
    float depthK = sqrt(clamp(max(vDepth, 0.0) / 8.0, 0.0, 1.0));
    col *= mix(vec3(1.10, 1.12, 1.0), vec3(0.62, 0.76, 0.94), depthK);
    col = mix(col, vec3(0.88, 0.95, 1.0), side * 0.12);

    // At grazing angles the surface mirrors the sky: tint towards the horizon colour and get
    // more opaque. Cheap (no pow) and it also calms the far ocean.
    highp vec3 toEye = uEyeRel - vRel;
    float cosT = abs(toEye.y) * inversesqrt(dot(toEye, toEye) + 0.0001);
    float f = 1.0 - cosT;
    f *= f;
    float fres = f * f * (1.0 - side);
    col = mix(col, uFogColor, fres * 0.45);

    // Opacity follows the length of the light path through the water: straight down over a
    // shallow shore you still see the sand, but a slanted view through even two or three
    // blocks of water is nearly opaque (so seabed steps never show as dark lines). Beyond
    // 300 blocks the sea is completely solid: whatever lies under it there is not drawn (or is
    // not meant to be seen), and a surface that is only 97 % opaque lets 3 % of every seam,
    // crack and stray triangle behind it through, which over a whole ocean is visible.
    float path = max(vDepth, 0.0) / max(cosT, 0.25);
    float alpha = 0.97 - 0.39 * exp(-0.55 * path);
    alpha = mix(alpha, 1.0, smoothstep(60.0, 300.0, vFogDist));
    alpha = mix(alpha, 0.80, side);
    alpha = clamp(alpha + fres * 0.15, 0.0, 1.0);
    if (uSide > 0.0) {
        alpha *= 1.0 - seam;
        if (alpha < 0.004) discard;
    } else if (columnLoaded) {
        // Fades in as the voxel layer above it (same surface) fades out, keeping the sum.
        alpha = 1.0 - (1.0 - alpha) / (1.0 - alpha * (1.0 - seam));
    }

    float fogFactor = clamp((vFogDist - uFogStart) / (uFogEnd - uFogStart), 0.0, 1.0);
    fragColor = vec4(mix(col, uFogColor, fogFactor), alpha);
}
"""

    /** The cloud mesh (see CloudRenderer): one tile of blocky clouds, drawn 3 x 3 times with
     *  instancing. aPos is tile-local; uOrigin is the X/Z of the first instance's tile and uBaseY the
     *  height of the cloud base, both relative to the camera origin (see the note at the top), so
     *  everything here, including uEye in the fragment shader, is camera-relative. */
    const val CLOUD_VERTEX = """#version 300 es
layout(location = 0) in vec3 aPos;
layout(location = 1) in float aShade;

uniform mat4 uViewProj;
uniform highp vec2 uOrigin;
uniform highp float uTile;
uniform highp float uBaseY;

out highp vec3 vWorld;
out float vShade;

void main() {
    float fx = float(gl_InstanceID % 3);
    float fz = float(gl_InstanceID / 3);
    highp vec3 p = vec3(uOrigin.x + fx * uTile + aPos.x, uBaseY + aPos.y, uOrigin.y + fz * uTile + aPos.z);
    vWorld = p;
    vShade = aShade;
    gl_Position = uViewProj * vec4(p, 1.0);
}
"""

    /** Clouds: baked per-vertex shade turned into a white-to-blue-grey colour, then dissolved
     *  into the sky gradient with distance (so no alpha blending and no visible far edge).
     *  uBand restricts which 3D distances from the eye are drawn: the far pass draws the far
     *  part of the sky, the voxel pass the near part (the two use different depth ranges). */
    const val CLOUD_FRAGMENT = """#version 300 es
precision highp float;

in highp vec3 vWorld;
in float vShade;

uniform highp vec3 uEye;
uniform highp float uRadius;
uniform highp vec2 uBand;
uniform vec3 uHorizon;
uniform vec3 uZenith;

out vec4 fragColor;

void main() {
    vec3 d = vWorld - uEye;
    float dist = length(d);
    if (dist < uBand.x || dist >= uBand.y || dist >= uRadius) discard;

    // Lit white on top and towards the sun, a cool blue-grey underneath and away from it.
    vec3 col = mix(vec3(0.50, 0.58, 0.74), vec3(1.0), clamp(vShade, 0.0, 1.0));

    // Distant clouds dissolve into the sky itself (the same gradient the sky pass draws), so
    // the edge of the cloud field is invisible without any alpha blending.
    float h = clamp(d.y / max(dist, 0.001), 0.0, 1.0);
    vec3 sky = mix(uHorizon, uZenith, sqrt(h));
    col = mix(col, sky, smoothstep(0.42 * uRadius, uRadius, dist));
    fragColor = vec4(col, 1.0);
}
"""

    /** One oversized triangle covering the screen; no vertex buffer needed. */
    const val SKY_VERTEX = """#version 300 es
out vec2 vNdc;

void main() {
    vec2 corner = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));
    vNdc = corner * 2.0 - 1.0;
    gl_Position = vec4(vNdc, 1.0, 1.0);
}
"""

    /** uForward/uRight/uUp: the camera basis; uTan.x = tan(fovY / 2) * aspect, uTan.y = tan(fovY / 2).
     *  The sun terms only matter near the sun, so every other pixel skips their pow() calls
     *  (at 0.6 the skipped part of the glow is below 0.001, so there is no visible edge). */
    const val SKY_FRAGMENT = """#version 300 es
precision highp float;

in vec2 vNdc;

uniform vec3 uForward;
uniform vec3 uRight;
uniform vec3 uUp;
uniform vec2 uTan;
uniform vec3 uHorizon;
uniform vec3 uZenith;
uniform vec3 uSunDir;

out vec4 fragColor;

void main() {
    vec3 dir = normalize(uForward + uRight * (vNdc.x * uTan.x) + uUp * (vNdc.y * uTan.y));
    float h = clamp(dir.y, 0.0, 1.0);
    vec3 col = mix(uHorizon, uZenith, sqrt(h));
    float sd = dot(dir, uSunDir);
    if (sd > 0.6) {
        col += vec3(1.0, 0.90, 0.68) * (pow(sd, 1500.0) * 2.0 + pow(sd, 10.0) * 0.14);
    }
    fragColor = vec4(col, 1.0);
}
"""
}
