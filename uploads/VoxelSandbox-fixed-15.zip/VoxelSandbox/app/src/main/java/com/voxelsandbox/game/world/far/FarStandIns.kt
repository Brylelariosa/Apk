package com.voxelsandbox.game.world.far

import kotlin.math.floor
import kotlin.math.min

/**
 * What takes the place of a distant tile that is not there (yet).
 *
 * The rings of the distant terrain are cut on exact distances, so a tile that has not been built when the player
 * reaches its ring (a fast flight, a teleport, a tile that was just evicted) leaves a hole in the picture, and the
 * only thing the old code could do about it was to pull the fog in. But the footprints of the tiles are aligned
 * (every tile edge is a multiple of the one before), so the area of a missing tile always lies inside exactly one
 * tile of every coarser level, and when such a tile is on the GPU its ground is simply the same ground in bigger
 * bricks. Drawn in the hole, clipped to the missing tile's footprint and ring, it is a stand-in: the picture is
 * complete (and, at the outer edge of the hole, identical to the ring beyond it, because that is the shape the
 * missing level slides to). When the real tile arrives it takes over by a dither fade (see FarTerrainRenderer).
 *
 * Everything here is pure arithmetic on tile keys, so the renderer (which asks "what stands in for this?") and the
 * planner (which asks "is this hole filled already?", and so must not pull the fog in) always give the same answer.
 */
internal object FarStandIns {
    /** "No tile": no key of a real tile is all ones (the level occupies the top three bits and is at most 7). */
    const val NONE = -1L

    /**
     * Key of the tile of [level] whose footprint contains the footprint of tile [key]; [key] itself if [level] is
     * not coarser than the tile's own. Tile edges are powers of two times a common base, so the containing tile is
     * found by integer division of the tile's corner.
     */
    @JvmStatic
    fun ancestor(key: Long, level: Int): Long {
        val own = FarTerrain.levelOf(key)
        if (level <= own) return key
        val size = FarLevels.tileBlocks(own).toLong()
        val big = FarLevels.tileBlocks(level).toLong()
        val tx = Math.floorDiv(FarTerrain.tileX(key) * size, big).toInt()
        val tz = Math.floorDiv(FarTerrain.tileZ(key) * size, big).toInt()
        return FarTerrain.tileKey(level, tx, tz)
    }

    /**
     * The key of the finest tile coarser than [key] whose footprint contains it and that [resident] says is there,
     * or [NONE] (always for the coarsest level, which has nothing above it). The finest one is the best stand-in: it
     * is the ground the missing level would have slid to.
     */
    inline fun find(key: Long, resident: (Long) -> Boolean): Long {
        for (level in FarTerrain.levelOf(key) + 1 until FarLevels.COUNT) {
            val a = ancestor(key, level)
            if (resident(a)) return a
        }
        return NONE
    }

    /**
     * Calls [action] with the key of every tile of [level] that has ground in the ring [inner]..[outer) around
     * ([eyeX], [eyeZ]) within [reach] blocks of the eye (the ring is cut off there: the fog's end, or the render
     * distance). A tile is listed if its footprint touches that part of the ring, whether or not it is built; the
     * caller tests what else it needs (the view frustum, the circle the voxel terrain covers).
     */
    inline fun forEachRingTile(
        level: Int,
        eyeX: Float,
        eyeZ: Float,
        inner: Float,
        outer: Float,
        reach: Float,
        action: (Long) -> Unit
    ) {
        val limit = min(outer, reach)
        if (limit <= inner) return
        val size = FarLevels.tileBlocks(level)
        val sizeF = size.toFloat()
        val minTx = Math.floorDiv(floor(eyeX - limit).toInt(), size)
        val maxTx = Math.floorDiv(floor(eyeX + limit).toInt(), size)
        val minTz = Math.floorDiv(floor(eyeZ - limit).toInt(), size)
        val maxTz = Math.floorDiv(floor(eyeZ + limit).toInt(), size)
        for (tz in minTz..maxTz) {
            for (tx in minTx..maxTx) {
                val x0 = (tx * size).toFloat()
                val z0 = (tz * size).toFloat()
                if (FarTileMath.nearest(x0, z0, sizeF, eyeX, eyeZ) >= limit) continue
                if (FarTileMath.farthest(x0, z0, sizeF, eyeX, eyeZ) < inner) continue
                action(FarTerrain.tileKey(level, tx, tz))
            }
        }
    }
}
