package com.voxelsandbox.game.world.color

/**
 * The colour field cut into square tiles of 16 x 16 samples, the unit the GPU's colour map is filled in (see
 * gl/BiomeColorMap). A sample stands for a cell of [spacing] x [spacing] blocks and holds the field at the
 * cell's centre; tile (tx, tz) covers the cells (16 tx .. 16 tx + 15, 16 tz .. 16 tz + 15). A pure function
 * of the tile's place and the world: any thread, any time, same numbers, so the colour of a place never
 * depends on which tiles were computed before it, in what order, or when.
 */
object BiomeColorTiles {
    const val TILE = 16

    /** Fills [out] (TILE x TILE ints, row-major, z rows) with the 0xRRGGBB grass colour of tile ([tx], [tz]). */
    fun compute(field: BiomeColorField, tx: Int, tz: Int, spacing: Int, out: IntArray, scratch: DoubleArray) {
        for (j in 0 until TILE) {
            val wz = ((tz * TILE + j) + 0.5) * spacing
            for (i in 0 until TILE) {
                val wx = ((tx * TILE + i) + 0.5) * spacing
                out[j * TILE + i] = field.grassAt(wx, wz, scratch)
            }
        }
    }
}
