package com.voxelsandbox.game.creative

import com.voxelsandbox.game.gl.TileSources
import com.voxelsandbox.game.world.BlockType
import java.util.Locale

/** One line of the creative inventory: a real registered block, its name, its tab and the words it is found by. */
class CatalogEntry(
    val block: BlockType,
    val name: String,
    val category: BlockCategory,
    /** The lower-case words of the name. */
    val nameWords: List<String>,
    /** Other lower-case words it is found by: the tab name and a few synonyms. */
    val extraWords: List<String>
)

/**
 * The creative inventory's catalogue, generated from the block registry ([BlockType]): every registered
 * block except air, once, in tab order and then registry order. There is no list of items to keep in step
 * by hand, so a block added to the registry shows up here by itself (in the "Other" tab until it is sorted).
 *
 * The game has no items apart from blocks (breaking a block never produced anything but the block), so the
 * catalogue is exactly the set of blocks. Pure Kotlin, no Android classes.
 */
object CreativeCatalog {
    /** Everything that can be picked, in display order. */
    val entries: List<CatalogEntry> by lazy {
        BlockType.values()
            .filter { it != BlockType.AIR }
            .map { block ->
                val category = BlockCategory.of(block)
                CatalogEntry(block, block.displayName, category, tokenize(block.displayName), extraWordsOf(block, category))
            }
            .sortedWith(compareBy<CatalogEntry> { it.category.ordinal }.thenBy { it.block.id.toInt() })
    }

    /** The tabs that have at least one block, in tab order. */
    val categories: List<BlockCategory> by lazy {
        BlockCategory.values().filter { c -> entries.any { it.category == c } }
    }

    private val byBlock: Map<BlockType, CatalogEntry> by lazy { entries.associateBy { it.block } }

    fun entryFor(block: BlockType): CatalogEntry? = byBlock[block]

    /**
     * The entries of [category] (all of them when null) that match [query]. Every word typed has to match
     * the start of one of the entry's words (a word typed with two or more letters may also match inside
     * one), so "lea" finds all the leaves and "birch tree" finds birch wood and birch leaves. Best matches
     * first: a word of the block's name beats a synonym or tab word, and within each a whole word beats the
     * start of a word beats the inside of one ("water" lists Water before the plants that live in it); equal
     * matches keep catalogue order.
     */
    fun search(query: String, category: BlockCategory? = null): List<CatalogEntry> {
        val tokens = tokenize(query)
        val pool = if (category == null) entries else entries.filter { it.category == category }
        if (tokens.isEmpty()) return pool
        val scored = ArrayList<Pair<Int, CatalogEntry>>()
        for (entry in pool) {
            var total = 0
            var matchedAll = true
            for (token in tokens) {
                val s = scoreToken(entry, token)
                if (s == 0) {
                    matchedAll = false
                    break
                }
                total += s
            }
            if (matchedAll) scored.add(total to entry)
        }
        // sortedByDescending is stable, so equal scores keep the catalogue order.
        return scored.sortedByDescending { it.first }.map { it.second }
    }

    /**
     * Problems that would make an entry unusable: no tile to draw it from, a duplicate block or name, a
     * block that cannot be told apart in the registry. Empty when the catalogue is sound. Used by the unit
     * tests and logged by the diagnostics; the result is the list of "unsupported entries" of the report.
     */
    fun problems(): List<String> {
        val out = ArrayList<String>()
        val seenBlocks = HashSet<BlockType>()
        val seenNames = HashSet<String>()
        for (e in entries) {
            if (!seenBlocks.add(e.block)) out.add("${e.block} appears twice")
            if (!seenNames.add(e.name.lowercase(Locale.ROOT))) out.add("name '${e.name}' is used by two blocks")
            if (e.name.isBlank()) out.add("${e.block} has no name")
            if (e.category == BlockCategory.OTHER) out.add("${e.block} is not sorted into a tab")
            if (BlockIcons.render(e.block) { TileSources.pixelsFor(it) } == null) out.add("${e.block} has no icon (missing tile)")
        }
        for (b in BlockType.values()) {
            if (b != BlockType.AIR && b !in byBlock) out.add("$b is registered but not in the catalogue")
        }
        return out
    }

    // ---- search internals --------------------------------------------------------------------

    private fun tokenize(text: String): List<String> =
        text.lowercase(Locale.ROOT).split(' ', '\t', ',', ';', '-', '_').filter { it.isNotEmpty() }

    private fun scoreToken(entry: CatalogEntry, token: String): Int {
        val inName = bestWordScore(entry.nameWords, token)
        if (inName > 0) return inName + NAME_BONUS
        return bestWordScore(entry.extraWords, token)
    }

    /** 3 = a word equals [token], 2 = a word starts with it, 1 = a word contains it (two letters or more), else 0. */
    private fun bestWordScore(words: List<String>, token: String): Int {
        var best = 0
        for (w in words) {
            val s = when {
                w == token -> 3
                w.startsWith(token) -> 2
                token.length >= 2 && w.contains(token) -> 1
                else -> 0
            }
            if (s > best) best = s
        }
        return best
    }

    private fun extraWordsOf(block: BlockType, category: BlockCategory): List<String> {
        val words = LinkedHashSet<String>()
        words.addAll(tokenize(category.label.replace("&", " ")))
        SYNONYMS[block]?.let { words.addAll(tokenize(it)) }
        words.removeAll(tokenize(block.displayName).toSet())
        return words.toList()
    }

    private const val NAME_BONUS = 3

    /** Extra words a block is found by (what players call it), beyond its own name and tab. */
    private val SYNONYMS: Map<BlockType, String> = mapOf(
        BlockType.GRASS to "turf lawn meadow",
        BlockType.DRY_GRASS to "dead savanna",
        BlockType.SWAMP_GRASS to "marsh bog",
        BlockType.DIRT to "soil earth mud",
        BlockType.SAND to "beach desert",
        BlockType.SANDSTONE to "desert rock",
        BlockType.GRAVEL to "pebbles",
        BlockType.SNOW to "white winter cold",
        BlockType.STONE to "rock",
        BlockType.DEEP_STONE to "rock cave dark",
        BlockType.COAL_ORE to "coal mineral mine",
        BlockType.WOOD to "log trunk tree oak",
        BlockType.BIRCH_WOOD to "log trunk tree",
        BlockType.SPRUCE_WOOD to "log trunk tree pine conifer",
        BlockType.LEAVES to "leaf foliage tree oak",
        BlockType.BIRCH_LEAVES to "leaf foliage tree",
        BlockType.SPRUCE_LEAVES to "leaf foliage tree pine needles conifer",
        BlockType.TALL_GRASS to "grass tuft weed",
        BlockType.POPPY to "flower red",
        BlockType.DANDELION to "flower yellow",
        BlockType.DEAD_BUSH to "bush shrub dry desert",
        BlockType.CACTUS to "desert prickly",
        BlockType.LILY_PAD to "lily pad swamp pond water",
        BlockType.SEAGRASS to "sea grass kelp ocean underwater water",
        BlockType.WATER to "liquid fluid ocean lake sea river"
    )
}
