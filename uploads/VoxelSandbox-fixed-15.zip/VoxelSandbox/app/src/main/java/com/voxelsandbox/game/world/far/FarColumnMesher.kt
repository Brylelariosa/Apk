package com.voxelsandbox.game.world.far

import com.voxelsandbox.game.gl.TextureAtlas
import com.voxelsandbox.game.world.WorldConfig
import com.voxelsandbox.game.world.far.FarLevels.SOIL_DEPTH
import com.voxelsandbox.game.world.far.FarLevels.TREE_LEVELS
import com.voxelsandbox.game.world.far.FarLevels.WATER_Y
import com.voxelsandbox.game.world.far.FarLevels.cellsOf
import com.voxelsandbox.game.world.far.FarLevels.landFloor
import com.voxelsandbox.game.world.far.FarLevels.step
import com.voxelsandbox.game.world.far.FarLevels.tileBlocks
import com.voxelsandbox.game.world.generation.TerrainGenerator
import com.voxelsandbox.game.world.generation.TreeSpecies
import com.voxelsandbox.game.world.mesh.FaceShade
import com.voxelsandbox.game.world.mesh.MeshData
import kotlin.math.max
import kotlin.math.min

/**
 * The land of the distant terrain as blocky, voxel-style columns at every level, the way the voxel world itself
 * looks: flat-coloured tops, vertical walls wherever a neighbour is lower, and (on the two finest levels) real
 * little trees. A level's columns are twice as wide as the previous level's, and its ring of the picture is twice as
 * far out, so the bricks stay a few pixels across wherever they are looked at.
 *
 * Everything about a column level lives in three small pieces: the ground of every column of a tile ([buildField],
 * see [FarColumnSampler]), the height and colours each column slides to as its ring ends ([slideOf], see
 * [ColumnSlide]), and the mesh ([buildLandMesh]): tops merged into the largest flat rectangles that share their
 * height and colour, and walls merged along the edge they stand on.
 */
internal class FarColumnMesher(
    private val generator: TerrainGenerator,
    private val styler: FarStyler
) {
    private val sampler = FarColumnSampler(generator, styler)

    /** The ground of the window of [cells] x [cells] columns of [level] whose first column is the global column
     *  ([gx0], [gz0]), plus a ring of one column around it. */
    fun buildField(level: Int, gx0: Int, gz0: Int, cells: Int, colors: Boolean = true): CellField =
        sampler.build(level, gx0, gz0, cells, colors)

    /** What the columns of tile ([tx], [tz]) of [level], whose ground is [field], slide to at the end of their ring:
     *  the columns of the next coarser level over them, computed by the very code that builds that level. */
    fun slideOf(level: Int, tx: Int, tz: Int, field: CellField): ColumnSlide {
        val parent = if (FarLevels.hasParent(level)) {
            val half = field.cells / 2
            sampler.build(level + 1, tx * half, tz * half, half)
        } else null
        return ColumnSlide(field, parent, landFloor(level))
    }

    /** The land mesh of one tile of [level], whose lower corner is ([x0], [z0]). */
    fun buildLandMesh(level: Int, tx: Int, tz: Int, x0: Int, z0: Int, field: CellField): MeshData =
        buildLandMesh(level, x0, z0, field, slideOf(level, tx, tz, field))

    fun buildLandMesh(level: Int, x0: Int, z0: Int, field: CellField, slide: ColumnSlide): MeshData =
        ColumnMeshJob(level, x0, z0, field, slide).run()

    /** The meshing of one tile. */
    private inner class ColumnMeshJob(
        private val level: Int,
        private val x0: Int,
        private val z0: Int,
        private val field: CellField,
        private val slide: ColumnSlide
    ) {
        private val step = step(level)
        private val cells = cellsOf(level)
        private val n = cells + 2
        private val floorY = landFloor(level)
        private val topY = field.topY
        private val col = field.col
        private val wallCol = field.wallCol
        private val skip = field.skip
        private val slideY = slide.y
        private val b = LandMeshBuilder(cells * cells)

        fun run(): MeshData {
            tops()
            walls(alongX = true)
            walls(alongX = false)
            if (level < TREE_LEVELS) trees()
            return b.build()
        }

        private fun vertex(lx: Int, lz: Int, y: Float, rgb: Int, slideRgb: Int, slideY: Float): Int =
            b.vertex((x0 + lx * step).toFloat(), y, (z0 + lz * step).toFloat(), rgb, slideRgb, slideY)

        // ---- tops -----------------------------------------------------------------------------

        /**
         * Tops. A column whose top has one colour all over (every flat-coloured top, and a grass top between the
         * borders of climates, where the biome colour is constant) and slides to one colour all over is merged with
         * its neighbours that have the very same height, colour and slide target into the largest rectangle that
         * fits: flat country, which is most of the ground, costs very little. Any other top (a grass top with a
         * colour at each corner, see [FarGroundColor.corner]) is a quad of its own.
         */
        private fun tops() {
            val area = cells * cells
            val ownUni = IntArray(area)
            val slideUni = IntArray(area)
            for (j in 0 until cells) {
                for (i in 0 until cells) {
                    val ij = j * cells + i
                    val c = (j + 1) * n + (i + 1)
                    if (skip[c]) {
                        ownUni[ij] = NOT_DRAWN
                        continue
                    }
                    ownUni[ij] = uniform(field.cornerRgb(i, j, 0, 0), field.cornerRgb(i, j, 0, 1), field.cornerRgb(i, j, 1, 1), field.cornerRgb(i, j, 1, 0))
                    slideUni[ij] = uniform(slide.topRgb(i, j, 0, 0), slide.topRgb(i, j, 0, 1), slide.topRgb(i, j, 1, 1), slide.topRgb(i, j, 1, 0))
                }
            }

            val used = BooleanArray(area)
            for (j in 0 until cells) {
                for (i in 0 until cells) {
                    val ij = j * cells + i
                    if (used[ij] || ownUni[ij] == NOT_DRAWN) continue
                    val c = (j + 1) * n + (i + 1)
                    used[ij] = true
                    if (ownUni[ij] < 0 || slideUni[ij] < 0) {
                        topQuad(
                            i, i + 1, j, j + 1, topY[c], slideY[c],
                            field.cornerRgb(i, j, 0, 0), field.cornerRgb(i, j, 0, 1), field.cornerRgb(i, j, 1, 1), field.cornerRgb(i, j, 1, 0),
                            slide.topRgb(i, j, 0, 0), slide.topRgb(i, j, 0, 1), slide.topRgb(i, j, 1, 1), slide.topRgb(i, j, 1, 0)
                        )
                        continue
                    }
                    var w = 1
                    while (i + w < cells && mergeable(ij, j * cells + i + w, c, c + w, ownUni, slideUni, used)) w++
                    var h = 1
                    rows@ while (j + h < cells) {
                        for (k in 0 until w) {
                            val ij2 = (j + h) * cells + i + k
                            if (!mergeable(ij, ij2, c, (j + h + 1) * n + (i + k + 1), ownUni, slideUni, used)) break@rows
                        }
                        h++
                    }
                    for (dj in 0 until h) for (di in 0 until w) used[(j + dj) * cells + i + di] = true
                    val own = ownUni[ij]
                    val to = slideUni[ij]
                    topQuad(i, i + w, j, j + h, topY[c], slideY[c], own, own, own, own, to, to, to, to)
                }
            }
        }

        /** True if the top of column [c2] can join the rectangle that starts at column [c0]: not taken yet, drawn,
         *  and the same height, colour, slide height and slide colour. */
        private fun mergeable(ij0: Int, ij2: Int, c0: Int, c2: Int, ownUni: IntArray, slideUni: IntArray, used: BooleanArray): Boolean =
            !used[ij2] && ownUni[ij2] == ownUni[ij0] && slideUni[ij2] == slideUni[ij0] &&
                topY[c2] == topY[c0] && slideY[c2] == slideY[c0]

        /** One flat top over lattice columns [i0] .. [i1] and rows [j0] .. [j1], its corners (in the order of the
         *  quad's vertices) coloured [k0] .. [k3], and sliding to the colours [s0] .. [s3]. */
        private fun topQuad(
            i0: Int, i1: Int, j0: Int, j1: Int, y: Float, sy: Float,
            k0: Int, k1: Int, k2: Int, k3: Int, s0: Int, s1: Int, s2: Int, s3: Int
        ) {
            val v0 = vertex(i0, j0, y, FarVertex.shaded(k0, SHADE_TOP), FarVertex.shaded(s0, SHADE_TOP), sy)
            val v1 = vertex(i0, j1, y, FarVertex.shaded(k1, SHADE_TOP), FarVertex.shaded(s1, SHADE_TOP), sy)
            val v2 = vertex(i1, j1, y, FarVertex.shaded(k2, SHADE_TOP), FarVertex.shaded(s2, SHADE_TOP), sy)
            val v3 = vertex(i1, j0, y, FarVertex.shaded(k3, SHADE_TOP), FarVertex.shaded(s3, SHADE_TOP), sy)
            b.quad(v0, v1, v2, v3)
        }

        // ---- walls ----------------------------------------------------------------------------

        /**
         * Walls on the edges between a column and its neighbour: between row j and row j + 1 ([alongX], walls that
         * face along Z) or between column i and column i + 1 (walls that face along X). The edge on the tile's own
         * border (index -1) belongs to the tile only if its own column is the higher one. Neighbouring columns that
         * have the same walls are merged along the edge into one quad.
         */
        private fun walls(alongX: Boolean) {
            val across = if (alongX) n else 1 // from a column to its neighbour on the other side of the edge
            val along = if (alongX) 1 else n // from a column to the next one along the edge
            val shadeBase = if (alongX) SHADE_Z else SHADE_X
            for (e in -1 until cells) {
                val aInside = e >= 0
                val bInside = e + 1 < cells
                var p = 0
                while (p < cells) {
                    val a = if (alongX) (e + 1) * n + (p + 1) else (p + 1) * n + (e + 1)
                    val dir = edgeDir(a, a + across, aInside, bInside)
                    if (dir == 0) {
                        p++
                        continue
                    }
                    val hi = if (dir > 0) a else a + across
                    val lo = if (dir > 0) a + across else a
                    if (skip[hi]) {
                        p++
                        continue
                    }
                    var run = 1
                    while (p + run < cells) {
                        val a2 = a + run * along
                        if (edgeDir(a2, a2 + across, aInside, bInside) != dir) break
                        val hi2 = if (dir > 0) a2 else a2 + across
                        val lo2 = if (dir > 0) a2 + across else a2
                        if (skip[hi2] || topY[hi2] != topY[hi] || topY[lo2] != topY[lo] || wallCol[hi2] != wallCol[hi] ||
                            slideY[hi2] != slideY[hi] || slideY[lo2] != slideY[lo] || slideWall(hi2, lo2) != slideWall(hi, lo)
                        ) break
                        run++
                    }
                    wall(alongX, e + 1, p, p + run, dir, hi, lo, shadeBase)
                    p += run
                }
            }
        }

        /**
         * Which side of the edge between columns [a] and [c] gets a wall: 1 = a's (a is the higher column and
         * inside this tile), -1 = c's, 0 = none (nothing to cover, or the higher column belongs to the neighbouring
         * tile, which emits that wall itself).
         *
         * Two columns need a wall between them if their heights differ, *or if the heights they slide to differ*:
         * equal neighbours whose coarse columns are at different heights come apart as the ring ends, and without a
         * (still zero-height) wall there the gap between them would be a crack. The higher column is the one with
         * the higher top, ties broken by the higher slide target.
         */
        private fun edgeDir(a: Int, c: Int, aInside: Boolean, bInside: Boolean): Int {
            val aHigher: Boolean
            if (topY[a] != topY[c]) {
                aHigher = topY[a] > topY[c]
            } else if (slideY[a] != slideY[c]) {
                aHigher = slideY[a] > slideY[c]
            } else {
                return 0
            }
            return if (aHigher) (if (aInside) 1 else 0) else (if (bInside) -1 else 0)
        }

        /** What a wall between [hi] and [lo] slides to, as one number to compare: the colour of the walls of the coarse
         *  column that is the higher of the two over them (the wall that is there once the ring has ended), and whether
         *  that wall is soil over rock. */
        private fun slideWall(hi: Int, lo: Int): Int {
            val from = if (slideY[hi] >= slideY[lo]) hi else lo
            return (slide.wallRgb[from] shl 1) or (if (slide.wallSoil[from]) 1 else 0)
        }

        /**
         * The wall of lattice edge [q] (a row line for [alongX], a column line otherwise) from [p0] to [p1], standing
         * under column [hi] and over column [lo] ([dir] > 0: the wall faces the side of larger lattice index along the
         * across direction), in one piece or two (see [layered]).
         */
        private fun wall(alongX: Boolean, q: Int, p0: Int, p1: Int, dir: Int, hi: Int, lo: Int, shadeBase: Float) {
            val yt = topY[hi]
            val yb = max(topY[lo], floorY)
            val mt = slideY[hi]
            val mb = slideY[lo]
            // (equal heights with different slide targets: a wall that is flat now and opens later)
            if (!(yt > yb || mt > mb)) return
            val key = wallCol[hi]
            val ownRgb = FarPalette.rgbOf(key)
            val packed = slideWall(hi, lo)
            val slideRgb = packed shr 1
            val parentSoil = (packed and 1) != 0
            // The wall faces +Z (alongX) / +X on the side of the larger index when the lower column is that one.
            val forward = (dir > 0) == alongX
            if (key != FarPalette.soilWallKey || yt - yb <= SOIL_DEPTH) {
                wallPiece(alongX, q, p0, p1, forward, yb, yt, mb, mt, ownRgb, slideRgb, shadeBase)
                return
            }
            // A soil-sided column is dirt for SOIL_DEPTH blocks below its top and stone below that, as the generator
            // builds it, so the cliffs of a distant mountain are not dirt all the way down. The seam slides to where
            // the coarse column's own seam is when that column has one (it is as tall as the soil is deep or taller),
            // so the colours meet where the coarse level puts them; if it has none the whole wall slides to its colour.
            val seam = yt - SOIL_DEPTH
            val layeredAbove = parentSoil && mt - mb > SOIL_DEPTH
            val seamTarget = if (layeredAbove) mt - SOIL_DEPTH else mb + (mt - mb) * ((seam - yb) / (yt - yb))
            val rockRgb = FarPalette.rgbOf(FarPalette.rockWallKey)
            wallPiece(alongX, q, p0, p1, forward, yb, seam, mb, seamTarget, rockRgb, if (layeredAbove) rockRgb else slideRgb, shadeBase)
            wallPiece(alongX, q, p0, p1, forward, seam, yt, seamTarget, mt, ownRgb, slideRgb, shadeBase)
        }

        /** One quad of a wall, from height [y0] to [y1], whose ends slide to [m0] and [m1], seen from the side it faces
         *  (counter-clockwise from outside). */
        private fun wallPiece(
            alongX: Boolean, q: Int, p0: Int, p1: Int, forward: Boolean,
            y0: Float, y1: Float, m0: Float, m1: Float, rgb: Int, slideRgb: Int, shadeBase: Float
        ) {
            val own = FarVertex.shaded(rgb, wallShade(y0, y1, shadeBase))
            val to = FarVertex.shaded(slideRgb, wallShade(m0, m1, shadeBase))
            val first = if (forward) p0 else p1
            val second = if (forward) p1 else p0
            val v0 = wallVertex(alongX, q, first, y0, own, to, m0)
            val v1 = wallVertex(alongX, q, second, y0, own, to, m0)
            val v2 = wallVertex(alongX, q, second, y1, own, to, m1)
            val v3 = wallVertex(alongX, q, first, y1, own, to, m1)
            b.quad(v0, v1, v2, v3)
        }

        private fun wallVertex(alongX: Boolean, q: Int, p: Int, y: Float, rgb: Int, slideRgb: Int, slideY: Float): Int =
            if (alongX) vertex(p, q, y, rgb, slideRgb, slideY) else vertex(q, p, y, rgb, slideRgb, slideY)

        // ---- trees ----------------------------------------------------------------------------

        /** The finest levels: real trees, where the chunk generator will grow them. (The generator's tree lattice
         *  is 4 x 4 blocks whatever the column width here.) */
        private fun trees() {
            val sea = WorldConfig.SEA_LEVEL
            val size = tileBlocks(level)
            val lattice = size / 4
            val lx0 = x0 / 4
            val lz0 = z0 / 4
            for (lj in 0 until lattice) {
                for (li in 0 until lattice) {
                    val spot = generator.treeSpot(lx0 + li, lz0 + lj) ?: continue
                    val ci = Math.floorDiv(spot.x - x0, step) + 1
                    val cj = Math.floorDiv(spot.z - z0, step) + 1
                    if (ci < 1 || ci > cells || cj < 1 || cj > cells) continue
                    val c = cj * n + ci
                    if (skip[c] || field.heights[c] < sea + 1) continue
                    // A tree slides into the ground (just under the surface it slides to) as its ring ends, so
                    // it never pops.
                    emitTree(b, spot, topY[c], slideY[c] - 0.6f, field.tint[c])
                }
            }
        }
    }

    /** Shade of a wall. Walls that stand in the water (the seabed steps seen through a translucent surface, the
     *  foot of a coast) get the shade of a top, so they never draw dark contour lines through or along the water;
     *  low shore steps get a halfway shade. */
    private fun wallShade(yb: Float, yt: Float, base: Float): Float {
        if (yt <= WATER_Y) return SHADE_TOP
        if (yb < WATER_Y && yt < WATER_Y + 2.5f) return 0.5f * (base + SHADE_TOP)
        return base
    }

    // ---- trees ----------------------------------------------------------------------------------

    /** An open-bottomed box: a top and four walls, all sliding to the height [m] (and keeping their colours). */
    private fun emitBox(
        b: LandMeshBuilder, xa: Float, xb: Float, za: Float, zb: Float, yb: Float, yt: Float, topKey: Int, sideKey: Int, m: Float
    ) {
        if (yt <= yb) return
        val top = FarVertex.shaded(FarPalette.rgbOf(topKey), SHADE_TOP)
        val sideX = FarVertex.shaded(FarPalette.rgbOf(sideKey), SHADE_X)
        val sideZ = FarVertex.shaded(FarPalette.rgbOf(sideKey), SHADE_Z)
        fun v(x: Float, y: Float, z: Float, rgb: Int) = b.vertex(x, y, z, rgb, rgb, m)
        // top
        b.quad(v(xa, yt, za, top), v(xa, yt, zb, top), v(xb, yt, zb, top), v(xb, yt, za, top))
        // +X, -X, +Z, -Z (counter-clockwise seen from outside)
        b.quad(v(xb, yb, zb, sideX), v(xb, yb, za, sideX), v(xb, yt, za, sideX), v(xb, yt, zb, sideX))
        b.quad(v(xa, yb, za, sideX), v(xa, yb, zb, sideX), v(xa, yt, zb, sideX), v(xa, yt, za, sideX))
        b.quad(v(xa, yb, zb, sideZ), v(xb, yb, zb, sideZ), v(xb, yt, zb, sideZ), v(xa, yt, zb, sideZ))
        b.quad(v(xb, yb, za, sideZ), v(xa, yb, za, sideZ), v(xa, yt, za, sideZ), v(xb, yt, za, sideZ))
    }

    /**
     * One distant tree as boxes: a trunk and a canopy (two stacked canopy boxes for a spruce), sized to match what
     * [com.voxelsandbox.game.world.generation.TreeBuilder] grows. [cellTop] is the LOD ground the tree stands on; the
     * trunk reaches down to it so a tree never floats above the flat cell top on a slope. [m] is the height the whole
     * tree flattens to at the end of its ring.
     */
    private fun emitTree(b: LandMeshBuilder, spot: TerrainGenerator.TreeSpot, cellTop: Float, m: Float, tint: Int) {
        val th = spot.th
        val species = spot.species
        val base = spot.ground + 1f
        val x = spot.x.toFloat()
        val z = spot.z.toFloat()
        val variant = ((th ushr 3) and 1).toFloat()
        val bush = species != TreeSpecies.SPRUCE && ((th ushr 20) and 15) == 0
        val leafBase = when (species) {
            TreeSpecies.BIRCH -> TextureAtlas.RAMP_BIRCH_LEAF
            TreeSpecies.SPRUCE -> TextureAtlas.RAMP_SPRUCE_LEAF
            TreeSpecies.OAK -> TextureAtlas.RAMP_OAK_LEAF
        }
        val woodBase = when (species) {
            TreeSpecies.BIRCH -> TextureAtlas.RAMP_BIRCH_WOOD
            TreeSpecies.SPRUCE -> TextureAtlas.RAMP_SPRUCE_WOOD
            TreeSpecies.OAK -> TextureAtlas.RAMP_OAK_WOOD
        }
        val topKey = styler.leafKey(leafBase + variant, tint)
        val sideKey = styler.leafKey(leafBase + 1f + variant, tint)
        val woodKey = FarPalette.colorKey(TextureAtlas.RAMP_ROW_FOLIAGE, woodBase)
        val bigOak = species == TreeSpecies.OAK && ((th ushr 24) and 7) == 0
        val trunk = when {
            bush -> 1
            species == TreeSpecies.BIRCH -> 6 + ((th ushr 4) % 4)
            species == TreeSpecies.SPRUCE -> 7 + ((th ushr 4) % 7)
            bigOak -> 7 + ((th ushr 4) % 3)
            else -> 5 + ((th ushr 4) % 4)
        }

        if (!bush) {
            emitBox(b, x, x + 1f, z, z + 1f, min(base - 0.25f, cellTop), base + trunk, woodKey, woodKey, m)
        }
        val cx = x + 0.5f
        val cz = z + 0.5f
        val tf = trunk.toFloat()
        when {
            bush -> emitBox(b, cx - 1.5f, cx + 1.5f, cz - 1.5f, cz + 1.5f, base, base + 3f, topKey, sideKey, m)
            species == TreeSpecies.SPRUCE -> {
                emitBox(b, cx - 3.25f, cx + 3.25f, cz - 3.25f, cz + 3.25f, base + 2f, base + tf - 4f, topKey, sideKey, m)
                emitBox(b, cx - 1.7f, cx + 1.7f, cz - 1.7f, cz + 1.7f, base + tf - 4f, base + tf + 1f, topKey, sideKey, m)
            }
            species == TreeSpecies.BIRCH ->
                emitBox(b, cx - 2f, cx + 2f, cz - 2f, cz + 2f, base + tf - 4f, base + tf + 1f, topKey, sideKey, m)
            bigOak ->
                emitBox(b, cx - 3.5f, cx + 3.5f, cz - 3.5f, cz + 3.5f, base + tf - 4f, base + tf + 1f, topKey, sideKey, m)
            else ->
                emitBox(b, cx - 2.5f, cx + 2.5f, cz - 2.5f, cz + 2.5f, base + tf - 4f, base + tf + 1f, topKey, sideKey, m)
        }
    }

    internal companion object {
        // Shading of the flat-coloured columns: exactly the voxel faces' (tops, and walls along each axis).
        private const val SHADE_TOP = FaceShade.TOP
        private const val SHADE_Z = FaceShade.ALONG_Z
        private const val SHADE_X = FaceShade.ALONG_X

        /** [ownUni] of a column that is not drawn. */
        private const val NOT_DRAWN = -2

        /** The colour that all four corners share, or -1 if they differ. */
        private fun uniform(a: Int, b: Int, c: Int, d: Int): Int = if (a == b && a == c && a == d) a else -1
    }
}
