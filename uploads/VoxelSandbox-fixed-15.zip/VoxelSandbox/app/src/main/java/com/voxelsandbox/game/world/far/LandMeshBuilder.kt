package com.voxelsandbox.game.world.far

import com.voxelsandbox.game.world.mesh.MeshData
import kotlin.math.max

/**
 * Collects the vertices and triangles of a distant-terrain land tile, in the vertex format described by
 * [FarVertex]. Every quad of the column meshes has four vertices of its own (a vertex is added once and may be
 * used by any number of triangles, but columns share none: each face has its own colour and slide target).
 */
internal class LandMeshBuilder(initialVertices: Int) {
    private var floats = FloatArray(max(initialVertices, 16) * FarVertex.FLOATS)
    private var indices = IntArray(max(initialVertices, 16) * 3 / 2)
    private var verts = 0
    private var idx = 0
    private var minY = Float.MAX_VALUE
    private var maxY = -Float.MAX_VALUE

    val vertexCount: Int get() = verts

    /**
     * Adds a vertex and returns its index. [rgb] / [slideRgb] are the colours (0xRRGGBB, shade applied) the vertex
     * has and ends the ring with, [slideY] the height it slides to.
     */
    fun vertex(x: Float, y: Float, z: Float, rgb: Int, slideRgb: Int, slideY: Float): Int {
        val stride = FarVertex.FLOATS
        if ((verts + 1) * stride > floats.size) floats = floats.copyOf(max(floats.size * 2, (verts + 1) * stride))
        var i = verts * stride
        val f = floats
        f[i++] = x; f[i++] = y; f[i++] = z
        f[i++] = FarVertex.colorOf(rgb)
        f[i++] = FarVertex.colorOf(slideRgb)
        f[i] = slideY
        if (y < minY) minY = y
        if (y > maxY) maxY = y
        // The slide target counts towards the tile's vertical extent too (a tile is culled by that box),
        // whichever way it goes.
        if (slideY < minY) minY = slideY
        if (slideY > maxY) maxY = slideY
        return verts++
    }

    /** One triangle, counter-clockwise seen from the front. */
    fun triangle(a: Int, b: Int, c: Int) {
        if (idx + 3 > indices.size) indices = indices.copyOf(max(indices.size * 2, idx + 3))
        indices[idx++] = a; indices[idx++] = b; indices[idx++] = c
    }

    /** One quad of four vertices listed counter-clockwise seen from the front: (a, b, c) and (a, c, d). */
    fun quad(a: Int, b: Int, c: Int, d: Int) {
        triangle(a, b, c)
        triangle(a, c, d)
    }

    fun build(): MeshData {
        if (verts == 0) return MeshData.EMPTY
        return MeshData(
            floats.copyOf(verts * FarVertex.FLOATS),
            indices.copyOf(idx),
            verts,
            minY,
            maxY
        )
    }
}
