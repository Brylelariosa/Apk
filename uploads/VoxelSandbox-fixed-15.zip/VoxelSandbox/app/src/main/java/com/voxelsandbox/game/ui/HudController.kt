package com.voxelsandbox.game.ui

import android.view.MotionEvent
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.voxelsandbox.game.R
import com.voxelsandbox.game.creative.BlockIcons
import com.voxelsandbox.game.input.InputState
import com.voxelsandbox.game.inventory.Hotbar
import com.voxelsandbox.game.world.BlockType

/**
 * Wires the HUD's touch views (joystick, look pad, action buttons, hotbar, creative inventory) to the
 * shared InputState and Hotbar. Kept separate from GameActivity so the activity
 * doesn't balloon into a god-class of findViewById calls.
 */
class HudController(
    private val root: View,
    private val input: InputState,
    private val hotbar: Hotbar,
    private val onPause: () -> Unit
) {
    private val joystick: VirtualJoystickView = root.findViewById(R.id.joystick)
    private val lookPad: LookPadView = root.findViewById(R.id.look_pad)
    private val btnJump: View = root.findViewById(R.id.btn_jump)
    private val btnBreak: View = root.findViewById(R.id.btn_break)
    private val btnPlace: View = root.findViewById(R.id.btn_place)
    private val btnInventory: View = root.findViewById(R.id.btn_inventory)
    private val btnPauseView: View = root.findViewById(R.id.btn_pause)
    private val btnFly: View = root.findViewById(R.id.btn_fly)
    private val btnDescend: View = root.findViewById(R.id.btn_descend)
    private val btnLaser: View = root.findViewById(R.id.btn_laser)
    private val hotbarContainer: LinearLayout = root.findViewById(R.id.hotbar_container)
    private val hotbarLabel: TextView = root.findViewById(R.id.hotbar_label)
    private val hudEditBar: View = root.findViewById(R.id.hud_edit_bar)
    private val btnResetLayout: View = root.findViewById(R.id.btn_reset_hud_layout)
    private val btnDoneHudEdit: View = root.findViewById(R.id.btn_done_hud_edit)

    val debugText: TextView = root.findViewById(R.id.debug_text)

    /** Biome name (and flight state), top centre. */
    val statusText: TextView = root.findViewById(R.id.status_text)

    private var flyingOn = false

    private val hotbarSlotViews = ArrayList<ImageView>()
    private val shownSlotIds = IntArray(Hotbar.SIZE) { -1 }
    private val shownFrames = IntArray(Hotbar.SIZE) { -1 } // 1 = selection frame drawn, 0 = plain frame

    private val icons = BlockIconCache(root.resources)
    private val hotbarSlotPx = (HOTBAR_SLOT_DP * root.resources.displayMetrics.density).toInt()

    /** Icons are enlarged by a whole number so every pixel stays square; never more than the slot holds. */
    private val hotbarIconScale = Math.max(1, Math.min(icons.scaleFor(HOTBAR_ICON_DP), hotbarSlotPx / BlockIcons.SIZE))

    private val inventory = CreativeInventoryController(
        root, hotbar, icons,
        onOpenChanged = { open -> onInventoryOpenChanged(open) },
        onPicked = { block -> onBlockPicked(block) }
    )

    private val hudLayoutStore = HudLayoutStore(root.context)
    private var editMode = false

    /** Every button/control the player can drag and resize. The joystick and
     *  hotbar move/scale as single units; look_pad (a full-screen invisible drag
     *  region, not a discrete button) is intentionally excluded. The fly button keeps the
     *  stored key "btn_creative" of the star button it replaced, so a layout the player
     *  already customised is still honoured. */
    private val customizableViews: List<Pair<String, View>> = listOf(
        "joystick" to joystick,
        "btn_jump" to btnJump,
        "btn_break" to btnBreak,
        "btn_place" to btnPlace,
        "btn_inventory" to btnInventory,
        "btn_pause" to btnPauseView,
        "btn_creative" to btnFly,
        "btn_descend" to btnDescend,
        "btn_laser" to btnLaser,
        "hotbar" to hotbarContainer
    )

    init {
        joystick.onChanged = { forward, strafe ->
            input.moveForward = forward
            input.moveStrafe = strafe
        }
        lookPad.onLookDelta = { dx, dy -> input.addLookDelta(dx, dy) }

        bindHold(btnJump) { input.jumpHeld = it }
        bindHold(btnBreak) { input.breakHeld = it }
        bindHold(btnPlace) { input.placeHeld = it }
        bindHold(btnDescend) { input.descendHeld = it }
        bindHold(btnLaser) { input.laserHeld = it }

        btnInventory.setOnClickListener { inventory.toggle() }
        btnPauseView.setOnClickListener { onPause() }
        btnFly.setOnClickListener { input.requestFlightToggle() }

        btnResetLayout.setOnClickListener { resetHudLayout() }
        btnDoneHudEdit.setOnClickListener { exitCustomizeMode() }

        buildHotbar()
        applyFlightVisibility()
        applyStoredHudLayout()
    }

    private fun bindHold(view: View, setter: (Boolean) -> Unit) {
        view.setOnTouchListener { v, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    setter(true)
                    v.isPressed = true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    setter(false)
                    v.isPressed = false
                }
            }
            true
        }
    }

    private fun buildHotbar() {
        hotbarContainer.removeAllViews()
        hotbarSlotViews.clear()
        val density = root.resources.displayMetrics.density
        val slotSizePx = hotbarSlotPx
        val marginPx = (4 * density).toInt()
        for (i in 0 until Hotbar.SIZE) {
            val slot = ImageView(root.context).apply {
                layoutParams = LinearLayout.LayoutParams(slotSizePx, slotSizePx).apply {
                    marginStart = marginPx
                    marginEnd = marginPx
                }
                scaleType = ImageView.ScaleType.CENTER
                setOnClickListener {
                    hotbar.select(i)
                    refreshHotbar()
                    showBlockLabel(hotbar.blockAt(i))
                }
            }
            hotbarSlotViews.add(slot)
            hotbarContainer.addView(slot)
        }
        refreshHotbar()
    }

    /** Brings the hotbar slots up to date (icons and the selection frame). Called from GameActivity's
     *  periodic tick and after every change; it only touches a slot whose block or selection really changed. */
    fun refreshHotbar() {
        val selected = hotbar.selectedIndex
        for (i in 0 until Hotbar.SIZE) {
            val block = hotbar.blockAt(i)
            val slot = hotbarSlotViews[i]
            if (shownSlotIds[i] != block.id.toInt()) {
                shownSlotIds[i] = block.id.toInt()
                slot.setImageDrawable(icons.drawable(block, hotbarIconScale))
                slot.contentDescription = block.displayName
            }
            val frame = if (i == selected) 1 else 0
            if (shownFrames[i] != frame) {
                shownFrames[i] = frame
                slot.setBackgroundResource(if (frame == 1) R.drawable.bg_hotbar_slot_selected else R.drawable.bg_hotbar_slot)
            }
        }
        inventory.refreshSelection()
    }

    /** A block was chosen in the creative inventory: it is in the selected slot now. */
    private fun onBlockPicked(block: BlockType) {
        refreshHotbar()
        showBlockLabel(block)
    }

    /** Shows [block]'s name above the hotbar for a moment. */
    private fun showBlockLabel(block: BlockType) {
        hotbarLabel.text = block.displayName
        hotbarLabel.animate().cancel()
        hotbarLabel.alpha = 1f
        hotbarLabel.animate().alpha(0f).setStartDelay(LABEL_HOLD_MS).setDuration(LABEL_FADE_MS).start()
    }

    // ---- the creative inventory ----------------------------------------------------------------

    val isInventoryOpen: Boolean get() = inventory.isOpen

    fun closeInventory() = inventory.close()

    /** Back key: closes the inventory if it is open. Returns true when it did. */
    fun handleBack(): Boolean {
        if (!inventory.isOpen) return false
        inventory.close()
        return true
    }

    /** While the inventory is open nothing may reach the game: whatever was held is let go, the touch
     *  tracking of the joystick and look pad is reset (a finger still down on them is ignored until it lifts),
     *  and the engine ignores the controls until it closes. */
    private fun onInventoryOpenChanged(open: Boolean) {
        releaseAllInputs()
        input.uiBlocked = open
    }

    /** Releases all held inputs — used when leaving gameplay (pause/menu) so a
     *  finger lifted off-screen (e.g. by a system dialog) can't leave movement or
     *  break/place stuck "on". Also resets the joystick's and look pad's own
     *  touch-tracking (see VirtualJoystickView.cancelActiveTouch): zeroing the
     *  InputState fields above is enough for the engine, but without this the two
     *  gesture views themselves can latch onto a pointer id that never comes again
     *  and silently stop responding to every touch after. */
    fun releaseAllInputs() {
        input.moveForward = 0f
        input.moveStrafe = 0f
        input.jumpHeld = false
        input.breakHeld = false
        input.placeHeld = false
        input.descendHeld = false
        input.laserHeld = false
        joystick.cancelActiveTouch()
        lookPad.cancelActiveTouch()
    }

    // ---- HUD customization ("Customize HUD" in the pause menu) -------------------

    private fun applyStoredHudLayout() {
        val dm = root.resources.displayMetrics
        for ((key, view) in customizableViews) {
            val layout = hudLayoutStore.get(key)
            view.translationX = layout.offsetXFrac * dm.widthPixels
            view.translationY = layout.offsetYFrac * dm.heightPixels
            view.scaleX = layout.scale
            view.scaleY = layout.scale
            // Heals a position an older build already let the player drag fully
            // off-screen (see HudGeometry.kt) — deferred with post() since
            // width/height/getLocationOnScreen aren't valid until this element has
            // actually been laid out, which hasn't happened yet this early in
            // HudController's construction.
            view.post {
                val beforeX = view.translationX
                val beforeY = view.translationY
                clampTranslationToScreen(view)
                if (view.translationX != beforeX || view.translationY != beforeY) {
                    persistHudElement(key, view)
                }
            }
        }
    }

    private fun persistHudElement(key: String, view: View) {
        val dm = root.resources.displayMetrics
        hudLayoutStore.set(
            key,
            HudElementLayout(
                offsetXFrac = view.translationX / dm.widthPixels,
                offsetYFrac = view.translationY / dm.heightPixels,
                scale = view.scaleX
            )
        )
    }

    /** Swaps every customizable button's normal gameplay touch handling for a
     *  drag/pinch-resize listener. Also freezes movement/look/hotbar-tap so a
     *  finger dragging a button can't also move the player or fire a hotbar
     *  selection underneath it. */
    fun enterCustomizeMode() {
        if (editMode) return
        editMode = true
        releaseAllInputs()
        lookPad.setOnTouchListener { _, _ -> true } // swallow touches; no camera drag while customizing
        hotbarSlotViews.forEach { it.isClickable = false } // let a drag starting on a slot move the whole bar
        for ((key, view) in customizableViews) {
            view.setOnTouchListener(DragResizeTouchListener(view, onAdjusted = { persistHudElement(key, view) }))
        }
        hudEditBar.visibility = View.VISIBLE
        applyFlightVisibility()
    }

    /** Shows the fly-down button while flying and marks the fly button as on or off. Called from
     *  GameActivity whenever the flight state may have changed. */
    fun setFlying(flying: Boolean) {
        if (flyingOn == flying) return
        flyingOn = flying
        applyFlightVisibility()
    }

    private fun applyFlightVisibility() {
        // While customizing, every button is shown so it can be placed.
        btnDescend.visibility = if (editMode || flyingOn) View.VISIBLE else View.INVISIBLE
        btnFly.alpha = if (flyingOn) 1f else 0.65f
    }

    /** Restores normal gameplay input handling. Safe to call even if edit mode was
     *  never entered (GameActivity calls this defensively whenever gameplay is
     *  paused/backgrounded, so a stray edit session can never carry over into the
     *  next play session with buttons still frozen in drag mode). */
    fun exitCustomizeMode() {
        if (!editMode) return
        editMode = false
        hudEditBar.visibility = View.GONE
        lookPad.setOnTouchListener(null)
        hotbarSlotViews.forEach { it.isClickable = true }
        for ((_, view) in customizableViews) view.setOnTouchListener(null)
        // Hold-buttons rely on setOnTouchListener for gameplay too (see bindHold),
        // so clearing it above means it must be reattached here.
        bindHold(btnJump) { input.jumpHeld = it }
        bindHold(btnBreak) { input.breakHeld = it }
        bindHold(btnPlace) { input.placeHeld = it }
        bindHold(btnDescend) { input.descendHeld = it }
        bindHold(btnLaser) { input.laserHeld = it }
        applyFlightVisibility()
    }

    private fun resetHudLayout() {
        hudLayoutStore.reset()
        for ((_, view) in customizableViews) {
            view.translationX = 0f
            view.translationY = 0f
            view.scaleX = 1f
            view.scaleY = 1f
        }
    }

    private companion object {
        /** About how big a block icon is drawn in a hotbar slot (the slot itself is 54dp). */
        const val HOTBAR_SLOT_DP = 54f
        const val HOTBAR_ICON_DP = 44f
        const val LABEL_HOLD_MS = 900L
        const val LABEL_FADE_MS = 400L
    }
}
