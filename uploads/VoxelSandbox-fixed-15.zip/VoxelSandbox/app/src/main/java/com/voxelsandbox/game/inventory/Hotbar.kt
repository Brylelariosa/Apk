package com.voxelsandbox.game.inventory

import com.voxelsandbox.game.world.BlockType
import java.util.concurrent.atomic.AtomicIntegerArray

/**
 * The creative hotbar: [SIZE] slots, each holding one block type for good (nothing is ever used up and
 * there are no counts). The player picks blocks from the creative inventory into it ([pick]) and selects a
 * slot to place from.
 *
 * Read by the game thread (what to place) and written by the UI thread (taps), so the slots live in an
 * atomic array and the selection is volatile; no operation needs more than one of them to be consistent.
 * Pure Kotlin: no Android classes, so it runs in unit tests.
 */
class Hotbar {
    companion object {
        const val SIZE = 8

        /** What a new world (and an old save that has no hotbar of its own) starts with. */
        val DEFAULT_LAYOUT: List<BlockType> = listOf(
            BlockType.GRASS, BlockType.DIRT, BlockType.STONE, BlockType.SAND,
            BlockType.WOOD, BlockType.LEAVES, BlockType.COAL_ORE, BlockType.WATER
        )

        /** True for a block that may sit in a slot: every registered block except air. */
        fun isAllowed(block: BlockType): Boolean = block != BlockType.AIR
    }

    private val ids = AtomicIntegerArray(SIZE)

    @Volatile
    var selectedIndex: Int = 0
        private set

    init {
        for (i in 0 until SIZE) ids.set(i, DEFAULT_LAYOUT[i].id.toInt())
    }

    fun blockAt(index: Int): BlockType =
        if (index in 0 until SIZE) BlockType.fromId(ids.get(index).toByte()) else BlockType.AIR

    fun selectedBlock(): BlockType = blockAt(selectedIndex)

    fun select(index: Int) {
        if (index in 0 until SIZE) selectedIndex = index
    }

    /** The first slot holding [block], or -1. */
    fun indexOf(block: BlockType): Int {
        val id = block.id.toInt()
        for (i in 0 until SIZE) if (ids.get(i) == id) return i
        return -1
    }

    /**
     * Makes [block] available and selected, the way a tap in the creative inventory does: if it is already
     * in the hotbar that slot is selected, otherwise it replaces whatever the selected slot holds. Returns
     * the slot it ended up in, or -1 when [block] cannot be picked (air).
     */
    fun pick(block: BlockType): Int {
        if (!isAllowed(block)) return -1
        val existing = indexOf(block)
        if (existing >= 0) {
            selectedIndex = existing
            return existing
        }
        val slot = selectedIndex
        ids.set(slot, block.id.toInt())
        return slot
    }

    /** Puts [block] into slot [index] without touching the selection; false when either is invalid. */
    fun setSlot(index: Int, block: BlockType): Boolean {
        if (index !in 0 until SIZE || !isAllowed(block)) return false
        ids.set(index, block.id.toInt())
        return true
    }

    // ---- saving ------------------------------------------------------------------------------

    /** The block ids of the slots in order, for the save file. */
    fun exportIds(): ByteArray = ByteArray(SIZE) { ids.get(it).toByte() }

    /**
     * Restores a saved hotbar. Anything that does not make sense (no data, a block id that is not in the
     * registry today, air, fewer or more slots than there are now, a selection outside the bar) falls back
     * to the default for that slot, so a damaged or older save can never leave an invalid block in a slot.
     */
    fun restore(savedIds: ByteArray?, savedSelected: Int) {
        for (i in 0 until SIZE) {
            val saved = if (savedIds != null && i < savedIds.size) validBlockOrNull(savedIds[i]) else null
            ids.set(i, (saved ?: DEFAULT_LAYOUT[i]).id.toInt())
        }
        selectedIndex = if (savedSelected in 0 until SIZE) savedSelected else 0
    }

    private fun validBlockOrNull(id: Byte): BlockType? {
        val block = BlockType.fromId(id)
        // fromId maps unknown ids to AIR, but it also masks the id to the table size, so check the id came back.
        return if (isAllowed(block) && block.id == id) block else null
    }
}
