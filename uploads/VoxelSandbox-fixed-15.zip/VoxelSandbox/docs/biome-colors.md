# Biome colours (v15)

Grass, leaves and tall grass take their colour from a smooth field of the world's climate, on the voxel terrain and
on the distant terrain alike. Nothing about a chunk, a mesh or a tile enters into it, so the colour of a place is
the same wherever and whenever it is asked for.

## What was wrong

The ground cover is three different blocks (grass, dry grass, swamp grass), chosen by a hard table of temperature and
humidity. Each block was drawn in its own fixed colour, so every border of the table was a hard line of lime next to
straw next to olive. The distant terrain did the same with three rows of its colour palette. Nothing in the colour
followed altitude, although the table does (high ground is colder).

## The field (`world/color/BiomeColorField.kt`, `Climate.kt`)

`BiomeColorField.grass(...)` is a pure function of position (and the height of the ground there): a blend of four
climate colours, `BiomePalette`: temperate, cold, dry and swamp. Each is not chosen but *measured*: the average colour of the
block texture that stands for it (the lime of plain grass, the straw of dry grass, the olive of swamp grass), and
cold is plain grass with its red taken down and its blue raised. So in the middle of a plain, a savanna or a swamp
the field says exactly what the texture always looked like.

The weights are soft versions of the table's own rules, built from the very same fields, wobble and height-dependent
temperature (`Climate.coldness`, `dryness`, `swampiness`, and `groundTemperature`, which the table now uses too):

- the 0.5 contour of a weight lies on the hard border of the table (a test checks 0 contradictions over 3 x 60 000 random
  columns, about 67 000 of them grass, savanna or swamp), so the colour is half-way between the two climates on the block that changes;
- `dryness` is the signed distance to the table's savanna / desert region, which is a staircase (the union of three
  boxes), taken through a smoothstep two `DRY_BAND`s wide: about 20-40 blocks of gradient;
- `swampiness` takes the colour over a wide window of the swamp weight (0.10..0.90 instead of the rule's 0.5): swamp
  patches have sharp edges (they are cut out of noise), which gave a 5 block gradient; this one is about 10 blocks;
- `coldness` falls with the ground temperature, so grass turns cool and bluish with altitude and towards taiga.

`Climate.biome()` itself is unchanged in what it answers: the golden check (9 seeds x 396 chunks of blocks, compared
with the output of v14) is bit-identical.

## Voxel terrain

`gl/BiomeColorMap.kt` holds the field in a 256 x 256 RGBA8 texture on unit 4: one texel per 4 x 4 blocks (the spacing
doubles if the voxel radius needs it, `BiomeColorLayout.spacingFor`), a torus around the eye, filled in 16 x 16 texel
tiles by a worker thread, nearest the eye first, and uploaded at most six tiles per frame. The block shader
(`VoxelShader.applyTint`) multiplies a tinted tile's texel by `field / anchor` (the climate colour the tile was drawn
for, so the factor is 1 in the middle of its own climate). Which tiles are tinted is one table, `gl/TintTable.kt`: grass tops,
the grass fringe on the sides of grass blocks, tall grass, and leaves (at 70 %, so a spruce stays a spruce). Sand, stone,
snow, gravel, dirt, water, wood and ore are not in it and are never touched, which is what keeps sand from
turning green and stone from taking the colour of the meadow beside it. The fringe is found by colour and stored as a mask in
the alpha channel of the three grass-side tiles, so the dirt below the grass stays brown.

No colour is stored in vertices, so greedy merging, chunk rebuilds, chunk borders and unloading cannot change it.

## Distant terrain

`world/far/FarGroundColor.kt` and `FarTerrain.buildField / buildLandMesh`. A grass cell takes the field's colour at its
centre times the brightness step it already had from the palette (the patch and forest noise are unchanged), the colour of each corner
of a cell is the average over the grass cells that meet there (cells of any other surface do not take part), and the top is drawn with a colour at
each corner. Such a colour travels in the `u` slot of the vertex as `-(0xRRGGBB + 1)` (exact in a float), the vertex
shader decodes it and the fragment shader mixes it with the palette lookup. Away from the borders of climates the field is
constant, so the cells still merge into long quads; only where it varies are they separate. Tree canopies (and the coarse
levels' forest cells) take the leaves' share of the shift, exactly as the voxel leaves do.

## Numbers

Measured on this machine's JVM (a desktop CPU, a phone is several times slower):

| | before (v14) | now |
|---|---|---|
| field, one 16 x 16 texel tile | - | 0.20 ms (0.8 us per texel); the whole GPU map 46 ms of one core, on a worker thread, over many frames |
| far land mesh, levels 0-4, radius 600 (3 test areas) | 81.2 / 108.6 / 102.4 MB | 83.1 / 113.9 / 105.5 MB (+2.4 / +4.9 / +3.0 %) |
| far tile build (level 0 / 1 / 2) | 1.6 / 8.0 / 6.5 ms | 1.8 / 8.8 / 7.2 ms (about +10 %) |

The voxel side adds one texture fetch and a table lookup per fragment of opaque terrain; **that was not measured on a GPU**.

## Checks

`tools/jvm-tests/run_biome.sh` (17 checks): determinism, exact palette colours in the middle of a climate, largest step between
neighbouring blocks (10 levels of 255), borders on the table's borders, altitude cools the grass, tile purity and agreement,
the tint table (what is and is not painted, the factor is 1 at home, the mask), the layout of the GPU map (torus, spacing),
the colour key through a float, corner averaging, the palette identity of far grass, tile-border agreement of far corners on
five levels (8 000 corners), and grass versus other surfaces.
Pictures (software WebGL2 on the real meshes and shaders): `out/` of the rig; before/after of the borders, and near next to far.

## Limits

- Not run on a phone or an emulator.
- The far terrain still darkens forests and varies by patches in 5 brightness steps (as before); the voxel terrain has no such
  patches, so a forest floor is darker from far away than up close (the far shader's tonal patches fade in from the edge of the voxel
  terrain, see `Shaders.FAR_FRAGMENT`).
- A pond's bed is dirt up close and sand-coloured in the distant mesh (not part of this change; it lies under water).
