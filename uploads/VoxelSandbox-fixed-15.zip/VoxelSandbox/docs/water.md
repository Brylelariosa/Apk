# Water (v15)

Pixel-art water that animates by changing frame, not by sliding; is pinned to the world, not to the camera; looks the
same at every distance; and takes its colour from nothing but its own depth and the sky, so it cannot change at a biome
border or tint the sand next to it.

## What it was (v14)

One 16 x 16 tile of three almost identical blues (`4279d2 4980d7 5088db`, within 9-15 levels of each other), repeated once per
block, and moved across the surface by the shader: **still water drifted continuously** (0.037 / 0.021 tiles a second) and running
water slid at 0.9 tiles a second. So a calm lake always crawled in one direction, and the one-block repeat showed as a grid.
(Checked in the software renderer: the v14 pattern was already tied to the world position, not to the camera, so moving the
camera by whole blocks changed no water pixel; what slid was the pattern with *time*.)

## What it is now

### The pixels (`gl/WaterPattern.kt`, pure Kotlin, no GL)

- A tile of 128 x 128 pixels, **16 pixels to the block like every block texture, one repeat per 8 blocks** (v14: per block),
  in 40 frames that loop seamlessly in space and in time. Four close blues (`3d6cc3 4579d0 5088db 6ba2e9`; neighbours differ
  by at most 30 levels a channel): 6 % darker troughs, 62 % calm base, 28 % lighter ripples, 4 % crests. The shares are exact
  (the height field is cut by pixel counts, not by thresholds that drift when a constant is tuned) and the mean colour is
  (73.1, 126.1, 211.3), the old tile's (73, 126, 211): the sea keeps its colour.
- Made from two octaves of gradient noise whose lattice gradients each turn once over the loop (so the field evolves
  smoothly and closes on itself), seen through a small periodic wobble. Ripples are longer along X than across. A ripple
  is always a run of pixels: **lone pixels are removed from every frame** (single pixels flicker and read as noise; a test
  checks there is none in any of the 40 frames). Between two frames about 7.8 % of the pixels change (min 7.2, max 8.8 %,
  the step that closes the loop 7.4 %), an edge moves a pixel at a time.
- The pixels are a pure function of the constants (trigonometry only on tiny tables, through `StrictMath`), so they are
  identical on every device and every run; a checksum test pins them. Generation takes tens of milliseconds on a desktop
  (68 ms cold); `WaterPattern.prewarm()` does it on a background thread while the main menu shows.

### Time and place (`gl/WaterAnimation.kt`, `Shaders.WATER_FRAGMENT`)

- **Still water does not move at all.** Its waves come from the change of frame (6 a second, a 6.67 s loop), picked on the CPU
  (one integer per frame, the layer of a `sampler2DArray`). Running water (flow vector in the mesh) carries the pattern along
  its flow at 0.8 blocks a second; a waterfall pulls it down its face.
- **Nothing slides when the camera moves.** The shader reads the tile at *camera-relative position + the camera origin
  modulo the tile*. The origin is a whole number of blocks, so that sum is the world position modulo the tile, exact, and it
  is the same whichever origin a frame uses: nothing moves when the camera moves and nothing jumps when the origin steps from one
  block to the next (unit-tested on 20 000 random origins up to +-200 000 blocks, and on every step -300..300).
- A very soft, slowly drifting patch field (`WaterPattern.tone`, 64 x 64 bytes, 4 blocks to the texel, 256 blocks to the repeat,
  drifting 0.256 blocks a second) shifts brightness by +-3 % and hue by a few percent: wind patches on the sea. It is what keeps
  a calm sea from looking like one flat colour and hides the tile's repeat.
- Every rate completes a whole number of cycles in the 1000 s wrap of the texture clock, so nothing jumps when it wraps (tested).

### Shoreline, depth, transparency, distance

- The alpha channel of the tile marks the ripple crests; in the first block of depth off a shore they turn pale: foam that
  follows the waves. Nothing in the water shaders reads a biome, a colour map or a vertex colour (a test lists every uniform and
  attribute), so water is the same colour everywhere and **only its own opacity lets sand or land show through**: it never tints them.
- v14's depth tint, grazing-angle sky mix, path-length opacity (the sea floor never shows as dark seams through a slanted
  view) and the near/far seam are kept as they were.
- **Distance**: the tile's mip chain averages it away where it is smaller than a pixel, and between 90 and 240 blocks it is
  faded to the mean colour of the animation, so what mip-mapping cannot calm down at grazing angles does not shimmer.
  The distant water layer uses the same shader and the same world-pinned pattern, so near and far water agree.
- **Cost**: two texture fetches per pixel (wave array, tone) against one in v14, no per-pixel trigonometry, no new overdraw
  (the same quads in the same passes). GPU memory 3.5 MB (40 x 128 x 128 RGBA8 with mips) and 5 KB; 2.6 MB of Java heap for the pixels
  so a lost GL context can be rebuilt without generating again. **Not measured on a phone.**

### Chunk borders

The mesher is unchanged (the water geometry of v14 is kept). It is now *tested* on the real `ChunkMesher` with lakes, a
stream and an ocean that cross the chunk borders: surface corners that two chunks share have the same height and depth; a
lake is one level surface with no wall between water cells and no hole or doubled layer anywhere (776 sample points); a stream
of flowing water has no wall across it at the border; merged deep-ocean rectangles leave no crack at any border and overlap the
next chunk's rectangle by the sliver on both sides (765 sample points). A negative control (meshing next to a chunk that is
not there) *does* produce a mismatch, so the checks can fail.

## Measured

Everything below was measured on this machine: JVM tests, or the game's real meshes and shader sources drawn by a software
WebGL2 renderer (`tools/render-rig`). A software renderer says nothing about the speed of a phone's GPU.

| what | result |
|---|---|
| camera moved by (+1,0) (+5,0) (+8,0) (0,+3) (-13,+7) blocks | 100.0000 % of 0.36-0.78 million water pixels identical, v14 and new alike |
| voxel water vs distant water drawn at the same place (camera 105 blocks above the sea) | mean of the largest channel difference: 0.48 levels up to 60 blocks from the eye, 0.70 from 60 to 92 (inside the voxel radius), 0.18 in the 8-block hand-over ring, 0.00 beyond; 1-4 % of the pixels differ by more than 4 levels (shorelines, where the distant mesh's depth is coarser) |
| per-frame change of the pattern | mean 7.8 %, min 7.2 %, max 8.8 % of the pixels; no lone pixel in any of the 40 frames |

Change between two frames 1/6 s apart (the animation's own step), still camera 0.7 blocks above the water, looking 6 degrees
down, 70 degree field of view, 1280 x 640; distance is along the water, v14 -> new:

| distance | pixels that change | mean change (levels) | worst pixel (levels) |
|---|---|---|---|
| 13-57 blocks | 0.6 % -> 42.5 % | 0.00 -> 0.20 | 1 -> 3 |
| 5-13 | 10.3 % -> 50.0 % | 0.04 -> 0.53 | 1 -> 13 |
| 2.6-5 | 7.2 % -> 12.5 % | 0.11 -> 0.69 | 5 -> 16 |
| 1.5-2.6 | 3.0 % -> 7.4 % | 0.14 -> 0.69 | 5 -> 18 |
| 1.1-1.5 | 3.4 % -> 7.7 % | 0.17 -> 0.82 | 6 -> 18 |
| 0.85-1.1 | 3.2 % -> 6.9 % | 0.16 -> 0.74 | 6 -> 18 |

(The large share of changing pixels far away is almost all +-1 level: the tone patches drift, and in the fade zone the pattern is
mixed with the mean colour. The mean change shows it.)

So the new water **moves more visibly than v14's**, which was nearly static from frame to frame (that was the slow drift). That
is the "subtle animated waves"; it is not zero, and the pixel art flips an edge pixel by up to about 18 levels at close range, 3 levels beyond 13 blocks.
If it turns out to be too lively on a phone, `WaterAnimation.FPS` (6) and the palette / `SHARES` in `WaterPattern` are the
knobs; the pattern checksum test must then be updated on purpose (it says so).

## Limits (and what is not verified)

- **Nothing here has run on a phone or an emulator**, the GPU cost of the second texture fetch was not measured, and the
  Gradle/AGP build was not run (no way to here). The shader compiles in SwiftShader (WebGL2), which is not the phone's driver.
- **Diagonal chunk neighbours.** A chunk is meshed once its four side neighbours are generated; its *diagonal* neighbour
  (the chunk that touches only at the corner) may still be queued, and when it arrives nothing remeshes the chunk. The one
  surface corner at which they meet then keeps a water depth computed as if the missing chunk were dry land: measured on a
  4-block deep lake, depth 3 instead of 4 at that corner, which the shader turns into about 4.5 % of red brightness and 3 %
  of opacity, fading over one block. It exists in v14 too; the side borders (which are always waited for) are exact. Not fixed
  in this checkpoint.
- Tone patches and the pattern fade are tuned by eye on software-rendered frames, not on a phone.

## Where

`gl/WaterPattern.kt` (pixels), `gl/WaterAnimation.kt` (time and place maths), `gl/WaterTexture.kt` (GL upload: the 40-layer array
and the tone texture, on texture units of their own), `gl/WaterRenderer.kt`, `gl/Shaders.kt` (`WATER_FRAGMENT`),
`gl/FrameState.kt` and `gl/GameRenderer.fillFrameState` (per-frame layer and phases), `GameActivity` (prewarm).
Checks: `tools/jvm-tests/WaterTests.kt` (`run_water.sh`, 28 checks); pictures and rig scripts: `tools/render-rig`.
