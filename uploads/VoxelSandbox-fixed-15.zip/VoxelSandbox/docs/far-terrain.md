# Distant terrain (v15)

The ground beyond the voxel area, from a few hundred blocks out to the render distance (3199 blocks on the test phone's HUD).
It stays what the player asked for ("make it like Distant Horizons"): **blocky voxel columns with the real block colours, trees
and water, whose bricks grow with distance**, not a smooth mesh. What changed in v15 is how the levels follow one another, what
happens when a tile is missing, and how mountains are cut into bricks.

## What it was (v14)

- The same ladder of column sizes (2, 4, 8 ... 256 blocks) but rings that ended at 512 / 896 / 1408 / 2304 / 6400 / 12800 blocks, so
  from 2300 blocks on the columns were 64 to 256 blocks wide and a distant mountain was a handful of big boxes.
- A level slid its column *heights* to the next level's over a narrow band (`aMorph`, 32 to 1024 blocks wide), but a vertex carried
  no target colour, so colour was not part of the hand-over: the shape changed continuously, the colour did not.
- A tile that was not built when the player reached its ring left a **hole** in the picture. The only remedy was to pull the fog
  in until the tile arrived, which shortened the view for as long as it took.

## What it is now

### The ladder (`world/far/FarLevels.kt`)

| level | column (blocks) | tile (blocks) | ring (blocks from the eye) | height rounded to | slides to the next level over the last |
|---|---|---|---|---|---|
| 0 (optional) | 2 | 64 | a thin ring just behind the voxel area | 1 | 32 |
| 1 | 4 | 256 | 0 - 512 | 1 | 96 |
| 2 | 8 | 512 | 512 - 1024 | 1 | 200 |
| 3 | 16 | 512 | 1024 - 2048 | 2 | 400 |
| 4 | 32 | 1024 | 2048 - 4096 | 4 | 800 |
| 5 | 64 | 2048 | 4096 - 8192 | 8 | 1600 |
| 6 | 128 | 4096 | 8192 - 16384 | 16 | 3200 |
| 7 | 256 | 8192 | 16384 - render distance | 32 | - |

Every ring ends at twice the distance of the one before and its columns are twice as wide, so a column is about the same size on
screen wherever it is looked at (128 to 256 columns fit between the eye and the end of a ring) and every doubling of the render
distance adds the same amount of work. Every step is a power of two and the grids are aligned: the columns of a level are exactly
2 x 2 of the level below, and the footprint of a tile lies inside exactly one tile of every coarser level.

### Bricks that follow the mountain

- **Heights are rounded** to the level's quantum (table) except within 4 blocks of the sea, so the shore never moves between levels.
  The quantum is about one pixel of the picture at the level's inner edge: the rounding is a texture, not a shape. Neighbouring
  columns that round to the same height and colour merge.
- **Meshes are merged in two dimensions** (`FarColumnMesher`): tops become the largest flat rectangles that share height, colour
  and slide target; walls merge along the edge they stand on. A flat tile is one rectangle (two triangles), one raised column costs
  its top, four walls and at most five rectangles around it (both tested).
- **Peaks and ridges are kept**: the heights are sampled from the real generator at the level's own detail setting, not averaged,
  and a column is never drawn lower than its own rounded ground (tested on every column of every level).
- Real little trees stand on levels 0 and 1; from level 2 on, forested ground is raised into a canopy of the same colour.

### Levels hand over by sliding, not stepping

Each vertex carries its own height and colour **and the height and colour of the column of the next coarser level that stands over
it** (`FarVertex`, six floats). The vertex shader blends from one to the other with `smoothstep` of the vertex's distance from the
eye over the last stretch of the ring (table, last column). At the end of the ring a fine column therefore *is* the coarse column:
same height, same colour, same brightness. The coarse columns are computed by the very code that builds that level
(`FarColumnSampler`, shared by all levels with `FarStyler`, which also uses the biome colour field of `docs/biome-colors.md`), so
colours do not change where a level hands over (tested: "at the end of its ring a column is the column of the next level over it").

### Rings are cut by exact distance

Every fragment shader of the distant terrain discards what lies outside its ring, with the same formula on the squared distance
from the eye (`uBand`). Neighbouring levels partition the ground exactly: no seam, no overlap, no z-fighting between levels. The
finest ring (level 0) is optional and thin; level 1 is always built from the player outwards and covers wherever level 0 is not
(`uSkip` hands the ground to level 0 only when all its tiles are on the GPU).

### A tile that is not there (yet): stand-ins and a fade

(`world/far/FarStandIns.kt`, `world/far/FarTileMath.kt`, `gl/FarTerrainRenderer.kt`, `gl/ClipDither.kt`, `Shaders.CLIP_AND_DITHER`)

- When a tile that the picture needs is not on the GPU, **the finest coarser tile that contains its footprint is drawn in its place**,
  clipped to the missing tile's footprint and ring (`uClip`). It is the same ground in bigger bricks, and at the outer edge of the
  hole it equals the ring beyond, because that is the shape the missing level slides to. The picture is complete instead of having
  a gap, and the **fog is not pulled in** (the planner counts such a hole as covered; `FarTerrain.Candidate.limitsCoverage`).
- When the real tile arrives it **fades in over 450 ms by a complementary dither**: the new tile draws the pixels whose fixed
  screen-space noise (interleaved gradient noise on `gl_FragCoord`) is below the fade fraction, the stand-in the rest, so the two
  always cover every pixel exactly once. No alpha blending, no sorting, no gap at any moment, and no cost when nothing fades (one
  uniform branch). Only tiles that arrive while they were a hole fade; everything else is drawn as before.
- The HUD's far line gets a `fill: N` suffix while N stand-ins are in use.
- A hole with **no** resident coarser tile (start-up, or a tile behind the player that was already unloaded) has nothing to stand in:
  there the old behaviour applies (the fog is pulled in until the tile arrives).

## Measured

All on this build machine (desktop JVM, single thread, software WebGL2 renderer), seed 12345; none of it is a phone's number.

**Geometry, v14 against v15** (`DumpFarLod`: every tile of levels 1-7 that touches its ring, radius 3300, before frustum culling):

| site | triangles v14 | triangles v15 | GPU bytes v14 | GPU bytes v15 | tiles v14 | tiles v15 |
|---|---|---|---|---|---|---|
| mountains (-5186, 5094) | 962 024 | 1 087 974 (+13 %) | 63.9 MB | 63.7 MB (-0.2 %) | 113 | 149 (+32 %) |
| mountains (-1721, 3593) | 1 071 362 | 1 164 534 (+9 %) | 71.1 MB | 68.2 MB (-4 %) | 109 | 142 (+30 %) |
| plains (0, 0) | 753 888 | 825 354 (+9 %) | 50.1 MB | 48.4 MB (-3 %) | 105 | 132 (+26 %) |
| sea (-9000, -9000) | 910 310 | 986 188 (+8 %) | 60.5 MB | 57.8 MB (-4 %) | 113 | 142 (+26 %) |

So v15 draws **8-13 % more triangles and 26-32 % more tiles (so more draw calls, one land draw and, where there is water, one water
draw per visible tile)** than v14 for the same view: the rings are wider at the fine levels, which is what makes the distance look finer;
the vertex is one float smaller and the 2-D merge keeps the bytes level or a few percent lower. Building every tile of the mountain view
takes 1.70 s (v14) and 1.78 s (v15) on this machine, one thread, JIT warm-up included. The logic of the byte budget (`FarBudget`) and
the per-frame upload budgets is unchanged; only its first guess of what a tile weighs (`DEFAULT_TILE_BYTES`) was re-measured.

**Stand-ins** (picture `A-D` of the rig, 1280 x 640, a mountain face whose tiles of levels 1 and 2 are missing; difference to the
full-detail picture):

| picture | mean difference (of 255) | pixels differing by more than 24 | by more than 64 |
|---|---|---|---|
| tile missing, nothing drawn in its place | 4.61 | 3.34 % | 3.01 % |
| stand-in drawn | 0.69 | 0.88 % | 0.36 % |
| new tile 25 % faded in | 0.52 | 0.66 % | 0.27 % |
| new tile 50 % faded in | 0.35 | 0.44 % | 0.18 % |
| new tile 75 % faded in | 0.17 | 0.22 % | 0.09 % |

The stand-in is coarser ground, so it is not identical to the full picture (that is the 0.88 %: the bigger bricks and the canopy
instead of single trees), but there is no hole and no pop; the fade converges to the real tile.

**Planner**: 267 leading-edge holes were enumerated on a walking player's plan; every one has a built coarser tile to stand in.

## Checks

- `tools/jvm-tests/run_far.sh` (40 checks): ladder tables (steps double, grids nest, ring and column sizes fit), height rounding (monotonic,
  never moves the shore, about a pixel at the inner edge), vertex format (colours exact in a float), the field of every level agrees with
  its neighbours on shared borders, tops and walls cover every drawn column exactly once, every step between columns (now and once slid)
  has a wall, a wall on a tile border is built by exactly one tile, slide targets equal the next level's columns, synthetic meshes
  (flat, one column, chessboard, colour and slide-target merge rules), tiles are bit-identical when built twice in any order, reference tiles
  keep their bytes, a triangle bound per column, and four stand-in checks (ancestor maths with negative coordinates, finest resident wins,
  ring enumeration equals brute force, leading-edge holes always have a stand-in).
- `tools/jvm-tests/run_water.sh`: the distant land and water shaders carry the same clip/dither snippet and both discard on it before
  they shade.
- `tools/render-rig` (software WebGL2, the game's real shaders on the real tiles): the pictures above (`jobs/jobs_v15_standin.json`),
  mountains at several distances (`jobs_v15_mtn.json`, `jobs_v15_elev.json`), `runlod.py` + `pair.py` for before/after sheets.
- The whole project compiles against the android-34 stubs; generation is bit-identical to v14 (`tools/gen-check`).

## Limits, and what has not been verified

- **Nothing here has run on a phone or an emulator.** The GL code (`FarTerrainRenderer`, `ClipDither`, `WaterRenderer`) is checked by
  compiling it and by the software renderer running the same shaders on the same meshes; the Gradle/AGP build was not run here.
- The GPU cost of the new per-pixel tests (four comparisons for the clip, the dither branch) and of a quarter to a third more tiles on the
  test phone's GPU is **not measured**. The HUD's far line (tiles, triangles, `fill`) and the diagnostic log are where to look first.
- A stand-in is the bigger bricks of the same ground; next to the real neighbours the difference is visible on close inspection (see
  the picture), by design. The dither is a screen-space pattern, so a fade shows as fine noise for 450 ms, not as smooth alpha.
- A hole behind the player (tiles already unloaded) may have no stand-in and falls back to the old fog behaviour.
- The finest ring's own handover (level 0 against level 1) is a switch per tile, not a fade.
- Water of stand-in tiles is drawn the same way (clipped, same ring), but its seam against the voxel water is the old one.

## Where

`world/far/` (levels, rings, column field, mesher, slide, styler, planner `FarTerrain`, budget, stand-ins), `gl/FarTerrainRenderer.kt`,
`gl/ClipDither.kt`, `gl/Handover.kt`, `Shaders.FAR_VERTEX` / `FAR_FRAGMENT` / `WATER_FRAGMENT` / `CLIP_AND_DITHER`.
