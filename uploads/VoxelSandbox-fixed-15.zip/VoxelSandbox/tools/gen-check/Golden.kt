package harness

import com.voxelsandbox.game.world.BlockType
import com.voxelsandbox.game.world.Chunk
import com.voxelsandbox.game.world.ChunkPos
import com.voxelsandbox.game.world.SubChunk
import com.voxelsandbox.game.world.generation.Biome
import com.voxelsandbox.game.world.generation.CaveCarver
import com.voxelsandbox.game.world.generation.TerrainGenerator
import java.io.File
import java.nio.ByteBuffer
import java.security.MessageDigest
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.floor

/** Golden-hash harness (tools/gen-check): compiled together with whatever pure sources the
 *  project tree under test has (see run_golden.sh). Everything is hashed bit-exactly (raw double bits). */

val SEEDS = longArrayOf(
    0L, 1L, 12345L, 20261023L, -1L, 25214903917L, -8453913705129337253L, Long.MAX_VALUE, Long.MIN_VALUE
)

class Sink {
    private val md = MessageDigest.getInstance("SHA-256")
    private val buf = ByteBuffer.allocate(8)
    fun int(v: Int) { buf.clear(); buf.putInt(v); md.update(buf.array(), 0, 4) }
    fun long(v: Long) { buf.clear(); buf.putLong(v); md.update(buf.array(), 0, 8) }
    fun dbl(v: Double) = long(java.lang.Double.doubleToRawLongBits(v))
    fun bool(b: Boolean) = int(if (b) 1 else 0)
    fun bytes(b: ByteArray) = md.update(b)
    fun shorts(s: ShortArray) { for (v in s) { buf.clear(); buf.putShort(v); md.update(buf.array(), 0, 2) } }
    fun hex(n: Int = 32): String = md.digest().joinToString("") { "%02x".format(it) }.substring(0, n)
}

fun splitmix(st: LongArray): Long {
    st[0] += -7046029254386353131L
    var z = st[0]
    z = (z xor (z ushr 30)) * -4658895280553007687L
    z = (z xor (z ushr 27)) * -7723592293110705685L
    return z xor (z ushr 31)
}

class Site(val seed: Long, val label: String, val cx: Int, val cz: Int, val w: Int, val h: Int)

fun readSites(f: File): List<Site> = f.readLines().filter { it.isNotBlank() && !it.startsWith("#") }.map {
    val p = it.trim().split(Regex("\\s+"))
    Site(p[0].toLong(), p[1], p[2].toInt(), p[3].toInt(), p[4].toInt(), p[5].toInt())
}

/** (cx, cz) of every chunk of a seed's sites, in file order (duplicates kept). */
fun chunkList(sites: List<Site>, seed: Long): List<IntArray> {
    val out = ArrayList<IntArray>()
    for (s in sites) if (s.seed == seed) for (z in s.cz until s.cz + s.h) for (x in s.cx until s.cx + s.w) out += intArrayOf(x, z)
    return out
}

fun chunkDigest(c: Chunk): String {
    val s = Sink()
    s.bytes(c.serializeBlocks())
    s.shorts(c.heightMap)
    s.bool(c.caveMouth)
    var mask = 0
    for (i in c.subChunks.indices) if (!c.subChunks[i].isAllAir()) mask = mask or (1 shl i)
    s.int(mask)
    return s.hex(16)
}

// ------------------------------------------------------------------------------------------------
// discover: pick the chunk sites with the ORIGINAL generator and write them down (fixed afterwards)

fun discover(out: File) {
    val sb = StringBuilder("# seed label chunkX chunkZ width height   (chosen once, by the original v14 generator)\n")
    for (seed in SEEDS) {
        val gen = TerrainGenerator(seed)
        fun site(label: String, cx: Int, cz: Int, w: Int, h: Int) { sb.append("$seed $label $cx $cz $w $h\n") }
        site("origin", -3, -3, 7, 7)
        val sp = gen.findSpawn()
        site("spawn", Math.floorDiv(sp.x, 16) - 2, Math.floorDiv(sp.z, 16) - 2, 5, 5)
        site("neg", -37, -41, 4, 4)
        site("far++", 6250, 6250, 2, 2); site("far-+", -6251, 6250, 2, 2)
        site("far+-", 6250, -6251, 2, 2); site("far--", -6251, -6251, 2, 2)
        site("far1M+-", 62500, -62500, 1, 1); site("far1M-+", -62501, 62500, 1, 1)
        // biome samples: scan a lattice ring by ring (closest to the origin first), two sites per biome >= 600 blocks apart
        val found = HashMap<Biome, ArrayList<IntArray>>()
        for ((step, range) in listOf(64 to 3000, 192 to 14000)) {
            val pts = ArrayList<IntArray>()
            var x = -range; while (x <= range) { var z = -range; while (z <= range) { pts += intArrayOf(x, z); z += step }; x += step }
            pts.sortWith(compareBy({ maxOf(Math.abs(it[0]), Math.abs(it[1])) }, { it[0] }, { it[1] }))
            for (p in pts) {
                if (Biome.values().all { (found[it]?.size ?: 0) >= 2 }) break
                val b = gen.biomeAt(p[0], p[1])
                val l = found.getOrPut(b) { ArrayList() }
                if (l.size < 2 && l.none { Math.abs(it[0] - p[0]) < 600 && Math.abs(it[1] - p[1]) < 600 }) l += p
            }
        }
        for (b in Biome.values()) for ((i, p) in (found[b] ?: ArrayList()).withIndex())
            site("${b.name.lowercase()}$i", Math.floorDiv(p[0], 16) - 1, Math.floorDiv(p[1], 16) - 1, 3, 3)
        System.err.println("seed $seed: biomes found ${found.keys.size}/16 missing=${Biome.values().filter { found[it] == null }}")
    }
    out.writeText(sb.toString())
}

// ------------------------------------------------------------------------------------------------
// public-API lattice

fun positions(seed: Long): List<IntArray> {
    val list = ArrayList<IntArray>()
    var x = -2400; while (x <= 2400) { var z = -2400; while (z <= 2400) { list += intArrayOf(x, z); z += 301 }; x += 301 }
    for (i in 0 until 48) list += intArrayOf(i * 3 - 70, 40 - i * 5)
    for (i in 0 until 16) { list += intArrayOf(15 + 16 * i, 16 * i); list += intArrayOf(-1 - 16 * i, 31 + 16 * i) }
    val st = longArrayOf(seed xor 0x1234567L)
    repeat(100) { list += intArrayOf(Math.floorMod(splitmix(st), 400001L).toInt() - 200000, Math.floorMod(splitmix(st), 400001L).toInt() - 200000) }
    list += intArrayOf(100000, 100000); list += intArrayOf(-100000, -100000); list += intArrayOf(1000000, -1000000); list += intArrayOf(-3000000, 2000000)
    return list
}

fun apiDigests(seed: Long, gen: TerrainGenerator): Map<String, String> {
    val shape = gen.shape
    val climate = gen.climate
    val caves = CaveCarver(seed, shape)
    val sShape = Sink(); val sClimate = Sink(); val sTerrain = Sink(); val sCaves = Sink()
    val biomes = Biome.values()
    for (b in biomes) sTerrain.dbl(gen.treeDensity(b))
    val ce = DoubleArray(3)
    val slopes = doubleArrayOf(0.0, 0.5, 1.05, 1.2, 2.0)
    val hs = doubleArrayOf(0.0, 3.0, 64.0, 66.5, 80.0, 140.0, 190.0) // 0.0 / 3.0 are offsets from the ground (see below)
    for (p in positions(seed)) {
        val x = p[0]; val z = p[1]
        val wx = x.toDouble(); val wz = z.toDouble()
        // TerrainShape
        for (lod in 0..7) {
            sShape.dbl(shape.height(wx, wz, lod))
            ce[0] = 0.0; ce[1] = 0.0; ce[2] = 0.0
            sShape.dbl(shape.heightAndCoast(wx, wz, lod, ce, 2)); sShape.dbl(ce[2]); sShape.dbl(ce[0]); sShape.dbl(ce[1])
        }
        val coast = shape.coastElevation(wx, wz)
        sShape.dbl(coast)
        // Climate
        val t0 = climate.baseTemperature(wx, wz); val hum = climate.humidity(wx, wz)
        sClimate.dbl(t0); sClimate.dbl(hum); sClimate.dbl(climate.forest(wx, wz))
        val g = gen.surfaceHeight(x, z)
        for (be in doubleArrayOf(coast, -3.0, 0.0, 5.0, 20.0, 30.0)) {
            sClimate.dbl(climate.swampWeight(wx, wz, be)); sClimate.dbl(climate.swampWeight(wx, wz, be, hum, t0))
        }
        for (hOff in hs) {
            val h = if (hOff == 0.0 || hOff == 3.0) g + hOff else hOff
            for (sl in slopes) for (cc in doubleArrayOf(coast, 0.5, 3.0)) {
                val b = climate.biome(wx, wz, h, sl, cc)
                sClimate.int(b.ordinal)
                sClimate.int(climate.biome(wx, wz, h, sl, cc, t0, hum).ordinal)
                sClimate.bool(climate.slopeMatters(h, cc))
                sClimate.int(climate.surfaceFor(b, wx, wz, h, sl).ordinal)
            }
        }
        for (b in biomes) for (sl in doubleArrayOf(0.3, 1.0, 1.5)) for (h in doubleArrayOf(g.toDouble(), 85.0, 150.0))
            sClimate.int(climate.surfaceFor(b, wx, wz, h, sl).ordinal)
        for (d in doubleArrayOf(1.0, 3.0, 4.5, 6.0, 15.0)) for (cc in doubleArrayOf(coast, -3.0, 0.0, 1.2))
            sClimate.int(climate.waterBiome(wx, wz, d, cc).ordinal)
        // TerrainGenerator
        sTerrain.int(g); sTerrain.int(gen.biomeAt(x, z).ordinal); sTerrain.dbl(gen.forestFactor(x, z))
        val ff = gen.forestFactor(x, z)
        for (b in arrayOf(Biome.FOREST, Biome.PLAINS, Biome.DESERT, Biome.SWAMP)) sTerrain.dbl(gen.treeChance(b, ff))
        for (dz in -1..1) for (dx in -1..1) {
            val sp = gen.treeSpot(Math.floorDiv(x, 4) + dx, Math.floorDiv(z, 4) + dz)
            if (sp == null) sTerrain.int(-1) else { sTerrain.int(sp.x); sTerrain.int(sp.z); sTerrain.int(sp.ground); sTerrain.int(sp.species.ordinal); sTerrain.int(sp.th) }
        }
        // CaveCarver queries
        sCaves.bool(caves.nearMouth(wx, wz)); sCaves.bool(caves.caveMouthNear(Math.floorDiv(x, 16), Math.floorDiv(z, 16)))
    }
    val sp = gen.findSpawn()
    return linkedMapOf(
        "shape" to sShape.hex(), "climate" to sClimate.hex(), "terrain" to sTerrain.hex(), "caves" to sCaves.hex(),
        "spawn" to "${sp.x},${sp.z}"
    )
}

// ------------------------------------------------------------------------------------------------

class SeedResult(val seed: Long, val fields: LinkedHashMap<String, String>, val chunkHashes: LinkedHashMap<String, String>) {
    fun line(): String = "seed=$seed " + fields.entries.joinToString(" ") { "${it.key}=${it.value}" }
}

fun runSeed(seed: Long, sites: List<Site>, threads: Int, coverage: LongArray?): SeedResult {
    val gen = TerrainGenerator(seed)
    val list = chunkList(sites, seed)
    val sBlocks = Sink(); val sH = Sink(); val sM = Sink(); val sA = Sink()
    val per = LinkedHashMap<String, String>()
    var mouths = 0
    for (c in list) {
        val chunk = gen.generate(ChunkPos(c[0], c[1]))
        sBlocks.int(c[0]); sBlocks.int(c[1]); sBlocks.bytes(chunk.serializeBlocks())
        sH.shorts(chunk.heightMap); sM.bool(chunk.caveMouth)
        var mask = 0
        for (i in chunk.subChunks.indices) if (!chunk.subChunks[i].isAllAir()) mask = mask or (1 shl i)
        sA.int(mask)
        per["${c[0]},${c[1]}"] = chunkDigest(chunk)
        if (chunk.caveMouth) mouths++
        if (coverage != null) for (b in chunk.serializeBlocks()) coverage[b.toInt() and 31]++
    }
    val fields = LinkedHashMap<String, String>()
    fields["chunks"] = list.size.toString()
    fields["mouths"] = mouths.toString()
    fields["blocks"] = sBlocks.hex(); fields["hmap"] = sH.hex(); fields["mouth"] = sM.hex(); fields["alloc"] = sA.hex()
    fields.putAll(apiDigests(seed, gen))
    // thread-safety check: a fresh generator, every chunk of the seed in shuffled order on several threads
    if (threads > 1) {
        val g2 = TerrainGenerator(seed)
        val uniq = list.distinctBy { it[0] to it[1] }.toMutableList()
        val st = longArrayOf(seed + 99)
        for (i in uniq.size - 1 downTo 1) { val j = Math.floorMod(splitmix(st), (i + 1).toLong()).toInt(); val t = uniq[i]; uniq[i] = uniq[j]; uniq[j] = t }
        val next = AtomicInteger(); val bad = AtomicInteger()
        val ts = (0 until threads).map {
            Thread {
                while (true) {
                    val i = next.getAndIncrement(); if (i >= uniq.size) break
                    val c = uniq[i]
                    val d = chunkDigest(g2.generate(ChunkPos(c[0], c[1])))
                    if (d != per["${c[0]},${c[1]}"]) bad.incrementAndGet()
                    // tree cells are shared state in some designs: hit them concurrently as well
                    g2.treeSpot(c[0] * 4, c[1] * 4)
                }
            }.also { it.start() }
        }
        ts.forEach { it.join() }
        fields["parallel"] = if (bad.get() == 0) "ok" else "MISMATCH(${bad.get()})"
    }
    return SeedResult(seed, fields, per)
}

fun main(args: Array<String>) {
    when (args[0]) {
        "discover" -> discover(File(args[1]))
        "golden" -> {
            // golden <sitesFile> <write|check> <goldenFile> <chunksFile> <threads> [onlySeedIndexes]
            val sites = readSites(File(args[1]))
            val write = args[2] == "write"
            val gf = File(args[3]); val cf = File(args[4]); val threads = args[5].toInt()
            val only = if (args.size > 6) args[6].split(",").map { it.toInt() }.toSet() else null
            val golden = HashMap<Long, Map<String, String>>()
            if (!write) for (l in gf.readLines()) if (l.startsWith("seed=")) {
                val kv = l.split(" ").associate { it.substringBefore('=') to it.substringAfter('=') }
                golden[kv["seed"]!!.toLong()] = kv
            }
            val goldChunks = HashMap<String, String>()
            if (!write && cf.exists()) for (l in cf.readLines()) { val p = l.split(" "); if (p.size == 4) goldChunks["${p[0]} ${p[1]},${p[2]}"] = p[3] }
            val outLines = ArrayList<String>(); val outChunks = ArrayList<String>()
            val cover = LongArray(32)
            var pass = 0; var total = 0
            for ((si, seed) in SEEDS.withIndex()) {
                if (only != null && si !in only) continue
                total++
                val t0 = System.nanoTime()
                val r = runSeed(seed, sites, if (write) 1 else threads, if (write) cover else null)
                val secs = (System.nanoTime() - t0) / 1e9
                if (write) {
                    outLines += r.line()
                    for ((k, v) in r.chunkHashes) outChunks += "$seed ${k.replace(',', ' ')} $v"
                    println("wrote seed=$seed chunks=${r.fields["chunks"]} (%.1fs)".format(secs))
                    pass++
                } else {
                    val g = golden[seed]
                    if (g == null) { println("FAIL seed=$seed (no golden entry)"); continue }
                    val diffs = ArrayList<String>()
                    for ((k, v) in r.fields) if (k != "parallel" && g[k] != v) diffs.add(k)
                    if (r.fields["parallel"]?.startsWith("MISMATCH") == true) diffs.add("parallel:" + r.fields["parallel"])
                    if (diffs.isEmpty()) { pass++; println("PASS seed=$seed chunks=${r.fields["chunks"]} blocks=${r.fields["blocks"]} (%.1fs)".format(secs)) }
                    else {
                        println("FAIL seed=$seed differs in: ${diffs.joinToString(", ")} (%.1fs)".format(secs))
                        var shown = 0
                        for ((k, v) in r.chunkHashes) {
                            val want = goldChunks["$seed $k"]
                            if (want != null && want != v && shown++ < 5) println("    chunk $k differs (got $v want $want)")
                        }
                    }
                }
            }
            if (write) {
                gf.writeText("# golden hashes written by the ORIGINAL v14 generator; fields: blocks=serializeBlocks, hmap=heightMap, mouth=caveMouth, alloc=non-empty sub-chunk mask, shape/climate/terrain/caves=public query lattices\n" + outLines.joinToString("\n") + "\n")
                cf.writeText(outChunks.joinToString("\n") + "\n")
                val names = BlockType.values()
                println("coverage (blocks over all golden chunks): " + names.joinToString(" ") { "${it.name}=${cover[it.id.toInt() and 31]}" })
            } else {
                println(if (pass == total) "GOLDEN: PASS ($pass/$total seeds)" else "GOLDEN: FAIL ($pass/$total seeds passed)")
                System.exit(if (pass == total) 0 else 1)
            }
        }
    }
}
