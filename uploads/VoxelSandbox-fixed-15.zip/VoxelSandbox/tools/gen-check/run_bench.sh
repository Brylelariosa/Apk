#!/bin/bash
# usage: ./run_bench.sh chunks <sites.txt> <rounds> [seedIndexes]   every golden chunk, one thread, scan order
#        ./run_bench.sh stream <rounds> <threads> <radius>          the game's order (nearest first, from a shared queue)
#        ./run_bench.sh far <rounds>                                the height sampler the distant terrain uses
# Prints per-round time, chunks/s and bytes allocated per chunk. This machine-dependent number is only meaningful next to the
# same command run on the tree it is compared with (PROJECT_ROOT=/path/to/other/tree ./run_bench.sh ...): run them alternately,
# the spread from one run to the next is easily +-10 %. env: JAVA_EXTRA (e.g. "-Xmn8m -Xlog:gc:file=gc.log" to count collections).
. "$(dirname "$0")/common.sh"
build_driver "$HERE/Bench.kt" bench/BenchKt.class
exec java -Xmx1500m -XX:+UseSerialGC ${JAVA_EXTRA} -cp "$OUT:$STDLIB:$ANDROID_JAR" bench.BenchKt "$@"
