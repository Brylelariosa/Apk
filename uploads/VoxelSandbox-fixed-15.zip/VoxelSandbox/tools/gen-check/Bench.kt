package bench

import com.sun.management.ThreadMXBean
import com.voxelsandbox.game.world.ChunkPos
import com.voxelsandbox.game.world.generation.TerrainGenerator
import java.io.File
import java.lang.management.ManagementFactory

/**
 * Chunk-generation benchmark, compiled together with the generator sources of the tree under test.
 *   Bench chunks <sites.txt> <rounds> [seedIndexes]   generate every golden chunk of the chosen seeds, `rounds` times;
 *                                                    prints per-round ms, chunks/s (median, best) and bytes allocated per chunk
 *   Bench far <rounds>                               the height/coast sampler the distant terrain uses (lod 0..3 lattices)
 */
class Site(val seed: Long, val cx: Int, val cz: Int, val w: Int, val h: Int)

fun readSites(f: File): List<Site> = f.readLines().filter { it.isNotBlank() && !it.startsWith("#") }.map {
    val p = it.trim().split(Regex("\\s+"))
    Site(p[0].toLong(), p[2].toInt(), p[3].toInt(), p[4].toInt(), p[5].toInt())
}

fun main(args: Array<String>) {
    val mx = ManagementFactory.getThreadMXBean() as ThreadMXBean
    val tid = Thread.currentThread().id
    when (args[0]) {
        "chunks" -> {
            val sites = readSites(File(args[1]))
            val rounds = args[2].toInt()
            val only = if (args.size > 3) args[3].split(",").map { it.toInt() } else null
            val seeds = sites.map { it.seed }.distinct().filterIndexed { i, _ -> only == null || i in only }
            val gens = seeds.associateWith { TerrainGenerator(it) }
            val jobs = ArrayList<Triple<Long, Int, Int>>()
            for (s in sites) if (s.seed in gens) for (z in s.cz until s.cz + s.h) for (x in s.cx until s.cx + s.w) jobs += Triple(s.seed, x, z)
            val times = ArrayList<Double>(); var allocPer = 0.0
            var sink = 0L
            for (r in 0 until rounds) {
                val a0 = mx.getThreadAllocatedBytes(tid); val t0 = System.nanoTime()
                for ((seed, x, z) in jobs) sink += gens[seed]!!.generate(ChunkPos(x, z)).heightMap[0].toLong()
                val t1 = System.nanoTime(); val a1 = mx.getThreadAllocatedBytes(tid)
                times += (t1 - t0) / 1e6; allocPer = (a1 - a0).toDouble() / jobs.size
                println(String.format("round %2d: %8.1f ms  %7.1f chunks/s  %9.0f bytes/chunk", r, (t1 - t0) / 1e6, jobs.size / ((t1 - t0) / 1e9), allocPer))
            }
            val steady = times.drop(times.size / 2).sorted()
            val med = steady[steady.size / 2]; val best = steady.first()
            println(String.format("RESULT chunks=%d  steady median %.1f ms (%.1f chunks/s, %.3f ms/chunk)  best %.1f ms (%.1f chunks/s)  alloc %.0f bytes/chunk  [%d]", jobs.size, med, jobs.size / (med / 1e3), med / jobs.size, best, jobs.size / (best / 1e3), allocPer, sink and 1))
        }
        "stream" -> {
            // The game's order: chunks nearest the player first (a spiral), taken one by one from a shared queue by N workers.
            val rounds = args[1].toInt(); val threads = args[2].toInt(); val radius = args[3].toInt()
            val seeds = longArrayOf(12345L, 0L, 20261023L)
            val centres = arrayOf(intArrayOf(20, 14), intArrayOf(-200, 300), intArrayOf(900, -700)) // chunk coordinates
            val order = ArrayList<IntArray>()
            for (dz in -radius..radius) for (dx in -radius..radius) if (dx * dx + dz * dz <= radius * radius) order += intArrayOf(dx, dz)
            order.sortWith(compareBy({ it[0] * it[0] + it[1] * it[1] }, { Math.atan2(it[1].toDouble(), it[0].toDouble()) }))
            val times = ArrayList<Double>(); val cpus = ArrayList<Double>(); var allocPer = 0.0
            for (r in 0 until rounds) {
                var chunks = 0; var cpuNs = 0L; var alloc = 0L; var wall = 0L
                for ((si, seed) in seeds.withIndex()) {
                    val gen = TerrainGenerator(seed)
                    val cx0 = centres[si][0]; val cz0 = centres[si][1]
                    val next = java.util.concurrent.atomic.AtomicInteger(0)
                    val cpu = java.util.concurrent.atomic.AtomicLong(0); val al = java.util.concurrent.atomic.AtomicLong(0)
                    val t0 = System.nanoTime()
                    val ws = (0 until threads).map {
                        Thread {
                            val id = Thread.currentThread().id
                            val c0 = mx.getThreadCpuTime(id); val a0 = mx.getThreadAllocatedBytes(id)
                            var sink = 0
                            while (true) {
                                val i = next.getAndIncrement(); if (i >= order.size) break
                                sink += gen.generate(ChunkPos(cx0 + order[i][0], cz0 + order[i][1])).heightMap[0].toInt()
                            }
                            cpu.addAndGet(mx.getThreadCpuTime(id) - c0); al.addAndGet(mx.getThreadAllocatedBytes(id) - a0)
                            if (sink == 42) println()
                        }.also { it.start() }
                    }
                    ws.forEach { it.join() }
                    wall += System.nanoTime() - t0; cpuNs += cpu.get(); alloc += al.get(); chunks += order.size
                }
                times += wall / 1e6; cpus += cpuNs / 1e6; allocPer = alloc.toDouble() / chunks
                println(String.format("round %2d: wall %7.1f ms  cpu %7.1f ms  %7.1f chunks/s  cpu/chunk %.3f ms  %7.0f bytes/chunk", r, wall / 1e6, cpuNs / 1e6, chunks / (wall / 1e9), cpuNs / 1e6 / chunks, allocPer))
            }
            val half = times.size / 2
            val w = times.drop(half).sorted(); val c = cpus.drop(half).sorted()
            val n = order.size * seeds.size
            println(String.format("RESULT stream threads=%d chunks=%d  steady median wall %.1f ms (%.1f chunks/s)  cpu %.1f ms (%.3f ms/chunk)  alloc %.0f bytes/chunk", threads, n, w[w.size / 2], n / (w[w.size / 2] / 1e3), c[c.size / 2], c[c.size / 2] / n, allocPer))
        }
        "far" -> {
            val rounds = args[1].toInt()
            val gen = TerrainGenerator(12345L)
            val shape = gen.shape
            val coast = DoubleArray(65 * 65)
            var sink = 0.0
            val times = ArrayList<Double>(); var allocPer = 0.0
            for (r in 0 until rounds) {
                val a0 = mx.getThreadAllocatedBytes(tid); val t0 = System.nanoTime()
                var n = 0
                for (lod in 0..3) {
                    val step = 1 shl (lod + 1)
                    for (tile in 0 until 12) {
                        val bx = -5000.0 + tile * 977.0; val bz = 3000.0 - tile * 613.0
                        for (j in 0 until 65) for (i in 0 until 65) { sink += shape.heightAndCoast(bx + i * step, bz + j * step, lod, coast, j * 65 + i); n++ }
                    }
                }
                val t1 = System.nanoTime(); val a1 = mx.getThreadAllocatedBytes(tid)
                times += (t1 - t0) / 1e6; allocPer = (a1 - a0).toDouble() / n
                println(String.format("round %2d: %8.1f ms  %9.0f samples/s  %6.1f bytes/sample", r, (t1 - t0) / 1e6, n / ((t1 - t0) / 1e9), allocPer))
            }
            val steady = times.drop(times.size / 2).sorted()
            println(String.format("RESULT far samples: steady median %.1f ms  best %.1f ms  alloc %.1f bytes/sample [%f]", steady[steady.size / 2], steady.first(), allocPer, sink))
        }
    }
}
