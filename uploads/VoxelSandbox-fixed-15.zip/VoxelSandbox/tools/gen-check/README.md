# Generator check and benchmark

Plain JVM programs (compiled with `kotlinc` against the android-34 stubs, like `../jvm-tests`) that compile the **pure generator sources of the project
they sit in** (`world/generation/*`, `Chunk`, `SubChunk`, `Block`, ...) together with a driver. Nothing here touches a phone or Gradle.

    export KOTLINC=/path/to/kotlinc ANDROID_JAR=/path/to/android-34/android.jar
    export STDLIB=/path/to/kotlin-stdlib.jar        # only if KOTLINC is a wrapper script
    ./run_golden.sh                                 # PASS (9/9 seeds) or FAIL with the first chunks that differ
    ./run_bench.sh stream 12 2 22                   # the game's order, 2 threads: CPU and garbage per chunk

- `run_golden.sh` (`Golden.kt`) — the generator must still make **exactly** the worlds v14 made. 9 seeds x 396 chunks (`golden-sites.txt`: the origin,
  the spawn point, negative and very distant coordinates, two places of every biome) are hashed bit for bit (blocks, height maps, cave mouths, which
  sub-chunks exist, the public height / climate / biome / cave query lattices, the spawn point) and compared with `golden-v14.txt` (written by the
  **original v14 generator**); `golden-v14.chunks.txt` has one hash per chunk to name the first one that differs. Every seed is also generated again
  on several threads in shuffled order (`THREADS=3`, `1` turns it off) and must give the same hashes. `./run_golden.sh write` regenerates the golden
  files: do that only when a change of the generated worlds is *intended*, and say so in the changelog.
- `run_bench.sh` (`Bench.kt`) — `chunks <sites> <rounds>` (every golden chunk, one thread, scan order), `stream <rounds> <threads> <radius>` (the
  game's order: nearest chunk first from a shared queue), `far <rounds>` (the height sampler of the distant terrain). It prints time, chunks a second
  and the bytes allocated per chunk (exact, from the JVM). Times on a shared 2-core machine vary by +-10 % between runs: compare two trees with
  `PROJECT_ROOT=/other/tree ./run_bench.sh ...`, alternating the runs, and trust the allocation number more than the clock.
  `JAVA_EXTRA="-Xmn8m -Xlog:gc:file=gc.log"` counts the collections of a small young generation.

Compiled drivers are cached under `$TMPDIR/voxelsandbox-gen-check/`, keyed by a hash of the sources, so an unchanged tree is not compiled twice.
The numbers are those of a desktop JVM; see `../../docs/terrain-generation.md` for what they showed and what they cannot say about a phone.
