#!/bin/bash
# usage: ./run_golden.sh [check|write|discover]
#   check (default): generate 9 seeds x 396 chunks (golden-sites.txt) and compare, bit for bit, against the hashes the ORIGINAL
#     v14 generator produced (golden-v14.txt: chunk blocks, height maps, cave mouths, which sub-chunks exist, and the public
#     height / climate / biome / cave query lattices; golden-v14.chunks.txt: one hash per chunk, to name the first chunk that
#     differs). Every seed is also generated again on several threads in shuffled order and must give the same hashes.
#   write: regenerate the golden files (only when a change of the generated worlds is intended!).
#   env: THREADS=3 (parallel consistency pass; 1 = off), SEEDS=0,3 (only those seed indexes), plus KOTLINC / ANDROID_JAR / STDLIB.
. "$(dirname "$0")/common.sh"
MODE=${1:-check}
build_driver "$HERE/Golden.kt" harness/GoldenKt.class
CP="$OUT:$STDLIB:$ANDROID_JAR"
if [ "$MODE" = discover ]; then
  exec java -Xmx1500m -XX:+UseSerialGC -cp "$CP" harness.GoldenKt discover "$HERE/golden-sites.txt"
fi
exec java -Xmx1500m -XX:+UseSerialGC -cp "$CP" harness.GoldenKt golden "$HERE/golden-sites.txt" "$MODE" "$HERE/golden-v14.txt" "$HERE/golden-v14.chunks.txt" "${THREADS:-3}" $SEEDS
