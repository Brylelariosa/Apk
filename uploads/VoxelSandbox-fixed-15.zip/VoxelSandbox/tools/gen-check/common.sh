# Shared by run_golden.sh and run_bench.sh: compiles the pure generator sources of THIS project tree together with a
# driver, once per distinct set of sources (the result is cached under $TMPDIR, keyed by a hash of the sources).
#   env: KOTLINC (default kotlinc), ANDROID_JAR (android-34 stubs, required), STDLIB (kotlin-stdlib.jar)
HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
ROOT=${PROJECT_ROOT:-$(cd "$HERE/../.." && pwd)}
G=$ROOT/app/src/main/java/com/voxelsandbox/game
KOTLINC=${KOTLINC:-kotlinc}
: "${ANDROID_JAR:?set ANDROID_JAR to an android.jar (API 34 stubs)}"
STDLIB=${STDLIB:-$(dirname "$(readlink -f "$(which "$KOTLINC")")")/../lib/kotlin-stdlib.jar}

# build_driver <Driver.kt> <main class file relative to the output dir>  ->  sets OUT
build_driver() {
  local driver=$1 marker=$2
  local files="$G/util/MathUtils.kt"
  for f in Block AtlasCell Fluid Chunk ChunkPos SubChunk WorldConfig; do [ -f "$G/world/$f.kt" ] && files="$files $G/world/$f.kt"; done
  files="$files $(ls "$G"/world/generation/*.kt | tr '\n' ' ')"
  local key
  key=$(cat $files "$driver" | sha256sum | cut -c1-16)
  OUT=${TMPDIR:-/tmp}/voxelsandbox-gen-check/$(basename "$driver" .kt)-$key
  if [ ! -f "$OUT/.ok" ]; then
    rm -rf "$OUT"; mkdir -p "$OUT"
    "$KOTLINC" -jvm-target 17 -nowarn -cp "$ANDROID_JAR:$STDLIB" -d "$OUT" $files "$driver" 2>&1 | grep -v "^warning" | head -30
    [ -f "$OUT/$marker" ] && touch "$OUT/.ok" || { echo "COMPILE FAILED"; exit 2; }
  fi
}
