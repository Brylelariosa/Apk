import numpy as np, sys
def series(d,n=13):
    return [np.fromfile(f'{d}/E_{i:02d}.rgba',dtype=np.uint8).reshape(640,1280,4)[:,:,:3].astype(int) for i in range(n)]
bands=[(280,300,'horizon'),(300,340,'far'),(340,400,'mid'),(400,480,'near-mid'),(480,560,'near'),(560,640,'closest')]
for label,d in [('v14','out/flick_v14'),('new','out/flick_new')]:
    S=series(d)
    print(label)
    for (y0,y1,nm) in bands:
        ch=[];mad=[];mx=[]
        for i in range(len(S)-1):
            dd=np.abs(S[i][y0:y1]-S[i+1][y0:y1]).sum(2)
            ch.append((dd>0).mean()*100); mad.append(dd.mean()/3); mx.append(dd.max()/3)
        print('  %-9s rows %3d-%3d: pixels changing per 1/6 s step %5.1f%%   mean abs change %.2f levels   worst pixel %.0f levels'%(nm,y0,y1,np.mean(ch),np.mean(mad),np.max(mx)))
