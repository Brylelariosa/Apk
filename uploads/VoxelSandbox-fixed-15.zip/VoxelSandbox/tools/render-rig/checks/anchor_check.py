import numpy as np, sys
d=sys.argv[1]
PAL=[(0x3D,0x6C,0xC3),(0x45,0x79,0xD0),(0x50,0x88,0xDB),(0x6B,0xA2,0xE9)]
def load(n): return np.fromfile(f'{d}/{n}.rgba',dtype=np.uint8).reshape(640,1280,4)[:,:,:3].astype(int)
def water_mask(im):
    m=np.zeros(im.shape[:2],bool)
    for p in PAL: m|=(im[:,:,0]==p[0])&(im[:,:,1]==p[1])&(im[:,:,2]==p[2])
    return m
A=load('p_0'); MA=water_mask(A)
ok=True
def cmp(name,dx,dz):
    global ok
    B=load(name); MB=water_mask(B)
    sx,sy=dx*32,dz*32
    h,w=640,1280
    ax0,ax1=max(0,sx),min(w,w+sx); ay0,ay1=max(0,sy),min(h,h+sy)
    Aa=A[ay0:ay1,ax0:ax1]; Bb=B[ay0-sy:ay1-sy,ax0-sx:ax1-sx]
    m=MA[ay0:ay1,ax0:ax1]&MB[ay0-sy:ay1-sy,ax0-sx:ax1-sx]
    dd=np.abs(Aa-Bb).sum(2)[m]
    same=(dd==0).mean()*100
    print('%-9s camera moved (%+d,%+d) blocks: %d water pixels compared, identical %.4f%%, max diff %d'%(name,dx,dz,dd.size,same,dd.max()))
    if same<100: ok=False
for n,dx,dz in [('p_x1',1,0),('p_x5',5,0),('p_x8',8,0),('p_z3',0,3),('p_xm13z7',-13,7)]: cmp(n,dx,dz)
print('RESULT:', 'world-anchored (every water pixel identical)' if ok else 'NOT identical')
