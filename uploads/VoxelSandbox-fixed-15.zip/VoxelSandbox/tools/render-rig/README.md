# Software-render rig (how the pictures in the notes were made)

The game has no way to run its GL code off a phone, so the shaders are checked in a software WebGL2 renderer (headless Chromium /
SwiftShader) on the game's *real* meshes, atlas and shader sources:

- `src/Dump.kt` meshes a scene with the real `ChunkMesher` and writes the meshes, the atlas (all mips), the biome colour map and
  the shader sources; scenes: `flat:SAND|GRASS|DIRT|STONE`, `terraces`, `world:<seed>:<chunkX>:<chunkZ>:<radiusInChunks>`.
- `src/DumpFar.kt` builds the real distant-terrain tiles (`FarTerrain.buildTile`, by reflection) of a square of the world, prints what they
  weigh and how long they took (`stats` as the last argument: only that), and writes them with the real far shaders.
  Works on this tree and on the v14 tree (that is how the before/after numbers were taken).
- `src/DumpWater.kt` writes the game's water shaders, the 40 wave frames and the tone texture (what `WaterTexture` uploads); `src/DumpWaterV14.kt`
  does the same on the v14 tree (shaders and the old 16 x 16 tile) for before/after. `src/DumpFarWater.kt` builds the distant water of a square of
  the world (`FarTerrain.buildWaterMesh`) with the real far-water shader.
- `jobs/` has the camera lists the water pictures and numbers came from (`jobs_water_anchor*.json` / `jobs_anchor_v14*.json`: camera moved by whole
  blocks; `jobs_flicker.json`: 13 frames 1/6 s apart; `jobs_dist.json`, `jobs_seam.json`: near / distant water hand-over; `jobs_anim.json`: the animation
  contact sheet). `checks/anchor_check.py` (is every water pixel identical after the camera moved?) and `checks/flicker_water.py` (how much changes per
  step, by distance band) read the frames `render.js` wrote. A job's `waterDebug: "pattern"` draws the raw wave colour instead of the finished water,
  which is how the anchoring was compared without the view-dependent fresnel and fog.
- `render.js` + `page.js` draw a scene from the cameras of a jobs file (`noSolid` / `noFar` draw only one of the two meshes).
  `topng.py` turns the raw frames into PNGs.

- **Distant terrain, level by level** (`src/DumpFarLod.kt`, `lod.js` + `lod_page.js`, `runlod.py`, `pair.py`, `jobs/jobs_v15_*.json`): `DumpFarLod` builds the real
  tiles of every level that touch its ring around an eye position (the tiles the renderer would draw, with each level's ring and slide parameters) and writes
  them with the real far shaders; `lod.js` draws them with the game's ring / slide / clip / dither logic, one frame per entry of a jobs file's `frames`
  (`drop`: tiles that are missing, `standins: false`: do not fill them, `fade`: tiles at a given fade share, `levels`, `debug: "level"`).
  `DumpFarLod` prints, per level, the tiles, triangles and build time, and the total (that is how the v14 / v15 geometry table in `docs/far-terrain.md`
  was made: build the class trees of both projects with `build_far.sh <project> <dir> src/DumpFarLod.kt`, run `java -cp <dir>:<kotlin-stdlib.jar> rig.DumpFarLodKt
  <outDir> <seed> <eyeX> <eyeZ> <radius> 1,2,3,4,5,6,7`). `./runlod.py <classes dir> jobs/jobs_v15_standin.json` renders the stand-in / fade pictures
  (`out/standin_<dir>/*.rgba`, then `topng.py`); `pair.py` stacks two such frames (before / after) with labels.

The scripts need `kotlinc`, an android.jar (API 34; `KOTLINC`, `ANDROID_JAR`, `STDLIB` in the environment), node + playwright with Chromium (some of the older
scripts still carry the paths of the machine they were written on, `/home/claude/...`). They are here so the numbers and pictures in `docs/` and the changelog can be reproduced, not as part of the app.
A software renderer says nothing about the speed of a phone's GPU.
