import sys, numpy as np
from PIL import Image
# usage: topng.py in.rgba W H out.png [scale]
a = np.fromfile(sys.argv[1], dtype=np.uint8).reshape(int(sys.argv[3]), int(sys.argv[2]), 4)[:, :, :3]
im = Image.fromarray(a, 'RGB')
if len(sys.argv) > 5: im = im.resize((im.width * int(sys.argv[5]), im.height * int(sys.argv[5])), Image.NEAREST)
im.save(sys.argv[4])
