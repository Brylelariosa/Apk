import sys, numpy as np
from PIL import Image, ImageDraw
# usage: pair.py <dirA> <dirB> <name> <W> <H> <out.png> [labelA labelB]
a, b, name, W, H, out = sys.argv[1], sys.argv[2], sys.argv[3], int(sys.argv[4]), int(sys.argv[5]), sys.argv[6]
la = sys.argv[7] if len(sys.argv) > 7 else 'A'; lb = sys.argv[8] if len(sys.argv) > 8 else 'B'
ims = []
for d, l in ((a, la), (b, lb)):
    arr = np.fromfile(f'{d}/{name}.rgba', dtype=np.uint8).reshape(H, W, 4)[:, :, :3]
    im = Image.fromarray(arr, 'RGB'); dr = ImageDraw.Draw(im); dr.rectangle([0, 0, 8 + 7 * len(l), 14], fill=(0, 0, 0)); dr.text((4, 2), l, fill=(255, 255, 255)); ims.append(im)
sheet = Image.new('RGB', (W, H * 2 + 4), (255, 0, 255)); sheet.paste(ims[0], (0, 0)); sheet.paste(ims[1], (0, H + 4)); sheet.save(out)
