#!/usr/bin/env python3
# usage: runlod.py <classes dir> <jobs.json> [only-name-substring]
#   <classes dir>: the game's far-terrain classes plus the dump tool, built with  build_far.sh <project> <classes dir> src/DumpFarLod.kt
#   (build the v14 tree and this one into two dirs to get before/after pictures; pair.py puts two frames above each other).
#   env: STDLIB (kotlin-stdlib.jar)
# jobs.json: {"width":1280,"height":640,"seed":12345,"radius":8000,"hole":192,"levels":"1,2,3,4,5,6,7","views":[{"name","eye":[x,y,z],"yaw","pitch","fov","fog":[a,b],"extra":{...}}]}
# For each view, the real far tiles of the rings around the view's eye are built by the given tree's classes and rendered.
import json, subprocess, sys, os
tree = sys.argv[1]; jobs = json.load(open(sys.argv[2])); only = sys.argv[3] if len(sys.argv) > 3 else None
STD = os.environ.get('STDLIB', 'kotlin-stdlib.jar')
cls = os.path.abspath(tree)
here = os.path.dirname(os.path.abspath(__file__)); os.chdir(here)
tag = jobs.get('tag', 'lodv')
tree = os.path.basename(os.path.normpath(tree))
outdir = f'out/{tag}_{tree}'; os.makedirs(outdir, exist_ok=True)
for v in jobs['views']:
    if only and only not in v['name']: continue
    scene = f'scenes/{tag}_{tree}_{v["name"]}'; os.makedirs(scene, exist_ok=True)
    ex, ey, ez = v['eye']
    r = subprocess.run(['java', '-Xmx2g', '-cp', f'{cls}:{STD}', 'rig.DumpFarLodKt', scene, str(jobs.get('seed', 12345)), str(ex), str(ez), str(v.get('radius', jobs.get('radius', 8000))), jobs.get('levels', '1,2,3,4,5,6,7')] + (['fine'] if jobs.get('fine') else []), capture_output=True, text=True)
    if r.returncode != 0: print(r.stderr[-2000:]); sys.exit(1)
    print(v['name'], [l for l in r.stdout.splitlines() if l.startswith('total')][0])
    frames = []
    for fr in v['frames']:
        d = dict(eye=v['eye'], yaw=v['yaw'], pitch=v['pitch'], fov=v.get('fov', 70), far=v.get('far', 30000), hole=jobs.get('hole', 192), fogColor=[0.62, 0.78, 0.96]); d.update(fr); d['name'] = f'{v["name"]}_{fr["name"]}'; frames.append(d)
    jf = f'{scene}/job.json'; json.dump(dict(width=jobs['width'], height=jobs['height'], frames=frames), open(jf, 'w'))
    r = subprocess.run(['node', 'lod.js', scene, jf, outdir], capture_output=True, text=True)
    if r.returncode != 0 or 'FAILED' in r.stdout: print(r.stdout[-2000:], r.stderr[-2000:]); sys.exit(1)
    subprocess.run(['rm', '-f', f'{scene}/far.vtx', f'{scene}/far.idx'])  # large; regenerated on demand
