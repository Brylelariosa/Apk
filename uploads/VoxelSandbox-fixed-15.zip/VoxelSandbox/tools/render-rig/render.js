// usage: node render.js <sceneDir> <jobs.json> <outDir>
// jobs.json: {"width":1280,"height":576,"frames":[{"name":"a","eye":[x,y,z],"yaw":0,"pitch":-0.2,"ss":1,"fog":[1e9,2e9]}]}
const { chromium } = require('playwright'); const fs = require('fs'), path = require('path');
(async () => {
  const [sceneDir, jobsFile, outDir] = process.argv.slice(2);
  const jobs = JSON.parse(fs.readFileSync(jobsFile)); fs.mkdirSync(outDir, { recursive: true });
  const shaderDir = process.env.SHADER_DIR || sceneDir; const rd = (n, enc) => fs.readFileSync(path.join(n.endsWith('.glsl') ? shaderDir : sceneDir, n), enc);
  const b64 = n => rd(n).toString('base64');
  const meta = JSON.parse(rd('meta.json', 'utf8'));
  const cfg = { waterDebug: jobs.waterDebug || null, aniso: jobs.aniso || 1, width: jobs.width, height: jobs.height, meta, vs: rd('vs.glsl', 'utf8'), fsOpaque: rd('fs_opaque.glsl', 'utf8'), fsCutout: rd('fs_cutout.glsl', 'utf8'),
    atlas: b64('atlas.bin'), biome: fs.existsSync(path.join(sceneDir,'biome.bin')) ? b64('biome.bin') : null, tint: fs.existsSync(path.join(sceneDir,'tint.bin')) ? b64('tint.bin') : null, tiles: fs.existsSync(path.join(sceneDir,'tiles.bin')) ? b64('tiles.bin') : null, farVtx: fs.existsSync(path.join(sceneDir,'far.vtx')) ? b64('far.vtx') : null, farIdx: fs.existsSync(path.join(sceneDir,'far.idx')) ? b64('far.idx') : null, anisoOn: jobs.aniso || 1, solidVtx: b64('solid.vtx'), solidIdx: b64('solid.idx'), waterVtx: b64('water.vtx'), waterIdx: b64('water.idx') };
  if (fs.existsSync(path.join(sceneDir, 'farwater.vtx'))) { cfg.farWaterVtx = b64('farwater.vtx'); cfg.farWaterIdx = b64('farwater.idx'); cfg.farWaterJson = rd('farwater.json', 'utf8'); }
  if (fs.existsSync(path.join(sceneDir, 'water_tile.bin'))) cfg.waterTile = b64('water_tile.bin');
  if (fs.existsSync(path.join(sceneDir, 'water_wave.bin'))) { cfg.waveBin = b64('water_wave.bin'); cfg.toneBin = b64('water_tone.bin'); cfg.waterMeta = JSON.parse(rd('water_meta.json', 'utf8')); }
  for (const k of ['vsWater:vs_water.glsl', 'fsWater:fs_water.glsl', 'vsFar:vs_far.glsl', 'fsFar:fs_far.glsl']) { const [a, b] = k.split(':'); if (fs.existsSync(path.join(shaderDir, b))) cfg[a] = rd(b, 'utf8'); }
  const browser = await chromium.launch({ args: ['--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--enable-webgl'] });
  const page = await browser.newPage(); page.on('console', m => console.log('[page]', m.text())); page.on('pageerror', e => console.log('[pageerror]', e.message));
  await page.setContent('<html><body style="margin:0"></body></html>');
  await page.addScriptTag({ path: path.join(__dirname, 'page.js') });
  if (fs.existsSync(path.join(sceneDir, 'extra.js'))) await page.addScriptTag({ path: path.join(sceneDir, 'extra.js') });
  let info;
  try { info = await page.evaluate(c => window.rigSetup(c), cfg); } catch (e) { console.log('SETUP FAILED:', e.message.split('\n').slice(0, 12).join('\n')); await browser.close(); process.exit(3); }
  console.log('GL:', info);
  const t0 = Date.now();
  for (const f of jobs.frames) {
    const s = await page.evaluate(([f, W, H]) => window.rigRender(f, W, H), [f, jobs.width, jobs.height]);
    fs.writeFileSync(path.join(outDir, f.name + '.rgba'), Buffer.from(s, 'base64'));
  }
  console.log('frames', jobs.frames.length, 'in', ((Date.now() - t0) / 1000).toFixed(1), 's');
  await browser.close();
})();
