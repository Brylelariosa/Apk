(function () {
  const b64 = s => { const bin = atob(s); const u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return u; };
  let farWater = null, farWaterIdx = null, waterTile = null, waterTex = null, toneTex = null, coverTex = null, waterMeta = null, farNearest = null, farNoise = null, biomeTex = null, tintTable = null, tilesTex = null, tileSamplers = null, gl, canvas, progs = {}, atlasTex, sampler, meshes = {}, meta, fbo = null, fboTex = null, fboDepth = null, fboW = 0, fboH = 0, blit = null, extra = {};
  const log = [];
  function compile(type, src, label) {
    const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s);
    if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(label + ": " + gl.getShaderInfoLog(s));
    return s;
  }
  function program(vs, fs, label) {
    const p = gl.createProgram();
    gl.attachShader(p, compile(gl.VERTEX_SHADER, vs, label + " VS")); gl.attachShader(p, compile(gl.FRAGMENT_SHADER, fs, label + " FS"));
    gl.linkProgram(p);
    if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error(label + " link: " + gl.getProgramInfoLog(p));
    return p;
  }
  function mat4mul(a, b) { const o = new Float64Array(16); for (let c = 0; c < 4; c++) for (let r = 0; r < 4; r++) { let s = 0; for (let k = 0; k < 4; k++) s += a[k * 4 + r] * b[c * 4 + k]; o[c * 4 + r] = s; } return o; }
  function perspective(fovy, aspect, n, f) { const t = 1 / Math.tan(fovy * Math.PI / 360); const m = new Float64Array(16); m[0] = t / aspect; m[5] = t; m[10] = (f + n) / (n - f); m[11] = -1; m[14] = 2 * f * n / (n - f); return m; }
  function lookAt(e, c, up) {
    let fx = c[0] - e[0], fy = c[1] - e[1], fz = c[2] - e[2]; let l = Math.hypot(fx, fy, fz); fx /= l; fy /= l; fz /= l;
    let sx = fy * up[2] - fz * up[1], sy = fz * up[0] - fx * up[2], sz = fx * up[1] - fy * up[0]; l = Math.hypot(sx, sy, sz); sx /= l; sy /= l; sz /= l;
    const ux = sy * fz - sz * fy, uy = sz * fx - sx * fz, uz = sx * fy - sy * fx;
    const m = new Float64Array(16);
    m[0] = sx; m[1] = ux; m[2] = -fx; m[4] = sy; m[5] = uy; m[6] = -fy; m[8] = sz; m[9] = uz; m[10] = -fz; m[15] = 1;
    m[12] = -(m[0] * e[0] + m[4] * e[1] + m[8] * e[2]); m[13] = -(m[1] * e[0] + m[5] * e[1] + m[9] * e[2]); m[14] = -(m[2] * e[0] + m[6] * e[1] + m[10] * e[2]);
    return m;
  }
  function uploadMesh(name, vtx, idx, counts) {
    const vao = gl.createVertexArray(); gl.bindVertexArray(vao);
    const vb = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, vb); gl.bufferData(gl.ARRAY_BUFFER, vtx, gl.STATIC_DRAW);
    gl.enableVertexAttribArray(0); gl.vertexAttribPointer(0, 3, gl.FLOAT, false, 24, 0);
    gl.enableVertexAttribArray(1); gl.vertexAttribPointer(1, 2, gl.FLOAT, false, 24, 12);
    gl.enableVertexAttribArray(2); gl.vertexAttribPointer(2, 1, gl.FLOAT, false, 24, 20);
    const ib = gl.createBuffer(); gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, ib); gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, idx, gl.STATIC_DRAW);
    gl.bindVertexArray(null);
    meshes[name] = { vao, counts };
  }
  window.rigSetup = function (cfg) {
    canvas = document.createElement('canvas'); canvas.width = cfg.width; canvas.height = cfg.height; document.body.appendChild(canvas);
    gl = canvas.getContext('webgl2', { antialias: false, alpha: false, depth: true, preserveDrawingBuffer: true });
    if (!gl) throw new Error('no webgl2');
    meta = cfg.meta;
    progs.opaque = program(cfg.vs, cfg.fsOpaque, 'opaque'); progs.cutout = program(cfg.vs, cfg.fsCutout, 'cutout');
    if (cfg.vsWater) {
      let fsw = cfg.fsWater;
      if (cfg.waterDebug === 'pattern') { const tail = 'fragColor = vec4(mix(col, uFogColor, fogFactor), alpha);'; if (!fsw.includes(tail)) throw new Error('debug hook missing'); fsw = fsw.replace(tail, 'fragColor = vec4(wave.rgb, 1.0);'); }
      if (cfg.waterDebug === 'pattern14') { const tail = 'fragColor = vec4(mix(col, uFogColor, fogFactor), alpha);'; fsw = fsw.replace(tail, 'fragColor = vec4(texture(uWaterTex, uv).rgb, 1.0);'); }
      if (cfg.waterDebug === 'notone') { const t = 'col *= vec3(1.0 + tone * 0.06, 1.0 + tone * 0.09, 1.0 + tone * 0.04);'; if (!fsw.includes(t)) throw new Error('notone hook missing'); fsw = fsw.replace(t, ''); }
      if (cfg.waterDebug === 'tone') { const tail = 'fragColor = vec4(mix(col, uFogColor, fogFactor), alpha);'; fsw = fsw.replace(tail, 'fragColor = vec4(vec3(tone + 0.5), 1.0);'); }
      progs.water = program(cfg.vsWater, fsw, 'water');
    }
    if (cfg.vsFar) progs.far = program(cfg.vsFar, cfg.fsFar, 'far');
    // atlas
    atlasTex = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, atlasTex);
    const atlas = b64(cfg.atlas); let off = 0;
    meta.atlas.forEach((s, lv) => { gl.texImage2D(gl.TEXTURE_2D, lv, gl.RGBA, s, s, 0, gl.RGBA, gl.UNSIGNED_BYTE, atlas.subarray(off, off + s * s * 4)); off += s * s * 4; });
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_BASE_LEVEL, 0); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAX_LEVEL, meta.atlas.length - 1);
    if (cfg.tiles) {
      tilesTex = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D_ARRAY, tilesTex); gl.texStorage3D(gl.TEXTURE_2D_ARRAY, 5, gl.RGBA8, 16, 16, 64);
      const tb = b64(cfg.tiles); let o2 = 0;
      for (let layer = 0; layer < 64; layer++) for (let lv = 0; lv < 5; lv++) { const s = 16 >> lv; gl.texSubImage3D(gl.TEXTURE_2D_ARRAY, lv, 0, 0, layer, s, s, 1, gl.RGBA, gl.UNSIGNED_BYTE, tb.subarray(o2, o2 + s * s * 4)); o2 += s * s * 4; }
      gl.texParameteri(gl.TEXTURE_2D_ARRAY, gl.TEXTURE_BASE_LEVEL, 0); gl.texParameteri(gl.TEXTURE_2D_ARRAY, gl.TEXTURE_MAX_LEVEL, 4);
      const mk = (wrap) => { const sp = gl.createSampler(); gl.samplerParameteri(sp, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR); gl.samplerParameteri(sp, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
        gl.samplerParameteri(sp, gl.TEXTURE_WRAP_S, wrap); gl.samplerParameteri(sp, gl.TEXTURE_WRAP_T, wrap);
        if (cfg.anisoOn > 1) { const ext = gl.getExtension('EXT_texture_filter_anisotropic'); if (ext) gl.samplerParameterf(sp, ext.TEXTURE_MAX_ANISOTROPY_EXT, cfg.anisoOn); } return sp; };
      tileSamplers = [mk(gl.REPEAT), mk(gl.CLAMP_TO_EDGE)];
    }
    if (cfg.biome) {
      const n = meta.biome.texels; biomeTex = gl.createTexture(); gl.activeTexture(gl.TEXTURE0 + 4); gl.bindTexture(gl.TEXTURE_2D, biomeTex);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, n, n, 0, gl.RGBA, gl.UNSIGNED_BYTE, b64(cfg.biome));
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.REPEAT); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.REPEAT);
      gl.activeTexture(gl.TEXTURE0);
      const tb = b64(cfg.tint); tintTable = new Float32Array(tb.buffer, tb.byteOffset, tb.byteLength / 4);
    }
    sampler = gl.createSampler();
    gl.samplerParameteri(sampler, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR); gl.samplerParameteri(sampler, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.samplerParameteri(sampler, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.samplerParameteri(sampler, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    if (false) { const ext = gl.getExtension('EXT_texture_filter_anisotropic'); if (ext) { gl.samplerParameterf(sampler, ext.TEXTURE_MAX_ANISOTROPY_EXT, cfg.aniso); log.push('aniso ' + cfg.aniso + ' max ' + gl.getParameter(ext.MAX_TEXTURE_MAX_ANISOTROPY_EXT)); } else log.push('no aniso ext'); }
    for (const k of ['solid', 'water']) if (cfg[k + 'Vtx'] && meta[k].verts > 0) {
      const v = b64(cfg[k + 'Vtx']); const i = b64(cfg[k + 'Idx']);
      uploadMesh(k, new Float32Array(v.buffer, v.byteOffset, v.byteLength / 4), new Uint32Array(i.buffer, i.byteOffset, i.byteLength / 4), meta[k].idx);
    }
    if (cfg.farVtx && progs.far) {
      const v = b64(cfg.farVtx), i = b64(cfg.farIdx);
      const vao = gl.createVertexArray(); gl.bindVertexArray(vao);
      const vb = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, vb); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(v.buffer, v.byteOffset, v.byteLength / 4), gl.STATIC_DRAW);
      gl.enableVertexAttribArray(0); gl.vertexAttribPointer(0, 3, gl.FLOAT, false, 28, 0);
      gl.enableVertexAttribArray(1); gl.vertexAttribPointer(1, 2, gl.FLOAT, false, 28, 12);
      gl.enableVertexAttribArray(2); gl.vertexAttribPointer(2, 1, gl.FLOAT, false, 28, 20);
      gl.enableVertexAttribArray(3); gl.vertexAttribPointer(3, 1, gl.FLOAT, false, 28, 24);
      const ib = gl.createBuffer(); gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, ib); gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint32Array(i.buffer, i.byteOffset, i.byteLength / 4), gl.STATIC_DRAW);
      gl.bindVertexArray(null);
      meshes.far = { vao, count: i.byteLength / 4 };
      farNearest = gl.createSampler();
      gl.samplerParameteri(farNearest, gl.TEXTURE_MIN_FILTER, gl.NEAREST); gl.samplerParameteri(farNearest, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
      gl.samplerParameteri(farNearest, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.samplerParameteri(farNearest, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      farNoise = gl.createTexture(); gl.activeTexture(gl.TEXTURE0 + 1); gl.bindTexture(gl.TEXTURE_2D, farNoise);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.R8, 1, 1, 0, gl.RED, gl.UNSIGNED_BYTE, new Uint8Array([128]));
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
      gl.activeTexture(gl.TEXTURE0);
    }
    if (cfg.waterTile) {
      waterTile = gl.createTexture(); gl.activeTexture(gl.TEXTURE0 + 1); gl.bindTexture(gl.TEXTURE_2D, waterTile);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 16, 16, 0, gl.RGBA, gl.UNSIGNED_BYTE, b64(cfg.waterTile)); gl.generateMipmap(gl.TEXTURE_2D);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.REPEAT); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.REPEAT);
      coverTex = gl.createTexture(); gl.activeTexture(gl.TEXTURE0 + 3); gl.bindTexture(gl.TEXTURE_2D, coverTex);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.R8, 1, 1, 0, gl.RED, gl.UNSIGNED_BYTE, new Uint8Array([0]));
      gl.activeTexture(gl.TEXTURE0);
    }
    if (cfg.waveBin) {
      waterMeta = cfg.waterMeta;
      const M = waterMeta;
      waterTex = gl.createTexture(); gl.activeTexture(gl.TEXTURE0 + 1); gl.bindTexture(gl.TEXTURE_2D_ARRAY, waterTex);
      const levels = Math.floor(Math.log2(M.size)) + 1;
      gl.texStorage3D(gl.TEXTURE_2D_ARRAY, levels, gl.RGBA8, M.size, M.size, M.frames);
      gl.texSubImage3D(gl.TEXTURE_2D_ARRAY, 0, 0, 0, 0, M.size, M.size, M.frames, gl.RGBA, gl.UNSIGNED_BYTE, b64(cfg.waveBin));
      gl.generateMipmap(gl.TEXTURE_2D_ARRAY);
      gl.texParameteri(gl.TEXTURE_2D_ARRAY, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR); gl.texParameteri(gl.TEXTURE_2D_ARRAY, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D_ARRAY, gl.TEXTURE_WRAP_S, gl.REPEAT); gl.texParameteri(gl.TEXTURE_2D_ARRAY, gl.TEXTURE_WRAP_T, gl.REPEAT);
      toneTex = gl.createTexture(); gl.activeTexture(gl.TEXTURE0 + 5); gl.bindTexture(gl.TEXTURE_2D, toneTex);
      gl.pixelStorei(gl.UNPACK_ALIGNMENT, 1);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.R8, M.toneSize, M.toneSize, 0, gl.RED, gl.UNSIGNED_BYTE, b64(cfg.toneBin));
      gl.pixelStorei(gl.UNPACK_ALIGNMENT, 4);
      gl.generateMipmap(gl.TEXTURE_2D);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.REPEAT); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.REPEAT);
      coverTex = gl.createTexture(); gl.activeTexture(gl.TEXTURE0 + 3); gl.bindTexture(gl.TEXTURE_2D, coverTex);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.R8, 1, 1, 0, gl.RED, gl.UNSIGNED_BYTE, new Uint8Array([0]));
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
      gl.activeTexture(gl.TEXTURE0);
    }
    if (cfg.farWaterVtx) {
      const v = b64(cfg.farWaterVtx), i = b64(cfg.farWaterIdx);
      const vao = gl.createVertexArray(); gl.bindVertexArray(vao);
      const vb = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, vb); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(v.buffer, v.byteOffset, v.byteLength / 4), gl.STATIC_DRAW);
      gl.enableVertexAttribArray(0); gl.vertexAttribPointer(0, 3, gl.FLOAT, false, 24, 0);
      gl.enableVertexAttribArray(1); gl.vertexAttribPointer(1, 2, gl.FLOAT, false, 24, 12);
      gl.enableVertexAttribArray(2); gl.vertexAttribPointer(2, 1, gl.FLOAT, false, 24, 20);
      const ib = gl.createBuffer(); gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, ib); gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint32Array(i.buffer, i.byteOffset, i.byteLength / 4), gl.STATIC_DRAW);
      gl.bindVertexArray(null);
      farWater = vao; farWaterIdx = JSON.parse(cfg.farWaterJson);
      // coverage mask: the chunk columns the voxel scene holds
      const sp = meta.spec.split(':'); const c0x = +sp[2], c0z = +sp[3], r = +sp[4];
      const mask = new Uint8Array(256 * 256);
      for (let cz = c0z - r; cz <= c0z + r; cz++) for (let cx = c0x - r; cx <= c0x + r; cx++) mask[((cz & 255) << 8) | (cx & 255)] = 255;
      if (coverTex) gl.deleteTexture(coverTex);
      coverTex = gl.createTexture(); gl.activeTexture(gl.TEXTURE0 + 3); gl.bindTexture(gl.TEXTURE_2D, coverTex);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.R8, 256, 256, 0, gl.RED, gl.UNSIGNED_BYTE, mask);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.REPEAT); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.REPEAT);
      gl.activeTexture(gl.TEXTURE0);
    }
    // box downsample blit
    blit = program('#version 300 es\nvoid main(){ vec2 p = vec2((gl_VertexID<<1)&2, gl_VertexID&2); gl_Position = vec4(p*2.0-1.0,0.0,1.0);}',
      '#version 300 es\nprecision highp float; uniform sampler2D uSrc; uniform int uSS; out vec4 o; void main(){ ivec2 b = ivec2(gl_FragCoord.xy)*uSS; vec4 s=vec4(0.0); for(int y=0;y<uSS;y++) for(int x=0;x<uSS;x++) s+=texelFetch(uSrc,b+ivec2(x,y),0); o = s/float(uSS*uSS);}', 'blit');
    return gl.getParameter(gl.VERSION) + ' | ' + gl.getParameter(gl.RENDERER) + ' | ' + log.join(';');
  };
  function target(w, h) {
    if (fbo && fboW === w && fboH === h) return;
    if (fbo) { gl.deleteFramebuffer(fbo); gl.deleteTexture(fboTex); gl.deleteRenderbuffer(fboDepth); }
    fbo = gl.createFramebuffer(); fboTex = gl.createTexture(); fboDepth = gl.createRenderbuffer(); fboW = w; fboH = h;
    gl.bindTexture(gl.TEXTURE_2D, fboTex); gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA8, w, h, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
    gl.bindRenderbuffer(gl.RENDERBUFFER, fboDepth); gl.renderbufferStorage(gl.RENDERBUFFER, gl.DEPTH_COMPONENT24, w, h);
    gl.bindFramebuffer(gl.FRAMEBUFFER, fbo); gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, fboTex, 0);
    gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.RENDERBUFFER, fboDepth);
  }
  function setCommon(p, f, vp, origin) {
    gl.useProgram(p);
    const u = n => gl.getUniformLocation(p, n);
    gl.uniformMatrix4fv(u('uViewProj'), false, vp);
    gl.uniform3f(u('uCamOrigin'), origin[0], origin[1], origin[2]);
    gl.uniform3f(u('uFogColor'), f.fogColor[0], f.fogColor[1], f.fogColor[2]);
    gl.uniform1f(u('uFogStart'), f.fog[0]); gl.uniform1f(u('uFogEnd'), f.fog[1]);
    gl.uniform1i(u('uTexture'), 0);
    if (u('uAlpha')) gl.uniform1f(u('uAlpha'), 1);
    if (u('uFade')) gl.uniform4f(u('uFade'), 0, 0, 0, 0);
    if (u('uTilesWrap')) gl.uniform1i(u('uTilesWrap'), 1); if (u('uTilesClamp')) gl.uniform1i(u('uTilesClamp'), 2);
    if (u('uTime')) gl.uniform1f(u('uTime'), f.time || 0);
    if (biomeTex) {
      const scale = meta.biome.scale; const fr = x => { const v = x * scale; return v - Math.floor(v); };
      gl.uniform1i(u('uBiomeMap'), 4);
      gl.uniform4f(u('uBiomeFrame'), fr(origin[0]), fr(origin[2]), scale, 0);
      if (u('uTint')) gl.uniform4fv(u('uTint'), tintTable);
      gl.activeTexture(gl.TEXTURE0 + 4); gl.bindTexture(gl.TEXTURE_2D, biomeTex); gl.activeTexture(gl.TEXTURE0);
    }
  }
  window.rigRender = function (f, W, H) {
    const ss = f.ss || 1, w = W * ss, h = H * ss;
    if (ss > 1) { target(w, h); gl.bindFramebuffer(gl.FRAMEBUFFER, fbo); } else gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    gl.viewport(0, 0, w, h);
    const origin = [Math.floor(f.eye[0]), Math.floor(f.eye[1]), Math.floor(f.eye[2])];
    const er = [f.eye[0] - origin[0], f.eye[1] - origin[1], f.eye[2] - origin[2]];
    const cp = Math.cos(f.pitch), dir = [cp * Math.sin(f.yaw), Math.sin(f.pitch), -cp * Math.cos(f.yaw)];
    const P = perspective(f.fov || 70, W / H, 0.15, f.far || 420);
    const V = lookAt(er, [er[0] + dir[0], er[1] + dir[1], er[2] + dir[2]], [0, 1, 0]);
    const vp = new Float32Array(mat4mul(P, V));
    f.fogColor = f.fogColor || [0.62, 0.78, 0.96];
    gl.clearColor(f.fogColor[0], f.fogColor[1], f.fogColor[2], 1); gl.clearDepth(1); gl.depthMask(true);
    gl.enable(gl.DEPTH_TEST); gl.depthFunc(gl.LEQUAL); gl.enable(gl.CULL_FACE); gl.cullFace(gl.BACK); gl.frontFace(gl.CCW);
    gl.disable(gl.BLEND);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, atlasTex); gl.bindSampler(0, sampler);
    if (tilesTex) { for (let u = 1; u <= 2; u++) { gl.activeTexture(gl.TEXTURE0 + u); gl.bindTexture(gl.TEXTURE_2D_ARRAY, tilesTex); gl.bindSampler(u, tileSamplers[u - 1]); } gl.activeTexture(gl.TEXTURE0); }
    const m = f.noSolid ? null : meshes.solid;
    if (m) {
      gl.bindVertexArray(m.vao);
      const c = m.counts;
      setCommon(progs.opaque, f, vp, origin); if (c[0]) gl.drawElements(gl.TRIANGLES, c[0], gl.UNSIGNED_INT, 0);
      setCommon(progs.cutout, f, vp, origin); if (c[1]) gl.drawElements(gl.TRIANGLES, c[1], gl.UNSIGNED_INT, c[0] * 4);
      gl.disable(gl.CULL_FACE); if (c[2]) gl.drawElements(gl.TRIANGLES, c[2], gl.UNSIGNED_INT, (c[0] + c[1]) * 4); gl.enable(gl.CULL_FACE);
    }
    if (meshes.far && !f.noFar) {
      const p = progs.far; gl.useProgram(p); const u = n => gl.getUniformLocation(p, n);
      gl.uniformMatrix4fv(u('uViewProj'), false, vp); gl.uniform3f(u('uCamOrigin'), origin[0], origin[1], origin[2]);
      gl.uniform2f(u('uCenter'), f.eye[0], f.eye[2]); gl.uniform4f(u('uBand'), 0, 1e9, 1e9, 2e9); gl.uniform2f(u('uSkip'), 0, 0); gl.uniform2f(u('uVoxel'), 0, 0);
      gl.uniform3f(u('uFogColor'), f.fogColor[0], f.fogColor[1], f.fogColor[2]); gl.uniform1f(u('uFogStart'), f.fog[0]); gl.uniform1f(u('uFogEnd'), f.fog[1]);
      gl.uniform1i(u('uTexture'), 0); gl.uniform1i(u('uNoise'), 1); gl.uniform1i(u('uCover'), 2);
      gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, atlasTex); gl.bindSampler(0, farNearest);
      gl.activeTexture(gl.TEXTURE0 + 1); gl.bindTexture(gl.TEXTURE_2D, farNoise); gl.activeTexture(gl.TEXTURE0);
      gl.bindVertexArray(meshes.far.vao); gl.drawElements(gl.TRIANGLES, meshes.far.count, gl.UNSIGNED_INT, 0);
      gl.bindSampler(0, sampler);
    }
    if (progs.water && meshes.water && (waterTex || waterTile) && !f.noWater) {
      const p = progs.water; gl.useProgram(p); const u = n => gl.getUniformLocation(p, n);
      const M = waterMeta || { size: 128, frames: 40, toneSize: 64, avg: [0.28, 0.5, 0.85] }, mod = (v, m) => ((v % m) + m) % m, t = f.time || 0, P = M.size / 16, TP = M.toneSize * 4;
      const layer = f.layer !== undefined ? f.layer : (Math.floor(t * (f.fps || 6)) % M.frames + M.frames) % M.frames;
      gl.uniformMatrix4fv(u('uViewProj'), false, vp); gl.uniform3f(u('uCamOrigin'), origin[0], origin[1], origin[2]);
      gl.uniform1f(u('uTime'), t); gl.uniform1f(u('uWaterLayer'), layer);
      gl.uniform3f(u('uWaterPhase'), mod(origin[0], P), mod(origin[1], P), mod(origin[2], P));
      const drift = f.noDrift ? 0 : t * 0.256;
      gl.uniform2f(u('uTonePhase'), mod(mod(origin[0], TP) - drift, TP), mod(origin[2], TP));
      gl.uniform3f(u('uWaterAvg'), M.avg[0], M.avg[1], M.avg[2]);
      gl.uniform3f(u('uEyeRel'), er[0], er[1], er[2]);
      gl.uniform3f(u('uFogColor'), f.fogColor[0], f.fogColor[1], f.fogColor[2]); gl.uniform1f(u('uFogStart'), f.fog[0]); gl.uniform1f(u('uFogEnd'), f.fog[1]);
      gl.uniform2f(u('uCenter'), f.eye[0], f.eye[2]); gl.uniform4f(u('uBand'), 0, 1e9, 0, 0); gl.uniform2f(u('uSkip'), 0, 0);
      gl.uniform2f(u('uVoxel'), f.voxel ? f.voxel[0] : 0, f.voxel ? f.voxel[1] : 0); gl.uniform1f(u('uSide'), f.seam ? 1 : 0);
      gl.uniform1i(u('uWaterTex'), 1); gl.uniform1i(u('uWaterTone'), 5); gl.uniform1i(u('uCover'), 3);
      if (waterTile) { gl.activeTexture(gl.TEXTURE0 + 1); gl.bindTexture(gl.TEXTURE_2D, waterTile); gl.bindSampler(1, null); }
      else { gl.activeTexture(gl.TEXTURE0 + 1); gl.bindTexture(gl.TEXTURE_2D_ARRAY, waterTex); gl.bindSampler(1, null);
      gl.activeTexture(gl.TEXTURE0 + 5); gl.bindTexture(gl.TEXTURE_2D, toneTex); gl.bindSampler(5, null); }
      gl.activeTexture(gl.TEXTURE0 + 3); gl.bindTexture(gl.TEXTURE_2D, coverTex); gl.bindSampler(3, null);
      gl.activeTexture(gl.TEXTURE0);
      gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA); gl.depthMask(false);
      gl.bindVertexArray(meshes.water.vao); gl.drawElements(gl.TRIANGLES, meshes.water.counts[0], gl.UNSIGNED_INT, 0);
      if (farWater && !f.noFarWater) {
        gl.uniform1f(u('uSide'), -1);
        gl.bindVertexArray(farWater);
        const maxL = farWaterIdx[farWaterIdx.length - 1].level;
        for (let k = farWaterIdx.length - 1; k >= 0; k--) {
          const L = farWaterIdx[k];
          gl.uniform4f(u('uBand'), L.inner, L.level === maxL ? L.outer : L.outer + 1.5, 0, 0);
          if (L.count) gl.drawElements(gl.TRIANGLES, L.count, gl.UNSIGNED_INT, L.first * 4);
        }
      }
      gl.depthMask(true); gl.disable(gl.BLEND);
    }
    if (window.rigExtraPasses) window.rigExtraPasses(gl, f, vp, origin, progs, meshes, setCommon);
    if (ss > 1) {
      gl.bindFramebuffer(gl.FRAMEBUFFER, null); gl.viewport(0, 0, W, H); gl.disable(gl.DEPTH_TEST); gl.disable(gl.CULL_FACE);
      gl.useProgram(blit); gl.activeTexture(gl.TEXTURE0); gl.bindSampler(0, null); gl.bindTexture(gl.TEXTURE_2D, fboTex);
      gl.uniform1i(gl.getUniformLocation(blit, 'uSrc'), 0); gl.uniform1i(gl.getUniformLocation(blit, 'uSS'), ss);
      gl.bindVertexArray(null); gl.drawArrays(gl.TRIANGLES, 0, 3);
    }
    const px = new Uint8Array(W * H * 4); gl.readPixels(0, 0, W, H, gl.RGBA, gl.UNSIGNED_BYTE, px);
    // flip rows (GL origin bottom-left) and base64 in chunks
    const out = new Uint8Array(W * H * 4);
    for (let y = 0; y < H; y++) out.set(px.subarray((H - 1 - y) * W * 4, (H - y) * W * 4), y * W * 4);
    let s = ''; const CH = 0x8000; for (let i = 0; i < out.length; i += CH) s += String.fromCharCode.apply(null, out.subarray(i, i + CH));
    return btoa(s);
  };
})();
