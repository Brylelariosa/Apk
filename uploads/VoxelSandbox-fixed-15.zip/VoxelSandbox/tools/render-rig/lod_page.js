(function () {
  const b64 = s => { const bin = atob(s); const u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return u; };
  let gl, prog, vao, lod, atlasTex, noiseTex, coverTex;
  function compile(type, src, label) { const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s); if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(label + ': ' + gl.getShaderInfoLog(s)); return s; }
  function mat4mul(a, b) { const o = new Float64Array(16); for (let c = 0; c < 4; c++) for (let r = 0; r < 4; r++) { let s = 0; for (let k = 0; k < 4; k++) s += a[k * 4 + r] * b[c * 4 + k]; o[c * 4 + r] = s; } return o; }
  function perspective(fovy, aspect, n, f) { const t = 1 / Math.tan(fovy * Math.PI / 360); const m = new Float64Array(16); m[0] = t / aspect; m[5] = t; m[10] = (f + n) / (n - f); m[11] = -1; m[14] = 2 * f * n / (n - f); return m; }
  function lookAt(e, c, up) {
    let fx = c[0] - e[0], fy = c[1] - e[1], fz = c[2] - e[2]; let l = Math.hypot(fx, fy, fz); fx /= l; fy /= l; fz /= l;
    let sx = fy * up[2] - fz * up[1], sy = fz * up[0] - fx * up[2], sz = fx * up[1] - fy * up[0]; l = Math.hypot(sx, sy, sz); sx /= l; sy /= l; sz /= l;
    const ux = sy * fz - sz * fy, uy = sz * fx - sx * fz, uz = sx * fy - sy * fx;
    const m = new Float64Array(16);
    m[0] = sx; m[1] = ux; m[2] = -fx; m[4] = sy; m[5] = uy; m[6] = -fy; m[8] = sz; m[9] = uz; m[10] = -fz; m[15] = 1;
    m[12] = -(m[0] * e[0] + m[4] * e[1] + m[8] * e[2]); m[13] = -(m[1] * e[0] + m[5] * e[1] + m[9] * e[2]); m[14] = -(m[2] * e[0] + m[6] * e[1] + m[10] * e[2]);
    return m;
  }
  const chunks = { vtx: [], idx: [] };
  window.lodPush = function (kind, b) { chunks[kind].push(b64(b)); return chunks[kind].length; };
  const join = parts => { let n = 0; for (const p of parts) n += p.length; const o = new Uint8Array(n); let off = 0; for (const p of parts) { o.set(p, off); off += p.length; } return o; };
  window.lodSetup = function (cfg) {
    const canvas = document.createElement('canvas'); canvas.width = cfg.width; canvas.height = cfg.height; document.body.appendChild(canvas);
    gl = canvas.getContext('webgl2', { antialias: false, alpha: false, depth: true, preserveDrawingBuffer: true });
    if (!gl) throw new Error('no webgl2');
    prog = gl.createProgram(); gl.attachShader(prog, compile(gl.VERTEX_SHADER, cfg.vs, 'VS')); gl.attachShader(prog, compile(gl.FRAGMENT_SHADER, cfg.fs, 'FS')); gl.linkProgram(prog);
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error('link: ' + gl.getProgramInfoLog(prog));
    lod = cfg.lod;
    const v = join(chunks.vtx), i = join(chunks.idx); chunks.vtx = []; chunks.idx = [];
    vao = gl.createVertexArray(); gl.bindVertexArray(vao);
    const vb = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, vb); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(v.buffer, v.byteOffset, v.byteLength / 4), gl.STATIC_DRAW);
    const fl = (lod.floats || 7), stride = fl * 4;
    gl.enableVertexAttribArray(0); gl.vertexAttribPointer(0, 3, gl.FLOAT, false, stride, 0);
    gl.enableVertexAttribArray(1); gl.vertexAttribPointer(1, 2, gl.FLOAT, false, stride, 12);
    gl.enableVertexAttribArray(2); gl.vertexAttribPointer(2, 1, gl.FLOAT, false, stride, 20);
    if (fl >= 7) { gl.enableVertexAttribArray(3); gl.vertexAttribPointer(3, 1, gl.FLOAT, false, stride, 24); }
    const ib = gl.createBuffer(); gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, ib); gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint32Array(i.buffer, i.byteOffset, i.byteLength / 4), gl.STATIC_DRAW);
    gl.bindVertexArray(null);
    gl.activeTexture(gl.TEXTURE0);
    atlasTex = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, atlasTex);
    if (cfg.atlas && cfg.meta) { const atlas = b64(cfg.atlas); let off = 0; cfg.meta.atlas.forEach((s, lv) => { gl.texImage2D(gl.TEXTURE_2D, lv, gl.RGBA, s, s, 0, gl.RGBA, gl.UNSIGNED_BYTE, atlas.subarray(off, off + s * s * 4)); off += s * s * 4; });
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_BASE_LEVEL, 0); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAX_LEVEL, cfg.meta.atlas.length - 1); }
    else gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 1, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE, new Uint8Array([255, 0, 255, 255]));
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
    gl.activeTexture(gl.TEXTURE0 + 1); noiseTex = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, noiseTex);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.R8, 1, 1, 0, gl.RED, gl.UNSIGNED_BYTE, new Uint8Array([128]));
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
    gl.activeTexture(gl.TEXTURE0 + 2); coverTex = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, coverTex);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.R8, 1, 1, 0, gl.RED, gl.UNSIGNED_BYTE, new Uint8Array([0]));
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
    gl.activeTexture(gl.TEXTURE0);
    return 'ok';
  };
  window.lodRender = function (f, W, H) {
    gl.bindFramebuffer(gl.FRAMEBUFFER, null); gl.viewport(0, 0, W, H);
    const origin = [Math.floor(f.eye[0]), Math.floor(f.eye[1]), Math.floor(f.eye[2])];
    const er = [f.eye[0] - origin[0], f.eye[1] - origin[1], f.eye[2] - origin[2]];
    const cp = Math.cos(f.pitch), dir = [cp * Math.sin(f.yaw), Math.sin(f.pitch), -cp * Math.cos(f.yaw)];
    const P = perspective(f.fov || 60, W / H, f.near || 2, f.far || 30000);
    const V = lookAt(er, [er[0] + dir[0], er[1] + dir[1], er[2] + dir[2]], [0, 1, 0]);
    const vp = new Float32Array(mat4mul(P, V));
    const fc = f.fogColor || [0.62, 0.78, 0.96];
    const sky = f.skyColor || fc;
    gl.clearColor(sky[0], sky[1], sky[2], 1); gl.clearDepth(1); gl.depthMask(true); gl.enable(gl.DEPTH_TEST); gl.depthFunc(gl.LEQUAL);
    gl.enable(gl.CULL_FACE); gl.cullFace(gl.BACK); gl.frontFace(gl.CCW); gl.disable(gl.BLEND); gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    gl.useProgram(prog); const u = n => gl.getUniformLocation(prog, n);
    gl.uniformMatrix4fv(u('uViewProj'), false, vp); gl.uniform3f(u('uCamOrigin'), origin[0], origin[1], origin[2]);
    gl.uniform2f(u('uCenter'), f.center ? f.center[0] : f.eye[0], f.center ? f.center[1] : f.eye[2]);
    gl.uniform3f(u('uFogColor'), fc[0], fc[1], fc[2]); gl.uniform1f(u('uFogStart'), (f.fog || [1e9, 2e9])[0]); gl.uniform1f(u('uFogEnd'), (f.fog || [1e9, 2e9])[1]);
    gl.uniform2f(u('uSkip'), 0, 0); gl.uniform2f(u('uVoxel'), 0, 0);
    gl.uniform1i(u('uTexture'), 0); gl.uniform1i(u('uNoise'), 1); gl.uniform1i(u('uCover'), 2);
    if (u('uGrow')) gl.uniform1f(u('uGrow'), f.grow || 0);
    const setClip = (a, b, c, d) => gl.uniform4f(u('uClip'), a, b, c, d), setDither = (lo, hi) => gl.uniform2f(u('uDither'), lo, hi);
    setClip(-1e9, -1e9, 1e9, 1e9); setDither(0, 1);
    gl.bindVertexArray(vao);
    const want = f.levels ? new Set(f.levels) : null;
    let tris = 0;
    // Tiles listed as missing (drop) are not drawn; a coarser tile that contains them stands in (see FarStandIns);
    // tiles listed in fade = [level, tx, tz, share] are drawn on the pixels with noise in [0, share) and their stand-in on the rest.
    const tileMap = new Map(), byLevel = new Map();
    for (const L of lod.levels) { byLevel.set(L.level, L); for (const [tx, tz, first, count] of (L.t || [])) tileMap.set(L.level + ':' + tx + ':' + tz, { first, count, level: L.level }); }
    const dropped = new Set((f.drop || []).map(d => d.join(':')));
    const fades = new Map((f.fade || []).map(d => [d.slice(0, 3).join(':'), d[3]]));
    for (const L of lod.levels) {
      if (want && !want.has(L.level)) continue;
      const inner = f.bands === false ? (f.hole || 0) : Math.max(L.inner, f.hole || 0), outer = f.bands === false ? 1e9 : (L.level === lod.levels[lod.levels.length - 1].level ? L.outer : L.outer);
      const ms = f.morph === false ? 2e9 : L.mStart, me = f.morph === false ? 3e9 : L.mEnd;
      gl.uniform4f(u('uBand'), inner, outer, ms, me);
      if (!L.t || (dropped.size === 0 && fades.size === 0)) { gl.drawElements(gl.TRIANGLES, L.count, gl.UNSIGNED_INT, L.first * 4); tris += L.count / 3; continue; }
      for (const [tx, tz, first, count] of L.t) {
        const key = L.level + ':' + tx + ':' + tz;
        if (dropped.has(key)) continue;
        if (fades.has(key)) setDither(0, fades.get(key)); else setDither(0, 1);
        gl.drawElements(gl.TRIANGLES, count, gl.UNSIGNED_INT, first * 4); tris += count / 3;
      }
      setDither(0, 1);
    }
    if (f.standins !== false && (dropped.size || fades.size)) {
      const standIn = (level, tx, tz, lo, hi) => {
        const size = byLevel.get(level).size, big = lvl => byLevel.has(lvl) ? byLevel.get(lvl).size : null;
        for (let up = level + 1; up <= 7; up++) {
          if (!byLevel.has(up)) continue;
          const bs = byLevel.get(up).size;
          const ax = Math.floor(tx * size / bs), az = Math.floor(tz * size / bs), k = up + ':' + ax + ':' + az;
          if (!tileMap.has(k) || dropped.has(k)) continue;
          const S = tileMap.get(k), H = byLevel.get(level), SL = byLevel.get(up);
          const inner = Math.max(H.inner, f.hole || 0);
          gl.uniform4f(u('uBand'), inner, H.outer, f.morph === false ? 2e9 : SL.mStart, f.morph === false ? 3e9 : SL.mEnd);
          setClip(tx * size, tz * size, (tx + 1) * size, (tz + 1) * size); setDither(lo, hi);
          gl.drawElements(gl.TRIANGLES, S.count, gl.UNSIGNED_INT, S.first * 4); tris += S.count / 3;
          return up;
        }
        return -1;
      };
      for (const d of (f.drop || [])) standIn(d[0], d[1], d[2], 0, 1);
      for (const d of (f.fade || [])) standIn(d[0], d[1], d[2], d[3], 1);
      setClip(-1e9, -1e9, 1e9, 1e9); setDither(0, 1);
    }
    const px = new Uint8Array(W * H * 4); gl.readPixels(0, 0, W, H, gl.RGBA, gl.UNSIGNED_BYTE, px);
    const out = new Uint8Array(W * H * 4);
    for (let y = 0; y < H; y++) out.set(px.subarray((H - 1 - y) * W * 4, (H - y) * W * 4), y * W * 4);
    let s = ''; const CH = 0x8000; for (let i = 0; i < out.length; i += CH) s += String.fromCharCode.apply(null, out.subarray(i, i + CH));
    return btoa(s);
  };
})();
