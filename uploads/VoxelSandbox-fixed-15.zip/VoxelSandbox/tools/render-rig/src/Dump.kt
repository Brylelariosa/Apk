package rig

import com.voxelsandbox.game.gl.TextureAtlas
import com.voxelsandbox.game.gl.VoxelShader
import com.voxelsandbox.game.world.BlockType
import com.voxelsandbox.game.world.Chunk
import com.voxelsandbox.game.world.ChunkPos
import com.voxelsandbox.game.world.World
import com.voxelsandbox.game.world.WorldConfig
import com.voxelsandbox.game.gl.TintTable
import com.voxelsandbox.game.world.color.BiomeColorField
import com.voxelsandbox.game.world.color.BiomeColorLayout
import com.voxelsandbox.game.world.color.BiomeColorTiles
import com.voxelsandbox.game.world.color.BiomePalette
import com.voxelsandbox.game.world.generation.TerrainGenerator
import com.voxelsandbox.game.world.mesh.ChunkMesher
import com.voxelsandbox.game.world.mesh.MeshData
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Test-rig scene dumper: meshes a scene with the REAL ChunkMesher / atlas / shaders and writes them for the WebGL2 renderer. */
private class Acc {
    val verts = ArrayList<FloatArray>(); var vcount = 0
    val idx = Array(3) { ArrayList<IntArray>() }
    fun add(m: MeshData) {
        if (m.isEmpty()) return
        val base = vcount
        verts.add(m.vertexData); vcount += m.vertexCount
        val bounds = intArrayOf(0, m.opaqueEnd, m.cutoutEnd, m.indices.size)
        for (g in 0 until 3) {
            val out = IntArray(bounds[g + 1] - bounds[g]) { m.indices[bounds[g] + it] + base }
            idx[g].add(out)
        }
    }
    fun write(dir: File, name: String): String {
        val vb = ByteBuffer.allocate(vcount * 24).order(ByteOrder.LITTLE_ENDIAN)
        for (v in verts) for (f in v) vb.putFloat(f)
        File(dir, "$name.vtx").writeBytes(vb.array())
        val counts = IntArray(3)
        val all = ArrayList<Int>()
        val ib = java.io.ByteArrayOutputStream()
        for (g in 0 until 3) {
            var n = 0
            for (a in idx[g]) n += a.size
            counts[g] = n
        }
        val buf = ByteBuffer.allocate((counts.sum()) * 4).order(ByteOrder.LITTLE_ENDIAN)
        for (g in 0 until 3) for (a in idx[g]) for (i in a) buf.putInt(i)
        File(dir, "$name.idx").writeBytes(buf.array())
        return "\"$name\":{\"verts\":$vcount,\"idx\":[${counts[0]},${counts[1]},${counts[2]}]}"
    }
}

private fun columnFill(chunk: Chunk, wx0: Int, wz0: Int, top: BlockType, sub: BlockType, h: (Int, Int) -> Int) {
    for (lz in 0 until 16) for (lx in 0 until 16) {
        val hh = h(wx0 + lx, wz0 + lz)
        for (y in 0 until hh) chunk.setBlock(lx, y, lz, if (y >= hh - 3) sub else BlockType.STONE)
        chunk.setBlock(lx, hh, lz, top)
        chunk.heightMap[lz * 16 + lx] = hh.toShort()
    }
}

fun main(args: Array<String>) {
    val out = File(args[0]); out.mkdirs()
    val spec = args[1]          // flat:SAND | flat:GRASS | terraces | world:<seed>:<cx>:<cz>:<radius>
    val world = World()
    val atlas = TextureAtlas()
    var c0x = 0; var c0z = 0; var r = 4
    var meshRange: IntRange? = null
    var fieldGen = TerrainGenerator(0L)
    if (spec.startsWith("world:")) {
        val p = spec.split(":")
        val gen = TerrainGenerator(p[1].toLong())
        fieldGen = gen
        c0x = p[2].toInt(); c0z = p[3].toInt(); r = p[4].toInt()
        for (cz in c0z - r - 1..c0z + r + 1) for (cx in c0x - r - 1..c0x + r + 1) world.putChunk(gen.generate(ChunkPos(cx, cz)))
    } else {
        // chunks 0..7 x 0..7 -> blocks 0..127
        for (cz in 0 until 8) for (cx in 0 until 8) {
            val ch = Chunk(ChunkPos(cx, cz))
            val wx0 = cx * 16; val wz0 = cz * 16
            when {
                spec == "flat:SAND" -> columnFill(ch, wx0, wz0, BlockType.SAND, BlockType.SAND) { _, _ -> 63 }
                spec == "flat:GRASS" -> columnFill(ch, wx0, wz0, BlockType.GRASS, BlockType.DIRT) { _, _ -> 63 }
                spec == "flat:DIRT" -> columnFill(ch, wx0, wz0, BlockType.DIRT, BlockType.DIRT) { _, _ -> 63 }
                spec == "flat:STONE" -> columnFill(ch, wx0, wz0, BlockType.STONE, BlockType.STONE) { _, _ -> 63 }
                spec == "terraces" -> {
                    // stairs of 2-high steps along z, grass on the left half, sand on the right half
                    for (lz in 0 until 16) for (lx in 0 until 16) {
                        val wx = wx0 + lx; val wz = wz0 + lz
                        val h = 56 + 2 * ((127 - wz) / 8).coerceAtMost(8)
                        val grass = wx < 64
                        for (y in 0 until h) ch.setBlock(lx, y, lz, if (y >= h - 3) (if (grass) BlockType.DIRT else BlockType.SAND) else BlockType.STONE)
                        ch.setBlock(lx, h, lz, if (grass) BlockType.GRASS else BlockType.SAND)
                        ch.heightMap[lz * 16 + lx] = h.toShort()
                    }
                }
                else -> error("unknown scene $spec")
            }
            world.putChunk(ch)
        }
        c0x = 4; c0z = 4; r = 4
    }
    val solid = Acc(); val water = Acc()
    val range = if (spec.startsWith("world:")) (c0x - r..c0x + r) else (0 until 8)
    val rangeZ = if (spec.startsWith("world:")) (c0z - r..c0z + r) else (0 until 8)
    var meshed = 0
    for (cz in rangeZ) for (cx in range) for (s in 0 until WorldConfig.SUBCHUNKS_PER_CHUNK) {
        val m = ChunkMesher.buildSubChunkMesh(world, cx, cz, s, atlas, false, false)
        if (m.isEmpty()) continue
        solid.add(m.solid); water.add(m.water); meshed++
    }
    // atlas
    val f = TextureAtlas::class.java.getDeclaredField("mips"); f.isAccessible = true
    @Suppress("UNCHECKED_CAST") val mips = f.get(atlas) as Array<IntArray>
    val ab = java.io.ByteArrayOutputStream()
    val sizes = ArrayList<Int>()
    var sz = TextureAtlas.SIZE_PX
    for (lv in mips) {
        val bb = ByteArray(lv.size * 4)
        for (i in lv.indices) { val p = lv[i]; bb[i * 4] = (p shr 16).toByte(); bb[i * 4 + 1] = (p shr 8).toByte(); bb[i * 4 + 2] = p.toByte(); bb[i * 4 + 3] = (p ushr 24).toByte() }
        ab.write(bb); sizes.add(sz); sz /= 2
    }
    File(out, "atlas.bin").writeBytes(ab.toByteArray())
    // The biome colour map exactly as the game's GPU texture holds it once the tiles around the eye have arrived,
    // and the table of which atlas cells are tinted.
    val field = BiomeColorField(fieldGen.climate, fieldGen.shape, BiomePalette.fromTiles())
    val spacing = BiomeColorLayout.MIN_SPACING
    File(out, "biome.bin").writeBytes(BiomeColorLayout.fullTexture(field, c0x * 16 + 8.0, c0z * 16 + 8.0, spacing, 7))
    val tint = TintTable.shaderTable(field.palette)
    val tb = ByteBuffer.allocate(tint.size * 4).order(ByteOrder.LITTLE_ENDIAN)
    for (v in tint) tb.putFloat(v)
    File(out, "tint.bin").writeBytes(tb.array())
    File(out, "vs.glsl").writeText(VoxelShader.VERTEX)
    File(out, "fs_opaque.glsl").writeText(VoxelShader.opaque(true))
    File(out, "fs_cutout.glsl").writeText(VoxelShader.cutout(true))
    val meta = "{\"spec\":\"$spec\",\"biome\":{\"spacing\":$spacing,\"scale\":${BiomeColorLayout.inverseWorldSize(spacing)},\"texels\":${BiomeColorLayout.TEXELS}},\"atlas\":[${sizes.joinToString(",")}],\"subchunks\":$meshed," + solid.write(out, "solid") + "," + water.write(out, "water") + "}"
    File(out, "meta.json").writeText(meta)
    println("scene $spec: $meshed subchunk meshes, solid verts=${solid.vcount} water verts=${water.vcount}")
}
