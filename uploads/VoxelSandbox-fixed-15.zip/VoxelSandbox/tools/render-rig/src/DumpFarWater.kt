package rig

import com.voxelsandbox.game.world.far.FarTerrain
import com.voxelsandbox.game.world.generation.TerrainGenerator
import com.voxelsandbox.game.world.mesh.MeshData
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

private fun newColorField(gen: TerrainGenerator): Any {
    val paletteClass = Class.forName("com.voxelsandbox.game.world.color.BiomePalette")
    val companion = paletteClass.getField("Companion").get(null)
    val palette = companion.javaClass.getMethod("fromTiles").invoke(companion)
    val fieldClass = Class.forName("com.voxelsandbox.game.world.color.BiomeColorField")
    return fieldClass.constructors.first().newInstance(gen.climate, gen.shape, palette)
}

/**
 * Builds the REAL distant water meshes (FarTerrain.buildTile(...).water) of the rings of levels 1..maxLevel around a point, and writes
 * them for the rig: farwater.vtx / farwater.idx (six floats per vertex) and farwater.json (per level: index range, the ring's inner and outer radius).
 * usage: DumpFarWater <outDir> <seed> <centreX> <centreZ> <maxLevel>
 */
fun main(args: Array<String>) {
    val out = File(args[0]); out.mkdirs()
    val seed = args[1].toLong(); val cx = args[2].toInt(); val cz = args[3].toInt(); val maxLevel = args[4].toInt()
    val gen = TerrainGenerator(seed)
    val ctor = FarTerrain::class.java.constructors.first()
    val far = ctor.newInstance(gen, newColorField(gen)) as FarTerrain
    val build = FarTerrain::class.java.declaredMethods.first { it.name == "buildTile" && it.parameterCount == 3 }
    build.isAccessible = true

    val verts = ArrayList<FloatArray>(); val idx = ArrayList<IntArray>()
    var vcount = 0; var icount = 0
    val json = StringBuilder("[")
    for (level in 1..maxLevel) {
        val inner = FarTerrain.drawInner(level); val outer = FarTerrain.drawOuter(level)
        val size = FarTerrain.tileBlocks(level)
        val reach = minOf(outer, 3000f) + size
        val tx0 = Math.floorDiv((cx - reach).toInt(), size); val tx1 = Math.floorDiv((cx + reach).toInt(), size)
        val tz0 = Math.floorDiv((cz - reach).toInt(), size); val tz1 = Math.floorDiv((cz + reach).toInt(), size)
        val firstIndex = icount; var tiles = 0
        val t0 = System.nanoTime()
        for (tz in tz0..tz1) for (tx in tx0..tx1) {
            // skip tiles wholly outside the ring
            val x0 = tx * size; val z0 = tz * size
            val nx = (cx.toFloat()).coerceIn(x0.toFloat(), (x0 + size).toFloat()); val nz = (cz.toFloat()).coerceIn(z0.toFloat(), (z0 + size).toFloat())
            val near = Math.hypot((nx - cx).toDouble(), (nz - cz).toDouble())
            val fx = if (cx - x0 > size / 2) x0.toDouble() else (x0 + size).toDouble(); val fz = if (cz - z0 > size / 2) z0.toDouble() else (z0 + size).toDouble()
            val far2 = Math.hypot(fx - cx, fz - cz)
            if (near >= outer + 2 || far2 < inner - 2) continue
            val tile = build.invoke(far, level, tx, tz)
            val water = tile.javaClass.getMethod("getWater").invoke(tile) as MeshData
            if (water.isEmpty()) continue
            verts.add(water.vertexData.copyOf(water.vertexCount * 6)); idx.add(IntArray(water.indices.size) { water.indices[it] + vcount })
            vcount += water.vertexCount; icount += water.indices.size; tiles++
        }
        json.append("{\"level\":$level,\"first\":$firstIndex,\"count\":${icount - firstIndex},\"inner\":$inner,\"outer\":$outer,\"tiles\":$tiles},")
        println(String.format("level %d: ring %.0f..%.0f  %d water tiles  built in %.1f s  (%d indices)", level, inner, outer, tiles, (System.nanoTime() - t0) / 1e9, icount - firstIndex))
    }
    if (json.endsWith(",")) json.setLength(json.length - 1)
    json.append("]")
    val vb = ByteBuffer.allocate(vcount * 24).order(ByteOrder.LITTLE_ENDIAN)
    for (v in verts) for (f in v) vb.putFloat(f)
    val ib = ByteBuffer.allocate(icount * 4).order(ByteOrder.LITTLE_ENDIAN)
    for (a in idx) for (i in a) ib.putInt(i)
    File(out, "farwater.vtx").writeBytes(vb.array()); File(out, "farwater.idx").writeBytes(ib.array()); File(out, "farwater.json").writeText(json.toString())
    println("wrote far water: $vcount verts, $icount indices")
}
