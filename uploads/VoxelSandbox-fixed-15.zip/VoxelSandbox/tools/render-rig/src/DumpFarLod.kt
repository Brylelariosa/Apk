package rig

import com.voxelsandbox.game.world.far.FarTerrain
import com.voxelsandbox.game.world.generation.TerrainGenerator
import com.voxelsandbox.game.world.mesh.MeshData
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

private fun newColorField(gen: TerrainGenerator): Any {
    val paletteClass = Class.forName("com.voxelsandbox.game.world.color.BiomePalette")
    val companion = paletteClass.getField("Companion").get(null)
    val palette = companion.javaClass.getMethod("fromTiles").invoke(companion)
    val fieldClass = Class.forName("com.voxelsandbox.game.world.color.BiomeColorField")
    return fieldClass.constructors.first().newInstance(gen.climate, gen.shape, palette)
}

/**
 * Builds the real far tiles of every level a view from ([eyeX], [eyeZ]) out to [radius] blocks needs (the tiles that
 * touch each level's ring, as the renderer draws it) and writes them, level by level, for the rig's LOD renderer
 * (lod.js): far.vtx / far.idx (the floats of one vertex are in lod.json), lod.json (per level: where its indices are, and the ring and slide
 * parameters the renderer would set), and the real far shaders of the tree the classes were compiled from.
 *
 * usage: DumpFarLod <outDir> <seed> <eyeX> <eyeZ> <radius> <levels, comma separated> [fine]
 */
fun main(args: Array<String>) {
    val out = File(args[0]); out.mkdirs()
    val seed = args[1].toLong()
    val ex = args[2].toFloat(); val ez = args[3].toFloat(); val radius = args[4].toFloat()
    val levels = args[5].split(",").map { it.toInt() }
    val fine = args.size > 6 && args[6] == "fine"

    val gen = TerrainGenerator(seed)
    val ctor = FarTerrain::class.java.constructors.first()
    val far: FarTerrain = if (ctor.parameterCount == 1) ctor.newInstance(gen) as FarTerrain
    else ctor.newInstance(gen, newColorField(gen)) as FarTerrain
    val build = FarTerrain::class.java.declaredMethods.first { it.name == "buildTile" && it.parameterCount == 3 }
    build.isAccessible = true
    FarTerrain.configureFineRing(if (fine) 160f else 0f, fine)

    val vbs = ArrayList<FloatArray>(); val ibs = ArrayList<IntArray>()
    var base = 0
    val json = StringBuilder("{\"levels\":[")
    var firstIdx = 0
    var totalTris = 0
    var totalBytes = 0L
    var fpv = 0
    for (level in levels) {
        val inner = FarTerrain.drawInner(level)
        val outer = if (level == FarTerrain.LEVELS - 1) radius else minOf(FarTerrain.drawOuter(level), radius)
        if (outer <= 0f || inner >= radius) continue
        val size = FarTerrain.tileBlocks(level)
        val tx0 = Math.floorDiv((ex - outer).toInt(), size); val tx1 = Math.floorDiv((ex + outer).toInt(), size)
        val tz0 = Math.floorDiv((ez - outer).toInt(), size); val tz1 = Math.floorDiv((ez + outer).toInt(), size)
        val levelFirst = firstIdx
        var tiles = 0
        var verts = 0
        val ranges = StringBuilder()
        val t0 = System.nanoTime()
        for (tz in tz0..tz1) for (tx in tx0..tx1) {
            val x0 = (tx * size).toFloat(); val z0 = (tz * size).toFloat()
            val nx = if (ex < x0) x0 else if (ex > x0 + size) x0 + size else ex
            val nz = if (ez < z0) z0 else if (ez > z0 + size) z0 + size else ez
            val near = Math.hypot((ex - nx).toDouble(), (ez - nz).toDouble()).toFloat()
            val fx = maxOf(Math.abs(ex - x0), Math.abs(ex - (x0 + size))); val fz = maxOf(Math.abs(ez - z0), Math.abs(ez - (z0 + size)))
            val farD = Math.hypot(fx.toDouble(), fz.toDouble()).toFloat()
            if (near >= outer || farD <= inner) continue
            val tile = build.invoke(far, level, tx, tz)
            val land = tile.javaClass.getMethod("getLand").invoke(tile) as MeshData
            if (land.isEmpty()) continue
            fpv = land.vertexData.size / land.vertexCount
            vbs.add(land.vertexData.copyOf(land.vertexCount * fpv))
            ibs.add(IntArray(land.indices.size) { land.indices[it] + base })
            if (ranges.isNotEmpty()) ranges.append(",")
            ranges.append("[$tx,$tz,$firstIdx,${land.indices.size}]")
            base += land.vertexCount; firstIdx += land.indices.size
            verts += land.vertexCount; tiles++
        }
        val ms = (System.nanoTime() - t0) / 1e6
        val count = firstIdx - levelFirst
        val last = level == FarTerrain.LEVELS - 1
        val mStart = if (last) 2.0e9f else FarTerrain.morphStart(level)
        val mEnd = if (last) 3.0e9f else maxOf(FarTerrain.drawOuter(level), mStart + 1f)
        if (json.last() != '[') json.append(",")
        json.append("{\"level\":$level,\"first\":$levelFirst,\"count\":$count,\"inner\":$inner,\"outer\":${FarTerrain.drawOuter(level)},\"mStart\":$mStart,\"mEnd\":$mEnd,\"size\":$size,\"tiles\":$tiles,\"verts\":$verts,\"t\":[$ranges]}")
        totalTris += count / 3; totalBytes += verts * fpv * 4L + count * 4L
        println(String.format("level %d: %3d tiles %8d verts %8d tris  ring %.0f..%.0f   %.0f ms to build", level, tiles, verts, count / 3, inner, outer, ms))
    }
    json.append("],\"floats\":$fpv}")
    println("total: $totalTris triangles, ${totalBytes / 1024} KB (every tile of the rings, before any culling)")
    val vb = ByteBuffer.allocate(base * fpv * 4).order(ByteOrder.LITTLE_ENDIAN)
    for (a in vbs) for (f in a) vb.putFloat(f)
    val ib = ByteBuffer.allocate(firstIdx * 4).order(ByteOrder.LITTLE_ENDIAN)
    for (a in ibs) for (v in a) ib.putInt(v)
    File(out, "far.vtx").writeBytes(vb.array())
    File(out, "far.idx").writeBytes(ib.array())
    File(out, "lod.json").writeText(json.toString())
    // Read through reflection: a `const val` would be inlined into this class at compile time, i.e. from whichever
    // tree it was compiled against, not the one it runs against.
    val shaders = Class.forName("com.voxelsandbox.game.gl.Shaders")
    File(out, "vs_far.glsl").writeText(shaders.getField("FAR_VERTEX").get(null) as String)
    File(out, "fs_far.glsl").writeText(shaders.getField("FAR_FRAGMENT").get(null) as String)
}
