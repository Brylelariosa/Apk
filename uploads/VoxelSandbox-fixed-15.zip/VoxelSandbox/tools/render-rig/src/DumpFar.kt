package rig

import com.voxelsandbox.game.gl.Shaders
import com.voxelsandbox.game.world.far.FarTerrain
import com.voxelsandbox.game.world.generation.TerrainGenerator
import com.voxelsandbox.game.world.mesh.MeshData
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** The biome colour field by reflection, so this file also compiles against the tree that has none. */
private fun newColorField(gen: TerrainGenerator): Any {
    val paletteClass = Class.forName("com.voxelsandbox.game.world.color.BiomePalette")
    val companion = paletteClass.getField("Companion").get(null)
    val palette = companion.javaClass.getMethod("fromTiles").invoke(companion)
    val fieldClass = Class.forName("com.voxelsandbox.game.world.color.BiomeColorField")
    return fieldClass.constructors.first().newInstance(gen.climate, gen.shape, palette)
}

/**
 * Builds the REAL distant-terrain tiles (FarTerrain.buildTile, called by reflection) of a square of the world, prints what
 * they weigh and how long they took, and writes them for the WebGL2 renderer of the rig (far.vtx / far.idx, seven floats per
 * vertex, plus the real far shaders).
 *
 * usage: DumpFar <outDir> <seed> <centreX> <centreZ> <radius> <levels, comma separated> [stats]
 * Works with the original (one-argument constructor) and the integrated tree (with the biome colour field).
 */
fun main(args: Array<String>) {
    val out = File(args[0]); out.mkdirs()
    val seed = args[1].toLong()
    val cx = args[2].toInt(); val cz = args[3].toInt(); val radius = args[4].toInt()
    val levels = args[5].split(",").map { it.toInt() }
    val statsOnly = args.size > 6 && args[6] == "stats"

    val gen = TerrainGenerator(seed)
    val ctor = FarTerrain::class.java.constructors.first()
    val far: FarTerrain = if (ctor.parameterCount == 1) ctor.newInstance(gen) as FarTerrain
    else ctor.newInstance(gen, newColorField(gen)) as FarTerrain
    val build = FarTerrain::class.java.declaredMethods.first { it.name == "buildTile" && it.parameterCount == 3 }
    build.isAccessible = true

    class Piece(val data: FloatArray, val idx: IntArray, val verts: Int)
    val pieces = ArrayList<Piece>()
    var totalVerts = 0; var totalIdx = 0; var tiles = 0
    val perLevel = HashMap<Int, DoubleArray>() // tiles, verts, indices, ms
    // two passes: the first warms the JIT up (and is the one that is written), the second is timed
    for (pass in 0..1) {
        for (level in levels) {
            val size = FarTerrain.tileBlocks(level)
            val tx0 = Math.floorDiv(cx - radius, size); val tx1 = Math.floorDiv(cx + radius, size)
            val tz0 = Math.floorDiv(cz - radius, size); val tz1 = Math.floorDiv(cz + radius, size)
            for (tz in tz0..tz1) for (tx in tx0..tx1) {
                val t0 = System.nanoTime()
                val tile = build.invoke(far, level, tx, tz)
                val ms = (System.nanoTime() - t0) / 1e6
                val land = tile.javaClass.getMethod("getLand").invoke(tile) as MeshData
                if (pass == 0) {
                    if (land.isEmpty()) continue
                    pieces.add(Piece(land.vertexData, land.indices, land.vertexCount))
                    totalVerts += land.vertexCount; totalIdx += land.indices.size; tiles++
                } else {
                    val s = perLevel.getOrPut(level) { DoubleArray(4) }
                    s[0] += 1.0; s[1] += land.vertexCount.toDouble(); s[2] += land.indices.size.toDouble(); s[3] += ms
                }
            }
        }
    }
    println("far land: $tiles tiles, verts=$totalVerts quads=${totalIdx / 6} bytes=${totalVerts * 28L + totalIdx * 4L}")
    for (level in levels) {
        val s = perLevel[level] ?: continue
        println(String.format("  level %d: %3.0f tiles  %8.0f verts  %8.0f quads  %7.1f KB/tile  %6.1f ms/tile", level, s[0], s[1], s[2] / 6, (s[1] * 28 + s[2] * 4) / s[0] / 1024, s[3] / s[0]))
    }
    if (statsOnly) return

    val vb = ByteBuffer.allocate(totalVerts * 28).order(ByteOrder.LITTLE_ENDIAN)
    val ib = ByteBuffer.allocate(totalIdx * 4).order(ByteOrder.LITTLE_ENDIAN)
    var base = 0
    for (p in pieces) {
        for (i in 0 until p.verts * 7) vb.putFloat(p.data[i])
        for (v in p.idx) ib.putInt(v + base)
        base += p.verts
    }
    File(out, "far.vtx").writeBytes(vb.array())
    File(out, "far.idx").writeBytes(ib.array())
    File(out, "far.json").writeText("{\"verts\":$totalVerts,\"indices\":$totalIdx}")
    File(out, "vs_far.glsl").writeText(Shaders.FAR_VERTEX)
    File(out, "fs_far.glsl").writeText(Shaders.FAR_FRAGMENT)
    println("wrote far scene to $out")
}
