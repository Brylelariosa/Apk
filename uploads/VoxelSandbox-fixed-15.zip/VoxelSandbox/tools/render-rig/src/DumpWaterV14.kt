package rig

import com.voxelsandbox.game.gl.Shaders
import com.voxelsandbox.game.gl.WaterTexture
import java.io.File

/** v14 reference: the old water shaders and the old 16x16 tile, for before/after comparisons. */
fun main(args: Array<String>) {
    val out = File(args[0]); out.mkdirs()
    File(out, "vs_water.glsl").writeText(Shaders.WATER_VERTEX)
    File(out, "fs_water.glsl").writeText(Shaders.WATER_FRAGMENT)
    val m = WaterTexture::class.java.getDeclaredMethod("generate"); m.isAccessible = true
    val bytes = m.invoke(WaterTexture()) as ByteArray
    File(out, "water_tile.bin").writeBytes(bytes)
    println("v14 water tile: ${bytes.size} bytes")
}
