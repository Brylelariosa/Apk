package rig

import com.voxelsandbox.game.gl.Shaders
import com.voxelsandbox.game.gl.WaterPattern
import java.io.File
import java.nio.ByteBuffer

/** Writes what the rig's water pass needs: the REAL water shaders, the wave frames, the tone texture. */
fun main(args: Array<String>) {
    val out = File(args[0]); out.mkdirs()
    File(out, "vs_water.glsl").writeText(Shaders.WATER_VERTEX)
    File(out, "fs_water.glsl").writeText(Shaders.WATER_FRAGMENT)
    val t0 = System.nanoTime()
    val frames = WaterPattern.frames
    val ms = (System.nanoTime() - t0) / 1e6
    val buf = ByteBuffer.allocate(WaterPattern.FRAMES * WaterPattern.SIZE * WaterPattern.SIZE * 4)
    for (f in frames) for (p in f) { buf.put((p shr 16).toByte()); buf.put((p shr 8).toByte()); buf.put(p.toByte()); buf.put((p ushr 24).toByte()) }
    File(out, "water_wave.bin").writeBytes(buf.array())
    File(out, "water_tone.bin").writeBytes(WaterPattern.tone)
    val avg = WaterPattern.average
    File(out, "water_meta.json").writeText("{\"size\":${WaterPattern.SIZE},\"frames\":${WaterPattern.FRAMES},\"toneSize\":${WaterPattern.TONE_SIZE},\"avg\":[${avg[0]},${avg[1]},${avg[2]}]}")
    println("water pattern: ${WaterPattern.FRAMES} frames of ${WaterPattern.SIZE}px generated in ${"%.1f".format(ms)} ms, avg=${avg.joinToString()}")
}
