#!/bin/bash
# usage: build.sh <projdir> <outdir>  -> compiles the project (pure + gl classes need the android stub) and the rig Dump tool
set -e
RIGSRC=/home/claude/work/rig/src/Dump.kt; if [ -n "$WITH_FAR" ]; then RIGSRC="$RIGSRC /home/claude/work/rig/src/DumpFar.kt"; fi
PROJ=$(readlink -f "$1"); OUT=$(readlink -f -m "$2"); mkdir -p "$OUT"
G=$PROJ/app/src/main/java/com/voxelsandbox/game
STD=/home/claude/tools/kotlinc/lib/kotlin-stdlib.jar
AJ=/home/claude/tools/android-platforms/android-34/android.jar
# only the classes the dumper needs (transitively): world/**, gl/{TextureAtlas,BlockTextures,VoxelShader,BlockGrain}, util
FARGREP='/far/\|'
if [ -n "$WITH_FAR" ]; then FARGREP=''; fi
SRC="$(find $G/world $G/util -name '*.kt' | grep -v "/streaming/\|WorldManager.kt\|${FARGREP}FluidSimulator.kt") $G/gl/TextureAtlas.kt $G/gl/BlockTextures.kt $G/gl/VoxelShader.kt $G/gl/BlockGrain.kt $G/gl/TileSources.kt $G/gl/TintTable.kt"
if [ -n "$WITH_FAR" ]; then SRC="$SRC $G/gl/Shaders.kt $G/diag/DiagLog.kt"; fi
/home/claude/tools/build/kc.sh -cp $AJ:$STD -d $OUT $SRC $RIGSRC 2>&1 | grep -v "^warning" | head -40
ls $OUT/rig/DumpKt.class
