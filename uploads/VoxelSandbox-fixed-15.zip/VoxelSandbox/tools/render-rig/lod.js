// usage: node lod.js <sceneDir> <jobs.json> <outDir>
// scene: far.vtx far.idx lod.json vs_far.glsl fs_far.glsl [atlas.bin meta.json: only for the palette-key shaders of the old format]
// jobs.json: {"width":1280,"height":640,"frames":[{"name":"a","eye":[x,y,z],"yaw":0,"pitch":-0.2,"fov":60,"far":20000,"fog":[8000,16000],"fogColor":[.62,.78,.96],
//    "levels":[1,2,3],"morph":true,"bands":true,"debug":"level"|"normal"|null,"grow":0}]}
const { chromium } = require('playwright'); const fs = require('fs'), path = require('path');
(async () => {
  const [sceneDir, jobsFile, outDir] = process.argv.slice(2);
  const jobs = JSON.parse(fs.readFileSync(jobsFile)); fs.mkdirSync(outDir, { recursive: true });
  const rd = (n, enc) => fs.readFileSync(path.join(sceneDir, n), enc);
  const has = n => fs.existsSync(path.join(sceneDir, n));
  const cfg = { width: jobs.width, height: jobs.height, vs: rd('vs_far.glsl', 'utf8'), fs: rd('fs_far.glsl', 'utf8'), lod: JSON.parse(rd('lod.json', 'utf8')),
    atlas: has('atlas.bin') ? rd('atlas.bin').toString('base64') : null, meta: has('meta.json') ? JSON.parse(rd('meta.json', 'utf8')) : null };
  const browser = await chromium.launch({ args: ['--use-angle=swiftshader', '--use-gl=angle', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--enable-webgl'] });
  const page = await browser.newPage(); page.on('console', m => console.log('[page]', m.text())); page.on('pageerror', e => console.log('[pageerror]', e.message));
  await page.setContent('<html><body style="margin:0"></body></html>');
  await page.addScriptTag({ path: path.join(__dirname, 'lod_page.js') });
  // The tile data goes over in pieces: one giant string kills the page.
  for (const [kind, file] of [['vtx', 'far.vtx'], ['idx', 'far.idx']]) {
    const buf = rd(file); const PIECE = 6 * 1024 * 1024;
    for (let o = 0; o < buf.length; o += PIECE) await page.evaluate(([k, b]) => window.lodPush(k, b), [kind, buf.subarray(o, Math.min(buf.length, o + PIECE)).toString('base64')]);
  }
  try { await page.evaluate(c => window.lodSetup(c), cfg); } catch (e) { console.log('SETUP FAILED:', e.message.split('\n').slice(0, 12).join('\n')); await browser.close(); process.exit(3); }
  const t0 = Date.now();
  for (const f of jobs.frames) {
    const s = await page.evaluate(([f, W, H]) => window.lodRender(f, W, H), [f, jobs.width, jobs.height]);
    fs.writeFileSync(path.join(outDir, f.name + '.rgba'), Buffer.from(s, 'base64'));
  }
  console.log('frames', jobs.frames.length, 'in', ((Date.now() - t0) / 1000).toFixed(1), 's');
  await browser.close();
})();
