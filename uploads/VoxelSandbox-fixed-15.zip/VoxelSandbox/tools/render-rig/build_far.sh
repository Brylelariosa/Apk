#!/bin/bash
# usage: build_far.sh <projdir> <outdir> [extra .kt files...]  -> compiles only what the far-terrain tools need
# (works for the v14 tree and the integrated one); default extra source: src/DumpFar.kt
# env: KOTLINC (default kotlinc), ANDROID_JAR (android-34 stubs, required), STDLIB (kotlin-stdlib.jar)
set -e
HERE=$(cd "$(dirname "$0")" && pwd)
KOTLINC=${KOTLINC:-kotlinc}
: "${ANDROID_JAR:?set ANDROID_JAR to an android.jar (API 34 stubs)}"
STD=${STDLIB:-$(dirname "$(readlink -f "$(which "$KOTLINC")")")/../lib/kotlin-stdlib.jar}
PROJ=$(readlink -f "$1"); OUT=$(readlink -f -m "$2"); shift 2; mkdir -p "$OUT"
EXTRA="$@"; if [ -z "$EXTRA" ]; then EXTRA=$HERE/src/DumpFar.kt; fi
G=$PROJ/app/src/main/java/com/voxelsandbox/game
AJ=$ANDROID_JAR
SRC="$(find $G/world $G/util -name '*.kt' | grep -v '/streaming/\|WorldManager.kt\|FluidSimulator.kt') $G/gl/TextureAtlas.kt $G/gl/BlockTextures.kt $G/gl/BlockGrain.kt $G/gl/Shaders.kt $G/diag/DiagLog.kt"
for f in WaterPattern WaterAnimation FrameState; do if [ -f $G/gl/$f.kt ]; then SRC="$SRC $G/gl/$f.kt"; fi; done
for f in TileSources TintTable; do if [ -f $G/gl/$f.kt ]; then SRC="$SRC $G/gl/$f.kt"; fi; done
"$KOTLINC" -jvm-target 17 -nowarn -cp $AJ:$STD -d $OUT $SRC $EXTRA 2>&1 | grep -v "^warning" | head -40
