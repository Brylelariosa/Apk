# Plain-JVM checks

The game has no test dependencies on purpose (see `app/build.gradle.kts`), so these checks are plain Kotlin
programs with a `main`, compiled with `kotlinc` against the Android stub jar. They test the pure logic only;
nothing here touches a phone or the Gradle build.

    KOTLINC=/path/to/kotlinc  ANDROID_JAR=/path/to/android-34/android.jar  ./run.sh

- `CreativeTests.kt` — creative catalogue, search, icons, hotbar, save format (v4 migration, damaged files),
  flight maths and collision, placement rules. Prints PASS/FAIL per check, exit code 1 on any failure.
- `IconSheet.kt` — draws every inventory icon into a PNG (`./run.sh sheet out.png`).
- `AtlasHash.kt` — prints a SHA-256 over all mip levels of the texture atlas (compare before/after a change).
- `BiomeColorTests.kt` (run with `./run_biome.sh`) — the biome colour field, the table of tinted tiles, the layout of the GPU colour map, and
  the colours of the distant terrain (17 checks, about 45 s; the field checks sample a few hundred thousand points).
- `WaterTests.kt` (run with `./run_water.sh`) — the water: the pixel art of the wave animation (palette, shares, no lone pixels, seamless tile and
  loop, calm per-frame change, checksum), the time and place maths that pin it to the world, what the water shaders may read (no biome input) and what
  they cost (including that the distant land and water shaders carry one and the same clip/dither snippet), and the real chunk mesher joining water
  across chunk borders (lake, stream, deep ocean, a negative control). 29 checks, about 1 minute.
- `FarTerrainTests.kt` (run with `./run_far.sh`; needs `STDLIB=.../kotlin-stdlib.jar` when `KOTLINC` is a wrapper script) — the distant terrain: the ladder of
  levels (steps double, grids nest, ring and column sizes fit), height rounding, the vertex format, tile fields agreeing on shared borders, tops and
  walls covering every drawn column once, slide targets equal to the next level's columns, merge rules on synthetic tiles, bit-identical tiles whatever
  the build order, reference tile bytes, a triangle bound per column, and the stand-ins for missing tiles (ancestor maths, finest resident wins,
  ring enumeration against brute force, leading-edge holes always covered). 40 checks, about 1 minute.

The generator has its own, separate check (bit-identical to v14, and the benchmark): see `../gen-check/README.md`.
