package tests

import com.voxelsandbox.game.gl.FrameState
import com.voxelsandbox.game.gl.Shaders
import com.voxelsandbox.game.gl.TextureAtlas
import com.voxelsandbox.game.gl.WaterAnimation
import com.voxelsandbox.game.gl.WaterPattern
import com.voxelsandbox.game.world.BlockType
import com.voxelsandbox.game.world.Chunk
import com.voxelsandbox.game.world.ChunkPos
import com.voxelsandbox.game.world.Fluid
import com.voxelsandbox.game.world.World
import com.voxelsandbox.game.world.WorldConfig
import com.voxelsandbox.game.world.mesh.ChunkMesher
import com.voxelsandbox.game.world.mesh.MeshData
import java.util.Random
import java.util.zip.CRC32
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max

/**
 * Plain-Kotlin checks of the water: the pixel art of the wave animation, the maths that pins it to the world and
 * steps it through time, what the water shaders may and may not read, and how the real chunk mesher joins water
 * across chunk borders. Prints PASS/FAIL per check and exits 1 on any failure; "measured" lines are numbers,
 * not checks. Nothing here needs a GPU: what a GPU does with these inputs was looked at with the software
 * renderer in tools/render-rig, which is a different kind of evidence (see docs/water.md).
 */
private var failures = 0
private var passed = 0

private fun check(name: String, body: () -> Unit) {
    try {
        body()
        passed++
        println("PASS  $name")
    } catch (t: Throwable) {
        failures++
        println("FAIL  $name -> ${t.javaClass.simpleName}: ${t.message}")
    }
}

private fun require(cond: Boolean, msg: () -> String) {
    if (!cond) throw AssertionError(msg())
}

/** Checksum of every pixel of every frame plus the tone texture. If the pattern is changed on purpose (a tuned
 *  constant in WaterPattern), the new value is printed by the failing check and goes here. */
private const val PATTERN_CRC = 0x92A11052L

fun main() {
    patternChecks()
    animationChecks()
    shaderChecks()
    meshChecks()
    println()
    println("water tests: $passed passed, $failures failed")
    if (failures > 0) System.exit(1)
}

// ===================================================================================== the pixel art

private fun patternChecks() {
    val t0 = System.nanoTime()
    val frames = WaterPattern.frames
    val tone = WaterPattern.tone
    val average = WaterPattern.average
    val ms = (System.nanoTime() - t0) / 1e6
    println("measured: first use of WaterPattern (cold JVM, interpreter and JIT warming up): %.0f ms".format(ms))

    val size = WaterPattern.SIZE
    val n = size * size
    val classes = Array(WaterPattern.FRAMES) { f -> IntArray(n) { WaterPattern.classOf(frames[f][it]) } }

    check("pattern: ${WaterPattern.FRAMES} frames of ${size}x$size, 16 pixels to the block, one repeat every ${WaterPattern.PERIOD_BLOCKS} blocks") {
        require(frames.size == WaterPattern.FRAMES) { "${frames.size} frames" }
        require(frames.all { it.size == n }) { "a frame has the wrong size" }
        require(WaterPattern.PIXELS_PER_BLOCK == 16) { "not 16 pixels to the block" }
        require(size == WaterPattern.PIXELS_PER_BLOCK * WaterPattern.PERIOD_BLOCKS) { "tile is not a whole number of blocks" }
    }

    check("pattern: every pixel is one of the four blues, with the alpha of its class (0 calm, 128 ripple, 255 crest)") {
        for (f in 0 until WaterPattern.FRAMES) for (i in 0 until n) {
            val c = classes[f][i]
            require(c >= 0) { "frame $f pixel $i has colour %06x, not in the palette".format(frames[f][i] and 0xFFFFFF) }
            val a = frames[f][i] ushr 24
            require(a == WaterPattern.CREST_ALPHA[c]) { "frame $f pixel $i alpha $a for class $c" }
        }
    }

    check("pattern: the four colours cover the share of the pixels they were designed for (within 2 points)") {
        val count = LongArray(4)
        for (f in classes) for (c in f) count[c]++
        val total = (WaterPattern.FRAMES * n).toDouble()
        val shares = DoubleArray(4) { count[it] / total }
        println("measured: colour shares dark/base/light/crest = " + shares.joinToString(" / ") { "%.1f %%".format(it * 100) })
        for (c in 0 until 4) {
            require(abs(shares[c] - WaterPattern.SHARES[c]) <= 0.02) { "class $c has ${shares[c]}, designed ${WaterPattern.SHARES[c]}" }
        }
    }

    check("pattern: no lone pixel in any frame (each has a 4-neighbour of its own colour, the tile wraps)") {
        var lone = 0
        for (f in 0 until WaterPattern.FRAMES) {
            val c = classes[f]
            for (y in 0 until size) for (x in 0 until size) {
                val me = c[y * size + x]
                val l = c[y * size + (x + size - 1) % size]
                val r = c[y * size + (x + 1) % size]
                val u = c[((y + size - 1) % size) * size + x]
                val d = c[((y + 1) % size) * size + x]
                if (me != l && me != r && me != u && me != d) lone++
            }
        }
        require(lone == 0) { "$lone lone pixels" }
    }

    check("pattern: the tile is seamless in space (the wrap-around seam is no busier than the inside)") {
        var seamX = 0L; var innerX = 0L; var seamY = 0L; var innerY = 0L
        for (f in 0 until WaterPattern.FRAMES) {
            val c = classes[f]
            for (y in 0 until size) for (x in 0 until size) {
                val me = c[y * size + x]
                val right = c[y * size + (x + 1) % size]
                val down = c[((y + 1) % size) * size + x]
                if (me != right) { if (x == size - 1) seamX++ else innerX++ }
                if (me != down) { if (y == size - 1) seamY++ else innerY++ }
            }
        }
        val perColumnSeam = seamX / (WaterPattern.FRAMES * size).toDouble()
        val perColumnInner = innerX / (WaterPattern.FRAMES * size * (size - 1).toDouble())
        val perRowSeam = seamY / (WaterPattern.FRAMES * size).toDouble()
        val perRowInner = innerY / (WaterPattern.FRAMES * size * (size - 1).toDouble())
        println("measured: neighbour pairs of a different colour: across the x seam %.3f, inside %.3f; across the y seam %.3f, inside %.3f"
            .format(perColumnSeam, perColumnInner, perRowSeam, perRowInner))
        require(perColumnSeam <= perColumnInner * 1.6) { "x seam is busier than the inside" }
        require(perRowSeam <= perRowInner * 1.6) { "y seam is busier than the inside" }
    }

    check("pattern: it animates calmly and the loop closes (every step, the last one included, changes a few percent of the pixels)") {
        val changed = DoubleArray(WaterPattern.FRAMES)
        for (f in 0 until WaterPattern.FRAMES) {
            val a = classes[f]
            val b = classes[(f + 1) % WaterPattern.FRAMES]
            var diff = 0
            for (i in 0 until n) if (a[i] != b[i]) diff++
            changed[f] = diff / n.toDouble()
        }
        val mean = changed.average()
        val max = changed.max()
        val min = changed.min()
        println("measured: share of pixels that change per frame step: mean %.1f %%, min %.1f %%, max %.1f %%; the closing step (last to first) %.1f %%"
            .format(mean * 100, min * 100, max * 100, changed[WaterPattern.FRAMES - 1] * 100))
        require(min > 0.01) { "a step that hardly changes anything: $min" }
        require(max < 0.12) { "a step that changes too much at once (shimmer): $max" }
        require(changed[WaterPattern.FRAMES - 1] in mean * 0.5..mean * 1.5) { "the loop's closing step is not like the others" }
    }

    check("pattern: the mean colour is the old flat tile's (73, 126, 211) to within 2 levels, so the sea keeps its colour") {
        val want = intArrayOf(73, 126, 211)
        for (c in 0 until 3) {
            val got = average[c] * 255.0
            require(abs(got - want[c]) <= 2.0) { "channel $c: $got, was ${want[c]}" }
        }
        println("measured: mean colour of the animation = (%.1f, %.1f, %.1f)".format(average[0] * 255, average[1] * 255, average[2] * 255))
    }

    check("pattern: the four blues are close (a calm sea): neighbouring colours differ by at most 30 levels a channel, the whole range by at most 60") {
        for (i in 0 until 4) for (j in 0 until 4) {
            for (shift in intArrayOf(16, 8, 0)) {
                val d = abs(((WaterPattern.PALETTE[i] shr shift) and 0xFF) - ((WaterPattern.PALETTE[j] shr shift) and 0xFF))
                val limit = if (abs(i - j) <= 1) 30 else 60
                require(d <= limit) { "palette entries %06x and %06x differ by $d in channel at shift $shift".format(WaterPattern.PALETTE[i], WaterPattern.PALETTE[j]) }
            }
        }
    }

    check("pattern: identical on every run and device (checksum of all pixels and the tone texture)") {
        val crc = CRC32()
        val bytes = java.nio.ByteBuffer.allocate(4)
        for (f in frames) for (p in f) {
            bytes.clear(); bytes.putInt(p); crc.update(bytes.array(), 0, 4)
        }
        crc.update(tone, 0, tone.size)
        require(crc.value == PATTERN_CRC) { "checksum is 0x%X, expected 0x%X (update PATTERN_CRC if the pattern was changed on purpose)".format(crc.value, PATTERN_CRC) }
    }

    check("tone: a ${WaterPattern.TONE_SIZE}x${WaterPattern.TONE_SIZE} field using the whole 0..255 range that tiles without a seam") {
        val s = WaterPattern.TONE_SIZE
        require(tone.size == s * s) { "size ${tone.size}" }
        var lo = 255; var hi = 0
        for (b in tone) { val v = b.toInt() and 0xFF; if (v < lo) lo = v; if (v > hi) hi = v }
        require(lo == 0 && hi == 255) { "range $lo..$hi" }
        // Neighbouring texels differ little inside the tile; across the wrap seam no more than inside.
        fun at(x: Int, y: Int) = tone[((y + s) % s) * s + (x + s) % s].toInt() and 0xFF
        var inner = 0L; var seam = 0L
        for (y in 0 until s) for (x in 0 until s) {
            val dx = abs(at(x + 1, y) - at(x, y)); val dy = abs(at(x, y + 1) - at(x, y))
            if (x == s - 1) seam += dx else inner += dx
            if (y == s - 1) seam += dy else inner += dy
        }
        val innerMean = inner / (2.0 * s * (s - 1)); val seamMean = seam / (2.0 * s)
        println("measured: tone texture, mean difference of neighbouring texels: inside %.2f, across the seam %.2f (of 255)".format(innerMean, seamMean))
        require(seamMean <= innerMean * 2.0 + 1.0) { "tone seam differs ($seamMean vs $innerMean)" }
    }
}

// ===================================================================================== time and place

private fun animationChecks() {
    val period = FrameState.TEXTURE_TIME_PERIOD

    check("animation: every rate completes a whole number of cycles in the texture clock's wrap, so nothing jumps when it wraps") {
        require((WaterAnimation.FPS * period).toLong() % WaterPattern.FRAMES == 0L) { "frames per wrap is not a multiple of the loop" }
        val flowTiles = WaterAnimation.FLOW_SPEED * period / WaterPattern.PERIOD_BLOCKS
        require(abs(flowTiles - Math.round(flowTiles)) * WaterPattern.PERIOD_BLOCKS < 0.001) { "flow does not travel whole tiles per wrap: $flowTiles" }
        val driftTextures = WaterAnimation.TONE_DRIFT * period / WaterPattern.TONE_PERIOD_BLOCKS
        require(abs(driftTextures - Math.round(driftTextures)) * WaterPattern.TONE_PERIOD_BLOCKS < 0.001) { "tone drift is not whole textures per wrap: $driftTextures" }
    }

    check("animation: frameAt steps once per 1/FPS second through all frames in order and wraps from the last to the first") {
        val seen = IntArray(WaterPattern.FRAMES)
        var prev = WaterAnimation.frameAt(0.0)
        require(prev == 0) { "starts at frame $prev" }
        var t = 0.0
        val dt = 0.0125
        var steps = 0
        while (t < 7.0) {
            t += dt
            val f = WaterAnimation.frameAt(t)
            require(f in 0 until WaterPattern.FRAMES) { "frame $f out of range at t=$t" }
            if (f != prev) {
                require(f == (prev + 1) % WaterPattern.FRAMES) { "jumped from $prev to $f at t=$t" }
                steps++
            }
            seen[f]++
            prev = f
        }
        require(seen.all { it > 0 }) { "a frame never showed" }
        require(steps in 41..43) { "$steps frame changes in 7 s" } // 7 s * 6 fps = 42
        // Just before the wrap and just after it: the last frame, then the first.
        require(WaterAnimation.frameAt(period - 0.01) == WaterPattern.FRAMES - 1) { "last frame before the wrap is ${WaterAnimation.frameAt(period - 0.01)}" }
        require(WaterAnimation.frameAt(0.0) == 0) { "first frame after the wrap" }
    }

    check("animation: the wave tile offset is the camera origin modulo the tile, exact for negative and huge origins") {
        for (o in longArrayOf(0, 1, 7, 8, 9, -1, -7, -8, -9, 123456, -123457, 1_000_000, -1_000_003, 16_000_001)) {
            val p = WaterAnimation.phase(o.toFloat())
            require(p == Math.floorMod(o, WaterPattern.PERIOD_BLOCKS.toLong()).toFloat()) { "origin $o gives $p" }
            require(p >= 0f && p < WaterPattern.PERIOD_BLOCKS) { "origin $o gives $p out of range" }
        }
    }

    check("animation: the pattern is pinned to the world: the tile coordinate of a world point is the same for every camera origin") {
        val rnd = Random(7)
        val tile = WaterPattern.PERIOD_BLOCKS.toLong()
        repeat(20000) {
            val origin = (rnd.nextInt(400_001) - 200_000).toFloat()
            // A world position within 300 blocks of the camera; float32 like the vertex shader's vRel.
            val world = origin + (rnd.nextFloat() * 600f - 300f)
            val rel = world - origin
            val at = rel + WaterAnimation.phase(origin)
            // (at - world) is an exact whole number of blocks here; it has to be a multiple of the tile.
            val whole = Math.round(at.toDouble() - world.toDouble())
            require(abs((at.toDouble() - world.toDouble()) - whole) < 1e-6) { "origin $origin, world $world: offset is not whole" }
            require(Math.floorMod(whole, tile) == 0L) { "origin $origin, world $world: tile coordinate $at is off by $whole blocks" }
        }
    }

    check("animation: when the camera origin steps by a block the tile coordinate of a fixed world point does not change (mod the tile)") {
        for (o in -300..300) {
            val before = 10.37f - o.toFloat() + WaterAnimation.phase(o.toFloat())
            val after = 10.37f - (o + 1).toFloat() + WaterAnimation.phase((o + 1).toFloat())
            val d = Math.floorMod(Math.round((after - before).toDouble() * 1000.0), WaterPattern.PERIOD_BLOCKS * 1000L)
            require(d == 0L) { "origin $o -> ${o + 1} moves the point on the tile by ${d / 1000.0}" }
        }
    }

    check("animation: tone patches stay in 0..256 blocks, drift along +X only, and do not jump at the wrap of the clock") {
        val size = WaterPattern.TONE_PERIOD_BLOCKS.toDouble()
        fun circ(a: Float, b: Float): Double { val d = abs(a - b).toDouble() % size; return minOf(d, size - d) }
        for (o in longArrayOf(0, 5, 255, 256, 257, -3, -256, 99_999)) {
            for (t in doubleArrayOf(0.0, 0.5, 33.3, 500.0, 999.9)) {
                val x = WaterAnimation.tonePhase(o.toFloat(), t, true)
                val z = WaterAnimation.tonePhase(o.toFloat(), t, false)
                require(x >= 0f && x < size) { "x phase $x" }
                require(z >= 0f && z < size) { "z phase $z" }
                require(z == Math.floorMod(o, WaterPattern.TONE_PERIOD_BLOCKS.toLong()).toFloat()) { "z phase drifts: $z" }
            }
            // The patches travel +X: the read position moves back by TONE_DRIFT per second.
            val a = WaterAnimation.tonePhase(o.toFloat(), 10.0, true)
            val b = WaterAnimation.tonePhase(o.toFloat(), 11.0, true)
            require(abs(circ(a, b) - WaterAnimation.TONE_DRIFT) < 1e-3) { "drift per second is ${circ(a, b)}" }
            val wrapEnd = WaterAnimation.tonePhase(o.toFloat(), period, true)
            val wrapStart = WaterAnimation.tonePhase(o.toFloat(), 0.0, true)
            require(circ(wrapEnd, wrapStart) < 1e-3) { "tone jumps by ${circ(wrapEnd, wrapStart)} blocks at the wrap" }
        }
    }

    check("animation: fill() writes the frame state from the origin and the time, nothing else") {
        val st = FrameState()
        st.originX = -37f; st.originY = 62f; st.originZ = 1001f
        WaterAnimation.fill(st, 12.5)
        require(st.waterLayer == WaterAnimation.frameAt(12.5).toFloat()) { "layer ${st.waterLayer}" }
        require(st.waterPhaseX == 3f && st.waterPhaseY == 6f && st.waterPhaseZ == 1f) { "phase ${st.waterPhaseX}, ${st.waterPhaseY}, ${st.waterPhaseZ}" }
        require(st.tonePhaseX == WaterAnimation.tonePhase(-37f, 12.5, true)) { "tone x" }
        require(st.tonePhaseZ == WaterAnimation.tonePhase(1001f, 12.5, false)) { "tone z" }
    }
}

// ===================================================================================== the shaders

private fun shaderChecks() {
    val fragment = Shaders.WATER_FRAGMENT
    val vertex = Shaders.WATER_VERTEX

    fun uniforms(src: String): Set<String> =
        Regex("""(?m)^\s*uniform\s+(?:\w+\s+)*\w+\s+(\w+)\s*;""").findAll(src).map { it.groupValues[1] }.toSet()

    check("shader: water reads only the camera, the clock, the wave and tone textures, fog and the hand-over: no biome or colour-map input exists") {
        val allowedFragment = setOf(
            "uWaterTex", "uWaterTone", "uCover", "uTime", "uWaterLayer", "uWaterPhase", "uTonePhase", "uWaterAvg",
            "uEyeRel", "uFogColor", "uFogStart", "uFogEnd", "uVoxel", "uSide", "uCenter", "uBand", "uSkip",
            // where a stand-in for a missing distant tile may draw, and which share of the screen-space noise a fading tile
            // keeps (see Shaders.CLIP_AND_DITHER): geometry and screen position, never a colour
            "uClip", "uDither"
        )
        val got = uniforms(fragment)
        require(got == allowedFragment) { "fragment uniforms differ: extra ${got - allowedFragment}, missing ${allowedFragment - got}" }
        require(uniforms(vertex) == setOf("uViewProj", "uCamOrigin")) { "vertex uniforms ${uniforms(vertex)}" }
        for (src in listOf(fragment, vertex)) {
            require(!Regex("(?i)biome|tint(?!\\w)|colormap").containsMatchIn(src.replace(Regex("//[^\n]*"), ""))) { "a biome/colour-map name is used" }
        }
        // Every vertex attribute: position, depth+flow, flow Z. No colour attribute exists to carry a biome colour.
        val attributes = Regex("""layout\(location\s*=\s*\d+\)\s*in\s+\w+\s+(\w+)""").findAll(vertex).map { it.groupValues[1] }.toList()
        require(attributes == listOf("aPosition", "aData", "aFlowZ")) { "vertex attributes $attributes" }
    }

    check("shader: distant land and distant water share one clip/dither snippet and both discard on it before they shade") {
        val land = Shaders.FAR_FRAGMENT
        fun snippet(src: String): String {
            val from = src.indexOf("bool clippedOut")
            require(from >= 0) { "no clippedOut() in the shader" }
            val end = src.indexOf("void main()", from)
            require(end > from) { "no main() after the clip code" }
            return src.substring(from, end).trim()
        }
        require(snippet(land) == snippet(fragment)) { "the land and water fragment shaders carry different clip/dither code" }
        for ((name, src) in listOf("land" to land, "water" to fragment)) {
            val body = src.substring(src.indexOf("void main()")).replace(Regex("//[^\n]*"), "")
            val first = body.substringAfter("{").trim().lineSequence().first().trim()
            require(first == "if (clippedOut(vWorld.xz)) discard;") { "$name: main() does not start with the clip test: '$first'" }
            require(Regex("""if \(ditheredOut\(\)\) discard;""").findAll(body).count() == 1) { "$name: expected exactly one dither discard" }
            require(body.indexOf("ditheredOut") < body.indexOf("fragColor =")) { "$name: the dither test comes after the colour is written" }
        }
    }

    check("shader: the water fragment shader does two texture fetches (wave, tone) and no per-pixel trigonometry") {
        val code = fragment.replace(Regex("//[^\n]*"), "")
        val fetches = Regex("""\btexture\s*\(""").findAll(code).count()
        require(fetches == 2) { "$fetches texture() calls" }
        for (fn in listOf("sin", "cos", "tan", "pow", "atan")) {
            require(!Regex("""\b$fn\s*\(""").containsMatchIn(code)) { "$fn() is used per pixel" }
        }
    }

    check("shader: the tile size, tone size and flow speed written into the GLSL are the Kotlin constants") {
        fun define(name: String): Double {
            val m = Regex("""#define\s+$name\s+([0-9.]+)""").find(fragment) ?: throw AssertionError("no #define $name")
            return m.groupValues[1].toDouble()
        }
        require(define("TILE_BLOCKS") == WaterPattern.PERIOD_BLOCKS.toDouble()) { "TILE_BLOCKS ${define("TILE_BLOCKS")}" }
        require(define("TONE_BLOCKS") == WaterPattern.TONE_PERIOD_BLOCKS.toDouble()) { "TONE_BLOCKS ${define("TONE_BLOCKS")}" }
        require(define("FLOW_SPEED") == WaterAnimation.FLOW_SPEED.toString().toDouble()) { "FLOW_SPEED ${define("FLOW_SPEED")}" }
    }

    check("shader: the wave fades to the animation's mean colour far away and the shore foam only shows near the player") {
        val code = fragment.replace(Regex("//[^\n]*"), "")
        require(code.contains("mix(uWaterAvg, wave.rgb, near)")) { "no fade to the mean colour" }
        require(Regex("""shore\s*\*\s*wave\.a\s*\*\s*near""").containsMatchIn(code)) { "foam does not depend on distance" }
    }
}

// ===================================================================================== water across chunk borders

/** One water quad of a mesh (four corners, vertex order as the mesher wrote them) and which chunk's mesh it came from. */
private class WaterQuad(val chunkX: Int, val chunkZ: Int, val x: FloatArray, val y: FloatArray, val z: FloatArray, val depth: FloatArray) {
    /** The mesher marks the side faces of water with a depth of -1; surfaces carry the depth below them. */
    val isSide get() = depth[0] < 0f
    val xMin get() = x.min()
    val xMax get() = x.max()
    val zMin get() = z.min()
    val zMax get() = z.max()
    fun covers(px: Float, pz: Float) = px >= xMin && px <= xMax && pz >= zMin && pz <= zMax
}

/** Every water quad that meshing chunk ([cx], [cz]) produces, all of its sub-chunks. */
private fun waterQuads(world: World, atlas: TextureAtlas, cx: Int, cz: Int): List<WaterQuad> {
    val out = ArrayList<WaterQuad>()
    val stride = MeshData.FLOATS_PER_VERTEX
    for (s in 0 until WorldConfig.SUBCHUNKS_PER_CHUNK) {
        val m = ChunkMesher.buildSubChunkMesh(world, cx, cz, s, atlas, true, true).water
        val f = m.vertexData
        var v = 0
        while (v < m.vertexCount) {
            // Water vertex: x, y, z, depth (or -1 for a side face), flow x, flow z.
            out.add(WaterQuad(cx, cz,
                FloatArray(4) { f[(v + it) * stride] }, FloatArray(4) { f[(v + it) * stride + 1] },
                FloatArray(4) { f[(v + it) * stride + 2] }, FloatArray(4) { f[(v + it) * stride + 3] }))
            v += 4
        }
    }
    return out
}

private fun meshAll(world: World, atlas: TextureAtlas, chunkXs: IntRange, chunkZs: IntRange, skip: Set<Pair<Int, Int>> = emptySet()): List<WaterQuad> {
    val out = ArrayList<WaterQuad>()
    for (cz in chunkZs) for (cx in chunkXs) if ((cx to cz) !in skip) out.addAll(waterQuads(world, atlas, cx, cz))
    return out
}

/** A flat test world: chunks [chunkXs] x [chunkZs] (those not in [skip]), each column stone up to its floor and, if
 *  [column] says so, source water above that up to its water level. */
private fun buildWorld(chunkXs: IntRange, chunkZs: IntRange, skip: Set<Pair<Int, Int>> = emptySet(), column: (Int, Int) -> IntArray): World {
    val world = World()
    for (cz in chunkZs) for (cx in chunkXs) {
        if ((cx to cz) in skip) continue
        val chunk = Chunk(ChunkPos(cx, cz))
        for (lz in 0 until 16) for (lx in 0 until 16) {
            val spec = column(cx * 16 + lx, cz * 16 + lz)
            val floor = spec[0]
            val top = spec[1]
            for (y in 0..floor) chunk.setBlock(lx, y, lz, BlockType.STONE)
            for (y in floor + 1..top) chunk.setBlock(lx, y, lz, BlockType.WATER)
            chunk.heightMap[lz * 16 + lx] = floor.toShort()
        }
        world.putChunk(chunk)
    }
    return world
}

private const val LAKE_X0 = -20
private const val LAKE_X1 = 20
private const val LAKE_Z0 = -6
private const val LAKE_Z1 = 6
private val CHUNKS_X = -2..1
private val CHUNKS_Z = -1..1

/** A lake 40 x 12 blocks that crosses the chunk borders x = -16, 0, 16 and z = 0, [depth] blocks deep, with land two blocks above it. */
private fun lakeWorld(depth: Int, skip: Set<Pair<Int, Int>> = emptySet()): World =
    buildWorld(CHUNKS_X, CHUNKS_Z, skip) { wx, wz ->
        if (wx in LAKE_X0 until LAKE_X1 && wz in LAKE_Z0 until LAKE_Z1) intArrayOf(64 - depth, 64) else intArrayOf(66, 66)
    }

private fun oceanWorld(depth: Int): World = buildWorld(CHUNKS_X, CHUNKS_Z) { _, _ -> intArrayOf(64 - depth, 64) }

private fun vertexKey(x: Float, y: Float, z: Float): String = "${x.toInt()},${z.toInt()},${floor(y).toInt()}"

/** For every whole-number surface corner that quads of two or more different chunks share: do they agree on the
 *  height and the depth under it? Returns how many such corners there are and the worst disagreement. */
private fun cornerAgreement(quads: List<WaterQuad>): Triple<Int, Float, Float> {
    class Seen(val chunk: Pair<Int, Int>, val y: Float, val depth: Float)
    val map = HashMap<String, MutableList<Seen>>()
    for (q in quads) {
        if (q.isSide) continue
        for (i in 0 until 4) {
            if (q.x[i] != Math.rint(q.x[i].toDouble()).toFloat() || q.z[i] != Math.rint(q.z[i].toDouble()).toFloat()) continue
            map.getOrPut(vertexKey(q.x[i], q.y[i], q.z[i])) { ArrayList() }.add(Seen(q.chunkX to q.chunkZ, q.y[i], q.depth[i]))
        }
    }
    var shared = 0
    var worstY = 0f
    var worstDepth = 0f
    for (list in map.values) {
        if (list.map { it.chunk }.toSet().size < 2) continue
        shared++
        for (a in list) for (b in list) {
            worstY = max(worstY, abs(a.y - b.y))
            worstDepth = max(worstDepth, abs(a.depth - b.depth))
        }
    }
    return Triple(shared, worstY, worstDepth)
}

/** The tint step of the water shader (depth -> 0..1), to say what a depth disagreement means on screen. */
private fun depthK(depth: Float) = Math.sqrt((depth / 8f).coerceIn(0f, 1f).toDouble())

private fun meshChecks() {
    val atlas = TextureAtlas()
    val surface = 64f + Fluid.heightOf(Fluid.SOURCE)

    // ---- a calm lake of unmerged quads (shallow water is never merged)
    val lake = lakeWorld(4)
    val lakeQuads = meshAll(lake, atlas, CHUNKS_X, CHUNKS_Z)

    check("chunk borders, calm lake: the surface corners that two chunks share have the same height and depth") {
        val (shared, dy, dd) = cornerAgreement(lakeQuads)
        println("measured: calm lake, $shared surface corners shared by two or more chunks: worst height difference $dy, worst depth difference $dd")
        require(shared >= 40) { "only $shared shared corners: the test is not looking at the borders" }
        require(dy == 0f && dd == 0f) { "height differs by $dy, depth by $dd" }
    }

    check("chunk borders, calm lake: one level surface (every corner at y = 64.875), no water side face anywhere") {
        val tops = lakeQuads.filter { !it.isSide }
        require(tops.isNotEmpty()) { "no surface at all" }
        for (q in tops) for (i in 0 until 4) require(q.y[i] == surface) { "a corner at ${q.y[i]}" }
        val sides = lakeQuads.count { it.isSide }
        require(sides == 0) { "$sides side faces: water draws a wall against water or rock" }
    }

    check("chunk borders, calm lake: the surface has no hole and no doubled layer across any chunk border") {
        var points = 0
        // Cell-interior sample points (off every cell edge), over the whole lake.
        var x = LAKE_X0 + 0.37f
        while (x < LAKE_X1) {
            var z = LAKE_Z0 + 0.61f
            while (z < LAKE_Z1) {
                val n = lakeQuads.count { !it.isSide && it.covers(x, z) }
                require(n == 1) { "$n surface layers at ($x, $z)" }
                points++
                z += 1f
            }
            x += 1f
        }
        // And along the borders themselves: points a hair either side of x = -16, 0, 16 and z = 0.
        for (b in intArrayOf(-16, 0, 16)) {
            var z = LAKE_Z0 + 0.5f
            while (z < LAKE_Z1) {
                for (dx in floatArrayOf(-0.001f, 0.001f)) {
                    require(lakeQuads.any { !it.isSide && it.covers(b + dx, z) }) { "hole at (${b + dx}, $z)" }
                    points++
                }
                z += 0.5f
            }
        }
        var xb = LAKE_X0 + 0.5f
        while (xb < LAKE_X1) {
            for (dz in floatArrayOf(-0.001f, 0.001f)) {
                require(lakeQuads.any { !it.isSide && it.covers(xb, 0f + dz) }) { "hole at ($xb, $dz)" }
                points++
            }
            xb += 0.5f
        }
        println("measured: calm lake, $points sample points checked for holes and double layers")
    }

    // ---- a stream with flowing water of changing fill, along the border x = 0
    val stream = buildWorld(CHUNKS_X, CHUNKS_Z) { _, _ -> intArrayOf(64, 64) }
    for (x in -8..7) for (z in 3..4) {
        val amount = (7 - (x + 8) / 2).coerceAtLeast(1)
        stream.setRaw(x, 65, z, Fluid.rawFor(amount))
    }
    val streamQuads = meshAll(stream, atlas, CHUNKS_X, CHUNKS_Z)

    check("chunk borders, stream of flowing water: corners shared by two chunks agree, and no wall stands across the stream at the border") {
        val (shared, dy, dd) = cornerAgreement(streamQuads)
        println("measured: stream, $shared shared corners: worst height difference $dy, worst depth difference $dd")
        require(shared >= 2) { "only $shared shared corners" }
        require(dy <= 1e-6f && dd <= 1e-6f) { "height differs by $dy, depth by $dd" }
        val tops = streamQuads.count { !it.isSide }
        require(tops >= 16 * 2) { "only $tops surface quads for a 16 x 2 stream" }
        // A wall in the plane x = 0 between two water cells would be a side quad with all four corners at x = 0 and z in the stream.
        val walls = streamQuads.filter { q -> q.isSide && q.x.all { it == 0f } && q.zMin >= 3f && q.zMax <= 5f }
        require(walls.isEmpty()) { "${walls.size} wall quads across the stream at the chunk border" }
        // The stream's own banks and ends do get walls (it is water standing next to air): proves side faces are being produced.
        require(streamQuads.any { it.isSide }) { "no side faces at all: the stream is not being meshed as flowing water" }
    }

    // ---- deep still ocean: merged into big rectangles that overlap their neighbours by a sliver
    val ocean = oceanWorld(12)
    val oceanQuads = meshAll(ocean, atlas, CHUNKS_X, CHUNKS_Z)

    check("chunk borders, deep ocean: merged rectangles leave no crack at any chunk border and overlap by the sliver on both sides") {
        val tops = oceanQuads.filter { !it.isSide }
        val big = tops.count { it.xMax - it.xMin > 3f || it.zMax - it.zMin > 3f }
        require(big > 0) { "no merged rectangles: the ocean was not deep and flat enough to merge" }
        require(oceanQuads.none { it.isSide }) { "side faces in an open ocean" }
        var samples = 0
        val offsets = floatArrayOf(-0.3f, -0.05f, -0.0039f, -0.001f, 0f, 0.001f, 0.0039f, 0.05f, 0.3f)
        // The borders between chunks that both have all their neighbours: x = -16, 0, 16 for z in 2.5..12.5; z = 0 and 16 for x in -12.5..12.5.
        for (b in intArrayOf(-16, 0, 16)) {
            var z = 2.5f
            while (z <= 12.5f) {
                for (d in offsets) {
                    val n = tops.count { it.covers(b + d, z) }
                    require(n >= 1) { "crack at (${b + d}, $z)" }
                    if (abs(d) < 0.0039f) require(tops.filter { it.covers(b + d, z) }.map { it.chunkX }.toSet().size >= 2) { "no overlap of the two chunks' rectangles at (${b + d}, $z)" }
                    samples++
                }
                z += 1f
            }
        }
        for (b in intArrayOf(0, 16)) {
            var x = -12.5f
            while (x <= 12.5f) {
                for (d in offsets) {
                    val n = tops.count { it.covers(x, b + d) }
                    require(n >= 1) { "crack at ($x, ${b + d})" }
                    if (abs(d) < 0.0039f) require(tops.filter { it.covers(x, b + d) }.map { it.chunkZ }.toSet().size >= 2) { "no overlap of the two chunks' rectangles at ($x, ${b + d})" }
                    samples++
                }
                x += 1f
            }
        }
        // Away from the borders a point lies under exactly one layer.
        var x = -12.37f
        while (x < 12f) {
            var z = 2.61f
            while (z < 12f) {
                val n = tops.count { it.covers(x, z) }
                require(n == 1) { "$n layers at ($x, $z)" }
                z += 1.5f
            }
            x += 1.5f
        }
        println("measured: deep ocean, ${tops.size} surface quads of which $big merged rectangles; $samples border sample points without a crack")
    }

    // ---- what the check is worth: meshing next to a chunk that is not there must be caught
    check("negative control: a chunk meshed before its neighbour exists has a different depth along the shared edge (so the border checks can fail)") {
        val withoutNeighbour = lakeWorld(4, skip = setOf(0 to 0))
        val before = waterQuads(withoutNeighbour, atlas, -1, 0)
        val reference = waterQuads(lake, atlas, 0, 0) + waterQuads(lake, atlas, -1, 0)
        val (sharedBefore, _, depthBefore) = cornerAgreement(before + waterQuads(lake, atlas, 0, 0))
        val (sharedAfter, _, depthAfter) = cornerAgreement(reference)
        println("measured: neighbour missing -> worst depth difference at the shared edge $depthBefore (${sharedBefore} corners); neighbour present -> $depthAfter")
        require(sharedBefore > 0 && depthBefore > 0f) { "the border check cannot see a missing neighbour" }
        require(depthAfter == 0f) { "with the neighbour present the edge must agree" }
    }

    // ---- known limit, measured: the chunk that only touches at a corner
    check("measured: a chunk meshed before its DIAGONAL neighbour arrived has one surface corner with a different depth") {
        val noDiagonal = lakeWorld(4, skip = setOf(0 to -1))
        val early = waterQuads(noDiagonal, atlas, -1, 0)
        val full = waterQuads(lake, atlas, -1, 0)
        fun cornerDepthAt(quads: List<WaterQuad>, x: Float, z: Float): Float {
            for (q in quads) {
                if (q.isSide) continue
                for (i in 0 until 4) if (q.x[i] == x && q.z[i] == z) return q.depth[i]
            }
            throw AssertionError("no corner at ($x, $z)")
        }
        val a = cornerDepthAt(early, 0f, 0f)
        val b = cornerDepthAt(full, 0f, 0f)
        // Does any other vertex of that chunk differ?
        var others = 0
        val byKey = HashMap<String, Float>()
        for (q in full) if (!q.isSide) for (i in 0 until 4) byKey[vertexKey(q.x[i], q.y[i], q.z[i])] = q.depth[i]
        for (q in early) if (!q.isSide) for (i in 0 until 4) {
            val want = byKey[vertexKey(q.x[i], q.y[i], q.z[i])] ?: continue
            if (want != q.depth[i] && !(q.x[i] == 0f && q.z[i] == 0f)) others++
        }
        val kEarly = depthK(a); val kFull = depthK(b)
        println("measured: corner (0, 0) of chunk (-1, 0) in a 4-deep lake: depth $a without its diagonal neighbour, $b with it; " +
            "other vertices that differ: $others; the water shader's depth tint steps %.3f -> %.3f (a brightness change of about %.1f %% in red) over one block".format(kEarly, kFull, abs(kEarly - kFull) * 0.48 * 100))
        require(others == 0) { "$others vertices other than the corner differ" }
        require(b == 4f) { "reference depth is $b" }
    }
}
