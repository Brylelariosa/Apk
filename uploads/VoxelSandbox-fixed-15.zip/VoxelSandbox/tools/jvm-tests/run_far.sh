#!/bin/bash
# usage: KOTLINC=... ANDROID_JAR=... ./run_far.sh
# Compiles the world, climate, colour field and distant terrain (no GL, no Android runtime) with FarTerrainTests.kt and runs it.
set -e
HERE=$(cd "$(dirname "$0")" && pwd)
ROOT=$(cd "$HERE/../.." && pwd)
G=$ROOT/app/src/main/java/com/voxelsandbox/game
KOTLINC=${KOTLINC:-kotlinc}
: "${ANDROID_JAR:?set ANDROID_JAR to an android.jar (API 34 stubs)}"
STDLIB=${STDLIB:-$(dirname "$(readlink -f "$(which "$KOTLINC")")")/../lib/kotlin-stdlib.jar}
OUT=$(mktemp -d)
SRC="$(find $G/world $G/util -name '*.kt' | grep -v '/streaming/\|WorldManager.kt\|FluidSimulator.kt')"
SRC="$SRC $G/gl/BlockTextures.kt $G/gl/TileSources.kt $G/gl/TextureAtlas.kt $G/gl/TintTable.kt $G/gl/BlockGrain.kt $G/gl/Shaders.kt $G/gl/WaterPattern.kt $G/gl/WaterAnimation.kt $G/gl/FrameState.kt $G/diag/DiagLog.kt"
"$KOTLINC" -jvm-target 17 -nowarn -cp "$ANDROID_JAR:$STDLIB" -d "$OUT" $SRC "$HERE/FarTerrainTests.kt"
java -cp "$OUT:$STDLIB:$ANDROID_JAR" tests.FarTerrainTestsKt
rm -rf "$OUT"
