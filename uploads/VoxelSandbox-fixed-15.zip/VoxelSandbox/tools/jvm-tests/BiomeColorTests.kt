package tests

import com.voxelsandbox.game.gl.TextureAtlas
import com.voxelsandbox.game.gl.TileSources
import com.voxelsandbox.game.gl.TintTable
import com.voxelsandbox.game.world.AtlasCell
import com.voxelsandbox.game.world.WorldConfig
import com.voxelsandbox.game.world.color.BiomeColorField
import com.voxelsandbox.game.world.color.BiomeColorLayout
import com.voxelsandbox.game.world.color.BiomeColorTiles
import com.voxelsandbox.game.world.color.BiomePalette
import com.voxelsandbox.game.world.far.FarColumnMesher
import com.voxelsandbox.game.world.far.FarGroundColor
import com.voxelsandbox.game.world.far.FarStyler
import com.voxelsandbox.game.world.far.FarTerrain
import com.voxelsandbox.game.world.generation.Biome
import com.voxelsandbox.game.world.generation.SurfaceKind
import com.voxelsandbox.game.world.generation.TerrainGenerator
import java.util.Random
import kotlin.math.abs
import kotlin.math.max

/**
 * Plain-Kotlin checks of the biome colour field and of everything that carries it to the screen: the field itself
 * (deterministic, smooth, aligned with the hard biome rules), the table of which tiles are painted by it, the layout
 * of the GPU colour map, and the distant terrain's colours (tile borders, corner colours, vertex encoding).
 * Prints PASS/FAIL per check and exits 1 on any failure; "measured" lines are numbers, not checks.
 */
private var failures = 0
private var passed = 0

private fun check(name: String, body: () -> Unit) {
    try {
        body()
        passed++
        println("PASS  $name")
    } catch (t: Throwable) {
        failures++
        println("FAIL  $name -> ${t.javaClass.simpleName}: ${t.message}")
    }
}

private fun require(cond: Boolean, msg: () -> String) {
    if (!cond) throw AssertionError(msg())
}

private fun ch(c: Int, shift: Int) = (c shr shift) and 0xFF
private fun maxChannelDiff(a: Int, b: Int) = max(abs(ch(a, 16) - ch(b, 16)), max(abs(ch(a, 8) - ch(b, 8)), abs(ch(a, 0) - ch(b, 0))))
private fun hex(c: Int) = String.format("%06x", c)

private val SEEDS = longArrayOf(0L, 12345L, 20261023L)

fun main() {
    val palette = BiomePalette.fromTiles()
    val gens = SEEDS.map { TerrainGenerator(it) }
    val fields = gens.map { BiomeColorField(it.climate, it.shape, palette) }

    // ---------------------------------------------------------------------------- the field
    check("field: the same place gives the same colour from a fresh generator (pure function of position)") {
        val rnd = Random(1)
        val other = TerrainGenerator(SEEDS[0])
        val otherField = BiomeColorField(other.climate, other.shape, BiomePalette.fromTiles())
        repeat(3000) {
            val x = rnd.nextInt(40000) - 20000 + 0.5; val z = rnd.nextInt(40000) - 20000 + 0.5
            require(fields[0].grassAt(x, z) == otherField.grassAt(x, z)) { "($x, $z) differs" }
        }
    }

    check("field: weights are exactly 0 or 1 away from the borders, so the middle of a climate is the texture's own colour") {
        var plain = 0; var dry = 0; var swamp = 0
        for ((gi, g) in gens.withIndex()) {
            val rnd = Random(2L + gi)
            repeat(40000) {
                val x = rnd.nextInt(60000) - 30000 + 0.5; val z = rnd.nextInt(60000) - 30000 + 0.5
                val ground = g.surfaceHeight(x.toInt(), z.toInt()).toDouble()
                if (ground <= WorldConfig.SEA_LEVEL) return@repeat
                val t0 = g.climate.baseTemperature(x, z); val hum = g.climate.humidity(x, z)
                val te = g.climate.groundTemperature(t0, g.climate.temperatureJitter(x, z), ground)
                val hu = hum + g.climate.humidityJitter(x, z)
                val cold = g.climate.coldness(te); val dr = g.climate.dryness(te, hu)
                val coast = g.shape.coastElevation(x, z)
                val sw = g.climate.swampiness(g.climate.swampWeight(x, z, coast, hum, t0), ground - WorldConfig.SEA_LEVEL)
                val c = fields[gi].grass(x, z, ground, coast, t0, hum)
                if (cold == 0.0 && dr == 0.0 && sw == 0.0) {
                    plain++
                    require(maxChannelDiff(c, fields[gi].neutral) == 0) { "plain at ($x,$z): ${hex(c)} vs ${hex(fields[gi].neutral)}" }
                }
                if (cold == 0.0 && dr == 1.0 && sw == 0.0) {
                    dry++
                    val d = BiomeColorField.pack(palette.dryR, palette.dryG, palette.dryB)
                    require(maxChannelDiff(c, d) == 0) { "savanna at ($x,$z): ${hex(c)} vs ${hex(d)}" }
                }
                if (sw == 1.0 && cold == 0.0) { swamp++; val sc = BiomeColorField.pack(palette.swampR, palette.swampG, palette.swampB); require(maxChannelDiff(c, sc) == 0) { "swamp at ($x,$z): ${hex(c)} vs ${hex(sc)}" } }
            }
        }
        require(plain > 1000 && dry > 100) { "too few samples: plain $plain dry $dry swamp $swamp" }
        println("      measured: $plain plain, $dry dry, $swamp swamp samples sat exactly on a palette colour")
    }

    check("field: colour changes by at most 12 levels per channel between neighbouring blocks at constant height, over 1 200 000 steps (no hard edges)") {
        var worst = 0
        for ((gi, g) in gens.withIndex()) {
            val rnd = Random(3L + gi)
            repeat(400) {
                var x = rnd.nextInt(60000) - 30000 + 0.5; val z = rnd.nextInt(60000) - 30000 + 0.5
                var prev = -1
                repeat(1000) {
                    val t0 = g.climate.baseTemperature(x, z); val hum = g.climate.humidity(x, z)
                    val coast = 6.0 // mid-height land, away from coasts: the swamp rules see a fixed elevation
                    val c = fields[gi].grass(x, z, 72.0, coast, t0, hum)
                    if (prev >= 0) worst = max(worst, maxChannelDiff(prev, c))
                    prev = c
                    x += 1.0
                }
            }
        }
        println("      measured: largest step between neighbouring blocks = $worst levels")
        require(worst <= 12) { "a step of $worst levels between neighbouring blocks" }
    }

    check("field: its borders lie on the hard biome table's borders (dry grass, plain grass, swamp), 0 contradictions") {
        var dryN = 0; var grassN = 0; var swampN = 0
        for ((gi, g) in gens.withIndex()) {
            val rnd = Random(4L + gi)
            repeat(60000) {
                val wx = rnd.nextInt(60000) - 30000; val wz = rnd.nextInt(60000) - 30000
                val h = g.surfaceHeight(wx, wz)
                if (h < WorldConfig.SEA_LEVEL + 1) return@repeat
                val biome = g.biomeAt(wx, wz)
                val x = wx.toDouble(); val z = wz.toDouble()
                val kind = g.climate.surfaceFor(biome, x, z, h.toDouble(), 0.0)
                val t0 = g.climate.baseTemperature(x, z); val hum = g.climate.humidity(x, z)
                val te = g.climate.groundTemperature(t0, g.climate.temperatureJitter(x, z), h.toDouble())
                val hu = hum + g.climate.humidityJitter(x, z)
                val dry = g.climate.dryness(te, hu)
                val coast = g.shape.coastElevation(x, z)
                val sw = g.climate.swampiness(g.climate.swampWeight(x, z, coast, hum, t0), h - WorldConfig.SEA_LEVEL.toDouble())
                if (biome == Biome.SAVANNA) { dryN++; require(dry >= 0.5 - 1e-9) { "savanna at ($wx,$wz) has dryness $dry" } }
                if (biome == Biome.DESERT) require(dry >= 0.5 - 1e-9) { "desert at ($wx,$wz) has dryness $dry" }
                if (kind == SurfaceKind.GRASS && biome != Biome.MOUNTAINS && biome != Biome.SWAMP) {
                    grassN++; require(dry < 0.5 + 1e-9) { "plain grass at ($wx,$wz) has dryness $dry" }
                    require(sw <= 0.5 + 1e-9) { "plain grass at ($wx,$wz) has swampiness $sw" }
                }
                if (biome == Biome.SWAMP && h - WorldConfig.SEA_LEVEL <= 3.0 + 5.0) { swampN++; require(sw > 0.5 - 1e-9) { "swamp at ($wx,$wz) has swampiness $sw" } }
            }
        }
        println("      measured: $dryN savanna, $grassN grass, $swampN swamp columns checked")
        require(dryN > 500 && grassN > 5000) { "too few samples" }
    }

    check("field: terrain-aware -- the same place gives cooler, bluer grass when the ground is higher, and never the reverse") {
        var cooler = 0
        for ((gi, g) in gens.withIndex()) {
            val rnd = Random(9L + gi)
            repeat(30000) {
                val x = rnd.nextInt(60000) - 30000 + 0.5; val z = rnd.nextInt(60000) - 30000 + 0.5
                val t0 = g.climate.baseTemperature(x, z); val hum = g.climate.humidity(x, z)
                val low = fields[gi].grass(x, z, 70.0, 6.0, t0, hum)
                val high = fields[gi].grass(x, z, 150.0, 6.0, t0, hum)
                val teLow = g.climate.groundTemperature(t0, g.climate.temperatureJitter(x, z), 70.0)
                val teHigh = g.climate.groundTemperature(t0, g.climate.temperatureJitter(x, z), 150.0)
                if (g.climate.coldness(teLow) == 0.0 && g.climate.coldness(teHigh) > 0.2 && g.climate.dryness(teLow, hum) == 0.0 && g.climate.dryness(teHigh, hum) == 0.0 &&
                    g.climate.swampWeight(x, z, 6.0, hum, t0) == 0.0) {
                    cooler++
                    require(ch(high, 0) > ch(low, 0) && ch(high, 16) < ch(low, 16)) { "at ($x,$z): low ${hex(low)} high ${hex(high)}" }
                }
            }
        }
        println("      measured: $cooler places checked")
        require(cooler > 50) { "too few places where altitude matters" }
    }

    check("tiles: a tile is the same whenever and in whatever order it is computed, and neighbouring tiles agree at their border") {
        val f = fields[1]
        val a = IntArray(256); val b = IntArray(256); val c = IntArray(256); val s = DoubleArray(1)
        BiomeColorTiles.compute(f, 7, -3, 4, a, s)
        BiomeColorTiles.compute(f, 8, -3, 4, c, s)
        BiomeColorTiles.compute(f, 7, -3, 4, b, s)
        require(a.contentEquals(b)) { "recomputing a tile changed it" }
        var worst = 0
        for (j in 0 until 16) worst = max(worst, maxChannelDiff(a[j * 16 + 15], c[j * 16]))
        require(worst <= 12) { "texels across the tile border differ by $worst" }
        // every texel is the field at its cell centre
        for (j in 0 until 16) for (i in 0 until 16) {
            val wx = ((7 * 16 + i) + 0.5) * 4; val wz = ((-3 * 16 + j) + 0.5) * 4
            require(a[j * 16 + i] == f.grassAt(wx, wz)) { "texel ($i,$j) is not the field at its centre" }
        }
    }

    // ---------------------------------------------------------------------------- the table of painted tiles
    check("tint table: only grass, grass sides, tall grass and leaves are painted; sand, stone, snow, gravel, dirt and water never are") {
        val painted = TintTable.entries.map { it.cell }.toSet()
        val expected = setOf(
            AtlasCell.GRASS_TOP, AtlasCell.GRASS_SIDE, AtlasCell.DRY_GRASS_TOP, AtlasCell.DRY_GRASS_SIDE, AtlasCell.SWAMP_GRASS_TOP,
            AtlasCell.SWAMP_GRASS_SIDE, AtlasCell.TALL_GRASS, AtlasCell.OAK_LEAVES, AtlasCell.BIRCH_LEAVES, AtlasCell.SPRUCE_LEAVES
        )
        require(painted == expected) { "painted cells: $painted" }
        for (never in listOf(AtlasCell.SAND, AtlasCell.STONE, AtlasCell.SNOW, AtlasCell.GRAVEL, AtlasCell.DIRT, AtlasCell.WATER, AtlasCell.OAK_BARK)) {
            require(TintTable.entryFor(never) == null) { "cell $never is painted" }
        }
        val table = TintTable.shaderTable(palette)
        for (cell in 0 until TintTable.CELLS) {
            val alpha = table[cell * 4 + 3]
            require((alpha != 0f) == (cell in painted)) { "shader table disagrees about cell $cell (alpha $alpha)" }
        }
    }

    check("tint table: in the middle of its own climate the factor is 1 (the tile looks as it was drawn)") {
        val table = TintTable.shaderTable(palette)
        val t = table.copyOfRange(AtlasCell.GRASS_TOP * 4, AtlasCell.GRASS_TOP * 4 + 4)
        require(abs(t[0] * palette.grassR / 255f - 1f) < 1e-5 && abs(t[1] * palette.grassG / 255f - 1f) < 1e-5 && abs(t[2] * palette.grassB / 255f - 1f) < 1e-5) { "grass top factor $t" }
        val d = table.copyOfRange(AtlasCell.DRY_GRASS_TOP * 4, AtlasCell.DRY_GRASS_TOP * 4 + 4)
        require(abs(d[0] * palette.dryR / 255f - 1f) < 1e-5) { "dry top factor" }
        val sw = table.copyOfRange(AtlasCell.SWAMP_GRASS_TOP * 4, AtlasCell.SWAMP_GRASS_TOP * 4 + 4)
        require(abs(sw[2] * palette.swampB / 255f - 1f) < 1e-5) { "swamp top factor" }
        require(table[AtlasCell.GRASS_SIDE * 4 + 3] < 0f && table[AtlasCell.GRASS_TOP * 4 + 3] > 0f) { "fringe tiles must be marked by the sign of alpha" }
        require(table[AtlasCell.OAK_LEAVES * 4 + 3] == TintTable.LEAF_STRENGTH) { "leaf strength" }
    }

    check("tint table: the grass-side tiles carry a mask of their grass texels (alpha 235) and nothing else; their dirt is not masked") {
        for (cell in listOf(AtlasCell.GRASS_SIDE, AtlasCell.DRY_GRASS_SIDE, AtlasCell.SWAMP_GRASS_SIDE)) {
            val src = TileSources.requirePixels(cell)
            val out = TintTable.atlasPixels(cell, src)
            var masked = 0
            for (i in src.indices) {
                val a = out[i] ushr 24
                require((out[i] and 0xFFFFFF) == (src[i] and 0xFFFFFF)) { "cell $cell texel $i changed colour" }
                if (a == 255 - TintTable.MASK_ALPHA_DROP) { masked++; require(TintTable.isGrassTexel(src[i])) { "cell $cell texel $i masked but not grass" } }
                else require(a == (src[i] ushr 24)) { "cell $cell texel $i alpha changed unexpectedly" }
            }
            val top = (0 until 16).count { out[it] ushr 24 == 255 - TintTable.MASK_ALPHA_DROP }
            val bottom = (0 until 16).count { out[15 * 16 + it] ushr 24 == 255 - TintTable.MASK_ALPHA_DROP }
            require(masked in 16..140) { "cell $cell: $masked masked texels" }
            require(top >= 12 && bottom == 0) { "cell $cell: top row $top masked, bottom row $bottom masked" }
        }
        // a tile that is not a fringe tile is returned untouched
        val sand = TileSources.requirePixels(AtlasCell.SAND)
        require(TintTable.atlasPixels(AtlasCell.SAND, sand) === sand) { "sand tile was rewritten" }
    }

    // ---------------------------------------------------------------------------- the GPU map's layout
    check("layout: the torus addresses every world position consistently (slot, texel, spacing)") {
        val rnd = Random(5)
        for (spacing in intArrayOf(4, 8, 16)) {
            repeat(5000) {
                val wx = rnd.nextInt(2_000_000) - 1_000_000 + rnd.nextDouble()
                val tx = BiomeColorLayout.tileOf(wx, spacing)
                val texel = BiomeColorLayout.texelX(wx, spacing)
                require(texel / BiomeColorTiles.TILE == Math.floorMod(tx, BiomeColorLayout.TILES)) { "texel $texel is not in the slot of tile $tx (wx $wx, spacing $spacing)" }
                require(texel in 0 until BiomeColorLayout.TEXELS) { "texel $texel out of range" }
                // one texel further along is the next texel (mod the torus) unless the cell boundary is crossed
                val next = BiomeColorLayout.texelX(wx + spacing, spacing)
                require(next == (texel + 1) % BiomeColorLayout.TEXELS) { "texel $texel then $next" }
            }
        }
        require(BiomeColorLayout.slot(-1, -1) == (BiomeColorLayout.TILES - 1) * BiomeColorLayout.TILES + BiomeColorLayout.TILES - 1) { "slot of (-1,-1)" }
        var prev = 0
        for (r in listOf(100f, 400f, 900f, 1800f, 3600f, 7200f)) {
            val s = BiomeColorLayout.spacingFor(r)
            require(s >= prev && (s and (s - 1)) == 0 && s >= BiomeColorLayout.MIN_SPACING) { "spacing $s for radius $r" }
            require((BiomeColorLayout.TILES / 2 - 2) * BiomeColorTiles.TILE * s >= r || s == 1024) { "torus too small for $r (spacing $s)" }
            prev = s
        }
        val f = BiomeColorLayout.frameOffset(123456f, 4)
        require(f in 0f..1f) { "frame offset $f" }
    }

    check("layout: the finished texture holds the field at the centre of every texel it covers, and the neutral colour elsewhere") {
        val f = fields[2]
        val spacing = BiomeColorLayout.MIN_SPACING
        val ex = 1234.0; val ez = -4321.0
        val tex = BiomeColorLayout.fullTexture(f, ex, ez, spacing, 2)
        fun texel(tx: Int, tz: Int): Int { val o = (tz * BiomeColorLayout.TEXELS + tx) * 4; return ((tex[o].toInt() and 0xFF) shl 16) or ((tex[o + 1].toInt() and 0xFF) shl 8) or (tex[o + 2].toInt() and 0xFF) }
        val rnd = Random(6)
        repeat(500) {
            val wx = ex + rnd.nextInt(2 * 2 * 16 * spacing) - 2 * 16 * spacing + 0.1; val wz = ez + rnd.nextInt(2 * 2 * 16 * spacing) - 2 * 16 * spacing + 0.1
            if (abs(wx - ex) > 2 * 16 * spacing || abs(wz - ez) > 2 * 16 * spacing) return@repeat
            val cx = (Math.floor(wx / spacing) + 0.5) * spacing; val cz = (Math.floor(wz / spacing) + 0.5) * spacing
            val expect = f.grassAt(cx, cz)
            val got = texel(BiomeColorLayout.texelX(wx, spacing), BiomeColorLayout.texelX(wz, spacing))
            require(got == expect) { "texel at ($wx,$wz): ${hex(got)} vs ${hex(expect)}" }
        }
    }

    // ---------------------------------------------------------------------------- the distant terrain
    val groundColor = FarGroundColor(palette)

    check("far colours: a colour key survives the trip through a float vertex (all 2^24 values, a sample of them exactly)") {
        require(FarGroundColor.directKey(0) == -1 && FarGroundColor.directKey(0xFFFFFF) == -16777216) { "key range" }
        val rnd = Random(7)
        val samples = IntArray(200000) { if (it < 4) intArrayOf(0, 1, 0xFFFFFF, 0x800000)[it] else rnd.nextInt(0x1000000) }
        for (rgb in samples) {
            val key = FarGroundColor.directKey(rgb)
            require(key < 0 && FarGroundColor.isDirect(key)) { "key of ${hex(rgb)} not negative" }
            val viaFloat = key.toFloat()
            require(viaFloat.toInt() == key) { "${hex(rgb)} changed in a float" }
            // what the vertex shader does: int(-u) - 1, then the three bytes
            val p = (-viaFloat).toInt() - 1
            require(p == rgb && FarGroundColor.rgbOfKey(key) == rgb) { "decoded ${hex(p)} for ${hex(rgb)}" }
        }
    }

    check("far colours: a corner is the average of the grass cells around it and ignores every other cell") {
        val n = FarGroundColor.NONE
        require(FarGroundColor.corner(n, n, n, n) == n) { "no grass" }
        require(FarGroundColor.corner(0x102030, n, n, n) == 0x102030) { "one grass cell" }
        require(FarGroundColor.corner(0x102030, 0x304050, n, n) == 0x203040) { "two" }
        require(FarGroundColor.corner(0x000000, 0x000000, 0x000000, 0x0000FF) == 0x000040) { "rounding: 255/4 = 63.75 -> 64" }
        require(FarGroundColor.corner(0xFFFFFF, 0xFFFFFF, 0xFFFFFF, 0xFFFFFF) == 0xFFFFFF) { "white" }
    }

    check("far colours: grass is the field's colour times the palette's own brightness step, so a plain looks as it did") {
        val neutral = fields[0].neutral
        for (col in 3..7) {
            val got = groundColor.grass(neutral, SurfaceKind.GRASS, col)
            val ramp = TextureAtlas.rampSurfaceRgb(col)
            require(maxChannelDiff(got, ramp) <= 1) { "grass column $col: ${hex(got)} vs palette ${hex(ramp)}" }
        }
        val dry = BiomeColorField.pack(palette.dryR, palette.dryG, palette.dryB)
        for (col in 16..18) require(maxChannelDiff(groundColor.grass(dry, SurfaceKind.DRY_GRASS, col), TextureAtlas.rampSurfaceRgb(col)) <= 1) { "dry column $col" }
        val swamp = BiomeColorField.pack(palette.swampR, palette.swampG, palette.swampB)
        for (col in 28..30) require(maxChannelDiff(groundColor.grass(swamp, SurfaceKind.SWAMP, col), TextureAtlas.rampSurfaceRgb(col)) <= 1) { "swamp column $col" }
    }

    check("far colours: leaves are unchanged in the middle of a plain and follow the field with 70 % of the shift elsewhere") {
        val neutral = fields[0].neutral
        for (col in 0..8) {
            val ramp = TextureAtlas.rampFoliageRgb(col)
            require(maxChannelDiff(groundColor.leaf(ramp, neutral), ramp) <= 1) { "leaf column $col moved on a plain" }
        }
        val ramp = TextureAtlas.rampFoliageRgb(0)
        val dry = BiomeColorField.pack(palette.dryR, palette.dryG, palette.dryB)
        val l = groundColor.leaf(ramp, dry)
        val k = TintTable.LEAF_STRENGTH
        val expectR = ch(ramp, 16) * (1f + (palette.dryR / palette.grassR - 1f) * k)
        require(abs(ch(l, 16) - expectR) <= 1.0f) { "red of a dry-climate leaf ${ch(l, 16)} vs $expectR" }
        require(ch(l, 16) > ch(ramp, 16)) { "dry leaves should be redder" }
    }

    // the column levels' ground sampler, built the way FarTerrain builds it
    fun columnMesher(gi: Int) = FarColumnMesher(gens[gi], FarStyler(gens[gi], fields[gi], FarGroundColor(fields[gi].palette)))

    check("far colours: neighbouring tiles of every level agree on the colour of every corner along their shared border") {
        var edges = 0
        for ((gi, g) in gens.withIndex()) {
            val far = columnMesher(gi)
            for (level in 0..4) {
                val cells = FarTerrain.cellsOf(level)
                val size = FarTerrain.tileBlocks(level)
                val rnd = Random(8L + level + 31L * gi)
                var found = 0
                var tries = 0
                while (found < 6 && tries++ < 400) {
                    val tx = rnd.nextInt(400) - 200 ; val tz = rnd.nextInt(400) - 200
                    if (Math.abs(tx.toLong() * size) > 30000 || Math.abs(tz.toLong() * size) > 30000) continue
                    val a = far.buildField(level, tx * cells, tz * cells, cells, true)
                    if (!a.hasGrass) continue
                    val east = far.buildField(level, (tx + 1) * cells, tz * cells, cells, true)
                    val south = far.buildField(level, tx * cells, (tz + 1) * cells, cells, true)
                    val ca = a.cornerArray()
                    val ce = east.cornerArray()
                    val cs = south.cornerArray()
                    val k = cells + 1
                    for (j in 0..cells) { require(ca[j * k + cells] == ce[j * k]) { "level $level tile ($tx,$tz): east border corner $j ${hex(ca[j * k + cells])} vs ${hex(ce[j * k])}" }; edges++ }
                    for (i in 0..cells) { require(ca[cells * k + i] == cs[i]) { "level $level tile ($tx,$tz): south border corner $i" }; edges++ }
                    found++
                }
                require(found >= 3) { "level $level: only $found tiles with grass found" }
            }
        }
        println("      measured: $edges border corners compared")
    }

    check("far colours: every corner of a grass cell has a colour, every grass colour is the field's, and sand / snow / rock cells have none") {
        val g = gens[0]
        val far = columnMesher(0)
        var grassCells = 0; var otherCells = 0
        for (level in 0..3) {
            val cells = FarTerrain.cellsOf(level); val n = cells + 2
            for ((tx, tz) in listOf(-7 to 3, 5 to 9, 40 to -20)) {
                val f = far.buildField(level, tx * cells, tz * cells, cells, true)
                val grass = f.grass; val tint = f.tint
                val corners = f.cornerArray()
                val k = cells + 1
                for (j in 0 until cells) for (i in 0 until cells) {
                    val c = (j + 1) * n + (i + 1)
                    if (grass[c] >= 0) {
                        grassCells++
                        for (corner in intArrayOf(j * k + i, j * k + i + 1, (j + 1) * k + i, (j + 1) * k + i + 1)) require(corners[corner] >= 0) { "grass cell without a corner colour" }
                        require(tint[c] >= 0) { "grass cell without a field colour" }
                    } else otherCells++
                }
            }
        }
        println("      measured: $grassCells grass cells, $otherCells others")
        require(grassCells > 500) { "too few grass cells" }
    }

    println()
    println("$passed passed, $failures failed")
    if (failures > 0) System.exit(1)
}
