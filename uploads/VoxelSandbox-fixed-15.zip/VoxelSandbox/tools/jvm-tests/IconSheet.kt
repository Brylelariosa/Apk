package tests

import com.voxelsandbox.game.creative.BlockIcons
import com.voxelsandbox.game.creative.CreativeCatalog
import com.voxelsandbox.game.gl.TileSources
import java.awt.image.BufferedImage
import java.io.File
import javax.imageio.ImageIO

/** Draws every catalogue icon on a slot-coloured grid (4x nearest-neighbour) into a PNG for a visual check. */
fun main(args: Array<String>) {
    val out = File(args[0])
    val entries = CreativeCatalog.entries
    val cols = 7
    val rows = (entries.size + cols - 1) / cols
    val cell = 32 * 4 + 24
    val label = 18
    val img = BufferedImage(cols * cell, rows * (cell + label), BufferedImage.TYPE_INT_ARGB)
    val g = img.createGraphics()
    g.color = java.awt.Color(0x2B2B33)
    g.fillRect(0, 0, img.width, img.height)
    for ((i, e) in entries.withIndex()) {
        val cx = (i % cols) * cell
        val cy = (i / cols) * (cell + label)
        g.color = java.awt.Color(0x4A4A57)
        g.fillRect(cx + 6, cy + 6, cell - 12, cell - 12)
        val px = BlockIcons.render(e.block) { TileSources.pixelsFor(it) }
        if (px == null) { g.color = java.awt.Color.RED; g.drawString("MISSING ${e.name}", cx + 10, cy + 60); continue }
        for (y in 0 until 32) for (x in 0 until 32) {
            val c = px[y * 32 + x]
            val a = c ushr 24
            if (a == 0) continue
            // composite over the slot colour
            val br = 0x4A; val bg = 0x4A; val bb = 0x57
            val r = (((c shr 16) and 0xFF) * a + br * (255 - a)) / 255
            val gg = (((c shr 8) and 0xFF) * a + bg * (255 - a)) / 255
            val b = ((c and 0xFF) * a + bb * (255 - a)) / 255
            g.color = java.awt.Color(r, gg, b)
            g.fillRect(cx + 12 + x * 4, cy + 12 + y * 4, 4, 4)
        }
        g.color = java.awt.Color.WHITE
        g.drawString(e.name, cx + 8, cy + cell + 12)
    }
    g.dispose()
    ImageIO.write(img, "png", out)
    println("entries=${entries.size} wrote $out")
}
