#!/bin/bash
# usage: KOTLINC=... ANDROID_JAR=... ./run.sh [sheet <out.png> | atlas]
set -e
HERE=$(cd "$(dirname "$0")" && pwd)
ROOT=$(cd "$HERE/../.." && pwd)
G=$ROOT/app/src/main/java/com/voxelsandbox/game
KOTLINC=${KOTLINC:-kotlinc}
: "${ANDROID_JAR:?set ANDROID_JAR to an android.jar (API 34 stubs)}"
STDLIB=${STDLIB:-$(dirname "$(readlink -f "$(which "$KOTLINC")")")/../lib/kotlin-stdlib.jar}
OUT=$(mktemp -d)
SRC="$G/world/Block.kt $G/world/AtlasCell.kt $G/gl/BlockTextures.kt $G/gl/TileSources.kt $G/gl/TextureAtlas.kt"
SRC="$SRC $(find $G/creative -name '*.kt')"
SRC="$SRC $G/inventory/Hotbar.kt $G/save/SaveCodec.kt $G/engine/PlacementRules.kt"
SRC="$SRC $G/player/FlightMath.kt $G/player/PhysicsController.kt $G/player/Player.kt"
SRC="$SRC $G/gl/TintTable.kt $G/world/color/BiomePalette.kt"
SRC="$SRC $(find $G/world $G/util -name '*.kt' | grep -v '/streaming/\|WorldManager.kt\|/far/\|FluidSimulator.kt\|/generation/\|/mesh/\|/color/\|world/Block.kt\|world/AtlasCell.kt')"
"$KOTLINC" -jvm-target 17 -nowarn -cp "$ANDROID_JAR:$STDLIB" -d "$OUT" $SRC "$HERE/CreativeTests.kt" "$HERE/IconSheet.kt" "$HERE/AtlasHash.kt"
CP="$OUT:$STDLIB:$ANDROID_JAR"
case "${1:-test}" in
  sheet) java -Djava.awt.headless=true -cp "$CP" tests.IconSheetKt "${2:-creative-icons.png}" ;;
  atlas) java -cp "$CP" tests.AtlasHashKt ;;
  *)     java -cp "$CP" tests.CreativeTestsKt ;;
esac
rm -rf "$OUT"
