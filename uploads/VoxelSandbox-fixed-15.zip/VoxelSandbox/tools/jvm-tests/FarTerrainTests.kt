package tests

import com.voxelsandbox.game.gl.TextureAtlas
import com.voxelsandbox.game.world.WorldConfig
import com.voxelsandbox.game.world.color.BiomeColorField
import com.voxelsandbox.game.world.color.BiomePalette
import com.voxelsandbox.game.world.far.CellField
import com.voxelsandbox.game.world.far.ColumnSlide
import com.voxelsandbox.game.world.far.FarColumnMesher
import com.voxelsandbox.game.world.far.FarGroundColor
import com.voxelsandbox.game.world.far.FarLevels
import com.voxelsandbox.game.world.far.FarPalette
import com.voxelsandbox.game.world.far.FarRings
import com.voxelsandbox.game.world.far.FarStandIns
import com.voxelsandbox.game.world.far.FarStyler
import com.voxelsandbox.game.world.far.FarTerrain
import com.voxelsandbox.game.world.far.FarTileMath
import com.voxelsandbox.game.world.far.FarVertex
import com.voxelsandbox.game.world.generation.TerrainGenerator
import com.voxelsandbox.game.world.mesh.MeshData
import java.util.Random
import java.util.zip.CRC32
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Plain-Kotlin checks of the distant terrain's blocky column levels: the rounding of heights, how the columns of
 * neighbouring tiles agree, that the meshes have no cracks (every height difference between neighbouring columns is
 * covered by walls, both as the mesh is and as it is once it has slid to the next level), that merged tops cover every
 * column exactly once, that what a column slides to is what the next level draws there, and that building a tile is
 * deterministic. Prints PASS/FAIL per check and exits 1 on any failure; "measured" lines are numbers, not checks.
 * Nothing here needs a GPU: what a GPU does with these meshes was looked at with the software renderer in
 * tools/render-rig, which is a different kind of evidence (see docs/far-terrain.md).
 */
private var failures = 0
private var passed = 0

private fun check(name: String, body: () -> Unit) {
    try {
        body()
        passed++
        println("PASS  $name")
    } catch (t: Throwable) {
        failures++
        println("FAIL  $name -> ${t.javaClass.simpleName}: ${t.message}")
    }
}

private fun require(cond: Boolean, msg: () -> String) {
    if (!cond) throw AssertionError(msg())
}

private fun ch(c: Int, shift: Int) = (c shr shift) and 0xFF
private fun maxChannelDiff(a: Int, b: Int) = max(abs(ch(a, 16) - ch(b, 16)), max(abs(ch(a, 8) - ch(b, 8)), abs(ch(a, 0) - ch(b, 0))))
private fun hex(c: Int) = String.format("%06x", c)

private val SEEDS = longArrayOf(0L, 12345L, 20261023L)
private const val EPS = 1e-3f

/** One world: the generator and the mesher built the way FarTerrain builds them. */
private class World(seed: Long) {
    val gen = TerrainGenerator(seed)
    private val palette = BiomePalette.fromTiles()
    private val field = BiomeColorField(gen.climate, gen.shape, palette)
    val mesher = FarColumnMesher(gen, FarStyler(gen, field, FarGroundColor(palette)))

    /** A built tile: its ground, what it slides to, and its mesh. */
    inner class Tile(val level: Int, val tx: Int, val tz: Int) {
        val cells = FarLevels.cellsOf(level)
        val step = FarLevels.step(level)
        val x0 = tx * FarLevels.tileBlocks(level)
        val z0 = tz * FarLevels.tileBlocks(level)
        val field: CellField = mesher.buildField(level, tx * cells, tz * cells, cells)
        val slide: ColumnSlide = mesher.slideOf(level, tx, tz, field)
        val mesh: MeshData = mesher.buildLandMesh(level, x0, z0, field, slide)
    }
}

/** A quad of a land mesh: four vertices of [FarVertex.FLOATS] floats (x, y, z, rgb, slideRgb, slideY). */
private class Quad(val data: FloatArray, val base: Int) {
    fun x(k: Int) = data[(base + k) * FarVertex.FLOATS]
    fun y(k: Int) = data[(base + k) * FarVertex.FLOATS + 1]
    fun z(k: Int) = data[(base + k) * FarVertex.FLOATS + 2]
    fun rgb(k: Int) = FarVertex.rgbOf(data[(base + k) * FarVertex.FLOATS + 3])
    fun slideRgb(k: Int) = FarVertex.rgbOf(data[(base + k) * FarVertex.FLOATS + 4])
    fun slideY(k: Int) = data[(base + k) * FarVertex.FLOATS + 5]
    val minX get() = min(min(x(0), x(1)), min(x(2), x(3)))
    val maxX get() = max(max(x(0), x(1)), max(x(2), x(3)))
    val minZ get() = min(min(z(0), z(1)), min(z(2), z(3)))
    val maxZ get() = max(max(z(0), z(1)), max(z(2), z(3)))

    /** A wall stands in a plane of constant X or Z; a top does not. */
    val isWall get() = minX == maxX || minZ == maxZ
}

/** The quads of a mesh, which is made of independent quads: four fresh vertices each, indices (v, v+1, v+2, v, v+2, v+3). */
private fun quadsOf(mesh: MeshData): List<Quad> {
    val out = ArrayList<Quad>(mesh.indices.size / 6)
    require(mesh.vertexData.size == mesh.vertexCount * FarVertex.FLOATS) { "vertex data is not ${FarVertex.FLOATS} floats per vertex" }
    require(mesh.indices.size % 6 == 0) { "index count ${mesh.indices.size} is not a whole number of quads" }
    var i = 0
    while (i < mesh.indices.size) {
        val v = mesh.indices[i]
        for ((k, e) in intArrayOf(v, v + 1, v + 2, v, v + 2, v + 3).withIndex()) {
            require(mesh.indices[i + k] == e) { "indices at $i are not a quad of four consecutive vertices" }
        }
        out.add(Quad(mesh.vertexData, v))
        i += 6
    }
    return out
}

/** True if every corner of the quad lies on the lattice of columns of the tile (tree boxes do not). */
private fun onLattice(q: Quad, x0: Int, z0: Int, step: Int): Boolean {
    for (k in 0 until 4) {
        if (((q.x(k) - x0) % step) != 0f || ((q.z(k) - z0) % step) != 0f) return false
    }
    return true
}

/** The checksum of a mesh's vertex data and indices. */
private fun crc(mesh: MeshData): Long {
    val c = CRC32()
    val b = java.nio.ByteBuffer.allocate(mesh.vertexData.size * 4 + mesh.indices.size * 4)
    for (f in mesh.vertexData) b.putFloat(f)
    for (i in mesh.indices) b.putInt(i)
    c.update(b.array())
    return c.value
}

/** Tiles for the checks that look at geometry: the ground near the sea, mountains and forests of every world. */
private fun sampleTiles(w: World, level: Int, count: Int, salt: Long): List<World.Tile> {
    val size = FarLevels.tileBlocks(level)
    val rnd = Random(77L + level * 131L + salt)
    val out = ArrayList<World.Tile>()
    var tries = 0
    while (out.size < count && tries++ < 400) {
        val tx = rnd.nextInt(2 * 12000 / size + 1) - 12000 / size
        val tz = rnd.nextInt(2 * 12000 / size + 1) - 12000 / size
        val t = w.Tile(level, tx, tz)
        // Want ground with something to look at: land and steps.
        val f = t.field
        if (f.highest + 1 > FarLevels.landFloor(level) && f.highest - f.lowest >= 3 && !t.mesh.isEmpty()) out.add(t)
    }
    require(out.size == count) { "level $level: only ${out.size} tiles with steps found" }
    return out
}

fun main() {
    val worlds = SEEDS.map { World(it) }

    heightChecks()
    tableChecks()
    for ((i, w) in worlds.withIndex()) {
        fieldChecks(w, i)
    }
    meshChecks(worlds)
    slideChecks(worlds)
    syntheticChecks(worlds[0])
    determinismChecks(worlds)
    standInChecks()

    println()
    println("far terrain tests: $passed passed, $failures failed")
    if (failures > 0) System.exit(1)
}

// ------------------------------------------------------------------------------------------------ heights, tables

private fun heightChecks() {
    check("heights: every level rounds to its quantum, never moves the shore, and is monotonic") {
        val sea = WorldConfig.SEA_LEVEL
        val base = sea + FarLevels.SHORE_BAND
        for (level in 0 until FarLevels.COUNT) {
            val q = FarLevels.heightQuantum(level)
            var prev = Int.MIN_VALUE
            for (h in sea - 80..sea + 300) {
                val s = FarLevels.snapHeight(level, h)
                if (h <= base) require(s == h) { "level $level: h=$h (at or below the top of the shore band) moved to $s" }
                else {
                    require(s >= base) { "level $level: h=$h snapped below the shore band ($s)" }
                    require((s - base) % q == 0) { "level $level: h=$h snapped to $s, not a multiple of $q above the shore band" }
                    require(abs(s - h) <= (q + 1) / 2) { "level $level: h=$h snapped to $s, more than half of $q away" }
                }
                require(s >= prev) { "level $level: not monotonic at h=$h" }
                prev = s
                if (q == 1) require(s == h) { "level $level: a quantum of 1 must be exact" }
            }
        }
    }
}

private fun tableChecks() {
    check("tables: steps double, grids nest, columns per tile are even and fit, the rings grow with the columns") {
        for (level in 0 until FarLevels.COUNT) {
            require(FarLevels.cellsOf(level) % 2 == 0 && FarLevels.cellsOf(level) <= FarLevels.MAX_CELLS) { "level $level cells" }
            if (level > 0) {
                require(FarLevels.step(level) == 2 * FarLevels.step(level - 1)) { "step of level $level" }
                require(FarLevels.tileBlocks(level) % FarLevels.tileBlocks(level - 1) == 0 ||
                    FarLevels.tileBlocks(level - 1) % FarLevels.tileBlocks(level) == 0) { "tiles of level $level do not nest" }
                require(FarLevels.heightQuantum(level) >= FarLevels.heightQuantum(level - 1)) { "quantum of level $level" }
            }
        }
        for (level in 1 until FarLevels.COUNT - 1) {
            require(FarLevels.ringOuter(level + 1) > FarLevels.ringOuter(level)) { "ring $level" }
            val width = FarLevels.morphWidth(level)
            require(width in 1f..(FarLevels.ringOuter(level) - FarRings.drawInner(level))) { "morph width of level $level ($width) does not fit its ring" }
        }
        require(FarLevels.LAND_FLOATS == 6 && FarTerrain.LAND_FLOATS == 6 && FarVertex.FLOATS == 6) { "vertex size" }
    }

    check("heights: a pixel of the picture at the inner edge of each ring is about a quantum or more (the rounding is not a shape)") {
        // 514 px per radian is a 70-degree view on a 720-pixel-high screen.
        for (level in 1 until FarLevels.COUNT - 1) {
            val inner = FarRings.drawInner(level)
            val pixel = inner / 514f
            val q = FarLevels.heightQuantum(level)
            println("      measured: level $level inner edge ${inner.toInt()}: a pixel is %.1f blocks, quantum $q, column ${FarLevels.step(level)}".format(pixel))
            require(q <= max(1f, 2.1f * pixel)) { "level $level: quantum $q is more than two pixels at ${inner.toInt()} blocks" }
        }
    }

    check("vertex format: colours survive a float exactly, shading rounds to the nearest level, 24 bits suffice") {
        val rnd = Random(5)
        for (n in 0 until 20000) {
            val rgb = rnd.nextInt(0x1000000)
            require(FarVertex.rgbOf(FarVertex.colorOf(rgb)) == rgb) { "colour ${hex(rgb)} changed in a float" }
        }
        require(FarVertex.shaded(0x336699, 1f) == 0x336699) { "shade 1 changes a colour" }
        require(FarVertex.shaded(0xFFFFFF, 0.5f) == 0x808080) { "half of white: ${hex(FarVertex.shaded(0xFFFFFF, 0.5f))}" }
        require(FarVertex.shaded(0x000000, 0.7f) == 0) { "shade of black" }
        require(FarVertex.shaded(0x102030, 0f) == 0) { "shade 0" }
    }
}

// ------------------------------------------------------------------------------------------------ fields

private fun fieldChecks(w: World, index: Int) {
    check("fields (world $index): tiles of every level agree on every column of their shared border, ring included") {
        var compared = 0L
        for (level in 0 until FarLevels.COUNT) {
            val cells = FarLevels.cellsOf(level)
            val n = cells + 2
            val rnd = Random(9L + level * 17 + index)
            for (t in 0 until 3) {
                val tx = rnd.nextInt(60) - 30
                val tz = rnd.nextInt(60) - 30
                val a = w.mesher.buildField(level, tx * cells, tz * cells, cells)
                val east = w.mesher.buildField(level, (tx + 1) * cells, tz * cells, cells)
                val south = w.mesher.buildField(level, tx * cells, (tz + 1) * cells, cells)
                val sa = w.mesher.slideOf(level, tx, tz, a)
                val se = w.mesher.slideOf(level, tx + 1, tz, east)
                val ss = w.mesher.slideOf(level, tx, tz + 1, south)
                // a's window cells (cells - 1, cells) are east's (-1, 0): array columns (cells, cells + 1) and (0, 1)
                for (j in 0 until n) for (k in 0..1) {
                    val ca = j * n + cells + k
                    val cb = j * n + k
                    compareCells(a, ca, east, cb, "level $level east border row $j")
                    require(sa.y[ca] == se.y[cb] && sa.wallRgb[ca] == se.wallRgb[cb] && sa.wallSoil[ca] == se.wallSoil[cb]) { "level $level: slide data of east border row $j differs" }
                    compared++
                }
                for (i in 0 until n) for (k in 0..1) {
                    val ca = (cells + k) * n + i
                    val cb = k * n + i
                    compareCells(a, ca, south, cb, "level $level south border column $i")
                    require(sa.y[ca] == ss.y[cb] && sa.wallRgb[ca] == ss.wallRgb[cb] && sa.wallSoil[ca] == ss.wallSoil[cb]) { "level $level: slide data of south border column $i differs" }
                    compared++
                }
            }
        }
        println("      measured: $compared columns compared")
    }

    check("fields (world $index): the top of a column is its rounded height plus the top face plus its canopy, never below the ground") {
        var cellsSeen = 0
        for (level in 0 until FarLevels.COUNT) {
            val cells = FarLevels.cellsOf(level)
            val f = w.mesher.buildField(level, 11 * cells, -7 * cells, cells)
            for (c in f.heights.indices) {
                val h = f.heights[c]
                val snapped = FarLevels.snapHeight(level, h)
                require(f.topY[c] >= snapped + FarLevels.LAND_Y_OFFSET - EPS) { "level $level column $c: top ${f.topY[c]} under its rounded ground ${snapped + 1}" }
                if (f.skip[c]) require(snapped + FarLevels.LAND_Y_OFFSET <= FarLevels.landFloor(level)) { "level $level column $c skipped above the floor" }
                else if (level < FarLevels.CANOPY_FROM_LEVEL) require(f.topY[c] == snapped + FarLevels.LAND_Y_OFFSET) { "level $level: raised ground on a level without canopy" }
                cellsSeen++
            }
        }
        println("      measured: $cellsSeen columns")
    }
}

private fun compareCells(a: CellField, ca: Int, b: CellField, cb: Int, what: String) {
    require(a.heights[ca] == b.heights[cb]) { "$what: heights ${a.heights[ca]} vs ${b.heights[cb]}" }
    require(a.topY[ca] == b.topY[cb]) { "$what: tops ${a.topY[ca]} vs ${b.topY[cb]}" }
    require(a.skip[ca] == b.skip[cb]) { "$what: skip" }
    if (!a.skip[ca]) {
        require(a.col[ca] == b.col[cb]) { "$what: colour" }
        require(a.wallCol[ca] == b.wallCol[cb]) { "$what: wall colour" }
        require(a.grass[ca] == b.grass[cb]) { "$what: grass" }
        require(a.tint[ca] == b.tint[cb]) { "$what: tint" }
    }
}

// ------------------------------------------------------------------------------------------------ meshes

/** A wall piece on one edge segment: its own height range and the one it slides to. */
private class Piece(val y0: Float, val y1: Float, val m0: Float, val m1: Float, val facing: Int)

private fun meshChecks(worlds: List<World>) {
    val tilesPerLevel = 3
    for (level in 0 until FarLevels.COUNT) {
        check("meshes (level $level): tops cover every drawn column exactly once, at its height, sliding to its target; nothing else is a top") {
            var columns = 0L
            var quadsTotal = 0L
            for ((wi, w) in worlds.withIndex()) {
                for (t in sampleTiles(w, level, tilesPerLevel, wi.toLong())) {
                    val seen = IntArray(t.cells * t.cells)
                    val quads = quadsOf(t.mesh).filter { onLattice(it, t.x0, t.z0, t.step) }
                    for (q in quads) {
                        if (q.isWall) continue
                        quadsTotal++
                        val i0 = Math.round((q.minX - t.x0) / t.step)
                        val i1 = Math.round((q.maxX - t.x0) / t.step)
                        val j0 = Math.round((q.minZ - t.z0) / t.step)
                        val j1 = Math.round((q.maxZ - t.z0) / t.step)
                        for (k in 1 until 4) require(q.y(k) == q.y(0) && q.slideY(k) == q.slideY(0)) { "a top that is not flat" }
                        require(i0 >= 0 && j0 >= 0 && i1 <= t.cells && j1 <= t.cells && i1 > i0 && j1 > j0) { "top outside the tile" }
                        for (j in j0 until j1) for (i in i0 until i1) {
                            val c = (j + 1) * t.field.n + i + 1
                            seen[j * t.cells + i]++
                            require(!t.field.skip[c]) { "level $level tile (${t.tx},${t.tz}): a top over a column that is not drawn" }
                            require(abs(q.y(0) - t.field.topY[c]) < EPS) { "top at ${q.y(0)} over a column at ${t.field.topY[c]}" }
                            require(abs(q.slideY(0) - t.slide.y[c]) < EPS) { "top slides to ${q.slideY(0)}, column to ${t.slide.y[c]}" }
                        }
                    }
                    for (j in 0 until t.cells) for (i in 0 until t.cells) {
                        val drawn = !t.field.skip[(j + 1) * t.field.n + i + 1]
                        require(seen[j * t.cells + i] == (if (drawn) 1 else 0)) {
                            "level $level tile (${t.tx},${t.tz}) column ($i,$j): covered ${seen[j * t.cells + i]} times, drawn=$drawn"
                        }
                        if (drawn) columns++
                    }
                }
            }
            println("      measured: $columns columns in $quadsTotal top quads (%.2f columns per quad)".format(columns.toDouble() / quadsTotal))
        }

        check("meshes (level $level): every step between columns, now and once slid to the next level, is covered by walls that face the lower side") {
            var segments = 0L
            var pieces = 0L
            for ((wi, w) in worlds.withIndex()) {
                for (t in sampleTiles(w, level, tilesPerLevel, 100L + wi)) {
                    segments += checkWalls(t)
                    pieces += quadsOf(t.mesh).count { it.isWall && onLattice(it, t.x0, t.z0, t.step) }
                }
            }
            println("      measured: $segments edge segments, $pieces wall quads")
        }
    }

    check("meshes: a wall on a border between two tiles is built by exactly one of them") {
        var borders = 0L
        for (level in intArrayOf(1, 3, 5)) {
            for ((wi, w) in worlds.withIndex()) {
                for (a in sampleTiles(w, level, 2, 200L + wi)) {
                    val b = w.Tile(level, a.tx + 1, a.tz)
                    val line = (a.x0 + a.cells * a.step).toFloat()
                    require(b.x0.toFloat() == line) { "tiles do not touch" }
                    val owners = HashMap<Int, Int>() // segment along Z -> number of walls on the line
                    for (t in listOf(a, b)) {
                        for (q in quadsOf(t.mesh)) {
                            if (!q.isWall || q.minX != q.maxX || q.minX != line || !onLattice(q, t.x0, t.z0, t.step)) continue
                            val j0 = Math.round((q.minZ - t.z0) / t.step)
                            val j1 = Math.round((q.maxZ - t.z0) / t.step)
                            for (j in j0 until j1) owners.merge(j, 1) { x, y -> x + y }
                        }
                    }
                    val n = a.field.n
                    for (j in 0 until a.cells) {
                        val ca = (j + 1) * n + a.cells // a's last column
                        val cb = (j + 1) * n + a.cells + 1 // b's first column, as a's ring
                        val differ = a.field.topY[ca] != a.field.topY[cb] || a.slide.y[ca] != a.slide.y[cb]
                        val hiSkipped = if (a.field.topY[ca] != a.field.topY[cb]) a.field.skip[if (a.field.topY[ca] > a.field.topY[cb]) ca else cb]
                        else a.field.skip[if (a.slide.y[ca] > a.slide.y[cb]) ca else cb]
                        val expected = if (differ && !hiSkipped) 1 else 0
                        val got = owners[j] ?: 0
                        // (a layered wall is two quads over one segment: count segments covered at least once, and at most twice)
                        require(if (expected == 0) got == 0 else got in 1..2) {
                            "level $level border row $j: expected $expected wall, found $got quads (tiles (${a.tx},${a.tz}) and (${b.tx},${b.tz}))"
                        }
                        borders++
                    }
                }
            }
        }
        println("      measured: $borders border segments")
    }
}

/** Checks all the walls of a tile against its columns; returns how many edge segments were examined. */
private fun checkWalls(t: World.Tile): Long {
    val n = t.field.n
    val cells = t.cells
    val floorY = FarLevels.landFloor(t.level)
    val topY = t.field.topY
    val slideY = t.slide.y
    // wall pieces per (alongX, edge line, segment): what the mesh has
    val pieces = HashMap<Long, ArrayList<Piece>>()
    fun key(alongX: Boolean, q: Int, p: Int) = ((if (alongX) 1L else 0L) shl 40) or ((q + 1L) shl 20) or p.toLong()
    for (q in quadsOf(t.mesh)) {
        if (!q.isWall || !onLattice(q, t.x0, t.z0, t.step)) continue
        val alongX = q.minZ == q.maxZ
        val line = Math.round(((if (alongX) q.minZ - t.z0 else q.minX - t.x0)) / t.step)
        val p0 = Math.round(((if (alongX) q.minX - t.x0 else q.minZ - t.z0)) / t.step)
        val p1 = Math.round(((if (alongX) q.maxX - t.x0 else q.maxZ - t.z0)) / t.step)
        require(abs(q.y(0) - q.y(1)) < EPS && abs(q.y(2) - q.y(3)) < EPS && abs(q.slideY(0) - q.slideY(1)) < EPS && abs(q.slideY(2) - q.slideY(3)) < EPS) { "a wall that is not made of two level edges" }
        // v0 and v1 are the bottom edge, v2 and v3 the top; the order of v0 -> v1 along the edge says which way it faces
        val facing = if (alongX) (if (q.x(0) < q.x(1)) 1 else -1) else (if (q.z(0) < q.z(1)) -1 else 1)
        for (p in p0 until p1) pieces.getOrPut(key(alongX, line, p)) { ArrayList() }.add(Piece(q.y(0), q.y(2), q.slideY(0), q.slideY(2), facing))
    }
    var segments = 0L
    for (alongX in booleanArrayOf(true, false)) {
        val across = if (alongX) n else 1
        for (e in -1 until cells) {
            for (p in 0 until cells) {
                val a = if (alongX) (e + 1) * n + p + 1 else (p + 1) * n + e + 1
                val c = a + across
                val aInside = e >= 0
                val cInside = e + 1 < cells
                val aHigher = when {
                    topY[a] != topY[c] -> topY[a] > topY[c]
                    slideY[a] != slideY[c] -> slideY[a] > slideY[c]
                    else -> null
                }
                var owner = -1
                if (aHigher != null) owner = if (aHigher) (if (aInside) a else -1) else (if (cInside) c else -1)
                val lo = if (owner == a) c else a
                val list = pieces[key(alongX, e + 1, p)]
                if (owner < 0 || t.field.skip[owner]) {
                    require(list == null) { "level ${t.level} tile (${t.tx},${t.tz}) ${if (alongX) "row" else "column"} edge ${e + 1} segment $p: a wall where none is owed" }
                    continue
                }
                segments++
                val yb = max(topY[lo], floorY)
                val yt = topY[owner]
                val mb = slideY[lo]
                val mt = slideY[owner]
                val hasHeight = yt > yb || mt > mb
                if (!hasHeight) {
                    require(list == null) { "level ${t.level}: a wall over no height" }
                    continue
                }
                require(list != null && list.isNotEmpty()) { "level ${t.level} tile (${t.tx},${t.tz}) ${if (alongX) "row" else "column"} edge ${e + 1} segment $p: step ${yb}..$yt (slides ${mb}..$mt) has no wall (a crack)" }
                val sorted = list!!.sortedBy { it.y0 }
                val wantFacing = if (owner == a) 1 else -1
                for (piece in sorted) require(piece.facing == wantFacing) { "level ${t.level}: a wall that faces the wrong way (${piece.facing}, wanted $wantFacing)" }
                require(abs(sorted.first().y0 - yb) < EPS && abs(sorted.last().y1 - yt) < EPS) { "level ${t.level}: wall spans ${sorted.first().y0}..${sorted.last().y1}, step is $yb..$yt" }
                require(abs(sorted.first().m0 - mb) < EPS && abs(sorted.last().m1 - mt) < EPS) { "level ${t.level}: wall slides to ${sorted.first().m0}..${sorted.last().m1}, target step is $mb..$mt" }
                for (k in 1 until sorted.size) {
                    require(abs(sorted[k].y0 - sorted[k - 1].y1) < EPS && abs(sorted[k].m0 - sorted[k - 1].m1) < EPS) { "level ${t.level}: pieces of a wall do not meet" }
                }
            }
        }
    }
    return segments
}

// ------------------------------------------------------------------------------------------------ slide targets

private fun slideChecks(worlds: List<World>) {
    check("slide: at the end of its ring a column is the column of the next level over it: same height, same colour") {
        var tops = 0L
        var colourChecked = 0L
        var worst = 0
        for (level in 1 until FarLevels.COUNT - 1) {
            for ((wi, w) in worlds.withIndex()) {
                for (child in sampleTiles(w, level, 2, 300L + wi)) {
                    val pl = level + 1
                    val ratio = Math.max(1, FarLevels.tileBlocks(pl) / FarLevels.tileBlocks(level))
                    val ptx = Math.floorDiv(child.tx, ratio)
                    val ptz = Math.floorDiv(child.tz, ratio)
                    val parent = w.Tile(pl, ptx, ptz)
                    if (parent.mesh.isEmpty()) continue
                    // what the parent paints, per parent column: the quad that covers it
                    val pq = HashMap<Long, Quad>()
                    for (q in quadsOf(parent.mesh)) {
                        if (q.isWall || !onLattice(q, parent.x0, parent.z0, parent.step)) continue
                        val i0 = Math.round((q.minX - parent.x0) / parent.step); val i1 = Math.round((q.maxX - parent.x0) / parent.step)
                        val j0 = Math.round((q.minZ - parent.z0) / parent.step); val j1 = Math.round((q.maxZ - parent.z0) / parent.step)
                        for (j in j0 until j1) for (i in i0 until i1) pq[(j.toLong() shl 20) or i.toLong()] = q
                    }
                    for (q in quadsOf(child.mesh)) {
                        if (q.isWall || !onLattice(q, child.x0, child.z0, child.step)) continue
                        tops++
                        val cx = (q.minX + q.maxX) / 2
                        val cz = (q.minZ + q.maxZ) / 2
                        val pi = Math.floor(((cx - parent.x0) / parent.step).toDouble()).toInt()
                        val pj = Math.floor(((cz - parent.z0) / parent.step).toDouble()).toInt()
                        val pquad = pq[(pj.toLong() shl 20) or pi.toLong()]
                        if (pquad == null) continue // the next level does not draw it: the column keeps its own colour
                        require(abs(max(pquad.y(0), FarLevels.landFloor(level)) - q.slideY(0)) < EPS) { "level $level: slides to ${q.slideY(0)}, the next level is at ${pquad.y(0)}" }
                        // The parent's colour at each corner of the child's quad (a corner of a parent column, the middle of one of its
                        // edges or of the column itself): interpolated over the parent's quad, which is flat for most ground.
                        for (k in 0 until 4) {
                            val expected = parentColourAt(pquad, q.x(k), q.z(k))
                            val d = maxChannelDiff(expected, q.slideRgb(k))
                            if (d > worst) worst = d
                            require(d <= 4) { "level $level corner $k: slides to ${hex(q.slideRgb(k))}, the next level paints ${hex(expected)} there" }
                            colourChecked++
                        }
                    }
                }
            }
        }
        println("      measured: $tops tops, $colourChecked corner colours; the largest difference from the next level's colour is $worst of 255")
        require(tops > 1000) { "too few tops compared" }
    }
}

/** What a top quad paints at (x, z): its four vertex colours, blended the way the GPU blends the two triangles of the quad. */
private fun parentColourAt(q: Quad, x: Float, z: Float): Int {
    val c0 = q.rgb(0)
    if (q.rgb(1) == c0 && q.rgb(2) == c0 && q.rgb(3) == c0) return c0
    // bilinear over the quad: vertex 0 = (minX, minZ), 1 = (minX, maxZ), 2 = (maxX, maxZ), 3 = (maxX, minZ)
    val u = ((x - q.minX) / (q.maxX - q.minX)).coerceIn(0f, 1f)
    val v = ((z - q.minZ) / (q.maxZ - q.minZ)).coerceIn(0f, 1f)
    var out = 0
    for (shift in intArrayOf(16, 8, 0)) {
        val a = ch(q.rgb(0), shift) * (1 - u) * (1 - v)
        val b = ch(q.rgb(1), shift) * (1 - u) * v
        val c = ch(q.rgb(2), shift) * u * v
        val d = ch(q.rgb(3), shift) * u * (1 - v)
        out = out or ((a + b + c + d + 0.5f).toInt() shl shift)
    }
    return out
}

// ------------------------------------------------------------------------------------------------ synthetic fields

private fun syntheticChecks(w: World) {
    fun flat(level: Int, height: Float, col: Int): CellField {
        val cells = FarLevels.cellsOf(level)
        val f = CellField(cells)
        for (c in f.topY.indices) {
            f.topY[c] = height
            f.heights[c] = height.toInt() - 1
            f.col[c] = col
            f.wallCol[c] = col
        }
        return f
    }
    val green = FarPalette.colorKey(TextureAtlas.RAMP_ROW_SURFACE, TextureAtlas.RAMP_GRASS + 1f)
    val level = 3

    check("synthetic: a flat tile is one rectangle and two triangles, whatever its size") {
        val f = flat(level, 90f, green)
        val mesh = w.mesher.buildLandMesh(level, 0, 0, f, ColumnSlide(f, null, FarLevels.landFloor(level)))
        require(mesh.indices.size == 6 && mesh.vertexCount == 4) { "${mesh.indices.size / 3} triangles, ${mesh.vertexCount} vertices" }
    }

    check("synthetic: one raised column in a flat tile costs its top, its four walls and at most five rectangles round it") {
        val f = flat(level, 90f, green)
        val cells = f.cells
        val c = (cells / 2 + 1) * f.n + cells / 2 + 1
        f.topY[c] = 100f
        val mesh = w.mesher.buildLandMesh(level, 0, 0, f, ColumnSlide(f, null, FarLevels.landFloor(level)))
        val quads = quadsOf(mesh)
        val walls = quads.count { it.isWall }
        val tops = quads.size - walls
        require(walls == 4) { "$walls walls" }
        require(tops <= 6) { "$tops tops" }
        var area = 0.0
        for (q in quads) if (!q.isWall) area += ((q.maxX - q.minX) / f.cells.let { FarLevels.step(level) }) * ((q.maxZ - q.minZ) / FarLevels.step(level))
        require(abs(area - cells * cells) < 1e-6) { "tops cover $area columns, the tile has ${cells * cells}" }
    }

    check("synthetic: a chessboard of heights makes every column its own top, with walls between all neighbours") {
        val f = flat(level, 90f, green)
        val cells = f.cells
        for (j in 0 until f.n) for (i in 0 until f.n) f.topY[j * f.n + i] = if ((i + j) % 2 == 0) 90f else 96f
        val mesh = w.mesher.buildLandMesh(level, 0, 0, f, ColumnSlide(f, null, FarLevels.landFloor(level)))
        val quads = quadsOf(mesh)
        require(quads.count { !it.isWall } == cells * cells) { "tops: ${quads.count { !it.isWall }}" }
        // every edge between neighbours inside the tile and half of the tile's own border has a wall (merged along an edge: none can merge here)
        val inner = 2 * cells * (cells - 1)
        val border = 4 * cells / 2
        require(quads.count { it.isWall } == inner + border) { "walls: ${quads.count { it.isWall }}, expected ${inner + border}" }
    }

    check("synthetic: colours that differ stop a merge, equal colours and heights do not") {
        val other = FarPalette.colorKey(TextureAtlas.RAMP_ROW_SURFACE, TextureAtlas.RAMP_SAND + 1f)
        val f = flat(level, 90f, green)
        val cells = f.cells
        for (j in 0 until f.n) for (i in f.n / 2 until f.n) f.col[j * f.n + i] = other
        f.wallCol.indices.forEach { f.wallCol[it] = f.col[it] }
        val mesh = w.mesher.buildLandMesh(level, 0, 0, f, ColumnSlide(f, null, FarLevels.landFloor(level)))
        val tops = quadsOf(mesh).filter { !it.isWall }
        require(tops.size == 2) { "${tops.size} tops, expected one per colour" }
        require(tops.sumOf { ((it.maxX - it.minX) / FarLevels.step(level) * (it.maxZ - it.minZ) / FarLevels.step(level)).toDouble() } == (cells * cells).toDouble()) { "area" }
    }

    check("synthetic: tops with different slide targets are not merged, and a wall opens between them") {
        val f = flat(level, 90f, green)
        val s = ColumnSlide(f, null, FarLevels.landFloor(level))
        for (j in 0 until f.n) for (i in f.n / 2 until f.n) s.y[j * f.n + i] = 94f
        val mesh = w.mesher.buildLandMesh(level, 0, 0, f, s)
        val quads = quadsOf(mesh)
        require(quads.count { !it.isWall } == 2) { "${quads.count { !it.isWall }} tops" }
        // equal heights, different slide: a wall of zero height now, four blocks once slid, along the whole seam
        val seam = quads.filter { it.isWall && it.minX == it.maxX }
        require(seam.isNotEmpty() && seam.all { abs(it.y(0) - it.y(2)) < EPS && abs(it.slideY(0) - 90f) < EPS && abs(it.slideY(2) - 94f) < EPS }) { "no zero-height wall over the seam" }
    }
}

// ------------------------------------------------------------------------------------------------ determinism

private fun determinismChecks(worlds: List<World>) {
    check("tiles: building a tile twice, in any order, gives the same bytes") {
        var n = 0
        for ((wi, w) in worlds.withIndex()) {
            for (level in 0 until FarLevels.COUNT) {
                val t = sampleTiles(w, level, 1, 400L + wi)[0]
                val again = w.Tile(level, t.tx, t.tz)
                require(crc(t.mesh) == crc(again.mesh)) { "level $level tile (${t.tx},${t.tz}) differs between two builds" }
                n++
            }
        }
        println("      measured: $n tiles built twice")
    }

    check("tiles: the reference tiles still have the bytes they had (an intended change to the meshes updates GOLDEN_FAR below)") {
        val w = worlds[1] // seed 12345
        val crcs = ArrayList<Long>()
        val out = StringBuilder()
        for (level in 0 until FarLevels.COUNT) {
            val t = w.Tile(level, 3 - level, -2 + level)
            crcs.add(crc(t.mesh))
            out.append(String.format("0x%08XL, ", crc(t.mesh)))
        }
        println("      measured: golden = $out")
        for (level in 0 until FarLevels.COUNT) require(crcs[level] == GOLDEN_FAR[level]) { "level $level tile changed: now ${String.format("0x%08XL", crcs[level])}" }
    }

    check("tiles: no level makes a tile of more than eight triangles per column (24 for the two tree levels)") {
        var worstRatio = 0.0
        for ((wi, w) in worlds.withIndex()) {
            for (level in 0 until FarLevels.COUNT) {
                for (t in sampleTiles(w, level, 2, 500L + wi)) {
                    val tris = t.mesh.indices.size / 3
                    val perColumn = tris.toDouble() / (t.cells * t.cells)
                    if (perColumn > worstRatio) worstRatio = perColumn
                    require(perColumn <= (if (level < FarLevels.TREE_LEVELS) 24.0 else 8.0)) { "level $level tile (${t.tx},${t.tz}): $tris triangles for ${t.cells * t.cells} columns" }
                }
            }
        }
        println("      measured: at most %.2f triangles per column".format(worstRatio))
    }
}

/** Checksums of the reference tiles of [determinismChecks], levels 0..7. The run prints the current values ("golden = ..."). */
private val GOLDEN_FAR = longArrayOf(0x60461A1DL, 0xDD9513B5L, 0x781A66A2L, 0x406F0C63L, 0x3D56DB0AL, 0x0E48113DL, 0x147692EAL, 0x405BC83BL)


// ------------------------------------------------------------------------------------------------ stand-ins

/** The planner's rule for which tiles of [level] it builds around ([px], [pz]) when the player stands still (see
 *  FarTerrain.planTiles; the margin is its PLAN_MARGIN): the tiles whose ring is on screen, and a margin beyond. */
private fun plannedAt(level: Int, tx: Int, tz: Int, px: Float, pz: Float, radius: Float): Boolean {
    val margin = 24f
    val inner = FarRings.planInner(level)
    if (inner - margin > radius) return false
    val visibleOuter = min(FarRings.drawOuter(level), radius)
    val outer = min(FarRings.drawOuter(level) + margin, radius)
    if (outer <= inner + 1f) return false
    val near = FarTileMath.nearest(level, tx, tz, px, pz)
    val far = FarTileMath.farthest(level, tx, tz, px, pz)
    val visible = near < visibleOuter && (inner <= 0f || far >= inner)
    return visible || (near <= outer && (inner <= 0f || far >= inner - margin))
}

private fun standInChecks() {
    check("stand-ins: the ancestor of a tile is the tile of the coarser level that contains it, negative coordinates included") {
        val rnd = Random(77)
        var n = 0
        for (own in 0 until FarLevels.COUNT) {
            val size = FarLevels.tileBlocks(own).toLong()
            for (level in own until FarLevels.COUNT) {
                val big = FarLevels.tileBlocks(level).toLong()
                repeat(300) {
                    val tx = rnd.nextInt(4001) - 2000
                    val tz = rnd.nextInt(4001) - 2000
                    val key = FarTerrain.tileKey(own, tx, tz)
                    val a = FarStandIns.ancestor(key, level)
                    require(FarTerrain.levelOf(a) == level) { "level of the ancestor of $own/$tx/$tz at $level is ${FarTerrain.levelOf(a)}" }
                    val ax = FarTerrain.tileX(a) * big
                    val az = FarTerrain.tileZ(a) * big
                    require(ax <= tx * size && (tx + 1) * size <= ax + big && az <= tz * size && (tz + 1) * size <= az + big) {
                        "tile $own/$tx/$tz is not inside its ancestor $level/${FarTerrain.tileX(a)}/${FarTerrain.tileZ(a)}"
                    }
                    n++
                }
            }
            val key = FarTerrain.tileKey(own, -3, 7)
            require(FarStandIns.ancestor(key, own) == key) { "the ancestor of a tile at its own level is the tile" }
            if (own > 0) require(FarStandIns.ancestor(key, own - 1) == key) { "a finer level has no ancestor: the tile itself comes back" }
        }
        require(n > 2000) { "only $n pairs checked" }
    }

    check("stand-ins: the finest coarser tile that is there wins; none there means none; the coarsest level has no stand-in") {
        for (own in 0 until FarLevels.COUNT) {
            val key = FarTerrain.tileKey(own, -5, 9)
            val none = FarStandIns.find(key) { false }
            require(none == FarStandIns.NONE) { "level $own: nothing resident, but found $none" }
            val all = FarStandIns.find(key) { true }
            if (own == FarLevels.COUNT - 1) {
                require(all == FarStandIns.NONE) { "the coarsest level has no coarser tile" }
            } else {
                require(all == FarStandIns.ancestor(key, own + 1)) { "level $own: with everything resident the next level must stand in" }
            }
            // only the levels two and four above are there: the nearer of them wins
            if (own + 2 < FarLevels.COUNT) {
                val two = FarStandIns.ancestor(key, own + 2)
                val four = if (own + 4 < FarLevels.COUNT) FarStandIns.ancestor(key, own + 4) else two
                val got = FarStandIns.find(key) { it == two || it == four }
                require(got == two) { "level $own: the finest resident ancestor is level ${own + 2}, got level ${FarTerrain.levelOf(got)}" }
                if (own + 4 < FarLevels.COUNT) {
                    val only = FarStandIns.find(key) { it == four }
                    require(only == four) { "level $own: only level ${own + 4} is there, got $only" }
                }
            }
            // a tile that is itself the one resident does not stand in for itself
            require(FarStandIns.find(key) { it == key } == FarStandIns.NONE) { "level $own: a tile stands in for itself" }
        }
    }

    check("stand-ins: the tiles listed for a ring are exactly the tiles that touch its part within reach (brute force)") {
        val rnd = Random(31)
        var listed = 0
        for (level in 1 until FarLevels.COUNT - 1) {
            val inner = FarRings.drawInner(level)
            val outer = FarRings.drawOuter(level)
            val size = FarLevels.tileBlocks(level)
            repeat(25) {
                val ex = (rnd.nextFloat() - 0.5f) * 40000f
                val ez = (rnd.nextFloat() - 0.5f) * 40000f
                val reach = 300f + rnd.nextFloat() * 3500f
                val got = ArrayList<Long>()
                FarStandIns.forEachRingTile(level, ex, ez, inner, outer, reach) { got.add(it) }
                val limit = min(outer, reach)
                val want = ArrayList<Long>()
                val span = (limit / size).toInt() + 3
                val cx = floor(ex / size).toInt()
                val cz = floor(ez / size).toInt()
                for (tz in cz - span..cz + span) for (tx in cx - span..cx + span) {
                    if (limit > inner &&
                        FarTileMath.nearest(level, tx, tz, ex, ez) < limit && FarTileMath.farthest(level, tx, tz, ex, ez) >= inner
                    ) want.add(FarTerrain.tileKey(level, tx, tz))
                }
                require(got.sorted() == want.sorted()) { "level $level eye ($ex, $ez) reach $reach: ${got.size} tiles listed, ${want.size} touch the ring" }
                require(got.toSet().size == got.size) { "level $level: a tile was listed twice" }
                listed += got.size
            }
        }
        require(listed > 500) { "only $listed tiles listed over all the cases" }
    }

    check("stand-ins: ground the picture needs but the plan did not reach, on the side the player walks towards, always has a built coarser tile") {
        val radius = 3300f
        val rnd = Random(5)
        var checked = 0
        var trailing = 0
        val levels = FarLevels.COUNT
        repeat(80) {
            val px = (rnd.nextFloat() - 0.5f) * 20000f
            val pz = (rnd.nextFloat() - 0.5f) * 20000f
            val angle = rnd.nextFloat() * 2f * PI.toFloat()
            val moved = 25f + rnd.nextFloat() * 125f // more than the plan's margin: the builders have not caught up
            val qx = px + cos(angle) * moved
            val qz = pz + sin(angle) * moved
            val built = HashSet<Long>()
            for (level in 1 until levels) {
                val size = FarLevels.tileBlocks(level)
                val reach = min(FarRings.drawOuter(level) + 24f, radius)
                val minTx = Math.floorDiv(floor(px - reach).toInt(), size)
                val maxTx = Math.floorDiv(floor(px + reach).toInt(), size)
                val minTz = Math.floorDiv(floor(pz - reach).toInt(), size)
                val maxTz = Math.floorDiv(floor(pz + reach).toInt(), size)
                for (tz in minTz..maxTz) for (tx in minTx..maxTx) {
                    if (plannedAt(level, tx, tz, px, pz, radius)) built.add(FarTerrain.tileKey(level, tx, tz))
                }
            }
            for (level in 1 until levels - 1) {
                val inner = FarRings.drawInner(level)
                val outer = FarRings.drawOuter(level)
                FarStandIns.forEachRingTile(level, qx, qz, inner, outer, radius * 0.95f) { key ->
                    if (built.contains(key)) return@forEachRingTile
                    val tx = FarTerrain.tileX(key)
                    val tz = FarTerrain.tileZ(key)
                    // beyond the render distance at the old position: the horizon growing, nothing coarser exists there
                    if (FarTileMath.nearest(level, tx, tz, px, pz) >= radius) return@forEachRingTile
                    // wholly inside the finer ring at the old position: the trailing edge, behind the player
                    if (FarTileMath.farthest(level, tx, tz, px, pz) < inner - 24f) {
                        trailing++
                        return@forEachRingTile
                    }
                    val s = FarStandIns.find(key) { built.contains(it) }
                    require(s != FarStandIns.NONE) {
                        "level $level tile ($tx, $tz) needed at ($qx, $qz) after ${moved.toInt()} blocks from ($px, $pz): nothing coarser is built"
                    }
                    checked++
                }
            }
        }
        require(checked > 40) { "only $checked uncovered tiles were checked" }
        println("      measured: $checked leading-edge holes all had a stand-in; $trailing trailing-edge holes were not asked to")
    }
}
