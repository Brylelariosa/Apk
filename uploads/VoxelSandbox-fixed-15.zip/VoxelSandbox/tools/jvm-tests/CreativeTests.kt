package tests

import com.voxelsandbox.game.creative.BlockCategory
import com.voxelsandbox.game.creative.BlockIcons
import com.voxelsandbox.game.creative.CreativeCatalog
import com.voxelsandbox.game.engine.PlacementRules
import com.voxelsandbox.game.gl.TileSources
import com.voxelsandbox.game.inventory.Hotbar
import com.voxelsandbox.game.player.FlightMath
import com.voxelsandbox.game.player.PhysicsController
import com.voxelsandbox.game.player.Player
import com.voxelsandbox.game.save.SaveCodec
import com.voxelsandbox.game.save.SaveHeader
import com.voxelsandbox.game.world.BlockType
import com.voxelsandbox.game.world.Chunk
import com.voxelsandbox.game.world.ChunkPos
import com.voxelsandbox.game.world.Fluid
import com.voxelsandbox.game.world.World
import com.voxelsandbox.game.world.WorldConfig
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/** Plain-Kotlin test runner (the project has no test dependencies by design): prints PASS/FAIL per check, exits 1 on any failure. */
private var failures = 0
private var passed = 0

private fun check(name: String, body: () -> Unit) {
    try {
        body()
        passed++
        println("PASS  $name")
    } catch (t: Throwable) {
        failures++
        println("FAIL  $name -> ${t.javaClass.simpleName}: ${t.message}")
    }
}

private fun require(cond: Boolean, msg: () -> String) {
    if (!cond) throw AssertionError(msg())
}

private fun near(a: Float, b: Float, eps: Float, msg: String) = require(abs(a - b) <= eps) { "$msg: $a vs $b (eps $eps)" }

private fun flatWorld(): World {
    val world = World()
    for (cx in -1..1) for (cz in -1..1) world.putChunk(Chunk(ChunkPos(cx, cz)))
    // stone floor up to y=63, everything above air
    for (x in -16..31) for (z in -16..31) for (y in 0..63) world.setBlock(x, y, z, BlockType.STONE)
    return world
}

fun main() {
    // ---------------------------------------------------------------- registry / catalogue
    check("catalogue lists every registered block except air, once") {
        val expected = BlockType.values().filter { it != BlockType.AIR }
        val listed = CreativeCatalog.entries.map { it.block }
        require(listed.size == expected.size) { "listed ${listed.size}, registry has ${expected.size}" }
        require(listed.toSet() == expected.toSet()) { "sets differ" }
        require(BlockType.AIR !in listed) { "air is listed" }
    }
    check("catalogue has no problems (names, tabs, icons)") {
        val p = CreativeCatalog.problems()
        require(p.isEmpty()) { p.joinToString("; ") }
    }
    check("every block is sorted into a real tab and no tab is empty") {
        for (b in BlockType.values()) if (b != BlockType.AIR) require(BlockCategory.of(b) != BlockCategory.OTHER) { "$b in OTHER" }
        for (c in CreativeCatalog.categories) require(CreativeCatalog.entries.any { it.category == c }) { "$c empty" }
        require(CreativeCatalog.categories.toSet() == CreativeCatalog.entries.map { it.category }.toSet()) { "tab set mismatch" }
    }
    check("catalogue order is tab order then registry order") {
        val e = CreativeCatalog.entries
        for (i in 1 until e.size) {
            val a = e[i - 1]; val b = e[i]
            require(a.category.ordinal < b.category.ordinal ||
                (a.category == b.category && a.block.id < b.block.id)) { "${a.name} before ${b.name}" }
        }
    }
    check("every block's textures exist and every tile is exactly 16x16") {
        for (t in TileSources.tiles) require(t.pixels.size == 16 * 16) { "${t.name} has ${t.pixels.size} px" }
        for (b in BlockType.values()) {
            if (b == BlockType.AIR) continue
            for (cell in listOf(b.topCell, b.sideCell, b.bottomCell)) {
                require(TileSources.pixelsFor(cell) != null) { "$b uses cell $cell with no tile" }
            }
        }
        require(TileSources.tiles.map { it.cell }.toSet().size == TileSources.tiles.size) { "two tiles share a cell" }
    }

    // ---------------------------------------------------------------- icons
    check("every icon is 32x32, non-empty and has a real silhouette") {
        for (e in CreativeCatalog.entries) {
            val px = BlockIcons.render(e.block) { TileSources.pixelsFor(it) } ?: throw AssertionError("${e.name}: no icon")
            require(px.size == BlockIcons.SIZE * BlockIcons.SIZE) { "${e.name}: size ${px.size}" }
            val opaque = px.count { (it ushr 24) >= 128 }
            require(opaque >= 80) { "${e.name}: only $opaque opaque pixels" }
            val colours = px.filter { (it ushr 24) != 0 }.toSet().size
            require(colours >= 4) { "${e.name}: only $colours colours" }
        }
    }
    check("no two blocks share an icon") {
        val seen = HashMap<Int, String>()
        for (e in CreativeCatalog.entries) {
            val px = BlockIcons.render(e.block) { TileSources.pixelsFor(it) }!!
            val h = px.contentHashCode()
            val other = seen.put(h, e.name)
            require(other == null) { "${e.name} has the same icon as $other" }
        }
    }
    check("an icon is built from its own texture (cube top = shaded top texel, sprite = 2x texture)") {
        val grass = BlockIcons.render(BlockType.GRASS) { TileSources.pixelsFor(it) }!!
        val top = TileSources.pixelsFor(BlockType.GRASS.topCell)!!
        // the pixel at the middle of the top diamond (16, 8) comes from the tile's centre (texel 8,8 +- 1) at full brightness
        val c = grass[8 * 32 + 16]
        val candidates = HashSet<Int>()
        for (dy in 6..9) for (dx in 6..9) candidates.add(top[dy * 16 + dx] or (0xFF shl 24))
        require(c in candidates) { "top centre %08x not among tile centre texels".format(c) }
        val poppy = BlockIcons.render(BlockType.POPPY) { TileSources.pixelsFor(it) }!!
        val tile = TileSources.pixelsFor(BlockType.POPPY.topCell)!!
        for (y in 0 until 32) for (x in 0 until 32) {
            val t = tile[(y / 2) * 16 + x / 2]
            if ((t ushr 24) >= 128) require(poppy[y * 32 + x] == (t or (0xFF shl 24))) { "sprite pixel $x,$y differs" }
        }
    }
    check("a block with a missing texture gets no icon (reported, not faked)") {
        require(BlockIcons.render(BlockType.STONE) { null } == null) { "icon without tile" }
        require(BlockIcons.render(BlockType.AIR) { TileSources.pixelsFor(it) } == null) { "air has icon" }
    }

    // ---------------------------------------------------------------- search
    check("empty search returns everything; unknown text returns nothing") {
        require(CreativeCatalog.search("").size == CreativeCatalog.entries.size) { "empty" }
        require(CreativeCatalog.search("   ").size == CreativeCatalog.entries.size) { "blank" }
        require(CreativeCatalog.search("qqqzzz").isEmpty()) { "garbage" }
    }
    check("search finds blocks by name, part of a name, synonym and tab; case-insensitive") {
        fun blocks(q: String, c: BlockCategory? = null) = CreativeCatalog.search(q, c).map { it.block }
        require(blocks("lea").toSet() == setOf(BlockType.LEAVES, BlockType.BIRCH_LEAVES, BlockType.SPRUCE_LEAVES)) { "lea: ${blocks("lea")}" }
        require(blocks("BIRCH").toSet() == setOf(BlockType.BIRCH_WOOD, BlockType.BIRCH_LEAVES)) { "birch: ${blocks("BIRCH")}" }
        require(blocks("birch tree").toSet() == setOf(BlockType.BIRCH_WOOD, BlockType.BIRCH_LEAVES)) { "birch tree" }
        require(BlockType.POPPY in blocks("flower") && BlockType.DANDELION in blocks("flower")) { "flower" }
        require(BlockType.WATER in blocks("liquid")) { "liquid" }
        require(blocks("log").toSet() == setOf(BlockType.WOOD, BlockType.BIRCH_WOOD, BlockType.SPRUCE_WOOD)) { "log: ${blocks("log")}" }
        require(blocks("plants").toSet() == CreativeCatalog.entries.filter { it.category == BlockCategory.PLANTS }.map { it.block }.toSet()) { "tab word" }
        require(blocks("coal") == listOf(BlockType.COAL_ORE)) { "coal" }
    }
    check("best matches come first, category filter narrows") {
        require(CreativeCatalog.search("water").first().block == BlockType.WATER) { "water first" }
        require(CreativeCatalog.search("grass").first().block == BlockType.GRASS || CreativeCatalog.search("grass").first().name.lowercase().contains("grass")) { "grass first" }
        val plants = CreativeCatalog.search("grass", BlockCategory.PLANTS).map { it.block }
        require(plants.all { BlockCategory.of(it) == BlockCategory.PLANTS } && BlockType.TALL_GRASS in plants && BlockType.GRASS !in plants) { "plants only: $plants" }
        require(CreativeCatalog.search("", BlockCategory.LIQUIDS).map { it.block } == listOf(BlockType.WATER)) { "liquids" }
    }
    check("search is stable and deterministic") {
        require(CreativeCatalog.search("a").map { it.block } == CreativeCatalog.search("a").map { it.block }) { "unstable" }
    }

    // ---------------------------------------------------------------- hotbar
    check("hotbar starts as the old default layout, first slot selected") {
        val h = Hotbar()
        for (i in 0 until Hotbar.SIZE) require(h.blockAt(i) == Hotbar.DEFAULT_LAYOUT[i]) { "slot $i" }
        require(h.selectedIndex == 0 && h.selectedBlock() == BlockType.GRASS) { "selection" }
        require(h.blockAt(-1) == BlockType.AIR && h.blockAt(Hotbar.SIZE) == BlockType.AIR) { "range" }
    }
    check("picking a new block puts it in the selected slot at once; an existing one selects its slot") {
        val h = Hotbar()
        h.select(3)
        require(h.pick(BlockType.CACTUS) == 3 && h.blockAt(3) == BlockType.CACTUS && h.selectedBlock() == BlockType.CACTUS) { "new" }
        h.select(5)
        require(h.pick(BlockType.DIRT) == 1 && h.selectedIndex == 1 && h.blockAt(5) == BlockType.LEAVES) { "existing keeps slot 5" }
        require(h.pick(BlockType.AIR) == -1 && h.selectedIndex == 1) { "air rejected" }
    }
    check("every registered block can be picked and is then what is placed") {
        val h = Hotbar()
        for (e in CreativeCatalog.entries) {
            require(h.pick(e.block) >= 0) { "${e.name} not pickable" }
            require(h.selectedBlock() == e.block) { "${e.name} not selected after pick" }
        }
    }
    check("hotbar save/restore round-trips and repairs bad data") {
        val h = Hotbar()
        h.select(2); h.pick(BlockType.SEAGRASS); h.select(6)
        val ids = h.exportIds()
        val h2 = Hotbar()
        h2.restore(ids, h.selectedIndex)
        for (i in 0 until Hotbar.SIZE) require(h2.blockAt(i) == h.blockAt(i)) { "slot $i" }
        require(h2.selectedIndex == 6) { "selection" }
        val h3 = Hotbar()
        h3.restore(byteArrayOf(0, 57, 99.toByte(), 255.toByte(), BlockType.POPPY.id), 42)
        require(h3.blockAt(0) == Hotbar.DEFAULT_LAYOUT[0] && h3.blockAt(1) == Hotbar.DEFAULT_LAYOUT[1] &&
            h3.blockAt(2) == Hotbar.DEFAULT_LAYOUT[2] && h3.blockAt(3) == Hotbar.DEFAULT_LAYOUT[3]) { "invalid ids not replaced by defaults" }
        require(h3.blockAt(4) == BlockType.POPPY) { "valid id kept" }
        for (i in 5 until Hotbar.SIZE) require(h3.blockAt(i) == Hotbar.DEFAULT_LAYOUT[i]) { "short data slot $i" }
        require(h3.selectedIndex == 0) { "bad selection" }
        val h4 = Hotbar(); h4.restore(null, -1)
        for (i in 0 until Hotbar.SIZE) require(h4.blockAt(i) == Hotbar.DEFAULT_LAYOUT[i]) { "null data" }
    }
    check("hotbar survives two threads hammering it") {
        val h = Hotbar()
        val err = java.util.concurrent.atomic.AtomicReference<Throwable?>(null)
        val entries = CreativeCatalog.entries
        val t1 = Thread { try { repeat(200_000) { h.pick(entries[it % entries.size].block); h.select(it % Hotbar.SIZE) } } catch (t: Throwable) { err.set(t) } }
        val t2 = Thread { try { repeat(200_000) { val b = h.selectedBlock(); require(b != BlockType.AIR) { "air selected" }; h.exportIds() } } catch (t: Throwable) { err.set(t) } }
        t1.start(); t2.start(); t1.join(); t2.join()
        err.get()?.let { throw it }
    }

    // ---------------------------------------------------------------- save codec
    fun header(ids: ByteArray = Hotbar().exportIds(), sel: Int = 3, flying: Boolean = true) =
        SaveHeader(-123456789L, 10.5f, 70f, -3.25f, 1.5f, -0.4f, ids, sel, flying)
    fun chunkBytes(seed: Int) = ByteArray(WorldConfig.BYTES_PER_CHUNK) { ((it * 31 + seed) and 0x1F).toByte() }
    fun write(h: SaveHeader, chunks: List<Pair<ChunkPos, ByteArray>>): ByteArray {
        val bos = ByteArrayOutputStream()
        DataOutputStream(bos).use { SaveCodec.write(it, h, chunks.size, chunks.iterator()) }
        return bos.toByteArray()
    }
    fun read(bytes: ByteArray) = SaveCodec.read(DataInputStream(ByteArrayInputStream(bytes)))

    check("save round trip keeps header, hotbar, flight and every edited chunk") {
        val chunks = listOf(ChunkPos(0, 0) to chunkBytes(1), ChunkPos(-5, 7) to chunkBytes(2))
        val bytes = write(header(), chunks)
        val s = read(bytes) ?: throw AssertionError("null")
        require(s.seed == -123456789L && s.playerX == 10.5f && s.playerY == 70f && s.playerZ == -3.25f && s.yaw == 1.5f && s.pitch == -0.4f) { "header" }
        require(s.hotbarIds!!.contentEquals(Hotbar().exportIds()) && s.hotbarSelected == 3 && s.flying) { "hotbar/flying" }
        require(s.chunkOverrides.size == 2) { "chunk count" }
        for ((pos, data) in chunks) require(s.chunkOverrides[pos]!!.contentEquals(data)) { "chunk $pos" }
    }
    check("a version 4 save (survival counts, no hotbar) still loads: world kept, hotbar default") {
        val bos = ByteArrayOutputStream()
        DataOutputStream(bos).use { o ->
            o.writeInt(SaveCodec.MAGIC); o.writeInt(4); o.writeLong(77L)
            o.writeFloat(1f); o.writeFloat(2f); o.writeFloat(3f); o.writeFloat(0.5f); o.writeFloat(0.25f)
            o.writeInt(8); repeat(8) { o.writeInt(it * 10) }
            o.writeInt(1); o.writeInt(4); o.writeInt(-9); o.write(chunkBytes(9))
        }
        val s = read(bos.toByteArray()) ?: throw AssertionError("v4 save rejected")
        require(s.seed == 77L && s.playerY == 2f && s.yaw == 0.5f) { "header" }
        require(s.hotbarIds == null && s.hotbarSelected == 0 && !s.flying) { "defaults" }
        require(s.chunkOverrides[ChunkPos(4, -9)]!!.contentEquals(chunkBytes(9))) { "chunk" }
        val h = Hotbar(); h.restore(s.hotbarIds, s.hotbarSelected)
        for (i in 0 until Hotbar.SIZE) require(h.blockAt(i) == Hotbar.DEFAULT_LAYOUT[i]) { "default hotbar" }
    }
    check("unreadable saves give null, never an exception") {
        val good = write(header(), listOf(ChunkPos(1, 1) to chunkBytes(3)))
        require(read(ByteArray(0)) == null) { "empty" }
        for (cut in listOf(1, 3, 7, 12, 30, 45, 60, 100, 5000, good.size - 1)) require(read(good.copyOf(cut)) == null) { "truncated at $cut" }
        fun patched(offset: Int, value: Int): ByteArray = good.copyOf().also {
            it[offset] = (value ushr 24).toByte(); it[offset + 1] = (value ushr 16).toByte(); it[offset + 2] = (value ushr 8).toByte(); it[offset + 3] = value.toByte()
        }
        require(read(patched(0, 0x12345678)) == null) { "bad magic" }
        require(read(patched(4, 3)) == null) { "version 3" }
        require(read(patched(4, 6)) == null) { "future version" }
        require(read(patched(8 + 8 + 20, 1000)) == null) { "absurd slot count" }
        require(read(patched(8 + 8 + 20, -1)) == null) { "negative slot count" }
        val nan = good.copyOf(); val nb = java.lang.Float.floatToIntBits(Float.NaN)
        nan[16] = (nb ushr 24).toByte(); nan[17] = (nb ushr 16).toByte(); nan[18] = (nb ushr 8).toByte(); nan[19] = nb.toByte()
        require(read(nan) == null) { "NaN position" }
    }
    check("a save with an unknown block id in its hotbar loads and the slot falls back to its default") {
        val ids = ByteArray(Hotbar.SIZE) { 100 } // not a registered block
        val s = read(write(header(ids = ids), emptyList())) ?: throw AssertionError("rejected")
        val h = Hotbar(); h.restore(s.hotbarIds, s.hotbarSelected)
        for (i in 0 until Hotbar.SIZE) require(h.blockAt(i) == Hotbar.DEFAULT_LAYOUT[i]) { "slot $i" }
    }

    // ---------------------------------------------------------------- flight maths
    check("flight: forward is the horizontal direction the camera faces; pitch never changes height") {
        val v = FloatArray(3)
        FlightMath.targetVelocity(1f, 0f, false, false, 0f, 30f, v)
        near(v[0], 0f, 1e-4f, "yaw 0 vx"); near(v[2], -30f, 1e-4f, "yaw 0 vz (looks down -Z)"); near(v[1], 0f, 1e-6f, "vy")
        FlightMath.targetVelocity(1f, 0f, false, false, (Math.PI / 2).toFloat(), 30f, v)
        near(v[0], 30f, 1e-3f, "yaw 90 vx"); near(v[2], 0f, 1e-3f, "yaw 90 vz")
        FlightMath.targetVelocity(0f, 1f, false, false, 0f, 30f, v)
        near(v[0], 30f, 1e-4f, "strafe right vx"); near(v[2], 0f, 1e-4f, "strafe vz")
        FlightMath.targetVelocity(0.6f, 0.8f, false, false, 0.7f, 30f, v)
        near(Math.hypot(v[0].toDouble(), v[2].toDouble()).toFloat(), 30f, 1e-3f, "full stick = fly speed")
        FlightMath.targetVelocity(1f, 1f, false, false, 0.7f, 30f, v)
        near(Math.hypot(v[0].toDouble(), v[2].toDouble()).toFloat(), 30f, 1e-3f, "diagonal stick limited to fly speed")
    }
    check("flight: ascend / descend buttons climb and sink at a fixed speed, both cancel") {
        val v = FloatArray(3)
        FlightMath.targetVelocity(0f, 0f, true, false, 0f, 30f, v); near(v[1], FlightMath.climbSpeed(30f), 1e-4f, "up")
        FlightMath.targetVelocity(0f, 0f, false, true, 0f, 30f, v); near(v[1], -FlightMath.climbSpeed(30f), 1e-4f, "down")
        FlightMath.targetVelocity(0f, 0f, true, true, 0f, 30f, v); near(v[1], 0f, 1e-6f, "both")
        require(FlightMath.climbSpeed(8f) >= 8f && FlightMath.climbSpeed(200f) <= 60f) { "climb limits" }
    }
    check("flight: distance flown is the same at 20, 30, 60 and 144 fps (and when stopping)") {
        fun fly(fps: Int, seconds: Float, stickSeconds: Float): Float {
            val vel = FloatArray(3)
            var x = 0f
            val dt = 1f / fps
            val frames = Math.round(seconds * fps)
            val stickFrames = Math.round(stickSeconds * fps)
            for (f in 0 until frames) x += FlightMath.advance(vel, 0, if (f < stickFrames) 30f else 0f, dt)
            return x
        }
        val ref = fly(1200, 3f, 2f)
        var worst = 0f
        for (fps in listOf(20, 30, 60, 144)) {
            val d = fly(fps, 3f, 2f)
            worst = maxOf(worst, abs(d - ref))
            require(abs(d - ref) <= 0.35f) { "$fps fps flew $d vs $ref" }
        }
        println("      (3 s flight, stick released at 2 s: reference ${ref} blocks, worst difference ${worst} blocks)")
        // exactness for a constant stick (no change of target inside a frame)
        val a = fly(20, 2f, 2f); val b = fly(240, 2f, 2f)
        require(abs(a - b) <= 1e-3f * b) { "constant stick $a vs $b" }
    }
    check("flight: speeds up to 95% within 0.35 s and stops within 0.25 s") {
        val vel = FloatArray(3)
        var t = 0f
        while (vel[0] < 0.95f * 30f && t < 2f) { FlightMath.advance(vel, 0, 30f, 1f / 60f); t += 1f / 60f }
        require(t <= 0.35f) { "took $t s to reach 95%" }
        t = 0f
        while (abs(vel[0]) > 0.05f * 30f && t < 2f) { FlightMath.advance(vel, 0, 0f, 1f / 60f); t += 1f / 60f }
        require(t <= 0.25f) { "took $t s to stop" }
    }

    // ---------------------------------------------------------------- flight collision
    check("flying into a wall stops at it; landing sets onGround; moving inside solid blocks is never stuck") {
        val world = flatWorld()
        for (y in 64..70) for (z in -16..31) world.setBlock(5, y, z, BlockType.STONE) // wall at x=5
        val phys = PhysicsController(world)
        val p = Player()
        p.position.set(2.5f, 66f, 2.5f)
        var blocked = 0
        repeat(40) { blocked = blocked or phys.flyMove(p, 0.5f, 0f, 0f) }
        require(blocked and PhysicsController.BLOCKED_X != 0) { "wall not reported" }
        require(p.position.x <= 5f - Player.WIDTH / 2f + 1e-3f && p.position.x > 4f) { "stopped at ${p.position.x}" }
        p.position.set(2.5f, 66f, 2.5f)
        var landed = 0
        repeat(40) { landed = landed or phys.flyMove(p, 0f, -0.5f, 0f) }
        require(landed and PhysicsController.BLOCKED_DOWN != 0 && p.onGround) { "landing" }
        near(p.position.y, 64f, 1e-3f, "feet on the floor")
        // inside solid: skip collision, can leave
        p.position.set(2.5f, 60f, 2.5f)
        phys.flyMove(p, 0f, 0.5f, 0f)
        near(p.position.y, 60.5f, 1e-4f, "free movement inside terrain")
    }
    check("a long flight step (200 blocks/s at 20 fps) cannot tunnel through a thin wall") {
        val world = flatWorld()
        for (y in 64..70) for (z in -16..31) world.setBlock(8, y, z, BlockType.STONE)
        val phys = PhysicsController(world)
        val p = Player(); p.position.set(2.5f, 66f, 2.5f)
        phys.flyMove(p, 10f, 0f, 0f) // one 0.05 s frame at 200 blocks/s
        require(p.position.x < 8f) { "tunnelled to ${p.position.x}" }
    }

    // ---------------------------------------------------------------- placement rules
    check("cube blocks go into air, water and plants; never into solids or out of the world") {
        val w = flatWorld()
        require(PlacementRules.canPlace(w, BlockType.STONE, 0, 64, 0)) { "air" }
        require(!PlacementRules.canPlace(w, BlockType.STONE, 0, 63, 0)) { "solid" }
        w.setBlock(1, 64, 0, BlockType.WATER); require(PlacementRules.canPlace(w, BlockType.SAND, 1, 64, 0)) { "water" }
        w.setBlock(2, 64, 0, BlockType.POPPY); require(PlacementRules.canPlace(w, BlockType.SAND, 2, 64, 0)) { "plant" }
        require(!PlacementRules.canPlace(w, BlockType.STONE, 0, WorldConfig.WORLD_HEIGHT, 0)) { "above world" }
        require(!PlacementRules.canPlace(w, BlockType.STONE, 0, 0, 0)) { "bottom" }
        require(!PlacementRules.canPlace(w, BlockType.AIR, 0, 64, 0)) { "air block" }
    }
    check("every catalogue block has at least one legal place to go in a suitable setting") {
        val w = flatWorld()
        // a pond: water cells above the stone floor at x=10..12
        for (x in 10..12) for (z in 10..12) for (y in 61..63) { w.setBlock(x, y, z, BlockType.STONE); }
        for (x in 10..12) for (z in 10..12) { w.setBlock(x, 62, z, BlockType.WATER); w.setBlock(x, 63, z, BlockType.WATER) }
        for (e in CreativeCatalog.entries) {
            val b = e.block
            val (x, y, z) = when (b) {
                BlockType.LILY_PAD -> Triple(11, 63, 11)      // aimed into the water: must rise to the surface
                BlockType.SEAGRASS -> Triple(11, 62, 11)       // the water cell right above the bed
                else -> Triple(0, 64, 0)
            }
            val ty = PlacementRules.targetY(w, b, x, y, z)
            require(PlacementRules.canPlace(w, b, x, ty, z)) { "${e.name} cannot be placed in its natural setting (y=$ty)" }
        }
    }
    check("plants need a solid block under them and open air; lily pads need water; seagrass needs water") {
        val w = flatWorld()
        require(PlacementRules.canPlace(w, BlockType.POPPY, 0, 64, 0)) { "poppy on ground" }
        require(!PlacementRules.canPlace(w, BlockType.POPPY, 0, 70, 0)) { "floating poppy" }
        require(!PlacementRules.canPlace(w, BlockType.LILY_PAD, 0, 64, 0)) { "lily pad on dry land" }
        require(!PlacementRules.canPlace(w, BlockType.SEAGRASS, 0, 64, 0)) { "seagrass in air" }
        w.setBlock(4, 64, 4, BlockType.WATER)
        require(!PlacementRules.canPlace(w, BlockType.POPPY, 4, 64, 4)) { "poppy in water" }
        require(PlacementRules.canPlace(w, BlockType.SEAGRASS, 4, 64, 4)) { "seagrass in water over stone" }
        w.setBlock(6, 64, 6, BlockType.WATER); w.setBlock(6, 65, 6, BlockType.WATER)
        require(!PlacementRules.canPlace(w, BlockType.SEAGRASS, 6, 65, 6)) { "seagrass over water, not over a bed" }
        require(PlacementRules.targetY(w, BlockType.LILY_PAD, 6, 64, 6) == 66) { "lily pad rises to the surface" }
        require(PlacementRules.canPlace(w, BlockType.LILY_PAD, 6, 66, 6)) { "lily pad on the surface" }
        require(PlacementRules.targetY(w, BlockType.STONE, 6, 64, 6) == 64) { "other blocks stay where aimed" }
        // flowing water (partial level) still holds a lily pad
        w.setRaw(8, 64, 8, Fluid.rawFor(3))
        require(PlacementRules.canPlace(w, BlockType.LILY_PAD, 8, 65, 8)) { "lily pad on flowing water" }
    }
    check("solid blocks cannot be put where the player stands; plants and water can") {
        val p = Player(); p.position.set(0.5f, 64f, 0.5f)
        require(PlacementRules.trapsPlayer(p, BlockType.STONE, 0, 64, 0)) { "feet" }
        require(PlacementRules.trapsPlayer(p, BlockType.STONE, 0, 65, 0)) { "head" }
        require(!PlacementRules.trapsPlayer(p, BlockType.STONE, 0, 66, 0)) { "above head" }
        require(!PlacementRules.trapsPlayer(p, BlockType.STONE, 3, 64, 0)) { "beside" }
        require(!PlacementRules.trapsPlayer(p, BlockType.WATER, 0, 64, 0)) { "water" }
        require(!PlacementRules.trapsPlayer(p, BlockType.POPPY, 0, 64, 0)) { "plant" }
    }

    println("\n$passed passed, $failures failed")
    if (failures > 0) System.exit(1)
}
