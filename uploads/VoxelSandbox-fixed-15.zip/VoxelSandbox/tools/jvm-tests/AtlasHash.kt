package tests

import com.voxelsandbox.game.gl.TextureAtlas
import java.security.MessageDigest

/** Prints a SHA-256 over every mip level of the atlas the game builds, so a refactor of how the tiles are
 *  collected can be proven to leave the atlas byte-identical. */
fun main() {
    val atlas = TextureAtlas()
    val f = TextureAtlas::class.java.getDeclaredField("mips"); f.isAccessible = true
    @Suppress("UNCHECKED_CAST") val mips = f.get(atlas) as Array<IntArray>
    val md = MessageDigest.getInstance("SHA-256")
    for (level in mips) {
        val b = java.nio.ByteBuffer.allocate(level.size * 4)
        for (p in level) b.putInt(p)
        md.update(b.array())
    }
    println("mips=${mips.size} sha256=" + md.digest().joinToString("") { "%02x".format(it) })
}
