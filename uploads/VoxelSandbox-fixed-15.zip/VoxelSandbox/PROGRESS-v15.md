# VoxelSandbox v15 work log

Everything below is checked by compile (kotlinc 1.9.22 against the android-34 stubs), by plain-JVM checks and by a software
WebGL2 renderer running the game's real shaders on its real meshes. **Nothing here has been run on a phone or an emulator**, and the
Gradle/AGP build has not been run in the sandbox that made this version (GitHub Actions is still the real build). CHANGELOG.md has the
numbers and the full wording; `docs/` has one note per subsystem.

## The brief, item by item

| # | item | status | where |
|---|---|---|---|
| 1 | terrain generation: faster, bit-identical, fewer allocations | **done, measured**: identical to v14 (9 seeds); garbage -58 %; CPU unchanged within noise; the neighbour-sample reuse was measured and removed | `docs/terrain-generation.md`, `tools/gen-check` |
| 2 | shimmering textures | done (checkpoint 1) | CHANGELOG checkpoint 1 |
| 3 | strict 16 x 16 pixel-art textures | done (checkpoint 1; a check of the creative suite pins every tile at exactly 16 x 16) | CHANGELOG checkpoint 1 |
| 4 | smooth, deterministic biome colours, voxel and distant the same | done (checkpoint 3) | `docs/biome-colors.md` |
| 5 | better water | done (checkpoint 4) | `docs/water.md` |
| 6 | LOD transitions: smooth, no popping, no gaps, same textures and colours, visible terrain first, long view kept | **done**: slide of shape and colour, exact ring cuts, stand-ins and a dither fade for missing tiles; render distance, LOD and fog untouched | `docs/far-terrain.md` |
| 7 | distant mountains must not look like rectangular buildings | **done**: small bricks that follow the ground (rings at doubled distances, quantised heights, 2-D merge), voxel look kept as asked | `docs/far-terrain.md` |
| 8 | Creative Mode only | done (checkpoint 2) | CHANGELOG checkpoint 2 |
| 9 | Android performance: few allocations, no stutter, no excess geometry | partly measured: garbage per chunk -58 %; far geometry +8-13 % triangles and +26-32 % tiles against v14 (GPU bytes -0 to -4 %), stated plainly; the GPU cost was **not** measured | `docs/far-terrain.md` (Measured) |
| 10 | honest testing | every claim is labelled source / JVM check / software renderer / not run on a device (below) | this file, CHANGELOG |
| 11 | final report | in the reply that delivers the ZIP | |

## What was verified, and how

| what | how | result |
|---|---|---|
| the whole app compiles | `compile.sh`: kotlinc 1.9.22, android-34 stubs, fresh build; resource references checked | 324 classes, no error |
| generation unchanged | `tools/gen-check/run_golden.sh`: 9 seeds x 396 chunks against the hashes of the original v14 generator, plus a shuffled three-thread pass | 9 / 9 identical; with a constant changed on purpose it fails (8 of 9) |
| Creative Mode logic | `tools/jvm-tests/run.sh` | 32 / 32 |
| biome colours | `run_biome.sh` | 17 / 17 |
| water | `run_water.sh` | 29 / 29 (28 + the new land / water shader contract; the suite *failed* once after the stand-in shader change, because its allow-list did not know the two new uniforms: fixed in the test, intent unchanged) |
| distant terrain | `run_far.sh` | 40 / 40 |
| pictures of the levels, holes, stand-ins, fades | `tools/render-rig` (SwiftShader WebGL2, real shaders, real tiles) | stand-in difference to the full picture 0.69 mean levels against 4.61 for a bare hole |
| geometry against v14 | `DumpFarLod` on both trees, four sites, radius 3300 | +8-13 % triangles, +26-32 % tiles, GPU bytes -0.2 to -4 % |
| garbage per chunk | `tools/gen-check/run_bench.sh` (exact allocated bytes per thread) | 60 391 to 25 253 bytes |

## Not verified (needs a phone)

- Everything visual and everything about speed on the device: frame time with the new shaders and about a quarter more tiles, the look of a fade while
  flying fast, Mali behaviour of `discard` plus the dither branch, whether 450 ms feels right.
- The Gradle / AGP build (GitHub Actions).
- That `ThreadLocal` scratch behaves the same under Android's runtime as on the JVM (the logic is the same one the cave carver has used since v14).
- Whether the large-array allocation the scratch removed was a real cost on the device (it is on the runtime's documented slow path; not measured there).

## Open, small, known

- Chunk meshed before its diagonal neighbour: one water-surface corner depth is computed as if that chunk were dry (checkpoint 4 note).
- Level 0 / level 1 handover of the finest ring is a switch per tile, not a fade.
- A hole behind the player (tiles already unloaded) may have no stand-in; the old fog behaviour applies there.
- `FarTerrainRenderer` iterates the tile map once per level per frame (about 8 iterators a frame): negligible, left as it was.
