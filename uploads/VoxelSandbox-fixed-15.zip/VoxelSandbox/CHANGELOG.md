# VoxelSandbox changelog

## v15 (final: distant terrain that keeps its look and has no holes, steadier generation, checks you can re-run)

The v15 work is complete with this drop; the four checkpoints below are still part of it (texture shimmer and the redrawn 16 x 16 tiles: checkpoint 1;
Creative Mode as the only mode: 2; biome colours that blend, near and far: 3; water: 4). This entry covers the rest of the brief: the distant terrain's
level transitions and mountains, the terrain-generation work, and the checks.
**What was checked**: the whole project compiles with kotlinc 1.9.22 against the android-34 stubs (324 classes, fresh build) and the resource references
lint clean; generation is bit-identical to v14 (golden check, 9 seeds x 396 chunks, also with three threads in shuffled order); the plain-JVM suites all
pass (creative 32, biome colours 17, water 29, distant terrain 40); the real shaders run in a software WebGL2 renderer on the real tiles (pictures and numbers
in `docs/far-terrain.md`). **Not checked: nothing here has run on a phone or an emulator, the GPU cost of the new per-pixel tests and of the extra tiles was not
measured, and the Gradle/AGP build was not run here.** Details: `docs/far-terrain.md`, `docs/terrain-generation.md`.

### Distant terrain: voxel look kept, levels slide into each other, missing tiles are filled

- **The look you asked for** (Distant-Horizons style): the distant ground is made of blocky columns with the real block colours, trees and water, whose
  bricks grow with distance. Every ring now ends at twice the distance of the one before and its columns are twice as wide, so a column is about the same
  size on screen at every distance (v14: rings ended at 512 / 896 / 1408 / 2304 / 6400, so from 2300 blocks on a mountain was a few 64-256-block boxes).
- **Mountains are cut into small bricks that follow the ground**: heights rounded to a per-level quantum (about a pixel at the level's inner edge, exact
  within 4 blocks of the sea so the shore never moves), neighbouring columns of equal height and colour merged in two dimensions, walls merged along their
  edge, canopy for forested ground from level 2 on, real trees on levels 0 and 1. Peaks and ridges come from the generator's own heights, not averages.
- **Levels hand over by sliding shape *and colour***: a vertex carries the height and colour of the column of the next coarser level over it (six floats; v14
  slid heights only, in seven) and the vertex shader blends to it by distance, so at the end of its ring a fine column is the coarse column. The ring edges are
  cut by the same exact distance in every shader: no seam, no overlap.
- **A missing tile no longer leaves a hole or pulls the fog in.** The finest coarser tile that contains the missing tile's footprint is drawn in its place
  (clipped to the footprint and the ring), and when the real tile arrives it fades in over 450 ms by a complementary screen-space dither (no blending, no
  gap at any moment, no cost when nothing fades). The planner counts such a hole as covered. HUD: `fill: N` while stand-ins are in use. A hole with no
  coarser tile resident (start-up, or behind the player after unloading) still falls back to the old fog behaviour.
- **Measured** (software renderer, a mountain face with two tiles missing, difference to the full picture): missing tile 4.61 mean levels / 3.3 % of the pixels
  off by more than 24; with the stand-in 0.69 / 0.9 %; 50 % faded in 0.35 / 0.4 %. Geometry against v14, same view, every tile of the rings before culling:
  **8-13 % more triangles and 26-32 % more tiles** (more draw calls), GPU bytes -0.2 to -4 %, building them all +4 % (1.70 s to 1.78 s on one thread).
- **Tests**: 40 checks in `tools/jvm-tests/run_far.sh` (ladder tables, rounding, vertex format, borders, tops and walls, slide targets, merges, deterministic
  tiles, stand-in maths and a brute-force check of the ring enumeration); the water suite now also pins that the distant land and water shaders share
  one clip/dither snippet (and its allow-list of shader inputs knows `uClip` / `uDither`, found by that suite failing after the shader change).
- **Also**: `FarTileMath` is the one place for tile distance maths (planner, stand-ins, renderer); `ClipDither` owns the two new uniforms of both programs and
  never re-sends an unchanged value; `FarTerrain.DEFAULT_TILE_BYTES` (the budget's first guess of a tile's weight) was re-measured.

### Terrain generation: the same worlds, a lot less garbage

- **Bit-identical to v14** for every seed tested (9 seeds x 396 chunks around the origin, the spawn, negative and distant coordinates and two places of every
  biome), and the check is part of the project (`tools/gen-check`), with a proof that it can fail.
- **58 % less garbage per chunk** (60 391 to 25 253 bytes in the game's order; young collections of a small heap 247 to 104): the working arrays of a chunk
  (about 35 KB, two of them above the size at which Android's runtime allocates apart from the normal heap) now live once per generating thread.
  **CPU time per chunk did not change beyond the noise of the machine** (about 1.2-1.3 ms before and after); no speed-up is claimed.
- **Measured and rejected**: reusing the border samples of the neighbouring chunks is bit-identical and saves 26 % of the samples in scan order, but in the
  game's order (nearest chunk first) it reuses 1.4-2.9 %; removed. Profile and what was left alone, with reasons: `docs/terrain-generation.md`.

### Tools added to the project

- `tools/gen-check`: `run_golden.sh` (bit-identity against the hashes of the original v14 generator, three-thread consistency pass) and `run_bench.sh`
  (time and bytes per chunk, scan and game order, GC counting); `PROJECT_ROOT=` points both at another tree to compare.
- `tools/render-rig`: the level-by-level distant-terrain dump and renderer (`DumpFarLod`, `lod.js`, `runlod.py`, `pair.py`, the v15 jobs).

### Known limits of this drop

- Everything above is verified by compiling, by plain-JVM checks and by a software renderer; none of it on a phone. First things to look at on the device: the HUD far
  line (tiles, triangles, `fill`), frame times with the finest ring on and off, the look of a fade while flying fast towards an unloaded area.
- A stand-in is the bigger bricks of the same ground; next to its real neighbours the difference can be seen. The fade is a fine dither for 450 ms, not an alpha blend.
- The finest ring's own handover (level 0 against 1) is a switch per tile, not a fade. A chunk meshed before its diagonal neighbour still has the one-corner water
  depth issue of checkpoint 4.

## v15 (checkpoint 4 of the v15 work: water)

Fourth intermediate drop (checkpoints 1-3 are below and still included). Still to come: LOD transitions, far mountains,
terrain-generation speed-up. **What was checked**: the whole project compiles with kotlinc 1.9.22 against the android-34 stubs
(302 classes, fresh build) and the resource references lint clean; generation is bit-identical to v14 (golden check, 9 seeds x 396
chunks); 28 new automated water checks (`tools/jvm-tests/run_water.sh`: the pixel art, the time and place maths, what the water
shaders may read, and the real chunk mesher joining water across chunk borders), the 17 biome checks and the 32 creative-mode checks
all pass; the shaders run in a software WebGL2 renderer on the game's real meshes (camera moves, time series, near/far hand-over,
shorelines). **Not checked: nothing here has run on a phone or an emulator, the GPU cost of the second texture fetch was not measured,
and the Gradle/AGP build was not run here.** Details and numbers: `docs/water.md`.

### Water

- **Cause**: v14's water was one 16 x 16 tile of three blues within 9-15 levels of each other, repeated every block and *scrolled*: still
  water crawled continuously (0.037 / 0.021 tiles a second), running water slid at 0.9. (The pattern was already tied to the world, not
  the camera: moving the camera by whole blocks changed no water pixel in v14 either; what slid was the pattern with time.)
- **New pixel-art water** (`gl/WaterPattern.kt`): 40 frames of a 128 x 128 tile (16 pixels to the block like every block texture, one repeat per 8
  blocks, seamless in space and in time), four close blues (6 / 62 / 28 / 4 % of the pixels, exact shares, mean colour 73, 126, 211 = the old
  tile's), ripples longer along X than across, no lone pixel in any frame, about 7.8 % of the pixels changing between frames. Generated
  (pure function of constants, bit-identical on every device, a checksum test pins it), in a background thread at start-up
  (`WaterPattern.prewarm()`), 3.5 MB of GPU memory as a texture array.
- **Animation without sliding** (`gl/WaterAnimation.kt`, `Shaders.WATER_FRAGMENT`): still water changes *frame* (6 a second, 6.67 s loop; one integer
  per frame picks the array layer) and does not move; running water carries the pattern along its flow (0.8 blocks a second), a waterfall pulls
  it down its face. The tile is read at camera-relative position + origin modulo the tile, which is the world position modulo the tile, exact, so
  nothing slides when the camera moves and nothing jumps when the origin steps (tested on 20 000 random origins to +-200 000 blocks). All
  rates complete whole cycles in the texture clock's wrap.
- **Natural variation, calm distance**: a soft drifting patch field (64 x 64 bytes, 4 blocks to the texel, +-3 % brightness and a little hue); the
  pattern fades to the animation's mean colour between 90 and 240 blocks (v14: 150-260) on top of the mip chain; foam on the crests in the first
  block of depth off a shore.
- **No biome input, no tint of the shore**: a test lists every uniform and vertex attribute of the water shaders (none is a biome, a colour map or a
  colour); water is one colour everywhere and only its own opacity lets sand or land show through. v14's depth tint, sky mix, path-length opacity
  and near/far seam are kept; the distant water uses the same shader and pinned pattern (voxel vs distant water at the same place differ by 0.2-0.7
  levels on average in the software renderer, 0.00 beyond the hand-over).
- **Chunk borders** are now tested with the real mesher (the water geometry is unchanged from v14): shared surface corners agree in height and
  depth, lakes have no wall, hole or doubled layer across a border, a stream of flowing water has no wall across it, merged deep-ocean rectangles
  leave no crack and overlap by the sliver on both sides; a negative control proves the checks can fail.
- **Cost**: two texture fetches per pixel (v14: one), no per-pixel trigonometry, no new overdraw. Texture units: wave array 1, tone 5, upload on 6
  (and unit 0 is restored, so the block atlas is never replaced by an upload).
- **More lively than v14, on purpose**: v14's water barely changed from frame to frame (mean 0.04-0.17 levels per 1/6 s); the new water changes
  0.2-0.8 levels on average and an edge pixel up to about 18 levels at close range (3 beyond 13 blocks). `WaterAnimation.FPS` and `WaterPattern.SHARES` / `PALETTE` are
  the knobs if it is too lively on the phone (the checksum test then has to be updated on purpose).
- **Known limit** (also in v14): a chunk meshed before its *diagonal* neighbour exists keeps one surface corner with a water depth computed as if
  that chunk were dry land (measured: depth 3 instead of 4 in a 4-block lake, about 4.5 % of red brightness over one block). Not fixed here.
- **Also**: `run_biome.sh` compiles the water files the shaders now depend on; the stale comment on `FrameState.TEXTURE_TIME_PERIOD` is rewritten;
  `tools/render-rig` has the water scenes and checks (`DumpWater`, `DumpFarWater`, `anchor_check.py`, `flicker_water.py`).

## v15 (checkpoint 3 of the v15 work: biome colours blend, near and far)

Third intermediate drop (checkpoints 1 and 2 are below and still included). Still to come: water, LOD transitions,
far mountains, terrain-generation speed-up. **What was checked**: the whole project compiles with kotlinc 1.9.22 against
the android-34 stubs (295 classes, fresh build) and the resource references lint clean; generation is bit-identical to v14
(golden check, 9 seeds x 396 chunks); 17 new automated checks of the colour field and what carries it
(`tools/jvm-tests/run_biome.sh`) and the 32 creative-mode checks all pass; the shaders run in a software WebGL2 renderer on the real
meshes (before/after of the borders, voxel terrain next to distant terrain of the same place, a mountain with grass, rock and snow).
**Not checked: nothing here has run on a phone or an emulator, the GPU cost of the extra texture fetch was not measured,
and the Gradle/AGP build was not run here.** Details: `docs/biome-colors.md`.

### Biome colours

- **Cause**: grass, dry grass and swamp grass are different blocks, each drawn in one fixed colour, and the distant terrain
  picked one of three palette rows, so every border of the biome table was a hard line of lime / straw / olive, and colour never
  followed altitude.
- **A smooth colour field** (`world/color/BiomeColorField.kt`): a blend of four climate colours (temperate, cold, dry, swamp; each is
  the measured average colour of the matching texture, so the middle of a climate looks as it always did) with weights that are soft versions of the
  table's own rules (`Climate.coldness / dryness / swampiness`). The 0.5 contours lie on the table's hard borders (0 contradictions over 180 000
  random columns), the gradient is 10-40 blocks wide, grass turns cooler and bluer with altitude. A pure function of position:
  deterministic, the same across chunk borders, reloads and between near and far. `Climate.biome()` answers exactly what it did (golden check).
- **Voxel terrain** (`gl/BiomeColorMap.kt`, `TintTable.kt`, `VoxelShader.applyTint`): the field lives in a 256 x 256 colour map (a torus around the
  eye, one texel per 4 x 4 blocks, filled by a worker thread nearest first, at most six 16 x 16 tiles uploaded per frame) and the block shader tints
  grass tops, the grass fringe of grass sides (a mask in the alpha channel of the tile, so the dirt below stays brown), tall grass and (at 70 %) leaves.
  **Sand, stone, snow, gravel, dirt, water, wood and ore are never tinted** (a test lists exactly what is). Nothing is stored in vertices, so
  merging, rebuilding and chunk borders cannot change a colour, and nothing pops when a chunk loads.
- **Distant terrain** (`world/far/FarGroundColor.kt`, `FarTerrain`, `Shaders.FAR_*`): grass cells take the field's colour times the brightness step
  they already had, each corner of a cell the average of the grass cells around it (never of sand, snow or rock), drawn as a colour per corner
  (a negative `u` in the vertex carries `-(rgb + 1)`; the vertex shader decodes it). Constant stretches of the field still merge. Tree canopies take
  the leaves' share of the shift. Tile borders agree on every level (tested on 8 000 corners).
- **Measured** (this machine, desktop JVM): the field costs 0.8 us per texel, 0.20 ms per tile; the far land mesh is 2.4 / 4.9 / 3.0 % bigger on three
  test areas (levels 0-4, radius 600) and a far tile takes about 10 % longer to build (level 1: 8.0 -> 8.8 ms).
- **Also**: the atlas bytes changed (the mask in the three grass-side tiles; colours identical, checked), `TextureAtlas` exposes the far
  palette as plain colours (`rampSurfaceRgb`), the grass brightness steps are named constants shared with the far colours, `Climate` exposes the
  numbers of the biome table that the field is built on (`dryness`, `coldness`, `swampiness`, `groundTemperature`).
- **Limits**: see the end of `docs/biome-colors.md` (forests are darker from far away than up close, as before; a pond bed is dirt up close and
  sand-coloured in the distant mesh, under the water).

## v15 (checkpoint 2 of the v15 work: Creative Mode is the only mode)

Second intermediate drop; checkpoint 1 (texture sampling, redrawn tiles) is below and still included. Still to
come: biome colour blending, water, LOD transitions, far mountains, terrain-generation speed-up.
**What was checked**: the whole project compiles with kotlinc 1.9.22 against the android-34 stubs (275 classes, fresh build from the unzipped ZIP) and
the resource references lint clean; the pure logic (catalogue, search, icons, hotbar, save format, flight maths and
collision, placement rules) has 32 automated checks that run on a JVM (`tools/jvm-tests/`, all pass); the icons
were drawn into a contact sheet and looked at (`docs/creative-icons.png`). **Not checked: the inventory screen, the
HUD and the flight feel were never run on a phone or an emulator, and the Gradle/AGP build was not run here.** What
that leaves open is listed at the end of this entry.

### Creative Mode as the only mode

- **No survival leftovers.** The old `Inventory` (stack counts, a starting stock, "breaking collects, placing
  consumes"), `BlockType.drop`, `BlockType.placeable`, the "Creative mode" switch in Settings, the star button
  that switched the mode on and off, and `GameSettings.creativeMode` are gone. Placing never uses anything up and
  nothing has to be collected. There is no mode selector.
- **Catalogue generated from the registry** (`creative/CreativeCatalog.kt`): every `BlockType` except air, once,
  25 entries today, ordered by tab then registry order. There is no hand-kept item list: a block added to the
  registry appears in the "All" tab by itself (and a test fails until it is sorted into a tab,
  `creative/BlockCategory.kt`). The game has no items apart from blocks, so the catalogue is exactly the blocks.
  Tabs are made from the entries that exist (Terrain 8, Stone & Ore 3, Trees 6, Plants 7, Liquids 1); a tab with
  nothing in it would not be shown. `CreativeCatalog.problems()` lists anything unusable (missing texture,
  duplicate, unsorted); it is empty today, so **no registered block is unsupported**.
- **Names**: Wood and Leaves are now "Oak Wood" and "Oak Leaves" (they were ambiguous next to Birch and Spruce).
- **Search** by name, part of a name, tab word or a few synonyms (log, flower, liquid, ...), all words must match;
  a name match ranks above a synonym ("water" lists Water before the water plants).
- **Icons** (`creative/BlockIcons.kt`): drawn from the blocks' own 16x16 textures through the new shared tile table
  `gl/TileSources.kt` (the atlas builder now reads the same table, and a SHA-256 over every mip level of the atlas
  is byte-identical before and after that change). Solid blocks are small isometric cubes with every texel
  mapped 1:1 (top, lit left, darker right face, leaves keep their holes), water is a translucent cube with a few
  wave pixels, plants are their sprite enlarged exactly 2x, seagrass sits on a faint blue backdrop (its dark blades
  vanish on the panel otherwise). Enlarged by a whole number for the screen with no smoothing, so every pixel stays
  square. A block with no texture would get no icon and show up in `problems()`; none does.
- **Inventory screen** (`ui/CreativeInventoryController.kt`, `overlay_hud.xml`): category rail, search box, and a
  recycling grid of 84dp cells (icon + name), open/close with the inventory button, the X, a tap outside, or Back.
  A tap makes the block the selected hotbar slot's block at once (a block that is already in the hotbar just
  selects its slot); tapping a hotbar slot first chooses which slot the next pick replaces. The hotbar stays
  visible and tappable under the panel. The search and the tab are reset when it closes.
- **No stray input around the screen**: opening it lets go of everything held, resets the joystick's and look
  pad's touch tracking, covers the controls with a full-screen scrim (so nothing under it can be touched), and
  the engine ignores the controls and the camera drag while `InputState.uiBlocked` is set. Back closes the
  inventory before it pauses; pausing or leaving the app closes it. The soft keyboard (search) is set to
  `adjustNothing`, so it never resizes the GL surface.
- **Hotbar** (`inventory/Hotbar.kt`): eight slots (the same default blocks in the same order as before), icons
  instead of names and counts, a name label that fades. Thread-safe (written by the UI thread, read by the game
  thread). A saved hotbar with an unknown block id, air, too few or too many slots or a bad selection is repaired
  slot by slot instead of rejected.
- **Placement rules** (`engine/PlacementRules.kt`) so everything in the inventory does what it should: flowers,
  grass tufts and dead bushes need a solid block below and open air; a lily pad floats on water (aimed at the
  water or its bed it rises to the surface); seagrass needs a water cell on a solid bed; cubes and water go into
  air, water and plants; a solid block cannot be put where the player stands (plants and water can).

### Flight (`player/FlightMath.kt`, `GameEngine.flyMove`, `PhysicsController.flyMove`)

- Joystick forward moves **horizontally in the direction the camera faces**, sideways is perpendicular, the stick
  is limited to length 1; looking up or down no longer climbs or sinks (height changes only with the jump and
  fly-down buttons, at a fixed speed of 60% of the fly speed, 8..60 blocks/s). The camera turns freely while
  flying (the look pad is separate from flight).
- Velocity eases to the target (0.10 s speeding up, 0.06 s stopping) with the exact integral over each frame, so
  the distance flown is **independent of the frame rate** (tested at 20, 30, 60 and 144 fps against a 1200 fps run:
  58.80 blocks flown in a 3 s flight, worst difference 0.0017 blocks). A long step at 200 blocks/s and 20
  fps cannot tunnel through a one-block wall (tested). Velocity that the terrain stops is dropped.
- The star button became the **fly button** in the same place (it keeps its stored HUD-layout key, so a layout
  you customised still applies); double-tapping jump still toggles flight. Fly-down appears while flying, and
  holding it until you rest on the ground lands you and ends the flight. The destroy laser button is now always
  there. The settings screen keeps the fly-speed slider.
- Flight state is saved with the world.

### Save format 5 (`save/SaveCodec.kt`, `SaveManager.kt`)

- The file layout moved into `SaveCodec` (no Android classes) so it can be tested; `SaveManager` only does the
  file handling. Version 5 stores the hotbar's block ids, the selected slot and the flight state in place of the
  stack counts. **Version 4 saves still load** (their world, position and view are kept, the counts are dropped,
  the hotbar starts at its default). Version 5 files are not readable by older builds. Truncated or damaged files
  and impossible numbers (NaN position, absurd slot or chunk counts) give "no usable save", never a crash
  (tested with truncation at ten points and seven kinds of damage).

### Known limits of this drop

- Nothing here has run on a device. In particular unverified: the real look and spacing of the inventory screen
  on the 720x1612 panel, touch feel of the grid/search, the soft keyboard over the immersive full screen, the feel
  of the flight smoothing, and the haptic tick. The tab labels and the 84dp cells were sized by arithmetic for
  roughly 360 to 410 dp of height.
- A lily pad aimed through deep water rises to the surface above, which can be many blocks from the aimed spot.
- `GameSettings` still stores the old `creative_mode` preference key unused (harmless, never read).

## v15 (checkpoint 1 of the v15 work: texture sampling and the first redrawn tiles)

This is an intermediate drop. It contains only what is finished and checked; the rest of the v15 brief (biome
colour blending, water, LOD transitions, far mountains, Creative Mode, terrain-generation speed-up) follows in
later drops. **What was checked**: the whole project compiles with kotlinc 1.9.22 against the android-34 stubs and
the resource references lint clean; the shaders were compiled and run in a software WebGL2 renderer (headless
Chromium / SwiftShader) on the game's real meshes and atlas. **Nothing was run on a phone and the Gradle/AGP
build was not run here.**

### Texture shimmer / crawl (VoxelShader.kt, TextureVariants.kt)

- **Cause found with a measurement, not a guess.** Ground seen at a low angle is stretched: a pixel covers about
  one texel along the view direction and a fraction of a texel across it. One trilinear sample per pixel then
  either blurs the sharp direction (it picks the mip level of the long axis) or aliases the long one, which
  is the crawl of speckled sand and dirt while walking. The software renderer walked a camera over flat sand,
  grass, dirt and stone and compared every frame with a 4x4 supersampled picture of the same view.
- **Fix: an anisotropic lookup in the block shader** (`tileLookup`). Up to `VoxelShader.TERRAIN_TAPS` = 4 taps
  are spread along the long axis of the pixel's footprint (fewer where the footprint is round, so walls and
  everything within a few blocks still take one), each with the footprint of its share, so the long direction
  is averaged and the short one stays sharp. Taps that leave the tile wrap around inside it for tiles that
  repeat seamlessly (new `TextureVariants.TILEABLE` bit, carried in the face description, so the shader needs no
  table) and stop at the edge for the others (grass sides, ore); they never read a neighbouring tile of the
  atlas. Far away the footprint is widened by up to 40% (about half a mip level) where texels are many per pixel.
  The sharp-bilinear remap that keeps close-up pixels square is unchanged except that it fades out a little
  later (0.7..1.6 texels per pixel instead of 0.5..1.0). Free quads (plants, particles) keep the old lookup.
- **Measured (software renderer, 1280x576, camera walking 0.03 blocks per frame, flicker = mean frame-to-frame
  change of the error against the supersampled reference, in luminance levels of 255)**: 4-8 blocks away:
  sand 1.80 -> 1.06, grass 3.01 -> 1.77, dirt 2.75 -> 1.60, stone 2.12 -> 1.28 (-40..-41%); 2-4 blocks: -34..-37%;
  8-16 blocks: -14..-18%; the error against the reference in the 4-8 band fell 49..51% and the sharpness
  (gradient energy relative to the reference) went from 0.70 to 0.93. 16-32 blocks away the flicker is 7-13%
  higher in the old art (0.41 -> 0.44 for sand) because the old lookup was simply blurrier there (sharpness 0.6-0.8
  of the reference against 1.0-1.2 now); the absolute level is below one luminance level.
- **Not measured**: the cost of up to four taps on the phone's GPU. `VoxelShader.TERRAIN_TAPS` is the single knob
  (1 = the old cost).

### Redrawn 16x16 tiles (BlockTextures.kt)

Dirt, grass top, grass side, sand and stone were redrawn (still exactly 16x16, same palettes, average colours
within 1-4% of the old tiles so the distant-terrain ramp, which is derived from them, keeps its look): small
clusters of two to four pixels instead of isolated speckle, a few single accent pixels placed at least three pixels
apart, no isolated pixel two tones away from all its neighbours, a ragged green cap with a darker lip over a dirt
part that uses the dirt tile's own palette and grain. The tiles wrap seamlessly (checked by tiling them 3x3 and
by the renderer). Textures that were not touched keep their old art.

## v14 - no more vanishing chunks, no ring around the player, steadier and less repetitive textures, greedy meshing, a leaner stream

**How this was checked, and what was not.** Every Kotlin source compiles with kotlinc 1.9.22 against the
android-34 API stubs. Behaviour was measured in JVM simulations (scripted flights over the real generator,
mesher, scheduler and far-terrain builder, with the GPU replaced by a cost model, on a 2-core Linux machine),
in unit-style tests of the pieces that are pure logic, and in a software WebGL2 renderer (headless Chromium /
SwiftShader) that runs the game's real shaders on the real meshes for the pictures of the LOD ring and the
distant terrain. **None of this is a measurement on a phone**: the Gradle/AGP build was not run here (GitHub
Actions is still the real build), and nothing below says how fast it runs on a Mali-G52 or what it looks like
on a 720p panel. Numbers are labelled "simulation" or "software renderer" where they come from there. What
could not be verified at all is listed at the end of this entry.

### 1. Chunks that disappeared, flashed and came back

The device log of the checkpoint showed five separate mechanisms, none of them a rendering bug of the chunks
themselves:

- **The memory policy halved the loaded area on a callback.** Android's `RUNNING_CRITICAL` trim callback
  arrived three times in six minutes while the app's heap sat at 150-209 MB of 512 MB and the system had
  600-960 MB free; each one cut the chunk budget by half for a minute and then grew it back 10% at a time, so
  the whole ring receded and re-grew. `MemoryPolicy` now works from evidence (heap fill, the system's own
  low-memory flag, an `OutOfMemoryError`), moves the budget by bounded steps per second in both directions,
  and treats the callbacks as "drop caches", costing budget only when a reading confirms real pressure (or
  once the app is in the background).
- **The far terrain's memory ceiling pulled the horizon in.** Hitting the byte ceiling refused the *nearest*
  unbuilt tile and collapsed the covered radius to about 500 blocks, and the fog and far plane followed
  within a frame, so the whole landscape behind vanished and re-grew (tiles drawn 84 -> 17). `FarBudget` now
  cuts the plan from its far end (prefetch first, then the finest ring, then the horizon), with a
  hysteresis band so a tile at the edge of the budget does not toggle, and evicts only what the plan does not
  keep, farthest first. Tiles are also prefetched where the player is heading (two seconds ahead) and
  unloaded only well outside their ring. Simulation, 40-second walks at radius 3000 (the checkpoint code ->
  now): at 25 blocks/s the covered radius fell as low as 11% -> never below 100%; at 5 blocks/s 48% -> 100%;
  at 80 blocks/s 17% -> 30% (the budget binds there); radius 6400 at 25 blocks/s 5% -> 100%.
- **One missing chunk shrank everything.** The voxel/far hand-over radius was "the distance to the first chunk
  without a mesh", so a single late chunk anywhere pulled the whole ring in (14 -> 6 chunks in the log). The
  radius is now a rate-limited follower of the nominal edge, centred on the eye (it used to jump 16 blocks
  each time a chunk boundary was crossed), the fog holds still through a dip that does not last and closes
  in smoothly when one does, and what is drawn where is decided per column by a coverage mask on the GPU:
  a column that has no voxel terrain yet shows the distant terrain there, a column that has it does not.
  (`gl/Handover.kt`, `gl/CoverageMask.kt`.)
- **Packed regions could overtake each other.** Two packs of one region going through two workers could reach
  the GL thread in either order, and an older one arriving last put an unloaded column back or removed a
  loaded one until the next pack. Every pack carries a sequence number now and `RegionVersions` drops an
  overtaken one. A region is replaced as a whole, in one step on the GL thread (one `glBufferData` per buffer,
  and the coverage mask changes in the same step), and until its replacement has been built on a worker thread
  the region keeps drawing as it is, so a column never disappears while its replacement is being made.
- **Chunks that did not need to be redone were redone.** The stream ran 1.3 mesh jobs per generated chunk
  walking and 2.0 to 2.4 flying: a chunk at the edge of the loaded area was meshed against a missing
  neighbour (treated as solid) and then again as that neighbour arrived. Each redo also re-packed and
  re-uploaded the whole 4x4-column region. See "A generation halo" below.

Unloading follows the wanted set with a hysteresis (chunks stay loaded until they are 3 chunks beyond the
edge of the ring, which is 2 beyond the halo of section 7), so chunks do not thrash in and out at the boundary.

### 2. The ring around the player (voxel -> distant terrain)

Four causes of a visible circle were found and removed. The software renderer was used to check each one on
three scenes (hills, mountains, plains), from eye height and from above:

- **The distant terrain was darker than the voxel terrain it overlaps.** Its shade constants were 0.97 / 0.80
  / 0.68 against the voxel faces' 1.0 / 0.82 / 0.70 (a faint ring of 2-3%), and its soft tone patches began
  40 blocks from the eye, so they were already at nine tenths of their strength where the voxel terrain ends
  (up to 12% lighter or darker than the ground next to it). The shade table is now one object
  (`world/mesh/FaceShade.kt`) used by both, the per-block grain constants are shared too (`gl/BlockGrain.kt`),
  and the tone patches are zero at the edge of the voxel terrain and reach full strength 220 blocks beyond it.
  Like for like in the software renderer (hill scene, distant terrain against the voxel terrain it overlaps,
  before this version -> now, in luminance steps of 255): 7.2 -> 4.0 darker at 200-240 blocks from the eye,
  5.7 -> 2.5 at 240-280, 3.2 -> 1.0 at 280-320. That is smaller, not gone: 1 to 4 steps (under 2%) remain
  and their cause was not chased.
- **The steps of the distant terrain were grass-coloured; the voxel steps are brown.** A cliff of voxel
  terrain shows its dirt (and, below four blocks, stone), never its grass. Distant walls over soil are now
  dirt for the top four blocks and stone below, like the generator builds it (`SurfaceKind.soilSides`).
- **A quarter-block height bias.** Distant columns sat 0.75 blocks above the top block's floor, a quarter of
  a block under the voxel top face, which made a visible seam where they meet and made the shoreline fall
  in a different place. They now sit exactly at the voxel top face (the two passes have their own depth
  ranges and the depth buffer is cleared between them, so they never compete); a column is exactly as high
  as the block it stands for, and ground at sea level is land in both.
- **The finest ring jumped.** The ring of 2-block columns just behind the dissolve is placed from the nominal
  edge and handed over per tile, only once every tile it needs is on the GPU, so there is no frame with a hole
  or two surfaces.

In top-down pictures from the software renderer the circle at the dissolve radius is no longer visible; what is
left is the 1 to 4 luminance steps quoted above. (The harness does not render water, so the coastline at the
ring is **not** checked.)

### 3. Distant terrain shape

The column heights were measured against the real generator at every level (a height-error tool; simulation):
they are unbiased (mean error about 0) and mountain peaks are kept. What remains is the stair-stepping of a
slope into flat-topped columns, an error of about 3 to 6 blocks rms on mountains at 8 to 16-block columns.
That is the price of the column representation, which was kept on purpose: its quad count is what the GPU
can afford, and its look matches the voxel terrain it hands over to. Two ways of lowering the error were
tried and **not adopted** because they did not help: a cell-mean estimator (5-10% at best) and band-limiting
the ridge and hill octaves per level (it made the error worse). What changed: the walls and shading (above),
the exact height match with the voxel terrain, trees that sink into the ground at the end of their ring, and
the `FarBudget` / prefetch work (no tile missing where the player is going).

### 4. Textures that moved, shimmered and swam

- **Camera-relative rendering.** The voxel vertex shader works on positions relative to the whole-block
  position of the eye (`uCamOrigin`); the fragment shader derives the block, the position in the block and the
  tile coordinate from those small numbers (highp), so nothing depends on the last bit of a world coordinate
  that is thousands of blocks from the origin.
- **Mip level and sampling.** The atlas is read with `textureGrad` and the derivatives of the *unwrapped* tile
  coordinate (the hardware's own derivative jumps where the coordinate wraps at every block boundary), biased
  a quarter of a level coarser than the hardware rule. Up close it is a "sharp bilinear" lookup: the texel
  coordinate is pushed to the centre of its texel except within half a pixel of an edge, so pixels stay square
  and crisp and an edge no longer jumps a whole pixel as the camera moves; from one texel per pixel up it
  fades into the plain trilinear sampler, which is a smooth function of position, so nothing flickers.
  Atlas gutters hold the tile's own pattern (for tiles that repeat) so the blend across an edge reads the
  same block.
- **The dissolve at the rim is noise fixed to the world** (one value per block cell) instead of the screen,
  and per-block grain on the far cliffs is offset away from cell boundaries (it used to flicker at large
  coordinates).

### 5. Repetitive textures

Every block face is drawn with its tile mirrored or turned in one of up to eight ways, chosen by a hash of the
block's world position and the face, in the shader (`gl/VoxelShader.kt`, `world/mesh/TextureVariants.kt`).
The choice is a pure function of position, so it is the same after a chunk is unloaded and loaded again, however
the mesher merged the faces, and at every distance; it stops where a tile is a few pixels (past 170 blocks).
What a texture allows depends on what it shows: ground, rock, sand, snow, leaves, ore and the ring pattern of a
log's end can be turned and mirrored freely; bark can only be mirrored (the streaks stay upright); the sides of
grass, snow, sandstone, cactus and swamp grass can only be mirrored left to right (the fringe stays the right way
up); plants, water and plain colours are never varied. The small per-block brightness variation that used to be
baked into the vertices comes from the same hash in the shader, for every block inside a merged rectangle.
(`TextureVariants.enabled = false` switches it off: the picture is then the plain tiling.)

### 6. Greedy meshing

The mesher before this version culled hidden faces but emitted one quad per visible block face (only flat deep
water was merged). It now merges faces that look the same into rectangles, per direction and layer of a
sub-chunk, standard greedy sweep (`ChunkMesher.emitGreedy`). Two faces merge only when their keys are equal:
same atlas cell, same draw group (opaque / cut-out), same cave darkening and the same occlusion level at all
four corners; a face whose corners differ in occlusion (a gradient a bigger quad would stretch) is never
merged, so ambient occlusion is exactly as before. Because a merged quad has no per-block texture coordinates,
the shader tiles the texture once per block from the block's position (and applies the variants of section 5).
Water, transparency and block boundaries are untouched (rectangles never leave their sub-chunk, water keeps its
own path, plants and other free quads are not merged). Faces grow by 6e-5 of their distance from the camera along
their own plane so that quads of different sizes lie in one plane without pixel-wide cracks (T-junctions);
that is **unverified on a Mali GPU**. Measured on the real generator, radius 10 (441 chunks), JVM simulation,
warmed: **1416 -> 1116 triangles per chunk (-21%)**, 83.0 -> 65.4 KB of mesh kept per chunk (-21%), 84.2 -> 66.6 KB
allocated per mesh job (-21%), mesh time 0.85 -> 0.74 ms per chunk (-13%). `ChunkMesher.greedy = false` gives
the old one-quad-per-face geometry for measuring.

### 7. Performance

- **A generation halo** (`WorldManager`). One extra ring of chunks (every chunk that touches the loaded area
  from outside) is generated but never meshed or uploaded, so every chunk of the ring is meshed once, with
  all four neighbours really there, instead of against a missing neighbour and again when it arrives. A chunk
  waiting for a neighbour that is still queued pulls it to the front, and waits longer when it is far from the
  player (distant terrain shows there meanwhile). The extra cost is block data of about one ring (a few MB; the
  halo chunks are cheaper than meshed ones, measured at 76-81 KB per loaded chunk against the 104 KB the budget
  assumes). Simulation, nine scripted flights (cold start, walking, running, flying at 30/100/200 blocks/s,
  a turn, a 3000-block teleport, a circle), checkpoint -> now: whole-column mesh jobs per generated chunk
  1.00-1.29 walking and 1.82-2.38 flying -> 0.90-0.94 (the remaining 6-10% are the halo chunks that are never
  meshed, so it is one job per chunk of the ring); partial redo jobs 398-13,836 per run -> 0-18; worker CPU per
  run -5% to -18% in the flights (fly200: 17.5 -> 14.1 s, turn: 7.1 -> 5.8 s); bytes uploaded -5% to -18% in
  the turns and flights (circle: 1087 -> 901 MB); the covered radius in flight is the same or better (fly200 mean
  15.6 -> 16.9 chunks, p10 13.0 -> 15.2); **0 holes and 0 failures in all nine**. The price: a cold start
  or a teleport takes about 0.1 s longer to cover (1.2 -> 1.3 s, 0.9 -> 1.0 s) and uploads about 10% more
  bytes. A separate test (render distance 6 -> 3 -> 10 -> 400 -> 5, then a 400-block walk and back) checks
  after every change that the ring is covered, the halo is not meshed and what is beyond the hysteresis is
  unloaded: all pass, exactly one whole job per chunk of the ring.
- **Far-terrain tiles are uploaded under a byte and time budget** shared with the voxel regions, instead of
  "two per frame": a tile gets the frame time the regions left over, half of the frame's bytes (at least
  400 KB) and never less than a fifth of its time, and the first tile of a call always goes. When the regions
  used all of the frame's time the tiles wait, but never more than two frames in a row, so neither kind can
  starve the other. A 1.3 MB tile no longer lands in the same frame as a big region upload. Tile builders
  back-pressure at 12 queued events.
- **Region uploads share one admission rule** (`UploadBudget`): the first upload of a frame always goes, later
  ones only if they fit both the byte and the time budget. Budgets follow the frame time (3 / 1.8 / 1 / 0.6 MB
  per frame).
- **Statistics**: the stats line counts whole and partial mesh jobs and chunks generated, so a regression of
  the 1.0 shows up (`meshJobsPerChunk`).
- Not done: the far-terrain triangle count (about 1.0-1.2 million land triangles in the three test scenes before
  frustum culling, 60-70% of them walls) was looked at and left as it is; merging colours that look alike saved
  about 1%, and anything bigger (flattening or smoothing heights) would change what the terrain looks like.

### Automatic Render Distance (new switch, off by default)

- Graphics settings has an **Automatic Render Distance** switch. It is stored with the other settings and
  survives restarts. **OFF: the selected render distance is used in full, always**, whatever the frame
  rate (the governor does not exist as far as the renderer is concerned). **ON: the game may draw less than
  the selected distance, but only while that is measured to make frames faster**; the screen shows
  "Selected: N chunks. Effective now: M chunks (P%)".
- The old governor pulled the view in whenever frames were slow. On a fill-rate-bound phone that is a trap
  (your log: 0.4x for 127 seconds at about 30 FPS, a shorter view buys almost nothing there). The new one
  (`engine/DistanceGovernor.kt`) takes one small step down, measures, and **keeps it only if the frame time
  fell by at least 6%**, otherwise it undoes the step at once and waits (15 s, doubling up to 240 s) before
  trying again. When there is headroom it steps back up and keeps the step unless frames got more than 3%
  slower; the gap between 3% and 6% is deliberate, it is what stops flip-flopping. While reduced it
  re-checks every 45 s that the reduction still pays. Floor: 40% of the selected distance and never below
  560 blocks. Levers: fog distance, the radius of full-detail voxel terrain, and the finest far ring.
- Tested in a JVM harness (10 scenarios, all pass): a GPU-bound scene settles near the slow threshold and
  stays there; a bottleneck that ignores distance leaves the view reduced under 8% of the time (the old
  governor: stuck at the floor); a heavy scene followed by a light one is given back; OFF is exactly 1.0
  with no decisions; switching OFF snaps back at once; a calm 30 ms scene makes no decisions.

### Maximum render distance 1000 chunks

- The render-distance and detail-distance limits, the slider mapping, the saved-settings validation and
  the streaming radius all accept 1000 chunks (16,000 blocks); nothing clamps silently to the old 400 / 300.
  1000 chunks is the **configurable maximum, not a promise** that a phone can hold that many chunks of voxel
  terrain: voxel chunks stay inside the memory budget, and the rest of the distance is the distant-terrain
  ladder. Demand-driven: the nearest chunks and the ones in front of the camera come first.
- Extreme distances are bounded rather than clamped: the distant-terrain ladder has 8 levels now (columns
  2, 4, 8, ... 256 blocks wide, so on-screen column size and triangle count stay bounded as the radius
  doubles), resident far-terrain tiles have a byte ceiling (96 to 192 MB by device heap), radii are coerced
  before any arithmetic that could overflow, the nearest-first ring has a hard cap, and a
  `onTrimMemory` / `OutOfMemoryError` cuts the loaded-chunk budget (and restores it step by step once the
  pressure has passed). A 1000-chunk selection was run through the streaming simulation (simulation, not a
  device).

### Streaming core: holes, priorities, rebuilds, uploads

- One re-rankable job queue for generate / mesh / pack jobs, ranked by distance, by direction of travel and
  by whether the ground is in front of the camera, and re-ranked as the player moves or turns.
- A chunk column is meshed once, after the neighbours it is meshed against, and handed over atomically.
  A neighbour that arrives later only redoes the sub-chunks that touch the shared edge (incremental
  boundary remesh) instead of the whole column and its 4x4 region.
- Region buffers are packed on the worker threads, uploaded by the GL thread under a per-frame budget in
  priority order (player edits first, then what is nearest and in front).
- **Failures are never silent**: a failed generate/mesh/pack job is counted, logged, retried with a delay,
  and a column that cannot be built is accounted for instead of leaving a permanent hole. The count shows as
  `errors:N` on the stats line whenever it is above zero.
- The chunk table (`world/ChunkMap.kt`) replaces `ConcurrentHashMap<Long, Chunk>`: the old table boxed every
  key (garbage on every block read) and its hash was `cx xor cz`, so a ring of about 1,100 chunks shared a
  few dozen buckets. The new one is lock-free for reads, primitive-keyed and uses a mixing hash. Verified in a
  concurrent stress test.

### Terrain generator

- The generator output was verified **bit-identical** to the original (SHA-256 over 4 seeds x 6 sites x 169
  chunks, blocks + height map + cave-mouth flag, re-run on the final code), because saved worlds regenerate
  unedited chunks from the seed and any change would put seams against the chunks you edited.

### Not verified (needs a phone)

- Frame rate, frame-time spikes and upload hitches on the Infinix X675 (Mali-G52 MP2): everything above about
  speed is from a JVM on a 2-core machine with a cost model for the GPU.
- Whether the crack-hiding growth of merged faces (`EDGE_GROW`) really closes every pixel-wide gap on a Mali
  GPU, and the cost of the new fragment shader (the per-block hash and the lookup) on it.
- The look of the coastline at the voxel/distant hand-over (the software renderer does not draw water), and
  trees, ambient occlusion and the risers at the dissolve ring, where the two kinds of terrain are built
  differently.
- How the memory policy behaves with real Android memory signals, and whether the far-terrain upload budget
  changes frame times (it should not exceed what the old two-per-frame rule did in a quiet frame).
- The Gradle build itself (this environment cannot reach it; GitHub Actions builds the APK).

## v13 - stable far terrain, a real LOD ladder, cleaner water, and a flight recorder

**Not compiled or run on a device.** This was written without a Kotlin toolchain (none is
available here), like several versions before it. What *was* checked: every shader compiles and
links in a WebGL2 (GLSL ES 3.00) driver; the level-of-detail blending logic was ported to Python and
checked for exact agreement between levels; and all Kotlin was checked for balanced delimiters and
for every cross-file reference. If the build reports an error, it will be a plain type or name slip:
send the message and it is a one-line fix.

**Build fix (CI run 1831).** The first build of v13 stopped on two compile errors in
`diag/DiagLog.kt` ("No set method providing array access"): `upload()` and `farTile()` added a
`Float` sample straight into a `DoubleArray` element. Both now convert it with `.toDouble()` first.
Nothing else changed.

### Distant terrain moved / "waved" while you moved or turned (fixed)

Four separate mechanisms could do this; all are gone:

- **Levels were drawn on top of each other and one was sunk by a distance-dependent amount.** Near
  each seam the coarser level was lowered by an amount that depended on its distance from the
  *player*, so the ground heaved as you walked, and where the finer level ended there was a hard
  height step. Now the columns of a level slide smoothly to the height of their *parent* column
  (2 x 2 columns share one) over the outer part of their ring (a per-vertex target height + a
  smoothstep of distance in the vertex shader). At the ring's edge a fine mesh *is* the coarse
  mesh, so levels meet with no overlap, no sinking, no step and no popping, and the meshes
  themselves stay static and cached. Equal neighbours whose parents differ get a (flat) wall that
  opens as they slide, so there is no crack either.
- **The voxel -> distant-terrain dissolve used screen-space noise.** The stipple was fixed to the
  screen, so the terrain swam behind it whenever the camera moved or turned. It is now noise fixed
  to the world (a quasi-random value per 2 x 2 block cell).
- **Sampling shimmer.** Textures were picked a quarter mip level *sharper* than the hardware rule
  with single-texel fetches, so pixels skipped texels and which ones changed with every camera
  movement. The bias is now a third of a level *coarser*; up close (texels bigger than pixels)
  nothing changes and pixels stay crisp.
- **Per-block grain on far cliffs flickered at large coordinates.** It was decided by
  `floor()` of an interpolated world position, which on a wall (exactly on a cell boundary) comes
  down to the last bit of the interpolation, and at x or z beyond a few thousand that bit is noise.
  The grain is now offset away from cell boundaries and fades out by 220 blocks, where it would
  only alias.

### Intermediate levels of detail (LOD)

Distant terrain is now a ladder of six levels, finest first, every level's columns twice as wide as
the one before and all on a common grid:

| level | name | column | ring (blocks from the player) |
|------:|------|-------:|-------------------------------|
| - | LOD 0: voxel chunks | 1 | unchanged |
| 0 | LOD 1 (high) | 2 | thin ring just behind where the voxel terrain dissolves (about 56 blocks wide) |
| 1 | LOD 2 (medium) | 4 | to 512 (this was the old level 0) |
| 2 | LOD 3 (low) | 8 | 512 - 896 (the old level 1) |
| 3 | very far | 16 | 896 - 1408 (new: bridges what used to be an 8 -> 32 jump) |
| 4 | very far | 32 | 1408 - 2304 (the old level 2, unchanged) |
| 5 | very far | 64 | beyond (the old level 3, unchanged) |

The original far terrain is kept as the VERY FAR family (its 32- and 64-block levels are untouched
apart from where their rings start). Cost control: the 2-block ring costs about four times the
triangles per block of the next level, so it is thin, uses small (64-block) tiles so a thin ring
wastes few triangles, is built *last* (it never delays the horizon or the fog), and is dropped
while the adaptive distance has pulled the view in (below 85 %; back at 97 %). Each 4-block
tile hands the ring over to the 2-block level only once every 2-block tile it needs is on the GPU,
so there is never a hole and never two surfaces. Ground under (near-)opaque water is not built:
level 0 keeps the sea floor down to 10 blocks, level 1 to 3.5, coarser levels keep only the shore
(see water, below). That saves triangles on every coast. Levels 0 and 1 stand real trees (which
sink into the ground at the end of their ring); coarser levels raise forests into a canopy layer, as before.
Ring columns now get their slope from their true neighbours (the height window is one column
larger), so colour and canopy of a tile's edge match the neighbouring tile exactly.

### Distant materials look natural

- The soft colour patches were three sine waves, so they formed regular stripes and repeats. They
  are now domain-warped fractal value noise: irregular clusters at several scales, a pure function
  of world position (identical at every level, never re-rolled, stable while moving). The finest
  octave is dropped on coarse levels, where it would only turn into speckle.
- A small tileable noise texture (`FarNoiseTexture`, 128 x 128, 16 KB) adds soft, world-anchored tonal
  variation to the flat palette colours, growing with distance (two taps at different scales and
  axes so the repeat never shows). It costs two texture fetches per far pixel and nothing in
  geometry.
- Biome, surface type and the generator's rules are untouched: the distant colours still come from
  the same `surfaceFor` rules as the voxel terrain.

### Water

The dark jagged contour-like lines had several independent causes (I could not see your
screenshots in this session, so each plausible cause is closed rather than one guessed at):

- **T-junction cracks in the voxel water.** Deep open sea is merged into big rectangles; where one
  meets the many small quads of unmerged water (or the next chunk's rectangle) the shared edge has
  extra vertices on one side only, and rasterisers round the two sides differently: pixel-wide
  cracks along the *whole 8-block-depth contour*, with the seabed or sky showing through. Merged
  rectangles now overlap their neighbours by 0.004 block (water is not depth-written and is ~97 %
  opaque there, so the overlap is invisible and the cracks are not).
- **Distant sea was only 97 % opaque,** so 3 % of every seam, crack and stray triangle behind it
  showed through, over a whole ocean. Beyond 300 blocks the sea is now fully solid, and the far
  ground under it is not built (see LOD).
- **Seabed steps outlined themselves through the surface.** Walls under water are shaded like tops,
  and low shore steps halfway, so a coast no longer gets a dark outline.
- **Rings of far water now overlap by 1.5 blocks** instead of meeting exactly (a hairline gap
  would show the dark ground as a ring).
- **Depth precision.** The distant pass's near plane could be as small as half a block while the
  voxel area had not loaded; depth resolution at 3000 blocks is then about a block, and the sea
  (an eighth of a block above shallow ground) and the ground fought for every pixel. The floor is
  12 blocks now (under 0.05 block at 3000).
- The old per-level "sink" no longer exists, so land near the sea at a seam cannot rise through water.

### Diagnostics: a low-overhead flight recorder

Settings > Diagnostics: **Off / Lightweight / Detailed**, and an optional on-screen panel. Pause menu >
**Diagnostics**: *Capture incident*, *Save full log*, *Share report* (Android's share sheet; files
are attached through a content URI, never the clipboard).

- Off does nothing (one volatile read per hook; no thread, no memory). On: events go into a
  preallocated ring buffer (12,288 events, ~0.5 MB, no allocation per event); one background thread
  formats them to JSONL and appends in batches (no file I/O on the render thread or any game
  thread), samples memory, and writes reports.
- Records: FPS and frame-time percentiles per second, stutters, freezes, Java/native heap,
  chunk generation and meshing times, GPU upload times, far-tile builds per level (with triangle
  counts), GL errors, coverage and *missing terrain*, governor changes, lifecycle, crashes.
- **Incidents** (lag spike >= 200 ms (120 detailed), freeze >= 500 ms, GL error, error, heap nearly
  full, low-memory, missing terrain for 4 s, or the manual button) keep the 10 s before and 5 s
  after, written to their own file and included in the report. Rate limited (15 s apart, 16 max).
- Timestamps: local time with milliseconds, derived from the monotonic clock (session start wall
  time + monotonic offset), plus elapsed seconds since the session began.
- Survives crashes: events reach disk within 1-2 s; the crash handler flushes and writes the last
  30 s; the next launch notes that the previous session ended abnormally. Folder: bounded to 32 MB
  and the newest 6 sessions; one session file is capped at 6 MB (12 detailed) after which only
  critical events are written.
- Reports say what was lost: events overwritten before writing, shed low-priority events, size cap,
  failed writes, suppressed incidents, and the measured overhead (render thread microseconds per
  frame; background thread busy time). When the writer falls behind or its own cost passes 1.5 % of
  frame time, low-priority events are shed automatically.

Statistics overlay: new line `lod tris(k): LOD1 LOD2 LOD3 | far16 far32 far64`.

### Known limitations

- Not run on a device (see the top). Please try Detailed logging for a minute at a coast and a
  mountain and share the report if anything looks wrong.
- The 2-block ring is dropped under load, so on a device that is always below ~30 FPS the first
  distant ring is the 4-block one, as before.
- The geomorph slides *heights* only: colours still change at a ring's edge (they come from the same
  world-position noise at every level, so the change is subtle, but it is not blended).
- The diagnostic panel shares the existing stats text view, so it appears with the same layout.
- A coast that is far away is built from columns at least 8 blocks wide, so its outline is coarse
  by construction.

## v12 - crisp pixels, calmer water, and about half the distant-terrain triangles

Found from three screenshots at a render distance of 400 chunks (26-37 FPS, 1.0-1.4 million
triangles per frame, three quarters of them distant terrain):

- **Textures were blurry because the GPU was filtering them.** The atlas asks for nearest-texel
  sampling, but on many mobile GPUs (the screenshots look exactly like it) anisotropic filtering is built on
  bilinear probes and quietly overrides that, which smears 16x16 pixel art into soft blotches
  (worst on the ground, where it streaks towards the horizon). Anisotropy is now off, and the
  voxel-terrain shaders no longer rely on the sampler at all: they pick the mip level from the
  pixel's footprint and `texelFetch` single texels (`Shaders.crisp`), which no driver can
  filter. If a driver rejects that shader the game falls back to the old one. (Checked by
  rendering it on a software GLES 3.2 against a CPU reference at six magnifications and
  minifications.)
- **Distant terrain costs half the triangles.** Every far tile used to be 64 x 64 columns whatever
  its distance, so a tile a kilometre or more away cost as much (about 16-18k triangles) as one
  at the edge of the voxel area. The two coarsest levels are now 32 x 32 columns of twice the
  width (same tile size, same bands), about 4k triangles each, and they build four times
  faster. The two finest levels are unchanged. Modelled on the real tile builder, a typical
  400-chunk view goes from about 750k far triangles to about 410k.
- **Tiles that start beyond the fog are not drawn at all** (they were pure fog colour, which is
  also exactly the sky colour at and below the horizon).
- **The adaptive distance can pull in further** (down to 40 % of the render distance, never
  below 560 blocks) because that now really saves work: it used to stop at 70 % and sit at
  27 FPS. While it is pulling in, the voxel area shrinks with it too (down to 60 % of its
  radius, once the distant terrain is proven to cover that range): a block of voxel terrain
  costs about ten times the triangles of the distant terrain that replaces it.
- **Water:** the seabed no longer shows through as dark lines. Opacity now follows the light's
  path through the water (depth / viewing angle) and rises with distance, so a slanted view
  through two or three blocks is nearly solid; the water tile lost its light flecks (they
  stretched into rain-like streaks at a slant) and is a calmer set of blues, and the
  anisotropic filtering that smeared it is gone too. The thin dark lines that remain standing
  in the sea in your screenshots look like real land rather than a water bug (their pixels are
  unblended dark gravel grey and grass tufts stand on them): 1-block-wide bars and terraces at
  sea level that stick out of the water by an eighth of a block or more.

## v11 - 16x16 textures, calmer water, a far horizon that fills in fast, and a lot less CPU per chunk

Saves are compatible with v10: the terrain is bit-for-bit the same (every change to the
generator below is a pure speed-up, checked against the old code on millions of samples).

### Look
- **16x16 block textures, like the classic voxel games.** Every tile is now hand-tuned 16x16
  pixel art (speckled grass/dirt/stone/sand, ragged grass caps on the sides, vertical bark,
  ring-patterned log ends, leaves with a few see-through holes, ...), baked into the code, so
  nothing is generated at start-up. The atlas shrank from 512x512 to 256x256 (a quarter of the
  texture memory and bandwidth). Pixels stay crisp up close; mip-mapping smooths them in the
  distance. The colour ramp of the distant terrain is derived from the new tiles, so the far
  ground matches the near ground.
- **Water** now matches the block textures: a 16x16 pixel-art water tile (four blues and a few
  light flecks), one repeat per block, drifting slowly or running with the current; depth tint,
  a sky tint at grazing angles. The old shader switched the pattern off with distance (so water
  looked flat from afar and "filled in" as you walked up to it) and added foam, a swell and a
  second blended copy of the tile. All of that is gone: the pattern is the same at every distance
  (the mip chain averages it away on its own), and the shader is about half the work per pixel
  (one texture fetch, no per-pixel trigonometry), which matters because water covers a large part
  of the screen over an ocean.

### Far terrain (render distances in the hundreds of chunks)
- **Tiles are built by two or three threads at once** (one on small CPUs), published in plan
  order, so the horizon fills in two to three times faster. Until a ring of tiles exists the fog
  stays in front of it, so a faster build is a longer visible range sooner.
- **Each tile's heights cost about a third less:** the river/lake/mountain/detail layers are
  skipped where their weight is exactly zero (open sea, high ground), and the smooth base
  elevation, which used to be computed a second time per cell for the biome rules, comes out of
  the same pass as the height.
- Trees: the 25 height samples per tree candidate became at most 13 (usually 5).

### Chunk generation and meshing
- Terrain generation is about a quarter to a third cheaper per chunk: base elevation and the
  humidity/temperature fields are computed once per column instead of two or three times, ore
  noise is sampled only for rock that is actually there, caverns are skipped cell by cell where
  the noise cannot reach the threshold, and blocks are written straight into the sub-chunk
  arrays.
- **Meshing reads one padded copy of the cells around a sub-chunk** (18x18x18) instead of doing a
  chunk/world lookup per face and per ambient-occlusion probe. Rock deep underground, with
  nothing see-through in or next to it, is recognised in a few microseconds and skipped. The
  output is identical to v10 (fuzz-tested on thousands of random sub-chunks, including chunk edges,
  unloaded neighbours and the world floor and ceiling), the CPU time per sub-chunk is about a third
  lower, and the per-lookup allocations are gone.
- The crosshair ray looks each cell up once instead of about twenty times.

## v10 - new world, caves, clouds, water, seagrass, and a lot less per-frame work

This version is a big step. **Old saves are not compatible** (the world is taller and the
terrain is different): "Continue" with a v9 save starts a fresh world.

### The world
- **Taller world, real mountains.** The world is 256 blocks tall (was 128) with sea level at 64
  (was 40). Mountain ranges are broad massifs that climb through foothills, forest, bare rock
  and a snow cap, and peak around 180 blocks above the sea (they used to top out near 85).
  About 17% of the land is above the rock line. Ridge height grows with the square of
  the mountain mask, so there are long gentle foothills before the cliffs.
- **Biomes that make sense.** Biomes come from a temperature x humidity table with five
  temperature bands, using the temperature *at the ground* (it drops with altitude). Desert
  (hot) can no longer touch snow (frozen): the way between always runs savanna -> plains ->
  taiga, at least ~400 blocks and typically ~1000. Mountains zone by height from the same
  rule, so the snow line is lower in cold climates and higher in hot ones.
- **Swamps** (new): wet, mild, low land is flattened to about sea level and dotted with shallow
  ponds, with murky olive grass, dense grass and oaks. **Lily pads now grow only in swamps.**
- **Seagrass** (new): meadows on the bed of seas, lakes and rivers (2-14 blocks deep). It is a
  plant that lives in a cell that is also full of water; breaking it leaves water.
- **Caves and a deep underground.** Winding tunnels (in four layers, clustered into cave
  systems), big caverns, and cave entrances: sloping ramps cut into hillsides, so caves are
  findable. Nothing comes closer than 6 blocks to the surface (9 under water), so the ground is
  intact and the sea never drains; any cave cell that would touch water is sealed as rock.
  Below y~24 the rock is dark **deep stone**, with coal veins and pockets of gravel and dirt.
  Faces get darker the deeper they are under the ground, so caves feel underground.
  Cave faces that cannot be seen from outside are only meshed while you are underground (and
  always for chunks with a cave mouth, so a far entrance is dark rock and not a see-through hole,
  and for chunks you have edited), which keeps the hidden underground out of memory and off the
  GPU in the normal case of walking or flying over the surface. Going underground meshes the
  chunks around you within a fraction of a second; they are dropped again 20 s after you leave.

### Look
- **Water**: replaced the one-block 32x32 tile (which tiled into a visible grid and aliased into
  moire) with a 128x128 procedural tile of five blues and thin ripple lines, stretched over
  8-12 blocks, two copies blended at different scales/angles so no lattice of repeats shows,
  fading to a flat colour with distance (with a mip bias), a slow large-scale swell, and a sky
  tint at grazing angles. Still flat and chunky, not realistic.
- **Clouds**: thick, blocky, shaded clouds (flat grey-blue underside that is darkest where the
  cloud is thickest, white tops, sun-lit sides) instead of a flat sheet. One static mesh,
  drawn 3 x 3 times with a single instanced draw; far clouds dissolve into the sky colour
  itself (no alpha blending). Mountains poke through the layer (base y=212).

### Distances
- Render distance slider now goes up to **400 chunks**, detail distance up to **300**, on a
  quadratic scale so the low end stays finely adjustable. Full-detail (voxel) chunks cost
  memory, so a device can only keep so many loaded: the settings text says how many chunks of
  full terrain *this device* holds (typically ~20 on a 512 MB heap), and the distant terrain
  takes over beyond that. To get more, raise `CHUNK_HEAP_SHARE` in WorldManager (memory risk).

### Performance (the HUD showed ~900 GL calls and ~1M triangles per frame, with the GL thread
### spending 22-26 ms of a ~30 ms frame in the driver: CPU-bound on call count, not on Kotlin)
- Regions are 4x4 columns (was 2x2): about a quarter of the draw calls and buffer binds.
- Plants (grass, flowers, seagrass, lily pads) are only drawn within 120 blocks: one less draw
  per far region and far less alpha-tested overdraw. Trees are drawn at any distance.
- **Flat open sea is merged into big quads** (voxel water: greedy rectangles per 16x16 chunk
  layer; distant water: any aligned block of 4x4..64x64 deep cells becomes a fan with the edge
  vertices kept, so no cracks). Over open ocean this was ~190k + ~250k triangles.
- The **sea floor under 10+ blocks of water** is only meshed while you are underwater and
  within ~3 chunks (from above it is hidden by the 93%-opaque water anyway): that was ~230k
  triangles of an ocean view, and flying over the sea no longer triggers any re-meshing for it.
- Chunk generation: ore/pocket noise on a 2-block lattice, cave fields on a 4-block lattice.
- Adaptive-distance governor engages below 30 fps (was 42) and goes no lower than 70% (was 65%).

### How it was checked (no Kotlin toolchain here, so none of it was compiled or run on a device)
- The terrain/climate/cave/cloud/water algorithms were prototyped in Java (identical integer
  semantics) and judged on rendered maps, silhouettes and slices; the cloud and water shaders
  were rendered with the real GLSL in headless WebGL2, and every shader pair in Shaders.kt
  compiles and links there. The water-quad merge, the fan triangulation and the ore rates were
  fuzz/unit tested numerically.
- The Kotlin was desk-checked against the original and checked for balanced braces. **Please
  build it and tell me about any compile error** -- and about frame times: the draw-call and
  triangle reductions are measured in counts, not in milliseconds.
- Known trade-off: where merged flat water meets unmerged water there can be the odd
  single-pixel crack (T-junction), as at the distant-terrain level seams.

## v9: flowing pixel-art water, smoother LOD transition, much lighter on the GPU

## What changed
- **Water flows.** Break a wall next to a lake and it pours in; dig a shaft and it falls; it runs about
  7 blocks over flat ground, one level lower per block, and drains again when you cover its source.
  The last hotbar slot is now **Water** (8 sources in survival, unlimited in creative): place one and watch
  it spread. It is a small event-driven simulation (`FluidSimulator`): nothing runs until a block next to
  water changes, then a few hundred cells per tick at 5 ticks a second, so calm oceans cost nothing.
  How full a cell is lives in the spare top 3 bits of its block byte (`Fluid`), so there is no new storage
  and old saves load unchanged (ocean and lake water are all full "source" blocks).
- **Water looks like the rest of the game.** The reflective / glinting / swelling water is gone. Water is now
  pixel art: a 32x32 tile in six blues (`WaterTexture`), nearest-texel filtered, sliding along the flow
  direction, with a depth tint (azure shallows, deep blue open water) and shoreline foam. Flowing water
  gets stretched streaks, waterfalls get their own side faces with tall streaks running down. The surface
  height follows the water level and slopes smoothly between cells.
- **LOD starts farther out and blends in.** Default detail distance 16 -> 20 chunks (slider up to 32;
  an old saved default of 16 moves to the new one once). The voxel terrain now *dissolves* into the distant
  terrain over the last ~30-45 blocks (ordered-noise screen door), instead of ending in a hard line.
  The distant terrain also carries the same per-block brightness speckle the real blocks have, so flat
  colour no longer reads as a different material. The textured wall that used to stand at the outer rim
  of loaded chunks is gone (see below), and the coverage scan runs 8x per second instead of 4x.
- **Lighter on the GPU / CPU (no visual cost):**
  - Opaque blocks are drawn by a fragment shader with **no `discard`**, so the GPU can reject hidden pixels
    early (and tile-based GPUs can remove them outright). Only leaves and plants are alpha-tested, in
    their own draws afterwards (`MeshData.opaqueEnd` / `cutoutEnd`, `ChunkGpuMesh.drawOpaque/Cutout/DoubleSided`).
  - Plants and lily pads are one quad per plane drawn with culling off instead of two quads each: half the
    vertices and triangles of every meadow, and less memory per chunk.
  - Faces towards a chunk that is not generated yet are not drawn. The outer rim of loaded chunks used to
    be a tall stone/dirt wall of faces nobody should see; that was a big share of all triangles.
  - Region uploads are debounced: a region still receiving subchunk results waits ~70 ms and is built once,
    instead of being rebuilt (and re-uploaded) after each of up to 32 results. Streaming hitches drop a lot.
  - All-air subchunks are not queued for meshing at all (a chunk generating queues its neighbours' too).
  - The new water shader is a couple of texture fetches and a tint (the old one did Fresnel, normals,
    glints and foam per pixel over big translucent oceans); water is also never drawn twice where the
    distant and voxel layers meet.
  - Voxel regions entirely past the dissolve edge are skipped; the sky shader skips the sun terms away from
    the sun.

## Heads-up
- New hotbar slot (Water). An old save has no count for it, so it starts with 8.
- Flowing water is saved with the chunks it entered. Water that was already "frozen" mid-flow when you
  quit stays as it was until something next to it changes.
- Water does not push the player or slow swimming (not asked for, not changed).
- Still written without a Kotlin/Android toolchain: not compiled or run on a device. The GLSL was compiled
  and the water previewed in a headless WebGL2 context, and the fluid rules were run in a Python port.
  If the build reports an error, the log line points straight at it.

---

# (previous) VoxelSandbox v8: creative mode, blocky LOD with trees, new biomes, fixes

## What changed
- **Creative mode** (star button on the HUD, or Settings): free flight along the look direction, jump = up,
  new "fly down" button, double-tap jump toggles flight, unlimited blocks, instant plant/block breaking.
  Fly speed slider in Settings (8..200 blocks/s) for fast travel while testing.
- **Destroy laser** (creative only, new HUD button): hold to carve a 96-block-long tube through everything
  in front of you (pierces terrain, trees, plants) to stress-test chunk edits and remeshing. Edits are batched
  (`WorldManager.setBlockBatched` / `flushBatchedEdits`) so a pulse remeshes each affected subchunk once.
- **Distant terrain (LOD)** now looks like voxels: flat-topped columns with vertical walls, flat colours,
  neighbours merged into long quads. Level 0 stands real little trees (trunk + canopy boxes) at exactly the
  spots the chunk generator will grow them; coarser levels raise forests into a dark canopy layer.
  Tiles are 64x64 columns (256 blocks at level 0), so roughly a quarter of the draw calls.
- **Leaves**: new crisp pixel-art leaf textures (flat palette colours, rare isolated holes with a darker rim)
  instead of the smooth blurry scatter; you can no longer see straight through trees.
- **Thin outlines on blocks** (sand, grass, snow, ...): caused by texture filtering at low angles reaching into
  the neighbouring tile of the atlas. Every tile now has a 16-texel gutter filled with its own pattern.
- **Sky box outline**: it was the edge of the translucent cloud square. Clouds are now a blocky, drifting layer
  with no edge (`CloudRenderer`, `Shaders.CLOUD_*`) that fades out with distance.
- **Biomes** (`Climate`, `Biome`): plains, forest, birch forest, taiga, snowy plains, snowy taiga, savanna,
  desert, mountains, snowy peaks, beach, snowy shore (gravel), ocean, deep ocean, lake. Decided from the slow
  climate fields, the smooth coastline and altitude, never from local bumps, so no more sand mixed with snow
  (snowy coasts are gravel, beaches only exist in warm climates, snow line depends on temperature).
  The biome you are in is shown at the top of the screen.
- **Terrain**: the 1-block jitter (micro noise) is gone, high-frequency hill octaves are weaker, and lone
  1-block bumps/pits are removed (`TerrainGenerator.despike`), so plains are flat and slopes form wide terraces.
- **Jump**: snappier (gravity 32, jump speed 8.9, about 1.25 blocks high), feet-level collision epsilon, and
  Auto Jump is now on by default.
- **Plants** can be targeted (small outline box) and broken, and placing a block on one replaces it.
- **Lily pads** float on shallow warm water in patches (new block, flat quad).
- **Performance**: voxel chunks are drawn in 2x2-column regions (about 3.5x fewer draw calls, the main cost on
  phones), distant tiles are 4x bigger (about 4x fewer draws), water shader skips its fine ripple layer and
  foam for distant fragments, one distant tile uploaded per frame.

## Heads-up
- Save format bumped to v3 (the terrain changed): "Continue" with an old save starts a fresh world.
- Written without a Kotlin/Android toolchain, so not compiled or run on a device. If the build reports an
  error, the log line points straight at it.

---

# Earlier: VoxelSandbox v7: water, textures, realistic terrain, 200-chunk view distance

## What changed
- **Animated water**: translucent surface drawn in its own pass (`WaterRenderer`, `Shaders.WATER_*`).
  Scrolling ripple normals, gentle vertical swell, Fresnel sky reflection, sun glint, depth-based
  colour/opacity (turquoise shallows -> deep blue), drifting shoreline foam. Works on voxel water
  and on distant water. You can now also place blocks into water.
- **Textures**: atlas is now 32x32 per tile (was 16x16), anisotropic filtering where available.
  New scattered-leaf foliage (midribs, rims, holes) for oak/birch/spruce; richer grass, dirt, stone
  (cracks), sand, bark, coal. Grass sides are mostly green so hills no longer read as brown contour bands.
  New blocks: snow, gravel, sandstone, dry grass, cactus, and cross-shaped plants (tall grass,
  poppy, dandelion, dead bush). All textures stay procedural (`BlockTextures.kt`), no assets.
- **Terrain** (`TerrainShape`, `Climate`, `TerrainGenerator`, `TreeBuilder`): world is now 128 tall
  with sea level 40. Oceans, continents, rolling hills, ridged mountain ranges with snow caps and
  rock/scree on steep slopes, rivers, lakes, beaches, deserts, savanna, taiga/snow, per-biome
  trees (oak, birch, tall spruce, cacti). New worlds spawn on dry land (`findSpawn`).
- **Render distance**: slider maximum is 200 chunks (3,200 blocks). Distant terrain now has 4 levels of
  detail (`FarTerrain`, `FarTerrainRenderer`) so the triangle count stays near a 600-block view's.
  Distant terrain is drawn in its own depth range for stable depth precision at that range.
- **Sky**: gradient sky with a sun (`SkyRenderer`, `Atmosphere`); fog fades into the horizon colour.

## Heads-up
- Save format bumped to v2: worlds saved with v6 cannot be loaded (their terrain no longer exists).
  "Continue" with an old save starts a fresh world.
- Chunk memory budget is now `WorldConfig.RESIDENT_BYTES_PER_CHUNK` (96 KB per chunk).
- This version was written without access to a Kotlin/Android toolchain, so it has not been
  compiled or run on a device. If the build reports an error, the log line points straight at it.

## Tuning knobs
- Water look: constants in `Shaders.WATER_FRAGMENT` (colours, alpha, glint power).
- Sky/fog colours and sun direction: `Atmosphere`.
- Terrain scale/shape: numbers in `TerrainShape.height` (continent frequency 0.00042, mountain
  height 74, hill amplitude), biome thresholds in `Climate.classify`.
- LOD ring distances: `FarTerrain.BAND_OUTER` / `BAND_OVERLAP`.
