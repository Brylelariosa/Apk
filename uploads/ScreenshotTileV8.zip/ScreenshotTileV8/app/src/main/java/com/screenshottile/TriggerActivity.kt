package com.screenshottile

import android.accessibilityservice.AccessibilityService
import android.app.Activity
import android.os.Bundle

/**
 * Invisible zero-UI activity.
 * startActivityAndCollapse() collapses the QS panel before this activity starts.
 *
 * SCREENSHOT TIMING STRATEGY
 * --------------------------
 * Ideal trigger: onWindowFocusChanged(hasFocus=true) — fires when the panel
 * animation is fully complete and the screen is clean.
 *
 * Fallback trigger: onResume + 400 ms delay — required for the home screen
 * (launcher) and menus, where Android does NOT grant window focus to a
 * translucent activity overlaid on the launcher. Without this fallback,
 * onWindowFocusChanged(true) never arrives and the activity exits without
 * taking a screenshot.
 *
 * SAVE RELIABILITY
 * ----------------
 * performGlobalAction() returns a Boolean — true means dispatched, not saved.
 * If it returns false (system temporarily busy / not ready), we retry once
 * after 200 ms rather than silently failing.
 *
 * We delay finish() by 1500 ms after dispatch. The actual file write is done
 * by the system process and is independent of our process, but keeping a
 * foreground component alive prevents Android from dropping our process
 * priority mid-pipeline on memory-constrained devices.
 *
 * FLASH PREVENTION
 * ----------------
 * Even with windowIsTranslucent=true, the activity's first draw can briefly
 * composite a surface — causing a visible flash that is NOT the screenshot
 * flash. Nulling the window background in onCreate removes this entirely.
 */
class TriggerActivity : Activity() {

    private var screenshotTaken = false
    private var retryCount = 0

    // Delayed fallback "take screenshot" posted from onResume
    private var screenshotRunnable: Runnable? = null
    // Delayed finish() posted after a successful dispatch
    private var finishRunnable: Runnable? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Null the background so the activity surface never composites a visible
        // frame — eliminates the spurious flash that looks like a failed screenshot.
        window.setBackgroundDrawable(null)
        if (ScreenshotAccessibilityService.instance == null) { finish(); return }
    }

    override fun onResume() {
        super.onResume()
        // Post a fallback in case onWindowFocusChanged(true) never fires
        // (home screen / launcher / menu below this transparent activity).
        // 400 ms gives the QS panel collapse animation time to complete.
        if (!screenshotTaken && screenshotRunnable == null) {
            val r = Runnable { takeScreenshot() }
            screenshotRunnable = r
            window.decorView.postDelayed(r, 400L)
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && !screenshotTaken) {
            // Focus arrived — panel animation is definitely done.
            // Cancel the pending fallback and fire immediately.
            screenshotRunnable?.let { window.decorView.removeCallbacks(it) }
            screenshotRunnable = null
            takeScreenshot()
        }
    }

    private fun takeScreenshot() {
        if (screenshotTaken) return   // guard against race between the two paths

        val service = ScreenshotAccessibilityService.instance
        if (service == null) { finish(); return }

        val dispatched = service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)

        if (!dispatched && retryCount < 1) {
            // System wasn't ready (e.g. still animating). Retry once after 200 ms.
            // Do NOT set screenshotTaken — we haven't actually taken anything yet.
            retryCount++
            val r = Runnable { takeScreenshot() }
            screenshotRunnable = r
            window.decorView.postDelayed(r, 200L)
            return
        }

        screenshotTaken = true

        // 1500 ms keeps this activity alive as a foreground component while the
        // system completes the async capture + MediaStore write. On slow/busy
        // devices, 400 ms was too short and the save pipeline could be interrupted
        // when our process priority dropped after finish().
        val r = Runnable { finish() }
        finishRunnable = r
        window.decorView.postDelayed(r, 1500L)
    }

    override fun onPause() {
        super.onPause()
        // If paused before the screenshot fired (another activity jumped in),
        // cancel the fallback — we'd be screenshotting the wrong screen.
        if (!screenshotTaken) {
            screenshotRunnable?.let { window.decorView.removeCallbacks(it) }
            screenshotRunnable = null
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        screenshotRunnable?.let { window.decorView.removeCallbacks(it) }
        finishRunnable?.let { window.decorView.removeCallbacks(it) }
        screenshotRunnable = null
        finishRunnable = null
    }
}
