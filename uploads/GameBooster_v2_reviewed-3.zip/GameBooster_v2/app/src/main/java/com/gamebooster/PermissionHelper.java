package com.gamebooster;

import android.app.AppOpsManager;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.PowerManager;
import android.os.Process;
import android.provider.Settings;

/**
 * Utility class for checking and requesting special permissions required by GameBooster.
 *
 * <p>Added in this revision:
 * <ul>
 *   <li>{@link #isBatteryOptimizationIgnored} — checks whether the OS will kill the service</li>
 *   <li>{@link #batteryOptimizationIntent} — opens the system exemption dialog directly</li>
 *   <li>{@link #isXosDevice} — detects Infinix/TECNO/itel XOS to show the Auto-start guide</li>
 * </ul>
 */
public final class PermissionHelper {

    private PermissionHelper() {}

    // ── Usage Access ─────────────────────────────────────────────────────────

    public static boolean hasUsageAccess(Context ctx) {
        AppOpsManager aom = (AppOpsManager) ctx.getSystemService(Context.APP_OPS_SERVICE);
        int mode = aom.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            Process.myUid(),
            ctx.getPackageName()
        );
        return mode == AppOpsManager.MODE_ALLOWED;
    }

    public static Intent usageAccessIntent() {
        return new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
    }

    // ── Notification Policy (DND) ────────────────────────────────────────────

    public static boolean hasNotificationPolicyAccess(Context ctx) {
        NotificationManager nm =
            (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        return nm.isNotificationPolicyAccessGranted();
    }

    public static Intent notificationPolicyIntent() {
        return new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS);
    }

    // ── Write Settings (brightness) ──────────────────────────────────────────

    public static boolean canWriteSettings(Context ctx) {
        return Settings.System.canWrite(ctx);
    }

    public static Intent writeSettingsIntent(Context ctx) {
        return new Intent(
            Settings.ACTION_MANAGE_WRITE_SETTINGS,
            Uri.parse("package:" + ctx.getPackageName())
        );
    }

    // ── Battery Optimization Exemption (NEW) ─────────────────────────────────

    /**
     * Returns {@code true} if the OS will NOT kill GameBooster in the background.
     *
     * <p>On XOS (Infinix/TECNO/itel) this is the single most important permission —
     * without it the foreground BoostService is terminated within minutes on Android 11+.
     */
    public static boolean isBatteryOptimizationIgnored(Context ctx) {
        PowerManager pm = (PowerManager) ctx.getSystemService(Context.POWER_SERVICE);
        return pm.isIgnoringBatteryOptimizations(ctx.getPackageName());
    }

    /**
     * Returns an Intent that shows the system dialog:
     * <em>"Keep GameBooster unrestricted?"</em>
     *
     * <p>This is the only reliable cross-vendor way to request exemption.
     * The XOS-specific Phone Manager route is handled separately in
     * {@link XosGuideDialog}.
     */
    public static Intent batteryOptimizationIntent(Context ctx) {
        return new Intent(
            Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
            Uri.parse("package:" + ctx.getPackageName())
        );
    }

    // ── XOS / Infinix detection (NEW) ────────────────────────────────────────

    /**
     * Returns {@code true} when running on an Infinix, TECNO, or itel device
     * (all share the XOS ROM and the same aggressive battery manager).
     */
    public static boolean isXosDevice() {
        String brand = android.os.Build.BRAND.toLowerCase();
        String mfr   = android.os.Build.MANUFACTURER.toLowerCase();
        return brand.contains("infinix")  || mfr.contains("infinix")
            || brand.contains("tecno")    || mfr.contains("tecno")
            || brand.contains("itel")     || mfr.contains("itel");
    }
}
