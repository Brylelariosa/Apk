package com.gamebooster;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;

/**
 * Step-by-step dialog guiding XOS (Infinix/TECNO/itel) users through two
 * settings that are required to keep BoostService alive:
 *
 * <ol>
 *   <li><b>Auto-start</b> — Phone Manager → Auto-start Manager → enable GameBooster</li>
 *   <li><b>Background freeze</b> — Phone Manager → Power Saver → unfreeze GameBooster</li>
 * </ol>
 *
 * <p>Both settings live inside Infinix's "Phone Master" app
 * ({@code com.transsion.phonemaster}), which ships on every XOS device.
 * The dialog tries to open it directly; if it's absent (custom ROM / stripped build)
 * it falls back to the standard Battery settings screen.
 */
public final class XosGuideDialog {

    /** Package name of Infinix's Phone Master battery manager app. */
    private static final String PHONE_MASTER_PKG = "com.transsion.phonemaster";

    private XosGuideDialog() {}

    /**
     * Shows the guide if running on an XOS device. No-op on other brands.
     *
     * @param ctx    calling Activity context
     * @param onDone optional runnable called when the dialog is dismissed
     */
    public static void showIfNeeded(Context ctx, Runnable onDone) {
        if (!PermissionHelper.isXosDevice()) {
            if (onDone != null) onDone.run();
            return;
        }
        show(ctx, onDone);
    }

    /** Always shows the dialog regardless of device brand (for debug / manual trigger). */
    public static void show(Context ctx, Runnable onDone) {
        new AlertDialog.Builder(ctx)
            .setTitle("⚠️  Allow GameBooster to Stay Active")
            .setMessage(buildMessage())
            .setPositiveButton("Open Phone Manager", (d, w) -> {
                openPhoneMaster(ctx);
                if (onDone != null) onDone.run();
            })
            .setNegativeButton("Skip", (d, w) -> {
                if (onDone != null) onDone.run();
            })
            .setCancelable(false)
            .show();
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private static String buildMessage() {
        return "Your phone (XOS) aggressively stops background apps — "
            + "this will kill the boost mid-game.\n\n"
            + "Please do both steps in Phone Manager:\n\n"
            + "1️⃣  Auto-start Manager\n"
            + "     → Find GameBooster → turn ON\n\n"
            + "2️⃣  Power Saver  (or App Management)\n"
            + "     → Find GameBooster → set to No restrictions\n\n"
            + "Tap \"Open Phone Manager\" and we'll take you there.";
    }

    private static void openPhoneMaster(Context ctx) {
        // Try to launch Infinix Phone Master directly
        try {
            Intent launch = ctx.getPackageManager()
                .getLaunchIntentForPackage(PHONE_MASTER_PKG);
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                ctx.startActivity(launch);
                return;
            }
        } catch (Exception ignored) {}

        // Fallback: open standard battery optimization settings
        try {
            Intent fallback = new Intent(
                android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS);
            fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(fallback);
        } catch (Exception ignored) {}
    }
}
