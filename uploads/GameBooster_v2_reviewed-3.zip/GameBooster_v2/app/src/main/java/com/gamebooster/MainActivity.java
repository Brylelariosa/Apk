package com.gamebooster;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.net.VpnService;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.content.ContextCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Dashboard Activity for GameBooster.
 *
 * <h3>Bug fixes in this revision</h3>
 * <ul>
 *   <li><b>UI revert fix</b>: {@code onResume} no longer calls
 *       {@code syncBoostUi(isBoostServiceRunning())} unconditionally. It reads the
 *       SharedPreferences flag written by {@link BoostService#KEY_IS_RUNNING} which is
 *       set only after the null-package guard passes — so XOS killing the service
 *       during startup correctly shows "not boosting" rather than flickering.</li>
 *   <li><b>Battery optimization guard</b>: boost cannot start on XOS if battery
 *       optimization exemption is not granted — the service would be killed immediately
 *       anyway, so we block early and show the guide instead.</li>
 * </ul>
 *
 * <h3>New features (XOS / Infinix HOT 11)</h3>
 * <ul>
 *   <li>Battery Optimization permission card (4th card in 2×2 grid).</li>
 *   <li>{@link XosGuideDialog} on first launch and before boost on XOS devices.</li>
 *   <li>Thermal warning banner — appears when ≥ 80 % headroom.</li>
 *   <li>Low-RAM warning banner — appears when free RAM &lt; 600 MB.</li>
 * </ul>
 */
public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private static final String KEY_SELECTED_PKG   = "sel_pkg";
    private static final String KEY_SELECTED_LABEL = "sel_label";
    private static final String PREFS_BOOST        = "boost_service_state";
    private static final String PREFS_APP          = "gamebooster_app";
    private static final String KEY_XOS_GUIDE_SHOWN = "xos_guide_shown";

    // ── Views — Hero ──────────────────────────────────────────────────────────
    private ImageView    ivHeroIcon;
    private TextView     tvHeroGameName;
    private TextView     tvHeroStatus;
    private TextView     tvHeroTweaks;

    // ── Views — Warning banners ───────────────────────────────────────────────
    private View     bannerThermal;
    private TextView tvThermalMsg;
    private View     bannerRam;
    private TextView tvRamMsg;

    // ── Views — Permission cards (2×2 grid) ───────────────────────────────────
    private MaterialCardView cardPermUsage,      cardPermDnd;
    private MaterialCardView cardPermBrightness, cardPermBattery;
    private ImageView        ivPermUsage,        ivPermDnd;
    private ImageView        ivPermBrightness,   ivPermBattery;
    private TextView         tvPermUsage,        tvPermDnd;
    private TextView         tvPermBrightness,   tvPermBattery;

    // ── Views — Profiles ──────────────────────────────────────────────────────
    private MaterialCardView cardBattery, cardBalanced, cardMax;

    // ── Views — Stats + Options + Action ─────────────────────────────────────
    private View           statsSection;
    private TextView       tvStatRam, tvStatCpu, tvStatBattery;
    private SwitchCompat   switchVpn;
    private MaterialButton btnBoost;
    private MaterialButton btnPickGame;

    // ── State ─────────────────────────────────────────────────────────────────
    private AppInfo         selectedApp;
    private BoostProfile    selectedProfile;
    private boolean         isBoosting = false;
    private GamePreferences prefs;

    // ── Sound ─────────────────────────────────────────────────────────────────
    private BoostSoundManager soundManager;

    // ── Executors ─────────────────────────────────────────────────────────────
    private final ExecutorService iconExecutor = Executors.newSingleThreadExecutor();
    private final Handler         mainHandler  = new Handler(Looper.getMainLooper());
    private final Handler         statsHandler = new Handler(Looper.getMainLooper());

    // ── Activity result launchers ─────────────────────────────────────────────
    private ActivityResultLauncher<Intent> permLauncher;
    private ActivityResultLauncher<Intent> vpnConsentLauncher;
    private String pendingVpnPackage;

    // ── Broadcast receiver ────────────────────────────────────────────────────
    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context ctx, Intent intent) {
            if (intent == null || intent.getAction() == null) return;
            switch (intent.getAction()) {
                case BoostService.ACTION_STATE_CHANGED:
                    boolean running = intent.getBooleanExtra(
                        BoostService.EXTRA_IS_RUNNING, false);
                    syncBoostUi(running);
                    break;

                case BoostService.ACTION_THERMAL_WARNING:
                    float headroom = intent.getFloatExtra(
                        BoostService.EXTRA_THERMAL_HEADROOM, 0f);
                    showThermalBanner(headroom);
                    break;

                case BoostService.ACTION_THERMAL_OK:
                    hideThermalBanner();
                    break;

                case BoostService.ACTION_RAM_WARNING:
                    long freeMb = intent.getLongExtra(BoostService.EXTRA_RAM_FREE_MB, 0);
                    showRamBanner(freeMb);
                    break;

                case BoostService.ACTION_RAM_OK:
                    hideRamBanner();
                    break;
            }
        }
    };

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs        = new GamePreferences(this);
        soundManager = new BoostSoundManager(this);

        bindViews();
        setupActivityResultLaunchers();
        setupProfileCards();
        setupVpnSwitch();
        setupPickGameButton();

        if (savedInstanceState != null) {
            String pkg   = savedInstanceState.getString(KEY_SELECTED_PKG);
            String label = savedInstanceState.getString(KEY_SELECTED_LABEL);
            if (pkg != null) {
                AppInfo a = new AppInfo(label != null ? label : pkg, pkg);
                a.isFavorite = prefs.isFavorite(pkg);
                onAppSelected(a, false);
            }
        } else {
            restoreLastGame();
        }

        selectedProfile = prefs.getProfile();
        switchVpn.setChecked(prefs.isVpnEnabled());
        highlightProfileCard(selectedProfile);

        // Show XOS Auto-start guide on first-ever launch
        showXosGuideOnFirstLaunch();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updatePermissionCards();
        registerBroadcasts();

        // FIX: read the SharedPreferences flag written by the service AFTER its
        // null-package guard passes. This avoids the race where onResume fired
        // before the service had fully started and getRunningServices() returned
        // stale data — causing the UI to flip back to "not boosting".
        boolean serviceRunning = getBoostServiceFlag();
        if (isBoosting != serviceRunning) {
            // Only sync if our local state disagrees with reality
            syncBoostUi(serviceRunning);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        LocalBroadcastManager.getInstance(this).unregisterReceiver(receiver);
        stopStatsPolling();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        soundManager.release();
        iconExecutor.shutdownNow();
        mainHandler.removeCallbacksAndMessages(null);
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        if (selectedApp != null) {
            out.putString(KEY_SELECTED_PKG,   selectedApp.packageName);
            out.putString(KEY_SELECTED_LABEL, selectedApp.label);
        }
    }

    // ── View binding ──────────────────────────────────────────────────────────

    private void bindViews() {
        ivHeroIcon     = findViewById(R.id.iv_hero_icon);
        tvHeroGameName = findViewById(R.id.tv_hero_game_name);
        tvHeroStatus   = findViewById(R.id.tv_hero_status);
        tvHeroTweaks   = findViewById(R.id.tv_hero_tweaks);

        bannerThermal = findViewById(R.id.banner_thermal);
        tvThermalMsg  = findViewById(R.id.tv_thermal_msg);
        bannerRam     = findViewById(R.id.banner_ram);
        tvRamMsg      = findViewById(R.id.tv_ram_msg);

        // Permission cards — 2x2 grid
        cardPermUsage      = findViewById(R.id.card_perm_usage);
        cardPermDnd        = findViewById(R.id.card_perm_dnd);
        cardPermBrightness = findViewById(R.id.card_perm_brightness);
        cardPermBattery    = findViewById(R.id.card_perm_battery);
        ivPermUsage        = findViewById(R.id.iv_perm_usage);
        ivPermDnd          = findViewById(R.id.iv_perm_dnd);
        ivPermBrightness   = findViewById(R.id.iv_perm_brightness);
        ivPermBattery      = findViewById(R.id.iv_perm_battery);
        tvPermUsage        = findViewById(R.id.tv_perm_usage_label);
        tvPermDnd          = findViewById(R.id.tv_perm_dnd_label);
        tvPermBrightness   = findViewById(R.id.tv_perm_brightness_label);
        tvPermBattery      = findViewById(R.id.tv_perm_battery_label);

        cardBattery  = findViewById(R.id.card_profile_battery);
        cardBalanced = findViewById(R.id.card_profile_balanced);
        cardMax      = findViewById(R.id.card_profile_max);

        statsSection  = findViewById(R.id.section_live_stats);
        tvStatRam     = findViewById(R.id.tv_stat_ram);
        tvStatCpu     = findViewById(R.id.tv_stat_cpu);
        tvStatBattery = findViewById(R.id.tv_stat_battery);

        switchVpn   = findViewById(R.id.switch_vpn);
        btnBoost    = findViewById(R.id.btn_boost);
        btnPickGame = findViewById(R.id.btn_pick_game);

        btnBoost.setOnClickListener(v -> onBoostClicked());
    }

    // ── Activity result launchers ─────────────────────────────────────────────

    private void setupActivityResultLaunchers() {
        permLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            r -> updatePermissionCards());

        vpnConsentLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            r -> {
                if (r.getResultCode() == Activity.RESULT_OK && pendingVpnPackage != null)
                    launchVpnService(pendingVpnPackage);
                pendingVpnPackage = null;
            });
    }

    // ── Profile cards ─────────────────────────────────────────────────────────

    private void setupProfileCards() {
        cardBattery.setOnClickListener(v -> selectProfile(BoostProfile.BATTERY_SAVER));
        cardBalanced.setOnClickListener(v -> selectProfile(BoostProfile.BALANCED));
        cardMax.setOnClickListener(v -> selectProfile(BoostProfile.MAX_PERFORMANCE));
    }

    private void selectProfile(BoostProfile profile) {
        selectedProfile = profile;
        prefs.saveProfile(profile);
        highlightProfileCard(profile);
        updateHeroTweaks();
        if (profile == BoostProfile.MAX_PERFORMANCE && !switchVpn.isChecked()) {
            switchVpn.setChecked(true);
            prefs.saveVpnEnabled(true);
        }
    }

    private void highlightProfileCard(BoostProfile profile) {
        int selStroke = ContextCompat.getColor(this, R.color.boost_color);
        int norStroke = ContextCompat.getColor(this, R.color.card_stroke);
        int selBg     = ContextCompat.getColor(this, R.color.profile_selected_bg);
        int norBg     = ContextCompat.getColor(this, R.color.bg_card);
        resetProfileCard(cardBattery,  norStroke, norBg);
        resetProfileCard(cardBalanced, norStroke, norBg);
        resetProfileCard(cardMax,      norStroke, norBg);
        MaterialCardView sel = profile == BoostProfile.BATTERY_SAVER ? cardBattery
            : profile == BoostProfile.MAX_PERFORMANCE ? cardMax : cardBalanced;
        sel.setStrokeColor(selStroke);
        sel.setStrokeWidth(dpToPx(2));
        sel.setCardBackgroundColor(selBg);
    }

    private void resetProfileCard(MaterialCardView c, int stroke, int bg) {
        c.setStrokeColor(stroke);
        c.setStrokeWidth(dpToPx(1));
        c.setCardBackgroundColor(bg);
    }

    // ── VPN switch ────────────────────────────────────────────────────────────

    private void setupVpnSwitch() {
        switchVpn.setOnCheckedChangeListener((b, c) -> prefs.saveVpnEnabled(c));
    }

    // ── App picker ────────────────────────────────────────────────────────────

    private void setupPickGameButton() {
        btnPickGame.setOnClickListener(v -> openAppPicker());
    }

    private void openAppPicker() {
        AppPickerBottomSheet sheet = AppPickerBottomSheet.newInstance();
        sheet.setOnAppPicked(app -> onAppSelected(app, true));
        sheet.show(getSupportFragmentManager(), AppPickerBottomSheet.TAG);
    }

    private void onAppSelected(AppInfo app, boolean playSound) {
        selectedApp = app;
        prefs.saveLastGame(app);
        tvHeroGameName.setText(app.label);
        tvHeroTweaks.setVisibility(View.VISIBLE);
        updateHeroTweaks();
        if (playSound) soundManager.playGameSelected();

        if (app.icon != null) {
            ivHeroIcon.setImageDrawable(app.icon);
        } else {
            ivHeroIcon.setImageResource(R.drawable.ic_gamepad);
            final String pkg = app.packageName;
            iconExecutor.execute(() -> {
                Drawable icon = null;
                try { icon = getPackageManager().getApplicationIcon(pkg); }
                catch (Exception ignored) {}
                final Drawable fi = icon;
                mainHandler.post(() -> {
                    if (selectedApp != null && selectedApp.packageName.equals(pkg)) {
                        if (fi != null) { app.icon = fi; ivHeroIcon.setImageDrawable(fi); }
                    }
                });
            });
        }
    }

    private void restoreLastGame() {
        String pkg = prefs.getLastPackage(), label = prefs.getLastLabel();
        if (pkg != null) {
            AppInfo a = new AppInfo(label != null ? label : pkg, pkg);
            a.isFavorite = prefs.isFavorite(pkg);
            onAppSelected(a, false);
        }
    }

    // ── Boost control ─────────────────────────────────────────────────────────

    private void onBoostClicked() {
        if (isBoosting) stopBoosting();
        else            startBoosting();
    }

    private void startBoosting() {
        // 1. Usage access is mandatory
        if (!PermissionHelper.hasUsageAccess(this)) {
            showSettingsDialog("Usage Access Required",
                "GameBooster needs Usage Access to detect when your game exits.\n\n"
                    + "Tap OK → enable GameBooster under Usage access.",
                PermissionHelper.usageAccessIntent());
            return;
        }

        // 2. On XOS, battery optimization exemption is effectively mandatory.
        //    Without it the service is killed within seconds of starting.
        if (PermissionHelper.isXosDevice()
                && !PermissionHelper.isBatteryOptimizationIgnored(this)) {
            new AlertDialog.Builder(this)
                .setTitle("⚠️  Battery Restriction Active")
                .setMessage("XOS will kill the boost within seconds because GameBooster "
                    + "is battery-restricted.\n\n"
                    + "Tap \"Allow\" to exempt it, then start the boost again.")
                .setPositiveButton("Allow", (d, w) ->
                    permLauncher.launch(
                        PermissionHelper.batteryOptimizationIntent(this)))
                .setNegativeButton("Boost Anyway", (d, w) -> doStartBoosting())
                .show();
            return;
        }

        doStartBoosting();
    }

    private void doStartBoosting() {
        if (selectedApp == null) {
            toast("Tap \"Select Game\" to choose a game first");
            return;
        }
        if (selectedProfile.enableDnd && !PermissionHelper.hasNotificationPolicyAccess(this))
            toast("DND access not granted — silence mode will be skipped");
        if (selectedProfile.enableMaxBrightness && !PermissionHelper.canWriteSettings(this))
            toast("Write Settings not granted — brightness boost will be skipped");

        startForegroundService(new Intent(this, BoostService.class)
            .putExtra(BoostService.EXTRA_PACKAGE, selectedApp.packageName)
            .putExtra(BoostService.EXTRA_LABEL,   selectedApp.label)
            .putExtra(BoostService.EXTRA_PROFILE,  selectedProfile.name()));

        if (selectedProfile.enableVpn && switchVpn.isChecked())
            requestVpnConsent(selectedApp.packageName);

        // Optimistic UI update — the service will confirm via broadcast
        syncBoostUi(true);
        soundManager.playBoostOn();
        toast("⚡ Boost started — " + selectedProfile.displayName);
    }

    private void stopBoosting() {
        stopService(new Intent(this, BoostService.class));
        if (BoostVpnService.isRunning)
            startService(new Intent(this, BoostVpnService.class)
                .setAction(BoostVpnService.ACTION_STOP));
        syncBoostUi(false);
        soundManager.playBoostOff();
        toast("Boost stopped");
    }

    // ── VPN consent ───────────────────────────────────────────────────────────

    private void requestVpnConsent(String pkg) {
        Intent prepare = VpnService.prepare(this);
        if (prepare != null) { pendingVpnPackage = pkg; vpnConsentLauncher.launch(prepare); }
        else launchVpnService(pkg);
    }

    private void launchVpnService(String pkg) {
        startService(new Intent(this, BoostVpnService.class)
            .putExtra(BoostVpnService.EXTRA_GAME_PACKAGE, pkg));
    }

    // ── UI sync ───────────────────────────────────────────────────────────────

    private void syncBoostUi(boolean boosting) {
        isBoosting = boosting;
        if (boosting) {
            btnBoost.setText(R.string.btn_stop);
            btnBoost.setBackgroundTintList(
                ContextCompat.getColorStateList(this, R.color.stop_color));
            tvHeroStatus.setText(R.string.status_active);
            tvHeroStatus.setTextColor(ContextCompat.getColor(this, R.color.perm_ok));
            statsSection.setVisibility(View.VISIBLE);
            startStatsPolling();
        } else {
            btnBoost.setText(R.string.btn_boost);
            btnBoost.setBackgroundTintList(
                ContextCompat.getColorStateList(this, R.color.boost_color));
            tvHeroStatus.setText(
                selectedApp != null ? R.string.status_ready : R.string.status_no_game);
            tvHeroStatus.setTextColor(
                ContextCompat.getColor(this, R.color.text_secondary));
            statsSection.setVisibility(View.GONE);
            stopStatsPolling();
            hideThermalBanner();
            hideRamBanner();
        }
    }

    // ── Permission cards ──────────────────────────────────────────────────────

    private void updatePermissionCards() {
        setPermCard(cardPermUsage, ivPermUsage, tvPermUsage,
            PermissionHelper.hasUsageAccess(this),
            getString(R.string.perm_usage_short),
            PermissionHelper.usageAccessIntent());

        setPermCard(cardPermDnd, ivPermDnd, tvPermDnd,
            PermissionHelper.hasNotificationPolicyAccess(this),
            getString(R.string.perm_dnd_short),
            PermissionHelper.notificationPolicyIntent());

        setPermCard(cardPermBrightness, ivPermBrightness, tvPermBrightness,
            PermissionHelper.canWriteSettings(this),
            getString(R.string.perm_brightness_short),
            PermissionHelper.writeSettingsIntent(this));

        setPermCard(cardPermBattery, ivPermBattery, tvPermBattery,
            PermissionHelper.isBatteryOptimizationIgnored(this),
            getString(R.string.perm_battery_short),
            PermissionHelper.batteryOptimizationIntent(this));
    }

    private void setPermCard(MaterialCardView card, ImageView icon, TextView label,
                              boolean granted, String text, Intent intent) {
        int okColor    = ContextCompat.getColor(this, R.color.perm_ok);
        int warnColor  = ContextCompat.getColor(this, R.color.perm_warn);
        int okStroke   = ContextCompat.getColor(this, R.color.perm_ok_stroke);
        int warnStroke = ContextCompat.getColor(this, R.color.perm_warn_stroke);
        label.setText(text);
        if (granted) {
            icon.setImageResource(R.drawable.ic_check_circle);
            icon.setColorFilter(okColor);
            card.setStrokeColor(okStroke);
            card.setOnClickListener(null);
        } else {
            icon.setImageResource(R.drawable.ic_warning);
            icon.setColorFilter(warnColor);
            card.setStrokeColor(warnStroke);
            card.setOnClickListener(v -> permLauncher.launch(intent));
        }
    }

    // ── Thermal banner ────────────────────────────────────────────────────────

    private void showThermalBanner(float headroom) {
        int pct = (int)(headroom * 100);
        tvThermalMsg.setText("🌡️  Phone heating up (" + pct + "% — throttle risk). "
            + "Consider a short break to cool down.");
        bannerThermal.setVisibility(View.VISIBLE);
    }

    private void hideThermalBanner() {
        if (bannerThermal != null) bannerThermal.setVisibility(View.GONE);
    }

    // ── RAM banner ────────────────────────────────────────────────────────────

    private void showRamBanner(long freeMb) {
        tvRamMsg.setText("💾  Low RAM: " + freeMb + " MB free. "
            + "Close background apps to keep the boost stable.");
        bannerRam.setVisibility(View.VISIBLE);
    }

    private void hideRamBanner() {
        if (bannerRam != null) bannerRam.setVisibility(View.GONE);
    }

    // ── XOS first-launch guide ────────────────────────────────────────────────

    private void showXosGuideOnFirstLaunch() {
        if (!PermissionHelper.isXosDevice()) return;
        SharedPreferences sp = getSharedPreferences(PREFS_APP, MODE_PRIVATE);
        if (sp.getBoolean(KEY_XOS_GUIDE_SHOWN, false)) return;
        sp.edit().putBoolean(KEY_XOS_GUIDE_SHOWN, true).apply();
        // Small delay so the UI is fully loaded before the dialog appears
        mainHandler.postDelayed(
            () -> XosGuideDialog.showIfNeeded(this, null), 800L);
    }

    // ── Hero tweaks count ─────────────────────────────────────────────────────

    private void updateHeroTweaks() {
        if (selectedProfile == null) return;
        int n = selectedProfile.activeTweakCount();
        tvHeroTweaks.setText(n + " optimization" + (n == 1 ? "" : "s") + " active");
    }

    // ── Live stats ────────────────────────────────────────────────────────────

    private final Runnable statsRunnable = this::refreshStats;

    private void startStatsPolling() {
        statsHandler.removeCallbacks(statsRunnable);
        statsHandler.post(statsRunnable);
    }

    private void stopStatsPolling() {
        statsHandler.removeCallbacks(statsRunnable);
    }

    private void refreshStats() {
        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        long usedMb  = (mi.totalMem - mi.availMem) / (1024 * 1024);
        long totalMb = mi.totalMem / (1024 * 1024);
        tvStatRam.setText(usedMb + " / " + totalMb + " MB");

        IntentFilter f = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        Intent bat    = registerReceiver(null, f);
        int lvl       = bat != null ? bat.getIntExtra(BatteryManager.EXTRA_LEVEL,  -1) : -1;
        int scale     = bat != null ? bat.getIntExtra(BatteryManager.EXTRA_SCALE,  -1) : -1;
        tvStatBattery.setText((lvl >= 0 && scale > 0)
            ? ((int)(lvl * 100f / scale)) + "%" : "—");

        int pressurePct = (int)(100 - (mi.availMem * 100.0 / mi.totalMem));
        tvStatCpu.setText(pressurePct + "%");

        if (isBoosting) statsHandler.postDelayed(statsRunnable, 2_000L);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    /** Reads the SharedPreferences flag the service writes — reliable across processes. */
    private boolean getBoostServiceFlag() {
        return getSharedPreferences(PREFS_BOOST, MODE_PRIVATE)
            .getBoolean(BoostService.KEY_IS_RUNNING, false);
    }

    private void registerBroadcasts() {
        IntentFilter f = new IntentFilter();
        f.addAction(BoostService.ACTION_STATE_CHANGED);
        f.addAction(BoostService.ACTION_THERMAL_WARNING);
        f.addAction(BoostService.ACTION_THERMAL_OK);
        f.addAction(BoostService.ACTION_RAM_WARNING);
        f.addAction(BoostService.ACTION_RAM_OK);
        LocalBroadcastManager.getInstance(this).registerReceiver(receiver, f);
    }

    private void showSettingsDialog(String title, String msg, Intent intent) {
        new AlertDialog.Builder(this)
            .setTitle(title).setMessage(msg)
            .setPositiveButton("Open Settings", (d, w) -> permLauncher.launch(intent))
            .setNegativeButton("Cancel", null)
            .show();
    }

    private void toast(String msg) { Toast.makeText(this, msg, Toast.LENGTH_LONG).show(); }

    private int dpToPx(int dp) {
        return (int)(dp * getResources().getDisplayMetrics().density + 0.5f);
    }
}
