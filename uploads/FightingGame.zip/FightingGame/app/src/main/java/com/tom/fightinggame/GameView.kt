package com.tom.fightinggame

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView

class GameView(context: Context) : SurfaceView(context), SurfaceHolder.Callback, Runnable {

    private var gameThread: Thread? = null
    @Volatile private var running = false

    private var screenWidth = 0
    private var screenHeight = 0
    private val groundYFraction = 0.74f

    private var player: Fighter? = null
    private var cpu: Fighter? = null
    private val cpuBrain = CpuBrain()
    private var touchControls: TouchControls? = null
    private var matchManager: MatchManager? = null

    private var lastFrameTimeNanos = 0L

    init {
        holder.addCallback(this)
        isFocusable = true
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        running = true
        gameThread = Thread(this, "GameLoopThread")
        gameThread?.start()
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        screenWidth = width
        screenHeight = height
        setupMatch()
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        running = false
        try {
            gameThread?.join()
        } catch (e: InterruptedException) {
        }
        gameThread = null
    }

    private fun setupMatch() {
        val groundY = screenHeight * groundYFraction
        val playerStartX = screenWidth * 0.25f
        val cpuStartX = screenWidth * 0.75f

        val newPlayer = Fighter(FighterArchetype.RONIN, playerStartX, groundY, isPlayerOne = true)
        val newCpu = Fighter(FighterArchetype.BRAWLER, cpuStartX, groundY, isPlayerOne = false)
        player = newPlayer
        cpu = newCpu
        touchControls = TouchControls(screenWidth, screenHeight)
        matchManager = MatchManager(newPlayer, newCpu, playerStartX, cpuStartX)
    }

    fun pause() {
        running = false
        try {
            gameThread?.join()
        } catch (e: InterruptedException) {
        }
        gameThread = null
    }

    fun resume() {
        if (gameThread == null && holder.surface.isValid) {
            running = true
            gameThread = Thread(this, "GameLoopThread")
            gameThread?.start()
        }
    }

    override fun run() {
        lastFrameTimeNanos = System.nanoTime()
        while (running) {
            val frameStart = System.nanoTime()
            var deltaSeconds = (frameStart - lastFrameTimeNanos) / 1_000_000_000f
            lastFrameTimeNanos = frameStart
            if (deltaSeconds > 0.05f) deltaSeconds = 0.05f

            update(deltaSeconds)

            val canvas = holder.lockCanvas()
            if (canvas != null) {
                try {
                    draw(canvas)
                } finally {
                    holder.unlockCanvasAndPost(canvas)
                }
            }

            val frameMillis = (System.nanoTime() - frameStart) / 1_000_000
            val sleepMillis = 16L - frameMillis
            if (sleepMillis > 0) {
                try {
                    Thread.sleep(sleepMillis)
                } catch (e: InterruptedException) {
                }
            }
        }
    }

    private fun update(dt: Float) {
        val p = player ?: return
        val c = cpu ?: return
        val mm = matchManager ?: return
        val tc = touchControls ?: return

        if (mm.state == MatchState.FIGHTING) {
            p.applyIntent(tc.currentIntent())
            c.applyIntent(cpuBrain.decide(c, p, dt))

            p.update(dt, c)
            c.update(dt, p)

            CombatResolver.resolve(p, c)
            CombatResolver.resolve(c, p)
        }

        mm.update(dt)

        // Always drain the restart flag; only act on it once the match is over.
        val restartTap = tc.consumeRestartTap()
        if (mm.state == MatchState.MATCH_OVER && restartTap) {
            setupMatch()
        }
    }

    private fun draw(canvas: Canvas) {
        canvas.drawColor(Color.rgb(28, 26, 40))
        drawStage(canvas)
        player?.draw(canvas)
        cpu?.draw(canvas)
        matchManager?.drawHud(canvas, screenWidth, screenHeight)
        touchControls?.draw(canvas)
    }

    private fun drawStage(canvas: Canvas) {
        val groundY = screenHeight * groundYFraction
        val floorPaint = Paint().apply { color = Color.rgb(48, 40, 58) }
        canvas.drawRect(0f, groundY, screenWidth.toFloat(), screenHeight.toFloat(), floorPaint)
        val linePaint = Paint().apply { color = Color.rgb(90, 80, 110); strokeWidth = 4f }
        canvas.drawLine(0f, groundY, screenWidth.toFloat(), groundY, linePaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        touchControls?.onTouchEvent(event)
        return true
    }
}
