# VolumeTile audit (1.6 -> 1.7), updated for 2.0 and 2.1

## Update for 2.1 (VolumeTile-7 -> 8)

**Request:** clear the cache of other apps, disabled ones included, automatically at a time the
person sets - without root or Shizuku.

**Why it is done by tapping Settings:** the calls that clear another app's cache
(`CLEAR_APP_CACHE`, `DELETE_CACHE_FILES`) are for the system only. The public
`StorageManager.allocateBytes` only frees cache above a reserved amount (about 1 GB by default), so
on a phone with a few hundred MB of cache it clears nothing. The accessibility service that is
already in the app can open each app's App info page, tap Storage, tap Clear cache - the same as a
person - and App info opens for disabled apps too.

| Change | Where |
|---|---|
| `CacheCleaner`: one app at a time, App info > Storage & cache > Clear cache, polled every 200 ms. Each app has a 10 s limit; the run has 25 min. A window that was on screen before a navigation is ignored until another replaces it, so a stale page is never read as the new one. Only the Storage entry and the exact "Clear cache" label are ever tapped. Labels come from Settings' own string resources, English as backup. | `CacheCleaner` |
| With Usage access, per-app cache sizes are read first (on a worker thread) and apps with none are skipped. Without it every installed app is visited. | `CacheCleaner.buildPlan`, `cacheSizes` |
| Dimmed cover with progress and Stop; keeps the screen on; swallows stray touches; it is also the visible window that lets the service start Settings from the background (Android 10+). | `CacheOverlay`, `overlay_cache_clear.xml` |
| Daily alarm (exact when allowed, otherwise inexact), booked again on boot, update, clock and zone change, service connect and any change in the app. A run that comes due while the phone is locked waits for unlock (`USER_PRESENT`/`SCREEN_ON`, then 5 s); a run waiting more than 12 h is dropped. | `CacheScheduler`, `CacheAlarmReceiver`, `SystemActionService.runPendingCacheClear` |
| `CLEAR_CACHE` action: chooser entry, bubble-arc pick, tile, "Clear cache now" | `SystemAction`, `ActionTiles`, `VolumeControlActivity` |
| Settings section: switch, time picker (asked for the first time the switch goes on), last result, Usage access button | `VolumeControlActivity`, `activity_volume_control.xml`, `CachePrefs` |
| Result notification and toast | `CacheNotice`, `SystemActionService.onCacheFinished` |

**Privacy / least privilege - changed:** `canRetrieveWindowContent` is now `"true"`, with
`flagReportViewIds` and `flagIncludeNotImportantViews`. The only code that reads a window is
`CacheCleaner`, and it reads only the Settings window and only while a run is going. While a run
goes the service asks for window-state events of every app (so it can follow Settings); `applyProtection`
narrows them back to the protected apps when it ends, and does nothing while a run is on. The service
description shown in Accessibility settings was rewritten to say all this. New permissions:
`QUERY_ALL_PACKAGES`, `PACKAGE_USAGE_STATS` (optional, the person's Usage access switch),
`RECEIVE_BOOT_COMPLETED`, `SCHEDULE_EXACT_ALARM`.

**Known limits, stated plainly**

- **Not run.** No Gradle, Android SDK or device here, and the Settings pages could not be looked at.
  The wording of the Storage entry and the Clear cache button on this phone's Settings (Infinix, XOS) is
  assumed to be the usual one. If it is not, the run stops after at most 8 apps with "Couldn't find
  the Storage screen in Settings. It showed: ..." followed by the first texts on the screen.
- It needs an awake, unlocked phone: Settings cannot be driven from a lock screen, and nothing here
  wakes or unlocks the phone.
- A run on a phone without Usage access visits every installed app and can take several minutes.
- The alarm may slip by some minutes where exact alarms are not allowed (Android 12+).
- If the system has stopped the service, a due run waits (a notice says so) until it is switched off and on.
- Apps that keep downloaded files in their cache folder will fetch them again.

**What to try first on the phone**

1. Install, switch the accessibility service back on (a new install starts with it off), open the app.
2. Tap **Clear cache now** with the phone unlocked. Watch the first app: Settings should open, the
   Storage page should appear, and the cover's counter should move.
3. If it stops with "Couldn't find the Storage screen...", send the texts in the message.
4. Allow Usage access, run again: it should visit far fewer apps and say how much it freed.
5. Switch **Auto clear cache** on, pick a time two minutes ahead and leave the phone unlocked. Then
   again with the screen locked: it should wait, and start a few seconds after unlocking.
6. Restart the phone and check the run still happens the next day.

**How it was checked:** by hand, plus scripts for XML well-formedness, every `R.*` / `@...` reference,
manifest class names, bracket balance, nested comments and the exhaustive `when` over
`SystemAction`. **Not compiled and not run**, as for 2.0: the pipeline build is the first compile of
the 2.1 edits.

## Update for 2.0 (VolumeTile-6 -> 7)

**Trigger:** GCash would not open while the accessibility service was on.

**Cause (from GCash's own Device Security help page):** GCash lets only accessibility services from
its allow-list stay enabled while it runs. Volume Tile is not on it. Nothing in this app can
legitimately change that, so the fix is to have the service off while GCash is open.

**What changed**

| Change | Where |
|---|---|
| The service switches itself off (`disableSelf()`) when a protected app opens. It asks the system for `TYPE_WINDOW_STATE_CHANGED` events of the listed packages only (set at run time with `setServiceInfo`, GCash by default) and ignores everything else. With the setting off, or an empty list, it requests no events, as before. | `SystemActionService.applyProtection` / `onAccessibilityEvent` / `pause`, `ProtectedApps` |
| **Service** tile and **Pause service** chooser entry: pause first, which never loses the race with GCash's own start-up check | `ServiceTileService`, `SystemAction.PAUSE_SERVICE` |
| Paused state: flag + notification (Resume button when the permission below is granted); banner and greyed tiles say "paused" | `ProtectedApps.isPaused`, `PauseNotice`, `ResumeReceiver`, `ActionTiles`, `VolumeControlActivity` |
| One-tap resume and self-heal of a stopped service, via `WRITE_SECURE_SETTINGS` (granted once with adb). Other enabled accessibility services are carried over untouched; without the permission every caller falls back to Accessibility settings. This is open item 1 of the 1.7 list, further down. | `ServiceSwitch` |
| Louder / Quieter / Mute tiles, no accessibility needed (1.7 open item 5, in part) | `ActionTiles` |
| `POST_NOTIFICATIONS` declared and asked for once (1.7 open item 4) | manifest, `VolumeControlActivity` |
| `build.yml` builds a debug APK its upload step can find (1.7 open item 8) | `.github/workflows/build.yml` |
| Service description in Settings says it notices when GCash opens | `strings.xml` |

**Known limit, stated plainly:** an accessibility event reaches the service only after the other app
has created a window, so GCash's very first check can run before the service pauses. The first open
after the service was on may still be refused; the second works. Pausing first (tile or menu) avoids
it. Whether GCash checks that early is not something this environment could observe.

**Privacy / least privilege:** still `canRetrieveWindowContent="false"`; the only events requested are
window-state changes of the packages the person lists, and only the package name is looked at.

**How it was checked:** by hand, plus scripts for XML well-formedness, every `R.string` /
`R.drawable` / `R.id` / `@string` / `@drawable` reference, manifest class names, brace balance and the
exhaustive `when` over `SystemAction`. **Not compiled and not run:** the environment had no Gradle or
Android SDK, so the pipeline build is the first compile of the 2.0 edits.

**To try on the phone**

1. GCash with the service on, protection on (default): open it; if refused, open it again. Then the
   Service tile should read "Paused, tap to resume" and the notice should be showing.
2. Service tile while running: pauses at once. Open GCash: it should open on the first try.
3. Service tile while paused: opens Accessibility settings (no permission) or switches the service on
   in place (permission granted). The bubble and nav-bar button come back.
4. After the adb grant (and USB debugging switched off again): a greyed Screenshot tile and the
   notification's Resume button switch the service on without opening Settings.
5. Louder / Quieter / Mute tiles work with the service paused.
6. With another accessibility service on (TalkBack, say): pausing and resuming must leave it on.

## Open items after 2.0

1. **Resume by itself when GCash is closed.** Today it stays paused until told. A timer is a bad idea
   (it could re-enable the service in the middle of a payment); the sound options are a foreground
   watcher that uses Usage access to see GCash leave the foreground, or resuming on screen-off.
2. **Service health line in the app** (running / keep-alive active / battery exempt): `KeepAlive.start`
   still only logs a refused `startForeground`.
3. Items 3, 6, 7 and 9 of the 1.7 list below are unchanged; the ringer-mode action and hold-to-repeat
   on the arc (part of item 5) are still open.

The rest of this file is the 1.7 audit as it was written.

**Scope:** every Kotlin file (14 files, about 2.7k lines), the manifest, the accessibility config, all
resources, the Gradle and CI files and the README of `VolumeTile-3.zip`.

**How:** read by hand, plus scripted cross-checks of every `R.string` / `R.drawable` / `R.id` reference
(nothing missing, nothing unused) and of XML well-formedness. **Not compiled and not run:** the
environment had no Gradle or Android SDK, so the pipeline build is the first compile of the 1.7 edits.
They are small and mechanical, and every changed file was diff-reviewed.

## Verdict: CPU and lag

Idle cost is effectively zero, and nothing in the code can cause sustained CPU use.

- `res/xml/system_action_service.xml` subscribes to no event types, so the system delivers nothing to
  the service while idle (2.1: window content is read only during a cache clean-up, see its update above).
  `onAccessibilityEvent` only looks at protected apps.
- No timers, polling, wake locks or alarms. Every `Handler` post is one-shot (screenshot 250-800 ms,
  lock 160 ms, chooser auto-dismiss 15 s) and is removed in `release()`.
- The foreground notification is static; the foreground service does no work.
- Work happens only during a gesture: the arc animation (about 0.3-0.7 s per hold, GPU-accelerated,
  five icons) and dragging the bubble.
- The app's only repeating task is `VolumeControlActivity.watchService` (every 2 s), and only while the
  app is on screen and the service is on but not connected.
- One cost no code can remove: while any accessibility service is bound, the framework tells every app
  that accessibility is on, and a few UI frameworks do extra work when they hear that. A service with no
  event types is the cheapest way to be one.

To confirm on the phone (menu names vary by maker): Battery usage for Volume Tile should read about
0%, and Developer options > Running services should show it with a tiny RAM figure.

## Fixed in 1.7

| Finding | Where | Change |
|---|---|---|
| Bubble touch handling, the hold-to-open runnable and the arc's frame callback ran outside `guarded`; an exception there would crash the process, which the README ties to the "service dead until toggled" symptom | `FloatingBubble.kt`, `ArcMenu.kt` (`Tween`) | Wrapped. A failure drops the gesture or ends the animation; a closing arc still removes its window |
| A refused `startForeground()` (Android 12+ restricts background starts) was never retried | `VolumeControlActivity.onResume` | Re-asserts keep-alive each time the app is opened |
| Registering the nav-bar button was unguarded in `onServiceConnected`, and could stop keep-alive and the bubble from starting | `SystemActionService.kt` | Wrapped; a failure is logged and start-up continues |
| One window move per touch event while dragging (a window-manager round trip each) | `FloatingBubble.dragTo` | At most one move per frame, none when unchanged |
| On Android 8.x a saved action the phone can't run made its picker show "Nothing", and the picker then wrote "Nothing" back over the saved choice | `VolumeControlActivity.setupBubbleSection` | Writes only when the person changes a picker |
| Docs said the Volume tile opens the slider panel; it pops up the system panel | README, `VolumeControlActivity` KDoc | Corrected |
| Accessibility settings entry had no gear to the app; sliders had no spoken names | `system_action_service.xml`, layout | `settingsActivity` added; `contentDescription` on the four SeekBars |

## Added in 1.7

**Louder / Quieter / Mute** (`SystemAction.VOLUME_UP/DOWN/MUTE`): one step on the media volume, or mute
toggle, with the system volume panel showing the result. The app exists to replace a broken volume
button, but until now the only volume action was "open the panel". They appear in the chooser and in
the arc pickers, need no accessibility service, and launch nothing. Version 7 / 1.6 -> 8 / 1.7.

## Open items as of 1.7 (items 1, 4, 5 in part and 8 are done in 2.0, see above)

1. **Self-heal after the system drops the service.** Only Settings can rebind a dead accessibility service,
   so today the person has to toggle it. With a one-time `adb shell pm grant com.volumetile.app
   android.permission.WRITE_SECURE_SETTINGS`, the app could flip its own entry in
   `Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES` from the tile or the app when `isStalled()` is true. Optional and inert
   without the grant. Left out because it writes a system setting that also lists the person's other
   accessibility services, and could not be tested here.
2. **Service health line in the app** (running / keep-alive active / battery exempt). `KeepAlive.start`
   catches a refused `startForeground` but only logs it; it could record that and the app could show it.
3. **Screen metrics.** `resources.displayMetrics` plus fixed 24 dp / 56 dp safe zones are approximate on
   tall status bars, foldables and multi-window. `WindowManager.currentWindowMetrics` (API 30+) with the
   real insets would be exact.
4. **POST_NOTIFICATIONS** is not declared. On Android 13+ the foreground service still runs, but its
   notification may be hidden from the shade. Not needed for keep-alive; needed if you want to see or
   manage the notification.
5. **Tiles for Louder / Quieter**, a ringer-mode (sound / vibrate / silent) action, and hold-to-repeat on
   the arc.
6. **Per-app bubble hiding** (for example in a full-screen game). Needs the
   `typeWindowStateChanged` event, which gives up the zero-event design and lets the service see package
   names. Only worth it if the bubble ever gets in the way.
7. **Unit tests for `ArcLayout`.** It is pure Kotlin geometry (`indexAt`, overflow and turn search), so
   it can be tested on the JVM with no Android.
8. **`build.yml`** builds an unsigned release APK (the pipeline signs), so its upload step finds no
   `app-release.apk`. Fine while the pipeline is what builds this; point the path at `*.apk` or build
   debug if it is ever used on its own.
9. `allowBackup="true"` backs up only the two small preference files (`keep_alive`, `bubble`); harmless, but Android 12+ lint
   wants `dataExtractionRules` for it.

## Checked and fine

- Exported components: all four tiles and the accessibility service are protected by their
  `BIND_*` permissions; the launcher activity reads no extras. No `INTERNET` permission.
- Least privilege: no gestures. As of 2.1 `canRetrieveWindowContent="true"`, for the cache clean-up only (see the 2.1 update).
- `PendingIntent`s are `FLAG_IMMUTABLE`; the notification is `VISIBILITY_SECRET`, minimum importance.
- Every `addView` / `removeView` / `updateViewLayout` is inside a `try`; window leaks on teardown are
  handled (`release()`, `detach()`, `dismissNow()`).
- Preferences store enum names through `name()` with a default fallback; nothing reflective for R8 to break.
- AGP 8.6.1, Kotlin 1.9.24, Gradle 8.9, JDK 17, compileSdk 35 and appcompat 1.7.0 are mutually consistent.
- `when (action)` over `SystemAction` in `perform()` is the only exhaustive switch; it is updated.
