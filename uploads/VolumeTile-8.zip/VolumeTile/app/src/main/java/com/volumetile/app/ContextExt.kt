package com.volumetile.app

import android.content.Context
import android.media.AudioManager
import android.widget.Toast

/** Short toast from any Context - services included. */
fun Context.toast(resId: Int) {
    Toast.makeText(this, resId, Toast.LENGTH_SHORT).show()
}

/**
 * Pops up the system volume panel - the one the hardware buttons bring up - by nudging
 * the media stream with ADJUST_SAME, which changes nothing. No activity is launched, so
 * whatever is in the foreground (a game, say) keeps running.
 */
fun Context.showSystemVolumePanel() {
    val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
    audioManager.adjustStreamVolume(
        AudioManager.STREAM_MUSIC,
        AudioManager.ADJUST_SAME,
        AudioManager.FLAG_SHOW_UI
    )
}

/**
 * The level a silent media stream is lifted to when the person asks for sound again: a third
 * of the way up, and never less than 1. One tap from silence has to be enough to hear
 * something - level 1 of 15 is close to inaudible on a phone speaker.
 */
private fun AudioManager.audibleLevel(): Int =
    maxOf(1, getStreamMaxVolume(AudioManager.STREAM_MUSIC) / 3)

/**
 * Runs the Louder / Quieter action on the media volume and lets the system volume panel show
 * the new level. No activity is launched.
 *
 * When a level was chosen for the action in the app ([VolumeLevels]) it unmutes if needed and
 * goes straight to that level. Otherwise it moves one step, the way the hardware keys do, and
 * will not leave the phone silent by accident:
 *  - Quieter stops at level 1. Mute is the way to silence the phone on purpose.
 *  - Louder unmutes first, and a volume sitting at 0 is lifted to [audibleLevel] instead of
 *    one barely-there step.
 */
fun Context.stepMediaVolume(up: Boolean) {
    val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
    val stream = AudioManager.STREAM_MUSIC

    val chosen = if (up) VolumeLevels.louder(this) else VolumeLevels.quieter(this)
    if (chosen > 0) {
        if (audioManager.isStreamMute(stream)) {
            audioManager.adjustStreamVolume(stream, AudioManager.ADJUST_UNMUTE, 0)
        }
        val level = chosen.coerceIn(1, audioManager.getStreamMaxVolume(stream))
        audioManager.setStreamVolume(stream, level, AudioManager.FLAG_SHOW_UI)
        return
    }

    if (up) {
        if (audioManager.isStreamMute(stream)) {
            audioManager.adjustStreamVolume(stream, AudioManager.ADJUST_UNMUTE, 0)
        }
        if (audioManager.getStreamVolume(stream) == 0) {
            audioManager.setStreamVolume(stream, audioManager.audibleLevel(), AudioManager.FLAG_SHOW_UI)
        } else {
            audioManager.adjustStreamVolume(stream, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
        }
    } else {
        // getStreamVolume() reads 0 while the stream is muted, so a muted phone also takes the
        // ADJUST_SAME branch and simply stays as it is, with the panel showing.
        val direction =
            if (audioManager.getStreamVolume(stream) > 1) AudioManager.ADJUST_LOWER
            else AudioManager.ADJUST_SAME
        audioManager.adjustStreamVolume(stream, direction, AudioManager.FLAG_SHOW_UI)
    }
}

/**
 * Mutes the media volume, or brings it back when it is already muted; the volume panel shows
 * the result. It asks whether the stream is muted and then mutes or unmutes explicitly, instead
 * of flipping a switch it cannot see, and when the sound comes back at level 0 it is lifted to
 * [audibleLevel] so "unmuted" never means "still silent".
 */
fun Context.toggleMediaMute() {
    val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
    val stream = AudioManager.STREAM_MUSIC
    if (!audioManager.isStreamMute(stream)) {
        audioManager.adjustStreamVolume(stream, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
        return
    }
    audioManager.adjustStreamVolume(stream, AudioManager.ADJUST_UNMUTE, 0)
    if (audioManager.getStreamVolume(stream) == 0) {
        audioManager.setStreamVolume(stream, audioManager.audibleLevel(), AudioManager.FLAG_SHOW_UI)
    } else {
        audioManager.adjustStreamVolume(stream, AudioManager.ADJUST_SAME, AudioManager.FLAG_SHOW_UI)
    }
}

/** The media volume as a whole percentage, 0 to 100 (what the Volume tile shows). */
fun Context.mediaVolumePercent(): Int {
    val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
    val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
    return if (max > 0) audioManager.getStreamVolume(AudioManager.STREAM_MUSIC) * 100 / max else 0
}

/** Density-independent pixels to whole screen pixels. */
fun Context.dpToPx(dp: Float): Int = (dp * resources.displayMetrics.density + 0.5f).toInt()
