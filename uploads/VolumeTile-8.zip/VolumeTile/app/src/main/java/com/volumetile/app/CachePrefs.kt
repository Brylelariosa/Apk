package com.volumetile.app

import android.content.Context

/**
 * Saved settings of the cache clean-up ([CacheCleaner]): whether it runs by itself, at what time
 * of day, whether a run is waiting for the phone to be unlocked, and what the last run did.
 *
 * Plain SharedPreferences, like [BubblePrefs]. The alarm receiver, the accessibility service and
 * the app all read them, so they live outside any one of those.
 */
object CachePrefs {

    private const val PREFS = "cache_clear"
    private const val KEY_ENABLED = "enabled"
    private const val KEY_HOUR = "hour"
    private const val KEY_MINUTE = "minute"
    private const val KEY_PENDING_AT = "pending_at"
    private const val KEY_LAST_AT = "last_at"
    private const val KEY_LAST_SUMMARY = "last_summary"

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** Off until the person switches it on in the app. */
    fun isEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_ENABLED, false)

    fun setEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_ENABLED, enabled).apply()
    }

    /** False until a time was chosen, so the app can ask for one the first time the switch goes on. */
    fun hasTime(context: Context): Boolean = prefs(context).contains(KEY_HOUR)

    /** Hour of the day (0-23) the clean-up runs at. */
    fun hour(context: Context): Int = prefs(context).getInt(KEY_HOUR, 12).coerceIn(0, 23)

    /** Minute (0-59) the clean-up runs at. */
    fun minute(context: Context): Int = prefs(context).getInt(KEY_MINUTE, 0).coerceIn(0, 59)

    fun setTime(context: Context, hour: Int, minute: Int) {
        prefs(context).edit().putInt(KEY_HOUR, hour).putInt(KEY_MINUTE, minute).apply()
    }

    /**
     * When a scheduled run came due but could not start yet (the phone was locked, or the
     * service was not running), or 0 when none is waiting.
     */
    fun pendingAt(context: Context): Long = prefs(context).getLong(KEY_PENDING_AT, 0L)

    fun setPendingAt(context: Context, millis: Long) {
        prefs(context).edit().putLong(KEY_PENDING_AT, millis).apply()
    }

    /** When the last run ended, and what it said; 0 and empty if it never ran. */
    fun lastRunAt(context: Context): Long = prefs(context).getLong(KEY_LAST_AT, 0L)

    fun lastSummary(context: Context): String =
        prefs(context).getString(KEY_LAST_SUMMARY, null).orEmpty()

    fun setLast(context: Context, millis: Long, summary: String) {
        prefs(context).edit()
            .putLong(KEY_LAST_AT, millis)
            .putString(KEY_LAST_SUMMARY, summary)
            .apply()
    }
}
