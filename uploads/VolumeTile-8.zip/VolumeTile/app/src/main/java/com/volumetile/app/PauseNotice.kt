package com.volumetile.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import android.util.Log

/**
 * The notification that says Volume Tile has stepped aside (for GCash, or because the person
 * paused it) and is still off. Tapping it opens the app, whose banner turns the service back
 * on; when the one-time permission is in place ([ServiceSwitch.canWrite]) it also carries a
 * Resume button that does it straight from the shade.
 *
 * It is a normal notification, not the keep-alive one: it comes and goes with the pause, and
 * the service removes it the moment it connects again. On Android 13+ it is only shown if the
 * person allowed notifications; if not, nothing is lost but the reminder.
 */
object PauseNotice {

    private const val TAG = "PauseNotice"
    private const val CHANNEL_ID = "paused"

    /** The keep-alive notification uses 1. */
    private const val NOTIFICATION_ID = 2

    fun show(context: Context) {
        try {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channel = NotificationChannel(
                CHANNEL_ID,
                context.getString(R.string.paused_channel),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                setShowBadge(false)
            }
            manager.createNotificationChannel(channel)

            val openApp = PendingIntent.getActivity(
                context,
                0,
                Intent(context, VolumeControlActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val builder = Notification.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_pause)
                .setContentTitle(context.getString(R.string.paused_title))
                .setContentText(context.getString(R.string.paused_text))
                .setContentIntent(openApp)
                .setAutoCancel(true)
                .setShowWhen(false)
                .setCategory(Notification.CATEGORY_STATUS)

            if (ServiceSwitch.canWrite(context)) {
                val resume = PendingIntent.getBroadcast(
                    context,
                    1,
                    Intent(context, ResumeReceiver::class.java),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
                builder.addAction(
                    Notification.Action.Builder(
                        Icon.createWithResource(context, R.drawable.ic_volume),
                        context.getString(R.string.paused_resume),
                        resume
                    ).build()
                )
            }
            manager.notify(NOTIFICATION_ID, builder.build())
        } catch (e: RuntimeException) {
            // A reminder is not worth a crash of the process that hosts the service.
            Log.w(TAG, "Could not show the paused notice", e)
        }
    }

    fun cancel(context: Context) {
        try {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.cancel(NOTIFICATION_ID)
        } catch (e: RuntimeException) {
            Log.w(TAG, "Could not remove the paused notice", e)
        }
    }
}
