package com.volumetile.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar

/**
 * Sets the one alarm behind "Auto clear cache": the next time the clock reads the hour and minute
 * chosen in the app. When it goes off, [CacheAlarmReceiver] books the following day's alarm
 * first and then asks the accessibility service to run the clean-up.
 *
 * The alarm is exact when Android allows that (always before Android 12, and from 12 on only if
 * the person allowed "Alarms & reminders"); otherwise it is the inexact kind, which can slip by
 * some minutes. For a clean-up that is no loss, so there is no screen asking for the permission.
 *
 * Alarms do not survive a restart, so [sync] is called when the phone starts, when the app is
 * updated, when the clock or zone changes, when the service connects and when the app changes
 * the setting.
 */
object CacheScheduler {

    /** The action of the alarm's broadcast, handled by [CacheAlarmReceiver]. */
    const val ACTION_RUN = "com.volumetile.app.action.CLEAR_CACHE"

    private const val REQUEST_CODE = 31

    /** Books the alarm if the setting is on, and cancels it if it is off. */
    fun sync(context: Context) {
        if (CachePrefs.isEnabled(context)) schedule(context) else cancel(context)
    }

    /** Books the next run, replacing any alarm that was already booked. */
    fun schedule(context: Context) {
        val manager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val at = nextRunMillis(
            CachePrefs.hour(context),
            CachePrefs.minute(context),
            System.currentTimeMillis()
        )
        val operation = alarmIntent(context)
        try {
            val exactAllowed =
                Build.VERSION.SDK_INT < Build.VERSION_CODES.S || manager.canScheduleExactAlarms()
            if (exactAllowed) {
                manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, operation)
            } else {
                manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, operation)
            }
        } catch (e: SecurityException) {
            // The exact-alarm permission was withdrawn between the check and the call.
            manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, operation)
        }
    }

    fun cancel(context: Context) {
        val manager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        manager.cancel(alarmIntent(context))
    }

    /** The first moment after [now] at which the clock reads [hour]:[minute]. */
    private fun nextRunMillis(hour: Int, minute: Int, now: Long): Long {
        val calendar = Calendar.getInstance()
        calendar.timeInMillis = now
        calendar.set(Calendar.HOUR_OF_DAY, hour)
        calendar.set(Calendar.MINUTE, minute)
        calendar.set(Calendar.SECOND, 0)
        calendar.set(Calendar.MILLISECOND, 0)
        // Already past (or about to be): the next one is tomorrow's.
        if (calendar.timeInMillis <= now + 1_000L) calendar.add(Calendar.DAY_OF_YEAR, 1)
        return calendar.timeInMillis
    }

    private fun alarmIntent(context: Context): PendingIntent =
        PendingIntent.getBroadcast(
            context,
            REQUEST_CODE,
            Intent(context, CacheAlarmReceiver::class.java).setAction(ACTION_RUN),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
}
