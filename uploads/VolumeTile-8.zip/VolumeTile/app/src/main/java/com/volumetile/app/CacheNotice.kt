package com.volumetile.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.util.Log

/**
 * The quiet notification that tells what the cache clean-up did (or why a scheduled one did not
 * start). A scheduled run may happen while the phone is in a pocket, so this is how the person
 * finds out it ran at all. Tapping it opens the app.
 *
 * Low importance (no sound or pop-up), and on Android 13+ only shown if notifications were
 * allowed; if not, nothing is lost but the message, which the app also shows under "Auto clear
 * cache".
 */
object CacheNotice {

    private const val TAG = "CacheNotice"
    private const val CHANNEL_ID = "cache_clear"

    /** The keep-alive notice uses 1 and the paused notice 2. */
    private const val NOTIFICATION_ID = 3

    fun show(context: Context, title: String, text: String) {
        try {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channel = NotificationChannel(
                CHANNEL_ID,
                context.getString(R.string.cache_channel),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                setShowBadge(false)
            }
            manager.createNotificationChannel(channel)

            val openApp = PendingIntent.getActivity(
                context,
                0,
                Intent(context, VolumeControlActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val notification = Notification.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_cache)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(Notification.BigTextStyle().bigText(text))
                .setContentIntent(openApp)
                .setAutoCancel(true)
                .setCategory(Notification.CATEGORY_STATUS)
                .build()
            manager.notify(NOTIFICATION_ID, notification)
        } catch (e: RuntimeException) {
            // A message is not worth a crash of the process that hosts the service.
            Log.w(TAG, "Could not show the cache notice", e)
        }
    }
}
