package com.volumetile.app

import android.accessibilityservice.AccessibilityService
import android.app.AppOpsManager
import android.app.usage.StorageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.Process
import android.os.SystemClock
import android.os.storage.StorageManager
import android.provider.Settings
import android.text.format.Formatter
import android.util.Log
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Clears the cache of every installed app - other apps, and disabled ones too - without root and
 * without Shizuku.
 *
 * Android gives an app no call for that (the permission behind it is for the system only), so this
 * does what a person would: for each app it opens that app's page in Settings (App info), taps
 * "Storage & cache", then taps "Clear cache". The accessibility service does the looking and
 * tapping. App info opens for any installed package, so disabled apps work the same way.
 *
 * What it relies on, and why it is built the way it is:
 *
 *  - **Reading Settings.** The service therefore declares canRetrieveWindowContent. It reads nothing
 *    but the Settings window, and only while a run is going.
 *  - **Labels.** The two buttons are found by their exact label, taken from Settings' own string
 *    resources when they can be read (so any language works), with the English words as a fallback.
 *    Nothing else is ever tapped: no "Clear storage", no "Force stop", no "Uninstall".
 *  - **Old pages.** Each tap or launch leaves the previous page on screen for a moment. A window that
 *    was showing before the last navigation is ignored until another window has replaced it, so a
 *    stale page is never mistaken for the new one.
 *  - **Speed.** With Usage access allowed, the size of each app's cache is known up front, and only
 *    apps that have some are visited (biggest first). Without it every app is visited, which takes
 *    several minutes.
 *  - **Staying put.** A dimmed cover ([CacheOverlay]) keeps the screen on, keeps stray touches out,
 *    and has a Stop button. The run also stops if the screen goes off, if Settings does not come
 *    up, or if the Storage screen cannot be found (the message then lists what the screen showed,
 *    so the wording can be added).
 *
 * Everything but listing the apps happens on the main thread, one short poll at a time.
 *
 * @param service the accessibility service doing the tapping.
 * @param onFinished called once, with a one-line result, when the run ends by itself or by Stop.
 *   Not called after [shutdown].
 */
class CacheCleaner(
    private val service: AccessibilityService,
    private val onFinished: (String) -> Unit
) {

    private val handler = Handler(Looper.getMainLooper())
    private val overlay = CacheOverlay(service) { cancel() }
    private val pollTask = Runnable { poll() }
    private val nextTask = Runnable { next() }

    private var settingsPackage = DEFAULT_SETTINGS_PACKAGE
    private var storageLabels: Set<String> = emptySet()
    private var clearLabels: Set<String> = emptySet()

    private var packages: List<String> = emptyList()

    /** Cache size of each app, when Usage access made them readable; empty otherwise. */
    private var cacheBefore: Map<String, Long> = emptyMap()
    private var index = 0
    private var finished = false
    private var runStart = 0L

    // What happened so far.
    private var cleared = 0
    private var freedBytes = 0L
    private var reachedStorage = 0
    private var notInSettings = 0
    private var seenTexts = ""

    // The app being worked on.
    private var packageStart = 0L
    private var sawButton = false
    private var disabledSince = 0L
    private var storageClickedAt = 0L
    private var scrolls = 0

    // The window that was showing before the last navigation; ignored until another one replaces it.
    private var staleWindowId = -1
    private var staleUntil = 0L

    private class Plan(val packages: List<String>, val sizes: Map<String, Long>)

    private enum class Outcome { WAIT, CLEARED, EMPTY, SKIPPED }

    /** Puts the cover up, works out which apps to visit, and starts. */
    fun start() {
        settingsPackage = resolveSettingsPackage()
        storageLabels = (STORAGE_LABELS + settingsLabels("storage_settings_for_app", "storage_settings")).toSet()
        clearLabels = (CLEAR_LABELS + settingsLabels("clear_cache_btn_text")).toSet()
        runStart = SystemClock.elapsedRealtime()
        overlay.show()
        // Asking for the cache size of every app takes a few seconds on a phone with many apps,
        // so it is not done on the main thread.
        Thread {
            val plan = try {
                buildPlan()
            } catch (e: RuntimeException) {
                Log.w(TAG, "Could not list the apps", e)
                null
            }
            handler.post { begin(plan) }
        }.start()
    }

    /** The service is going away: stop at once and say nothing. */
    fun shutdown() {
        if (finished) return
        finished = true
        handler.removeCallbacksAndMessages(null)
        overlay.hide()
    }

    // ---------------------------------------------------------------- planning

    @Suppress("DEPRECATION")
    private fun buildPlan(): Plan {
        clearOwnCache()
        val skip = setOf(service.packageName, settingsPackage) + SKIP_PACKAGES
        // Includes disabled apps: they are still installed, and their App info page works.
        val names = service.packageManager.getInstalledApplications(0)
            .map { it.packageName }
            .filter { it !in skip }
            .distinct()
        val sizes = cacheSizes(names) ?: return Plan(names.sorted(), emptyMap())
        // An app whose size could not be read is kept: it may well have cache.
        val wanted = names
            .filter { (sizes[it] ?: 1L) > 0L }
            .sortedByDescending { sizes[it] ?: 0L }
        return Plan(wanted, sizes)
    }

    /** Volume Tile's own cache needs no tapping: it is simply deleted. */
    private fun clearOwnCache() {
        try {
            service.cacheDir?.listFiles()?.forEach { it.deleteRecursively() }
            service.externalCacheDir?.listFiles()?.forEach { it.deleteRecursively() }
        } catch (e: RuntimeException) {
            Log.w(TAG, "Could not clear the app's own cache", e)
        }
    }

    /** Cache size per app, or null when Usage access has not been allowed. */
    private fun cacheSizes(names: List<String>): Map<String, Long>? {
        val manager = service.getSystemService(Context.STORAGE_STATS_SERVICE) as? StorageStatsManager
            ?: return null
        val user = Process.myUserHandle()
        val sizes = HashMap<String, Long>()
        for (name in names) {
            try {
                sizes[name] = manager.queryStatsForPackage(StorageManager.UUID_DEFAULT, name, user).cacheBytes
            } catch (e: SecurityException) {
                return null
            } catch (e: Exception) {
                // This one app could not be measured (not found, I/O error): leave its size unknown.
            }
        }
        return sizes
    }

    private fun begin(plan: Plan?) {
        if (finished) return
        if (plan == null) {
            finish(service.getString(R.string.cache_result_failed))
            return
        }
        packages = plan.packages
        cacheBefore = plan.sizes
        if (packages.isEmpty()) {
            finish(service.getString(R.string.cache_result_nothing))
            return
        }
        next()
    }

    // ---------------------------------------------------------------- one app at a time

    private fun next() {
        if (finished) return
        if (index >= packages.size) {
            finish(null)
            return
        }
        if (notInSettings >= MAX_OFF_SETTINGS) {
            finish(service.getString(R.string.cache_result_no_settings))
            return
        }
        if (reachedStorage == 0 && index >= MAX_BLIND_PACKAGES) {
            finish(service.getString(R.string.cache_result_no_storage, seenTexts.ifEmpty { "-" }))
            return
        }

        val name = packages[index]
        overlay.update(index, packages.size, appLabel(name))

        val now = SystemClock.elapsedRealtime()
        packageStart = now
        sawButton = false
        disabledSince = 0L
        storageClickedAt = 0L
        scrolls = 0
        // Whatever Settings shows now (the last app's Storage page) is not the new app's page.
        val current = service.rootInActiveWindow
        if (current != null) markStale(current, now)

        try {
            service.startActivity(detailsIntent(name))
        } catch (e: RuntimeException) {
            Log.w(TAG, "Could not open the App info of $name", e)
            advance(0L)
            return
        }
        handler.postDelayed(pollTask, FIRST_POLL_MS)
    }

    private fun advance(delayMs: Long) {
        index++
        handler.postDelayed(nextTask, delayMs)
    }

    private fun poll() {
        if (finished) return
        val now = SystemClock.elapsedRealtime()
        if (now - runStart > MAX_RUN_MS) {
            finish(service.getString(R.string.cache_result_too_long))
            return
        }
        val power = service.getSystemService(Context.POWER_SERVICE) as PowerManager
        if (!power.isInteractive) {
            finish(service.getString(R.string.cache_result_screen_off))
            return
        }
        val outcome = try {
            step(now)
        } catch (e: RuntimeException) {
            // A node that went stale mid-look; try again on the next poll.
            Log.w(TAG, "Reading the screen failed", e)
            Outcome.WAIT
        }
        when (outcome) {
            Outcome.WAIT -> handler.postDelayed(pollTask, POLL_MS)
            Outcome.CLEARED -> {
                cleared++
                freedBytes += cacheBefore[packages[index]] ?: 0L
                advance(SETTLE_MS)
            }
            Outcome.EMPTY, Outcome.SKIPPED -> advance(0L)
        }
    }

    /** One look at the screen: tap whatever comes next for the current app. */
    private fun step(now: Long): Outcome {
        if (now - packageStart > PACKAGE_TIMEOUT_MS) return giveUp()
        val root = settingsRoot(now) ?: return Outcome.WAIT

        // The Clear cache button (on the Storage page; on some phones already on App info).
        val button = findClearCache(root)
        if (button != null) {
            if (!sawButton) {
                sawButton = true
                reachedStorage++
            }
            if (button.isEnabled) {
                return if (button.performAction(AccessibilityNodeInfo.ACTION_CLICK)) Outcome.CLEARED else Outcome.WAIT
            }
            // Greyed out: either the size is still being counted, or there is no cache.
            if (disabledSince == 0L) disabledSince = now
            return if (now - disabledSince >= enableWaitMs()) Outcome.EMPTY else Outcome.WAIT
        }

        // Not there yet: the Storage entry on the App info page leads to it.
        if (now - storageClickedAt >= RETRY_CLICK_MS) {
            val row = findStorageRow(root)
            if (row != null && row.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                storageClickedAt = now
                markStale(root, now)
                return Outcome.WAIT
            }
        }

        // Neither is on screen: the entry may be below the fold of a small screen.
        if (scrolls < MAX_SCROLLS && now - packageStart > SCROLL_AFTER_MS * (scrolls + 1)) {
            scrolls++
            scrollForward(root)
        }
        return Outcome.WAIT
    }

    /** The current app could not be handled in time. */
    private fun giveUp(): Outcome {
        val root = service.rootInActiveWindow
        val inSettings = root != null && root.packageName?.toString() == settingsPackage
        if (inSettings) {
            // Kept for the message in case the Storage screen is never found.
            if (seenTexts.isEmpty() && root != null) seenTexts = collectTexts(root)
        } else {
            notInSettings++
        }
        return Outcome.SKIPPED
    }

    private fun enableWaitMs(): Long =
        if (cacheBefore.isEmpty()) ENABLE_WAIT_BLIND_MS else ENABLE_WAIT_KNOWN_MS

    // ---------------------------------------------------------------- ending

    private fun finish(message: String?) {
        if (finished) return
        finished = true
        handler.removeCallbacksAndMessages(null)
        overlay.hide()
        leaveSettings(0)
        onFinished(message ?: summary())
    }

    /** The Stop button. */
    private fun cancel() {
        finish(service.getString(R.string.cache_result_stopped, index))
    }

    private fun summary(): String {
        if (cleared == 0) return service.getString(R.string.cache_result_nothing)
        val apps = service.resources.getQuantityString(R.plurals.cache_cleared_apps, cleared, cleared)
        return if (freedBytes > 0L) {
            service.getString(R.string.cache_result_freed, apps, Formatter.formatShortFileSize(service, freedBytes))
        } else {
            apps
        }
    }

    /** Backs out of Settings to wherever the person was; Home if Back does not get out. */
    private fun leaveSettings(attempt: Int) {
        val root = try {
            service.rootInActiveWindow
        } catch (e: RuntimeException) {
            null
        }
        if (root == null || root.packageName?.toString() != settingsPackage) return
        if (attempt >= MAX_BACKS) {
            service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
            return
        }
        service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
        handler.postDelayed({ leaveSettings(attempt + 1) }, BACK_GAP_MS)
    }

    // ---------------------------------------------------------------- reading the screen

    /** The active window if it is Settings and not the stale one; null otherwise. */
    private fun settingsRoot(now: Long): AccessibilityNodeInfo? {
        val root = service.rootInActiveWindow ?: return null
        if (root.packageName?.toString() != settingsPackage) return null
        if (root.windowId == staleWindowId && now < staleUntil) return null
        notInSettings = 0
        return root
    }

    private fun markStale(root: AccessibilityNodeInfo, now: Long) {
        staleWindowId = root.windowId
        staleUntil = now + STALE_MAX_MS
    }

    private fun findClearCache(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        for (node in findNodes(root) { hasLabel(it, clearLabels) }) {
            val target = clickableSelfOrAncestor(node)
            if (target != null) return target
        }
        return null
    }

    private fun findStorageRow(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        // A list row's title first; a summary line that happens to read "Storage" only after those.
        val matches = findNodes(root) { hasLabel(it, storageLabels) }
            .sortedBy { if (it.viewIdResourceName?.endsWith("/title") == true) 0 else 1 }
        for (node in matches) {
            val row = clickableSelfOrAncestor(node)
            if (row != null) return row
        }
        return null
    }

    private fun scrollForward(root: AccessibilityNodeInfo) {
        val list = findNodes(root) { it.isScrollable }.firstOrNull() ?: return
        list.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
    }

    /** True if the node's text or description is exactly one of [labels] (ignoring case). */
    private fun hasLabel(node: AccessibilityNodeInfo, labels: Set<String>): Boolean {
        val text = node.text?.toString()?.trim()?.lowercase()
        if (text != null && text in labels) return true
        val description = node.contentDescription?.toString()?.trim()?.lowercase()
        return description != null && description in labels
    }

    private fun clickableSelfOrAncestor(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var current: AccessibilityNodeInfo? = node
        var hops = 0
        while (current != null && hops <= MAX_ANCESTOR_HOPS) {
            if (current.isClickable) return current
            current = current.parent
            hops++
        }
        return null
    }

    /** Every node under [root] (root included) for which [test] is true, in screen order. */
    private fun findNodes(
        root: AccessibilityNodeInfo,
        test: (AccessibilityNodeInfo) -> Boolean
    ): List<AccessibilityNodeInfo> {
        val found = ArrayList<AccessibilityNodeInfo>()
        var visited = 0
        fun walk(node: AccessibilityNodeInfo, depth: Int) {
            if (visited++ > MAX_NODES || depth > MAX_DEPTH) return
            if (test(node)) found.add(node)
            for (i in 0 until node.childCount) {
                val child = node.getChild(i) ?: continue
                walk(child, depth + 1)
            }
        }
        walk(root, 0)
        return found
    }

    /** The first texts on a screen, for the message that asks for the wording to be added. */
    private fun collectTexts(root: AccessibilityNodeInfo): String {
        val texts = LinkedHashSet<String>()
        findNodes(root) { node ->
            val text = node.text?.toString()?.trim()
            if (!text.isNullOrEmpty() && texts.size < MAX_SEEN_TEXTS) texts.add(text.take(30))
            false
        }
        return texts.joinToString(" | ")
    }

    // ---------------------------------------------------------------- Settings and labels

    private fun detailsIntent(name: String): Intent =
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", name, null))
            .addFlags(
                // A new, empty task each time, so pages never pile up; no animation to wait for;
                // and no extra entry in the recent apps.
                Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TASK or
                    Intent.FLAG_ACTIVITY_NO_ANIMATION or
                    Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS
            )

    /** The package that answers "open this app's info", normally com.android.settings. */
    private fun resolveSettingsPackage(): String {
        val probe = Intent(
            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            Uri.fromParts("package", service.packageName, null)
        )
        val found = service.packageManager
            .resolveActivity(probe, PackageManager.MATCH_DEFAULT_ONLY)
            ?.activityInfo
            ?.packageName
        // "android" is the system's chooser, which means no single app answered.
        return if (found.isNullOrEmpty() || found == "android") DEFAULT_SETTINGS_PACKAGE else found
    }

    /**
     * The phone's own wording for strings in Settings, so the buttons are found in any language.
     * Empty if Settings' resources cannot be read; the English words are always tried as well.
     */
    private fun settingsLabels(vararg names: String): List<String> {
        val labels = ArrayList<String>()
        try {
            val resources = service.packageManager.getResourcesForApplication(settingsPackage)
            for (name in names) {
                val id = resources.getIdentifier(name, "string", settingsPackage)
                if (id != 0) labels.add(resources.getString(id).trim().lowercase())
            }
        } catch (e: Exception) {
            Log.w(TAG, "Could not read Settings' strings", e)
        }
        return labels
    }

    @Suppress("DEPRECATION")
    private fun appLabel(name: String): String = try {
        val packageManager = service.packageManager
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(name, 0)).toString()
    } catch (e: Exception) {
        name
    }

    companion object {
        private const val TAG = "CacheCleaner"

        private const val DEFAULT_SETTINGS_PACKAGE = "com.android.settings"

        /** Never visited: the framework itself and the system UI (its "app" page is not a normal one). */
        private val SKIP_PACKAGES = setOf("android", "com.android.systemui")

        /** The English wording; the phone's own is added on top (see settingsLabels). All lower case. */
        private val STORAGE_LABELS = listOf(
            "storage",
            "storage & cache",
            "storage and cache",
            "storage usage",
            "storage & memory"
        )
        private val CLEAR_LABELS = listOf("clear cache")

        private const val POLL_MS = 200L
        private const val FIRST_POLL_MS = 400L
        private const val SETTLE_MS = 350L
        private const val BACK_GAP_MS = 350L
        private const val MAX_BACKS = 3

        /** Per app: how long to wait for its pages before moving on. */
        private const val PACKAGE_TIMEOUT_MS = 10_000L

        /** A window that was on screen before a navigation is ignored for at most this long. */
        private const val STALE_MAX_MS = 3_000L
        private const val RETRY_CLICK_MS = 3_000L
        private const val SCROLL_AFTER_MS = 1_200L
        private const val MAX_SCROLLS = 3

        /** How long a greyed-out Clear cache button is waited on: sizes known, or not. */
        private const val ENABLE_WAIT_KNOWN_MS = 3_500L
        private const val ENABLE_WAIT_BLIND_MS = 1_800L

        /** A whole run is cut off after this, whatever it is doing. */
        private const val MAX_RUN_MS = 25 * 60 * 1_000L

        /** Give up when the first this many apps never showed the Storage screen at all. */
        private const val MAX_BLIND_PACKAGES = 8

        /** Give up when Settings did not come up for this many apps in a row. */
        private const val MAX_OFF_SETTINGS = 4

        private const val MAX_DEPTH = 40
        private const val MAX_NODES = 900
        private const val MAX_ANCESTOR_HOPS = 6
        private const val MAX_SEEN_TEXTS = 14

        /** Whether Usage access is allowed: it makes the sizes readable, so empty apps can be skipped. */
        @Suppress("DEPRECATION")
        fun hasUsageAccess(context: Context): Boolean {
            val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            val mode = appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
            return mode == AppOpsManager.MODE_ALLOWED
        }
    }
}
