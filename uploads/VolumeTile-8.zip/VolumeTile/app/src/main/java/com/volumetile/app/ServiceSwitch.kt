package com.volumetile.app

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Log

/**
 * Switches this app's accessibility service on and off by editing the system's list of enabled
 * accessibility services - what Settings > Accessibility does when the person flips the toggle.
 *
 * Android only lets an app do that once it has been granted WRITE_SECURE_SETTINGS, a one-time
 * `adb shell pm grant` (see the README and the "Set up one-tap resume" button in the app).
 * Without it every function here does nothing and returns false, and the callers fall back to
 * opening Accessibility settings for the person to flip the toggle themselves.
 *
 * It is used to turn the service back on after it stepped aside for GCash ([ProtectedApps]) and
 * to revive a service that Android stopped while Settings still lists it as on. Other
 * accessibility services in the list (TalkBack, say) are carried over exactly as they were.
 */
object ServiceSwitch {

    private const val TAG = "ServiceSwitch"

    /** Gap between switching off and on again in [restart], so the system sees both changes. */
    private const val RESTART_GAP_MS = 500L

    /** True once the one-time permission has been granted. */
    fun canWrite(context: Context): Boolean =
        context.checkSelfPermission(Manifest.permission.WRITE_SECURE_SETTINGS) ==
            PackageManager.PERMISSION_GRANTED

    /**
     * Adds this service to the enabled list, or removes it. Returns false when that isn't
     * possible (no permission, or the system refused), true when the setting was written. The
     * system binds or unbinds the service a moment after that.
     */
    fun setEnabled(context: Context, enable: Boolean): Boolean {
        if (!canWrite(context)) return false
        return try {
            val resolver = context.contentResolver
            val self = ComponentName(context, SystemActionService::class.java)
            // Every entry except ours, untouched and in the same order.
            val others = Settings.Secure
                .getString(resolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
                .orEmpty()
                .split(':')
                .filter { entry -> entry.isNotBlank() && ComponentName.unflattenFromString(entry) != self }
            val updated = if (enable) others + self.flattenToString() else others
            Settings.Secure.putString(
                resolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES,
                updated.joinToString(":")
            )
            if (enable) {
                Settings.Secure.putInt(resolver, Settings.Secure.ACCESSIBILITY_ENABLED, 1)
            } else if (updated.isEmpty()) {
                // Nothing else is enabled either, so accessibility as a whole goes off.
                Settings.Secure.putInt(resolver, Settings.Secure.ACCESSIBILITY_ENABLED, 0)
            }
            true
        } catch (e: RuntimeException) {
            // SecurityException if the permission was revoked meanwhile; anything else is a
            // phone that doesn't like the write. Either way the caller has a fallback.
            Log.w(TAG, "Could not change the enabled accessibility services", e)
            false
        }
    }

    /**
     * Revives a service that Settings lists as on but the system no longer runs: off now, on
     * again half a second later. Returns false (and changes nothing) without the permission.
     */
    fun restart(context: Context): Boolean {
        if (!setEnabled(context, false)) return false
        val app = context.applicationContext
        Handler(Looper.getMainLooper()).postDelayed({ setEnabled(app, true) }, RESTART_GAP_MS)
        return true
    }
}
