package com.volumetile.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Two jobs, both for "Auto clear cache" ([CacheScheduler]):
 *
 *  - The daily alarm ([CacheScheduler.ACTION_RUN]): books tomorrow's alarm first, so a failure
 *    further on never ends the daily run, notes that a clean-up is due, and hands it to the
 *    accessibility service, which does the work.
 *  - Phone start, app update, clock or time-zone change: alarms are lost or off by then, so the
 *    alarm is booked again.
 */
class CacheAlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext
        if (intent.action != CacheScheduler.ACTION_RUN) {
            CacheScheduler.sync(app)
            return
        }
        if (!CachePrefs.isEnabled(app)) return

        CacheScheduler.schedule(app)
        CachePrefs.setPendingAt(app, System.currentTimeMillis())

        // After a cold start the system may need a few seconds to bind the service, so this
        // broadcast is kept open for a moment (goAsync) rather than finishing at once.
        val pending = goAsync()
        SystemActionService.runDueCacheClear(app) { pending.finish() }
    }
}
