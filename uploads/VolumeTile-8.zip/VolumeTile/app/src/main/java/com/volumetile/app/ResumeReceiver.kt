package com.volumetile.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * The Resume button on the paused notification ([PauseNotice]). It switches the accessibility
 * service back on through [ServiceSwitch], so it only works - and the button is only shown -
 * once the one-time WRITE_SECURE_SETTINGS permission has been granted. It starts no activity.
 */
class ResumeReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (ServiceSwitch.setEnabled(context, true)) PauseNotice.cancel(context)
    }
}
