package com.volumetile.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationManager
import android.app.TimePickerDialog
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.text.format.DateFormat
import android.text.format.DateUtils
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.CompoundButton
import android.widget.EditText
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import java.util.Calendar

/**
 * Shows adjustable sliders for Media, Ring, Notification and Alarm volume. It is the
 * launcher activity; the Volume tile does not open it (the tile pops up the system
 * volume panel instead, so a game in the foreground is left alone).
 *
 * Two more sliders set what the Louder and Quieter actions do (see [VolumeLevels]).
 *
 * Also the place that keeps the accessibility service healthy: it shows when the service
 * is off, paused or has been stopped by the system (and, with the one-time permission, turns
 * it back on from its button), offers the battery-optimisation exemption, and holds the
 * checkbox for [KeepAlive], the switch (plus the pickers for the icons of its arc) for the
 * floating bubble, the switch and app list for pausing the service when GCash or another
 * [ProtectedApps] app opens, and the switch and time of day for "Auto clear cache"
 * ([CacheScheduler], [CacheCleaner]) with a button that runs it right now.
 */
class VolumeControlActivity : AppCompatActivity() {

    private lateinit var audioManager: AudioManager
    private lateinit var rows: List<StreamRow>
    private lateinit var bubbleSwitch: SwitchCompat
    private lateinit var bubbleOptions: View
    private lateinit var protectSwitch: SwitchCompat
    private lateinit var protectOptions: View
    private lateinit var cacheSwitch: SwitchCompat
    private lateinit var cacheOptions: View

    private val bubbleToggleListener = CompoundButton.OnCheckedChangeListener { _, checked ->
        onBubbleToggled(checked)
    }

    private val protectToggleListener = CompoundButton.OnCheckedChangeListener { _, checked ->
        onProtectToggled(checked)
    }

    private val cacheToggleListener = CompoundButton.OnCheckedChangeListener { _, checked ->
        onCacheToggled(checked)
    }

    private val handler = Handler(Looper.getMainLooper())

    /**
     * Re-checks the service while it is switched on but not yet connected, so the banner
     * appears if it never comes up and vanishes as soon as it does. Stops by itself once
     * the answer can no longer change, and while the screen isn't showing.
     */
    private val watchService = object : Runnable {
        override fun run() {
            if (updateAccessibilityBanner()) handler.postDelayed(this, SERVICE_RECHECK_MS)
        }
    }

    private data class StreamRow(
        val stream: Int,
        val seekBar: SeekBar,
        val valueText: TextView
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_volume_control)

        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager

        rows = listOf(
            StreamRow(AudioManager.STREAM_MUSIC, findViewById(R.id.seekMedia), findViewById(R.id.valueMedia)),
            StreamRow(AudioManager.STREAM_RING, findViewById(R.id.seekRing), findViewById(R.id.valueRing)),
            StreamRow(
                AudioManager.STREAM_NOTIFICATION,
                findViewById(R.id.seekNotification),
                findViewById(R.id.valueNotification)
            ),
            StreamRow(AudioManager.STREAM_ALARM, findViewById(R.id.seekAlarm), findViewById(R.id.valueAlarm))
        )

        rows.forEach(::setupRow)
        setupLevelRows()

        findViewById<View>(R.id.btnGrantDnd).setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        }
        findViewById<View>(R.id.btnEnableAccessibility).setOnClickListener {
            onServiceButtonClicked()
        }
        findViewById<View>(R.id.btnBatteryUnrestricted).setOnClickListener {
            requestUnrestrictedBattery()
        }
        findViewById<CheckBox>(R.id.checkKeepAlive).apply {
            isChecked = KeepAlive.isEnabled(this@VolumeControlActivity)
            setOnCheckedChangeListener { _, checked ->
                KeepAlive.setEnabled(this@VolumeControlActivity, checked)
                SystemActionService.refreshKeepAlive()
            }
        }
        setupBubbleSection()
        setupProtectSection()
        setupCacheSection()
        findViewById<View>(R.id.btnDone).setOnClickListener { finish() }
    }

    override fun onResume() {
        super.onResume()
        // Re-sync sliders in case volume changed elsewhere (e.g. an incoming call)
        rows.forEach { row ->
            val current = audioManager.getStreamVolume(row.stream)
            row.seekBar.progress = current
            row.valueText.text = current.toString()
        }
        updateDndBannerVisibility()
        updateBatteryBannerVisibility()
        syncBubbleSwitch()
        syncProtectSwitch()
        syncCacheSection()
        updateResumeState()
        askForNotificationsOnce()
        // A foreground start the system refused while the phone sat idle (Android 12+ is strict
        // about starting one from the background) is not retried by anything else. The app is
        // on screen now, which is always allowed, so make sure the service is protected again.
        SystemActionService.refreshKeepAlive()
        handler.removeCallbacks(watchService)
        watchService.run()
    }

    override fun onPause() {
        handler.removeCallbacks(watchService)
        super.onPause()
    }

    private fun setupRow(row: StreamRow) {
        val max = audioManager.getStreamMaxVolume(row.stream)
        val current = audioManager.getStreamVolume(row.stream)
        row.seekBar.max = max
        row.seekBar.progress = current
        row.valueText.text = current.toString()

        row.seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                row.valueText.text = progress.toString()
                if (!fromUser) return
                try {
                    audioManager.setStreamVolume(row.stream, progress, 0)
                } catch (e: SecurityException) {
                    Toast.makeText(
                        this@VolumeControlActivity,
                        getString(R.string.dnd_needed_toast),
                        Toast.LENGTH_SHORT
                    ).show()
                    updateDndBannerVisibility()
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar) {}
            override fun onStopTrackingTouch(seekBar: SeekBar) {}
        })
    }

    /**
     * What the Louder and Quieter actions do. At the far left of a slider the action moves one
     * step (what it always did); anywhere else it jumps straight to that media volume level.
     * Saved as the slider moves; the accessibility service reads it each time an action runs.
     */
    private fun setupLevelRows() {
        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        bindLevelRow(
            findViewById(R.id.seekQuieter),
            findViewById(R.id.valueQuieter),
            max,
            VolumeLevels.quieter(this)
        ) { VolumeLevels.setQuieter(this, it) }
        bindLevelRow(
            findViewById(R.id.seekLouder),
            findViewById(R.id.valueLouder),
            max,
            VolumeLevels.louder(this)
        ) { VolumeLevels.setLouder(this, it) }
    }

    private fun bindLevelRow(
        seekBar: SeekBar,
        valueText: TextView,
        max: Int,
        saved: Int,
        save: (Int) -> Unit
    ) {
        fun show(level: Int) {
            valueText.text =
                if (level == 0) getString(R.string.level_one_step)
                else getString(R.string.level_value, level)
        }
        seekBar.max = max
        seekBar.progress = saved.coerceIn(0, max)
        show(seekBar.progress)
        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar, progress: Int, fromUser: Boolean) {
                show(progress)
                if (fromUser) save(progress)
            }

            override fun onStartTrackingTouch(bar: SeekBar) {}
            override fun onStopTrackingTouch(bar: SeekBar) {}
        })
    }

    /**
     * The floating bubble: a switch for it and, while it is on, a picker for what each icon
     * of its arc does. The accessibility service does the actual showing; it is told right
     * away through [SystemActionService.refreshBubble] and reads the saved settings itself
     * whenever it starts.
     */
    private fun setupBubbleSection() {
        bubbleOptions = findViewById(R.id.bubbleOptions)
        bubbleSwitch = findViewById(R.id.switchBubble)

        val actions = SystemAction.forArc()
        val labels = listOf(getString(R.string.action_none)) + actions.map { getString(it.labelRes) }
        val pickers = listOf(
            ArcSlot.FIRST to findViewById<Spinner>(R.id.spinnerSlot1),
            ArcSlot.SECOND to findViewById<Spinner>(R.id.spinnerSlot2),
            ArcSlot.THIRD to findViewById<Spinner>(R.id.spinnerSlot3),
            ArcSlot.FOURTH to findViewById<Spinner>(R.id.spinnerSlot4),
            ArcSlot.FIFTH to findViewById<Spinner>(R.id.spinnerSlot5)
        )
        for ((slot, picker) in pickers) {
            picker.adapter = ArrayAdapter(this, R.layout.item_spinner_compact, labels).apply {
                setDropDownViewResource(R.layout.item_spinner_compact)
            }
            // Entry 0 is "Nothing"; the actions follow in the order of [labels]. A saved action
            // this Android version can't run is not in the list, so the picker then shows
            // "Nothing" while the saved choice stays as it is.
            val current = BubblePrefs.actionFor(this, slot)
            var shown = if (current == null) 0 else actions.indexOf(current) + 1
            picker.setSelection(shown)
            picker.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    // This also fires once when the picker is first laid out: only save a real change.
                    if (position == shown) return
                    shown = position
                    val chosen = if (position == 0) null else actions.getOrNull(position - 1)
                    BubblePrefs.setAction(this@VolumeControlActivity, slot, chosen)
                }

                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }
        }
        syncBubbleSwitch()
    }

    /**
     * Shows the saved state of the bubble. The chooser's Floating entry changes it too, so
     * this also runs whenever the screen comes back, without that counting as a tap on the switch.
     */
    private fun syncBubbleSwitch() {
        val enabled = BubblePrefs.isEnabled(this)
        bubbleSwitch.setOnCheckedChangeListener(null)
        bubbleSwitch.isChecked = enabled
        bubbleSwitch.setOnCheckedChangeListener(bubbleToggleListener)
        bubbleOptions.visibility = if (enabled) View.VISIBLE else View.GONE
    }

    private fun onBubbleToggled(checked: Boolean) {
        BubblePrefs.setEnabled(this, checked)
        bubbleOptions.visibility = if (checked) View.VISIBLE else View.GONE
        SystemActionService.refreshBubble()
        if (!checked) return

        // The bubble is a window of the accessibility service, so it needs the service. The
        // switch stays on either way: the bubble appears by itself once the service runs.
        when {
            !SystemActionService.isEnabled(this) -> {
                Toast.makeText(this, R.string.toast_bubble_needs_service, Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
            SystemActionService.isStalled(this) -> {
                Toast.makeText(this, R.string.toast_restart_service, Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
    }

    /**
     * Auto clear cache: a switch, the time of day it runs at, when it last ran and what it did,
     * a button to allow Usage access (which lets the clean-up skip apps that have no cache) and
     * one that runs the clean-up right now. The daily alarm is booked right away through
     * [CacheScheduler]; the clean-up itself is done by the accessibility service ([CacheCleaner]).
     */
    private fun setupCacheSection() {
        cacheSwitch = findViewById(R.id.switchCache)
        cacheOptions = findViewById(R.id.cacheOptions)
        findViewById<View>(R.id.btnCacheTime).setOnClickListener { pickCacheTime(firstTime = false) }
        findViewById<View>(R.id.btnCacheUsage).setOnClickListener { openUsageAccess() }
        findViewById<View>(R.id.btnCacheNow).setOnClickListener { clearCacheNow() }
        syncCacheSection()
    }

    /**
     * Shows the saved state. It also runs whenever the screen comes back, so a run that finished
     * meanwhile shows up, and so does Usage access having been allowed - without any of that
     * counting as a tap on the switch.
     */
    private fun syncCacheSection() {
        val enabled = CachePrefs.isEnabled(this)
        cacheSwitch.setOnCheckedChangeListener(null)
        cacheSwitch.isChecked = enabled
        cacheSwitch.setOnCheckedChangeListener(cacheToggleListener)
        cacheOptions.visibility = if (enabled) View.VISIBLE else View.GONE
        findViewById<Button>(R.id.btnCacheTime).text = formatCacheTime()
        findViewById<View>(R.id.btnCacheUsage).visibility =
            if (CacheCleaner.hasUsageAccess(this)) View.GONE else View.VISIBLE

        val last = CachePrefs.lastSummary(this)
        findViewById<TextView>(R.id.textCacheStatus).text =
            if (last.isEmpty()) {
                getString(R.string.cache_never_ran)
            } else {
                val whenText = DateUtils.formatDateTime(
                    this,
                    CachePrefs.lastRunAt(this),
                    DateUtils.FORMAT_SHOW_DATE or DateUtils.FORMAT_SHOW_TIME or DateUtils.FORMAT_ABBREV_ALL
                )
                getString(R.string.cache_last_run, whenText, last)
            }
    }

    private fun onCacheToggled(checked: Boolean) {
        // The first time there is no time to run at yet: ask for one, and switch on only once it
        // is chosen. Cancelling the dialog leaves the switch off.
        if (checked && !CachePrefs.hasTime(this)) {
            pickCacheTime(firstTime = true)
            return
        }
        CachePrefs.setEnabled(this, checked)
        if (!checked) CachePrefs.setPendingAt(this, 0L)
        CacheScheduler.sync(this)
        cacheOptions.visibility = if (checked) View.VISIBLE else View.GONE
        if (checked) warnIfServiceOff()
    }

    private fun pickCacheTime(firstTime: Boolean) {
        val dialog = TimePickerDialog(
            this,
            { _, hour, minute ->
                CachePrefs.setTime(this, hour, minute)
                if (firstTime) CachePrefs.setEnabled(this, true)
                CacheScheduler.sync(this)
                syncCacheSection()
                if (firstTime) warnIfServiceOff()
            },
            CachePrefs.hour(this),
            CachePrefs.minute(this),
            DateFormat.is24HourFormat(this)
        )
        if (firstTime) dialog.setOnCancelListener { syncCacheSection() }
        dialog.show()
    }

    /** The time of day as the phone writes it (12 or 24 hour clock). */
    private fun formatCacheTime(): String {
        val calendar = Calendar.getInstance()
        calendar.set(Calendar.HOUR_OF_DAY, CachePrefs.hour(this))
        calendar.set(Calendar.MINUTE, CachePrefs.minute(this))
        return DateFormat.getTimeFormat(this).format(calendar.time)
    }

    /**
     * The clean-up is done by the accessibility service, so say so when it isn't running. The
     * switch stays on either way: the run works by itself once the service is back.
     */
    private fun warnIfServiceOff() {
        when {
            !SystemActionService.isEnabled(this) -> {
                Toast.makeText(this, R.string.toast_cache_needs_service, Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
            SystemActionService.isStalled(this) -> {
                Toast.makeText(this, R.string.toast_restart_service, Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
    }

    /** Runs the clean-up now: the same one the daily alarm runs, and the Clear cache tile. */
    private fun clearCacheNow() {
        when {
            !SystemActionService.isEnabled(this) || SystemActionService.isStalled(this) -> warnIfServiceOff()
            !SystemActionService.dispatch(SystemAction.CLEAR_CACHE, ActionOrigin.CHOOSER) ->
                Toast.makeText(this, R.string.toast_service_starting, Toast.LENGTH_SHORT).show()
        }
    }

    /** Opens this app's switch in "Usage access" (Android 10+; older versions open the list). */
    private fun openUsageAccess() {
        try {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS, Uri.parse("package:$packageName")))
        } catch (e: ActivityNotFoundException) {
            try {
                startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            } catch (e2: ActivityNotFoundException) {
                Toast.makeText(this, R.string.toast_action_failed, Toast.LENGTH_SHORT).show()
            }
        }
    }

    /**
     * Pausing for GCash and similar apps: a switch, the list of apps (package names) and the
     * state of one-tap resume. The service is told right away through
     * [SystemActionService.refreshProtection] and reads the saved settings itself whenever it
     * starts.
     */
    private fun setupProtectSection() {
        protectOptions = findViewById(R.id.protectOptions)
        protectSwitch = findViewById(R.id.switchProtect)

        val appList = findViewById<EditText>(R.id.editProtectedApps)
        // Fill the box before the watcher exists, so showing the saved list isn't a "change".
        appList.setText(ProtectedApps.rawPackages(this))
        appList.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}

            override fun afterTextChanged(s: Editable?) {
                ProtectedApps.setPackages(this@VolumeControlActivity, s?.toString().orEmpty())
                SystemActionService.refreshProtection()
            }
        })
        findViewById<View>(R.id.btnResumeSetup).setOnClickListener { showResumeSetupDialog() }
        syncProtectSwitch()
    }

    /** Shows the saved state of the switch without that counting as a tap on it. */
    private fun syncProtectSwitch() {
        val enabled = ProtectedApps.isEnabled(this)
        protectSwitch.setOnCheckedChangeListener(null)
        protectSwitch.isChecked = enabled
        protectSwitch.setOnCheckedChangeListener(protectToggleListener)
        protectOptions.visibility = if (enabled) View.VISIBLE else View.GONE
    }

    private fun onProtectToggled(checked: Boolean) {
        ProtectedApps.setEnabled(this, checked)
        protectOptions.visibility = if (checked) View.VISIBLE else View.GONE
        SystemActionService.refreshProtection()
    }

    /** Says whether the one-time permission for one-tap resume is in place, and offers to set it up. */
    private fun updateResumeState() {
        val ready = ServiceSwitch.canWrite(this)
        findViewById<TextView>(R.id.textResumeState)
            .setText(if (ready) R.string.resume_on else R.string.resume_off)
        findViewById<View>(R.id.btnResumeSetup).visibility = if (ready) View.GONE else View.VISIBLE
    }

    /**
     * Explains the one-time `adb shell pm grant` that lets the app switch its own accessibility
     * service back on, with a button that copies the command.
     */
    private fun showResumeSetupDialog() {
        val command = "adb shell pm grant $packageName android.permission.WRITE_SECURE_SETTINGS"
        AlertDialog.Builder(this)
            .setTitle(R.string.resume_setup_title)
            .setMessage(getString(R.string.resume_setup_message, command))
            .setPositiveButton(R.string.copy_command) { _, _ -> copyCommand(command) }
            .setNegativeButton(R.string.done, null)
            .show()
    }

    private fun copyCommand(command: String) {
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("adb", command))
        Toast.makeText(this, R.string.toast_copied, Toast.LENGTH_SHORT).show()
    }

    /**
     * Android 13+ wants a yes from the person before an app may post a notification - here, the
     * one that says the service is paused. Asked once; nothing else depends on the answer (the
     * keep-alive notification is a foreground-service one and is not affected).
     */
    private fun askForNotificationsOnce() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) return
        val state = getSharedPreferences(STATE_PREFS, MODE_PRIVATE)
        if (state.getBoolean(KEY_ASKED_NOTIFICATIONS, false)) return
        state.edit().putBoolean(KEY_ASKED_NOTIFICATIONS, true).apply()
        requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), NOTIFICATION_REQUEST)
    }

    /**
     * The banner button. With the one-time permission it switches the service back on (or
     * revives a stopped one) right here; without it, it opens Accessibility settings for the
     * person to flip the switch.
     */
    private fun onServiceButtonClicked() {
        val done = when {
            !SystemActionService.isEnabled(this) -> ServiceSwitch.setEnabled(this, true)
            SystemActionService.isStalled(this) -> ServiceSwitch.restart(this)
            else -> false
        }
        if (done) {
            Toast.makeText(this, R.string.toast_service_resuming, Toast.LENGTH_SHORT).show()
            // The system binds the service a moment later: look again then, so the banner clears.
            handler.removeCallbacks(watchService)
            handler.postDelayed(watchService, RESUME_RECHECK_MS)
        } else {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
    }

    private fun updateDndBannerVisibility() {
        val notificationManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val needsAccess = !notificationManager.isNotificationPolicyAccessGranted
        findViewById<View>(R.id.btnGrantDnd).visibility = if (needsAccess) View.VISIBLE else View.GONE
    }

    /**
     * The Screenshot / Shade shot / Power menu tiles and the nav-bar button need the
     * accessibility service running. The banner covers both ways that can be missing:
     * switched off (never enabled, or an app update turned it off), or switched on but
     * stopped by the system - the case where the button just does nothing. Either way the
     * tap leads to Accessibility settings; for the second, flip Volume Tile off and on.
     *
     * @return true while the service is on but not connected yet, i.e. worth checking again.
     */
    private fun updateAccessibilityBanner(): Boolean {
        val button = findViewById<Button>(R.id.btnEnableAccessibility)
        val enabled = SystemActionService.isEnabled(this)
        val connected = SystemActionService.isConnected()
        when {
            // Stepped aside on purpose (GCash opened, or it was paused by hand): say so, rather
            // than asking the person to "enable" something they never switched off.
            !enabled && ProtectedApps.isPaused(this) -> {
                button.setText(R.string.resume_service)
                button.visibility = View.VISIBLE
            }
            !enabled -> {
                button.setText(R.string.enable_accessibility_access)
                button.visibility = View.VISIBLE
            }
            connected -> button.visibility = View.GONE
            SystemActionService.isStalled(this) -> {
                button.setText(R.string.restart_accessibility_service)
                button.visibility = View.VISIBLE
            }
            // Just (re)started: the system is about to bind the service. Say nothing yet.
            else -> button.visibility = View.GONE
        }
        return enabled && !connected
    }

    /** Offered until the app is exempt from battery optimisation; vanishes once it is. */
    private fun updateBatteryBannerVisibility() {
        val powerManager = getSystemService(POWER_SERVICE) as PowerManager
        val restricted = !powerManager.isIgnoringBatteryOptimizations(packageName)
        findViewById<View>(R.id.btnBatteryUnrestricted).visibility =
            if (restricted) View.VISIBLE else View.GONE
    }

    /**
     * Asks to be left out of battery optimisation. The first intent shows a one-tap system
     * dialog; if a phone lacks it, fall back to the full list, then to this app's info page.
     */
    @SuppressLint("BatteryLife")
    private fun requestUnrestrictedBattery() {
        val packageUri = Uri.parse("package:$packageName")
        val attempts = listOf(
            Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, packageUri),
            Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS),
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, packageUri)
        )
        for (intent in attempts) {
            try {
                startActivity(intent)
                return
            } catch (e: ActivityNotFoundException) {
                // This phone doesn't have that screen; try the next one.
            }
        }
    }

    private companion object {
        const val SERVICE_RECHECK_MS = 2_000L

        /** How long after switching the service on from here before the banner is checked again. */
        const val RESUME_RECHECK_MS = 1_000L

        const val STATE_PREFS = "app_state"
        const val KEY_ASKED_NOTIFICATIONS = "asked_notifications"
        const val NOTIFICATION_REQUEST = 11
    }
}
