package com.volumetile.app

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.view.ContextThemeWrapper
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.ProgressBar
import android.widget.TextView

/**
 * The dimmed cover with a progress bar and a Stop button that stays on screen while
 * [CacheCleaner] works its way through Settings. It does three jobs:
 *
 *  - It tells the person what is going on, instead of leaving them with Settings pages that flick
 *    by on their own, and gives them a way out (Stop).
 *  - It swallows touches, so a stray tap cannot land in Settings halfway through. Accessibility
 *    clicks are not touches, so they pass straight through to Settings underneath.
 *  - It keeps the screen awake for as long as it is up; a run takes longer than the screen timeout.
 *
 * It is also what lets the service open Settings from the background: an app that owns a visible
 * window may start activities (the rule is Android 10+), and this is that window.
 *
 * Like [ActionChooserOverlay] it is a TYPE_ACCESSIBILITY_OVERLAY window, which only an accessibility
 * service may add, and it is not focusable, so Settings stays the active window underneath.
 *
 * @param service the accessibility service. Its own WindowManager must be used: only that one
 *   carries the token allowed to add overlay windows.
 * @param onStop called when Stop is tapped; the overlay does not remove itself.
 */
class CacheOverlay(
    private val service: Context,
    private val onStop: () -> Unit
) {

    private val windowManager = service.getSystemService(Context.WINDOW_SERVICE) as WindowManager

    private var root: View? = null
    private var bar: ProgressBar? = null
    private var status: TextView? = null

    /**
     * Puts the cover on screen, with "getting ready" in it. Returns false if the system refused
     * the window; the run can still go on without it, just without the cover.
     */
    fun show(): Boolean {
        if (root != null) return true
        return try {
            // A service context carries no app theme. Borrow the app's so CardView and the
            // text colours follow light/dark mode like the rest of the app.
            val themed = ContextThemeWrapper(service, R.style.Theme_VolumeApp)
            val view = LayoutInflater.from(themed).inflate(R.layout.overlay_cache_clear, null)
            view.findViewById<View>(R.id.cacheStop).setOnClickListener { onStop() }
            val progress = view.findViewById<ProgressBar>(R.id.cacheProgress)
            val message = view.findViewById<TextView>(R.id.cacheStatus)
            message.setText(R.string.cache_overlay_preparing)
            windowManager.addView(view, windowParams())
            bar = progress
            status = message
            root = view
            true
        } catch (e: RuntimeException) {
            // Either the layout couldn't be inflated, or the system refused the window
            // (BadTokenException, e.g. while the service is being torn down). Nothing was added.
            false
        }
    }

    /** Shows that app number [done] + 1 of [total] is being worked on. */
    fun update(done: Int, total: Int, name: String) {
        val progress = bar ?: return
        progress.isIndeterminate = false
        progress.max = total
        progress.progress = done
        status?.text = service.getString(R.string.cache_overlay_progress, done + 1, total, name)
    }

    fun hide() {
        val view = root ?: return
        root = null
        bar = null
        status = null
        try {
            windowManager.removeView(view)
        } catch (e: RuntimeException) {
            // Already gone - the system drops overlay windows when a service stops.
        }
    }

    private fun windowParams() = WindowManager.LayoutParams(
        WindowManager.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
        PixelFormat.TRANSLUCENT
    ).apply {
        // Without this the cover stops short of a notch/punch-hole in landscape.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }
}
