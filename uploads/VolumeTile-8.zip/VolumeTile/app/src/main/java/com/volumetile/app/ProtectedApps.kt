package com.volumetile.app

import android.content.Context

/**
 * GCash, and any other app that refuses to run while an accessibility service it doesn't
 * recognise is switched on, plus the "paused" state that goes with stepping aside for them.
 *
 * GCash keeps an allow-list of accessibility services (its Device Security help page says only
 * the apps on that list may be enabled) and Volume Tile is not on it, so the two can only be
 * used together if this app's service is off while GCash is open. That is what the service does
 * when one of these apps opens: it switches itself off ([SystemActionService] pause) and stays
 * off until it is turned back on - by the Service tile, the paused notification, the app's
 * Resume button, or Settings > Accessibility.
 *
 * Plain SharedPreferences, like [BubblePrefs]. The service reads them each time it connects and
 * again when the app says the list changed ([SystemActionService.refreshProtection]).
 */
object ProtectedApps {

    /** GCash's package name: the list the person gets until they edit it. */
    const val DEFAULT_PACKAGES = "com.globe.gcash.android"

    private const val PREFS = "protected_apps"
    private const val KEY_ENABLED = "enabled"
    private const val KEY_PACKAGES = "packages"
    private const val KEY_PAUSED = "paused"

    /** What a package name looks like: two or more dot-separated words. Anything else is ignored. */
    private val NAME = Regex("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z][A-Za-z0-9_]*)+")

    /** Commas, semicolons, spaces and line breaks all separate package names. */
    private val SEPARATORS = Regex("[,;\\s]+")

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** On by default: someone whose GCash won't open should not have to find this switch first. */
    fun isEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_ENABLED, true)

    fun setEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_ENABLED, enabled).apply()
    }

    /** The list exactly as typed in the app, or [DEFAULT_PACKAGES] while it was never edited. */
    fun rawPackages(context: Context): String =
        prefs(context).getString(KEY_PACKAGES, null) ?: DEFAULT_PACKAGES

    fun setPackages(context: Context, raw: String) {
        prefs(context).edit().putString(KEY_PACKAGES, raw).apply()
    }

    /** The valid package names in [rawPackages], each once. Empty when the person cleared the list. */
    fun packages(context: Context): List<String> =
        rawPackages(context).split(SEPARATORS).filter { NAME.matches(it) }.distinct()

    /** True when protection is on and [packageName] is one of the listed apps. */
    fun matches(context: Context, packageName: String): Boolean =
        isEnabled(context) && packages(context).contains(packageName)

    /**
     * True from the moment the service switched itself off (for a protected app, or because the
     * person paused it) until it connects again. It lets the tiles and the app say "paused"
     * instead of "enable accessibility".
     */
    fun isPaused(context: Context): Boolean = prefs(context).getBoolean(KEY_PAUSED, false)

    /** Written with commit(): the process may be cleaned up right after the service pauses. */
    fun setPaused(context: Context, paused: Boolean) {
        prefs(context).edit().putBoolean(KEY_PAUSED, paused).commit()
    }
}
