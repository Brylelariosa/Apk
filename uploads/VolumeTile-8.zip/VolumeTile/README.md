# Volume Tile

A Quick Settings tile that opens a small volume-control panel — built as a
workaround for a broken physical volume button.

## What it does

- Adds a **Volume** tile to the Quick Settings shade (pull down notifications,
  tap edit/pencil icon, drag the tile in).
- Tapping the tile pops up the system volume panel, the same one the hardware
  buttons bring up. Nothing is launched, so a game in the foreground keeps running.
- The app icon on your home screen opens a panel with sliders for **Media, Ring,
  Notification, and Alarm** volume, so it also works as a standalone volume app.
- The tile subtitle shows the media volume as a percentage (refreshed each time
  the shade is opened).

## GCash (and other apps that won't run beside an accessibility service)

GCash only lets accessibility services from its own allow-list stay switched on while it runs.
Its Device Security help page says that every other one has to be turned off in Settings >
Accessibility. Volume Tile's service is not on that list, and there is no honest way to put it
there, so the fix is for the service to be **off while GCash is open**. Version 2.0 makes that cheap:

- **It steps aside by itself.** Under **Pause for GCash and similar apps** in the app (on by
  default, with GCash listed) the service listens for the windows of the listed apps - and of no
  other app, reading nothing from them - and when one opens, it switches itself off. It stays off
  until you turn it back on (below). The list takes package names separated by commas; an app's
  package name is the `id=` part of its Play Store link (GCash is `com.globe.gcash.android`).
- **Pause first, to be sure.** GCash runs its check while it starts, which can be before the
  service has heard that it opened, so the *first* open after the service was on can still be
  refused. Open it again and it works, because the service is off by then. To never see that,
  pause first: tap the **Service** tile (pause icon) in Quick Settings, or **Pause service** in
  the menu behind the nav-bar button or a tap on the bubble.
- **Turning it back on.** Tap the **Service** tile (or any greyed Screenshot / Power menu tile),
  the **Resume** button on the "Volume Tile is paused" notification, or the banner button in the
  app. Without the one-time setup below, each of them opens Accessibility settings, where you
  switch **Volume Tile** on. With it, they switch it on in place.
- **One-time setup for one-tap resume (optional).** Android only lets an app switch its own
  accessibility service on after it has been granted `WRITE_SECURE_SETTINGS`. From a computer
  with adb:

  ```
  adb shell pm grant com.volumetile.app android.permission.WRITE_SECURE_SETTINGS
  ```

  The app has a **Set up one-tap resume** button that explains this and copies the command. The
  grant stays after USB debugging is turned off again, and you should turn **Developer options and
  USB debugging off before opening GCash**: its help page lists them as another reason it refuses
  to run. The same permission lets the app revive a service that Android stopped, instead of
  asking you to flip the switch in Settings. Other accessibility services in the list (TalkBack,
  say) are carried over untouched.
- **What still works while it is paused.** Everything that needs no accessibility service: the
  Volume tile, the new **Louder**, **Quieter** and **Mute** tiles, and the sliders in the app.
  Screenshot, Power menu, Screen off, the nav-bar button and the bubble need the service, so
  they wait for the resume.
- If GCash still refuses with the service off, the same help page lists the other things it
  checks: Developer options, USB debugging, installing from unknown sources and cloned apps.

## Extra tiles: Screenshot, Shade shot, Power menu

Built for the same reason as the Volume tile: no working hardware buttons
needed.

| Tile | What it does |
|------|--------------|
| **Screenshot** | Collapses the shade, then takes a normal screenshot of whatever is underneath. Nothing is launched, so a game in the foreground keeps running. |
| **Shade shot** | Takes the screenshot with the notification shade left open, so the notification area is what gets captured. Single frame only, it never scrolls. |
| **Power menu** | Opens the system power menu (Power off / Restart), same as holding the power button. |

Android only lets an app do this through an accessibility service, so there is
a one-time setup:

1. Add the tiles: pull down the shade, tap the edit/pencil icon, drag them in.
2. Tap any of them (or the **Enable accessibility** button in the app). It
   opens Settings > Accessibility; turn on **Volume Tile**.
3. On Android 13+, a sideloaded APK may have that toggle greyed out. Fix: App
   info > ⋮ > **Allow restricted settings**, then try again.

Apart from the cache clean-up (see "Clear cache" below), the service subscribes to no events and
does not read window content; it only performs the action behind the tile you tapped. Screenshot and Shade shot need
Android 9+. Power menu works on every supported version. Until the service is
on, these tiles show greyed out with a "Tap to enable" hint.

**Screen off** has no tile of its own: it is an entry in the menu (nav-bar button, or a tap on
the bubble) and, by default, the bottom icon of the bubble's arc. It turns the screen off and
locks the phone, the same as the power button, through the same accessibility service (Android
9+). It waits about 0.15 s after you pick it so the pick animation can finish.

## More tiles: Service, Louder, Quieter, Mute

| Tile | What it does |
|------|--------------|
| **Service** | Pauses the accessibility service (highlighted = running), or switches it back on (see the GCash section). It works whatever the service is doing, because a tile is not part of the service. A stopped service is revived the same way. |
| **Louder** | One step up on the media volume, or straight to the level set in the app. Tap it again to keep going; the system volume panel shows the level. |
| **Quieter** | The same, downwards. It stops at level 1; Mute is the way to silence the phone. |
| **Mute** | Mutes or unmutes the media volume. It lights up while muted. |

Louder, Quieter and Mute never touch the accessibility service, so they work while it is paused
for GCash or switched off. Add them like the others: pull down the shade, tap the pencil, drag
them in.

## Accessibility button menu (navigation bar)

The person-icon button in the navigation bar opens a small menu of everything this
app can do: **Volume, Louder, Quieter, Mute, Screenshot, Shade shot, Power menu, Screen off, Floating, Pause service**. Tap an entry to run
it; tap outside the card (or **Cancel**) to close it. Tapping the floating bubble (next
section) opens the same menu. The card fades and grows in.

- **Floating** shows the floating bubble. It carries an **On** tag while the bubble is
  showing; pick it again to hide the bubble, and a short message says how to bring it back.
  It is the same switch as **Floating bubble** in the app, so the two always agree.

- The menu is kept compact: a narrow card with one slim row per action, so it covers
  as little of the app underneath as possible. Screen readers still announce each
  action's one-line description even though it isn't drawn.
- The menu is an overlay window, not an activity, so a game in the foreground keeps
  running underneath it. It needs no extra permission.
- It rides on the same accessibility service as the Screenshot / Power menu tiles, so
  the one-time setup is the same: turn on **Volume Tile** in Settings > Accessibility.
  After installing an update, check the toggle is still on - some phones switch
  accessibility services off when their app is replaced.
- If another accessibility feature is also assigned to the button, Android shows its own
  list first: pick **Volume Tile**. To change what the button does, open Settings >
  Accessibility > Volume Tile and look for its shortcut setting (wording varies by phone).
- Games that hide the navigation bar hide the button too: swipe to bring the bar back,
  then tap the button.
- From the menu, **Shade shot** pulls the notification shade down by itself and then
  captures it (the tile version expects the shade to be open already - the tile lives in it).
- Volume uses the system volume panel, the same as the Volume tile, so the sliders in the
  app itself are not needed for this.
- **Louder**, **Quieter** and **Mute** stand in for the hardware volume keys: one step up or
  down on the media volume, or mute / unmute it, with the system volume panel showing the new
  level. They need no accessibility service, don't launch anything, and can sit on any icon of
  the bubble's arc (pick them in the app, under the Floating bubble switch). They are built not
  to leave the phone silent by accident: Quieter stops at level 1 (Mute is the way to silence
  it), and Louder / unmute lift a volume of 0 to about a third of the way up. Two sliders in
  the app, under the four volume sliders, set what Quieter and Louder do: far left is one step
  at a time, anywhere else makes the button jump straight to that media level.

## Floating bubble (hold, then slide to an icon)

A small bubble that floats on top of every app. Switch it on with **Floating bubble** in
the app, or by choosing **Floating** in the accessibility-button menu. It pops in on the
right-hand edge at first.

| Gesture | What it does |
|---------|--------------|
| **Tap** | Opens the action menu (the same one as the nav-bar button). |
| **Hold** | After a moment (the phone's own "touch and hold" delay, usually 0.4 s, never under 0.25 s) the bubble buzzes and a **C** of icons springs out around it. Without lifting the finger, slide towards an icon: it swells, turns purple and shows its name. Lift the finger to run it. |
| **Drag** | Moves the bubble. It settles against the nearest side of the screen and remembers where you left it. |

To call a pick off, slide back to the bubble or towards the screen edge it rests against
(where there is no icon) and lift the finger: nothing runs.

Default icons, top to bottom (change any of them under the switch, or set one to
**Nothing**; the icons that remain close up):

| Icon | Default action |
|------|----------------|
| 1st (top) | Volume (the system volume panel) |
| 2nd | Power menu |
| 3rd | Screenshot |
| 4th | Shade shot |
| 5th (bottom) | Screen off |

- The icons sit close to the bubble (60 dp from its centre, 42 dp wide; they used to be 88 and
  46). With five icons next to a screen edge the C spans about 180 degrees; fewer icons make a
  shorter C at the same distance.
- The C always opens towards the middle of the screen (a backwards C when the bubble sits
  on the left). Near the top or bottom edge, or on a short landscape screen, the whole arc
  turns just far enough to stay on screen; a bubble parked in a corner gets its icons
  packed a little closer. Every icon is always reachable.
- Only the direction of the slide counts, not how far it goes, so a short flick is enough
  (it must move about 28 dp first, so a wobbling finger can't run anything).
- Animation: the bubble pops in and out and grows a little under the finger. Holding fans the
  icons out along the curve (the middle ones first, each springing a little past its place)
  over a dark curved track. Sliding towards an icon makes it spring up in size, turn purple and
  send a ring rippling out of it; its neighbours slide aside to make room, the other icons dim
  a little, and it shows its name. Slide on to the next icon and all of that moves with you.
  On release the others fold back into the bubble while the picked one pops. The arc keeps its
  own frame clock, so these play at full speed even where the phone's animation scale
  (Settings > Developer options) is off, or battery saver has switched animations off. (The
  bubble's own pop and grow still follow that setting.)
- The arc is a second overlay window that cannot be touched and is only as big as the arc
  itself, so the app underneath keeps running and keeps getting its touches. It is gone
  well before a screenshot is taken, and the bubble hides itself for about a second around
  a screenshot, so neither is in the picture.
- It is another window of the same accessibility service, so there is nothing extra to
  allow: if the Screenshot / Power tiles work, the bubble works. Turn the switch on first
  and the bubble appears as soon as **Volume Tile** is switched on in Accessibility.
- On phones with gesture navigation the bubble stays clear of the edge-swipe "back" zone
  (and asks the system to leave touches on it alone).
- Like the nav-bar button it lives and dies with the service, so the **Keep the service
  running** checkbox and the battery exemption (next section) keep the bubble alive too.
- Upgrading from the swipe version: the four old swipe choices carry over (up, right, left
  and down become icons 1 to 4), so nothing you set is lost.

## If the nav-bar button stops working after a few hours

Symptom: the button (and the Screenshot / Power tiles) work, then hours later do nothing
until **Settings > Accessibility > Volume Tile** is switched off and on again.

Cause: the phone's memory killer, or the maker's battery / memory cleaner (Infinix XOS is
aggressive), cleaned up the idle app process and left the service switched on in Settings but
no longer running. An app can't restart its own accessibility service; only Settings can.

What the app does about it, with no cost while idle (the service subscribes to no events and
nothing runs on a timer, so there is no polling, no wake lock and no wake-ups):

- **Keep-alive.** The service runs as a foreground service, which the system and the cleaners
  leave alone. The price is one silent notification: minimum importance, so no status-bar icon
  and no sound, and hidden on the lock screen. The checkbox **Keep the service running** in the
  app turns it off. (`KeepAlive.kt`)
- **Never crashes its own process.** A process that keeps crashing is marked as misbehaving and
  Android stops restarting its services, which looks exactly like the symptom above. Every
  entry point of the service (button tap, tile action, chooser pick, delayed screenshot) is
  wrapped, and the chooser's layout inflation is inside its try block.
- **Says so when it happens anyway.** The app shows a banner (*Service stopped by Android, tap,
  then switch Volume Tile off and on*), and a tile tapped in that state says the same and jumps
  to Accessibility settings, instead of the old "Service is starting" forever. A freshly
  restarted process gets 8 seconds to be rebound before it counts as stopped.
- **Battery exemption.** The app offers a one-tap *Allow background running* button until it
  is exempt from battery optimisation.

If it still happens, the phone's own cleaner is the likely cause. On Infinix / Tecno (XOS /
HiOS; menu names vary by version): allow Volume Tile under Phone Master > Autostart (or the
app's own Battery / Background settings), and lock it in the Recents screen.

## Ring volume note

Android requires "Do Not Disturb access" before an app can move Ring volume
to/through silent. If you drag the Ring slider to 0 and it's blocked, a
**Grant Do Not Disturb access** button appears — tap it once, allow access in
Settings, and it won't ask again.

## Building

Your build log shows this is actually built through your existing
zip-upload pipeline (the `Apk` repo / ZipApkBuilder), not the
`.github/workflows/build.yml` included here — that workflow is just a
ready-to-go alternative if you ever push this as its own standalone repo.

The pipeline's "Fetch gradle-wrapper.jar" step has been reliably producing
a jar with no `MANIFEST.MF` Main-Class entry (`no main manifest attribute`
when `gradlew` tries `-jar` on it) — reproduced twice with the identical
byte count, so it's not a one-off. `gradlew` here uses `-classpath
gradle-wrapper.jar org.gradle.wrapper.GradleWrapperMain` instead of `-jar`,
which specifies the main class directly and doesn't need a manifest at
all — the same technique your `FloatNote` project's `gradlew` already
uses against this same pipeline. The real, robust fix is still to change
the pipeline's "Build APK" step to call the already-provisioned `gradle`
directly instead of `./gradlew` (see below); this is a workaround for
until that's changed, or if you'd rather not touch the pipeline.

## Known pipeline issue

In the `Brylelariosa/Apk` repo's workflow, the "Build APK" step runs
`./gradlew assembleRelease`/`assembleDebug`. The earlier "Setup Gradle"
step already provisions a working `gradle` binary and puts it on `PATH`
(`gradle/actions/setup-gradle@v3`), so swapping `./gradlew` for `gradle`
in that step removes the dependency on the broken jar-fetch entirely, and
the "Fetch gradle-wrapper.jar" and "Make gradlew executable" steps become
unnecessary.

## Clear cache, for every app (by hand, and every day)

A **Clear cache** entry in the menu (nav-bar button, or a tap on the bubble), a **Clear cache** tile
and **Clear cache now** in the app all do the same thing: clear the cache of every installed app -
other apps, and disabled apps too - without root and without Shizuku. **Auto clear cache** in the
app does it by itself every day at a time you choose.

How: Android gives an app no call to clear another app's cache, so the accessibility service does
it the way you would. For each app it opens that app's page in Settings (App info opens for
disabled apps too), taps **Storage & cache**, then **Clear cache**. A dimmed cover shows the
progress, keeps the screen on, keeps stray touches out of Settings and has a **Stop** button.

- **The service now reads Settings.** `canRetrieveWindowContent` is on for this one job: it reads
  the Settings window while a clean-up runs, and no other window, ever. The service description in
  Settings > Accessibility says so. With the service off, none of this works.
- **Awake and unlocked.** Settings cannot be driven from a lock screen. If the set time comes while the
  phone is locked or the screen is off, the run waits and starts about 5 seconds after you next
  unlock (a waiting run older than 12 hours is dropped). It never wakes or unlocks the phone.
- **Usage access (optional, much faster).** Allow Volume Tile under Settings > Apps > Special app
  access > Usage access; the button in the app opens it. The clean-up then knows how much cache each
  app has, visits only the ones that have some (biggest first) and can say roughly how much it freed.
  Without it every installed app is visited, which can take several minutes.
- **Afterwards** a toast and a quiet notification say what happened, and "Last run" in the app keeps it.
- **Only two things are ever tapped:** the Storage entry and the **Clear cache** button, each found
  by its exact label (read from Settings' own strings when possible, so any language works, with the
  English words as a backup). Never Clear storage, Force stop, Uninstall or Disable.
- **It stops** on Stop, when the screen turns off, after 25 minutes, when Settings will not open,
  or when the Storage screen cannot be found. In that last case the message lists the first texts
  the screen showed: send them along and the wording can be added.
- **The time** is a daily alarm. It is exact where Android allows (always before Android 12; from 12 on
  only if "Alarms & reminders" is allowed for the app) and otherwise may slip by some minutes. It is
  booked again after a restart, an app update, and a clock or time-zone change.
- Volume Tile's own cache is simply deleted, with no tapping.
- This is what Settings' own **Clear cache** button does: it removes temporary files, not accounts
  or settings. Apps can start a little slower while they rebuild their cache, and an app that keeps
  downloaded files in its cache folder (a few do) will fetch them again.

## Project layout

```
app/src/main/java/com/volumetile/app/
  VolumeTileService.kt      — the Volume Quick Settings tile: pops up the system volume
                               panel (name must not change, or its place in the shade is lost)
  VolumeControlActivity.kt  — the launcher activity: volume sliders, the accessibility /
                               battery / keep-alive banners and the bubble settings
  VolumeLevels.kt           — what Louder and Quieter do: one step, or a media level
                               chosen in the app (saved settings)
  BaseTileService.kt        — shared tile plumbing (state render, collapse+launch)
  ActionTiles.kt            — ActionTileService base + Screenshot / Shade shot /
                               Power menu tiles (one line each), the Service (pause /
                               resume) tile and the Louder / Quieter / Mute tiles
  SystemAction.kt           — the actions the tiles, the chooser and the bubble can fire
                               (label, hint, icon, min Android version, whether it may sit on
                               the bubble's arc) + where a request came from
  SystemActionService.kt    — accessibility service that performs them, receives the
                               nav-bar accessibility button taps and hosts the floating
                               bubble; guards every entry point and reports connected /
                               stalled state; switches itself off when a protected app opens
  KeepAlive.kt              — runs that service as a silent foreground service so the
                               system leaves its process alone (checkbox in the app)
  ProtectedApps.kt          — GCash and the other apps the service steps aside for (saved
                               list and on/off switch) and the saved "paused" flag
  ServiceSwitch.kt          — switches the service on / off through the system setting, once
                               the one-time WRITE_SECURE_SETTINGS permission is granted
  PauseNotice.kt            — the "Volume Tile is paused" notification (+ Resume button)
  ResumeReceiver.kt         — what that Resume button runs
  ActionChooserOverlay.kt   — the compact menu opened by that button or by a tap on the
                               bubble (overlay window); marks switched-on entries (Floating)
  FloatingBubble.kt         — the bubble: overlay window + tap / hold / drag gestures and
                               its own pop-in / grow animations
  ArcMenu.kt                — the C of icons that fans out while the bubble is held: its
                               overlay window, drawing and animations (own frame clock, see
                               the Tween class at the bottom)
  ArcLayout.kt              — pure geometry for that arc: where each icon goes (turning or
                               packing it to stay on screen) and which one a finger points at
  ArcSlot.kt                — the five places on the arc, top to bottom, and each one's
                               default action (and the old swipe setting it replaced, for
                               the first four)
  BubblePrefs.kt            — saved bubble settings: on/off, position, action per arc slot
  ContextExt.kt             — Context.toast(), dpToPx(), showSystemVolumePanel(),
                               stepMediaVolume() and toggleMediaMute()
  CacheCleaner.kt           — the cache clean-up: walks Settings through the accessibility
                               service, app by app (Storage & cache > Clear cache)
  CacheOverlay.kt           — the dimmed cover with progress and Stop shown while it runs
  CacheScheduler.kt         — the daily alarm behind "Auto clear cache"
  CacheAlarmReceiver.kt     — that alarm going off, and re-booking it after a restart,
                               update or clock change
  CachePrefs.kt             — saved settings: on/off, time of day, a waiting run, last result
  CacheNotice.kt            — the notification that says what a run did
app/src/main/res/           — layouts (panel, chooser + its rows, arc pickers), strings,
                               icons, xml/ (accessibility config)
gradlew                     — classpath-style wrapper script (see Building)
gradlew.bat, gradle/wrapper/ — rest of the standard Gradle wrapper, pinned to
                               Gradle 8.9
.github/workflows/build.yml — alternate CI build, only used if pushed as its
                               own repo with Actions enabled. It builds a debug APK, which
                               installs as it is (the pipeline builds its own)
AUDIT.md                    — findings of the 1.7 audit and what is still open
```

## Changes in 2.1

From a request to clear the cache of other apps - disabled ones too - automatically, at a time
you set, with no root and no Shizuku.

- **Auto clear cache** in the app: a switch and a time of day. A daily alarm starts the clean-up; if
  the phone is locked then, it runs when you next unlock.
- **Clear cache** as a menu entry, a bubble-arc icon, a Quick Settings tile and a **Clear cache now**
  button in the app. All of them run the same clean-up.
- **Usage access** (optional): lets the clean-up skip apps that have no cache, which turns a run of
  several minutes into about one, and lets it report roughly how much it freed.
- The accessibility service can now read window content, used only for this (see above). Its
  description in Settings > Accessibility says so.
- New permissions: `QUERY_ALL_PACKAGES` (to list every app, disabled ones too), `PACKAGE_USAGE_STATS`
  (optional, the Usage access switch), `RECEIVE_BOOT_COMPLETED` and `SCHEDULE_EXACT_ALARM` (the alarm).
- Version 2.1 (versionCode 12).
- Not compiled or run here (no Gradle or Android SDK), and the Settings screens it taps could not be
  looked at: `AUDIT.md` says what was checked by hand and what to try first on the phone.

## Changes in 2.0

From a report that GCash would not open while the accessibility service was on.

- **GCash fix.** The service switches itself off when GCash (or any app in the list in the app)
  opens, and says so in a notification. New **Service** tile and **Pause service** menu entry to
  pause it first, which never loses the race with GCash's own check. See the GCash section above
  for how it works, what it cannot do (the first open can still be refused) and the optional
  one-time adb step for one-tap resume.
- **One-tap resume and self-heal** (optional, needs the adb permission): the Service tile, the
  greyed tiles, the notification's Resume button and the banner button switch the service back on
  in place, and revive one that Android stopped. Without the permission they open Accessibility
  settings as before.
- **New tiles:** Louder, Quieter and Mute, one per hardware volume key. They need no accessibility
  service.
- The banner and the greyed tiles say "paused" when the service stepped aside on purpose, instead
  of "enable accessibility".
- The service description in Settings > Accessibility now says it notices when GCash opens.
- The app asks once for the notification permission on Android 13+ (for the paused notice).
- `.github/workflows/build.yml` builds an installable debug APK (it used to build an unsigned
  release APK and then fail to find it).
- Not compiled or run here (no Gradle or Android SDK); the pipeline build is the first compile.
  `AUDIT.md` lists what was checked by hand and what to try on the phone.

## Changes in 1.9

- **Set what Quieter and Louder do.** Two sliders in the app (under the four volume sliders)
  choose the media level each button jumps to; far left, "One step", keeps the one-step
  behaviour. A chosen level also unmutes first.

## Changes in 1.8

From a report that the media sound went silent and only came back after restarting the phone
(sometimes by scrolling a video feed fast, which starts new audio players).

- **Quieter** stops at level 1 instead of going to 0; **Mute** is the way to silence the phone.
- **Louder** unmutes first, and lifts a volume of 0 to about a third of the way up, so one tap
  from silence is audible.
- **Mute** now asks whether the media stream is muted and mutes or unmutes explicitly, instead of
  flipping a toggle it cannot see; unmuting at level 0 lifts it the same way.
- Not compiled or run here (no Gradle or Android SDK); the pipeline build is the first compile.
  If the sound still dies after this, that points to the phone's audio output rather than the
  volume settings.

## Changes in 1.7

From a full code audit (see `AUDIT.md` for the findings and the open items).

- **Louder / Quieter / Mute** actions (menu and bubble arc): the hardware volume keys' job.
- **Never crashes its own process, continued.** The bubble's touch handling, the hold-to-open
  runnable and the arc's frame callback now fail safe like the service's entry points do; a
  failure drops the gesture or ends the animation instead of killing the process. Registering the
  nav-bar button can no longer abort the service's start-up (and with it the keep-alive and bubble).
- **Keep-alive re-armed** whenever the app is opened (the app being on screen is the one moment a
  foreground start can't be refused), in case a start was refused while the phone sat idle.
- **Smoother bubble drag:** the window is moved at most once per frame instead of once per touch
  event, and not at all when the position didn't change.
- **Settings pickers** no longer overwrite a saved choice that this Android version can't run.
- The gear next to Volume Tile in Settings > Accessibility now opens the app; the four volume
  sliders have spoken names for TalkBack.
- README and code comments no longer say the Volume tile opens the slider panel.

## Size optimizations

The release build (what CI produces) is shrunk without dropping any
functionality:

- R8 minification + resource shrinking enabled (was off)
- Removed two dependencies that were pulled in but never actually used
  in the code (Material Components, core-ktx)
- Bundled resources restricted to English, dropping ~70 unused translated
  string sets that AppCompat/CardView ship internally
- Signed by your pipeline's real release keystore (it injects one via
  `-Pandroid.injected.signing.*` properties when the `KEYSTORE_B64` secret is
  set) — the build no longer overrides that with the debug key, so future
  updates install over each other normally instead of needing a reinstall

Stack traces from a release-build crash still show real file/line info
(kept explicitly in `proguard-rules.pro`) despite the obfuscation.

Your pipeline builds `assembleDebug` automatically when no keystore secret
is configured, and `assembleRelease` when one is — nothing to trigger
manually.

