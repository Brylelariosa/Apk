package com.photopuzzle.game.puzzle

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Shader
import androidx.core.content.ContextCompat
import com.photopuzzle.game.R
import kotlin.math.roundToInt

/**
 * Draws a [PuzzlePiece]'s backside: a plain kraft-paper look, deliberately
 * distinct from the photo front.
 *
 * Reuses [PuzzlePiece.drawSilhouette] the same way [PuzzleBoardView]
 * already does for the front border and the thickness sliver, so the back
 * always traces the exact same jigsaw silhouette as the front -- no
 * separate geometry to keep in sync.
 *
 * The "material" is one small tile bitmap, built once in [buildTileShader]
 * and shared by every piece and every frame via [fillPaint]'s
 * [BitmapShader] -- never a per-piece bitmap.
 */
internal class PieceBackRenderer(context: Context, density: Float) {

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        shader = buildTileShader(context, density)
    }
    private val rimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = RIM_STROKE_DP * density
        strokeJoin = Paint.Join.ROUND
        color = ContextCompat.getColor(context, R.color.colorPieceEdgeShade)
    }

    /** [canvas] must already be translated to this piece's own origin --
     * same requirement as [PuzzlePiece.drawSilhouette] itself. */
    fun draw(canvas: Canvas, piece: PuzzlePiece) {
        piece.drawSilhouette(canvas, fillPaint)
        piece.drawSilhouette(canvas, rimPaint)
    }

    /**
     * One small tile, repeated via [Shader.TileMode.REPEAT], stands in for
     * a per-piece backside bitmap: a plain base tone plus a single
     * edge-to-edge diagonal for a subtle kraft-paper hatch. A single
     * diagonal per tile is enough -- repeating the same tile continues the
     * same family of parallel stripes seamlessly across every tile
     * boundary, no wrapped extra copies needed.
     */
    private fun buildTileShader(context: Context, density: Float): BitmapShader {
        val size = (TILE_DP * density).roundToInt().coerceAtLeast(MIN_TILE_PX)
        val tile = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val tileCanvas = Canvas(tile)
        tileCanvas.drawColor(ContextCompat.getColor(context, R.color.colorPieceBackBase))

        val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = ContextCompat.getColor(context, R.color.colorPieceBackLine)
            strokeWidth = size * HATCH_STROKE_FRACTION
        }
        val s = size.toFloat()
        tileCanvas.drawLine(0f, s, s, 0f, linePaint)

        return BitmapShader(tile, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
    }

    private companion object {
        const val TILE_DP = 22f
        const val MIN_TILE_PX = 12
        const val HATCH_STROKE_FRACTION = 0.16f
        const val RIM_STROKE_DP = 1f
    }
}
