package com.photopuzzle.game.puzzle.render3d

/**
 * The result of [PieceMeshBuilder.build]: a piece's silhouette extruded
 * into a solid -- front cap, back cap, and connecting side wall -- as flat
 * arrays ready to hand to OpenGL. Deliberately has no `android.opengl` (or
 * any other GL) import: building this mesh is pure geometry, so it can run
 * on any thread, including one that has no GL context bound to it, which is
 * what lets [Piece3DView] build it on the
 * caller's thread and only hand the result to the GL thread for upload.
 *
 * [vertexData] is interleaved per vertex as: position.xyz, normal.xyz,
 * uv.xy, faceId (see the byte-offset constants below for wiring this to
 * `glVertexAttribPointer`). [faceId] tells the fragment shader which
 * material to use -- see [FACE_FRONT], [FACE_BACK], [FACE_WALL] -- rather
 * than needing separate draw calls or programs per face.
 *
 * [indices] indexes into [vertexData] (i.e. index N refers to the vertex
 * starting at float offset `N * FLOATS_PER_VERTEX`), grouped in triples,
 * one per triangle. Piece meshes stay well under 65536 vertices even at
 * generous sampling, so 16-bit indices are always enough.
 *
 * The mesh is centered on the piece's own bounding-box center, so rotating
 * it in place (see `Piece3DRenderer`) doesn't need a separate pivot
 * translation. [boundingRadius] is the resulting distance from that center
 * to the farthest vertex, for a camera to frame the whole piece regardless
 * of how big or small the source piece bitmap was.
 */
internal class PieceMeshData(
    val vertexData: FloatArray,
    val indices: ShortArray,
    val boundingRadius: Float
) {
    companion object {
        const val FACE_FRONT = 0.0f
        const val FACE_BACK = 1.0f
        const val FACE_WALL = 2.0f

        const val POSITION_COMPONENTS = 3
        const val NORMAL_COMPONENTS = 3
        const val UV_COMPONENTS = 2
        const val FACE_ID_COMPONENTS = 1
        const val FLOATS_PER_VERTEX =
            POSITION_COMPONENTS + NORMAL_COMPONENTS + UV_COMPONENTS + FACE_ID_COMPONENTS

        private const val BYTES_PER_FLOAT = 4
        const val POSITION_OFFSET_BYTES = 0
        const val NORMAL_OFFSET_BYTES = POSITION_OFFSET_BYTES + POSITION_COMPONENTS * BYTES_PER_FLOAT
        const val UV_OFFSET_BYTES = NORMAL_OFFSET_BYTES + NORMAL_COMPONENTS * BYTES_PER_FLOAT
        const val FACE_ID_OFFSET_BYTES = UV_OFFSET_BYTES + UV_COMPONENTS * BYTES_PER_FLOAT
        const val STRIDE_BYTES = FLOATS_PER_VERTEX * BYTES_PER_FLOAT
    }
}
