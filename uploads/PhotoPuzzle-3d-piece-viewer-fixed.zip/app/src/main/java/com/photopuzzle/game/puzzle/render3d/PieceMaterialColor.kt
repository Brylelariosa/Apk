package com.photopuzzle.game.puzzle.render3d

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color

/**
 * Color sampling shared by every GLES renderer in this package -- reading
 * a fixed resource color as GL-ready [0..1] floats, and approximating a
 * piece's own "material" tone from its texture so a piece's rim/edge can
 * relate to its own photo instead of using one fixed color for every piece
 * regardless of what photo it's cut from. Originally lived only on
 * [Piece3DRenderer]; pulled out here once [PuzzleBoard3DRenderer] needed
 * the exact same logic, rather than a second copy of it.
 */
internal object PieceMaterialColor {

    fun readColorRgb(context: Context, colorRes: Int): FloatArray {
        val color = context.getColor(colorRes)
        return floatArrayOf(Color.red(color) / 255f, Color.green(color) / 255f, Color.blue(color) / 255f)
    }

    /**
     * Approximates [bitmap]'s overall color by averaging a coarse grid of
     * samples across it -- a few dozen pixel reads rather than a full
     * per-pixel scan, which is plenty for a rim color that only needs to
     * feel like it belongs to the piece, not reproduce its exact palette.
     */
    fun averageColor(bitmap: Bitmap, fallback: FloatArray): FloatArray {
        val stepsX = COLOR_SAMPLE_GRID.coerceAtMost(bitmap.width)
        val stepsY = COLOR_SAMPLE_GRID.coerceAtMost(bitmap.height)
        if (stepsX <= 0 || stepsY <= 0) return fallback

        var rSum = 0L
        var gSum = 0L
        var bSum = 0L
        for (sx in 0 until stepsX) {
            for (sy in 0 until stepsY) {
                val x = ((sx + 0.5f) / stepsX * bitmap.width).toInt().coerceIn(0, bitmap.width - 1)
                val y = ((sy + 0.5f) / stepsY * bitmap.height).toInt().coerceIn(0, bitmap.height - 1)
                val pixel = bitmap.getPixel(x, y)
                rSum += Color.red(pixel)
                gSum += Color.green(pixel)
                bSum += Color.blue(pixel)
            }
        }
        val count = stepsX * stepsY
        return floatArrayOf(rSum.toFloat() / count / 255f, gSum.toFloat() / count / 255f, bSum.toFloat() / count / 255f)
    }

    /**
     * Turns an [averageColor] sample into a rim color: keeps that color's
     * hue -- so the piece's cut edge feels like the same material as its
     * face, not an unrelated decoration wrapped around it -- but pins
     * saturation/brightness to the same values [R.color.colorPieceThickness]
     * (see colors.xml) was tuned at. A photo that's very dark, very
     * bright, or nearly grayscale still gets a rim with the same legible
     * weight the original fixed color had, rather than one that
     * disappears into the background or blows out to white. [fallback] is
     * used as-is for a near-grayscale [sample], whose hue is essentially
     * noise (red, green, and blue too close together to say which
     * direction is "the" color).
     */
    fun materialRimColor(sample: FloatArray, fallback: FloatArray): FloatArray {
        val hsv = FloatArray(3)
        Color.RGBToHSV(
            (sample[0] * 255f).toInt().coerceIn(0, 255),
            (sample[1] * 255f).toInt().coerceIn(0, 255),
            (sample[2] * 255f).toInt().coerceIn(0, 255),
            hsv
        )
        if (hsv[1] < MIN_SOURCE_SATURATION) return fallback
        hsv[1] = RIM_SATURATION
        hsv[2] = RIM_VALUE
        val rgb = Color.HSVToColor(hsv)
        return floatArrayOf(Color.red(rgb) / 255f, Color.green(rgb) / 255f, Color.blue(rgb) / 255f)
    }

    private const val COLOR_SAMPLE_GRID = 8
    private const val MIN_SOURCE_SATURATION = 0.08f
    private const val RIM_SATURATION = 0.5f
    private const val RIM_VALUE = 0.68f
}
