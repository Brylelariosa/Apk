package com.photopuzzle.game.puzzle

/**
 * The four sides of a grid piece, and the (row, col) step to the
 * neighboring cell across each one.
 *
 * Previously each of [PuzzlePieceFactory] (which edge gets which
 * tab/blank) and [PuzzleGame] (grid adjacency for connecting) defined its
 * own private notion of "which side is which" -- two copies that could
 * silently drift apart. One shared definition here, also used by
 * [PuzzlePiece] (per-side outlines) and [PuzzleBoardView] (deciding which
 * of a piece's borders to draw), keeps grid geometry and piece geometry
 * talking about sides the same way everywhere.
 */
internal enum class PieceSide(val rowDelta: Int, val colDelta: Int) {
    TOP(-1, 0), RIGHT(0, 1), BOTTOM(1, 0), LEFT(0, -1)
}
