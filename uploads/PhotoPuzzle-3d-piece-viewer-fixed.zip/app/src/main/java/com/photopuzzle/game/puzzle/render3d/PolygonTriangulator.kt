package com.photopuzzle.game.puzzle.render3d

import android.graphics.PointF
import kotlin.math.abs

/**
 * Ear-clipping triangulation of a simple (non-self-intersecting), hole-free
 * polygon -- specifically, a jigsaw piece's silhouette. A piece's tab/blank
 * knobs (see `PieceEdgeShape`) make that silhouette neither convex nor
 * reliably star-shaped from its own centroid, so a plain centroid fan can't
 * be trusted to stay inside the shape; ear clipping handles any simple
 * polygon, knobs and all.
 *
 * Before this was written, the exact same algorithm (same epsilons, same
 * degenerate-triangle handling) was prototyped in Python and run against
 * every piece a real game can produce -- all four difficulty grid sizes,
 * many random seeds, every row/column position (corner/edge/interior) --
 * checked for a simple output polygon and for triangle-area coverage
 * matching the source polygon's own area. All cases passed using 32-bit
 * float arithmetic (matching Kotlin's [Float], not Python's default
 * float64), which is what fixed the epsilon values below.
 */
internal object PolygonTriangulator {

    /**
     * [orderedPoints] is [points], reversed first if needed so it's always
     * wound counter-clockwise -- callers that need consistent outward
     * normals (see [PieceMeshBuilder]) can rely on that winding without
     * separately checking it themselves. [triangleIndices] is a flat list
     * of index triples into [orderedPoints] (size is always a multiple of
     * 3): read it as `(triangleIndices[0], [1], [2])`, `([3], [4], [5])`,
     * and so on.
     */
    class Result(val orderedPoints: List<PointF>, val triangleIndices: List<Int>)

    fun triangulate(points: List<PointF>): Result {
        val n = points.size
        if (n < 3) return Result(points, emptyList())

        val ordered = if (signedArea(points) < 0f) points.asReversed() else points
        val triangles = ArrayList<Int>((n - 2).coerceAtLeast(0) * 3)

        // The shrinking working polygon, as indices into `ordered`. Ears are
        // clipped from this list (never from `ordered` itself) until only
        // one triangle's worth of vertices is left.
        val remaining = ArrayList<Int>(n)
        for (i in 0 until n) remaining.add(i)

        var guard = 0
        val maxGuard = n * n + 64 // generous; only here to guarantee termination on bad input
        while (remaining.size > 3 && guard < maxGuard) {
            guard++
            var clippedThisPass = false
            var i = 0
            while (i < remaining.size) {
                val m = remaining.size
                val iPrev = remaining[(i - 1 + m) % m]
                val iCurr = remaining[i]
                val iNext = remaining[(i + 1) % m]
                val a = ordered[iPrev]
                val b = ordered[iCurr]
                val c = ordered[iNext]
                val cr = cross(a, b, c)

                if (cr >= -REFLEX_EPSILON && isEar(ordered, remaining, iPrev, iCurr, iNext, a, b, c)) {
                    // A near-zero cross product means this "ear" is really
                    // just three near-collinear boundary points (common
                    // along a piece's flat/straight runs) -- clip the
                    // middle vertex out of the working polygon either way
                    // (the algorithm needs that to keep progressing), but
                    // don't emit a triangle with no real area to draw.
                    if (abs(cr) > MIN_TRIANGLE_CROSS) {
                        triangles.add(iPrev); triangles.add(iCurr); triangles.add(iNext)
                    }
                    remaining.removeAt(i)
                    clippedThisPass = true
                    break
                }
                i++
            }
            // No ear found this pass would mean degenerate input (points
            // that aren't actually a simple polygon); stop rather than
            // spin, and hand back whatever triangulated cleanly so far.
            if (!clippedThisPass) break
        }
        if (remaining.size == 3) {
            val a = ordered[remaining[0]]
            val b = ordered[remaining[1]]
            val c = ordered[remaining[2]]
            if (abs(cross(a, b, c)) > MIN_TRIANGLE_CROSS) {
                triangles.add(remaining[0]); triangles.add(remaining[1]); triangles.add(remaining[2])
            }
        }
        return Result(ordered, triangles)
    }

    private fun isEar(
        pts: List<PointF>,
        remaining: List<Int>,
        iPrev: Int,
        iCurr: Int,
        iNext: Int,
        a: PointF,
        b: PointF,
        c: PointF
    ): Boolean {
        for (other in remaining) {
            if (other == iPrev || other == iCurr || other == iNext) continue
            if (pointInTriangle(pts[other], a, b, c)) return false
        }
        return true
    }

    /** Twice the signed area of triangle (o, a, b): positive if o->a->b
     * turns counter-clockwise, negative if clockwise, ~0 if collinear. */
    private fun cross(o: PointF, a: PointF, b: PointF): Float =
        (a.x - o.x) * (b.y - o.y) - (a.y - o.y) * (b.x - o.x)

    private fun pointInTriangle(p: PointF, a: PointF, b: PointF, c: PointF): Boolean {
        val d1 = cross(p, a, b)
        val d2 = cross(p, b, c)
        val d3 = cross(p, c, a)
        val hasNeg = d1 < -POINT_IN_TRIANGLE_EPSILON || d2 < -POINT_IN_TRIANGLE_EPSILON || d3 < -POINT_IN_TRIANGLE_EPSILON
        val hasPos = d1 > POINT_IN_TRIANGLE_EPSILON || d2 > POINT_IN_TRIANGLE_EPSILON || d3 > POINT_IN_TRIANGLE_EPSILON
        return !(hasNeg && hasPos)
    }

    private fun signedArea(pts: List<PointF>): Float {
        var sum = 0f
        val n = pts.size
        for (i in 0 until n) {
            val a = pts[i]
            val b = pts[(i + 1) % n]
            sum += a.x * b.y - b.x * a.y
        }
        return sum * 0.5f
    }

    // Tuned (see class doc) against ~3000 generated piece outlines using
    // Float32 arithmetic. Piece coordinates are raw bitmap pixels (tens to
    // low thousands in magnitude), so these are small relative to any
    // genuine triangle in that range but comfortably above Float32's own
    // rounding noise at that scale -- tighter values started rejecting
    // valid, only-numerically-imperfect ears near the piece's straight
    // (collinear) runs.
    private const val REFLEX_EPSILON = 1e-2f
    private const val POINT_IN_TRIANGLE_EPSILON = 1e-2f
    private const val MIN_TRIANGLE_CROSS = 1e-2f
}
