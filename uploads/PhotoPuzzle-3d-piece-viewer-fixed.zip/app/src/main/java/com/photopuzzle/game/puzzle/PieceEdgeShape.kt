package com.photopuzzle.game.puzzle

import android.graphics.Path
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Draws one edge of a puzzle piece: either a straight line (grid border,
 * `sign == 0`) or the classic interlocking "tab / blank" knob.
 *
 * This is deliberately the *only* place the knob's curve is defined. Every
 * side of every piece calls through here with different direction/normal
 * vectors (see [PuzzlePieceFactory]) rather than four hand-duplicated
 * copies of the curve -- so the shape only needs tuning in one spot, and
 * top/right/bottom/left can never quietly drift out of sync with each
 * other.
 *
 * The knob is built from two parts, both expressed in edge-local units
 * where 1.0 == the edge's own [length] -- so a "t" offset and a "d" offset
 * of the same size really do move the same physical distance, just along
 * different axes:
 *  - a short, narrow **neck** where the piece body pinches in, and
 *  - a genuinely circular **head** ([HEAD_RADIUS], swept through
 *    [HEAD_ARC_DEGREES] on each side of the tip) wider than the neck, so
 *    the head truly overhangs it -- the interlocking part, the same way a
 *    real puzzle piece's head is too wide to pull straight back out
 *    through its own neck.
 *
 * An earlier version of this shape used a single hand-tuned Bezier bump
 * for the whole knob. It technically had a narrower neck than head, but
 * with no true circle anywhere in the math, "neck" and "head" widths were
 * tuned by feel against a d-axis that (in the first draft) was secretly
 * compressed relative to the t-axis by the old tab-amplitude constant --
 * so what looked reasonable in the numbers rendered as a flattened,
 * lopsided blob rather than a round knob. Building the head from actual
 * circle points, in axes that share one scale, makes "does this look
 * round" a property of [HEAD_RADIUS] directly instead of something four
 * unrelated control-point constants had to conspire to produce.
 *
 * [knots] is the shape: to make the head bigger or the neck narrower,
 * change a number there and every edge of every piece picks it up.
 * [appendSmoothSpline] turns whatever knot sequence it's given into a
 * smooth curve, so the technique is reusable for any future knob shape,
 * not just this one.
 */
internal object PieceEdgeShape {

    /** One point of the knob's silhouette, in edge-local units: [t] is
     * position along the edge (0 = start, 1 = end), [d] is perpendicular
     * displacement toward the tab side, in the *same* units as [t] (1.0 in
     * either axis is one full edge [length]). */
    private data class Knot(val t: Float, val d: Float) {
        operator fun plus(other: Knot) = Knot(t + other.t, d + other.d)
        operator fun minus(other: Knot) = Knot(t - other.t, d - other.d)
        operator fun times(scale: Float) = Knot(t * scale, d * scale)
    }

    // Where the flat edge bends into the curve, and the neck's narrowest
    // point just past it -- both relative to the knob's own center (the
    // edge's true midpoint, 0.5).
    private const val BASE_HALF_WIDTH = 0.15f
    private const val NECK_HALF_WIDTH = 0.062f
    private const val NECK_DEPTH = 0.082f

    // The head: a true circle of this radius, centered this far out from
    // the edge, traced from -HEAD_ARC_DEGREES to +HEAD_ARC_DEGREES either
    // side of the tip (the remaining arc, facing back toward the edge,
    // isn't needed -- the neck attaches across it instead). HEAD_RADIUS
    // exceeding NECK_HALF_WIDTH by this much is what makes the head a
    // genuine overhang rather than just a wider taper.
    private const val HEAD_RADIUS = 0.155f
    private const val HEAD_CENTER_DEPTH = 0.148f
    private const val HEAD_ARC_DEGREES = 74f

    /** Handle length of the two clamped end tangents -- keeps the curve
     * perfectly flat (horizontal in t/d space) right where it meets the
     * straight part of the edge, so there's no visible kink at the join. */
    private const val END_CLAMP = 0.03f

    private val DEGREES_TO_RADIANS = (PI / 180.0).toFloat()

    /** The knob's silhouette, left to right along the edge: base, neck,
     * five points swept around the head circle, neck, base. Symmetric by
     * construction: mirror any change on one side to its counterpart. */
    private fun knots(center: Float): List<Knot> {
        val head = (-2..2).map { step ->
            val angle = (step * (HEAD_ARC_DEGREES / 2f)) * DEGREES_TO_RADIANS
            Knot(center + HEAD_RADIUS * sin(angle), HEAD_CENTER_DEPTH + HEAD_RADIUS * cos(angle))
        }
        return listOf(Knot(center - BASE_HALF_WIDTH, 0f), Knot(center - NECK_HALF_WIDTH, NECK_DEPTH)) +
            head +
            listOf(Knot(center + NECK_HALF_WIDTH, NECK_DEPTH), Knot(center + BASE_HALF_WIDTH, 0f))
    }

    /**
     * Appends one edge to [path], whose current point must already be at
     * (startX, startY). The edge runs `length` units in direction
     * (dirX, dirY) and its knob (if any) bulges toward (normalX, normalY)
     * when [sign] is positive, away from it when negative, centered at the
     * true midpoint of the edge.
     *
     * @param sign -1f, 0f, or +1f. 0f draws a plain straight line (used for
     *   the grid's outer border, which never has a tab).
     */
    fun addEdge(
        path: Path,
        startX: Float,
        startY: Float,
        dirX: Float,
        dirY: Float,
        normalX: Float,
        normalY: Float,
        length: Float,
        sign: Float
    ) {
        if (sign == 0f) {
            path.lineTo(startX + dirX * length, startY + dirY * length)
            return
        }

        fun worldX(k: Knot) = startX + dirX * k.t * length + normalX * k.d * sign * length
        fun worldY(k: Knot) = startY + dirY * k.t * length + normalY * k.d * sign * length

        val silhouette = knots(0.5f)
        path.lineTo(worldX(silhouette.first()), worldY(silhouette.first()))
        appendSmoothSpline(path, silhouette, ::worldX, ::worldY)
        path.lineTo(startX + dirX * length, startY + dirY * length)
    }

    /**
     * Appends a smooth curve through [knots] (whose first point must
     * already be the path's current point) as a sequence of cubic Beziers.
     * Interior knots get a Catmull-Rom-derived tangent (each control point
     * leans toward its neighbors, giving a natural, non-self-intersecting
     * curve through the whole sequence, including around the head's
     * circle points); the two end knots get a tangent clamped flat in
     * [Knot.d] instead, since those are the points where this curve meets
     * a straight [Path.lineTo] and a mismatched tangent there would show
     * up as a kink.
     *
     * Generic over any knot sequence describing a silhouette this way, so
     * it isn't tied to this particular knob shape.
     */
    private fun appendSmoothSpline(
        path: Path,
        knots: List<Knot>,
        worldX: (Knot) -> Float,
        worldY: (Knot) -> Float
    ) {
        val lastIndex = knots.lastIndex
        for (i in 0 until lastIndex) {
            val start = knots[i]
            val end = knots[i + 1]

            val control1 = if (i == 0) {
                start + Knot(END_CLAMP, 0f)
            } else {
                start + (end - knots[i - 1]) * CATMULL_ROM_TANGENT_SCALE
            }
            val control2 = if (i == lastIndex - 1) {
                end - Knot(END_CLAMP, 0f)
            } else {
                end - (knots[i + 2] - start) * CATMULL_ROM_TANGENT_SCALE
            }

            path.cubicTo(
                worldX(control1), worldY(control1),
                worldX(control2), worldY(control2),
                worldX(end), worldY(end)
            )
        }
    }

    private const val CATMULL_ROM_TANGENT_SCALE = 1f / 6f
}
