package com.photopuzzle.game.puzzle.render3d

import android.content.Context
import android.graphics.Bitmap
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.opengl.Matrix
import com.photopuzzle.game.R
import com.photopuzzle.game.puzzle.PieceGroup
import com.photopuzzle.game.puzzle.PuzzleGame
import com.photopuzzle.game.puzzle.PuzzlePiece
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.ShortBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.cos
import kotlin.math.sin

private const val BYTES_PER_FLOAT = 4
private const val BYTES_PER_SHORT = 2

/** (Re)creates a GL texture from [bitmap], deleting [existingHandle] first
 * if there is one; returns 0 if the bitmap has already been recycled
 * (e.g. the activity is shutting down) rather than crashing on it. */
private fun uploadTexture(bitmap: Bitmap, existingHandle: Int): Int {
    if (existingHandle != 0) GLES20.glDeleteTextures(1, intArrayOf(existingHandle), 0)
    if (bitmap.isRecycled) return 0
    val handles = IntArray(1)
    GLES20.glGenTextures(1, handles, 0)
    GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, handles[0])
    GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
    GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
    GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
    GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
    GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bitmap, 0)
    return handles[0]
}

private fun deleteTexture(handle: Int) {
    if (handle != 0) GLES20.glDeleteTextures(1, intArrayOf(handle), 0)
}

/**
 * Renders every piece of a [PuzzleGame] as a lit, textured, extruded solid
 * lying flat on a shared virtual table -- the whole-board counterpart to
 * [Piece3DRenderer], which only ever shows one piece at a time. Reuses the
 * same shaders ([PieceShaders]) and the same per-piece material-rim color
 * ([PieceMaterialColor]); what differs is the camera (one fixed, tilted,
 * orthographic view of the whole board) and that every piece is drawn each
 * frame.
 *
 * *** Coordinate mapping (checked numerically, see below) ***
 * Board pixel space -- X right, Y down, origin top-left, exactly what
 * [PuzzleGame] and [com.photopuzzle.game.puzzle.PuzzlePieceFactory] already
 * use -- maps to world `(x, height, -y)`, and each piece is tipped -90
 * degrees about the world X axis so it lies face-up (see
 * [pieceModelMatrix]). That is the one combination, of everything tried
 * against a small numeric simulation of this exact matrix chain, in which
 * a piece's own tabs still reach toward its true neighbors both
 * horizontally and vertically *and* each piece's own photo is not
 * mirrored. The unavoidable side effect is that the whole assembled board
 * appears left-right mirrored on screen; [PuzzleBoard3DView] cancels that
 * once, by flipping the source photo horizontally before it is ever cut
 * into pieces, so nothing here compensates for it.
 *
 * On screen (tilt `t`, ortho height scaled by cos t so the table plane
 * itself isn't foreshortened): `board_x = viewWidth - touchX` and
 * `board_y = touchY` exactly, for anything resting on the table.
 * Height above the table shows up as an upward shift of `height * tan t`
 * pixels, and a piece's own thickness as a visible band along its
 * screen-bottom edges -- which is where the "solid, not paper" look comes
 * from.
 *
 * *** Texture V ***
 * [PieceMeshBuilder] writes V as `1 - y/height` -- right for
 * [Piece3DRenderer]'s y-up camera, but [GLUtils.texImage2D] puts a
 * bitmap's *top* row at texture t=0, so on a table viewed in the board's
 * own y-down orientation a piece's photo would come out vertically
 * scrambled relative to its own outline. The `uFlipV` uniform (see
 * [PieceShaders]) undoes that here, without touching the mesh or the
 * single-piece viewer.
 */
internal class PuzzleBoard3DRenderer(context: Context) : GLSurfaceView.Renderer {

    private var program: GlProgram? = null
    private var referenceProgram: GlProgram? = null

    private var activeGame: PuzzleGame? = null
    private val pieceResources = HashMap<PuzzlePiece, PieceGpuResources>()
    private var reference: ReferenceGpuResources? = null

    /** The group being dragged, if any -- drawn a little above the table so
     * the "picked up" state is visible from this camera. Set from the
     * main thread by [PuzzleBoard3DView]. */
    @Volatile
    var liftedGroup: PieceGroup? = null

    private var boardWidth = 1f
    private var boardHeight = 1f

    private val viewMatrix = FloatArray(16)
    private val projMatrix = FloatArray(16)
    private val viewProjMatrix = FloatArray(16)
    private val modelMatrix = FloatArray(16)
    private val mvpMatrix = FloatArray(16)
    private val normalMatrix = FloatArray(9)
    private val eyePosition = FloatArray(3)

    private val backgroundColor = PieceMaterialColor.readColorRgb(context, R.color.colorBoardBackground)
    private val backColor = PieceMaterialColor.readColorRgb(context, R.color.colorPieceBackBase)
    private val backLineColor = PieceMaterialColor.readColorRgb(context, R.color.colorPieceBackLine)
    private val defaultRimColor = PieceMaterialColor.readColorRgb(context, R.color.colorPieceThickness)

    /** One frame's worth of what to draw, snapshotted under the game's lock
     * so the GL thread never walks lists the main thread is reordering. */
    private class DrawItem(val piece: PuzzlePiece, val centerX: Float, val centerY: Float, val rotation: Float, val lifted: Boolean, val startsGroup: Boolean)

    /**
     * Replaces everything rendered with [pieces] (already laid out by
     * [aGame]) plus the faint reference [picture] at ([pictureLeft],
     * [pictureTop]) -- board pixels, the same numbers the pieces were
     * built with. Must run on the GL thread ([GLSurfaceView.queueEvent]).
     */
    fun setGame(
        aGame: PuzzleGame,
        pieces: List<PuzzlePiece>,
        boardW: Float,
        boardH: Float,
        picture: Bitmap,
        pictureLeft: Float,
        pictureTop: Float
    ) {
        activeGame = aGame
        boardWidth = boardW.coerceAtLeast(1f)
        boardHeight = boardH.coerceAtLeast(1f)
        for (resources in pieceResources.values) resources.delete()
        pieceResources.clear()
        for (piece in pieces) {
            pieceResources[piece] = PieceGpuResources.upload(piece, defaultRimColor)
        }
        reference?.delete()
        reference = ReferenceGpuResources.upload(picture, pictureLeft, pictureTop)
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(backgroundColor[0], backgroundColor[1], backgroundColor[2], 1f)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        // Deliberately no GL_CULL_FACE -- same reason as
        // Piece3DRenderer.onSurfaceCreated: the mesh winding has only ever
        // been checked off-device, and a wrong winding should look slightly
        // off rather than silently drop a whole face.
        program = GlProgram(PieceShaders.VERTEX, PieceShaders.FRAGMENT)
        referenceProgram = GlProgram(PieceShaders.REFERENCE_VERTEX, PieceShaders.REFERENCE_FRAGMENT)

        // A fresh context has none of the old textures.
        for (resources in pieceResources.values) resources.reuploadTexture()
        reference?.reuploadTexture()
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        val piecesProgram = program ?: return
        val game = activeGame ?: return
        if (pieceResources.isEmpty()) return

        updateCamera()
        val items = snapshot(game)

        drawReference()

        piecesProgram.use()
        GLES20.glUniform3f(piecesProgram.uniform("uLightDir"), LIGHT_DIR_X, LIGHT_DIR_Y, LIGHT_DIR_Z)
        GLES20.glUniform3f(piecesProgram.uniform("uViewPos"), eyePosition[0], eyePosition[1], eyePosition[2])
        GLES20.glUniform3f(piecesProgram.uniform("uBackColor"), backColor[0], backColor[1], backColor[2])
        GLES20.glUniform3f(piecesProgram.uniform("uBackLineColor"), backLineColor[0], backLineColor[1], backLineColor[2])
        GLES20.glUniform1f(piecesProgram.uniform("uFlipV"), 1f)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glUniform1i(piecesProgram.uniform("uTexture"), 0)

        for (item in items) {
            val resources = pieceResources[item.piece] ?: continue
            // Painter's order between groups (a group drawn later is on top
            // of everything before it, exactly the rule bringToFront sets),
            // real depth testing *within* a group -- so a piece's own caps
            // and walls sort correctly, and so does a piece's wall against
            // its connected neighbor's face at a seam.
            if (item.startsGroup) GLES20.glClear(GLES20.GL_DEPTH_BUFFER_BIT)

            pieceModelMatrix(item, if (item.lifted) LIFTED_HEIGHT else 0f)
            Matrix.multiplyMM(mvpMatrix, 0, viewProjMatrix, 0, modelMatrix, 0)
            mat4RotationToMat3(modelMatrix, normalMatrix)

            GLES20.glUniformMatrix4fv(piecesProgram.uniform("uMvpMatrix"), 1, false, mvpMatrix, 0)
            GLES20.glUniformMatrix4fv(piecesProgram.uniform("uModelMatrix"), 1, false, modelMatrix, 0)
            GLES20.glUniformMatrix3fv(piecesProgram.uniform("uNormalMatrix"), 1, false, normalMatrix, 0)
            GLES20.glUniform3f(piecesProgram.uniform("uRimColor"), resources.rimColor[0], resources.rimColor[1], resources.rimColor[2])
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, resources.textureHandle)

            bindAttrib(piecesProgram, resources.vertexBuffer, "aPosition", PieceMeshData.POSITION_COMPONENTS, PieceMeshData.POSITION_OFFSET_BYTES)
            bindAttrib(piecesProgram, resources.vertexBuffer, "aNormal", PieceMeshData.NORMAL_COMPONENTS, PieceMeshData.NORMAL_OFFSET_BYTES)
            bindAttrib(piecesProgram, resources.vertexBuffer, "aTexCoord", PieceMeshData.UV_COMPONENTS, PieceMeshData.UV_OFFSET_BYTES)
            bindAttrib(piecesProgram, resources.vertexBuffer, "aFaceId", PieceMeshData.FACE_ID_COMPONENTS, PieceMeshData.FACE_ID_OFFSET_BYTES)

            resources.indexBuffer.position(0)
            GLES20.glDrawElements(GLES20.GL_TRIANGLES, resources.indexCount, GLES20.GL_UNSIGNED_SHORT, resources.indexBuffer)
        }
    }

    /**
     * Copies out, under the game's own lock, everything [onDrawFrame] needs
     * -- in draw order: groups ordered by their topmost member's position
     * in [PuzzleGame.piecesInDrawOrder], each group's members together.
     * The main thread takes the same lock for every touch-driven change, so
     * this never sees a list mid-reorder.
     */
    private fun snapshot(game: PuzzleGame): List<DrawItem> = synchronized(game) {
        val ordered = game.piecesInDrawOrder()
        val topIndex = LinkedHashMap<PieceGroup, Int>()
        for ((index, piece) in ordered.withIndex()) topIndex[piece.group] = index
        val lifted = liftedGroup
        val items = ArrayList<DrawItem>(ordered.size)
        for (group in topIndex.entries.sortedBy { it.value }.map { it.key }) {
            var first = true
            for (piece in group.members) {
                items += DrawItem(
                    piece,
                    piece.currentX + piece.width / 2f,
                    piece.currentY + piece.height / 2f,
                    piece.pileRotationDegrees,
                    group === lifted,
                    first
                )
                first = false
            }
        }
        items
    }

    private fun updateCamera() {
        val halfW = boardWidth / 2f
        val halfH = boardHeight / 2f
        val cosT = cos(TILT_RADIANS)
        val sinT = sin(TILT_RADIANS)
        // Ortho height is scaled by cos(tilt) so the table plane maps 1:1
        // to screen pixels vertically (see the class doc).
        Matrix.orthoM(projMatrix, 0, -halfW, halfW, -halfH * cosT, halfH * cosT, NEAR, FAR)
        eyePosition[0] = halfW
        eyePosition[1] = CAMERA_DISTANCE * cosT
        eyePosition[2] = -halfH - CAMERA_DISTANCE * sinT
        Matrix.setLookAtM(
            viewMatrix, 0,
            eyePosition[0], eyePosition[1], eyePosition[2],
            halfW, 0f, -halfH,
            0f, 0f, 1f
        )
        Matrix.multiplyMM(viewProjMatrix, 0, projMatrix, 0, viewMatrix, 0)
    }

    private fun drawReference() {
        val ref = reference ?: return
        val refProgram = referenceProgram ?: return
        refProgram.use()
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        GLES20.glUniformMatrix4fv(refProgram.uniform("uMvpMatrix"), 1, false, viewProjMatrix, 0)
        GLES20.glUniform1f(refProgram.uniform("uAlpha"), REFERENCE_ALPHA)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, ref.textureHandle)
        GLES20.glUniform1i(refProgram.uniform("uTexture"), 0)

        val posLocation = refProgram.attrib("aPosition")
        val uvLocation = refProgram.attrib("aTexCoord")
        ref.quad.position(0)
        GLES20.glEnableVertexAttribArray(posLocation)
        GLES20.glVertexAttribPointer(posLocation, 3, GLES20.GL_FLOAT, false, ReferenceGpuResources.STRIDE_BYTES, ref.quad)
        ref.quad.position(3)
        GLES20.glEnableVertexAttribArray(uvLocation)
        GLES20.glVertexAttribPointer(uvLocation, 2, GLES20.GL_FLOAT, false, ReferenceGpuResources.STRIDE_BYTES, ref.quad)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisable(GLES20.GL_BLEND)
    }

    /**
     * Builds [modelMatrix] for one piece: translate to its board position
     * (plus [liftHeight] off the table), spin about the now-vertical front
     * normal by [PuzzlePiece.pileRotationDegrees] -- the same value the 2D
     * board drew as a flat rotation, here a real rotation about a real
     * vertical axis (positive = the same direction, which
     * [PuzzleGame]'s hit-test inverse relies on) -- then tip the piece flat.
     * [PieceMeshBuilder] centers every mesh on its own piece, so no extra
     * pivot offset is needed.
     */
    private fun pieceModelMatrix(item: DrawItem, liftHeight: Float) {
        Matrix.setIdentityM(modelMatrix, 0)
        Matrix.translateM(modelMatrix, 0, item.centerX, liftHeight, -item.centerY)
        Matrix.rotateM(modelMatrix, 0, item.rotation, 0f, 1f, 0f)
        Matrix.rotateM(modelMatrix, 0, -90f, 1f, 0f, 0f)
    }

    private fun bindAttrib(program: GlProgram, buffer: FloatBuffer, name: String, components: Int, offsetBytes: Int) {
        val location = program.attrib(name)
        if (location < 0) return
        GLES20.glEnableVertexAttribArray(location)
        buffer.position(offsetBytes / BYTES_PER_FLOAT)
        GLES20.glVertexAttribPointer(location, components, GLES20.GL_FLOAT, false, PieceMeshData.STRIDE_BYTES, buffer)
    }

    /** Same reasoning as [Piece3DRenderer]'s identical helper: the model
     * matrix is only rotations plus a translation, so its upper 3x3 is
     * already a correct normal matrix. */
    private fun mat4RotationToMat3(m4: FloatArray, out9: FloatArray) {
        out9[0] = m4[0]; out9[1] = m4[1]; out9[2] = m4[2]
        out9[3] = m4[4]; out9[4] = m4[5]; out9[5] = m4[6]
        out9[6] = m4[8]; out9[7] = m4[9]; out9[8] = m4[10]
    }

    /** One piece's GPU-side mesh, texture, and material color. Draws
     * straight from the piece's own live bitmap (never recycled here --
     * [PuzzleGame] still owns it, see [PuzzleGame.recycleAll]), which is
     * also what lets [reuploadTexture] recover from a lost GL context. */
    private class PieceGpuResources private constructor(
        private val piece: PuzzlePiece,
        val vertexBuffer: FloatBuffer,
        val indexBuffer: ShortBuffer,
        val indexCount: Int,
        val rimColor: FloatArray
    ) {
        var textureHandle = 0
            private set

        fun reuploadTexture() {
            textureHandle = uploadTexture(piece.bitmap, textureHandle)
        }

        fun delete() {
            deleteTexture(textureHandle)
            textureHandle = 0
        }

        companion object {
            fun upload(piece: PuzzlePiece, defaultRimColor: FloatArray): PieceGpuResources {
                val mesh = PieceMeshBuilder.build(piece)
                val vertexBuffer = ByteBuffer.allocateDirect(mesh.vertexData.size * BYTES_PER_FLOAT)
                    .order(ByteOrder.nativeOrder())
                    .asFloatBuffer()
                    .apply { put(mesh.vertexData); position(0) }
                val indexBuffer = ByteBuffer.allocateDirect(mesh.indices.size * BYTES_PER_SHORT)
                    .order(ByteOrder.nativeOrder())
                    .asShortBuffer()
                    .apply { put(mesh.indices); position(0) }
                val rimColor = if (piece.bitmap.isRecycled) {
                    defaultRimColor
                } else {
                    PieceMaterialColor.materialRimColor(
                        PieceMaterialColor.averageColor(piece.bitmap, defaultRimColor),
                        defaultRimColor
                    )
                }
                return PieceGpuResources(piece, vertexBuffer, indexBuffer, mesh.indices.size, rimColor)
                    .also { it.reuploadTexture() }
            }
        }
    }

    /** The faint reference picture: one quad in board pixels, texture from
     * the same (already mirrored) bitmap the pieces were cut from. */
    private class ReferenceGpuResources private constructor(
        private val picture: Bitmap,
        val quad: FloatBuffer
    ) {
        var textureHandle = 0
            private set

        fun reuploadTexture() {
            textureHandle = uploadTexture(picture, textureHandle)
        }

        fun delete() {
            deleteTexture(textureHandle)
            textureHandle = 0
        }

        companion object {
            const val STRIDE_BYTES = 5 * BYTES_PER_FLOAT

            fun upload(picture: Bitmap, left: Float, top: Float): ReferenceGpuResources {
                val right = left + picture.width
                val bottom = top + picture.height
                // x, y(height), z, u, v -- triangle-strip order. V is the
                // bitmap's own top-down v (row 0 at t=0), *not* flipped.
                val data = floatArrayOf(
                    left, 0f, -top, 0f, 0f,
                    right, 0f, -top, 1f, 0f,
                    left, 0f, -bottom, 0f, 1f,
                    right, 0f, -bottom, 1f, 1f
                )
                val quad = ByteBuffer.allocateDirect(data.size * BYTES_PER_FLOAT)
                    .order(ByteOrder.nativeOrder())
                    .asFloatBuffer()
                    .apply { put(data); position(0) }
                return ReferenceGpuResources(picture, quad).also { it.reuploadTexture() }
            }
        }
    }

    private companion object {
        // Camera tilt away from straight-down, and how far back it sits.
        // Only affects how much of a piece's thickness shows (about
        // thickness * tan(tilt) pixels along each bottom edge) and how far
        // a lifted piece appears to rise; the touch mapping in the class
        // doc holds for any tilt below 90 degrees.
        val TILT_RADIANS = Math.toRadians(35.0).toFloat()
        const val CAMERA_DISTANCE = 2000f
        const val NEAR = 1f
        const val FAR = 4000f

        // Toward the light from the table: a little to screen-left (world
        // +X, since the board renders mirrored), mostly overhead, and
        // toward the viewer's side (world -Z) so the visible bottom walls
        // catch some light instead of sitting in pure shadow.
        const val LIGHT_DIR_X = 0.35f
        const val LIGHT_DIR_Y = 0.8f
        const val LIGHT_DIR_Z = -0.5f

        // In board-pixel units, like everything else in world space.
        const val LIFTED_HEIGHT = 40f
        const val REFERENCE_ALPHA = 36f / 255f
    }
}
