package com.photopuzzle.game.puzzle

/**
 * Which side of a [PuzzlePiece] is currently showing.
 *
 * Set on the piece itself (see [PuzzlePiece.orientation]) so it survives
 * dragging, fling, pile movement, reordering, and connected-group movement
 * the same way position and group membership already do.
 * [PuzzleGame.scatter] resets every piece to [FRONT] at the start of each
 * game, so no orientation carries over from a previous puzzle.
 *
 * Only a [FRONT] piece may join a [PieceGroup] (see
 * [PuzzleGame.tryConnect]) -- a flipped piece must be turned back over
 * before it can snap into place, and flipping is only ever offered for a
 * loose piece (`group.size == 1`; see [PuzzleBoardView]), never one already
 * inside a multi-piece group.
 */
internal enum class PieceOrientation { FRONT, BACK }
