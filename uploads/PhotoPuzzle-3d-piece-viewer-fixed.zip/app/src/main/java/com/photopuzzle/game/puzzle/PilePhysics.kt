package com.photopuzzle.game.puzzle

import android.graphics.PointF
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Decides whether a spot a piece (or group) just landed in is already too
 * crowded with other pieces -- a pile stacked too "tall" there -- and if
 * so, how far and which way it should slide to find clearer ground, the
 * same way a real piece dropped onto an unstable heap slides off rather
 * than balancing exactly where it landed.
 *
 * Pure math, no Android View/Canvas dependency (same spirit as
 * [FlingPhysics]) -- [PuzzleBoardView] is the only thing that turns the
 * [Nudge] this returns into an actual on-screen slide animation.
 */
internal object PilePhysics {

    /** How far, and which way, a crowded drop should slide. */
    data class Nudge(val dx: Float, val dy: Float)

    /**
     * [centerX]/[centerY] is where the dropped object currently sits;
     * [neighborCenters] the centers of every *other* piece worth
     * considering -- filtering out which pieces are even relevant (its
     * own group, pieces already fused into a bigger assembly) is the
     * caller's job, not this function's. [checkRadius] is how close
     * another piece has to be to count as part of this pile at all.
     *
     * Each neighbor within [checkRadius] contributes to a "crowding"
     * score -- nearer neighbors weigh more, the way a real pile is denser
     * toward its center -- and pushes away from itself proportionally.
     * Returns null once crowding is at or under [PILE_STABLE_THRESHOLD],
     * the same way a real heap sits stable once it isn't too steep;
     * otherwise returns the combined push, scaled by how far past that
     * threshold the spot is, so a taller pile produces a longer slide.
     */
    fun resolveOverlap(
        centerX: Float,
        centerY: Float,
        neighborCenters: List<PointF>,
        checkRadius: Float,
        random: Random = Random.Default
    ): Nudge? {
        if (checkRadius <= 0f) return null

        var pushX = 0f
        var pushY = 0f
        var crowding = 0f

        for (neighbor in neighborCenters) {
            val dx = centerX - neighbor.x
            val dy = centerY - neighbor.y
            val distance = sqrt(dx * dx + dy * dy)
            if (distance >= checkRadius) continue

            val weight = (checkRadius - distance) / checkRadius
            crowding += weight
            if (distance > MIN_DISTANCE_PX) {
                pushX += (dx / distance) * weight
                pushY += (dy / distance) * weight
            }
        }

        if (crowding <= PILE_STABLE_THRESHOLD) return null

        val pushLength = sqrt(pushX * pushX + pushY * pushY)
        val (dirX, dirY) = if (pushLength > MIN_DISTANCE_PX) {
            (pushX / pushLength) to (pushY / pushLength)
        } else {
            // A (rare) perfectly symmetric crowd has no single "away from
            // the pile" direction -- pick one at random rather than
            // leaving the piece stuck exactly where it landed.
            val angle = random.nextFloat() * TWO_PI
            cos(angle) to sin(angle)
        }

        val slideDistance = (crowding - PILE_STABLE_THRESHOLD) * checkRadius * SLIDE_DISTANCE_FACTOR
        return Nudge(dirX * slideDistance, dirY * slideDistance)
    }

    /** Below this, a neighbor is considered "crowding but not too tall" --
     * e.g. a single piece dropped directly onto one other piece shouldn't
     * by itself trigger a dramatic slide; it takes a properly stacked-up
     * spot to cross this. */
    private const val PILE_STABLE_THRESHOLD = 1.1f

    /** Scales how far past [PILE_STABLE_THRESHOLD] crowding turns into
     * on-screen slide distance, in units of [checkRadius]. */
    private const val SLIDE_DISTANCE_FACTOR = 0.6f

    private const val MIN_DISTANCE_PX = 1f
    private val TWO_PI = (kotlin.math.PI * 2).toFloat()
}
