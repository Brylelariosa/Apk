package com.photopuzzle.game.puzzle

/**
 * Produces the randomized tab/blank layout for a jigsaw grid: one
 * [sign, jitter] pair per internal edge, horizontal edges first (row-major),
 * then vertical edges (row-major). See [EdgeGeometry.sideSign] for how this
 * flat array is interpreted into each piece's four sides, and
 * [EdgeSmoothing] for a repair pass this project runs over the result
 * before [PuzzlePieceFactory] builds any piece from it.
 *
 * jitter is still generated and carried through the array so the native
 * and Kotlin-fallback implementations stay unchanged and in sync with each
 * other, but nothing reads it any more -- [PieceEdgeShape] centers every
 * knob on the edge's true midpoint rather than shifting it by jitter's
 * amount.
 */
internal interface EdgeGenerator {
    fun generate(rows: Int, cols: Int, seed: Long): FloatArray
}

/** JNI-backed generator using the CMake-built `puzzlecore` native library. */
internal object NativeEdgeGenerator : EdgeGenerator {

    val isAvailable: Boolean = try {
        System.loadLibrary("puzzlecore")
        true
    } catch (error: Throwable) {
        false
    }

    override fun generate(rows: Int, cols: Int, seed: Long): FloatArray {
        val out = FloatArray(EdgeGeometry.floatCountFor(rows, cols))
        nativeGenerate(rows, cols, seed, out)
        return out
    }

    /** Fills [out] in place; [out] must already be sized by the caller (see
     * [EdgeGeometry.floatCountFor]) since the native side does no allocation. */
    private external fun nativeGenerate(rows: Int, cols: Int, seed: Long, out: FloatArray)
}

/** Pure-Kotlin fallback implementing the identical SplitMix64-based
 * algorithm as core/edge_generator.cpp, used if the native library is
 * unavailable for any reason so the game still works either way. */
internal object KotlinEdgeGenerator : EdgeGenerator {

    override fun generate(rows: Int, cols: Int, seed: Long): FloatArray {
        val edgeCount = EdgeGeometry.edgeCountFor(rows, cols)
        val out = FloatArray(edgeCount * 2)
        val seedBits = seed.toULong()

        for (i in 0 until edgeCount) {
            val bits = splitmix64(seedBits xor (i.toULong() * INDEX_MIX_CONSTANT))

            out[i * 2] = if ((bits and 1UL) == 0UL) -1f else 1f

            val jitterBits = ((bits shr 32) and 0xFFFFUL).toInt()
            out[i * 2 + 1] = (jitterBits / 65535f - 0.5f) * 0.12f
        }
        return out
    }

    // SplitMix64 (public-domain step function, S. Vigna / S. Steele) -- kept
    // byte-for-byte identical to the C++ version so native and fallback
    // produce the same puzzles for the same seed.
    private fun splitmix64(input: ULong): ULong {
        var z = input + 0x9E3779B97F4A7C15UL
        z = (z xor (z shr 30)) * 0xBF58476D1CE4E5B9UL
        z = (z xor (z shr 27)) * 0x94D049BB133111EBUL
        return z xor (z shr 31)
    }

    private const val INDEX_MIX_CONSTANT = 0x9E3779B97F4A7C15UL
}

/** Shared sizing *and* access math so the native path, the fallback path,
 * [PuzzlePieceFactory], and [EdgeSmoothing] can never disagree about array
 * layout or how a piece's four sides map onto it. */
internal object EdgeGeometry {
    fun edgeCountFor(rows: Int, cols: Int): Int {
        if (rows < 1 || cols < 1) return 0
        return (rows - 1) * cols + rows * (cols - 1)
    }

    fun floatCountFor(rows: Int, cols: Int): Int = edgeCountFor(rows, cols) * 2

    /** Horizontal edges (row-major) come first in the flat array, then
     * vertical edges (also row-major) -- see [EdgeGenerator]. */
    private fun horizontalIndex(cols: Int, r: Int, c: Int): Int = r * cols + c
    private fun verticalIndex(rows: Int, cols: Int, r: Int, c: Int): Int =
        (rows - 1) * cols + r * (cols - 1) + c

    private val FLAT = 0f to 0f

    /**
     * [sign, jitter] for one piece's one [side], already flipped to that
     * piece's own point of view -- e.g. two pieces sharing an edge always
     * see opposite signs for it, since one's tab is the other's blank (see
     * [PieceEdgeShape] for what the sign itself means; jitter is carried
     * through unused -- see [EdgeGenerator]). FLAT at the grid's outer
     * border, which never has a tab.
     */
    fun sideSign(data: FloatArray, rows: Int, cols: Int, side: PieceSide, r: Int, c: Int): Pair<Float, Float> {
        fun pair(index: Int) = data[index * 2] to data[index * 2 + 1]
        return when (side) {
            PieceSide.TOP -> if (r == 0) FLAT else
                pair(horizontalIndex(cols, r - 1, c)).let { (s, j) -> -s to -j }
            PieceSide.BOTTOM -> if (r == rows - 1) FLAT else pair(horizontalIndex(cols, r, c))
            PieceSide.LEFT -> if (c == 0) FLAT else
                pair(verticalIndex(rows, cols, r, c - 1)).let { (s, j) -> -s to -j }
            PieceSide.RIGHT -> if (c == cols - 1) FLAT else pair(verticalIndex(rows, cols, r, c))
        }
    }

    /** Flips the shared edge on [side] of piece (r,c) between tab and
     * blank -- e.g. turning that piece's own blank into a tab necessarily
     * turns its neighbor's tab into a blank, since it's the same physical
     * edge for both. A no-op at the grid's outer border (nothing there to
     * flip -- see [sideSign]). */
    fun flipSide(data: FloatArray, rows: Int, cols: Int, side: PieceSide, r: Int, c: Int) {
        val index = when (side) {
            PieceSide.TOP -> if (r == 0) return else horizontalIndex(cols, r - 1, c)
            PieceSide.BOTTOM -> if (r == rows - 1) return else horizontalIndex(cols, r, c)
            PieceSide.LEFT -> if (c == 0) return else verticalIndex(rows, cols, r, c - 1)
            PieceSide.RIGHT -> if (c == cols - 1) return else verticalIndex(rows, cols, r, c)
        }
        data[index * 2] = -data[index * 2]
    }
}

/** Picks the native generator when it's genuinely working (loads *and*
 * successfully services a smoke-test call), falling back to the pure-Kotlin
 * one otherwise -- so a native/JNI problem degrades the game to "slightly
 * slower generation," never to a crash. */
internal object EdgeGeneratorProvider {
    private val resolved: EdgeGenerator by lazy {
        if (NativeEdgeGenerator.isAvailable) {
            try {
                NativeEdgeGenerator.generate(2, 2, 0L)
                NativeEdgeGenerator
            } catch (error: Throwable) {
                KotlinEdgeGenerator
            }
        } else {
            KotlinEdgeGenerator
        }
    }

    fun get(): EdgeGenerator = resolved
}
