package com.photopuzzle.game

/**
 * The grid sizes offered on the picker screen, as a target piece count
 * rather than a fixed rows x cols -- the actual grid shape is decided per
 * photo by [com.photopuzzle.game.puzzle.PuzzleGridSizing] once the chosen
 * photo's own dimensions are known, so a portrait or landscape photo still
 * ends up with roughly square pieces instead of a flat NxN grid stretching
 * every piece to match whichever way the photo happens to be longer.
 * Kept as one small, data-driven list rather than branching on a chosen
 * RadioButton id wherever a piece count is needed, so adding another size
 * later touches only this file (plus its own option in activity_main.xml).
 */
internal enum class Difficulty(val pieceCount: Int) {
    EASY(9),
    MEDIUM(16),
    HARD(25),
    EXPERT(100)
}
