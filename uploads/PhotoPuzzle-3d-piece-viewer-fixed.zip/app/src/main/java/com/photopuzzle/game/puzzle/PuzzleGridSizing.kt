package com.photopuzzle.game.puzzle

import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Turns a target piece count into an actual rows x cols grid, shaped to
 * match the source photo's own aspect ratio -- so a piece comes out
 * roughly square (the shape [PieceEdgeShape]'s knob proportions already
 * assume) instead of however tall or wide the *photo* happens to be. A
 * flat NxN grid used for every photo turns a non-square photo's pieces
 * into slivers stretched along whichever side the photo is longer on --
 * most visible on the portrait photos a phone camera shoots by default.
 */
internal object PuzzleGridSizing {

    /**
     * Chooses rows/cols so that `photoWidth/cols` (a piece's width) lands
     * close to `photoHeight/rows` (a piece's height), while `rows * cols`
     * lands close to [pieceCount]. Exact equality on either front isn't
     * possible in general (rows/cols must be whole numbers), so this
     * favors a good aspect-ratio match over hitting [pieceCount] exactly
     * -- landing on, say, 15 pieces instead of the requested 16 reads as
     * "about medium difficulty" the way a stretched piece never will. For
     * a photo whose width equals its height, this reduces to the square
     * `sqrt(pieceCount) x sqrt(pieceCount)` grid every photo used to get.
     */
    fun forPhoto(pieceCount: Int, photoWidth: Int, photoHeight: Int): Pair<Int, Int> {
        val aspect = (photoWidth.toFloat() / photoHeight.toFloat()).coerceIn(MIN_ASPECT, MAX_ASPECT)
        val rows = sqrt(pieceCount / aspect).roundToInt().coerceAtLeast(MIN_GRID_LINE)
        val cols = sqrt(pieceCount * aspect).roundToInt().coerceAtLeast(MIN_GRID_LINE)
        return rows to cols
    }

    // Clamped so a panorama or a very tall crop still gets a sane, usable
    // grid rather than one equally stretched the other way (e.g. 2 rows x
    // 50 cols) -- pieces stay closer to square than the raw photo shape
    // would give, at the cost of a small amount of aspect mismatch on
    // genuinely extreme photos.
    private const val MIN_ASPECT = 0.4f
    private const val MAX_ASPECT = 2.5f

    // PuzzlePieceFactory.createPieces requires at least a 2x2 grid.
    private const val MIN_GRID_LINE = 2
}
