package com.photopuzzle.game.puzzle

/**
 * Repairs the case [EdgeGenerator] leaves a piece with a blank on both
 * opposite sides at once (left+right, or top+bottom) -- structurally legal,
 * since every edge is generated independently, but a piece pinched in from
 * two sides at once reads as an accident rather than a puzzle piece: its
 * two neighbors' tabs eat so far into its middle that barely any of its own
 * body is left connecting top to bottom (or left to right).
 *
 * Runs once, in a single top-left-to-bottom-right sweep, directly on the
 * flat array [EdgeGenerator] produced -- so it applies the same way
 * regardless of which [EdgeGenerator] ran, with no separate copy of this
 * policy needed in the native generator, the Kotlin fallback, or a second
 * "which grid size did I just build" call site. For each piece, in turn,
 * only its own right/bottom side is ever flipped -- never left/top, which
 * the sweep already finalized when an earlier piece owned them as *its*
 * right/bottom -- so a fix here can only ever affect sides this pass
 * hasn't looked at yet, never undoes one it already made, and the whole
 * grid is done in one pass with no risk of looping back on itself.
 */
internal object EdgeSmoothing {

    fun apply(data: FloatArray, rows: Int, cols: Int) {
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                unpinch(data, rows, cols, PieceSide.LEFT, PieceSide.RIGHT, r, c)
                unpinch(data, rows, cols, PieceSide.TOP, PieceSide.BOTTOM, r, c)
            }
        }
    }

    /** If both [nearSide] (already finalized -- either the grid border, or
     * fixed already when an earlier piece in the sweep owned it as its own
     * far side) and [farSide] (this piece's own, not yet visited) are
     * blanks, flips [farSide] to a tab so the piece keeps a solid spine
     * connecting [nearSide] to [farSide] across its middle. */
    private fun unpinch(data: FloatArray, rows: Int, cols: Int, nearSide: PieceSide, farSide: PieceSide, r: Int, c: Int) {
        val (nearSign, _) = EdgeGeometry.sideSign(data, rows, cols, nearSide, r, c)
        val (farSign, _) = EdgeGeometry.sideSign(data, rows, cols, farSide, r, c)
        if (nearSign < 0f && farSign < 0f) {
            EdgeGeometry.flipSide(data, rows, cols, farSide, r, c)
        }
    }
}
