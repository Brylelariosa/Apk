package com.photopuzzle.game.puzzle

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Region

/**
 * One cut-out jigsaw piece.
 *
 * [homeX]/[homeY] are in the board's own coordinate space -- the same
 * space [currentX]/[currentY] live in -- and mark where this piece
 * belongs once solved; [PuzzlePieceFactory] offsets them from the source
 * bitmap's own top-left out to wherever the photo/reference area sits
 * within the larger board. [outline] stays in the piece's own local
 * bitmap coordinates (see [drawSilhouette]) and is unaffected by that
 * offset. [currentX]/[currentY] are updated as the player drags the piece
 * -- or the [group] it belongs to -- around the board.
 */
internal class PuzzlePiece(
    val row: Int,
    val col: Int,
    val bitmap: Bitmap,
    val outline: Path,
    private val sideOutlines: Map<PieceSide, Path>,
    val homeX: Float,
    val homeY: Float
) {
    val width: Int get() = bitmap.width
    val height: Int get() = bitmap.height

    var currentX: Float = homeX
    var currentY: Float = homeY

    /**
     * The cluster this piece currently moves, and is brought to front,
     * together with. Starts as a lone group of one; [PuzzleGame.tryConnect]
     * merges groups together as correctly-adjacent pieces meet, and
     * [PuzzleGame.scatter] resets every piece back to its own group for a
     * fresh game.
     */
    var group: PieceGroup = PieceGroup(this)

    /**
     * Which face is currently showing -- see [PieceOrientation]. Lives here
     * (rather than on [PuzzleBoardView], which only tracks the transient
     * flip *animation*) so it survives dragging, fling, pile movement, and
     * reordering exactly like [currentX]/[group] already do.
     * [PuzzleGame.scatter] resets this to [PieceOrientation.FRONT] for
     * every piece at the start of each game.
     */
    var orientation: PieceOrientation = PieceOrientation.FRONT

    /**
     * Degrees this piece is rotated about its own center from its normal,
     * upright drawing angle -- what makes a freshly [PuzzleGame.scatter]ed
     * pile read as tumbled-together solid pieces (some sideways, some
     * upside down) rather than a neat stack of flat, always-upright paper
     * cutouts. Only ever nonzero for a piece nobody has handled yet this
     * game: [PuzzleGame.straighten] zeroes it the moment the piece is
     * picked up or flipped, and it stays zero from then on, including
     * after joining a [group] -- two interlocked neighbors' tabs/blanks
     * only actually line up when both are drawn upright.
     */
    var pileRotationDegrees: Float = 0f

    // Built lazily (and only once) since Region.setPath does real rasterization
    // work; most pieces are dragged/redrawn far more often than they're
    // hit-tested for the first time.
    private val hitRegion: Region by lazy {
        Region().apply { setPath(outline, Region(0, 0, width, height)) }
    }

    /** [localX]/[localY] are relative to this piece's own bitmap, i.e. already
     * had [currentX]/[currentY] subtracted out by the caller. */
    fun containsLocalPoint(localX: Int, localY: Int): Boolean =
        hitRegion.contains(localX, localY)

    /**
     * Draws this piece's *whole* jigsaw-cut silhouette with [paint] --
     * filled, for the procedural backside ([PieceBackRenderer]) and for
     * the thickness sliver/elevation shadow (see
     * [PuzzleBoardView.drawThickness], which clips a connected neighbor's
     * territory out of the canvas itself before calling this, rather than
     * needing a separately-shaped path here -- two adjacent, correctly
     * interlocked pieces don't actually overlap in *area*, so cutting one
     * piece's outline by the other's doesn't remove anything on its own).
     * The front-facing border cares which particular side is connected --
     * see [drawSide]. [canvas] must already be translated so its origin
     * sits at ([currentX], [currentY]) -- [outline] itself is in the
     * piece's own local bitmap coordinates, same as everywhere else it's
     * used ([containsLocalPoint], [cutPiece]).
     */
    fun drawSilhouette(canvas: Canvas, paint: Paint) {
        canvas.drawPath(outline, paint)
    }

    /**
     * Draws just this piece's [side] -- not its whole silhouette -- with
     * [paint]. [PuzzleBoardView] uses this to stroke only the borders
     * that aren't shared with an already-connected neighbor, so a solved
     * seam goes un-outlined instead of showing a border on both sides of
     * the join. Same coordinate-space contract as [drawSilhouette].
     */
    fun drawSide(canvas: Canvas, side: PieceSide, paint: Paint) {
        canvas.drawPath(sideOutlines.getValue(side), paint)
    }

    fun recycle() {
        if (!bitmap.isRecycled) bitmap.recycle()
    }
}
