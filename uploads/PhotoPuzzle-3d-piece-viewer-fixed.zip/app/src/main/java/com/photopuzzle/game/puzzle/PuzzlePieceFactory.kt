package com.photopuzzle.game.puzzle

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Path
import android.graphics.RectF
import java.util.EnumMap
import kotlin.math.ceil
import kotlin.math.floor

internal object PuzzlePieceFactory {

    /**
     * Cuts [source] into a `rows` x `cols` grid of interlocking jigsaw
     * pieces. Each returned piece owns its own small [Bitmap]; [source]
     * itself is left untouched (caller keeps ownership of it).
     *
     * [originX]/[originY] shift every piece's [PuzzlePiece.homeX]/[homeY]
     * out from [source]'s own top-left to wherever the caller's board
     * places the photo/reference area -- e.g. centered with room to spare
     * on every side for scattering, rather than filling the board itself.
     * Left at 0f, home positions match [source]'s own coordinates exactly
     * as before.
     */
    fun createPieces(
        source: Bitmap,
        rows: Int,
        cols: Int,
        seed: Long,
        originX: Float = 0f,
        originY: Float = 0f
    ): List<PuzzlePiece> {
        require(rows >= 2 && cols >= 2) { "A puzzle needs at least a 2x2 grid" }
        require(source.width > 0 && source.height > 0) { "Source bitmap is empty" }

        val edgeData = EdgeGeneratorProvider.get().generate(rows, cols, seed)
        val hEdgeCount = (rows - 1) * cols

        fun edgePair(index: Int) = edgeData[index * 2] to edgeData[index * 2 + 1]
        fun horizontalSign(r: Int, c: Int) = edgePair(r * cols + c)
        fun verticalSign(r: Int, c: Int) = edgePair(hEdgeCount + r * (cols - 1) + c)

        fun edgeSignAt(side: PieceSide, r: Int, c: Int): Pair<Float, Float> = when (side) {
            PieceSide.TOP -> if (r == 0) FLAT else
                horizontalSign(r - 1, c).let { (s, j) -> -s to -j }
            PieceSide.BOTTOM -> if (r == rows - 1) FLAT else horizontalSign(r, c)
            PieceSide.LEFT -> if (c == 0) FLAT else
                verticalSign(r, c - 1).let { (s, j) -> -s to -j }
            PieceSide.RIGHT -> if (c == cols - 1) FLAT else verticalSign(r, c)
        }

        val cellW = source.width.toFloat() / cols
        val cellH = source.height.toFloat() / rows
        val bounds = RectF()
        val pieces = ArrayList<PuzzlePiece>(rows * cols)

        for (r in 0 until rows) {
            for (c in 0 until cols) {
                val outline = buildPieceOutline(r, c, cellW, cellH) { side -> edgeSignAt(side, r, c) }

                outline.combined.computeBounds(bounds, true)
                pieces += cutPiece(source, r, c, outline, bounds, originX, originY)
            }
        }
        return pieces
    }

    /** A piece's outline, two ways: [combined] is the single closed path
     * used for hit-testing, clipping the bitmap out of the source, and the
     * procedural backside -- unchanged from before. [sides] is the same
     * geometry again, but as four independent per-side paths rather than
     * one continuous one, so [PuzzleBoardView] can later stroke/fill just
     * the sides that are still open and skip the ones already connected
     * to a neighbor. Both are built from the exact same
     * [PieceEdgeShape.addEdge] calls with the exact same arguments, so
     * there's no risk of the two views of the same piece drifting apart. */
    private class PieceOutline(val combined: Path, val sides: Map<PieceSide, Path>)

    private fun buildPieceOutline(
        r: Int,
        c: Int,
        cellW: Float,
        cellH: Float,
        edgeAt: (side: PieceSide) -> Pair<Float, Float>
    ): PieceOutline {
        val ox = c * cellW
        val oy = r * cellH
        val combined = Path().apply { moveTo(ox, oy) }
        val sides = EnumMap<PieceSide, Path>(PieceSide::class.java)

        fun appendSide(
            side: PieceSide,
            startX: Float,
            startY: Float,
            dirX: Float,
            dirY: Float,
            normalX: Float,
            normalY: Float,
            length: Float
        ) {
            val (sign, jitter) = edgeAt(side)
            PieceEdgeShape.addEdge(combined, startX, startY, dirX, dirY, normalX, normalY, length, sign, jitter)
            sides[side] = Path().apply { moveTo(startX, startY) }.also {
                PieceEdgeShape.addEdge(it, startX, startY, dirX, dirY, normalX, normalY, length, sign, jitter)
            }
        }

        appendSide(PieceSide.TOP, ox, oy, 1f, 0f, 0f, -1f, cellW)
        appendSide(PieceSide.RIGHT, ox + cellW, oy, 0f, 1f, 1f, 0f, cellH)
        appendSide(PieceSide.BOTTOM, ox + cellW, oy + cellH, -1f, 0f, 0f, 1f, cellW)
        appendSide(PieceSide.LEFT, ox, oy + cellH, 0f, -1f, -1f, 0f, cellH)

        combined.close()
        return PieceOutline(combined, sides)
    }

    private fun cutPiece(
        source: Bitmap,
        r: Int,
        c: Int,
        outline: PieceOutline,
        bounds: RectF,
        originX: Float,
        originY: Float
    ): PuzzlePiece {
        val bitmapW = ceil(bounds.width()).toInt().coerceAtLeast(1)
        val bitmapH = ceil(bounds.height()).toInt().coerceAtLeast(1)

        // By construction no piece's tab ever reaches past the source
        // bitmap's own edges (the outer grid border is always flat -- see
        // edgeAt() above), so these coerceIn calls are a defensive no-op in
        // practice rather than something that routinely clips real content.
        val srcLeft = floor(bounds.left).toInt().coerceIn(0, source.width)
        val srcTop = floor(bounds.top).toInt().coerceIn(0, source.height)
        val srcRight = ceil(bounds.right).toInt().coerceIn(0, source.width)
        val srcBottom = ceil(bounds.bottom).toInt().coerceIn(0, source.height)
        val subWidth = (srcRight - srcLeft).coerceAtLeast(1)
        val subHeight = (srcBottom - srcTop).coerceAtLeast(1)

        val sourceRegion = Bitmap.createBitmap(source, srcLeft, srcTop, subWidth, subHeight)
        val pieceBitmap = Bitmap.createBitmap(bitmapW, bitmapH, Bitmap.Config.ARGB_8888)

        val localPath = Path(outline.combined).apply { offset(-bounds.left, -bounds.top) }
        val localSides = outline.sides.mapValuesTo(EnumMap<PieceSide, Path>(PieceSide::class.java)) { (_, sidePath) ->
            Path(sidePath).apply { offset(-bounds.left, -bounds.top) }
        }
        Canvas(pieceBitmap).apply {
            save()
            clipPath(localPath)
            drawBitmap(sourceRegion, srcLeft - bounds.left, srcTop - bounds.top, null)
            restore()
        }
        sourceRegion.recycle()

        return PuzzlePiece(
            row = r,
            col = c,
            bitmap = pieceBitmap,
            outline = localPath,
            sideOutlines = localSides,
            homeX = bounds.left + originX,
            homeY = bounds.top + originY
        )
    }

    private val FLAT = 0f to 0f
}
