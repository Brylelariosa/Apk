package com.photopuzzle.game.puzzle.render3d

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.opengl.Matrix
import com.photopuzzle.game.R
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.ShortBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.jvm.Volatile
import kotlin.math.max
import kotlin.math.sin

/**
 * Renders one piece at a time as a lit, textured 3D solid. Owns the GLES
 * resources (shader program, this piece's texture, its vertex/index
 * buffers); the data to render comes from outside via [setPiece].
 *
 * [setPiece] and every other member here (aside from the two exceptions
 * noted below) must only be called from this view's own GL thread -- in
 * practice, that means through [android.opengl.GLSurfaceView.queueEvent],
 * which is how [Piece3DView] calls in from the main thread. `queueEvent`
 * runnables only ever run once the GL thread has a current context (its
 * very first acts are creating that context and calling
 * [onSurfaceCreated]), so there's no "surface not ready yet" case for
 * [setPiece] to guard against.
 *
 * The two exceptions are [yaw]/[pitch]/[recordInteraction] together:
 * they're written from the *main* thread as the user drags, and read (and,
 * for [yaw], sometimes written) from the GL thread every [onDrawFrame].
 * They're plain `@Volatile` fields rather than behind a lock because the
 * two threads never actually write the same field at the same moment: the
 * main thread only writes [yaw]/[pitch] while the user is actively
 * dragging, and dragging is exactly what keeps [recordInteraction] calls
 * frequent enough to suppress this renderer's own idle auto-rotate writes
 * to that same [yaw] field -- so at any given moment, only one side is
 * writing it.
 */
internal class Piece3DRenderer(context: Context) : GLSurfaceView.Renderer {

    @Volatile var yaw: Float = INITIAL_YAW_DEGREES
    @Volatile var pitch: Float = INITIAL_PITCH_DEGREES

    @Volatile private var lastInteractionAtMs: Long = System.currentTimeMillis()

    fun recordInteraction() {
        lastInteractionAtMs = System.currentTimeMillis()
    }

    private var program: GlProgram? = null
    private var textureHandle: Int = 0

    private var vertexBuffer: FloatBuffer? = null
    private var indexBuffer: ShortBuffer? = null
    private var indexCount: Int = 0
    private var boundingRadius: Float = DEFAULT_BOUNDING_RADIUS

    private var viewportWidth: Int = 1
    private var viewportHeight: Int = 1
    private var lastFrameNanos: Long = 0L

    private val modelMatrix = FloatArray(16)
    private val viewMatrix = FloatArray(16)
    private val projMatrix = FloatArray(16)
    private val viewProjMatrix = FloatArray(16)
    private val mvpMatrix = FloatArray(16)
    private val normalMatrix3 = FloatArray(9)

    // Read once here from colors.xml -- the same resources
    // PieceBackRenderer and the 2D board's thickness/back drawing already
    // use -- rather than hardcoded a second time, so the 3D piece's
    // back/rim/background can't silently drift out of sync with the 2D
    // board's own palette if that palette is ever retouched.
    private val backgroundColor = readColorRgb(context, R.color.colorBoardBackground)
    private val backColor = readColorRgb(context, R.color.colorPieceBackBase)
    private val backLineColor = readColorRgb(context, R.color.colorPieceBackLine)

    // Starts as the same fixed "material edge" tone the 2D board's own
    // thickness sliver uses, in case a piece is somehow drawn before
    // setPiece ever runs; setPiece immediately replaces this with a color
    // sampled from that specific piece's own photo (see materialRimColor)
    // so the rim reads as part of the piece rather than an unrelated
    // decoration wrapped around it.
    private val defaultRimColor = readColorRgb(context, R.color.colorPieceThickness)
    private var rimColor = defaultRimColor

    /**
     * Replaces the piece currently on screen and resets the view angle
     * back to the default "just picked it up" framing. See class doc for
     * the GL-thread requirement.
     *
     * [textureBitmap] is uploaded via [GLUtils.texImage2D] -- Android's
     * own Bitmap-to-texture path, which (unlike a hand-rolled
     * `glTexImage2D` over a raw pixel buffer) already accounts for a
     * bitmap's row stride possibly not matching `width * bytesPerPixel`
     * exactly, so a texture built this way can't come out skewed on a
     * device where that stride happens to include padding. This renderer
     * takes ownership of (and recycles) [textureBitmap] once it's
     * uploaded -- callers should pass a bitmap they don't need afterward
     * (see [Piece3DView.show], which passes a
     * defensive copy rather than a piece's own live bitmap).
     */
    fun setPiece(mesh: PieceMeshData, textureBitmap: Bitmap) {
        vertexBuffer = ByteBuffer.allocateDirect(mesh.vertexData.size * BYTES_PER_FLOAT)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()
            .apply { put(mesh.vertexData); position(0) }
        indexBuffer = ByteBuffer.allocateDirect(mesh.indices.size * BYTES_PER_SHORT)
            .order(ByteOrder.nativeOrder())
            .asShortBuffer()
            .apply { put(mesh.indices); position(0) }
        indexCount = mesh.indices.size
        boundingRadius = if (mesh.boundingRadius > 0f) mesh.boundingRadius else DEFAULT_BOUNDING_RADIUS
        rimColor = materialRimColor(averageColor(textureBitmap))

        if (textureHandle != 0) {
            GLES20.glDeleteTextures(1, intArrayOf(textureHandle), 0)
        }
        val handles = IntArray(1)
        GLES20.glGenTextures(1, handles, 0)
        textureHandle = handles[0]
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureHandle)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, textureBitmap, 0)
        textureBitmap.recycle() // already copied into the GPU texture; done with the CPU-side copy

        yaw = INITIAL_YAW_DEGREES
        pitch = INITIAL_PITCH_DEGREES
        recordInteraction()
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(backgroundColor[0], backgroundColor[1], backgroundColor[2], 1f)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        // Deliberately no GL_CULL_FACE: this mesh's triangle winding was
        // checked against a Python-ported validation script (see
        // PolygonTriangulator's doc) but never against an on-device build.
        // If that winding turned out subtly wrong somewhere, leaving
        // culling off means it would look slightly off rather than
        // silently dropping a whole face.
        program = GlProgram(PieceShaders.VERTEX, PieceShaders.FRAGMENT)
        lastFrameNanos = System.nanoTime()
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        viewportWidth = width.coerceAtLeast(1)
        viewportHeight = height.coerceAtLeast(1)
        GLES20.glViewport(0, 0, viewportWidth, viewportHeight)
    }

    override fun onDrawFrame(gl: GL10?) {
        val now = System.nanoTime()
        val deltaSeconds = ((now - lastFrameNanos).coerceAtLeast(0L) / 1_000_000_000f).coerceAtMost(0.1f)
        lastFrameNanos = now

        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        val activeProgram = program ?: return
        val buffer = vertexBuffer ?: return
        val indices = indexBuffer ?: return
        if (indexCount == 0) return

        if (System.currentTimeMillis() - lastInteractionAtMs > IDLE_DELAY_MS) {
            yaw = (yaw + AUTO_ROTATE_DEGREES_PER_SECOND * deltaSeconds) % 360f
        }

        val halfFovRad = degToRad(CAMERA_FOV_Y_DEGREES / 2f)
        val cameraDistance = max(boundingRadius / sin(halfFovRad), MIN_CAMERA_DISTANCE) * CAMERA_FRAMING_MARGIN
        val near = (cameraDistance - boundingRadius * 3f).coerceAtLeast(cameraDistance * 0.02f)
        val far = cameraDistance + boundingRadius * 3f
        val aspect = viewportWidth.toFloat() / viewportHeight.toFloat()

        Matrix.setIdentityM(modelMatrix, 0)
        Matrix.rotateM(modelMatrix, 0, pitch, 1f, 0f, 0f)
        Matrix.rotateM(modelMatrix, 0, yaw, 0f, 1f, 0f)

        Matrix.setLookAtM(viewMatrix, 0, 0f, 0f, cameraDistance, 0f, 0f, 0f, 0f, 1f, 0f)
        Matrix.perspectiveM(projMatrix, 0, CAMERA_FOV_Y_DEGREES, aspect, near, far)
        Matrix.multiplyMM(viewProjMatrix, 0, projMatrix, 0, viewMatrix, 0)
        Matrix.multiplyMM(mvpMatrix, 0, viewProjMatrix, 0, modelMatrix, 0)
        mat4RotationToMat3(modelMatrix, normalMatrix3)

        activeProgram.use()
        GLES20.glUniformMatrix4fv(activeProgram.uniform("uMvpMatrix"), 1, false, mvpMatrix, 0)
        GLES20.glUniformMatrix4fv(activeProgram.uniform("uModelMatrix"), 1, false, modelMatrix, 0)
        GLES20.glUniformMatrix3fv(activeProgram.uniform("uNormalMatrix"), 1, false, normalMatrix3, 0)
        GLES20.glUniform3f(activeProgram.uniform("uLightDir"), LIGHT_DIR_X, LIGHT_DIR_Y, LIGHT_DIR_Z)
        GLES20.glUniform3f(activeProgram.uniform("uViewPos"), 0f, 0f, cameraDistance)
        GLES20.glUniform3f(activeProgram.uniform("uBackColor"), backColor[0], backColor[1], backColor[2])
        GLES20.glUniform3f(activeProgram.uniform("uBackLineColor"), backLineColor[0], backLineColor[1], backLineColor[2])
        GLES20.glUniform3f(activeProgram.uniform("uRimColor"), rimColor[0], rimColor[1], rimColor[2])

        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureHandle)
        GLES20.glUniform1i(activeProgram.uniform("uTexture"), 0)

        bindAttrib(activeProgram, buffer, "aPosition", PieceMeshData.POSITION_COMPONENTS, PieceMeshData.POSITION_OFFSET_BYTES)
        bindAttrib(activeProgram, buffer, "aNormal", PieceMeshData.NORMAL_COMPONENTS, PieceMeshData.NORMAL_OFFSET_BYTES)
        bindAttrib(activeProgram, buffer, "aTexCoord", PieceMeshData.UV_COMPONENTS, PieceMeshData.UV_OFFSET_BYTES)
        bindAttrib(activeProgram, buffer, "aFaceId", PieceMeshData.FACE_ID_COMPONENTS, PieceMeshData.FACE_ID_OFFSET_BYTES)

        indices.position(0)
        GLES20.glDrawElements(GLES20.GL_TRIANGLES, indexCount, GLES20.GL_UNSIGNED_SHORT, indices)
    }

    private fun bindAttrib(program: GlProgram, buffer: FloatBuffer, name: String, components: Int, offsetBytes: Int) {
        val location = program.attrib(name)
        if (location < 0) return // shader doesn't use this attribute; nothing to bind
        GLES20.glEnableVertexAttribArray(location)
        buffer.position(offsetBytes / BYTES_PER_FLOAT)
        GLES20.glVertexAttribPointer(location, components, GLES20.GL_FLOAT, false, PieceMeshData.STRIDE_BYTES, buffer)
    }

    /** Copies just the rotation part of a 4x4 column-major matrix into a
     * 3x3 one. No inverse-transpose correction is needed here (unlike a
     * general-purpose model matrix) because [modelMatrix] only ever holds
     * rotations -- never scale or shear -- and pure rotations already
     * transform normals correctly as-is. */
    private fun mat4RotationToMat3(m4: FloatArray, out9: FloatArray) {
        out9[0] = m4[0]; out9[1] = m4[1]; out9[2] = m4[2]
        out9[3] = m4[4]; out9[4] = m4[5]; out9[5] = m4[6]
        out9[6] = m4[8]; out9[7] = m4[9]; out9[8] = m4[10]
    }

    private fun degToRad(degrees: Float): Float = degrees * DEG_TO_RAD

    private fun readColorRgb(context: Context, colorRes: Int): FloatArray {
        val color = context.getColor(colorRes)
        return floatArrayOf(Color.red(color) / 255f, Color.green(color) / 255f, Color.blue(color) / 255f)
    }

    /**
     * Approximates [bitmap]'s overall color by averaging a coarse grid of
     * samples across it -- a few dozen pixel reads rather than a full
     * per-pixel scan, which is plenty for a rim color that only needs to
     * feel like it belongs to the piece, not reproduce its exact palette.
     */
    private fun averageColor(bitmap: Bitmap): FloatArray {
        val stepsX = COLOR_SAMPLE_GRID.coerceAtMost(bitmap.width)
        val stepsY = COLOR_SAMPLE_GRID.coerceAtMost(bitmap.height)
        if (stepsX <= 0 || stepsY <= 0) return defaultRimColor

        var rSum = 0L
        var gSum = 0L
        var bSum = 0L
        for (sx in 0 until stepsX) {
            for (sy in 0 until stepsY) {
                val x = ((sx + 0.5f) / stepsX * bitmap.width).toInt().coerceIn(0, bitmap.width - 1)
                val y = ((sy + 0.5f) / stepsY * bitmap.height).toInt().coerceIn(0, bitmap.height - 1)
                val pixel = bitmap.getPixel(x, y)
                rSum += Color.red(pixel)
                gSum += Color.green(pixel)
                bSum += Color.blue(pixel)
            }
        }
        val count = stepsX * stepsY
        return floatArrayOf(rSum.toFloat() / count / 255f, gSum.toFloat() / count / 255f, bSum.toFloat() / count / 255f)
    }

    /**
     * Turns an [averageColor] sample into a rim color: keeps that color's
     * hue -- so the piece's cut edge feels like the same material as its
     * face, not an unrelated decoration wrapped around it -- but pins
     * saturation/brightness to the same values [R.color.colorPieceThickness]
     * (see colors.xml) was tuned at. A photo that's very dark, very
     * bright, or nearly grayscale still gets a rim with the same legible
     * weight the original fixed color had, rather than one that
     * disappears into the background or blows out to white.
     */
    private fun materialRimColor(sample: FloatArray): FloatArray {
        val hsv = FloatArray(3)
        Color.RGBToHSV(
            (sample[0] * 255f).toInt().coerceIn(0, 255),
            (sample[1] * 255f).toInt().coerceIn(0, 255),
            (sample[2] * 255f).toInt().coerceIn(0, 255),
            hsv
        )
        // A near-grayscale photo's hue is essentially noise (red, green,
        // and blue too close together to say which direction is "the"
        // color) -- falls back to the original fixed tone rather than
        // tinting the rim some arbitrary hue that has nothing to do with
        // how the photo actually looks.
        if (hsv[1] < MIN_SOURCE_SATURATION) return defaultRimColor
        hsv[1] = RIM_SATURATION
        hsv[2] = RIM_VALUE
        val rgb = Color.HSVToColor(hsv)
        return floatArrayOf(Color.red(rgb) / 255f, Color.green(rgb) / 255f, Color.blue(rgb) / 255f)
    }

    companion object {
        private const val BYTES_PER_FLOAT = 4
        private const val BYTES_PER_SHORT = 2
        private const val DEG_TO_RAD = 0.017453292f // pi / 180

        private const val INITIAL_YAW_DEGREES = -34f
        private const val INITIAL_PITCH_DEGREES = 22f
        private const val IDLE_DELAY_MS = 2200L
        private const val AUTO_ROTATE_DEGREES_PER_SECOND = 12f

        private const val CAMERA_FOV_Y_DEGREES = 45f
        private const val CAMERA_FRAMING_MARGIN = 1.35f // headroom so the piece doesn't touch the viewport edges
        private const val MIN_CAMERA_DISTANCE = 1f
        private const val DEFAULT_BOUNDING_RADIUS = 1f

        // Upper-front-left, so the specular highlight reads clearly as the
        // piece rotates rather than sitting flat-on.
        private const val LIGHT_DIR_X = -0.35f
        private const val LIGHT_DIR_Y = 0.55f
        private const val LIGHT_DIR_Z = 0.75f

        // materialRimColor's sample grid (COLOR_SAMPLE_GRID x
        // COLOR_SAMPLE_GRID points) and the saturation/value it pins every
        // sampled hue to -- matching #B08D57 (colorPieceThickness's own
        // value, see colors.xml), the tone this whole scheme replaces.
        private const val COLOR_SAMPLE_GRID = 8
        private const val MIN_SOURCE_SATURATION = 0.08f
        private const val RIM_SATURATION = 0.5f
        private const val RIM_VALUE = 0.68f
    }
}
