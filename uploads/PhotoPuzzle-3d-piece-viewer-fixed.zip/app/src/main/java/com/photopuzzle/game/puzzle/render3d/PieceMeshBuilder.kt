package com.photopuzzle.game.puzzle.render3d

import android.graphics.PathMeasure
import android.graphics.PointF
import com.photopuzzle.game.puzzle.PuzzlePiece
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Turns a [PuzzlePiece]'s existing 2D silhouette -- the same
 * [android.graphics.Path] the 2D game already cuts the piece's bitmap with
 * and draws on screen -- into an extruded 3D solid: a textured front cap,
 * a matching back cap, and a wall of the given thickness connecting them.
 *
 * Deliberately does *not* re-derive the tab/blank knob shape from
 * `PieceEdgeShape`/`PuzzlePieceFactory`'s row/column adjacency logic;
 * sampling [PuzzlePiece.outline] instead means there is no second place a
 * piece's silhouette is computed, so the 3D model can never drift out of
 * sync with the 2D one.
 */
internal object PieceMeshBuilder {

    /** Points sampled evenly by arc length around the piece's outline.
     * Purely a visual-smoothness/vertex-count trade-off -- one piece at a
     * time is cheap to render at any of these sizes, so this favors a
     * smooth-looking curved knob over a lean vertex count. */
    private const val DEFAULT_SAMPLE_COUNT = 160

    /** Full front-to-back depth, as a fraction of the piece's shorter
     * bounding-box side -- keeps the piece looking like a chunky, tactile
     * physical object rather than a paper cutout, at any grid size. */
    private const val THICKNESS_FRACTION = 0.16f

    fun build(piece: PuzzlePiece, sampleCount: Int = DEFAULT_SAMPLE_COUNT): PieceMeshData {
        val triangulated = PolygonTriangulator.triangulate(sampleOutline(piece, sampleCount))
        val boundary = triangulated.orderedPoints
        val n = boundary.size
        if (n < 3) return PieceMeshData(FloatArray(0), ShortArray(0), 0f)

        var minX = Float.MAX_VALUE
        var minY = Float.MAX_VALUE
        var maxX = -Float.MAX_VALUE
        var maxY = -Float.MAX_VALUE
        for (p in boundary) {
            minX = min(minX, p.x); maxX = max(maxX, p.x)
            minY = min(minY, p.y); maxY = max(maxY, p.y)
        }
        // Centering on the piece's own bounding box (rather than, say, the
        // board position it belongs at) makes "rotate in place" simple for
        // the renderer: no separate pivot offset to track alongside it.
        val centerX = (minX + maxX) / 2f
        val centerY = (minY + maxY) / 2f
        val halfThickness = min(maxX - minX, maxY - minY).coerceAtLeast(1f) * THICKNESS_FRACTION / 2f

        val bitmapW = piece.width.toFloat().coerceAtLeast(1f)
        val bitmapH = piece.height.toFloat().coerceAtLeast(1f)
        val wallNormals = averagedWallNormals(boundary)

        // Vertex ranges: [0, n) front cap, [n, 2n) back cap, [2n, 3n) wall
        // top ring, [3n, 4n) wall bottom ring. Front/back need their own
        // vertices even though they share XY with the wall rings, since a
        // cap vertex's normal points straight along Z while a wall
        // vertex's normal at the same XY points outward in the XY plane --
        // sharing one vertex between them would wrongly blend the two.
        val vertexData = FloatArray(n * 4 * PieceMeshData.FLOATS_PER_VERTEX)
        var boundingRadius = 0f

        fun writeVertex(index: Int, x: Float, y: Float, z: Float, nx: Float, ny: Float, nz: Float, u: Float, v: Float, faceId: Float) {
            val base = index * PieceMeshData.FLOATS_PER_VERTEX
            vertexData[base] = x; vertexData[base + 1] = y; vertexData[base + 2] = z
            vertexData[base + 3] = nx; vertexData[base + 4] = ny; vertexData[base + 5] = nz
            vertexData[base + 6] = u; vertexData[base + 7] = v
            vertexData[base + 8] = faceId
            val r = sqrt(x * x + y * y + z * z)
            if (r > boundingRadius) boundingRadius = r
        }

        for (i in 0 until n) {
            val p = boundary[i]
            val x = p.x - centerX
            val y = p.y - centerY
            // GL texture V is bottom-up; Android bitmap/Path Y grows
            // downward, so this flip is what keeps the photo right-side up
            // once textured onto the front cap.
            val u = p.x / bitmapW
            val v = 1f - p.y / bitmapH

            writeVertex(i, x, y, halfThickness, 0f, 0f, 1f, u, v, PieceMeshData.FACE_FRONT)
            writeVertex(n + i, x, y, -halfThickness, 0f, 0f, -1f, u, v, PieceMeshData.FACE_BACK)

            val wn = wallNormals[i]
            val wallU = i / n.toFloat()
            writeVertex(2 * n + i, x, y, halfThickness, wn.x, wn.y, 0f, wallU, 1f, PieceMeshData.FACE_WALL)
            writeVertex(3 * n + i, x, y, -halfThickness, wn.x, wn.y, 0f, wallU, 0f, PieceMeshData.FACE_WALL)
        }

        val indices = ArrayList<Short>(triangulated.triangleIndices.size * 2 + n * 6)
        val tri = triangulated.triangleIndices
        var t = 0
        while (t < tri.size) {
            // Front cap: the triangulation's own winding.
            indices.add(tri[t].toShort()); indices.add(tri[t + 1].toShort()); indices.add(tri[t + 2].toShort())
            // Back cap: same vertices offset by n, winding reversed so the
            // two caps stay consistent should face culling ever be turned
            // on later (it's left off today -- see Piece3DRenderer -- so
            // this doesn't change what's on screen yet).
            indices.add((n + tri[t]).toShort()); indices.add((n + tri[t + 2]).toShort()); indices.add((n + tri[t + 1]).toShort())
            t += 3
        }
        for (i in 0 until n) {
            val i2 = (i + 1) % n
            val topI = (2 * n + i).toShort(); val topI2 = (2 * n + i2).toShort()
            val bottomI = (3 * n + i).toShort(); val bottomI2 = (3 * n + i2).toShort()
            indices.add(topI); indices.add(bottomI); indices.add(bottomI2)
            indices.add(topI); indices.add(bottomI2); indices.add(topI2)
        }

        return PieceMeshData(vertexData, indices.toShortArray(), boundingRadius)
    }

    /** Walks [PuzzlePiece.outline] with a [PathMeasure] to flatten its
     * curves into [sampleCount] points, evenly spaced by arc length. */
    private fun sampleOutline(piece: PuzzlePiece, sampleCount: Int): List<PointF> {
        val measure = PathMeasure(piece.outline, true)
        val length = measure.length
        if (length <= 0f || sampleCount < 3) {
            // Degenerate outline (shouldn't happen for a real piece) --
            // fall back to a flat triangle so the mesh builder still
            // returns something rather than crashing.
            return listOf(PointF(0f, 0f), PointF(piece.width.toFloat(), 0f), PointF(0f, piece.height.toFloat()))
        }
        val pos = FloatArray(2)
        val raw = ArrayList<PointF>(sampleCount)
        for (i in 0 until sampleCount) {
            if (measure.getPosTan(length * i / sampleCount, pos, null)) {
                raw.add(PointF(pos[0], pos[1]))
            }
        }
        return dedupeConsecutive(raw)
    }

    private fun dedupeConsecutive(points: List<PointF>, epsilon: Float = 0.01f): List<PointF> {
        if (points.isEmpty()) return points
        val out = ArrayList<PointF>(points.size)
        for (p in points) {
            val last = out.lastOrNull()
            if (last == null || sqrt((p.x - last.x) * (p.x - last.x) + (p.y - last.y) * (p.y - last.y)) > epsilon) {
                out.add(p)
            }
        }
        if (out.size > 1) {
            val first = out.first(); val last = out.last()
            if (sqrt((first.x - last.x) * (first.x - last.x) + (first.y - last.y) * (first.y - last.y)) <= epsilon) {
                out.removeAt(out.size - 1)
            }
        }
        return out
    }

    /**
     * Per-vertex outward normal, averaged from the two boundary edges
     * meeting at that vertex -- gives the wall smooth-looking shading
     * around a piece's curved knobs instead of a faceted look, while
     * staying flat (the average of two equal normals) along its straight
     * runs. [boundary] must already be wound counter-clockwise, which
     * [PolygonTriangulator.Result.orderedPoints] guarantees.
     */
    private fun averagedWallNormals(boundary: List<PointF>): List<PointF> {
        val n = boundary.size
        val edgeNormals = Array(n) { i ->
            val a = boundary[i]
            val b = boundary[(i + 1) % n]
            val dx = b.x - a.x
            val dy = b.y - a.y
            val len = sqrt(dx * dx + dy * dy)
            if (len < 1e-6f) PointF(0f, 0f) else PointF(dy / len, -dx / len)
        }
        return List(n) { i ->
            val prev = edgeNormals[(i - 1 + n) % n]
            val curr = edgeNormals[i]
            val sx = prev.x + curr.x
            val sy = prev.y + curr.y
            val len = sqrt(sx * sx + sy * sy)
            if (len < 1e-6f) curr else PointF(sx / len, sy / len)
        }
    }
}
