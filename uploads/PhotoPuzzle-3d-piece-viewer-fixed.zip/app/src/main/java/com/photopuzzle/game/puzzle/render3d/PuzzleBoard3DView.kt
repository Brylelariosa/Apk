package com.photopuzzle.game.puzzle.render3d

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.opengl.GLSurfaceView
import android.util.AttributeSet
import android.view.MotionEvent
import com.photopuzzle.game.puzzle.PieceGroup
import com.photopuzzle.game.puzzle.PuzzleGame
import com.photopuzzle.game.puzzle.PuzzlePiece
import com.photopuzzle.game.puzzle.PuzzlePieceFactory
import com.photopuzzle.game.util.ImageUtils
import kotlin.math.roundToInt

/**
 * The whole puzzle board, rendered as real 3D: every piece a lit, extruded
 * solid lying on a table (see [PuzzleBoard3DRenderer]), replacing the flat
 * bitmap-and-outline drawing of `PuzzleBoardView`. All the *rules* --
 * where pieces are, which are connected, when the puzzle is solved --
 * still come from the same [PuzzleGame] the 2D board used, unchanged; this
 * view only builds the game, turns touches into calls on it, and hosts the
 * renderer that draws whatever it reports.
 *
 * Same public surface as the old board ([start], [shuffle], [recycleAll],
 * [onSolved], [onPiecePlaced], [topPiece]) so [com.photopuzzle.game.puzzle.PuzzleActivity]
 * barely changes.
 *
 * *** Not ported from the 2D board (yet) ***
 * Momentum-fling on release, the flip-to-see-the-back gesture, the confetti
 * celebration, pieces sliding themselves out of a crowded spot, and the
 * drop shadow / lift-tilt animation. What is here is the core loop: pick a
 * piece up, drag it, drop it, snap it onto a correct neighbor, finish the
 * puzzle.
 *
 * *** Threading ***
 * Touches run on the main thread, drawing on the GL thread; both read and
 * write the same [PuzzleGame] lists, so every touch-driven change -- and
 * the renderer's per-frame snapshot of them -- happens under
 * `synchronized(game)`.
 */
class PuzzleBoard3DView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : GLSurfaceView(context, attrs) {

    private val renderer = PuzzleBoard3DRenderer(context)

    private var game: PuzzleGame? = null
    private var referenceBitmap: Bitmap? = null

    // The board's own pixel size, fixed at start(): the renderer's camera
    // frames exactly this rectangle, and touches are mapped back into it
    // (see boardX/boardY) even if this view's size were to change later.
    private var boardWidth = 0
    private var boardHeight = 0

    private var draggingPiece: PuzzlePiece? = null
    private var lastBoardX = 0f
    private var lastBoardY = 0f
    private var solvedPending = false

    var onSolved: (() -> Unit)? = null
    var onPiecePlaced: ((connected: Int, total: Int) -> Unit)? = null

    init {
        setEGLContextClientVersion(2)
        // Same explicit config Piece3DView asks for -- guarantees the depth
        // buffer the per-group depth testing in the renderer relies on.
        setEGLConfigChooser(8, 8, 8, 8, 16, 0)
        // See the identical note in Piece3DView: keeps the GL context (and
        // every piece's uploaded texture) alive across pause/resume.
        setPreserveEGLContextOnPause(true)
        setRenderer(renderer)
        renderMode = RENDERMODE_CONTINUOUSLY
    }

    /**
     * Starts a new puzzle from [sourcePhoto]. This view takes ownership of
     * [sourcePhoto] from this call onward (and of everything derived from
     * it) -- the caller should not use or recycle it afterward; call
     * [recycleAll] (e.g. from `onDestroy`) to free it instead.
     *
     * Waits for layout if this view doesn't have a size yet, since pieces
     * are fit and scattered against the view's actual pixel dimensions.
     */
    fun start(sourcePhoto: Bitmap, rows: Int, cols: Int, seed: Long = System.nanoTime()) {
        if (width == 0 || height == 0) {
            post { start(sourcePhoto, rows, cols, seed) }
            return
        }

        recycleAll()
        boardWidth = width
        boardHeight = height

        // Same photo-area sizing the 2D board used, so there's room around
        // the picture for the pile.
        val fitted = ImageUtils.fitToBounds(
            sourcePhoto,
            (boardWidth * PHOTO_AREA_WIDTH_FRACTION).roundToInt(),
            (boardHeight * PHOTO_AREA_HEIGHT_FRACTION).roundToInt()
        )
        if (fitted !== sourcePhoto) sourcePhoto.recycle()

        // The one place the renderer's left-right mirroring (see
        // PuzzleBoard3DRenderer's class doc) gets cancelled: cut the pieces
        // from the mirrored photo, and the assembled board comes out
        // reading the right way round.
        val mirrored = mirrorHorizontally(fitted)
        val referenceLeft = (boardWidth - mirrored.width) / 2f
        val referenceTop = (boardHeight - mirrored.height) / 2f

        val pieces = PuzzlePieceFactory.createPieces(mirrored, rows, cols, seed, referenceLeft, referenceTop)
            .toMutableList()
        val newGame = PuzzleGame(pieces, SNAP_THRESHOLD_DP * resources.displayMetrics.density)
        newGame.onSolved = { solvedPending = true }
        newGame.scatter(boardWidth, boardHeight, seed)

        game = newGame
        referenceBitmap = mirrored
        val boardW = boardWidth.toFloat()
        val boardH = boardHeight.toFloat()
        queueEvent {
            renderer.setGame(newGame, pieces, boardW, boardH, mirrored, referenceLeft, referenceTop)
        }
    }

    /** Re-scatters every piece into a fresh pile, dropping any connections. */
    fun shuffle(seed: Long = System.nanoTime()) {
        val activeGame = game ?: return
        endDrag()
        synchronized(activeGame) { activeGame.scatter(boardWidth, boardHeight, seed) }
    }

    /** The piece currently drawn frontmost -- whatever the player picked up
     * most recently, or `null` before a game has started. Read-only, so a
     * "View in 3D" trigger can't disturb an in-progress touch. */
    internal fun topPiece(): PuzzlePiece? {
        val activeGame = game ?: return null
        return synchronized(activeGame) { activeGame.piecesInDrawOrder().lastOrNull() }
    }

    fun recycleAll() {
        endDrag()
        game?.recycleAll()
        game = null
        referenceBitmap?.takeIf { !it.isRecycled }?.recycle()
        referenceBitmap = null
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val activeGame = game ?: return true
        val boardX = boardWidth * (1f - event.x / width)
        val boardY = boardHeight * (event.y / height)

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val piece = synchronized(activeGame) {
                    activeGame.findTopPieceAt(boardX, boardY)?.also {
                        activeGame.bringToFront(it)
                        activeGame.straighten(it)
                    }
                } ?: return true
                draggingPiece = piece
                renderer.liftedGroup = piece.group
                lastBoardX = boardX
                lastBoardY = boardY
            }
            MotionEvent.ACTION_MOVE -> {
                val piece = draggingPiece ?: return true
                synchronized(activeGame) {
                    activeGame.moveBy(piece, boardX - lastBoardX, boardY - lastBoardY)
                    keepOnBoard(piece.group)
                }
                lastBoardX = boardX
                lastBoardY = boardY
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val piece = draggingPiece ?: return true
                endDrag()
                val connected = synchronized(activeGame) { activeGame.tryConnect(piece) }
                if (connected) onPiecePlaced?.invoke(activeGame.connectedCount, activeGame.pieceCount)
                if (solvedPending) {
                    solvedPending = false
                    onSolved?.invoke()
                }
            }
        }
        return true
    }

    private fun endDrag() {
        draggingPiece = null
        renderer.liftedGroup = null
    }

    /** Shifts [group] back inside the board if a drag pushed any part of it
     * past an edge, so a piece can't be thrown somewhere unreachable. */
    private fun keepOnBoard(group: PieceGroup) {
        var left = Float.MAX_VALUE
        var top = Float.MAX_VALUE
        var right = -Float.MAX_VALUE
        var bottom = -Float.MAX_VALUE
        for (piece in group.members) {
            left = minOf(left, piece.currentX)
            top = minOf(top, piece.currentY)
            right = maxOf(right, piece.currentX + piece.width)
            bottom = maxOf(bottom, piece.currentY + piece.height)
        }
        val dx = when {
            left < 0f -> -left
            right > boardWidth -> boardWidth - right
            else -> 0f
        }
        val dy = when {
            top < 0f -> -top
            bottom > boardHeight -> boardHeight - bottom
            else -> 0f
        }
        group.moveBy(dx, dy)
    }

    private fun mirrorHorizontally(source: Bitmap): Bitmap {
        val flip = Matrix().apply { postScale(-1f, 1f) }
        val mirrored = Bitmap.createBitmap(source, 0, 0, source.width, source.height, flip, true)
        if (mirrored !== source) source.recycle()
        return mirrored
    }

    private companion object {
        const val PHOTO_AREA_WIDTH_FRACTION = 0.62f
        const val PHOTO_AREA_HEIGHT_FRACTION = 0.5f
        const val SNAP_THRESHOLD_DP = 12f
    }
}
