package com.photopuzzle.game.puzzle.render3d

import android.opengl.GLES20

/**
 * Compiles and links a GLES20 vertex+fragment shader pair, and caches
 * attribute/uniform location lookups -- each is a `glGetXLocation`
 * round-trip, cheap but pointless to repeat every frame. Not specific to
 * piece rendering; reusable for any future GLES20 draw call this app adds.
 *
 * Must be constructed on a thread with a current GL context (i.e. from
 * [android.opengl.GLSurfaceView.Renderer] callbacks).
 */
internal class GlProgram(vertexSource: String, fragmentSource: String) {

    val handle: Int

    private val attribLocations = HashMap<String, Int>()
    private val uniformLocations = HashMap<String, Int>()

    init {
        val vertexShader = compileShader(GLES20.GL_VERTEX_SHADER, vertexSource)
        val fragmentShader = compileShader(GLES20.GL_FRAGMENT_SHADER, fragmentSource)
        val program = GLES20.glCreateProgram()
        GLES20.glAttachShader(program, vertexShader)
        GLES20.glAttachShader(program, fragmentShader)
        GLES20.glLinkProgram(program)

        val linked = IntArray(1)
        GLES20.glGetProgramiv(program, GLES20.GL_LINK_STATUS, linked, 0)
        if (linked[0] == 0) {
            val log = GLES20.glGetProgramInfoLog(program)
            GLES20.glDeleteProgram(program)
            error("Piece3D shader program failed to link: $log")
        }
        // Once linked, the program has its own copy of what it needs;
        // the individual shader objects can go.
        GLES20.glDeleteShader(vertexShader)
        GLES20.glDeleteShader(fragmentShader)
        handle = program
    }

    fun attrib(name: String): Int =
        attribLocations.getOrPut(name) { GLES20.glGetAttribLocation(handle, name) }

    fun uniform(name: String): Int =
        uniformLocations.getOrPut(name) { GLES20.glGetUniformLocation(handle, name) }

    fun use() = GLES20.glUseProgram(handle)

    private fun compileShader(type: Int, source: String): Int {
        val shader = GLES20.glCreateShader(type)
        GLES20.glShaderSource(shader, source)
        GLES20.glCompileShader(shader)
        val compiled = IntArray(1)
        GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, compiled, 0)
        if (compiled[0] == 0) {
            val log = GLES20.glGetShaderInfoLog(shader)
            GLES20.glDeleteShader(shader)
            error("Piece3D shader failed to compile: $log")
        }
        return shader
    }
}
