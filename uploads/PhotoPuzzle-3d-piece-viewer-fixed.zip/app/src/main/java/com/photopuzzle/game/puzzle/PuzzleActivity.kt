package com.photopuzzle.game.puzzle

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import com.photopuzzle.game.R
import com.photopuzzle.game.puzzle.render3d.Piece3DView
import com.photopuzzle.game.util.ImageUtils

class PuzzleActivity : ComponentActivity() {

    private lateinit var boardView: PuzzleBoardView
    private lateinit var progressLabel: TextView
    private lateinit var winOverlay: View
    private lateinit var piece3DView: Piece3DView
    private lateinit var view3DButton: Button
    private lateinit var drag3DHint: View

    /** Disabled by default so back-press falls through to the normal
     * "leave this screen" behavior; enabled only while the 3D preview is
     * showing, so back-press closes that instead. */
    private val hide3DCallback = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() = hide3DPreview()
    }

    private var rows = 3
    private var cols = 3

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_puzzle)

        boardView = findViewById(R.id.puzzleBoardView)
        progressLabel = findViewById(R.id.progressLabel)
        winOverlay = findViewById(R.id.winOverlay)
        piece3DView = findViewById(R.id.piece3DView)
        view3DButton = findViewById(R.id.view3DButton)
        drag3DHint = findViewById(R.id.drag3DHint)
        onBackPressedDispatcher.addCallback(this, hide3DCallback)

        val imagePath = intent.getStringExtra(EXTRA_IMAGE_PATH)
        if (imagePath == null) {
            finish()
            return
        }

        val bitmap = ImageUtils.loadOrientedBitmap(imagePath, MAX_IMAGE_DIMENSION)
        if (bitmap == null) {
            finish()
            return
        }

        val pieceCount = intent.getIntExtra(EXTRA_PIECE_COUNT, DEFAULT_PIECE_COUNT)
        val (gridRows, gridCols) = PuzzleGridSizing.forPhoto(pieceCount, bitmap.width, bitmap.height)
        rows = gridRows
        cols = gridCols

        progressLabel.text = getString(R.string.progress_format, 0, rows * cols)

        boardView.onSolved = { showWinOverlay() }
        boardView.onPiecePlaced = { locked, total ->
            progressLabel.text = getString(R.string.progress_format, locked, total)
        }
        boardView.start(bitmap, rows, cols)

        findViewById<Button>(R.id.playAgainButton).setOnClickListener {
            winOverlay.animate().cancel()
            winOverlay.visibility = View.GONE
            progressLabel.text = getString(R.string.progress_format, 0, rows * cols)
            boardView.shuffle()
        }
        findViewById<Button>(R.id.newPhotoButton).setOnClickListener { finish() }
        view3DButton.setOnClickListener {
            if (hide3DCallback.isEnabled) hide3DPreview() else show3DPreview()
        }
    }

    /** Builds a 3D mesh for whichever piece is currently drawn frontmost
     * (see [PuzzleBoardView.topPiece]) and shows it full-screen. No-op if
     * the board has no pieces yet. */
    private fun show3DPreview() {
        val piece = boardView.topPiece() ?: return
        piece3DView.show(piece)
        piece3DView.visibility = View.VISIBLE
        piece3DView.onResume()
        drag3DHint.visibility = View.VISIBLE
        view3DButton.text = getString(R.string.back_to_puzzle)
        hide3DCallback.isEnabled = true
    }

    private fun hide3DPreview() {
        piece3DView.onPause()
        piece3DView.visibility = View.GONE
        drag3DHint.visibility = View.GONE
        view3DButton.text = getString(R.string.view_in_3d)
        hide3DCallback.isEnabled = false
    }

    /**
     * Reveals the win overlay only after [PuzzleBoardView]'s own on-solve
     * celebration (border fade, picture pop, confetti) has had room to
     * play -- showing it immediately would instantly cover that animation
     * with an opaque overlay before the player ever sees it. Fades in
     * afterward rather than popping visible, to match.
     */
    private fun showWinOverlay() {
        winOverlay.postDelayed(revealWinOverlay, PuzzleBoardView.COMPLETION_CELEBRATION_DURATION_MS)
    }

    private val revealWinOverlay = Runnable {
        winOverlay.alpha = 0f
        winOverlay.visibility = View.VISIBLE
        winOverlay.animate().alpha(1f).setDuration(WIN_OVERLAY_FADE_MS).start()
    }

    override fun onResume() {
        super.onResume()
        // Only while the 3D preview is actually the thing on screen -- it
        // already gets its own onResume() the moment it's shown (see
        // show3DPreview()), so this covers the "app was backgrounded and
        // came back while the preview was up" case specifically.
        if (hide3DCallback.isEnabled) piece3DView.onResume()
    }

    override fun onPause() {
        super.onPause()
        if (hide3DCallback.isEnabled) piece3DView.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
        winOverlay.removeCallbacks(revealWinOverlay)
        winOverlay.animate().cancel()
        boardView.recycleAll()
    }

    companion object {
        const val EXTRA_IMAGE_PATH = "com.photopuzzle.game.extra.IMAGE_PATH"
        const val EXTRA_PIECE_COUNT = "com.photopuzzle.game.extra.PIECE_COUNT"
        private const val DEFAULT_PIECE_COUNT = 9
        private const val MAX_IMAGE_DIMENSION = 2048
        private const val WIN_OVERLAY_FADE_MS = 300L
    }
}
