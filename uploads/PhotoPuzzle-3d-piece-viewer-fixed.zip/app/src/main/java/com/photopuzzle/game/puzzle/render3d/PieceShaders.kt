package com.photopuzzle.game.puzzle.render3d

/**
 * GLES 2.0 (GLSL ES 1.00) shader source for rendering one [PieceMeshData].
 * A single program handles all three faces -- front, back, wall -- via the
 * `aFaceId` vertex attribute (see [PieceMeshData.FACE_FRONT] and friends)
 * rather than needing separate programs or draw calls per face.
 */
internal object PieceShaders {

    val VERTEX = """
        uniform mat4 uMvpMatrix;
        uniform mat4 uModelMatrix;
        uniform mat3 uNormalMatrix;

        attribute vec3 aPosition;
        attribute vec3 aNormal;
        attribute vec2 aTexCoord;
        attribute float aFaceId;

        varying vec3 vWorldNormal;
        varying vec3 vWorldPos;
        varying vec2 vTexCoord;
        varying float vFaceId;

        void main() {
            vec4 worldPos = uModelMatrix * vec4(aPosition, 1.0);
            vWorldPos = worldPos.xyz;
            vWorldNormal = normalize(uNormalMatrix * aNormal);
            vTexCoord = aTexCoord;
            vFaceId = aFaceId;
            gl_Position = uMvpMatrix * vec4(aPosition, 1.0);
        }
    """.trimIndent()

    // Ambient + Lambertian diffuse + a modest Blinn-Phong specular, all
    // computed in world space so the highlight sweeps across the piece
    // naturally as the user rotates it. Front/back/wall share one lighting
    // path and differ only in `baseColor`, chosen per faceId:
    //  - front:  the piece's own photo texture
    //  - back:   a flat kraft-paper tone plus a cheap procedural diagonal
    //            hatch (matching PieceBackRenderer's 2D look), computed
    //            straight from UV rather than a second texture upload
    //  - wall:   a single rim color (the piece "material" showing through
    //            its cut edge)
    val FRAGMENT = """
        precision mediump float;

        uniform sampler2D uTexture;
        uniform vec3 uLightDir;
        uniform vec3 uViewPos;
        uniform vec3 uBackColor;
        uniform vec3 uBackLineColor;
        uniform vec3 uRimColor;

        varying vec3 vWorldNormal;
        varying vec3 vWorldPos;
        varying vec2 vTexCoord;
        varying float vFaceId;

        void main() {
            vec3 n = normalize(vWorldNormal);
            vec3 l = normalize(uLightDir);
            float diffuse = max(dot(n, l), 0.0);
            vec3 v = normalize(uViewPos - vWorldPos);
            vec3 h = normalize(l + v);
            float specular = pow(max(dot(n, h), 0.0), 28.0);

            vec3 baseColor;
            if (vFaceId < 0.5) {
                baseColor = texture2D(uTexture, vTexCoord).rgb;
            } else if (vFaceId < 1.5) {
                float stripe = fract((vTexCoord.x + vTexCoord.y) * 16.0);
                float line = smoothstep(0.46, 0.5, stripe) - smoothstep(0.5, 0.54, stripe);
                baseColor = mix(uBackColor, uBackLineColor, line * 0.6);
            } else {
                baseColor = uRimColor;
            }

            vec3 ambient = baseColor * 0.45;
            vec3 diffuseTerm = baseColor * diffuse * 0.7;
            vec3 specularTerm = vec3(1.0) * specular * 0.22;
            gl_FragColor = vec4(ambient + diffuseTerm + specularTerm, 1.0);
        }
    """.trimIndent()
}
