package com.photopuzzle.game.puzzle.render3d

/**
 * GLES 2.0 (GLSL ES 1.00) shader source for rendering one [PieceMeshData].
 * A single program handles all three faces -- front, back, wall -- via the
 * `aFaceId` vertex attribute (see [PieceMeshData.FACE_FRONT] and friends)
 * rather than needing separate programs or draw calls per face.
 */
internal object PieceShaders {

    val VERTEX = """
        uniform mat4 uMvpMatrix;
        uniform mat4 uModelMatrix;
        uniform mat3 uNormalMatrix;

        attribute vec3 aPosition;
        attribute vec3 aNormal;
        attribute vec2 aTexCoord;
        attribute float aFaceId;

        varying vec3 vWorldNormal;
        varying vec3 vWorldPos;
        varying vec2 vTexCoord;
        varying float vFaceId;

        void main() {
            vec4 worldPos = uModelMatrix * vec4(aPosition, 1.0);
            vWorldPos = worldPos.xyz;
            vWorldNormal = normalize(uNormalMatrix * aNormal);
            vTexCoord = aTexCoord;
            vFaceId = aFaceId;
            gl_Position = uMvpMatrix * vec4(aPosition, 1.0);
        }
    """.trimIndent()

    // Ambient + Lambertian diffuse + a modest Blinn-Phong specular + a
    // fresnel-style rim light, all computed in world space so the
    // highlight sweeps across the piece naturally as the user rotates it.
    // The rim light is the odd one out: a flat-faced piece has no actual
    // curvature to catch real edge light the way a rounded object would,
    // but approximating it anyway is what stops an otherwise evenly-lit
    // flat face from reading as a lit sticker rather than a solid with
    // depth. Front/back/wall share this whole lighting path and differ
    // only in `baseColor`, chosen per faceId:
    //  - front:  the piece's own photo texture
    //  - back:   a flat kraft-paper tone plus a cheap procedural diagonal
    //            hatch (matching PieceBackRenderer's 2D look), computed
    //            straight from UV rather than a second texture upload
    //  - wall:   a single rim color (the piece "material" showing through
    //            its cut edge) -- sampled from the piece's own photo
    //            rather than fixed, see Piece3DRenderer.materialRimColor
    val FRAGMENT = """
        precision mediump float;

        uniform sampler2D uTexture;
        uniform vec3 uLightDir;
        uniform vec3 uViewPos;
        uniform vec3 uBackColor;
        uniform vec3 uBackLineColor;
        uniform vec3 uRimColor;
        uniform float uFlipV;

        varying vec3 vWorldNormal;
        varying vec3 vWorldPos;
        varying vec2 vTexCoord;
        varying float vFaceId;

        void main() {
            vec3 n = normalize(vWorldNormal);
            vec3 l = normalize(uLightDir);
            float diffuse = max(dot(n, l), 0.0);
            vec3 v = normalize(uViewPos - vWorldPos);
            vec3 h = normalize(l + v);
            float specular = pow(max(dot(n, h), 0.0), 28.0);
            float fresnel = pow(1.0 - max(dot(n, v), 0.0), 2.5);

            vec3 baseColor;
            if (vFaceId < 0.5) {
                // uFlipV is 0 (its GL default) for Piece3DRenderer, which has always sampled
                // with the mesh's own V as-is; PuzzleBoard3DRenderer sets it to 1 -- see the
                // note there on why a board-lying piece needs the opposite V.
                vec2 uv = vec2(vTexCoord.x, mix(vTexCoord.y, 1.0 - vTexCoord.y, uFlipV));
                baseColor = texture2D(uTexture, uv).rgb;
            } else if (vFaceId < 1.5) {
                float stripe = fract((vTexCoord.x + vTexCoord.y) * 16.0);
                float line = smoothstep(0.46, 0.5, stripe) - smoothstep(0.5, 0.54, stripe);
                baseColor = mix(uBackColor, uBackLineColor, line * 0.6);
            } else {
                baseColor = uRimColor;
            }

            vec3 ambient = baseColor * 0.38;
            vec3 diffuseTerm = baseColor * diffuse * 0.78;
            vec3 specularTerm = vec3(1.0) * specular * 0.26;
            vec3 rimLight = vec3(1.0) * fresnel * 0.18;
            gl_FragColor = vec4(ambient + diffuseTerm + specularTerm + rimLight, 1.0);
        }
    """.trimIndent()

    // The faint "here's what you're building" picture PuzzleBoard3DRenderer
    // lays flat on the table under the pieces: one unlit, alpha-blended,
    // textured quad, no lighting or per-face colors, so it doesn't need
    // any of the machinery above.
    val REFERENCE_VERTEX = """
        uniform mat4 uMvpMatrix;
        attribute vec3 aPosition;
        attribute vec2 aTexCoord;
        varying vec2 vTexCoord;

        void main() {
            vTexCoord = aTexCoord;
            gl_Position = uMvpMatrix * vec4(aPosition, 1.0);
        }
    """.trimIndent()

    val REFERENCE_FRAGMENT = """
        precision mediump float;

        uniform sampler2D uTexture;
        uniform float uAlpha;
        varying vec2 vTexCoord;

        void main() {
            gl_FragColor = vec4(texture2D(uTexture, vTexCoord).rgb, uAlpha);
        }
    """.trimIndent()
}
