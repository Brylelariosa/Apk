# BUGS_FIXED — Twenty-fifth pass

**Multiplayer still doesn't connect — not fixed this pass either.** A fresh
matched host+child capture shows the exact same unresolved symptom as FIX
18/19: the child's own SIOMLT_SEND is still only ever `0x0000`/`0xFEFE`, and
its own link setup restarts every ~200ms, even though the host's own data is
still demonstrably arriving at the child correctly. New this pass: the user
confirmed the same ROM's multiplayer works outside this app, ruling out "the
ROM's own code is just unusual" for the first time. That points at this
app's own link timing/architecture rather than anything ROM-specific, but
this pass adds a toggleable experiment (FIX 20 in `mgba_jni.c` — see
CHANGELOG.md), not a confirmed fix. Needs a real device test to know whether
it helps.

Not confirmed on a real device this pass — no Android toolchain here, as
every pass before it.

# BUGS_FIXED — Twenty-fourth pass

**Menu Save State/Load State feeling slow (both the dialog appearing and
picking a slot).** Two separate causes, both perf, not correctness bugs:
(1) `showSaveStateSlotDialog()` re-decoded every slot's PNG thumbnail
from disk on every single open, even when nothing had changed — fixed
with an in-memory cache (`slotInfoCache`) keyed by ROM name + slot,
invalidated only when a slot's `exists`/`lastModified()` actually differ
from what's cached. (2) `backupIfExists()` — run right before every save,
by Quick Save and the menu alike — copied an existing slot's full bytes
to its `.bak` sibling right before `nativeSaveState()` overwrote that
same file anyway, up to 2x a save-state's disk I/O per save, all before
the toast could fire. Fixed with `SaveEntry.moveInto()`: a plain
`File.renameTo()` on the common (no Storage folder) path instead of a
byte-for-byte copy, falling back to the old copy behavior otherwise.

Not confirmed on a real device this pass — no Android toolchain here —
but both are straightforward reductions in redundant I/O with a
correctness fallback in each case (cache miss still re-decodes; rename
failure still falls back to copy).

---

# BUGS_FIXED — Twenty-third pass

**Quick Save/Quick Load racing each other when used fast.** Reported from
fast save/load testing: saves landing on an unexpected frame, and taps
that appeared not to save at all. Root cause: `quickSaveState()` and
`quickLoadState()` each spawned an unsynchronized `Thread` per tap, with
no lock or debounce between them. `g_core_mutex` (native side) serializes
the actual file write/read against the running game thread, but not the
*order* in which two Kotlin threads reach it — a fast second tap could
win that race and run before the first tap's operation finished,
producing an out-of-order save/load. Fixed with a shared `AtomicBoolean`
busy-guard: a tap while one is already in flight is now ignored (with its
own toast) instead of racing. Separately confirmed `nativeSaveState()`
uses `O_TRUNC`, so a slot is always fully replaced on save — that part
was never the problem.

Not confirmed on a real device this pass — no Android toolchain here —
but the race itself is unambiguous from the code (two independent
Threads, no synchronization, touching the same file and native calls).

---

# BUGS_FIXED — Twenty-second pass

**Floating "Load ROM" button rendering on top of the ROM browser.**
Reported with a screenshot: the purple "▶ Load ROM" button was visible
hovering over the "Load game" file browser's list, even though it was
added to the layout underneath that browser. Root cause: a stock Material
`Button` carries a small default elevation, and Android draws
higher-elevation children above lower-elevation ones regardless of add
order — so the button drew on top of the opaque overlay meant to cover
it. Fixed by removing the button entirely; `changeRom()` already
auto-opens the ROM browser on launch and on Close, and a tap on the idle
surface now covers the one case the button still served (folder picker
cancelled, or a ROM load failed, with nothing else on screen).

**Save State feeling slow ("doesn't save instantly").** The slot-save
confirmation toast waited on `captureStateThumbnail()` — up to a 500ms
`PixelCopy` wait plus bitmap scale/PNG encode — before showing, even
though the actual state write had already finished and was safe on disk.
Fixed by firing the confirmation immediately after the real save/load
call returns, with thumbnail capture still happening afterward in the
background rather than gating the toast. Quicksave (the one-tap 💾
button) was never affected — it doesn't capture a thumbnail.

Neither fix confirmed on a real device this pass — no Android toolchain
here — but both are backed by specific mechanisms in the code (Android's
own elevation/Z-order rule; the `PixelCopy` call's own literal 500ms
timeout), not guesses.

---

# BUGS_FIXED — Twenty-first pass

**Save/load broken by the Storage folder feature (Twentieth pass), reported
from an actual device.** The Twentieth pass's `/proc/self/fd/<N>` bridge —
used so native `VFileOpen()` could operate on a SAF document as if it were
a plain local path — was flagged in that pass's own KNOWN_LIMITATIONS.md as
unconfirmed on real hardware. This pass confirms it doesn't hold up: a real
device test showed exactly the reported symptom, saves and loads silently
not working once a Storage folder was chosen. Fixed by removing native
code's dependency on SAF entirely — it always operates on a plain internal-
storage file now, with Kotlin copying bytes to/from the chosen folder via
`ContentResolver` streams instead of a re-opened file descriptor. Full
detail in CHANGELOG.md; still not verified against a real device in this
project's own testing (no Android toolchain here either), but the design no
longer depends on the specific provider behavior that broke.

---

# BUGS_FIXED — Nineteenth pass

No bug fixed this pass — Eighteenth pass's SIOCNT-mirroring change was
re-tested against a real matched capture and showed no observed change
(child's `childData` still only ever `0x0000`/`0xFEFE`). Left in place;
not the fix, but still correct on its own terms.

One real fix, unrelated to the link protocol itself: two phones' log
captures in this test covered different real-world spans, which had no
quick explanation before now. Root cause: the host's code logs ~3 lines
per SIO exchange against the child's ~1, so the same 40,000-character
export cap holds less real time on the host side — not a phone problem.
`copyLinkDebugLog()` now appends the exact copy timestamp to the exported
text so this is visible at a glance next time, instead of needing to be
worked out after the fact.

---

# BUGS_FIXED — Eighteenth pass

Real bug fix, not a diagnostic pass — the first one aimed at a gap found
through a real matched two-phone capture instead of a code re-read alone.

- **Fixed: the child device's own SIOCNT never reflected transfer
  completion.** The new matched capture (see CHANGELOG.md/
  KNOWN_LIMITATIONS.md) confirmed both directions of the network exchange
  are correct — real evidence, for the first time, from both phones during
  the same attempt. That narrowed things to the child ROM's own code, and
  reading `nativeLinkChildExchange()` end to end turned up a gap the
  function's own comment already admitted: it wrote the data registers and
  raised the IRQ, but never touched SIOCNT bit 7 (Busy), which GBATEK
  documents as a hardware-mirrored parent-clock reflection on every
  connected unit — a normal thing for a child ROM to poll instead of, or
  alongside, the IRQ. `nativeLinkChildExchange()` now refreshes SIOCNT
  bits 2/3/4-5/7 on the child's device after every exchange, preserving
  every other bit exactly as the ROM last set it.

Not confirmed on a real device — same caveat as every pass before it. See
KNOWN_LIMITATIONS.md for what would actually settle it.

---

# BUGS_FIXED — Seventeenth pass

Not a bug-fix pass, same as Sixteenth — nothing here changes multiplayer
behavior. Included for completeness: one real infrastructure gap closed
(logging that no longer depends on OS logcat access, which W's own device
split this pass confirmed is a real, current blocker, not a hypothetical
one), plus a deeper read of Sixteenth pass's own evidence that ruled out
one leading candidate explanation without confirming any other.

- **Fixed: the debug-log tool depended entirely on OS logcat access,
  which doesn't work on every phone.** Sixteenth pass flagged this
  (screenshotted empty capture on one of W's two phones) but explicitly
  didn't attempt a fix, since one working phone was enough to make
  progress at the time. This pass, W hit the same wall again while trying
  to get a synchronized two-phone capture — which needs *both* phones'
  logs, so "one working phone" isn't enough for that specific, repeatedly-
  requested next step. `copyLinkDebugLog()` now reads a private file this
  app owns outright instead of shelling out to `logcat`; see CHANGELOG.md
  items 1-3 and FILE_CHANGES.md for the mechanics.
- **Checked, not fixed: FIX 9's bit2/bit3 SIOCNT reflection, against the
  specific theory that the child ROM never sees bit3 (all-ready) and that
  being why its own negotiation never progresses.** Re-read this pass
  against the child-side evidence in Sixteenth pass's new logging (see
  KNOWN_LIMITATIONS.md). The code already applies the bit3/bit2 OR
  unconditionally on every SIOCNT write while `g_link_active` is true,
  regardless of host/child role — this was the single most likely
  candidate explanation going in, and reading the code turned up no bug in
  it. Listed here rather than silently dropped, since ruling out a
  plausible cause is itself useful information for whoever continues this.

Neither of these touches the actual reported bug (multiplayer still
doesn't work). See CHANGELOG.md and KNOWN_LIMITATIONS.md for the new
evidence from this pass's logs (strong, still-unconfirmed indication the
child ROM's own negotiation never advances past writing placeholder
values, independent of the network layer, which looks solid) and an
updated theory (timing/synchronization, grounded in how mGBA's own real
multiplayer implementation handles this — not confirmed against this
codebase specifically) for what a real device test should check next.

---

# BUGS_FIXED — Sixteenth pass

Not a bug-fix pass in the usual sense — nothing here changes multiplayer
behavior. Included for completeness: two diagnostic gaps closed after
reading W's first genuinely useful evidence (three real logcat captures,
following Fifteenth pass's logging fix actually working).

- **Fixed: the SIO exchange's own result was never logged, only the write
  that triggers it.** `wifi_host.text` this pass showed 1124 Start-bit
  writes in 1.67 seconds on the host — too fast to be timing out on most
  of them (that would take 30+ seconds at `WIFI_XCHG_MS=30` each) — which
  strongly suggested the network side is basically working, but nothing
  confirmed it or showed what was actually coming back. `link_exchange()`'s
  return value and timeout flag are now logged for every host exchange.
- **Fixed: the entire child-side receive path had no logging.**
  `nativeLinkChildExchange()` — the only function that updates a child
  device's own link registers — logged nothing, in either its early-exit
  or success path, across all sixteen passes so far. `wifi_join.text` and
  `bluetoth__1_.text` both show the child ROM restarting its own link setup
  roughly every 200ms without ever stabilizing, but whether that's because
  this function never ran, ran with unhelpful data, or ran fine and the ROM
  didn't react to it, was unanswerable without this. Now logs every call.

Neither of these touches the actual reported bug. See CHANGELOG.md and
KNOWN_LIMITATIONS.md for what the new evidence actually suggests (a
possible mutual-reset livelock between the two ROMs' own negotiation state
machines — not confirmed) and what the next capture needs to look like to
confirm or rule it out.

---

# BUGS_FIXED — Fifteenth pass

This pass fixed one clearly demonstrated bug (item 1 — the evidence is the
two logcat files W attached), one diagnostic gap that made every disconnect
report hard to read (item 2), and applied one hardening whose actual effect
is genuinely unconfirmed (item 3, included here anyway in the interest of
not burying it — see its own honesty note). **None of the three symptoms
reported this pass — ROM detection on either transport, Wi-Fi disconnect
propagation, Bluetooth lag — are confirmed fixed.** See
KNOWN_LIMITATIONS.md.

- **Fixed: the multiplayer debug-log capture tool was capturing nothing
  useful.** `jni_log()` in `mgba_jni.c` forwarded every mGBA core log line,
  at every level, to logcat under the same tag `copyLinkDebugLog()` greps
  — including `"Starting DMA ..."` and `"Read from write-only I/O
  register: ..."` chatter that fires dozens of times per frame for any
  ROM, unrelated to link. Both logs W attached this pass are direct proof:
  2000 lines each, tag-filtered correctly, but covering barely 200ms of
  real time — pure boot noise, nothing from anywhere near an actual
  multiplayer attempt. Fixed by dropping `mLOG_DEBUG`/`mLOG_STUB`/
  `mLOG_GAME_ERROR` at the source (mirrors mGBA's own libretro frontend
  under `NDEBUG`, which this project also builds with), plus a
  belt-and-suspenders check on the two exact message prefixes observed.
  Also bumped the capture window from 2000 to 8000 lines as extra
  headroom. This doesn't fix any of the three reported symptoms by
  itself — it fixes why nothing gathered about them so far has been
  readable.
- **Fixed: disconnect/peer-lost events were logged with no distinguishing
  detail.** `disconnect()`'s BYE send had a silent `catch (_: Exception)
  {}` — no record of whether it sent, was skipped, or failed. Every one of
  `handlePeerLost()`'s 8 call sites logged the exact same generic line
  regardless of which of 6 listener locations fired or why. A captured log
  could not have told "peer's BYE never arrived" apart from "arrived but
  something else consumed it" apart from "neither side ever sent one, the
  8s watchdog just gave up" — three different bugs, all invisible from the
  old logging. Every disconnect/peer-lost path now logs specifically what
  happened. Purely additive; no protocol or timing logic changed.
- **Hardened, not confirmed as a fix: native SIO exchange trigger was not
  gated to the host role.** `link_sio_write_register()`'s exchange branch
  ran on *any* device's own Start-bit SIOCNT write — FIX 9's original
  comment already claimed a child device's write "correctly never" reaches
  it, but nothing enforced that; it depended entirely on the assumption
  that a child ROM's own code never performs that write. Now explicitly
  gated on `g_link_is_host`. If either test ROM's link code doesn't
  actually respect that split (plausible if parent/child share one code
  path), this would have let a child device fire a second, spurious
  exchange alongside the correct network-triggered one, potentially
  stealing the host's real reply out from under it — a mechanism that
  would explain identical ROM-detection failure on both transports plus
  worse Bluetooth lag specifically (longer timeout there). Genuinely don't
  know if this was happening. Cheap and safe regardless: host behavior is
  completely unchanged.

---

# BUGS_FIXED — Earlier passes (summary)

Full entries trimmed for length. Link/multiplayer-relevant ones are noted;
the rest are unrelated app bugs, fixed and not revisited since.

- **Fourteenth** — Compile error: a `showLinkDebugLogDialog()` parameter
  named `text` shadowed the `TextView.text` property it was meant to set.
  Renamed the parameter; no link logic touched.
- **Twelfth** — Added the (logcat-based, later superseded) "Copy link log"
  diagnostic. Not a fix on its own.
- **Eleventh** — Quick game menu rows were all silently unresponsive
  (`isClickable`/`isFocusable` stealing the tap from the `ListView`'s own
  dispatch) — a regression from the Tenth pass's restyle.
- **Tenth** — Immersive mode not sticking across dialogs; black bar in the
  camera-cutout area on landscape.
- **Ninth** — Wi-Fi host's liveness watchdog could fire on a healthy
  connection, because the host (unlike the child) had no code path that
  kept reading the socket while waiting for the ROM to reach its own link
  screen. Fixed with a dedicated host-side keepalive drain.
- **Eighth** — No fix; added trace logging after a real fix (Seventh)
  produced zero observed change, to stop guessing blind.
- **Seventh** — SIO IRQ was never raised at all, so any interrupt-driven
  ROM (the standard IntrWait pattern) never woke up on a completed
  transfer, even though the byte exchange itself (Sixth) was correct.
- **Sixth** — Root cause of the original "Connected but ROM never
  reacts" report: a child device never answered the host's requests at
  all (Start/Busy is hardware read-only for slaves per GBATEK, so the
  child's own exchange code path never fired) — fixed with the passive
  `nativeLinkChildExchange()` responder. Also: SIOCNT parent/child + all-
  ready bits were never set; ID/Error bits never set after a transfer;
  peer disconnects were never detected; Bluetooth never ran the keepalive
  loop at all.
- **Fifth** — First multiplayer-focused pass. Missing `@Volatile` on six
  connection-state fields; untracked discovery socket made disconnect a
  no-op for it; non-functional stale-packet sequence check; unblocked
  concurrent connection attempts could clobber each other; uncancellable
  in-progress Bluetooth connect; ROM-swap could leave link UI stuck on
  "Connected" after the native driver was already gone; a rare
  post-teardown resource leak in the ROM-load callback; two unused
  permissions removed.
