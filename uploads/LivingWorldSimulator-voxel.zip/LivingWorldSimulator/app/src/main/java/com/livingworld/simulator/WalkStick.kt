package com.livingworld.simulator

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View

/**
 * Virtual joystick for walking. Drag the knob: the offset from the centre becomes (right, forward) in -1..1 and is
 * sent to the engine; letting go stops the walker. It is a separate view so that it can be held with one thumb while
 * the other thumb drags the globe view to look around.
 */
class WalkStick(context: Context) : View(context) {
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val knob = Paint(Paint.ANTI_ALIAS_FLAG)
    private var kx = 0f
    private var ky = 0f

    init {
        ring.style = Paint.Style.STROKE
        ring.strokeWidth = 3f * resources.displayMetrics.density
        ring.color = Color.argb(150, 190, 215, 255)
        fill.style = Paint.Style.FILL
        fill.color = Color.argb(60, 20, 40, 80)
        knob.style = Paint.Style.FILL
        knob.color = Color.argb(200, 215, 230, 255)
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = Math.min(width, height) / 2f - ring.strokeWidth
        canvas.drawCircle(cx, cy, r, fill)
        canvas.drawCircle(cx, cy, r, ring)
        canvas.drawCircle(cx + kx * r, cy + ky * r, r * 0.36f, knob)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val cx = width / 2f
        val cy = height / 2f
        val r = Math.min(width, height) / 2f
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                var dx = (e.x - cx) / r
                var dy = (e.y - cy) / r
                val l = Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
                if (l > 1f) {
                    dx /= l
                    dy /= l
                }
                kx = dx
                ky = dy
                Native.nWalkInput(dx.toDouble(), -dy.toDouble())
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                kx = 0f
                ky = 0f
                Native.nWalkInput(0.0, 0.0)
                invalidate()
            }
        }
        return true
    }
}
