//! First-person walking on the planet surface. The walker follows the simulated terrain (fractal detail included),
//! wades through shallow water, swims in deep water, jumps, and moves at several speed steps so that a whole planet can
//! be crossed. Looking around is handled by the camera; this module owns the position and the vertical motion.

use crate::mathx::*;
use crate::sampler::Sampler;
use crate::world::View;

/// eye height above the feet (m)
pub const EYE_HEIGHT: f64 = 1.7;
/// speed steps in m/s: walk, run, fast, turbo, hyper
pub const SPEEDS: [f64; 5] = [3.0, 9.0, 40.0, 160.0, 800.0];
const GRAVITY: f64 = 9.8;
const JUMP_SPEED: f64 = 4.6;
/// water deeper than this (m) makes the walker swim instead of wade
const SWIM_DEPTH: f64 = 0.9;
/// steepest slope (rise / run) that is climbed on foot at the two slowest speeds
const MAX_CLIMB: f64 = 1.3;
/// finest terrain wavelength (m) sampled for the ground under the feet
const GROUND_LAM: f64 = 5.0;

#[derive(Clone)]
pub struct Walker {
    pub active: bool,
    /// unit vector from the planet centre to the feet
    pub dir: V3,
    /// terrain height under the feet (m above sea level)
    pub ground: f64,
    /// water surface height there (equal to `ground` on dry land)
    pub water: f64,
    /// height of the feet above sea level
    pub feet: f64,
    pub vz: f64,
    pub speed_idx: usize,
    pub swimming: bool,
    /// joystick: x = right, y = forward, both -1..1
    pub stick_x: f64,
    pub stick_y: f64,
    pub jump_req: bool,
    /// eye height above the ground or the water surface (m), at least 0.4
    pub clear: f64,
}

impl Walker {
    pub fn new() -> Walker {
        Walker {
            active: false,
            dir: V3::new(1.0, 0.0, 0.0),
            ground: 0.0,
            water: 0.0,
            feet: 0.0,
            vz: 0.0,
            speed_idx: 0,
            swimming: false,
            stick_x: 0.0,
            stick_y: 0.0,
            jump_req: false,
            clear: EYE_HEIGHT,
        }
    }

    /// start walking at `dir` (unit vector from the planet centre)
    pub fn enter(&mut self, v: &View, dir: V3) {
        let s = Sampler::new(v);
        let (g, w) = s.ground_and_water(dir, GROUND_LAM);
        self.dir = dir;
        self.ground = g;
        self.water = w;
        self.vz = 0.0;
        self.stick_x = 0.0;
        self.stick_y = 0.0;
        self.jump_req = false;
        self.swimming = w - g > SWIM_DEPTH;
        self.feet = self.rest_height();
        self.clear = self.clearance();
        self.active = true;
    }

    pub fn leave(&mut self) {
        self.active = false;
        self.stick_x = 0.0;
        self.stick_y = 0.0;
        self.jump_req = false;
        self.vz = 0.0;
    }

    /// feet height when standing still: on the ground, or hanging in the water so that the head is just above it
    fn rest_height(&self) -> f64 {
        if self.swimming {
            self.water - 1.2
        } else {
            self.ground
        }
    }

    fn clearance(&self) -> f64 {
        let top = if self.water > self.ground { self.water } else { self.ground };
        let c = self.feet + EYE_HEIGHT - top;
        if c < 0.4 {
            0.4
        } else {
            c
        }
    }

    /// eye height above sea level
    pub fn eye_msl(&self) -> f64 {
        self.feet + EYE_HEIGHT
    }

    pub fn speed(&self) -> f64 {
        let i = if self.speed_idx < SPEEDS.len() { self.speed_idx } else { 0 };
        SPEEDS[i]
    }

    /// cycle walk -> run -> fast -> turbo -> hyper -> walk
    pub fn next_speed(&mut self) {
        self.speed_idx = (self.speed_idx + 1) % SPEEDS.len();
    }

    /// advance by `dt` seconds; `heading` is the view direction (radians clockwise from north)
    pub fn update(&mut self, v: &View, dt: f64, heading: f64) {
        let dt = clampv(dt, 0.0, 0.1);
        let s = Sampler::new(v);
        let r = v.s.dv.r;
        // ---- horizontal movement along the surface
        let mut sx = self.stick_x;
        let mut sy = self.stick_y;
        let l = (sx * sx + sy * sy).sqrt();
        if l > 1.0 {
            sx /= l;
            sy /= l;
        }
        if l > 0.03 {
            let mut sp = self.speed();
            if self.swimming {
                sp *= 0.5;
            }
            let step = sp * dt;
            let (e, n) = east_north(self.dir);
            let (sh, ch) = dsincos(heading);
            let fwd = e * sh + n * ch;
            let right = e * ch - n * sh;
            let mv = fwd * (sy * step) + right * (sx * step);
            let nd = normalize(self.dir + mv * (1.0 / (r + self.ground.max(0.0))));
            if nd.x.is_finite() && nd.y.is_finite() && nd.z.is_finite() {
                let (g, w) = s.ground_and_water(nd, GROUND_LAM);
                let run = step * (if l > 1.0 { 1.0 } else { l });
                let climb = if run > 1e-6 { (g - self.ground) / run } else { 0.0 };
                let too_steep = climb > MAX_CLIMB && self.speed_idx < 2 && !self.swimming && (self.feet - self.ground) < 0.5;
                if !too_steep {
                    self.dir = nd;
                    self.ground = g;
                    self.water = w;
                }
            }
        } else {
            // standing still: keep following the terrain (it may have been refined)
            let (g, w) = s.ground_and_water(self.dir, GROUND_LAM);
            self.ground = g;
            self.water = w;
        }
        // ---- vertical motion: stand, jump, fall, swim
        self.swimming = self.water - self.ground > SWIM_DEPTH;
        let target = self.rest_height();
        let grounded = self.feet <= target + 0.08 && self.vz <= 0.0;
        if grounded {
            if self.jump_req && !self.swimming {
                self.vz = JUMP_SPEED;
                self.feet += self.vz * dt;
            } else {
                if self.feet < target {
                    // rising terrain: never let the eye sink into it
                    self.feet = target;
                } else {
                    let k = 1.0 - dexp(-18.0 * dt);
                    self.feet += (target - self.feet) * k;
                }
                self.vz = 0.0;
            }
        } else {
            self.vz -= GRAVITY * dt;
            self.feet += self.vz * dt;
            if self.feet <= target {
                self.feet = target;
                self.vz = 0.0;
            }
        }
        self.jump_req = false;
        self.clear = self.clearance();
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn speed_steps_cycle() {
        let mut w = Walker::new();
        let first = w.speed();
        for _ in 0..SPEEDS.len() {
            w.next_speed();
        }
        assert!((w.speed() - first).abs() < 1e-12);
        w.next_speed();
        assert!(w.speed() > first);
    }

    #[test]
    fn clearance_is_never_tiny() {
        let mut w = Walker::new();
        w.ground = 10.0;
        w.water = 10.0;
        w.feet = 10.0;
        assert!((w.clearance() - EYE_HEIGHT).abs() < 1e-9);
        w.feet = -50.0;
        assert!(w.clearance() >= 0.4);
    }
}
