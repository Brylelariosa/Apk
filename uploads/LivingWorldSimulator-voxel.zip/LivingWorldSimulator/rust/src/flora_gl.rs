//! OpenGL ES side of the plants. Every plant is drawn as a cloud of micro voxels: one GL point per cube, sized on the
//! screen from the cube's real edge length, so a 4 cm grass cube is a pixel-sized dot far away and a big pixel-art block
//! close up. There is no mesh at all, which makes every level of detail cost about the same per cube.
//!
//! One bucket = one kind at one level of detail. It owns a static buffer with the cubes of the model (position, size,
//! colour, normal, sway) and a dynamic buffer with the instances (x, y, z, scale | yaw, tint r, g, b) whose positions are
//! metres relative to the build anchor; the vertex shader puts the anchor into the world with its own east / north / up
//! axes, lights every cube from its stored normal, blends it into the haze and sizes the point.

use crate::flora::KIND_INFO;
use crate::flora_voxel::*;
use crate::gl::*;
use std::ffi::c_void;
use std::time::Instant;

const VOX_VS: &str = r#"#version 300 es
precision highp float;
layout(location = 0) in vec4 aPosSize;
layout(location = 1) in vec4 aCol;
layout(location = 2) in vec4 aNrm;
layout(location = 3) in vec4 iPosScale;
layout(location = 4) in vec4 iYawTint;
uniform mat4 uVP;
uniform vec3 uAnchor;
uniform vec3 uE;
uniform vec3 uN;
uniform vec3 uU;
uniform vec3 uSun;
uniform float uHazeK;
uniform float uHazeAmt;
uniform vec3 uHazeColor;
uniform float uTime;
uniform float uFocal;
uniform vec2 uThin;
out vec3 vColor;
out float vPx;
void main() {
    vec3 basePos = uAnchor + uE * iPosScale.x + uN * iPosScale.y + uU * iPosScale.z;
    float dist0 = length(basePos);
    // far end: every plant has its own random threshold, so forests and meadows thin out instead of popping away
    float rnd = fract(sin(iYawTint.x * 91.3458 + iPosScale.w * 47.853 + iYawTint.y * 13.37) * 43758.5453);
    float keep = 1.0 - smoothstep(uThin.x, uThin.y, dist0);
    if (rnd >= keep) {
        gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
        gl_PointSize = 1.0;
        vColor = vec3(0.0);
        vPx = 0.0;
        return;
    }
    float cy = cos(iYawTint.x);
    float sy = sin(iYawTint.x);
    vec3 lp = aPosSize.xyz * iPosScale.w;
    vec3 rp = vec3(cy * lp.x - sy * lp.y, sy * lp.x + cy * lp.y, lp.z);
    float ph = iYawTint.x * 3.1 + iPosScale.w * 11.0;
    float gust = sin(uTime * 1.6 + ph) + 0.6 * sin(uTime * 2.7 + ph * 1.9);
    rp.x += aNrm.w * gust * 0.07 * iPosScale.w;
    rp.y += aNrm.w * gust * 0.045 * iPosScale.w;
    vec3 wp = basePos + uE * rp.x + uN * rp.y + uU * rp.z;
    float dist = length(wp);
    // nudge the cube towards the eye so cubes on the ground are not swallowed by a coarser ground mesh further out
    wp -= wp * ((0.05 + 0.004 * dist) / max(dist, 0.001));
    vec4 clip = uVP * vec4(wp, 1.0);
    gl_Position = clip;
    float w = max(clip.w, 0.05);
    float px = aPosSize.w * iPosScale.w * uFocal / w;
    float ps = clamp(px * 1.08 + 0.35, 1.5, 96.0);
    gl_PointSize = ps;
    vPx = ps;

    vec3 nl = aNrm.xyz;
    vec3 nr = vec3(cy * nl.x - sy * nl.y, sy * nl.x + cy * nl.y, nl.z);
    vec3 n = normalize(uE * nr.x + uN * nr.y + uU * nr.z);
    vec3 U = normalize(uU);
    vec3 L = normalize(uSun);
    float day = smoothstep(-0.07, 0.10, dot(U, L));
    float diff = max(dot(n, L), 0.0);
    float back = max(dot(-n, L), 0.0) * 0.25;
    vec3 base = aCol.rgb * mix(vec3(1.0), iYawTint.yzw, aCol.a);
    vec3 alb = base * base;
    vec3 ambient = vec3(0.020, 0.028, 0.050) + vec3(0.075, 0.095, 0.135) * day;
    vec3 col = alb * (ambient + vec3(1.10, 1.04, 0.96) * (diff + back) * day);
    float haze = (1.0 - exp(-dist * uHazeK)) * uHazeAmt;
    float hf = mix(0.25, 0.04, clamp(uHazeK * 20000.0, 0.0, 1.0));
    col = mix(col, uHazeColor * (hf + (1.0 - hf) * day), clamp(haze, 0.0, 0.92));
    col = col / (1.0 + 0.18 * col);
    vColor = sqrt(max(col, 0.0));
}
"#;

const VOX_FS: &str = r#"#version 300 es
precision mediump float;
in vec3 vColor;
in float vPx;
out vec4 fragColor;
void main() {
    vec3 c = vColor;
    if (vPx >= 5.0) {
        // pixel-art block: light top and left edge, dark bottom and right edge, a soft light-to-dark gradient
        vec2 pc = gl_PointCoord;
        float e = 1.6 / vPx;
        float hi = max(step(pc.y, e), step(pc.x, e));
        float lo = max(step(1.0 - e, pc.y), step(1.0 - e, pc.x));
        c *= 1.0 + 0.14 * hi - 0.22 * lo + 0.10 * (0.5 - pc.y);
    }
    fragColor = vec4(c, 1.0);
}
"#;

/// per-frame values for drawing (all vectors in world axes, positions relative to the camera)
pub struct FloraDraw {
    pub vp: [f32; 16],
    pub anchor_rel: [f32; 3],
    pub e: [f32; 3],
    pub n: [f32; 3],
    pub u: [f32; 3],
    pub sun: [f32; 3],
    pub haze_k: f32,
    pub haze_amt: f32,
    pub haze_color: [f32; 3],
    /// scales every view distance (0 hides everything, 1 = full range)
    pub fade: f32,
    /// scales every view distance and level-of-detail distance; must match what the placement code was built with
    pub detail: f32,
    /// camera focal length in pixels (viewport height / (2 tan(fov / 2)))
    pub focal: f32,
}

pub struct FloraGl {
    prog: u32,
    u: [i32; 12],
    vao: [u32; NBUCKET],
    vbo: [u32; NBUCKET],
    inst: [u32; NBUCKET],
    nvox: [i32; NBUCKET],
    count: [i32; NBUCKET],
    start: Instant,
    pub ready: bool,
    pub error: String,
}

impl FloraGl {
    pub fn new() -> FloraGl {
        FloraGl {
            prog: 0,
            u: [-1; 12],
            vao: [0; NBUCKET],
            vbo: [0; NBUCKET],
            inst: [0; NBUCKET],
            nvox: [0; NBUCKET],
            count: [0; NBUCKET],
            start: Instant::now(),
            ready: false,
            error: String::new(),
        }
    }

    /// compile the shader and upload the voxel models (call with a current GL context)
    pub fn init(&mut self) {
        self.ready = false;
        self.error.clear();
        self.prog = 0;
        for b in 0..NBUCKET {
            self.vao[b] = 0;
            self.vbo[b] = 0;
            self.inst[b] = 0;
            self.nvox[b] = 0;
            self.count[b] = 0;
        }
        let models = match VoxModels::load() {
            Ok(m) => m,
            Err(e) => {
                self.error = format!("plants {}", e);
                log(&self.error);
                return;
            }
        };
        match compile_program(VOX_VS, VOX_FS) {
            Ok(p) => self.prog = p,
            Err(e) => {
                self.error = format!("plants shader {}", e);
                log(&self.error);
                return;
            }
        }
        let names = ["uVP", "uAnchor", "uE", "uN", "uU", "uSun", "uHazeK", "uHazeAmt", "uHazeColor", "uTime", "uFocal", "uThin"];
        for i in 0..names.len() {
            self.u[i] = uniform_loc(self.prog, names[i]);
        }
        for b in 0..NBUCKET {
            let m = &models.lods[b];
            let mut vao = 0u32;
            let mut vbo = 0u32;
            let mut inst = 0u32;
            unsafe {
                glGenVertexArrays(1, &mut vao);
                glBindVertexArray(vao);
                // the cubes of the model: 12 floats each
                glGenBuffers(1, &mut vbo);
                glBindBuffer(GL_ARRAY_BUFFER, vbo);
                glBufferData(GL_ARRAY_BUFFER, (m.data.len() * 4) as isize, m.data.as_ptr() as *const c_void, GL_STATIC_DRAW);
                glEnableVertexAttribArray(0);
                glVertexAttribPointer(0, 4, GL_FLOAT, 0, 48, std::ptr::null());
                glEnableVertexAttribArray(1);
                glVertexAttribPointer(1, 4, GL_FLOAT, 0, 48, 16usize as *const c_void);
                glEnableVertexAttribArray(2);
                glVertexAttribPointer(2, 4, GL_FLOAT, 0, 48, 32usize as *const c_void);
                // the instances: 8 floats each, advanced once per instance
                glGenBuffers(1, &mut inst);
                glBindBuffer(GL_ARRAY_BUFFER, inst);
                glBufferData(GL_ARRAY_BUFFER, 32, std::ptr::null(), GL_DYNAMIC_DRAW);
                glEnableVertexAttribArray(3);
                glVertexAttribPointer(3, 4, GL_FLOAT, 0, 32, std::ptr::null());
                glVertexAttribDivisor(3, 1);
                glEnableVertexAttribArray(4);
                glVertexAttribPointer(4, 4, GL_FLOAT, 0, 32, 16usize as *const c_void);
                glVertexAttribDivisor(4, 1);
                glBindVertexArray(0);
                glBindBuffer(GL_ARRAY_BUFFER, 0);
            }
            self.vao[b] = vao;
            self.vbo[b] = vbo;
            self.inst[b] = inst;
            self.nvox[b] = m.count() as i32;
        }
        self.ready = true;
    }

    /// the GL context is gone: forget every object name
    pub fn lose(&mut self) {
        self.prog = 0;
        for b in 0..NBUCKET {
            self.vao[b] = 0;
            self.vbo[b] = 0;
            self.inst[b] = 0;
            self.nvox[b] = 0;
            self.count[b] = 0;
        }
        self.ready = false;
    }

    /// replace the instances of one kind at one level of detail (8 floats each: x y z scale yaw r g b)
    pub fn upload_bucket(&mut self, kind: usize, level: usize, data: &[f32]) {
        let b = kind * NLOD + level;
        if !self.ready || kind >= K_COUNT || level >= NLOD {
            return;
        }
        let n = data.len() / 8;
        self.count[b] = n as i32;
        if n == 0 {
            return;
        }
        unsafe {
            glBindBuffer(GL_ARRAY_BUFFER, self.inst[b]);
            glBufferData(GL_ARRAY_BUFFER, (n * 32) as isize, data.as_ptr() as *const c_void, GL_DYNAMIC_DRAW);
            glBindBuffer(GL_ARRAY_BUFFER, 0);
        }
    }

    pub fn draw(&self, d: &FloraDraw) {
        if !self.ready || self.prog == 0 {
            return;
        }
        let u = self.u;
        let t = (self.start.elapsed().as_secs_f64() % 3600.0) as f32;
        unsafe {
            glUseProgram(self.prog);
            glUniformMatrix4fv(u[0], 1, 0, d.vp.as_ptr());
            glUniform3f(u[1], d.anchor_rel[0], d.anchor_rel[1], d.anchor_rel[2]);
            glUniform3f(u[2], d.e[0], d.e[1], d.e[2]);
            glUniform3f(u[3], d.n[0], d.n[1], d.n[2]);
            glUniform3f(u[4], d.u[0], d.u[1], d.u[2]);
            glUniform3f(u[5], d.sun[0], d.sun[1], d.sun[2]);
            glUniform1f(u[6], d.haze_k);
            glUniform1f(u[7], d.haze_amt);
            glUniform3f(u[8], d.haze_color[0], d.haze_color[1], d.haze_color[2]);
            glUniform1f(u[9], t);
            glUniform1f(u[10], d.focal);
            for k in 0..K_COUNT {
                let far = (KIND_INFO[k].far as f32) * d.detail * d.fade;
                if far < 2.0 {
                    continue;
                }
                glUniform2f(u[11], far * 0.8, far);
                for l in 0..NLOD {
                    let b = k * NLOD + l;
                    if self.count[b] <= 0 || self.nvox[b] <= 0 {
                        continue;
                    }
                    glBindVertexArray(self.vao[b]);
                    glDrawArraysInstanced(GL_POINTS, 0, self.nvox[b], self.count[b]);
                }
            }
            glBindVertexArray(0);
        }
    }
}
