//! Ground-level sky: a full-screen pass drawn behind the planet when the camera is close to the surface. It has a
//! zenith-to-horizon gradient whose horizon colour equals the haze colour of the terrain (so distant land melts into
//! it), a sun with twilight glow, and a drifting cloud deck whose coverage follows the simulated weather.

use crate::gl::*;
use std::ffi::c_void;

const SKY_VS: &str = r#"#version 300 es
precision highp float;
layout(location = 0) in vec2 aPos;
out vec2 vNdc;
void main() {
    vNdc = aPos;
    gl_Position = vec4(aPos, 1.0, 1.0);
}
"#;

const SKY_FS: &str = r#"#version 300 es
precision highp float;
in vec2 vNdc;
uniform vec3 uRight;
uniform vec3 uUpV;
uniform vec3 uFwd;
uniform vec2 uTan;
uniform vec3 uSky;
uniform vec3 uEast;
uniform vec3 uNorth;
uniform vec3 uSun;
uniform vec3 uHaze;
uniform float uHazeFloor;
uniform float uAmt;
uniform float uCover;
uniform float uTime;
out vec4 fragColor;

float hash(vec2 p) {
    return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);
}

float vnoise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = hash(i);
    float b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0));
    float d = hash(i + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float fbm(vec2 p) {
    float s = 0.0;
    float a = 0.5;
    for (int i = 0; i < 4; i++) {
        s += a * vnoise(p);
        p = p * 2.03 + vec2(17.3, 9.1);
        a *= 0.5;
    }
    return s;
}

void main() {
    vec3 dir = normalize(uFwd + uRight * (vNdc.x * uTan.x) + uUpV * (vNdc.y * uTan.y));
    vec3 L = normalize(uSun);
    float el = dot(dir, uSky);
    float sunEl = dot(L, uSky);
    float day = smoothstep(-0.12, 0.25, sunEl);
    float twi = smoothstep(-0.22, 0.0, sunEl) * (1.0 - smoothstep(0.0, 0.35, sunEl));
    vec3 zen = mix(vec3(0.010, 0.014, 0.040), vec3(0.14, 0.34, 0.78), day);
    vec3 hor = uHaze * (uHazeFloor + (1.0 - uHazeFloor) * day);
    float t = pow(clamp(1.0 - max(el, 0.0), 0.0, 1.0), 3.2);
    vec3 col = mix(zen, hor, t);
    float sd = max(dot(dir, L), 0.0);
    col += vec3(1.0, 0.55, 0.25) * twi * (pow(sd, 6.0) * 0.55 * t + t * 0.18);
    col += vec3(1.0, 0.85, 0.60) * pow(sd, 24.0) * 0.16 * day;
    col += vec3(1.0, 0.95, 0.85) * smoothstep(0.9996, 0.99985, sd) * 2.5 * day;
    // drifting cloud deck
    if (el > 0.02) {
        vec2 q = vec2(dot(dir, uEast), dot(dir, uNorth)) / (el + 0.10);
        q = q * 1.6 + vec2(uTime * 0.012, uTime * 0.005);
        float n = fbm(q);
        float cov = clamp(uCover, 0.0, 1.0);
        float c = smoothstep(0.64 - 0.55 * cov, 0.86 - 0.45 * cov, n);
        vec3 cc = mix(vec3(0.46, 0.50, 0.58), vec3(1.0, 0.98, 0.95), day);
        cc *= 1.0 - 0.30 * c * cov;
        cc = mix(cc, vec3(1.0, 0.62, 0.42), twi * 0.55);
        cc = mix(cc, col, 0.12);
        col = mix(col, cc, c * smoothstep(0.02, 0.22, el) * 0.92);
    }
    // below the horizon the sky continues as haze so that the edge of the land blends in
    col = mix(col, hor, 1.0 - smoothstep(-0.08, 0.0, el));
    col = col / (1.0 + 0.18 * col);
    fragColor = vec4(sqrt(max(col, 0.0)), uAmt);
}
"#;

/// camera and atmosphere values for one sky draw (all vectors in world axes)
pub struct SkyParams {
    pub right: [f32; 3],
    pub up: [f32; 3],
    pub fwd: [f32; 3],
    pub tan_x: f32,
    pub tan_y: f32,
    pub zenith: [f32; 3],
    pub east: [f32; 3],
    pub north: [f32; 3],
    pub sun: [f32; 3],
    pub haze: [f32; 3],
    pub haze_floor: f32,
    pub amount: f32,
    pub cover: f32,
    pub time: f32,
}

pub struct SkyGl {
    prog: u32,
    vbo: u32,
    u: [i32; 13],
    pub ready: bool,
    pub error: String,
}

impl SkyGl {
    pub fn new() -> SkyGl {
        SkyGl { prog: 0, vbo: 0, u: [-1; 13], ready: false, error: String::new() }
    }

    /// compile the shader and create the triangle that covers the screen (call with a current GL context)
    pub fn init(&mut self) {
        self.ready = false;
        self.error.clear();
        self.prog = 0;
        self.vbo = 0;
        match compile_program(SKY_VS, SKY_FS) {
            Ok(p) => self.prog = p,
            Err(e) => {
                self.error = format!("sky shader {}", e);
                log(&self.error);
                return;
            }
        }
        let names = ["uRight", "uUpV", "uFwd", "uTan", "uSky", "uEast", "uNorth", "uSun", "uHaze", "uHazeFloor", "uAmt", "uCover", "uTime"];
        for i in 0..names.len() {
            self.u[i] = uniform_loc(self.prog, names[i]);
        }
        let tri: [f32; 6] = [-1.0, -1.0, 3.0, -1.0, -1.0, 3.0];
        unsafe {
            let mut id = 0u32;
            glGenBuffers(1, &mut id);
            self.vbo = id;
            glBindBuffer(GL_ARRAY_BUFFER, id);
            glBufferData(GL_ARRAY_BUFFER, 24, tri.as_ptr() as *const c_void, GL_STATIC_DRAW);
            glBindBuffer(GL_ARRAY_BUFFER, 0);
        }
        self.ready = true;
    }

    /// the GL context is gone: forget the object names (they are invalid now)
    pub fn lose(&mut self) {
        self.prog = 0;
        self.vbo = 0;
        self.ready = false;
    }

    pub fn draw(&self, p: &SkyParams) {
        if !self.ready || self.prog == 0 {
            return;
        }
        let u = self.u;
        unsafe {
            glDisable(GL_DEPTH_TEST);
            glEnable(GL_BLEND);
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
            glUseProgram(self.prog);
            glUniform3f(u[0], p.right[0], p.right[1], p.right[2]);
            glUniform3f(u[1], p.up[0], p.up[1], p.up[2]);
            glUniform3f(u[2], p.fwd[0], p.fwd[1], p.fwd[2]);
            glUniform2f(u[3], p.tan_x, p.tan_y);
            glUniform3f(u[4], p.zenith[0], p.zenith[1], p.zenith[2]);
            glUniform3f(u[5], p.east[0], p.east[1], p.east[2]);
            glUniform3f(u[6], p.north[0], p.north[1], p.north[2]);
            glUniform3f(u[7], p.sun[0], p.sun[1], p.sun[2]);
            glUniform3f(u[8], p.haze[0], p.haze[1], p.haze[2]);
            glUniform1f(u[9], p.haze_floor);
            glUniform1f(u[10], p.amount);
            glUniform1f(u[11], p.cover);
            glUniform1f(u[12], p.time);
            glBindBuffer(GL_ARRAY_BUFFER, self.vbo);
            glEnableVertexAttribArray(0);
            glVertexAttribPointer(0, 2, GL_FLOAT, 0, 8, std::ptr::null());
            glDrawArrays(GL_TRIANGLES, 0, 3);
            glDisableVertexAttribArray(0);
            glBindBuffer(GL_ARRAY_BUFFER, 0);
            glDisable(GL_BLEND);
            glEnable(GL_DEPTH_TEST);
        }
    }
}
