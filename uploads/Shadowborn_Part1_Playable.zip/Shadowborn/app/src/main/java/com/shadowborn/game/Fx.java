package com.shadowborn.game;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import java.util.Random;

/** Particles, rings, floating text, the sword trail and screen-level effects (shake, hit-stop, flash). */
final class Fx {
    private static final int MAXP = 220, MAXR = 14, MAXT = 10, MAXTR = 28;
    private static final float TRAIL_LIFE = 0.2f, TEXT_LIFE = 0.8f, RING_LIFE = 0.35f;

    final Random rnd = new Random();
    float freeze, shake, slowT, flashA;
    int flashC = 0xFFFFFFFF;

    private final float[] px = new float[MAXP], py = new float[MAXP], pvx = new float[MAXP], pvy = new float[MAXP];
    private final float[] pl = new float[MAXP], pm = new float[MAXP], ps = new float[MAXP], pg = new float[MAXP];
    private final int[] pc = new int[MAXP];
    private int pcur;

    private final float[] rx = new float[MAXR], ry = new float[MAXR], rm = new float[MAXR], rl = new float[MAXR];
    private final int[] rc = new int[MAXR];
    private int rcur;

    private final float[] tx = new float[MAXT], ty = new float[MAXT], tl = new float[MAXT];
    private final String[] ts = new String[MAXT];
    private final int[] tc = new int[MAXT];
    private int tcur;

    private final float[] trBx = new float[MAXTR], trBy = new float[MAXTR], trTx = new float[MAXTR], trTy = new float[MAXTR];
    private final float[] trl = new float[MAXTR];
    private final boolean[] trFirst = new boolean[MAXTR];
    private int trCur;

    void emit(float x, float y, float vx, float vy, float life, float size, int col, float grav) {
        int i = pcur;
        pcur = (pcur + 1) % MAXP;
        px[i] = x; py[i] = y; pvx[i] = vx; pvy[i] = vy;
        pl[i] = life; pm[i] = life; ps[i] = size; pc[i] = col; pg[i] = grav;
    }

    void burst(float x, float y, int n, int col, float speed, float life, float size) {
        for (int i = 0; i < n; i++) {
            float a = rnd.nextFloat() * 6.2832f, s = speed * (0.3f + 0.7f * rnd.nextFloat());
            emit(x, y, (float) Math.cos(a) * s, (float) Math.sin(a) * s, life * (0.6f + 0.4f * rnd.nextFloat()), size, col, 0f);
        }
    }

    /** Directional sparks; dirX is -1 or +1. */
    void sparks(float x, float y, float dirX, int col) {
        for (int i = 0; i < 9; i++) {
            float a = (rnd.nextFloat() - 0.5f) * 2.2f, s = 120f + rnd.nextFloat() * 220f;
            emit(x, y, (float) Math.cos(a) * s * dirX, (float) Math.sin(a) * s - 40f, 0.25f + rnd.nextFloat() * 0.25f, 1.6f + rnd.nextFloat(), col, 500f);
        }
    }

    void dust(float x, float y) {
        for (int i = 0; i < 6; i++) {
            emit(x + (rnd.nextFloat() - 0.5f) * 10f, y - 1f, (rnd.nextFloat() - 0.5f) * 70f, -rnd.nextFloat() * 30f, 0.35f, 2.4f, 0xFFB8B0C8, 0f);
        }
    }

    void ring(float x, float y, float maxR, int col) {
        int i = rcur;
        rcur = (rcur + 1) % MAXR;
        rx[i] = x; ry[i] = y; rm[i] = maxR; rl[i] = RING_LIFE; rc[i] = col;
    }

    void text(float x, float y, String s, int col) {
        int i = tcur;
        tcur = (tcur + 1) % MAXT;
        tx[i] = x; ty[i] = y; ts[i] = s; tc[i] = col; tl[i] = TEXT_LIFE;
    }

    /** Adds one sword-trail sample; first = true starts a new strip. */
    void trail(float bx, float by, float tipX, float tipY, boolean first) {
        int i = trCur;
        trCur = (trCur + 1) % MAXTR;
        trBx[i] = bx; trBy[i] = by; trTx[i] = tipX; trTy[i] = tipY; trl[i] = TRAIL_LIFE; trFirst[i] = first;
    }

    void shake(float m) {
        if (m > shake) shake = m;
    }

    void update(float dt) {
        for (int i = 0; i < MAXP; i++) {
            if (pl[i] <= 0f) continue;
            pl[i] -= dt;
            pvy[i] += pg[i] * dt;
            px[i] += pvx[i] * dt;
            py[i] += pvy[i] * dt;
        }
        for (int i = 0; i < MAXR; i++) if (rl[i] > 0f) rl[i] -= dt;
        for (int i = 0; i < MAXT; i++) if (tl[i] > 0f) tl[i] -= dt;
        for (int i = 0; i < MAXTR; i++) if (trl[i] > 0f) trl[i] -= dt;
        shake *= Math.max(0f, 1f - 10f * dt);
        if (shake < 0.05f) shake = 0f;
        if (slowT > 0f) slowT -= dt;
        if (flashA > 0f) flashA = Math.max(0f, flashA - dt * 2.5f);
    }

    /** World-space effects: trail, particles, rings and floating numbers. */
    void draw(Canvas c) {
        Paint p = Art.P;
        Path pa = Art.PA;
        p.setStyle(Paint.Style.FILL);
        for (int k = 1; k < MAXTR; k++) {
            int i = (trCur + k - 1) % MAXTR, j = (trCur + k) % MAXTR;
            if (trl[i] <= 0f || trl[j] <= 0f || trFirst[j]) continue;
            pa.reset();
            pa.moveTo(trBx[i], trBy[i]);
            pa.lineTo(trTx[i], trTy[i]);
            pa.lineTo(trTx[j], trTy[j]);
            pa.lineTo(trBx[j], trBy[j]);
            pa.close();
            p.setColor(0xFF58E0FF);
            p.setAlpha((int) (110f * trl[j] / TRAIL_LIFE));
            c.drawPath(pa, p);
        }
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2.2f);
        p.setStrokeCap(Paint.Cap.ROUND);
        for (int k = 1; k < MAXTR; k++) {
            int i = (trCur + k - 1) % MAXTR, j = (trCur + k) % MAXTR;
            if (trl[i] <= 0f || trl[j] <= 0f || trFirst[j]) continue;
            p.setColor(0xFFFFFFFF);
            p.setAlpha((int) (235f * trl[j] / TRAIL_LIFE));
            c.drawLine(trTx[i], trTy[i], trTx[j], trTy[j], p);
        }
        p.setStyle(Paint.Style.FILL);
        for (int i = 0; i < MAXP; i++) {
            if (pl[i] <= 0f) continue;
            float k = pl[i] / pm[i];
            p.setColor(pc[i]);
            p.setAlpha((int) (255f * k));
            c.drawCircle(px[i], py[i], ps[i] * (0.4f + 0.6f * k), p);
        }
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2f);
        for (int i = 0; i < MAXR; i++) {
            if (rl[i] <= 0f) continue;
            float k = rl[i] / RING_LIFE;
            p.setColor(rc[i]);
            p.setAlpha((int) (230f * k));
            c.drawCircle(rx[i], ry[i], rm[i] * (1f - k * k) + 2f, p);
        }
        p.setStyle(Paint.Style.FILL);
        p.setTypeface(Art.FONT);
        p.setTextSize(11f);
        p.setTextAlign(Paint.Align.CENTER);
        for (int i = 0; i < MAXT; i++) {
            if (tl[i] <= 0f) continue;
            float k = tl[i] / TEXT_LIFE;
            p.setColor(tc[i]);
            p.setAlpha((int) (255f * Math.min(1f, k * 2f)));
            c.drawText(ts[i], tx[i], ty[i] - (1f - k) * 24f, p);
        }
    }

    /** Screen-space drifting embers. */
    void ambient(Canvas c, float vw, float vh, float time, int col) {
        Paint p = Art.P;
        p.setStyle(Paint.Style.FILL);
        p.setColor(col);
        for (int i = 0; i < 18; i++) {
            float k = i * 0.6180339f;
            float x = ((k * 977f + time * (8f + (i % 5) * 4f)) % (vw + 40f)) - 20f + (float) Math.sin(time * 1.3f + i) * 8f;
            float y = vh - ((k * 531f + time * (14f + (i % 4) * 6f)) % (vh + 20f)) + 10f;
            p.setAlpha((int) (90f + 60f * Math.sin(time * 3f + i * 2f)));
            c.drawCircle(x, y, 1.1f + (i % 3) * 0.5f, p);
        }
    }
}
