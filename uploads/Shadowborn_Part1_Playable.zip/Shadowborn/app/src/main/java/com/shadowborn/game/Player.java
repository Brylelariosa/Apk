package com.shadowborn.game;

import android.graphics.Canvas;
import android.graphics.Paint;

/** The black stickman hero: running, variable jump, double jump, 3-stage sword combo and dodge. */
final class Player extends Body {
    private static final float RUN = 190f, JUMP_V = 520f, DJ_V = 500f;
    private static final float[] DUR = {0f, 0.30f, 0.32f, 0.50f};
    private static final int[] DMG = {0, 10, 12, 22};
    private static final float[] RANGE = {0f, 54f, 56f, 68f};
    private static final float[] LUNGE = {0f, 140f, 170f, 260f};

    int hp = 100, maxHp = 100, facing = 1, atk, swing;
    boolean dead, hasDJ, edge;
    float invuln, hurtT, dodgeT, dodgeCd, atkT, atkDur, lastSafeX, lastSafeY;
    final Art.Fig fig = new Art.Fig();

    private float coyote, jumpBuf, atkBuf, dodgeBuf, landT, phase, t, ghostT;
    private int extraJumps, gi;
    private boolean jumping, trailStart;
    private final float[] gx = new float[4], gy = new float[4], ga = new float[4];
    private final int[] gd = new int[4];

    Player() {
        w = 14f;
        h = 34f;
    }

    /** Puts the hero at a position without touching health. */
    void place(float px, float py) {
        x = px;
        y = py;
        vx = 0f;
        vy = 0f;
        lastSafeX = px;
        lastSafeY = py;
        atk = 0;
        dodgeT = 0f;
        hurtT = 0f;
        onGround = false;
        for (int i = 0; i < 4; i++) ga[i] = 0f;
    }

    void revive() {
        dead = false;
        hp = maxHp;
        invuln = 1.2f;
    }

    void update(Game g, Input in, float dt) {
        t += dt;
        if (invuln > 0f) invuln -= dt;
        if (hurtT > 0f) hurtT -= dt;
        if (dodgeCd > 0f) dodgeCd -= dt;
        if (coyote > 0f) coyote -= dt;
        if (jumpBuf > 0f) jumpBuf -= dt;
        if (atkBuf > 0f) atkBuf -= dt;
        if (dodgeBuf > 0f) dodgeBuf -= dt;
        if (landT > 0f) landT -= dt;
        for (int i = 0; i < 4; i++) if (ga[i] > 0f) ga[i] -= dt * 2.4f;
        if (in.takeJump()) jumpBuf = 0.12f;
        if (in.takeAttack()) atkBuf = 0.22f;
        if (in.takeDodge()) dodgeBuf = 0.15f;

        float dir = (in.right ? 1f : 0f) - (in.left ? 1f : 0f);
        boolean stunned = hurtT > 0f;
        boolean dodging = dodgeT > 0f;

        if (!stunned && !dodging && dodgeBuf > 0f && dodgeCd <= 0f) {
            dodgeT = 0.24f;
            dodgeCd = 0.7f;
            dodgeBuf = 0f;
            if (dir != 0f) facing = dir > 0f ? 1 : -1;
            invuln = Math.max(invuln, 0.3f);
            atk = 0;
            vy = 0f;
            ghostT = 0f;
            dodging = true;
            g.fx.burst(cx(), y + h - 3f, 7, 0xFF58E0FF, 90f, 0.3f, 2.4f);
        }

        if (dodging) {
            dodgeT -= dt;
            vx = facing * 430f;
            vy = 0f;
            ghostT -= dt;
            if (ghostT <= 0f) {
                ghostT = 0.045f;
                gx[gi] = cx();
                gy[gi] = y + h;
                gd[gi] = facing;
                ga[gi] = 0.55f;
                gi = (gi + 1) & 3;
            }
            if (dodgeT <= 0f) vx = facing * 120f;
        } else {
            if (!stunned && atkBuf > 0f) {
                if (atk == 0) startAttack(1, dir);
                else if (atk < 3 && atkT >= atkDur * 0.5f) startAttack(atk + 1, dir);
            }
            if (atk > 0) {
                atkT += dt;
                if (atkT >= atkDur) atk = 0;
            }
            if (stunned) {
                vx = approach(vx, 0f, 700f * dt);
            } else if (atk > 0) {
                vx = approach(vx, 0f, 600f * dt);
            } else {
                vx = approach(vx, dir * RUN, (onGround ? 2600f : 1700f) * dt);
                if (dir != 0f) facing = dir > 0f ? 1 : -1;
            }
            if (!stunned && jumpBuf > 0f) {
                if (onGround || coyote > 0f) {
                    vy = -JUMP_V;
                    jumping = true;
                    jumpBuf = 0f;
                    coyote = 0f;
                    onGround = false;
                    g.fx.dust(cx(), y + h);
                    if (atk > 0 && atkT > atkDur * 0.45f) atk = 0;
                } else if (hasDJ && extraJumps > 0) {
                    vy = -DJ_V;
                    extraJumps--;
                    jumpBuf = 0f;
                    jumping = true;
                    g.fx.ring(cx(), y + h, 34f, 0xFF58E0FF);
                    g.fx.burst(cx(), y + h, 9, 0xFF9AF0FF, 100f, 0.35f, 2f);
                }
            }
            if (jumping && !in.jump && vy < -170f) {
                vy *= 0.5f;
                jumping = false;
            }
            if (vy >= 0f) jumping = false;
        }

        gravity = dodging ? 0f : 1500f;
        boolean was = onGround;
        float vyBefore = vy;
        physics(g.world, dt);
        if (onGround) {
            coyote = 0.1f;
            extraJumps = hasDJ ? 1 : 0;
            if (!was && vyBefore > 260f) {
                g.fx.dust(cx(), y + h);
                landT = 0.14f;
            }
            if (!dodging && g.world.safeSpot(this)) {
                lastSafeX = x;
                lastSafeY = y;
            }
        }
        phase += Math.abs(vx) * dt * 0.075f;
        pose();
        Art.solve(fig);
        if (atk > 0) {
            float pr = atkT / atkDur;
            if (pr >= 0.2f && pr <= 0.72f) {
                float[] j = fig.j;
                g.fx.trail(j[20] + (j[22] - j[20]) * 0.3f, j[21] + (j[23] - j[21]) * 0.3f, j[22], j[23], trailStart);
                trailStart = false;
            }
            if (pr >= 0.26f && pr <= 0.62f) hitCheck(g);
        }
    }

    private void startAttack(int stage, float dir) {
        atk = stage;
        atkT = 0f;
        atkDur = DUR[stage];
        swing++;
        atkBuf = 0f;
        trailStart = true;
        if (dir != 0f) facing = dir > 0f ? 1 : -1;
        vx = facing * LUNGE[stage];
    }

    private void hitCheck(Game g) {
        float range = RANGE[atk] + (edge ? 10f : 0f);
        float hx = facing > 0 ? cx() - 4f : cx() + 4f - range;
        float hy, hh;
        if (atk == 1) { hy = y + 2f; hh = h - 4f; }
        else if (atk == 2) { hy = y - 8f; hh = h + 8f; }
        else { hy = y - 14f; hh = h + 20f; }
        int dmg = Math.round(DMG[atk] * (edge ? 1.5f : 1f));
        float kb = atk == 3 ? 300f : 190f;
        boolean hitAny = false;
        for (int i = 0; i < g.enemies.size(); i++) {
            Enemy e = g.enemies.get(i);
            if (e.dead || e.lastSwing == swing) continue;
            if (overlap(hx, hy, range, hh, e.x, e.y, e.w, e.h)) {
                e.lastSwing = swing;
                e.hurt(g, dmg, cx(), kb);
                hitAny = true;
            }
        }
        Boss b = g.boss;
        if (b != null && b.vulnerable() && b.lastSwing != swing && overlap(hx, hy, range, hh, b.x, b.y, b.w, b.h)) {
            b.lastSwing = swing;
            b.hurt(g, dmg);
            hitAny = true;
        }
        if (hitAny) {
            g.fx.freeze = Math.max(g.fx.freeze, atk == 3 ? 0.09f : 0.05f);
            g.fx.shake(atk == 3 ? 5f : 2.5f);
        }
    }

    void hurt(Game g, int dmg, float srcX) {
        if (invuln > 0f || dead) return;
        hp -= dmg;
        if (hp < 0) hp = 0;
        invuln = 0.9f;
        hurtT = 0.3f;
        atk = 0;
        dodgeT = 0f;
        float d = cx() < srcX ? -1f : 1f;
        vx = d * 230f;
        vy = -240f;
        onGround = false;
        g.fx.shake(6f);
        g.fx.freeze = Math.max(g.fx.freeze, 0.07f);
        g.fx.flashA = 0.4f;
        g.fx.flashC = 0xFFFF2040;
        g.fx.burst(cx(), cy(), 10, 0xFFFF4060, 150f, 0.4f, 2.4f);
        g.fx.text(cx(), y - 6f, "-" + dmg, 0xFFFF6070);
    }

    /** Falling into a pit: small damage, then back to the last safe ground. */
    void pitReset(Game g) {
        if (dead) return;
        x = lastSafeX;
        y = lastSafeY;
        vx = 0f;
        vy = 0f;
        if (invuln <= 0f) {
            hp = Math.max(0, hp - 15);
            g.fx.shake(5f);
            g.fx.flashA = 0.3f;
            g.fx.flashC = 0xFFFF2040;
            g.fx.text(cx(), y - 6f, "-15", 0xFFFF6070);
        }
        invuln = 1.2f;
        hurtT = 0f;
        atk = 0;
        dodgeT = 0f;
        g.fx.burst(cx(), cy(), 12, 0xFF58E0FF, 120f, 0.4f, 2f);
    }

    private void pose() {
        Art.Fig f = fig;
        Art.hero(f, edge);
        f.x = cx();
        f.y = y + h;
        f.s = 1f;
        f.dir = facing;
        f.t = t;
        f.vx = vx;
        float sp = Math.min(1f, Math.abs(vx) / RUN);
        if (hurtT > 0f) {
            f.lean = -0.3f; f.legF = 0.25f; f.kneeF = 0.3f; f.legB = -0.5f; f.kneeB = 0.6f; f.armB = 2.4f; f.swordAng = 2.6f;
        } else if (dodgeT > 0f) {
            f.lean = 0.8f; f.legF = 1.1f; f.kneeF = 0.2f; f.legB = -1.2f; f.kneeB = 0.5f; f.armB = -1.0f; f.swordAng = -0.9f;
        } else if (atk > 0) {
            float pr = atkT / atkDur;
            f.swordAng = Art.swordAngle(atk, pr);
            f.armB = 1.3f;
            if (atk == 3) {
                f.lean = pr < 0.25f ? -0.25f : 0.25f + 0.5f * Math.min(1f, (pr - 0.25f) / 0.3f);
                f.legF = 0.9f; f.kneeF = 0.9f; f.legB = -0.9f; f.kneeB = 0.8f; f.armB = 0.3f;
            } else {
                f.lean = 0.15f + 0.25f * Math.min(1f, Math.max(0f, pr - 0.2f) / 0.3f);
                f.legF = 0.7f; f.kneeF = 0.5f; f.legB = -0.75f; f.kneeB = 0.4f;
            }
        } else if (!onGround) {
            if (vy < 0f) {
                f.lean = 0.12f; f.legF = 0.7f; f.kneeF = 1.1f; f.legB = -0.25f; f.kneeB = 0.9f; f.armB = 1.6f; f.swordAng = 1.9f;
            } else {
                f.lean = 0.02f; f.legF = 0.35f; f.kneeF = 0.3f; f.legB = -0.4f; f.kneeB = 0.5f; f.armB = 2.2f; f.swordAng = 2.3f;
            }
        } else if (landT > 0f) {
            f.lean = 0.3f; f.legF = 0.8f; f.kneeF = 1.4f; f.legB = -0.5f; f.kneeB = 1.2f; f.armB = 0.6f; f.swordAng = 0.8f;
        } else if (sp > 0.1f) {
            float cs = (float) Math.cos(phase), sn = (float) Math.sin(phase);
            f.lean = 0.3f * sp;
            f.legF = sn * 0.95f;
            f.legB = -sn * 0.95f;
            f.kneeF = 0.15f + Math.max(0f, cs) * 0.9f;
            f.kneeB = 0.15f + Math.max(0f, -cs) * 0.9f;
            f.armB = 0.3f - sn * 0.9f;
            f.swordAng = 0.35f - sn * 0.45f;
        } else {
            Art.idle(f, t);
        }
    }

    void draw(Canvas c) {
        Paint p = Art.P;
        for (int i = 0; i < 4; i++) {
            if (ga[i] <= 0f) continue;
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeWidth(7f);
            p.setColor(0xFF58E0FF);
            p.setAlpha((int) (220f * ga[i]));
            c.drawLine(gx[i] - gd[i] * 2f, gy[i] - 8f, gx[i] + gd[i] * 4f, gy[i] - 26f, p);
            Art.dot(c, gx[i] + gd[i] * 5f, gy[i] - 30f, 4.5f, 0xFF58E0FF, (int) (220f * ga[i]));
        }
        if (dead) return;
        Art.glow(c, Art.GLOW_CYAN, cx(), y + h * 0.5f, 56f, 0.5f);
        fig.alpha = (invuln > 0f && dodgeT <= 0f && ((int) (t * 24f) & 1) == 0) ? 110 : 255;
        fig.flash = hurtT > 0f ? 1f : 0f;
        Art.draw(c, fig);
    }
}
