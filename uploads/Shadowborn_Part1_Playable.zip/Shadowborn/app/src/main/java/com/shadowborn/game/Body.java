package com.shadowborn.game;

/** Axis-aligned physics body that collides with the tile grid. */
class Body {
    float x, y, w, h, vx, vy;
    float gravity = 1500f;
    boolean onGround, hitWall;

    final float cx() { return x + w * 0.5f; }
    final float cy() { return y + h * 0.5f; }

    static boolean overlap(float ax, float ay, float aw, float ah, float bx, float by, float bw, float bh) {
        return ax < bx + bw && ax + aw > bx && ay < by + bh && ay + ah > by;
    }

    static float approach(float v, float target, float step) {
        return v < target ? Math.min(v + step, target) : Math.max(v - step, target);
    }

    static float clamp(float v, float lo, float hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }

    void physics(World wd, float dt) {
        vy += gravity * dt;
        if (vy > 900f) vy = 900f;
        hitWall = false;
        moveX(wd, vx * dt);
        onGround = false;
        moveY(wd, vy * dt);
    }

    private void moveX(World wd, float dx) {
        x += dx;
        int ty0 = (int) Math.floor(y / World.TS);
        int ty1 = (int) Math.floor((y + h - 0.01f) / World.TS);
        if (dx > 0f) {
            int tx = (int) Math.floor((x + w) / World.TS);
            for (int ty = ty0; ty <= ty1; ty++) {
                if (wd.solid(tx, ty)) { x = tx * World.TS - w; vx = 0f; hitWall = true; break; }
            }
        } else if (dx < 0f) {
            int tx = (int) Math.floor(x / World.TS);
            for (int ty = ty0; ty <= ty1; ty++) {
                if (wd.solid(tx, ty)) { x = (tx + 1) * World.TS; vx = 0f; hitWall = true; break; }
            }
        }
    }

    private void moveY(World wd, float dy) {
        y += dy;
        int tx0 = (int) Math.floor(x / World.TS);
        int tx1 = (int) Math.floor((x + w - 0.01f) / World.TS);
        if (dy >= 0f) {
            int ty = (int) Math.floor((y + h) / World.TS);
            for (int tx = tx0; tx <= tx1; tx++) {
                if (wd.solid(tx, ty)) { y = ty * World.TS - h; vy = 0f; onGround = true; break; }
            }
        } else {
            int ty = (int) Math.floor(y / World.TS);
            for (int tx = tx0; tx <= tx1; tx++) {
                if (wd.solid(tx, ty)) { y = (ty + 1) * World.TS; vy = 0f; break; }
            }
        }
    }
}
