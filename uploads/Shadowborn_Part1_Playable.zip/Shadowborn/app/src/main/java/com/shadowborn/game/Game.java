package com.shadowborn.game;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.ConcurrentLinkedQueue;

/** Game state machine: owns the world, entities, camera, menus and progression. */
final class Game {
    static final int MENU = 0, PLAY = 1, PAUSE = 2, SETTINGS = 3, DEAD = 4;
    static final float VH = 360f;

    final Save save;
    final Input input = new Input();
    final Controls controls = new Controls();
    final Fx fx = new Fx();
    final World world = new World();
    final Player player = new Player();
    final ArrayList<Enemy> enemies = new ArrayList<>();
    final ArrayList<Proj> projs = new ArrayList<>();
    final ArrayList<Pickup> pickups = new ArrayList<>();
    final ConcurrentLinkedQueue<float[]> taps = new ConcurrentLinkedQueue<>();
    final Random rnd = new Random();
    final Paint vignette = new Paint();
    final float[] btnPlay = new float[4], btnSettings = new float[4], pauseBtn = new float[4];
    final float[][] pBtn = new float[4][4], sBtn = new float[5][4], dBtn = new float[2][4];

    Boss boss;
    volatile int state = MENU;
    int prevState = MENU, fadeDir, pendingRoom, shardsShown = -1;
    float vw = 800f, scale = 1f, time, camX, camY, deadT, fade, hpGhost = 100f, bannerT;
    boolean pendingFromLeft, resetArmed, hintShown, bossStarted;
    String bannerA = "", bannerB = "", shardStr = "0", fpsStr = "";

    Game(Context ctx) {
        save = new Save(ctx);
        applySave();
        setSize(800f, 1f);
    }

    // ------------------------------------------------------------------ layout / input plumbing

    void setSize(float w, float s) {
        vw = w;
        scale = s;
        controls.layout(vw, VH);
        layoutUi();
        vignette.setShader(new RadialGradient(vw / 2f, VH / 2f, vw * 0.65f, 0x00000000, 0xC0000000, Shader.TileMode.CLAMP));
    }

    float menuX() {
        return vw * 0.62f;
    }

    private static void set(float[] r, float x, float y, float w, float h) {
        r[0] = x;
        r[1] = y;
        r[2] = w;
        r[3] = h;
    }

    private static boolean in(float[] r, float x, float y) {
        return x >= r[0] && x <= r[0] + r[2] && y >= r[1] && y <= r[1] + r[3];
    }

    private void layoutUi() {
        float cx = vw / 2f, mx = menuX();
        set(btnPlay, mx - 115f, 188f, 230f, 50f);
        set(btnSettings, mx - 115f, 248f, 230f, 40f);
        set(pauseBtn, vw - 76f, 8f, 46f, 46f);
        for (int i = 0; i < 4; i++) set(pBtn[i], cx - 125f, 112f + i * 50f, 250f, 42f);
        for (int i = 0; i < 5; i++) set(sBtn[i], cx - 140f, 76f + i * 47f, 280f, 38f);
        set(dBtn[0], cx - 100f, 232f, 200f, 46f);
        set(dBtn[1], cx - 100f, 288f, 200f, 36f);
    }

    void setFps(int f) {
        fpsStr = "FPS " + f;
    }

    /** Called from the UI thread; returns false when the activity should handle Back itself. */
    boolean onBack() {
        if (state == MENU) return false;
        taps.add(new float[] {-1f, -1f});
        return true;
    }

    /** Called from the UI thread after the loop thread stopped. */
    void onBackground() {
        if (state == PLAY) state = PAUSE;
        input.clear();
        save.write();
    }

    private void handleTap(float x, float y) {
        if (x < 0f) {
            back();
            return;
        }
        switch (state) {
            case MENU:
                if (in(btnPlay, x, y)) {
                    startGame();
                } else if (in(btnSettings, x, y)) {
                    prevState = MENU;
                    state = SETTINGS;
                    resetArmed = false;
                }
                break;
            case PLAY:
                if (in(pauseBtn, x, y)) pause();
                break;
            case PAUSE:
                if (in(pBtn[0], x, y)) {
                    state = PLAY;
                    input.clear();
                } else if (in(pBtn[1], x, y)) {
                    buyVitality();
                } else if (in(pBtn[2], x, y)) {
                    prevState = PAUSE;
                    state = SETTINGS;
                    resetArmed = false;
                } else if (in(pBtn[3], x, y)) {
                    save.write();
                    state = MENU;
                }
                break;
            case SETTINGS:
                if (in(sBtn[0], x, y)) {
                    save.shake = !save.shake;
                    save.write();
                } else if (in(sBtn[1], x, y)) {
                    save.ctrlOpacity = save.ctrlOpacity >= 100 ? 40 : save.ctrlOpacity + 20;
                    save.write();
                } else if (in(sBtn[2], x, y)) {
                    save.fps = !save.fps;
                    save.write();
                } else if (prevState == MENU && in(sBtn[3], x, y)) {
                    if (resetArmed) {
                        save.resetProgress();
                        applySave();
                        resetArmed = false;
                    } else {
                        resetArmed = true;
                    }
                } else if (in(sBtn[4], x, y)) {
                    state = prevState;
                    resetArmed = false;
                    save.write();
                }
                break;
            case DEAD:
                if (deadT > 1.2f) {
                    if (in(dBtn[0], x, y)) {
                        respawn();
                    } else if (in(dBtn[1], x, y)) {
                        save.write();
                        state = MENU;
                    }
                }
                break;
            default:
                break;
        }
    }

    private void back() {
        switch (state) {
            case PLAY:
                pause();
                break;
            case PAUSE:
                state = PLAY;
                input.clear();
                break;
            case SETTINGS:
                state = prevState;
                resetArmed = false;
                save.write();
                break;
            default:
                break;
        }
    }

    private void pause() {
        state = PAUSE;
        input.clear();
        save.write();
    }

    int upgradeCost() {
        return 40 + 35 * save.vit;
    }

    private void buyVitality() {
        if (save.vit >= 5) return;
        int cost = upgradeCost();
        if (save.shards < cost) return;
        save.shards -= cost;
        save.vit++;
        player.maxHp = 100 + 20 * save.vit;
        player.hp = player.maxHp;
        hpGhost = player.hp;
        save.write();
    }

    private void applySave() {
        player.maxHp = 100 + 20 * save.vit;
        player.hasDJ = save.dj;
        player.edge = save.edge;
    }

    // ------------------------------------------------------------------ session flow

    private void startGame() {
        applySave();
        loadRoom(save.cpRoom);
        placePlayer(save.cpCol, save.cpRow);
        player.revive();
        hpGhost = player.hp;
        state = PLAY;
        fade = 1f;
        fadeDir = -1;
        input.clear();
        updateCamera(0f, true);
        banner(world.room.name, save.hasProgress() ? "" : "Part One  -  awaken, Shadowborn");
    }

    private void die() {
        player.dead = true;
        state = DEAD;
        deadT = 0f;
        input.clear();
        fx.shake(10f);
        fx.burst(player.cx(), player.cy(), 40, 0xFF58E0FF, 220f, 0.9f, 2.8f);
        fx.flashA = 0.5f;
        fx.flashC = 0xFFFF2040;
    }

    private void respawn() {
        loadRoom(save.cpRoom);
        placePlayer(save.cpCol, save.cpRow);
        player.revive();
        hpGhost = player.hp;
        state = PLAY;
        input.clear();
        fade = 1f;
        fadeDir = -1;
        updateCamera(0f, true);
        banner(world.room.name, "");
    }

    private void placePlayer(int col, int row) {
        player.place(col * World.TS + (World.TS - player.w) / 2f, (row + 1) * World.TS - player.h);
    }

    private void loadRoom(int idx) {
        idx = Math.max(0, Math.min(world.rooms.length - 1, idx));
        world.load(idx);
        enemies.clear();
        projs.clear();
        pickups.clear();
        boss = null;
        bossStarted = false;
        hintShown = false;
        World.Room r = world.room;
        for (int ty = 0; ty < r.h; ty++) {
            for (int tx = 0; tx < r.w; tx++) {
                char ch = r.t[ty][tx];
                if (ch == '.' || ch == '#') continue;
                float px = tx * World.TS, py = ty * World.TS;
                switch (ch) {
                    case 'H':
                        enemies.add(new Enemy(Enemy.HUSK, px + 8f, py + World.TS - 30f));
                        break;
                    case 'W':
                        enemies.add(new Enemy(Enemy.WRAITH, px + 6f, py + 4f));
                        break;
                    case 'B':
                        if (!save.boss) boss = new Boss(px - 1f, py + World.TS - 70f);
                        break;
                    case 'J':
                        if (!save.dj) pickups.add(new Pickup(Pickup.DJ, px + 16f, py + 16f, -1));
                        break;
                    case 'c': {
                        int id = idx * 100000 + ty * 100 + tx;
                        if (!save.taken.contains(id)) pickups.add(new Pickup(Pickup.SHARD, px + 16f, py + 16f, id));
                        break;
                    }
                    default:
                        break;
                }
            }
        }
        if (idx == 2 && save.boss && !save.edge) {
            pickups.add(new Pickup(Pickup.EDGE, 15f * World.TS + 16f, 9f * World.TS + 12f, -1));
        }
    }

    private void startTransition(int to, boolean fromLeft) {
        pendingRoom = to;
        pendingFromLeft = fromLeft;
        fadeDir = 1;
    }

    private void finishTransition() {
        save.write();
        loadRoom(pendingRoom);
        int[] m = world.find(pendingFromLeft ? 'L' : 'R');
        if (m == null) m = new int[] {2, 9};
        placePlayer(m[0], m[1]);
        player.facing = pendingFromLeft ? 1 : -1;
        updateCamera(0f, true);
        fadeDir = -1;
        banner(world.room.name, "");
    }

    void banner(String a, String b) {
        bannerA = a;
        bannerB = b;
        bannerT = 3.2f;
    }

    void addShards(int n, float x, float y, boolean text) {
        save.shards += n;
        if (text) fx.text(x, y, "+" + n, 0xFF9AF0FF);
    }

    void unlockDoubleJump(float x, float y) {
        save.dj = true;
        player.hasDJ = true;
        fx.ring(x, y, 90f, 0xFF58E0FF);
        fx.burst(x, y, 30, 0xFF9AF0FF, 200f, 0.8f, 2.6f);
        fx.flashA = 0.5f;
        fx.flashC = 0xFF9AF0FF;
        fx.shake(4f);
        banner("WRAITH STRIDE", "Double jump unlocked  -  tap jump again in mid-air");
        save.write();
    }

    void unlockEdge(float x, float y) {
        save.edge = true;
        player.edge = true;
        fx.ring(x, y, 90f, 0xFFFF3050);
        fx.burst(x, y, 30, 0xFFFF6070, 200f, 0.8f, 2.6f);
        fx.flashA = 0.5f;
        fx.flashC = 0xFFFF6070;
        fx.shake(4f);
        banner("UMBRAL EDGE", "Sword damage and reach increased");
        save.write();
    }

    void onBossDefeated(Boss b) {
        save.boss = true;
        world.gateClosed = false;
        fx.slowT = 0.5f;
        fx.flashA = 0.6f;
        fx.flashC = 0xFFFFFFFF;
        fx.shake(12f);
        fx.burst(b.cx(), b.cy(), 60, 0xFFFF3050, 260f, 1.0f, 3.4f);
        addShards(100, b.cx(), b.y, true);
        pickups.add(new Pickup(Pickup.EDGE, 15f * World.TS + 16f, 9f * World.TS + 12f, -1));
        projs.clear();
        banner("THE ASHEN WARDEN FALLS", "Claim the Umbral Edge");
        save.write();
    }

    // ------------------------------------------------------------------ update

    void update(float dt) {
        time += dt;
        if (bannerT > 0f) bannerT -= dt;
        float[] tp;
        while ((tp = taps.poll()) != null) handleTap(tp[0], tp[1]);
        if (state == PLAY) {
            updatePlay(dt);
        } else if (state == DEAD) {
            deadT += dt;
            fx.update(dt);
        }
    }

    private void updatePlay(float dt) {
        if (fadeDir > 0) {
            fade += dt * 5f;
            if (fade >= 1f) {
                fade = 1f;
                finishTransition();
            }
        } else if (fadeDir < 0) {
            fade -= dt * 4f;
            if (fade <= 0f) {
                fade = 0f;
                fadeDir = 0;
            }
        }
        if (fx.freeze > 0f) {
            fx.freeze -= dt;
            return;
        }
        float sdt = fx.slowT > 0f ? dt * 0.35f : dt;
        player.update(this, input, sdt);
        for (int i = enemies.size() - 1; i >= 0; i--) {
            Enemy e = enemies.get(i);
            e.update(this, sdt);
            if (e.remove) enemies.remove(i);
        }
        if (boss != null) {
            boss.update(this, sdt);
            if (boss.dead) boss = null;
        }
        for (int i = projs.size() - 1; i >= 0; i--) {
            Proj pr = projs.get(i);
            pr.update(this, sdt);
            if (pr.dead) projs.remove(i);
        }
        for (int i = pickups.size() - 1; i >= 0; i--) {
            Pickup pk = pickups.get(i);
            pk.update(this, sdt);
            if (pk.gone) pickups.remove(i);
        }
        hazards();
        checkpoints();
        triggers();
        fx.update(sdt);
        updateCamera(dt, false);
        if (hpGhost > player.hp) hpGhost = Math.max(player.hp, hpGhost - 45f * dt);
        else hpGhost = player.hp;
        if (fadeDir == 0) {
            World.Room r = world.room;
            float pc = player.cx();
            if (pc < 0f && r.leftTo >= 0) startTransition(r.leftTo, false);
            else if (pc > r.w * World.TS && r.rightTo >= 0) startTransition(r.rightTo, true);
        }
        if (player.hp <= 0 && !player.dead) die();
    }

    private void hazards() {
        Player p = player;
        if (p.dead) return;
        int x0 = (int) Math.floor((p.x + 2f) / World.TS), x1 = (int) Math.floor((p.x + p.w - 2f) / World.TS);
        int y0 = (int) Math.floor((p.y + 4f) / World.TS), y1 = (int) Math.floor((p.y + p.h - 1f) / World.TS);
        for (int ty = y0; ty <= y1; ty++) {
            for (int tx = x0; tx <= x1; tx++) {
                if (!world.isSpike(tx, ty)) continue;
                boolean up = world.solid(tx, ty + 1);
                float sx = tx * World.TS + 4f, sy = up ? ty * World.TS + 14f : ty * World.TS;
                if (p.invuln <= 0f && Body.overlap(sx, sy, World.TS - 8f, 18f, p.x, p.y, p.w, p.h)) {
                    p.hurt(this, 20, tx * World.TS + 16f);
                    p.vy = -280f;
                }
            }
        }
        if (p.y > world.room.h * World.TS + 20f) p.pitReset(this);
    }

    private void checkpoints() {
        World.Room r = world.room;
        int pc = (int) Math.floor(player.cx() / World.TS), pr = (int) Math.floor((player.y + player.h - 2f) / World.TS);
        for (int ty = pr - 1; ty <= pr + 1; ty++) {
            for (int tx = pc - 1; tx <= pc + 1; tx++) {
                if (tx < 0 || ty < 0 || tx >= r.w || ty >= r.h || r.t[ty][tx] != 'C') continue;
                if (save.cpRoom == world.index && save.cpCol == tx && save.cpRow == ty) continue;
                save.cpRoom = world.index;
                save.cpCol = tx;
                save.cpRow = ty;
                player.hp = player.maxHp;
                banner("CHECKPOINT", "Ember shrine lit  -  health restored");
                fx.ring(tx * World.TS + 16f, ty * World.TS + 16f, 70f, 0xFFFFB060);
                fx.burst(tx * World.TS + 16f, ty * World.TS + 8f, 22, 0xFFFFA040, 150f, 0.8f, 2.4f);
                fx.flashA = 0.25f;
                fx.flashC = 0xFFFFB060;
                save.write();
            }
        }
    }

    private void triggers() {
        if (boss != null && !bossStarted && player.cx() > 9f * World.TS) {
            bossStarted = true;
            world.gateClosed = true;
            boss.wake();
            fx.shake(4f);
            banner("THE ASHEN WARDEN", "Mini-boss  -  the gate seals behind you");
        }
        if (!hintShown && world.index == 1 && !save.dj && player.cx() > 44f * World.TS) {
            hintShown = true;
            banner("THE CHASM IS TOO WIDE", "Seek the shrine in the crypt");
        }
    }

    private void updateCamera(float dt, boolean snap) {
        World.Room r = world.room;
        float ww = r.w * World.TS, wh = r.h * World.TS;
        float tx = player.cx() - vw * 0.5f + player.facing * 36f;
        float ty = player.y + player.h * 0.5f - VH * 0.58f;
        tx = ww <= vw ? (ww - vw) * 0.5f : Body.clamp(tx, 0f, ww - vw);
        ty = wh <= VH ? (wh - VH) * 0.5f : Body.clamp(ty, 0f, wh - VH);
        if (snap) {
            camX = tx;
            camY = ty;
        } else {
            camX += (tx - camX) * Math.min(1f, 7f * dt);
            camY += (ty - camY) * Math.min(1f, 5f * dt);
        }
    }

    // ------------------------------------------------------------------ render

    void render(Canvas c) {
        c.drawColor(0xFF000000);
        c.save();
        c.scale(scale, scale);
        if (state == MENU || (state == SETTINGS && prevState == MENU)) {
            Ui.menu(this, c);
        } else {
            renderWorld(c);
            Ui.hud(this, c);
        }
        if (state == PAUSE) Ui.pause(this, c);
        else if (state == SETTINGS) Ui.settings(this, c);
        else if (state == DEAD) Ui.dead(this, c);
        c.restore();
    }

    private void renderWorld(Canvas c) {
        float sx = 0f, sy = 0f;
        if (save.shake && fx.shake > 0f) {
            sx = (rnd.nextFloat() * 2f - 1f) * fx.shake;
            sy = (rnd.nextFloat() * 2f - 1f) * fx.shake;
        }
        World.Room r = world.room;
        Art.backdrop(c, r.theme, Math.max(0f, camX), vw, VH, time);
        c.save();
        c.translate(-camX + sx, -camY + sy);
        world.draw(c, camX, camY, vw, VH, time, save);
        for (int i = 0; i < pickups.size(); i++) pickups.get(i).draw(c);
        for (int i = 0; i < enemies.size(); i++) enemies.get(i).draw(c);
        if (boss != null) boss.draw(c);
        for (int i = 0; i < projs.size(); i++) projs.get(i).draw(c);
        player.draw(c);
        fx.draw(c);
        c.restore();
        fx.ambient(c, vw, VH, time, r.theme == 1 ? 0xFF60E0FF : 0xFFFFA060);
        c.drawRect(0f, 0f, vw, VH, vignette);
    }
}
