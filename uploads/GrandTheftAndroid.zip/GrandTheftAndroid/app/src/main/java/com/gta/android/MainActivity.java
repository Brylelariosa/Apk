package com.gta.android;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;

public class MainActivity extends Activity {

    private GameView gameView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Full-screen, keep screen on
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN          |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION     |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY    |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN   |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        );

        gameView = new GameView(this);
        setContentView(gameView);
    }

    @Override protected void onResume()  { super.onResume();  gameView.onResume(); }
    @Override protected void onPause()   { super.onPause();   gameView.onPause();  }
}
