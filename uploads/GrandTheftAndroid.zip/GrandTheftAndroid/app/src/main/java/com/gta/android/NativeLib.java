package com.gta.android;

public class NativeLib {
    static { System.loadLibrary("gtagame"); }

    public static native void  init(int width, int height);
    public static native void  resize(int width, int height);
    public static native void  frame(float deltaTime);
    public static native void  touchDown(int pointerId, float x, float y);
    public static native void  touchMove(int pointerId, float x, float y);
    public static native void  touchUp(int pointerId, float x, float y);
    public static native void  destroy();
    public static native float getPlayerHealth();
    public static native int   getWantedStars();
}
