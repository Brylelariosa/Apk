package com.gta.android;

import android.content.Context;
import android.opengl.GLSurfaceView;
import android.view.MotionEvent;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class GameView extends GLSurfaceView implements GLSurfaceView.Renderer {

    private long lastFrameNanos = 0;
    private boolean initialised = false;

    public GameView(Context ctx) {
        super(ctx);
        setEGLContextClientVersion(3);          // OpenGL ES 3.0
        setEGLConfigChooser(8,8,8,0, 24, 0);   // 24-bit depth, no MSAA
        setRenderer(this);
        setRenderMode(RENDERMODE_CONTINUOUSLY);
    }

    // ── GLSurfaceView.Renderer ────────────────────────────────────────────

    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        // Defer real init until we know the size
        lastFrameNanos = System.nanoTime();
    }

    @Override
    public void onSurfaceChanged(GL10 gl, int width, int height) {
        if (!initialised) {
            NativeLib.init(width, height);
            initialised = true;
        } else {
            NativeLib.resize(width, height);
        }
        lastFrameNanos = System.nanoTime();
    }

    @Override
    public void onDrawFrame(GL10 gl) {
        if (!initialised) return;
        long now = System.nanoTime();
        float dt = Math.min((now - lastFrameNanos) / 1_000_000_000f, 0.05f);
        lastFrameNanos = now;
        NativeLib.frame(dt);
    }

    // ── Touch input ───────────────────────────────────────────────────────

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        final int action = e.getActionMasked();
        final int idx    = e.getActionIndex();
        final int pid    = e.getPointerId(idx);

        switch (action) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN:
                NativeLib.touchDown(pid, e.getX(idx), e.getY(idx));
                break;

            case MotionEvent.ACTION_MOVE:
                for (int i = 0; i < e.getPointerCount(); i++) {
                    NativeLib.touchMove(e.getPointerId(i), e.getX(i), e.getY(i));
                }
                break;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP:
            case MotionEvent.ACTION_CANCEL:
                NativeLib.touchUp(pid, e.getX(idx), e.getY(idx));
                break;
        }
        return true;
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (initialised) {
            NativeLib.destroy();
            initialised = false;
        }
    }
}
