#include "Mesh.h"

void Mesh::upload(const std::vector<Vertex>& verts, const std::vector<uint32_t>& indices) {
    if (ready) destroy();
    indexCount = (GLsizei)indices.size();

    glGenVertexArrays(1, &vao);
    glGenBuffers(1, &vbo);
    glGenBuffers(1, &ebo);

    glBindVertexArray(vao);

    glBindBuffer(GL_ARRAY_BUFFER, vbo);
    glBufferData(GL_ARRAY_BUFFER, verts.size()*sizeof(Vertex), verts.data(), GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size()*sizeof(uint32_t), indices.data(), GL_STATIC_DRAW);

    constexpr GLsizei stride = sizeof(Vertex);
    // pos
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, (void*)0);
    // normal
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, stride, (void*)(3*sizeof(float)));
    // color
    glEnableVertexAttribArray(2);
    glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, stride, (void*)(6*sizeof(float)));

    glBindVertexArray(0);
    ready = true;
}

void Mesh::draw() const {
    if (!ready) return;
    glBindVertexArray(vao);
    glDrawElements(GL_TRIANGLES, indexCount, GL_UNSIGNED_INT, nullptr);
    glBindVertexArray(0);
}

void Mesh::destroy() {
    if (vao) { glDeleteVertexArrays(1,&vao); vao=0; }
    if (vbo) { glDeleteBuffers(1,&vbo); vbo=0; }
    if (ebo) { glDeleteBuffers(1,&ebo); ebo=0; }
    ready = false;
}

// ─── Box builder ──────────────────────────────────────────────────────────────
void Mesh::buildBox(std::vector<Vertex>& V, std::vector<uint32_t>& I,
                    float w, float h, float d,
                    float r, float g, float b,
                    uint32_t base) {
    float hw=w/2, hh=h/2, hd=d/2;
    // 6 faces, each 4 verts
    struct Face { float nx,ny,nz; float verts[4][3]; };
    Face faces[6] = {
        // +X
        { 1,0,0, { {hw,-hh,-hd},{hw,-hh,hd},{hw,hh,hd},{hw,hh,-hd} } },
        // -X
        {-1,0,0, { {-hw,-hh,hd},{-hw,-hh,-hd},{-hw,hh,-hd},{-hw,hh,hd} } },
        // +Y
        { 0,1,0, { {-hw,hh,-hd},{hw,hh,-hd},{hw,hh,hd},{-hw,hh,hd} } },
        // -Y
        { 0,-1,0,{ {-hw,-hh,hd},{hw,-hh,hd},{hw,-hh,-hd},{-hw,-hh,-hd} } },
        // +Z
        { 0,0,1, { {-hw,-hh,hd},{hw,-hh,hd},{hw,hh,hd},{-hw,hh,hd} } },
        // -Z
        { 0,0,-1,{ {hw,-hh,-hd},{-hw,-hh,-hd},{-hw,hh,-hd},{hw,hh,-hd} } },
    };
    for (auto& f : faces) {
        uint32_t idx = base + (uint32_t)V.size();
        for (int i=0;i<4;i++)
            V.push_back({f.verts[i][0],f.verts[i][1],f.verts[i][2], f.nx,f.ny,f.nz, r,g,b});
        I.insert(I.end(), {idx,idx+1,idx+2, idx,idx+2,idx+3});
    }
}

void Mesh::buildGround(std::vector<Vertex>& V, std::vector<uint32_t>& I,
                       float hw, float hd, float r, float g, float b) {
    uint32_t base = (uint32_t)V.size();
    V.push_back({-hw,0,-hd, 0,1,0, r,g,b});
    V.push_back({ hw,0,-hd, 0,1,0, r,g,b});
    V.push_back({ hw,0, hd, 0,1,0, r,g,b});
    V.push_back({-hw,0, hd, 0,1,0, r,g,b});
    I.insert(I.end(), {base,base+1,base+2, base,base+2,base+3});
}
