#include "Renderer.h"
#include <android/log.h>
#define TAG "GTARenderer"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

// ════════════════════════════════════════════════════════════════════════════
//  Geometry shader — Phong per-fragment lighting
// ════════════════════════════════════════════════════════════════════════════
static const char* GEO_VERT = R"glsl(
#version 300 es
layout(location=0) in vec3 aPos;
layout(location=1) in vec3 aNormal;
layout(location=2) in vec3 aColor;

uniform mat4 uMVP;
uniform mat4 uModel;
uniform mat3 uNormalMat;

out vec3 vFragPos;
out vec3 vNormal;
out vec3 vColor;

void main() {
    vec4 worldPos = uModel * vec4(aPos, 1.0);
    vFragPos  = worldPos.xyz;
    vNormal   = normalize(uNormalMat * aNormal);
    vColor    = aColor;
    gl_Position = uMVP * vec4(aPos, 1.0);
}
)glsl";

static const char* GEO_FRAG = R"glsl(
#version 300 es
precision mediump float;

in  vec3 vFragPos;
in  vec3 vNormal;
in  vec3 vColor;
out vec4 fragColor;

uniform vec3  uSunDir;
uniform vec3  uSunColor;
uniform float uAmbient;
uniform vec3  uFogColor;
uniform float uFogStart;
uniform float uFogEnd;
uniform vec3  uCamPos;

void main() {
    float diff    = max(dot(vNormal, -normalize(uSunDir)), 0.0);
    vec3  light   = uAmbient * vec3(1.0) + diff * uSunColor;
    vec3  color   = clamp(vColor * light, 0.0, 1.0);

    // Simple linear fog
    float dist    = length(uCamPos - vFragPos);
    float fogFac  = clamp((dist - uFogStart) / (uFogEnd - uFogStart), 0.0, 1.0);
    color = mix(color, uFogColor, fogFac);

    fragColor = vec4(color, 1.0);
}
)glsl";

// ════════════════════════════════════════════════════════════════════════════
//  HUD shader — flat coloured quads in screen space
// ════════════════════════════════════════════════════════════════════════════
static const char* HUD_VERT = R"glsl(
#version 300 es
layout(location=0) in vec2 aPos;
uniform mat4 uOrtho;
void main() { gl_Position = uOrtho * vec4(aPos, 0.0, 1.0); }
)glsl";

static const char* HUD_FRAG = R"glsl(
#version 300 es
precision mediump float;
uniform vec4 uColor;
out vec4 fragColor;
void main() { fragColor = uColor; }
)glsl";

// ═══════════════════════════════════════════════════════════════════════════
bool Renderer::init() {
    if (!geoShader.compile(GEO_VERT, GEO_FRAG)) { LOGE("geoShader failed"); return false; }
    if (!hudShader.compile(HUD_VERT, HUD_FRAG)) { LOGE("hudShader failed"); return false; }
    setupHUDBuffers();

    glEnable(GL_DEPTH_TEST);
    glEnable(GL_CULL_FACE);
    glCullFace(GL_BACK);
    glDepthFunc(GL_LEQUAL);

    LOGI("Renderer initialised");
    return true;
}

void Renderer::destroy() {
    geoShader.destroy(); hudShader.destroy();
    if (hudVAO) { glDeleteVertexArrays(1,&hudVAO); hudVAO=0; }
    if (hudVBO) { glDeleteBuffers(1,&hudVBO); hudVBO=0; }
}

void Renderer::resize(int w, int h) {
    screenW=w; screenH=h;
    glViewport(0,0,w,h);
}

void Renderer::setupHUDBuffers() {
    glGenVertexArrays(1,&hudVAO);
    glGenBuffers(1,&hudVBO);
    glBindVertexArray(hudVAO);
    glBindBuffer(GL_ARRAY_BUFFER, hudVBO);
    glBufferData(GL_ARRAY_BUFFER, 6*2*sizeof(float), nullptr, GL_DYNAMIC_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0,2,GL_FLOAT,GL_FALSE,2*sizeof(float),(void*)0);
    glBindVertexArray(0);
}

void Renderer::beginFrame(const Camera& cam) {
    const float SKY_R=0.53f, SKY_G=0.71f, SKY_B=0.85f;
    glClearColor(SKY_R,SKY_G,SKY_B,1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    float aspect = (screenH>0) ? (float)screenW/screenH : 1.0f;
    projMat  = cam.getProjection(aspect);
    viewMat  = cam.getViewMatrix();
    camPos   = cam.getPosition();

    geoShader.use();
    geoShader.setVec3("uSunDir",   SUN_DIR.x, SUN_DIR.y, SUN_DIR.z);
    geoShader.setVec3("uSunColor", 0.9f,0.85f,0.7f);
    geoShader.setFloat("uAmbient", 0.3f);
    geoShader.setVec3("uFogColor", SKY_R,SKY_G,SKY_B);
    geoShader.setFloat("uFogStart", 80.0f);
    geoShader.setFloat("uFogEnd",  200.0f);
    geoShader.setVec3("uCamPos",   camPos.x,camPos.y,camPos.z);
}

void Renderer::endFrame() { /* nothing yet */ }

void Renderer::drawMesh(const Mesh& mesh, const mat4& model) {
    mat4 mvp = projMat * viewMat * model;
    float nm[9]; model.normalMatrix(nm);
    geoShader.setMat4("uMVP",       mvp.m);
    geoShader.setMat4("uModel",     model.m);
    geoShader.setMat3("uNormalMat", nm);
    mesh.draw();
}

void Renderer::drawBox(const vec3& pos, const vec3& sz, float rotY,
                       float r, float g, float b) {
    std::vector<Vertex> verts;
    std::vector<uint32_t> idx;
    Mesh::buildBox(verts, idx, sz.x, sz.y, sz.z, r, g, b);
    Mesh tmp;
    tmp.upload(verts, idx);
    mat4 model = mat4::translation(pos) * mat4::rotationY(rotY);
    drawMesh(tmp, model);
    tmp.destroy();
}

void Renderer::beginHUD() {
    glDisable(GL_DEPTH_TEST);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    mat4 ortho = mat4::ortho(0,(float)screenW,0,(float)screenH,-1,1);
    hudShader.use();
    hudShader.setMat4("uOrtho", ortho.m);
}

void Renderer::drawHUDRect(float x, float y, float w, float h,
                           float r, float g, float b, float a) {
    float verts[] = {
        x,   y,
        x+w, y,
        x+w, y+h,
        x,   y,
        x+w, y+h,
        x,   y+h
    };
    glBindVertexArray(hudVAO);
    glBindBuffer(GL_ARRAY_BUFFER, hudVBO);
    glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(verts), verts);
    hudShader.setVec4("uColor", r,g,b,a);
    glDrawArrays(GL_TRIANGLES, 0, 6);
    glBindVertexArray(0);
}

void Renderer::endHUD() {
    glDisable(GL_BLEND);
    glEnable(GL_DEPTH_TEST);
}
