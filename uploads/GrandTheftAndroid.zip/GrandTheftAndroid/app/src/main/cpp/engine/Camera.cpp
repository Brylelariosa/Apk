#include "Camera.h"

void Camera::followTarget(const vec3& t, float dt) {
    // Smooth lerp target
    float s = 1.0f - expf(-12.0f * dt);
    target = target + (t - target) * s;
}

void Camera::applyLook(float dX, float dY) {
    yaw   += dX * YAW_SENS;
    pitch += dY * PITCH_SENS;
    pitch  = clampf(pitch, PITCH_MIN, PITCH_MAX);
}

vec3 Camera::getPosition() const {
    // Spherical coordinates around target
    float cp = cosf(pitch);
    float sp = sinf(pitch);
    return {
        target.x + dist * cp * sinf(yaw),
        target.y - dist * sp,           // -sp because pitch<0 means above
        target.z + dist * cp * cosf(yaw)
    };
}

mat4 Camera::getViewMatrix() const {
    return mat4::lookAt(getPosition(), target, {0,1,0});
}

mat4 Camera::getProjection(float aspect) const {
    return mat4::perspective(60.0f, aspect, 0.3f, 400.0f);
}

vec3 Camera::getForwardXZ() const {
    return vec3{sinf(yaw), 0, cosf(yaw)}.normalize();
}

vec3 Camera::getRightXZ() const {
    return vec3{cosf(yaw), 0, -sinf(yaw)}.normalize();
}
