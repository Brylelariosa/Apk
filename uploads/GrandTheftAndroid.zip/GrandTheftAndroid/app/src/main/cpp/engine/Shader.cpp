#include "Shader.h"
#include <android/log.h>
#define TAG "GTAShader"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

GLuint Shader::compileStage(GLenum type, const char* src) {
    GLuint s = glCreateShader(type);
    glShaderSource(s, 1, &src, nullptr);
    glCompileShader(s);
    GLint ok; glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        char buf[1024]; glGetShaderInfoLog(s, sizeof(buf), nullptr, buf);
        LOGE("Shader compile error: %s", buf);
        glDeleteShader(s); return 0;
    }
    return s;
}

bool Shader::compile(const char* vertSrc, const char* fragSrc) {
    GLuint vert = compileStage(GL_VERTEX_SHADER, vertSrc);
    GLuint frag = compileStage(GL_FRAGMENT_SHADER, fragSrc);
    if (!vert || !frag) return false;
    program = glCreateProgram();
    glAttachShader(program, vert);
    glAttachShader(program, frag);
    glLinkProgram(program);
    glDeleteShader(vert); glDeleteShader(frag);
    GLint ok; glGetProgramiv(program, GL_LINK_STATUS, &ok);
    if (!ok) {
        char buf[1024]; glGetProgramInfoLog(program, sizeof(buf), nullptr, buf);
        LOGE("Shader link error: %s", buf);
        glDeleteProgram(program); program = 0; return false;
    }
    return true;
}

void Shader::use()    const { glUseProgram(program); }
void Shader::destroy()      { if(program) { glDeleteProgram(program); program=0; } }

void Shader::setMat4(const char* n, const float* m)  const { glUniformMatrix4fv(glGetUniformLocation(program,n),1,GL_FALSE,m); }
void Shader::setMat3(const char* n, const float* m)  const { glUniformMatrix3fv(glGetUniformLocation(program,n),1,GL_FALSE,m); }
void Shader::setVec3(const char* n, float x, float y, float z) const { glUniform3f(glGetUniformLocation(program,n),x,y,z); }
void Shader::setVec3(const char* n, const vec3& v) const { glUniform3f(glGetUniformLocation(program,n),v.x,v.y,v.z); }
void Shader::setVec4(const char* n, float x, float y, float z, float w) const { glUniform4f(glGetUniformLocation(program,n),x,y,z,w); }
void Shader::setFloat(const char* n, float v) const { glUniform1f(glGetUniformLocation(program,n),v); }
void Shader::setInt(const char* n, int v)     const { glUniform1i(glGetUniformLocation(program,n),v); }
