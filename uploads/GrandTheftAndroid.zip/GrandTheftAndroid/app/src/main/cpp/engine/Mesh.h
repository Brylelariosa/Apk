#pragma once
#include <GLES3/gl3.h>
#include <vector>
#include "MathUtils.h"

// Vertex: position(xyz) + normal(xyz) + color(rgb)  — 9 floats, 36 bytes
struct Vertex {
    float px, py, pz;
    float nx, ny, nz;
    float cr, cg, cb;
};

class Mesh {
public:
    GLuint vao = 0, vbo = 0, ebo = 0;
    GLsizei indexCount = 0;
    bool ready = false;

    void upload(const std::vector<Vertex>& verts, const std::vector<uint32_t>& indices);
    void draw() const;
    void destroy();

    // ── Static geometry factories ──────────────────────────────────────────
    // Box centred at origin, size w×h×d
    static void buildBox(std::vector<Vertex>& verts, std::vector<uint32_t>& indices,
                         float w, float h, float d,
                         float r, float g, float b,
                         uint32_t baseIndex = 0);

    // Flat quad on XZ plane, centred at origin
    static void buildGround(std::vector<Vertex>& verts, std::vector<uint32_t>& indices,
                            float halfW, float halfD,
                            float r, float g, float b);
};
