#pragma once
#include <GLES3/gl3.h>
#include "Shader.h"
#include "Mesh.h"
#include "Camera.h"

class Renderer {
public:
    bool init();
    void destroy();
    void resize(int w, int h);

    void beginFrame(const Camera& cam);
    void endFrame();

    // Draw an instanced box (convenience: builds a temporary mesh)
    void drawBox(const vec3& pos, const vec3& size, float rotY,
                 float r, float g, float b);

    // Draw a pre-built mesh with a model transform
    void drawMesh(const Mesh& mesh, const mat4& model);

    // HUD (call after all 3D draws)
    void beginHUD();
    void drawHUDRect(float x, float y, float w, float h,
                     float r, float g, float b, float a = 1.0f);
    void endHUD();

    int screenW = 1, screenH = 1;

private:
    Shader geoShader;   // 3D geometry
    Shader hudShader;   // 2D HUD quads

    GLuint hudVAO = 0, hudVBO = 0;

    mat4 viewMat;
    mat4 projMat;
    vec3 camPos;

    // Sun direction (normalised, pointing toward light)
    const vec3 SUN_DIR = vec3{0.4f,-0.8f,0.3f}.normalize();

    void setupHUDBuffers();
};
