#pragma once
#include "MathUtils.h"

class Camera {
public:
    vec3  target;          // point the camera orbits around (player head)
    float yaw   = 0.0f;   // radians, horizontal rotation
    float pitch = -0.45f; // radians, negative = above horizon
    float dist  = 9.0f;   // follow distance

    static constexpr float PITCH_MIN = -1.35f; // ~77°  (near top-down)
    static constexpr float PITCH_MAX = -0.08f; // ~5°   (near horizontal)
    static constexpr float YAW_SENS   = 0.004f;
    static constexpr float PITCH_SENS = 0.003f;

    // Called every frame to smoothly follow player
    void followTarget(const vec3& worldTarget, float dt);

    // Right-joystick / touchpad rotation
    void applyLook(float dScreenX, float dScreenY);

    vec3  getPosition() const;
    mat4  getViewMatrix() const;
    mat4  getProjection(float aspect) const;

    // Forward direction on XZ plane (for player movement)
    vec3  getForwardXZ() const;
    vec3  getRightXZ()   const;
};
