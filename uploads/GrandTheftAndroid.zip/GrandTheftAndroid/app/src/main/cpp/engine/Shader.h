#pragma once
#include <GLES3/gl3.h>
#include <string>
#include "MathUtils.h"

class Shader {
public:
    GLuint program = 0;

    bool compile(const char* vertSrc, const char* fragSrc);
    void use() const;
    void destroy();

    void setMat4(const char* name, const float* m) const;
    void setMat3(const char* name, const float* m) const;
    void setVec3(const char* name, float x, float y, float z) const;
    void setVec3(const char* name, const vec3& v) const;
    void setVec4(const char* name, float x, float y, float z, float w) const;
    void setFloat(const char* name, float v) const;
    void setInt(const char* name, int v) const;

private:
    static GLuint compileStage(GLenum type, const char* src);
};
