#pragma once
#include <cmath>
#include <algorithm>

static constexpr float PI = 3.14159265f;
static constexpr float DEG2RAD = PI / 180.0f;
static constexpr float RAD2DEG = 180.0f / PI;

inline float clampf(float v, float lo, float hi) { return v < lo ? lo : v > hi ? hi : v; }
inline float lerpf(float a, float b, float t)    { return a + (b - a) * t; }

// ── vec2 ──────────────────────────────────────────────────────────────────────
struct vec2 {
    float x = 0, y = 0;
    vec2() = default;
    vec2(float x, float y) : x(x), y(y) {}
    vec2 operator+(const vec2& o) const { return {x+o.x, y+o.y}; }
    vec2 operator-(const vec2& o) const { return {x-o.x, y-o.y}; }
    vec2 operator*(float s)       const { return {x*s, y*s}; }
    float length()                const { return sqrtf(x*x + y*y); }
    vec2  normalize()             const { float l=length(); return l>1e-6f?vec2{x/l,y/l}:vec2{0,0}; }
};

// ── vec3 ──────────────────────────────────────────────────────────────────────
struct vec3 {
    float x = 0, y = 0, z = 0;
    vec3() = default;
    vec3(float x, float y, float z) : x(x), y(y), z(z) {}

    vec3 operator+(const vec3& o) const { return {x+o.x, y+o.y, z+o.z}; }
    vec3 operator-(const vec3& o) const { return {x-o.x, y-o.y, z-o.z}; }
    vec3 operator*(float s)       const { return {x*s, y*s, z*s}; }
    vec3 operator-()              const { return {-x,-y,-z}; }
    vec3& operator+=(const vec3& o)    { x+=o.x; y+=o.y; z+=o.z; return *this; }
    vec3& operator-=(const vec3& o)    { x-=o.x; y-=o.y; z-=o.z; return *this; }
    vec3& operator*=(float s)          { x*=s; y*=s; z*=s; return *this; }

    float dot(const vec3& o)  const { return x*o.x + y*o.y + z*o.z; }
    vec3  cross(const vec3& o) const { return {y*o.z-z*o.y, z*o.x-x*o.z, x*o.y-y*o.x}; }
    float length()             const { return sqrtf(x*x + y*y + z*z); }
    float lengthSq()           const { return x*x + y*y + z*z; }
    vec3  normalize()          const { float l=length(); return l>1e-6f?vec3{x/l,y/l,z/l}:vec3{0,0,0}; }
};
inline vec3 operator*(float s, const vec3& v) { return v * s; }

// ── mat4 (column-major, matches OpenGL) ──────────────────────────────────────
struct mat4 {
    float m[16];

    mat4() { *this = identity(); }

    static mat4 identity() {
        mat4 r; for(auto& v:r.m) v=0;
        r.m[0]=r.m[5]=r.m[10]=r.m[15]=1; return r;
    }

    static mat4 translation(float x, float y, float z) {
        mat4 r = identity();
        r.m[12]=x; r.m[13]=y; r.m[14]=z; return r;
    }
    static mat4 translation(const vec3& v) { return translation(v.x,v.y,v.z); }

    static mat4 scale(float x, float y, float z) {
        mat4 r = identity();
        r.m[0]=x; r.m[5]=y; r.m[10]=z; return r;
    }
    static mat4 scale(const vec3& v) { return scale(v.x,v.y,v.z); }
    static mat4 scale(float s)       { return scale(s,s,s); }

    static mat4 rotationX(float a) {
        mat4 r = identity();
        r.m[5]=cosf(a); r.m[6]=sinf(a);
        r.m[9]=-sinf(a); r.m[10]=cosf(a); return r;
    }
    static mat4 rotationY(float a) {
        mat4 r = identity();
        r.m[0]=cosf(a); r.m[2]=-sinf(a);
        r.m[8]=sinf(a); r.m[10]=cosf(a); return r;
    }
    static mat4 rotationZ(float a) {
        mat4 r = identity();
        r.m[0]=cosf(a); r.m[1]=sinf(a);
        r.m[4]=-sinf(a); r.m[5]=cosf(a); return r;
    }

    static mat4 perspective(float fovY_deg, float aspect, float znear, float zfar) {
        mat4 r; for(auto& v:r.m) v=0;
        float tanH = tanf(fovY_deg * 0.5f * DEG2RAD);
        r.m[0]  = 1.0f / (aspect * tanH);
        r.m[5]  = 1.0f / tanH;
        r.m[10] = -(zfar + znear) / (zfar - znear);
        r.m[11] = -1.0f;
        r.m[14] = -(2.0f * zfar * znear) / (zfar - znear);
        return r;
    }

    static mat4 lookAt(const vec3& eye, const vec3& center, const vec3& up) {
        vec3 f = (center - eye).normalize();
        vec3 r = f.cross(up).normalize();
        vec3 u = r.cross(f);
        mat4 res; for(auto& v:res.m) v=0;
        res.m[0]=r.x; res.m[4]=r.y; res.m[8]=r.z;
        res.m[1]=u.x; res.m[5]=u.y; res.m[9]=u.z;
        res.m[2]=-f.x; res.m[6]=-f.y; res.m[10]=-f.z;
        res.m[12]=-r.dot(eye); res.m[13]=-u.dot(eye); res.m[14]=f.dot(eye);
        res.m[15]=1; return res;
    }

    static mat4 ortho(float l, float r, float b, float t, float n, float f) {
        mat4 res; for(auto& v:res.m) v=0;
        res.m[0]=2/(r-l); res.m[5]=2/(t-b); res.m[10]=-2/(f-n);
        res.m[12]=-(r+l)/(r-l); res.m[13]=-(t+b)/(t-b); res.m[14]=-(f+n)/(f-n);
        res.m[15]=1; return res;
    }

    mat4 operator*(const mat4& o) const {
        mat4 res; for(auto& v:res.m) v=0;
        for(int c=0;c<4;c++)
            for(int row=0;row<4;row++)
                for(int k=0;k<4;k++)
                    res.m[c*4+row] += m[k*4+row] * o.m[c*4+k];
        return res;
    }

    // Normal matrix (upper-left 3x3, column-major 9 floats)
    void normalMatrix(float out[9]) const {
        out[0]=m[0]; out[1]=m[1]; out[2]=m[2];
        out[3]=m[4]; out[4]=m[5]; out[5]=m[6];
        out[6]=m[8]; out[7]=m[9]; out[8]=m[10];
    }
};

// ── AABB ─────────────────────────────────────────────────────────────────────
struct AABB {
    vec3 mn, mx;
    AABB() = default;
    AABB(vec3 mn, vec3 mx) : mn(mn), mx(mx) {}

    bool overlaps(const AABB& o) const {
        return mn.x<=o.mx.x && mx.x>=o.mn.x &&
               mn.y<=o.mx.y && mx.y>=o.mn.y &&
               mn.z<=o.mx.z && mx.z>=o.mn.z;
    }
    bool contains(const vec3& p) const {
        return p.x>=mn.x && p.x<=mx.x &&
               p.y>=mn.y && p.y<=mx.y &&
               p.z>=mn.z && p.z<=mx.z;
    }
    vec3 center() const { return {(mn.x+mx.x)*0.5f,(mn.y+mx.y)*0.5f,(mn.z+mx.z)*0.5f}; }
    vec3 size()   const { return mx - mn; }
};
