#include <jni.h>
#include <android/log.h>
#include "game/GameEngine.h"

#define TAG "GTABridge"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

static GameEngine* gEngine = nullptr;

extern "C" {

JNIEXPORT void JNICALL
Java_com_gta_android_NativeLib_init(JNIEnv*, jclass, jint w, jint h) {
    if (gEngine) { delete gEngine; gEngine = nullptr; }
    gEngine = new GameEngine();
    if (!gEngine->init(w, h)) {
        LOGE("GameEngine::init failed");
        delete gEngine; gEngine = nullptr;
    } else {
        LOGI("GameEngine init OK (%dx%d)", w, h);
    }
}

JNIEXPORT void JNICALL
Java_com_gta_android_NativeLib_resize(JNIEnv*, jclass, jint w, jint h) {
    if (gEngine) gEngine->resize(w, h);
}

JNIEXPORT void JNICALL
Java_com_gta_android_NativeLib_frame(JNIEnv*, jclass, jfloat dt) {
    if (gEngine) gEngine->frame(dt);
}

JNIEXPORT void JNICALL
Java_com_gta_android_NativeLib_touchDown(JNIEnv*, jclass, jint id, jfloat x, jfloat y) {
    if (gEngine) gEngine->touchDown(id, x, y);
}

JNIEXPORT void JNICALL
Java_com_gta_android_NativeLib_touchMove(JNIEnv*, jclass, jint id, jfloat x, jfloat y) {
    if (gEngine) gEngine->touchMove(id, x, y);
}

JNIEXPORT void JNICALL
Java_com_gta_android_NativeLib_touchUp(JNIEnv*, jclass, jint id, jfloat x, jfloat y) {
    if (gEngine) gEngine->touchUp(id, x, y);
}

JNIEXPORT void JNICALL
Java_com_gta_android_NativeLib_destroy(JNIEnv*, jclass) {
    if (gEngine) { delete gEngine; gEngine = nullptr; }
    LOGI("GameEngine destroyed");
}

JNIEXPORT jfloat JNICALL
Java_com_gta_android_NativeLib_getPlayerHealth(JNIEnv*, jclass) {
    return gEngine ? gEngine->getPlayerHealth() : 0.0f;
}

JNIEXPORT jint JNICALL
Java_com_gta_android_NativeLib_getWantedStars(JNIEnv*, jclass) {
    return gEngine ? gEngine->getWantedStars() : 0;
}

} // extern "C"
