#pragma once
#include "../engine/MathUtils.h"
#include "../engine/Renderer.h"
#include "InputState.h"

enum class PlayerState { IDLE, WALK, PUNCH, HURT, DEAD };

class Player {
public:
    vec3  position   = {0, 0, 0};
    float facing     = 0.0f;     // yaw in radians
    vec3  velocity   = {0,0,0};
    float health     = 100.0f;
    float maxHealth  = 100.0f;
    int   wantedStars = 0;

    AABB  getAABB() const;

    void  update(float dt, const InputState& input, const Camera& cam,
                 const std::vector<AABB>& staticColliders);
    void  draw(Renderer& r) const;
    void  takeDamage(float dmg);

    // Returns punch hitbox in front of player (active only during punch)
    bool  getPunchHitbox(AABB& out) const;

    bool  isAlive() const { return health > 0; }

private:
    PlayerState state      = PlayerState::IDLE;
    float       stateTimer = 0.0f;
    float       punchTimer = 0.0f;
    float       hurtTimer  = 0.0f;
    float       walkAnim   = 0.0f;   // leg oscillation phase

    void  updateMovement(float dt, const InputState& input, const Camera& cam,
                         const std::vector<AABB>& cols);
    void  resolveCollisions(const std::vector<AABB>& cols);
    void  drawCharacter(Renderer& r) const;

    static constexpr float MOVE_SPEED  = 7.0f;
    static constexpr float PUNCH_RANGE = 1.8f;
    static constexpr float HEIGHT      = 1.8f;
    static constexpr float RADIUS      = 0.35f;
};
