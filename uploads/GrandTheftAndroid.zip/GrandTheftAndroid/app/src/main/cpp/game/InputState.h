#pragma once
#include <cmath>

struct VirtualStick {
    bool  active   = false;
    int   touchId  = -1;
    float originX  = 0, originY = 0;  // initial touch screen coords
    float currX    = 0, currY   = 0;
    float axisX    = 0, axisY   = 0;  // -1..1  (Y+ = up)
    static constexpr float DEAD_ZONE = 0.15f;
    static constexpr float MAX_PIX   = 90.0f;  // pixels radius

    void begin(int id, float x, float y) {
        active=true; touchId=id;
        originX=x; originY=y;
        currX=x; currY=y;
        axisX=0; axisY=0;
    }
    void move(float x, float y) {
        currX=x; currY=y;
        float dx = x - originX, dy = y - originY;
        float len = sqrtf(dx*dx+dy*dy);
        if (len > MAX_PIX) { dx=dx/len*MAX_PIX; dy=dy/len*MAX_PIX; }
        axisX =  dx / MAX_PIX;
        axisY = -dy / MAX_PIX;  // screen Y is down → negate for world up
        if (fabsf(axisX)<DEAD_ZONE) axisX=0;
        if (fabsf(axisY)<DEAD_ZONE) axisY=0;
    }
    void end() { active=false; touchId=-1; axisX=0; axisY=0; }
};

struct TouchPad {
    bool  active   = false;
    int   touchId  = -1;
    float prevX    = 0, prevY = 0;
    float deltaX   = 0, deltaY = 0;

    void begin(int id, float x, float y) {
        active=true; touchId=id; prevX=x; prevY=y; deltaX=0; deltaY=0;
    }
    void move(float x, float y) {
        deltaX = x - prevX;
        deltaY = y - prevY;
        prevX=x; prevY=y;
    }
    void end() { active=false; touchId=-1; deltaX=0; deltaY=0; }
    void clearDeltas() { deltaX=0; deltaY=0; }
};

struct PunchButton {
    bool  active   = false;
    int   touchId  = -1;
    bool  justPressed = false;

    void begin(int id) { if(!active){ active=true; touchId=id; justPressed=true; } }
    void end(int id)   { if(touchId==id){ active=false; touchId=-1; } }
    void consume()     { justPressed=false; }
};

struct InputState {
    VirtualStick leftStick;    // movement (left half of screen)
    TouchPad     rightPad;     // camera look (right half, above punch zone)
    PunchButton  punchBtn;     // bottom-right corner

    int screenW = 1, screenH = 1;

    bool isPunchZone(float x, float y) const {
        return x > screenW * 0.70f && y > screenH * 0.65f;
    }
    bool isLeftSide(float x) const { return x < screenW * 0.50f; }

    void onDown(int id, float x, float y) {
        if (isPunchZone(x,y))          { punchBtn.begin(id); return; }
        if (isLeftSide(x))             { leftStick.begin(id,x,y); }
        else if (!rightPad.active)     { rightPad.begin(id,x,y); }
    }
    void onMove(int id, float x, float y) {
        if (leftStick.active  && leftStick.touchId  == id) leftStick.move(x,y);
        if (rightPad.active   && rightPad.touchId   == id) rightPad.move(x,y);
    }
    void onUp(int id) {
        if (leftStick.touchId  == id) leftStick.end();
        if (rightPad.touchId   == id) rightPad.end();
        punchBtn.end(id);
    }
};
