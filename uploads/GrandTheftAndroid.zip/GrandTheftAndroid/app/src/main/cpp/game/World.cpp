#include "World.h"
#include <cmath>
#include <cstring>

float World::nextRand() {
    rng ^= rng << 13; rng ^= rng >> 17; rng ^= rng << 5;
    return (rng & 0xFFFF) / 65535.0f;
}

void World::addBuilding(float x, float z, float w, float h, float d,
                        float r, float g, float b) {
    Building b_;
    b_.pos   = {x + w*0.5f, 0, z + d*0.5f};
    b_.size  = {w, h, d};
    b_.color = {r, g, b};
    b_.aabb  = { {x, 0, z}, {x+w, h, z+d} };

    std::vector<Vertex> verts; std::vector<uint32_t> idx;
    Mesh::buildBox(verts, idx, w, h, d, r, g, b);
    b_.mesh.upload(verts, idx);
    colliders.push_back(b_.aabb);
    buildings.push_back(std::move(b_));
}

void World::generate(unsigned int seed) {
    rng = seed ? seed : 1;
    buildings.clear(); colliders.clear();

    float cellSize = BLOCK + ROAD;
    float half = GRID * cellSize * 0.5f;

    // Building colour palettes
    static const float palette[][3] = {
        {0.50f,0.50f,0.52f},  // concrete
        {0.55f,0.45f,0.35f},  // brick
        {0.40f,0.50f,0.45f},  // tinted glass
        {0.65f,0.60f,0.50f},  // tan
        {0.35f,0.35f,0.40f},  // dark concrete
        {0.70f,0.40f,0.30f},  // terracotta
    };
    constexpr int PAL = 6;

    for (int bx = 0; bx < GRID; bx++) {
        for (int bz = 0; bz < GRID; bz++) {
            float originX = bx * cellSize - half + ROAD*0.5f;
            float originZ = bz * cellSize - half + ROAD*0.5f;

            // 1-4 buildings per block
            int numB = 1 + (int)(nextRand() * 3.0f);
            float usedX = 0;
            for (int i = 0; i < numB && usedX < BLOCK - 3; i++) {
                float bw = 6.0f + nextRand() * 12.0f;
                float bh = 5.0f + nextRand() * 25.0f;
                float bd = 8.0f + nextRand() * 12.0f;
                bw = std::min(bw, BLOCK - usedX - 1.0f);
                bd = std::min(bd, BLOCK - 2.0f);
                if (bw < 4 || bd < 4) break;

                int palIdx = (int)(nextRand() * PAL) % PAL;
                float cr = palette[palIdx][0] + (nextRand()-0.5f)*0.08f;
                float cg = palette[palIdx][1] + (nextRand()-0.5f)*0.08f;
                float cb = palette[palIdx][2] + (nextRand()-0.5f)*0.08f;

                addBuilding(originX + usedX, originZ, bw, bh, bd, cr, cg, cb);
                usedX += bw + 1.5f + nextRand() * 2.0f;
            }
        }
    }

    buildGroundAndRoads();
}

void World::buildGroundAndRoads() {
    // Ground — dark green grass
    {
        std::vector<Vertex> verts; std::vector<uint32_t> idx;
        Mesh::buildGround(verts, idx, EXTENT, EXTENT, 0.15f, 0.32f, 0.10f);
        groundMesh.upload(verts, idx);
    }
    // Road — dark asphalt grid
    {
        std::vector<Vertex> verts; std::vector<uint32_t> idx;
        float cellSize = BLOCK + ROAD;
        float half = GRID * cellSize * 0.5f;

        // Horizontal roads (along X axis)
        for (int r = 0; r <= GRID; r++) {
            float z0 = r * cellSize - half - ROAD * 0.5f;
            uint32_t base = (uint32_t)verts.size();
            float hw = EXTENT, hd = ROAD * 0.5f;
            float y  = 0.02f;  // slight offset to avoid z-fight
            verts.push_back({-hw, y, z0,     0,1,0, 0.22f,0.22f,0.22f});
            verts.push_back({ hw, y, z0,     0,1,0, 0.22f,0.22f,0.22f});
            verts.push_back({ hw, y, z0+ROAD,0,1,0, 0.22f,0.22f,0.22f});
            verts.push_back({-hw, y, z0+ROAD,0,1,0, 0.22f,0.22f,0.22f});
            idx.insert(idx.end(),{base,base+1,base+2, base,base+2,base+3});
        }
        // Vertical roads (along Z axis)
        for (int c = 0; c <= GRID; c++) {
            float x0 = c * cellSize - half - ROAD * 0.5f;
            uint32_t base = (uint32_t)verts.size();
            float hd2 = EXTENT;
            float y  = 0.02f;
            verts.push_back({x0,      y, -hd2, 0,1,0, 0.22f,0.22f,0.22f});
            verts.push_back({x0+ROAD, y, -hd2, 0,1,0, 0.22f,0.22f,0.22f});
            verts.push_back({x0+ROAD, y,  hd2, 0,1,0, 0.22f,0.22f,0.22f});
            verts.push_back({x0,      y,  hd2, 0,1,0, 0.22f,0.22f,0.22f});
            idx.insert(idx.end(),{base,base+1,base+2, base,base+2,base+3});
        }
        roadMesh.upload(verts, idx);
    }
}

vec3 World::safeSpawnAt(int col, int row) const {
    float cellSize = BLOCK + ROAD;
    float half = GRID * cellSize * 0.5f;
    // Spawn in road between blocks
    float x = (col + 0.5f) * cellSize - half - ROAD * 0.5f + ROAD * 0.5f;
    float z = (row + 0.5f) * cellSize - half - ROAD * 0.5f + ROAD * 0.5f;
    return {x, 0, z};
}

void World::draw(Renderer& r) const {
    // Ground
    r.drawMesh(groundMesh, mat4::identity());
    // Roads
    r.drawMesh(roadMesh, mat4::identity());
    // Buildings
    for (const auto& b : buildings) {
        mat4 model = mat4::translation(b.pos) *
                     mat4::scale(1,1,1);   // already scaled in mesh
        // The mesh is built around origin at centre; translate to half-height so Y=0 is ground
        mat4 m = mat4::translation(b.pos.x, b.size.y*0.5f, b.pos.z);
        r.drawMesh(b.mesh, m);
    }
}
