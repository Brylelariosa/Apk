#include "GameEngine.h"
#include <android/log.h>
#define TAG "GTAEngine"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

bool GameEngine::init(int w, int h) {
    if (!renderer.init()) { LOGE("Renderer init failed"); return false; }
    renderer.resize(w, h);
    input.screenW = w;
    input.screenH = h;

    world.generate(42);

    // Spawn player in first road intersection
    player.position = world.safeSpawnAt(0, 0);
    camera.target   = player.position + vec3{0, 1.2f, 0};

    spawnEnemies(8);

    LOGI("GameEngine ready — %d buildings, %d enemies",
         (int)world.buildings.size(), (int)enemies.size());
    return true;
}

void GameEngine::resize(int w, int h) {
    renderer.resize(w, h);
    input.screenW = w;
    input.screenH = h;
}

void GameEngine::spawnEnemies(int count) {
    unsigned int seed = 999;
    for (int i = 0; i < count; i++) {
        // Scatter in grid intersections
        int col = i % World::GRID;
        int row = i / World::GRID;
        vec3 sp = world.safeSpawnAt(col, row) + vec3{4.0f, 0, 4.0f};
        Enemy e;
        e.init(sp, seed + i * 137);
        enemies.push_back(e);
    }
}

void GameEngine::frame(float dt) {
    dt = (dt > 0.05f) ? 0.05f : dt;  // cap at 20 fps minimum
    totalTime += dt;

    if (gameOver) { handleRespawn(dt); return; }

    // Update input
    input.rightPad.clearDeltas();

    // Camera look from right pad
    if (input.rightPad.active) {
        camera.applyLook(input.rightPad.deltaX, input.rightPad.deltaY);
    }

    // Update player
    player.update(dt, input, camera, world.colliders);
    input.punchBtn.consume();

    // Camera follow
    vec3 camTarget = player.position + vec3{0, 1.2f, 0};
    camera.followTarget(camTarget, dt);

    // Update enemies
    for (auto& e : enemies) {
        e.update(dt, player.position, player.isAlive(), world.colliders);
    }

    updateCombat();

    if (!player.isAlive()) { gameOver = true; respawnTimer = 3.0f; }

    // ── Render ────────────────────────────────────────────────────────────
    renderer.beginFrame(camera);

    world.draw(renderer);
    player.draw(renderer);
    for (const auto& e : enemies) e.draw(renderer);

    renderer.endFrame();

    drawHUD();
}

void GameEngine::updateCombat() {
    // Player punch → hit enemies
    AABB punchBox;
    if (player.getPunchHitbox(punchBox)) {
        for (auto& e : enemies) {
            if (!e.isAlive()) continue;
            if (punchBox.overlaps(e.getAABB())) {
                e.takeDamage(25.0f);
                if (!e.isAlive()) player.wantedStars = std::min(5, player.wantedStars+1);
            }
        }
    }

    // Enemies attack player
    for (auto& e : enemies) {
        AABB attackBox;
        if (e.getAttackHitbox(attackBox) && attackBox.overlaps(player.getAABB())) {
            player.takeDamage(e.getAttackDamage());
        }
    }

    // Enemy–enemy separation (simple push)
    for (size_t i=0; i<enemies.size(); i++) {
        if (!enemies[i].isAlive()) continue;
        for (size_t j=i+1; j<enemies.size(); j++) {
            if (!enemies[j].isAlive()) continue;
            AABB a = enemies[i].getAABB(), b = enemies[j].getAABB();
            if (a.overlaps(b)) {
                vec3 d = enemies[j].position - enemies[i].position;
                float l = d.length();
                if (l < 0.01f) d={1,0,0};
                else d = d * (1.0f/l);
                float push = 0.3f;
                enemies[i].position -= d * push;
                enemies[j].position += d * push;
            }
        }
    }
}

void GameEngine::handleRespawn(float dt) {
    respawnTimer -= dt;
    if (respawnTimer <= 0) {
        // Respawn
        player.health     = player.maxHealth;
        player.wantedStars = 0;
        player.position   = world.safeSpawnAt(0, 0);
        // Reset enemies
        enemies.clear();
        spawnEnemies(8);
        gameOver = false;
    }
    // Still render but with death tint
    renderer.beginFrame(camera);
    world.draw(renderer);
    player.draw(renderer);
    for (const auto& e : enemies) e.draw(renderer);
    renderer.endFrame();
    drawHUD();
}

void GameEngine::drawHUD() {
    float sw = (float)renderer.screenW;
    float sh = (float)renderer.screenH;

    renderer.beginHUD();

    // ── Health bar ────────────────────────────────────────────────────────
    float hpFrac = player.health / player.maxHealth;
    float barW = sw * 0.28f, barH = sh * 0.028f;
    float barX = sw * 0.04f, barY = sh * 0.05f;
    // Background
    renderer.drawHUDRect(barX-2, barY-2, barW+4, barH+4, 0.1f,0.1f,0.1f, 0.8f);
    // Fill
    renderer.drawHUDRect(barX, barY, barW * hpFrac, barH, 0.9f,0.15f,0.15f);
    // Label border
    renderer.drawHUDRect(barX, barY, barW, barH, 0.9f,0.15f,0.15f, 0.25f);

    // ── Wanted stars ──────────────────────────────────────────────────────
    float starSize = sw * 0.032f;
    float starY    = sh * 0.11f;
    for (int i=0; i<5; i++) {
        float sx = barX + i * (starSize + starSize*0.3f);
        bool lit = i < player.wantedStars;
        float sr = lit ? 1.0f : 0.3f;
        float sg = lit ? 0.85f: 0.3f;
        float sb = lit ? 0.0f : 0.3f;
        renderer.drawHUDRect(sx, starY, starSize, starSize, sr,sg,sb, 0.9f);
    }

    // ── Left joystick visual ──────────────────────────────────────────────
    if (input.leftStick.active) {
        float jx = input.leftStick.originX;
        float jy = sh - input.leftStick.originY;  // flip Y for HUD
        float jR = sw * 0.08f;
        // Outer ring
        renderer.drawHUDRect(jx-jR,  jy-jR,  jR*2, jR*2, 0.9f,0.9f,0.9f, 0.20f);
        // Thumb dot
        float tx = jx + input.leftStick.axisX  * jR * 0.7f;
        float ty = jy + input.leftStick.axisY  * jR * 0.7f;
        float dot = jR * 0.35f;
        renderer.drawHUDRect(tx-dot, ty-dot, dot*2, dot*2, 0.9f,0.9f,0.9f, 0.60f);
    }

    // ── Punch button ──────────────────────────────────────────────────────
    {
        float pbW = sw * 0.14f, pbH = sw * 0.14f;
        float pbX = sw - pbW - sw*0.04f;
        float pbY = pbH * 0.4f;
        float pa  = input.punchBtn.active ? 0.85f : 0.50f;
        renderer.drawHUDRect(pbX, pbY, pbW, pbH, 0.95f,0.30f,0.10f, pa);
        // Small inner marker
        renderer.drawHUDRect(pbX+pbW*0.35f, pbY+pbH*0.35f,
                             pbW*0.3f, pbH*0.3f, 1.0f,0.9f,0.9f, 0.7f);
    }

    // ── Game-over overlay ─────────────────────────────────────────────────
    if (gameOver) {
        renderer.drawHUDRect(0, 0, sw, sh, 0.5f, 0.0f, 0.0f, 0.45f);
    }

    renderer.endHUD();
}

void GameEngine::touchDown(int id, float x, float y) { input.onDown(id, x, y); }
void GameEngine::touchMove(int id, float x, float y) { input.onMove(id, x, y); }
void GameEngine::touchUp  (int id, float x, float y) { input.onUp(id); }
