#pragma once
#include "../engine/Renderer.h"
#include "../engine/Camera.h"
#include "World.h"
#include "Player.h"
#include "Enemy.h"
#include "InputState.h"
#include <vector>
#include <string>

class GameEngine {
public:
    bool init(int screenW, int screenH);
    void resize(int w, int h);
    void frame(float dt);
    void touchDown(int id, float x, float y);
    void touchMove(int id, float x, float y);
    void touchUp(int id, float x, float y);

    // HUD info for Java overlay (optional)
    float getPlayerHealth() const { return player.health; }
    float getPlayerMaxHealth() const { return player.maxHealth; }
    int   getWantedStars() const { return player.wantedStars; }

private:
    Renderer    renderer;
    Camera      camera;
    World       world;
    Player      player;
    InputState  input;

    std::vector<Enemy> enemies;
    float totalTime = 0;
    bool  gameOver  = false;
    float respawnTimer = 0;

    void spawnEnemies(int count);
    void updateCombat();
    void drawHUD();
    void handleRespawn(float dt);
};
