#pragma once
#include "../engine/Mesh.h"
#include "../engine/Renderer.h"
#include <vector>

struct Building {
    vec3   pos;
    vec3   size;
    vec3   color;
    AABB   aabb;
    Mesh   mesh;
};

class World {
public:
    static constexpr int   GRID   = 5;
    static constexpr float BLOCK  = 32.0f;
    static constexpr float ROAD   = 9.0f;
    static constexpr float EXTENT = (GRID * (BLOCK + ROAD)) * 0.5f;

    std::vector<Building>    buildings;
    std::vector<AABB>        colliders;   // quick lookup for collision
    Mesh                     groundMesh;
    Mesh                     roadMesh;

    void generate(unsigned int seed = 42);
    void draw(Renderer& r) const;

    vec3 safeSpawnAt(int col, int row) const;

private:
    void addBuilding(float x, float z, float w, float h, float d,
                     float r, float g, float b);
    void buildGroundAndRoads();
    unsigned int rng;
    float nextRand();
};
