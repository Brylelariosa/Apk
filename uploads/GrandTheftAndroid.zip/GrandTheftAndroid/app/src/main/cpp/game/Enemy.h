#pragma once
#include "../engine/MathUtils.h"
#include "../engine/Renderer.h"

enum class EnemyState { IDLE, PATROL, ALERT, CHASE, ATTACK, HURT, DEAD };

class Enemy {
public:
    vec3  position;
    float facing    = 0.0f;
    float health    = 60.0f;
    bool  active    = true;

    void  init(const vec3& spawnPos, unsigned int seed);
    void  update(float dt, const vec3& playerPos, bool playerAlive,
                 const std::vector<AABB>& cols);
    void  draw(Renderer& r) const;
    void  takeDamage(float dmg);

    AABB  getAABB() const;
    bool  isAlive() const { return health > 0; }

    // Returns attack hitbox when in ATTACK state
    bool  getAttackHitbox(AABB& out) const;
    float getAttackDamage() const { return 12.0f; }

private:
    EnemyState state      = EnemyState::IDLE;
    float      stateTimer = 0.0f;
    float      alertTimer = 0.0f;
    float      attackCooldown = 0.0f;
    float      walkAnim   = 0.0f;
    vec3       patrolTarget;

    static constexpr float ALERT_RANGE  = 12.0f;
    static constexpr float ATTACK_RANGE = 1.6f;
    static constexpr float SPEED_PATROL = 2.5f;
    static constexpr float SPEED_CHASE  = 5.0f;
    static constexpr float HEIGHT       = 1.8f;
    static constexpr float RADIUS       = 0.35f;

    void moveTo(const vec3& target, float speed, float dt,
                const std::vector<AABB>& cols);
    void resolveCollisions(const std::vector<AABB>& cols);
    void pickNewPatrolTarget(unsigned int& rng);
    unsigned int rng_state = 1;
    float nextRand();
};
