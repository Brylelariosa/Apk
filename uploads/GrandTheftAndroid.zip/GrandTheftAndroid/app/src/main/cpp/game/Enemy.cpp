#include "Enemy.h"
#include <cmath>

float Enemy::nextRand() {
    rng_state ^= rng_state << 13;
    rng_state ^= rng_state >> 17;
    rng_state ^= rng_state << 5;
    return (rng_state & 0xFFFF) / 65535.0f;
}

AABB Enemy::getAABB() const {
    return { {position.x-RADIUS, position.y, position.z-RADIUS},
             {position.x+RADIUS, position.y+HEIGHT, position.z+RADIUS} };
}

bool Enemy::getAttackHitbox(AABB& out) const {
    if (state != EnemyState::ATTACK) return false;
    float px = position.x + sinf(facing) * (RADIUS + 1.0f);
    float pz = position.z + cosf(facing) * (RADIUS + 1.0f);
    out = { {px-0.5f, position.y+0.4f, pz-0.5f},
            {px+0.5f, position.y+1.4f, pz+0.5f} };
    return true;
}

void Enemy::init(const vec3& pos, unsigned int seed) {
    position   = pos;
    rng_state  = seed ? seed : 1337;
    patrolTarget = pos;
    state = EnemyState::PATROL;
}

void Enemy::takeDamage(float dmg) {
    if (!isAlive()) return;
    health -= dmg;
    if (health <= 0) { health=0; state=EnemyState::DEAD; active=false; }
    else             { state=EnemyState::HURT; stateTimer=0.3f; }
}

void Enemy::pickNewPatrolTarget(unsigned int& /*rng*/) {
    patrolTarget = {
        position.x + (nextRand()-0.5f) * 20.0f,
        0,
        position.z + (nextRand()-0.5f) * 20.0f
    };
    patrolTarget.x = clampf(patrolTarget.x, -90, 90);
    patrolTarget.z = clampf(patrolTarget.z, -90, 90);
}

void Enemy::update(float dt, const vec3& playerPos, bool playerAlive,
                   const std::vector<AABB>& cols) {
    if (!active || !isAlive()) return;

    stateTimer += dt;
    if (attackCooldown > 0) attackCooldown -= dt;

    float distToPlayer = (playerPos - position).length();
    float yDiff = fabsf(playerPos.y - position.y);

    // ── State machine ────────────────────────────────────────────────────────
    switch (state) {
    case EnemyState::IDLE:
        if (stateTimer > 2.0f + nextRand()*2.0f) {
            state=EnemyState::PATROL; stateTimer=0;
            pickNewPatrolTarget(rng_state);
        }
        if (playerAlive && distToPlayer < ALERT_RANGE && yDiff < 2)
            state=EnemyState::ALERT;
        break;

    case EnemyState::PATROL:
        moveTo(patrolTarget, SPEED_PATROL, dt, cols);
        if ((patrolTarget-position).length() < 1.0f) {
            state=EnemyState::IDLE; stateTimer=0;
        }
        if (playerAlive && distToPlayer < ALERT_RANGE && yDiff < 2)
            state=EnemyState::ALERT;
        break;

    case EnemyState::ALERT:
        alertTimer += dt;
        if (alertTimer > 0.5f) { state=EnemyState::CHASE; alertTimer=0; }
        if (!playerAlive || distToPlayer > ALERT_RANGE*1.5f) {
            state=EnemyState::PATROL; alertTimer=0;
        }
        break;

    case EnemyState::CHASE:
        moveTo(playerPos, SPEED_CHASE, dt, cols);
        if (distToPlayer <= ATTACK_RANGE && attackCooldown<=0)
            state=EnemyState::ATTACK;
        if (!playerAlive || distToPlayer > ALERT_RANGE*2.0f)
            state=EnemyState::PATROL;
        break;

    case EnemyState::ATTACK:
        // Face player
        { vec3 d = playerPos-position; facing = atan2f(d.x,d.z); }
        stateTimer += 0;
        if (stateTimer > 0.4f) {
            attackCooldown = 1.2f;
            state = EnemyState::CHASE;
            stateTimer = 0;
        }
        break;

    case EnemyState::HURT:
        if (stateTimer > 0.3f) { state=EnemyState::CHASE; stateTimer=0; }
        break;

    case EnemyState::DEAD:
        break;
    }

    walkAnim += dt * 7.0f * (state==EnemyState::PATROL||state==EnemyState::CHASE?1.0f:0.0f);
}

void Enemy::moveTo(const vec3& target, float speed, float dt,
                   const std::vector<AABB>& cols) {
    vec3 dir = target - position;
    dir.y = 0;
    float len = dir.length();
    if (len < 0.1f) return;
    dir = dir * (1.0f/len);
    facing = atan2f(dir.x, dir.z);
    position += dir * speed * dt;
    position.y = 0;
    resolveCollisions(cols);
}

void Enemy::resolveCollisions(const std::vector<AABB>& cols) {
    AABB self = getAABB();
    for (const auto& b : cols) {
        if (!self.overlaps(b)) continue;
        float ox = std::min(self.mx.x,b.mx.x) - std::max(self.mn.x,b.mn.x);
        float oz = std::min(self.mx.z,b.mx.z) - std::max(self.mn.z,b.mn.z);
        if (ox < oz) {
            float sign = (self.center().x < b.center().x) ? -1.0f : 1.0f;
            position.x += sign * ox;
        } else {
            float sign = (self.center().z < b.center().z) ? -1.0f : 1.0f;
            position.z += sign * oz;
        }
        self = getAABB();
    }
}

void Enemy::draw(Renderer& r) const {
    if (!active) return;

    float flash = (state==EnemyState::HURT) ? 1.0f : 0.0f;
    float er = 0.85f + flash*0.15f;
    float eg = 0.15f - flash*0.15f;
    float eb = 0.1f;

    float legSwing = sinf(walkAnim) * 0.22f;

    auto drawPart = [&](vec3 off, vec3 sz, float extraY,
                        float cr, float cg, float cb) {
        float s=sinf(facing), c=cosf(facing);
        vec3 ro = { off.x*c + off.z*s, off.y, -off.x*s + off.z*c };
        r.drawBox(position + ro, sz, facing + extraY, cr, cg, cb);
    };

    if (state == EnemyState::DEAD) {
        // Lying flat
        r.drawBox(position + vec3{0,0.2f,0}, {1.0f,0.2f,0.5f}, facing, er,eg,eb);
        return;
    }

    drawPart({0, 1.0f, 0},    {0.44f,0.60f,0.25f}, 0, er,eg,eb);
    drawPart({0, 1.50f, 0},   {0.30f,0.30f,0.30f}, 0, 0.85f,0.70f,0.55f);
    drawPart({-0.30f,1.0f,0}, {0.14f,0.55f,0.14f},-legSwing, er,eg,eb);
    drawPart({ 0.30f,1.0f,0}, {0.14f,0.55f,0.14f}, legSwing, er,eg,eb);
    drawPart({-0.13f,0.35f,0},{0.15f,0.55f,0.15f}, legSwing, 0.4f,0.1f,0.1f);
    drawPart({ 0.13f,0.35f,0},{0.15f,0.55f,0.15f},-legSwing, 0.4f,0.1f,0.1f);
}
