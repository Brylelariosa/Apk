#include "Player.h"
#include <cmath>

AABB Player::getAABB() const {
    return { {position.x-RADIUS, position.y, position.z-RADIUS},
             {position.x+RADIUS, position.y+HEIGHT, position.z+RADIUS} };
}

bool Player::getPunchHitbox(AABB& out) const {
    if (state != PlayerState::PUNCH || punchTimer > 0.25f) return false;
    float px = position.x + sinf(facing) * (RADIUS + PUNCH_RANGE * 0.5f);
    float pz = position.z + cosf(facing) * (RADIUS + PUNCH_RANGE * 0.5f);
    out = { {px-0.5f, position.y+0.5f, pz-0.5f},
            {px+0.5f, position.y+1.4f, pz+0.5f} };
    return true;
}

void Player::takeDamage(float dmg) {
    if (!isAlive()) return;
    health -= dmg;
    if (health <= 0) { health=0; state=PlayerState::DEAD; }
    else             { state=PlayerState::HURT; hurtTimer=0.4f; }
}

void Player::update(float dt, const InputState& input, const Camera& cam,
                    const std::vector<AABB>& cols) {
    if (!isAlive()) return;

    // State timers
    stateTimer += dt;

    // Punch trigger
    if (input.punchBtn.justPressed && state != PlayerState::PUNCH) {
        state = PlayerState::PUNCH;
        punchTimer = 0;
        stateTimer = 0;
    }

    // Hurt timer
    if (state == PlayerState::HURT) {
        hurtTimer -= dt;
        if (hurtTimer <= 0) state = PlayerState::IDLE;
    }

    // Punch timer
    if (state == PlayerState::PUNCH) {
        punchTimer += dt;
        if (punchTimer > 0.5f) { state=PlayerState::IDLE; punchTimer=0; }
    }

    // Movement (not while punching or hurt)
    if (state != PlayerState::PUNCH && state != PlayerState::HURT) {
        updateMovement(dt, input, cam, cols);
    } else {
        velocity = {0,0,0};
    }

    walkAnim += dt * 8.0f * (velocity.length() > 0.1f ? 1.0f : 0.0f);
}

void Player::updateMovement(float dt, const InputState& input, const Camera& cam,
                             const std::vector<AABB>& cols) {
    float axX = input.leftStick.axisX;
    float axZ = input.leftStick.axisY;   // joystick Y → world Z

    vec3 fwd = cam.getForwardXZ();
    vec3 rgt = cam.getRightXZ();

    vec3 move = fwd * axZ + rgt * axX;
    float len = move.length();

    if (len > 0.01f) {
        move = move.normalize() * MOVE_SPEED;
        // Smooth facing toward movement direction
        float targetFacing = atan2f(move.x, move.z);
        float diff = targetFacing - facing;
        while (diff >  PI) diff -= 2*PI;
        while (diff < -PI) diff += 2*PI;
        facing += diff * clampf(dt * 14.0f, 0, 1);
        state = PlayerState::WALK;
    } else {
        move = {0,0,0};
        state = PlayerState::IDLE;
    }

    velocity = move;
    position += velocity * dt;
    position.y = 0;  // stay on ground

    resolveCollisions(cols);
}

void Player::resolveCollisions(const std::vector<AABB>& cols) {
    AABB self = getAABB();
    for (const auto& b : cols) {
        if (!self.overlaps(b)) continue;
        // Simple push-out: find shallowest axis
        float ox = std::min(self.mx.x,b.mx.x) - std::max(self.mn.x,b.mn.x);
        float oz = std::min(self.mx.z,b.mx.z) - std::max(self.mn.z,b.mn.z);
        if (ox < oz) {
            float sign = (self.center().x < b.center().x) ? -1.0f : 1.0f;
            position.x += sign * ox;
        } else {
            float sign = (self.center().z < b.center().z) ? -1.0f : 1.0f;
            position.z += sign * oz;
        }
        self = getAABB();
    }
}

void Player::draw(Renderer& r) const {
    // Hurt flash
    float flash = (state == PlayerState::HURT) ? 1.0f : 0.0f;
    float br = 0.3f + flash * 0.7f, bg = 0.3f - flash*0.3f, bb = 0.9f - flash*0.6f;

    float legSwing = sinf(walkAnim) * 0.25f;
    float armSwing = -legSwing;
    float punchArm = (state == PlayerState::PUNCH)
                     ? sinf(clampf(punchTimer/0.25f,0,1) * PI)
                     : armSwing;

    // All boxes drawn relative to player world position + facing
    auto drawPart = [&](vec3 offset, vec3 sz, float extraRotY,
                        float cr, float cg, float cb) {
        // Rotate offset by player facing
        float s=sinf(facing), c=cosf(facing);
        vec3 ro = { offset.x*c + offset.z*s,
                    offset.y,
                   -offset.x*s + offset.z*c };
        r.drawBox(position + ro, sz, facing + extraRotY, cr, cg, cb);
    };

    // Body
    drawPart({0, 1.0f, 0},    {0.44f,0.60f,0.25f}, 0, br,bg,bb);
    // Head
    drawPart({0, 1.50f, 0},   {0.30f,0.30f,0.30f}, 0, 0.85f,0.70f,0.55f);
    // Left arm
    drawPart({-0.30f, 1.0f, 0},{0.14f,0.55f,0.14f}, -legSwing, br,bg,bb);
    // Right arm (punch arm)
    drawPart({ 0.30f, 1.0f, 0.2f*punchArm},{0.14f,0.55f,0.14f}, punchArm*0.4f, br,bg,bb);
    // Left leg
    drawPart({-0.13f, 0.35f, 0},{0.15f,0.55f,0.15f}, legSwing, 0.1f,0.1f,0.5f);
    // Right leg
    drawPart({ 0.13f, 0.35f, 0},{0.15f,0.55f,0.15f},-legSwing, 0.1f,0.1f,0.5f);
}
