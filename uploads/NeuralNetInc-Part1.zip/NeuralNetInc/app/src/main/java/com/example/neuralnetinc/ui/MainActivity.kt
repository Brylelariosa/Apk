package com.example.neuralnetinc.ui

import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.neuralnetinc.NeuralNetApp
import com.example.neuralnetinc.data.GameState
import com.example.neuralnetinc.databinding.ActivityMainBinding
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.text.DecimalFormat

/**
 * MainActivity — thin UI layer.
 *
 * Responsibilities:
 *  - Inflate layout via ViewBinding.
 *  - Observe GameState StateFlow and call updateUI().
 *  - Trigger save on pause (lifecycle-safe).
 *
 * No gameplay logic lives here — all logic is in ViewModel/engine.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val viewModel: MainViewModel by viewModels {
        MainViewModel.Factory((application as NeuralNetApp).repository)
    }

    // Formatters reused across frames
    private val moneyFmt   = DecimalFormat("#,##0.00")
    private val computeFmt = DecimalFormat("#,##0.000")
    private val statFmt    = DecimalFormat("#,##0.00")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        observeGameState()
    }

    private fun observeGameState() {
        lifecycleScope.launch {
            viewModel.gameState.collectLatest { state ->
                state?.let { updateUI(it) }
            }
        }
    }

    private fun updateUI(state: GameState) {
        binding.tvMoney.text          = "\$${moneyFmt.format(state.money)}"
        binding.tvTotalCompute.text   = "${computeFmt.format(state.totalCompute)} GF"
        binding.tvComputePerSec.text  = "${computeFmt.format(state.computePerSecond)} GF/s"
        binding.tvElectricity.text    = "${statFmt.format(state.electricity)} kW"
        binding.tvCooling.text        = "${statFmt.format(state.cooling)}°C"
        binding.tvResearch.text       = "${computeFmt.format(state.researchPoints)} RP"
    }

    override fun onPause() {
        super.onPause()
        viewModel.saveGame()
    }
}
