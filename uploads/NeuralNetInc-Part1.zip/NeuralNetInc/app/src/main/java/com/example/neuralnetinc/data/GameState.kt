package com.example.neuralnetinc.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Core game state persisted in Room.
 *
 * Fields:
 *  - money             : Player's USD balance.
 *  - totalCompute      : Cumulative compute generated (GFLOPS).
 *  - computePerSecond  : Current compute rate (GFLOPS/s). Driven by hardware in Part 2.
 *  - electricity       : Available power budget (kW). Hardware consumes this.
 *  - cooling           : Cooling capacity (°C limit). Excess heat slows compute.
 *  - researchPoints    : Unlocks upgrades and new hardware.
 *  - lastSavedTime     : Unix ms timestamp used for offline progress.
 */
@Entity(tableName = "game_state")
data class GameState(

    @PrimaryKey
    val id: Int = 1,

    val money: Double = 0.0,

    val totalCompute: Double = 0.0,

    /** Base value 1.0 GF/s; multiplied by hardware in Part 2. */
    val computePerSecond: Double = 1.0,

    /** Starting power budget; expanded by buying power plants in Part 2. */
    val electricity: Double = 100.0,

    /** Starting cooling capacity; limits heat in Part 2. */
    val cooling: Double = 100.0,

    val researchPoints: Double = 0.0,

    val lastSavedTime: Long = System.currentTimeMillis()
)
