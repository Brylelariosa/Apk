package com.example.neuralnetinc.engine

import com.example.neuralnetinc.data.GameState
import com.example.neuralnetinc.systems.EconomyManager

/**
 * TickSystem — processes one game tick.
 * Single responsibility: delegate to EconomyManager and track tick count.
 *
 * Keeping tick logic separate from the loop makes it trivial to
 * add tick modifiers (speed boosts, prestige multipliers) later.
 */
class TickSystem(private val economyManager: EconomyManager) {

    private var tickCount = 0

    /**
     * Process one tick and return the updated GameState.
     * Called every TICK_INTERVAL_MS by GameLoop.
     */
    fun tick(currentState: GameState): GameState {
        tickCount++
        return economyManager.applyTick(currentState)
    }

    /**
     * Returns true when an auto-save should trigger.
     * Formula: tickCount % interval == 0
     */
    fun shouldAutoSave(interval: Int): Boolean =
        tickCount > 0 && tickCount % interval == 0

    fun resetTickCount() { tickCount = 0 }

    fun getTickCount(): Int = tickCount
}
