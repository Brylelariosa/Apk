package com.example.neuralnetinc.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.neuralnetinc.data.GameState
import com.example.neuralnetinc.engine.GameLoop
import com.example.neuralnetinc.engine.TickSystem
import com.example.neuralnetinc.repository.GameRepository
import com.example.neuralnetinc.systems.EconomyManager
import com.example.neuralnetinc.systems.SaveManager
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

/**
 * MainViewModel — single source of truth for the UI.
 *
 * Responsibilities:
 *  - Load game on creation (with offline progress).
 *  - Start/stop GameLoop tied to the ViewModel lifecycle.
 *  - Expose GameState as StateFlow for UI observation.
 *  - Trigger manual saves on pause.
 *
 * Does NOT contain any Android View or Context references.
 */
class MainViewModel(
    private val repository: GameRepository
) : ViewModel() {

    // ── Dependencies (manual DI) ──────────────────────────────────────────
    private val economyManager = EconomyManager()
    private val tickSystem     = TickSystem(economyManager)
    private val gameLoop       = GameLoop(tickSystem)
    private val saveManager    = SaveManager(repository, economyManager)

    // ── Public state ──────────────────────────────────────────────────────
    /** Observed by MainActivity. Null until the first load completes. */
    val gameState: StateFlow<GameState?> = gameLoop.gameState

    // ── Init ──────────────────────────────────────────────────────────────
    init {
        loadAndStart()
    }

    private fun loadAndStart() {
        viewModelScope.launch {
            val state = saveManager.loadGame()
            gameLoop.start(
                scope        = viewModelScope,
                initialState = state,
                onAutoSave   = { latest -> saveManager.saveGame(latest) }
            )
        }
    }

    // ── Public actions ────────────────────────────────────────────────────

    /** Called from Activity.onPause to ensure state is persisted. */
    fun saveGame() {
        viewModelScope.launch {
            gameState.value?.let { saveManager.saveGame(it) }
        }
    }

    /**
     * Used by Part 2 to inject a modified state after a purchase
     * without interrupting the game loop.
     */
    fun applyStateChange(newState: GameState) {
        gameLoop.updateState(newState)
    }

    // ── Cleanup ───────────────────────────────────────────────────────────
    override fun onCleared() {
        super.onCleared()
        gameLoop.stop()
    }

    // ── Factory ───────────────────────────────────────────────────────────
    class Factory(private val repository: GameRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T =
            MainViewModel(repository) as T
    }
}
