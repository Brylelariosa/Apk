package com.example.neuralnetinc.systems

import com.example.neuralnetinc.data.GameState
import com.example.neuralnetinc.util.Constants

/**
 * EconomyManager — all resource generation formulas live here.
 *
 * Core tick formulas (all linear in Part 1; exponential scaling via
 * hardware multipliers will be added in Part 2):
 *
 *   compute  += computePerSecond                          (GF/s)
 *   money    += computePerSecond * BASE_MONEY_PER_COMPUTE ($/s)
 *   research += BASE_RESEARCH_PER_TICK                    (RP/s)
 *
 * Separation principle: this class is pure logic — no Android imports,
 * no coroutines. Easy to unit-test.
 */
class EconomyManager {

    // ── Per-tick generators ───────────────────────────────────────────────

    /**
     * Money gained per tick.
     * Formula: computePerSecond * BASE_MONEY_PER_COMPUTE
     * Rationale: selling compute time to clients.
     */
    fun moneyPerTick(state: GameState): Double =
        state.computePerSecond * Constants.BASE_MONEY_PER_COMPUTE

    /**
     * Research points gained per tick.
     * Flat rate for now; Part 2 adds research hardware multiplier.
     */
    fun researchPerTick(@Suppress("UNUSED_PARAMETER") state: GameState): Double =
        Constants.BASE_RESEARCH_PER_TICK

    // ── Tick application ──────────────────────────────────────────────────

    /**
     * Apply one game tick. Returns a new immutable GameState.
     * Called by TickSystem every TICK_INTERVAL_MS.
     */
    fun applyTick(state: GameState): GameState = state.copy(
        totalCompute  = state.totalCompute  + state.computePerSecond,
        money         = state.money         + moneyPerTick(state),
        researchPoints = state.researchPoints + researchPerTick(state)
    )

    // ── Offline progress ──────────────────────────────────────────────────

    /**
     * Calculates resources earned while the app was closed.
     * Uses direct multiplication (O(1)) rather than a tick loop.
     * Capped at OFFLINE_CAP_SECONDS to prevent abuse.
     *
     * Formula per resource:
     *   gained = rate * min(elapsed, CAP)
     */
    fun applyOfflineProgress(state: GameState): GameState {
        val elapsed = ((System.currentTimeMillis() - state.lastSavedTime) / 1000L)
            .coerceIn(0L, Constants.OFFLINE_CAP_SECONDS)

        if (elapsed == 0L) return state

        val e = elapsed.toDouble()
        return state.copy(
            totalCompute   = state.totalCompute   + state.computePerSecond * e,
            money          = state.money          + moneyPerTick(state)    * e,
            researchPoints = state.researchPoints + researchPerTick(state) * e
        )
    }

    // ── Scaling helpers (used by Part 2 hardware costs) ───────────────────

    /**
     * Exponential cost formula: baseCost * scaleFactor^owned
     * e.g. first GPU costs 50, scale 1.15 → 10th costs ~202.
     */
    fun hardwareCost(baseCost: Double, scaleFactor: Double, owned: Int): Double =
        baseCost * Math.pow(scaleFactor, owned.toDouble())

    /**
     * Compute per second contributed by N units of a hardware tier.
     * Linear for now; upgrade multipliers applied on top in Part 2.
     */
    fun computeContribution(computePerUnit: Double, count: Int): Double =
        computePerUnit * count
}
