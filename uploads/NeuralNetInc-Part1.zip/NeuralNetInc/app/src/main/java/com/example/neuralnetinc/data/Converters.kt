package com.example.neuralnetinc.data

import androidx.room.TypeConverter

/**
 * Room TypeConverters — reserved for complex types in future parts.
 * (e.g. List<Hardware>, Map<String, Int>)
 *
 * NOTE: Room handles all primitive types (Long, Int, Double, String, Boolean)
 * natively. Only add @TypeConverter methods here for types Room cannot handle
 * on its own (e.g. custom enums, serialized lists, dates as strings).
 */
class Converters {
    // Converters will be added in Part 2 for hardware lists and enums.
}
