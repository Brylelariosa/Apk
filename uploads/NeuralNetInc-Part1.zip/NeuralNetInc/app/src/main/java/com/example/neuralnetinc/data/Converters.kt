package com.example.neuralnetinc.data

import androidx.room.TypeConverter

/**
 * Room TypeConverters — reserved for complex types in future parts.
 * (e.g. List<Hardware>, Map<String, Int>)
 */
class Converters {

    @TypeConverter
    fun longToLong(value: Long?): Long? = value

    @TypeConverter
    fun longFromLong(value: Long?): Long? = value
}
