package com.example.neuralnetinc.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.neuralnetinc.util.Constants

/**
 * Room database — single source of truth.
 * Version 1: only GameState table.
 * Increment version + add migration when schema changes.
 */
@Database(
    entities = [GameState::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun gameStateDao(): GameStateDao

    companion object {

        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    Constants.DB_NAME
                ).build().also { INSTANCE = it }
            }
        }
    }
}
