// ============================================================================
// HZCM v4 — World.cpp
// ============================================================================
#include "World.h"
#include <android/log.h>
#include <algorithm>
#include <cmath>
#include <climits>

#define TAG  "HZCMWorld"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

// ─────────────────────────────────────────────────────────────────────────────
World::World() : m_noise(0) {}

World::~World() {
    m_jobQueue.requestStop();
    for (auto& t : m_workers)
        if (t.joinable()) t.join();
}

// ── Worker main loop ──────────────────────────────────────────────────────────
void World::workerLoop() {
    WorldJob job;
    // popWait blocks up to 20 ms then retries; returns false only when
    // the queue is stopped AND empty — our exit condition.
    while (m_jobQueue.popWait(job, 20)) {
        executeJob(job);
    }
}

// ── Job dispatcher ─────────────────────────────────────────────────────────────
void World::executeJob(const WorldJob& job) {
    switch (job.kind) {
        case JobKind::CHUNK_BUILD:
            workerChunkBuild(job.chunk);
            break;
        case JobKind::CLUSTER_REBUILD:
            workerClusterRebuild(job.chunk, job.ci);
            break;
        case JobKind::NEIGHBOUR_FLUSH:
            workerNeighbourFlush(job.flushCX, job.flushCZ);
            break;
    }
}

// ── Enqueue helpers ────────────────────────────────────────────────────────────
void World::enqueueChunkBuild(Chunk* chunk) {
    WorldJob job{};
    job.kind  = JobKind::CHUNK_BUILD;
    job.world = this;
    job.chunk = chunk;
    job.ci    = -1;
    if (!m_jobQueue.push(job))
        LOGE("Job queue full — CHUNK_BUILD dropped (%d,%d)", chunk->cx, chunk->cz);
}

void World::enqueueClusterRebuild(Chunk* chunk, int ci) {
    WorldJob job{};
    job.kind  = JobKind::CLUSTER_REBUILD;
    job.world = this;
    job.chunk = chunk;
    job.ci    = ci;
    if (!m_jobQueue.push(job))
        LOGE("Job queue full — CLUSTER_REBUILD dropped");
}

void World::enqueueNeighbourFlush(int cx, int cz) {
    WorldJob job{};
    job.kind    = JobKind::NEIGHBOUR_FLUSH;
    job.world   = this;
    job.chunk   = nullptr;
    job.ci      = -1;
    job.flushCX = cx;
    job.flushCZ = cz;
    if (!m_jobQueue.push(job))
        LOGE("Job queue full — NEIGHBOUR_FLUSH dropped");
}

// ── Worker implementations ────────────────────────────────────────────────────

void World::workerChunkBuild(Chunk* chunk) {
    // Guard: if chunk was evicted before we even started, skip entirely
    if (chunk->evicted.load(std::memory_order_acquire)) return;
    chunk->inFlight.fetch_add(1, std::memory_order_acquire);

    int cx = chunk->cx, cz = chunk->cz;

    // BUG FIXED (v10 → v11): workerNeighbourFlush can now enqueue a
    // CHUNK_BUILD for a neighbour that is generated-but-not-yet-meshed.
    // Guard against running generate() a second time — terrain is already
    // correct; we only need the mesh step.
    if (!chunk->generated.load(std::memory_order_acquire)) {
        // Generate terrain voxels
        chunk->generate(m_noise);

        // Re-check eviction: might have been evicted during generate()
        if (chunk->evicted.load(std::memory_order_acquire)) {
            chunk->inFlight.fetch_sub(1, std::memory_order_release);
            return;
        }
    }

    // Grab neighbour pointers under shared lock
    const Chunk *nx, *px, *nz, *pz;
    {
        std::shared_lock<std::shared_mutex> rlk(m_chunksMtx);
        nx = getChunk(cx-1, cz); px = getChunk(cx+1, cz);
        nz = getChunk(cx, cz-1); pz = getChunk(cx, cz+1);
    }

    // 3. Mesh all 4 clusters
    for (int ci = 0; ci < CLUSTER_STACK; ++ci)
        chunk->buildClusterMesh(ci, nx, px, nz, pz);

    // Push in REVERSE order so that LIFO (end-of-vector) pop in updateGPU
    // processes ci=0 (ground) FIRST and ci=3 (tree-tops/sky) LAST.
    // Without this, ci=3 uploads first → floating tree canopy with no ground.
    {
        std::unique_lock<std::mutex> ulk(m_uploadMtx);
        for (int ci = CLUSTER_STACK - 1; ci >= 0; --ci)
            m_uploadQueue.push_back({ chunk, ci, chunk->clusterDirtyGen[ci] });
    }

    chunk->inFlight.fetch_sub(1, std::memory_order_release);

    // ── Race-condition guard ────────────────────────────────────────────────
    // If any neighbour that was null when we grabbed pointers above has since
    // generated, our border clusters used BLOCK_AIR for that side and are stale.
    // Enqueue CLUSTER_REBUILD for every affected cluster so the border faces
    // are corrected.  workerNeighbourFlush only triggers on READY/MESHED
    // neighbours, so this self-check is the only way to catch the race where
    // B completes and calls workerNeighbourFlush while A's clusters are DIRTY.
    {
        const Chunk *nx2, *px2, *nz2, *pz2;
        {
            std::shared_lock<std::shared_mutex> rlk2(m_chunksMtx);
            nx2 = getChunk(cx-1, cz); px2 = getChunk(cx+1, cz);
            nz2 = getChunk(cx, cz-1); pz2 = getChunk(cx, cz+1);
        }
        bool stale =
            (nx2 && nx2->generated.load(std::memory_order_acquire) && !nx) ||
            (px2 && px2->generated.load(std::memory_order_acquire) && !px) ||
            (nz2 && nz2->generated.load(std::memory_order_acquire) && !nz) ||
            (pz2 && pz2->generated.load(std::memory_order_acquire) && !pz);
        if (stale) {
            for (int ci2 = 0; ci2 < CLUSTER_STACK; ++ci2)
                enqueueClusterRebuild(chunk, ci2);
        }
    }

    // Remesh border clusters of existing neighbours
    workerNeighbourFlush(cx, cz);
}

void World::workerClusterRebuild(Chunk* chunk, int ci) {
    if (chunk->evicted.load(std::memory_order_acquire)) return;
    chunk->inFlight.fetch_add(1, std::memory_order_acquire);

    int cx = chunk->cx, cz = chunk->cz;
    const Chunk *nx, *px, *nz, *pz;
    {
        std::shared_lock<std::shared_mutex> rlk(m_chunksMtx);
        nx = getChunk(cx-1, cz); px = getChunk(cx+1, cz);
        nz = getChunk(cx, cz-1); pz = getChunk(cx, cz+1);
    }
    chunk->buildClusterMesh(ci, nx, px, nz, pz);

    if (!chunk->evicted.load(std::memory_order_acquire)) {
        std::unique_lock<std::mutex> ulk(m_uploadMtx);
        // Single cluster: order doesn't matter. Push normally.
        m_uploadQueue.push_back({ chunk, ci, chunk->clusterDirtyGen[ci] });
    }

    chunk->inFlight.fetch_sub(1, std::memory_order_release);
}

void World::workerNeighbourFlush(int cx, int cz) {
    // BUG FIXED (v10 → v11): old code only re-meshed neighbours in READY or
    // MESHED state.  A neighbour whose CHUNK_BUILD job had completed generate()
    // but not yet buildClusterMesh() — cluster state = DIRTY — was silently
    // skipped.  In that narrow window, neither this flush nor the neighbour's
    // own stale-check re-queued the rebuild, producing a permanent seam on the
    // shared border.
    //
    // Fix:  Collect two sets —
    //   • remesh: clusters already READY/MESHED that need a border correction.
    //   • initMesh: generated neighbours with ALL clusters still DIRTY/EMPTY,
    //     meaning their first full mesh hasn't happened yet.  Enqueue a
    //     CHUNK_BUILD for them so they pick up the now-generated neighbour
    //     (us) during their own mesh pass.  workerChunkBuild skips generate()
    //     if `generated` is already true, so this is safe against double-gen.
    static const int dirs[4][2] = {{-1,0},{1,0},{0,-1},{0,1}};
    std::vector<std::pair<Chunk*,int>> remesh;
    std::vector<Chunk*>                initMesh;
    {
        std::shared_lock<std::shared_mutex> rlk(m_chunksMtx);
        for (auto& d : dirs) {
            Chunk* nb = getChunk(cx + d[0], cz + d[1]);
            if (!nb || !nb->generated.load(std::memory_order_acquire)) continue;

            bool anyMeshed = false;
            for (int c2 = 0; c2 < CLUSTER_STACK; ++c2) {
                auto st = nb->clusterState[c2].load(std::memory_order_acquire);
                if (st == ClusterState::READY || st == ClusterState::MESHED) {
                    remesh.push_back({nb, c2});
                    anyMeshed = true;
                }
            }
            // All clusters are DIRTY/EMPTY but terrain is generated — the
            // neighbour's initial mesh is in-flight or hasn't been enqueued yet.
            // Trigger a build so it meshes with correct border data.
            if (!anyMeshed && !nb->evicted.load(std::memory_order_acquire)) {
                initMesh.push_back(nb);
            }
        }
    }
    for (auto& [nb, c2] : remesh)
        enqueueClusterRebuild(nb, c2);
    for (Chunk* nb : initMesh)
        enqueueChunkBuild(nb);
}

// ── Init ───────────────────────────────────────────────────────────────────────
void World::init(int seed) {
    m_noise = Noise(seed);

    {
        std::unique_lock<std::shared_mutex> wlk(m_chunksMtx);
        m_chunks.clear();
    }
    m_submitted.clear();
    m_pendingCandidates.clear();
    m_candidateIdx = 0;
    m_lastCamCX = INT_MIN;
    m_lastCamCZ = INT_MIN;
    m_lastRdGen = 0;

    int hw       = (int)std::thread::hardware_concurrency();
    int nThreads = std::max(2, std::min(3, hw - 1));
    LOGI("Starting %d worker threads (hw=%d)", nThreads, hw);
    for (int i = 0; i < nThreads; ++i)
        m_workers.emplace_back([this] { workerLoop(); });

    // Prime initial area
    update(0.f, 0.f, 64.f, 0.f, 0.f, 0.f, 1.f, 0.016f);
    LOGI("World init done (render distance=%d)", m_renderDist.getDistance());
}

// ── Effective radius ──────────────────────────────────────────────────────────
void World::refreshEffectiveRadius() {
    int   requested = m_renderDist.getDistance();
    float scale     = m_thermal.radiusScale();
    m_effectiveRadius = std::max(RenderDistanceSystem::MIN_DIST,
                                 (int)((float)requested * scale));
}

// ── Per-frame update ───────────────────────────────────────────────────────────
void World::update(float camX, float camZ, float camY,
                    float velX, float velZ,
                    float fwdX, float fwdZ, float dt)
{
    m_thermal.update(dt);
    m_scheduler.update(camX, camZ, camY, velX, velZ, fwdX, fwdZ);

    bool rdChanged = m_renderDist.pollChanged(m_lastRdGen);
    refreshEffectiveRadius();

    // Thermally-scaled radii
    float scale = m_thermal.radiusScale();
    auto  radii = m_renderDist.getRadii();
    int loadR   = std::max(RenderDistanceSystem::MIN_DIST,
                            (int)((float)radii.load * scale));
    int unloadR = std::max(loadR + 1,
                            (int)((float)radii.unload * scale));

    int camCX = (int)floorf(camX / (float)CHUNK_W);
    int camCZ = (int)floorf(camZ / (float)CHUNK_D);
    bool camMoved = (camCX != m_lastCamCX || camCZ != m_lastCamCZ);

    // ── Unload ────────────────────────────────────────────────────────────────
    if (camMoved || rdChanged) {
        std::vector<std::pair<ChunkKey, std::unique_ptr<Chunk>>> evicted;
        {
            std::unique_lock<std::shared_mutex> wlk(m_chunksMtx);
            for (auto it = m_chunks.begin(); it != m_chunks.end(); ) {
                int dx = std::abs(it->first.cx - camCX);
                int dz = std::abs(it->first.cz - camCZ);
                if (dx > unloadR || dz > unloadR) {
                    evictChunk(it->second.get());           // mark evicted + free GPU
                    m_submitted.erase({it->first.cx, it->first.cz});
                    evicted.push_back({it->first, std::move(it->second)});
                    it = m_chunks.erase(it);
                } else {
                    ++it;
                }
            }

            // BUG FIXED (v10 → v11): On render-distance change, also scrub any
            // m_submitted entries whose chunk is no longer in m_chunks.  This
            // can happen when the queue-full rollback path removes a chunk from
            // m_chunks between a rdChanged and its corresponding eviction pass
            // (the rollback does not erase from m_submitted because the entry
            // was never inserted, but a pathological multi-frame sequence could
            // leave the set pointing at a dead key).  The check is cheap and
            // makes the submitted set provably consistent after every RD event.
            if (rdChanged) {
                for (auto sit = m_submitted.begin(); sit != m_submitted.end(); ) {
                    if (m_chunks.find({sit->cx, sit->cz}) == m_chunks.end())
                        sit = m_submitted.erase(sit);
                    else
                        ++sit;
                }
            }
        }
        // Move evicted chunks to graveyard (deferred deletion — workers may still be reading)
        {
            std::lock_guard<std::mutex> glk(m_graveyardMtx);
            for (auto& [key, ptr] : evicted) {
                m_graveyard.push_back({ std::move(ptr), 4 }); // wait 4 frames
                enqueueNeighbourFlush(key.cx, key.cz);
            }
        }
    }

    // ── Rebuild sorted candidate list when necessary ───────────────────────────
    // Expensive at large RD (67k entries at RD=129) so only rebuild when
    // the camera chunk changes or render distance changes.
    if (camMoved || rdChanged) {
        m_lastCamCX = camCX;
        m_lastCamCZ = camCZ;
        m_pendingCandidates.clear();
        StreamScheduler::buildCandidates(camCX, camCZ, 0, loadR, m_pendingCandidates);

        // BUG FIXED (v10 → v11): Strip already-submitted chunks from the
        // candidate list before sorting.
        //
        // Old behaviour: m_pendingCandidates contained ALL O(RD²) chunks in
        // range.  The submission loop below advanced m_candidateIdx by 1 per
        // iteration regardless of whether the entry was skipped (already in
        // m_submitted).  With RD=7 that was ~289 skip-iterations per camera
        // move before a single new chunk could be submitted; with RD=20 it was
        // ~1764.  Because maxNew is capped (typically 8–32), those skips
        // consumed the entire per-frame budget, leaving new peripheral chunks
        // unsubmitted for (loadedCount / maxNew) additional frames.
        //
        // Fix: remove submitted entries once, here, so every slot in the
        // sorted list represents genuine unsubmitted work.  The 'continue'
        // guard inside the submission loop is kept as a safety net only.
        //
        // Correctness: m_submitted ⊆ m_chunks (eviction removes from both),
        // so this never discards a chunk that needs re-generation.
        {
            auto newEnd = std::remove_if(
                m_pendingCandidates.begin(), m_pendingCandidates.end(),
                [this](const ChunkPriority& cp) {
                    return m_submitted.count({cp.cx, cp.cz}) != 0;
                });
            m_pendingCandidates.erase(newEnd, m_pendingCandidates.end());
        }

        // Sort the filtered (new-chunks-only) list by priority.
        // With the Chebyshev-ring formula in StreamScheduler this now
        // guarantees strict nearest-first ordering across all render distances.
        m_scheduler.sortByPriority(m_pendingCandidates);
        m_candidateIdx = 0;
        m_visibility.markDirty();
    }

    // ── Submit unsubmitted chunks every frame (not only on camera move) ────────
    // This ensures a stationary player at any RD still loads all chunks.
    // maxNew scales with render distance so large RD loads faster.
    // Near chunks always have highest priority (sorted above).
    //
    // CRITICAL: cap maxNew to available queue space and only insert into
    // m_submitted AFTER a successful push.  The old code did:
    //
    //   m_submitted.insert(key);   <- always
    //   m_chunks[key] = ...;       <- always
    //   enqueueChunkBuild(ptr);    <- silently dropped when queue full
    //
    // A dropped push left a zombie chunk: in m_submitted (never retried) and
    // in m_chunks (DIRTY forever). With RD>=16 the 1024-slot ring filled in
    // ~16 frames causing slow loading and terrain missing after RD changes.
    {
        int queueFree = (int)JOB_RING_CAPACITY
                      - (int)m_jobQueue.approximateSize()
                      - 32;  // headroom for CLUSTER_REBUILD/NEIGHBOUR_FLUSH
        int maxNew = std::min(
            std::max(8, m_thermal.maxRebuildBudget()
                        * std::max(1, m_effectiveRadius / 8)),
            std::max(0, queueFree)
        );

        int submitted = 0;
        while (m_candidateIdx < (int)m_pendingCandidates.size()
               && submitted < maxNew)
        {
            int savedIdx = m_candidateIdx;
            const auto& cp = m_pendingCandidates[m_candidateIdx++];
            ChunkKey key{cp.cx, cp.cz};
            if (m_submitted.count(key)) continue;

            Chunk* ptr;
            {
                std::unique_lock<std::shared_mutex> wlk(m_chunksMtx);
                auto ch = std::make_unique<Chunk>(cp.cx, cp.cz);
                ptr = ch.get();
                m_chunks[key] = std::move(ch);
            }

            // Push inline so we can react to failure before touching m_submitted.
            WorldJob job{};
            job.kind  = JobKind::CHUNK_BUILD;
            job.world = this;
            job.chunk = ptr;
            job.ci    = -1;
            if (!m_jobQueue.push(job)) {
                // Queue unexpectedly full — undo the allocation, restore index,
                // and stop this frame so workers can drain before we push more.
                {
                    std::unique_lock<std::shared_mutex> wlk(m_chunksMtx);
                    m_chunks.erase(key);
                }
                m_candidateIdx = savedIdx;
                break;
            }

            // Only mark submitted once the job is safely in the ring.
            m_submitted.insert(key);
            ++submitted;
        }
    }

    // ── Rebuild HierarchicalVisibility when camera chunk changes ───────────────
    if (m_visibility.needsRebuild()) {
        m_visibility.rebuild(camCX, camCZ, camY, m_effectiveRadius,
            [this](int cx, int cz) { return surfaceHeightAt(cx, cz); });
    }
}

// ── GPU upload ─────────────────────────────────────────────────────────────────
void World::updateGPU() {
    m_mega.beginFrame();

    // ── Tick graveyard — delete chunks whose workers have all finished ─────────
    {
        std::lock_guard<std::mutex> glk(m_graveyardMtx);
        auto it = m_graveyard.begin();
        while (it != m_graveyard.end()) {
            it->frames--;
            // Safe to delete when countdown expired AND no worker is inside it
            if (it->frames <= 0 && it->chunk->inFlight.load(std::memory_order_acquire) == 0) {
                it = m_graveyard.erase(it);   // unique_ptr destructor runs here
            } else {
                ++it;
            }
        }
    }

    // Scale upload budget with render distance (mirrors submit-budget scaling).
    // Do NOT round to CLUSTER_STACK — the upload queue is a flat list of
    // individual cluster tasks (mix of 4-task chunk builds AND 1-task cluster
    // rebuilds).  Rounding to 4 would silently discard single-cluster rebuild
    // tasks when the queue total isn't a multiple of 4, leaving those clusters
    // in MESHED state forever and hiding whole chunks via the render guard.
    int rdScale = std::max(1, m_effectiveRadius / 8);
    int budget  = m_thermal.maxUploadBudget() * CLUSTER_STACK * rdScale;

    std::vector<UploadTask> tasks;
    {
        std::unique_lock<std::mutex> ulk(m_uploadMtx);
        int n = std::min(budget, (int)m_uploadQueue.size());
        if (n > 0) {
            tasks.assign(m_uploadQueue.end() - n, m_uploadQueue.end());
            m_uploadQueue.resize(m_uploadQueue.size() - n);
        }
    }

    // Iterate in REVERSE so that ci=0 (ground) is processed before ci=3 (tree-tops).
    // Tasks were pushed in reverse order (3,2,1,0) so the vector ends with ci=0;
    // reversing the iteration restores bottom-up upload order and prevents the
    // "floating canopy with no ground" artifact when the upload budget < 4.
    for (int ti = (int)tasks.size() - 1; ti >= 0; --ti) {
        auto& task = tasks[ti];
        Chunk*   ch = task.chunk;
        int      ci = task.ci;

        // Skip if chunk was evicted while this task was queued
        if (ch->evicted.load(std::memory_order_acquire)) continue;

        // Stale check: cluster was re-dirtied after enqueue
        // A newer CLUSTER_REBUILD will have already re-queued it.
        if (ch->clusterState[ci].load(std::memory_order_acquire) != ClusterState::MESHED)
            continue;
        if (ch->clusterDirtyGen[ci] != task.dirtyGen)
            continue;

        std::lock_guard<std::mutex> lk(ch->clusterMutex[ci]);
        auto& faces  = ch->clusterFaces[ci];
        uint32_t nFaces = (uint32_t)faces.size();

        // Free old GPU slot first
        if (ch->clusterGPUOffset[ci] != MEGA_INVALID) {
            m_mega.free(ch->clusterGPUOffset[ci], ch->clusterFaceCount[ci]);
            ch->clusterGPUOffset[ci] = MEGA_INVALID;
            ch->clusterFaceCount[ci] = 0;
        }

        if (nFaces > 0) {
            uint32_t offset = m_mega.alloc(nFaces);
            if (offset != MEGA_INVALID) {
                if (!m_mega.upload(offset, faces.data(), nFaces)) {
                    // Ring staging full this frame — return to queue for next frame
                    m_mega.free(offset, nFaces);
                    std::unique_lock<std::mutex> ulk(m_uploadMtx);
                    m_uploadQueue.push_back(task);
                    continue;
                }
                ch->clusterGPUOffset[ci] = offset;
                ch->clusterFaceCount[ci] = nFaces;
            } else {
                LOGE("PageAllocator full! used=%u total=%u",
                     m_mega.usedFaces(), m_mega.totalFaces());
            }
        }

        faces.clear();
        faces.shrink_to_fit();
        ch->clusterState[ci].store(ClusterState::READY, std::memory_order_release);

        // Track first-time uploads per cluster.  uploadedClusterCount is
        // GL-thread-only so no atomic/lock needed.  We only increment when
        // the cluster had no prior GPU allocation (MEGA_INVALID before alloc),
        // meaning this is the very first successful upload for this cluster.
        // Once uploadedClusterCount == CLUSTER_STACK the chunk becomes visible.
        if (ch->uploadedClusterCount < CLUSTER_STACK) {
            // We freed the old slot and re-allocated above; if the new offset
            // is valid OR faces were zero (empty cluster, offset stays INVALID
            // but cluster is legitimately empty), count it as "first uploaded".
            // The "was MEGA_INVALID before this task ran" check: we can't read
            // that retroactively, so instead we count every cluster we process
            // that hasn't been counted yet.  Use the cluster index as a one-bit
            // seen-flag via a bitmask stored on the chunk.
            if (!(ch->clusterFirstUploadMask & (1u << ci))) {
                ch->clusterFirstUploadMask |= (1u << ci);
                ++ch->uploadedClusterCount;
            }
        }
    }

    // One glMapBufferRange + fence for all staged uploads
    m_mega.flushUploads();
}

// ── Gather visible clusters + sorted draw ─────────────────────────────────────
void World::gatherAndDraw(const Frustum& frustum, GLint originUniformLoc) {
    m_drawBatcher.beginFrame();

    int visible = 0;
    std::shared_lock<std::shared_mutex> rlk(m_chunksMtx);

    for (auto& kv : m_chunks) {
        Chunk* ch = kv.second.get();

        // 1. HierarchicalVisibility chunk-level cull
        if (!m_visibility.isChunkVisible(ch->cx, ch->cz)) continue;

        // 1b. First-upload guard — hide the chunk until every cluster has been
        //     uploaded to the GPU at least once.  uploadedClusterCount is a
        //     GL-thread-only monotonic counter incremented in updateGPU the
        //     first time each cluster's mesh is pushed to the MegaBuffer.
        //     Because it only ever increases and is written on the same thread
        //     that reads it here, there is no race.  This replaces the old
        //     per-cluster ClusterState scan which raced with workerClusterRebuild
        //     setting clusters back to MESHED, permanently keeping the flag
        //     false and hiding chunks that should have been visible.
        if (ch->uploadedClusterCount < CLUSTER_STACK) continue;

        // 1c. Neighbour-generation guard — prevents floating-island artifacts.
        //
        // BUG FIXED (v10 → v11):
        // When chunk A is meshed before any of its cardinal neighbours exist,
        // buildClusterMesh uses BLOCK_AIR for those sides.  The resulting mesh
        // has visible faces on every border plane — the "floating island" look.
        // workerNeighbourFlush queues a rebuild once each neighbour generates,
        // but between A's first upload and that rebuild completing, A is already
        // drawn with the incorrect mesh (sometimes for many frames, especially
        // at larger render distances where the old priority sort loaded far
        // forward chunks before adjacent ones).
        //
        // Fix: defer drawing until every cardinal neighbour that currently
        // EXISTS in m_chunks has finished terrain generation.  Neighbours that
        // are out-of-range or not yet submitted (getChunk returns null) are
        // treated as air and never block rendering.  Once all present neighbours
        // have generated, the workerNeighbourFlush-triggered rebuild will have
        // corrected the border mesh and the chunk appears seamlessly connected.
        //
        // m_chunksMtx shared lock is already held by the outer scope, so
        // getChunk is safe without a second lock acquisition.
        {
            static const int CDIRS[4][2] = {{-1,0},{1,0},{0,-1},{0,1}};
            bool waitingForNeighbour = false;
            for (int d = 0; d < 4; ++d) {
                const Chunk* nb = getChunk(ch->cx + CDIRS[d][0],
                                           ch->cz + CDIRS[d][1]);
                if (nb && !nb->generated.load(std::memory_order_acquire)) {
                    waitingForNeighbour = true;
                    break;
                }
            }
            if (waitingForNeighbour) continue;
        }

        // 2. Frustum cull
        float mnX, mnY, mnZ, mxX, mxY, mxZ;
        ch->getAABB(mnX, mnY, mnZ, mxX, mxY, mxZ);
        if (!frustum.testAABB({mnX,mnY,mnZ}, {mxX,mxY,mxZ})) continue;

        for (int ci = 0; ci < CLUSTER_STACK; ++ci) {
            // 3. Per-cluster visibility (sky / underground)
            if (!m_visibility.isVisible(ch->cx, ch->cz, ci)) continue;

            // Accept both READY and MESHED: a MESHED cluster is mid-rebuild
            // but its GPU allocation from the previous mesh is still valid —
            // keep drawing old data so the face never vanishes between the
            // "neighbour flush" rebuild and the next GPU upload.
            ClusterState cst = ch->clusterState[ci].load(std::memory_order_acquire);
            if (cst != ClusterState::READY && cst != ClusterState::MESHED)
                continue;

            uint32_t offset = ch->clusterGPUOffset[ci];
            uint32_t count  = ch->clusterFaceCount[ci];
            if (offset == MEGA_INVALID || count == 0) continue;

            m_drawBatcher.submit(
                ch->clusterWorldX(ci),
                ch->clusterWorldY(ci),
                ch->clusterWorldZ(ci),
                offset, count);
            ++visible;
        }
    }
    m_lastVisibleDraws = visible;

    // Sort by mega-offset → sequential VBO reads → driver prefetch wins
    m_drawBatcher.sort();
    m_drawBatcher.issueDraws(originUniformLoc);
}

// ── Evict ─────────────────────────────────────────────────────────────────────
// MUST be called while holding the write lock on m_chunksMtx.
// We mark `evicted` FIRST (so any in-flight worker stops writing),
// release GPU slots, then hand ownership to the graveyard for deferred deletion.
// The unique_ptr is moved out of m_chunks by the caller AFTER this call.
void World::evictChunk(Chunk* chunk) {
    // Signal workers to abandon this chunk immediately
    chunk->evicted.store(true, std::memory_order_release);

    // Release GPU slots (GL thread — safe here)
    for (int ci = 0; ci < CLUSTER_STACK; ++ci) {
        if (chunk->clusterGPUOffset[ci] != MEGA_INVALID) {
            m_mega.free(chunk->clusterGPUOffset[ci], chunk->clusterFaceCount[ci]);
            chunk->clusterGPUOffset[ci] = MEGA_INVALID;
            chunk->clusterFaceCount[ci] = 0;
        }
        chunk->clusterState[ci].store(ClusterState::EMPTY, std::memory_order_release);
    }
}

// ── Surface height (for HierarchicalVisibility) ────────────────────────────────
int World::surfaceHeightAt(int cx, int cz) const {
    // Caller holds no lock — take shared briefly
    std::shared_lock<std::shared_mutex> rlk(m_chunksMtx);
    const Chunk* ch = getChunk(cx, cz);
    if (!ch || !ch->generated.load(std::memory_order_acquire)) return 40;
    for (int y = CHUNK_H - 1; y >= 0; --y)
        if (ch->getBlock(8, y, 8) != BLOCK_AIR) return y;
    return 0;
}

// ── Accessors ─────────────────────────────────────────────────────────────────
Chunk* World::getChunk(int cx, int cz) const {
    auto it = m_chunks.find({cx, cz});
    return it != m_chunks.end() ? it->second.get() : nullptr;
}

uint8_t World::getBlock(int wx, int wy, int wz) const {
    if (wy < 0 || wy >= CHUNK_H) return BLOCK_AIR;
    int cx = (int)floorf((float)wx / CHUNK_W);
    int cz = (int)floorf((float)wz / CHUNK_D);
    int lx = wx - cx * CHUNK_W;
    int lz = wz - cz * CHUNK_D;
    std::shared_lock<std::shared_mutex> rlk(m_chunksMtx);
    const Chunk* ch = getChunk(cx, cz);
    return ch ? ch->getBlock(lx, wy, lz) : BLOCK_AIR;
}

int World::getChunkCount() const {
    std::shared_lock<std::shared_mutex> rlk(m_chunksMtx);
    return (int)m_chunks.size();
}
