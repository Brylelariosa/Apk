# HZCM v4 — Engineering Change Log (v10 → v11)

## Bug Fixes — 6 targeted patches across 2 files

---

### Fix 1 · `StreamScheduler.h` — Priority sort violated ring ordering → far chunks loaded before nearby ones

**Root cause:** `sortByPriority` computed distance from the *lookahead* position
(`camX + smoothVel * 2.5 s`) and used `priority = 1/dist + 0.5 * align`.
With any non-zero velocity the lookahead sits far ahead of the camera, so a
chunk at Chebyshev ring 10 directly in front could have a *smaller*
lookahead-distance than a chunk at ring 2 behind the player, giving it higher
priority.  Result: far-forward chunks loaded before adjacent ones, leaving large
"nearby gaps" in terrain and causing the secondary island / seam bugs below to
persist for many more frames than necessary.

**Fix:** Two-part change to `sortByPriority`:

1. **Chebyshev ring as primary key** — `1e6 / (chebRing + 1)` dominates for
   every ring 0..200, guaranteeing ring N always beats ring N+1 regardless of
   direction bias.  (Gap between consecutive rings > `FORWARD_BIAS = 0.5` for
   all N ≤ 1413, safely covering `RD_MAX = 200`.)

2. **Direction alignment as sub-ring tiebreaker** — computed from the actual
   camera forward vector to the chunk centre; *not* from the lookahead distance.
   Lookahead velocity smoothing is retained for jitter reduction but no longer
   distorts the ring ordering.

```cpp
// Before (broken — lookahead distance as primary):
float dx = cx - lookX, dz = cz - lookZ;
float dist = sqrtf(dx*dx + dz*dz) + 0.001f;
cp.priority = (1.f / dist) + FORWARD_BIAS * align;

// After (fixed — Chebyshev ring primary, direction secondary):
int cheb = std::max(std::abs(cp.cx - camCX), std::abs(cp.cz - camCZ));
cp.priority = 1000000.f / (float)(cheb + 1) + FORWARD_BIAS * align;
```

---

### Fix 2 · `World.cpp` `update()` — Candidate list wasted per-frame budget on already-submitted entries → slow peripheral loading

**Root cause:** `m_pendingCandidates` was built from the full O(RD²) square of
chunks including every already-loaded one.  The submission loop advanced
`m_candidateIdx` by 1 whether it submitted or skipped.  At RD=7 (~289 chunks),
each camera-chunk move burned ~289 `continue` iterations before touching a new
chunk; at RD=20 (~1764 chunks) this ballooned to ~1560 skips.  With `maxNew`
capped at 8–32, new peripheral chunks waited `(loadedCount / maxNew)` extra
frames to be submitted — compounding the priority bug above.

**Fix:** After `buildCandidates` and before `sortByPriority`, remove every entry
already in `m_submitted` via `std::remove_if`.  The remaining list contains only
unsubmitted work; every slot the submission loop visits is a genuine new chunk.

```cpp
auto newEnd = std::remove_if(
    m_pendingCandidates.begin(), m_pendingCandidates.end(),
    [this](const ChunkPriority& cp) {
        return m_submitted.count({cp.cx, cp.cz}) != 0;
    });
m_pendingCandidates.erase(newEnd, m_pendingCandidates.end());
// sort AFTER filter so priority order is over new chunks only
m_scheduler.sortByPriority(m_pendingCandidates);
```

Correctness: `m_submitted ⊆ m_chunks` at all times (eviction removes from
both), so this filter never discards a chunk that needs re-generation.

---

### Fix 3 · `World.cpp` `workerNeighbourFlush()` — DIRTY-state neighbours silently skipped → permanent border seams

**Root cause:** `workerNeighbourFlush` only enqueued `CLUSTER_REBUILD` for
neighbours in `READY` or `MESHED` state.  If a neighbour had called
`generate()` (setting `generated = true`) but its own `CHUNK_BUILD` job had not
yet reached `buildClusterMesh()`, its clusters were still `DIRTY`.  The flush
skipped them silently.  The neighbour's later stale-check also missed the race
(it compared pointers captured before its own `generate()` completed, not after).
Result: a narrow but reproducible window where a border seam was never corrected.

**Fix:** Collect two work-sets inside the shared lock:

- `remesh` — existing `READY`/`MESHED` clusters (border correction, unchanged).
- `initMesh` — generated neighbours with ALL clusters in `DIRTY`/`EMPTY` state,
  meaning their first mesh hasn't happened yet.  Enqueue a `CHUNK_BUILD` so they
  mesh with correct data from the now-available neighbour.

```cpp
if (!anyMeshed && !nb->evicted.load(std::memory_order_acquire))
    initMesh.push_back(nb);
// ...
for (Chunk* nb : initMesh)
    enqueueChunkBuild(nb);  // safe: see Fix 4
```

---

### Fix 4 · `World.cpp` `workerChunkBuild()` — Re-entering generate() on an already-generated chunk

**Root cause (new, introduced by Fix 3):** `workerNeighbourFlush` can now
enqueue `CHUNK_BUILD` for a chunk that is already generated but not yet meshed.
The old `workerChunkBuild` called `chunk->generate()` unconditionally, which
would overwrite existing block data and reset cluster states.

**Fix:** Guard `generate()` with a `!chunk->generated.load()` check.  If the
terrain is already present, skip straight to `buildClusterMesh()` using the
current (now-available) neighbours.

```cpp
if (!chunk->generated.load(std::memory_order_acquire)) {
    chunk->generate(m_noise);
    if (chunk->evicted.load(std::memory_order_acquire)) { ... return; }
}
// fall through to buildClusterMesh() in all cases
```

---

### Fix 5 · `World.cpp` `gatherAndDraw()` — Floating-island rendering before border mesh is corrected

**Root cause:** A chunk became visible (uploadedClusterCount == CLUSTER_STACK)
immediately after its first GPU upload, even when its initial mesh was built with
BLOCK_AIR on one or more sides (neighbours didn't exist yet).  The incorrect mesh
— visible faces on every border plane — produced the "floating island" look.
`workerNeighbourFlush` eventually corrects the mesh, but the old priority sort
(Fix 1) delayed neighbour generation, stretching the artifact window to tens of
seconds at larger render distances.

**Fix:** After the existing `uploadedClusterCount` guard, add a
*neighbour-generation guard*: if any cardinal neighbour exists in `m_chunks` but
has not yet set `generated = true`, skip drawing this chunk.  The shared lock is
already held, making `getChunk` safe with zero extra locking overhead.

```cpp
static const int CDIRS[4][2] = {{-1,0},{1,0},{0,-1},{0,1}};
bool waitingForNeighbour = false;
for (int d = 0; d < 4; ++d) {
    const Chunk* nb = getChunk(ch->cx + CDIRS[d][0], ch->cz + CDIRS[d][1]);
    if (nb && !nb->generated.load(std::memory_order_acquire)) {
        waitingForNeighbour = true; break;
    }
}
if (waitingForNeighbour) continue;
```

Neighbours outside load range (null) are treated as air and never block
rendering; edge-of-world chunks are therefore never permanently hidden.

---

### Fix 6 · `World.cpp` `update()` — Stale `m_submitted` entries after render-distance change → missing chunks

**Root cause:** The queue-full rollback path in the submission loop removed a
chunk from `m_chunks` but could not remove it from `m_submitted` (the entry is
only inserted *after* a successful push).  In pathological multi-frame sequences
— queue full, RD change, resubmission attempted — `m_submitted` could contain a
key that no longer had a corresponding entry in `m_chunks`.  On the next
candidate rebuild the key was filtered as "already submitted", silently
preventing re-submission of that chunk indefinitely.

**Fix:** Inside the write-lock scope of the unload pass, when `rdChanged`, scan
`m_submitted` and erase any key absent from `m_chunks`.  This runs O(loaded
chunks) once per RD change event — a rare operation — and makes the two
structures provably consistent at every render-distance boundary.

```cpp
if (rdChanged) {
    for (auto sit = m_submitted.begin(); sit != m_submitted.end(); ) {
        if (m_chunks.find({sit->cx, sit->cz}) == m_chunks.end())
            sit = m_submitted.erase(sit);
        else
            ++sit;
    }
}
```

---

## Files changed

| File | Changes |
|------|---------|
| `core/hzcm/StreamScheduler.h` | Fix 1 — `sortByPriority` priority formula |
| `core/World.cpp` | Fixes 2–6 — candidate filter, neighbour flush, generate guard, draw guard, RD sync |

No API surface, shader, data-layout, or platform changes.
