package com.hzcm.duelforge.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hzcm.duelforge.model.*

/** Fixed card dimensions used in the hand row and small previews. */
val CardWidth  = 56.dp
val CardHeight = 80.dp

/**
 * Animated wrapper for a field zone slot.
 * When [fillSlot] = true the card fills whatever space its parent provides
 * (use this for field zones with weight-based rows).
 * When false, the card uses the fixed [CardWidth]×[CardHeight].
 */
@Composable
fun AnimatedCardSlot(
    instance: CardInstance?,
    modifier: Modifier = Modifier,
    fillSlot: Boolean = false,
    revealFaceDown: Boolean = false,
    selected: Boolean = false,
    onClick: (() -> Unit)? = null
) {
    AnimatedContent(
        targetState = instance,
        modifier    = modifier,
        transitionSpec = {
            (fadeIn(tween(240)) + scaleIn(initialScale = 0.6f, animationSpec = tween(240)))
                .togetherWith(fadeOut(tween(130)) + scaleOut(targetScale = 0.75f, animationSpec = tween(130)))
        },
        contentKey = { it?.instanceId }
    ) { inst ->
        CardView(
            instance       = inst,
            fillSlot       = fillSlot,
            revealFaceDown = revealFaceDown,
            selected       = selected,
            onClick        = onClick
        )
    }
}

/**
 * Renders one card zone.
 *
 * When [fillSlot] = true (field zones): fills the full space provided by the
 * parent layout. Defense cards are shown portrait with a "DEF" badge — no slot
 * widening needed, keeping the grid uniform.
 *
 * When [fillSlot] = false (hand, preview): uses fixed [CardWidth]×[CardHeight]
 * and defense cards rotate 90° (their displayed width expands to [CardHeight]).
 */
@Composable
fun CardView(
    instance: CardInstance?,
    modifier: Modifier = Modifier,
    fillSlot: Boolean = false,
    revealFaceDown: Boolean = false,
    selected: Boolean = false,
    onClick: (() -> Unit)? = null
) {
    val isDefense = instance != null &&
        instance.card.isMonster &&
        instance.battlePosition == BattlePosition.DEFENSE

    // In fill-slot mode we never widen the slot; defense is shown portrait + badge.
    val slotWidth = if (!fillSlot && isDefense) CardHeight else CardWidth

    val baseMod = if (fillSlot)
        modifier.fillMaxSize()
    else
        modifier.size(slotWidth, CardHeight)

    val outerMod = baseMod.let { m -> if (onClick != null) m.clickable { onClick() } else m }

    if (instance == null) {
        Box(
            modifier = outerMod
                .background(Color(0xFF0D1C2E), RoundedCornerShape(6.dp))
                .border(1.dp, Color(0xFF1E3050), RoundedCornerShape(6.dp))
        ) {}
        return
    }

    val showFace = instance.faceUp
    // Hand / non-fill mode: rotate defense cards
    val rotation = if (!fillSlot && isDefense) 90f else 0f

    Box(modifier = outerMod, contentAlignment = Alignment.Center) {
        // The visual card body
        val bodyMod = if (fillSlot)
            Modifier.fillMaxSize()
        else
            Modifier.size(CardWidth, CardHeight)

        Box(
            modifier = bodyMod
                .graphicsLayer { rotationZ = rotation }
                .clip(RoundedCornerShape(6.dp))
                .border(
                    width = if (selected) 2.dp else 1.dp,
                    color = when {
                        selected                    -> Color(0xFFFFD54F)
                        !showFace && revealFaceDown  -> Color(0xFF6699CC)
                        isDefense && showFace        -> Color(0xFF4488FF)
                        else                         -> Color(0xFF253850)
                    },
                    shape = RoundedCornerShape(6.dp)
                )
        ) {
            if (!showFace) {
                CardBack()
            } else {
                val context = LocalContext.current
                val bitmap  = remember(instance.card.imageId) {
                    ImageLoader.loadCardImage(context, instance.card.imageId)
                }
                if (bitmap != null) {
                    Image(
                        bitmap             = bitmap.asImageBitmap(),
                        contentDescription = instance.card.name,
                        modifier           = Modifier.fillMaxSize(),
                        contentScale       = ContentScale.Crop
                    )
                } else {
                    Box(
                        modifier = Modifier.fillMaxSize().background(cardTypeColor(instance.card))
                    ) {
                        PlaceholderCardContent(instance)
                    }
                }
            }
        }

        // DEF badge (portrait fill-slot mode OR rotated hand mode)
        if (isDefense) {
            Box(
                modifier = Modifier
                    .align(if (fillSlot) Alignment.BottomStart else Alignment.BottomCenter)
                    .padding(2.dp)
                    .background(Color(0xCC1A3060), RoundedCornerShape(3.dp))
                    .padding(horizontal = 3.dp, vertical = 1.dp)
            ) {
                Text(
                    "DEF",
                    color      = Color(0xFF88BBFF),
                    fontSize   = 6.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Card back
// ─────────────────────────────────────────────────────────────────────────────

@Composable
fun CardBack(modifier: Modifier = Modifier) {
    val context    = LocalContext.current
    val backBitmap = remember { ImageLoader.loadCardBack(context) }
    Box(
        modifier           = modifier.fillMaxSize().background(Color(0xFF2B2D6E)),
        contentAlignment   = Alignment.Center
    ) {
        if (backBitmap != null) {
            Image(
                bitmap             = backBitmap.asImageBitmap(),
                contentDescription = "Card back",
                modifier           = Modifier.fillMaxSize(),
                contentScale       = ContentScale.Crop
            )
        } else {
            Box(
                modifier = Modifier
                    .padding(6.dp)
                    .fillMaxSize()
                    .border(1.dp, Color(0xFF6E72C7), RoundedCornerShape(4.dp))
            )
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Text placeholder (shown when no artwork file exists)
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun PlaceholderCardContent(instance: CardInstance) {
    val card = instance.card
    Column(
        modifier            = Modifier.fillMaxSize().padding(4.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            card.name,
            color      = Color.Black,
            fontSize   = 9.sp,
            fontWeight = FontWeight.Bold,
            lineHeight  = 10.sp,
            maxLines   = 4,
            overflow   = TextOverflow.Ellipsis
        )
        if (card.isMonster) {
            Text(
                "ATK ${card.atk ?: 0}/${card.def ?: 0}",
                color      = Color.Black,
                fontSize   = 8.sp,
                fontWeight = FontWeight.Bold
            )
        } else {
            Text(
                if (card.isSpell) "SPELL" else "TRAP",
                color = Color.Black, fontSize = 8.sp, fontWeight = FontWeight.Bold
            )
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Card type colours
// ─────────────────────────────────────────────────────────────────────────────

fun cardTypeColor(card: Card): Color = when (card.cardType) {
    CardType.MONSTER -> when (card.monsterCategory) {
        MonsterCategory.NORMAL -> Color(0xFFE8C77A)
        MonsterCategory.EFFECT -> Color(0xFFE8915A)
        MonsterCategory.FUSION -> Color(0xFFC79BE8)
        null                   -> Color(0xFFE8C77A)
    }
    CardType.SPELL -> Color(0xFF7FBF7F)
    CardType.TRAP  -> Color(0xFFE07FA8)
}
