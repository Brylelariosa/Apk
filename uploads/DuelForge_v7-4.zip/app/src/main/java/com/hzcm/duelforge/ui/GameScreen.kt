package com.hzcm.duelforge.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.hzcm.duelforge.data.EffectRegistry
import com.hzcm.duelforge.engine.*
import com.hzcm.duelforge.model.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// ─── Palette ──────────────────────────────────────────────────────────────────
private val BgColor    = Color(0xFF0A1424)
private val MatColor   = Color(0xFF0D1F35)
private val PanelColor = Color(0xFF112440)
private val AccentGold = Color(0xFFE8B339)
private val DimText    = Color(0xFF5A7A9A)
private val AttackRed  = Color(0xFFFF4422)
private val GreenOk    = Color(0xFF44CC77)

@Composable
fun GameScreen(
    viewModel: GameViewModel = viewModel(),
    onOpenDebug: () -> Unit = {}
) {
    val engine = viewModel.engine
    @Suppress("UNUSED_EXPRESSION") viewModel.refresh
    val state  = engine.state
    val scope  = rememberCoroutineScope()
    var showLog by remember { mutableStateOf(false) }

    val hasSelection = viewModel.selectedCard     != null ||
                       viewModel.tributeSelection  != null ||
                       viewModel.attackerSelection != null

    Box(modifier = Modifier.fillMaxSize().background(BgColor)) {

        Column(modifier = Modifier.fillMaxSize().padding(horizontal = 3.dp, vertical = 2.dp)) {

            // ── Opponent HUD ──────────────────────────────────────────────
            OpponentHud(engine, viewModel,
                onLogClick  = { showLog = true },
                onOpenDebug = onOpenDebug)

            Spacer(Modifier.height(2.dp))

            // ── Field mat — fills all remaining vertical space ────────────
            Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                Column(modifier = Modifier.fillMaxSize()) {

                    // Opponent spell/trap
                    FieldRow(
                        modifier       = Modifier.weight(1f).fillMaxWidth(),
                        cards          = (0..4).map { state.field(PlayerId.AI).spellTrapZones[it] },
                        isOpponent     = true
                    )
                    Spacer(Modifier.height(2.dp))
                    // Opponent monsters
                    FieldRow(
                        modifier       = Modifier.weight(1f).fillMaxWidth(),
                        cards          = (0..4).map { state.field(PlayerId.AI).monsterZones[it] },
                        isOpponent     = true,
                        highlightAll   = viewModel.attackerSelection != null,
                        onTap          = { c -> if (c != null) viewModel.onOpponentMonsterTapped(c) }
                    )

                    // Centre divider
                    Spacer(Modifier.height(2.dp))
                    Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFF1A3050)))
                    Spacer(Modifier.height(2.dp))

                    // Player monsters
                    FieldRow(
                        modifier     = Modifier.weight(1f).fillMaxWidth(),
                        cards        = (0..4).map { state.field(PlayerId.PLAYER).monsterZones[it] },
                        revealOwn    = true,
                        onTap        = { c -> if (c != null) viewModel.onOwnMonsterTapped(c) },
                        isSelected   = { c -> isCardSelected(c, viewModel) },
                        attackBadge  = { c ->
                            c != null &&
                            state.phase        == Phase.BATTLE &&
                            state.turnPlayer   == PlayerId.PLAYER &&
                            c.faceUp &&
                            c.battlePosition   == BattlePosition.ATTACK &&
                            !c.hasAttackedThisTurn
                        }
                    )
                    Spacer(Modifier.height(2.dp))
                    // Player spell/trap
                    FieldRow(
                        modifier   = Modifier.weight(1f).fillMaxWidth(),
                        cards      = (0..4).map { state.field(PlayerId.PLAYER).spellTrapZones[it] },
                        revealOwn  = true,
                        onTap      = { c -> if (c != null) viewModel.onOwnSpellTrapTapped(c) },
                        isSelected = { c -> isCardSelected(c, viewModel) }
                    )
                }
            }

            Spacer(Modifier.height(2.dp))

            // ── Player HUD + turn controls ────────────────────────────────
            PlayerHudRow(
                engine    = engine,
                vm        = viewModel,
                onDraw    = { viewModel.drawCard(); scope.launch { delay(550); viewModel.advancePhase() } },
                onBattle  = { viewModel.goToBattlePhase() },
                onMain2   = { viewModel.skipToMainPhase2() },
                onEnd     = { viewModel.endTurnNow() },
                onAdvance = { viewModel.advancePhase() }
            )

            Spacer(Modifier.height(3.dp))

            // ── Hand ──────────────────────────────────────────────────────
            LazyRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                items(engine.state.field(PlayerId.PLAYER).hand) { card ->
                    CardView(
                        instance       = card,
                        revealFaceDown = true,
                        selected       = isCardSelected(card, viewModel),
                        onClick        = { viewModel.onHandCardTapped(card) }
                    )
                }
            }
        }

        // ── Compact action popup ──────────────────────────────────────────
        AnimatedVisibility(
            visible  = hasSelection,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically(tween(180)) { it } + fadeIn(tween(180)),
            exit  = slideOutVertically(tween(140)) { it } + fadeOut(tween(120))
        ) {
            CompactActionPopup(vm = viewModel, engine = engine)
        }

        // ── Overlays ─────────────────────────────────────────────────────
        if (showLog) LogDialog(state) { showLog = false }
        state.pendingHumanPriority?.let { PriorityDialog(it, viewModel) }
        state.pendingDiscard?.let       { DiscardDialog(it, viewModel) }
        state.pendingCoinCall?.let      { CoinCallDialog(it, viewModel) }
        if (state.gameOver) GameOverOverlay(state, viewModel)

        viewModel.phasePopupText?.let  { PhasePopupOverlay(it) }
        viewModel.attackIndicator?.let { AttackIndicatorOverlay(it) }
        viewModel.destroyAnimCard?.let { CardBreakOverlay(it) }
        viewModel.coinFlipReveal?.let  { CoinFlipOverlay(it) { viewModel.dismissCoinFlipReveal() } }

        val previewCard = viewModel.previewCard
        var cachedPreview by remember { mutableStateOf(previewCard) }
        if (previewCard != null) cachedPreview = previewCard
        AnimatedVisibility(
            visible  = previewCard != null,
            enter    = fadeIn(tween(160)) + scaleIn(initialScale = 0.88f, animationSpec = tween(160)),
            exit     = fadeOut(tween(130)) + scaleOut(targetScale = 0.92f, animationSpec = tween(130))
        ) {
            cachedPreview?.let { card ->
                CardPreviewOverlay(
                    card        = card,
                    autoDismiss = viewModel.previewAutoShow,
                    onDismiss   = { viewModel.dismissPreview() }
                )
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Field row — all 5 slots fill the row's width × height uniformly
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun FieldRow(
    modifier:     Modifier             = Modifier,
    cards:        List<CardInstance?>,
    isOpponent:   Boolean              = false,
    revealOwn:    Boolean              = false,
    highlightAll: Boolean              = false,
    onTap:        (CardInstance?) -> Unit = {},
    isSelected:   (CardInstance?) -> Boolean = { false },
    attackBadge:  (CardInstance?) -> Boolean = { false }
) {
    Row(
        modifier              = modifier,
        horizontalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        cards.forEach { card ->
            val tappable = card != null || highlightAll
            Box(
                modifier           = Modifier.weight(1f).fillMaxHeight(),
                contentAlignment   = Alignment.Center
            ) {
                AnimatedCardSlot(
                    instance       = card,
                    fillSlot       = true,
                    modifier       = Modifier.fillMaxSize(),
                    revealFaceDown = revealOwn,
                    selected       = isSelected(card) || (highlightAll && card != null),
                    onClick        = if (tappable) ({ onTap(card) }) else null
                )
                // ⚔ attack badge (top-right corner)
                if (attackBadge(card)) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(2.dp)
                            .size(14.dp)
                            .background(AttackRed, CircleShape)
                            .border(1.dp, Color.White, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("⚔", fontSize = 6.sp)
                    }
                }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Opponent HUD
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun OpponentHud(
    engine:      GameEngine,
    vm:          GameViewModel,
    onLogClick:  () -> Unit,
    onOpenDebug: () -> Unit
) {
    val field = engine.state.field(PlayerId.AI)
    Row(
        modifier              = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment     = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            SmallDeck(field.deck.size)
            Column {
                Text("OPPONENT", color = DimText, fontSize = 7.sp, fontWeight = FontWeight.Bold)
                Text("LP ${field.lifePoints}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
            field.fieldZone?.let { FieldSpellChip(it, vm) }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("GY:${field.graveyard.size} ✦${field.banished.size}", color = DimText, fontSize = 7.sp)
            HudBtn("📜", onLogClick)
            HudBtn("⚙", onOpenDebug)
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Player HUD row
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun PlayerHudRow(
    engine:   GameEngine,
    vm:       GameViewModel,
    onDraw:   () -> Unit,
    onBattle: () -> Unit,
    onMain2:  () -> Unit,
    onEnd:    () -> Unit,
    onAdvance:() -> Unit
) {
    val state       = engine.state
    val field       = state.field(PlayerId.PLAYER)
    val isMyTurn    = state.turnPlayer == PlayerId.PLAYER
    val canAct      = isMyTurn && !state.gameOver &&
                      state.chain.isEmpty() && state.pendingHumanPriority == null
    val canDraw     = canAct && state.phase == Phase.DRAW && !vm.playerHasDrawnThisTurn

    Row(
        modifier          = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        // Tappable deck during Draw phase
        PlayerDeck(deckSize = field.deck.size, canDraw = canDraw, onDraw = onDraw)

        Column(modifier = Modifier.weight(1f)) {
            Text("YOU", color = DimText, fontSize = 7.sp, fontWeight = FontWeight.Bold)
            Text("LP ${field.lifePoints}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            field.fieldZone?.let { FieldSpellChip(it, vm) }
        }

        Text("GY:${field.graveyard.size}", color = DimText, fontSize = 7.sp)

        // Phase badge
        PhaseBadge(state)

        // Turn action buttons
        if (canAct) {
            TurnButtons(state, vm.playerHasDrawnThisTurn, onDraw, onBattle, onMain2, onEnd, onAdvance)
        } else if (!isMyTurn) {
            Text("…", color = DimText, fontSize = 13.sp, modifier = Modifier.padding(end = 4.dp))
        }
    }
}

@Composable
private fun PhaseBadge(state: GameState) {
    val label = when (state.phase) {
        Phase.DRAW         -> "DRAW"
        Phase.STANDBY      -> "STBY"
        Phase.MAIN1        -> "MAIN1"
        Phase.BATTLE, Phase.BATTLE_START -> "BATTLE"
        Phase.MAIN2        -> "MAIN2"
        Phase.END          -> "END"
    }
    val mine = state.turnPlayer == PlayerId.PLAYER
    Box(
        modifier = Modifier
            .background(
                if (mine) AccentGold.copy(alpha = 0.18f) else Color(0xFF3A0D0D),
                RoundedCornerShape(4.dp)
            )
            .border(
                1.dp,
                if (mine) AccentGold.copy(alpha = 0.8f) else Color(0xFF883030),
                RoundedCornerShape(4.dp)
            )
            .padding(horizontal = 5.dp, vertical = 3.dp)
    ) {
        Text(label, color = if (mine) AccentGold else Color(0xFFCC6666), fontSize = 8.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun TurnButtons(
    state:   GameState,
    hasDrawn: Boolean,
    onDraw:  () -> Unit,
    onBattle:() -> Unit,
    onMain2: () -> Unit,
    onEnd:   () -> Unit,
    onAdv:   () -> Unit
) {
    Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
        when (state.phase) {
            Phase.DRAW    -> if (!hasDrawn) TBtn(if (state.turnCount == 1) "Skip" else "Draw") { onDraw() }
            Phase.STANDBY -> TBtn("▶") { onAdv() }
            Phase.MAIN1   -> {
                TBtn("⚔", AttackRed)   { onBattle() }
                TBtn("M2", DimText)    { onMain2() }
                TBtn("End", DimText)   { onEnd() }
            }
            Phase.BATTLE, Phase.BATTLE_START -> TBtn("M2 ▶") { onAdv() }
            Phase.MAIN2   -> TBtn("End Turn") { onEnd() }
            Phase.END     -> TBtn("End Turn") { onAdv() }
        }
    }
}

@Composable
private fun TBtn(label: String, tint: Color = AccentGold, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .height(26.dp)
            .clip(RoundedCornerShape(5.dp))
            .background(tint.copy(alpha = 0.16f))
            .border(1.dp, tint.copy(alpha = 0.65f), RoundedCornerShape(5.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = tint, fontSize = 9.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun PlayerDeck(deckSize: Int, canDraw: Boolean, onDraw: () -> Unit) {
    Box(
        modifier = Modifier
            .size(36.dp, 50.dp)
            .then(if (canDraw) Modifier.clickable(onClick = onDraw) else Modifier)
            .border(
                if (canDraw) 2.dp else 1.dp,
                if (canDraw) AccentGold else Color(0xFF1E3050),
                RoundedCornerShape(5.dp)
            ),
        contentAlignment = Alignment.BottomEnd
    ) {
        if (deckSize > 0) CardBack(modifier = Modifier.fillMaxSize())
        else Box(Modifier.fillMaxSize().background(Color(0xFF0D1A2A), RoundedCornerShape(5.dp)))

        if (deckSize > 0) {
            Box(
                modifier = Modifier.size(15.dp).background(Color(0xDD000000), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(deckSize.toString(), color = Color.White, fontSize = 6.sp, fontWeight = FontWeight.Bold)
            }
        }
        if (canDraw) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .offset(y = 3.dp)
                    .background(AccentGold, RoundedCornerShape(2.dp))
                    .padding(horizontal = 3.dp, vertical = 1.dp)
            ) {
                Text("DRAW", fontSize = 5.sp, color = Color(0xFF1A1300), fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun SmallDeck(size: Int) {
    Box(modifier = Modifier.size(24.dp, 34.dp), contentAlignment = Alignment.BottomEnd) {
        if (size > 0) CardBack(Modifier.fillMaxSize())
        else Box(Modifier.fillMaxSize().background(Color(0xFF0D1A2A), RoundedCornerShape(4.dp)))
        if (size > 0) {
            Box(Modifier.size(13.dp).background(Color(0xCC000000), CircleShape), Alignment.Center) {
                Text(size.toString(), color = Color.White, fontSize = 5.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun HudBtn(icon: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier.size(24.dp).background(PanelColor, RoundedCornerShape(5.dp)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(icon, fontSize = 11.sp) }
}

@Composable
private fun FieldSpellChip(card: CardInstance, vm: GameViewModel) {
    Box(
        modifier = Modifier
            .background(Color(0xFF1D5C32), RoundedCornerShape(4.dp))
            .clickable { if (card.faceUp) vm.showFieldPreview(card) }
            .padding(horizontal = 5.dp, vertical = 2.dp)
    ) {
        Text("🌍 ${card.card.name}", color = Color.White, fontSize = 7.sp, maxLines = 1,
            overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 88.dp))
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Compact GBA-style action popup
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun CompactActionPopup(vm: GameViewModel, engine: GameEngine) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xEE0A1828))
            .border(
                width = 1.dp,
                color = AccentGold.copy(alpha = 0.5f),
                shape = RoundedCornerShape(topStart = 10.dp, topEnd = 10.dp)
            )
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp)) {
            val tribute  = vm.tributeSelection
            val attacker = vm.attackerSelection
            val card     = vm.selectedCard

            when {
                tribute  != null -> TributeRow(vm, tribute)
                attacker != null -> AttackerRow(vm, engine, attacker)
                card     != null -> CardPopupContent(vm, engine, card)
            }
        }
    }
}

@Composable
private fun TributeRow(vm: GameViewModel, tribute: TributeSelection) {
    val action = if (tribute.asSet) "Set" else "Summon"
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        // Header
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "$action: ${tribute.card.card.name}",
                color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            Text(
                "${tribute.chosen.size}/${tribute.required} tribute${if (tribute.required > 1) "s" else ""}",
                color = AccentGold, fontSize = 11.sp, fontWeight = FontWeight.Bold
            )
        }
        Text("Tap your monsters on the field to select tributes.", color = DimText, fontSize = 10.sp)
        // Buttons
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            ActionChip(
                "✓  Confirm",
                tint    = if (tribute.chosen.size == tribute.required) GreenOk else DimText,
                enabled = tribute.chosen.size == tribute.required
            ) { vm.confirmTributeSummon() }
            ActionChip("✕  Cancel", tint = AttackRed) { vm.cancelTributeSummon() }
        }
    }
}

@Composable
private fun AttackerRow(vm: GameViewModel, engine: GameEngine, attacker: CardInstance) {
    val computedAtk = engine.computeAtk(attacker)
    val opMonsters  = engine.state.field(PlayerId.AI).monsters()
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("⚔  ${attacker.card.name}", color = AttackRed, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text("ATK $computedAtk", color = AccentGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Text(
            if (opMonsters.isEmpty()) "No opponent monsters — direct attack available." else "Tap an opponent monster to attack it.",
            color = DimText, fontSize = 10.sp
        )
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            if (opMonsters.isEmpty() || engine.canDeclareAttack(attacker, null)) {
                ActionChip("⚔  Direct Attack", tint = AttackRed) { vm.declareDirectAttack() }
            }
            ActionChip("✕  Cancel") { vm.clearSelection() }
        }
    }
}

@Composable
private fun CardPopupContent(vm: GameViewModel, engine: GameEngine, card: CardInstance) {
    val baseAtk   = card.card.atk ?: 0
    val compAtk   = if (card.card.isMonster && card.location == Location.MONSTER_ZONE) engine.computeAtk(card) else baseAtk
    val compDef   = if (card.card.isMonster && card.location == Location.MONSTER_ZONE) engine.computeDef(card) else (card.card.def ?: 0)
    val boosted   = compAtk != baseAtk

    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        // ── Header: name + dismiss ──────────────────────────────────────
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(card.card.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (card.card.isMonster) {
                    val atkLabel = if (boosted) "ATK $compAtk (+${compAtk - baseAtk}) / DEF $compDef" else "ATK $compAtk / DEF $compDef"
                    Text(
                        "Lv${card.card.level ?: 0}  ${card.card.attribute?.name ?: ""}  ${card.card.race?.name?.replace('_', ' ') ?: ""}  $atkLabel",
                        color = if (boosted) Color(0xFF77EE99) else AccentGold,
                        fontSize = 9.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
            }
            if (card.faceUp) {
                ActionChip("🔍") { vm.showFieldPreview(card) }
            }
            Spacer(Modifier.width(4.dp))
            ActionChip("✕") { vm.clearSelection() }
        }

        // ── Action chips ───────────────────────────────────────────────
        val state          = engine.state
        val playerMonsters = state.field(PlayerId.PLAYER).monsters()
        val tribReq        = card.card.tributesRequired
        val hasEnoughTrib  = playerMonsters.size >= tribReq

        when (card.location) {
            Location.HAND -> {
                if (card.card.isMonster && engine.canNormalSummon(card)) {
                    if (hasEnoughTrib) {
                        val tribNote = if (tribReq > 0) " ($tribReq trib)" else ""
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                            ActionChip("Normal Summon$tribNote", modifier = Modifier.weight(1f)) { vm.beginSummon(false) }
                            if (engine.canSetMonster(card))
                                ActionChip("Set$tribNote", modifier = Modifier.weight(1f)) { vm.beginSummon(true) }
                        }
                    } else if (tribReq > 0) {
                        Text(
                            "⚠ Need $tribReq tribute${if (tribReq > 1) "s" else ""} (have ${playerMonsters.size} on field)",
                            color = Color(0xFFFF9944), fontSize = 10.sp
                        )
                    }
                }
                if ((card.card.isSpell || card.card.isTrap) && engine.canSetSpellOrTrap(card)) {
                    ActionChip("Set face-down", modifier = Modifier.fillMaxWidth()) { vm.setTrap() }
                }
                for (eff in EffectRegistry.effectsFor(card.card.id)) {
                    if (engine.canActivateEffect(card, eff))
                        ActionChip("Activate: ${eff.description}", modifier = Modifier.fillMaxWidth()) { vm.activateEffect(eff) }
                }
            }

            Location.MONSTER_ZONE -> {
                val inBattle = state.phase == Phase.BATTLE && state.turnPlayer == PlayerId.PLAYER
                        && card.battlePosition == BattlePosition.ATTACK && card.faceUp && !card.hasAttackedThisTurn
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (engine.canFlipSummon(card))
                        ActionChip("Flip Summon") { vm.flipSummon() }
                    val opp = if (card.battlePosition == BattlePosition.ATTACK) BattlePosition.DEFENSE else BattlePosition.ATTACK
                    if (engine.canChangeBattlePosition(card, opp))
                        ActionChip(if (opp == BattlePosition.ATTACK) "→ ATK" else "→ DEF") { vm.changeBattlePosition(opp) }
                    if (inBattle)
                        ActionChip("⚔ Attack", tint = AttackRed) { vm.onOwnMonsterTapped(card) }
                }
                for (eff in EffectRegistry.effectsFor(card.card.id)) {
                    if (engine.canActivateEffect(card, eff))
                        ActionChip("Activate: ${eff.description}", modifier = Modifier.fillMaxWidth()) { vm.activateEffect(eff) }
                }
            }

            Location.SPELL_TRAP_ZONE -> {
                for (eff in EffectRegistry.effectsFor(card.card.id)) {
                    if (engine.canActivateEffect(card, eff))
                        ActionChip("Activate: ${eff.description}", modifier = Modifier.fillMaxWidth()) { vm.activateEffect(eff) }
                }
                if (!card.faceUp) {
                    Text(
                        if (card.card.isTrap) "Set Trap — activates on opponent's turn." else "Set Spell — tap Activate when ready.",
                        color = DimText, fontSize = 10.sp
                    )
                }
            }
            else -> {}
        }
    }
}

/** Compact pill-shaped action button. */
@Composable
private fun ActionChip(
    label:   String,
    tint:    Color   = AccentGold,
    enabled: Boolean = true,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val bg     = if (enabled) tint.copy(alpha = 0.15f) else Color(0xFF1A2A3A)
    val border = if (enabled) tint.copy(alpha = 0.65f) else DimText.copy(alpha = 0.3f)
    val text   = if (enabled) tint else DimText

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bg)
            .border(1.dp, border, RoundedCornerShape(6.dp))
            .then(if (enabled) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 10.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = text, fontSize = 11.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center)
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Log dialog
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun LogDialog(state: GameState, onDismiss: () -> Unit) {
    val listState = rememberLazyListState()
    LaunchedEffect(Unit) { if (state.log.isNotEmpty()) listState.scrollToItem(state.log.size - 1) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Duel Log") },
        text = {
            LazyColumn(state = listState, modifier = Modifier.heightIn(max = 400.dp)) {
                items(state.log) { line ->
                    Text(line, color = Color(0xFFCCCCCC), fontSize = 11.sp, lineHeight = 14.sp)
                }
            }
        },
        confirmButton = { Button(onClick = onDismiss) { Text("Close") } }
    )
}

// ─────────────────────────────────────────────────────────────────────────────
// Dialogs
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun PriorityDialog(prompt: PriorityPrompt, vm: GameViewModel) {
    AlertDialog(
        onDismissRequest = {},
        title = { Text("Respond?") },
        text = {
            Column {
                Text(prompt.reason, fontSize = 11.sp)
                Spacer(Modifier.height(8.dp))
                prompt.optionLabels.forEachIndexed { i, label ->
                    Button(onClick = { vm.submitPriorityChoice(i) }, modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                        Text(label, fontSize = 10.sp)
                    }
                }
            }
        },
        confirmButton = { Button(onClick = { vm.submitPriorityChoice(null) }) { Text("Pass") } }
    )
}

@Composable
private fun DiscardDialog(req: DiscardRequest, vm: GameViewModel) {
    AlertDialog(
        onDismissRequest = {},
        title = { Text("Discard ${req.count} card${if (req.count > 1) "s" else ""}") },
        text = {
            Column {
                Text(req.reason, fontSize = 10.sp, color = Color.LightGray)
                Spacer(Modifier.height(6.dp))
                Text("Tap to select (${vm.discardChosen.size}/${req.count})", fontSize = 9.sp, color = Color.Gray)
                Spacer(Modifier.height(4.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    items(vm.engine.state.field(req.player).hand) { card ->
                        CardView(
                            instance       = card,
                            revealFaceDown = true,
                            selected       = vm.discardChosen.contains(card),
                            onClick        = { vm.onDiscardCardToggled(card) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = { vm.confirmDiscard() }, enabled = vm.discardChosen.size == req.count) {
                Text("Discard")
            }
        }
    )
}

@Composable
private fun CoinCallDialog(req: CoinCallRequest, vm: GameViewModel) {
    AlertDialog(
        onDismissRequest = {},
        title = { Text("Call it!") },
        text = {
            Column {
                Text(req.reason, fontSize = 11.sp, color = Color.LightGray)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { vm.callCoinToss(CoinSide.HEADS) }, modifier = Modifier.weight(1f)) { Text("Heads") }
                    Button(onClick = { vm.callCoinToss(CoinSide.TAILS) }, modifier = Modifier.weight(1f)) { Text("Tails") }
                }
            }
        },
        confirmButton = {}
    )
}

// ─────────────────────────────────────────────────────────────────────────────
// Overlays: phase popup, attack indicator, card break, coin flip, preview
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun PhasePopupOverlay(text: String) {
    val enemy = text.startsWith("ENEMY")
    Box(Modifier.fillMaxSize(), Alignment.Center) {
        Box(
            modifier = Modifier
                .background(if (enemy) Color(0xCC4A0A0A) else Color(0xCC0A2840), RoundedCornerShape(10.dp))
                .border(2.dp, if (enemy) Color(0xFFAA3333) else AccentGold, RoundedCornerShape(10.dp))
                .padding(horizontal = 26.dp, vertical = 12.dp)
        ) {
            Text(text, color = if (enemy) Color(0xFFFF8888) else AccentGold, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
    }
}

@Composable
private fun AttackIndicatorOverlay(text: String) {
    Box(Modifier.fillMaxSize(), Alignment.Center) {
        Box(
            modifier = Modifier
                .background(Color(0xCC000000), RoundedCornerShape(8.dp))
                .border(1.dp, Color(0xFF994422), RoundedCornerShape(8.dp))
                .padding(horizontal = 18.dp, vertical = 10.dp)
        ) {
            Text("⚔  $text", color = Color(0xFFFFAA44), fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
    }
}

@Composable
private fun CardBreakOverlay(card: CardInstance) {
    val scale    = remember { Animatable(1f) }
    val alpha    = remember { Animatable(1f) }
    val rotation = remember { Animatable(0f) }
    LaunchedEffect(card) {
        launch { scale.animateTo(1.15f, tween(140)) }
        delay(140L)
        launch { rotation.animateTo(14f, tween(280)) }
        launch { scale.animateTo(0f, tween(460)) }
        launch { alpha.animateTo(0f, tween(560)) }
    }
    Box(Modifier.fillMaxSize(), Alignment.Center) {
        Box(
            modifier = Modifier.graphicsLayer {
                scaleX = scale.value; scaleY = scale.value
                this.alpha = alpha.value; rotationZ = rotation.value
            }
        ) {
            Box(
                modifier = Modifier
                    .size(CardWidth * 1.5f, CardHeight * 1.5f)
                    .background(Color(0xFFCC2222), RoundedCornerShape(8.dp))
                    .border(3.dp, Color(0xFFFF4444), RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) { Text("💥", fontSize = 26.sp) }
        }
    }
}

@Composable
private fun CoinFlipOverlay(reveal: CoinFlipReveal, onDone: () -> Unit) {
    var displayedSide by remember(reveal) { mutableStateOf(reveal.called) }
    var settled       by remember(reveal) { mutableStateOf(false) }
    val coinScale     by animateFloatAsState(if (settled) 1.18f else 1f, tween(220), label = "coin")

    LaunchedEffect(reveal) {
        repeat(12) {
            displayedSide = if (displayedSide == CoinSide.HEADS) CoinSide.TAILS else CoinSide.HEADS
            delay(70L)
        }
        displayedSide = reveal.landed; settled = true; delay(1500L); onDone()
    }

    Box(Modifier.fillMaxSize().background(Color(0xCC000000)), Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier
                    .size(100.dp).scale(coinScale)
                    .background(Brush.radialGradient(listOf(Color(0xFFFFE9A8), Color(0xFFC9971F))), CircleShape)
                    .border(4.dp, Color(0xFF8A6418), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(if (displayedSide == CoinSide.HEADS) "H" else "T", fontSize = 40.sp, fontWeight = FontWeight.Black, color = Color(0xFF4A3300))
            }
            Spacer(Modifier.height(14.dp))
            Text(if (!settled) "Flipping…" else "${reveal.landed.displayName}!", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
            if (settled) {
                Spacer(Modifier.height(4.dp))
                Text(
                    "Called ${reveal.called.displayName} — " + if (reveal.won) "right!" else "wrong!",
                    color = if (reveal.won) Color(0xFF66E28A) else Color(0xFFFF6B6B),
                    fontWeight = FontWeight.Bold, fontSize = 14.sp
                )
            }
        }
    }
}

@Composable
private fun CardPreviewOverlay(card: CardInstance, autoDismiss: Boolean, onDismiss: () -> Unit) {
    if (autoDismiss) LaunchedEffect(card) { delay(2200L); onDismiss() }
    Box(
        modifier = Modifier.fillMaxSize().background(Color(0xCC000000)).clickable { onDismiss() },
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(modifier = Modifier.size(200.dp, 285.dp)) {
                val context = LocalContext.current
                val bitmap  = remember(card.card.imageId) { ImageLoader.loadCardImage(context, card.card.imageId) }
                if (bitmap != null) {
                    Image(bitmap.asImageBitmap(), card.card.name, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                } else {
                    Box(
                        Modifier.fillMaxSize().background(cardTypeColor(card.card), RoundedCornerShape(10.dp)).padding(12.dp)
                    ) {
                        Column {
                            Text(card.card.name, color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Spacer(Modifier.height(8.dp))
                            Text(card.card.description, color = Color.DarkGray, fontSize = 11.sp, lineHeight = 13.sp)
                            if (card.card.isMonster) {
                                Spacer(Modifier.height(8.dp))
                                Text("ATK ${card.card.atk ?: 0} / DEF ${card.card.def ?: 0}", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("Tap to dismiss", color = Color(0xFFAAAAAA), fontSize = 10.sp)
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Game over
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun GameOverOverlay(state: GameState, vm: GameViewModel) {
    Box(Modifier.fillMaxSize().background(Color(0xCC000000)), Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                when (state.winner) {
                    PlayerId.PLAYER -> "You Win! 🎉"
                    PlayerId.AI     -> "Opponent Wins!"
                    null            -> "Duel Over"
                },
                color = Color.White, fontWeight = FontWeight.Bold, fontSize = 28.sp
            )
            Spacer(Modifier.height(16.dp))
            Button(onClick = { vm.restart() }) { Text("New Duel") }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────────────────────

private fun isCardSelected(card: CardInstance?, vm: GameViewModel): Boolean {
    if (card == null) return false
    return vm.selectedCard          === card ||
           vm.attackerSelection     === card ||
           vm.tributeSelection?.chosen?.contains(card) == true ||
           vm.discardChosen.contains(card)
}
