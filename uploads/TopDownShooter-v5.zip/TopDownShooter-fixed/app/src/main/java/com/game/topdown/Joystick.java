package com.game.topdown;

import android.graphics.*;

public class Joystick {
    private float bx, by, radius;
    private float sx, sy;
    private int   touchId = -1;
    private float nx, ny;
    private boolean active;

    private Paint basePaint  = ring(80);
    private Paint stickPaint = ring(190);
    private int   baseAlpha  = 150;   // outer ring alpha

    public Joystick(float bx, float by, float r) {
        this.bx=bx; this.by=by; this.radius=r; sx=bx; sy=by;
    }

    public void setAlpha(int a) {
        baseAlpha = a;
        basePaint  = ring(a / 3);
        stickPaint = ring(a);
    }

    private static Paint ring(int alpha) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.argb(alpha,255,255,255));
        p.setStyle(Paint.Style.FILL);
        return p;
    }

    public void updateBase(float x, float y) {
        bx=x; by=y; if(!active){sx=x; sy=y;}
    }

    /** Returns true if this joystick claimed the touch. */
    public boolean onTouchDown(int id, float x, float y) {
        if (touchId != -1) return false;
        float dx=x-bx, dy=y-by;
        if (dx*dx+dy*dy <= radius*radius*2.25f) {
            touchId=id; active=true; move(x,y); return true;
        }
        return false;
    }
    public void onTouchMove(int id, float x, float y) { if(touchId==id) move(x,y); }
    public void onTouchUp(int id) {
        if(touchId==id){ touchId=-1; active=false; sx=bx; sy=by; nx=0; ny=0; }
    }
    private void move(float x, float y) {
        float dx=x-bx, dy=y-by, d=(float)Math.sqrt(dx*dx+dy*dy);
        if(d>radius){ dx=dx/d*radius; dy=dy/d*radius; }
        sx=bx+dx; sy=by+dy; nx=dx/radius; ny=dy/radius;
    }

    public void draw(Canvas c) {
        Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
        ring.setColor(Color.argb(baseAlpha / 3, 255, 255, 255));
        ring.setStyle(Paint.Style.STROKE);
        ring.setStrokeWidth(4f);
        c.drawCircle(bx, by, radius, ring);
        c.drawCircle(bx, by, radius, basePaint);
        c.drawCircle(sx, sy, radius * 0.44f, stickPaint);
    }

    public float   getX()     { return nx; }
    public float   getY()     { return ny; }
    public boolean isActive() { return active; }
}
