# The restoration pipeline

Everything below runs natively, per tile, orchestrated by
`RestorationEngine::run()` (`app/src/main/cpp/src/restoration_engine.cpp`).
Every method named here is a published, classical (pre-deep-learning)
technique — no step involves a trained model, weights, or a network of any
kind.

## Stage 1 — Whole-image analysis

A single Sobel gradient-magnitude pass over the full image
(`conv::sobelMagnitude`) produces the edge map used later by Reality Lock.
Computed once at full resolution rather than per-tile, since Stage 8 needs
it at the same scale as the final reassembled image.

## Stage 2 — Adaptive tiling

`TileProcessor::computeAdaptiveTiles` splits the image into a grid of
`tileSize` tiles (128–512px, user-configurable), each expanded by
`tileSize / 4` px of overlap on every side that borders a neighbor. Tiles
at the true image edge aren't expanded on that side — there's nothing to
blend against there.

## Stage 3 — Restoration candidates (generated per tile, on the Y/luma plane)

Four independent candidates, kept separate rather than blended at this
stage:

- **Wiener deconvolution** (`Deconvolution::wiener`) — frequency-domain
  division by an estimated point-spread function with a
  noise-to-signal regularization term. Fast, stable, tends to look
  slightly flat on its own.
- **Richardson–Lucy deconvolution** (`Deconvolution::richardsonLucy`) —
  spatial-domain iterative deblurring, iteration count clamped to 1–15
  per the spec's "limited iterations." Recovers more contrast than
  Wiener, more prone to ringing near strong edges (which Stage 6 exists
  to catch).
- **Edge-aware sharpen** (`EdgeAwareEnhancer::sharpen`) — an unsharp
  mask built on a guided-filter base (He, Sun & Tang, 2010) instead of a
  plain Gaussian, which keeps halos smaller at the source than a
  textbook unsharp mask.
- **Texture/local-contrast pass** (`EdgeAwareEnhancer::localContrast`) —
  the same guided-filter-detail-boost idea at a much larger radius, for
  mid-frequency tonal structure ("clarity") rather than fine edges.

The point-spread function for both deconvolution methods is a Gaussian,
elongated along the estimated blur direction in proportion to the
estimated anisotropy (see Stage "Analysis" below) — isotropic when the
tile looks like defocus blur, directional when it looks like motion blur.

## Stage 4 — Consensus restoration

`ConsensusEngine::combine` compares the four candidates pixel-by-pixel.
Where they agree (low spread across candidates), their average is
trusted. Where they disagree, the spec is explicit that the result should
never just be an average — so the engine picks whichever single candidate
deviates *least* from the original pixel, i.e. the conservative choice,
and records a per-pixel confidence map from the agreement level.

## Stage 5 — Reality Score

Not a single function — a composite the orchestrator assembles per tile
from signals produced across the other stages: consensus confidence,
blur-estimate confidence, artifact severity (inverted), and noise
estimate (inverted). Rolled up to a whole-image score weighted by tile
area. Surfaced in Debug Mode.

## Stage 6 — Artifact detection

`ArtifactDetector::detect` compares the restored tile against the
*original* tile's local (3×3) intensity range. Any pixel that overshoots
that range beyond a small tolerance is scored as halo/ringing severity —
by construction, anything past that tolerance is information the
restoration *added*, not recovered. `ArtifactDetector::suppress` blends
the restored value back toward the original in proportion to that
severity, i.e. undoes enhancement only where it misbehaved.

## Stage 7 — Frequency-band consensus

`FrequencyAnalyzer::decompose` splits the tile into low/mid/high bands via
two Gaussian blurs at different sigmas (a small Laplacian-pyramid-style
decomposition). `bandAgreementMap` computes a local, box-filtered
normalized correlation between the rectified mid and high bands: high
where fine detail sits on top of real mid-band structure, low where the
high band has energy with no mid-band support underneath it (the
signature of noise rather than texture). The orchestrator uses this map
to gate how much of the restored image's high-frequency residual gets
trusted, per pixel, versus falling back to the original's residual.

## Stage 8 — Reality Lock

`RealityLock::protect` builds an "importance" map from two classical,
zero-training measures on the *original* tile: Sobel edge magnitude, and
a Harris corner response (Harris & Stephens, 1988) computed from the
local structure tensor. High-importance pixels — corners, line
junctions, fine text strokes, and in practice most facial features too —
get blended back toward the original in proportion to both the
importance score and a `protectionStrength` (higher in Conservative
Mode). See ARCHITECTURE.md for why this is structural-cue-based rather
than an actual face/eye detector.

## Stage 9 — Reassembly and output

`TileProcessor::accumulateTile` / `finalizeBlend` composite every tile
back into the full image using a raised-cosine crossfade across each
tile's overlap band (see ARCHITECTURE.md for why this doesn't seam).
Global tone adjustments (contrast, brightness, saturation, white balance)
are applied once on the fully-reassembled image — never per-tile — so
there's no risk of a visible tone shift at a tile boundary. The final
`PipelineOutput` carries the restored image plus five diagnostic maps
(blur, noise, edge, confidence, artifact severity), the whole-image
Reality Score, and per-stage timings, all surfaced in the editor's Debug
tab.

## Analysis primitives used above

- **Blur radius / direction** (`BlurEstimator::estimate`) — Laplacian-
  variance as a sharpness proxy (well-established autofocus/blur-
  detection cue), and a structure-tensor eigen-decomposition for
  direction and anisotropy (classical Harris/Förstner analysis).
- **Noise sigma** (`NoiseEstimator::estimateSigma`) — Immerkær's fast
  noise-variance estimator (*Fast Noise Variance Estimation*, CVIU 1996):
  a single Laplacian-like convolution with a closed-form scaling.
- **FFT** (`fft::fft1D` / `fft2D`) — an iterative radix-2 Cooley–Tukey
  implementation, used only by Wiener deconvolution on power-of-two
  padded tile buffers.

## Special modes

`RestorationEngine::applySpecialMode` retunes the incoming
`RestorationParams` once, before tiling starts, based on the selected
mode (Document/Text, Old Photo, Portrait, Screenshot) — see the function
body for the exact adjustments per mode. Every downstream stage just sees
already-tuned parameters; special modes carry no logic of their own.
