# Building Project Crystal

## Prerequisites

- Android Studio Ladybug (2024.2) or newer
- JDK 17 (bundled with recent Android Studio)
- Android SDK Platform 34
- Android NDK **25.2.9519653** (Android Studio → SDK Manager → SDK Tools
  → NDK, "Show Package Details" to pick the exact version)
- CMake **3.22.1** (same SDK Manager tab)

The exact NDK/CMake versions matter here: they're pinned in
`app/build.gradle.kts` (`ndkVersion`, `externalNativeBuild.cmake.version`)
to match what the included CI workflow installs, so a local build and a CI
build use identical native toolchains.

## Building locally

1. Open the project root (the folder containing `settings.gradle.kts`) in
   Android Studio — **not** the `app/` subfolder.
2. Let Gradle sync. First sync will download the NDK/CMake versions above
   if they aren't already installed.
3. Run on a device or emulator running Android 8.0 (API 26) or newer.

Debug builds are unsigned and unminified by default — just Run ▶. Release
builds (`./gradlew assembleRelease`) require a signing config; see
"Signing" below, or build unsigned with
`./gradlew assembleRelease -Pandroid.injected.signing.store.file=` left
unset, which Android Studio will prompt you to configure.

### Command line

```bash
./gradlew assembleDebug      # unsigned debug APK, app/build/outputs/apk/debug/
./gradlew assembleRelease    # signed release APK, if signing is configured
./gradlew test               # JVM unit tests
./gradlew connectedAndroidTest  # instrumentation tests, needs a connected device/emulator
```

### 32-bit devices

The release build ships `arm64-v8a` only by default (see ARCHITECTURE.md,
"APK size"). To also build `armeabi-v7a`:

```bash
./gradlew assembleRelease -PincludeArmv7=true
```

## Building via the included GitHub Actions workflow

The `Build APK` workflow you provided (`.github/workflows/build.yml` in
your repo) builds this project without anyone needing Android Studio
installed at all:

1. Zip this entire project folder (the one containing `settings.gradle.kts`
   at its root — the workflow searches up to 4 levels deep for that file,
   so a wrapper folder around it is fine, but don't zip just `app/`).
2. Push the zip into `uploads/` on `main` or `master` (that path is what
   the workflow's `paths:` trigger watches for).
3. Actions installs NDK 25.2.9519653/25.1.8937393 and CMake 3.22.1,
   fetches `gradle-wrapper.jar` (not included in the zip — see below),
   and runs `assembleRelease` if a `KEYSTORE_BASE64` repo secret is
   present, or `assembleDebug` otherwise.
4. The resulting APK is uploaded as a workflow artifact; the zip is then
   removed from the repo automatically (`[skip ci]` on that commit, so it
   doesn't retrigger the workflow).

This repo's zip intentionally does **not** include
`gradle/wrapper/gradle-wrapper.jar` — the workflow downloads it itself
from `https://raw.githubusercontent.com/gradle/gradle/v8.6.0/...` as its
"Fetch gradle-wrapper.jar" step. `gradlew`, `gradlew.bat`, and
`gradle/wrapper/gradle-wrapper.properties` (pointing at Gradle 8.6) are
included, which is everything else the wrapper needs.

### Signing (optional — for `assembleRelease`)

Add these repo secrets to get a signed release APK instead of a debug one:

| Secret | Contents |
|---|---|
| `KEYSTORE_BASE64` | `base64 -i your-release-key.jks \| pbcopy` (or equivalent) |
| `STORE_PASSWORD` | Keystore password |
| `KEY_ALIAS` | Key alias |
| `KEY_PASSWORD` | Key password |

Without these, the workflow falls back to `assembleDebug` and still
produces an installable (debug-signed) APK.

## Troubleshooting

- **"NDK not configured" / CMake errors on first sync** — make sure the
  exact versions above are installed via SDK Manager; Gradle won't
  silently substitute a different NDK version since `ndkVersion` is
  pinned.
- **`libcrystal_native.so` UnsatisfiedLinkError at runtime** — almost
  always an ABI mismatch (running a `armeabi-v7a`-only build on an
  emulator image that doesn't support it, or vice versa). Check the
  emulator/device ABI against `ndk.abiFilters` in `app/build.gradle.kts`.
- **Room `NoSuchMethodError` at runtime after modifying `HistoryEntity`**
  — `kapt` didn't regenerate. `./gradlew clean` and rebuild.
