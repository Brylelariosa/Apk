# Architecture

## Layers

```
UI (Fragments, ViewBinding)
   │  reads/writes StateFlow, never touches JNI or Room directly
   ▼
ViewModel (EditorViewModel, HomeViewModel, HistoryViewModel, BatchViewModel)
   │  orchestrates; owns UI-facing state
   ▼
Repository (ImageRepository)  ──────────────►  ExportManager
   │  the one place that knows about both the native layer and storage
   ▼
NativeImageProcessor (JNI wrapper)  +  Room (AppDatabase)  +  WorkManager (RestorationWorker)
   │
   ▼
libcrystal_native.so  — RestorationEngine and the Stage 1–9 pipeline (see PIPELINE.md)
```

Every screen follows the same rule: **Fragment → ViewModel → Repository**,
never Fragment → Repository or Fragment → JNI directly. `EditorViewModel`
in particular never talks to the native library itself — it enqueues a
`RestorationWorker`, which is the only thing that calls
`ImageRepository.restore()`, which is the only thing that calls
`NativeImageProcessor`. That chain is what makes restoration survive the
app being backgrounded and stay cancelable, per the spec's "no UI freezes,
cancelable operations" requirement.

## Native module structure

The C++ side is organized one class per pipeline stage (`BlurEstimator`,
`NoiseEstimator`, `Deconvolution`, `EdgeAwareEnhancer`, `ConsensusEngine`,
`ArtifactDetector`, `FrequencyAnalyzer`, `RealityLock`, `TileProcessor`),
each independently readable and unit-testable in isolation, with
`RestorationEngine` as the only class that knows the *order* they run in.
`jni_bridge.cpp` is a thin boundary, not where any algorithm lives — see
its file comment for why the whole pipeline runs behind a single JNI call
rather than one call per stage.

## Key design decisions

**Why no OpenCV native dependency.** OpenCV now publishes an Android AAR
to Maven Central (since 4.9.0), but wiring its native CMake package into a
JNI build — and trusting that wiring without being able to test-compile it
against a real NDK toolchain in this environment — was judged a worse risk
than writing the roughly 1,500 lines of dependency-free C++ this project
actually needs (convolution, a Cooley–Tukey FFT, box/Gaussian filtering).
The upside beyond risk: the entire numerical pipeline is auditable in one
place, which matches the spec's own "conservative, explainable" design
philosophy, and the release binary stays small. See CMakeLists.txt for the
same note in context. Swapping in the real OpenCV AAR later is a
contained change (replace `src/*.cpp` internals one function at a time;
the class boundaries don't need to move) if a future iteration wants it.

**Why manual DI instead of Hilt.** One repository and a handful of
ViewModels don't justify a DI framework's annotation processor — that's
real added build-time risk (also unverifiable without a full compile) for
very little payoff over `ViewModelFactory { SomeViewModel(deps) }`. See
`ui/common/ViewModelFactory.kt`. Revisit if the dependency graph grows.

**Why a metrics sidecar file instead of passing results through
WorkManager.** `WorkManager`'s `Data` output is capped at roughly 10KB —
nowhere near enough for five diagnostic maps at up to 512×512 floats each.
`ImageRepository.restore()` persists the full `RestorationResult` as JSON
next to the restored PNG; the worker's output `Data` carries only the
file path, and `EditorViewModel` reads the sidecar back in once the
worker reports success. See `ImageRepository.metricsPathFor()`.

**Why luma/chroma separation instead of processing R/G/B independently.**
Deconvolution and consensus run once, on the Y plane; Cb/Cr get a light
box blur scaled by the noise-reduction slider and are otherwise passed
through. This is standard practice in real restoration pipelines (avoids
color fringing from independently-deconvolved channels) and cuts native
compute roughly 3x versus running the full candidate pipeline three times.

**Why the tile blend uses a `2×overlap`-wide raised-cosine crossfade.**
Worked out and documented in `tile_processor.cpp` — the two adjacent
tiles' ramps are proven to sum to exactly 1.0 across their shared overlap
band (`f(t) + f(1-t) = 1` for the raised-cosine `f`), which is what
avoids a visible seam at tile boundaries.

**Why Reality Lock uses edge magnitude + a Harris corner response instead
of face/eye detection.** The spec's Stage 8 asks to protect "faces, eyes,
text, corners, straight lines, thin structures" — but a real face/eye
detector is itself a trained classifier, which conflicts with the "no
pretrained models" constraint. Structural cues (strong gradients, corner
response) protect the same *kind* of content — corners, line junctions,
fine text strokes, and in practice most facial features too — without
knowing what a face is. See PIPELINE.md, Stage 8, and `reality_lock.cpp`'s
file comment.

**Why images are downscaled above ~3000px before processing.** The
pipeline holds input, output, and a weight-accumulator buffer at full
resolution simultaneously; uncapped, a large modern photo could exceed
what the spec's own 4GB-RAM device target can spare. See
`ImageRepository.MAX_PROCESSING_DIMENSION`.

## APK size

- Ships `arm64-v8a` only by default (covers virtually all Android 8+
  devices in active use); build with `-PincludeArmv7=true` to add the
  32-bit ABI back for older hardware.
- Release native libraries are fully stripped (`ndk.debugSymbolLevel =
  "NONE"`) and packaged compressed (`useLegacyPackaging = true`) — the
  right trade-off for a directly-installed CI artifact rather than a
  Play-delivered bundle; flip both if this ever ships as an `.aab`
  (`bundle { }` in `app/build.gradle.kts` documents that path too).
- `resourceConfigurations += setOf("en")` strips the dozens of
  AndroidX/Material transitive translation strings the app doesn't use yet.
- R8 full mode + the new resource shrinker are both explicit (not just
  relying on AGP defaults) in `gradle.properties`.
- All icons are vector drawables and the launcher icon is a vector
  adaptive icon (`mipmap-anydpi-v26` only) — no raster PNGs, no
  per-density duplication.

## What's simplified vs. the original spec

Being direct about this rather than quietly shipping dead buttons:

- **Crop / grid overlay / histogram** are not wired into the editor
  toolbar. Each is a real feature in its own right (a draggable crop
  rect; a live-recomputed histogram) rather than a one-line handler, and
  a menu item that does nothing on tap is worse than not having it.
- **Batch processing** runs every selected image through one shared Auto
  preset rather than exposing a full per-image tool panel — intentional
  scope boundary, not an oversight (see `BatchViewModel`'s file comment).
- **TIFF export** isn't implemented; the spec itself marked it optional.
- **Navigation Drawer** carries Batch/Favorites/About/Help per the spec's
  "advanced features" framing; it doesn't duplicate items already on the
  bottom nav.
- **Face/eye detection** in Reality Lock is structural-cue-based, not a
  literal detector — see the design-decision note above.
- **Test coverage** is a representative sample (native algorithm
  correctness would need on-device or host-side C++ test infra beyond
  this session's scope), not exhaustive: two JVM unit-test files, two
  instrumentation-test files. Real, passing, and meaningful, but not a
  full suite.
- **Accessibility** covers content descriptions, scalable text (`sp` /
  theme text appearances throughout, no hardcoded `dp` font sizes), and
  system font-scale support by construction (no fixed-height text
  containers); it hasn't been audited with TalkBack on a real device.
