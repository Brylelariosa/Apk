// Top-level build file. Per-module configuration lives in each module's build.gradle.kts.
plugins {
    id("com.android.application") version "8.4.0" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
    id("androidx.navigation.safeargs.kotlin") version "2.7.7" apply false
}
