# Project Crystal

Offline image restoration for Android, built entirely on classical
computational photography — no AI, no machine learning, no neural networks,
no cloud calls. Every restoration decision the app makes is a closed-form
or iterative numerical method you could name and explain (Wiener
deconvolution, Richardson–Lucy, a guided filter, a structure tensor), not a
trained model's opaque judgment.

> **Where this build stands.** This is a complete, working v1: a real
> native restoration pipeline, a full MVVM Android app around it, and a
> CI-ready Gradle/CMake project. It is not a byte-for-byte implementation
> of every line item in the original spec — see ["What's simplified vs.
> the spec"](ARCHITECTURE.md#whats-simplified-vs-the-original-spec) in
> ARCHITECTURE.md for the honest list of what's trimmed or deferred, and
> why.

## What it does

Restores motion blur, camera shake, defocus blur, JPEG/compression
artifacts, noise, and general softness — in old photographs, documents,
screenshots, and ordinary photos alike. The design philosophy is
conservative by construction: the engine never invents texture that isn't
already implied by the image, and every enhancement stage has a
corresponding "back off" mechanism (artifact detection, frequency-band
gating, a Harris-corner-based "reality lock") that pulls the result back
toward the original wherever the evidence is weak.

## Documentation

- **[ARCHITECTURE.md](ARCHITECTURE.md)** — module layout, key design
  decisions, and what's simplified vs. the original spec.
- **[PIPELINE.md](PIPELINE.md)** — the Stage 1–9 restoration pipeline,
  algorithm by algorithm, mapped to the actual source files.
- **[BUILD.md](BUILD.md)** — building locally in Android Studio, and how
  the included GitHub Actions workflow builds a CI APK.

## Tech stack

Kotlin · Android SDK/NDK · C++17 · JNI · CMake · Material Design 3 ·
MVVM · ViewBinding · Coroutines · WorkManager · Room

## Project layout

```
app/src/main/
├── cpp/            # Native restoration engine (C++17, no external CV library)
├── java/.../core/  # Cross-cutting models + the JNI wrapper
├── java/.../data/  # Room, the repository, WorkManager, export
├── java/.../ui/    # MVVM screens (home, editor, history, settings, batch)
└── res/            # Material 3 theme, vector icons, layouts
```

## Status of the spec's feature list

| Area | Status |
|---|---|
| Classical restoration pipeline (Stages 1–9) | Implemented — see PIPELINE.md |
| Restore / Enhance / Color tool panel | Implemented |
| Debug Mode (maps, reality score, stage timings) | Implemented |
| History, Favorites, Settings, About, Help | Implemented |
| Batch processing | Implemented (shared preset, not per-image tuning) |
| Export (PNG/JPEG/WebP, quality, metadata, folder) | Implemented |
| Crop / grid overlay / histogram | Not wired up — see ARCHITECTURE.md |
| TIFF export | Not implemented (spec marked it optional) |
| OpenCV | Not used — see ARCHITECTURE.md |
| Explicit face/eye detection in Reality Lock | Not implemented — protected via structural cues instead (see PIPELINE.md, Stage 8) |
