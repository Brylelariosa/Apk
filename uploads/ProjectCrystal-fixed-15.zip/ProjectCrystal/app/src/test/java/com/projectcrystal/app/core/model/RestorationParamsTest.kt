package com.projectcrystal.app.core.model

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * The native JNI boundary depends entirely on [RestorationParams.toNativeArray]
 * producing a fixed-length, fixed-order float array — a silent reordering
 * here would make every slider control the wrong thing natively without
 * any compile-time signal. These tests pin that contract down.
 */
class RestorationParamsTest {

    @Test
    fun `toNativeArray produces exactly PARAM_COUNT floats`() {
        val array = RestorationParams().toNativeArray()
        assertEquals(RestorationParams.PARAM_COUNT, array.size)
    }

    @Test
    fun `toNativeArray field order matches the documented native contract`() {
        val params = RestorationParams(
            blurStrength = 0.1f, noiseReduction = 0.2f, sharpness = 0.3f, textureRecovery = 0.4f,
            haloSuppression = 0.5f, frequencyStrength = 0.6f, contrast = 0.7f, brightness = 0.8f,
            saturation = 0.9f, temperature = 1.0f, tint = -0.5f, tileSize = 256,
            richardsonLucyIterations = 6, edgeEnhancement = 0.15f, localContrast = 0.25f,
        )
        val array = params.toNativeArray()

        assertEquals(0.1f, array[0], EPSILON)   // blurStrength
        assertEquals(0.2f, array[1], EPSILON)   // noiseReduction
        assertEquals(0.3f, array[2], EPSILON)   // sharpness
        assertEquals(0.4f, array[3], EPSILON)   // textureRecovery
        assertEquals(0.5f, array[4], EPSILON)   // haloSuppression
        assertEquals(0.6f, array[5], EPSILON)   // frequencyStrength
        assertEquals(0.7f, array[6], EPSILON)   // contrast
        assertEquals(0.8f, array[7], EPSILON)   // brightness
        assertEquals(0.9f, array[8], EPSILON)   // saturation
        assertEquals(1.0f, array[9], EPSILON)   // temperature
        assertEquals(-0.5f, array[10], EPSILON) // tint
        assertEquals(256f, array[11], EPSILON)  // tileSize
        assertEquals(6f, array[12], EPSILON)    // richardsonLucyIterations
        assertEquals(0.15f, array[13], EPSILON) // edgeEnhancement
        assertEquals(0.25f, array[14], EPSILON) // localContrast
    }

    @Test
    fun `forSpecialMode always returns the requested mode`() {
        SpecialMode.entries.forEach { mode ->
            assertEquals(mode, RestorationParams.forSpecialMode(mode).specialMode)
        }
    }

    @Test
    fun `document mode is tuned toward crisp edges over texture recovery`() {
        val documentParams = RestorationParams.forSpecialMode(SpecialMode.DOCUMENT)
        val defaultParams = RestorationParams()
        assertTrue(documentParams.frequencyStrength > defaultParams.frequencyStrength)
        assertTrue(documentParams.textureRecovery < defaultParams.textureRecovery)
    }

    companion object {
        private const val EPSILON = 1e-6f
    }
}
