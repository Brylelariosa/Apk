package com.projectcrystal.app.util

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Deliberately avoids android.graphics.Color: under Gradle's plain-JVM unit
 * tests (no Robolectric), Color's methods are stubbed to always return 0,
 * which would make brightness comparisons meaningless. ColormapUtil packs
 * ARGB with plain Int bit-shifts specifically so this logic is testable
 * without a device — this test reads pixel channels the same way.
 */
class ColormapUtilTest {

    private fun red(color: Int) = (color shr 16) and 0xFF
    private fun green(color: Int) = (color shr 8) and 0xFF
    private fun blue(color: Int) = color and 0xFF
    private fun alpha(color: Int) = (color shr 24) and 0xFF

    @Test
    fun `colorFor is deterministic for the same input`() {
        assertEquals(ColormapUtil.colorFor(0.42f), ColormapUtil.colorFor(0.42f))
    }

    @Test
    fun `colorFor clamps out-of-range input instead of crashing`() {
        assertEquals(ColormapUtil.colorFor(0f), ColormapUtil.colorFor(-5f))
        assertEquals(ColormapUtil.colorFor(1f), ColormapUtil.colorFor(5f))
    }

    @Test
    fun `colorFor is always fully opaque`() {
        assertEquals(255, alpha(ColormapUtil.colorFor(0.5f)))
    }

    @Test
    fun `colorFor moves from dark to bright across the range`() {
        val low = ColormapUtil.colorFor(0f)
        val high = ColormapUtil.colorFor(1f)
        val lowLuma = red(low) + green(low) + blue(low)
        val highLuma = red(high) + green(high) + blue(high)
        assertTrue("Colormap should get brighter from 0 to 1", highLuma > lowLuma)
    }

    @Test
    fun `colorFor interpolates smoothly between adjacent samples`() {
        val a = ColormapUtil.colorFor(0.30f)
        val b = ColormapUtil.colorFor(0.31f)
        // A 1% step should never jump by more than a small fraction of the full channel range.
        assertTrue(Math.abs(red(a) - red(b)) < 40)
        assertTrue(Math.abs(green(a) - green(b)) < 40)
        assertTrue(Math.abs(blue(a) - blue(b)) < 40)
    }
}
