package com.projectcrystal.app.util

import androidx.test.ext.junit.runners.AndroidJUnit4
import com.projectcrystal.app.core.model.DiagnosticMap
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith

/** Covers the real-Bitmap half of ColormapUtil that plain JVM unit tests can't exercise. */
@RunWith(AndroidJUnit4::class)
class ColormapUtilBitmapTest {

    @Test
    fun heatmapBitmapMatchesSourceDimensions() {
        val map = DiagnosticMap(width = 4, height = 3, values = FloatArray(12) { it / 11f })
        val bitmap = ColormapUtil.toHeatmapBitmap(map)
        assertEquals(4, bitmap.width)
        assertEquals(3, bitmap.height)
    }

    @Test
    fun heatmapPixelMatchesColorForAtEachPosition() {
        val values = floatArrayOf(0f, 0.5f, 1f, 0.25f)
        val map = DiagnosticMap(width = 2, height = 2, values = values)
        val bitmap = ColormapUtil.toHeatmapBitmap(map)

        assertEquals(ColormapUtil.colorFor(0f), bitmap.getPixel(0, 0))
        assertEquals(ColormapUtil.colorFor(0.5f), bitmap.getPixel(1, 0))
        assertEquals(ColormapUtil.colorFor(1f), bitmap.getPixel(0, 1))
        assertEquals(ColormapUtil.colorFor(0.25f), bitmap.getPixel(1, 1))
    }
}
