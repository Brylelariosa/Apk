package com.projectcrystal.app.ui

import androidx.test.core.app.ActivityScenario
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.matcher.ViewMatchers.isDisplayed
import androidx.test.espresso.matcher.ViewMatchers.withId
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.projectcrystal.app.R
import com.projectcrystal.app.ui.main.MainActivity
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Smoke test for the app shell: the activity launches without crashing and
 * the bottom navigation actually swaps the hosted fragment when tapped.
 * Deep per-screen behavior is covered by unit tests on the underlying
 * ViewModels/repositories rather than duplicated here.
 */
@RunWith(AndroidJUnit4::class)
class MainActivityNavigationTest {

    @Test
    fun launchesOnHomeAndShowsBottomNav() {
        ActivityScenario.launch(MainActivity::class.java).use {
            onView(withId(R.id.bottomNav)).check(matches(isDisplayed()))
            onView(withId(R.id.navHostFragment)).check(matches(isDisplayed()))
        }
    }

    @Test
    fun tappingHistoryTabSwitchesDestination() {
        ActivityScenario.launch(MainActivity::class.java).use {
            onView(withId(R.id.historyFragment)).perform(androidx.test.espresso.action.ViewActions.click())
            onView(withId(R.id.historyRecycler)).check(matches(isDisplayed()))
        }
    }
}
