package com.projectcrystal.app.data.db

import androidx.room.Room
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Runs against a real in-memory Room database on-device — the standard
 * pattern for verifying actual SQL behavior (queries, ordering, cascading
 * deletes) rather than mocking the DAO away.
 */
@RunWith(AndroidJUnit4::class)
class HistoryDaoTest {

    private lateinit var db: AppDatabase
    private lateinit var dao: HistoryDao

    @Before
    fun createDb() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        dao = db.historyDao()
    }

    @After
    fun closeDb() {
        db.close()
    }

    private fun sampleEntity(favorite: Boolean = false, createdAt: Long = System.currentTimeMillis()) = HistoryEntity(
        originalPath = "content://test/original.jpg",
        restoredPath = "/cache/restored.png",
        thumbnailPath = "/cache/thumb.jpg",
        createdAtEpochMs = createdAt,
        realityScore = 0.8f,
        specialMode = 0,
        paramsJson = "{}",
        isFavorite = favorite,
    )

    @Test
    fun insertAndRetrieveById() = runBlocking {
        val id = dao.insert(sampleEntity())
        val loaded = dao.getById(id)
        assertEquals("content://test/original.jpg", loaded?.originalPath)
    }

    @Test
    fun observeAllOrdersNewestFirst() = runBlocking {
        dao.insert(sampleEntity(createdAt = 1_000))
        dao.insert(sampleEntity(createdAt = 3_000))
        dao.insert(sampleEntity(createdAt = 2_000))

        val all = dao.observeAll().first()
        assertEquals(listOf(3_000L, 2_000L, 1_000L), all.map { it.createdAtEpochMs })
    }

    @Test
    fun observeFavoritesOnlyReturnsFavorited() = runBlocking {
        dao.insert(sampleEntity(favorite = true))
        dao.insert(sampleEntity(favorite = false))

        val favorites = dao.observeFavorites().first()
        assertEquals(1, favorites.size)
        assertTrue(favorites.all { it.isFavorite })
    }

    @Test
    fun updateTogglesFavoriteFlag() = runBlocking {
        val id = dao.insert(sampleEntity(favorite = false))
        val entity = dao.getById(id)!!
        dao.update(entity.copy(isFavorite = true))

        val reloaded = dao.getById(id)
        assertTrue(reloaded!!.isFavorite)
    }

    @Test
    fun deleteRemovesEntity() = runBlocking {
        val id = dao.insert(sampleEntity())
        val entity = dao.getById(id)!!
        dao.delete(entity)

        assertNull(dao.getById(id))
    }
}
