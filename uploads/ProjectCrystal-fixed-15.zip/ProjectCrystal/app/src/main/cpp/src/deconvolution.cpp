#include "deconvolution.h"
#include "convolution.h"
#include "fft.h"
#include <cmath>
#include <algorithm>
#include <complex>

namespace crystal {
namespace {

// Builds a (possibly elongated) Gaussian PSF, sampled on a (2*half+1)^2
// spatial grid, normalized to sum to 1. anisotropy in [0,1] elongates the
// kernel along directionRad to approximate directional motion blur; at
// anisotropy == 0 this is a plain isotropic Gaussian (defocus-like).
std::vector<float> buildGaussianPsf(int half, float blurRadius, float directionRad, float anisotropy) {
    const int size = 2 * half + 1;
    std::vector<float> kernel(static_cast<size_t>(size) * size);
    float sigmaAlong = std::max(0.6f, blurRadius * (1.0f + anisotropy * 1.5f));
    float sigmaAcross = std::max(0.6f, blurRadius * (1.0f - anisotropy * 0.6f));
    float cosT = std::cos(directionRad), sinT = std::sin(directionRad);

    double sum = 0.0;
    for (int j = -half; j <= half; ++j) {
        for (int i = -half; i <= half; ++i) {
            float du = i * cosT + j * sinT;
            float dv = -i * sinT + j * cosT;
            float v = std::exp(-(du * du) / (2.0f * sigmaAlong * sigmaAlong)
                                - (dv * dv) / (2.0f * sigmaAcross * sigmaAcross));
            kernel[(j + half) * size + (i + half)] = v;
            sum += v;
        }
    }
    for (auto& v : kernel) v = static_cast<float>(v / sum);
    return kernel;
}

} // namespace

FloatImage Deconvolution::wiener(const FloatImage& tileY, float blurRadius, float directionRad,
                                  float anisotropy, float noiseToSignalRatio) {
    const int tileW = tileY.width(), tileH = tileY.height();
    const int half = std::max(1, static_cast<int>(std::round(blurRadius * 2.0f)));

    const int paddedW = fft::nextPowerOfTwo(tileW + 2 * half);
    const int paddedH = fft::nextPowerOfTwo(tileH + 2 * half);

    // Edge-replicated padding (via sampleClamped) avoids the hard
    // discontinuity a hard zero-pad would introduce at tile borders, which
    // otherwise shows up as ringing along the tile edges after the inverse
    // FFT.
    std::vector<std::complex<float>> image(static_cast<size_t>(paddedW) * paddedH);
    for (int y = 0; y < paddedH; ++y)
        for (int x = 0; x < paddedW; ++x)
            image[static_cast<size_t>(y) * paddedW + x] = std::complex<float>(tileY.sampleClamped(x, y, 0), 0.0f);

    // PSF placed "wrapped around the origin" (standard FFT convolution
    // convention) so the result isn't spatially shifted.
    std::vector<float> psf = buildGaussianPsf(half, blurRadius, directionRad, anisotropy);
    const int psfSize = 2 * half + 1;
    std::vector<std::complex<float>> psfImg(static_cast<size_t>(paddedW) * paddedH, std::complex<float>(0, 0));
    for (int j = -half; j <= half; ++j) {
        for (int i = -half; i <= half; ++i) {
            int px = ((i % paddedW) + paddedW) % paddedW;
            int py = ((j % paddedH) + paddedH) % paddedH;
            psfImg[static_cast<size_t>(py) * paddedW + px] = psf[(j + half) * psfSize + (i + half)];
        }
    }

    fft::fft2D(image, paddedW, paddedH, false);
    fft::fft2D(psfImg, paddedW, paddedH, false);

    const float K = std::clamp(noiseToSignalRatio, 1e-4f, 1.0f);
    for (size_t i = 0; i < image.size(); ++i) {
        std::complex<float> H = psfImg[i];
        float magSq = std::norm(H); // |H|^2
        std::complex<float> wienerFactor = std::conj(H) / (magSq + K);
        image[i] *= wienerFactor;
    }

    fft::fft2D(image, paddedW, paddedH, true);

    FloatImage out(tileW, tileH, 1);
    for (int y = 0; y < tileH; ++y)
        for (int x = 0; x < tileW; ++x)
            out.at(x, y, 0) = image[static_cast<size_t>(y) * paddedW + x].real();
    out.clamp(0.0f, 1.0f);
    return out;
}

FloatImage Deconvolution::richardsonLucy(const FloatImage& tileY, float blurRadius, float directionRad,
                                          float anisotropy, int iterations) {
    iterations = std::clamp(iterations, 1, 15); // spec calls for "limited iterations"
    const int half = std::max(1, static_cast<int>(std::round(blurRadius * 1.6f)));
    const int psfSize = 2 * half + 1;
    std::vector<float> psf = buildGaussianPsf(half, blurRadius, directionRad, anisotropy);
    // The PSF used here is a symmetric Gaussian, so its 180-degree-rotated
    // version (needed for the RL correction pass) is identical to itself;
    // built explicitly anyway so the algorithm stays correct if the PSF
    // model is ever swapped for something asymmetric.
    std::vector<float> psfFlipped(psf.size());
    for (int j = 0; j < psfSize; ++j)
        for (int i = 0; i < psfSize; ++i)
            psfFlipped[j * psfSize + i] = psf[(psfSize - 1 - j) * psfSize + (psfSize - 1 - i)];

    FloatImage estimate = tileY.clone();
    const int w = tileY.width(), h = tileY.height();

    for (int iter = 0; iter < iterations; ++iter) {
        FloatImage blurredEstimate = conv::convolve2D(estimate, psf, psfSize, psfSize);

        FloatImage relativeBlur(w, h, 1);
        for (int i = 0; i < w * h; ++i) {
            float denom = std::max(blurredEstimate.raw()[i], 1e-4f);
            // Clamp the ratio: an unclamped RL update can explode noise in
            // near-zero-signal regions after a few iterations.
            relativeBlur.raw()[i] = std::clamp(tileY.raw()[i] / denom, 0.0f, 4.0f);
        }

        FloatImage correction = conv::convolve2D(relativeBlur, psfFlipped, psfSize, psfSize);

        for (int i = 0; i < w * h; ++i) {
            estimate.raw()[i] = std::clamp(estimate.raw()[i] * correction.raw()[i], 0.0f, 1.0f);
        }
    }

    return estimate;
}

} // namespace crystal
