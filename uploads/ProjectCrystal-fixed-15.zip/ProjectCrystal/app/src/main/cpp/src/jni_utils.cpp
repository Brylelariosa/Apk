#include "jni_utils.h"
#include <android/bitmap.h>
#include <android/log.h>
#include <algorithm>
#include <cmath>
#include <vector>

#define LOG_TAG "CrystalJNI"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace crystal {
namespace jniutil {
namespace {

void throwIllegalArgument(JNIEnv* env, const char* message) {
    jclass cls = env->FindClass("java/lang/IllegalArgumentException");
    if (cls != nullptr) env->ThrowNew(cls, message);
}

// Simple block-average downsample. Debug-map quality only needs to be good
// enough for a heatmap preview, so a fast box average (rather than a proper
// filtered resample) is a deliberate, documented simplification.
FloatImage downsample(const FloatImage& src, int maxDimension) {
    int longSide = std::max(src.width(), src.height());
    if (longSide <= maxDimension) return src.clone();

    float scale = static_cast<float>(maxDimension) / static_cast<float>(longSide);
    int dstW = std::max(1, static_cast<int>(src.width() * scale));
    int dstH = std::max(1, static_cast<int>(src.height() * scale));

    FloatImage dst(dstW, dstH, 1);
    for (int dy = 0; dy < dstH; ++dy) {
        int srcY0 = dy * src.height() / dstH;
        int srcY1 = std::max(srcY0 + 1, (dy + 1) * src.height() / dstH);
        for (int dx = 0; dx < dstW; ++dx) {
            int srcX0 = dx * src.width() / dstW;
            int srcX1 = std::max(srcX0 + 1, (dx + 1) * src.width() / dstW);
            double sum = 0.0;
            int count = 0;
            for (int sy = srcY0; sy < srcY1; ++sy) {
                for (int sx = srcX0; sx < srcX1; ++sx) {
                    sum += src.at(sx, sy, 0);
                    ++count;
                }
            }
            dst.at(dx, dy, 0) = count > 0 ? static_cast<float>(sum / count) : 0.0f;
        }
    }
    return dst;
}

jfloatArray toJavaFloatArray(JNIEnv* env, const FloatImage& map) {
    jfloatArray array = env->NewFloatArray(static_cast<jsize>(map.raw().size()));
    if (array != nullptr) {
        env->SetFloatArrayRegion(array, 0, static_cast<jsize>(map.raw().size()), map.raw().data());
    }
    return array;
}

} // namespace

FloatImage bitmapToFloatImage(JNIEnv* env, jobject bitmap) {
    AndroidBitmapInfo info;
    if (AndroidBitmap_getInfo(env, bitmap, &info) != ANDROID_BITMAP_RESULT_SUCCESS) {
        throwIllegalArgument(env, "Unable to read bitmap info");
        return FloatImage();
    }
    if (info.format != ANDROID_BITMAP_FORMAT_RGBA_8888) {
        throwIllegalArgument(env, "Bitmap must be ARGB_8888");
        return FloatImage();
    }

    void* pixels = nullptr;
    if (AndroidBitmap_lockPixels(env, bitmap, &pixels) != ANDROID_BITMAP_RESULT_SUCCESS) {
        throwIllegalArgument(env, "Unable to lock bitmap pixels");
        return FloatImage();
    }

    FloatImage result = FloatImage::fromARGB8888(
        static_cast<const uint8_t*>(pixels), static_cast<int>(info.width), static_cast<int>(info.height),
        static_cast<int>(info.stride));

    AndroidBitmap_unlockPixels(env, bitmap);
    return result;
}

void floatImageToBitmap(JNIEnv* env, jobject bitmap, const FloatImage& image) {
    AndroidBitmapInfo info;
    if (AndroidBitmap_getInfo(env, bitmap, &info) != ANDROID_BITMAP_RESULT_SUCCESS) {
        throwIllegalArgument(env, "Unable to read output bitmap info");
        return;
    }
    if (info.format != ANDROID_BITMAP_FORMAT_RGBA_8888 ||
        static_cast<int>(info.width) != image.width() || static_cast<int>(info.height) != image.height()) {
        throwIllegalArgument(env, "Output bitmap must be ARGB_8888 and match the input's dimensions");
        return;
    }

    void* pixels = nullptr;
    if (AndroidBitmap_lockPixels(env, bitmap, &pixels) != ANDROID_BITMAP_RESULT_SUCCESS) {
        throwIllegalArgument(env, "Unable to lock output bitmap pixels");
        return;
    }

    image.toARGB8888(static_cast<uint8_t*>(pixels), static_cast<int>(info.stride));
    AndroidBitmap_unlockPixels(env, bitmap);
}

RestorationParams unpackParams(JNIEnv* env, jfloatArray paramsArray, jint specialMode, jboolean conservativeMode) {
    RestorationParams params;
    jsize len = env->GetArrayLength(paramsArray);
    if (len < kRestorationParamFloatCount) {
        throwIllegalArgument(env, "Params array is shorter than expected");
        return params;
    }

    std::vector<float> p(kRestorationParamFloatCount);
    env->GetFloatArrayRegion(paramsArray, 0, kRestorationParamFloatCount, p.data());

    // Defense-in-depth clamps: these values normally come from UI sliders
    // (already range-limited) but can also be reloaded from a persisted
    // HistoryEntity.paramsJson blob via Gson, which bypasses Kotlin
    // constructor/property validation entirely (reflective field assignment).
    // A hand-edited or corrupted JSON blob should degrade gracefully rather
    // than feed out-of-range values into the numerical pipeline.
    auto clamp01 = [](float v) { return std::clamp(v, 0.0f, 1.0f); };
    auto clampBipolar = [](float v) { return std::clamp(v, -1.0f, 1.0f); };

    params.blurStrength = clamp01(p[0]);
    params.noiseReduction = clamp01(p[1]);
    params.sharpness = clamp01(p[2]);
    params.textureRecovery = clamp01(p[3]);
    params.haloSuppression = clamp01(p[4]);
    params.frequencyStrength = clamp01(p[5]);
    params.contrast = clampBipolar(p[6]);
    params.brightness = clampBipolar(p[7]);
    params.saturation = clampBipolar(p[8]);
    params.temperature = clampBipolar(p[9]);
    params.tint = clampBipolar(p[10]);
    // Upper bound matches the largest tile size ever offered in the UI
    // (512px) with headroom; without it a corrupted paramsJson could request
    // an arbitrarily large single tile and defeat the tiling memory budget.
    params.tileSize = std::clamp(static_cast<int>(std::round(p[11])), 64, 1024);
    params.richardsonLucyIterations = std::clamp(static_cast<int>(std::round(p[12])), 1, 15);
    params.edgeEnhancement = clamp01(p[13]);
    params.localContrast = clamp01(p[14]);
    params.conservativeMode = (conservativeMode != JNI_FALSE);
    params.specialMode = static_cast<SpecialMode>(specialMode);

    return params;
}

jobject buildMetricsObject(JNIEnv* env, const PipelineOutput& out, int maxDimension) {
    jclass cls = env->FindClass("com/projectcrystal/app/core/native/RestorationMetricsNative");
    if (cls == nullptr) {
        LOGE("RestorationMetricsNative class not found");
        return nullptr;
    }
    jmethodID ctor = env->GetMethodID(cls, "<init>", "(FII[F[F[F[F[FDDDDDDDDDDDDI)V");
    if (ctor == nullptr) {
        LOGE("RestorationMetricsNative constructor not found");
        return nullptr;
    }

    FloatImage blur = downsample(out.blurMap, maxDimension);
    FloatImage noise = downsample(out.noiseMap, maxDimension);
    FloatImage edge = downsample(out.edgeMap, maxDimension);
    FloatImage confidence = downsample(out.confidenceMap, maxDimension);
    FloatImage artifact = downsample(out.artifactMap, maxDimension);
    // All five maps share dimensions (identical source resolution + the
    // same downsample() call), so one width/height pair describes all of
    // them on the Kotlin side.
    jint mapWidth = blur.width();
    jint mapHeight = blur.height();

    jfloatArray blurArr = toJavaFloatArray(env, blur);
    jfloatArray noiseArr = toJavaFloatArray(env, noise);
    jfloatArray edgeArr = toJavaFloatArray(env, edge);
    jfloatArray confidenceArr = toJavaFloatArray(env, confidence);
    jfloatArray artifactArr = toJavaFloatArray(env, artifact);

    if (blurArr == nullptr || noiseArr == nullptr || edgeArr == nullptr ||
        confidenceArr == nullptr || artifactArr == nullptr) {
        // NewFloatArray only fails on OOM, in which case it already threw;
        // bail out rather than passing a null into RestorationMetricsNative's
        // non-nullable FloatArray constructor parameters.
        return nullptr;
    }

    return env->NewObject(cls, ctor,
                           out.realityScore, mapWidth, mapHeight,
                           blurArr, noiseArr, edgeArr, confidenceArr, artifactArr,
                           out.stats.analysisMs, out.stats.candidateGenMs, out.stats.consensusMs,
                           out.stats.artifactMs, out.stats.frequencyGateMs, out.stats.realityLockMs,
                           out.stats.blendMs, out.stats.totalMs,
                           out.stats.consensusDelta, out.stats.artifactDelta,
                           out.stats.freqGateDelta, out.stats.realityLockDelta,
                           out.stats.tileCount);
}

} // namespace jniutil
} // namespace crystal
