#include "fft.h"
#include <cmath>

namespace crystal {
namespace fft {

int nextPowerOfTwo(int n) {
    int p = 1;
    while (p < n) p <<= 1;
    return p;
}

void fft1D(std::vector<std::complex<float>>& a, bool inverse) {
    const size_t n = a.size();
    if (n <= 1) return;

    // Bit-reversal permutation.
    for (size_t i = 1, j = 0; i < n; ++i) {
        size_t bit = n >> 1;
        for (; j & bit; bit >>= 1) j ^= bit;
        j ^= bit;
        if (i < j) std::swap(a[i], a[j]);
    }

    for (size_t len = 2; len <= n; len <<= 1) {
        const float angleSign = inverse ? 1.0f : -1.0f;
        const float theta = angleSign * 2.0f * static_cast<float>(M_PI) / static_cast<float>(len);
        const std::complex<float> wLen(std::cos(theta), std::sin(theta));
        for (size_t i = 0; i < n; i += len) {
            std::complex<float> w(1.0f, 0.0f);
            for (size_t k = 0; k < len / 2; ++k) {
                std::complex<float> u = a[i + k];
                std::complex<float> v = a[i + k + len / 2] * w;
                a[i + k] = u + v;
                a[i + k + len / 2] = u - v;
                w *= wLen;
            }
        }
    }

    if (inverse) {
        for (auto& x : a) x /= static_cast<float>(n);
    }
}

void fft2D(std::vector<std::complex<float>>& data, int w, int h, bool inverse) {
    // Rows.
    std::vector<std::complex<float>> row(w);
    for (int y = 0; y < h; ++y) {
        for (int x = 0; x < w; ++x) row[x] = data[static_cast<size_t>(y) * w + x];
        fft1D(row, inverse);
        for (int x = 0; x < w; ++x) data[static_cast<size_t>(y) * w + x] = row[x];
    }
    // Columns.
    std::vector<std::complex<float>> col(h);
    for (int x = 0; x < w; ++x) {
        for (int y = 0; y < h; ++y) col[y] = data[static_cast<size_t>(y) * w + x];
        fft1D(col, inverse);
        for (int y = 0; y < h; ++y) data[static_cast<size_t>(y) * w + x] = col[y];
    }
}

} // namespace fft
} // namespace crystal
