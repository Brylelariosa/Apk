#include "reality_lock.h"
#include "convolution.h"
#include <algorithm>
#include <cmath>

namespace crystal {

FloatImage RealityLock::computeCornerResponse(const FloatImage& grayOrY) {
    const int w = grayOrY.width(), h = grayOrY.height();

    // Harris corner response (Harris & Stephens, 1988): a classical,
    // zero-training closed-form measure of "cornerness" from the local
    // structure tensor. High response = corners, line junctions, fine
    // textured strokes — the things thin structures and text are made of.
    FloatImage gx, gy;
    conv::sobelGradients(grayOrY, gx, gy);
    FloatImage ixx(w, h, 1), iyy(w, h, 1), ixy(w, h, 1);
    for (int i = 0; i < w * h; ++i) {
        ixx.raw()[i] = gx.raw()[i] * gx.raw()[i];
        iyy.raw()[i] = gy.raw()[i] * gy.raw()[i];
        ixy.raw()[i] = gx.raw()[i] * gy.raw()[i];
    }
    ixx = conv::boxBlur(ixx, 2);
    iyy = conv::boxBlur(iyy, 2);
    ixy = conv::boxBlur(ixy, 2);

    constexpr float kHarrisK = 0.04f;
    FloatImage cornerResponse(w, h, 1);
    for (int i = 0; i < w * h; ++i) {
        float sxx = ixx.raw()[i], syy = iyy.raw()[i], sxy = ixy.raw()[i];
        float det = sxx * syy - sxy * sxy;
        float trace = sxx + syy;
        cornerResponse.raw()[i] = std::max(0.0f, det - kHarrisK * trace * trace);
    }
    return cornerResponse;
}

FloatImage RealityLock::protect(const FloatImage& restoredY, const FloatImage& originalY,
                                 const FloatImage& edgeMagnitude, const FloatImage& cornerResponse,
                                 float protectionStrength, float maxEdgeGlobal, float maxCornerGlobal) {
    const int w = originalY.width(), h = originalY.height();
    const float maxEdge = std::max(maxEdgeGlobal, 1e-6f);
    const float maxCorner = std::max(maxCornerGlobal, 1e-6f);

    FloatImage out(w, h, 1);
    for (int i = 0; i < w * h; ++i) {
        float normEdge = std::clamp(edgeMagnitude.raw()[i] / maxEdge, 0.0f, 1.0f);
        float normCorner = std::sqrt(std::clamp(cornerResponse.raw()[i] / maxCorner, 0.0f, 1.0f)); // sqrt compresses the long tail
        float importance = std::max(normEdge, normCorner);

        float weight = importance * protectionStrength;
        out.raw()[i] = restoredY.raw()[i] * (1.0f - weight) + originalY.raw()[i] * weight;
    }
    return out;
}

} // namespace crystal
