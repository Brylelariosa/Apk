#include "noise_estimator.h"
#include <cmath>
#include <algorithm>

namespace crystal {

float NoiseEstimator::estimateSigma(const FloatImage& grayTile) {
    // Immerkaer's fast noise estimator: convolve with the mask
    //   [ 1 -2  1 ]
    //   [-2  4 -2 ]
    //   [ 1 -2  1 ]
    // which has a zero response on any locally-planar or linear-gradient
    // signal, so (ideally) only noise contributes to it. Sigma follows from
    // a closed-form scaling of the mean absolute response.
    const int w = grayTile.width();
    const int h = grayTile.height();
    if (w < 3 || h < 3) return 0.0f;

    double sum = 0.0;
    for (int y = 1; y < h - 1; ++y) {
        for (int x = 1; x < w - 1; ++x) {
            double v =
                grayTile.at(x - 1, y - 1, 0) - 2.0 * grayTile.at(x, y - 1, 0) + grayTile.at(x + 1, y - 1, 0)
              - 2.0 * grayTile.at(x - 1, y, 0) + 4.0 * grayTile.at(x, y, 0) - 2.0 * grayTile.at(x + 1, y, 0)
              + grayTile.at(x - 1, y + 1, 0) - 2.0 * grayTile.at(x, y + 1, 0) + grayTile.at(x + 1, y + 1, 0);
            sum += std::abs(v);
        }
    }

    const double norm = std::sqrt(M_PI / 2.0) / (6.0 * (w - 2) * (h - 2));
    double sigma = norm * sum;
    return static_cast<float>(std::clamp(sigma, 0.0, 1.0));
}

} // namespace crystal
