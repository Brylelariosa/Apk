#include "tile_processor.h"
#include <algorithm>
#include <cmath>

namespace crystal {
namespace {

// Raised-cosine crossfade: f(0)=0, f(1)=1, and critically f(t)+f(1-t)=1 for
// all t — which is exactly what makes two neighboring tiles' ramps sum to
// a clean 1.0 across their shared overlap band with no seam.
float raisedCosine(float t) {
    t = std::clamp(t, 0.0f, 1.0f);
    return 0.5f - 0.5f * std::cos(static_cast<float>(M_PI) * t);
}

// Weight contribution from a single edge: 1.0 once you're `2*overlap` px
// inside the tile from that edge, ramping down to 0 exactly at the edge —
// but only if that edge actually borders a neighbor (otherwise it's a true
// image boundary and there's nothing to blend against, so weight stays 1).
float edgeRampWeight(int distFromEdge, int overlap, bool hasNeighbor) {
    if (!hasNeighbor || overlap <= 0) return 1.0f;
    const int band = 2 * overlap;
    if (distFromEdge >= band) return 1.0f;
    float t = (distFromEdge + 0.5f) / static_cast<float>(band);
    return raisedCosine(t);
}

} // namespace

std::vector<TileProcessor::Tile> TileProcessor::computeAdaptiveTiles(int imgW, int imgH, int baseTileSize,
                                                                       int overlap) {
    std::vector<Tile> tiles;
    const int cols = (imgW + baseTileSize - 1) / baseTileSize;
    const int rows = (imgH + baseTileSize - 1) / baseTileSize;

    for (int row = 0; row < rows; ++row) {
        for (int col = 0; col < cols; ++col) {
            int coreX0 = col * baseTileSize;
            int coreY0 = row * baseTileSize;
            int coreX1 = std::min(imgW, coreX0 + baseTileSize);
            int coreY1 = std::min(imgH, coreY0 + baseTileSize);

            Tile tile;
            tile.hasLeftNeighbor = coreX0 > 0;
            tile.hasRightNeighbor = coreX1 < imgW;
            tile.hasTopNeighbor = coreY0 > 0;
            tile.hasBottomNeighbor = coreY1 < imgH;

            int x0 = tile.hasLeftNeighbor ? coreX0 - overlap : coreX0;
            int x1 = tile.hasRightNeighbor ? coreX1 + overlap : coreX1;
            int y0 = tile.hasTopNeighbor ? coreY0 - overlap : coreY0;
            int y1 = tile.hasBottomNeighbor ? coreY1 + overlap : coreY1;

            x0 = std::max(0, x0);
            y0 = std::max(0, y0);
            x1 = std::min(imgW, x1);
            y1 = std::min(imgH, y1);

            tile.x = x0;
            tile.y = y0;
            tile.w = x1 - x0;
            tile.h = y1 - y0;
            tiles.push_back(tile);
        }
    }
    return tiles;
}

void TileProcessor::accumulateTile(FloatImage& output, FloatImage& weightAccum, const FloatImage& tileResult,
                                    const Tile& tile, int overlap) {
    const int channels = output.channels();
    for (int j = 0; j < tile.h; ++j) {
        for (int i = 0; i < tile.w; ++i) {
            float wx = edgeRampWeight(i, overlap, tile.hasLeftNeighbor) *
                       edgeRampWeight(tile.w - 1 - i, overlap, tile.hasRightNeighbor);
            float wy = edgeRampWeight(j, overlap, tile.hasTopNeighbor) *
                       edgeRampWeight(tile.h - 1 - j, overlap, tile.hasBottomNeighbor);
            float weight = wx * wy;

            int gx = tile.x + i, gy = tile.y + j;
            for (int c = 0; c < channels; ++c) {
                output.at(gx, gy, c) += tileResult.at(i, j, c) * weight;
            }
            weightAccum.at(gx, gy, 0) += weight;
        }
    }
}

void TileProcessor::finalizeBlend(FloatImage& output, const FloatImage& weightAccum) {
    const int channels = output.channels();
    for (int y = 0; y < output.height(); ++y) {
        for (int x = 0; x < output.width(); ++x) {
            float w = std::max(weightAccum.at(x, y, 0), 1e-4f);
            for (int c = 0; c < channels; ++c) {
                output.at(x, y, c) /= w;
            }
        }
    }
}

} // namespace crystal
