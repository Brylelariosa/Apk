#include "artifact_detector.h"
#include <algorithm>
#include <cmath>

namespace crystal {

ArtifactDetector::ArtifactMap ArtifactDetector::detect(const FloatImage& originalY, const FloatImage& restoredY) {
    ArtifactMap result;
    const int w = originalY.width(), h = originalY.height();
    result.severity = FloatImage(w, h, 1);

    double severitySum = 0.0;
    // Window over which we consider a value "locally plausible": a 3x3
    // neighborhood's min/max in the *original*, expanded by a small
    // tolerance for legitimate contrast increase. Anything past that is
    // scored as overshoot — the halo/ringing signature.
    constexpr float kTolerance = 0.04f;
    for (int y = 0; y < h; ++y) {
        for (int x = 0; x < w; ++x) {
            float mn = 1e9f, mx = -1e9f;
            for (int dy = -1; dy <= 1; ++dy) {
                for (int dx = -1; dx <= 1; ++dx) {
                    float v = originalY.sampleClamped(x + dx, y + dy, 0);
                    mn = std::min(mn, v);
                    mx = std::max(mx, v);
                }
            }
            float restored = restoredY.at(x, y, 0);
            float overshoot = std::max(0.0f, restored - (mx + kTolerance));
            float undershoot = std::max(0.0f, (mn - kTolerance) - restored);
            float rangeSpan = std::max(mx - mn, 0.02f); // avoid dividing by ~0 in flat regions
            float severity = std::clamp((overshoot + undershoot) / rangeSpan, 0.0f, 1.0f);
            result.severity.at(x, y, 0) = severity;
            severitySum += severity;
        }
    }
    result.overallSeverity = static_cast<float>(severitySum / (w * h));
    return result;
}

FloatImage ArtifactDetector::suppress(const FloatImage& restoredY, const FloatImage& originalY,
                                       const ArtifactMap& artifacts, float strength) {
    const int n = restoredY.width() * restoredY.height();
    FloatImage out(restoredY.width(), restoredY.height(), 1);
    for (int i = 0; i < n; ++i) {
        float w = std::clamp(artifacts.severity.raw()[i] * strength, 0.0f, 1.0f);
        out.raw()[i] = restoredY.raw()[i] * (1.0f - w) + originalY.raw()[i] * w;
    }
    return out;
}

} // namespace crystal
