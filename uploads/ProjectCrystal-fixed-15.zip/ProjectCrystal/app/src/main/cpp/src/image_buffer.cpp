#include "image_buffer.h"
#include <algorithm>
#include <cassert>

namespace crystal {

FloatImage::FloatImage(int width, int height, int channels, float fill)
    : width_(width), height_(height), channels_(channels),
      data_(static_cast<size_t>(width) * height * channels, fill) {}

float& FloatImage::at(int x, int y, int c) {
    return data_[(static_cast<size_t>(y) * width_ + x) * channels_ + c];
}

float FloatImage::at(int x, int y, int c) const {
    return data_[(static_cast<size_t>(y) * width_ + x) * channels_ + c];
}

float FloatImage::sampleClamped(int x, int y, int c) const {
    x = std::clamp(x, 0, width_ - 1);
    y = std::clamp(y, 0, height_ - 1);
    return at(x, y, c);
}

FloatImage FloatImage::clone() const {
    FloatImage copy(width_, height_, channels_);
    copy.data_ = data_;
    return copy;
}

FloatImage FloatImage::crop(int x, int y, int w, int h) const {
    FloatImage out(w, h, channels_);
    for (int j = 0; j < h; ++j) {
        for (int i = 0; i < w; ++i) {
            for (int c = 0; c < channels_; ++c) {
                out.at(i, j, c) = sampleClamped(x + i, y + j, c);
            }
        }
    }
    return out;
}

FloatImage FloatImage::fromARGB8888(const uint8_t* pixels, int width, int height, int strideBytes) {
    FloatImage out(width, height, 3);
    for (int y = 0; y < height; ++y) {
        const uint8_t* row = pixels + static_cast<size_t>(y) * strideBytes;
        for (int x = 0; x < width; ++x) {
            const uint8_t* px = row + x * 4; // R,G,B,A (Android ARGB_8888 is byte-order R,G,B,A)
            out.at(x, y, 0) = px[0] / 255.0f;
            out.at(x, y, 1) = px[1] / 255.0f;
            out.at(x, y, 2) = px[2] / 255.0f;
        }
    }
    return out;
}

void FloatImage::toARGB8888(uint8_t* pixels, int strideBytes) const {
    assert(channels_ == 3);
    for (int y = 0; y < height_; ++y) {
        uint8_t* row = pixels + static_cast<size_t>(y) * strideBytes;
        for (int x = 0; x < width_; ++x) {
            uint8_t* px = row + x * 4;
            px[0] = static_cast<uint8_t>(std::clamp(at(x, y, 0), 0.0f, 1.0f) * 255.0f + 0.5f);
            px[1] = static_cast<uint8_t>(std::clamp(at(x, y, 1), 0.0f, 1.0f) * 255.0f + 0.5f);
            px[2] = static_cast<uint8_t>(std::clamp(at(x, y, 2), 0.0f, 1.0f) * 255.0f + 0.5f);
            px[3] = 255;
        }
    }
}

FloatImage FloatImage::toYCbCr() const {
    assert(channels_ == 3);
    FloatImage out(width_, height_, 3);
    for (int y = 0; y < height_; ++y) {
        for (int x = 0; x < width_; ++x) {
            float r = at(x, y, 0), g = at(x, y, 1), b = at(x, y, 2);
            float Y  = 0.299f * r + 0.587f * g + 0.114f * b;
            float Cb = -0.168736f * r - 0.331264f * g + 0.5f * b + 0.5f;
            float Cr = 0.5f * r - 0.418688f * g - 0.081312f * b + 0.5f;
            out.at(x, y, 0) = Y;
            out.at(x, y, 1) = Cb;
            out.at(x, y, 2) = Cr;
        }
    }
    return out;
}

FloatImage FloatImage::fromYCbCr(const FloatImage& ycbcr) {
    FloatImage out(ycbcr.width(), ycbcr.height(), 3);
    for (int y = 0; y < ycbcr.height(); ++y) {
        for (int x = 0; x < ycbcr.width(); ++x) {
            float Y = ycbcr.at(x, y, 0);
            float Cb = ycbcr.at(x, y, 1) - 0.5f;
            float Cr = ycbcr.at(x, y, 2) - 0.5f;
            out.at(x, y, 0) = Y + 1.402f * Cr;
            out.at(x, y, 1) = Y - 0.344136f * Cb - 0.714136f * Cr;
            out.at(x, y, 2) = Y + 1.772f * Cb;
        }
    }
    out.clamp(0.0f, 1.0f);
    return out;
}

FloatImage FloatImage::toGrayscale() const {
    if (channels_ == 1) return clone();
    FloatImage out(width_, height_, 1);
    for (int y = 0; y < height_; ++y) {
        for (int x = 0; x < width_; ++x) {
            out.at(x, y, 0) = 0.299f * at(x, y, 0) + 0.587f * at(x, y, 1) + 0.114f * at(x, y, 2);
        }
    }
    return out;
}

void FloatImage::clamp(float lo, float hi) {
    for (auto& v : data_) v = std::clamp(v, lo, hi);
}

FloatImage FloatImage::channel(int c) const {
    FloatImage out(width_, height_, 1);
    for (int y = 0; y < height_; ++y)
        for (int x = 0; x < width_; ++x)
            out.at(x, y, 0) = at(x, y, c);
    return out;
}

void FloatImage::setChannel(int c, const FloatImage& src) {
    for (int y = 0; y < height_; ++y)
        for (int x = 0; x < width_; ++x)
            at(x, y, c) = src.at(x, y, 0);
}

} // namespace crystal
