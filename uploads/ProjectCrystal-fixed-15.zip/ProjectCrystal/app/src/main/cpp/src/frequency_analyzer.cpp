#include "frequency_analyzer.h"
#include "convolution.h"
#include <cmath>
#include <algorithm>

namespace crystal {

FrequencyAnalyzer::Bands FrequencyAnalyzer::decompose(const FloatImage& gray) {
    Bands bands;
    FloatImage lightBlur = conv::gaussianBlur(gray, 1.2f);
    FloatImage heavyBlur = conv::gaussianBlur(gray, 3.5f);

    bands.low = heavyBlur;

    bands.mid = FloatImage(gray.width(), gray.height(), 1);
    for (size_t i = 0; i < bands.mid.raw().size(); ++i)
        bands.mid.raw()[i] = lightBlur.raw()[i] - heavyBlur.raw()[i];

    bands.high = FloatImage(gray.width(), gray.height(), 1);
    for (size_t i = 0; i < bands.high.raw().size(); ++i)
        bands.high.raw()[i] = gray.raw()[i] - lightBlur.raw()[i];

    return bands;
}

FloatImage FrequencyAnalyzer::bandAgreementMap(const Bands& bands) {
    const int w = bands.mid.width(), h = bands.mid.height();
    FloatImage midAbs(w, h, 1), highAbs(w, h, 1);
    for (int i = 0; i < w * h; ++i) {
        midAbs.raw()[i] = std::abs(bands.mid.raw()[i]);
        highAbs.raw()[i] = std::abs(bands.high.raw()[i]);
    }

    // Local (box-filtered) normalized cross-correlation between the two
    // rectified bands: high where a fine-detail pixel sits on top of
    // meaningful mid-band structure, low where it's isolated.
    constexpr int kWindow = 3;
    FloatImage meanMid = conv::boxBlur(midAbs, kWindow);
    FloatImage meanHigh = conv::boxBlur(highAbs, kWindow);

    FloatImage product(w, h, 1);
    for (int i = 0; i < w * h; ++i) product.raw()[i] = midAbs.raw()[i] * highAbs.raw()[i];
    FloatImage meanProduct = conv::boxBlur(product, kWindow);

    FloatImage agreement(w, h, 1);
    for (int i = 0; i < w * h; ++i) {
        float denom = meanMid.raw()[i] * meanHigh.raw()[i] + 1e-5f;
        float corr = meanProduct.raw()[i] / denom;
        agreement.raw()[i] = std::clamp(corr, 0.0f, 1.0f);
    }
    return agreement;
}

} // namespace crystal
