#include "edge_aware_enhancer.h"
#include "convolution.h"
#include <algorithm>
#include <cmath>

namespace crystal {

FloatImage EdgeAwareEnhancer::guidedFilter(const FloatImage& guide, const FloatImage& src, int radius, float eps) {
    // Closed-form local linear model: q = a*I + b, fit per-window by least
    // squares, then a/b themselves are averaged across overlapping windows.
    // All of it reduces to box filters, so this is just a handful of mean
    // filters plus elementwise arithmetic — no external solver needed.
    FloatImage meanI = conv::boxBlur(guide, radius);
    FloatImage meanP = conv::boxBlur(src, radius);

    const int n = guide.width() * guide.height();
    FloatImage corrI(guide.width(), guide.height(), 1);
    FloatImage corrIp(guide.width(), guide.height(), 1);
    for (int i = 0; i < n; ++i) {
        corrI.raw()[i] = guide.raw()[i] * guide.raw()[i];
        corrIp.raw()[i] = guide.raw()[i] * src.raw()[i];
    }
    corrI = conv::boxBlur(corrI, radius);
    corrIp = conv::boxBlur(corrIp, radius);

    FloatImage a(guide.width(), guide.height(), 1), b(guide.width(), guide.height(), 1);
    for (int i = 0; i < n; ++i) {
        float varI = corrI.raw()[i] - meanI.raw()[i] * meanI.raw()[i];
        float covIp = corrIp.raw()[i] - meanI.raw()[i] * meanP.raw()[i];
        a.raw()[i] = covIp / (varI + eps);
        b.raw()[i] = meanP.raw()[i] - a.raw()[i] * meanI.raw()[i];
    }

    FloatImage meanA = conv::boxBlur(a, radius);
    FloatImage meanB = conv::boxBlur(b, radius);

    FloatImage out(guide.width(), guide.height(), 1);
    for (int i = 0; i < n; ++i) {
        out.raw()[i] = meanA.raw()[i] * guide.raw()[i] + meanB.raw()[i];
    }
    return out;
}

FloatImage EdgeAwareEnhancer::sharpen(const FloatImage& tileY, float amount, float radius, float haloSuppression) {
    int r = std::max(1, static_cast<int>(std::round(radius)));
    // eps sets the local-variance threshold below which guidedFilter treats
    // structure as "flat/noise" and smooths it, vs. above which it treats it
    // as "a real edge" and preserves it (a = var/(var+eps) -> 1 as var grows
    // past eps). 1e-4 (the original value here) is the right order of
    // magnitude for *denoising* (only near-perfectly-flat patches get
    // touched), but that's the wrong job here: `detail = tileY - base` is
    // meant to capture real edges so the unsharp boost below has something
    // to amplify, which needs base to actually deviate from tileY across
    // ordinary edges, not just flat noise.
    //
    // 0.02 (an earlier value here) overcorrected: tested directly against a
    // heavily-compressed JPEG source, it picked up compression-block-scale
    // and skin-texture-scale variance about as readily as real edges —
    // meanAbsDiff in a flat skin patch came out within ~15% of meanAbsDiff
    // at a genuine hard edge (headphone band), which shows up as visible
    // blocky mottling on skin rather than clean sharpening. 0.006 was
    // empirically the better trade-off on that same test image: still
    // clearly more effect than the original 1e-4 (no visible restoration at
    // all), without the blockiness. Reducing eps scales the whole effect
    // down fairly proportionally rather than selectively suppressing just
    // the artifact — so this remains a strength dial, not a fully solved
    // selectivity problem, and heavily-compressed sources may still show
    // some of this at high sharpness settings.
    FloatImage base = guidedFilter(tileY, tileY, r, 0.006f);
    
    const int n = tileY.width() * tileY.height();
    FloatImage out(tileY.width(), tileY.height(), 1);

    // Overshoot clamp: near an edge, don't let the boosted value exceed the
    // original local [min, max] range by more than a haloSuppression-scaled
    // margin. This is the "prevent halos at the source" half of artifact
    // control; ArtifactDetector (Stage 6) catches whatever slips through.
    FloatImage localMin(tileY.width(), tileY.height(), 1), localMax(tileY.width(), tileY.height(), 1);
    for (int y = 0; y < tileY.height(); ++y) {
        for (int x = 0; x < tileY.width(); ++x) {
            float mn = 1e9f, mx = -1e9f;
            for (int dy = -1; dy <= 1; ++dy) {
                for (int dx = -1; dx <= 1; ++dx) {
                    float v = tileY.sampleClamped(x + dx, y + dy, 0);
                    mn = std::min(mn, v);
                    mx = std::max(mx, v);
                }
            }
            localMin.at(x, y, 0) = mn;
            localMax.at(x, y, 0) = mx;
        }
    }

    float margin = (1.0f - haloSuppression) * 0.25f + 0.02f; // more suppression -> tighter clamp
    for (int i = 0; i < n; ++i) {
        float detail = tileY.raw()[i] - base.raw()[i];
        float boosted = tileY.raw()[i] + amount * detail;
        float lo = localMin.raw()[i] - margin;
        float hi = localMax.raw()[i] + margin;
        out.raw()[i] = std::clamp(boosted, lo, hi);
    }
    out.clamp(0.0f, 1.0f);
    return out;
}

FloatImage EdgeAwareEnhancer::localContrast(const FloatImage& tileY, float amount) {
    // Same detail-boost idea as sharpen(), but with a much larger radius so
    // it acts on mid-frequency tonal structure ("clarity") rather than fine
    // edges, and no overshoot clamp — this is meant to be gentle by
    // construction (small `amount`) rather than clamp-limited.
    int radius = std::max(4, tileY.width() / 8);
    // Same reasoning and same empirical retuning as sharpen()'s eps — see
    // its doc comment. Keeping roughly the same 0.03:0.02 -> 0.01:0.006
    // ratio between the two.
    FloatImage base = guidedFilter(tileY, tileY, radius, 0.01f);
    FloatImage out(tileY.width(), tileY.height(), 1);
    for (int i = 0; i < tileY.width() * tileY.height(); ++i) {
        float detail = tileY.raw()[i] - base.raw()[i];
        out.raw()[i] = std::clamp(tileY.raw()[i] + amount * detail, 0.0f, 1.0f);
    }
    return out;
}

FloatImage EdgeAwareEnhancer::denoise(const FloatImage& tileY, float noiseSigma, float strength) {
    if (strength <= 0.0f || noiseSigma <= 0.0f) return tileY;

    // Inverse of sharpen()'s reasoning: there, eps needed to sit near
    // typical *edge* variance so detail would include real structure. Here
    // we want the opposite threshold — sit near typical *noise* variance
    // (noiseSigma^2) so only variation at roughly the noise's own scale
    // gets smoothed, while edges (which have much higher local variance
    // than sensor/compression noise almost by definition) stay put. The
    // 2x multiplier biases slightly toward suppressing over preserving,
    // since under-denoising here just means sharpen() amplifies the
    // leftover noise right back in.
    float eps = std::max(1e-5f, noiseSigma * noiseSigma * 2.0f);
    FloatImage denoised = guidedFilter(tileY, tileY, 2, eps);

    const int n = tileY.width() * tileY.height();
    FloatImage out(tileY.width(), tileY.height(), 1);
    for (int i = 0; i < n; ++i) {
        out.raw()[i] = tileY.raw()[i] * (1.0f - strength) + denoised.raw()[i] * strength;
    }
    return out;
}

} // namespace crystal
