#include "blur_estimator.h"
#include "convolution.h"
#include <cmath>
#include <algorithm>

namespace crystal {

BlurEstimator::Estimate BlurEstimator::estimate(const FloatImage& grayTile) {
    Estimate result{};

    // --- "How blurred": Laplacian-energy heuristic ---------------------
    // A sharp tile has high-variance Laplacian response (strong, well
    // localized second derivatives at edges); a blurred tile's edges are
    // spread out, so the Laplacian response is smaller and smoother. This is
    // the same underlying cue classic autofocus/"blur detection" systems
    // use; it is a heuristic, not a physical PSF measurement, and is
    // deliberately conservative (see kRefLaplacianVariance below).
    FloatImage lap = conv::laplacian(grayTile);
    double mean = 0.0;
    for (float v : lap.raw()) mean += v;
    mean /= lap.raw().size();
    double variance = 0.0;
    for (float v : lap.raw()) variance += (v - mean) * (v - mean);
    variance /= lap.raw().size();

    // Empirical calibration constant (not derived from a camera/optics
    // model): a "typically sharp" natural-image tile at [0,1] intensity
    // range tends to land Laplacian variance around this order of
    // magnitude. Tiles far below it are treated as increasingly blurred.
    constexpr double kRefLaplacianVariance = 0.015;
    double sharpnessRatio = variance / kRefLaplacianVariance;
    result.radius = static_cast<float>(std::clamp(2.6 / std::sqrt(std::max(sharpnessRatio, 0.02)), 0.4, 6.0));

    // --- "Which direction": structure tensor -----------------------------
    // Classical Harris/Förstner structure-tensor analysis: average the
    // outer product of the image gradient over the tile, then look at the
    // eigenvalues/eigenvector of the resulting 2x2 matrix. A strongly
    // anisotropic tensor (one eigenvalue >> the other) indicates gradients
    // consistently pointing one way — the signature of directional motion
    // blur. An isotropic tensor (eigenvalues similar) indicates symmetric
    // (defocus-like) blur or non-directional detail.
    FloatImage gx, gy;
    conv::sobelGradients(grayTile, gx, gy);
    double sxx = 0.0, syy = 0.0, sxy = 0.0;
    const size_t n = gx.raw().size();
    for (size_t i = 0; i < n; ++i) {
        double gxv = gx.raw()[i], gyv = gy.raw()[i];
        sxx += gxv * gxv;
        syy += gyv * gyv;
        sxy += gxv * gyv;
    }
    sxx /= n; syy /= n; sxy /= n;

    double trace = sxx + syy;
    double det = sxx * syy - sxy * sxy;
    double disc = std::max(0.0, (trace * trace) / 4.0 - det);
    double lambda1 = trace / 2.0 + std::sqrt(disc);
    double lambda2 = trace / 2.0 - std::sqrt(disc);

    result.directionRad = static_cast<float>(0.5 * std::atan2(2.0 * sxy, sxx - syy));
    result.anisotropy = static_cast<float>((lambda1 - lambda2) / (lambda1 + lambda2 + 1e-6));
    result.isMotionBlur = result.anisotropy > 0.45f;

    // Confidence: a nearly-flat tile (tiny gradient energy) gives an
    // unreliable direction/radius estimate, so scale confidence by how much
    // edge energy was actually available.
    constexpr double kRefEdgeEnergy = 0.01;
    result.confidence = static_cast<float>(std::clamp(trace / (trace + kRefEdgeEnergy), 0.0, 1.0));

    return result;
}

} // namespace crystal
