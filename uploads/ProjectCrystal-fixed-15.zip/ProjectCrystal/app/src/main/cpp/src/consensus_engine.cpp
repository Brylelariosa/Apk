#include "consensus_engine.h"
#include <cmath>
#include <algorithm>
#include <vector>

namespace crystal {

ConsensusEngine::Result ConsensusEngine::combine(const std::vector<FloatImage>& candidatesY,
                                                  const FloatImage& originalY, bool conservativeMode) {
    Result result;
    const int w = originalY.width(), h = originalY.height();
    result.image = FloatImage(w, h, 1);
    result.confidenceMap = FloatImage(w, h, 1);

    if (candidatesY.empty()) {
        // No candidates to reconcile: fall back to the original untouched.
        // Only reachable if a future caller passes an empty candidate set;
        // RestorationEngine::run always supplies exactly four.
        result.image = originalY.clone();
        result.realityScore = 0.0f;
        return result;
    }

    // Agreement threshold: candidate spread (standard deviation) below this
    // is treated as "the methods agree" and gets averaged; above it, the
    // methods disagree and the most conservative candidate wins instead of
    // an average (spec: "Never average everything together").
    constexpr float kAgreementThreshold = 0.035f;

    double confidenceSum = 0.0;
    const int n = w * h;
    for (int i = 0; i < n; ++i) {
        double mean = 0.0;
        for (const auto& cand : candidatesY) mean += cand.raw()[i];
        mean /= candidatesY.size();

        double variance = 0.0;
        for (const auto& cand : candidatesY) {
            double d = cand.raw()[i] - mean;
            variance += d * d;
        }
        variance /= candidatesY.size();
        double spread = std::sqrt(variance);

        float confidence = static_cast<float>(std::clamp(1.0 - spread / 0.15, 0.0, 1.0));
        result.confidenceMap.raw()[i] = confidence;
        confidenceSum += confidence;

        if (spread <= kAgreementThreshold && !conservativeMode) {
            result.image.raw()[i] = static_cast<float>(mean);
        } else if (spread <= kAgreementThreshold) {
            // Even in agreement, conservative mode nudges slightly toward
            // the original rather than trusting the average outright.
            result.image.raw()[i] = static_cast<float>(mean * 0.85 + originalY.raw()[i] * 0.15);
        } else {
            // Disagreement: use the median candidate as the robust consensus
            // value. The previous approach here — picking whichever
            // candidate deviates least from the original — sounds
            // conservative but is actually structurally incapable of
            // restoring anything: by construction it always selects
            // whichever method happened to change this pixel the least,
            // regardless of how strong the other three candidates (or the
            // user's slider settings) were. The median is resistant to any
            // single outlier candidate without collapsing to "closest to
            // unchanged", and conservativeMode now nudges toward the
            // original by the same bounded amount as the agreement branch
            // above instead of silently overriding it every time regardless
            // of the flag.
            // True median: for the even-sized 4-candidate array this is the
            // average of the two middle values, not just vals[size/2] (which
            // picks the upper-middle / 3rd-of-4 value alone — biased high
            // relative to a real median, and not resistant to a single
            // outlier candidate the way an actual median is).
            std::vector<float> vals;
            vals.reserve(candidatesY.size());
            for (const auto& cand : candidatesY) vals.push_back(cand.raw()[i]);
            const size_t mid = vals.size() / 2;
            std::nth_element(vals.begin(), vals.begin() + mid, vals.end());
            float median = vals[mid];
            if (vals.size() % 2 == 0) {
                float lowerMid = *std::max_element(vals.begin(), vals.begin() + mid);
                median = (median + lowerMid) * 0.5f;
            }
            float original = originalY.raw()[i];
            result.image.raw()[i] = conservativeMode ? (median * 0.85f + original * 0.15f) : median;
        }
    }

    result.realityScore = static_cast<float>(confidenceSum / n);
    return result;
}

} // namespace crystal
