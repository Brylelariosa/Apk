#include "convolution.h"
#include <cmath>
#include <algorithm>

namespace crystal {
namespace conv {

std::vector<float> gaussianKernel1D(float sigma, int radius) {
    sigma = std::max(sigma, 0.1f);
    std::vector<float> kernel(2 * radius + 1);
    float sum = 0.0f;
    for (int i = -radius; i <= radius; ++i) {
        float v = std::exp(-(i * i) / (2.0f * sigma * sigma));
        kernel[i + radius] = v;
        sum += v;
    }
    for (auto& v : kernel) v /= sum;
    return kernel;
}

FloatImage convolveSeparable(const FloatImage& img, const std::vector<float>& kernel1D) {
    const int radius = static_cast<int>(kernel1D.size() / 2);
    const int w = img.width(), h = img.height(), c = img.channels();

    FloatImage temp(w, h, c);
    // Horizontal pass.
    for (int y = 0; y < h; ++y) {
        for (int x = 0; x < w; ++x) {
            for (int ch = 0; ch < c; ++ch) {
                float acc = 0.0f;
                for (int k = -radius; k <= radius; ++k) {
                    acc += img.sampleClamped(x + k, y, ch) * kernel1D[k + radius];
                }
                temp.at(x, y, ch) = acc;
            }
        }
    }
    // Vertical pass.
    FloatImage out(w, h, c);
    for (int y = 0; y < h; ++y) {
        for (int x = 0; x < w; ++x) {
            for (int ch = 0; ch < c; ++ch) {
                float acc = 0.0f;
                for (int k = -radius; k <= radius; ++k) {
                    acc += temp.sampleClamped(x, y + k, ch) * kernel1D[k + radius];
                }
                out.at(x, y, ch) = acc;
            }
        }
    }
    return out;
}

FloatImage gaussianBlur(const FloatImage& img, float sigma) {
    int radius = std::max(1, static_cast<int>(std::ceil(sigma * 3.0f)));
    return convolveSeparable(img, gaussianKernel1D(sigma, radius));
}

FloatImage boxBlur(const FloatImage& img, int radius) {
    if (radius <= 0) return img.clone();
    std::vector<float> kernel(2 * radius + 1, 1.0f / (2 * radius + 1));
    return convolveSeparable(img, kernel);
}

void sobelGradients(const FloatImage& gray, FloatImage& gx, FloatImage& gy) {
    const int w = gray.width(), h = gray.height();
    gx = FloatImage(w, h, 1);
    gy = FloatImage(w, h, 1);
    static const float kx[3][3] = {{-1, 0, 1}, {-2, 0, 2}, {-1, 0, 1}};
    static const float ky[3][3] = {{-1, -2, -1}, {0, 0, 0}, {1, 2, 1}};
    for (int y = 0; y < h; ++y) {
        for (int x = 0; x < w; ++x) {
            float sx = 0.0f, sy = 0.0f;
            for (int j = -1; j <= 1; ++j) {
                for (int i = -1; i <= 1; ++i) {
                    float v = gray.sampleClamped(x + i, y + j, 0);
                    sx += v * kx[j + 1][i + 1];
                    sy += v * ky[j + 1][i + 1];
                }
            }
            gx.at(x, y, 0) = sx;
            gy.at(x, y, 0) = sy;
        }
    }
}

FloatImage sobelMagnitude(const FloatImage& gray) {
    FloatImage gx, gy;
    sobelGradients(gray, gx, gy);
    FloatImage out(gray.width(), gray.height(), 1);
    for (int i = 0; i < gray.width() * gray.height(); ++i) {
        float mag = std::sqrt(gx.raw()[i] * gx.raw()[i] + gy.raw()[i] * gy.raw()[i]);
        out.raw()[i] = mag;
    }
    return out;
}

FloatImage laplacian(const FloatImage& gray) {
    const int w = gray.width(), h = gray.height();
    FloatImage out(w, h, 1);
    for (int y = 0; y < h; ++y) {
        for (int x = 0; x < w; ++x) {
            float center = gray.at(x, y, 0);
            float sum = gray.sampleClamped(x - 1, y, 0) + gray.sampleClamped(x + 1, y, 0) +
                        gray.sampleClamped(x, y - 1, 0) + gray.sampleClamped(x, y + 1, 0) -
                        4.0f * center;
            out.at(x, y, 0) = sum;
        }
    }
    return out;
}

FloatImage convolve2D(const FloatImage& img, const std::vector<float>& kernel, int kw, int kh) {
    const int w = img.width(), h = img.height(), c = img.channels();
    const int halfW = kw / 2, halfH = kh / 2;
    FloatImage out(w, h, c);
    for (int y = 0; y < h; ++y) {
        for (int x = 0; x < w; ++x) {
            for (int ch = 0; ch < c; ++ch) {
                float acc = 0.0f;
                for (int j = 0; j < kh; ++j) {
                    for (int i = 0; i < kw; ++i) {
                        float sample = img.sampleClamped(x + i - halfW, y + j - halfH, ch);
                        acc += sample * kernel[j * kw + i];
                    }
                }
                out.at(x, y, ch) = acc;
            }
        }
    }
    return out;
}

} // namespace conv
} // namespace crystal
