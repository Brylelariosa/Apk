#pragma once

#include "image_buffer.h"

namespace crystal {

// Stage 1/2: per-tile blur characterization using classical, closed-form
// cues only (Laplacian energy for "how blurred", structure-tensor anisotropy
// for "in which direction"). No learned model of any kind.
class BlurEstimator {
public:
    struct Estimate {
        float radius;       // estimated equivalent Gaussian PSF radius, in px
        float directionRad; // dominant blur direction, radians (meaningful when isMotionBlur)
        float anisotropy;   // 0 = symmetric (defocus-like), 1 = strongly directional (motion-like)
        float confidence;   // 0..1, low in flat/low-contrast tiles where the estimate is unreliable
        bool isMotionBlur;  // anisotropy above threshold
    };

    static Estimate estimate(const FloatImage& grayTile);
};

} // namespace crystal
