#pragma once

#include <jni.h>
#include "image_buffer.h"
#include "restoration_params.h"
#include "restoration_engine.h"

namespace crystal {
namespace jniutil {

// Locks an Android Bitmap (must be ARGB_8888) and decodes it into a
// FloatImage. Throws a Java IllegalArgumentException (via env->ThrowNew) and
// returns an empty FloatImage on failure — callers should check empty()
// immediately after.
FloatImage bitmapToFloatImage(JNIEnv* env, jobject bitmap);

// Encodes a FloatImage back into a locked ARGB_8888 Bitmap of the same size.
void floatImageToBitmap(JNIEnv* env, jobject bitmap, const FloatImage& image);

// Unpacks the fixed-order float array documented in restoration_params.h
// into a RestorationParams.
RestorationParams unpackParams(JNIEnv* env, jfloatArray paramsArray, jint specialMode, jboolean conservativeMode);

// Builds a com.projectcrystal.app.core.native.RestorationMetricsNative
// object from a PipelineOutput. Diagnostic maps are downsampled to at most
// `maxDimension` on the long side first — a full-resolution map would be an
// unreasonable amount of data to marshal across JNI and hold as a Java
// float array for a large photo, and Debug Mode never needs more pixels
// than the screen can show anyway.
jobject buildMetricsObject(JNIEnv* env, const PipelineOutput& pipelineOutput, int maxDimension);

} // namespace jniutil
} // namespace crystal
