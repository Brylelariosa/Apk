#pragma once

#include "image_buffer.h"
#include <vector>

namespace crystal {

// Stage 2: Adaptive Tile Analysis, plus the seam-free blending half of
// reassembling per-tile results (an "overlap-add" scheme, the same family
// of technique used to stitch windowed spectrogram frames back together).
class TileProcessor {
public:
    struct Tile {
        int x, y, w, h;             // processing rect, including overlap; clipped to image bounds
        bool hasLeftNeighbor;
        bool hasRightNeighbor;
        bool hasTopNeighbor;
        bool hasBottomNeighbor;
    };

    // Splits an image into a grid of `baseTileSize` tiles, each expanded by
    // `overlap` px on every side it shares with a neighbor (and left
    // un-expanded at true image borders, where there's nothing to blend
    // against).
    static std::vector<Tile> computeAdaptiveTiles(int imgW, int imgH, int baseTileSize, int overlap);

    // Accumulates `tileResult` (sized tile.w x tile.h) into `output`/
    // `weightAccum` using a raised-cosine taper across each neighbor-facing
    // overlap band (full weight in the tile interior, tapering to 0 at the
    // shared boundary) so adjacent tiles blend smoothly instead of showing
    // a seam. Call FinalizeBlend once all tiles are accumulated.
    static void accumulateTile(FloatImage& output, FloatImage& weightAccum, const FloatImage& tileResult,
                                const Tile& tile, int overlap);

    // Normalizes `output` by `weightAccum` in place (output /= weightAccum).
    static void finalizeBlend(FloatImage& output, const FloatImage& weightAccum);
};

} // namespace crystal
