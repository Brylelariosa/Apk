#pragma once

#include "image_buffer.h"

namespace crystal {

// Stage 3: edge-aware enhancement candidate + Stage-adjacent tools
// (local-contrast / "clarity" style enhancement). Built on He et al.'s
// guided filter (a closed-form local linear model, O(n), no ML) as an
// edge-preserving smoothing base — using it instead of a plain Gaussian for
// the unsharp-mask base is what keeps halos smaller at the source, before
// ArtifactDetector even has to intervene.
class EdgeAwareEnhancer {
public:
    // Edge-aware unsharp mask: base = guidedFilter(img), detail = img -
    // base, output = img + amount*detail, with an overshoot clamp scaled by
    // haloSuppression.
    static FloatImage sharpen(const FloatImage& tileY, float amount, float radius, float haloSuppression);

    // Larger-radius, gentler version of the same idea for midtone "clarity".
    static FloatImage localContrast(const FloatImage& tileY, float amount);

    // Edge-preserving denoise, calibrated to the *estimated noise variance*
    // rather than a fixed eps: unlike sharpen()/localContrast() (which need
    // detail to include real edges), this needs the opposite — detail
    // *excluding* real edges, only variance at roughly the noise's own
    // scale. sharpen()/localContrast() have no noise awareness of their own
    // (unlike the Wiener candidate, which folds noiseReduction into its own
    // regularization), so run this on their input first or a wider `amount`
    // there boosts noise right alongside real detail.
    static FloatImage denoise(const FloatImage& tileY, float noiseSigma, float strength);

    // He, Sun & Tang, "Guided Image Filtering" (ECCV 2010 / TPAMI 2013).
    // Exposed publicly since ArtifactDetector and RealityLock also use it as
    // a general edge-preserving smoothing primitive.
    static FloatImage guidedFilter(const FloatImage& guide, const FloatImage& src, int radius, float eps);
};

} // namespace crystal
