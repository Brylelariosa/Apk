#pragma once

#include "image_buffer.h"

namespace crystal {

// Stage 8: Reality Lock. The spec asks to protect "faces, eyes, text,
// corners, straight lines, thin structures" from aggressive restoration.
// Doing that with an actual face/eye detector would mean shipping a
// pretrained classifier, which the spec explicitly rules out — so this
// protects the same *kind* of content a different way: it identifies
// structurally important pixels directly from the image itself (strong
// edges via gradient magnitude, and corner-like points via a classical
// Harris corner response, both zero-training closed-form measures) and
// dials restoration strength down wherever they're found. Corners, line
// junctions and fine text strokes score highly on both cues; so, usually,
// do eyes and facial features, without needing to know what a "face" is.
class RealityLock {
public:
    // Harris corner response (Harris & Stephens, 1988), raw/unnormalized.
    // Split out from protect() so the orchestrator can compute it once on
    // the *whole* image (see restoration_engine.cpp Stage 1) instead of
    // once per tile: a structural response only means something relative
    // to how strong structure gets elsewhere in the same photo, and a
    // small tile's own local maximum is a poor stand-in for that.
    static FloatImage computeCornerResponse(const FloatImage& grayOrY);

    // edgeMagnitude / cornerResponse: this tile's crop out of the
    // *whole-image* edge map and corner-response map (both computed once,
    // see Stage 1 in restoration_engine.cpp) — not recomputed locally.
    // maxEdgeGlobal / maxCornerGlobal: the whole image's maximum edge
    // magnitude / corner response, used to normalize importance. Passing
    // these in (rather than each call finding its own local max) is what
    // makes protectionStrength mean the same thing in every tile: a
    // texture-only tile with no strong edges anywhere in it would
    // otherwise still normalize its modest local max up to 1.0 and get
    // locked down just as hard as a tile that actually contains a sharp
    // silhouette — silently undoing most of the restoration everywhere
    // there's any texture at all, which is exactly where restoration is
    // meant to be visible.
    static FloatImage protect(const FloatImage& restoredY, const FloatImage& originalY,
                               const FloatImage& edgeMagnitude, const FloatImage& cornerResponse,
                               float protectionStrength, float maxEdgeGlobal, float maxCornerGlobal);
};

} // namespace crystal
