#pragma once

#include <vector>
#include <complex>

namespace crystal {

// Minimal iterative radix-2 Cooley-Tukey FFT. Only used internally by
// Deconvolution::wiener on padded, power-of-two tile buffers — this is not a
// general-purpose signal processing library, just enough to do frequency
// domain division for Wiener deconvolution without an external dependency.
namespace fft {

// n must be a power of two. In-place, decimation-in-time.
void fft1D(std::vector<std::complex<float>>& a, bool inverse);

// Smallest power of two >= n.
int nextPowerOfTwo(int n);

// Row/column separable 2D FFT over a w*h (row-major) complex buffer.
// w and h must each be powers of two.
void fft2D(std::vector<std::complex<float>>& data, int w, int h, bool inverse);

} // namespace fft
} // namespace crystal
