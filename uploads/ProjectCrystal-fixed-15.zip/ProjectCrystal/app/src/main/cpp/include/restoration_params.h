#pragma once

namespace crystal {

// Mirrors the special-mode enum on the Kotlin side (core/model/SpecialMode.kt).
// Keep the integer values in sync — they cross the JNI boundary as a plain int.
enum class SpecialMode : int {
    AUTO = 0,
    PORTRAIT = 1,
    LANDSCAPE = 2,
    DOCUMENT = 3,
    SCREENSHOT = 4,
    OLD_PHOTO = 5,
    TEXT_ENHANCEMENT = 6
};

// All user-facing sliders, flattened into one struct so the JNI boundary is a
// single fixed-order float array (see NativeImageProcessor.kt / jni_bridge.cpp
// for the documented field order). Every 0..1 field is a fraction of the
// slider's usable range; RestorationEngine maps these onto physical units
// (pixels, iteration counts, dB) once, in one place.
struct RestorationParams {
    float blurStrength = 0.5f;        // 0..1, how aggressively to invert estimated blur
    float noiseReduction = 0.5f;      // 0..1
    float sharpness = 0.5f;           // 0..1
    float textureRecovery = 0.4f;     // 0..1
    float haloSuppression = 0.6f;     // 0..1, higher = more conservative near edges
    float frequencyStrength = 0.5f;   // 0..1, gates how much high-frequency detail is trusted
    float contrast = 0.0f;            // -1..1
    float brightness = 0.0f;          // -1..1
    float saturation = 0.0f;          // -1..1
    float temperature = 0.0f;         // -1..1 (blue <-> orange)
    float tint = 0.0f;                // -1..1 (green <-> magenta)
    int tileSize = 256;               // px, one of 128/192/256/384/512
    int richardsonLucyIterations = 6; // clamped internally to [1, 15] — spec calls for "limited iterations"
    float edgeEnhancement = 0.5f;     // 0..1
    float localContrast = 0.3f;       // 0..1
    bool conservativeMode = true;     // when candidates disagree, bias further toward the original
    SpecialMode specialMode = SpecialMode::AUTO;
};

// Fixed field order used to pack/unpack RestorationParams across JNI as a
// float array (conservativeMode and specialMode cross separately as their
// own JNI arguments, not packed into this array):
//   0 blurStrength      5 frequencyStrength   10 tint                14 localContrast
//   1 noiseReduction     6 contrast            11 tileSize
//   2 sharpness          7 brightness          12 richardsonLucyIterations
//   3 textureRecovery    8 saturation          13 edgeEnhancement
//   4 haloSuppression    9 temperature
// Update BOTH this comment and NativeImageProcessor.kt's PARAM_COUNT/pack()
// together if the struct changes.
constexpr int kRestorationParamFloatCount = 15;

} // namespace crystal
