#pragma once

#include "image_buffer.h"
#include <vector>

namespace crystal {

// Stage 4: Consensus Restoration. Combines several independent single-
// channel restoration candidates pixel-by-pixel. Where candidates agree
// (low spread), confidence is high and their average is trusted. Where they
// disagree, the spec is explicit: never blend blindly — fall back to
// whichever candidate changed the pixel the least from the original. This
// keeps the result conservative exactly where the algorithm is uncertain.
class ConsensusEngine {
public:
    struct Result {
        FloatImage image;          // consensus single-channel (Y) output
        FloatImage confidenceMap;  // 0..1, per pixel
        float realityScore;        // 0..1, tile-level summary of confidenceMap
    };

    static Result combine(const std::vector<FloatImage>& candidatesY, const FloatImage& originalY,
                           bool conservativeMode);
};

} // namespace crystal
