#pragma once

#include "image_buffer.h"

namespace crystal {

// Stage 1/2: fast noise-sigma estimation using Immerkaer's method (J.
// Immerkaer, "Fast Noise Variance Estimation", CVIU 1996) — a single
// Laplacian-like convolution followed by a closed-form scaling. Chosen
// because it is cheap enough to run per-tile and does not require any
// training data or iterative fitting.
class NoiseEstimator {
public:
    // Returns the estimated Gaussian noise standard deviation, in the same
    // [0, 1] units as pixel intensity.
    static float estimateSigma(const FloatImage& grayTile);
};

} // namespace crystal
