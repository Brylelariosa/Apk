#pragma once

#include "image_buffer.h"

namespace crystal {

// Stage 6: Artifact Detection. Looks for the classic signatures of
// over-aggressive restoration — halos/ringing/overshoot next to strong
// edges — by comparing the restored tile against the *original* tile's
// local intensity range. Anything that overshoots is, by construction,
// information that was added rather than recovered, which is exactly what
// the "never invent detail" design philosophy rules out.
class ArtifactDetector {
public:
    struct ArtifactMap {
        FloatImage severity; // 0..1 per pixel: how much this pixel overshoots the original's local range
        float overallSeverity; // tile-average of severity, used in the Reality Score
    };

    static ArtifactMap detect(const FloatImage& originalY, const FloatImage& restoredY);

    // Blends `restoredY` back toward `originalY` in proportion to
    // artifacts.severity * strength — i.e. undoes enhancement only where
    // it produced an artifact, leaving the rest of the tile untouched.
    static FloatImage suppress(const FloatImage& restoredY, const FloatImage& originalY,
                                const ArtifactMap& artifacts, float strength);
};

} // namespace crystal
