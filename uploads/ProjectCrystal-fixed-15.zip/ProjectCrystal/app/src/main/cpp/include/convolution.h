#pragma once

#include "image_buffer.h"
#include <vector>

namespace crystal {
namespace conv {

// Builds a normalized 1D Gaussian kernel of radius `radius` (kernel width =
// 2*radius+1) for standard deviation `sigma`.
std::vector<float> gaussianKernel1D(float sigma, int radius);

// Separable convolution (horizontal pass then vertical pass) with a 1D
// kernel, edge-reflected. Works on images with any channel count.
FloatImage convolveSeparable(const FloatImage& img, const std::vector<float>& kernel1D);

// Convenience wrapper: derives a sensible radius from sigma and blurs.
FloatImage gaussianBlur(const FloatImage& img, float sigma);

// Box filter (mean filter) via separable convolution with a uniform kernel.
// Used as the fast running-sum step inside the guided filter.
FloatImage boxBlur(const FloatImage& img, int radius);

// Sobel gradient magnitude of a single-channel image.
FloatImage sobelMagnitude(const FloatImage& gray);

// Sobel gradients (Gx, Gy) of a single-channel image, returned separately —
// needed by the structure-tensor code in BlurEstimator and RealityLock.
void sobelGradients(const FloatImage& gray, FloatImage& gx, FloatImage& gy);

// Discrete Laplacian (single-channel), used for sharpness/noise estimation.
FloatImage laplacian(const FloatImage& gray);

// Generic (non-separable) 2D convolution with an arbitrary kw*kh kernel,
// edge-reflected. Intended for small kernels (PSFs up to ~15x15) such as the
// ones Richardson-Lucy iterates against; not optimized for large kernels.
FloatImage convolve2D(const FloatImage& img, const std::vector<float>& kernel, int kw, int kh);

} // namespace conv
} // namespace crystal
