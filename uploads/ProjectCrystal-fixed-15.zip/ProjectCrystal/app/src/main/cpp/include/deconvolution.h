#pragma once

#include "image_buffer.h"

namespace crystal {

// Stage 3: classical deblurring candidates. Both operate on a single-channel
// (luma) tile and assume a symmetric Gaussian point-spread function sized by
// BlurEstimator's radius estimate — a good match for defocus blur and a
// usable approximation for mild motion blur once oriented via the estimated
// blur direction (a directional box PSF is used instead of Gaussian when
// BlurEstimator reports strong anisotropy).
namespace Deconvolution {

// Frequency-domain Wiener deconvolution: divides by the PSF in frequency
// space with a noise-to-signal regularization term so near-zero frequencies
// of the PSF don't blow up. Fast (single FFT/IFFT pair) and stable, but can
// leave a slightly "flat" look — this is why it's only one of several
// candidates the ConsensusEngine chooses between.
FloatImage wiener(const FloatImage& tileY, float blurRadius, float directionRad,
                   float anisotropy, float noiseToSignalRatio);

// Iterative Richardson-Lucy deconvolution (spatial domain, limited
// iterations per the spec). Tends to recover more contrast than Wiener at
// the cost of being more prone to ringing near strong edges — the
// ArtifactDetector stage exists specifically to catch that.
FloatImage richardsonLucy(const FloatImage& tileY, float blurRadius, float directionRad,
                           float anisotropy, int iterations);

} // namespace Deconvolution
} // namespace crystal
