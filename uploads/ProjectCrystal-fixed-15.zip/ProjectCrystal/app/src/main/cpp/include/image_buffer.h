#pragma once

#include <vector>
#include <cstdint>
#include <string>

namespace crystal {

// A minimal, dependency-free floating point image buffer. Values are stored
// as planar-interleaved (like RGB RGB RGB...) 32-bit floats, normalized to
// [0, 1] for color data. This is the one image type every restoration stage
// speaks; keeping it dependency-free (no OpenCV::Mat) is what lets the whole
// native module build without an external CV library.
class FloatImage {
public:
    FloatImage() = default;
    FloatImage(int width, int height, int channels, float fill = 0.0f);

    int width() const { return width_; }
    int height() const { return height_; }
    int channels() const { return channels_; }
    bool empty() const { return data_.empty(); }

    float& at(int x, int y, int c);
    float at(int x, int y, int c) const;

    // Clamped-coordinate sampling (reflects out-of-bounds reads to the
    // nearest valid pixel). Used by convolution/estimation code so callers
    // don't have to special-case tile borders.
    float sampleClamped(int x, int y, int c) const;

    FloatImage clone() const;

    // Extracts a sub-region (used by TileProcessor). Coordinates are clamped
    // to image bounds automatically.
    FloatImage crop(int x, int y, int w, int h) const;

    // Decodes a locked ARGB_8888 Android Bitmap buffer (4 bytes/px, stride in
    // bytes) into a 3-channel RGB FloatImage in [0, 1].
    static FloatImage fromARGB8888(const uint8_t* pixels, int width, int height, int strideBytes);

    // Encodes a 3-channel RGB FloatImage back into a locked ARGB_8888 buffer.
    // Alpha is always written as fully opaque.
    void toARGB8888(uint8_t* pixels, int strideBytes) const;

    // BT.601 luma/chroma conversions. Restoration operates mainly on Y to
    // avoid color fringing and to cut FFT/convolution cost 3x versus
    // processing R, G, and B independently.
    FloatImage toYCbCr() const;
    static FloatImage fromYCbCr(const FloatImage& ycbcr);

    // Single-channel luminance view (identical formula to the Y plane above),
    // convenience for stages that only ever want grayscale.
    FloatImage toGrayscale() const;

    // In-place per-channel clamp to [lo, hi].
    void clamp(float lo = 0.0f, float hi = 1.0f);

    // Extracts one channel as its own single-channel FloatImage.
    FloatImage channel(int c) const;

    // Writes `src` (must be 1-channel) into channel `c` of this image.
    void setChannel(int c, const FloatImage& src);

    std::vector<float>& raw() { return data_; }
    const std::vector<float>& raw() const { return data_; }

private:
    int width_ = 0;
    int height_ = 0;
    int channels_ = 0;
    std::vector<float> data_;
};

} // namespace crystal
