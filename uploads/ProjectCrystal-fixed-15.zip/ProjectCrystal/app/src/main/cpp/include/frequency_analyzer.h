#pragma once

#include "image_buffer.h"

namespace crystal {

// Stage 7: Frequency-band consensus. Decomposes a tile into three bands
// (low / mid / high) via successive Gaussian blurring (a small Laplacian
// pyramid), then produces a per-pixel "agreement" map: places where the mid
// and high bands correlate are treated as real texture; places where high
// exists with no mid-band support look like isolated noise and are not
// trusted for enhancement.
class FrequencyAnalyzer {
public:
    struct Bands {
        FloatImage low;   // heavily blurred base
        FloatImage mid;   // low - moreBlurred  (coarse structure)
        FloatImage high;  // original - lightlyBlurred (fine detail + noise)
    };

    static Bands decompose(const FloatImage& gray);

    // 0..1 per pixel; 1 = mid/high bands agree (trust this detail), 0 = only
    // the high band has energy here (probably noise).
    static FloatImage bandAgreementMap(const Bands& bands);
};

} // namespace crystal
