package com.projectcrystal.app.data.prefs

import android.content.Context
import androidx.preference.PreferenceManager
import com.projectcrystal.app.core.model.RestorationParams
import com.projectcrystal.app.data.export.ExportFormat

/**
 * Typed access to the single SharedPreferences-backed settings screen (see
 * res/xml/preferences.xml). Every key the Settings screen writes has exactly
 * one reader, defined here, so a preference can never silently drift out of
 * sync between the UI that sets it and the code that's supposed to act on
 * it — which is what happened before this class existed: pref_tile_size,
 * pref_conservative_mode, pref_debug_mode, pref_export_format, and
 * pref_preserve_metadata were all persisted correctly by their Preference
 * widgets but never actually read anywhere.
 */
class AppPreferences(context: Context) {

    private val prefs = PreferenceManager.getDefaultSharedPreferences(context)

    fun themeMode(): String = prefs.getString(KEY_THEME, DEFAULT_THEME) ?: DEFAULT_THEME

    fun isDebugModeEnabled(): Boolean = prefs.getBoolean(KEY_DEBUG_MODE, false)

    fun isConservativeModeEnabled(): Boolean = prefs.getBoolean(KEY_CONSERVATIVE_MODE, true)

    fun defaultTileSize(): Int = prefs.getString(KEY_TILE_SIZE, DEFAULT_TILE_SIZE.toString())
        ?.toIntOrNull() ?: DEFAULT_TILE_SIZE

    /**
     * Starting point for a brand-new restoration (a freshly picked image, or
     * the first item queued in a batch run). Per-image slider edits made in
     * the editor override this afterward — this only sets the defaults
     * those sliders start at.
     */
    fun defaultRestorationParams(): RestorationParams = RestorationParams(
        tileSize = defaultTileSize(),
        conservativeMode = isConservativeModeEnabled(),
    )

    fun defaultExportFormat(): ExportFormat = when (prefs.getString(KEY_EXPORT_FORMAT, ExportFormat.PNG.name)) {
        ExportFormat.JPEG.name -> ExportFormat.JPEG
        ExportFormat.WEBP.name -> ExportFormat.WEBP
        else -> ExportFormat.PNG
    }

    fun defaultPreserveMetadata(): Boolean = prefs.getBoolean(KEY_PRESERVE_METADATA, true)

    companion object {
        const val KEY_THEME = "pref_theme"
        const val KEY_DEBUG_MODE = "pref_debug_mode"
        const val KEY_TILE_SIZE = "pref_tile_size"
        const val KEY_CONSERVATIVE_MODE = "pref_conservative_mode"
        const val KEY_EXPORT_FORMAT = "pref_export_format"
        const val KEY_PRESERVE_METADATA = "pref_preserve_metadata"

        private const val DEFAULT_THEME = "system"
        private const val DEFAULT_TILE_SIZE = 256
    }
}
