package com.projectcrystal.app.data.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface HistoryDao {

    @Query("SELECT * FROM history_entries ORDER BY createdAtEpochMs DESC")
    fun observeAll(): Flow<List<HistoryEntity>>

    @Query("SELECT * FROM history_entries ORDER BY createdAtEpochMs DESC LIMIT :limit")
    fun observeRecent(limit: Int): Flow<List<HistoryEntity>>

    @Query("SELECT * FROM history_entries WHERE isFavorite = 1 ORDER BY createdAtEpochMs DESC")
    fun observeFavorites(): Flow<List<HistoryEntity>>

    @Query("SELECT * FROM history_entries WHERE id = :id")
    suspend fun getById(id: Long): HistoryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entity: HistoryEntity): Long

    @Update
    suspend fun update(entity: HistoryEntity)

    @Delete
    suspend fun delete(entity: HistoryEntity)

    /**
     * Used by [com.projectcrystal.app.data.repository.ImageRepository.delete]
     * to decide whether an ingested original file can be safely removed:
     * "edit again" reprocesses the same original into a new row, so several
     * entries can legitimately share one originalPath.
     */
    @Query("SELECT COUNT(*) FROM history_entries WHERE originalPath = :originalPath")
    suspend fun countByOriginalPath(originalPath: String): Int
}
