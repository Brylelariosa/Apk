package com.projectcrystal.app.core.diagnostics

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.max

/** Summary of how different two same-sized bitmaps are, in 0-255 units. */
data class BitmapDiffSummary(
    val meanAbsDiff: Double,
    val maxAbsDiff: Int,
    val pctChangedOver5: Double,
    val pctChangedOver20: Double,
) {
    override fun toString(): String =
        "meanAbsDiff=%.2f/255 maxAbsDiff=%d/255 changed>5=%.1f%% changed>20=%.1f%%"
            .format(meanAbsDiff, maxAbsDiff, pctChangedOver5, pctChangedOver20)
}

/**
 * Answers "did this restoration actually change anything visible" as a
 * number instead of a screenshot — a mean diff under ~1/255 looks
 * identical to the naked eye whether the pipeline is broken or the source
 * image just had little to fix, but it's unambiguous in a log line. Samples
 * a stride of pixels rather than every one: restoration output can be up to
 * 3000px square, and this only needs a representative summary, not a
 * research-grade metric.
 */
object BitmapDiff {
    fun summarize(original: Bitmap, restored: Bitmap, stride: Int = 4): BitmapDiffSummary {
        val w = minOf(original.width, restored.width)
        val h = minOf(original.height, restored.height)
        val origRow = IntArray(w)
        val restRow = IntArray(w)

        var sum = 0.0
        var count = 0L
        var maxDiff = 0
        var over5 = 0L
        var over20 = 0L

        var y = 0
        while (y < h) {
            original.getPixels(origRow, 0, w, 0, y, w, 1)
            restored.getPixels(restRow, 0, w, 0, y, w, 1)
            var x = 0
            while (x < w) {
                val o = origRow[x]
                val r = restRow[x]
                val dr = abs(((o shr 16) and 0xFF) - ((r shr 16) and 0xFF))
                val dg = abs(((o shr 8) and 0xFF) - ((r shr 8) and 0xFF))
                val db = abs((o and 0xFF) - (r and 0xFF))
                val d = max(dr, max(dg, db))

                sum += d
                count++
                if (d > maxDiff) maxDiff = d
                if (d > 5) over5++
                if (d > 20) over20++
                x += stride
            }
            y += stride
        }

        return BitmapDiffSummary(
            meanAbsDiff = if (count > 0) sum / count else 0.0,
            maxAbsDiff = maxDiff,
            pctChangedOver5 = if (count > 0) 100.0 * over5 / count else 0.0,
            pctChangedOver20 = if (count > 0) 100.0 * over20 / count else 0.0,
        )
    }
}
