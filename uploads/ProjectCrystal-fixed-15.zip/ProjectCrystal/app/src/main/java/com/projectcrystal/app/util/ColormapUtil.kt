package com.projectcrystal.app.util

import android.graphics.Bitmap
import com.projectcrystal.app.core.model.DiagnosticMap
import kotlin.math.floor

/**
 * Renders a [DiagnosticMap] (blur/noise/edge/confidence/artifact — all
 * single-channel, 0..1) as a false-color heatmap Bitmap for Debug Mode.
 * Uses a small hand-picked, perceptually-ordered (dark purple -> teal ->
 * yellow) color ramp rather than a library dependency.
 *
 * The color math ([colorFor], [lerpColor]) is deliberately plain Int
 * bit-packing rather than android.graphics.Color: Color's methods are
 * stubbed to return 0 under Gradle's plain-JVM unit tests (no
 * Robolectric), which would make [colorFor] untestable without a device.
 * Only [toHeatmapBitmap] touches a real Bitmap and is exercised by an
 * instrumentation test instead.
 */
object ColormapUtil {

    // 0xAARRGGBB packed ints — see packArgb().
    private val stops = intArrayOf(
        packArgb(13, 8, 61),
        packArgb(59, 15, 112),
        packArgb(140, 41, 129),
        packArgb(222, 73, 104),
        packArgb(254, 159, 66),
        packArgb(240, 249, 33),
    )

    fun colorFor(value01: Float): Int {
        val v = value01.coerceIn(0f, 1f) * (stops.size - 1)
        val lowIndex = floor(v).toInt().coerceIn(0, stops.size - 2)
        val t = v - lowIndex
        return lerpColor(stops[lowIndex], stops[lowIndex + 1], t)
    }

    fun toHeatmapBitmap(map: DiagnosticMap): Bitmap {
        val bitmap = Bitmap.createBitmap(map.width, map.height, Bitmap.Config.ARGB_8888)
        val pixels = IntArray(map.width * map.height)
        for (i in pixels.indices) {
            pixels[i] = colorFor(map.values[i])
        }
        bitmap.setPixels(pixels, 0, map.width, 0, 0, map.width, map.height)
        return bitmap
    }

    private fun packArgb(r: Int, g: Int, b: Int): Int =
        (0xFF shl 24) or (r shl 16) or (g shl 8) or b

    private fun lerpColor(from: Int, to: Int, t: Float): Int {
        val r = lerpChannel(from shr 16, to shr 16, t)
        val g = lerpChannel(from shr 8, to shr 8, t)
        val b = lerpChannel(from, to, t)
        return packArgb(r, g, b)
    }

    private fun lerpChannel(from: Int, to: Int, t: Float): Int {
        val fromChannel = from and 0xFF
        val toChannel = to and 0xFF
        return (fromChannel + (toChannel - fromChannel) * t).toInt().coerceIn(0, 255)
    }
}
