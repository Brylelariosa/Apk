package com.projectcrystal.app.core.diagnostics

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

/**
 * Append-only log of what each restoration run actually did — params used,
 * per-stage timings, and how much the output differs from the input (see
 * [BitmapDiff]) — persisted to app storage so it can be shared off-device.
 * This exists specifically because the target device has no adb/logcat
 * access (see BUILD.md); Logcat alone would be invisible to whoever's
 * debugging this. Every entry is a structured restoration-run summary or
 * failure, not free-form chatter, so the log stays short enough to paste
 * into a chat.
 */
object DiagnosticLog {
    private const val MAX_BYTES = 512 * 1024
    private const val FILE_NAME = "crystal_debug.log"
    private val lock = ReentrantLock()
    private val timestampFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US)

    fun file(context: Context): File {
        val dir = File(context.applicationContext.filesDir, "diagnostics").apply { mkdirs() }
        return File(dir, FILE_NAME)
    }

    fun log(context: Context, tag: String, message: String) = lock.withLock {
        runCatching {
            val target = file(context)
            target.appendText("${timestampFormat.format(Date())} [$tag] $message\n")
            trimIfNeeded(target)
        }
    }

    fun logFailure(context: Context, tag: String, throwable: Throwable) = log(
        context, tag,
        "FAILED: ${throwable.javaClass.simpleName}: ${throwable.message}\n${throwable.stackTraceToString()}",
    )

    fun clear(context: Context) = lock.withLock { runCatching { file(context).writeText("") } }

    /** Share-sheet intent so the log can be handed off (e.g. pasted into a chat) without needing a file manager. */
    fun shareIntent(context: Context): Intent {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file(context))
        return Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    /** Drops the oldest half once over the cap rather than truncating mid-line, so the log always ends readable. */
    private fun trimIfNeeded(target: File) {
        if (target.length() <= MAX_BYTES) return
        val lines = target.readLines()
        target.writeText(lines.takeLast(lines.size / 2).joinToString("\n", postfix = "\n"))
    }
}
