package com.projectcrystal.app.ui.home

import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.FileProvider
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import com.projectcrystal.app.R
import com.projectcrystal.app.data.repository.ImageRepository
import com.projectcrystal.app.databinding.FragmentHomeBinding
import com.projectcrystal.app.ui.common.ViewModelFactory
import com.projectcrystal.app.util.setVisibleOrGone
import kotlinx.coroutines.launch
import java.io.File

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    private val viewModel: HomeViewModel by viewModels {
        ViewModelFactory { HomeViewModel(ImageRepository(requireContext().applicationContext)) }
    }

    private val adapter = RecentImageAdapter { entity -> openEditorFor(Uri.parse(entity.originalPath), entity.id) }

    private var pendingCameraUri: Uri? = null

    private val pickImage = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        uri?.let { openEditorFor(it) }
    }

    private val takePhoto = registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        if (success) pendingCameraUri?.let { openEditorFor(it) }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        pendingCameraUri = savedInstanceState?.getString(KEY_PENDING_CAMERA_URI)?.let(Uri::parse)
        return binding.root
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        // The camera app runs as a separate foreground process; if the
        // system kills this app in the background while it's active (real
        // risk here given largeHeap=true on a low-RAM device), this Fragment
        // gets recreated from scratch on return and a plain field would
        // silently lose the URI, so the captured photo would never open.
        pendingCameraUri?.let { outState.putString(KEY_PENDING_CAMERA_URI, it.toString()) }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.recentImagesRecycler.adapter = adapter

        bindActionCard(binding.cardOpenImage, R.drawable.ic_gallery, R.string.home_open_image) {
            pickImage.launch(androidx.activity.result.PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }
        bindActionCard(binding.cardTakePhoto, R.drawable.ic_camera, R.string.home_take_photo) { launchCamera() }
        bindActionCard(binding.cardBatch, R.drawable.ic_batch, R.string.home_batch_processing) {
            findNavController().navigate(R.id.batchFragment)
        }
        bindActionCard(binding.cardHistory, R.drawable.ic_history, R.string.home_history) {
            findNavController().navigate(R.id.action_home_to_history)
        }
        bindActionCard(binding.cardFavorites, R.drawable.ic_favorite, R.string.home_favorites) {
            findNavController().navigate(R.id.historyFragment, bundleOf("favoritesOnly" to true))
        }
        bindActionCard(binding.cardSettings, R.drawable.ic_settings, R.string.home_settings) {
            findNavController().navigate(R.id.settingsFragment)
        }

        binding.seeAllRecent.setOnClickListener { findNavController().navigate(R.id.action_home_to_history) }

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.recentImages.collect { entries ->
                    adapter.submitList(entries)
                    binding.recentEmptyLabel.setVisibleOrGone(entries.isEmpty())
                    binding.recentImagesRecycler.setVisibleOrGone(entries.isNotEmpty())
                }
            }
        }
    }

    private fun bindActionCard(
        cardBinding: com.projectcrystal.app.databinding.ItemActionCardBinding,
        iconRes: Int,
        labelRes: Int,
        onClick: () -> Unit,
    ) {
        cardBinding.actionIcon.setImageResource(iconRes)
        cardBinding.actionLabel.setText(labelRes)
        cardBinding.actionCardRoot.setOnClickListener { onClick() }
    }

    private fun launchCamera() {
        val captureDir = File(requireContext().cacheDir, "camera_captures").apply { mkdirs() }
        val photoFile = File(captureDir, "camera_${java.util.UUID.randomUUID()}.jpg")
        val uri = FileProvider.getUriForFile(requireContext(), "${requireContext().packageName}.fileprovider", photoFile)
        pendingCameraUri = uri
        takePhoto.launch(uri)
    }

    private fun openEditorFor(uri: Uri, historyEntryId: Long = -1L) {
        findNavController().navigate(
            R.id.action_home_to_editor,
            bundleOf("sourceUri" to uri.toString(), "historyEntryId" to historyEntryId),
        )
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        private const val KEY_PENDING_CAMERA_URI = "pending_camera_uri"
    }
}
