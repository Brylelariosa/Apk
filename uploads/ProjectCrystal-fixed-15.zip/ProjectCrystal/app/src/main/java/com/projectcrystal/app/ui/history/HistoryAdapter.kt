package com.projectcrystal.app.ui.history

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.projectcrystal.app.R
import com.projectcrystal.app.data.db.HistoryEntity
import com.projectcrystal.app.databinding.ItemHistoryBinding
import com.projectcrystal.app.util.setVisibleOrGone

class HistoryAdapter(
    private val onOpen: (HistoryEntity) -> Unit,
    private val onToggleFavorite: (HistoryEntity) -> Unit,
    private val onMore: (HistoryEntity, android.view.View) -> Unit,
    private val onViewLog: (HistoryEntity) -> Unit,
) : ListAdapter<HistoryEntity, HistoryAdapter.ViewHolder>(DIFF) {

    init {
        // HistoryEntity.id is a stable Room primary key, so RecyclerView can
        // track item identity across list updates for better item-animator
        // behavior (no unnecessary re-creation "flicker" on reorders).
        setHasStableIds(true)
    }

    override fun getItemId(position: Int): Long = getItem(position).id

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemHistoryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) = holder.bind(getItem(position))

    override fun onBindViewHolder(holder: ViewHolder, position: Int, payloads: MutableList<Any>) {
        if (payloads.contains(PAYLOAD_FAVORITE_CHANGED)) {
            // Only the favorite flag changed (e.g. tapping the heart icon):
            // update just that, skip re-triggering the Glide thumbnail load
            // and everything else a full rebind would touch.
            holder.bindFavorite(getItem(position))
        } else {
            onBindViewHolder(holder, position)
        }
    }

    inner class ViewHolder(private val binding: ItemHistoryBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(entity: HistoryEntity) {
            Glide.with(binding.thumbnail).load(entity.thumbnailPath).centerCrop().into(binding.thumbnail)
            binding.realityScoreLabel.text = entity.realityScore?.let { "${(it * 100).toInt()}%" } ?: "—"
            bindFavorite(entity)
            binding.thumbnail.setOnClickListener { onOpen(entity) }
            binding.moreButton.setOnClickListener { onMore(entity, it) }
            binding.logIndicator.setVisibleOrGone(!entity.diagnosticLog.isNullOrBlank())
            binding.logIndicator.setOnClickListener { onViewLog(entity) }
        }

        fun bindFavorite(entity: HistoryEntity) {
            binding.favoriteButton.setImageResource(
                if (entity.isFavorite) R.drawable.ic_favorite else R.drawable.ic_favorite_border,
            )
            binding.favoriteButton.setOnClickListener { onToggleFavorite(entity) }
        }
    }

    companion object {
        private const val PAYLOAD_FAVORITE_CHANGED = "favorite_changed"

        private val DIFF = object : DiffUtil.ItemCallback<HistoryEntity>() {
            override fun areItemsTheSame(oldItem: HistoryEntity, newItem: HistoryEntity) = oldItem.id == newItem.id
            override fun areContentsTheSame(oldItem: HistoryEntity, newItem: HistoryEntity) = oldItem == newItem
            override fun getChangePayload(oldItem: HistoryEntity, newItem: HistoryEntity): Any? =
                if (oldItem.copy(isFavorite = newItem.isFavorite) == newItem) PAYLOAD_FAVORITE_CHANGED else null
        }
    }
}
