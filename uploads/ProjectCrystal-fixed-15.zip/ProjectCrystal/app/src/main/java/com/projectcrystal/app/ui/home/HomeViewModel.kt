package com.projectcrystal.app.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.projectcrystal.app.data.db.HistoryEntity
import com.projectcrystal.app.data.repository.ImageRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn

class HomeViewModel(private val repository: ImageRepository) : ViewModel() {

    val recentImages: StateFlow<List<HistoryEntity>> = repository.observeRecent(RECENT_LIMIT)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    companion object {
        private const val RECENT_LIMIT = 12
    }
}
