package com.projectcrystal.app.ui.main

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.os.bundleOf
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import com.google.android.material.snackbar.Snackbar
import com.projectcrystal.app.R
import com.projectcrystal.app.databinding.ActivityMainBinding

/**
 * Application shell: hosts the nav graph, top app bar, bottom navigation
 * (Home / History / Settings, the frequently-used destinations) and the
 * navigation drawer (Batch Processing / Favorites / About / Help — the
 * spec's "advanced features" surface, deliberately kept out of the bottom
 * nav so that stays uncluttered).
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var navController: NavController
    private lateinit var appBarConfiguration: AppBarConfiguration

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        val navHostFragment = supportFragmentManager
            .findFragmentById(R.id.navHostFragment) as NavHostFragment
        navController = navHostFragment.navController

        appBarConfiguration = AppBarConfiguration(
            setOf(R.id.homeFragment, R.id.historyFragment, R.id.settingsFragment),
            binding.drawerLayout,
        )
        setupActionBarWithNavController(navController, appBarConfiguration)
        binding.bottomNav.setupWithNavController(navController)

        binding.navigationView.setNavigationItemSelectedListener { item ->
            binding.drawerLayout.closeDrawers()
            when (item.itemId) {
                R.id.favoritesDestination -> {
                    navController.navigate(R.id.historyFragment, bundleOf("favoritesOnly" to true))
                    true
                }
                else -> {
                    navController.navigate(item.itemId)
                    true
                }
            }
        }

        if (savedInstanceState == null) {
            handleIncomingImageIntent()
        }
    }

    /** Supports "Share to Project Crystal" from the gallery/camera (see the SEND intent-filter in the manifest). */
    private fun handleIncomingImageIntent() {
        if (intent?.action == android.content.Intent.ACTION_SEND && intent.type?.startsWith("image/") == true) {
            val uri = incomingImageUri(intent) ?: return
            navController.navigate(R.id.editorFragment, bundleOf("sourceUri" to uri.toString()))
        }
    }

    private fun incomingImageUri(intent: android.content.Intent): android.net.Uri? =
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra(android.content.Intent.EXTRA_STREAM, android.net.Uri::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(android.content.Intent.EXTRA_STREAM)
        }

    override fun onSupportNavigateUp(): Boolean =
        navController.navigateUp(appBarConfiguration) || super.onSupportNavigateUp()

    fun showMessage(message: String) {
        Snackbar.make(binding.root, message, Snackbar.LENGTH_SHORT).show()
    }
}
