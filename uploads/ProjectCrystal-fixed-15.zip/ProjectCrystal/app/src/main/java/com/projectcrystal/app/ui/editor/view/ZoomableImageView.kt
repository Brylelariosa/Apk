package com.projectcrystal.app.ui.editor.view

import android.content.Context
import android.graphics.Matrix
import android.graphics.RectF
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import androidx.appcompat.widget.AppCompatImageView
import kotlin.math.min

/**
 * Pinch-to-zoom, double-tap-zoom, and pan for the editor's main preview.
 * Implemented directly on a Matrix rather than pulling in a third-party
 * zoom-image library — the gesture math this needs (scale about the pinch
 * focal point, clamp to a min/max zoom, re-center on double tap) is
 * self-contained and small enough that a dependency would cost more in
 * APK size and version-drift risk than it would save in code.
 */
class ZoomableImageView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
) : AppCompatImageView(context, attrs, defStyleAttr) {

    private val imageMatrix2 = Matrix()
    private var currentScale = 1f

    private val scaleGestureDetector = ScaleGestureDetector(context, ScaleListener())
    private val gestureDetector = GestureDetector(context, GestureListener())

    init {
        scaleType = ScaleType.MATRIX
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleGestureDetector.onTouchEvent(event)
        gestureDetector.onTouchEvent(event)

        when (event.actionMasked) {
            MotionEvent.ACTION_MOVE -> if (event.pointerCount == 1 && !scaleGestureDetector.isInProgress) {
                val dx = event.x - lastTouchX
                val dy = event.y - lastTouchY
                imageMatrix2.postTranslate(dx, dy)
                constrainTranslation()
                imageMatrix = imageMatrix2
                lastTouchX = event.x
                lastTouchY = event.y
            }
            MotionEvent.ACTION_DOWN -> {
                lastTouchX = event.x
                lastTouchY = event.y
            }
            MotionEvent.ACTION_UP -> performClick()
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    private var lastTouchX = 0f
    private var lastTouchY = 0f

    override fun onLayout(changed: Boolean, left: Int, top: Int, right: Int, bottom: Int) {
        super.onLayout(changed, left, top, right, bottom)
        if (changed) resetToFit()
    }

    /** Centers and scales the drawable to fit the view bounds — the zoomed-out baseline state. */
    fun resetToFit() {
        val d = drawable ?: return
        val viewWidth = width.toFloat()
        val viewHeight = height.toFloat()
        if (viewWidth <= 0f || viewHeight <= 0f) return

        val scale = min(viewWidth / d.intrinsicWidth, viewHeight / d.intrinsicHeight)
        val dx = (viewWidth - d.intrinsicWidth * scale) / 2f
        val dy = (viewHeight - d.intrinsicHeight * scale) / 2f

        imageMatrix2.reset()
        imageMatrix2.postScale(scale, scale)
        imageMatrix2.postTranslate(dx, dy)
        currentScale = 1f
        imageMatrix = imageMatrix2
    }

    /**
     * Keeps the drawable from being panned or zoomed entirely off-screen:
     * centers it when it's smaller than the viewport, otherwise clamps so
     * its edges never leave a gap on the side they'd otherwise expose.
     */
    private fun constrainTranslation() {
        val d = drawable ?: return
        val viewWidth = width.toFloat()
        val viewHeight = height.toFloat()
        if (viewWidth <= 0f || viewHeight <= 0f) return

        val bounds = RectF(0f, 0f, d.intrinsicWidth.toFloat(), d.intrinsicHeight.toFloat())
        imageMatrix2.mapRect(bounds)

        val dx = when {
            bounds.width() <= viewWidth -> (viewWidth - bounds.width()) / 2f - bounds.left
            bounds.left > 0f -> -bounds.left
            bounds.right < viewWidth -> viewWidth - bounds.right
            else -> 0f
        }
        val dy = when {
            bounds.height() <= viewHeight -> (viewHeight - bounds.height()) / 2f - bounds.top
            bounds.top > 0f -> -bounds.top
            bounds.bottom < viewHeight -> viewHeight - bounds.bottom
            else -> 0f
        }

        if (dx != 0f || dy != 0f) imageMatrix2.postTranslate(dx, dy)
    }

    private inner class ScaleListener : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            val newScale = (currentScale * detector.scaleFactor).coerceIn(MIN_SCALE, MAX_SCALE)
            val factor = newScale / currentScale
            imageMatrix2.postScale(factor, factor, detector.focusX, detector.focusY)
            currentScale = newScale
            constrainTranslation()
            imageMatrix = imageMatrix2
            return true
        }
    }

    private inner class GestureListener : GestureDetector.SimpleOnGestureListener() {
        override fun onDoubleTap(e: MotionEvent): Boolean {
            if (currentScale > 1.01f) {
                resetToFit()
            } else {
                val targetScale = DOUBLE_TAP_SCALE
                // postScale multiplies onto the *current* matrix, so the
                // argument must be the incremental factor needed to reach
                // targetScale from currentScale — not targetScale itself.
                // Those only happen to match when currentScale is exactly
                // 1f; anywhere else (e.g. a pinch left it at 1.005f, just
                // under the resetToFit threshold above) this used to
                // silently zoom past the intended target and desync
                // currentScale from the matrix's actual scale, causing a
                // visible jump on the next pinch.
                val factor = targetScale / currentScale
                imageMatrix2.postScale(factor, factor, e.x, e.y)
                currentScale = targetScale
                constrainTranslation()
                imageMatrix = imageMatrix2
            }
            return true
        }

        override fun onDown(e: MotionEvent): Boolean = true
    }

    companion object {
        private const val MIN_SCALE = 1f
        private const val MAX_SCALE = 6f
        private const val DOUBLE_TAP_SCALE = 3f
    }
}
