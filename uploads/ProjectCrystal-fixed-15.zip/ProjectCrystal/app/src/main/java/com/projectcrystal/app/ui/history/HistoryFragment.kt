package com.projectcrystal.app.ui.history

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.content.getSystemService
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.GridLayoutManager
import androidx.appcompat.widget.PopupMenu
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.projectcrystal.app.R
import com.projectcrystal.app.data.db.HistoryEntity
import com.projectcrystal.app.data.repository.ImageRepository
import com.projectcrystal.app.databinding.DialogLogViewerBinding
import com.projectcrystal.app.databinding.FragmentHistoryBinding
import com.projectcrystal.app.ui.common.ViewModelFactory
import com.projectcrystal.app.util.setVisibleOrGone
import kotlinx.coroutines.launch

class HistoryFragment : Fragment() {

    private var _binding: FragmentHistoryBinding? = null
    private val binding get() = _binding!!

    private val args: HistoryFragmentArgs by navArgs()

    private val viewModel: HistoryViewModel by viewModels {
        ViewModelFactory {
            HistoryViewModel(ImageRepository(requireContext().applicationContext), args.favoritesOnly)
        }
    }

    private val adapter = HistoryAdapter(
        onOpen = { entity -> openInEditor(entity) },
        onToggleFavorite = { entity -> viewModel.toggleFavorite(entity) },
        onMore = { entity, anchor -> showMoreMenu(entity, anchor) },
        onViewLog = { entity -> viewLog(entity) },
    )

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentHistoryBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.historyRecycler.layoutManager = GridLayoutManager(requireContext(), 2)
        binding.historyRecycler.adapter = adapter

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.entries.collect { entries ->
                    adapter.submitList(entries)
                    binding.emptyLabel.setVisibleOrGone(entries.isEmpty())
                }
            }
        }
    }

    private fun openInEditor(entity: HistoryEntity) {
        findNavController().navigate(
            R.id.action_history_to_editor,
            bundleOf("sourceUri" to entity.originalPath, "historyEntryId" to entity.id),
        )
    }

    private fun showMoreMenu(entity: HistoryEntity, anchor: View) {
        PopupMenu(requireContext(), anchor).apply {
            menu.add(Menu.NONE, MENU_ITEM_EDIT_AGAIN, Menu.NONE, getString(R.string.history_edit_again))
            menu.add(Menu.NONE, MENU_ITEM_VIEW_LOG, Menu.NONE, getString(R.string.history_view_log))
            menu.add(Menu.NONE, MENU_ITEM_DELETE, Menu.NONE, getString(R.string.history_delete))
            setOnMenuItemClickListener { item ->
                when (item.itemId) {
                    MENU_ITEM_EDIT_AGAIN -> openInEditor(entity)
                    MENU_ITEM_VIEW_LOG -> viewLog(entity)
                    MENU_ITEM_DELETE -> viewModel.delete(entity)
                }
                true
            }
        }.show()
    }

    /**
     * Shows just this entry's own [HistoryEntity.diagnosticLog] — captured
     * at restore time, so it's exactly what that run produced regardless of
     * what's happened to the shared debug log file since (cleared, trimmed,
     * or overwritten by later runs). Opens a dialog rather than jumping
     * straight to a share sheet: most of the time the destination is
     * "paste into a chat", which a clipboard copy serves directly, without
     * forcing a save/share round-trip when nothing actually needs saving.
     * Share is still offered alongside it for when something *does* need
     * saving to a file or sent through another app.
     */
    private fun viewLog(entity: HistoryEntity) {
        val logText = entity.diagnosticLog
        if (logText.isNullOrBlank()) {
            Toast.makeText(requireContext(), R.string.history_no_log, Toast.LENGTH_SHORT).show()
            return
        }
        val dialogBinding = DialogLogViewerBinding.inflate(LayoutInflater.from(requireContext()))
        dialogBinding.logText.text = logText

        MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.log_dialog_title)
            .setView(dialogBinding.root)
            .setPositiveButton(R.string.log_copy) { _, _ -> copyLogToClipboard(logText) }
            .setNegativeButton(R.string.log_share) { _, _ -> shareLog(logText) }
            .show()
    }

    private fun copyLogToClipboard(logText: String) {
        val clipboard = requireContext().getSystemService<ClipboardManager>()
        clipboard?.setPrimaryClip(ClipData.newPlainText("Diagnostic log", logText))
        Toast.makeText(requireContext(), R.string.log_copied, Toast.LENGTH_SHORT).show()
    }

    private fun shareLog(logText: String) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, logText)
        }
        startActivity(Intent.createChooser(intent, getString(R.string.log_share)))
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private companion object {
        const val MENU_ITEM_EDIT_AGAIN = 1
        const val MENU_ITEM_DELETE = 2
        const val MENU_ITEM_VIEW_LOG = 3
    }
}
