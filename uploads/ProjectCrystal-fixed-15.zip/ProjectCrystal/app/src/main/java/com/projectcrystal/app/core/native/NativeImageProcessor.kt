package com.projectcrystal.app.core.native

import android.graphics.Bitmap
import com.projectcrystal.app.core.model.RestorationParams

/**
 * Thin JNI wrapper around libcrystal_native.so — this object and
 * [RestorationMetricsNative] are the *only* two files in the app that know
 * the JNI boundary's exact shape. Everything above this (Repository,
 * ViewModels, UI) speaks the app's own Kotlin model types
 * ([RestorationParams], RestorationResult) and never touches a raw
 * FloatArray or Bitmap-in/Bitmap-out pair directly.
 */
object NativeImageProcessor {

    init {
        System.loadLibrary("crystal_native")
    }

    /**
     * Runs the full Stage 1-9 restoration pipeline natively. [input] and
     * [output] must both be ARGB_8888 and the same size; [output] is
     * written in place. Returns null (and logs via JNI) if the bitmaps are
     * the wrong config/size — callers are expected to have validated that
     * already via [com.projectcrystal.app.data.repository.ImageRepository].
     */
    external fun processImage(
        input: Bitmap,
        output: Bitmap,
        params: FloatArray,
        specialMode: Int,
        conservativeMode: Boolean,
        mapMaxDimension: Int,
    ): RestorationMetricsNative?

    /**
     * Fast, single-pass sharpen/halo-suppress preview used while a slider is
     * actively being dragged — skips tiling, deconvolution and consensus
     * entirely so it can run at interactive (sub-100ms on a typical crop)
     * speed. Never used for the final export.
     */
    external fun quickPreview(
        input: Bitmap,
        output: Bitmap,
        sharpness: Float,
        haloSuppression: Float,
    )

    /**
     * A string bumped whenever the native pipeline's *behavior* changes
     * (see kEngineBuildTag in restoration_engine.h). Logged on every
     * [com.projectcrystal.app.data.repository.ImageRepository] restore so a
     * shared debug log can prove whether a given APK actually contains the
     * native changes it's supposed to, independent of anything visible from
     * Kotlin/CI alone.
     */
    external fun engineBuildTag(): String

    fun packParams(params: RestorationParams): FloatArray = params.toNativeArray()
}
