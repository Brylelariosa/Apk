package com.projectcrystal.app.core.model

/** UI-facing state machine for a single restoration run, exposed by EditorViewModel. */
sealed interface ProcessingState {
    data object Idle : ProcessingState
    data class Analyzing(val progress: Float) : ProcessingState
    data class Processing(val progress: Float, val stageLabel: String) : ProcessingState
    data class Done(val result: RestorationResult) : ProcessingState
    data class Failed(val message: String) : ProcessingState
    data object Cancelled : ProcessingState
}
