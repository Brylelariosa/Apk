package com.projectcrystal.app.ui.batch

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.WorkInfo
import androidx.work.WorkManager
import com.projectcrystal.app.core.model.RestorationParams
import com.projectcrystal.app.data.prefs.AppPreferences
import com.projectcrystal.app.data.work.RestorationWorker
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Batch processing runs every selected image through the same
 * [RestorationParams] preset (Settings' tile size / conservative mode
 * defaults, otherwise Auto) rather than exposing its own copy of the full
 * tool panel — per-image tuning is what the single-image editor is for.
 * Each image is still its own independent [RestorationWorker], so one
 * failure doesn't block the rest of the batch and progress is tracked
 * per-item.
 */
class BatchViewModel(private val appContext: Context) : ViewModel() {

    private val preferences = AppPreferences(appContext)

    private val _items = MutableStateFlow<List<BatchItem>>(emptyList())
    val items: StateFlow<List<BatchItem>> = _items.asStateFlow()

    /** Uris already being observed, so re-entering this screen (or a stray double-tap) doesn't stack duplicate WorkManager collectors onto the same item. */
    private val observedUris = mutableSetOf<Uri>()

    fun setImages(uris: List<Uri>) {
        _items.value = uris.map { BatchItem(it) }
    }

    fun startBatch(params: RestorationParams = preferences.defaultRestorationParams()) {
        _items.value.forEach { item ->
            RestorationWorker.enqueue(appContext, item.uri, params)
            observeItem(item.uri)
        }
    }

    private fun observeItem(uri: Uri) {
        if (!observedUris.add(uri)) return
        viewModelScope.launch {
            WorkManager.getInstance(appContext)
                .getWorkInfosForUniqueWorkFlow(RestorationWorker.uniqueWorkName(uri))
                .collect { infos ->
                    val info = infos.firstOrNull() ?: return@collect
                    applyStatus(uri, info)
                }
        }
    }

    private fun applyStatus(uri: Uri, info: WorkInfo) {
        val status = when (info.state) {
            WorkInfo.State.SUCCEEDED -> BatchStatus.DONE
            WorkInfo.State.FAILED, WorkInfo.State.CANCELLED -> BatchStatus.FAILED
            WorkInfo.State.RUNNING -> BatchStatus.PROCESSING
            WorkInfo.State.ENQUEUED, WorkInfo.State.BLOCKED -> BatchStatus.QUEUED
        }
        val progress = info.progress.getFloat(RestorationWorker.KEY_PROGRESS, 0f)
        _items.value = _items.value.map { if (it.uri == uri) it.copy(status = status, progress = progress) else it }
    }
}
