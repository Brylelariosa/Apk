package com.projectcrystal.app.ui.history

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.projectcrystal.app.data.db.HistoryEntity
import com.projectcrystal.app.data.repository.ImageRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class HistoryViewModel(private val repository: ImageRepository, favoritesOnly: Boolean) : ViewModel() {

    val entries: StateFlow<List<HistoryEntity>> =
        (if (favoritesOnly) repository.observeFavorites() else repository.observeAll())
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun toggleFavorite(entity: HistoryEntity) {
        viewModelScope.launch {
            runCatching { repository.toggleFavorite(entity) }
                .onFailure { Log.w(TAG, "Failed to toggle favorite for ${entity.id}", it) }
        }
    }

    fun delete(entity: HistoryEntity) {
        viewModelScope.launch {
            runCatching { repository.delete(entity) }
                .onFailure { Log.w(TAG, "Failed to delete history entry ${entity.id}", it) }
        }
    }

    private companion object {
        const val TAG = "HistoryViewModel"
    }
}
