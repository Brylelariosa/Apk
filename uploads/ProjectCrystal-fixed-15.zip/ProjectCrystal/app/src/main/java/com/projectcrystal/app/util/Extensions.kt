package com.projectcrystal.app.util

import android.content.Context
import android.util.TypedValue
import android.view.View
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.FragmentManager

fun View.visible() { visibility = View.VISIBLE }
fun View.gone() { visibility = View.GONE }
fun View.invisible() { visibility = View.INVISIBLE }
fun View.setVisibleOrGone(isVisible: Boolean) { visibility = if (isVisible) View.VISIBLE else View.GONE }

fun Context.dpToPx(dp: Float): Float =
    TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, resources.displayMetrics)

/** Clamps to [0, 1] — used pervasively when mapping slider positions to native param floats. */
fun Float.clamp01(): Float = coerceIn(0f, 1f)

/**
 * Shows [fragment] under [tag] unless one is already showing there. A plain
 * `.show(fragmentManager, tag)` on a click listener commits a new fragment
 * transaction on every call with no de-duplication, so a double-tap (easy to
 * trigger on a slower device, e.g. while the sheet's open animation is still
 * running) queues two commits for the same tag and the second one throws
 * `IllegalStateException: Fragment already added`. This is the guard that
 * belongs on every button that opens a DialogFragment/BottomSheetDialogFragment.
 */
fun FragmentManager.showOnce(fragment: DialogFragment, tag: String) {
    if (findFragmentByTag(tag) == null) fragment.show(this, tag)
}
