package com.projectcrystal.app.core.model

import kotlinx.parcelize.Parcelize
import android.os.Parcelable

/**
 * Every restore/enhance slider value in one immutable, Parcelable object —
 * this is what flows from the tool panel through the ViewModel, into
 * [com.projectcrystal.app.data.work.RestorationWorker], and finally packed
 * into the fixed-order float array [toNativeArray] hands to JNI.
 *
 * Field order in [toNativeArray] MUST match
 * crystal::kRestorationParamFloatCount's documented order in
 * restoration_params.h. [conservativeMode] and [specialMode] cross the JNI
 * boundary as separate explicit arguments, not packed into the array.
 */
@Parcelize
data class RestorationParams(
    val blurStrength: Float = 0.5f,
    val noiseReduction: Float = 0.5f,
    val sharpness: Float = 0.5f,
    val textureRecovery: Float = 0.4f,
    val haloSuppression: Float = 0.6f,
    val frequencyStrength: Float = 0.5f,
    val contrast: Float = 0f,
    val brightness: Float = 0f,
    val saturation: Float = 0f,
    val temperature: Float = 0f,
    val tint: Float = 0f,
    val tileSize: Int = 256,
    val richardsonLucyIterations: Int = 6,
    val edgeEnhancement: Float = 0.5f,
    val localContrast: Float = 0.3f,
    val conservativeMode: Boolean = true,
    val specialMode: SpecialMode = SpecialMode.AUTO,
) : Parcelable {

    fun toNativeArray(): FloatArray = floatArrayOf(
        blurStrength, noiseReduction, sharpness, textureRecovery, haloSuppression,
        frequencyStrength, contrast, brightness, saturation, temperature, tint,
        tileSize.toFloat(), richardsonLucyIterations.toFloat(), edgeEnhancement, localContrast,
    )

    companion object {
        const val PARAM_COUNT = 15

        /** Presets applied when the user picks a special mode from the tool panel. */
        fun forSpecialMode(mode: SpecialMode): RestorationParams = when (mode) {
            SpecialMode.DOCUMENT, SpecialMode.TEXT_ENHANCEMENT -> RestorationParams(
                specialMode = mode, haloSuppression = 0.3f, frequencyStrength = 0.75f,
                textureRecovery = 0.1f, sharpness = 0.65f,
            )
            SpecialMode.OLD_PHOTO -> RestorationParams(
                specialMode = mode, noiseReduction = 0.65f, conservativeMode = true, haloSuppression = 0.65f,
            )
            SpecialMode.PORTRAIT -> RestorationParams(specialMode = mode, haloSuppression = 0.6f)
            SpecialMode.SCREENSHOT -> RestorationParams(
                specialMode = mode, textureRecovery = 0.1f, frequencyStrength = 0.6f,
            )
            SpecialMode.LANDSCAPE, SpecialMode.AUTO -> RestorationParams(specialMode = mode)
        }
    }
}
