package com.projectcrystal.app.data.export

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.exifinterface.media.ExifInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream

/**
 * Writes a restored image out to the shared Pictures library. Two code
 * paths, split at API 29 (scoped storage): MediaStore.insert() with
 * RELATIVE_PATH on 29+, and a direct file write into the public Pictures
 * directory (requires the legacy WRITE_EXTERNAL_STORAGE permission, granted
 * by the manifest's maxSdkVersion=28 request) below it. EXIF metadata is
 * copied from the original file when [ExportOptions.preserveMetadata] is
 * set and the target format supports EXIF (JPEG only — PNG/WebP via
 * Android's encoder don't carry it).
 */
class ExportManager(private val context: Context) {

    sealed interface ExportResult {
        data class Success(val displayPath: String) : ExportResult
        data class Failure(val message: String) : ExportResult
    }

    suspend fun export(sourceImagePath: String, originalUriForExif: String?, options: ExportOptions): ExportResult =
        withContext(Dispatchers.IO) {
            val bitmap = BitmapFactory.decodeFile(sourceImagePath)
                ?: return@withContext ExportResult.Failure("Unable to read restored image")
            try {
                val filename = "${sanitizeFilename(options.filename)}.${options.format.extension}"
                val copyExif = options.preserveMetadata && options.format == ExportFormat.JPEG

                val displayPath = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    exportViaMediaStore(bitmap, filename, options, originalUriForExif.takeIf { copyExif })
                } else {
                    exportLegacy(bitmap, filename, options).also { path ->
                        if (copyExif) copyExifToFile(originalUriForExif, path)
                    }
                }

                ExportResult.Success(displayPath)
            } catch (e: Exception) {
                ExportResult.Failure(e.message ?: "Export failed")
            } finally {
                bitmap.recycle()
            }
        }

    /**
     * [exifSourceUri], when non-null, is copied onto the new MediaStore row
     * *before* IS_PENDING is cleared: this keeps "write pixels, write
     * metadata, publish" atomic from any other app's point of view, and
     * avoids relying on this app still holding write access to its own row
     * after the row has already been published.
     */
    private fun exportViaMediaStore(bitmap: Bitmap, filename: String, options: ExportOptions, exifSourceUri: String?): String {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, filename)
            put(MediaStore.Images.Media.MIME_TYPE, options.format.mimeType)
            put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/ProjectCrystal")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: error("MediaStore rejected the insert")

        resolver.openOutputStream(uri)?.use { out -> writeBitmap(bitmap, options, out) }
            ?: error("Unable to open output stream")

        if (exifSourceUri != null) {
            copyExifViaFileDescriptor(exifSourceUri, uri)
        }

        values.clear()
        values.put(MediaStore.Images.Media.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
        return uri.toString()
    }

    private fun exportLegacy(bitmap: Bitmap, filename: String, options: ExportOptions): String {
        @Suppress("DEPRECATION")
        val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "ProjectCrystal")
        if (!dir.exists()) dir.mkdirs()
        val file = File(dir, filename)
        FileOutputStream(file).use { out -> writeBitmap(bitmap, options, out) }
        return file.absolutePath
    }

    private fun writeBitmap(bitmap: Bitmap, options: ExportOptions, out: OutputStream) {
        val format = when (options.format) {
            ExportFormat.PNG -> Bitmap.CompressFormat.PNG
            ExportFormat.JPEG -> Bitmap.CompressFormat.JPEG
            ExportFormat.WEBP -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Bitmap.CompressFormat.WEBP_LOSSY
            } else {
                @Suppress("DEPRECATION")
                Bitmap.CompressFormat.WEBP
            }
        }
        bitmap.compress(format, options.quality, out)
    }

    /** Legacy (pre-API 29) path: [exportedPath] is already a real filesystem path, so ExifInterface(String) works directly. */
    private fun copyExifToFile(originalUriString: String?, exportedPath: String) {
        val originalUri = originalUriString ?: return
        runCatching {
            val sourceExif = context.contentResolver.openInputStream(Uri.parse(originalUri))?.use {
                ExifInterface(it)
            } ?: return
            val targetExif = ExifInterface(exportedPath)
            EXIF_TAGS_TO_COPY.forEach { tag ->
                sourceExif.getAttribute(tag)?.let { targetExif.setAttribute(tag, it) }
            }
            targetExif.saveAttributes()
        }
    }

    /**
     * MediaStore (API 29+) path: [targetUri] is a content:// row we just
     * inserted ourselves, so ExifInterface needs a writable FileDescriptor
     * rather than a filesystem path. This is the piece that was missing
     * before — without it, "preserve metadata" silently did nothing on
     * every device running Android 10+.
     */
    private fun copyExifViaFileDescriptor(originalUriString: String, targetUri: Uri) {
        runCatching {
            val sourceExif = context.contentResolver.openInputStream(Uri.parse(originalUriString))?.use {
                ExifInterface(it)
            } ?: return
            context.contentResolver.openFileDescriptor(targetUri, "rw")?.use { pfd ->
                val targetExif = ExifInterface(pfd.fileDescriptor)
                EXIF_TAGS_TO_COPY.forEach { tag ->
                    sourceExif.getAttribute(tag)?.let { targetExif.setAttribute(tag, it) }
                }
                targetExif.saveAttributes()
            }
        }
    }

    /** Strips anything that isn't a safe filename character, guarding both path traversal and legacy exportLegacy()'s raw File(dir, filename). */
    private fun sanitizeFilename(raw: String): String {
        val cleaned = raw.replace(UNSAFE_FILENAME_CHARS, "_").trim('_', '.', ' ')
        return cleaned.ifBlank { ExportOptions.defaultFilename() }.take(MAX_FILENAME_LENGTH)
    }

    companion object {
        private val EXIF_TAGS_TO_COPY = listOf(
            ExifInterface.TAG_DATETIME,
            ExifInterface.TAG_GPS_LATITUDE,
            ExifInterface.TAG_GPS_LONGITUDE,
            ExifInterface.TAG_MAKE,
            ExifInterface.TAG_MODEL,
        )
        private val UNSAFE_FILENAME_CHARS = Regex("[^A-Za-z0-9._-]")
        private const val MAX_FILENAME_LENGTH = 120
    }
}
