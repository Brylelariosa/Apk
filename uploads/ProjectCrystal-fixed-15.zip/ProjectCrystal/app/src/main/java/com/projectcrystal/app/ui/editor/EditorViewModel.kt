package com.projectcrystal.app.ui.editor

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.WorkInfo
import androidx.work.WorkManager
import com.projectcrystal.app.core.model.ProcessingState
import com.projectcrystal.app.core.model.RestorationParams
import com.projectcrystal.app.core.model.SpecialMode
import com.projectcrystal.app.data.prefs.AppPreferences
import com.projectcrystal.app.data.repository.ImageRepository
import com.projectcrystal.app.data.work.RestorationWorker
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Owns everything the Editor screen needs: the source image, the current
 * slider state, and the lifecycle of a restoration run. Restoration itself
 * always goes through [RestorationWorker] (never a raw coroutine) so it
 * survives the app being backgrounded and can be cancelled from the UI.
 *
 * Scoped to the Activity (shared with [ToolBottomSheetFragment] and
 * [ExportDialogFragment], both children of [EditorFragment]) rather than to
 * the Fragment itself, so it outlives a single EditorFragment instance —
 * which is exactly why [setSourceImage] has to explicitly reset state
 * rather than relying on a fresh ViewModel per visit.
 */
class EditorViewModel(
    private val appContext: Context,
    private val repository: ImageRepository,
) : ViewModel() {

    private val preferences = AppPreferences(appContext)

    private val _sourceUri = MutableStateFlow<Uri?>(null)
    val sourceUri: StateFlow<Uri?> = _sourceUri.asStateFlow()

    private val _params = MutableStateFlow(preferences.defaultRestorationParams())
    val params: StateFlow<RestorationParams> = _params.asStateFlow()

    private val _processingState = MutableStateFlow<ProcessingState>(ProcessingState.Idle)
    val processingState: StateFlow<ProcessingState> = _processingState.asStateFlow()

    private val _showingOriginal = MutableStateFlow(false)
    val showingOriginal: StateFlow<Boolean> = _showingOriginal.asStateFlow()

    private var observeJob: Job? = null

    /**
     * Resets all per-image state. Because this ViewModel is Activity-scoped
     * (see class doc), it's reused across every "open a different image in
     * the editor" navigation within the same app session — without this
     * reset, a WorkManager observer left over from a previous image (backed
     * out of before it finished) could still be listening when it
     * eventually completes, and would overwrite whatever the user is
     * looking at now with the *previous* image's result.
     */
    fun setSourceImage(uri: Uri) {
        val isNewImage = _sourceUri.value != uri
        if (isNewImage) {
            observeJob?.cancel()
            observeJob = null
            _params.value = preferences.defaultRestorationParams()
            _processingState.value = ProcessingState.Idle
            _showingOriginal.value = false
        }
        _sourceUri.value = uri
    }

    /** Decodes the current source image for preview. Delegates to the repository so the Fragment never touches it directly. */
    suspend fun decodeOriginal(): Bitmap {
        val uri = _sourceUri.value ?: error("No source image set")
        return repository.decodeForProcessing(uri)
    }

    fun loadParams(params: RestorationParams) {
        _params.value = params
    }

    /** Reopens a previously-saved history entry's slider state ("edit again"), overriding whatever setSourceImage() just defaulted to. */
    suspend fun loadHistoryParams(historyEntryId: Long) {
        val entity = repository.historyEntryById(historyEntryId) ?: return
        loadParams(repository.paramsFor(entity))
    }

    fun updateParams(transform: (RestorationParams) -> RestorationParams) {
        _params.value = transform(_params.value)
    }

    fun applySpecialMode(mode: SpecialMode) {
        _params.value = RestorationParams.forSpecialMode(mode)
    }

    fun toggleBeforeAfter() {
        _showingOriginal.value = !_showingOriginal.value
    }

    fun startRestoration() {
        val uri = _sourceUri.value ?: return
        _processingState.value = ProcessingState.Analyzing(0f)
        RestorationWorker.enqueue(appContext, uri, _params.value)
        observeWork(uri)
    }

    fun cancelRestoration() {
        val uri = _sourceUri.value ?: return
        WorkManager.getInstance(appContext).cancelUniqueWork(RestorationWorker.uniqueWorkName(uri))
        _processingState.value = ProcessingState.Cancelled
    }

    private fun observeWork(uri: Uri) {
        observeJob?.cancel()
        observeJob = viewModelScope.launch {
            WorkManager.getInstance(appContext)
                .getWorkInfosForUniqueWorkFlow(RestorationWorker.uniqueWorkName(uri))
                .collect { infos ->
                    val info = infos.firstOrNull() ?: return@collect
                    handleWorkInfo(info)
                }
        }
    }

    private suspend fun handleWorkInfo(info: WorkInfo) {
        when (info.state) {
            WorkInfo.State.RUNNING, WorkInfo.State.ENQUEUED -> {
                val progress = info.progress.getFloat(RestorationWorker.KEY_PROGRESS, 0f)
                _processingState.value = if (progress < ANALYSIS_PROGRESS_CUTOFF) {
                    ProcessingState.Analyzing(progress)
                } else {
                    ProcessingState.Processing(progress, stageLabelFor(progress))
                }
            }
            WorkInfo.State.SUCCEEDED -> {
                val path = info.outputData.getString(RestorationWorker.KEY_RESULT_PATH)
                if (path == null) {
                    _processingState.value = ProcessingState.Failed("Missing output path")
                    return
                }
                _processingState.value = try {
                    ProcessingState.Done(repository.loadResult(path))
                } catch (e: Exception) {
                    // The metrics sidecar file backing this result can go
                    // missing (low-storage cache eviction between the
                    // worker finishing and this collector running) or be
                    // corrupted; treat that as a failed run instead of
                    // crashing the collector, which would otherwise take
                    // down this whole Flow subscription.
                    ProcessingState.Failed(e.message ?: "Couldn't load the restored result")
                }
            }
            WorkInfo.State.FAILED -> {
                val message = info.outputData.getString(RestorationWorker.KEY_ERROR) ?: "Restoration failed"
                _processingState.value = ProcessingState.Failed(message)
            }
            WorkInfo.State.CANCELLED -> _processingState.value = ProcessingState.Cancelled
            WorkInfo.State.BLOCKED -> Unit
        }
    }

    private fun stageLabelFor(progress: Float): String = when {
        progress < 0.4f -> "Generating restoration candidates"
        progress < 0.6f -> "Building consensus"
        progress < 0.75f -> "Detecting artifacts"
        progress < 0.9f -> "Applying reality lock"
        else -> "Finalizing"
    }

    companion object {
        private const val ANALYSIS_PROGRESS_CUTOFF = 0.15f
    }
}
