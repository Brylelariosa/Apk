package com.projectcrystal.app.core.native

/**
 * Mirrors the object jni_utils.cpp::buildMetricsObject constructs. Field
 * order and types are load-bearing: they must match the JNI constructor
 * signature "(FII[F[F[F[F[FDDDDDDDDDDDDI)V" built in that function exactly, or
 * NewObject() will throw NoSuchMethodError at runtime. This class is a
 * plain JNI-facing data carrier — NativeImageProcessorRepository maps it
 * into the app's own [com.projectcrystal.app.core.model.RestorationResult]
 * immediately after the JNI call returns; nothing else in the app should
 * hold a reference to this class.
 */
data class RestorationMetricsNative(
    val realityScore: Float,
    val mapWidth: Int,
    val mapHeight: Int,
    val blurMap: FloatArray,
    val noiseMap: FloatArray,
    val edgeMap: FloatArray,
    val confidenceMap: FloatArray,
    val artifactMap: FloatArray,
    val analysisMs: Double,
    val candidateGenMs: Double,
    val consensusMs: Double,
    val artifactMs: Double,
    val frequencyGateMs: Double,
    val realityLockMs: Double,
    val blendMs: Double,
    val totalMs: Double,
    val consensusDelta: Double,
    val artifactDelta: Double,
    val freqGateDelta: Double,
    val realityLockDelta: Double,
    val tileCount: Int,
)
