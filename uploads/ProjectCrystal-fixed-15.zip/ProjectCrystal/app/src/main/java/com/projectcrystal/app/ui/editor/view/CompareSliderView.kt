package com.projectcrystal.app.ui.editor.view

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import androidx.core.content.ContextCompat
import com.projectcrystal.app.R

/**
 * Split before/after comparison: draws [afterBitmap] full-frame, then the
 * portion of [beforeBitmap] to the left of a draggable vertical divider,
 * with a thin handle the user can drag. Both bitmaps are letterboxed
 * identically (same fit-center transform) so the split lines up pixel-for-
 * pixel regardless of the two images' aspect ratio being briefly
 * mismatched mid-crop.
 */
class CompareSliderView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
) : View(context, attrs, defStyleAttr) {

    var beforeBitmap: Bitmap? = null
        set(value) { field = value; invalidate() }
    var afterBitmap: Bitmap? = null
        set(value) { field = value; invalidate() }

    /** 0..1, fraction of the view width where the divider currently sits. */
    var dividerFraction: Float = 0.5f
        set(value) { field = value.coerceIn(0f, 1f); invalidate() }

    private val density = context.resources.displayMetrics.density

    private val handlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; strokeWidth = 4f }
    private val handleFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    // Thin accent ring on the handle, tying it back to the app's own theme
    // rather than sitting there as a plain white dot with no drag affordance.
    private val handleRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(context, R.color.crystal_primary)
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }
    // The "< >" chevrons inside the handle are the actual drag affordance —
    // a plain circle doesn't read as draggable at a glance the way this
    // does. Dark-on-white keeps it legible regardless of what's behind the
    // divider.
    private val chevronPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(context, R.color.crystal_on_primary)
        style = Paint.Style.STROKE
        strokeWidth = 3f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val chevronPath = Path()
    private val afterSrcRect = Rect()
    private val beforeSrcRect = Rect()
    private val destRect = RectF()

    // Corner tags identifying which side is which — always pinned to the
    // frame's top corners regardless of divider position, same as the
    // before/after labels in the HTML comparison mockup. Reuses
    // R.string.compare_before/compare_after, which existed already but had
    // never actually been wired up to a view.
    private val tagTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 12f * density
        typeface = Typeface.DEFAULT_BOLD
    }
    private val tagBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(160, 0, 0, 0) }
    private val tagBgRect = RectF()
    private val tagTextBounds = Rect()
    private val beforeLabel = context.getString(R.string.compare_before)
    private val afterLabel = context.getString(R.string.compare_after)

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val after = afterBitmap ?: return
        val before = beforeBitmap ?: return

        computeFitRect(after, destRect)
        afterSrcRect.set(0, 0, after.width, after.height)
        canvas.drawBitmap(after, afterSrcRect, destRect, null)

        val dividerX = destRect.left + destRect.width() * dividerFraction
        canvas.save()
        canvas.clipRect(destRect.left, destRect.top, dividerX, destRect.bottom)
        beforeSrcRect.set(0, 0, before.width, before.height)
        canvas.drawBitmap(before, beforeSrcRect, destRect, null)
        canvas.restore()

        drawTag(canvas, beforeLabel, atRight = false)
        drawTag(canvas, afterLabel, atRight = true)

        canvas.drawLine(dividerX, destRect.top, dividerX, destRect.bottom, handlePaint)
        val handleCy = (destRect.top + destRect.bottom) / 2f
        canvas.drawCircle(dividerX, handleCy, HANDLE_RADIUS_PX, handleFillPaint)
        canvas.drawCircle(dividerX, handleCy, HANDLE_RADIUS_PX - handleRingPaint.strokeWidth / 2f, handleRingPaint)
        drawChevrons(canvas, dividerX, handleCy)
    }

    /** Draws a "< >" glyph centered on (cx, cy), scaled off the handle radius. */
    private fun drawChevrons(canvas: Canvas, cx: Float, cy: Float) {
        val armLen = HANDLE_RADIUS_PX * 0.34f
        val armSpan = armLen * 0.42f
        val gap = HANDLE_RADIUS_PX * 0.24f

        chevronPath.reset()
        chevronPath.moveTo(cx - gap + armSpan, cy - armLen)
        chevronPath.lineTo(cx - gap - armSpan, cy)
        chevronPath.lineTo(cx - gap + armSpan, cy + armLen)
        canvas.drawPath(chevronPath, chevronPaint)

        chevronPath.reset()
        chevronPath.moveTo(cx + gap - armSpan, cy - armLen)
        chevronPath.lineTo(cx + gap + armSpan, cy)
        chevronPath.lineTo(cx + gap - armSpan, cy + armLen)
        canvas.drawPath(chevronPath, chevronPaint)
    }

    /** Draws a rounded, semi-opaque pill with [text], pinned to a top corner of [destRect]. */
    private fun drawTag(canvas: Canvas, text: String, atRight: Boolean) {
        tagTextPaint.getTextBounds(text, 0, text.length, tagTextBounds)
        val padH = 8f * density
        val padV = 5f * density
        val margin = 8f * density
        val w = tagTextBounds.width() + padH * 2
        val h = tagTextPaint.textSize + padV * 2

        val left = if (atRight) destRect.right - margin - w else destRect.left + margin
        tagBgRect.set(left, destRect.top + margin, left + w, destRect.top + margin + h)
        canvas.drawRoundRect(tagBgRect, 6f * density, 6f * density, tagBgPaint)

        val textX = tagBgRect.left + padH
        val textY = tagBgRect.top + padV - tagTextPaint.ascent()
        canvas.drawText(text, textX, textY, tagTextPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                if (destRect.width() > 0) {
                    dividerFraction = (event.x - destRect.left) / destRect.width()
                }
                parent?.requestDisallowInterceptTouchEvent(true)
                return true
            }
            MotionEvent.ACTION_UP -> {
                performClick()
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    private fun computeFitRect(bitmap: Bitmap, out: RectF) {
        val viewW = width.toFloat()
        val viewH = height.toFloat()
        val scale = minOf(viewW / bitmap.width, viewH / bitmap.height)
        val w = bitmap.width * scale
        val h = bitmap.height * scale
        val left = (viewW - w) / 2f
        val top = (viewH - h) / 2f
        out.set(left, top, left + w, top + h)
    }

    companion object {
        private const val HANDLE_RADIUS_PX = 24f
    }
}
