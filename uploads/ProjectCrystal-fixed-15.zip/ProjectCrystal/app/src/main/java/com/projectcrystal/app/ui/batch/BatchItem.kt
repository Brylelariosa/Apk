package com.projectcrystal.app.ui.batch

import android.net.Uri

enum class BatchStatus { QUEUED, PROCESSING, DONE, FAILED }

data class BatchItem(
    val uri: Uri,
    val status: BatchStatus = BatchStatus.QUEUED,
    val progress: Float = 0f,
)
