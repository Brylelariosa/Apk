package com.projectcrystal.app.ui.batch

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.projectcrystal.app.databinding.FragmentBatchBinding
import com.projectcrystal.app.ui.common.ViewModelFactory
import com.projectcrystal.app.util.setVisibleOrGone
import kotlinx.coroutines.launch

class BatchFragment : Fragment() {

    private var _binding: FragmentBatchBinding? = null
    private val binding get() = _binding!!

    private val viewModel: BatchViewModel by viewModels {
        ViewModelFactory { BatchViewModel(requireContext().applicationContext) }
    }

    private val adapter = BatchAdapter()

    private val pickImages = registerForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(MAX_BATCH_SIZE)) { uris ->
        if (uris.isNotEmpty()) {
            viewModel.setImages(uris)
            binding.startBatchButton.isEnabled = true
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentBatchBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.batchRecycler.adapter = adapter

        binding.selectImagesButton.setOnClickListener {
            pickImages.launch(androidx.activity.result.PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }
        binding.startBatchButton.setOnClickListener {
            viewModel.startBatch()
            binding.startBatchButton.isEnabled = false
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.items.collect { items ->
                    adapter.submitList(items)
                    binding.batchEmptyLabel.setVisibleOrGone(items.isEmpty())
                    binding.batchRecycler.setVisibleOrGone(items.isNotEmpty())
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        private const val MAX_BATCH_SIZE = 20
    }
}
