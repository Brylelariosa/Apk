package com.projectcrystal.app.ui.settings

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatDelegate
import androidx.navigation.fragment.findNavController
import androidx.preference.ListPreference
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat
import com.projectcrystal.app.R
import com.projectcrystal.app.core.diagnostics.DiagnosticLog
import com.projectcrystal.app.data.prefs.AppPreferences
import com.projectcrystal.app.ui.main.MainActivity

class SettingsFragment : PreferenceFragmentCompat() {

    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        setPreferencesFromResource(R.xml.preferences, rootKey)

        findPreference<ListPreference>(AppPreferences.KEY_THEME)?.setOnPreferenceChangeListener { _, newValue ->
            applyTheme(newValue as String)
            true
        }
        findPreference<Preference>("pref_about")?.setOnPreferenceClickListener {
            findNavController().navigate(R.id.aboutFragment)
            true
        }
        findPreference<Preference>("pref_help")?.setOnPreferenceClickListener {
            findNavController().navigate(R.id.helpFragment)
            true
        }
        findPreference<Preference>("pref_share_debug_log")?.setOnPreferenceClickListener {
            shareDebugLog()
            true
        }
        findPreference<Preference>("pref_clear_debug_log")?.setOnPreferenceClickListener {
            DiagnosticLog.clear(requireContext().applicationContext)
            showMessage(getString(R.string.settings_clear_debug_log_title))
            true
        }
    }

    private fun shareDebugLog() {
        val context = requireContext().applicationContext
        if (!DiagnosticLog.file(context).let { it.exists() && it.length() > 0 }) {
            showMessage(getString(R.string.settings_no_debug_log_message))
            return
        }
        val chooser = Intent.createChooser(DiagnosticLog.shareIntent(context), getString(R.string.settings_share_debug_log_title))
        startActivity(chooser)
    }

    private fun showMessage(message: String) {
        (activity as? MainActivity)?.showMessage(message)
    }

    private fun applyTheme(value: String) {
        AppCompatDelegate.setDefaultNightMode(
            when (value) {
                "light" -> AppCompatDelegate.MODE_NIGHT_NO
                "dark" -> AppCompatDelegate.MODE_NIGHT_YES
                else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
            },
        )
    }
}
