package com.projectcrystal.app.core.model

/**
 * The special processing modes from the tool panel. Each one nudges
 * [RestorationParams] toward settings tuned for that content type before
 * the native pipeline runs (see RestorationEngine::applySpecialMode on the
 * native side) — the mode itself carries no logic, it's just a label the
 * native engine interprets.
 *
 * [nativeValue] MUST stay in sync with crystal::SpecialMode in
 * restoration_params.h.
 */
enum class SpecialMode(val nativeValue: Int, val labelResId: Int) {
    AUTO(0, com.projectcrystal.app.R.string.mode_auto),
    PORTRAIT(1, com.projectcrystal.app.R.string.mode_portrait),
    LANDSCAPE(2, com.projectcrystal.app.R.string.mode_landscape),
    DOCUMENT(3, com.projectcrystal.app.R.string.mode_document),
    SCREENSHOT(4, com.projectcrystal.app.R.string.mode_screenshot),
    OLD_PHOTO(5, com.projectcrystal.app.R.string.mode_old_photo),
    TEXT_ENHANCEMENT(6, com.projectcrystal.app.R.string.mode_text_enhancement);

    companion object {
        fun fromNativeValue(value: Int): SpecialMode = entries.firstOrNull { it.nativeValue == value } ?: AUTO
    }
}
