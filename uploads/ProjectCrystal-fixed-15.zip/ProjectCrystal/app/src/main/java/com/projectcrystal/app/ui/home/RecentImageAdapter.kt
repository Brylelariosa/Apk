package com.projectcrystal.app.ui.home

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.projectcrystal.app.data.db.HistoryEntity
import com.projectcrystal.app.databinding.ItemRecentImageBinding

class RecentImageAdapter(private val onClick: (HistoryEntity) -> Unit) :
    ListAdapter<HistoryEntity, RecentImageAdapter.ViewHolder>(DIFF) {

    init {
        setHasStableIds(true)
    }

    override fun getItemId(position: Int): Long = getItem(position).id

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemRecentImageBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) = holder.bind(getItem(position))

    inner class ViewHolder(private val binding: ItemRecentImageBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(entity: HistoryEntity) {
            Glide.with(binding.thumbnail).load(entity.thumbnailPath).centerCrop().into(binding.thumbnail)
            binding.realityScoreLabel.text = entity.realityScore?.let { "${(it * 100).toInt()}%" } ?: "—"
            binding.root.setOnClickListener { onClick(entity) }
        }
    }

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<HistoryEntity>() {
            override fun areItemsTheSame(oldItem: HistoryEntity, newItem: HistoryEntity) = oldItem.id == newItem.id
            override fun areContentsTheSame(oldItem: HistoryEntity, newItem: HistoryEntity) = oldItem == newItem
        }
    }
}
