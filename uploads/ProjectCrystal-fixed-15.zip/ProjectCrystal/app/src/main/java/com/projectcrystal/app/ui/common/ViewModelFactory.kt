package com.projectcrystal.app.ui.common

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider

/**
 * Tiny generic factory used everywhere a ViewModel needs a constructor
 * argument (almost always [com.projectcrystal.app.data.repository.ImageRepository]).
 *
 * The project deliberately uses this instead of a Hilt/Dagger graph: with
 * one repository and a handful of ViewModels, a DI framework's annotation
 * processor would add real build-time risk (it can't be verified without a
 * full compile) for very little payoff over "pass a lambda". If the
 * dependency graph grows significantly, Hilt is the natural next step —
 * see ARCHITECTURE.md, "Dependency injection".
 */
class ViewModelFactory<VM : ViewModel>(private val creator: () -> VM) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = creator() as T
}
