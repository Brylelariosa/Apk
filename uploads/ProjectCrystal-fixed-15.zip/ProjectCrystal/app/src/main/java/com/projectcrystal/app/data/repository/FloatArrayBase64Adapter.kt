package com.projectcrystal.app.data.repository

import android.util.Base64
import com.google.gson.TypeAdapter
import com.google.gson.stream.JsonReader
import com.google.gson.stream.JsonToken
import com.google.gson.stream.JsonWriter
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Serializes [FloatArray] as a single base64 string of raw little-endian
 * bytes instead of Gson's default JSON array-of-numbers.
 *
 * [RestorationResult][com.projectcrystal.app.core.model.RestorationResult]'s
 * diagnostic maps can be up to 512x512 floats each, five per restoration —
 * as decimal JSON numbers that's tens of megabytes of text per run (and a
 * slow, character-by-character parse back in); base64-encoded raw bytes are
 * roughly a third of that size and decode in one bulk operation. This is a
 * pure wire-format change: it only affects how the metrics sidecar file
 * written by [ImageRepository] is encoded on disk, not any public API shape.
 */
class FloatArrayBase64Adapter : TypeAdapter<FloatArray>() {

    override fun write(out: JsonWriter, value: FloatArray?) {
        if (value == null) {
            out.nullValue()
            return
        }
        val bytes = ByteBuffer.allocate(value.size * BYTES_PER_FLOAT).order(ByteOrder.LITTLE_ENDIAN)
        for (f in value) bytes.putFloat(f)
        out.value(Base64.encodeToString(bytes.array(), Base64.NO_WRAP))
    }

    override fun read(reader: JsonReader): FloatArray {
        if (reader.peek() == JsonToken.NULL) {
            reader.nextNull()
            return FloatArray(0)
        }
        val bytes = Base64.decode(reader.nextString(), Base64.NO_WRAP)
        val buffer = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        return FloatArray(bytes.size / BYTES_PER_FLOAT) { buffer.float }
    }

    private companion object {
        const val BYTES_PER_FLOAT = 4
    }
}
