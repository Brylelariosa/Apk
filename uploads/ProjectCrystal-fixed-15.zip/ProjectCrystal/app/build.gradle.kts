plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("kotlin-kapt")
    id("androidx.navigation.safeargs.kotlin")
    id("kotlin-parcelize")
}

android {
    namespace = "com.projectcrystal.app"
    compileSdk = 34
    ndkVersion = "25.2.9519653"

    // --- APK size ---------------------------------------------------------
    // Everything in this section trims download/install size; see
    // "APK size" in ARCHITECTURE.md for the full rationale and numbers.
    // Ship arm64-v8a only by default — it covers virtually all Android 8+
    // devices in active use and roughly halves the native-library payload
    // versus shipping both ABIs in one APK. armeabi-v7a can still be built
    // for genuinely old/32-bit-only hardware: ./gradlew assembleRelease -PincludeArmv7=true
    val includeArmv7 = project.findProperty("includeArmv7") == "true"

    defaultConfig {
        applicationId = "com.projectcrystal.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        // Only "en" resources ship by default. Transitive AndroidX/Material
        // dependencies bundle translated strings for dozens of locales;
        // without this filter every one of them ends up in the APK even
        // though the app itself isn't localized yet. Extend this set the
        // day real translations are added.
        resourceConfigurations += setOf("en")

        ndk {
            abiFilters += if (includeArmv7) listOf("arm64-v8a", "armeabi-v7a") else listOf("arm64-v8a")
        }

        externalNativeBuild {
            cmake {
                cppFlags += listOf("-std=c++17", "-fexceptions", "-frtti")
                arguments += listOf("-DANDROID_STL=c++_shared")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            // Strips symbol tables from the built .so files entirely. For a
            // native-heavy module like this one, unstripped symbols are
            // routinely several times the size of the code itself — this is
            // the single biggest native-size lever available.
            ndk {
                debugSymbolLevel = "NONE"
            }
        }
        debug {
            isMinifyEnabled = false
            isDebuggable = true
            applicationIdSuffix = ".debug"
            ndk {
                debugSymbolLevel = "FULL"
            }
        }
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
        buildConfig = true
    }

    packaging {
        jniLibs {
            // Compressed .so files: smaller APK on disk, which is what
            // matters for a CI-built artifact people install directly
            // (rather than one served through Play's per-device delivery).
            // Flip to false if this is ever distributed as an Android App
            // Bundle, where Play re-optimizes packaging itself and
            // uncompressed libs let the OS mmap them without an extraction
            // step at install time.
            useLegacyPackaging = true
        }
        resources {
            excludes += setOf(
                "/META-INF/{AL2.0,LGPL2.1}",
                "META-INF/*.version",
                "META-INF/proguard/*",
                "**/kotlin/**",
                "DebugProbesKt.bin", // coroutines debugger hook, unused in release
                "kotlin-tooling-metadata.json"
            )
        }
    }

    // Only exercised if this is ever published as an .aab instead of the
    // CI's current assembleRelease/assembleDebug APK output. Kept explicit
    // (these are AGP's defaults) so the intent is documented in one place.
    bundle {
        language { enableSplit = true }
        density { enableSplit = true }
        abi { enableSplit = true }
    }

    testOptions {
        unitTests {
            isIncludeAndroidResources = true
            isReturnDefaultValues = true
        }
    }
}

dependencies {
    // --- Core AndroidX / Kotlin ---
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.fragment:fragment-ktx:1.8.1")
    implementation("androidx.activity:activity-ktx:1.9.0")
    implementation("androidx.core:core-splashscreen:1.0.1")
    implementation("androidx.preference:preference-ktx:1.2.1")
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")
    implementation("androidx.exifinterface:exifinterface:1.3.7")
    implementation("com.google.code.gson:gson:2.11.0")

    // --- Lifecycle / Coroutines ---
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.8.2")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.2")
    implementation("androidx.lifecycle:lifecycle-livedata-ktx:2.8.2")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // --- Navigation ---
    implementation("androidx.navigation:navigation-fragment-ktx:2.7.7")
    implementation("androidx.navigation:navigation-ui-ktx:2.7.7")

    // --- Room (history / settings persistence) ---
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    kapt("androidx.room:room-compiler:2.6.1")

    // --- WorkManager (long-running background restoration) ---
    implementation("androidx.work:work-runtime-ktx:2.9.1")

    // --- RecyclerView ---
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("com.github.bumptech.glide:glide:4.16.0")

    // --- Testing ---
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.8.1")
    testImplementation("androidx.arch.core:core-testing:2.2.0")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.6.1")
    androidTestImplementation("androidx.room:room-testing:2.6.1")
    androidTestImplementation("androidx.work:work-testing:2.9.1")
    androidTestImplementation("androidx.test:runner:1.6.1")
    androidTestImplementation("androidx.test:rules:1.6.1")
}
