package dev.netcontrol.app.diag

import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.TimeZone
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CrashReportTest {

    private val manila = TimeZone.getTimeZone("Asia/Manila")
    private val utc = TimeZone.getTimeZone("UTC")

    private fun millis(hour: Int, minute: Int, second: Int): Long =
        ZonedDateTime.of(2026, 10, 15, hour, minute, second, 0, ZoneId.of("Asia/Manila")).toInstant().toEpochMilli()

    private fun report(
        error: Throwable = IllegalStateException("boom"),
        recentLog: String? = "line 1\nline 2\n",
        details: List<Pair<String, String>> = listOf("App" to "dev.netcontrol.app 1.0.0 (code 1)", "Device" to "Acme Phone"),
        threadName: String = "main"
    ): String = CrashReport.build(millis(11, 5, 30), manila, details, threadName, error, recentLog)

    @Test
    fun fileNameUsesTheGivenTimeZone() {
        assertEquals("NetControl-crash-20261015-110530.txt", CrashReport.fileName(millis(11, 5, 30), manila))
        assertEquals("NetControl-crash-20261015-030530.txt", CrashReport.fileName(millis(11, 5, 30), utc))
    }

    @Test
    fun fileNamesSortInTimeOrder() {
        val names = listOf(millis(23, 59, 59), millis(9, 0, 0), millis(11, 5, 30)).map { CrashReport.fileName(it, manila) }
        assertEquals(
            listOf(millis(9, 0, 0), millis(11, 5, 30), millis(23, 59, 59)).map { CrashReport.fileName(it, manila) },
            names.sorted()
        )
    }

    @Test
    fun reportListsTimeDetailsThreadAndTheFullTraceWithCauses() {
        val error = IllegalStateException("outer", java.io.IOException("root cause"))
        val text = report(error = error, threadName = "worker-7")

        assertTrue(text.startsWith("NetControl crash report\nTime: 2026-10-15 11:05:30 +0800\n"))
        assertTrue(text.contains("\nApp: dev.netcontrol.app 1.0.0 (code 1)\n"))
        assertTrue(text.contains("\nDevice: Acme Phone\n"))
        assertTrue(text.contains("\nThread: worker-7\n"))
        assertTrue(text.contains("[Exception]\njava.lang.IllegalStateException: outer\n"))
        assertTrue(text.contains("\nCaused by: java.io.IOException: root cause\n"))
        assertTrue(text.endsWith("[End of report]\n"))
    }

    @Test
    fun sectionsComeInTheDocumentedOrder() {
        val text = report()
        val order = listOf("[Exception]", "[Recent log lines of this app, newest last]", "[End of report]").map { text.indexOf(it) }
        assertTrue(order.all { it >= 0 })
        assertEquals(order.sorted(), order)
    }

    @Test
    fun missingOrBlankLogIsReportedAsNotAvailable() {
        for (log in listOf(null, "", "  \n ")) {
            val text = report(recentLog = log)
            assertTrue(text.contains("[Recent log lines of this app, newest last]\n(not available)\n"))
        }
    }

    @Test
    fun logLinesAreKeptInTheirOriginalOrder() {
        val text = report(recentLog = "first\nsecond\nthird")
        assertTrue(text.contains("newest last]\nfirst\nsecond\nthird\n\n[End of report]"))
    }

    @Test
    fun anOverlongLogKeepsItsNewestEnd() {
        val log = "OLDEST\n" + "x".repeat(CrashReport.MAX_LOG_CHARS) + "\nNEWEST\n"
        val text = report(recentLog = log)
        assertTrue(text.contains("[... earlier lines cut]\n"))
        assertTrue(text.contains("NEWEST\n"))
        assertFalse(text.contains("OLDEST"))
    }

    @Test
    fun anOverlongTraceKeepsItsStartAndSaysHowMuchWasCut() {
        val text = report(error = RuntimeException("y".repeat(CrashReport.MAX_TRACE_CHARS + 5_000)))
        assertTrue(text.contains("[Exception]\njava.lang.RuntimeException: yyy"))
        assertTrue(Regex("\\[\\.\\.\\. cut, \\d+ more characters]").containsMatchIn(text))
    }

    @Test
    fun clippingLeavesShortTextAlone() {
        assertEquals("abc", CrashReport.clipHead("abc", 3))
        assertEquals("abc\n", CrashReport.clipTail("abc", 10))
        assertEquals("abc\n", CrashReport.clipTail("abc\n", 10))
    }

    @Test
    fun aThrowableThatCannotPrintItselfStillProducesAReport() {
        val broken = object : RuntimeException() {
            override fun toString(): String = throw IllegalStateException("toString is broken")
        }
        val text = report(error = broken)
        assertTrue(text.contains("stack trace unavailable: java.lang.IllegalStateException"))
        assertTrue(text.endsWith("[End of report]\n"))
    }
}
