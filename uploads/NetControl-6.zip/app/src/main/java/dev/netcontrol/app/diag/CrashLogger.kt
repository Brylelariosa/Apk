package dev.netcontrol.app.diag

import android.app.Application
import android.os.Build
import android.os.SystemClock
import java.io.File
import java.io.IOException
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit

/**
 * Writes every uncaught exception to a text file in the public Download folder so a crash can be reported
 * without adb, root, Shizuku or a PC. It is installed from `NetControlApp.attachBaseContext`, before any other
 * app code runs, so crashes while the app starts are covered too.
 *
 * A report is first written to private storage (plain file I/O) and then copied to Download through the
 * MediaStore. A report that could not be copied is retried at the next start by [exportPending].
 */
object CrashLogger {
    private const val DIR_NAME = "crash-logs"
    private const val LOG_LINES = 400
    private const val LOG_TIMEOUT_MS = 1500L
    private const val MAX_PENDING = 10

    private val lock = Any()
    private var app: Application? = null

    fun install(application: Application) {
        synchronized(lock) {
            if (app != null) return
            app = application
        }
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            try {
                record(application, thread, error)
            } catch (failure: Throwable) {
                // the reporter must never hide or replace the original crash
            } finally {
                previous?.uncaughtException(thread, error)
            }
        }
    }

    /** Copies reports that could not be exported when they were written (for example a full disk) to Download. */
    fun exportPending() {
        val application = app ?: return
        try {
            val files = pendingFiles(application).sortedBy { it.name }
            for ((index, file) in files.withIndex()) {
                // keep only the newest few if exporting keeps failing
                val exported = DownloadsWriter.saveText(application, file.name, file.readText(Charsets.UTF_8))
                if (exported || index < files.size - MAX_PENDING) file.delete()
            }
        } catch (e: Exception) {
            // best effort only
        }
    }

    private fun record(application: Application, thread: Thread, error: Throwable) {
        val now = System.currentTimeMillis()
        val zone = TimeZone.getDefault()
        val report = CrashReport.build(
            timeMs = now,
            zone = zone,
            details = details(application),
            threadName = thread.name,
            error = error,
            recentLog = LogcatSnapshot.capture(LOG_LINES, LOG_TIMEOUT_MS)
        )
        val name = CrashReport.fileName(now, zone)
        val kept = keepPrivately(application, name, report)
        if (DownloadsWriter.saveText(application, name, report)) kept?.delete()
    }

    private fun keepPrivately(application: Application, name: String, report: String): File? = try {
        val dir = File(application.filesDir, DIR_NAME)
        dir.mkdirs()
        val file = File(dir, name)
        file.writeText(report, Charsets.UTF_8)
        file
    } catch (e: Exception) {
        null
    }

    private fun pendingFiles(application: Application): List<File> {
        val dir = File(application.filesDir, DIR_NAME)
        return dir.listFiles { f -> f.isFile && f.name.endsWith(".txt") }.orEmpty().toList()
    }

    private fun details(application: Application): List<Pair<String, String>> = try {
        val info = try {
            application.packageManager.getPackageInfo(application.packageName, 0)
        } catch (e: Exception) {
            null
        }
        val version = if (info == null) "unknown" else info.versionName + " (code " + info.longVersionCode + ")"
        val runtime = Runtime.getRuntime()
        val usedMb = (runtime.totalMemory() - runtime.freeMemory()) shr 20
        val maxMb = runtime.maxMemory() shr 20
        val uptimeMs = SystemClock.elapsedRealtime() - android.os.Process.getStartElapsedRealtime()
        listOf(
            "App" to application.packageName + " " + version,
            "Android" to Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + "), security patch " + Build.VERSION.SECURITY_PATCH,
            "Device" to Build.MANUFACTURER + " " + Build.MODEL + " (" + Build.DEVICE + ")",
            "ABI" to Build.SUPPORTED_ABIS.joinToString(),
            "Build" to Build.FINGERPRINT,
            "Process" to "pid " + android.os.Process.myPid() + ", running for " + uptimeMs + " ms",
            "Heap" to "$usedMb MB used of $maxMb MB",
            "Language" to Locale.getDefault().toLanguageTag()
        )
    } catch (e: Exception) {
        emptyList()
    }
}

/** The last lines of this app's own log (Android only lets an app read its own entries). */
private object LogcatSnapshot {

    /** The log text, or a one-line reason in parentheses when nothing could be read. The report shows either as is. */
    fun capture(lines: Int, timeoutMs: Long): String {
        var process: Process? = null
        try {
            val started = ProcessBuilder("logcat", "-d", "-t", lines.toString(), "-v", "threadtime")
                .redirectErrorStream(true)
                .start()
            process = started
            val text = StringBuffer()
            val reader = Thread {
                try {
                    started.inputStream.bufferedReader().forEachLine { text.append(it).append('\n') }
                } catch (e: IOException) {
                    // the process ended or was stopped
                }
            }
            reader.isDaemon = true // must never keep a dying process alive
            reader.start()
            reader.join(timeoutMs)
            val log = text.toString()
            return if (log.isNotBlank()) log else "(logcat gave no output; " + exitState(started) + ")"
        } catch (e: Exception) {
            return "(logcat could not be started: " + e.javaClass.simpleName + ": " + e.message + ")"
        } finally {
            process?.destroy()
        }
    }

    private fun exitState(process: Process): String =
        if (process.waitFor(EXIT_GRACE_MS, TimeUnit.MILLISECONDS)) {
            "exit code " + process.exitValue()
        } else {
            "still running after the time limit"
        }

    private const val EXIT_GRACE_MS = 200L
}
