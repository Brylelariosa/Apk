package dev.netcontrol.app

import android.app.Application
import android.content.Context
import dev.netcontrol.app.diag.CrashLogger

class NetControlApp : Application() {

    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(base)
        // First thing in the process: a crash anywhere after this point, including while the rest of the
        // app starts, is saved as a text file in the Download folder.
        CrashLogger.install(this)
    }

    override fun onCreate() {
        super.onCreate()
        CrashLogger.exportPending()
        Graph.init(this)
    }
}
