package dev.netcontrol.app.diag

import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Text layout of a crash report. Deliberately free of Android classes: everything that needs the system
 * (device details, log lines, file storage) is collected elsewhere and handed in.
 */
internal object CrashReport {
    const val MAX_TRACE_CHARS = 200_000
    const val MAX_LOG_CHARS = 150_000

    /** Name the report is saved under, for example `NetControl-crash-20261015-110530.txt`. */
    fun fileName(timeMs: Long, zone: TimeZone): String =
        "NetControl-crash-" + format("yyyyMMdd-HHmmss", timeMs, zone) + ".txt"

    fun build(
        timeMs: Long,
        zone: TimeZone,
        details: List<Pair<String, String>>,
        threadName: String,
        error: Throwable,
        recentLog: String?
    ): String {
        val sb = StringBuilder()
        sb.append("NetControl crash report\n")
        sb.append("Time: ").append(format("yyyy-MM-dd HH:mm:ss Z", timeMs, zone)).append('\n')
        for ((label, value) in details) sb.append(label).append(": ").append(value).append('\n')
        sb.append("Thread: ").append(threadName).append("\n\n")
        sb.append("[Exception]\n")
        sb.append(clipHead(stackTrace(error), MAX_TRACE_CHARS)).append('\n')
        sb.append("[Recent log lines of this app, newest last]\n")
        if (recentLog.isNullOrBlank()) {
            sb.append("(not available)\n")
        } else {
            sb.append(clipTail(recentLog, MAX_LOG_CHARS))
        }
        sb.append("\n[End of report]\n")
        return sb.toString()
    }

    /** The full stack trace including every "Caused by" section. */
    fun stackTrace(error: Throwable): String = try {
        val writer = StringWriter()
        PrintWriter(writer).use { error.printStackTrace(it) }
        writer.toString()
    } catch (failure: Throwable) {
        error.javaClass.name + " (stack trace unavailable: " + failure.javaClass.name + ")"
    }

    /** Keeps the start of [text]; the first lines of a stack trace name the actual problem. */
    fun clipHead(text: String, max: Int): String =
        if (text.length <= max) text else text.substring(0, max) + "\n[... cut, " + (text.length - max) + " more characters]"

    /** Keeps the end of [text]; the newest log lines are the ones that matter. */
    fun clipTail(text: String, max: Int): String {
        val body = if (text.length <= max) text else "[... earlier lines cut]\n" + text.substring(text.length - max)
        return if (body.endsWith("\n")) body else body + "\n"
    }

    private fun format(pattern: String, timeMs: Long, zone: TimeZone): String {
        val formatter = SimpleDateFormat(pattern, Locale.US)
        formatter.timeZone = zone
        return formatter.format(Date(timeMs))
    }
}
