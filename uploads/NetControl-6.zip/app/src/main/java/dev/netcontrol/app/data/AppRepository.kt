package dev.netcontrol.app.data

import android.Manifest
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.util.LruCache
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import dev.netcontrol.app.Graph
import dev.netcontrol.app.R
import dev.netcontrol.engine.CoreUids
import dev.netcontrol.engine.Policy
import dev.netcontrol.engine.RoutingTable
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext

data class AppEntry(
    val packageName: String,
    val label: String,
    val uid: Int,
    /** A system app the user did not update (for example Download Manager). */
    val isSystem: Boolean,
    /** One entry that stands for a whole core Android UID (below 10000), for example "Android System". */
    val isCore: Boolean = false,
    /** Names of the other packages that run under the same UID. A rule applies to all of them. */
    val sharedWith: List<String> = emptyList()
)

class AppRepository(private val ctx: Context) {

    /** UID of an installed package, or null when it is not installed. */
    fun uidOf(pkg: String): Int? = try {
        ctx.packageManager.getApplicationInfo(pkg, 0).uid
    } catch (e: PackageManager.NameNotFoundException) {
        null
    }

    /**
     * Installed apps that can use the network (declare INTERNET), system apps included.
     *
     * Packages with an app UID (10000 and above) get one entry each. Core system UIDs (below 10000: Android
     * System, phone services, Bluetooth, NFC, ...) are shared by many system packages, so every such UID gets a
     * single entry, flagged [AppEntry.isCore]. A rule on a core entry applies to the whole UID.
     */
    suspend fun load(): List<AppEntry> = withContext(Dispatchers.IO) {
        val pm = ctx.packageManager
        @Suppress("DEPRECATION")
        val packages = pm.getInstalledPackages(PackageManager.GET_PERMISSIONS)

        // Packages that share a UID share one network identity, so group them first.
        val byUid = HashMap<Int, MutableList<PackageInfo>>()
        for (pi in packages) {
            val ai = pi.applicationInfo ?: continue
            byUid.getOrPut(ai.uid) { ArrayList() }.add(pi)
        }

        val labels = HashMap<String, String>()
        val out = ArrayList<AppEntry>(packages.size)
        for ((uid, group) in byUid) {
            if (RoutingTable.isCoreUid(uid)) {
                val core = coreEntry(pm, labels, uid, group)
                if (core != null) out.add(core)
            } else {
                for (pi in group) {
                    if (pi.packageName == ctx.packageName || !requestsInternet(pi)) continue
                    val entry = appEntry(pm, labels, pi, group)
                    if (entry != null) out.add(entry)
                }
            }
        }
        out.sortBy { it.label.lowercase() }
        out
    }

    private fun requestsInternet(pi: PackageInfo): Boolean =
        pi.requestedPermissions?.contains(Manifest.permission.INTERNET) == true

    private fun appEntry(
        pm: PackageManager,
        labels: MutableMap<String, String>,
        pi: PackageInfo,
        group: List<PackageInfo>
    ): AppEntry? {
        val ai = pi.applicationInfo ?: return null
        val updatedSystem = (ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
        val system = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0 && !updatedSystem
        val others = group.filter { it.packageName != pi.packageName }
        return AppEntry(pi.packageName, labelOf(pm, labels, pi), ai.uid, system, false, labelsOf(pm, labels, others))
    }

    private fun coreEntry(
        pm: PackageManager,
        labels: MutableMap<String, String>,
        uid: Int,
        group: List<PackageInfo>
    ): AppEntry? {
        val byName = group.associateBy { it.packageName }
        val rep = CoreUids.representative(byName.keys) { name -> byName[name]?.let { requestsInternet(it) } == true }
            ?: return null
        val repInfo = byName[rep] ?: return null
        val resId = coreLabelRes(uid)
        val label = if (resId != null) ctx.getString(resId) else labelOf(pm, labels, repInfo)
        val others = group.filter { it.packageName != rep }
        return AppEntry(rep, label, uid, true, true, labelsOf(pm, labels, others))
    }

    private fun coreLabelRes(uid: Int): Int? = when (uid) {
        CoreUids.SYSTEM -> R.string.core_uid_system
        CoreUids.PHONE -> R.string.core_uid_phone
        CoreUids.BLUETOOTH -> R.string.core_uid_bluetooth
        CoreUids.NFC -> R.string.core_uid_nfc
        CoreUids.SECURE_ELEMENT -> R.string.core_uid_se
        CoreUids.NETWORK_STACK -> R.string.core_uid_networkstack
        CoreUids.SHELL -> R.string.core_uid_shell
        else -> null
    }

    /** Loading a label is the slow part of a scan, so each package is asked only once. */
    private fun labelOf(pm: PackageManager, cache: MutableMap<String, String>, pi: PackageInfo): String =
        cache.getOrPut(pi.packageName) {
            val ai = pi.applicationInfo
            if (ai == null) pi.packageName else pm.getApplicationLabel(ai).toString()
        }

    private fun labelsOf(pm: PackageManager, cache: MutableMap<String, String>, list: List<PackageInfo>): List<String> =
        list.map { labelOf(pm, cache, it) }.distinct().sortedBy { it.lowercase() }

    /**
     * Applies the "default policy for new apps" setting to packages that were not present on the
     * previous scan. The first scan only records a baseline and never changes any rule. System apps and core
     * system services never receive the default policy: it is meant for apps the user installs, and blocking
     * a system component can break the phone.
     */
    suspend fun applyDefaultPolicyToNew(installed: List<AppEntry>) {
        val names = installed.map { it.packageName }.toSet()
        val known = Graph.settings.knownPackages()
        if (known == null) {
            Graph.settings.setKnownPackages(names)
            return
        }
        val fresh = names - known
        if (fresh.isNotEmpty()) {
            val def = Graph.settings.flow.first().defaultPolicy
            if (def != Policy.AUTOMATIC) {
                val existing = Graph.rules.rules.first()
                val system = installed.filter { it.isSystem }.map { it.packageName }.toSet()
                val changes = HashMap<String, Policy>()
                for (p in fresh) {
                    if (p in system) continue
                    if (!existing.containsKey(p)) changes[p] = def
                }
                if (changes.isNotEmpty()) Graph.rules.setMany(changes)
            }
        }
        if (names != known) Graph.settings.setKnownPackages(names)
    }
}

/** Small in-memory cache of launcher icons rendered at the size they are drawn (never full resolution). */
class IconCache(private val ctx: Context) {
    private val cache = LruCache<String, ImageBitmap>(160)

    suspend fun get(pkg: String, sizePx: Int): ImageBitmap? {
        val hit = cache.get(pkg)
        if (hit != null) return hit
        val bmp: ImageBitmap = withContext(Dispatchers.IO) {
            try {
                ctx.packageManager.getApplicationIcon(pkg)
                    .toBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
                    .asImageBitmap()
            } catch (e: Exception) {
                null
            }
        } ?: return null
        cache.put(pkg, bmp)
        return bmp
    }
}
