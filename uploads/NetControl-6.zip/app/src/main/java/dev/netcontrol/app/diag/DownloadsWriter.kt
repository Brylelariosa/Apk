package dev.netcontrol.app.diag

import android.content.ContentValues
import android.content.Context
import android.os.Environment
import android.provider.MediaStore
import java.io.IOException

/**
 * Saves a text file into the public Download folder. Scoped storage (Android 10 and newer) lets an app create
 * its own files there through the MediaStore without any storage permission, so nothing has to be granted and
 * no PC, root or Shizuku is involved.
 */
internal object DownloadsWriter {

    /** Returns true when the file now exists in Download. Never throws. */
    fun saveText(context: Context, fileName: String, text: String): Boolean {
        try {
            val values = ContentValues()
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
            values.put(MediaStore.MediaColumns.MIME_TYPE, "text/plain")
            values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)

            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return false
            try {
                val stream = resolver.openOutputStream(uri) ?: throw IOException("no output stream")
                stream.use { it.write(text.toByteArray(Charsets.UTF_8)) }
            } catch (e: Exception) {
                // do not leave an empty entry behind
                try {
                    resolver.delete(uri, null, null)
                } catch (ignored: Exception) {
                    // nothing more to do
                }
                return false
            }
            return true
        } catch (e: Exception) {
            return false
        }
    }
}
