package dev.netcontrol.app.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import dev.netcontrol.app.Graph
import dev.netcontrol.app.R
import dev.netcontrol.app.domain.EnforcementLevel
import dev.netcontrol.app.ui.theme.LocalStatusColors
import dev.netcontrol.engine.BlockReason
import dev.netcontrol.engine.Policy

@Composable
fun ScreenHeader(title: String, onBack: (() -> Unit)?, actions: @Composable RowScope.() -> Unit = {}) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 56.dp)
            .padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            IconButton(onClick = onBack) {
                Icon(painterResource(R.drawable.ic_back), stringResource(R.string.action_back))
            }
        } else {
            Spacer(Modifier.width(8.dp))
        }
        Text(
            text = title,
            style = MaterialTheme.typography.titleLarge,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )
        actions()
    }
}

@Composable
fun SectionCard(title: String?, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (title != null) {
                Text(title, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
            }
            content()
        }
    }
}

@Composable
fun InfoRow(label: String, value: String, valueColor: Color = Color.Unspecified) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) {
        Text(
            label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(1f)
        )
        Text(
            value,
            style = MaterialTheme.typography.bodyMedium,
            color = valueColor,
            textAlign = TextAlign.End,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
fun StatusPill(text: String, color: Color) {
    Surface(shape = RoundedCornerShape(50), color = color.copy(alpha = 0.16f)) {
        Text(
            text,
            color = color,
            style = MaterialTheme.typography.labelLarge,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
        )
    }
}

/** Small label shown next to an app name ("System", "Core system"). */
@Composable
fun TagPill(text: String, color: Color) {
    Surface(shape = RoundedCornerShape(50), color = color.copy(alpha = 0.16f)) {
        Text(
            text,
            color = color,
            style = MaterialTheme.typography.labelSmall,
            maxLines = 1,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 1.dp)
        )
    }
}

/** "A, B, C and 4 more": a short text for a long list of component names. */
@Composable
fun sharedSummary(names: List<String>, max: Int = 6): String {
    if (names.size <= max) return names.joinToString(", ")
    return names.take(max).joinToString(", ") + " " + stringResource(R.string.shared_more, names.size - max)
}

@Composable
fun AppIcon(pkg: String, size: Dp, modifier: Modifier = Modifier) {
    val px = with(LocalDensity.current) { size.roundToPx() }
    val bmp by produceState<ImageBitmap?>(initialValue = null, pkg, px) {
        value = Graph.icons.get(pkg, px)
    }
    val b = bmp
    if (b != null) {
        Image(bitmap = b, contentDescription = null, modifier = modifier.size(size))
    } else {
        Spacer(modifier.size(size))
    }
}

// ---------------------------------------------------------------------- policy helpers

fun policyIconRes(p: Policy): Int = when (p) {
    Policy.AUTOMATIC -> R.drawable.ic_auto
    Policy.WIFI_ONLY -> R.drawable.ic_wifi
    Policy.MOBILE_ONLY -> R.drawable.ic_cellular
    Policy.BLOCK -> R.drawable.ic_block
}

@Composable
fun policyLabel(p: Policy): String = stringResource(
    when (p) {
        Policy.AUTOMATIC -> R.string.policy_auto
        Policy.WIFI_ONLY -> R.string.policy_wifi
        Policy.MOBILE_ONLY -> R.string.policy_mobile
        Policy.BLOCK -> R.string.policy_block
    }
)

@Composable
fun policyShortLabel(p: Policy): String = stringResource(
    when (p) {
        Policy.AUTOMATIC -> R.string.policy_auto_short
        Policy.WIFI_ONLY -> R.string.policy_wifi_short
        Policy.MOBILE_ONLY -> R.string.policy_mobile_short
        Policy.BLOCK -> R.string.policy_block_short
    }
)

@Composable
fun policyDescription(p: Policy): String = stringResource(
    when (p) {
        Policy.AUTOMATIC -> R.string.policy_auto_desc
        Policy.WIFI_ONLY -> R.string.policy_wifi_desc
        Policy.MOBILE_ONLY -> R.string.policy_mobile_desc
        Policy.BLOCK -> R.string.policy_block_desc
    }
)

@Composable
fun enforcementLabel(level: EnforcementLevel, policy: Policy): String = stringResource(
    when (level) {
        EnforcementLevel.NO_RULE -> R.string.enf_no_rule
        EnforcementLevel.SERVICE_STOPPED -> R.string.enf_stopped
        EnforcementLevel.APPLYING -> R.string.enf_applying
        EnforcementLevel.MISSING -> R.string.enf_missing
        EnforcementLevel.NETWORK_UNAVAILABLE ->
            if (policy == Policy.MOBILE_ONLY) R.string.enf_cell_down else R.string.enf_wifi_down
        EnforcementLevel.NOT_VERIFIED -> R.string.enf_not_verified
        EnforcementLevel.VERIFIED -> R.string.enf_verified
        EnforcementLevel.FAILURE -> R.string.enf_failure
    }
)

@Composable
fun enforcementExplanation(level: EnforcementLevel, policy: Policy): String = stringResource(
    when (level) {
        EnforcementLevel.NO_RULE -> R.string.enf_expl_no_rule
        EnforcementLevel.SERVICE_STOPPED -> R.string.enf_expl_stopped
        EnforcementLevel.APPLYING -> R.string.enf_expl_applying
        EnforcementLevel.MISSING -> R.string.enf_expl_missing
        EnforcementLevel.NETWORK_UNAVAILABLE ->
            if (policy == Policy.MOBILE_ONLY) R.string.enf_expl_cell_down else R.string.enf_expl_wifi_down
        EnforcementLevel.NOT_VERIFIED -> R.string.enf_expl_not_verified
        EnforcementLevel.VERIFIED ->
            if (policy == Policy.BLOCK) R.string.enf_expl_verified_block else R.string.enf_expl_verified
        EnforcementLevel.FAILURE -> R.string.enf_expl_failure
    }
)

@Composable
fun enforcementColor(level: EnforcementLevel): Color {
    val sc = LocalStatusColors.current
    return when (level) {
        EnforcementLevel.NO_RULE -> MaterialTheme.colorScheme.onSurfaceVariant
        EnforcementLevel.VERIFIED, EnforcementLevel.NETWORK_UNAVAILABLE -> sc.ok
        EnforcementLevel.APPLYING, EnforcementLevel.NOT_VERIFIED -> sc.warn
        EnforcementLevel.SERVICE_STOPPED, EnforcementLevel.MISSING, EnforcementLevel.FAILURE -> sc.bad
    }
}

@Composable
fun blockReasonLabel(r: BlockReason): String = stringResource(
    when (r) {
        BlockReason.POLICY_BLOCK -> R.string.block_policy
        BlockReason.WIFI_UNAVAILABLE -> R.string.block_wifi
        BlockReason.CELLULAR_UNAVAILABLE -> R.string.block_cell
        BlockReason.UNATTRIBUTED -> R.string.block_unattributed
        BlockReason.DNS_UNAVAILABLE -> R.string.block_dns
        BlockReason.DNS_PORT_UNSUPPORTED -> R.string.block_dns_port
        BlockReason.ROUTE_VIOLATION -> R.string.block_violation
        BlockReason.SOCKET_FAILURE -> R.string.block_socket
        BlockReason.TABLE_FULL -> R.string.block_table
    }
)

@Composable
fun yesNo(v: Boolean): String = stringResource(if (v) R.string.yes else R.string.no)

/** Compact mode selector used in lists: shows the current mode and opens a menu with all four. */
@Composable
fun PolicyMenu(current: Policy, onSelect: (Policy) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { open = true }, contentPadding = PaddingValues(horizontal = 10.dp)) {
            Icon(painterResource(policyIconRes(current)), null, Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text(policyShortLabel(current), style = MaterialTheme.typography.labelLarge)
            Icon(painterResource(R.drawable.ic_expand), null, Modifier.size(18.dp))
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            for (p in Policy.values()) {
                DropdownMenuItem(
                    text = { Text(policyLabel(p)) },
                    leadingIcon = { Icon(painterResource(policyIconRes(p)), null, Modifier.size(20.dp)) },
                    onClick = {
                        open = false
                        onSelect(p)
                    }
                )
            }
        }
    }
}
