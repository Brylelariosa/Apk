package dev.netcontrol.app.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dev.netcontrol.engine.Policy
import dev.netcontrol.engine.RuleCodec
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.netControlStore: DataStore<Preferences> by preferencesDataStore(name = "netcontrol")

enum class ThemeMode { DARK, LIGHT, SYSTEM }

data class Settings(
    val protectionEnabled: Boolean = false,
    val defaultPolicy: Policy = Policy.AUTOMATIC,
    val persistentNotification: Boolean = true,
    val ipv6: Boolean = true,
    val theme: ThemeMode = ThemeMode.DARK,
    val vpnExplained: Boolean = false
)

/** Persistent per-app rules ("package=W"), stored locally with DataStore. */
class RuleStore(private val ctx: Context) {
    private val key = stringSetPreferencesKey("rules")

    val rules: Flow<Map<String, Policy>> = ctx.netControlStore.data
        .map { RuleCodec.decode(it[key] ?: emptySet()) }
        .distinctUntilChanged()

    suspend fun set(pkg: String, policy: Policy) {
        setMany(mapOf(pkg to policy))
    }

    suspend fun setMany(changes: Map<String, Policy>) {
        ctx.netControlStore.edit { prefs ->
            val m = LinkedHashMap<String, Policy>(RuleCodec.decode(prefs[key] ?: emptySet()))
            for ((pkg, p) in changes) {
                if (p == Policy.AUTOMATIC) {
                    m.remove(pkg)
                } else {
                    m[pkg] = p
                }
            }
            prefs[key] = RuleCodec.encode(m)
        }
    }

    suspend fun clear() {
        ctx.netControlStore.edit { prefs ->
            prefs.remove(key)
        }
    }
}

class SettingsStore(private val ctx: Context) {
    private val kProtect = booleanPreferencesKey("protection_enabled")
    private val kDefault = stringPreferencesKey("default_policy")
    private val kNotif = booleanPreferencesKey("persistent_notification")
    private val kIpv6 = booleanPreferencesKey("ipv6")
    private val kTheme = stringPreferencesKey("theme")
    private val kExplained = booleanPreferencesKey("vpn_explained")
    private val kKnown = stringSetPreferencesKey("known_packages")
    private val kScanVersion = intPreferencesKey("known_scan_version")

    val flow: Flow<Settings> = ctx.netControlStore.data.map { p ->
        val defaultCode = (p[kDefault] ?: "A").firstOrNull()
        val theme = try {
            ThemeMode.valueOf(p[kTheme] ?: "DARK")
        } catch (e: IllegalArgumentException) {
            ThemeMode.DARK
        }
        Settings(
            protectionEnabled = p[kProtect] ?: false,
            defaultPolicy = (if (defaultCode == null) null else Policy.fromCode(defaultCode)) ?: Policy.AUTOMATIC,
            persistentNotification = p[kNotif] ?: true,
            ipv6 = p[kIpv6] ?: true,
            theme = theme,
            vpnExplained = p[kExplained] ?: false
        )
    }.distinctUntilChanged()

    suspend fun setProtectionEnabled(v: Boolean) {
        ctx.netControlStore.edit { it[kProtect] = v }
    }

    suspend fun setDefaultPolicy(p: Policy) {
        ctx.netControlStore.edit { it[kDefault] = p.code.toString() }
    }

    suspend fun setPersistentNotification(v: Boolean) {
        ctx.netControlStore.edit { it[kNotif] = v }
    }

    suspend fun setIpv6(v: Boolean) {
        ctx.netControlStore.edit { it[kIpv6] = v }
    }

    suspend fun setTheme(t: ThemeMode) {
        ctx.netControlStore.edit { it[kTheme] = t.name }
    }

    suspend fun setVpnExplained(v: Boolean) {
        ctx.netControlStore.edit { it[kExplained] = v }
    }

    /**
     * Package names seen on the previous scan, or null before the first scan. Also null when the saved set
     * comes from an older scan that listed fewer packages (see [SCAN_VERSION]): the caller then records a
     * new baseline instead of treating every newly listed package as an install.
     */
    suspend fun knownPackages(): Set<String>? {
        val prefs = ctx.netControlStore.data.first()
        if ((prefs[kScanVersion] ?: 1) != SCAN_VERSION) return null
        return prefs[kKnown]
    }

    suspend fun setKnownPackages(names: Set<String>) {
        ctx.netControlStore.edit {
            it[kKnown] = names
            it[kScanVersion] = SCAN_VERSION
        }
    }

    private companion object {
        /** Version 2: the scan also lists system apps and core system UIDs. */
        const val SCAN_VERSION = 2
    }
}
