package dev.netcontrol.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.netcontrol.app.R
import dev.netcontrol.app.data.AppEntry
import dev.netcontrol.app.domain.EnforcementCalculator
import dev.netcontrol.app.domain.EnforcementLevel
import dev.netcontrol.app.ui.MainViewModel
import dev.netcontrol.app.ui.components.AppIcon
import dev.netcontrol.app.ui.components.PolicyMenu
import dev.netcontrol.app.ui.components.ScreenHeader
import dev.netcontrol.app.ui.components.TagPill
import dev.netcontrol.app.ui.components.enforcementColor
import dev.netcontrol.app.ui.components.enforcementLabel
import dev.netcontrol.app.ui.theme.LocalStatusColors
import dev.netcontrol.engine.Policy

enum class AppFilter(val label: Int) {
    ALL(R.string.apps_filter_all),
    WIFI_ONLY(R.string.apps_filter_wifi),
    MOBILE_ONLY(R.string.apps_filter_mobile),
    AUTOMATIC(R.string.apps_filter_auto),
    BLOCK(R.string.apps_filter_block),
    CUSTOM(R.string.apps_filter_custom),
    NOT_ENFORCED(R.string.apps_filter_not_enforced)
}

private class Row3(val app: AppEntry, val policy: Policy, val level: EnforcementLevel)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppsScreen(vm: MainViewModel, onOpen: (String) -> Unit) {
    val apps by vm.apps.collectAsStateWithLifecycle()
    val loading by vm.appsLoading.collectAsStateWithLifecycle()
    val rules by vm.rules.collectAsStateWithLifecycle()
    val status by vm.status.collectAsStateWithLifecycle()
    val net by vm.net.collectAsStateWithLifecycle()
    val stats by vm.engineStats.collectAsStateWithLifecycle()

    var query by rememberSaveable { mutableStateOf("") }
    var filter by rememberSaveable { mutableStateOf(AppFilter.ALL) }
    // System apps (Download Manager, ...) and core system services are listed by default.
    var showUser by rememberSaveable { mutableStateOf(true) }
    var showSystem by rememberSaveable { mutableStateOf(true) }

    val rows = remember(apps, rules, status, net, stats, query, filter, showUser, showSystem) {
        val q = query.trim().lowercase()
        val out = ArrayList<Row3>()
        for (a in apps) {
            if (a.isSystem) {
                // A hidden system app stays visible when it has a rule, so configured entries never vanish.
                if (!showSystem && !rules.containsKey(a.packageName)) continue
            } else if (!showUser) {
                continue
            }
            if (q.isNotEmpty() && !a.label.lowercase().contains(q) && !a.packageName.lowercase().contains(q)) continue
            val policy = rules[a.packageName] ?: Policy.AUTOMATIC
            val level = EnforcementCalculator.levelFor(a.packageName, policy, status, net, stats?.perUid?.get(a.uid))
            val keep = when (filter) {
                AppFilter.ALL -> true
                AppFilter.WIFI_ONLY -> policy == Policy.WIFI_ONLY
                AppFilter.MOBILE_ONLY -> policy == Policy.MOBILE_ONLY
                AppFilter.AUTOMATIC -> policy == Policy.AUTOMATIC
                AppFilter.BLOCK -> policy == Policy.BLOCK
                AppFilter.CUSTOM -> policy != Policy.AUTOMATIC
                AppFilter.NOT_ENFORCED -> policy != Policy.AUTOMATIC && !level.isEnforcing
            }
            if (keep) out.add(Row3(a, policy, level))
        }
        out
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(stringResource(R.string.nav_apps), null)
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            singleLine = true,
            placeholder = { Text(stringResource(R.string.apps_search_hint)) },
            leadingIcon = { Icon(painterResource(R.drawable.ic_search), null, Modifier.size(20.dp)) },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
        )
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = showUser,
                onClick = { showUser = !showUser },
                label = { Text(stringResource(R.string.apps_show_user)) }
            )
            FilterChip(
                selected = showSystem,
                onClick = { showSystem = !showSystem },
                label = { Text(stringResource(R.string.apps_show_system)) }
            )
            Spacer(Modifier.width(4.dp))
            for (f in AppFilter.values()) {
                FilterChip(
                    selected = filter == f,
                    onClick = { filter = f },
                    label = { Text(stringResource(f.label)) }
                )
            }
        }
        Text(
            stringResource(R.string.apps_count, rows.size),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp)
        )
        if (loading && apps.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator()
                    Spacer(Modifier.size(12.dp))
                    Text(stringResource(R.string.apps_loading))
                }
            }
        } else if (rows.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.TopCenter) {
                Text(
                    stringResource(R.string.apps_empty),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                items(rows, key = { it.app.packageName }) { r ->
                    AppRow(r, onOpen = { onOpen(r.app.packageName) }, onSelect = { p -> vm.requestPolicy(r.app, p) })
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                }
            }
        }
    }
}

@Composable
private fun AppRow(r: Row3, onOpen: () -> Unit, onSelect: (Policy) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onOpen).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AppIcon(r.app.packageName, 40.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    r.app.label,
                    style = MaterialTheme.typography.bodyLarge,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )
                if (r.app.isCore) {
                    Spacer(Modifier.width(6.dp))
                    TagPill(stringResource(R.string.tag_core), LocalStatusColors.current.warn)
                } else if (r.app.isSystem) {
                    Spacer(Modifier.width(6.dp))
                    TagPill(stringResource(R.string.tag_system), MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Text(
                enforcementLabel(r.level, r.policy),
                style = MaterialTheme.typography.bodySmall,
                color = enforcementColor(r.level),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Spacer(Modifier.width(8.dp))
        PolicyMenu(r.policy, onSelect)
    }
}
