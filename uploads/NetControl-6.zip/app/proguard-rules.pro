# R8 full mode is the AGP default. Manifest components (activity, VpnService, receiver) are kept
# automatically by the rules AGP generates from AndroidManifest.xml.

# Keep real class and method names and line numbers in release builds. A crash report is written on the phone
# (Download/NetControl-crash-*.txt) and there is no mapping file there to translate an obfuscated stack trace,
# so a readable trace is worth more than the few KB that obfuscation saves. Delete these two lines to
# obfuscate again.
-dontobfuscate
-keepattributes SourceFile,LineNumberTable

# Lifecycle 2.8 (lifecycle-runtime-compose) finds the lifecycle owner of a Compose screen by looking up a getter
# of the older Compose UI 1.6 library by its name (reflection). R8 cannot see that, removes the getter from the
# release build, and the first collectAsStateWithLifecycle() call then ends the app on start with
# "IllegalStateException: CompositionLocal LocalLifecycleOwner not present". This is the same rule newer Lifecycle
# releases ship themselves (Google issue 346808608). It can be deleted after moving to Compose UI 1.7 or newer.
-keep public class androidx.compose.ui.platform.AndroidCompositionLocals_androidKt {
    public static *** getLocalLifecycleOwner();
}

# Strip verbose/debug logging from release builds.
-assumenosideeffects class android.util.Log {
    public static int v(...);
    public static int d(...);
}
