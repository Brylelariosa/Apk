package dev.netcontrol.engine

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class CoreUidsTest {

    private fun requesting(vararg names: String): (String) -> Boolean {
        val set = names.toSet()
        return { name -> set.contains(name) }
    }

    @Test
    fun frameworkPackageStandsForTheSystemUid() {
        val packages = listOf("com.android.settings", "android", "com.android.keychain")
        assertEquals("android", CoreUids.representative(packages, requesting("com.android.settings")))
    }

    @Test
    fun otherwiseTheFirstPackageThatRequestsInternetWins() {
        val packages = listOf("com.android.stk", "com.android.phone", "com.android.mms.service")
        val chosen = CoreUids.representative(packages, requesting("com.android.phone", "com.android.mms.service"))
        assertEquals("com.android.mms.service", chosen)
    }

    @Test
    fun theChoiceDoesNotDependOnTheOrderOfThePackages() {
        val names = arrayOf("com.android.nfc", "com.android.nfc.helper")
        val a = CoreUids.representative(names.toList(), requesting(*names))
        val b = CoreUids.representative(names.reversed(), requesting(*names))
        assertEquals("com.android.nfc", a)
        assertEquals(a, b)
    }

    @Test
    fun aUidWithoutNetworkAccessIsNotListed() {
        assertNull(CoreUids.representative(listOf("android", "com.android.keychain"), requesting()))
    }
}
