package dev.netcontrol.engine

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CapturePlannerTest {

    private val own = "dev.netcontrol.app"

    private val uids = mapOf(
        "android" to 1000,
        "com.android.phone" to 1001,
        "com.example.a" to 10001,
        "com.example.b" to 10002,
        "com.shared.one" to 10050,
        "com.shared.two" to 10050
    )

    private fun plan(rules: Map<String, Policy>): CapturePlan =
        CapturePlanner.plan(rules, own) { pkg -> uids[pkg] }

    @Test
    fun coreSystemUidsAreCaptured() {
        val p = plan(mapOf("com.android.phone" to Policy.BLOCK, "android" to Policy.WIFI_ONLY))
        assertEquals(listOf("android", "com.android.phone"), p.packages)
        assertEquals(mapOf(1000 to Policy.WIFI_ONLY, 1001 to Policy.BLOCK), p.uidPolicies)
        assertTrue(p.missing.isEmpty())
    }

    @Test
    fun automaticRulesAndTheOwnPackageAreIgnored() {
        val p = plan(
            mapOf(
                "com.example.a" to Policy.AUTOMATIC,
                own to Policy.BLOCK,
                "com.example.b" to Policy.MOBILE_ONLY
            )
        )
        assertEquals(listOf("com.example.b"), p.packages)
        assertEquals(mapOf(10002 to Policy.MOBILE_ONLY), p.uidPolicies)
        assertTrue(p.missing.isEmpty())
    }

    @Test
    fun notInstalledPackagesAreReportedAsMissing() {
        val p = plan(mapOf("com.gone" to Policy.BLOCK, "com.example.a" to Policy.WIFI_ONLY))
        assertEquals(setOf("com.gone"), p.missing)
        assertEquals(listOf("com.example.a"), p.packages)
        assertEquals(mapOf(10001 to Policy.WIFI_ONLY), p.uidPolicies)
    }

    @Test
    fun blockWinsInASharedUidWhateverTheOrder() {
        val a = plan(linkedMapOf("com.shared.one" to Policy.WIFI_ONLY, "com.shared.two" to Policy.BLOCK))
        val b = plan(linkedMapOf("com.shared.two" to Policy.BLOCK, "com.shared.one" to Policy.WIFI_ONLY))
        assertEquals(mapOf(10050 to Policy.BLOCK), a.uidPolicies)
        assertEquals(mapOf(10050 to Policy.BLOCK), b.uidPolicies)
        assertEquals(listOf("com.shared.one", "com.shared.two"), a.packages)
    }

    @Test
    fun sharedUidTieGoesToTheFirstPackageByName() {
        val a = plan(linkedMapOf("com.shared.two" to Policy.WIFI_ONLY, "com.shared.one" to Policy.MOBILE_ONLY))
        val b = plan(linkedMapOf("com.shared.one" to Policy.MOBILE_ONLY, "com.shared.two" to Policy.WIFI_ONLY))
        assertEquals(Policy.MOBILE_ONLY, a.uidPolicies[10050])
        assertEquals(Policy.MOBILE_ONLY, b.uidPolicies[10050])
    }

    @Test
    fun noRulesGiveAnEmptyPlan() {
        val p = plan(emptyMap())
        assertTrue(p.packages.isEmpty())
        assertTrue(p.uidPolicies.isEmpty())
        assertTrue(p.missing.isEmpty())
        assertTrue(CapturePlan.EMPTY.packages.isEmpty())
    }
}
