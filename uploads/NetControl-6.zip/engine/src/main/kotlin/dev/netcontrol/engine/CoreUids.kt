package dev.netcontrol.engine

/**
 * The UIDs below [RoutingTable.FIRST_APP_UID] belong to the Android system itself. Many system
 * packages run under the same one (for example everything that uses the shared "system" UID), so the
 * app list shows one entry per core UID instead of dozens of packages that would all mean the same thing.
 */
object CoreUids {
    const val SYSTEM = 1000
    const val PHONE = 1001
    const val BLUETOOTH = 1002
    const val NFC = 1027
    const val SECURE_ELEMENT = 1068
    const val NETWORK_STACK = 1073
    const val SHELL = 2000

    /** The framework package. It runs under [SYSTEM] and is the natural name for that UID. */
    const val SYSTEM_PACKAGE = "android"

    /**
     * Chooses the package that stands for a core UID: the rule is stored under its name and the app list
     * shows it. Returns null when no package of the UID can use the network, so the UID is not listed.
     *
     * [requestsInternet] tells whether a package declares the INTERNET permission. The choice is
     * deterministic: the framework package if it belongs to the UID, else the first package by name that
     * requests INTERNET.
     */
    fun representative(packages: Collection<String>, requestsInternet: (String) -> Boolean): String? {
        if (packages.none(requestsInternet)) return null
        val sorted = packages.sorted()
        return sorted.firstOrNull { it == SYSTEM_PACKAGE } ?: sorted.firstOrNull(requestsInternet)
    }
}
