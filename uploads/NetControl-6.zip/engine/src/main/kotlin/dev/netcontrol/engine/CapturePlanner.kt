package dev.netcontrol.engine

/**
 * What the VPN has to capture for a set of saved rules.
 *
 * [packages] are the package names handed to the tunnel (sorted), [uidPolicies] is the effective policy of
 * every captured UID and [missing] lists the rules whose package is not installed.
 */
class CapturePlan(
    val packages: List<String>,
    val uidPolicies: Map<Int, Policy>,
    val missing: Set<String>
) {
    companion object {
        val EMPTY = CapturePlan(emptyList(), emptyMap(), emptySet())
    }
}

/**
 * Pure logic (no Android classes) that decides which packages enter the tunnel.
 *
 * Every installed package with a non-automatic rule is captured, system apps and core system UIDs
 * included. Several packages can run under one UID and a UID is captured as a whole, so the UID gets one
 * policy: Block beats every other mode, otherwise the package that sorts first wins. The result therefore
 * never depends on the order in which the rules were stored.
 */
object CapturePlanner {

    /**
     * [uidOf] returns the UID of an installed package, or null when the package is not installed.
     * [ownPackage] is never captured: NetControl's own sockets must stay outside the tunnel.
     */
    fun plan(rules: Map<String, Policy>, ownPackage: String, uidOf: (String) -> Int?): CapturePlan {
        val packages = ArrayList<String>()
        val uidPolicies = HashMap<Int, Policy>()
        val missing = HashSet<String>()
        for (pkg in rules.keys.sorted()) {
            val policy = rules.getValue(pkg)
            if (policy == Policy.AUTOMATIC || pkg == ownPackage) continue
            val uid = uidOf(pkg)
            if (uid == null) {
                missing.add(pkg)
                continue
            }
            packages.add(pkg)
            val previous = uidPolicies[uid]
            if (previous == null || weight(policy) > weight(previous)) uidPolicies[uid] = policy
        }
        return CapturePlan(packages, uidPolicies, missing)
    }

    private fun weight(p: Policy): Int = when (p) {
        Policy.BLOCK -> 3
        Policy.AUTOMATIC -> 0
        else -> 2
    }
}
