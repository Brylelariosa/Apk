package dev.netcontrol.engine

import java.io.IOException
import java.net.InetAddress
import java.net.InetSocketAddress
import java.nio.channels.DatagramChannel
import java.nio.channels.SocketChannel

/** Immutable IP address (4 or 16 bytes) with value semantics, safe to use as a map key. */
class Addr(private val raw: ByteArray) {
    val size: Int get() = raw.size
    val isV6: Boolean get() = raw.size == 16

    fun byteAt(i: Int): Int = raw[i].toInt() and 0xFF
    fun copyInto(dst: ByteArray, off: Int) {
        System.arraycopy(raw, 0, dst, off, raw.size)
    }

    fun toInet(): InetAddress = InetAddress.getByAddress(raw)

    override fun equals(other: Any?): Boolean = other is Addr && other.raw.contentEquals(raw)
    override fun hashCode(): Int = raw.contentHashCode()
    override fun toString(): String = try {
        toInet().hostAddress ?: "?"
    } catch (e: Exception) {
        "?"
    }

    companion object {
        fun of(inet: InetAddress): Addr = Addr(inet.address)
        fun v4(a: Int, b: Int, c: Int, d: Int): Addr =
            Addr(byteArrayOf(a.toByte(), b.toByte(), c.toByte(), d.toByte()))

        fun from(b: ByteArray, off: Int, len: Int): Addr = Addr(b.copyOfRange(off, off + len))
    }
}

/** Per-application connection policy. */
enum class Policy(val code: Char) {
    AUTOMATIC('A'),
    WIFI_ONLY('W'),
    MOBILE_ONLY('M'),
    BLOCK('B');

    companion object {
        fun fromCode(c: Char): Policy? {
            for (p in values()) {
                if (p.code == c) return p
            }
            return null
        }
    }
}

enum class Transport { WIFI, CELLULAR }

enum class BlockReason {
    POLICY_BLOCK,
    WIFI_UNAVAILABLE,
    CELLULAR_UNAVAILABLE,
    UNATTRIBUTED,
    DNS_UNAVAILABLE,
    DNS_PORT_UNSUPPORTED,
    ROUTE_VIOLATION,
    SOCKET_FAILURE,
    TABLE_FULL
}

/**
 * A physical network that traffic may be forwarded over. [handle] is opaque to the engine
 * (the Android layer stores the android.net.Network there).
 */
class Uplink(
    val id: Long,
    val transport: Transport,
    val dns: List<Addr>,
    val addresses: Set<Addr>,
    val handle: Any?
)

sealed class Decision {
    class Route(val uplink: Uplink) : Decision()
    class Block(val reason: BlockReason) : Decision()
}

/**
 * Immutable snapshot of everything needed to decide how a flow is handled.
 * [rules] maps Android UIDs to a non-automatic policy.
 */
class RoutingTable(
    val rules: Map<Int, Policy>,
    val wifi: Uplink?,
    val cellular: Uplink?,
    val defaultTransport: Transport?
) {
    private val hasWifiRules: Boolean = rules.values.any { it == Policy.WIFI_ONLY }
    private val hasCellRules: Boolean = rules.values.any { it == Policy.MOBILE_ONLY }

    fun isCaptured(uid: Int): Boolean {
        val p = rules[uid]
        return p != null && p != Policy.AUTOMATIC
    }

    /** Decision for a flow owned by [uid] (use -1 when the owner could not be determined). */
    fun decide(uid: Int): Decision {
        val p = rules[uid]
        if (p != null && p != Policy.AUTOMATIC) return forPolicy(p)
        return if (isCoreUid(uid)) systemDecision() else unattributedDecision()
    }

    private fun forPolicy(p: Policy): Decision = when (p) {
        Policy.BLOCK -> Decision.Block(BlockReason.POLICY_BLOCK)
        Policy.WIFI_ONLY ->
            if (wifi != null) Decision.Route(wifi) else Decision.Block(BlockReason.WIFI_UNAVAILABLE)
        Policy.MOBILE_ONLY ->
            if (cellular != null) Decision.Route(cellular) else Decision.Block(BlockReason.CELLULAR_UNAVAILABLE)
        Policy.AUTOMATIC -> unattributedDecision()
    }

    /**
     * Operating-system traffic that Android routes into the tunnel (connectivity checks, resolver
     * traffic owned by system UIDs). It is not a configured app, so it follows the transport the
     * configured apps need; with mixed rules it follows the system default network.
     */
    private fun systemDecision(): Decision {
        if (hasWifiRules && !hasCellRules) return forPolicy(Policy.WIFI_ONLY)
        if (hasCellRules && !hasWifiRules) return forPolicy(Policy.MOBILE_ONLY)
        if (hasWifiRules && hasCellRules) {
            val preferred: Uplink? = when (defaultTransport) {
                Transport.WIFI -> wifi
                Transport.CELLULAR -> cellular
                null -> null
            }
            val up = preferred ?: wifi ?: cellular
            return if (up != null) Decision.Route(up) else Decision.Block(BlockReason.UNATTRIBUTED)
        }
        return Decision.Block(BlockReason.UNATTRIBUTED)
    }

    /** Flow whose owner is unknown or not a configured app: only safe when one transport applies. */
    private fun unattributedDecision(): Decision =
        if (hasWifiRules != hasCellRules) systemDecision() else Decision.Block(BlockReason.UNATTRIBUTED)

    companion object {
        const val FIRST_APP_UID = 10000

        /** True for the UIDs of the Android system itself (system, phone, Bluetooth, NFC, shell, ...). */
        fun isCoreUid(uid: Int): Boolean = uid in 0 until FIRST_APP_UID

        val EMPTY = RoutingTable(emptyMap(), null, null, null)
    }
}

/** Compact text codec for the persisted rule set: "package=W". */
object RuleCodec {
    fun encode(rules: Map<String, Policy>): Set<String> {
        val out = LinkedHashSet<String>()
        for ((pkg, p) in rules) {
            if (p != Policy.AUTOMATIC) out.add(pkg + "=" + p.code)
        }
        return out
    }

    fun decode(lines: Set<String>): Map<String, Policy> {
        val out = LinkedHashMap<String, Policy>()
        for (line in lines) {
            if (line.length < 3 || line[line.length - 2] != '=') continue
            val p = Policy.fromCode(line[line.length - 1]) ?: continue
            if (p == Policy.AUTOMATIC) continue
            out[line.substring(0, line.length - 2)] = p
        }
        return out
    }
}

class EngineConfig(
    val mtu: Int,
    val dns4: Addr,
    val dns6: Addr?,
    val ipv6: Boolean
)

/** Creates sockets that are already bound to the given uplink. */
interface SocketProvider {
    @Throws(IOException::class)
    fun openTcp(uplink: Uplink): SocketChannel

    @Throws(IOException::class)
    fun openUdp(uplink: Uplink): DatagramChannel
}

/** Maps a tunnel flow to the UID that owns it, or -1 when unknown. */
interface UidResolver {
    fun uidOf(protocol: Int, local: InetSocketAddress, remote: InetSocketAddress): Int
}
