package com.mgba.android

import android.Manifest
import android.content.Context
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.text.InputType
import android.text.format.DateFormat
import android.util.Log
import android.util.TypedValue
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs

class MainActivity : AppCompatActivity(), SurfaceHolder.Callback {

    private lateinit var surfaceView: SurfaceView
    private lateinit var loadRomBtn:  Button
    private lateinit var changeRomBtn: TextView
    private lateinit var linkBtn:     TextView
    private lateinit var settingsBtn: TextView
    private lateinit var settingsMenuOverlay: LinearLayout
    private var surfaceHolder: SurfaceHolder? = null
    private var gameThread:    Thread? = null
    @Volatile private var running   = false
    @Volatile private var romLoaded = false
    // ── Save states / battery save ────────────────────────────────────────
    // Identifies the loaded ROM for save-file naming (both the battery .sav
    // and save-state slots below) — see deriveRomBaseName(). Kept separate
    // from the fixed "rom_loaded.gba" cache path every ROM is copied to
    // (see romPicker) so switching ROMs (changeRomBtn) never mixes one
    // game's save data into another's.
    @Volatile private var currentRomBaseName = "rom"
    // ── Triple-buffered framebuffers ────────────────────────────────────────
    // AUDIO FIX (this pass — root cause of crackle/stutter/perceived pitch
    // drift): renderFrame() (lockCanvas/drawBitmap/unlockCanvasAndPost) used
    // to run on the SAME thread as writePcm(), right after it, every frame.
    // Since writePcm() blocking IS the frame pacer now (see startGameLoop()),
    // any slow render — a GC pause, a busy compositor, a software-canvas
    // SurfaceView on a budget device — delayed the *next* audio write too.
    // That starves AudioTrack while the render is stuck, which is heard as a
    // click/pop when playback resumes (buffer underrun), and the resulting
    // irregular frame delivery reads as choppiness or "speed" wobble even
    // though no single sample is mispitched. This was flagged in an earlier
    // pass as a known, deferred risk ("the real fix is decoupling rendering
    // onto its own thread") rather than fixed outright.
    //
    // Fix: three Bitmap buffers, ping-ponged so the game thread never writes
    // into a buffer the renderer might currently be reading:
    //   writeIdx   — owned by the game thread; where nativeRunFrame() writes.
    //   readyIdx   — the most recently completed frame, swapped in under
    //                bufferLock once a frame finishes; -1 = none yet.
    //   displayIdx — owned by the Choreographer render callback; the buffer
    //                it last drew (and may still be drawing via the Surface).
    // The game thread always picks its next writeIdx as whichever of the 3
    // indices is neither readyIdx nor displayIdx — with 3 buffers and only
    // 2 "spoken for" at once, a free one always exists, so the writer never
    // blocks on the renderer and the renderer never tears mid-draw.
    // The renderer runs off Choreographer.postFrameCallback — i.e. paced by
    // the display's own vsync — completely independent of how fast the
    // audio-locked game thread is producing frames.
    private var frameBuffers: Array<Bitmap>? = null
    private var writeIdx = 0
    private val bufferLock = Object()
    private var readyIdx = -1
    private var displayIdx = -1
    @Volatile private var renderLoopActive = false
    private val renderCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!renderLoopActive) return
            val bufs = frameBuffers
            if (bufs != null) {
                var toDraw = -1
                synchronized(bufferLock) {
                    if (readyIdx != -1 && readyIdx != displayIdx) {
                        displayIdx = readyIdx
                    }
                    toDraw = displayIdx
                }
                if (toDraw != -1) renderFrame(bufs[toDraw])
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }
    private fun startRenderLoop() {
        // Choreographer is thread-affine (it binds to whichever thread first
        // asks for an instance) and stopGameLoop() can be called from a
        // background thread (see romPicker's reload path). Flip the volatile
        // flag immediately — doFrame() checks it before ever rescheduling
        // itself, so that alone halts the loop within one vsync tick — and
        // push the actual Choreographer registration through mainHandler so
        // it's always made from the main thread's Choreographer instance.
        renderLoopActive = true
        mainHandler.post {
            if (renderLoopActive) Choreographer.getInstance().postFrameCallback(renderCallback)
        }
    }
    private fun stopRenderLoop() {
        renderLoopActive = false
        mainHandler.post { Choreographer.getInstance().removeFrameCallback(renderCallback) }
    }
    private val gameMatrix  = Matrix()
    private val currentKeys = AtomicInteger(0)
    // BUG FIX ("buttons disappear while dragging"): this used to be a
    // `mutableListOf<ButtonDef>()` that buildControlLayout() mutated in
    // place — buttons.clear() followed by ~11 buttons += calls. That's
    // called on every ACTION_MOVE while dragging a button in the editor
    // (see onEditTouch), i.e. dozens of times a second, ON THE UI THREAD —
    // while the game thread's render loop reads this same list ~60x/sec to
    // draw it (drawControls()). There was no synchronization between the
    // two, so the render thread could paint a frame at the exact moment the
    // list was between clear() and being refilled: every button vanishes
    // for that one frame. Worse under load (exactly when you're actively
    // dragging), which matches "it freezes/disappears when you move it".
    // Fix: build a brand-new list off to the side and swap the *reference*
    // in one atomic write. The render thread then only ever sees a fully
    // "old" or fully "new" list, never a half-built one.
    @Volatile private var buttons: List<ButtonDef> = emptyList()
    private var controlsTop = 0f
    @Volatile private var pickerLive = false
    private lateinit var link: LinkMultiplayer
    private val mainHandler = Handler(Looper.getMainLooper())

    // ── Control layout editor ────────────────────────────────────────────────
    // Per-button position/size/opacity overrides, keyed by stable button id
    // ("dpad","a","b","start","select","l","r","ff", …). Absent from the
    // map == "use the default geometric layout computed in buildControlLayout()".
    // Positions are stored as FRACTIONS of screen width/height (not raw
    // pixels) so a saved layout still makes sense if the app is later run on
    // a different screen size. Persisted as JSON in SharedPreferences,
    // keyed per orientation (see orientationTag()) so a future portrait mode
    // doesn't inherit an unsuitable landscape layout — today the activity is
    // locked to landscape (android:screenOrientation="landscape"), so only
    // the "land" profile is ever active, but the storage format doesn't need
    // to change when portrait support is eventually added.
    private data class LayoutEntry(
        var xFrac: Float,
        var yFrac: Float,
        var scale: Float = 1f,
        var alphaOverride: Int = -1,   // -1 == inherit the global idle-alpha setting
        var locked: Boolean = false
    )
    private data class Geometry(val cx: Float, val cy: Float, val w: Float, val h: Float)

    private val customLayout = mutableMapOf<String, LayoutEntry>()
    private val defaultGeometry = mutableMapOf<String, Geometry>()
    private var lastSw = 0f
    private var lastSh = 0f

    @Volatile private var editModeActive = false
    private var editSelectedId: String? = null
    private var editDragPointerId = -1
    private var editDragOffX = 0f   // touch point minus button center, at drag start
    private var editDragOffY = 0f
    private var editResizing = false
    private var editResizeStartDist = 0f
    private var editResizeStartScale = 1f
    private var editDirty = false   // true once the working copy diverges from what's saved
    private lateinit var editTopBar: LinearLayout
    private lateinit var editButtonBar: LinearLayout
    private lateinit var editButtonLabel: TextView
    private lateinit var editLockBtn: Button

    // ── Fast-forward state ─────────────────────────────────────────────────
    @Volatile private var fastForwardSpeed  = 2.0f
    @Volatile private var fastForwardActive = false
    private var ffBtnRect  = RectF()
    private var ffFrameAccumulator = 0.0

    // ── Fullscreen mode (toggled ONLY from Settings) ───────────────────────
    @Volatile private var fullscreenMode = false

    // ── Button / screen customization ─────────────────────────────────────
    private var buttonScaleMultiplier = 1.0f   // 0.75 / 1.0 / 1.25
    private var buttonBaseAlpha       = 160    // idle opacity 0-255
    private var gameScreenFraction    = GAME_FRAC_NORM  // 0.35–0.65
    // OUTLINE SKIN: stroke width for the line-art button style, recomputed
    // as a screen-size fraction in buildControlLayout() (same convention as
    // every other button dimension in that function) rather than a fixed
    // pixel constant, so it scales sensibly across phone sizes.
    private var outlineStrokeW        = 5f

    // ── Turbo (rapid-fire) A / B ────────────────────────────────────────────
    // Adds two extra red on-screen buttons — "TA"/"TB" — that auto-repeat
    // the A/B press while held instead of holding it continuously. Off by
    // default; toggled in ⚙ Settings → Input (see showInputSettings()),
    // which just adds/removes "ta"/"tb" from buildControlLayout() and
    // rebuilds — same mechanism as any other layout change.
    @Volatile private var turboButtonsEnabled = false
    @Volatile private var turboAHeld = false
    @Volatile private var turboBHeld = false
    // Half-period of the on/off square wave, in ms. ~66ms half-period ≈ 7-8
    // presses/sec, a typical "turbo" feel — fast enough to matter, slow
    // enough that the core still registers each edge.
    private val turboHalfPeriodMs = 66L

    // ── Performance overlay (FEATURE — off by default) ─────────────────────
    // Small corner readout of emulated core FPS and the AudioTrack underrun
    // counter — the same underrun figure already logged periodically (see
    // writePcm()), just also surfaced on-screen for at-a-glance diagnosis
    // without needing logcat. Purely additive and opt-in: when disabled
    // (the default) the game thread does none of the counting work below,
    // so there's zero overhead on the thread that also paces audio.
    // Toggled in ⚙ Settings → Misc, next to the other gameplay tweaks.
    @Volatile private var showFpsOverlay = false
    @Volatile private var fpsOverlayText = ""
    private var fpsFrameCount    = 0
    private var fpsWindowStartNs = 0L

    // ── Button click sound ───────────────────────────────────────────────
    // Uses the system's built-in FX_KEYPRESS_STANDARD effect via AudioManager
    // rather than SoundPool/MediaPlayer. That matters for two reasons:
    //  1. No asset file needed — the sound ships with the OS.
    //  2. playSoundEffect() is fire-and-forget and non-blocking; it's cached
    //     by the system after the first call. A prior approach that created
    //     a MediaPlayer (or cold-loaded a SoundPool sample) on every touch
    //     event would synchronously decode/prepare audio on the UI thread —
    //     and since updateGameKeys() runs on EVERY ACTION_MOVE while
    //     dragging (not just on initial press), that's dozens of blocking
    //     calls per second, which is exactly what freezes the UI.
    // We avoid both problems by only firing on the RISING EDGE of a button
    // press (see updateGameKeys) and by using the pre-cached system effect.
    private var buttonSoundEnabled = false
    private var lastSoundKeys      = 0
    private var audioManager: AudioManager? = null

    // ── Audio ──────────────────────────────────────────────────────────────
    @Volatile private var audioTrack: AudioTrack? = null
    private val audioBuffer = ShortArray(2048)
    // FAST-FORWARD AUDIO: accumulates every sub-frame's PCM across one
    // fast-forward batch (see startGameLoop) before decimateForFastForward()
    // compresses it back down to about one frame's worth. Sized for
    // FF_MAX_BATCH_FRAMES sub-frames at audioBuffer's own per-read capacity.
    private val ffAccumBuffer = ShortArray(FF_MAX_BATCH_FRAMES * audioBuffer.size)
    private var audioDiagCounter = 0
    // AUDIO FIX (this pass): audio focus was never requested. AudioTrack will
    // still *build* and accept writes without it, but several OEM audio HALs
    // (MIUI/ColorOS/FuntouchOS in particular) silently keep a stream's output
    // gain at zero — not muted, not erroring, just inaudible — until the app
    // holding the Surface/foreground also holds AUDIOFOCUS_GAIN. Requesting
    // it costs nothing on stock AOSP devices where sound already worked.
    private var audioFocusRequest: AudioFocusRequest? = null
    private val audioFocusListener = AudioManager.OnAudioFocusChangeListener { /* no-op: USAGE_GAME doesn't duck */ }

    companion object {
        private const val TAG             = "mGBA"
        private const val GAME_FRAC_NORM  = 0.52f
        private const val CTRL_FRAC_FULL  = 0.60f

        // ── GBA hardware timing ─────────────────────────────────────────────
        // AUDIO FIX (root cause #1): the old loop paced itself with
        // Thread.sleep(1_000_000_000.0 / 60.0) — i.e. it assumed an exact
        // 60.000 Hz refresh. Real GBA hardware runs at CPU_CLOCK / CYCLES_PER_FRAME
        // = 16777216 / 280896 ≈ 59.7275 Hz. Pacing 0.46% too fast meant the game
        // thread fed the blip_buf resampler audio slightly faster than a
        // 44.1 kHz AudioTrack could drain it. Since the old code wrote with
        // WRITE_NON_BLOCKING and never checked the return value, that constant
        // small surplus was silently dropped by AudioTrack roughly every 3–4
        // real seconds — an audible periodic "stutter" that would read as
        // "audio is a little broken" on a real device even though nothing was
        // ever fully silent. Below are the exact constants (matching
        // GBA_AUDIO_CLOCK in mgba_jni.c) used for the corrected pacing.
        private const val GBA_CPU_CLOCK_HZ    = 16_777_216L   // 2^24, ARM7TDMI clock
        private const val GBA_CYCLES_PER_FRAME = 280_896L     // 228 lines * 1232 cycles
        // Only used as a *fallback* pacer for frames that produce no audio
        // (e.g. the first frame or two right after a ROM loads, before the
        // blip_buf resamplers have accumulated a full sample). Normal frames
        // are paced by the AudioTrack itself — see startGameLoop().
        private val FALLBACK_FRAME_NS =
            GBA_CYCLES_PER_FRAME * 1_000_000_000L / GBA_CPU_CLOCK_HZ

        // Headroom above the 16x fast-forward speed clamp (see
        // showMiscSettings) for sizing ffAccumBuffer below.
        private const val FF_MAX_BATCH_FRAMES = 24

        // SharedPreferences
        private const val PREFS            = "mgba_prefs"
        private const val PREF_FF_SPEED    = "ff_speed"
        private const val PREF_BTN_SCALE   = "btn_scale"
        private const val PREF_BTN_ALPHA   = "btn_alpha"
        private const val PREF_SCREEN_FRAC = "screen_frac"
        private const val PREF_FULLSCREEN  = "fullscreen"
        private const val PREF_BTN_SOUND   = "btn_sound"
        private const val PREF_TURBO       = "turbo_buttons"
        private const val PREF_SHOW_FPS    = "show_fps"
        private const val PREF_LAYOUT_PREFIX = "layout_"

        // Number of independent save-state slots offered per ROM.
        private const val SAVE_STATE_SLOTS = 4
    }

    private data class ButtonDef(
        val id: String, val rect: RectF, val keyMask: Int, val label: String, val color: Int,
        val isDpad: Boolean = false
    )

    // ── ROM picker ─────────────────────────────────────────────────────────

    // FIX: BLUETOOTH_CONNECT / BLUETOOTH_SCAN are runtime-dangerous permissions
    // on API 31+ (Android 12+). They were declared in the manifest but never
    // actually requested anywhere, so every Bluetooth link-cable action
    // (Host, Join, listing bonded devices) threw an uncaught SecurityException
    // and crashed the app on any Android 12+ device. This launcher requests
    // the permission on demand; [pendingBtAction] resumes whatever the user
    // was trying to do as soon as it's granted.
    private var pendingBtAction: (() -> Unit)? = null
    private val btPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        val action = pendingBtAction; pendingBtAction = null
        if (granted) action?.invoke()
        else uiToast("Bluetooth permission is required for BT link cable")
    }

    /** Runs [action] immediately if Bluetooth permission is already granted
     *  (or not needed on this API level), otherwise requests it first. */
    private fun ensureBluetoothPermission(action: () -> Unit) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) { action(); return }
        val granted = ContextCompat.checkSelfPermission(
            this, Manifest.permission.BLUETOOTH_CONNECT
        ) == PackageManager.PERMISSION_GRANTED
        if (granted) { action() }
        else { pendingBtAction = action; btPermissionLauncher.launch(Manifest.permission.BLUETOOTH_CONNECT) }
    }

    private val romPicker = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        pickerLive = false
        uri ?: return@registerForActivityResult
        Thread {
            try {
                // FIX: nativeLoadROM() silently drops any active link session
                // as part of swapping the native core (see the "ROM swapped
                // while a link session was active" comment in mgba_jni.c) —
                // that side is careful to avoid leaving a dangling pointer,
                // but it has no way to tell the Kotlin side this happened.
                // Without this, link.isConnected and the "🔗 ✓" button would
                // keep claiming "Connected" after a ROM swap even though the
                // native SIO driver backing the exchange no longer exists —
                // a silently broken multiplayer session with no indication
                // in the UI of why. Disconnect first so both sides agree.
                if (link.isConnected) stopLink()
                // FIX: stop any in-progress game loop *before* touching the
                // native core, and reset transient input/FF state. Previously
                // there was no way to load a second ROM at all (loadRomBtn was
                // permanently hidden after the first successful load), so this
                // path was never exercised. nativeLoadROM() now builds the new
                // core fully before swapping it in, so a failed load here
                // leaves the previous session running rather than destroying
                // it (see mgba_jni.c).
                stopGameLoop()
                val tmp = cacheDir.resolve("rom_loaded.gba")
                contentResolver.openInputStream(uri)?.use { i ->
                    tmp.outputStream().use { o -> i.copyTo(o) }
                } ?: run { uiToast("Cannot read selected file"); return@Thread }
                // ROM SAVE: identify the ROM by its picked display name —
                // not the fixed "rom_loaded.gba" cache path above, which
                // every ROM shares — so its battery save persists under a
                // name stable across app restarts and re-picking the same
                // file later. See deriveRomBaseName()/batterySaveFile().
                val baseName = deriveRomBaseName(uri)
                val saveFile = batterySaveFile(baseName)
                backupIfExists(saveFile)   // FEATURE: auto save backup
                val savePath = saveFile.absolutePath
                val ok = EmulatorEngine.nativeLoadROM(tmp.absolutePath, savePath)
                Handler(Looper.getMainLooper()).post romLoadDone@ {
                    // FIX: onDestroy() may have already run and freed the
                    // native core by the time this posts, if the load was
                    // slow (large ROM, a slow SAF/cloud-backed URI) and the
                    // user backed out of the app in the meantime. Without
                    // this check, the block below would re-init AudioTrack
                    // and start a brand new game thread + Choreographer
                    // registration after teardown — resources nothing would
                    // ever clean up, since onDestroy() has already run and
                    // won't run again for this instance.
                    if (isFinishing || isDestroyed) return@romLoadDone
                    if (ok) {
                        val w = EmulatorEngine.nativeGetWidth().coerceAtLeast(1)
                        val h = EmulatorEngine.nativeGetHeight().coerceAtLeast(1)
                        frameBuffers = Array(3) {
                            Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                        }
                        writeIdx = 0
                        readyIdx = -1
                        displayIdx = -1
                        romLoaded = true
                        currentRomBaseName = baseName
                        clearPointerState()
                        currentKeys.set(0)
                        fastForwardActive = false
                        loadRomBtn.visibility   = View.GONE
                        linkBtn.visibility      = View.VISIBLE
                        changeRomBtn.visibility = View.VISIBLE
                        initAudioTrack()
                        startGameLoop()
                    } else {
                        romLoaded = false
                        uiToast("Unsupported ROM format")
                    }
                }
            } catch (e: Throwable) {
                Log.e(TAG, "ROM load failed", e)
                uiToast("Load error: ${e.message ?: e.javaClass.simpleName}")
            }
        }.apply { name = "mGBA-load" }.start()
    }

    // ── Save / state file naming ─────────────────────────────────────────
    // SAF (Storage Access Framework) URIs don't carry a real filesystem
    // path, and the only identifier for "which ROM is this" that's stable
    // across app restarts and re-picking the same file is the picked
    // document's display name — queried via ContentResolver, since
    // uri.lastPathSegment is often an opaque provider-specific ID rather
    // than the actual filename on many document providers (Downloads,
    // Google Drive, etc).

    private fun deriveRomBaseName(uri: Uri): String {
        var display: String? = null
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { c ->
                    val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0 && c.moveToFirst()) display = c.getString(idx)
                }
        } catch (_: Exception) {
            // Provider didn't support the query — fall through to the
            // URI-based fallback below.
        }
        val base = (display ?: uri.lastPathSegment ?: "rom").substringBeforeLast('.')
        // Keep only filesystem-safe characters — a display name can contain
        // spaces, parentheses, unicode, anything a user or provider chose.
        val sanitized = base.replace(Regex("[^A-Za-z0-9_-]"), "_").take(80)
        return sanitized.ifBlank { "rom" }
    }

    private fun savesDir():  File = File(filesDir, "saves").apply  { mkdirs() }
    private fun statesDir(): File = File(filesDir, "states").apply { mkdirs() }

    /** Path for the cartridge's battery save (SRAM/Flash/EEPROM). */
    private fun batterySaveFile(baseName: String): File =
        File(savesDir(), "$baseName.sav")

    /** Path for save-state slot [slot] (1-based) of the currently loaded ROM. */
    private fun stateSlotFile(slot: Int): File =
        File(statesDir(), "$currentRomBaseName.state$slot")

    /**
     * FEATURE: auto save backup. Copies [f] to a sibling "<name>.bak" file
     * if [f] already exists, right before it's about to be overwritten —
     * the battery save is re-opened read/write and mmap'd by the native
     * core on every ROM load (see nativeLoadROM), and a save-state slot is
     * truncated the instant "Save State" is tapped (see nativeSaveState /
     * showSaveStateSlotDialog). Best-effort and silent: a backup failure
     * must never block the actual save, so any exception here is only
     * logged, never surfaced to the user.
     *
     * This is a single rolling backup, not a history — each new backup
     * replaces the last. It's a one-level rollback if the current session's
     * save turns out to be corrupt (app killed mid-write, storage fills up,
     * a bad ROM stomps save memory it shouldn't, etc.), not a substitute
     * for the user making their own backups of anything precious. There is
     * currently no in-app "restore from backup" UI — see KNOWN_LIMITATIONS.md.
     */
    private fun backupIfExists(f: File) {
        if (!f.exists()) return
        try {
            f.copyTo(File(f.parentFile, "${f.name}.bak"), overwrite = true)
        } catch (e: Exception) {
            Log.w(TAG, "Backup failed for ${f.name} (continuing without one)", e)
        }
    }

    // ── Lifecycle ──────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        // Load saved preferences
        getSharedPreferences(PREFS, MODE_PRIVATE).also { p ->
            fastForwardSpeed      = p.getFloat(PREF_FF_SPEED,    2.0f)
            buttonScaleMultiplier = p.getFloat(PREF_BTN_SCALE,   1.0f)
            buttonBaseAlpha       = p.getInt(PREF_BTN_ALPHA,      160)
            gameScreenFraction    = p.getFloat(PREF_SCREEN_FRAC, GAME_FRAC_NORM)
            fullscreenMode        = p.getBoolean(PREF_FULLSCREEN, false)
            buttonSoundEnabled    = p.getBoolean(PREF_BTN_SOUND,  false)
            turboButtonsEnabled   = p.getBoolean(PREF_TURBO,      false)
            showFpsOverlay        = p.getBoolean(PREF_SHOW_FPS,   false)
        }
        audioManager = getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        loadCustomLayout()

        link = LinkMultiplayer(this)
        // FIX 9: previously nothing ever told this side when the *other*
        // phone disconnected — isConnected only ever went back to false via
        // our own local "Disconnect" tap. link.onPeerLost fires from
        // LinkMultiplayer's liveness watchdog / BYE handling, already on the
        // main thread, so this can update UI directly.
        link.onPeerLost = { EmulatorEngine.nativeLinkStop(); updateLinkBtn("🔗 Link"); uiToast("Peer disconnected") }
        val root = FrameLayout(this)
        surfaceView = SurfaceView(this)
        surfaceView.holder.addCallback(this)
        root.addView(surfaceView, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        loadRomBtn = Button(this).apply {
            text = "▶  Load ROM"
            setBackgroundColor(Color.parseColor("#BB86FC"))
            setTextColor(Color.BLACK); textSize = 16f
            setOnClickListener { if (!pickerLive) { pickerLive = true; romPicker.launch(arrayOf("*/*")) } }
        }
        root.addView(loadRomBtn, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT
        ).also { it.gravity = Gravity.CENTER })

        linkBtn = TextView(this).apply {
            text = "🔗 Link"; textSize = 13f
            setTextColor(Color.WHITE); setPadding(20, 10, 20, 10)
            background = iconChipBackground()
            visibility = View.GONE
            setOnClickListener { showLinkDialog() }
        }
        root.addView(linkBtn, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT
        ).also { it.gravity = Gravity.TOP or Gravity.END; it.topMargin = 8; it.rightMargin = 8 })

        // FIX: previously there was NO way to load a different ROM once one
        // was loaded — loadRomBtn was hidden forever and nothing replaced it.
        // Switching games required force-killing and restarting the app.
        changeRomBtn = TextView(this).apply {
            text = "📂"; textSize = 16f
            setTextColor(Color.WHITE); setPadding(20, 6, 20, 6)
            background = iconChipBackground()
            visibility = View.GONE
            setOnClickListener { if (!pickerLive) { pickerLive = true; romPicker.launch(arrayOf("*/*")) } }
        }
        root.addView(changeRomBtn, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT
        ).also { it.gravity = Gravity.TOP or Gravity.END; it.topMargin = 8; it.rightMargin = 96 })

        settingsBtn = TextView(this).apply {
            text = "⚙"; textSize = 18f
            setTextColor(Color.WHITE); setPadding(20, 6, 20, 6)
            background = iconChipBackground()
            setOnClickListener { showGameMenu() }
        }
        root.addView(settingsBtn, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT
        ).also { it.gravity = Gravity.TOP or Gravity.START; it.topMargin = 8; it.leftMargin = 8 })

        // ── Control-layout editor UI ────────────────────────────────────────
        // Two small real-View toolbars layered above the SurfaceView. Editing
        // itself (drag/resize hit-testing) happens on the SurfaceView's touch
        // events (see onEditTouch) exactly like normal gameplay input — these
        // bars are just chrome: mode controls + per-button fine adjustment.
        fun editChip(label: String, onClick: () -> Unit) = Button(this).apply {
            text = label; textSize = 12f; setPadding(18, 4, 18, 4)
            minWidth = 0; minimumWidth = 0; minHeight = 0; minimumHeight = 0
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#552A2A3A"))
            setOnClickListener { onClick() }
        }

        editTopBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(12, 8, 12, 8)
            setBackgroundColor(Color.parseColor("#DD1A1A22"))
            visibility = View.GONE
            addView(TextView(this@MainActivity).apply {
                text = "🖊 EDIT LAYOUT — drag to move, corner handle to resize"
                setTextColor(Color.parseColor("#FFEE58")); textSize = 12f
                setPadding(8, 8, 24, 8)
            })
            addView(editChip("↺ Reset All") { confirmResetAllLayout() })
            addView(editChip("✕ Cancel")    { exitEditMode(save = false) })
            addView(editChip("✓ Done")      { exitEditMode(save = true) })
        }
        root.addView(editTopBar, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT
        ).also { it.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; it.topMargin = 8 })

        editButtonLabel = TextView(this).apply {
            textSize = 12f; setTextColor(Color.WHITE); setPadding(14, 4, 14, 4)
        }
        editLockBtn = editChip("🔓") { toggleSelectedLock() }
        editButtonBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(10, 6, 10, 6)
            setBackgroundColor(Color.parseColor("#EE22222E"))
            visibility = View.GONE
            addView(editButtonLabel)
            addView(editChip("Size－") { adjustSelectedScale(-0.1f) })
            addView(editChip("Size＋") { adjustSelectedScale(+0.1f) })
            addView(editChip("Op－")   { adjustSelectedAlpha(-20) })
            addView(editChip("Op＋")   { adjustSelectedAlpha(+20) })
            addView(editLockBtn)
            addView(editChip("↺") { editSelectedId?.let { resetSingleButton(it) } })
        }
        // Positioned dynamically (see refreshEditToolbarPosition) — x/y set
        // directly rather than via gravity, since it needs to track whichever
        // button is currently selected.
        root.addView(editButtonBar, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT))

        // ── Settings screen ──────────────────────────────────────────────
        // Built once and just shown/hidden (same pattern as editTopBar
        // above) — it has no dynamic state of its own, unlike the category
        // dialogs it opens, which rebuild their fields fresh every time.
        settingsMenuOverlay = buildSettingsMenu().apply { visibility = View.GONE }
        root.addView(settingsMenuOverlay, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        setContentView(root)
        surfaceView.setOnTouchListener { _, ev -> onGameTouch(ev); true }
        setImmersive()
    }

    override fun onDestroy() {
        super.onDestroy()
        stopGameLoop()
        releaseAudio()
        EmulatorEngine.nativeLinkStop()
        link.disconnect()
        EmulatorEngine.nativeDestroy()
    }

    // FIX: no onPause/onResume existed at all. The emulation thread and the
    // AudioTrack were only ever stopped from surfaceDestroyed()/onDestroy(),
    // but backgrounding an app (Home button, recents, notification shade)
    // does not reliably or promptly destroy a SurfaceView's Surface — so the
    // game kept running full-speed and audio kept playing while the app was
    // not visible, burning battery/CPU and producing audio "leaking" behind
    // whatever the user switched to. This is exactly the kind of background
    // battery-drain behavior Play Console's background-usage checks flag.
    override fun onPause() {
        super.onPause()
        stopGameLoop()
        try {
            audioTrack?.pause()
            // AUDIO FIX: pause() alone leaves whatever was already queued in
            // the AudioTrack's internal buffer intact. If the app is
            // backgrounded for a while and then resumed, that stale audio
            // would play first, ahead of anything the resumed game loop
            // writes — an audible "blip" of old sound. flush() (only valid
            // once paused/stopped) discards it so resume always starts clean.
            audioTrack?.flush()
        } catch (_: Exception) {}
    }

    override fun onResume() {
        super.onResume()
        if (romLoaded && surfaceHolder != null && !running) {
            startGameLoop()
        }
    }

    // ── Audio ──────────────────────────────────────────────────────────────
    //
    // AUDIO ARCHITECTURE (rewritten)
    // ───────────────────────────────
    // Old design: game thread ran nativeRunFrame() once, wrote PCM to
    // AudioTrack with WRITE_NON_BLOCKING (return value discarded), then slept
    // for a *fixed* 1/60 s to pace itself. Two compounding problems:
    //   1. 1/60 s is not the GBA's real frame period (see GBA_CYCLES_PER_FRAME
    //      above), so the loop fed audio ~0.46% faster than it could play.
    //   2. WRITE_NON_BLOCKING silently drops whatever doesn't fit — so that
    //      surplus was thrown away in little bursts instead of building
    //      genuine latency, producing a small periodic glitch.
    //
    // New design: the game thread writes PCM with a genuine *blocking* write
    // and does NOT sleep on its own for the normal-speed case — the blocking
    // write against a real audio clock (the DAC/HAL drain rate) becomes the
    // frame pacer. This is the same "audio-locked" sync strategy used by most
    // well-engineered software emulators: the audio hardware clock is far more
    // stable than Thread.sleep(), which is at the mercy of OS scheduling
    // jitter, so tying video pacing to it removes drift entirely instead of
    // approximating a fixed wall-clock rate. A short fallback sleep
    // (FALLBACK_FRAME_NS) only kicks in for frames that produce zero audio
    // samples (e.g. immediately after a ROM loads), so the loop never spins
    // unpaced if audio is temporarily unavailable.
    //
    // Fast-forward now plays audio too, instead of dropping it outright.
    // Each FF batch's sub-frame audio is accumulated (ffAccumBuffer) and
    // then box-filter decimated down to roughly one frame's worth — see
    // decimateForFastForward() below — before going through the same
    // blocking writePcm() pacer as normal playback. That keeps the loop's
    // real-time pacing (and therefore the actual speedup) intact while
    // producing real, audible, pitched-up audio: the same "sped-up tape"
    // effect classic emulators use for FF sound, not a pitch-accurate
    // resample. A proper interpolating resampler would sound cleaner but is
    // a substantially bigger DSP undertaking for a fairly small audible gain
    // over this.
    // (audioTrack / audioBuffer / audioDiagCounter fields are declared above,
    // grouped with the rest of the class's mutable state.)

    /**
     * (Re)creates the AudioTrack.
     *
     * Buffer size: minBuf * 3. This used to be minBuf * 2 for lower latency,
     * but that cut it too close: rendering used to run on this same thread
     * right after each writePcm() call, and a slow render (a GC pause, a
     * busy compositor) could stall the next write long enough for AudioTrack
     * to run dry — an underrun, heard as a click/pop. Rendering is now
     * decoupled onto its own Choreographer-driven loop (see the triple-buffer
     * fields near the top of this class and startGameLoop()), which removes
     * that particular stall, but minBuf*3 is left as-is: it's cheap headroom
     * against ordinary OS scheduling jitter on the write thread itself, and
     * there's no benefit to shaving it back down.
     *
     * PERFORMANCE_MODE_LOW_LATENCY (API 26+) opts into the platform's fast
     * mixer path when the device supports it. It's a request, not a
     * guarantee — unsupported devices silently fall back to the normal path
     * with no functional risk, so it's safe to always ask for it.
     */
    private fun initAudioTrack() {
        releaseAudio()
        val minBuf = AudioTrack.getMinBufferSize(
            44100,
            AudioFormat.CHANNEL_OUT_STEREO,
            AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(4096)
        val bufferBytes = (minBuf * 3).coerceAtLeast(6144)

        val builder = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(44100)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                    .build()
            )
            .setBufferSizeInBytes(bufferBytes)
            .setTransferMode(AudioTrack.MODE_STREAM)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder.setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
        }

        audioTrack = try { builder.build() } catch (e: Exception) {
            Log.e(TAG, "AudioTrack.Builder failed, retrying without low-latency mode", e)
            // Some OEM audio HALs reject PERFORMANCE_MODE_LOW_LATENCY outright
            // instead of gracefully degrading. Retry once without it so a
            // quirky device still gets sound, even if not the fast path.
            try {
                AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build())
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(44100)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                            .build())
                    .setBufferSizeInBytes(bufferBytes)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()
            } catch (e2: Exception) {
                Log.e(TAG, "AudioTrack unavailable on this device", e2)
                null
            }
        }
        // Explicit full volume — build() already defaults to 1.0f, but this
        // removes any doubt on OEM tracks that have shipped odd defaults.
        try { audioTrack?.setVolume(1.0f) } catch (_: Exception) {}
        requestAudioFocus()
        audioTrack?.play()
        audioDiagCounter = 0
        Log.d(TAG, "AudioTrack started (bufferBytes=$bufferBytes, minBuf=$minBuf, " +
                "lowLatency=${Build.VERSION.SDK_INT >= Build.VERSION_CODES.O})")
    }

    /** See the comment on [audioFocusRequest] for why this exists. */
    private fun requestAudioFocus() {
        val am = audioManager ?: return
        val granted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build())
                .setOnAudioFocusChangeListener(audioFocusListener)
                .build()
            audioFocusRequest = req
            am.requestAudioFocus(req) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        } else {
            @Suppress("DEPRECATION")
            am.requestAudioFocus(
                audioFocusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN
            ) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        }
        Log.d(TAG, "Audio focus granted=$granted")
    }

    private fun abandonAudioFocus() {
        val am = audioManager ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            audioFocusRequest?.let { am.abandonAudioFocusRequest(it) }
            audioFocusRequest = null
        } else {
            @Suppress("DEPRECATION")
            am.abandonAudioFocus(audioFocusListener)
        }
    }

    private fun releaseAudio() {
        try { audioTrack?.stop(); audioTrack?.release() } catch (_: Exception) {}
        audioTrack = null
        abandonAudioFocus()
    }

    /**
     * Blocking write of [count] interleaved stereo PCM pairs from
     * [audioBuffer] to the AudioTrack. Called from the game thread only.
     *
     * Unlike the old WRITE_NON_BLOCKING call (whose return value was
     * discarded), this checks the result:
     *   - a short write (0 < written < requested) retries the remainder —
     *     legitimate under blocking mode only if playback state changed
     *     mid-write (e.g. onPause() firing concurrently), in which case
     *     finishing the write is harmless and cheap.
     *   - ERROR_DEAD_OBJECT means the audio server died/restarted under us
     *     (e.g. mediaserver crash, or another app seized exclusive audio) —
     *     recreate the AudioTrack once and retry, rather than staying silent
     *     for the rest of the session.
     *   - any other negative error code is logged and the frame's audio is
     *     dropped; retrying indefinitely inside the game loop would risk
     *     hanging it.
     */
    private fun writePcm(count: Int) {
        if (count <= 0) return
        val totalShorts = count * 2
        var track = audioTrack ?: return
        var offset = 0
        var attempts = 0
        while (offset < totalShorts && attempts < 2) {
            val n = try {
                track.write(audioBuffer, offset, totalShorts - offset, AudioTrack.WRITE_BLOCKING)
            } catch (e: Exception) {
                Log.e(TAG, "AudioTrack.write threw", e); return
            }
            when {
                n > 0 -> offset += n
                n == AudioTrack.ERROR_DEAD_OBJECT -> {
                    Log.w(TAG, "AudioTrack died — reinitializing")
                    initAudioTrack()
                    track = audioTrack ?: return
                    attempts++
                }
                n < 0 -> { Log.e(TAG, "AudioTrack.write error=$n"); return }
                else  -> return // n == 0: track not started / no progress possible right now
            }
        }
        // Lightweight real-device diagnostics: log the underrun counter every
        // ~5s (300 frames @ ~60Hz) rather than every frame, so it's cheap
        // enough to leave in a release build's logcat for field debugging.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            audioDiagCounter++
            if (audioDiagCounter >= 300) {
                audioDiagCounter = 0
                Log.d(TAG, "AudioTrack underrunCount=${audioTrack?.underrunCount}")
            }
        }
    }

    /**
     * Fast-forward audio compression. Averages [accumPairs] stereo pairs in
     * [ffAccumBuffer] (collected across [factor] emulated sub-frames — see
     * the game loop in startGameLoop) down into `audioBuffer`, roughly
     * [factor]x shorter, and returns how many pairs it wrote there.
     *
     * This is plain box-filter decimation: each output pair is the mean of
     * one block of [factor] consecutive input pairs (L and R averaged
     * separately). Averaging first is a cheap stand-in for a proper
     * low-pass filter ahead of the downsample — standard decimation
     * practice — and keeps the result from sounding as harsh as naively
     * dropping samples would, at effectively zero extra cost. Playing the
     * shorter result back at the normal 44.1kHz rate is what produces the
     * audible pitch-up.
     */
    private fun decimateForFastForward(accumPairs: Int, factor: Int): Int {
        if (factor <= 1) {
            val n = accumPairs.coerceAtMost(audioBuffer.size / 2)
            System.arraycopy(ffAccumBuffer, 0, audioBuffer, 0, n * 2)
            return n
        }
        val outPairs = (accumPairs / factor).coerceAtMost(audioBuffer.size / 2)
        var src = 0
        for (out in 0 until outPairs) {
            var sumL = 0
            var sumR = 0
            repeat(factor) {
                sumL += ffAccumBuffer[src].toInt()
                sumR += ffAccumBuffer[src + 1].toInt()
                src += 2
            }
            audioBuffer[out * 2]     = (sumL / factor).toShort()
            audioBuffer[out * 2 + 1] = (sumR / factor).toShort()
        }
        return outPairs
    }

    // ── Surface ────────────────────────────────────────────────────────────

    override fun surfaceCreated(holder: SurfaceHolder)                          { surfaceHolder = holder }
    override fun surfaceDestroyed(holder: SurfaceHolder)                        { stopGameLoop(); surfaceHolder = null }
    override fun surfaceChanged(holder: SurfaceHolder, fmt: Int, w: Int, h: Int) {
        surfaceHolder = holder
        buildControlLayout(w.toFloat(), h.toFloat())
        if (romLoaded) { updateGameMatrix(w.toFloat(), h.toFloat()); if (!running) startGameLoop() }
    }

    // ── Game loop ──────────────────────────────────────────────────────────

    private fun startGameLoop() {
        if (running) return
        val bufs = frameBuffers ?: return
        val holder = surfaceHolder ?: return
        val sw = holder.surfaceFrame.width().toFloat()
        val sh = holder.surfaceFrame.height().toFloat()
        if (sw > 0f && sh > 0f) { buildControlLayout(sw, sh); updateGameMatrix(sw, sh) }
        try { audioTrack?.play() } catch (_: Exception) {}
        running = true
        ffFrameAccumulator = 0.0
        fpsFrameCount = 0
        fpsWindowStartNs = 0L
        startRenderLoop()
        gameThread = Thread {
            while (running) {
                try {
                    val t0 = System.nanoTime()
                    val speed = if (fastForwardActive) fastForwardSpeed else 1f

                    val framesToRun: Int
                    if (fastForwardActive) {
                        ffFrameAccumulator += speed
                        framesToRun = ffFrameAccumulator.toInt().coerceAtLeast(1)
                        ffFrameAccumulator -= framesToRun
                    } else {
                        framesToRun = 1
                        ffFrameAccumulator = 0.0
                    }

                    EmulatorEngine.nativeSetKeys(effectiveKeysForCore())
                    // Sub-frames of a fast-forward batch all render into the
                    // same back buffer — only the last one ends up on screen,
                    // same as before; only the publish step below is new.
                    val backBmp = bufs[writeIdx]
                    var wroteAudio = false
                    if (framesToRun == 1) {
                        // Normal (non-FF) path — unchanged.
                        EmulatorEngine.nativeRunFrame(backBmp)
                        val n = EmulatorEngine.nativeReadAudioSamples(audioBuffer, audioBuffer.size / 2)
                        if (n > 0) { writePcm(n); wroteAudio = true }   // blocking — this *is* the frame pacer now
                    } else {
                        // Fast-forward batch: run every sub-frame, collecting
                        // each one's audio into ffAccumBuffer instead of
                        // discarding it, then compress the whole batch down
                        // to about one frame's worth (decimateForFastForward)
                        // so it can go through the same blocking writePcm()
                        // pacer below — see the audio-architecture note above.
                        var accumPairs = 0
                        for (i in 0 until framesToRun) {
                            // PERF: only the LAST sub-frame in the batch is
                            // ever displayed (see the buffer-publish step
                            // below), so earlier ones pass null and skip the
                            // pixel-copy blit entirely — see FIX 5 in
                            // mgba_jni.c. Emulation and audio still run in
                            // full for every sub-frame.
                            val bmpForThisSubFrame = if (i == framesToRun - 1) backBmp else null
                            EmulatorEngine.nativeRunFrame(bmpForThisSubFrame)
                            val n = EmulatorEngine.nativeReadAudioSamples(audioBuffer, audioBuffer.size / 2)
                            if (n > 0 && accumPairs + n <= ffAccumBuffer.size / 2) {
                                System.arraycopy(audioBuffer, 0, ffAccumBuffer, accumPairs * 2, n * 2)
                                accumPairs += n
                            }
                        }
                        if (accumPairs > 0) {
                            val outPairs = decimateForFastForward(accumPairs, framesToRun)
                            if (outPairs > 0) { writePcm(outPairs); wroteAudio = true }
                        }
                    }

                    // Publish the completed frame for the Choreographer
                    // renderer (see the field comments above) and claim
                    // whichever of the 3 buffers is free for next time —
                    // never the one just published or the one the renderer
                    // may currently be drawing.
                    synchronized(bufferLock) {
                        readyIdx = writeIdx
                        writeIdx = (0..2).first { it != readyIdx && it != displayIdx }
                    }

                    if (showFpsOverlay) {
                        // FEATURE: performance overlay — counts every emulated
                        // GBA frame, so a 4x fast-forward batch counts as 4,
                        // matching the "core FPS" figure emulators
                        // conventionally show. Gated behind the toggle so
                        // there is no counting work at all on this thread —
                        // the one pacing audio — when the overlay is off.
                        if (fpsWindowStartNs == 0L) fpsWindowStartNs = t0
                        fpsFrameCount += framesToRun
                        val windowNs = t0 - fpsWindowStartNs
                        if (windowNs >= 1_000_000_000L) {
                            val fps = fpsFrameCount * 1_000_000_000.0 / windowNs
                            val underruns = try { audioTrack?.underrunCount ?: 0 } catch (_: Exception) { 0 }
                            fpsOverlayText = "%.1f fps  ·  %d underruns".format(fps, underruns)
                            fpsFrameCount = 0
                            fpsWindowStartNs = t0
                        }
                    }

                    if (!wroteAudio) {
                        // Fallback pacer for the rare batch that produced no audio
                        // (e.g. immediately after a ROM loads, before blip_buf has
                        // accumulated a full sample, or if this device has no usable
                        // AudioTrack at all). Uses the real GBA frame period, scaled
                        // down by `speed` during FF so this edge case doesn't stall
                        // fast-forward back to real-time.
                        val elapsed = System.nanoTime() - t0
                        val fallbackNs = (FALLBACK_FRAME_NS / speed).toLong()
                        val sleepMs = (fallbackNs - elapsed) / 1_000_000L
                        if (sleepMs > 0L) Thread.sleep(sleepMs)
                    }
                    // Normal case: writePcm() above already blocked until the
                    // audio HAL had room for this batch's samples, which paces
                    // the loop against the real device audio clock — no
                    // Thread.sleep() needed and no drift accumulates, whether
                    // this iteration ran one GBA frame or a fast-forward batch
                    // of them. Rendering is no longer on this thread at all, so
                    // a slow frame draw can no longer delay the next audio write.
                } catch (_: InterruptedException) { break }
                catch (e: Throwable) { Log.e(TAG, "Loop error", e); uiToast("Error: ${e.message}"); break }
            }
            running = false
        }.also { it.name = "mGBA-loop"; it.start() }
    }

    private fun stopGameLoop() {
        running = false
        // 750ms rather than 500ms: the game thread may be inside a blocking
        // AudioTrack.write() call (see writePcm()). Android unblocks a
        // pending write when the track's play state changes from another
        // thread, so this should return almost immediately in practice —
        // the extra margin only matters on a slow/unusual audio HAL.
        gameThread?.join(750)
        gameThread = null
        stopRenderLoop()
    }

    private fun renderFrame(bmp: Bitmap) {
        val holder = surfaceHolder ?: return
        // PERF: lockHardwareCanvas() (API 23+, always available at our
        // minSdk 24) hands back a GPU-composited canvas instead of the plain
        // software Skia canvas lockCanvas() gives — the scaled drawBitmap()
        // plus the dozen-odd drawRoundRect/drawText calls for the on-screen
        // controls get composited on the GPU instead of the CPU every frame.
        // Falls back to a software canvas automatically on devices/drivers
        // that don't support it, so this is a strict upside with no
        // compatibility risk. Every draw call below (drawColor, drawBitmap
        // with a Matrix, drawRoundRect, drawText, drawCircle) is a basic op
        // fully supported under hardware acceleration — nothing here relies
        // on a software-only Xfermode/PathEffect/Shader.
        val canvas: Canvas = try { holder.lockHardwareCanvas() ?: return } catch (_: Exception) { return }
        try {
            canvas.drawColor(Color.BLACK)
            canvas.drawBitmap(bmp, gameMatrix, null)
            drawControls(canvas)
            if (editModeActive) drawEditOverlay(canvas)
            if (link.isConnected) drawLinkStatus(canvas)
            if (fastForwardActive) drawFfOverlay(canvas)
            if (showFpsOverlay) drawFpsOverlay(canvas)
        } finally { try { holder.unlockCanvasAndPost(canvas) } catch (_: Exception) {} }
    }

    // ── Game matrix ────────────────────────────────────────────────────────

    private fun updateGameMatrix(sw: Float, sh: Float) {
        val bmp   = frameBuffers?.get(0) ?: return
        val gameH = if (fullscreenMode) sh else sh * gameScreenFraction
        val scale = minOf(sw / bmp.width, gameH / bmp.height)
        gameMatrix.reset()
        gameMatrix.postScale(scale, scale)
        gameMatrix.postTranslate(
            (sw - bmp.width  * scale) / 2f,
            (gameH - bmp.height * scale) / 2f
        )
    }

    // ── Controls layout ────────────────────────────────────────────────────

    /**
     * Builds the on-screen button rects.
     * buttonScaleMultiplier (0.75 / 1.0 / 1.25) scales all button sizes.
     * gameScreenFraction controls where the controls strip begins.
     *
     * Fullscreen mode: game fills screen, controls overlay from CTRL_FRAC_FULL.
     * Normal mode    : game in top [gameScreenFraction] fraction.
     *
     * NOTE: the fullscreen ⛶ button was REMOVED from the game screen.
     * Toggle fullscreen from ⚙ Settings instead.
     */
    // ── Layout persistence ───────────────────────────────────────────────────

    private fun orientationTag(): String =
        if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) "land" else "port"

    private fun loadCustomLayout() {
        customLayout.clear()
        val raw = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(PREF_LAYOUT_PREFIX + orientationTag(), null) ?: return
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                customLayout[o.getString("id")] = LayoutEntry(
                    xFrac = o.getDouble("x").toFloat(),
                    yFrac = o.getDouble("y").toFloat(),
                    scale = o.optDouble("scale", 1.0).toFloat(),
                    alphaOverride = o.optInt("alpha", -1),
                    locked = o.optBoolean("locked", false)
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Corrupt saved layout, ignoring", e)
        }
    }

    private fun saveCustomLayout() {
        try {
            val arr = JSONArray()
            for ((id, e) in customLayout) {
                arr.put(JSONObject().apply {
                    put("id", id); put("x", e.xFrac.toDouble()); put("y", e.yFrac.toDouble())
                    put("scale", e.scale.toDouble()); put("alpha", e.alphaOverride); put("locked", e.locked)
                })
            }
            getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString(PREF_LAYOUT_PREFIX + orientationTag(), arr.toString())
                .apply()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to save layout", e)
            uiToast("Couldn't save layout")
        }
        editDirty = false
    }

    /** Computes the on-screen rect for [id] given its DEFAULT center/size,
     *  applying any saved/in-progress override. Always records the default
     *  geometry so "reset this button" and a brand-new drag both have a
     *  known baseline to work from, even if a saved override already exists. */
    private fun resolvedRect(id: String, cx: Float, cy: Float, w: Float, h: Float): RectF {
        defaultGeometry[id] = Geometry(cx, cy, w, h)
        val ov = customLayout[id]
        val fcx = if (ov != null) ov.xFrac * lastSw else cx
        val fcy = if (ov != null) ov.yFrac * lastSh else cy
        val scale = ov?.scale ?: 1f
        val fw = (w * scale).coerceAtLeast(1f)
        val fh = (h * scale).coerceAtLeast(1f)
        return RectF(fcx - fw / 2f, fcy - fh / 2f, fcx + fw / 2f, fcy + fh / 2f)
    }

    // Scratch list buildControlLayout() appends into via addButton(); only
    // ever touched from the UI thread, then published atomically to
    // `buttons` in one assignment at the end of buildControlLayout().
    private var buildingButtons = mutableListOf<ButtonDef>()

    private fun addButton(id: String, cx: Float, cy: Float, w: Float, h: Float, mask: Int, label: String, color: Int, isDpad: Boolean = false) {
        buildingButtons += ButtonDef(id, resolvedRect(id, cx, cy, w, h), mask, label, color, isDpad)
    }

    // ── Control layout (positions/sizes) ────────────────────────────────────
    //
    // CONTROL EDITOR (feature #2): every button below is now addressable by a
    // stable id and routed through resolvedRect()/addButton(), which checks
    // customLayout for a saved override before falling back to the default
    // formula. The formulas themselves are UNCHANGED from the original
    // design — they're still exactly what you get on a fresh install or
    // after "Reset all" — only the indirection through an override is new.
    private fun buildControlLayout(sw: Float, sh: Float) {
        buildingButtons = mutableListOf()
        lastSw = sw; lastSh = sh
        controlsTop = sh * (if (fullscreenMode) CTRL_FRAC_FULL else gameScreenFraction)
        val padH = sh - controlsTop

        // Apply scale multiplier to all button sizes
        val s      = buttonScaleMultiplier
        val btnSz  = minOf(padH * 0.24f, sw * 0.084f) * s
        val abSz   = btnSz * 0.94f
        outlineStrokeW = (minOf(sw, sh) * 0.006f).coerceIn(3f, 7f)

        // ── D-pad (left side) ────────────────────────────────────────────
        // FEATURE: unified into ONE control (id "dpad") instead of four
        // separate up/down/left/right hitboxes. Two problems that fixes:
        //  1. Editor UX — previously you had to drag/resize 4 buttons
        //     individually to reshape the d-pad, easy to knock out of
        //     alignment. Now it's one object, exactly like My Boy!'s pad.
        //  2. Diagonals — the old 4 separate rects had gaps between them
        //     (arranged in a cross with `step` spacing), so touching between
        //     e.g. up and right hit NEITHER hitbox — diagonal input was
        //     physically impossible. The unified pad hit-tests by angle
        //     (see dpadKeysFor()) so diagonals work like a real d-pad.
        val dpCx = sw * 0.18f
        val dpCy = controlsTop + padH * 0.52f
        val dpadSize = btnSz * 3.0f
        addButton("dpad", dpCx, dpCy, dpadSize, dpadSize, 0, "", colorAccentLight, isDpad = true)

        // ── A / B (right side) ────────────────────────────────────────────
        // OUTLINE SKIN: back to the same light/neutral accent as every other
        // button. The red outline read as a "turbo/rapid-fire" A/B variant
        // (that's the usual convention in emulator skins) rather than the
        // normal buttons, so A/B now match D-pad / L / R / Select / Start.
        val abCx  = sw * 0.82f
        val abCy  = controlsTop + padH * 0.52f
        val abGap = abSz * 1.2f
        addButton("a", abCx+abGap, abCy, abSz, abSz, EmulatorEngine.KEY_A, "A", colorAccentLight)
        addButton("b", abCx-abGap, abCy, abSz, abSz, EmulatorEngine.KEY_B, "B", colorAccentLight)

        // ── Turbo A / Turbo B (small red satellites, optional) ─────────────
        // Toggled in ⚙ Settings → Input. keyMask is 0 here on purpose — they
        // must NOT get OR'd straight into currentKeys like a normal button
        // (that'd just be a continuous hold, not rapid-fire). Their held
        // state is tracked separately (turboAHeld/turboBHeld, set in
        // updateGameKeys()) and turned into an actual on/off square wave
        // only at the point it's sent to the core — see nativeSetKeys() call
        // in startGameLoop().
        if (turboButtonsEnabled) {
            val tSz = abSz * 0.55f
            val tOffX = abSz * 0.75f
            val tOffY = abSz * 0.95f
            addButton("ta", abCx+abGap+tOffX, abCy-tOffY, tSz, tSz, 0, "T", colorAccentRed)
            addButton("tb", abCx-abGap-tOffX, abCy-tOffY, tSz, tSz, 0, "T", colorAccentRed)
        }

        // ── Select / Start (centre) ───────────────────────────────────────
        // Shortened from the old 0.11×/0.038× (≈6.4:1 — a long thin bar)
        // down to a squatter ≈3:1 pill.
        val ssW  = sw * 0.072f * s;  val ssH  = sh * 0.052f * s
        val ssCy = controlsTop + padH * 0.82f + ssH / 2f
        val ssGap = sw * 0.07f
        addButton("select", sw/2f-ssGap-ssW/2f, ssCy, ssW, ssH, EmulatorEngine.KEY_SELECT, "SEL", colorAccentLight)
        addButton("start",  sw/2f+ssGap+ssW/2f, ssCy, ssW, ssH, EmulatorEngine.KEY_START,  "STA", colorAccentLight)

        // ── L / R shoulder buttons ─────────────────────────────────────────
        // Reshaped to match the reference skin: a squat ~2:1 trigger glyph
        // (flat hinge edge + one big rounded sweep — see shoulderButtonPath())
        // instead of the old 0.13×/0.042× (~6.9:1) long thin bar.
        val lrW = sw * 0.07f  * s;  val lrH = sh * 0.075f * s
        val lrY = controlsTop + padH * 0.06f + lrH / 2f
        val lrCxL = sw*0.03f+lrW/2f
        val lrCxR = sw-sw*0.03f-lrW/2f
        addButton("l", lrCxL, lrY, lrW, lrH, EmulatorEngine.KEY_L, "L", colorAccentLight)
        addButton("r", lrCxR, lrY, lrW, lrH, EmulatorEngine.KEY_R, "R", colorAccentLight)

        // ── ⏩ Fast-forward — docked directly under R (matching the
        // reference layout) instead of floating above SEL/STA. Roughly
        // square, sized off R's own height, with about one R-height of gap
        // between them.
        // Not pushed into `buttons` (it isn't a GBA key — see onGameTouch),
        // but still routed through resolvedRect() so it's just as draggable
        // and resizable in the editor as every other button.
        val utilSize = lrH
        val utilY = lrY + lrH/2f + lrH + utilSize/2f
        ffBtnRect = resolvedRect("ff", lrCxR, utilY, utilSize, utilSize)
        // NOTE: fsBtnRect REMOVED — fullscreen is now in ⚙ Settings only

        // Publish the whole list in one atomic reference write — see the
        // `buttons` field comment for why this matters.
        buttons = buildingButtons

        if (editModeActive) refreshEditToolbarPosition()
    }

    // ── Draw controls ──────────────────────────────────────────────────────

    private val fillPaint   = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val labelPaint  = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textAlign = Paint.Align.CENTER
    }

    // PERF FIX: these were previously Color.parseColor("#...") calls made
    // INSIDE drawControls()/drawDpad() — i.e. re-parsed from a hex string on
    // every single rendered frame (the d-pad alone re-parsed the same string
    // 4×/frame). That's pure wasted CPU sitting on the exact thread that
    // also paces audio playback (see startGameLoop()) — any extra time spent
    // here delays the next AudioTrack.write(), which is what an underrun
    // "click" actually is. Precomputing these once is a zero-risk, visually
    // identical change (same values, same Color.parseColor, just evaluated
    // once instead of ~6-7×/frame).
    private val colorControlsBg = Color.parseColor("#CC111122")
    private val colorFfActive   = Color.parseColor("#CC7700")
    // OUTLINE SKIN: every control is now a stroked (line-art) shape instead
    // of a filled one, matching the requested reference skin — one shared
    // light/neutral accent for every button (D-pad / A / B / L / R /
    // Select / Start / FF-idle). The old solid colorFfIdle / colorDpadBase /
    // colorDpadArm fills are gone: there's no shared d-pad base plate any
    // more either — see drawDpad(), each arm is its own outlined button.
    private val colorAccentLight = Color.parseColor("#D8D8DE")
    // Used only by the optional Turbo A/B satellites — red reads as
    // "rapid-fire" (the usual emulator-skin convention), which is exactly
    // right here since that's what they are, unlike the normal A/B.
    private val colorAccentRed   = Color.parseColor("#E5484D")

    private fun drawControls(canvas: Canvas) {
        if (buttons.isEmpty()) return

        if (!fullscreenMode) {
            fillPaint.color = colorControlsBg
            canvas.drawRect(0f, controlsTop, canvas.width.toFloat(), canvas.height.toFloat(), fillPaint)
        }

        val keys       = currentKeys.get()
        // Idle alpha scales with user preference; press brightens by +80.
        // Per-button opacity overrides from the editor take priority — see
        // the loop below.
        val idleAlpha  = if (fullscreenMode) (buttonBaseAlpha * 0.70f).toInt() else buttonBaseAlpha

        for (btn in buttons) {
            val ov = customLayout[btn.id]?.alphaOverride ?: -1
            val btnIdle = if (ov >= 0) ov else idleAlpha
            if (btn.isDpad) {
                drawDpad(canvas, btn.rect, keys, btnIdle)
                continue
            }
            val pressed = when (btn.id) {
                "ta" -> turboAHeld
                "tb" -> turboBHeld
                else -> keys and btn.keyMask != 0
            }
            drawOutlineButton(canvas, btn.rect, btn.id, btn.label, btn.color, btnIdle, pressed)
        }

        // ── » Fast-forward button ────────────────────────────────────────
        val ffPressed = fastForwardActive
        val ffAlpha = (idleAlpha + 20).coerceAtMost(255)
        strokePaint.color = if (ffPressed) colorFfActive else colorAccentLight
        strokePaint.alpha = ffAlpha
        strokePaint.strokeWidth = outlineStrokeW
        if (ffPressed) {
            fillPaint.color = colorFfActive
            fillPaint.alpha = (ffAlpha * 0.35f).toInt().coerceIn(0, 255)
            canvas.drawRoundRect(ffBtnRect, 8f, 8f, fillPaint)
        }
        canvas.drawRoundRect(ffBtnRect, 8f, 8f, strokePaint)
        labelPaint.textSize = (ffBtnRect.height() * 0.52f).coerceAtLeast(12f)
        val ffLabel = if (ffPressed) "» ${formatSpeed(fastForwardSpeed)}×" else "»"
        canvas.drawText(ffLabel,
            ffBtnRect.centerX(), ffBtnRect.centerY() + labelPaint.textSize * 0.36f, labelPaint)
        // NOTE: ⛶ fullscreen button no longer drawn here — it lives in ⚙ Settings
    }

    /** Builds the L/R shoulder-trigger glyph: a flat hinge edge (left edge
     *  for L, right edge for R) with small rounded corners, a flat top edge,
     *  a short flat bottom segment on the hinge side, and one big smooth
     *  sweep on the outer side connecting the top corner down to where that
     *  bottom segment starts — the classic controller-bumper silhouette from
     *  the reference skin, instead of a plain pill. `mirrored = true` flips
     *  it for R. */
    private fun shoulderButtonPath(rect: RectF, mirrored: Boolean): Path {
        val w = rect.width(); val h = rect.height()
        val c = h * 0.22f              // small round on the two hinge-side corners
        val bottomRun = w * 0.30f      // length of the short flat bottom segment
        val path = Path()
        val left = rect.left; val top = rect.top; val right = rect.right; val bottom = rect.bottom
        if (!mirrored) {
            // L: hinge (flat) edge on the LEFT, big sweep on the RIGHT.
            path.moveTo(left, top + c)
            path.quadTo(left, top, left + c, top)
            path.lineTo(right, top)
            path.cubicTo(
                right + w * 0.02f, top + h * 0.35f,
                right - w * 0.04f, bottom - h * 0.10f,
                left + bottomRun, bottom
            )
            path.lineTo(left + c, bottom)
            path.quadTo(left, bottom, left, bottom - c)
            path.close()
        } else {
            // R: mirror of the above — hinge (flat) edge on the RIGHT.
            path.moveTo(right, top + c)
            path.quadTo(right, top, right - c, top)
            path.lineTo(left, top)
            path.cubicTo(
                left - w * 0.02f, top + h * 0.35f,
                left + w * 0.04f, bottom - h * 0.10f,
                right - bottomRun, bottom
            )
            path.lineTo(right - c, bottom)
            path.quadTo(right, bottom, right, bottom - c)
            path.close()
        }
        return path
    }

    /** Draws one outlined control button — a stroked circle for A/B (and the
     *  optional Turbo A/B satellites), a stroked shoulder-trigger glyph for
     *  L/R, a stroked pill (fully-rounded rect) for Select/Start, and a
     *  stroked rounded rect as a fallback for anything else. This is the
     *  line-art skin: no solid fill at rest, just a stroke — a soft matching
     *  fill fades in underneath only while the button is actually held, as
     *  the sole "pressed" cue. */
    private fun drawOutlineButton(
        canvas: Canvas, rect: RectF, id: String, label: String,
        accent: Int, idleAlpha: Int, pressed: Boolean
    ) {
        val alpha = if (pressed) (idleAlpha + 80).coerceAtMost(255) else idleAlpha
        strokePaint.color = accent
        strokePaint.alpha = alpha
        strokePaint.strokeWidth = outlineStrokeW
        if (pressed) {
            fillPaint.color = accent
            fillPaint.alpha = (alpha * 0.30f).toInt().coerceIn(0, 255)
        }
        var labelDx = 0f
        when (id) {
            "a", "b", "ta", "tb" -> {
                val cx = rect.centerX(); val cy = rect.centerY()
                val radius = minOf(rect.width(), rect.height()) / 2f - outlineStrokeW / 2f
                if (pressed) canvas.drawCircle(cx, cy, radius, fillPaint)
                canvas.drawCircle(cx, cy, radius, strokePaint)
            }
            "l", "r" -> {
                val p = shoulderButtonPath(rect, mirrored = id == "r")
                if (pressed) canvas.drawPath(p, fillPaint)
                canvas.drawPath(p, strokePaint)
                // Nudge the label into the "meat" of the glyph (the flat
                // hinge side), away from the tapering sweep.
                labelDx = if (id == "l") -rect.width() * 0.18f else rect.width() * 0.18f
            }
            "select", "start" -> {
                val r = rect.height() / 2f
                if (pressed) canvas.drawRoundRect(rect, r, r, fillPaint)
                canvas.drawRoundRect(rect, r, r, strokePaint)
            }
            else -> {
                if (pressed) canvas.drawRoundRect(rect, 12f, 12f, fillPaint)
                canvas.drawRoundRect(rect, 12f, 12f, strokePaint)
            }
        }
        if (label.isNotEmpty()) {
            labelPaint.textSize = (rect.height() * 0.42f).coerceAtLeast(13f)
            canvas.drawText(label, rect.centerX() + labelDx,
                rect.centerY() + labelPaint.textSize * 0.36f, labelPaint)
        }
    }

    /** Renders four independently-outlined direction buttons — no shared
     *  base plate — arranged in a loose cross, matching the reference skin
     *  where the D-pad reads as four separate line-art buttons rather than
     *  one filled plate. Hit-testing is UNCHANGED: dpadKeysFor() still
     *  resolves the whole unified [rect] by angle (see its own doc comment),
     *  so diagonals still work exactly as before even though visually
     *  you're now tapping between two shapes rather than on a solid arm. */
    private fun drawDpad(canvas: Canvas, rect: RectF, keys: Int, idleAlpha: Int) {
        val cx = rect.centerX(); val cy = rect.centerY()
        val r  = minOf(rect.width(), rect.height()) / 2f

        val armLen = r * 0.62f
        val armW   = r * 0.60f
        val corner = armW * 0.24f
        fun arm(dx: Float, dy: Float, pressed: Boolean, label: String) {
            val ax = cx + dx * armLen; val ay = cy + dy * armLen
            val armRect = RectF(ax - armW / 2f, ay - armW / 2f, ax + armW / 2f, ay + armW / 2f)
            val alpha = if (pressed) (idleAlpha + 80).coerceAtMost(255) else idleAlpha
            if (pressed) {
                fillPaint.color = colorAccentLight
                fillPaint.alpha = (alpha * 0.30f).toInt().coerceIn(0, 255)
                canvas.drawRoundRect(armRect, corner, corner, fillPaint)
            }
            strokePaint.color = colorAccentLight
            strokePaint.alpha = alpha
            strokePaint.strokeWidth = outlineStrokeW
            canvas.drawRoundRect(armRect, corner, corner, strokePaint)
            labelPaint.textSize = (armW * 0.44f).coerceAtLeast(12f)
            canvas.drawText(label, ax, ay + labelPaint.textSize * 0.36f, labelPaint)
        }
        arm(0f, -1f, keys and EmulatorEngine.KEY_UP    != 0, "▲")
        arm(0f,  1f, keys and EmulatorEngine.KEY_DOWN  != 0, "▼")
        arm(-1f, 0f, keys and EmulatorEngine.KEY_LEFT  != 0, "◀")
        arm(1f,  0f, keys and EmulatorEngine.KEY_RIGHT != 0, "▶")
    }

    /** Maps a touch point inside the unified d-pad rect to a GBA key-bit
     *  combination by angle from center, split into 8 x 45° sectors — the
     *  4 cardinal sectors give a single direction, the 4 sectors between
     *  them give the two adjacent bits (a genuine diagonal). A small
     *  circular dead-zone at the very center avoids accidental input from
     *  a light tap that lands near the middle. */
    private fun dpadKeysFor(rect: RectF, x: Float, y: Float): Int {
        val cx = rect.centerX(); val cy = rect.centerY()
        val halfW = (rect.width() / 2f).coerceAtLeast(1f)
        val halfH = (rect.height() / 2f).coerceAtLeast(1f)
        val dx = x - cx; val dy = y - cy
        val distNorm = maxOf(abs(dx) / halfW, abs(dy) / halfH)
        if (distNorm < 0.16f) return 0   // dead zone — no accidental direction from a center tap

        var deg = Math.toDegrees(kotlin.math.atan2(-dy.toDouble(), dx.toDouble()))
        if (deg < 0) deg += 360.0
        val U = EmulatorEngine.KEY_UP; val D = EmulatorEngine.KEY_DOWN
        val L = EmulatorEngine.KEY_LEFT; val R = EmulatorEngine.KEY_RIGHT
        return when {
            deg >= 337.5 || deg < 22.5  -> R
            deg < 67.5                  -> U or R
            deg < 112.5                 -> U
            deg < 157.5                 -> U or L
            deg < 202.5                 -> L
            deg < 247.5                 -> D or L
            deg < 292.5                 -> D
            else                         -> D or R
        }
    }

    private val hudPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FFCC00"); textSize = 28f; isFakeBoldText = true
    }
    private fun drawFfOverlay(canvas: Canvas) =
        canvas.drawText("⏩ ${formatSpeed(fastForwardSpeed)}×", 14f, 36f, hudPaint)

    private fun formatSpeed(s: Float): String =
        if (s == s.toLong().toFloat()) s.toLong().toString() else "%.1f".format(s)

    // ── Touch handling ─────────────────────────────────────────────────────
    //
    // STICKY DRAG-OFF: once a finger is down on a control, it keeps
    // contributing that control's key(s) even after the finger drags
    // outside that control's own hit-box — right up until that specific
    // finger actually lifts (ACTION_UP / ACTION_POINTER_UP) or the gesture
    // is cancelled. Previously updateGameKeys() re-hit-tested every
    // pointer's CURRENT position on every single call with nothing carried
    // over, so straying off a button's rect by even a pixel — while still
    // pressing down — read as an immediate release. That doesn't match how
    // a physical button (or basically any touch gamepad) behaves.
    //
    // Tracked per pointer ID (not per button) so multiple fingers can each
    // independently hold their own button, and so a finger sliding from one
    // button straight onto a different one correctly switches instead of
    // both buttons lighting up.
    private val pointerKeys   = mutableMapOf<Int, Int>()  // pointerId -> GBA key bits that finger last hit
    private val pointerTurboA = mutableSetOf<Int>()       // pointerIds currently "holding" the Turbo-A satellite
    private val pointerTurboB = mutableSetOf<Int>()       // pointerIds currently "holding" the Turbo-B satellite

    private fun clearPointerState() {
        pointerKeys.clear(); pointerTurboA.clear(); pointerTurboB.clear()
    }

    private fun onGameTouch(event: MotionEvent) {
        if (editModeActive) { onEditTouch(event); return }
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val x = event.x; val y = event.y
                // ⏩ — tap toggles fast-forward
                if (ffBtnRect.contains(x, y)) { fastForwardActive = !fastForwardActive; return }
                // NOTE: fullscreen ⛶ touch removed — use ⚙ Settings to toggle fullscreen
                updateGameKeys(event)
            }
            MotionEvent.ACTION_POINTER_DOWN,
            MotionEvent.ACTION_MOVE -> updateGameKeys(event)
            MotionEvent.ACTION_UP -> {
                if (ffBtnRect.contains(event.x, event.y)) return
                clearPointerState()
                currentKeys.set(0)
                lastSoundKeys = 0
                turboAHeld = false; turboBHeld = false
            }
            MotionEvent.ACTION_POINTER_UP -> {
                // Evict just the lifting finger's sticky state — it's the
                // only one actually going away. The explicit remove() here
                // AND excludePointerIndex below are both needed: this same
                // MotionEvent still reports the lifting pointer at its last
                // coordinates (it's only dropped from the *next* event), so
                // without excluding its index in updateGameKeys(), the
                // hit-test would immediately re-add it to pointerKeys and
                // undo the remove().
                val liftedId = event.getPointerId(event.actionIndex)
                pointerKeys.remove(liftedId)
                pointerTurboA.remove(liftedId)
                pointerTurboB.remove(liftedId)
                updateGameKeys(event, excludePointerIndex = event.actionIndex)
            }
            else                          -> {
                clearPointerState()
                currentKeys.set(0)
                lastSoundKeys = 0
                turboAHeld = false; turboBHeld = false
            }
        }
    }

    private fun updateGameKeys(event: MotionEvent, excludePointerIndex: Int = -1) {
        for (i in 0 until event.pointerCount) {
            if (i == excludePointerIndex) continue
            val pid = event.getPointerId(i)
            val x = event.getX(i); val y = event.getY(i)
            var hitAny = false
            var hitKeys = 0
            var hitTa = false
            var hitTb = false
            for (btn in buttons) {
                if (!btn.rect.contains(x, y)) continue
                hitAny = true
                when (btn.id) {
                    // Turbo satellites don't feed currentKeys directly (that
                    // would just be a continuous hold) — see the on/off
                    // square-wave applied in startGameLoop() before
                    // nativeSetKeys().
                    "ta" -> hitTa = true
                    "tb" -> hitTb = true
                    else -> hitKeys = hitKeys or (if (btn.isDpad) dpadKeysFor(btn.rect, x, y) else btn.keyMask)
                }
            }
            if (hitAny) {
                // Overwrite (don't merge with) this pointer's previous
                // sticky state — a finger that's moved onto a different
                // button, or off Turbo onto a normal button, should read
                // as ONLY what it's on now, not accumulate stale bits from
                // wherever it used to be.
                pointerKeys[pid] = hitKeys
                if (hitTa) pointerTurboA.add(pid) else pointerTurboA.remove(pid)
                if (hitTb) pointerTurboB.add(pid) else pointerTurboB.remove(pid)
            }
            // else: this pointer is over empty space right now. Leave
            // pointerKeys[pid] / pointerTurboA / pointerTurboB exactly as
            // they were — that's the fix itself: a control that was
            // pressed keeps reading as pressed while dragged off it, until
            // this specific pointer lifts (handled in onGameTouch above).
        }

        var keys = 0
        for (k in pointerKeys.values) keys = keys or k
        currentKeys.set(keys)
        turboAHeld = pointerTurboA.isNotEmpty()
        turboBHeld = pointerTurboB.isNotEmpty()

        // Click sound: only on the RISING EDGE (bits newly set that weren't
        // set last call). This function runs on every ACTION_MOVE while a
        // finger drags across the d-pad, not just on initial touch-down —
        // gating on the edge instead of "any key held" keeps this to one
        // fire-and-forget system call per actual button press, so it can
        // never flood the audio pipeline or block the UI thread.
        if (buttonSoundEnabled) {
            val newlyPressed = keys and lastSoundKeys.inv()
            if (newlyPressed != 0) audioManager?.playSoundEffect(AudioManager.FX_KEYPRESS_STANDARD)
        }
        lastSoundKeys = keys
    }

    /** currentKeys as touched, plus the Turbo A/B on/off square wave mixed
     *  in if either is currently held. Kept separate from currentKeys
     *  itself so the on-screen "pressed" glow stays a simple, steady held
     *  state (see drawControls()) — only what actually reaches the core
     *  flickers. Called once per emulated frame from startGameLoop(), which
     *  at turboHalfPeriodMs=66 is plenty of resolution for the wave to read
     *  cleanly even under fast-forward. */
    private fun effectiveKeysForCore(): Int {
        var keys = currentKeys.get()
        if (turboAHeld || turboBHeld) {
            val phaseOn = (System.currentTimeMillis() / turboHalfPeriodMs) % 2L == 0L
            if (turboAHeld) keys = if (phaseOn) keys or EmulatorEngine.KEY_A else keys and EmulatorEngine.KEY_A.inv()
            if (turboBHeld) keys = if (phaseOn) keys or EmulatorEngine.KEY_B else keys and EmulatorEngine.KEY_B.inv()
        }
        return keys
    }

    // ── Control layout editor ────────────────────────────────────────────────
    //
    // FEATURE #2 — a My Boy!-style layout editor. Scope for this pass: every
    // button (D-pad × 4, A, B, Start, Select, L, R, Fast-Forward) can be
    // freely dragged anywhere on screen and resized via a corner handle, with
    // a per-button opacity override and a per-button lock, all live-previewed
    // over the actual running game and persisted across sessions. Deliberately
    // NOT built in this pass (flagged rather than silently skipped):
    // per-button rotation/mirroring (unusual for a D-pad/AB layout — mostly
    // relevant for decorative custom skins, low value here), snap-to-guides /
    // alignment grid, and named/duplicatable layout profiles beyond the
    // automatic portrait/landscape split already wired into the storage
    // format. Per-game layouts are a storage-key change away (see
    // orientationTag()/PREF_LAYOUT_PREFIX) but need a ROM-identity concept
    // (hash or path) this codebase doesn't have yet, so it's out of scope
    // until that exists rather than faked with a no-op toggle.

    private fun labelFor(id: String): String = when (id) {
        "dpad" -> "D-Pad"
        "a" -> "A Button"; "b" -> "B Button"; "start" -> "Start"; "select" -> "Select"
        "l" -> "L Shoulder"; "r" -> "R Shoulder"; "ff" -> "Fast-Forward"
        "ta" -> "Turbo A"; "tb" -> "Turbo B"
        else -> id
    }

    private fun editRectFor(id: String): RectF? =
        if (id == "ff") ffBtnRect else buttons.find { it.id == id }?.rect

    private fun resizeHandleRadius(rect: RectF): Float =
        (minOf(rect.width(), rect.height()) * 0.22f).coerceIn(22f, 36f)

    private fun dist(x1: Float, y1: Float, x2: Float, y2: Float): Float {
        val dx = x1 - x2; val dy = y1 - y2
        return kotlin.math.sqrt(dx * dx + dy * dy)
    }

    /** Gets-or-creates the override entry for [id], seeded from its current
     *  default geometry so a freshly-touched button starts exactly where it
     *  visually already is, not at some arbitrary origin. */
    private fun entryFor(id: String): LayoutEntry = customLayout.getOrPut(id) {
        val g = defaultGeometry[id]
        LayoutEntry(
            xFrac = (g?.cx ?: lastSw / 2f) / lastSw.coerceAtLeast(1f),
            yFrac = (g?.cy ?: lastSh / 2f) / lastSh.coerceAtLeast(1f)
        )
    }

    private fun hitTestEditable(x: Float, y: Float): String? {
        if (ffBtnRect.contains(x, y)) return "ff"
        for (b in buttons) if (b.rect.contains(x, y)) return b.id
        return null
    }

    private fun enterEditMode() {
        if (!romLoaded) {
            uiToast("Load a ROM first — the editor previews live over the running game")
            return
        }
        editModeActive = true
        editSelectedId = null
        clearPointerState()  // else the finger that opened the editor stays "stuck" in
        currentKeys.set(0)   // pointerKeys and comes back held the instant the editor closes
        turboAHeld = false; turboBHeld = false
        editTopBar.visibility = View.VISIBLE
        editButtonBar.visibility = View.GONE
        uiToast("Drag a button to move it • drag its corner dot to resize")
    }

    private fun exitEditMode(save: Boolean) {
        editModeActive = false
        editSelectedId = null
        editDragPointerId = -1
        editResizing = false
        editTopBar.visibility = View.GONE
        editButtonBar.visibility = View.GONE
        if (save) { saveCustomLayout(); uiToast("Layout saved") }
        else { loadCustomLayout(); uiToast("Changes discarded") }
        buildControlLayout(lastSw, lastSh)
    }

    private fun confirmResetAllLayout() {
        AlertDialog.Builder(this)
            .setTitle("Reset layout?")
            .setMessage("This clears every custom position/size for this orientation. You can still Cancel afterward to undo.")
            .setPositiveButton("Reset") { _, _ ->
                customLayout.clear()
                editDirty = true
                editSelectedId = null
                editButtonBar.visibility = View.GONE
                buildControlLayout(lastSw, lastSh)
                uiToast("Reset — tap ✓ Done to save, or ✕ Cancel to undo")
            }
            .setNegativeButton("Keep", null)
            .show()
    }

    private fun resetSingleButton(id: String) {
        customLayout.remove(id)
        editDirty = true
        buildControlLayout(lastSw, lastSh)
        refreshEditToolbarPosition()
    }

    private fun adjustSelectedScale(delta: Float) {
        val id = editSelectedId ?: return
        val e = entryFor(id)
        if (e.locked) { uiToast("🔒 Unlock this button first"); return }
        e.scale = (e.scale + delta).coerceIn(0.5f, 2.5f)
        editDirty = true
        buildControlLayout(lastSw, lastSh)
        refreshEditToolbarPosition()
    }

    private fun adjustSelectedAlpha(delta: Int) {
        val id = editSelectedId ?: return
        val e = entryFor(id)
        if (e.locked) { uiToast("🔒 Unlock this button first"); return }
        val base = if (e.alphaOverride < 0) buttonBaseAlpha else e.alphaOverride
        e.alphaOverride = (base + delta).coerceIn(60, 255)
        editDirty = true
    }

    private fun toggleSelectedLock() {
        val id = editSelectedId ?: return
        val e = entryFor(id)
        e.locked = !e.locked
        editDirty = true
        updateEditButtonBarLockIcon()
    }

    private fun updateEditButtonBarLockIcon() {
        val id = editSelectedId ?: return
        editLockBtn.text = if (customLayout[id]?.locked == true) "🔒" else "🔓"
    }

    /** Repositions the per-button toolbar just above (or below, if that
     *  would collide with the top bar) the currently selected control. */
    private fun refreshEditToolbarPosition() {
        val id = editSelectedId ?: return
        val rect = editRectFor(id) ?: return
        editButtonBar.post {
            val w = editButtonBar.width.takeIf { it > 0 } ?: 480
            val h = editButtonBar.height.takeIf { it > 0 } ?: 110
            var ty = rect.top - h - 12f
            if (ty < editTopBar.height + 12f) ty = rect.bottom + 12f
            val tx = (rect.centerX() - w / 2f).coerceIn(4f, (lastSw - w - 4f).coerceAtLeast(4f))
            ty = ty.coerceIn(4f, (lastSh - h - 4f).coerceAtLeast(4f))
            editButtonBar.x = tx
            editButtonBar.y = ty
        }
    }

    private fun onEditTouch(event: MotionEvent) {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val x = event.x; val y = event.y
                val hitId = hitTestEditable(x, y)
                if (hitId == null) {
                    editSelectedId = null
                    editButtonBar.visibility = View.GONE
                    return
                }
                editSelectedId = hitId
                editDragPointerId = event.getPointerId(0)
                val rect = editRectFor(hitId) ?: return
                val handleR = resizeHandleRadius(rect)
                editResizing = dist(x, y, rect.right, rect.bottom) <= handleR * 1.6f
                if (editResizing) {
                    editResizeStartDist = dist(x, y, rect.centerX(), rect.centerY()).coerceAtLeast(1f)
                    editResizeStartScale = customLayout[hitId]?.scale ?: 1f
                } else {
                    editDragOffX = x - rect.centerX()
                    editDragOffY = y - rect.centerY()
                }
                editButtonLabel.text = labelFor(hitId)
                updateEditButtonBarLockIcon()
                editButtonBar.visibility = View.VISIBLE
                refreshEditToolbarPosition()
            }
            MotionEvent.ACTION_MOVE -> {
                val id = editSelectedId ?: return
                val ptr = event.findPointerIndex(editDragPointerId)
                if (ptr < 0) return
                val e = entryFor(id)
                if (e.locked) return
                val x = event.getX(ptr); val y = event.getY(ptr)
                if (editResizing) {
                    val c = editRectFor(id)
                    val d = dist(x, y, c?.centerX() ?: x, c?.centerY() ?: y)
                    e.scale = (editResizeStartScale * (d / editResizeStartDist)).coerceIn(0.5f, 2.5f)
                } else {
                    val cx = (x - editDragOffX).coerceIn(lastSw * 0.03f, lastSw * 0.97f)
                    val cy = (y - editDragOffY).coerceIn(lastSh * 0.03f, lastSh * 0.97f)
                    e.xFrac = cx / lastSw.coerceAtLeast(1f)
                    e.yFrac = cy / lastSh.coerceAtLeast(1f)
                }
                editDirty = true
                buildControlLayout(lastSw, lastSh)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                if (event.getPointerId(event.actionIndex) == editDragPointerId) {
                    editDragPointerId = -1
                    editResizing = false
                }
            }
        }
    }

    private val editHighlightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 4f; color = Color.parseColor("#FFEE58")
    }
    private val editHandlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL; color = Color.parseColor("#FFEE58")
    }
    private val editDimPaint = Paint().apply { color = Color.parseColor("#22000000") }

    private fun drawEditOverlay(canvas: Canvas) {
        canvas.drawRect(0f, 0f, canvas.width.toFloat(), canvas.height.toFloat(), editDimPaint)
        val id = editSelectedId ?: return
        val rect = editRectFor(id) ?: return
        canvas.drawRoundRect(rect, 12f, 12f, editHighlightPaint)
        canvas.drawCircle(rect.right, rect.bottom, resizeHandleRadius(rect), editHandlePaint)
    }

    // ── Settings screen ────────────────────────────────────────────────────
    //
    // RESKIN: the old single scrolling dialog is now a full-screen category
    // list — Video / Audio / Input / Layouts / Misc / Advanced / About —
    // matching the requested reference layout. Every setting that existed
    // before still exists, just regrouped:
    //   Video    — game screen size, fullscreen              (was GAME SCREEN)
    //   Audio    — button click sound
    //   Input    — the drag/resize button-layout editor
    //   Layouts  — button size, button opacity                (was CONTROLS)
    //   Misc     — fast-forward speed                         (was EMULATION)
    //   Advanced — reset all settings to defaults (new — nothing else in
    //              this app currently qualifies as "advanced")
    //   About    — app name / version (new)
    //
    // settingsMenuOverlay itself is built once in onCreate and just shown/
    // hidden (see buildSettingsMenu()) — it has no dynamic state of its own.
    // Each category still opens as an AlertDialog exactly like the old
    // settings screen did, rebuilding its fields fresh every time it's
    // opened, so Save/Cancel behaves exactly as before; dismissing that
    // dialog reveals the category list again underneath.

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    /** Transparent, outlined "chip" background for the corner icon buttons
     *  and the settings header's close button — replaces the old flat
     *  translucent box so they match the new line-art button skin. */
    private fun iconChipBackground(): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = dp(10).toFloat()
        setColor(Color.parseColor("#33000000"))
        setStroke(dp(1).coerceAtLeast(2), colorAccentLight)
    }

    private fun buildSettingsMenu(): LinearLayout {
        val ctx = this

        val header = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(16), dp(16), dp(14))
            addView(TextView(ctx).apply {
                text = "Settings"; textSize = 22f; typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.WHITE)
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(TextView(ctx).apply {
                text = "✕ Close"; textSize = 13f
                setTextColor(colorAccentLight)
                setPadding(dp(14), dp(8), dp(14), dp(8))
                isClickable = true; isFocusable = true
                background = iconChipBackground()
                setOnClickListener { settingsMenuOverlay.visibility = View.GONE }
            })
        }

        val rows = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            addView(settingsRow("💾", "Save States", "Save or load your progress")  { showSaveStateMenu() })
            addView(settingsRow("🖥", "Video",    "Screen size & fullscreen")      { showVideoSettings() })
            addView(settingsRow("🔊", "Audio",    "Button click sound")            { showAudioSettings() })
            addView(settingsRow("🕹", "Input",    "Edit on-screen button layout")  { showInputSettings() })
            addView(settingsRow("▦", "Layouts",  "Button size & opacity")         { showLayoutsSettings() })
            addView(settingsRow("👤", "Misc",     "Fast-forward speed")            { showMiscSettings() })
            addView(settingsRow("🎚", "Advanced", "Reset settings to defaults")    { showAdvancedSettings() })
            addView(settingsRow("ℹ️", "About",    "Version & info")                { showAboutDialog() })
        }

        return LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#FF17171B"))
            isClickable = true; isFocusable = true   // swallow touches — nothing behind this should be reachable
            addView(header)
            addView(View(ctx).apply { setBackgroundColor(Color.parseColor("#22FFFFFF")) },
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1).coerceAtLeast(1)))
            // Scrollable: this app is locked to landscape (see onCreate), so
            // available height can be quite short on a lot of phones — seven
            // rows plus a header can easily exceed that, which would make
            // "About" unreachable without this.
            addView(ScrollView(ctx).apply { addView(rows) },
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        }
    }

    private fun settingsRow(icon: String, title: String, subtitle: String, onClick: () -> Unit): View {
        val ctx = this
        val ripple = TypedValue()
        theme.resolveAttribute(android.R.attr.selectableItemBackground, ripple, true)
        return LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            isClickable = true; isFocusable = true
            setBackgroundResource(ripple.resourceId)
            setPadding(dp(20), dp(14), dp(20), dp(14))
            addView(TextView(ctx).apply {
                text = icon; textSize = 20f
                setTextColor(colorAccentLight)
            }, LinearLayout.LayoutParams(dp(44), LinearLayout.LayoutParams.WRAP_CONTENT))
            addView(LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                addView(TextView(ctx).apply {
                    text = title; textSize = 17f
                    setTextColor(Color.WHITE)
                })
                addView(TextView(ctx).apply {
                    text = subtitle; textSize = 12f
                    setTextColor(Color.parseColor("#888892"))
                    setPadding(0, dp(2), 0, 0)
                })
            })
            setOnClickListener { onClick() }
        }
    }

    private fun showSettingsMenu() {
        settingsMenuOverlay.visibility = View.VISIBLE
    }

    // FIX: ⚙ used to call showSettingsMenu() directly, jumping straight into
    // the full Video/Audio/Input/Layouts/... category list with no menu in
    // between. This is the quick game menu that now opens first — Load,
    // Save and Fast forward act immediately; Settings and Link remote hand
    // off to the existing screens below, unchanged.
    private fun showGameMenu() {
        AlertDialog.Builder(this)
            .setItems(arrayOf("Load", "Save", "Fast forward", "Cheats", "Settings", "Link remote")) { _, which ->
                if (which <= 2 && !romLoaded) { uiToast("Load a ROM first"); return@setItems }
                when (which) {
                    0 -> showSaveStateSlotDialog(forSave = false)
                    1 -> showSaveStateSlotDialog(forSave = true)
                    2 -> {
                        fastForwardActive = !fastForwardActive
                        uiToast(if (fastForwardActive) "Fast forward ON" else "Fast forward OFF")
                    }
                    3 -> uiToast("Cheats — not implemented yet")
                    4 -> showSettingsMenu()
                    5 -> showLinkDialog()
                }
            }
            .show()
    }

    // ── Shared dialog-building helpers (used by several categories below) ──

    private fun dlgRadioGroup(horizontal: Boolean = true) = RadioGroup(this).apply {
        if (horizontal) orientation = LinearLayout.HORIZONTAL
    }
    private fun RadioGroup.dlgAddOpt(label: String): RadioButton = RadioButton(context).apply {
        text = label
        id   = View.generateViewId()
        setTextColor(Color.WHITE)
        textSize = 13f
    }.also { addView(it) }

    // ── Video ────────────────────────────────────────────────────────────

    private fun showVideoSettings() {
        val ctx = this
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val layout = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(56, 28, 56, 20)
        }

        layout.addView(TextView(ctx).apply {
            text = "Game screen size"; textSize = 12f; setTextColor(Color.WHITE)
        })
        val screenOptions = listOf(
            "35%"        to 0.35f,
            "44%"        to 0.44f,
            "52% (def)"  to 0.52f,
            "65%"        to 0.65f
        )
        val screenRadio = dlgRadioGroup()
        screenOptions.forEach { (label, _) -> screenRadio.dlgAddOpt(label) }
        val curScreenIdx = screenOptions.indexOfFirst { abs(it.second - gameScreenFraction) < 0.02f }
            .takeIf { it >= 0 } ?: 2
        (screenRadio.getChildAt(curScreenIdx) as RadioButton).isChecked = true
        layout.addView(screenRadio)

        val fsCheck = CheckBox(ctx).apply {
            text      = "Fullscreen — game covers control area"
            isChecked = fullscreenMode
            setTextColor(Color.WHITE)
            textSize  = 13f
            setPadding(0, 16, 0, 0)
        }
        layout.addView(fsCheck)
        layout.addView(TextView(ctx).apply {
            text = "  (controls become a transparent overlay)"
            textSize = 10f
            setTextColor(Color.parseColor("#888888"))
        })

        AlertDialog.Builder(ctx)
            .setTitle("🖥  Video")
            .setView(ScrollView(ctx).also { it.addView(layout) })
            .setPositiveButton("Save") { _, _ ->
                val selScreenIdx = (0 until screenRadio.childCount)
                    .firstOrNull { (screenRadio.getChildAt(it) as RadioButton).isChecked } ?: curScreenIdx
                val newFrac = screenOptions[selScreenIdx].second

                val needsRelayout = abs(newFrac - gameScreenFraction) > 0.01f || fsCheck.isChecked != fullscreenMode
                gameScreenFraction = newFrac
                fullscreenMode     = fsCheck.isChecked

                prefs.edit()
                    .putFloat(PREF_SCREEN_FRAC, newFrac)
                    .putBoolean(PREF_FULLSCREEN, fullscreenMode)
                    .apply()

                if (needsRelayout) applyLayoutSettings()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ── Audio ────────────────────────────────────────────────────────────

    private fun showAudioSettings() {
        val ctx = this
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val layout = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(56, 28, 56, 20)
        }

        // Button click sound — system FX_KEYPRESS_STANDARD effect, fired
        // only on the rising edge of a press (see updateGameKeys()).
        val soundCheck = CheckBox(ctx).apply {
            text      = "🔊 Button click sound"
            isChecked = buttonSoundEnabled
            setTextColor(Color.WHITE)
            textSize  = 13f
        }
        layout.addView(soundCheck)
        layout.addView(TextView(ctx).apply {
            text = "Plays the system key-press effect on every button press."
            textSize = 10f
            setTextColor(Color.parseColor("#888888"))
            setPadding(0, 4, 0, 0)
        })

        AlertDialog.Builder(ctx)
            .setTitle("🔊  Audio")
            .setView(layout)
            .setPositiveButton("Save") { _, _ ->
                buttonSoundEnabled = soundCheck.isChecked
                prefs.edit().putBoolean(PREF_BTN_SOUND, buttonSoundEnabled).apply()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ── Input ────────────────────────────────────────────────────────────

    private fun showInputSettings() {
        val ctx = this
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val layout = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(56, 28, 56, 20)
            addView(TextView(ctx).apply {
                text = "Drag any button to move it, or drag its corner handle to resize — live, over the running game."
                textSize = 12f; setTextColor(Color.WHITE)
            })
        }

        // Turbo A/B — adds (or removes) the two red rapid-fire satellites
        // next to A/B. Applies immediately, same as the other one-off
        // toggles in this app (Audio's click-sound check, etc.) rather than
        // waiting on a Save button, since the only other control in this
        // dialog is an action button, not a form.
        val turboCheck = CheckBox(ctx).apply {
            text      = "⚡ Turbo A / Turbo B buttons"
            isChecked = turboButtonsEnabled
            setTextColor(Color.WHITE)
            textSize  = 13f
            setPadding(0, 16, 0, 0)
        }
        layout.addView(turboCheck)
        layout.addView(TextView(ctx).apply {
            text = "Adds two small red buttons that rapid-fire A/B while held, instead of holding them down."
            textSize = 10f
            setTextColor(Color.parseColor("#888888"))
            setPadding(0, 4, 0, 0)
        })
        turboCheck.setOnCheckedChangeListener { _, isChecked ->
            turboButtonsEnabled = isChecked
            prefs.edit().putBoolean(PREF_TURBO, isChecked).apply()
            applyLayoutSettings()
        }

        // FEATURE #2: My Boy!-style per-button layout editor entry point.
        // Dismisses both this dialog and the settings menu behind it, then
        // opens the live drag/resize editor over the running game (see
        // enterEditMode()).
        val editLayoutBtn = Button(ctx).apply {
            text = "🖊  Edit Button Layout…"
            setPadding(0, 16, 0, 0)
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#553A3A4A"))
        }
        layout.addView(editLayoutBtn)

        val dlg = AlertDialog.Builder(ctx)
            .setTitle("🕹  Input")
            .setView(layout)
            .setNegativeButton("Close", null)
            .show()
        editLayoutBtn.setOnClickListener {
            dlg.dismiss()
            settingsMenuOverlay.visibility = View.GONE
            enterEditMode()
        }
    }

    // ── Layouts ──────────────────────────────────────────────────────────

    private fun showLayoutsSettings() {
        val ctx = this
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val layout = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(56, 28, 56, 20)
        }

        layout.addView(TextView(ctx).apply {
            text = "Button size"; textSize = 12f; setTextColor(Color.WHITE)
        })
        val sizeOptions = listOf("Small" to 0.75f, "Normal" to 1.0f, "Large" to 1.25f)
        val sizeRadio   = dlgRadioGroup()
        sizeOptions.forEach { (label, _) -> sizeRadio.dlgAddOpt(label) }
        val curSizeIdx = sizeOptions.indexOfFirst { abs(it.second - buttonScaleMultiplier) < 0.05f }
            .takeIf { it >= 0 } ?: 1
        (sizeRadio.getChildAt(curSizeIdx) as RadioButton).isChecked = true
        layout.addView(sizeRadio)

        layout.addView(TextView(ctx).apply {
            text = "Button opacity"; textSize = 12f; setTextColor(Color.WHITE)
            setPadding(0, 16, 0, 0)
        })
        val alphaOptions = listOf("Low" to 90, "Normal" to 160, "High" to 220)
        val alphaRadio   = dlgRadioGroup()
        alphaOptions.forEach { (label, _) -> alphaRadio.dlgAddOpt(label) }
        val curAlphaIdx = alphaOptions.indexOfFirst { abs(it.second - buttonBaseAlpha) < 40 }
            .takeIf { it >= 0 } ?: 1
        (alphaRadio.getChildAt(curAlphaIdx) as RadioButton).isChecked = true
        layout.addView(alphaRadio)

        AlertDialog.Builder(ctx)
            .setTitle("▦  Layouts")
            .setView(ScrollView(ctx).also { it.addView(layout) })
            .setPositiveButton("Save") { _, _ ->
                val selSizeIdx = (0 until sizeRadio.childCount)
                    .firstOrNull { (sizeRadio.getChildAt(it) as RadioButton).isChecked } ?: curSizeIdx
                val newScale = sizeOptions[selSizeIdx].second

                val selAlphaIdx = (0 until alphaRadio.childCount)
                    .firstOrNull { (alphaRadio.getChildAt(it) as RadioButton).isChecked } ?: curAlphaIdx
                val newAlpha = alphaOptions[selAlphaIdx].second

                val needsRelayout = newScale != buttonScaleMultiplier
                buttonScaleMultiplier = newScale
                buttonBaseAlpha       = newAlpha

                prefs.edit()
                    .putFloat(PREF_BTN_SCALE, newScale)
                    .putInt(PREF_BTN_ALPHA,   newAlpha)
                    .apply()

                if (needsRelayout) applyLayoutSettings()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ── Misc ─────────────────────────────────────────────────────────────

    private fun showMiscSettings() {
        val ctx = this
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val layout = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(56, 28, 56, 20)
        }

        layout.addView(TextView(ctx).apply {
            text = "Fast-forward speed (0.5 – 16×)\nTap » on screen to activate"
            textSize = 12f; setTextColor(Color.WHITE)
        })
        val ffEdit = EditText(ctx).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText(formatSpeed(fastForwardSpeed))
            hint = "e.g. 2, 4, 4.5"
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            setPadding(8, 8, 8, 8)
        }
        layout.addView(ffEdit)

        val fpsCheck = CheckBox(ctx).apply {
            text = "Show performance overlay (FPS / audio underruns)"
            isChecked = showFpsOverlay
            setTextColor(Color.WHITE)
            setPadding(0, 24, 0, 0)
        }
        layout.addView(fpsCheck)

        AlertDialog.Builder(ctx)
            .setTitle("👤  Misc")
            .setView(layout)
            .setPositiveButton("Save") { _, _ ->
                val ffVal = ffEdit.text.toString().toFloatOrNull()
                if (ffVal != null) {
                    when {
                        ffVal < 0.5f || ffVal > 16f -> uiToast("Speed must be 0.5 – 16")
                        else -> {
                            fastForwardSpeed = ffVal
                            prefs.edit().putFloat(PREF_FF_SPEED, fastForwardSpeed).apply()
                        }
                    }
                }
                showFpsOverlay = fpsCheck.isChecked
                prefs.edit().putBoolean(PREF_SHOW_FPS, showFpsOverlay).apply()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ── Advanced ─────────────────────────────────────────────────────────

    private fun showAdvancedSettings() {
        val ctx = this
        val layout = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(56, 28, 56, 20)
            addView(TextView(ctx).apply {
                text = "Resets game screen size, fullscreen, button size/opacity, click sound, and fast-forward speed back to their defaults.\n\nThis does NOT clear custom button positions — reset those from Input → Edit Button Layout instead."
                textSize = 12f; setTextColor(Color.WHITE)
            })
        }
        val resetBtn = Button(ctx).apply {
            text = "↺  Reset settings to defaults"
            setPadding(0, 16, 0, 0)
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#553A3A4A"))
        }
        layout.addView(resetBtn)

        val dlg = AlertDialog.Builder(ctx)
            .setTitle("🎚  Advanced")
            .setView(layout)
            .setNegativeButton("Close", null)
            .show()

        resetBtn.setOnClickListener {
            AlertDialog.Builder(ctx)
                .setTitle("Reset settings?")
                .setMessage("This resets Video/Audio/Layouts/Misc settings to defaults.")
                .setPositiveButton("Reset") { _, _ ->
                    fastForwardSpeed      = 2.0f
                    buttonScaleMultiplier = 1.0f
                    buttonBaseAlpha       = 160
                    gameScreenFraction    = GAME_FRAC_NORM
                    fullscreenMode        = false
                    buttonSoundEnabled    = false
                    showFpsOverlay        = false
                    getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                        .putFloat(PREF_FF_SPEED, fastForwardSpeed)
                        .putFloat(PREF_BTN_SCALE, buttonScaleMultiplier)
                        .putInt(PREF_BTN_ALPHA, buttonBaseAlpha)
                        .putFloat(PREF_SCREEN_FRAC, gameScreenFraction)
                        .putBoolean(PREF_FULLSCREEN, fullscreenMode)
                        .putBoolean(PREF_BTN_SOUND, buttonSoundEnabled)
                        .putBoolean(PREF_SHOW_FPS, showFpsOverlay)
                        .apply()
                    applyLayoutSettings()
                    uiToast("Settings reset to defaults")
                    dlg.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    // ── About ────────────────────────────────────────────────────────────

    private fun showAboutDialog() {
        val ctx = this
        val versionName = try {
            packageManager.getPackageInfo(packageName, 0).versionName ?: "—"
        } catch (e: PackageManager.NameNotFoundException) { "—" }

        val layout = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(56, 28, 56, 20)
            addView(TextView(ctx).apply {
                text = getString(R.string.app_name); textSize = 18f; typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.WHITE)
            })
            addView(TextView(ctx).apply {
                text = "Version $versionName"
                textSize = 12f; setTextColor(Color.parseColor("#AAAAAA"))
                setPadding(0, 6, 0, 16)
            })
            addView(TextView(ctx).apply {
                text = "A custom Android build wrapping the mGBA core via JNI."
                textSize = 12f; setTextColor(Color.WHITE)
            })
        }

        AlertDialog.Builder(ctx)
            .setTitle("ℹ️  About")
            .setView(layout)
            .setPositiveButton("OK", null)
            .show()
    }

    /**
     * Rebuild control layout and game matrix after settings change.
     * Called on main thread; game thread picks up changes on next frame.
     */
    private fun applyLayoutSettings() {
        val holder = surfaceHolder ?: return
        val sw = holder.surfaceFrame.width().toFloat()
        val sh = holder.surfaceFrame.height().toFloat()
        if (sw > 0f && sh > 0f) {
            buildControlLayout(sw, sh)
            if (romLoaded) updateGameMatrix(sw, sh)
        }
    }

    // ── Save states ──────────────────────────────────────────────────────
    // Independent of the automatic battery save (see romPicker/nativeLoadROM)
    // — that persists whatever the *game itself* lets you save; these are
    // full emulator snapshots that let you resume from any exact moment,
    // GBA-hardware-save-menu or not. SAVE_STATE_SLOTS per-ROM slots, each a
    // plain file under statesDir(), named/keyed by currentRomBaseName so
    // switching ROMs never shows another game's slots.

    private fun showSaveStateMenu() {
        if (!romLoaded) { uiToast("Load a ROM first"); return }
        AlertDialog.Builder(this)
            .setTitle("💾  Save States")
            .setItems(arrayOf("Save State", "Load State")) { _, which ->
                showSaveStateSlotDialog(forSave = which == 0)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showSaveStateSlotDialog(forSave: Boolean) {
        val labels = (1..SAVE_STATE_SLOTS).map { slot ->
            val f = stateSlotFile(slot)
            if (f.exists()) "Slot $slot — ${DateFormat.format("MMM d, h:mm a", f.lastModified())}"
            else            "Slot $slot — Empty"
        }.toTypedArray()

        AlertDialog.Builder(this)
            .setTitle(if (forSave) "Save to which slot?" else "Load which slot?")
            .setItems(labels) { _, index ->
                val slot = index + 1
                val f = stateSlotFile(slot)
                if (!forSave && !f.exists()) {
                    uiToast("Slot $slot is empty"); return@setItems
                }
                // Runs off the UI thread — same pattern as romPicker above —
                // since this touches disk and briefly holds the native
                // core's mutex against the running game thread.
                Thread {
                    // FEATURE: auto save backup — nativeSaveState() truncates
                    // this slot's file the instant it's called (VFileOpen
                    // uses O_TRUNC — see mgba_jni.c), so anything already in
                    // it is gone the moment a save starts, even if the write
                    // itself then fails partway through.
                    if (forSave) backupIfExists(f)
                    val ok = if (forSave) EmulatorEngine.nativeSaveState(f.absolutePath)
                             else         EmulatorEngine.nativeLoadState(f.absolutePath)
                    uiToast(when {
                        ok && forSave -> "Saved to Slot $slot"
                        ok            -> "Loaded Slot $slot"
                        forSave       -> "Save failed"
                        else          -> "Load failed — slot may be from a different ROM"
                    })
                }.apply { name = "mGBA-state" }.start()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ── Link cable UI ──────────────────────────────────────────────────────

    private fun showLinkDialog() {
        if (link.isConnected) {
            AlertDialog.Builder(this).setTitle("Link Connected ✓")
                .setItems(arrayOf("Disconnect")) { _, _ -> stopLink() }.show()
            return
        }
        AlertDialog.Builder(this).setTitle("GBA Link Cable")
            .setItems(arrayOf("Host — Wi-Fi", "Join — Wi-Fi",
                               "Host — Bluetooth", "Join — Bluetooth")) { _, i ->
                when (i) {
                    0 -> link.startWifiHost(
                        onReady     = { ip -> uiToast("Waiting…\nIP: $ip"); updateLinkBtn("⏳ Hosting…") },
                        onConnected = { onLinkConnected(true,  "Wi-Fi") },
                        onError     = { uiToast("Host error: $it"); updateLinkBtn("🔗 Link") })
                    1 -> { updateLinkBtn("🔗 Scanning…")
                           link.discoverWifiHosts(
                               onFound = { hosts ->
                                   if (hosts.isEmpty()) showIpDialog()
                                   else AlertDialog.Builder(this)
                                       .setTitle("Select host")
                                       .setItems(hosts.toTypedArray()) { _, j -> joinWifi(hosts[j]) }
                                       .setNegativeButton("Enter IP") { _, _ -> showIpDialog() }.show() },
                               onError = { showIpDialog() }) }
                    // FIX: BLUETOOTH_CONNECT is a runtime-dangerous permission on API 31+.
                    // It was declared in the manifest but never requested, so tapping either
                    // of these two options crashed the app on Android 12+ with an uncaught
                    // SecurityException from listenUsingInsecureRfcommWithServiceRecord() /
                    // createInsecureRfcommSocketToServiceRecord() / getBondedDevices().
                    2 -> ensureBluetoothPermission {
                           updateLinkBtn("⏳ BT Host…")
                           link.startBluetoothHost(
                               onConnected = { onLinkConnected(true,  "Bluetooth") },
                               onError     = { uiToast("BT error: $it"); updateLinkBtn("🔗 Link") }) }
                    3 -> ensureBluetoothPermission {
                           val devs = link.getBondedDevices()
                           if (devs.isEmpty()) { uiToast("No paired devices"); return@ensureBluetoothPermission }
                           AlertDialog.Builder(this).setTitle("Choose device")
                               .setItems(devs.map { it.name ?: it.address }.toTypedArray()) { _, j ->
                                   updateLinkBtn("⏳ BT…")
                                   link.connectBluetooth(devs[j],
                                       onConnected = { onLinkConnected(false, "Bluetooth") },
                                       onError     = { uiToast("BT error: $it"); updateLinkBtn("🔗 Link") })
                               }.show() }
                }
            }.show()
    }

    private fun showIpDialog() {
        val et = EditText(this).apply { hint = "192.168.x.x" }
        AlertDialog.Builder(this).setTitle("Host IP").setView(et)
            .setPositiveButton("Connect") { _, _ -> joinWifi(et.text.toString().trim()) }.show()
    }

    private fun joinWifi(ip: String) {
        if (ip.isBlank()) return
        updateLinkBtn("⏳ Connecting…")
        link.connectWifi(ip,
            onConnected = { onLinkConnected(false, "Wi-Fi") },
            onError     = { uiToast("Connect error: $it"); updateLinkBtn("🔗 Link") })
    }

    private fun onLinkConnected(isHost: Boolean, via: String) {
        val ok = EmulatorEngine.nativeLinkStart(link, isHost)
        updateLinkBtn("🔗 $via ✓")
        uiToast("Link via $via${if (!ok) " (SIO error)" else ""}")
    }

    private fun stopLink() {
        EmulatorEngine.nativeLinkStop(); link.disconnect()
        updateLinkBtn("🔗 Link"); uiToast("Disconnected")
    }

    private fun updateLinkBtn(t: String) =
        Handler(Looper.getMainLooper()).post { linkBtn.text = t }

    // ── Link status overlay ────────────────────────────────────────────────

    private val linkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#CC22BB77"); textSize = 26f
    }
    private fun drawLinkStatus(canvas: Canvas) =
        canvas.drawText("⬤ LINK", 14f, canvas.height - 14f, linkPaint)

    // ── Performance overlay (FEATURE — see the field comments above) ───────

    private val fpsPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#CCFFFFFF"); textSize = 24f; textAlign = Paint.Align.RIGHT
    }
    private fun drawFpsOverlay(canvas: Canvas) =
        canvas.drawText(fpsOverlayText, canvas.width - 14f, 32f, fpsPaint)

    // ── Helpers ────────────────────────────────────────────────────────────

    private fun uiToast(msg: String) =
        Handler(Looper.getMainLooper()).post { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }

    @Suppress("DEPRECATION")
    private fun setImmersive() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
    }
}
