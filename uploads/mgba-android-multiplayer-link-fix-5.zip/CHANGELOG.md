# CHANGELOG — Fifth pass

Scope note: this pass reviewed `LinkMultiplayer.kt` (482 → 574 lines),
`MainActivity.kt` (2436 → 2549 lines), `EmulatorEngine.kt` (unchanged),
`mgba_jni.c` (unchanged, but read in full), `AndroidManifest.xml`,
`gradle.properties`, `app/build.gradle.kts`, `settings.gradle.kts`,
`gradle-wrapper.properties`, and `proguard-rules.pro` — the entire project.
Four previous passes (documented in `README_SETUP.md`) had already covered
audio, rendering, ROM-swap safety, permissions, and the control layout
editor in depth, so this pass concentrated on multiplayer/link internals,
which hadn't had a dedicated pass yet, plus a general pass over the rest
looking for anything the previous four missed. No UI was redesigned,
restyled, or reorganized — every change below is either backend-only or,
where it touches a screen, additive and off by default.

---

## 1. `LinkMultiplayer.kt` — cross-thread visibility on the connection state

**Category:** Bug fix — thread safety / race condition
**Files modified:** `LinkMultiplayer.kt`
**Problem:** `dataSocket`, `peerAddr`, `peerDataPort`, `btSocket`, `btIn`,
`btOut` were plain `var` fields. They're written on a setup thread (the
host's discovery thread, or the client's connect thread) and read from
`jniExchangeData()` — called from native code on the game-loop thread,
which is frequently already running by the time a connection finishes
setting up. Without `@Volatile`, the JVM memory model does not guarantee
that thread ever observes the write.
**Solution:** Marked all six fields `@Volatile`.
**Reason:** `isConnected`/`mode` were already `@Volatile`; these were the
actual gap that made the "publish a connection" pattern incomplete.
**Expected improvement:** Removes a class of "multiplayer connects but
never actually exchanges data until you background/foreground the app"
failures that would otherwise depend on unrelated incidental memory
barriers to work at all.
**Side effects:** None — `@Volatile` only affects visibility/ordering, not
behavior.

## 2. `LinkMultiplayer.kt` — discovery socket wasn't actually tracked

**Category:** Bug fix — resource cleanup / disconnect handling
**Files modified:** `LinkMultiplayer.kt`
**Problem:** A `discSocket` field existed but nothing ever assigned the
live host-broadcast or client-scan socket to it, so `disconnect()`'s
`discSocket?.close()` call was a permanent no-op. A pending
`DatagramSocket.receive()` in either thread could then only ever unblock
via its own timeout (200 ms–4000 ms depending on which one), not
immediately on disconnect.
**Solution:** Both sockets are now assigned to `discSocket` when created
and cleared when their thread finishes; `disconnect()`'s existing
`discSocket?.close()` call now actually does something.
**Reason:** Matches the same "close the live socket to force an immediate
unblock" pattern already used correctly for `dataSocket`/`btServer`.
**Expected improvement:** Backing out of a host/join screen mid-search now
tears down its background thread immediately instead of after a multi
-second delay.
**Side effects:** None.

## 3. `LinkMultiplayer.kt` — Wi-Fi packet seq byte now actually checked

**Category:** Bug fix — packet ordering / synchronization
**Files modified:** `LinkMultiplayer.kt`
**Problem:** The packet-layout doc comment described the `seq` byte as
being "for out-of-order discard," and it was populated on send, but
nothing on the receive side ever validated it. A stale reply that arrived
late — after its own round had already timed out — could be silently
accepted by whichever `receive()` call next popped it off the socket
queue, corrupting SIO data without ever looking like a connection problem.
**Solution:** `wifiExchange()` now tracks the last accepted `seq`
(`lastRxSeq`) and discards an exact repeat.
**Reason:** Implements what the existing doc comment already claimed,
cheaply and with no risk of a false-positive drop.
**Expected improvement:** Removes one source of silent, hard-to-diagnose
multiplayer desync under Wi-Fi jitter.
**Side effects:** This is a partial mitigation, not full modular
sequence-ordering — see `KNOWN_LIMITATIONS.md`.

## 4. `LinkMultiplayer.kt` — stale/abandoned connection attempts

**Category:** Bug fix — race condition / reconnect / disconnect handling
**Files modified:** `LinkMultiplayer.kt`
**Problem:** `showLinkDialog()` only blocks re-opening the connect flow
once `isConnected` is `true` — nothing stopped starting a second
connection attempt while a first was still mid-handshake (e.g. host, back
out, join — all within the 15 s handshake window). Whichever attempt
finished last would silently win, potentially clobbering the other's
sockets. Separately, `connectBluetooth()` only recorded its socket in a
class field *after* `sock.connect()` succeeded, so `disconnect()` had
nothing to close to cancel an attempt already in progress — a Bluetooth
`connect()` call can block for 10+ seconds on its own OS-level timeout.
**Solution:** Added a `connectGeneration` counter, bumped by every
`start*`/`connect*` call and by `disconnect()`; each background attempt
captures it and re-checks before mutating shared state or firing a
callback. Added `btPendingSocket`, published *before* the blocking
`connect()` call so `disconnect()` can close it to force an immediate
abort.
**Reason:** Makes "cancel and try something else" actually cancel, instead
of leaving a zombie attempt that can complete unpredictably later.
**Expected improvement:** More reliable behavior when a user backs out of
a connection attempt and immediately tries a different host/method.
**Side effects:** None — the guard is purely additive; the normal
single-attempt path behaves identically.

## 5. `MainActivity.kt` — ROM swap while linked left the UI/state inconsistent

**Category:** Bug fix — multiplayer / lifecycle consistency
**Files modified:** `MainActivity.kt`
**Problem:** `mgba_jni.c`'s ROM-swap path already protects itself from a
dangling pointer when a new ROM loads mid-link-session, by dropping the
native SIO driver registration — but it has no way to tell the Kotlin side
this happened. `changeRomBtn`/`loadRomBtn` never checked `link.isConnected`
before launching the ROM picker, so the Kotlin-side state and the "🔗 ✓"
button kept claiming "Connected" after a swap even though the link no
longer actually exchanged data.
**Solution:** The ROM-load background thread now calls `stopLink()` first
if `link.isConnected`.
**Reason:** Keeps native and Kotlin state in agreement instead of a silent,
user-visible inconsistency.
**Expected improvement:** No more "still says Connected but multiplayer
stopped working" after changing ROMs mid-session.
**Side effects:** Changing ROMs while linked now explicitly disconnects
instead of leaving a non-functional link silently in place — this is a
user-facing behavior change, but the link was already non-functional in
that state; this just makes the UI say so.

## 6. `MainActivity.kt` — ROM-load completion callback could run post-teardown

**Category:** Bug fix — lifecycle / resource leak
**Files modified:** `MainActivity.kt`
**Problem:** The ROM-load background thread posts its completion callback
to the main thread with no check that the Activity is still alive. If
`onDestroy()` already ran (e.g. the user backed out of the app during a
slow load — a large ROM, or a slow SAF/cloud-backed URI) by the time the
callback posts, it would re-initialize `AudioTrack` and start a brand-new
game thread + `Choreographer` registration *after* the native core was
already destroyed — resources with nothing left to ever clean them up.
**Solution:** Added an `isFinishing || isDestroyed` guard at the top of the
callback.
**Reason:** Standard defensive pattern for posted callbacks that can
outlive the component that scheduled them.
**Expected improvement:** Removes a narrow-window resource leak (orphaned
`AudioTrack` + thread + frame-callback registration).
**Side effects:** None.

## 7. `MainActivity.kt` — auto-backup before an overwrite

**Category:** Feature — data safety
**Files modified:** `MainActivity.kt`
**Problem:** The battery save file is re-opened read/write and mapped
fresh on every ROM load; a save-state slot is truncated the instant "Save
State" is tapped. Either one being interrupted mid-write (app killed,
storage full, a bad ROM writing where it shouldn't) had no recovery path.
**Solution:** Added `backupIfExists()` — copies the existing file to a
sibling `.bak` before it's touched. Best-effort and silent: a backup
failure is logged, never blocks the actual save.
**Reason:** Directly requested ("Auto save backups") and low-risk — purely
additive file management, no native or UI changes.
**Expected improvement:** One level of rollback if a session's save turns
out to be corrupt.
**Side effects:** Uses a small, bounded amount of extra storage (one extra
copy per save file/state slot). There is no in-app restore UI yet — see
`KNOWN_LIMITATIONS.md`.

## 8. `MainActivity.kt` — optional performance overlay

**Category:** Feature — diagnostics
**Files modified:** `MainActivity.kt`
**Problem:** No on-screen way to see whether the emulator is keeping up
(core FPS) or whether audio is underrunning, short of reading logcat.
**Solution:** Added a small corner text overlay showing core FPS (every
emulated GBA frame, including fast-forward sub-frames) and the existing
`AudioTrack.getUnderrunCount()` figure. Off by default; toggled from
⚙ Settings → Misc; included in "Reset settings to defaults".
**Reason:** Directly requested ("Performance monitor", "FPS counter") and
implementable with zero UI redesign — same visual pattern as the existing
link-status/fast-forward overlays, opt-in only.
**Expected improvement:** At-a-glance performance diagnosis without
attaching logcat.
**Side effects:** None when off (default) — the counting code doesn't run
at all unless the toggle is on, so there's no cost on the audio-pacing
thread in the default configuration.

## 9–10. `AndroidManifest.xml` — two unused permissions removed

**Category:** Security / Android best practices
**Files modified:** `AndroidManifest.xml`
**Problem:** `READ_EXTERNAL_STORAGE` and `BLUETOOTH_SCAN` were both
declared but never referenced or relied upon anywhere in the code (checked
by grepping the whole `kotlin/` tree for both). ROM loading is 100% SAF
(`OpenDocument`), which needs no storage permission; the app only calls
`getBondedDevices()` and RFCOMM connect/listen/accept, which need
`BLUETOOTH_CONNECT`, never `startDiscovery()`/BLE scanning, which is what
`BLUETOOTH_SCAN` actually gates.
**Solution:** Removed both declarations.
**Reason:** Unused dangerous-adjacent permissions increase the app's
attack surface/review footprint for no functional benefit.
**Expected improvement:** Smaller permission footprint; nothing to break,
since grep confirms zero usage of either.
**Side effects:** None.

## 11. `gradle.properties` — Jetifier disabled

**Category:** Build / technical debt
**Files modified:** `gradle.properties`
**Problem:** `android.enableJetifier=true` rewrites legacy
`android.support.*` bytecode to AndroidX at build time — but only
`androidx.core:core-ktx` and `androidx.appcompat:appcompat` remain as
dependencies (Material Components was already removed in an earlier pass),
both AndroidX-native since first publication. Jetifier was scanning every
dependency on every build for a rewrite it never had to make.
**Solution:** Set `android.enableJetifier=false`, with a comment
explaining the reasoning and when to re-enable it.
**Reason:** Verified via the dependency list in `app/build.gradle.kts` —
zero support-lib-namespaced dependencies remain.
**Expected improvement:** Slightly faster builds (one fewer full
dependency-scanning pass).
**Side effects:** None, provided no future dependency reintroduces the
legacy support-lib namespace (the comment left in place flags this).

---

## Not changed this pass

`EmulatorEngine.kt` and `mgba_jni.c` were both read in full and found to
already correctly implement what this pass would otherwise have flagged —
`g_core_mutex` already guards every native entry point, the ROM-swap path
already avoids the dangling-pointer risk it exists to avoid, and
`proguard-rules.pro` already protects `jniExchangeData` (the one method R8
could otherwise rename and silently break, since it's only ever resolved
reflectively from native code via `GetMethodID`). No changes were made to
any of these files.
