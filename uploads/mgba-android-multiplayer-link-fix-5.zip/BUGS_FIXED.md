# BUGS_FIXED — Eighth pass

Nothing fixed this pass — see `KNOWN_LIMITATIONS.md` and `FILE_CHANGES.md`
("Eighth pass") for why: the seventh pass's IRQ fix was real, but user
re-testing showed zero change on either game or transport, which points
further upstream than anything fixable by more protocol guessing from this
sandbox. Added trace logging instead of a fourth speculative fix; next
pass should be grounded in the resulting logcat output rather than more
static-only reasoning.

# BUGS_FIXED — Seventh pass

Root-caused why the sixth pass's (real, correct) SIO protocol fixes still
didn't get either test game — Yu-Gi-Oh! World Championship 2006, The
Legend of Zelda: Four Swords — off their own "waiting for link" screens.

- **Fixed: the SIO IRQ was never raised, so any interrupt-driven ROM
  never woke up to notice a completed transfer.** This was flagged as a
  known gap back at FIX 8 ("this build doesn't automatically raise the
  SIO IRQ the way hardware would") but never acted on, on the assumption
  it would only matter for unusual ROMs. It's the opposite: BIOS
  `IntrWait`/`VBlankIntrWait` — enable the interrupt, then sleep for it —
  is the standard GBA-dev pattern for waiting on *any* interrupt,
  serial included, precisely because busy-polling wastes battery on real
  hardware. A ROM using that pattern would make its one SIOCNT Start-bit
  write, then go to sleep waiting for an interrupt that was never coming
  — indistinguishable, from the player's side, from the link simply not
  working, even though the underlying byte exchange (sixth pass) was
  correct. Fixed by calling `GBARaiseIRQ(gba, GBA_IRQ_SIO, 0)` at the
  point each side (host in `link_sio_write_register()`, child in
  `nativeLinkChildExchange()`) finishes writing that round's data to
  SIOMULTI0-3. Confirmed the exact call against mGBA's real
  `src/gba/sio.c` rather than reasoning from memory — see `FIX 10` in
  `mgba_jni.c` and `KNOWN_LIMITATIONS.md` for the full citation and the
  one remaining caveat (no build-log confirmation yet, same as every
  other change across every pass).

- **Explains, not just fixes:** the user also reported fast-forward
  staying available during an active "Connected" session, unlike real
  mGBA, where it doesn't. That's downstream of the same bug — an
  interrupt-driven ROM stuck asleep isn't re-triggering the Start bit
  every frame, so there's no per-frame blocking network round-trip left
  to throttle fast-forward against. Nothing needed fixing in the
  fast-forward code itself; it was accurately reporting a game that had
  stalled.

# BUGS_FIXED — Sixth pass

This pass root-caused the two symptoms reported after the fifth pass: the
app claims "Connected" but the ROM's own link/multiplayer menu never gets
past "waiting", and a peer disconnecting on one phone was never noticed by
the other. Both were real, deterministic bugs (not flakiness) — confirmed
against GBATEK's documented Multi-Player SIO register semantics, not just
inferred from this codebase.

- **Fixed: a child (non-host) device never actually answered the host's
  link requests.** GBATEK: the Start/Busy bit is "Read Only for Slaves" — a
  GBA child unit never triggers its own SIO transfer, only the parent does.
  Since the exchange logic in `link_sio_write_register()` is keyed off
  *this device's own* Start-bit write, it correctly never fired on a child
  device — meaning a child's `wifiExchange()`/`btExchange()` (the only thing
  that ever answered the host's request packet) was never called. The
  host's every request timed out waiting for a reply nothing was ever going
  to send. This is why it was 100%-reproducible rather than intermittent.
  Fixed with a new native entry point, `nativeLinkChildExchange()`, called
  from a new passive-responder thread on the child side
  (`startWifiChildResponder()` for Wi-Fi; the existing `startBtReader()`
  thread now does the same inline for Bluetooth) the instant a request
  arrives over the network, instead of waiting on a local SIO write that
  hardware-correctly never comes.

- **Fixed: nothing ever set SIOCNT's parent/child or all-ready status
  bits.** GBATEK documents games checking SIOCNT bit 2 (parent/child) and
  bit 3 (all GBAs ready) *before* ever attempting a transfer. Neither bit
  was ever set, so a ROM that checks first could sit on its "waiting for
  link" screen indefinitely — indistinguishable from no cable being
  plugged in — regardless of whether the phones' own network handshake had
  already succeeded. Fixed by reflecting both on every SIOCNT write, not
  only ones with the Start bit set.

- **Fixed: the ID bits and Error bit were never set after a transfer.**
  GBATEK: bits 4-5 (Multi-Player ID) are undefined before the first
  transfer and meaningful after; games use them, alongside bit 2, to tell
  their own role apart. Bit 6 (Error) is meant to flag a round the peer
  didn't answer in time. Neither was ever touched, so even a
  timed-out/failed round looked identical to a real one from the ROM's
  point of view. Now set correctly on the parent's side after every
  transfer.

- **Fixed: a disconnected peer was never detected.** `isConnected` only
  ever went back to `false` via this device's own local `disconnect()`
  call — a dead socket, a force-closed peer app, or Bluetooth going out of
  range all left this side claiming "Connected" forever. Fixed with a BYE
  packet sent best-effort on `disconnect()` (so the peer notices instantly
  in the common case) plus a liveness watchdog checking time-since-last-
  peer-activity inside the existing keepalive loop (fallback for a crash or
  anything else that never gets to send a BYE). `LinkMultiplayer.onPeerLost`
  is the new hook MainActivity uses to reflect this in the UI.

- **Fixed: Bluetooth sessions never ran the keepalive loop at all.**
  `startKeepalive()` was only ever called from the two Wi-Fi connect-success
  paths; `startBluetoothHost()`/`connectBluetooth()` never called it. Beyond
  losing the periodic keepalive traffic, this pass also put the new
  liveness-watchdog check inside that same loop — so without this, a dead
  Bluetooth peer would never have been detected at all. Now called from all
  four connect-success paths.

# BUGS_FIXED — Fifth pass

- **Fixed a cross-thread visibility gap in the multiplayer link state.**
  `dataSocket`/`peerAddr`/`peerDataPort`/`btSocket`/`btIn`/`btOut` were
  written on a setup thread and read on the native game-loop thread without
  `@Volatile`, so a completed connection could go unnoticed by the thread
  that actually exchanges link data.

- **Fixed discovery-socket cleanup on disconnect.** A `discSocket` field
  existed but nothing ever assigned the live socket to it, so
  `disconnect()`'s cleanup call on it was a silent no-op; backing out of a
  host/join screen mid-search waited out a multi-second timeout instead of
  closing immediately.

- **Fixed a non-functional out-of-order-packet guard.** The Wi-Fi packet
  format's `seq` byte was documented as being for stale/out-of-order
  discard but was never actually checked on receive; a late-arriving stale
  reply could be silently accepted as current data.

- **Fixed stale/abandoned multiplayer connection attempts.** Starting a
  second connection attempt while a first was still mid-handshake (the UI
  never blocked this) could let the abandoned attempt's eventual completion
  clobber the newer one's state or fire a callback for an operation the
  user had already backed out of.

- **Fixed an uncancellable in-progress Bluetooth connection attempt.**
  `connectBluetooth()`'s socket was only tracked in a class field *after*
  `connect()` succeeded, so `disconnect()` had nothing to close to actually
  cancel an attempt in progress (which can otherwise block for 10+ seconds).

- **Fixed a ROM-swap/link-state inconsistency.** Loading or changing a ROM
  while linked left the Kotlin-side state and the link button UI claiming
  "Connected" even after the native SIO driver behind the exchange had
  already been silently dropped by the ROM swap.

- **Fixed a post-teardown resource leak in the ROM-load callback.** A slow
  ROM load whose completion callback ran after the user had already backed
  out of the app (and `onDestroy()` had already run) would re-initialize
  `AudioTrack` and start a new game thread/`Choreographer` registration
  with nothing left to ever clean them up.

- **Removed two unused, dangerous-adjacent permissions.**
  `READ_EXTERNAL_STORAGE` and `BLUETOOTH_SCAN` were declared in the
  manifest but never referenced or relied upon anywhere in the code.
