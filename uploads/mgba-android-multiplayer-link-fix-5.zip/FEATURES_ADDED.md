# FEATURES_ADDED — Fifth pass

Both features below are backend-only or off-by-default additions — neither
changes the existing UI's look, layout, or default behavior.

## 1. Auto save backup

**Description:** Before the battery save file is re-opened/mapped by a new
ROM load, or a save-state slot is overwritten, the existing file (if any)
is copied to a sibling `<name>.bak` file. Best-effort and silent — a
backup failure is logged but never blocks or interrupts the actual save.

**User benefit:** A single level of rollback if a save turns out to be
corrupted (app killed mid-write, storage fills up mid-save, or anything
else goes wrong during the write itself). Previously there was no recovery
path at all — the previous save's on-disk content was already truncated
before the new write completed.

**Files modified:** `MainActivity.kt` (`backupIfExists()`, and its two call
sites in the ROM-load path and the save-state-slot dialog).

**Reason for implementation:** Directly requested ("Auto save backups") in
the review brief, and implementable as pure, low-risk file management with
no native code or UI changes.

## 2. Optional performance overlay

**Description:** A small corner readout showing emulated core FPS
(counting every emulated GBA frame, including fast-forward sub-frames) and
the existing `AudioTrack.getUnderrunCount()` figure. Off by default;
toggled via a checkbox in ⚙ Settings → Misc, alongside the existing
fast-forward-speed setting; included in "Reset settings to defaults".

**User benefit:** At-a-glance answer to "is this actually keeping up right
now?" — useful when troubleshooting a specific device or ROM — without
needing to attach `adb logcat`.

**Files modified:** `MainActivity.kt` (state fields, a gated counter in the
game loop, a draw function following the exact style of the existing
link-status/fast-forward overlays, and the Misc-settings checkbox).

**Reason for implementation:** Directly requested ("Performance monitor",
"FPS counter") in the review brief. Implemented so it costs nothing when
disabled — the counting code inside the game loop (the same thread that
paces audio) is skipped entirely unless the toggle is on.
