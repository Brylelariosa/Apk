# KNOWN_LIMITATIONS — Fifth pass

## Environment constraints on this pass itself

- **No build was run.** This sandbox has a JDK but no Android SDK, no NDK,
  no Kotlin compiler, and no network access to fetch any of them — so
  `./gradlew assembleDebug` was never actually invoked here. Every change
  was verified by careful manual reading, full brace/paren-balance
  checking across both edited Kotlin files, and cross-referencing every
  new identifier against its declaration and every use site. That is real
  verification, but it is not the same thing as a green CI build, and it
  cannot catch every class of compiler-level error (e.g. a subtle type
  mismatch). Recommend running the normal GitHub Actions workflow on this
  ZIP before relying on it.
- **No device/emulator testing.** Nothing here was exercised on real or
  virtual hardware. This particularly matters for the multiplayer fixes —
  they were reasoned through against the JVM memory model and the existing
  code's own logic, not observed fixing an actual repro.
- **No network access for supply-chain verification.** See the Gradle
  wrapper checksum item below.

## Found but deliberately not fixed this pass

- **Wi-Fi link protocol: only exact-duplicate packets are discarded, not
  full out-of-order sequences.** `wifiExchange()` now discards a packet
  whose `seq` byte exactly repeats the last one accepted, which covers the
  simplest and most common stale-packet case. It does not implement full
  modular sequence-number correlation (comparing a received packet's `seq`
  against what was actually expected for the current round, with wraparound
  handling). Doing that properly requires deciding how the protocol should
  behave after any packet loss causes the two sides' sequence counters to
  drift — a real design question, not just a bug fix, and not something to
  guess at without a way to test against real network conditions.

- **An SIO exchange holds the native core mutex for its full network
  round-trip.** `link_sio_write_register()` runs synchronously inside
  `runFrame()` (already inside `g_core_mutex`) and calls back into Kotlin's
  `jniExchangeData()`, which does a blocking socket operation (up to 30 ms
  for Wi-Fi, 50 ms for Bluetooth) before returning. In the current
  architecture this is safe (verified: everything in the hot path runs
  sequentially on the same game thread, so there's no self-deadlock, and a
  cross-thread caller like `nativeSaveState`/`nativeDestroy` just waits a
  bounded amount of time for the mutex) but it does mean a game that
  performs SIO transfers very frequently could see its effective frame rate
  capped by the network round-trip time during active multiplayer. Fixing
  this properly would mean redesigning the SIO/network interaction to be
  asynchronous — a substantial change that needs real hardware and
  real-game testing to get right, not something to attempt blind in one
  pass.

- **`WifiManager.getConnectionInfo()`/`.dhcpInfo` remain deprecated but
  in use**, already wrapped in `@Suppress("DEPRECATION")` from an earlier
  pass. A modern replacement exists (`ConnectivityManager` +
  `LinkProperties`, both available since well below this project's
  minSdk 24) but this exact code path has already been root-caused and
  fixed multiple times across prior passes (per `README_SETUP.md`), and a
  rewrite can't be validated against real Wi-Fi hardware in this
  environment. Left as-is rather than risk regressing a working,
  hard-won fix.

- **Gradle wrapper has no pinned `distributionSha256Sum`.** Adding one is
  good supply-chain practice, but doing it correctly requires the real
  published checksum for `gradle-8.6-bin.zip` from Gradle's own
  release-checksums page — this sandbox has no network access to fetch it,
  and a guessed/incorrect value would hard-fail every build. Recommend
  pulling the real value from `https://gradle.org/release-checksums/` and
  adding it directly.

- **No armeabi-v7a/x86/x86_64 ABI support** (arm64-v8a only). Reasonable
  given `minSdk 24` — 32-bit-ARM-only devices are effectively extinct at
  that API level — but noted here for completeness since it wasn't changed
  or re-evaluated this pass.

- **No automated tests exist for the multiplayer fixes made this pass** (or
  for the codebase generally). The fixes were verified by reasoning through
  the JVM memory model and the existing control flow, not by a test that
  could catch a future regression. Adding instrumented/unit test coverage
  for `LinkMultiplayer.kt` would be a reasonable next investment, especially
  given how much of this pass's value was in exactly this file.

## Not revisited this pass (out of scope, not found broken)

`MainActivity.kt`'s touch-handling, control-layout editor, and rendering
code were read but intentionally not modified — nothing broken was found,
and this code implements the exact visual "outline skin" the brief asked
to preserve unchanged. Audio/render pipeline internals were the subject of
two previous dedicated passes and were only re-read here to confirm this
pass's changes don't interact with them, not re-audited from scratch.
