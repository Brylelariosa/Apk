# FILE_CHANGES — Fifth pass

## Modified

### `app/src/main/kotlin/com/mgba/android/LinkMultiplayer.kt`
**Why:** Dedicated review of the multiplayer/link-cable subsystem, which
hadn't had one yet across the previous four passes.
**What changed:** `@Volatile` added to six connection-state fields; a
`discSocket` field that existed but was never assigned is now actually
used; a `connectGeneration` token and `btPendingSocket` tracking added
across all four connect paths and `disconnect()`; the Wi-Fi `DATA` packet's
`seq` byte is now validated on receive instead of only being populated on
send. See `CHANGELOG.md` items 1–4 for full detail.
**Expected benefit:** More reliable multiplayer connection setup, teardown,
and reconnect handling; a documented-but-previously-nonfunctional packet
check now actually works.

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** General review pass plus fixing the cross-cutting issue where a
native-side ROM swap could silently leave the Kotlin-side link state
inconsistent.
**What changed:** ROM load/change now disconnects an active link session
first; the ROM-load completion callback now checks `isFinishing`/
`isDestroyed`; added `backupIfExists()` and wired it into both the battery
-save and save-state-slot write paths; added an opt-in performance overlay
(state fields, game-loop counter, draw function, and a Misc-settings
checkbox). See `CHANGELOG.md` items 5–8.
**Expected benefit:** Consistent link/ROM state, one fewer lifecycle edge
case, a data-safety net, and an optional diagnostic overlay — all without
any visible change to the existing UI unless the new overlay is explicitly
turned on.

### `app/src/main/AndroidManifest.xml`
**Why:** Two declared permissions were confirmed (via grep across the
whole `kotlin/` tree) to be unused.
**What changed:** Removed `READ_EXTERNAL_STORAGE` and `BLUETOOTH_SCAN`,
each with a comment explaining why.
**Expected benefit:** Smaller permission footprint; no functional change,
since neither was ever checked or relied upon.

### `gradle.properties`
**Why:** `android.enableJetifier` was verified to be dead weight given the
current dependency list.
**What changed:** `android.enableJetifier=true` → `false`, with a comment
explaining the reasoning and when to revert it.
**Expected benefit:** Marginally faster builds.

### `README_SETUP.md`
**Why:** The project's own convention (see its "Fixes applied vs the
original" / "Second/Third/Fourth pass" sections) is to document each
review pass in place.
**What changed:** Appended a "Fifth pass" section following the same
format, plus a note (not a retroactive edit) flagging that the original
table's pthread-linking entry no longer matches the current
`CMakeLists.txt`.
**Expected benefit:** Keeps the project's own change history complete and
consistent for whoever reads it next (including a future review pass).

## Added

- `CHANGELOG.md`, `REVIEW_REPORT.md`, `FILE_CHANGES.md` (this file),
  `FEATURES_ADDED.md`, `BUGS_FIXED.md`, `KNOWN_LIMITATIONS.md` — the
  documentation deliverables for this pass.

## Deleted

None.

## Reviewed and deliberately left unchanged

- **`app/src/main/kotlin/com/mgba/android/EmulatorEngine.kt`** — read in
  full; a clean, minimal JNI facade with no issues found.
- **`app/src/main/cpp/mgba_jni.c`** — read in full (all 731 lines). Every
  entry point already correctly guards `g_core`/`g_fb` behind
  `g_core_mutex` with proper NULL-after-destroy checking, including the
  ROM-swap path. No changes made or needed.
- **`app/src/main/cpp/CMakeLists.txt`** — read in full; the pthread-linking
  decision (intentionally *not* linking `-lpthread`) is correct and already
  well-commented for NDK r18+. No changes made.
- **`app/proguard-rules.pro`** — already correctly protects
  `jniExchangeData` (the one method a native `GetMethodID` lookup depends
  on by exact name) from R8 renaming. No changes needed.
- **`app/build.gradle.kts`, `settings.gradle.kts`,
  `gradle/wrapper/gradle-wrapper.properties`** — reviewed; no functional
  issues found. See `KNOWN_LIMITATIONS.md` for one supply-chain
  recommendation (a pinned wrapper checksum) that wasn't made because this
  sandbox has no network access to fetch the real value.
