# BUGS_FIXED — Fifth pass

- **Fixed a cross-thread visibility gap in the multiplayer link state.**
  `dataSocket`/`peerAddr`/`peerDataPort`/`btSocket`/`btIn`/`btOut` were
  written on a setup thread and read on the native game-loop thread without
  `@Volatile`, so a completed connection could go unnoticed by the thread
  that actually exchanges link data.

- **Fixed discovery-socket cleanup on disconnect.** A `discSocket` field
  existed but nothing ever assigned the live socket to it, so
  `disconnect()`'s cleanup call on it was a silent no-op; backing out of a
  host/join screen mid-search waited out a multi-second timeout instead of
  closing immediately.

- **Fixed a non-functional out-of-order-packet guard.** The Wi-Fi packet
  format's `seq` byte was documented as being for stale/out-of-order
  discard but was never actually checked on receive; a late-arriving stale
  reply could be silently accepted as current data.

- **Fixed stale/abandoned multiplayer connection attempts.** Starting a
  second connection attempt while a first was still mid-handshake (the UI
  never blocked this) could let the abandoned attempt's eventual completion
  clobber the newer one's state or fire a callback for an operation the
  user had already backed out of.

- **Fixed an uncancellable in-progress Bluetooth connection attempt.**
  `connectBluetooth()`'s socket was only tracked in a class field *after*
  `connect()` succeeded, so `disconnect()` had nothing to close to actually
  cancel an attempt in progress (which can otherwise block for 10+ seconds).

- **Fixed a ROM-swap/link-state inconsistency.** Loading or changing a ROM
  while linked left the Kotlin-side state and the link button UI claiming
  "Connected" even after the native SIO driver behind the exchange had
  already been silently dropped by the ROM swap.

- **Fixed a post-teardown resource leak in the ROM-load callback.** A slow
  ROM load whose completion callback ran after the user had already backed
  out of the app (and `onDestroy()` had already run) would re-initialize
  `AudioTrack` and start a new game thread/`Choreographer` registration
  with nothing left to ever clean them up.

- **Removed two unused, dangerous-adjacent permissions.**
  `READ_EXTERNAL_STORAGE` and `BLUETOOTH_SCAN` were declared in the
  manifest but never referenced or relied upon anywhere in the code.
