package com.voxelsandbox.game.gl

import android.opengl.GLES30
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * The water tile: 32x32 pixel art in six blues, one tile per block of water, in the same
 * hand-made style as the block textures. It repeats seamlessly in both directions, so the
 * shader can scroll it freely (see Shaders.WATER_FRAGMENT).
 *
 * The data is a literal (one character per pixel, an index into [PALETTE_R]/[PALETTE_G]/
 * [PALETTE_B]) rather than generated noise, so what you see in game is exactly what was
 * drawn. The alpha channel is 1 on the light "crest" pixels (palette 4 and 5) and 0
 * elsewhere; the shader uses it for the sliding highlights and the shoreline foam, and
 * the mip chain turns it into a coverage value at a distance.
 *
 * Nearest-texel filtering with mip-mapping: crisp square texels up close, the same
 * look and filtering as the terrain atlas.
 */
class WaterTexture {
    private var textureId = 0

    fun upload() {
        val ids = IntArray(1)
        GLES30.glGenTextures(1, ids, 0)
        textureId = ids[0]
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textureId)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_NEAREST_MIPMAP_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_NEAREST)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_REPEAT)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_REPEAT)

        val buf = ByteBuffer.allocateDirect(SIZE * SIZE * 4).order(ByteOrder.nativeOrder())
        for (y in 0 until SIZE) {
            val row = ROWS[y]
            for (x in 0 until SIZE) {
                val index = row[x] - '0'
                buf.put(PALETTE_R[index].toByte())
                buf.put(PALETTE_G[index].toByte())
                buf.put(PALETTE_B[index].toByte())
                buf.put((if (index >= 4) 255 else 0).toByte())
            }
        }
        buf.position(0)
        GLES30.glTexImage2D(
            GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGBA, SIZE, SIZE, 0,
            GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, buf
        )
        GLES30.glGenerateMipmap(GLES30.GL_TEXTURE_2D)
        enableAnisotropy()
    }

    fun bind(unit: Int) {
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0 + unit)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textureId)
    }

    /** A little anisotropy keeps the ripples from smearing over far-off ocean at grazing
     *  angles; skipped silently where the driver does not offer it. */
    private fun enableAnisotropy() {
        try {
            val extensions = GLES30.glGetString(GLES30.GL_EXTENSIONS) ?: return
            if (!extensions.contains("GL_EXT_texture_filter_anisotropic")) return
            val limit = FloatArray(1)
            GLES30.glGetFloatv(GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT, limit, 0)
            if (limit[0] > 1f) {
                GLES30.glTexParameterf(GLES30.GL_TEXTURE_2D, GL_TEXTURE_MAX_ANISOTROPY_EXT, minOf(ANISOTROPY, limit[0]))
            }
        } catch (t: Throwable) {
            // purely cosmetic; ignore
        }
    }

    private companion object {
        const val SIZE = 32
        const val GL_TEXTURE_MAX_ANISOTROPY_EXT = 0x84FE
        const val GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT = 0x84FF
        const val ANISOTROPY = 2f

        val PALETTE_R = intArrayOf(28, 40, 54, 76, 128, 212)
        val PALETTE_G = intArrayOf(66, 94, 116, 144, 184, 236)
        val PALETTE_B = intArrayOf(152, 186, 206, 226, 242, 252)

        val ROWS = arrayOf(
            "44443333211112111212111111111222",
            "33333321110011000111111121222323",
            "52222211000000000001122333322222",
            "11111111011000000012333344422111",
            "00001111111111100123344433320000",
            "00001122222322211234433332150000",
            "00111233333333322444335221000000",
            "01113334444444434422211111100000",
            "11233444453333332221111111111001",
            "12244433333333222110001122221121",
            "23243333222222210000001223223222",
            "43222222221211100000001233333243",
            "22222221111110100000012333444322",
            "11101111111111111001112334443222",
            "10000001111112212122223444432211",
            "00000000011222333223434443352100",
            "00000000011223334343422333221000",
            "10000001112333444323222222111000",
            "11000011225444353222111111110111",
            "22211122344433322111100050001122",
            "32222224433332221111000000011122",
            "53422222211111111511100000112233",
            "34432111000111111211100000122333",
            "44332100000011122322110011223334",
            "43321000000012233333222115234444",
            "33211000000122334444423222224333",
            "32110001111222444444443332222233",
            "22111111252224444433333332111121",
            "21111123222223344333322221000001",
            "12222333442222443333322210000001",
            "23333444432222333332222100000015",
            "33344443322222222232221110000122"
        )
    }
}
