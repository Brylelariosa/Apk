package com.voxelsandbox.game.world

/**
 * Makes water flow. Event driven and deliberately tiny: nothing is simulated until a block
 * changes next to some water (the player digs a channel through a shore, places a water
 * source, covers a source with a block, ...), and only the cells around that change are
 * looked at, a few hundred per tick at 5 ticks a second. Calm oceans and lakes cost
 * nothing at all.
 *
 * The rules (see [Fluid] for how a cell stores its amount):
 *
 *  - A SOURCE (amount 8) never changes. Neighbours draw water from it.
 *  - Any other cell that is free (air, a plant, or flowing water) works out what it
 *    should hold from its neighbours and changes to that:
 *      - water directly above it feeds it fully (7): water falls straight down;
 *      - otherwise it holds one less than its fullest side neighbour, which a source
 *        counts as 8, so water runs 7 blocks from a source across flat ground and each
 *        step is one level lower;
 *      - with nothing feeding it, it dries up, so channels drain when their source is
 *        covered or removed.
 *  - Water that can still fall (the cell below is free and not a full source) does not
 *    spread sideways, so a stream pours over an edge instead of also leaking along the
 *    top. When it lands on something solid it spreads at full strength.
 *
 * "Pull" rather than "push": each cell asks its neighbours what it should be, and a cell
 * that changes re-queues its six neighbours. That one rule produces spreading, falling and
 * draining, and cannot run away: levels only ever drop by one per step away from a source.
 *
 * Changed cells are reported to [WorldManager] (so their chunks remesh at normal priority,
 * batched once per tick) and written through [World.setRaw] (so chunks that gained water
 * are saved). Everything here runs on the game thread. Water never flows into a chunk that
 * is not loaded.
 */
class FluidSimulator(private val world: World, private val manager: WorldManager) {
    /** Cells waiting to be re-evaluated, oldest first. A set, so a cell queued twice runs once. */
    private val pending = LinkedHashSet<Long>()
    private val batch = LongArray(MAX_UPDATES_PER_TICK)
    private var clock = 0f

    /** Call after any block at (x, y, z) was changed (placed, broken, ...). Does nothing
     *  unless there is water in or next to that cell. */
    fun onBlockChanged(x: Int, y: Int, z: Int) {
        if (!waterAmong(x, y, z)) return
        schedule(x, y, z)
        schedule(x + 1, y, z)
        schedule(x - 1, y, z)
        schedule(x, y, z + 1)
        schedule(x, y, z - 1)
        schedule(x, y + 1, z)
        schedule(x, y - 1, z)
    }

    /** Call once per frame. Runs a tick every [TICK_SECONDS] while there is work. */
    fun update(dt: Float) {
        if (pending.isEmpty()) {
            clock = 0f
            return
        }
        clock += dt
        if (clock < TICK_SECONDS) return
        clock = 0f
        runTick()
    }

    private fun runTick() {
        var count = 0
        val iter = pending.iterator()
        while (iter.hasNext() && count < MAX_UPDATES_PER_TICK) {
            batch[count] = iter.next()
            count++
            iter.remove()
        }
        for (i in 0 until count) {
            val key = batch[i]
            updateCell(unpackX(key), unpackY(key), unpackZ(key))
        }
        manager.flushBatchedEdits(FLUID_MESH_PRIORITY)
    }

    private fun updateCell(x: Int, y: Int, z: Int) {
        val raw = world.getRaw(x, y, z)
        val current = Fluid.amountOf(raw)
        if (current == Fluid.SOURCE) return
        // Solid blocks hold no water. (Air, plants and flowing water can.)
        if (current == 0 && !BlockType.fromId(raw.toByte()).replaceable) return

        val target = targetAmount(x, y, z)
        if (target == current) return

        val newRaw = if (target == 0) 0 else Fluid.rawFor(target)
        if (!world.setRaw(x, y, z, newRaw)) return
        manager.noteBlockChanged(x, y, z)
        schedule(x + 1, y, z)
        schedule(x - 1, y, z)
        schedule(x, y, z + 1)
        schedule(x, y, z - 1)
        schedule(x, y + 1, z)
        schedule(x, y - 1, z)
    }

    /** How much water the free cell (x, y, z) should hold, 0..7, judging by its neighbours. */
    private fun targetAmount(x: Int, y: Int, z: Int): Int {
        if (Fluid.amountOf(world.getRaw(x, y + 1, z)) > 0) return 7
        var best = sideSupply(x + 1, y, z)
        val b = sideSupply(x - 1, y, z)
        if (b > best) best = b
        val c = sideSupply(x, y, z + 1)
        if (c > best) best = c
        val d = sideSupply(x, y, z - 1)
        if (d > best) best = d
        return best
    }

    /** What the cell (nx, y, nz) pushes sideways into the free cell next to it: its own
     *  amount minus one, or 0 if it holds no water or can still fall. */
    private fun sideSupply(nx: Int, y: Int, nz: Int): Int {
        var amount = Fluid.amountOf(world.getRaw(nx, y, nz))
        if (amount == 0) return 0
        if (canFall(nx, y, nz)) return 0
        // A stream that is falling into this cell counts as full once it has landed.
        if (amount != Fluid.SOURCE && Fluid.amountOf(world.getRaw(nx, y + 1, nz)) > 0) amount = Fluid.SOURCE
        return amount - 1
    }

    /** True if water in (x, y, z) would drop: the cell under it is free and not already a
     *  full source block. */
    private fun canFall(x: Int, y: Int, z: Int): Boolean {
        if (y <= 0) return false
        val below = world.getRaw(x, y - 1, z)
        if (Fluid.amountOf(below) == Fluid.SOURCE) return false
        return BlockType.fromId(below.toByte()).replaceable
    }

    private fun waterAmong(x: Int, y: Int, z: Int): Boolean =
        Fluid.amountOf(world.getRaw(x, y, z)) > 0 ||
            Fluid.amountOf(world.getRaw(x + 1, y, z)) > 0 ||
            Fluid.amountOf(world.getRaw(x - 1, y, z)) > 0 ||
            Fluid.amountOf(world.getRaw(x, y, z + 1)) > 0 ||
            Fluid.amountOf(world.getRaw(x, y, z - 1)) > 0 ||
            Fluid.amountOf(world.getRaw(x, y + 1, z)) > 0 ||
            Fluid.amountOf(world.getRaw(x, y - 1, z)) > 0

    private fun schedule(x: Int, y: Int, z: Int) {
        if (y < 0 || y >= WorldConfig.WORLD_HEIGHT) return
        if (pending.size >= MAX_PENDING) return
        pending.add(pack(x, y, z))
    }

    // x and z each get 26 bits (about +-33 million blocks), y gets 12.
    private fun pack(x: Int, y: Int, z: Int): Long =
        ((x.toLong() and COORD_MASK) shl 38) or ((z.toLong() and COORD_MASK) shl 12) or (y.toLong() and 0xFFFL)

    private fun unpackX(key: Long): Int = ((key ushr 38).toInt() shl 6) shr 6

    private fun unpackZ(key: Long): Int = (((key ushr 12) and COORD_MASK).toInt() shl 6) shr 6

    private fun unpackY(key: Long): Int = (key and 0xFFFL).toInt()

    private companion object {
        /** Water spreads one block per tick: 5 blocks a second. */
        const val TICK_SECONDS = 0.2f

        /** Cells re-evaluated per tick. A big breach drains into a backlog that is worked
         *  off over a few seconds instead of in one long frame. */
        const val MAX_UPDATES_PER_TICK = 256

        /** Hard cap on queued cells (memory guard for a huge flood). */
        const val MAX_PENDING = 40000

        /** Remesh priority for flow changes: ahead of chunk streaming (priorities are
         *  squared distances, 0 at the player) but not "urgent", so they are batched. */
        const val FLUID_MESH_PRIORITY = 0L

        const val COORD_MASK = 0x3FFFFFFL
    }
}
