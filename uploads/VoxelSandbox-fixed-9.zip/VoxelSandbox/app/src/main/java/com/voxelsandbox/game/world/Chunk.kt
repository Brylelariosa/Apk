package com.voxelsandbox.game.world

import com.voxelsandbox.game.world.WorldConfig.SUBCHUNKS_PER_CHUNK
import com.voxelsandbox.game.world.WorldConfig.SUBCHUNK_HEIGHT

class Chunk(val pos: ChunkPos) {
    val subChunks: Array<SubChunk> = Array(SUBCHUNKS_PER_CHUNK) { SubChunk() }

    /** Set once, when a player edit first touches this chunk. Only chunks in this
     *  state are written to the save file (everything else regenerates from seed). */
    @Volatile
    var hasPlayerEdits: Boolean = false

    fun getBlock(lx: Int, y: Int, lz: Int): BlockType {
        if (y < 0 || y >= WorldConfig.WORLD_HEIGHT) return BlockType.AIR
        val sub = y / SUBCHUNK_HEIGHT
        val ly = y % SUBCHUNK_HEIGHT
        return subChunks[sub].getBlock(lx, ly, lz)
    }

    fun setBlock(lx: Int, y: Int, lz: Int, type: BlockType) {
        if (y < 0 || y >= WorldConfig.WORLD_HEIGHT) return
        val sub = y / SUBCHUNK_HEIGHT
        val ly = y % SUBCHUNK_HEIGHT
        subChunks[sub].setBlock(lx, ly, lz, type)
    }

    /** The whole block byte (id plus water fill bits), 0 outside the world. */
    fun getRaw(lx: Int, y: Int, lz: Int): Int {
        if (y < 0 || y >= WorldConfig.WORLD_HEIGHT) return 0
        return subChunks[y / SUBCHUNK_HEIGHT].getRaw(lx, y % SUBCHUNK_HEIGHT, lz)
    }

    fun setRaw(lx: Int, y: Int, lz: Int, raw: Int) {
        if (y < 0 || y >= WorldConfig.WORLD_HEIGHT) return
        subChunks[y / SUBCHUNK_HEIGHT].setRaw(lx, y % SUBCHUNK_HEIGHT, lz, raw)
    }

    /** Concatenates all subchunk block arrays into one buffer for saving. */
    fun serializeBlocks(): ByteArray {
        val out = ByteArray(WorldConfig.BYTES_PER_CHUNK)
        var offset = 0
        for (sub in subChunks) {
            System.arraycopy(sub.blocks, 0, out, offset, WorldConfig.BLOCKS_PER_SUBCHUNK)
            offset += WorldConfig.BLOCKS_PER_SUBCHUNK
        }
        return out
    }

    fun deserializeBlocks(data: ByteArray) {
        require(data.size == WorldConfig.BYTES_PER_CHUNK) { "Bad chunk block array size" }
        var offset = 0
        for (sub in subChunks) {
            sub.fill(data.copyOfRange(offset, offset + WorldConfig.BLOCKS_PER_SUBCHUNK))
            offset += WorldConfig.BLOCKS_PER_SUBCHUNK
        }
    }
}
