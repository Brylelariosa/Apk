package com.voxelsandbox.game.gl

import android.opengl.GLES30

/**
 * One of the programs that draw voxel-chunk geometry. They all share one vertex format and
 * the same uniforms (view-projection, atlas texture, fog, the rim dissolve), and differ
 * only in their fragment shader (see [Shaders]): opaque, opaque with dissolve, alpha-tested.
 *
 * A uniform the chosen fragment shader does not use has location -1, and GL silently
 * ignores uploads to it, so [use] can set all of them for every variant.
 */
class TerrainProgram(vertexSource: String, fragmentSource: String) {
    private val program = ShaderProgram(vertexSource, fragmentSource)
    private val uViewProj = program.uniform("uViewProj")
    private val uTexture = program.uniform("uTexture")
    private val uFogColor = program.uniform("uFogColor")
    private val uFogStart = program.uniform("uFogStart")
    private val uFogEnd = program.uniform("uFogEnd")
    private val uAlpha = program.uniform("uAlpha")
    private val uFade = program.uniform("uFade")

    /**
     * Makes this the current program and uploads this frame's shared values. With [fade] the
     * voxel-area rim dissolve is switched on (centre, start radius and width come from
     * [frame]); without it the dissolve width is 0, which the shaders read as "off".
     * The atlas must be bound to texture unit 0.
     */
    fun use(viewProj: FloatArray, frame: FrameState, fade: Boolean) {
        program.use()
        GLES30.glUniformMatrix4fv(uViewProj, 1, false, viewProj, 0)
        GLES30.glUniform3f(uFogColor, frame.fogR, frame.fogG, frame.fogB)
        GLES30.glUniform1f(uFogStart, frame.fogStart)
        GLES30.glUniform1f(uFogEnd, frame.fogEnd)
        GLES30.glUniform1i(uTexture, 0)
        GLES30.glUniform1f(uAlpha, 1f)
        if (fade) {
            GLES30.glUniform4f(uFade, frame.coverX, frame.coverZ, frame.fadeStart, frame.fadeWidth)
        } else {
            GLES30.glUniform4f(uFade, 0f, 0f, 0f, 0f)
        }
    }
}
