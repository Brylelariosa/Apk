package com.voxelsandbox.game.world.mesh

import com.voxelsandbox.game.gl.TextureAtlas
import com.voxelsandbox.game.world.BlockType
import com.voxelsandbox.game.world.Chunk
import com.voxelsandbox.game.world.ChunkPos
import com.voxelsandbox.game.world.Face
import com.voxelsandbox.game.world.Fluid
import com.voxelsandbox.game.world.World
import com.voxelsandbox.game.world.WorldConfig
import kotlin.math.sqrt

class MeshData(
    val vertexData: FloatArray,
    val indices: IntArray,
    val vertexCount: Int,
    /** Lowest / highest world-space Y of any vertex. Lets the renderer build a tight
     *  frustum-culling box per column instead of always testing the full world height. */
    val minY: Float = 0f,
    val maxY: Float = 0f,
    /** The triangle indices come in three consecutive groups so the renderer can draw each
     *  with the GPU state it needs (see GameRenderer.drawChunks):
     *   - [0, opaqueEnd): opaque cubes (drawn by a shader with no `discard`),
     *   - [opaqueEnd, cutoutEnd): alpha-tested foliage cubes (leaves),
     *   - [cutoutEnd, indices.size): double-sided decoration (plants, lily pads), drawn
     *     with back-face culling off so each needs one quad per plane instead of two.
     *  A mesh that is not split (water, distant terrain, overlays) is all "opaque", which is
     *  what both defaults mean. */
    val opaqueEnd: Int = indices.size,
    val cutoutEnd: Int = indices.size
) {
    fun isEmpty(): Boolean = vertexCount == 0

    companion object {
        val EMPTY = MeshData(FloatArray(0), IntArray(0), 0)

        /** Floats per vertex in [vertexData]: position(3) + uv(2) + shade(1). Public
         *  (unlike MeshBuilder's private copy of the same number) so GameRenderer can
         *  correctly concatenate multiple subchunks' MeshData into one combined
         *  per-column buffer without duplicating/guessing the stride. */
        const val FLOATS_PER_VERTEX = 6
    }
}

/** The two layers one subchunk is drawn in: opaque / alpha-cut terrain, and the
 *  translucent water surface (drawn afterwards by its own animated shader). */
class SubChunkMesh(val solid: MeshData, val water: MeshData) {
    fun isEmpty(): Boolean = solid.isEmpty() && water.isEmpty()

    companion object {
        val EMPTY = SubChunkMesh(MeshData.EMPTY, MeshData.EMPTY)
    }
}

/** Interleaved vertex layout: position(3) + uv(2) + shade(1) = 6 floats/vertex. Kept
 *  private to this file — nothing outside the mesher needs to know the layout details,
 *  only the resulting MeshData.
 *
 *  One builder is kept per mesh-worker thread and reset between jobs (see
 *  ChunkMesher.builders): its arrays only ever grow to the high-water mark of the
 *  biggest subchunk that thread has meshed, instead of every job re-growing fresh
 *  arrays from 128 vertices by repeated doubling (~3x the final size in garbage).
 *
 *  Triangle indices are collected in three groups (opaque / cutout / double-sided, see
 *  [MeshData.opaqueEnd]) and joined, in that order, by [build]. */
private class MeshBuilder(initialVerts: Int = 1024) {
    companion object {
        const val FLOATS_PER_VERTEX = 6
        const val GROUP_OPAQUE = 0
        const val GROUP_CUTOUT = 1
        const val GROUP_DOUBLE = 2
    }

    private var floats = FloatArray(initialVerts * FLOATS_PER_VERTEX)
    private var idxOpaque = IntArray(initialVerts * 3 / 2)
    private var idxCutout = IntArray(64)
    private var idxDouble = IntArray(64)
    private var nOpaque = 0
    private var nCutout = 0
    private var nDouble = 0
    private var vertCount = 0
    private var minY = Float.MAX_VALUE
    private var maxY = -Float.MAX_VALUE

    fun reset() {
        vertCount = 0
        nOpaque = 0
        nCutout = 0
        nDouble = 0
        minY = Float.MAX_VALUE
        maxY = -Float.MAX_VALUE
    }

    /** Emits one quad (4 vertices, 2 triangles). Vertices are v0..v3 in the order given;
     *  uv rect corners map to them as v0=(u0,va) v1=(u1,va) v2=(u1,vb) v3=(u0,vb), so a
     *  caller passes va/vb swapped to flip a texture vertically.
     *
     *  [flip] reverses the triangle winding without touching vertex positions or UVs,
     *  which is how TOP/BOTTOM faces get the same counter-clockwise-from-outside winding
     *  the four side faces are already authored with (see ChunkMesher) so back-face
     *  culling can be on. [altDiagonal] splits the quad along v1-v3 instead of v0-v2;
     *  the mesher picks whichever diagonal passes through the darker corners so ambient-
     *  occlusion gradients don't turn into visible triangle seams. [group] picks which
     *  index group the two triangles go to (GROUP_*). */
    fun quad(
        x0: Float, y0: Float, z0: Float,
        x1: Float, y1: Float, z1: Float,
        x2: Float, y2: Float, z2: Float,
        x3: Float, y3: Float, z3: Float,
        u0: Float, va: Float, u1: Float, vb: Float,
        s0: Float, s1: Float, s2: Float, s3: Float,
        flip: Boolean,
        altDiagonal: Boolean,
        group: Int = GROUP_OPAQUE
    ) {
        reserve()
        val f = floats
        var i = vertCount * FLOATS_PER_VERTEX
        f[i++] = x0; f[i++] = y0; f[i++] = z0; f[i++] = u0; f[i++] = va; f[i++] = s0
        f[i++] = x1; f[i++] = y1; f[i++] = z1; f[i++] = u1; f[i++] = va; f[i++] = s1
        f[i++] = x2; f[i++] = y2; f[i++] = z2; f[i++] = u1; f[i++] = vb; f[i++] = s2
        f[i++] = x3; f[i++] = y3; f[i++] = z3; f[i++] = u0; f[i++] = vb; f[i] = s3
        finishQuad(y0, y1, y2, y3, flip, altDiagonal, group)
    }

    /** Emits one water-surface quad (an upward-facing TOP face, so wound like one). Water
     *  has no texture: the three "uv"/shade slots of each vertex carry the water depth
     *  below it in blocks (the shader turns it into tint and opacity) and the flow vector
     *  of the cell (x, z; length 0 = still, 1 = fast), which makes the water texture slide
     *  the way the water runs. */
    fun waterTop(
        x0: Float, y0: Float, z0: Float, d0: Float,
        x1: Float, y1: Float, z1: Float, d1: Float,
        x2: Float, y2: Float, z2: Float, d2: Float,
        x3: Float, y3: Float, z3: Float, d3: Float,
        flowX: Float, flowZ: Float,
        altDiagonal: Boolean
    ) {
        reserve()
        val f = floats
        var i = vertCount * FLOATS_PER_VERTEX
        f[i++] = x0; f[i++] = y0; f[i++] = z0; f[i++] = d0; f[i++] = flowX; f[i++] = flowZ
        f[i++] = x1; f[i++] = y1; f[i++] = z1; f[i++] = d1; f[i++] = flowX; f[i++] = flowZ
        f[i++] = x2; f[i++] = y2; f[i++] = z2; f[i++] = d2; f[i++] = flowX; f[i++] = flowZ
        f[i++] = x3; f[i++] = y3; f[i++] = z3; f[i++] = d3; f[i++] = flowX; f[i] = flowZ
        finishQuad(y0, y1, y2, y3, true, altDiagonal, GROUP_OPAQUE)
    }

    /** Emits one vertical side face of a water cell (wound like a terrain side face: the
     *  first two vertices are the bottom edge). The depth slot is -1, which the water
     *  shader reads as "this is a side face: texture it vertically and let it run down". */
    fun waterSide(
        x0: Float, y0: Float, z0: Float,
        x1: Float, y1: Float, z1: Float,
        x2: Float, y2: Float, z2: Float,
        x3: Float, y3: Float, z3: Float
    ) {
        reserve()
        val f = floats
        var i = vertCount * FLOATS_PER_VERTEX
        f[i++] = x0; f[i++] = y0; f[i++] = z0; f[i++] = -1f; f[i++] = 0f; f[i++] = 0f
        f[i++] = x1; f[i++] = y1; f[i++] = z1; f[i++] = -1f; f[i++] = 0f; f[i++] = 0f
        f[i++] = x2; f[i++] = y2; f[i++] = z2; f[i++] = -1f; f[i++] = 0f; f[i++] = 0f
        f[i++] = x3; f[i++] = y3; f[i++] = z3; f[i++] = -1f; f[i++] = 0f; f[i] = 0f
        finishQuad(y0, y1, y2, y3, false, false, GROUP_OPAQUE)
    }

    private fun reserve() {
        val neededFloats = (vertCount + 4) * FLOATS_PER_VERTEX
        if (neededFloats > floats.size) floats = floats.copyOf(maxOf(floats.size * 2, neededFloats))
    }

    /** Writes the two triangles for the 4 vertices just stored (into the index group
     *  [group]) and updates the Y bounds. */
    private fun finishQuad(y0: Float, y1: Float, y2: Float, y3: Float, flip: Boolean, altDiagonal: Boolean, group: Int) {
        val lo = minOf(minOf(y0, y1), minOf(y2, y3))
        val hi = maxOf(maxOf(y0, y1), maxOf(y2, y3))
        if (lo < minY) minY = lo
        if (hi > maxY) maxY = hi

        val b = vertCount
        when (group) {
            GROUP_CUTOUT -> {
                if (nCutout + 6 > idxCutout.size) idxCutout = idxCutout.copyOf(maxOf(idxCutout.size * 2, nCutout + 6))
                nCutout = writeIndices(idxCutout, nCutout, b, flip, altDiagonal)
            }
            GROUP_DOUBLE -> {
                if (nDouble + 6 > idxDouble.size) idxDouble = idxDouble.copyOf(maxOf(idxDouble.size * 2, nDouble + 6))
                nDouble = writeIndices(idxDouble, nDouble, b, flip, altDiagonal)
            }
            else -> {
                if (nOpaque + 6 > idxOpaque.size) idxOpaque = idxOpaque.copyOf(maxOf(idxOpaque.size * 2, nOpaque + 6))
                nOpaque = writeIndices(idxOpaque, nOpaque, b, flip, altDiagonal)
            }
        }
        vertCount += 4
    }

    /** The six indices of one quad starting at vertex [b]; returns the new fill position. */
    private fun writeIndices(ix: IntArray, start: Int, b: Int, flip: Boolean, altDiagonal: Boolean): Int {
        var k = start
        if (!altDiagonal) {
            if (flip) {
                ix[k++] = b; ix[k++] = b + 2; ix[k++] = b + 1
                ix[k++] = b; ix[k++] = b + 3; ix[k++] = b + 2
            } else {
                ix[k++] = b; ix[k++] = b + 1; ix[k++] = b + 2
                ix[k++] = b; ix[k++] = b + 2; ix[k++] = b + 3
            }
        } else {
            if (flip) {
                ix[k++] = b + 1; ix[k++] = b + 3; ix[k++] = b + 2
                ix[k++] = b + 1; ix[k++] = b; ix[k++] = b + 3
            } else {
                ix[k++] = b + 1; ix[k++] = b + 2; ix[k++] = b + 3
                ix[k++] = b + 1; ix[k++] = b + 3; ix[k++] = b
            }
        }
        return k
    }

    fun build(): MeshData {
        if (vertCount == 0) return MeshData.EMPTY
        val all = IntArray(nOpaque + nCutout + nDouble)
        System.arraycopy(idxOpaque, 0, all, 0, nOpaque)
        System.arraycopy(idxCutout, 0, all, nOpaque, nCutout)
        System.arraycopy(idxDouble, 0, all, nOpaque + nCutout, nDouble)
        return MeshData(
            floats.copyOf(vertCount * FLOATS_PER_VERTEX),
            all,
            vertCount,
            minY,
            maxY,
            nOpaque,
            nOpaque + nCutout
        )
    }
}

/** One solid + one water builder per mesh-worker thread. */
private class BuilderPair {
    val solid = MeshBuilder()
    val water = MeshBuilder(256)
}

/**
 * Builds one mesh per subchunk using face culling: a face is emitted only when the
 * neighboring cell is non-opaque. A neighbour in a chunk that has not been generated yet
 * counts as SOLID for this (see [outsideBlockAt]): the outer rim of the loaded area gets
 * no cliff-like wall facing the unknown (that was a large share of all triangles, and an
 * ugly textured edge in front of the distant terrain), and when the neighbour does load
 * both sides remesh and every face that is really exposed appears.
 *
 * Faces that can never be seen are not emitted at all:
 *  - water: meshed into its own translucent layer (see emitWater): the surface at the
 *    height the cell's fill level says, plus side faces only where water borders open
 *    air (waterfalls, the edge of a stream). Sides and bottoms of a lake or ocean, which
 *    border terrain, are never drawn;
 *  - foliage against foliage (leaf textures are alpha-cut, but the inside of a canopy
 *    is never worth its triangles);
 *  - the bottom faces of the world floor (y = 0), which no legal camera position can
 *    ever see (that alone was ~30% of a typical chunk's geometry).
 * All-air subchunks return immediately without scanning their 4096 cells.
 *
 * Lighting is baked into the per-vertex shade: a fixed brightness per face direction,
 * classic "smooth lighting" ambient occlusion at every corner (so creases, tree bases
 * and cliff feet get soft contact shadows), and a very small per-block brightness
 * variation that breaks up the visible tiling of large flat areas.
 *
 * Winding: the four side faces are authored counter-clockwise as seen from outside;
 * TOP and BOTTOM were authored clockwise, so they are emitted with flip = true. That
 * makes every face front-facing from outside, which lets GameRenderer enable back-face
 * culling.
 */
object ChunkMesher {
    private val builders = object : ThreadLocal<BuilderPair>() {
        override fun initialValue(): BuilderPair = BuilderPair()
    }

    private const val SIZE = WorldConfig.CHUNK_SIZE
    private const val SUB_H = WorldConfig.SUBCHUNK_HEIGHT

    /** Corner brightness for ambient-occlusion level 0 (fully boxed in) .. 3 (open). */
    private val AO_SHADE = floatArrayOf(0.58f, 0.72f, 0.86f, 1.0f)

    /** Opacity by block id, so the hot loops read one boolean instead of going through
     *  the enum (ids are masked to the table size, see BlockType.TABLE_SIZE). */
    private val OPAQUE: BooleanArray = BlockType.OPAQUE_BY_ID
    private const val ID_MASK = BlockType.TABLE_SIZE - 1

    /** Solidity by block id (leaves count; plants and water do not). */
    private val SOLID: BooleanArray = BlockType.SOLID_BY_ID

    /** What a cell in a chunk that is not generated yet reads as when the mesher decides
     *  which faces (and water sides) to draw: stone, i.e. solid and opaque. */
    private val UNLOADED_RAW: Int = BlockType.STONE.id.toInt()

    /** Horizontal neighbour offsets for NORTH, SOUTH, EAST, WEST: face index 2 + n in
     *  FACE_VERTS. */
    private val SIDE_DX = intArrayOf(0, 0, 1, -1)
    private val SIDE_DZ = intArrayOf(-1, 1, 0, 0)

    /** For the flow vector: indices into SubMeshJob.nb of the west, east, north and south
     *  neighbours, and the direction each lies in. */
    private val FLOW_IDX = intArrayOf(3, 5, 1, 7)
    private val FLOW_DX = floatArrayOf(-1f, 1f, 0f, 0f)
    private val FLOW_DZ = floatArrayOf(0f, 0f, -1f, 1f)

    /** The four 3x3-neighbourhood indices that surround a corner, relative to the first. */
    private val CORNER_STEP = intArrayOf(0, 1, 3, 4)

    /** Water deeper than this reads as "deep" in the shader, so there is no point counting
     *  further down. */
    private const val WATER_DEPTH_CAP = 10

    /** Vertex offsets (x, y, z for v0..v3) of each face's quad, in Face enum order
     *  (TOP, BOTTOM, NORTH, SOUTH, EAST, WEST). Must match the winding the quads were
     *  authored with — see MeshBuilder.quad. */
    private val FACE_VERTS: Array<IntArray> = arrayOf(
        intArrayOf(0, 1, 0, 1, 1, 0, 1, 1, 1, 0, 1, 1), // TOP
        intArrayOf(0, 0, 1, 1, 0, 1, 1, 0, 0, 0, 0, 0), // BOTTOM
        intArrayOf(1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 0), // NORTH
        intArrayOf(0, 0, 1, 1, 0, 1, 1, 1, 1, 0, 1, 1), // SOUTH
        intArrayOf(1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 1, 1), // EAST
        intArrayOf(0, 0, 0, 0, 0, 1, 0, 1, 1, 0, 1, 0)  // WEST
    )

    /** For every face and each of its four vertices: the three cells (side 1, side 2,
     *  corner) that can shadow that vertex, as dx,dy,dz triples relative to the cell in
     *  FRONT of the face. 6 faces * 4 vertices * 9 ints. Derived from FACE_VERTS so the
     *  two can never disagree. */
    private val AO_CELLS: IntArray = buildAoCells()

    private fun buildAoCells(): IntArray {
        val out = IntArray(6 * 4 * 9)
        for (face in Face.ALL) {
            val fv = FACE_VERTS[face.ordinal]
            for (k in 0 until 4) {
                // Sign of each in-plane axis for this vertex; the face-normal axis stays 0.
                val sx = if (face.dx != 0) 0 else if (fv[k * 3] == 1) 1 else -1
                val sy = if (face.dy != 0) 0 else if (fv[k * 3 + 1] == 1) 1 else -1
                val sz = if (face.dz != 0) 0 else if (fv[k * 3 + 2] == 1) 1 else -1
                var ax = 0
                var ay = 0
                var az = 0
                var bx = 0
                var by = 0
                var bz = 0
                var haveFirst = false
                if (sx != 0) {
                    ax = sx
                    haveFirst = true
                }
                if (sy != 0) {
                    if (haveFirst) {
                        by = sy
                    } else {
                        ay = sy
                        haveFirst = true
                    }
                }
                if (sz != 0) {
                    if (haveFirst) {
                        bz = sz
                    } else {
                        az = sz
                    }
                }
                val base = (face.ordinal * 4 + k) * 9
                out[base] = ax; out[base + 1] = ay; out[base + 2] = az
                out[base + 3] = bx; out[base + 4] = by; out[base + 5] = bz
                out[base + 6] = ax + bx; out[base + 7] = ay + by; out[base + 8] = az + bz
            }
        }
        return out
    }

    /** Everything one subchunk mesh needs to look up cells around itself. */
    private class SubMeshJob(
        val world: World,
        val chunk: Chunk,
        val blocks: ByteArray,
        val baseX: Int,
        val baseY: Int,
        val baseZ: Int
    ) {
        /** Is the cell at subchunk-local (lx, ly, lz) opaque? Coordinates may fall up to a
         *  cell outside the subchunk; the in-array case (the vast majority) is a plain
         *  array read, everything else goes through chunk / world lookups. */
        fun opaqueAt(lx: Int, ly: Int, lz: Int): Boolean {
            val size = WorldConfig.CHUNK_SIZE
            if (lx >= 0 && lx < size && lz >= 0 && lz < size && ly >= 0 && ly < WorldConfig.SUBCHUNK_HEIGHT) {
                return ChunkMesher.OPAQUE[blocks[(ly * size + lz) * size + lx].toInt() and ChunkMesher.ID_MASK]
            }
            val wy = baseY + ly
            if (wy < 0 || wy >= WorldConfig.WORLD_HEIGHT) return false
            return if (lx >= 0 && lx < size && lz >= 0 && lz < size) {
                chunk.getBlock(lx, wy, lz).opaque
            } else {
                world.getBlock(baseX + lx, wy, baseZ + lz).opaque
            }
        }

        /** Block at subchunk-local x/z and absolute world height [wy] (the cell may lie in
         *  another subchunk or, at the rim, in a neighbouring chunk). */
        fun blockAtWorldY(lx: Int, wy: Int, lz: Int): BlockType {
            val size = WorldConfig.CHUNK_SIZE
            return if (lx >= 0 && lx < size && lz >= 0 && lz < size) {
                chunk.getBlock(lx, wy, lz)
            } else {
                world.getBlock(baseX + lx, wy, baseZ + lz)
            }
        }

        // ---- scratch for water meshing (one job = one subchunk on one thread) ----

        /** Raw block bytes of the 3x3 columns around the water cell being meshed, at its own
         *  level ([nb]) and one level up ([nbUp]); index (dz + 1) * 3 + (dx + 1). */
        val nb = IntArray(9)
        val nbUp = IntArray(9)

        /** Water depth (blocks) of those same nine columns. */
        val depth = IntArray(9)

        /** Flow vector of the cell last passed to ChunkMesher.computeFlow. */
        var flowX = 0f
        var flowZ = 0f

        /** The whole block byte (id plus water fill bits) at subchunk-local x/z and world
         *  height [wy]. A cell in a chunk that is not generated yet reads as stone. */
        fun rawAt(lx: Int, wy: Int, lz: Int): Int {
            if (wy < 0 || wy >= WorldConfig.WORLD_HEIGHT) return 0
            val size = WorldConfig.CHUNK_SIZE
            if (lx >= 0 && lx < size && lz >= 0 && lz < size) return chunk.getRaw(lx, wy, lz)
            val wx = baseX + lx
            val wz = baseZ + lz
            if (!world.isChunkLoadedAt(wx, wz)) return ChunkMesher.UNLOADED_RAW
            return world.getRaw(wx, wy, wz)
        }

        fun loadNeighborhood(lx: Int, wy: Int, lz: Int) {
            for (dz in -1..1) {
                for (dx in -1..1) {
                    val i = (dz + 1) * 3 + (dx + 1)
                    nb[i] = rawAt(lx + dx, wy, lz + dz)
                    nbUp[i] = rawAt(lx + dx, wy + 1, lz + dz)
                }
            }
        }
    }

    fun buildSubChunkMesh(world: World, chunkX: Int, chunkZ: Int, subY: Int, atlas: TextureAtlas): SubChunkMesh {
        // The caller (WorldManager's mesh worker) already confirmed this chunk is
        // GENERATED and loaded before enqueueing the job; getChunk returning null
        // here would only mean it was unloaded in the tiny window since then, in
        // which case there's nothing left to mesh.
        val chunk = world.getChunk(ChunkPos(chunkX, chunkZ)) ?: return SubChunkMesh.EMPTY
        if (subY < 0 || subY >= WorldConfig.SUBCHUNKS_PER_CHUNK) return SubChunkMesh.EMPTY

        val sub = chunk.subChunks[subY]
        if (sub.isAllAir()) return SubChunkMesh.EMPTY
        val blocks = sub.blocks

        val pair = builders.get()
        val builder = pair.solid
        val waterBuilder = pair.water
        builder.reset()
        waterBuilder.reset()

        val baseX = chunkX * SIZE
        val baseZ = chunkZ * SIZE
        val baseY = subY * SUB_H
        val job = SubMeshJob(world, chunk, blocks, baseX, baseY, baseZ)

        for (ly in 0 until SUB_H) {
            val wy = baseY + ly
            for (lz in 0 until SIZE) {
                for (lx in 0 until SIZE) {
                    val block = BlockType.fromId(blocks[(ly * SIZE + lz) * SIZE + lx])
                    if (block == BlockType.AIR) continue

                    val wx = baseX + lx
                    val wz = baseZ + lz

                    if (block == BlockType.WATER) {
                        val raw = blocks[(ly * SIZE + lz) * SIZE + lx].toInt() and 0xFF
                        emitWater(waterBuilder, job, lx, lz, wx, wy, wz, raw)
                        continue
                    }
                    if (block.flat) {
                        emitLilyPad(builder, atlas, block, wx, wy, wz)
                        continue
                    }
                    if (block.plant) {
                        emitPlant(builder, atlas, block, wx, wy, wz)
                        continue
                    }

                    for (face in Face.ALL) {
                        val wny = wy + face.dy
                        if (wny < 0) continue // below the world floor: never visible

                        val nx = lx + face.dx
                        val ny = ly + face.dy
                        val nz = lz + face.dz
                        // Neighbors inside this same subchunk (the overwhelming majority)
                        // are read straight from the local array; only the one-cell rim
                        // falls back to chunk/world lookups.
                        val neighbor = if (nx >= 0 && nx < SIZE && nz >= 0 && nz < SIZE && ny >= 0 && ny < SUB_H) {
                            BlockType.fromId(blocks[(ny * SIZE + nz) * SIZE + nx])
                        } else {
                            outsideBlockAt(world, chunk, baseX, baseZ, nx, wny, nz)
                        }
                        if (neighbor.opaque) continue
                        if (block.cutout && neighbor.cutout) continue
                        emitFace(builder, job, atlas, block, face, lx, ly, lz, wx, wy, wz)
                    }
                }
            }
        }
        return SubChunkMesh(builder.build(), waterBuilder.build())
    }

    /** Neighbor lookup for face culling, for cells that fall outside this subchunk's own
     *  array: still inside this chunk (another subchunk) -> this chunk's own arrays; across
     *  the chunk edge -> World. A chunk that is not generated yet reads as STONE here
     *  (World itself reads it as air): the face towards the unknown is not drawn. Ambient
     *  occlusion keeps treating it as open air (SubMeshJob.opaqueAt), so the rim does not
     *  get a dark edge. */
    private fun outsideBlockAt(world: World, chunk: Chunk, baseX: Int, baseZ: Int, lx: Int, y: Int, lz: Int): BlockType =
        if (lx >= 0 && lx < SIZE && lz >= 0 && lz < SIZE) {
            chunk.getBlock(lx, y, lz)
        } else if (!world.isChunkLoadedAt(baseX + lx, baseZ + lz)) {
            BlockType.STONE
        } else {
            world.getBlock(baseX + lx, y, baseZ + lz)
        }

    /** 0 (fully boxed in) .. 3 (open) occlusion level of one face vertex. */
    private fun aoLevel(job: SubMeshJob, nx: Int, ny: Int, nz: Int, base: Int): Int {
        val side1 = job.opaqueAt(nx + AO_CELLS[base], ny + AO_CELLS[base + 1], nz + AO_CELLS[base + 2])
        val side2 = job.opaqueAt(nx + AO_CELLS[base + 3], ny + AO_CELLS[base + 4], nz + AO_CELLS[base + 5])
        if (side1 && side2) return 0
        val corner = job.opaqueAt(nx + AO_CELLS[base + 6], ny + AO_CELLS[base + 7], nz + AO_CELLS[base + 8])
        return 3 - (if (side1) 1 else 0) - (if (side2) 1 else 0) - (if (corner) 1 else 0)
    }

    private fun emitFace(
        builder: MeshBuilder, job: SubMeshJob, atlas: TextureAtlas,
        block: BlockType, face: Face,
        lx: Int, ly: Int, lz: Int, wx: Int, wy: Int, wz: Int
    ) {
        val fx = wx.toFloat()
        val fy = wy.toFloat()
        val fz = wz.toFloat()
        val uv = atlas.uvFor(block.cellFor(face))

        val shade = shadeFor(face) * variation(wx, wy, wz, if (block.cutout) 0.14f else 0.06f)
        val nx = lx + face.dx
        val ny = ly + face.dy
        val nz = lz + face.dz
        val base = face.ordinal * 36
        val a0 = aoLevel(job, nx, ny, nz, base)
        val a1 = aoLevel(job, nx, ny, nz, base + 9)
        val a2 = aoLevel(job, nx, ny, nz, base + 18)
        val a3 = aoLevel(job, nx, ny, nz, base + 27)
        val s0 = shade * AO_SHADE[a0]
        val s1 = shade * AO_SHADE[a1]
        val s2 = shade * AO_SHADE[a2]
        val s3 = shade * AO_SHADE[a3]
        // Split along the diagonal that runs through the darker corners.
        val alt = (a0 + a2) > (a1 + a3)

        val v = FACE_VERTS[face.ordinal]
        val x0 = fx + v[0]; val y0 = fy + v[1]; val z0 = fz + v[2]
        val x1 = fx + v[3]; val y1 = fy + v[4]; val z1 = fz + v[5]
        val x2 = fx + v[6]; val y2 = fy + v[7]; val z2 = fz + v[8]
        val x3 = fx + v[9]; val y3 = fy + v[10]; val z3 = fz + v[11]
        // Foliage is alpha-tested, everything else opaque: two index groups, two shaders.
        val group = if (block.cutout) MeshBuilder.GROUP_CUTOUT else MeshBuilder.GROUP_OPAQUE

        if (face == Face.TOP || face == Face.BOTTOM) {
            builder.quad(
                x0, y0, z0, x1, y1, z1, x2, y2, z2, x3, y3, z3,
                uv.u0, uv.v0, uv.u1, uv.v1, s0, s1, s2, s3, true, alt, group
            )
        } else {
            // Side faces: the first two vertices are the bottom edge. Image row 0 is the
            // top of a tile, so the bottom edge takes the tile's bottom row (v1) and the
            // top edge its top row (v0) — this is what keeps grass fringes, bark streaks
            // and the like the right way up.
            builder.quad(
                x0, y0, z0, x1, y1, z1, x2, y2, z2, x3, y3, z3,
                uv.u0, uv.v1, uv.u1, uv.v0, s0, s1, s2, s3, false, alt, group
            )
        }
    }

    /**
     * Everything drawn for one water cell: its surface (unless water or an opaque block sits
     * on top of it) and a side face towards every neighbour that is neither water nor
     * opaque, so waterfalls and the edge of a stream have walls while the sides of a lake
     * (always against terrain) cost nothing.
     *
     * The surface height follows how full the cell is, and each corner takes the average of
     * the (up to) four cells that meet there, so a flowing surface slopes smoothly from cell
     * to cell and neighbouring quads always agree on shared corners. A cell with water above
     * it is full height. Each top vertex also carries the water depth beneath it (averaged
     * over the four columns at that corner, so the tint fades smoothly from the shore into
     * open water) and the cell's flow vector.
     */
    private fun emitWater(builder: MeshBuilder, job: SubMeshJob, lx: Int, lz: Int, wx: Int, wy: Int, wz: Int, raw: Int) {
        val aboveRaw = job.rawAt(lx, wy + 1, lz)
        val aboveWater = Fluid.amountOf(aboveRaw) > 0
        val top = !aboveWater && !OPAQUE[aboveRaw and ID_MASK]
        var sides = 0
        for (dir in 0 until 4) {
            val nRaw = job.rawAt(lx + SIDE_DX[dir], wy, lz + SIDE_DZ[dir])
            if (Fluid.amountOf(nRaw) == 0 && !OPAQUE[nRaw and ID_MASK]) sides = sides or (1 shl dir)
        }
        // The common case by far: a cell inside a body of water. Nothing to draw.
        if (!top && sides == 0) return

        job.loadNeighborhood(lx, wy, lz)
        val h0 = cornerHeight(job, 0, 0)
        val h1 = cornerHeight(job, 1, 0)
        val h2 = cornerHeight(job, 1, 1)
        val h3 = cornerHeight(job, 0, 1)
        val fx = wx.toFloat()
        val fy = wy.toFloat()
        val fz = wz.toFloat()

        if (top) {
            for (dz in -1..1) {
                for (dx in -1..1) {
                    job.depth[(dz + 1) * 3 + (dx + 1)] = columnWaterDepth(job, lx + dx, lz + dz, wy)
                }
            }
            computeFlow(job, Fluid.amountOf(raw), aboveWater)
            // Split the quad along the diagonal whose corners differ least in height.
            val alt = Math.abs(h0 - h2) > Math.abs(h1 - h3)
            builder.waterTop(
                fx, fy + h0, fz, cornerDepth(job, 0, 0),
                fx + 1f, fy + h1, fz, cornerDepth(job, 1, 0),
                fx + 1f, fy + h2, fz + 1f, cornerDepth(job, 1, 1),
                fx, fy + h3, fz + 1f, cornerDepth(job, 0, 1),
                job.flowX, job.flowZ, alt
            )
        }

        for (dir in 0 until 4) {
            if ((sides and (1 shl dir)) == 0) continue
            // The face's vertices: the first two are its bottom edge (at the cell floor), the
            // last two follow the surface (the corner heights computed above).
            val v = FACE_VERTS[2 + dir]
            builder.waterSide(
                fx + v[0], sideY(fy, v[0], v[1], v[2], h0, h1, h2, h3), fz + v[2],
                fx + v[3], sideY(fy, v[3], v[4], v[5], h0, h1, h2, h3), fz + v[5],
                fx + v[6], sideY(fy, v[6], v[7], v[8], h0, h1, h2, h3), fz + v[8],
                fx + v[9], sideY(fy, v[9], v[10], v[11], h0, h1, h2, h3), fz + v[11]
            )
        }
    }

    /** World height of a side-face vertex at cell offset (ox, oy, oz): the cell floor for the
     *  bottom edge, the surface height of that corner for the top edge. */
    private fun sideY(fy: Float, ox: Int, oy: Int, oz: Int, h0: Float, h1: Float, h2: Float, h3: Float): Float {
        if (oy == 0) return fy
        return fy + if (oz == 0) {
            if (ox == 0) h0 else h1
        } else {
            if (ox == 0) h3 else h2
        }
    }

    /**
     * Surface height at one corner (cx, cz in 0..1) of the cell whose 3x3 neighbourhood is
     * loaded in [job]: the average of the four cells meeting there, weighing a nearly full
     * cell ten times as much as a low one (so a shallow trickle does not drag a lake's
     * edge down), counting open air as height 0 and ignoring solid blocks. Water above any
     * of the four cells means the corner reaches the top of the cell.
     */
    private fun cornerHeight(job: SubMeshJob, cx: Int, cz: Int): Float {
        var sum = 0f
        var weight = 0
        val first = cz * 3 + cx
        for (n in 0 until 4) {
            val i = first + CORNER_STEP[n]
            if (Fluid.amountOf(job.nbUp[i]) > 0) return 1f
            val raw = job.nb[i]
            val amount = Fluid.amountOf(raw)
            if (amount > 0) {
                val h = Fluid.heightOf(amount)
                if (h >= 0.8f) {
                    sum += h * 10f
                    weight += 10
                } else {
                    sum += h
                    weight += 1
                }
            } else if (!SOLID[raw and ID_MASK]) {
                weight += 1
            }
        }
        return if (weight == 0) Fluid.heightOf(Fluid.SOURCE) else sum / weight
    }

    /** Mean water depth (blocks, capped) of the four columns around corner (cx, cz) of the
     *  cell whose nine column depths are in [SubMeshJob.depth]. */
    private fun cornerDepth(job: SubMeshJob, cx: Int, cz: Int): Float {
        val i = cz * 3 + cx
        return (job.depth[i] + job.depth[i + 1] + job.depth[i + 3] + job.depth[i + 4]) * 0.25f
    }

    /**
     * Which way the water in this cell runs, as a vector with length 0 (still) .. 1 (fast),
     * left in job.flowX / job.flowZ. Water runs towards lower neighbours (and into open air),
     * so it is the sum of the height drops to the four sides; a calm lake, where every side
     * is level or solid, comes out as exactly zero.
     */
    private fun computeFlow(job: SubMeshJob, amount: Int, aboveWater: Boolean) {
        val own = if (aboveWater) 1f else Fluid.heightOf(amount)
        var fx = 0f
        var fz = 0f
        for (k in 0 until 4) {
            val i = FLOW_IDX[k]
            val raw = job.nb[i]
            val nAmount = Fluid.amountOf(raw)
            var drop = 0f
            var counts = false
            if (nAmount > 0) {
                val nh = if (Fluid.amountOf(job.nbUp[i]) > 0) 1f else Fluid.heightOf(nAmount)
                drop = own - nh
                counts = true
            } else if (!SOLID[raw and ID_MASK]) {
                drop = own
                counts = true
            }
            if (!counts) continue
            fx += FLOW_DX[k] * drop
            fz += FLOW_DZ[k] * drop
        }
        val len = sqrt(fx * fx + fz * fz)
        if (len < 0.0001f) {
            job.flowX = 0f
            job.flowZ = 0f
        } else {
            val speed = if (len * 6f > 1f) 1f else len * 6f
            job.flowX = fx / len * speed
            job.flowZ = fz / len * speed
        }
    }

    /** Number of consecutive water cells in a column counting down from [wy] (inclusive). */
    private fun columnWaterDepth(job: SubMeshJob, lx: Int, lz: Int, wy: Int): Int {
        var depth = 0
        var y = wy
        while (depth < WATER_DEPTH_CAP && y >= 0 && job.blockAtWorldY(lx, y, lz) == BlockType.WATER) {
            depth++
            y--
        }
        return depth
    }

    /**
     * A cross-shaped plant: two vertical quads along the cell's diagonals. They go to the
     * double-sided index group, which is drawn with back-face culling off, so one quad per
     * diagonal shows from both sides (it used to be two quads each, in both windings: half
     * the plant vertices and triangles of every meadow). A position hash nudges each
     * plant off the block grid so meadows don't look stamped; the quad is a little darker
     * at the root, which grounds it without any lighting data.
     */
    private fun emitPlant(builder: MeshBuilder, atlas: TextureAtlas, block: BlockType, wx: Int, wy: Int, wz: Int) {
        val uv = atlas.uvFor(block.topCell)
        val bits = (wx * 73856093) xor (wz * 19349663) xor (wy * 83492791)
        val jx = ((bits ushr 4) and 7) / 7f * 0.24f - 0.12f
        val jz = ((bits ushr 8) and 7) / 7f * 0.24f - 0.12f
        val bright = variation(wx, wy, wz, 0.18f)
        val root = 0.74f * bright
        val tip = 1.0f * bright
        val x = wx + 0.5f + jx
        val z = wz + 0.5f + jz
        val y0 = wy.toFloat()
        val y1 = wy + 1f
        val r = 0.46f
        // diagonal A: (-r,-r) -> (+r,+r); diagonal B: (+r,-r) -> (-r,+r)
        builder.quad(
            x - r, y0, z - r, x + r, y0, z + r, x + r, y1, z + r, x - r, y1, z - r,
            uv.u0, uv.v1, uv.u1, uv.v0, root, root, tip, tip, false, false, MeshBuilder.GROUP_DOUBLE
        )
        builder.quad(
            x + r, y0, z - r, x - r, y0, z + r, x - r, y1, z + r, x + r, y1, z - r,
            uv.u0, uv.v1, uv.u1, uv.v0, root, root, tip, tip, false, false, MeshBuilder.GROUP_DOUBLE
        )
    }

    /** A lily pad: one horizontal quad just above the water, in the double-sided group so it
     *  shows from above and from below. */
    private fun emitLilyPad(builder: MeshBuilder, atlas: TextureAtlas, block: BlockType, wx: Int, wy: Int, wz: Int) {
        val uv = atlas.uvFor(block.topCell)
        val bits = (wx * 73856093) xor (wz * 19349663) xor (wy * 83492791)
        val jx = ((bits ushr 4) and 7) / 7f * 0.16f - 0.08f
        val jz = ((bits ushr 8) and 7) / 7f * 0.16f - 0.08f
        val shade = variation(wx, wy, wz, 0.14f)
        val x = wx + 0.5f + jx
        val z = wz + 0.5f + jz
        val y = wy + 0.03f
        val r = 0.5f
        builder.quad(
            x - r, y, z - r, x - r, y, z + r, x + r, y, z + r, x + r, y, z - r,
            uv.u0, uv.v0, uv.u1, uv.v1, shade, shade, shade, shade, false, false, MeshBuilder.GROUP_DOUBLE
        )
    }

    /** Per-block brightness multiplier in (1 - range)..1, a pure function of position. */
    private fun variation(x: Int, y: Int, z: Int, range: Float): Float {
        var h = x * 73856093 xor y * 19349663 xor z * 83492791
        h = h xor (h ushr 15)
        h *= 739982445
        h = h xor (h ushr 13)
        return 1f - range * (((h ushr 8) and 0xFF) / 255f)
    }

    private fun shadeFor(face: Face): Float = when (face) {
        Face.TOP -> 1.0f
        Face.BOTTOM -> 0.4f
        Face.NORTH, Face.SOUTH -> 0.82f
        Face.EAST, Face.WEST -> 0.70f
    }
}
