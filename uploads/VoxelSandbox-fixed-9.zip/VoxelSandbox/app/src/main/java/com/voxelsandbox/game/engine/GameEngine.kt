package com.voxelsandbox.game.engine

import com.voxelsandbox.game.engine.fx.ParticleSystem
import com.voxelsandbox.game.gl.TextureAtlas
import com.voxelsandbox.game.input.InputState
import com.voxelsandbox.game.inventory.Inventory
import com.voxelsandbox.game.player.Player
import com.voxelsandbox.game.player.PhysicsController
import com.voxelsandbox.game.player.Raycaster
import com.voxelsandbox.game.player.RaycastHit
import com.voxelsandbox.game.save.LoadedSave
import com.voxelsandbox.game.settings.GameSettings
import com.voxelsandbox.game.world.BlockType
import com.voxelsandbox.game.world.ChunkPos
import com.voxelsandbox.game.world.FluidSimulator
import com.voxelsandbox.game.world.World
import com.voxelsandbox.game.world.WorldConfig
import com.voxelsandbox.game.world.WorldManager
import com.voxelsandbox.game.world.far.FarTerrain
import com.voxelsandbox.game.world.generation.TerrainGenerator
import java.util.Locale
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.random.Random

/**
 * The GL-agnostic game loop: physics, input interpretation, world-streaming input,
 * and break/place actions. GameRenderer calls [update] once per frame from the GL
 * thread and then reads the exposed state (player, world, particles, ...) to draw.
 */
class GameEngine(val settings: GameSettings, savedGame: LoadedSave?) {
    val world = World()
    val seed: Long = savedGame?.seed ?: Random.nextLong()
    private val generator = TerrainGenerator(seed)
    val atlas = TextureAtlas()
    val worldManager = WorldManager(world, generator, atlas, savedGame?.chunkOverrides ?: emptyMap())
    val farTerrain = FarTerrain(generator)

    /** Makes water flow: spreads into holes the player digs, falls down shafts, recedes when
     *  its source is covered. Driven by block edits (see [FluidSimulator]). */
    private val fluid = FluidSimulator(world, worldManager)

    val player = Player()
    private val physics = PhysicsController(world)
    val inventory = Inventory()
    val particles = ParticleSystem()
    val input = InputState()

    private val spawnPos: ChunkPos
    private var breakCooldown = 0f
    private var placeCooldown = 0f
    private var bobPhase = 0f

    // creative mode
    private var lastCreative = false
    private var timeSec = 0f
    private var lastJumpPress = -10f
    private var lastJumpHeld = false
    private var laserTimer = 0f

    /** True while the creative destroy laser is firing (the renderer draws the beam). */
    var laserActive = false
        private set

    var bobOffset = 0f
        private set
    var lastHit: RaycastHit? = null
        private set

    init {
        if (savedGame != null) {
            player.position.set(savedGame.playerX, savedGame.playerY, savedGame.playerZ)
            player.yaw = savedGame.yaw
            player.pitch = savedGame.pitch
            inventory.importCounts(savedGame.inventoryCounts)
            player.waitingForSpawn = false // saved position is already known-good ground
        }
        if (savedGame == null) {
            // New world: start on dry, gentle ground rather than wherever (0, 0) happens to be
            // (it could be the middle of an ocean). The search is a pure function of the seed.
            val spawn = generator.findSpawn()
            player.position.set(spawn.x + 0.5f, player.position.y, spawn.z + 0.5f)
        }
        spawnPos = ChunkPos.fromWorld(player.position.x, player.position.z)
        worldManager.requestImmediateChunk(spawnPos)
        worldManager.start()
        pushFarTerrainState()
        farTerrain.start()
    }

    fun shutdown() {
        worldManager.shutdown()
        farTerrain.shutdown()
    }

    /** Feeds the distant-terrain builder the player position and the current settings.
     *  Called every frame (it only stores a few volatile fields), including while the
     *  spawn chunk is still generating, so the horizon appears immediately. */
    private fun pushFarTerrainState() {
        farTerrain.updatePlayer(
            player.position.x,
            player.position.z,
            settings.renderDistanceChunks * WorldConfig.CHUNK_SIZE.toFloat(),
            settings.farTerrain
        )
    }

    private val lookDelta = FloatArray(2)

    fun update(dt: Float) {
        val clampedDt = dt.coerceAtMost(0.05f) // guards against a huge dt after e.g. resuming from background

        pushFarTerrainState()
        if (player.waitingForSpawn) {
            if (worldManager.isChunkGenerated(spawnPos)) {
                dropPlayerToSurface()
                player.waitingForSpawn = false
            } else {
                return // hold everything until the spawn column actually exists
            }
        }

        input.consumeLookDelta(lookDelta)
        val lookSens = 0.0022f + settings.lookSensitivity * 0.0035f
        player.addLook(lookDelta[0] * lookSens, -lookDelta[1] * lookSens)

        // Slider sits at 1.0x speed in its default middle position rather than at a
        // fraction of walking speed, which would otherwise feel like a bug.
        val moveSens = 0.6f + settings.touchSensitivity.coerceIn(0f, 1f) * 0.8f
        val forward = input.moveForward * moveSens
        val strafe = input.moveStrafe * moveSens
        val yaw = player.yaw
        val worldMoveX = forward * sin(yaw) + strafe * cos(yaw)
        val worldMoveZ = -forward * cos(yaw) + strafe * sin(yaw)

        val creative = settings.creativeMode
        timeSec += clampedDt
        if (creative != lastCreative) {
            // Turning creative on starts flying; turning it off drops back to normal walking.
            lastCreative = creative
            player.flying = creative
            player.velocity.set(0f, 0f, 0f)
        }
        // Double-tapping jump toggles flight while in creative mode.
        val jumpNow = input.jumpHeld
        if (creative && jumpNow && !lastJumpHeld) {
            if (timeSec - lastJumpPress < 0.3f) {
                player.flying = !player.flying
                player.velocity.set(0f, 0f, 0f)
                lastJumpPress = -10f
            } else {
                lastJumpPress = timeSec
            }
        }
        lastJumpHeld = jumpNow

        if (creative && player.flying) {
            flyMove(clampedDt)
            updateViewBob(0f, 0f, clampedDt)
        } else {
            physics.step(player, worldMoveX, worldMoveZ, input.jumpHeld, settings.autoJump, clampedDt)
            updateViewBob(worldMoveX, worldMoveZ, clampedDt)
        }

        worldManager.updatePlayerPosition(player.position.x, player.position.z, settings.nearChunks())
        particles.update(clampedDt)
        handleBreakPlace(clampedDt, creative)
        handleLaser(clampedDt, creative)
        fluid.update(clampedDt)
    }

    /** Creative flight: the joystick moves along the look direction (including up/down
     *  when looking up or down), the jump button climbs and the descend button sinks. */
    private fun flyMove(dt: Float) {
        val speed = settings.flySpeed
        val yaw = player.yaw
        val pitch = player.pitch
        val fwd = input.moveForward
        val str = input.moveStrafe
        val cp = cos(pitch)
        val vx = (cp * sin(yaw) * fwd + cos(yaw) * str) * speed
        var vy = sin(pitch) * fwd * speed
        val vz = (-cp * cos(yaw) * fwd + sin(yaw) * str) * speed
        val climb = maxOf(10f, speed * 0.6f)
        if (input.jumpHeld) vy += climb
        if (input.descendHeld) vy -= climb
        physics.flyStep(player, vx, vy, vz, dt)
        val ceiling = WorldConfig.WORLD_HEIGHT + 200f
        if (player.position.y > ceiling) player.position.y = ceiling
    }

    /** Creative destroy laser: while held, every [LASER_INTERVAL] seconds it removes every
     *  breakable block in a tube of [LASER_RADIUS] around the view ray, out to [LASER_RANGE]
     *  blocks (it pierces everything), for stress-testing chunk edits and remeshing. */
    private fun handleLaser(dt: Float, creative: Boolean) {
        laserActive = creative && input.laserHeld
        if (!laserActive) {
            laserTimer = 0f
            return
        }
        laserTimer -= dt
        if (laserTimer > 0f) return
        laserTimer = LASER_INTERVAL

        val cp = cos(player.pitch)
        val dirX = cp * sin(player.yaw)
        val dirY = sin(player.pitch)
        val dirZ = -cp * cos(player.yaw)
        val ex = player.eyeX()
        val ey = player.eyeY()
        val ez = player.eyeZ()
        val r = LASER_RADIUS
        val reach2 = r * r + 1
        var step = 2
        while (step <= LASER_RANGE) {
            val cx = floor(ex + dirX * step).toInt()
            val cy = floor(ey + dirY * step).toInt()
            val cz = floor(ez + dirZ * step).toInt()
            for (ox in -r..r) for (oy in -r..r) for (oz in -r..r) {
                if (ox * ox + oy * oy + oz * oz > reach2) continue
                val by = cy + oy
                if (by < 1 || by >= WorldConfig.WORLD_HEIGHT) continue
                val bx = cx + ox
                val bz = cz + oz
                val block = world.getBlock(bx, by, bz)
                if (block != BlockType.AIR && block.breakable) {
                    if (worldManager.setBlockBatched(bx, by, bz, BlockType.AIR)) {
                        fluid.onBlockChanged(bx, by, bz)
                    }
                }
            }
            step++
        }
        worldManager.flushBatchedEdits()
    }

    private fun updateViewBob(worldMoveX: Float, worldMoveZ: Float, dt: Float) {
        if (!settings.viewBobbing) {
            bobOffset = 0f
            return
        }
        val speed = hypot(worldMoveX.toDouble(), worldMoveZ.toDouble()).toFloat()
        if (player.onGround && speed > 0.05f) {
            bobPhase += dt * 9f
            bobOffset = sin(bobPhase) * 0.045f
        } else {
            bobOffset *= 0.85f
        }
    }

    private fun handleBreakPlace(dt: Float, creative: Boolean) {
        breakCooldown -= dt
        placeCooldown -= dt

        val dirX = cos(player.pitch) * sin(player.yaw)
        val dirY = sin(player.pitch)
        val dirZ = -cos(player.pitch) * cos(player.yaw)
        val hit = Raycaster.cast(world, player.eyeX(), player.eyeY(), player.eyeZ(), dirX, dirY, dirZ, WorldConfig.MAX_INTERACT_REACH)
        lastHit = hit
        if (hit == null) return

        val target = world.getBlock(hit.blockX, hit.blockY, hit.blockZ)

        if (input.breakHeld && breakCooldown <= 0f) {
            if (target.breakable) {
                if (worldManager.setBlockAndRemesh(hit.blockX, hit.blockY, hit.blockZ, BlockType.AIR)) {
                    fluid.onBlockChanged(hit.blockX, hit.blockY, hit.blockZ)
                    if (!creative) inventory.add(target.drop, 1)
                    if (settings.particlesEnabled) {
                        particles.spawnBurst(hit.blockX + 0.5f, hit.blockY + 0.5f, hit.blockZ + 0.5f, target)
                    }
                }
            }
            breakCooldown = if (creative) 0.12f else 0.28f
        }

        if (input.placeHeld && placeCooldown <= 0f) {
            // Aiming at a plant places into the plant's own cell (replacing it); otherwise
            // the block goes onto the face that was hit.
            var px = hit.blockX
            var py = hit.blockY
            var pz = hit.blockZ
            var canTry = target.plant
            if (!target.plant && (hit.faceX != 0 || hit.faceY != 0 || hit.faceZ != 0)) {
                px += hit.faceX
                py += hit.faceY
                pz += hit.faceZ
                canTry = true
            }
            if (canTry) {
                val existing = world.getBlock(px, py, pz)
                val selected = inventory.selectedBlock()
                // Water does not block movement, so it may be placed on top of the player too.
                val fitsPlayer = selected == BlockType.WATER || !intersectsPlayer(px, py, pz)
                if (existing.replaceable && (creative || inventory.canPlaceSelected()) && fitsPlayer) {
                    if (worldManager.setBlockAndRemesh(px, py, pz, selected)) {
                        fluid.onBlockChanged(px, py, pz)
                        if (!creative) inventory.consumeSelected()
                    }
                }
            }
            placeCooldown = 0.22f
        }
    }

    private fun intersectsPlayer(bx: Int, by: Int, bz: Int): Boolean {
        val hw = Player.WIDTH / 2f
        val px = player.position.x; val py = player.position.y; val pz = player.position.z
        return px + hw > bx && px - hw < bx + 1f &&
            py + Player.HEIGHT > by && py < by + 1f &&
            pz + hw > bz && pz - hw < bz + 1f
    }

    /** Puts the player on the ground at the spawn column, or at the nearest column that has
     *  real standing room (not under a tree trunk, not on a canopy, cactus or water). */
    private fun dropPlayerToSurface() {
        val bx = floor(player.position.x).toInt()
        val bz = floor(player.position.z).toInt()
        for (ring in 0..SPAWN_SEARCH_RADIUS) {
            for (dz in -ring..ring) {
                for (dx in -ring..ring) {
                    if (maxOf(abs(dx), abs(dz)) != ring) continue
                    val feetY = standingHeight(bx + dx, bz + dz)
                    if (feetY >= 0) {
                        player.position.set(bx + dx + 0.5f, feetY.toFloat(), bz + dz + 0.5f)
                        return
                    }
                }
            }
        }
        // Nothing suitable nearby (practically impossible): fall back to the topmost block.
        var y = WorldConfig.WORLD_HEIGHT - 1
        while (y > 0 && world.getBlock(bx, y, bz) == BlockType.AIR) y--
        player.position.set(player.position.x, (y + 1).toFloat(), player.position.z)
    }

    /** Feet Y for standing in column (x, z): on top of the highest solid, non-foliage block
     *  that has two clear cells above it. -1 if the column has no such place. */
    private fun standingHeight(x: Int, z: Int): Int {
        var y = WorldConfig.WORLD_HEIGHT - 3
        while (y > 0) {
            val block = world.getBlock(x, y, z)
            if (block.solid && !block.cutout && block != BlockType.CACTUS &&
                isClear(x, y + 1, z) && isClear(x, y + 2, z)
            ) {
                return y + 1
            }
            y--
        }
        return -1
    }

    private fun isClear(x: Int, y: Int, z: Int): Boolean {
        val block = world.getBlock(x, y, z)
        return block == BlockType.AIR || block.plant
    }

    /** Short HUD status line: the biome the player is standing in, plus the creative state. */
    fun statusLine(): String {
        val biome = generator.biomeAt(floor(player.position.x).toInt(), floor(player.position.z).toInt()).displayName
        if (!settings.creativeMode) return biome
        return biome + "   |   Creative" + (if (player.flying) " - flying" else "")
    }

    fun debugStats(): String {
        val s = worldManager.stats()
        return String.format(
            Locale.US,
            "chunks:%d/%d  genQ:%d  meshQ:%d\npos: %.1f, %.1f, %.1f  particles:%d",
            s.loadedChunks, s.chunkBudget, s.genQueueSize, s.meshQueueSize,
            player.position.x, player.position.y, player.position.z, particles.count()
        )
    }

    private companion object {
        /** How far (in columns) from the spawn point to look for real standing room. */
        const val SPAWN_SEARCH_RADIUS = 7

        /** Creative destroy laser: tube radius (blocks), reach (blocks), seconds between pulses. */
        const val LASER_RADIUS = 2
        const val LASER_RANGE = 96
        const val LASER_INTERVAL = 0.1f
    }
}
