package com.voxelsandbox.game.world

/**
 * How full a cell of water is, packed into the block byte itself.
 *
 * The low 5 bits of a block byte are the block id ([BlockType.WATER] for every kind of
 * water) and the top 3 bits were unused, so they hold the fill level at no memory cost and
 * with no change to the save format (older saves simply have 0 there):
 *
 *  - bits 0: a SOURCE block. Full, permanent, and what the terrain generator and the
 *    player's water slot produce. Oceans and lakes are sources.
 *  - bits 1..7: flowing water. Its "amount" is 8 - bits, so 7 right next to a source down
 *    to 1 seven blocks away. Flowing water is not permanent: it needs a neighbour to feed
 *    it (see [FluidSimulator]).
 *
 * Everything that only asks "is this water?" can keep comparing block ids; only the mesher
 * (surface height, sides, flow direction), the simulator and the underwater test care
 * about the amount.
 */
object Fluid {
    /** The amount a source block counts as. */
    const val SOURCE = 8

    private val WATER_ID: Int = BlockType.WATER.id.toInt()
    private const val ID_MASK = BlockType.TABLE_SIZE - 1

    /** 0 if [raw] (a block byte, 0..255) is not water, [SOURCE] for a source, else 1..7. */
    fun amountOf(raw: Int): Int {
        if ((raw and ID_MASK) != WATER_ID) return 0
        val bits = (raw ushr 5) and 7
        return if (bits == 0) SOURCE else 8 - bits
    }

    /** The block byte for a cell holding [amount] (1..8) of water. */
    fun rawFor(amount: Int): Int =
        if (amount >= SOURCE) WATER_ID else WATER_ID or ((8 - amount) shl 5)

    /** Height of the water surface in its cell, in blocks (0..1). A source sits a little
     *  below the top of the cell, exactly where the old flat water did. */
    fun heightOf(amount: Int): Float = if (amount >= SOURCE) 0.875f else amount * 0.125f
}
