package com.voxelsandbox.game.gl

import android.opengl.GLES30

/**
 * The translucent, animated water pass. It owns the water program and its tile texture
 * and knows nothing about where the water meshes come from: GameRenderer (voxel chunks)
 * and FarTerrainRenderer (distant tiles) each call [begin], pick an area with
 * [useNearArea] / [useFarBand], draw their meshes, then call [end].
 *
 * Water is drawn after all opaque geometry, with blending on and depth writes off, so the
 * lake bed (or whatever lies behind) shows through according to the surface's opacity.
 *
 * The look is pixel art, not simulation: the shader samples a 32x32 tile with nearest
 * filtering, slides it along the flow direction stored in the vertices, tints it by water
 * depth and adds shoreline foam. That is both cheaper than the old reflective shader (one
 * big translucent layer covers a lot of the screen over an ocean) and a much better match
 * for the block textures.
 */
class WaterRenderer {
    private lateinit var program: ShaderProgram
    private val texture = WaterTexture()

    private var uViewProj = 0
    private var uWaterTex = 0
    private var uTime = 0
    private var uFogColor = 0
    private var uFogStart = 0
    private var uFogEnd = 0
    private var uClip = 0
    private var uCenter = 0
    private var uBand = 0

    /** Call from onSurfaceCreated (a new GL context needs a fresh program and texture). */
    fun init() {
        program = ShaderProgram(Shaders.WATER_VERTEX, Shaders.WATER_FRAGMENT)
        uViewProj = program.uniform("uViewProj")
        uWaterTex = program.uniform("uWaterTex")
        uTime = program.uniform("uTime")
        uFogColor = program.uniform("uFogColor")
        uFogStart = program.uniform("uFogStart")
        uFogEnd = program.uniform("uFogEnd")
        uClip = program.uniform("uClip")
        uCenter = program.uniform("uCenter")
        uBand = program.uniform("uBand")
        texture.upload()
    }

    /** Switches to the water program with this frame's shared uniforms and turns blending on. */
    fun begin(frame: FrameState) {
        program.use()
        GLES30.glUniformMatrix4fv(uViewProj, 1, false, frame.viewProj, 0)
        GLES30.glUniform1f(uTime, frame.textureTime)
        GLES30.glUniform3f(uFogColor, frame.fogR, frame.fogG, frame.fogB)
        GLES30.glUniform1f(uFogStart, frame.fogStart)
        GLES30.glUniform1f(uFogEnd, frame.fogEnd)
        texture.bind(1)
        GLES30.glUniform1i(uWaterTex, 1)

        GLES30.glEnable(GLES30.GL_BLEND)
        GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE_MINUS_SRC_ALPHA)
        GLES30.glDepthMask(false)
    }

    /**
     * Water in voxel chunks. With [limitToCovered] (the distant terrain is on) it is kept
     * inside the circle of full-detail chunks, the exact complement of [useFarBand]'s clip,
     * so the two translucent layers never overlap into a darker ring. Otherwise (distant
     * terrain off, or underwater) nothing is clipped.
     */
    fun useNearArea(frame: FrameState, limitToCovered: Boolean) {
        GLES30.glUniform3f(uClip, 0f, 0f, 0f)
        if (limitToCovered) {
            GLES30.glUniform2f(uCenter, frame.coverX, frame.coverZ)
            GLES30.glUniform4f(uBand, 0f, frame.coverRadius, 0f, 0f)
        } else {
            GLES30.glUniform2f(uCenter, frame.eyeX, frame.eyeZ)
            GLES30.glUniform4f(uBand, 0f, 1.0e9f, 0f, 0f)
        }
    }

    /** Distant water of one level of detail: kept out of the voxel-covered circle and
     *  clipped exactly to the ring [innerRadius, outerRadius) around the player. */
    fun useFarBand(frame: FrameState, innerRadius: Float, outerRadius: Float) {
        GLES30.glUniform3f(uClip, frame.coverX, frame.coverZ, frame.coverRadius * frame.coverRadius)
        GLES30.glUniform2f(uCenter, frame.eyeX, frame.eyeZ)
        GLES30.glUniform4f(uBand, innerRadius, outerRadius, 0f, 0f)
    }

    /** Leaves GL in the state the opaque passes expect. */
    fun end() {
        GLES30.glDepthMask(true)
        GLES30.glDisable(GLES30.GL_BLEND)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
    }
}
