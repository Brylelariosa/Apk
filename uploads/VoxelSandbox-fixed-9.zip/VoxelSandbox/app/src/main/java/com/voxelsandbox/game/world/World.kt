package com.voxelsandbox.game.world

import com.voxelsandbox.game.util.floorDiv
import com.voxelsandbox.game.util.floorMod
import java.util.concurrent.ConcurrentHashMap

/**
 * Owns the chunk map. Reads (getBlock/isOpaque/isSolid) are called from the GL/game
 * thread every frame (physics, raycasting) and from background generation/mesh worker
 * threads (neighbor lookups) — ConcurrentHashMap gives safe, lock-free reads. Writes
 * (putChunk/removeChunk) come from WorldManager only.
 *
 * A coordinate in a chunk that isn't loaded is treated as AIR/non-opaque. This is a
 * deliberate, safe default: it means chunk-boundary faces render (rather than leaving
 * holes) until the real neighbor loads and both sides remesh.
 *
 * Internally keyed by a packed Long (chunkX/chunkZ folded into one 64-bit value)
 * rather than by ChunkPos: getBlock/isOpaque/isSolid/setBlock run for every block a
 * raycast steps through and every block physics sweeps each frame, and each call
 * used to allocate a fresh ChunkPos purely to key this map (the ChunkMesher.kt
 * comment on its own in-chunk fast path already measured how much that kind of
 * per-lookup allocation costs at real scale). packKey below is computed straight
 * from the already-in-hand chunkX/chunkZ ints, so these hot paths allocate nothing
 * of their own; getChunk/putChunk/removeChunk keep taking a ChunkPos since callers
 * outside this class already have one on hand, and just pack it the same way.
 */
class World {
    private val chunks = ConcurrentHashMap<Long, Chunk>()

    private fun packKey(cx: Int, cz: Int): Long = (cx.toLong() shl 32) or (cz.toLong() and 0xFFFFFFFFL)

    fun getChunk(pos: ChunkPos): Chunk? = chunks[packKey(pos.x, pos.z)]

    fun putChunk(chunk: Chunk) {
        chunks[packKey(chunk.pos.x, chunk.pos.z)] = chunk
    }

    fun removeChunk(pos: ChunkPos): Chunk? = chunks.remove(packKey(pos.x, pos.z))

    fun allChunks(): Collection<Chunk> = chunks.values

    fun chunkCount(): Int = chunks.size

    fun getBlock(x: Int, y: Int, z: Int): BlockType {
        if (y < 0 || y >= WorldConfig.WORLD_HEIGHT) return BlockType.AIR
        val cx = floorDiv(x, WorldConfig.CHUNK_SIZE)
        val cz = floorDiv(z, WorldConfig.CHUNK_SIZE)
        val chunk = chunks[packKey(cx, cz)] ?: return BlockType.AIR
        val lx = floorMod(x, WorldConfig.CHUNK_SIZE)
        val lz = floorMod(z, WorldConfig.CHUNK_SIZE)
        return chunk.getBlock(lx, y, lz)
    }

    /** True if the chunk containing this column is loaded (the mesher uses this to tell
     *  "air" from "not generated yet"). */
    fun isChunkLoadedAt(x: Int, z: Int): Boolean =
        chunks.containsKey(packKey(floorDiv(x, WorldConfig.CHUNK_SIZE), floorDiv(z, WorldConfig.CHUNK_SIZE)))

    /** The whole block byte at a position (block id plus, for water, how full the cell is;
     *  see [Fluid]). 0 (air) outside the world or in a chunk that is not loaded. */
    fun getRaw(x: Int, y: Int, z: Int): Int {
        if (y < 0 || y >= WorldConfig.WORLD_HEIGHT) return 0
        val cx = floorDiv(x, WorldConfig.CHUNK_SIZE)
        val cz = floorDiv(z, WorldConfig.CHUNK_SIZE)
        val chunk = chunks[packKey(cx, cz)] ?: return 0
        return chunk.getRaw(floorMod(x, WorldConfig.CHUNK_SIZE), y, floorMod(z, WorldConfig.CHUNK_SIZE))
    }

    /** Like [setBlock] but writes the whole byte, so flowing water can carry its level.
     *  Returns false if the target chunk isn't loaded. */
    fun setRaw(x: Int, y: Int, z: Int, raw: Int): Boolean {
        if (y < 0 || y >= WorldConfig.WORLD_HEIGHT) return false
        val cx = floorDiv(x, WorldConfig.CHUNK_SIZE)
        val cz = floorDiv(z, WorldConfig.CHUNK_SIZE)
        val chunk = chunks[packKey(cx, cz)] ?: return false
        chunk.setRaw(floorMod(x, WorldConfig.CHUNK_SIZE), y, floorMod(z, WorldConfig.CHUNK_SIZE), raw)
        chunk.hasPlayerEdits = true
        return true
    }

    fun isOpaque(x: Int, y: Int, z: Int): Boolean = getBlock(x, y, z).opaque

    fun isSolid(x: Int, y: Int, z: Int): Boolean = getBlock(x, y, z).solid

    /** Returns false if the target chunk isn't loaded (caller should not treat this as
     *  a successful edit). */
    fun setBlock(x: Int, y: Int, z: Int, type: BlockType): Boolean {
        if (y < 0 || y >= WorldConfig.WORLD_HEIGHT) return false
        val cx = floorDiv(x, WorldConfig.CHUNK_SIZE)
        val cz = floorDiv(z, WorldConfig.CHUNK_SIZE)
        val chunk = chunks[packKey(cx, cz)] ?: return false
        val lx = floorMod(x, WorldConfig.CHUNK_SIZE)
        val lz = floorMod(z, WorldConfig.CHUNK_SIZE)
        chunk.setBlock(lx, y, lz, type)
        chunk.hasPlayerEdits = true
        return true
    }
}
