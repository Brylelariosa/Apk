# VoxelSandbox v9: flowing pixel-art water, smoother LOD transition, much lighter on the GPU

## What changed
- **Water flows.** Break a wall next to a lake and it pours in; dig a shaft and it falls; it runs about
  7 blocks over flat ground, one level lower per block, and drains again when you cover its source.
  The last hotbar slot is now **Water** (8 sources in survival, unlimited in creative): place one and watch
  it spread. It is a small event-driven simulation (`FluidSimulator`): nothing runs until a block next to
  water changes, then a few hundred cells per tick at 5 ticks a second, so calm oceans cost nothing.
  How full a cell is lives in the spare top 3 bits of its block byte (`Fluid`), so there is no new storage
  and old saves load unchanged (ocean and lake water are all full "source" blocks).
- **Water looks like the rest of the game.** The reflective / glinting / swelling water is gone. Water is now
  pixel art: a 32x32 tile in six blues (`WaterTexture`), nearest-texel filtered, sliding along the flow
  direction, with a depth tint (azure shallows, deep blue open water) and shoreline foam. Flowing water
  gets stretched streaks, waterfalls get their own side faces with tall streaks running down. The surface
  height follows the water level and slopes smoothly between cells.
- **LOD starts farther out and blends in.** Default detail distance 16 -> 20 chunks (slider up to 32;
  an old saved default of 16 moves to the new one once). The voxel terrain now *dissolves* into the distant
  terrain over the last ~30-45 blocks (ordered-noise screen door), instead of ending in a hard line.
  The distant terrain also carries the same per-block brightness speckle the real blocks have, so flat
  colour no longer reads as a different material. The textured wall that used to stand at the outer rim
  of loaded chunks is gone (see below), and the coverage scan runs 8x per second instead of 4x.
- **Lighter on the GPU / CPU (no visual cost):**
  - Opaque blocks are drawn by a fragment shader with **no `discard`**, so the GPU can reject hidden pixels
    early (and tile-based GPUs can remove them outright). Only leaves and plants are alpha-tested, in
    their own draws afterwards (`MeshData.opaqueEnd` / `cutoutEnd`, `ChunkGpuMesh.drawOpaque/Cutout/DoubleSided`).
  - Plants and lily pads are one quad per plane drawn with culling off instead of two quads each: half the
    vertices and triangles of every meadow, and less memory per chunk.
  - Faces towards a chunk that is not generated yet are not drawn. The outer rim of loaded chunks used to
    be a tall stone/dirt wall of faces nobody should see; that was a big share of all triangles.
  - Region uploads are debounced: a region still receiving subchunk results waits ~70 ms and is built once,
    instead of being rebuilt (and re-uploaded) after each of up to 32 results. Streaming hitches drop a lot.
  - All-air subchunks are not queued for meshing at all (a chunk generating queues its neighbours' too).
  - The new water shader is a couple of texture fetches and a tint (the old one did Fresnel, normals,
    glints and foam per pixel over big translucent oceans); water is also never drawn twice where the
    distant and voxel layers meet.
  - Voxel regions entirely past the dissolve edge are skipped; the sky shader skips the sun terms away from
    the sun.

## Heads-up
- New hotbar slot (Water). An old save has no count for it, so it starts with 8.
- Flowing water is saved with the chunks it entered. Water that was already "frozen" mid-flow when you
  quit stays as it was until something next to it changes.
- Water does not push the player or slow swimming (not asked for, not changed).
- Still written without a Kotlin/Android toolchain: not compiled or run on a device. The GLSL was compiled
  and the water previewed in a headless WebGL2 context, and the fluid rules were run in a Python port.
  If the build reports an error, the log line points straight at it.

---

# (previous) VoxelSandbox v8: creative mode, blocky LOD with trees, new biomes, fixes

## What changed
- **Creative mode** (star button on the HUD, or Settings): free flight along the look direction, jump = up,
  new "fly down" button, double-tap jump toggles flight, unlimited blocks, instant plant/block breaking.
  Fly speed slider in Settings (8..200 blocks/s) for fast travel while testing.
- **Destroy laser** (creative only, new HUD button): hold to carve a 96-block-long tube through everything
  in front of you (pierces terrain, trees, plants) to stress-test chunk edits and remeshing. Edits are batched
  (`WorldManager.setBlockBatched` / `flushBatchedEdits`) so a pulse remeshes each affected subchunk once.
- **Distant terrain (LOD)** now looks like voxels: flat-topped columns with vertical walls, flat colours,
  neighbours merged into long quads. Level 0 stands real little trees (trunk + canopy boxes) at exactly the
  spots the chunk generator will grow them; coarser levels raise forests into a dark canopy layer.
  Tiles are 64x64 columns (256 blocks at level 0), so roughly a quarter of the draw calls.
- **Leaves**: new crisp pixel-art leaf textures (flat palette colours, rare isolated holes with a darker rim)
  instead of the smooth blurry scatter; you can no longer see straight through trees.
- **Thin outlines on blocks** (sand, grass, snow, ...): caused by texture filtering at low angles reaching into
  the neighbouring tile of the atlas. Every tile now has a 16-texel gutter filled with its own pattern.
- **Sky box outline**: it was the edge of the translucent cloud square. Clouds are now a blocky, drifting layer
  with no edge (`CloudRenderer`, `Shaders.CLOUD_*`) that fades out with distance.
- **Biomes** (`Climate`, `Biome`): plains, forest, birch forest, taiga, snowy plains, snowy taiga, savanna,
  desert, mountains, snowy peaks, beach, snowy shore (gravel), ocean, deep ocean, lake. Decided from the slow
  climate fields, the smooth coastline and altitude, never from local bumps, so no more sand mixed with snow
  (snowy coasts are gravel, beaches only exist in warm climates, snow line depends on temperature).
  The biome you are in is shown at the top of the screen.
- **Terrain**: the 1-block jitter (micro noise) is gone, high-frequency hill octaves are weaker, and lone
  1-block bumps/pits are removed (`TerrainGenerator.despike`), so plains are flat and slopes form wide terraces.
- **Jump**: snappier (gravity 32, jump speed 8.9, about 1.25 blocks high), feet-level collision epsilon, and
  Auto Jump is now on by default.
- **Plants** can be targeted (small outline box) and broken, and placing a block on one replaces it.
- **Lily pads** float on shallow warm water in patches (new block, flat quad).
- **Performance**: voxel chunks are drawn in 2x2-column regions (about 3.5x fewer draw calls, the main cost on
  phones), distant tiles are 4x bigger (about 4x fewer draws), water shader skips its fine ripple layer and
  foam for distant fragments, one distant tile uploaded per frame.

## Heads-up
- Save format bumped to v3 (the terrain changed): "Continue" with an old save starts a fresh world.
- Written without a Kotlin/Android toolchain, so not compiled or run on a device. If the build reports an
  error, the log line points straight at it.

---

# Earlier: VoxelSandbox v7: water, textures, realistic terrain, 200-chunk view distance

## What changed
- **Animated water**: translucent surface drawn in its own pass (`WaterRenderer`, `Shaders.WATER_*`).
  Scrolling ripple normals, gentle vertical swell, Fresnel sky reflection, sun glint, depth-based
  colour/opacity (turquoise shallows -> deep blue), drifting shoreline foam. Works on voxel water
  and on distant water. You can now also place blocks into water.
- **Textures**: atlas is now 32x32 per tile (was 16x16), anisotropic filtering where available.
  New scattered-leaf foliage (midribs, rims, holes) for oak/birch/spruce; richer grass, dirt, stone
  (cracks), sand, bark, coal. Grass sides are mostly green so hills no longer read as brown contour bands.
  New blocks: snow, gravel, sandstone, dry grass, cactus, and cross-shaped plants (tall grass,
  poppy, dandelion, dead bush). All textures stay procedural (`BlockTextures.kt`), no assets.
- **Terrain** (`TerrainShape`, `Climate`, `TerrainGenerator`, `TreeBuilder`): world is now 128 tall
  with sea level 40. Oceans, continents, rolling hills, ridged mountain ranges with snow caps and
  rock/scree on steep slopes, rivers, lakes, beaches, deserts, savanna, taiga/snow, per-biome
  trees (oak, birch, tall spruce, cacti). New worlds spawn on dry land (`findSpawn`).
- **Render distance**: slider maximum is 200 chunks (3,200 blocks). Distant terrain now has 4 levels of
  detail (`FarTerrain`, `FarTerrainRenderer`) so the triangle count stays near a 600-block view's.
  Distant terrain is drawn in its own depth range for stable depth precision at that range.
- **Sky**: gradient sky with a sun (`SkyRenderer`, `Atmosphere`); fog fades into the horizon colour.

## Heads-up
- Save format bumped to v2: worlds saved with v6 cannot be loaded (their terrain no longer exists).
  "Continue" with an old save starts a fresh world.
- Chunk memory budget is now `WorldConfig.RESIDENT_BYTES_PER_CHUNK` (96 KB per chunk).
- This version was written without access to a Kotlin/Android toolchain, so it has not been
  compiled or run on a device. If the build reports an error, the log line points straight at it.

## Tuning knobs
- Water look: constants in `Shaders.WATER_FRAGMENT` (colours, alpha, glint power).
- Sky/fog colours and sun direction: `Atmosphere`.
- Terrain scale/shape: numbers in `TerrainShape.height` (continent frequency 0.00042, mountain
  height 74, hill amplitude), biome thresholds in `Climate.classify`.
- LOD ring distances: `FarTerrain.BAND_OUTER` / `BAND_OVERLAP`.
