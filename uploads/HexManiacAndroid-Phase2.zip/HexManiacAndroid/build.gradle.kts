// Top-level build file: plugin versions are declared once here; each module applies
// only the ones it needs. core-engine is pure Kotlin/JVM (no Android plugin) so that
// the ROM/undo engine stays testable and portable, independent of the UI layer -
// mirrors the Core/WPF split in the original, but with a hard module boundary instead
// of an incidental one.
plugins {
    id("com.android.application") version "8.4.0" apply false
    id("org.jetbrains.kotlin.android") version "2.0.0" apply false
    id("org.jetbrains.kotlin.jvm") version "2.0.0" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.0" apply false
    id("org.jetbrains.kotlin.kapt") version "2.0.0" apply false
    id("com.google.dagger.hilt.android") version "2.51.1" apply false
}
