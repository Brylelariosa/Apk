# HexManiac release R8 rules.
#
# This is short on purpose. The default rules (proguard-android-optimize.txt,
# applied alongside this file) plus each library's own consumer-proguard-rules.pro
# - bundled in the Hilt/Compose/AndroidX AARs and merged in automatically - cover
# this app's actual usage. Checked against what's really in this codebase:
#   - No manual reflection anywhere in app/ or core-engine/
#   - No JSON/Parcelable/Serializable (de)serialization
#   - No dynamic class loading
#   - Hilt usage is vanilla (@HiltAndroidApp, @AndroidEntryPoint, @HiltViewModel
#     with a plain @Inject constructor) - exactly the pattern Hilt's own consumer
#     rules are written for
# So nothing app-specific needs a keep rule to keep working.
#
# What IS here is for readability, not correctness: without it, a release-build
# crash produces an obfuscated, line-number-free stack trace, which would work
# against the build-log-driven debug loop this project uses. Keeping source file
# and line number info costs a small amount of size and is worth it.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
