package com.hexmaniac.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val HexDarkColors = darkColorScheme(
    primary = HexPrimary,
    onPrimary = HexOnPrimary,
    background = HexBackground,
    onBackground = HexOnBackground,
    surface = HexSurface,
    onSurfaceVariant = HexOnSurfaceVariant,
    tertiaryContainer = HexTertiaryContainer,
)

private val HexLightColors = lightColorScheme(
    primary = HexPrimary,
    onPrimary = HexOnPrimary,
)

@Composable
fun HexManiacTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = if (darkTheme) HexDarkColors else HexLightColors,
        content = content,
    )
}
