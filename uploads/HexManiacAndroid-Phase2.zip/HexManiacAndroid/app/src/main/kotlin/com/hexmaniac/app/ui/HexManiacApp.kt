package com.hexmaniac.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.hexmaniac.app.ui.table.TableEditorScreen
import com.hexmaniac.app.ui.table.TableEditorViewModel

/**
 * Top-level screens the app can show. There's no deeper stack yet - see [HexManiacApp]'s doc
 * comment for why this is a plain sealed interface instead of Navigation Compose.
 */
sealed interface HexManiacScreen {
    data object HexViewer : HexManiacScreen
    data object TableEditor : HexManiacScreen
}

/**
 * Root composable: owns which top-level screen is showing, routes the system back button, and
 * re-syncs each destination's ViewModel from [com.hexmaniac.app.data.RomSessionRepository] at
 * the moment it becomes visible - an edit made on the other screen wouldn't otherwise be
 * reflected, since each ViewModel's `uiState` is its own plain `mutableStateOf`, not something
 * that reacts to the repository automatically. See `syncFromSession()` on
 * [HexViewerViewModel]/[TableEditorViewModel].
 *
 * Deliberately not Jetpack Navigation Compose: with exactly two top-level tool screens and no
 * deep links or nested graphs, a NavHost is more machinery than the app needs right now, and
 * would add two more dependency versions this sandbox has no way to compile-check (see the
 * README's build-verification note) for a problem this file already solves in a few lines.
 * Worth revisiting once a later phase needs an actual multi-level back stack.
 */
@Composable
fun HexManiacApp(
    hexViewerViewModel: HexViewerViewModel,
    tableEditorViewModel: TableEditorViewModel,
    onOpenRomRequested: () -> Unit,
    onSaveRomRequested: () -> Unit,
) {
    var screen by remember { mutableStateOf<HexManiacScreen>(HexManiacScreen.HexViewer) }

    fun goToHexViewer() {
        hexViewerViewModel.syncFromSession()
        screen = HexManiacScreen.HexViewer
    }

    fun goToTableEditor(prefillAddress: Int?) {
        tableEditorViewModel.syncFromSession(prefillAddress)
        screen = HexManiacScreen.TableEditor
    }

    BackHandler(enabled = screen != HexManiacScreen.HexViewer) { goToHexViewer() }

    when (screen) {
        HexManiacScreen.HexViewer -> HexViewerScreen(
            viewModel = hexViewerViewModel,
            onOpenRomRequested = onOpenRomRequested,
            onSaveRomRequested = onSaveRomRequested,
            onOpenTableEditor = { address -> goToTableEditor(address) },
        )
        HexManiacScreen.TableEditor -> TableEditorScreen(
            viewModel = tableEditorViewModel,
            onBack = { goToHexViewer() },
            onOpenRomRequested = onOpenRomRequested,
        )
    }
}
