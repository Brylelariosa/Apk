package com.hexmaniac.app

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class HexManiacApplication : Application()
