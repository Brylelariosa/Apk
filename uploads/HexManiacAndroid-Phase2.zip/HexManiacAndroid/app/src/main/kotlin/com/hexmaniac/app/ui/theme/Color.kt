package com.hexmaniac.app.ui.theme

import androidx.compose.ui.graphics.Color

val HexBackground = Color(0xFF121212)
val HexSurface = Color(0xFF1E1E1E)
val HexPrimary = Color(0xFF4FC3F7)
val HexOnPrimary = Color(0xFF00344A)
val HexTertiaryContainer = Color(0xFF3A2E1F) // pointer-byte highlight
val HexOnBackground = Color(0xFFE0E0E0)
val HexOnSurfaceVariant = Color(0xFF9E9E9E) // address gutter text
