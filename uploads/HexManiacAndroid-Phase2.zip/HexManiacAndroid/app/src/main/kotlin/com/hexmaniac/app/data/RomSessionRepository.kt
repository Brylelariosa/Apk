package com.hexmaniac.app.data

import android.content.ContentResolver
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.hexmaniac.core.model.PointerScanner
import com.hexmaniac.core.model.RomDataModel
import com.hexmaniac.core.model.Run
import com.hexmaniac.core.undo.ModelDelta
import com.hexmaniac.core.undo.UndoRedoStack
import java.io.ByteArrayOutputStream
import java.util.BitSet
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Owns the currently-loaded ROM - bytes, runs, and undo history - as a single [Singleton]
 * source of truth. Every screen (hex viewer, table editor, and whatever later phases add) reads
 * and writes through here instead of holding its own copy, so an edit made on one screen is
 * immediately visible, undoable, and included when saving from any other.
 *
 * Extracted out of what was originally [com.hexmaniac.app.ui.HexViewerViewModel]'s private state,
 * at the point a second screen needed the same ROM - see that class's doc comment. Screens are
 * responsible for pulling fresh values from [session] when they become visible again (see
 * `syncFromSession()` on each screen's ViewModel); this class doesn't push updates to them, to
 * avoid taking on a Flow/StateFlow dependency for two screens that don't need one yet.
 */
@Singleton
class RomSessionRepository @Inject constructor() {

    private var model: RomDataModel? = null
    private var undoRedo = UndoRedoStack()

    // BitSet, not Set<Int>: a 32MB ROM can have millions of pointer-covered bytes - one bit
    // each instead of a boxed Integer each matters at that scale (same reasoning as the
    // original HexViewerViewModel had for this field).
    private var pointerHighlights = BitSet()

    var session by mutableStateOf(RomSession())
        private set

    /** The live model, for callers that need direct read/write access (e.g. table field I/O). */
    val currentModel: RomDataModel? get() = model

    val pointerByteCount: Int get() = pointerHighlights.cardinality()

    fun load(resolver: ContentResolver, uri: Uri): Boolean {
        val bytes = resolver.openInputStream(uri)?.use { input ->
            val buffer = ByteArrayOutputStream()
            input.copyTo(buffer)
            buffer.toByteArray()
        } ?: return false

        model = RomDataModel(bytes)
        undoRedo = UndoRedoStack()
        pointerHighlights = BitSet()
        session = RomSession(romLoaded = true, romName = uri.lastPathSegment ?: "ROM", romSize = bytes.size)
        return true
    }

    fun save(resolver: ContentResolver, uri: Uri): Boolean {
        val m = model ?: return false
        resolver.openOutputStream(uri)?.use { out -> out.write(m.snapshotBytes()) }
        return true
    }

    fun byteAt(index: Int): Int? = model?.let { if (index < it.size) it[index] else null }

    fun isPointerByte(index: Int): Boolean = pointerHighlights.get(index)

    fun runAt(address: Int): Run? = model?.getRunAt(address)

    /**
     * Registers a newly-recognized [Run] (e.g. a table a user just defined). Not undoable -
     * only byte content goes through [applyEdit]; recognizing a shape in existing bytes isn't a
     * content edit, same as how the original's pointer scan never touched undo history either.
     */
    fun addRun(run: Run) {
        model?.addRun(run)
        bumpRevision()
    }

    /**
     * Runs [edit] as one undoable step, then pushes it. [edit] receives the live model and a
     * fresh [ModelDelta] token to write through - same contract [ModelDelta.setByte] itself uses.
     * A no-op [edit] is safe: [UndoRedoStack.push] already ignores empty deltas.
     */
    fun applyEdit(edit: (RomDataModel, ModelDelta) -> Unit) {
        val m = model ?: return
        val delta = ModelDelta()
        edit(m, delta)
        undoRedo.push(delta)
        bumpRevision()
    }

    fun scanForPointers(): Int {
        val m = model ?: return 0
        val found = PointerScanner.scan(m)
        val bits = BitSet(m.size)
        for (run in found) for (i in run.start until run.start + run.length) bits.set(i)
        pointerHighlights = bits
        bumpRevision()
        return found.size
    }

    fun undo() {
        val m = model ?: return
        undoRedo.undo(m)
        bumpRevision()
    }

    fun redo() {
        val m = model ?: return
        undoRedo.redo(m)
        bumpRevision()
    }

    private fun bumpRevision() {
        session = session.copy(
            canUndo = undoRedo.canUndo,
            canRedo = undoRedo.canRedo,
            revision = session.revision + 1,
        )
    }
}

data class RomSession(
    val romLoaded: Boolean = false,
    val romName: String? = null,
    val romSize: Int = 0,
    val canUndo: Boolean = false,
    val canRedo: Boolean = false,
    val revision: Int = 0,
)
