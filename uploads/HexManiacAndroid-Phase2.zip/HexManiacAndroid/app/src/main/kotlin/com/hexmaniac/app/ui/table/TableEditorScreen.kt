package com.hexmaniac.app.ui.table

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hexmaniac.core.model.TableRun

// Text actions instead of icons, same reasoning as HexViewerScreen: material-icons-extended
// was deliberately dropped for APK size, so this screen follows the same convention.

@OptIn(ExperimentalMaterial3Api::class) // TopAppBar is experimental in this Material3 BOM
@Composable
fun TableEditorScreen(
    viewModel: TableEditorViewModel,
    onBack: () -> Unit,
    onOpenRomRequested: () -> Unit,
) {
    val state = viewModel.uiState
    val table = state.table

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Table Editor", style = MaterialTheme.typography.titleMedium) },
                navigationIcon = { TextButton(onClick = onBack) { Text("Back") } },
                actions = {
                    Row(modifier = Modifier.horizontalScroll(rememberScrollState())) {
                        if (table != null) {
                            TextButton(onClick = viewModel::clearTable) { Text("New") }
                        }
                        TextButton(onClick = viewModel::undo, enabled = state.canUndo) { Text("Undo") }
                        TextButton(onClick = viewModel::redo, enabled = state.canRedo) { Text("Redo") }
                    }
                },
            )
        },
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {
            when {
                !state.romLoaded -> EmptyRomState(onOpenRomRequested)
                table == null -> DefineTableForm(viewModel, state)
                else -> TableGrid(viewModel, table, state, modifier = Modifier.weight(1f))
            }
            if (table != null) {
                EditCellBar(viewModel, table, state)
            }
            Text(
                text = state.statusMessage,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
            )
        }
    }
}

@Composable
private fun EmptyRomState(onOpenRomRequested: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("No ROM loaded", style = MaterialTheme.typography.titleMedium)
        Text(
            "Open a .gba file before defining a table.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 8.dp, bottom = 16.dp),
        )
        TextButton(onClick = onOpenRomRequested) { Text("Open ROM") }
    }
}

@Composable
private fun DefineTableForm(viewModel: TableEditorViewModel, state: TableEditorUiState) {
    Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
        Text("Define a table", style = MaterialTheme.typography.titleMedium)
        Text(
            "Address in hex, then a format like [hp. attack. name\"\"10 next<>]20 - one marker " +
                "per field: '.' 1 byte, ':' 2 bytes, ':.' 3 bytes, '::' 4 bytes, '\"\"N' an N-byte " +
                "text field, '<>' a pointer. The number after ']' is the row count.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 4.dp, bottom = 16.dp),
        )
        OutlinedTextField(
            value = state.addressText,
            onValueChange = viewModel::updateAddressText,
            label = { Text("Start address (hex)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
            value = state.formatText,
            onValueChange = viewModel::updateFormatText,
            label = { Text("Format") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(modifier = Modifier.height(12.dp))
        TextButton(onClick = viewModel::defineTable) { Text("Define") }
    }
}

@Composable
private fun TableGrid(
    viewModel: TableEditorViewModel,
    table: TableRun,
    state: TableEditorUiState,
    modifier: Modifier = Modifier,
) {
    // One shared ScrollState for the header row and every data row, so they scroll horizontally
    // together without a third-party table library. Fine at this scale (a handful of columns,
    // only visible rows composed); a much wider table would want a smarter approach.
    val horizontalScrollState = rememberScrollState()
    Column(modifier = modifier) {
        Row(modifier = Modifier.horizontalScroll(horizontalScrollState)) {
            RowIndexHeaderCell()
            table.segments.forEach { segment -> HeaderCell(segment.name) }
        }
        LazyColumn(modifier = Modifier.fillMaxWidth()) {
            // key folds in revision for the same reason HexViewerScreen's grid does: cellText()
            // reads a plain field, not Compose State, so this is what tells Compose to re-read
            // after an edit instead of showing a stale value.
            items(count = table.elementCount, key = { row -> "$row:${state.revision}" }) { row ->
                Row(modifier = Modifier.horizontalScroll(horizontalScrollState)) {
                    RowIndexCell(row)
                    table.segments.indices.forEach { fieldIndex ->
                        DataCell(
                            text = viewModel.cellText(row, fieldIndex),
                            selected = row == state.selectedRow && fieldIndex == state.selectedField,
                            onClick = { viewModel.selectCell(row, fieldIndex) },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun RowIndexHeaderCell() {
    Box(modifier = Modifier.width(40.dp).padding(4.dp)) {
        Text("#", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun RowIndexCell(row: Int) {
    Box(modifier = Modifier.width(40.dp).padding(4.dp)) {
        Text(
            text = row.toString(),
            fontFamily = FontFamily.Monospace,
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun HeaderCell(name: String) {
    Box(modifier = Modifier.width(96.dp).padding(4.dp)) {
        Text(name, style = MaterialTheme.typography.labelSmall, maxLines = 1)
    }
}

@Composable
private fun DataCell(text: String, selected: Boolean, onClick: () -> Unit) {
    val background = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.background
    val textColor = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onBackground
    Box(
        modifier = Modifier
            .width(96.dp)
            .padding(2.dp)
            .background(background)
            .clickable(onClick = onClick)
            .padding(6.dp),
    ) {
        Text(text = text, fontFamily = FontFamily.Monospace, fontSize = 12.sp, maxLines = 1, color = textColor)
    }
}

@Composable
private fun EditCellBar(viewModel: TableEditorViewModel, table: TableRun, state: TableEditorUiState) {
    val row = state.selectedRow
    val field = state.selectedField
    if (row == null || field == null) return

    var text by remember(row, field, state.revision) { mutableStateOf(viewModel.cellText(row, field)) }
    Row(
        modifier = Modifier.fillMaxWidth().padding(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = "${table.segments[field].name}:",
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(end = 8.dp),
        )
        OutlinedTextField(
            value = text,
            onValueChange = { text = it },
            modifier = Modifier.weight(1f),
            singleLine = true,
        )
        TextButton(onClick = { viewModel.writeSelectedCell(text) }) { Text("Set") }
    }
}
