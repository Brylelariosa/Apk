package com.hexmaniac.app

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import com.hexmaniac.app.ui.HexManiacApp
import com.hexmaniac.app.ui.HexViewerViewModel
import com.hexmaniac.app.ui.table.TableEditorViewModel
import com.hexmaniac.app.ui.text.TextEditorViewModel
import com.hexmaniac.app.ui.theme.HexManiacTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    private val hexViewerViewModel: HexViewerViewModel by viewModels()
    private val tableEditorViewModel: TableEditorViewModel by viewModels()
    private val textEditorViewModel: TextEditorViewModel by viewModels()

    // Loading/saving stays wired to the hex viewer's ViewModel (registerForActivityResult must
    // be called before the Activity reaches STARTED, so it can't move into a Composable) - both
    // screens see the result either way, since loadRom/saveRom write through the shared
    // RomSessionRepository rather than to view-local state.
    private val openRomLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            uri?.let { hexViewerViewModel.loadRom(contentResolver, it) }
        }

    private val saveRomLauncher =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri: Uri? ->
            uri?.let { hexViewerViewModel.saveRom(contentResolver, it) }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            HexManiacTheme {
                HexManiacApp(
                    hexViewerViewModel = hexViewerViewModel,
                    tableEditorViewModel = tableEditorViewModel,
                    textEditorViewModel = textEditorViewModel,
                    onOpenRomRequested = { openRomLauncher.launch(arrayOf("*/*")) },
                    onSaveRomRequested = { saveRomLauncher.launch(hexViewerViewModel.uiState.romName ?: "rom.gba") },
                )
            }
        }
    }
}
