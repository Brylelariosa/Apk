package com.hexmaniac.app.ui

import android.content.ContentResolver
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.hexmaniac.app.data.RomSessionRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

data class HexViewerUiState(
    val romLoaded: Boolean = false,
    val romName: String? = null,
    val romSize: Int = 0,
    val bytesPerRow: Int = 16,
    val rowCount: Int = 0,
    val selectedIndex: Int? = null,
    val pointerByteCount: Int = 0,
    val canUndo: Boolean = false,
    val canRedo: Boolean = false,
    val statusMessage: String = "Open a ROM to begin.",
    // Bumped on every mutation that doesn't otherwise change uiState's identity, so the
    // (lazily-composed, engine-backed) byte grid knows to recompose after an edit or scan.
    val revision: Int = 0,
)

/**
 * Screen-local state (selection, status text) layered over [RomSessionRepository]'s shared ROM
 * session - see that class's doc comment for why the ROM itself lives there now instead of here.
 * [byteAt]/[isPointerByte] read straight through to the repository on every call rather than
 * caching, so hex viewer and table editor are always looking at the same bytes.
 */
@HiltViewModel
class HexViewerViewModel @Inject constructor(
    private val romSession: RomSessionRepository,
) : ViewModel() {

    var uiState by mutableStateOf(HexViewerUiState())
        private set

    /**
     * Call when this screen becomes visible again (e.g. navigating back from the table editor),
     * since edits may have happened there while this screen wasn't showing. loadRom/saveRom
     * don't need an equivalent - this screen is the only one that calls them, so nothing else
     * can leave romLoaded/romName/romSize stale the way canUndo/canRedo/revision can go stale.
     */
    fun syncFromSession() {
        uiState = uiState.copy(
            canUndo = romSession.session.canUndo,
            canRedo = romSession.session.canRedo,
            revision = romSession.session.revision,
        )
    }

    fun loadRom(resolver: ContentResolver, uri: Uri) {
        uiState = if (romSession.load(resolver, uri)) {
            val size = romSession.session.romSize
            HexViewerUiState(
                romLoaded = true,
                romName = romSession.session.romName,
                romSize = size,
                rowCount = (size + 15) / 16,
                statusMessage = "Loaded $size bytes.",
            )
        } else {
            uiState.copy(statusMessage = "Could not open that file.")
        }
    }

    fun saveRom(resolver: ContentResolver, uri: Uri) {
        uiState = if (romSession.save(resolver, uri)) {
            uiState.copy(statusMessage = "Saved ${romSession.session.romSize} bytes.")
        } else {
            uiState.copy(statusMessage = "Nothing to save yet.")
        }
    }

    fun byteAt(index: Int): Int? = romSession.byteAt(index)

    fun isPointerByte(index: Int): Boolean = romSession.isPointerByte(index)

    fun selectByte(index: Int) {
        uiState = uiState.copy(selectedIndex = index)
    }

    fun writeSelectedByte(hexValue: String) {
        val index = uiState.selectedIndex ?: return
        val value = hexValue.toIntOrNull(16)
        if (value == null) {
            uiState = uiState.copy(statusMessage = "'$hexValue' isn't valid hex.")
            return
        }
        if (value !in 0..255) {
            uiState = uiState.copy(statusMessage = "Byte value must be 00-FF.")
            return
        }
        romSession.applyEdit { model, token -> token.setByte(model, index, value) }
        refreshAfterEdit("Set byte ${index.toHexAddress()} = ${value.toString(16).uppercase()}")
    }

    fun undo() {
        romSession.undo()
        refreshAfterEdit("Undid last edit.")
    }

    fun redo() {
        romSession.redo()
        refreshAfterEdit("Redid edit.")
    }

    fun scanForPointers() {
        val count = romSession.scanForPointers()
        uiState = uiState.copy(
            statusMessage = "Found $count candidate pointers.",
            pointerByteCount = romSession.pointerByteCount,
            canUndo = romSession.session.canUndo,
            canRedo = romSession.session.canRedo,
            revision = romSession.session.revision,
        )
    }

    private fun refreshAfterEdit(message: String) {
        uiState = uiState.copy(
            statusMessage = message,
            canUndo = romSession.session.canUndo,
            canRedo = romSession.session.canRedo,
            revision = romSession.session.revision,
        )
    }
}

private fun Int.toHexAddress(): String = "0x" + toString(16).uppercase().padStart(6, '0')
