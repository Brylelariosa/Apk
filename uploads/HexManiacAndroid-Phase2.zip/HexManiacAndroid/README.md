# HexManiac Android

A native Android rewrite of [HexManiacAdvance](https://github.com/haven1433/HexManiacAdvance) (HMA),
the C#/WPF hex editor for GBA Pokémon ROM hacking. HMA itself isn't portable (WPF/WinForms are
Windows-only, and its scripting system depends on IronPython) - this rebuilds the feature set
natively in Kotlin, using HMA's source as the reference spec rather than code to reuse.

## Status: Phase 3 - text editor

Phase 1 was the foundation (open/view/edit raw bytes, undo/redo, pointer scan). Phase 2 added
table editing. Phase 3 adds real PCS text: a dedicated text editor for free-floating strings, PCS
encoding for both that and table text fields (replacing the raw-Latin-1 placeholder), and
auto-repoint when edited text no longer fits where it was.

**Working (Phase 1):**
- Open any file via SAF, view it as a scrollable hex grid (address | hex | tap-to-edit)
- Byte-accurate undo/redo, tracked per edit
- Pointer auto-detection scan (GBA convention: 4-byte LE value, top byte `0x08`/`0x09`,
  value − `0x08000000` = file offset), with detected bytes highlighted in the grid
- Save back to a file via SAF

**Working (Phase 2):**
- Define a table by address + format string (`[hp. attack: name""10 next<>]20` - see
  `TableFormat`'s doc comment for the exact marker syntax and what's deliberately not supported
  yet: enum fields, bit arrays, calculated fields, auto-detected or table-linked element counts)
- Browse it as a scrollable, horizontally-scrollable grid; tap a cell to edit its value
- Numeric, pointer, and text fields (real PCS as of Phase 3 - see below), each validated on write
- Hex viewer, table editor, and text editor all share one ROM session (`RomSessionRepository`) -
  an edit made on any screen is immediately visible, undoable, and included when saving from
  another
- `core-engine` unit tests covering all three phases (pointer round-trip, scanner, undo/redo
  ordering, run containment lookup at boundaries, format-string parsing and its error messages,
  table layout math, every field type's read/write round-trip, PCS encode/decode, free-space
  search, and pointer repointing)

**Working (Phase 3):**
- `PcsString`: real PCS character encoding/decoding - see its doc comment for exactly which parts
  of the real format this covers (every printable character plus the common single-byte and
  multi-byte control codes, all byte-exact) and which it deliberately doesn't (per-game
  color/button/buffer macro names, pixel-width overflow checking)
- Table text fields now decode/encode as real PCS instead of raw Latin-1 - same fields, same
  `TableRun.readText`/`writeText` call sites, just correct now (see the "known rough edges" note
  v3 left about this)
- A new Text Editor screen: type an address, edit the decoded string in a multi-line field, Set
  to write it back
- Auto-repoint: if the saved text's PCS encoding no longer fits in its current slot, it's
  relocated to freshly-found free space and every pointer that targeted the old address is
  rewritten to the new one - all as one atomic, undoable edit (`StringRun.writeText`, backed by
  `Repointer`)

**Not yet implemented** (see the phase order below): images, maps, code/scripts, patches. Table
and string *recognition* are both still manual (you type the address) - HMA's own auto-detection
relies on a per-game hardcoded table/anchor database that's out of scope here. PCS's per-game
macro names (`[player]`, color codes, button names) aren't decoded to friendly text either - see
`PcsString`'s doc comment for the byte-exact fallback that stands in for them.

## Architecture

Two modules, one direction of dependency:

```
core-engine/   pure Kotlin/JVM, zero Android dependency
  model/       Run (sealed interface): UnknownRun, PointerRun, TableRun, StringRun
               FieldSegment (sealed interface): NumericField, PointerField, TextField
               RomDataModel, PointerScanner, TableFormat (format-string parser)
               PcsString (PCS text encode/decode), Repointer (free-space search + repointing)
  undo/        ModelDelta, UndoRedoStack

app/           Android application (Compose, Material3, Hilt)
  data/        RomSessionRepository - single shared source of truth for the loaded ROM
  ui/          HexManiacApp (screen router), HexManiacTopBar, EmptyRomState,
               HexViewerViewModel, HexViewerScreen, theme/
  ui/table/    TableEditorViewModel, TableEditorScreen
  ui/text/     TextEditorViewModel, TextEditorScreen
```

`core-engine` doesn't know Android exists, on purpose - it's plain JVM, so its tests run in
milliseconds with no emulator, and it stays reusable if a desktop or CLI front end ever makes
sense. `app` depends on it; never the reverse.

**Where this deliberately differs from the original:**
- `Run` is a Kotlin `sealed interface` (`UnknownRun`, `PointerRun`, `TableRun`, and now
  `StringRun`). Every exhaustive `when (run)` elsewhere fails to compile until updated when a new
  run type is added - HMA's C# base-class version doesn't get that check for free. `FieldSegment`
  (a table row's fields: `NumericField`/`PointerField`/`TextField`) is sealed for the same reason.
- All byte mutation is `internal` on `RomDataModel`; the only public write path is through a
  `ModelDelta`. It's not possible to accidentally make a non-undoable edit. Table field writes
  (`TableRun.writeNumeric`/`writePointerField`/`writeText`) and `StringRun.writeText` are all built
  on the same `ModelDelta` contract, not a parallel one - true even for `StringRun.writeText`'s
  repoint case, where freeing the old bytes, writing the new ones, and rewriting every pointer
  that targeted the old address all happen inside one `ModelDelta`.
- Repointing a string that's outgrown its slot finds new free space and rewrites every reference
  to it via one live linear scan (`Repointer.repointReferences`), not a persisted reverse-pointer
  index - `PointerScanner`'s own doc comment already covers why this project doesn't keep one of
  those. Same cost class as the pointer-scan button the app already has, just triggered by Save
  instead of Scan.
- Pointer-highlight membership uses `BitSet` instead of a boxed `Set<Int>` - relevant once a ROM
  (up to 32MB) has a dense pointer table; one bit per byte instead of ~20 bytes per entry.
- The ROM session (bytes, runs, undo history) moved out of `HexViewerViewModel` and into
  `RomSessionRepository`, a `@Singleton` every screen's ViewModel injects, once a second screen
  (the table editor) needed the same ROM. Each ViewModel still owns its own screen-local state
  (selection, form text, status message) and pulls fresh shared state from the repository
  imperatively - explicitly on mutation, and via a `syncFromSession()` call at the moment a
  screen becomes visible again - rather than reactively via `StateFlow`/`collectAsState`. That
  keeps this at zero new dependencies; if a screen's state needs finer-grained reactivity than
  "resync on becoming visible," that's the point to reconsider it.
- Screen switching (`HexManiacApp`) is a hand-rolled sealed-interface + `when`, not Jetpack
  Navigation Compose - see that file's doc comment for why, and when to revisit it.

## Build order (why this order)

1. **Data engine + hex viewer** *(done)* - nothing else works without it
2. **Table editor** *(done)* - Pokémon/move/item/trainer grids; highest value-to-effort,
   most-used day to day. Format-string-driven and manually addressed for now (see Status above);
   auto-detected/named tables are a natural follow-up but aren't required to make this useful.
3. **Text editor** *(this phase)* - PCS string encoding, auto-repoint on edit
4. **Image editor** - sprites, tilemaps, palettes
5. **Map editor** - maps, events, connections, warps, wild encounters
6. **Code editor + patch DSL** - Thumb disassembler, event/battle/AI scripts, the `.hma` patch
   format - hardest subsystem, saved for once the engine's proven under real use

IronPython's live-scripting console (table automation) has no clean Android equivalent and isn't
scoped into any phase yet; it's the one piece of the original worth deferring rather than
matching feature-for-feature.

## Building

Same pipeline as the rest of the projects - zip this folder, push through ZipApkBuilder. No NDK/
CMake needed (pure Kotlin, no native code), though the workflow installing them anyway is
harmless. Toolchain: JDK 17, Gradle 8.6, AGP 8.4.0, Kotlin 2.0.0.

Local validation note: this sandbox had a JRE but no `javac`/network, so the core algorithms
(pointer encode/decode, scanning, undo/redo ordering, run lookup at boundaries) were verified with
a throwaway Python harness before the Kotlin was written, then ported into the real `core-engine`
tests above. Gradle/Kotlin compilation itself only happens for real in CI, which is where the two
issues below actually surfaced.

## v2 - CI fixes + APK size pass

**Fixed, from run 1559's failure log:**
- `HexViewerScreen.kt` explicitly imported `androidx.compose.foundation.layout.weight`. That path
  resolves to Compose Foundation's *internal* `RowColumnParentData.weight` property, not the
  `ColumnScope`/`RowScope` member extension the code actually wants - hence
  `Cannot access 'val RowColumnParentData?.weight: Float': it is internal in file`. Fix: delete the
  import. `Modifier.weight(1f)` needs no import at all inside a `Column`/`Row` content lambda; it
  resolves via the implicit `ColumnScope`/`RowScope` receiver. (This is the same class of bug as
  Outcrop's outstanding `.weight(1f)` import error - worth checking there too.)
- `TopAppBar` is `@ExperimentalMaterial3Api` in Compose BOM 2024.06.00, which is a hard compile
  error without an opt-in, not just a warning. Fix: `@OptIn(ExperimentalMaterial3Api::class)` on
  `HexViewerScreen`.

**APK size, no features removed, no ABI split:**
- ABI splits wouldn't do anything here anyway - there's no native code/JNI, so there's nothing
  architecture-specific being bundled in the first place.
- `isMinifyEnabled = true` + `isShrinkResources = true` for release only (debug stays fast/
  unminified for iteration). This is the actual lever: R8 strips unreachable code, which matters
  most for `material3` since the app only calls a handful of its components, and shrinkResources
  drops resources nothing reachable references. `proguard-rules.pro` documents why this is safe
  for this codebase specifically (no reflection, no serialization, vanilla Hilt usage that its own
  consumer rules already cover) and keeps source-file/line-number info so release crashes still
  produce a readable stack trace.
- `resourceConfigurations += setOf("en")` in `defaultConfig` - the app has zero i18n of its own, so
  this only drops *other libraries'* bundled non-English strings (mostly accessibility labels),
  not anything the app presents. Flagging this one specifically since it's the one change here
  that's a real trade-off rather than a pure win: a non-English device will see those library
  labels fall back to English instead of their own language.
- No dependency changes needed - `material-icons-extended` was already avoided (see `app/build.gradle.kts`).

Compiles cleanly against the CI log's actual failure now; the R8 config is reasoned through but,
same as everything Gradle-related, not locally build-tested (no network in this sandbox) - worth
double-checking the release APK actually launches and behaves correctly on-device, not just that
CI goes green, since R8 issues are sometimes runtime-only.

## v3 - Phase 2: table editor

**New in `core-engine`:** `FieldSegment` (`NumericField`/`PointerField`/`TextField`), `TableFormat`
(the `[name.]N`-style format-string parser - deliberate subset, see its doc comment), `TableRun`
(the row-major table `Run` plus typed field read/write). `RomDataModel.readPointer`/`writePointer`
were refactored to share a new `internal readLittleEndian`/`writeLittleEndian` pair with table
numeric fields, instead of each re-deriving little-endian byte packing - behavior-preserving
(same bounds checks, same GBA-address validation stays on the pointer-specific methods), covered
by the existing pointer tests plus new ones for the shared primitive via table fields.

**New in `app`:** `RomSessionRepository` (`data/`) is now the single owner of the loaded ROM;
`HexViewerViewModel` was refactored to delegate to it rather than hold the model/undo stack
itself - its public API to `HexViewerScreen` is unchanged, so that screen needed no changes
beyond a new "Tables" button. `TableEditorViewModel`/`TableEditorScreen` (`ui/table/`) are new:
address+format form when no table is open, otherwise a scrollable editable grid. `HexManiacApp`
is a new small root composable that switches between the two screens and keeps them in sync with
the repository - see its doc comment for why that's a hand-rolled sealed `when` rather than
Navigation Compose (short version: zero new dependency versions to get wrong in a sandbox with no
way to compile-check them, for a two-screen app that doesn't need a real back stack yet).

**Known rough edges, honestly:**
- Table editor has no Save button of its own - go back to the hex viewer to save, since both
  screens share the same ROM bytes anyway. Small, but worth a real button if this gets used a lot.
- Text fields are raw Latin-1 with a `0xFF` terminator, not the game's actual PCS character map
  (that's Phase 3). The byte-level contract (terminator + zero padding) is deliberately the same
  one PCS will use, so upgrading a field's decoding later shouldn't change what's on disk.
- No enum-typed fields (e.g. a move's type rendered by name instead of a raw byte), bit arrays,
  or calculated fields - `TableFormat` throws a specific message rather than misparsing these.
- Table *recognition* is manual (you type the address + format); there's no hardcoded/per-game
  table database like HMA's own. Once defined, a table is remembered for the rest of the session
  (`RomSessionRepository` keeps it in the model's `runs`), just not before that.

Same caveat as v2, worth repeating rather than assuming it stopped applying: this sandbox has a
JDK but no Android SDK, no Gradle, and no network, so none of this was actually compiled here.
Every method signature this phase depends on (`ModelDelta.setByte`, `RomDataModel.get`/
`readPointer`/`writePointer`, `UndoRedoStack.push`, `Run`'s properties) was checked against the
real Phase 1 source rather than assumed, and the new engine logic (format parsing, table layout
math, every field type's read/write) has direct unit test coverage - but the same
build-verification gap as always applies to the Compose/Hilt wiring specifically. Worth a real
`./gradlew build` (or a CI run) before trusting it further, same as v2 was.

## v4 - top bar title fix + table editor Save

**Fixed:** the title in every screen's top bar was wrapping one or two characters per line
("HexManiac" as "He" / "xM" / "ani" / "ac") instead of displaying normally. Root cause: Material3's
`TopAppBar` measures its `actions` slot first, at up to the bar's *entire* width, and only gives
`title` whatever's left over (`TopAppBarLayout` in Material3's `AppBar.kt`) - harmless for a
couple of icon buttons, but both screens' actions are full-width text buttons in a
`horizontalScroll` row, and on a narrow phone their natural width claims nearly the whole bar,
leaving the title only a handful of pixels to wrap into. Fix: `HexManiacTopBar` (`app/ui/`), a
small composable shared by both screens - title on its own full-width row, the scrollable actions
row below it, so the title can't be starved no matter how many actions a future screen adds.
Bonus: this also drops the `TopAppBar`/`ExperimentalMaterial3Api` opt-in both screens needed (see
the v2 notes on why that opt-in existed in the first place) - one less experimental API this BOM
could break on a future bump.

**New:** the table editor now has its own Save button, wired to the same `onSaveRomRequested`
callback (and so the same `RomSessionRepository`-backed SAF write) the hex viewer already used -
closes the "no Save button of its own" rough edge the v3 notes flagged. `HexManiacApp` now threads
`onSaveRomRequested` to both screens instead of just the hex viewer; `MainActivity` needed no
changes, since that callback was already screen-agnostic.

Same caveat as v2 and v3: this sandbox still has no Android SDK, no Gradle, and no network, so
none of this was compiled here either - `HexManiacTopBar`'s Compose usage (a real `Row`/`Column`
this time, not `TopAppBar`'s internal layout, so `Modifier.weight` resolves the normal way) was
checked by hand against the same Material3 BOM the rest of the app targets, but a real
`./gradlew build` is worth running before trusting it further.

## v5 - Phase 3: text editor

**New in `core-engine`:** `PcsString` (PCS character encode/decode - see its doc comment for the
exact subset covered), `StringRun` (a free-floating PCS string `Run`, plus `readText`/`writeText`
extensions - the latter does the actual auto-repoint), `Repointer` (`findFreeSpace` +
`repointReferences`, the two primitives `writeText` composes). `RomDataModel` gained `removeRun`,
the inverse of the existing `addRun` - needed once a run's address can change out from under it
(a relocated string), which nothing before this phase did. `TableRun.readText`/`writeText` now
delegate to `PcsString` instead of the raw-Latin-1 placeholder from v3 - same call sites, same
byte-level contract (terminator + zero padding), different (correct) byte values, which is exactly
what the v3 notes said this upgrade would mean. One existing test checked a raw byte value
directly rather than going through `readText`; updated to the real PCS value instead of just
made to pass.

**New in `app`:** `TextEditorViewModel`/`TextEditorScreen` (`ui/text/`) - address form when
nothing's open, otherwise a multi-line editable field and a Set button, following the same
open/edit/status-message shape `TableEditorViewModel` already established. `HexViewerScreen` got
a "Text" button next to "Tables", passing the current hex-grid selection through as a prefill
address, same pattern "Tables" already used. `HexManiacApp` grew a third `HexManiacScreen` case -
still a flat `when`, no more reason to reach for Navigation Compose with three screens than with
two (see that file's updated doc comment). Two small extractions along the way, same spirit as
`HexManiacTopBar` last pass: `EmptyRomState` (Table Editor's "no ROM loaded" body) moved to
`app/ui/` so Text Editor could use it too instead of a second copy; `TableEditorViewModel` now
catches `PcsEncodingException` around its text-field write, the same way it already caught
`TableFormatException` around table definition - a real fix, not new scope: `TableRun.writeText`
can throw that now that it runs real PCS encoding, and an uncaught exception there would have
crashed the screen on the first unsupported character someone typed into a name field.

**Known rough edges, honestly:**
- PCS's per-game macro layer - `[player]`/`[rival]`/buffer-variable names, per-game color codes,
  button-icon names - isn't decoded to a friendly name; those bytes round-trip byte-exactly as
  raw hex escapes instead (`\CC`, `\btn`, ...). Naming them needs a detected game code and
  per-game tables this project doesn't have yet. See `PcsString`'s doc comment for the complete
  list of what is and isn't covered.
- Table field text truncation (when saved text is longer than the fixed-width slot) is
  byte-level, not escape-aware - content that used a multi-byte PCS escape right at the cut point
  could truncate mid-escape. Free-floating strings don't have this problem (they repoint instead
  of truncating); only table cells do, and only ones long enough to hit the limit in the first
  place, which named/labeled fields rarely are.
- String *recognition* is manual, same as tables - type the address, no hardcoded per-game string
  table. Once opened, a string is remembered for the rest of the session, same as a table.
- A relocated string's *new* run registration isn't itself undoable, only the underlying bytes
  are - hit undo after a repoint and the bytes correctly revert, but the session may still show
  the string "open" at its new (now-reverted-away-from) address until you navigate back to the
  old one. `TableEditorViewModel.defineTable`'s own run registration already wasn't undoable
  either (see v3); this phase inherits that rather than fixing it, since fixing it for real means
  threading run-registration changes through `ModelDelta` too - a bigger change than this phase's
  scope.
- `findFreeSpace` treats any run of 0xFF bytes not already claimed by a registered `Run` as
  available. That's the right convention for GBA ROMs (unused space is 0xFF-filled - it's also
  why 0xFF is the PCS terminator), but this app doesn't recognize every byte's purpose yet, so a
  region that's genuinely meaningful data, happens to be 0xFF, and hasn't been scanned or defined
  as a run could theoretically be treated as free. Same class of risk as HMA's own free-space
  search, not something new here.

Same caveat as v2 through v4: this sandbox still has no Android SDK, no Gradle, and no network, so
none of this was compiled here either. The PCS character table was transcribed by hand from HMA's
own `pcsReference.txt`/`PCSString.cs` and checked byte-range-by-byte-range against them rather
than retyped from memory; `PcsString`, `Repointer`, and `StringRun`'s tests trace concrete byte
sequences end to end (not just round-trip through the code's own encode/decode, which can hide a
bug that's wrong the same way in both directions) - but the Compose/Hilt wiring has the same
unverified-by-compiler status it always has here. Worth a real `./gradlew build` before trusting
any of this further, same as every phase before it.
