# HexManiac Android

A native Android rewrite of [HexManiacAdvance](https://github.com/haven1433/HexManiacAdvance) (HMA),
the C#/WPF hex editor for GBA Pokémon ROM hacking. HMA itself isn't portable (WPF/WinForms are
Windows-only, and its scripting system depends on IronPython) - this rebuilds the feature set
natively in Kotlin, using HMA's source as the reference spec rather than code to reuse.

## Status: Phase 2 - table editor

Phase 1 was the foundation (open/view/edit raw bytes, undo/redo, pointer scan). Phase 2 adds the
first HMA-specific editor on top of it: manually define a table at an address with a format
string, then browse and edit it as rows/columns instead of raw hex.

**Working (Phase 1):**
- Open any file via SAF, view it as a scrollable hex grid (address | hex | tap-to-edit)
- Byte-accurate undo/redo, tracked per edit
- Pointer auto-detection scan (GBA convention: 4-byte LE value, top byte `0x08`/`0x09`,
  value − `0x08000000` = file offset), with detected bytes highlighted in the grid
- Save back to a file via SAF

**Working (Phase 2):**
- Define a table by address + format string (`[hp. attack: name""10 next<>]20` - see
  `TableFormat`'s doc comment for the exact marker syntax and what's deliberately not supported
  yet: enum fields, bit arrays, calculated fields, auto-detected or table-linked element counts)
- Browse it as a scrollable, horizontally-scrollable grid; tap a cell to edit its value
- Numeric, pointer, and (raw-bytes-for-now, see below) text fields, each validated on write
- Hex viewer and table editor share one ROM session (`RomSessionRepository`) - an edit made on
  either screen is immediately visible, undoable, and included when saving from the other
- `core-engine` unit tests covering both phases (pointer round-trip, scanner, undo/redo ordering,
  run containment lookup at boundaries, format-string parsing and its error messages, table
  layout math, and every field type's read/write round-trip)

**Not yet implemented** (see the phase order below): the real PCS text character map (table text
fields are raw Latin-1 + `0xFF` terminator until Phase 3 lands), images, maps, code/scripts,
patches. Table auto-detection also isn't implemented - HMA's own relies on a per-game hardcoded
table/anchor database that's out of scope here; tables are found by typing in an address.

## Architecture

Two modules, one direction of dependency:

```
core-engine/   pure Kotlin/JVM, zero Android dependency
  model/       Run (sealed interface): UnknownRun, PointerRun, TableRun
               FieldSegment (sealed interface): NumericField, PointerField, TextField
               RomDataModel, PointerScanner, TableFormat (format-string parser)
  undo/        ModelDelta, UndoRedoStack

app/           Android application (Compose, Material3, Hilt)
  data/        RomSessionRepository - single shared source of truth for the loaded ROM
  ui/          HexManiacApp (screen router), HexViewerViewModel, HexViewerScreen, theme/
  ui/table/    TableEditorViewModel, TableEditorScreen
```

`core-engine` doesn't know Android exists, on purpose - it's plain JVM, so its tests run in
milliseconds with no emulator, and it stays reusable if a desktop or CLI front end ever makes
sense. `app` depends on it; never the reverse.

**Where this deliberately differs from the original:**
- `Run` is a Kotlin `sealed interface` (`UnknownRun`, `PointerRun`, and now `TableRun`). Every
  exhaustive `when (run)` elsewhere fails to compile until updated when a new run type is added -
  HMA's C# base-class version doesn't get that check for free. `FieldSegment` (a table row's
  fields: `NumericField`/`PointerField`/`TextField`) is sealed for the same reason.
- All byte mutation is `internal` on `RomDataModel`; the only public write path is through a
  `ModelDelta`. It's not possible to accidentally make a non-undoable edit. Table field writes
  (`TableRun.writeNumeric`/`writePointerField`/`writeText`) are built on the same `ModelDelta`
  contract, not a parallel one.
- Pointer-highlight membership uses `BitSet` instead of a boxed `Set<Int>` - relevant once a ROM
  (up to 32MB) has a dense pointer table; one bit per byte instead of ~20 bytes per entry.
- The ROM session (bytes, runs, undo history) moved out of `HexViewerViewModel` and into
  `RomSessionRepository`, a `@Singleton` both screens' ViewModels inject, once a second screen
  (the table editor) needed the same ROM. Each ViewModel still owns its own screen-local state
  (selection, form text, status message) and pulls fresh shared state from the repository
  imperatively - explicitly on mutation, and via a `syncFromSession()` call at the moment a
  screen becomes visible again - rather than reactively via `StateFlow`/`collectAsState`. That
  keeps this at zero new dependencies; if a third screen's state needs finer-grained reactivity
  than "resync on becoming visible," that's the point to reconsider it.
- Screen switching (`HexManiacApp`) is a hand-rolled sealed-interface + `when`, not Jetpack
  Navigation Compose - see that file's doc comment for why, and when to revisit it.

## Build order (why this order)

1. **Data engine + hex viewer** *(done)* - nothing else works without it
2. **Table editor** *(this phase)* - Pokémon/move/item/trainer grids; highest value-to-effort,
   most-used day to day. Format-string-driven and manually addressed for now (see Status above);
   auto-detected/named tables are a natural follow-up but aren't required to make this useful.
3. **Text editor** - PCS string encoding, auto-repoint on edit
4. **Image editor** - sprites, tilemaps, palettes
5. **Map editor** - maps, events, connections, warps, wild encounters
6. **Code editor + patch DSL** - Thumb disassembler, event/battle/AI scripts, the `.hma` patch
   format - hardest subsystem, saved for once the engine's proven under real use

IronPython's live-scripting console (table automation) has no clean Android equivalent and isn't
scoped into any phase yet; it's the one piece of the original worth deferring rather than
matching feature-for-feature.

## Building

Same pipeline as the rest of the projects - zip this folder, push through ZipApkBuilder. No NDK/
CMake needed (pure Kotlin, no native code), though the workflow installing them anyway is
harmless. Toolchain: JDK 17, Gradle 8.6, AGP 8.4.0, Kotlin 2.0.0.

Local validation note: this sandbox had a JRE but no `javac`/network, so the core algorithms
(pointer encode/decode, scanning, undo/redo ordering, run lookup at boundaries) were verified with
a throwaway Python harness before the Kotlin was written, then ported into the real `core-engine`
tests above. Gradle/Kotlin compilation itself only happens for real in CI, which is where the two
issues below actually surfaced.

## v2 - CI fixes + APK size pass

**Fixed, from run 1559's failure log:**
- `HexViewerScreen.kt` explicitly imported `androidx.compose.foundation.layout.weight`. That path
  resolves to Compose Foundation's *internal* `RowColumnParentData.weight` property, not the
  `ColumnScope`/`RowScope` member extension the code actually wants - hence
  `Cannot access 'val RowColumnParentData?.weight: Float': it is internal in file`. Fix: delete the
  import. `Modifier.weight(1f)` needs no import at all inside a `Column`/`Row` content lambda; it
  resolves via the implicit `ColumnScope`/`RowScope` receiver. (This is the same class of bug as
  Outcrop's outstanding `.weight(1f)` import error - worth checking there too.)
- `TopAppBar` is `@ExperimentalMaterial3Api` in Compose BOM 2024.06.00, which is a hard compile
  error without an opt-in, not just a warning. Fix: `@OptIn(ExperimentalMaterial3Api::class)` on
  `HexViewerScreen`.

**APK size, no features removed, no ABI split:**
- ABI splits wouldn't do anything here anyway - there's no native code/JNI, so there's nothing
  architecture-specific being bundled in the first place.
- `isMinifyEnabled = true` + `isShrinkResources = true` for release only (debug stays fast/
  unminified for iteration). This is the actual lever: R8 strips unreachable code, which matters
  most for `material3` since the app only calls a handful of its components, and shrinkResources
  drops resources nothing reachable references. `proguard-rules.pro` documents why this is safe
  for this codebase specifically (no reflection, no serialization, vanilla Hilt usage that its own
  consumer rules already cover) and keeps source-file/line-number info so release crashes still
  produce a readable stack trace.
- `resourceConfigurations += setOf("en")` in `defaultConfig` - the app has zero i18n of its own, so
  this only drops *other libraries'* bundled non-English strings (mostly accessibility labels),
  not anything the app presents. Flagging this one specifically since it's the one change here
  that's a real trade-off rather than a pure win: a non-English device will see those library
  labels fall back to English instead of their own language.
- No dependency changes needed - `material-icons-extended` was already avoided (see `app/build.gradle.kts`).

Compiles cleanly against the CI log's actual failure now; the R8 config is reasoned through but,
same as everything Gradle-related, not locally build-tested (no network in this sandbox) - worth
double-checking the release APK actually launches and behaves correctly on-device, not just that
CI goes green, since R8 issues are sometimes runtime-only.

## v3 - Phase 2: table editor

**New in `core-engine`:** `FieldSegment` (`NumericField`/`PointerField`/`TextField`), `TableFormat`
(the `[name.]N`-style format-string parser - deliberate subset, see its doc comment), `TableRun`
(the row-major table `Run` plus typed field read/write). `RomDataModel.readPointer`/`writePointer`
were refactored to share a new `internal readLittleEndian`/`writeLittleEndian` pair with table
numeric fields, instead of each re-deriving little-endian byte packing - behavior-preserving
(same bounds checks, same GBA-address validation stays on the pointer-specific methods), covered
by the existing pointer tests plus new ones for the shared primitive via table fields.

**New in `app`:** `RomSessionRepository` (`data/`) is now the single owner of the loaded ROM;
`HexViewerViewModel` was refactored to delegate to it rather than hold the model/undo stack
itself - its public API to `HexViewerScreen` is unchanged, so that screen needed no changes
beyond a new "Tables" button. `TableEditorViewModel`/`TableEditorScreen` (`ui/table/`) are new:
address+format form when no table is open, otherwise a scrollable editable grid. `HexManiacApp`
is a new small root composable that switches between the two screens and keeps them in sync with
the repository - see its doc comment for why that's a hand-rolled sealed `when` rather than
Navigation Compose (short version: zero new dependency versions to get wrong in a sandbox with no
way to compile-check them, for a two-screen app that doesn't need a real back stack yet).

**Known rough edges, honestly:**
- Table editor has no Save button of its own - go back to the hex viewer to save, since both
  screens share the same ROM bytes anyway. Small, but worth a real button if this gets used a lot.
- Text fields are raw Latin-1 with a `0xFF` terminator, not the game's actual PCS character map
  (that's Phase 3). The byte-level contract (terminator + zero padding) is deliberately the same
  one PCS will use, so upgrading a field's decoding later shouldn't change what's on disk.
- No enum-typed fields (e.g. a move's type rendered by name instead of a raw byte), bit arrays,
  or calculated fields - `TableFormat` throws a specific message rather than misparsing these.
- Table *recognition* is manual (you type the address + format); there's no hardcoded/per-game
  table database like HMA's own. Once defined, a table is remembered for the rest of the session
  (`RomSessionRepository` keeps it in the model's `runs`), just not before that.

Same caveat as v2, worth repeating rather than assuming it stopped applying: this sandbox has a
JDK but no Android SDK, no Gradle, and no network, so none of this was actually compiled here.
Every method signature this phase depends on (`ModelDelta.setByte`, `RomDataModel.get`/
`readPointer`/`writePointer`, `UndoRedoStack.push`, `Run`'s properties) was checked against the
real Phase 1 source rather than assumed, and the new engine logic (format parsing, table layout
math, every field type's read/write) has direct unit test coverage - but the same
build-verification gap as always applies to the Compose/Hilt wiring specifically. Worth a real
`./gradlew build` (or a CI run) before trusting it further, same as v2 was.
