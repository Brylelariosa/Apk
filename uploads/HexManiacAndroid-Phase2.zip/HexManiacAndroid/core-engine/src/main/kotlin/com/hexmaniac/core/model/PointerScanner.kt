package com.hexmaniac.core.model

/**
 * Scans a ROM for byte sequences that look like valid GBA pointers, mirroring
 * HexManiacAdvance's "search for pointers" pass. This is a byte-by-byte scan (not
 * 4-byte-aligned) since HMA's own pointer tables aren't guaranteed aligned either;
 * it will produce some overlap/false positives on dense data, same as the original -
 * pruning those is a Phase 2 concern once there's a table/anchor model to cross-check against.
 */
object PointerScanner {
    fun scan(model: RomDataModel): List<PointerRun> {
        if (model.size < 4) return emptyList()
        val found = mutableListOf<PointerRun>()
        for (i in 0..model.size - 4) {
            if (model.readPointer(i) >= 0) found.add(PointerRun(i))
        }
        return found
    }
}
