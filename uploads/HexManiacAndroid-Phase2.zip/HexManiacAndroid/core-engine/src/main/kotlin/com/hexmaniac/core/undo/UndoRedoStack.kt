package com.hexmaniac.core.undo

import com.hexmaniac.core.model.RomDataModel
import java.util.ArrayDeque

/** LIFO undo/redo stack of [ModelDelta]s. */
class UndoRedoStack {
    private val undoStack = ArrayDeque<ModelDelta>()
    private val redoStack = ArrayDeque<ModelDelta>()

    val canUndo: Boolean get() = !undoStack.isEmpty()
    val canRedo: Boolean get() = !redoStack.isEmpty()

    /** Pushes [delta] as the most recent edit. Empty deltas are ignored. A new edit clears redo history. */
    fun push(delta: ModelDelta) {
        if (delta.isEmpty) return
        undoStack.push(delta)
        redoStack.clear()
    }

    fun undo(model: RomDataModel) {
        val delta = undoStack.poll() ?: return
        redoStack.push(delta.revert(model))
    }

    fun redo(model: RomDataModel) {
        val delta = redoStack.poll() ?: return
        undoStack.push(delta.revert(model))
    }
}
