package com.hexmaniac.core.model

import com.hexmaniac.core.undo.ModelDelta

/**
 * Holds the raw ROM bytes plus the sorted collection of interpreted [Run]s layered over them.
 * Mirrors HexManiacAdvance's IDataModel, minus the anchor/name/table-specific concerns that
 * belong to later phases (table, text, and map editors).
 *
 * Direct byte mutation is `internal` on purpose: every edit must go through a [ModelDelta] so
 * it is always undoable. UI code reads via [get]/[readPointer] but can only write via
 * [ModelDelta.setByte] or [writePointer] - there is no public path that bypasses undo tracking.
 */
class RomDataModel(private val data: ByteArray) {

    val size: Int get() = data.size

    // Parallel sorted list of run-start addresses, kept in sync with runsByStart, so
    // getRunAt() can binary-search instead of scanning - matters once a ROM has
    // thousands of detected runs.
    private val runStarts = mutableListOf<Int>()
    private val runsByStart = mutableMapOf<Int, Run>()

    val runs: List<Run> get() = runStarts.map { runsByStart.getValue(it) }

    operator fun get(index: Int): Int = data[index].toInt() and 0xFF

    internal operator fun set(index: Int, value: Int) {
        data[index] = value.toByte()
    }

    /** Returns a defensive copy of the current bytes, e.g. for saving to a file. */
    fun snapshotBytes(): ByteArray = data.copyOf()

    /** Reads a little-endian 4-byte GBA pointer at [address]; returns the file offset, or -1 if invalid. */
    fun readPointer(address: Int): Int {
        if (address < 0 || address + 4 > data.size) return -1
        val value = readLittleEndian(address, 4)
        val topByte = (value ushr 24) and 0xFF
        if (topByte != 0x08 && topByte != 0x09) return -1 // not in GBA ROM address space
        val fileOffset = value - POINTER_OFFSET
        if (fileOffset < 0 || fileOffset >= data.size) return -1
        return fileOffset
    }

    /** Writes [fileOffset] as a 4-byte GBA pointer at [address], tracked by [token] so it can be undone. */
    fun writePointer(address: Int, fileOffset: Int, token: ModelDelta) {
        writeLittleEndian(address, 4, fileOffset + POINTER_OFFSET, token)
    }

    /**
     * Reads [byteCount] (1-4) bytes starting at [address] as an unsigned little-endian integer.
     * `internal`, not `private`: Phase 2's table numeric fields reuse this exact primitive
     * (see TableRun.kt) rather than re-deriving little-endian packing a second time - this is
     * the one place that logic lives. [readPointer] above is the 4-byte, GBA-address-space-
     * validated special case of the same primitive.
     */
    internal fun readLittleEndian(address: Int, byteCount: Int): Int {
        var value = 0
        for (i in 0 until byteCount) value = value or (this[address + i] shl (8 * i))
        return value
    }

    /** Writes [value]'s low [byteCount] bytes starting at [address], little-endian, tracked by [token]. See [readLittleEndian]. */
    internal fun writeLittleEndian(address: Int, byteCount: Int, value: Int, token: ModelDelta) {
        for (i in 0 until byteCount) token.setByte(this, address + i, (value ushr (8 * i)) and 0xFF)
    }

    fun addRun(run: Run) {
        val i = runStarts.binarySearch(run.start)
        if (i < 0) runStarts.add(-(i + 1), run.start)
        runsByStart[run.start] = run
    }

    /** Returns the run containing [address], or null if none does. O(log n). */
    fun getRunAt(address: Int): Run? {
        val i = runStarts.binarySearch(address)
        val floorIndex = if (i >= 0) i else -(i + 1) - 1
        if (floorIndex < 0) return null
        val run = runsByStart.getValue(runStarts[floorIndex])
        return if (address in run) run else null
    }

    companion object {
        const val POINTER_OFFSET = 0x08000000
    }
}
