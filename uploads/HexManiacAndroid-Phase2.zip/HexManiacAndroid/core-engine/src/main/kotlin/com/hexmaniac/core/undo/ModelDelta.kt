package com.hexmaniac.core.undo

import com.hexmaniac.core.model.RomDataModel

/**
 * Represents one undoable edit: for every index touched, the value it had *before* this
 * delta first touched it. Mirrors HexManiacAdvance's ModelDelta.
 *
 * [revert] both undoes this delta's changes on [model] and hands back a fresh delta that
 * would redo them - so redo is just "revert the revert", the same trick the original uses.
 */
class ModelDelta {
    private val oldBytes = LinkedHashMap<Int, Int>()

    val isEmpty: Boolean get() = oldBytes.isEmpty()

    fun setByte(model: RomDataModel, index: Int, newValue: Int) {
        oldBytes.getOrPut(index) { model[index] }
        model[index] = newValue
    }

    fun revert(model: RomDataModel): ModelDelta {
        val reverse = ModelDelta()
        for ((index, oldValue) in oldBytes) {
            reverse.oldBytes[index] = model[index]
            model[index] = oldValue
        }
        return reverse
    }
}
