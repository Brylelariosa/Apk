package com.hexmaniac.core.model

/** Thrown by [TableFormat.parse] with a message meant to be shown directly to the user. */
class TableFormatException(message: String) : Exception(message)

/**
 * Parses HexManiacAdvance's table format-string DSL - e.g. `[hp. attack. name""10 next<>]20` -
 * into [FieldSegment]s plus an element count. Reference: ArrayRun.cs / ArrayRunElementSegment.cs
 * in the original C# source (this project uses HMA's source as a spec to read, not code to
 * reuse - see README).
 *
 * Deliberate subset of the real grammar, matching what [FieldSegment] supports:
 *   - Fields: `name.` (1-byte int), `name:` (2-byte), `name:.` (3-byte), `name::` (4-byte),
 *     `name""N` (N-byte text), `name<>` (4-byte pointer). No space between a name and its marker.
 *   - Count: only a literal integer after `]` (e.g. `]20`). The original spec also allows
 *     leaving it blank (scan forward until the data stops matching the format) or naming
 *     another table to match its length - both throw here with a message saying so, rather
 *     than silently guessing at a count.
 * Not supported at all yet: enum-typed fields, bit arrays, calculated/derived fields, nested
 * struct segments, the `^` inner-pointer-support prefix - all later-phase concerns per the
 * README's build order.
 */
object TableFormat {
    private const val ARRAY_START = '['
    private const val ARRAY_END = ']'

    data class Parsed(val segments: List<FieldSegment>, val elementCount: Int)

    fun parse(formatText: String): Parsed {
        val text = formatText.trim()
        if (!text.startsWith(ARRAY_START)) {
            throw TableFormatException("Format must start with '$ARRAY_START', e.g. '[hp. attack.]20'.")
        }
        val closeIndex = text.lastIndexOf(ARRAY_END)
        if (closeIndex < 0) throw TableFormatException("Format is missing a closing '$ARRAY_END'.")

        val body = text.substring(1, closeIndex)
        val countText = text.substring(closeIndex + 1).trim()
        val elementCount = countText.toIntOrNull() ?: throw TableFormatException(
            if (countText.isEmpty())
                "Auto-detected length isn't supported yet - add an explicit count after ']', e.g. ']20'."
            else
                "'$countText' isn't a number - matching another table's length isn't supported yet."
        )
        if (elementCount < 1) throw TableFormatException("Element count must be at least 1.")

        val segments = parseSegments(body)
        if (segments.isEmpty()) {
            throw TableFormatException("Declare at least one field between '$ARRAY_START' and '$ARRAY_END'.")
        }
        return Parsed(segments, elementCount)
    }

    private fun parseSegments(body: String): List<FieldSegment> {
        val segments = mutableListOf<FieldSegment>()
        var i = 0
        while (i < body.length) {
            if (body[i].isWhitespace()) {
                i++
                continue
            }
            val nameStart = i
            while (i < body.length && !body[i].isWhitespace() && body[i] !in "\"<:.") i++
            val name = body.substring(nameStart, i)
            if (name.isEmpty()) throw TableFormatException("Expected a field name near '${body.substring(i)}'.")
            if (i >= body.length || body[i].isWhitespace()) {
                throw TableFormatException(
                    "Field '$name' needs a type marker right after its name - ., :, ::, \"\"N, or <> - with no space before it."
                )
            }

            val segment: FieldSegment = when {
                body.startsWith("\"\"", i) -> {
                    i += 2
                    val lenStart = i
                    while (i < body.length && body[i].isDigit()) i++
                    val len = body.substring(lenStart, i).toIntOrNull()
                        ?: throw TableFormatException("Text field '$name' needs a byte length right after its quotes, e.g. '$name\"\"10'.")
                    TextField(name, len)
                }
                body.startsWith("<>", i) -> {
                    i += 2
                    PointerField(name)
                }
                body.startsWith("::", i) -> {
                    i += 2
                    NumericField(name, 4)
                }
                body.startsWith(":.", i) -> {
                    i += 2
                    NumericField(name, 3)
                }
                body.startsWith(":", i) -> {
                    i += 1
                    NumericField(name, 2)
                }
                body.startsWith(".", i) -> {
                    i += 1
                    NumericField(name, 1)
                }
                else -> throw TableFormatException("Field '$name' has an unrecognized type marker '${body[i]}'.")
            }
            segments.add(segment)
        }
        return segments
    }
}
