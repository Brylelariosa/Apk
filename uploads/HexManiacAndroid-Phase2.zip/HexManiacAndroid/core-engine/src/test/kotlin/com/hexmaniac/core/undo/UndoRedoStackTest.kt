package com.hexmaniac.core.undo

import com.hexmaniac.core.model.RomDataModel
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse

class UndoRedoStackTest {

    @Test
    fun `undo restores and redo reapplies a single edit`() {
        val model = RomDataModel(byteArrayOf(1, 2, 3, 4, 5))
        val stack = UndoRedoStack()

        val delta = ModelDelta()
        delta.setByte(model, 2, 99)
        stack.push(delta)
        assertEquals(99, model[2])

        stack.undo(model)
        assertEquals(3, model[2])

        stack.redo(model)
        assertEquals(99, model[2])
    }

    @Test
    fun `undo past the bottom of the stack is a safe no-op`() {
        val model = RomDataModel(byteArrayOf(1, 2, 3))
        val stack = UndoRedoStack()
        val delta = ModelDelta()
        delta.setByte(model, 0, 42)
        stack.push(delta)

        stack.undo(model)
        stack.undo(model) // nothing left to undo - must not throw
        assertEquals(1, model[0])
        assertFalse(stack.canUndo)
    }

    @Test
    fun `a new edit after undo clears the redo stack`() {
        val model = RomDataModel(byteArrayOf(0, 0, 0))
        val stack = UndoRedoStack()

        val d1 = ModelDelta(); d1.setByte(model, 0, 1); stack.push(d1)
        val d2 = ModelDelta(); d2.setByte(model, 0, 2); stack.push(d2)

        stack.undo(model)
        assertEquals(1, model[0])

        val d3 = ModelDelta(); d3.setByte(model, 0, 9); stack.push(d3)
        assertEquals(9, model[0])

        stack.redo(model) // redo stack was cleared when d3 was pushed - this must be a no-op
        assertEquals(9, model[0])
    }
}
