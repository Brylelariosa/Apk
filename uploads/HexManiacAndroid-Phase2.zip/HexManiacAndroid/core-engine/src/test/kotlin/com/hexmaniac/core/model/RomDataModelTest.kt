package com.hexmaniac.core.model

import com.hexmaniac.core.undo.ModelDelta
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull
import kotlin.test.assertTrue

class RomDataModelTest {

    @Test
    fun `pointer round-trips through write and read`() {
        val model = RomDataModel(ByteArray(0x100))
        val delta = ModelDelta()
        model.writePointer(0x10, 0x50, delta)
        assertEquals(0x50, model.readPointer(0x10))
        assertEquals(0x08, model[0x13]) // top address byte for the 0x08000000 GBA ROM space
    }

    @Test
    fun `all-zero bytes are not a valid pointer`() {
        val model = RomDataModel(ByteArray(4))
        assertEquals(-1, model.readPointer(0))
    }

    @Test
    fun `all-0xFF bytes are not a valid pointer`() {
        val model = RomDataModel(byteArrayOf(-1, -1, -1, -1))
        assertEquals(-1, model.readPointer(0))
    }

    @Test
    fun `pointer scanner finds planted pointers amid noise`() {
        val data = ByteArray(0x200) { -1 } // 0xFF noise that must not look like a pointer
        val model = RomDataModel(data)
        val delta = ModelDelta()
        model.writePointer(0x20, 0x100, delta)
        model.writePointer(0x40, 0x180, delta)

        val found = PointerScanner.scan(model).map { it.start }.toSet()
        assertTrue(0x20 in found)
        assertTrue(0x40 in found)
        assertTrue(found.none { it > 0x44 && it < 0x1F8 })
    }

    @Test
    fun `run lookup finds the containing run at its start, middle, and last byte`() {
        val model = RomDataModel(ByteArray(0x50))
        model.addRun(UnknownRun(0x10, 0x10)) // covers [0x10, 0x20)
        model.addRun(PointerRun(0x30))        // covers [0x30, 0x34)

        assertEquals(0x10, model.getRunAt(0x10)?.start)
        assertEquals(0x10, model.getRunAt(0x15)?.start)
        assertEquals(0x10, model.getRunAt(0x1F)?.start)
        assertNull(model.getRunAt(0x25))
        assertEquals(0x30, model.getRunAt(0x32)?.start)
    }

    @Test
    fun `removeRun undoes a previous addRun so the address looks unclaimed again`() {
        val model = RomDataModel(ByteArray(0x20))
        model.addRun(UnknownRun(0x10, 0x8))
        assertEquals(0x10, model.getRunAt(0x12)?.start)

        model.removeRun(0x10)

        assertNull(model.getRunAt(0x12))
    }

    @Test
    fun `removeRun is a no-op for an address with nothing registered`() {
        val model = RomDataModel(ByteArray(0x20))
        model.removeRun(0x10) // should not throw
        assertNull(model.getRunAt(0x10))
    }
}
