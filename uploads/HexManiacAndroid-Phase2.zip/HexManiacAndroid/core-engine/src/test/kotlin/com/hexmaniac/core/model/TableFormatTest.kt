package com.hexmaniac.core.model

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertTrue

class TableFormatTest {

    @Test
    fun `parses a mix of every supported field type`() {
        val parsed = TableFormat.parse("[hp. attack: total:. flags:: name\"\"10 next<>]5")
        assertEquals(
            listOf(
                NumericField("hp", 1),
                NumericField("attack", 2),
                NumericField("total", 3),
                NumericField("flags", 4),
                TextField("name", 10),
                PointerField("next"),
            ),
            parsed.segments,
        )
        assertEquals(5, parsed.elementCount)
    }

    @Test
    fun `tolerates extra whitespace between fields`() {
        val parsed = TableFormat.parse("[  hp.   attack:  ]3")
        assertEquals(listOf(NumericField("hp", 1), NumericField("attack", 2)), parsed.segments)
    }

    @Test
    fun `rejects a format missing the opening bracket`() {
        assertFailsWith<TableFormatException> { TableFormat.parse("hp.]5") }
    }

    @Test
    fun `rejects a format missing the closing bracket`() {
        assertFailsWith<TableFormatException> { TableFormat.parse("[hp.5") }
    }

    @Test
    fun `rejects a blank element count with a specific message`() {
        val error = assertFailsWith<TableFormatException> { TableFormat.parse("[hp.]") }
        assertTrue(error.message!!.contains("supported yet"))
    }

    @Test
    fun `rejects a name-referenced element count with a specific message`() {
        val error = assertFailsWith<TableFormatException> { TableFormat.parse("[hp.]otherTable") }
        assertTrue(error.message!!.contains("supported yet"))
    }

    @Test
    fun `rejects a zero element count`() {
        assertFailsWith<TableFormatException> { TableFormat.parse("[hp.]0") }
    }

    @Test
    fun `rejects a field with a space before its marker`() {
        assertFailsWith<TableFormatException> { TableFormat.parse("[hp .]5") }
    }

    @Test
    fun `rejects a field with no marker at all`() {
        assertFailsWith<TableFormatException> { TableFormat.parse("[hp]5") }
    }

    @Test
    fun `rejects an empty field list`() {
        assertFailsWith<TableFormatException> { TableFormat.parse("[]5") }
    }

    @Test
    fun `rejects a text field with no length after its quotes`() {
        assertFailsWith<TableFormatException> { TableFormat.parse("[name\"\"]5") }
    }
}
