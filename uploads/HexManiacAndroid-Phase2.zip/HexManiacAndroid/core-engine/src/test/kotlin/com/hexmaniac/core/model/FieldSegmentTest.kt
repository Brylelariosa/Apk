package com.hexmaniac.core.model

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith

class FieldSegmentTest {

    @Test
    fun `numeric field rejects lengths outside 1 to 4`() {
        assertFailsWith<IllegalArgumentException> { NumericField("x", 0) }
        assertFailsWith<IllegalArgumentException> { NumericField("x", 5) }
    }

    @Test
    fun `text field rejects a non-positive length`() {
        assertFailsWith<IllegalArgumentException> { TextField("x", 0) }
    }

    @Test
    fun `pointer field is always 4 bytes regardless of construction`() {
        assertEquals(4, PointerField("x").length)
    }
}
