package com.browser.app

import android.app.Activity
import android.content.Context
import android.util.AttributeSet
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.webkit.WebView
import android.view.inputmethod.InputMethodManager
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

class ScrollAwareWebView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : WebView(context, attrs, defStyleAttr) {

    var onScrollCallback: ((dy: Int) -> Unit)? = null
    var onWebInputFocused: (() -> Unit)? = null
    var onDebugEvent: ((String) -> Unit)? = null   // debug overlay hook

    override fun onScrollChanged(l: Int, t: Int, oldl: Int, oldt: Int) {
        super.onScrollChanged(l, t, oldl, oldt)
        onScrollCallback?.invoke(t - oldt)
    }

    override fun onCheckIsTextEditor(): Boolean = true

    override fun onCreateInputConnection(outAttrs: EditorInfo): InputConnection? {
        val ic = super.onCreateInputConnection(outAttrs)
        onDebugEvent?.invoke("onCreateIC: ic=${if (ic != null) "OK" else "NULL"}")
        if (ic != null) {
            postDelayed({
                onWebInputFocused?.invoke()
                val activity = context as? Activity ?: run {
                    onDebugEvent?.invoke("onCreateIC: no Activity!")
                    return@postDelayed
                }
                try {
                    this.requestFocus()
                    // Try classic IMM first (works on more devices)
                    val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                    val immResult = imm.showSoftInput(this, InputMethodManager.SHOW_IMPLICIT)
                    // Also try WindowInsetsController (API 30+)
                    WindowInsetsControllerCompat(activity.window, this)
                        .show(WindowInsetsCompat.Type.ime())
                    onDebugEvent?.invoke("showKB: imm=$immResult")
                } catch (e: Exception) {
                    onDebugEvent?.invoke("showKB ERROR: ${e.message}")
                }
            }, 150)
        }
        return ic
    }
}
