# Project specific ProGuard rules. Minification is disabled, so nothing is needed here.
