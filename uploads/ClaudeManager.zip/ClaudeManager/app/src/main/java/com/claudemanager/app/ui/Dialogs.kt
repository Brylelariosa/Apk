package com.claudemanager.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.claudemanager.app.data.Account
import com.claudemanager.app.data.ActivityEvent
import com.claudemanager.app.data.ActivityStatus
import com.claudemanager.app.data.Project
import com.claudemanager.app.util.TimeUtil
import kotlinx.coroutines.flow.Flow

fun durationMillisOf(hours: String, minutes: String): Long =
    (hours.toLongOrNull() ?: 0L) * 3_600_000L + (minutes.toLongOrNull() ?: 0L) * 60_000L

/** Hours and minutes inputs, digits only. */
@Composable
fun DurationFields(
    hours: String,
    minutes: String,
    onHoursChange: (String) -> Unit,
    onMinutesChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        OutlinedTextField(
            value = hours,
            onValueChange = { onHoursChange(it.filter { c -> c.isDigit() }.take(3)) },
            modifier = Modifier.weight(1f),
            label = { Text("Hours") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
        )
        OutlinedTextField(
            value = minutes,
            onValueChange = { onMinutesChange(it.filter { c -> c.isDigit() }.take(2)) },
            modifier = Modifier.weight(1f),
            label = { Text("Minutes") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
        )
    }
}

/** One-tap status change: picking a row saves immediately. */
@Composable
fun StatusPickerDialog(
    project: Project,
    onSelect: (ActivityStatus) -> Unit,
    onDismiss: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = cs.surface,
        title = { Text("Change status") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                for (s in ActivityStatus.values()) {
                    val selected = s == project.activityStatus
                    val c = statusColor(s)
                    val label = if (s == ActivityStatus.CUSTOM && selected && project.customStatusLabel.isNotBlank()) {
                        "CUSTOM: ${project.customStatusLabel}"
                    } else {
                        s.name
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { onSelect(s) }
                            .padding(horizontal = 4.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = selected,
                            onClick = null,
                            colors = RadioButtonDefaults.colors(
                                selectedColor = c,
                                unselectedColor = c.copy(alpha = 0.7f)
                            )
                        )
                        Spacer(Modifier.width(12.dp))
                        Text(
                            text = label,
                            style = MaterialTheme.typography.bodyLarge,
                            color = cs.onSurface
                        )
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun CustomStatusDialog(initial: String, onSave: (String) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = { Text("Custom status") },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it.take(24) },
                label = { Text("Status label") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            TextButton(onClick = { onSave(text) }, enabled = text.isNotBlank()) { Text("Set status") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun NoteDialog(project: Project, onSave: (String) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(project.activityNote) }
    val isError = project.activityStatus == ActivityStatus.ERROR
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = { Text(if (isError) "Error note" else "Note") },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it.take(140) },
                modifier = Modifier.fillMaxWidth(),
                placeholder = {
                    Text(if (isError) "Build failed - Gradle dependency error" else "Building APK")
                },
                minLines = 2,
                maxLines = 4
            )
        },
        confirmButton = { TextButton(onClick = { onSave(text) }) { Text("Save note") } },
        dismissButton = {
            Row {
                if (project.activityNote.isNotEmpty()) {
                    TextButton(onClick = { onSave("") }) { Text("Clear") }
                }
                TextButton(onClick = onDismiss) { Text("Cancel") }
            }
        }
    )
}

/** Create (project == null) or edit a project. Can also create an account inline. */
@Composable
fun EditProjectDialog(
    project: Project?,
    accounts: List<Account>,
    defaultDurationMillis: Long,
    onSave: (
        name: String,
        accountId: Long?,
        newAccountLabel: String?,
        newAccountEmail: String,
        durationMillis: Long
    ) -> Unit,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf(project?.name ?: "") }
    var accountId by remember {
        mutableStateOf<Long?>(if (project != null) project.accountId else accounts.firstOrNull()?.id)
    }
    var creating by remember { mutableStateOf(project == null && accounts.isEmpty()) }
    var newLabel by remember { mutableStateOf("") }
    var newEmail by remember { mutableStateOf("") }
    val initialMillis = project?.defaultDurationMillis ?: defaultDurationMillis
    var hours by remember { mutableStateOf((initialMillis / 3_600_000L).toString()) }
    var minutes by remember { mutableStateOf(((initialMillis / 60_000L) % 60L).toString()) }
    var menuOpen by remember { mutableStateOf(false) }

    val durationMillis = durationMillisOf(hours, minutes)
    val canSave = name.isNotBlank() && durationMillis > 0L && (!creating || newLabel.isNotBlank())
    val selectedAccount = accounts.firstOrNull { it.id == accountId }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = { Text(if (project == null) "New project" else "Edit project") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it.take(40) },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Project name") },
                    singleLine = true
                )

                if (creating) {
                    OutlinedTextField(
                        value = newLabel,
                        onValueChange = { newLabel = it.take(30) },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("New account name") },
                        placeholder = { Text("Main Claude") },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = newEmail,
                        onValueChange = { newEmail = it.take(60) },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Account email (optional)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                    )
                    TextButton(onClick = { creating = false }) {
                        Text(
                            if (accounts.isNotEmpty()) "Use an existing account"
                            else "Skip the account for now"
                        )
                    }
                } else {
                    Box {
                        OutlinedButton(
                            onClick = { menuOpen = true },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = if (selectedAccount != null) accountLine(selectedAccount) else "No account",
                                modifier = Modifier.weight(1f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text("\u25BE")
                        }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            for (a in accounts) {
                                DropdownMenuItem(
                                    text = { Text(accountLine(a)) },
                                    onClick = {
                                        accountId = a.id
                                        menuOpen = false
                                    }
                                )
                            }
                            DropdownMenuItem(
                                text = { Text("No account") },
                                onClick = {
                                    accountId = null
                                    menuOpen = false
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("New account...") },
                                onClick = {
                                    menuOpen = false
                                    creating = true
                                }
                            )
                        }
                    }
                }

                Text(
                    text = "Default timer",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                DurationFields(
                    hours = hours,
                    minutes = minutes,
                    onHoursChange = { hours = it },
                    onMinutesChange = { minutes = it }
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    onSave(
                        name,
                        if (creating) null else accountId,
                        if (creating) newLabel else null,
                        newEmail,
                        durationMillis
                    )
                },
                enabled = canSave
            ) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

/** Type in the time left until the limit resets. The activity status is not touched. */
@Composable
fun SetTimerDialog(project: Project, onSet: (Long) -> Unit, onDismiss: () -> Unit) {
    val openedAt = remember { System.currentTimeMillis() }
    val end = project.timerEndTimestamp
    val baseMillis = if (end != null && end > openedAt) end - openedAt else project.defaultDurationMillis
    val baseMinutes = baseMillis / 60_000L
    var hours by remember { mutableStateOf((baseMinutes / 60L).toString()) }
    var minutes by remember { mutableStateOf((baseMinutes % 60L).toString()) }
    val millis = durationMillisOf(hours, minutes)

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = { Text("Set remaining time") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "How long until this limit resets? The status stays as it is.",
                    style = MaterialTheme.typography.bodyMedium
                )
                DurationFields(
                    hours = hours,
                    minutes = minutes,
                    onHoursChange = { hours = it },
                    onMinutesChange = { minutes = it }
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onSet(millis) }, enabled = millis > 0L) { Text("Set timer") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

private sealed interface HistoryRow {
    data class Header(val text: String) : HistoryRow
    data class Entry(val event: ActivityEvent) : HistoryRow
}

/** Day-grouped history: newest day first, events in time order inside each day. */
@Composable
fun HistoryDialog(
    project: Project,
    events: Flow<List<ActivityEvent>>,
    onClear: () -> Unit,
    onDismiss: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val context = LocalContext.current
    val list by events.collectAsStateWithLifecycle(initialValue = emptyList())
    val rows = remember(list) {
        val now = System.currentTimeMillis()
        val out = mutableListOf<HistoryRow>()
        val byDay = list.groupBy { TimeUtil.dayKey(it.timestamp) }
        for ((_, dayEvents) in byDay) {
            out.add(HistoryRow.Header(TimeUtil.dayLabel(dayEvents.first().timestamp, now)))
            val ordered = dayEvents.sortedWith(compareBy<ActivityEvent> { it.timestamp }.thenBy { it.id })
            for (e in ordered) out.add(HistoryRow.Entry(e))
        }
        out
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = cs.surface,
        title = { Text(project.name) },
        text = {
            if (rows.isEmpty()) {
                Text(
                    text = "No activity yet. Every status change shows up here.",
                    style = MaterialTheme.typography.bodyMedium
                )
            } else {
                LazyColumn(Modifier.fillMaxWidth().heightIn(max = 420.dp)) {
                    items(rows) { row ->
                        when (row) {
                            is HistoryRow.Header -> Text(
                                text = row.text,
                                modifier = Modifier.padding(top = 12.dp, bottom = 4.dp),
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = cs.primary
                            )
                            is HistoryRow.Entry -> {
                                val e = row.event
                                Column(Modifier.padding(vertical = 4.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = TimeUtil.formatTime(context, e.timestamp),
                                            modifier = Modifier.width(76.dp),
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = cs.onSurfaceVariant
                                        )
                                        StatusDot(statusColor(e.status), 9.dp)
                                        Spacer(Modifier.width(8.dp))
                                        Text(
                                            text = statusLabel(e.status, e.customLabel),
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.SemiBold,
                                            color = cs.onSurface
                                        )
                                    }
                                    if (e.note.isNotBlank()) {
                                        Text(
                                            text = e.note,
                                            modifier = Modifier.padding(start = 93.dp),
                                            style = MaterialTheme.typography.bodySmall,
                                            color = cs.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
        dismissButton = {
            if (rows.isNotEmpty()) {
                TextButton(onClick = onClear) { Text("Clear history") }
            }
        }
    )
}

@Composable
fun ConfirmDialog(
    title: String,
    message: String,
    confirmLabel: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = cs.surface,
        title = { Text(title) },
        text = { Text(message) },
        confirmButton = {
            TextButton(onClick = onConfirm) { Text(confirmLabel, color = cs.error) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun AccountDialog(
    initial: Account?,
    onSave: (label: String, email: String) -> Unit,
    onDismiss: () -> Unit
) {
    var label by remember { mutableStateOf(initial?.label ?: "") }
    var email by remember { mutableStateOf(initial?.email ?: "") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = { Text(if (initial == null) "New account" else "Edit account") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = label,
                    onValueChange = { label = it.take(30) },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Account name") },
                    placeholder = { Text("Main Claude") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it.take(60) },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Email (optional)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(label, email) }, enabled = label.isNotBlank()) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
