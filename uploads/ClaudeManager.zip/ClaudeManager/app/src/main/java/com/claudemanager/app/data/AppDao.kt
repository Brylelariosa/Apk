package com.claudemanager.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {

    // ---- Projects ----

    @Query("SELECT * FROM projects")
    fun observeProjects(): Flow<List<Project>>

    @Query("SELECT * FROM projects")
    suspend fun getProjects(): List<Project>

    @Query("SELECT * FROM projects WHERE id = :id")
    suspend fun getProject(id: Long): Project?

    @Insert
    suspend fun insertProject(project: Project): Long

    @Update
    suspend fun updateProject(project: Project)

    @Query("DELETE FROM projects WHERE id = :id")
    suspend fun deleteProject(id: Long)

    // ---- Accounts ----

    @Query("SELECT * FROM accounts ORDER BY label COLLATE NOCASE ASC")
    fun observeAccounts(): Flow<List<Account>>

    @Query("SELECT * FROM accounts")
    suspend fun getAccounts(): List<Account>

    @Query("SELECT * FROM accounts WHERE id = :id")
    suspend fun getAccount(id: Long): Account?

    @Insert
    suspend fun insertAccount(account: Account): Long

    @Update
    suspend fun updateAccount(account: Account)

    @Query("DELETE FROM accounts WHERE id = :id")
    suspend fun deleteAccount(id: Long)

    @Query("UPDATE projects SET accountId = NULL WHERE accountId = :accountId")
    suspend fun clearAccount(accountId: Long)

    // ---- Activity history ----

    @Query("SELECT * FROM activity_events WHERE projectId = :projectId ORDER BY timestamp DESC, id DESC")
    fun observeEvents(projectId: Long): Flow<List<ActivityEvent>>

    @Insert
    suspend fun insertEvent(event: ActivityEvent): Long

    @Query(
        "DELETE FROM activity_events WHERE projectId = :projectId AND id NOT IN " +
            "(SELECT id FROM activity_events WHERE projectId = :projectId " +
            "ORDER BY timestamp DESC, id DESC LIMIT :keep)"
    )
    suspend fun trimEvents(projectId: Long, keep: Int)

    @Query("DELETE FROM activity_events WHERE projectId = :projectId")
    suspend fun deleteEvents(projectId: Long)

    @Query(
        "UPDATE activity_events SET note = :note WHERE id = " +
            "(SELECT id FROM activity_events WHERE projectId = :projectId " +
            "ORDER BY timestamp DESC, id DESC LIMIT 1)"
    )
    suspend fun setLatestEventNote(projectId: Long, note: String)
}
