package com.claudemanager.app.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.claudemanager.app.data.Account
import com.claudemanager.app.data.ActivityStatus
import com.claudemanager.app.data.Project
import com.claudemanager.app.util.TimeUtil

/** Everything a project card can ask the app to do. */
class ProjectActions(
    val onStatusClick: (Long) -> Unit,
    val onSetStatus: (Long, ActivityStatus) -> Unit,
    val onStart: (Long) -> Unit,
    val onResetTimer: (Long) -> Unit,
    val onToggleFavorite: (Long) -> Unit,
    val onEditNote: (Long) -> Unit,
    val onSetTimer: (Long) -> Unit,
    val onHistory: (Long) -> Unit,
    val onEdit: (Long) -> Unit,
    val onDelete: (Long) -> Unit
)

private enum class Quick(val label: String, val color: Color) {
    START("START", Color(0xFF2FBF71)),
    RESUME("RESUME", Color(0xFF2FBF71)),
    BUILD("BUILD", Color(0xFF3B82F6)),
    TEST("TEST", Color(0xFFA266F0)),
    DONE("DONE", Color(0xFFB7BECC)),
    ERROR("ERROR", Color(0xFFEF4B4B)),
    RESET("RESET", Color(0xFFF2A93B))
}

/** The next logical step(s) from each status, at most three buttons. */
private fun quickFor(status: ActivityStatus): List<Quick> = when (status) {
    ActivityStatus.READY -> listOf(Quick.START, Quick.BUILD)
    ActivityStatus.RUNNING -> listOf(Quick.BUILD, Quick.TEST, Quick.DONE)
    ActivityStatus.BUILDING -> listOf(Quick.TEST, Quick.DONE, Quick.ERROR)
    ActivityStatus.TESTING -> listOf(Quick.DONE, Quick.BUILD, Quick.ERROR)
    ActivityStatus.WAITING -> listOf(Quick.RESUME, Quick.BUILD, Quick.DONE)
    ActivityStatus.FINISHED -> listOf(Quick.START, Quick.RESET)
    ActivityStatus.ERROR -> listOf(Quick.BUILD, Quick.TEST, Quick.DONE)
    ActivityStatus.CUSTOM -> listOf(Quick.BUILD, Quick.TEST, Quick.DONE)
}

private fun runQuick(q: Quick, id: Long, actions: ProjectActions) {
    when (q) {
        Quick.START -> actions.onStart(id)
        Quick.RESUME -> actions.onSetStatus(id, ActivityStatus.RUNNING)
        Quick.BUILD -> actions.onSetStatus(id, ActivityStatus.BUILDING)
        Quick.TEST -> actions.onSetStatus(id, ActivityStatus.TESTING)
        Quick.DONE -> actions.onSetStatus(id, ActivityStatus.FINISHED)
        Quick.ERROR -> actions.onSetStatus(id, ActivityStatus.ERROR)
        Quick.RESET -> actions.onResetTimer(id)
    }
}

/**
 * One compact row per project, titled by its account:
 *
 *   * Account                       9:00 AM  :
 *   (o BUILDING v)       [TEST] [DONE] [ERROR]
 */
@Composable
fun ProjectCard(
    p: Project,
    account: Account?,
    now: Long,
    alarmOn: Boolean,
    actions: ProjectActions
) {
    val cs = MaterialTheme.colorScheme
    val accent = statusColor(p.activityStatus)
    val rail by animateColorAsState(targetValue = accent, label = "statusRail")

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = cs.surface),
        border = BorderStroke(1.dp, cs.outlineVariant)
    ) {
        Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {
            // The rail is the status, readable from across the room.
            Box(
                Modifier
                    .width(5.dp)
                    .fillMaxHeight()
                    .background(rail)
            )
            Column(
                Modifier
                    .weight(1f)
                    .padding(start = 8.dp, end = 6.dp, top = 2.dp, bottom = 8.dp)
            ) {
                CardHeader(p, account, now, alarmOn, actions)
                StatusRow(p, accent, actions)
                NoteLine(p, actions)
                ResetProgress(p, now, accent)
            }
        }
    }
}

@Composable
private fun CardHeader(
    p: Project,
    account: Account?,
    now: Long,
    alarmOn: Boolean,
    actions: ProjectActions
) {
    val cs = MaterialTheme.colorScheme
    Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(
            onClick = { actions.onToggleFavorite(p.id) },
            modifier = Modifier.size(36.dp)
        ) {
            Icon(
                Icons.Filled.Star,
                contentDescription = if (p.favorite) "Remove from favorites" else "Add to favorites",
                tint = if (p.favorite) StarGold else cs.outline,
                modifier = Modifier.size(20.dp)
            )
        }
        Text(
            text = displayTitle(p, account),
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 4.dp),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        ResetTime(p, now, alarmOn) { actions.onSetTimer(p.id) }
        ProjectMenu(p, actions)
    }
}

/** The reset time as a clock time, like an alarm. Tap it to change it. */
@Composable
private fun ResetTime(p: Project, now: Long, alarmOn: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val context = LocalContext.current
    val end = p.timerEndTimestamp
    val numerals = MaterialTheme.typography.titleSmall.copy(fontFeatureSettings = "tnum")

    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 2.dp),
        horizontalAlignment = Alignment.End
    ) {
        if (end == null) {
            Text(
                text = "Set time",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.SemiBold,
                color = cs.primary
            )
        } else {
            val reached = end <= now
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (alarmOn && !reached) {
                    Icon(
                        Icons.Filled.Notifications,
                        contentDescription = "Alarm set",
                        tint = cs.primary,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                }
                Text(
                    text = TimeUtil.formatClock(context, end, now),
                    style = numerals,
                    fontWeight = FontWeight.Bold,
                    color = if (reached) ResetGreen else cs.onSurface
                )
            }
            Text(
                text = if (reached) "Reset reached" else "in ${TimeUtil.formatRemaining(end - now)}",
                style = MaterialTheme.typography.labelSmall,
                color = cs.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun ProjectMenu(p: Project, actions: ProjectActions) {
    val cs = MaterialTheme.colorScheme
    var open by remember { mutableStateOf(false) }

    Box {
        IconButton(onClick = { open = true }, modifier = Modifier.size(36.dp)) {
            Icon(Icons.Filled.MoreVert, contentDescription = "More", modifier = Modifier.size(20.dp))
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            MenuEntry("Set reset time") {
                open = false
                actions.onSetTimer(p.id)
            }
            MenuEntry("Start \u00B7 reset in ${TimeUtil.formatDuration(p.defaultDurationMillis)}") {
                open = false
                actions.onStart(p.id)
            }
            MenuEntry("Clear reset time", enabled = p.timerEndTimestamp != null) {
                open = false
                actions.onResetTimer(p.id)
            }
            MenuEntry("Edit note") {
                open = false
                actions.onEditNote(p.id)
            }
            MenuEntry("Activity history") {
                open = false
                actions.onHistory(p.id)
            }
            MenuEntry("Edit project") {
                open = false
                actions.onEdit(p.id)
            }
            MenuEntry("Delete project", color = cs.error) {
                open = false
                actions.onDelete(p.id)
            }
        }
    }
}

@Composable
private fun MenuEntry(
    text: String,
    enabled: Boolean = true,
    color: Color = Color.Unspecified,
    onClick: () -> Unit
) {
    DropdownMenuItem(
        text = { Text(text, color = color) },
        onClick = onClick,
        enabled = enabled
    )
}

/** Status chip on the left, the next-step buttons on the right. */
@Composable
private fun StatusRow(p: Project, accent: Color, actions: ProjectActions) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // The box takes the leftover width so the buttons stay on the right edge.
        Box(Modifier.weight(1f)) {
            StatusPill(
                label = statusLabel(p.activityStatus, p.customStatusLabel),
                color = accent,
                onClick = { actions.onStatusClick(p.id) }
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            quickFor(p.activityStatus).forEach { q ->
                QuickButton(q.label, q.color) { runQuick(q, p.id, actions) }
            }
        }
    }
}

/** The note, or a prompt to add one when the project is in ERROR. Shown only when needed. */
@Composable
private fun NoteLine(p: Project, actions: ProjectActions) {
    val cs = MaterialTheme.colorScheme
    val isError = p.activityStatus == ActivityStatus.ERROR
    val text = when {
        p.activityNote.isNotBlank() -> p.activityNote
        isError -> "Add error note"
        else -> return
    }
    Text(
        text = text,
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 4.dp)
            .clickable { actions.onEditNote(p.id) },
        style = MaterialTheme.typography.bodySmall,
        color = if (isError) cs.error else cs.onSurfaceVariant,
        maxLines = 2,
        overflow = TextOverflow.Ellipsis
    )
}

/** Hairline progress toward the reset. Green and full once the reset has passed. */
@Composable
private fun ResetProgress(p: Project, now: Long, accent: Color) {
    val end = p.timerEndTimestamp ?: return
    val start = p.timerStartTimestamp
    val barModifier = Modifier.padding(top = 8.dp, end = 2.dp)

    if (end <= now) {
        TimerBar(1f, ResetGreen, barModifier, barHeight = 3.dp)
    } else {
        val fraction = if (start != null && end > start) {
            ((now - start).toFloat() / (end - start).toFloat()).coerceIn(0f, 1f)
        } else {
            0f
        }
        TimerBar(fraction, accent, barModifier, barHeight = 3.dp)
    }
}
