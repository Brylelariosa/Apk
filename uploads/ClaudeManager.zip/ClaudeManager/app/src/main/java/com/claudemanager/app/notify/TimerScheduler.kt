package com.claudemanager.app.notify

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.claudemanager.app.data.Project

/**
 * Schedules one inexact alarm per project that fires when its timer reaches zero.
 * Alarms do not survive a reboot; they are re-created whenever the app is opened.
 */
object TimerScheduler {

    const val CHANNEL_ID = "timer_reset"
    const val EXTRA_ID = "project_id"
    const val EXTRA_NAME = "project_name"
    const val EXTRA_ACCOUNT = "account_label"

    fun ensureChannel(context: Context) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Timer resets",
            NotificationManager.IMPORTANCE_DEFAULT
        )
        channel.description = "Tells you when a project's timer reaches zero"
        nm.createNotificationChannel(channel)
    }

    fun schedule(context: Context, project: Project, accountLabel: String?, enabled: Boolean) {
        val end = project.timerEndTimestamp
        if (!enabled || end == null) {
            cancel(context, project.id)
            return
        }
        if (end <= System.currentTimeMillis()) {
            cancel(context, project.id)
            return
        }

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, TimerReceiver::class.java).apply {
            putExtra(EXTRA_ID, project.id)
            putExtra(EXTRA_NAME, project.name)
            putExtra(EXTRA_ACCOUNT, accountLabel.orEmpty())
        }
        val pending = PendingIntent.getBroadcast(
            context,
            project.id.toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, end, pending)
    }

    fun cancel(context: Context, projectId: Long) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pending: PendingIntent? = PendingIntent.getBroadcast(
            context,
            projectId.toInt(),
            Intent(context, TimerReceiver::class.java),
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pending != null) {
            alarmManager.cancel(pending)
            pending.cancel()
        }
    }
}
