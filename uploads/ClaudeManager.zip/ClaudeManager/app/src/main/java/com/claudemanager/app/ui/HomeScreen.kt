package com.claudemanager.app.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.claudemanager.app.data.Account
import com.claudemanager.app.data.ActivityStatus
import com.claudemanager.app.data.Project
import com.claudemanager.app.util.TimeUtil

/** Everything a project card can ask the app to do. */
class ProjectActions(
    val onStatusClick: (Long) -> Unit,
    val onSetStatus: (Long, ActivityStatus) -> Unit,
    val onStart: (Long) -> Unit,
    val onResetTimer: (Long) -> Unit,
    val onToggleFavorite: (Long) -> Unit,
    val onEditNote: (Long) -> Unit,
    val onSetTimer: (Long) -> Unit,
    val onHistory: (Long) -> Unit,
    val onEdit: (Long) -> Unit,
    val onDelete: (Long) -> Unit
)

private val ActiveStatuses = setOf(
    ActivityStatus.RUNNING,
    ActivityStatus.BUILDING,
    ActivityStatus.TESTING
)

private val FilterOrder = listOf(
    ActivityStatus.RUNNING,
    ActivityStatus.BUILDING,
    ActivityStatus.TESTING,
    ActivityStatus.WAITING,
    ActivityStatus.FINISHED,
    ActivityStatus.ERROR,
    ActivityStatus.READY,
    ActivityStatus.CUSTOM
)

@Composable
fun HomeScreen(
    projects: List<Project>?,
    accounts: List<Account>,
    now: Long,
    actions: ProjectActions,
    onAdd: () -> Unit,
    onOpenAccounts: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    var query by rememberSaveable { mutableStateOf("") }
    var filter by rememberSaveable { mutableStateOf("ALL") }
    var menuOpen by remember { mutableStateOf(false) }

    val all = projects ?: emptyList()
    val accountById = remember(accounts) { accounts.associateBy { it.id } }
    val sorted = remember(all) {
        all.sortedWith(compareByDescending<Project> { it.favorite }.thenBy { it.name.lowercase() })
    }
    val counts = remember(all) { all.groupingBy { it.activityStatus }.eachCount() }
    val active = remember(sorted) { sorted.filter { it.activityStatus in ActiveStatuses } }
    val q = query.trim()
    val visible = remember(sorted, filter, q, accountById) {
        sorted.filter { p ->
            val account = p.accountId?.let { accountById[it] }
            val matchesFilter = filter == "ALL" || p.activityStatus.name == filter
            val matchesQuery = q.isEmpty() ||
                p.name.contains(q, ignoreCase = true) ||
                (account?.label?.contains(q, ignoreCase = true) == true) ||
                (account?.email?.contains(q, ignoreCase = true) == true)
            matchesFilter && matchesQuery
        }
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = onAdd,
                containerColor = cs.primary,
                contentColor = cs.onPrimary
            ) {
                Icon(Icons.Filled.Add, contentDescription = "New project")
            }
        }
    ) { inner ->
        Column(Modifier.fillMaxSize().padding(inner)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 20.dp, end = 8.dp, top = 8.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Claude Manager",
                    modifier = Modifier.weight(1f),
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )
                Box {
                    IconButton(onClick = { menuOpen = true }) {
                        Icon(Icons.Filled.MoreVert, contentDescription = "Menu")
                    }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        DropdownMenuItem(
                            text = { Text("Accounts") },
                            onClick = {
                                menuOpen = false
                                onOpenAccounts()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Settings") },
                            onClick = {
                                menuOpen = false
                                onOpenSettings()
                            }
                        )
                    }
                }
            }

            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item(key = "search") {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Search projects or accounts") },
                        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                        trailingIcon = {
                            if (query.isNotEmpty()) {
                                IconButton(onClick = { query = "" }) {
                                    Icon(Icons.Filled.Close, contentDescription = "Clear search")
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(16.dp)
                    )
                }

                if (active.isNotEmpty() && q.isEmpty()) {
                    item(key = "active") {
                        Column {
                            SectionLabel("CURRENTLY ACTIVE", Modifier.padding(start = 4.dp, bottom = 8.dp))
                            ActiveBox(active, now, actions.onStatusClick)
                        }
                    }
                }

                item(key = "filters") {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        item(key = "ALL") {
                            FilterPill("ALL ${all.size}", filter == "ALL", cs.primary) { filter = "ALL" }
                        }
                        val shown = FilterOrder.filter {
                            it != ActivityStatus.CUSTOM || (counts[it] ?: 0) > 0 || filter == it.name
                        }
                        items(shown, key = { it.name }) { s ->
                            val n = counts[s] ?: 0
                            FilterPill(
                                label = if (n > 0) "${s.name} $n" else s.name,
                                selected = filter == s.name,
                                color = statusColor(s)
                            ) { filter = s.name }
                        }
                    }
                }

                item(key = "all_label") {
                    SectionLabel("ALL PROJECTS", Modifier.padding(start = 4.dp))
                }

                if (projects != null && all.isEmpty()) {
                    item(key = "empty") {
                        EmptyState(
                            "No projects yet",
                            "Tap + to add one. Pick an account, set the default timer, then press START."
                        )
                    }
                } else if (projects != null && visible.isEmpty()) {
                    item(key = "no_match") {
                        EmptyState(
                            "Nothing here",
                            "No project matches. Clear the search or pick another filter."
                        )
                    }
                }

                items(visible, key = { it.id }) { p ->
                    ProjectCard(
                        p = p,
                        account = p.accountId?.let { accountById[it] },
                        now = now,
                        actions = actions
                    )
                }
            }
        }
    }
}

@Composable
private fun EmptyState(title: String, body: String) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 24.dp)) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold
        )
        Spacer(Modifier.height(6.dp))
        Text(
            text = body,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

private fun activeLine(p: Project, now: Long): String {
    val label = statusLabel(p.activityStatus, p.customStatusLabel)
    val end = p.timerEndTimestamp ?: return label
    return if (end > now) {
        "$label \u00B7 ${TimeUtil.formatRemaining(end - now)}"
    } else {
        "$label \u00B7 reset reached"
    }
}

/** The CURRENTLY ACTIVE strip. Tapping a row opens its status list. */
@Composable
private fun ActiveBox(active: List<Project>, now: Long, onClick: (Long) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(cs.surfaceVariant)
    ) {
        active.forEachIndexed { index, p ->
            if (index > 0) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(cs.outlineVariant)
                )
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onClick(p.id) }
                    .padding(horizontal = 16.dp, vertical = 13.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                StatusDot(statusColor(p.activityStatus), 12.dp)
                Spacer(Modifier.width(12.dp))
                Text(
                    text = p.name,
                    modifier = Modifier.weight(1f),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.width(12.dp))
                Text(
                    text = activeLine(p, now),
                    style = MaterialTheme.typography.labelLarge,
                    color = cs.onSurfaceVariant
                )
            }
        }
    }
}

private enum class Quick(val label: String, val color: Color) {
    START("START", Color(0xFF2FBF71)),
    RESUME("RESUME", Color(0xFF2FBF71)),
    BUILD("BUILD", Color(0xFF3B82F6)),
    TEST("TEST", Color(0xFFA266F0)),
    DONE("DONE", Color(0xFFB7BECC)),
    ERROR("ERROR", Color(0xFFEF4B4B)),
    RESET("RESET", Color(0xFFF2A93B))
}

/** The next logical step(s) from each status, at most three buttons. */
private fun quickFor(status: ActivityStatus): List<Quick> = when (status) {
    ActivityStatus.READY -> listOf(Quick.START, Quick.BUILD)
    ActivityStatus.RUNNING -> listOf(Quick.BUILD, Quick.TEST, Quick.DONE)
    ActivityStatus.BUILDING -> listOf(Quick.TEST, Quick.DONE, Quick.ERROR)
    ActivityStatus.TESTING -> listOf(Quick.DONE, Quick.BUILD, Quick.ERROR)
    ActivityStatus.WAITING -> listOf(Quick.RESUME, Quick.BUILD, Quick.DONE)
    ActivityStatus.FINISHED -> listOf(Quick.START, Quick.RESET)
    ActivityStatus.ERROR -> listOf(Quick.BUILD, Quick.TEST, Quick.DONE)
    ActivityStatus.CUSTOM -> listOf(Quick.BUILD, Quick.TEST, Quick.DONE)
}

private fun runQuick(q: Quick, id: Long, actions: ProjectActions) {
    when (q) {
        Quick.START -> actions.onStart(id)
        Quick.RESUME -> actions.onSetStatus(id, ActivityStatus.RUNNING)
        Quick.BUILD -> actions.onSetStatus(id, ActivityStatus.BUILDING)
        Quick.TEST -> actions.onSetStatus(id, ActivityStatus.TESTING)
        Quick.DONE -> actions.onSetStatus(id, ActivityStatus.FINISHED)
        Quick.ERROR -> actions.onSetStatus(id, ActivityStatus.ERROR)
        Quick.RESET -> actions.onResetTimer(id)
    }
}

@Composable
private fun ProjectCard(p: Project, account: Account?, now: Long, actions: ProjectActions) {
    val cs = MaterialTheme.colorScheme
    val accent = statusColor(p.activityStatus)
    val rail by animateColorAsState(targetValue = accent, label = "statusRail")
    var menuOpen by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = cs.surface),
        border = BorderStroke(1.dp, cs.outlineVariant)
    ) {
        Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {
            // The rail is the status, readable from across the room.
            Box(
                Modifier
                    .width(6.dp)
                    .fillMaxHeight()
                    .background(rail)
            )
            Column(
                Modifier
                    .weight(1f)
                    .padding(start = 12.dp, end = 4.dp, top = 6.dp, bottom = 14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { actions.onToggleFavorite(p.id) },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            Icons.Filled.Star,
                            contentDescription = if (p.favorite) "Remove from favorites" else "Add to favorites",
                            tint = if (p.favorite) StarGold else cs.outline,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Text(
                        text = p.name,
                        modifier = Modifier.weight(1f).padding(start = 4.dp),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Box {
                        IconButton(onClick = { menuOpen = true }) {
                            Icon(Icons.Filled.MoreVert, contentDescription = "More")
                        }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            DropdownMenuItem(
                                text = { Text("Start timer") },
                                onClick = {
                                    menuOpen = false
                                    actions.onStart(p.id)
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Set remaining time") },
                                onClick = {
                                    menuOpen = false
                                    actions.onSetTimer(p.id)
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Reset timer") },
                                enabled = p.timerEndTimestamp != null,
                                onClick = {
                                    menuOpen = false
                                    actions.onResetTimer(p.id)
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Edit note") },
                                onClick = {
                                    menuOpen = false
                                    actions.onEditNote(p.id)
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Activity history") },
                                onClick = {
                                    menuOpen = false
                                    actions.onHistory(p.id)
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Edit project") },
                                onClick = {
                                    menuOpen = false
                                    actions.onEdit(p.id)
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Delete project", color = cs.error) },
                                onClick = {
                                    menuOpen = false
                                    actions.onDelete(p.id)
                                }
                            )
                        }
                    }
                }

                Column(Modifier.padding(end = 10.dp)) {
                    if (account != null) {
                        Text(
                            text = account.label,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium
                        )
                        if (account.email.isNotBlank()) {
                            Text(
                                text = account.email,
                                style = MaterialTheme.typography.bodySmall,
                                color = cs.onSurfaceVariant
                            )
                        }
                    } else {
                        Text(
                            text = "No account",
                            style = MaterialTheme.typography.bodyMedium,
                            color = cs.onSurfaceVariant
                        )
                    }

                    Spacer(Modifier.height(12.dp))
                    Row {
                        StatusPill(
                            label = statusLabel(p.activityStatus, p.customStatusLabel),
                            color = accent,
                            onClick = { actions.onStatusClick(p.id) }
                        )
                    }

                    val isError = p.activityStatus == ActivityStatus.ERROR
                    if (p.activityNote.isNotBlank()) {
                        Text(
                            text = p.activityNote,
                            modifier = Modifier
                                .padding(top = 8.dp)
                                .clickable { actions.onEditNote(p.id) },
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (isError) cs.error else cs.onSurfaceVariant
                        )
                    } else if (isError) {
                        Text(
                            text = "Add error note",
                            modifier = Modifier
                                .padding(top = 8.dp)
                                .clickable { actions.onEditNote(p.id) },
                            style = MaterialTheme.typography.bodyMedium,
                            color = cs.error
                        )
                    }

                    Spacer(Modifier.height(14.dp))
                    TimerSection(p, now, accent)
                    Spacer(Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        quickFor(p.activityStatus).forEach { q ->
                            QuickButton(q.label, q.color, Modifier.weight(1f)) {
                                runQuick(q, p.id, actions)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TimerSection(p: Project, now: Long, accent: Color) {
    val cs = MaterialTheme.colorScheme
    val context = LocalContext.current
    val end = p.timerEndTimestamp
    val numerals = MaterialTheme.typography.headlineSmall.copy(fontFeatureSettings = "tnum")

    if (end == null) {
        Text(
            text = "No timer",
            style = MaterialTheme.typography.titleMedium,
            color = cs.onSurfaceVariant
        )
    } else if (end > now) {
        val start = p.timerStartTimestamp
        val fraction = if (start != null && end > start) {
            ((now - start).toFloat() / (end - start).toFloat()).coerceIn(0f, 1f)
        } else {
            0f
        }
        Row(verticalAlignment = Alignment.Bottom) {
            Text(
                text = TimeUtil.formatRemaining(end - now),
                style = numerals,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.width(8.dp))
            Text(
                text = "remaining",
                modifier = Modifier.padding(bottom = 3.dp).weight(1f),
                style = MaterialTheme.typography.bodyMedium,
                color = cs.onSurfaceVariant
            )
            Text(
                text = "Reset ${TimeUtil.formatClock(context, end, now)}",
                modifier = Modifier.padding(bottom = 3.dp),
                style = MaterialTheme.typography.bodyMedium,
                color = cs.onSurfaceVariant
            )
        }
        Spacer(Modifier.height(8.dp))
        TimerBar(fraction, accent)
    } else {
        Row(verticalAlignment = Alignment.Bottom) {
            Text(
                text = "Reset reached",
                modifier = Modifier.weight(1f),
                style = numerals,
                fontWeight = FontWeight.Bold,
                color = ResetGreen
            )
            Text(
                text = "at ${TimeUtil.formatClock(context, end, now)}",
                modifier = Modifier.padding(bottom = 3.dp),
                style = MaterialTheme.typography.bodyMedium,
                color = cs.onSurfaceVariant
            )
        }
        Spacer(Modifier.height(8.dp))
        TimerBar(1f, ResetGreen)
    }
}
