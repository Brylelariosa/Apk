package com.claudemanager.app.ui

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.claudemanager.app.data.Account
import com.claudemanager.app.data.ActivityStatus
import com.claudemanager.app.data.Project
import com.claudemanager.app.util.TimeUtil

private val ActiveStatuses = setOf(
    ActivityStatus.RUNNING,
    ActivityStatus.BUILDING,
    ActivityStatus.TESTING
)

private val FilterOrder = listOf(
    ActivityStatus.RUNNING,
    ActivityStatus.BUILDING,
    ActivityStatus.TESTING,
    ActivityStatus.WAITING,
    ActivityStatus.FINISHED,
    ActivityStatus.ERROR,
    ActivityStatus.READY,
    ActivityStatus.CUSTOM
)

@Composable
fun HomeScreen(
    projects: List<Project>?,
    accounts: List<Account>,
    now: Long,
    alarmOn: Boolean,
    actions: ProjectActions,
    onAdd: () -> Unit,
    onOpenAccounts: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    var query by rememberSaveable { mutableStateOf("") }
    var filter by rememberSaveable { mutableStateOf("ALL") }
    var menuOpen by remember { mutableStateOf(false) }

    val all = projects ?: emptyList()
    val accountById = remember(accounts) { accounts.associateBy { it.id } }
    // Rows are titled by account, so that is also what the list is ordered by.
    val sorted = remember(all, accountById) {
        all.sortedWith(
            compareByDescending<Project> { it.favorite }
                .thenBy { displayTitle(it, it.accountId?.let { id -> accountById[id] }).lowercase() }
                .thenBy { it.name.lowercase() }
        )
    }
    val counts = remember(all) { all.groupingBy { it.activityStatus }.eachCount() }
    val active = remember(sorted) { sorted.filter { it.activityStatus in ActiveStatuses } }
    val q = query.trim()
    val visible = remember(sorted, filter, q, accountById) {
        sorted.filter { p ->
            val account = p.accountId?.let { accountById[it] }
            val matchesFilter = filter == "ALL" || p.activityStatus.name == filter
            val matchesQuery = q.isEmpty() ||
                p.name.contains(q, ignoreCase = true) ||
                (account?.label?.contains(q, ignoreCase = true) == true) ||
                (account?.email?.contains(q, ignoreCase = true) == true)
            matchesFilter && matchesQuery
        }
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = onAdd,
                containerColor = cs.primary,
                contentColor = cs.onPrimary
            ) {
                Icon(Icons.Filled.Add, contentDescription = "New project")
            }
        }
    ) { inner ->
        Column(Modifier.fillMaxSize().padding(inner)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 20.dp, end = 8.dp, top = 4.dp, bottom = 0.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Claude Manager",
                    modifier = Modifier.weight(1f),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Box {
                    IconButton(onClick = { menuOpen = true }) {
                        Icon(Icons.Filled.MoreVert, contentDescription = "Menu")
                    }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        DropdownMenuItem(
                            text = { Text("Accounts") },
                            onClick = {
                                menuOpen = false
                                onOpenAccounts()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Settings") },
                            onClick = {
                                menuOpen = false
                                onOpenSettings()
                            }
                        )
                    }
                }
            }

            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 4.dp, bottom = 88.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item(key = "search") {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Search accounts or projects") },
                        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                        trailingIcon = {
                            if (query.isNotEmpty()) {
                                IconButton(onClick = { query = "" }) {
                                    Icon(Icons.Filled.Close, contentDescription = "Clear search")
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(16.dp)
                    )
                }

                if (active.isNotEmpty() && q.isEmpty()) {
                    item(key = "active") {
                        Column {
                            SectionLabel("CURRENTLY ACTIVE", Modifier.padding(start = 4.dp, top = 4.dp, bottom = 6.dp))
                            ActiveBox(active, accountById, now, actions.onStatusClick)
                        }
                    }
                }

                item(key = "filters") {
                    LazyRow(
                        modifier = Modifier.padding(top = 2.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        item(key = "ALL") {
                            FilterPill("ALL ${all.size}", filter == "ALL", cs.primary) { filter = "ALL" }
                        }
                        val shown = FilterOrder.filter {
                            it != ActivityStatus.CUSTOM || (counts[it] ?: 0) > 0 || filter == it.name
                        }
                        items(shown, key = { it.name }) { s ->
                            val n = counts[s] ?: 0
                            FilterPill(
                                label = if (n > 0) "${s.name} $n" else s.name,
                                selected = filter == s.name,
                                color = statusColor(s)
                            ) { filter = s.name }
                        }
                    }
                }

                item(key = "all_label") {
                    SectionLabel("ALL PROJECTS", Modifier.padding(start = 4.dp, top = 2.dp))
                }

                if (projects != null && all.isEmpty()) {
                    item(key = "empty") {
                        EmptyState(
                            "No projects yet",
                            "Tap + to add one. Pick an account, then press START or set its reset time."
                        )
                    }
                } else if (projects != null && visible.isEmpty()) {
                    item(key = "no_match") {
                        EmptyState(
                            "Nothing here",
                            "No project matches. Clear the search or pick another filter."
                        )
                    }
                }

                items(visible, key = { it.id }) { p ->
                    ProjectCard(
                        p = p,
                        account = p.accountId?.let { accountById[it] },
                        now = now,
                        alarmOn = alarmOn,
                        actions = actions
                    )
                }
            }
        }
    }
}

@Composable
private fun EmptyState(title: String, body: String) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 24.dp)) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold
        )
        Spacer(Modifier.height(6.dp))
        Text(
            text = body,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

/** "BUILDING · 9:00 AM": status and the clock time the limit resets. */
private fun activeLine(context: Context, p: Project, now: Long): String {
    val label = statusLabel(p.activityStatus, p.customStatusLabel)
    val end = p.timerEndTimestamp ?: return label
    return if (end > now) {
        "$label \u00B7 ${TimeUtil.formatClock(context, end, now)}"
    } else {
        "$label \u00B7 reset reached"
    }
}

/** The CURRENTLY ACTIVE strip. Tapping a row opens its status list. */
@Composable
private fun ActiveBox(
    active: List<Project>,
    accountById: Map<Long, Account>,
    now: Long,
    onClick: (Long) -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val context = LocalContext.current
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(cs.surfaceVariant)
    ) {
        active.forEachIndexed { index, p ->
            if (index > 0) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(cs.outlineVariant)
                )
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onClick(p.id) }
                    .padding(horizontal = 14.dp, vertical = 9.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                StatusDot(statusColor(p.activityStatus), 10.dp)
                Spacer(Modifier.width(10.dp))
                Text(
                    text = displayTitle(p, p.accountId?.let { accountById[it] }),
                    modifier = Modifier.weight(1f),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    text = activeLine(context, p, now),
                    style = MaterialTheme.typography.labelLarge,
                    color = cs.onSurfaceVariant,
                    maxLines = 1
                )
            }
        }
    }
}
