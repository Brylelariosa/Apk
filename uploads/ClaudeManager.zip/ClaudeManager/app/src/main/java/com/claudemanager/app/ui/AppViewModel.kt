package com.claudemanager.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.withTransaction
import com.claudemanager.app.data.Account
import com.claudemanager.app.data.ActivityEvent
import com.claudemanager.app.data.ActivityStatus
import com.claudemanager.app.data.AppDatabase
import com.claudemanager.app.data.Prefs
import com.claudemanager.app.data.Project
import com.claudemanager.app.data.Settings
import com.claudemanager.app.notify.TimerScheduler
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AppViewModel(private val app: Application) : AndroidViewModel(app) {

    private val db = AppDatabase.get(app)
    private val dao = db.dao()
    private val prefs = Prefs(app)

    val settings = MutableStateFlow(prefs.load())

    /** null until the first database read finishes. */
    val projects: StateFlow<List<Project>?> =
        dao.observeProjects().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000L), null)

    val accounts: StateFlow<List<Account>> =
        dao.observeAccounts().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000L), emptyList())

    /** Ticks once a second, but only while the UI is visible. */
    val ticker: StateFlow<Long> =
        flow {
            while (true) {
                emit(System.currentTimeMillis())
                delay(1_000L)
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(0L), System.currentTimeMillis())

    init {
        // Alarms are lost on reboot, so re-create them every time the app starts.
        viewModelScope.launch { rescheduleAll() }
    }

    fun events(projectId: Long): Flow<List<ActivityEvent>> = dao.observeEvents(projectId)

    // ------------------------------------------------------------------
    // Activity status (never touches the timer)
    // ------------------------------------------------------------------

    fun setStatus(id: Long, status: ActivityStatus, customLabel: String = "") {
        mutate(id) { cur, t ->
            val label = if (status == ActivityStatus.CUSTOM) customLabel.trim() else ""
            if (cur.activityStatus == status && cur.customStatusLabel == label) {
                null
            } else {
                logEvent(id, status, label, t)
                cur.copy(
                    activityStatus = status,
                    customStatusLabel = label,
                    activityNote = "",
                    lastActivityChangeAt = t
                )
            }
        }
    }

    fun setNote(id: Long, note: String) {
        mutate(id) { cur, _ ->
            val text = note.trim()
            dao.setLatestEventNote(id, text)
            cur.copy(activityNote = text)
        }
    }

    // ------------------------------------------------------------------
    // Timer
    // ------------------------------------------------------------------

    /** START: begin the default-length timer and mark the project RUNNING. */
    fun start(id: Long) {
        mutate(id) { cur, t ->
            logEvent(id, ActivityStatus.RUNNING, "", t)
            cur.copy(
                activityStatus = ActivityStatus.RUNNING,
                customStatusLabel = "",
                activityNote = "",
                timerStartTimestamp = t,
                timerEndTimestamp = t + cur.defaultDurationMillis,
                lastStartedAt = t,
                lastActivityChangeAt = t
            )
        }
    }

    /** RESET: clear the timer only. The activity status stays as it is. */
    fun resetTimer(id: Long) {
        mutate(id) { cur, _ ->
            cur.copy(timerStartTimestamp = null, timerEndTimestamp = null)
        }
    }

    /** Type in how much time is left (for example 2h 30m) without touching the status. */
    fun setRemaining(id: Long, millis: Long) {
        mutate(id) { cur, t ->
            val end = t + millis
            val start = if (millis <= cur.defaultDurationMillis) end - cur.defaultDurationMillis else t
            cur.copy(timerStartTimestamp = start, timerEndTimestamp = end)
        }
    }

    fun toggleFavorite(id: Long) {
        mutate(id) { cur, _ -> cur.copy(favorite = !cur.favorite) }
    }

    // ------------------------------------------------------------------
    // Projects
    // ------------------------------------------------------------------

    fun saveProject(
        id: Long?,
        name: String,
        accountId: Long?,
        newAccountLabel: String?,
        newAccountEmail: String,
        durationMillis: Long
    ) {
        viewModelScope.launch {
            val saved: Project = db.withTransaction {
                var resolvedAccount = accountId
                if (!newAccountLabel.isNullOrBlank()) {
                    resolvedAccount = dao.insertAccount(
                        Account(label = newAccountLabel.trim(), email = newAccountEmail.trim())
                    )
                }
                val existing = if (id != null) dao.getProject(id) else null
                if (existing != null) {
                    val updated = existing.copy(
                        name = name.trim(),
                        accountId = resolvedAccount,
                        defaultDurationMillis = durationMillis
                    )
                    dao.updateProject(updated)
                    updated
                } else {
                    val created = Project(
                        name = name.trim(),
                        accountId = resolvedAccount,
                        defaultDurationMillis = durationMillis
                    )
                    created.copy(id = dao.insertProject(created))
                }
            }
            reschedule(saved)
        }
    }

    fun deleteProject(id: Long) {
        viewModelScope.launch {
            db.withTransaction {
                dao.deleteEvents(id)
                dao.deleteProject(id)
            }
            TimerScheduler.cancel(app, id)
        }
    }

    fun clearHistory(projectId: Long) {
        viewModelScope.launch { dao.deleteEvents(projectId) }
    }

    // ------------------------------------------------------------------
    // Accounts
    // ------------------------------------------------------------------

    fun saveAccount(id: Long?, label: String, email: String) {
        viewModelScope.launch {
            if (id == null) {
                dao.insertAccount(Account(label = label.trim(), email = email.trim()))
            } else {
                dao.updateAccount(Account(id = id, label = label.trim(), email = email.trim()))
            }
            rescheduleAll()
        }
    }

    fun deleteAccount(id: Long) {
        viewModelScope.launch {
            db.withTransaction {
                dao.clearAccount(id)
                dao.deleteAccount(id)
            }
            rescheduleAll()
        }
    }

    // ------------------------------------------------------------------
    // Settings
    // ------------------------------------------------------------------

    fun updateSettings(newSettings: Settings) {
        val old = settings.value
        settings.value = newSettings
        prefs.save(newSettings)
        viewModelScope.launch {
            if (newSettings.historyLimit < old.historyLimit) {
                for (p in dao.getProjects()) dao.trimEvents(p.id, newSettings.historyLimit)
            }
            if (newSettings.notificationsEnabled != old.notificationsEnabled) {
                rescheduleAll()
            }
        }
    }

    // ------------------------------------------------------------------
    // Internals
    // ------------------------------------------------------------------

    /**
     * Re-reads the project inside a transaction, applies [block], and saves the result.
     * Returning null from [block] means "nothing to change".
     */
    private fun mutate(id: Long, block: suspend (Project, Long) -> Project?) {
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            val updated: Project? = db.withTransaction {
                val current = dao.getProject(id)
                if (current == null) {
                    null
                } else {
                    val next = block(current, now)
                    if (next != null) dao.updateProject(next)
                    next
                }
            }
            if (updated != null) reschedule(updated)
        }
    }

    private suspend fun logEvent(projectId: Long, status: ActivityStatus, customLabel: String, timestamp: Long) {
        dao.insertEvent(
            ActivityEvent(
                projectId = projectId,
                status = status,
                customLabel = customLabel,
                timestamp = timestamp
            )
        )
        dao.trimEvents(projectId, settings.value.historyLimit)
    }

    private suspend fun reschedule(project: Project) {
        val label = project.accountId?.let { dao.getAccount(it)?.label }
        TimerScheduler.schedule(app, project, label, settings.value.notificationsEnabled)
    }

    private suspend fun rescheduleAll() {
        val labels = dao.getAccounts().associate { it.id to it.label }
        val enabled = settings.value.notificationsEnabled
        for (p in dao.getProjects()) {
            val label = p.accountId?.let { labels[it] }
            TimerScheduler.schedule(app, p, label, enabled)
        }
    }
}
