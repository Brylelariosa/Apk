package com.claudemanager.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.claudemanager.app.data.Account
import com.claudemanager.app.data.Project
import com.claudemanager.app.data.Settings

@Composable
private fun ScreenHeader(title: String, onBack: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onBack) {
            Text("\u2190", fontSize = 22.sp)
        }
        Text(
            text = title,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun AccountsScreen(
    accounts: List<Account>,
    projects: List<Project>,
    onBack: () -> Unit,
    onSave: (Long?, String, String) -> Unit,
    onDelete: (Long) -> Unit
) {
    val cs = MaterialTheme.colorScheme
    var adding by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Account?>(null) }
    var deleting by remember { mutableStateOf<Account?>(null) }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { adding = true },
                containerColor = cs.primary,
                contentColor = cs.onPrimary
            ) {
                Icon(Icons.Filled.Add, contentDescription = "Add account")
            }
        }
    ) { inner ->
        Column(Modifier.fillMaxSize().padding(inner)) {
            ScreenHeader("Accounts", onBack)
            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (accounts.isEmpty()) {
                    item(key = "empty") {
                        Text(
                            text = "No accounts yet. Add the Claude accounts you switch between, then pick one when you create a project.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = cs.onSurfaceVariant
                        )
                    }
                }
                items(accounts, key = { it.id }) { a ->
                    val count = projects.count { it.accountId == a.id }
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = cs.surface),
                        border = BorderStroke(1.dp, cs.outlineVariant)
                    ) {
                        Column(Modifier.fillMaxWidth().padding(start = 18.dp, end = 8.dp, top = 16.dp, bottom = 6.dp)) {
                            Text(
                                text = a.label,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            if (a.email.isNotBlank()) {
                                Text(
                                    text = a.email,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = cs.onSurfaceVariant
                                )
                            }
                            Text(
                                text = if (count == 1) "1 project" else "$count projects",
                                modifier = Modifier.padding(top = 4.dp),
                                style = MaterialTheme.typography.bodySmall,
                                color = cs.onSurfaceVariant
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                TextButton(onClick = { editing = a }) { Text("Edit") }
                                TextButton(onClick = { deleting = a }) {
                                    Text("Delete", color = cs.error)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (adding) {
        AccountDialog(
            initial = null,
            onSave = { label, email ->
                onSave(null, label, email)
                adding = false
            },
            onDismiss = { adding = false }
        )
    }

    val editTarget = editing
    if (editTarget != null) {
        AccountDialog(
            initial = editTarget,
            onSave = { label, email ->
                onSave(editTarget.id, label, email)
                editing = null
            },
            onDismiss = { editing = null }
        )
    }

    val deleteTarget = deleting
    if (deleteTarget != null) {
        val count = projects.count { it.accountId == deleteTarget.id }
        ConfirmDialog(
            title = "Delete ${deleteTarget.label}?",
            message = if (count == 0) {
                "This account has no projects."
            } else {
                "Its projects stay, but they will have no account."
            },
            confirmLabel = "Delete",
            onConfirm = {
                onDelete(deleteTarget.id)
                deleting = null
            },
            onDismiss = { deleting = null }
        )
    }
}

@Composable
fun SettingsScreen(
    settings: Settings,
    onBack: () -> Unit,
    onChange: (Settings) -> Unit
) {
    val cs = MaterialTheme.colorScheme
    var hours by remember { mutableStateOf((settings.defaultDurationMillis / 3_600_000L).toString()) }
    var minutes by remember { mutableStateOf(((settings.defaultDurationMillis / 60_000L) % 60L).toString()) }
    var limit by remember { mutableStateOf(settings.historyLimit.toString()) }

    fun push(h: String, m: String, l: String) {
        val millis = durationMillisOf(h, m)
        val keep = l.toIntOrNull() ?: 0
        if (millis > 0L && keep in 1..500) {
            onChange(settings.copy(defaultDurationMillis = millis, historyLimit = keep))
        }
    }

    Scaffold { inner ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(inner)
                .verticalScroll(rememberScrollState())
        ) {
            ScreenHeader("Settings", onBack)
            Column(
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(24.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Default timer",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "New projects start with this length. You can change it per project.",
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurfaceVariant
                    )
                    DurationFields(
                        hours = hours,
                        minutes = minutes,
                        onHoursChange = {
                            hours = it
                            push(it, minutes, limit)
                        },
                        onMinutesChange = {
                            minutes = it
                            push(hours, it, limit)
                        }
                    )
                }

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Activity history",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold
                    )
                    OutlinedTextField(
                        value = limit,
                        onValueChange = { v ->
                            val digits = v.filter { c -> c.isDigit() }.take(3)
                            limit = digits
                            push(hours, minutes, digits)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Entries kept per project") },
                        supportingText = { Text("Between 1 and 500. Older entries are dropped.") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            text = "Notify when a timer ends",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "One notification per project when its countdown reaches zero.",
                            style = MaterialTheme.typography.bodySmall,
                            color = cs.onSurfaceVariant
                        )
                    }
                    Spacer(Modifier.width(12.dp))
                    Switch(
                        checked = settings.notificationsEnabled,
                        onCheckedChange = { onChange(settings.copy(notificationsEnabled = it)) }
                    )
                }
            }
        }
    }
}
