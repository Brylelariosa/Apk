package com.claudemanager.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.claudemanager.app.data.Account
import com.claudemanager.app.data.Project
import com.claudemanager.app.data.Settings

@Composable
private fun ScreenHeader(title: String, onBack: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onBack) {
            Text("\u2190", fontSize = 22.sp)
        }
        Text(
            text = title,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun AccountsScreen(
    accounts: List<Account>,
    projects: List<Project>,
    onBack: () -> Unit,
    onSave: (Long?, String, String) -> Unit,
    onDelete: (Long) -> Unit
) {
    val cs = MaterialTheme.colorScheme
    var adding by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Account?>(null) }
    var deleting by remember { mutableStateOf<Account?>(null) }

    // An account with no project is idle. Idle accounts go first so the free ones are obvious.
    val projectCounts = remember(projects) { projects.groupingBy { it.accountId }.eachCount() }
    val ordered = remember(accounts, projectCounts) {
        accounts.sortedWith(
            compareByDescending<Account> { (projectCounts[it.id] ?: 0) == 0 }
                .thenBy { it.label.lowercase() }
        )
    }
    val idleCount = ordered.count { (projectCounts[it.id] ?: 0) == 0 }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { adding = true },
                containerColor = cs.primary,
                contentColor = cs.onPrimary
            ) {
                Icon(Icons.Filled.Add, contentDescription = "Add account")
            }
        }
    ) { inner ->
        Column(Modifier.fillMaxSize().padding(inner)) {
            ScreenHeader("Accounts", onBack)
            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 4.dp, bottom = 88.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (accounts.isEmpty()) {
                    item(key = "empty") {
                        Text(
                            text = "No accounts yet. Add the Claude accounts you switch between, then pick one when you create a project.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = cs.onSurfaceVariant
                        )
                    }
                } else {
                    item(key = "summary") {
                        Row(Modifier.padding(start = 4.dp, bottom = 2.dp)) {
                            Text(
                                text = "$idleCount idle",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = if (idleCount > 0) ResetGreen else cs.onSurfaceVariant
                            )
                            Text(
                                text = " \u00B7 ${accounts.size - idleCount} in use",
                                style = MaterialTheme.typography.labelLarge,
                                color = cs.onSurfaceVariant
                            )
                        }
                    }
                }
                items(ordered, key = { it.id }) { a ->
                    val count = projectCounts[a.id] ?: 0
                    val idle = count == 0
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = cs.surface),
                        border = BorderStroke(
                            1.dp,
                            if (idle) ResetGreen.copy(alpha = 0.55f) else cs.outlineVariant
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(start = 14.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = a.label,
                                        modifier = Modifier.weight(1f, fill = false),
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    if (idle) {
                                        Spacer(Modifier.width(8.dp))
                                        IdleBadge()
                                    }
                                }
                                val detail = listOfNotNull(
                                    a.email.takeIf { it.isNotBlank() },
                                    if (idle) null else if (count == 1) "1 project" else "$count projects"
                                ).joinToString(" \u00B7 ")
                                if (detail.isNotEmpty()) {
                                    Text(
                                        text = detail,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = cs.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                            TextButton(onClick = { editing = a }) { Text("Edit") }
                            TextButton(onClick = { deleting = a }) {
                                Text("Delete", color = cs.error)
                            }
                        }
                    }
                }
            }
        }
    }

    if (adding) {
        AccountDialog(
            initial = null,
            onSave = { label, email ->
                onSave(null, label, email)
                adding = false
            },
            onDismiss = { adding = false }
        )
    }

    val editTarget = editing
    if (editTarget != null) {
        AccountDialog(
            initial = editTarget,
            onSave = { label, email ->
                onSave(editTarget.id, label, email)
                editing = null
            },
            onDismiss = { editing = null }
        )
    }

    val deleteTarget = deleting
    if (deleteTarget != null) {
        val count = projects.count { it.accountId == deleteTarget.id }
        ConfirmDialog(
            title = "Delete ${deleteTarget.label}?",
            message = if (count == 0) {
                "This account has no projects."
            } else {
                "Its projects stay, but they will have no account."
            },
            confirmLabel = "Delete",
            onConfirm = {
                onDelete(deleteTarget.id)
                deleting = null
            },
            onDismiss = { deleting = null }
        )
    }
}

@Composable
fun SettingsScreen(
    settings: Settings,
    onBack: () -> Unit,
    onChange: (Settings) -> Unit
) {
    val cs = MaterialTheme.colorScheme
    var hours by remember { mutableStateOf((settings.defaultDurationMillis / 3_600_000L).toString()) }
    var minutes by remember { mutableStateOf(((settings.defaultDurationMillis / 60_000L) % 60L).toString()) }
    var limit by remember { mutableStateOf(settings.historyLimit.toString()) }

    fun push(h: String, m: String, l: String) {
        val millis = durationMillisOf(h, m)
        val keep = l.toIntOrNull() ?: 0
        if (millis > 0L && keep in 1..500) {
            onChange(settings.copy(defaultDurationMillis = millis, historyLimit = keep))
        }
    }

    Scaffold { inner ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(inner)
                .verticalScroll(rememberScrollState())
        ) {
            ScreenHeader("Settings", onBack)
            Column(
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(24.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Default timer",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "New projects start with this length. You can change it per project.",
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurfaceVariant
                    )
                    DurationFields(
                        hours = hours,
                        minutes = minutes,
                        onHoursChange = {
                            hours = it
                            push(it, minutes, limit)
                        },
                        onMinutesChange = {
                            minutes = it
                            push(hours, it, limit)
                        }
                    )
                }

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Activity history",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold
                    )
                    OutlinedTextField(
                        value = limit,
                        onValueChange = { v ->
                            val digits = v.filter { c -> c.isDigit() }.take(3)
                            limit = digits
                            push(hours, minutes, digits)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Entries kept per project") },
                        supportingText = { Text("Between 1 and 500. Older entries are dropped.") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            text = "Reset alarm",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Rings at each project's reset time, like an alarm clock.",
                            style = MaterialTheme.typography.bodySmall,
                            color = cs.onSurfaceVariant
                        )
                    }
                    Spacer(Modifier.width(12.dp))
                    Switch(
                        checked = settings.notificationsEnabled,
                        onCheckedChange = { onChange(settings.copy(notificationsEnabled = it)) }
                    )
                }
            }
        }
    }
}
