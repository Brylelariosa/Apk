package com.claudemanager.app.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.TypeConverter

/**
 * What the project is doing right now. This is completely independent of the
 * countdown timer: changing the status never touches the timer fields.
 */
enum class ActivityStatus {
    READY, RUNNING, BUILDING, TESTING, WAITING, FINISHED, ERROR, CUSTOM
}

@Entity(tableName = "accounts")
data class Account(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val label: String,
    val email: String = ""
)

@Entity(tableName = "projects", indices = [Index("accountId")])
data class Project(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val name: String,
    val accountId: Long? = null,
    val defaultDurationMillis: Long,
    val timerStartTimestamp: Long? = null,
    val timerEndTimestamp: Long? = null,
    val activityStatus: ActivityStatus = ActivityStatus.READY,
    val customStatusLabel: String = "",
    val activityNote: String = "",
    val favorite: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val lastStartedAt: Long? = null,
    val lastActivityChangeAt: Long? = null
)

@Entity(tableName = "activity_events", indices = [Index("projectId")])
data class ActivityEvent(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val projectId: Long,
    val status: ActivityStatus,
    val customLabel: String = "",
    val timestamp: Long,
    val note: String = ""
)

class Converters {
    @TypeConverter
    fun statusToString(status: ActivityStatus): String = status.name

    @TypeConverter
    fun stringToStatus(value: String): ActivityStatus =
        try {
            ActivityStatus.valueOf(value)
        } catch (e: IllegalArgumentException) {
            ActivityStatus.READY
        }
}
