/* Test glue: mirrors the commands of host/host_main.c so the same scripts run on native and interpreted builds. */
#include "game.h"
#include "assets.h"
static int god;
void t_god(int a, int b, int c) { god = a; }
void t_pre(int a, int b, int c) { if (god && game_state == ST_PLAY) { pl.hp = pl.maxhp; pl.invuln = 5; } }
void t_newgame(int a, int b, int c) { begin_new_game(a); }
void t_seed(int a, int b, int c) { rnd_seed((u32)a); }
void t_warp(int a, int b, int c) { if (game_state == ST_PLAY) start_transition(a, b, c, DIR_DOWN); }
void t_xp(int a, int b, int c) { player_add_xp(a); }
void t_hp(int a, int b, int c) { pl.hp = (s16)a; }
void t_gold(int a, int b, int c) { pl.gold = (u16)a; }
void t_give(int a, int b, int c) { player_give(a, b); }
void t_flags(int a, int b, int c) { gflags |= (u32)a; }
void t_place(int a, int b, int c) { player_place(a, b, c); }
void t_state(int a, int b, int c) { game_state = a; }
void t_spawn(int a, int b, int c) { enemy_spawn(a, b, c); }
void t_craft(int a, int b, int c) { craft_open(a); game_state = ST_CRAFT; }
void t_quest(int a, int b, int c) { quest_state[a] = (u8)b; quest_prog[a] = (u8)c; quest_refresh(); }
void t_killall(int a, int b, int c) { for (int k = 0; k < MAX_EN; k++) if (en[k].active) en[k].active = 0; }
void t_bossdie(int a, int b, int c) { Enemy *e = enemy_boss(); if (e) { e->phase = 2; enemy_damage(e, 99999, 0, 1, 0, 0); } }
void t_shop(int a, int b, int c) { shop_open(); game_state = ST_SHOP; }
void t_killadds(int a, int b, int c) { for (int k = 0; k < MAX_EN; k++) if (en[k].active && en[k].type == EN_SKELETON) { en[k].hp = 0; en[k].dying = 1; en[k].t = 100; } }
void t_warddie(int a, int b, int c) { for (int k = 0; k < MAX_EN; k++) if (en[k].active && en[k].type == EN_WARDEN) { en[k].state = 7; enemy_damage(&en[k], 99999, 0, 1, 0, 0); } }
void t_pts(int a, int b, int c) { pl.stat_pts = (u8)a; }
void t_level(int a, int b, int c) { while (pl.level < a) player_add_xp(xp_for_level(pl.level)); }
void t_equip(int a, int b, int c) { player_give(a, 1); player_equip(a); }
void t_aspd(int a, int b, int c) { pl.aspd = (s16)a; }
void t_bosshp(int a, int b, int c) { Enemy *e = enemy_big(); if (e) e->hp = (s16)a; }
