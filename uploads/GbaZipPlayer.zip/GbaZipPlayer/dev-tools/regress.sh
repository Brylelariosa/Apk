#!/bin/sh
# Regression check for the C-source player core (needs gcc + python3 on a PC).
# Runs every script of an Embervale-style project (host/*.txt) twice - once as a normal native build
# and once through the interpreter in app/src/main/cpp/core - and compares video memory frame by frame.
#   usage: dev-tools/regress.sh /path/to/Embervale-project
set -e
PROJ=$1; HERE=$(cd "$(dirname "$0")" && pwd); CORE=$HERE/../app/src/main/cpp/core
[ -d "$PROJ/src" ] || { echo "usage: $0 /path/to/project (with src/ and host/)"; exit 1; }
mkdir -p /tmp/gba_nat /tmp/gba_vm
gcc -O2 -w -I"$CORE" -o /tmp/gba_vmtest "$CORE"/lex.c "$CORE"/parse.c "$CORE"/eval.c "$CORE"/hw.c "$CORE"/ppu.c "$CORE"/api.c "$HERE"/vmtest.c -lm
gcc -DHOST_BUILD -std=gnu11 -O1 -w "$PROJ"/src/*.c "$PROJ"/host/host_main.c -o /tmp/gba_native
for t in "$PROJ"/host/*.txt; do
  n=$(basename "$t" .txt); rm -f /tmp/gba_nat/${n}_* /tmp/gba_vm/${n}_*
  /tmp/gba_native "$t" /tmp/gba_nat/$n >/dev/null 2>&1 || true
  GLUE="$HERE/glue.c" /tmp/gba_vmtest "$PROJ" "$t" /tmp/gba_vm/$n | grep -E 'ERROR|FAULT|unknown' || true
  python3 "$HERE/compare_dumps.py" /tmp/gba_nat/$n /tmp/gba_vm/$n
done
