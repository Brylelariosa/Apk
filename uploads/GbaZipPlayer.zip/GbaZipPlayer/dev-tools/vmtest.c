#include "gba.h"
#include <dirent.h>
#include <time.h>
static double now_ms(void) { struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t); return t.tv_sec * 1000.0 + t.tv_nsec / 1e6; }
static char *slurp(const char *p, int *n) { FILE *f = fopen(p, "rb"); if (!f) return 0; fseek(f, 0, SEEK_END); long l = ftell(f); fseek(f, 0, SEEK_SET); char *b = malloc(l + 1); if (fread(b, 1, l, f) != (size_t)l) { fclose(f); return 0; } b[l] = 0; fclose(f); *n = (int)l; return b; }
typedef struct { int frame; char cmd[16]; int a, b, c; } Ev;
static void dump(const char *prefix, int frame) {
    char name[256]; snprintf(name, sizeof name, "%s_%05d.bin", prefix, frame);
    FILE *f = fopen(name, "wb"); if (!f) return;
    fwrite(g_io, 1, 0x400, f); fwrite(g_pal, 1, 0x400, f); fwrite(g_vram, 1, 0x18000, f); fwrite(g_oam, 1, 0x400, f); fclose(f);
}
int main(int argc, char **argv) {
    if (argc < 4) { fprintf(stderr, "usage: vmtest projdir script prefix [frames]\n"); return 1; }
    static SrcFile files[200]; int n = 0; char path[512];
    const char *sub[] = { "src" };
    for (int s = 0; s < 1; s++) {
        snprintf(path, sizeof path, "%s/%s", argv[1], sub[s]); DIR *d = opendir(path); struct dirent *e;
        while (d && (e = readdir(d))) {
            if (e->d_name[0] == '.') continue; char full[700]; snprintf(full, sizeof full, "%s/%s", path, e->d_name);
            files[n].path = malloc(300); snprintf(files[n].path, 300, "%s/%s", sub[s], e->d_name); files[n].data = slurp(full, &files[n].len); { size_t L = strlen(e->d_name); files[n].unit = L > 2 && !strcmp(e->d_name + L - 2, ".c"); } n++;
        }
        if (d) closedir(d);
    }
    files[n].path = strdup("src/zz_glue.c"); files[n].data = slurp(getenv("GLUE") ? getenv("GLUE") : "glue.c", &files[n].len); files[n].unit = 1; n++;
    char err[600]; clock_t t0 = clock();
    if (gba_load(files, n, err, sizeof err)) { printf("LOAD ERROR: %s\n", err); return 2; }
    printf("compiled in %.3f s\n", (double)(clock() - t0) / CLOCKS_PER_SEC);
    FILE *f = fopen(argv[2], "r"); static Ev evs[4096]; int nev = 0, maxframe = 0; char line[256];
    while (f && fgets(line, sizeof line, f)) { Ev e; memset(&e, 0, sizeof e); if (line[0] == '#' || line[0] == '\n') continue; int k = sscanf(line, "%d %15s %i %i %i", &e.frame, e.cmd, &e.a, &e.b, &e.c); if (k < 2) continue; evs[nev++] = e; if (e.frame > maxframe) maxframe = e.frame; }
    if (f) fclose(f);
    if (argc > 4) maxframe = atoi(argv[4]);
    if (gba_start(err, sizeof err)) { printf("START ERROR: %s\n", err); return 3; }
    double fmax = 0, ftot = 0; int keys = 0; Obj *pre = vm_func("t_pre"); t0 = clock();
    for (int fr = 0; fr <= maxframe; fr++) {
        int shot = 0;
        for (int i = 0; i < nev; i++) {
            if (evs[i].frame != fr) continue; Ev *e = &evs[i];
            if (!strcmp(e->cmd, "keys")) keys = e->a; else if (!strcmp(e->cmd, "shot")) shot = 1;
            else if (!strcmp(e->cmd, "dump") || !strcmp(e->cmd, "ehp") || !strcmp(e->cmd, "tileflags") || !strcmp(e->cmd, "savetest") || !strcmp(e->cmd, "inv") || !strcmp(e->cmd, "trace")) {}
            else { char fn[40]; snprintf(fn, sizeof fn, "t_%s", e->cmd); Obj *o = vm_func(fn); if (!o) { printf("unknown cmd %s\n", e->cmd); continue; } u32 args[3] = { (u32)e->a, (u32)e->b, (u32)e->c }; vm_call(o, 3, args); if (g_abort) { printf("FAULT in %s at frame %d: %s\n", fn, fr, gba_fault()); return 4; } }
        }
        u16 ki = (u16)(~keys & 0x3FF); memcpy(g_io + 0x130, &ki, 2);
        u32 z[3] = { 0, 0, 0 }; vm_call(pre, 3, z);
        double ft0 = now_ms(); int rc = gba_run_frame((u32)keys); double fdt = now_ms() - ft0; ftot += fdt; if (fdt > fmax) fmax = fdt;
        if (rc) { printf("FAULT at frame %d: %s\n", fr, gba_fault()); return 5; }
        if (shot) dump(argv[3], fr);
    }
    printf("ran %d frames: avg %.3f ms, worst %.3f ms per frame\n", maxframe + 1, ftot / (maxframe + 1), fmax);
    return 0;
}
