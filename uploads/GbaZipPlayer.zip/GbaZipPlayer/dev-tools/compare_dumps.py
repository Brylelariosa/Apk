import sys, glob, os
def load(p):
    d = open(p,'rb').read()
    return d[0:0x400], d[0x400:0x800], d[0x800:0x800+0x18000], d[0x800+0x18000:0x800+0x18000+0x400]
mask = set()
for base in range(0xB0, 0xE0, 4):          # DMA source addresses hold host pointers natively
    mask.update(range(base, base+4))
mask.update(range(0x130, 0x132)); mask.update(range(0x04, 0x08)); mask.update(range(0xBC+4, 0xBC+8))
tot = 0; bad = 0; detail = []
for nat in sorted(glob.glob(sys.argv[1] + '_*.bin')):
    vm = sys.argv[2] + nat[len(sys.argv[1]):]
    if not os.path.exists(vm): detail.append(('missing', nat)); bad += 1; continue
    a = load(nat); b = load(vm); tot += 1
    diffs = []
    for si, name in enumerate(('io','pal','vram','oam')):
        x, y = a[si], b[si]
        if x == y: continue
        idx = [i for i in range(len(x)) if x[i] != y[i] and not (si == 0 and i in mask)]
        if idx: diffs.append((name, len(idx), idx[:6]))
    if diffs: bad += 1; detail.append((os.path.basename(nat), diffs))
print(f"{os.path.basename(sys.argv[1])}: compared {tot} shots, {bad} differ")
for d in detail[:3]: print("   ", d)
