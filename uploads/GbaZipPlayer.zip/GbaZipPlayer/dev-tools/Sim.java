// Virtual-time simulation of the emulation loop (Pacer) against an audio device with clock drift, a finite buffer and
// a position counter that only updates every audio period. To run it, put Pacer.java (from the app) and this file in
// a folder com/embervale/zipplayer, compile both with javac and run com.embervale.zipplayer.Sim.
package com.embervale.zipplayer;

import java.util.Random;

/** Virtual-time simulation of the emulation loop against an audio device (drift, quantised head position, finite buffer). */
public final class Sim {
    static final long MS = 1000000L;
    static final double FRAME_S = Pacer.FRAME_NS / 1e9;

    static final class Cfg {
        String name; boolean newLogic = true; boolean useAudioQueue = true;
        double computeMs = 3, computeJitterMs = 1, drawMs = 1.5, spikeMs = 0, spikeEverySec = 0;
        double driftPpm = 0; int periodFrames = 960; int rate = 48000; int capacityFrames = 6000; int seconds = 600;
        boolean drawCostMatters = true;
    }

    static final class Res {
        int underruns; double underrunMs; double speed; double skippedPct; double presentStdMs; double minQueuedMs, avgQueuedMs; double avgSkewMs;
    }

    static Res run(Cfg c, long seed) {
        Random rnd = new Random(seed);
        double devRate = c.rate * (1 + c.driftPpm * 1e-6);       // frames consumed per wall second
        long now = 0;
        double queued = 0, consumed = 0; long written = 0; long devTime = 0; boolean starving = false;
        Res r = new Res();
        Pacer pacer = new Pacer(0);
        // old logic state
        long t0 = 0, framesOld = 0;
        long end = (long) c.seconds * 1000 * MS;
        long frames = 0, draws = 0, skipped = 0; long lastPresent = -1; double sumI = 0, sumI2 = 0; long nI = 0;
        double sumQ = 0; long nQ = 0; r.minQueuedMs = 1e9; double sumSkew = 0; long nSkew = 0;
        double qEst0 = 0; double acc = 0; long nextSpike = (long) (c.spikeEverySec * 1000 * MS);
        while (now < end) {
            // ---- emulate one frame
            double cm = c.computeMs + (rnd.nextDouble() * 2 - 1) * c.computeJitterMs;
            if (c.spikeEverySec > 0 && now >= nextSpike) { cm += c.spikeMs; nextSpike = now + (long) (c.spikeEverySec * 1000 * MS); }
            now += (long) (Math.max(0.2, cm) * MS);
            boolean draw;
            { double can0 = (now - devTime) / 1e9 * devRate; double take0 = Math.min(can0, queued); double cons0 = consumed + take0;
              double headQ0 = Math.floor(cons0 / c.periodFrames) * c.periodFrames; qEst0 = (written - headQ0) / (double) c.rate * 1e9; }
            if (c.newLogic) draw = pacer.shouldDraw(now, c.useAudioQueue ? (long) qEst0 : -1); else draw = true;
            
            if (draw) {
                now += (long) ((c.drawMs * (0.9 + 0.2 * rnd.nextDouble())) * MS); draws++;
                if (lastPresent >= 0) { double iv = (now - lastPresent) / 1e6; sumI += iv; sumI2 += iv * iv; nI++; }
                lastPresent = now;
            } else skipped++;
            // ---- audio device advances to 'now'
            { double can = (now - devTime) / 1e9 * devRate; double take = Math.min(can, queued);
              if (can > queued + 1e-9) { if (!starving) { r.underruns++; starving = true; } r.underrunMs += (can - queued) / devRate * 1000; }
              consumed += take; queued -= take; devTime = now; }
            // ---- write one frame of audio (blocking when the track is full)
            acc += c.rate * FRAME_S; int n = (int) acc; acc -= n;
            if (queued + n > c.capacityFrames) {
                double need = queued + n - c.capacityFrames; long dt = (long) (need / devRate * 1e9);
                now += dt; consumed += need; queued -= need; devTime = now;
            }
            queued += n; written += n; if (queued > 0) starving = false;
            frames++;
            double headQ = Math.floor(consumed / c.periodFrames) * c.periodFrames;
            double queuedEstNs = (written - headQ) / (double) c.rate * 1e9;
            sumQ += queued / c.rate * 1000; nQ++; r.minQueuedMs = Math.min(r.minQueuedMs, queued / c.rate * 1000);
            // ---- pacing
            long sleep;
            if (c.newLogic) {
                sleep = pacer.afterFrame(now, c.useAudioQueue ? (long) queuedEstNs : -1);
            } else {   // the original logic
                framesOld++;
                long ahead = framesOld * Pacer.FRAME_NS - (now - t0);
                sleep = 0;
                if (ahead > 40 * MS) sleep = ahead - 20 * MS;
                else if (ahead < -250 * MS) { t0 = now; framesOld = 0; }
            }
            if (sleep > 0) now += sleep + (long) ((0.1 + rnd.nextDouble() * 0.9) * MS);
            // average skew = wall-clock lead of emulated time
            sumSkew += (frames * Pacer.FRAME_NS - now) / 1e6; nSkew++;
        }
        r.speed = frames * FRAME_S / (now / 1e9);
        r.skippedPct = 100.0 * skipped / frames;
        double mean = sumI / Math.max(1, nI); r.presentStdMs = Math.sqrt(Math.max(0, sumI2 / Math.max(1, nI) - mean * mean));
        r.avgQueuedMs = sumQ / nQ; r.avgSkewMs = sumSkew / nSkew;
        return r;
    }

    static void show(Cfg c) {
        Res r = run(c, 12345);
        System.out.printf("%-44s %s | speed %5.1f%% | underruns %4d (%6.0f ms) | skipped draws %5.1f%% | present jitter %4.1f ms | queued min %5.1f avg %5.1f ms%n",
                c.name, c.newLogic ? "NEW" : "OLD", 100 * r.speed, r.underruns, r.underrunMs, r.skippedPct, r.presentStdMs, r.minQueuedMs, r.avgQueuedMs);
    }

    static Cfg cfg(String name, boolean nl, double compute, double draw, double drift, int period, double spike, double every) {
        Cfg c = new Cfg(); c.name = name; c.newLogic = nl; c.computeMs = compute; c.drawMs = draw; c.driftPpm = drift; c.periodFrames = period; c.spikeMs = spike; c.spikeEverySec = every; return c;
    }

    public static void main(String[] a) {
        for (boolean nl : new boolean[]{false, true}) {
            show(cfg("fast phone, 4 ms audio periods", nl, 3, 1.5, 0, 192, 0, 0));
            show(cfg("fast phone, 20 ms audio periods", nl, 3, 1.5, 0, 960, 0, 0));
            show(cfg("fast phone, audio clock +50 ppm fast", nl, 3, 1.5, 50, 960, 0, 0));
            show(cfg("fast phone, audio clock +200 ppm fast", nl, 3, 1.5, 200, 960, 0, 0));
            show(cfg("fast phone, audio clock +200 ppm, 4 ms periods", nl, 3, 1.5, 200, 192, 0, 0));
            show(cfg("fast phone, audio clock 50 ppm slow", nl, 3, 1.5, -50, 960, 0, 0));
            show(cfg("fast phone, audio clock 200 ppm slow", nl, 3, 1.5, -200, 960, 0, 0));
            show(cfg("fast phone, 35 ms lag spike every 3 s", nl, 3, 1.5, 0, 960, 35, 3));
            show(cfg("borderline phone (9 ms emu + 9 ms draw)", nl, 9, 9, 0, 960, 0, 0));
            show(cfg("slow phone (14 ms emu + 6 ms draw)", nl, 14, 6, 0, 960, 0, 0));
            show(cfg("too slow even without drawing (19 ms emu)", nl, 19, 6, 0, 960, 0, 0));
            System.out.println();
        }
    }
}
