/* Native bench for the GBA C-source player core: runs a project through the interpreter on a PC, reports the time
 * the game logic, the renderer and the mixer take per frame, and writes the game's sound to a WAV file.
 *
 *   cd dev-tools
 *   C=../app/src/main/cpp/core
 *   gcc -O2 -w -I$C -o bench $C/lex.c $C/parse.c $C/eval.c $C/hw.c $C/ppu.c $C/api.c bench.c -lm
 *   ./bench /path/to/project /path/to/project/host/t25_map_menu.txt glue.c out.wav 48000 [frames]
 *
 * The script format is the one of the project's host scripts (host/t*.txt) ("<frame> <command> [args]", see glue.c). */
#include "gba.h"
#include <dirent.h>
#include <time.h>

static double now_ms(void) { struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t); return t.tv_sec * 1000.0 + t.tv_nsec / 1e6; }
static char *slurp(const char *p, int *n) {
    FILE *f = fopen(p, "rb"); if (!f) return 0;
    fseek(f, 0, SEEK_END); long l = ftell(f); fseek(f, 0, SEEK_SET);
    char *b = malloc(l + 1); if (fread(b, 1, l, f) != (size_t)l) { fclose(f); return 0; }
    b[l] = 0; fclose(f); *n = (int)l; return b;
}
typedef struct { int frame; char cmd[16]; int a, b, c; } Ev;

static void wav_header(FILE *f, int rate, int nframes) {
    u32 data = (u32)nframes * 4, riff = 36 + data, fmt = 16, br = (u32)rate * 4, sr = (u32)rate;
    u16 pcm = 1, ch = 2, ba = 4, bits = 16;
    fseek(f, 0, SEEK_SET);
    fwrite("RIFF", 1, 4, f); fwrite(&riff, 4, 1, f); fwrite("WAVEfmt ", 1, 8, f); fwrite(&fmt, 4, 1, f);
    fwrite(&pcm, 2, 1, f); fwrite(&ch, 2, 1, f); fwrite(&sr, 4, 1, f); fwrite(&br, 4, 1, f); fwrite(&ba, 2, 1, f); fwrite(&bits, 2, 1, f);
    fwrite("data", 1, 4, f); fwrite(&data, 4, 1, f);
}

int main(int argc, char **argv) {
    if (argc < 6) { fprintf(stderr, "usage: bench projdir script glue.c out.wav rate [frames]\n"); return 1; }
    static SrcFile files[200]; int n = 0; char path[512];
    snprintf(path, sizeof path, "%s/src", argv[1]); DIR *d = opendir(path); struct dirent *e;
    while (d && (e = readdir(d))) {
        if (e->d_name[0] == '.') continue;
        char full[700]; snprintf(full, sizeof full, "%s/%s", path, e->d_name);
        files[n].path = malloc(300); snprintf(files[n].path, 300, "src/%s", e->d_name);
        files[n].data = slurp(full, &files[n].len);
        { size_t L = strlen(e->d_name); files[n].unit = L > 2 && !strcmp(e->d_name + L - 2, ".c"); }
        n++;
    }
    if (d) closedir(d);
    files[n].path = strdup("src/zz_glue.c"); files[n].data = slurp(argv[3], &files[n].len); files[n].unit = 1; n++;
    char err[600]; double t0 = now_ms();
    if (gba_load(files, n, err, sizeof err)) { printf("LOAD ERROR: %s\n", err); return 2; }
    printf("compiled in %.1f ms\n", now_ms() - t0);

    int rate = atoi(argv[5]); apu_set_rate(rate);
    FILE *f = fopen(argv[2], "r"); static Ev evs[8192]; int nev = 0, maxframe = 0; char line[256];
    while (f && fgets(line, sizeof line, f)) {
        Ev ev; memset(&ev, 0, sizeof ev); if (line[0] == '#' || line[0] == '\n') continue;
        int k = sscanf(line, "%d %15s %i %i %i", &ev.frame, ev.cmd, &ev.a, &ev.b, &ev.c); if (k < 2) continue;
        evs[nev++] = ev; if (ev.frame > maxframe) maxframe = ev.frame;
    }
    if (f) fclose(f);
    if (argc > 6) maxframe = atoi(argv[6]);
    if (gba_start(err, sizeof err)) { printf("START ERROR: %s\n", err); return 3; }

    FILE *wav = fopen(argv[4], "wb"); wav_header(wav, rate, 0);
    static s16 abuf[8192 * 2]; long total = 0;
    double tv = 0, tp = 0, ta = 0, vmax = 0; int keys = 0;
    static double vt[20000];
    for (int fr = 0; fr <= maxframe; fr++) {
        for (int i = 0; i < nev; i++) {
            if (evs[i].frame != fr) continue; Ev *ev = &evs[i];
            if (!strcmp(ev->cmd, "keys")) keys = ev->a;
            else if (!strcmp(ev->cmd, "shot") || !strcmp(ev->cmd, "dump") || !strcmp(ev->cmd, "ehp") || !strcmp(ev->cmd, "tileflags") ||
                     !strcmp(ev->cmd, "savetest") || !strcmp(ev->cmd, "inv") || !strcmp(ev->cmd, "trace")) {}
            else {
                char fn[40]; snprintf(fn, sizeof fn, "t_%s", ev->cmd); Obj *o = vm_func(fn);
                if (!o) { printf("unknown cmd %s\n", ev->cmd); continue; }
                u32 args[3] = { (u32)ev->a, (u32)ev->b, (u32)ev->c }; vm_call(o, 3, args);
            }
        }
        Obj *pre = vm_func("t_pre"); u32 z[3] = { 0, 0, 0 }; if (pre) vm_call(pre, 3, z);
        double a = now_ms(); int rc = gba_run_frame((u32)keys); double b = now_ms();
        static u32 px[240 * 160]; ppu_render(px); double c = now_ms();
        int ns = gba_audio(abuf, 8192);
        double dd = now_ms();
        if (rc) { printf("FAULT at frame %d: %s\n", fr, gba_fault()); return 5; }
        if (ns > 0) { fwrite(abuf, 4, ns, wav); total += ns; }
        tv += b - a; tp += c - b; ta += dd - c; if (b - a > vmax) vmax = b - a; if (fr < 20000) vt[fr] = b - a;
    }
    wav_header(wav, rate, (int)total); fclose(wav);
    int nf = maxframe + 1;
    printf("frames %d | interp %.3f ms/frame (worst %.2f) | ppu %.3f ms | audio %.3f ms | total %.3f ms (budget 16.74)\n",
           nf, tv / nf, vmax, tp / nf, ta / nf, (tv + tp + ta) / nf);
    /* per-second interp average to see which game moments are heavy */
    for (int s = 0; s * 60 < nf && s < 120; s += 5) { double sum = 0; int c = 0; for (int i = s * 60; i < (s + 5) * 60 && i < nf; i++) { sum += vt[i]; c++; } if (c) printf("  t=%3ds..%3ds interp avg %.3f ms\n", s, s + 5, sum / c); }
    return 0;
}
