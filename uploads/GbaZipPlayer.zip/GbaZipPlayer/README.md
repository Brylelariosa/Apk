# GBA ZIP Player

Play a Game Boy Advance game **straight from a ZIP of its C source code** - no ROM build, no devkitARM,
no GitHub Actions run for the game. Tap **Choose ZIP file**, pick e.g. `Embervale-GBA-3-2.zip`, and the
game starts about a second later.

## How it works

1. `ZipLoader` reads the `.c` / `.h` files and the `Makefile` out of the ZIP (nothing is extracted to disk).
2. The native core (`app/src/main/cpp/core`) compiles the project **on the phone**:
   * `lex.c` - tokenizer + C preprocessor (macros, `#if`, includes, virtual `<stdint.h>` etc.)
   * `parse.c` - C front end (types, structs/enums, designated initializers, switch, ...) producing a typed AST;
     the translation units are the `.c` files in the Makefile's `SOURCES` folder (default `src`).
   * `eval.c` - fast tree-walking interpreter + a GBA memory map (EWRAM/IWRAM/IO/PAL/VRAM/OAM/ROM/SRAM) and linker.
   * `hw.c` - IO registers, DMA, direct-sound FIFOs, PSG channels 1-4 and the audio mixer (the tone channels are
     generated 4x oversampled and low-pass filtered, so they do not alias into harsh noise).
   * `ppu.c` - scanline renderer: text/affine/bitmap backgrounds, sprites (regular + affine), alpha/brightness
     blending and mosaic. Works tile row by tile row and skips blending where it cannot matter (about 4x faster
     than a pixel-by-pixel renderer, with identical output).
   * `api.c` - project loading / boot / one-frame stepping used by `jni.c`.
3. The game is driven the way the original ROM `main()` does it: `game_init()` once, then `game_frame()` per frame
   (59.73 fps). The picture and sound come from the emulated hardware registers the game writes.

The Java side (`PlayActivity`, `GameView`) adds touch controls, keyboard/gamepad input, audio output, the pause menu
and automatic saving (battery save RAM is stored per game in the app's private storage; every version of the same
game - `Embervale-GBA-3-2.zip`, `Embervale-GBA-3-3.zip`, ... - shares one save slot).

## Speed and sound

The emulation thread has one job per frame: run the game, draw the picture, queue the sound. If a phone cannot do
all of that in 16.7 ms the game plays in slow motion and the sound breaks up. What keeps that from happening:

* `Pacer` paces the game by the wall clock (one short sleep per frame, so the picture moves evenly) and keeps about
  45 ms of sound queued in the audio track. The sleep is cut short whenever the queue runs low and extended if it
  grows too long, which also absorbs small differences between the audio clock and the system clock.
* When the game falls behind real time, the **picture of that frame is skipped** (rendering + drawing are the
  expensive part); emulation and sound always run, so speed and sound stay right and only the picture gets less
  smooth. At least every fifth frame is drawn.
* On Android 8+ the frame and the on-screen controls are drawn with a GPU canvas (`lockHardwareCanvas`); older
  versions use the software canvas. Frames rotate through three bitmaps because the GPU reads a bitmap after the draw
  call returns.
* The emulation thread runs at display priority.
* Sample effects are streamed to the sound FIFO by DMA from the array that holds them. A game stops that DMA a
  frame or two after the sample ends, so the old mixer kept playing whatever array came next in memory (the start
  of an unrelated sound effect after most effects). The FIFO now reads silence once the array it started in is used up.

## Requirements for a game ZIP

* C source for the GBA with direct hardware access (like the Embervale project). A top-level folder inside the ZIP is fine.
* `game_init()` and `game_frame()` entry points (`game_frame()` does one full frame including `vsync()`).
* Supported C: C99 without floating point, `long long`, bit-fields, `goto` and compound literals; function pointers,
  unions, designated initializers, static locals and `switch` are fine. libc functions available: `memcpy`, `memmove`,
  `memset`, `memcmp`, `strlen`, `strcmp`, `strcpy`, `abs`.
* Ready-made `.gba` ROM files are **not** supported (there is no ARM CPU emulator in this app).

If compilation fails, the error (file, line, reason) is shown on screen.

## Build

Push this project as a ZIP into the `uploads/` folder of your repository; the *Build APK* workflow produces the APK
(`./gradlew assembleDebug`, NDK 25.2.9519653, CMake 3.22.1, AGP 8.2.2, Gradle 8.6, minSdk 24).

## Controls

On-screen D-pad, A, B, L, R, START, SELECT; **MENU** button or the Back key opens the pause menu (resume, restart,
sound, scaling, delete save, choose another ZIP). Keyboard: arrows, X = A, Z = B, Enter = START, Backspace = SELECT,
Q / E = L / R. Gamepads work too.

## Developer tools

`dev-tools/bench.c` runs a project through the interpreter on a PC and reports how long the game logic, the renderer
and the mixer take per frame (compile line in the file); it can also write the game's sound to a WAV file.
`dev-tools/Sim.java` is a virtual-time simulation of the frame loop against an audio device (clock drift, slow
frames, lag spikes) that was used to tune `Pacer`.

`dev-tools/regress.sh <project>` builds the Embervale project natively and through this interpreter, runs all of its
`host/*.txt` test scripts on both and compares IO/palette/VRAM/OAM byte for byte (all 30+ scripts and 16 random-input
fuzz runs matched when this was written).
