# GBA ZIP Player

Play a Game Boy Advance game **straight from a ZIP of its C source code** - no ROM build, no devkitARM,
no GitHub Actions run for the game. Tap **Choose ZIP file**, pick e.g. `Embervale-GBA-3-2.zip`, and the
game starts about a second later.

## How it works

1. `ZipLoader` reads the `.c` / `.h` files and the `Makefile` out of the ZIP (nothing is extracted to disk).
2. The native core (`app/src/main/cpp/core`) compiles the project **on the phone**:
   * `lex.c` - tokenizer + C preprocessor (macros, `#if`, includes, virtual `<stdint.h>` etc.)
   * `parse.c` - C front end (types, structs/enums, designated initializers, switch, ...) producing a typed AST;
     the translation units are the `.c` files in the Makefile's `SOURCES` folder (default `src`).
   * `eval.c` - fast tree-walking interpreter + a GBA memory map (EWRAM/IWRAM/IO/PAL/VRAM/OAM/ROM/SRAM) and linker.
   * `hw.c` - IO registers, DMA, direct-sound FIFOs, PSG channels 1-4 and the audio mixer.
   * `ppu.c` - scanline renderer: text/affine/bitmap backgrounds, sprites (regular + affine), alpha/brightness
     blending and mosaic.
   * `api.c` - project loading / boot / one-frame stepping used by `jni.c`.
3. The game is driven the way the original ROM `main()` does it: `game_init()` once, then `game_frame()` per frame
   (59.73 fps). The picture and sound come from the emulated hardware registers the game writes.

The Java side (`PlayActivity`, `GameView`) adds touch controls, keyboard/gamepad input, audio output, the pause menu
and automatic saving (battery save RAM is stored per game in the app's private storage; every version of the same
game - `Embervale-GBA-3-2.zip`, `Embervale-GBA-3-3.zip`, ... - shares one save slot).

## Requirements for a game ZIP

* C source for the GBA with direct hardware access (like the Embervale project). A top-level folder inside the ZIP is fine.
* `game_init()` and `game_frame()` entry points (`game_frame()` does one full frame including `vsync()`).
* Supported C: C99 without floating point, `long long`, bit-fields, `goto` and compound literals; function pointers,
  unions, designated initializers, static locals and `switch` are fine. libc functions available: `memcpy`, `memmove`,
  `memset`, `memcmp`, `strlen`, `strcmp`, `strcpy`, `abs`.
* Ready-made `.gba` ROM files are **not** supported (there is no ARM CPU emulator in this app).

If compilation fails, the error (file, line, reason) is shown on screen.

## Build

Push this project as a ZIP into the `uploads/` folder of your repository; the *Build APK* workflow produces the APK
(`./gradlew assembleDebug`, NDK 25.2.9519653, CMake 3.22.1, AGP 8.2.2, Gradle 8.6, minSdk 24).

## Controls

On-screen D-pad, A, B, L, R, START, SELECT; **MENU** button or the Back key opens the pause menu (resume, restart,
sound, scaling, delete save, choose another ZIP). Keyboard: arrows, X = A, Z = B, Enter = START, Backspace = SELECT,
Q / E = L / R. Gamepads work too.

## Developer tools

`dev-tools/regress.sh <project>` builds the Embervale project natively and through this interpreter, runs all of its
`host/*.txt` test scripts on both and compares IO/palette/VRAM/OAM byte for byte (all 30+ scripts and 16 random-input
fuzz runs matched when this was written).
