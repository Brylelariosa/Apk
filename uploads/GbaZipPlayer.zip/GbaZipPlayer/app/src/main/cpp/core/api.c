/* Public player API: project loading (source file selection), boot, frame stepping. */
#include "gba.h"
#include <setjmp.h>
#include <ctype.h>
extern jmp_buf cc_jmp;

static Obj *fn_init, *fn_frame; static int loaded;

static int ends_with(const char *s, const char *suf) { size_t a = strlen(s), b = strlen(suf); return a >= b && !strcmp(s + a - b, suf); }
static const char *base_name(const char *p) { const char *s = strrchr(p, '/'); return s ? s + 1 : p; }
static int is_makefile(const char *p) { const char *b = base_name(p); return !strcmp(b, "Makefile") || !strcmp(b, "makefile") || !strcmp(b, "GNUmakefile"); }

void gba_unload(void) {
    free(g_funcs); g_funcs = NULL; g_nfuncs = 0; cc_reset(); arena_free_all();
    free(g_rom); g_rom = NULL; g_rom_size = 0; g_files = NULL; g_nfiles = 0; fn_init = fn_frame = NULL; loaded = 0;
}

/* Collect the SOURCES directories named in the top-level Makefile (devkitPro style). */
static int makefile_sources(SrcFile *fs, int m, char dirs[8][160]) {
    int nd = 0;
    for (int i = 0; i < m; i++) {
        if (!is_makefile(fs[i].path) || strchr(fs[i].path, '/')) continue;
        const char *p = fs[i].data;
        while (*p) {
            const char *e = strchr(p, '\n'); if (!e) e = p + strlen(p);
            const char *q = p; while (q < e && (*q == ' ' || *q == '\t')) q++;
            if (e - q > 7 && !strncmp(q, "SOURCES", 7) && (q[7] == ' ' || q[7] == '\t' || q[7] == ':' || q[7] == '=' || q[7] == '?')) {
                const char *eqp = memchr(q, '=', e - q);
                if (eqp) {
                    const char *t = eqp + 1;
                    while (t < e && nd < 8) {
                        while (t < e && (*t == ' ' || *t == '\t' || *t == '\\')) t++;
                        const char *s = t; while (t < e && *t != ' ' && *t != '\t' && *t != '#' && *t != '\r') t++;
                        if (t > s && !(t - s >= 2 && s[0] == '$' && s[1] == '(') && !(t - s == 1 && *s == '.')) {
                            int l = (int)(t - s); if (l > 150) l = 150; memcpy(dirs[nd], s, l); dirs[nd][l] = 0;
                            while (l > 0 && dirs[nd][l - 1] == '/') dirs[nd][--l] = 0; nd++;
                        }
                        if (t < e && *t == '#') break;
                    }
                    if (nd) return nd;
                }
            }
            p = *e ? e + 1 : e;
        }
    }
    return nd;
}
static int in_junk_dir(const char *path) {
    static const char *junk[] = { "host/", "tools/", "test/", "tests/", "build/", "docs/", ".github/", "scripts/", NULL };
    for (int i = 0; junk[i]; i++) if (!strncmp(path, junk[i], strlen(junk[i]))) return 1;
    return 0;
}

int gba_load(SrcFile *in, int n, char *err, int errlen) {
    gba_unload();
    if (setjmp(cc_jmp)) { snprintf(err, errlen, "%s", g_err); return -1; }
    SrcFile *fs = xalloc(sizeof(SrcFile) * (n + 2)); int m = 0;
    for (int i = 0; i < n; i++) {
        const char *p = in[i].path; while (*p == '/' || (p[0] == '.' && p[1] == '/')) p += (*p == '/') ? 1 : 2;
        if (strstr(p, "__MACOSX") || !strncmp(base_name(p), "._", 2)) continue;
        if (!(ends_with(p, ".c") || ends_with(p, ".h") || is_makefile(p))) continue;
        fs[m].path = xstrndup(p, (int)strlen(p)); for (char *c = fs[m].path; *c; c++) if (*c == '\\') *c = '/';
        fs[m].data = xstrndup(in[i].data, in[i].len); fs[m].len = in[i].len; fs[m].unit = in[i].unit; m++;
    }
    if (!m) { snprintf(err, errlen, "no C source files were found in the ZIP"); return -1; }
    /* drop a single common top-level folder (GitHub-style zips) */
    { const char *first = fs[0].path; const char *sl = strchr(first, '/'); int ok = sl != NULL; size_t fl = sl ? (size_t)(sl - first) : 0;
      for (int i = 0; i < m && ok; i++) { const char *s2 = strchr(fs[i].path, '/'); if (!s2 || (size_t)(s2 - fs[i].path) != fl || strncmp(fs[i].path, first, fl)) ok = 0; }
      if (ok) for (int i = 0; i < m; i++) fs[i].path += fl + 1; }
    int forced = 0; for (int i = 0; i < m; i++) if (fs[i].unit) forced = 1;
    if (!forced) {
        char dirs[8][160]; int nd = makefile_sources(fs, m, dirs); int any = 0;
        if (!nd) { strcpy(dirs[0], "src"); nd = 1; }
        for (int i = 0; i < m; i++) {
            if (!ends_with(fs[i].path, ".c")) continue;
            char d[300]; const char *s = strrchr(fs[i].path, '/'); if (s) { memcpy(d, fs[i].path, s - fs[i].path); d[s - fs[i].path] = 0; } else d[0] = 0;
            for (int k = 0; k < nd; k++) if (!strcmp(d, dirs[k])) { fs[i].unit = 1; any = 1; }
        }
        if (!any) for (int i = 0; i < m; i++) if (ends_with(fs[i].path, ".c") && !in_junk_dir(fs[i].path)) { fs[i].unit = 1; any = 1; }
        if (!any) { snprintf(err, errlen, "no C source files to compile"); return -1; }
    }
    if (cc_compile(fs, m, err, errlen)) return -1;
    fn_init = vm_func("game_init"); fn_frame = vm_func("game_frame");
    if (!fn_frame || !fn_frame->body) { snprintf(err, errlen, "This project has no game_frame() function. Only projects that expose game_init()/game_frame() can be played from source."); return -1; }
    if (vm_link(err, errlen)) return -1;
    loaded = 1; return 0;
}
int gba_start(char *err, int errlen) {
    if (!loaded) { snprintf(err, errlen, "no game loaded"); return -1; }
    vm_boot(); g_abort = 0;
    if (fn_init && fn_init->body) vm_call(fn_init, 0, NULL);
    if (g_abort) { snprintf(err, errlen, "%s", gba_fault()); return -1; }
    return 0;
}
int gba_run_frame(u32 keys) {
    if (!loaded) return 1;
    g_keys = keys & 0x3FF; g_abort = 0; vm_call(fn_frame, 0, NULL);
    return g_abort;
}

int gba_audio(s16 *out, int cap) {
    static double acc;
    acc += apu_rate() * 280896.0 / 16777216.0;
    int ns = (int)acc; acc -= ns;
    if (ns > cap) ns = cap;
    if (ns > 0) apu_frame(out, ns);
    return ns;
}
void gba_set_sram(const u8 *d, int n) { memset(g_sram, 0, sizeof g_sram); if (n > (int)sizeof g_sram) n = (int)sizeof g_sram; if (d && n > 0) memcpy(g_sram, d, n); }
const u8 *gba_get_sram(void) { return g_sram; }
