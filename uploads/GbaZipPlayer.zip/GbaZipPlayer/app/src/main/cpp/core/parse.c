/* C parser: declarations, types, expressions, statements, initializers, linking. */
#include "gba.h"
#include <setjmp.h>
#include <ctype.h>
extern jmp_buf cc_jmp;
#define err(...) cc_error(tk->file, tk->line, __VA_ARGS__)

Obj *g_objs; static Obj *g_tail; Obj **g_funcs; int g_nfuncs;
#define GH 2048
static Obj *gtab[GH];
static Token *tk;
static Obj *cur_fn; static int cur_stack; static Node *cur_switch; static int uniq;

static unsigned hash_n(const char *s, int n) { unsigned h = 5381; while (n--) h = h * 33 + (u8)*s++; return h; }
static int eq(const char *s) { return tok_is(tk, s); }
static int consume(const char *s) { if (tok_is(tk, s)) { tk = tk->next; return 1; } return 0; }
static void skip(const char *s) { if (!consume(s)) err("expected '%s'", s); }
static void skip_attrs(void) {
    while (eq("__attribute__") || eq("__extension__") || eq("__asm__")) {
        int ext = eq("__extension__"); tk = tk->next; if (ext) continue;
        int d = 0;
        if (!eq("(")) err("bad attribute");
        do { if (eq("(")) d++; else if (eq(")")) d--; if (tk->kind == TK_EOF) err("unexpected end of file"); tk = tk->next; } while (d > 0);
    }
}

/* ---------- scopes ---------- */
typedef struct Sym Sym; typedef struct Scope Scope;
enum { S_VAR, S_TYPEDEF, S_ENUM };
struct Scope { Scope *up; Sym *syms; };
struct Sym { Sym *hnext, *snext; const char *name; int len, ns, kind; Obj *var; Type *ty; s32 val; Scope *sc; };
#define SH 4096
static Sym *stab[SH]; static Scope *scope;
static Sym *lookup_n(const char *s, int len, int ns) {
    for (Sym *y = stab[hash_n(s, len) % SH]; y; y = y->hnext) if (y->ns == ns && y->len == len && !memcmp(y->name, s, len)) return y;
    return NULL;
}
static Sym *lookup(Token *t, int ns) { return lookup_n(t->str, t->len, ns); }
static Sym *declare(const char *name, int len, int ns, int kind) {
    Sym *y = xalloc(sizeof(Sym)); y->name = name; y->len = len; y->ns = ns; y->kind = kind; y->sc = scope;
    unsigned h = hash_n(name, len) % SH; y->hnext = stab[h]; stab[h] = y; y->snext = scope->syms; scope->syms = y; return y;
}
static void enter_scope(void) { Scope *s = xalloc(sizeof(Scope)); s->up = scope; scope = s; }
static void leave_scope(void) {
    for (Sym *y = scope->syms; y; y = y->snext) stab[hash_n(y->name, y->len) % SH] = y->hnext;
    scope = scope->up;
}

/* ---------- types ---------- */
static Type *ty_void, *ty_bool, *ty_char, *ty_schar, *ty_uchar, *ty_short, *ty_ushort, *ty_int, *ty_uint;
static Type *mkty(TyKind k, int size, int uns) { Type *t = xalloc(sizeof(Type)); t->kind = k; t->size = size; t->align = size ? size : 1; t->uns = uns; return t; }
static void types_init(void) {
    ty_void = mkty(TY_VOID, 1, 0); ty_bool = mkty(TY_BOOL, 1, 1); ty_char = mkty(TY_CHAR, 1, 1); ty_schar = mkty(TY_CHAR, 1, 0);
    ty_uchar = mkty(TY_CHAR, 1, 1); ty_short = mkty(TY_SHORT, 2, 0); ty_ushort = mkty(TY_SHORT, 2, 1); ty_int = mkty(TY_INT, 4, 0); ty_uint = mkty(TY_INT, 4, 1);
}
static Type *copy_type(Type *t) { Type *n = xalloc(sizeof(Type)); *n = *t; return n; }
static Type *qual_const(Type *t) { if (t->is_const) return t; Type *n = copy_type(t); n->is_const = 1; return n; }
static Type *pointer_to(Type *b) { Type *t = mkty(TY_PTR, 4, 1); t->base = b; return t; }
static Type *array_of(Type *b, int len) { Type *t = mkty(TY_ARRAY, len < 0 ? 0 : b->size * len, 0); t->align = b->align; t->base = b; t->len = len; return t; }
static int is_int(Type *t) { return t->kind == TY_BOOL || t->kind == TY_CHAR || t->kind == TY_SHORT || t->kind == TY_INT || t->kind == TY_ENUM; }
static int is_ptr(Type *t) { return t->kind == TY_PTR || t->kind == TY_ARRAY; }
static int is_agg(Type *t) { return t->kind == TY_STRUCT || t->kind == TY_UNION; }
static int is_const_obj(Type *t) { while (t->kind == TY_ARRAY) t = t->base; return t->is_const; }
static int align_up(int n, int a) { return a <= 1 ? n : (n + a - 1) / a * a; }
static int lmode(Type *t) {
    switch (t->kind) {
    case TY_ARRAY: case TY_STRUCT: case TY_UNION: case TY_FUNC: case TY_VOID: return LM_AGG;
    case TY_BOOL: return LM_BOOL;
    default: break;
    }
    if (t->size == 1) return t->uns ? LM_U8 : LM_S8;
    if (t->size == 2) return t->uns ? LM_U16 : LM_S16;
    return LM_32;
}

/* ---------- nodes ---------- */
static Node *mk(NodeKind k) { Node *n = xalloc(sizeof(Node)); n->kind = k; n->tok = tk; return n; }
static Node *num(s32 v, Type *ty) { Node *n = mk(ND_NUM); n->val = v; n->ty = ty; return n; }
static Node *un(NodeKind k, Node *l, Type *ty) { Node *n = mk(k); n->lhs = l; n->ty = ty; return n; }
static Node *var_node(Obj *v) { Node *n = mk(v->is_local ? ND_LVAR : ND_GVAR); n->var = v; n->ty = v->ty; n->lm = lmode(v->ty); return n; }
static Type *base_of(Type *t) { return t->base; }
static Node *deref_node(Node *p) {
    if (!is_ptr(p->ty) && p->ty->kind != TY_FUNC) err("dereferencing a non-pointer");
    Type *b = p->ty->kind == TY_FUNC ? p->ty : base_of(p->ty);
    if (b->kind == TY_VOID) err("dereferencing a void pointer");
    Node *n = un(ND_DEREF, p, b); n->lm = lmode(b); return n;
}
static Node *member_node(Node *s, Member *m) { Node *n = un(ND_MEMBER, s, m->ty); n->mem = m; n->lm = lmode(m->ty); return n; }
static Node *addr_node(Node *l) {
    Type *t = l->ty;
    if (l->kind == ND_DEREF) { Node *n = un(ND_CAST, l->lhs, pointer_to(t)); n->val = LM_32; return n; }
    return un(ND_ADDR, l, pointer_to(t));
}
static Type *promote(Type *t) { return (is_int(t) && t->size < 4) ? ty_int : t; }
static int cast_mode(Type *ty) {
    if (ty->kind == TY_BOOL) return LM_BOOL;
    if (is_int(ty)) { if (ty->size == 1) return ty->uns ? LM_U8 : LM_S8; if (ty->size == 2) return ty->uns ? LM_U16 : LM_S16; }
    return LM_32;
}
static Node *cast_to(Node *e, Type *ty) {
    if (ty->kind == TY_VOID) { Node *n = un(ND_CAST, e, ty); n->val = LM_32; return n; }
    if (is_agg(ty) || ty->kind == TY_FUNC) return e;
    int m = cast_mode(ty);
    if (e->kind == ND_NUM && is_int(ty)) return num((s32)trunc_lm((u32)e->val, m), ty);
    Node *n = un(ND_CAST, e, ty); n->val = m; return n;
}
static Type *arith_type(Node *l, Node *r) {
    int ul = l->ty->size == 4 && l->ty->uns, ur = r->ty->size == 4 && r->ty->uns;
    return (ul || ur) ? ty_uint : ty_int;
}
static int is_const_node(Node *n) { return n->kind == ND_NUM; }
static Node *arith(NodeKind k, Node *l, Node *r) {
    Node *n = mk(k); n->lhs = l; n->rhs = r;
    if (k == ND_SHL || k == ND_SHR) { Type *t = promote(l->ty); n->ty = (t->size == 4 && t->uns) ? ty_uint : ty_int; n->uns = n->ty == ty_uint; }
    else { n->ty = arith_type(l, r); n->uns = n->ty == ty_uint; }
    if (k == ND_EQ || k == ND_NE || k == ND_LT || k == ND_LE) n->ty = ty_int;
    if (is_const_node(l) && is_const_node(r) && !((k == ND_DIV || k == ND_MOD) && r->val == 0))
        return num((s32)do_binop(k, (u32)l->val, (u32)r->val, n->uns), n->ty);
    return n;
}
static Node *new_add(Node *l, Node *r) {
    if (is_int(l->ty) && is_int(r->ty)) return arith(ND_ADD, l, r);
    if (is_ptr(r->ty) && is_int(l->ty)) { Node *t = l; l = r; r = t; }
    if (!is_ptr(l->ty) || !is_int(r->ty)) err("invalid operands to +");
    int sz = l->ty->base->size; if (l->ty->base->kind == TY_VOID) sz = 1;
    Node *n = mk(ND_ADD); n->lhs = l; n->rhs = arith(ND_MUL, r, num(sz, ty_int)); n->ty = pointer_to(l->ty->base); n->uns = 1; return n;
}
static Node *new_sub(Node *l, Node *r) {
    if (is_int(l->ty) && is_int(r->ty)) return arith(ND_SUB, l, r);
    if (is_ptr(l->ty) && is_int(r->ty)) {
        int sz = l->ty->base->size; if (l->ty->base->kind == TY_VOID) sz = 1;
        Node *n = mk(ND_SUB); n->lhs = l; n->rhs = arith(ND_MUL, r, num(sz, ty_int)); n->ty = pointer_to(l->ty->base); n->uns = 1; return n;
    }
    if (is_ptr(l->ty) && is_ptr(r->ty)) {
        int sz = l->ty->base->size; if (sz < 1) sz = 1;
        Node *d = mk(ND_SUB); d->lhs = l; d->rhs = r; d->ty = ty_int; d->uns = 0;
        Node *n = mk(ND_DIV); n->lhs = d; n->rhs = num(sz, ty_int); n->ty = ty_int; n->uns = 0; return n;
    }
    err("invalid operands to -"); return NULL;
}

/* ---------- globals / objects ---------- */
static Obj *new_obj(const char *name, int len, Type *ty) { Obj *o = xalloc(sizeof(Obj)); o->name = xstrndup(name, len); o->ty = ty; return o; }
static void gadd(Obj *o) { if (g_tail) g_tail->gnext = o; else g_objs = o; g_tail = o; }
static Obj *gfind(const char *name, int len) {
    for (Obj *o = gtab[hash_n(name, len) % GH]; o; o = o->hnext) if ((int)strlen(o->name) == len && !memcmp(o->name, name, len)) return o;
    return NULL;
}
Obj *cc_find_global(const char *name) { return gfind(name, (int)strlen(name)); }
static Obj *gcreate(const char *name, int len, Type *ty, int external) {
    Obj *o = new_obj(name, len, ty); gadd(o);
    if (external) { unsigned h = hash_n(name, len) % GH; o->hnext = gtab[h]; gtab[h] = o; }
    return o;
}
static void alloc_local(Obj *v) {
    int a = v->ty->align < 1 ? 1 : v->ty->align; cur_stack = align_up(cur_stack, a);
    v->off = cur_stack; cur_stack += v->ty->size > 0 ? v->ty->size : 1;
}
static Obj *new_tmp(Type *ty) { Obj *v = new_obj("", 0, ty); v->is_local = 1; alloc_local(v); return v; }
static Node *str_node(const u8 *s, int n) {
    Obj *o = gcreate("", 0, array_of(ty_char, n + 1), 0);
    o->ty = qual_const(o->ty); o->ty->base = qual_const(ty_char);
    o->is_def = 1; o->is_const = 1; o->img = xalloc(n + 1); memcpy(o->img, s, n); o->imglen = n + 1;
    return var_node(o);
}

/* ---------- constant evaluation ---------- */
static s32 ceval(Node *n, Obj **lab);
static s32 addr_const(Node *n, Obj **lab) {
    switch (n->kind) {
    case ND_GVAR: *lab = n->var; return 0;
    case ND_MEMBER: return addr_const(n->lhs, lab) + n->mem->off;
    case ND_DEREF: return ceval(n->lhs, lab);
    default: err("initializer element is not constant"); return 0;
    }
}
static s32 ceval(Node *n, Obj **lab) {
    Obj *l1 = NULL, *l2 = NULL; s32 a, b;
    switch (n->kind) {
    case ND_NUM: return n->val;
    case ND_CAST: a = ceval(n->lhs, lab); if (*lab) return a; return (s32)trunc_lm((u32)a, n->val);
    case ND_ADD: a = ceval(n->lhs, &l1); b = ceval(n->rhs, &l2); if (l1 && l2) err("bad constant"); *lab = l1 ? l1 : l2; return a + b;
    case ND_SUB: a = ceval(n->lhs, &l1); b = ceval(n->rhs, &l2); if (l2) err("bad constant"); *lab = l1; return a - b;
    case ND_ADDR: return addr_const(n->lhs, lab);
    case ND_GVAR: if (n->lm == LM_AGG) { *lab = n->var; return 0; } err("initializer element is not constant"); return 0;
    case ND_MEMBER: if (n->lm == LM_AGG) return addr_const(n, lab); err("initializer element is not constant"); return 0;
    case ND_COMMA: ceval(n->lhs, &l1); return ceval(n->rhs, lab);
    case ND_COND: a = ceval(n->cond, &l1); return a ? ceval(n->then, lab) : ceval(n->els, lab);
    case ND_NOT: a = ceval(n->lhs, &l1); return !a;
    case ND_NEG: a = ceval(n->lhs, &l1); return -a;
    case ND_BITNOT: a = ceval(n->lhs, &l1); return ~a;
    case ND_LOGAND: a = ceval(n->lhs, &l1); return a && ceval(n->rhs, &l2);
    case ND_LOGOR: a = ceval(n->lhs, &l1); return a || ceval(n->rhs, &l2);
    case ND_MUL: case ND_DIV: case ND_MOD: case ND_AND: case ND_OR: case ND_XOR: case ND_SHL: case ND_SHR: case ND_EQ: case ND_NE: case ND_LT: case ND_LE:
        a = ceval(n->lhs, &l1); b = ceval(n->rhs, &l2);
        if (l1 || l2) err("bad constant expression");
        if ((n->kind == ND_DIV || n->kind == ND_MOD) && b == 0) err("division by zero in constant");
        return (s32)do_binop(n->kind, (u32)a, (u32)b, n->uns);
    default: err("initializer element is not constant"); return 0;
    }
}
static s32 const_int(Node *n) { Obj *l = NULL; s32 v = ceval(n, &l); if (l) err("integer constant expression required"); return v; }

/* ---------- forward decls ---------- */
static Node *expr(void); static Node *assign(void); static Node *conditional(void); static Node *cast_expr(void);
static Node *compound_stmt(void); static Type *declspec(void *attr); static Type *declarator(Type *ty, Token **name);
static Type *typename_(void);
typedef struct { int is_typedef, is_static, is_extern, is_inline; } Attr;

/* ---------- declaration specifiers ---------- */
static const char *kw_types[] = { "void", "_Bool", "char", "short", "int", "long", "float", "double", "signed", "unsigned", "struct", "union", "enum", "typedef", "static", "extern",
    "inline", "const", "volatile", "register", "auto", "restrict", "_Noreturn", "__attribute__", "__inline", "__inline__", "__const", "__volatile__", "__restrict", "__restrict__", "__extension__", NULL };
static int is_typename(Token *t) {
    if (t->kind != TK_IDENT) return 0;
    for (int i = 0; kw_types[i]; i++) if (tok_is(t, kw_types[i])) return 1;
    Sym *y = lookup(t, 0); return y && y->kind == S_TYPEDEF;
}
static Member *find_member(Type *ty, const char *name, int len, int *extra) {
    for (Member *m = ty->mem; m; m = m->next) {
        if (m->name) { if (m->nlen == len && !memcmp(m->name, name, len)) return m; }
        else if (is_agg(m->ty)) { Member *r = find_member(m->ty, name, len, extra); if (r) { *extra += m->off; return r; } }
    }
    return NULL;
}
static Type *struct_decl(int is_union) {
    skip_attrs();
    Token *tag = NULL;
    if (tk->kind == TK_IDENT) { tag = tk; tk = tk->next; }
    if (tag && !eq("{")) {
        Sym *y = lookup(tag, 1); if (y) return y->ty;
        Type *t = mkty(is_union ? TY_UNION : TY_STRUCT, 0, 0); t->align = 1; t->incomplete = 1;
        declare(tag->str, tag->len, 1, S_TYPEDEF)->ty = t; return t;
    }
    Type *ty = NULL;
    if (tag) { Sym *y = lookup(tag, 1); if (y && y->sc == scope && y->ty->incomplete) ty = y->ty; }
    if (!ty) { ty = mkty(is_union ? TY_UNION : TY_STRUCT, 0, 0); ty->align = 1; if (tag) declare(tag->str, tag->len, 1, S_TYPEDEF)->ty = ty; }
    skip("{");
    Member head = {0}, *cur = &head; int off = 0, maxsz = 0, al = 1;
    while (!eq("}")) {
        Type *base = declspec(NULL);
        if (eq(";") && is_agg(base)) { /* anonymous struct/union member */
            tk = tk->next; Member *m = xalloc(sizeof(Member)); m->ty = base; int a = base->align;
            if (is_union) { m->off = 0; if (base->size > maxsz) maxsz = base->size; } else { off = align_up(off, a); m->off = off; off += base->size; }
            if (a > al) al = a; cur = cur->next = m; continue;
        }
        for (int first = 1; !eq(";"); first = 0) {
            if (!first) skip(",");
            Token *name = NULL; Type *mty = declarator(base, &name);
            skip_attrs();
            if (eq(":")) err("bit-fields are not supported");
            if (!name) err("member name expected");
            Member *m = xalloc(sizeof(Member)); m->ty = mty; m->name = name->str; m->nlen = name->len;
            int a = mty->align < 1 ? 1 : mty->align;
            if (is_union) { m->off = 0; if (mty->size > maxsz) maxsz = mty->size; } else { off = align_up(off, a); m->off = off; off += mty->size; }
            if (a > al) al = a; cur = cur->next = m;
        }
        skip(";");
    }
    skip("}"); skip_attrs();
    ty->mem = head.next; ty->align = al; ty->size = align_up(is_union ? maxsz : off, al); ty->incomplete = 0;
    return ty;
}
static Type *enum_spec(void) {
    skip_attrs();
    Token *tag = NULL; if (tk->kind == TK_IDENT) { tag = tk; tk = tk->next; }
    if (tag && !eq("{")) { Sym *y = lookup(tag, 1); if (!y) err("unknown enum type"); return y->ty; }
    Type *ty = mkty(TY_ENUM, 4, 1);
    skip("{"); s32 v = 0; int neg = 0;
    while (!eq("}")) {
        if (tk->kind != TK_IDENT) err("enumerator name expected");
        Token *nm = tk; tk = tk->next;
        if (consume("=")) v = const_int(conditional());
        Sym *y = declare(nm->str, nm->len, 0, S_ENUM); y->val = v; if (v < 0) neg = 1; v++;
        if (!consume(",")) break;
    }
    skip("}"); ty->uns = !neg;
    if (tag) declare(tag->str, tag->len, 1, S_TYPEDEF)->ty = ty;
    return ty;
}
static Type *declspec(void *attrp) {
    enum { VOID = 1, BOOL = 4, CHAR = 16, SHORT = 64, INT = 256, LONG = 1024, FLT = 4096, DBL = 16384, OTHER = 65536, SIGNED = 1 << 17, UNSIGNED = 1 << 18 };
    Attr *attr = attrp; Attr dummy; if (!attr) attr = &dummy; memset(attr, 0, sizeof *attr);
    Type *ty = ty_int; int counter = 0, is_const = 0;
    while (is_typename(tk)) {
        if (eq("typedef")) { attr->is_typedef = 1; tk = tk->next; continue; }
        if (eq("static")) { attr->is_static = 1; tk = tk->next; continue; }
        if (eq("extern")) { attr->is_extern = 1; tk = tk->next; continue; }
        if (eq("inline") || eq("__inline") || eq("__inline__")) { attr->is_inline = 1; tk = tk->next; continue; }
        if (eq("const") || eq("__const")) { is_const = 1; tk = tk->next; continue; }
        if (eq("volatile") || eq("register") || eq("auto") || eq("restrict") || eq("_Noreturn") || eq("__volatile__") || eq("__restrict") || eq("__restrict__") || eq("__extension__")) { tk = tk->next; continue; }
        if (eq("__attribute__")) { skip_attrs(); continue; }
        if (eq("struct") || eq("union")) { int u = eq("union"); tk = tk->next; if (counter) break; ty = struct_decl(u); counter += OTHER; continue; }
        if (eq("enum")) { tk = tk->next; if (counter) break; ty = enum_spec(); counter += OTHER; continue; }
        if (tk->kind == TK_IDENT && !eq("void") && !eq("_Bool") && !eq("char") && !eq("short") && !eq("int") && !eq("long") && !eq("float") && !eq("double") && !eq("signed") && !eq("unsigned")) {
            if (counter) break;
            Sym *y = lookup(tk, 0); if (!y || y->kind != S_TYPEDEF) break;
            ty = y->ty; counter += OTHER; tk = tk->next; continue;
        }
        if (eq("void")) counter += VOID; else if (eq("_Bool")) counter += BOOL; else if (eq("char")) counter += CHAR;
        else if (eq("short")) counter += SHORT; else if (eq("int")) counter += INT; else if (eq("long")) counter += LONG;
        else if (eq("float")) counter += FLT; else if (eq("double")) counter += DBL;
        else if (eq("signed")) counter |= SIGNED; else if (eq("unsigned")) counter |= UNSIGNED;
        tk = tk->next;
        switch (counter) {
        case VOID: ty = ty_void; break;
        case BOOL: ty = ty_bool; break;
        case CHAR: ty = ty_char; break;
        case SIGNED + CHAR: ty = ty_schar; break;
        case UNSIGNED + CHAR: ty = ty_uchar; break;
        case SHORT: case SHORT + INT: case SIGNED + SHORT: case SIGNED + SHORT + INT: ty = ty_short; break;
        case UNSIGNED + SHORT: case UNSIGNED + SHORT + INT: ty = ty_ushort; break;
        case INT: case SIGNED: case SIGNED + INT: ty = ty_int; break;
        case UNSIGNED: case UNSIGNED + INT: ty = ty_uint; break;
        case LONG: case LONG + INT: case SIGNED + LONG: case SIGNED + LONG + INT: ty = ty_int; break;
        case UNSIGNED + LONG: case UNSIGNED + LONG + INT: ty = ty_uint; break;
        case LONG + LONG: case LONG + LONG + INT: case SIGNED + LONG + LONG: case UNSIGNED + LONG + LONG: err("'long long' is not supported"); break;
        case FLT: case DBL: case LONG + DBL: err("floating point is not supported"); break;
        case OTHER: break;
        default: break;
        }
    }
    if (is_const) ty = qual_const(ty);
    return ty;
}

/* ---------- declarators ---------- */
static Type *func_params(Type *ret) {
    Type *fty = mkty(TY_FUNC, 1, 0); fty->base = ret;
    if (eq("void") && tok_is(tk->next, ")")) { tk = tk->next->next; return fty; }
    if (eq(")")) { tk = tk->next; fty->unspec = 1; return fty; }
    Type head = {0}, *cur = &head;
    while (!eq(")")) {
        if (consume("...")) { fty->variadic = 1; break; }
        Type *base = declspec(NULL); Token *pn = NULL; Type *pty = declarator(base, &pn);
        if (pty->kind == TY_ARRAY) { Type *q = pointer_to(pty->base); pty = q; } else if (pty->kind == TY_FUNC) pty = pointer_to(pty);
        Type *p = copy_type(pty); p->next = NULL; if (pn) { p->pname = pn->str; p->pnlen = pn->len; }
        cur = cur->next = p;
        if (!consume(",")) break;
    }
    skip(")"); fty->params = head.next; return fty;
}
static Type *type_suffix(Type *ty) {
    if (consume("(")) return func_params(ty);
    if (consume("[")) {
        while (eq("static") || eq("const") || eq("restrict")) tk = tk->next;
        int len = -1;
        if (!eq("]")) len = const_int(conditional());
        skip("]");
        ty = type_suffix(ty);
        return array_of(ty, len);
    }
    return ty;
}
static Type *pointers(Type *ty) {
    while (consume("*")) {
        ty = pointer_to(ty);
        for (;;) {
            if (eq("const") || eq("__const")) { ty = qual_const(ty); tk = tk->next; }
            else if (eq("volatile") || eq("restrict") || eq("__restrict") || eq("__restrict__")) tk = tk->next;
            else if (eq("__attribute__")) skip_attrs();
            else break;
        }
    }
    return ty;
}
static Type *declarator(Type *ty, Token **name) {
    ty = pointers(ty); skip_attrs();
    if (eq("(") && (tok_is(tk->next, "*") || tok_is(tk->next, "(") || tok_is(tk->next, "__attribute__") || (tk->next->kind == TK_IDENT && !is_typename(tk->next)))) {
        Token *start = tk->next; tk = start;
        Type dummy; memset(&dummy, 0, sizeof dummy); dummy.kind = TY_INT; dummy.size = 4; dummy.align = 4;
        Token *dn = NULL; declarator(&dummy, &dn);
        skip(")");
        ty = type_suffix(ty);
        Token *end = tk; tk = start;
        ty = declarator(ty, name);
        tk = end; return ty;
    }
    if (tk->kind == TK_IDENT && !is_typename(tk)) { if (name) *name = tk; tk = tk->next; }
    ty = type_suffix(ty); skip_attrs();
    return ty;
}
static Type *typename_(void) { Type *b = declspec(NULL); return declarator(b, NULL); }

/* ---------- expressions ---------- */
static void unpack_numlist(void) {
    Token *nl = tk, *rest = nl->next, head = {0}, *cur = &head; const s32 *v = (const s32 *)nl->sval; const u8 *f = (const u8 *)nl->str;
    for (int i = 0; i < nl->slen; i++) {
        Token *a = talloc(sizeof(Token)), *c = talloc(sizeof(Token));
        a->kind = TK_NUM; a->val = v[i]; a->uns = f[i]; a->file = nl->file; a->line = nl->line; a->str = "0"; a->len = 1;
        c->kind = TK_PUNCT; c->str = ","; c->len = 1; c->file = nl->file; c->line = nl->line;
        cur->next = a; a->next = c; cur = c;
    }
    cur->next = rest; tk = head.next;
}
static Node *func_call(Node *fn);
static Node *assign_op(NodeKind k, Node *l, Node *r) {
    Node *n = mk(ND_OPASSIGN); n->op = k; n->lhs = l; n->ty = l->ty; n->lm = l->lm;
    if (is_ptr(l->ty) && (k == ND_ADD || k == ND_SUB)) { int sz = l->ty->base->size; if (sz < 1) sz = 1; r = arith(ND_MUL, r, num(sz, ty_int)); n->uns = 1; }
    else if (k == ND_SHL || k == ND_SHR) { Type *t = promote(l->ty); n->uns = t->size == 4 && t->uns; }
    else n->uns = arith_type(l, r) == ty_uint;
    n->rhs = r; return n;
}
static Node *assign_node(Node *l, Node *r) {
    Node *n = mk(ND_ASSIGN); n->lhs = l; n->rhs = r; n->ty = l->ty; n->lm = l->lm;
    if (l->lm == LM_AGG && !is_agg(l->ty)) err("assignment to array or function");
    return n;
}
static Node *primary(void) {
    Token *t = tk;
    if (t->kind == TK_NUMLIST) { unpack_numlist(); t = tk; }
    if (consume("(")) {
        if (eq("{")) err("statement expressions are not supported");
        Node *n = expr(); skip(")"); return n;
    }
    if (t->kind == TK_NUM) {
        if (t->uns == 2) err("floating point is not supported");
        tk = tk->next; return num(t->val, (t->uns == 1) ? ty_uint : ty_int);
    }
    if (t->kind == TK_STR) {
        u8 *buf = NULL; int n = 0;
        while (tk->kind == TK_STR) { buf = realloc(buf, n + tk->slen + 1); memcpy(buf + n, tk->sval, tk->slen); n += tk->slen; tk = tk->next; }
        Node *r = str_node(buf ? buf : (u8 *)"", n); free(buf); return r;
    }
    if (t->kind == TK_IDENT) {
        Sym *y = lookup(t, 0);
        if (!y) err("'%.*s' undeclared", t->len, t->str);
        tk = tk->next;
        if (y->kind == S_ENUM) return num(y->val, ty_int);
        if (y->kind == S_TYPEDEF) err("unexpected type name '%.*s'", t->len, t->str);
        return var_node(y->var);
    }
    err("expression expected"); return NULL;
}
static Node *postfix(void) {
    Node *n = primary();
    for (;;) {
        if (eq("(")) { n = func_call(n); continue; }
        if (consume("[")) { Node *i = expr(); skip("]"); n = deref_node(new_add(n, i)); continue; }
        if (eq(".") || eq("->")) {
            int arrow = eq("->"); tk = tk->next;
            if (tk->kind != TK_IDENT) err("member name expected");
            if (arrow) n = deref_node(n);
            if (!is_agg(n->ty)) err("member access on non-struct");
            int extra = 0; Member *m = find_member(n->ty, tk->str, tk->len, &extra);
            if (!m) err("no member named '%.*s'", tk->len, tk->str);
            tk = tk->next;
            if (extra) { Member *w = xalloc(sizeof(Member)); *w = *m; w->off += extra; m = w; }
            n = member_node(n, m); continue;
        }
        if (eq("++") || eq("--")) {
            int inc = eq("++"); tk = tk->next;
            Node *p = mk(ND_POSTINC); p->lhs = n; p->ty = n->ty; p->lm = n->lm;
            int sz = 1; if (is_ptr(n->ty)) { sz = n->ty->base->size; if (sz < 1) sz = 1; }
            p->val = inc ? sz : -sz; n = p; continue;
        }
        return n;
    }
}
static Node *func_call(Node *fn) {
    skip("(");
    Type *fty = fn->ty;
    if (fty->kind == TY_PTR && fty->base->kind == TY_FUNC) fty = fty->base;
    if (fty->kind != TY_FUNC) err("called object is not a function");
    Node head = {0}, *cur = &head; Type *pt = fty->params; int nargs = 0;
    while (!eq(")")) {
        Node *a = assign();
        if (is_agg(a->ty) == 0 && pt && pt->kind != TY_ARRAY && !is_agg(pt)) a = a; /* store truncates */
        cur = cur->next = a; nargs++; if (pt) pt = pt->next;
        if (!consume(",")) break;
    }
    skip(")");
    int np = 0; for (Type *p = fty->params; p; p = p->next) np++;
    if (!fty->unspec && nargs < np) err("too few arguments to function call");
    if (!fty->unspec && !fty->variadic && nargs > np) err("too many arguments to function call");
    Node *n = mk(ND_CALL); n->args = head.next; n->ty = fty->base;
    if (fn->kind == ND_GVAR && fn->var->is_func) n->func = fn->var; else n->lhs = fn;
    if (is_agg(n->ty)) { if (!cur_fn) err("struct return outside function"); n->var = new_tmp(n->ty); }
    return n;
}
static Node *unary(void) {
    if (consume("+")) { Node *e = cast_expr(); return arith(ND_ADD, num(0, ty_int), e); }
    if (consume("-")) { Node *e = cast_expr(); Type *t = promote(e->ty); if (e->kind == ND_NUM) return num(-e->val, (t->size == 4 && t->uns) ? ty_uint : ty_int); return un(ND_NEG, e, (t->size == 4 && t->uns) ? ty_uint : ty_int); }
    if (consume("!")) { Node *e = cast_expr(); return un(ND_NOT, e, ty_int); }
    if (consume("~")) { Node *e = cast_expr(); Type *t = promote(e->ty); if (e->kind == ND_NUM) return num(~e->val, (t->size == 4 && t->uns) ? ty_uint : ty_int); return un(ND_BITNOT, e, (t->size == 4 && t->uns) ? ty_uint : ty_int); }
    if (consume("*")) {
        Node *e = cast_expr();
        if (e->ty->kind == TY_FUNC) return e;
        if (e->ty->kind == TY_PTR && e->ty->base->kind == TY_FUNC) return deref_node(e);
        return deref_node(e);
    }
    if (consume("&")) { Node *e = cast_expr(); if (e->ty->kind == TY_FUNC) return e; return addr_node(e); }
    if (eq("++") || eq("--")) {
        int inc = eq("++"); tk = tk->next; Node *l = unary();
        int sz = 1; if (is_ptr(l->ty)) { sz = l->ty->base->size; if (sz < 1) sz = 1; }
        Node *p = mk(ND_PREINC); p->lhs = l; p->ty = l->ty; p->lm = l->lm; p->val = inc ? sz : -sz; return p;
    }
    if (eq("sizeof")) {
        tk = tk->next;
        if (eq("(") && is_typename(tk->next)) { tk = tk->next; Type *t = typename_(); skip(")"); return num(t->size, ty_uint); }
        Node *e = unary(); return num(e->ty->size, ty_uint);
    }
    return postfix();
}
static Node *cast_expr(void) {
    if (eq("(") && is_typename(tk->next)) {
        Token *save = tk; tk = tk->next; Type *t = typename_(); skip(")");
        if (eq("{")) { tk = save; err("compound literals are not supported"); }
        return cast_to(cast_expr(), t);
    }
    return unary();
}
static int bin_prec(Token *t, NodeKind *k, int *sw) {
    static const struct { const char *s; int p; NodeKind k; int sw; } tb[] = {
        {"||",1,ND_LOGOR,0},{"&&",2,ND_LOGAND,0},{"|",3,ND_OR,0},{"^",4,ND_XOR,0},{"&",5,ND_AND,0},{"==",6,ND_EQ,0},{"!=",6,ND_NE,0},
        {"<",7,ND_LT,0},{">",7,ND_LT,1},{"<=",7,ND_LE,0},{">=",7,ND_LE,1},{"<<",8,ND_SHL,0},{">>",8,ND_SHR,0},{"+",9,ND_ADD,0},{"-",9,ND_SUB,0},
        {"*",10,ND_MUL,0},{"/",10,ND_DIV,0},{"%",10,ND_MOD,0},{NULL,0,0,0} };
    if (t->kind != TK_PUNCT) return 0;
    for (int i = 0; tb[i].s; i++) if (tok_is(t, tb[i].s)) { *k = tb[i].k; *sw = tb[i].sw; return tb[i].p; }
    return 0;
}
static Node *binary(int minprec) {
    Node *l = cast_expr();
    for (;;) {
        NodeKind k; int sw = 0; int p = bin_prec(tk, &k, &sw);
        if (!p || p < minprec) return l;
        tk = tk->next; Node *r = binary(p + 1);
        if (k == ND_LOGAND || k == ND_LOGOR) { Node *n = mk(k); n->lhs = l; n->rhs = r; n->ty = ty_int; l = n; continue; }
        if (sw) { Node *t = l; l = r; r = t; }
        if (k == ND_ADD) l = new_add(l, r); else if (k == ND_SUB) l = new_sub(l, r);
        else {
            if ((k == ND_EQ || k == ND_NE || k == ND_LT || k == ND_LE) && (is_ptr(l->ty) || is_ptr(r->ty))) { Node *n = mk(k); n->lhs = l; n->rhs = r; n->ty = ty_int; n->uns = 1; l = n; continue; }
            if (!is_int(l->ty) || !is_int(r->ty)) err("invalid operands to binary operator");
            l = arith(k, l, r);
        }
    }
}
static Node *conditional(void) {
    Node *c = binary(1);
    if (!consume("?")) return c;
    Node *t = expr(); skip(":"); Node *e = conditional();
    Node *n = mk(ND_COND); n->cond = c; n->then = t; n->els = e;
    if (is_int(t->ty) && is_int(e->ty)) n->ty = arith_type(t, e);
    else if (is_ptr(t->ty)) n->ty = (t->ty->kind == TY_ARRAY) ? pointer_to(t->ty->base) : t->ty;
    else if (is_ptr(e->ty)) n->ty = (e->ty->kind == TY_ARRAY) ? pointer_to(e->ty->base) : e->ty;
    else n->ty = t->ty;
    return n;
}
static Node *assign(void) {
    Node *l = conditional();
    if (consume("=")) return assign_node(l, assign());
    static const struct { const char *s; NodeKind k; } ops[] = { {"+=",ND_ADD},{"-=",ND_SUB},{"*=",ND_MUL},{"/=",ND_DIV},{"%=",ND_MOD},{"&=",ND_AND},{"|=",ND_OR},{"^=",ND_XOR},{"<<=",ND_SHL},{">>=",ND_SHR},{NULL,0} };
    for (int i = 0; ops[i].s; i++) if (consume(ops[i].s)) return assign_op(ops[i].k, l, assign());
    return l;
}
static Node *expr(void) {
    Node *n = assign();
    while (consume(",")) { Node *c = mk(ND_COMMA); c->lhs = n; c->rhs = assign(); c->ty = c->rhs->ty; n = c; }
    return n;
}

/* ---------- global initializers (written straight into an image buffer) ---------- */
typedef struct { u8 *p; int len, cap; } Buf;
static Buf gb; static Obj *g_owner;
static void bensure(int n) {
    if (n > gb.cap) { int nc = gb.cap ? gb.cap * 2 : 256; while (nc < n) nc *= 2; gb.p = realloc(gb.p, nc); memset(gb.p + gb.cap, 0, nc - gb.cap); gb.cap = nc; }
    if (n > gb.len) gb.len = n;
}
static void bput(int off, int size, u32 v) { bensure(off + size); for (int i = 0; i < size; i++) gb.p[off + i] = (u8)(v >> (8 * i)); }
static void gi_init(int off, Type *ty);
static void gi_scalar(int off, Type *ty) {
    if (tk->kind == TK_NUMLIST) unpack_numlist();
    int braced = consume("{");
    if (tk->kind == TK_NUM && tk->uns != 2 && (tok_is(tk->next, ",") || tok_is(tk->next, "}") || tok_is(tk->next, ";"))) {
        u32 v = (u32)tk->val; if (ty->kind == TY_BOOL) v = v != 0; bput(off, ty->size, v); tk = tk->next;
    } else {
        Node *e = assign(); Obj *lab = NULL; s32 v = ceval(e, &lab);
        if (lab) {
            if (ty->size != 4) err("address constant needs a 4-byte target");
            Reloc *r = xalloc(sizeof(Reloc)); r->off = off; r->sym = lab; r->add = v; r->next = g_owner->rels; g_owner->rels = r; bput(off, 4, 0);
        } else { if (ty->kind == TY_BOOL) v = v != 0; bput(off, ty->size, (u32)v); }
    }
    if (braced) { consume(","); skip("}"); }
}
static void gi_list(int off, Type *ty, int braced) {
    if (ty->kind == TY_ARRAY) {
        Type *b = ty->base; int i = 0, maxi = 0, esz = b->size;
        int intlike = is_int(b) || b->kind == TY_PTR;
        for (;;) {
            if (tk->kind == TK_NUMLIST) {
                int n = tk->slen;
                if (intlike && (ty->len < 0 || n <= ty->len - i)) {
                    const s32 *v = (const s32 *)tk->sval; bensure(off + (i + n) * esz);
                    for (int k = 0; k < n; k++) bput(off + (i + k) * esz, esz, (u32)v[k]);
                    i += n; if (i > maxi) maxi = i; tk = tk->next; continue;
                }
                unpack_numlist();
            }
            if (braced) { if (eq("}")) break; } else if (eq("}") || (ty->len >= 0 && i >= ty->len)) break;
            if (eq("[")) { tk = tk->next; i = const_int(conditional()); skip("]"); consume("="); }
            if (ty->len >= 0 && i >= ty->len) err("excess elements in array initializer");
            gi_init(off + i * esz, b); i++; if (i > maxi) maxi = i;
            if (!consume(",")) break;
        }
        if (ty->len < 0) { ty->len = maxi; ty->size = maxi * esz; }
        return;
    }
    Member *m = ty->mem;
    for (;;) {
        if (tk->kind == TK_NUMLIST) unpack_numlist();
        if (braced) { if (eq("}")) break; } else if (!m || eq("}")) break;
        if (eq(".")) {
            tk = tk->next; if (tk->kind != TK_IDENT) err("member name expected");
            for (m = ty->mem; m; m = m->next) if (m->name && m->nlen == tk->len && !memcmp(m->name, tk->str, tk->len)) break;
            if (!m) err("unknown member '%.*s' in initializer", tk->len, tk->str);
            tk = tk->next; skip("=");
        }
        if (!m) err("excess elements in struct initializer");
        gi_init(off + m->off, m->ty);
        m = (ty->kind == TY_UNION) ? NULL : m->next;
        if (!consume(",")) break;
    }
}
static void gi_init(int off, Type *ty) {
    if (ty->kind == TY_ARRAY) {
        if (tk->kind == TK_STR && ty->base->size == 1 && is_int(ty->base)) {
            u8 *buf = NULL; int n = 0;
            while (tk->kind == TK_STR) { buf = realloc(buf, n + tk->slen + 1); memcpy(buf + n, tk->sval, tk->slen); n += tk->slen; tk = tk->next; }
            if (ty->len < 0) { ty->len = n + 1; ty->size = n + 1; }
            bensure(off + ty->len); for (int i = 0; i < n && i < ty->len; i++) gb.p[off + i] = buf[i];
            free(buf); return;
        }
        if (consume("{")) { gi_list(off, ty, 1); skip("}"); } else gi_list(off, ty, 0);
        return;
    }
    if (is_agg(ty)) { if (consume("{")) { gi_list(off, ty, 1); skip("}"); } else gi_list(off, ty, 0); return; }
    gi_scalar(off, ty);
}
static void finish_global(Obj *o) {
    int sz = o->ty->size > gb.len ? o->ty->size : gb.len;
    o->img = xalloc(sz > 0 ? sz : 1); if (gb.len) memcpy(o->img, gb.p, gb.len);
    o->imglen = sz; free(gb.p); gb.p = NULL; gb.len = gb.cap = 0;
    o->is_const = is_const_obj(o->ty);
}
static void global_init(Obj *o) {
    if (o->is_def && o->img) err("redefinition of '%s'", o->name);
    o->is_def = 1; g_owner = o; gb.p = NULL; gb.len = gb.cap = 0;
    gi_init(0, o->ty); finish_global(o);
}

/* ---------- local initializers ---------- */
typedef struct Init Init; struct Init { Type *ty; Init **ch; Node *expr; };
static Init *new_init(Type *ty) {
    Init *in = xalloc(sizeof(Init)); in->ty = ty;
    if (ty->kind == TY_ARRAY) { int n = ty->len < 0 ? 0 : ty->len; in->ch = xalloc(sizeof(Init *) * (n + 1)); for (int i = 0; i < n; i++) in->ch[i] = new_init(ty->base); }
    else if (is_agg(ty)) { int n = 0; for (Member *m = ty->mem; m; m = m->next) n++; in->ch = xalloc(sizeof(Init *) * (n + 1)); int i = 0; for (Member *m = ty->mem; m; m = m->next) in->ch[i++] = new_init(m->ty); }
    return in;
}
static void init2(Init *in);
static void init_list(Init *in, int braced) {
    Type *ty = in->ty;
    if (ty->kind == TY_ARRAY) {
        int i = 0;
        for (;;) {
            if (tk->kind == TK_NUMLIST) unpack_numlist();
            if (braced) { if (eq("}")) break; } else if (eq("}") || i >= ty->len) break;
            if (eq("[")) { tk = tk->next; i = const_int(conditional()); skip("]"); consume("="); }
            if (i >= ty->len) err("excess elements in array initializer");
            init2(in->ch[i]); i++;
            if (!consume(",")) break;
        }
        return;
    }
    Member *m = ty->mem; int mi = 0;
    for (;;) {
        if (tk->kind == TK_NUMLIST) unpack_numlist();
        if (braced) { if (eq("}")) break; } else if (!m || eq("}")) break;
        if (eq(".")) {
            tk = tk->next; mi = 0;
            for (m = ty->mem; m; m = m->next, mi++) if (m->name && m->nlen == tk->len && !memcmp(m->name, tk->str, tk->len)) break;
            if (!m) err("unknown member in initializer");
            tk = tk->next; skip("=");
        }
        if (!m) err("excess elements in struct initializer");
        init2(in->ch[mi]);
        m = (ty->kind == TY_UNION) ? NULL : m->next; mi++;
        if (!consume(",")) break;
    }
}
static void init2(Init *in) {
    Type *ty = in->ty;
    if (ty->kind == TY_ARRAY && ty->base->size == 1 && is_int(ty->base) && tk->kind == TK_STR) {
        int i = 0;
        while (tk->kind == TK_STR) { for (int k = 0; k < tk->slen && i < ty->len; k++, i++) in->ch[i]->expr = num(tk->sval[k], ty_int); tk = tk->next; }
        return;
    }
    if (ty->kind == TY_ARRAY || is_agg(ty)) {
        if (consume("{")) { init_list(in, 1); skip("}"); return; }
        if (is_agg(ty)) { Token *save = tk; Node *e = assign(); if (is_agg(e->ty)) { in->expr = e; return; } tk = save; }
        init_list(in, 0); return;
    }
    int braced = consume("{"); in->expr = assign(); if (braced) { consume(","); skip("}"); }
}
static Node *comma_join(Node *a, Node *b) { if (!a) return b; if (!b) return a; Node *c = mk(ND_COMMA); c->lhs = a; c->rhs = b; c->ty = b->ty; return c; }
static Node *init_nodes(Init *in, Node *dst) {
    Type *ty = in->ty; Node *res = NULL;
    if (in->expr) return assign_node(dst, in->expr);
    if (ty->kind == TY_ARRAY) { for (int i = 0; i < ty->len; i++) res = comma_join(res, init_nodes(in->ch[i], deref_node(new_add(dst, num(i, ty_int))))); }
    else if (is_agg(ty)) { int i = 0; for (Member *m = ty->mem; m; m = m->next, i++) res = comma_join(res, init_nodes(in->ch[i], member_node(dst, m))); }
    return res;
}
static int count_braced_elems(void) {
    Token *t = tk; if (!tok_is(t, "{")) return 1;
    int depth = 0, n = 0, last_comma = 1, any = 0;
    for (; t->kind != TK_EOF; t = t->next) {
        if (tok_is(t, "{") || tok_is(t, "(") || tok_is(t, "[")) { depth++; if (depth == 1) continue; }
        else if (tok_is(t, "}") || tok_is(t, ")") || tok_is(t, "]")) { depth--; if (depth == 0) break; }
        if (depth == 1) {
            if (t->kind == TK_NUMLIST) { n += t->slen; last_comma = 1; any = 1; }
            else if (tok_is(t, ",")) { n++; last_comma = 1; }
            else { if (last_comma) any = 1; last_comma = 0; }
        } else any = 1, last_comma = 0;
    }
    if (any && !last_comma) n++;
    return n;
}

/* ---------- declarations ---------- */
static Obj *declare_global(Token *name, Type *ty, Attr *attr) {
    Sym *y = lookup(name, 0); Obj *o;
    if (attr->is_static) {
        if (y && y->sc == scope && y->kind == S_VAR && !y->var->is_local && y->var->is_static && !y->var->is_func) o = y->var;
        else { o = gcreate(name->str, name->len, ty, 0); o->is_static = 1; declare(name->str, name->len, 0, S_VAR)->var = o; }
    } else {
        o = gfind(name->str, name->len);
        if (!o) o = gcreate(name->str, name->len, ty, 1);
        if (o->is_func) err("'%s' redeclared as a different kind of symbol", o->name);
        if (!y || y->var != o) declare(name->str, name->len, 0, S_VAR)->var = o;
    }
    if (ty->kind != TY_ARRAY || ty->len >= 0 || o->ty->kind != TY_ARRAY) { if (!(ty->kind == TY_ARRAY && ty->len < 0 && o->ty->kind == TY_ARRAY && o->ty->len >= 0)) o->ty = ty; }
    return o;
}
static Obj *declare_func(Token *name, Type *ty, Attr *attr) {
    Sym *y = lookup(name, 0); Obj *o;
    if (attr->is_static) {
        if (y && y->sc == scope && y->kind == S_VAR && y->var->is_func && y->var->is_static) o = y->var;
        else { o = gcreate(name->str, name->len, ty, 0); o->is_func = 1; o->is_static = 1; declare(name->str, name->len, 0, S_VAR)->var = o; }
    } else {
        o = gfind(name->str, name->len);
        if (!o) { o = gcreate(name->str, name->len, ty, 1); o->is_func = 1; }
        if (!o->is_func) err("'%s' redeclared as a different kind of symbol", o->name);
        if (!y || y->var != o) declare(name->str, name->len, 0, S_VAR)->var = o;
    }
    if (ty->params || !o->ty || o->ty->unspec) o->ty = ty;
    return o;
}
static Node *stmt(void);
static Node *declaration(void) {
    Attr attr; Type *base = declspec(&attr);
    Node head = {0}, *cur = &head;
    if (consume(";")) return NULL;
    for (int first = 1; !eq(";"); first = 0) {
        if (!first) skip(",");
        Token *name = NULL; Type *ty = declarator(base, &name); skip_attrs();
        if (!name) err("variable name omitted");
        if (attr.is_typedef) { declare(name->str, name->len, 0, S_TYPEDEF)->ty = ty; continue; }
        if (ty->kind == TY_FUNC) { Attr a = attr; a.is_static = 0; declare_func(name, ty, &a); continue; }
        if (attr.is_extern) { Attr a = attr; a.is_static = 0; declare_global(name, ty, &a); continue; }
        if (attr.is_static) {
            char nm[200]; snprintf(nm, sizeof nm, "%s.%.*s.%d", cur_fn ? cur_fn->name : "", name->len, name->str, ++uniq);
            Obj *o = gcreate(nm, (int)strlen(nm), ty, 0); o->is_static = 1;
            if (consume("=")) global_init(o); else o->is_tentative = 1;
            o->is_const = is_const_obj(o->ty);
            declare(name->str, name->len, 0, S_VAR)->var = o; continue;
        }
        Obj *v = new_obj(name->str, name->len, ty); v->is_local = 1;
        Node *init = NULL;
        if (consume("=")) {
            if (ty->kind == TY_ARRAY && ty->len < 0) {
                int n;
                if (tk->kind == TK_STR) { n = 1; for (Token *t = tk; t->kind == TK_STR; t = t->next) n += t->slen; } else n = count_braced_elems();
                ty = array_of(ty->base, n); v->ty = ty;
            }
            Sym *y = declare(name->str, name->len, 0, S_VAR); y->var = v;
            Init *in = new_init(ty); init2(in);
            alloc_local(v); Node *dst = var_node(v);
            Node *z = (is_agg(ty) || ty->kind == TY_ARRAY) && !in->expr ? un(ND_MEMZERO, dst, ty_void) : NULL;
            init = comma_join(z, init_nodes(in, dst));
        } else {
            if (ty->kind == TY_ARRAY && ty->len < 0) err("array size missing");
            alloc_local(v); declare(name->str, name->len, 0, S_VAR)->var = v;
        }
        if (init) { Node *es = mk(ND_EXPR_STMT); es->lhs = init; cur = cur->next = es; }
    }
    skip(";");
    Node *b = mk(ND_BLOCK); b->body = head.next; return b;
}

/* ---------- statements ---------- */
static Node *compound_stmt(void) {
    Node *n = mk(ND_BLOCK); skip("{"); enter_scope();
    Node head = {0}, *cur = &head;
    while (!eq("}")) {
        if (tk->kind == TK_EOF) err("unexpected end of file");
        Node *s;
        if (is_typename(tk) && !tok_is(tk->next, ":")) s = declaration(); else s = stmt();
        if (s) cur = cur->next = s;
    }
    leave_scope(); skip("}"); n->body = head.next; return n;
}
static Node *stmt(void) {
    if (consume("return")) {
        Node *n = mk(ND_RETURN);
        if (consume(";")) return n;
        Node *e = expr(); skip(";");
        Type *rt = cur_fn->ty->base;
        if (rt->kind != TY_VOID && !is_agg(rt)) e = cast_to(e, rt);
        n->lhs = e; return n;
    }
    if (consume("if")) {
        Node *n = mk(ND_IF); skip("("); n->cond = expr(); skip(")"); n->then = stmt();
        if (consume("else")) n->els = stmt();
        return n;
    }
    if (consume("for")) {
        Node *n = mk(ND_FOR); skip("("); enter_scope();
        if (is_typename(tk)) n->init = declaration();
        else if (consume(";")) {}
        else { Node *e = mk(ND_EXPR_STMT); e->lhs = expr(); skip(";"); n->init = e; }
        if (!eq(";")) n->cond = expr();
        skip(";");
        if (!eq(")")) n->inc = expr();
        skip(")"); n->then = stmt(); leave_scope(); return n;
    }
    if (consume("while")) { Node *n = mk(ND_FOR); skip("("); n->cond = expr(); skip(")"); n->then = stmt(); return n; }
    if (consume("do")) { Node *n = mk(ND_DO); n->then = stmt(); skip("while"); skip("("); n->cond = expr(); skip(")"); skip(";"); return n; }
    if (consume("switch")) {
        Node *n = mk(ND_SWITCH); skip("("); n->cond = expr(); skip(")");
        Node *save = cur_switch; cur_switch = n; n->then = stmt(); cur_switch = save; return n;
    }
    if (eq("case")) {
        if (!cur_switch) err("'case' outside of switch");
        tk = tk->next; Node *n = mk(ND_CASE); n->val = const_int(conditional()); skip(":");
        n->case_next = cur_switch->case_next; cur_switch->case_next = n; n->lhs = stmt(); return n;
    }
    if (eq("default")) {
        if (!cur_switch) err("'default' outside of switch");
        tk = tk->next; skip(":"); Node *n = mk(ND_CASE); cur_switch->default_case = n; n->lhs = stmt(); return n;
    }
    if (consume("break")) { skip(";"); return mk(ND_BREAK); }
    if (consume("continue")) { skip(";"); return mk(ND_CONTINUE); }
    if (eq("goto")) err("goto is not supported");
    if (eq("{")) return compound_stmt();
    if (consume(";")) return mk(ND_BLOCK);
    if (tk->kind == TK_IDENT && tok_is(tk->next, ":")) err("labels are not supported");
    Node *n = mk(ND_EXPR_STMT); n->lhs = expr(); skip(";"); return n;
}

/* ---------- functions and translation units ---------- */
static void function_def(Token *name, Type *ty, Attr *attr) {
    Obj *fn = declare_func(name, ty, attr);
    if (fn->is_def) err("redefinition of '%s'", fn->name);
    fn->is_def = 1; fn->ty = ty;
    Obj *sf = cur_fn; int ss = cur_stack; cur_fn = fn; cur_stack = 0;
    enter_scope();
    Obj head = {0}, *cur = &head;
    for (Type *p = ty->params; p; p = p->next) {
        if (!p->pname) err("parameter name omitted");
        Obj *v = new_obj(p->pname, p->pnlen, p); v->is_local = 1; alloc_local(v);
        declare(p->pname, p->pnlen, 0, S_VAR)->var = v; cur = cur->next = v; fn->nparams++;
    }
    fn->params = head.next;
    fn->body = compound_stmt();
    fn->stack_size = align_up(cur_stack, 8);
    leave_scope(); cur_fn = sf; cur_stack = ss;
}
static void toplevel(void) {
    if (consume(";")) return;
    Attr attr; Type *base = declspec(&attr);
    if (consume(";")) return;
    if (attr.is_typedef) {
        for (int first = 1; !eq(";"); first = 0) {
            if (!first) skip(",");
            Token *name = NULL; Type *ty = declarator(base, &name); skip_attrs();
            if (!name) err("typedef name omitted");
            declare(name->str, name->len, 0, S_TYPEDEF)->ty = ty;
        }
        skip(";"); return;
    }
    for (int first = 1;; first = 0) {
        if (!first) skip(",");
        Token *name = NULL; Type *ty = declarator(base, &name); skip_attrs();
        if (!name) err("declaration without a name");
        if (ty->kind == TY_FUNC) {
            if (first && eq("{")) { function_def(name, ty, &attr); return; }
            declare_func(name, ty, &attr);
        } else {
            Obj *o = declare_global(name, ty, &attr);
            if (consume("=")) global_init(o); else if (!attr.is_extern) o->is_tentative = 1;
            o->is_const = is_const_obj(o->ty);
        }
        if (!eq(",")) break;
    }
    skip(";");
}

void cc_reset(void) {
    memset(gtab, 0, sizeof gtab); memset(stab, 0, sizeof stab);
    g_objs = g_tail = NULL; g_funcs = NULL; g_nfuncs = 0; scope = NULL; cur_fn = NULL; cur_stack = 0; uniq = 0; cur_switch = NULL;
}
int cc_compile(SrcFile *files, int n, char *err_out, int errlen) {
    g_files = files; g_nfiles = n; cc_reset();
    if (setjmp(cc_jmp)) { snprintf(err_out, errlen, "%s", g_err); return -1; }
    types_init();
    for (int i = 0; i < n; i++) {
        if (!files[i].unit) continue;
        pp_reset(); Token *t = preprocess_file(&files[i]);
        tk = t; scope = NULL; enter_scope(); cur_fn = NULL;
        while (tk->kind != TK_EOF) toplevel();
        leave_scope(); tarena_free();
    }
    return 0;
}
