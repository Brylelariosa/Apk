/* GBA hardware: IO registers, DMA, direct-sound FIFOs and the PSG/APU mixer. */
#include "gba.h"
#include <math.h>

static u32 vline;
static u8 wavebank[2][16];
static int psg_trig[4];
typedef struct { s8 q[32]; int head, count; s8 cur; int dma_on; u32 src, end; double tacc; } Fifo;
static Fifo fifo[2];
static int out_rate = 32000;

static u32 r16(u32 o) { u16 v; memcpy(&v, g_io + o, 2); return v; }
static void w16(u32 o, u32 v) { u16 x = (u16)v; memcpy(g_io + o, &x, 2); }

int apu_rate(void) { return out_rate; }
void apu_set_rate(int hz) { if (hz >= 8000 && hz <= 96000) out_rate = hz; }
static void psg_reset(void);
void hw_reset(void) {
    vline = 0; memset(wavebank, 0, sizeof wavebank); memset(psg_trig, 0, sizeof psg_trig); memset(fifo, 0, sizeof fifo);
    psg_reset();
}

/* ---------- direct sound ---------- */
static void fifo_push(Fifo *f, u32 w) { for (int i = 0; i < 4; i++) { if (f->count < 32) { f->q[(f->head + f->count) & 31] = (s8)(w >> (8 * i)); f->count++; } } }
/* End of the global array that contains guest address a (0xFFFFFFFF if a is not inside one). A sound effect that is
   streamed by DMA is followed in memory by whatever array happens to come next; real code stops the DMA in time, but the
   frame-based stop used by games is only accurate to a frame, so the player feeds silence once the array is used up
   instead of playing the start of an unrelated sound. */
static u32 array_end(u32 a) {
    for (Obj *o = g_objs; o; o = o->gnext) {
        if (o->is_func) continue;
        u32 size = (u32)(o->ty->size > o->imglen ? o->ty->size : o->imglen); if (size == 0) size = 4;
        if (a >= o->addr && a - o->addr < size) return o->addr + size;
    }
    return 0xFFFFFFFFu;
}
static void fifo_refill(Fifo *f) { while (f->dma_on && f->count <= 16) { for (int i = 0; i < 4; i++) { fifo_push(f, f->src < f->end ? rd32(f->src) : 0); f->src += 4; } break; } }
static void fifo_pop(Fifo *f) {
    if (f->count) { f->cur = f->q[f->head]; f->head = (f->head + 1) & 31; f->count--; }
    if (f->dma_on && f->count <= 16) fifo_refill(f);
}

/* ---------- DMA ---------- */
static void dma_start(int n) {
    u32 base = 0xB0 + 12 * n; u32 ctl = r16(base + 10);
    u32 src, dst; memcpy(&src, g_io + base, 4); memcpy(&dst, g_io + base + 4, 4);
    u32 cnt = r16(base + 8); int timing = (ctl >> 12) & 3;
    if ((n == 1 || n == 2) && timing == 3) {
        Fifo *f = &fifo[(dst & 4) ? 1 : 0]; f->dma_on = 1; f->src = src; f->end = array_end(src);
        while (f->count <= 16 && f->dma_on) fifo_refill(f);
        return;
    }
    if (timing != 0) return;
    if (cnt == 0) cnt = (n == 3) ? 0x10000 : 0x4000;
    int unit = (ctl & 0x400) ? 4 : 2; int sa = (ctl >> 7) & 3, da = (ctl >> 5) & 3;
    int sstep = sa == 0 ? unit : sa == 1 ? -unit : 0, dstep = (da == 0 || da == 3) ? unit : da == 1 ? -unit : 0;
    u32 s = src, d = dst;
    for (u32 i = 0; i < cnt; i++) {
        if (unit == 4) wr32(d, rd32(s)); else wr16(d, rd16(s));
        s += sstep; d += dstep;
    }
    w16(base + 10, ctl & ~0x8000u);
}

/* ---------- IO ---------- */
static void io_w16(u32 o, u32 v) {
    if (o == 0x202) { w16(o, r16(o) & ~v); return; }                  /* IF: write 1 to acknowledge */
    if (o >= 0x90 && o < 0xA0) { int bank = ((r16(0x70) >> 6) & 1) ^ 1; wavebank[bank][o - 0x90] = (u8)v; wavebank[bank][o - 0x90 + 1] = (u8)(v >> 8); w16(o, v); return; }
    if (o == 0xA0 || o == 0xA2 || o == 0xA4 || o == 0xA6) { Fifo *f = &fifo[o >= 0xA4]; for (int i = 0; i < 2; i++) { if (f->count < 32) { f->q[(f->head + f->count) & 31] = (s8)(v >> (8 * i)); f->count++; } } return; }
    if (o == 0x82) {
        if (v & 0x0800) { fifo[0].count = fifo[0].head = 0; fifo[0].cur = 0; }
        if (v & 0x8000) { fifo[1].count = fifo[1].head = 0; fifo[1].cur = 0; }
        v &= ~0x8800u;
    }
    w16(o, v);
    switch (o) {
    case 0x64: if (v & 0x8000) psg_trig[0] = 1; break;
    case 0x6C: if (v & 0x8000) psg_trig[1] = 1; break;
    case 0x74: if (v & 0x8000) psg_trig[2] = 1; break;
    case 0x7C: if (v & 0x8000) psg_trig[3] = 1; break;
    case 0xBA: case 0xC6: case 0xD2: case 0xDE: {
        int n = (o - 0xBA) / 12;
        if (v & 0x8000) dma_start(n);
        else if (n == 1 || n == 2) { u32 dst; memcpy(&dst, g_io + 0xB0 + 12 * n + 4, 4); fifo[(dst & 4) ? 1 : 0].dma_on = 0; }
        break;
    }
    default: break;
    }
}
void io_write(u32 off, u32 v, int size) {
    if (size == 4) { io_w16(off, v & 0xFFFF); io_w16(off + 2, v >> 16); }
    else if (size == 2) io_w16(off, v);
    else { u32 o = off & ~1u; u32 cur = r16(o); if (off & 1) cur = (cur & 0x00FF) | (v << 8); else cur = (cur & 0xFF00) | v; io_w16(o, cur); }
}
static u32 io_r16(u32 o) {
    switch (o) {
    case 0x04: return (r16(0x04) & ~7u) | (vline >= 160 && vline < 227 ? 1 : 0) | (((vline & 0xFF) == (r16(0x04) >> 8)) ? 4 : 0);
    case 0x06: { u32 v = vline; vline = (vline + 37) % 228; return v; }
    case 0x130: return ~g_keys & 0x3FF;
    default: return r16(o);
    }
}
u32 io_read(u32 off, int size) {
    if (size == 4) return io_r16(off) | (io_r16(off + 2) << 16);
    if (size == 2) return io_r16(off);
    return (io_r16(off & ~1u) >> ((off & 1) * 8)) & 0xFF;
}

/* ---------- PSG ---------- */
typedef struct { int on, len, lenen, vol, dir, period, ecnt; double ph; u32 lfsr; int swp, swc, sws, swd; int shadow; } Ch;
static Ch ch[4];
static double seq_acc; static int seq_step;
static const u8 duty_tab[4][8] = { {0,0,0,0,0,0,0,1}, {1,0,0,0,0,0,0,1}, {1,0,0,0,0,1,1,1}, {0,1,1,1,1,1,1,0} };

static void env_load(Ch *c, u32 reg) { c->vol = reg >> 12; c->dir = (reg >> 11) & 1; c->period = (reg >> 8) & 7; c->ecnt = c->period; }
static void apply_triggers(void) {
    for (int i = 0; i < 4; i++) {
        if (!psg_trig[i]) continue; psg_trig[i] = 0; Ch *c = &ch[i];
        c->on = 1; c->ph = 0;
        if (i == 0) { env_load(c, r16(0x62)); c->len = 64 - (r16(0x62) & 63); c->lenen = (r16(0x64) >> 14) & 1; u32 sw = r16(0x60); c->sws = sw & 7; c->swd = (sw >> 3) & 1; c->swp = (sw >> 4) & 7; c->swc = c->swp; c->shadow = r16(0x64) & 0x7FF; }
        else if (i == 1) { env_load(c, r16(0x68)); c->len = 64 - (r16(0x68) & 63); c->lenen = (r16(0x6C) >> 14) & 1; }
        else if (i == 2) { c->len = 256 - (r16(0x72) & 255); c->lenen = (r16(0x74) >> 14) & 1; if (!((r16(0x70) >> 7) & 1)) c->on = 0; }
        else { env_load(c, r16(0x78)); c->len = 64 - (r16(0x78) & 63); c->lenen = (r16(0x7C) >> 14) & 1; c->lfsr = 0x7FFF; }
    }
}
static void seq_tick(void) {
    seq_step = (seq_step + 1) & 7;
    if (!(seq_step & 1)) for (int i = 0; i < 4; i++) if (ch[i].lenen && ch[i].len > 0 && --ch[i].len == 0) ch[i].on = 0;
    if (seq_step == 7) for (int i = 0; i < 4; i++) { Ch *c = &ch[i]; if (i == 2 || !c->on || !c->period) continue; if (--c->ecnt <= 0) { c->ecnt = c->period; if (c->dir && c->vol < 15) c->vol++; else if (!c->dir && c->vol > 0) c->vol--; } }
    if ((seq_step == 2 || seq_step == 6) && ch[0].on && ch[0].swp && ch[0].sws) {
        Ch *c = &ch[0];
        if (--c->swc <= 0) {
            c->swc = c->swp; int d = c->shadow >> c->sws; int nf = c->swd ? c->shadow - d : c->shadow + d;
            if (nf > 2047) c->on = 0; else if (nf >= 0) { c->shadow = nf; w16(0x64, (r16(0x64) & ~0x7FFu) | nf); }
        }
    }
}

/* The four tone channels (squares, wave, noise) are plain staircase waveforms. Sampling those directly at the output
   rate folds everything above half the sample rate back into the audible range as harsh, inharmonic "screech", so they
   are generated PSG_OS times faster and low-pass filtered down (windowed-sinc FIR) before mixing with the sample channels. */
#define PSG_OS 4
#define FIR_TAPS 97     /* odd, and (taps-1)/2 is a multiple of PSG_OS: the filter delay is a whole number (12) of output samples */
#define HIST_MASK 127
static double fir_h[FIR_TAPS]; static int fir_rate;
static double hist_l[HIST_MASK + 1], hist_r[HIST_MASK + 1]; static unsigned hist_pos;
static double noise_acc;

static void fir_design(void) {
    const double PI = 3.14159265358979323846;
    double fc = 0.46 / PSG_OS;                       /* cutoff as a fraction of the oversampled rate: 0.46 x output rate */
    int M = (FIR_TAPS - 1) / 2; double sum = 0;
    for (int k = 0; k < FIR_TAPS; k++) {
        double x = k - M, sinc = x == 0 ? 2 * fc : sin(2 * PI * fc * x) / (PI * x);
        double w = 0.42 - 0.5 * cos(2 * PI * k / (FIR_TAPS - 1)) + 0.08 * cos(4 * PI * k / (FIR_TAPS - 1));   /* Blackman */
        fir_h[k] = sinc * w; sum += fir_h[k];
    }
    for (int k = 0; k < FIR_TAPS; k++) fir_h[k] /= sum;
    fir_rate = out_rate;
}

/* power-on state of the tone channels and of the filter that follows them (a game restart must not leave a tone hanging) */
static void psg_reset(void) {
    memset(ch, 0, sizeof ch); seq_acc = 0; seq_step = 0; noise_acc = 0;
    memset(hist_l, 0, sizeof hist_l); memset(hist_r, 0, sizeof hist_r); hist_pos = 0;
}

void apu_frame(s16 *out, int ns) {
    apply_triggers();
    if (fir_rate != out_rate) fir_design();
    u32 cntl = r16(0x80), cnth = r16(0x82), cntx = r16(0x84);
    int master = (cntx >> 7) & 1;
    double psg_ratio = (cnth & 3) == 0 ? 0.25 : (cnth & 3) == 1 ? 0.5 : 1.0;
    double volr = ((cntl & 7) + 1) / 8.0, voll = (((cntl >> 4) & 7) + 1) / 8.0;
    double dsvol[2] = { (cnth & 4) ? 1.0 : 0.5, (cnth & 8) ? 1.0 : 0.5 };
    int dsr[2] = { (cnth >> 8) & 1, (cnth >> 12) & 1 }, dsl[2] = { (cnth >> 9) & 1, (cnth >> 13) & 1 };
    int dstim[2] = { (cnth >> 10) & 1, (cnth >> 14) & 1 };
    double trate[2];
    for (int i = 0; i < 2; i++) {
        u32 rel = r16(0x100 + dstim[i] * 4), ctl = r16(0x102 + dstim[i] * 4);
        static const int pre[4] = { 1, 64, 256, 1024 };
        trate[i] = (ctl & 0x80) ? 16777216.0 / ((double)(0x10000 - rel) * pre[ctl & 3]) : 0.0;
    }
    int f1 = r16(0x64) & 0x7FF, f2 = r16(0x6C) & 0x7FF, f3 = r16(0x74) & 0x7FF;
    int d1 = (r16(0x62) >> 6) & 3, d2 = (r16(0x68) >> 6) & 3;
    u32 wc = r16(0x70), wh = r16(0x72); int wvol = (wh >> 13) & 3; double wmul = (wh & 0x8000) ? 0.75 : wvol == 0 ? 0 : wvol == 1 ? 1.0 : wvol == 2 ? 0.5 : 0.25;
    int wbank = (wc >> 6) & 1, w64 = (wc >> 5) & 1;
    u32 nr = r16(0x7C); int nr_r = nr & 7, nr_s = (nr >> 4) & 15, nr_w = (nr >> 3) & 1;
    double nfreq = 524288.0 / (nr_r ? nr_r : 0.5) / (double)(1u << (nr_s + 1 > 30 ? 30 : nr_s + 1));
    const double osr = (double)out_rate * PSG_OS;
    for (int i = 0; i < ns; i++) {
        seq_acc += 512.0 / out_rate; if (seq_acc >= 1) { seq_acc -= 1; seq_tick(); }
        for (int j = 0; j < PSG_OS; j++) {
            double v[4] = {0, 0, 0, 0};
            if (ch[0].on) { ch[0].ph += (131072.0 / (2048 - (ch[0].swp && ch[0].sws ? ch[0].shadow : f1))) / osr; ch[0].ph -= floor(ch[0].ph); v[0] = duty_tab[d1][(int)(ch[0].ph * 8) & 7] ? ch[0].vol : -ch[0].vol; }
            if (ch[1].on) { ch[1].ph += (131072.0 / (2048 - f2)) / osr; ch[1].ph -= floor(ch[1].ph); v[1] = duty_tab[d2][(int)(ch[1].ph * 8) & 7] ? ch[1].vol : -ch[1].vol; }
            if (ch[2].on && ((wc >> 7) & 1)) {
                ch[2].ph += (65536.0 / (2048 - f3)) / osr * (w64 ? 0.5 : 1.0); ch[2].ph -= floor(ch[2].ph);
                int pos = (int)(ch[2].ph * (w64 ? 64 : 32)) & (w64 ? 63 : 31);
                const u8 *bank = wavebank[w64 ? (pos >> 5) : wbank]; int p = pos & 31; int nib = (p & 1) ? (bank[p >> 1] & 15) : (bank[p >> 1] >> 4);
                v[2] = (nib * 2 - 15) * wmul;
            }
            if (ch[3].on) {
                noise_acc += nfreq / osr;
                while (noise_acc >= 1) { noise_acc -= 1; u32 x = (ch[3].lfsr & 1) ^ ((ch[3].lfsr >> 1) & 1); ch[3].lfsr = (ch[3].lfsr >> 1) | (x << 14); if (nr_w) ch[3].lfsr = (ch[3].lfsr & ~0x40u) | (x << 6); }
                v[3] = (ch[3].lfsr & 1) ? -ch[3].vol : ch[3].vol;
            }
            double sl = 0, sr = 0;
            for (int c = 0; c < 4; c++) { if ((cntl >> (12 + c)) & 1) sl += v[c]; if ((cntl >> (8 + c)) & 1) sr += v[c]; }
            hist_l[hist_pos & HIST_MASK] = sl; hist_r[hist_pos & HIST_MASK] = sr; hist_pos++;
        }
        double pl = 0, pr = 0;   /* low-pass and drop to the output rate */
        for (int k = 0; k < FIR_TAPS; k++) { unsigned at = (hist_pos - 1 - k) & HIST_MASK; pl += fir_h[k] * hist_l[at]; pr += fir_h[k] * hist_r[at]; }
        double L = pl / 60.0 * voll * psg_ratio * 1.3, R = pr / 60.0 * volr * psg_ratio * 1.3;
        for (int k = 0; k < 2; k++) {
            if (trate[k] > 0) { fifo[k].tacc += trate[k] / out_rate; while (fifo[k].tacc >= 1) { fifo[k].tacc -= 1; fifo_pop(&fifo[k]); } }
            double s = fifo[k].cur / 128.0 * dsvol[k] * 0.6;
            if (dsl[k]) L += s; if (dsr[k]) R += s;
        }
        if (!master) L = R = 0;
        L *= 0.7; R *= 0.7;
        int li = (int)(L * 32767), ri = (int)(R * 32767);
        out[i * 2] = (s16)(li > 32767 ? 32767 : li < -32768 ? -32768 : li); out[i * 2 + 1] = (s16)(ri > 32767 ? 32767 : ri < -32768 ? -32768 : ri);
    }
}
void hw_frame_end(void) {}
