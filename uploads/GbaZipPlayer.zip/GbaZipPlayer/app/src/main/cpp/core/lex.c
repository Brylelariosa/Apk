/* Tokenizer + C preprocessor. */
#include "gba.h"
#include <ctype.h>
#include <setjmp.h>

char g_err[600];
jmp_buf cc_jmp;
SrcFile *g_files; int g_nfiles;

/* ---------- arena ---------- */
typedef struct Chunk { struct Chunk *next; size_t used, cap, pad; } Chunk;
static Chunk *chunks;
void *xalloc(size_t n) {
    n = (n + 15) & ~(size_t)15;
    if (!chunks || chunks->used + n > chunks->cap) {
        size_t cap = n > (1u << 20) ? n : (1u << 20);
        Chunk *c = calloc(1, sizeof(Chunk) + cap);
        if (!c) { snprintf(g_err, sizeof g_err, "out of memory"); longjmp(cc_jmp, 1); }
        c->cap = cap; c->next = chunks; chunks = c;
    }
    void *p = (u8 *)(chunks + 1) + chunks->used;
    chunks->used += n;
    return p;
}
static Chunk *tchunks;
void *talloc(size_t n) {
    n = (n + 15) & ~(size_t)15;
    if (!tchunks || tchunks->used + n > tchunks->cap) {
        size_t cap = n > (1u << 20) ? n : (1u << 20);
        Chunk *c = calloc(1, sizeof(Chunk) + cap);
        if (!c) { snprintf(g_err, sizeof g_err, "out of memory"); longjmp(cc_jmp, 1); }
        c->cap = cap; c->next = tchunks; tchunks = c;
    }
    void *p = (u8 *)(tchunks + 1) + tchunks->used;
    tchunks->used += n;
    return p;
}
void tarena_free(void) { while (tchunks) { Chunk *n = tchunks->next; free(tchunks); tchunks = n; } }
void arena_free_all(void) { while (chunks) { Chunk *n = chunks->next; free(chunks); chunks = n; } tarena_free(); }
char *tstrndup(const char *s, int n) { char *p = talloc(n + 1); memcpy(p, s, n); return p; }
char *xstrndup(const char *s, int n) { char *p = xalloc(n + 1); memcpy(p, s, n); return p; }

void cc_error(const char *file, int line, const char *fmt, ...) {
    int n = snprintf(g_err, sizeof g_err, "%s:%d: ", file ? file : "?", line);
    va_list ap; va_start(ap, fmt); vsnprintf(g_err + n, sizeof g_err - n, fmt, ap); va_end(ap);
    longjmp(cc_jmp, 1);
}

int tok_is(Token *t, const char *s) {
    size_t l = strlen(s);
    return (t->kind == TK_PUNCT || t->kind == TK_IDENT) && (size_t)t->len == l && !memcmp(t->str, s, l);
}

/* ---------- tokenizer ---------- */
static int ishex(int c) { return isxdigit(c); }
static int read_escape(const char **pp) {
    const char *p = *pp; int c = *p++;
    switch (c) {
    case 'n': c = 10; break; case 't': c = 9; break; case 'r': c = 13; break; case 'a': c = 7; break;
    case 'b': c = 8; break; case 'f': c = 12; break; case 'v': c = 11; break; case 'e': c = 27; break;
    case 'x': { int v = 0; while (ishex(*p)) { v = v * 16 + (isdigit(*p) ? *p - '0' : (tolower(*p) - 'a' + 10)); p++; } c = v & 0xFF; break; }
    default:
        if (c >= '0' && c <= '7') { int v = c - '0'; for (int i = 0; i < 2 && *p >= '0' && *p <= '7'; i++) v = v * 8 + (*p++ - '0'); c = v & 0xFF; }
    }
    *pp = p; return c;
}


/* Long runs of "number ," (typical of generated data tables) are folded into a single TK_NUMLIST token. */
static int chain_num(const char **pp, s32 *out, u8 *fl) {
    const char *p = *pp; int neg = 0;
    if (*p == '-') { neg = 1; p++; while (*p == ' ') p++; }
    if (!isdigit((u8)*p)) return 0;
    u32 v = 0; int base = 10;
    if (p[0] == '0' && (p[1] == 'x' || p[1] == 'X')) { base = 16; p += 2; }
    else if (p[0] == '0' && (p[1] == 'b' || p[1] == 'B')) { base = 2; p += 2; }
    else if (p[0] == '0' && isdigit((u8)p[1])) { base = 8; p++; }
    const char *ds = p;
    for (;; p++) {
        int d;
        if (isdigit((u8)*p)) d = *p - '0'; else if (base == 16 && isxdigit((u8)*p)) d = tolower(*p) - 'a' + 10; else break;
        if (d >= base) return 0;
        v = v * base + d;
    }
    if (p == ds && base != 8) return 0;
    int u = 0;
    if (*p == 'u' || *p == 'U') { u = 1; p++; }
    if (isalnum((u8)*p) || *p == '.' || *p == '_') return 0;
    *out = neg ? (s32)(0u - v) : (s32)v; *fl = (u8)(neg ? 0 : (u || v > 0x7FFFFFFFu));
    *pp = p; return 1;
}
static Token *try_numlist(const char **pp, int *line, Token *tmpl) {
    const char *p = *pp; int ln = *line, n = 0;
    s32 *vals = NULL; u8 *fls = NULL; int cap = 0;
    const char *good = p; int good_line = ln;
    for (;;) {
        s32 v; u8 f; const char *q = p;
        if (!chain_num(&q, &v, &f)) break;
        while (*q == ' ' || *q == '\t' || *q == '\r' || *q == '\n') q++;
        if (*q != ',') break;
        const char *r = q + 1; int l2 = ln;
        for (const char *c = p; c < r; c++) if (*c == '\n') l2++;
        while (*r == ' ' || *r == '\t' || *r == '\r' || *r == '\n') { if (*r == '\n') l2++; r++; }
        if (n == cap) { int nc = cap ? cap * 2 : 64; s32 *nv = talloc(nc * sizeof(s32)); u8 *nf = talloc(nc); if (n) { memcpy(nv, vals, n * sizeof(s32)); memcpy(nf, fls, n); } vals = nv; fls = nf; cap = nc; }
        vals[n] = v; fls[n] = f; n++;
        good = r; good_line = l2; p = r; ln = l2;
    }
    if (n < 12) return NULL;
    tmpl->kind = TK_NUMLIST; tmpl->sval = (u8 *)vals; tmpl->slen = n; tmpl->str = (char *)fls; tmpl->len = n;
    *pp = good; *line = good_line;
    return tmpl;
}

static const char *puncts[] = { "<<=", ">>=", "...", "==", "!=", "<=", ">=", "->", "+=", "-=", "*=", "/=", "++", "--", "%=", "&=", "|=", "^=", "&&", "||", "<<", ">>", "##", NULL };

Token *tokenize(SrcFile *f) {
    const char *p = f->data; int line = 1, bol = 1, sp = 0;
    Token head = {0}, *cur = &head;
    while (*p) {
        if (p[0] == '\\' && (p[1] == '\n' || (p[1] == '\r' && p[2] == '\n'))) { p += (p[1] == '\n') ? 2 : 3; line++; continue; }
        if (*p == '\n') { p++; line++; bol = 1; sp = 0; continue; }
        if (isspace((u8)*p)) { p++; sp = 1; continue; }
        if (p[0] == '/' && p[1] == '/') { while (*p && *p != '\n') p++; continue; }
        if (p[0] == '/' && p[1] == '*') {
            const char *q = strstr(p + 2, "*/");
            if (!q) cc_error(f->path, line, "unterminated comment");
            for (const char *c = p; c < q; c++) if (*c == '\n') line++;
            p = q + 2; sp = 1; continue;
        }
        Token *t = talloc(sizeof(Token));
        t->file = f->path; t->line = line; t->bol = bol; t->sp = sp; bol = 0; sp = 0;
        cur = cur->next = t;
        if (isdigit((u8)*p) || (*p == '-' && cur != &head && (tok_is(cur, ",") || tok_is(cur, "{")) && (isdigit((u8)p[1]) || (p[1] == ' ' && isdigit((u8)p[2]))))) {
            const char *np = p; int nl = line;
            if (try_numlist(&np, &nl, t)) { p = np; line = nl; continue; }
        }
        if (isdigit((u8)*p) || (*p == '.' && isdigit((u8)p[1]))) {
            const char *s = p; p++;
            while (isalnum((u8)*p) || *p == '.' || *p == '_' || ((*p == '+' || *p == '-') && strchr("eEpP", p[-1]) && !(s[0]=='0' && (s[1]=='x'||s[1]=='X') ? 0 : 0))) p++;
            t->kind = TK_NUM; t->str = (char *)s; t->len = (int)(p - s);
            int hex = (s[0] == '0' && (s[1] == 'x' || s[1] == 'X'));
            int isf = 0;
            for (const char *c = s; c < p; c++) if (*c == '.' || (!hex && (*c == 'e' || *c == 'E')) ) isf = 1;
            if (isf) { t->uns = 2; continue; }
            u32 v = 0; const char *c = s; int base = 10;
            if (hex) { base = 16; c += 2; } else if (s[0] == '0' && (s[1] == 'b' || s[1] == 'B')) { base = 2; c += 2; } else if (s[0] == '0' && p - s > 1) { base = 8; c++; }
            u32 prev = 0; int ovf = 0;
            for (; c < p; c++) {
                int d;
                if (isdigit((u8)*c)) d = *c - '0'; else if (isalpha((u8)*c) && base == 16 && tolower(*c) <= 'f') d = tolower(*c) - 'a' + 10; else break;
                if (d >= base) cc_error(f->path, line, "bad digit in number");
                prev = v; v = v * base + d; if (v / base != prev && base != 16) ovf = 1;
            }
            int u = 0, l = 0;
            for (; c < p; c++) { if (*c == 'u' || *c == 'U') u = 1; else if (*c == 'l' || *c == 'L') l++; else cc_error(f->path, line, "bad number suffix"); }
            (void)ovf; (void)l;
            t->val = (s32)v; t->uns = (u || v > 0x7FFFFFFFu) ? 1 : 0;
            continue;
        }
        if (*p == '"') {
            p++; u8 *buf = talloc(strlen(p) < 4096 ? strlen(p) + 1 : 4096 + 1); int n = 0; int cap = 0; (void)cap;
            /* size by scanning to the closing quote first */
            const char *q = p; while (*q && *q != '"') { if (*q == '\\' && q[1]) q++; q++; }
            if (*q != '"') cc_error(f->path, line, "unterminated string");
            buf = talloc((size_t)(q - p) + 1);
            while (p < q) { if (*p == '\\') { p++; buf[n++] = (u8)read_escape(&p); } else buf[n++] = (u8)*p++; }
            p++;
            t->kind = TK_STR; t->sval = buf; t->slen = n; continue;
        }
        if (*p == '\'') {
            p++; int v;
            if (*p == '\\') { p++; v = read_escape(&p); } else v = (u8)*p++;
            if (*p != '\'') cc_error(f->path, line, "bad character literal");
            p++; t->kind = TK_NUM; t->val = v; t->str = "'"; t->len = 1; continue;
        }
        if (isalpha((u8)*p) || *p == '_' || *p == '$') {
            const char *s = p; while (isalnum((u8)*p) || *p == '_' || *p == '$') p++;
            t->kind = TK_IDENT; t->str = (char *)s; t->len = (int)(p - s); continue;
        }
        t->kind = TK_PUNCT; t->str = (char *)p; t->len = 1;
        for (int i = 0; puncts[i]; i++) { size_t l = strlen(puncts[i]); if (!strncmp(p, puncts[i], l)) { t->len = (int)l; break; } }
        if (!strchr("+-*/%&|^~!<>=?:;,.()[]{}#", *p) && t->len == 1) cc_error(f->path, line, "unexpected character '%c'", *p);
        p += t->len;
    }
    Token *e = talloc(sizeof(Token));
    e->kind = TK_EOF; e->file = f->path; e->line = line; e->bol = 1; cur->next = e;
    return head.next;
}

/* ---------- virtual system headers ---------- */
static const char *sys_names[] = { "stdint.h", "stddef.h", "stdbool.h", "string.h", "stdlib.h", "stdio.h", "limits.h", NULL };
static const char *sys_text[] = {
    "#ifndef _STDINT_H\n#define _STDINT_H\ntypedef signed char int8_t; typedef unsigned char uint8_t; typedef short int16_t; typedef unsigned short uint16_t;\n"
    "typedef int int32_t; typedef unsigned int uint32_t; typedef unsigned int uintptr_t; typedef int intptr_t; typedef unsigned int size_t; typedef int ptrdiff_t;\n#endif\n",
    "#ifndef _STDDEF_H\n#define _STDDEF_H\n#define NULL ((void*)0)\ntypedef unsigned int size_t; typedef int ptrdiff_t;\n#endif\n",
    "#ifndef _STDBOOL_H\n#define _STDBOOL_H\n#define bool _Bool\n#define true 1\n#define false 0\n#endif\n",
    "#ifndef _STRING_H\n#define _STRING_H\n#define NULL ((void*)0)\ntypedef unsigned int size_t;\nvoid *memcpy(void *d, const void *s, size_t n); void *memmove(void *d, const void *s, size_t n); void *memset(void *d, int c, size_t n);\n"
    "int memcmp(const void *a, const void *b, size_t n); size_t strlen(const char *s); int strcmp(const char *a, const char *b); char *strcpy(char *d, const char *s);\n#endif\n",
    "#ifndef _STDLIB_H\n#define _STDLIB_H\n#define NULL ((void*)0)\ntypedef unsigned int size_t;\nint abs(int x);\n#endif\n",
    "#ifndef _STDIO_H\n#define _STDIO_H\n#define NULL ((void*)0)\n#endif\n",
    "#ifndef _LIMITS_H\n#define _LIMITS_H\n#define CHAR_BIT 8\n#define INT_MAX 2147483647\n#define INT_MIN (-2147483647-1)\n#define UINT_MAX 4294967295u\n#define SHRT_MAX 32767\n#define USHRT_MAX 65535\n#define UCHAR_MAX 255\n#endif\n",
};

static char *dir_of(const char *path, char *buf) {
    const char *s = strrchr(path, '/');
    if (!s) buf[0] = 0; else { memcpy(buf, path, s - path); buf[s - path] = 0; }
    return buf;
}
static void normalize(char *p) {  /* collapse "a/../b" and "./" */
    char *out = p, *in = p; char *segs[64]; int n = 0;
    char *copy = strdup(p); char *tok = strtok(copy, "/");
    while (tok && n < 64) {
        if (!strcmp(tok, ".") || !*tok) {} else if (!strcmp(tok, "..")) { if (n) n--; } else segs[n++] = tok;
        tok = strtok(NULL, "/");
    }
    (void)in; out = p;
    for (int i = 0; i < n; i++) { size_t l = strlen(segs[i]); if (i) *out++ = '/'; memmove(out, segs[i], l); out += l; }
    *out = 0; free(copy);
}
SrcFile *find_file(const char *path) {
    for (int i = 0; i < g_nfiles; i++) if (!strcmp(g_files[i].path, path)) return &g_files[i];
    return NULL;
}
static SrcFile *find_include(const char *name, int sys, const char *from) {
    if (sys) {
        for (int i = 0; sys_names[i]; i++) if (!strcmp(sys_names[i], name)) {
            SrcFile *f = talloc(sizeof(SrcFile)); f->path = (char *)sys_names[i]; f->data = (char *)sys_text[i]; f->len = (int)strlen(sys_text[i]); return f;
        }
    }
    char buf[600], d[600];
    snprintf(buf, sizeof buf, "%s%s%s", dir_of(from, d), d[0] ? "/" : "", name);
    normalize(buf);
    SrcFile *f = find_file(buf);
    if (f) return f;
    size_t nl = strlen(name);
    for (int i = 0; i < g_nfiles; i++) {
        size_t pl = strlen(g_files[i].path);
        if (pl >= nl && !strcmp(g_files[i].path + pl - nl, name) && (pl == nl || g_files[i].path[pl - nl - 1] == '/')) return &g_files[i];
    }
    return NULL;
}

/* ---------- preprocessor ---------- */
typedef struct Macro Macro;
struct Macro { Macro *next; char *name; int len, is_func, va, nparams, disabled, deleted; Token **params; Token *body; };
#define MHASH 2048
static Macro *mtab[MHASH];
static unsigned hash_str(const char *s, int n) { unsigned h = 5381; while (n--) h = h * 33 + (u8)*s++; return h; }
void pp_reset(void) { memset(mtab, 0, sizeof mtab); }
static Macro *find_macro(Token *t) {
    for (Macro *m = mtab[hash_str(t->str, t->len) % MHASH]; m; m = m->next)
        if (m->len == t->len && !memcmp(m->name, t->str, t->len)) return m->deleted ? NULL : m;
    return NULL;
}
static Macro *add_macro(Token *name) {
    Macro *m = talloc(sizeof(Macro)); m->name = tstrndup(name->str, name->len); m->len = name->len;
    unsigned h = hash_str(name->str, name->len) % MHASH; m->next = mtab[h]; mtab[h] = m; return m;
}
static Token *copy_tok(Token *t) { Token *n = talloc(sizeof(Token)); *n = *t; n->next = NULL; return n; }
static Token *new_eof(Token *like) { Token *e = talloc(sizeof(Token)); e->kind = TK_EOF; e->file = like->file; e->line = like->line; return e; }

static Token *expand(Token *in);

typedef struct { Token *head, *tail; } List;
static void lpush(List *l, Token *t) { if (l->tail) l->tail->next = t; else l->head = t; l->tail = t; t->next = NULL; }

static int param_index(Macro *m, Token *t) {
    if (t->kind != TK_IDENT) return -1;
    for (int i = 0; i < m->nparams; i++) if (m->params[i]->len == t->len && !memcmp(m->params[i]->str, t->str, t->len)) return i;
    if (m->va && t->len == 11 && !memcmp(t->str, "__VA_ARGS__", 11)) return m->nparams;
    return -1;
}

static Token *paste(Token *a, Token *b, Token *at) {
    char buf[300]; int n = 0;
    if (a->kind == TK_STR || b->kind == TK_STR) cc_error(at->file, at->line, "cannot paste strings");
    if (a->len + b->len >= 299) cc_error(at->file, at->line, "paste too long");
    memcpy(buf, a->str, a->len); n = a->len; memcpy(buf + n, b->str, b->len); n += b->len; buf[n] = 0;
    SrcFile tmp = { (char *)at->file, tstrndup(buf, n), n };
    Token *t = tokenize(&tmp);
    t->line = at->line; t->sp = a->sp; t->bol = 0;
    return t;
}

static char *spell(Token *t) {
    if (t->kind == TK_STR) {
        char *s = talloc(t->slen * 2 + 3); int n = 0; s[n++] = '"';
        for (int i = 0; i < t->slen; i++) { if (t->sval[i] == '"' || t->sval[i] == '\\') s[n++] = '\\'; s[n++] = (char)t->sval[i]; }
        s[n++] = '"'; return s;
    }
    return tstrndup(t->str, t->len);
}

static Token **collect_args(Macro *m, Token *lp, Token **rest) {
    int np = m->nparams + (m->va ? 1 : 0);
    Token **args = talloc(sizeof(Token *) * (np + 1));
    Token *t = lp->next; int idx = 0;
    List cur = {0};
    int depth = 0;
    for (;;) {
        if (t->kind == TK_EOF) cc_error(lp->file, lp->line, "unterminated macro call");
        if (depth == 0 && tok_is(t, ")")) break;
        if (depth == 0 && tok_is(t, ",") && !(m->va && idx >= m->nparams)) {
            lpush(&cur, new_eof(t)); if (idx < np) args[idx] = cur.head; idx++; cur.head = cur.tail = NULL; t = t->next; continue;
        }
        if (tok_is(t, "(")) depth++; else if (tok_is(t, ")")) depth--;
        lpush(&cur, copy_tok(t)); t = t->next;
    }
    lpush(&cur, new_eof(t)); if (idx < np) args[idx] = cur.head; idx++;
    for (int i = 0; i < np; i++) if (!args[i]) args[i] = new_eof(lp);
    if (m->nparams == 0 && !m->va) idx = 0;
    if (idx < m->nparams) cc_error(lp->file, lp->line, "too few macro arguments for %s", m->name);
    *rest = t->next;
    return args;
}

static Token *subst(Macro *m, Token **args, Token *call) {
    List out = {0};
    for (Token *b = m->body; b->kind != TK_EOF; b = b->next) {
        if (tok_is(b, "#") && b->next->kind != TK_EOF && param_index(m, b->next) >= 0) {
            int pi = param_index(m, b->next); char buf[1024]; int n = 0; buf[n++] = '"';
            for (Token *a = args[pi]; a->kind != TK_EOF; a = a->next) {
                if (a->sp && n > 1) buf[n++] = ' ';
                char *s = spell(a); size_t l = strlen(s); if (n + l < 1000) { memcpy(buf + n, s, l); n += (int)l; }
            }
            Token *t = talloc(sizeof(Token)); t->kind = TK_STR; t->file = call->file; t->line = call->line;
            t->sval = (u8 *)tstrndup(buf + 1, n - 1); t->slen = n - 1; lpush(&out, t); b = b->next; continue;
        }
        int pi = param_index(m, b);
        if (tok_is(b, "##") && out.tail && b->next->kind != TK_EOF) {
            Token *r = b->next; int rp = param_index(m, r);
            Token *rhs = r; Token *rtail = NULL;
            if (rp >= 0) { rhs = args[rp]->kind == TK_EOF ? NULL : args[rp]; }
            if (rhs) {
                Token *p = paste(out.tail, rhs, call);
                /* replace tail */
                Token *prev = NULL; for (Token *x = out.head; x != out.tail; x = x->next) prev = x;
                Token *pn = p; while (pn->next && pn->next->kind != TK_EOF) pn = pn->next;
                if (prev) prev->next = p; else out.head = p;
                pn->next = NULL; out.tail = pn;
                if (rp >= 0) for (Token *a = args[rp]->next; a->kind != TK_EOF; a = a->next) { Token *c = copy_tok(a); lpush(&out, c); }
            }
            (void)rtail; b = b->next; continue;
        }
        if (pi >= 0) {
            int nextpaste = tok_is(b->next, "##");
            Token *a = nextpaste ? args[pi] : expand(args[pi]);
            int first = 1;
            for (; a->kind != TK_EOF; a = a->next) { Token *c = copy_tok(a); if (first) c->sp = b->sp; first = 0; lpush(&out, c); }
            continue;
        }
        lpush(&out, copy_tok(b));
    }
    lpush(&out, new_eof(call));
    return out.head;
}

static Token *expand(Token *in) {
    List out = {0};
    while (in->kind != TK_EOF) {
        Macro *m = in->kind == TK_IDENT ? find_macro(in) : NULL;
        if (m && !m->disabled) {
            Token *body = NULL, *rest = NULL;
            if (!m->is_func) {
                List b = {0};
                for (Token *x = m->body; x->kind != TK_EOF; x = x->next) { Token *c = copy_tok(x); c->line = in->line; c->file = in->file; lpush(&b, c); }
                lpush(&b, new_eof(in)); body = b.head; rest = in->next;
            } else if (tok_is(in->next, "(")) {
                Token **args = collect_args(m, in->next, &rest);
                body = subst(m, args, in);
            }
            if (body) {
                m->disabled = 1; body = expand(body); m->disabled = 0;
                int first = 1;
                for (Token *x = body; x->kind != TK_EOF; x = x->next) { Token *c = copy_tok(x); if (first) c->sp = in->sp; first = 0; lpush(&out, c); }
                in = rest; continue;
            }
        }
        lpush(&out, copy_tok(in)); in = in->next;
    }
    lpush(&out, new_eof(in));
    return out.head;
}

/* ---- #if expression evaluation ---- */
static Token *pe_t; static const char *pe_file; static int pe_line;
static s32 pe_expr(int minprec);
static s32 pe_prim(void) {
    Token *t = pe_t;
    if (t->kind == TK_NUM) { if (t->uns == 2) cc_error(pe_file, pe_line, "float in #if"); pe_t = t->next; return t->val; }
    if (tok_is(t, "(")) { pe_t = t->next; s32 v = pe_expr(0); if (!tok_is(pe_t, ")")) cc_error(pe_file, pe_line, "expected ) in #if"); pe_t = pe_t->next; return v; }
    if (tok_is(t, "-")) { pe_t = t->next; return -pe_prim(); }
    if (tok_is(t, "+")) { pe_t = t->next; return pe_prim(); }
    if (tok_is(t, "!")) { pe_t = t->next; return !pe_prim(); }
    if (tok_is(t, "~")) { pe_t = t->next; return ~pe_prim(); }
    if (t->kind == TK_IDENT) { pe_t = t->next; return 0; }
    cc_error(pe_file, pe_line, "bad #if expression");
    return 0;
}
static int binprec(Token *t) {
    if (t->kind != TK_PUNCT) return -1;
    static const struct { const char *s; int p; } tb[] = { {"||",1},{"&&",2},{"|",3},{"^",4},{"&",5},{"==",6},{"!=",6},{"<",7},{">",7},{"<=",7},{">=",7},{"<<",8},{">>",8},{"+",9},{"-",9},{"*",10},{"/",10},{"%",10},{NULL,0} };
    for (int i = 0; tb[i].s; i++) if (tok_is(t, tb[i].s)) return tb[i].p;
    return -1;
}
static s32 pe_expr(int minprec) {
    s32 l = pe_prim();
    for (;;) {
        Token *op = pe_t;
        if (minprec == 0 && tok_is(op, "?")) {
            pe_t = op->next; s32 a = pe_expr(0);
            if (!tok_is(pe_t, ":")) cc_error(pe_file, pe_line, "expected : in #if");
            pe_t = pe_t->next; s32 b = pe_expr(0); l = l ? a : b; continue;
        }
        int p = binprec(op);
        if (p < 0 || p <= minprec - 0 - (minprec ? 0 : 0) || p < minprec + (minprec ? 0 : 0)) { if (p < 0 || p < minprec || (minprec && p <= minprec - 1 && 0)) break; }
        if (p < 0 || p < minprec) break;
        pe_t = op->next; s32 r = pe_expr(p + 1);
        u32 ul = (u32)l, ur = (u32)r;
        if (tok_is(op, "||")) l = l || r; else if (tok_is(op, "&&")) l = l && r; else if (tok_is(op, "|")) l = l | r;
        else if (tok_is(op, "^")) l = l ^ r; else if (tok_is(op, "&")) l = l & r; else if (tok_is(op, "==")) l = l == r;
        else if (tok_is(op, "!=")) l = l != r; else if (tok_is(op, "<")) l = l < r; else if (tok_is(op, ">")) l = l > r;
        else if (tok_is(op, "<=")) l = l <= r; else if (tok_is(op, ">=")) l = l >= r; else if (tok_is(op, "<<")) l = (s32)(ul << (ur & 31));
        else if (tok_is(op, ">>")) l = l >> (ur & 31); else if (tok_is(op, "+")) l = (s32)(ul + ur); else if (tok_is(op, "-")) l = (s32)(ul - ur);
        else if (tok_is(op, "*")) l = (s32)(ul * ur); else if (tok_is(op, "/")) l = r ? l / r : 0; else if (tok_is(op, "%")) l = r ? l % r : 0;
    }
    return l;
}
static s32 eval_if(Token *line, Token *dir) {
    List l = {0};
    for (Token *t = line; t->kind != TK_EOF && !t->bol; t = t->next) {
        if (tok_is(t, "defined")) {
            Token *n = t->next; int paren = tok_is(n, "(");
            if (paren) n = n->next;
            if (n->kind != TK_IDENT) cc_error(t->file, t->line, "bad defined");
            Token *c = copy_tok(n); c->kind = TK_NUM; c->val = find_macro(n) ? 1 : 0; c->uns = 0; lpush(&l, c);
            t = n; if (paren) { t = t->next; if (!tok_is(t, ")")) cc_error(t->file, t->line, "expected )"); }
            continue;
        }
        lpush(&l, copy_tok(t));
    }
    lpush(&l, new_eof(dir));
    Token *e = expand(l.head);
    pe_t = e; pe_file = dir->file; pe_line = dir->line;
    s32 v = pe_expr(0);
    if (pe_t->kind != TK_EOF) cc_error(dir->file, dir->line, "junk in #if expression");
    return v;
}

typedef struct Cond Cond; struct Cond { Cond *up; int parent_active, active, taken, saw_else; };
static List g_out;

static void pp_file(SrcFile *f, int depth) {
    if (depth > 40) cc_error(f->path, 1, "include nesting too deep");
    Token *t = tokenize(f);
    Cond *cs = NULL; List run = {0};
    int active = 1;
#define FLUSH() do { if (run.head) { lpush(&run, new_eof(t)); Token *e = expand(run.head); \
        for (Token *x = e; x->kind != TK_EOF; ) { Token *nx = x->next; lpush(&g_out, x); x = nx; } run.head = run.tail = NULL; } } while (0)
    while (t->kind != TK_EOF) {
        if (t->bol && tok_is(t, "#") && t->kind == TK_PUNCT) {
            Token *d = t; Token *ln = t->next;
            Token *end = ln; while (end->kind != TK_EOF && !end->bol) end = end->next;
            /* line tokens are [ln, end) */
            Token *saved_next = NULL; Token *last = NULL;
            for (Token *x = ln; x != end; x = x->next) last = x;
            if (last) { saved_next = last->next; last->next = new_eof(d); }
            if (ln == end) { t = end; continue; }
            Token *dn = ln;
            if (dn->kind == TK_NUM) { if (last) last->next = saved_next; t = end; continue; }
            int is_if = tok_is(dn, "if"), is_ifdef = tok_is(dn, "ifdef"), is_ifndef = tok_is(dn, "ifndef");
            if (is_if || is_ifdef || is_ifndef) {
                Cond *c = talloc(sizeof(Cond)); c->up = cs; c->parent_active = active; cs = c;
                int v = 0;
                if (active) {
                    if (is_if) v = eval_if(dn->next, dn) != 0;
                    else { if (dn->next->kind != TK_IDENT) cc_error(dn->file, dn->line, "expected macro name"); v = find_macro(dn->next) != NULL; if (is_ifndef) v = !v; }
                }
                c->active = active && v; c->taken = c->active; active = c->active;
            } else if (tok_is(dn, "elif") || tok_is(dn, "else") || tok_is(dn, "endif")) {
                if (!cs) cc_error(dn->file, dn->line, "#%.*s without #if", dn->len, dn->str);
                if (tok_is(dn, "endif")) { active = cs->parent_active; cs = cs->up; }
                else if (tok_is(dn, "else")) { cs->saw_else = 1; cs->active = cs->parent_active && !cs->taken; cs->taken = 1; active = cs->active; }
                else { int v = 0; if (cs->parent_active && !cs->taken) v = eval_if(dn->next, dn) != 0; cs->active = cs->parent_active && !cs->taken && v; if (cs->active) cs->taken = 1; active = cs->active; }
            } else if (active) {
                if (tok_is(dn, "define")) {
                    Token *nm = dn->next;
                    if (nm->kind != TK_IDENT) cc_error(nm->file, nm->line, "macro name expected");
                    Macro *m = add_macro(nm);
                    Token *b = nm->next;
                    if (tok_is(b, "(") && !b->sp) {
                        m->is_func = 1; b = b->next; Token *pl[64]; int n = 0;
                        while (!tok_is(b, ")")) {
                            if (b->kind == TK_EOF) cc_error(nm->file, nm->line, "bad macro parameters");
                            if (tok_is(b, "...")) { m->va = 1; b = b->next; break; }
                            if (b->kind != TK_IDENT) cc_error(b->file, b->line, "bad macro parameter");
                            pl[n++] = b; b = b->next; if (tok_is(b, ",")) b = b->next;
                        }
                        if (!tok_is(b, ")")) cc_error(nm->file, nm->line, "expected ) in macro");
                        b = b->next; m->nparams = n; m->params = talloc(sizeof(Token *) * (n + 1)); memcpy(m->params, pl, sizeof(Token *) * n);
                    }
                    List body = {0};
                    for (; b->kind != TK_EOF; b = b->next) lpush(&body, copy_tok(b));
                    lpush(&body, new_eof(nm)); m->body = body.head;
                } else if (tok_is(dn, "undef")) {
                    if (dn->next->kind == TK_IDENT) { Macro *m = add_macro(dn->next); m->deleted = 1; }
                } else if (tok_is(dn, "include")) {
                    Token *a = dn->next; char name[300]; int sys = 0;
                    if (a->kind == TK_STR) { snprintf(name, sizeof name, "%.*s", a->slen, a->sval); }
                    else if (tok_is(a, "<")) {
                        int n = 0; Token *x = a->next;
                        while (x->kind != TK_EOF && !tok_is(x, ">")) { for (int i = 0; i < x->len && n < 290; i++) name[n++] = x->str[i]; x = x->next; }
                        name[n] = 0; sys = 1;
                    } else cc_error(dn->file, dn->line, "bad #include");
                    SrcFile *inc = find_include(name, sys, f->path);
                    if (!inc) cc_error(dn->file, dn->line, "cannot find include file %s", name);
                    FLUSH();
                    pp_file(inc, depth + 1);
                } else if (tok_is(dn, "error")) {
                    cc_error(dn->file, dn->line, "#error");
                }
            }
            if (last) last->next = saved_next;
            t = end; continue;
        }
        Token *nx = t->next;
        if (active) lpush(&run, copy_tok(t));
        t = nx;
    }
    if (cs) cc_error(f->path, t->line, "unterminated #if");
    FLUSH();
#undef FLUSH
}

Token *preprocess_file(SrcFile *f) {
    g_out.head = g_out.tail = NULL;
    pp_file(f, 0);
    Token *e = talloc(sizeof(Token)); e->kind = TK_EOF; e->file = f->path; e->line = 1;
    lpush(&g_out, e);
    return g_out.head;
}
