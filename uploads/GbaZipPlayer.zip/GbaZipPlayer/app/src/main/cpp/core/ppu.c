/* Scanline software renderer: text/affine/bitmap backgrounds, sprites, alpha + brightness blending, mosaic. */
#include "gba.h"

static inline u32 r16m(const u8 *p) { return p[0] | (p[1] << 8); }
static inline u32 ioreg(u32 o) { return r16m(g_io + o); }
static inline u32 rgb(u32 c) { u32 r = c & 31, g = (c >> 5) & 31, b = (c >> 10) & 31; return (r << 3 | r >> 2) | ((g << 3 | g >> 2) << 8) | ((b << 3 | b >> 2) << 16); }
#define TRANS 0x8000
static u16 bgpix[4][240]; static u16 objpix[240]; static u8 objprio[240], objsemi[240];
static const u8 spw[3][4] = { {8,16,32,64}, {16,32,32,64}, {8,8,16,32} };
static const u8 sph[3][4] = { {8,16,32,64}, {8,8,16,32}, {16,32,32,64} };

static void draw_text_bg(int bg, int y, u32 dispcnt) {
    (void)dispcnt;
    u32 cnt = ioreg(8 + bg * 2); u16 *dst = bgpix[bg];
    int cbb = (cnt >> 2) & 3, sbb = (cnt >> 8) & 31, size = cnt >> 14, c256 = (cnt >> 7) & 1;
    int hofs = ioreg(0x10 + bg * 4) & 0x1FF, vofs = ioreg(0x12 + bg * 4) & 0x1FF;
    int bw = (size & 1) ? 512 : 256, bh = (size & 2) ? 512 : 256;
    u32 mos = ioreg(0x4C); int mh = (cnt & 0x40) ? (mos & 15) + 1 : 1, mv = (cnt & 0x40) ? ((mos >> 4) & 15) + 1 : 1;
    int sy = y - (y % mv);
    for (int x = 0; x < 240; x++) {
        int sx = x - (x % mh);
        int bx = (sx + hofs) & (bw - 1), by = (sy + vofs) & (bh - 1);
        int tx = bx >> 3, ty = by >> 3, sbi = 0;
        if (size == 1) sbi = tx >> 5; else if (size == 2) sbi = ty >> 5; else if (size == 3) sbi = (tx >> 5) + ((ty >> 5) << 1);
        u32 addr = (u32)(sbb + sbi) * 0x800 + (((ty & 31) * 32) + (tx & 31)) * 2;
        u32 ent = addr < 0x17FFF ? r16m(g_vram + addr) : 0;
        int tile = ent & 0x3FF, px = bx & 7, py = by & 7;
        if (ent & 0x400) px = 7 - px; if (ent & 0x800) py = 7 - py;
        u32 idx, pal;
        if (!c256) {
            u32 ta = (u32)cbb * 0x4000 + tile * 32 + py * 4 + (px >> 1);
            if (ta >= 0x10000) { dst[x] = TRANS; continue; }
            u32 b = g_vram[ta]; idx = (px & 1) ? b >> 4 : b & 15; pal = (ent >> 12) * 16 + idx;
        } else {
            u32 ta = (u32)cbb * 0x4000 + tile * 64 + py * 8 + px;
            if (ta >= 0x10000) { dst[x] = TRANS; continue; }
            idx = g_vram[ta]; pal = idx;
        }
        dst[x] = idx ? (u16)r16m(g_pal + pal * 2) & 0x7FFF : TRANS;
    }
}
static void draw_affine_bg(int bg, int y) {
    u32 cnt = ioreg(8 + bg * 2); u16 *dst = bgpix[bg];
    int cbb = (cnt >> 2) & 3, sbb = (cnt >> 8) & 31, wrap = (cnt >> 13) & 1, size = 128 << (cnt >> 14), tiles = size >> 3;
    u32 b = bg == 2 ? 0x20 : 0x30;
    s32 pa = (s16)ioreg(b), pb = (s16)ioreg(b + 2), pc = (s16)ioreg(b + 4), pd = (s16)ioreg(b + 6);
    u32 xr = ioreg(b + 8) | (ioreg(b + 10) << 16), yr = ioreg(b + 12) | (ioreg(b + 14) << 16);
    s32 rx = (s32)(xr << 4) >> 4, ry = (s32)(yr << 4) >> 4;
    s32 cx = rx + pb * y, cy = ry + pd * y;
    for (int x = 0; x < 240; x++, cx += pa, cy += pc) {
        int tx = cx >> 8, ty = cy >> 8;
        if (tx < 0 || ty < 0 || tx >= size || ty >= size) { if (!wrap) { dst[x] = TRANS; continue; } tx &= size - 1; ty &= size - 1; }
        u32 tile = g_vram[(u32)sbb * 0x800 + (ty >> 3) * tiles + (tx >> 3)];
        u32 ta = (u32)cbb * 0x4000 + tile * 64 + (ty & 7) * 8 + (tx & 7);
        u32 idx = ta < 0x10000 ? g_vram[ta] : 0;
        dst[x] = idx ? (u16)r16m(g_pal + idx * 2) & 0x7FFF : TRANS;
    }
}
static void draw_bitmap_bg(int mode, int y) {
    u16 *dst = bgpix[2]; u32 d = ioreg(0); int page = (d >> 4) & 1;
    for (int x = 0; x < 240; x++) {
        if (mode == 3) dst[x] = (u16)r16m(g_vram + (y * 240 + x) * 2) & 0x7FFF;
        else if (mode == 4) { u32 i = g_vram[(page ? 0xA000 : 0) + y * 240 + x]; dst[x] = i ? (u16)r16m(g_pal + i * 2) & 0x7FFF : TRANS; }
        else dst[x] = (x < 160 && y < 128) ? (u16)r16m(g_vram + (page ? 0xA000 : 0) + (y * 160 + x) * 2) & 0x7FFF : TRANS;
    }
}
static void draw_sprites(int y, u32 dispcnt) {
    for (int x = 0; x < 240; x++) { objpix[x] = TRANS; objprio[x] = 9; objsemi[x] = 0; }
    if (!(dispcnt & 0x1000)) return;
    int mode_bitmap = ((dispcnt & 7) >= 3);
    u32 mos = ioreg(0x4C); int omh = (mos >> 8 & 15) + 1, omv = (mos >> 12 & 15) + 1;
    for (int i = 127; i >= 0; i--) {
        const u8 *o = g_oam + i * 8; u32 a0 = r16m(o), a1 = r16m(o + 2), a2 = r16m(o + 4);
        int rs = (a0 >> 8) & 1, dbl = (a0 >> 9) & 1; if (!rs && dbl) continue;
        int omode = (a0 >> 10) & 3; if (omode == 3 || omode == 2) continue;
        int shape = a0 >> 14, size = a1 >> 14; if (shape == 3) continue;
        int w = spw[shape][size], h = sph[shape][size];
        int sy0 = a0 & 255; if (sy0 >= 160) sy0 -= 256;
        int sx0 = a1 & 511; if (sx0 >= 256) sx0 -= 512;
        int bw = (rs && dbl) ? w * 2 : w, bh = (rs && dbl) ? h * 2 : h;
        int yy = y; if ((a0 & 0x1000)) yy = y - (y % omv);
        int dy = yy - sy0; if (dy < 0 || dy >= bh) continue;
        if (sx0 + bw <= 0 || sx0 >= 240) continue;
        int tile = a2 & 0x3FF, prio = (a2 >> 10) & 3, pb = a2 >> 12, c256 = (a0 >> 13) & 1;
        int pa = 0, pbb = 0, pc = 0, pd = 0;
        if (rs) { const u8 *g = g_oam + ((a1 >> 9) & 31) * 32; pa = (s16)r16m(g + 6); pbb = (s16)r16m(g + 14); pc = (s16)r16m(g + 22); pd = (s16)r16m(g + 30); }
        for (int dx = 0; dx < bw; dx++) {
            int sx = sx0 + dx; if (sx < 0 || sx >= 240) continue;
            int tx, ty;
            if (rs) { int cx = dx - bw / 2, cy = dy - bh / 2; tx = ((pa * cx + pbb * cy) >> 8) + w / 2; ty = ((pc * cx + pd * cy) >> 8) + h / 2; }
            else { int ddx = dx; if (a0 & 0x1000) { int xx = sx - (sx % omh); ddx = xx - sx0; if (ddx < 0) ddx = 0; if (ddx >= w) ddx = w - 1; } tx = (a1 & 0x1000) ? w - 1 - ddx : ddx; ty = (a1 & 0x2000) ? h - 1 - dy : dy; }
            if (tx < 0 || ty < 0 || tx >= w || ty >= h) continue;
            int rowstep = (dispcnt & 0x40) ? (w >> 3) * (c256 ? 2 : 1) : 32;
            u32 idx, ad;
            if (!c256) { int t = tile + (ty >> 3) * rowstep + (tx >> 3); ad = 0x10000 + (u32)t * 32 + (ty & 7) * 4 + ((tx & 7) >> 1); if (ad >= 0x18000) continue; u32 bt = g_vram[ad]; idx = (tx & 1) ? bt >> 4 : bt & 15; }
            else { int t = tile + (ty >> 3) * rowstep + (tx >> 3) * 2; ad = 0x10000 + (u32)t * 32 + (ty & 7) * 8 + (tx & 7); if (ad >= 0x18000) continue; idx = g_vram[ad]; }
            if (!idx) continue;
            if (mode_bitmap && tile < 512) continue;
            if (prio <= objprio[sx]) {
                u32 pi = c256 ? idx : pb * 16 + idx;
                objpix[sx] = (u16)r16m(g_pal + 0x200 + pi * 2) & 0x7FFF; objprio[sx] = (u8)prio; objsemi[sx] = omode == 1;
            }
        }
    }
}
void ppu_render(u32 *out) {
    u32 dispcnt = ioreg(0);
    if (dispcnt & 0x80) { for (int i = 0; i < 240 * 160; i++) out[i] = 0xFFFFFFFFu; return; }
    int mode = dispcnt & 7; u32 backdrop = r16m(g_pal) & 0x7FFF;
    u32 bld = ioreg(0x50), bmode = (bld >> 6) & 3, first = bld & 63, second = (bld >> 8) & 63;
    u32 alpha = ioreg(0x52); int eva = (int)(alpha & 31), evb = (int)((alpha >> 8) & 31); if (eva > 16) eva = 16; if (evb > 16) evb = 16;
    int bldy = (int)(ioreg(0x54) & 31); if (bldy > 16) bldy = 16;
    for (int y = 0; y < 160; y++) {
        int en[4] = { 0, 0, 0, 0 };
        for (int b = 0; b < 4; b++) en[b] = (dispcnt >> (8 + b)) & 1;
        if (mode == 0) { for (int b = 0; b < 4; b++) if (en[b]) draw_text_bg(b, y, dispcnt); }
        else if (mode == 1) { if (en[0]) draw_text_bg(0, y, dispcnt); if (en[1]) draw_text_bg(1, y, dispcnt); if (en[2]) draw_affine_bg(2, y); en[3] = 0; }
        else if (mode == 2) { en[0] = en[1] = 0; if (en[2]) draw_affine_bg(2, y); if (en[3]) draw_affine_bg(3, y); }
        else { en[0] = en[1] = en[3] = 0; if (en[2] && mode <= 5) draw_bitmap_bg(mode, y); }
        draw_sprites(y, dispcnt);
        u32 *row = out + y * 240;
        for (int x = 0; x < 240; x++) {
            u32 tcol = backdrop, scol = backdrop; int ttag = 5, stag = 5, tsemi = 0, got = 0;
            for (int p = 0; p < 4 && got < 2; p++) {
                for (int l = -1; l < 4 && got < 2; l++) {
                    u32 c; int tag, semi = 0;
                    if (l < 0) { if (objpix[x] == TRANS || objprio[x] != p) continue; c = objpix[x]; tag = 4; semi = objsemi[x]; }
                    else { if (!en[l] || (int)(ioreg(8 + l * 2) & 3) != p || bgpix[l][x] == TRANS) continue; c = bgpix[l][x]; tag = l; }
                    if (got == 0) { tcol = c; ttag = tag; tsemi = semi; } else { scol = c; stag = tag; }
                    got++;
                }
            }
            u32 t = rgb(tcol), s = rgb(scol), res = t;
            int second_ok = (second >> stag) & 1, first_ok = (first >> ttag) & 1;
            int semi_blend = tsemi && ttag == 4 && second_ok;
            if (semi_blend || (bmode == 1 && first_ok && second_ok)) {
                u32 r = 0; for (int k = 0; k < 24; k += 8) { int a = (t >> k) & 255, b2 = (s >> k) & 255; int v = (a * eva + b2 * evb) >> 4; if (v > 255) v = 255; r |= (u32)v << k; }
                res = r;
            } else if (bmode == 2 && first_ok) {
                u32 r = 0; for (int k = 0; k < 24; k += 8) { int a = (t >> k) & 255; r |= (u32)(a + (((255 - a) * bldy) >> 4)) << k; } res = r;
            } else if (bmode == 3 && first_ok) {
                u32 r = 0; for (int k = 0; k < 24; k += 8) { int a = (t >> k) & 255; r |= (u32)(a - ((a * bldy) >> 4)) << k; } res = r;
            }
            row[x] = res | 0xFF000000u;
        }
    }
}
