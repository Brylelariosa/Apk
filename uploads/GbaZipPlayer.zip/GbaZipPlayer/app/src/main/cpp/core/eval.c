/* Tree-walking interpreter, guest memory map and linker. */
#include "gba.h"
#include <setjmp.h>

u8 *g_ewram, *g_iwram, *g_rom; u32 g_rom_size;
u8 g_io[0x400], g_pal[0x400], g_vram[0x18000], g_oam[0x400], g_sram[0x10000];
u32 g_keys; int g_abort;

static u32 sp, fp, cur_ret_buf; static u8 *fpp; static int depth; static long g_budget;
static jmp_buf run_jmp; static char fault_msg[240]; static u32 retval; static Node *seek_target;

static void vm_fault(const char *fmt, ...) {
    va_list ap; va_start(ap, fmt); vsnprintf(fault_msg, sizeof fault_msg, fmt, ap); va_end(ap);
    longjmp(run_jmp, 1);
}
const char *gba_fault(void) { return fault_msg; }

/* ---------- guest memory ---------- */
static inline u32 ld32(const u8 *p) { u32 v; memcpy(&v, p, 4); return v; }
static inline u32 ld16(const u8 *p) { u16 v; memcpy(&v, p, 2); return v; }
static inline void st32(u8 *p, u32 v) { memcpy(p, &v, 4); }
static inline void st16(u8 *p, u32 v) { u16 x = (u16)v; memcpy(p, &x, 2); }
static inline u32 vram_off(u32 a) { u32 o = a & 0x1FFFF; return o >= 0x18000 ? o - 0x8000 : o; }

u32 rd8(u32 a) {
    switch (a >> 24) {
    case 2: return g_ewram[a & (EWRAM_SIZE - 1)];
    case 3: return g_iwram[a & (IWRAM_SIZE - 1)];
    case 4: { u32 o = a & 0xFFFFFF; return o < 0x400 ? io_read(o, 1) : 0; }
    case 5: return g_pal[a & 0x3FF];
    case 6: return g_vram[vram_off(a)];
    case 7: return g_oam[a & 0x3FF];
    case 8: case 9: case 10: case 11: { u32 o = a & 0x1FFFFFF; return o < g_rom_size ? g_rom[o] : 0; }
    case 14: case 15: return g_sram[a & 0xFFFF];
    default: return 0;
    }
}
u32 rd16(u32 a) {
    switch (a >> 24) {
    case 2: return ld16(g_ewram + (a & (EWRAM_SIZE - 1)));
    case 3: return ld16(g_iwram + (a & (IWRAM_SIZE - 1)));
    case 4: { u32 o = a & 0xFFFFFE; return o < 0x400 ? io_read(o, 2) : 0; }
    case 5: return ld16(g_pal + (a & 0x3FE));
    case 6: return ld16(g_vram + (vram_off(a) & ~1u));
    case 7: return ld16(g_oam + (a & 0x3FE));
    case 8: case 9: case 10: case 11: { u32 o = a & 0x1FFFFFF; return o + 1 < g_rom_size ? ld16(g_rom + o) : 0; }
    case 14: case 15: return g_sram[a & 0xFFFF] * 0x0101u;
    default: return 0;
    }
}
u32 rd32(u32 a) {
    switch (a >> 24) {
    case 2: return ld32(g_ewram + (a & (EWRAM_SIZE - 1)));
    case 3: return ld32(g_iwram + (a & (IWRAM_SIZE - 1)));
    case 4: { u32 o = a & 0xFFFFFC; return o < 0x400 ? io_read(o, 4) : 0; }
    case 5: return ld32(g_pal + (a & 0x3FC));
    case 6: return ld32(g_vram + (vram_off(a) & ~3u));
    case 7: return ld32(g_oam + (a & 0x3FC));
    case 8: case 9: case 10: case 11: { u32 o = a & 0x1FFFFFF; return o + 3 < g_rom_size ? ld32(g_rom + o) : 0; }
    case 14: case 15: return g_sram[a & 0xFFFF] * 0x01010101u;
    default: return 0;
    }
}
void wr8(u32 a, u32 v) {
    switch (a >> 24) {
    case 2: g_ewram[a & (EWRAM_SIZE - 1)] = (u8)v; break;
    case 3: g_iwram[a & (IWRAM_SIZE - 1)] = (u8)v; break;
    case 4: { u32 o = a & 0xFFFFFF; if (o < 0x400) io_write(o, v & 0xFF, 1); break; }
    case 5: { u32 o = a & 0x3FE; g_pal[o] = g_pal[o + 1] = (u8)v; break; }
    case 6: { u32 o = vram_off(a); if (o < 0x10000) { o &= ~1u; g_vram[o] = g_vram[o + 1] = (u8)v; } break; }
    case 14: case 15: g_sram[a & 0xFFFF] = (u8)v; break;
    default: break;
    }
}
void wr16(u32 a, u32 v) {
    switch (a >> 24) {
    case 2: st16(g_ewram + (a & (EWRAM_SIZE - 1)), v); break;
    case 3: st16(g_iwram + (a & (IWRAM_SIZE - 1)), v); break;
    case 4: { u32 o = a & 0xFFFFFE; if (o < 0x400) io_write(o, v & 0xFFFF, 2); break; }
    case 5: st16(g_pal + (a & 0x3FE), v); break;
    case 6: st16(g_vram + (vram_off(a) & ~1u), v); break;
    case 7: st16(g_oam + (a & 0x3FE), v); break;
    case 14: case 15: g_sram[a & 0xFFFF] = (u8)v; break;
    default: break;
    }
}
void wr32(u32 a, u32 v) {
    switch (a >> 24) {
    case 2: st32(g_ewram + (a & (EWRAM_SIZE - 1)), v); break;
    case 3: st32(g_iwram + (a & (IWRAM_SIZE - 1)), v); break;
    case 4: { u32 o = a & 0xFFFFFC; if (o < 0x400) io_write(o, v, 4); break; }
    case 5: st32(g_pal + (a & 0x3FC), v); break;
    case 6: st32(g_vram + (vram_off(a) & ~3u), v); break;
    case 7: st32(g_oam + (a & 0x3FC), v); break;
    case 14: case 15: g_sram[a & 0xFFFF] = (u8)v; break;
    default: break;
    }
}
static void copy_mem(u32 d, u32 s, u32 n) {
    if ((d >> 24) == 3 && (s >> 24) == 3 && d - IWRAM_BASE + n <= IWRAM_SIZE && s - IWRAM_BASE + n <= IWRAM_SIZE) { memmove(g_iwram + (d - IWRAM_BASE), g_iwram + (s - IWRAM_BASE), n); return; }
    if ((d >> 24) == 2 && (s >> 24) == 2 && (d & (EWRAM_SIZE - 1)) + n <= EWRAM_SIZE && (s & (EWRAM_SIZE - 1)) + n <= EWRAM_SIZE) { memmove(g_ewram + (d & (EWRAM_SIZE - 1)), g_ewram + (s & (EWRAM_SIZE - 1)), n); return; }
    if (d <= s) for (u32 i = 0; i < n; i++) wr8(d + i, rd8(s + i)); else for (u32 i = n; i-- > 0;) wr8(d + i, rd8(s + i));
}

/* ---------- arithmetic ---------- */
u32 trunc_lm(u32 v, int lm) {
    switch (lm) {
    case LM_U8: return v & 0xFF; case LM_S8: return (u32)(s32)(s8)v; case LM_U16: return v & 0xFFFF;
    case LM_S16: return (u32)(s32)(s16)v; case LM_BOOL: return v != 0; default: return v;
    }
}
u32 do_binop(int k, u32 a, u32 b, int uns) {
    switch (k) {
    case ND_ADD: return a + b; case ND_SUB: return a - b; case ND_MUL: return a * b;
    case ND_DIV: if (!b) return 0; if (uns) return a / b; if ((s32)b == -1) return 0u - a; return (u32)((s32)a / (s32)b);
    case ND_MOD: if (!b) return 0; if (uns) return a % b; if ((s32)b == -1) return 0; return (u32)((s32)a % (s32)b);
    case ND_AND: return a & b; case ND_OR: return a | b; case ND_XOR: return a ^ b;
    case ND_SHL: return b >= 32 ? 0 : a << b;
    case ND_SHR: if (uns) return b >= 32 ? 0 : a >> b; return (u32)((s32)a >> (b >= 32 ? 31 : b));
    case ND_EQ: return a == b; case ND_NE: return a != b;
    case ND_LT: return uns ? a < b : (s32)a < (s32)b;
    case ND_LE: return uns ? a <= b : (s32)a <= (s32)b;
    default: return 0;
    }
}

/* ---------- native helpers ---------- */
static const char *native_names[] = { "", "memcpy", "memset", "memmove", "memcmp", "strlen", "strcmp", "strcpy", "abs", NULL };
static u32 call_native(int id, const u32 *a, int n) {
    (void)n;
    switch (id) {
    case 1: case 3: copy_mem(a[0], a[1], a[2]); return a[0];
    case 2: for (u32 i = 0; i < a[2]; i++) wr8(a[0] + i, a[1]); return a[0];
    case 4: for (u32 i = 0; i < a[2]; i++) { int d = (int)rd8(a[0] + i) - (int)rd8(a[1] + i); if (d) return (u32)d; } return 0;
    case 5: { u32 l = 0; while (rd8(a[0] + l)) l++; return l; }
    case 6: for (u32 i = 0;; i++) { int x = rd8(a[0] + i), y = rd8(a[1] + i); if (x != y) return (u32)(x - y); if (!x) return 0; }
    case 7: { u32 i = 0; do { wr8(a[0] + i, rd8(a[1] + i)); } while (rd8(a[1] + i++)); return a[0]; }
    case 8: return (s32)a[0] < 0 ? 0u - a[0] : a[0];
    }
    return 0;
}

/* ---------- evaluator ---------- */
static u32 ev(Node *n);
static int exec(Node *n);
static inline u32 fn_ptr(Obj *f) { return FUNC_BASE + ((u32)f->findex << 2); }
static u32 do_call(Obj *f, const u32 *argv, int argc, u32 retbuf);

static inline u32 load_lm(u32 a, int lm) {
    switch (lm) {
    case LM_32: return rd32(a);
    case LM_U8: case LM_BOOL: return rd8(a);
    case LM_S8: return (u32)(s32)(s8)rd8(a);
    case LM_U16: return rd16(a);
    case LM_S16: return (u32)(s32)(s16)rd16(a);
    default: return a;
    }
}
static inline void store_lm(u32 a, int lm, u32 v) {
    switch (lm) {
    case LM_32: wr32(a, v); break;
    case LM_U8: case LM_S8: case LM_BOOL: wr8(a, v); break;
    case LM_U16: case LM_S16: wr16(a, v); break;
    default: break;
    }
}
static u32 lv(Node *n) {
    switch (n->kind) {
    case ND_LVAR: return fp + n->var->off;
    case ND_GVAR: return n->var->is_func ? fn_ptr(n->var) : n->var->addr;
    case ND_DEREF: return ev(n->lhs);
    case ND_MEMBER: return lv(n->lhs) + n->mem->off;
    case ND_COMMA: ev(n->lhs); return lv(n->rhs);
    case ND_COND: return ev(n->cond) ? lv(n->then) : lv(n->els);
    case ND_ASSIGN: case ND_CALL: return ev(n);
    default: vm_fault("internal error: not an lvalue (node %d)", n->kind); return 0;
    }
}
static Obj *fn_from_ptr(u32 p) {
    if (p < FUNC_BASE || ((p - FUNC_BASE) & 3)) vm_fault("call through a bad function pointer (0x%08X)", p);
    u32 i = (p - FUNC_BASE) >> 2;
    if (i >= (u32)g_nfuncs) vm_fault("call through a bad function pointer (0x%08X)", p);
    return g_funcs[i];
}
static u32 ev(Node *n) {
    switch (n->kind) {
    case ND_NUM: return (u32)n->val;
    case ND_LVAR: {
        int off = n->var->off;
        switch (n->lm) {
        case LM_32: return ld32(fpp + off);
        case LM_U8: case LM_BOOL: return fpp[off];
        case LM_S8: return (u32)(s32)(s8)fpp[off];
        case LM_U16: return ld16(fpp + off);
        case LM_S16: return (u32)(s32)(s16)ld16(fpp + off);
        default: return fp + off;
        }
    }
    case ND_GVAR: { if (n->var->is_func) return fn_ptr(n->var); return load_lm(n->var->addr, n->lm); }
    case ND_DEREF: { u32 a = ev(n->lhs); if (n->ty->kind == TY_FUNC) return a; return load_lm(a, n->lm); }
    case ND_MEMBER: return load_lm(lv(n->lhs) + n->mem->off, n->lm);
    case ND_ADDR: return lv(n->lhs);
    case ND_ASSIGN: {
        if (n->lm == LM_AGG) { u32 s = ev(n->rhs); u32 d = lv(n->lhs); copy_mem(d, s, n->ty->size); return d; }
        u32 v = trunc_lm(ev(n->rhs), n->lm);
        if (n->lhs->kind == ND_LVAR) {
            int off = n->lhs->var->off;
            switch (n->lm) { case LM_32: st32(fpp + off, v); return v; case LM_U8: case LM_S8: case LM_BOOL: fpp[off] = (u8)v; return v; default: st16(fpp + off, v); return v; }
        }
        store_lm(lv(n->lhs), n->lm, v); return v;
    }
    case ND_OPASSIGN: {
        u32 r = ev(n->rhs); u32 a = lv(n->lhs); u32 old = load_lm(a, n->lm);
        u32 v = trunc_lm(do_binop(n->op, old, r, n->uns), n->lm); store_lm(a, n->lm, v); return v;
    }
    case ND_PREINC: { u32 a = lv(n->lhs); u32 v = trunc_lm(load_lm(a, n->lm) + (u32)n->val, n->lm); store_lm(a, n->lm, v); return v; }
    case ND_POSTINC: { u32 a = lv(n->lhs); u32 old = load_lm(a, n->lm); store_lm(a, n->lm, trunc_lm(old + (u32)n->val, n->lm)); return old; }
    case ND_COMMA: ev(n->lhs); return ev(n->rhs);
    case ND_COND: return ev(n->cond) ? ev(n->then) : ev(n->els);
    case ND_LOGAND: return ev(n->lhs) && ev(n->rhs);
    case ND_LOGOR: return ev(n->lhs) || ev(n->rhs);
    case ND_NOT: return !ev(n->lhs);
    case ND_BITNOT: return ~ev(n->lhs);
    case ND_NEG: return 0u - ev(n->lhs);
    case ND_ADD: { u32 a = ev(n->lhs); return a + ev(n->rhs); }
    case ND_SUB: { u32 a = ev(n->lhs); return a - ev(n->rhs); }
    case ND_MUL: { u32 a = ev(n->lhs); return a * ev(n->rhs); }
    case ND_EQ: { u32 a = ev(n->lhs); return a == ev(n->rhs); }
    case ND_NE: { u32 a = ev(n->lhs); return a != ev(n->rhs); }
    case ND_LT: { u32 a = ev(n->lhs); u32 b = ev(n->rhs); return n->uns ? a < b : (s32)a < (s32)b; }
    case ND_LE: { u32 a = ev(n->lhs); u32 b = ev(n->rhs); return n->uns ? a <= b : (s32)a <= (s32)b; }
    case ND_DIV: case ND_MOD: case ND_AND: case ND_OR: case ND_XOR: case ND_SHL: case ND_SHR: { u32 a = ev(n->lhs); u32 b = ev(n->rhs); return do_binop(n->kind, a, b, n->uns); }
    case ND_CAST: { u32 v = ev(n->lhs); return n->val == LM_32 ? v : trunc_lm(v, n->val); }
    case ND_MEMZERO: { u32 a = lv(n->lhs); u32 sz = n->lhs->ty->size; if ((a >> 24) == 3 && a - IWRAM_BASE + sz <= IWRAM_SIZE) memset(g_iwram + (a - IWRAM_BASE), 0, sz); else for (u32 i = 0; i < sz; i++) wr8(a + i, 0); return 0; }
    case ND_CALL: {
        Obj *f = n->func; u32 argv[16]; int argc = 0;
        if (!f) f = fn_from_ptr(ev(n->lhs));
        Node *an[16];
        for (Node *a = n->args; a; a = a->next) { if (argc >= 16) vm_fault("too many call arguments"); an[argc++] = a; }
        for (int k = argc - 1; k >= 0; k--) argv[k] = ev(an[k]);   /* right-to-left, like gcc on x86-64 and ARM */
        return do_call(f, argv, argc, n->var ? fp + n->var->off : 0);
    }
    default: vm_fault("internal error: cannot evaluate node %d", n->kind); return 0;
    }
}
static u32 do_call(Obj *f, const u32 *argv, int argc, u32 retbuf) {
    if (f->native) return call_native(f->native, argv, argc);
    if (!f->body) vm_fault("call to undefined function '%s'", f->name);
    if (depth >= 300) vm_fault("call stack too deep in '%s'", f->name);
    u32 nsp = sp - (u32)f->stack_size;
    if (nsp < IWRAM_BASE + 512) vm_fault("stack overflow in '%s'", f->name);
    u32 osp = sp, ofp = fp, orb = cur_ret_buf; u8 *ofpp = fpp;
    sp = fp = nsp; fpp = g_iwram + (fp - IWRAM_BASE); memset(fpp, 0, (size_t)f->stack_size);
    depth++; cur_ret_buf = retbuf;
    int i = 0;
    for (Obj *p = f->params; p && i < argc; p = p->next, i++) {
        Type *t = p->ty;
        if (t->kind == TY_STRUCT || t->kind == TY_UNION) copy_mem(fp + p->off, argv[i], t->size);
        else { u32 v = argv[i]; if (t->kind == TY_BOOL) v = v != 0; memcpy(fpp + p->off, &v, t->size < 4 ? t->size : 4); }
    }
    int r = exec(f->body);
    u32 rv = r == 3 ? retval : 0;
    depth--; sp = osp; fp = ofp; fpp = ofpp; cur_ret_buf = orb;
    return rv;
}

enum { R_NONE, R_BREAK, R_CONT, R_RET };
static int exec_seek(Node *n) {
    switch (n->kind) {
    case ND_CASE: if (n == seek_target) { seek_target = NULL; return exec(n->lhs); } return exec_seek(n->lhs);
    case ND_BLOCK: for (Node *c = n->body; c; c = c->next) { int r = seek_target ? exec_seek(c) : exec(c); if (r) return r; } return 0;
    case ND_IF: { int r = exec_seek(n->then); if (seek_target && n->els) r = exec_seek(n->els); return r; }
    default: return 0;
    }
}
static int exec(Node *n) {
    switch (n->kind) {
    case ND_BLOCK: for (Node *c = n->body; c; c = c->next) { int r = exec(c); if (r) return r; } return 0;
    case ND_EXPR_STMT: ev(n->lhs); return 0;
    case ND_IF: if (ev(n->cond)) return exec(n->then); return n->els ? exec(n->els) : 0;
    case ND_FOR:
        if (n->init) { int r = exec(n->init); if (r) return r; }
        for (;;) {
            if (n->cond && !ev(n->cond)) break;
            int r = exec(n->then);
            if (r == R_BREAK) break; if (r == R_RET) return r;
            if (n->inc) ev(n->inc);
            if (--g_budget < 0) vm_fault("the game stopped responding (endless loop)");
        }
        return 0;
    case ND_DO:
        for (;;) {
            int r = exec(n->then);
            if (r == R_BREAK) break; if (r == R_RET) return r;
            if (!ev(n->cond)) break;
            if (--g_budget < 0) vm_fault("the game stopped responding (endless loop)");
        }
        return 0;
    case ND_SWITCH: {
        u32 v = ev(n->cond); Node *t = NULL;
        for (Node *c = n->case_next; c; c = c->case_next) if ((u32)c->val == v) { t = c; break; }
        if (!t) t = n->default_case;
        if (!t) return 0;
        seek_target = t; int r = exec_seek(n->then); seek_target = NULL;
        return r == R_BREAK ? 0 : r;
    }
    case ND_CASE: return exec(n->lhs);
    case ND_BREAK: return R_BREAK;
    case ND_CONTINUE: return R_CONT;
    case ND_RETURN:
        if (n->lhs) {
            if (n->lhs->ty && (n->lhs->ty->kind == TY_STRUCT || n->lhs->ty->kind == TY_UNION)) { u32 s = ev(n->lhs); if (cur_ret_buf) copy_mem(cur_ret_buf, s, n->lhs->ty->size); retval = cur_ret_buf; }
            else retval = ev(n->lhs);
        } else retval = 0;
        return R_RET;
    default: ev(n); return 0;
    }
}

/* ---------- linking ---------- */
static int native_id(const char *name) { for (int i = 1; native_names[i]; i++) if (!strcmp(native_names[i], name)) return i; return 0; }
static u32 al(u32 v, u32 a) { return a <= 1 ? v : (v + a - 1) / a * a; }
Obj *vm_func(const char *name) { Obj *o = cc_find_global(name); return (o && o->is_func) ? o : NULL; }
int vm_link(char *err, int errlen) {
    int nf = 0; for (Obj *o = g_objs; o; o = o->gnext) if (o->is_func) nf++;
    g_funcs = calloc(nf + 1, sizeof(Obj *)); g_nfuncs = 0;
    for (Obj *o = g_objs; o; o = o->gnext) if (o->is_func) { o->findex = g_nfuncs; g_funcs[g_nfuncs++] = o; if (!o->body) o->native = native_id(o->name); }
    u32 ew = 0, ro = 0;
    for (Obj *o = g_objs; o; o = o->gnext) {
        if (o->is_func) continue;
        u32 size = (u32)(o->ty->size > o->imglen ? o->ty->size : o->imglen); if (size == 0) size = 4;
        u32 a = (u32)(o->ty->align < 4 ? 4 : o->ty->align);
        if (o->is_const && o->img) { ro = al(ro, a); o->addr = ROM_BASE + ro; ro += size; }
        else { ew = al(ew, a); o->addr = EWRAM_BASE + ew; ew += size; }
    }
    if (ew >= EWRAM_SIZE - 4096) { snprintf(err, errlen, "global data (%u bytes) does not fit in memory", ew); return -1; }
    free(g_rom); g_rom = calloc(ro + 16, 1); g_rom_size = ro;
    for (Obj *o = g_objs; o; o = o->gnext) {
        if (o->is_func) continue;
        for (Reloc *r = o->rels; r; r = r->next) {
            u32 sa = r->sym->is_func ? FUNC_BASE + ((u32)r->sym->findex << 2) : r->sym->addr; u32 v = sa + (u32)r->add;
            if (r->off + 4 <= o->imglen) memcpy(o->img + r->off, &v, 4);
        }
        if (o->is_const && o->img) memcpy(g_rom + (o->addr - ROM_BASE), o->img, o->imglen);
    }
    return 0;
}
void vm_boot(void) {
    if (!g_ewram) g_ewram = calloc(EWRAM_SIZE + 16, 1);
    if (!g_iwram) g_iwram = calloc(IWRAM_SIZE + 16, 1);
    memset(g_ewram, 0, EWRAM_SIZE); memset(g_iwram, 0, IWRAM_SIZE);
    for (Obj *o = g_objs; o; o = o->gnext)
        if (!o->is_func && o->img && !o->is_const) memcpy(g_ewram + (o->addr - EWRAM_BASE), o->img, o->imglen);
    memset(g_io, 0, sizeof g_io); memset(g_pal, 0, sizeof g_pal); memset(g_vram, 0, sizeof g_vram); memset(g_oam, 0, sizeof g_oam);
    hw_reset();
}
u32 vm_call(Obj *fn, int nargs, const u32 *args) {
    sp = IWRAM_BASE + IWRAM_SIZE - 64; fp = sp; fpp = g_iwram + (fp - IWRAM_BASE); depth = 0; cur_ret_buf = 0; seek_target = NULL;
    g_budget = 30000000;
    if (setjmp(run_jmp)) { g_abort = 1; return 0; }
    return do_call(fn, args, nargs, 0);
}
