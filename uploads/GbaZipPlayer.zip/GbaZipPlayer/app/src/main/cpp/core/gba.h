/* GBA C-source player core: shared declarations. */
#ifndef GBA_H
#define GBA_H
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

typedef uint8_t u8; typedef uint16_t u16; typedef uint32_t u32;
typedef int8_t s8; typedef int16_t s16; typedef int32_t s32;

/* ---------- memory / errors ---------- */
void *xalloc(size_t n);                 /* zeroed, lives until gba_unload() */
char *xstrndup(const char *s, int n);
void *talloc(size_t n);                 /* temporary (token) arena, freed per translation unit */
void tarena_free(void);
char *tstrndup(const char *s, int n);
void cc_error(const char *file, int line, const char *fmt, ...);   /* longjmps out of compilation */
void arena_free_all(void);
extern char g_err[600];

/* ---------- source files ---------- */
typedef struct { char *path; char *data; int len; int unit; } SrcFile;
extern SrcFile *g_files; extern int g_nfiles;
SrcFile *find_file(const char *path);

/* ---------- tokens ---------- */
typedef enum { TK_EOF, TK_IDENT, TK_PUNCT, TK_NUM, TK_STR, TK_NUMLIST } TokKind;
typedef struct Token Token;
struct Token {
    TokKind kind; Token *next; const char *file; int line;
    char *str; int len;          /* spelling (idents / punctuators) */
    u8 bol, sp, uns;             /* begins a line / preceded by space / unsigned literal */
    s32 val;                     /* number or char literal */
    u8 *sval; int slen;          /* string literal bytes (without NUL) */
};
Token *tokenize(SrcFile *f);
Token *preprocess_file(SrcFile *f);            /* fully preprocessed token list for one translation unit */
void pp_reset(void);
int tok_is(Token *t, const char *s);

/* ---------- types ---------- */
typedef struct Type Type; typedef struct Member Member; typedef struct Obj Obj; typedef struct Node Node;
typedef enum { TY_VOID, TY_BOOL, TY_CHAR, TY_SHORT, TY_INT, TY_LONG, TY_ENUM, TY_PTR, TY_ARRAY, TY_STRUCT, TY_UNION, TY_FUNC } TyKind;
struct Type {
    TyKind kind; int size, align; int uns;
    Type *base; int len;               /* ptr/array/func base; array length (-1 = unknown) */
    Member *mem; int incomplete;       /* struct/union */
    Type *params, *next; const char *pname; int pnlen;  /* function parameter chain; parameter name */
    int variadic, unspec, is_const;
};
struct Member { Member *next; Type *ty; const char *name; int nlen; int off; };
enum { LM_32, LM_U8, LM_S8, LM_U16, LM_S16, LM_BOOL, LM_AGG };
u32 trunc_lm(u32 v, int lm);
u32 do_binop(int kind, u32 a, u32 b, int uns);

/* ---------- objects ---------- */
typedef struct Reloc Reloc; struct Reloc { Reloc *next; int off; Obj *sym; int add; };
struct Obj {
    Obj *next, *gnext, *hnext; char *name; Type *ty;
    int is_local, is_func, is_static, is_def, is_const, is_tentative;
    int off;                        /* local: frame offset */
    u32 addr; u8 *img; int imglen;  /* global: guest address and initial image */
    Reloc *rels;
    Obj *params; Node *body; int stack_size, nparams, findex;
    int native;                     /* >0: built-in function id */
};

typedef enum {
    ND_NUM, ND_LVAR, ND_GVAR, ND_ADDR, ND_DEREF, ND_MEMBER, ND_ASSIGN, ND_OPASSIGN, ND_PREINC, ND_POSTINC,
    ND_COMMA, ND_COND, ND_LOGAND, ND_LOGOR, ND_NOT, ND_BITNOT, ND_NEG,
    ND_ADD, ND_SUB, ND_MUL, ND_DIV, ND_MOD, ND_AND, ND_OR, ND_XOR, ND_SHL, ND_SHR, ND_EQ, ND_NE, ND_LT, ND_LE,
    ND_CAST, ND_CALL, ND_MEMZERO, ND_VAIDX,
    ND_BLOCK, ND_EXPR_STMT, ND_IF, ND_FOR, ND_DO, ND_SWITCH, ND_CASE, ND_BREAK, ND_CONTINUE, ND_RETURN, ND_NOP
} NodeKind;

struct Node {
    NodeKind kind; Type *ty; Token *tok;
    Node *lhs, *rhs, *next;
    Node *cond, *then, *els, *init, *inc, *body;
    Obj *var; Member *mem; s32 val; int op, uns, lm;
    Node *args; Obj *func;            /* call */
    Node *case_next, *default_case;   /* switch bookkeeping */
};

/* compiler entry: compile all translation units; returns 0 on success */
int cc_compile(SrcFile *files, int n, char *err, int errlen);
void cc_reset(void);
Obj *cc_find_global(const char *name);
int cc_enum_const(const char *name, s32 *out);
extern Obj *g_objs;       /* all global objects, in declaration order */
extern Obj **g_funcs; extern int g_nfuncs;

/* ---------- guest memory ---------- */
#define EWRAM_BASE 0x02000000u
#define EWRAM_SIZE (1u << 20)
#define IWRAM_BASE 0x03000000u
#define IWRAM_SIZE (1u << 18)
#define ROM_BASE   0x08000000u
#define FUNC_BASE  0x0C000000u
#define SRAM_BASE  0x0E000000u
extern u8 *g_ewram, *g_iwram, *g_rom; extern u8 g_io[0x400], g_pal[0x400], g_vram[0x18000], g_oam[0x400], g_sram[0x10000];
extern u32 g_rom_size;
u32 rd8(u32 a); u32 rd16(u32 a); u32 rd32(u32 a);
void wr8(u32 a, u32 v); void wr16(u32 a, u32 v); void wr32(u32 a, u32 v);

/* ---------- link + run ---------- */
int vm_link(char *err, int errlen);               /* lay out globals, apply relocations */
void vm_boot(void);                               /* clear memory, copy initial images */
u32 vm_call(Obj *fn, int nargs, const u32 *args);
Obj *vm_func(const char *name);
extern u32 g_keys;                                /* pressed buttons, GBA bit order (A=1,B=2,Sel=4,Start=8,R,L,U,D...) */
extern int g_abort;

/* ---------- hardware ---------- */
void hw_reset(void);
void io_write(u32 off, u32 v, int size);          /* called by wr8/16/32 for IO region */
u32  io_read(u32 off, int size);
void ppu_render(u32 *rgba);                       /* 240x160, 0xAABBGGRR little endian = RGBA bytes */
void apu_frame(s16 *out, int nsamples);           /* stereo interleaved */
void hw_frame_end(void);
void apu_set_rate(int hz);
int apu_rate(void);

/* ---------- public player API ---------- */
int  gba_load(SrcFile *files, int n, char *err, int errlen);
int  gba_start(char *err, int errlen);            /* link + boot + game_init */
void gba_unload(void);
int  gba_run_frame(u32 keys);                     /* returns 0 ok, nonzero on runtime fault */
const char *gba_fault(void);
int gba_audio(s16 *out, int cap);                 /* samples (stereo frames) for one video frame */
void gba_set_sram(const u8 *d, int n);
const u8 *gba_get_sram(void);
#endif
