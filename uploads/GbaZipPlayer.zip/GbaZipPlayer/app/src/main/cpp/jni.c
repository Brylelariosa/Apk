/* JNI bridge between the Java UI and the GBA C-source player core. */
#include <jni.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "gba.h"

#define JNI_FN(ret, name) JNIEXPORT ret JNICALL Java_com_embervale_zipplayer_Native_##name

/* NewStringUTF needs valid UTF-8; error text can contain arbitrary source bytes. */
static jstring safe_string(JNIEnv *env, const char *msg) {
    char buf[760]; size_t n = 0;
    for (; msg && *msg && n < sizeof buf - 1; msg++) {
        unsigned char c = (unsigned char)*msg;
        buf[n++] = (c >= 32 && c < 127) || c == '\n' ? (char)c : '?';
    }
    buf[n] = 0;
    return (*env)->NewStringUTF(env, buf);
}

JNI_FN(jstring, load)(JNIEnv *env, jclass cls, jobjectArray jpaths, jobjectArray jdata) {
    (void)cls;
    int n = (int)(*env)->GetArrayLength(env, jpaths);
    SrcFile *fs = (SrcFile *)calloc(n > 0 ? (size_t)n : 1, sizeof(SrcFile));
    if (!fs) return safe_string(env, "out of memory");
    for (int i = 0; i < n; i++) {
        jstring js = (jstring)(*env)->GetObjectArrayElement(env, jpaths, i);
        const char *p = js ? (*env)->GetStringUTFChars(env, js, NULL) : NULL;
        fs[i].path = strdup(p ? p : "");
        if (p) (*env)->ReleaseStringUTFChars(env, js, p);
        if (js) (*env)->DeleteLocalRef(env, js);
        jbyteArray ba = (jbyteArray)(*env)->GetObjectArrayElement(env, jdata, i);
        jsize len = ba ? (*env)->GetArrayLength(env, ba) : 0;
        fs[i].data = (char *)malloc((size_t)len + 1);
        if (len > 0) (*env)->GetByteArrayRegion(env, ba, 0, len, (jbyte *)fs[i].data);
        fs[i].data[len] = 0; fs[i].len = (int)len;
        if (ba) (*env)->DeleteLocalRef(env, ba);
    }
    char err[700]; err[0] = 0;
    int r = gba_load(fs, n, err, (int)sizeof err);
    for (int i = 0; i < n; i++) { free(fs[i].path); free(fs[i].data); }
    free(fs);
    return r ? safe_string(env, err) : NULL;
}

JNI_FN(jstring, start)(JNIEnv *env, jclass cls) {
    (void)cls; char err[700]; err[0] = 0;
    return gba_start(err, (int)sizeof err) ? safe_string(env, err) : NULL;
}

JNI_FN(jstring, frame)(JNIEnv *env, jclass cls, jint keys) {
    (void)cls;
    return gba_run_frame((u32)keys) ? safe_string(env, gba_fault()) : NULL;
}

JNI_FN(void, render)(JNIEnv *env, jclass cls, jobject buf) {
    (void)cls;
    void *p = (*env)->GetDirectBufferAddress(env, buf);
    jlong cap = (*env)->GetDirectBufferCapacity(env, buf);
    if (p && cap >= 240 * 160 * 4) ppu_render((u32 *)p);
}

JNI_FN(jint, audio)(JNIEnv *env, jclass cls, jshortArray out) {
    (void)cls;
    static s16 tmp[8192 * 2];
    int cap = (int)((*env)->GetArrayLength(env, out) / 2);
    if (cap > 8192) cap = 8192;
    int ns = gba_audio(tmp, cap);
    if (ns > 0) (*env)->SetShortArrayRegion(env, out, 0, ns * 2, (const jshort *)tmp);
    return ns;
}

JNI_FN(void, setRate)(JNIEnv *env, jclass cls, jint hz) { (void)env; (void)cls; apu_set_rate((int)hz); }

JNI_FN(jbyteArray, getSram)(JNIEnv *env, jclass cls) {
    (void)cls;
    jbyteArray a = (*env)->NewByteArray(env, 0x10000);
    if (a) (*env)->SetByteArrayRegion(env, a, 0, 0x10000, (const jbyte *)gba_get_sram());
    return a;
}

JNI_FN(void, setSram)(JNIEnv *env, jclass cls, jbyteArray data) {
    (void)cls;
    jsize n = data ? (*env)->GetArrayLength(env, data) : 0;
    if (n > 0x10000) n = 0x10000;
    jbyte *tmp = (jbyte *)calloc(1, (size_t)n + 1);
    if (n > 0 && tmp) (*env)->GetByteArrayRegion(env, data, 0, n, tmp);
    gba_set_sram((const u8 *)tmp, (int)n);
    free(tmp);
}

JNI_FN(void, unload)(JNIEnv *env, jclass cls) { (void)env; (void)cls; gba_unload(); }
