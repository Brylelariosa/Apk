package com.embervale.zipplayer;

/**
 * Frame pacing for the emulation thread (no Android dependencies, so it can be tested on a PC).
 *
 * <ul>
 *   <li>Keeps the game at the real GBA speed (59.73 frames per second) using the wall clock, one short sleep per
 *       frame, so the picture moves smoothly.</li>
 *   <li>Keeps a little sound queued in the audio track so that a slow frame does not make the sound break up. The
 *       sleep is cut short whenever the audio queue is running low.</li>
 *   <li>Tells the loop to skip <em>drawing</em> a frame when the game falls behind real time. Emulation and sound are
 *       never skipped, so game speed and audio stay right even on a slow phone; only the picture gets less smooth.</li>
 * </ul>
 */
final class Pacer {
    /** 280896 cycles at 16.78 MHz. */
    static final long FRAME_NS = 16743000L;

    /** How far (wall clock) the emulated time runs ahead of real time in steady state. */
    private static final long LEAD_NS = 45000000L;
    /** The sleep never lets the audio track queue drop below this much sound (the playback position the system reports
     *  is only updated every audio period, so the estimate can be one period too generous). */
    private static final long AUDIO_MIN_NS = 40000000L;
    /** If the audio queue grows beyond this (audio clock slower than the system clock) the loop waits for it to drain. */
    private static final long AUDIO_MAX_NS = 90000000L;
    /** If the lead is smaller than this after a frame, the next picture is not drawn. */
    private static final long SKIP_BELOW_NS = 6000000L;
    /** Too far behind (or the clock jumped): forget the past and start over. */
    private static final long RESYNC_NS = 250000000L;
    private static final long MAX_SLEEP_NS = 40000000L;
    private static final long MIN_SLEEP_NS = 1000000L;
    /** At least every fifth frame is drawn, however late we are. */
    private static final int MAX_SKIP = 4;

    private long t0;
    private long frames;
    private int skipped;

    Pacer(long now) {
        reset(now);
    }

    void reset(long now) {
        t0 = now;
        frames = 0;
        skipped = 0;
    }

    /**
     * Call after a frame has been emulated and before it is drawn: true = render and draw it.
     *
     * @param audioQueuedNs sound waiting in the audio track in nanoseconds, or -1 when unknown
     */
    boolean shouldDraw(long now, long audioQueuedNs) {
        long ahead = (frames + 1) * FRAME_NS - (now - t0);
        boolean late = ahead < SKIP_BELOW_NS;
        if (late && audioQueuedNs >= AUDIO_MIN_NS) {
            late = false;   // the sound is not at risk: the audio and system clocks have only drifted apart a little
        }
        if (!late || skipped >= MAX_SKIP) {
            skipped = 0;
            return true;
        }
        skipped++;
        return false;
    }

    /**
     * Call after the frame's sound has been queued.
     *
     * @param audioQueuedNs sound waiting in the audio track in nanoseconds, or -1 when unknown
     * @return how long to sleep before starting the next frame (0 = do not sleep)
     */
    long afterFrame(long now, long audioQueuedNs) {
        frames++;
        long ahead = frames * FRAME_NS - (now - t0);
        if (ahead < -RESYNC_NS || ahead > 4 * LEAD_NS) {
            reset(now);
            return 0;
        }
        long sleep = ahead - LEAD_NS;
        if (audioQueuedNs >= 0) {
            long s2 = audioQueuedNs - AUDIO_MIN_NS;
            if (s2 < sleep) {
                sleep = s2;
            }
            long s3 = audioQueuedNs - AUDIO_MAX_NS;
            if (s3 > sleep) {
                sleep = s3;
            }
        }
        if (sleep < MIN_SLEEP_NS) {
            return 0;
        }
        return sleep > MAX_SLEEP_NS ? MAX_SLEEP_NS : sleep;
    }
}
