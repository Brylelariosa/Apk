package com.embervale.zipplayer;

import java.nio.ByteBuffer;

/** JNI entry points of the GBA C-source player core (see src/main/cpp). */
final class Native {
    static {
        System.loadLibrary("gbazip");
    }

    private Native() { }

    /** Compiles the project sources; returns null on success or an error message. */
    static native String load(String[] paths, byte[][] data);

    /** (Re)boots the loaded game; returns null on success or an error message. */
    static native String start();

    /** Runs one video frame with the given pressed-key mask; returns null or a runtime error message. */
    static native String frame(int keys);

    /** Renders the current picture (240x160, RGBA bytes) into a direct buffer. */
    static native void render(ByteBuffer rgba);

    /** Generates the sound of the last frame; returns the number of stereo sample frames written. */
    static native int audio(short[] out);

    static native void setRate(int hz);

    static native byte[] getSram();

    static native void setSram(byte[] data);

    static native void unload();
}
