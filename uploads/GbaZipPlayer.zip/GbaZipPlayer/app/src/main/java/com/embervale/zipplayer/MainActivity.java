package com.embervale.zipplayer;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.UriPermission;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.List;

/** Start screen: pick a ZIP file that contains the C source of a GBA game. */
public class MainActivity extends Activity {
    private static final int REQ_PICK = 42;

    private SharedPreferences prefs;
    private float dp;
    private Button lastButton;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("gbazip", MODE_PRIVATE);
        dp = getResources().getDisplayMetrics().density;
        buildUi();
        Intent i = getIntent();
        if (b == null && i != null && Intent.ACTION_VIEW.equals(i.getAction()) && i.getData() != null) {
            play(i.getData());
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshLast();
    }

    private int px(float v) {
        return (int) (v * dp + 0.5f);
    }

    private Button makeButton(String text, boolean primary) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setAllCaps(false);
        btn.setTextSize(17f);
        btn.setTypeface(Typeface.DEFAULT_BOLD);
        btn.setTextColor(primary ? Color.rgb(30, 18, 8) : Color.rgb(255, 190, 110));
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(px(14));
        if (primary) {
            bg.setColor(Color.rgb(255, 160, 50));
        } else {
            bg.setColor(Color.rgb(28, 30, 44));
            bg.setStroke(px(2), Color.rgb(255, 160, 50));
        }
        btn.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, px(58));
        lp.topMargin = px(14);
        btn.setLayoutParams(lp);
        return btn;
    }

    private TextView makeText(String text, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) {
            t.setTypeface(Typeface.DEFAULT_BOLD);
        }
        return t;
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(14, 15, 23));
        scroll.setFillViewport(true);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(px(24), px(48), px(24), px(32));
        scroll.addView(col, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = makeText("GBA ZIP Player", 30f, Color.rgb(255, 160, 50), true);
        title.setGravity(Gravity.CENTER);
        col.addView(title);

        TextView sub = makeText("Play a Game Boy Advance game straight from a ZIP of its C source code.",
                15f, Color.rgb(200, 204, 220), false);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, px(10), 0, px(18));
        col.addView(sub);

        Button choose = makeButton("Choose ZIP file", true);
        choose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pick();
            }
        });
        col.addView(choose);

        lastButton = makeButton("", false);
        lastButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s = prefs.getString("last_uri", null);
                if (s != null) {
                    play(Uri.parse(s));
                }
            }
        });
        col.addView(lastButton);

        TextView how = makeText(
                "How it works\n"
                        + "\n1.  Tap \"Choose ZIP file\" and pick the game's ZIP (for example Embervale-GBA-3-2.zip)."
                        + "\n2.  The game's C code is compiled on your phone in about a second - there is no ROM to build and no GitHub Actions run to wait for."
                        + "\n3.  Play with the on-screen buttons (or a keyboard / gamepad). The Back button opens the menu."
                        + "\n\nThe ZIP needs a src folder with game_init() and game_frame(), like the Embervale project. Progress is saved automatically and shared by every version of the same game.",
                14f, Color.rgb(170, 175, 195), false);
        how.setPadding(px(4), px(26), px(4), 0);
        col.addView(how);

        setContentView(scroll);
    }

    private void pick() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                "application/zip", "application/x-zip-compressed", "application/x-zip", "application/octet-stream"});
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i, REQ_PICK);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_PICK && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {
                // the picker did not offer a persistable grant; playing now still works
            }
            play(uri);
        }
    }

    private void play(Uri uri) {
        String name = ZipLoader.displayName(getContentResolver(), uri);
        prefs.edit().putString("last_uri", uri.toString()).putString("last_name", name).apply();
        Intent i = new Intent(this, PlayActivity.class);
        i.setData(uri);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(i);
    }

    private boolean canRead(Uri uri) {
        try {
            List<UriPermission> perms = getContentResolver().getPersistedUriPermissions();
            for (UriPermission p : perms) {
                if (p.getUri().equals(uri) && p.isReadPermission()) {
                    return true;
                }
            }
        } catch (Exception ignored) {
            // fall through
        }
        return false;
    }

    private void refreshLast() {
        if (lastButton == null) {
            return;
        }
        String s = prefs.getString("last_uri", null);
        if (s != null && canRead(Uri.parse(s))) {
            lastButton.setText("Play again: " + prefs.getString("last_name", "last ZIP"));
            lastButton.setVisibility(View.VISIBLE);
        } else {
            lastButton.setVisibility(View.GONE);
        }
    }
}
