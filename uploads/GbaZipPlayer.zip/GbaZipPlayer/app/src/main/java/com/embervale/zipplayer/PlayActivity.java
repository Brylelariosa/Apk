package com.embervale.zipplayer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;
import java.util.Locale;

/** Loads a ZIP, compiles the game inside it and runs it in real time. */
public class PlayActivity extends Activity implements GameView.Listener {
    private static final long FRAME_NS = 16743000L;   // 280896 cycles at 16.78 MHz

    private GameView view;
    private Runner runner;
    private Uri uri;
    private String zipName = "game.zip";
    private String saveKey = "game";
    private SharedPreferences prefs;
    private volatile int hwKeys;
    private volatile int padKeys;
    private volatile boolean muted;
    private boolean menuOpen;
    private AlertDialog dialog;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }
        prefs = getSharedPreferences("gbazip", MODE_PRIVATE);
        muted = prefs.getBoolean("muted", false);
        uri = getIntent().getData();
        if (uri == null) {
            finish();
            return;
        }
        zipName = ZipLoader.displayName(getContentResolver(), uri);
        saveKey = saveKeyFor(zipName);
        view = new GameView(this);
        view.setListener(this);
        view.setPixelPerfect(prefs.getBoolean("pixel_perfect", true));
        view.setStatus("Reading " + zipName + " ...");
        setContentView(view);
        hideSystemUi();
        runner = new Runner();
        runner.start();
    }

    /** "Embervale-GBA-3-2.zip" -> "embervale_gba": every version of a game shares one save slot. */
    static String saveKeyFor(String name) {
        String n = name;
        int dot = n.lastIndexOf('.');
        if (dot > 0) {
            n = n.substring(0, dot);
        }
        n = n.toLowerCase(Locale.ROOT);
        n = n.replaceAll("\\s*\\(\\d+\\)$", "");
        String prev;
        do {
            prev = n;
            n = n.replaceAll("[-_ .]*v?\\d+$", "");
        } while (!n.equals(prev) && n.length() > 0);
        if (n.length() == 0) {
            n = name.toLowerCase(Locale.ROOT);
        }
        n = n.replaceAll("[^a-z0-9]+", "_");
        return n.length() == 0 ? "game" : n;
    }

    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (runner != null) {
            runner.setPaused(true);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        hideSystemUi();
        if (runner != null && !menuOpen && !runner.faulted) {
            runner.setPaused(false);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            hideSystemUi();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dialog != null && dialog.isShowing()) {
            dialog.dismiss();
        }
        if (runner != null) {
            runner.shutdown();
            try {
                runner.join(4000);
            } catch (InterruptedException ignored) {
                // give up waiting
            }
            if (!runner.isAlive()) {
                try {
                    Native.unload();
                } catch (Throwable ignored) {
                    // native library was never loaded
                }
            }
        }
    }

    // ------------------------------------------------------------------ input

    private static int mapKey(int code) {
        switch (code) {
            case KeyEvent.KEYCODE_DPAD_UP: return GameView.K_UP;
            case KeyEvent.KEYCODE_DPAD_DOWN: return GameView.K_DOWN;
            case KeyEvent.KEYCODE_DPAD_LEFT: return GameView.K_LEFT;
            case KeyEvent.KEYCODE_DPAD_RIGHT: return GameView.K_RIGHT;
            case KeyEvent.KEYCODE_BUTTON_A:
            case KeyEvent.KEYCODE_X:
            case KeyEvent.KEYCODE_DPAD_CENTER: return GameView.K_A;
            case KeyEvent.KEYCODE_BUTTON_B:
            case KeyEvent.KEYCODE_Z: return GameView.K_B;
            case KeyEvent.KEYCODE_BUTTON_START:
            case KeyEvent.KEYCODE_ENTER: return GameView.K_START;
            case KeyEvent.KEYCODE_BUTTON_SELECT:
            case KeyEvent.KEYCODE_DEL:
            case KeyEvent.KEYCODE_SHIFT_RIGHT: return GameView.K_SELECT;
            case KeyEvent.KEYCODE_BUTTON_L1:
            case KeyEvent.KEYCODE_Q: return GameView.K_L;
            case KeyEvent.KEYCODE_BUTTON_R1:
            case KeyEvent.KEYCODE_E: return GameView.K_R;
            default: return 0;
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        int m = mapKey(keyCode);
        if (m != 0) {
            hwKeys |= m;
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        int m = mapKey(keyCode);
        if (m != 0) {
            hwKeys &= ~m;
            return true;
        }
        return super.onKeyUp(keyCode, event);
    }

    @Override
    public boolean onGenericMotionEvent(MotionEvent ev) {
        if ((ev.getSource() & InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
                && ev.getAction() == MotionEvent.ACTION_MOVE) {
            float hx = ev.getAxisValue(MotionEvent.AXIS_HAT_X);
            float hy = ev.getAxisValue(MotionEvent.AXIS_HAT_Y);
            float lx = ev.getAxisValue(MotionEvent.AXIS_X);
            float ly = ev.getAxisValue(MotionEvent.AXIS_Y);
            int k = 0;
            if (hx < -0.5f || lx < -0.5f) {
                k |= GameView.K_LEFT;
            }
            if (hx > 0.5f || lx > 0.5f) {
                k |= GameView.K_RIGHT;
            }
            if (hy < -0.5f || ly < -0.5f) {
                k |= GameView.K_UP;
            }
            if (hy > 0.5f || ly > 0.5f) {
                k |= GameView.K_DOWN;
            }
            padKeys = k;
            return true;
        }
        return super.onGenericMotionEvent(ev);
    }

    private int currentKeys() {
        int k = view.getTouchKeys() | hwKeys | padKeys;
        if ((k & (GameView.K_LEFT | GameView.K_RIGHT)) == (GameView.K_LEFT | GameView.K_RIGHT)) {
            k &= ~(GameView.K_LEFT | GameView.K_RIGHT);
        }
        if ((k & (GameView.K_UP | GameView.K_DOWN)) == (GameView.K_UP | GameView.K_DOWN)) {
            k &= ~(GameView.K_UP | GameView.K_DOWN);
        }
        return k;
    }

    // ------------------------------------------------------------------ menu

    @Override
    public void onMenuRequested() {
        showMenu();
    }

    @Override
    public void onBackPressed() {
        showMenu();
    }

    private void showMenu() {
        if (menuOpen || isFinishing() || runner == null) {
            return;
        }
        menuOpen = true;
        runner.setPaused(true);
        boolean pp = prefs.getBoolean("pixel_perfect", true);
        String[] items = new String[]{
                "Resume",
                "Restart game",
                muted ? "Sound: off  (tap to turn on)" : "Sound: on  (tap to mute)",
                pp ? "Scaling: pixel-perfect  (tap for fit-to-screen)" : "Scaling: fit-to-screen  (tap for pixel-perfect)",
                "Delete saved game",
                "Choose another ZIP"
        };
        AlertDialog.Builder b = new AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK);
        b.setTitle(zipName);
        b.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface d, int which) {
                onMenuChoice(which);
            }
        });
        b.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface d) {
                menuOpen = false;
                if (runner != null && !runner.faulted) {
                    runner.setPaused(false);
                }
            }
        });
        dialog = b.create();
        dialog.show();
    }

    private void onMenuChoice(int which) {
        switch (which) {
            case 1:
                runner.requestRestart();
                break;
            case 2:
                muted = !muted;
                prefs.edit().putBoolean("muted", muted).apply();
                runner.requestMuteUpdate();
                break;
            case 3: {
                boolean now = !prefs.getBoolean("pixel_perfect", true);
                prefs.edit().putBoolean("pixel_perfect", now).apply();
                view.setPixelPerfect(now);
                break;
            }
            case 4:
                runner.requestDeleteSave();
                break;
            case 5:
                finish();
                break;
            default:
                break;
        }
    }

    // ------------------------------------------------------------------ errors

    private void showFailure(final String title, final String msg, final boolean canRestart) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (isFinishing()) {
                    return;
                }
                AlertDialog.Builder b = new AlertDialog.Builder(PlayActivity.this, AlertDialog.THEME_DEVICE_DEFAULT_DARK);
                b.setTitle(title);
                b.setMessage(msg);
                b.setCancelable(false);
                if (canRestart) {
                    b.setNeutralButton("Restart game", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface d, int w) {
                            if (runner != null) {
                                runner.faulted = false;
                                runner.requestRestart();
                                runner.setPaused(false);
                            }
                        }
                    });
                }
                b.setPositiveButton("Back", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        finish();
                    }
                });
                dialog = b.create();
                dialog.show();
            }
        });
    }

    // ------------------------------------------------------------------ emulation thread

    private final class Runner extends Thread {
        private volatile boolean quit;
        private volatile boolean paused;
        private volatile boolean restart;
        private volatile boolean deleteSave;
        private volatile boolean muteUpdate;
        volatile boolean faulted;
        private final ByteBuffer fb = ByteBuffer.allocateDirect(240 * 160 * 4).order(ByteOrder.nativeOrder());
        private final Bitmap bmp = Bitmap.createBitmap(240, 160, Bitmap.Config.ARGB_8888);
        private AudioTrack track;
        private short[] abuf = new short[2048];
        private byte[] lastSaved = new byte[0x10000];

        Runner() {
            super(null, null, "gba-runner", 8L * 1024L * 1024L);
        }

        void setPaused(boolean p) {
            paused = p;
        }

        void shutdown() {
            quit = true;
            paused = false;
        }

        void requestRestart() {
            restart = true;
        }

        void requestDeleteSave() {
            deleteSave = true;
        }

        void requestMuteUpdate() {
            muteUpdate = true;
        }

        @Override
        public void run() {
            try {
                loadAndPlay();
            } catch (Throwable t) {
                String m = t.getMessage();
                showFailure("Cannot play this ZIP", t.getClass().getSimpleName() + (m != null ? ": " + m : ""), false);
            } finally {
                stopAudio();
            }
        }

        private void loadAndPlay() throws Exception {
            ZipLoader.Project p = ZipLoader.read(getContentResolver(), uri);
            if (p.paths.isEmpty()) {
                String msg = "No C source files were found in this ZIP.";
                if (p.romName != null) {
                    msg += "\n\nIt contains a ready-made ROM (" + p.romName + "). This player runs GBA games straight"
                            + " from their C source code; it cannot run built .gba ROM files.";
                }
                showFailure("Cannot play this ZIP", msg, false);
                return;
            }
            view.setStatus("Compiling " + p.paths.size() + " files ...");
            String[] paths = p.paths.toArray(new String[0]);
            byte[][] data = p.data.toArray(new byte[0][]);
            p = null;
            String err = Native.load(paths, data);
            paths = null;
            data = null;
            if (err != null) {
                showFailure("Compile error", err, false);
                return;
            }
            loadSave();
            err = Native.start();
            if (err != null) {
                showFailure("The game failed to start", err, false);
                return;
            }
            view.setStatus("");
            initAudio();

            long t0 = System.nanoTime();
            long frames = 0;
            int sinceSave = 0;
            while (!quit) {
                if (paused) {
                    if (track != null) {
                        try {
                            track.pause();
                            track.flush();
                        } catch (IllegalStateException ignored) {
                            // track already released
                        }
                    }
                    saveIfChanged();
                    while (paused && !quit) {
                        sleepMs(25);
                        if (restart || deleteSave || muteUpdate) {
                            break;
                        }
                    }
                    if (quit) {
                        break;
                    }
                    if (track != null && !paused) {
                        try {
                            track.play();
                        } catch (IllegalStateException ignored) {
                            // track already released
                        }
                    }
                    t0 = System.nanoTime();
                    frames = 0;
                    if (paused) {
                        // woke up only to service a request while the menu is open
                        if (muteUpdate) {
                            muteUpdate = false;
                            applyVolume();
                        }
                        if (restart || deleteSave) {
                            String e2 = serviceRequests();
                            if (e2 != null) {
                                showFailure("The game failed to start", e2, false);
                                return;
                            }
                        }
                        continue;
                    }
                }
                if (muteUpdate) {
                    muteUpdate = false;
                    applyVolume();
                }
                String e3 = serviceRequests();
                if (e3 != null) {
                    showFailure("The game failed to start", e3, false);
                    return;
                }
                String f = Native.frame(currentKeys());
                if (f != null) {
                    faulted = true;
                    paused = true;
                    showFailure("The game stopped", f, true);
                    continue;
                }
                Native.render(fb);
                fb.rewind();
                bmp.copyPixelsFromBuffer(fb);
                view.drawFrame(bmp);
                int n = Native.audio(abuf);
                if (track != null && n > 0) {
                    track.write(abuf, 0, n * 2);
                }
                frames++;
                long now = System.nanoTime();
                long ahead = frames * FRAME_NS - (now - t0);
                if (ahead > 40000000L) {
                    sleepNs(ahead - 20000000L);
                } else if (ahead < -250000000L) {
                    t0 = now;
                    frames = 0;
                }
                if (++sinceSave >= 120) {
                    sinceSave = 0;
                    saveIfChanged();
                }
            }
            saveIfChanged();
        }

        /** Handles restart / delete-save requests; returns an error message if the game fails to boot. */
        private String serviceRequests() {
            if (deleteSave) {
                deleteSave = false;
                saveFile().delete();
                Native.setSram(new byte[0x10000]);
                lastSaved = new byte[0x10000];
                restart = true;
            }
            if (restart) {
                restart = false;
                return Native.start();
            }
            return null;
        }

        private void applyVolume() {
            if (track != null) {
                try {
                    track.setVolume(muted ? 0f : 1f);
                } catch (IllegalStateException ignored) {
                    // track already released
                }
            }
        }

        private void initAudio() {
            try {
                int rate = AudioTrack.getNativeOutputSampleRate(AudioManager.STREAM_MUSIC);
                if (rate < 22050 || rate > 48000) {
                    rate = 44100;
                }
                Native.setRate(rate);
                abuf = new short[(rate / 40 + 64) * 2];
                int min = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT);
                int bytes = Math.max(min, (rate / 8) * 4);
                AudioTrack.Builder tb = new AudioTrack.Builder()
                        .setAudioAttributes(new AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_GAME)
                                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                                .build())
                        .setAudioFormat(new AudioFormat.Builder()
                                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                                .setSampleRate(rate)
                                .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                                .build())
                        .setBufferSizeInBytes(bytes)
                        .setTransferMode(AudioTrack.MODE_STREAM);
                if (Build.VERSION.SDK_INT >= 26) {
                    tb.setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY);
                }
                track = tb.build();
                applyVolume();
                track.play();
            } catch (Throwable t) {
                track = null;   // run silently; the frame timer keeps the speed right
            }
        }

        private void stopAudio() {
            if (track != null) {
                try {
                    track.stop();
                } catch (Throwable ignored) {
                    // already stopped
                }
                try {
                    track.release();
                } catch (Throwable ignored) {
                    // already released
                }
                track = null;
            }
        }

        private File saveFile() {
            File d = new File(getFilesDir(), "saves");
            if (!d.exists()) {
                d.mkdirs();
            }
            return new File(d, saveKey + ".sav");
        }

        private void loadSave() {
            byte[] s = new byte[0x10000];
            File f = saveFile();
            if (f.exists()) {
                FileInputStream in = null;
                try {
                    in = new FileInputStream(f);
                    int off = 0;
                    while (off < s.length) {
                        int r = in.read(s, off, s.length - off);
                        if (r <= 0) {
                            break;
                        }
                        off += r;
                    }
                } catch (IOException ignored) {
                    // start with an empty save
                } finally {
                    if (in != null) {
                        try {
                            in.close();
                        } catch (IOException ignored) {
                            // nothing to do
                        }
                    }
                }
            }
            Native.setSram(s);
            lastSaved = s.clone();
        }

        private void saveIfChanged() {
            byte[] s = Native.getSram();
            if (s == null || Arrays.equals(s, lastSaved)) {
                return;
            }
            File f = saveFile();
            File t = new File(f.getPath() + ".tmp");
            try {
                FileOutputStream o = new FileOutputStream(t);
                try {
                    o.write(s);
                    o.getFD().sync();
                } finally {
                    o.close();
                }
                if (!t.renameTo(f)) {
                    f.delete();
                    t.renameTo(f);
                }
                lastSaved = s;
            } catch (IOException ignored) {
                // try again at the next checkpoint
            }
        }

        private void sleepMs(long ms) {
            try {
                Thread.sleep(ms);
            } catch (InterruptedException ignored) {
                // ignore
            }
        }

        private void sleepNs(long ns) {
            try {
                Thread.sleep(ns / 1000000L, (int) (ns % 1000000L));
            } catch (InterruptedException ignored) {
                // ignore
            }
        }
    }
}
