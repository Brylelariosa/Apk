package com.embervale.zipplayer;

import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Reads the C sources (and Makefile) of a game project straight out of a ZIP file. */
final class ZipLoader {
    static final class Project {
        final ArrayList<String> paths = new ArrayList<String>();
        final ArrayList<byte[]> data = new ArrayList<byte[]>();
        String romName;
    }

    private static final long MAX_TOTAL = 200L * 1024L * 1024L;

    private ZipLoader() { }

    static Project read(ContentResolver cr, Uri uri) throws IOException {
        Project p = new Project();
        InputStream raw = cr.openInputStream(uri);
        if (raw == null) {
            throw new IOException("Cannot open the selected file");
        }
        ZipInputStream zin = new ZipInputStream(new BufferedInputStream(raw, 1 << 16));
        try {
            byte[] buf = new byte[1 << 16];
            long total = 0;
            ZipEntry e;
            while ((e = zin.getNextEntry()) != null) {
                if (e.isDirectory()) {
                    continue;
                }
                String name = e.getName().replace('\\', '/');
                String lower = name.toLowerCase(Locale.ROOT);
                if (lower.endsWith(".gba") || lower.endsWith(".agb")) {
                    p.romName = name;
                }
                String base = name.substring(name.lastIndexOf('/') + 1);
                boolean wanted = lower.endsWith(".c") || lower.endsWith(".h")
                        || base.equals("Makefile") || base.equals("makefile") || base.equals("GNUmakefile");
                if (!wanted) {
                    continue;
                }
                ByteArrayOutputStream bos = new ByteArrayOutputStream(16 * 1024);
                int n;
                while ((n = zin.read(buf)) > 0) {
                    bos.write(buf, 0, n);
                    total += n;
                    if (total > MAX_TOTAL) {
                        throw new IOException("The ZIP is too large");
                    }
                }
                p.paths.add(name);
                p.data.add(bos.toByteArray());
            }
        } finally {
            try {
                zin.close();
            } catch (IOException ignored) {
                // nothing to do
            }
        }
        return p;
    }

    static String displayName(ContentResolver cr, Uri uri) {
        Cursor c = null;
        try {
            c = cr.query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (c != null && c.moveToFirst()) {
                String s = c.getString(0);
                if (s != null && s.length() > 0) {
                    return s;
                }
            }
        } catch (Exception ignored) {
            // fall through to the URI based name
        } finally {
            if (c != null) {
                c.close();
            }
        }
        String last = uri.getLastPathSegment();
        return last != null ? last : "game.zip";
    }
}
