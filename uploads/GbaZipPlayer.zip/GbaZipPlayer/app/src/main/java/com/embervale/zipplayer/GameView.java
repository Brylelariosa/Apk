package com.embervale.zipplayer;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

/** The game picture plus the on-screen GBA controls (multi-touch). */
public class GameView extends SurfaceView implements SurfaceHolder.Callback {
    interface Listener {
        void onMenuRequested();
    }

    // GBA KEYINPUT bit order
    static final int K_A = 1, K_B = 2, K_SELECT = 4, K_START = 8, K_RIGHT = 16, K_LEFT = 32, K_UP = 64, K_DOWN = 128, K_R = 256, K_L = 512;

    private final SurfaceHolder holder;
    private final Paint picturePaint = new Paint();
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint label = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Rect src = new Rect(0, 0, 240, 160);
    private final RectF game = new RectF();
    private final RectF tmp = new RectF();
    private final RectF startR = new RectF();
    private final RectF selectR = new RectF();
    private final RectF lR = new RectF();
    private final RectF rR = new RectF();
    private final RectF menuR = new RectF();
    private final float dp;

    private volatile boolean ready;
    private volatile int touchKeys;
    private volatile String status = "";
    private volatile boolean pixelPerfect = true;
    private int viewW, viewH;
    private boolean portrait;
    private float dpadX, dpadY, dpadR, aX, aY, bX, bY, btnR;
    private Listener listener;

    public GameView(Context context) {
        super(context);
        dp = context.getResources().getDisplayMetrics().density;
        holder = getHolder();
        holder.addCallback(this);
        picturePaint.setFilterBitmap(false);
        label.setTextAlign(Paint.Align.CENTER);
        label.setColor(Color.WHITE);
        label.setFakeBoldText(true);
        setFocusable(true);
        setFocusableInTouchMode(true);
    }

    void setListener(Listener l) {
        listener = l;
    }

    void setStatus(String s) {
        status = s == null ? "" : s;
    }

    void setPixelPerfect(boolean on) {
        pixelPerfect = on;
        computeLayout();
    }

    int getTouchKeys() {
        return touchKeys;
    }

    @Override
    public void surfaceCreated(SurfaceHolder h) {
        ready = true;
    }

    @Override
    public void surfaceChanged(SurfaceHolder h, int format, int w, int hh) {
        viewW = w;
        viewH = hh;
        computeLayout();
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder h) {
        ready = false;
    }

    private void computeLayout() {
        if (viewW <= 0 || viewH <= 0) {
            return;
        }
        portrait = viewH >= viewW;
        float top;
        float availH;
        if (portrait) {
            top = 28f * dp;
            availH = viewH * 0.45f;
        } else {
            top = 0f;
            availH = viewH;
        }
        float scale = Math.min(viewW / 240f, availH / 160f);
        if (pixelPerfect && scale >= 1f) {
            scale = (float) Math.floor(scale);
        }
        float gw = 240f * scale;
        float gh = 160f * scale;
        float gx = (viewW - gw) / 2f;
        float gy = portrait ? top : (viewH - gh) / 2f;
        game.set(gx, gy, gx + gw, gy + gh);

        if (portrait) {
            float rTop = game.bottom + 10f * dp;
            float rH = Math.max(120f * dp, viewH - rTop - 10f * dp);
            float cy = rTop + rH * 0.50f;
            dpadR = Math.min(viewW * 0.21f, rH * 0.30f);
            dpadX = viewW * 0.27f;
            dpadY = cy;
            btnR = Math.min(viewW * 0.10f, rH * 0.13f);
            aX = viewW * 0.85f;
            aY = cy - btnR * 0.85f;
            bX = viewW * 0.65f;
            bY = cy + btnR * 0.85f;
            lR.set(12f * dp, rTop, 112f * dp, rTop + 46f * dp);
            rR.set(viewW - 112f * dp, rTop, viewW - 12f * dp, rTop + 46f * dp);
            menuR.set(viewW / 2f - 44f * dp, rTop + 4f * dp, viewW / 2f + 44f * dp, rTop + 40f * dp);
            float sy = rTop + rH * 0.90f;
            selectR.set(viewW * 0.38f - 44f * dp, sy - 17f * dp, viewW * 0.38f + 44f * dp, sy + 17f * dp);
            startR.set(viewW * 0.62f - 44f * dp, sy - 17f * dp, viewW * 0.62f + 44f * dp, sy + 17f * dp);
        } else {
            dpadR = 78f * dp;
            dpadX = Math.max(dpadR + 14f * dp, viewW * 0.13f);
            dpadY = viewH - dpadR - 22f * dp;
            btnR = 36f * dp;
            aX = viewW - Math.max(btnR + 20f * dp, viewW * 0.07f);
            aY = viewH - 150f * dp;
            bX = aX - btnR * 2.1f;
            bY = aY + btnR * 1.1f;
            lR.set(16f * dp, 10f * dp, 106f * dp, 52f * dp);
            rR.set(viewW - 106f * dp, 10f * dp, viewW - 16f * dp, 52f * dp);
            menuR.set(viewW / 2f - 44f * dp, 8f * dp, viewW / 2f + 44f * dp, 40f * dp);
            float sy = viewH - 26f * dp;
            selectR.set(viewW / 2f - 98f * dp, sy - 16f * dp, viewW / 2f - 10f * dp, sy + 16f * dp);
            startR.set(viewW / 2f + 10f * dp, sy - 16f * dp, viewW / 2f + 98f * dp, sy + 16f * dp);
        }
    }

    /** Draws one emulated frame (called from the emulation thread). */
    void drawFrame(Bitmap bmp) {
        if (!ready) {
            return;
        }
        Canvas c = null;
        try {
            c = holder.lockCanvas();
            if (c == null) {
                return;
            }
            c.drawColor(Color.BLACK);
            if (bmp != null) {
                picturePaint.setFilterBitmap(!pixelPerfect);
                c.drawBitmap(bmp, src, game, picturePaint);
            }
            drawControls(c);
            drawStatus(c);
        } catch (Throwable ignored) {
            // surface went away while drawing
        } finally {
            if (c != null) {
                try {
                    holder.unlockCanvasAndPost(c);
                } catch (Throwable ignored) {
                    // surface went away
                }
            }
        }
    }

    private void drawStatus(Canvas c) {
        String s = status;
        if (s.length() == 0) {
            return;
        }
        label.setTextSize(18f * dp);
        label.setColor(Color.WHITE);
        label.setShadowLayer(4f * dp, 0f, 0f, Color.BLACK);
        float y = game.centerY() - (label.ascent() + label.descent()) / 2f;
        c.drawText(s, viewW / 2f, y, label);
        label.clearShadowLayer();
    }

    private void drawControls(Canvas c) {
        int k = touchKeys;
        int a = portrait ? 210 : 120;
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(Color.argb(a / 4, 255, 255, 255));
        c.drawCircle(dpadX, dpadY, dpadR, fill);
        float t = dpadR * 0.30f;
        float arm = dpadR * 0.88f;
        float rad = t * 0.7f;
        fill.setColor(Color.argb(a, 58, 64, 88));
        tmp.set(dpadX - arm, dpadY - t, dpadX + arm, dpadY + t);
        c.drawRoundRect(tmp, rad, rad, fill);
        tmp.set(dpadX - t, dpadY - arm, dpadX + t, dpadY + arm);
        c.drawRoundRect(tmp, rad, rad, fill);
        fill.setColor(Color.argb(a, 255, 160, 50));
        if ((k & K_LEFT) != 0) {
            tmp.set(dpadX - arm, dpadY - t, dpadX - t * 0.3f, dpadY + t);
            c.drawRoundRect(tmp, rad, rad, fill);
        }
        if ((k & K_RIGHT) != 0) {
            tmp.set(dpadX + t * 0.3f, dpadY - t, dpadX + arm, dpadY + t);
            c.drawRoundRect(tmp, rad, rad, fill);
        }
        if ((k & K_UP) != 0) {
            tmp.set(dpadX - t, dpadY - arm, dpadX + t, dpadY - t * 0.3f);
            c.drawRoundRect(tmp, rad, rad, fill);
        }
        if ((k & K_DOWN) != 0) {
            tmp.set(dpadX - t, dpadY + t * 0.3f, dpadX + t, dpadY + arm);
            c.drawRoundRect(tmp, rad, rad, fill);
        }
        circleButton(c, aX, aY, "A", (k & K_A) != 0, a);
        circleButton(c, bX, bY, "B", (k & K_B) != 0, a);
        pill(c, startR, "START", (k & K_START) != 0, a);
        pill(c, selectR, "SELECT", (k & K_SELECT) != 0, a);
        pill(c, lR, "L", (k & K_L) != 0, a);
        pill(c, rR, "R", (k & K_R) != 0, a);
        pill(c, menuR, "MENU", false, a);
    }

    private void circleButton(Canvas c, float x, float y, String text, boolean down, int a) {
        fill.setColor(down ? Color.argb(a, 255, 160, 50) : Color.argb(a, 58, 64, 88));
        c.drawCircle(x, y, btnR, fill);
        label.setTextSize(btnR * 0.9f);
        label.setColor(Color.argb(Math.min(255, a + 40), 255, 255, 255));
        c.drawText(text, x, y - (label.ascent() + label.descent()) / 2f, label);
    }

    private void pill(Canvas c, RectF r, String text, boolean down, int a) {
        fill.setColor(down ? Color.argb(a, 255, 160, 50) : Color.argb(a, 58, 64, 88));
        float rad = r.height() / 2f;
        c.drawRoundRect(r, rad, rad, fill);
        label.setTextSize(r.height() * 0.40f);
        label.setColor(Color.argb(Math.min(255, a + 40), 255, 255, 255));
        c.drawText(text, r.centerX(), r.centerY() - (label.ascent() + label.descent()) / 2f, label);
    }

    private boolean inRect(RectF r, float x, float y) {
        float pad = 6f * dp;
        return x >= r.left - pad && x <= r.right + pad && y >= r.top - pad && y <= r.bottom + pad;
    }

    private int hit(float x, float y) {
        int k = 0;
        float dx = x - dpadX;
        float dy = y - dpadY;
        float lim = dpadR * 1.3f;
        if (dx * dx + dy * dy <= lim * lim) {
            float t = dpadR * 0.30f;
            if (dx < -t) {
                k |= K_LEFT;
            } else if (dx > t) {
                k |= K_RIGHT;
            }
            if (dy < -t) {
                k |= K_UP;
            } else if (dy > t) {
                k |= K_DOWN;
            }
        }
        float rr = btnR * 1.2f;
        rr *= rr;
        if ((x - aX) * (x - aX) + (y - aY) * (y - aY) <= rr) {
            k |= K_A;
        }
        if ((x - bX) * (x - bX) + (y - bY) * (y - bY) <= rr) {
            k |= K_B;
        }
        if (inRect(startR, x, y)) {
            k |= K_START;
        }
        if (inRect(selectR, x, y)) {
            k |= K_SELECT;
        }
        if (inRect(lR, x, y)) {
            k |= K_L;
        }
        if (inRect(rR, x, y)) {
            k |= K_R;
        }
        return k;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int action = e.getActionMasked();
        int keys = 0;
        boolean menuHit = false;
        if (action != MotionEvent.ACTION_UP && action != MotionEvent.ACTION_CANCEL) {
            int skip = (action == MotionEvent.ACTION_POINTER_UP) ? e.getActionIndex() : -1;
            for (int i = 0; i < e.getPointerCount(); i++) {
                if (i == skip) {
                    continue;
                }
                float x = e.getX(i);
                float y = e.getY(i);
                keys |= hit(x, y);
                boolean down = action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN;
                if (down && i == e.getActionIndex() && inRect(menuR, x, y)) {
                    menuHit = true;
                }
            }
        }
        if ((keys & (K_LEFT | K_RIGHT)) == (K_LEFT | K_RIGHT)) {
            keys &= ~(K_LEFT | K_RIGHT);
        }
        if ((keys & (K_UP | K_DOWN)) == (K_UP | K_DOWN)) {
            keys &= ~(K_UP | K_DOWN);
        }
        touchKeys = keys;
        if (menuHit && listener != null) {
            listener.onMenuRequested();
        }
        return true;
    }
}
