# What changed in this build (faster + better enhancement, tuned for the Infinix HOT 11 2022)

Full explanation, measurements and honest limitations: README.md -> "Performance and quality work".
Trained models are unaffected: the network architecture and the checkpoint/parameter layout are unchanged,
so every existing checkpoint loads exactly as before.

## In-app crash log (added after build 6)
Crash diagnosis with no PC/adb/root: Settings -> View Crash Log, and a prompt at launch if the last run ended badly.
It also recovers crashes no in-process code can catch (native/C++ crashes, Android's low-memory kills) on the NEXT launch,
from Android's own exit record (Android 11+: reason, signal number, RAM held) plus an on-disk log of what the app was doing,
band by band, when it died. Copy / Share / Clear buttons; written, NOT compiled or run (no Kotlin toolchain here).

| File | Status | Purpose |
|---|---|---|
| utils/PersistentLog.kt | new | append-only on-disk log that survives the process dying; one file per run + the previous run |
| utils/ProcessExitHistory.kt | new | reads ActivityManager.getHistoricalProcessExitReasons (Android 11+) and explains it in plain English |
| utils/MemoryStats.kt | new | one-line java/native/system memory snapshot used in the breadcrumbs |
| utils/CrashReporter.kt | modified | still writes last_crash.txt on Java crashes; now also checks how the previous run ended and builds the log text |
| utils/NovaLog.kt | modified | every line is also written to PersistentLog; new `breadcrumb()` (disk only) for per-band / per-filter markers |
| ui/screens/CrashLogScreen.kt | new | the screen: Copy / Share / Clear |
| ui/navigation/NovaNavHost.kt, NovaDestinations.kt | modified | route + the "app stopped unexpectedly" prompt |
| ui/screens/SettingsScreen.kt | modified | "View Crash Log" button (screen is now scrollable) |
| ui/viewmodel/EnhanceViewModel.kt, ai/engine/EnhancementEngine.kt, BandProcessor.kt | modified | ENHANCE_BEGIN/END/FAIL/CANCEL markers + per-band and per-filter breadcrumbs with memory use |
| app/proguard-rules.pro | modified | keep names + line numbers (`-dontobfuscate`) so release stack traces are readable on the phone |

## Native (C++)  app/src/main/cpp
| File | Status | Purpose |
|---|---|---|
| nn/simd.h | new | 4-lane SIMD layer: NEON AArch64, NEON ARMv7, portable fallback |
| nn/conv_kernels.{h,cpp} | new | register-blocked 3x3 conv kernels (forward, gated backward-data, weight-gradient) |
| nn/weights.{h,cpp} | new | repack flat params into kernel layouts (checkpoint format untouched) |
| nn/inference.{h,cpp} | new | fused streaming whole-image inference, column strips, seam-free |
| nn/training.{h,cpp} | new | parallel forward/backward over (sample x row-band) jobs |
| util/thread_pool.{h,cpp} | new | persistent worker pool, dynamic job scheduling (big.LITTLE friendly) |
| nn/network.{h,cpp} | modified | slim front door: init + optimizer; delegates to the above. Public API unchanged (trainStep gains a defaulted `threads`) |
| filters/convolution.{h,cpp} | modified | bilateral LUTs, blur fast path, row-parallel; output bit-identical |
| native-lib.cpp | modified | new JNI: nativeInferRegion, threads for train step, workspace release, backend name; image ceiling 4096 -> 16384 |
| CMakeLists.txt, ../../build.gradle.kts | modified | new sources; -O3 in every build type; NEON forced on armeabi-v7a |

## Kotlin  app/src/main/java/com/novaenhance/ai
| File | Status | Purpose |
|---|---|---|
| ai/engine/BandProcessor.kt | new | seam-free band-by-band processing (replaces TileProcessor) |
| ai/engine/TileProcessor.kt | removed | superseded by BandProcessor |
| ai/engine/EnhancementEngine.kt | modified | uses bands + whole-band native inference; same public API |
| ai/engine/NativeNeuralEngine.kt, NovaModelEngine.kt | modified | inferRegion, thread budget, workspace release, backend name |
| ai/engine/PixelBufferOps.kt | modified | cropRect, transformSquare (rotate/mirror augmentation) |
| training/trainer/TrainingPatchLoader.kt | new | background prefetch, 4 augmented patches per decoded crop |
| training/trainer/ModelTrainer.kt, AdaptiveTrainingController.kt | modified | uses the loader and thread budget; frees native workspace after a session |
| utils/ComputeBudget.kt | new | thread counts per workload (8 enhance / 6 train on an 8-core phone) |
| utils/Constants.kt, DiagnosticsReport.kt, ThermalGovernor.kt, ... | modified | new constants, "Native kernels:" line in debug info, doc updates |

## Tests and tooling
- app/src/test: PixelBufferOpsTest (+8 tests), ComputeBudgetTest (new) - written, NOT run (no Kotlin toolchain here).
- tools/nn_verification: run_all.sh, kernel_check, equivalence_check, bench, neon_shim.h, reference_network.cpp.
- tools/filter_verification: bit-exact filter check against the original implementation.
