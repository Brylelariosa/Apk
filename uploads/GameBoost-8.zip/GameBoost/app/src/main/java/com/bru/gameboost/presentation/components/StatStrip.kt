package com.bru.gameboost.presentation.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.bru.gameboost.domain.model.CleanResult
import com.bru.gameboost.domain.model.CpuLoad
import com.bru.gameboost.domain.model.DeviceSnapshot
import com.bru.gameboost.domain.model.Latency
import com.bru.gameboost.domain.model.NetworkStatus
import com.bru.gameboost.domain.model.PingQuality
import com.bru.gameboost.domain.model.isDown
import com.bru.gameboost.domain.model.pingMs
import com.bru.gameboost.presentation.RamCleanState
import com.bru.gameboost.presentation.SnapshotFormatter
import kotlin.math.roundToInt

// The temperature meter spans a realistic phone range; amber starts a few degrees before the alert.
private const val TEMP_BAR_MIN_C = 25f
private const val TEMP_BAR_MAX_C = 50f
private const val WARM_MARGIN_C = 3f

// The ping meter is full at this round trip; anything slower just pins the bar.
private const val PING_BAR_MAX_MS = 200f
private val WarmColor = Color(0xFFFFB300)

private enum class CleanPhase { IDLE, RUNNING, RESULT }

/**
 * The whole "this device right now" readout in one short card: four mini meters and the Free RAM
 * action. It replaces a tall stack of bars so the games below it stay on screen. Tapping the
 * meters asks the screen to show [StatDetails] (ping notes, battery, thermal) as its own item.
 */
@Composable
fun StatStrip(
    snapshot: DeviceSnapshot?,
    alertAtC: Float,
    ramClean: RamCleanState,
    expanded: Boolean,
    onToggleExpanded: () -> Unit,
    onFreeRam: () -> Unit,
    onOpenBatterySaver: () -> Unit,
    modifier: Modifier = Modifier
) {
    val usedMb = snapshot?.ramUsedMb
    val totalMb = snapshot?.ramTotalMb
    val ramFraction = if (usedMb != null && totalMb != null && totalMb > 0) usedMb.toFloat() / totalMb else null
    val cpuFraction = (snapshot?.cpuLoad as? CpuLoad.Reading)?.let { it.percent / 100f }
    val cpuApprox = snapshot?.cpuLoad is CpuLoad.Estimated
    val tempC = snapshot?.batteryTempC
    val tempFraction = tempC?.let { (it - TEMP_BAR_MIN_C) / (TEMP_BAR_MAX_C - TEMP_BAR_MIN_C) }
    val tempColor = when {
        tempC != null && tempC >= alertAtC -> MaterialTheme.colorScheme.error
        tempC != null && tempC >= alertAtC - WARM_MARGIN_C -> WarmColor
        else -> MaterialTheme.colorScheme.primary
    }
    val network = snapshot?.network
    val pingMs = network.pingMs
    val pingColor = when {
        network.isDown -> MaterialTheme.colorScheme.error
        pingMs == null -> MaterialTheme.colorScheme.primary
        else -> when (PingQuality.of(pingMs)) {
            PingQuality.GOOD -> MaterialTheme.colorScheme.primary
            PingQuality.FAIR -> WarmColor
            PingQuality.POOR -> MaterialTheme.colorScheme.error
        }
    }
    // A dead connection fills the bar red: it is the worst reading, not a missing one.
    val pingFraction = if (network.isDown) 1f else pingMs?.let { it / PING_BAR_MAX_MS }

    // The freed figure counts up from zero each time a clean finishes. It starts "done" so that
    // coming back to the screen doesn't replay an old result.
    val lastClean = ramClean.last
    val countUp = remember { Animatable(1f) }
    LaunchedEffect(ramClean.running) {
        if (ramClean.running) {
            countUp.snapTo(0f)
        } else {
            countUp.animateTo(1f, tween(durationMillis = 700, easing = FastOutSlowInEasing))
        }
    }
    val phase = when {
        ramClean.running -> CleanPhase.RUNNING
        lastClean != null -> CleanPhase.RESULT
        else -> CleanPhase.IDLE
    }

    val chevronAngle by animateFloatAsState(
        targetValue = if (expanded) 180f else 0f,
        animationSpec = tween(durationMillis = 250),
        label = "statChevron"
    )

    Card(modifier = modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp)) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(MaterialTheme.shapes.small)
                    .clickable(
                        onClickLabel = if (expanded) "Hide details" else "Show details",
                        onClick = onToggleExpanded
                    )
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    MiniMeter(
                        label = "CPU",
                        fraction = cpuFraction,
                        barColor = MaterialTheme.colorScheme.primary,
                        valueText = { f -> (if (cpuApprox) "~" else "") + "${(f * 100f).roundToInt()}%" },
                        modifier = Modifier.weight(1f)
                    )
                    MiniMeter(
                        label = "RAM",
                        fraction = ramFraction,
                        barColor = MaterialTheme.colorScheme.primary,
                        valueText = { f -> "${(f * 100f).roundToInt()}%" },
                        modifier = Modifier.weight(1f),
                        scanning = ramClean.running
                    )
                    MiniMeter(
                        label = "Ping",
                        fraction = pingFraction,
                        barColor = pingColor,
                        valueText = { _ -> pingShort(network) },
                        modifier = Modifier.weight(1f)
                    )
                    MiniMeter(
                        label = "Temp",
                        fraction = tempFraction,
                        barColor = tempColor,
                        valueText = { _ -> tempC?.let { SnapshotFormatter.temperature(it) } ?: "—" },
                        modifier = Modifier.weight(1f)
                    )
                }
                // Sits in the empty right end of the last label, so the meters keep their width.
                Icon(
                    imageVector = Icons.Default.KeyboardArrowDown,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .size(16.dp)
                        .graphicsLayer { rotationZ = chevronAngle }
                )
            }

            if (snapshot?.powerSaveMode == true) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Battery Saver is on — it can limit performance while you play.",
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier
                            .weight(1f)
                            .padding(end = 8.dp)
                    )
                    TextButton(
                        onClick = onOpenBatterySaver,
                        contentPadding = PaddingValues(horizontal = 8.dp)
                    ) { Text("Settings") }
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AnimatedContent(
                    targetState = phase,
                    transitionSpec = { fadeIn(tween(200)) togetherWith fadeOut(tween(120)) },
                    modifier = Modifier
                        .weight(1f)
                        .padding(end = 8.dp),
                    label = "cleanLine"
                ) { shown ->
                    when (shown) {
                        CleanPhase.RUNNING -> StatusText("Closing background apps…")
                        CleanPhase.RESULT ->
                            if (lastClean != null) {
                                CleanResultLine(result = lastClean, progress = { countUp.value })
                            } else {
                                StatusText("")
                            }
                        CleanPhase.IDLE -> StatusText("Close cached apps to free RAM")
                    }
                }
                FreeRamButton(running = ramClean.running, onClick = onFreeRam)
            }
        }
    }
}

/** The second line of detail under the strip: what the four meters can't say in one word. */
@Composable
fun StatDetails(snapshot: DeviceSnapshot, modifier: Modifier = Modifier) {
    Card(modifier = modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            DetailLine("RAM", "${SnapshotFormatter.ram(snapshot)} in use")
            SnapshotFormatter.pingCaption(snapshot)?.let { DetailLine("Ping", it) }
            SnapshotFormatter.cpuUnavailableNote(snapshot)?.let { DetailLine("CPU", it) }
            DetailLine(
                "Battery",
                listOfNotNull(
                    SnapshotFormatter.battery(snapshot),
                    SnapshotFormatter.throttling(snapshot)
                ).joinToString(" · ")
            )
        }
    }
}

@Composable
private fun DetailLine(label: String, value: String) {
    Row {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.width(56.dp)
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.weight(1f)
        )
    }
}

/**
 * One label, one number, one thin bar. The number is derived from the animated bar fill, so the
 * digits count smoothly along with the bar instead of jumping ahead of it. While [scanning] a
 * highlight sweeps along the bar: the "working on it" cue for a RAM clean.
 */
@Composable
private fun MiniMeter(
    label: String,
    fraction: Float?,
    barColor: Color,
    valueText: (Float) -> String,
    modifier: Modifier = Modifier,
    scanning: Boolean = false
) {
    val fill by animateFloatAsState(
        targetValue = (fraction ?: 0f).coerceIn(0f, 1f),
        animationSpec = tween(durationMillis = 700),
        label = "meterFill"
    )
    val color by animateColorAsState(
        targetValue = barColor,
        animationSpec = tween(durationMillis = 400),
        label = "meterColor"
    )
    val track = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)

    Column(modifier = modifier) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1
        )
        Text(
            text = if (fraction == null) "—" else valueText(fill),
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Clip
        )
        Box(
            modifier = Modifier
                .padding(top = 4.dp)
                .fillMaxWidth()
                .height(4.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(track)
                .drawBehind {
                    drawRoundRect(
                        color = color,
                        size = Size(size.width * fill, size.height),
                        cornerRadius = CornerRadius(size.height / 2f)
                    )
                }
        ) {
            if (scanning) {
                ScanSweep(color = MaterialTheme.colorScheme.primary, modifier = Modifier.matchParentSize())
            }
        }
    }
}

/** A bright segment that runs along the bar. Only composed while a clean runs, so it costs nothing otherwise. */
@Composable
private fun ScanSweep(color: Color, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "scan")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 850, easing = LinearEasing)
        ),
        label = "scanPhase"
    )
    Canvas(modifier = modifier) {
        val segment = size.width * 0.4f
        val left = ((size.width + segment) * phase - segment).coerceAtLeast(0f)
        val right = ((size.width + segment) * phase).coerceAtMost(size.width)
        if (right > left) {
            drawRect(
                color = color,
                topLeft = Offset(left, 0f),
                size = Size(right - left, size.height)
            )
        }
    }
}

@Composable
private fun StatusText(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        maxLines = 2,
        overflow = TextOverflow.Ellipsis
    )
}

/** "Freed ≈ N MB", with N counting up as [progress] runs from 0 to 1. Only this line recomposes while it counts. */
@Composable
private fun CleanResultLine(result: CleanResult, progress: () -> Float) {
    val text = if (result.freedMb > 0) {
        val shown = (result.freedMb * progress()).toLong()
        "Freed ≈ $shown MB · ${result.appsChecked} apps"
    } else {
        "Already clean · ${result.appsChecked} apps"
    }
    StatusText(text)
}

@Composable
private fun FreeRamButton(running: Boolean, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        contentPadding = PaddingValues(horizontal = 14.dp),
        modifier = Modifier.height(36.dp)
    ) {
        Box(contentAlignment = Alignment.Center, modifier = Modifier.size(16.dp)) {
            Crossfade(targetState = running, label = "freeRamIcon") { busy ->
                if (busy) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        strokeWidth = 2.dp,
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                } else {
                    BoltMark(
                        modifier = Modifier.size(16.dp),
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                }
            }
        }
        Spacer(Modifier.width(6.dp))
        Text("Free RAM")
    }
}

/** The ping meter's value, short enough for a quarter-width column ("38 ms", "Offline", "No reply"). */
private fun pingShort(status: NetworkStatus?): String = when (status) {
    null -> "—"
    NetworkStatus.Offline -> "Offline"
    is NetworkStatus.Online -> when (val latency = status.latency) {
        is Latency.Measured -> "${latency.medianMs} ms"
        Latency.Unreachable -> "No reply"
    }
}
