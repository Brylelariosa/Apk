#!/usr/bin/env bash
# Reproducible benchmark driver for the NovaEnhance native core (rust/examples/bench.rs).
#
#   tools/bench.sh                         quick suite on this computer
#   tools/bench.sh --full                  the whole suite (12 MP, 48 MP slice, training, kernel race)
#   tools/bench.sh --full --long 600       ... plus a 600 s sustained run that reports speed drift
#   tools/bench.sh --full --only "12 MP"  only the cases whose name contains that text (repeat the option for more)
#   tools/bench.sh --target android        build for arm64-v8a with cargo-ndk, push to a USB-connected phone, run there
#   tools/bench.sh --baseline /path/to/old/NovaEnhanceAI   also run the SAME benchmark against an older source tree
#                                          and print old and new side by side (that tree needs only a rust/ folder)
#
# Output: one `key=value` block per case (as printed by the example) in bench-results-<time>.txt next to this
# script's repo root, plus a short summary table on screen. NOTHING is estimated: every number is a measurement made
# by this run. Run it a few times and compare medians - on a phone the first run after a cold start is slower, and
# the result depends on temperature and on which cores the system gives the process.
#
# Why one process per case: the example reports peak memory (VmHWM), which only ever grows within a process.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TARGET=host
SUITE=quick
LONG=0
BASELINE=""
ONLY=()
THREADS_ARG=()
while [[ $# -gt 0 ]]; do
  case "$1" in
    --target) TARGET="$2"; shift 2 ;;
    --full) SUITE=full; shift ;;
    --quick) SUITE=quick; shift ;;
    --long) LONG="$2"; shift 2 ;;
    --baseline) BASELINE="$2"; shift 2 ;;
    --only) ONLY+=("$2"); shift 2 ;;
    --threads) THREADS_ARG=(--threads "$2"); shift 2 ;;
    -h|--help) sed -n '2,21p' "${BASH_SOURCE[0]}"; exit 0 ;;
    *) echo "unknown option: $1 (see --help)" >&2; exit 2 ;;
  esac
done

STAMP="$(date +%Y%m%d-%H%M%S)"
OUT="$ROOT/bench-results-$STAMP.txt"

build_example() { # $1 = rust dir
  if [[ "$TARGET" == android ]]; then
    command -v cargo-ndk >/dev/null || { echo "cargo-ndk is required for --target android (cargo install cargo-ndk)" >&2; exit 1; }
    (cd "$1" && cargo ndk -t arm64-v8a build --release --example bench >&2)
    echo "$1/target/aarch64-linux-android/release/examples/bench"
  else
    (cd "$1" && cargo build --release --example bench >&2)
    echo "$1/target/release/examples/bench"
  fi
}

NEW_BIN="$(build_example "$ROOT/rust")"
OLD_BIN=""
if [[ -n "$BASELINE" ]]; then
  [[ -d "$BASELINE/rust" ]] || { echo "--baseline: $BASELINE/rust not found" >&2; exit 1; }
  # The example uses only the crate's public API, so the same file builds against the older tree.
  mkdir -p "$BASELINE/rust/examples"
  # (the blocks marked NEW-ONLY use functions an older tree does not have, so they are left out of that copy)
  sed '/NEW-ONLY-BEGIN/,/NEW-ONLY-END/d' "$ROOT/rust/examples/bench.rs" > "$BASELINE/rust/examples/bench.rs"
  OLD_BIN="$(build_example "$BASELINE/rust")"
fi

RUN() { # $1 = label, $2 = binary, rest = bench args
  local label="$1" bin="$2"; shift 2
  if [[ "$TARGET" == android ]]; then
    local remote="/data/local/tmp/nova_bench_$label"
    adb push "$bin" "$remote" >/dev/null && adb shell chmod +x "$remote"
    NOVA_BENCH_LABEL="$label" adb shell "NOVA_BENCH_LABEL=$label $remote $*"
  else
    NOVA_BENCH_LABEL="$label" "$bin" "$@"
  fi
}

CASES=()   # "name|args"
if [[ "$SUITE" == quick ]]; then
  CASES+=("kernel race|kernel --repeats 3")
  CASES+=("enhance 0.8 MP default (CNN + classic)|enhance --size 1024x768 --profile default --repeats 3")
  CASES+=("enhance 0.8 MP classic only|enhance --size 1024x768 --profile classic --repeats 3")
  CASES+=("CNN inference 0.8 MP|infer --size 1024x768 --repeats 3")
  CASES+=("training step, batch 4|train --steps 8 --batch 4")
else
  CASES+=("kernel race|kernel --repeats 5")
  CASES+=("enhance 0.8 MP default|enhance --size 1024x768 --profile default --repeats 5")
  CASES+=("enhance 0.8 MP no CNN|enhance --size 1024x768 --profile nocnn --repeats 5")
  CASES+=("enhance 0.8 MP classic|enhance --size 1024x768 --profile classic --repeats 5")
  CASES+=("enhance 0.8 MP everything on|enhance --size 1024x768 --profile all --repeats 3")
  CASES+=("repeated 0.8 MP x10 (memory growth / drift)|enhance --size 1024x768 --profile default --repeats 10")
  CASES+=("enhance 12 MP default|enhance --mp 12 --profile default --repeats 1")
  CASES+=("enhance 12 MP classic|enhance --mp 12 --profile classic --repeats 1")
  CASES+=("enhance 48 MP slice (600 rows) classic|enhance --mp 48 --rows 600 --profile classic --repeats 1")
  CASES+=("enhance 48 MP slice (600 rows) default|enhance --mp 48 --rows 600 --profile default --repeats 1")
  CASES+=("CNN inference 0.8 MP|infer --size 1024x768 --repeats 5")
  CASES+=("training step, batch 4|train --steps 20 --batch 4")
  CASES+=("training step, batch 8|train --steps 10 --batch 8")
  CASES+=("scoped-thread spawn cost|spawn")
  if [[ "$LONG" -gt 0 ]]; then
    CASES+=("sustained ${LONG} s, 0.8 MP default|enhance --size 1024x768 --profile default --duration $LONG")
  fi
fi

{
  echo "# NovaEnhance bench $STAMP  target=$TARGET suite=$SUITE"
  echo "# host: $(uname -srm)  cores: $(nproc 2>/dev/null || echo ?)"
  echo
} | tee "$OUT"

for entry in "${CASES[@]}"; do
  name="${entry%%|*}"; args="${entry#*|}"
  if [[ ${#ONLY[@]} -gt 0 ]]; then
    keep=0
    for pat in "${ONLY[@]}"; do [[ "$name" == *"$pat"* ]] && keep=1; done
    [[ $keep -eq 1 ]] || continue
  fi
  echo "== $name  [bench $args]" | tee -a "$OUT"
  if [[ -n "$OLD_BIN" && "$args" != kernel* ]]; then
    echo "-- baseline (older tree)" | tee -a "$OUT"
    # shellcheck disable=SC2086
    RUN baseline "$OLD_BIN" $args ${THREADS_ARG[@]+"${THREADS_ARG[@]}"} 2>&1 | grep -v '^iter=' | tee -a "$OUT" || true
    echo "-- this tree" | tee -a "$OUT"
  fi
  # shellcheck disable=SC2086
  RUN optimized "$NEW_BIN" $args ${THREADS_ARG[@]+"${THREADS_ARG[@]}"} 2>&1 | grep -v '^iter=' | tee -a "$OUT" || true
  echo | tee -a "$OUT"
done

echo "Results written to $OUT"
