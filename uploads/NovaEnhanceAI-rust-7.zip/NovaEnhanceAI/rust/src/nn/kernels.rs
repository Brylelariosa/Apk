//! Register-blocked 3x3 'same' convolution kernels (stride 1, zero padding), portable Rust.
//!
//! Data layout shared by every kernel here and by the code that calls them:
//!
//! * Activations are NHWC, one image at a time: pixel (y,x) channel c lives at `((y * W) + x) * C + c`.
//! * "Padded planes" carry a ONE-PIXEL ZERO BORDER: (H+2) x (W+2) x C, with the real image in the interior. Every
//!   kernel reads its 3x3 neighbourhood straight out of such a plane, so there is no edge special-casing in the hot
//!   loops. Callers must never write into the border.
//! * Weights are `[ki][kj][cin][cout]` with cout contiguous - exactly the flat parameter layout.
//! * Channel counts must be multiples of 4 (the 3-channel image tensors are padded to 4 channels).
//!
//! Two implementations of the same convolution live here and give bit-identical results:
//!
//! * the REFERENCE kernel ([`conv_row`], [`conv_row_gated`]): small fixed-size blocks (4 pixels x 12 or 4 output
//!   channels) held in local arrays, written so LLVM can keep them in vector registers (NEON on ARM) without
//!   intrinsics. Simple, obviously correct, and what the unit tests compare against;
//! * the BLOCKED kernel ([`conv_row_blocked`], [`conv_row_gated_blocked`]): the same arithmetic in the same order,
//!   but with weights re-ordered into one contiguous stream per output-channel block, which the compiler turns into
//!   much tighter code on x86-64 (measured 2.7x faster there).
//!
//! Auto-vectorisation is fragile, so which one is faster varies with the compiler and CPU; [`active_kernel`] times
//! both once on the device and uses the faster. On AArch64 the multiply-add is a fused `fmla`; elsewhere it is a
//! plain multiply and add (a software fma would be far slower). Both kernels use the same `fma`, so they agree
//! exactly on every platform.

use std::sync::OnceLock;
use std::time::Instant;

#[cfg(target_arch = "aarch64")]
#[inline(always)]
fn fma(a: f32, b: f32, c: f32) -> f32 {
    a.mul_add(b, c)
}

#[cfg(not(target_arch = "aarch64"))]
#[inline(always)]
fn fma(a: f32, b: f32, c: f32) -> f32 {
    a * b + c
}

/// Accumulates the 3x3 x `cin` reduction for PX adjacent output pixels and CB output channels starting at `c0`.
#[inline(always)]
fn conv_block<const PX: usize, const CB: usize>(
    rows: &[&[f32]; 3],
    cin: usize,
    weights: &[f32],
    cout: usize,
    x: usize,
    c0: usize,
    acc: &mut [[f32; CB]; PX],
) {
    for ki in 0..3 {
        let row = rows[ki];
        for kj in 0..3 {
            let tap = ki * 3 + kj;
            let wbase = tap * cin * cout + c0;
            let ibase = (x + kj) * cin;
            for ci in 0..cin {
                let woff = wbase + ci * cout;
                let wrow = &weights[woff..woff + CB];
                for p in 0..PX {
                    let v = row[ibase + p * cin + ci];
                    for b in 0..CB {
                        acc[p][b] = fma(v, wrow[b], acc[p][b]);
                    }
                }
            }
        }
    }
}

#[inline(always)]
fn row_pixels<const PX: usize, const CB: usize>(
    rows: &[&[f32]; 3],
    cin: usize,
    weights: &[f32],
    bias: Option<&[f32]>,
    cout: usize,
    relu: bool,
    out: &mut [f32],
    x: usize,
) {
    let mut c0 = 0usize;
    while c0 < cout {
        let mut acc = [[0.0f32; CB]; PX];
        if let Some(b) = bias {
            for p in 0..PX {
                for k in 0..CB {
                    acc[p][k] = b[c0 + k];
                }
            }
        }
        conv_block::<PX, CB>(rows, cin, weights, cout, x, c0, &mut acc);
        for p in 0..PX {
            let o = (x + p) * cout + c0;
            for k in 0..CB {
                let v = acc[p][k];
                out[o + k] = if relu && v < 0.0 { 0.0 } else { v };
            }
        }
        c0 += CB;
    }
}

fn conv_row_cb<const CB: usize>(
    rows: &[&[f32]; 3],
    cin: usize,
    weights: &[f32],
    bias: Option<&[f32]>,
    cout: usize,
    width: usize,
    relu: bool,
    out: &mut [f32],
) {
    let mut x = 0usize;
    while x + 4 <= width {
        row_pixels::<4, CB>(rows, cin, weights, bias, cout, relu, out, x);
        x += 4;
    }
    while x < width {
        row_pixels::<1, CB>(rows, cin, weights, bias, cout, relu, out, x);
        x += 1;
    }
}

/// One output row of `out = epi(bias + conv3x3(in, weights))`.
///
/// * `rows[0..2]`  padded input rows y-1, y, y+1. Each starts at PADDED pixel 0 (the left zero column) and is at
///   least `(width + 2) * cin` floats long.
/// * `weights`     `[3][3][cin][cout]`
/// * `bias`        `cout` floats, or `None` for zero
/// * `out`         starts at OUTPUT pixel 0 of the row; pixel stride is `cout`
/// * `relu`        apply ReLU to the result
pub fn conv_row(
    rows: [&[f32]; 3],
    cin: usize,
    weights: &[f32],
    bias: Option<&[f32]>,
    cout: usize,
    width: usize,
    relu: bool,
    out: &mut [f32],
) {
    assert!(cout % 4 == 0 && cin % 4 == 0, "channel counts must be multiples of 4");
    if cout % 12 == 0 {
        conv_row_cb::<12>(&rows, cin, weights, bias, cout, width, relu, out);
    } else {
        conv_row_cb::<4>(&rows, cin, weights, bias, cout, width, relu, out);
    }
}

// ------------------------------------------------------------------------------------------------ blocked kernel
//
// The kernel above is the REFERENCE implementation (simple, obviously correct, kept for the tests). The hot paths
// (inference and training) use the blocked kernel below, which computes the same numbers in the same order - it is
// bit-for-bit identical, a unit test checks that - but is laid out so the compiler produces good code for it:
//
// * Weights are re-ordered once per call into `[block][tap][ci][CB]` (`ConvWeights`). The inner loop then reads
//   them as ONE contiguous stream (`chunks_exact(CB)`), with no index arithmetic and no bounds checks; and one
//   block (9 x 48 x 12 floats = 21 KB for the 48-channel layers) stays in the L1 cache while a whole row of pixels
//   is computed against it. The reference kernel walks all 83 KB of a layer's weights for every 4 pixels.
// * The four input pixels a tap needs are taken as four slices of exactly `cin` floats, so zipping them with the
//   weight stream needs no bounds checks either.
//
// Measured on the x86-64 development machine (see docs/PERFORMANCE.md) the reference kernel's accumulators were
// spilled to the stack in every iteration, which made it 2-3x slower than this layout; whether the AArch64 build had
// the same problem could not be measured without a phone, but this layout does not depend on that luck.

/// One convolution layer's weights, kept in both layouts so either kernel can run them: the flat parameter layout
/// (`[tap][ci][co]`, what the reference kernel reads) and the blocked layout (see above). Built once per
/// `PackedWeights::pack`; the copy costs ~0.2 MB and a few hundred microseconds.
pub struct ConvWeights {
    cin: usize,
    cout: usize,
    /// Output channels per block: 12 when `cout` is a multiple of 12, else 4.
    cb: usize,
    flat: Vec<f32>,
    blocked: Vec<f32>,
}

fn block_width(cout: usize) -> usize {
    if cout % 12 == 0 {
        12
    } else {
        4
    }
}

impl ConvWeights {
    /// A layer with no weights (stands in for "not packed"); using it in a kernel panics.
    pub fn empty() -> ConvWeights {
        ConvWeights { cin: 0, cout: 0, cb: 4, flat: Vec::new(), blocked: Vec::new() }
    }

    /// `w` is `[tap][ci][co]` (`tap = ki * 3 + kj`, `co` contiguous): the flat parameter layout.
    pub fn new(w: &[f32], cin: usize, cout: usize) -> ConvWeights {
        assert!(cout % 4 == 0 && cin % 4 == 0, "channel counts must be multiples of 4");
        assert!(w.len() >= 9 * cin * cout, "ConvWeights: weight slice too short");
        let cb = block_width(cout);
        let mut blocked = vec![0.0f32; 9 * cin * cout];
        for blk in 0..cout / cb {
            for tap in 0..9 {
                for ci in 0..cin {
                    let src = (tap * cin + ci) * cout + blk * cb;
                    let dst = ((blk * 9 + tap) * cin + ci) * cb;
                    blocked[dst..dst + cb].copy_from_slice(&w[src..src + cb]);
                }
            }
        }
        ConvWeights { cin, cout, cb, flat: w[..9 * cin * cout].to_vec(), blocked }
    }

    pub fn cin(&self) -> usize {
        self.cin
    }

    pub fn cout(&self) -> usize {
        self.cout
    }

    /// The weights in the flat parameter layout.
    pub fn flat(&self) -> &[f32] {
        &self.flat
    }
}

/// Four adjacent output pixels x CB output channels.
#[inline(always)]
fn block4<const CB: usize>(rows: &[&[f32]; 3], cin: usize, wb: &[f32], x: usize, acc: &mut [[f32; CB]; 4]) {
    for ki in 0..3 {
        let row = rows[ki];
        for kj in 0..3 {
            let tap = ki * 3 + kj;
            let wt = &wb[tap * cin * CB..(tap + 1) * cin * CB];
            let b = (x + kj) * cin;
            let i0 = &row[b..b + cin];
            let i1 = &row[b + cin..b + 2 * cin];
            let i2 = &row[b + 2 * cin..b + 3 * cin];
            let i3 = &row[b + 3 * cin..b + 4 * cin];
            for ((w, (a0, a1)), (a2, a3)) in
                wt.chunks_exact(CB).zip(i0.iter().zip(i1.iter())).zip(i2.iter().zip(i3.iter()))
            {
                for k in 0..CB {
                    acc[0][k] = fma(*a0, w[k], acc[0][k]);
                    acc[1][k] = fma(*a1, w[k], acc[1][k]);
                    acc[2][k] = fma(*a2, w[k], acc[2][k]);
                    acc[3][k] = fma(*a3, w[k], acc[3][k]);
                }
            }
        }
    }
}

/// One output pixel x CB output channels (the row's tail).
#[inline(always)]
fn block1<const CB: usize>(rows: &[&[f32]; 3], cin: usize, wb: &[f32], x: usize, acc: &mut [f32; CB]) {
    for ki in 0..3 {
        let row = rows[ki];
        for kj in 0..3 {
            let tap = ki * 3 + kj;
            let wt = &wb[tap * cin * CB..(tap + 1) * cin * CB];
            let b = (x + kj) * cin;
            let i0 = &row[b..b + cin];
            for (w, a0) in wt.chunks_exact(CB).zip(i0.iter()) {
                for k in 0..CB {
                    acc[k] = fma(*a0, w[k], acc[k]);
                }
            }
        }
    }
}

fn conv_blocked_cb<const CB: usize>(
    rows: &[&[f32]; 3],
    bw: &ConvWeights,
    bias: Option<&[f32]>,
    width: usize,
    relu: bool,
    out: &mut [f32],
) {
    let (cin, cout) = (bw.cin, bw.cout);
    for blk in 0..cout / CB {
        let c0 = blk * CB;
        let wblk = &bw.blocked[blk * 9 * cin * CB..(blk + 1) * 9 * cin * CB];
        let mut bias_blk = [0.0f32; CB];
        if let Some(b) = bias {
            bias_blk.copy_from_slice(&b[c0..c0 + CB]);
        }
        let mut x = 0usize;
        while x + 4 <= width {
            let mut acc = [bias_blk; 4];
            block4::<CB>(rows, cin, wblk, x, &mut acc);
            for p in 0..4 {
                let o = (x + p) * cout + c0;
                let dst = &mut out[o..o + CB];
                for k in 0..CB {
                    let v = acc[p][k];
                    dst[k] = if relu && v < 0.0 { 0.0 } else { v };
                }
            }
            x += 4;
        }
        while x < width {
            let mut acc = bias_blk;
            block1::<CB>(rows, cin, wblk, x, &mut acc);
            let o = x * cout + c0;
            let dst = &mut out[o..o + CB];
            for k in 0..CB {
                let v = acc[k];
                dst[k] = if relu && v < 0.0 { 0.0 } else { v };
            }
            x += 1;
        }
    }
}

/// [`conv_row`] with pre-blocked weights: one output row of `out = epi(bias + conv3x3(in, weights))`, bit-for-bit
/// the same result. Same row/`out` conventions as [`conv_row`].
pub fn conv_row_blocked(
    rows: [&[f32]; 3],
    bw: &ConvWeights,
    bias: Option<&[f32]>,
    width: usize,
    relu: bool,
    out: &mut [f32],
) {
    assert!(bw.cin > 0 && bw.cout > 0, "conv_row_blocked: the layer has no weights");
    if bw.cb == 12 {
        conv_blocked_cb::<12>(&rows, bw, bias, width, relu, out);
    } else {
        conv_blocked_cb::<4>(&rows, bw, bias, width, relu, out);
    }
}

/// [`conv_row_gated`] with pre-blocked weights.
pub fn conv_row_gated_blocked(
    rows: [&[f32]; 3],
    bw: &ConvWeights,
    width: usize,
    gate: &[f32],
    out: &mut [f32],
) {
    conv_row_blocked(rows, bw, None, width, false, out);
    let n = width * bw.cout;
    for i in 0..n {
        if !(gate[i] > 0.0) {
            out[i] = 0.0;
        }
    }
}

// ------------------------------------------------------------------------------------------------ kernel choice

/// Which implementation computes the network's convolutions. Both produce BIT-IDENTICAL results (unit tests check
/// it), so the choice only affects speed - and which one is faster depends on the compiler and the CPU: on the x86-64
/// development machine the blocked kernel is 2.7x faster, but the AArch64 build could not be timed without a phone.
/// So the engine does not guess: it measures both on the device it runs on (see [`active_kernel`]).
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Kernel {
    /// [`conv_row`] / [`conv_row_gated`]: the original, simple formulation.
    Reference,
    /// [`conv_row_blocked`] / [`conv_row_gated_blocked`]: blocked weights, one contiguous weight stream.
    Blocked,
}

impl Kernel {
    pub fn name(self) -> &'static str {
        match self {
            Kernel::Reference => "reference",
            Kernel::Blocked => "blocked",
        }
    }
}

static CHOSEN: OnceLock<Kernel> = OnceLock::new();

/// The kernel every convolution in this process uses. Decided once, on first use:
///
/// 1. `NOVA_KERNEL=reference` or `NOVA_KERNEL=blocked` in the environment forces one (for benchmarking with
///    `adb shell`; an app process normally has no such variable);
/// 2. otherwise both are timed on a synthetic row of the network's dominant layer (48 -> 48 channels) and the blocked
///    kernel is chosen only if it is clearly faster (>= 5 %); a tie or any doubt keeps the reference kernel, so a
///    device where the new code does not help behaves exactly like before.
pub fn active_kernel() -> Kernel {
    *CHOSEN.get_or_init(choose_kernel)
}

/// What [`measure`] found.
#[derive(Clone, Copy, Debug)]
pub struct Calibration {
    /// Throughput of each kernel on the 48 -> 48 test row, in GMAC/s (multiply-accumulates, not FLOPs).
    pub reference_gmac_s: f64,
    pub blocked_gmac_s: f64,
    /// What the engine picks from those numbers.
    pub choice: Kernel,
}

fn choose_kernel() -> Kernel {
    if let Ok(v) = std::env::var("NOVA_KERNEL") {
        match v.trim().to_ascii_lowercase().as_str() {
            "reference" => return Kernel::Reference,
            "blocked" => return Kernel::Blocked,
            _ => {} // "auto" or anything else: measure
        }
    }
    measure().choice
}

/// Times both kernels on one row of a 48 -> 48 layer (conv2/conv3 are ~94 % of the network's work) and says which is
/// faster. The two are timed alternately, in a different order every round, and each one's BEST round counts, so a
/// scheduler hiccup or a core migration while one of them was running does not decide the outcome. About
/// 2 x 8 x 3 rows of 64 pixels: a few milliseconds on a PC, tens on a phone. [`active_kernel`] runs it once per
/// process; the benchmark and diagnostics may call it again to see the numbers.
pub fn measure() -> Calibration {
    const WIDTH: usize = 64;
    const CH: usize = 48;
    const ROUNDS: usize = 8;
    const ROWS_PER_ROUND: usize = 3;

    let mut seed = 0x1234_5678u32;
    let mut next = move || {
        seed = seed.wrapping_mul(1_664_525).wrapping_add(1_013_904_223);
        ((seed >> 8) as f32) / 16_777_216.0 - 0.5
    };
    let plane = (WIDTH + 2) * CH;
    let r0: Vec<f32> = (0..plane).map(|_| next()).collect();
    let r1: Vec<f32> = (0..plane).map(|_| next()).collect();
    let r2: Vec<f32> = (0..plane).map(|_| next()).collect();
    let w: Vec<f32> = (0..9 * CH * CH).map(|_| next() * 0.1).collect();
    let bias = vec![0.01f32; CH];
    let cw = ConvWeights::new(&w, CH, CH);
    let mut out = vec![0.0f32; WIDTH * CH];

    let mut best = [f64::MAX; 2];
    // Round 0 only warms the caches and the branch predictors; it is not counted.
    for round in 0..=ROUNDS {
        let order = if round % 2 == 0 { [0usize, 1] } else { [1, 0] };
        for &which in &order {
            let kernel = if which == 0 { Kernel::Reference } else { Kernel::Blocked };
            let t = Instant::now();
            for _ in 0..ROWS_PER_ROUND {
                conv_row_with(kernel, [&r0, &r1, &r2], &cw, Some(&bias), WIDTH, true, &mut out);
                std::hint::black_box(&mut out);
            }
            let dt = t.elapsed().as_secs_f64();
            if round > 0 && dt < best[which] {
                best[which] = dt;
            }
        }
    }
    let macs = (ROWS_PER_ROUND * WIDTH * 9 * CH * CH) as f64;
    let choice = if best[1] < best[0] * 0.95 { Kernel::Blocked } else { Kernel::Reference };
    Calibration { reference_gmac_s: macs / best[0] / 1e9, blocked_gmac_s: macs / best[1] / 1e9, choice }
}

/// One output row with the chosen kernel; same contract as [`conv_row`] (the layer's channel counts come from `cw`).
pub fn conv_row_with(
    kernel: Kernel,
    rows: [&[f32]; 3],
    cw: &ConvWeights,
    bias: Option<&[f32]>,
    width: usize,
    relu: bool,
    out: &mut [f32],
) {
    match kernel {
        Kernel::Blocked => conv_row_blocked(rows, cw, bias, width, relu, out),
        Kernel::Reference => conv_row(rows, cw.cin, &cw.flat, bias, cw.cout, width, relu, out),
    }
}

/// One gated output row with the chosen kernel; same contract as [`conv_row_gated`].
pub fn conv_row_gated_with(
    kernel: Kernel,
    rows: [&[f32]; 3],
    cw: &ConvWeights,
    width: usize,
    gate: &[f32],
    out: &mut [f32],
) {
    match kernel {
        Kernel::Blocked => conv_row_gated_blocked(rows, cw, width, gate, out),
        Kernel::Reference => conv_row_gated(rows, cw.cin, &cw.flat, cw.cout, width, gate, out),
    }
}

/// Backward-data building block: `out = (gate > 0) ? conv3x3(in, weights) : 0`. With spatially flipped,
/// channel-transposed weights and the forward ReLU activation as `gate`, it computes dL/d(pre-activation) of the
/// previous layer in one pass. `gate` has `out`'s layout (pixel stride `cout`) and starts at output pixel 0.
pub fn conv_row_gated(
    rows: [&[f32]; 3],
    cin: usize,
    weights: &[f32],
    cout: usize,
    width: usize,
    gate: &[f32],
    out: &mut [f32],
) {
    conv_row(rows, cin, weights, None, cout, width, false, out);
    let n = width * cout;
    for i in 0..n {
        if !(gate[i] > 0.0) {
            out[i] = 0.0;
        }
    }
}

fn weight_grad_cb<const CIB: usize, const COB: usize>(
    in_pad: &[f32],
    cin: usize,
    dout_pad: &[f32],
    cout: usize,
    width: usize,
    y0: usize,
    y1: usize,
    dw: &mut [f32],
) {
    let pw = width + 2;
    for tap in 0..9 {
        let ki = tap / 3;
        let kj = tap % 3;
        let mut ci0 = 0usize;
        while ci0 < cin {
            let mut co0 = 0usize;
            while co0 < cout {
                let mut acc = [[0.0f32; COB]; CIB];
                for y in y0..y1 {
                    let in_row = &in_pad[((y + ki) * pw + kj) * cin..];
                    let d_row = &dout_pad[((y + 1) * pw + 1) * cout..];
                    for x in 0..width {
                        let ip = &in_row[x * cin + ci0..x * cin + ci0 + CIB];
                        let dp = &d_row[x * cout + co0..x * cout + co0 + COB];
                        for a in 0..CIB {
                            let v = ip[a];
                            for b in 0..COB {
                                acc[a][b] = fma(v, dp[b], acc[a][b]);
                            }
                        }
                    }
                }
                for a in 0..CIB {
                    let base = (tap * cin + ci0 + a) * cout + co0;
                    for b in 0..COB {
                        dw[base + b] += acc[a][b];
                    }
                }
                co0 += COB;
            }
            ci0 += CIB;
        }
    }
}

/// Accumulates the weight gradient of one conv layer for output rows `[y0, y1)`:
///
/// ```text
/// dW[ki][kj][ci][co] += sum_{y,x} in_pad[y+ki][x+kj][ci] * dout[y][x][co]
/// dB[co]             += sum_{y,x} dout[y][x][co]
/// ```
///
/// `in_pad` / `dout_pad` are padded planes of the layer input (`cin` channels) and of the gradient at the layer
/// output (`cout` channels), both (height+2) x (width+2). `dw` must hold `9*cin*cout` floats and `db` `cout` floats;
/// both are ACCUMULATED into, so each worker owns a private pair and the caller sums them afterwards.
pub fn conv_weight_grad(
    in_pad: &[f32],
    cin: usize,
    dout_pad: &[f32],
    cout: usize,
    width: usize,
    y0: usize,
    y1: usize,
    dw: &mut [f32],
    db: &mut [f32],
) {
    assert!(cout % 4 == 0 && cin % 4 == 0, "channel counts must be multiples of 4");
    let pw = width + 2;
    for y in y0..y1 {
        let d_row = &dout_pad[((y + 1) * pw + 1) * cout..];
        for x in 0..width {
            let dp = &d_row[x * cout..x * cout + cout];
            for co in 0..cout {
                db[co] += dp[co];
            }
        }
    }
    if cout % 12 == 0 {
        weight_grad_cb::<4, 12>(in_pad, cin, dout_pad, cout, width, y0, y1, dw);
    } else {
        weight_grad_cb::<4, 4>(in_pad, cin, dout_pad, cout, width, y0, y1, dw);
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::rng::Rng;

    /// Naive reference: padded planes in, same-size output (no padding in the output).
    fn naive_conv(inp: &[f32], cin: usize, w: &[f32], bias: &[f32], cout: usize, width: usize, height: usize) -> Vec<f32> {
        let pw = width + 2;
        let mut out = vec![0.0f32; width * height * cout];
        for y in 0..height {
            for x in 0..width {
                for co in 0..cout {
                    let mut s = bias[co] as f64;
                    for ki in 0..3 {
                        for kj in 0..3 {
                            for ci in 0..cin {
                                let v = inp[((y + ki) * pw + (x + kj)) * cin + ci] as f64;
                                s += v * w[((ki * 3 + kj) * cin + ci) * cout + co] as f64;
                            }
                        }
                    }
                    out[(y * width + x) * cout + co] = s as f32;
                }
            }
        }
        out
    }

    fn random_plane(rng: &mut Rng, width: usize, height: usize, ch: usize) -> Vec<f32> {
        let pw = width + 2;
        let mut p = vec![0.0f32; (height + 2) * pw * ch];
        for y in 0..height {
            for x in 0..width {
                for c in 0..ch {
                    p[((y + 1) * pw + (x + 1)) * ch + c] = rng.normal();
                }
            }
        }
        p
    }

    #[test]
    fn conv_row_matches_naive_reference() {
        let mut rng = Rng::new(5);
        for &(cin, cout) in &[(4usize, 48usize), (48, 48), (48, 4)] {
            let (width, height) = (11usize, 5usize);
            let plane = random_plane(&mut rng, width, height, cin);
            let w: Vec<f32> = (0..9 * cin * cout).map(|_| rng.normal() * 0.1).collect();
            let bias: Vec<f32> = (0..cout).map(|_| rng.normal() * 0.1).collect();
            let expect = naive_conv(&plane, cin, &w, &bias, cout, width, height);
            let pw = width + 2;
            for y in 0..height {
                let r = |k: usize| &plane[(y + k) * pw * cin..(y + k + 1) * pw * cin];
                let mut out = vec![0.0f32; width * cout];
                conv_row([r(0), r(1), r(2)], cin, &w, Some(bias.as_slice()), cout, width, false, &mut out);
                for i in 0..width * cout {
                    let e = expect[y * width * cout + i];
                    assert!((out[i] - e).abs() < 1e-3, "cin {} cout {} y {} i {}: {} vs {}", cin, cout, y, i, out[i], e);
                }
            }
        }
    }

    #[test]
    fn blocked_kernel_is_bit_identical_to_the_reference() {
        let mut rng = Rng::new(21);
        // Every channel combination the network uses, plus odd ones, and widths with and without a 1-3 pixel tail.
        for &(cin, cout) in &[(4usize, 48usize), (48, 48), (48, 4), (4, 4), (8, 12), (12, 24)] {
            for &width in &[1usize, 2, 3, 4, 5, 7, 8, 11] {
                let height = 3usize;
                let plane = random_plane(&mut rng, width, height, cin);
                let w: Vec<f32> = (0..9 * cin * cout).map(|_| rng.normal() * 0.1).collect();
                let bias: Vec<f32> = (0..cout).map(|_| rng.normal() * 0.1).collect();
                let bw = ConvWeights::new(&w, cin, cout);
                let pw = width + 2;
                for &(use_bias, relu) in &[(true, false), (true, true), (false, true), (false, false)] {
                    for y in 0..height {
                        let r = |k: usize| &plane[(y + k) * pw * cin..(y + k + 1) * pw * cin];
                        let b = if use_bias { Some(bias.as_slice()) } else { None };
                        let mut want = vec![0.0f32; width * cout];
                        let mut got = vec![0.0f32; width * cout];
                        conv_row([r(0), r(1), r(2)], cin, &w, b, cout, width, relu, &mut want);
                        conv_row_blocked([r(0), r(1), r(2)], &bw, b, width, relu, &mut got);
                        let mut via_reference = vec![0.0f32; width * cout];
                        conv_row_with(Kernel::Reference, [r(0), r(1), r(2)], &bw, b, width, relu, &mut via_reference);
                        let mut via_blocked = vec![0.0f32; width * cout];
                        conv_row_with(Kernel::Blocked, [r(0), r(1), r(2)], &bw, b, width, relu, &mut via_blocked);
                        assert!(want.iter().zip(via_reference.iter()).all(|(a, b)| a.to_bits() == b.to_bits()));
                        assert!(want.iter().zip(via_blocked.iter()).all(|(a, b)| a.to_bits() == b.to_bits()));
                        for i in 0..width * cout {
                            assert_eq!(
                                want[i].to_bits(),
                                got[i].to_bits(),
                                "cin {} cout {} width {} y {} i {}: {} vs {}",
                                cin, cout, width, y, i, want[i], got[i]
                            );
                        }
                    }
                }
            }
        }
    }

    #[test]
    fn gated_blocked_kernel_matches_the_reference() {
        let mut rng = Rng::new(22);
        let (cin, cout, width, height) = (48usize, 48usize, 9usize, 3usize);
        let plane = random_plane(&mut rng, width, height, cin);
        let w: Vec<f32> = (0..9 * cin * cout).map(|_| rng.normal() * 0.1).collect();
        let gate: Vec<f32> = (0..width * cout).map(|_| rng.normal()).collect();
        let bw = ConvWeights::new(&w, cin, cout);
        let pw = width + 2;
        let r = |k: usize| &plane[k * pw * cin..(k + 1) * pw * cin];
        let mut want = vec![0.0f32; width * cout];
        let mut got = vec![0.0f32; width * cout];
        conv_row_gated([r(0), r(1), r(2)], cin, &w, cout, width, &gate, &mut want);
        conv_row_gated_blocked([r(0), r(1), r(2)], &bw, width, &gate, &mut got);
        assert!(want.iter().zip(got.iter()).all(|(a, b)| a.to_bits() == b.to_bits()));
        let mut via_reference = vec![0.0f32; width * cout];
        conv_row_gated_with(Kernel::Reference, [r(0), r(1), r(2)], &bw, width, &gate, &mut via_reference);
        assert!(want.iter().zip(via_reference.iter()).all(|(a, b)| a.to_bits() == b.to_bits()));
    }

    #[test]
    fn the_engine_picks_a_kernel_and_sticks_with_it() {
        // Timing decides which one, so the test only checks that the choice is made, is valid and is stable.
        let first = active_kernel();
        assert!(first == Kernel::Reference || first == Kernel::Blocked);
        assert_eq!(first, active_kernel());
        assert!(!first.name().is_empty());
    }

    #[test]
    fn weight_grad_matches_naive_reference() {
        let mut rng = Rng::new(9);
        let (cin, cout, width, height) = (8usize, 12usize, 9usize, 6usize);
        let inp = random_plane(&mut rng, width, height, cin);
        let dout = random_plane(&mut rng, width, height, cout);
        let mut dw = vec![0.0f32; 9 * cin * cout];
        let mut db = vec![0.0f32; cout];
        conv_weight_grad(&inp, cin, &dout, cout, width, 0, height, &mut dw, &mut db);
        let pw = width + 2;
        for ki in 0..3 {
            for kj in 0..3 {
                for ci in 0..cin {
                    for co in 0..cout {
                        let mut s = 0.0f64;
                        for y in 0..height {
                            for x in 0..width {
                                s += inp[((y + ki) * pw + (x + kj)) * cin + ci] as f64
                                    * dout[((y + 1) * pw + (x + 1)) * cout + co] as f64;
                            }
                        }
                        let got = dw[((ki * 3 + kj) * cin + ci) * cout + co];
                        assert!((got as f64 - s).abs() < 1e-3, "dw mismatch {} vs {}", got, s);
                    }
                }
            }
        }
        for co in 0..cout {
            let mut s = 0.0f64;
            for y in 0..height {
                for x in 0..width {
                    s += dout[((y + 1) * pw + (x + 1)) * cout + co] as f64;
                }
            }
            assert!((db[co] as f64 - s).abs() < 1e-3);
        }
    }
}
