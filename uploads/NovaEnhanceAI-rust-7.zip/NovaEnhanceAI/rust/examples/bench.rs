//! Reproducible native benchmark for the NovaEnhance core. Run it on a PC (or, built with `cargo ndk`, on a phone)
//! through `tools/bench.sh`, or directly:
//!
//! ```text
//! cargo run --release --example bench -- enhance --size 4000x3000 --profile default --repeats 3
//! cargo run --release --example bench -- infer --size 1024x768
//! cargo run --release --example bench -- train --steps 30 --batch 4
//! cargo run --release --example bench -- spawn
//! cargo run --release --example bench -- kernel --repeats 5
//! ```
//!
//! Set `NOVA_BENCH_LABEL=<name>` to tag a run (it is echoed as `build=<name>`), e.g. `baseline` / `optimized`.
//!
//! ONE case per process: the peak-RSS figure (`VmHWM`) only ever grows, so mixing cases in one process would blur it.
//! Every case prints `key=value` lines that `tools/bench.sh` collects. The example uses nothing but the crate's public
//! API, so the very same file builds against an older tree to compare old and new code.
//!
//! The counting allocator below exists only in this example (never in the shipped library): it reports how many heap
//! allocations a case made and the largest amount of heap that was live at once ABOVE what the case started with.

use std::alloc::{GlobalAlloc, Layout, System};
use std::sync::atomic::{AtomicU64, AtomicUsize, Ordering::Relaxed};
use std::time::Instant;

use novaenhance_native::enhance::analysis::PixelSource;
use novaenhance_native::enhance::options::*;
use novaenhance_native::enhance::session::{RowIo, Session};
use novaenhance_native::nn::{self, INPUT_FLOATS, OUTPUT_FLOATS, TOTAL_PARAMS};
use novaenhance_native::rng::Rng;

// ------------------------------------------------------------------------------------------------ allocator stats

struct Counting;

static ALLOCS: AtomicU64 = AtomicU64::new(0);
static LARGE_ALLOCS: AtomicU64 = AtomicU64::new(0);
static BYTES: AtomicU64 = AtomicU64::new(0);
static LIVE: AtomicUsize = AtomicUsize::new(0);
static PEAK: AtomicUsize = AtomicUsize::new(0);

/// Allocations of at least this size are served by mmap/munmap on most libcs, which is where page-fault storms
/// (and, on a phone, memory fragmentation) come from.
const LARGE: usize = 128 * 1024;

fn note_alloc(n: usize) {
    ALLOCS.fetch_add(1, Relaxed);
    BYTES.fetch_add(n as u64, Relaxed);
    if n >= LARGE {
        LARGE_ALLOCS.fetch_add(1, Relaxed);
    }
    let live = LIVE.fetch_add(n, Relaxed) + n;
    PEAK.fetch_max(live, Relaxed);
}

unsafe impl GlobalAlloc for Counting {
    unsafe fn alloc(&self, l: Layout) -> *mut u8 {
        note_alloc(l.size());
        System.alloc(l)
    }
    unsafe fn alloc_zeroed(&self, l: Layout) -> *mut u8 {
        note_alloc(l.size());
        System.alloc_zeroed(l)
    }
    unsafe fn dealloc(&self, p: *mut u8, l: Layout) {
        LIVE.fetch_sub(l.size(), Relaxed);
        System.dealloc(p, l)
    }
    unsafe fn realloc(&self, p: *mut u8, l: Layout, new_size: usize) -> *mut u8 {
        LIVE.fetch_sub(l.size(), Relaxed);
        note_alloc(new_size);
        System.realloc(p, l, new_size)
    }
}

#[global_allocator]
static COUNTING: Counting = Counting;

#[derive(Clone, Copy)]
struct HeapMark {
    allocs: u64,
    large: u64,
    bytes: u64,
    live: usize,
}

fn heap_mark() -> HeapMark {
    PEAK.store(LIVE.load(Relaxed), Relaxed);
    HeapMark { allocs: ALLOCS.load(Relaxed), large: LARGE_ALLOCS.load(Relaxed), bytes: BYTES.load(Relaxed), live: LIVE.load(Relaxed) }
}

/// (allocations, large allocations, total bytes requested, peak extra live heap in bytes) since `m`.
fn heap_since(m: HeapMark) -> (u64, u64, u64, usize) {
    (
        ALLOCS.load(Relaxed) - m.allocs,
        LARGE_ALLOCS.load(Relaxed) - m.large,
        BYTES.load(Relaxed) - m.bytes,
        PEAK.load(Relaxed).saturating_sub(m.live),
    )
}

// ------------------------------------------------------------------------------------------------ /proc readers

fn proc_status_kb(key: &str) -> Option<u64> {
    let text = std::fs::read_to_string("/proc/self/status").ok()?;
    for line in text.lines() {
        if let Some(rest) = line.strip_prefix(key) {
            return rest.trim().trim_end_matches("kB").trim().parse().ok();
        }
    }
    None
}

/// utime + stime of this process in clock ticks (assumed 100 per second, the Linux/Android default).
fn cpu_ticks() -> Option<u64> {
    let text = std::fs::read_to_string("/proc/self/stat").ok()?;
    let after = &text[text.rfind(')')? + 2..];
    let f: Vec<&str> = after.split_whitespace().collect();
    // After the ") " the first field is `state` (field 3 of stat); utime is field 14 -> index 11, stime index 12.
    Some(f.get(11)?.parse::<u64>().ok()? + f.get(12)?.parse::<u64>().ok()?)
}

// ------------------------------------------------------------------------------------------------ test image

/// An RGBA bitmap read and written through a raw pointer, like the real `sys::LockedBitmap`.
struct Image {
    w: usize,
    h: usize,
    buf: Vec<u8>,
    ptr: *mut u8,
}

unsafe impl Sync for Image {}

impl Image {
    fn new(w: usize, h: usize) -> Image {
        let mut buf = vec![255u8; w * h * 4];
        let ptr = buf.as_mut_ptr();
        Image { w, h, buf, ptr }
    }

    /// A deterministic photo-like picture: sky gradient, soft blobs, hard-edged blocks and a little sensor noise.
    fn photo(w: usize, h: usize) -> Image {
        let img = Image::new(w, h);
        let threads = std::thread::available_parallelism().map(|v| v.get()).unwrap_or(1).min(8);
        let rows_per = (h + threads - 1) / threads;
        std::thread::scope(|scope| {
            for t in 0..threads {
                let img = &img;
                scope.spawn(move || {
                    let y_start = t * rows_per;
                    let y_end = ((t + 1) * rows_per).min(h);
                    let block = (w / 24).max(8);
                    let mut rng = Rng::new(1000 + t as u64);
                    let mut row = vec![0u8; w * 4];
                    for y in y_start..y_end {
                        let fy = y as f32 / h as f32;
                        for x in 0..w {
                            let fx = x as f32 / w as f32;
                            let sky = 60.0 + 110.0 * fy;
                            let blob = 28.0 * ((fx * 9.0).sin() * (fy * 7.0).cos());
                            let edge = if ((x / block) + (y / block)) % 3 == 0 { 38.0 } else { 0.0 };
                            let noise = (rng.next_f32() - 0.5) * 12.0;
                            for c in 0..3 {
                                let v = sky + blob + edge + noise + c as f32 * 14.0 * (1.0 - fy);
                                row[x * 4 + c] = v.max(0.0).min(255.0) as u8;
                            }
                            row[x * 4 + 3] = 255;
                        }
                        img.write_row(y, &row);
                    }
                });
            }
        });
        img
    }

    fn checksum(&self) -> u64 {
        let mut h = 0xcbf2_9ce4_8422_2325u64;
        for chunk in self.buf.chunks(8) {
            let mut v = 0u64;
            for (i, b) in chunk.iter().enumerate() {
                v |= (*b as u64) << (8 * i);
            }
            h = (h ^ v).wrapping_mul(0x0000_0100_0000_01B3);
        }
        h
    }
}

impl PixelSource for Image {
    fn width(&self) -> usize {
        self.w
    }
    fn height(&self) -> usize {
        self.h
    }
    fn row(&self, y: usize) -> &[u8] {
        assert!(y < self.h);
        unsafe { std::slice::from_raw_parts(self.ptr.add(y * self.w * 4) as *const u8, self.w * 4) }
    }
}

impl RowIo for Image {
    fn write_row(&self, y: usize, data: &[u8]) {
        assert!(y < self.h && data.len() == self.w * 4);
        unsafe { std::slice::from_raw_parts_mut(self.ptr.add(y * self.w * 4), self.w * 4).copy_from_slice(data) }
    }
}

// ------------------------------------------------------------------------------------------------ options

/// What the app's sliders produce at their defaults (strength 100 %, sharpness 30 %, noise reduction 30 %, colour
/// restoration 20 %, 1x, auto off): `EnhancementEngine.sharpenSpecFor1x` maps sharpness 0.3 to these sharpen values.
fn base_options() -> Vec<f32> {
    let mut a = vec![0.0f32; OPTIONS_LEN];
    a[STRENGTH] = 1.0;
    a[SHARPNESS] = 0.3;
    a[NOISE_REDUCTION] = 0.3;
    a[COLOR_RESTORATION] = 0.2;
    a[UPSCALE_FACTOR] = 1.0;
    a[SHARP_AMOUNT] = 1.5 * 0.3 * 0.3;
    a[SHARP_SIGMA] = 1.0;
    a[SHARP_OVERSHOOT] = 0.0;
    a[SHARP_CLAMP_RADIUS] = 1.0;
    a[SHARP_PUSH] = (0.3f32 * 1.6).min(1.0);
    a[SHARP_PUSH_RADIUS] = 1.0;
    a
}

/// Every classical technique at a moderate setting.
fn add_classical(a: &mut [f32]) {
    for (idx, v) in [
        (WHITE_BALANCE, 0.3),
        (AUTO_LEVELS, 0.3),
        (EXPOSURE, 0.1),
        (CONTRAST, 0.1),
        (SHADOWS, 0.3),
        (HIGHLIGHTS, 0.3),
        (CLAHE, 0.3),
        (LOW_LIGHT, 0.3),
        (DEHAZE, 0.3),
        (VIBRANCE, 0.3),
        (CLARITY, 0.4),
        (DETAIL, 0.4),
        (DENOISE, 0.5),
        (DESPIKE, 0.5),
        (DEBAND, 0.5),
        (DEBLUR, 0.5),
    ] {
        a[idx] = v;
    }
}

fn options_for(profile: &str) -> Result<Vec<f32>, String> {
    let mut a = base_options();
    match profile {
        "default" => {}
        "nocnn" => a[STRENGTH] = 0.0,
        "classic" => {
            a[STRENGTH] = 0.0;
            add_classical(&mut a);
        }
        "all" => add_classical(&mut a),
        p if p.starts_with("single:") => {
            // Exactly one technique on: everything else (including sharpen / noise reduction / colour) is off.
            let mut b = vec![0.0f32; OPTIONS_LEN];
            b[UPSCALE_FACTOR] = 1.0;
            let name = &p["single:".len()..];
            let idx = match name {
                "cnn" => {
                    b[STRENGTH] = 1.0;
                    return Ok(b);
                }
                "sharpen" => return Ok({
                    for i in SHARP_AMOUNT..=SHARP_PUSH_RADIUS {
                        b[i] = a[i];
                    }
                    b
                }),
                "noise_reduction" => NOISE_REDUCTION,
                "color_restoration" => COLOR_RESTORATION,
                "white_balance" => WHITE_BALANCE,
                "auto_levels" => AUTO_LEVELS,
                "exposure" => EXPOSURE,
                "contrast" => CONTRAST,
                "shadows" => SHADOWS,
                "highlights" => HIGHLIGHTS,
                "clahe" => CLAHE,
                "low_light" => LOW_LIGHT,
                "dehaze" => DEHAZE,
                "vibrance" => VIBRANCE,
                "clarity" => CLARITY,
                "detail" => DETAIL,
                "denoise" => DENOISE,
                "despike" => DESPIKE,
                "deband" => DEBAND,
                "deblur" => DEBLUR,
                "vignette" => VIGNETTE,
                other => return Err(format!("unknown technique '{}'", other)),
            };
            b[idx] = 0.5;
            return Ok(b);
        }
        other => return Err(format!("unknown profile '{}' (default, nocnn, classic, all, single:<technique>)", other)),
    }
    Ok(a)
}

/// Non-trivial CNN weights: He-initialised, with the tail layer scaled up so the network visibly changes the picture
/// (a fresh model is a near-identity, which would hide differences between two builds).
fn bench_params() -> Vec<f32> {
    let mut p = vec![0.0f32; TOTAL_PARAMS];
    nn::initialize_params(&mut p, 7);
    for i in 0..nn::W4_SIZE {
        p[nn::W4_OFFSET + i] *= 100.0;
    }
    p
}

// ------------------------------------------------------------------------------------------------ command line

struct Args {
    case: String,
    size: (usize, usize),
    profile: String,
    repeats: usize,
    duration: f64,
    threads: usize,
    band_rows: usize,
    band_px: usize,
    in_place: bool,
    steps: usize,
    batch: usize,
    save: Option<String>,
    compare: Option<String>,
    rows: Option<usize>,
}

fn parse_args() -> Result<Args, String> {
    let mut it = std::env::args().skip(1);
    let case = it.next().ok_or("usage: bench <enhance|infer|train|spawn|kernel> [options]")?;
    let hw = std::thread::available_parallelism().map(|v| v.get()).unwrap_or(1).min(8);
    let mut a = Args {
        case,
        size: (1024, 768),
        profile: "default".into(),
        repeats: 3,
        duration: 0.0,
        threads: hw,
        band_rows: 256,
        band_px: 800_000,
        in_place: false,
        steps: 20,
        batch: 4,
        save: None,
        compare: None,
        rows: None,
    };
    while let Some(flag) = it.next() {
        let mut val = || it.next().ok_or(format!("{} needs a value", flag));
        match flag.as_str() {
            "--size" => {
                let v = val()?;
                let (w, h) = v.split_once('x').ok_or("--size WxH")?;
                a.size = (w.parse().map_err(|_| "bad width")?, h.parse().map_err(|_| "bad height")?);
            }
            "--mp" => {
                let mp: f64 = val()?.parse().map_err(|_| "bad --mp")?;
                let w = (mp * 1e6 * 4.0 / 3.0).sqrt().round() as usize;
                a.size = (w, w * 3 / 4);
            }
            "--profile" => a.profile = val()?,
            "--repeats" => a.repeats = val()?.parse().map_err(|_| "bad --repeats")?,
            "--duration" => a.duration = val()?.parse().map_err(|_| "bad --duration")?,
            "--threads" => a.threads = val()?.parse().map_err(|_| "bad --threads")?,
            "--band-rows" => a.band_rows = val()?.parse().map_err(|_| "bad --band-rows")?,
            "--band-px" => a.band_px = val()?.parse().map_err(|_| "bad --band-px")?,
            "--steps" => a.steps = val()?.parse().map_err(|_| "bad --steps")?,
            "--batch" => a.batch = val()?.parse().map_err(|_| "bad --batch")?,
            "--rows" => a.rows = Some(val()?.parse().map_err(|_| "bad --rows")?),
            "--save" => a.save = Some(val()?),
            "--compare" => a.compare = Some(val()?),
            "--in-place" => a.in_place = true,
            other => return Err(format!("unknown flag {}", other)),
        }
    }
    Ok(a)
}

// ------------------------------------------------------------------------------------------------ reporting

fn kv(key: &str, value: impl std::fmt::Display) {
    println!("{}={}", key, value);
}

fn median(v: &mut Vec<f64>) -> f64 {
    v.sort_by(|a, b| a.partial_cmp(b).unwrap());
    v[v.len() / 2]
}

fn header(a: &Args) {
    kv("case", &a.case);
    kv("profile", &a.profile);
    kv("size", format!("{}x{}", a.size.0, a.size.1));
    kv("megapixels", format!("{:.2}", (a.size.0 * a.size.1) as f64 / 1e6));
    kv("threads", a.threads);
    kv("cores_available", std::thread::available_parallelism().map(|v| v.get()).unwrap_or(1));
    kv("backend", nn::backend_name());
    kv("build", std::env::var("NOVA_BENCH_LABEL").unwrap_or_else(|_| "unlabeled".into()));
}

fn footer(wall: f64, cpu0: Option<u64>, mark: HeapMark) {
    let (allocs, large, bytes, peak_extra) = heap_since(mark);
    kv("allocations", allocs);
    kv("large_allocations", large);
    kv("alloc_bytes_total_mb", format!("{:.1}", bytes as f64 / 1048576.0));
    kv("peak_extra_heap_mb", format!("{:.1}", peak_extra as f64 / 1048576.0));
    if let Some(kb) = proc_status_kb("VmHWM:") {
        kv("peak_rss_mb", format!("{:.1}", kb as f64 / 1024.0));
    }
    if let (Some(c0), Some(c1)) = (cpu0, cpu_ticks()) {
        let cpu_s = (c1 - c0) as f64 / 100.0;
        kv("cpu_seconds", format!("{:.2}", cpu_s));
        kv("avg_cores_busy", format!("{:.2}", cpu_s / wall.max(1e-9)));
    }
}

// ------------------------------------------------------------------------------------------------ cases

fn case_enhance(a: &Args) -> Result<(), String> {
    let (w, h) = a.size;
    let opts = options_for(&a.profile)?;
    let use_cnn = opts[STRENGTH] > 0.0;
    let params = bench_params();
    let src = Image::photo(w, h);
    let rows_limit = a.rows.unwrap_or(h).min(h);
    // A separate destination unless in place (in place keeps a pristine copy of the source for each repeat).
    let pristine = if a.in_place { Some(src.buf.clone()) } else { None };
    let dst = if a.in_place { None } else { Some(Image::new(w, h)) };
    header(a);
    kv("cnn", use_cnn);
    kv("rows_processed", rows_limit);
    kv("in_place", a.in_place);
    kv("band_rows", a.band_rows);
    kv("band_px", a.band_px);

    let mark = heap_mark();
    let cpu0 = cpu_ticks();
    let t_all = Instant::now();
    let mut totals: Vec<f64> = Vec::new();
    let mut opens: Vec<f64> = Vec::new();
    let mut iter = 0usize;
    let mut first_rss = None;
    let mut last_rss = None;
    let mut last_sum = 0u64;
    loop {
        if a.duration > 0.0 {
            if t_all.elapsed().as_secs_f64() >= a.duration {
                break;
            }
        } else if iter >= a.repeats {
            break;
        }
        if let Some(p) = pristine.as_ref() {
            // SAFETY-free restore: copy the pristine bytes back through the same raw pointer the rows use.
            for y in 0..h {
                src.write_row(y, &p[y * w * 4..(y + 1) * w * 4]);
            }
        }
        let t0 = Instant::now();
        let session = Session::open(&src, &opts, if use_cnn { Some(params.as_slice()) } else { None }, a.band_px, a.threads);
        let t_open = t0.elapsed().as_secs_f64();
        if iter == 0 {
            kv("context_rows", session.context_rows());
        }
        let out: &Image = dst.as_ref().unwrap_or(&src);
        let mut y0 = 0usize;
        let t1 = Instant::now();
        while y0 < rows_limit {
            let y1 = (y0 + a.band_rows).min(rows_limit);
            session.process_rows(&src, out, y0, y1, a.in_place, a.threads)?;
            y0 = y1;
        }
        let t_process = t1.elapsed().as_secs_f64();
        let total = t0.elapsed().as_secs_f64();
        drop(session);
        totals.push(total);
        opens.push(t_open);
        let rss = proc_status_kb("VmRSS:").unwrap_or(0);
        first_rss.get_or_insert(rss);
        last_rss = Some(rss);
        last_sum = out.checksum();
        println!(
            "iter={} total_s={:.3} open_s={:.3} process_s={:.3} mpix_per_s={:.2} rss_mb={:.1}",
            iter,
            total,
            t_open,
            t_process,
            (w * rows_limit) as f64 / 1e6 / t_process.max(1e-9),
            rss as f64 / 1024.0
        );
        iter += 1;
    }
    let wall = t_all.elapsed().as_secs_f64();
    let mut sorted = totals.clone();
    let med = median(&mut sorted);
    let best = sorted[0];
    kv("runs", totals.len());
    kv("best_s", format!("{:.3}", best));
    kv("median_s", format!("{:.3}", med));
    kv("open_median_s", format!("{:.3}", { let mut o = opens.clone(); median(&mut o) }));
    kv("mpix_per_s_median", format!("{:.2}", (w * rows_limit) as f64 / 1e6 / med));
    if totals.len() >= 4 {
        let q = totals.len() / 4;
        let first: f64 = totals[..q].iter().sum::<f64>() / q as f64;
        let lastq: f64 = totals[totals.len() - q..].iter().sum::<f64>() / q as f64;
        kv("first_quartile_mean_s", format!("{:.3}", first));
        kv("last_quartile_mean_s", format!("{:.3}", lastq));
        kv("drift_percent", format!("{:+.1}", (lastq / first - 1.0) * 100.0));
    }
    if let (Some(f), Some(l)) = (first_rss, last_rss) {
        kv("rss_growth_mb_over_runs", format!("{:.1}", (l as f64 - f as f64) / 1024.0));
    }
    kv("output_checksum", format!("{:016x}", last_sum));
    footer(wall, cpu0, mark);

    let out: &Image = dst.as_ref().unwrap_or(&src);
    if let Some(path) = &a.save {
        std::fs::write(path, &out.buf).map_err(|e| e.to_string())?;
        kv("saved", path);
    }
    if let Some(path) = &a.compare {
        let reference = std::fs::read(path).map_err(|e| e.to_string())?;
        if reference.len() != out.buf.len() {
            return Err("compare file has a different size".into());
        }
        let (mut max_d, mut diff_px, mut sq) = (0i32, 0u64, 0f64);
        for (i, (x, y)) in out.buf.iter().zip(reference.iter()).enumerate() {
            let d = (*x as i32 - *y as i32).abs();
            if i % 4 != 3 {
                sq += (d * d) as f64;
            }
            max_d = max_d.max(d);
            if d != 0 {
                diff_px += 1;
            }
        }
        let n = (out.buf.len() / 4 * 3) as f64;
        let mse = sq / n;
        kv("compare_max_abs_diff", max_d);
        kv("compare_differing_values", diff_px);
        kv("compare_differing_percent", format!("{:.4}", diff_px as f64 / out.buf.len() as f64 * 100.0));
        kv("compare_psnr_db", if mse == 0.0 { "inf".to_string() } else { format!("{:.2}", 10.0 * (255.0f64 * 255.0 / mse).log10()) });
    }
    Ok(())
}

fn case_infer(a: &Args) -> Result<(), String> {
    use novaenhance_native::nn::{infer::infer_rgb, weights::PackedWeights};
    let (w, h) = a.size;
    let params = bench_params();
    let weights = PackedWeights::pack(&params, false);
    let mut rng = Rng::new(5);
    let src: Vec<f32> = (0..w * h * 3).map(|_| rng.next_f32() * 255.0).collect();
    let mut dst = vec![0.0f32; w * h * 3];
    header(a);
    let mark = heap_mark();
    let cpu0 = cpu_ticks();
    let t_all = Instant::now();
    let mut times = Vec::new();
    for i in 0..a.repeats.max(1) {
        let t = Instant::now();
        infer_rgb(&src, w, h, &weights, &mut dst, a.threads);
        let s = t.elapsed().as_secs_f64();
        println!("iter={} total_s={:.3} mpix_per_s={:.3}", i, s, (w * h) as f64 / 1e6 / s);
        times.push(s);
    }
    let wall = t_all.elapsed().as_secs_f64();
    let med = median(&mut times.clone());
    kv("best_s", format!("{:.3}", times.iter().cloned().fold(f64::MAX, f64::min)));
    kv("median_s", format!("{:.3}", med));
    kv("mpix_per_s_median", format!("{:.3}", (w * h) as f64 / 1e6 / med));
    kv("gmac_per_s_median", format!("{:.2}", (w * h) as f64 * 44_208.0 / 1e9 / med));
    let sum: f64 = dst.iter().map(|v| *v as f64).sum();
    kv("output_sum", format!("{:.3}", sum));
    footer(wall, cpu0, mark);
    Ok(())
}

fn case_train(a: &Args) -> Result<(), String> {
    let b = a.batch.max(1);
    let mut params = vec![0.0f32; TOTAL_PARAMS];
    nn::initialize_params(&mut params, 1);
    let mut momentum = vec![0.0f32; TOTAL_PARAMS];
    let mut velocity = vec![0.0f32; TOTAL_PARAMS];
    let mut rng = Rng::new(11);
    let target: Vec<f32> = (0..b * OUTPUT_FLOATS).map(|i| ((i / 3) % 64) as f32 / 63.0).collect();
    let input: Vec<f32> = target.iter().map(|v| (v + 0.1 * rng.normal()).max(0.0).min(1.0)).collect();
    assert_eq!(input.len(), b * INPUT_FLOATS);
    header(a);
    kv("batch", b);
    let mark = heap_mark();
    let cpu0 = cpu_ticks();
    let t_all = Instant::now();
    let mut times = Vec::new();
    let mut first = 0.0;
    let mut last = 0.0;
    for step in 1..=a.steps.max(1) {
        let t = Instant::now();
        let loss = nn::train_step(&input, &target, b, &mut params, &mut momentum, &mut velocity, None, step as i32, 1e-3, 0.0, a.threads);
        times.push(t.elapsed().as_secs_f64() * 1000.0);
        if step == 1 {
            first = loss;
        }
        last = loss;
    }
    let wall = t_all.elapsed().as_secs_f64();
    let med = median(&mut times.clone());
    kv("steps", times.len());
    kv("step_ms_median", format!("{:.2}", med));
    kv("step_ms_best", format!("{:.2}", times.iter().cloned().fold(f64::MAX, f64::min)));
    kv("tiles_per_s_median", format!("{:.1}", b as f64 / (med / 1000.0)));
    kv("loss_first", format!("{:.6}", first));
    kv("loss_last", format!("{:.6}", last));
    footer(wall, cpu0, mark);
    nn::train::release_workspace();
    Ok(())
}

/// How much does one `run_jobs` call cost when the jobs themselves do (almost) nothing? That is the scheduling
/// overhead a worker pool could at best remove. The `pool` rows time a best-case persistent pool (idle workers that
/// are woken through a mutex + condvar) for comparison.
// NEW-ONLY-BEGIN (tools/bench.sh strips these blocks when it builds this file against an older source tree)
/// The device-side kernel race the engine runs once per process: both convolution kernels on a 48 -> 48 row.
/// Run it a few times (`--repeats`) - on a phone the numbers depend on which core the thread lands on.
fn case_kernel(a: &Args) -> Result<(), String> {
    use novaenhance_native::nn::kernels;
    header(a);
    for i in 0..a.repeats.max(1) {
        let c = kernels::measure();
        println!(
            "run={} reference_gmac_s={:.2} blocked_gmac_s={:.2} blocked_over_reference={:.2} choice={}",
            i,
            c.reference_gmac_s,
            c.blocked_gmac_s,
            c.blocked_gmac_s / c.reference_gmac_s,
            c.choice.name()
        );
    }
    kv("engine_choice", kernels::active_kernel().name());
    Ok(())
}
// NEW-ONLY-END

fn case_spawn(a: &Args) -> Result<(), String> {
    use novaenhance_native::par::run_jobs;
    use std::sync::{Arc, Condvar, Mutex};
    header(a);
    for &t in &[1usize, 2, 4, 8] {
        let iterations = 3000;
        let t0 = Instant::now();
        for _ in 0..iterations {
            let jobs: Vec<usize> = (0..t * 2).collect();
            let states = run_jobs(jobs, t, || 0u64, |s, j| *s += j as u64);
            std::hint::black_box(states);
        }
        let per_call = t0.elapsed().as_secs_f64() / iterations as f64 * 1e6;
        println!("scoped_threads={} us_per_call={:.1} us_per_thread={:.1}", t, per_call, if t > 1 { per_call / t as f64 } else { 0.0 });
    }
    // Best-case persistent pool: `t` workers parked on a condvar; a call publishes a generation number and waits for
    // all of them to report back. (A real pool borrowing the caller's data would need unsafe lifetime erasure; this
    // lower bound ignores that and the job hand-out entirely.)
    for &t in &[2usize, 4, 8] {
        struct Shared {
            gen: Mutex<(u64, usize, bool)>, // (generation, finished workers, quit)
            go: Condvar,
            done: Condvar,
        }
        let shared = Arc::new(Shared { gen: Mutex::new((0, 0, false)), go: Condvar::new(), done: Condvar::new() });
        let mut handles = Vec::new();
        for _ in 0..t {
            let s = shared.clone();
            handles.push(std::thread::spawn(move || {
                let mut seen = 0u64;
                loop {
                    let mut g = s.gen.lock().unwrap();
                    while g.0 == seen && !g.2 {
                        g = s.go.wait(g).unwrap();
                    }
                    if g.2 {
                        return;
                    }
                    seen = g.0;
                    drop(g);
                    let mut g = s.gen.lock().unwrap();
                    g.1 += 1;
                    if g.1 == usize::MAX {
                        return;
                    }
                    s.done.notify_all();
                }
            }));
        }
        let iterations = 3000;
        let t0 = Instant::now();
        for _ in 0..iterations {
            let mut g = shared.gen.lock().unwrap();
            g.0 += 1;
            g.1 = 0;
            shared.go.notify_all();
            while g.1 < t {
                g = shared.done.wait(g).unwrap();
            }
        }
        let per_call = t0.elapsed().as_secs_f64() / iterations as f64 * 1e6;
        {
            let mut g = shared.gen.lock().unwrap();
            g.2 = true;
            shared.go.notify_all();
        }
        for h in handles {
            let _ = h.join();
        }
        println!("pool_threads={} us_per_call={:.1}", t, per_call);
    }
    Ok(())
}

fn main() {
    let args = match parse_args() {
        Ok(a) => a,
        Err(e) => {
            eprintln!("{}", e);
            std::process::exit(2);
        }
    };
    let result = match args.case.as_str() {
        "enhance" => case_enhance(&args),
        "infer" => case_infer(&args),
        "train" => case_train(&args),
        "spawn" => case_spawn(&args),
        // NEW-ONLY-BEGIN
        "kernel" => case_kernel(&args),
        // NEW-ONLY-END
        other => Err(format!("unknown case '{}'", other)),
    };
    if let Err(e) = result {
        eprintln!("error: {}", e);
        std::process::exit(1);
    }
}
