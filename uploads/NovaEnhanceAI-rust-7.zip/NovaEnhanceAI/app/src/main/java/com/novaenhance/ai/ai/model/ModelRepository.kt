package com.novaenhance.ai.ai.model

import com.novaenhance.ai.ai.engine.CheckpointCorruptedException
import com.novaenhance.ai.ai.engine.CheckpointSizeMismatchException
import com.novaenhance.ai.ai.engine.NativeNeuralEngine
import com.novaenhance.ai.ai.engine.NovaModelEngine
import com.novaenhance.ai.database.dao.ModelDao
import com.novaenhance.ai.database.dao.ModelVersionDao
import com.novaenhance.ai.database.entities.ModelEntity
import com.novaenhance.ai.database.entities.ModelVersionEntity
import com.novaenhance.ai.storage.AppStorage
import com.novaenhance.ai.training.checkpoint.CheckpointManager
import com.novaenhance.ai.utils.NovaLog
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File

private const val TAG = "ModelRepository"

/**
 * Thrown by [ModelRepository.importModel] when a file can't be imported. The message is written for the person
 * using the app (it is shown as is), not for a log.
 */
class ModelImportException(message: String, cause: Throwable? = null) : Exception(message, cause)

/**
 * Owns the mapping from "which model is active" to "which [NovaModelEngine]
 * is currently loaded in memory," plus the Model Manager / Model Version
 * Management operations (switch/rename/export/import/backup/delete/
 * compare/restore).
 *
 * Only ever holds ONE [NovaModelEngine] loaded at a time - only one model
 * is ever active for Enhance Image or Train AI at once, so there's no
 * reason to keep more in memory.
 *
 * Unlike this project's earlier TFLite-based design, there is no bundled
 * asset to bootstrap from and no separate "architecture" file shared across
 * versions: [createModel] generates a brand-new model with randomly
 * initialized weights directly (see [NativeNeuralEngine.initializeParams]),
 * and each [ModelVersionEntity] is simply its own weights file.
 */
class ModelRepository(
    private val storage: AppStorage,
    private val checkpointManager: CheckpointManager,
    private val modelDao: ModelDao,
    private val modelVersionDao: ModelVersionDao
) {
    private val loadMutex = Mutex()
    private val bootstrapMutex = Mutex()
    private var loadedEngine: NovaModelEngine? = null
    private var loadedModelId: String? = null

    companion object {
        /**
         * Single source of truth for the app's default model identity, used
         * by both [com.novaenhance.ai.NovaEnhanceApplication]'s eager
         * bootstrap (so the Dashboard has something to show immediately)
         * AND [getOrCreateActiveModel]'s lazy fallback (so a model-requiring
         * action taken before that eager bootstrap finishes - or if it
         * somehow failed - creates the SAME model rather than a duplicate
         * with a different id.
         */
        const val DEFAULT_MODEL_ID = "general"
        const val DEFAULT_MODEL_NAME = "General Photo AI"
        const val DEFAULT_MODEL_DESCRIPTION =
            "A general-purpose photo enhancement model that learns from the pairs you teach it."
    }

    /**
     * Returns the currently active model, creating the default one on the
     * spot if none exists yet. This is the self-healing safety net behind
     * every model-requiring screen (Enhance, Train, Dataset Manager): the
     * eager bootstrap in [com.novaenhance.ai.NovaEnhanceApplication] should
     * normally have already created a model long before any UI is
     * interacted with, but if a user somehow acts before that finishes (or
     * it failed for an unrelated reason), this guarantees the action still
     * works instead of surfacing an avoidable "no model" error - unlike
     * this project's earlier TFLite-based design, creating a model needs no
     * external asset or generation step, so there's no legitimate reason
     * for a user-facing action to ever fail purely because no model exists
     * yet.
     */
    suspend fun getOrCreateActiveModel(): ModelEntity = bootstrapMutex.withLock {
        modelDao.getActive()?.let { return@withLock it }

        // A model row might exist without being flagged active (shouldn't
        // normally happen, but cheap to handle rather than create a
        // needless duplicate).
        modelDao.getAny()?.let { existing ->
            modelDao.setActive(existing.id)
            return@withLock existing.copy(isActive = true)
        }

        NovaLog.i(TAG, "No model registered yet - creating the default model on demand")
        createModel(DEFAULT_MODEL_ID, DEFAULT_MODEL_NAME, DEFAULT_MODEL_DESCRIPTION)
    }

    suspend fun getEngine(modelId: String): NovaModelEngine = loadMutex.withLock {
        loadedEngine?.let { if (loadedModelId == modelId) return it }

        loadedEngine = null
        loadedModelId = null

        val activeVersion = modelVersionDao.getActiveVersion(modelId)
            ?: error("No active version registered for model $modelId")
        val weightsFile = File(activeVersion.weightsFilePath)
        require(weightsFile.exists()) { "Weights file missing on disk: ${weightsFile.path}" }

        val engine = try {
            NovaModelEngine.loadFromCheckpoint(weightsFile.path)
        } catch (e: CheckpointCorruptedException) {
            // The active version's file itself is damaged (most likely a
            // relic of the pre-AtomicCheckpointFile non-atomic save path -
            // new saves can't produce this). Unlike a size mismatch, the
            // *shape* is still right, so try this same version's own
            // crash-safety fallback (see AtomicCheckpointFile) before ever
            // giving up and wiping the model's learned weights.
            NovaLog.w(TAG, "${e.message} - trying this version's own crash-safety fallback before resetting", e)
            NovaModelEngine.tryRecoverInProgress(weightsFile.path) ?: run {
                NovaLog.w(TAG, "No usable generation left for $modelId's active version - resetting weights fresh; its dataset pairs are untouched")
                resetToFreshWeights(modelId, activeVersion, weightsFile)
            }
        } catch (e: CheckpointSizeMismatchException) {
            NovaLog.w(TAG, "${e.message} - resetting $modelId's weights fresh at the current size; its dataset pairs are untouched")
            resetToFreshWeights(modelId, activeVersion, weightsFile)
        }
        loadedEngine = engine
        loadedModelId = modelId
        engine
    }

    /**
     * Installs [engine] as [modelId]'s currently loaded engine, overwriting
     * whatever was cached. Used by [com.novaenhance.ai.training.trainer.ModelTrainer]
     * to resume training from a validated in-progress checkpoint after an
     * app/process restart, so the rest of the app (this same cache is also
     * what the Enhance screen reads from - see the class doc above) keeps
     * seeing one consistent engine for [modelId] rather than [getEngine]
     * loading a second, different one from the promoted active version
     * right alongside it.
     */
    suspend fun installResumedEngine(modelId: String, engine: NovaModelEngine): NovaModelEngine = loadMutex.withLock {
        loadedEngine = engine
        loadedModelId = modelId
        engine
    }

    /** Shared by both the size-mismatch and out-of-fallbacks-corruption paths in [getEngine]. */
    private suspend fun resetToFreshWeights(modelId: String, activeVersion: ModelVersionEntity, weightsFile: File): NovaModelEngine {
        val fresh = NovaModelEngine.createFresh()
        fresh.saveCheckpoint(weightsFile.path)
        val newSize = weightsFile.length()
        modelVersionDao.update(
            activeVersion.copy(parameterCount = NativeNeuralEngine.TOTAL_PARAMS.toLong(), sizeBytes = newSize)
        )
        // The old weights this model had learned are gone along with the incompatible file,
        // so the stats describing "how trained is this model" need to reset with them -
        // otherwise the Dashboard would keep showing e.g. "3 sessions, 45% improvement" for
        // what's now a blank, freshly-initialized model.
        modelDao.getById(modelId)?.let { model ->
            modelDao.update(
                model.copy(
                    parameterCount = NativeNeuralEngine.TOTAL_PARAMS.toLong(),
                    sizeBytes = newSize,
                    trainingSessionCount = 0,
                    totalImagesLearned = 0,
                    lastTrainedAt = null,
                    improvementScore = 0f
                )
            )
        }
        return fresh
    }

    /**
     * Creates a brand-new model with freshly, randomly initialized weights -
     * no bundled asset, no external generation step. This IS the network's
     * starting point (near-identity output, see `rust/src/nn/mod.rs`'s
     * `initializeParams` for why), not a placeholder waiting to be replaced.
     */
    suspend fun createModel(modelId: String, displayName: String, description: String): ModelEntity {
        val engine = NovaModelEngine.createFresh(seed = System.currentTimeMillis())
        val weightsFile = storage.weightsFile(modelId, 1)
        engine.saveCheckpoint(weightsFile.path)

        val metadata = ModelMetadata(modelName = displayName, parameterCount = NativeNeuralEngine.TOTAL_PARAMS, versionNumber = 1)
        ModelMetadata.sidecarFor(weightsFile).writeText(metadata.toJson())

        val now = System.currentTimeMillis()
        val model = ModelEntity(
            id = modelId,
            displayName = displayName,
            description = description,
            createdAt = now,
            currentVersionNumber = 1,
            parameterCount = NativeNeuralEngine.TOTAL_PARAMS.toLong(),
            sizeBytes = weightsFile.length(),
            trainingSessionCount = 0,
            totalImagesLearned = 0,
            lastTrainedAt = null,
            improvementScore = 0f,
            isActive = modelDao.getActive() == null // first model created becomes active by default
        )
        modelDao.upsert(model)

        modelVersionDao.insert(
            ModelVersionEntity(
                modelId = modelId,
                versionNumber = 1,
                weightsFilePath = weightsFile.path,
                sizeBytes = weightsFile.length(),
                parameterCount = NativeNeuralEngine.TOTAL_PARAMS.toLong(),
                createdAt = now,
                trainingSessionId = null,
                validationScore = 0f,
                isPromoted = true,
                isActive = true,
                notes = "Freshly initialized model"
            )
        )
        return model
    }

    suspend fun switchActiveModel(modelId: String) {
        modelDao.deactivateAll()
        modelDao.setActive(modelId)
    }

    suspend fun renameModel(modelId: String, newName: String) {
        val model = modelDao.getById(modelId) ?: return
        modelDao.update(model.copy(displayName = newName))
    }

    /** Model Version Management: restore an older version as the active one - a DB flag flip, the weights file was never deleted. */
    suspend fun restoreVersion(modelId: String, versionId: Long) = loadMutex.withLock {
        val version = modelVersionDao.getById(versionId) ?: return@withLock
        require(File(version.weightsFilePath).exists()) { "Weights file missing for version ${version.versionNumber}" }

        modelVersionDao.deactivateAllForModel(modelId)
        modelVersionDao.activate(versionId)

        modelDao.getById(modelId)?.let { model ->
            modelDao.update(
                model.copy(
                    currentVersionNumber = version.versionNumber,
                    parameterCount = version.parameterCount,
                    sizeBytes = version.sizeBytes
                )
            )
        }

        if (loadedModelId == modelId) {
            loadedEngine = null
            loadedModelId = null
        }
        NovaLog.i(TAG, "Restored model $modelId to version ${version.versionNumber}")
    }

    suspend fun backupVersion(modelId: String, versionId: Long): File {
        val version = modelVersionDao.getById(versionId) ?: error("Version not found")
        val destZip = storage.backupFile(modelId, version.versionNumber, System.currentTimeMillis())
        writeBundle(version, destZip)
        return destZip
    }

    /** Deletes a version's weights file + DB row. Refuses to delete the currently active version or v1 (the model's baseline). */
    suspend fun deleteVersion(versionId: Long): Boolean {
        val version = modelVersionDao.getById(versionId) ?: return false
        if (version.isActive) {
            NovaLog.w(TAG, "Refusing to delete active version ${version.versionNumber} for ${version.modelId}")
            return false
        }
        if (version.versionNumber == 1) {
            NovaLog.w(TAG, "Refusing to delete version 1 (baseline) for ${version.modelId}")
            return false
        }
        val deletedRows = modelVersionDao.deleteIfInactive(versionId)
        if (deletedRows > 0) {
            File(version.weightsFilePath).delete()
            ModelMetadata.sidecarFor(File(version.weightsFilePath)).delete()
        }
        return deletedRows > 0
    }

    suspend fun deleteModel(modelId: String) {
        if (loadedModelId == modelId) {
            loadedEngine = null
            loadedModelId = null
        }
        modelDao.delete(modelId) // cascades to model_versions/dataset_pairs/training_sessions/replay_buffer via FK
        storage.modelDir(modelId).deleteRecursively()
        storage.datasetDir(modelId).deleteRecursively()
        storage.checkpointDir(modelId).deleteRecursively()
    }

    /**
     * Packages a version as a portable `.novamodel` bundle in the app's export directory, ready for FileProvider
     * sharing (see [com.novaenhance.ai.utils.shareModelBundle]).
     */
    suspend fun exportVersion(versionId: Long): File {
        val version = modelVersionDao.getById(versionId) ?: error("Version not found")
        val model = modelDao.getById(version.modelId)
        val destZip = storage.exportFile(version.modelId, version.versionNumber, model?.displayName)
        writeBundle(version, destZip)
        return destZip
    }

    /** [exportVersion] for the model currently in use - what the Parameters screen shares. */
    suspend fun exportActiveVersion(): File {
        val model = getOrCreateActiveModel()
        val version = modelVersionDao.getActiveVersion(model.id) ?: error("This model has no saved version yet")
        return exportVersion(version.id)
    }

    /**
     * Writes [version] as a bundle at [destZip]. The metadata is generated here, from the registry, instead of
     * read from a sidecar file: only a model's first version ever had one (versions written by training did
     * not), which made exporting any trained version fail.
     */
    private suspend fun writeBundle(version: ModelVersionEntity, destZip: File) {
        val weights = File(version.weightsFilePath)
        require(weights.exists()) { "Weights file missing for version ${version.versionNumber}" }
        val model = modelDao.getById(version.modelId)
        val metadata = ModelMetadata(
            modelName = model?.displayName ?: DEFAULT_MODEL_NAME,
            parameterCount = version.parameterCount.toInt(),
            versionNumber = version.versionNumber,
            trainingSessionCount = model?.trainingSessionCount ?: 0,
            totalImagesLearned = model?.totalImagesLearned ?: 0,
            improvementScore = model?.improvementScore ?: 0f,
            lastTrainedAt = model?.lastTrainedAt
        )
        withContext(Dispatchers.IO) {
            checkpointManager.exportBundle(weightsFile = weights, metadataJson = metadata.toJson(), destZip = destZip)
        }
    }

    /**
     * Imports a `.novamodel` bundle (see [CheckpointManager]) as a new model registry entry and, unless
     * [activate] is false, makes it the model in use - the point of receiving a trained model is to use it.
     *
     * The weights are fully validated (magic, parameter count, checksum, every value finite) BEFORE anything is
     * registered, so a damaged or foreign file is refused with a readable [ModelImportException] instead of
     * becoming a model that later resets itself.
     */
    suspend fun importModel(
        bundleZip: File,
        modelId: String,
        displayName: String? = null,
        activate: Boolean = true
    ): ModelEntity {
        try {
            val imported = withContext(Dispatchers.IO) {
                checkpointManager.importBundle(
                    zipFile = bundleZip,
                    destDir = storage.checkpointDir(modelId),
                    versionNumber = 1
                )
            }

            try {
                NovaModelEngine.loadFromCheckpoint(imported.weightsFile.path)
            } catch (e: CheckpointSizeMismatchException) {
                throw ModelImportException(
                    "This model was made for a different version of the AI network (its size does not match " +
                        "this app's ${NativeNeuralEngine.TOTAL_PARAMS} parameters), so it can't be used here.",
                    e
                )
            } catch (e: CheckpointCorruptedException) {
                throw ModelImportException(
                    "The model file is damaged - it may have been cut short while it was sent. Send it again and retry.",
                    e
                )
            }

            val metadata = try {
                ModelMetadata.fromFile(imported.metadataFile)
            } catch (e: Exception) {
                null
            }
            val now = System.currentTimeMillis()
            val name = displayName?.takeIf { it.isNotBlank() } ?: importedName(metadata?.modelName)

            val model = ModelEntity(
                id = modelId, displayName = name, description = "Imported model",
                createdAt = now, currentVersionNumber = 1,
                parameterCount = NativeNeuralEngine.TOTAL_PARAMS.toLong(),
                sizeBytes = imported.weightsFile.length(),
                trainingSessionCount = metadata?.trainingSessionCount ?: 0,
                totalImagesLearned = metadata?.totalImagesLearned ?: 0,
                lastTrainedAt = metadata?.lastTrainedAt,
                improvementScore = metadata?.improvementScore ?: 0f,
                isActive = false
            )
            modelDao.upsert(model)
            modelVersionDao.insert(
                ModelVersionEntity(
                    modelId = modelId, versionNumber = 1,
                    weightsFilePath = imported.weightsFile.path,
                    sizeBytes = imported.weightsFile.length(),
                    parameterCount = NativeNeuralEngine.TOTAL_PARAMS.toLong(),
                    createdAt = now, trainingSessionId = null, validationScore = 0f,
                    isPromoted = true, isActive = true, notes = "Imported from ${bundleZip.name}"
                )
            )
            if (activate) switchActiveModel(modelId)
            NovaLog.i(TAG, "Imported model $modelId (\"$name\"), active=$activate")
            return model.copy(isActive = activate)
        } catch (e: CancellationException) {
            storage.checkpointDir(modelId).deleteRecursively()
            throw e
        } catch (e: Throwable) {
            // Nothing half-imported is left behind: not the files, and not a registry row if one got as far as being written.
            storage.checkpointDir(modelId).deleteRecursively()
            runCatching { modelDao.delete(modelId) }
            if (e is ModelImportException) throw e
            NovaLog.w(TAG, "Import of ${bundleZip.name} failed", e)
            throw ModelImportException(
                "That file isn't a NovaEnhance model (.novamodel), or it can't be read.",
                e
            )
        }
    }

    /** A received model gets "(imported)" added so it can't be mistaken for a model this phone made itself. */
    private fun importedName(sentName: String?): String {
        val base = sentName?.trim().orEmpty().ifEmpty { "Imported model" }
        return if (base.endsWith("(imported)")) base else "$base (imported)"
    }
}
