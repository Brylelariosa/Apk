package com.novaenhance.ai.utils

import android.os.Build
import com.novaenhance.ai.BuildConfig
import com.novaenhance.ai.ai.engine.NativeNeuralEngine
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Assembles a plain-text snapshot of "what's going on with this install"
 * for the user to save out of Settings (it is part 1 of the file
 * [LogExporter] writes to Downloads) and hand to someone debugging a
 * report of slow/broken behavior. Device specs plus recent [NovaLog]
 * activity - tile-processing timings, dataset-analysis duration, training
 * failures, and so on - is usually enough to tell a real hardware/dataset-
 * size constraint apart from an actual bug, without needing a full
 * bug-report export or any remote telemetry.
 *
 * Pure function of its input (no Context, no singletons reached into
 * directly) so it's trivial to call from a ViewModel or test in isolation -
 * [DeviceCapabilities] is the only thing that needs a Context, and that
 * stays the caller's responsibility.
 */
object DiagnosticsReport {

    private val timestampFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)

    fun build(device: DeviceSnapshot, lastCrash: String? = null): String = buildString {
        if (lastCrash != null) {
            appendLine("--- Last crash (most recent launch that crashed) ---")
            appendLine(lastCrash)
            appendLine()
        }
        appendLine("NovaEnhance AI debug info")
        appendLine("Generated: ${timestampFormat.format(Date(System.currentTimeMillis()))}")
        appendLine()
        appendLine("--- App ---")
        appendLine("Version: ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE}, ${BuildConfig.BUILD_TYPE})")
        appendLine()
        appendLine("--- Device ---")
        appendLine("Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}), ${Build.MANUFACTURER} ${Build.MODEL}")
        appendLine("CPU cores: ${device.cpuCoreCount}")
        // Which convolution kernels the native library actually runs: the CPU family ("rust-aarch64-neon" on a 64-bit
        // phone, "rust-armv7-neon" on a 32-bit userland, "rust-portable" would mean no ARM build - a slow one),
        // then "/blocked" or "/reference": the implementation this phone measured as faster the first time the
        // network ran (both give the same numbers; see docs/PERFORMANCE.md). The first call times them, a few ms.
        // runCatching: this report must still render if the native library failed to load.
        appendLine("Native kernels: ${runCatching { NativeNeuralEngine.backendName }.getOrDefault("unavailable")}")
        appendLine(
            "Thread budget: enhance ${ComputeBudget.enhancementThreads(device.cpuCoreCount)}, " +
                "train ${ComputeBudget.trainingThreads(device.cpuCoreCount)}"
        )
        appendLine(
            "RAM: ${device.availableRamMb}MB available / ${device.totalRamMb}MB total" +
                if (device.isLowRamDevice) " (flagged low-RAM device)" else ""
        )
        // The working-set cap a photo enhancement would get right now (RAM tier, limited by what is free).
        appendLine(
            "Enhance band budget: " +
                "${ComputeBudget.maxBandPixels(ComputeBudget.RamInfo(device.totalRamMb, device.availableRamMb, device.isLowRamDevice))}" +
                " px per native chunk"
        )
        appendLine("Battery: ${device.batteryPercent}%${if (device.isCharging) " (charging)" else ""}")
        appendLine("Thermal status: ${device.thermalStatus}")
        // 0.0 cool .. 1.0 = Android starts severe throttling. Many budget phones do not report it at all.
        appendLine(
            "Thermal headroom (10 s forecast): " +
                if (device.thermalHeadroom.isNaN()) "not reported by this phone" else String.format(Locale.US, "%.2f", device.thermalHeadroom)
        )
        appendLine()
        appendLine("--- Recent activity (most recent last) ---")
        val history = NovaLog.recentHistory()
        if (history.isEmpty()) {
            appendLine("(none yet this session)")
        } else {
            history.forEach { appendLine(it) }
        }
    }
}
