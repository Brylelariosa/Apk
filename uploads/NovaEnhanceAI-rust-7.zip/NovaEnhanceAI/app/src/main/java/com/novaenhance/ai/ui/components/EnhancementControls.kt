package com.novaenhance.ai.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.novaenhance.ai.ai.engine.EnhancementOptions

/**
 * The controls of the Enhance screen, arranged so that NONE of them needs a long scroll and the preview never has to
 * leave the screen while you use them.
 *
 * They used to be one tall list (four sliders, the upscaling buttons, the Auto switch, then a button that expanded
 * seventeen more sliders) under a preview that scrolled away, so adjusting a slider far down the page meant
 * scrolling the picture out of view. Now they are split into six groups, one chip each, and a group is never more
 * than six one-line sliders - about 300dp, which fits in the panel that sits under the pinned preview:
 *
 *  * Basic   the original four sliders and the 1x / 2x / 4x upscaling
 *  * Auto    the "Auto enhance" switch and how strongly it is applied
 *  * Light   exposure, contrast, shadows, highlights, auto levels, low-light boost
 *  * Colour  white balance, vibrance, dehaze
 *  * Detail  clarity, fine detail, deblur, local contrast
 *  * Fix     denoise, hot pixels, banding, vignette
 *
 * A dot on a chip means something in that group is switched on, so nothing is hidden when you leave the group.
 * Every control and every option is exactly what it was before; only where it sits has changed.
 *
 * @param notes          short footnotes shown under the Basic controls (e.g. "this model is not trained yet")
 * @param maxPanelHeight how tall the panel under the chips may grow before it scrolls ([Dp.Unspecified] = no limit)
 * @param fillHeight     true when the caller gives this a fixed height (landscape): the panel then takes whatever
 *                       is left under the chips and scrolls inside it
 */
@Composable
fun EnhancementControls(
    options: EnhancementOptions,
    enabled: Boolean,
    onOptionsChange: (EnhancementOptions) -> Unit,
    modifier: Modifier = Modifier,
    notes: List<String> = emptyList(),
    maxPanelHeight: Dp = Dp.Unspecified,
    fillHeight: Boolean = false
) {
    var selected by remember { mutableIntStateOf(0) }
    val groups = ControlGroup.values()
    val group = groups[selected.coerceIn(0, groups.size - 1)]

    Surface(
        modifier = modifier,
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 2.dp,
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
    ) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                groups.forEachIndexed { index, g ->
                    NovaChoiceChip(
                        label = g.title,
                        selected = index == selected,
                        marked = options.isGroupOn(g),
                        onClick = { selected = index },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            val sizing = if (fillHeight) Modifier.weight(1f) else Modifier.heightIn(max = maxPanelHeight)
            Column(
                modifier = sizing
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 4.dp)
            ) {
                when (group) {
                    ControlGroup.Basic -> BasicControls(options, enabled, notes, onOptionsChange)
                    ControlGroup.Auto -> AutoControls(options, enabled, onOptionsChange)
                    ControlGroup.Light -> {
                        TechniqueSlider("Exposure", options.exposure, enabled, signed = true) { onOptionsChange(options.copy(exposure = it)) }
                        TechniqueSlider("Contrast", options.contrast, enabled, signed = true) { onOptionsChange(options.copy(contrast = it)) }
                        TechniqueSlider("Shadows (lift)", options.shadows, enabled) { onOptionsChange(options.copy(shadows = it)) }
                        TechniqueSlider("Highlights (recover)", options.highlights, enabled) { onOptionsChange(options.copy(highlights = it)) }
                        TechniqueSlider("Auto levels", options.autoLevels, enabled) { onOptionsChange(options.copy(autoLevels = it)) }
                        TechniqueSlider("Low-light boost", options.lowLight, enabled) { onOptionsChange(options.copy(lowLight = it)) }
                        ResetAdvancedRow(options, enabled, onOptionsChange)
                    }
                    ControlGroup.Colour -> {
                        TechniqueSlider("White balance", options.whiteBalance, enabled) { onOptionsChange(options.copy(whiteBalance = it)) }
                        TechniqueSlider("Vibrance", options.vibrance, enabled) { onOptionsChange(options.copy(vibrance = it)) }
                        TechniqueSlider("Dehaze", options.dehaze, enabled) { onOptionsChange(options.copy(dehaze = it)) }
                        ResetAdvancedRow(options, enabled, onOptionsChange)
                    }
                    ControlGroup.Detail -> {
                        TechniqueSlider("Clarity", options.clarity, enabled) { onOptionsChange(options.copy(clarity = it)) }
                        TechniqueSlider("Fine detail", options.detail, enabled) { onOptionsChange(options.copy(detail = it)) }
                        TechniqueSlider("Deblur (deconvolution)", options.deblur, enabled) { onOptionsChange(options.copy(deblur = it)) }
                        TechniqueSlider("Local contrast (CLAHE)", options.clahe, enabled) { onOptionsChange(options.copy(clahe = it)) }
                        ResetAdvancedRow(options, enabled, onOptionsChange)
                    }
                    ControlGroup.Fix -> {
                        TechniqueSlider("Denoise (non-local means)", options.denoise, enabled) { onOptionsChange(options.copy(denoise = it)) }
                        TechniqueSlider("Hot pixels / speckle", options.despike, enabled) { onOptionsChange(options.copy(despike = it)) }
                        TechniqueSlider("Remove banding", options.deband, enabled) { onOptionsChange(options.copy(deband = it)) }
                        TechniqueSlider("Vignette fix", options.vignette, enabled, signed = true) { onOptionsChange(options.copy(vignette = it)) }
                        ResetAdvancedRow(options, enabled, onOptionsChange)
                    }
                }
            }
        }
    }
}

private enum class ControlGroup(val title: String) {
    Basic("Basic"),
    Auto("Auto"),
    Light("Light"),
    Colour("Colour"),
    Detail("Detail"),
    Fix("Fix")
}

/** True when something in [group] is switched on (shown as a dot on the group's chip). */
private fun EnhancementOptions.isGroupOn(group: ControlGroup): Boolean = when (group) {
    ControlGroup.Basic -> false
    ControlGroup.Auto -> autoEnhance
    ControlGroup.Light ->
        exposure != 0f || contrast != 0f || shadows > 0f || highlights > 0f || autoLevels > 0f || lowLight > 0f
    ControlGroup.Colour -> whiteBalance > 0f || vibrance > 0f || dehaze > 0f
    ControlGroup.Detail -> clarity > 0f || detail > 0f || deblur > 0f || clahe > 0f
    ControlGroup.Fix -> denoise > 0f || despike > 0f || deband > 0f || vignette != 0f
}

/** Every advanced technique back to off (the four basic sliders and the upscaling are left alone). */
private fun EnhancementOptions.withAdvancedReset(): EnhancementOptions = copy(
    autoEnhance = false,
    autoStrength = 1f,
    whiteBalance = 0f,
    autoLevels = 0f,
    exposure = 0f,
    contrast = 0f,
    shadows = 0f,
    highlights = 0f,
    clahe = 0f,
    lowLight = 0f,
    dehaze = 0f,
    vibrance = 0f,
    clarity = 0f,
    detail = 0f,
    vignette = 0f,
    denoise = 0f,
    despike = 0f,
    deband = 0f,
    deblur = 0f
)

@Composable
private fun BasicControls(
    options: EnhancementOptions,
    enabled: Boolean,
    notes: List<String>,
    onOptionsChange: (EnhancementOptions) -> Unit
) {
    InlineSlider("Enhancement strength", options.strength, enabled = enabled) {
        onOptionsChange(options.copy(strength = it))
    }
    InlineSlider("Sharpness", options.sharpness, enabled = enabled) {
        onOptionsChange(options.copy(sharpness = it))
    }
    InlineSlider("Noise reduction", options.noiseReduction, enabled = enabled) {
        onOptionsChange(options.copy(noiseReduction = it))
    }
    InlineSlider("Color restoration", options.colorRestoration, enabled = enabled) {
        onOptionsChange(options.copy(colorRestoration = it))
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("Upscaling", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.width(InlineLabelWidth))
        Row(modifier = Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(1, 2, 4).forEach { factor ->
                NovaChoiceChip(
                    label = "${factor}x",
                    selected = options.upscaleFactor == factor,
                    enabled = enabled,
                    onClick = { onOptionsChange(options.copy(upscaleFactor = factor)) },
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
    notes.forEach { note ->
        Text(
            note,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.secondary,
            modifier = Modifier.padding(top = 4.dp, bottom = 8.dp)
        )
    }
}

@Composable
private fun AutoControls(
    options: EnhancementOptions,
    enabled: Boolean,
    onOptionsChange: (EnhancementOptions) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text("Auto enhance", style = MaterialTheme.typography.bodyLarge)
            Text(
                "Analyses each photo (colour cast, exposure, haze, noise, blur ...) and applies only what it " +
                    "needs, leaving natural colours alone. Sliders you move yourself always win.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Switch(
            checked = options.autoEnhance,
            onCheckedChange = { onOptionsChange(options.copy(autoEnhance = it)) },
            enabled = enabled
        )
    }
    if (options.autoEnhance) {
        InlineSlider(
            label = "Auto strength",
            value = options.autoStrength,
            valueRange = 0.2f..1.5f,
            enabled = enabled,
            onValueChange = { onOptionsChange(options.copy(autoStrength = it)) }
        )
    }
    ResetAdvancedRow(options, enabled, onOptionsChange)
}

@Composable
private fun ResetAdvancedRow(
    options: EnhancementOptions,
    enabled: Boolean,
    onOptionsChange: (EnhancementOptions) -> Unit
) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
        TextButton(
            onClick = { onOptionsChange(options.withAdvancedReset()) },
            enabled = enabled && options.usesAdvancedTechniques
        ) {
            Text("Reset advanced techniques")
        }
    }
}

@Composable
private fun TechniqueSlider(
    label: String,
    value: Float,
    enabled: Boolean,
    signed: Boolean = false,
    onValueChange: (Float) -> Unit
) {
    InlineSlider(
        label = label,
        value = value,
        valueRange = if (signed) -1f..1f else 0f..1f,
        enabled = enabled,
        onValueChange = onValueChange
    )
}
