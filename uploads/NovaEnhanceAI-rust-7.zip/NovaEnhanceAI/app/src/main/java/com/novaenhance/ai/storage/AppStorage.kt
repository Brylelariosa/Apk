package com.novaenhance.ai.storage

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import com.novaenhance.ai.utils.Constants
import com.novaenhance.ai.utils.NovaLog
import java.io.File

private const val TAG = "AppStorage"

/**
 * Single source of truth for every on-disk location the app uses. Nothing
 * else in the codebase should call `context.getExternalFilesDir` or build a
 * `File(...)` path by hand - route it through here so storage layout only
 * has to change in one place.
 *
 * Models/checkpoints/datasets live under app-private external storage
 * (`getExternalFilesDir(null)`), which on API 29+ requires no storage
 * permission at all and is automatically cleaned up on uninstall - fitting
 * for an app that promises "no cloud, no accounts, no servers." An enhanced
 * *photo* the user chose to save is different: that's the user's content,
 * not app data, so [saveEnhancedPhotoToGallery] deliberately does NOT use
 * app-private storage - see its doc comment.
 */
class AppStorage(private val context: Context) {

    private val root: File
        get() = context.getExternalFilesDir(null) ?: context.filesDir

    fun modelsDir(): File = childDir(root, Constants.MODELS_DIR)
    fun checkpointsDir(): File = childDir(root, Constants.CHECKPOINTS_DIR)
    fun backupsDir(): File = childDir(root, Constants.BACKUPS_DIR)
    fun datasetsDir(): File = childDir(root, Constants.DATASET_DIR)
    fun replayBufferDir(): File = childDir(root, "replay_buffer")
    fun cacheCapturesDir(): File = childDir(context.cacheDir, "captures")

    fun modelDir(modelId: String): File = childDir(modelsDir(), modelId)

    fun checkpointDir(modelId: String): File = childDir(checkpointsDir(), modelId)

    /** The single weights+optimizer-state file for one version - see NovaModelEngine's save/restore format. */
    fun weightsFile(modelId: String, versionNumber: Int): File =
        File(checkpointDir(modelId), "v$versionNumber.weights")

    fun datasetDir(modelId: String): File = childDir(datasetsDir(), modelId)
    fun datasetLowQualityDir(modelId: String): File = childDir(datasetDir(modelId), "low")
    fun datasetHighQualityDir(modelId: String): File = childDir(datasetDir(modelId), "high")

    /**
     * A ".novamodel" bundle is a plain ZIP containing one version's weights
     * file + metadata.json - i.e. everything needed to restore that exact
     * version on another install. See
     * [com.novaenhance.ai.training.checkpoint.CheckpointManager].
     */
    fun backupFile(modelId: String, versionNumber: Int, timestamp: Long): File =
        File(backupsDir(), "${modelId}_v${versionNumber}_$timestamp.novamodel")

    /**
     * Where a version's export is written. [displayName] (the model's name) makes the file recognisable on the
     * phone it is sent to ("General-Photo-AI_v3.novamodel" rather than an internal id).
     */
    fun exportFile(modelId: String, versionNumber: Int, displayName: String? = null): File {
        val base = displayName?.let { safeFileName(it) }?.takeIf { it.isNotEmpty() } ?: modelId
        return File(modelExportsDir(), "${base}_v$versionNumber.novamodel")
    }

    private fun safeFileName(name: String): String =
        name.trim().replace(Regex("[^A-Za-z0-9._-]+"), "-").trim('-', '.').take(48)

    /** Directory usable by [androidx.core.content.FileProvider] for sharing/export. */
    fun modelExportsDir(): File = childDir(root, "model_exports")

    /**
     * Saves [bitmap] as a JPEG into the shared Pictures collection via
     * MediaStore (under `Pictures/NovaEnhance`), so it shows up in the
     * user's Gallery/Photos app like any normal photo, is shareable from
     * other apps, and survives this app being uninstalled.
     *
     * This used to write into an app-private directory instead, which is
     * app-private external storage - invisible to Gallery/Files apps and
     * deleted on uninstall. That's correct for models/datasets, which are
     * this app's own data, but wrong for a photo the user explicitly chose
     * to save: from their point of view, tapping "Save" produced a file
     * they had no way to find or use, which looked identical to Save not
     * working at all. `RELATIVE_PATH`/`IS_PENDING` require API 29+, which
     * this app's minSdk already is, so no version check is needed.
     *
     * Returns the resulting content [Uri] (directly shareable, no
     * FileProvider needed), or null if the write failed.
     */
    fun saveEnhancedPhotoToGallery(bitmap: Bitmap, displayName: String): Uri? {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, displayName)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/NovaEnhance")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }

        val collection = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        val uri = resolver.insert(collection, values) ?: run {
            NovaLog.w(TAG, "MediaStore insert returned null for $displayName")
            return null
        }

        return try {
            val wrote = resolver.openOutputStream(uri)?.use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 95, out)
            } ?: false
            if (!wrote) {
                resolver.delete(uri, null, null)
                return null
            }
            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            uri
        } catch (t: Throwable) {
            NovaLog.w(TAG, "Failed writing $displayName to gallery", t)
            resolver.delete(uri, null, null)
            null
        }
    }

    /**
     * Copies a `.novamodel` bundle into the shared Downloads collection (`Download/NovaEnhance`) so it shows up
     * in any file manager and can be moved to another phone by cable, SD card or any app. Like
     * [saveEnhancedPhotoToGallery] this needs no storage permission on API 29+. Returns the new file's content
     * [Uri], or null if the copy failed.
     */
    fun saveModelBundleToDownloads(bundle: File, displayName: String): Uri? {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, displayName)
            put(MediaStore.Downloads.MIME_TYPE, "application/octet-stream")
            put(MediaStore.Downloads.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/NovaEnhance")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }

        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: run {
            NovaLog.w(TAG, "MediaStore insert returned null for $displayName")
            return null
        }

        return try {
            val wrote = resolver.openOutputStream(uri)?.use { out ->
                bundle.inputStream().use { input -> input.copyTo(out) }
                true
            } ?: false
            if (!wrote) {
                resolver.delete(uri, null, null)
                return null
            }
            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            uri
        } catch (t: Throwable) {
            NovaLog.w(TAG, "Failed writing $displayName to Downloads", t)
            resolver.delete(uri, null, null)
            null
        }
    }

    private fun childDir(parent: File, name: String): File =
        File(parent, name).apply { if (!exists()) mkdirs() }
}
