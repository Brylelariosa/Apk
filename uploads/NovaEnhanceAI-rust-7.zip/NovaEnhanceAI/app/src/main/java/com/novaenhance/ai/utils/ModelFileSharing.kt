package com.novaenhance.ai.utils

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import java.io.File

/**
 * Opens the system share sheet for a `.novamodel` bundle (see
 * [com.novaenhance.ai.training.checkpoint.CheckpointManager]) so a trained model can be sent to another phone by
 * any app that takes files: Nearby Share, Bluetooth, Drive, WhatsApp, Telegram, e-mail ...
 *
 * [bundle] must live under one of the folders listed in `res/xml/file_paths.xml` (the app's `model_exports`
 * directory does). Returns false when the share sheet could not be opened, so the caller can say so instead of
 * leaving the person with a button that seems to do nothing.
 */
fun shareModelBundle(context: Context, bundle: File, chooserTitle: String = "Share trained model"): Boolean {
    return try {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", bundle)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "application/octet-stream"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, bundle.name)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(send, chooserTitle)
        if (context !is Activity) chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
        true
    } catch (e: ActivityNotFoundException) {
        NovaLog.w("ModelFileSharing", "No app can show the share sheet", e)
        false
    } catch (e: IllegalArgumentException) {
        // FileProvider has no configured root for this path.
        NovaLog.w("ModelFileSharing", "Cannot share ${bundle.path}: not under a FileProvider path", e)
        false
    }
}
