package com.novaenhance.ai.ui.components

import android.widget.Toast
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import com.novaenhance.ai.utils.LogExporter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * What every "Save logs to Downloads" button does: writes ALL the logs (debug info and crash log together) as one
 * text file into Download/NovaEnhance - see [LogExporter] - and then says where the file is.
 *
 * The file work runs on a background thread, so the button never freezes the screen, and a second tap while a save is
 * still running is ignored, so one tap is exactly one file.
 */
@Composable
fun rememberSaveLogsAction(): () -> Unit {
    val appContext = LocalContext.current.applicationContext
    val scope = rememberCoroutineScope()
    var saving by remember { mutableStateOf(false) }
    return {
        if (!saving) {
            saving = true
            scope.launch {
                try {
                    val result = withContext(Dispatchers.IO) { LogExporter.saveAllLogs(appContext) }
                    Toast.makeText(appContext, LogExporter.describe(result), Toast.LENGTH_LONG).show()
                } finally {
                    saving = false
                }
            }
        }
    }
}
