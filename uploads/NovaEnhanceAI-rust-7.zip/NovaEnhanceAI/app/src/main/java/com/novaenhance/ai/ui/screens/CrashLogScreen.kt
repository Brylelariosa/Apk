package com.novaenhance.ai.ui.screens

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.novaenhance.ai.R
import com.novaenhance.ai.ui.components.NovaButton
import com.novaenhance.ai.ui.components.NovaButtonStyle
import com.novaenhance.ai.ui.components.rememberSaveLogsAction
import com.novaenhance.ai.utils.CrashReporter

private const val MAX_SHOWN_CHARS = 60_000
private const val MAX_SHARED_CHARS = 150_000

/**
 * Shows [CrashReporter.buildCrashLog]: why the app last stopped, what it was doing at that moment, and the
 * recent activity of this run. Built so a crash can be diagnosed with no PC, adb or root - tap Save to Downloads
 * and send the file it makes (it holds this log AND the debug info, whole), or Share, or just take a screenshot
 * of the top of it. Text on screen can still be selected and copied by hand.
 */
@Composable
fun CrashLogScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val saveLogs = rememberSaveLogsAction()
    var refreshCount by remember { mutableStateOf(0) }
    val fullText = remember(refreshCount) { CrashReporter.buildCrashLog() }
    val shownText = if (fullText.length > MAX_SHOWN_CHARS) {
        fullText.take(MAX_SHOWN_CHARS) + "\n\n... (cut off on screen - Save to Downloads gives you the whole log)"
    } else {
        fullText
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Crash log") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(painterResource(R.drawable.ic_back_arrow), contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                NovaButton(
                    text = "Save to Downloads",
                    onClick = saveLogs,
                    modifier = Modifier.weight(1f)
                )
                NovaButton(
                    text = "Share",
                    style = NovaButtonStyle.Outlined,
                    onClick = {
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_SUBJECT, "NovaEnhance AI crash log")
                            putExtra(Intent.EXTRA_TEXT, fullText.take(MAX_SHARED_CHARS))
                        }
                        context.startActivity(
                            Intent.createChooser(send, "Share crash log").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    },
                    modifier = Modifier.weight(1f)
                )
                NovaButton(
                    text = "Clear",
                    style = NovaButtonStyle.Outlined,
                    onClick = {
                        CrashReporter.clearAll()
                        refreshCount += 1
                        Toast.makeText(context, "Crash log cleared", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.weight(1f)
                )
            }

            SelectionContainer(modifier = Modifier.weight(1f).fillMaxWidth()) {
                Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                    Text(
                        text = shownText,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )
                }
            }
        }
    }
}
