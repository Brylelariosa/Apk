package com.novaenhance.ai.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.novaenhance.ai.ai.engine.CheckpointCorruptedException
import com.novaenhance.ai.ai.engine.CheckpointSizeMismatchException
import com.novaenhance.ai.ai.engine.NovaModelEngine
import com.novaenhance.ai.ai.model.ModelRepository
import com.novaenhance.ai.ai.model.ParameterInspector
import com.novaenhance.ai.ai.model.ParameterSnapshot
import com.novaenhance.ai.database.dao.ModelVersionDao
import com.novaenhance.ai.storage.AppStorage
import com.novaenhance.ai.utils.NovaLog
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private const val TAG = "ParametersVM"

data class ParametersUiState(
    val isLoading: Boolean = true,
    val error: String? = null,
    val modelName: String = "",
    val versionNumber: Int = 0,
    val fileSizeBytes: Long = 0L,
    val snapshot: ParameterSnapshot? = null,
    /** True while a share/save is being prepared. */
    val isWorking: Boolean = false,
    /** A one-off line to show (and then clear): how a share/save went. */
    val message: String? = null
)

/**
 * Reads the saved parameters of the model currently in use and offers to share them as a file.
 *
 * It reads the version's weights FILE (the same bytes a share sends), not the live engine: while a training run is
 * going the live weights are changing under it, and what a person wants to look at - and send - is the saved model.
 */
class ParametersViewModel(
    private val modelVersionDao: ModelVersionDao,
    private val modelRepository: ModelRepository,
    private val storage: AppStorage
) : ViewModel() {

    private val _uiState = MutableStateFlow(ParametersUiState())
    val uiState: StateFlow<ParametersUiState> = _uiState.asStateFlow()

    init {
        refresh()
    }

    fun refresh() {
        viewModelScope.launch {
            _uiState.update { ParametersUiState(isLoading = true) }
            try {
                val model = modelRepository.getOrCreateActiveModel()
                val version = modelVersionDao.getActiveVersion(model.id) ?: error("This model has no saved version yet.")
                val weightsFile = File(version.weightsFilePath)
                val engine = NovaModelEngine.loadFromCheckpoint(weightsFile.path)
                val values = engine.snapshotParams()
                val adamStep = engine.currentAdamStep
                val snapshot = withContext(Dispatchers.Default) { ParameterInspector.inspect(values, adamStep) }
                _uiState.update {
                    ParametersUiState(
                        isLoading = false,
                        modelName = model.displayName,
                        versionNumber = version.versionNumber,
                        fileSizeBytes = weightsFile.length(),
                        snapshot = snapshot
                    )
                }
            } catch (e: CancellationException) {
                throw e
            } catch (t: Throwable) {
                NovaLog.w(TAG, "Could not read the active model's parameters", t)
                _uiState.update { ParametersUiState(isLoading = false, error = describeLoadFailure(t)) }
            }
        }
    }

    private fun describeLoadFailure(t: Throwable): String = when (t) {
        is CheckpointSizeMismatchException ->
            "This model was saved for a different version of the AI network, so its parameters can't be shown."
        is CheckpointCorruptedException ->
            "This model's file is damaged, so its parameters can't be shown."
        else -> "Couldn't read this model's parameters: ${t.message ?: t::class.java.simpleName}"
    }

    fun clearMessage() {
        _uiState.update { it.copy(message = null) }
    }

    /** Lets the screen report something that only it knows (e.g. no app could open the share sheet). */
    fun report(text: String) {
        _uiState.update { it.copy(message = text) }
    }

    /** Packages the model in use as a `.novamodel` file and hands it to [onReady] to open the share sheet. */
    fun share(onReady: (File) -> Unit) {
        runWork("Couldn't prepare the model file") {
            onReady(modelRepository.exportActiveVersion())
        }
    }

    /** Copies the model in use, as a `.novamodel` file, into the phone's Downloads folder. */
    fun saveToDownloads() {
        runWork("Couldn't save the file") {
            val file = modelRepository.exportActiveVersion()
            val saved = withContext(Dispatchers.IO) { storage.saveModelBundleToDownloads(file, file.name) }
            report(
                if (saved != null) "Saved to Downloads/NovaEnhance/${file.name}" else "Couldn't save the file to Downloads."
            )
        }
    }

    private fun runWork(failurePrefix: String, block: suspend () -> Unit) {
        if (_uiState.value.isWorking) return
        viewModelScope.launch {
            _uiState.update { it.copy(isWorking = true) }
            try {
                block()
            } catch (e: CancellationException) {
                throw e
            } catch (t: Throwable) {
                NovaLog.w(TAG, failurePrefix, t)
                report("$failurePrefix: ${t.message ?: t::class.java.simpleName}")
            } finally {
                _uiState.update { it.copy(isWorking = false) }
            }
        }
    }
}
