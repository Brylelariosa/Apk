package com.novaenhance.ai.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.novaenhance.ai.R
import com.novaenhance.ai.ui.components.ActionTile
import com.novaenhance.ai.ui.components.StatCard
import com.novaenhance.ai.ui.viewmodel.DashboardViewModel
import com.novaenhance.ai.ui.viewmodel.NovaViewModelFactory
import java.text.DateFormat
import java.util.Date

/**
 * The first screen. Everything you can DO is at the top - the two things people open the app for as big tiles, the
 * rest in a row under them - so no button is ever below the fold; the numbers about the model come after.
 */
@Composable
fun DashboardScreen(
    onNavigateToEnhance: () -> Unit,
    onNavigateToTraining: () -> Unit,
    onNavigateToDataset: () -> Unit,
    onNavigateToModelManager: () -> Unit,
    onNavigateToSettings: () -> Unit,
    onNavigateToParameters: () -> Unit
) {
    val context = LocalContext.current
    val viewModel: DashboardViewModel = viewModel(factory = NovaViewModelFactory(context))
    val state by viewModel.uiState.collectAsState()

    Scaffold(
        topBar = { TopAppBar(title = { Text("NovaEnhance AI") }) }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Column {
                    Text(
                        text = state.activeModel?.displayName ?: "Setting up your AI…",
                        style = MaterialTheme.typography.headlineMedium
                    )
                    state.activeModel?.let { model ->
                        Text(
                            text = "Version ${model.currentVersionNumber} · ${formatParams(model.parameterCount)} parameters",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    ActionTile(
                        label = "Enhance Image",
                        iconRes = R.drawable.ic_nav_enhance,
                        onClick = onNavigateToEnhance,
                        modifier = Modifier.weight(1f),
                        emphasized = true,
                        minHeight = 120.dp
                    )
                    ActionTile(
                        label = "Train AI",
                        iconRes = R.drawable.ic_nav_train,
                        onClick = onNavigateToTraining,
                        modifier = Modifier.weight(1f),
                        emphasized = true,
                        minHeight = 120.dp
                    )
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    ActionTile(
                        label = "Dataset",
                        iconRes = R.drawable.ic_nav_dataset,
                        onClick = onNavigateToDataset,
                        modifier = Modifier.weight(1f)
                    )
                    ActionTile(
                        label = "Models",
                        iconRes = R.drawable.ic_nav_model,
                        onClick = onNavigateToModelManager,
                        modifier = Modifier.weight(1f)
                    )
                    ActionTile(
                        label = "Settings",
                        iconRes = R.drawable.ic_nav_settings,
                        onClick = onNavigateToSettings,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            if (state.activeModel == null && !state.isLoading) {
                item {
                    Text(
                        "Your AI model is being set up. This only takes a moment the first time the app opens - " +
                            "if it doesn't appear, open Models to check.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            state.activeModel?.let { model ->
                item {
                    Card(
                        onClick = onNavigateToParameters,
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 72.dp)
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                painter = painterResource(R.drawable.ic_nav_params),
                                contentDescription = null,
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(modifier = Modifier.width(16.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text("View parameters", style = MaterialTheme.typography.titleMedium)
                                Text(
                                    "See the trained numbers and share them as a file",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Text(
                                text = formatParams(model.parameterCount),
                                style = MaterialTheme.typography.titleLarge.copy(fontFamily = FontFamily.Monospace),
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        StatCard(
                            label = "Model size",
                            value = formatBytes(model.sizeBytes),
                            modifier = Modifier.weight(1f)
                        )
                        StatCard(
                            label = "Model version",
                            value = "v${model.currentVersionNumber}",
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        StatCard(
                            label = "Training sessions",
                            value = model.trainingSessionCount.toString(),
                            modifier = Modifier.weight(1f)
                        )
                        StatCard(
                            label = "Images learned",
                            value = model.totalImagesLearned.toString(),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        StatCard(
                            label = "Improvement score",
                            value = "${model.improvementScore.toInt()}%",
                            modifier = Modifier.weight(1f),
                            accent = true
                        )
                        StatCard(
                            label = "Last training date",
                            value = model.lastTrainedAt?.let { DateFormat.getDateInstance().format(Date(it)) } ?: "Never",
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            if (state.recentSessions.isNotEmpty()) {
                item { Text("Recent training", style = MaterialTheme.typography.titleMedium) }
                items(state.recentSessions) { session ->
                    Text(
                        "${DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(session.startedAt))} - " +
                            "${session.status} ${if (session.wasPromoted) "(improved)" else ""}",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }
    }
}

private fun formatBytes(bytes: Long): String = when {
    bytes >= 1_000_000 -> "%.1f MB".format(bytes / 1_000_000.0)
    bytes >= 1_000 -> "%.1f KB".format(bytes / 1_000.0)
    else -> "$bytes B"
}

private fun formatParams(count: Long): String = when {
    count >= 1_000_000 -> "%.1fM".format(count / 1_000_000.0)
    count >= 1_000 -> "%.1fK".format(count / 1_000.0)
    else -> count.toString()
}
