package com.novaenhance.ai.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.novaenhance.ai.R
import com.novaenhance.ai.ai.model.ParameterLayout
import com.novaenhance.ai.ai.model.ParameterSnapshot
import com.novaenhance.ai.ai.model.SegmentStats
import com.novaenhance.ai.ui.components.NovaBottomBar
import com.novaenhance.ai.ui.components.NovaButton
import com.novaenhance.ai.ui.components.NovaButtonStyle
import com.novaenhance.ai.ui.viewmodel.NovaViewModelFactory
import com.novaenhance.ai.ui.viewmodel.ParametersUiState
import com.novaenhance.ai.ui.viewmodel.ParametersViewModel
import com.novaenhance.ai.utils.shareModelBundle
import java.util.Locale

/**
 * The model's parameters: what they add up to, how the numbers of each layer are spread, what the first layer's
 * filters look like, and every single value. Below it, the two ways to get the trained model onto another phone:
 * share the file, or save it to Downloads.
 */
@Composable
fun ParametersScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val viewModel: ParametersViewModel = viewModel(factory = NovaViewModelFactory(context))
    val state by viewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    var tab by remember { mutableIntStateOf(0) }

    LaunchedEffect(state.message) {
        val text = state.message
        if (text != null) {
            snackbarHostState.showSnackbar(text)
            viewModel.clearMessage()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Parameters") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(painterResource(R.drawable.ic_back_arrow), contentDescription = "Back")
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            if (state.snapshot != null) {
                NovaBottomBar {
                    Text(
                        "To use this trained model on another phone: send the file, then tap Import model file in Models there.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        NovaButton(
                            text = "Share file",
                            iconRes = R.drawable.ic_share,
                            enabled = !state.isWorking,
                            onClick = {
                                viewModel.share { file ->
                                    if (!shareModelBundle(context, file)) {
                                        viewModel.report("No app could open the share sheet.")
                                    }
                                }
                            },
                            modifier = Modifier.weight(1f)
                        )
                        NovaButton(
                            text = "Save to Downloads",
                            style = NovaButtonStyle.Outlined,
                            iconRes = R.drawable.ic_download,
                            enabled = !state.isWorking,
                            onClick = { viewModel.saveToDownloads() },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    ) { padding ->
        val snapshot = state.snapshot
        val error = state.error
        Box(modifier = Modifier.fillMaxSize().padding(padding)) {
            when {
                state.isLoading -> CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
                error != null -> Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(error, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
                    NovaButton(text = "Try again", onClick = { viewModel.refresh() }, modifier = Modifier.fillMaxWidth())
                }
                snapshot != null -> Column(modifier = Modifier.fillMaxSize()) {
                    TabRow(selectedTabIndex = tab) {
                        Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Summary") })
                        Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("All values") })
                    }
                    if (tab == 0) {
                        SummaryTab(state = state, snapshot = snapshot)
                    } else {
                        ValuesTab(snapshot = snapshot)
                    }
                }
            }
        }
    }
}

@Composable
private fun SummaryTab(state: ParametersUiState, snapshot: ParameterSnapshot) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { OverviewCard(state = state, snapshot = snapshot) }
        items(ParameterLayout.LAYER_COUNT) { index -> LayerCard(layer = index + 1, snapshot = snapshot) }
        item { FilterGalleryCard(snapshot = snapshot) }
    }
}

@Composable
private fun OverviewCard(state: ParametersUiState, snapshot: ParameterSnapshot) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(state.modelName, style = MaterialTheme.typography.titleLarge)
            Text(
                "Version ${state.versionNumber}",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            FactRow("Parameters", formatCount(snapshot.parameterCount))
            FactRow("Model file", formatBytes(state.fileSizeBytes))
            FactRow("Training steps", formatCount(snapshot.adamStep))
            FactRow("Fingerprint", snapshot.fingerprint)
            Text(
                "The fingerprint identifies these exact numbers. After you send the model to another phone, " +
                    "both phones show the same one.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun FactRow(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.titleMedium.copy(fontFamily = FontFamily.Monospace))
    }
}

@Composable
private fun LayerCard(layer: Int, snapshot: ParameterSnapshot) {
    val weights = ParameterLayout.weights(layer)
    val biases = ParameterLayout.biases(layer)
    val weightStats = snapshot.statsFor(weights)
    val biasStats = snapshot.statsFor(biases)
    val layerSize = weights.size + biases.size
    val share = layerSize * 100f / snapshot.parameterCount

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Layer $layer", style = MaterialTheme.typography.titleMedium)
            Text(
                "${weights.inChannels} to ${weights.outChannels} channels, 3×3 filters · " +
                    "${formatCount(layerSize)} parameters (${String.format(Locale.US, "%.1f", share)}%)",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Histogram(
                bins = weightStats.histogram,
                barColor = MaterialTheme.colorScheme.primary,
                axisColor = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.fillMaxWidth().height(64.dp)
            )
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                val edge = String.format(Locale.US, "%.3f", weightStats.maxAbs)
                Text("-$edge", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("0", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("+$edge", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            StatsBlock(title = "Weights", stats = weightStats)
            StatsBlock(title = "Biases", stats = biasStats)
        }
    }
}

@Composable
private fun StatsBlock(title: String, stats: SegmentStats) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text("$title · ${formatCount(stats.segment.size)} values", style = MaterialTheme.typography.labelLarge)
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Stat("lowest", signed(stats.min))
            Stat("highest", signed(stats.max))
            Stat("average", signed(stats.mean))
            Stat("spread", String.format(Locale.US, "%.3f", stats.std))
        }
    }
}

@Composable
private fun Stat(label: String, value: String) {
    Column {
        Text(value, style = MaterialTheme.typography.labelSmall.copy(fontSize = 12.sp))
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

/** How the values of one layer are spread between their most negative and most positive; the middle line is zero. */
@Composable
private fun Histogram(bins: IntArray, barColor: Color, axisColor: Color, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val peak = (bins.maxOrNull() ?: 0).coerceAtLeast(1)
        val slot = size.width / bins.size
        for (i in bins.indices) {
            val barHeight = size.height * (bins[i].toFloat() / peak)
            drawRect(
                color = barColor,
                topLeft = Offset(i * slot + 1f, size.height - barHeight),
                size = Size(slot - 2f, barHeight)
            )
        }
        drawLine(
            color = axisColor.copy(alpha = 0.6f),
            start = Offset(size.width / 2f, 0f),
            end = Offset(size.width / 2f, size.height),
            strokeWidth = 1f
        )
    }
}

@Composable
private fun FilterGalleryCard(snapshot: ParameterSnapshot) {
    val scale = snapshot.statsFor(ParameterLayout.weights(1)).maxAbs
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("What the first layer looks for", style = MaterialTheme.typography.titleMedium)
            Text(
                "Each tile is one of the 48 small filters of layer 1. Its nine squares show how strongly it reacts " +
                    "to red, green and blue at that spot. They start out random and become organised as the AI trains.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            FilterGallery(
                values = snapshot.values,
                scale = if (scale > 0f) scale else 1f,
                modifier = Modifier.fillMaxWidth().aspectRatio(8f / 6f)
            )
        }
    }
}

/** The 48 filters of layer 1 as 3x3 colour tiles: red/green/blue = the filter's weight on that input channel. */
@Composable
private fun FilterGallery(values: FloatArray, scale: Float, modifier: Modifier = Modifier) {
    val layer = ParameterLayout.weights(1)
    Canvas(modifier = modifier) {
        val columns = 8
        val rows = 6
        val gap = 4.dp.toPx()
        val tileWidth = (size.width - gap * (columns - 1)) / columns
        val tileHeight = (size.height - gap * (rows - 1)) / rows
        val cellWidth = tileWidth / 3f
        val cellHeight = tileHeight / 3f
        for (out in 0 until layer.outChannels) {
            val left = (out % columns) * (tileWidth + gap)
            val top = (out / columns) * (tileHeight + gap)
            for (tap in 0 until ParameterLayout.KERNEL_TAPS) {
                val red = values[layer.offset + (tap * layer.inChannels + 0) * layer.outChannels + out]
                val green = values[layer.offset + (tap * layer.inChannels + 1) * layer.outChannels + out]
                val blue = values[layer.offset + (tap * layer.inChannels + 2) * layer.outChannels + out]
                drawRect(
                    color = Color(
                        red = unitChannel(red, scale),
                        green = unitChannel(green, scale),
                        blue = unitChannel(blue, scale)
                    ),
                    topLeft = Offset(left + (tap % 3) * cellWidth, top + (tap / 3) * cellHeight),
                    size = Size(cellWidth, cellHeight)
                )
            }
        }
    }
}

/** Maps a weight in -scale..+scale to 0..1 around mid-grey, so zero is grey and strong weights are vivid. */
private fun unitChannel(value: Float, scale: Float): Float = (0.5f + 0.5f * (value / scale)).coerceIn(0f, 1f)

@Composable
private fun ValuesTab(snapshot: ParameterSnapshot) {
    var layer by remember { mutableIntStateOf(0) } // 0 = every layer
    val range = if (layer == 0) 0 until snapshot.parameterCount else ParameterLayout.layerRange(layer)
    val count = range.last - range.first + 1
    val values = snapshot.values

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(selected = layer == 0, onClick = { layer = 0 }, label = { Text("All") })
            for (l in 1..ParameterLayout.LAYER_COUNT) {
                FilterChip(selected = layer == l, onClick = { layer = l }, label = { Text("Layer $l") })
            }
        }
        Text(
            "${formatCount(count)} values. Positive in teal, negative in amber.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp)
        )
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
        ) {
            items(count) { i ->
                val index = range.first + i
                ValueRow(index = index, value = values[index])
            }
        }
    }
}

@Composable
private fun ValueRow(index: Int, value: Float) {
    Row(
        modifier = Modifier.fillMaxWidth().heightIn(min = 28.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            "#$index  ${ParameterLayout.describe(index)}",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(1f)
        )
        Text(
            String.format(Locale.US, "%+.6f", value),
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 13.sp),
            color = if (value >= 0f) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary
        )
    }
}

private fun formatCount(n: Int): String = String.format(Locale.US, "%,d", n)

private fun signed(v: Float): String = String.format(Locale.US, "%+.3f", v)

private fun formatBytes(bytes: Long): String = when {
    bytes >= 1_000_000 -> "%.1f MB".format(bytes / 1_000_000.0)
    bytes >= 1_000 -> "%.1f KB".format(bytes / 1_000.0)
    else -> "$bytes B"
}
