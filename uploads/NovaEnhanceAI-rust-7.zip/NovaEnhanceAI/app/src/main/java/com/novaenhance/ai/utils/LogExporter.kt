package com.novaenhance.ai.utils

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

private const val TAG = "LogExporter"

/**
 * Puts EVERY log the app keeps into ONE text file in the phone's Download folder, so a problem report is "attach this
 * file" - no copying, no switching apps, no pasting, and nothing cut off by the clipboard.
 *
 * The file has four parts, in this order:
 *  1. DEBUG INFO - app version, device, which native kernels run, RAM, heat, and the recent activity ([DiagnosticsReport]);
 *  2. CRASH LOG - why the app last stopped, what it was doing, how Android says recent runs ended ([CrashReporter]);
 *  3. the FULL on-disk log of the previous run ([PersistentLog]) - the crash log only quotes its last lines;
 *  4. the FULL on-disk log of this run.
 *
 * It lands in `Download/NovaEnhance`, the same folder exported models go to ([com.novaenhance.ai.storage.AppStorage]),
 * through MediaStore: no storage permission is needed on Android 10+ (this app's minSdk is 29) and the file shows up in
 * any file manager. Each save is a new file named with the time, so nothing is overwritten and the newest is obvious.
 *
 * [fileName], [compose] and [describe] are pure so they can be unit-tested without a phone.
 */
object LogExporter {

    /** Sub-folder of Download that the logs (and exported models) go to. */
    const val FOLDER = "NovaEnhance"

    private const val RULE = "=============================================================================="

    sealed class Result {
        /** Written to `Download/NovaEnhance/[fileName]`. */
        data class Saved(val fileName: String) : Result()

        /** Nothing was kept - a half-written file is removed again. */
        data class Failed(val reason: String) : Result()
    }

    /** "NovaEnhance-logs-20261126-134012.txt": the local time, so files sort by when they were saved. */
    fun fileName(timeMillis: Long, zone: TimeZone = TimeZone.getDefault()): String {
        val format = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US)
        format.timeZone = zone
        return "NovaEnhance-logs-${format.format(Date(timeMillis))}.txt"
    }

    /** The text of the whole file. A part with nothing in it still gets its heading, saying so. */
    fun compose(
        savedAt: String,
        debugInfo: String,
        crashLog: String,
        previousRunLog: String,
        thisRunLog: String
    ): String = buildString {
        appendLine("NovaEnhance AI - all logs in one file")
        appendLine("Saved: $savedAt")
        appendLine("Parts: 1 debug info | 2 crash log | 3 full log of the previous run | 4 full log of this run")
        appendLine()
        part(1, "DEBUG INFO - device, memory, heat, recent activity", debugInfo)
        part(2, "CRASH LOG - why the app last stopped", crashLog)
        part(3, "FULL LOG OF THE PREVIOUS RUN (the run before this launch)", previousRunLog)
        part(4, "FULL LOG OF THIS RUN (since this launch)", thisRunLog)
    }

    private fun StringBuilder.part(number: Int, title: String, body: String) {
        appendLine(RULE)
        appendLine("PART $number: $title")
        appendLine(RULE)
        val text = body.trimEnd()
        appendLine(if (text.isEmpty()) "(nothing recorded)" else text)
        appendLine()
    }

    /** What to tell the user once [result] is known. */
    fun describe(result: Result): String = when (result) {
        is Result.Saved -> "Logs saved to Downloads/$FOLDER/${result.fileName}"
        is Result.Failed -> "Could not save the logs: ${result.reason}"
    }

    /**
     * Gathers every log and writes the file. Reads and writes files, so call it off the main thread. Never throws: a
     * problem comes back as [Result.Failed]. If the device snapshot cannot be read the other parts are still saved -
     * the crash log is the one thing that must not be lost to a failure in the nice-to-have part.
     */
    fun saveAllLogs(context: Context, nowMillis: Long = System.currentTimeMillis()): Result {
        val appContext = context.applicationContext
        val name = fileName(nowMillis)
        val text = try {
            val debugInfo = try {
                DiagnosticsReport.build(DeviceCapabilities(appContext).snapshot(), lastCrash = null)
            } catch (t: Throwable) {
                "(device info could not be read: ${t.javaClass.simpleName})"
            }
            compose(
                savedAt = logStamp(nowMillis),
                debugInfo = debugInfo,
                crashLog = CrashReporter.buildCrashLog(),
                previousRunLog = PersistentLog.previousSessionText(),
                thisRunLog = PersistentLog.currentSessionText()
            )
        } catch (t: Throwable) {
            NovaLog.w(TAG, "Could not put the logs together", t)
            return Result.Failed("the logs could not be put together (${t.javaClass.simpleName})")
        }

        val result = writeToDownloads(appContext, name, text)
        when (result) {
            is Result.Saved -> NovaLog.i(TAG, "Saved ${text.length / 1024} KB of logs to Download/$FOLDER/$name")
            is Result.Failed -> NovaLog.w(TAG, "Saving the logs failed: ${result.reason}")
        }
        return result
    }

    /** Same MediaStore route as `AppStorage.saveModelBundleToDownloads`, for text. */
    private fun writeToDownloads(context: Context, displayName: String, text: String): Result {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, displayName)
            put(MediaStore.Downloads.MIME_TYPE, "text/plain")
            put(MediaStore.Downloads.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/$FOLDER")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }

        val uri: Uri? = try {
            resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
        } catch (t: Throwable) {
            NovaLog.w(TAG, "MediaStore insert failed for $displayName", t)
            null
        }
        if (uri == null) return Result.Failed("Android would not create the file in Downloads")

        return try {
            val out = resolver.openOutputStream(uri) ?: throw IOException("could not open the new file for writing")
            out.use { it.write(text.toByteArray(Charsets.UTF_8)) }
            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            Result.Saved(displayName)
        } catch (t: Throwable) {
            try {
                resolver.delete(uri, null, null)
            } catch (ignored: Throwable) {
                // the half-written file stays hidden (still pending); nothing more can be done
            }
            Result.Failed(t.message ?: t.javaClass.simpleName)
        }
    }
}
