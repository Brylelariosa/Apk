package com.novaenhance.ai.ui.screens

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.novaenhance.ai.R
import com.novaenhance.ai.database.entities.ModelEntity
import com.novaenhance.ai.database.entities.ModelVersionEntity
import com.novaenhance.ai.ui.components.NovaBottomBar
import com.novaenhance.ai.ui.components.NovaButton
import com.novaenhance.ai.ui.components.NovaButtonStyle
import com.novaenhance.ai.ui.viewmodel.ModelManagerViewModel
import com.novaenhance.ai.ui.viewmodel.NovaViewModelFactory
import com.novaenhance.ai.utils.shareModelBundle
import java.io.File
import java.text.DateFormat
import java.util.Date

/**
 * Every model on this phone, and the way to move one between phones: Share sends a trained model as a
 * `.novamodel` file, Import model file (always visible at the bottom) takes one in and makes it the active model.
 */
@Composable
fun ModelManagerScreen(onBack: () -> Unit, onOpenParameters: () -> Unit) {
    val context = LocalContext.current
    val viewModel: ModelManagerViewModel = viewModel(factory = NovaViewModelFactory(context))
    val state by viewModel.uiState.collectAsState()
    val message by viewModel.message.collectAsState()
    val busy by viewModel.isBusy.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    var pendingDeleteModel by remember { mutableStateOf<ModelEntity?>(null) }
    var pendingDeleteVersion by remember { mutableStateOf<ModelVersionEntity?>(null) }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { viewModel.importModel(it) }
    }

    LaunchedEffect(message) {
        val text = message
        if (text != null) {
            snackbarHostState.showSnackbar(text)
            viewModel.clearMessage()
        }
    }

    // Hands a freshly packaged model file to the system share sheet.
    val openShareSheet: (File) -> Unit = { file ->
        if (!shareModelBundle(context, file)) {
            Toast.makeText(context, "No app could open the share sheet.", Toast.LENGTH_LONG).show()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Models") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(painterResource(R.drawable.ic_back_arrow), contentDescription = "Back")
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            NovaBottomBar {
                NovaButton(
                    text = "Import model file",
                    iconRes = R.drawable.ic_upload,
                    enabled = !busy,
                    onClick = { importLauncher.launch("*/*") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text(
                    "To use a trained model on another phone: tap Share on it, send the file, then tap " +
                        "Import model file on the other phone.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            items(state.models, key = { it.id }) { model ->
                val selected = model.id == state.selectedModelId
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = if (selected) {
                            MaterialTheme.colorScheme.primaryContainer
                        } else {
                            MaterialTheme.colorScheme.surfaceVariant
                        }
                    ),
                    onClick = { viewModel.selectModel(model.id) }
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(
                                model.displayName,
                                style = MaterialTheme.typography.titleMedium,
                                modifier = Modifier.weight(1f)
                            )
                            if (model.isActive) {
                                Text(
                                    "In use",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onPrimary,
                                    modifier = Modifier
                                        .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(50))
                                        .padding(horizontal = 10.dp, vertical = 3.dp)
                                )
                            }
                        }
                        Text(
                            "v${model.currentVersionNumber} · ${model.trainingSessionCount} sessions · " +
                                "${model.totalImagesLearned} images learned",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            if (model.isActive) {
                                NovaButton(
                                    text = "Parameters",
                                    style = NovaButtonStyle.Tonal,
                                    iconRes = R.drawable.ic_nav_params,
                                    onClick = onOpenParameters,
                                    modifier = Modifier.weight(1f)
                                )
                            } else {
                                NovaButton(
                                    text = "Use this model",
                                    style = NovaButtonStyle.Tonal,
                                    enabled = !busy,
                                    onClick = { viewModel.switchActive(model.id) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            NovaButton(
                                text = "Share",
                                iconRes = R.drawable.ic_share,
                                enabled = !busy,
                                onClick = { viewModel.shareModel(model.id, openShareSheet) },
                                modifier = Modifier.weight(1f)
                            )
                        }

                        if (selected) {
                            Text(
                                "Versions",
                                style = MaterialTheme.typography.labelLarge,
                                modifier = Modifier.padding(top = 8.dp)
                            )
                            state.versionsForSelected.forEach { version ->
                                Column(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                                    Text(
                                        "v${version.versionNumber}${if (version.isActive) " (in use)" else ""} · " +
                                            DateFormat.getDateInstance().format(Date(version.createdAt)),
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        VersionButton("Share", enabled = !busy) {
                                            viewModel.shareVersion(version.id, openShareSheet)
                                        }
                                        VersionButton("Save", enabled = !busy) {
                                            viewModel.saveVersionToDownloads(version.id)
                                        }
                                        if (!version.isActive) {
                                            VersionButton("Restore", enabled = !busy) {
                                                viewModel.restoreVersion(model.id, version.id)
                                            }
                                            VersionButton("Delete", enabled = !busy) {
                                                pendingDeleteVersion = version
                                            }
                                        }
                                    }
                                }
                            }
                            TextButton(
                                onClick = { pendingDeleteModel = model },
                                modifier = Modifier.heightIn(min = 48.dp)
                            ) {
                                Text("Delete this model", color = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
            }
        }
    }

    pendingDeleteModel?.let { model ->
        AlertDialog(
            onDismissRequest = { pendingDeleteModel = null },
            title = { Text("Delete “${model.displayName}”?") },
            text = {
                Text(
                    "Its trained weights, its versions and its training pairs are removed from this phone. " +
                        "Share it first if you want to keep a copy."
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteModel(model.id)
                        pendingDeleteModel = null
                    }
                ) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { pendingDeleteModel = null }) { Text("Keep") } }
        )
    }

    pendingDeleteVersion?.let { version ->
        AlertDialog(
            onDismissRequest = { pendingDeleteVersion = null },
            title = { Text("Delete version ${version.versionNumber}?") },
            text = { Text("This version's weights are removed from this phone.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteVersion(version.id)
                        pendingDeleteVersion = null
                    }
                ) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { pendingDeleteVersion = null }) { Text("Keep") } }
        )
    }
}

/** One of the equally wide, 48dp-tall buttons under a version, so up to four fit side by side on a narrow phone. */
@Composable
private fun RowScope.VersionButton(text: String, enabled: Boolean, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        contentPadding = PaddingValues(horizontal = 4.dp),
        modifier = Modifier.weight(1f).heightIn(min = 48.dp)
    ) {
        Text(text, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}
