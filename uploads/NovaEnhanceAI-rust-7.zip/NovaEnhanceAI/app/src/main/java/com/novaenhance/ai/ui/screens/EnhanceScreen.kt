package com.novaenhance.ai.ui.screens

import android.content.Intent
import android.graphics.Bitmap
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import com.novaenhance.ai.R
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.IconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.novaenhance.ai.ui.components.BatchThumbnailStrip
import com.novaenhance.ai.ui.components.BeforeAfterSlider
import com.novaenhance.ai.ui.components.EnhancementControls
import com.novaenhance.ai.ui.components.NovaBottomBar
import com.novaenhance.ai.ui.components.NovaButton
import com.novaenhance.ai.ui.components.NovaButtonMinHeight
import com.novaenhance.ai.ui.components.NovaButtonStyle
import com.novaenhance.ai.ui.viewmodel.BatchItemStatus
import com.novaenhance.ai.ui.viewmodel.BatchUiState
import com.novaenhance.ai.ui.viewmodel.EnhanceUiState
import com.novaenhance.ai.ui.viewmodel.EnhanceViewModel
import com.novaenhance.ai.ui.viewmodel.NovaViewModelFactory
import java.io.File

@Composable
fun EnhanceScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val viewModel: EnhanceViewModel = viewModel(factory = NovaViewModelFactory(context))
    val state by viewModel.uiState.collectAsState()
    val batch by viewModel.batchState.collectAsState()

    LaunchedEffect(state.savedUri) {
        if (state.savedUri != null) {
            Toast.makeText(context, "Saved to your Gallery", Toast.LENGTH_SHORT).show()
        }
    }

    // Multi-select: the system photo picker lets the user tick several photos at once (Android falls back to the
    // document picker, which also allows multiple selection, where the photo picker isn't available). One photo
    // behaves exactly as before; several enable the thumbnail strip and "Enhance & save all" below.
    val pickImagesLauncher = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia()) { uris ->
        if (uris.isNotEmpty()) viewModel.onImagesSelected(uris)
    }
    val launchImagePicker = {
        pickImagesLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }

    var pendingCaptureFile by remember { mutableStateOf<File?>(null) }
    val captureLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        if (success) {
            pendingCaptureFile?.let { file ->
                val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                viewModel.onImageSelected(uri)
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Enhance Image") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(painterResource(R.drawable.ic_back_arrow), contentDescription = "Back")
                    }
                }
            )
        },
        // Save / Share / Enhance-all used to sit under the last slider, so you had to scroll past every control to
        // reach them. They live in a bar that stays on screen instead.
        bottomBar = {
            if (state.originalBitmap != null) {
                NovaBottomBar {
                    if (batch.isBatch && batch.isRunning) {
                        val working = batch.items.indexOfFirst { it.status == BatchItemStatus.WORKING }
                        val position = if (working >= 0) {
                            working + 1
                        } else {
                            (batch.doneCount + batch.failedCount + 1).coerceAtMost(batch.items.size)
                        }
                        Text(
                            "Enhancing photo $position of ${batch.items.size}…",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        LinearProgressIndicator(progress = { batch.overallFraction }, modifier = Modifier.fillMaxWidth())
                        NovaButton(
                            text = "Cancel",
                            style = NovaButtonStyle.Outlined,
                            onClick = viewModel::cancelBatch,
                            modifier = Modifier.fillMaxWidth()
                        )
                    } else {
                        if (batch.isBatch) {
                            batch.summary?.let { Text(it, style = MaterialTheme.typography.bodyMedium) }
                            NovaButton(
                                text = "Enhance & save all ${batch.items.size} photos",
                                onClick = viewModel::enhanceAndSaveAll,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Button(
                                onClick = { viewModel.saveResult() },
                                modifier = Modifier.weight(1f).heightIn(min = NovaButtonMinHeight),
                                enabled = !state.isSaving
                            ) {
                                if (state.isSaving) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(18.dp),
                                        strokeWidth = 2.dp,
                                        color = MaterialTheme.colorScheme.onPrimary
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Saving…")
                                } else {
                                    Icon(
                                        painter = painterResource(R.drawable.ic_download),
                                        contentDescription = null,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(if (state.savedUri != null) "Saved" else "Save")
                                }
                            }
                            NovaButton(
                                text = "Share",
                                style = NovaButtonStyle.Outlined,
                                iconRes = R.drawable.ic_share,
                                enabled = state.savedUri != null,
                                onClick = {
                                    state.savedUri?.let { uri ->
                                        val intent = Intent(Intent.ACTION_SEND).apply {
                                            type = "image/jpeg"
                                            putExtra(Intent.EXTRA_STREAM, uri)
                                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        }
                                        context.startActivity(Intent.createChooser(intent, "Share enhanced image"))
                                    }
                                },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }
    ) { padding ->
        val original = state.originalBitmap
        if (original == null) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                NovaButton(
                    text = "Select Images",
                    iconRes = R.drawable.ic_nav_dataset,
                    onClick = { launchImagePicker() },
                    modifier = Modifier.fillMaxWidth()
                )
                NovaButton(
                    text = "Capture Image",
                    style = NovaButtonStyle.Outlined,
                    onClick = {
                        val file = File(context.cacheDir, "capture_${System.currentTimeMillis()}.jpg")
                        pendingCaptureFile = file
                        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                        captureLauncher.launch(uri)
                    },
                    modifier = Modifier.fillMaxWidth()
                )
                state.errorMessage?.let {
                    Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
                }
            }
        } else {
            // The preview is PINNED: it never scrolls, and the controls sit under it in a panel of their own, so the
            // picture is on screen while a slider moves. (It used to be the first item of one long scrolling list.)
            val notes = buildList {
                if (batch.isBatch) {
                    add(
                        "Enhance & save all uses the settings on this page for every photo and saves each " +
                            "result to your Gallery."
                    )
                }
                if (state.activeModelTrainingSessionCount == 0 && state.enhancedBitmap != null) {
                    add(
                        "This model hasn't been trained yet, so the AI pass is an intentional near-no-op - " +
                            "what you see is mostly the classical controls. Train it in Train AI to see " +
                            "learned enhancement."
                    )
                }
            }
            val configuration = LocalConfiguration.current
            val sideBySide = configuration.screenWidthDp > configuration.screenHeightDp
            if (sideBySide) {
                // Landscape: the preview takes the left, the controls a fixed column on the right.
                Row(modifier = Modifier.fillMaxSize().padding(padding)) {
                    EnhancePreview(
                        state = state,
                        batch = batch,
                        onBitmapDisplayChanged = viewModel::onBitmapDisplayChanged,
                        onSelectBatchItem = viewModel::selectBatchItem,
                        onChoosePhotos = { launchImagePicker() },
                        modifier = Modifier.weight(1f).fillMaxHeight()
                    )
                    EnhancementControls(
                        options = state.options,
                        enabled = !batch.isRunning,
                        onOptionsChange = viewModel::onOptionsChanged,
                        notes = notes,
                        fillHeight = true,
                        modifier = Modifier.width(360.dp).fillMaxHeight()
                    )
                }
            } else {
                // Portrait: the preview takes whatever the controls leave. The controls panel grows to about a
                // third of the screen (enough for six one-line sliders) and scrolls inside itself beyond that.
                val panelMax = (configuration.screenHeightDp * 0.36f).dp
                Column(modifier = Modifier.fillMaxSize().padding(padding)) {
                    EnhancePreview(
                        state = state,
                        batch = batch,
                        onBitmapDisplayChanged = viewModel::onBitmapDisplayChanged,
                        onSelectBatchItem = viewModel::selectBatchItem,
                        onChoosePhotos = { launchImagePicker() },
                        modifier = Modifier.weight(1f).fillMaxWidth()
                    )
                    EnhancementControls(
                        options = state.options,
                        enabled = !batch.isRunning,
                        onOptionsChange = viewModel::onOptionsChanged,
                        notes = notes,
                        maxPanelHeight = panelMax,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}

/**
 * The pinned top part of the Enhance screen: the before/after preview (taking all the height it is given), a one-line
 * hint with the "Change photo" button, the thumbnail strip when several photos were picked, and any error message.
 */
@Composable
private fun EnhancePreview(
    state: EnhanceUiState,
    batch: BatchUiState,
    onBitmapDisplayChanged: (Bitmap, Boolean) -> Unit,
    onSelectBatchItem: (Int) -> Unit,
    onChoosePhotos: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier) {
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 4.dp)
                .clip(RoundedCornerShape(12.dp))
        ) {
            val original = state.originalBitmap
            val enhanced = state.enhancedBitmap
            if (original != null && enhanced != null) {
                BeforeAfterSlider(
                    original = original,
                    enhanced = enhanced,
                    modifier = Modifier.fillMaxSize(),
                    onOriginalDisplayChanged = onBitmapDisplayChanged,
                    onEnhancedDisplayChanged = onBitmapDisplayChanged
                )
            }
            if (state.isProcessing) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(progress = { state.progressFraction })
                }
            }
        }

        val hint = when {
            batch.isBatch -> "Photo ${batch.activeIndex + 1} of ${batch.items.size} - tap a photo to preview it"
            state.enhancedBitmap != null -> "Pinch or double-tap to zoom, drag the divider to compare"
            else -> ""
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                hint,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.weight(1f)
            )
            TextButton(onClick = onChoosePhotos, enabled = !batch.isRunning) {
                Text(if (batch.isBatch) "Change photos" else "Change photo")
            }
        }

        if (batch.isBatch) {
            BatchThumbnailStrip(
                items = batch.items,
                activeIndex = batch.activeIndex,
                enabled = !batch.isRunning,
                onSelect = onSelectBatchItem,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
            )
        }

        state.errorMessage?.let {
            Text(
                it,
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
            )
        }
    }
}
