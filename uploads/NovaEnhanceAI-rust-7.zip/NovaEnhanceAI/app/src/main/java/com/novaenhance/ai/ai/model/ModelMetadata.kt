package com.novaenhance.ai.ai.model

import com.novaenhance.ai.ai.engine.NativeNeuralEngine
import org.json.JSONObject
import java.io.File

/**
 * Descriptive metadata carried alongside a `.novamodel` bundle (see
 * [com.novaenhance.ai.training.checkpoint.CheckpointManager]) so an
 * exported/imported model is self-describing independent of this
 * install's database. The network architecture is fixed at compile time
 * (`rust/src/nn/mod.rs`), so the essentials are display info and the version
 * this bundle represents.
 *
 * The training statistics ([trainingSessionCount] and friends) travel with the
 * model so that a model received from another phone still says how trained it
 * is - without them the Enhance screen would call a fully trained, imported
 * model "not trained yet". Every one of them is optional when reading, so
 * bundles written before they existed still import.
 */
data class ModelMetadata(
    val modelName: String,
    val parameterCount: Int,
    val versionNumber: Int,
    val trainingSessionCount: Int = 0,
    val totalImagesLearned: Int = 0,
    val improvementScore: Float = 0f,
    val lastTrainedAt: Long? = null
) {
    companion object {
        fun fromFile(jsonFile: File): ModelMetadata = fromJson(jsonFile.readText())

        /** Lenient on purpose: a hand-made or older bundle with missing fields still imports. */
        fun fromJson(text: String): ModelMetadata {
            val json = JSONObject(text)
            return ModelMetadata(
                modelName = json.optString("modelName", "Imported model"),
                parameterCount = json.optInt("parameterCount", NativeNeuralEngine.TOTAL_PARAMS),
                versionNumber = json.optInt("versionNumber", 1),
                trainingSessionCount = json.optInt("trainingSessionCount", 0),
                totalImagesLearned = json.optInt("totalImagesLearned", 0),
                improvementScore = json.optDouble("improvementScore", 0.0).toFloat(),
                lastTrainedAt = if (json.has("lastTrainedAt") && !json.isNull("lastTrainedAt")) json.getLong("lastTrainedAt") else null
            )
        }

        /** Sidecar path convention: `foo.weights` <-> `foo.json`. */
        fun sidecarFor(weightsFile: File): File =
            File(weightsFile.parentFile, weightsFile.nameWithoutExtension + ".json")
    }

    fun toJson(): String {
        val json = JSONObject()
        json.put("modelName", modelName)
        json.put("parameterCount", parameterCount)
        json.put("versionNumber", versionNumber)
        json.put("trainingSessionCount", trainingSessionCount)
        json.put("totalImagesLearned", totalImagesLearned)
        json.put("improvementScore", improvementScore.toDouble())
        lastTrainedAt?.let { json.put("lastTrainedAt", it) }
        return json.toString(2)
    }
}
