package com.novaenhance.ai.utils

import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

/**
 * How many native worker threads each kind of job asks for BEFORE [ThermalGovernor] narrows it
 * further for heat / memory pressure (callers pass the result as the governor's
 * `concurrencyCeiling` and run with the `maxConcurrency` it hands back).
 *
 * Kept as a pure function of the core count so the policy is unit-testable and lives in one place.
 *
 * Tuned for the phones this app mostly runs on. Take the Infinix HOT 11 2022 (Unisoc T610: 2x
 * Cortex-A75 + 6x Cortex-A55, all clocked at 1.8 GHz, 4 GB RAM, 5000 mAh):
 *
 *  - Interactive enhancement uses every core. The user is staring at a progress bar and the native
 *    scheduler hands work out one job at a time, so the two fast A75 cores simply take more jobs
 *    than the six A55 cores and nothing idles waiting for the slowest core.
 *  - Background training leaves [CORES_RESERVED_DURING_TRAINING] cores to the OS and UI. A plastic
 *    budget phone cannot shed the heat of eight cores pinned for minutes, and a training session
 *    runs for many minutes; six threads keep well over 90% of the throughput with noticeably less
 *    sustained heat and no UI jank while the phone is in the user's hand.
 */
object ComputeBudget {

    /** Must match the native pool's hard cap (rust/src/par.rs, MAX_THREADS). */
    const val MAX_NATIVE_THREADS = 8

    const val CORES_RESERVED_DURING_TRAINING = 2

    /** Threads for an interactive, user-waiting job (Enhance, validation previews). */
    fun enhancementThreads(cpuCores: Int): Int = cpuCores.coerceIn(1, MAX_NATIVE_THREADS)

    /** Threads for a background training session. Always at least 1, also on dual/quad-core phones. */
    fun trainingThreads(cpuCores: Int): Int =
        (cpuCores - CORES_RESERVED_DURING_TRAINING).coerceIn(1, MAX_NATIVE_THREADS)

    // ------------------------------------------------------------------------------------------------ memory

    /** What the memory budget needs to know about the device (see [MemoryStats.ramInfo]). */
    data class RamInfo(val totalMb: Long, val availableMb: Long, val isLowRamDevice: Boolean)

    /**
     * Most pixels (band + context rows) the native enhancement pipeline may process at once on this device.
     *
     * Two limits, the smaller wins: a TIER from the device's total RAM (a 4 GB phone is conservative, 6 GB and 8 GB
     * phones may take bigger bands, which waste less work re-processing context rows), and an AFFORDABILITY cap of
     * [Constants.BAND_SHARE_OF_FREE_RAM] of the RAM that is free right now, at [Constants.BAND_BYTES_PER_PIXEL] per
     * pixel - so a phone that is already short of memory gets a smaller band than its tier. With no RAM information
     * the old fixed value ([Constants.BAND_PIXELS_LOW_RAM]) is used.
     *
     * The result is rounded down to 50,000 pixels and never below [Constants.MIN_BAND_PIXELS].
     */
    fun maxBandPixels(ram: RamInfo?): Int {
        if (ram == null) return Constants.BAND_PIXELS_LOW_RAM
        val tier = when {
            ram.isLowRamDevice || ram.totalMb < Constants.RAM_TIER_4GB_MIN_MB -> Constants.BAND_PIXELS_LOW_RAM
            ram.totalMb < Constants.RAM_TIER_6GB_MIN_MB -> Constants.BAND_PIXELS_4GB
            ram.totalMb < Constants.RAM_TIER_8GB_MIN_MB -> Constants.BAND_PIXELS_6GB
            else -> Constants.BAND_PIXELS_8GB
        }
        val affordable = max(0L, ram.availableMb).toDouble() * 1_048_576.0 *
            Constants.BAND_SHARE_OF_FREE_RAM / Constants.BAND_BYTES_PER_PIXEL
        val rounded = (min(affordable, tier.toDouble()).toLong() / 50_000L * 50_000L).toInt()
        return min(tier, max(Constants.MIN_BAND_PIXELS, rounded))
    }

    /**
     * Own rows per native processing chunk for a photo [width] pixels wide whose pipeline needs [halo] context rows
     * above and below every chunk. MIRRORS `chunk_core_rows` in rust/src/enhance/session.rs - keep the two in step
     * (if they ever drift the only effect is a short tail chunk, never a wrong pixel).
     *
     * Every chunk also processes [halo] rows on each side that are then thrown away, so a chunk with fewer than
     * `2 * halo` own rows wastes more than half its work; the pixel cap alone let that reach 8x on wide photos.
     */
    fun chunkCoreRows(maxBandPixels: Int, width: Int, halo: Int): Int {
        val minCore = max(16, 2 * halo)
        val maxRows = max(maxBandPixels / max(1, width), 2 * halo + minCore)
        return maxRows - 2 * halo
    }

    /**
     * Rows per [com.novaenhance.ai.ai.engine.BandProcessor] band: the traditional [Constants.BAND_ROWS_PX] rows,
     * adjusted so a band is a whole number of native chunks - a band that ends mid-chunk makes the native side
     * process one short tail chunk per band, and a short chunk pays its context rows for little useful work.
     * Bands stay between one chunk and twice [Constants.BAND_ROWS_PX] rows, so progress updates, cancellation and
     * thermal pacing keep their granularity however much memory the device has.
     */
    fun bandRowsFor(width: Int, halo: Int, maxBandPixels: Int): Int {
        val core = chunkCoreRows(maxBandPixels, width, halo)
        val base = Constants.BAND_ROWS_PX
        return if (core >= base) min(core, 2 * base) else core * (base / core)
    }

    // ------------------------------------------------------------------------------------------------ heat

    /**
     * Threads to use given the thermal headroom ([android.os.PowerManager.getThermalHeadroom]): all of [ceiling] while
     * the phone is comfortably cool, then a gradual hand-back as it warms - 100 % at headroom
     * [Constants.THERMAL_HEADROOM_EASE_START], [Constants.THERMAL_HEADROOM_MIN_FRACTION] of the ceiling at
     * [Constants.THERMAL_HEADROOM_EASE_FULL] and beyond. NaN (no thermal API, or the device does not report it)
     * changes nothing, so those phones behave exactly as before.
     */
    fun threadsForHeadroom(ceiling: Int, headroom: Float): Int {
        val top = max(1, ceiling)
        if (headroom.isNaN() || headroom <= Constants.THERMAL_HEADROOM_EASE_START) return top
        val span = Constants.THERMAL_HEADROOM_EASE_FULL - Constants.THERMAL_HEADROOM_EASE_START
        val t = ((headroom - Constants.THERMAL_HEADROOM_EASE_START) / span).coerceIn(0f, 1f)
        val fraction = 1f - (1f - Constants.THERMAL_HEADROOM_MIN_FRACTION) * t
        return ceil(top * fraction).toInt().coerceIn(1, top)
    }
}
