package com.novaenhance.ai.training.checkpoint

import com.novaenhance.ai.utils.NovaLog
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

private const val TAG = "CheckpointManager"
private const val ENTRY_WEIGHTS = "model.weights"
private const val ENTRY_METADATA = "metadata.json"

// A real model is ~0.5 MB. Anything near this is not a model, and an import must never be able to fill the phone.
private const val MAX_ENTRY_BYTES = 64L * 1024L * 1024L

/**
 * Packages/unpacks a `.novamodel` bundle: a version's single weights file
 * (see [com.novaenhance.ai.ai.engine.NovaModelEngine]'s save/restore
 * format) plus its metadata, zipped together into one portable,
 * importable file. Much simpler than this project's earlier TFLite-based
 * design, which needed to juggle several sibling checkpoint shard files
 * sharing a prefix plus a separately-shared architecture graph file - here
 * a version is just one file, so backup/export/import is just "copy/zip/
 * unzip one file," full stop.
 */
class CheckpointManager {

    /** Bundles [weightsFile] with an existing metadata file. */
    fun exportBundle(weightsFile: File, metadataFile: File, destZip: File) {
        writeBundle(destZip) { zip ->
            addEntry(zip, ENTRY_WEIGHTS, weightsFile)
            addEntry(zip, ENTRY_METADATA, metadataFile)
        }
    }

    /**
     * Bundles [weightsFile] with metadata given as JSON text. This is the path real exports take: only a model's
     * first version ever had a metadata *file* next to its weights (versions written by training never did), so
     * exporting from a file made every trained version fail.
     */
    fun exportBundle(weightsFile: File, metadataJson: String, destZip: File) {
        writeBundle(destZip) { zip ->
            addEntry(zip, ENTRY_WEIGHTS, weightsFile)
            zip.putNextEntry(ZipEntry(ENTRY_METADATA))
            zip.write(metadataJson.toByteArray(Charsets.UTF_8))
            zip.closeEntry()
        }
    }

    data class ImportedBundle(val weightsFile: File, val metadataFile: File)

    /**
     * Unpacks [zipFile] into [destDir] as `v<versionNumber>.weights` / `v<versionNumber>.json`. A bundle without
     * metadata still imports (a minimal metadata file is written), but one without weights is rejected.
     */
    fun importBundle(zipFile: File, destDir: File, versionNumber: Int): ImportedBundle {
        destDir.mkdirs()
        val weightsFile = File(destDir, "v$versionNumber.weights")
        val metadataFile = File(destDir, "v$versionNumber.json")

        ZipInputStream(zipFile.inputStream().buffered()).use { zip ->
            var entry: ZipEntry? = zip.nextEntry
            while (entry != null) {
                when (entry.name) {
                    ENTRY_WEIGHTS -> writeEntry(zip, weightsFile)
                    ENTRY_METADATA -> writeEntry(zip, metadataFile)
                }
                zip.closeEntry()
                entry = zip.nextEntry
            }
        }

        require(weightsFile.exists()) { "Bundle is missing $ENTRY_WEIGHTS" }
        if (!metadataFile.exists()) {
            metadataFile.writeText("""{"modelName":"Imported model","versionNumber":$versionNumber}""")
        }
        return ImportedBundle(weightsFile, metadataFile)
    }

    /** Writes through a temporary file, so a failed export never leaves a half-written bundle that could be shared. */
    private fun writeBundle(destZip: File, fill: (ZipOutputStream) -> Unit) {
        destZip.parentFile?.mkdirs()
        val staging = File(destZip.parentFile, destZip.name + ".tmp")
        try {
            ZipOutputStream(staging.outputStream().buffered()).use { zip -> fill(zip) }
            if (destZip.exists()) destZip.delete()
            if (!staging.renameTo(destZip)) {
                staging.copyTo(destZip, overwrite = true)
                staging.delete()
            }
        } catch (t: Throwable) {
            staging.delete()
            throw t
        }
        NovaLog.i(TAG, "Exported bundle to ${destZip.path} (${destZip.length()} bytes)")
    }

    private fun addEntry(zip: ZipOutputStream, name: String, file: File) {
        zip.putNextEntry(ZipEntry(name))
        file.inputStream().use { it.copyTo(zip) }
        zip.closeEntry()
    }

    private fun writeEntry(zip: ZipInputStream, dest: File) {
        dest.outputStream().use { out ->
            val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
            var total = 0L
            while (true) {
                val read = zip.read(buffer)
                if (read < 0) break
                total += read
                require(total <= MAX_ENTRY_BYTES) { "Bundle entry is larger than $MAX_ENTRY_BYTES bytes" }
                out.write(buffer, 0, read)
            }
        }
    }
}
