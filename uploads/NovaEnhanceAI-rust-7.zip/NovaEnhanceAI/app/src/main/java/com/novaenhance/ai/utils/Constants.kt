package com.novaenhance.ai.utils

/**
 * Central home for tunables that would otherwise be duplicated/hardcoded
 * across the AI engine, training engine, and workers. Nothing in this file
 * is a hardcoded *path* - storage locations always go through [com.novaenhance.ai.storage.AppStorage],
 * which resolves them from Android's Context APIs at runtime.
 */
object Constants {

    // --- Tile-based processing (keeps peak memory bounded on 4GB devices) ---
    // Must match NativeNeuralEngine.TILE_SIZE exactly - the network's input
    // size is fixed at compile time (see rust/src/nn/mod.rs),
    // not configurable per-model.
    const val TILE_SIZE_PX = 64

    // Enhancing a large image runs the network over whole full-width bands of rows (BandProcessor) rather than
    // 64px tiles: memory stays bounded, yet results have no tile seams. A band's native working set is a few
    // MB per array; taller bands mean less redundant context-row work (BandProcessor re-reads a handful of
    // rows above/below each band), shorter ones mean finer progress/cancellation/thermal-pacing granularity.
    const val BAND_ROWS_PX = 256

    // --- Training defaults (starting points for the adaptive controller) ---
    // WARNING: this architecture's clip[0,1] output activation has zero
    // gradient outside that range, so a learning rate that's too high can
    // saturate the network and get it permanently stuck (verified
    // empirically, not just theoretically - see the comment on
    // clip01BackwardFromPre in rust/src/nn/mod.rs and
    // tools/nn_verification/lr_saturation_check.cpp). 1e-4 is safely inside
    // the working range (confirmed up to 1.5x this, the adaptive
    // controller's ceiling, under a stress test far harsher than real
    // training); 0.02 reliably breaks within ~30 steps. Don't raise this
    // without re-running that check.
    const val DEFAULT_LEARNING_RATE = 1e-4f
    const val DEFAULT_BATCH_SIZE = 4
    const val DEFAULT_EPOCHS = 3

    // A CNN with ~44K parameters needs a few hundred optimizer steps before a session can change it in a way
    // validation can measure. A small dataset (10 pairs -> 3 batches per epoch) used to mean 2 epochs = 6 steps: the
    // session "finished" in seconds, changed nothing, and looked like it never trained. The planner now raises the
    // epoch count (up to MAX_TRAINING_EPOCHS) until a session has at least this many steps; patches are re-cut at
    // random positions and orientations every epoch, so repeating a small dataset is not repeating the same input.
    const val MIN_TRAINING_STEPS = 200
    const val MAX_TRAINING_EPOCHS = 40
    const val MIN_BATCH_SIZE = 1
    const val MAX_BATCH_SIZE = 16

    // Training patches cut from every (low, high) image pair per optimizer step, each from the same
    // decoded crop but at its own random position and flip/rotation (TrainingPatchLoader). Decoding a
    // crop out of a JPEG costs about the same whether it yields one patch or four, and the native
    // training step is now fast enough that disk/decode - not math - is what a session waits on.
    const val TRAINING_PATCHES_PER_PAIR = 4
    const val TRAINING_PATCHES_PER_PAIR_REDUCED = 2

    // --- Adaptive controller thresholds ---
    const val LOW_RAM_THRESHOLD_MB = 2048L
    const val CRITICAL_RAM_THRESHOLD_MB = 1024L
    // Below this much free RAM the governor pauses work outright (see ThermalGovernor). Deliberately far lower
    // than CRITICAL_RAM_THRESHOLD_MB, which only shrinks the batch size.
    const val PAUSE_RAM_THRESHOLD_MB = 256L

    // --- Graduated thermal throttling (see ThermalGovernor.evaluate) ---
    // Below THERMAL_STATUS_SEVERE, the old behavior was "run flat out" -
    // these let CPU-bound work (training batches, validation/rescoring
    // passes, and tile-based image enhancement) ease off progressively
    // instead of pinning every available core until Android's own thermal
    // manager forces SEVERE. Chosen to be a small, close-to-free tax when
    // the device is only mildly warm (MODERATE) and a much more assertive
    // one once thermalProtectionEnabled is off but the device is already at
    // SEVERE (that setting only opts out of the hard PAUSE, not out of
    // easing off at all).
    const val THERMAL_COOLDOWN_MODERATE_MS = 300L
    const val THERMAL_COOLDOWN_SEVERE_UNPROTECTED_MS = 1_500L
    const val THERMAL_CONCURRENCY_MODERATE = 2
    const val THERMAL_CONCURRENCY_SEVERE_UNPROTECTED = 1

    // --- Thermal headroom easing (Android 11+; see ComputeBudget.threadsForHeadroom) ---
    // PowerManager.getThermalHeadroom() is 0.0 for a cool device and 1.0 at the point where Android starts SEVERE
    // throttling. Below EASE_START the app runs flat out as before; from there to EASE_FULL it hands back threads
    // gradually (down to MIN_FRACTION of the ceiling) instead of running every core until the status flips to
    // MODERATE and the governor drops straight to two threads plus a pause. The forecast looks this far ahead.
    const val THERMAL_HEADROOM_EASE_START = 0.70f
    const val THERMAL_HEADROOM_EASE_FULL = 1.00f
    const val THERMAL_HEADROOM_MIN_FRACTION = 0.25f
    const val THERMAL_HEADROOM_FORECAST_SECONDS = 10

    // While the user is waiting for an Enhance (InteractiveWork), a background training step may use at most this
    // many native threads, so training cannot take the cores the interactive pass needs.
    const val THREADS_WHILE_INTERACTIVE_WORK_RUNS = 2

    // --- Device-adaptive working set for image enhancement (see ComputeBudget.maxBandPixels) ---
    // Android reports a little less than the marketing RAM figure (a "4 GB" phone reports ~3.7 GB), so the tier
    // boundaries sit below the round numbers.
    const val RAM_TIER_4GB_MIN_MB = 3_072L
    const val RAM_TIER_6GB_MIN_MB = 5_120L
    const val RAM_TIER_8GB_MIN_MB = 7_168L
    // Most pixels (band + context rows) the native pipeline processes at once, per tier. The first is what every
    // device used before; a bigger band wastes less work re-processing context rows (docs/PERFORMANCE.md).
    const val BAND_PIXELS_LOW_RAM = 800_000
    const val BAND_PIXELS_4GB = 1_500_000
    const val BAND_PIXELS_6GB = 2_500_000
    const val BAND_PIXELS_8GB = 4_000_000
    const val MIN_BAND_PIXELS = 400_000
    // Native working-set cost per band pixel, measured on the heaviest stage mix at 8000 px wide (~54 bytes),
    // rounded up. One band's working set may take at most BAND_SHARE_OF_FREE_RAM of the RAM that is free right now.
    const val BAND_BYTES_PER_PIXEL = 56L
    const val BAND_SHARE_OF_FREE_RAM = 0.05

    // --- Experience replay (anti-forgetting) ---
    const val REPLAY_BUFFER_MAX_SIZE = 200
    const val REPLAY_BATCH_FRACTION = 0.25f // fraction of each batch drawn from replay buffer

    // --- Dataset analysis ---
    const val PERCEPTUAL_HASH_SIZE = 8 // 8x8 -> 64-bit dHash
    const val DUPLICATE_HASH_DISTANCE_THRESHOLD = 5 // Hamming distance
    const val MIN_VALID_PAIR_SIMILARITY = 0.15f // below this, pair is likely mismatched content
    const val MAX_VALID_PAIR_SIMILARITY = 0.98f // above this, pair has no enhancement signal
    // Every metric analyzeNewPairs computes (perceptual hash, sharpness,
    // quick-similarity) internally downsamples further to <=128px anyway,
    // so decoding at full camera resolution just to shrink it again was
    // pure wasted decode time; this is generous headroom above that 128px
    // ceiling with no measurable effect on the scores themselves.
    const val DATASET_ANALYSIS_DECODE_TARGET_PX = 256

    // --- Model file layout (relative to app-private external files dir) ---
    const val MODELS_DIR = "models"
    const val CHECKPOINTS_DIR = "checkpoints"
    const val BACKUPS_DIR = "model_backups"
    const val DATASET_DIR = "datasets"

    // --- Notification channels ---
    const val NOTIFICATION_CHANNEL_TRAINING = "novaenhance_training"
    const val TRAINING_NOTIFICATION_ID = 1001
    const val TRAINING_RESULT_NOTIFICATION_ID = 1002

    // --- WorkManager unique work names ---
    const val WORK_NAME_TRAINING = "novaenhance_training_work"
    const val WORK_NAME_DATASET_ANALYSIS = "novaenhance_dataset_analysis_work"
}
