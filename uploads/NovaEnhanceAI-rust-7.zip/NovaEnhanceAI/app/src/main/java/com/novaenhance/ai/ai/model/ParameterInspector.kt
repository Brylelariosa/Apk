package com.novaenhance.ai.ai.model

import com.novaenhance.ai.ai.engine.NativeNeuralEngine
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import java.util.zip.CRC32
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

/** Whether a slice of the flat parameter vector holds convolution weights or biases. */
enum class ParameterKind { WEIGHT, BIAS }

/**
 * One contiguous slice of the model's flat parameter vector: one layer's weights, or one layer's biases.
 * [layerIndex] is 1-based (layer 1 is the first convolution).
 */
class ParameterSegment(
    val layerIndex: Int,
    val kind: ParameterKind,
    val offset: Int,
    val size: Int,
    val inChannels: Int,
    val outChannels: Int
) {
    val label: String
        get() = "Layer $layerIndex ${if (kind == ParameterKind.WEIGHT) "weights" else "biases"}"
}

/**
 * Where everything sits in the flat `FloatArray` that IS the model. This mirrors `rust/src/nn/mod.rs` (the Rust
 * side owns the truth; `ParameterInspectorTest` pins the offsets against its constants): four 3x3 convolutions,
 * 3 -> 48 -> 48 -> 48 -> 3 channels, each stored as its weights `[tap][in][out]` (out contiguous) followed by its
 * biases.
 */
object ParameterLayout {
    const val KERNEL_TAPS = 9
    const val LAYER_COUNT = 4

    private val channels = intArrayOf(3, 48, 48, 48, 3)

    val segments: List<ParameterSegment> = buildSegments()

    /** Number of parameters the layout describes; equals [NativeNeuralEngine.TOTAL_PARAMS]. */
    val total: Int = segments.last().offset + segments.last().size

    private fun buildSegments(): List<ParameterSegment> {
        val list = ArrayList<ParameterSegment>()
        var offset = 0
        for (layer in 0 until LAYER_COUNT) {
            val inCh = channels[layer]
            val outCh = channels[layer + 1]
            val weightCount = KERNEL_TAPS * inCh * outCh
            list.add(ParameterSegment(layer + 1, ParameterKind.WEIGHT, offset, weightCount, inCh, outCh))
            offset += weightCount
            list.add(ParameterSegment(layer + 1, ParameterKind.BIAS, offset, outCh, inCh, outCh))
            offset += outCh
        }
        return list
    }

    /** The weights of [layer] (1-based). */
    fun weights(layer: Int): ParameterSegment = segments[(layer - 1) * 2]

    /** The biases of [layer] (1-based). */
    fun biases(layer: Int): ParameterSegment = segments[(layer - 1) * 2 + 1]

    /** Index range covering one layer's weights AND biases (they are adjacent in the vector). */
    fun layerRange(layer: Int): IntRange {
        val w = weights(layer)
        val b = biases(layer)
        return w.offset until (b.offset + b.size)
    }

    fun segmentFor(index: Int): ParameterSegment {
        require(index in 0 until total) { "parameter index $index is outside 0..${total - 1}" }
        return segments.first { index >= it.offset && index < it.offset + it.size }
    }

    /** A short, human-readable address for one parameter, e.g. `L2 w tap4 in12 out30` or `L3 bias out7`. */
    fun describe(index: Int): String {
        val seg = segmentFor(index)
        val local = index - seg.offset
        return when (seg.kind) {
            ParameterKind.BIAS -> "L${seg.layerIndex} bias out$local"
            ParameterKind.WEIGHT -> {
                val perTap = seg.inChannels * seg.outChannels
                val tap = local / perTap
                val rest = local % perTap
                "L${seg.layerIndex} w tap$tap in${rest / seg.outChannels} out${rest % seg.outChannels}"
            }
        }
    }
}

/** Summary numbers for one [ParameterSegment]. [histogram] spreads the values evenly over `-maxAbs..+maxAbs`. */
class SegmentStats(
    val segment: ParameterSegment,
    val min: Float,
    val max: Float,
    val mean: Float,
    val std: Float,
    val rms: Float,
    /** Share (0..1) of values whose magnitude is below [ParameterInspector.NEAR_ZERO]. */
    val nearZeroFraction: Float,
    val maxAbs: Float,
    val histogram: IntArray
)

/** Everything the Parameters screen shows about one saved model version. */
class ParameterSnapshot(
    val values: FloatArray,
    val adamStep: Int,
    val fingerprint: String,
    val segments: List<SegmentStats>
) {
    val parameterCount: Int get() = values.size

    fun statsFor(segment: ParameterSegment): SegmentStats = segments.first { it.segment === segment }
}

/**
 * Pure-Kotlin statistics over a model's parameters - no native code, so it is unit-testable on a plain JVM.
 */
object ParameterInspector {
    const val HISTOGRAM_BINS = 25

    /** Values smaller than this in magnitude count as "essentially zero" for the near-zero share. */
    const val NEAR_ZERO = 1e-3f

    fun inspect(values: FloatArray, adamStep: Int): ParameterSnapshot {
        require(values.size == ParameterLayout.total) {
            "Expected ${ParameterLayout.total} parameters but got ${values.size} " +
                "(the app's network has ${NativeNeuralEngine.TOTAL_PARAMS})"
        }
        val stats = ParameterLayout.segments.map { statsOf(values, it) }
        return ParameterSnapshot(values, adamStep, fingerprint(values), stats)
    }

    /**
     * A short identifier of the exact weights (CRC-32 of their little-endian bytes, as `XXXX-XXXX`). The same
     * trained model has the same fingerprint on every phone, so after sending a model the two can be compared by
     * eye. Optimizer state is deliberately not part of it - only the numbers the model actually computes with.
     */
    fun fingerprint(values: FloatArray): String {
        val buffer = ByteBuffer.allocate(values.size * 4).order(ByteOrder.LITTLE_ENDIAN)
        buffer.asFloatBuffer().put(values)
        val crc = CRC32()
        crc.update(buffer.array())
        val hex = String.format(Locale.US, "%08X", crc.value)
        return hex.substring(0, 4) + "-" + hex.substring(4)
    }

    private fun statsOf(values: FloatArray, segment: ParameterSegment): SegmentStats {
        val start = segment.offset
        val end = segment.offset + segment.size
        var lowest = Float.POSITIVE_INFINITY
        var highest = Float.NEGATIVE_INFINITY
        var sum = 0.0
        var nearZero = 0
        for (i in start until end) {
            val v = values[i]
            if (v < lowest) lowest = v
            if (v > highest) highest = v
            sum += v
            if (abs(v) < NEAR_ZERO) nearZero++
        }
        val count = segment.size
        val mean = sum / count
        var squares = 0.0
        var variance = 0.0
        for (i in start until end) {
            val v = values[i].toDouble()
            squares += v * v
            variance += (v - mean) * (v - mean)
        }
        val maxAbs = max(abs(lowest), abs(highest))
        val histogram = IntArray(HISTOGRAM_BINS)
        val half = if (maxAbs > 0f) maxAbs else 1f
        for (i in start until end) {
            val position = (values[i] + half) / (2f * half)
            val bin = (position * HISTOGRAM_BINS).toInt().coerceIn(0, HISTOGRAM_BINS - 1)
            histogram[bin]++
        }
        return SegmentStats(
            segment = segment,
            min = lowest,
            max = highest,
            mean = mean.toFloat(),
            std = sqrt(variance / count).toFloat(),
            rms = sqrt(squares / count).toFloat(),
            nearZeroFraction = nearZero.toFloat() / count,
            maxAbs = maxAbs,
            histogram = histogram
        )
    }
}
