package com.novaenhance.ai.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = TealPrimaryDark,
    onPrimary = GraphiteBackgroundDark,
    primaryContainer = Color(0xFF1B4A45),
    onPrimaryContainer = Color(0xFFD2F7F2),
    secondary = AmberAccentDark,
    onSecondary = GraphiteBackgroundDark,
    secondaryContainer = Color(0xFF4A3A1E),
    onSecondaryContainer = Color(0xFFFFE3BC),
    background = GraphiteBackgroundDark,
    onBackground = OnDark,
    surface = GraphiteSurfaceDark,
    onSurface = OnDark,
    surfaceVariant = GraphiteSurfaceVariantDark,
    onSurfaceVariant = OnDarkMuted,
    error = ErrorDark,
    onError = GraphiteBackgroundDark
)

private val LightColors = lightColorScheme(
    primary = TealPrimaryLight,
    onPrimary = CloudSurfaceLight,
    primaryContainer = Color(0xFFCDEFEA),
    onPrimaryContainer = Color(0xFF083A34),
    secondary = AmberAccentLight,
    onSecondary = CloudSurfaceLight,
    secondaryContainer = Color(0xFFFBE7C6),
    onSecondaryContainer = Color(0xFF4A3300),
    background = CloudBackgroundLight,
    onBackground = OnLight,
    surface = CloudSurfaceLight,
    onSurface = OnLight,
    surfaceVariant = CloudSurfaceVariantLight,
    onSurfaceVariant = OnLightMuted,
    error = ErrorLight,
    onError = CloudSurfaceLight
)

/**
 * Deliberately does NOT offer a dynamic-color (Material You wallpaper-based)
 * option - this app's teal/amber restoration-lab identity is a considered
 * design choice (see [Color.kt]), not a placeholder meant to be overridden
 * by whatever wallpaper the user has.
 */
@Composable
fun NovaEnhanceTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = NovaTypography,
        content = content
    )
}
