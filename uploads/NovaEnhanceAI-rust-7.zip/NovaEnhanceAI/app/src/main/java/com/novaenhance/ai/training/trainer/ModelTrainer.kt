package com.novaenhance.ai.training.trainer

import androidx.room.withTransaction
import com.novaenhance.ai.ai.engine.NovaModelEngine
import com.novaenhance.ai.ai.engine.NativeNeuralEngine
import com.novaenhance.ai.ai.model.ModelRepository
import com.novaenhance.ai.database.AppDatabase
import com.novaenhance.ai.database.dao.DatasetPairDao
import com.novaenhance.ai.database.dao.LossHistoryDao
import com.novaenhance.ai.database.dao.ModelDao
import com.novaenhance.ai.database.dao.ModelVersionDao
import com.novaenhance.ai.database.dao.TrainingSessionDao
import com.novaenhance.ai.database.dao.ValidationMetricDao
import com.novaenhance.ai.database.entities.DatasetPairEntity
import com.novaenhance.ai.database.entities.LossHistoryEntity
import com.novaenhance.ai.database.entities.ModelVersionEntity
import com.novaenhance.ai.database.entities.TrainingSessionEntity
import com.novaenhance.ai.database.entities.TrainingStatus
import com.novaenhance.ai.storage.AppStorage
import com.novaenhance.ai.training.checkpoint.AtomicCheckpointFile
import com.novaenhance.ai.training.dataset.DatasetAnalyzer
import com.novaenhance.ai.utils.ComputeBudget
import com.novaenhance.ai.utils.DeviceCapabilities
import com.novaenhance.ai.utils.NovaLog
import com.novaenhance.ai.utils.ThermalGovernor
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.random.Random

private const val TAG = "ModelTrainer"
private const val CHECKPOINT_SAVE_EVERY_N_BATCHES = 20
private const val MIN_VALIDATION_HOLD_OUT = 1
private const val MAX_VALIDATION_HOLD_OUT = 20
private const val VALIDATION_HOLD_OUT_FRACTION = 0.15f

// When the thermal/memory governor says PAUSE the batch loop waits for the condition to clear instead of ending the
// session: re-check every few seconds, for up to this long, before giving up and leaving the session paused.
private const val THROTTLE_WAIT_POLL_MS = 3_000L
private const val THROTTLE_WAIT_MAX_MS = 3 * 60_000L

/**
 * The Self-Improvement Loop's engine room: collect data -> train -> evaluate
 * -> (find weak areas / prioritize similar data is handled one level up by
 * [SelfImprovementOrchestrator], which decides *when* to call this and with
 * what dataset slice). This class owns one training *session's* full
 * lifecycle: dataset analysis gate, adaptive planning, the pause/resume/
 * cancel-safe batch loop, periodic crash-safe checkpoints that a resume
 * actually loads (see [loadEngineForSession]), anti-forgetting (anchor +
 * replay), and validation-gated, transactionally-promoted models.
 */
class ModelTrainer(
    private val modelRepository: ModelRepository,
    private val datasetPairDao: DatasetPairDao,
    private val trainingSessionDao: TrainingSessionDao,
    private val lossHistoryDao: LossHistoryDao,
    private val validationMetricDao: ValidationMetricDao,
    private val modelVersionDao: ModelVersionDao,
    private val modelDao: ModelDao,
    private val appDatabase: AppDatabase,
    private val datasetAnalyzer: DatasetAnalyzer,
    private val adaptiveController: AdaptiveTrainingController,
    private val experienceMemory: ExperienceMemory,
    private val validator: ModelValidator,
    private val storage: AppStorage,
    private val deviceCapabilities: DeviceCapabilities,
    private val thermalGovernor: ThermalGovernor,
    private val progressPublisher: TrainingProgressPublisher
) {
    /**
     * [progress] and [lastError] delegate straight through to the shared
     * [TrainingProgressPublisher] (also written by [SelfImprovementOrchestrator]'s
     * RESCORING phase) rather than owning their own StateFlows, so every
     * existing caller of `modelTrainer.progress`/`.lastError` keeps working
     * unchanged while still seeing updates published by other stages of the
     * pipeline.
     */
    val progress: StateFlow<TrainingProgressState?> get() = progressPublisher.progress
    val lastError: StateFlow<String?> get() = progressPublisher.lastError

    /** Called by [com.novaenhance.ai.workers.TrainingForegroundService] when [runSession] throws. */
    fun reportStartupFailure(message: String) {
        progressPublisher.reportStartupFailure(message)
    }

    fun clearLastError() {
        progressPublisher.clearLastError()
    }

    /** Crash recovery: call at app/service start to find a session that never reached a terminal state. */
    suspend fun findRecoverableSession(): TrainingSessionEntity? =
        trainingSessionDao.findLatestWithStatus(TrainingStatus.RUNNING)

    /**
     * Call once, early in the process's lifetime (see
     * [com.novaenhance.ai.NovaEnhanceApplication]). If [findRecoverableSession]
     * finds a session still marked RUNNING, nothing in THIS process has
     * started training it yet - this runs before any Activity/Service/Worker
     * can - so it can only be a leftover from a previous process that never
     * reached a terminal state (killed mid-session, force-stopped, crashed).
     * Flips it to PAUSED, identical to what an explicit user pause produces,
     * so the existing Resume flow ([runSession]'s `resumeSessionId`) picks it
     * up with zero special-casing anywhere else -
     * [com.novaenhance.ai.ui.viewmodel.TrainingViewModel] and
     * [com.novaenhance.ai.ui.screens.TrainingScreen] only ever needed to
     * handle "PAUSED is resumable," not "RUNNING but actually dead." Without
     * this, a killed process left its session stuck at RUNNING forever: the
     * Train AI screen would show Pause/Cancel controls for a session with no
     * training actually behind them (a fresh process's [TrainingControlFlow]
     * has nothing live reading it), and neither button could ever do
     * anything - there was no way back to a usable state short of clearing
     * app data.
     */
    suspend fun reconcileInterruptedSessions() {
        val stale = findRecoverableSession() ?: return
        trainingSessionDao.update(stale.copy(status = TrainingStatus.PAUSED))
        NovaLog.i(TAG, "Reconciled session ${stale.id} (model ${stale.modelId}) from a stale RUNNING state to PAUSED after an app/process restart")
    }

    private data class ResolvedTrainingEngine(
        val engine: NovaModelEngine,
        val session: TrainingSessionEntity,
        val resumedFromCheckpoint: Boolean = false,
        val resumedBatchesInEpoch: Int = 0
    )

    /**
     * Resolves which [NovaModelEngine] this session should train on. If
     * [session] has a recorded, still-valid in-progress checkpoint (see
     * [saveInProgressCheckpoint]), resumes from exactly that - restored
     * weights, optimizer state, and epoch/batch position all included -
     * rather than [ModelRepository.getEngine]'s promoted *active* version,
     * which silently discards every batch this session ran before whatever
     * interrupted it. That silent discard - recovery loading the active
     * model instead of the session's own latest valid checkpoint - was the
     * core bug this function exists to close; every session (fresh, or
     * resumed but with nothing yet checkpointed) still correctly falls back
     * to [ModelRepository.getEngine] exactly as before.
     *
     * The batch-skip this resolves to is only trusted when [plan]'s current
     * `realPairsPerBatch` matches what was recorded alongside the checkpoint
     * ([TrainingSessionEntity.checkpointRealPairsPerBatch]) -
     * [AdaptiveTrainingController] re-plans batch size/replay fraction from
     * scratch on every call, including a resume, so a device/dataset change
     * between the crash and the resume can legitimately produce a different
     * plan. Skipping the wrong *count* of batches under a changed plan could
     * silently skip past real training pairs that were never actually
     * trained on; falling back to 0 (re-running the epoch in full) is always
     * safe, just possibly a little redundant.
     */
    private suspend fun loadEngineForSession(
        modelId: String,
        session: TrainingSessionEntity,
        plan: AdaptiveTrainingController.TrainingPlan
    ): ResolvedTrainingEngine {
        val checkpointPath = session.checkpointPath
        if (checkpointPath != null) {
            val recovered = NovaModelEngine.tryRecoverInProgress(checkpointPath)
            if (recovered != null) {
                NovaLog.i(
                    TAG,
                    "Resuming session ${session.id} from its in-progress checkpoint " +
                        "(epoch ${session.checkpointEpoch}, batch ${session.checkpointBatchesInEpoch}, adamStep ${recovered.currentAdamStep})"
                )
                modelRepository.installResumedEngine(modelId, recovered)

                val sameEpoch = session.checkpointEpoch == session.epochsCompleted
                val currentRealPerBatch = realPairsPerBatch(plan.batchSize, plan.replayFraction)
                val sameBatching = session.checkpointRealPairsPerBatch == null || session.checkpointRealPairsPerBatch == currentRealPerBatch
                if (sameEpoch && !sameBatching) {
                    NovaLog.w(
                        TAG,
                        "Session ${session.id}'s batch plan changed since its last checkpoint " +
                            "(was ${session.checkpointRealPairsPerBatch} real pairs/batch, now $currentRealPerBatch) - " +
                            "re-running epoch ${session.checkpointEpoch} in full rather than risk skipping the wrong pairs"
                    )
                }
                val skipBatches = if (sameEpoch && sameBatching) session.checkpointBatchesInEpoch ?: 0 else 0
                return ResolvedTrainingEngine(recovered, session, resumedFromCheckpoint = true, resumedBatchesInEpoch = skipBatches)
            }
            NovaLog.w(TAG, "Session ${session.id} had a recorded checkpoint at $checkpointPath but it no longer validates - falling back to the active model")
            // Clear the now-confirmed-dead reference (and hand back the cleared
            // copy for the caller to keep using - not just write it to the DB -
            // so this doesn't get silently undone the next time the caller's own
            // session variable is persisted, e.g. by a finishAs() a moment later
            // that would otherwise still be copy()-ing forward the stale value)
            // so a later resume attempt doesn't keep re-validating the same
            // unrecoverable path.
            val cleared = session.copy(
                checkpointPath = null, checkpointEpoch = null, checkpointBatchesInEpoch = null,
                checkpointRealPairsPerBatch = null, checkpointAdamStep = null
            )
            trainingSessionDao.update(cleared)
            return ResolvedTrainingEngine(modelRepository.getEngine(modelId), cleared)
        }
        return ResolvedTrainingEngine(modelRepository.getEngine(modelId), session)
    }

    /**
     * Crash-safe save of an in-progress checkpoint PLUS the session
     * bookkeeping describing it (epoch/batch position, batching plan, Adam
     * step, when) - used by the periodic mid-epoch save, the end-of-epoch
     * save, and [finalizeSession]'s own pre-validation save, so there's
     * exactly one place that decides what "resumable from here" means. The
     * session row is only updated - and only after the file write actually
     * succeeds - so a save failure never makes the DB point at a checkpoint
     * that isn't really there; on failure the returned session is unchanged,
     * still describing whichever earlier save last succeeded (or none yet).
     */
    private suspend fun saveInProgressCheckpoint(
        session: TrainingSessionEntity,
        engine: NovaModelEngine,
        weightsFile: File,
        epoch: Int,
        batchesInEpoch: Int,
        realPairsPerBatchThisPlan: Int
    ): TrainingSessionEntity {
        return try {
            engine.saveCheckpoint(weightsFile.path)
            val updated = session.copy(
                checkpointPath = weightsFile.path,
                checkpointEpoch = epoch,
                checkpointBatchesInEpoch = batchesInEpoch,
                checkpointRealPairsPerBatch = realPairsPerBatchThisPlan,
                checkpointAdamStep = engine.currentAdamStep,
                checkpointSavedAt = System.currentTimeMillis()
            )
            trainingSessionDao.update(updated)
            updated
        } catch (t: Throwable) {
            NovaLog.w(TAG, "In-progress checkpoint save failed for session ${session.id} - the previous checkpoint (if any) remains the resumable one", t)
            session
        }
    }

    /**
     * Runs (or resumes) one training session to completion, pause, or
     * cancellation. Must be called from a background-appropriate dispatcher
     * (this does blocking bitmap I/O and CPU-bound tensor work) - see
     * [com.novaenhance.ai.workers.TrainingForegroundService].
     *
     * Resets [control] to [TrainingCommand.RUN] before anything else runs.
     * [control] is a single process-lifetime instance (one per
     * [com.novaenhance.ai.di.ServiceLocator]) that only ever moves off RUN
     * via an explicit pause()/cancel() call and nothing ever moved it back
     * except this - so without the reset, the *first* pause or cancel of
     * the process's lifetime would leave it stuck at PAUSE/CANCEL forever.
     * Every later call to this function - a brand new session just as much
     * as an actual resume - would then hit the very first
     * `control.command.value` check in the batch loop below with a stale
     * command left over from a previous session, and immediately re-exit
     * via [finishAs] before running a single batch or publishing a single
     * progress update. That's what made the progress bar never appear and
     * Pause/Resume/Cancel look unresponsive: the buttons worked fine, but
     * every run they started was already over by the time the batch loop
     * got to its first iteration.
     */
    suspend fun runSession(modelId: String, resumeSessionId: Long?, control: TrainingControlFlow): TrainingSessionEntity {
        // Owned here rather than inside the body so EVERY way out of a session - normal finish, pause,
        // cancel, an exception - abandons any batch still being prefetched and frees the native
        // training workspace (tens of MB of activations that exist only while a session runs).
        val loaderScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        try {
            return runSessionBody(modelId, resumeSessionId, control, loaderScope)
        } catch (cancelled: CancellationException) {
            // The service was torn down mid-session (the system stopped it, or the notification's Cancel was
            // tapped). Say so in the database: otherwise the row stays RUNNING and the Train AI screen shows a
            // training session - with Pause/Cancel buttons - that nothing is running any more.
            withContext(NonCancellable) { settleInterruptedSession(control, failure = null) }
            throw cancelled
        } catch (failure: Exception) {
            // Same for a crash inside the session (a native error, a missing file ...): record it as FAILED.
            withContext(NonCancellable) { settleInterruptedSession(control, failure = failure) }
            throw failure
        } finally {
            loaderScope.cancel()
            NativeNeuralEngine.releaseTrainingWorkspace()
        }
    }

    private suspend fun runSessionBody(
        modelId: String,
        resumeSessionId: Long?,
        control: TrainingControlFlow,
        loaderScope: CoroutineScope
    ): TrainingSessionEntity {
        control.resume()
        progressPublisher.clearLastError()
        publishPreparing(resumeSessionId ?: 0L, 0, "Checking your training pairs…")
        datasetAnalyzer.analyzeNewPairs(modelId)
        val usablePairs = datasetPairDao.getUsablePairsByDifficulty(modelId)
        require(usablePairs.isNotEmpty()) { "No usable training pairs for model $modelId" }

        val holdOut = (usablePairs.size * VALIDATION_HOLD_OUT_FRACTION).toInt()
            .coerceIn(MIN_VALIDATION_HOLD_OUT, MAX_VALIDATION_HOLD_OUT)
            .coerceAtMost(usablePairs.size - 1)
            .coerceAtLeast(0)
        // usablePairs is difficulty-ordered (hardest first, see
        // getUsablePairsByDifficulty), which trainPairs benefits from for
        // curriculum ordering - but WHICH pairs get held out is re-randomized
        // every session rather than always being the same fixed tail. On a
        // static/reused dataset a fixed takeLast() tail meant validation
        // metrics - and AdaptiveTrainingController's loss-trend heuristics,
        // which react to them indirectly via promoted-session history - kept
        // getting evaluated against the exact same (easiest) slice every
        // single session instead of a representative spread of difficulty.
        val validationIds = if (holdOut > 0) {
            usablePairs.shuffled().take(holdOut).map { it.id }.toSet()
        } else {
            emptySet()
        }
        val validationPairs = usablePairs.filter { it.id in validationIds }
        val trainPairs = usablePairs.filterNot { it.id in validationIds }

        val recentSessions = trainingSessionDao.getRecentCompleted(modelId, limit = 5)
        // Distinct high-quality-image hashes, not distinct pairs: several
        // synthetic variants (DatasetManager.addSyntheticPairs) share the
        // same source photo and same perceptualHashHigh even though each
        // gets its own randomized low-quality degradation and its own
        // perceptualHashLow (so DatasetAnalyzer's dedup doesn't catch them).
        // This is what actually distinguishes "20 pairs from 20 different
        // photos" from "20 pairs from 4 photos" for planSession's epoch cap.
        val uniqueSourceCount = trainPairs.distinctBy { it.perceptualHashHigh }.size
        val plan = adaptiveController.planSession(trainPairs.size, recentSessions, uniqueSourceCount)

        var session = resumeSessionId?.let { trainingSessionDao.getById(it) }
            ?: run {
                val fresh = TrainingSessionEntity(
                    modelId = modelId,
                    startedAt = System.currentTimeMillis(),
                    status = TrainingStatus.RUNNING,
                    plannedEpochs = plan.epochs,
                    batchSize = plan.batchSize,
                    learningRate = plan.learningRate,
                    replayFraction = plan.replayFraction,
                    datasetPairCount = trainPairs.size,
                    deviceRamMbAtStart = plan.deviceRamMbAtStart
                )
                val id = trainingSessionDao.insert(fresh)
                fresh.copy(id = id)
            }
        if (session.status != TrainingStatus.RUNNING) {
            session = session.copy(status = TrainingStatus.RUNNING)
            trainingSessionDao.update(session)
        }

        val activeVersion = modelVersionDao.getActiveVersion(modelId) ?: error("No active version for $modelId")
        // Computed once, here, and threaded through every save this session makes
        // (periodic, end-of-epoch, and finalizeSession's own) rather than each site
        // computing activeVersion.versionNumber + 1 independently. getLatestVersionNumber
        // - not just activeVersion.versionNumber + 1 - matters whenever a *newer* version
        // number already exists on disk but isn't the active one: ModelRepository.restoreVersion
        // lets a user roll back to an older version without deleting the newer ones it
        // rolled back from, so activeVersion.versionNumber + 1 can collide with (and silently
        // overwrite mid-training) an existing, still-referenced, un-deleted later version.
        val nextVersionNumber = (modelVersionDao.getLatestVersionNumber(modelId) ?: activeVersion.versionNumber) + 1
        publishPreparing(session.id, session.plannedEpochs, "Loading the model…")
        val resolvedEngine = loadEngineForSession(modelId, session, plan)
        session = resolvedEngine.session // keep in sync with any DB-level change loadEngineForSession made (e.g. clearing a dead checkpoint reference)
        val engine = resolvedEngine.engine

        // Anti-forgetting anchor: snapshot pre-session weights once, before
        // any train() calls, so L2-SP can penalize drifting away from them.
        // Skipped when we actually resumed from an in-progress checkpoint
        // (see loadEngineForSession): the anchor was already snapshotted once
        // at this session's true start and is baked into the checkpoint's own
        // params/momentum/velocity state. Re-snapshotting here would anchor
        // to the *already-partially-trained* weights instead, defeating the
        // anti-forgetting penalty for exactly the segment that's resuming.
        if (!resolvedEngine.resumedFromCheckpoint) {
            engine.setAnchor()
        }

        val random = Random(System.currentTimeMillis())
        val patchLoader = TrainingPatchLoader(engine.tileSize, plan.patchesPerPair, loaderScope, random)
        // Native worker threads the optimizer step may use before the thermal governor narrows it. Training
        // leaves a couple of cores to the OS/UI (ComputeBudget): it runs for minutes in the user's pocket.
        val trainThreadCeiling = ComputeBudget.trainingThreads(Runtime.getRuntime().availableProcessors())
        var initialLoss: Float? = null
        var lastLoss: Float? = null
        var batchesRun = 0
        var unreadableBatches = 0 // batches whose images could not be decoded at all
        var thermalCooldownOccurred = false
        val startMs = System.currentTimeMillis()
        // Same realPerBatch math buildBatches() uses (not plan.batchSize
        // directly), so this prediction can't drift from the batch counts
        // buildBatches() actually produces once replay blending shrinks how
        // many real pairs fit per batch.
        val realPerBatch = realPairsPerBatch(plan.batchSize, plan.replayFraction)
        val batchesPerEpoch = kotlin.math.ceil(trainPairs.size.toFloat() / realPerBatch).toInt().coerceAtLeast(1)
        // Reduced by resumedBatchesInEpoch so the progress bar/ETA (which
        // compares batchesRun, itself always starting fresh at 0 for this
        // invocation - see below - against this total) still reaches exactly
        // 100% when this invocation's own remaining work finishes, instead of
        // permanently reading short by however many batches were skipped.
        val totalPlannedBatches = batchesPerEpoch * (session.plannedEpochs - session.epochsCompleted) - resolvedEngine.resumedBatchesInEpoch
        // The session's full unit budget: every remaining batch, the final
        // checkpoint write (1 unit), and validation's old-model + new-model
        // pass over every held-out pair (see ModelValidator) - so the bar
        // keeps moving through the checkpoint-save and validation tail
        // instead of freezing the moment the last batch finishes.
        val totalUnits = totalPlannedBatches + 1 + validationPairs.size * 2

        for (epoch in session.epochsCompleted until session.plannedEpochs) {
            val batches = buildBatches(trainPairs, plan.batchSize, plan.replayFraction, modelId)
            val skipBatches = if (epoch == session.epochsCompleted) resolvedEngine.resumedBatchesInEpoch else 0

            // The batch being decoded in the background while the previous one trains (null = nothing in
            // flight yet, e.g. the epoch's first batch). Abandoned automatically with [loaderScope].
            var prefetched: Deferred<List<PatchPair>>? = null
            for ((batchIndex, batch) in batches.withIndex()) {
                // Already covered by the checkpoint we resumed from - see
                // loadEngineForSession. trainPairs is difficulty-ordered and
                // not reshuffled between epochs, so re-derived batches are
                // pair-for-pair identical to the ones already trained on
                // except for the replay-sampled slice (buildBatches), which
                // is fine to draw fresh again.
                if (batchIndex < skipBatches) continue

                when (control.command.value) {
                    TrainingCommand.CANCEL -> return finishAs(session, TrainingStatus.CANCELLED, epoch, null)
                    TrainingCommand.PAUSE -> return finishAs(session, TrainingStatus.PAUSED, epoch, null)
                    TrainingCommand.RUN -> Unit
                }
                var throttle = thermalGovernor.evaluate(concurrencyCeiling = trainThreadCeiling, yieldToInteractive = true)
                if (throttle.action == ThermalGovernor.ThrottleAction.PAUSE) {
                    // Low memory and heat are usually momentary. Wait for them to clear - telling the user why -
                    // instead of ending the session on the spot: that used to flash the training notification
                    // and then stop, leaving a session that never trained and no explanation.
                    thermalCooldownOccurred = true
                    val after = waitOutPause(session, throttle, trainThreadCeiling, control)
                    if (control.stopRequested) {
                        return finishAs(
                            session,
                            if (control.command.value == TrainingCommand.CANCEL) TrainingStatus.CANCELLED else TrainingStatus.PAUSED,
                            epoch,
                            null
                        )
                    }
                    if (after.action == ThermalGovernor.ThrottleAction.PAUSE) {
                        progressPublisher.reportStartupFailure(
                            "Training paused because ${after.reason ?: "the phone needs a break"}. " +
                                "Free up memory or let the phone cool down, then tap Resume."
                        )
                        return finishAs(session, TrainingStatus.PAUSED, epoch, null, throttled = true)
                    }
                    throttle = after
                }
                if (throttle.action == ThermalGovernor.ThrottleAction.COOL_DOWN) {
                    thermalCooldownOccurred = true
                    delay(throttle.cooldownMillis)
                }

                val patches = (prefetched ?: patchLoader.loadAsync(batch)).await()
                // Start decoding the next batch NOW so it is ready by the time this step finishes.
                prefetched = batches.getOrNull(batchIndex + 1)?.let { patchLoader.loadAsync(it) }
                if (patches.isEmpty()) {
                    unreadableBatches++
                    continue
                }
                val lowTiles = patches.map { it.low }
                val highTiles = patches.map { it.high }

                val loss = engine.trainBatch(
                    lowTiles, highTiles, plan.learningRate, plan.l2SpLambda, threads = throttle.maxConcurrency
                )
                if (initialLoss == null) initialLoss = loss
                lastLoss = loss
                batchesRun++

                lossHistoryDao.insert(
                    LossHistoryEntity(sessionId = session.id, epoch = epoch, batchIndex = batchIndex, loss = loss, timestamp = System.currentTimeMillis())
                )

                publishProgress(session, epoch, plan, batchIndex, batches.size, loss, batchesRun, totalPlannedBatches, totalUnits, startMs)

                if (batchesRun % CHECKPOINT_SAVE_EVERY_N_BATCHES == 0) {
                    val inProgressFile = storage.weightsFile(modelId, nextVersionNumber)
                    session = saveInProgressCheckpoint(session, engine, inProgressFile, epoch, batchIndex + 1, realPerBatch)
                }
            }
            // Always checkpoint at the epoch boundary too, not just every
            // CHECKPOINT_SAVE_EVERY_N_BATCHES batches - otherwise a crash
            // between "last batch of an epoch" and the next periodic-save
            // tick (up to CHECKPOINT_SAVE_EVERY_N_BATCHES - 1 batches later)
            // could leave epochsCompleted claiming an epoch's worth of
            // training that the latest on-disk checkpoint doesn't actually
            // reflect yet.
            session = saveInProgressCheckpoint(session, engine, storage.weightsFile(modelId, nextVersionNumber), epoch, batches.size, realPerBatch)
            session = session.copy(epochsCompleted = epoch + 1)
            trainingSessionDao.update(session)
        }

        if (batchesRun == 0 && unreadableBatches > 0) {
            // Every batch came back empty: none of the pairs' images could be decoded. Finishing "successfully"
            // here is what made a session look like it trained when it had not run a single step.
            val reason = "None of the training images could be read ($unreadableBatches batches skipped). " +
                "Check that the image files still exist, then try again."
            progressPublisher.reportStartupFailure(reason)
            return finishAs(session, TrainingStatus.FAILED, session.plannedEpochs, null, failureReason = reason)
        }

        if (thermalCooldownOccurred && !session.wasThrottledByThermal) {
            session = session.copy(wasThrottledByThermal = true)
            trainingSessionDao.update(session)
        }

        return finalizeSession(modelId, session, engine, activeVersion, nextVersionNumber, trainPairs, validationPairs, initialLoss, lastLoss, totalPlannedBatches, totalUnits, control)
    }

    private suspend fun finalizeSession(
        modelId: String,
        session: TrainingSessionEntity,
        engine: NovaModelEngine,
        activeVersion: ModelVersionEntity,
        nextVersionNumber: Int,
        trainPairs: List<DatasetPairEntity>,
        validationPairs: List<DatasetPairEntity>,
        initialLoss: Float?,
        finalLoss: Float?,
        trainingUnitsCompleted: Int,
        totalUnits: Int,
        control: TrainingControlFlow
    ): TrainingSessionEntity {
        var session = session // shadowed as var - saveInProgressCheckpoint below needs to update it in place
        // Catches a pause/cancel that landed in the narrow gap between the
        // batch loop's last per-batch check and the loop simply running out
        // of batches - the epoch loop above only checks control *before*
        // each batch, so nothing polls it again between "last batch done"
        // and getting here. Whatever the last periodic/end-of-epoch save
        // captured (see saveInProgressCheckpoint) is still this session's
        // valid resume point either way, so there's nothing new to discard -
        // same as any other pause/cancel caught inside the batch loop itself.
        if (control.stopRequested) {
            return finishAs(
                session,
                if (control.command.value == TrainingCommand.CANCEL) TrainingStatus.CANCELLED else TrainingStatus.PAUSED,
                session.plannedEpochs,
                null
            )
        }

        publishPhase(session, TrainingPhase.SAVING_CHECKPOINT, 0, 1, trainingUnitsCompleted, totalUnits, finalLoss)

        val newWeightsFile = storage.weightsFile(modelId, nextVersionNumber)
        // Routed through the same bookkeeping-updating save as the in-training
        // checkpoints (epoch = plannedEpochs is a safe "fully done" sentinel -
        // it can never match a real loop epoch, which is always < plannedEpochs,
        // so it can never cause a spurious batch-skip on a future resume). This
        // closes the gap where a crash between "last epoch finished" and this
        // point would otherwise leave epochsCompleted claiming full credit
        // while the latest *checkpointed* file could still be missing up to
        // CHECKPOINT_SAVE_EVERY_N_BATCHES - 1 batches of the final epoch.
        session = saveInProgressCheckpoint(session, engine, newWeightsFile, session.plannedEpochs, 0, 0)

        val afterCheckpointUnits = trainingUnitsCompleted + 1
        publishPhase(session, TrainingPhase.SAVING_CHECKPOINT, 1, 1, afterCheckpointUnits, totalUnits, finalLoss)

        // Independent, unmutated "before" model for a fair comparison -
        // `engine` has already moved on to the freshly trained weights.
        // (No close()/cleanup needed - NovaModelEngine is a plain Kotlin
        // object with no native handle to leak.)
        val oldEngine = NovaModelEngine.loadFromCheckpoint(activeVersion.weightsFilePath)

        // Old-model + new-model pass per held-out pair - matches the *2 this
        // phase was budgeted in totalUnits. Each pass is a full band-based
        // enhancement (see EnhancementEngine/BandProcessor) that can take
        // several seconds to tens of seconds on a full-resolution image -
        // exactly the stretch that used to report no progress at all.
        val validationTotalPasses = (validationPairs.size * 2).coerceAtLeast(1)
        publishPhase(session, TrainingPhase.VALIDATING, 0, validationTotalPasses, afterCheckpointUnits, totalUnits, finalLoss)
        val validationResult = validator.validate(oldEngine, engine, validationPairs, session.id, control) { passesDone ->
            publishPhase(
                session, TrainingPhase.VALIDATING, passesDone, validationTotalPasses,
                afterCheckpointUnits + passesDone, totalUnits, finalLoss
            )
        }

        if (validationResult.wasInterrupted) {
            // Mirrors the batch loop's own pause/cancel contract: an
            // incomplete comparison can't support a promotion decision
            // either way (see ModelValidator.validate's overallImproved),
            // so the candidate checkpoint is discarded exactly like a
            // rejected one, and nothing lands in validationMetricDao for a
            // comparison that never finished.
            AtomicCheckpointFile.deleteAllGenerations(newWeightsFile)
            return finishAs(
                session,
                if (control.command.value == TrainingCommand.CANCEL) TrainingStatus.CANCELLED else TrainingStatus.PAUSED,
                session.plannedEpochs,
                null,
                initialLoss = initialLoss,
                finalLoss = finalLoss
            )
        }

        if (validationResult.metrics.isNotEmpty()) {
            validationMetricDao.insertAll(validationResult.metrics)
        }

        // However many onProgress calls the validator actually made (fewer
        // than budgeted if e.g. there was no old model to compare a
        // first-ever session against), the session's own work is now
        // genuinely done - snap the bar to the full total rather than
        // leaving it just short of 100%, the same class of bug this
        // phase-tracking scheme exists to fix.
        publishPhase(session, TrainingPhase.VALIDATING, validationTotalPasses, validationTotalPasses, totalUnits, totalUnits, finalLoss)

        val completedAt = System.currentTimeMillis()

        return if (validationResult.overallImproved) {
            // Everything that makes this version "the active model" happens in
            // one DB transaction: deactivating the old version, inserting and
            // activating the new one, marking the training pairs used, updating
            // the replay buffer, and recording the promotion on the model row
            // itself. Previously these were six separate, unguarded suspend
            // calls - a crash between deactivateAllForModel and insert could
            // leave the model with NO active version at all (getActiveVersion
            // returning null, breaking ModelRepository.getEngine outright)
            // until the user got lucky enough to retrain successfully; a crash
            // any time after insert could leave a promoted version whose
            // dataset/replay/model-stats bookkeeping never happened. Wrapping
            // the whole sequence means a crash anywhere in it now leaves things
            // exactly as they were before this session ran, with the old
            // version still fully active and untouched - never a half-applied
            // promotion.
            val versionId = appDatabase.withTransaction {
                modelVersionDao.deactivateAllForModel(modelId)
                val insertedId = modelVersionDao.insert(
                    ModelVersionEntity(
                        modelId = modelId,
                        versionNumber = nextVersionNumber,
                        weightsFilePath = newWeightsFile.path,
                        sizeBytes = newWeightsFile.length(),
                        parameterCount = activeVersion.parameterCount,
                        createdAt = completedAt,
                        trainingSessionId = session.id,
                        validationScore = validationResult.metrics.map { it.scoreAfterTraining }.average().toFloat(),
                        isPromoted = true,
                        isActive = true,
                        notes = "Trained on ${trainPairs.size} pairs"
                    )
                )
                modelVersionDao.activate(insertedId)

                datasetPairDao.markUsedInSession(trainPairs.map { it.id }, session.id)
                experienceMemory.remember(modelId, trainPairs)

                val improvementDelta = (validationResult.metrics.map { it.delta }.average() * 100).toFloat()
                modelDao.getById(modelId)?.let { model ->
                    modelDao.recordTrainingPromotion(
                        modelId = modelId,
                        versionNumber = nextVersionNumber,
                        parameterCount = activeVersion.parameterCount,
                        sizeBytes = newWeightsFile.length(),
                        newImagesLearned = trainPairs.size,
                        trainedAt = completedAt,
                        improvementScore = (model.improvementScore * 0.7f + improvementDelta * 0.3f).coerceIn(0f, 100f)
                    )
                }
                insertedId
            }

            finishAs(session, TrainingStatus.COMPLETED, session.plannedEpochs, versionId, initialLoss = initialLoss, finalLoss = finalLoss, promoted = true)
        } else {
            // Reject: discard the new checkpoint (and its crash-safety
            // siblings), old version stays active.
            AtomicCheckpointFile.deleteAllGenerations(newWeightsFile)
            finishAs(
                session, TrainingStatus.COMPLETED, session.plannedEpochs, null,
                initialLoss = initialLoss, finalLoss = finalLoss, promoted = false,
                failureReason = "Validation showed no overall improvement over the current model"
            )
        }
    }

    private suspend fun finishAs(
        session: TrainingSessionEntity,
        status: TrainingStatus,
        epochsCompleted: Int,
        resultVersionId: Long?,
        initialLoss: Float? = null,
        finalLoss: Float? = null,
        promoted: Boolean = false,
        failureReason: String? = null,
        throttled: Boolean = false
    ): TrainingSessionEntity {
        val updated = session.copy(
            status = status,
            epochsCompleted = epochsCompleted,
            completedAt = if (status == TrainingStatus.PAUSED) session.completedAt else System.currentTimeMillis(),
            resultModelVersionId = resultVersionId,
            wasPromoted = promoted,
            initialLoss = initialLoss ?: session.initialLoss,
            finalLoss = finalLoss ?: session.finalLoss,
            wasThrottledByThermal = session.wasThrottledByThermal || throttled,
            failureReason = failureReason
        )
        trainingSessionDao.update(updated)
        progressPublisher.updateStatus(status)
        return updated
    }

    private fun publishProgress(
        session: TrainingSessionEntity,
        epoch: Int,
        plan: AdaptiveTrainingController.TrainingPlan,
        batchIndex: Int,
        batchesInEpoch: Int,
        loss: Float,
        batchesRun: Int,
        totalPlannedBatches: Int,
        totalUnits: Int,
        startMs: Long
    ) {
        val elapsedSec = (System.currentTimeMillis() - startMs) / 1000.0
        val imagesPerSecond = if (elapsedSec > 0) (batchesRun * plan.batchSize) / elapsedSec else 0.0
        // ETA stays scoped to the training phase's own throughput (images/sec)
        // - totalUnits also includes checkpoint-save and validation units,
        // which take far longer per unit than a training batch does, so
        // mixing them into this calculation would badly inflate the ETA.
        val remainingBatches = (totalPlannedBatches - batchesRun).coerceAtLeast(0)
        val etaSeconds = if (imagesPerSecond > 0) (remainingBatches * plan.batchSize / imagesPerSecond).toLong() else -1L
        val ram = deviceCapabilities.snapshot()

        progressPublisher.publish(
            TrainingProgressState(
                sessionId = session.id,
                phase = TrainingPhase.TRAINING,
                epoch = epoch,
                totalEpochs = session.plannedEpochs,
                phaseStepIndex = batchIndex,
                phaseStepTotal = batchesInEpoch,
                unitsCompleted = batchesRun,
                totalUnits = totalUnits,
                latestLoss = loss,
                imagesPerSecond = imagesPerSecond.toFloat(),
                estimatedSecondsRemaining = etaSeconds,
                memoryUsedMb = ram.totalRamMb - ram.availableRamMb,
                status = TrainingStatus.RUNNING
            )
        )
    }

    /**
     * A setup stage with nothing to count yet ([TrainingPhase.PREPARING]): the Train AI screen and the notification
     * show [note] with an indeterminate bar, so there is always a visible sign of what the session is doing between
     * "Start" and the first batch (dataset analysis and model loading can take a while).
     */
    private fun publishPreparing(sessionId: Long, totalEpochs: Int, note: String) {
        val ram = deviceCapabilities.snapshot()
        progressPublisher.publish(
            TrainingProgressState(
                sessionId = sessionId,
                phase = TrainingPhase.PREPARING,
                epoch = 0,
                totalEpochs = totalEpochs,
                phaseStepIndex = 0,
                phaseStepTotal = 0,
                unitsCompleted = 0,
                totalUnits = 0,
                latestLoss = null,
                imagesPerSecond = 0f,
                estimatedSecondsRemaining = -1L,
                memoryUsedMb = ram.totalRamMb - ram.availableRamMb,
                status = TrainingStatus.RUNNING,
                note = note
            )
        )
    }

    /** Shows why training is waiting, keeping the progress made so far when there is any. */
    private fun publishWaiting(session: TrainingSessionEntity, note: String) {
        val previous = progressPublisher.progress.value
        if (previous != null && previous.sessionId == session.id && previous.phase == TrainingPhase.TRAINING) {
            progressPublisher.publish(previous.copy(note = note))
        } else {
            publishPreparing(session.id, session.plannedEpochs, note)
        }
    }

    /**
     * Polls the governor while it says PAUSE (almost no free RAM, or the phone is overheating), up to
     * [THROTTLE_WAIT_MAX_MS]. Returns the last decision: no longer PAUSE when the condition cleared, still PAUSE when
     * it did not, or when a pause/cancel was requested in the meantime (the caller checks [control] first).
     */
    private suspend fun waitOutPause(
        session: TrainingSessionEntity,
        first: ThermalGovernor.ThrottleDecision,
        threadCeiling: Int,
        control: TrainingControlFlow
    ): ThermalGovernor.ThrottleDecision {
        var decision = first
        var waitedMs = 0L
        while (decision.action == ThermalGovernor.ThrottleAction.PAUSE && !control.stopRequested && waitedMs < THROTTLE_WAIT_MAX_MS) {
            publishWaiting(session, "Waiting because ${decision.reason ?: "the phone needs a moment"}…")
            delay(THROTTLE_WAIT_POLL_MS)
            waitedMs += THROTTLE_WAIT_POLL_MS
            decision = thermalGovernor.evaluate(concurrencyCeiling = threadCeiling)
        }
        return decision
    }

    /**
     * Called when [runSession] is leaving through an exception: whatever session row still says RUNNING is no longer
     * running. A cancellation becomes PAUSED (resumable) - or CANCELLED when the user asked for that - and a crash
     * becomes FAILED with its message.
     */
    private suspend fun settleInterruptedSession(control: TrainingControlFlow, failure: Throwable?) {
        val stale = trainingSessionDao.findLatestWithStatus(TrainingStatus.RUNNING) ?: return
        val status = when {
            failure != null -> TrainingStatus.FAILED
            control.command.value == TrainingCommand.CANCEL -> TrainingStatus.CANCELLED
            else -> TrainingStatus.PAUSED
        }
        trainingSessionDao.update(
            stale.copy(
                status = status,
                completedAt = if (status == TrainingStatus.PAUSED) stale.completedAt else System.currentTimeMillis(),
                failureReason = failure?.let { it.message ?: it::class.simpleName } ?: stale.failureReason
            )
        )
        progressPublisher.updateStatus(status)
        NovaLog.i(TAG, "Session ${stale.id} was interrupted mid-run; recorded as $status")
    }

    /**
     * Publishes a progress update for the SAVING_CHECKPOINT/VALIDATING tail
     * that follows the batch loop. Unlike [publishProgress] there's no
     * meaningful images/sec or ETA for these phases (a checkpoint write and
     * a validation pass aren't "batches"), so those are left at their
     * "unknown" values - [com.novaenhance.ai.ui.components.TrainingProgressCard]
     * already falls back to "Calculating…" for a negative ETA. [epoch]/
     * [TrainingProgressState.totalEpochs] and the previous phase's step
     * counts carry over from whatever was last published rather than being
     * reset to 0, purely so the data class doesn't hold misleading zeros -
     * the UI branches on [phase] before reading them.
     */
    private fun publishPhase(
        session: TrainingSessionEntity,
        phase: TrainingPhase,
        phaseStepIndex: Int,
        phaseStepTotal: Int,
        unitsCompleted: Int,
        totalUnits: Int,
        lastKnownLoss: Float?
    ) {
        val ram = deviceCapabilities.snapshot()
        val previous = progressPublisher.progress.value
        progressPublisher.publish(
            TrainingProgressState(
                sessionId = session.id,
                phase = phase,
                epoch = previous?.epoch ?: (session.plannedEpochs - 1).coerceAtLeast(0),
                totalEpochs = session.plannedEpochs,
                phaseStepIndex = phaseStepIndex,
                phaseStepTotal = phaseStepTotal,
                unitsCompleted = unitsCompleted,
                totalUnits = totalUnits,
                latestLoss = lastKnownLoss,
                imagesPerSecond = 0f,
                estimatedSecondsRemaining = -1L,
                memoryUsedMb = ram.totalRamMb - ram.availableRamMb,
                status = TrainingStatus.RUNNING
            )
        )
    }

    /**
     * How many real (non-replay) training pairs land in one batch once
     * replay blending sets aside [replayFraction] of each batch. Shared by
     * [buildBatches] (which uses it to build each epoch's actual chunks),
     * the batches-per-epoch prediction in [runSession] (for totalPlannedBatches/
     * totalUnits), and [loadEngineForSession]'s check that a resumed
     * checkpoint's recorded batching still matches the current plan - all
     * three previously risked computing this independently and drifting
     * apart whenever replayFraction > 0, since the actual chunk count
     * depends on realPerBatch, not plan.batchSize directly.
     */
    private fun realPairsPerBatch(batchSize: Int, replayFraction: Float): Int {
        val replayPerBatch = (batchSize * replayFraction).toInt().coerceIn(0, batchSize - 1)
        return (batchSize - replayPerBatch).coerceAtLeast(1)
    }

    /** Builds batches mixing real training pairs with a fraction drawn from the anti-forgetting replay buffer. */
    private suspend fun buildBatches(
        trainPairs: List<DatasetPairEntity>,
        batchSize: Int,
        replayFraction: Float,
        modelId: String
    ): List<List<Pair<String, String>>> {
        val realPerBatch = realPairsPerBatch(batchSize, replayFraction)
        val replayPerBatch = batchSize - realPerBatch

        val realChunks = trainPairs.map { it.lowQualityPath to it.highQualityPath }.chunked(realPerBatch)
        return realChunks.map { chunk ->
            val replaySample = if (replayPerBatch > 0) {
                experienceMemory.sample(modelId, replayPerBatch).map { it.lowQualityPath to it.highQualityPath }
            } else {
                emptyList()
            }
            chunk + replaySample
        }
    }
}
