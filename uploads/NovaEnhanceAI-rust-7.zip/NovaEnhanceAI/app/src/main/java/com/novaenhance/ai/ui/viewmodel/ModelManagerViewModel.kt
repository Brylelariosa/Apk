package com.novaenhance.ai.ui.viewmodel

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.novaenhance.ai.ai.model.ModelImportException
import com.novaenhance.ai.ai.model.ModelRepository
import com.novaenhance.ai.database.dao.ModelDao
import com.novaenhance.ai.database.dao.ModelVersionDao
import com.novaenhance.ai.database.entities.ModelEntity
import com.novaenhance.ai.database.entities.ModelVersionEntity
import com.novaenhance.ai.storage.AppStorage
import com.novaenhance.ai.utils.NovaLog
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID

private const val TAG = "ModelManagerVM"

// A real model bundle is about half a megabyte; refuse to copy anything wildly bigger into the cache.
private const val MAX_IMPORT_BYTES = 64L * 1024L * 1024L

data class ModelManagerUiState(
    val models: List<ModelEntity> = emptyList(),
    val selectedModelId: String? = null,
    val versionsForSelected: List<ModelVersionEntity> = emptyList()
)

class ModelManagerViewModel(
    private val appContext: Context,
    private val modelDao: ModelDao,
    private val modelVersionDao: ModelVersionDao,
    private val modelRepository: ModelRepository,
    private val storage: AppStorage
) : ViewModel() {

    private val selectedModelId = MutableStateFlow<String?>(null)

    val uiState: StateFlow<ModelManagerUiState> = combine(
        modelDao.observeAll(),
        selectedModelId
    ) { models, selectedId -> Pair(models, selectedId ?: models.firstOrNull()?.id) }
        .flatMapLatest { (models, selectedId) ->
            if (selectedId == null) {
                flowOf(ModelManagerUiState(models = models))
            } else {
                modelVersionDao.observeForModel(selectedId).map { versions ->
                    ModelManagerUiState(
                        models = models,
                        selectedModelId = selectedId,
                        versionsForSelected = versions
                    )
                }
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ModelManagerUiState())

    private val _message = MutableStateFlow<String?>(null)

    /** One line about how the last action went (success or failure); shown once, then cleared with [clearMessage]. */
    val message: StateFlow<String?> = _message.asStateFlow()

    private val _isBusy = MutableStateFlow(false)

    /** True while an action is running; the screen disables its buttons so a double tap can't start two. */
    val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

    fun clearMessage() {
        _message.value = null
    }

    /**
     * Runs one user-visible action. Anything that goes wrong becomes a message on screen - these actions used to
     * run in a bare `launch`, where an exception (a missing file, a damaged import) took the whole app down.
     */
    private fun runOperation(failurePrefix: String, block: suspend () -> Unit) {
        if (_isBusy.value) return
        viewModelScope.launch {
            _isBusy.value = true
            try {
                block()
            } catch (e: CancellationException) {
                throw e
            } catch (t: Throwable) {
                NovaLog.w(TAG, failurePrefix, t)
                _message.value = if (t is ModelImportException) {
                    t.message ?: failurePrefix
                } else {
                    "$failurePrefix: ${t.message ?: t::class.java.simpleName}"
                }
            } finally {
                _isBusy.value = false
            }
        }
    }

    fun selectModel(modelId: String) {
        selectedModelId.value = modelId
    }

    fun switchActive(modelId: String) = runOperation("Couldn't switch models") {
        modelRepository.switchActiveModel(modelId)
    }

    fun renameModel(modelId: String, newName: String) = viewModelScope.launch { modelRepository.renameModel(modelId, newName) }

    fun deleteModel(modelId: String) = runOperation("Couldn't delete the model") {
        modelRepository.deleteModel(modelId)
        if (selectedModelId.value == modelId) selectedModelId.value = null
    }

    fun restoreVersion(modelId: String, versionId: Long) = runOperation("Couldn't restore that version") {
        modelRepository.restoreVersion(modelId, versionId)
        _message.value = "Version restored - it is now the one in use."
    }

    fun deleteVersion(versionId: Long) = runOperation("Couldn't delete that version") {
        val deleted = modelRepository.deleteVersion(versionId)
        if (!deleted) _message.value = "That version can't be deleted: it is the one in use, or the original."
    }

    /** Packages the model's version in use as a `.novamodel` file and hands it to [onReady] (to open the share sheet). */
    fun shareModel(modelId: String, onReady: (File) -> Unit) = runOperation("Couldn't prepare the model file") {
        val version = modelVersionDao.getActiveVersion(modelId) ?: error("This model has no saved version yet")
        onReady(modelRepository.exportVersion(version.id))
    }

    /** Same as [shareModel], for one specific entry of the version history. */
    fun shareVersion(versionId: Long, onReady: (File) -> Unit) = runOperation("Couldn't prepare the model file") {
        onReady(modelRepository.exportVersion(versionId))
    }

    /** Copies one version, as a `.novamodel` file, into the phone's Downloads folder. */
    fun saveVersionToDownloads(versionId: Long) = runOperation("Couldn't save the file") {
        val file = modelRepository.exportVersion(versionId)
        val saved = withContext(Dispatchers.IO) { storage.saveModelBundleToDownloads(file, file.name) }
        _message.value = if (saved != null) {
            "Saved to Downloads/NovaEnhance/${file.name}"
        } else {
            "Couldn't save the file to Downloads."
        }
    }

    /** Imports a `.novamodel` file the person picked and makes the model in it the active one. */
    fun importModel(bundleUri: Uri) = runOperation("Couldn't import the model") {
        val tempFile = File(appContext.cacheDir, "import_${System.currentTimeMillis()}.novamodel")
        try {
            withContext(Dispatchers.IO) {
                val input = appContext.contentResolver.openInputStream(bundleUri)
                    ?: throw ModelImportException("That file couldn't be opened.")
                input.use { source -> tempFile.outputStream().use { sink -> copyWithLimit(source, sink) } }
            }
            val modelId = "imported_${UUID.randomUUID().toString().take(8)}"
            val model = modelRepository.importModel(tempFile, modelId)
            _message.value = "Imported “${model.displayName}”. It is now your active model."
        } finally {
            tempFile.delete()
        }
    }

    private fun copyWithLimit(input: InputStream, output: OutputStream) {
        val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
        var total = 0L
        while (true) {
            val read = input.read(buffer)
            if (read < 0) break
            total += read
            if (total > MAX_IMPORT_BYTES) throw ModelImportException("That file is too big to be a NovaEnhance model.")
            output.write(buffer, 0, read)
        }
    }
}
