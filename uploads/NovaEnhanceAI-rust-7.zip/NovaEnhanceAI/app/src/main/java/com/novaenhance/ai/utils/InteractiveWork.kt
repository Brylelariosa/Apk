package com.novaenhance.ai.utils

import java.util.concurrent.atomic.AtomicInteger

/**
 * Counts the user-facing image-processing requests that are running or waiting right now (an Enhance tap, a batch
 * job). Background training reads it through [ThermalGovernor.evaluate]'s `yieldToInteractive` flag and drops to
 * [Constants.THREADS_WHILE_INTERACTIVE_WORK_RUNS] native threads while it is non-zero, so a training session that
 * has been using most of the cores does not slow the photo the user is waiting for.
 *
 * Only a counter: nothing here blocks or schedules anything, and a leaked count can at worst keep training on two
 * threads until the process ends.
 */
object InteractiveWork {
    private val active = AtomicInteger(0)

    fun enter() {
        active.incrementAndGet()
    }

    fun exit() {
        active.updateAndGet { if (it > 0) it - 1 else 0 }
    }

    val isActive: Boolean
        get() = active.get() > 0
}
