package com.novaenhance.ai.ai.model

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ModelMetadataTrainingStatsTest {

    @Test
    fun `training statistics survive a json round trip`() {
        val original = ModelMetadata(
            modelName = "General Photo AI",
            parameterCount = 44211,
            versionNumber = 4,
            trainingSessionCount = 6,
            totalImagesLearned = 240,
            improvementScore = 41.5f,
            lastTrainedAt = 1_730_000_000_000L
        )

        assertEquals(original, ModelMetadata.fromJson(original.toJson()))
    }

    @Test
    fun `a bundle written before the statistics existed still reads, with zeros`() {
        val parsed = ModelMetadata.fromJson("""{"modelName":"Old","parameterCount":44211,"versionNumber":2}""")

        assertEquals("Old", parsed.modelName)
        assertEquals(0, parsed.trainingSessionCount)
        assertEquals(0, parsed.totalImagesLearned)
        assertEquals(0f, parsed.improvementScore, 0f)
        assertNull(parsed.lastTrainedAt)
    }

    @Test
    fun `an empty object is accepted so a hand-made bundle can still be imported`() {
        val parsed = ModelMetadata.fromJson("{}")

        assertEquals("Imported model", parsed.modelName)
        assertEquals(1, parsed.versionNumber)
    }
}
