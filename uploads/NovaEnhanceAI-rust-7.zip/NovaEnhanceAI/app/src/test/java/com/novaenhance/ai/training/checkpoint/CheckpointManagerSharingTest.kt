package com.novaenhance.ai.training.checkpoint

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.io.File
import java.io.IOException
import java.nio.file.Files

/** Sharing a trained model: exporting a version that has no metadata file, and importing what arrives. */
class CheckpointManagerSharingTest {

    private lateinit var tempDir: File
    private lateinit var manager: CheckpointManager

    @Before
    fun setUp() {
        tempDir = Files.createTempDirectory("nova_checkpoint_sharing_test").toFile()
        manager = CheckpointManager()
    }

    @Test
    fun `a version with no metadata file exports from json text and imports back exactly`() {
        // Versions written by training have a .weights file and NO sidecar .json - the case that used to fail.
        val weights = File(tempDir, "v3.weights").apply { writeBytes(ByteArray(64) { (it * 3).toByte() }) }
        assertFalse(File(tempDir, "v3.json").exists())
        val json = """{"modelName":"Mine","parameterCount":44211,"versionNumber":3}"""

        val bundle = File(tempDir, "out/Mine_v3.novamodel")
        manager.exportBundle(weights, json, bundle)
        assertTrue(bundle.exists())

        val imported = manager.importBundle(bundle, File(tempDir, "phone-b"), versionNumber = 1)
        assertArrayEquals(weights.readBytes(), imported.weightsFile.readBytes())
        assertEquals(json, imported.metadataFile.readText())
    }

    @Test
    fun `a bundle without metadata still imports and gets minimal metadata`() {
        val weights = File(tempDir, "v1.weights").apply { writeBytes(byteArrayOf(1, 2, 3)) }
        val bundle = File(tempDir, "no-meta.novamodel")
        java.util.zip.ZipOutputStream(bundle.outputStream()).use { zip ->
            zip.putNextEntry(java.util.zip.ZipEntry("model.weights"))
            zip.write(weights.readBytes())
            zip.closeEntry()
        }

        val imported = manager.importBundle(bundle, File(tempDir, "dest"), versionNumber = 1)

        assertArrayEquals(byteArrayOf(1, 2, 3), imported.weightsFile.readBytes())
        assertTrue(imported.metadataFile.readText().contains("\"versionNumber\":1"))
    }

    @Test
    fun `a file that is not a model bundle is refused`() {
        val notABundle = File(tempDir, "photo.jpg").apply { writeText("definitely not a zip") }

        assertThrows(IllegalArgumentException::class.java) {
            manager.importBundle(notABundle, File(tempDir, "dest2"), versionNumber = 1)
        }
    }

    @Test
    fun `a failed export leaves no half-written bundle behind`() {
        val bundle = File(tempDir, "broken.novamodel")

        assertThrows(IOException::class.java) {
            manager.exportBundle(File(tempDir, "does-not-exist.weights"), "{}", bundle)
        }

        assertFalse(bundle.exists())
        assertFalse(File(tempDir, "broken.novamodel.tmp").exists())
    }

    @Test
    fun `exporting again over an existing bundle replaces it`() {
        val weights = File(tempDir, "v2.weights").apply { writeBytes(byteArrayOf(5, 5, 5)) }
        val bundle = File(tempDir, "again.novamodel")

        manager.exportBundle(weights, "{}", bundle)
        weights.writeBytes(byteArrayOf(6, 6, 6, 6))
        manager.exportBundle(weights, "{}", bundle)

        val imported = manager.importBundle(bundle, File(tempDir, "dest3"), versionNumber = 1)
        assertArrayEquals(byteArrayOf(6, 6, 6, 6), imported.weightsFile.readBytes())
    }
}
