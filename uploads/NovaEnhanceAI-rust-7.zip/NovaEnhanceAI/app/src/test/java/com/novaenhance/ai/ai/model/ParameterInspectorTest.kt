package com.novaenhance.ai.ai.model

import com.novaenhance.ai.ai.engine.NativeNeuralEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test

class ParameterInspectorTest {

    @Test
    fun `the layout adds up to the parameter count of the Rust network`() {
        assertEquals(NativeNeuralEngine.TOTAL_PARAMS, ParameterLayout.total)
    }

    @Test
    fun `segment offsets and sizes match the constants in rust nn mod rs`() {
        // W1 B1 W2 B2 W3 B3 W4 B4
        assertEquals(listOf(0, 1296, 1344, 22080, 22128, 42864, 42912, 44208), ParameterLayout.segments.map { it.offset })
        assertEquals(listOf(1296, 48, 20736, 48, 20736, 48, 1296, 3), ParameterLayout.segments.map { it.size })
    }

    @Test
    fun `weights and biases of a layer are adjacent and layerRange spans both`() {
        for (layer in 1..ParameterLayout.LAYER_COUNT) {
            val w = ParameterLayout.weights(layer)
            val b = ParameterLayout.biases(layer)
            assertEquals(w.offset + w.size, b.offset)
            val range = ParameterLayout.layerRange(layer)
            assertEquals(w.offset, range.first)
            assertEquals(b.offset + b.size - 1, range.last)
        }
        assertEquals(1344, ParameterLayout.layerRange(2).first)
        assertEquals(22127, ParameterLayout.layerRange(2).last)
    }

    @Test
    fun `describe addresses a parameter by layer, filter tap and channels`() {
        assertEquals("L1 w tap0 in0 out0", ParameterLayout.describe(0))
        assertEquals("L1 w tap8 in2 out47", ParameterLayout.describe(1295))
        assertEquals("L1 bias out7", ParameterLayout.describe(1296 + 7))
        // layer 2 weights start at 1344; tap 4, in 12, out 30 -> 1344 + 4 * 2304 + 12 * 48 + 30
        assertEquals("L2 w tap4 in12 out30", ParameterLayout.describe(1344 + 4 * 2304 + 12 * 48 + 30))
        assertEquals("L4 bias out2", ParameterLayout.describe(ParameterLayout.total - 1))
    }

    @Test
    fun `describe rejects an index outside the model`() {
        assertThrows(IllegalArgumentException::class.java) { ParameterLayout.describe(ParameterLayout.total) }
        assertThrows(IllegalArgumentException::class.java) { ParameterLayout.describe(-1) }
    }

    @Test
    fun `inspect computes the basic statistics of each segment`() {
        val values = FloatArray(ParameterLayout.total) { 0.5f }
        val w1 = ParameterLayout.weights(1)
        for (i in 0 until w1.size) values[w1.offset + i] = if (i % 2 == 0) 1f else -1f

        val snapshot = ParameterInspector.inspect(values, adamStep = 7)

        val stats = snapshot.statsFor(w1)
        assertEquals(-1f, stats.min, 0f)
        assertEquals(1f, stats.max, 0f)
        assertEquals(0f, stats.mean, 1e-6f)
        assertEquals(1f, stats.std, 1e-6f)
        assertEquals(1f, stats.rms, 1e-6f)
        assertEquals(1f, stats.maxAbs, 0f)
        assertEquals(0f, stats.nearZeroFraction, 0f)
        assertEquals(w1.size, stats.histogram.sum())
        assertEquals(7, snapshot.adamStep)
        assertEquals(ParameterLayout.total, snapshot.parameterCount)

        // A segment where every value is the same has no spread, and still lands every value in the histogram.
        val b1 = snapshot.statsFor(ParameterLayout.biases(1))
        assertEquals(0.5f, b1.mean, 1e-6f)
        assertEquals(0f, b1.std, 1e-6f)
        assertEquals(ParameterLayout.biases(1).size, b1.histogram.sum())
    }

    @Test
    fun `an all-zero model is handled without dividing by zero`() {
        val snapshot = ParameterInspector.inspect(FloatArray(ParameterLayout.total), adamStep = 0)
        val stats = snapshot.statsFor(ParameterLayout.weights(2))
        assertEquals(0f, stats.maxAbs, 0f)
        assertEquals(1f, stats.nearZeroFraction, 0f)
        assertEquals(ParameterLayout.weights(2).size, stats.histogram.sum())
    }

    @Test
    fun `inspect rejects a vector of the wrong size`() {
        assertThrows(IllegalArgumentException::class.java) { ParameterInspector.inspect(FloatArray(10), 0) }
    }

    @Test
    fun `fingerprint is stable and changes when a single weight changes`() {
        val a = FloatArray(ParameterLayout.total) { it * 0.001f }
        val b = a.copyOf()
        assertEquals(ParameterInspector.fingerprint(a), ParameterInspector.fingerprint(b))

        b[12345] += 0.0001f
        assertNotEquals(ParameterInspector.fingerprint(a), ParameterInspector.fingerprint(b))
        assertTrue(Regex("[0-9A-F]{4}-[0-9A-F]{4}").matches(ParameterInspector.fingerprint(a)))
    }
}
