package com.novaenhance.ai.utils

import org.junit.After
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.util.concurrent.CountDownLatch
import kotlin.concurrent.thread

/**
 * [InteractiveWork] is process-wide state, so every test starts from, and leaves behind, an idle counter (the
 * counter never goes below zero, so draining it with extra `exit()` calls is always safe).
 */
class InteractiveWorkTest {

    private fun drain() = repeat(64) { InteractiveWork.exit() }

    @Before
    fun idleBefore() = drain()

    @After
    fun idleAfter() = drain()

    @Test
    fun `idle until a request enters`() {
        assertFalse(InteractiveWork.isActive)
        InteractiveWork.enter()
        assertTrue(InteractiveWork.isActive)
        InteractiveWork.exit()
        assertFalse(InteractiveWork.isActive)
    }

    @Test
    fun `stays active until every overlapping request has left`() {
        InteractiveWork.enter()
        InteractiveWork.enter()
        InteractiveWork.exit()
        assertTrue("one request is still running", InteractiveWork.isActive)
        InteractiveWork.exit()
        assertFalse(InteractiveWork.isActive)
    }

    @Test
    fun `an unmatched exit cannot hide the next request`() {
        InteractiveWork.exit()
        InteractiveWork.exit()
        assertFalse(InteractiveWork.isActive)
        InteractiveWork.enter()
        assertTrue("a count that went negative would report idle here", InteractiveWork.isActive)
    }

    @Test
    fun `enters and exits from many threads balance out`() {
        val threads = 8
        val pairsPerThread = 2_000
        val start = CountDownLatch(1)
        val workers = List(threads) {
            thread {
                start.await()
                repeat(pairsPerThread) {
                    InteractiveWork.enter()
                    InteractiveWork.exit()
                }
            }
        }
        start.countDown()
        workers.forEach { it.join() }
        assertFalse(InteractiveWork.isActive)
    }
}
