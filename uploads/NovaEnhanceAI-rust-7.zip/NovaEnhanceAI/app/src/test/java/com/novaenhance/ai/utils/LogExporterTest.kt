package com.novaenhance.ai.utils

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.TimeZone

/**
 * The parts of [LogExporter] that need no phone: the file name, the text of the file and the message shown after a
 * save. (Writing into Download/NovaEnhance goes through MediaStore and can only be tried on a device.)
 */
class LogExporterTest {

    private val utc = TimeZone.getTimeZone("UTC")
    private val manila = TimeZone.getTimeZone("Asia/Manila")

    // 2026-11-26 05:35:02 UTC, which is 13:35:02 in Manila (UTC+8).
    private val sample = 1_795_671_302_000L

    private fun file(
        debugInfo: String = "DEBUG-BODY",
        crashLog: String = "CRASH-BODY",
        previousRunLog: String = "PREVIOUS-BODY",
        thisRunLog: String = "THIS-BODY"
    ) = LogExporter.compose("2026-11-26 13:35:02", debugInfo, crashLog, previousRunLog, thisRunLog)

    // ------------------------------------------------------------------------------------------ file name

    @Test
    fun `file name carries the local time to the second`() {
        assertEquals("NovaEnhance-logs-20261126-053502.txt", LogExporter.fileName(sample, utc))
        assertEquals("NovaEnhance-logs-20261126-133502.txt", LogExporter.fileName(sample, manila))
    }

    @Test
    fun `file name has only characters every file manager accepts`() {
        val name = LogExporter.fileName(sample, manila)
        assertTrue(name, Regex("[A-Za-z0-9._-]+").matches(name))
        assertTrue(name.endsWith(".txt"))
    }

    @Test
    fun `file names sort in the order the files were saved`() {
        val times = listOf(sample, sample + 1_000L, sample + 61_000L, sample + 86_400_000L)
        val names = times.map { LogExporter.fileName(it, utc) }
        assertEquals(names.sorted(), names)
        assertEquals(names.size, names.toSet().size)
    }

    // ------------------------------------------------------------------------------------------ the text

    @Test
    fun `the four parts come in order, each under its own heading`() {
        val text = file()
        val positions = listOf("PART 1:", "DEBUG-BODY", "PART 2:", "CRASH-BODY", "PART 3:", "PREVIOUS-BODY", "PART 4:", "THIS-BODY")
            .map { text.indexOf(it) }
        assertTrue("every part is present: $positions", positions.all { it >= 0 })
        assertEquals("in order", positions.sorted(), positions)
    }

    @Test
    fun `the file says when it was saved`() {
        assertTrue(file().contains("Saved: 2026-11-26 13:35:02"))
    }

    @Test
    fun `a part with nothing in it keeps its heading and says so`() {
        val text = file(previousRunLog = "", crashLog = "   \n\n")
        assertTrue(text.contains("PART 2:"))
        assertTrue(text.contains("PART 3:"))
        assertEquals("parts 2 and 3 are empty", 2, Regex("\\(nothing recorded\\)").findAll(text).count())
        assertTrue("the others are untouched", text.contains("DEBUG-BODY") && text.contains("THIS-BODY"))
    }

    @Test
    fun `trailing blank lines of a part do not pile up`() {
        val text = file(debugInfo = "first line\nlast line\n\n\n\n")
        assertTrue(text.contains("last line\n\n====="))
        assertFalse(text.contains("last line\n\n\n"))
    }

    @Test
    fun `nothing is cut from a large log`() {
        val big = buildString { repeat(20_000) { appendLine("12:00:00.000 I/Tag: line number $it of a long run") } }
        val text = file(thisRunLog = big)
        assertTrue(text.contains("line number 0 of a long run"))
        assertTrue(text.contains("line number 19999 of a long run"))
        assertTrue(text.length > big.length)
    }

    // ------------------------------------------------------------------------------------------ the message

    @Test
    fun `the saved message says which folder and which file`() {
        val message = LogExporter.describe(LogExporter.Result.Saved("NovaEnhance-logs-20261126-133502.txt"))
        assertEquals("Logs saved to Downloads/NovaEnhance/NovaEnhance-logs-20261126-133502.txt", message)
    }

    @Test
    fun `the failure message gives the reason`() {
        val message = LogExporter.describe(LogExporter.Result.Failed("Android would not create the file in Downloads"))
        assertTrue(message, message.startsWith("Could not save the logs"))
        assertTrue(message, message.contains("Android would not create the file in Downloads"))
    }
}
