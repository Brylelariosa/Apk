package com.novaenhance.ai.utils

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ComputeBudgetTest {

    private fun ram(totalMb: Long, availableMb: Long, low: Boolean = false) =
        ComputeBudget.RamInfo(totalMb, availableMb, low)

    // ---------------------------------------------------------------------------------------- band pixels

    @Test
    fun `without RAM information the old fixed band size is used`() {
        assertEquals(Constants.BAND_PIXELS_LOW_RAM, ComputeBudget.maxBandPixels(null))
        assertEquals(800_000, Constants.BAND_PIXELS_LOW_RAM)
    }

    @Test
    fun `a 4 GB phone gets the conservative 4 GB tier and is capped by what is free`() {
        // Android reports ~3.7 GB for a "4 GB" phone.
        assertEquals(1_400_000, ComputeBudget.maxBandPixels(ram(3_700, 1_500)))
        // Plenty free: the tier itself.
        assertEquals(Constants.BAND_PIXELS_4GB, ComputeBudget.maxBandPixels(ram(3_700, 3_000)))
        // Short of memory: smaller, never below the floor.
        assertEquals(700_000, ComputeBudget.maxBandPixels(ram(3_700, 800)))
        assertEquals(Constants.MIN_BAND_PIXELS, ComputeBudget.maxBandPixels(ram(3_700, 100)))
    }

    @Test
    fun `6 GB and 8 GB phones get bigger bands`() {
        assertEquals(Constants.BAND_PIXELS_6GB, ComputeBudget.maxBandPixels(ram(5_600, 4_000)))
        assertEquals(Constants.BAND_PIXELS_8GB, ComputeBudget.maxBandPixels(ram(7_600, 6_000)))
        assertTrue(Constants.BAND_PIXELS_4GB < Constants.BAND_PIXELS_6GB)
        assertTrue(Constants.BAND_PIXELS_6GB < Constants.BAND_PIXELS_8GB)
    }

    @Test
    fun `a low-RAM device never goes above the old fixed band size`() {
        assertEquals(Constants.BAND_PIXELS_LOW_RAM, ComputeBudget.maxBandPixels(ram(2_000, 1_200)))
        assertEquals(Constants.BAND_PIXELS_LOW_RAM, ComputeBudget.maxBandPixels(ram(7_600, 6_000, low = true)))
    }

    @Test
    fun `the band size never drops below the floor and is a multiple of 50000`() {
        for (total in listOf(1_000L, 2_000L, 3_700L, 5_600L, 7_600L, 12_000L)) {
            for (free in listOf(0L, 50L, 300L, 1_000L, 2_500L, 6_000L)) {
                val px = ComputeBudget.maxBandPixels(ram(total, free))
                assertTrue("total $total free $free -> $px", px >= Constants.MIN_BAND_PIXELS)
                assertTrue("total $total free $free -> $px", px <= Constants.BAND_PIXELS_8GB)
                assertEquals(0, px % 50_000)
            }
        }
    }

    // ---------------------------------------------------------------------------------------- chunk / band rows
    // The first three mirror the Rust test `chunks_always_get_room_for_their_context` (rust/src/enhance/session.rs).

    @Test
    fun `chunk rows match the native side`() {
        assertEquals(162, ComputeBudget.chunkCoreRows(800_000, 4000, 19))
        assertEquals(520, ComputeBudget.chunkCoreRows(50_000, 96, 0))
        assertEquals(114, ComputeBudget.chunkCoreRows(800_000, 8000, 57))
    }

    @Test
    fun `a chunk always has room for its context`() {
        for (px in listOf(1, 50_000, 800_000, 4_000_000)) {
            for (w in listOf(1, 96, 4000, 8000, 30_000)) {
                for (halo in listOf(0, 4, 19, 57, 200)) {
                    val core = ComputeBudget.chunkCoreRows(px, w, halo)
                    assertTrue("px $px w $w halo $halo core $core", core >= maxOf(16, 2 * halo))
                }
            }
        }
    }

    @Test
    fun `a band is a whole number of chunks and keeps its granularity`() {
        // Chunk smaller than the traditional 256-row band: a whole number of chunks fits in it.
        assertEquals(228, ComputeBudget.bandRowsFor(8000, 57, 800_000)) // chunk 114 -> 2 chunks
        assertEquals(162, ComputeBudget.bandRowsFor(4000, 19, 800_000)) // chunk 162 -> 1 chunk
        // Chunk bigger than 256 rows: the band is the chunk, up to twice the traditional height.
        assertEquals(337, ComputeBudget.bandRowsFor(4000, 19, 1_500_000))
        assertEquals(512, ComputeBudget.bandRowsFor(4000, 19, 4_000_000))
        for (px in listOf(400_000, 800_000, 1_500_000, 4_000_000)) {
            for (w in listOf(640, 4000, 8000, 12_000)) {
                for (halo in listOf(0, 4, 19, 57)) {
                    val rows = ComputeBudget.bandRowsFor(w, halo, px)
                    val core = ComputeBudget.chunkCoreRows(px, w, halo)
                    assertTrue(rows > 0 && rows <= 2 * Constants.BAND_ROWS_PX)
                    assertTrue("rows $rows core $core", rows % core == 0 || rows == core.coerceAtMost(2 * Constants.BAND_ROWS_PX))
                }
            }
        }
    }

    // ---------------------------------------------------------------------------------------- thermal headroom

    @Test
    fun `no headroom information changes nothing`() {
        assertEquals(8, ComputeBudget.threadsForHeadroom(8, Float.NaN))
        assertEquals(1, ComputeBudget.threadsForHeadroom(1, Float.NaN))
        assertEquals(1, ComputeBudget.threadsForHeadroom(0, Float.NaN))
    }

    @Test
    fun `a cool phone keeps every thread`() {
        assertEquals(8, ComputeBudget.threadsForHeadroom(8, 0.0f))
        assertEquals(8, ComputeBudget.threadsForHeadroom(8, 0.5f))
        assertEquals(8, ComputeBudget.threadsForHeadroom(8, Constants.THERMAL_HEADROOM_EASE_START))
    }

    @Test
    fun `threads are handed back gradually as the phone warms`() {
        val readings = listOf(0.70f, 0.75f, 0.80f, 0.85f, 0.90f, 0.95f, 1.00f, 1.20f)
        val threads = readings.map { ComputeBudget.threadsForHeadroom(8, it) }
        // Never increases as the headroom shrinks, ends at a quarter of the ceiling, and never reaches zero.
        for (i in 1 until threads.size) assertTrue("$threads", threads[i] <= threads[i - 1])
        assertEquals(8, threads.first())
        assertEquals(2, threads.last())
        assertEquals(5, ComputeBudget.threadsForHeadroom(8, 0.85f))
        // Small ceilings stay valid.
        assertEquals(1, ComputeBudget.threadsForHeadroom(1, 2.0f))
        assertEquals(1, ComputeBudget.threadsForHeadroom(2, 2.0f))
        assertEquals(3, ComputeBudget.threadsForHeadroom(4, 0.8f))
    }

    // ---------------------------------------------------------------------------------------- interactive work

    @Test
    fun `interactive work is counted and cannot go negative`() {
        val before = InteractiveWork.isActive
        InteractiveWork.enter()
        assertTrue(InteractiveWork.isActive)
        InteractiveWork.exit()
        assertEquals(before, InteractiveWork.isActive)
        InteractiveWork.exit() // an extra exit must not leave a negative count behind
        InteractiveWork.enter()
        assertTrue(InteractiveWork.isActive)
        InteractiveWork.exit()
        assertTrue(!InteractiveWork.isActive || before)
    }
}
