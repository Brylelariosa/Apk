# What changed in this build (build 16: logs are saved as a file in Downloads; build 15: faster enhancement and training, memory sized to the phone, an Enhance screen with nothing to scroll to; build 14.1: fix for CI run 1987; build 14: reachable buttons, new icon, parameters screen, shareable models; builds 13 / 12.1 / 12 below)

## Build 16: the logs are saved as a file in your Downloads folder (no more copying)
Request: "make the log save in the Download folder, no copy - all logs, crash and debug".

1. **Settings -> Save logs to Downloads** (it replaces *Copy debug info*) writes **one** text file, `NovaEnhance-logs-YYYYMMDD-HHMMSS.txt`, into
   **Download / NovaEnhance** - the same folder exported models already go to. No permission is needed (Android 10+ MediaStore, like the model export),
   every tap makes a new file (nothing is overwritten) and the message on screen names it.
2. The file holds **everything the app keeps**, in four labelled parts: **1** debug info (app, device, `Native kernels:`, RAM, `Enhance band budget:`, heat, recent
   activity), **2** the crash log (last incident, last Java crash, how Android says the recent runs ended), **3** the *full* on-disk log of the previous run and
   **4** the *full* on-disk log of this run. Before, the crash log screen only quoted the last 150 lines of a run, and everything had to fit through the clipboard.
3. **View crash log** has the same button, **Save to Downloads**, where *Copy* was; *Share* and *Clear* stay, and the text on screen can still be selected by hand.
   Its three buttons now use the app's 56 dp button like every other screen (the stock ones were 40 dp and would have come out uneven). The "app stopped
   unexpectedly" prompt now says to tap Save to Downloads.
4. Saving runs off the main thread, a second tap while it is running is ignored (one tap = one file), and if Android refuses, the half-written file is removed and the
   message says why. The file work never throws into the UI.

**Changed files:** new `utils/LogExporter.kt`, `ui/components/SaveLogsAction.kt`, test `LogExporterTest.kt`; `PersistentLog.kt` (+1 accessor for this run's whole log),
`SettingsScreen.kt`, `CrashLogScreen.kt`, `NovaNavHost.kt` (prompt wording), `SettingsViewModel.kt` / `ViewModelFactory.kt` (the copy function and its now-unused
device dependency are gone), doc comments in `DiagnosticsReport.kt` / `NovaLog.kt`. **The Rust crate, the JNI surface, the model format and every enhancement or training
code path are unchanged from build 15.**

**Verification status.** *Checked here:* the new Kotlin compiles with the real Kotlin compiler in 2.0 and 1.9 language modes against Android stand-ins; 10 new unit tests pass (file
name in two time zones, order of the four parts, empty parts, a large log, both messages). *NOT checked here:* the Gradle / Android build and the two Compose screens
(the next CI run is the real check), and the actual write into Downloads - it is the same MediaStore route as the existing model export but has not been run on a phone.
**What to look for on your Infinix:** Settings -> Save logs to Downloads -> a message with the file name -> Files app -> Download -> NovaEnhance. Note that the crash log
still holds the old "recycled bitmap" crash from 2 Oct (fixed in build 8); View crash log -> Clear removes it so it stops appearing in every file.

## Build 15: faster CNN enhancement and training, memory sized to the phone, an Enhance screen with nothing to scroll to
Requests: (1) the performance brief ("make enhancement and training faster on a 4 GB Android 11 phone, without changing results, and
do not invent benchmark numbers") and (2) "improve the UI or buttons - I have to scroll to see them on the Enhance area".

**Headline - measured on a PC, NOT on a phone:** CNN enhancement about **2.7x faster**, CNN training steps about **1.9x faster**, big photos
with only the classic stages **1.6x - 5x faster**, and the output is **byte-for-byte identical** to build 14 in every case compared.
No model file, parameter layout or JNI signature changed: **every `.novamodel` and every saved model loads exactly as before.**
Full report with the audit, every table, what carries over to the phone and what does not: **`docs/PERFORMANCE.md`**; raw runs: `docs/benchmarks/`.

### What changed
1. **A faster convolution kernel that the phone chooses for itself** (`rust/src/nn/kernels.rs`). The CNN's 48 -> 48 layers are about 94 % of its
   work. A second kernel (same arithmetic in the same order, weights laid out as one contiguous stream) is 2.9x faster on the PC. Whether it is faster
   on ARM could not be tested here, so the first time the network runs the phone **times both kernels and keeps the faster one** - only if the new one is
   at least 5 % faster; otherwise the phone runs the old one, exactly like build 14. Both give identical numbers, so this only affects speed.
2. **Big photos no longer re-process the same rows over and over** (`enhance/session.rs`, `ComputeBudget.bandRowsFor`). Every chunk is processed with
   some rows of its neighbours above and below, then those rows are thrown away. On an 8000-px-wide photo with all classic stages on, a chunk
   processed 130 rows to keep 16. Chunks now keep at least as many own rows as context rows, and Kotlin's bands are whole numbers of chunks.
3. **Working memory sized to the phone** (`ComputeBudget.maxBandPixels`, `MemoryStats.ramInfo`). The native working set per chunk used to be 800 000
   pixels on every phone. It is now 800 000 (under ~3 GB or low-RAM flag), 1.5 M ("4 GB" - your Infinix), 2.5 M ("6 GB") or 4 M ("8 GB"), and never more than 5 %
   of the RAM free at that moment. **More memory for the speed:** on the PC a 12 MP photo's native working memory went from 34 MB to 63 MB (CNN profile) and from 43 MB to 81 MB
   (classic stages) with the 4 GB setting - more on bigger tiers (tables in the report). If the RAM cannot be read the old value is used.
4. **Gentler heat handling** (`ThermalGovernor`, `DeviceCapabilities`). On Android 11+ phones that report `getThermalHeadroom`, threads are handed back
   gradually while the phone warms up (all of them up to headroom 0.70, a quarter of them at 1.0) instead of running every core until Android says MODERATE. Phones that do
   not report it behave exactly as before. **The MODERATE / SEVERE / CRITICAL rules and all cool-down lengths are unchanged.**
5. **Training steps aside for Enhance** (`InteractiveWork`, `ModelTrainer`). While you wait for an Enhance (or a batch), background training is limited to 2 threads.
   It never pauses because of this.
6. **Enhance screen: nothing to scroll to.** The preview stays pinned at the top (it no longer scrolls away while you move a slider). The controls sit
   under it in six groups - **Basic** (the four original sliders and 1x / 2x / 4x), **Auto**, **Light**, **Colour**, **Detail**, **Fix** - and a group is never more
   than six one-line sliders. A dot on a chip means something in that group is on. In landscape the preview is on the left and the controls in a column on
   the right. Save / Share (or *Enhance & save all*) stay pinned at the bottom as in build 14. Every control and option is the same as before; only where it sits changed.
7. **Settings -> Copy debug info** now also prints `Native kernels:` (which kernel your phone chose: `.../blocked` or `.../reference`), `Enhance band budget:` and
   `Thermal headroom:` - so you can check all of this on the phone without a PC.
8. **`tools/bench.sh`** (+ `rust/examples/bench.rs`): reproducible benchmarks - on a PC, or on a USB-connected phone with `--target android` - that print
   time, memory, allocations, busy cores, drift and an output checksum, and can run the same case against an older source tree for a side-by-side.

### Looked at and deliberately NOT changed (evidence in the report)
The worker scheduler `par.rs` (thread start-up is about 0.2 % of a CNN run and about 3 % of a classic-only run on the PC), scratch-buffer reuse in the classic stages
(page-fault cost 0.4 % - 3 % of CPU time), the core-count lookup (7 us, once per call), NEON intrinsics / assembly (cannot be tested here, and the phone-side race is the safer way
to pick), a Winograd convolution (1.3x - 1.5x faster than the new kernel on the PC but **not** bit-identical, so it would change results). The training activation workspace was already reused.

### Verification status of this build
* **Checked here:** `cargo test --lib` - **64 tests pass** (the 58 existing plus 6 new: both kernels bit-identical, inference bit-identical to a whole-image reference, identical
  loss and gradient, kernel choice, chunk floor); the output of four profiles with both kernels is identical to build 14's, pixel for pixel; `tools/jni_crosscheck.py` -
  19 / 19 JNI functions match; the Kotlin engine / budget / thermal / diagnostics files compile with the real Kotlin compiler (also in 1.9 language mode) against Android stubs; the new
  Enhance-screen files type-check against hand-written Compose stubs; 16 Kotlin unit tests pass (12 budget, 4 interactive-work); all XML resources parse and every reference resolves.
* **NOT checked here:** the Gradle / Android build and the Compose screens (no SDK in the sandbox - the next CI run is the real check, as for builds 13 and 14), **anything on a phone**
  (ARM speed, which kernel it picks, heat, battery, real memory), and the benchmark script's Android mode.
* **What to look for on your Infinix:** Copy debug info -> `Native kernels:` and `Enhance band budget:`; enhance one big photo and compare the `Processed ... in N ms` line with build 14's. If anything feels
  slower or hotter, the report's section 10 lists one-line switches for each change.

## Build 14.1: fix the CI build (run 1987: the "Rust unit tests" step did not compile)
- **Cause.** `cargo test --lib` stopped the job (Gradle never started). The runner's Rust 1.100 turns the lint
  `dangerous_implicit_autorefs` into a hard error, and the `TestImage` helper in `rust/src/enhance/session.rs` tripped it twice
  (`row` and `write_row` indexed `(*cell.get())[..]`, which implicitly borrows the whole `Vec` on every access). Test code only:
  the library itself, the JNI surface, the network and all Kotlin are unchanged.
- **Fix.** `TestImage` now keeps a raw pointer to its pixels and hands out / writes one row-sized slice at a time, the way the real
  `sys::LockedBitmap` does, so no reference to the whole image is ever created. The old form was also not sound when the two
  worker threads wrote different rows at once.
- **Checked here:** all 58 `cargo test --lib` tests pass (Rust 1.97, 1 / 2 / 8 test threads) and `cargo build --release` of the
  library is clean. Not checked here: the Android targets and everything Gradle / Kotlin (no SDK in the sandbox), so build 14's
  Kotlin is still uncompiled - the next CI run is the check.

## Build 14: buttons you can reach, a new icon, a Parameters screen, and trained models you can send to another phone
Request: "make some buttons easy to click (some need you to scroll to see them), improve the app icon, let me see the
parameters, and let me send the weights as a file so another phone's copy is already trained".
Rust, the network, the checkpoint format and the database are untouched: **every existing `.novamodel` and every saved model
loads exactly as before.** All changes are Kotlin and resources.

### 1. Why "Export" never gave you a file (a real bug, now fixed)
Model Manager's Export/Backup buttons were wired up, but they could not work for any model that had ever been trained:
- A `.novamodel` bundle is weights + a metadata file, and the code read that metadata from a `vN.json` next to the weights.
  Only a model's *first* version ever had one (`createModel` writes it); **every version written by training (v2, v3, ...) has
  none**, so exporting it threw `FileNotFoundException` - inside a bare `launch`, which takes the whole app down.
- Even when it didn't crash, the result was written to the app's private folder and nothing ever shared it or said where it was.

Now: the metadata is generated at export time from the database (name, version, how trained it is), the bundle is written
through a temporary file (a failed export never leaves a half file), and **Share** opens the system share sheet while **Save**
copies the file to `Download/NovaEnhance` (no storage permission needed).

### 2. Sharing a trained model between phones
- **Phone A:** Models -> *Share* on the model (or Parameters -> *Share file*). Send the `.novamodel` file by any app.
- **Phone B:** Models -> *Import model file* (pinned at the bottom) -> pick the file. The model is checked completely first
  (magic, parameter count, checksum, every value finite) and only then registered; it becomes the **active** model at once and is
  named "... (imported)". A damaged or foreign file is refused with a plain message and nothing is left behind (before, a bad
  file crashed the import).
- The training statistics travel with the model (new optional fields in `metadata.json`), so an imported, fully trained model
  does not claim to be "not trained yet" on the Enhance screen. Bundles from older builds import fine (the fields default to 0).
- The **fingerprint** on the Parameters screen (CRC-32 of the weights, `XXXX-XXXX`) is identical on both phones after a transfer.

### 3. Parameters screen (Dashboard -> View parameters, or Models -> Parameters)
Reads the active version's saved weights file (what a share sends, not the live training state):
- model, version, parameter count, file size, training steps, fingerprint;
- per layer: where its parameters sit, a histogram of the weights (middle line = 0), lowest / highest / average / spread of
  weights and biases;
- "What the first layer looks for": the 48 first-layer filters drawn as small RGB tiles (they start random and organise as the
  AI trains - a quick visual check that training did something);
- **All values**: every one of the 44,211 numbers, filterable by layer, each addressed as e.g. `L2 w tap4 in12 out30`;
- *Share file* / *Save to Downloads* pinned at the bottom.
The layout (`ParameterLayout`) mirrors `rust/src/nn/mod.rs`; `ParameterInspectorTest` pins every offset against the Rust constants.

### 4. Buttons that are always on screen (and big)
The rule is now: the action a screen is for lives in a bar pinned to the bottom, and every button is at least 56dp tall.
- **Dashboard:** Enhance Image / Train AI are two big tiles at the very top, Dataset / Models / Settings a row under them;
  the numbers come after. (The buttons used to be the last thing on a scrolling list of eight stat cards.)
- **Enhance:** Save / Share (and *Enhance & save all N photos*, or its progress + Cancel) are pinned; they were under the
  last slider. Upscale 1x/2x/4x are three equal-width buttons.
- **Train AI:** Start / Pause / Resume / Cancel pinned; the page scrolls.
- **Dataset Manager:** Add Pair / Auto-Generate pinned (plus the generation progress and the "pick the matching high-quality
  image" step, which now has a Cancel); the header now scrolls with the list instead of squeezing it.
- **Models:** *Import model file* pinned; each model has Use / Parameters / Share; the four-button row per version (which did
  not fit a phone's width) is now Share / Save / Restore / Delete in equal 48dp buttons. Deleting a model or a version asks first.
- **Settings:** Copy debug info / View crash log pinned; theme choice is three big buttons; a whole setting row toggles, not
  just the small switch.
- Theme: the container colours (selected cards, chips) were Material's default purple; they are teal/amber now.

### 5. New launcher icon
A four-point nova in the app's teal, with the amber pixels of a degraded photo falling away behind it, on the graphite
background with a soft teal glow. Adaptive (vector, no PNGs), with a **themed/monochrome** layer for Android 13+. All of it sits
inside the adaptive-icon safe zone, so no launcher mask clips it. The training notification's status-bar icon is the same star.

### Verification status of this build
No Android SDK, Kotlin compiler or Rust toolchain was available when this was written, so **it has not been compiled**. What was
checked: delimiter balance and string/comment scanning of every changed Kotlin file, that every project import resolves, that
every new external import exists in code the project already compiles or in the pinned Compose/Material3 versions, that every
`R.drawable` reference has a resource, that all XML is well-formed, and the icon's geometry against the safe zone (rendered).
New unit tests: `ParameterInspectorTest`, `ModelMetadataTrainingStatsTest`, `CheckpointManagerSharingTest`. If the first
Gradle build reports an error it will name the file and line - each should be a small fix.


## Build 13: Auto enhance colours, the "training" notification, and a better Auto
Request: "fix auto enhance has weird color and its notification but it's not training and can improve it more".
Network, checkpoint layout and the JNI surface (apart from one new option slot) are unchanged: every trained model still loads.

### 1. Weird colours from Auto enhance
Checked on real photos (old vs new maths side by side): the old Auto turned a coffee cup white-blue, a warm cat photo cold
and magenta, and a face green. Five causes, all fixed:
- **White balance was grey-world, switched on for any cast above 10%.** Almost every natural photo is "more than 10%
  off-grey" (a forest is green, a sunset is orange), so Auto "corrected" real colour at up to 85% strength. Now the cast is
  measured only on *near-neutral* pixels (low saturation, not sky-blue) - their colour is the light's, not the objects' - and
  needs enough of them (confidence ramps from 4% to 16% of the picture). Strongest for mild casts, tapering for large ones
  (more often the scene itself), capped at 60%. Colourful scenes, skies and portraits get no white balance. The manual
  slider still works everywhere (it falls back to grey-world when there are no neutral pixels).
- **The tone curve was applied to R, G and B separately**, which changes their ratios (hue and saturation of every colour
  it touches) and clips one channel before the others. It now acts on **luma**: RGB is scaled to the new luma while it fits
  and then fades toward white, so a bright orange stays orange.
- **Saturation/vibrance could push channels past 255.** The boost is now capped per pixel so no channel leaves 0..255,
  fades out for already-vivid colours, and vibrance is reduced on skin tones. Auto's vibrance is lower (0.12, 0.25 for dull
  pictures, none for vivid ones; was 0.15 / 0.30).
- **Levels used luma for the white point**, so a vivid sunset (luma never high) looked "dull" and was stretched into
  clipping. The white point is now the 99.6th percentile of the *brightest channel*, the stretch is capped at 2x, and levels
  and exposure are solved together so the middle tone is never darkened by a stretch (the old Auto could darken flat scenes).
- Dehaze: the atmospheric-light colour is now mostly neutral (a coloured sky or wall no longer tints the picture); Auto
  dehaze needs real haze (dark channel > 0.38, low saturation).

### 2. "Training" notification without training
Found while reading the whole training path (no phone logs were attached, so these are the causes the code shows):
- **A session could take almost no steps.** 10 pairs, batch of 4 = 3 batches x 2 epochs = **6 optimizer steps**: it finished in
  seconds, changed nothing, and looked like it never trained. The plan now raises the epoch count until a session has at
  least 200 steps (cap: 40 epochs); patches are re-cut at random positions/orientations every epoch, and validation still
  rejects an overfitted model.
- **The governor paused (silently) below 512 MB free RAM**, which a 4 GB phone with a few apps open often is: the notification
  appeared, training stopped, nothing said why. The floor is now 256 MB (batch size already adapts to low memory), and a
  pause is *waited out* (re-checked every 3 s for up to 3 minutes, shown as "Waiting because ..." in the notification and on
  the screen) before the session is left paused with an explanation and a Resume button.
- **Start tapped during the follow-up pass was ignored**: after a session the rescoring pass keeps the service busy for a
  while; tapping Start then replaced the notification with "Starting training session..." and the service did nothing. The
  button now waits ("Finishing the previous run...") and the service keeps showing the real state if it is asked anyway.
- **Cancel from the notification killed the job mid-batch** and left the session marked RUNNING (a Train AI screen with
  Pause/Cancel buttons for a session nothing was running). Cancel now asks the session to stop and it records CANCELLED
  itself; any crash or cancellation inside `runSession` now settles the row (PAUSED / CANCELLED / FAILED).
- **A late progress update could re-post the ongoing notification after the service stopped** (it cannot be swiped away).
  Posting and removal are now serialised, and removal is final.
- **Unreadable training images were skipped silently**; a session where *every* batch was empty "completed" without a step.
  It now fails with a clear message.
- **Nothing showed what a setup stage was doing.** Dataset analysis and model loading (no progress before the first batch)
  now publish a "Getting ready..." state with an indeterminate bar and a note, in the app and in the notification.
- **Nothing said how a run ended.** A normal notification now says: improved (with the loss), ran but was not better (so
  the current model was kept), paused and why, or failed and why; the Train AI screen shows the same line for the last run.

### 3. Improve it more
- **Auto strength** slider (20%..150%) next to the Auto switch; scales every automatic choice. Native option slot 23.
- Tone and exposure are solved jointly (see above); contrast/CLAHE are judged on the spread the picture will have *after*
  the levels stretch, so they stop stacking on an already-stretched picture.
- Gentler, more defensible Auto thresholds (denoise only above 2 levels of estimated noise and capped at 80%, deblur at most
  50%, clarity 0.12, detail only for clean pictures).

### Tests
New/updated unit tests (Rust: value histogram, near-neutral white balance, colourful scenes left alone, a well-exposed ramp
left alone, Auto strength scaling, levels window, hue-preserving luma retargeting, gamut-safe saturation; Kotlin: Auto strength
range). `tools/validate_color.py` (a numpy port of the old and new colour maths) compares them on synthetic scenes: mean hue shift
on saturated pixels fell from 10-32 degrees to about 0, and on real sample photos (coffee, cat, portrait, motorcycle,
launch pad) from 10-43 degrees to 0-3. It checks the *maths*, not the Rust code.

**Not compiled or run here** (no Rust/Kotlin/Gradle toolchain in the sandbox): the next CI run is the check, as for build 12.

---



Full explanation: README.md. Trained models are unaffected: the network architecture and the checkpoint/parameter
layout are unchanged, so every existing checkpoint loads exactly as before.

## Build 12.1: fix the CI build (run 1947: "Duplicate resources" for libnovaenhance_native.so)
- **Cause.** The GitHub workflow builds the Rust library itself with `cargo ndk` (arm64-v8a) into
  `app/src/main/jniLibs/` and passes `-PrustPrebuilt=true`, but `app/build.gradle.kts` ignored that and built the same
  library again into `app/build/rustJniLibs`. Both folders are jniLibs sources, so `:app:mergeReleaseJniLibFolders`
  failed with "Duplicate resources" for `arm64-v8a/libnovaenhance_native.so`.
- **Fix.** Gradle now looks for a prebuilt `<abi>/libnovaenhance_native.so` in `src/main/jniLibs` per ABI: an ABI
  that has one is only packaged, every other ABI (armeabi-v7a in CI) is still built by Gradle, and the generated
  `rustJniLibs` folder is only added when Gradle builds something. No workflow change needed.
- **Rust unit test.** `deblur_steepens_a_soft_edge_without_overshoot` moved `band` in a `for` loop and then indexed it
  (E0382), so the whole `cargo test --lib` target did not compile (the non-blocking CI step). It now iterates by reference.
- Not compiled or run here (no Rust/Gradle toolchain available): the next CI run is the check.

## Build 12: Rust rewrite + lower memory + all enhancement techniques
Request: "make this memory efficient and ram efficient and add all photo enhancement technique and rewrite it to rust".

- **Native core rewritten in Rust** (`/rust`, no dependencies). `app/src/main/cpp` and CMake are removed; Gradle runs
  `rust/build-android.sh` once per ABI (arm64-v8a, and armeabi-v7a via the NEON `thumbv7neon` target). JNI is hand-written
  (no `jni` crate), every entry point is panic-safe (a Rust panic becomes a Java exception, not a crash).
- **One native enhancement session per photo** (`NativeEnhancer`: open / processBand / close). Pixels are read from and
  written to bitmap memory directly (`jnigraphics`); the Java heap is no longer touched per band. Native working memory is
  capped by a band budget (800 000 px) whatever the photo's size.
- **In-place batch mode**: batch photos are decoded mutable and enhanced in place (saves one photo-sized bitmap per photo).
- **Lanczos upscaler**: two of the three horizontal-pass float buffers are gone (the anti-ringing range is read from the
  4 source pixels instead of being stored as two extra planes).
- **Training workspace**: 4 samples in flight (~17 MB) instead of 8 (~34 MB); bigger batches run in waves. Scoped-thread
  scheduling (dynamic, big.LITTLE-friendly) replaces the C++ pool; no unsafe code in the parallel helpers.
- **New techniques** (all off by default, each with a slider under "Advanced techniques"): white balance, auto levels,
  exposure, contrast (S-curve), shadows, highlights, CLAHE, low-light (Retinex-style), dehaze (dark-channel prior),
  vibrance, vignette fix, clarity, fine detail (guided filter), deblur (Richardson-Lucy), denoise (non-local means +
  guided chroma), hot-pixel removal, debanding - and **Auto enhance**, which analyses the photo (colour cast, exposure,
  haze, noise, blur, banding, hot pixels) and switches on what it needs.
- Removed: the unused `unsharpMask`, `denoiseBilateral`, `resizeBitmapInto` JNI calls and the Kotlin band-copy pipeline
  (`restoreArtifacts` / `smartSharpen` JNI calls are now stages inside the Rust pipeline).
- `tools/jni_crosscheck.py` now checks Kotlin `external fun`s against the Rust exports; the C++ verification tools are gone
  (their checks live on as `cargo test` unit tests in `rust/src`).

**Not verified by a compiler.** See README -> "Verification status".

---


## Build 11: cleaner, crisper results - artifact removal + a halo-free edge push + ringing-free upscaling
Request: "anyway to improve" (with before/after screenshots of a compressed manga/webtoon panel).
Trained models are unaffected (network, checkpoint layout and the AI pass are unchanged).

**What the screenshots showed.** The "after" was only a little different from the "before": the enhancement is mostly the
*classical* stages (a freshly trained 44K-parameter network is close to an identity), and those had three weak spots on
lossy line art - (1) colour blotches and mosquito noise survived, because a 5x5 bilateral filter is far smaller than the
8-16 px blocks JPEG/WebP leaves; (2) the unsharp mask can only ADD contrast around an edge, so every strong line got a dark
or bright halo (visible as a dark band outside the white head outline); (3) Lanczos-3 rings next to hard edges when
upscaling, and the unsharp mask then sharpened that ringing.

**What changed** (all native, so it works with every existing checkpoint):
- *Artifact removal* (`filters/restore.{h,cpp}`) replaces the 5x5 bilateral behind the **Noise reduction** slider: a
  separable joint-bilateral on YCbCr, 17 taps per axis. Chroma is averaged widely but only across pixels that look alike in
  luma AND colour (blotches melt, colour never bleeds across a line); luma is averaged only with near-identical pixels
  (ringing ripples vanish, real edges are untouched). The old filter stays in the library (`denoiseBilateral`).
- *Edge push* (`edgePush` in `filters/upscale.cpp`, `SharpenParams.push`) runs before the unsharp stage, driven by the
  **Sharpness** slider: it snaps each pixel of a blurred edge ramp towards the flat colour on its own side, so lines get
  steeper without ever leaving the colours already next to them - no overshoot, no halos, no fringes. The unsharp stage
  stays (halo clamp now strict: overshoot 0) for micro-contrast.
- *Anti-ringing Lanczos*: every upscaled sample is clamped to the range of the 2x2 source pixels around it.
- The Sharpness slider now maps to both stages (`EnhancementEngine.sharpenSpecFor1x` / `sharpenSpecForUpscale`).

**Measured** (`tools/quality_eval/run.sh`; synthetic JPEG-damaged line art and photos against the clean original,
Noise reduction 0.3 / Sharpness 0.3, PSNR dB / SSIM): line art 28.21 / 0.9492 -> 29.27 / 0.9618 (halo energy -14%, colour
error -10%); photos 30.77 / 0.8758 -> 30.55 / 0.8803. At 2x/4x (build-10 upscaler vs build 11, measured once with the
build-10 binary, synthetic panel with a high-resolution original): +0.4 to +0.8 dB at the default and mid slider (-0.15 to
+0.17 dB at Sharpness 1.0), SSIM unchanged within +-0.001, halo energy about 14% lower everywhere - so the big gain is at
1x cleaning, and upscaling mainly gets cleaner edges. Sharpness above ~0.6 on *photos* costs PSNR (the push is made for
line art); README -> "Cleaner results (build 11)".

| File | Status | Purpose |
|---|---|---|
| app/src/main/cpp/filters/restore.{h,cpp} | new | artifact removal: chroma deblocking + luma de-ringing, band-exact, 17-tap separable joint bilateral |
| app/src/main/cpp/filters/row_parallel.h | new | `forRowBlocks` / `rowsPerJobFor` shared by upscale.cpp and restore.cpp (were private to upscale.cpp) |
| app/src/main/cpp/filters/upscale.{h,cpp} | modified | edge push stage, `gaussianPlane()` factored out of the unsharp stage, anti-ringing in the Lanczos passes, `SharpenParams.push/pushRadius`, `sharpenReachRows` = push reach + unsharp reach. The unsharp-only 1x path is untouched (bit-identical to build 10) |
| app/src/main/cpp/native-lib.cpp, CMakeLists.txt | modified | JNI: `nativeRestoreArtifacts`, `nativeRestoreReachRows`; push parameters on `nativeSmartSharpen` / `nativeUpscaleBand` / `nativeSharpenReachRows` |
| ai/engine/NativeImageProcessor.kt | modified | `restoreArtifacts`, `restoreReachRows`, push parameters passed through |
| ai/engine/SharpenSpec.kt | modified | `push`, `pushRadius`; enabled by either stage |
| ai/engine/EnhancementEngine.kt | modified | noise reduction = `restoreArtifacts` (reach asked from native); Sharpness mapped to push + unsharp; no more bilateral constants |
| ai/engine/UpscaleStage.kt | modified | band pixel cap 1M -> 700K (the push needs ~44 B/px of scratch instead of ~28) |
| ai/engine/EnhancementOptions.kt, BandProcessor.kt | modified | KDoc only |
| test/.../EnhancementSharpenTest.kt | modified | new slider mapping, push strength curve, enabled-by-either-stage |
| tools/restore_verification/ | new | band exactness, naive double-precision reference, edge/colour-boundary/blotch/ringing properties, ASan+UBSan (`SAN=1`) |
| tools/upscale_verification/upscale_check.cpp | modified | reference now includes anti-ringing and the push; 1x band-reach test; no-overshoot, steepening and noise-immunity properties |
| tools/quality_eval/ | new | the synthetic test set + the build-10 vs build-11 comparison quoted above |
| tools/jni_crosscheck.py | new | checks every Kotlin `external fun` against its C++ `Java_...` (names, parameter and return types) |

Verified on the host with g++: `tools/upscale_verification` 22256 checks, `tools/restore_verification` 4932 checks (both also
under ASan+UBSan), `tools/filter_verification` unchanged and bit-identical, `native-lib.cpp` type-checks against stub JNI
headers, `tools/jni_crosscheck.py` ALL MATCH. Not compiled or run on a device (no Kotlin/NDK toolchain here): expect to
fix a compile error or two on the first CI build; the Kotlin edits are small and mirror existing code.

## Build 10: deep zoom on the enhanced photo + multi-select for auto-generate
Two requests: "add zoom on enhance photo, very zoom" and "add multiple photos select on auto generate dataset".
Trained models are unaffected (network, checkpoint layout and the enhancement pipeline are unchanged).

**Zoom.** Pinch to zoom the before/after preview (up to ~49x on a 12 MP photo, floor 16x, ceiling 80x), drag to pan, double-tap to
step 4x -> 12x -> 32x -> fit, badge to reset. Both images share one transform; the divider stays put on screen and, while zoomed, is
moved by its line/handle only. Zoom survives re-enhancing the same photo (slider tweaks) and resets for a new photo. Deep zoom draws
crisp pixels. The dataset pair preview dialog gets the same zoom (it reuses BeforeAfterSlider). Not zoomed, nothing changes: a drag
anywhere still moves the divider and the picture is drawn exactly as before.

**Auto-generate.** "Auto-Generate" now takes any number of photos (system photo picker, multi-select). One photo at a time, 3 variants
each, progress panel with "photo X of N", Cancel (finishes the photo in progress, keeps everything made), a failed photo is skipped and
counted, and the result line says what was added. The buttons that also add data are disabled while it runs.

| File | Status | Purpose |
|---|---|---|
| ui/components/zoom/ZoomMath.kt | new | pure zoom/pan arithmetic: limits, clamping, pinch-follows-fingers, double-tap steps |
| ui/components/zoom/ZoomPanState.kt | new | zoom + pan state (read in the draw phase only), animated double-tap / reset |
| ui/components/zoom/ZoomGestures.kt | new | `detectZoomGestures`: one loop for pinch, pan, double-tap and "owner may claim a one-finger drag" |
| ui/components/zoom/ZoomBadge.kt | new | "12.4x - tap to reset" pill; recomposes on its own, not the host |
| ui/components/BeforeAfterSlider.kt | modified | zoom transform in the Canvas, gesture loop replaces detectDragGestures, crisp pixels when magnified, badge |
| ui/components/PairPreviewDialog.kt | modified | title mentions zoom |
| ui/screens/EnhanceScreen.kt | modified | one-line hint under the preview |
| training/dataset/DatasetManager.kt | modified | `addSyntheticPairsFromPhotos`; `addSyntheticPairs` split into `createSyntheticPair`, decodes with `decodeUriBitmap` (EXIF-upright, 24 MP cap), JPEG encoded once per photo, files of a failed pair removed |
| ui/viewmodel/GenerationProgress.kt | new | run progress + summary line (pure, tested) |
| ui/viewmodel/DatasetViewModel.kt | modified | `addSyntheticPairsFromPhotos` / `cancelGeneration`, progress in the UI state, messages carry an error flag (a success note is no longer drawn in the error colour) |
| ui/components/RunProgressPanel.kt | new | reusable title + bar + optional Cancel |
| ui/screens/DatasetManagerScreen.kt | modified | multi-select picker, progress panel, buttons disabled during a run |
| test/.../ZoomMathTest.kt, GenerationProgressTest.kt | new | limits, clamping, the fixed-point property of pinching, double-tap steps; progress and summary lines |

Not compiled or run on a device (no Kotlin/NDK toolchain here): expect to fix a compile error or two on the first build. The zoom
arithmetic and the summary strings were checked by running a Python port of the same formulas and test cases.

## Build 9: sharper upscaling + multi-select photos
Two requests: "can you improve the enhance result more" and "a way to multi select photos".
Trained models are unaffected (network and checkpoint layout unchanged); this build changes only the classical stages around
the network and the Enhance screen. Details, measurements and limits: README.md -> "Upscaling and sharpening".

**Quality.** Found by comparing a 512x658 panel with its 4x result: the CNN runs at 1x and the enlargement was bilinear + a
plain unsharp mask, so edges were soft and compression noise was boosted. Now Lanczos-3 + gated, halo-clamped sharpening done
natively at the final resolution; the same sharpen replaces the unsharp mask at 1x. Output size is capped (Android will not
draw a bitmap over 100 MB), photos over 24 MP are decoded at reduced size, and picked photos are now rotated by their EXIF tag.

**Multi-select.** "Select Images" (multi-select photo picker) -> thumbnail strip -> tap one to preview/tune -> "Enhance & save
all": one photo at a time, saved to the Gallery as it finishes, failures skipped, Cancel keeps what is saved.

| File | Status | Purpose |
|---|---|---|
| cpp/filters/upscale.{h,cpp} | new | Lanczos-3 band upscaler + edge-aware sharpener; output identical for any band split |
| cpp/native-lib.cpp, CMakeLists.txt | modified | JNI: nativeSmartSharpen, nativeSharpenReachRows, nativeUpscaleBand (writes bitmap memory directly) |
| tools/upscale_verification/ | new | bit-exact band invariance, naive double-precision reference, padding/edge cases, timing; `SAN=1` for ASan+UBSan |
| ai/engine/UpscaleStage.kt | new | banded native upscale with cancellation + thermal pacing |
| ai/engine/UpscalePlan.kt | new | largest safe factor for a photo (draw-size and memory cap) |
| ai/engine/SharpenSpec.kt | new | the sharpen parameters shared with the native side |
| ai/engine/BandPacer.kt | new | thermal pacing, extracted from BandProcessor so both band stages share it |
| ai/engine/BandProcessor.kt | modified | uses BandPacer (behaviour unchanged) |
| ai/engine/EnhancementEngine.kt | modified | smart sharpen at 1x, UpscaleStage for 2x/4x, sharpening moved after the upscale, factor cap |
| ai/engine/NativeImageProcessor.kt | modified | smartSharpen, sharpenReachRows, upscaleBand |
| ai/engine/BatchEnhancer.kt | new | decode -> enhance -> save -> free, one photo at a time |
| utils/UriBitmapLoader.kt | new | EXIF-aware decode of picked photos, thumbnails, display names |
| ui/viewmodel/EnhanceViewModel.kt | modified | multi-photo selection state, enhanceAndSaveAll / cancelBatch, latest-pick-wins preview loading |
| ui/components/BatchSelection.kt | new | thumbnail strip, status badges, batch run panel |
| ui/components/LabeledSlider.kt | modified | optional `enabled` |
| ui/screens/EnhanceScreen.kt | modified | multi-select picker, strip, batch panel; settings freeze while a batch runs |
| test/.../UpscalePlanTest.kt, EnhancementSharpenTest.kt | new | factor cap and slider->sharpen mapping |

Not compiled or run on a device (no Kotlin/NDK toolchain here): expect to fix a compile error or two on the first build.

## Crash fix: "Canvas: trying to use a recycled bitmap" (build 8)
Found in the in-app crash log (Infinix X675, Android 11): the app died on the first enhancement that REPLACED a result already
on screen (e.g. after moving an option slider), 17 ms after ENHANCE_END. The log showed `retire ...: deferred, hold count 1`,
then `recycled ... on last release`, then the crash inside BeforeAfterSlider's draw. The ViewModel's hold/retire bookkeeping did
its job; the slider let go of the old bitmap too early: it reported "no longer displayed" from its own composition, but its Canvas
sat inside BoxWithConstraints, a separate composition that is updated on its own schedule, so the old bitmap was recycled while
the Canvas still held a draw lambda that captured it. Likely trigger (inferred from the log, not reproduced): a finished
enhancement flips isProcessing, the progress overlay goes away and that layer is re-recorded in the same frame.

| File | Status | Purpose |
|---|---|---|
| ui/components/BeforeAfterSlider.kt | modified | root-cause fix: one plain composition (Box, not BoxWithConstraints) so the new draw lambda is installed before the old bitmap is released; draw-time `isRecycled` guard (skips the frame and logs once instead of crashing); the divider no longer recomposes while dragging |
| utils/ResourceRetirement.kt | new | the hold / retire / dispose bookkeeping, extracted from EnhanceViewModel as a reusable class (identity-based, counted holds, `withHold`) |
| ui/viewmodel/EnhanceViewModel.kt | modified | uses ResourceRetirement; same behaviour, ~90 fewer lines |

## In-app crash log (added after build 6)
Crash diagnosis with no PC/adb/root: Settings -> View Crash Log, and a prompt at launch if the last run ended badly.
It also recovers crashes no in-process code can catch (native/C++ crashes, Android's low-memory kills) on the NEXT launch,
from Android's own exit record (Android 11+: reason, signal number, RAM held) plus an on-disk log of what the app was doing,
band by band, when it died. Copy / Share / Clear buttons; written, NOT compiled or run (no Kotlin toolchain here).

| File | Status | Purpose |
|---|---|---|
| utils/PersistentLog.kt | new | append-only on-disk log that survives the process dying; one file per run + the previous run |
| utils/ProcessExitHistory.kt | new | reads ActivityManager.getHistoricalProcessExitReasons (Android 11+) and explains it in plain English |
| utils/MemoryStats.kt | new | one-line java/native/system memory snapshot used in the breadcrumbs |
| utils/CrashReporter.kt | modified | still writes last_crash.txt on Java crashes; now also checks how the previous run ended and builds the log text |
| utils/NovaLog.kt | modified | every line is also written to PersistentLog; new `breadcrumb()` (disk only) for per-band / per-filter markers |
| ui/screens/CrashLogScreen.kt | new | the screen: Copy / Share / Clear |
| ui/navigation/NovaNavHost.kt, NovaDestinations.kt | modified | route + the "app stopped unexpectedly" prompt |
| ui/screens/SettingsScreen.kt | modified | "View Crash Log" button (screen is now scrollable) |
| ui/viewmodel/EnhanceViewModel.kt, ai/engine/EnhancementEngine.kt, BandProcessor.kt | modified | ENHANCE_BEGIN/END/FAIL/CANCEL markers + per-band and per-filter breadcrumbs with memory use |
| app/proguard-rules.pro | modified | keep names + line numbers (`-dontobfuscate`) so release stack traces are readable on the phone |

## Native (C++)  app/src/main/cpp
| File | Status | Purpose |
|---|---|---|
| nn/simd.h | new | 4-lane SIMD layer: NEON AArch64, NEON ARMv7, portable fallback |
| nn/conv_kernels.{h,cpp} | new | register-blocked 3x3 conv kernels (forward, gated backward-data, weight-gradient) |
| nn/weights.{h,cpp} | new | repack flat params into kernel layouts (checkpoint format untouched) |
| nn/inference.{h,cpp} | new | fused streaming whole-image inference, column strips, seam-free |
| nn/training.{h,cpp} | new | parallel forward/backward over (sample x row-band) jobs |
| util/thread_pool.{h,cpp} | new | persistent worker pool, dynamic job scheduling (big.LITTLE friendly) |
| nn/network.{h,cpp} | modified | slim front door: init + optimizer; delegates to the above. Public API unchanged (trainStep gains a defaulted `threads`) |
| filters/convolution.{h,cpp} | modified | bilateral LUTs, blur fast path, row-parallel; output bit-identical |
| native-lib.cpp | modified | new JNI: nativeInferRegion, threads for train step, workspace release, backend name; image ceiling 4096 -> 16384 |
| CMakeLists.txt, ../../build.gradle.kts | modified | new sources; -O3 in every build type; NEON forced on armeabi-v7a |

## Kotlin  app/src/main/java/com/novaenhance/ai
| File | Status | Purpose |
|---|---|---|
| ai/engine/BandProcessor.kt | new | seam-free band-by-band processing (replaces TileProcessor) |
| ai/engine/TileProcessor.kt | removed | superseded by BandProcessor |
| ai/engine/EnhancementEngine.kt | modified | uses bands + whole-band native inference; same public API |
| ai/engine/NativeNeuralEngine.kt, NovaModelEngine.kt | modified | inferRegion, thread budget, workspace release, backend name |
| ai/engine/PixelBufferOps.kt | modified | cropRect, transformSquare (rotate/mirror augmentation) |
| training/trainer/TrainingPatchLoader.kt | new | background prefetch, 4 augmented patches per decoded crop |
| training/trainer/ModelTrainer.kt, AdaptiveTrainingController.kt | modified | uses the loader and thread budget; frees native workspace after a session |
| utils/ComputeBudget.kt | new | thread counts per workload (8 enhance / 6 train on an 8-core phone) |
| utils/Constants.kt, DiagnosticsReport.kt, ThermalGovernor.kt, ... | modified | new constants, "Native kernels:" line in debug info, doc updates |

## Tests and tooling
- app/src/test: PixelBufferOpsTest (+8 tests), ComputeBudgetTest (new), ResourceRetirementTest (new, 11 tests) - written, NOT run (no Kotlin toolchain here;
  the retirement logic itself was checked by running a Java port of the test cases).
- tools/nn_verification: run_all.sh, kernel_check, equivalence_check, bench, neon_shim.h, reference_network.cpp.
- tools/filter_verification: bit-exact filter check against the original implementation.
