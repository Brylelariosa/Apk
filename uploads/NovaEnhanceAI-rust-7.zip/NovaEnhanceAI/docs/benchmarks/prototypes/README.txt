These two files are throw-away experiments behind the "kept / not done" findings in docs/PERFORMANCE.md (F6-F10).
They are NOT part of the build and are stored as .txt so that nothing compiles them by accident.

kernel-prototypes-main.rs.txt
    main.rs of a small separate cargo project ("kbench", edition 2021). Its Cargo.toml was:

        [package]
        name = "kbench"
        version = "0.1.0"
        edition = "2021"
        [profile.release]
        opt-level = 3
        lto = "fat"
        codegen-units = 1
        [dependencies]
        novaenhance_native = { path = "<path to the ORIGINAL build 14.1 tree>/rust" }

    Run with `cargo run --release`. It times, on one 48 -> 48 channel 3x3 layer over a 130 x 64 tile: the original kernel (verbatim copy),
    the blocked-weights kernel that shipped, and a Winograd F(2x2,3x3) prototype that did not (not bit-identical). Results: host-run-5, section C.
    It was built against the ORIGINAL crate (it calls that crate's `conv_row`, `infer_rgb` and `PackedWeights::pack`); against this tree it may need small changes.

available-parallelism-cost.rs.txt
    `rustc -O -o ap available-parallelism-cost.rs && ./ap` - time of std::thread::available_parallelism(). Results: host-run-5, section D.
