# KNOWN_LIMITATIONS — Thirty-fourth pass

Two things fixed this pass (Turbo A/B rework, fast-forward audio
decimation — see CHANGELOG.md, no fresh limitations worth calling out
beyond what's already in their own verification notes there); two things
investigated without a confident fix, which is what this entry is about.

- **Camera-cutout black area: still unresolved, and now suspected to be
  something else entirely.** Two passes changed the cutout *mode*
  (`SHORT_EDGES`, then `ALWAYS`); the report persisted through both. This
  pass's read-through of `updateGameMatrix()` found that the GBA's 3:2
  image is deliberately letterboxed/pillarboxed to preserve aspect ratio
  on a modern phone's much-wider screen — real, expected, correctly-
  computed black margin, unrelated to any cutout setting, that would look
  identical no matter what the cutout mode is doing. If the phone's
  cutout happens to sit inside that margin (plausible — both tend to be
  near an edge), that could be the whole explanation, in which case
  there's no cutout bug left to fix at all. **What would actually settle
  this:** a screenshot. If the black area is specifically on the left/
  right of the game image while playing (not top/bottom, not the ROM
  browser) — that's the pillarboxing, expected behavior, and the only way
  to shrink it is stretching or cropping the actual game image, both
  worse than the black bars. If it's genuinely a gap that doesn't
  correspond to normal letterboxing — a rectangle that stays put
  regardless of the game's own aspect ratio, say — that's still an
  unexplained real bug worth chasing, just not one guessable from here a
  third time without more to go on.
- **Fast-forward "laggy": no bug found, real hardware limit suspected but
  not confirmed.** The blocking-audio-write frame pacer this app uses
  assumes emulating `factor` sub-frames is faster than playing `factor`
  frames' worth of audio at 1x — true with CPU headroom to spare, false
  if the device can't keep up at the chosen multiplier, in which case the
  exact same design that paces normal play smoothly shows up as real
  stutter instead, because emulation becomes the bottleneck rather than
  the audio buffer. This is architectural, not a specific bug — no single
  line to point at and fix. **What would help:** which fast-forward speed
  is actually set (Settings → Fast forward speed) — trying a lower one is
  the fastest way to tell whether this is a hardware-throughput ceiling
  (lag scales down with speed) or something else (lag doesn't change much
  regardless of speed, pointing at a different cause worth investigating
  further).
- **Neither of the above got a blind third/second guess this pass.**
  Two guesses already spent on the cutout specifically without resolving
  it is a real signal to stop and ask rather than keep spending Gary's CI
  cycles on the same target — consistent with how this project has
  always treated repeated unconfirmed attempts elsewhere (see the
  multiplayer/link investigation notes throughout this file's earlier
  entries).

---

# KNOWN_LIMITATIONS — Thirty-third pass

Two things this pass — a cutout-handling change and the new memory
viewer. Stated the same way every fix in this project states its
confidence level:

- **The cutout fix is a real strengthening, not a confirmed root-cause
  fix.** `LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS` is documented to allow
  strictly more drawable area than `SHORT_EDGES` did, so it cannot make
  things worse — but "a lot of black screen on camera notch area" was
  reported without a screenshot, and there's more than one plausible
  cause bundled under that description (the cutout mode itself, the
  emulator's own aspect-ratio letterboxing being mistaken for cutout
  black space, or — now fixed with more confidence, since it's a
  confirmed gap rather than a guess — RomBrowserActivity simply never
  having had any cutout handling at all before this pass). If it's still
  visible after this, a screenshot would narrow it down a lot faster than
  another round of read-through guessing.
- **Memory viewer is read-only.** Inspects live RAM, as asked for; can't
  poke/edit values. See FEATURES_ADDED.md's note on why a write path
  wasn't included alongside this.
- **No search/watch-list, just a hex dump.** Finding *which* address
  holds a given Pokémon's HP still means knowing where to look, or
  paging through EWRAM by hand watching values change — there's no
  "find addresses that changed between two snapshots" tool (the classic
  Cheat-Engine/GameShark-code-finding workflow) here yet. A real, useful,
  materially bigger feature if wanted later — snapshot + compare +
  narrow across multiple filters — not attempted as part of this pass's
  scope.
- **Fixed 512-byte page, fixed 500ms refresh, five fixed regions.** No
  UI for a custom address, a custom page size, or a custom refresh rate.
  Reasonable defaults, not the only useful choices.
- **Not confirmed on a real device.** No Android toolchain in this
  sandbox, as every pass. `busRead8`/`busRead16`/`busRead32` being real
  `mCore` members was checked against mGBA's own source rather than
  assumed, and the mutex discipline matches this file's existing
  pattern exactly, but whether the hex dump actually shows sensible,
  correctly-addressed values against a real running Pokémon battle is
  unverified until built and tried.

---

# KNOWN_LIMITATIONS — Thirty-second pass

ROM browser split into its own Activity this pass (see
CHANGELOG.md/FEATURES_ADDED.md), not the link/multiplayer work below.
Stated the same way every fix in this project states its confidence
level:

- **Not confirmed on a real device — genuinely the most important line in
  this section for this particular pass.** Two previous attempts at
  Portrait for this exact screen both looked reasonable on read-through
  and both crashed on an actual device anyway (native RenderThread
  SIGABRT, not something a sandbox without a compiler or a phone could
  ever have caught in advance either time). This pass's approach — a
  statically declared per-Activity orientation instead of any runtime
  rotation call — is the platform's own standard mechanism for this exact
  situation and doesn't share the specific failure mode either previous
  attempt hit, by construction: there's no runtime orientation change for
  RenderThread to race against, because the orientation was never
  anything else for this Activity's whole lifetime. That's a real,
  structural difference, not just a hope this time is different — but
  "no longer shares the previously-identified failure mode" and
  "confirmed crash-free on a real device" are not the same claim, and
  only the second one is actually verified before this reaches an actual
  phone.
- **Activity transition, not an instant overlay toggle.** Opening/closing
  ROM selection now plays whatever Activity transition animation the
  system/theme uses by default, where the overlay version was instant.
  Purely cosmetic, but a real, visible behavior change from every earlier
  pass's version of this screen.
- **Multi-window / freeform.** A statically Portrait-locked Activity on a
  device or mode that supports true multi-window (a fair number of larger
  Android phones and most tablets do now) may be resized by the system in
  ways a fixed-orientation phone screen never has to handle — untested,
  since there's no such device available here either.
- **All files access OEM variance carries over unchanged from Thirty-
  first pass** — see that pass's own KNOWN_LIMITATIONS.md entry, still
  accurate: the per-app Settings screen isn't guaranteed on every skin,
  there's a general-screen fallback, and neither path is verified on an
  actual device yet.

---

# KNOWN_LIMITATIONS — Thirty-first pass

Free-roam file manager + portrait panel this pass (see
CHANGELOG.md/FEATURES_ADDED.md), not the link/multiplayer work below.
Stated the same way every fix in this project states its confidence
level:

- **Not confirmed on a real device.** No Android toolchain in this
  sandbox, as every pass. The permission flow in particular
  (`ensureBroadFileAccess()`) is the kind of thing that tends to surface
  real OEM-skin surprises — this project's own comments already note
  Infinix's XOS varies more than stock Android in unrelated places (see
  the dialog-styling comment near `showRemoveButtonDialog()`), and the
  "All files access" Settings screen is a documented source of that kind
  of variance industry-wide, which is exactly why the per-app intent is
  wrapped in try/catch with a general-screen fallback rather than assumed
  to always work — but that fallback itself is unverified on an actual
  device too.
- **Local shared storage only — no separate SD card / other volumes.**
  `romBrowserDeviceRoot` is `Environment.getExternalStorageDirectory()`,
  which is internal shared storage (`/storage/emulated/0`); a removable
  SD card (if the device has one) typically lives at a sibling path like
  `/storage/XXXX-XXXX` and isn't reachable by navigating "up" from
  internal storage, or currently reachable at all from this browser.
  Fixable later (enumerate volumes via `StorageManager`, offer them as
  extra roots) if it turns out to matter.
- **First run now asks for a real permission, where it didn't before.**
  On API 30+ specifically, that's a redirect to a system Settings screen,
  not just an in-app dialog — a bigger first-run interruption than this
  app has ever had. Deliberate trade-off for free-roam browsing, not an
  oversight — see FEATURES_ADDED.md's note on this — but worth knowing if
  it reads as a surprising new hurdle on first launch after updating.
- **Portrait panel's width is a fixed cap, not measured against the
  device's actual portrait dimensions.** `dp(420)` (or 94% of screen
  width if narrower) is a reasonable stand-in for "about as wide as a
  phone in portrait," not a real portrait-mode measurement — it'll look
  right on typical phone screens but hasn't been checked against an
  actual wide/small/tablet-class screen.

---

# KNOWN_LIMITATIONS — Thirtieth pass

New feature this pass (content-verified zip filtering in the ROM browser
— see CHANGELOG.md/FEATURES_ADDED.md), not the link/multiplayer work
below. Its own limitations, stated up front the same way every fix in
this project states its confidence level:

- **Sequential scan, one Binder round trip per `.zip`.** Each candidate
  is checked with its own `ContentResolver.openInputStream()` call, one
  after another on a single background thread — matching this project's
  existing "simple over parallel" choices elsewhere rather than adding a
  thread pool. Fine for a realistic ROMs folder; a folder with many
  large, irrelevant `.zip` files — most plausible on a slow or
  cloud-backed SAF provider — will take proportionally longer for all of
  them to either appear or be filtered out.
- **`ZipInputStream`, not `ZipFile`'s random-access central directory.**
  The check reads entries in stream order and returns the instant it
  finds a `.gba` — fast in the common case, since a real GBA-ROM zip
  usually has very few entries — but a zip with no `.gba` inside still
  costs reading through every entry it does have, because
  `ZipInputStream` can only skip an entry's compressed data by reading
  (and discarding) it, not by jumping straight to the next entry's
  header the way a central-directory read could. `ZipFile` avoids this
  but needs real seekable access, which an arbitrary SAF
  `DocumentsProvider` isn't guaranteed to support — see the next point.
- **Deliberately not reusing the `/proc/self/fd/<N>` bridge idea to get
  seekable access instead.** This project already tried a shortcut like
  that for native save/load access to SAF documents (Twentieth pass) and
  found it unreliable on a real device (Twenty-first pass — see this
  file's own Twentieth-pass section below, and
  CHANGELOG.md/BUGS_FIXED.md's Twenty-first-pass entries). Reaching for
  it again here just to get `ZipFile`'s faster reads wasn't worth risking
  the same failure mode for what's ultimately a browsing convenience, not
  a load-bearing save path.
- **Not confirmed on a real device.** No Android toolchain in this
  sandbox, as every pass — the logic reads correctly by hand and the
  file's brace balance checks out, but whether a real zip full of
  screenshots is correctly excluded, and a real GBA-ROM zip still
  appears, is unverified until built and tried.

---

# KNOWN_LIMITATIONS — Twenty-eighth pass

No code change this pass — a matched capture with FIX 22 active answered
the question it was built to answer, and turned up something new besides.
Both are worth recording before touching anything further.

## FIX 22's theory is refuted

`rcnt` stayed `0x0000` and `siocnt`'s mode-select bits (12-13) stayed fixed
on Multi-Player the entire session, on both host and child, straight
through the quiet stretch. The only thing that ever changed was SIOCNT's
IRQ-enable bit, briefly, at session start — unrelated to the stall. Neither
ROM ever leaves Multi-Player mode. The Twenty-seventh pass's theory (a
child signaling "not ready" by switching modes, invisible to a
Multi-Player-only driver) is cleanly ruled out. Worth having checked
cheaply rather than building the driver-callback version of this on top of
a wrong premise.

## What this capture shows instead

The transport is clean. The child's real SIOMLT_SEND values during each
burst aren't noise — every single pair sums to exactly `0xFFF3` (10 out of
10 pairs, across two separate attempts, verified by hand), which is
plainly a checksum or complement pattern the ROM is deliberately computing,
not corrupted or aliased data. The host's own `recv=` log confirms it
received that exact final pair (`0x0280`, `0xFD73`) intact. Whatever is
failing now is not a data-corruption or timing-aliasing problem — FIX 20/21
appear to have genuinely fixed that part.

More specifically: the host writes `SIOCNT=0x2003` (Start cleared) the
instant after receiving the second half of that last checksummed pair —
not after some elapsed timeout. That means the *host ROM's own code* is
choosing to stop issuing new Start-bit transfers right there, in direct
reaction to something about that round, not because this driver failed to
deliver anything or delivered it late. Only the host can ever initiate a
new Multi-Player transfer — nothing in this driver controls whether the
host's own code decides to write another one.

## Where this leaves things

Two working hypotheses, and no way to distinguish them from the log alone:
- The checksum handshake itself completes successfully every time (it's
  internally consistent in every round captured), and the ROM moves on to
  wait on something else this driver doesn't provide or emulate at all —
  possibly something needing to happen on both screens, possibly something
  else the host is supposed to receive that a real link partner would send
  and this driver doesn't.
- Or there's a check beyond "does it sum to 0xFFF3" — e.g. the *specific*
  value, not just the relationship — that this driver's child-side data
  doesn't satisfy, and the checksum consistency we're seeing is a red
  herring rather than confirmation the handshake itself is passing.

Distinguishing these needs something this project hasn't had access to at
any point in 28 passes: either a disassembly of this specific ROM's link
code, or a reference capture from a setup already known to work (real
hardware, or a different working link solution) to diff against. Guessing
further from this log alone risks the same category of blind, blind
signature-style mistake this project has consistently avoided elsewhere.

## Worth asking next

Whether this exact symptom is specific to Dragon Ball Z: Supersonic
Warriors, or whether any multiplayer ROM now gets further than this with
FIX 20/21/22 in place — that would materially change where the next pass
should look.

---

# KNOWN_LIMITATIONS — Twenty-seventh pass

## The honest state of things right now

Same symptom, sharper diagnosis. Dragon Ball Z: Supersonic Warriors still
fails, with the same stall shape the Twenty-sixth pass's capture showed —
FIX 21 didn't change it, which rules pacing out as the cause of this
specific failure. New and important: the user confirmed the communication
error appears *during* the quiet stretch after the initial handshake
burst, well before this file's own ~11.5s retry gives up on its own. The
game is failing faster, and for a different reason, than anything this
driver currently tracks.

## The reframing this pass found

GBATEK's actual documented Multi-Player procedure says a child can signal
"not ready" by temporarily leaving Multi-Player mode entirely — not
through any bit this driver has ever inspected. `link_sio_write_register()`
is registered for `SIO_MULTI` only (FIX 7), the same way every real
per-mode SIO driver in mGBA's own source is scoped to one mode. If either
ROM takes that documented exit, every write it makes until switching back
would go completely unlogged here — indistinguishable, from this file's
point of view, from the ROM doing nothing at all.

If that's what's happening, it reframes a lot of this project's own
history: every "restart" logged since the Sixteenth pass — the ones this
project has consistently read as the negotiation failing and beginning
again from scratch — might instead be the ROM doing exactly what GBATEK
says it should, invisibly. And this driver has never relayed *mode* over
the network at all, only actual Multi-Player transfers, so even where this
theory is completely right, the other device still has no way to see its
partner's not-ready signal — which would explain a stall that both sides
enter into together and neither one ever resolves.

## What this pass checked instead of assuming

Two ways to test this: add `init`/`load`/`unload` driver callbacks to log
mode transitions directly, or read the core's own `sio.rcnt`/`sio.siocnt`
fields straight from `nativeRunFrame()`. Went with the second. The first is
a real option for later, deliberately not taken this pass — FIX 7's own
comment already records getting bitten by exactly this category of mistake
once (`GBASIOSetDriver()`'s argument count, only caught by a real build
log), and this sandbox has no better way to confirm `load`/`unload`'s exact
signature against the pinned mGBA headers now than it did then. Reading
two existing struct fields directly is a smaller, cheaper claim.

## What the next capture should show either way

If a matched capture with FIX 22 shows an "SIO mode" log line moving away
from Multi-Player's own selection bits during the quiet stretch — on
either device — that confirms this theory outright, and the
driver-callback approach (plus, eventually, actually relaying mode/
readiness over the network, which is the real fix if this is right) is
worth the build-log round trip to pursue next. If `rcnt`/`siocnt` sit
completely still through the whole quiet stretch instead, this theory is
wrong, and the search should move elsewhere without carrying it forward.

---

# KNOWN_LIMITATIONS — Twenty-sixth pass

## The honest state of things right now

Mixed, and genuinely informative both ways. A fresh device capture with
FIX 20 active shows the child's own link code producing real, varying data
for the first time ever, and the ~200ms restart loop is gone. But
multiplayer still doesn't work, and separately the user reported Dragon
Ball Z: Supersonic Warriors — a real-time fighting game — instantly
failing with "communication error" plus visible lag.

## What the capture confirms

The aliasing/timing theory from the Twenty-fifth pass predicted that
letting the child's CPU actually observe each exchange, instead of many
landing between one frame of its own execution, should let its negotiation
progress past two placeholder values. That's what happened: this capture's
childData includes 0x003C, 0x0019/0xFFDA, 0x022F/0xFDC4, 0x0047/0xFFAC,
0x005D/0xFF96, 0x0279/0xFD7A, 0x0084/0xFF6F — real variation, not just
0x0000/0xFEFE — and the restart period went from ~200ms to ~15-17s. First
real evidence this theory is on the right track, not just plausible.

## The new bottleneck this exposes

Each attempt in this capture follows the same shape: a burst of real
variation for roughly a second after a restart, then both sides write
SIOCNT with Start cleared (`0x2003`) and sit idle for several seconds
before the whole thing restarts from RCNT=0 again. This is a different
problem from the one FIX 20/21 target, and it's only visible now because
those fixes got far enough for it to be reached at all. No theory yet for
what this specific stall is — worth treating as its own question next pass
rather than assumed to be more of the same aliasing issue.

## The regression risk this pass responds to

FIX 20 as originally written paced *every* host-triggered exchange for the
*entire* session, with no way to turn itself off once a connection
stabilized. Dragon Ball Z: Supersonic Warriors' instant "communication
error" plus lag is consistent with exactly that cost landing on a
real-time game that needs fast, frequent exchanges for actual gameplay —
not the slower, retry-tolerant handshake the working capture above came
from. No capture from that specific attempt to confirm it was really
pacing latency and not something else about that ROM; that would be the
most useful thing to get next, ideally matched host+child like every other
capture in this project.

FIX 21 bounds pacing to a short window per negotiation attempt (armed at
session start and re-armed on every RCNT write) instead of removing it —
see CHANGELOG.md. This is a guess at the right shape of trade-off, not a
confirmed one: it's possible 3 seconds is too short to help the games that
need it, too long to spare the games that don't, or that the RCNT-based
re-arming doesn't fire the way this pass assumes for every ROM's own
negotiation style.

## Open questions for the next pass

- Does FIX 21 preserve the progress FIX 20 showed on the ROM used in this
  pass's capture, or was the un-bounded window actually load-bearing for
  some part of what happened after the first second?
- Does bounding the window fix (or improve) Dragon Ball Z: Supersonic
  Warriors, or was its failure unrelated to pacing entirely?
- What is the SIOCNT=0x2003/Start-cleared stall this pass's capture
  exposed, and is it timing-related too or a genuinely separate bug?

---

# KNOWN_LIMITATIONS — Twenty-fifth pass

## The honest state of things right now

Still broken. A fresh matched host+child capture (07-17) shows the exact
same pattern as every capture back to the Sixth pass: the child's own
SIOMLT_SEND is only ever `0x0000`/`0xFEFE`, nothing else, ever — unchanged
by FIX 18/19 and by everything since (Twentieth-Twenty-fourth pass touched
Storage folder, save-state perf, and UI; nothing in the link code path).

## Nineteenth pass's standing question, answered

Nineteenth pass left open whether either phone might just be sitting on its
own "waiting for other player" menu — which would mean no bug in this file
at all, just a human not having pressed Start on both screens. This pass's
capture answers that two ways. First, directly: the user confirmed the same
ROM's multiplayer works outside this app, which wouldn't be true if this
were just an unconfirmed menu on one screen. Second, from the capture
itself: the child's own RCNT/SIOCNT setup resets every ~200ms
(18:37:59.699 / .908 / 18:38:00.102 / .309 / .506 — 194-209ms apart each
time). A phone genuinely idling on a static "waiting for link" menu
wouldn't be expected to keep re-touching RCNT on a ~200ms cadence; that
pattern reads as an active retry/timeout loop, not an idle screen. Both
point the same way: this is a real bug in this app's link code, not a
menu/input miss and not something unusual about this particular ROM.

## Where this leaves the running theories

- **Missing SIO IRQ (Seventh pass):** fixed, confirmed present in the code
  on both host and child paths. No observed effect on its own or combined
  with FIX 18/20.
- **Child's SIOCNT busy bit never mirrored (Eighteenth pass):** fixed,
  confirmed present in the code. No observed effect on its own.
- **ROM-specific quirk / menu-state ambiguity:** ruled out this pass — see
  above.
- **Timing/cycle-count mismatch (Sixteenth/Seventeenth pass):** the only
  remaining theory with real reasoning behind it and, as of this pass, the
  only one actually tested rather than just named — see FIX 20 in
  `mgba_jni.c` / CHANGELOG.md. Not confirmed either way yet; needs a real
  device.

## What FIX 20 does and doesn't tell us

FIX 20 is deliberately a narrow experiment, not an attempt at the real fix.
It paces host-triggered exchanges to roughly one emulated frame apart
(~16.7ms) instead of letting them fire as fast as the network replies
(hundreds/second). Real Multi-Player mode is designed to run many transfers
per frame, so this is a coarser interval than real hardware would ever use
— chosen specifically to give the child's CPU a chance to observe each
exchange at all, not to be cycle-accurate. Two possible outcomes once
someone can actually run this on a device:
- **No change** (still ~200ms resets, still only 0x0000/0xFEFE): the
  aliasing/overwrite theory above is likely wrong or incomplete, and the
  next pass should look elsewhere rather than push further on timing.
- **Any change** (different reset period, a childData value other than
  those two, anything): real evidence the timing theory is on the right
  track, and grounds to invest in the bigger fix — pacing transfer
  completion against mGBA's own cycle-accurate scheduler (`mTiming`), the
  way its real `GBASIOLockstepDriver` does — which this pass still does not
  attempt, for the same reason every pass since the Seventeenth hasn't:
  real scheduler integration isn't something to get right blind, without a
  device to check it against.

---

# KNOWN_LIMITATIONS — Twenty-first pass

Follow-up to the Twentieth pass's Storage folder feature — see
CHANGELOG.md/BUGS_FIXED.md for the fix itself (the `/proc/self/fd` bridge
below, replaced with a stage-and-copy approach). This pass's own limitations:

- **Battery save has brief windows where the chosen folder can lag behind
  what's actually been played.** The core mmaps a local mirror file for
  the whole session (see `SaveEntry.batteryMirrorPath()`); that mirror is
  only copied out to the real document at `onPause()`, before swapping
  ROMs, on `closeGame()`, and as a last resort in `onDestroy()` — not after
  every single in-game save. An app process killed outright between one of
  those sync points and the next (rare, but Android can do this to a
  backgrounded app under memory pressure before `onPause()` finishes, or
  the OS can kill a process harder than that) could leave the chosen
  folder's copy slightly behind the mirror's. The mirror itself (internal
  storage) is never behind — only the copy out to the user-visible folder
  can be.
- **`onPause()`'s sync runs synchronously on the main thread.** Deliberate:
  a background thread kicked off from `onPause()` isn't guaranteed to
  finish before the process can be torn down, which would defeat the
  point. Battery saves are small (GBA SRAM/Flash tops out at 128KB, EEPROM
  far less), so this should be a sub-frame stall in practice — not
  measured against a real slow storage provider, since (as always in this
  project's history) there's no device here to measure it on.
- **Still not verified against every DocumentsProvider**, cloud-storage-
  backed folders (Google Drive, Dropbox, etc. exposed through SAF)
  especially — only against the general contract every `DocumentsProvider`
  is required to implement (`openInputStream`/`openOutputStream`), which is
  a much safer bet than the mmap/seek/truncate behavior the previous
  approach silently assumed, but still not the same as an actual test.

---

# KNOWN_LIMITATIONS — Twentieth pass

New feature this pass (Storage folder — see CHANGELOG.md/FEATURES_ADDED.md),
not the link/multiplayer work above. Its own limitations, stated up front
the same way every fix in this project states its confidence level:

- **No migration.** Switching to a chosen folder does not move whatever
  already exists under internal storage — only new saves/states/
  screenshots go to the new location from that point on. Not attempted
  because it would mean automatically rewriting or deleting a user's
  actual game-save data with no real device anywhere in this project's
  history to verify the move against first. Stated plainly in the
  Settings screen itself.
- **FIXED (Twenty-first pass) — was: "The `/proc/self/fd/<N>` bridge
  (native save/load path) is unconfirmed on a real device."** It wasn't
  just unconfirmed — a real-device test surfaced exactly the "doesn't save
  and load" symptom this note worried about. Replaced; see
  CHANGELOG.md/BUGS_FIXED.md — Twenty-first pass, and this file's own
  Twenty-first-pass section above.
- **`cheat` subfolder is provisioned, not used.** There's no cheat-file
  feature yet (see the "Cheats" menu row, still "not implemented yet") —
  this just gives one somewhere to write once it exists.
- **DocumentFile.createFile()'s displayName handling isn't provider-
  verified.** Passing `application/octet-stream` as the mime type should
  make providers preserve exact filenames like `game.sav`/`game.state1`
  rather than appending an extension of their own choosing, and this is
  standard practice for exactly this reason — but "should," same caveat
  as above, no device to confirm it against.

---

# KNOWN_LIMITATIONS — Nineteenth pass

## The honest state of things right now

Still broken. Eighteenth pass's SIOCNT-mirroring fix was tested against a
real matched capture this pass and showed **no observed change**: the
child's own exchange log still shows `childData` as only ever
`0x0000`/`0xFEFE` — the exact same two values every capture back to the
Sixth pass has shown, with nothing else ever appearing. The host's `recv`
correspondingly still only ever reflects those same two values (plus the
occasional `0xFFFF` timeout). Not reverted — it's still a correctness fix
on its own terms — but it is not, or not the whole of, what's actually
wrong.

## Where this leaves the running theories

- **Missing SIO IRQ (Seventh pass):** fixed, confirmed present in the code
  on both host and child paths. No observed effect on its own (Eighth
  pass) or in combination with FIX 18 (this pass).
- **Child's SIOCNT busy bit never mirrored (Eighteenth pass):** fixed,
  confirmed present in the code. No observed effect this pass.
- **Timing/cycle-count mismatch (Sixteenth/Seventeenth pass):** still
  untouched, still the only remaining code-level theory with any real
  reasoning behind it that hasn't actually been tried yet.

Two independent, individually well-reasoned fixes producing zero visible
change is worth pausing on rather than reaching for a third blind one
immediately — per Eighth pass's own precedent for exactly this situation.

## A question worth answering before the next code change

Nothing in any capture so far has said what's actually on each phone's
*screen* at the moment of capture. Every log confirms the SIO protocol
layer is cycling through a fixed "not ready yet" pattern — but that's also
exactly what a game legitimately shows while a human hasn't yet pressed
Start/confirmed on the in-game link menu on one or both phones. Worth
ruling out directly: at the moment of capture, does either phone still say
something like "Waiting for other player," or has a player already
pressed A/Start on both screens with nothing happening afterward? The
former would mean there's no bug in this file at all yet to find; the
latter narrows things back to the timing theory above.

## Log-capture tooling note (this pass)

The two logs this pass covered different real-world spans, which had no
quick explanation before now. Confirmed root cause: the host's code logs
~3 lines per SIO exchange (two writes + one result) against the child's
~1 ("Child exchange" line), so the same 40,000-character export cap holds
less real time on the denser, host side — not a phone problem, and not
specific to this capture. `copyLinkDebugLog()` now appends the exact copy
timestamp so this is visible at a glance on future captures.

---

# KNOWN_LIMITATIONS — Eighteenth pass

## The honest state of things right now

Multiplayer still doesn't work — not fixed, not yet re-tested against a
real device. What's different this pass: for the first time since this
project started asking for it (Twelfth pass onward), a real matched
two-phone capture came in — `wifi_host`/`wifi_join`-style logs from *both*
phones, timestamps overlapping to the second (07-16 14:02:58–14:03:00),
not minutes apart. Seventeenth pass's file-based logging is what made this
possible.

## What the matched capture actually confirms

Cross-referencing both sides directly (not just each side's own aggregate
stats, which is all any previous pass had) confirms Sixteenth/Seventeenth
pass's read and rules out one whole category of explanation for good:

- The host's own live, changing outgoing values — its counter-embedded
  probe sequence (`0xFEFE`, `0x4921`, `0x2002`, `0x0001`, `0x0020`, plus
  the slowly-drifting counter bytes) — show up **correctly** as `hostData`
  in the child's own exchange log, value for value.
- The child's fixed `0x0000`/`0xFEFE` show up **correctly** as `recv` in
  the host's own exchange log.

Data crosses the network both ways, correctly, confirmed from both ends
of the same attempt at once. This was always the leading "boring"
explanation to rule out, and it's now ruled out as solidly as a log-only
sandbox can manage — not a relay/corruption bug, not a network-timing
bug on the transport itself.

## New finding and this pass's fix

With the network layer cleared, the child ROM's own code is the only
place left unaccounted for — and re-reading `nativeLinkChildExchange()`
specifically against that framing (rather than re-reading everything from
scratch again) turned up a gap the function's own comment already
admitted to: it writes SIOMULTI0-3 and raises the SIO IRQ, but never
touched the child device's own SIOCNT. GBATEK documents Multi-Player
SIOCNT bit 7 (Start/Busy) as a hardware-mirrored reflection of the
parent's clock line on *every* connected unit, not something a child's
CPU sets — polling it to notice "a transfer just landed" is a normal
technique alongside, or instead of, IntrWait on the IRQ this file already
raises correctly. Since nothing here ever pulsed that bit on the child's
device, a child ROM using that technique would see a flat, never-changing
value — indistinguishable from "no transfer has ever happened" — no
matter how correct the IRQ or the data registers already are.

Fixed: `nativeLinkChildExchange()` now refreshes SIOCNT bits 2 (child), 3
(ready), 4-5 (player ID) and clears bit 7 (busy) on the child's own device
after every exchange, preserving every other bit exactly as the ROM last
set it. See `mgba_jni.c`'s own FIX 18 comment for the full reasoning.

**Not confirmed** — same caveat as every fix in this project, still no
device in this sandbox — but grounded in a gap the code already admitted
to itself, cross-referenced against GBATEK, rather than a new guess about
either test ROM's internals.

## Found but not addressed this pass

- **Exchange completion still isn't cycle-timed against any real transfer
  duration** — the timing/lockstep theory from Sixteenth/Seventeenth pass
  is untouched by this fix and remains a live secondary candidate if this
  one turns out not to be the whole answer.
- Everything else listed as open in Seventeenth pass's own section below
  is still open; this pass didn't revisit any of it.

## What would move this forward

Exactly what would have moved every pass since the Twelfth forward: a real
device re-test with this fix in place, ideally with another matched
same-attempt pair from both phones (now easy to get, since Seventeenth
pass's logging doesn't need logcat access on either device). If the child
ROM was polling SIOCNT bit 7, its own `Child exchange:` log entries should
finally show `childData` values other than `0x0000`/`0xFEFE` — that's the
one thing to check first.

---

# KNOWN_LIMITATIONS — Seventeenth pass

## The honest state of things right now

Multiplayer still doesn't work. This pass had two goals: get more out of
the first evidence taken with Sixteenth pass's exchange-result/child-
exchange logging, and close the logcat-access gap that's been blocking a
truly simultaneous two-phone capture since the Twelfth. Neither goal
produces a confirmed fix — see BUGS_FIXED.md's own honesty note, same as
every pass since the Ninth.

## What the new logs actually show

W sent `wifi_host__1_.text` (2128 lines) and `wifi_join__1_.text` (1739
lines) this pass — real captures, both taken with Sixteenth pass's new
trace points already built in, so for the first time the *content* of
each side's exchanges is visible, not just that an exchange happened.

**Caveat first, same as every pass since the Fifteenth:** these are two
separate sessions. Host timestamps run 12:46:02.132–12:46:03.726; join
timestamps run 12:49:13.435–12:49:15.423 — about three minutes apart, not
the same connection attempt. Nothing below can be cross-referenced
transfer-by-transfer. What follows is each side's own aggregate behavior,
which is real evidence on its own, just not proof the two sides were
actually failing the same handshake at the same moment.

**Host side.** 704 completed exchanges in ~1.6s. 694 (98.6%) got a real
reply, not a timeout — only 10 timed out, and each of those correctly
shows up as `recv=0xFFFF` (Ninth pass's own placeholder for a timed-out
round), not silently dropped. A network layer replying this fast, this
reliably, is real evidence it isn't the bottleneck. But of those 694 real
replies, every single one was either `0xFEFE` (544 times) or `0x0000` (150
times) — never once anything resembling the host's own outgoing data,
which cycles through a repeating ~20-value set (`0x0000`, `0xFEFE`,
`0x4921`, `0x2002`, `0x0001`, `0x0020`) plus two slowly-incrementing
counter-like bytes (`0x56xx`, `0x40xx`) — the same shape Sixteenth pass
already described from the trigger side alone.

**Child side.** This is the real addition this pass. Across all 1586 of
this capture's own `nativeLinkChildExchange()` calls, `childData` — this
device's own `g_link_driver.localSend`, i.e. whatever its ROM most
recently wrote to its own SIOMLT_SEND — is `0xFEFE` (1137 times) or
`0x0000` (449 times) and **literally nothing else**, for the entire ~2
second capture. This is a directly-traced local write, not a relay
question: the child ROM itself never writes anything past these two
placeholders. Its SIOCNT/RCNT/SIOMLT_SEND writes repeat the same
five-write sequence roughly every 200ms (10 RCNT=0x0000 writes across the
capture, 194–209ms apart each time) — write SIOCNT, write RCNT=0x0000,
write SIOCNT again, reset SIOMLT_SEND to 0x0000, write SIOCNT a third
time. Per GBATEK, RCNT bit 14-15 combined with SIOCNT bit 12-13 is exactly
how Multi-Player mode gets *selected* — writing RCNT=0 here (with SIOCNT's
bit 13 already set from the previous write) is part of that selection, not
a fallback to Normal mode. So this really does look like the child ROM's
own "waiting for the other unit" setup loop — the kind of thing a real
game does while sitting on a link/lobby screen — just one that never gets
past its own opening move and keeps restarting.

Put together: the network is delivering data quickly and reliably in both
directions (confirmed independently from both sides now, not just
inferred from the host's trigger pattern). The child ROM's own code is
what never progresses. This doesn't identify why yet, but it does move the
question from "is something dropping or corrupting data" (looking
unlikely) to "why does the child's own negotiation never see whatever
condition it's waiting for" (still open).

## Re-checked: is bit3 (all-ready) actually reaching the child?

This was the single most likely explanation going into this pass — GBATEK
says SIOCNT bit 3 tells a unit "all connected GBAs are in Multi-Player
mode"; a child ROM that never sees that bit set would plausibly just keep
re-initializing forever, which is exactly the observed symptom. Ninth
pass's fix (`link_sio_write_register()` ORing bit 3, and bit 2 for
parent/child identity, into every SIOCNT write while `g_link_active` is
true) was checked specifically against this theory this pass.

On paper it already covers this correctly: the OR happens unconditionally
on *every* SIOCNT write, gated only on `g_link_active`, not on
`g_link_is_host` — unlike the exchange-trigger branch right below it in
the same function, which *is* host-gated (Fifteenth pass, FIX 14). Since
`g_link_active` is true for this entire capture (confirmed — every one of
the 1586 child-exchange calls produced real data, never hit the early-exit
skip path), the child ROM should already be seeing bit3=1 from its very
first SIOCNT poll onward. **No bug found here this pass** — worth stating
plainly rather than silently re-confirming, since it was the leading
candidate coming in and ruling it out (as much as static reading can rule
anything out) is itself useful for whoever picks this up next.

## Best current theory, updated but still NOT confirmed

Per DeepWiki's generated documentation of mgba-emu/mgba's own real
`src/gba/sio/lockstep.c` (a secondary source describing the real file,
cross-referencing real line ranges — not fetched directly this pass), the
actual mGBA project's own multiplayer implementation — used by its Qt
frontend for local multi-instance play, unrelated to this project's code
but the source Eighth pass's `GBASIOMultiplayerFinishTransfer` reference
came from — is built around a lockstep coordinator: a transfer-start event
gets enqueued to every secondary player, the coordinator explicitly waits
for all of them to acknowledge, and completion is timed against a
`GBASIOCyclesPerTransfer` table so every transfer takes the same number of
emulated cycles a real cable would.

This file's own exchange has no equivalent of any of that. It's a single
blocking network round-trip that completes the instant one UDP/RFCOMM
reply comes back — real SIO hardware (and mGBA's own lockstep driver)
never completes that fast relative to the CPU's own instruction stream,
because a real transfer takes a fixed, non-zero number of cycles no matter
how fast the physical link is. The same DeepWiki page lists
"desynchronization due to timing issues" as the most common multiplayer
bug class in mGBA's own reference implementation — real, independent
support for timing/synchronization being a plausible category here too,
not a guess invented from nothing. It is still not evidence that this
specific codebase's specific instance of that category is what's actually
happening — that would take a real device test, same as every other
theory this project has ever proposed.

**Deliberately not attempted this pass:** reworking the exchange to be
event-paced / cycle-timed instead of one blocking call. That's a real
protocol redesign, not a logging addition, and every prior pass's stated
policy — most explicitly the Eighth's — has been to not make that kind of
change blind, without a real device to check it against. Flagging it here
as the most promising remaining direction for whoever has device access
next, not attempting it speculatively now.

## The fix this pass: logging that doesn't need logcat at all

W's report this round — real evidence on one phone, nothing on the other,
same split as Sixteenth pass's screenshot — confirms the logcat-access gap
flagged then but not fixed is still standing between this project and the
one thing every pass since the Twelfth has actually asked for: a capture
from *both* phones during the *same* connection attempt. Without that,
even the theory above can only ever be "plausible," never checked.

`copyLinkDebugLog()` no longer touches `logcat` at all. Every `LOGI`/
`LOGW`/`LOGE` call in `mgba_jni.c`, plus `LinkMultiplayer.kt`'s own 7
connection-lifecycle log lines (Fifteenth pass), now also writes to a
plain file this app owns outright, under its own `filesDir` — no
permission needed, no OS logcat access of any kind, on any OEM build,
because it was never reading logcat in the first place. Re-truncated at
the start of every `nativeLinkStart()`, so a capture is one attempt, not
an accumulation. See CHANGELOG.md and FILE_CHANGES.md for the mechanics.

**This should directly unblock the thing that's been stuck since the
Twelfth pass.** If it does, the actual next step is unchanged from every
recent pass: connect, get both ROMs into their in-game link screens, let
it sit a few seconds, then tap "Copy link log" on *both* phones within the
same short window, and send both. With that — and only with that — the
theory above (or whatever the logs actually show instead) can finally be
checked against a real, matched pair instead of two windows minutes apart.

## Found but not addressed this pass

- **Exchange completion isn't cycle-timed against any real transfer
  duration** — see "Best current theory" above. Real redesign, needs
  device feedback to attempt safely.
- **`nativeLinkChildExchange()` is called from a background Kotlin thread,
  asynchronously with respect to `nativeRunFrame()`'s own instruction
  stream** (protected by `g_core_mutex` for data-race safety, but not
  synchronized to any particular point in the emulated frame). Whether
  this matters is unknown — flagged as a distinct angle from the timing
  theory above, not folded into it, since it's about *when within a frame*
  an interrupt lands rather than *how long a transfer takes*. Not
  investigated this pass; noted so it isn't lost.

## What would move this forward

Unchanged in substance from every pass since the Twelfth, hopefully now
actually reachable: a real, simultaneous two-phone capture of one
connection attempt, both ROMs actually on their in-game link screens, both
logs pulled via "Copy link log" within the same short window. Everything
else in this section is downstream of finally having that.

---

# KNOWN_LIMITATIONS — Sixteenth pass

## The honest state of things right now

Fifteenth pass's logging fix worked: W's four uploads this pass are the
first real evidence this project has had in sixteen passes. One screenshot
shows the debug-log tool producing nothing on one specific phone (see its
own section below); the other three are genuine logcat captures with real
content — `wifi_host.text` (2243 lines, host role), `wifi_join.text` (271
lines, child role), `bluetoth__1_.text` (136 lines, child role).

What they show, read plainly:

- **The network layer is very likely working.** The host recorded 1124
  Start-bit-triggered exchange attempts in 1.67 seconds. At
  `WIFI_XCHG_MS=30` per timeout, hitting that ceiling on most of them would
  take upwards of 30 seconds — it didn't. The overwhelming majority
  completed fast, which only happens if a reply is actually arriving
  quickly from the other phone.
- **The host doesn't seem to be making progress.** Its outgoing data isn't
  varied — it cycles through what looks like the same ~20-value sequence
  repeatedly (a handful of fixed values, plus two that drift by exactly ±1
  between cycles: `4007→4008`, `56B4→56B3`, which reads like a live
  counter embedded in an otherwise-static probe). It never seems to
  advance to different content, which is what you'd expect from a
  handshake that keeps getting rejected and restarting rather than one
  progressing normally.
- **The child doesn't seem to be making progress either.** Both child-role
  logs (Wi-Fi and Bluetooth, separate sessions) show the same pattern:
  SIOCNT/RCNT written in a short setup sequence, then the whole thing
  repeated again roughly every 200ms, indefinitely. That looks like a ROM
  that keeps abandoning its own negotiation and starting over, on both
  transports, not a transport-specific problem.

**One important caveat: `wifi_host.text` and `wifi_join.text` are
timestamped about two minutes apart.** They're not two windows into the
same live conversation — each shows that device's own behavior in its own
attempt, not a matched pair that can be directly cross-referenced
transfer-by-transfer. Nothing below should be read as "the host sent X and
the child's log shows it receiving X" — that comparison isn't possible with
what's been captured so far.

**Best current theory — not confirmed, and explicitly a guess about
game-specific protocol behavior this sandbox has no way to verify:** each
side's own link-negotiation code is independently timing out and
restarting because whatever it's reading back from the other side doesn't
look like a valid response — plausible if a network round trip frequently
lands while the far side is itself mid-reset, since a device mid-reset has
nothing better than a stale placeholder value to hand back, creating a
loop where neither side's "good" moment ever lines up with the other's.
That is one plausible story that fits the shape of the data. It is not
confirmed, and it isn't the only story that would fit.

The concrete gap closed this pass: neither theory *could* have been
checked before now, because the only thing ever logged was the write that
*triggers* a host-side exchange — never what came back, and never anything
at all from the child's own receive function
(`nativeLinkChildExchange()`), which had zero logging in either of its two
paths across all sixteen passes. Both fixed (logging only, see
CHANGELOG.md items 1-2).

## What would actually move this forward

The single most valuable thing that hasn't happened yet: **capture both
phones' logs from the same connection attempt**, not sequential ones
minutes apart. Concretely:

1. Connect (Wi-Fi first). Get both ROMs to their in-game link screens.
2. Let it sit for a few seconds — long enough to accumulate a real sample,
   short enough that `Copy link log`'s 20000-line window comfortably
   covers the whole thing on both phones.
3. Open `Copy link log` on **both** phones within the same short window,
   right after, before doing anything else.
4. Repeat over Bluetooth.

With items 1-2 from this pass in place, that capture should show, per
phone: every exchange the host triggered and what actually came back
(timeout or real data, and what data); every exchange the child's own
receive path actually processed, or logged as skipped and why. If the
"mutual reset livelock" theory is right, the host's `recv=` values during
a child's own reset window should visibly be the same placeholder-looking
values (`0xFEFE`/`0x0000`) the child logs show it writing to its own
SIOMLT_SEND right around then — checkable for the first time with a
matched pair of logs and approximately synchronized clocks (both phones'
system clocks, not the app — logcat timestamps are wall-clock).

## The debug-log tool doesn't work on every phone

W reported and screenshotted an empty capture (`"(no matching lines
yet...)"`) on one phone, while the other produced real output — the three
files above. Not addressed as a code fix this pass. Likely explanation,
not fully confirmed: a non-root, non-system, non-debuggable app's ability
to read back even its own logcat output varies by Android version and OEM
policy — some builds allow it unconditionally, some restrict it further.
Shizuku (which W already has working on the productive phone) is a common
workaround for exactly this, which is itself circumstantial evidence for
this explanation over some other cause.

A durable fix would mean not depending on OS logcat access at all — e.g.
the app writing its own diagnostic lines to a private file directly (both
from Kotlin and, via a small JNI addition, from this file's own LOGI/LOGW
call sites) and having `copyLinkDebugLog()` read that file back instead of
shelling out to `logcat`. That's a real feature addition (new JNI entry
point, a file path handshake at startup, touching every existing log call
site) — not attempted blind, in the same pass as everything else above,
given there's no device or compiler here to catch a mistake in it. Worth
doing if the one working phone turns out not to be enough to finish this
investigation; not yet necessary, since it's currently providing usable
evidence on its own.

## Found but not addressed this pass

- Everything in this section from the Fifteenth pass below is still open.
- The Twelfth-pass "many exchanges within one 16ms window" observation
  (further below, unmoved for several passes now) looks, in hindsight,
  like an earlier sighting of the exact same fast-repeating-attempts
  pattern `wifi_host.text` shows clearly this pass. Worth formally
  connecting once a matched host+child capture exists to check against.

# KNOWN_LIMITATIONS — Earlier passes (summary)

Full write-ups trimmed for length. The throughline, condensed:

- **Fifteenth** — Built the exchange-result/child-exchange trace logging
  that Sixteenth pass's evidence and this pass's matched capture both
  depend on. No new evidence of its own yet.
- **Thirteenth** — Save-state thumbnails pass; no new link evidence.
- **Twelfth** — Added the (logcat-based) "Copy link log" tool. First step
  toward getting any real evidence at all, but no capture yet.
- **Ninth** — First pass to explicitly ask for real logcat evidence
  instead of another round of static-only theorizing; none available yet.
- **Eighth** — Seventh pass's real IRQ fix produced zero observed change
  on either test game. Flagged that this pointed further upstream than
  more protocol guessing could reach from this sandbox alone.
- **Seventh** — SIO IRQ fix (see BUGS_FIXED.md); expected to matter for
  interrupt-driven ROMs specifically.
- **Sixth** — The original root-cause pass: child never answers the host
  at all (fixed with the passive responder), SIOCNT status bits never
  set, peer-disconnect never detected.
- **Fifth** — First multiplayer-focused pass; thread-safety and socket-
  lifecycle fixes, no protocol-level work yet.

Every pass from the Sixth through the Seventeenth shares one constraint,
unchanged until this pass: no Android device or NDK toolchain in this
sandbox, so nothing has ever been build- or runtime-verified here — every
fix is confirmed only by static reading against GBATEK and/or mGBA's own
source, and by whatever the user reports back after a real-device test.
