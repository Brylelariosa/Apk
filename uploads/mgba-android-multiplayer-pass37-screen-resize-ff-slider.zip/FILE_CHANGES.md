# FILE_CHANGES — Thirty-seventh pass

## Modified

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** Six related requests around fast-forward, the game screen, and
Fullscreen — see CHANGELOG.md/BUGS_FIXED.md for the full descriptions.
**What changed:**
- Game loop (`startGameLoop()`): the buffer-publish step
  (`synchronized(bufferLock) { readyIdx = ...; writeIdx = ... }`) moved
  from unconditional to only running on the branch where `backBmp` was
  actually rendered into — fixes the white-flash bug.
- New field `gameScreenRect`; removed fields `fullscreenMode`; removed
  constants `CTRL_FRAC_FULL`, `PREF_FULLSCREEN`.
- `updateGameMatrix()`: now resolves `"gamescreen"`'s rect via
  `resolvedRect()` (the same function every button's own position
  resolves through) instead of a fixed top-left region sized by
  `gameScreenFraction`/`fullscreenMode` directly.
- `buildControlLayout()`: calls `updateGameMatrix(sw, sh)` internally at
  its own end now; three external call sites that used to pair the two
  calls manually (`startGameLoop()`, `surfaceChanged()`,
  `applyLayoutSettings()`) simplified to just the one call.
- `labelFor()`, `editRectFor()`, `hitTestEditable()`: each gained a
  `"gamescreen"` case (label "Game Screen"; rect from `gameScreenRect`;
  hit-tested last, after every real button).
- `showRemoveButtonMenu()`: guarded against `id == "gamescreen"`.
- `resetSingleButton()` needed no changes — already called
  `buildControlLayout()`, which now updates the screen too, for free.
- FF button (`onGameTouch()`'s `ACTION_DOWN`/`ACTION_UP`): tap-vs-hold
  disambiguation added (new field `ffLongPressPending`) — a tap still
  toggles fast-forward instantly-feeling (resolved on `ACTION_UP` now
  rather than `ACTION_DOWN`), a hold opens the new
  `showFastForwardSpeedSlider()` instead. FF button's drawn label:
  dropped the "» 4×" active-speed text, kept the existing color/fill
  on/off indicator.
- New `showFastForwardSpeedSlider()`.
- `showVideoSettings()`: removed the Fullscreen checkbox entirely; fixed
  "Screen size" to also hide `settingsMenuOverlay` (not just dismiss its
  own popup) before entering the editor.
- Controls background draw and idle-alpha calc: `fullscreenMode`
  conditionals removed (background always draws now; idle alpha is
  always `buttonBaseAlpha`, no fullscreen-specific dim).
- "Reset settings" handler (Misc): `fullscreenMode`/`PREF_FULLSCREEN`
  removed; `stretchToFit`/`maxFrameSkips`/`linearFilterEnabled` (and
  their prefs) added — these three had been missing from this handler
  since they were introduced two passes ago, noticed while removing
  `fullscreenMode` from the same list.
- Settings sidebar's Video row subtitle: "...& fullscreen" →
  "...& effects".

---

# FILE_CHANGES — Thirty-sixth pass

## Modified

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** Real compile error, caught by an attached CI build log — see
BUGS_FIXED.md/CHANGELOG.md.
**What changed:**
- Added `@Volatile private var linearFilterEnabled = false`, declared
  next to `stretchToFit`/`maxFrameSkips`. Corrected a comment nearby
  (`updateLinearFilterPaint()`'s doc comment) that had incorrectly
  described this field as already existing before this pass.

---

# FILE_CHANGES — Thirty-fifth pass

## Modified

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** Video settings rebuild, Max frame skips implementation, Turbo A/B
sizing — all requested directly. Full description in CHANGELOG.md.
**What changed:**
- New `gamePaint` (shared, mutable `Paint`) and `updateLinearFilterPaint()`;
  the game bitmap's `canvas.drawBitmap(bmp, gameMatrix, null)` now passes
  `gamePaint` instead of `null`. Called once after prefs load and again
  from the new Linear filtering checkbox's toggle handler.
- New fields: `consecutiveFrameSkips`, `lastFrameLoopStartNs`,
  `frameBudgetNs`. Reset alongside `ffFrameAccumulator` wherever the game
  loop (re)starts.
- `startGameLoop()`: computes `behindSchedule` from the gap since the
  previous iteration's own `t0`; the `framesToRun == 1` branch now chooses
  `nativeRunFrame(null)` vs `nativeRunFrame(backBmp)` based on
  `maxFrameSkips`/`behindSchedule`/`consecutiveFrameSkips` instead of
  always blitting.
- `buildControlLayout()`: Turbo A/B's `tSz` raised `abSz * 0.55f` →
  `abSz * 0.75f`.
- Both button-resize `coerceIn` call sites (toolbar +/- and pinch gesture):
  `4.0f` → `8.0f` max.
- `showVideoSettings()` rewritten entirely (list layout, see CHANGELOG.md).
  New helpers `videoListRow()`, `videoCheckRow()`, `videoDivider()`,
  `roundedDialogBackground()` (the last one also a straight extraction of
  a `GradientDrawable` pattern that was previously copy-pasted at several
  other dialog call sites — same styling, one place now instead of many).
- New `showScreenOrientationDialog()`, `showMaxFrameSkipsDialog()`.

---

# FILE_CHANGES — Thirty-fourth pass

## Modified

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** Turbo A/B rework and fast-forward audio quality — both requested
directly. Full description of both in CHANGELOG.md. (The other two things
reported this pass — cutout black area, fast-forward lag — were
investigated but not code-changed; see CHANGELOG.md items 3–4 and
KNOWN_LIMITATIONS.md.)
**What changed:**
- `extraControlIds`: added `"ta"`, `"tb"` at the front of the list.
- `allControlIds()`: removed the `if (turboButtonsEnabled) { ids += "ta"; ids += "tb" }`
  special case — now fully covered by `ids += extraControlIds`.
- `buildControlLayout()`: the Turbo A/B block's `if (turboButtonsEnabled)`
  wrapper removed — `addButton("ta", ...)`/`addButton("tb", ...)` now
  called unconditionally, same pattern every other extra control already
  used (visibility is `addButton()`'s own internal `isButtonVisible()`
  check). Button face text changed `"T"`/`"T"` → `"A"`/`"B"`.
- Removed: `turboButtonsEnabled` field, `PREF_TURBO` constant, its
  SharedPreferences load line, and the whole "⚡ Turbo A / Turbo B
  buttons" checkbox block in `showInputSettings()` (including the now-
  unused local `prefs` variable that block was the only user of).
- `turboHalfPeriodMs`: `66L` → `30L`.
- `decimateForFastForward()`: rewritten from box-filter averaging to a
  one-pole low-pass (continuous IIR state across the whole accumulated
  block) followed by direct every-`factor`th-sample downsampling. Return
  value / output-count math (`accumPairs / factor`) unchanged — only how
  each output sample's value is computed changed, not how many get
  produced or how long `writePcm()` ends up blocking for.

---

# FILE_CHANGES — Thirty-third pass

## Modified

### `app/src/main/cpp/mgba_jni.c`
**Why:** Live memory viewer feature — see FEATURES_ADDED.md.
**What changed:**
- New `nativeReadMemory()`, placed directly after `nativeReadAudioSamples()`
  (same "caller allocates a Java array, native fills it" shape). Loops
  `core->busRead8(core, address + i)` for `length` bytes into the caller's
  `jbyteArray` via `GetByteArrayElements`/`ReleaseByteArrayElements`,
  entirely inside `g_core_mutex`. Returns 0 (buffer untouched) if the core
  isn't initialised or `length` isn't positive; otherwise always returns
  `length`.

### `app/src/main/kotlin/com/mgba/android/EmulatorEngine.kt`
**Why:** Same feature — the Kotlin-side declaration for the function above.
**What changed:**
- New `external fun nativeReadMemory(address: Int, buf: ByteArray, length: Int): Int`,
  added after `nativeReadAudioSamples`.

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** Both requests this pass. Full description of the memory viewer in
FEATURES_ADDED.md; the cutout change in CHANGELOG.md.
**What changed:**
- Cutout handling in `onCreate()` upgraded: `LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS`
  on API 30+, falling back to the previous `LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES`
  on API 28–29 (unchanged below that).
- New fields: `memoryViewerOverlay`, `memoryDumpText`, `memoryAddressText`,
  `memoryRegionIndex`, `memoryPageOffset`.
- New `MemRegion` data class and `memRegions` list (EWRAM/IWRAM/Palette/
  VRAM/OAM, standard GBA memory map addresses).
- New functions: `showMemoryViewer()`, `hideMemoryViewer()`,
  `scheduleMemoryRefresh()` (self-rescheduling `Handler.postDelayed()`
  loop, guarded by `isFinishing || isDestroyed` and the overlay's own
  visibility, same shape as this file's other posted-completion guards),
  `refreshMemoryDump()`, `formatHexDump()`, `buildMemoryViewer()`.
- `onCreate()`: `memoryViewerOverlay` built and attached to `root`, same
  pattern as `settingsMenuOverlay` right above it.
- `showGameMenu()`: new "Memory" item appended right before "Close" (so
  every other item's index is unchanged), added to `needsRom`, dispatches
  to `showMemoryViewer()`.

### `app/src/main/kotlin/com/mgba/android/RomBrowserActivity.kt`
**Why:** Cutout fix — this Activity is new this overall changeset and
never had any cutout handling at all.
**What changed:**
- Added import `android.view.WindowManager`.
- `onCreate()`: same `ALWAYS`/`SHORT_EDGES` pair MainActivity now has,
  added before `setContentView()`.

---

# FILE_CHANGES — Thirty-second pass

## Added

### `app/src/main/kotlin/com/mgba/android/RomBrowserActivity.kt`
**Why:** ROM selection needed to be a real, statically Portrait-locked
Activity instead of an overlay inside MainActivity's window — see
FEATURES_ADDED.md for the full reasoning.
**What it contains:** Everything that used to be
`buildRomBrowser()`/`openRomBrowserAtRoot()`/`romBrowserUp()`/
`refreshRomBrowserList()`/`renderRomBrowserList()`/`romBrowserMessageRow()`/
`romBrowserRow()`/`buildBrowserStack()` inside `MainActivity.kt` (Thirty-
first pass), adapted to standalone-Activity shape: `setResult()`+`finish()`
instead of toggling overlay visibility; its own `onCreate()` (builds the
UI, wires an `OnBackPressedCallback` for folder-aware Back, then calls
`ensureBroadFileAccess { openAtRoot() }`); its own copies of
`pendingFileAccessAction`/`legacyStoragePermissionLauncher`/
`allFilesAccessLauncher`/`hasBroadFileAccess()`/`ensureBroadFileAccess()`/
`romPicker`/`pickerLive` (moved from `MainActivity.kt`, not duplicated —
`MainActivity.kt` no longer has its own copies); its own
`PREF_ROMS_LAST_FOLDER` constant (private to this Activity now — nothing
else needs it). UI is full-screen edge-to-edge again, not the
centered/width-capped "panel over a dimmed backdrop" Thirty-first pass
built — that trick existed specifically to fake a Portrait look inside an
actually-Landscape window, which is no longer the situation now that this
Activity's whole window really is Portrait.

### `app/src/main/kotlin/com/mgba/android/RomZipUtils.kt`
**Why:** `isZipSignature()`/`zipContainsGba()` needed to be callable from
two different classes now (`MainActivity.stageRomFile()` and
`RomBrowserActivity`'s listing) instead of one.
**What it contains:** `object RomZipUtils` with both functions, moved
out of `MainActivity.kt` verbatim except `zipContainsGba()` now takes a
`ContentResolver` parameter explicitly instead of implicitly using an
Activity's own `contentResolver` property.

### `app/src/main/kotlin/com/mgba/android/SharedUi.kt`
**Why:** `dp()`, `uiToast()`, `colorAccentLight`, `iconChipBackground()`
needed to be usable from `RomBrowserActivity` too.
**What it contains:** The same four, moved out of `MainActivity.kt` as
top-level `Context`/`Activity` extension functions/properties (package-
level, not a shared base class — every existing unqualified call site in
`MainActivity.kt`, e.g. `dp(20)`, keeps compiling unchanged since these
now live in the same package instead of being that class's own private
members).

## Modified

### `app/src/main/AndroidManifest.xml`
**Why:** `RomBrowserActivity` needs its own manifest entry to declare a
static Portrait lock.
**What changed:** New `<activity android:name=".RomBrowserActivity"
android:exported="false" android:screenOrientation="portrait"/>` entry,
with a comment explaining why (see FEATURES_ADDED.md).

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** Same feature — see FEATURES_ADDED.md.
**What changed:**
- Removed: `isZipSignature()`, `zipContainsGba()` (→ `RomZipUtils.kt`);
  `dp()`, `iconChipBackground()`, `colorAccentLight`, `uiToast()`
  (→ `SharedUi.kt`); `romTreePicker`'s already-removed successor —
  `pendingFileAccessAction`/`legacyStoragePermissionLauncher`/
  `allFilesAccessLauncher`/`hasBroadFileAccess()`/`ensureBroadFileAccess()`/
  `romPicker`/`pickerLive` (→ `RomBrowserActivity.kt`); every ROM-browser
  UI field and function (`romBrowserOverlay`, `romBrowserListLayout`,
  `romBrowserPathText`, `romBrowserBackBtn`, `romBrowserDeviceRoot`,
  `romBrowserStack`, `romBrowserGeneration`, `buildBrowserStack()`,
  `openRomBrowserAtRoot()`, `romBrowserUp()`, `refreshRomBrowserList()`,
  `renderRomBrowserList()`, `romBrowserMessageRow()`, `romBrowserRow()`,
  `buildRomBrowser()` — all → `RomBrowserActivity.kt`); `PREFS` constant
  (→ top-level in `SharedUi.kt`); `PREF_ROMS_LAST_FOLDER` constant
  (→ private in `RomBrowserActivity.kt`, nothing else needs it); imports
  `android.os.Environment`, `android.provider.Settings`,
  `java.io.BufferedInputStream` (all now unused here — their only call
  sites moved out).
- `stageRomFile()` now calls `RomZipUtils.isZipSignature(input)` instead
  of a local function; otherwise unchanged.
- `changeRom()` reduced to one line:
  `romBrowserLauncher.launch(Intent(this, RomBrowserActivity::class.java))`.
- New `romBrowserLauncher` (`ActivityResultContracts.StartActivityForResult()`)
  — on `RESULT_OK`, hands `result.data?.data` to the existing, unchanged
  `loadRomFromUri()`; does nothing on `RESULT_CANCELED`, same
  surface-sits-idle behavior as before.
- `onCreate()`: no longer builds/attaches a ROM browser overlay to `root`
  (nothing to build here now).
- Six stale comments fixed, all left over from earlier passes and made
  more obviously wrong by this one: the floating-Load-ROM-button removal
  note in `onCreate()` (referenced `romBrowserOverlay`); the "land
  straight in" comment right before `changeRom()`'s call site in
  `onCreate()` (described a flow this file no longer has any part of);
  `surfaceChanged()`'s resize comment (claimed ROM selection forces a
  Portrait switch — hasn't been true since Thirty-first pass); the
  Storage-folder feature's "deliberately SAF" comment (justified itself
  by comparison to the ROM browser's *old* reasoning, which the ROM
  browser no longer uses); `onGameTouch()`'s comment (referenced
  `romBrowserOverlay`'s `isClickable` guard, which doesn't exist to
  reference anymore); `applyScreenOrientationPref()`'s try/catch history
  comment (referenced `openRomBrowserAtRoot()`/`buildRomBrowser()` call
  sites that no longer exist in this file).

---

# FILE_CHANGES — Thirty-first pass

## Modified

### `app/src/main/AndroidManifest.xml`
**Why:** Requested feature — free-roam file manager needs broad local
storage access; see FEATURES_ADDED.md.
**What changed:**
- Replaced the old "READ_EXTERNAL_STORAGE removed, unused" comment block
  with one explaining the new permissions and why the old reasoning no
  longer applies.
- Added `<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="29"/>`
  and `<uses-permission android:name="android.permission.MANAGE_EXTERNAL_STORAGE"/>`.
- Added `android:requestLegacyExternalStorage="true"` to `<application>`
  — only takes effect on exactly API 29, harmless/ignored elsewhere.

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** Same feature, plus the portrait-panel styling — both requested
directly. Full description in FEATURES_ADDED.md.
**What changed:**
- Added imports: `android.os.Environment`, `android.provider.Settings`.
- Removed `romTreeUri` field, `romTreePicker` (the `OpenDocumentTree`
  launcher), and the `PREF_ROMS_TREE_URI` constant.
- Added `PREF_ROMS_LAST_FOLDER` constant (plain path string, replaces the
  removed tree-Uri pref).
- Added `pendingFileAccessAction`, `legacyStoragePermissionLauncher`,
  `allFilesAccessLauncher`, `hasBroadFileAccess()`, `ensureBroadFileAccess()`
  — mirrors the existing `ensureBluetoothPermission()` pattern. The All
  Files Access launch is wrapped in try/catch: the per-app Settings
  intent (`ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION`) isn't shipped
  by every OEM skin, falls back to the general
  `ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION` screen.
- `changeRom()` simplified to `ensureBroadFileAccess { openRomBrowserAtRoot() }`.
- `romBrowserStack` is now `MutableList<File>` (was `MutableList<DocumentFile>`).
- Added `romBrowserDeviceRoot` (`Environment.getExternalStorageDirectory()`,
  lazily cached) and `buildBrowserStack(target)`, which walks `File.parentFile`
  from a target back up to the device root to reconstruct the navigation
  stack — used to restore the last-browsed folder on reopen.
- `openRomBrowserAtRoot()` rewritten: reads `PREF_ROMS_LAST_FOLDER`,
  validates it's still a real directory, falls back to the device root
  if not, builds the stack via `buildBrowserStack()`.
- `refreshRomBrowserList()`: `current.listFiles()` (nullable for
  `java.io.File`, unlike `DocumentFile`) now falls back to `emptyArray()`;
  persists the current folder to `PREF_ROMS_LAST_FOLDER` on every
  navigation; breadcrumb text shows "Internal storage" for the root
  entry instead of its raw folder name. Zip-candidate scanning
  (Thirtieth pass) unchanged in structure, just calls
  `zipContainsGba(Uri.fromFile(f))` instead of `zipContainsGba(doc.uri)`.
- `renderRomBrowserList()`'s parameter type updated to `List<File>`.
- `romBrowserRow()` rewritten for `File` instead of `DocumentFile` —
  functionally identical (directory → drill in, file → `loadRomFromUri(Uri.fromFile(file))`),
  simpler in one respect: `File.name` isn't nullable, so the old
  `doc.name ?: "?"` fallback is gone.
- `buildRomBrowser()` return type changed from `LinearLayout` to
  `FrameLayout`; `romBrowserOverlay`'s declared type updated to match.
  The existing header/pathRow/list/fallback content is now built into a
  `panel` (rounded corners via `GradientDrawable`, `#FF17171B` background,
  same as before) with a computed max width
  (`dp(420).coerceAtMost(94% of screen width)`), centered inside a new
  outer `FrameLayout` with a `#CC000000` dimmed backdrop.
- Header's "📂 Change folder" button replaced with "🏠 Root" (clears
  `romBrowserStack` back to just `romBrowserDeviceRoot`).
- Updated three stale comments left pointing at the removed
  `romTreePicker`/`PREF_ROMS_TREE_URI`: the block comment above
  `openRomBrowserAtRoot()` (kept the original reasoning for the record,
  marked superseded, explained why); the Storage-folder feature's own
  explanatory comment a few hundred lines earlier, which referenced
  `romTreePicker` only as a same-mechanism comparison; and the
  `onCreate()` comment describing the "land straight in" startup flow.

---

# FILE_CHANGES — Thirtieth pass

## Modified

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** Requested feature — the ROM browser's `.zip` filtering should be
based on what's actually inside the archive, not its extension. Full
description in FEATURES_ADDED.md.
**What changed:**
- New `isZipSignature(input: BufferedInputStream): Boolean` — the exact
  magic-bytes check `stageRomFile()` used to do inline, now shared.
  `stageRomFile()` calls it instead of repeating the byte comparison; no
  behavior change there.
- New `zipContainsGba(uri: Uri): Boolean` — same check, but only peeks
  for a `.gba` entry name and returns the instant it finds one; never
  writes anything to disk.
- `refreshRomBrowserList()` rewritten: `current.listFiles()` is now split
  into `immediate` (directories + bare `.gba` files, rendered right away,
  same sort as before) and `zipCandidates` (`.zip` files, not yet shown).
  If there are no zip candidates, the visible result is unchanged
  end-to-end. If there are, a background `Thread` named
  `"mGBA-rom-zip-scan"` calls `zipContainsGba()` on each — each check
  wrapped in its own try/catch so one unreadable/corrupt zip can't abort
  the rest of the scan — then posts back to the main thread and merges
  whichever passed into the visible list.
- New `romBrowserGeneration` field (`@Volatile Int`, declared with this
  browser's other fields near the top of the class), bumped at the start
  of every `refreshRomBrowserList()` call. The posted completion checks
  it against the value captured when its own scan started, and bails out
  if the user has since navigated elsewhere (or the Activity is
  finishing/destroyed) — same shape as `loadRomFromUri()`'s own
  posted-completion guard, including the explicit `post label@ { }` style
  rather than the implicit `@post` label.
- New `renderRomBrowserList(entries, stillScanning)` — the actual list
  rendering, extracted out of `refreshRomBrowserList()` so both the
  immediate render and the post-scan re-render share one code path. When
  `stillScanning` is true, an empty `entries` does *not* trigger the "No
  ROMs or folders here" empty state (a folder holding only zip candidates
  would otherwise flash that message right before the scan fills it in)
  — the list shows a trailing "Checking archives…" row instead.
- New `romBrowserMessageRow(message)` — small shared helper for that row
  and the pre-existing empty-state message, which used to have its
  `TextView` styling written out inline once.
- Removed `romRelevantExtensions` (the `.zip`/`.gba` list). Its two
  extensions now need different treatment — one renders immediately, one
  needs verification first — so a single list checked identically for
  both no longer fit. Both extensions are still checked, just inline at
  their own now-separate call sites, matching how `stageRomFile()` already
  checks `.gba` as a string literal rather than a named constant.

---

# FILE_CHANGES — Twenty-ninth pass

## Modified

### `app/src/main/cpp/mgba_jni.c`
**Why:** Code audit found `g_link_obj`/`g_link_xchg_mid`/`g_link_is_host`
written outside `g_core_mutex` despite being read under it everywhere
else. See CHANGELOG.md/BUGS_FIXED.md.
**What changed:**
- `nativeLinkStart()`: `GetObjectClass()`/`GetMethodID()` still run before
  the lock (pure JNIEnv calls, no shared state touched); `NewGlobalRef()`
  now happens before the lock too but is only *assigned* to `g_link_obj`
  after `pthread_mutex_lock(&g_core_mutex)`, alongside `g_link_xchg_mid`
  and `g_link_is_host`. The old unconditional `DeleteGlobalRef` of any
  previous `g_link_obj` at the top of the function moved to right after
  the lock, immediately before the new one is assigned.
- `nativeLinkStop()`: the `if (g_link_obj) { DeleteGlobalRef; ... }` and
  `g_link_xchg_mid = NULL;` lines moved from after
  `pthread_mutex_unlock(&g_core_mutex)` to before it.

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** Code audit found `showSaveStateSlotDialog()`'s save/load action
had the same unsynchronized-Thread race an earlier pass already fixed for
Quick Save/Quick Load, just never extended here. See CHANGELOG.md/
BUGS_FIXED.md.
**What changed:**
- Renamed `quickStateBusy` → `saveStateBusy` (`AtomicBoolean`); updated
  its doc comment to describe the broader scope. `quickSaveState()`/
  `quickLoadState()`'s existing `compareAndSet`/`.set(false)` calls
  updated to the new name, no other change to either function.
- `showSaveStateSlotDialog()`'s `setAdapter` callback: added the same
  `if (!saveStateBusy.compareAndSet(false, true)) { uiToast(...); return@setAdapter }`
  guard, right after the existing empty-slot check and before the
  save/load `Thread` is spawned. Wrapped that `Thread`'s body in
  `try { ... } finally { saveStateBusy.set(false) }` so the guard always
  clears, success or failure — mirrors `quickSaveState()`'s own
  `try/finally` shape exactly.

---

# FILE_CHANGES — Twenty-seventh pass

## Modified

### `app/src/main/cpp/mgba_jni.c`
**Why:** User tested against Dragon Ball Z: Supersonic Warriors with a
fresh matched capture and confirmed the communication error appears during
the post-handshake quiet stretch, before this file's own retry gives up.
See CHANGELOG.md/BUGS_FIXED.md.
**What changed:**
- Added `g_link_last_sio_rcnt`, `g_link_last_sio_siocnt`,
  `g_link_sio_mode_logged` next to the other pre-declared link globals
  (FIX 8's block, for the same "used before declared" reason as that one).
- `nativeRunFrame()`: right after the existing `g_core->runFrame(g_core);`
  / `g_link_driver.env = NULL;` pair, added a guarded block that reads
  `g_link_gba->sio.rcnt` and `g_link_gba->sio.siocnt` directly and logs
  them (tagged `SIO mode`, distinct from the existing `SIO write` tag)
  only when either value has changed since the last check.
- `nativeLinkStart()`: added `g_link_sio_mode_logged = false;` next to the
  existing FIX 20/21 reset lines, so every session logs a fresh baseline.
- Added a FIX 22 entry to the file's top-of-file history comment, in the
  same style/detail as FIX 1-21.



## Modified

### `app/src/main/cpp/mgba_jni.c`
**Why:** User tested FIX 20 on a real device (fresh matched capture
attached) and separately reported Dragon Ball Z: Supersonic Warriors
failing instantly with "communication error" plus lag. See
CHANGELOG.md/BUGS_FIXED.md.
**What changed:**
- Added `LINK_PACE_WINDOW_NS` (3s), `g_link_pace_window_start`,
  `g_link_pace_window_active`, and `link_pace_arm_window()`.
- `link_pace_exchange()`: now returns immediately (no clock read) when no
  window is armed; when one is armed, checks whether it's expired first
  (clearing `g_link_pace_window_active` and returning if so) before
  falling through to FIX 20's original interval-pacing logic unchanged.
- `nativeLinkStart()`: now calls `link_pace_arm_window()` right after the
  existing `g_link_last_exchange_set = false;` line.
- `link_sio_write_register()`: added a new `address == 0x134u` branch
  (RCNT was previously unhandled — the function only special-cased 0x12A
  and 0x128) that calls `link_pace_arm_window()`, placed before the
  existing `if (address != 0x128u) return value;` line so it applies on
  every RCNT write regardless of value or role.
- Added a FIX 21 entry to the file's top-of-file history comment, in the
  same style/detail as FIX 1-20.

---

# FILE_CHANGES — Twenty-sixth pass

## Modified

### `app/src/main/cpp/mgba_jni.c`
**Why:** User tested FIX 20 on a real device (fresh matched capture
attached) and separately reported Dragon Ball Z: Supersonic Warriors
failing instantly with "communication error" plus lag. See
CHANGELOG.md/BUGS_FIXED.md.
**What changed:**
- Added `LINK_PACE_WINDOW_NS` (3s), `g_link_pace_window_start`,
  `g_link_pace_window_active`, and `link_pace_arm_window()`.
- `link_pace_exchange()`: now returns immediately (no clock read) when no
  window is armed; when one is armed, checks whether it's expired first
  (clearing `g_link_pace_window_active` and returning if so) before
  falling through to FIX 20's original interval-pacing logic unchanged.
- `nativeLinkStart()`: now calls `link_pace_arm_window()` right after the
  existing `g_link_last_exchange_set = false;` line.
- `link_sio_write_register()`: added a new `address == 0x134u` branch
  (RCNT was previously unhandled — the function only special-cased 0x12A
  and 0x128) that calls `link_pace_arm_window()`, placed before the
  existing `if (address != 0x128u) return value;` line so it applies on
  every RCNT write regardless of value or role.
- Added a FIX 21 entry to the file's top-of-file history comment, in the
  same style/detail as FIX 1-20.

---

# FILE_CHANGES — Twenty-fifth pass

## Modified

### `app/src/main/cpp/mgba_jni.c`
**Why:** User-reported, with a fresh matched host+child capture attached:
multiplayer still doesn't connect, now confirmed (by the user, not a log)
to be an app-side issue rather than a ROM-side one. See CHANGELOG.md/
BUGS_FIXED.md/KNOWN_LIMITATIONS.md for the full reasoning.
**What changed:**
- Added `LINK_PACE_EXCHANGES` (default on), `LINK_GBA_CYCLES_PER_FRAME`,
  `LINK_MIN_EXCHANGE_INTERVAL_NS`, `g_link_last_exchange_ts`,
  `g_link_last_exchange_set`, and `link_pace_exchange()` — a small,
  self-contained, OFF-able block placed immediately before `link_exchange()`.
- `link_pace_exchange()` is called at the top of `link_sio_write_register()`'s
  existing host Start-bit branch, immediately before the existing call to
  `link_exchange()` — no other line in that branch changed.
- `nativeLinkStart()`: added one line, `g_link_last_exchange_set = false;`,
  next to the existing `g_link_driver.localSend = 0xFFFFu;` reset, so a new
  connection attempt never paces its first exchange against a stale
  timestamp from a previous session.
- Added a new FIX 20 entry to the file's own top-of-file history comment,
  in the same style/detail as FIX 1-19.



## Modified

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** User-reported: menu Save State/Load State feels slow, both
opening the slot picker and confirming after picking a slot. See
CHANGELOG.md/BUGS_FIXED.md.
**What changed:**
- Hoisted the `SlotInfo` data class out of `showSaveStateSlotDialog()` to
  a private class-level declaration (now carries `modified: Long` too),
  and added `slotInfoCache: ConcurrentHashMap<String, SlotInfo>` keyed by
  `"$currentRomBaseName:$slot"`.
- `showSaveStateSlotDialog()`: each slot now checks `slotInfoCache` before
  reading/decoding its thumbnail; only re-decodes when `exists`/`modified`
  no longer match the cached entry.
- Added `SaveEntry.moveInto(dest)`: renames `legacy` into `dest.legacy`
  when neither entry uses a Storage folder (deleting any existing `dest`
  first), falling back to the old copy-based behavior otherwise.
- `backupIfExists()` now calls `entry.moveInto(entry.backupEntry())`
  instead of doing its own read/write copy.

---

# FILE_CHANGES — Twenty-fourth pass

## Modified

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** User-reported: menu Save State/Load State feels slow, both
opening the slot picker and confirming after picking a slot. See
CHANGELOG.md/BUGS_FIXED.md.
**What changed:**
- Hoisted the `SlotInfo` data class out of `showSaveStateSlotDialog()` to
  a private class-level declaration (now carries `modified: Long` too),
  and added `slotInfoCache: ConcurrentHashMap<String, SlotInfo>` keyed by
  `"$currentRomBaseName:$slot"`.
- `showSaveStateSlotDialog()`: each slot now checks `slotInfoCache` before
  reading/decoding its thumbnail; only re-decodes when `exists`/`modified`
  no longer match the cached entry.
- Added `SaveEntry.moveInto(dest)`: renames `legacy` into `dest.legacy`
  when neither entry uses a Storage folder (deleting any existing `dest`
  first), falling back to the old copy-based behavior otherwise.
- `backupIfExists()` now calls `entry.moveInto(entry.backupEntry())`
  instead of doing its own read/write copy.

---

# FILE_CHANGES — Twenty-third pass

## Modified

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** User-reported: Quick Save/Quick Load racing each other during
fast save/load testing. See CHANGELOG.md/BUGS_FIXED.md.
**What changed:**
- Added `quickStateBusy: AtomicBoolean`, shared by `quickSaveState()` and
  `quickLoadState()`.
- Both functions now `compareAndSet(false, true)` at the top and bail out
  with a "Still saving/loading" toast if another call is already in
  flight, instead of unconditionally spawning a new `Thread`.
- Both `Thread { ... }` bodies wrapped in `try/finally` so
  `quickStateBusy` is always cleared, including the existing early
  `return@Thread` in `quickLoadState()` for "No quick save yet".

---

# FILE_CHANGES — Twenty-second pass

## Modified

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** User-reported: a stray "Load ROM" button rendering on top of the
ROM browser (screenshot provided), and Save State feeling slow. See
CHANGELOG.md/BUGS_FIXED.md.
**What changed:**
- Removed the `loadRomBtn` field, its `Button` construction, and its
  `root.addView(...)` call in `onCreate()` entirely.
- Removed the two `loadRomBtn.visibility = ...` calls left over from the
  ROM-load success/failure paths, and the one in `closeGame()`.
- `onGameTouch()`: now returns early on `ACTION_UP` with `changeRom()`
  whenever `!romLoaded`, replacing the button as the way back into ROM
  selection when nothing else is on screen.
- `showSaveStateSlotDialog()`: moved the "Saved to Slot N"/"Loaded Slot
  N"/failure `uiToast(...)` call to fire immediately after
  `nativeSaveState()`/`nativeLoadState()` returns, ahead of
  `captureStateThumbnail(slot)` rather than after it.
- Updated the doc comments on `changeRom()`, `onCreate()`'s closing block,
  and `closeGame()` that referenced `loadRomBtn` by name.

---

# FILE_CHANGES — Twenty-first pass

## Modified

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** real-device bug report — Storage folder feature broke save/load.
See CHANGELOG.md/BUGS_FIXED.md.
**What changed:**
- Removed `NativeHandle` and `SaveEntry.nativePath()` — the `/proc/self/fd/<N>`
  bridge in its entirety.
- `SaveEntry.outputStream()`: now opens with explicit `"wt"` mode (was the
  2-arg `openOutputStream(uri)` default), so a write shorter than the
  previous save can't leave stale trailing bytes on providers that don't
  truncate on plain `"w"`.
- New `SaveEntry` methods: `stageForRead()`, `stageForWrite()`,
  `commitWrite()` (one-shot save-state/quicksave/thumbnail read/write —
  stage a SAF document's bytes to/from a local cache file, native only
  ever touches the local file) and `batteryMirrorPath()`,
  `syncBatteryMirror()` (session-long battery save — local mirror file the
  core mmaps for the whole session, synced out to the real document at a
  handful of call sites, not continuously).
- `quickSaveState()`/`quickLoadState()`/`showSaveStateSlotDialog()`: rewired
  from `entry.nativePath(...).use { }` to the new stage/commit methods.
- `loadRomFromUri()`/`resetGame()`: rewired from `saveEntry.nativePath(...)`
  to `saveEntry.batteryMirrorPath()`; `loadRomFromUri()` also now syncs the
  *outgoing* ROM's mirror before swapping in a new one.
- `onPause()`/`onDestroy()`/`closeGame()`: each now calls
  `syncBatteryMirror()` for the currently-loaded ROM, so the chosen
  folder's copy doesn't just sit stale until the app happens to reload a
  ROM again.

---

# FILE_CHANGES — Twentieth pass

## Modified

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** new Storage-folder feature — see CHANGELOG.md/FEATURES_ADDED.md.
**What changed:**
- New `PREF_DATA_FOLDER_URI`, `dataFolderPicker` (SAF tree picker, mirrors
  the existing `romTreePicker`), `dataFolderTree()`, `dataSubfolder()`.
- New `SaveEntry` (inner class) + `NativeHandle`: the abstraction that
  lets every save-adjacent file live in either internal storage or the
  chosen folder transparently, including the `/proc/self/fd/<N>` bridge
  for native calls — see that class's own comment for the full mechanism.
- `batterySaveEntry()`/`stateSlotEntry()`/`stateThumbEntry()`/
  `quickStateEntry()`: thin wrappers over the existing (now "legacy",
  still the fallback) `batterySaveFile()`/`stateSlotFile()`/
  `stateThumbFile()`/`quickStateFile()`.
- `quickSaveState()`/`quickLoadState()`/`showSaveStateSlotDialog()`/
  `captureStateThumbnail()`/`backupIfExists()`/both `nativeLoadROM()` call
  sites (initial load + `resetGame()`): rewired from raw `File` to
  `SaveEntry`.
- `saveScreenshotBitmap()`: writes into the `screenshot` subfolder when a
  folder's chosen; unchanged `getExternalFilesDir()` fallback otherwise.
- New `showStorageSettings()` + a "Storage" row in the Settings menu.

---

# FILE_CHANGES — Nineteenth pass

## Modified

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** This pass's two log captures covered different real-world spans
with no quick way to tell how different, or why.
**What changed:** `copyLinkDebugLog()` now appends a `=== copied at
MM-DD HH:MM:SS.mmm ===` line (same layout as the log's own timestamps) to
the text before it's shown/copied.

### `app/src/main/cpp/mgba_jni.c`
**Why:** record-keeping only.
**What changed:** New FIX 19 entry in the top-of-file history noting
Eighteenth pass's fix showed no observed change in this capture, and
pointing at the MainActivity.kt change above. No logic changed in this
file this pass.

---

# FILE_CHANGES — Eighteenth pass

## Modified

### `app/src/main/cpp/mgba_jni.c`
**Why:** First real matched two-phone capture (see CHANGELOG.md/
KNOWN_LIMITATIONS.md) confirmed the network exchange is correct in both
directions, narrowing the still-open bug to the child ROM's own code.
Re-reading `nativeLinkChildExchange()` against that finding turned up a
gap the function's own comment already admitted: it never touched the
child device's own SIOCNT.
**What changed:**
- `nativeLinkChildExchange()`: after writing SIOMULTI0-3 and before
  raising the IRQ, now reads the child's current SIOCNT and refreshes
  bits 2 (child), 3 (ready), 4-5 (player ID), and clears bit 7 (busy) —
  preserving every other bit (mode, baud rate, IRQ-enable) exactly as the
  ROM last set it.
- Updated that function's own top comment (previously said it
  "deliberately does NOT touch SIOCNT"; no longer true).
- New FIX 18 entry in the file's top-of-file history comment.

---

# FILE_CHANGES — Seventeenth pass

## Modified

### `app/src/main/cpp/mgba_jni.c`
**Why:** `copyLinkDebugLog()`'s `logcat` dependency doesn't work on every
device (W's own two-phone split this pass — real output on one, nothing on
the other) and was blocking the one thing every pass since the Twelfth has
asked for: a synchronized two-phone capture. Separately, W's new
`wifi_host__1_.text`/`wifi_join__1_.text` captures (taken with Sixteenth
pass's exchange-result/child-exchange logging already in place) needed a
close read.
**What changed:**
- New includes: `<stdarg.h>`, `<stdio.h>`, `<time.h>`.
- `LOGI`/`LOGW`/`LOGE` macros now expand to a new `jni_log_line()` instead
  of calling `__android_log_print()` directly. Every existing call site in
  the file is unchanged — these are still plain macros.
- New: `g_link_log_mutex` (dedicated lock, never `g_core_mutex` — see its
  own comment for why reusing `g_core_mutex` would self-deadlock),
  `g_link_log_file`, `g_link_log_path`, `link_log_write_locked()`,
  `link_log_write()`, `jni_log_line()`. Together: every `LOGI`/`LOGW`/
  `LOGE` call now also appends a logcat-`threadtime`-formatted line to a
  private file, in addition to the normal `__android_log_print()` call
  (unchanged — Android Studio / a real debugger sees no difference).
- New: `Java_com_mgba_android_EmulatorEngine_nativeSetLinkLogPath()` —
  receives the file path from Kotlin once at startup, opens it in append
  mode.
- `nativeLinkStart()`: now re-opens the log file in truncate mode
  (`fopen(path, "w")`) at the start of every session, so a capture
  reflects one connection attempt.
- Top-of-file fix-history comment: added a FIX 17 entry covering both the
  logging infrastructure and this pass's reading of the new evidence
  (host/child value distributions, the re-check of FIX 9's bit2/bit3
  reflection, and an updated theory citing mGBA's own real lockstep
  implementation).
**Why this fixes it:** The logging change directly addresses "can't get
log on this device" — see FIX 17's own comment. It doesn't fix the
reported multiplayer bug itself; see KNOWN_LIMITATIONS.md for what this
pass's evidence actually shows and BUGS_FIXED.md for why this isn't
labeled a bug fix.
**Verification:** No NDK/Android SDK in this sandbox, as every pass — but
unlike every prior pass, this sandbox does have a plain `gcc`. The new
logging functions (`link_log_write_locked`, `link_log_write`,
`jni_log_line`, the macros, `nativeSetLinkLogPath`, and
`nativeLinkStart()`'s new truncate block) were extracted verbatim from the
edited file — not retyped — and compiled standalone against minimal
stand-ins for the Android/JNI-only pieces (`__android_log_print`, `JNIEnv`'s
`GetStringUTFChars`/`ReleaseStringUTFChars`), since the real NDK/mgba
headers aren't available here either. Compiled clean under
`gcc -Wall -Wextra -std=gnu11` (no explicit `C_STANDARD` is pinned in this
project's `CMakeLists.txt`, so this matches the NDK/Clang default
GNU-extended dialect rather than glibc's stricter plain `-std=c11`, which
does not expose `clock_gettime`/`CLOCK_REALTIME` without extra feature-test
macros — confirmed by hitting exactly that failure first and fixing the
*test's* dialect flag, not the real code, which needs no such fix under
the NDK). At runtime: opens the file, writes/reads back formatted lines
correctly, confirms a second `nativeSetLinkLogPath()` call appends rather
than truncates (per its own doc comment), and confirms `nativeLinkStart()`'s
new block does truncate. This is real verification of the new code's
syntax and logic that no prior pass in this project's history could do
("no compiler here" appears in nearly every previous pass's own
Verification section) — it is not a substitute for a real
`./gradlew assembleDebug` against the actual mgba/NDK headers, which
remains untested as always. Brace/paren counts on the full file checked
balanced before and after (68/68 braces, 363/363 parens).

### `app/src/main/kotlin/com/mgba/android/EmulatorEngine.kt`
**Why:** Kotlin-side declaration for the new native entry point.
**What changed:** Added `external fun nativeSetLinkLogPath(path: String):
Boolean` with a doc comment explaining when to call it and its
relationship to `nativeLinkStart()`'s truncation.
**Verification:** No Kotlin compiler in this sandbox. Signature matches
the JNI export name (`Java_com_mgba_android_EmulatorEngine_
nativeSetLinkLogPath`) exactly, following the same `Java_<package>_<class>_
<method>` pattern already proven by every other `external fun` in this
file (spot-checked against `nativeLinkStart`'s own export name). File-wide
brace/paren balance checked programmatically (comment- and string-aware,
not just a raw character count) — clean.

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** See `mgba_jni.c` above — this is the Kotlin half of the same
change.
**What changed:**
- `onCreate()`: added one `EmulatorEngine.nativeSetLinkLogPath(...)` call
  right after `link = LinkMultiplayer(this)`, passing
  `File(filesDir, "link_debug.log").absolutePath`.
- `copyLinkDebugLog()`: no longer builds a `logcat` `Process` at all — now
  just reads `File(filesDir, "link_debug.log")` directly. Simpler than
  what it replaced (no `ProcessBuilder`/stream-draining/`waitFor()`), and
  removes the only place in this project that shelled out to a system
  binary for this feature.
- `showLinkDebugLogDialog()`: empty-state message updated to describe the
  new mechanism instead of the old tag-filtered-window one, including a
  pointer to check Logcat for the file-open confirmation line if the file
  is unexpectedly still empty after a real attempt.
- Doc comments above both functions rewritten to describe the new
  mechanism and reference this pass.
**Verification:** No Kotlin compiler here. Single call site of
`copyLinkDebugLog()`/`showLinkDebugLogDialog()` each, both unchanged
(quick-menu item 9 still calls `copyLinkDebugLog()` the same way). File-wide
brace/paren balance checked programmatically — clean.

### `app/src/main/kotlin/com/mgba/android/LinkMultiplayer.kt`
**Why:** See `mgba_jni.c` above — Fifteenth pass's 7 connection-lifecycle
log lines were logcat-only; without also mirroring them into the new file,
the file-based tool would be strictly less capable than the old
logcat-based one for anyone whose logcat access does work.
**What changed:**
- New imports: `java.io.File`, `java.text.SimpleDateFormat`,
  `java.util.Locale`.
- New `linkLog(level, msg, throwable?)` private helper: calls the normal
  `Log.i`/`Log.w`/`Log.e` (unchanged behavior for anyone watching Logcat
  directly) and additionally appends a matching line to
  `File(context.filesDir, "link_debug.log")`.
- All 7 existing `Log.i`/`Log.w` call sites (the BYE-send logging in
  `disconnect()`, the "Disconnected" line, and `handlePeerLost()`'s
  "Peer connection lost" line) now call `linkLog(...)` instead. No call
  site's actual logged content changed — only the function they go
  through.
**Why this fixes it:** See CHANGELOG.md item 3.
**Verification:** No Kotlin compiler here. All 7 original call sites
confirmed replaced (`grep` for `Log\.` now only matches inside `linkLog()`
itself). File-wide brace/paren balance checked programmatically — clean.

---

# FILE_CHANGES — Sixteenth pass

## Modified

### `app/src/main/cpp/mgba_jni.c`
**Why:** W's three real logcat captures (first genuine evidence in sixteen
passes) showed real exchange activity but left two specific things
unanswerable: whether the host's rapid exchange attempts were getting real
replies or timing out, and whether the child's own receive path
(`nativeLinkChildExchange()`) was ever running at all.
**What changed:**
- `link_sio_write_register()`'s host-only exchange branch: added
  `LOGI("SIO exchange result: sent=... recv=... timedOut=...")` right after
  `link_exchange()` returns.
- `nativeLinkChildExchange()`: added `LOGW` on its early-exit branch
  (previously silent) and `LOGI` on every successful call, logging both
  `hostData` and `childData`. Previously had no logging at all.
- Top-of-file fix-history comment: added a FIX 16 entry summarizing what
  the three logs actually showed and the theory (unconfirmed) that fits.
**Why this fixes it:** It doesn't fix the reported bug — it closes the two
remaining diagnostic blind spots standing between "we have activity" and
"we know what the activity means." See FIX 16's own comment and
CHANGELOG.md items 1-2.
**Verification:** No compiler/device here, as every pass. Brace/paren
counts checked balanced before and after. Both additions are pure logging
— no control flow, register values, or return values changed.

### `app/src/main/kotlin/com/mgba/android/MainActivity.kt`
**Why:** `copyLinkDebugLog()`'s window (8000 lines, sized last pass against
boot noise) is short relative to real exchange activity's actual measured
rate this pass — `wifi_host.text` alone was 2243 lines in 1.67 seconds,
before this pass's two new trace points add more on top.
**What changed:** `logcat -t 8000` → `-t 20000`. Comment above the function
updated with the real measured numbers behind the bump.
**Why this fixes it:** See CHANGELOG.md item 3.
**Verification:** No compiler here. Single call site of the modified
function unchanged.

---

# FILE_CHANGES — Earlier passes (summary)

Full diffs trimmed for length. File(s) touched per pass, condensed:

- **Fifteenth** — `mgba_jni.c`, `LinkMultiplayer.kt`, `MainActivity.kt`:
  Sixteenth/Seventeenth pass's exchange-result/child-exchange trace
  logging groundwork, plus connection-lifecycle logging.
- **Fourteenth** — `MainActivity.kt`: compile-error fix only
  (`showLinkDebugLogDialog` parameter rename).
- **Thirteenth** — `MainActivity.kt`: save-state thumbnails.
- **Twelfth** — `MainActivity.kt`: original logcat-based "Copy link log"
  (superseded by Seventeenth pass's file-based version).
- **Eleventh** — `MainActivity.kt`: quick-menu tap regression fix.
- **Tenth** — `MainActivity.kt`: quick game menu restyle, Settings
  cleanup, immersive mode, display-cutout fix, Screenshot/Reset/Close.
- **Ninth** — `LinkMultiplayer.kt`: Wi-Fi host keepalive/liveness fix.
- **Eighth** — `mgba_jni.c`: trace logging only, no logic change.
- **Seventh** — `mgba_jni.c`: SIO IRQ raise (host + child).
- **Sixth** — `mgba_jni.c`, `EmulatorEngine.kt`, `LinkMultiplayer.kt`,
  `MainActivity.kt`: the original `nativeLinkChildExchange()` passive-
  responder fix, SIOCNT status bits, peer-disconnect detection,
  Bluetooth keepalive.
- **Fifth** — `LinkMultiplayer.kt`, `MainActivity.kt`,
  `AndroidManifest.xml`, `gradle.properties`, `README_SETUP.md`: first
  multiplayer-focused pass — thread-safety, socket cleanup, permissions.
