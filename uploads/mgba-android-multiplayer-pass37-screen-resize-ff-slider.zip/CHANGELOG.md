# CHANGELOG — Thirty-seventh pass

Six things reported together: the hold-for-speed-slider request repeated
(not built two passes ago), the game screen still not actually
resizable, a Z-order bug hiding the editor behind Settings, a request to
remove Fullscreen now that resize is real, 4x fast-forward feel/sound,
and Max frame skips flickering/flashing white. The white-flash one was a
real, confirmed bug — see BUGS_FIXED.md. Everything else here.

## 1. Fast-forward hold-for-speed-slider

**Category:** Feature (previously deferred, now built)
**Files modified:** `MainActivity.kt`
**What changed:** The »/fast-forward button no longer toggles the instant
it's touched. `ACTION_DOWN` now arms a delayed Runnable
(`ffLongPressPending`, same shape as the editor's own
`editLongPressPending`); if `ACTION_UP` lands on the button before the
long-press timeout, that Runnable is cancelled and fast-forward toggles
normally (a real tap). If the timeout fires first, `showFastForwardSpeedSlider()`
opens instead — a slider (0.5–16×, half-speed steps) with a live-updating
readout and a Done button, writing the same `fastForwardSpeed`/
`PREF_FF_SPEED` the Misc settings text field already does. Also removed
the "» 4×" speed-text that used to appear on the button while active —
the existing color/fill change already shows on/off state; the text was
a separate indicator reported as unwanted.
**Reason:** Requested directly (twice — see Thirty-fifth pass's own
deferral note).
**Side effects:** None to the toggle behavior itself for a normal tap —
still instant, just resolved on `ACTION_UP` instead of `ACTION_DOWN` now.
**Verification:** No compiler or device in this sandbox, as every pass.
Read-through only: confirmed the Runnable is cancelled via
`mainHandler.removeCallbacks()` on both the tap-resolves-first path and
the generic `else` branch (`ACTION_CANCEL`/stray events) other touch
state already gets cleared on, not just the happy path.

## 2. Game screen is now actually resizable/draggable

**Category:** Feature (completing something claimed finished before it
was)
**Files modified:** `MainActivity.kt`
**What changed:** The game screen is now a real participant in the same
editor every button already used, through the same generic id-keyed
machinery (`resolvedRect()`, `editRectFor()`, `hitTestEditable()`,
`labelFor()`, `resetSingleButton()`) rather than a parallel system of its
own — see the `gameScreenRect` field comment for the full reasoning.
`updateGameMatrix()` resolves `"gamescreen"`'s rect the same way any
button resolves its own, then fits/positions the GBA image within
*that* rect instead of a fixed top-left region.
`buildControlLayout()` now calls `updateGameMatrix()` internally at its
own end (removing three now-redundant external call-site pairs), so
`gameScreenRect` — and the actual rendered image — stays in sync with
every layout change, live drag/resize included, without threading a
second call through every one of `buildControlLayout`'s own call sites
individually. Long-press-to-remove is explicitly guarded against
`"gamescreen"` (see `showRemoveButtonMenu()`) — there's nothing sensible
"remove the game screen" would mean.
**Reason:** Requested directly; the previous pass had only fixed the
*navigation* into the editor, not made the screen draggable/resizable
once there (flagged as deferred at the time).
**Side effects:** None to button behavior — buttons' own resolution and
editing are completely unchanged, this only adds a new id alongside them
sharing the same machinery.
**Verification:** No compiler or device in this sandbox. Read-through
only: confirmed `editRectFor()`/`hitTestEditable()`/`drawEditOverlay()`
(the last one already generic via `editRectFor()`, needed no changes at
all) all correctly reach `gameScreenRect` for the new id; confirmed
`isButtonVisible("gamescreen")` resolves true by default (not in
`extraControlIds`, so it falls to the "not in `removedButtons`" branch,
and the long-press guard stops it from ever landing there); confirmed
`saveCustomLayout()`/`loadCustomLayout()` needed zero changes since they
already serialize the whole `customLayout` map generically by key.

## 3. Fixed: editor was invisible until Settings was closed first

**Category:** Bug fix
**Files modified:** `MainActivity.kt`
**Problem:** Tapping "Screen size" dismissed the Video popup and called
`enterEditMode()`, but never touched `settingsMenuOverlay` — the
Settings screen *underneath* that popup, a separate full-screen opaque
overlay — which stayed covering the editor that had, in fact, already
started right underneath it.
**Solution:** `settingsMenuOverlay.visibility = View.GONE` added
alongside the existing `dialog?.dismiss()`.
**Reason:** Reported directly ("you have to closed setting first to see
screen size or screen button customization").
**Expected improvement:** The editor (and its existing toolbar — Add
control, per-button Reset, Done/Discard — all of which likely read as
missing entirely while this bug made the whole screen unreachable) should
now actually be visible and usable the first time.
**Verification:** No compiler or device in this sandbox. Confirmed
`settingsMenuOverlay.visibility = View.GONE` is the exact same call its
own "✕ Close" button already uses elsewhere in this file, not a new,
unproven way of hiding it.

## 4. Fullscreen removed

**Category:** UX change (requested removal)
**Files modified:** `MainActivity.kt`
**What changed:** `fullscreenMode`, `CTRL_FRAC_FULL`, `PREF_FULLSCREEN`,
and every branch conditioned on them removed entirely — not hidden,
actually deleted (the controls-background rect now always draws; idle
alpha no longer has a fullscreen-only dim). The "Reset settings" handler
(Misc) also gained `stretchToFit`/`maxFrameSkips`/`linearFilterEnabled`,
which turned out to have been missing from it since they were added two
passes ago — an unrelated gap noticed while removing `fullscreenMode`
from that same list.
**Reason:** Requested directly, now that screen resize (item 2) is a
real substitute for what Fullscreen used to be the only way to get.
**Side effects:** Anyone with Fullscreen previously turned on will see
the game screen back at its plain default size after updating — a one-time
resize via the editor gets back to (or past) what Fullscreen used to give
directly.
**Verification:** No compiler or device in this sandbox. Grepped for
every remaining reference to all three removed symbols after the edit —
none left outside this pass's own explanatory comments.

## 5. Fast-forward at 4x and Max frame skips (My Boy comparison)

**Category:** Investigated / partially fixed
**Files modified:** `MainActivity.kt` (Max frame skips only — see
BUGS_FIXED.md for that one; nothing changed for fast-forward speed/audio
itself this pass)
**What happened:** Max frame skips' flickering was a real, confirmed bug
— fixed, see BUGS_FIXED.md. Fast-forward "4x is slow, sound a bit bad"
is the same territory investigated two passes ago (that pass's items 3–4),
now with a specific number attached rather than resolved further — see
KNOWN_LIMITATIONS.md for why this wasn't guessed at a third time either.

---

# CHANGELOG — Thirty-sixth pass

Scope note: one real bug, `MainActivity.kt` only, prompted by an actual
CI build-log attachment (run 1565 — Thirty-fifth pass's zip failed
`compileReleaseKotlin`, so nothing installable came out of it).

## 1. Fixed a real Kotlin compile error

**Category:** Bug fix (build-breaking)
**Files modified:** `MainActivity.kt`
**Problem:** `linearFilterEnabled` (Thirty-fifth pass's Linear filtering
feature) was read/written in four places but never declared — an
unchecked assumption that it already existed as a field alongside
`stretchToFit`/`maxFrameSkips`, based on seeing its *name* in a grep
result (a pref-load line and a doc comment) rather than an actual
declaration line for it specifically.
**Solution:** Added `@Volatile private var linearFilterEnabled = false`
next to `stretchToFit`/`maxFrameSkips`, matching their declaration style
exactly. No other change needed — every read/write site already had the
right shape for a plain `Boolean` field.
**Reason:** The user attached the actual GitHub Actions build log
showing `compileReleaseKotlin FAILED` with four `Unresolved reference:
linearFilterEnabled` errors, exact file/line/column for each.
**Expected improvement:** `assembleRelease` should compile again — this
was the only reported error in the log, and all four instances shared
the one root cause.
**Side effects:** None — a missing declaration doesn't have partial or
alternate behavior to preserve; adding it just makes the already-written
call sites work as originally intended.
**Verification:** No compiler in this sandbox, as every pass — verified
by reading the exact four file/line/column locations the real compiler
reported and confirming each now resolves to the new declaration, rather
than a fresh guess; whole-file brace/paren balance checked after the
edit (708 open/close braces, 3113 open/close parens).

---

# CHANGELOG — Thirty-fifth pass

Five screenshots this pass, comparing this app's Video settings against a
reference emulator's, plus a fullscreen crash report, a layout-reset
report, and the Turbo A/B size complaint continuing. Large pass — see
FILE_CHANGES.md for the full diff and KNOWN_LIMITATIONS.md for what's
deferred and why.

## 1. Video settings rebuilt to match the reference screenshots

**Category:** Feature + UX rework
**Files modified:** `MainActivity.kt`
**What changed:** `showVideoSettings()` rebuilt as a plain list (title +
optional gray subtitle per row, dividers) instead of one form with
everything crammed in. Two real, previously-unreachable features turned
out to already exist as fields/logic with zero UI wired to them —
**Stretch to fit screen** (`stretchToFit`, already implemented in
`updateGameMatrix()`) and **Linear filtering** (`linearFilterEnabled`,
had a field and a pref but nothing ever read it — the actual `drawBitmap`
call passed a plain `null` Paint, filtering permanently off regardless of
the setting; now uses a real `gamePaint` whose `isFilterBitmap` follows
it) — both just needed a checkbox. **Max frame skips** was the same
halfway state one level deeper: the field/pref/doc-comment describing the
intended behavior already existed, but the referenced
`maybeSkipRenderThisFrame()` didn't — implemented for real this pass (see
item 2). **Screen orientation** moved from an inline 5-option radio group
into its own popup (`showScreenOrientationDialog()`), matching the
reference's own popup styling — applies on tap, no separate Save. **Enable
OpenGL** and **GLSL Shader**, also in the reference, are deliberately
*not* included — this app's renderer has only ever been Canvas/
SurfaceView; there's no OpenGL path to switch to and no shader system,
and a checkbox that doesn't change anything would be worse than no
checkbox. **Fullscreen** (the previous screen's own checkbox) was kept
despite not appearing in the reference list — see item 4, it's not
redundant yet.
**Reason:** Requested directly, reference screenshots provided.
**Side effects:** None for existing saved prefs — `PREF_STRETCH`,
`PREF_MAX_SKIPS`, `PREF_LINEAR_FILTER` were already being read on every
launch, just never written to by anything in the UI; this pass adds the
first UI that can actually write them.
**Verification:** No compiler or device in this sandbox, as every pass.
Read-through only: confirmed all three "phantom" fields
(`stretchToFit`/`maxFrameSkips`/`linearFilterEnabled`) by grepping for
every reference to each, not just the one that prompted the search;
confirmed `gamePaint`'s single shared instance is mutated in place
(`updateLinearFilterPaint()`) rather than allocating a fresh Paint per
frame; whole-file brace/paren balance checked after all edits.

## 2. Max frame skips — implemented for real, wired into the normal-speed loop

**Category:** Feature (completing a half-built one)
**Files modified:** `MainActivity.kt`
**What changed:** The normal (non-fast-forward, `framesToRun == 1`)
branch of the game loop now tracks whether the *previous* iteration took
longer than one frame's budget (~16.67ms) and, if so and skip budget
remains (`consecutiveFrameSkips < maxFrameSkips`), calls
`nativeRunFrame(null)` instead of `nativeRunFrame(backBmp)` for this
frame — skipping the pixel blit only, not emulation or audio, reusing
the exact same null-bitmap fast path fast-forward's own sub-frame loop
already relies on. The buffer-publish step after it is unconditional
either way, so a skipped frame just leaves the previous frame on screen
for one more render cycle rather than corrupting anything.
**Reason:** Requested directly ("add max frame skip features can be set
to 0 to 10").
**Expected improvement:** On a slower device, normal (1x) play can drop
the expensive blit for a few frames to catch back up, rather than only
ever having that option during fast-forward.
**Side effects:** None at the default (0 — behavior identical to every
previous pass, `behindSchedule` is irrelevant when `maxFrameSkips` is 0
since the `&&` short-circuits). `consecutiveFrameSkips`/
`lastFrameLoopStartNs` reset every time the loop (re)starts, alongside
the existing `ffFrameAccumulator` reset, so stale state can't leak into
a fresh game session.
**Verification:** No compiler or device in this sandbox. Read-through
only: confirmed the buffer-publish `synchronized` block already runs
unconditionally regardless of whether a blit happened (checked its
actual code rather than assuming), which is what makes "skip the blit"
safe rather than needing its own separate handling; confirmed the skip
logic is scoped to `framesToRun == 1` only, so it can't interact with
fast-forward's own, differently-motivated skip-blit logic in the batch
branch.

## 3. Turbo A/B size — raised again

**Category:** Fix (second round of the same complaint)
**Files modified:** `MainActivity.kt`
**What changed:** Default size (`tSz`) raised 0.55x → 0.75x of a normal
A/B button; the resize scale cap (shared by every button, both the
toolbar +/- and the pinch gesture) raised 4x → 8x.
**Reason:** Reported as still too limited after an earlier pass had
already raised the cap once (2.5x → 4x) for this same complaint.
**Expected improvement:** Turbo A/B can now reach roughly 6x their old
default size (0.75 × 8) — comfortably past a normal A/B button's size if
wanted, rather than topping out just short of one.
**Side effects:** The higher cap applies to every button, not just Turbo
A/B — anyone resizing anything can now go bigger than before. Still
bounded, not literally unlimited.
**Verification:** No compiler or device in this sandbox. Confirmed both
`coerceIn` call sites (toolbar +/- and the pinch-resize gesture) were
updated together, not just one.

## 4. Fullscreen crash and lost layout edits — not fixed, crash log requested

**Category:** Investigated, not fixed
**Files modified:** none
**What happened:** Read through `applyLayoutSettings()`,
`buildControlLayout()`, and every `fullscreenMode`-conditional branch
looking for a crash-prone path. Didn't find one with high enough
confidence to act on. Separately, confirmed *why* a crash would also
explain "all the buttons I changed are gone": `saveCustomLayout()` is
only ever called from the edit-mode exit handler (`exitEditMode(save =
true)`) — layout edits aren't persisted until that explicit save, so a
crash before reaching it would lose whatever was mid-edit with no
separate bug required to explain that part.
**Why no code change:** No specific line to point at. This app already
has a built-in crash logger (see "Copy crash log" in the quick game
menu) — that's real data instead of another guess, and the efficient way
to actually find this one.

---

# CHANGELOG — Thirty-fourth pass

Four things reported in one message: cutout black area still present after
last pass, Turbo A/B feeling slow with an unwanted toggle, and fast-forward
described as laggy with weird sound. Two of these got real code changes
this pass; two got investigated and explained instead of guessed at a
third/second time — see each item and KNOWN_LIMITATIONS.md.

## 1. Turbo A/B moved off a toggle, sped up, labels fixed

**Category:** UX rework + fix (existing feature, not new)
**Files modified:** `MainActivity.kt`
**What changed:** The "⚡ Turbo A / Turbo B buttons" Settings checkbox
(added both together, all-or-nothing) is gone. `"ta"`/`"tb"` moved into
`extraControlIds`, the same individually opt-in-via-"+ Add control" system
`"abturbo"`/`"ab"`/etc. already used — each can now be added, positioned,
and removed independently. Their on-button label changed from `"T"` (both
buttons showed the identical letter, no way to tell Turbo A from Turbo B
by looking) to `"A"`/`"B"` respectively, matching how `"abturbo"` already
reuses its equivalent normal button's letter with red signaling "turbo."
`turboHalfPeriodMs` halved, 66ms → 30ms (≈7-8/sec → ≈16-17/sec).
**Reason:** Requested directly — toggle removal, label confusion, and
"its slow" were all named explicitly.
**Expected improvement:** Add just the one you want; tell them apart at a
glance; feels like an actual turbo button rather than a slow repeat.
**Side effects:** Anyone who'd previously turned the old checkbox on will
find Turbo A/B gone from their layout after updating (the old pref is
simply no longer read) — needs re-adding via "+ Add control", once, same
as adopting any other newly-available extra. Not a data-loss concern, no
saves/states involved, just a one-time re-add.
**Verification:** No compiler or device in this sandbox, as every pass.
Read-through only: confirmed `addButton()` already checks
`isButtonVisible()` internally for every id (checked its implementation
directly rather than assuming), so dropping the `if (turboButtonsEnabled)`
wrapper and calling it unconditionally is exactly the same pattern
`"abturbo"` already used successfully, not a new one; confirmed
`allControlIds()`'s special-cased `if (turboButtonsEnabled)` branch is
now fully redundant with `ids += extraControlIds` and removed rather than
left dead; confirmed `labelFor()` already had `"ta" -> "Turbo A"`/
`"tb" -> "Turbo B"` mapped (so the "+ Add control" menu needed no changes
of its own to show them correctly); confirmed removing the checkbox left
`showInputSettings()`'s local `prefs` variable unused and removed it too,
rather than leaving dead code; whole-file brace/paren balance checked
after all edits.

## 2. Fast-forward audio: better decimation filter

**Category:** Fix (audio quality during fast-forward)
**Files modified:** `MainActivity.kt`
**What changed:** `decimateForFastForward()` used plain box-filter
averaging (each output sample the equal-weighted mean of `factor` input
samples) — the function's own prior doc comment already called this "a
cheap stand-in for a proper low-pass filter." Replaced with the standard
filter-then-downsample shape: a one-pole low-pass runs once across the
whole accumulated block, then every `factor`th filtered sample is kept,
rather than trying to make the averaging do both jobs.
**Reason:** Reported as "sound is weird" alongside the fast-forward lag
complaint.
**Expected improvement:** Less aliasing (harsh/grainy high-frequency
content folding back down) and less of the muffled quality a box filter's
weak, non-flat passband adds — a cleaner-sounding pitch-up. The pitch-up
itself is unchanged and not a bug: speeding up audio this way inherently
raises its pitch (the "chipmunk" effect), same as it would on a tape
played fast, and this function was never trying to hide that.
**Side effects:** None expected for pacing/timing — `outPairs` (what
actually governs how much audio gets written and how long `writePcm()`
blocks for) is computed exactly the same way as before, `accumPairs /
factor`; only how each output sample's *value* is computed changed. CPU
cost is in the same complexity class as the box average it replaces (one
multiply-add per input sample either way), so this shouldn't make the
reported laggy feeling any worse.
**Verification:** No compiler or device in this sandbox, as every pass.
Read-through only: confirmed the filter runs continuously across
`accumPairs` samples rather than being reset per output (a continuous
IIR state is what makes it an actual low-pass rather than something more
like independent per-block averages again); confirmed the `alpha =
2/(factor+1)` conversion is a standard, well-established period-to-EMA
formula rather than an arbitrary constant; confirmed the caller
(`accumPairs > 0` before calling) already guarantees at least one sample
exists before the function reads `ffAccumBuffer[0]`/`[1]` to seed the
filter state; confirmed the `factor <= 1` early-return path (normal,
non-fast-forward speeds) is completely untouched.

## 3. Camera-cutout black area — not touched again this pass

**Category:** Investigated, not fixed a third time
**Files modified:** none
**What happened:** Still reported after Thirty-third pass's `ALWAYS` mode
upgrade. Read back through how the game screen itself is sized
(`updateGameMatrix()`) rather than guessing at the cutout mode a third
time, and found a real, separate, and quite plausible explanation: the
GBA's native 240×160 (3:2) image is scaled to *fit inside* the available
area preserving aspect ratio (`scale = min(sw/240, gameH/160)`), then
centered — on a modern phone's much wider-than-3:2 landscape screen, the
width term is essentially never the limit, so there's a real, expected,
correctly-computed black margin on the left and right of the game image
(pillarboxing) on every device with this app, cutout or not. If the
phone's cutout happens to sit within that margin — plausible, since
cutouts are usually near an edge and so is the pillarbox — "a lot of
black screen on camera notch area" could describe *that*, not a
cutout-handling gap at all, in which case neither this pass's nor last
pass's cutout-mode changes could ever have looked any different, working
correctly or not.
**Why no code change:** This is a real, different hypothesis from what
the last two passes acted on, not confirmed — and if it's right, there
isn't an obvious fix that doesn't mean stretching or cropping the actual
game image, both worse tradeoffs than the pillarboxing itself. Guessing a
third time on a description this general risked another cycle spent on
the wrong target. See KNOWN_LIMITATIONS.md for what would actually
resolve this.

## 4. Fast-forward "laggy" — investigated, no bug found

**Category:** Investigated, not fixed
**Files modified:** none
**What happened:** Read back through the entire fast-forward path in
`startGameLoop()` (the audio-write-blocking frame pacer, the batched
sub-frame loop, the skip-blit optimization for hidden sub-frames) and
`nativeRunFrame()`'s null-bitmap fast path in `mgba_jni.c` looking for a
concrete inefficiency. Didn't find one — both are already tuned about as
tightly as this design allows (documented across several earlier passes'
own FIX comments already in this code). The audio-blocking pacer's
correctness assumption is that emulating `factor` sub-frames takes *less*
wall-clock time than playing `factor` frames' worth of audio would at 1x
— true with CPU to spare, but if a device's CPU can't emulate faster than
that at the chosen fast-forward multiplier, the same blocking design that
paces normal 1x play smoothly will instead show up as real stutter,
because emulation itself becomes the bottleneck rather than the audio
buffer. Genuinely can't tell from a read-through alone whether that's
what's happening here, or something else — no profiler, no device.
**Why no code change:** No specific bug to point at and fix. See
KNOWN_LIMITATIONS.md for what would help pin this down further.

---

# CHANGELOG — Thirty-third pass

Two unrelated requests this pass: a reported black area around the
camera-cutout notch, and a live memory viewer (full description in
FEATURES_ADDED.md; this entry covers its mechanics too).

## 1. Camera-cutout black area — strengthened, not confirmed fixed

**Category:** Fix attempt (display cutout handling)
**Files modified:** `MainActivity.kt`, `RomBrowserActivity.kt`
**What changed:** MainActivity's existing cutout handling (added an
earlier pass) upgraded from `LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES`
to `LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS` on API 30+ (falling back to the
previous `SHORT_EDGES` on API 28–29, where `ALWAYS` doesn't exist).
`ALWAYS` is a strict superset of `SHORT_EDGES` — content is unconditionally
allowed into the cutout area, with none of `SHORT_EDGES`'s own conditions
— so this can only extend the drawable area further, never shrink it.
Separately, and more confidently: RomBrowserActivity — new this overall
changeset, so it never had *any* cutout handling — got the same
ALWAYS/SHORT_EDGES pair MainActivity now has, rather than being left on
the platform default.
**Reason:** Reported directly: "a lot of black screen on camera notch
area."
**Expected improvement:** Less unused black area around the cutout on
MainActivity; RomBrowserActivity should now handle it at all, where
before this pass it did nothing.
**Side effects:** None expected — `ALWAYS` only ever grants more drawable
area, never less, and the two Activities' handling is now consistent
with each other.
**Verification:** No compiler or device in this sandbox, as every pass —
and this one carries a genuine, stated uncertainty on top of that usual
caveat: `ALWAYS` is a real, correct strengthening of the cutout mode
regardless, confirmed against current Android documentation, but whether
it's the *complete* explanation for "a lot of black screen" (as opposed
to, say, aspect-ratio letterboxing being mistaken for it, or the
RomBrowserActivity gap being the larger part of what was actually seen)
isn't something this read-through can settle without a screenshot or a
device to compare against. See KNOWN_LIMITATIONS.md.

## 2. Live memory viewer

**Category:** Feature (see FEATURES_ADDED.md for the full description)
**Files modified:** `mgba_jni.c`, `EmulatorEngine.kt`, `MainActivity.kt`
**What changed:** New `nativeReadMemory()` (native) /
`EmulatorEngine.nativeReadMemory()` (Kotlin) reads live core memory via
`mCore.busRead8()`; a new overlay displays it as a hex dump, reachable
from the quick game menu's new "Memory" item.
**Reason:** Requested directly.
**Expected improvement:** Can now watch live GBA memory (party/battle
data, or anything else) change turn by turn without leaving the running
game.
**Side effects:** None to existing features — purely additive; the new
`busRead8()` calls happen only while the overlay is open and are held
under the same `g_core_mutex` every other core access already uses, so
they can't race with `nativeRunFrame()` on the game thread.
**Verification:** No compiler or device in this sandbox, as every pass.
Read-through only: confirmed `busRead8`/`busRead16`/`busRead32` are real,
current `mCore` function-pointer members (checked against mGBA's own
`src/core/cheats.c`, which reads memory through the identical
`core->busRead8(core, address)` call for its cheat system) rather than
assumed from memory of the API; confirmed every `g_core` access in the
new function is inside the lock, matching this file's existing
discipline; confirmed the quick game menu's new item was appended at the
end of the list (not inserted in the middle) so no other item's numeric
dispatch `when` case needed renumbering; whole-file brace/paren balance
checked on every touched file after all edits (`MainActivity.kt` 689/689
braces, `mgba_jni.c` 80/80 braces, all parens balanced too).

---

# CHANGELOG — Thirty-second pass

Follow-up on Thirty-first pass's delivery: remove the Root button, and
pushed back on the no-rotation compromise with a concrete counter-example
(My Boy's own file manager: Portrait for ROM selection, a different,
Settings-configurable rotation for gameplay). Full description in
FEATURES_ADDED.md; this entry covers the mechanics.

## 1. ROM browser split into its own Activity, statically locked to Portrait

**Category:** Feature/architecture (ROM browser presentation)
**Files modified:** `AndroidManifest.xml`, `MainActivity.kt`; new
`RomBrowserActivity.kt`, `RomZipUtils.kt`, `SharedUi.kt`.
**What changed:** ROM selection moved from an overlay inside
MainActivity's window to a separate `RomBrowserActivity`, declared
`android:screenOrientation="portrait"` in the manifest. No
`requestedOrientation` call exists anywhere in the new Activity.
MainActivity's role reduced to launching it and handling the result.
**Reason:** Requested directly, with a specific real-world counter-
example (My Boy) that the previous panel-only compromise didn't match.
**Expected improvement:** The actual Portrait-file-manager /
independently-oriented-gameplay behavior asked for, matching the
reference app, without the two previous attempts' runtime-rotation
crash risk — see below.
**Side effects:** `RomBrowserActivity` is a real screen transition now
(new Activity, not an overlay) — a system Activity transition animation
will play opening/closing it, where before this was instant (an overlay
visibility toggle). Minor visual change, not expected to matter, but
different from before. Back button behavior changed: it now navigates up
a folder before exiting, where previously there was no back-stack
participation for this screen at all (it was an overlay, not an
Activity) — see FEATURES_ADDED.md.
**Verification:** No compiler or device in this sandbox, as every pass.
Read-through only: grepped the entire codebase for every symbol that
should have moved (`romTreeUri`, `romTreePicker`, `PREF_ROMS_TREE_URI`,
`romBrowserStack`, `buildRomBrowser`, `zipContainsGba`,
`ensureBroadFileAccess`, etc.) to confirm no stray references were left
calling something that no longer exists in `MainActivity.kt`; separately
checked every import added or left over from earlier passes
(`android.os.Environment`, `android.provider.Settings`,
`java.io.BufferedInputStream`) for real usage beyond the import line
itself, removing three that had none; checked every import in all three
new files the same way, all used; six now-inaccurate comments (see
FILE_CHANGES.md for the full list) caught and rewritten rather than left
to describe code that no longer exists; whole-file brace/paren balance
checked on `MainActivity.kt` (652/652 braces, 2777/2777 parens) and each
new file individually (`RomBrowserActivity.kt`: 70/70, 259/259;
`RomZipUtils.kt`: 6/6, 29/29; `SharedUi.kt`: 2/2, 23/23); manifest XML
parsed successfully; confirmed the new/pristine file lists differ by
exactly the 3 new files, nothing else added or removed.

---

# CHANGELOG — Thirty-first pass

Follow-up feedback on Thirtieth pass's ROM browser delivery: wanted real
free navigation instead of the existing SAF-tree-scoped browsing, a
Portrait-only file manager screen, and mentioned the menus/browser
feeling laggy. Full description of what got built in FEATURES_ADDED.md;
this entry covers the mechanics and the two things that were *not* just
built as literally requested.

## 1. Free-roam file manager, replacing the SAF tree picker

**Category:** Feature (ROM browser navigation model)
**Files modified:** `AndroidManifest.xml`, `MainActivity.kt`
**What changed:** ROM browsing moved from `DocumentFile` over one
SAF-granted folder tree to plain `java.io.File` over all of local shared
storage, gated by a new permission flow (`ensureBroadFileAccess()` —
`MANAGE_EXTERNAL_STORAGE` on API 30+, `READ_EXTERNAL_STORAGE` below
that). See FEATURES_ADDED.md for the full file list.
**Reason:** Requested directly.
**Expected improvement:** Navigate anywhere in local storage without a
separate folder-granting step; likely addresses the reported "laggy
menus/file manager" too, since folder listing is now a direct local read
instead of a Binder call into Android's storage provider — the
pre-existing code already flagged that call as a possible lag source
(see the block comment above `openRomBrowserAtRoot()` before this pass,
and KNOWN_LIMITATIONS.md).
**Side effects:** First launch (or first ROM load after an update) now
prompts for a real permission — a system Settings screen on API 30+, not
just an in-app dialog — where before this feature needed no storage
permission at all. Documented as a deliberate, known trade-off, not an
oversight — see FEATURES_ADDED.md's note.
**Verification:** No compiler or device in this sandbox, as every pass.
Read-through only: confirmed the native ROM-loading call
(`EmulatorEngine.nativeLoadROM(tmp.absolutePath, savePath)`) already only
ever took plain paths, never a `Uri` or SAF-specific type, so
`stageRomFile()`/`zipContainsGba()`/`loadRomFromUri()` needed zero
changes — the new browser just calls the same `loadRomFromUri(Uri.fromFile(file))`
every other entry point already used; confirmed `deriveRomBaseName()`'s
existing `contentResolver.query()` + `try/catch` + `uri.lastPathSegment`
fallback chain handles a `file://` Uri correctly (the query throws or
returns nothing for a scheme with no registered ContentProvider,
falling through to `lastPathSegment`, which returns the decoded file
name); whole-file brace/paren count checked after all edits (726/726
braces, 3083/3083 parens).

## 2. Portrait-styled panel, not an actual forced rotation

**Category:** Feature (ROM browser presentation)
**Files modified:** `MainActivity.kt`
**What changed:** `buildRomBrowser()` now returns a dimmed-backdrop
`FrameLayout` with a centered, width-capped, rounded `panel` inside it,
instead of one edge-to-edge `LinearLayout`. No orientation API call
anywhere in this screen's code.
**Reason:** Requested as "force Portrait for file manager only" — built
as the safer alternative instead (see below), not the literal request.
**Expected improvement:** The portrait-list look, without reintroducing
the native RenderThread SIGABRT a real forced rotation caused on this
exact screen (found and reverted two passes before this one — see
BUGS_FIXED.md/CHANGELOG.md). That reverted attempt's own comment had
already named this panel approach as the safer route to revisit if
portrait selection mattered enough to come back to — it did, so this
pass built it.
**Side effects:** Not a literal device rotation, so anything that
specifically expected the *device* to report itself as portrait (none of
this app's own code does) wouldn't see that. Purely visual/layout.
**Verification:** No compiler or device in this sandbox. Read-through
only: confirmed no `requestedOrientation` call exists anywhere in
`buildRomBrowser()`, `openRomBrowserAtRoot()`, or the row/close/load
handlers — the exact call sites the reverted attempt used — so the
SIGABRT's specific trigger (a real surface reconfiguration in the middle
of other view work) has nothing to fire on here.

---

# CHANGELOG — Thirtieth pass

Feature request: make the ROM browser's `.zip` filtering content-aware
instead of name-only. Full description in FEATURES_ADDED.md; this entry
covers the mechanics.

## 1. ROM browser now verifies a `.zip` actually contains a `.gba` before listing it

**Category:** Feature (ROM browser filtering)
**Files modified:** `MainActivity.kt`
**What changed:** `refreshRomBrowserList()` no longer treats every `.zip`
in a folder as a ROM by name alone. Directories and bare `.gba` files
still render immediately; `.zip` files are now checked in the background
(`zipContainsGba()`, sharing its magic-bytes check with `stageRomFile()`
via new helper `isZipSignature()`) and only added to the list once
verified. A new generation counter (`romBrowserGeneration`) discards a
scan whose folder the user has already navigated away from by the time
it finishes.
**Reason:** Requested directly — see FEATURES_ADDED.md for the full
description and user-facing behavior.
**Expected improvement:** A ROMs folder that also holds a save-data
backup zip, a screenshot batch, or any other unrelated archive no longer
shows those as if they were games in the "Load game" list — only `.zip`
files that actually contain a `.gba` appear.
**Side effects:** None for directories or bare `.gba` files — that path
is byte-for-byte the same filter as before, same sort order. `.zip`
files now take an extra (background, non-blocking) content check before
appearing; a folder with many/large irrelevant `.zip` files will show its
real ROMs slightly later than a folder with few. See
KNOWN_LIMITATIONS.md.
**Verification:** No compiler or device in this sandbox, as every pass.
Read-through only: confirmed `stageRomFile()`'s own behavior and its one
caller (`loadRomFromUri()`) are unchanged — it now calls the extracted
`isZipSignature()` but performs the identical byte comparison; confirmed
`openRomBrowserAtRoot()`/`romBrowserUp()` (the only two callers of
`refreshRomBrowserList()`) needed no changes; whole-file brace count
checked before and after this pass's edits (713 open, 713 close both
times) and again after a follow-up fix to a doc-comment ordering slip
made during the edit itself.

---

# CHANGELOG — Twenty-ninth pass

User requested a code audit, then a deeper one, then asked to fix both
findings. Neither is the multiplayer bug this project has been chasing —
both are independent, real issues the audit surfaced along the way.

---

## 1. `mgba_jni.c` — close a pre-existing locking gap around g_link_obj/g_link_xchg_mid/g_link_is_host (FIX 23)

**Category:** Correctness (data race), low practical severity
**Files modified:** `mgba_jni.c`
**What the audit found:** These three globals are read under `g_core_mutex`
everywhere else (`link_sio_write_register()`, called from `nativeRunFrame()`
while it holds the lock) but were written *outside* the lock in both
`nativeLinkStart()` (before it was ever taken) and `nativeLinkStop()`
(after it was released) — the one gap in an otherwise-consistent
"always under g_core_mutex" rule for this file's globals. Present since
FIX 7/8 introduced these globals; not something any of the recent passes
introduced.
**The fix:** Both functions now write all three only while holding
`g_core_mutex`. `GetObjectClass()`/`GetMethodID()` stay outside it (pure
JNIEnv reflection, touch no shared state); only the resulting method ID
and global ref, plus `is_host`, move inside. One small, deliberate
behavior refinement along the way: previously, on `nativeLinkStart()`'s
`!g_core` failure path, `g_link_xchg_mid` could be left holding a
freshly-resolved, valid method ID while `g_link_obj` was NULL (the old
code cleared `g_link_obj` unconditionally at the very top, before the
`g_core` check existed). Now all three are only ever written together, so
there's no window where they're inconsistent with each other.
**Practical risk:** Low. Pointer- and bool-sized writes are naturally
atomic on ARM, so this was never likely to produce an actual torn read —
but it was genuine unsynchronized concurrent access by the letter of the C
standard, worth closing once found rather than leaving on the books.
**Verification:** No device or compiler in this sandbox, as every pass.
File-wide brace/paren balance checked before and after (comment- and
string-aware, same script every C-file pass has used).

## 2. `MainActivity.kt` — extend the quicksave-race guard to the slot-picker dialog (FIX, audit pass)

**Category:** Correctness (race condition), same class as a bug already
fixed once in this file
**Files modified:** `MainActivity.kt`
**What the audit found:** An earlier pass added `quickStateBusy` (an
`AtomicBoolean` guard) specifically because `quickSaveState()`/
`quickLoadState()` used to spawn unsynchronized background Threads with no
ordering between overlapping calls — a fast double-tap could load stale
data or land saves out of order. `showSaveStateSlotDialog()`'s own
save/load action had the exact same unguarded pattern and was never given
the same guard. Narrower to actually hit (the dialog dismisses itself
after one tap, so it takes two separate menu visits in quick succession
rather than one fast double-tap on an always-visible button) but
identical underlying race.
**The fix:** Renamed `quickStateBusy` → `saveStateBusy` (its scope is no
longer just the "quick" operations) and added the same
`compareAndSet(false, true)` guard, with a `try/finally` that always
clears it, to the slot dialog's save/load `Thread`. One shared flag
across all three call sites (quick save, quick load, slot save/load) was
chosen over a second, separate flag so a quick-save can't race a
slot-load either — the two would need to know about each other to close
that gap otherwise, which is more state for no real benefit.
**Verification:** No device or compiler in this sandbox. Checked the
edited region's brace/try/finally nesting by hand, plus a whole-file
naive brace count (697 open, 697 close) as a smoke test — not fully
reliable for Kotlin string templates in general, but a meaningful signal
given the edit itself didn't touch any string literals.

---

# CHANGELOG — Twenty-seventh pass

User tested against Dragon Ball Z: Supersonic Warriors with a fresh matched
capture, and confirmed directly that the communication error appears
during the quiet stretch after the initial handshake burst — well before
this file's own ~11.5s retry gives up.

---

## 1. `mgba_jni.c` — log raw SIO mode changes independent of the active per-mode driver (FIX 22)

**Category:** Diagnostic, not a fix
**Files modified:** `mgba_jni.c`
**What the new capture shows:** Same shape as the Twenty-sixth pass's own
capture — a burst of real handshake data, then both sides write
`SIOCNT=0x2003` (Start cleared) within 65ms of each other and go silent
until a restart ~11.5s later. FIX 21 didn't change this shape, which rules
out pacing as the cause. New this pass, confirmed by the user: the
communication error is already showing on screen during that quiet
stretch, well before this file's own retry timeout — something is failing
faster and on different grounds than anything this driver currently tracks.
**The theory:** Checked GBATEK's actual documented Multi-Player procedure
(gbatek-sio-multi-player-mode). It documents that a child can signal
"not ready" by temporarily leaving Multi-Player mode entirely — not via any
bit this driver inspects. `link_sio_write_register()` is only ever
registered for `SIO_MULTI` (FIX 7), matching how every real per-mode SIO
driver in mGBA's own source is scoped to one mode — so a ROM taking that
exact documented exit would go completely unlogged by this file until it
switches back, and every "restart" logged since the Sixteenth pass might
be exactly that, not a failed-and-retried negotiation. This driver also
never relays *mode*, only actual Multi-Player transfers, so even where the
theory is right, the other device has no way to see its partner's signal.
**What this pass does:** Not the fix — the safe way to check the theory.
Rather than adding `init`/`load`/`unload` driver callbacks (a real option,
deliberately not taken — their exact signature isn't something this
sandbox can verify, and FIX 7's own comment already records getting bitten
by exactly this category of mistake once, on `GBASIOSetDriver()`'s own
argument count), `nativeRunFrame()` now reads `sio.rcnt`/`sio.siocnt`
straight off the core directly and logs on any change — bypassing the
per-mode driver question entirely, since these are plain fields on a
struct this file already dereferences successfully elsewhere.
**Expected outcome:** If the next matched capture shows an "SIO mode" log
line moving away from Multi-Player's own selection during the quiet
stretch, that confirms the theory and justifies the driver-callback
approach next. If `rcnt`/`siocnt` sit still through the whole stretch, the
theory is wrong and this was a cheap way to rule it out.
**Verification:** No device or compiler in this sandbox, as always. Unlike
FIX 20/21's pacing math, this isn't pure arithmetic that can be tested
standalone — it's a struct field read whose only real verification is
whether it compiles against the pinned mGBA headers, which happens in CI.
File-wide brace/paren balance checked before and after, as every pass.

---

# CHANGELOG — Twenty-sixth pass

User tested FIX 20 on a real device and sent back a fresh matched capture,
then separately reported trying Dragon Ball Z: Supersonic Warriors and
getting an instant "communication error" plus noticeable in-game lag.

---

## 1. `mgba_jni.c` — bound FIX 20's pacing to a short per-attempt window (FIX 21)

**Category:** Refinement of an experimental diagnostic, still not a
confirmed fix
**Files modified:** `mgba_jni.c`
**What the new capture shows:** Real movement for the first time in this
project's history — the child's own SIOMLT_SEND is no longer stuck at only
`0x0000`/`0xFEFE`; it's now writing genuinely varying values, and the
~200ms restart loop documented since the Sixteenth pass is gone, replaced
by full attempts ~15-17s apart. Each attempt still ends in a new stall
(both sides write SIOCNT with Start cleared and sit for several seconds)
before restarting — a different, previously-invisible bottleneck.
**What the user separately reported:** Dragon Ball Z: Supersonic Warriors —
a real-time fighting game, far less tolerant than a slow retry-based
handshake — fails instantly with "communication error" and lags visibly.
No capture from that specific attempt, but consistent with FIX 20's own
documented cost: an unconditional ~16.74ms added to every host-triggered
exchange for the whole session, with no way to turn itself off.
**The fix:** Not a fix — a refinement of FIX 20's experiment. Pacing is now
bounded to a 3-second `LINK_PACE_WINDOW_NS` grace window, armed once at
session start and re-armed on every local RCNT write (i.e. every
negotiation restart, per every capture on file). Outside an armed window —
an established connection, exactly where a real-time game would be during
actual play — `link_pace_exchange()` is a single boolean check, identical
in cost to FIX 20 being off. See `mgba_jni.c`'s FIX 21 comment for the full
reasoning and exactly which capture the 3s figure comes from.
**Reason:** The aliasing/timing theory looks confirmed by the first result
(nothing else in 20 fixes had ever moved the child past two placeholder
values) but applying it as a flat, whole-session cost is too blunt — it
risks trading one game's stuck handshake for another game's broken
real-time play. Bounding it to short per-attempt windows keeps the
demonstrated benefit without the standing tax.
**Verification:** No device in this sandbox, as always. The windowed
pacing logic (arm/expire/re-arm, and that only the exchanges genuinely
inside the window ever sleep) was extracted verbatim and compiled
standalone against a controllable fake clock — 5 scenarios (unarmed,
armed-matches-FIX-20, expiry stops sleeping and clears the flag, a
400-call burst spanning the boundary only paces the ~179 calls actually
inside it, re-arming after expiry starts a fresh window) all passed under
`gcc -Wall -Wextra -std=gnu11` with zero warnings. File-wide brace/paren
balance checked before and after.
**Not answered by this pass:** Whether 3s is the right window, whether the
new SIOCNT=0x2003 stall is the next real bottleneck, and whether Dragon
Ball Z: Supersonic Warriors' failure was really pacing latency or
something else about that ROM — all need a real device and, ideally, a
capture from that specific game.

---

# CHANGELOG — Twenty-fifth pass

User-reported, with a fresh matched host+child capture (`log.text`/
`logt.text`, 07-17) attached: multiplayer still doesn't work, and — new
information, not previously on file — confirmed the same ROM's multiplayer
works outside this app, ruling out "this specific ROM's own link code is
unusual" as an explanation for the first time in this project's history.

---

## 1. `mgba_jni.c` — experimental exchange pacing (FIX 20)

**Category:** Diagnostic experiment, not a confirmed fix
**Files modified:** `mgba_jni.c`
**What the new capture shows:** Identical to FIX 18/19's evidence, unchanged
across ten passes and five unrelated feature passes in between: the child's
own SIOMLT_SEND is still only ever `0x0000`/`0xFEFE`, and its own RCNT/SIOCNT
setup sequence still restarts roughly every 200ms (194-209ms apart across
five resets in this capture), while the host's own outgoing data still
arrives at the child correctly and varying, exactly as it always has.
**What's new:** With the ROM ruled out by the user directly, the bug has to
be in this app's own link implementation. That re-focuses attention on the
theory named since the Seventeenth pass but never acted on: this driver
resolves every transfer as one instantaneous blocking network round-trip,
with nothing pacing completion against real per-transfer cycle cost
(`GBASIOCyclesPerTransfer`, cited since FIX 10) — and `nativeLinkChildExchange()`
runs on a background thread with no correlation to when the child's own CPU
actually gets to execute, so at the observed exchange rate (hundreds/second)
roughly a dozen updates can land, each overwriting the last, for every
single frame's worth of CPU time the child ROM gets to run in.
**The fix:** Not a fix — a bounded, reversible experiment. `link_pace_exchange()`
makes a host-triggered exchange wait until at least one emulated GBA frame
(~16.74ms) has passed since the previous one before starting the network
round-trip, so the child's CPU gets a real chance to observe each exchange
before the next one lands. Toggleable via `LINK_PACE_EXCHANGES` (on by
default); set to 0 for this file's exact prior behavior. See `mgba_jni.c`'s
own FIX 20 comment for the full reasoning, including why a fully correct
fix (real `mTiming` scheduler integration) is not attempted here.
**Reason:** Every prior pass that named the timing-architecture theory
declined to test it, for lack of a way to check it without a device. This
gives the user a cheap, single-toggle way to test it on a real device
without this project taking on a full scheduler-integration rewrite blind.
**Expected outcome:** One of two informative results, either of which moves
this forward. If the ~200ms reset and the 0x0000/0xFEFE ceiling persist
unchanged with pacing on, the aliasing theory is very likely wrong (or not
the whole story), and the next pass should look elsewhere. If either
changes, that's real evidence to justify real scheduler integration next.
**Side effects:** Adds up to ~16.7ms of latency per host-triggered exchange
when the network reply would otherwise have arrived faster than that — on
top of the network round-trip's own latency, not instead of it. No effect
on the child role's own code path. No effect on data correctness — every
byte exchanged is identical to before, only the timing of when the next
exchange is allowed to start changes.
**Verification:** No Android/NDK toolchain or device in this sandbox, as
every pass. The pacing/interval math (GBA frame length → nanoseconds,
sleep-remaining-time logic, reset-on-reconnect) was extracted verbatim and
compiled standalone against a controllable fake clock (not real
`clock_gettime`/`nanosleep`, which need a real device to observe) — five
scenarios (first exchange, back-to-back, late-arriving, half-elapsed,
ten-in-a-row) all passed under `gcc -Wall -Wextra -std=gnu11` with zero
warnings. File-wide brace/paren balance checked comment- and string-aware
before and after. This confirms the arithmetic and control flow are correct
in isolation — it does not confirm the fix changes the reported symptom,
which (as with every pass in this project) needs a real device to know.

---

# CHANGELOG — Twenty-fourth pass

User-reported: the menu-based Save State/Load State flow (as opposed to
the Quick Save/Quick Load buttons fixed last pass) feels slow in two
places — the slot-picker dialog taking a moment to appear, and picking a
slot taking a moment to confirm.

---

## 1. `MainActivity.kt` — slot thumbnails cached in memory

**Category:** Performance
**Files modified:** `MainActivity.kt`
**What was wrong:** `showSaveStateSlotDialog()` re-read and re-decoded
every slot's PNG thumbnail from disk on *every single open*, even when
nothing about that slot had changed since the last time the dialog was
shown. On repeat opens — exactly what fast save/load testing does — this
was pure wasted disk I/O and PNG decode work.
**The fix:** Added `slotInfoCache`, an in-memory `ConcurrentHashMap` keyed
by ROM name + slot number, holding each slot's already-decoded `SlotInfo`.
A slot is only re-read/re-decoded when its `exists`/`lastModified()` no
longer match what's cached — i.e. only when it's actually stale, which in
practice means right after a save to that slot. Keyed by ROM name as well
as slot number since slot *numbers* repeat across ROMs but point at
different underlying files.
**Confidence:** High — this only removes redundant, correctness-neutral
work; the freshness check still falls back to a full re-decode any time
the underlying file has actually changed.

---

## 2. `MainActivity.kt`/`SaveEntry` — backup-before-save now a rename, not a copy

**Category:** Performance
**Files modified:** `MainActivity.kt`
**What was wrong:** `backupIfExists()` (called right before every save,
by both Quick Save and the menu's Save State) read an existing slot's
full bytes and wrote them out again to the `.bak` sibling — immediately
before `nativeSaveState()` was about to overwrite that same original file
anyway. That's up to 2x a save-state's worth of disk I/O for every single
save, all of it before the confirmation toast could fire.
**The fix:** Added `SaveEntry.moveInto()`. When no Storage folder is
configured (the common case), the backup is now a single
`File.renameTo()` — an instant, metadata-only move on the same volume —
instead of a byte-for-byte copy. Falls back to the old copy behavior if
the rename fails, or whenever a Storage folder IS configured (no
equivalent plain rename via `DocumentFile`).
**Confidence:** High for the internal-storage path (the default); the
Storage-folder path is unchanged from before, so no regression risk
there.

---

# CHANGELOG — Twenty-third pass

User-reported (from fast save/load testing): Quick Save/Quick Load
sometimes "saved on a different frame" than expected, and sometimes
appeared not to save at all when tapped quickly.

---

## 1. `MainActivity.kt` — quickSaveState()/quickLoadState() race fixed

**Category:** Bug fix (data race)
**Files modified:** `MainActivity.kt`
**What was wrong:** Every tap of Quick Save or Quick Load spawned a brand
new, totally unsynchronized `Thread`. `g_core_mutex` on the native side
only serializes the moment of the actual file write/read against the
running game thread — it says nothing about which Kotlin thread reaches
that point first. A fast double-tap of Quick Save, or Quick Save followed
immediately by Quick Load, raced: whichever thread happened to win the
mutex first went first, regardless of tap order. A Load that won the race
before a pending Save had written could read the file from before that
save (looks like "loaded the old/first save"); two Saves landing in
either order looks like "saved a different frame" than the one actually
displayed at the moment of the tap.
**The fix:** Added a shared `AtomicBoolean` busy-guard around both
functions. A tap that arrives while a prior quicksave/quickload is still
in flight is now a no-op with its own toast, instead of spawning a second
racing thread. Confirmed: `nativeSaveState()` already opens with
`O_TRUNC` (see `mgba_jni.c`), so an existing slot is always fully
replaced, never appended to or left partially overwritten — the
"different frame" symptom was the race above, not a failure to replace
the slot.
**Confidence:** The race is definite from the code (no lock, no debounce,
two independent Threads touching the same file/native calls). Not
re-confirmed on a real device this pass — no Android toolchain here.

---

# CHANGELOG — Twenty-second pass

Two user-reported issues, both in `MainActivity.kt`: a stray "Load ROM"
button rendering on top of the ROM browser it was supposed to sit behind,
and Save State feeling slow — the confirmation toast wasn't showing up
until well after the state had actually finished saving.

---

## 1. `MainActivity.kt` — floating "Load ROM" button removed

**Category:** Bug fix (visual — matches a screenshot showing the button
floating over the ROM browser's file list)
**Files modified:** `MainActivity.kt`
**What was wrong:** The purple "▶ Load ROM" `Button` sat behind
`romBrowserOverlay`/`settingsMenuOverlay` in add order (added to `root`
first), but a stock Material `Button` carries a small default elevation
even with nothing explicitly setting one. Android draws children with
non-zero elevation above children with zero elevation regardless of add
order once any Z-order is involved, so the button rendered ON TOP of the
overlays that were supposed to cover it — visible as a stray purple pill
hovering over the ROM browser's file list, exactly as reported.
**The fix:** Removed the button outright rather than patching its
elevation. `changeRom()` already auto-opens the ROM browser on first
launch and on Close (`closeGame()`), which covers the button's main
purpose already. Its other purpose — a way back into ROM selection when
the folder picker gets cancelled before any folder's chosen, or a ROM
load fails — is now handled by `onGameTouch()`: tapping the idle
(no-ROM-loaded) surface calls `changeRom()` directly. No button, no
elevation, no Z-order conflict possible.
**Confidence:** The elevation-over-opaque-sibling explanation matches
Android's own documented Z-order behavior and matches the reported
screenshot exactly (button visible mid-screen, over the file list, below
where "Use system file picker instead" sits). Not re-confirmed on a real
device this pass — no Android toolchain here — but removing the view
entirely can't reproduce a Z-order bug that only existed because the view
was there.

---

## 2. `MainActivity.kt` — Save State confirmation no longer waits on the thumbnail

**Category:** Bug fix (perceived performance — reported as "doesn't save
instantly")
**Files modified:** `MainActivity.kt`
**What was wrong:** In `showSaveStateSlotDialog()`'s save path, the
"Saved to Slot N" toast fired AFTER `captureStateThumbnail(slot)`
completed, not right after the actual state write. That thumbnail capture
waits on `PixelCopy.request()` (up to a 500ms `CountDownLatch.await()`),
then scales and PNG-encodes a full-screen bitmap — all of it fully
blocking, even though the save itself was already done and safely on disk
before any of it started. Every Save State via the slot dialog felt
delayed by however long that took. (The one-tap 💾 quicksave button —
`quickSaveState()` — never had this problem; it doesn't capture a
thumbnail at all.)
**The fix:** Reordered so the confirmation toast fires immediately after
`nativeSaveState()`/`nativeLoadState()` returns, and
`captureStateThumbnail()` runs afterward, still on the same background
thread but no longer gating the confirmation. The slot list just won't
show a brand-new thumbnail until it's next opened; the save itself is no
longer perceived as slow.
**Confidence:** The 500ms figure is read directly from
`captureStateThumbnail()`'s own `latch.await(500, TimeUnit.MILLISECONDS)`
call, so the worst case this fix removes from the confirmation's critical
path is exact, not estimated. Not verified against a real device's actual
felt latency this pass — no Android toolchain here — but the reorder
itself can't change save correctness, only when the toast fires relative
to work that was already happening.

---

# CHANGELOG — Twenty-first pass

Bug fix, real-device-reported: the Twentieth pass's Storage folder feature
broke save/load once someone actually tested it on a phone — reported as
"doesn't save and load" after turning that feature on. Root cause and fix
below; no new feature this pass.

---

## 1. `MainActivity.kt` — SAF native-fopen bridge replaced

**Category:** Bug fix (confirmed on real device this pass; Twentieth pass's
version of this was flagged in KNOWN_LIMITATIONS.md as unconfirmed)
**Files modified:** `MainActivity.kt`
**What was wrong:** `SaveEntry.nativePath()` bridged a SAF document to
native code via `/proc/self/fd/<N>` — reopening a `ParcelFileDescriptor`'s
fd as a plain path and handing that straight to `VFileOpen()`, including
for the battery save, which the core mmaps for the entire ROM session.
Nothing guarantees a re-opened SAF fd supports mmap/seek/`O_TRUNC` the way
native code needs — that's provider-specific — and a real-device test this
pass showed it doesn't hold up: saves and states appeared to go somewhere,
but loading them back either failed or didn't reflect what was saved.
**The fix:** Native code no longer touches a SAF document directly. It
always `fopen()`s a plain file under this app's own internal storage —
exactly as before the Storage-folder feature existed — and Kotlin copies
bytes to/from the chosen folder's document on either side of that call,
using `ContentResolver`'s stream APIs (`openInputStream`/`openOutputStream`),
which every `DocumentsProvider` is required to support. See
`SaveEntry.stageForRead()` / `stageForWrite()` / `commitWrite()` for the
one-shot save-state/quicksave/thumbnail case, and `batteryMirrorPath()` /
`syncBatteryMirror()` for the session-long battery save (synced out at
`onPause()`, before swapping to a different ROM, on `closeGame()`, and as a
last-resort in `onDestroy()`).
**Confidence:** Removes a specific, real failure mode confirmed this pass.
Still not run against every possible DocumentsProvider (cloud-storage-backed
folders in particular) — see KNOWN_LIMITATIONS.md — but no longer depends on
provider-specific mmap/seek/truncate behavior at all, only on the stream
APIs every provider must implement.

---

# CHANGELOG — Twentieth pass

New feature, unrelated to the link/multiplayer work above — user-chosen
Storage folder for saves/states/screenshots, so they can live somewhere
visible in a file manager instead of only under this app's own internal
storage (`Android/data/...`).

---

## 1. `MainActivity.kt` — Storage folder (Settings → Storage)

**Category:** Feature
**Files modified:** `MainActivity.kt`
**What it does:** A new Settings row lets the user pick a folder (system
folder-picker/SAF — same mechanism the ROM browser already uses, see
`romTreePicker`, just with write access too). Once set, three subfolders
appear inside it — `save`, `cheat`, `screenshot` — and every battery save,
save-state, state thumbnail, quicksave, and screenshot goes there instead
of internal storage from that point on. `cheat` is provisioned but unused
— there's no cheat feature yet to write into it (see the "Cheats" menu
entry, still "not implemented yet").
**Why SAF, not a plain hardcoded path:** the obvious alternative
(`MANAGE_EXTERNAL_STORAGE`, giving raw `java.io.File` access anywhere)
was already deliberately rejected for the ROM browser for reasons that
apply just as much here — see that feature's own comment. The wrinkle
specific to this feature: `nativeSaveState()`/`nativeLoadState()`/
`nativeLoadROM()`'s save path all need a real fopen()-able path string,
which a SAF document's `content://` URI isn't. Bridged via
`/proc/self/fd/<N>` — open a `ParcelFileDescriptor` for the SAF document,
hand native code that path instead, close the descriptor once native code
has opened its own independent handle. No native code changed at all.
**No migration:** switching folders does not move whatever already exists
under internal storage — only new saves/states/screenshots go to the new
location. Stated plainly in the Settings screen itself before anyone taps
"Choose folder" — see KNOWN_LIMITATIONS.md for why automatic migration
isn't attempted.
**Verification:** No Android toolchain in this sandbox (unchanged
constraint every pass). Brace/paren counts checked directly. The
`/proc/self/fd/` bridge itself is a well-known, long-used technique for
this exact SAF/native-fopen mismatch, but not confirmed against a real
device/provider here — see KNOWN_LIMITATIONS.md.

---

# CHANGELOG — Nineteenth pass

Negative result, not a fix — re-tested Eighteenth pass's SIOCNT-mirroring
change against a real matched capture. No observed change: the child's own
`childData` is still only ever `0x0000`/`0xFEFE`, same as every capture
back to the Sixth pass. Not reverted — it's still correct on its own terms,
just not the fix for this ROM.

Also added: `copyLinkDebugLog()` now appends a `=== copied at
MM-DD HH:MM:SS.mmm ===` line to the exported text, so two phones' captures
can be time-aligned by eye. Prompted by this pass's two logs covering
different real-world spans — turned out to be expected (host logs ~3
lines per SIO exchange, child ~1, so the same 40,000-character cap holds
less real time on the host side), not a bug, but there was no quick way to
confirm that from the logs alone before now.

---

# CHANGELOG — Eighteenth pass

Scope note: `mgba_jni.c` only. First pass with a real matched capture — two
link logs, one per phone, from the same connection attempt (timestamps
overlapping to the second) instead of minutes apart, made possible by
Seventeenth pass's logcat-independent logging.

---

## 1. `mgba_jni.c` — child's own SIOCNT never reflected transfer completion

**Category:** Bug fix
**Files modified:** `mgba_jni.c`
**Problem:** Cross-referencing the new matched capture confirmed the
network layer is not the issue — the host's live, changing outgoing data
correctly reaches the child (visible as `hostData` in its exchange log),
and the child's own data correctly reaches the host (`recv`), both
directions, from a real simultaneous pair for the first time. That leaves
the child ROM's own code as the only place still unaccounted for. Reading
`nativeLinkChildExchange()` end to end turned up a gap it already
self-documented: it writes the SIOMULTI0-3 data registers and raises the
SIO IRQ, but never touched the child device's own SIOCNT. GBATEK documents
Multi-Player SIOCNT bit 7 (Start/Busy) as a hardware-mirrored reflection of
the parent's clock line on every connected unit, not something a child's
CPU sets — polling it to notice "a transfer just landed" is a normal
technique alongside, or instead of, IntrWait on the IRQ this file already
raises. A child ROM using that technique would see a flat, never-changing
value here, regardless of the IRQ or data registers already being correct.
**Solution:** `nativeLinkChildExchange()` now reads the child's current
SIOCNT, refreshes bits 2 (child), 3 (ready), 4-5 (player ID), and clears
bit 7 (busy) after every exchange, preserving every other bit (mode, baud
rate, IRQ-enable) exactly as the ROM last set it.
**Reason:** Closes a gap the code already admitted to itself in a comment,
cross-referenced against GBATEK — not a new guess about either test ROM's
internals.
**Expected improvement:** If either test ROM polls SIOCNT bit 7 to detect
new data (a common pattern alongside or instead of the IRQ), it should now
see it, instead of a flat value indistinguishable from "no cable."
**Side effects:** None on the host path — this only touches the child-role
function. Preserves mode/baud/IRQ-enable bits rather than clobbering them.
**Verification:** No Android toolchain in this sandbox (unchanged
constraint every pass). Brace/paren count checked directly (69/69, 645/645
across the whole file). Not confirmed on a real device — see
KNOWN_LIMITATIONS.md.

---

# CHANGELOG — Seventeenth pass

Scope note: `mgba_jni.c`, `EmulatorEngine.kt`, `MainActivity.kt`,
`LinkMultiplayer.kt`. Prompted by two things in the same message: "still
doesn't work multiplayer" (expected — see KNOWN_LIMITATIONS.md for what
this pass's new evidence actually shows) and "can't get log on this
device, only on other device" — the exact logcat-access split Sixteenth
pass flagged but didn't fix, now confirmed to still be blocking things.

1. **Durable, logcat-independent link debug logging.** `copyLinkDebugLog()`
   used to shell out to `logcat`, which reads back a process's own output
   fine on stock Android but which some OEM builds restrict further — W's
   own two-phone split (real output on one, nothing on the other, same
   build) is direct evidence of that, not of a bug in this app. Every
   `LOGI`/`LOGW`/`LOGE` in `mgba_jni.c` now also writes to a plain private
   file under this app's own `filesDir`, via a new `jni_log_line()` the
   existing `LOGI`/`LOGW`/`LOGE` macros expand to — every call site in the
   file is unchanged, since those are still plain macros. A new
   `nativeSetLinkLogPath()` JNI entry point (called once from
   `MainActivity.onCreate()`) hands the path in. Needs no logcat/READ_LOGS
   access at all, on any device, since it was never reading logcat to
   begin with.
2. **Fresh log per connection attempt, not an ever-growing file.**
   `nativeLinkStart()` re-truncates the log file at the start of every
   session, matching the actual workflow (connect, wait, read the log) —
   a capture reflects one attempt, not whatever a previous one left
   behind. An 8MB backstop cap in the new `link_log_write()` resets to
   empty if a single session ever runs long enough to hit it, which normal
   use shouldn't.
3. **Kotlin-side connection-lifecycle logging (Fifteenth pass's 7 log
   lines in `LinkMultiplayer.kt`) now mirrors into the same file** via a
   new `linkLog()` helper, instead of only going to `Log.i`/`Log.w`. One
   "Copy link log" read now captures the same combined picture the old
   3-tag logcat filter (`mGBA-JNI:* mGBA-Link:* mGBA:*`) used to, without
   depending on logcat access to get it.
4. **No protocol or timing behavior changed.** All four items above are
   logging/infrastructure only. See KNOWN_LIMITATIONS.md for this pass's
   actual investigation (a deeper read of the new host+child evidence, and
   an updated but still-unconfirmed theory) and BUGS_FIXED.md for why this
   isn't labeled a bug fix.

---

# CHANGELOG — Sixteenth pass

Scope note: `mgba_jni.c`, `MainActivity.kt` only. Prompted by the first
genuinely useful evidence this project has had: FIX 13 (Fifteenth pass)
worked, and W sent back four logs — a screenshot of an empty capture on one
phone, and three real logcat files (`wifi_host.text`, `wifi_join.text`,
`bluetoth__1_.text`) with actual multiplayer-attempt content instead of
boot noise.

Reading those three files is what this pass actually is. No new hypothesis
was chased from a cold read this time — everything below follows directly
from what the logs show, and from tracing the two remaining places this
codebase had *no* logging at all (the exchange result on the host side, and
the entire child-side receive path) once it became clear those were the
specific gaps stopping the new evidence from being conclusive.

**Still nothing here fixes the reported bug.** See KNOWN_LIMITATIONS.md.
What this pass adds is the other half of the trace FIX 11/13 started, so
the *next* capture — taken with both phones logging the same session,
which this one wasn't — has a real chance of showing the actual mechanism
rather than another layer of "here's activity, still can't tell what it
means."

---

## 1. Logged the SIO exchange result on the host side, not just the trigger

**Category:** Diagnostic capture
**Files modified:** `app/src/main/cpp/mgba_jni.c`
**Problem:** `link_sio_write_register()` (FIX 11/13) traced every write that
*triggers* an exchange, but never what `link_exchange()` actually returned.
`wifi_host.text` this pass showed 1124 Start-bit writes in 1.67 seconds —
mathematically far too fast to be hitting `WIFI_XCHG_MS=30` on each one
(that alone would take over 30 seconds) — strongly implying most were
completing fast with real replies, not timing out, but nothing in the log
said so directly, and the reply *content* was invisible either way.
**Solution:** Added `LOGI("SIO exchange result: sent=... recv=... timedOut=...")`
right after `link_exchange()` returns, inside the same host-only branch.
**Reason:** Directly motivated by not being able to answer "is the network
side actually working" from `wifi_host.text` alone, despite the timing
strongly suggesting yes.
**Expected improvement:** The next host-side capture will say, per
transfer, exactly what came back and whether it was a timeout.
**Side effects:** Roughly doubles this function's log volume during active
exchanges — expected and accounted for in item 3 below.
**Verification:** Not runnable here. Read-through only; placed inside the
already-host-gated branch, so no new conditions to get wrong.

---

## 2. Added logging to the entire child-side receive path (previously zero)

**Category:** Diagnostic capture
**Files modified:** `app/src/main/cpp/mgba_jni.c`
**Problem:** `nativeLinkChildExchange()` — the only thing that ever updates
a child device's own SIOMULTI0/1 registers — had no logging in either its
early-exit or success path. Every log gathered across sixteen passes,
including this pass's three, is entirely blind to whether this function is
even being called, let alone what it exchanges. `wifi_join.text` and
`bluetoth__1_.text` both show the child ROM repeatedly restarting its own
SIOCNT/RCNT setup roughly every 200ms — consistent with a ROM that keeps
giving up on its own negotiation — but whether that's because this function
never runs, runs but with bad data, or runs fine and the ROM just doesn't
react, was and is unanswerable without this.
**Solution:** Added `LOGW` on the early-exit branch (active/host-role/core
pointer check) and `LOGI` on every successful call, logging both
`hostData` and `childData`.
**Reason:** Same motivation as item 1 — this was the single largest blind
spot left after item 1, and the one most directly relevant to the
"still doesn't work on rom" reports for a device acting as the child.
**Expected improvement:** The next child-side capture will show whether
this function runs at all during a real attempt, how often, and with what
data — directly testable against the host's own `wifi_host.text`-style
trace if both phones capture the same session.
**Side effects:** Adds log volume proportional to how often the child
actually receives host data — unknown until measured, since this pass's
child-role logs show no evidence either way.
**Verification:** Not runnable here. Read-through only.

---

## 3. Bumped the debug-log capture window again, 8000 → 20000 lines

**Category:** Bug fix (diagnostic capture)
**Files modified:** `MainActivity.kt`
**Problem:** Fifteenth pass's 8000-line bump was sized against *boot*
noise, before this pass's evidence showed real exchange activity running
at ~670/second on the host — 2243 lines in 1.67s from the write trace
alone, before items 1-2 above add more on top.
**Solution:** `-t 8000` → `-t 20000`. Comment above `copyLinkDebugLog()`
updated with the real numbers behind the bump this time, instead of a
guess.
**Reason:** Directly sized against this pass's own measured log rate, with
headroom for items 1-2's added volume.
**Expected improvement:** A capture spanning several seconds of real
exchange activity, from either role, shouldn't scroll its own start out
from under itself before W gets to read it.
**Side effects:** Larger worst-case clipboard/dialog payload — same
reasoning as the Fifteenth-pass bump, still well within what a
`ScrollView`/`TextView` and the clipboard handle fine.
**Verification:** Not runnable here. Read-through only.

---

## Not changed this pass

- The actual mechanism behind the child ROM's repeated resets, or whether
  it's the same mechanism on Wi-Fi and Bluetooth — items 1-2 are what
  would show this, not a fix for it yet.
- The empty-log-on-one-phone issue W also reported/screenshotted this
  pass. Very likely a normal Android self-logcat restriction that varies
  by device/OS version (not something this codebase controls), for which
  Shizuku — already working on W's other phone — is the practical
  workaround. Not attempted as a code fix this pass; see
  KNOWN_LIMITATIONS.md for why and what a real fix would involve.
- Everything else FIX 9-15 already covers.



Scope note: `mgba_jni.c`, `LinkMultiplayer.kt`, `MainActivity.kt`. Prompted
by a retest reporting all three still-open symptoms at once: ROM detection
still failing on both transports, Wi-Fi disconnect not reaching the other
phone, and lag on Bluetooth. Two logcat dumps (one per transport) were
attached as evidence for the ROM-detection question specifically.

Reading those two dumps first, before touching any source, is what this
pass actually turned on: neither contained a single line from anywhere near
an actual link attempt — both covered barely 200ms of real time, entirely
boot-time noise. That's items 1-2 below. Item 3 is a design gap every prior
FIX 9-12 comment already described the intent for but never actually
enforced, found by re-reading `mgba_jni.c` end to end rather than from the
logs (which had no signal to read). Item 4 is the clipboard tool itself,
updated to match.

**None of this is confirmed to fix the reported symptoms** — see
KNOWN_LIMITATIONS.md's Fifteenth-pass entry for exactly what would. Items
1-2 are a confirmed, demonstrated bug (the evidence is the two attached
files) whose fix is straightforward; item 3 is a hardening whose actual
impact is unknown. What every item together should reliably produce,
even if the underlying multiplayer bug turns out to be something else
entirely, is a next debug-log capture that finally contains something to
read.

---

## 1. Filtered mGBA's own core logging out of `jni_log()`

**Category:** Bug fix (diagnostic capture) / possible general performance
**Files modified:** `app/src/main/cpp/mgba_jni.c`
**Problem:** `jni_log()` — the callback that forwards mGBA's internal
logger to Android's logcat — forwarded every core log line, at every
level, to `LOGI` under the `mGBA-JNI` tag, with `(void)level` explicitly
discarding the one piece of information that would have let it filter
anything. Confirmed directly from both logcat files attached this pass:
every line in both was genuinely `mGBA-JNI` (the tag filter was never the
issue), but both covered barely 166-241ms of real time — pure boot-time
`"Starting DMA ..."` / `"Read from write-only I/O register: ..."` spam,
nothing from anywhere near an actual multiplayer attempt. Confirmed
against mgba-emu/mgba's real source this pass (not inferred): the latter
message is logged at `mLOG_STUB`, the same level FIX 12 already
identified for the (now-removed) `rawWrite16` no-op warnings. This chatter
is completely unrelated to link/multiplayer — any DMA-heavy ROM produces
dozens of these lines every single frame — so it was never specific to
this investigation, it just happened to be what finally made the capture
tool's output visibly useless enough to trace.
**Solution:** `jni_log()` now drops `mLOG_DEBUG`/`mLOG_STUB`/
`mLOG_GAME_ERROR` before they reach `LOGI`, matching mGBA's own
`src/platform/libretro/libretro.c` under `NDEBUG` (this project's own
`CMakeLists.txt` also builds with `NDEBUG`). `FATAL`/`ERROR`/`WARN`/`INFO`
are unaffected. Belt-and-suspenders on top of the level check: also drops
the two specific message prefixes actually observed flooding both attached
logs, regardless of level, in case either isn't DEBUG/STUB after all.
**Reason:** Directly demonstrated by the two files W attached — see
mgba_jni.c's own FIX 13 comment for the full trail.
**Expected improvement:** The next `Copy link log` capture should cover
much more real time and actually contain FIX 11's SIO trace lines and
LinkMultiplayer.kt's own connection-lifecycle logging, instead of nothing.
Secondary, unconfirmed: `__android_log_print` is a real syscall: cutting
dozens of avoidable calls per frame, on every ROM, may also just be a
general performance improvement — not only for the Bluetooth lag this pass
was asked about.
**Side effects:** None expected — pure log suppression, no behavior
change. If DEBUG/STUB-level core tracing is ever needed again for
unrelated debugging, this is the one place to temporarily loosen.
**Verification:** No compiler in this sandbox, as every pass. The two
attached logs are direct evidence the *problem* is real; the fix itself
(which specific mLogLevel constants exist, and that STUB is used for
exactly this "wrong-direction register access" case) is checked against
mgba-emu/mgba's real source this pass, not assumed.

---

## 2. Bumped the debug-log capture window, updated its guidance

**Category:** Bug fix (diagnostic capture)
**Files modified:** `MainActivity.kt`
**Problem:** `copyLinkDebugLog()`'s `logcat -t 2000` limit, combined with
Item 1's since-fixed noise, meant the window covered a fraction of a
second in practice.
**Solution:** Bumped `2000` to `8000`. Purely a safety margin on top of
Item 1's real fix, not a substitute for it — the comment above the
function, and the empty-state dialog message, were both updated to say so
and to explicitly mention re-testing the disconnect scenario (tap
Disconnect, wait a few seconds, then read the log), since that's now also
something this capture is meant to help diagnose.
**Reason:** Cheap extra headroom now that each line is worth far more
signal than before.
**Expected improvement:** A long test session (multiple connect/play/
disconnect cycles) is less likely to scroll early evidence back out.
**Side effects:** Slightly larger clipboard payload and dialog text in the
worst case; a plain monospace `TextView` inside a `ScrollView` handles a
few thousand lines fine.
**Verification:** Not runnable here (no device). Read-through only.

---

## 3. Host-gated the native SIO exchange trigger

**Category:** Hardening (protocol correctness) — impact unconfirmed
**Files modified:** `app/src/main/cpp/mgba_jni.c`
**Problem:** `link_sio_write_register()`'s exchange branch fired on *any*
SIOCNT write with the Start bit set, regardless of which role's own ROM
made that write. FIX 9's original comment already claimed this branch
"correctly never fires" on a child device, on the theory that a child ROM
never performs that write (GBATEK: Start/Busy is read-only for slaves) —
but nothing in the code actually enforced that; it was resting entirely on
that assumption holding for both test ROMs.
**Solution:** Added `&& g_link_is_host` to the branch condition; simplified
the two `g_link_is_host ? … : …` blocks inside it that the guard now makes
unreachable in the child case. The FIX 11 diagnostic warning is now also
host-gated, deliberately not logging the (now-expected) child case at all,
to avoid reintroducing Item 1's problem if a ROM's child-role code hits
this on every poll iteration.
**Reason:** Re-reading `mgba_jni.c` end to end for anything FIX 9-12 might
have missed, since the attached logs had no signal to point at anything
more specific. If either test ROM's link code shares one code path between
parent/child roles (plausible — Nintendo's SDK is commonly used that way)
and doesn't itself distinguish, this would have let a child device trigger
a second, spurious exchange of its own alongside the correct
network-triggered one — sending an unsolicited packet the host's *next*
real exchange could then consume as that round's reply. Fits the reported
symptom set well: identical ROM-detection failure on both transports (this
file is shared, unlike the already-hardened transport-specific Kotlin) and
worse lag specifically on Bluetooth (`BT_XCHG_MS=50` vs `WIFI_XCHG_MS=30` —
a stolen reply costs more there). Also may bear on the Twelfth-pass
KNOWN_LIMITATIONS entry that flagged suspiciously rapid repeated exchanges
in an earlier capture, never followed up.
**Expected improvement:** Unconfirmed — see KNOWN_LIMITATIONS.md. Cheap and
safe either way: host behavior is completely unchanged, since `is_host` was
already true on every path that used to run.
**Side effects:** None expected for the host role. For the child role. only
removes a call this design was never supposed to make in the first place.
**Verification:** Not runnable here. Design-intent gap identified by
reading, not by a build or device test.

---

## 4. Added specific reason logging to every disconnect/peer-lost path

**Category:** Bug fix (diagnostic capture)
**Files modified:** `LinkMultiplayer.kt`
**Problem:** `disconnect()`'s outgoing BYE send had a bare
`catch (_: Exception) {}` — completely silent whether it succeeded, was
skipped (null socket/peer), or threw. Separately, all 8 call sites of
`handlePeerLost()` logged one identical generic line regardless of which
of the 6 listener locations detected it or why (explicit BYE vs. the 8s
liveness timeout). A captured log couldn't have distinguished "peer's BYE
never arrived", "it arrived but something else consumed it first", and
"neither side has sent one yet, still waiting on the watchdog" — three
very different bugs that all look identical from the report "if I
disconnect, it doesn't disconnect on the other phone."
**Solution:** `disconnect()` now logs the BYE send's outcome specifically
(sent + destination, skipped + which of socket/peer was null, or the
exception). `handlePeerLost()` now takes a `reason: String`; every call
site names itself and, where relevant, the specific trigger (BYE received
vs. timeout duration).
**Reason:** Purely additive — no timing or protocol logic changed, only
what gets logged and how specifically.
**Expected improvement:** The next capture of a disconnect test should say
exactly which side sent a BYE, whether it was received, and if not,
whether the other side eventually gave up via the 8s watchdog instead —
enough to actually localize the reported bug instead of re-guessing at it.
**Side effects:** None expected. Slightly more log volume on disconnect
specifically (a handful of lines, not per-frame) — not a concern after
Item 1.
**Verification:** Not runnable here. Read-through only; every call site
cross-checked to confirm none were missed (`grep -n "handlePeerLost("`).

---

## Not changed this pass

- The actual WiFi disconnect-propagation bug, if it's not just Item 3
  above or a timing/testing artifact — nothing else found it by reading.
- The actual Bluetooth ROM-detection failure and lag, beyond Items 1 and 3
  above — same.
- `BT_XCHG_MS`/`WIFI_XCHG_MS` themselves — no evidence yet that the
  timeout values are wrong rather than the timeouts being hit at all.
- Everything else FIX 9-14 already covers.



Scope note: one-line fix, `MainActivity.kt` only, prompted by a real CI
build log the user attached (the Thirteenth pass's zip failed
`compileReleaseKotlin`).

---

## 1. Fixed a real Kotlin compile error

**Category:** Bug fix (compile error)
**Files modified:** `MainActivity.kt`
**Problem:** `showLinkDebugLogDialog(text: String)`'s parameter name
collided with `TextView`'s own `text` property. Inside `TextView(this)
.apply { text = shown }`, the bare `text` on the left of the assignment
resolved to the outer parameter (immutable) rather than the receiver's
property, so the compiler rejected it as reassigning a `val`. Everywhere
else in the file, the same kind of assignment goes through an explicit
variable (`row.text = ...`), which is never ambiguous — this was the one
bare/unqualified case, and it happened to collide.
**Solution:** Renamed the parameter to `logText`; the function body's one
reference to it (`text.ifBlank { ... }`) updated to match, `text = shown`
inside the `apply` block left as-is since it's now unambiguous.
**Reason:** Real `compileReleaseKotlin` failure from an actual CI run —
see the attached build log's `14_Build APK.txt`.
**Expected improvement:** Build succeeds.
**Side effects:** None — pure rename, no behavior change. The one caller
(`copyLinkDebugLog()`) passes its argument positionally, so it's
unaffected by the parameter's internal name.
**Verification:** No compiler available in this sandbox, as always — but
this fix is about as close to "verified" as this project gets without
one: the failure came from a real Gradle/Kotlin compiler run, the
collision was fully diagnosed against the exact reported line/column, and
grepping confirmed no other function in either of the last two passes'
additions has a parameter name that collides with a property name used
bare inside a nested `apply`/similar block.

---

# CHANGELOG — Earlier passes (summary)

Full entries for these passes were trimmed to keep this file a
reasonable length. None of them touch multiplayer/link code except where
noted — see FILE_CHANGES.md's own history if the exact diff for one of
these ever matters again.

- **Thirteenth** — `MainActivity.kt`: save-state slot picker now shows a
  thumbnail per slot.
- **Twelfth** — `MainActivity.kt`: added the in-app "Copy link log"
  diagnostic (logcat-based at the time; superseded by Seventeenth pass's
  file-based version). Diagnostic only, not a link fix.
- **Eleventh** — `MainActivity.kt`: fixed a Tenth-pass regression where
  every row in the restyled quick game menu silently did nothing when
  tapped (`isClickable`/`isFocusable` on the row view was stealing the
  touch from the `ListView`'s own click dispatch).
- **Tenth** — `MainActivity.kt`: quick game menu restyled and expanded to
  match a reference screenshot (10 items instead of 5); two now-redundant
  Settings rows removed; immersive mode now re-applied on focus regain;
  display-cutout black bar fixed; Screenshot/Reset/Close actions added.
- **Fifth** — First pass to focus on `LinkMultiplayer.kt`/multiplayer
  internals specifically (four earlier undocumented passes had already
  covered audio, rendering, ROM-swap safety, and the control layout
  editor). Fixed missing `@Volatile` on six connection-state fields
  (a real cross-thread visibility bug) and an untracked discovery socket
  that made `disconnect()` a no-op for it.
