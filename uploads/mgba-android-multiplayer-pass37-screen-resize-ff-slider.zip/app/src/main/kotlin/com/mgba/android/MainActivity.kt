package com.mgba.android

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.text.InputType
import android.text.format.DateFormat
import android.util.Log
import android.util.TypedValue
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.PixelCopy
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.Closeable
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.io.PrintWriter
import java.io.StringWriter
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.zip.ZipInputStream
import kotlin.math.abs

class MainActivity : AppCompatActivity(), SurfaceHolder.Callback {

    private lateinit var surfaceView: SurfaceView
    private lateinit var settingsBtn: TextView
    private lateinit var settingsMenuOverlay: LinearLayout
    // ── Memory viewer (see showMemoryViewer()/buildMemoryViewer()) ──────────
    // FEATURE: live GBA memory inspector, requested for watching game state
    // (Pokémon battle values — HP, party data, etc. — were the specific
    // example) change in real time. Deliberately built as an overlay, same
    // built-once/shown-hidden pattern as Settings just below, rather than
    // its own Activity the way the ROM browser is — the whole point is to
    // watch memory *while the game keeps running underneath*, which an
    // Activity switch (pausing MainActivity, per the Android lifecycle)
    // would work against; showSettingsMenu() already establishes that
    // showing an overlay here does NOT stop the game loop, exactly what
    // this needs too. Read-only for now: inspects live RAM, as asked for,
    // not a cheat/poke tool — see showMemoryViewer()'s own doc comment.
    private lateinit var memoryViewerOverlay: LinearLayout
    private lateinit var memoryDumpText: TextView
    private lateinit var memoryAddressText: TextView
    private var memoryRegionIndex = 0
    private var memoryPageOffset = 0
    // ROM browser fields (romBrowserOverlay, romBrowserListLayout,
    // romBrowserPathText, romBrowserBackBtn, romBrowserDeviceRoot,
    // romBrowserStack, romBrowserGeneration) all moved out this pass
    // (Thirty-second) into RomBrowserActivity.kt, a separate Activity now —
    // see changeRom()/romBrowserLauncher below and RomBrowserActivity.kt's
    // own top-of-file comment for why (a real, twice-reproduced native
    // crash from forcing orientation on this screen while it lived here as
    // an overlay in the same window as the game surface).
    // ── Screen orientation (see applyScreenOrientationPref()/showVideoSettings()) ──
    private var screenOrientationChoice: Int = ORIENTATION_LANDSCAPE
    private var surfaceHolder: SurfaceHolder? = null
    private var gameThread:    Thread? = null
    @Volatile private var running   = false
    @Volatile private var romLoaded = false
    // ── Save states / battery save ────────────────────────────────────────
    // Identifies the loaded ROM for save-file naming (both the battery .sav
    // and save-state slots below) — see deriveRomBaseName(). Kept separate
    // from the fixed "rom_loaded.gba" cache path every ROM is copied to
    // (see romPicker) so switching ROMs (via Settings → Change ROM) never
    // mixes one game's save data into another's.
    @Volatile private var currentRomBaseName = "rom"
    // ── Triple-buffered framebuffers ────────────────────────────────────────
    // AUDIO FIX (this pass — root cause of crackle/stutter/perceived pitch
    // drift): renderFrame() (lockCanvas/drawBitmap/unlockCanvasAndPost) used
    // to run on the SAME thread as writePcm(), right after it, every frame.
    // Since writePcm() blocking IS the frame pacer now (see startGameLoop()),
    // any slow render — a GC pause, a busy compositor, a software-canvas
    // SurfaceView on a budget device — delayed the *next* audio write too.
    // That starves AudioTrack while the render is stuck, which is heard as a
    // click/pop when playback resumes (buffer underrun), and the resulting
    // irregular frame delivery reads as choppiness or "speed" wobble even
    // though no single sample is mispitched. This was flagged in an earlier
    // pass as a known, deferred risk ("the real fix is decoupling rendering
    // onto its own thread") rather than fixed outright.
    //
    // Fix: three Bitmap buffers, ping-ponged so the game thread never writes
    // into a buffer the renderer might currently be reading:
    //   writeIdx   — owned by the game thread; where nativeRunFrame() writes.
    //   readyIdx   — the most recently completed frame, swapped in under
    //                bufferLock once a frame finishes; -1 = none yet.
    //   displayIdx — owned by the Choreographer render callback; the buffer
    //                it last drew (and may still be drawing via the Surface).
    // The game thread always picks its next writeIdx as whichever of the 3
    // indices is neither readyIdx nor displayIdx — with 3 buffers and only
    // 2 "spoken for" at once, a free one always exists, so the writer never
    // blocks on the renderer and the renderer never tears mid-draw.
    // The renderer runs off Choreographer.postFrameCallback — i.e. paced by
    // the display's own vsync — completely independent of how fast the
    // audio-locked game thread is producing frames.
    private var frameBuffers: Array<Bitmap>? = null
    private var writeIdx = 0
    private val bufferLock = Object()
    private var readyIdx = -1
    private var displayIdx = -1
    @Volatile private var renderLoopActive = false
    private val renderCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!renderLoopActive) return
            val bufs = frameBuffers
            if (bufs != null) {
                var toDraw = -1
                synchronized(bufferLock) {
                    if (readyIdx != -1 && readyIdx != displayIdx) {
                        displayIdx = readyIdx
                    }
                    toDraw = displayIdx
                }
                if (toDraw != -1) renderFrame(bufs[toDraw])
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }
    private fun startRenderLoop() {
        // Choreographer is thread-affine (it binds to whichever thread first
        // asks for an instance) and stopGameLoop() can be called from a
        // background thread (see romPicker's reload path). Flip the volatile
        // flag immediately — doFrame() checks it before ever rescheduling
        // itself, so that alone halts the loop within one vsync tick — and
        // push the actual Choreographer registration through mainHandler so
        // it's always made from the main thread's Choreographer instance.
        renderLoopActive = true
        mainHandler.post {
            if (renderLoopActive) Choreographer.getInstance().postFrameCallback(renderCallback)
        }
    }
    private fun stopRenderLoop() {
        renderLoopActive = false
        mainHandler.post { Choreographer.getInstance().removeFrameCallback(renderCallback) }
    }
    private val gameMatrix  = Matrix()
    private val currentKeys = AtomicInteger(0)
    // BUG FIX ("buttons disappear while dragging"): this used to be a
    // `mutableListOf<ButtonDef>()` that buildControlLayout() mutated in
    // place — buttons.clear() followed by ~11 buttons += calls. That's
    // called on every ACTION_MOVE while dragging a button in the editor
    // (see onEditTouch), i.e. dozens of times a second, ON THE UI THREAD —
    // while the game thread's render loop reads this same list ~60x/sec to
    // draw it (drawControls()). There was no synchronization between the
    // two, so the render thread could paint a frame at the exact moment the
    // list was between clear() and being refilled: every button vanishes
    // for that one frame. Worse under load (exactly when you're actively
    // dragging), which matches "it freezes/disappears when you move it".
    // Fix: build a brand-new list off to the side and swap the *reference*
    // in one atomic write. The render thread then only ever sees a fully
    // "old" or fully "new" list, never a half-built one.
    @Volatile private var buttons: List<ButtonDef> = emptyList()
    private var controlsTop = 0f
    // pickerLive moved to RomBrowserActivity this pass — its only two uses
    // (romPicker, the classic single-file fallback) moved there with it.
    private lateinit var link: LinkMultiplayer
    private val mainHandler = Handler(Looper.getMainLooper())

    // ── Control layout editor ────────────────────────────────────────────────
    // Per-button position/size/opacity overrides, keyed by stable button id
    // ("dpad","a","b","start","select","l","r","ff", …). Absent from the
    // map == "use the default geometric layout computed in buildControlLayout()".
    // Positions are stored as FRACTIONS of screen width/height (not raw
    // pixels) so a saved layout still makes sense if the app is later run on
    // a different screen size. Persisted as JSON in SharedPreferences,
    // keyed per orientation (see orientationTag()) so a future portrait mode
    // doesn't inherit an unsuitable landscape layout — today the activity is
    // locked to landscape (android:screenOrientation="landscape"), so only
    // the "land" profile is ever active, but the storage format doesn't need
    // to change when portrait support is eventually added.
    private data class LayoutEntry(
        var xFrac: Float,
        var yFrac: Float,
        var scale: Float = 1f,
        var alphaOverride: Int = -1,   // -1 == inherit the global idle-alpha setting
        var locked: Boolean = false
    )
    private data class Geometry(val cx: Float, val cy: Float, val w: Float, val h: Float)

    private val customLayout = mutableMapOf<String, LayoutEntry>()
    private val defaultGeometry = mutableMapOf<String, Geometry>()
    private var lastSw = 0f
    private var lastSh = 0f

    // ── ADD/REMOVE CONTROL ──────────────────────────────────────────────
    // Button ids currently hidden from the on-screen layout (and therefore
    // excluded from buildControlLayout()'s `buttons`/ffBtnRect output, so
    // they're neither drawn nor hit-tested during normal gameplay). Entered
    // via hold-to-remove in the editor (see onEditTouch/showRemoveButtonMenu)
    // and reversed via "+ Add control" (see showAddControlMenu). Persisted
    // the same way/at the same points as customLayout — see
    // loadCustomLayout()/saveCustomLayout() — so Cancel discards a removal
    // exactly like it discards a drag, and Done makes it stick.
    private val removedButtons = mutableSetOf<String>()

    // "Extra" controls — the shoulder+face combos, the A/B combos, and the
    // three one-tap actions (quick save/load, screenshot). Opposite default
    // from removedButtons above: these start OFF and only ever appear once
    // explicitly added, rather than starting on and being explicitly
    // removed — shipping this feature should never dump 9 new buttons onto
    // a layout someone already has set up exactly how they want it. See
    // isButtonVisible()/allControlIds() for how the two sets combine, and
    // buildControlLayout() for where each of these is actually built.
    // "ta"/"tb" (Turbo A / Turbo B) joined this list this pass — previously
    // a single all-or-nothing Settings checkbox added both together (see
    // showInputSettings()'s old turboCheck, removed this pass); moved here
    // on request, so each can be added/positioned/removed independently,
    // same as every other opt-in extra.
    private val extraControlIds = listOf(
        "ta", "tb", "la", "lb", "ra", "rb", "ab", "abturbo", "quicksave", "quickload", "screenshot"
    )
    private val addedExtraButtons = mutableSetOf<String>()

    /** True if [id] should currently be drawn/hit-tested. Base controls
     *  (the original 8 — dpad/a/b/select/start/l/r/ff) are opt-OUT via
     *  removedButtons; extraControlIds are opt-IN via addedExtraButtons.
     *  addButton() gates on this; everywhere else that used to check
     *  removedButtons directly (hitTestEditable, the old add/remove
     *  toggles) now goes through this instead so both catalogs behave
     *  consistently. */
    private fun isButtonVisible(id: String): Boolean =
        if (id in extraControlIds) id in addedExtraButtons else id !in removedButtons

    @Volatile private var editModeActive = false
    private var editSelectedId: String? = null
    private var editDragPointerId = -1
    private var editDragOffX = 0f   // touch point minus button center, at drag start
    private var editDragOffY = 0f
    private var editResizing = false
    private var editResizeStartDist = 0f
    private var editResizeStartScale = 1f
    private var editDirty = false   // true once the working copy diverges from what's saved
    private lateinit var editTopBar: LinearLayout
    private lateinit var editButtonBar: LinearLayout
    private lateinit var editButtonLabel: TextView
    private lateinit var editLockBtn: Button
    // HOLD-TO-REMOVE: armed on ACTION_DOWN over a button (plain grab, not a
    // corner resize-grab — see onEditTouch), cancelled by real movement or
    // by lifting the finger before it fires. See cancelEditLongPress().
    private var editLongPressPending: Runnable? = null
    private var editDownX = 0f
    private var editDownY = 0f
    private val editTouchSlop: Float by lazy { ViewConfiguration.get(this).scaledTouchSlop.toFloat() }
    // FEATURE: hold-for-speed-slider on the on-screen »/fast-forward
    // button, gameplay (not edit-mode) touch handling — see onGameTouch()
    // and showFastForwardSpeedSlider(). Same "armed on DOWN, cancelled if
    // it resolves as a tap before the timeout fires" shape as
    // editLongPressPending just above, for the same reason (Runnable
    // stays cancellable via mainHandler.removeCallbacks right up until it
    // actually runs).
    private var ffLongPressPending: Runnable? = null

    // ── Fast-forward state ─────────────────────────────────────────────────
    @Volatile private var fastForwardSpeed  = 2.0f
    @Volatile private var fastForwardActive = false
    private var ffBtnRect  = RectF()
    private var ffFrameAccumulator = 0.0

    // FEATURE (this pass): the game screen is now a resizable/draggable
    // participant in the same edit-mode/customLayout system every button
    // already used — see resolvedRect("gamescreen", ...) in
    // updateGameMatrix(), and editRectFor()/hitTestEditable()/labelFor()
    // below. gameScreenRect is its resolved on-screen rect, kept as its
    // own field (not a ButtonDef in the buttons list) since it isn't a
    // real input control — no keyMask, never drawn as a button glyph
    // during normal gameplay, excluded from the long-press-to-remove menu
    // (see onEditTouch) since there's nothing sensible "removing" it
    // would mean.
    //
    // Replaces the previous Fullscreen checkbox (fullscreenMode) entirely
    // on request — a separate on/off toggle for "game covers the control
    // area" doesn't add anything once the screen itself can just be
    // dragged and resized to be exactly as big as wanted, controls
    // included or not.
    private var gameScreenRect = RectF()
    // FEATURE: distorts the image to fill the game area exactly instead of
    // preserving the GBA's native 3:2 aspect ratio — see updateGameMatrix().
    @Volatile private var stretchToFit = false
    // FEATURE: bilinear-smooths the upscaled image instead of showing
    // crisp/blocky pixels — see gamePaint/updateLinearFilterPaint() below.
    // FIX: this field itself was missing entirely through pass 35 — every
    // read of it (the pref-load line, updateLinearFilterPaint(), the
    // Video settings checkbox) compiled as an unresolved reference,
    // caught by the real CI build (this project has no compiler in the
    // sandbox that writes it — see every pass's own verification notes).
    // Wrongly assumed to already exist alongside stretchToFit/maxFrameSkips
    // above without actually checking for a declaration, not just a use —
    // the two lines it happened to share a grep result with were a load
    // line and a doc comment, neither of which is one.
    @Volatile private var linearFilterEnabled = false
    // FEATURE: MyBoy-style frame skipping for normal (non-fast-forward)
    // play — see maybeSkipRenderThisFrame() in the game loop. 0 = never
    // skip (always render every frame, the previous and still-default
    // behavior); up to maxFrameSkips consecutive frames may be emulated
    // without blitting if the loop is genuinely running behind.
    @Volatile private var maxFrameSkips = 0
    // FEATURE: state for maybeSkipRenderThisFrame's "are we behind" check
    // and its consecutive-skip budget — see startGameLoop().
    @Volatile private var consecutiveFrameSkips = 0
    private var lastFrameLoopStartNs = 0L
    private val frameBudgetNs = 1_000_000_000L / 60  // one GBA frame at 60fps

    // ── Button / screen customization ─────────────────────────────────────
    private var buttonScaleMultiplier = 1.0f   // 0.75 / 1.0 / 1.25
    private var buttonBaseAlpha       = 160    // idle opacity 0-255
    private var gameScreenFraction    = GAME_FRAC_NORM  // 0.35–0.65
    // OUTLINE SKIN: stroke width for the line-art button style, recomputed
    // as a screen-size fraction in buildControlLayout() (same convention as
    // every other button dimension in that function) rather than a fixed
    // pixel constant, so it scales sensibly across phone sizes.
    private var outlineStrokeW        = 5f

    // ── Turbo (rapid-fire) A / B ────────────────────────────────────────────
    // Adds two extra red on-screen buttons — "A"/"B" in red — that
    // auto-repeat the A/B press while held instead of holding it
    // continuously. Individually opt-in via "+ Add control" (see
    // extraControlIds above) as of this pass — previously a single
    // Settings checkbox added both together with no way to get just one;
    // removed on request in favor of the same per-button system every
    // other extra control already used.
    @Volatile private var turboAHeld = false
    @Volatile private var turboBHeld = false
    // Half-period of the on/off square wave, in ms.
    // FIX (this pass): was 66ms (≈7-8 presses/sec), reported as feeling
    // slow — not really "rapid" fire. Halved to 30ms (≈16-17 presses/sec),
    // comfortably inside the range real turbo controllers typically run
    // at (roughly 10-30/sec), and still safely above the ~16.7ms a single
    // GBA frame takes at 60fps — each on/off phase still spans close to
    // two full frames, so the core should still reliably register every
    // edge as a distinct press rather than the two phases blurring
    // together into what would just look like a continuous hold again.
    private val turboHalfPeriodMs = 30L

    // ── Performance overlay (FEATURE — off by default) ─────────────────────
    // Small corner readout of emulated core FPS and the AudioTrack underrun
    // counter — the same underrun figure already logged periodically (see
    // writePcm()), just also surfaced on-screen for at-a-glance diagnosis
    // without needing logcat. Purely additive and opt-in: when disabled
    // (the default) the game thread does none of the counting work below,
    // so there's zero overhead on the thread that also paces audio.
    // Toggled in ⚙ Settings → Misc, next to the other gameplay tweaks.
    @Volatile private var showFpsOverlay = false
    @Volatile private var fpsOverlayText = ""
    private var fpsFrameCount    = 0
    private var fpsWindowStartNs = 0L

    // ── Button click sound ───────────────────────────────────────────────
    // Uses the system's built-in FX_KEYPRESS_STANDARD effect via AudioManager
    // rather than SoundPool/MediaPlayer. That matters for two reasons:
    //  1. No asset file needed — the sound ships with the OS.
    //  2. playSoundEffect() is fire-and-forget and non-blocking; it's cached
    //     by the system after the first call. A prior approach that created
    //     a MediaPlayer (or cold-loaded a SoundPool sample) on every touch
    //     event would synchronously decode/prepare audio on the UI thread —
    //     and since updateGameKeys() runs on EVERY ACTION_MOVE while
    //     dragging (not just on initial press), that's dozens of blocking
    //     calls per second, which is exactly what freezes the UI.
    // We avoid both problems by only firing on the RISING EDGE of a button
    // press (see updateGameKeys) and by using the pre-cached system effect.
    private var buttonSoundEnabled = false
    private var lastSoundKeys      = 0
    private var audioManager: AudioManager? = null

    // ── Audio ──────────────────────────────────────────────────────────────
    @Volatile private var audioTrack: AudioTrack? = null
    private val audioBuffer = ShortArray(2048)
    // FAST-FORWARD AUDIO: accumulates every sub-frame's PCM across one
    // fast-forward batch (see startGameLoop) before decimateForFastForward()
    // compresses it back down to about one frame's worth. Sized for
    // FF_MAX_BATCH_FRAMES sub-frames at audioBuffer's own per-read capacity.
    private val ffAccumBuffer = ShortArray(FF_MAX_BATCH_FRAMES * audioBuffer.size)
    private var audioDiagCounter = 0
    // AUDIO FIX (this pass): audio focus was never requested. AudioTrack will
    // still *build* and accept writes without it, but several OEM audio HALs
    // (MIUI/ColorOS/FuntouchOS in particular) silently keep a stream's output
    // gain at zero — not muted, not erroring, just inaudible — until the app
    // holding the Surface/foreground also holds AUDIOFOCUS_GAIN. Requesting
    // it costs nothing on stock AOSP devices where sound already worked.
    private var audioFocusRequest: AudioFocusRequest? = null
    private val audioFocusListener = AudioManager.OnAudioFocusChangeListener { /* no-op: USAGE_GAME doesn't duck */ }

    companion object {
        private const val TAG             = "mGBA"
        private const val GAME_FRAC_NORM  = 0.52f

        // ── GBA hardware timing ─────────────────────────────────────────────
        // AUDIO FIX (root cause #1): the old loop paced itself with
        // Thread.sleep(1_000_000_000.0 / 60.0) — i.e. it assumed an exact
        // 60.000 Hz refresh. Real GBA hardware runs at CPU_CLOCK / CYCLES_PER_FRAME
        // = 16777216 / 280896 ≈ 59.7275 Hz. Pacing 0.46% too fast meant the game
        // thread fed the blip_buf resampler audio slightly faster than a
        // 44.1 kHz AudioTrack could drain it. Since the old code wrote with
        // WRITE_NON_BLOCKING and never checked the return value, that constant
        // small surplus was silently dropped by AudioTrack roughly every 3–4
        // real seconds — an audible periodic "stutter" that would read as
        // "audio is a little broken" on a real device even though nothing was
        // ever fully silent. Below are the exact constants (matching
        // GBA_AUDIO_CLOCK in mgba_jni.c) used for the corrected pacing.
        private const val GBA_CPU_CLOCK_HZ    = 16_777_216L   // 2^24, ARM7TDMI clock
        private const val GBA_CYCLES_PER_FRAME = 280_896L     // 228 lines * 1232 cycles
        // Only used as a *fallback* pacer for frames that produce no audio
        // (e.g. the first frame or two right after a ROM loads, before the
        // blip_buf resamplers have accumulated a full sample). Normal frames
        // are paced by the AudioTrack itself — see startGameLoop().
        private val FALLBACK_FRAME_NS =
            GBA_CYCLES_PER_FRAME * 1_000_000_000L / GBA_CPU_CLOCK_HZ

        // Headroom above the 16x fast-forward speed clamp (see
        // showMiscSettings) for sizing ffAccumBuffer below.
        private const val FF_MAX_BATCH_FRAMES = 24

        // SharedPreferences
        // PREFS itself moved to SharedUi.kt this pass (top-level, shared
        // with RomBrowserActivity) — everything below is still just this
        // Activity's own keys within that same file.
        private const val PREF_FF_SPEED    = "ff_speed"
        private const val PREF_BTN_SCALE   = "btn_scale"
        private const val PREF_BTN_ALPHA   = "btn_alpha"
        private const val PREF_SCREEN_FRAC = "screen_frac"
        private const val PREF_STRETCH     = "stretch_to_fit"
        private const val PREF_MAX_SKIPS   = "max_frame_skips"
        private const val PREF_LINEAR_FILTER = "linear_filter"
        private const val PREF_BTN_SOUND   = "btn_sound"
        // PREF_TURBO removed this pass — Turbo A/B moved into the same
        // added-extras layout persistence every other opt-in button
        // already uses (see extraControlIds/addedExtraButtons above),
        // rather than a separate on/off flag of their own.
        private const val PREF_SHOW_FPS    = "show_fps"
        private const val PREF_LAYOUT_PREFIX = "layout_"
        // ADD/REMOVE CONTROL feature — which button ids are hidden, per
        // orientation (same "land"/"port" split as PREF_LAYOUT_PREFIX above).
        // See removedButtons / loadCustomLayout() / saveCustomLayout().
        private const val PREF_REMOVED_PREFIX = "removed_"
        // Same idea, opposite default — which extraControlIds ids have been
        // explicitly added. See addedExtraButtons / isButtonVisible().
        private const val PREF_EXTRAS_PREFIX = "extras_"
        private const val PREF_ORIENTATION   = "screen_orientation"  // Int, one of ORIENTATION_* below
        // FEATURE: user-chosen Storage folder for saves/states/screenshots —
        // see dataFolderTree()/showStorageSettings()/SaveEntry below. Absent
        // (the default) means every save-adjacent file lives exactly where
        // it always has: this app's own internal storage. Still a
        // persisted SAF tree Uri (unlike the ROM browser's own
        // PREF_ROMS_LAST_FOLDER, now in RomBrowserActivity.kt — a plain
        // path, and this Activity doesn't need to know it exists at all
        // any more) and read/write instead of read-only, since this one
        // gets written to.
        private const val PREF_DATA_FOLDER_URI = "data_folder_tree_uri"

        // Screen orientation choice, persisted under PREF_ORIENTATION — see
        // applyScreenOrientationPref() and the "Screen orientation" radio
        // group in showVideoSettings(). ORIENTATION_LANDSCAPE is the default
        // (and was previously the only, hardcoded option — see onCreate/
        // AndroidManifest.xml) so existing installs behave identically until
        // someone actually opens Video settings and changes it.
        private const val ORIENTATION_AUTO              = 0
        private const val ORIENTATION_LANDSCAPE          = 1
        private const val ORIENTATION_REVERSE_LANDSCAPE  = 2
        private const val ORIENTATION_PORTRAIT           = 3
        private const val ORIENTATION_SYSTEM             = 4

        // Number of independent save-state slots offered per ROM.
        private const val SAVE_STATE_SLOTS = 4

        // Save-state thumbnail width in px; height is derived per-capture from
        // the SurfaceView's actual aspect ratio at that moment (see
        // captureStateThumbnail) rather than hardcoded, since the surface may
        // be letterboxed/fullscreen differently across sessions and forcing a
        // fixed WxH here would stretch the image instead of just cropping it.
        private const val STATE_THUMB_WIDTH_PX = 200
    }

    private data class ButtonDef(
        val id: String, val rect: RectF, val keyMask: Int, val label: String, val color: Int,
        val isDpad: Boolean = false
    )

    // ── ROM picker ─────────────────────────────────────────────────────────

    // FIX: BLUETOOTH_CONNECT / BLUETOOTH_SCAN are runtime-dangerous permissions
    // on API 31+ (Android 12+). They were declared in the manifest but never
    // actually requested anywhere, so every Bluetooth link-cable action
    // (Host, Join, listing bonded devices) threw an uncaught SecurityException
    // and crashed the app on any Android 12+ device. This launcher requests
    // the permission on demand; [pendingBtAction] resumes whatever the user
    // was trying to do as soon as it's granted.
    private var pendingBtAction: (() -> Unit)? = null
    private val btPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        val action = pendingBtAction; pendingBtAction = null
        if (granted) action?.invoke()
        else uiToast("Bluetooth permission is required for BT link cable")
    }

    /** Runs [action] immediately if Bluetooth permission is already granted
     *  (or not needed on this API level), otherwise requests it first. */
    private fun ensureBluetoothPermission(action: () -> Unit) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) { action(); return }
        val granted = ContextCompat.checkSelfPermission(
            this, Manifest.permission.BLUETOOTH_CONNECT
        ) == PackageManager.PERMISSION_GRANTED
        if (granted) { action() }
        else { pendingBtAction = action; btPermissionLauncher.launch(Manifest.permission.BLUETOOTH_CONNECT) }
    }

    // FEATURE (Thirty-second pass): romPicker (the classic single-file SAF
    // picker) and the whole broad-file-access permission flow
    // (ensureBroadFileAccess() etc.) moved to RomBrowserActivity.kt along
    // with the rest of ROM browsing — see the field-block comment above and
    // RomBrowserActivity.kt's own top-of-file comment for why. What's left
    // here is just the launcher that starts that Activity and receives
    // whichever ROM it picked, mirroring how romPicker/dataFolderPicker
    // above already used registerForActivityResult() for a similar
    // "launch something, get a Uri back" shape.
    private val romBrowserLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            result.data?.data?.let { loadRomFromUri(it) }
        }
        // RESULT_CANCELED (backed out / denied permission / nothing
        // picked): do nothing, same as before — the surface just sits
        // idle and tapping it calls changeRom() again (see onGameTouch()).
    }

    // FEATURE: user-chosen Storage folder (see PREF_DATA_FOLDER_URI/
    // showStorageSettings()/SaveEntry). Unlike the ROM browser (its own
    // Activity now, see above), this still goes through a SAF tree picker
    // rather than the broad MANAGE_EXTERNAL_STORAGE permission — it needs
    // *write* access, and there's no reason to widen what this feature
    // touches just because the ROM browser needs the broader permission
    // for its own, separate reasons.
    private val dataFolderPicker = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        uri ?: return@registerForActivityResult
        try {
            contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        } catch (e: Exception) {
            Log.e(TAG, "takePersistableUriPermission failed for data folder", e)
            uiToast("Couldn't get permission for that folder"); return@registerForActivityResult
        }
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putString(PREF_DATA_FOLDER_URI, uri.toString())
            .apply()
        // Create the three subfolders right away so they're visible in a
        // file manager immediately, not only after the first save/
        // screenshot/(future) cheat file actually gets written.
        dataSubfolder("save"); dataSubfolder("cheat"); dataSubfolder("screenshot")
        uiToast("Folder set — new saves/states/screenshots go here from now on")
        refreshStorageSettingsUi?.invoke()
    }

    // isZipSignature()/zipContainsGba() moved to RomZipUtils.kt this pass
    // (Thirty-second) when the ROM browser became its own Activity —
    // RomBrowserActivity needs zipContainsGba() too, and this way there's
    // still only one copy of the byte comparison between it and
    // stageRomFile() below, same as when both lived in this class.

    /** Copies [uri] into [tmp]. If the source is a zip archive — detected by
     *  its real magic bytes (see RomZipUtils.isZipSignature()), not by file
     *  extension, so a misnamed archive still works and a .zip that somehow
     *  isn't a real zip is correctly rejected instead of handed to the core
     *  as garbage — the first .gba entry found inside is extracted instead
     *  of the raw archive bytes. This is what lets both the file browser
     *  and the classic system picker load a ROM straight out of a .zip with
     *  no separate extraction step. Returns false if nothing worth loading
     *  ended up in [tmp] (unreadable source, or a zip with no .gba entry). */
    private fun stageRomFile(uri: Uri, tmp: File): Boolean {
        val raw = contentResolver.openInputStream(uri) ?: return false
        raw.use { stream ->
            val input = stream.buffered()
            if (!RomZipUtils.isZipSignature(input)) {
                tmp.outputStream().use { o -> input.copyTo(o) }
                return true
            }
            ZipInputStream(input).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    if (!entry.isDirectory && entry.name.endsWith(".gba", ignoreCase = true)) {
                        tmp.outputStream().use { o -> zip.copyTo(o) }
                        return true
                    }
                    entry = zip.nextEntry
                }
            }
            return false
        }
    }

    /** Stages [uri] (transparently unzipping it first if needed — see
     *  stageRomFile()), swaps it into the running core, and updates the UI
     *  on success or failure. Shared by every ROM entry point — the classic
     *  system picker above and the in-app file browser's file rows below
     *  both just call this now, instead of each duplicating the load. */
    private fun loadRomFromUri(uri: Uri) {
        Thread {
            try {
                // FIX: nativeLoadROM() silently drops any active link session
                // as part of swapping the native core (see the "ROM swapped
                // while a link session was active" comment in mgba_jni.c) —
                // that side is careful to avoid leaving a dangling pointer,
                // but it has no way to tell the Kotlin side this happened.
                // Without this, link.isConnected and the ⬤ LINK overlay would
                // keep claiming "Connected" after a ROM swap even though the
                // native SIO driver backing the exchange no longer exists —
                // a silently broken multiplayer session with no indication
                // in the UI of why. Disconnect first so both sides agree.
                if (link.isConnected) stopLink()
                // FIX (Twenty-first pass): if a Storage folder is configured
                // and a ROM is already running, its battery save has only
                // ever been mirrored to internal storage (see
                // SaveEntry.batteryMirrorPath()) — the real document in the
                // chosen folder hasn't seen anything played since the last
                // sync point. Flush it out now, before that mirror file gets
                // reused for the ROM we're about to swap in, or whatever was
                // played this session never reaches the chosen folder at all.
                if (romLoaded) batterySaveEntry(currentRomBaseName).syncBatteryMirror()
                // FIX: stop any in-progress game loop *before* touching the
                // native core, and reset transient input/FF state. Previously
                // there was no way to load a second ROM at all (loadRomBtn was
                // permanently hidden after the first successful load), so this
                // path was never exercised. nativeLoadROM() now builds the new
                // core fully before swapping it in, so a failed load here
                // leaves the previous session running rather than destroying
                // it (see mgba_jni.c).
                stopGameLoop()
                val tmp = cacheDir.resolve("rom_loaded.gba")
                if (!stageRomFile(uri, tmp)) {
                    uiToast("Couldn't read that file (or found no .gba inside the zip)")
                    return@Thread
                }
                // ROM SAVE: identify the ROM by its picked display name —
                // not the fixed "rom_loaded.gba" cache path above, which
                // every ROM shares — so its battery save persists under a
                // name stable across app restarts and re-picking the same
                // file later. See deriveRomBaseName()/batterySaveEntry().
                val baseName = deriveRomBaseName(uri)
                val saveEntry = batterySaveEntry(baseName)
                backupIfExists(saveEntry)   // FEATURE: auto save backup
                // FIX (Twenty-first pass): was saveEntry.nativePath(forWrite
                // = true).path — a /proc/self/fd bridge straight onto the SAF
                // document, mmap'd by the core for the whole session. See the
                // block comment above dataFolderTree() for why that doesn't
                // hold up on a real device. batteryMirrorPath() below is
                // always a plain local path; when a Storage folder is
                // configured it stages the existing save in from there first.
                val savePath = saveEntry.batteryMirrorPath()
                val ok = EmulatorEngine.nativeLoadROM(tmp.absolutePath, savePath)
                Handler(Looper.getMainLooper()).post romLoadDone@ {
                    // FIX: onDestroy() may have already run and freed the
                    // native core by the time this posts, if the load was
                    // slow (large ROM, a slow SAF/cloud-backed URI) and the
                    // user backed out of the app in the meantime. Without
                    // this check, the block below would re-init AudioTrack
                    // and start a brand new game thread + Choreographer
                    // registration after teardown — resources nothing would
                    // ever clean up, since onDestroy() has already run and
                    // won't run again for this instance.
                    if (isFinishing || isDestroyed) return@romLoadDone
                    // BUG FIX: this whole block runs on the MAIN thread,
                    // asynchronously, well after loadRomFromUri's own
                    // try/catch — wrapping the background Thread body above
                    // — has already finished and returned. That catch does
                    // NOT protect anything in here despite the misleading
                    // nesting; Handler.post() only schedules this lambda,
                    // it doesn't run it, so by the time this body actually
                    // executes the outer try is long gone. Any exception
                    // here (Bitmap.createBitmap, AudioTrack init, the
                    // thread/Choreographer setup in startGameLoop()) was
                    // previously a genuine uncaught exception on the main
                    // thread — a hard app crash, with the ROM having *just*
                    // finished loading successfully.
                    try {
                        if (ok) {
                            val w = EmulatorEngine.nativeGetWidth().coerceAtLeast(1)
                            val h = EmulatorEngine.nativeGetHeight().coerceAtLeast(1)
                            frameBuffers = Array(3) {
                                Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                            }
                            writeIdx = 0
                            readyIdx = -1
                            displayIdx = -1
                            romLoaded = true
                            currentRomBaseName = baseName
                            clearPointerState()
                            currentKeys.set(0)
                            fastForwardActive = false
                            initAudioTrack()
                            startGameLoop()
                        } else {
                            romLoaded = false
                            uiToast("Unsupported ROM format")
                        }
                    } catch (e: Throwable) {
                        // Leave the app in a state the user can recover from
                        // instead of a crash: no half-started game, surface
                        // wiped, and romLoaded left false so a tap on the
                        // idle screen (see onGameTouch()) reopens the ROM
                        // browser instead of leaving a dead screen behind.
                        Log.e(TAG, "ROM load post-processing failed", e)
                        uiToast("Load error: ${e.message ?: e.javaClass.simpleName}")
                        romLoaded = false
                        clearSurfaceToBlack()
                    }
                }
            } catch (e: Throwable) {
                Log.e(TAG, "ROM load failed", e)
                uiToast("Load error: ${e.message ?: e.javaClass.simpleName}")
            }
        }.apply { name = "mGBA-load" }.start()
    }

    /** Entry point for loading/swapping the ROM — called from onCreate() on
     *  first launch, from closeGame() when backing out of a game, and from
     *  onGameTouch() when the idle (no-ROM-loaded) surface is tapped.
     *  Launches RomBrowserActivity (a separate Activity as of Thirty-second
     *  pass, not an overlay in this one — see its own top-of-file comment)
     *  and waits for a result; romBrowserLauncher above hands whatever it
     *  returns to loadRomFromUri(). Broad file access, the folder browsing
     *  itself, and the classic single-document SAF picker fallback are all
     *  that Activity's own concern now, not this one's. */
    private fun changeRom() {
        romBrowserLauncher.launch(Intent(this, RomBrowserActivity::class.java))
    }

    // ── Save / state file naming ─────────────────────────────────────────
    // SAF (Storage Access Framework) URIs don't carry a real filesystem
    // path, and the only identifier for "which ROM is this" that's stable
    // across app restarts and re-picking the same file is the picked
    // document's display name — queried via ContentResolver, since
    // uri.lastPathSegment is often an opaque provider-specific ID rather
    // than the actual filename on many document providers (Downloads,
    // Google Drive, etc).

    private fun deriveRomBaseName(uri: Uri): String {
        var display: String? = null
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { c ->
                    val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0 && c.moveToFirst()) display = c.getString(idx)
                }
        } catch (_: Exception) {
            // Provider didn't support the query — fall through to the
            // URI-based fallback below.
        }
        val base = (display ?: uri.lastPathSegment ?: "rom").substringBeforeLast('.')
        // Keep only filesystem-safe characters — a display name can contain
        // spaces, parentheses, unicode, anything a user or provider chose.
        val sanitized = base.replace(Regex("[^A-Za-z0-9_-]"), "_").take(80)
        return sanitized.ifBlank { "rom" }
    }

    private fun savesDir():  File = File(filesDir, "saves").apply  { mkdirs() }
    private fun statesDir(): File = File(filesDir, "states").apply { mkdirs() }

    /** Path for the cartridge's battery save (SRAM/Flash/EEPROM), in this
     *  app's own internal storage — the ONLY location before this feature
     *  existed, and still the fallback location: see SaveEntry below for
     *  where a save/state/screenshot actually ends up once a Storage
     *  folder has been chosen. */
    private fun batterySaveFile(baseName: String): File =
        File(savesDir(), "$baseName.sav")

    /** Legacy path for save-state slot [slot] (1-based). See batterySaveFile
     *  above re: "legacy". */
    private fun stateSlotFile(slot: Int): File =
        File(statesDir(), "$currentRomBaseName.state$slot")

    /**
     * Legacy path for save-state slot [slot]'s thumbnail PNG, sitting next
     * to the state file itself (same dir, same base name, `.png`
     * appended). Written by [captureStateThumbnail] right after a
     * successful save; simply absent for an empty slot, or for a slot
     * saved before this feature existed — both cases are handled the same
     * way by [showSaveStateSlotDialog].
     */
    private fun stateThumbFile(slot: Int): File =
        File(statesDir(), "$currentRomBaseName.state$slot.png")

    /** Legacy path for the dedicated "quick save" slot — separate from the
     *  numbered Slot 1..SAVE_STATE_SLOTS files above, so a tap on the
     *  on-screen Quick Save/Quick Load buttons (see actionButtonAt/
     *  triggerActionButton) never collides with, or gets confused for, a
     *  save the user deliberately put in one of the numbered slots via
     *  showSaveStateSlotDialog(). No thumbnail file for this one — it's
     *  only ever reached by a direct tap, never shown in a slot-picker
     *  list, so there's nothing that would ever display it. */
    private fun quickStateFile(): File =
        File(statesDir(), "$currentRomBaseName.quicksave")

    // ── FEATURE: Storage folder (saves/states/screenshots outside app data) ──
    //
    // Everything above this comment is untouched from before this feature
    // existed, and stays the fallback: someone who never opens Settings →
    // Storage sees exactly the same behavior as always, saves included.
    //
    // What's new: PREF_DATA_FOLDER_URI, set via showStorageSettings() below,
    // points at a folder the user picked with the system folder-picker
    // (SAF's OpenDocumentTree, via dataFolderPicker below — the ROM
    // browser used this same mechanism too until this pass, see
    // CHANGELOG.md/FILE_CHANGES.md's free-roam-file-manager entry for why
    // it moved to plain java.io.File instead; this feature has a
    // different tradeoff, see dataFolderPicker's own comment, and keeps
    // the SAF tree it already had). Once set, THREE
    // subfolders inside it — "save", "cheat", "screenshot" — hold
    // everything that used to live under this app's own internal storage:
    // battery saves and every save-state/thumbnail/quicksave under "save"
    // (there's only one user-facing "Save" action even though this app
    // internally has both battery saves and save-states, so they share one
    // folder rather than splitting a distinction the user never asked
    // for), "cheat" sits ready and empty for whenever a cheat-file feature
    // exists (see MainActivity's own "Cheats — not implemented yet" row —
    // this doesn't add that feature, just gives it somewhere to write once
    // it exists), and "screenshot" replaces the old
    // getExternalFilesDir()/Screenshots location (see saveScreenshotBitmap
    // further down).
    //
    // Deliberately still SAF, not MANAGE_EXTERNAL_STORAGE (the ROM browser's
    // own choice as of Thirty-second pass — see RomBrowserActivity.kt's
    // top-of-file comment): this feature only ever needs ONE folder, picked
    // once, with no reason to ever browse elsewhere afterward — exactly what
    // SAF's OpenDocumentTree is for. No scary system permission dialog for
    // something this occasional, no Play Store policy risk, works
    // identically across Android versions. The ROM browser needed the
    // broader permission specifically because free navigation *anywhere*
    // was the actual feature being asked for there — a different
    // requirement this one doesn't share, not a reason to switch this one
    // too just because that one did. The one wrinkle specific to
    // *this* feature: nativeSaveState()/nativeLoadState()/nativeLoadROM()'s
    // save path all expect a plain fopen()-able path string (they hand it
    // straight to mGBA's VFileOpen — see mgba_jni.c), and a SAF document's
    // content:// URI is not one.
    //
    // FIX (Twenty-first pass): the previous pass bridged that gap via
    // /proc/self/fd/<N> — reopening a ParcelFileDescriptor's fd as a plain
    // path and handing THAT straight to native VFileOpen, including for the
    // battery save, which the core mmaps for the entire session. That was
    // flagged in KNOWN_LIMITATIONS.md as unconfirmed on a real device, and a
    // real-device test this pass showed it doesn't hold up — the reported
    // symptom was exactly "doesn't save and load" once a Storage folder was
    // in use. Root cause: nothing forces a re-opened SAF fd to support
    // mmap/seek/O_TRUNC the way native VFileOpen needs, and that support is
    // provider-specific, not guaranteed by the framework.
    //
    // Replaced with a strictly simpler scheme native code can't get wrong:
    // native NEVER touches a SAF document directly. It always fopen()s a
    // plain file under this app's own internal storage — exactly as it did
    // before this feature existed — and Kotlin copies bytes to/from the
    // chosen folder's document on either side of that call, using
    // ContentResolver's stream APIs, which every DocumentsProvider is
    // required to support (unlike mmap/seek/truncate through a re-opened
    // descriptor). See SaveEntry.stageForRead()/stageForWrite()/
    // commitWrite() for the one-shot save-state/thumbnail case, and
    // batteryMirrorPath()/syncBatteryMirror() for the session-long battery
    // save. Slightly more I/O (a copy instead of a direct mmap), never
    // measurable next to a save file's actual size (a few KB to maybe a few
    // hundred KB), in exchange for not depending on undocumented provider
    // behavior for the one thing this feature actually has to get right.
    //
    // No migration: switching to a folder here does NOT move whatever
    // already exists under internal storage — only new saves/states/
    // screenshots go to the new location from that point on. Doing that
    // move automatically would mean silently rewriting or deleting a
    // user's actual game-save data with no real device available anywhere
    // in this project's history to verify it against — see
    // KNOWN_LIMITATIONS.md. showStorageSettings() says this plainly before
    // anyone taps "Choose folder".

    /** The user's chosen Storage folder, or null if none has been picked
     *  (the default — see the block comment above) or the app's
     *  permission for it is no longer valid (folder deleted/moved outside
     *  the app, permission revoked in system Settings, etc.) — in which
     *  case every SaveEntry below transparently falls back to its legacy
     *  internal-storage path, same as if nothing had ever been picked. */
    private fun dataFolderTree(): DocumentFile? {
        val uriStr = getSharedPreferences(PREFS, MODE_PRIVATE).getString(PREF_DATA_FOLDER_URI, null)
            ?: return null
        return try {
            val uri = Uri.parse(uriStr)
            val stillGranted = contentResolver.persistedUriPermissions.any {
                it.uri == uri && it.isReadPermission && it.isWritePermission
            }
            if (!stillGranted) return null
            DocumentFile.fromTreeUri(this, uri)?.takeIf { it.exists() && it.canWrite() }
        } catch (e: Exception) {
            Log.w(TAG, "dataFolderTree() unusable, falling back to internal storage", e)
            null
        }
    }

    /** Gets-or-creates one of the three fixed subfolders ("save", "cheat",
     *  "screenshot") inside the chosen Storage folder. Null if no folder is
     *  configured, or if creating the subfolder failed for any reason. */
    private fun dataSubfolder(name: String): DocumentFile? {
        val root = dataFolderTree() ?: return null
        return try {
            root.findFile(name)?.takeIf { it.isDirectory } ?: root.createDirectory(name)
        } catch (e: Exception) {
            Log.w(TAG, "dataSubfolder($name) failed", e)
            null
        }
    }

    /**
     * One save-adjacent file — a battery save, a numbered state slot, a
     * state thumbnail, or the quicksave slot — that transparently lives in
     * either this app's internal storage ([legacy], unchanged default) or
     * the [subfolder] ("save") of the user's chosen Storage folder, once
     * one is set. See the block comment above dataFolderTree() for the
     * full reasoning; this class is just the per-file interface onto it,
     * used from quickSaveState()/quickLoadState()/showSaveStateSlotDialog()/
     * captureStateThumbnail()/the two nativeLoadROM() call sites.
     */
    private inner class SaveEntry(private val legacy: File, private val subfolder: String = "save") {
        private fun doc(create: Boolean): DocumentFile? {
            val dir = dataSubfolder(subfolder) ?: return null
            return try {
                dir.findFile(legacy.name)
                    ?: if (create) dir.createFile("application/octet-stream", legacy.name) else null
            } catch (e: Exception) {
                Log.w(TAG, "SaveEntry.doc(${legacy.name}) failed", e); null
            }
        }

        private val usesDataFolder: Boolean get() = dataFolderTree() != null

        fun exists(): Boolean = if (usesDataFolder) doc(create = false) != null else legacy.exists()

        fun lastModified(): Long =
            if (usesDataFolder) (doc(create = false)?.lastModified() ?: 0L) else legacy.lastModified()

        /** Best-effort delete; used by backupIfExists' callers indirectly
         *  through overwrite semantics only — nothing currently calls this
         *  directly, kept for symmetry with the rest of this class. */
        fun delete(): Boolean = if (usesDataFolder) (doc(create = false)?.delete() ?: false) else legacy.delete()

        /** The sibling "<name>.bak" entry backupIfExists() copies this one
         *  into — same folder this entry itself resolves to, legacy or
         *  Storage folder alike. */
        fun backupEntry(): SaveEntry = SaveEntry(File(legacy.parentFile, "${legacy.name}.bak"), subfolder)

        /** For plain Kotlin-side writes (state thumbnails, and
         *  backupIfExists' own copy, and commitWrite()/syncBatteryMirror()
         *  below) — NOT for native fopen()-based calls, which always get a
         *  local path instead; see stageForRead()/stageForWrite() below.
         *  "wt" explicitly, not the 2-arg openOutputStream(uri)'s default
         *  "w": some providers only guarantee truncation with "wt" — a
         *  plain "w" that happens to write fewer bytes than the previous
         *  save could otherwise leave stale trailing bytes behind. */
        fun outputStream(): OutputStream {
            if (!usesDataFolder) return legacy.outputStream()
            val d = doc(create = true) ?: throw IOException("Couldn't create ${legacy.name} in the chosen folder")
            return contentResolver.openOutputStream(d.uri, "wt") ?: throw IOException("openOutputStream failed for ${legacy.name}")
        }

        /** Null if the entry doesn't exist yet — mirrors the legacy
         *  `if (!f.exists()) return` checks this replaces. */
        fun inputStream(): InputStream? {
            if (!usesDataFolder) return if (legacy.exists()) legacy.inputStream() else null
            val d = doc(create = false) ?: return null
            return contentResolver.openInputStream(d.uri)
        }

        /** Where stageForRead()/stageForWrite() below put their scratch
         *  copy — this app's own cache dir, one fixed name per (subfolder,
         *  legacy name) pair, so a repeated save/load against the same slot
         *  reuses the same scratch file instead of littering the cache. */
        private fun stagingFile(): File = File(cacheDir, "saf_stage_${subfolder}_${legacy.name}")

        /**
         * A LOCAL, REAL file path — never a content:// URI — that already
         * holds this entry's current bytes, ready for
         * nativeLoadState()/nativeLoadROM() to fopen() and read. Returns
         * null if the entry doesn't exist yet, same as the exists() checks
         * every caller already does first.
         *
         * When no Storage folder is configured this is just [legacy]'s own
         * path — already a real local file, nothing to stage. When one IS
         * configured, this copies the SAF document's bytes into a scratch
         * file under this app's cache dir first (via inputStream() above,
         * which every DocumentsProvider supports), then hands back THAT
         * path. See the block comment above dataFolderTree() for why this
         * replaced a direct SAF-fd bridge this pass.
         */
        fun stageForRead(): String? {
            if (!usesDataFolder) return if (legacy.exists()) legacy.absolutePath else null
            val input = inputStream() ?: return null
            val tmp = stagingFile()
            return try {
                input.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                tmp.absolutePath
            } catch (e: Exception) {
                Log.w(TAG, "SaveEntry.stageForRead(${legacy.name}) failed", e)
                null
            }
        }

        /**
         * A LOCAL, REAL file path for nativeSaveState() to fopen() and
         * write into. When no Storage folder is configured this is just
         * [legacy]'s own path — the write lands directly where it always
         * has, nothing further needed. When one IS configured, this is a
         * scratch file under this app's cache dir; the caller MUST call
         * commitWrite() with this same path immediately after a
         * *successful* native write, or the bytes never reach the chosen
         * folder — see commitWrite() below.
         */
        fun stageForWrite(): String {
            if (!usesDataFolder) return legacy.absolutePath
            return stagingFile().absolutePath
        }

        /** Copies whatever native just wrote at [localPath] (from a prior
         *  stageForWrite() call) into the real SAF document. No-op when no
         *  Storage folder is configured — native already wrote straight to
         *  [legacy] in that case, there's nothing left to copy. Callers
         *  must only invoke this after confirming the native write actually
         *  succeeded: calling it unconditionally would happily overwrite a
         *  perfectly good existing save with a partial/empty file on a
         *  failed write. */
        fun commitWrite(localPath: String) {
            if (!usesDataFolder) return
            try {
                File(localPath).inputStream().use { input ->
                    outputStream().use { out -> input.copyTo(out) }
                }
            } catch (e: Exception) {
                Log.w(TAG, "SaveEntry.commitWrite(${legacy.name}) failed — folder copy not updated, local save is still intact", e)
            }
        }

        /** FIX (menu-slot speed pass): moves this entry's current bytes into
         *  [dest] (its ".bak" sibling), replacing whatever was there —
         *  called right before this slot is about to be overwritten by a
         *  fresh save. When no Storage folder is configured this is a
         *  single File.renameTo(): an instant, metadata-only move on the
         *  same volume, NOT a byte-for-byte copy. backupIfExists() used to
         *  read this entry's full bytes and write them out again just to
         *  have nativeSaveState() immediately overwrite this same file
         *  anyway right after — up to 2x a save-state's worth of disk I/O
         *  on every single save, which was most of "pick a slot -> Saved"
         *  feeling slow. Deletes any existing [dest] first, since
         *  File.renameTo()'s platform behavior when the destination already
         *  exists isn't guaranteed. Falls back to copy (old behavior) if
         *  the rename fails for any reason, or whenever a Storage folder
         *  IS configured — DocumentFile has no equivalent plain rename
         *  here, so that path is unchanged from before this fix. */
        fun moveInto(dest: SaveEntry) {
            if (!usesDataFolder && !dest.usesDataFolder) {
                dest.legacy.delete()
                if (legacy.renameTo(dest.legacy)) return
            }
            inputStream()?.use { input -> dest.outputStream().use { out -> input.copyTo(out) } }
        }

        /**
         * The real, local, persistent path nativeLoadROM() mmaps this
         * entry's battery save through for the *entire* ROM session — the
         * one save-adjacent file that can't just be staged-and-discarded
         * per call, since the core keeps writing to it live for as long as
         * the ROM is running (see mgba_jni.c's core->loadSave() comment).
         *
         * When no Storage folder is configured this is just [legacy]
         * itself, exactly as before this feature existed. When one IS
         * configured, [legacy] is used as a local *mirror*: whatever bytes
         * already exist in the chosen folder are copied in here first (so
         * a save carries over from wherever it was last written), the core
         * then mmaps this same local file for the whole session same as
         * always, and syncBatteryMirror() below copies its current bytes
         * back out to the real document at the points in this file that
         * call it (onPause, before swapping ROMs, onDestroy). A failed
         * copy-in here just means starting from whatever's already local
         * (same as a fresh save) rather than losing the load entirely.
         */
        fun batteryMirrorPath(): String {
            if (usesDataFolder) {
                try {
                    inputStream()?.use { input -> legacy.outputStream().use { out -> input.copyTo(out) } }
                } catch (e: Exception) {
                    Log.w(TAG, "SaveEntry.batteryMirrorPath(${legacy.name}): couldn't stage existing save from the chosen folder, continuing from whatever's already local", e)
                }
            }
            return legacy.absolutePath
        }

        /** Copies [legacy]'s current bytes — the mirror nativeLoadROM has
         *  been mmap-writing to all session — out to the real SAF
         *  document. No-op when no Storage folder is configured, or if
         *  [legacy] doesn't exist yet (nothing played, nothing to sync). */
        fun syncBatteryMirror() {
            if (!usesDataFolder || !legacy.exists()) return
            try {
                legacy.inputStream().use { input -> outputStream().use { out -> input.copyTo(out) } }
            } catch (e: Exception) {
                Log.w(TAG, "SaveEntry.syncBatteryMirror(${legacy.name}) failed — folder copy may be stale, local mirror still has the latest", e)
            }
        }
    }

    private fun batterySaveEntry(baseName: String): SaveEntry = SaveEntry(batterySaveFile(baseName), "save")
    private fun stateSlotEntry(slot: Int): SaveEntry = SaveEntry(stateSlotFile(slot), "save")
    private fun stateThumbEntry(slot: Int): SaveEntry = SaveEntry(stateThumbFile(slot), "save")
    private fun quickStateEntry(): SaveEntry = SaveEntry(quickStateFile(), "save")

    /** Set only while showStorageSettings()'s dialog is on screen, so
     *  dataFolderPicker's callback above can refresh its status text in
     *  place instead of needing the user to close and reopen it. */
    private var refreshStorageSettingsUi: (() -> Unit)? = null

    /** FIX (quicksave race pass): guards quickSaveState()/quickLoadState()
     *  against overlapping calls. Both used to spawn a brand-new, totally
     *  unsynchronized Thread on every tap — a fast double-tap of Quick Save,
     *  or Quick Save immediately followed by Quick Load (exactly the "test
     *  saving/loading fast" case), fired two Threads with no ordering
     *  between them. g_core_mutex on the native side only serializes the
     *  moment of the actual file write/read against the running game
     *  thread — it does NOT decide which Kotlin thread reaches that point
     *  first. So a fast second tap could win that race and load the file
     *  from BEFORE the first tap's save had written it (looks like it
     *  "loaded the old/first save"), or two saves could land in either
     *  order (looks like it "saved a different frame" than expected). This
     *  flag makes a tap that arrives while one is still in flight a no-op
     *  (with its own toast) instead of racing — same one-thing-at-a-time
     *  guarantee MyBoy's pause-then-menu flow gets for free by construction.
     *
     *  FIX (audit pass): renamed from quickStateBusy and now also guards
     *  showSaveStateSlotDialog()'s save/load Thread, which had the exact
     *  same unguarded pattern — every reason above applies identically
     *  there (it calls the same nativeSaveState()/nativeLoadState(), off
     *  the same kind of bare background Thread, with no ordering between
     *  overlapping calls either). Narrower to actually hit in practice —
     *  the slot dialog dismisses itself after one tap, so it takes two
     *  separate menu visits in quick succession rather than one fast
     *  double-tap on an always-visible button — but it's the identical
     *  underlying race, and one flag correctly covering *every* save-state
     *  operation (quick or slot) is simpler and safer than two flags that
     *  would each need to know about the other to close the gap between
     *  them (a quick-save racing a slot-load, etc.). */
    private val saveStateBusy = java.util.concurrent.atomic.AtomicBoolean(false)

    private fun quickSaveState() {
        if (!romLoaded) { uiToast("Load a ROM first"); return }
        if (!saveStateBusy.compareAndSet(false, true)) {
            uiToast("Still saving/loading — try again in a moment"); return
        }
        val entry = quickStateEntry()
        // Off the UI thread — same reasoning as showSaveStateSlotDialog's
        // Thread below: touches disk and briefly holds the native core's
        // mutex against the running game thread.
        Thread {
            try {
                backupIfExists(entry)
                val localPath = entry.stageForWrite()
                val ok = EmulatorEngine.nativeSaveState(localPath)
                if (ok) entry.commitWrite(localPath)
                uiToast(if (ok) "Quick saved" else "Quick save failed")
            } finally {
                saveStateBusy.set(false)
            }
        }.apply { name = "mGBA-quicksave" }.start()
    }

    private fun quickLoadState() {
        if (!romLoaded) { uiToast("Load a ROM first"); return }
        if (!saveStateBusy.compareAndSet(false, true)) {
            uiToast("Still saving/loading — try again in a moment"); return
        }
        val entry = quickStateEntry()
        // FIX (lag pass): entry.exists() used to run right here, on the UI
        // thread, before ever spawning a background thread — the same
        // SAF-round-trip cost as showSaveStateSlotDialog's old exists()
        // calls, just once instead of a dozen. Moved inside the thread
        // below so a slow/SAF-backed check can't stall the UI either.
        Thread {
            try {
                if (!entry.exists()) { uiToast("No quick save yet"); return@Thread }
                val localPath = entry.stageForRead()
                val ok = localPath != null && EmulatorEngine.nativeLoadState(localPath)
                uiToast(if (ok) "Quick loaded" else "Quick load failed — may be from a different ROM")
            } finally {
                saveStateBusy.set(false)
            }
        }.apply { name = "mGBA-quickload" }.start()
    }

    /**
     * FEATURE: auto save backup. Copies [entry] to its sibling
     * [SaveEntry.backupEntry] — same folder [entry] itself resolves to,
     * legacy internal storage or the chosen Storage folder alike — if it
     * already exists, right before it's about to be overwritten: the
     * battery save is re-opened read/write and mmap'd by the native core
     * on every ROM load (see nativeLoadROM), and a save-state slot is
     * truncated the instant "Save State" is tapped (see nativeSaveState/
     * showSaveStateSlotDialog). Best-effort and silent: a backup failure
     * must never block the actual save, so any exception here is only
     * logged, never surfaced to the user.
     *
     * This is a single rolling backup, not a history — each new backup
     * replaces the last. It's a one-level rollback if the current session's
     * save turns out to be corrupt (app killed mid-write, storage fills up,
     * a bad ROM stomps save memory it shouldn't, etc.), not a substitute
     * for the user making their own backups of anything precious. There is
     * currently no in-app "restore from backup" UI — see KNOWN_LIMITATIONS.md.
     */
    private fun backupIfExists(entry: SaveEntry) {
        if (!entry.exists()) return
        try {
            entry.moveInto(entry.backupEntry())
        } catch (e: Exception) {
            Log.w(TAG, "Backup failed (continuing without one)", e)
        }
    }

    // ── Lifecycle ──────────────────────────────────────────────────────────

    /** FEATURE: new — self-service crash log. W can't pull logcat off this
     *  device for reasons neither of us has pinned down, which blocks the
     *  normal "send me the stack trace" loop entirely. This sidesteps that:
     *  it wraps whatever the default uncaught-exception handler already
     *  was, so a crash still behaves exactly as it always did (process
     *  dies, system shows its usual "stopped" behavior) — but first writes
     *  the full exception, stack trace, thread name, and device info to a
     *  plain file this app owns outright (File(filesDir, "crash_log.txt"),
     *  same pattern as the FIX 17 link-debug log). Exposed through the
     *  existing ⚙ menu's new "Copy crash log" row (see showGameMenu() /
     *  copyCrashLog() below) so it can be grabbed with nothing but a tap +
     *  paste, no PC/adb/logcat involved. Overwrites on each crash (not
     *  appended) so it always reflects the MOST RECENT crash, never a
     *  stale one from an already-fixed issue.
     *
     *  Everything in here is wrapped defensively — a crash handler that
     *  itself throws (e.g. disk full while writing the report) must still
     *  fall through to the real handler below, or the app would hang
     *  instead of dying cleanly, which is a worse failure mode than simply
     *  losing that one report. */
    private fun installCrashLogger() {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val trace = StringWriter().also { throwable.printStackTrace(PrintWriter(it)) }.toString()
                val report = buildString {
                    appendLine("mGBA crash report")
                    appendLine("Time: ${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US).format(java.util.Date())}")
                    appendLine("Thread: ${thread.name}")
                    appendLine("Device: ${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})")
                    appendLine()
                    append(trace)
                }
                File(filesDir, "crash_log.txt").writeText(report)
            } catch (_: Throwable) {
                // See doc comment above — must not block the real handoff below.
            }
            if (previous != null) {
                previous.uncaughtException(thread, throwable)
            } else {
                android.os.Process.killProcess(android.os.Process.myPid())
                kotlin.system.exitProcess(10)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // FEATURE: new — self-service crash log, no logcat/adb needed. See
        // installCrashLogger()'s own doc comment. Installed as the literal
        // first thing after super.onCreate() so it's active before
        // anything else in this method — or any background thread this
        // method goes on to spawn, e.g. loadRomFromUri()'s — gets a chance
        // to throw.
        installCrashLogger()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        // FIX: let the window draw into the camera-cutout area instead of
        // leaving the default black bar there. LAYOUT_IN_DISPLAY_CUTOUT_MODE_
        // DEFAULT letterboxes around the cutout on whichever edge it sits
        // on — most visible in landscape (still the default orientation
        // below), where the cutout (normally the phone's physical top edge,
        // a "short" edge) ends up intruding into the middle of the
        // horizontal game view instead of just sitting inside a status bar
        // that's already hidden.
        //
        // FIX (this pass): reported as still a lot of black area around the
        // cutout even with SHORT_EDGES. Upgraded to ALWAYS on API 30+,
        // which is a strict superset of SHORT_EDGES — "content is always
        // allowed to extend into the cutout areas" outright, with none of
        // SHORT_EDGES's own conditions about which edge or bar state — so
        // this can only extend the drawable area further, never shrink it.
        // ALWAYS needs API 30 specifically (SHORT_EDGES, the previous only
        // option here, needs API 28); below 30 this still falls back to
        // SHORT_EDGES exactly as before. Genuinely uncertain this fully
        // explains what was reported rather than just being a real,
        // separate improvement alongside it — no device in this sandbox to
        // confirm either way, and "a lot of black screen" without a
        // screenshot leaves real room for this being partly/wholly a
        // different area entirely (see RomBrowserActivity.kt, which had no
        // cutout handling at all before this pass — a confirmed gap, not a
        // guess, since that Activity is new this same overall changeset).
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        // Load saved preferences
        getSharedPreferences(PREFS, MODE_PRIVATE).also { p ->
            fastForwardSpeed      = p.getFloat(PREF_FF_SPEED,    2.0f)
            buttonScaleMultiplier = p.getFloat(PREF_BTN_SCALE,   1.0f)
            buttonBaseAlpha       = p.getInt(PREF_BTN_ALPHA,      160)
            gameScreenFraction    = p.getFloat(PREF_SCREEN_FRAC, GAME_FRAC_NORM)
            stretchToFit          = p.getBoolean(PREF_STRETCH,    false)
            maxFrameSkips         = p.getInt(PREF_MAX_SKIPS,      0)
            linearFilterEnabled   = p.getBoolean(PREF_LINEAR_FILTER, false)
            buttonSoundEnabled    = p.getBoolean(PREF_BTN_SOUND,  false)
            showFpsOverlay        = p.getBoolean(PREF_SHOW_FPS,   false)
            screenOrientationChoice = p.getInt(PREF_ORIENTATION, ORIENTATION_LANDSCAPE)
        }
        updateLinearFilterPaint()
        // FEATURE: screen orientation setting (Video settings, see
        // applyScreenOrientationPref()/showVideoSettings()). This used to be
        // a fixed requestedOrientation = SCREEN_ORIENTATION_LANDSCAPE right
        // here, with android:screenOrientation="landscape" in the manifest
        // on top of it — see AndroidManifest.xml for why that attribute is
        // now "unspecified" instead. android:configChanges there already
        // keeps this activity (and the running core) alive across whatever
        // orientation change this causes, exactly as it did for the old
        // hardcoded assignment, so nothing about restart/config-change
        // handling needed to change for this.
        applyScreenOrientationPref()
        audioManager = getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        loadCustomLayout()

        link = LinkMultiplayer(this)

        // FIX 17: durable link-debug logging that doesn't depend on OS
        // logcat access — see KNOWN_LIMITATIONS.md's "The debug-log tool
        // doesn't work on every phone" and copyLinkDebugLog() below, which
        // now reads this file instead of shelling out to `logcat`. filesDir
        // is always writable by this app, on every device, with no
        // permission needed — unlike reading back the system's own logcat
        // buffer, which some OEM builds restrict even for an app reading
        // its own output.
        EmulatorEngine.nativeSetLinkLogPath(File(filesDir, "link_debug.log").absolutePath)
        // FIX 9: previously nothing ever told this side when the *other*
        // phone disconnected — isConnected only ever went back to false via
        // our own local "Disconnect" tap. link.onPeerLost fires from
        // LinkMultiplayer's liveness watchdog / BYE handling, already on the
        // main thread, so this can update UI directly.
        link.onPeerLost = { EmulatorEngine.nativeLinkStop(); uiToast("Peer disconnected") }
        val root = FrameLayout(this)
        surfaceView = SurfaceView(this)
        surfaceView.holder.addCallback(this)
        root.addView(surfaceView, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        // FIX (this pass): the floating "▶ Load ROM" button that used to sit
        // here is gone. It was a Button, and a stock Material Button carries
        // a small default elevation even when nothing sets one explicitly —
        // enough that Android's Z-order draws it ABOVE the opaque
        // settingsMenuOverlay added later in this method (and, before it
        // became a separate Activity, the ROM browser overlay too),
        // regardless of add order. Since changeRom() (below, and on Close —
        // see closeGame()) already opens the ROM browser automatically any
        // time there's no ROM loaded, that button was floating uselessly on
        // top of the browser it was supposed to sit *behind* — visible as a
        // stray purple pill hovering over the file list. Removed outright
        // rather than patched (e.g. elevation = 0f), since changeRom()
        // already covers every case it existed for. The one thing it also
        // did — give the user a way back in in the two edge cases where
        // nothing else is on screen (the folder picker gets cancelled
        // before any folder's ever been chosen, or a ROM load fails) — is
        // now handled by onGameTouch() below: tapping the idle surface while
        // no ROM is loaded calls changeRom() directly.

        // UI: the 🔗 Link and 📂 change-ROM buttons that used to float here
        // (top-right, always on top of the game view) are gone — both now
        // live as rows inside the Settings list instead ("Link remote",
        // "Link local", "Change ROM" — see buildSettingsMenu()), reached via
        // the ⚙ button below. One less pair of icons sitting over gameplay,
        // and Settings was already scrollable so the extra rows just fit.
        settingsBtn = TextView(this).apply {
            text = "⚙"; textSize = 18f
            setTextColor(Color.WHITE); setPadding(20, 6, 20, 6)
            background = iconChipBackground()
            setOnClickListener { showGameMenu() }
        }
        root.addView(settingsBtn, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT
        ).also { it.gravity = Gravity.TOP or Gravity.START; it.topMargin = 8; it.leftMargin = 8 })

        // ── Control-layout editor UI ────────────────────────────────────────
        // Two small real-View toolbars layered above the SurfaceView. Editing
        // itself (drag/resize hit-testing) happens on the SurfaceView's touch
        // events (see onEditTouch) exactly like normal gameplay input — these
        // bars are just chrome: mode controls + per-button fine adjustment.
        fun editChip(label: String, onClick: () -> Unit) = Button(this).apply {
            text = label; textSize = 12f; setPadding(18, 4, 18, 4)
            minWidth = 0; minimumWidth = 0; minHeight = 0; minimumHeight = 0
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#552A2A3A"))
            setOnClickListener { onClick() }
        }

        editTopBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(12, 8, 12, 8)
            setBackgroundColor(Color.parseColor("#DD1A1A22"))
            visibility = View.GONE
            addView(TextView(this@MainActivity).apply {
                text = "🖊 EDIT LAYOUT"
                setTextColor(Color.parseColor("#FFEE58")); textSize = 12f
                setPadding(8, 8, 24, 8)
            })
            // ADD/REMOVE CONTROL — opens the picker of currently-hidden
            // controls (see showAddControlMenu). Removing one is done by
            // holding it instead (see onEditTouch/showRemoveButtonMenu) —
            // full instructions are in the toast shown on entering edit
            // mode (enterEditMode()), kept off this bar so it stays short
            // enough to fit alongside these buttons in landscape.
            addView(editChip("＋ Add control") { showAddControlMenu() })
            addView(editChip("↺ Reset All")    { confirmResetAllLayout() })
            addView(editChip("✕ Cancel")       { exitEditMode(save = false) })
            addView(editChip("✓ Done")         { exitEditMode(save = true) })
        }
        // Wrapped in a HorizontalScrollView so this row degrades to
        // scrollable (instead of clipping off-screen) on narrower landscape
        // widths now that it holds four buttons instead of three — see the
        // BUG FIX comments around the button-editor's hitbox/precision
        // issues above for the broader "landscape + this editor" theme.
        // Visibility is still toggled on editTopBar itself (enterEditMode/
        // exitEditMode) — a GONE child collapses this wrapper to nothing,
        // so no extra plumbing needed here for that.
        val editTopBarScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(editTopBar)
        }
        root.addView(editTopBarScroll, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT
        ).also { it.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; it.topMargin = 8 })

        editButtonLabel = TextView(this).apply {
            textSize = 12f; setTextColor(Color.WHITE); setPadding(14, 4, 14, 4)
        }
        editLockBtn = editChip("🔓") { toggleSelectedLock() }
        editButtonBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(10, 6, 10, 6)
            setBackgroundColor(Color.parseColor("#EE22222E"))
            visibility = View.GONE
            addView(editButtonLabel)
            addView(editChip("Size－") { adjustSelectedScale(-0.1f) })
            addView(editChip("Size＋") { adjustSelectedScale(+0.1f) })
            addView(editChip("Op－")   { adjustSelectedAlpha(-20) })
            addView(editChip("Op＋")   { adjustSelectedAlpha(+20) })
            addView(editLockBtn)
            addView(editChip("↺") { editSelectedId?.let { resetSingleButton(it) } })
        }
        // Positioned dynamically (see refreshEditToolbarPosition) — x/y set
        // directly rather than via gravity, since it needs to track whichever
        // button is currently selected.
        root.addView(editButtonBar, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT))

        // ── Settings screen ──────────────────────────────────────────────
        // Built once and just shown/hidden (same pattern as editTopBar
        // above) — it has no dynamic state of its own, unlike the category
        // dialogs it opens, which rebuild their fields fresh every time.
        settingsMenuOverlay = buildSettingsMenu().apply { visibility = View.GONE }
        root.addView(settingsMenuOverlay, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        // ── Memory viewer ────────────────────────────────────────────────
        // Same built-once/shown-hidden pattern as Settings just above — see
        // showMemoryViewer()'s doc comment for why this is an overlay
        // rather than its own Activity (needs the game loop to keep
        // running underneath it, unlike the ROM browser).
        memoryViewerOverlay = buildMemoryViewer().apply { visibility = View.GONE }
        root.addView(memoryViewerOverlay, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        // ROM file browser: was built and attached here as an overlay,
        // same built-once/shown-hidden pattern as the Settings screen just
        // above — now RomBrowserActivity.kt, its own Activity, launched via
        // changeRom()/romBrowserLauncher instead. Nothing to build here.

        setContentView(root)
        surfaceView.setOnTouchListener { _, ev -> onGameTouch(ev); true }
        setImmersive()

        // FEATURE: land straight in ROM selection instead of requiring an
        // explicit tap first — changeRom() launches RomBrowserActivity
        // unconditionally; whether that lands the user straight in the
        // folder they last browsed, prompts for permission first, or
        // whatever else, is entirely that Activity's own concern now (see
        // RomBrowserActivity.kt), not something this onCreate() needs to
        // know about. If the user backs out of it with nothing picked
        // (permission denied, cancelled, whatever), romBrowserLauncher's
        // callback above does nothing and the surface just sits idle —
        // tapping it calls changeRom() again (see onGameTouch()), so
        // there's still a way back in without any button needed underneath.
        changeRom()
    }

    override fun onDestroy() {
        super.onDestroy()
        stopGameLoop()
        // FIX (Twenty-first pass): last-resort flush of the battery-save
        // mirror to the chosen Storage folder, if one is configured — see
        // SaveEntry.syncBatteryMirror(). onPause() below is the main place
        // this happens; this is just a backstop for whatever's played
        // between onPause and the process actually going away, e.g. a
        // resumed session that's then killed outright rather than just
        // backgrounded.
        if (romLoaded) batterySaveEntry(currentRomBaseName).syncBatteryMirror()
        releaseAudio()
        EmulatorEngine.nativeLinkStop()
        link.disconnect()
        EmulatorEngine.nativeDestroy()
    }

    // FIX: no onPause/onResume existed at all. The emulation thread and the
    // AudioTrack were only ever stopped from surfaceDestroyed()/onDestroy(),
    // but backgrounding an app (Home button, recents, notification shade)
    // does not reliably or promptly destroy a SurfaceView's Surface — so the
    // game kept running full-speed and audio kept playing while the app was
    // not visible, burning battery/CPU and producing audio "leaking" behind
    // whatever the user switched to. This is exactly the kind of background
    // battery-drain behavior Play Console's background-usage checks flag.
    override fun onPause() {
        super.onPause()
        stopGameLoop()
        // FIX (Twenty-first pass): flush the battery-save mirror out to the
        // chosen Storage folder (no-op if none is configured, or if nothing
        // has been played yet — see SaveEntry.syncBatteryMirror()). Backgrounding
        // is the single most common way a session actually ends on Android —
        // Home button, notification shade, a phone call — far more often
        // than onDestroy() ever runs, so this is the flush that actually
        // matters in practice; onDestroy()'s own call is just a backstop.
        if (romLoaded) batterySaveEntry(currentRomBaseName).syncBatteryMirror()
        try {
            audioTrack?.pause()
            // AUDIO FIX: pause() alone leaves whatever was already queued in
            // the AudioTrack's internal buffer intact. If the app is
            // backgrounded for a while and then resumed, that stale audio
            // would play first, ahead of anything the resumed game loop
            // writes — an audible "blip" of old sound. flush() (only valid
            // once paused/stopped) discards it so resume always starts clean.
            audioTrack?.flush()
        } catch (_: Exception) {}
    }

    override fun onResume() {
        super.onResume()
        if (romLoaded && surfaceHolder != null && !running) {
            startGameLoop()
        }
    }

    // FIX: setImmersive() was only ever called once, at the very end of
    // onCreate. Every AlertDialog this app opens — the game menu, each
    // Settings category, save-state prompts, all of them — takes window
    // focus away and back, and that resets the old systemUiVisibility
    // flags, so the status/nav bars crept back in the moment any dialog was
    // shown and dismissed. Re-applying on every focus regain (not just
    // launch) is the standard fix for immersive mode "not sticking".
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) setImmersive()
    }

    // ── Audio ──────────────────────────────────────────────────────────────
    //
    // AUDIO ARCHITECTURE (rewritten)
    // ───────────────────────────────
    // Old design: game thread ran nativeRunFrame() once, wrote PCM to
    // AudioTrack with WRITE_NON_BLOCKING (return value discarded), then slept
    // for a *fixed* 1/60 s to pace itself. Two compounding problems:
    //   1. 1/60 s is not the GBA's real frame period (see GBA_CYCLES_PER_FRAME
    //      above), so the loop fed audio ~0.46% faster than it could play.
    //   2. WRITE_NON_BLOCKING silently drops whatever doesn't fit — so that
    //      surplus was thrown away in little bursts instead of building
    //      genuine latency, producing a small periodic glitch.
    //
    // New design: the game thread writes PCM with a genuine *blocking* write
    // and does NOT sleep on its own for the normal-speed case — the blocking
    // write against a real audio clock (the DAC/HAL drain rate) becomes the
    // frame pacer. This is the same "audio-locked" sync strategy used by most
    // well-engineered software emulators: the audio hardware clock is far more
    // stable than Thread.sleep(), which is at the mercy of OS scheduling
    // jitter, so tying video pacing to it removes drift entirely instead of
    // approximating a fixed wall-clock rate. A short fallback sleep
    // (FALLBACK_FRAME_NS) only kicks in for frames that produce zero audio
    // samples (e.g. immediately after a ROM loads), so the loop never spins
    // unpaced if audio is temporarily unavailable.
    //
    // Fast-forward now plays audio too, instead of dropping it outright.
    // Each FF batch's sub-frame audio is accumulated (ffAccumBuffer) and
    // then box-filter decimated down to roughly one frame's worth — see
    // decimateForFastForward() below — before going through the same
    // blocking writePcm() pacer as normal playback. That keeps the loop's
    // real-time pacing (and therefore the actual speedup) intact while
    // producing real, audible, pitched-up audio: the same "sped-up tape"
    // effect classic emulators use for FF sound, not a pitch-accurate
    // resample. A proper interpolating resampler would sound cleaner but is
    // a substantially bigger DSP undertaking for a fairly small audible gain
    // over this.
    // (audioTrack / audioBuffer / audioDiagCounter fields are declared above,
    // grouped with the rest of the class's mutable state.)

    /**
     * (Re)creates the AudioTrack.
     *
     * Buffer size: minBuf * 3. This used to be minBuf * 2 for lower latency,
     * but that cut it too close: rendering used to run on this same thread
     * right after each writePcm() call, and a slow render (a GC pause, a
     * busy compositor) could stall the next write long enough for AudioTrack
     * to run dry — an underrun, heard as a click/pop. Rendering is now
     * decoupled onto its own Choreographer-driven loop (see the triple-buffer
     * fields near the top of this class and startGameLoop()), which removes
     * that particular stall, but minBuf*3 is left as-is: it's cheap headroom
     * against ordinary OS scheduling jitter on the write thread itself, and
     * there's no benefit to shaving it back down.
     *
     * PERFORMANCE_MODE_LOW_LATENCY (API 26+) opts into the platform's fast
     * mixer path when the device supports it. It's a request, not a
     * guarantee — unsupported devices silently fall back to the normal path
     * with no functional risk, so it's safe to always ask for it.
     */
    private fun initAudioTrack() {
        releaseAudio()
        val minBuf = AudioTrack.getMinBufferSize(
            44100,
            AudioFormat.CHANNEL_OUT_STEREO,
            AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(4096)
        val bufferBytes = (minBuf * 3).coerceAtLeast(6144)

        val builder = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(44100)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                    .build()
            )
            .setBufferSizeInBytes(bufferBytes)
            .setTransferMode(AudioTrack.MODE_STREAM)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder.setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
        }

        audioTrack = try { builder.build() } catch (e: Exception) {
            Log.e(TAG, "AudioTrack.Builder failed, retrying without low-latency mode", e)
            // Some OEM audio HALs reject PERFORMANCE_MODE_LOW_LATENCY outright
            // instead of gracefully degrading. Retry once without it so a
            // quirky device still gets sound, even if not the fast path.
            try {
                AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build())
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(44100)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                            .build())
                    .setBufferSizeInBytes(bufferBytes)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()
            } catch (e2: Exception) {
                Log.e(TAG, "AudioTrack unavailable on this device", e2)
                null
            }
        }
        // Explicit full volume — build() already defaults to 1.0f, but this
        // removes any doubt on OEM tracks that have shipped odd defaults.
        try { audioTrack?.setVolume(1.0f) } catch (_: Exception) {}
        requestAudioFocus()
        audioTrack?.play()
        audioDiagCounter = 0
        Log.d(TAG, "AudioTrack started (bufferBytes=$bufferBytes, minBuf=$minBuf, " +
                "lowLatency=${Build.VERSION.SDK_INT >= Build.VERSION_CODES.O})")
    }

    /** See the comment on [audioFocusRequest] for why this exists. */
    private fun requestAudioFocus() {
        val am = audioManager ?: return
        val granted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build())
                .setOnAudioFocusChangeListener(audioFocusListener)
                .build()
            audioFocusRequest = req
            am.requestAudioFocus(req) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        } else {
            @Suppress("DEPRECATION")
            am.requestAudioFocus(
                audioFocusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN
            ) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        }
        Log.d(TAG, "Audio focus granted=$granted")
    }

    private fun abandonAudioFocus() {
        val am = audioManager ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            audioFocusRequest?.let { am.abandonAudioFocusRequest(it) }
            audioFocusRequest = null
        } else {
            @Suppress("DEPRECATION")
            am.abandonAudioFocus(audioFocusListener)
        }
    }

    private fun releaseAudio() {
        try { audioTrack?.stop(); audioTrack?.release() } catch (_: Exception) {}
        audioTrack = null
        abandonAudioFocus()
    }

    /**
     * Blocking write of [count] interleaved stereo PCM pairs from
     * [audioBuffer] to the AudioTrack. Called from the game thread only.
     *
     * Unlike the old WRITE_NON_BLOCKING call (whose return value was
     * discarded), this checks the result:
     *   - a short write (0 < written < requested) retries the remainder —
     *     legitimate under blocking mode only if playback state changed
     *     mid-write (e.g. onPause() firing concurrently), in which case
     *     finishing the write is harmless and cheap.
     *   - ERROR_DEAD_OBJECT means the audio server died/restarted under us
     *     (e.g. mediaserver crash, or another app seized exclusive audio) —
     *     recreate the AudioTrack once and retry, rather than staying silent
     *     for the rest of the session.
     *   - any other negative error code is logged and the frame's audio is
     *     dropped; retrying indefinitely inside the game loop would risk
     *     hanging it.
     */
    private fun writePcm(count: Int) {
        if (count <= 0) return
        val totalShorts = count * 2
        var track = audioTrack ?: return
        var offset = 0
        var attempts = 0
        while (offset < totalShorts && attempts < 2) {
            val n = try {
                track.write(audioBuffer, offset, totalShorts - offset, AudioTrack.WRITE_BLOCKING)
            } catch (e: Exception) {
                Log.e(TAG, "AudioTrack.write threw", e); return
            }
            when {
                n > 0 -> offset += n
                n == AudioTrack.ERROR_DEAD_OBJECT -> {
                    Log.w(TAG, "AudioTrack died — reinitializing")
                    initAudioTrack()
                    track = audioTrack ?: return
                    attempts++
                }
                n < 0 -> { Log.e(TAG, "AudioTrack.write error=$n"); return }
                else  -> return // n == 0: track not started / no progress possible right now
            }
        }
        // Lightweight real-device diagnostics: log the underrun counter every
        // ~5s (300 frames @ ~60Hz) rather than every frame, so it's cheap
        // enough to leave in a release build's logcat for field debugging.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            audioDiagCounter++
            if (audioDiagCounter >= 300) {
                audioDiagCounter = 0
                Log.d(TAG, "AudioTrack underrunCount=${audioTrack?.underrunCount}")
            }
        }
    }

    /**
     * Fast-forward audio compression. Filters and downsamples [accumPairs]
     * stereo pairs in [ffAccumBuffer] (collected across [factor] emulated
     * sub-frames — see the game loop in startGameLoop) down into
     * `audioBuffer`, roughly [factor]x shorter, and returns how many pairs
     * it wrote there. Playing the shorter result back at the normal
     * 44.1kHz rate is what produces the audible pitch-up — expected,
     * inherent to speeding up audio this way, the same "chipmunk" effect
     * any sped-up tape/tune has, not something this function tries to
     * hide.
     *
     * FIX (this pass): reported as sounding "weird" during fast-forward —
     * on top of that expected pitch-up, there was a second, avoidable
     * problem. This used to be plain box-filter decimation (each output
     * pair the equal-weighted mean of one block of [factor] consecutive
     * input pairs), which the original version's own doc comment already
     * called "a cheap stand-in for a proper low-pass filter ahead of the
     * downsample." That stand-in has real weaknesses as an anti-aliasing
     * filter — weak stopband rejection lets high-frequency content fold
     * back down as audible harshness/grain on top of the pitch-up, and its
     * passband isn't flat either, adding a muffled quality. Replaced with
     * the textbook-standard shape instead — filter, then downsample,
     * rather than trying to make the averaging do both jobs at once: a
     * one-pole low-pass runs continuously across the whole accumulated
     * block first (cheap, one multiply-add per sample, so no heavier on
     * this thread than the box average it replaces), then every [factor]th
     * *filtered* sample is kept. alpha follows the standard
     * period-to-EMA-smoothing conversion (2/(period+1)) so the filter's
     * cutoff scales down as [factor] grows, same direction the box
     * average's own implicit cutoff moved, just with a real filter shape
     * behind it instead of a rectangular window's.
     */
    private fun decimateForFastForward(accumPairs: Int, factor: Int): Int {
        if (factor <= 1) {
            val n = accumPairs.coerceAtMost(audioBuffer.size / 2)
            System.arraycopy(ffAccumBuffer, 0, audioBuffer, 0, n * 2)
            return n
        }
        val outPairs = (accumPairs / factor).coerceAtMost(audioBuffer.size / 2)
        val alpha = 2f / (factor + 1)
        var lpL = ffAccumBuffer[0].toFloat()
        var lpR = ffAccumBuffer[1].toFloat()
        var out = 0
        for (i in 0 until accumPairs) {
            lpL += alpha * (ffAccumBuffer[i * 2]     - lpL)
            lpR += alpha * (ffAccumBuffer[i * 2 + 1] - lpR)
            if (out < outPairs && i % factor == factor - 1) {
                audioBuffer[out * 2]     = lpL.toInt().coerceIn(-32768, 32767).toShort()
                audioBuffer[out * 2 + 1] = lpR.toInt().coerceIn(-32768, 32767).toShort()
                out++
            }
        }
        return outPairs
    }

    // ── Surface ────────────────────────────────────────────────────────────

    override fun surfaceCreated(holder: SurfaceHolder)                          { surfaceHolder = holder }
    override fun surfaceDestroyed(holder: SurfaceHolder)                        { stopGameLoop(); surfaceHolder = null }
    override fun surfaceChanged(holder: SurfaceHolder, fmt: Int, w: Int, h: Int) {
        surfaceHolder = holder
        buildControlLayout(w.toFloat(), h.toFloat())   // also calls updateGameMatrix() internally now
        if (romLoaded && !running) startGameLoop()
        // BUG FIX: this fires on every resize — a user-triggered orientation
        // change (see applyScreenOrientationPref()), entering/exiting
        // split-screen, etc. A SurfaceView's buffer doesn't repaint itself
        // just because it changed size — whatever pixels were already in it
        // stay there, stretched/cropped to the new dimensions, until
        // something actually draws again. Without this, that could briefly
        // be a stretched copy of the last black-cleared frame (harmless) or,
        // in some resize orderings, genuinely undefined content — either
        // way, repainting black immediately at the new size is cheap and
        // removes any doubt.
        else clearSurfaceToBlack()
    }

    // ── Game loop ──────────────────────────────────────────────────────────

    private fun startGameLoop() {
        if (running) return
        val bufs = frameBuffers ?: return
        val holder = surfaceHolder ?: return
        val sw = holder.surfaceFrame.width().toFloat()
        val sh = holder.surfaceFrame.height().toFloat()
        if (sw > 0f && sh > 0f) buildControlLayout(sw, sh)   // also calls updateGameMatrix() internally now
        try { audioTrack?.play() } catch (_: Exception) {}
        running = true
        ffFrameAccumulator = 0.0
        consecutiveFrameSkips = 0
        lastFrameLoopStartNs = 0L
        fpsFrameCount = 0
        fpsWindowStartNs = 0L
        startRenderLoop()
        gameThread = Thread {
            while (running) {
                try {
                    val t0 = System.nanoTime()
                    // FEATURE: maybeSkipRenderThisFrame's "are we behind"
                    // signal — gap since the *previous* iteration's own t0
                    // exceeding one frame's budget means that iteration
                    // (blit + emulation + the writePcm() block) took longer
                    // than a frame should, so this one skips the blit if
                    // there's still skip budget left. lastFrameLoopStartNs
                    // updates every iteration regardless of fast-forward
                    // state, but the skip decision itself only ever applies
                    // to the framesToRun == 1 branch below — fast-forward
                    // already has its own, unrelated skip-blit logic for
                    // every sub-frame but the batch's last.
                    val behindSchedule = lastFrameLoopStartNs != 0L && (t0 - lastFrameLoopStartNs) > frameBudgetNs
                    lastFrameLoopStartNs = t0
                    val speed = if (fastForwardActive) fastForwardSpeed else 1f

                    val framesToRun: Int
                    if (fastForwardActive) {
                        ffFrameAccumulator += speed
                        framesToRun = ffFrameAccumulator.toInt().coerceAtLeast(1)
                        ffFrameAccumulator -= framesToRun
                    } else {
                        framesToRun = 1
                        ffFrameAccumulator = 0.0
                    }

                    EmulatorEngine.nativeSetKeys(effectiveKeysForCore())
                    var wroteAudio = false
                    // FIX (this pass): reported as flickering / flashing white
                    // screen once Max frame skips was actually turned on.
                    // Root cause: a skipped frame was still going through the
                    // *publish* step below unconditionally — readyIdx claimed
                    // whatever buffer writeIdx pointed at even though
                    // nativeRunFrame(null) never wrote a single pixel into it
                    // this iteration. Early on, or after several skips in a
                    // row, that buffer can be one none of the 3 have ever
                    // actually been rendered into yet — publishing it hands
                    // the Choreographer renderer genuinely uninitialized
                    // bitmap contents to draw, which is exactly a "flash of
                    // garbage" (often reading as white). Fast-forward's own
                    // sub-frame skipping never had this problem — every
                    // batch's *last* sub-frame still always writes real
                    // pixels into backBmp before the one publish at the end —
                    // only this pass's new normal-speed skip path shared the
                    // unconditional publish without sharing that guarantee.
                    // Fixed by moving the publish inside the "a real render
                    // actually happened" branch: a skipped frame now claims
                    // no buffer and changes nothing about readyIdx/displayIdx
                    // at all, so the renderer just keeps showing whatever it
                    // was already showing — the correct, safe meaning of
                    // "skip this frame's visual update."
                    val skipBlit = framesToRun == 1 && maxFrameSkips > 0 &&
                        behindSchedule && consecutiveFrameSkips < maxFrameSkips
                    if (skipBlit) {
                        EmulatorEngine.nativeRunFrame(null)
                        consecutiveFrameSkips++
                        val n = EmulatorEngine.nativeReadAudioSamples(audioBuffer, audioBuffer.size / 2)
                        if (n > 0) { writePcm(n); wroteAudio = true }   // blocking — this *is* the frame pacer now
                    } else {
                        consecutiveFrameSkips = 0
                        // Sub-frames of a fast-forward batch all render into
                        // the same back buffer — only the last one ends up on
                        // screen, same as before; only the publish step below
                        // is new.
                        val backBmp = bufs[writeIdx]
                        if (framesToRun == 1) {
                            EmulatorEngine.nativeRunFrame(backBmp)
                            val n = EmulatorEngine.nativeReadAudioSamples(audioBuffer, audioBuffer.size / 2)
                            if (n > 0) { writePcm(n); wroteAudio = true }   // blocking — this *is* the frame pacer now
                        } else {
                            // Fast-forward batch: run every sub-frame, collecting
                            // each one's audio into ffAccumBuffer instead of
                            // discarding it, then compress the whole batch down
                            // to about one frame's worth (decimateForFastForward)
                            // so it can go through the same blocking writePcm()
                            // pacer below — see the audio-architecture note above.
                            var accumPairs = 0
                            for (i in 0 until framesToRun) {
                                // PERF: only the LAST sub-frame in the batch is
                                // ever displayed (see the buffer-publish step
                                // below), so earlier ones pass null and skip the
                                // pixel-copy blit entirely — see FIX 5 in
                                // mgba_jni.c. Emulation and audio still run in
                                // full for every sub-frame.
                                val bmpForThisSubFrame = if (i == framesToRun - 1) backBmp else null
                                EmulatorEngine.nativeRunFrame(bmpForThisSubFrame)
                                val n = EmulatorEngine.nativeReadAudioSamples(audioBuffer, audioBuffer.size / 2)
                                if (n > 0 && accumPairs + n <= ffAccumBuffer.size / 2) {
                                    System.arraycopy(audioBuffer, 0, ffAccumBuffer, accumPairs * 2, n * 2)
                                    accumPairs += n
                                }
                            }
                            if (accumPairs > 0) {
                                val outPairs = decimateForFastForward(accumPairs, framesToRun)
                                if (outPairs > 0) { writePcm(outPairs); wroteAudio = true }
                            }
                        }

                        // Publish the completed frame for the Choreographer
                        // renderer (see the field comments above) and claim
                        // whichever of the 3 buffers is free for next time —
                        // never the one just published or the one the renderer
                        // may currently be drawing. Only ever reached here, on
                        // the branch that actually wrote real pixels into
                        // backBmp — see the FIX note above.
                        synchronized(bufferLock) {
                            readyIdx = writeIdx
                            writeIdx = (0..2).first { it != readyIdx && it != displayIdx }
                        }
                    }

                    if (showFpsOverlay) {
                        // FEATURE: performance overlay — counts every emulated
                        // GBA frame, so a 4x fast-forward batch counts as 4,
                        // matching the "core FPS" figure emulators
                        // conventionally show. Gated behind the toggle so
                        // there is no counting work at all on this thread —
                        // the one pacing audio — when the overlay is off.
                        if (fpsWindowStartNs == 0L) fpsWindowStartNs = t0
                        fpsFrameCount += framesToRun
                        val windowNs = t0 - fpsWindowStartNs
                        if (windowNs >= 1_000_000_000L) {
                            val fps = fpsFrameCount * 1_000_000_000.0 / windowNs
                            val underruns = try { audioTrack?.underrunCount ?: 0 } catch (_: Exception) { 0 }
                            fpsOverlayText = "%.1f fps  ·  %d underruns".format(fps, underruns)
                            fpsFrameCount = 0
                            fpsWindowStartNs = t0
                        }
                    }

                    if (!wroteAudio) {
                        // Fallback pacer for the rare batch that produced no audio
                        // (e.g. immediately after a ROM loads, before blip_buf has
                        // accumulated a full sample, or if this device has no usable
                        // AudioTrack at all). Uses the real GBA frame period, scaled
                        // down by `speed` during FF so this edge case doesn't stall
                        // fast-forward back to real-time.
                        val elapsed = System.nanoTime() - t0
                        val fallbackNs = (FALLBACK_FRAME_NS / speed).toLong()
                        val sleepMs = (fallbackNs - elapsed) / 1_000_000L
                        if (sleepMs > 0L) Thread.sleep(sleepMs)
                    }
                    // Normal case: writePcm() above already blocked until the
                    // audio HAL had room for this batch's samples, which paces
                    // the loop against the real device audio clock — no
                    // Thread.sleep() needed and no drift accumulates, whether
                    // this iteration ran one GBA frame or a fast-forward batch
                    // of them. Rendering is no longer on this thread at all, so
                    // a slow frame draw can no longer delay the next audio write.
                } catch (_: InterruptedException) { break }
                catch (e: Throwable) { Log.e(TAG, "Loop error", e); uiToast("Error: ${e.message}"); break }
            }
            running = false
        }.also { it.name = "mGBA-loop"; it.start() }
    }

    private fun stopGameLoop() {
        running = false
        // 750ms rather than 500ms: the game thread may be inside a blocking
        // AudioTrack.write() call (see writePcm()). Android unblocks a
        // pending write when the track's play state changes from another
        // thread, so this should return almost immediately in practice —
        // the extra margin only matters on a slow/unusual audio HAL.
        gameThread?.join(750)
        gameThread = null
        stopRenderLoop()
    }

    private fun renderFrame(bmp: Bitmap) {
        val holder = surfaceHolder ?: return
        // PERF: lockHardwareCanvas() (API 23+, always available at our
        // minSdk 24) hands back a GPU-composited canvas instead of the plain
        // software Skia canvas lockCanvas() gives — the scaled drawBitmap()
        // plus the dozen-odd drawRoundRect/drawText calls for the on-screen
        // controls get composited on the GPU instead of the CPU every frame.
        // Falls back to a software canvas automatically on devices/drivers
        // that don't support it, so this is a strict upside with no
        // compatibility risk. Every draw call below (drawColor, drawBitmap
        // with a Matrix, drawRoundRect, drawText, drawCircle) is a basic op
        // fully supported under hardware acceleration — nothing here relies
        // on a software-only Xfermode/PathEffect/Shader.
        val canvas: Canvas = try { holder.lockHardwareCanvas() ?: return } catch (_: Exception) { return }
        try {
            canvas.drawColor(Color.BLACK)
            canvas.drawBitmap(bmp, gameMatrix, gamePaint)
            drawControls(canvas)
            if (editModeActive) drawEditOverlay(canvas)
            if (link.isConnected) drawLinkStatus(canvas)
            if (fastForwardActive) drawFfOverlay(canvas)
            if (showFpsOverlay) drawFpsOverlay(canvas)
        } finally { try { holder.unlockCanvasAndPost(canvas) } catch (_: Exception) {} }
    }

    /** Paints one solid black frame straight onto the SurfaceView, bypassing
     *  the triple-buffered game frames entirely. A SurfaceView keeps showing
     *  whatever it last drew until something draws over it again — so
     *  without this, closing a game (closeGame()) left its last emulated
     *  frame sitting on screen (behind/around whatever comes up next) until
     *  a new ROM loaded and rendered its own first frame. Safe to call
     *  right after stopGameLoop(): that join()s the game thread and flips
     *  the @Volatile renderLoopActive flag synchronously before returning,
     *  and renderFrame() is only ever reached through that flag (see
     *  renderCallback.doFrame), so nothing can race this with another draw.
     *
     *  BUG FIX (real crash, confirmed via two matching device crash logs —
     *  see BUGS_FIXED.md): this used to call the plain software
     *  holder.lockCanvas() instead of lockHardwareCanvas(). Two different
     *  APIs backed by two different rendering paths on the SAME
     *  SurfaceHolder — renderFrame() below has always used the hardware one
     *  (see its own PERF comment) — and switching a Surface between a
     *  software Skia canvas and a hardware GL/Skia-on-GL canvas across
     *  calls is a known way to leave the EGL/GL surface binding in a broken
     *  state on some devices/drivers. That matches the reported crash
     *  precisely: SIGABRT on Android's own RenderThread, "drawRenderNode
     *  called on a context with no surface!", every time, right after a ROM
     *  finishes loading — exactly the point where this function (called
     *  from surfaceChanged()/closeGame() while browsing ROMs) hands off to
     *  renderFrame()'s hardware-locked rendering for the first time in the
     *  session. Now locks the same way renderFrame() does, so this
     *  SurfaceHolder is never touched through two different rendering
     *  backends. No manual fallback to the software lock if this returns
     *  null — matching renderFrame()'s own handling (see its comment): on a
     *  device where hardware locking genuinely isn't available, skipping
     *  one black-clear is harmless, where falling back to software would
     *  reintroduce the exact mismatch this fix removes. */
    private fun clearSurfaceToBlack() {
        val holder = surfaceHolder ?: return
        val canvas: Canvas = try { holder.lockHardwareCanvas() ?: return } catch (_: Exception) { return }
        try { canvas.drawColor(Color.BLACK) } finally { try { holder.unlockCanvasAndPost(canvas) } catch (_: Exception) {} }
    }

    // ── Game matrix ────────────────────────────────────────────────────────

    /** FEATURE (this pass): when [stretchToFit] is on, width and height
     *  scale independently to fill the whole game area exactly — no
     *  letterbox/pillarbox margin left over, at the cost of distorting the
     *  GBA's native 3:2 image (circles become ovals, etc.), same tradeoff
     *  "stretch to fit" means in the reference this was matched against.
     *  Off (the default) keeps the existing aspect-ratio-preserving fit —
     *  see minOf() below — which is also what leaves the pillarbox margin
     *  discussed in KNOWN_LIMITATIONS.md's cutout-area entry; this toggle
     *  is the actual, real way to get rid of that margin, for anyone who'd
     *  rather have a distorted full-bleed image than any black space.
     *
     *  FEATURE (this pass): the game area itself is no longer just "full
     *  width, gameScreenFraction of the height, anchored top-left" — it's
     *  resolvedRect("gamescreen", ...), the same customLayout-backed
     *  resolution every button already goes through, so it can be dragged
     *  and resized like one (see the gameScreenRect field comment).
     *  gameScreenFraction * sh is still the *default* height (used to seed
     *  defaultGeometry the first time, and to fall back to if the entry's
     *  never been customized), just no longer the only possible one. */
    private fun updateGameMatrix(sw: Float, sh: Float) {
        val bmp = frameBuffers?.get(0) ?: return
        val defaultH = sh * gameScreenFraction
        gameScreenRect = resolvedRect("gamescreen", sw / 2f, defaultH / 2f, sw, defaultH)
        val areaW = gameScreenRect.width()
        val areaH = gameScreenRect.height()
        gameMatrix.reset()
        if (stretchToFit) {
            gameMatrix.postScale(areaW / bmp.width, areaH / bmp.height)
            gameMatrix.postTranslate(gameScreenRect.left, gameScreenRect.top)
        } else {
            val scale = minOf(areaW / bmp.width, areaH / bmp.height)
            gameMatrix.postScale(scale, scale)
            gameMatrix.postTranslate(
                gameScreenRect.left + (areaW - bmp.width  * scale) / 2f,
                gameScreenRect.top  + (areaH - bmp.height * scale) / 2f
            )
        }
    }

    // ── Controls layout ────────────────────────────────────────────────────

    /**
     * Builds the on-screen button rects.
     * buttonScaleMultiplier (0.75 / 1.0 / 1.25) scales all button sizes.
     * gameScreenFraction controls where the controls strip begins — the
     * game screen's own actual rendered size can now be independently
     * dragged/resized past this (see gameScreenRect/updateGameMatrix()),
     * but this is still what determines where controls sit.
     */
    // ── Layout persistence ───────────────────────────────────────────────────

    private fun orientationTag(): String =
        if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) "land" else "port"

    private fun loadCustomLayout() {
        customLayout.clear()
        removedButtons.clear()
        addedExtraButtons.clear()
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val raw = prefs.getString(PREF_LAYOUT_PREFIX + orientationTag(), null)
        if (raw != null) {
            try {
                val arr = JSONArray(raw)
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    customLayout[o.getString("id")] = LayoutEntry(
                        xFrac = o.getDouble("x").toFloat(),
                        yFrac = o.getDouble("y").toFloat(),
                        scale = o.optDouble("scale", 1.0).toFloat(),
                        alphaOverride = o.optInt("alpha", -1),
                        locked = o.optBoolean("locked", false)
                    )
                }
            } catch (e: Exception) {
                Log.e(TAG, "Corrupt saved layout, ignoring", e)
            }
        }
        // ADD/REMOVE CONTROL — see the removedButtons field comment.
        val rawRemoved = prefs.getString(PREF_REMOVED_PREFIX + orientationTag(), null)
        if (rawRemoved != null) {
            try {
                val arr = JSONArray(rawRemoved)
                for (i in 0 until arr.length()) removedButtons.add(arr.getString(i))
            } catch (e: Exception) {
                Log.e(TAG, "Corrupt removed-controls list, ignoring", e)
            }
        }
        // Extra (opt-in) controls — see the addedExtraButtons field comment.
        val rawExtras = prefs.getString(PREF_EXTRAS_PREFIX + orientationTag(), null)
        if (rawExtras != null) {
            try {
                val arr = JSONArray(rawExtras)
                for (i in 0 until arr.length()) addedExtraButtons.add(arr.getString(i))
            } catch (e: Exception) {
                Log.e(TAG, "Corrupt extra-controls list, ignoring", e)
            }
        }
    }

    private fun saveCustomLayout() {
        try {
            val arr = JSONArray()
            for ((id, e) in customLayout) {
                arr.put(JSONObject().apply {
                    put("id", id); put("x", e.xFrac.toDouble()); put("y", e.yFrac.toDouble())
                    put("scale", e.scale.toDouble()); put("alpha", e.alphaOverride); put("locked", e.locked)
                })
            }
            val removedArr = JSONArray().apply { removedButtons.forEach { put(it) } }
            val extrasArr = JSONArray().apply { addedExtraButtons.forEach { put(it) } }
            getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString(PREF_LAYOUT_PREFIX + orientationTag(), arr.toString())
                .putString(PREF_REMOVED_PREFIX + orientationTag(), removedArr.toString())
                .putString(PREF_EXTRAS_PREFIX + orientationTag(), extrasArr.toString())
                .apply()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to save layout", e)
            uiToast("Couldn't save layout")
        }
        editDirty = false
    }

    /** Computes the on-screen rect for [id] given its DEFAULT center/size,
     *  applying any saved/in-progress override. Always records the default
     *  geometry so "reset this button" and a brand-new drag both have a
     *  known baseline to work from, even if a saved override already exists. */
    private fun resolvedRect(id: String, cx: Float, cy: Float, w: Float, h: Float): RectF {
        defaultGeometry[id] = Geometry(cx, cy, w, h)
        val ov = customLayout[id]
        val fcx = if (ov != null) ov.xFrac * lastSw else cx
        val fcy = if (ov != null) ov.yFrac * lastSh else cy
        val scale = ov?.scale ?: 1f
        val fw = (w * scale).coerceAtLeast(1f)
        val fh = (h * scale).coerceAtLeast(1f)
        return RectF(fcx - fw / 2f, fcy - fh / 2f, fcx + fw / 2f, fcy + fh / 2f)
    }

    // Scratch list buildControlLayout() appends into via addButton(); only
    // ever touched from the UI thread, then published atomically to
    // `buttons` in one assignment at the end of buildControlLayout().
    private var buildingButtons = mutableListOf<ButtonDef>()

    private fun addButton(id: String, cx: Float, cy: Float, w: Float, h: Float, mask: Int, label: String, color: Int, isDpad: Boolean = false) {
        // Always resolve — and so record defaultGeometry — even if [id] is
        // currently hidden, so "+ Add control" (showAddControlMenu) has a
        // sane default position/size to bring it back at rather than
        // whatever stale geometry happened to be lying around.
        val rect = resolvedRect(id, cx, cy, w, h)
        if (!isButtonVisible(id)) return   // ADD/REMOVE CONTROL — hidden, skip drawing/hit-testing
        buildingButtons += ButtonDef(id, rect, mask, label, color, isDpad)
    }

    // ── Control layout (positions/sizes) ────────────────────────────────────
    //
    // CONTROL EDITOR (feature #2): every button below is now addressable by a
    // stable id and routed through resolvedRect()/addButton(), which checks
    // customLayout for a saved override before falling back to the default
    // formula. The formulas themselves are UNCHANGED from the original
    // design — they're still exactly what you get on a fresh install or
    // after "Reset all" — only the indirection through an override is new.
    private fun buildControlLayout(sw: Float, sh: Float) {
        buildingButtons = mutableListOf()
        lastSw = sw; lastSh = sh
        controlsTop = sh * gameScreenFraction
        val padH = sh - controlsTop

        // Apply scale multiplier to all button sizes
        val s      = buttonScaleMultiplier
        val btnSz  = minOf(padH * 0.24f, sw * 0.084f) * s
        val abSz   = btnSz * 0.94f
        outlineStrokeW = (minOf(sw, sh) * 0.006f).coerceIn(3f, 7f)

        // ── D-pad (left side) ────────────────────────────────────────────
        // FEATURE: unified into ONE control (id "dpad") instead of four
        // separate up/down/left/right hitboxes. Two problems that fixes:
        //  1. Editor UX — previously you had to drag/resize 4 buttons
        //     individually to reshape the d-pad, easy to knock out of
        //     alignment. Now it's one object, exactly like My Boy!'s pad.
        //  2. Diagonals — the old 4 separate rects had gaps between them
        //     (arranged in a cross with `step` spacing), so touching between
        //     e.g. up and right hit NEITHER hitbox — diagonal input was
        //     physically impossible. The unified pad hit-tests by angle
        //     (see dpadKeysFor()) so diagonals work like a real d-pad.
        val dpCx = sw * 0.18f
        val dpCy = controlsTop + padH * 0.52f
        val dpadSize = btnSz * 3.0f
        addButton("dpad", dpCx, dpCy, dpadSize, dpadSize, 0, "", colorAccentLight, isDpad = true)

        // ── A / B (right side) ────────────────────────────────────────────
        // OUTLINE SKIN: back to the same light/neutral accent as every other
        // button. The red outline read as a "turbo/rapid-fire" A/B variant
        // (that's the usual convention in emulator skins) rather than the
        // normal buttons, so A/B now match D-pad / L / R / Select / Start.
        val abCx  = sw * 0.82f
        val abCy  = controlsTop + padH * 0.52f
        val abGap = abSz * 1.2f
        addButton("a", abCx+abGap, abCy, abSz, abSz, EmulatorEngine.KEY_A, "A", colorAccentLight)
        addButton("b", abCx-abGap, abCy, abSz, abSz, EmulatorEngine.KEY_B, "B", colorAccentLight)

        // ── Turbo A / Turbo B (small red satellites, optional) ─────────────
        // FEATURE (this pass): moved from a single all-or-nothing Settings
        // checkbox (added both together, no way to get just one or to
        // reposition them independently) to the same opt-in-per-button
        // system as every other extra control — see extraControlIds above.
        // No "if" here any more: addButton() already checks
        // isButtonVisible() internally and only actually adds anything
        // tappable when the id's been added via "+ Add control", same as
        // "abturbo"/"ab"/etc. just above and below this block — these two
        // just weren't following that same pattern until now.
        //
        // Label changed from "T" to "A"/"B": "T" was identical on both
        // buttons, so there was no way to tell Turbo A from Turbo B by
        // looking at them — matches "abturbo"'s own convention instead
        // (reuses the equivalent normal button's letter, red color is what
        // signals "this one's the turbo version").
        //
        // keyMask is 0 here on purpose — they must NOT get OR'd straight
        // into currentKeys like a normal button (that'd just be a
        // continuous hold, not rapid-fire). Their held state is tracked
        // separately (turboAHeld/turboBHeld, set in updateGameKeys()) and
        // turned into an actual on/off square wave only at the point it's
        // sent to the core — see nativeSetKeys() call in startGameLoop().
        val tSz = abSz * 0.75f
        val tOffX = abSz * 0.75f
        val tOffY = abSz * 0.95f
        addButton("ta", abCx+abGap+tOffX, abCy-tOffY, tSz, tSz, 0, "A", colorAccentRed)
        addButton("tb", abCx-abGap-tOffX, abCy-tOffY, tSz, tSz, 0, "B", colorAccentRed)

        // ── Select / Start (centre) ───────────────────────────────────────
        // Shortened from the old 0.11×/0.038× (≈6.4:1 — a long thin bar)
        // down to a squatter ≈3:1 pill.
        val ssW  = sw * 0.072f * s;  val ssH  = sh * 0.052f * s
        val ssCy = controlsTop + padH * 0.82f + ssH / 2f
        val ssGap = sw * 0.07f
        addButton("select", sw/2f-ssGap-ssW/2f, ssCy, ssW, ssH, EmulatorEngine.KEY_SELECT, "SEL", colorAccentLight)
        addButton("start",  sw/2f+ssGap+ssW/2f, ssCy, ssW, ssH, EmulatorEngine.KEY_START,  "STA", colorAccentLight)

        // ── L / R shoulder buttons ─────────────────────────────────────────
        // Reshaped to match the reference skin: a squat ~2:1 trigger glyph
        // (flat hinge edge + one big rounded sweep — see shoulderButtonPath())
        // instead of the old 0.13×/0.042× (~6.9:1) long thin bar.
        val lrW = sw * 0.07f  * s;  val lrH = sh * 0.075f * s
        val lrY = controlsTop + padH * 0.06f + lrH / 2f
        val lrCxL = sw*0.03f+lrW/2f
        val lrCxR = sw-sw*0.03f-lrW/2f
        addButton("l", lrCxL, lrY, lrW, lrH, EmulatorEngine.KEY_L, "L", colorAccentLight)
        addButton("r", lrCxR, lrY, lrW, lrH, EmulatorEngine.KEY_R, "R", colorAccentLight)

        // ── ⏩ Fast-forward — docked directly under R (matching the
        // reference layout) instead of floating above SEL/STA. Roughly
        // square, sized off R's own height, with about one R-height of gap
        // between them.
        // Not pushed into `buttons` (it isn't a GBA key — see onGameTouch),
        // but still routed through resolvedRect() so it's just as draggable
        // and resizable in the editor as every other button.
        val utilSize = lrH
        val utilY = lrY + lrH/2f + lrH + utilSize/2f
        val ffRect = resolvedRect("ff", lrCxR, utilY, utilSize, utilSize)
        // ADD/REMOVE CONTROL: an empty RectF.contains() is always false for
        // any point, so this alone is enough to make a hidden ff both
        // undrawable and untappable — see drawControls()/onGameTouch().
        ffBtnRect = if (isButtonVisible("ff")) ffRect else RectF()
        // NOTE: fsBtnRect REMOVED — fullscreen is now in ⚙ Settings only

        // ── Extra controls (opt-in via "+ Add control") ────────────────────
        // FEATURE: new — the shoulder+face combos (TL+A/TL+B/TR+A/TR+B),
        // the A/B combos (plain + turbo), and three one-tap actions (quick
        // save/load, screenshot), matching the reference app's own "Add
        // control" catalog. Hidden until explicitly added (extraControlIds/
        // addedExtraButtons/isButtonVisible) — every one of these is a
        // completely ordinary addButton() entry once visible, so it's just
        // as draggable/resizable/lockable/removable as any base button with
        // no extra plumbing. This default spot (a small two-row cluster
        // between the shoulder buttons and the D-pad/A-B row — clear of
        // both at every screen size this app targets) only has to be a
        // reasonable starting point, since where it ends up is entirely up
        // to whoever adds it.
        val exSz    = btnSz * 0.56f
        val exGapX  = exSz * 1.35f
        val exRow1Y = controlsTop + padH * 0.27f
        val exRow2Y = controlsTop + padH * 0.42f
        val exRow1X0 = sw * 0.5f - exGapX * 2f
        addButton("la", exRow1X0,             exRow1Y, exSz, exSz, EmulatorEngine.KEY_L or EmulatorEngine.KEY_A, "LA", colorAccentLight)
        addButton("lb", exRow1X0 + exGapX,    exRow1Y, exSz, exSz, EmulatorEngine.KEY_L or EmulatorEngine.KEY_B, "LB", colorAccentLight)
        addButton("ab", exRow1X0 + exGapX*2f, exRow1Y, exSz, exSz, EmulatorEngine.KEY_A or EmulatorEngine.KEY_B, "AB", colorAccentLight)
        addButton("ra", exRow1X0 + exGapX*3f, exRow1Y, exSz, exSz, EmulatorEngine.KEY_R or EmulatorEngine.KEY_A, "RA", colorAccentLight)
        addButton("rb", exRow1X0 + exGapX*4f, exRow1Y, exSz, exSz, EmulatorEngine.KEY_R or EmulatorEngine.KEY_B, "RB", colorAccentLight)
        val exRow2X0 = sw * 0.5f - exGapX * 1.5f
        // "abturbo" reuses the same red-for-turbo convention as ta/tb above
        // (see updateGameKeys()'s "abturbo" case for how it actually drives
        // both satellites' phase-square-wave at once).
        addButton("abturbo",    exRow2X0,             exRow2Y, exSz, exSz, 0, "AB", colorAccentRed)
        addButton("quicksave",  exRow2X0 + exGapX,    exRow2Y, exSz, exSz, 0, "💾", colorAccentLight)
        addButton("quickload",  exRow2X0 + exGapX*2f, exRow2Y, exSz, exSz, 0, "📂", colorAccentLight)
        addButton("screenshot", exRow2X0 + exGapX*3f, exRow2Y, exSz, exSz, 0, "📷", colorAccentLight)

        // Publish the whole list in one atomic reference write — see the
        // `buttons` field comment for why this matters.
        buttons = buildingButtons

        // FEATURE: keeps gameScreenRect (and the actual rendered image —
        // updateGameMatrix() is what gameScreenRect ultimately drives) in
        // sync with every button-layout change, live drag/resize included,
        // rather than needing updateGameMatrix() threaded individually
        // through every one of buildControlLayout's own call sites. Safe
        // to call unconditionally — updateGameMatrix() already no-ops via
        // its own frameBuffers null check on any call site reached before
        // a ROM is loaded.
        updateGameMatrix(sw, sh)

        if (editModeActive) refreshEditToolbarPosition()
    }

    // ── Draw controls ──────────────────────────────────────────────────────

    private val fillPaint   = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    // FEATURE: linearFilterEnabled (declared above with stretchToFit/
    // maxFrameSkips — see the FIX note there for why its declaration is
    // worth a second look) wired up here. Bilinear (isFilterBitmap = true)
    // softens the GBA's blocky upscaled pixels; nearest-neighbor (false,
    // the default, matching every previous pass's actual on-screen
    // behavior since this used to always be a plain `null` Paint, which
    // the Canvas API treats as filtering off) keeps them crisp. One
    // shared, mutable Paint instead of a fresh one per frame —
    // updateLinearFilterPaint() below flips isFilterBitmap on the same
    // instance whenever the setting changes, rather than needing a new
    // object either way.
    private val gamePaint = Paint().apply { isFilterBitmap = false }
    private fun updateLinearFilterPaint() { gamePaint.isFilterBitmap = linearFilterEnabled }
    private val labelPaint  = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textAlign = Paint.Align.CENTER
    }

    // PERF FIX: these were previously Color.parseColor("#...") calls made
    // INSIDE drawControls()/drawDpad() — i.e. re-parsed from a hex string on
    // every single rendered frame (the d-pad alone re-parsed the same string
    // 4×/frame). That's pure wasted CPU sitting on the exact thread that
    // also paces audio playback (see startGameLoop()) — any extra time spent
    // here delays the next AudioTrack.write(), which is what an underrun
    // "click" actually is. Precomputing these once is a zero-risk, visually
    // identical change (same values, same Color.parseColor, just evaluated
    // once instead of ~6-7×/frame).
    private val colorControlsBg = Color.parseColor("#CC111122")
    private val colorFfActive   = Color.parseColor("#CC7700")
    // OUTLINE SKIN: every control is now a stroked (line-art) shape instead
    // of a filled one, matching the requested reference skin — one shared
    // light/neutral accent for every button (D-pad / A / B / L / R /
    // Select / Start / FF-idle). The old solid colorFfIdle / colorDpadBase /
    // colorDpadArm fills are gone: there's no shared d-pad base plate any
    // more either — see drawDpad(), each arm is its own outlined button.
    // (colorAccentLight itself moved to SharedUi.kt this pass — RomBrowserActivity needs it too.)
    // Used only by the optional Turbo A/B satellites — red reads as
    // "rapid-fire" (the usual emulator-skin convention), which is exactly
    // right here since that's what they are, unlike the normal A/B.
    private val colorAccentRed   = Color.parseColor("#E5484D")

    private fun drawControls(canvas: Canvas) {
        // ADD/REMOVE CONTROL: `buttons` can now legitimately be empty (every
        // normal button removed) while ff is still shown, or vice versa —
        // used to be a flat "buttons.isEmpty() => bail entirely", which was
        // fine back when buttons was only empty before the very first
        // buildControlLayout() call. Now it'd also silently hide a still-
        // present ff button any time every OTHER control was removed. Bail
        // only when there is truly nothing to draw.
        val ffVisible = ffBtnRect.width() > 0f
        if (buttons.isEmpty() && !ffVisible) return

        fillPaint.color = colorControlsBg
        canvas.drawRect(0f, controlsTop, canvas.width.toFloat(), canvas.height.toFloat(), fillPaint)

        val keys       = currentKeys.get()
        // Idle alpha scales with user preference; press brightens by +80.
        // Per-button opacity overrides from the editor take priority — see
        // the loop below.
        val idleAlpha  = buttonBaseAlpha

        for (btn in buttons) {
            val ov = customLayout[btn.id]?.alphaOverride ?: -1
            val btnIdle = if (ov >= 0) ov else idleAlpha
            if (btn.isDpad) {
                drawDpad(canvas, btn.rect, keys, btnIdle)
                continue
            }
            val pressed = when (btn.id) {
                "ta" -> turboAHeld
                "tb" -> turboBHeld
                "abturbo" -> turboAHeld && turboBHeld
                // BUG FIX: was `keys and btn.keyMask != 0` — correct for a
                // single-bit mask, but for the new combo buttons (e.g. "la"
                // = KEY_L|KEY_A) that lit up as soon as EITHER key was down
                // from any source, not just when this specific combo's own
                // full press was active. Requiring every bit fixes that and
                // is equivalent to the old check for every single-bit button.
                else -> btn.keyMask != 0 && keys and btn.keyMask == btn.keyMask
            }
            drawOutlineButton(canvas, btn.rect, btn.id, btn.label, btn.color, btnIdle, pressed)
        }

        // ── » Fast-forward button ────────────────────────────────────────
        if (!ffVisible) return
        val ffPressed = fastForwardActive
        val ffAlpha = (idleAlpha + 20).coerceAtMost(255)
        strokePaint.color = if (ffPressed) colorFfActive else colorAccentLight
        strokePaint.alpha = ffAlpha
        strokePaint.strokeWidth = outlineStrokeW
        if (ffPressed) {
            fillPaint.color = colorFfActive
            fillPaint.alpha = (ffAlpha * 0.35f).toInt().coerceIn(0, 255)
            canvas.drawRoundRect(ffBtnRect, 8f, 8f, fillPaint)
        }
        canvas.drawRoundRect(ffBtnRect, 8f, 8f, strokePaint)
        labelPaint.textSize = (ffBtnRect.height() * 0.52f).coerceAtLeast(12f)
        // FIX (this pass): used to show "» 4×" (the active speed) while
        // toggled on — reported as an indicator that shouldn't be there at
        // all. The color/fill change above (colorFfActive, the translucent
        // fill) already shows on/off state on its own; just "»" either way
        // now, no text distinguishing the two beyond that.
        canvas.drawText("»",
            ffBtnRect.centerX(), ffBtnRect.centerY() + labelPaint.textSize * 0.36f, labelPaint)
        // NOTE: ⛶ fullscreen button no longer drawn here — it lives in ⚙ Settings
    }

    /** Builds the L/R shoulder-trigger glyph: a flat hinge edge (left edge
     *  for L, right edge for R) with small rounded corners, a flat top edge,
     *  a short flat bottom segment on the hinge side, and one big smooth
     *  sweep on the outer side connecting the top corner down to where that
     *  bottom segment starts — the classic controller-bumper silhouette from
     *  the reference skin, instead of a plain pill. `mirrored = true` flips
     *  it for R. */
    private fun shoulderButtonPath(rect: RectF, mirrored: Boolean): Path {
        val w = rect.width(); val h = rect.height()
        val c = h * 0.22f              // small round on the two hinge-side corners
        val bottomRun = w * 0.30f      // length of the short flat bottom segment
        val path = Path()
        val left = rect.left; val top = rect.top; val right = rect.right; val bottom = rect.bottom
        if (!mirrored) {
            // L: hinge (flat) edge on the LEFT, big sweep on the RIGHT.
            path.moveTo(left, top + c)
            path.quadTo(left, top, left + c, top)
            path.lineTo(right, top)
            path.cubicTo(
                right + w * 0.02f, top + h * 0.35f,
                right - w * 0.04f, bottom - h * 0.10f,
                left + bottomRun, bottom
            )
            path.lineTo(left + c, bottom)
            path.quadTo(left, bottom, left, bottom - c)
            path.close()
        } else {
            // R: mirror of the above — hinge (flat) edge on the RIGHT.
            path.moveTo(right, top + c)
            path.quadTo(right, top, right - c, top)
            path.lineTo(left, top)
            path.cubicTo(
                left - w * 0.02f, top + h * 0.35f,
                left + w * 0.04f, bottom - h * 0.10f,
                right - bottomRun, bottom
            )
            path.lineTo(right - c, bottom)
            path.quadTo(right, bottom, right, bottom - c)
            path.close()
        }
        return path
    }

    /** Draws one outlined control button — a stroked circle for A/B (and the
     *  optional Turbo A/B satellites), a stroked shoulder-trigger glyph for
     *  L/R, a stroked pill (fully-rounded rect) for Select/Start, and a
     *  stroked rounded rect as a fallback for anything else. This is the
     *  line-art skin: no solid fill at rest, just a stroke — a soft matching
     *  fill fades in underneath only while the button is actually held, as
     *  the sole "pressed" cue. */
    private fun drawOutlineButton(
        canvas: Canvas, rect: RectF, id: String, label: String,
        accent: Int, idleAlpha: Int, pressed: Boolean
    ) {
        val alpha = if (pressed) (idleAlpha + 80).coerceAtMost(255) else idleAlpha
        strokePaint.color = accent
        strokePaint.alpha = alpha
        strokePaint.strokeWidth = outlineStrokeW
        if (pressed) {
            fillPaint.color = accent
            fillPaint.alpha = (alpha * 0.30f).toInt().coerceIn(0, 255)
        }
        var labelDx = 0f
        when (id) {
            "a", "b", "ta", "tb" -> {
                val cx = rect.centerX(); val cy = rect.centerY()
                val radius = minOf(rect.width(), rect.height()) / 2f - outlineStrokeW / 2f
                if (pressed) canvas.drawCircle(cx, cy, radius, fillPaint)
                canvas.drawCircle(cx, cy, radius, strokePaint)
            }
            "l", "r" -> {
                val p = shoulderButtonPath(rect, mirrored = id == "r")
                if (pressed) canvas.drawPath(p, fillPaint)
                canvas.drawPath(p, strokePaint)
                // Nudge the label into the "meat" of the glyph (the flat
                // hinge side), away from the tapering sweep.
                labelDx = if (id == "l") -rect.width() * 0.18f else rect.width() * 0.18f
            }
            "select", "start" -> {
                val r = rect.height() / 2f
                if (pressed) canvas.drawRoundRect(rect, r, r, fillPaint)
                canvas.drawRoundRect(rect, r, r, strokePaint)
            }
            else -> {
                if (pressed) canvas.drawRoundRect(rect, 12f, 12f, fillPaint)
                canvas.drawRoundRect(rect, 12f, 12f, strokePaint)
            }
        }
        if (label.isNotEmpty()) {
            labelPaint.textSize = (rect.height() * 0.42f).coerceAtLeast(13f)
            canvas.drawText(label, rect.centerX() + labelDx,
                rect.centerY() + labelPaint.textSize * 0.36f, labelPaint)
        }
    }

    /** Renders four independently-outlined direction buttons — no shared
     *  base plate — arranged in a loose cross, matching the reference skin
     *  where the D-pad reads as four separate line-art buttons rather than
     *  one filled plate. Hit-testing is UNCHANGED: dpadKeysFor() still
     *  resolves the whole unified [rect] by angle (see its own doc comment),
     *  so diagonals still work exactly as before even though visually
     *  you're now tapping between two shapes rather than on a solid arm. */
    private fun drawDpad(canvas: Canvas, rect: RectF, keys: Int, idleAlpha: Int) {
        val cx = rect.centerX(); val cy = rect.centerY()
        val r  = minOf(rect.width(), rect.height()) / 2f

        val armLen = r * 0.62f
        val armW   = r * 0.60f
        val corner = armW * 0.24f
        fun arm(dx: Float, dy: Float, pressed: Boolean, label: String) {
            val ax = cx + dx * armLen; val ay = cy + dy * armLen
            val armRect = RectF(ax - armW / 2f, ay - armW / 2f, ax + armW / 2f, ay + armW / 2f)
            val alpha = if (pressed) (idleAlpha + 80).coerceAtMost(255) else idleAlpha
            if (pressed) {
                fillPaint.color = colorAccentLight
                fillPaint.alpha = (alpha * 0.30f).toInt().coerceIn(0, 255)
                canvas.drawRoundRect(armRect, corner, corner, fillPaint)
            }
            strokePaint.color = colorAccentLight
            strokePaint.alpha = alpha
            strokePaint.strokeWidth = outlineStrokeW
            canvas.drawRoundRect(armRect, corner, corner, strokePaint)
            labelPaint.textSize = (armW * 0.44f).coerceAtLeast(12f)
            canvas.drawText(label, ax, ay + labelPaint.textSize * 0.36f, labelPaint)
        }
        arm(0f, -1f, keys and EmulatorEngine.KEY_UP    != 0, "▲")
        arm(0f,  1f, keys and EmulatorEngine.KEY_DOWN  != 0, "▼")
        arm(-1f, 0f, keys and EmulatorEngine.KEY_LEFT  != 0, "◀")
        arm(1f,  0f, keys and EmulatorEngine.KEY_RIGHT != 0, "▶")
    }

    /** Maps a touch point inside the unified d-pad rect to a GBA key-bit
     *  combination by angle from center, split into 8 x 45° sectors — the
     *  4 cardinal sectors give a single direction, the 4 sectors between
     *  them give the two adjacent bits (a genuine diagonal). A small
     *  circular dead-zone at the very center avoids accidental input from
     *  a light tap that lands near the middle. */
    private fun dpadKeysFor(rect: RectF, x: Float, y: Float): Int {
        val cx = rect.centerX(); val cy = rect.centerY()
        val halfW = (rect.width() / 2f).coerceAtLeast(1f)
        val halfH = (rect.height() / 2f).coerceAtLeast(1f)
        val dx = x - cx; val dy = y - cy
        val distNorm = maxOf(abs(dx) / halfW, abs(dy) / halfH)
        if (distNorm < 0.16f) return 0   // dead zone — no accidental direction from a center tap

        var deg = Math.toDegrees(kotlin.math.atan2(-dy.toDouble(), dx.toDouble()))
        if (deg < 0) deg += 360.0
        val U = EmulatorEngine.KEY_UP; val D = EmulatorEngine.KEY_DOWN
        val L = EmulatorEngine.KEY_LEFT; val R = EmulatorEngine.KEY_RIGHT
        return when {
            deg >= 337.5 || deg < 22.5  -> R
            deg < 67.5                  -> U or R
            deg < 112.5                 -> U
            deg < 157.5                 -> U or L
            deg < 202.5                 -> L
            deg < 247.5                 -> D or L
            deg < 292.5                 -> D
            else                         -> D or R
        }
    }

    private val hudPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FFCC00"); textSize = 28f; isFakeBoldText = true
    }
    private fun drawFfOverlay(canvas: Canvas) =
        canvas.drawText("⏩ ${formatSpeed(fastForwardSpeed)}×", 14f, 36f, hudPaint)

    private fun formatSpeed(s: Float): String =
        if (s == s.toLong().toFloat()) s.toLong().toString() else "%.1f".format(s)

    /** Hold-the-»-button speed picker — a slider (0.5–16×, half-speed
     *  steps, matching the existing text-field validation's own range —
     *  see the Fast-forward speed setting in Misc) plus a Done button,
     *  requested as a faster way to change speed than opening Settings
     *  every time. Setting the value here writes the exact same
     *  fastForwardSpeed field/PREF_FF_SPEED pref that setting's own text
     *  field does — either one changes what the other shows next time. */
    private fun showFastForwardSpeedSlider() {
        val ctx = this
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val layout = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(4), dp(24), dp(0))
        }
        val valueText = TextView(ctx).apply {
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        layout.addView(valueText)
        // SeekBar only deals in whole-number steps — 0..31 here maps to
        // 0.5..16.0 in steps of 0.5, matching the Misc speed field's own
        // 0.5–16 range exactly (see its "Speed must be 0.5 – 16" check).
        fun speedFor(progress: Int) = 0.5f + progress * 0.5f
        val seek = SeekBar(ctx).apply {
            max = 31
            progress = ((fastForwardSpeed - 0.5f) / 0.5f).toInt().coerceIn(0, 31)
        }
        valueText.text = "${formatSpeed(speedFor(seek.progress))}×"
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, value: Int, fromUser: Boolean) {
                valueText.text = "${formatSpeed(speedFor(value))}×"
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })
        layout.addView(seek)

        val dialog = AlertDialog.Builder(ctx)
            .setTitle("Fast-forward speed")
            .setView(layout)
            .setPositiveButton("Done") { _, _ ->
                val speed = speedFor(seek.progress)
                fastForwardSpeed = speed
                prefs.edit().putFloat(PREF_FF_SPEED, speed).apply()
            }
            .create()
        dialog.window?.setBackgroundDrawable(roundedDialogBackground())
        dialog.show()
    }

    // ── Touch handling ─────────────────────────────────────────────────────
    //
    // STICKY DRAG-OFF: once a finger is down on a control, it keeps
    // contributing that control's key(s) even after the finger drags
    // outside that control's own hit-box — right up until that specific
    // finger actually lifts (ACTION_UP / ACTION_POINTER_UP) or the gesture
    // is cancelled. Previously updateGameKeys() re-hit-tested every
    // pointer's CURRENT position on every single call with nothing carried
    // over, so straying off a button's rect by even a pixel — while still
    // pressing down — read as an immediate release. That doesn't match how
    // a physical button (or basically any touch gamepad) behaves.
    //
    // Tracked per pointer ID (not per button) so multiple fingers can each
    // independently hold their own button, and so a finger sliding from one
    // button straight onto a different one correctly switches instead of
    // both buttons lighting up.
    private val pointerKeys   = mutableMapOf<Int, Int>()  // pointerId -> GBA key bits that finger last hit
    private val pointerTurboA = mutableSetOf<Int>()       // pointerIds currently "holding" the Turbo-A satellite
    private val pointerTurboB = mutableSetOf<Int>()       // pointerIds currently "holding" the Turbo-B satellite

    private fun clearPointerState() {
        pointerKeys.clear(); pointerTurboA.clear(); pointerTurboB.clear()
    }

    // FIX (this pass): replaces the removed floating "Load ROM" button (see
    // the FIX comment in onCreate where it used to be built) as the way
    // back into ROM selection whenever nothing else is on screen — the
    // folder picker gets cancelled before any folder's ever been chosen, or
    // a ROM load fails (see loadRomFromUri's catch block). Gated on
    // !romLoaded specifically so this never fires mid-game: settingsMenuOverlay
    // sits on top of the surface while Settings are open and marks itself
    // isClickable = true precisely to swallow touches before they'd ever
    // reach here (the ROM browser doesn't need the same guard any more —
    // it's RomBrowserActivity, a separate Activity now, so MainActivity's
    // own surface simply isn't the foreground window, let alone touchable,
    // whenever it's showing). ACTION_UP (not ACTION_DOWN) so a
    // drag that started on the idle screen doesn't fire this.
    private fun onGameTouch(event: MotionEvent) {
        if (!romLoaded) {
            if (event.actionMasked == MotionEvent.ACTION_UP) changeRom()
            return
        }
        if (editModeActive) { onEditTouch(event); return }
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val x = event.x; val y = event.y
                // FEATURE (this pass): »/fast-forward no longer toggles the
                // instant it's touched — a hold now shows a speed slider
                // instead (see showFastForwardSpeedSlider()), so this has
                // to wait and see which one it turns out to be. Arms a
                // delayed Runnable exactly like the editor's own
                // hold-to-remove gesture (editLongPressPending above);
                // ACTION_UP below cancels it and toggles normally if it
                // gets there first (a real tap), otherwise the Runnable
                // itself fires, opens the slider, and there's nothing left
                // for ACTION_UP to do.
                if (ffBtnRect.contains(x, y)) {
                    val lp = Runnable {
                        ffLongPressPending = null
                        showFastForwardSpeedSlider()
                    }
                    ffLongPressPending = lp
                    mainHandler.postDelayed(lp, ViewConfiguration.getLongPressTimeout().toLong())
                    return
                }
                // NOTE: fullscreen ⛶ touch removed — use ⚙ Settings to toggle fullscreen
                // One-tap extra controls (quick save/load, screenshot) — see
                // actionButtonAt(). Same "only the first/primary finger, not
                // a second one landing mid-gesture" shape as the ff check
                // just above; fine, since these are meant as a deliberate
                // single tap, not something you'd chord with other buttons.
                actionButtonAt(x, y)?.let { id -> triggerActionButton(id); return }
                updateGameKeys(event)
            }
            MotionEvent.ACTION_POINTER_DOWN,
            MotionEvent.ACTION_MOVE -> updateGameKeys(event)
            MotionEvent.ACTION_UP -> {
                if (ffBtnRect.contains(event.x, event.y)) {
                    // Only a genuine tap if the long press never actually
                    // fired — if it already has, ffLongPressPending is
                    // already null and the slider is open; toggling fast-
                    // forward out from under it here would be wrong.
                    ffLongPressPending?.let { pending ->
                        mainHandler.removeCallbacks(pending)
                        ffLongPressPending = null
                        fastForwardActive = !fastForwardActive
                    }
                    return
                }
                clearPointerState()
                currentKeys.set(0)
                lastSoundKeys = 0
                turboAHeld = false; turboBHeld = false
            }
            MotionEvent.ACTION_POINTER_UP -> {
                // Evict just the lifting finger's sticky state — it's the
                // only one actually going away. The explicit remove() here
                // AND excludePointerIndex below are both needed: this same
                // MotionEvent still reports the lifting pointer at its last
                // coordinates (it's only dropped from the *next* event), so
                // without excluding its index in updateGameKeys(), the
                // hit-test would immediately re-add it to pointerKeys and
                // undo the remove().
                val liftedId = event.getPointerId(event.actionIndex)
                pointerKeys.remove(liftedId)
                pointerTurboA.remove(liftedId)
                pointerTurboB.remove(liftedId)
                updateGameKeys(event, excludePointerIndex = event.actionIndex)
            }
            else                          -> {
                ffLongPressPending?.let { mainHandler.removeCallbacks(it) }
                ffLongPressPending = null
                clearPointerState()
                currentKeys.set(0)
                lastSoundKeys = 0
                turboAHeld = false; turboBHeld = false
            }
        }
    }

    private fun updateGameKeys(event: MotionEvent, excludePointerIndex: Int = -1) {
        for (i in 0 until event.pointerCount) {
            if (i == excludePointerIndex) continue
            val pid = event.getPointerId(i)
            val x = event.getX(i); val y = event.getY(i)
            var hitAny = false
            var hitKeys = 0
            var hitTa = false
            var hitTb = false
            for (btn in buttons) {
                if (!btn.rect.contains(x, y)) continue
                hitAny = true
                when (btn.id) {
                    // Turbo satellites don't feed currentKeys directly (that
                    // would just be a continuous hold) — see the on/off
                    // square-wave applied in startGameLoop() before
                    // nativeSetKeys().
                    "ta" -> hitTa = true
                    "tb" -> hitTb = true
                    // "A/B turbo" combo — both satellites at once, reusing
                    // the exact same pointerTurboA/pointerTurboB machinery
                    // as ta/tb individually. Both share one phaseOn value
                    // in effectiveKeysForCore(), so driving both from a
                    // single touch square-waves A and B together in sync,
                    // rather than needing a third independent turbo channel.
                    "abturbo" -> { hitTa = true; hitTb = true }
                    else -> hitKeys = hitKeys or (if (btn.isDpad) dpadKeysFor(btn.rect, x, y) else btn.keyMask)
                }
            }
            if (hitAny) {
                // Overwrite (don't merge with) this pointer's previous
                // sticky state — a finger that's moved onto a different
                // button, or off Turbo onto a normal button, should read
                // as ONLY what it's on now, not accumulate stale bits from
                // wherever it used to be.
                pointerKeys[pid] = hitKeys
                if (hitTa) pointerTurboA.add(pid) else pointerTurboA.remove(pid)
                if (hitTb) pointerTurboB.add(pid) else pointerTurboB.remove(pid)
            }
            // else: this pointer is over empty space right now. Leave
            // pointerKeys[pid] / pointerTurboA / pointerTurboB exactly as
            // they were — that's the fix itself: a control that was
            // pressed keeps reading as pressed while dragged off it, until
            // this specific pointer lifts (handled in onGameTouch above).
        }

        var keys = 0
        for (k in pointerKeys.values) keys = keys or k
        currentKeys.set(keys)
        turboAHeld = pointerTurboA.isNotEmpty()
        turboBHeld = pointerTurboB.isNotEmpty()

        // Click sound: only on the RISING EDGE (bits newly set that weren't
        // set last call). This function runs on every ACTION_MOVE while a
        // finger drags across the d-pad, not just on initial touch-down —
        // gating on the edge instead of "any key held" keeps this to one
        // fire-and-forget system call per actual button press, so it can
        // never flood the audio pipeline or block the UI thread.
        if (buttonSoundEnabled) {
            val newlyPressed = keys and lastSoundKeys.inv()
            if (newlyPressed != 0) audioManager?.playSoundEffect(AudioManager.FX_KEYPRESS_STANDARD)
        }
        lastSoundKeys = keys
    }

    /** currentKeys as touched, plus the Turbo A/B on/off square wave mixed
     *  in if either is currently held. Kept separate from currentKeys
     *  itself so the on-screen "pressed" glow stays a simple, steady held
     *  state (see drawControls()) — only what actually reaches the core
     *  flickers. Called once per emulated frame from startGameLoop(), which
     *  at turboHalfPeriodMs=66 is plenty of resolution for the wave to read
     *  cleanly even under fast-forward. */
    private fun effectiveKeysForCore(): Int {
        var keys = currentKeys.get()
        if (turboAHeld || turboBHeld) {
            val phaseOn = (System.currentTimeMillis() / turboHalfPeriodMs) % 2L == 0L
            if (turboAHeld) keys = if (phaseOn) keys or EmulatorEngine.KEY_A else keys and EmulatorEngine.KEY_A.inv()
            if (turboBHeld) keys = if (phaseOn) keys or EmulatorEngine.KEY_B else keys and EmulatorEngine.KEY_B.inv()
        }
        return keys
    }

    // ── One-tap extra controls (quick save/load, screenshot) ────────────────
    // FEATURE: new. Unlike every other button, these don't feed
    // currentKeys/nativeSetKeys at all (keyMask 0 — see buildControlLayout)
    // — a tap fires the action once, immediately, the same way the ⏩
    // button toggles fastForwardActive in onGameTouch's ACTION_DOWN rather
    // than going through updateGameKeys.
    private val actionButtonIds = setOf("quicksave", "quickload", "screenshot")

    private fun actionButtonAt(x: Float, y: Float): String? =
        buttons.firstOrNull { it.id in actionButtonIds && it.rect.contains(x, y) }?.id

    private fun triggerActionButton(id: String) {
        when (id) {
            "quicksave"  -> quickSaveState()
            "quickload"  -> quickLoadState()
            "screenshot" -> takeScreenshot()
        }
    }

    // ── Control layout editor ────────────────────────────────────────────────
    //
    // FEATURE #2 — a My Boy!-style layout editor. Scope for this pass: every
    // button (D-pad × 4, A, B, Start, Select, L, R, Fast-Forward) can be
    // freely dragged anywhere on screen and resized via a corner handle, with
    // a per-button opacity override and a per-button lock, all live-previewed
    // over the actual running game and persisted across sessions. Deliberately
    // NOT built in this pass (flagged rather than silently skipped):
    // per-button rotation/mirroring (unusual for a D-pad/AB layout — mostly
    // relevant for decorative custom skins, low value here), snap-to-guides /
    // alignment grid, and named/duplicatable layout profiles beyond the
    // automatic portrait/landscape split already wired into the storage
    // format. Per-game layouts are a storage-key change away (see
    // orientationTag()/PREF_LAYOUT_PREFIX) but need a ROM-identity concept
    // (hash or path) this codebase doesn't have yet, so it's out of scope
    // until that exists rather than faked with a no-op toggle.

    private fun labelFor(id: String): String = when (id) {
        "dpad" -> "D-Pad"
        "a" -> "A Button"; "b" -> "B Button"; "start" -> "Start"; "select" -> "Select"
        "l" -> "L Shoulder"; "r" -> "R Shoulder"; "ff" -> "Fast-Forward"
        "ta" -> "Turbo A"; "tb" -> "Turbo B"
        "la" -> "TL+A"; "lb" -> "TL+B"; "ra" -> "TR+A"; "rb" -> "TR+B"
        "ab" -> "A/B"; "abturbo" -> "A/B Turbo"
        "quicksave" -> "Quick Save"; "quickload" -> "Quick Load"; "screenshot" -> "Screenshot"
        "gamescreen" -> "Game Screen"
        else -> id
    }

    private fun editRectFor(id: String): RectF? = when (id) {
        "ff" -> ffBtnRect
        "gamescreen" -> gameScreenRect
        else -> buttons.find { it.id == id }?.rect
    }

    private fun resizeHandleRadius(rect: RectF): Float =
        (minOf(rect.width(), rect.height()) * 0.22f).coerceIn(22f, 36f)

    // BUG FIX ("hitbox for dragging to resize is not accurate", most
    // noticeable in landscape): resizeHandleRadius() above is a *visual*
    // size — deliberately small so the dot doesn't look oversized on a tiny
    // button — but onEditTouch() used that exact same tiny radius as the
    // TOUCH target too, and worse, in raw pixels rather than dp. Its
    // 22–36f clamp is 22–36 *pixels*, which on a typical ~2.5–3x density
    // phone is only a ~15–24dp hit diameter — well under Android's own
    // 48dp minimum recommended touch target — and landscape specifically
    // makes it worse: buttons sit in a vertically-squeezed strip there
    // (see buildControlLayout's padH), so minOf(width,height) is smaller
    // and the radius bottoms out at the 22px floor even more often.
    // This is the touch-only hit radius: same visual dot, a much more
    // generous invisible grab zone around it (standard "small glyph, big
    // tap target" pattern), floored at a real 24dp regardless of how small
    // the button itself has been resized down to.
    private fun resizeHandleTouchRadius(rect: RectF): Float =
        maxOf(resizeHandleRadius(rect), dp(24).toFloat())

    private fun dist(x1: Float, y1: Float, x2: Float, y2: Float): Float {
        val dx = x1 - x2; val dy = y1 - y2
        return kotlin.math.sqrt(dx * dx + dy * dy)
    }

    /** Gets-or-creates the override entry for [id], seeded from its current
     *  default geometry so a freshly-touched button starts exactly where it
     *  visually already is, not at some arbitrary origin. */
    private fun entryFor(id: String): LayoutEntry = customLayout.getOrPut(id) {
        val g = defaultGeometry[id]
        LayoutEntry(
            xFrac = (g?.cx ?: lastSw / 2f) / lastSw.coerceAtLeast(1f),
            yFrac = (g?.cy ?: lastSh / 2f) / lastSh.coerceAtLeast(1f)
        )
    }

    private fun hitTestEditable(x: Float, y: Float): String? {
        // BUG FIX (resize hitbox "not accurate"), part 2: the resize dot is
        // drawn CENTERED ON the button's corner (drawEditOverlay:
        // drawCircle(rect.right, rect.bottom, ...)), so roughly half of its
        // visible area sits outside the button's own rect. The plain
        // rect.contains() checks below reject any touch that lands outside
        // the rect — including a touch square on the visible dot — so
        // grabbing the *outer* half of a handle you can plainly see used to
        // just deselect the button instead of resizing it. Checking the
        // already-selected button's handle FIRST, with the expanded
        // touch-friendly radius above, and allowing that check to succeed
        // even outside the rect, fixes it — while unselected buttons still
        // use plain rect.contains() (no handle is drawn for them, so there's
        // nothing extra to grab yet).
        editSelectedId?.let { id ->
            if (isButtonVisible(id)) {   // a hidden button's rect is zero-size, not "small" — never treat it as a handle target
                val rect = editRectFor(id)
                if (rect != null && dist(x, y, rect.right, rect.bottom) <= resizeHandleTouchRadius(rect)) return id
            }
        }
        if (ffBtnRect.contains(x, y)) return "ff"
        for (b in buttons) if (b.rect.contains(x, y)) return b.id
        // Lowest priority, checked last: the screen occupies a much larger
        // area than any button, so anything that *did* land on an actual
        // button was already returned above — this is only reached for
        // taps that missed every one of them.
        if (gameScreenRect.contains(x, y)) return "gamescreen"
        return null
    }

    private fun enterEditMode() {
        if (!romLoaded) {
            uiToast("Load a ROM first — the editor previews live over the running game")
            return
        }
        editModeActive = true
        editSelectedId = null
        clearPointerState()  // else the finger that opened the editor stays "stuck" in
        currentKeys.set(0)   // pointerKeys and comes back held the instant the editor closes
        turboAHeld = false; turboBHeld = false
        editTopBar.visibility = View.VISIBLE
        editButtonBar.visibility = View.GONE
        uiToast("Drag to move • corner dot to resize • hold to remove")
    }

    private fun exitEditMode(save: Boolean) {
        editModeActive = false
        editSelectedId = null
        editDragPointerId = -1
        editResizing = false
        cancelEditLongPress()
        editTopBar.visibility = View.GONE
        editButtonBar.visibility = View.GONE
        if (save) { saveCustomLayout(); uiToast("Layout saved") }
        else { loadCustomLayout(); uiToast("Changes discarded") }
        buildControlLayout(lastSw, lastSh)
    }

    private fun confirmResetAllLayout() {
        AlertDialog.Builder(this)
            .setTitle("Reset layout?")
            .setMessage("This clears every custom position/size for this orientation, brings back any removed controls, and clears any extra controls you've added. You can still Cancel afterward to undo.")
            .setPositiveButton("Reset") { _, _ ->
                customLayout.clear()
                removedButtons.clear()
                addedExtraButtons.clear()
                editDirty = true
                editSelectedId = null
                editButtonBar.visibility = View.GONE
                buildControlLayout(lastSw, lastSh)
                uiToast("Reset — tap ✓ Done to save, or ✕ Cancel to undo")
            }
            .setNegativeButton("Keep", null)
            .show()
    }

    private fun resetSingleButton(id: String) {
        customLayout.remove(id)
        editDirty = true
        buildControlLayout(lastSw, lastSh)
        refreshEditToolbarPosition()
    }

    private fun adjustSelectedScale(delta: Float) {
        val id = editSelectedId ?: return
        val e = entryFor(id)
        if (e.locked) { uiToast("🔒 Unlock this button first"); return }
        // FIX: was capped at 2.5x, then 4x (an earlier pass's own fix for
        // this same complaint against Turbo A/B specifically, whose
        // *default* size was only 0.55x a normal A/B button's — 4x of that
        // reaches 2.2x normal, which apparently still wasn't enough
        // headroom in practice). This pass: default Turbo A/B size raised
        // again (buildControlLayout's tSz, 0.55x → 0.75x) *and* the cap
        // raised again, 4x → 8x, for every button rather than special-
        // casing just these two — 8x is generous enough that reaching it
        // should be a rare, deliberate choice rather than a wall someone
        // hits while just trying to make a small satellite button
        // comfortable to tap. Still a real, finite ceiling rather than
        // literally none at all — an unbounded button could in principle
        // grow to cover the whole screen — just one far enough out that it
        // shouldn't be the thing anyone actually runs into again.
        e.scale = (e.scale + delta).coerceIn(0.5f, 8.0f)
        editDirty = true
        buildControlLayout(lastSw, lastSh)
        refreshEditToolbarPosition()
    }

    private fun adjustSelectedAlpha(delta: Int) {
        val id = editSelectedId ?: return
        val e = entryFor(id)
        if (e.locked) { uiToast("🔒 Unlock this button first"); return }
        val base = if (e.alphaOverride < 0) buttonBaseAlpha else e.alphaOverride
        e.alphaOverride = (base + delta).coerceIn(60, 255)
        editDirty = true
    }

    private fun toggleSelectedLock() {
        val id = editSelectedId ?: return
        val e = entryFor(id)
        e.locked = !e.locked
        editDirty = true
        updateEditButtonBarLockIcon()
    }

    private fun updateEditButtonBarLockIcon() {
        val id = editSelectedId ?: return
        editLockBtn.text = if (customLayout[id]?.locked == true) "🔒" else "🔓"
    }

    /** Repositions the per-button toolbar just above (or below, if that
     *  would collide with the top bar) the currently selected control. */
    private fun refreshEditToolbarPosition() {
        val id = editSelectedId ?: return
        val rect = editRectFor(id) ?: return
        editButtonBar.post {
            val w = editButtonBar.width.takeIf { it > 0 } ?: 480
            val h = editButtonBar.height.takeIf { it > 0 } ?: 110
            var ty = rect.top - h - 12f
            if (ty < editTopBar.height + 12f) ty = rect.bottom + 12f
            val tx = (rect.centerX() - w / 2f).coerceIn(4f, (lastSw - w - 4f).coerceAtLeast(4f))
            ty = ty.coerceIn(4f, (lastSh - h - 4f).coerceAtLeast(4f))
            editButtonBar.x = tx
            editButtonBar.y = ty
        }
    }

    private fun onEditTouch(event: MotionEvent) {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val x = event.x; val y = event.y
                val hitId = hitTestEditable(x, y)
                if (hitId == null) {
                    editSelectedId = null
                    editButtonBar.visibility = View.GONE
                    return
                }
                editSelectedId = hitId
                editDragPointerId = event.getPointerId(0)
                editDownX = x; editDownY = y
                val rect = editRectFor(hitId) ?: return
                // BUG FIX: was resizeHandleRadius(rect) * 1.6f — a tiny,
                // non-dp-aware radius (see resizeHandleTouchRadius's own
                // comment for the full root-cause). This is the down-time
                // decision for "did this touch grab the resize handle", now
                // using the same generous, density-aware radius that
                // hitTestEditable() uses to even let the touch reach here.
                val handleR = resizeHandleTouchRadius(rect)
                editResizing = dist(x, y, rect.right, rect.bottom) <= handleR
                if (editResizing) {
                    editResizeStartDist = dist(x, y, rect.centerX(), rect.centerY()).coerceAtLeast(1f)
                    editResizeStartScale = customLayout[hitId]?.scale ?: 1f
                } else {
                    editDragOffX = x - rect.centerX()
                    editDragOffY = y - rect.centerY()
                    // ADD/REMOVE CONTROL — hold-to-remove: armed only for a
                    // plain grab (not a resize-grab, so holding the corner
                    // handle still just resizes). Cancelled by real movement
                    // (ACTION_MOVE below) or the finger lifting first.
                    val pressedId = hitId
                    val longPress = Runnable {
                        if (editSelectedId == pressedId && editDragPointerId != -1) {
                            editLongPressPending = null
                            editDragPointerId = -1   // gesture is now "consumed" by the menu, not a drag
                            showRemoveButtonMenu(pressedId)
                        }
                    }
                    editLongPressPending = longPress
                    mainHandler.postDelayed(longPress, ViewConfiguration.getLongPressTimeout().toLong())
                }
                editButtonLabel.text = labelFor(hitId)
                updateEditButtonBarLockIcon()
                editButtonBar.visibility = View.VISIBLE
                refreshEditToolbarPosition()
            }
            MotionEvent.ACTION_MOVE -> {
                val id = editSelectedId ?: return
                val ptr = event.findPointerIndex(editDragPointerId)
                if (ptr < 0) return
                val e = entryFor(id)
                if (e.locked) return
                val x = event.getX(ptr); val y = event.getY(ptr)
                if (editLongPressPending != null && dist(x, y, editDownX, editDownY) > editTouchSlop) {
                    cancelEditLongPress()
                }
                if (editResizing) {
                    val c = editRectFor(id)
                    val d = dist(x, y, c?.centerX() ?: x, c?.centerY() ?: y)
                    // Matches adjustSelectedScale()'s own cap above — see
                    // its comment for why 4x, not the old 2.5x.
                    e.scale = (editResizeStartScale * (d / editResizeStartDist)).coerceIn(0.5f, 8.0f)
                } else {
                    val cx = (x - editDragOffX).coerceIn(lastSw * 0.03f, lastSw * 0.97f)
                    val cy = (y - editDragOffY).coerceIn(lastSh * 0.03f, lastSh * 0.97f)
                    e.xFrac = cx / lastSw.coerceAtLeast(1f)
                    e.yFrac = cy / lastSh.coerceAtLeast(1f)
                }
                editDirty = true
                buildControlLayout(lastSw, lastSh)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                if (event.getPointerId(event.actionIndex) == editDragPointerId) {
                    cancelEditLongPress()
                    editDragPointerId = -1
                    editResizing = false
                }
            }
            MotionEvent.ACTION_CANCEL -> {
                cancelEditLongPress()
                editDragPointerId = -1
                editResizing = false
            }
        }
    }

    private fun cancelEditLongPress() {
        editLongPressPending?.let { mainHandler.removeCallbacks(it) }
        editLongPressPending = null
    }

    /** Hold-to-remove popup — shown when [id]'s long-press timer fires in
     *  onEditTouch(). Deliberately a single tap-to-confirm action rather
     *  than a second confirmation dialog: removal is already low-stakes
     *  since "+ Add control" (showAddControlMenu) and ✕ Cancel both undo it. */
    private fun showRemoveButtonMenu(id: String) {
        // "gamescreen" isn't a real, removable control the way every other
        // id here is — there's nothing sensible "remove the game screen"
        // would even mean. Guarded here rather than at the long-press
        // arming site so this stays the one choke point regardless of what
        // ends up calling it.
        if (editSelectedId != id || id == "gamescreen") return
        val dialog = AlertDialog.Builder(this)
            .setItems(arrayOf("✕  Remove ${labelFor(id)}")) { _, _ -> removeButton(id) }
            .setNegativeButton("Cancel", null)
            .create()
        dialog.window?.setBackgroundDrawable(roundedDialogBackground())
        dialog.show()
    }

    private fun removeButton(id: String) {
        if (id in extraControlIds) addedExtraButtons.remove(id) else removedButtons.add(id)
        if (editSelectedId == id) {
            editSelectedId = null
            editButtonBar.visibility = View.GONE
        }
        editDirty = true
        buildControlLayout(lastSw, lastSh)
        uiToast("${labelFor(id)} removed — tap ＋ Add control to bring it back")
    }

    /** Every button id the editor knows how to draw — the source list for
     *  "+ Add control" (showAddControlMenu). Turbo A/B only count as
     *  "addable" while the Turbo setting itself is on (⚙ Settings → Input);
     *  buildControlLayout() never builds them at all otherwise, so re-adding
     *  one while Turbo is off would bring back a control with nothing to
     *  land on screen. extraControlIds (the shoulder/A-B combos and the
     *  quick save/load/screenshot actions) are always listed here — unlike
     *  Turbo, nothing else has to be enabled first for them to work. */
    private fun allControlIds(): List<String> {
        val ids = mutableListOf("dpad", "a", "b", "select", "start", "l", "r", "ff")
        ids += extraControlIds
        return ids
    }

    private fun showAddControlMenu() {
        val hidden = allControlIds().filter { !isButtonVisible(it) }
        if (hidden.isEmpty()) { uiToast("Every control is already on screen"); return }
        val labels = hidden.map { labelFor(it) }.toTypedArray()
        val dialog = AlertDialog.Builder(this)
            .setTitle("Add control")
            .setItems(labels) { _, which ->
                val id = hidden[which]
                if (id in extraControlIds) addedExtraButtons.add(id) else removedButtons.remove(id)
                editDirty = true
                buildControlLayout(lastSw, lastSh)
                uiToast("${labelFor(id)} added")
            }
            .setNegativeButton("Cancel", null)
            .create()
        dialog.window?.setBackgroundDrawable(roundedDialogBackground())
        dialog.show()
    }

    private val editHighlightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 4f; color = Color.parseColor("#FFEE58")
    }
    private val editHandlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL; color = Color.parseColor("#FFEE58")
    }
    private val editDimPaint = Paint().apply { color = Color.parseColor("#22000000") }

    private fun drawEditOverlay(canvas: Canvas) {
        canvas.drawRect(0f, 0f, canvas.width.toFloat(), canvas.height.toFloat(), editDimPaint)
        val id = editSelectedId ?: return
        val rect = editRectFor(id) ?: return
        canvas.drawRoundRect(rect, 12f, 12f, editHighlightPaint)
        canvas.drawCircle(rect.right, rect.bottom, resizeHandleRadius(rect), editHandlePaint)
    }

    // ── Settings screen ────────────────────────────────────────────────────
    //
    // RESKIN: the old single scrolling dialog is now a full-screen category
    // list — Video / Audio / Input / Layouts / Misc / Advanced / About —
    // matching the requested reference layout. Every setting that existed
    // before still exists, just regrouped:
    //   Video    — game screen size, fullscreen              (was GAME SCREEN)
    //   Audio    — button click sound
    //   Input    — the drag/resize button-layout editor
    //   Layouts  — button size, button opacity                (was CONTROLS)
    //   Misc     — fast-forward speed                         (was EMULATION)
    //   Advanced — reset all settings to defaults (new — nothing else in
    //              this app currently qualifies as "advanced")
    //   About    — app name / version (new)
    //
    // Link remote / Link local were added later, moved here from floating
    // buttons that used to sit on top of the game view (📂 top-right, 🔗
    // top-right) — see the comment in onCreate where settingsBtn is built.
    // Link remote is the Wi-Fi flow, Link local is Bluetooth; both used to
    // live behind one combined dialog, now split into their own rows to
    // match. Nothing about the underlying connect logic changed (see
    // showLinkRemoteDialog()/showLinkLocalDialog()). Both rows are also on
    // the quick game menu now for a faster path to the same actions (see
    // showGameMenu()) — harmless to leave duplicated here too.
    //
    // REMOVED: the Change ROM and Save States rows. changeRom() now lives
    // only on the initial "▶ Load ROM" button, and on Close, which now goes
    // straight to ROM selection itself rather than just that button (see
    // the BUG FIX comment on closeGame()). Save/Load moved to the quick
    // game menu's own rows, which already called showSaveStateSlotDialog()
    // directly rather than through this screen's old showSaveStateMenu()
    // — that function is now unused; left in place rather than deleted in
    // case it's wanted back.
    //
    // settingsMenuOverlay itself is built once in onCreate and just shown/
    // hidden (see buildSettingsMenu()) — it has no dynamic state of its own.
    // Each category still opens as an AlertDialog exactly like the old
    // settings screen did, rebuilding its fields fresh every time it's
    // opened, so Save/Cancel behaves exactly as before; dismissing that
    // dialog reveals the category list again underneath.

    // dp() and iconChipBackground() moved to SharedUi.kt this pass (Thirty-
    // second) as Context extension functions — RomBrowserActivity needs
    // them too, and every call site here (dp(20), iconChipBackground(), ...)
    // keeps working unchanged since both are in the same package.

    // ── Memory viewer ─────────────────────────────────────────────────────

    private data class MemRegion(val label: String, val base: Int, val size: Int)

    // Standard GBA memory map — fixed by the hardware, not this app; the
    // same addresses any GBA devkit/emulator/disassembler uses. EWRAM
    // listed first/default since that's where most games, Pokémon
    // included, keep the bulk of their live state (party data, battle
    // structs, etc.) — IWRAM is smaller and mostly used for hot/
    // performance-critical data, less likely to be what's actually being
    // looked for here.
    private val memRegions = listOf(
        MemRegion("EWRAM",   0x02000000, 0x40000),
        MemRegion("IWRAM",   0x03000000, 0x8000),
        MemRegion("Palette", 0x05000000, 0x400),
        MemRegion("VRAM",    0x06000000, 0x18000),
        MemRegion("OAM",     0x07000000, 0x400)
    )
    // 32 rows of 16 bytes — fits one screen without scrolling on most
    // phones at the dump's text size, without paging through hundreds of
    // screens to cross a 256KB region like EWRAM one page at a time.
    private val memoryPageBytes = 512
    private val memoryRefreshMs = 500L

    /** Shows the live memory viewer overlay — read-only inspection of the
     *  running core's RAM, requested for watching game state (a Pokémon
     *  battle's HP/party data was the specific example) change turn by
     *  turn. Values are read through mCore's own busRead8() (see
     *  nativeReadMemory() in mgba_jni.c) — the same bus mGBA's own cheat
     *  system reads through — rather than a raw pointer into EWRAM/IWRAM
     *  specifically, so every region (I/O registers, palette, VRAM, OAM,
     *  even ROM) works through one path instead of needing one per region.
     *
     *  Read-only for now, deliberately: "inspect live RAM" is what was
     *  asked for. Writing to memory (poking values — an actual cheat/edit
     *  tool) is a natural next step from here — a busWrite8() counterpart
     *  to nativeReadMemory() would be a small, symmetric addition — but is
     *  a materially different feature (anything that changes game state
     *  deserves its own explicit ask rather than riding along with
     *  "inspect"), so it's not included here.
     *
     *  Does not stop the game loop (see the field-block comment above
     *  where memoryViewerOverlay is declared) — gameplay keeps running
     *  underneath while this is open, and a self-rescheduling
     *  Handler.postDelayed() loop (see scheduleMemoryRefresh()) keeps the
     *  dump current every memoryRefreshMs while the overlay stays visible. */
    private fun showMemoryViewer() {
        memoryRegionIndex = 0
        memoryPageOffset = 0
        memoryViewerOverlay.visibility = View.VISIBLE
        refreshMemoryDump()
        scheduleMemoryRefresh()
    }

    private fun hideMemoryViewer() {
        memoryViewerOverlay.visibility = View.GONE
    }

    private fun scheduleMemoryRefresh() {
        mainHandler.postDelayed({
            if (isFinishing || isDestroyed) return@postDelayed
            if (memoryViewerOverlay.visibility != View.VISIBLE) return@postDelayed
            refreshMemoryDump()
            scheduleMemoryRefresh()
        }, memoryRefreshMs)
    }

    private fun refreshMemoryDump() {
        val region = memRegions[memoryRegionIndex]
        memoryAddressText.text = "%s   0x%08X".format(region.label, region.base + memoryPageOffset)
        if (!romLoaded) { memoryDumpText.text = "Load a ROM first"; return }
        val length = memoryPageBytes.coerceAtMost(region.size - memoryPageOffset)
        if (length <= 0) { memoryDumpText.text = "End of region"; return }
        val address = region.base + memoryPageOffset
        val buf = ByteArray(length)
        val n = EmulatorEngine.nativeReadMemory(address, buf, length)
        memoryDumpText.text = if (n <= 0) "Not available right now" else formatHexDump(address, buf, n)
    }

    /** Classic hex-dump layout: 8-digit address, 16 hex bytes (a mid-row gap
     *  after the 8th, same convention as `hexdump -C`/most hex editors),
     *  then the same 16 bytes as ASCII (printable range 0x20–0x7E, '.' for
     *  everything else). */
    private fun formatHexDump(baseAddress: Int, bytes: ByteArray, length: Int): String {
        val sb = StringBuilder()
        var i = 0
        while (i < length) {
            val rowLen = minOf(16, length - i)
            sb.append(String.format("%08X  ", baseAddress + i))
            for (j in 0 until 16) {
                if (j < rowLen) sb.append(String.format("%02X ", bytes[i + j])) else sb.append("   ")
                if (j == 7) sb.append(' ')
            }
            sb.append(' ')
            for (j in 0 until rowLen) {
                val b = bytes[i + j].toInt() and 0xFF
                sb.append(if (b in 0x20..0x7E) b.toChar() else '.')
            }
            sb.append('\n')
            i += 16
        }
        return sb.toString()
    }

    private fun buildMemoryViewer(): LinearLayout {
        val ctx = this

        val header = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(16), dp(16), dp(14))
            addView(TextView(ctx).apply {
                text = "Memory"; textSize = 22f; typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.WHITE)
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(TextView(ctx).apply {
                text = "✕ Close"; textSize = 13f
                setTextColor(colorAccentLight)
                setPadding(dp(14), dp(8), dp(14), dp(8))
                isClickable = true; isFocusable = true
                background = iconChipBackground()
                setOnClickListener { hideMemoryViewer() }
            })
        }

        // Chip TextViews kept in a list (indexed the same as memRegions) so
        // tapping one can restyle every chip's highlight directly, rather
        // than rebuilding this row (or the whole overlay) from scratch on
        // every tap.
        val regionChips = mutableListOf<TextView>()
        val regionRow = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(16), dp(0), dp(16), dp(10))
            memRegions.forEachIndexed { index, region ->
                val chip = TextView(ctx).apply {
                    text = region.label; textSize = 12f
                    setTextColor(if (index == memoryRegionIndex) Color.WHITE else colorAccentLight)
                    setPadding(dp(10), dp(8), dp(10), dp(8))
                    isClickable = true; isFocusable = true
                    background = iconChipBackground()
                }
                regionChips.add(chip)
                chip.setOnClickListener {
                    memoryRegionIndex = index
                    memoryPageOffset = 0
                    regionChips.forEachIndexed { i, c -> c.setTextColor(if (i == index) Color.WHITE else colorAccentLight) }
                    refreshMemoryDump()
                }
                addView(chip, LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
                ).also { it.rightMargin = dp(8) })
            }
        }

        val pageRow = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(0), dp(20), dp(10))
            addView(TextView(ctx).apply {
                text = "◀"; textSize = 16f
                setTextColor(Color.WHITE)
                setPadding(dp(10), dp(4), dp(20), dp(4))
                isClickable = true; isFocusable = true
                setOnClickListener {
                    memoryPageOffset = (memoryPageOffset - memoryPageBytes).coerceAtLeast(0)
                    refreshMemoryDump()
                }
            })
            memoryAddressText = TextView(ctx).apply {
                textSize = 13f
                typeface = Typeface.MONOSPACE
                setTextColor(colorAccentLight)
            }
            addView(memoryAddressText, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(TextView(ctx).apply {
                text = "▶"; textSize = 16f
                setTextColor(Color.WHITE)
                setPadding(dp(20), dp(4), dp(10), dp(4))
                isClickable = true; isFocusable = true
                setOnClickListener {
                    val region = memRegions[memoryRegionIndex]
                    memoryPageOffset = (memoryPageOffset + memoryPageBytes).coerceAtMost(
                        (region.size - 1).coerceAtLeast(0))
                    refreshMemoryDump()
                }
            })
        }

        memoryDumpText = TextView(ctx).apply {
            typeface = Typeface.MONOSPACE
            textSize = 11f
            setTextColor(Color.parseColor("#D8D8DE"))
            setPadding(dp(16), dp(0), dp(16), dp(16))
        }

        val footer = TextView(ctx).apply {
            text = "Read-only — refreshes automatically every ${memoryRefreshMs / 1000.0}s while open"
            textSize = 11f
            setTextColor(Color.parseColor("#888892"))
            setPadding(dp(20), dp(4), dp(20), dp(16))
        }

        return LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#FF17171B"))
            isClickable = true; isFocusable = true
            addView(header)
            addView(View(ctx).apply { setBackgroundColor(Color.parseColor("#22FFFFFF")) },
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1).coerceAtLeast(1)))
            addView(regionRow)
            addView(pageRow)
            addView(ScrollView(ctx).apply { addView(memoryDumpText) },
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
            addView(footer)
        }
    }

    private fun buildSettingsMenu(): LinearLayout {
        val ctx = this

        val header = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(16), dp(16), dp(14))
            addView(TextView(ctx).apply {
                text = "Settings"; textSize = 22f; typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.WHITE)
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(TextView(ctx).apply {
                text = "✕ Close"; textSize = 13f
                setTextColor(colorAccentLight)
                setPadding(dp(14), dp(8), dp(14), dp(8))
                isClickable = true; isFocusable = true
                background = iconChipBackground()
                setOnClickListener { settingsMenuOverlay.visibility = View.GONE }
            })
        }

        val rows = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            addView(settingsRow("🖥", "Video",    "Screen size, orientation & effects") { showVideoSettings() })
            addView(settingsRow("🔊", "Audio",    "Button click sound")            { showAudioSettings() })
            addView(settingsRow("🕹", "Input",    "Edit on-screen button layout")  { showInputSettings() })
            addView(settingsRow("▦", "Layouts",  "Button size & opacity")         { showLayoutsSettings() })
            addView(settingsRow("👤", "Misc",     "Fast-forward speed")            { showMiscSettings() })
            addView(settingsRow("💾", "Storage",  "Where saves/states/screenshots live") { showStorageSettings() })
            addView(settingsRow("🔗", "Link remote", "Multiplayer over Wi-Fi")     { showLinkRemoteDialog() })
            addView(settingsRow("📶", "Link local",  "Multiplayer over Bluetooth") { showLinkLocalDialog() })
            addView(settingsRow("🎚", "Advanced", "Reset settings to defaults")    { showAdvancedSettings() })
            addView(settingsRow("ℹ️", "About",    "Version & info")                { showAboutDialog() })
        }

        return LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#FF17171B"))
            isClickable = true; isFocusable = true   // swallow touches — nothing behind this should be reachable
            addView(header)
            addView(View(ctx).apply { setBackgroundColor(Color.parseColor("#22FFFFFF")) },
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1).coerceAtLeast(1)))
            // Scrollable: this app is locked to landscape (see onCreate), so
            // available height can be quite short on a lot of phones — eleven
            // rows plus a header can easily exceed that, which would make
            // "About" unreachable without this. (Was seven rows before Change
            // ROM / Link remote / Link local moved in from floating buttons —
            // already scrollable, so they just slot in.)
            addView(ScrollView(ctx).apply { addView(rows) },
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        }
    }

    private fun settingsRow(icon: String, title: String, subtitle: String, onClick: () -> Unit): View {
        val ctx = this
        val ripple = TypedValue()
        theme.resolveAttribute(android.R.attr.selectableItemBackground, ripple, true)
        return LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            isClickable = true; isFocusable = true
            setBackgroundResource(ripple.resourceId)
            setPadding(dp(20), dp(14), dp(20), dp(14))
            addView(TextView(ctx).apply {
                text = icon; textSize = 20f
                setTextColor(colorAccentLight)
            }, LinearLayout.LayoutParams(dp(44), LinearLayout.LayoutParams.WRAP_CONTENT))
            addView(LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                addView(TextView(ctx).apply {
                    text = title; textSize = 17f
                    setTextColor(Color.WHITE)
                })
                addView(TextView(ctx).apply {
                    text = subtitle; textSize = 12f
                    setTextColor(Color.parseColor("#888892"))
                    setPadding(0, dp(2), 0, 0)
                })
            })
            setOnClickListener { onClick() }
        }
    }

    private fun showSettingsMenu() {
        settingsMenuOverlay.visibility = View.VISIBLE
    }

    /** Applies [screenOrientationChoice] to the live activity. Safe to call
     *  any time, not just from onCreate — e.g. showVideoSettings()'s Save
     *  button calls this too, right after persisting a new choice.
     *  android:configChanges in the manifest already keeps this activity
     *  (and the running core) alive across whatever orientation change this
     *  triggers, rather than recreating it.
     *
     *  BUG FIX: wrapped in try/catch. setRequestedOrientation() has a known
     *  Android crash — IllegalStateException("Only fullscreen opaque
     *  activities can request orientation") — thrown on API 26+ whenever
     *  the system doesn't currently consider this activity fullscreen (e.g.
     *  split-screen/multi-window/freeform, or some OEM launcher/window
     *  quirks entirely outside this app's control). This call already
     *  existed before the fix (app start, Video settings' Save button),
     *  just rarely enough that this was a latent, never-hit risk; a later
     *  pass temporarily added far more call sites — every ROM browser
     *  open/close/load, back when it forced Portrait for that screen from
     *  right here in this class — which is exactly where a crash "opening
     *  a ROM" started actually showing up. Those extra call sites are gone
     *  now (the ROM browser is RomBrowserActivity, its own Activity,
     *  locked to Portrait statically via the manifest instead of any
     *  requestedOrientation call — see its top-of-file comment), so this
     *  function is back to being the only place that sets orientation. The
     *  try/catch stays regardless: cheap insurance, and the underlying
     *  platform quirk it guards against has nothing to do with how many
     *  call sites there are. Worst case with the catch: that one
     *  orientation change silently doesn't happen; without it, the whole
     *  app crashes. */
    private fun applyScreenOrientationPref() {
        try {
            requestedOrientation = when (screenOrientationChoice) {
                ORIENTATION_AUTO             -> ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
                ORIENTATION_REVERSE_LANDSCAPE -> ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE
                ORIENTATION_PORTRAIT         -> ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                ORIENTATION_SYSTEM           -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                else                         -> ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE  // ORIENTATION_LANDSCAPE + any bad stored value
            }
        } catch (e: Exception) {
            Log.e(TAG, "setRequestedOrientation failed, ignoring", e)
        }
    }

    // ── ROM file browser — now RomBrowserActivity.kt, a separate Activity ──
    //
    // buildBrowserStack(), openRomBrowserAtRoot(), romBrowserUp(),
    // refreshRomBrowserList(), renderRomBrowserList(), romBrowserMessageRow(),
    // romBrowserRow(), and buildRomBrowser() all moved to RomBrowserActivity.kt
    // this pass (Thirty-second) — see that file for the current versions and
    // its own top-of-file comment for why this is a separate Activity now
    // instead of an overlay here (a real, twice-reproduced native crash from
    // forcing orientation on this screen while it lived in this Activity's
    // own window, alongside the game surface).

    // FIX: ⚙ used to call showSettingsMenu() directly, jumping straight into
    // the full Video/Audio/Input/Layouts/... category list with no menu in
    // between. This is the quick game menu that now opens first — Load,
    // Save and Fast forward act immediately; Settings hands off to the
    // screen below.
    //
    // MENU REDESIGN: restyled from a bare .setItems() list (default system
    // row styling) to plain rows via a custom ArrayAdapter, to match the
    // reference screenshot — and folded Link remote/local back in here
    // alongside three new actions (Screenshot, Reset, Close), matching that
    // reference's full ten-item list. It's one continuous list; AlertDialog's
    // own internal ListView scrolls it automatically once it overflows the
    // dialog's height, exactly like it already did for the old 5-item
    // version — nothing extra needed for that part. Settings, Link remote
    // and Link local are still also reachable from the Settings screen,
    // unchanged (see buildSettingsMenu()) — this just adds a faster path to
    // the same actions, matching how My Boy's own menu is laid out.
    private fun showGameMenu() {
        val items = listOf(
            "Load", "Save", "Fast forward", "Cheats", "Settings",
            "Link remote", "Link local", "Screenshot", "Reset",
            "Copy link log", "Copy crash log", "Memory", "Close"
        )
        // FEATURE: "Memory" (index 11) added right before "Close" rather
        // than in a more thematically-grouped spot (e.g. next to "Cheats")
        // specifically so every other item's index stays exactly what it
        // was — this list is dispatched purely by position below, and
        // inserting in the middle would have meant renumbering every case
        // after it for no functional reason.
        val needsRom = setOf(0, 1, 2, 7, 8, 11) // Load, Save, Fast forward, Screenshot, Reset, Memory
        val adapter = object : ArrayAdapter<String>(this, 0, items) {
            override fun getView(position: Int, recycled: View?, parent: ViewGroup): View {
                val row = recycled as? TextView ?: gameMenuRow()
                row.text = getItem(position)
                return row
            }
        }
        val dialog = AlertDialog.Builder(this)
            .setAdapter(adapter) { _, which ->
                if (which in needsRom && !romLoaded) { uiToast("Load a ROM first"); return@setAdapter }
                when (which) {
                    0 -> showSaveStateSlotDialog(forSave = false)
                    1 -> showSaveStateSlotDialog(forSave = true)
                    2 -> {
                        fastForwardActive = !fastForwardActive
                        uiToast(if (fastForwardActive) "Fast forward ON" else "Fast forward OFF")
                    }
                    3 -> uiToast("Cheats — not implemented yet")
                    4 -> showSettingsMenu()
                    5 -> showLinkRemoteDialog()
                    6 -> showLinkLocalDialog()
                    7 -> takeScreenshot()
                    8 -> resetGame()
                    9 -> copyLinkDebugLog()
                    10 -> copyCrashLog()
                    11 -> showMemoryViewer()
                    12 -> closeGame()
                }
            }
            .create()
        // Dark rounded panel to match the reference screenshot explicitly —
        // the system default AlertDialog background varies more by device/
        // OEM skin (Infinix's XOS included) than the plain row styling
        // above does, so this is pinned rather than left to the theme.
        dialog.window?.setBackgroundDrawable(roundedDialogBackground())
        dialog.show()
    }

    /** Plain-text row for the quick game menu above — larger and simpler
     *  than settingsRow() (no icon/subtitle) to match the reference
     *  screenshot: a scrollable list of plain rows, nothing else.
     *
     *  FIX (Eleventh pass): this row must NOT be isClickable/isFocusable,
     *  and previously was — copied from settingsRow() below without
     *  noticing the two are backed by completely different click paths.
     *  settingsRow() is a plain LinearLayout child added via addView(),
     *  which has no click handling of its own, so it needs to be
     *  clickable/focusable AND carry its own setOnClickListener. This row
     *  is the convertView inside showGameMenu()'s ListView (AlertDialog's
     *  setAdapter), where the *only* click handling is that ListView's own
     *  OnItemClickListener — the `{ _, which -> ... }` lambda passed to
     *  setAdapter() above. A clickable/focusable child steals the touch
     *  before the ListView ever gets to fire that listener, so every row
     *  quietly ate its own tap: the ripple still played (the background
     *  is a pressed-state drawable, and ListView forwards pressed state to
     *  whichever child is under the touch regardless of its own clickable
     *  flag) but `which` was never delivered — which is why Load, Save,
     *  Settings, Link remote, Link local, etc. all silently did nothing
     *  after this menu was restyled. Removing the two flags here restores
     *  the same plain-list-item behavior the old .setItems() version had,
     *  while keeping the ripple background exactly as it was. */
    private fun gameMenuRow(): TextView {
        val ripple = TypedValue()
        theme.resolveAttribute(android.R.attr.selectableItemBackground, ripple, true)
        return TextView(this).apply {
            textSize = 17f
            setTextColor(Color.WHITE)
            setPadding(dp(28), dp(20), dp(28), dp(20))
            setBackgroundResource(ripple.resourceId)
        }
    }

    // ── Link debug log ───────────────────────────────────────────────────
    // FEATURE: new (Twelfth pass). The multiplayer subsystem has a real,
    // still-open issue (see KNOWN_LIMITATIONS.md / BUGS_FIXED.md, "Sixth"
    // through "Seventeenth" passes): the app-level Wi-Fi/Bluetooth handshake
    // can succeed while the ROM's own in-game link/multiplayer screen never
    // reacts to it. mgba_jni.c's FIX 11 already added permanent trace
    // logging for exactly this (tag mGBA-JNI, plus mGBA-Link on the Kotlin
    // side) — every pass since concluded the *next* real step needs that
    // actual log output, not another guess.
    //
    // FIX 17: this used to shell out to `logcat`, which works for reading
    // back a process's own output without root or READ_LOGS on stock
    // Android, but which W's own device split (real output on one phone,
    // nothing at all on the other, both running this exact build) confirmed
    // some OEM builds restrict further than that. Now reads a plain private
    // file this app owns outright instead (see EmulatorEngine.
    // nativeSetLinkLogPath, called once from onCreate) — every LOGI/LOGW/
    // LOGE in mgba_jni.c, plus this class's own connection-lifecycle lines
    // (see LinkMultiplayer.kt's FIX 17 entry), now mirrors into it. Needs no
    // logcat/READ_LOGS access at all, on any OEM build, since it was never
    // reading logcat to begin with — just a file in this app's own
    // filesDir. The native side truncates it fresh at the start of every
    // link session (see nativeLinkStart()'s own FIX 17 comment), so a
    // capture reflects one connection attempt, not an accumulation.
    //
    // Meant to be opened right after reproducing the issue being chased —
    // both phones' ROMs actually navigated into their in-game link menus,
    // not just the app-level "Connected" toast, and (for a disconnect
    // report specifically) after actually tapping Disconnect and giving the
    // other phone a few seconds — so the log actually covers a real
    // attempt. Whether *any* "SIO write addr=..." line shows up at all is
    // the specific thing every recent pass has been unable to check: none
    // at all points upstream of the SIO driver entirely (wrong mode
    // selected, or the driver never truly took); several, with the exchange
    // completing, points at the protocol logic instead. Copies to the
    // clipboard automatically (paste it straight back) and also shows it
    // on-screen in case the clipboard isn't available for some reason.
    /** BUG FIX (real ANR, not a guess — caught via the Crash Log Viewer
     *  app): "Input dispatching timed out... Waited 5000ms", with the main
     *  thread's stack sitting inside TextView/Editor draw code under a
     *  ScrollView at the moment it hung — exactly the shape of
     *  showLinkDebugLogDialog()/showCrashLogDialog() below. A real link
     *  session logs a line (sometimes several) per SIO write and per child
     *  exchange — see LinkMultiplayer.kt's own log calls — which adds up to
     *  a genuinely huge file over a real testing session, especially on
     *  whichever side is host. Rendering that much text in a
     *  setTextIsSelectable(true) TextView is known to be catastrophically
     *  slow (selectable text needs a much heavier internal layout the
     *  plain non-selectable path doesn't), and that's exactly what froze
     *  the main thread long enough to trip Android's own ANR watchdog.
     *  Caps to the most recent [maxChars] — still tens of thousands of
     *  characters of context, plenty to debug from, but bounded — applied
     *  once here so it protects both the on-screen dialog and the
     *  clipboard copy, not just one of them. */
    private fun capLogText(text: String, maxChars: Int = 40_000): String =
        if (text.length <= maxChars) text
        else "…[${text.length - maxChars} earlier characters truncated — showing the most recent $maxChars]…\n\n" + text.takeLast(maxChars)

    private fun copyLinkDebugLog() {
        uiToast("Reading log…")
        Thread {
            val text = try {
                val f = File(filesDir, "link_debug.log")
                if (f.exists()) capLogText(f.readText()) else ""
            } catch (e: Exception) {
                Log.e(TAG, "link log file read failed", e)
                "Couldn't read the log file directly (${e.message})."
            }
            // FIX 19: stamp the exact moment THIS device's copy happened, in
            // the same MM-DD HH:MM:SS.mmm layout the log lines themselves
            // use (see link_log_write_locked()'s own comment in mgba_jni.c)
            // — two phones' copies never land at quite the same instant (a
            // human taps one button, then walks to the other phone and taps
            // its button too), and until now the only way to tell how far
            // apart two captures really were was comparing the last real SIO
            // line on each side, which only works if both sides were still
            // actively exchanging data right up to the tap — not during a
            // lull, and not at all if one side's tail is mostly idle
            // padding. This line answers "how far apart were these two
            // captures" directly, every time.
            val stamp = java.text.SimpleDateFormat("MM-dd HH:mm:ss.SSS", java.util.Locale.US)
                .format(java.util.Date())
            val stamped = if (text.isBlank()) text else "$text\n=== copied at $stamp ==="
            runOnUiThread { showLinkDebugLogDialog(stamped) }
        }.start()
    }

    private fun showLinkDebugLogDialog(logText: String) {
        val shown = logText.ifBlank {
            "(empty — make sure both phones' ROMs were actually navigated " +
            "into their in-game link/multiplayer menu during this session, " +
            "not just the app-level Connected step; for a disconnect issue, " +
            "also actually tap Disconnect and wait a few seconds before " +
            "reading this log. If this stays empty even after a real " +
            "attempt, nativeSetLinkLogPath() may have failed to open the " +
            "file — check Logcat for \"Link log file path set\" around app " +
            "startup.)"
        }
        try {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("mGBA link log", shown))
        } catch (e: Exception) {
            Log.w(TAG, "Clipboard copy failed (log is still shown below)", e)
        }
        // BUG FIX: was setTextIsSelectable(true) — see capLogText()'s doc
        // comment. The clipboard copy just above already covers "get this
        // text out of the phone"; on-screen selection was a nice-to-have
        // that turned out to cause a real ANR, so it's gone rather than
        // just gated behind a length check — not worth the risk twice.
        val textView = TextView(this).apply {
            text = shown
            textSize = 11f
            typeface = Typeface.MONOSPACE
            setTextColor(Color.WHITE)
            setPadding(dp(20), dp(16), dp(20), dp(16))
        }
        AlertDialog.Builder(this)
            .setTitle("Link debug log (copied to clipboard)")
            .setView(ScrollView(this).apply { addView(textView) })
            .setPositiveButton("Close", null)
            .show()
    }

    // ── Crash log ─────────────────────────────────────────────────────────
    // See installCrashLogger()'s doc comment (near onCreate) for the why —
    // this just reads back what that handler wrote, the same read-off-
    // main-thread-then-show-a-dialog shape as copyLinkDebugLog() above.
    private fun copyCrashLog() {
        uiToast("Reading crash log…")
        Thread {
            val text = try {
                val f = File(filesDir, "crash_log.txt")
                if (f.exists()) capLogText(f.readText()) else ""
            } catch (e: Exception) {
                Log.e(TAG, "crash log file read failed", e)
                "Couldn't read the crash log file directly (${e.message})."
            }
            runOnUiThread { showCrashLogDialog(text) }
        }.start()
    }

    private fun showCrashLogDialog(logText: String) {
        val shown = logText.ifBlank {
            "(empty — no crash recorded since this build was installed. If " +
            "it crashes again, come straight back here afterward; the next " +
            "launch will have written a fresh report before you even see " +
            "this menu again.)"
        }
        try {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("mGBA crash log", shown))
        } catch (e: Exception) {
            Log.w(TAG, "Clipboard copy failed (log is still shown below)", e)
        }
        // BUG FIX: see capLogText()'s doc comment — same reasoning as
        // showLinkDebugLogDialog() above.
        val textView = TextView(this).apply {
            text = shown
            textSize = 11f
            typeface = Typeface.MONOSPACE
            setTextColor(Color.WHITE)
            setPadding(dp(20), dp(16), dp(20), dp(16))
        }
        AlertDialog.Builder(this)
            .setTitle("Crash log (copied to clipboard)")
            .setView(ScrollView(this).apply { addView(textView) })
            .setPositiveButton("Close", null)
            .show()
    }

    // ── Screenshot ───────────────────────────────────────────────────────
    // FEATURE: new — didn't exist before. Uses PixelCopy against the
    // SurfaceView itself (API 24+, matches this app's minSdk, no version
    // check needed) rather than reaching into frameBuffers/displayIdx
    // directly, so it always grabs exactly what's currently on screen
    // without needing to reason about the triple-buffer's own
    // synchronization from an unrelated call site.

    private fun takeScreenshot() {
        if (!romLoaded) { uiToast("Load a ROM first"); return }
        val w = surfaceView.width
        val h = surfaceView.height
        if (w <= 0 || h <= 0) { uiToast("Screenshot failed"); return }
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        PixelCopy.request(surfaceView, bmp, { result ->
            if (result == PixelCopy.SUCCESS) saveScreenshotBitmap(bmp)
            else uiToast("Screenshot failed")
        }, Handler(Looper.getMainLooper()))
    }

    private fun saveScreenshotBitmap(bmp: Bitmap) {
        val stamp = DateFormat.format("yyyyMMdd_HHmmss", System.currentTimeMillis())
        val name = "${currentRomBaseName}_$stamp.png"
        try {
            // FEATURE: Storage folder — see the block comment above
            // dataFolderTree(). Screenshots always create a brand-new,
            // uniquely-timestamped file, never look up an existing one, so
            // this doesn't need the full find-or-create SaveEntry
            // machinery the save/state files below do — just create it
            // directly in the "screenshot" subfolder when one's configured.
            val subDir = dataSubfolder("screenshot")
            if (subDir != null) {
                val doc = subDir.createFile("image/png", name)
                    ?: throw IOException("Couldn't create $name in the chosen folder")
                contentResolver.openOutputStream(doc.uri)?.use { out ->
                    bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
                } ?: throw IOException("openOutputStream failed for $name")
            } else {
                // Legacy/fallback location — unchanged from before this
                // feature existed. Still under Android/data, same as every
                // save/state without a Storage folder chosen; see
                // showStorageSettings() to change that.
                val dir = File(getExternalFilesDir(null), "Screenshots").apply { mkdirs() }
                File(dir, name).outputStream().use { out -> bmp.compress(Bitmap.CompressFormat.PNG, 100, out) }
            }
            uiToast("Saved $name")
        } catch (e: Exception) {
            Log.e(TAG, "Screenshot save failed", e)
            uiToast("Screenshot save failed")
        }
    }

    // ── Reset ────────────────────────────────────────────────────────────
    // FEATURE: new. There's no standalone core-reset entry point on the
    // native side — core->reset() is only ever called from inside
    // nativeLoadROM() itself (see mgba_jni.c) — and this project's own
    // history shows JNI signature mismatches only turning up once a real CI
    // build ran against the actual pinned mGBA headers (see FIX 8 in
    // mgba_jni.c). A brand-new hand-written JNI export isn't worth that
    // build-and-pray risk just for this, so this reuses nativeLoadROM()
    // instead: the last-loaded ROM's bytes are still sitting at the fixed
    // cache path below (see the ROM-picker callback above — it's never
    // deleted), so reloading from there with the same battery-save path is
    // a full power-cycle — same user-visible effect as a hardware reset,
    // save data intact — through a path that's already proven to build and
    // work rather than a new, unverifiable one.

    private fun resetGame() {
        if (!romLoaded) { uiToast("Load a ROM first"); return }
        val tmp = cacheDir.resolve("rom_loaded.gba")
        if (!tmp.exists()) { uiToast("Can't reset — try Close, then Load ROM"); return }
        if (link.isConnected) stopLink()
        stopGameLoop()
        val baseName = currentRomBaseName
        Thread {
            val saveEntry = batterySaveEntry(baseName)
            backupIfExists(saveEntry)
            // FIX (Twenty-first pass): see loadRomFromUri's own comment on
            // batteryMirrorPath() replacing the /proc/self/fd bridge.
            val savePath = saveEntry.batteryMirrorPath()
            val ok = EmulatorEngine.nativeLoadROM(tmp.absolutePath, savePath)
            Handler(Looper.getMainLooper()).post {
                if (isFinishing || isDestroyed) return@post
                if (ok) {
                    val w = EmulatorEngine.nativeGetWidth().coerceAtLeast(1)
                    val h = EmulatorEngine.nativeGetHeight().coerceAtLeast(1)
                    frameBuffers = Array(3) { Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888) }
                    writeIdx = 0; readyIdx = -1; displayIdx = -1
                    clearPointerState(); currentKeys.set(0); fastForwardActive = false
                    initAudioTrack()
                    startGameLoop()
                    uiToast("Game reset")
                } else {
                    romLoaded = false
                    uiToast("Reset failed — ROM may be missing from cache")
                }
            }
        }.apply { name = "mGBA-reset" }.start()
    }

    // ── Close ────────────────────────────────────────────────────────────
    // FEATURE: new. Stops the current game and drops back to ROM selection.
    // Nothing needs freeing on the native side for this — nativeLoadROM()
    // already swaps cores cleanly on the next load (see the FIX comment
    // above the ROM-picker callback) — so this just stops the loop/audio
    // and restores the pre-load UI.
    //
    // BUG FIX (earlier pass): Close used to only flip the old floating
    // "Load ROM" button back to VISIBLE and stop there, leaving the
    // SurfaceView untouched. A SurfaceView just keeps showing whatever it
    // last drew until something draws over it again, so the closed game's
    // last frame stayed sitting there until a new ROM was loaded and
    // rendered its own first frame. Fixed by wiping the surface to black
    // immediately (clearSurfaceToBlack()) and handing off straight to
    // changeRom(), which opens the file browser directly if a ROM folder's
    // already been picked, otherwise prompts to pick one. That button is
    // gone now (see the FIX comment in onCreate where it used to be built)
    // — romLoaded is left false here, so if changeRom()'s own picker gets
    // cancelled, a tap on the idle surface (see onGameTouch()) is the way
    // back in instead.
    private fun closeGame() {
        if (!romLoaded) return
        if (link.isConnected) stopLink()
        stopGameLoop()
        try { audioTrack?.pause(); audioTrack?.flush() } catch (_: Exception) {}
        // FIX (Twenty-first pass): flush the battery-save mirror out to the
        // chosen Storage folder before this ROM's session is considered
        // over — see onPause()'s own copy of this call for the fuller
        // explanation. Closing back to the ROM browser is exactly the kind
        // of "I'm done with this game for now" moment that should sync,
        // same as backgrounding the app.
        batterySaveEntry(currentRomBaseName).syncBatteryMirror()
        romLoaded = false
        clearSurfaceToBlack()
        uiToast("Game closed")
        changeRom()
    }

    // ── Shared dialog-building helpers (used by several categories below) ──

    private fun dlgRadioGroup(horizontal: Boolean = true) = RadioGroup(this).apply {
        if (horizontal) orientation = LinearLayout.HORIZONTAL
    }
    private fun RadioGroup.dlgAddOpt(label: String): RadioButton = RadioButton(context).apply {
        text = label
        id   = View.generateViewId()
        setTextColor(Color.WHITE)
        textSize = 13f
    }.also { addView(it) }

    /** Plain tappable row for the Video list — no icon, unlike settingsRow()
     *  above (that one's for the Settings category list one level up; this
     *  screen's own reference screenshot has no icons on its rows at all). */
    private fun videoListRow(title: String, subtitle: String?, onClick: () -> Unit): View {
        val ctx = this
        val ripple = TypedValue()
        theme.resolveAttribute(android.R.attr.selectableItemBackground, ripple, true)
        return LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            isClickable = true; isFocusable = true
            setBackgroundResource(ripple.resourceId)
            setPadding(dp(20), dp(14), dp(20), dp(14))
            addView(TextView(ctx).apply { text = title; textSize = 16f; setTextColor(Color.WHITE) })
            if (subtitle != null) {
                addView(TextView(ctx).apply {
                    text = subtitle; textSize = 12f
                    setTextColor(Color.parseColor("#888892"))
                    setPadding(0, dp(2), 0, 0)
                })
            }
            setOnClickListener { onClick() }
        }
    }

    private fun videoCheckRow(title: String, subtitle: String?, checked: Boolean, onToggle: (Boolean) -> Unit): View {
        val ctx = this
        val textCol = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(ctx).apply { text = title; textSize = 16f; setTextColor(Color.WHITE) })
            if (subtitle != null) {
                addView(TextView(ctx).apply {
                    text = subtitle; textSize = 12f
                    setTextColor(Color.parseColor("#888892"))
                    setPadding(0, dp(2), 0, 0)
                })
            }
        }
        val box = CheckBox(ctx).apply { isChecked = checked }
        box.setOnCheckedChangeListener { _, isChecked -> onToggle(isChecked) }
        return LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(14), dp(20), dp(14))
            isClickable = true; isFocusable = true
            setOnClickListener { box.isChecked = !box.isChecked }
            addView(textCol, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(box)
        }
    }

    private fun videoDivider(): View = View(this).apply {
        setBackgroundColor(Color.parseColor("#22FFFFFF"))
    }

    private fun roundedDialogBackground(): GradientDrawable = GradientDrawable().apply {
        cornerRadius = dp(14).toFloat()
        setColor(Color.parseColor("#FF2E2E33"))
    }

    // ── Video ────────────────────────────────────────────────────────────
    //
    // FEATURE (this pass): rebuilt to match a reference screenshot's plain
    // list layout (title + optional gray subtitle per row, checkboxes on
    // the boolean ones, thin dividers) instead of the previous single form
    // with everything crammed into one Save/Cancel dialog. "Screen size"
    // and "Screen orientation" now each open their own follow-on screen
    // rather than showing inline controls here — showScreenOrientationDialog()
    // and showMaxFrameSkipsDialog() below.
    //
    // "Enable OpenGL" and "GLSL Shader" from that same reference screenshot
    // are deliberately NOT here. This app's renderer has only ever been a
    // Canvas/SurfaceView pipeline (see updateGameMatrix()/renderFrame()) —
    // there's no OpenGL rendering path to switch to at all, let alone a
    // shader system to plug GLSL into. A checkbox that doesn't actually
    // change anything is worse than no checkbox — building the real thing
    // (an EGL/GLSurfaceView pipeline alongside or replacing the current
    // one) would be a genuinely large, separate undertaking, not something
    // to fake here alongside everything else this pass. "Linear filtering"
    // doesn't need OpenGL to be real, so it's included and fully wired
    // (see gamePaint/updateLinearFilterPaint() above) — just not gated
    // behind an OpenGL toggle that doesn't exist.
    private fun showVideoSettings() {
        val ctx = this
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        var dialog: AlertDialog? = null
        val layout = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }

        layout.addView(videoCheckRow(
            "Stretch to fit screen",
            "Always stretch to fill the game area in landscape mode",
            stretchToFit
        ) { isChecked ->
            stretchToFit = isChecked
            prefs.edit().putBoolean(PREF_STRETCH, isChecked).apply()
            if (running) updateGameMatrix(lastSw, lastSh)
        })
        layout.addView(videoDivider())

        // FEATURE: used to open a 35/44/52/65% picker here, then (last
        // pass) just a navigation fix into the editor with nothing
        // resizable to do once there. This pass: the game screen is a
        // real drag-and-resize participant in that editor now, same as
        // any button — see gameScreenRect/resolvedRect("gamescreen", ...)
        // in updateGameMatrix(). Opening the editor is enough; nothing
        // more specific to navigate to.
        //
        // FIX (this pass): reported as not actually appearing until
        // Settings was closed first. dialog?.dismiss() only ever closed
        // this Video popup — settingsMenuOverlay (the Settings screen
        // *underneath* it, a separate full-screen opaque overlay) was
        // never touched, so it stayed covering the editor that had, in
        // fact, already started underneath it the whole time. Both need
        // to close for the editor to actually become visible/usable.
        layout.addView(videoListRow("Screen size", "Drag and resize the game screen directly") {
            dialog?.dismiss()
            settingsMenuOverlay.visibility = View.GONE
            enterEditMode()
        })
        layout.addView(videoDivider())

        layout.addView(videoListRow("Screen orientation", null) {
            showScreenOrientationDialog()
        })
        layout.addView(videoDivider())

        layout.addView(videoListRow("Max frame skips", "Maximum number of consecutive frame skips") {
            showMaxFrameSkipsDialog()
        })
        layout.addView(videoDivider())

        layout.addView(videoCheckRow(
            "Linear filtering",
            "Smooths the upscaled image instead of showing crisp pixels",
            linearFilterEnabled
        ) { isChecked ->
            linearFilterEnabled = isChecked
            prefs.edit().putBoolean(PREF_LINEAR_FILTER, isChecked).apply()
            updateLinearFilterPaint()
        })

        dialog = AlertDialog.Builder(ctx)
            .setTitle("🖥  Video")
            .setView(ScrollView(ctx).also { it.addView(layout) })
            .setNegativeButton("Close", null)
            .create()
        dialog.window?.setBackgroundDrawable(roundedDialogBackground())
        dialog.show()
    }

    /** Standalone orientation picker — a reference screenshot's own popup
     *  style (title + single-choice list + Cancel only, no separate
     *  Save/OK) rather than the inline radio group this used to be part
     *  of inside showVideoSettings(). Applies immediately on tap, same as
     *  that reference's own behavior reads: there's no reason to make
     *  someone confirm a second time for a single choice like this one. */
    private fun showScreenOrientationDialog() {
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val options = listOf(
            "Auto rotate"       to ORIENTATION_AUTO,
            "Landscape"         to ORIENTATION_LANDSCAPE,
            "Reverse landscape" to ORIENTATION_REVERSE_LANDSCAPE,
            "Portrait"          to ORIENTATION_PORTRAIT,
            "System default"    to ORIENTATION_SYSTEM
        )
        val curIdx = options.indexOfFirst { it.second == screenOrientationChoice }.takeIf { it >= 0 } ?: 1
        val dialog = AlertDialog.Builder(this)
            .setTitle("Screen orientation")
            .setSingleChoiceItems(options.map { it.first }.toTypedArray(), curIdx) { d, which ->
                val newOrientation = options[which].second
                screenOrientationChoice = newOrientation
                prefs.edit().putInt(PREF_ORIENTATION, newOrientation).apply()
                applyScreenOrientationPref()
                d.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .create()
        dialog.window?.setBackgroundDrawable(roundedDialogBackground())
        dialog.show()
    }

    /** Max frame skips picker — a reference screenshot's own slider-dialog
     *  style (title + centered number readout + slider + Cancel/OK).
     *  0 keeps every frame (default, previous behavior); 1–10 lets the
     *  game loop skip up to that many consecutive blits while genuinely
     *  behind — see maybeSkipRenderThisFrame's logic inline in
     *  startGameLoop(). */
    private fun showMaxFrameSkipsDialog() {
        val ctx = this
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val layout = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(4), dp(24), dp(0))
        }
        val valueText = TextView(ctx).apply {
            text = maxFrameSkips.toString()
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        layout.addView(valueText)
        val seek = SeekBar(ctx).apply {
            max = 10
            progress = maxFrameSkips
        }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, value: Int, fromUser: Boolean) { valueText.text = value.toString() }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })
        layout.addView(seek)

        val dialog = AlertDialog.Builder(ctx)
            .setTitle("Max frame skips")
            .setView(layout)
            .setPositiveButton("OK") { _, _ ->
                maxFrameSkips = seek.progress
                prefs.edit().putInt(PREF_MAX_SKIPS, maxFrameSkips).apply()
            }
            .setNegativeButton("Cancel", null)
            .create()
        dialog.window?.setBackgroundDrawable(roundedDialogBackground())
        dialog.show()
    }

    // ── Audio ────────────────────────────────────────────────────────────

    private fun showAudioSettings() {
        val ctx = this
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val layout = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(56, 28, 56, 20)
        }

        // Button click sound — system FX_KEYPRESS_STANDARD effect, fired
        // only on the rising edge of a press (see updateGameKeys()).
        val soundCheck = CheckBox(ctx).apply {
            text      = "🔊 Button click sound"
            isChecked = buttonSoundEnabled
            setTextColor(Color.WHITE)
            textSize  = 13f
        }
        layout.addView(soundCheck)
        layout.addView(TextView(ctx).apply {
            text = "Plays the system key-press effect on every button press."
            textSize = 10f
            setTextColor(Color.parseColor("#888888"))
            setPadding(0, 4, 0, 0)
        })

        AlertDialog.Builder(ctx)
            .setTitle("🔊  Audio")
            .setView(layout)
            .setPositiveButton("Save") { _, _ ->
                buttonSoundEnabled = soundCheck.isChecked
                prefs.edit().putBoolean(PREF_BTN_SOUND, buttonSoundEnabled).apply()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ── Input ────────────────────────────────────────────────────────────

    private fun showInputSettings() {
        val ctx = this
        val layout = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(56, 28, 56, 20)
            addView(TextView(ctx).apply {
                text = "Drag any button to move it, or drag its corner handle to resize — live, over the running game."
                textSize = 12f; setTextColor(Color.WHITE)
            })
        }

        // Turbo A/B checkbox removed this pass — "⚡ Turbo A / Turbo B
        // buttons" used to live here, adding/removing both red rapid-fire
        // satellites together with no way to get just one. Now individually
        // reachable through "+ Add control" below instead (they're in
        // extraControlIds, same as every other opt-in extra), on request.

        // FEATURE #2: My Boy!-style per-button layout editor entry point.
        // Dismisses both this dialog and the settings menu behind it, then
        // opens the live drag/resize editor over the running game (see
        // enterEditMode()).
        val editLayoutBtn = Button(ctx).apply {
            text = "🖊  Edit Button Layout…"
            setPadding(0, 16, 0, 0)
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#553A3A4A"))
        }
        layout.addView(editLayoutBtn)

        val dlg = AlertDialog.Builder(ctx)
            .setTitle("🕹  Input")
            .setView(layout)
            .setNegativeButton("Close", null)
            .show()
        editLayoutBtn.setOnClickListener {
            dlg.dismiss()
            settingsMenuOverlay.visibility = View.GONE
            enterEditMode()
        }
    }

    // ── Layouts ──────────────────────────────────────────────────────────

    private fun showLayoutsSettings() {
        val ctx = this
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val layout = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(56, 28, 56, 20)
        }

        layout.addView(TextView(ctx).apply {
            text = "Button size"; textSize = 12f; setTextColor(Color.WHITE)
        })
        val sizeOptions = listOf("Small" to 0.75f, "Normal" to 1.0f, "Large" to 1.25f)
        val sizeRadio   = dlgRadioGroup()
        sizeOptions.forEach { (label, _) -> sizeRadio.dlgAddOpt(label) }
        val curSizeIdx = sizeOptions.indexOfFirst { abs(it.second - buttonScaleMultiplier) < 0.05f }
            .takeIf { it >= 0 } ?: 1
        (sizeRadio.getChildAt(curSizeIdx) as RadioButton).isChecked = true
        layout.addView(sizeRadio)

        layout.addView(TextView(ctx).apply {
            text = "Button opacity"; textSize = 12f; setTextColor(Color.WHITE)
            setPadding(0, 16, 0, 0)
        })
        val alphaOptions = listOf("Low" to 90, "Normal" to 160, "High" to 220)
        val alphaRadio   = dlgRadioGroup()
        alphaOptions.forEach { (label, _) -> alphaRadio.dlgAddOpt(label) }
        val curAlphaIdx = alphaOptions.indexOfFirst { abs(it.second - buttonBaseAlpha) < 40 }
            .takeIf { it >= 0 } ?: 1
        (alphaRadio.getChildAt(curAlphaIdx) as RadioButton).isChecked = true
        layout.addView(alphaRadio)

        AlertDialog.Builder(ctx)
            .setTitle("▦  Layouts")
            .setView(ScrollView(ctx).also { it.addView(layout) })
            .setPositiveButton("Save") { _, _ ->
                val selSizeIdx = (0 until sizeRadio.childCount)
                    .firstOrNull { (sizeRadio.getChildAt(it) as RadioButton).isChecked } ?: curSizeIdx
                val newScale = sizeOptions[selSizeIdx].second

                val selAlphaIdx = (0 until alphaRadio.childCount)
                    .firstOrNull { (alphaRadio.getChildAt(it) as RadioButton).isChecked } ?: curAlphaIdx
                val newAlpha = alphaOptions[selAlphaIdx].second

                val needsRelayout = newScale != buttonScaleMultiplier
                buttonScaleMultiplier = newScale
                buttonBaseAlpha       = newAlpha

                prefs.edit()
                    .putFloat(PREF_BTN_SCALE, newScale)
                    .putInt(PREF_BTN_ALPHA,   newAlpha)
                    .apply()

                if (needsRelayout) applyLayoutSettings()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ── Misc ─────────────────────────────────────────────────────────────

    private fun showMiscSettings() {
        val ctx = this
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val layout = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(56, 28, 56, 20)
        }

        layout.addView(TextView(ctx).apply {
            text = "Fast-forward speed (0.5 – 16×)\nTap » on screen to activate"
            textSize = 12f; setTextColor(Color.WHITE)
        })
        val ffEdit = EditText(ctx).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText(formatSpeed(fastForwardSpeed))
            hint = "e.g. 2, 4, 4.5"
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            setPadding(8, 8, 8, 8)
        }
        layout.addView(ffEdit)

        val fpsCheck = CheckBox(ctx).apply {
            text = "Show performance overlay (FPS / audio underruns)"
            isChecked = showFpsOverlay
            setTextColor(Color.WHITE)
            setPadding(0, 24, 0, 0)
        }
        layout.addView(fpsCheck)

        AlertDialog.Builder(ctx)
            .setTitle("👤  Misc")
            .setView(layout)
            .setPositiveButton("Save") { _, _ ->
                val ffVal = ffEdit.text.toString().toFloatOrNull()
                if (ffVal != null) {
                    when {
                        ffVal < 0.5f || ffVal > 16f -> uiToast("Speed must be 0.5 – 16")
                        else -> {
                            fastForwardSpeed = ffVal
                            prefs.edit().putFloat(PREF_FF_SPEED, fastForwardSpeed).apply()
                        }
                    }
                }
                showFpsOverlay = fpsCheck.isChecked
                prefs.edit().putBoolean(PREF_SHOW_FPS, showFpsOverlay).apply()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ── Storage ──────────────────────────────────────────────────────────
    // FEATURE: new. See the block comment above dataFolderTree() (right
    // before batterySaveFile/stateSlotFile/etc.) for the full reasoning —
    // this is just the settings screen that lets someone actually pick a
    // folder, or go back to the app-internal default.

    private fun showStorageSettings() {
        val ctx = this
        lateinit var statusText: TextView
        lateinit var chooseBtn: Button
        lateinit var resetBtn: Button

        fun currentFolderLabel(): String {
            val tree = dataFolderTree()
            return if (tree != null) (tree.name ?: "(chosen folder)") else "App-internal storage (default)"
        }

        fun refresh() {
            val tree = dataFolderTree()
            statusText.text = "Current folder: ${currentFolderLabel()}\n\n" +
                "Holds three subfolders — save, cheat, screenshot — for battery " +
                "saves, save-states and their thumbnails, the (future) cheat " +
                "file feature, and screenshots. Visible in any file manager, " +
                "not tucked away under Android/data.\n\n" +
                "Switching folders does NOT move anything already saved — " +
                "only saves/states/screenshots made after switching go to the " +
                "new location. Nothing already there is deleted either; it's " +
                "just not used anymore until you switch back."
            resetBtn.visibility = if (tree != null) View.VISIBLE else View.GONE
        }

        val layout = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(56, 28, 56, 20)
            statusText = TextView(ctx).apply { textSize = 12f; setTextColor(Color.WHITE) }
            addView(statusText)
            chooseBtn = Button(ctx).apply {
                text = "📁  Choose folder"
                setPadding(0, 16, 0, 0)
                setTextColor(Color.WHITE)
                setBackgroundColor(Color.parseColor("#553A3A4A"))
            }
            addView(chooseBtn)
            resetBtn = Button(ctx).apply {
                text = "↺  Use app-internal storage instead"
                setPadding(0, 16, 0, 0)
                setTextColor(Color.WHITE)
                setBackgroundColor(Color.parseColor("#553A3A4A"))
            }
            addView(resetBtn)
        }
        refresh()

        AlertDialog.Builder(ctx)
            .setTitle("💾  Storage")
            .setView(layout)
            .setNegativeButton("Close", null)
            .setOnDismissListener { refreshStorageSettingsUi = null }
            .show()
        refreshStorageSettingsUi = { refresh() }

        chooseBtn.setOnClickListener {
            // OpenDocumentTree's launch() takes an optional initial-location
            // Uri, not an Intent — read+write permission for whatever the
            // user picks comes back on the result URI automatically (that's
            // the whole point of a tree pick); dataFolderPicker's own
            // callback above is what persists it via
            // takePersistableUriPermission() so it survives app restarts.
            dataFolderPicker.launch(null)
        }
        resetBtn.setOnClickListener {
            AlertDialog.Builder(ctx)
                .setTitle("Use app-internal storage?")
                .setMessage("New saves/states/screenshots go back to this app's own storage. Nothing in the chosen folder is deleted.")
                .setPositiveButton("Switch back") { _, _ ->
                    getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove(PREF_DATA_FOLDER_URI).apply()
                    uiToast("Back to app-internal storage")
                    refresh()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    // ── Advanced ─────────────────────────────────────────────────────────

    private fun showAdvancedSettings() {
        val ctx = this
        val layout = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(56, 28, 56, 20)
            addView(TextView(ctx).apply {
                text = "Resets game screen size, fullscreen, button size/opacity, click sound, and fast-forward speed back to their defaults.\n\nThis does NOT clear custom button positions — reset those from Input → Edit Button Layout instead."
                textSize = 12f; setTextColor(Color.WHITE)
            })
        }
        val resetBtn = Button(ctx).apply {
            text = "↺  Reset settings to defaults"
            setPadding(0, 16, 0, 0)
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#553A3A4A"))
        }
        layout.addView(resetBtn)

        val dlg = AlertDialog.Builder(ctx)
            .setTitle("🎚  Advanced")
            .setView(layout)
            .setNegativeButton("Close", null)
            .show()

        resetBtn.setOnClickListener {
            AlertDialog.Builder(ctx)
                .setTitle("Reset settings?")
                .setMessage("This resets Video/Audio/Layouts/Misc settings to defaults.")
                .setPositiveButton("Reset") { _, _ ->
                    fastForwardSpeed      = 2.0f
                    buttonScaleMultiplier = 1.0f
                    buttonBaseAlpha       = 160
                    gameScreenFraction    = GAME_FRAC_NORM
                    // FIX: stretchToFit/maxFrameSkips/linearFilterEnabled
                    // (all added two passes ago) were missing from this
                    // reset entirely — a gap from when they were added,
                    // not something this pass changed on purpose. Included
                    // now, alongside removing fullscreenMode, which no
                    // longer exists at all (see the field comment where
                    // gameScreenRect is declared).
                    stretchToFit          = false
                    maxFrameSkips         = 0
                    linearFilterEnabled   = false
                    buttonSoundEnabled    = false
                    showFpsOverlay        = false
                    updateLinearFilterPaint()
                    getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                        .putFloat(PREF_FF_SPEED, fastForwardSpeed)
                        .putFloat(PREF_BTN_SCALE, buttonScaleMultiplier)
                        .putInt(PREF_BTN_ALPHA, buttonBaseAlpha)
                        .putFloat(PREF_SCREEN_FRAC, gameScreenFraction)
                        .putBoolean(PREF_STRETCH, stretchToFit)
                        .putInt(PREF_MAX_SKIPS, maxFrameSkips)
                        .putBoolean(PREF_LINEAR_FILTER, linearFilterEnabled)
                        .putBoolean(PREF_BTN_SOUND, buttonSoundEnabled)
                        .putBoolean(PREF_SHOW_FPS, showFpsOverlay)
                        .apply()
                    applyLayoutSettings()
                    uiToast("Settings reset to defaults")
                    dlg.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    // ── About ────────────────────────────────────────────────────────────

    private fun showAboutDialog() {
        val ctx = this
        val versionName = try {
            packageManager.getPackageInfo(packageName, 0).versionName ?: "—"
        } catch (e: PackageManager.NameNotFoundException) { "—" }

        val layout = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(56, 28, 56, 20)
            addView(TextView(ctx).apply {
                text = getString(R.string.app_name); textSize = 18f; typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.WHITE)
            })
            addView(TextView(ctx).apply {
                text = "Version $versionName"
                textSize = 12f; setTextColor(Color.parseColor("#AAAAAA"))
                setPadding(0, 6, 0, 16)
            })
            addView(TextView(ctx).apply {
                text = "A custom Android build wrapping the mGBA core via JNI."
                textSize = 12f; setTextColor(Color.WHITE)
            })
        }

        AlertDialog.Builder(ctx)
            .setTitle("ℹ️  About")
            .setView(layout)
            .setPositiveButton("OK", null)
            .show()
    }

    /**
    /**
     * Rebuild control layout and game matrix after settings change.
     * Called on main thread; game thread picks up changes on next frame.
     * FIX: the explicit updateGameMatrix() call this used to make right
     * after buildControlLayout() is gone — buildControlLayout() calls it
     * internally now (see the note at its own end), so this was calling
     * it twice for no benefit.
     */
    private fun applyLayoutSettings() {
        val holder = surfaceHolder ?: return
        val sw = holder.surfaceFrame.width().toFloat()
        val sh = holder.surfaceFrame.height().toFloat()
        if (sw > 0f && sh > 0f) buildControlLayout(sw, sh)
    }

    // ── Save states ──────────────────────────────────────────────────────
    // Independent of the automatic battery save (see romPicker/nativeLoadROM)
    // — that persists whatever the *game itself* lets you save; these are
    // full emulator snapshots that let you resume from any exact moment,
    // GBA-hardware-save-menu or not. SAVE_STATE_SLOTS per-ROM slots, each a
    // plain file under statesDir(), named/keyed by currentRomBaseName so
    // switching ROMs never shows another game's slots.

    private fun showSaveStateMenu() {
        if (!romLoaded) { uiToast("Load a ROM first"); return }
        AlertDialog.Builder(this)
            .setTitle("💾  Save States")
            .setItems(arrayOf("Save State", "Load State")) { _, which ->
                showSaveStateSlotDialog(forSave = which == 0)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ── Save-state thumbnails ────────────────────────────────────────────
    // FEATURE: new. Reuses takeScreenshot()'s exact technique (PixelCopy off
    // the live SurfaceView) rather than adding any new native/JNI surface —
    // this project's own history shows hand-written JNI exports are exactly
    // where build-vs-sandbox mismatches turn up (see FIX 8 in mgba_jni.c),
    // so avoiding a new one here entirely sidesteps that risk. The one
    // difference from takeScreenshot(): this runs on the state-save
    // background thread (see showSaveStateSlotDialog) rather than the UI
    // thread, and PixelCopy.request() only takes a Handler for where its
    // *result callback* lands, not for which thread it may be called from —
    // so a CountDownLatch turns that callback back into a plain blocking
    // call, keeping the save flow linear instead of splitting it across two
    // independent async paths.
    private fun captureStateThumbnail(slot: Int) {
        try {
            val w = surfaceView.width
            val h = surfaceView.height
            if (w <= 0 || h <= 0) return
            val full = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val latch = CountDownLatch(1)
            var ok = false
            PixelCopy.request(surfaceView, full, { result ->
                ok = (result == PixelCopy.SUCCESS)
                latch.countDown()
            }, Handler(Looper.getMainLooper()))
            latch.await(500, TimeUnit.MILLISECONDS)
            if (!ok) return
            // Derive height from the surface's own current aspect ratio
            // instead of hardcoding one — see STATE_THUMB_WIDTH_PX's comment.
            val thumbH = (STATE_THUMB_WIDTH_PX.toLong() * h / w).toInt().coerceAtLeast(1)
            val thumb = Bitmap.createScaledBitmap(full, STATE_THUMB_WIDTH_PX, thumbH, true)
            stateThumbEntry(slot).outputStream().use { out -> thumb.compress(Bitmap.CompressFormat.PNG, 90, out) }
        } catch (e: Exception) {
            // Best-effort, same spirit as backupIfExists(): a thumbnail
            // failure must never be surfaced as a save failure.
            Log.w(TAG, "State thumbnail capture failed (save itself is unaffected)", e)
        }
    }

    /**
     *  Row view for showSaveStateSlotDialog()'s ListView.
     *
     *  FIX (Eleventh pass) applies here too, deliberately: do NOT set
     *  isClickable/isFocusable on this row or on either child, and do not
     *  give the row its own setOnClickListener. This is a ListView item
     *  inside an AlertDialog exactly like gameMenuRow() — see that
     *  function's comment and BUGS_FIXED.md's Eleventh-pass entry for the
     *  full explanation of why that combination silently eats every tap.
     *  Clicks here are meant to reach the ListView's own OnItemClickListener
     *  (the `{ _, which -> ... }` lambda passed to setAdapter() below) and
     *  nothing else.
     */
    private fun stateSlotRow(): LinearLayout {
        val ripple = TypedValue()
        theme.resolveAttribute(android.R.attr.selectableItemBackground, ripple, true)
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(24), dp(14), dp(24), dp(14))
            setBackgroundResource(ripple.resourceId)
            addView(ImageView(this@MainActivity).apply {
                layoutParams = LinearLayout.LayoutParams(dp(96), dp(64))
                scaleType = ImageView.ScaleType.CENTER_CROP
                setBackgroundColor(Color.parseColor("#2A2A2A"))
            })
            addView(TextView(this@MainActivity).apply {
                layoutParams = LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f
                ).apply { marginStart = dp(24) }
                textSize = 16f
                setTextColor(Color.WHITE)
            })
        }
    }

    /** Row data for showSaveStateSlotDialog()'s ListView — hoisted out of
     *  that function (it used to be a local `data class`) so slotInfoCache
     *  below can hold instances of it between calls. */
    private data class SlotInfo(val slot: Int, val entry: SaveEntry, val exists: Boolean, val modified: Long, val label: String, val thumb: Bitmap?)

    /** FIX (menu-slot speed pass): cache of each slot's already-decoded
     *  SlotInfo, keyed by "$currentRomBaseName:$slot" (the ROM name is
     *  part of the key since slot *numbers* repeat across ROMs but refer
     *  to different underlying files). showSaveStateSlotDialog() below
     *  re-decodes a slot's thumbnail from disk only when that slot's
     *  exists/modified no longer match what's cached — i.e. only when the
     *  data's actually stale, typically right after a save to that same
     *  slot. Before this, opening the dialog re-read and re-decoded every
     *  slot's PNG from disk on *every single open*, even when nothing had
     *  changed since the last time you looked — most of what made
     *  "menu tap -> slot list appearing" feel slow on repeat opens.
     *  ConcurrentHashMap since a fast reopen could plausibly start a
     *  second listing thread before the first one's finished. */
    private val slotInfoCache = java.util.concurrent.ConcurrentHashMap<String, SlotInfo>()

    private fun showSaveStateSlotDialog(forSave: Boolean) {
        Thread {
            // One folder resolution + one listing, reused for every slot
            // and every thumbnail below — instead of SaveEntry.doc()
            // re-resolving and re-listing this same folder from scratch
            // for each of the ~12 lookups this dialog used to make.
            val folderRoot = dataSubfolder("save")
            val docsByName: Map<String, DocumentFile>? =
                folderRoot?.listFiles()?.mapNotNull { d -> d.name?.let { it to d } }?.toMap()

            val slots = (1..SAVE_STATE_SLOTS).map { slot ->
                val entry = stateSlotEntry(slot)
                val exists: Boolean
                val modified: Long
                if (docsByName != null) {
                    val stateDoc = docsByName[stateSlotFile(slot).name]
                    exists = stateDoc != null
                    modified = stateDoc?.lastModified() ?: 0L
                } else {
                    // No Storage folder configured — plain internal-storage
                    // File calls, same as before this fix, just now off
                    // the UI thread too for consistency.
                    exists = entry.exists()
                    modified = entry.lastModified()
                }

                val cacheKey = "$currentRomBaseName:$slot"
                val cached = slotInfoCache[cacheKey]
                if (cached != null && cached.exists == exists && cached.modified == modified) {
                    // Cache hit — nothing about this slot has changed since
                    // the last time we decoded it, so skip the disk read
                    // and PNG decode entirely.
                    cached
                } else {
                    val thumbStream: InputStream? = if (docsByName != null) {
                        docsByName[stateThumbFile(slot).name]?.let {
                            try { contentResolver.openInputStream(it.uri) } catch (e: Exception) { null }
                        }
                    } else {
                        stateThumbEntry(slot).inputStream()
                    }
                    val label = if (exists) "Slot $slot — ${DateFormat.format("MMM d, h:mm a", modified)}"
                                else         "Slot $slot — Empty"
                    val bmp = try {
                        thumbStream?.use { BitmapFactory.decodeStream(it) }
                    } catch (e: Exception) {
                        Log.w(TAG, "Corrupt state thumbnail for slot $slot", e); null
                    }
                    SlotInfo(slot, entry, exists, modified, label, bmp).also { slotInfoCache[cacheKey] = it }
                }
            }

            Handler(Looper.getMainLooper()).post {
                if (isFinishing || isDestroyed) return@post

                val adapter = object : ArrayAdapter<SlotInfo>(this, 0, slots) {
                    override fun getView(position: Int, recycled: View?, parent: ViewGroup): View {
                        val row = recycled as? LinearLayout ?: stateSlotRow()
                        val info = getItem(position)!!
                        (row.getChildAt(1) as TextView).text = info.label
                        val icon = row.getChildAt(0) as ImageView
                        if (info.thumb != null) icon.setImageBitmap(info.thumb) else icon.setImageDrawable(null)
                        return row
                    }
                }

                AlertDialog.Builder(this)
                    .setTitle(if (forSave) "Save to which slot?" else "Load which slot?")
                    .setAdapter(adapter) { _, index ->
                        val info = slots[index]
                        val slot = info.slot
                        val entry = info.entry
                        // Reuses the exists flag this same background pass
                        // already computed, instead of calling
                        // entry.exists() again here on the UI thread.
                        if (!forSave && !info.exists) {
                            uiToast("Slot $slot is empty"); return@setAdapter
                        }
                        // FIX (audit pass): same guard quickSaveState()/
                        // quickLoadState() already have and for the same
                        // reason — see saveStateBusy's own doc comment.
                        // Picking a slot dismisses this dialog, so hitting
                        // this needs two separate menu visits in quick
                        // succession rather than one fast double-tap, but
                        // the underlying race (two unordered Threads both
                        // calling nativeSaveState()/nativeLoadState()) is
                        // identical.
                        if (!saveStateBusy.compareAndSet(false, true)) {
                            uiToast("Still saving/loading — try again in a moment"); return@setAdapter
                        }
                        // Runs off the UI thread — same pattern as romPicker above —
                        // since this touches disk and briefly holds the native
                        // core's mutex against the running game thread.
                        Thread {
                            try {
                            // FEATURE: auto save backup — nativeSaveState() truncates
                            // this slot's file the instant it's called (VFileOpen
                            // uses O_TRUNC — see mgba_jni.c), so anything already in
                            // it is gone the moment a save starts, even if the write
                            // itself then fails partway through. The thumbnail gets
                            // the same one-level rolling backup, for the same reason.
                            if (forSave) { backupIfExists(entry); backupIfExists(stateThumbEntry(slot)) }
                            val ok = if (forSave) {
                                val localPath = entry.stageForWrite()
                                val saved = EmulatorEngine.nativeSaveState(localPath)
                                if (saved) entry.commitWrite(localPath)
                                saved
                            } else {
                                val localPath = entry.stageForRead()
                                localPath != null && EmulatorEngine.nativeLoadState(localPath)
                            }
                            // FIX (this pass): confirmation now fires right here,
                            // the instant the actual save/load call above
                            // returns, instead of after captureStateThumbnail()
                            // below. Thumbnail capture waits on PixelCopy (up to
                            // 500ms — see its own comment) and then scales/PNG-
                            // encodes a full-screen bitmap, so leaving the toast
                            // after it made every single save feel sluggish even
                            // though the actual state write is already done and
                            // safe on disk by this point. uiToast() posts to the
                            // main thread and returns immediately, so this still
                            // doesn't block the thumbnail capture that follows —
                            // it just no longer waits on it first.
                            uiToast(when {
                                ok && forSave -> "Saved to Slot $slot"
                                ok            -> "Loaded Slot $slot"
                                forSave       -> "Save failed"
                                else          -> "Load failed — slot may be from a different ROM"
                            })
                            // Thumbnail only on a *successful* save — an old
                            // thumbnail surviving a failed save (whose backupIfExists
                            // call above already preserved it under .bak regardless)
                            // is more useful than no thumbnail at all. Runs after
                            // the confirmation above now, so the slot list simply
                            // won't show the new thumbnail until it's next opened,
                            // rather than the save itself feeling delayed.
                            if (ok && forSave) captureStateThumbnail(slot)
                            } finally {
                                // FIX (audit pass): mirrors quickSaveState()/
                                // quickLoadState()'s finally block — always
                                // clears the guard, success or failure, so a
                                // save/load that throws can't leave every
                                // future attempt permanently blocked.
                                saveStateBusy.set(false)
                            }
                        }.apply { name = "mGBA-state" }.start()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
        }.apply { name = "mGBA-slot-list" }.start()
    }

    // ── Link cable UI ──────────────────────────────────────────────────────
    // Split into two Settings rows — "Link remote" (Wi-Fi) and "Link local"
    // (Bluetooth) — instead of one combined dialog behind the old floating
    // 🔗 button (see buildSettingsMenu()). Nothing about the connect logic
    // itself changed, just how it's reached. Status used to also update
    // that floating button's label; now it's toasts only, plus the existing
    // ⬤ LINK canvas overlay (drawLinkStatus, below) for "still connected".

    private fun showLinkRemoteDialog() {
        if (link.isConnected) { showLinkDisconnectDialog(); return }
        AlertDialog.Builder(this).setTitle("Link Remote — Wi-Fi")
            .setItems(arrayOf("Host", "Join")) { _, i ->
                when (i) {
                    0 -> link.startWifiHost(
                        onReady     = { ip -> uiToast("Waiting…\nIP: $ip") },
                        onConnected = { onLinkConnected(true,  "Wi-Fi") },
                        onError     = { uiToast("Host error: $it") })
                    1 -> {
                        uiToast("Scanning…")
                        link.discoverWifiHosts(
                            onFound = { hosts ->
                                if (hosts.isEmpty()) showIpDialog()
                                else AlertDialog.Builder(this)
                                    .setTitle("Select host")
                                    .setItems(hosts.toTypedArray()) { _, j -> joinWifi(hosts[j]) }
                                    .setNegativeButton("Enter IP") { _, _ -> showIpDialog() }.show()
                            },
                            onError = { showIpDialog() })
                    }
                }
            }.show()
    }

    private fun showLinkLocalDialog() {
        if (link.isConnected) { showLinkDisconnectDialog(); return }
        AlertDialog.Builder(this).setTitle("Link Local — Bluetooth")
            .setItems(arrayOf("Host", "Join")) { _, i ->
                when (i) {
                    // FIX: BLUETOOTH_CONNECT is a runtime-dangerous permission on API 31+.
                    // It was declared in the manifest but never requested, so tapping either
                    // of these two options crashed the app on Android 12+ with an uncaught
                    // SecurityException from listenUsingInsecureRfcommWithServiceRecord() /
                    // createInsecureRfcommSocketToServiceRecord() / getBondedDevices().
                    0 -> ensureBluetoothPermission {
                        uiToast("Starting host…")
                        link.startBluetoothHost(
                            onConnected = { onLinkConnected(true,  "Bluetooth") },
                            onError     = { uiToast("BT error: $it") })
                    }
                    1 -> ensureBluetoothPermission {
                        val devs = link.getBondedDevices()
                        if (devs.isEmpty()) { uiToast("No paired devices"); return@ensureBluetoothPermission }
                        AlertDialog.Builder(this).setTitle("Choose device")
                            .setItems(devs.map { it.name ?: it.address }.toTypedArray()) { _, j ->
                                uiToast("Connecting…")
                                link.connectBluetooth(devs[j],
                                    onConnected = { onLinkConnected(false, "Bluetooth") },
                                    onError     = { uiToast("BT error: $it") })
                            }.show()
                    }
                }
            }.show()
    }

    private fun showLinkDisconnectDialog() {
        AlertDialog.Builder(this).setTitle("Link Connected ✓")
            .setItems(arrayOf("Disconnect")) { _, _ -> stopLink() }.show()
    }

    private fun showIpDialog() {
        val et = EditText(this).apply { hint = "192.168.x.x" }
        AlertDialog.Builder(this).setTitle("Host IP").setView(et)
            .setPositiveButton("Connect") { _, _ -> joinWifi(et.text.toString().trim()) }.show()
    }

    private fun joinWifi(ip: String) {
        if (ip.isBlank()) return
        uiToast("Connecting…")
        link.connectWifi(ip,
            onConnected = { onLinkConnected(false, "Wi-Fi") },
            onError     = { uiToast("Connect error: $it") })
    }

    private fun onLinkConnected(isHost: Boolean, via: String) {
        val ok = EmulatorEngine.nativeLinkStart(link, isHost)
        uiToast("Link via $via${if (!ok) " (SIO error)" else ""}")
    }

    private fun stopLink() {
        EmulatorEngine.nativeLinkStop(); link.disconnect()
        uiToast("Disconnected")
    }

    // ── Link status overlay ────────────────────────────────────────────────

    private val linkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#CC22BB77"); textSize = 26f
    }
    private fun drawLinkStatus(canvas: Canvas) =
        canvas.drawText("⬤ LINK", 14f, canvas.height - 14f, linkPaint)

    // ── Performance overlay (FEATURE — see the field comments above) ───────

    private val fpsPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#CCFFFFFF"); textSize = 24f; textAlign = Paint.Align.RIGHT
    }
    private fun drawFpsOverlay(canvas: Canvas) =
        canvas.drawText(fpsOverlayText, canvas.width - 14f, 32f, fpsPaint)

    // ── Helpers ────────────────────────────────────────────────────────────

    // uiToast() moved to SharedUi.kt this pass as an Activity extension —
    // RomBrowserActivity needs it too for permission-flow messages.

    @Suppress("DEPRECATION")
    private fun setImmersive() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
    }
}
