# Known Limitations

No compiler, Android SDK, or physical device is available in this
sandbox for any pass of this project. Every fix is checked by hand-
tracing against documented Android/Kotlin/Compose API behavior, XML
validation, and static balance/reference checks - real, but not a
substitute for an actual build and a real WiFi Direct exchange between
two phones. This file is where that gap is spelled out per-topic,
rather than left as a blanket disclaimer.

## 1.0.6 has never been compiled

Most files in the project changed in 1.0.6 - every screen, the session manager, the
WiFi Direct manager, the transfer session and the resources. Unlike earlier passes
there was no build log from the previous version to work from, so the first CI build is
the real test. A script checked brace balance, unresolved resources, unresolved project
imports and string format arguments across all 37 Kotlin files, and every XML resource
was validated - but Kotlin type errors, overload ambiguities and Compose API
mismatches can't be found that way. If the build fails, the compiler output points
straight at the line; that is far faster than another read-through.

The UI has likewise never been rendered. Layout is written against standard Material 3
components, but spacing on small or very narrow screens, and how the gradients look on
a particular panel, need a look on the actual phone. The vector icons and the launcher
icon *were* rendered offline to check their shapes.

## WiFi Direct

- **`thisDevice` (own QR code) on API 26-28.** The fix in BUGS_FIXED.md
  #2 adds an active `requestDeviceInfo()` query, but that API only
  exists from API 29 onward. On API 26-28 specifically, populating the
  Receive screen's QR code still depends entirely on
  `WIFI_P2P_THIS_DEVICE_CHANGED_ACTION` firing, which is the same
  broadcast-only behavior that caused the original bug. Given how rare
  Android 8.0/8.1 devices are at this point, this is an accepted gap
  rather than one worth more code to close - but it's a real, known one,
  not silently assumed fixed everywhere.
- **The pairing path was rewritten in 1.0.6.** QR scanning no longer connects to an
  address read from the code; it matches the code's device name against what discovery
  found and connects to that. The earlier "busy after a QR scan" fixes (1.0.4, 1.0.5)
  were against code that has since been replaced, so they no longer apply as written.
  If BUSY still shows up, `WifiDirectManager` now retries it on its own and only
  reports it after several attempts - a logcat capture (`WifiP2pService` tag) around
  that moment would be worth more than another read of the source.
- **QR matching is by device name.** Two phones with identical WiFi Direct names
  (e.g. both "Android_ab12", which is vanishingly unlikely but not impossible) could
  match the wrong one. The name is the phone's *WiFi Direct* name, which on Android 10
  and 11 is often "Android_xxxx" rather than the name in Settings - the Receive screen
  shows the name that is actually encoded.
- **Two prompts on the receiving phone.** Android itself shows a WiFi Direct invitation
  on the receiver, and BeamShare then asks again. The first can't be suppressed without
  creating the group from the receiver and having the sender join with credentials,
  which is a different (and, on some phones, less reliable) pairing design. The second
  is deliberate: it's the app-level approval.
- **Location must be on for Android 12 and older.** Detected and explained in the app,
  but it's an OS rule, so the user still has to switch it on.
- **Two-device testing.** Every fix in this project so far has been
  checked against one device's code path at a time - the actual
  session handshake, offer/accept, and file streaming between two real
  paired phones has never been observed running. The protocol design
  (see `TransferProtocol.kt`'s own doc comment) is reasoned through
  carefully, but "reasoned through" and "watched two phones actually do
  it" are different confidence levels, worth being honest about. 1.0.6 changed
  that path substantially (approval handshake, retrying sockets, chunk-exact
  streaming), so a first real two-phone run is the most valuable next test.

## Sending apps

- **Only the base APK is sent.** Apps installed from app bundles (most Play Store apps)
  also have split APKs; the base alone often won't install. The picker now marks such
  apps "Split APK". Single-APK apps - debug builds, side-loaded and most open-source
  apps - install normally. Supporting splits would mean sending several files per app
  and installing them with `PackageInstaller` sessions on the receiver, which is a
  feature of its own.
- The receiving phone must allow "install unknown apps" for BeamShare; Android prompts
  for this the first time.

## Size optimization

- **ML Kit barcode scanning: bundled, not switched to Play-Services-
  unbundled.** `com.google.mlkit:barcode-scanning` ships its model
  inside the APK; a Play-Services-backed unbundled variant
  (`com.google.android.gms:play-services-mlkit-barcode-scanning`) would
  likely cut a further meaningful chunk of size by downloading that
  model on first use instead. Deliberately not switched this pass: it's
  designed to be close to a drop-in API replacement, but "close to" is
  doing real work in that sentence without a compiler here to confirm
  it, it adds a hard Google-Play-Services dependency (a real constraint
  on some device forks) and a network requirement before the *first*
  scan specifically, and this project has already had two build-log-
  driven fix cycles in a row - better to bank the confirmed,
  zero-behavior-change icon-library win this pass than risk a third
  cycle chasing a second, less certain one. Worth revisiting if more
  size reduction is needed and a real build is available to confirm the
  swap compiles and scans correctly before shipping it.
- **Native-library ABI filtering: available, not applied.** ML Kit's
  bundled model is the one dependency here shipping actual native
  (`.so`) code, for all four Android ABIs (arm64-v8a, armeabi-v7a, x86,
  x86_64) inside the single universal APK, since this project
  deliberately isn't using Gradle's ABI-split output (multiple APKs,
  one per architecture). A *single* universal APK can still restrict
  which ABIs it packages via `ndk.abiFilters` in `build.gradle.kts` -
  e.g. dropping `x86`/`x86_64` (real Android phones are effectively all
  arm64-v8a today; those two exist mainly for emulators) would shrink
  that native payload without producing multiple APK files or touching
  any feature. Not applied this pass since it sits close enough to "ABI
  split" in spirit that it seemed better to surface as a choice than
  fold in silently. Applied instead: resource locale filtering
  (`resourceConfigurations` in `defaultConfig`, restricted to `"en"`),
  which drops other-locale string resources bundled by AndroidX/
  Compose/CameraX/ML Kit - safe regardless of whether ABI filtering
  gets taken later, since this app has no translations of its own to
  lose either way.
- **The hand-authored vector icons are not pixel-identical to Google's
  Material Symbols glyphs** they replace - they're clean, simple geometric
  reconstructions of the same concept. As of 1.0.6 every icon (and the launcher
  icon, under circle and rounded-square masks) was rasterised offline to confirm the
  shapes read correctly, but that renderer isn't Android's, so a glance on a real
  device is still worth it for stroke weight and alignment.

## Foreground service / notification lifecycle

- **`onTaskRemoved()` relies on stock Android behavior.** The 1.0.5 fix
  for the persistent notification is standard, documented `Service`
  API with no OEM-specific assumptions - but several Android OEM skins
  are known to layer extra, non-standard battery-optimization behavior
  around backgrounded or task-removed services on top of stock
  behavior. Nothing about that can be verified from source alone. If
  the notification is ever still seen after 1.0.5, specifically on a
  heavily-customized OEM ROM, that's worth suspecting before another
  read of this code.
- **The service stops when pairing screens leave the back stack.** Since 1.0.6 this is
  driven by `ViewModel.onCleared()` (via `SessionManager.cancelPairing()`), which fires
  when the Discover/Receive entry is popped - not when it merely leaves composition, so
  opening the QR scanner on top of Discover doesn't tear anything down. The service
  itself still just mirrors session state and stops on `Disconnected`.
