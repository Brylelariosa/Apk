# BeamShare

Local WiFi Direct file & app transfer for Android. No internet, no server, no account -
one phone finds the other (peer scan or QR code), and once paired either side can beam
files or installed apps to the other without re-pairing.

## How it works

1. **Send**: pick files and/or installed apps -> find the other phone (device list, or scan
   the receiver's QR code) -> the receiver approves -> your items start sending.
2. **Receive**: shows your QR code and stays discoverable -> Android may ask you to accept a
   WiFi Direct invitation -> BeamShare asks you to approve the sender -> you land on the
   connected hub. Nothing is accepted from the sender before you approve.
3. **Connected hub**: once paired, both phones can send more files/apps at any time - the
   link and the session stay open until someone disconnects.

Before any of that, a readiness check makes sure the nearby-devices permission is granted
and WiFi is on (and Location, on Android 12 and older - the OS only answers WiFi Direct
discovery while it's on). The screen lists whatever is missing, with a button for each.

## Architecture

```
core/
  discovery/   WifiDirectManager      - wraps WifiP2pManager as StateFlow, no Android
                                         callback types leak past this layer
  transfer/    TransferProtocol       - wire format (frame header + raw bytes, no JSON dep),
                                         versioned greeting, READY approval frame
               GroupSocket            - group owner listens (cancellable), client dials with
                                         retry; the TCP socket on top of the P2P link
               TransferSession        - one paired connection: handshake, offer/accept,
                                         exact-length streaming both ways, smoothed speed
               SessionManager         - orchestrates link -> socket -> handshake -> approval
                                         -> connected session, and owns sending; this is
                                         what the UI observes
  qr/          ConnectPayload / QrCodeGenerator - pairing payload codec + QR bitmap (ZXing
                                         core only, no scanning UI dependency)
  apps/        InstalledAppsRepository / ApkInstaller - "send an app" enumeration + receive-
                                         side install intent
  files/       FileRepository         - SAF-picked source resolution, MediaStore-backed
                                         incoming file sink (scoped storage compliant)
di/            ServiceLocator         - manual DI; the dependency graph is small enough
                                         that Hilt's annotation processing wouldn't pay for
                                         itself here
service/       BeamShareService       - thin foreground-service wrapper; owns no transfer
                                         logic itself, just mirrors SessionManager's state
                                         into a notification so the OS doesn't kill the link
ui/            MVVM per feature (home, send, receive, session), Compose + Material 3,
               vector iconography only, a small monospace numeral style reserved for byte/
               speed readouts. components/ holds the shared pieces (cards, radar/link
               animations, transfer rows, the readiness gate); theme/ holds the colour
               system and brand gradient
```

Everything above `ui/` is plain Kotlin + coroutines and doesn't touch Compose, so the
transfer engine is unit-testable independent of the UI.

## Building

This is a ready-to-build Gradle project (Kotlin DSL + version catalog at
`gradle/libs.versions.toml`). Two things to know before wiring it into CI:

- **Gradle wrapper**: `gradlew` / `gradlew.bat` are included. The binary
  `gradle-wrapper.jar` is not (can't author binary bytes here) - either run
  `gradle wrapper` once locally, or let CI fetch just the jar before invoking
  `./gradlew`, e.g.:
  ```bash
  curl -sSL -o gradle/wrapper/gradle-wrapper.jar \
    https://raw.githubusercontent.com/gradle/gradle/v8.6.0/gradle/wrapper/gradle-wrapper.jar
  ```
- **SDK levels**: `compileSdk`/`targetSdk` are set to 35, `minSdk` to 26. Dependency
  versions in the catalog are current as of early 2026 training data - bump them via the
  catalog if your CI has newer SDK platforms installed.

## Permissions

| Permission | Why |
|---|---|
| `NEARBY_WIFI_DEVICES` (13+) / `ACCESS_FINE_LOCATION` (<13) | WiFi Direct peer discovery. Declared `neverForLocation` on 13+ since the app never derives physical location from it. On Android 12 and older the Location *switch* must also be on - the OS requirement, not something the app reads. |
| `CAMERA` | QR code scanning only, requested lazily when you tap "Scan QR". |
| `POST_NOTIFICATIONS`, `FOREGROUND_SERVICE_CONNECTED_DEVICE` | Keeps the transfer session alive if you background the app mid-transfer. |
| `REQUEST_INSTALL_PACKAGES` | Lets a received APK be handed to the system installer. |

No storage permission is requested - incoming files land in `Downloads/BeamShare` via
`MediaStore` on API 29+, or app-specific external storage (shared through `FileProvider`)
on 26-28.

## Known v1 scope boundaries

- Sending an app sends its **base APK only**, not split/config APKs from app-bundle
  installs. Single-APK apps (debug builds, side-loaded and most open-source apps) install
  fine; apps from the Play Store often won't, and the picker marks those "Split APK".
- Each device streams its own outgoing items **one at a time, in order**; simultaneous
  sends in both directions both work, but two files queued from the *same* device won't
  literally interleave their bytes. Everything queued shows up immediately as "Waiting".
- No transfer history persists across sessions by design - the connected hub shows the
  current session only.
