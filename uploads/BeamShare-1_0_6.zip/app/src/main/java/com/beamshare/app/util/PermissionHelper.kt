package com.beamshare.app.util

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.wifi.WifiManager
import android.os.Build
import androidx.core.content.ContextCompat

/** Everything WiFi Direct needs switched on before discovery can work, as one snapshot. */
data class Readiness(
    val wifiDirectSupported: Boolean,
    val permissionGranted: Boolean,
    val wifiEnabled: Boolean,
    val locationEnabled: Boolean
) {
    val isReady: Boolean get() = wifiDirectSupported && permissionGranted && wifiEnabled && locationEnabled
}

object PermissionHelper {

    /** The one runtime permission WiFi Direct discovery/connect needs on this OS version. */
    fun nearbyPermission(): String = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        Manifest.permission.NEARBY_WIFI_DEVICES
    } else {
        Manifest.permission.ACCESS_FINE_LOCATION
    }

    fun hasNearbyPermission(context: Context): Boolean = isGranted(context, nearbyPermission())

    fun hasCameraPermission(context: Context): Boolean = isGranted(context, Manifest.permission.CAMERA)

    /** Null on API levels where notification permission isn't a runtime prompt. */
    fun notificationPermissionOrNull(): String? =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) Manifest.permission.POST_NOTIFICATIONS else null

    fun isWifiEnabled(context: Context): Boolean = runCatching {
        val wifi = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        wifi?.isWifiEnabled ?: true
    }.getOrDefault(true)

    /**
     * Before Android 13 the framework only answers WiFi Direct discovery while the Location
     * switch is on, even though the app never reads the location itself.
     */
    fun needsLocationServices(): Boolean = Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU

    fun isLocationEnabled(context: Context): Boolean {
        val manager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return true
        return runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                manager.isLocationEnabled
            } else {
                manager.isProviderEnabled(LocationManager.GPS_PROVIDER) ||
                    manager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
            }
        }.getOrDefault(true)
    }

    fun isWifiDirectSupported(context: Context): Boolean =
        context.packageManager.hasSystemFeature(PackageManager.FEATURE_WIFI_DIRECT)

    fun readiness(context: Context): Readiness = Readiness(
        wifiDirectSupported = isWifiDirectSupported(context),
        permissionGranted = hasNearbyPermission(context),
        wifiEnabled = isWifiEnabled(context),
        locationEnabled = !needsLocationServices() || isLocationEnabled(context)
    )

    private fun isGranted(context: Context, permission: String): Boolean =
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
}
