package com.beamshare.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

val BeamShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

private val DarkColors = darkColorScheme(
    primary = BeamBlueLight,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF26307A),
    onPrimaryContainer = Color(0xFFDDE1FF),
    secondary = BeamCyan,
    onSecondary = Color(0xFF00363D),
    secondaryContainer = Color(0xFF0E3A44),
    onSecondaryContainer = Color(0xFFBDF1FA),
    tertiary = BeamMint,
    onTertiary = Color(0xFF00382B),
    tertiaryContainer = Color(0xFF0B3D31),
    onTertiaryContainer = Color(0xFFB7F4DE),
    error = BeamRed,
    onError = Color.White,
    errorContainer = Color(0xFF4A1620),
    onErrorContainer = Color(0xFFFFD9DD),
    background = DarkBackground,
    onBackground = DarkOnSurface,
    surface = DarkBackground,
    onSurface = DarkOnSurface,
    surfaceVariant = DarkSurfaceHigh,
    onSurfaceVariant = DarkOnSurfaceMuted,
    surfaceContainerLowest = Color(0xFF080A0F),
    surfaceContainerLow = DarkSurfaceLow,
    surfaceContainer = DarkSurface,
    surfaceContainerHigh = DarkSurfaceHigh,
    surfaceContainerHighest = DarkSurfaceHighest,
    outline = DarkOutline,
    outlineVariant = DarkOutlineVariant
)

private val LightColors = lightColorScheme(
    primary = BeamBlue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE0E4FF),
    onPrimaryContainer = Color(0xFF0B1550),
    secondary = Color(0xFF0891B2),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFD2F3FA),
    onSecondaryContainer = Color(0xFF00363D),
    tertiary = Color(0xFF0F9F7C),
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFD2F6E9),
    onTertiaryContainer = Color(0xFF00382B),
    error = Color(0xFFD8342A),
    onError = Color.White,
    errorContainer = Color(0xFFFFE1E3),
    onErrorContainer = Color(0xFF5C0F18),
    background = LightBackground,
    onBackground = LightOnSurface,
    surface = LightBackground,
    onSurface = LightOnSurface,
    surfaceVariant = LightSurfaceHigh,
    onSurfaceVariant = LightOnSurfaceMuted,
    surfaceContainerLowest = Color.White,
    surfaceContainerLow = LightSurface,
    surfaceContainer = LightSurface,
    surfaceContainerHigh = LightSurfaceHigh,
    surfaceContainerHighest = LightSurfaceHighest,
    outline = LightOutline,
    outlineVariant = LightOutlineVariant
)

/**
 * System bar icon colours come from enableEdgeToEdge() in MainActivity (it follows the system
 * dark-mode setting, which is also what this theme follows), so nothing needs to reach into the
 * Activity's window from here.
 */
@Composable
fun BeamShareTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = BeamTypography,
        shapes = BeamShapes,
        content = content
    )
}
