# VoxelSandbox v7: water, textures, realistic terrain, 200-chunk view distance

## What changed
- **Animated water**: translucent surface drawn in its own pass (`WaterRenderer`, `Shaders.WATER_*`).
  Scrolling ripple normals, gentle vertical swell, Fresnel sky reflection, sun glint, depth-based
  colour/opacity (turquoise shallows -> deep blue), drifting shoreline foam. Works on voxel water
  and on distant water. You can now also place blocks into water.
- **Textures**: atlas is now 32x32 per tile (was 16x16), anisotropic filtering where available.
  New scattered-leaf foliage (midribs, rims, holes) for oak/birch/spruce; richer grass, dirt, stone
  (cracks), sand, bark, coal. Grass sides are mostly green so hills no longer read as brown contour bands.
  New blocks: snow, gravel, sandstone, dry grass, cactus, and cross-shaped plants (tall grass,
  poppy, dandelion, dead bush). All textures stay procedural (`BlockTextures.kt`), no assets.
- **Terrain** (`TerrainShape`, `Climate`, `TerrainGenerator`, `TreeBuilder`): world is now 128 tall
  with sea level 40. Oceans, continents, rolling hills, ridged mountain ranges with snow caps and
  rock/scree on steep slopes, rivers, lakes, beaches, deserts, savanna, taiga/snow, per-biome
  trees (oak, birch, tall spruce, cacti). New worlds spawn on dry land (`findSpawn`).
- **Render distance**: slider maximum is 200 chunks (3,200 blocks). Distant terrain now has 4 levels of
  detail (`FarTerrain`, `FarTerrainRenderer`) so the triangle count stays near a 600-block view's.
  Distant terrain is drawn in its own depth range for stable depth precision at that range.
- **Sky**: gradient sky with a sun (`SkyRenderer`, `Atmosphere`); fog fades into the horizon colour.

## Heads-up
- Save format bumped to v2: worlds saved with v6 cannot be loaded (their terrain no longer exists).
  "Continue" with an old save starts a fresh world.
- Chunk memory budget is now `WorldConfig.RESIDENT_BYTES_PER_CHUNK` (96 KB per chunk).
- This version was written without access to a Kotlin/Android toolchain, so it has not been
  compiled or run on a device. If the build reports an error, the log line points straight at it.

## Tuning knobs
- Water look: constants in `Shaders.WATER_FRAGMENT` (colours, alpha, glint power).
- Sky/fog colours and sun direction: `Atmosphere`.
- Terrain scale/shape: numbers in `TerrainShape.height` (continent frequency 0.00042, mountain
  height 74, hill amplitude), biome thresholds in `Climate.classify`.
- LOD ring distances: `FarTerrain.BAND_OUTER` / `BAND_OVERLAP`.
