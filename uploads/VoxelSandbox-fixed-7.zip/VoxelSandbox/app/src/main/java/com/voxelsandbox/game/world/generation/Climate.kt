package com.voxelsandbox.game.world.generation

import com.voxelsandbox.game.world.WorldConfig
import kotlin.math.max

/** What covers the ground at a point of dry land. Shared by the chunk generator (which
 *  turns it into blocks) and the distant-terrain builder (which turns it into a colour),
 *  so a hillside looks the same colour from far away as it does up close. */
enum class SurfaceKind { GRASS, DRY_GRASS, DESERT, BEACH, SNOW, ROCK, GRAVEL }

/**
 * Temperature, humidity and forest cover as smooth pure functions of position, plus the
 * rules that combine them with elevation and slope into a [SurfaceKind]:
 * hot + dry = desert, hot/warm + fairly dry = dry grass, cold = snow (more so with
 * altitude), steep or very high = bare rock, a thin band around sea level = beach.
 */
class Climate(seed: Long) {
    private val temperatureNoise = NoiseGenerator(mixSeed(seed, 11))
    private val humidityNoise = NoiseGenerator(mixSeed(seed, 12))
    private val forestNoise = NoiseGenerator(mixSeed(seed, 13))
    private val jitterNoise = NoiseGenerator(mixSeed(seed, 16))

    /** Sea-level temperature in -1 (arctic) .. 1 (tropical). Slow: climate zones span
     *  thousands of blocks. */
    fun baseTemperature(wx: Double, wz: Double): Double =
        (temperatureNoise.fbm2D(wx * 0.0005 + 31.0, wz * 0.0005 - 17.0, 3, 0.5, 2.0) * 1.3 + 0.16).coerceIn(-1.0, 1.0)

    /** Temperature at ground height [h]: it falls steadily above the lowlands, which puts
     *  snow on high peaks even in warm regions. */
    fun temperature(wx: Double, wz: Double, h: Double): Double {
        val alt = max(0.0, h - (SEA + 16.0))
        return baseTemperature(wx, wz) - alt * 0.017
    }

    /** Humidity in -1 (arid) .. 1 (wet). */
    fun humidity(wx: Double, wz: Double): Double =
        (humidityNoise.fbm2D(wx * 0.0006 - 70.0, wz * 0.0006 + 44.0, 3, 0.5, 2.0) * 1.4).coerceIn(-1.0, 1.0)

    /** Forest-ness in 0..1 (0 = open ground, 1 = dense forest). Drives tree density and
     *  the darker green the distant terrain uses over forests. */
    fun forest(wx: Double, wz: Double): Double {
        val f = forestNoise.fbm2D(wx * 0.011, wz * 0.011, 2, 0.5, 2.0)
        return ((f + 0.02) / 0.5).coerceIn(0.0, 1.0)
    }

    /**
     * Surface of dry land at ground height [h] with local [slope] (blocks of rise per
     * block, measured over a 2-block baseline), given the local [temp] (already corrected
     * for altitude) and [humid].
     */
    fun classify(wx: Double, wz: Double, h: Double, slope: Double, temp: Double, humid: Double): SurfaceKind {
        val aridity = 0.9 * temp - humid
        var kind = SurfaceKind.GRASS
        if (aridity > 0.58) kind = SurfaceKind.DESERT
        else if (aridity > 0.30) kind = SurfaceKind.DRY_GRASS

        val jitter = jitterNoise.noise2D(wx * 0.09 + 5.0, wz * 0.09 - 3.0)
        val highRock = smoothStep(SEA + 50.0, SEA + 68.0, h + jitter * 5.0)
        if (highRock > 0.5) {
            kind = SurfaceKind.ROCK // above the tree line
        } else if (h > SEA + 3.0 && slope > 1.1 + 0.25 * jitter) {
            kind = SurfaceKind.ROCK // cliffs
        } else if (h > SEA + 20.0 && slope > 0.75 + 0.2 * jitter) {
            kind = SurfaceKind.GRAVEL // loose scree below the cliffs
        }

        if (temp < -0.66 && h > SEA + 2.0 && kind != SurfaceKind.ROCK) kind = SurfaceKind.SNOW
        if (temp < -0.5 && kind == SurfaceKind.ROCK && slope < 1.3) kind = SurfaceKind.SNOW // snow caps

        if (h >= SEA - 2.0 && h <= SEA + 2.4 && slope < 1.0 && kind != SurfaceKind.SNOW) kind = SurfaceKind.BEACH
        return kind
    }

    private companion object {
        val SEA: Double = WorldConfig.SEA_LEVEL.toDouble()
    }
}
