package com.voxelsandbox.game.gl

/**
 * Four programs. The first three share one vertex format (position + uv + shade); the
 * water program reads the same buffers but treats the "uv" slot as data (see [WATER_VERTEX]).
 *
 *  - [VERTEX]/[FRAGMENT]: chunk terrain, particles, highlight and the cloud layer. The
 *    fragment stage alpha-tests (leaf textures have real transparent holes) and fades
 *    to the fog colour with distance.
 *  - [FAR_VERTEX]/[FAR_FRAGMENT]: the distant-terrain heightfield tiles. Identical
 *    shading, plus (a) a circular clip around the player so the far mesh never draws on
 *    top of the full-detail chunks that already cover that area (no z-fighting, no wasted
 *    fill-rate), and (b) a distance band: each level of detail only draws inside its own
 *    ring, and sinks slightly where it overlaps the next finer ring so the finer surface
 *    always wins (see FarTerrain).
 *  - [WATER_VERTEX]/[WATER_FRAGMENT]: every water surface, near (voxel chunks) and far
 *    (distant tiles). Animated normals scrolled from a small tiling noise texture give
 *    ripples; Fresnel mixes the body colour (shallow turquoise -> deep blue by water
 *    depth) with a reflection of the sky and a sun glint; a moving foam line follows the
 *    shore; opacity grows with depth so the bed shows through the shallows.
 *  - [SKY_VERTEX]/[SKY_FRAGMENT]: a full-screen gradient with a sun, drawn first.
 */
object Shaders {
    const val VERTEX = """#version 300 es
layout(location = 0) in vec3 aPosition;
layout(location = 1) in vec2 aTexCoord;
layout(location = 2) in float aShade;

uniform mat4 uViewProj;

out vec2 vTexCoord;
out float vShade;
out float vFogDist;

void main() {
    gl_Position = uViewProj * vec4(aPosition, 1.0);
    vTexCoord = aTexCoord;
    vShade = aShade;
    vFogDist = gl_Position.w;
}
"""

    const val FRAGMENT = """#version 300 es
precision mediump float;

in highp vec2 vTexCoord;
in float vShade;
in float vFogDist;

uniform sampler2D uTexture;
uniform vec3 uFogColor;
uniform float uFogStart;
uniform float uFogEnd;
uniform float uAlpha;

out vec4 fragColor;

void main() {
    vec4 texColor = texture(uTexture, vTexCoord);
    // Leaf and plant tiles carry transparent holes; every other tile (and the white cloud
    // cell) has alpha 1.0, so this only ever discards actual foliage gaps.
    if (texColor.a < 0.5) discard;
    vec3 shaded = texColor.rgb * vShade;
    float fogFactor = clamp((vFogDist - uFogStart) / (uFogEnd - uFogStart), 0.0, 1.0);
    vec3 finalColor = mix(shaded, uFogColor, fogFactor);
    fragColor = vec4(finalColor, texColor.a * uAlpha);
}
"""

    /** uCenter: world X/Z the band radii are measured from.
     *  uBand: x = inner radius, y = outer radius, z = how far (blocks) to sink this tile at
     *  the inner edge, w = length of the zone over which that sinking fades out. */
    const val FAR_VERTEX = """#version 300 es
layout(location = 0) in vec3 aPosition;
layout(location = 1) in vec2 aTexCoord;
layout(location = 2) in float aShade;

uniform mat4 uViewProj;
uniform highp vec2 uCenter;
uniform highp vec4 uBand;

out vec2 vTexCoord;
out float vShade;
out float vFogDist;
out vec2 vWorldXZ;

void main() {
    vec3 p = aPosition;
    highp float dist = length(p.xz - uCenter);
    float t = clamp((dist - uBand.x) / max(uBand.w, 1.0), 0.0, 1.0);
    p.y -= uBand.z * (1.0 - t * t * (3.0 - 2.0 * t));
    gl_Position = uViewProj * vec4(p, 1.0);
    vTexCoord = aTexCoord;
    vShade = aShade;
    vFogDist = gl_Position.w;
    vWorldXZ = aPosition.xz;
}
"""

    /** uClip: xy = centre of the clipped circle (world X/Z), z = its radius SQUARED.
     *  Fragments inside the circle belong to full-detail chunks and are dropped.
     *  uBand.xy = inner / outer radius of this level's ring (see FAR_VERTEX). */
    const val FAR_FRAGMENT = """#version 300 es
precision mediump float;

in highp vec2 vTexCoord;
in float vShade;
in float vFogDist;
in highp vec2 vWorldXZ;

uniform sampler2D uTexture;
uniform vec3 uFogColor;
uniform float uFogStart;
uniform float uFogEnd;
uniform highp vec3 uClip;
uniform highp vec2 uCenter;
uniform highp vec4 uBand;

out vec4 fragColor;

void main() {
    highp vec2 dc = vWorldXZ - uClip.xy;
    if (dot(dc, dc) < uClip.z) discard;
    highp vec2 db = vWorldXZ - uCenter;
    highp float d2 = dot(db, db);
    if (d2 < uBand.x * uBand.x || d2 > uBand.y * uBand.y) discard;
    vec4 texColor = texture(uTexture, vTexCoord);
    vec3 shaded = texColor.rgb * vShade;
    float fogFactor = clamp((vFogDist - uFogStart) / (uFogEnd - uFogStart), 0.0, 1.0);
    vec3 finalColor = mix(shaded, uFogColor, fogFactor);
    fragColor = vec4(finalColor, 1.0);
}
"""

    /**
     * Vertex data for water: position, then (depth in blocks, unused) in the "uv" slots,
     * then an unused shade. uWave scales the vertical swell (1 for voxel water, 0 for the
     * flat distant water, which is too far away for it to matter). The swell is a pure
     * function of world X/Z and time, so vertices shared by neighbouring chunks move
     * together and no crack can open between them. uWaveTime wraps at 2*pi/0.05 seconds, a
     * whole number of periods of all three swell frequencies, so it never jumps.
     */
    const val WATER_VERTEX = """#version 300 es
layout(location = 0) in vec3 aPosition;
layout(location = 1) in vec2 aData;
layout(location = 2) in float aShade;

uniform mat4 uViewProj;
uniform highp float uWaveTime;
uniform float uWave;

out highp vec3 vWorld;
out float vDepth;
out float vFogDist;

void main() {
    vec3 p = aPosition;
    float swell = sin(p.x * 0.55 + uWaveTime * 1.25)
                + sin(p.z * 0.43 - uWaveTime * 0.95)
                + sin((p.x + p.z) * 0.31 + uWaveTime * 0.70);
    p.y += swell * 0.02 * uWave;
    gl_Position = uViewProj * vec4(p, 1.0);
    vWorld = p;
    vDepth = aData.x;
    vFogDist = gl_Position.w;
}
"""

    /** uClip / uBand: same meaning as in FAR_FRAGMENT (near water passes a zero clip and a
     *  band that spans everything). uWaterTex: tiling noise; rg = slope, b = height. */
    const val WATER_FRAGMENT = """#version 300 es
precision mediump float;

in highp vec3 vWorld;
in float vDepth;
in float vFogDist;

uniform sampler2D uWaterTex;
uniform highp float uTime;
uniform highp vec3 uEye;
uniform vec3 uSunDir;
uniform vec3 uHorizon;
uniform vec3 uZenith;
uniform vec3 uFogColor;
uniform float uFogStart;
uniform float uFogEnd;
uniform highp vec3 uClip;
uniform highp vec2 uCenter;
uniform highp vec4 uBand;

out vec4 fragColor;

void main() {
    highp vec2 dc = vWorld.xz - uClip.xy;
    if (dot(dc, dc) < uClip.z) discard;
    highp vec2 db = vWorld.xz - uCenter;
    highp float d2 = dot(db, db);
    if (d2 < uBand.x * uBand.x || d2 >= uBand.y * uBand.y) discard;

    // Two layers of scrolling noise, one fine and one broad, drifting in different
    // directions, give a believable ripple pattern.
    highp vec2 p = vWorld.xz;
    highp vec2 uvA = p * 0.031 + vec2(uTime * 0.017, uTime * 0.011);
    highp vec2 uvB = p * 0.077 + vec2(-uTime * 0.021, uTime * 0.015);
    vec4 a = texture(uWaterTex, uvA);
    vec4 b = texture(uWaterTex, uvB);
    vec2 slope = (a.rg - 0.5) + (b.rg - 0.5) * 0.7;
    vec3 n = normalize(vec3(-slope.x * 1.1, 1.0, -slope.y * 1.1));

    vec3 v = normalize(uEye - vWorld);
    float ndv = clamp(dot(n, v), 0.0, 1.0);
    float fresnel = 0.04 + 0.96 * pow(1.0 - ndv, 5.0);

    // What the surface mirrors: the sky gradient, plus the sun as a tight glint.
    vec3 r = reflect(-v, n);
    vec3 sky = mix(uHorizon, uZenith, pow(clamp(r.y, 0.0, 1.0), 0.5));
    float sd = max(dot(r, uSunDir), 0.0);
    vec3 glint = vec3(1.0, 0.93, 0.78) * (pow(sd, 90.0) * 1.4 + pow(sd, 12.0) * 0.12);

    // Body colour: clear turquoise in the shallows, deep blue over deep water.
    float depthK = sqrt(clamp(vDepth / 8.0, 0.0, 1.0));
    vec3 body = mix(vec3(0.20, 0.58, 0.62), vec3(0.03, 0.18, 0.38), depthK);

    vec3 col = mix(body, sky, clamp(fresnel * 0.9 + 0.06, 0.0, 1.0)) + glint;

    // Foam: a drifting, broken white line where the water is shallow. Fades with distance.
    float foamNoise = texture(uWaterTex, p * 0.09 + vec2(uTime * 0.03, -uTime * 0.02)).b;
    float shore = 1.0 - smoothstep(0.0, 1.0, vDepth);
    float foam = shore * smoothstep(0.50, 0.75, foamNoise + shore * 0.25);
    foam *= 1.0 - clamp(vFogDist / 120.0, 0.0, 1.0);
    col = mix(col, vec3(0.93, 0.97, 1.0), foam * 0.85);

    float alpha = mix(0.42, 0.93, depthK);
    alpha = clamp(alpha + fresnel * 0.30 + foam * 0.5, 0.0, 1.0);

    float fogFactor = clamp((vFogDist - uFogStart) / (uFogEnd - uFogStart), 0.0, 1.0);
    col = mix(col, uFogColor, fogFactor);
    fragColor = vec4(col, alpha);
}
"""

    /** One oversized triangle covering the screen; no vertex buffer needed. */
    const val SKY_VERTEX = """#version 300 es
out vec2 vNdc;

void main() {
    vec2 corner = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));
    vNdc = corner * 2.0 - 1.0;
    gl_Position = vec4(vNdc, 1.0, 1.0);
}
"""

    /** uForward/uRight/uUp: the camera basis; uTan.x = tan(fovY / 2) * aspect, uTan.y = tan(fovY / 2). */
    const val SKY_FRAGMENT = """#version 300 es
precision highp float;

in vec2 vNdc;

uniform vec3 uForward;
uniform vec3 uRight;
uniform vec3 uUp;
uniform vec2 uTan;
uniform vec3 uHorizon;
uniform vec3 uZenith;
uniform vec3 uSunDir;

out vec4 fragColor;

void main() {
    vec3 dir = normalize(uForward + uRight * (vNdc.x * uTan.x) + uUp * (vNdc.y * uTan.y));
    float h = clamp(dir.y, 0.0, 1.0);
    vec3 col = mix(uHorizon, uZenith, pow(h, 0.5));
    float sd = max(dot(dir, uSunDir), 0.0);
    col += vec3(1.0, 0.90, 0.68) * (pow(sd, 1500.0) * 2.0 + pow(sd, 10.0) * 0.14);
    fragColor = vec4(col, 1.0);
}
"""
}
