package com.voxelsandbox.game.world.generation

import com.voxelsandbox.game.world.WorldConfig
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.tanh

/**
 * The land-form of the world as a pure function of (x, z): oceans, continents, rolling
 * hills, mountain ranges, river valleys and lake basins. It knows nothing about blocks,
 * chunks or biomes, so the chunk generator and the distant-terrain builder sample exactly
 * the same landscape.
 *
 * Layers, from large to small:
 *  1. A domain warp bends everything below so coastlines and ranges are organic.
 *  2. Continentalness (very low frequency) decides ocean vs. land and the base elevation
 *     through a hand-shaped curve: deep ocean, shelf, coast, plains, uplands.
 *  3. Ridged mountains grow only on elevated land, masked by their own low-frequency
 *     noise, so ranges are separate massifs rather than a bumpy carpet.
 *  4. Hills of a locally varying roughness: calm plains next to rugged country.
 *  5. Rivers follow the zero-crossings of a noise field and cut valleys into lowlands;
 *     lake basins are carved where another noise field is high.
 *  6. A faint high-frequency roughness breaks up the long straight terrace edges that
 *     a one-block vertical resolution would otherwise leave on gentle slopes.
 */
class TerrainShape(seed: Long) {
    private val warpA = NoiseGenerator(mixSeed(seed, 1))
    private val warpB = NoiseGenerator(mixSeed(seed, 2))
    private val continent = NoiseGenerator(mixSeed(seed, 3))
    private val mountainMask = NoiseGenerator(mixSeed(seed, 4))
    private val ridge = NoiseGenerator(mixSeed(seed, 5))
    private val roughness = NoiseGenerator(mixSeed(seed, 6))
    private val hill = NoiseGenerator(mixSeed(seed, 7))
    private val detail = NoiseGenerator(mixSeed(seed, 8))
    private val river = NoiseGenerator(mixSeed(seed, 9))
    private val lake = NoiseGenerator(mixSeed(seed, 10))
    private val micro = NoiseGenerator(mixSeed(seed, 14))
    private val riverWidth = NoiseGenerator(mixSeed(seed, 15))

    /**
     * Ground height (in blocks, continuous) at world position ([wx], [wz]).
     *
     * [lod] drops the finest features for distant terrain, which is sampled sparsely and
     * would only alias them: 0 = full detail (the voxel world), 1 = no micro roughness,
     * 2 and up = also fewer hill octaves and no mid-scale detail.
     */
    fun height(wx: Double, wz: Double, lod: Int = 0): Double {
        // 1. domain warp
        val wxw = wx + 90.0 * warpA.fbm2D(wx * 0.0021, wz * 0.0021, 2, 0.5, 2.0)
        val wzw = wz + 90.0 * warpB.fbm2D(wx * 0.0021 + 41.0, wz * 0.0021 - 23.0, 2, 0.5, 2.0)

        // 2. continents -> base elevation
        val c = continent.fbm2D(wxw * 0.00042, wzw * 0.00042, 4, 0.5, 2.0) + 0.14
        val base = SEA + interpolate(c, BASE_C, BASE_H)
        val landW = smoothStep(-0.20, 0.03, c)

        // 3. mountains
        val mm = mountainMask.fbm2D(wxw * 0.0009 + 57.0, wzw * 0.0009 - 13.0, 3, 0.5, 2.0)
        val m = smoothStep(0.06, 0.42, mm) * smoothStep(0.04, 0.26, c)
        var mountains = 0.0
        if (m > 0.0) {
            val r = ridge.ridged2D(wxw * 0.0022, wzw * 0.0022, 5, 2.0, 2.0)
            mountains = m * (r.coerceIn(0.0, 1.0).pow(1.25) * 74.0 + 4.0)
        }

        // 4. hills (amplitude varies from calm plains to rugged country)
        val rough = (0.5 + 0.7 * roughness.fbm2D(wx * 0.0023 + 9.0, wz * 0.0023 + 4.0, 2, 0.5, 2.0)).coerceIn(0.0, 1.0)
        val hillAmp = 2.5 + 15.0 * rough.pow(1.6)
        val coastal = smoothStep(0.0, 14.0, base - SEA)
        val hillOctaves = max(2, 5 - lod)
        val hills = hill.fbm2D(wx * 0.0062, wz * 0.0062, hillOctaves, 0.5, 2.0) * hillAmp * 2.0 * (0.22 + 0.78 * coastal)
        val fine = if (lod <= 1) detail.fbm2D(wx * 0.045 + 3.3, wz * 0.045 - 7.1, 2, 0.5, 2.0) * 1.2 else 0.0
        var h = base + hills * (0.25 + 0.75 * landW) + mountains + fine * landW

        // 5a. rivers: carve a channel along the zero-crossings of the river field
        val rv = abs(river.fbm2D(wxw * 0.0011 + 222.0, wzw * 0.0011 + 11.0, 3, 0.5, 2.0))
        val rwn = 0.5 + 0.5 * riverWidth.noise2D(wx * 0.004, wz * 0.004)
        val rIn = 0.012 + 0.014 * rwn
        val rOut = rIn + 0.07
        val rf = 1.0 - smoothStep(rIn, rOut, rv)
        val lowland = 1.0 - smoothStep(SEA + 7.0, SEA + 20.0, h)
        val fr = rf * lowland * smoothStep(-0.05, 0.05, c)
        val bed = SEA - 3.5 + 2.2 * (1.0 - rf)
        h = min(h, h + (bed - h) * fr)

        // 5b. lakes: basins scooped out of low ground
        val lk = lake.fbm2D(wxw * 0.0030 + 777.0, wzw * 0.0030 - 333.0, 3, 0.5, 2.0)
        val lf = smoothStep(0.30, 0.46, lk) * (1.0 - smoothStep(SEA + 10.0, SEA + 22.0, h)) * smoothStep(-0.05, 0.05, c)
        val lakeBed = SEA - 2.0 - 6.0 * lf
        h = min(h, h + (lakeBed - h) * lf)

        // 6. micro roughness on dry land only (keeps shorelines clean)
        if (lod == 0) h += micro.noise2D(wx * 0.21, wz * 0.21) * 0.7 * smoothStep(SEA + 1.0, SEA + 4.0, h)

        // soft ceiling so peaks never flat-clip against the top of the world
        if (h > SOFT_CEILING) h = SOFT_CEILING + SOFT_RANGE * tanh((h - SOFT_CEILING) / SOFT_RANGE)
        return h.coerceIn(3.0, WorldConfig.WORLD_HEIGHT - 4.0)
    }

    private companion object {
        val SEA: Double = WorldConfig.SEA_LEVEL.toDouble()
        val SOFT_CEILING: Double = SEA + 50.0
        const val SOFT_RANGE = 32.0

        /** Continentalness -> base elevation above sea level. */
        val BASE_C = doubleArrayOf(-1.0, -0.42, -0.24, -0.11, -0.02, 0.06, 0.20, 0.38, 0.62, 1.0)
        val BASE_H = doubleArrayOf(-34.0, -30.0, -17.0, -7.0, 0.8, 5.0, 10.0, 16.0, 23.0, 30.0)
    }
}
