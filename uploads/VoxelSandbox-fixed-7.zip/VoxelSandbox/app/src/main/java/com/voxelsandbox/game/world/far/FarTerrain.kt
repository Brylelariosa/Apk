package com.voxelsandbox.game.world.far

import com.voxelsandbox.game.gl.TextureAtlas
import com.voxelsandbox.game.world.WorldConfig
import com.voxelsandbox.game.world.generation.SurfaceKind
import com.voxelsandbox.game.world.generation.TerrainGenerator
import com.voxelsandbox.game.world.mesh.MeshData
import java.util.concurrent.LinkedBlockingQueue
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/** Tile add ([tile] != null) or removal ([tile] == null) for [key], delivered to the GL
 *  thread strictly in the order the worker produced them. A single ordered stream matters:
 *  with separate "ready" and "unload" queues a tile that was built, unloaded and rebuilt
 *  could be applied in the wrong order and leave a ghost mesh behind. */
class FarEvent(val key: Long, val tile: FarTile?)

/** One finished distant-terrain tile, ready for the GL thread to upload: the opaque land
 *  mesh and (where the tile touches water) the translucent water mesh. */
class FarTile(
    val key: Long,
    val land: MeshData,
    val water: MeshData,
    val minY: Float,
    val maxY: Float
) {
    val level: Int get() = FarTerrain.levelOf(key)

    /** Edge length of the (square) tile in blocks. */
    val size: Float get() = FarTerrain.tileBlocks(level).toFloat()

    /** World-space X/Z of the tile's lower corner. */
    val x0: Float get() = FarTerrain.tileX(key) * size
    val z0: Float get() = FarTerrain.tileZ(key) * size
}

/**
 * Distant terrain: a cheap heightfield that fills the space between the full-detail voxel
 * chunks and the horizon, so the view distance can be many times larger than what voxel
 * chunks could ever afford (memory- or draw-call-wise).
 *
 * Nothing here touches the voxel world. Heights come straight from the terrain
 * generator's pure height function, so a tile can exist for terrain that no chunk has
 * generated yet — which is also why the horizon is there instantly at start-up and why
 * it fills any gap while real chunks are still streaming in.
 *
 * Level of detail: there are [LEVELS] levels. Level L tiles are (128 << L) blocks wide
 * with a vertex every (4 << L) blocks, so every tile is the same 32 x 32 cells whatever
 * its size. Each level owns a distance band around the player (see [bandInner] /
 * [bandOuter]): detail halves as the distance doubles, which keeps the triangle count of a
 * 3,200-block view at roughly that of a 600-block one. The band limits are enforced by the
 * GL side (it discards fragments outside the band) rather than by cutting tiles, and
 * neighbouring bands deliberately overlap a little with the coarser surface nudged down
 * inside the overlap, so the seam between two levels can never open a crack.
 *
 * Tiles of one level sample exactly the same heights along their shared edges, so there are
 * no cracks inside a level either. Colour comes from a one-row "ramp" in the texture atlas
 * chosen from the surface type (see [SurfaceKind]), height and forest density, so a tile
 * needs no per-block textures. Where the ground is below sea level the tile also gets a
 * water mesh whose vertices carry the water depth, drawn by the animated-water shader.
 *
 * Everything is built on one background thread, nearest tile first. [coveredRadiusBlocks]
 * reports how far from the player the tiles are contiguously complete, which the renderer
 * uses to keep the fog in front of any still-missing ground.
 */
class FarTerrain(private val generator: TerrainGenerator) {

    @Volatile private var running = false
    @Volatile private var enabled = true
    @Volatile private var playerX = 0f
    @Volatile private var playerZ = 0f
    @Volatile private var radiusBlocks = 0f
    @Volatile private var resetRequested = false

    /** Tiles to add / remove, in order, for the GL thread to apply. */
    val events = LinkedBlockingQueue<FarEvent>()

    /** Distance from the player out to which every wanted tile has been built. */
    @Volatile var coveredRadiusBlocks: Float = 0f
        private set

    private var thread: Thread? = null

    fun start() {
        if (running) return
        running = true
        thread = Thread({ workerLoop() }, "voxel-far").apply {
            isDaemon = true
            start()
        }
    }

    fun shutdown() {
        running = false
        thread?.interrupt()
        thread = null
    }

    /** Cheap; safe to call every frame. [radius] is the render distance in blocks. */
    fun updatePlayer(x: Float, z: Float, radius: Float, enable: Boolean) {
        playerX = x
        playerZ = z
        radiusBlocks = radius
        enabled = enable
    }

    /** The renderer lost its GL objects (context recreated): everything must be rebuilt
     *  and re-sent, since the CPU copies are not kept after upload. */
    fun invalidateAll() {
        resetRequested = true
    }

    // ---- worker ---------------------------------------------------------------------------

    private class Candidate(val level: Int, val tx: Int, val tz: Int, val key: Long, val nearDist: Float)

    private fun workerLoop() {
        try {
            android.os.Process.setThreadPriority(
                android.os.Process.THREAD_PRIORITY_BACKGROUND + android.os.Process.THREAD_PRIORITY_MORE_FAVORABLE
            )
        } catch (t: Throwable) {
            // best effort only
        }

        val built = HashSet<Long>()
        while (running) {
            try {
                if (resetRequested) {
                    resetRequested = false
                    built.clear()
                    events.clear()
                    coveredRadiusBlocks = 0f
                }

                val radius = radiusBlocks
                if (!enabled || radius < 32f) {
                    if (built.isNotEmpty()) {
                        for (k in built) events.put(FarEvent(k, null))
                        built.clear()
                    }
                    coveredRadiusBlocks = 0f
                    Thread.sleep(250)
                    continue
                }

                val px = playerX
                val pz = playerZ
                val wanted = planTiles(px, pz, radius)
                unloadStale(built, px, pz, radius)

                var replan = false
                for (cand in wanted) {
                    if (!running) return
                    if (built.contains(cand.key)) continue

                    // Wanted tiles are sorted nearest-first and every nearer one is already
                    // built, so contiguous coverage ends exactly where this tile begins.
                    coveredRadiusBlocks = cand.nearDist

                    // Backpressure: the GL thread uploads only a couple per frame.
                    while (running && events.size >= MAX_QUEUED_EVENTS) Thread.sleep(4)

                    val tile = buildTile(cand.level, cand.tx, cand.tz)
                    events.put(FarEvent(tile.key, tile))
                    built.add(cand.key)

                    if (resetRequested || !enabled || radiusBlocks != radius ||
                        abs(playerX - px) > REPLAN_DISTANCE || abs(playerZ - pz) > REPLAN_DISTANCE
                    ) {
                        replan = true
                        break
                    }
                }
                if (!replan) {
                    coveredRadiusBlocks = radius
                    Thread.sleep(120)
                }
            } catch (e: InterruptedException) {
                return
            } catch (t: Throwable) {
                // A bad tile must never kill the whole horizon; back off briefly and retry.
                try {
                    Thread.sleep(250)
                } catch (e: InterruptedException) {
                    return
                }
            }
        }
    }

    /** Every tile that must exist for the current position and render distance, across all
     *  levels, nearest first. */
    private fun planTiles(px: Float, pz: Float, radius: Float): ArrayList<Candidate> {
        val out = ArrayList<Candidate>()
        for (level in 0 until LEVELS) {
            val inner = bandInner(level)
            if (inner > radius) break
            val outer = min(bandDrawOuter(level), radius)
            val size = tileBlocks(level)
            val minTx = Math.floorDiv(floor(px - outer).toInt(), size)
            val maxTx = Math.floorDiv(floor(px + outer).toInt(), size)
            val minTz = Math.floorDiv(floor(pz - outer).toInt(), size)
            val maxTz = Math.floorDiv(floor(pz + outer).toInt(), size)
            for (tz in minTz..maxTz) {
                for (tx in minTx..maxTx) {
                    val near = nearestDistance(tx, tz, size, px, pz)
                    if (near > outer) continue
                    if (inner > 0f && farthestDistance(tx, tz, size, px, pz) < inner) continue
                    out.add(Candidate(level, tx, tz, tileKey(level, tx, tz), near))
                }
            }
        }
        out.sortBy { it.nearDist }
        return out
    }

    /** Drops tiles that are well outside their band. The margin (one tile) is the
     *  hysteresis that stops a tile on the edge of a band being rebuilt back and forth. */
    private fun unloadStale(built: HashSet<Long>, px: Float, pz: Float, radius: Float) {
        var stale: ArrayList<Long>? = null
        for (key in built) {
            val level = levelOf(key)
            val size = tileBlocks(level)
            val tx = tileX(key)
            val tz = tileZ(key)
            val near = nearestDistance(tx, tz, size, px, pz)
            val outer = min(bandDrawOuter(level), radius)
            val tooFar = near > outer + size
            val tooNear = bandInner(level) > 0f && farthestDistance(tx, tz, size, px, pz) < bandInner(level) - size
            if (tooFar || tooNear) {
                if (stale == null) stale = ArrayList()
                stale.add(key)
            }
        }
        if (stale != null) {
            for (key in stale) {
                built.remove(key)
                events.put(FarEvent(key, null))
            }
        }
    }

    private fun nearestDistance(tx: Int, tz: Int, size: Int, px: Float, pz: Float): Float {
        val x0 = (tx * size).toFloat()
        val z0 = (tz * size).toFloat()
        val cx = if (px < x0) x0 else if (px > x0 + size) x0 + size else px
        val cz = if (pz < z0) z0 else if (pz > z0 + size) z0 + size else pz
        val dx = px - cx
        val dz = pz - cz
        return sqrt(dx * dx + dz * dz)
    }

    private fun farthestDistance(tx: Int, tz: Int, size: Int, px: Float, pz: Float): Float {
        val x0 = (tx * size).toFloat()
        val z0 = (tz * size).toFloat()
        val dx = max(abs(px - x0), abs(px - (x0 + size)))
        val dz = max(abs(pz - z0), abs(pz - (z0 + size)))
        return sqrt(dx * dx + dz * dz)
    }

    // ---- tile construction ----------------------------------------------------------------

    private fun buildTile(level: Int, tx: Int, tz: Int): FarTile {
        val step = step(level)
        val size = tileBlocks(level)
        val x0 = tx * size
        val z0 = tz * size
        val shape = generator.shape

        // Heights on the vertex grid plus one extra ring on every side (for edge slopes).
        val n = VERTS + 2
        val heights = IntArray(n * n)
        var lowest = Int.MAX_VALUE
        var highest = Int.MIN_VALUE
        for (j in 0 until n) {
            val wz = (z0 + (j - 1) * step).toDouble()
            for (i in 0 until n) {
                val wx = (x0 + (i - 1) * step).toDouble()
                val h = floor(shape.height(wx, wz, level)).toInt()
                heights[j * n + i] = h
                if (i in 1..VERTS && j in 1..VERTS) {
                    if (h < lowest) lowest = h
                    if (h > highest) highest = h
                }
            }
        }

        // Ground that is far below the surface is hidden by (near-opaque) deep water, so a
        // tile that is entirely deep ocean needs only its water mesh.
        val hasLand = highest + LAND_Y_OFFSET > WATER_Y - DEEP_WATER
        val hasWater = lowest + LAND_Y_OFFSET < WATER_Y

        var minY = Float.MAX_VALUE
        var maxY = -Float.MAX_VALUE
        val land = if (hasLand) buildLandMesh(level, x0, z0, heights) else MeshData.EMPTY
        if (!land.isEmpty()) {
            minY = land.minY
            maxY = land.maxY
        }
        val water = if (hasWater) buildWaterMesh(level, x0, z0, heights) else MeshData.EMPTY
        if (!water.isEmpty()) {
            minY = min(minY, WATER_Y)
            maxY = max(maxY, WATER_Y)
        }
        if (minY > maxY) {
            minY = WATER_Y
            maxY = WATER_Y
        }
        return FarTile(tileKey(level, tx, tz), land, water, minY, maxY)
    }

    private fun buildLandMesh(level: Int, x0: Int, z0: Int, heights: IntArray): MeshData {
        val step = step(level)
        val n = VERTS + 2
        val vertexData = FloatArray(VERTS * VERTS * MeshData.FLOATS_PER_VERTEX)
        val indices = IntArray(CELLS * CELLS * 6)
        val rampV = TextureAtlas.rampV()
        val span = 2f * step
        val slopeGain = SLOPE_GAIN[level]
        val climate = generator.climate

        var minY = Float.MAX_VALUE
        var maxY = -Float.MAX_VALUE
        var vi = 0
        for (j in 0 until VERTS) {
            for (i in 0 until VERTS) {
                val c = (j + 1) * n + (i + 1)
                val h = heights[c]
                val dhdx = (heights[c + 1] - heights[c - 1]) / span
                val dhdz = (heights[c + n] - heights[c - n]) / span
                val wx = x0 + i * step
                val wz = z0 + j * step

                val y = h + LAND_Y_OFFSET // voxel top face is at h + 1; sit just under it
                val t = rampIndex(climate.forest(wx.toDouble(), wz.toDouble()).toFloat(), wx, wz, h, max(abs(dhdx), abs(dhdz)) * slopeGain)

                // Directional shading from the slope normal; flat ground ~= 1.0 like the top
                // face of a voxel block, slopes facing away from the light darker.
                val inv = 1f / sqrt(dhdx * dhdx + 1f + dhdz * dhdz)
                val nx = -dhdx * inv
                val ny = inv
                val nz = -dhdz * inv
                val lit = nx * LIGHT_X + ny * LIGHT_Y + nz * LIGHT_Z
                val shade = (0.5f + 0.6f * max(0f, lit)).coerceAtMost(1f) * 0.97f

                vertexData[vi++] = wx.toFloat()
                vertexData[vi++] = y
                vertexData[vi++] = wz.toFloat()
                vertexData[vi++] = TextureAtlas.rampU(t)
                vertexData[vi++] = rampV
                vertexData[vi++] = shade
                if (y < minY) minY = y
                if (y > maxY) maxY = y
            }
        }

        var ii = 0
        for (j in 0 until CELLS) {
            for (i in 0 until CELLS) {
                val a = j * VERTS + i // (x0, z0)
                val b = a + 1 // (x1, z0)
                val d = a + VERTS // (x0, z1)
                val c = d + 1 // (x1, z1)
                // counter-clockwise seen from above, same as a voxel TOP face
                indices[ii++] = a; indices[ii++] = c; indices[ii++] = b
                indices[ii++] = a; indices[ii++] = d; indices[ii++] = c
            }
        }
        return MeshData(vertexData, indices, VERTS * VERTS, minY, maxY)
    }

    /** The sea / lake / river surface of a tile: a flat grid at [WATER_Y] whose vertices
     *  carry the depth of the ground below, and only the cells that touch water. */
    private fun buildWaterMesh(level: Int, x0: Int, z0: Int, heights: IntArray): MeshData {
        val step = step(level)
        val n = VERTS + 2
        val vertexData = FloatArray(VERTS * VERTS * MeshData.FLOATS_PER_VERTEX)
        val depths = FloatArray(VERTS * VERTS)
        var vi = 0
        for (j in 0 until VERTS) {
            for (i in 0 until VERTS) {
                val h = heights[(j + 1) * n + (i + 1)]
                val depth = (WATER_Y - (h + LAND_Y_OFFSET)).coerceIn(0f, DEEP_WATER)
                depths[j * VERTS + i] = depth
                vertexData[vi++] = (x0 + i * step).toFloat()
                vertexData[vi++] = WATER_Y
                vertexData[vi++] = (z0 + j * step).toFloat()
                vertexData[vi++] = depth // the water shader reads depth from the "u" slot
                vertexData[vi++] = 0f
                vertexData[vi++] = 1f
            }
        }

        val indices = IntArray(CELLS * CELLS * 6)
        var ii = 0
        for (j in 0 until CELLS) {
            for (i in 0 until CELLS) {
                val a = j * VERTS + i
                val b = a + 1
                val d = a + VERTS
                val c = d + 1
                if (depths[a] <= 0f && depths[b] <= 0f && depths[c] <= 0f && depths[d] <= 0f) continue
                indices[ii++] = a; indices[ii++] = c; indices[ii++] = b
                indices[ii++] = a; indices[ii++] = d; indices[ii++] = c
            }
        }
        if (ii == 0) return MeshData.EMPTY
        return MeshData(vertexData, indices.copyOf(ii), VERTS * VERTS, WATER_Y, WATER_Y)
    }

    /**
     * Position on the atlas colour ramp (see TextureAtlas) for a land vertex. The ramp's
     * colours are the averages of the real block textures, so the far terrain matches what
     * the voxel terrain looks like close up: sand on beaches and sea floors, grass (lighter
     * on open ground, darker over forest), dry grass, desert sand, bare rock, scree and snow.
     */
    private fun rampIndex(forest: Float, wx: Int, wz: Int, h: Int, slope: Float): Float {
        val sea = WorldConfig.SEA_LEVEL
        if (h < sea - 2) {
            return if (sea - h > 8) TextureAtlas.RAMP_GRAVEL + 1f else TextureAtlas.RAMP_SAND + 2f // sea floor
        }

        val x = wx.toDouble()
        val z = wz.toDouble()
        val hd = h.toDouble()
        val climate = generator.climate
        val temp = climate.temperature(x, z, hd)
        val humid = climate.humidity(x, z)
        val kind = climate.classify(x, z, hd, slope.toDouble(), temp, humid)

        // Large soft patches, so a field of one surface type is not one flat colour.
        val patch = (0.5f + 0.25f * sin(wx * 0.043f + 1.7f) * cos(wz * 0.057f) + 0.25f * sin((wx + wz) * 0.021f))
            .coerceIn(0f, 1f)
        return when (kind) {
            SurfaceKind.BEACH -> TextureAtlas.RAMP_SAND + (if (h <= sea) 2f else if (h == sea + 1) 1f else 0f)
            SurfaceKind.GRASS -> TextureAtlas.RAMP_GRASS + 0.3f + patch * 2.0f + forest * 1.9f
            SurfaceKind.DRY_GRASS -> TextureAtlas.RAMP_DRY + patch * 1.8f + forest * 0.6f
            SurfaceKind.DESERT -> TextureAtlas.RAMP_DESERT + patch * 2.0f
            SurfaceKind.SNOW -> TextureAtlas.RAMP_SNOW + patch * 1.8f
            SurfaceKind.ROCK -> TextureAtlas.RAMP_STONE + patch * 2.0f
            SurfaceKind.GRAVEL -> TextureAtlas.RAMP_GRAVEL + patch * 2.0f
        }
    }

    companion object {
        /** Number of detail levels (0 = finest). */
        const val LEVELS = 4

        /** Every tile is CELLS x CELLS quads whatever its level. */
        const val CELLS = 32
        const val VERTS = CELLS + 1

        /** Vertex spacing and tile edge of level 0, in blocks. Each level doubles both. */
        const val BASE_STEP = 4
        const val BASE_TILE_BLOCKS = BASE_STEP * CELLS // 128

        fun step(level: Int): Int = BASE_STEP shl level
        fun tileBlocks(level: Int): Int = BASE_TILE_BLOCKS shl level

        /** Nominal outer edge of each level's distance band, in blocks from the player. The
         *  last level has no outer edge (it reaches the render distance). */
        private val BAND_OUTER = floatArrayOf(512f, 1024f, 2048f, 1.0e9f)

        /** How far past its nominal edge a level keeps drawing so the next, coarser level
         *  can blend in underneath (see the class comment). */
        private val BAND_OVERLAP = floatArrayOf(32f, 64f, 128f, 0f)

        /** Distance at which a level's band starts (level 0 starts at the voxel terrain). */
        fun bandInner(level: Int): Float = if (level == 0) 0f else BAND_OUTER[level - 1]

        /** Nominal outer edge of the band; water (flat, so seam-free) is clipped exactly here. */
        fun bandOuter(level: Int): Float = BAND_OUTER[level]

        /** Outer edge for land, including the overlap. */
        fun bandDrawOuter(level: Int): Float = BAND_OUTER[level] + BAND_OVERLAP[level]

        /** Length of the overlap zone at the start of a (coarser) level's band. */
        fun bandOverlapAtStart(level: Int): Float = if (level == 0) 0f else BAND_OVERLAP[level - 1]

        /** Far-terrain slopes are measured over a coarser baseline than the voxel terrain's,
         *  which smooths them; these gains restore the rock / scree coverage the voxel
         *  generator would give, so a mountainside keeps its colour with distance. */
        private val SLOPE_GAIN = floatArrayOf(1.2f, 1.5f, 1.9f, 2.7f)

        /** Voxel water surfaces sit at SEA_LEVEL + 0.875 (see ChunkMesher). */
        const val WATER_Y = WorldConfig.SEA_LEVEL + 0.875f

        /** Land vertices sit this far above the top block's floor: just under the voxel top
         *  face (which is at +1), so real voxel terrain always wins where both exist. */
        private const val LAND_Y_OFFSET = 0.75f

        /** Water at least this deep is drawn (near-)opaque, so ground beneath it is skipped. */
        private const val DEEP_WATER = 10f

        private const val MAX_QUEUED_EVENTS = 24
        private const val REPLAN_DISTANCE = 24f

        // Fixed light direction (normalised) used to shade slopes: the sun (see Atmosphere)
        // pulled toward straight up, so flat ground comes out as bright as a voxel top face.
        private const val LIGHT_X = 0.29f
        private const val LIGHT_Y = 0.89f
        private const val LIGHT_Z = -0.35f

        // Tile key = level (3 bits) | tx (29 bits, signed) | tz (29 bits, signed).
        private const val COORD_MASK = 0x1FFFFFFFL

        fun tileKey(level: Int, tx: Int, tz: Int): Long =
            (level.toLong() shl 58) or ((tx.toLong() and COORD_MASK) shl 29) or (tz.toLong() and COORD_MASK)

        fun levelOf(key: Long): Int = (key ushr 58).toInt()
        fun tileX(key: Long): Int = (((key ushr 29) and COORD_MASK).toInt() shl 3) shr 3
        fun tileZ(key: Long): Int = ((key and COORD_MASK).toInt() shl 3) shr 3
    }
}
