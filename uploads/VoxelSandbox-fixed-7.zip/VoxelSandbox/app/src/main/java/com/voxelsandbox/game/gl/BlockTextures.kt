package com.voxelsandbox.game.gl

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * The procedural art for every block texture: 32x32 tiles built from seeded hash noise
 * and a few geometric primitives (scattered leaves, Voronoi pebbles and cracks, ...).
 * Nothing is read from disk, so the project stays asset-free.
 *
 * Every tile is an ARGB int array in row-major order with *straight* alpha; row 0 is the
 * top of the tile. Tiles that cover a surface (grass, dirt, stone, sand, leaves, ...) are
 * built from noise that is periodic over the tile, so neighbouring blocks line up with no
 * visible seam. [TextureAtlas] packs the tiles and builds the mip chain.
 */
internal object BlockTextures {
    private const val S = TextureAtlas.CELL_PX
    private const val HALF = S / 2f
    private val PI_F: Float = PI.toFloat()

    // ---- palettes ---------------------------------------------------------------------------

    private val GRASS = intArrayOf(rgb(52, 104, 36), rgb(70, 130, 46), rgb(88, 152, 56), rgb(108, 174, 66), rgb(132, 196, 82))
    private val DRY_GRASS = intArrayOf(rgb(112, 118, 54), rgb(138, 144, 64), rgb(160, 166, 74), rgb(184, 188, 90), rgb(206, 208, 112))
    private val DIRT = intArrayOf(rgb(78, 52, 34), rgb(98, 68, 44), rgb(116, 82, 54), rgb(134, 98, 64))
    private val STONE = intArrayOf(rgb(88, 88, 92), rgb(108, 108, 112), rgb(126, 126, 130), rgb(144, 144, 148), rgb(160, 160, 162))
    private val SAND = intArrayOf(rgb(196, 178, 128), rgb(210, 194, 142), rgb(222, 207, 156), rgb(234, 221, 172))
    private val SNOW = intArrayOf(rgb(214, 224, 236), rgb(232, 240, 248), rgb(244, 248, 252), rgb(252, 253, 255))
    private val OAK_BARK = intArrayOf(rgb(58, 40, 24), rgb(80, 56, 34), rgb(102, 74, 44), rgb(124, 92, 56))
    private val SPRUCE_BARK = intArrayOf(rgb(38, 27, 18), rgb(54, 39, 26), rgb(70, 51, 34), rgb(88, 65, 43))
    private val BIRCH_BARK = intArrayOf(rgb(196, 192, 180), rgb(216, 212, 202), rgb(232, 229, 220), rgb(242, 240, 233))
    private val OAK_LEAF = intArrayOf(rgb(24, 66, 30), rgb(36, 90, 40), rgb(52, 116, 48), rgb(76, 144, 58), rgb(112, 176, 76))
    private val BIRCH_LEAF = intArrayOf(rgb(52, 98, 34), rgb(76, 126, 40), rgb(104, 154, 48), rgb(138, 182, 62), rgb(176, 208, 86))
    private val SPRUCE_LEAF = intArrayOf(rgb(14, 40, 30), rgb(22, 58, 42), rgb(32, 78, 54), rgb(46, 100, 66), rgb(70, 126, 84))
    private val GRAVEL = intArrayOf(rgb(96, 92, 88), rgb(128, 122, 116), rgb(150, 144, 136), rgb(112, 100, 92), rgb(168, 160, 150))

    // ---- public tiles -----------------------------------------------------------------------

    fun grassTop(): IntArray = tile { x, y -> grassTopPx(x, y, GRASS, 11) }
    fun grassSide(): IntArray = tile { x, y -> grassSidePx(x, y, GRASS, 31) }
    fun dryGrassTop(): IntArray = tile { x, y -> grassTopPx(x, y, DRY_GRASS, 17) }
    fun dryGrassSide(): IntArray = tile { x, y -> grassSidePx(x, y, DRY_GRASS, 37) }
    fun dirt(): IntArray = tile { x, y -> dirtPx(x, y) }
    fun stone(): IntArray = tile { x, y -> stonePx(x, y) }
    fun sand(): IntArray = tile { x, y -> sandPx(x, y, 51) }
    fun gravel(): IntArray = tile { x, y -> gravelPx(x, y) }
    fun snow(): IntArray = tile { x, y -> snowPx(x, y) }
    fun snowSide(): IntArray = tile { x, y -> snowSidePx(x, y) }
    fun sandstoneSide(): IntArray = tile { x, y -> sandstoneSidePx(x, y) }
    fun sandstoneTop(): IntArray = tile { x, y -> mul(sandPx(x, y, 52), 0.93f) }
    fun coalOre(): IntArray = tile { x, y -> coalPx(x, y) }

    fun oakBark(): IntArray = tile { x, y -> barkPx(x, y, OAK_BARK, 61) }
    fun spruceBark(): IntArray = tile { x, y -> barkPx(x, y, SPRUCE_BARK, 161) }
    fun birchBark(): IntArray = tile { x, y -> birchBarkPx(x, y) }

    fun oakRings(): IntArray = tile { x, y ->
        ringsPx(x, y, rgb(96, 68, 40), rgb(186, 150, 98), rgb(160, 122, 78), rgb(134, 98, 60), rgb(80, 56, 33))
    }

    fun birchRings(): IntArray = tile { x, y ->
        ringsPx(x, y, rgb(226, 223, 212), rgb(216, 198, 152), rgb(190, 168, 122), rgb(160, 138, 96), rgb(190, 187, 176))
    }

    fun spruceRings(): IntArray = tile { x, y ->
        ringsPx(x, y, rgb(70, 50, 32), rgb(160, 122, 78), rgb(134, 98, 60), rgb(110, 78, 46), rgb(54, 38, 24))
    }

    fun oakLeaves(): IntArray = tile { x, y -> leafPx(x, y, OAK_LEAF, 81, false, 3.3f, 1.7f, 0.74f) }
    fun birchLeaves(): IntArray = tile { x, y -> leafPx(x, y, BIRCH_LEAF, 121, false, 3.1f, 1.6f, 0.72f) }
    fun spruceLeaves(): IntArray = tile { x, y -> leafPx(x, y, SPRUCE_LEAF, 141, true, 3.6f, 1.8f, 0.74f) }

    fun tallGrass(): IntArray = tile { x, y -> tallGrassPx(x, y) }
    fun poppy(): IntArray = tile { x, y -> flowerPx(x, y, rgb(214, 38, 40), rgb(40, 28, 24), 501) }
    fun dandelion(): IntArray = tile { x, y -> flowerPx(x, y, rgb(250, 214, 40), rgb(210, 150, 20), 511) }
    fun deadBush(): IntArray = tile { x, y -> deadBushPx(x, y) }
    fun cactusSide(): IntArray = tile { x, y -> cactusSidePx(x, y) }
    fun cactusTop(): IntArray = tile { x, y -> cactusTopPx(x, y) }

    fun water(): IntArray = tile { _, _ -> rgb(60, 116, 206) }
    fun white(): IntArray = tile { _, _ -> rgb(255, 255, 255) }

    /** Mean colour of the opaque texels of [tile]; the distant-terrain colour ramp is built
     *  from these so far-away ground matches the textures it stands in for. */
    fun averageColor(tile: IntArray): Int {
        var r = 0
        var g = 0
        var b = 0
        var n = 0
        for (p in tile) {
            if ((p ushr 24) < 128) continue
            r += (p shr 16) and 0xFF
            g += (p shr 8) and 0xFF
            b += p and 0xFF
            n++
        }
        if (n == 0) return rgb(128, 128, 128)
        return rgb(r / n, g / n, b / n)
    }

    /** Colour [c] scaled by [f] (alpha untouched). */
    fun scaleColor(c: Int, f: Float): Int = mul(c, f)

    // ---- ground tiles -----------------------------------------------------------------------

    private fun grassTopPx(x: Int, y: Int, p: IntArray, salt: Int): Int {
        val v = fbm(x, y, salt)
        var blade = 0f
        for (k in 0 until 3) {
            val bx = rnd(x, ((y + k * 11) % S) / 3, salt + 20 + k)
            if (bx % 7 == 0) blade += 0.18f
        }
        val r = rndf(x, y, salt + 5)
        val t = v * 0.8f + (r - 0.5f) * 0.28f + blade * 0.35f - 0.05f
        var c = pal(p, t)
        if (rnd(x, y, salt + 6) < 14) {
            c = mul(c, 0.78f)
        } else if (rnd(x, y, salt + 7) > 244) {
            c = mul(c, 1.16f)
        }
        return c
    }

    private fun dirtPx(x: Int, y: Int): Int {
        val salt = 21
        val v = fbm(x, y, salt)
        var c = pal(DIRT, v * 0.85f + (rndf(x, y, salt + 1) - 0.5f) * 0.3f)
        val pebble = pn(x, y, 4, salt + 9)
        if (pebble > 0.80f && rnd(x, y, salt + 3) < 140) c = lerpc(c, rgb(150, 138, 120), 0.55f)
        if (rnd(x, y, salt + 4) < 12) c = mul(c, 0.7f)
        return c
    }

    /** Grass-covered side: mostly green with a ragged lower edge over dirt, so a hillside
     *  built of stacked blocks reads as grassy slope rather than brown contour bands. */
    private fun grassSidePx(x: Int, y: Int, p: IntArray, salt: Int): Int {
        val depth = 19 + (pn(x, 0, 4, salt) * 6f).toInt() + (rnd(x, 1, salt + 1) % 3)
        if (y < depth) {
            var c = grassTopPx(x, y, p, 11)
            if (y >= depth - 2) c = mul(c, 0.82f)
            return c
        }
        if (y < depth + 4 && rnd(x, 2, salt + 2) < 90 && x % 3 != 1) {
            return mul(grassTopPx(x, y, p, 11), 0.72f)
        }
        var c = dirtPx(x, y)
        if (y < depth + 3) c = mul(c, 0.85f)
        return c
    }

    private fun stonePx(x: Int, y: Int): Int {
        val salt = 41
        val v = fbm(x, y, salt)
        var c = pal(STONE, v * 0.9f + (rndf(x, y, salt + 1) - 0.5f) * 0.22f)
        // Voronoi cell edges on an 8px grid (4x4 cells wrap around the tile) read as cracks.
        var best = 99f
        var second = 99f
        for (cy in -1..1) {
            for (cx in -1..1) {
                val gx = x / 8 + cx
                val gy = y / 8 + cy
                val mx = Math.floorMod(gx, 4)
                val my = Math.floorMod(gy, 4)
                val px = gx * 8 + 1 + rnd(mx, my, salt + 7) % 6
                val py = gy * 8 + 1 + rnd(mx, my, salt + 8) % 6
                val dx = (x - px).toFloat()
                val dy = (y - py).toFloat()
                val d = sqrt(dx * dx + dy * dy)
                if (d < best) {
                    second = best
                    best = d
                } else if (d < second) {
                    second = d
                }
            }
        }
        val edge = second - best
        if (edge < 1.15f) {
            c = mul(c, 0.62f)
        } else if (edge < 2.0f) {
            c = mul(c, 0.86f)
        }
        if (rnd(x, y, salt + 3) < 10) c = mul(c, 0.8f)
        return c
    }

    private fun sandPx(x: Int, y: Int, salt: Int): Int {
        val v = fbm(x, y, salt)
        // Ripples: whole numbers of periods across the tile, so they wrap seamlessly.
        val phase = x * (2f * PI_F * 3f / S) + y * (2f * PI_F * 5f / S) + 6f * pn(x, y, 8, salt + 4)
        val ripple = 0.5f + 0.5f * sin(phase)
        val t = v * 0.55f + ripple * 0.18f + (rndf(x, y, salt + 1) - 0.5f) * 0.35f
        var c = pal(SAND, t)
        if (rnd(x, y, salt + 2) < 9) c = mul(c, 0.9f)
        return c
    }

    private fun gravelPx(x: Int, y: Int): Int {
        val salt = 61
        var best = 99f
        var id = 0
        for (cy in -1..1) {
            for (cx in -1..1) {
                val gx = x / 8 + cx
                val gy = y / 8 + cy
                val mx = Math.floorMod(gx, 4)
                val my = Math.floorMod(gy, 4)
                val px = gx * 8 + 1 + rnd(mx, my, salt) % 6
                val py = gy * 8 + 1 + rnd(mx, my, salt + 1) % 6
                val dx = (x - px).toFloat()
                val dy = (y - py).toFloat()
                val d = sqrt(dx * dx + dy * dy)
                if (d < best) {
                    best = d
                    id = rnd(mx, my, salt + 2)
                }
            }
        }
        var base = pal(GRAVEL, id / 255f)
        if (best > 4.4f) {
            base = mul(base, 0.5f)
        } else if (best > 3.6f) {
            base = mul(base, 0.76f)
        }
        return mul(base, 0.92f + 0.12f * rndf(x, y, salt + 5))
    }

    private fun snowPx(x: Int, y: Int): Int {
        val salt = 71
        val v = fbm(x, y, salt)
        var c = pal(SNOW, 0.35f + v * 0.65f + (rndf(x, y, salt + 1) - 0.5f) * 0.18f)
        c = lerpc(c, rgb(200, 216, 238), 0.25f * (1f - v))
        if (rnd(x, y, salt + 2) > 247) c = rgb(255, 255, 255)
        return c
    }

    private fun snowSidePx(x: Int, y: Int): Int {
        val salt = 81
        val depth = 19 + (pn(x, 0, 4, salt) * 6f).toInt() + (rnd(x, 1, salt + 1) % 3)
        if (y < depth) {
            var c = snowPx(x, y)
            if (y >= depth - 2) c = mul(c, 0.9f)
            return c
        }
        var c = dirtPx(x, y)
        if (y < depth + 3) c = mul(c, 0.85f)
        return c
    }

    private fun sandstoneSidePx(x: Int, y: Int): Int {
        val salt = 91
        // Strata: four full bands across the tile so the pattern wraps.
        val band = 0.5f + 0.5f * sin((y + 3f * pn(x, y, 8, salt)) * (2f * PI_F / 8f))
        var c = pal(SAND, 0.15f + 0.35f * band + 0.3f * fbm(x, y, salt + 1))
        c = mul(c, 0.86f + 0.1f * rndf(x, y, salt + 2))
        if (y % 8 == 0 && rnd(x, y, salt + 3) < 200) {
            c = mul(c, 0.74f)
        } else if (y % 8 == 1) {
            c = mul(c, 0.94f)
        }
        return c
    }

    private fun coalPx(x: Int, y: Int): Int {
        val salt = 91
        var c = stonePx(x, y)
        // (centre x, centre y, radius) of each lump of coal
        val blobs = intArrayOf(7, 8, 26, 21, 7, 22, 12, 21, 29, 25, 22, 24, 5, 26, 20, 27, 12, 19)
        var k = 0
        while (k < 6) {
            val bx = blobs[k * 3]
            val by = blobs[k * 3 + 1]
            val br = blobs[k * 3 + 2] / 10f
            val dx = x - (bx + (rnd(k, 0, salt) % 3) - 1).toFloat()
            val dy = y - (by + (rnd(k, 1, salt) % 3) - 1).toFloat()
            val ex = dx / (br * 1.2f)
            val ey = dy / br
            val e = ex * ex + ey * ey + (rndf(x, y, salt + 2) - 0.5f) * 0.4f
            if (e < 1f) {
                c = lerpc(rgb(24, 24, 28), rgb(58, 58, 64), 0.6f * rndf(x, y, salt + 3))
                if (dx < -0.5f && dy < -0.5f && rnd(x, y, salt + 4) < 150) c = rgb(92, 92, 100)
            }
            k++
        }
        return c
    }

    // ---- wood -------------------------------------------------------------------------------

    private fun barkPx(x: Int, y: Int, p: IntArray, salt: Int): Int {
        val stripe = pn(x, 0, 2, salt)
        val furrow = pn(x, y, 4, salt + 3)
        val t = stripe * 0.6f + furrow * 0.25f + (rndf(x, y, salt + 1) - 0.5f) * 0.3f
        var c = pal(p, t)
        if (x % 4 == 0 && rnd(x, y, salt + 2) < 170) c = mul(c, 0.72f)
        // one knot per tile
        val kx = rnd(0, 0, salt + 9) % S
        val ky = rnd(1, 0, salt + 9) % S
        val dx = min(abs(x - kx), S - abs(x - kx))
        val dy = min(abs(y - ky), S - abs(y - ky))
        if (dx * dx + dy * dy < 5) c = mul(c, 0.62f)
        return c
    }

    private fun birchBarkPx(x: Int, y: Int): Int {
        val salt = 111
        val t = pn(x, y, 4, salt) * 0.5f + 0.3f + (rndf(x, y, salt + 1) - 0.5f) * 0.25f
        var c = pal(BIRCH_BARK, t)
        // the dark horizontal scars birch is known for
        for (k in 0 until 4) {
            val sy = (rnd(k, 0, salt + 5) % (S - 2)) + 1
            val sx = rnd(k, 1, salt + 5) % S
            val len = 5 + rnd(k, 2, salt + 5) % 9
            if (y == sy || (y == sy + 1 && rnd(x, y, salt + 6) < 120)) {
                val dxw = Math.floorMod(x - sx, S)
                if (dxw < len) c = lerpc(rgb(46, 44, 40), rgb(96, 92, 86), rndf(x, y, salt + 7))
            }
        }
        return c
    }

    /** Cut end of a log: growth rings inside a bark rim. */
    private fun ringsPx(x: Int, y: Int, outer: Int, ringA: Int, ringB: Int, core: Int, edge: Int): Int {
        val salt = 71
        val dx = x - 15.5f
        val dy = y - 15.5f
        val d = sqrt(dx * dx + dy * dy)
        val wob = (pn(x, y, 8, salt) - 0.5f) * 2f
        if (d > 13.6f + wob * 0.4f) {
            var c = lerpc(outer, edge, 0.5f + 0.5f * sin(x * 0.9f + y * 0.5f))
            if (rnd(x, y, salt + 1) < 70) c = edge
            return c
        }
        val dd = d + wob
        var c = if ((dd * 0.62f).toInt() % 2 == 0) ringA else ringB
        if (dd < 2.4f) c = core
        return mul(c, 0.94f + 0.1f * rndf(x, y, salt + 2))
    }

    // ---- leaves -----------------------------------------------------------------------------

    /**
     * Foliage: two layers of small leaves (or needles) scattered on a periodic grid of 4px
     * cells, each with a lighter midrib, a darker rim and its own tint, painted in random
     * depth order; plus irregular holes so a canopy reads as foliage rather than a solid
     * cube. Texels no leaf covers are fully transparent (the shader alpha-tests them).
     */
    private fun leafPx(x: Int, y: Int, p: IntArray, salt: Int, needles: Boolean, leafLen: Float, leafWid: Float, holeThreshold: Float): Int {
        val cellPx = 4
        val cells = S / cellPx
        var bestZ = -1f
        var best = 0
        var found = false
        for (layer in 0..1) {
            val off = if (layer == 0) 0 else 2
            for (cy in -1..1) {
                for (cx in -1..1) {
                    val gx = Math.floorDiv(x - off, cellPx) + cx
                    val gy = Math.floorDiv(y - off, cellPx) + cy
                    val wx = Math.floorMod(gx, cells)
                    val wy = Math.floorMod(gy, cells)
                    val s = salt + layer * 40
                    val lx = gx * cellPx + off + 1.5f + rndf(wx, wy, s) * (cellPx - 2f)
                    val ly = gy * cellPx + off + 1.5f + rndf(wx, wy, s + 1) * (cellPx - 2f)
                    var ang = rndf(wx, wy, s + 2) * PI_F
                    if (needles) {
                        ang = PI_F * (0.20f + 0.60f * rndf(wx, wy, s + 2)) + (if (rnd(wx, wy, s + 8) < 128) PI_F / 2f else 0f)
                    }
                    var dx = x - lx
                    var dy = y - ly
                    if (dx > HALF) dx -= S
                    if (dx < -HALF) dx += S
                    if (dy > HALF) dy -= S
                    if (dy < -HALF) dy += S
                    val ca = cos(ang)
                    val sa = sin(ang)
                    val u = dx * ca + dy * sa
                    val v = -dx * sa + dy * ca
                    val ll = leafLen * (0.8f + 0.5f * rndf(wx, wy, s + 3))
                    val ww = leafWid * (0.8f + 0.4f * rndf(wx, wy, s + 4))
                    if (abs(u) > ll) continue
                    val e: Float
                    if (needles) {
                        val eu = abs(u) / ll
                        val ev = abs(v) / 0.78f
                        e = max(eu * eu, ev * ev)
                    } else {
                        val eu = u / ll
                        val ev = v / (ww * (1f - 0.35f * abs(u) / ll))
                        e = eu * eu + ev * ev
                    }
                    if (e > 1f) continue
                    val z = rndf(wx, wy, s + 5) * 0.5f + (if (layer == 1) 0.5f else 0f)
                    if (z > bestZ) {
                        bestZ = z
                        val shade = 0.5f + 0.5f * rndf(wx, wy, s + 6)
                        val lit = 0.5f - 0.5f * (v / max(0.6f, ww))
                        var t = 0.18f + 0.48f * shade + 0.26f * lit
                        if (layer == 0) t *= 0.8f
                        var c = pal(p, t)
                        if (!needles && abs(v) < 0.45f && abs(u) < ll * 0.85f) c = mul(c, 1.16f)
                        if (e > 0.62f) c = mul(c, 0.78f)
                        best = c
                        found = true
                    }
                }
            }
        }
        val hole = pn(x, y, 4, salt + 90) * 0.6f + pn(x, y, 2, salt + 91) * 0.4f
        if (!found || hole > holeThreshold) return 0
        return best or (0xFF shl 24)
    }

    // ---- plants (transparent background) ----------------------------------------------------

    private fun tallGrassPx(x: Int, y: Int): Int {
        val salt = 201
        var best = 0
        var found = false
        val yy = S - 1 - y
        for (k in 0 until 9) {
            val bx = 3 + k * 3 + (rnd(k, 0, salt) % 3) - 1
            val h = 14 + rnd(k, 1, salt) % 14
            val lean = (rndf(k, 2, salt) - 0.5f) * 0.35f
            if (yy < 0 || yy > h) continue
            val curve = 0.012f * yy * yy * (if (k % 2 == 1) 1f else -1f)
            val cx = bx + lean * yy + curve
            val w = 1.4f * (1f - yy / (h + 2f)) + 0.35f
            if (abs(x - cx) <= w) {
                val t = 0.25f + 0.6f * (yy.toFloat() / h) + 0.15f * rndf(k, 3, salt)
                best = pal(GRASS, t)
                found = true
            }
        }
        if (!found) return 0
        return best or (0xFF shl 24)
    }

    private fun flowerPx(x: Int, y: Int, petal: Int, center: Int, salt: Int): Int {
        // stem (two pixels wide) and one leaf
        if (y > 14 && (x == 15 || x == 16)) return rgb(58, 118, 44)
        if (y in 21..28 && (x == 14 - (y - 21) / 3 || x == 13 - (y - 21) / 3)) return rgb(66, 130, 50)
        // blossom
        val dx = x - 15.5f
        val dy = y - 9.5f
        val d = sqrt(dx * dx + dy * dy)
        if (d < 2.2f) return center
        val ang = atan2(dy, dx)
        val petals = 0.5f + 0.5f * cos(ang * 5f)
        if (d < 5f + 1.6f * petals) return mul(petal, 0.85f + 0.25f * rndf(x, y, salt))
        return 0
    }

    private fun deadBushPx(x: Int, y: Int): Int {
        // branching twigs as (x0, y0, x1, y1) segments
        val twigs = intArrayOf(
            16, 31, 15, 18, 15, 20, 8, 9, 15, 22, 22, 10, 16, 27, 11, 17,
            16, 26, 21, 18, 11, 17, 6, 12, 21, 18, 25, 12, 8, 9, 5, 5
        )
        var i = 0
        while (i < twigs.size) {
            val x0 = twigs[i]
            val y0 = twigs[i + 1]
            val vx = (twigs[i + 2] - x0).toFloat()
            val vy = (twigs[i + 3] - y0).toFloat()
            val len2 = vx * vx + vy * vy
            val t = max(0f, min(1f, ((x - x0) * vx + (y - y0) * vy) / len2))
            val px = x0 + t * vx
            val py = y0 + t * vy
            val ex = x - px
            val ey = y - py
            if (ex * ex + ey * ey <= 0.9f) return mul(rgb(118, 86, 48), 0.8f + 0.3f * rndf(x, y, 301))
            i += 4
        }
        return 0
    }

    private fun cactusSidePx(x: Int, y: Int): Int {
        val salt = 401
        val rib = abs((x % 8) - 3.5f) / 3.5f
        var c = pal(intArrayOf(rgb(30, 84, 40), rgb(44, 112, 52), rgb(64, 138, 62)), 1f - rib * 0.9f)
        c = mul(c, 0.92f + 0.12f * rndf(x, y, salt))
        if ((x % 8 == 3 || x % 8 == 4) && y % 5 == 2) c = rgb(228, 224, 190)
        return c
    }

    private fun cactusTopPx(x: Int, y: Int): Int {
        val d = max(abs(x - 15.5f), abs(y - 15.5f))
        var c = pal(intArrayOf(rgb(36, 98, 46), rgb(60, 132, 60)), 1f - d / 16f)
        if (d.toInt() % 4 == 1) c = mul(c, 0.85f)
        return c
    }

    // ---- noise & colour helpers -------------------------------------------------------------

    private fun tile(f: (Int, Int) -> Int): IntArray {
        val out = IntArray(S * S)
        for (y in 0 until S) {
            for (x in 0 until S) out[y * S + x] = f(x, y)
        }
        return out
    }

    private fun hash(x: Int, y: Int, salt: Int): Int {
        var h = x * 374761393 + y * 668265263 + salt * 1274126177
        h = (h xor (h ushr 13)) * 1274126177
        return h xor (h ushr 16)
    }

    /** 0..255 hash noise. */
    private fun rnd(x: Int, y: Int, salt: Int): Int = (hash(x, y, salt) ushr 8) and 0xFF

    private fun rndf(x: Int, y: Int, salt: Int): Float = rnd(x, y, salt) / 255f

    private fun smooth(t: Float): Float = t * t * (3f - 2f * t)

    /** Smooth value noise in 0..1 that repeats every tile (lattice spacing [cell] px). */
    private fun pn(x: Int, y: Int, cell: Int, salt: Int): Float {
        val n = S / cell
        val ix = x / cell
        val iy = y / cell
        val tx = smooth((x - ix * cell).toFloat() / cell)
        val ty = smooth((y - iy * cell).toFloat() / cell)
        val x0 = ix % n
        val x1 = (ix + 1) % n
        val y0 = iy % n
        val y1 = (iy + 1) % n
        val a = rnd(x0, y0, salt)
        val b = rnd(x1, y0, salt)
        val c = rnd(x0, y1, salt)
        val d = rnd(x1, y1, salt)
        val top = a + (b - a) * tx
        val bot = c + (d - c) * tx
        return (top + (bot - top) * ty) / 255f
    }

    private fun fbm(x: Int, y: Int, salt: Int): Float =
        0.5f * pn(x, y, 16, salt) + 0.3f * pn(x, y, 8, salt + 1) + 0.2f * pn(x, y, 4, salt + 2)

    private fun rgb(r: Int, g: Int, b: Int): Int = (255 shl 24) or (r shl 16) or (g shl 8) or b

    private fun channel(v: Float): Int = if (v < 0f) 0 else if (v > 255f) 255 else v.toInt()

    private fun mul(c: Int, f: Float): Int {
        val a = c ushr 24
        val r = channel(((c shr 16) and 0xFF) * f)
        val g = channel(((c shr 8) and 0xFF) * f)
        val b = channel((c and 0xFF) * f)
        return (a shl 24) or (r shl 16) or (g shl 8) or b
    }

    private fun lerpc(a: Int, b: Int, t: Float): Int {
        val aa = a ushr 24
        val ar = (a shr 16) and 0xFF
        val ag = (a shr 8) and 0xFF
        val ab = a and 0xFF
        val ba = b ushr 24
        val br = (b shr 16) and 0xFF
        val bg = (b shr 8) and 0xFF
        val bb = b and 0xFF
        val oa = channel(aa + (ba - aa) * t)
        val or_ = channel(ar + (br - ar) * t)
        val og = channel(ag + (bg - ag) * t)
        val ob = channel(ab + (bb - ab) * t)
        return (oa shl 24) or (or_ shl 16) or (og shl 8) or ob
    }

    /** Colour at [t0] (0..1, clamped) along a palette, blending linearly between entries. */
    private fun pal(p: IntArray, t0: Float): Int {
        val t = if (t0 < 0f) 0f else if (t0 > 0.999f) 0.999f else t0
        val f = t * (p.size - 1)
        val i = f.toInt()
        return lerpc(p[i], p[i + 1], f - i)
    }
}
