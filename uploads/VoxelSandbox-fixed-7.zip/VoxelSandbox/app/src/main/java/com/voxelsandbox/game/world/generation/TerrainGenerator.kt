package com.voxelsandbox.game.world.generation

import com.voxelsandbox.game.world.BlockType
import com.voxelsandbox.game.world.Chunk
import com.voxelsandbox.game.world.ChunkPos
import com.voxelsandbox.game.world.WorldConfig
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin

/** A good place to start a new world: dry, gentle ground well away from the shore. */
class SpawnPoint(val x: Int, val z: Int)

/**
 * Deterministic seeded terrain generator: the same (seed, chunkX, chunkZ) always
 * produces the same chunk, which is what lets SaveManager store only player-modified
 * chunks and regenerate everything else from the seed on load.
 *
 * The landscape itself lives in [TerrainShape] (height) and [Climate] (temperature,
 * humidity, surface type); this class turns those pure functions into blocks:
 * layered soil per surface type, plants, cacti and trees.
 *
 * Trees are placed without any neighbour coordination and still cross chunk borders
 * cleanly: every chunk independently evaluates the (pure, position-hashed) tree
 * candidates in its own area *plus a margin*, and writes only the tree blocks that fall
 * inside itself. A canopy that straddles a border is therefore assembled from the same
 * deterministic tree by both chunks, with no cross-chunk writes and no races. The
 * terrain height is a pure function of (x, z), so a chunk can also ask "how high is the
 * ground under that neighbouring tree" without the neighbour existing.
 */
class TerrainGenerator(private val seed: Long) {
    /** Land-form (height); also sampled directly by the distant-terrain builder. */
    val shape = TerrainShape(seed)

    /** Temperature / humidity / surface type; also sampled by the distant-terrain builder. */
    val climate = Climate(seed)

    private val oreNoise = NoiseGenerator(mixSeed(seed, 20))
    private val seedMix: Int = seed.toInt() * 1274126177
    private val trees = TreeBuilder(seedMix)

    fun generate(pos: ChunkPos): Chunk {
        val chunk = Chunk(pos)
        val size = WorldConfig.CHUNK_SIZE
        val baseX = pos.x * size
        val baseZ = pos.z * size

        // Ground heights for the chunk plus a one-block border, so the slope of edge
        // columns is exact without needing the neighbouring chunks.
        val g = size + 2
        val heights = IntArray(g * g)
        for (gz in 0 until g) {
            for (gx in 0 until g) {
                heights[gz * g + gx] = surfaceHeight(baseX + gx - 1, baseZ + gz - 1)
            }
        }

        for (lz in 0 until size) {
            for (lx in 0 until size) {
                val i = (lz + 1) * g + (lx + 1)
                val rise = max(abs(heights[i + 1] - heights[i - 1]), abs(heights[i + g] - heights[i - g]))
                fillColumn(chunk, lx, lz, baseX + lx, baseZ + lz, heights[i], rise * 0.5)
            }
        }
        placeTrees(ChunkCanvas(chunk, baseX, baseZ), baseX, baseZ)
        return chunk
    }

    /** Y of the topmost solid block at (wx, wz). Pure function of position; the
     *  distant-terrain builder samples it directly without generating any chunk. */
    fun surfaceHeight(wx: Int, wz: Int): Int = floor(shape.height(wx.toDouble(), wz.toDouble())).toInt()

    /** Forest-ness in 0..1 (0 = open plains, 1 = dense forest). */
    fun forestFactor(wx: Int, wz: Int): Double = climate.forest(wx.toDouble(), wz.toDouble())

    // ---- Spawn ------------------------------------------------------------------------------

    /**
     * Searches outward from the origin, ring by ring, for the nearest pleasant spot to
     * start: dry gentle grassland with no water or cliff within a few blocks. Pure and
     * deterministic, so a world always starts in the same place for the same seed.
     */
    fun findSpawn(): SpawnPoint {
        for (ring in 0..SPAWN_MAX_RINGS) {
            val radius = ring * SPAWN_STEP
            val count = if (ring == 0) 1 else max(8, (2.0 * PI * radius / SPAWN_STEP).toInt())
            val phase = ring * 0.61
            for (k in 0 until count) {
                val a = phase + 2.0 * PI * k / count
                val x = (radius * cos(a)).roundToInt()
                val z = (radius * sin(a)).roundToInt()
                if (isGoodSpawn(x, z)) return SpawnPoint(x, z)
            }
        }
        return SpawnPoint(0, 0)
    }

    private fun isGoodSpawn(x: Int, z: Int): Boolean {
        val sea = WorldConfig.SEA_LEVEL
        val h = surfaceHeight(x, z)
        if (h < sea + 3 || h > sea + 24) return false
        var i = 0
        while (i < SPAWN_PROBES.size) {
            val h2 = surfaceHeight(x + SPAWN_PROBES[i], z + SPAWN_PROBES[i + 1])
            if (h2 < sea + 1 || abs(h2 - h) > 5) return false
            i += 2
        }
        val kind = surfaceKindAt(x, z, h)
        return kind == SurfaceKind.GRASS || kind == SurfaceKind.DRY_GRASS
    }

    // ---- Surface ----------------------------------------------------------------------------

    /** Surface type of the dry ground at (wx, wz), whose top block is at [height]. Measures
     *  the slope itself (four extra height samples), so use it for sparse queries only. */
    private fun surfaceKindAt(wx: Int, wz: Int, height: Int): SurfaceKind {
        val rise = max(
            abs(surfaceHeight(wx + 1, wz) - surfaceHeight(wx - 1, wz)),
            abs(surfaceHeight(wx, wz + 1) - surfaceHeight(wx, wz - 1))
        )
        val x = wx.toDouble()
        val z = wz.toDouble()
        val h = height.toDouble()
        return climate.classify(x, z, h, rise * 0.5, climate.temperature(x, z, h), climate.humidity(x, z))
    }

    private fun fillColumn(chunk: Chunk, lx: Int, lz: Int, wx: Int, wz: Int, height: Int, slope: Double) {
        val sea = WorldConfig.SEA_LEVEL
        val x = wx.toDouble()
        val z = wz.toDouble()
        val h = height.toDouble()
        val temp = climate.temperature(x, z, h)
        val humid = climate.humidity(x, z)

        var kind = SurfaceKind.GRASS
        var topBlock = BlockType.GRASS
        var soilBlock = BlockType.DIRT
        var soilLayers = 3
        var strataBlock = BlockType.STONE
        var strataLayers = 0

        if (height < sea) {
            // Sea / lake / river bed: sand in the shallows, gravel in the deep.
            val deep = sea - height > 8
            topBlock = if (deep) BlockType.GRAVEL else BlockType.SAND
            soilBlock = topBlock
            soilLayers = 2
        } else {
            kind = climate.classify(x, z, h, slope, temp, humid)
            when (kind) {
                SurfaceKind.GRASS -> {}
                SurfaceKind.DRY_GRASS -> topBlock = BlockType.DRY_GRASS
                SurfaceKind.DESERT -> {
                    topBlock = BlockType.SAND
                    soilBlock = BlockType.SAND
                    soilLayers = 3
                    strataBlock = BlockType.SANDSTONE
                    strataLayers = 4
                }
                SurfaceKind.BEACH -> {
                    topBlock = BlockType.SAND
                    soilBlock = BlockType.SAND
                    soilLayers = 2
                }
                SurfaceKind.SNOW -> topBlock = BlockType.SNOW
                SurfaceKind.ROCK -> {
                    topBlock = BlockType.STONE
                    soilBlock = BlockType.STONE
                    soilLayers = 0
                }
                SurfaceKind.GRAVEL -> {
                    topBlock = BlockType.GRAVEL
                    soilBlock = BlockType.GRAVEL
                    soilLayers = 2
                }
            }
        }

        val topY = max(height, sea)
        for (y in 0..topY) {
            val block: BlockType = when {
                y > height -> BlockType.WATER // only below sea level (height < y <= sea)
                y == height -> topBlock
                y == 0 -> BlockType.STONE
                else -> {
                    val depth = height - y
                    when {
                        depth <= soilLayers -> soilBlock
                        depth <= soilLayers + strataLayers -> strataBlock
                        isCoalOre(wx, y, wz) -> BlockType.COAL_ORE
                        else -> BlockType.STONE
                    }
                }
            }
            chunk.setBlock(lx, y, lz, block)
        }

        if (height >= sea && height + 2 < WorldConfig.WORLD_HEIGHT) {
            scatterPlants(chunk, lx, lz, wx, wz, height, kind, humid)
        }
    }

    private fun isCoalOre(wx: Int, y: Int, wz: Int): Boolean {
        if (y > WorldConfig.SEA_LEVEL - 4) return false
        val n = oreNoise.noise2D(wx * 0.35 + y * 0.7, wz * 0.35 - y * 0.4)
        return n > 0.90
    }

    // ---- Ground cover ---------------------------------------------------------------------

    /** Grass tufts, flowers, dead bushes and cacti on top of the ground block. */
    private fun scatterPlants(chunk: Chunk, lx: Int, lz: Int, wx: Int, wz: Int, height: Int, kind: SurfaceKind, humid: Double) {
        val bits = hash3(wx, 7, wz)
        val u = ((bits ushr 8) and 0xFFFF) / 65536.0
        val y = height + 1
        when (kind) {
            SurfaceKind.GRASS -> {
                val tufts = 0.10 + 0.14 * (humid + 1.0) * 0.5 // thicker in wet country
                if (u < tufts) {
                    chunk.setBlock(lx, y, lz, BlockType.TALL_GRASS)
                } else if (u < tufts + 0.014) {
                    chunk.setBlock(lx, y, lz, if ((bits and 1) == 0) BlockType.POPPY else BlockType.DANDELION)
                }
            }
            SurfaceKind.DRY_GRASS -> {
                if (u < 0.09) {
                    chunk.setBlock(lx, y, lz, BlockType.TALL_GRASS)
                } else if (u < 0.10) {
                    chunk.setBlock(lx, y, lz, BlockType.DEAD_BUSH)
                }
            }
            SurfaceKind.DESERT -> {
                if (u < 0.012) {
                    chunk.setBlock(lx, y, lz, BlockType.DEAD_BUSH)
                } else if (u < 0.019) {
                    val cactusHeight = 1 + ((bits ushr 3) and 3) % 3
                    for (k in 0 until cactusHeight) chunk.setBlock(lx, y + k, lz, BlockType.CACTUS)
                }
            }
            else -> {}
        }
    }

    // ---- Trees ----------------------------------------------------------------------------

    private fun placeTrees(canvas: ChunkCanvas, baseX: Int, baseZ: Int) {
        val size = WorldConfig.CHUNK_SIZE
        val minCellX = Math.floorDiv(baseX - TREE_REACH, CELL)
        val maxCellX = Math.floorDiv(baseX + size - 1 + TREE_REACH, CELL)
        val minCellZ = Math.floorDiv(baseZ - TREE_REACH, CELL)
        val maxCellZ = Math.floorDiv(baseZ + size - 1 + TREE_REACH, CELL)

        for (cz in minCellZ..maxCellZ) {
            for (cx in minCellX..maxCellX) {
                // Deterministic per-4x4 cell: at most one tree candidate at a hash-chosen spot.
                val th = cellHash(cx, cz)
                val wx = cx * CELL + ((th ushr 8) and 3)
                val wz = cz * CELL + ((th ushr 10) and 3)
                if (wx < baseX - TREE_REACH || wx >= baseX + size + TREE_REACH) continue
                if (wz < baseZ - TREE_REACH || wz >= baseZ + size + TREE_REACH) continue

                val forest = forestFactor(wx, wz)
                val chance = 0.02 + 0.30 * forest * forest // sparse in open ground, thick in forests
                if ((th and 0xFF) >= (chance * 256.0).toInt()) continue

                val ground = surfaceHeight(wx, wz)
                if (ground <= WorldConfig.SEA_LEVEL + 2) continue // beaches / shallows stay bare
                val species = pickSpecies(wx, wz, ground, th) ?: continue
                trees.grow(canvas, species, wx, wz, ground, th)
            }
        }
    }

    /** Which tree (if any) grows at this candidate spot; depends on surface and climate. */
    private fun pickSpecies(wx: Int, wz: Int, ground: Int, th: Int): TreeSpecies? {
        val x = wx.toDouble()
        val z = wz.toDouble()
        val temp = climate.temperature(x, z, ground.toDouble())
        val kind = surfaceKindAt(wx, wz, ground)
        val roll = (th ushr 12) and 0xFF
        return when (kind) {
            SurfaceKind.GRASS -> when {
                temp < -0.12 || ground >= WorldConfig.SEA_LEVEL + 34 -> if (roll < 225) TreeSpecies.SPRUCE else TreeSpecies.BIRCH
                temp > 0.30 -> if (roll < 215) TreeSpecies.OAK else TreeSpecies.BIRCH
                else -> if (roll < 170) TreeSpecies.OAK else TreeSpecies.BIRCH
            }
            SurfaceKind.DRY_GRASS -> if (roll < 64) TreeSpecies.OAK else null // sparse savanna trees
            SurfaceKind.SNOW -> if (roll < 150) TreeSpecies.SPRUCE else null
            else -> null // desert, scree, bare rock and beaches have no trees
        }
    }

    private fun cellHash(x: Int, z: Int): Int {
        var h = x * 374761393 + z * 668265263 + seed.toInt() * 1274126177
        h = (h xor (h ushr 13)) * -1028477387
        return h xor (h ushr 16)
    }

    private fun hash3(x: Int, y: Int, z: Int): Int {
        var h = x * 374761393 + y * 668265263 + z * 1274126177 + seedMix
        h = (h xor (h ushr 13)) * -1028477387
        return h xor (h ushr 16)
    }

    private companion object {
        const val CELL = 4

        /** Widest a canopy ever reaches from its trunk, plus one block of slack. */
        const val TREE_REACH = 4

        const val SPAWN_STEP = 24
        const val SPAWN_MAX_RINGS = 120

        /** (dx, dz) pairs probed around a candidate spawn: all must be dry and level-ish. */
        val SPAWN_PROBES = intArrayOf(6, 0, -6, 0, 0, 6, 0, -6, 5, 5, -5, 5, 5, -5, -5, -5)
    }
}
