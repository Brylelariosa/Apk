#!/usr/bin/env python3
"""Synthesises the cube turn sounds (res/raw/turn_slide_*.wav and turn_click_*.wav). No recordings are used: every
sample is built here from damped resonances (the plastic shell), a short noise burst (the impact) and shaped noise
(the layer sliding), so the sounds are reproducible and carry no licence.

  python3 tests/sound/make_sounds.py app/src/main/res/raw          # writes the six WAV files
  python3 tests/sound/make_sounds.py /tmp/sounds --report          # also prints level / spectrum figures

Needs only numpy. 44.1 kHz, 16 bit, mono.
"""
import sys, os, wave
import numpy as np

SR = 44100


def band(x, lo, hi, soft=0.25):
    """Smooth band-pass by FFT masking: pass [lo, hi] Hz, edges eased over `soft` of their frequency."""
    n = len(x)
    f = np.fft.rfftfreq(n, 1.0 / SR)
    m = np.ones_like(f)
    if lo > 0:
        m *= np.clip((f - lo * (1 - soft)) / (lo * 2 * soft), 0, 1)
    if hi < SR / 2:
        m *= np.clip((hi * (1 + soft) - f) / (hi * 2 * soft), 0, 1)
    return np.fft.irfft(np.fft.rfft(x) * m, n)


def smooth(t, a, b):
    u = np.clip((t - a) / (b - a), 0, 1)
    return u * u * (3 - 2 * u)


def click(seed, bright=1.0, thock=1.0, length=0.06):
    """The dry plastic click of a layer seating: a few tiny knocks of band-limited noise a few ms apart (the pieces
    touching and rebounding) over a soft low-mid 'thock'. No sustained tones, so there is no ring or boing and pitching
    it up or down a little still sounds like plastic."""
    rng = np.random.default_rng(seed)
    n = int(length * SR)
    t = np.arange(n) / SR
    x = np.zeros(n)
    # (delay s, gain, decay s, centre Hz, width Hz): the main knock, then two smaller rebounds
    for delay, gain, tau, fc, bw in [(0.0, 1.00, 0.0022, 3300, 2800), (0.0036, 0.42, 0.0016, 2700, 2300), (0.0088, 0.20, 0.0012, 3900, 2500)]:
        d = int(delay * SR)
        tt = t[: n - d]
        noise = band(rng.standard_normal(len(tt)), max(600.0, fc * bright - bw / 2), fc * bright + bw / 2)
        noise /= np.std(noise)
        x[d:] += gain * noise * np.exp(-tt / tau) * (1 - np.exp(-tt / 0.00008))
    body = band(rng.standard_normal(n), 260, 950)
    body = body / np.std(body) * 0.45 * thock * np.exp(-t / 0.0065) * (1 - np.exp(-t / 0.0004))
    x = band(x + body, 170, 9500, 0.2)
    x *= 1 - smooth(t, length - 0.012, length)
    return x / np.max(np.abs(x)) * 0.8


def slide(seed, length=0.22, speed=1.0):
    """The layer sliding round: shaped noise with a ratchet texture (the pieces passing the core), quiet and soft."""
    rng = np.random.default_rng(seed)
    n = int(length * SR)
    t = np.arange(n) / SR
    hiss = band(rng.standard_normal(n), 1300, 6200)
    rumble = band(rng.standard_normal(n), 90, 520)
    # grit: random tiny contacts, each a few ms of high-passed noise
    grit = np.zeros(n)
    count = int(950 * length * speed)
    for p in rng.integers(0, n - 160, count):
        k = np.arange(160)
        grit[p:p + 160] += rng.uniform(0.2, 1.0) * rng.standard_normal(160) * np.exp(-k / 38.0)
    grit = band(grit, 1800, 8000)
    ratchet = 0.62 + 0.38 * np.sin(2 * np.pi * 93 * speed * t + rng.uniform(0, 6.28)) * np.sin(2 * np.pi * 57 * speed * t + rng.uniform(0, 6.28))
    env = smooth(t, 0.0, 0.03) * (1 - smooth(t, length - 0.06, length)) * (0.62 + 0.38 * np.sin(np.pi * t / length))
    x = (0.5 * hiss / np.std(hiss) + 0.7 * grit / np.std(grit) + 0.28 * rumble / np.std(rumble)) * ratchet * env
    # the faint tick as the layer lets go of its seat
    tick = click(seed + 100, bright=1.2, thock=0.4, length=0.03)
    x[: len(tick)] += 0.55 * tick * np.max(np.abs(x)) / 0.85
    return x / np.max(np.abs(x)) * 0.42


def write(path, x):
    pcm = np.clip(x, -1, 1)
    with wave.open(path, 'wb') as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes((pcm * 32767).astype('<i2').tobytes())


def main():
    out = sys.argv[1] if len(sys.argv) > 1 else '.'
    os.makedirs(out, exist_ok=True)
    clicks = [click(11, bright=1.00, thock=1.00),
              click(23, bright=0.86, thock=1.25),
              click(37, bright=1.16, thock=0.80)]
    slides = [slide(5, speed=1.0), slide(9, speed=0.9), slide(14, speed=1.1)]
    for i, x in enumerate(clicks, 1):
        write(os.path.join(out, f'turn_click_{i}.wav'), x)
    for i, x in enumerate(slides, 1):
        write(os.path.join(out, f'turn_slide_{i}.wav'), x)
    if '--report' in sys.argv:
        for name, x in [(f'click_{i}', c) for i, c in enumerate(clicks, 1)] + [(f'slide_{i}', s) for i, s in enumerate(slides, 1)]:
            f = np.fft.rfftfreq(len(x), 1 / SR)
            mag = np.abs(np.fft.rfft(x))
            cen = float((f * mag).sum() / mag.sum())
            rms = float(np.sqrt(np.mean(x ** 2)))
            print(f'{name}: {len(x) / SR * 1000:.0f} ms, peak {np.max(np.abs(x)):.2f}, rms {rms:.3f}, spectral centroid {cen:.0f} Hz')


if __name__ == '__main__':
    main()
