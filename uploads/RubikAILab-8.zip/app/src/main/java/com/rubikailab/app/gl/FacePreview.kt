package com.rubikailab.app.gl

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.MotionEvent
import android.view.View
import com.rubikailab.app.core.PuzzleModel
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * A strip of small flat pictures, one per face of the puzzle, showing the colours that face has right now.
 * Tapping a picture swings the main view round to look straight at that face. The pictures are drawn from the
 * same sticker polygons as the 3D view, so they work for every puzzle.
 */
class FacePreview(context: Context, private val target: PuzzleView) : View(context) {

    private var model: PuzzleModel? = null

    /** Per sticker, up to four corners as (x, y) in 0..1 inside its face's picture, y pointing down. */
    private var pts = FloatArray(0)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG)
    private val back = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val density = resources.displayMetrics.density
    private val cell = density * 46f
    private val gap = density * 6f

    init {
        fill.style = Paint.Style.FILL
        edge.style = Paint.Style.STROKE
        edge.strokeWidth = density * 1.2f
        edge.color = Color.rgb(10, 12, 17)
        back.style = Paint.Style.FILL
        back.color = Color.argb(190, 10, 12, 17)
    }

    /** Lays out one picture per face of [m]. */
    fun bind(m: PuzzleModel) {
        model = m
        pts = FloatArray(m.stickers * 8)
        for (f in 0 until m.faces) {
            var first = -1
            for (i in 0 until m.stickers) {
                if (m.faceOf[i] == f) {
                    first = i
                    break
                }
            }
            if (first < 0) continue
            val nx = m.normals[first * 3]
            val ny = m.normals[first * 3 + 1]
            val nz = m.normals[first * 3 + 2]
            // Screen basis for a viewer in front of the face: right x up = normal.
            var ux = 0f
            var uy = 1f
            var uz = 0f
            if (abs(ny) > 0.9f) {
                uy = 0f
                uz = -1f
            }
            val d = ux * nx + uy * ny + uz * nz
            ux -= nx * d
            uy -= ny * d
            uz -= nz * d
            val ul = sqrt(ux * ux + uy * uy + uz * uz)
            ux /= ul
            uy /= ul
            uz /= ul
            val rx = uy * nz - uz * ny
            val ry = uz * nx - ux * nz
            val rz = ux * ny - uy * nx
            var x0 = Float.MAX_VALUE
            var x1 = -Float.MAX_VALUE
            var y0 = Float.MAX_VALUE
            var y1 = -Float.MAX_VALUE
            for (i in 0 until m.stickers) {
                if (m.faceOf[i] != f) continue
                for (k in 0 until m.cornerCount[i]) {
                    val c = i * 12 + k * 3
                    val px = m.corners[c] * rx + m.corners[c + 1] * ry + m.corners[c + 2] * rz
                    val py = m.corners[c] * ux + m.corners[c + 1] * uy + m.corners[c + 2] * uz
                    x0 = min(x0, px)
                    x1 = max(x1, px)
                    y0 = min(y0, py)
                    y1 = max(y1, py)
                }
            }
            val scale = 1f / max(max(x1 - x0, y1 - y0), 1.0e-4f)
            val mx = (x0 + x1) * 0.5f
            val my = (y0 + y1) * 0.5f
            for (i in 0 until m.stickers) {
                if (m.faceOf[i] != f) continue
                for (k in 0 until min(4, m.cornerCount[i])) {
                    val c = i * 12 + k * 3
                    val px = m.corners[c] * rx + m.corners[c + 1] * ry + m.corners[c + 2] * rz
                    val py = m.corners[c] * ux + m.corners[c + 1] * uy + m.corners[c + 2] * uz
                    pts[i * 8 + k * 2] = 0.5f + (px - mx) * scale
                    pts[i * 8 + k * 2 + 1] = 0.5f - (py - my) * scale
                }
            }
        }
        requestLayout()
        invalidate()
    }

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        val n = model?.faces ?: 0
        setMeasuredDimension((n * cell + max(0, n - 1) * gap).toInt(), cell.toInt())
    }

    override fun onDraw(canvas: Canvas) {
        val m = model ?: return
        val state = target.renderer.snapshot()
        if (state.size != m.stickers) return
        val pad = cell * 0.09f
        val size = cell - 2f * pad
        for (f in 0 until m.faces) {
            val left = f * (cell + gap)
            canvas.drawRoundRect(left, 0f, left + cell, cell, density * 8f, density * 8f, back)
            for (i in 0 until m.stickers) {
                if (m.faceOf[i] != f) continue
                path.rewind()
                val n = min(4, m.cornerCount[i])
                for (k in 0 until n) {
                    val x = left + pad + pts[i * 8 + k * 2] * size
                    val y = pad + pts[i * 8 + k * 2 + 1] * size
                    if (k == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                path.close()
                val c = m.palette[state[i].toInt().coerceIn(0, m.colors - 1)]
                fill.color = Color.rgb((c[0] * 255f).toInt(), (c[1] * 255f).toInt(), (c[2] * 255f).toInt())
                canvas.drawPath(path, fill)
                canvas.drawPath(path, edge)
            }
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val m = model ?: return false
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> return true
            MotionEvent.ACTION_UP -> {
                val f = (event.x / (cell + gap)).toInt()
                val inside = event.x - f * (cell + gap) <= cell
                if (inside && f in 0 until m.faces) target.lookAtFace(f)
                return true
            }
        }
        return true
    }
}
