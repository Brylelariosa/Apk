package com.rubikailab.app.gl

import android.content.Context
import android.opengl.GLSurfaceView
import android.os.SystemClock
import android.view.MotionEvent
import android.view.ViewConfiguration
import com.rubikailab.app.core.PuzzleModel
import com.rubikailab.app.core.Puzzles

/**
 * GLSurfaceView hosting [PuzzleRenderer].
 *
 * Gestures (when [turnable] is on): a drag that starts on the puzzle, including its dark lines, and is long
 * enough turns the layer that carries the touched sticker the way the finger moved, and never spins the
 * view; a drag that starts on the empty background orbits the camera. With [orbitMode] on, every drag
 * orbits. When [turnable] is off the view only orbits (used by the watch-the-AI view).
 *
 * The Skewb is more forgiving, because its corner pieces are small triangles at the very edge of the picture: a
 * finger that lands within a fingertip of a corner piece counts as touching it, and a tap on a corner twists it
 * clockwise, a press-and-hold the other way, so a corner can be turned without choosing a drag direction.
 *
 * [onUserMove] is called on the UI thread with the move the player asked for; the owner applies it to
 * its own state and enqueues it on [renderer]. [onMoveDone] is delivered on the UI thread each time an
 * animated turn has finished.
 */
class PuzzleView(
    context: Context,
    private val onUserMove: (Int) -> Unit,
    onMoveDone: (Int) -> Unit
) : GLSurfaceView(context) {

    val renderer: PuzzleRenderer

    /** Whether swipes on the puzzle may turn layers. */
    var turnable = true

    /** When true every drag orbits the camera, even one that starts on the puzzle. */
    var orbitMode = false

    /** Optional strip of face pictures that is kept in step with the puzzle. */
    var facePreview: FacePreview? = null

    private var model: PuzzleModel? = null
    private var flight: Runnable? = null
    private var picker: Picker? = null
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var picked = -1
    private var mode = IDLE
    private var tapAllowed = true
    private var infoText = ""
    private val slop: Float
    private val reach: Float

    init {
        setEGLContextClientVersion(2)
        preserveEGLContextOnPause = true
        renderer = PuzzleRenderer({ requestRender() }, { move -> post { onMoveDone(move) } })
        setRenderer(renderer)
        renderMode = RENDERMODE_WHEN_DIRTY
        renderer.onDisplayChanged = { post { facePreview?.invalidate() } }
        slop = maxOf(context.resources.displayMetrics.density * 14f, ViewConfiguration.get(context).scaledTouchSlop * 1.5f)
        reach = context.resources.displayMetrics.density * 16f
    }

    /** Debug aid: when set, receives a short text about every touch (what it hit, what it did); the Play page shows it. */
    var touchInfo: ((String) -> Unit)? = null

    /** Adds a line to the touch info of the current touch, when the info is on. */
    fun reportTouch(line: String) {
        val info = touchInfo ?: return
        infoText = infoText + "\n" + line
        info(infoText)
    }

    private fun moveLabel(move: Int): String {
        val m = model
        return if (move >= 0 && m != null) m.moveNames[move] else "no move"
    }

    /** Shows [puzzle] in the given [state]. */
    fun setPuzzle(puzzle: PuzzleModel, state: ByteArray) {
        picker = Picker(puzzle)
        model = puzzle
        facePreview?.bind(puzzle)
        renderer.setPuzzle(puzzle, state)
    }

    /** Tells the view how many pixels at its top and bottom are covered by floating bars (the puzzle centres between them). */
    fun setFreeArea(top: Int, bottom: Int) {
        if (renderer.freeTop == top.toFloat() && renderer.freeBottom == bottom.toFloat()) return
        renderer.freeTop = top.toFloat()
        renderer.freeBottom = bottom.toFloat()
        requestRender()
    }

    /** Swings the camera round to look straight at face [face] of the puzzle. */
    fun lookAtFace(face: Int) {
        val m = model ?: return
        var s = -1
        for (i in 0 until m.stickers) {
            if (m.faceOf[i] == face) {
                s = i
                break
            }
        }
        if (s < 0) return
        val nx = m.normals[s * 3].toDouble()
        val ny = m.normals[s * 3 + 1].toDouble()
        val nz = m.normals[s * 3 + 2].toDouble()
        val h = Math.hypot(nx, nz)
        val fromYaw = renderer.yaw
        val fromPitch = renderer.pitch
        // The view turns points by pitch about x after yaw about y; these angles bring the normal to the camera.
        val toYaw = if (h > 1.0e-4) Math.toDegrees(Math.atan2(-nx, nz)).toFloat() else fromYaw
        val toPitch = Math.toDegrees(Math.atan2(ny, h)).toFloat()
        val dYaw = shortest(toYaw - fromYaw)
        val dPitch = shortest(toPitch - fromPitch)
        stopFlight()
        val start = SystemClock.uptimeMillis()
        val step = object : Runnable {
            override fun run() {
                val t = ((SystemClock.uptimeMillis() - start).toFloat() / FLIGHT_MS).coerceIn(0f, 1f)
                val e = t * t * (3f - 2f * t)
                renderer.yaw = fromYaw + dYaw * e
                renderer.pitch = fromPitch + dPitch * e
                requestRender()
                if (t < 1f) postOnAnimation(this) else flight = null
            }
        }
        flight = step
        postOnAnimation(step)
    }

    private fun shortest(a: Float): Float {
        var v = a % 360f
        if (v > 180f) v -= 360f
        if (v < -180f) v += 360f
        return v
    }

    private fun stopFlight() {
        val f = flight
        if (f != null) removeCallbacks(f)
        flight = null
    }

    override fun onDetachedFromWindow() {
        stopFlight()
        super.onDetachedFromWindow()
    }

    override fun onResume() {
        super.onResume()
        requestRender()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                tapAllowed = flight == null // a touch that only stops the swing to a face is not a tap
                stopFlight()
                downX = event.x
                downY = event.y
                lastX = event.x
                lastY = event.y
                mode = UNDECIDED
                picked = -1
                val p = picker
                val puzzle = model
                if (turnable && !orbitMode && p != null) {
                    p.setCamera(width, height, renderer.yaw, renderer.pitch, renderer.freeTop, renderer.freeBottom)
                    picked = p.pick(event.x, event.y)
                    if (picked < 0 && puzzle != null && puzzle.id == Puzzles.SKEWB) {
                        picked = p.pickNear(event.x, event.y, reach)
                    }
                    val info = touchInfo
                    if (info != null) {
                        infoText = "Touch " + event.x.toInt() + "," + event.y.toInt() + " in " + width + "x" + height +
                            " (surface " + renderer.surfaceSize + ", free " + renderer.freeTop.toInt() + "/" + renderer.freeBottom.toInt() +
                            ", view " + renderer.yaw.toInt() + "/" + renderer.pitch.toInt() + ")\n" +
                            p.describeTouch(event.x, event.y, picked)
                        info(infoText)
                    }
                } else {
                    val info = touchInfo
                    if (info != null) {
                        infoText = "Touch not used for turning: " + (if (orbitMode) "Rotate view is on" else "turning is off")
                        info(infoText)
                    }
                }
                parent?.requestDisallowInterceptTouchEvent(true)
            }
            MotionEvent.ACTION_MOVE -> {
                if (mode == UNDECIDED) {
                    val dx = event.x - downX
                    val dy = event.y - downY
                    if (dx * dx + dy * dy >= slop * slop) {
                        val p = picker
                        if (picked >= 0 && p != null) {
                            // The finger went down on the puzzle: this drag turns a layer or does nothing,
                            // it never rotates the whole view.
                            mode = TURNED
                            val move = p.swipeMove(picked, dx, dy)
                            reportTouch("swipe " + dx.toInt() + "," + dy.toInt() + " -> " + moveLabel(move))
                            if (move >= 0) onUserMove(move)
                        } else {
                            mode = ORBIT
                            reportTouch("started on nothing, so the view orbits")
                            renderer.rotate(dx, dy)
                            lastX = event.x
                            lastY = event.y
                        }
                    }
                } else if (mode == ORBIT) {
                    renderer.rotate(event.x - lastX, event.y - lastY)
                    lastX = event.x
                    lastY = event.y
                }
            }
            MotionEvent.ACTION_UP -> {
                if (mode == UNDECIDED && picked >= 0 && tapAllowed) {
                    // The finger lifted before the drag was long enough to be a swipe: a tap or a hold on a Skewb corner.
                    val p = picker
                    if (p != null) {
                        val held = event.eventTime - event.downTime >= HOLD_MS
                        val move = p.tapMove(picked, held)
                        reportTouch((if (held) "hold" else "tap") + " -> " + moveLabel(move))
                        if (move >= 0) onUserMove(move)
                    }
                }
                mode = IDLE
                parent?.requestDisallowInterceptTouchEvent(false)
            }
            MotionEvent.ACTION_CANCEL -> {
                mode = IDLE
                parent?.requestDisallowInterceptTouchEvent(false)
            }
        }
        return true
    }

    private companion object {
        const val IDLE = 0
        const val UNDECIDED = 1
        const val TURNED = 2
        const val ORBIT = 3
        const val FLIGHT_MS = 300f
        const val HOLD_MS = 450L
    }
}
