package com.rubikailab.app.gl

import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.os.SystemClock
import android.util.Log
import com.rubikailab.app.core.PuzzleModel
import com.rubikailab.app.core.Puzzles
import java.nio.Buffer
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

/**
 * OpenGL ES 2.0 renderer for every puzzle.
 *
 * The scene is built from the native puzzle description (sticker polygons, dark body pieces, and the
 * axis / angle / layer of every move), the same data the move permutations were generated from, so what is
 * drawn always matches the simulated state. A turn animates the stickers and bodies of the turning layer
 * about the move's axis; when the animation ends the move is applied to the displayed state.
 *
 * Threading: public methods may be called from any thread; all drawing happens on the GL thread.
 */
class PuzzleRenderer(
    private val requestRender: () -> Unit,
    private val onMoveDone: (Int) -> Unit
) : GLSurfaceView.Renderer {

    private class Mesh(val buffer: FloatBuffer, val count: Int)

    private class Frame(
        val model: PuzzleModel?,
        val finished: Int,
        val angle: Float,
        val ax: Float,
        val ay: Float,
        val az: Float,
        val more: Boolean,
        val staticMesh: Mesh?,
        val movingMesh: Mesh?,
        val started: Int,
        val duration: Long
    )

    private class MeshBuilder {
        private var data = FloatArray(9 * 8192)
        private var size = 0

        fun vertex(x: Float, y: Float, z: Float, nx: Float, ny: Float, nz: Float, c: FloatArray) {
            if (size + 9 > data.size) data = data.copyOf(data.size * 2)
            data[size] = x
            data[size + 1] = y
            data[size + 2] = z
            data[size + 3] = nx
            data[size + 4] = ny
            data[size + 5] = nz
            data[size + 6] = c[0]
            data[size + 7] = c[1]
            data[size + 8] = c[2]
            size += 9
        }

        fun build(): Mesh {
            val fb = ByteBuffer.allocateDirect(size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
            fb.put(data, 0, size)
            return Mesh(fb, size / 9)
        }
    }

    private val lock = Any()
    private var model: PuzzleModel? = null
    private var display: ByteArray = ByteArray(0)
    private val queue = java.util.ArrayDeque<Int>()
    private var current = -1
    private var currentStart = 0L
    private var currentDuration = 260L
    private var version = 0
    private var builtVersion = -1
    private var staticMesh: Mesh? = null
    private var movingMesh: Mesh? = null

    @Volatile
    var yaw = DEFAULT_YAW

    @Volatile
    var pitch = DEFAULT_PITCH

    /** Pixels at the top and bottom of the view covered by the bars and buttons; the puzzle keeps clear of them. */
    @Volatile
    var freeTop = 0f

    @Volatile
    var freeBottom = 0f

    /** Animation speed multiplier: 1 = normal, larger = faster (used to show a scramble quickly). */
    @Volatile
    var speed = 1f

    /** Plays the cube sounds when a turn starts and when it ends; null keeps the view silent. */
    @Volatile
    var sound: TurnSound? = null

    private var program = 0
    private var aPos = 0
    private var aNormal = 0
    private var aColor = 0
    private var uVP = 0
    private var uModel = 0
    private var uNormalMat = 0

    private var viewW = 1
    private var viewH = 1

    /** The size of the drawing surface as text; only used by the touch-info debug line, to compare it with the view size. */
    val surfaceSize: String
        get() = viewW.toString() + "x" + viewH
    private val vp = FloatArray(16)
    private val orbit = FloatArray(16)
    private val layer = FloatArray(16)
    private val modelMat = FloatArray(16)
    private val normalMat = FloatArray(9)

    // ---------------------------------------------------------------- public API (any thread)

    /** Switches to another puzzle showing [state]; drops every queued animation. */
    fun setPuzzle(puzzle: PuzzleModel, state: ByteArray) {
        synchronized(lock) {
            if (model?.id != puzzle.id) {
                // A different puzzle starts in its own default view.
                yaw = Puzzles.viewYaw(puzzle.id)
                pitch = Puzzles.viewPitch(puzzle.id)
            }
            model = puzzle
            display = state.copyOf()
            queue.clear()
            current = -1
            version++
        }
        onDisplayChanged?.invoke()
        requestRender()
    }

    /** Shows [state] immediately and drops every queued animation. */
    fun setState(state: ByteArray) {
        synchronized(lock) {
            display = state.copyOf()
            queue.clear()
            current = -1
            version++
        }
        onDisplayChanged?.invoke()
        requestRender()
    }

    fun enqueue(move: Int) {
        synchronized(lock) { queue.addLast(move) }
        requestRender()
    }

    fun enqueueAll(moves: IntArray) {
        synchronized(lock) {
            for (m in moves) queue.addLast(m)
        }
        requestRender()
    }

    fun isAnimating(): Boolean = synchronized(lock) { current >= 0 || !queue.isEmpty() }

    /**
     * Turns the view by a drag. There is no limit: the view may go over the top and under the bottom. Once the
     * puzzle is upside down the sideways drag is mirrored, so it still follows the finger.
     */
    fun rotate(dx: Float, dy: Float) {
        val flip = if (Math.cos(Math.toRadians(pitch.toDouble())) < 0.0) -1f else 1f
        yaw = wrapAngle(yaw + dx * 0.45f * flip)
        pitch = wrapAngle(pitch + dy * 0.45f)
        requestRender()
    }

    private fun wrapAngle(a: Float): Float {
        var v = a % 360f
        if (v > 180f) v -= 360f
        if (v < -180f) v += 360f
        return v
    }

    /** A copy of the colours currently shown (for the face previews). */
    fun snapshot(): ByteArray = synchronized(lock) { display.copyOf() }

    /** Called (from any thread) whenever the shown colours change. */
    @Volatile
    var onDisplayChanged: (() -> Unit)? = null

    fun resetView() {
        val id = synchronized(lock) { model?.id }
        yaw = if (id != null) Puzzles.viewYaw(id) else DEFAULT_YAW
        pitch = if (id != null) Puzzles.viewPitch(id) else DEFAULT_PITCH
        requestRender()
    }

    // ---------------------------------------------------------------- GLSurfaceView.Renderer

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0.039f, 0.047f, 0.067f, 1f)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glDisable(GLES20.GL_CULL_FACE)
        program = buildProgram()
        if (program != 0) {
            aPos = GLES20.glGetAttribLocation(program, "aPos")
            aNormal = GLES20.glGetAttribLocation(program, "aNormal")
            aColor = GLES20.glGetAttribLocation(program, "aColor")
            uVP = GLES20.glGetUniformLocation(program, "uVP")
            uModel = GLES20.glGetUniformLocation(program, "uModel")
            uNormalMat = GLES20.glGetUniformLocation(program, "uNormalMat")
        }
        synchronized(lock) { builtVersion = -1 }
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
        viewW = maxOf(1, width)
        viewH = maxOf(1, height)
    }

    override fun onDrawFrame(gl: GL10?) {
        val f = advance()
        val snd = sound
        if (snd != null) {
            if (f.started >= 0) snd.turnStarted(f.duration)
            if (f.finished >= 0) snd.turnEnded(f.duration)
        }
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        val m = f.model
        if (program != 0 && m != null) {
            GLES20.glUseProgram(program)
            Camera.projectionView(vp, viewW, viewH, m.radius, freeTop, freeBottom)
            Camera.orbit(orbit, yaw, pitch)
            val sm = f.staticMesh
            if (sm != null && sm.count > 0) drawMesh(sm, orbit)
            val mm = f.movingMesh
            if (mm != null && mm.count > 0) {
                Matrix.setRotateM(layer, 0, f.angle, f.ax, f.ay, f.az)
                Matrix.multiplyMM(modelMat, 0, orbit, 0, layer, 0)
                drawMesh(mm, modelMat)
            }
        }
        if (f.finished >= 0) onMoveDone(f.finished)
        if (f.more) requestRender()
    }

    // ---------------------------------------------------------------- animation clock

    private fun advance(): Frame = synchronized(lock) {
        val m = model
        if (m == null) {
            return@synchronized Frame(null, -1, 0f, 0f, 0f, 1f, false, null, null, -1, 0L)
        }
        val now = SystemClock.uptimeMillis()
        var started = -1
        if (current < 0 && !queue.isEmpty()) {
            current = queue.pollFirst()
            started = current
            currentStart = now
            // The longer the backlog, the faster the turns, so long solutions do not drag on.
            val base = (780L / (3 + queue.size)).coerceIn(70L, 260L)
            currentDuration = (base.toFloat() / maxOf(0.25f, speed)).toLong().coerceAtLeast(35L)
            version++
        }
        var finished = -1
        var angle = 0f
        var ax = 0f
        var ay = 0f
        var az = 1f
        if (current >= 0) {
            val t = ((now - currentStart).toFloat() / currentDuration.toFloat()).coerceIn(0f, 1f)
            if (t >= 1f) {
                display = m.apply(display, current)
                finished = current
                current = -1
                version++
                onDisplayChanged?.invoke()
            } else {
                val eased = t * t * (3f - 2f * t)
                angle = m.angle[current] * eased
                ax = m.axis[current * 3]
                ay = m.axis[current * 3 + 1]
                az = m.axis[current * 3 + 2]
            }
        }
        if (builtVersion != version) {
            rebuild(m)
            builtVersion = version
        }
        Frame(m, finished, angle, ax, ay, az, current >= 0 || !queue.isEmpty(), staticMesh, movingMesh, started, currentDuration)
    }

    // ---------------------------------------------------------------- mesh building

    /** Rebuilds both meshes from [display] and [current]. Caller holds [lock]. */
    private fun rebuild(m: PuzzleModel) {
        val st = MeshBuilder()
        val mv = MeshBuilder()
        val turning = current
        addTriangles(st, m.core)
        for (b in m.bodies) {
            val moving = turning >= 0 && m.inLayer(turning, b.cx, b.cy, b.cz)
            addTriangles(if (moving) mv else st, b.tris)
        }
        if (display.size == m.stickers) {
            for (i in 0 until m.stickers) {
                val moving = turning >= 0 &&
                    m.inLayer(turning, m.centroids[i * 3], m.centroids[i * 3 + 1], m.centroids[i * 3 + 2])
                addSticker(if (moving) mv else st, m, i, display[i].toInt())
            }
        }
        staticMesh = st.build()
        movingMesh = mv.build()
    }

    /** 12 floats per triangle: three corners then the outward normal. */
    private fun addTriangles(mb: MeshBuilder, tris: FloatArray) {
        var i = 0
        while (i + 12 <= tris.size) {
            val nx = tris[i + 9]
            val ny = tris[i + 10]
            val nz = tris[i + 11]
            mb.vertex(tris[i], tris[i + 1], tris[i + 2], nx, ny, nz, BODY)
            mb.vertex(tris[i + 3], tris[i + 4], tris[i + 5], nx, ny, nz, BODY)
            mb.vertex(tris[i + 6], tris[i + 7], tris[i + 8], nx, ny, nz, BODY)
            i += 12
        }
    }

    /**
     * A coloured tile: the sticker polygon pulled in by a fixed margin (so every dark line is equally thin) with
     * rounded corners, lifted a hair off the piece it sits on. See [StickerShape].
     */
    private fun addSticker(mb: MeshBuilder, m: PuzzleModel, i: Int, colorId: Int) {
        val n = m.cornerCount[i]
        if (n < 3) return
        val nx = m.normals[i * 3]
        val ny = m.normals[i * 3 + 1]
        val nz = m.normals[i * 3 + 2]
        val col = m.palette[colorId.coerceIn(0, m.colors - 1)]
        val pts = StickerShape.outline(m.corners, i * 12, n, nx, ny, nz, m.stickerInset, m.stickerRound, m.stickerLift)
        val total = pts.size / 3
        var cx = 0f
        var cy = 0f
        var cz = 0f
        for (j in 0 until total) {
            cx += pts[j * 3]
            cy += pts[j * 3 + 1]
            cz += pts[j * 3 + 2]
        }
        cx /= total
        cy /= total
        cz /= total
        for (j in 0 until total) {
            val j2 = (j + 1) % total
            mb.vertex(cx, cy, cz, nx, ny, nz, col)
            mb.vertex(pts[j * 3], pts[j * 3 + 1], pts[j * 3 + 2], nx, ny, nz, col)
            mb.vertex(pts[j2 * 3], pts[j2 * 3 + 1], pts[j2 * 3 + 2], nx, ny, nz, col)
        }
    }

    // ---------------------------------------------------------------- drawing

    private fun seek(b: Buffer, position: Int) {
        b.position(position)
    }

    private fun drawMesh(mesh: Mesh, modelMatrix: FloatArray) {
        GLES20.glUniformMatrix4fv(uVP, 1, false, vp, 0)
        GLES20.glUniformMatrix4fv(uModel, 1, false, modelMatrix, 0)
        // Normal matrix = rotation part of the model matrix (the model is a pure rotation).
        normalMat[0] = modelMatrix[0]
        normalMat[1] = modelMatrix[1]
        normalMat[2] = modelMatrix[2]
        normalMat[3] = modelMatrix[4]
        normalMat[4] = modelMatrix[5]
        normalMat[5] = modelMatrix[6]
        normalMat[6] = modelMatrix[8]
        normalMat[7] = modelMatrix[9]
        normalMat[8] = modelMatrix[10]
        GLES20.glUniformMatrix3fv(uNormalMat, 1, false, normalMat, 0)

        val b = mesh.buffer
        seek(b, 0)
        GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, STRIDE, b)
        GLES20.glEnableVertexAttribArray(aPos)
        seek(b, 3)
        GLES20.glVertexAttribPointer(aNormal, 3, GLES20.GL_FLOAT, false, STRIDE, b)
        GLES20.glEnableVertexAttribArray(aNormal)
        seek(b, 6)
        GLES20.glVertexAttribPointer(aColor, 3, GLES20.GL_FLOAT, false, STRIDE, b)
        GLES20.glEnableVertexAttribArray(aColor)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, mesh.count)
    }

    private fun buildProgram(): Int {
        val vs = compile(GLES20.GL_VERTEX_SHADER, VERTEX_SHADER)
        val fs = compile(GLES20.GL_FRAGMENT_SHADER, FRAGMENT_SHADER)
        if (vs == 0 || fs == 0) return 0
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, vs)
        GLES20.glAttachShader(p, fs)
        GLES20.glLinkProgram(p)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) {
            Log.e(TAG, "program link failed: " + GLES20.glGetProgramInfoLog(p))
            GLES20.glDeleteProgram(p)
            return 0
        }
        return p
    }

    private fun compile(type: Int, source: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, source)
        GLES20.glCompileShader(s)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) {
            Log.e(TAG, "shader compile failed: " + GLES20.glGetShaderInfoLog(s))
            GLES20.glDeleteShader(s)
            return 0
        }
        return s
    }

    companion object {
        private const val TAG = "PuzzleRenderer"
        const val DEFAULT_YAW = -35f
        const val DEFAULT_PITCH = 28f

        private const val STRIDE = 9 * 4

        /** Dark plastic of the pieces: light enough to read against the background, dark enough to look black. */
        private val BODY = floatArrayOf(0.15f, 0.155f, 0.17f)

        private const val VERTEX_SHADER = """
uniform mat4 uVP;
uniform mat4 uModel;
uniform mat3 uNormalMat;
attribute vec3 aPos;
attribute vec3 aNormal;
attribute vec3 aColor;
varying vec3 vColor;
void main() {
  vec3 n = normalize(uNormalMat * aNormal);
  float diff = max(dot(n, normalize(vec3(0.35, 0.8, 0.6))), 0.0);
  vColor = aColor * (0.60 + 0.50 * diff);
  gl_Position = uVP * uModel * vec4(aPos, 1.0);
}
"""

        private const val FRAGMENT_SHADER = """
precision mediump float;
varying vec3 vColor;
void main() {
  gl_FragColor = vec4(vColor, 1.0);
}
"""
    }
}
