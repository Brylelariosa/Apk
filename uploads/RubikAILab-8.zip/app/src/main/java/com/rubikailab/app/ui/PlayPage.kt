package com.rubikailab.app.ui

import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.rubikailab.app.Lab
import com.rubikailab.app.R
import com.rubikailab.app.core.PuzzleCatalog
import com.rubikailab.app.core.PuzzleModel
import com.rubikailab.app.core.Puzzles
import com.rubikailab.app.core.SolveResult
import com.rubikailab.app.core.SolveStatus
import com.rubikailab.app.core.SolverMode
import com.rubikailab.app.gl.FacePreview
import com.rubikailab.app.gl.PuzzleView
import com.rubikailab.app.gl.TurnSound
import java.util.Random

/**
 * Tab 1: play. The puzzle fills the whole screen and everything you tap sits in one panel at the bottom: the puzzle
 * picker, the timer and move counter, the turn pad / rotate view / settings buttons, then Scramble, Reset and AI solve.
 * The top stays clear except for the face strip and short messages. Swipe the puzzle to turn it, drag the background
 * to look around. Scramble mixes it up, the timer starts with your first move and stops when it is solved.
 * "AI solve" asks the learned solver, which only ever sees the sticker colours, never the scramble.
 */
class PlayPage(context: Context) : PageView(context) {

    private val uiHandler = Handler(Looper.getMainLooper())
    private val rng = Random()

    private var model: PuzzleModel? = null
    private var state = ByteArray(0)
    private var moveCount = 0
    private var armed = false // a scramble is on the puzzle and the timer waits for the first move
    private var timing = false
    private var startMs = 0L
    private var busy = false // an animated scramble or AI solution is playing: player input is ignored
    private var pendingMoves = 0
    private var scrambling = false
    private var aiPlaying = false
    private var solving = false // waiting for the solver
    private var scrambleLen = 0
    private var aiSummary = ""
    private var turnSound: TurnSound? = null

    private val puzzleChip: TextView
    private val topSpace: View
    private val timerView: TextView
    private val movesView: TextView
    private val statusView: TextView
    private val orbitBtn: ImageView
    private val padToggle: ImageView
    private val barScroll: HorizontalScrollView
    private val barText: TextView
    private val padBox: LinearLayout
    private val puzzleView: PuzzleView
    private val faceStrip: FacePreview
    private val scrambleBtn: ActionButton
    private val resetBtn: ActionButton
    private val solveBtn: ActionButton

    init {
        // The puzzle view fills the whole page. The face strip and the short messages float at the top, one control
        // panel sits at the bottom, and the puzzle is sized to the free space between them.
        val stage = FrameLayout(context)
        addView(stage, lp(MATCH, 0, 1f))
        puzzleView = PuzzleView(context, { move -> onUserMove(move) }, { onMoveDone() })
        stage.addView(puzzleView, FrameLayout.LayoutParams(MATCH, MATCH))

        // Top: only the face strip and the messages. Nothing here needs reaching for.
        val topColumn = LinearLayout(context)
        topColumn.orientation = LinearLayout.VERTICAL
        topSpace = View(context)
        topColumn.addView(topSpace, lp(MATCH, context.dp(10)))
        faceStrip = FacePreview(context, puzzleView)
        puzzleView.facePreview = faceStrip
        val fp = LinearLayout.LayoutParams(WRAP, WRAP)
        fp.gravity = Gravity.CENTER_HORIZONTAL
        topColumn.addView(faceStrip, fp)

        // The status line also carries the hint on how to turn this puzzle.
        statusView = TextView(context)
        statusView.textSize = 13f
        statusView.setTextColor(Theme.TEXT)
        statusView.gravity = Gravity.CENTER
        statusView.setPadding(context.dp(14), context.dp(6), context.dp(14), context.dp(6))
        statusView.background = context.rounded(Theme.SCRIM, 16f)
        statusView.visibility = View.GONE
        val sp = LinearLayout.LayoutParams(WRAP, WRAP)
        sp.gravity = Gravity.CENTER_HORIZONTAL
        sp.setMargins(context.dp(12), context.dp(6), context.dp(12), 0)
        topColumn.addView(statusView, sp)

        // One-line strip for the scramble or the AI's solution.
        barText = context.label("", 13f, Theme.TEXT, false)
        barText.maxLines = 1
        barText.setSingleLine(true)
        barText.setPadding(context.dp(14), context.dp(5), context.dp(14), context.dp(5))
        barScroll = HorizontalScrollView(context)
        barScroll.isHorizontalScrollBarEnabled = false
        barScroll.background = context.rounded(Theme.SCRIM, 14f)
        barScroll.addView(barText)
        barScroll.visibility = View.GONE
        val bp = LinearLayout.LayoutParams(MATCH, WRAP)
        bp.setMargins(context.dp(12), context.dp(6), context.dp(12), 0)
        topColumn.addView(barScroll, bp)
        stage.addView(topColumn, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP))

        // Bottom: one panel with everything you tap.
        val dock = LinearLayout(context)
        dock.orientation = LinearLayout.VERTICAL
        dock.background = context.roundedTop(Theme.PANEL, 22f)
        dock.setPadding(context.dp(8), context.dp(8), context.dp(8), context.dp(10))
        dock.isClickable = true // a drag that starts on the panel must not spin the view behind it

        // Optional buttons for the turns (the face turns of the small cubes, the corner twists of the Skewb).
        padBox = LinearLayout(context)
        padBox.orientation = LinearLayout.VERTICAL
        padBox.setPadding(0, 0, 0, context.dp(6))
        padBox.visibility = View.GONE
        dock.addView(padBox, lp(MATCH, WRAP))

        // Puzzle picker, timer with the move counter, and the pad / rotate / settings buttons in one row.
        val stats = LinearLayout(context)
        stats.orientation = LinearLayout.HORIZONTAL
        stats.gravity = Gravity.CENTER_VERTICAL
        puzzleChip = context.chip("") { choosePuzzle() }
        puzzleChip.maxLines = 1
        puzzleChip.setEndIcon(R.drawable.ic_expand, 18, Theme.TEXT)
        stats.addView(puzzleChip, LinearLayout.LayoutParams(WRAP, WRAP))
        val timeBox = LinearLayout(context)
        timeBox.orientation = LinearLayout.VERTICAL
        timeBox.gravity = Gravity.CENTER_HORIZONTAL
        timerView = context.label("0:00.0", 22f, Theme.TEXT, true)
        movesView = context.label("0 moves", 12f, Theme.MUTED, false)
        timeBox.addView(timerView, LinearLayout.LayoutParams(WRAP, WRAP))
        timeBox.addView(movesView, LinearLayout.LayoutParams(WRAP, WRAP))
        stats.addView(timeBox, lp(0, WRAP, 1f))
        padToggle = iconToggle(R.drawable.ic_pad, "Turn pad") { togglePad() }
        orbitBtn = iconToggle(R.drawable.ic_orbit, "Rotate view") { toggleOrbit() }
        val settingsBtn = context.iconButton(R.drawable.ic_tune) { openSettings() }
        settingsBtn.contentDescription = "Settings"
        stats.addView(padToggle, lp(context.dp(42), context.dp(42)))
        stats.addView(orbitBtn, lp(context.dp(42), context.dp(42)))
        stats.addView(settingsBtn, lp(context.dp(42), context.dp(42)))
        dock.addView(stats, lp(MATCH, WRAP))

        // Main controls.
        val controls = LinearLayout(context)
        controls.orientation = LinearLayout.HORIZONTAL
        scrambleBtn = ActionButton(context, R.drawable.ic_shuffle, "Scramble", false) { scramble() }
        resetBtn = ActionButton(context, R.drawable.ic_reset, "Reset", false) { reset() }
        solveBtn = ActionButton(context, R.drawable.ic_ai, "AI solve", true) { aiSolve() }
        for (b in listOf(scrambleBtn, resetBtn, solveBtn)) {
            val p = LinearLayout.LayoutParams(0, context.dp(56), 1f)
            p.setMargins(context.dp(4), 0, context.dp(4), 0)
            controls.addView(b, p)
        }
        val cp = LinearLayout.LayoutParams(MATCH, WRAP)
        cp.topMargin = context.dp(6)
        dock.addView(controls, cp)
        stage.addView(dock, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM))

        // The puzzle uses the space between the face strip and the panel; keep that in step with the layout.
        val refit = View.OnLayoutChangeListener { _, _, _, _, _, _, _, _, _ ->
            if (stage.height > 0 && dock.height > 0) {
                val top = if (faceStrip.visibility == View.VISIBLE) faceStrip.bottom else topSpace.bottom
                puzzleView.setFreeArea(top, stage.height - dock.top)
            }
        }
        stage.addOnLayoutChangeListener(refit)
        topColumn.addOnLayoutChangeListener(refit)
        dock.addOnLayoutChangeListener(refit)
    }

    /** The camera hole's room goes into the space above the face strip, so the puzzle view itself can run under it. */
    override fun setTopInset(t: Int) {
        val p = topSpace.layoutParams
        p.height = t + context.dp(4)
        topSpace.layoutParams = p
    }

    // Declared after init on purpose: it reads timerView, which init assigns. Declared before init the
    // Kotlin compiler rejects it ("Variable 'timerView' must be initialized").
    private val ticker = object : Runnable {
        override fun run() {
            if (timing) {
                timerView.text = Format.duration(SystemClock.elapsedRealtime() - startMs)
                uiHandler.postDelayed(this, 100L)
            }
        }
    }

    /** Icon-only button that can be shown as "on", for the pad and rotate-view switches. */
    private fun iconToggle(iconRes: Int, description: String, onClick: () -> Unit): ImageView {
        val v = context.iconButton(iconRes, onClick)
        v.contentDescription = description
        if (Build.VERSION.SDK_INT >= 26) v.tooltipText = description
        v.background = context.toggleBackground(false)
        return v
    }

    // ---------------------------------------------------------------- puzzle loading

    private fun load(id: Int) {
        val m = PuzzleCatalog.get(id)
        if (m == null) {
            showStatus("The native library could not be loaded.")
            return
        }
        Lab.cancelWork()
        model = m
        state = m.solved()
        puzzleView.setPuzzle(m, state)
        puzzleView.renderer.speed = 1f
        busy = false
        pendingMoves = 0
        scrambling = false
        aiPlaying = false
        solving = false
        resetTimer()
        hideBar()
        puzzleChip.text = Puzzles.title(id)
        buildPad(m)
        solveBtn.isEnabled = m.aiSupported
        scrambleBtn.isEnabled = true
        showStatus(Puzzles.hint(id))
    }

    private fun buildPad(m: PuzzleModel) {
        padBox.removeAllViews()
        val moves = m.padMoves
        if (moves.isEmpty()) {
            padToggle.visibility = View.GONE
            padBox.visibility = View.GONE
            return
        }
        padToggle.visibility = View.VISIBLE
        padToggle.background = context.toggleBackground(padBox.visibility == View.VISIBLE)
        val perRow = if (moves.size % 6 == 0) 6 else 4
        var at = 0
        while (at < moves.size) {
            val line = LinearLayout(context)
            line.orientation = LinearLayout.HORIZONTAL
            for (k in 0 until perRow) {
                if (at + k >= moves.size) break
                val move = moves[at + k]
                val c = context.chip(m.moveNames[move]) { onUserMove(move) }
                c.textSize = 14f
                val p = LinearLayout.LayoutParams(0, context.dp(38), 1f)
                p.setMargins(context.dp(3), context.dp(2), context.dp(3), context.dp(2))
                line.addView(c, p)
            }
            padBox.addView(line, lp(MATCH, WRAP))
            at += perRow
        }
    }

    // ---------------------------------------------------------------- playing

    private fun onUserMove(move: Int) {
        val m = model ?: return
        if (busy || solving) {
            puzzleView.reportTouch("IGNORED: busy=" + busy + " solving=" + solving + " (press Reset to clear)")
            return
        }
        puzzleView.reportTouch("turn " + m.moveNames[move] + " applied")
        state = m.apply(state, move)
        puzzleView.renderer.enqueue(move)
        moveCount++
        movesView.text = moveCount.toString() + (if (moveCount == 1) " move" else " moves")
        if (armed && !timing) {
            timing = true
            startMs = SystemClock.elapsedRealtime()
            uiHandler.post(ticker)
            statusView.visibility = View.GONE
        }
        if (m.isSolved(state) && timing) {
            val ms = SystemClock.elapsedRealtime() - startMs
            timing = false
            armed = false
            uiHandler.removeCallbacks(ticker)
            timerView.text = Format.duration(ms)
            val best = Lab.recordSolve(m.id, scrambleLen, ms, moveCount)
            val record = if (best) " New best!" else ""
            showStatus("Solved in " + Format.duration(ms) + ", " + moveCount + " moves." + record)
        }
    }

    /** Called when one animated turn has finished playing. */
    private fun onMoveDone() {
        if (pendingMoves <= 0) return
        pendingMoves--
        if (pendingMoves > 0) return
        busy = false
        puzzleView.renderer.speed = 1f
        scrambleBtn.isEnabled = true
        solveBtn.isEnabled = model?.aiSupported == true
        if (scrambling) {
            scrambling = false
            armed = true
            showStatus("Your turn. The timer starts with your first move.")
        } else if (aiPlaying) {
            aiPlaying = false
            showStatus(aiSummary)
        }
    }

    private fun scramble() {
        val m = model ?: return
        if (busy || solving) return
        Lab.cancelWork()
        val len = Lab.scrambleLength(m.id)
        val moves = m.scramble(rng, len)
        state = m.applyAll(m.solved(), moves)
        scrambleLen = len
        resetTimer()
        puzzleView.renderer.setState(m.solved())
        puzzleView.renderer.speed = 3.2f
        puzzleView.renderer.enqueueAll(moves)
        busy = true
        scrambling = true
        pendingMoves = moves.size
        scrambleBtn.isEnabled = false
        solveBtn.isEnabled = false
        showBar("Scramble (the AI never sees this): " + m.format(moves))
        showStatus("Scrambling...")
    }

    private fun reset() {
        val m = model ?: return
        Lab.cancelWork()
        state = m.solved()
        puzzleView.renderer.setState(state)
        puzzleView.renderer.speed = 1f
        busy = false
        pendingMoves = 0
        scrambling = false
        aiPlaying = false
        solving = false
        scrambleBtn.isEnabled = true
        solveBtn.isEnabled = m.aiSupported
        solveBtn.setLabel("AI solve")
        resetTimer()
        hideBar()
        showStatus("Solved puzzle. Press Scramble to start.")
    }

    private fun aiSolve() {
        val m = model ?: return
        if (busy || solving) return
        if (!m.aiSupported) {
            Toast.makeText(context, "The " + m.shortName + " is play-only: too many states to learn on a phone.", Toast.LENGTH_LONG).show()
            return
        }
        if (m.isSolved(state)) {
            showStatus("Already solved. Press Scramble first.")
            return
        }
        // An AI solution never counts as the player's time.
        armed = false
        timing = false
        uiHandler.removeCallbacks(ticker)
        solving = true
        solveBtn.isEnabled = false
        solveBtn.setLabel("Thinking")
        scrambleBtn.isEnabled = false
        showStatus("The AI is thinking. It sees only the colours.")
        val start = state.copyOf()
        Lab.solveAsync(m.id, start) { r -> onAiResult(m, start, r) }
    }

    private fun onAiResult(m: PuzzleModel, start: ByteArray, r: SolveResult) {
        solving = false
        solveBtn.setLabel("AI solve")
        solveBtn.isEnabled = m.aiSupported
        scrambleBtn.isEnabled = true
        if (model !== m || !state.contentEquals(start)) return // the puzzle was reset or changed meanwhile
        if (!r.solved) {
            val hint = if (Lab.solverMode == SolverMode.LEARNED) " Train this AI longer in the Train tab, or raise the node budget in settings." else ""
            showStatus(SolveStatus.label(r.status) + "." + hint)
            return
        }
        val finalState = m.applyAll(start, r.moves)
        if (!m.isSolved(finalState)) {
            showStatus("The returned moves do not solve the puzzle.")
            return
        }
        state = finalState
        aiSummary = SolverMode.label(Lab.solverMode) + " solved it in " + r.moves.size + " moves (" +
            Format.compact(r.expanded.toLong()) + " nodes, " + r.elapsedMs + " ms)."
        showBar("AI solution: " + m.format(r.moves))
        showStatus("The AI is solving it.")
        puzzleView.renderer.speed = 1.2f
        puzzleView.renderer.enqueueAll(r.moves)
        busy = true
        aiPlaying = true
        pendingMoves = r.moves.size
        scrambleBtn.isEnabled = false
        solveBtn.isEnabled = false
    }

    // ---------------------------------------------------------------- small helpers

    private fun resetTimer() {
        timing = false
        armed = false
        uiHandler.removeCallbacks(ticker)
        moveCount = 0
        timerView.text = "0:00.0"
        movesView.text = "0 moves"
    }

    private fun showStatus(text: String) {
        statusView.text = text
        statusView.visibility = View.VISIBLE
    }

    private fun showBar(text: String) {
        barText.text = text
        barScroll.scrollTo(0, 0)
        barScroll.visibility = View.VISIBLE
    }

    private fun hideBar() {
        barScroll.visibility = View.GONE
    }

    private fun togglePad() {
        val show = padBox.visibility != View.VISIBLE
        padBox.visibility = if (show) View.VISIBLE else View.GONE
        padToggle.background = context.toggleBackground(show)
    }

    private fun toggleOrbit() {
        val on = !puzzleView.orbitMode
        puzzleView.orbitMode = on
        orbitBtn.background = context.toggleBackground(on)
        showStatus(if (on) "Rotate view is on: drag anywhere to look around." else "Rotate view is off: swipe the puzzle to turn it.")
    }

    private fun choosePuzzle() {
        Dialogs.choosePuzzle(context, Lab.playPuzzle) { id ->
            if (id != Lab.playPuzzle) {
                Lab.playPuzzle = id
                load(id)
                Lab.warmAsync(id)
            }
        }
    }

    private fun openSettings() {
        val m = model ?: return
        Dialogs.playSettings(context, m.id) {
            applyFacePreview()
            applySound()
            applyTouchInfo()
        }
    }

    /** Shows what each touch on the puzzle did at the top of the screen, when that setting is on (for tracing a bug on a phone). */
    private fun applyTouchInfo() {
        if (Lab.touchInfo) {
            puzzleView.touchInfo = { text -> showStatus(text) }
        } else {
            puzzleView.touchInfo = null
        }
    }

    /** Shows or hides the face strip according to the setting. */
    private fun applyFacePreview() {
        faceStrip.visibility = if (Lab.facePreviews) View.VISIBLE else View.GONE
    }

    /** Turns the cube sounds on or off according to the setting; the sound pool exists only while it is on and the page is shown. */
    private fun applySound() {
        if (Lab.turnSounds) {
            var snd = turnSound
            if (snd == null) {
                snd = TurnSound(context)
                turnSound = snd
            }
            puzzleView.renderer.sound = snd
        } else {
            puzzleView.renderer.sound = null
            turnSound?.release()
            turnSound = null
        }
    }

    override fun onShow() {
        val id = Lab.playPuzzle
        if (model?.id != id) load(id)
        applyFacePreview()
        applySound()
        applyTouchInfo()
        puzzleView.onResume()
        if (timing) uiHandler.post(ticker)
        Lab.warmAsync(id)
    }

    override fun onHide() {
        puzzleView.onPause()
        uiHandler.removeCallbacks(ticker)
        puzzleView.renderer.sound = null
        turnSound?.release()
        turnSound = null
    }
}
