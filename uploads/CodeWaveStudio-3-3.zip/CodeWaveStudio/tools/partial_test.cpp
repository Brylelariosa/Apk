// Tests of the additive commands (partial.track / partial.harmonics / partial.dynamics), envelope.deltas and the
// independence of noise layers. Desktop only:
//   g++ -std=c++17 -O2 -I app/src/main/cpp tools/partial_test.cpp app/src/main/cpp/{dsp,parser,engine,audio}/*.cpp -o partial_test
#include <cmath>
#include <cstdio>
#include <string>
#include <vector>

#include "engine/engine.h"

using namespace cw;

static int failures = 0;
#define CHECK(cond, ...)                                    \
  do {                                                      \
    if (!(cond)) {                                          \
      std::printf("FAIL %s:%d  ", __FILE__, __LINE__);      \
      std::printf(__VA_ARGS__);                             \
      std::printf("\n");                                    \
      ++failures;                                           \
    }                                                       \
  } while (0)

struct Result {
  GenStatus status;
  std::string error;
  std::vector<float> x;  // mono (left channel)
  int sr = 44100;
};

static Result render(const std::string& script) {
  Engine e;
  GenerateSettings gs;
  gs.sampleRate = 44100;
  gs.channels = 1;
  Result r;
  r.status = e.generate(script, gs, nullptr);
  r.error = e.lastError();
  if (r.status == GenStatus::Ok) {
    auto snd = e.sound();
    r.x = snd->ch[0];
    r.sr = snd->sampleRate;
  }
  return r;
}

// Amplitude of a sinusoid of frequency f in x[from, to) (single bin DFT with a Hann window).
static double amplitudeAt(const std::vector<float>& x, int sr, double f, double t0, double t1) {
  const long a = (long)(t0 * sr), b = std::min<long>((long)(t1 * sr), (long)x.size());
  double re = 0, im = 0, wsum = 0;
  for (long i = a; i < b; ++i) {
    const double w = 0.5 - 0.5 * std::cos(2 * M_PI * (double)(i - a) / (double)(b - a));
    re += x[(size_t)i] * w * std::cos(2 * M_PI * f * i / sr);
    im -= x[(size_t)i] * w * std::sin(2 * M_PI * f * i / sr);
    wsum += w;
  }
  return 2.0 * std::sqrt(re * re + im * im) / wsum;
}

static double variance(const std::vector<float>& x, size_t from) {
  double m = 0, v = 0;
  for (size_t i = from; i < x.size(); ++i) m += x[i];
  m /= (double)(x.size() - from);
  for (size_t i = from; i < x.size(); ++i) v += (x[i] - m) * (x[i] - m);
  return v / (double)(x.size() - from);
}

int main() {
  // ---- a gliding partial: 440 Hz held, then up to 880 Hz
  {
    Result r = render("sound.begin(2);\npartial.track(0, 440, 0, 0.1, 440, 0.5, 0.5, 440, 0.5, 1.5, 880, 0.5, 1.9, 880, 0);\nsound.end();\n");
    CHECK(r.status == GenStatus::Ok, "glide script failed: %s", r.error.c_str());
    if (r.status == GenStatus::Ok) {
      const double a440 = amplitudeAt(r.x, r.sr, 440, 0.15, 0.45), a880 = amplitudeAt(r.x, r.sr, 880, 1.52, 1.62);
      CHECK(a440 > 0.3 && a440 < 0.6, "440 Hz level %.3f", a440);
      CHECK(a880 > 0.3 && a880 < 0.6, "880 Hz level %.3f", a880);
      CHECK(amplitudeAt(r.x, r.sr, 440, 1.52, 1.62) < 0.02, "the partial should have left 440 Hz");
    }
  }
  // ---- a harmonic stack with explicit gains
  {
    Result r = render("sound.begin(1);\npartial.track(0, 200, 0, 0.05, 200, 1, 0.9, 200, 1, 1, 200, 0);\npartial.harmonics(1, 0.5, 0.25, 0, 0.1);\nsound.end();\n");
    CHECK(r.status == GenStatus::Ok, "stack script failed: %s", r.error.c_str());
    if (r.status == GenStatus::Ok) {
      const double a1 = amplitudeAt(r.x, r.sr, 200, 0.3, 0.7), a2 = amplitudeAt(r.x, r.sr, 400, 0.3, 0.7), a3 = amplitudeAt(r.x, r.sr, 600, 0.3, 0.7),
                   a4 = amplitudeAt(r.x, r.sr, 800, 0.3, 0.7), a5 = amplitudeAt(r.x, r.sr, 1000, 0.3, 0.7);
      CHECK(std::fabs(a2 / a1 - 0.5) < 0.03 && std::fabs(a3 / a1 - 0.25) < 0.03, "gains: %.3f %.3f %.3f", a1, a2, a3);
      CHECK(a4 < 0.01 * a1, "harmonic 4 has gain 0 but level %.4f", a4);
      CHECK(std::fabs(a5 / a1 - 0.1) < 0.02, "harmonic 5 level %.4f", a5 / a1);
    }
  }
  // ---- partial.dynamics: with exponent 2 a harmonic loses twice as many dB when the track gets quieter
  {
    Result r = render("sound.begin(2);\npartial.track(0, 300, 0, 0.01, 300, 1, 1, 300, 1, 1.01, 300, 0.1, 2, 300, 0.1);\npartial.harmonics(1, 1);\npartial.dynamics(1, 2);\nsound.end();\n");
    CHECK(r.status == GenStatus::Ok, "dynamics script failed: %s", r.error.c_str());
    if (r.status == GenStatus::Ok) {
      const double loud1 = amplitudeAt(r.x, r.sr, 300, 0.3, 0.7), loud2 = amplitudeAt(r.x, r.sr, 600, 0.3, 0.7);
      const double quiet1 = amplitudeAt(r.x, r.sr, 300, 1.4, 1.9), quiet2 = amplitudeAt(r.x, r.sr, 600, 1.4, 1.9);
      const double dropFund = 20 * std::log10(loud1 / quiet1), dropHarm = 20 * std::log10(loud2 / quiet2);
      CHECK(std::fabs(dropFund - 20.0) < 1.0, "fundamental drop %.1f dB (expected 20)", dropFund);
      CHECK(std::fabs(dropHarm - 40.0) < 1.5, "harmonic drop %.1f dB (expected 40)", dropHarm);
    }
  }
  // ---- volume points are joined on a dB scale: a decay from 1 to 0.01 in 1 s is 20 dB at the half way point
  {
    Result r = render("sound.begin(1);\npartial.track(0.001, 1000, 1, 1, 1000, 0.01);\nsound.end();\n");
    CHECK(r.status == GenStatus::Ok, "decay script failed: %s", r.error.c_str());
    if (r.status == GenStatus::Ok) {
      const double a0 = amplitudeAt(r.x, r.sr, 1000, 0.05, 0.15), aMid = amplitudeAt(r.x, r.sr, 1000, 0.45, 0.55), a1 = amplitudeAt(r.x, r.sr, 1000, 0.85, 0.95);
      CHECK(std::fabs(20 * std::log10(a0 / aMid) - 16.0) < 1.5 && std::fabs(20 * std::log10(aMid / a1) - 16.0) < 1.5,
            "dB scale decay: %.1f then %.1f dB per 0.4 s (expected 16 and 16)", 20 * std::log10(a0 / aMid), 20 * std::log10(aMid / a1));
    }
  }
  // ---- envelope.deltas: times are gaps in ms and the points are joined on a dB scale
  {
    Result a = render("sound.begin(1);\nlayer.begin(0, 1);\n oscillator.sine(1000, 1);\n envelope.deltas(0, 1, 1000, 0.01);\nlayer.end();\nsound.end();\n");
    Result b = render("sound.begin(1);\nlayer.begin(0, 1);\n oscillator.sine(1000, 1);\n envelope.deltas(0, 1, 500, 0.1, 500, 0.01);\nlayer.end();\nsound.end();\n");
    CHECK(a.status == GenStatus::Ok && b.status == GenStatus::Ok, "deltas scripts failed: %s %s", a.error.c_str(), b.error.c_str());
    if (a.status == GenStatus::Ok && b.status == GenStatus::Ok) {
      double worst = 0;
      for (size_t i = 0; i < a.x.size() && i < b.x.size(); ++i) worst = std::max(worst, (double)std::fabs(a.x[i] - b.x[i]));
      CHECK(worst < 0.01, "a point on the straight dB line must not change anything (max difference %.4f)", worst);
      const double mid = amplitudeAt(a.x, a.sr, 1000, 0.45, 0.55);
      CHECK(std::fabs(20 * std::log10(mid) + 20.0) < 1.5, "level at 0.5 s is %.1f dB (expected -20)", 20 * std::log10(mid));
    }
  }
  // ---- noise layers are independent: N identical layers have N times the power (not N^2: no shared random stream)
  {
    auto layers = [](int n) {
      std::string s = "sound.begin(4);\n";
      for (int i = 0; i < n; ++i) s += "layer.begin(0, 4);\n noise.add(0.5);\n filter.bandpass(1000, 2, order = 2);\nlayer.end();\n";
      return s + "sound.end();\n";
    };
    Result r1 = render(layers(1)), r4 = render(layers(4)), r8 = render(layers(8));
    CHECK(r1.status == GenStatus::Ok && r4.status == GenStatus::Ok && r8.status == GenStatus::Ok, "noise scripts failed");
    if (r1.status == GenStatus::Ok && r4.status == GenStatus::Ok && r8.status == GenStatus::Ok) {
      const double v1 = variance(r1.x, 44100), v4 = variance(r4.x, 44100), v8 = variance(r8.x, 44100);
      CHECK(std::fabs(v4 / v1 - 4.0) < 0.6, "4 layers: power x%.2f (independent noise = 4, a shared stream = 16)", v4 / v1);
      CHECK(std::fabs(v8 / v1 - 8.0) < 1.2, "8 layers: power x%.2f (independent noise = 8, a shared stream = 64)", v8 / v1);
    }
  }
  // ---- errors are caught with a message that says what is wrong
  struct Bad {
    const char* body;
    const char* expect;
  } bad[] = {
      {"partial.track(0, 440, 0.5);", "partial.track needs"},
      {"partial.track(0, 440, 0.5, 1, 440);", "partial.track needs"},
      {"partial.track(1, 440, 0.5, 0.5, 440, 0.5);", "increasing order"},
      {"partial.track(0, 0.5, 0.5, 1, 440, 0.5);", "frequency must be"},
      {"partial.track(0, 440, 9, 1, 440, 0.5);", "volume must be"},
      {"oscillator.sine(440, 0.5); partial.harmonics(1, 0.5);", "directly after partial.track"},
      {"partial.track(0, 440, 0.5, 1, 440, 0.5); fm.modulate(5);", "cannot change a partial.track"},
      {"partial.track(0, 440, 0.5, 1, 440, 0.5); partial.harmonics(1, 9);", "volume must be"},
      {"partial.track(0, 440, 0.5, 1, 440, 0.5); partial.dynamics(1, 20);", "exponent must be"},
      {"partial.track(0, 440, 0.5, 1, 440, 0.5); filter.lowpass(900); partial.harmonics(1);", "directly after partial.track"},
      {"noise.add(1); envelope.deltas(0, 1, -5, 0);", "cannot be negative"},
      {"noise.add(1); envelope.deltas(0);", "needs 1 to"},
  };
  for (const Bad& b : bad) {
    Result r = render(std::string("sound.begin(1);\n") + b.body + "\nsound.end();\n");
    CHECK(r.status == GenStatus::ScriptError, "should be rejected: %s", b.body);
    CHECK(r.error.find(b.expect) != std::string::npos, "wrong message for '%s': %s", b.body, r.error.c_str());
  }
  // ---- thousands of partial tracks may share one layer (the 16-oscillator limit is for classic oscillators)
  {
    std::string s = "sound.begin(2);\n";
    for (int i = 0; i < 3000; ++i) s += "partial.track(0, " + std::to_string(100 + i % 900) + ", 0.001, 1, " + std::to_string(100 + i % 900) + ", 0);\n";
    s += "sound.end();\n";
    Result r = render(s);
    CHECK(r.status == GenStatus::Ok, "3000 tracks in one layer failed: %s", r.error.c_str());
    std::string t = "sound.begin(1);\n";
    for (int i = 0; i < 17; ++i) t += "oscillator.sine(" + std::to_string(200 + i * 10) + ", 0.1);\n";
    t += "sound.end();\n";
    Result q = render(t);
    CHECK(q.status == GenStatus::ScriptError && q.error.find("maximum 16") != std::string::npos, "17 classic oscillators must still be rejected: %s", q.error.c_str());
  }
  if (failures == 0) std::printf("partial_test: all checks passed\n");
  return failures == 0 ? 0 : 1;
}
