import sys, numpy as np
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
import evaluate as E
t0, t1, fmax = float(sys.argv[1]), float(sys.argv[2]), float(sys.argv[3])
files = sys.argv[5:]; out = sys.argv[4]
sigs = []
for f in files:
    sr, x = E.load(f); sigs.append(x)
n = min(len(x) for x in sigs); ref = sigs[0][:n]
fig, ax = plt.subplots(len(sigs), 1, figsize=(14, 3.2 * len(sigs)), sharex=True)
for a, f, x in zip(np.atleast_1d(ax), files, sigs):
    x = x[:n] * (np.sqrt(np.mean(ref**2)) / np.sqrt(np.mean(x[:n]**2)))
    S = E.stft(x, 2048, 256, sr); D = 20*np.log10(S + 1e-6); D -= D.max()
    fr = np.fft.rfftfreq(2048, 1/sr); kmax = int(fmax / (sr/2048))
    i0, i1 = int(t0*sr/256), int(t1*sr/256)
    a.imshow(D[:kmax, i0:i1], origin='lower', aspect='auto', vmin=-85, vmax=0, cmap='magma', extent=[t0, t1, 0, fr[kmax]])
    a.set_title(f)
plt.tight_layout(); plt.savefig(out, dpi=65); plt.close()
