# Measuring "does the code sound like the audio?"

Nobody can listen to a unit test, so the analyser is tuned against objective stand-ins (`evaluate.py`):

| score | what it compares | better |
|---|---|---|
| `mel`, `melm` | log-mel spectrogram, all bins / only what is audible next to the loudest part of each frame (dB) | lower |
| `melc` | per-band correlation of the mel envelopes over time (rhythm + timbre) | higher |
| `fine` | cosine similarity of 8192-point spectra below 5 kHz: do the partials line up? | higher |
| `chr` | chroma (pitch class) correlation: harmony and melody | higher |
| `ons` | onset-strength correlation: does the beat land in the right place? | higher |
| `lowd` | dB error of the 40-200 Hz band: kick and bass weight | lower |
| `msl` | multi-resolution STFT log distance (dominated by random noise fine structure, a weak guide) | lower |

```
sh tools/eval/build_debug.sh                  # analyser with -DA2C_DEBUG -> tools/eval/a2c_dbg
python3 tools/eval/make_song.py song.wav      # synthetic test piece (kick, claps, hats, bass, pads, plucks, vocals)
python3 tools/eval/exp.py baseline            # Detailed, default settings
python3 tools/eval/exp.py try1 A_SHARE=0.5    # change any knob (analysis/detail_levels.cpp lists them)
python3 tools/eval/zoom.py 4 8 8000 zoom.png song.wav exp/try1.wav   # spectrograms side by side
python3 tools/eval/bands_err.py song.wav exp/try1.wav                # error by frequency range
```

Use your own audio instead of the synthetic piece whenever you can: the scores only mean something relative to each
other, on the same input. Always look at a spectrogram as well as the numbers.
