#!/bin/sh
# Builds the audio->code analyser with its development hooks (-DA2C_DEBUG): every tuning value can be overridden
# from the environment (A_SNR, A_SHARE, ..., see analysis/detail_levels.cpp) and per-stage timings are printed.
set -e
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
CPP="$ROOT/app/src/main/cpp"
OUT="${1:-$(dirname "$0")/a2c_dbg}"
g++ -std=c++17 -O2 -DA2C_DEBUG -Wall -Wextra -I"$CPP" "$ROOT/tools/audio_to_code_test.cpp" "$CPP"/analysis/*.cpp \
  "$CPP"/dsp/*.cpp "$CPP"/parser/*.cpp "$CPP"/engine/*.cpp "$CPP"/audio/*.cpp -o "$OUT"
echo "built $OUT"
