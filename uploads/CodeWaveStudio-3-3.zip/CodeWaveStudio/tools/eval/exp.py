#!/usr/bin/env python3
"""Run the development build of the analyser with environment overrides and print objective scores.

    tools/eval/build_debug.sh                          # builds tools/eval/a2c_dbg
    python3 tools/eval/make_song.py song.wav           # a synthetic pop-like test piece (any wav works)
    python3 tools/eval/exp.py [-d detail] [-s song.wav] NAME KEY=VALUE ...

    python3 tools/eval/exp.py try1 A_SHARE=0.5 A_SNR=9      # detail 2 (Detailed) with two knobs changed
    PLOT=1 SHOWDBG=1 python3 tools/eval/exp.py -d 1 try2    # also writes exp/try2.png and prints statistics
"""
import os, re, subprocess, sys
here = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, here)
import evaluate

args = sys.argv[1:]
detail, song, exe = 2, 'song.wav', os.environ.get('A2C_EXE', os.path.join(here, 'a2c_dbg'))
while args and args[0].startswith('-'):
    if args[0] == '-d': detail = int(args[1]); args = args[2:]
    elif args[0] == '-s': song = args[1]; args = args[2:]
    elif args[0] == '-x': exe = args[1]; args = args[2:]
    else: break
if not args:
    sys.exit(__doc__)
name, env = args[0], dict(os.environ)
for kv in args[1:]:
    k, v = kv.split('=')
    env[k] = v
os.makedirs('exp', exist_ok=True)
cws, wav = f'exp/{name}.cws', f'exp/{name}.wav'
r = subprocess.run([exe, song, cws, str(detail), wav], env=env, capture_output=True, text=True)
info = re.findall(r'analysis ok: (.*?) \| commands=(\d+) chars=(\d+)', r.stdout)
if not info:
    sys.exit(f'{name} FAILED\n{r.stdout[-300:]}\n{r.stderr[-300:]}')
sr, a = evaluate.load(song)
_, b = evaluate.load(wav)
m = evaluate.metrics(a, b, sr)
print(f"{name:14s} {info[0][0]:36s} chars={info[0][2]:>6s} | " + ' '.join(f'{k}={v:.3f}' for k, v in m.items()))
if os.environ.get('SHOWDBG'):
    print('    ' + ' '.join(l.strip() for l in r.stderr.splitlines() if l.startswith('[a2c]')))
if os.environ.get('PLOT'):
    evaluate.plot(a, b, sr, f'exp/{name}.png')
