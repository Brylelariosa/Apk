import sys, numpy as np
import evaluate as E
sr, a = E.load(sys.argv[1]); _, b = E.load(sys.argv[2])
n = min(len(a), len(b)); a = a[:n]; b = b[:n]; b = b * (np.sqrt(np.mean(a**2)) / np.sqrt(np.mean(b**2)))
n_fft, hop = 1024, 441
fb = E.mel_fb(sr, n_fft)
A = np.maximum(fb @ (E.stft(a, n_fft, hop, sr)**2), 1e-10); B = np.maximum(fb @ (E.stft(b, n_fft, hop, sr)**2), 1e-10)
dA, dB = 10*np.log10(A), 10*np.log10(B)
mel_hz = np.array([700*(10**(m/2595)-1) for m in np.linspace(2595*np.log10(1+30/700), 2595*np.log10(1+16000/700), 82)[1:-1]])
groups = [(0,120),(120,300),(300,800),(800,2000),(2000,5000),(5000,9000),(9000,16000)]
gate = dA > dA.max() - 70
print('band(Hz)       signed(dB)  abs(dB)   corr(time)')
for lo, hi in groups:
    sel = (mel_hz >= lo) & (mel_hz < hi)
    d = (dB - dA)[sel]; g = gate[sel]
    cs = [np.corrcoef(dA[i], dB[i])[0,1] for i in np.where(sel)[0]]
    print(f'{lo:5d}-{hi:5d}   {d[g].mean():+7.2f}   {np.abs(d)[g].mean():6.2f}   {np.nanmean(cs):6.3f}')
