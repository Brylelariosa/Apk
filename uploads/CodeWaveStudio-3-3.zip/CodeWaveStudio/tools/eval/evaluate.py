"""Compare an original with its resynthesis. Objective stand-ins for "does it sound the same":
  mel  : mean |dB difference| of an 80-band log-mel spectrogram (10 ms hop)      lower = better
  melm : the same, but only for what is audible next to the loudest part of each frame   lower = better
  melc : mean per-band correlation of the mel envelopes over time               higher = better (rhythm + timbre)
  msl  : multi-resolution STFT log-spectral distance (512/2048/8192 FFT)         lower = better
  fine : cosine similarity of 8192-FFT magnitudes < 5 kHz (do the partials line up?)  higher = better
  chr  : chroma (pitch-class) correlation                                         higher = better (harmony / melody)
  ons  : onset-strength envelope correlation                                       higher = better (rhythm)
  lowd : mean |dB difference| of the 40-200 Hz band energy (kick / bass weight)   lower = better
"""
import sys, numpy as np
from scipy.io import wavfile
from scipy import signal

def load(p):
    sr, x = wavfile.read(p)
    x = x.astype(np.float64)
    if x.ndim > 1: x = x.mean(axis=1)
    if x.dtype != np.float64 or np.max(np.abs(x)) > 2: x = x / 32768.0
    return sr, x

def stft(x, n, hop, sr):
    w = np.hanning(n)
    pad = np.pad(x, (n // 2, n // 2))
    frames = 1 + (len(pad) - n) // hop
    idx = np.arange(n)[None, :] + hop * np.arange(frames)[:, None]
    return np.abs(np.fft.rfft(pad[idx] * w[None, :], axis=1)).T   # (bins, frames)

def mel_fb(sr, n_fft, n_mels=80, fmin=30, fmax=16000):
    def h2m(f): return 2595 * np.log10(1 + f / 700)
    def m2h(m): return 700 * (10 ** (m / 2595) - 1)
    pts = m2h(np.linspace(h2m(fmin), h2m(fmax), n_mels + 2))
    bins = np.fft.rfftfreq(n_fft, 1 / sr)
    fb = np.zeros((n_mels, len(bins)))
    for i in range(n_mels):
        l, c, r = pts[i], pts[i + 1], pts[i + 2]
        up = (bins - l) / (c - l); dn = (r - bins) / (r - c)
        fb[i] = np.maximum(0, np.minimum(up, dn))
    return fb / np.maximum(fb.sum(axis=1, keepdims=True), 1e-9)

def metrics(a, b, sr):
    n = min(len(a), len(b)); a = a[:n]; b = b[:n]
    b = b * (np.sqrt(np.mean(a ** 2)) / max(np.sqrt(np.mean(b ** 2)), 1e-12))
    out = {}
    # mel
    n_fft = 1024; hop = 441
    fb = mel_fb(sr, n_fft)
    A = np.maximum(fb @ (stft(a, n_fft, hop, sr) ** 2), 1e-10); B = np.maximum(fb @ (stft(b, n_fft, hop, sr) ** 2), 1e-10)
    dA, dB = 10 * np.log10(A), 10 * np.log10(B)
    gate = dA > dA.max() - 70
    out['mel'] = float(np.mean(np.abs(dA - dB)[gate]))
    # masked: only what a listener can hear next to the loudest thing of that moment (within 45 dB of the frame max)
    audible = gate & (dA > dA.max(axis=0, keepdims=True) - 45)
    out['melm'] = float(np.mean(np.abs(dA - dB)[audible]))
    cs = [np.corrcoef(dA[i], dB[i])[0, 1] for i in range(dA.shape[0]) if np.std(dA[i]) > 1e-6 and np.std(dB[i]) > 1e-6]
    out['melc'] = float(np.nanmean(cs))
    # multi-res
    msl = []
    for N in (512, 2048, 8192):
        SA = stft(a, N, N // 4, sr); SB = stft(b, N, N // 4, sr)
        la, lb = np.log10(SA + 1e-4), np.log10(SB + 1e-4)
        msl.append(np.mean(np.abs(la - lb)) * 20)
    out['msl'] = float(np.mean(msl))
    # fine structure
    N = 8192; SA = stft(a, N, 2048, sr); SB = stft(b, N, 2048, sr)
    kmax = int(5000 / (sr / N)); SA = SA[:kmax]; SB = SB[:kmax]
    num = np.sum(SA * SB, axis=0); den = np.sqrt(np.sum(SA ** 2, axis=0) * np.sum(SB ** 2, axis=0)) + 1e-12
    w = np.sum(SA ** 2, axis=0); out['fine'] = float(np.sum(num / den * w) / np.sum(w))
    # chroma
    N = 8192; SA = stft(a, N, 2048, sr) ** 2; SB = stft(b, N, 2048, sr) ** 2
    fr = np.fft.rfftfreq(N, 1 / sr)
    sel = (fr > 60) & (fr < 4000)
    pc = (np.round(12 * np.log2(fr[sel] / 440.0) + 69).astype(int)) % 12
    def chroma(S):
        C = np.zeros((12, S.shape[1]))
        for k in range(12): C[k] = S[sel][pc == k].sum(axis=0)
        return C / (C.sum(axis=0, keepdims=True) + 1e-12)
    CA, CB = chroma(SA), chroma(SB)
    out['chr'] = float(np.mean([np.corrcoef(CA[:, i], CB[:, i])[0, 1] for i in range(CA.shape[1]) if np.std(CA[:, i]) > 1e-9 and np.std(CB[:, i]) > 1e-9]))
    # onset envelope
    def onset(x):
        S = np.log1p(30 * (fb @ (stft(x, 1024, 441, sr) ** 2)) ** 0.5)
        d = np.maximum(0, np.diff(S, axis=1)).sum(axis=0)
        return d
    oa, ob = onset(a), onset(b)
    out['ons'] = float(np.corrcoef(oa, ob)[0, 1])
    # low end
    N = 4096; SA = stft(a, N, 1024, sr) ** 2; SB = stft(b, N, 1024, sr) ** 2
    fr = np.fft.rfftfreq(N, 1 / sr); s = (fr >= 40) & (fr <= 200)
    la = 10 * np.log10(SA[s].sum(axis=0) + 1e-10); lb = 10 * np.log10(SB[s].sum(axis=0) + 1e-10)
    out['lowd'] = float(np.mean(np.abs(la - lb)))
    return out

def plot(a, b, sr, path, title_b='resynthesis'):
    import matplotlib; matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    n = min(len(a), len(b)); a = a[:n]; b = b[:n]
    b = b * (np.sqrt(np.mean(a ** 2)) / max(np.sqrt(np.mean(b ** 2)), 1e-12))
    fig, ax = plt.subplots(2, 1, figsize=(14, 7), sharex=True)
    for axx, x, t in ((ax[0], a, 'original'), (ax[1], b, title_b)):
        S = stft(x, 2048, 512, sr)
        D = 20 * np.log10(S + 1e-6); D -= D.max()
        fr = np.fft.rfftfreq(2048, 1 / sr); kmax = int(8000 / (sr / 2048))
        axx.imshow(D[:kmax], origin='lower', aspect='auto', vmin=-90, vmax=0, cmap='magma',
                   extent=[0, n / sr, 0, fr[kmax]])
        axx.set_title(t); axx.set_ylabel('Hz')
    ax[1].set_xlabel('s')
    plt.tight_layout(); plt.savefig(path, dpi=70); plt.close()

if __name__ == '__main__':
    sr, a = load(sys.argv[1]); sr2, b = load(sys.argv[2])
    m = metrics(a, b, sr)
    print(' '.join(f'{k}={v:.3f}' for k, v in m.items()))
    if len(sys.argv) > 3: plot(a, b, sr, sys.argv[3])
