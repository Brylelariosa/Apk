"""Synthetic 'pop / EDM-folk' test piece (mono, 44.1 kHz) used to measure the audio->script analyser.
Contains: four-on-the-floor kick, claps, hats, saw bass, detuned-saw pad chords, banjo-like plucks,
a formant-sung lead vocal with vibrato and glides, light reverb. About 28.7 s at 126 BPM."""
import numpy as np, sys
from scipy import signal
from scipy.io import wavfile

sr = 44100
dur = 28.7
n = int(dur * sr)
rng = np.random.default_rng(7)
bpm = 126.0
beat = 60.0 / bpm

def midi(m): return 440.0 * 2 ** ((np.asarray(m) - 69) / 12.0)
def place(buf, sig, t0):
    i = int(t0 * sr)
    if i >= len(buf): return
    j = min(len(buf), i + len(sig))
    buf[i:j] += sig[: j - i]

def lp(x, fc, order=2):
    b, a = signal.butter(order, fc / (sr / 2), 'low'); return signal.lfilter(b, a, x)
def hp(x, fc, order=2):
    b, a = signal.butter(order, fc / (sr / 2), 'high'); return signal.lfilter(b, a, x)
def bp(x, f1, f2, order=2):
    b, a = signal.butter(order, [f1 / (sr / 2), f2 / (sr / 2)], 'band'); return signal.lfilter(b, a, x)

def saw_phase(f, length, detune_cents=0.0, ph0=0.0):
    f = f * 2 ** (detune_cents / 1200.0)
    if np.isscalar(f): f = np.full(length, f)
    ph = (ph0 + np.cumsum(f / sr)) % 1.0
    return 2 * ph - 1

drums = np.zeros(n); bass = np.zeros(n); pad = np.zeros(n); pluck = np.zeros(n); vox = np.zeros(n)

# ------------------------------ drums
def kick():
    t = np.arange(int(0.45 * sr)) / sr
    f = 45 + 120 * np.exp(-t * 28)
    ph = 2 * np.pi * np.cumsum(f) / sr
    return (np.sin(ph) * np.exp(-t * 7.5) + 0.25 * np.sin(2 * ph) * np.exp(-t * 20)) * 1.0
def clap():
    t = np.arange(int(0.28 * sr)) / sr
    x = bp(rng.standard_normal(len(t)), 900, 3500)
    env = np.exp(-t * 18) + 0.8 * np.exp(-((t - 0.012) % 0.011) * 150) * (t < 0.035)
    return x * env * 0.5
def hat(open_=False):
    L = 0.25 if open_ else 0.05
    t = np.arange(int(L * sr)) / sr
    x = hp(rng.standard_normal(len(t)), 7000)
    return x * np.exp(-t * (14 if open_ else 90)) * (0.18 if open_ else 0.16)

nbeats = int(dur / beat) + 1
for b in range(nbeats):
    place(drums, kick(), b * beat)
    if b % 4 in (1, 3): place(drums, clap(), b * beat)
    place(drums, hat(False), b * beat + beat * 0.25 * 0)   # 16ths-ish
    place(drums, hat(False), b * beat + beat * 0.5)
    place(drums, hat(True), b * beat + beat * 0.5 + 0.0)
    if b % 2 == 0: place(drums, hat(False), b * beat + beat * 0.75)

# side-chain envelope (ducks pads/bass on every kick)
duck = np.ones(n)
for b in range(nbeats):
    i = int(b * beat * sr); L = int(0.28 * sr)
    seg = np.minimum(1.0, 0.25 + 0.75 * (np.arange(min(L, n - i)) / L) ** 1.5)
    if i < n: duck[i:i + len(seg)] = np.minimum(duck[i:i + len(seg)], seg)

# ------------------------------ chords: D#m  B  F#  C#   (2 bars each... 1 bar each here)
chords = [([51, 54, 58], 39), ([47, 51, 54], 35), ([54, 58, 61], 42), ([49, 53, 56], 37)]   # (pad notes, bass root)
bars = int(dur / (4 * beat)) + 1
for bar in range(bars):
    notes, root = chords[bar % 4]
    t0 = bar * 4 * beat
    L = int(4 * beat * sr)
    t = np.arange(L) / sr
    env = np.minimum(1, t / 0.15) * np.minimum(1, (4 * beat - t) / 0.2)
    p = np.zeros(L)
    for m in notes:
        for dc in (-14, -7, 0, 7, 14):
            p += saw_phase(midi(m), L, dc, rng.random())
    p = lp(p, 2200) * env * 0.045
    place(pad, p, t0)
    # bass 8ths with off-beat pushes
    for k in range(8):
        tb = t0 + k * beat / 2
        Lb = int(beat / 2 * sr * 0.9)
        tt = np.arange(Lb) / sr
        m = root + (12 if k in (3, 7) else 0)
        s = saw_phase(midi(m) * np.ones(Lb), Lb)
        s = lp(s, 900) * np.exp(-tt * 3.0) * np.minimum(1, tt / 0.005)
        place(bass, s * 0.33, tb)

# ------------------------------ banjo-like plucks (16th arpeggio)
def pluck_note(m, L=0.6):
    f = midi(m)
    tt = np.arange(int(L * sr)) / sr
    s = np.zeros_like(tt)
    for h in range(1, 14):
        if f * h > 9000: break
        s += (1.0 / h ** 1.2) * np.sin(2 * np.pi * f * h * tt + rng.random() * 6.28) * np.exp(-tt * (6 + 5 * h))
    return s * 0.22
for bar in range(bars):
    notes, root = chords[bar % 4]
    arp = [notes[0] + 12, notes[1] + 12, notes[2] + 12, notes[1] + 24]
    for k in range(16):
        tb = bar * 4 * beat + k * beat / 4
        if tb < 1.0: continue
        m = arp[(k * 3) % 4] if k % 2 == 0 else arp[(k * 5 + 1) % 4] + 12
        place(pluck, pluck_note(m) * (1.0 if k % 4 == 0 else 0.7), tb)

# ------------------------------ lead vocal: glottal source -> formant filters, vibrato, glides
VOW = {'a': (800, 1150, 2900), 'o': (500, 900, 2800), 'e': (450, 1900, 2700), 'i': (300, 2300, 3100)}
def vocal_phrase(notes, vowel='a'):
    """notes: list of (midi, seconds). Returns the sung signal."""
    total = sum(d for _, d in notes)
    L = int(total * sr)
    f0 = np.zeros(L); i = 0
    prev = notes[0][0]
    for m, d in notes:
        k = int(d * sr)
        tgt = np.full(k, float(m))
        g = int(0.07 * sr)   # portamento
        tgt[:g] = np.linspace(prev, m, g)
        f0[i:i + k] = tgt; i += k; prev = m
    t = np.arange(L) / sr
    vib = 0.35 * np.sin(2 * np.pi * 5.6 * t) * np.minimum(1, t / 0.3)
    jit = 0.05 * lp(rng.standard_normal(L), 12, 1) * 4
    freq = midi(f0 + vib + jit)
    ph = np.cumsum(freq / sr) % 1.0
    src = 2 * ph - 1
    src = lp(src, 3500, 2)
    src = src + 0.03 * rng.standard_normal(L)
    out = np.zeros(L)
    F = VOW[vowel]
    for fc, q, g in zip(F, (8, 10, 12), (1.0, 0.7, 0.35)):
        out += g * bp(src, fc * 0.93, fc * 1.07, 2)
    out *= 3.0
    a = 0.03; env = np.ones(L)
    env[: int(a * sr)] = np.linspace(0, 1, int(a * sr))
    env[-int(0.08 * sr):] *= np.linspace(1, 0, int(0.08 * sr))
    return out * env * (0.55 + 0.45 * np.minimum(1, t / 0.2))
phr = [
    ([(61, 0.55), (63, 0.4), (66, 0.9), (63, 0.45), (61, 1.1)], 'a'),
    ([(58, 0.5), (61, 0.5), (63, 0.7), (61, 0.5), (58, 1.3)], 'o'),
    ([(66, 0.6), (68, 0.45), (70, 1.0), (68, 0.5), (66, 1.2)], 'e'),
    ([(65, 0.5), (66, 0.5), (68, 0.8), (66, 0.55), (63, 1.4)], 'a'),
]
t0 = 8 * beat
for ph_i in range(8):
    notes, v = phr[ph_i % 4]
    if t0 > dur - 1: break
    place(vox, vocal_phrase(notes, v) * 0.30, t0)
    t0 += sum(d for _, d in notes) + 0.45

# ------------------------------ reverb on vocal + plucks
ir_len = int(1.4 * sr); tt = np.arange(ir_len) / sr
ir = rng.standard_normal(ir_len) * np.exp(-tt * 5.0); ir[:int(0.012 * sr)] = 0; ir = lp(ir, 5000, 1)
wet = signal.fftconvolve(vox * 1.0 + pluck * 0.6, ir / np.sqrt(np.sum(ir ** 2)) * 0.5)[:n]

mix = drums * 0.9 + (bass + pad) * duck + pluck + vox + 0.22 * wet
mix = mix[:n]
mix = mix / np.max(np.abs(mix)) * 0.9
wavfile.write(sys.argv[1] if len(sys.argv) > 1 else 'song.wav', sr, (mix * 32767).astype(np.int16))
print('wrote', len(mix) / sr, 's rms', float(np.sqrt(np.mean(mix ** 2))))
