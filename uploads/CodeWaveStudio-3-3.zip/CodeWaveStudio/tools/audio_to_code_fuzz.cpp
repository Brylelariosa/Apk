// Fuzzer for the audio -> script analyser: random / hostile audio in, and every script that comes out
// must be accepted by the real engine. Build with -fsanitize=address,undefined (see build_and_test.sh).
//   ./a2c_fuzz [iterations] [seed]
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <limits>
#include <string>
#include <vector>

#include "analysis/audio_to_code.h"
#include "engine/engine.h"

static uint32_t g = 12345;
static uint32_t rnd() { g ^= g << 13; g ^= g >> 17; g ^= g << 5; return g; }
static double uni() { return (rnd() >> 8) * (1.0 / 16777216.0); }

int main(int argc, char** argv) {
  const int iters = argc > 1 ? std::atoi(argv[1]) : 200;
  if (argc > 2) g = (uint32_t)std::atoi(argv[2]) | 1u;
  const int rates[] = {4000, 8000, 11025, 16000, 22050, 32000, 44100, 48000, 88200, 96000};
  int ok = 0, rejected = 0;
  for (int it = 0; it < iters; ++it) {
    const bool longClip = rnd() % 20 == 0;  // 40..140 s (the analyser must cut at 120 s), low rate to stay fast
    const int sr = longClip ? rates[rnd() % 4] : rates[rnd() % 10];
    const double secs = longClip ? 40.0 + uni() * 100.0 : ((rnd() % 5 == 0) ? uni() * 0.2 : uni() * 8.0);
    const size_t n = (size_t)(secs * sr) + (rnd() % 3 == 0 ? 0 : 1024);
    std::vector<float> x(n, 0.0f);
    const int kind = (int)(rnd() % 9);
    const int parts = 1 + (int)(rnd() % 6);
    for (int p = 0; p < parts; ++p) {
      const double f = 20.0 + uni() * 0.5 * sr * (rnd() % 2 ? 0.2 : 1.0);
      const double f2 = f * (0.3 + uni() * 3.0);
      const double a = uni() * 0.6;
      const size_t s0 = (size_t)(uni() * n * 0.7), s1 = std::min(n, s0 + (size_t)(uni() * n));
      for (size_t i = s0; i < s1; ++i) {
        const double t = (double)i / sr, u = (double)(i - s0) / std::max<size_t>(1, s1 - s0);
        double v = 0;
        switch (kind) {
          case 0: v = std::sin(2 * M_PI * f * t); break;
          case 1: v = std::sin(2 * M_PI * (f + (f2 - f) * u) * t); break;                  // glide
          case 2: v = (uni() * 2 - 1); break;                                              // noise
          case 3: v = std::sin(2 * M_PI * f * t) > 0 ? 1 : -1; break;                      // square
          case 4: v = 2 * std::fmod(f * t, 1.0) - 1; break;                                // saw
          case 5: v = (i % 4410 < 40) ? 1.0 : 0.0; break;                                  // clicks
          case 6: v = std::sin(2 * M_PI * f * t) * std::exp(-4 * u) + (uni() * 2 - 1) * 0.05; break;
          case 7: v = 100.0 * (uni() * 2 - 1); break;                                      // huge amplitude
          default: v = std::sin(2 * M_PI * f * t) * std::sin(2 * M_PI * 6 * t); break;
        }
        x[i] += (float)(a * v);
      }
    }
    if (rnd() % 7 == 0 && n > 10) x[rnd() % n] = std::numeric_limits<float>::quiet_NaN();
    if (rnd() % 11 == 0 && n > 10) x[rnd() % n] = std::numeric_limits<float>::infinity();
    cw::AnalyzeOptions opt;
    opt.detail = (int)(rnd() % 4) - 1;  // also out-of-range values
    opt.name = (rnd() % 3 == 0) ? std::string("na\xc3\xafve \"q\"\n\\x/..") : std::string("clip.mp3");
    const cw::AnalyzeResult r = cw::analyzeAudioToScript(x.data(), x.size(), sr, opt);
    if (!r.ok) { ++rejected; continue; }
    // the generated script has to respect the limits the app and the engine promise (30000 commands; 250000 characters keeps it
    // clipboard friendly) - whatever the audio looks like
    if (r.commands > 29000 || r.script.size() > 250000) { std::printf("LIMIT VIOLATION it=%d cmds=%d size=%zu\n", it, r.commands, r.script.size()); return 1; }
    cw::Engine e;
    cw::GenerateSettings gs;
    gs.channels = 1;
    gs.sampleRate = (rnd() % 2) ? 22050 : 48000;
    const cw::GenStatus st = e.generate(r.script, gs, nullptr);
    if (st != cw::GenStatus::Ok) {
      std::printf("ENGINE REJECTED it=%d sr=%d n=%zu kind=%d: line %d\n%s\n", it, sr, n, kind, e.lastErrorLine(), e.lastError().c_str());
      return 1;
    }
    ++ok;
  }
  std::printf("fuzz: %d scripts accepted by the engine, %d inputs rejected cleanly, no crashes\n", ok, rejected);
  return 0;
}
