#!/bin/sh
# Builds the native engine for the host machine and renders every preset (no Android SDK needed).
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CPP="$ROOT/app/src/main/cpp"
OUT="${TMPDIR:-/tmp}/cwtest_out"
mkdir -p "$OUT"
g++ -std=c++17 -O2 -Wall -Wextra -I"$CPP" "$ROOT/tools/desktop_test.cpp" \
  "$CPP"/dsp/*.cpp "$CPP"/parser/*.cpp "$CPP"/engine/*.cpp "$CPP"/audio/*.cpp -o "$OUT/cwtest"
for f in "$ROOT"/app/src/main/assets/presets/*.cws; do
  printf '%-28s ' "$(basename "$f")"
  "$OUT/cwtest" "$f" "$OUT/$(basename "$f" .cws).wav"
done

# Additive commands (partial.track / harmonics / dynamics), envelope.deltas, independent noise layers.
g++ -std=c++17 -O2 -Wall -Wextra -I"$CPP" "$ROOT/tools/partial_test.cpp" \
  "$CPP"/dsp/*.cpp "$CPP"/parser/*.cpp "$CPP"/engine/*.cpp "$CPP"/audio/*.cpp -o "$OUT/partial_test"
"$OUT/partial_test"

# Native crash reporter: provoke a real SIGSEGV and check the report file.
g++ -std=c++17 -O0 -g -rdynamic -I"$CPP" "$ROOT/tools/crash_handler_test.cpp" "$CPP/crash/crash_handler.cpp" -o "$OUT/crash_test" -ldl
rm -f "$OUT/native_crash.txt"
"$OUT/crash_test" "$OUT/native_crash.txt" >/dev/null 2>&1 || true
grep -q "SIGSEGV" "$OUT/native_crash.txt" && echo "crash reporter: OK (SIGSEGV captured)" || { echo "crash reporter: FAILED"; exit 1; }

# Audio -> code: turn rendered presets back into scripts (the same analyser the app runs on imported
# mp3 / m4a files), then let the real engine parse and render the generated script.
g++ -std=c++17 -O2 -Wall -Wextra -I"$CPP" "$ROOT/tools/audio_to_code_test.cpp" "$CPP"/analysis/*.cpp \
  "$CPP"/dsp/*.cpp "$CPP"/parser/*.cpp "$CPP"/engine/*.cpp "$CPP"/audio/*.cpp -o "$OUT/a2c_test"
for p in 02_robot_voice 05_explosion 18_chiptune_melody 20_additive_bell 21_choir_stack; do
  for d in 0 1 2; do
    printf '%-34s ' "audio->code $p (detail $d)"
    "$OUT/a2c_test" "$OUT/$p.wav" "$OUT/$p.from_audio.$d.cws" $d | tr '\n' ' '
    echo
  done
done
# Fuzz the analyser with random / hostile audio under AddressSanitizer + UBSan.
g++ -std=c++17 -O1 -g -fsanitize=address,undefined -fno-sanitize-recover=undefined -I"$CPP" \
  "$ROOT/tools/audio_to_code_fuzz.cpp" "$CPP"/analysis/*.cpp "$CPP"/dsp/*.cpp "$CPP"/parser/*.cpp \
  "$CPP"/engine/*.cpp "$CPP"/audio/*.cpp -o "$OUT/a2c_fuzz"
"$OUT/a2c_fuzz" 120 7
