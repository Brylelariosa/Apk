// CodeWave Studio - audio -> script analysis.
//
// Takes decoded mono PCM (from an mp3 / m4a / wav ... decoded by the platform) and writes a CodeWave script that
// approximates it:
//   * partials - sinusoids found by multi-resolution short-time spectra and tracked over time (partials.*), the
//                harmonic ones collapsed into stacks that share one pitch and one volume curve (voices.*); each
//                voice is one partial.track (+ partial.harmonics / partial.dynamics) command;
//   * noise    - everything the partials do not explain (drums, breath, hiss, rumble, reverb) as band-passed noise
//                layers whose level over time is fitted with envelope.deltas (noise_model.*), measured against
//                what the emitted partials will actually sound like.
// The pipeline lives in this directory, one module per step; audio_to_code.cpp only orchestrates it and spends the
// character budget of the chosen detail level (detail_levels.*). The result is an approximation, not a copy: the
// same kind of code a person could write to imitate the sound, and it always stays inside the script limits.
#pragma once

#include <cstddef>
#include <string>

namespace cw {

struct AnalyzeOptions {
  int detail = 1;             // 0 = simple, 1 = normal, 2 = detailed
  std::string name;           // source name for the header comment (sanitised before use)
  double startSeconds = 0.0;  // where in the source file the analysed part starts (header only)
};

struct AnalyzeResult {
  bool ok = false;
  std::string error;    // set when !ok
  std::string script;   // set when ok
  std::string summary;  // one line for the UI, e.g. "42 partials + 5 noise bands, 3.2 s"
  int tones = 0;        // partial.track commands written (a harmonic stack counts once)
  int noiseBands = 0;
  int commands = 0;
  double seconds = 0.0;
};

// `mono` holds `frames` samples at `sampleRate` Hz. At most the first 120 seconds are used.
AnalyzeResult analyzeAudioToScript(const float* mono, size_t frames, int sampleRate, const AnalyzeOptions& opt);

}  // namespace cw
