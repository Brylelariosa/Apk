#include "audio_to_code.h"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <new>
#include <utility>

#include "../dsp/dsp.h"
#include "curve_fit.h"
#include "detail_levels.h"
#include "noise_model.h"
#include "partials.h"
#include "script_text.h"
#include "spectral.h"
#include "tuning.h"
#include "voices.h"

namespace cw {
namespace {

using namespace analysis;

constexpr double kMaxAnalysisSec = 120.0;   // the engine's longest sound
constexpr int kMaxCommandsUsed = 29000;     // engine limit is 30000
constexpr int kMaxLayersUsed = 11000;       // engine limit is 12000 layer instances
constexpr double kChunkSec = 20.0;          // noise-band layers are cut into pieces of at most this length
constexpr double kCharsPerPair = 8.5;       // text size of one envelope.deltas (milliseconds, value) pair
constexpr int kMinBandPts = 24;             // a band is worth at least this many points
constexpr size_t kHeaderReserve = 1600;     // header comments, sound.begin / normalize / end
constexpr double kBandOverhead = 135.0;     // text size of one noise layer around its envelope

// ------------------------------------------------------------------ noise layers
struct NoiseChunk {
  double t0 = 0, len = 0;
  int band = 0;
  std::vector<Pt2> env;  // (time since t0, 0..1 of the band's loudest level)
};
struct NoiseBand {
  double vmax = 0;  // white-noise volume at the band's loudest moment (input peak = 1)
  std::vector<NoiseChunk> chunks;
};

std::string emitNoise(const NoiseBand& nb, const NoiseChunk& c, const Bands& B, double S) {
  const double vol = clampd(nb.vmax / S, 0.0, 4.0);
  const size_t j = (size_t)c.band;
  std::string s = "layer.begin(" + fmt(c.t0, 3) + ", " + fmt(c.len, 3) + ");   // noise " + fmt(B.edge[j], 0) + "-" +
                  fmt(B.edge[j + 1], 0) + " Hz\n";
  s += "  noise.add(" + fmtAmp(vol) + ");\n";
  s += "  filter.bandpass(" + fmt(B.center[j], 0) + ", " + fmt(B.q[j], 2) + ", order = 2);\n";
  s += envelopeDeltasText(c.env);
  s += "layer.end();\n";
  return s;
}

// ------------------------------------------------------------------ voices
std::string voiceText(const Voice& v, double S) {
  std::string s = partialTrackText(v.pts, S);
  if (!v.gains.empty()) s += partialHarmonicsText(v.gains);
  if (!v.dyn.empty()) s += partialDynamicsText(v.dyn);
  return s;
}
int voiceCommands(const Voice& v) { return 1 + (v.gains.empty() ? 0 : 1) + (v.dyn.empty() ? 0 : 1); }

// What the emitted voices sound like, rendered with the engine's own partial renderer (analysis by synthesis).
std::vector<float> renderTonal(const std::vector<const Voice*>& chosen, size_t n, int sr) {
  std::vector<float> y(n, 0.0f);
  std::vector<double> flat, harm, dyn;
  for (const Voice* v : chosen) {
    flat.clear();
    harm.clear();
    dyn.clear();
    for (const TrackPt& p : v->pts) {
      flat.push_back(p.t);
      flat.push_back(p.f);
      flat.push_back(p.a);
    }
    for (float g : v->gains) harm.push_back((double)g);
    for (float e : v->dyn) dyn.push_back((double)e);
    renderPartialTrack(flat.data(), v->pts.size(), harm.empty() ? nullptr : harm.data(), harm.size(),
                       dyn.empty() ? nullptr : dyn.data(), dyn.size(), y.data(), (int)n, 1.0, 1.0, sr, nullptr);
  }
  return y;
}

// ------------------------------------------------------------------ the pipeline
AnalyzeResult analyseImpl(const float* mono, size_t frames, int sampleRate, const AnalyzeOptions& opt) {
  AnalyzeResult R;
  Lap lap;
  const Params P = paramsFor(opt.detail);
  const size_t limitChars = P.maxChars;
  if (!mono || frames < 1024 || sampleRate < 4000 || sampleRate > 400000) {
    R.error = "The audio is too short to analyse.";
    return R;
  }

  // ---- 1. clean-up
  std::vector<float> x;
  int sr = sampleRate;
  const size_t nUse = std::min(frames, (size_t)(kMaxAnalysisSec * sampleRate));
  x.assign(mono, mono + nUse);
  for (float& v : x)
    if (!std::isfinite(v)) v = 0.0f;
  while (sr > 50000 && x.size() > 8) {  // 88.2 / 96 kHz -> half rate (only < 16 kHz matters here)
    std::vector<float> y(x.size() / 2);
    for (size_t i = 0; i < y.size(); ++i) {
      const float a = x[i == 0 ? 0 : 2 * i - 1], b = x[2 * i], c = x[std::min(x.size() - 1, 2 * i + 1)];
      y[i] = 0.25f * a + 0.5f * b + 0.25f * c;
    }
    x.swap(y);
    sr /= 2;
  }
  double mean = 0.0;
  for (float v : x) mean += v;
  mean /= (double)x.size();
  double peak = 0.0;
  for (float& v : x) {
    v = (float)(v - mean);
    peak = std::max(peak, (double)std::fabs(v));
  }
  if (peak < 1e-4) {
    R.error = "The audio is silent.";
    return R;
  }
  for (float& v : x) v = (float)(v / peak);

  // trim silence (below -50 dB of the loudest 10 ms) at both ends
  {
    const int blk = std::max(1, sr / 100);
    const size_t nBlk = x.size() / (size_t)blk;
    std::vector<double> rms(nBlk, 0.0);
    double mx = 0.0;
    for (size_t b = 0; b < nBlk; ++b) {
      double s = 0.0;
      for (int i = 0; i < blk; ++i) s += (double)x[b * (size_t)blk + (size_t)i] * x[b * (size_t)blk + (size_t)i];
      rms[b] = std::sqrt(s / blk);
      mx = std::max(mx, rms[b]);
    }
    const double thr = mx * 0.00316;
    size_t fb = 0, lb = nBlk;
    while (fb < nBlk && rms[fb] < thr) ++fb;
    while (lb > fb && rms[lb - 1] < thr) --lb;
    if (lb > fb) {
      const long s0 = std::max(0L, (long)(fb * (size_t)blk) - (long)(0.015 * sr));
      const long s1 = std::min((long)x.size(), (long)(lb * (size_t)blk) + (long)(0.06 * sr));
      if (s1 - s0 >= (long)(0.05 * sr)) x = std::vector<float>(x.begin() + s0, x.begin() + s1);
    }
  }
  const double dur = (double)x.size() / sr;
  R.seconds = dur;

  // ---- 2. text budget: the noise bands take a fixed share, the partials get the rest.
  // Fewer, wider bands with a usable time resolution beat many bands that cannot follow the rhythm, so long
  // clips get fewer bands.
  const size_t noiseChars = (size_t)(P.charShare * (double)(limitChars - kHeaderReserve));
  const size_t toneChars = limitChars - kHeaderReserve - noiseChars;
  const double chunksPerBand = std::ceil(dur / kChunkSec) + 1.0;
  const double bandOverhead = chunksPerBand * kBandOverhead;
  const double minPtsPerBand = std::max((double)kMinBandPts, 12.0 * dur);  // enough to follow a beat
  const int nbAffordable = (int)(((double)noiseChars / kCharsPerPair) / (minPtsPerBand + bandOverhead / kCharsPerPair));
  const Bands B = makeBands(std::max(4, std::min(P.nBands, nbAffordable)), sr);

  lap("cleanup");
  // ---- 3. partials -> voices, judged by how audible they are
  std::vector<Partial> partials = findPartials(x, sr, P.partial);
  lap("findPartials");
  double strongest = 0.0;
  for (const Partial& p : partials) strongest = std::max(strongest, p.heard);
  const double keepHeard = strongest * std::pow(10.0, -P.toneRelDb / 20.0);
  partials.erase(std::remove_if(partials.begin(), partials.end(), [&](const Partial& p) { return p.heard < keepHeard; }),
                 partials.end());
  const size_t nPartials = partials.size();
  (void)nPartials;  // (only logged in development builds)
  std::vector<Voice> voices = buildVoices(std::move(partials), P.voice);
  lap("buildVoices");
  {
    size_t stacksBuilt = 0, memberSum = 0;
    for (const Voice& v : voices)
      if (!v.gains.empty()) {
        ++stacksBuilt;
        memberSum += (size_t)v.members;
      }
    A2C_LOG("[a2c] partials kept=%zu -> voices=%zu (stacks=%zu holding %zu partials)\n", nPartials, voices.size(), stacksBuilt, memberSum);
  }

  // ---- 4. choose what fits: most audible energy per character first
  struct Pick {
    const Voice* v;
    size_t chars;
    double density;
  };
  std::vector<Pick> picks;
  picks.reserve(voices.size());
  for (const Voice& v : voices) {
    const size_t len = voiceText(v, 1.0).size();
    picks.push_back({&v, len, v.energy / (double)(len + 30)});
  }
  std::sort(picks.begin(), picks.end(), [](const Pick& a, const Pick& b) { return a.density > b.density; });
  std::vector<const Voice*> chosen;
  int cmds = 3;  // sound.begin, sound.normalize, sound.end
  size_t tChars = 0;
  for (const Pick& pk : picks) {
    const int c = voiceCommands(*pk.v);
    if (cmds + c > kMaxCommandsUsed - 5 * P.nBands * 2) continue;
    if (tChars + pk.chars > toneChars) continue;
    cmds += c;
    tChars += pk.chars;
    chosen.push_back(pk.v);
  }

  {
    size_t allChars = 0;
    for (const Pick& pk : picks) allChars += pk.chars;
    double eAll = 0.0, eChosen = 0.0;
    for (const Pick& pk : picks) eAll += pk.v->energy;
    for (const Voice* v : chosen) eChosen += v->energy;
    A2C_LOG("[a2c] candidates=%zu (%zu chars) chosen=%zu (%zu chars of %zu); energy chosen/all=%.3f\n", picks.size(), allChars, chosen.size(), tChars, toneChars, eAll > 0 ? eChosen / eAll : 0.0);
  }

  if (knob("A_NOTONES", 0) > 0.5) chosen.clear();  // (development: noise only)

  // ---- 5. noise bands: the rest of the sound, with a fine envelope each
  const std::vector<float> tonal = chosen.empty() ? std::vector<float>() : renderTonal(chosen, x.size(), sr);
  lap("renderTonal");
  const NoiseLevels nl = analyseNoise(x, tonal, sr, B);
  lap("analyseNoise");
  double toneHeard = 0.0;
  for (const Voice* v : chosen) toneHeard = std::max(toneHeard, v->heard / std::sqrt(2.0));
  std::vector<double> bandMax((size_t)B.nb, 0.0), bandHeard((size_t)B.nb, 0.0);
  double ref = toneHeard;
  for (int i = 0; i < B.nb; ++i) {
    for (float v : nl.v[(size_t)i]) bandMax[(size_t)i] = std::max(bandMax[(size_t)i], (double)v);
    bandHeard[(size_t)i] = bandMax[(size_t)i] / std::sqrt(3.0) * hearingWeight(B.center[(size_t)i]);
    ref = std::max(ref, bandHeard[(size_t)i]);
  }
  std::vector<int> active;
  for (int i = 0; i < B.nb; ++i)
    if (bandHeard[(size_t)i] >= ref * std::pow(10.0, -P.noiseRelDb / 20.0) && bandMax[(size_t)i] > 0.0) active.push_back(i);
  if (knob("A_NONOISE", 0) > 0.5) active.clear();  // (development: partials only)
  const double overhead = (double)active.size() * bandOverhead;
  const int totalPts = (int)std::max(0.0, ((double)noiseChars - overhead) / kCharsPerPair);
  std::vector<double> envFloors = {0.05, 0.015, 0.004, 0.001};
  if (knob("A_ENVFLOOR", 0) > 0) envFloors = {knob("A_ENVFLOOR", 0)};  // (development)

  // the levels of every active band as an envelope (relative to the band's loudest moment) ...
  std::vector<NoiseBand> bands((size_t)B.nb);
  std::vector<std::vector<Pt2>> envs;
  std::vector<int> envBand;
  std::vector<EnvCurve> curves;
  envs.reserve(active.size());
  for (int i : active) {
    NoiseBand& nb = bands[(size_t)i];
    nb.vmax = bandMax[(size_t)i];
    std::vector<Pt2> env;
    const std::vector<float>& v = nl.v[(size_t)i];
    for (size_t m = 0; m < v.size(); ++m) {
      const double t = std::min(dur, (double)m * nl.hopSec);
      if (!env.empty() && t <= env.back().first && m + 1 < v.size()) continue;
      env.push_back({std::max(t, env.empty() ? 0.0 : env.back().first), (double)v[m] / nb.vmax});
    }
    if (env.size() < 2) continue;
    envs.push_back(std::move(env));
    envBand.push_back(i);
  }
  for (size_t e = 0; e < envs.size(); ++e) {
    const double w = clampd(std::sqrt(bandHeard[(size_t)envBand[e]] / std::max(1e-12, ref)), 0.3, 1.0);
    curves.push_back({&envs[e], P.bandTolDb, w});
  }
  // ... fitted together: the points go wherever a dB of error matters most
  const std::vector<std::vector<Pt2>> fitted = simplifyEnvelopes(curves, totalPts, envFloors, (int)std::lround(P.minBandPtsPerSec * dur));
  for (size_t e = 0; e < fitted.size(); ++e) {
    const int i = envBand[e];
    NoiseBand& nb = bands[(size_t)i];
    const std::vector<Pt2>& pl = fitted[e];
    for (size_t s0 = 0; s0 + 1 < pl.size();) {
      size_t e0 = s0 + 1;
      while (e0 + 1 < pl.size() && pl[e0 + 1].first - pl[s0].first <= kChunkSec && e0 + 1 - s0 < 1500) ++e0;
      double hi = 0.0;
      for (size_t k = s0; k <= e0; ++k) hi = std::max(hi, pl[k].second);
      NoiseChunk c;
      c.band = i;
      c.t0 = round3(pl[s0].first);
      c.len = round3(round3(pl[e0].first) - c.t0);
      if (hi >= 0.004 && c.len >= 0.01 && c.t0 < dur) {
        for (size_t k = s0; k <= e0; ++k)
          c.env.push_back({std::max(0.0, std::min(c.len, round3(pl[k].first - c.t0))), pl[k].second});
        c.env.back().first = c.len;
        nb.chunks.push_back(std::move(c));
      }
      s0 = e0;
    }
  }

  lap("fitEnvelopes");
  // ---- 6. assemble
  double S = 1e-9;
  for (const Voice* v : chosen) S = std::max(S, v->peak);
  for (const NoiseBand& nb : bands)
    if (!nb.chunks.empty()) S = std::max(S, nb.vmax);

  std::string noiseText;
  int noiseBandsOut = 0, layers = 0;
  for (const NoiseBand& nb : bands) {
    if (nb.chunks.empty()) continue;
    ++noiseBandsOut;
    for (const NoiseChunk& c : nb.chunks) {
      if (cmds + 5 > kMaxCommandsUsed || layers + 1 > kMaxLayersUsed) break;
      noiseText += emitNoise(nb, c, B, S);
      cmds += 5;
      ++layers;
    }
  }
  std::vector<const Voice*> out;
  size_t total = kHeaderReserve + noiseText.size();
  std::vector<const Voice*> byStart = chosen;
  std::sort(byStart.begin(), byStart.end(), [](const Voice* a, const Voice* b) { return a->t0 < b->t0; });
  std::string toneText;
  int stacks = 0;
  for (const Voice* v : byStart) {
    if (v->peak / S < 0.0003) continue;
    const std::string txt = voiceText(*v, S);
    if (total + txt.size() > limitChars) continue;
    total += txt.size();
    toneText += txt;
    out.push_back(v);
    if (!v->gains.empty()) ++stacks;
  }
  if (out.empty() && noiseText.empty()) {
    R.error = "No clear sound could be found in this audio.";
    return R;
  }

  double topHz = 0.0, topAmp = 0.0;
  for (const Voice* v : out)
    if (v->peak > topAmp) {
      topAmp = v->peak;
      for (const TrackPt& p : v->pts)
        if (p.a >= v->peak) topHz = p.f;
    }

  std::string name = sanitizeName(opt.name);
  if (name.empty()) name = "audio";
  std::string text;
  text.reserve(total + 256);
  text += "// CodeWave script made from \"" + name + "\" (" + clockText(opt.startSeconds) + " - " +
          clockText(opt.startSeconds + dur) + ")\n";
  text += std::string("// Detail level: ") + P.label + ". " + std::to_string(out.size()) + " partials" +
          (stacks > 0 ? " (" + std::to_string(stacks) + " harmonic stacks)" : std::string()) + " + " +
          std::to_string(noiseBandsOut) + " noise bands. An approximation of the audio, not a copy.\n";
  if (topHz > 0.0) text += "// Strongest partial: " + noteName(topHz) + " (" + fmtHz(topHz) + " Hz)\n";
  text += "// partial.track = a sine whose pitch and volume follow the points (time, Hz, volume); partial.harmonics adds its overtones\n";
  text += "// noise = band-passed noise layers: everything the partials do not cover (drums, hiss, rumble, breath)\n";
  text += "sound.begin(" + fmt(round3(std::max(0.05, dur)), 3) + ");\n";
  if (!out.empty()) text += "\n// ---- partials\n" + toneText;
  if (!noiseText.empty()) text += "\n// ---- noise\n" + noiseText;
  text += "\nsound.normalize(0.9);\nsound.end();\n";

  R.ok = true;
  R.script = std::move(text);
  R.tones = (int)out.size();
  R.noiseBands = noiseBandsOut;
  R.commands = cmds;
  char sum[160];
  std::snprintf(sum, sizeof sum, "%d partials + %d noise bands, %.1f s", R.tones, R.noiseBands, dur);
  R.summary = sum;
  return R;
}

}  // namespace

AnalyzeResult analyzeAudioToScript(const float* mono, size_t frames, int sampleRate, const AnalyzeOptions& opt) {
  try {
    return analyseImpl(mono, frames, sampleRate, opt);
  } catch (const std::bad_alloc&) {
    AnalyzeResult r;
    r.error = "Not enough memory to analyse this audio.";
    return r;
  } catch (...) {
    AnalyzeResult r;
    r.error = "The audio could not be analysed.";
    return r;
  }
}

}  // namespace cw
