// CodeWave Studio - audio -> script analysis: what Simple / Normal / Detailed mean.
#pragma once

#include <cstddef>

#include "partials.h"
#include "voices.h"

namespace cw {
namespace analysis {

struct Params {
  PartialParams partial;  // how hard to look for partials
  VoiceParams voice;      // how they are collapsed into harmonic stacks
  double toneRelDb;       // keep partials whose weighted peak is within this of the strongest
  int nBands;             // noise bands (the "everything else" channels)
  double noiseRelDb;      // noise bands this far below the loudest (weighted) part are dropped
  double bandTolDb;       // noise band envelope fit tolerance (dB); the shared point budget usually binds first
  size_t maxChars;        // size limit of the generated script (characters)
  double charShare;       // share of that the noise bands may use
  double minBandPtsPerSec;  // every noise band gets at least this many envelope points per second
  const char* label;
};

constexpr size_t kLargestScript = 250000;  // engine limit 1 MB; kept clipboard friendly (the editor takes 300000)

// detail: 0 = Simple, 1 = Normal, 2 = Detailed (anything else is clamped).
Params paramsFor(int detail);

}  // namespace analysis
}  // namespace cw
