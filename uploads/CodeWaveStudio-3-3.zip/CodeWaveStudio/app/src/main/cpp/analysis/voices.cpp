#include "voices.h"

#include <algorithm>
#include <cmath>
#include <utility>

#include "../dsp/common.h"
#include "script_text.h"

namespace cw {
namespace analysis {
namespace {

constexpr double kDt = 0.01;           // grid the partial curves are compared on
constexpr double kHarmonicTol = 0.012; // a harmonic stays within this fraction (~20 cents) of k x the fundamental
constexpr int kMinMembers = 3;

// A partial sampled on the kDt grid (its simplified curve, linearly interpolated: exactly what the engine plays).
struct Sampled {
  int g0 = 0, g1 = -1;  // first / last grid index, inclusive
  std::vector<float> f, a;
  bool has(int g) const { return g >= g0 && g <= g1; }
  double freq(int g) const { return f[(size_t)(g - g0)]; }
  double amp(int g) const { return a[(size_t)(g - g0)]; }
};

Sampled sample(const Partial& p) {
  Sampled s;
  s.g0 = (int)std::ceil(p.t0 / kDt - 1e-9);
  s.g1 = (int)std::floor(p.t1 / kDt + 1e-9);
  if (s.g1 < s.g0) return s;
  s.f.resize((size_t)(s.g1 - s.g0 + 1));
  s.a.resize(s.f.size());
  size_t seg = 0;
  for (int g = s.g0; g <= s.g1; ++g) {
    const double t = g * kDt;
    while (seg + 2 < p.pts.size() && p.pts[seg + 1].t < t) ++seg;
    const TrackPt& A = p.pts[seg];
    const TrackPt& B = p.pts[seg + 1];
    const double u = B.t > A.t ? clampd((t - A.t) / (B.t - A.t), 0.0, 1.0) : 0.0;
    s.f[(size_t)(g - s.g0)] = (float)(A.f + (B.f - A.f) * u);
    s.a[(size_t)(g - s.g0)] = (float)joinVolume(A.a, B.a, u);
  }
  return s;
}

inline double clampd2(double v, double lo, double hi) { return v < lo ? lo : (v > hi ? hi : v); }

struct Member {
  int idx;  // partial
  int k;    // harmonic number
};

class StackBuilder {
 public:
  StackBuilder(const std::vector<Partial>& parts, const std::vector<Sampled>& smp, const VoiceParams& vp, double maxHz)
      : parts_(parts), smp_(smp), vp_(vp), maxHz_(maxHz) {}

  // The partials in `used` are taken. Tries to explain as many unused partials as possible as harmonics of
  // partial `a` divided by h (h = 1: a is the fundamental).
  bool findMembers(int a, int h, const std::vector<char>& used, std::vector<Member>& out) const {
    out.clear();
    const Sampled& SA = smp_[(size_t)a];
    if (SA.g1 < SA.g0) return false;
    const Partial& PA = parts_[(size_t)a];
    const double fa = SA.freq((SA.g0 + SA.g1) / 2);
    const double f0mid = fa / h;
    if (f0mid < 40.0 || f0mid > 1500.0) return false;
    out.push_back({a, h});
    for (size_t b = 0; b < parts_.size(); ++b) {
      if ((int)b == a || used[b]) continue;
      const Partial& PB = parts_[b];
      if (PB.t0 > PA.t1 + 0.1 || PB.t1 < PA.t0 - 0.1) continue;
      // Members of one stack are one note: they start together and do not outlive it. (Repeated plucks of one
      // pitch, or a pad under them, share harmonic frequencies but not the time structure.)
      const double slack = std::max(0.08, 0.2 * (PA.t1 - PA.t0));
      if (std::fabs(PB.t0 - PA.t0) > slack || PB.t1 > PA.t1 + slack) continue;
      const Sampled& SB = smp_[b];
      const int lo = std::max(SA.g0, SB.g0), hi = std::min(SA.g1, SB.g1);
      if (hi - lo < 2) continue;                                    // too little in common
      if ((double)(hi - lo + 1) < 0.6 * (double)(SB.g1 - SB.g0 + 1)) continue;  // B mostly lives elsewhere
      // harmonic number from the middle of the overlap, then the whole overlap must agree
      const int mid = (lo + hi) / 2;
      const double r = SB.freq(mid) / (SA.freq(mid) / h);
      const int k = (int)std::lround(r);
      if (k < 1 || k > vp_.maxHarmonics || k == h) {
        if (k == h) continue;  // the same harmonic as `a` (a duplicate or a fragment): leave it alone
        continue;
      }
      if ((double)k * f0mid > maxHz_) continue;
      bool ok = true;
      for (int g = lo; g <= hi && ok; ++g) {
        const double ratio = SB.freq(g) / ((SA.freq(g) / h) * k);
        ok = std::fabs(ratio - 1.0) <= kHarmonicTol;
      }
      if (ok) out.push_back({(int)b, k});
    }
    return out.size() >= (size_t)kMinMembers;
  }

  // Fits one volume curve and, per harmonic, one gain and one exponent to the members:
  //     log volume of harmonic k at time t  =  G_k + p_k * s(t)
  // (least squares weighted by loudness, alternating between the curve and the per-harmonic numbers). p_k lets a
  // harmonic fade faster than the track (plucked strings: the highs die first) or hold. A harmonic that does not
  // follow the model - or that the model would keep playing where the original has none - is dropped from the
  // stack (it stays an ordinary partial). Returns false when too little is left.
  bool fit(std::vector<Member>& mem, Voice& v, double& memberEnergy, double& memberChars) const {
    const double kNats = 8.686;  // dB per neper
    for (int round = 0; round < 8; ++round) {
      if (mem.size() < (size_t)kMinMembers) return false;
      int g0 = 1 << 30, g1 = -(1 << 30), K = 0;
      double peak = 0.0;
      for (const Member& m : mem) {
        const Sampled& S = smp_[(size_t)m.idx];
        g0 = std::min(g0, S.g0);
        g1 = std::max(g1, S.g1);
        K = std::max(K, m.k);
        peak = std::max(peak, parts_[(size_t)m.idx].peak);
      }
      const int nG = g1 - g0 + 1;
      if (nG < 3 || peak <= 0.0) return false;
      const double floorA = 1e-3 * peak;
      // per harmonic number: amplitude and pitch on the grid (loudest member where several share the number)
      std::vector<std::vector<float>> amp((size_t)K + 1, std::vector<float>((size_t)nG, 0.0f));
      std::vector<std::vector<float>> frq((size_t)K + 1, std::vector<float>((size_t)nG, 0.0f));
      for (const Member& m : mem) {
        const Sampled& S = smp_[(size_t)m.idx];
        for (int g = S.g0; g <= S.g1; ++g) {
          float& dst = amp[(size_t)m.k][(size_t)(g - g0)];
          if (S.amp(g) > dst) {
            dst = (float)S.amp(g);
            frq[(size_t)m.k][(size_t)(g - g0)] = (float)(S.freq(g) / m.k);
          }
        }
      }
      auto present = [&](int k, int g) { return amp[(size_t)k][(size_t)g] > floorA; };
      auto logA = [&](int k, int g) { return std::log((double)amp[(size_t)k][(size_t)g]); };
      auto wgt = [&](int k, int g) {
        const double a = amp[(size_t)k][(size_t)g];
        return a > floorA ? a * a : 0.0;
      };
      std::vector<double> G((size_t)K + 1, 0.0), p((size_t)K + 1, 1.0), s((size_t)nG, 0.0), E((size_t)K + 1, 0.0);
      for (int k = 1; k <= K; ++k)
        for (int g = 0; g < nG; ++g) E[(size_t)k] += wgt(k, g);
      for (int g = 0; g < nG; ++g) {
        double best = floorA;
        for (int k = 1; k <= K; ++k) best = std::max(best, (double)amp[(size_t)k][(size_t)g]);
        s[(size_t)g] = std::log(best);
      }
      for (int it = 0; it < 10; ++it) {
        // per harmonic: regress its log volume on the shared curve
        for (int k = 1; k <= K; ++k) {
          if (E[(size_t)k] <= 0.0) continue;
          double sw = 0.0, ss = 0.0, sl = 0.0;
          for (int g = 0; g < nG; ++g) {
            const double w = wgt(k, g);
            if (w <= 0.0) continue;
            sw += w;
            ss += w * s[(size_t)g];
            sl += w * logA(k, g);
          }
          const double ms = ss / sw, ml = sl / sw;
          double cov = 0.0, var = 0.0;
          for (int g = 0; g < nG; ++g) {
            const double w = wgt(k, g);
            if (w <= 0.0) continue;
            cov += w * (s[(size_t)g] - ms) * (logA(k, g) - ml);
            var += w * (s[(size_t)g] - ms) * (s[(size_t)g] - ms);
          }
          // a harmonic seen over a narrow range of the curve says little about its exponent: stay near 1
          const double prior = 0.02 * sw;
          p[(size_t)k] = clampd2((cov + prior * 1.0) / (var + prior), 0.3, 4.0);
          G[(size_t)k] = ml - p[(size_t)k] * ms;
        }
        // the shared curve, given the per-harmonic numbers
        for (int g = 0; g < nG; ++g) {
          double num = 0.0, den = 0.0;
          for (int k = 1; k <= K; ++k) {
            const double w = wgt(k, g);
            if (w <= 0.0) continue;
            num += w * p[(size_t)k] * (logA(k, g) - G[(size_t)k]);
            den += w * p[(size_t)k] * p[(size_t)k];
          }
          if (den > 0.0) s[(size_t)g] = num / den;
        }
        // gauge: the loudness-weighted mean exponent is 1 (scaling s and p oppositely changes nothing else)
        double pe = 0.0, ee = 0.0;
        for (int k = 1; k <= K; ++k) {
          pe += E[(size_t)k] * p[(size_t)k];
          ee += E[(size_t)k];
        }
        const double alpha = ee > 0.0 ? pe / ee : 1.0;
        if (alpha > 1e-3) {
          for (int g = 0; g < nG; ++g) s[(size_t)g] *= alpha;
          for (int k = 1; k <= K; ++k) p[(size_t)k] = clampd2(p[(size_t)k] / alpha, 0.3, 4.0);
        }
      }
      // How well does every harmonic follow the model where it is there (rms, dB)? And how much of the time, weighted
      // by the stack's loudness, is it there at all? A harmonic that is seen only briefly (the highs of a plucked
      // note) would otherwise be played for the whole note.
      std::vector<double> err((size_t)K + 1, 0.0);
      double sumS = 0.0;
      for (int g = 0; g < nG; ++g) sumS += std::exp(s[(size_t)g]);
      for (int k = 1; k <= K; ++k) {
        if (E[(size_t)k] <= 0.0) continue;
        double num = 0.0, den = 0.0, seen = 0.0;
        for (int g = 0; g < nG; ++g) {
          if (!present(k, g)) continue;
          const double pred = G[(size_t)k] + p[(size_t)k] * s[(size_t)g];
          const double w = wgt(k, g), e = logA(k, g) - pred;
          num += w * e * e;
          den += w;
          seen += std::exp(s[(size_t)g]);
        }
        const double fitErr = den > 0.0 ? std::sqrt(num / den) * kNats : 0.0;
        const double coverage = sumS > 0.0 ? seen / sumS : 0.0;
        const double covErr = coverage >= vp_.minCoverage ? 0.0 : (vp_.minCoverage - coverage) / vp_.minCoverage * 4.0 * vp_.maxFitErrDb;
        err[(size_t)k] = std::max(fitErr, covErr);
      }
      int worstK = 0;
      double worst = vp_.maxFitErrDb;
      for (int k = 1; k <= K; ++k)
        if (err[(size_t)k] > worst) {
          worst = err[(size_t)k];
          worstK = k;
        }
      if (worstK > 0) {  // drop that harmonic number's members and refit
        mem.erase(std::remove_if(mem.begin(), mem.end(), [&](const Member& m) { return m.k == worstK; }), mem.end());
        continue;
      }

      // ---- accepted: build the voice. Harmonic k at the curve's peak has the volume exp(G_k + p_k * s_max);
      // the stored curve and gains are scaled so that the loudest harmonic is 1 there.
      double smax = -1e30;
      for (int g = 0; g < nG; ++g) smax = std::max(smax, s[(size_t)g]);
      std::vector<char> inStack((size_t)K + 1, 0);
      for (const Member& m : mem) inStack[(size_t)m.k] = 1;
      std::vector<double> atPeak((size_t)K + 1, 0.0);
      double gmax = 0.0;
      for (int k = 1; k <= K; ++k) {
        if (!inStack[(size_t)k] || E[(size_t)k] <= 0.0) continue;
        atPeak[(size_t)k] = std::exp(G[(size_t)k] + p[(size_t)k] * smax);
        gmax = std::max(gmax, atPeak[(size_t)k]);
      }
      if (gmax <= 0.0) return false;
      v.gains.assign((size_t)K, 0.0f);
      v.dyn.assign((size_t)K, 1.0f);
      bool anyDyn = false;
      for (int k = 1; k <= K; ++k) {
        const double g = atPeak[(size_t)k] / gmax;
        if (g < 0.012) continue;
        v.gains[(size_t)k - 1] = (float)g;
        if (std::fabs(p[(size_t)k] - 1.0) > 0.12) {
          v.dyn[(size_t)k - 1] = (float)p[(size_t)k];
          anyDyn = true;
        }
      }
      if (!anyDyn) v.dyn.clear();
      std::vector<TrackPt> raw;
      for (int g = 0; g < nG; ++g) {
        double fnum = 0.0, fden = 0.0;
        for (int k = 1; k <= K; ++k) {
          const double a = amp[(size_t)k][(size_t)g];
          if (a <= floorA || v.gains[(size_t)k - 1] == 0.0f) continue;
          const double w = a * k;
          fnum += w * frq[(size_t)k][(size_t)g];
          fden += w;
        }
        if (fden <= 0.0) continue;
        raw.push_back({(g0 + g) * kDt, fnum / fden, gmax * std::exp(s[(size_t)g] - smax)});
      }
      if (raw.size() < 2) return false;
      // the stack starts and ends silent (the members fade in and out) unless a member is clipped by the audio edge
      raw.front().a = std::min(raw.front().a, 0.0);
      raw.back().a = std::min(raw.back().a, 0.0);
      double vpeak = 0.0;
      for (const TrackPt& q : raw) vpeak = std::max(vpeak, q.a);
      v.pts = simplifyTrack(raw, vp_.maxPoints, vp_.ampTolDb, vp_.freqTolCents, std::max(1e-5, 0.02 * vpeak));
      v.peak = vpeak;
      v.t0 = v.pts.front().t;
      v.t1 = v.pts.back().t;
      memberEnergy = 0.0;
      memberChars = 0.0;
      v.heard = 0.0;
      for (const Member& m : mem) {
        memberEnergy += parts_[(size_t)m.idx].energy;
        memberChars += (double)partialTrackText(parts_[(size_t)m.idx].pts, 1.0).size();
        v.heard = std::max(v.heard, parts_[(size_t)m.idx].heard);
      }
      v.energy = memberEnergy;
      v.members = (int)mem.size();
      return true;
    }
    return false;
  }

 private:
  const std::vector<Partial>& parts_;
  const std::vector<Sampled>& smp_;
  const VoiceParams& vp_;
  double maxHz_;
};

Voice plainVoice(Partial&& p) {
  Voice v;
  v.pts = std::move(p.pts);
  v.peak = p.peak;
  v.energy = p.energy;
  v.heard = p.heard;
  v.t0 = p.t0;
  v.t1 = p.t1;
  return v;
}

}  // namespace

std::vector<Voice> buildVoices(std::vector<Partial>&& partials, const VoiceParams& vp) {
  std::vector<Voice> out;
  out.reserve(partials.size());
  if (!vp.stacks || partials.size() < (size_t)kMinMembers) {
    for (Partial& p : partials) out.push_back(plainVoice(std::move(p)));
    return out;
  }
  const size_t n = partials.size();
  std::vector<Sampled> smp(n);
  for (size_t i = 0; i < n; ++i) smp[i] = sample(partials[i]);
  std::vector<char> used(n, 0);
  const StackBuilder sb(partials, smp, vp, 20000.0);

  // Strongest first: its harmonic family is the most valuable one. A partial may be the fundamental (h = 1) or
  // the 2nd / 3rd harmonic of a voice whose fundamental is weak or missing.
  std::vector<int> order((size_t)n);
  for (size_t i = 0; i < n; ++i) order[i] = (int)i;
  std::sort(order.begin(), order.end(), [&](int a, int b) { return partials[(size_t)a].energy > partials[(size_t)b].energy; });
  std::vector<Member> mem, bestMem;
  for (int a : order) {
    if (used[(size_t)a]) continue;
    Voice best;
    double bestEnergy = 0.0, bestMemberChars = 0.0;
    for (int h = 1; h <= 3; ++h) {
      if (!sb.findMembers(a, h, used, mem)) continue;
      Voice v;
      double energy = 0.0, chars = 0.0;
      if (!sb.fit(mem, v, energy, chars)) continue;
      // a stack has to be clearly cheaper than the partials it replaces, otherwise it only costs fidelity
      const double cost = (double)partialTrackText(v.pts, 1.0).size() + (double)partialHarmonicsText(v.gains).size() +
                          (v.dyn.empty() ? 0.0 : (double)partialDynamicsText(v.dyn).size());
      if (cost > 0.7 * chars) continue;
      if (energy > bestEnergy) {
        bestEnergy = energy;
        bestMemberChars = chars;
        best = std::move(v);
        bestMem = mem;
      }
    }
    (void)bestMemberChars;
    if (bestEnergy > 0.0) {
      for (const Member& m : bestMem) used[(size_t)m.idx] = 1;
      out.push_back(std::move(best));
    }
  }
  for (size_t i = 0; i < n; ++i)
    if (!used[i]) out.push_back(plainVoice(std::move(partials[i])));
  return out;
}

}  // namespace analysis
}  // namespace cw
