#include "script_text.h"

#include <cmath>
#include <cstdio>

#include "../dsp/common.h"

namespace cw {
namespace analysis {

std::string fmt(double v, int decimals) {
  char buf[64];
  std::snprintf(buf, sizeof buf, "%.*f", decimals, v);
  std::string s(buf);
  if (s.find('.') != std::string::npos) {
    while (!s.empty() && s.back() == '0') s.pop_back();
    if (!s.empty() && s.back() == '.') s.pop_back();
  }
  if (s.empty() || s == "-0") s = "0";
  return s;
}

std::string fmtHz(double hz) { return fmt(hz, hz >= 1000.0 ? 0 : (hz >= 100.0 ? 1 : 2)); }

std::string fmtAmp(double v) {
  v = clampd(v, 0.0, 4.0);
  if (v <= 0.0) return "0";
  const int mag = (int)std::floor(std::log10(v));  // 0.42 -> -1, 0.0042 -> -3
  return fmt(v, std::min(6, std::max(0, 1 - mag)));
}

std::string noteName(double hz) {
  static const char* names[12] = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};
  if (hz < 8.0) return "";
  const long m = std::lround(69.0 + 12.0 * std::log2(hz / 440.0));
  const long pc = ((m % 12) + 12) % 12;
  const long oct = (m - pc) / 12 - 1;
  return std::string(names[pc]) + std::to_string(oct);
}

std::string clockText(double sec) {
  char buf[32];
  if (sec < 100.0) {
    std::snprintf(buf, sizeof buf, "%.1f s", sec);
  } else {
    const int s = (int)std::floor(sec + 0.5);
    std::snprintf(buf, sizeof buf, "%d:%02d", s / 60, s % 60);
  }
  return buf;
}

std::string sanitizeName(const std::string& in) {
  std::string out;
  size_t from = in.find_last_of("/\\");
  from = from == std::string::npos ? 0 : from + 1;
  for (size_t i = from; i < in.size(); ++i) {
    const char c = in[i];
    if (out.size() >= 48) break;
    const unsigned char u = (unsigned char)c;
    out += (u >= 32 && u < 127 && c != '"' && c != '\\') ? c : '_';
  }
  return out;
}

std::string envelopeText(const std::vector<Pt2>& env) {
  const bool wrap = env.size() > 8;
  std::string s = wrap ? "  envelope.custom(\n    " : "  envelope.custom(";
  int onLine = 0;
  for (size_t i = 0; i < env.size(); ++i) {
    if (i) {
      s += ",";
      if (wrap && onLine >= 8) {
        s += "\n    ";
        onLine = 0;
      } else {
        s += " ";
      }
    }
    s += fmt(round3(env[i].first), 3) + ", " + fmtAmp(env[i].second);
    ++onLine;
  }
  return s + (wrap ? "\n  );\n" : ");\n");
}

std::string envelopeDeltasText(const std::vector<Pt2>& env) {
  const bool wrap = env.size() > 10;
  std::string s = wrap ? "  envelope.deltas(\n    " : "  envelope.deltas(";
  long prev = 0;
  int onLine = 0;
  for (size_t i = 0; i < env.size(); ++i) {
    const long ms = std::lround(env[i].first * 1000.0);
    if (i) {
      s += ",";
      if (wrap && onLine >= 12) {
        s += "\n    ";
        onLine = 0;
      }
    }
    s += std::to_string(std::max(0L, ms - prev)) + "," + fmtAmp(env[i].second);
    prev = ms;
    ++onLine;
  }
  return s + (wrap ? "\n  );\n" : ");\n");
}

std::string partialTrackText(const std::vector<TrackPt>& pts, double scale) {
  std::string s = "partial.track(";
  for (size_t i = 0; i < pts.size(); ++i) {
    if (i) s += (i % 6 == 0) ? ",\n  " : ",";
    s += fmt(round3(pts[i].t), 3) + "," + fmtHz(pts[i].f) + "," + fmtAmp(pts[i].a / scale);
  }
  return s + ");\n";
}

std::string partialHarmonicsText(const std::vector<float>& gains) {
  std::string s = "partial.harmonics(";
  for (size_t i = 0; i < gains.size(); ++i) {
    if (i) s += (i % 16 == 0) ? ",\n  " : ",";
    s += fmtAmp(gains[i]);
  }
  return s + ");\n";
}

std::string partialDynamicsText(const std::vector<float>& dyn) {
  std::string s = "partial.dynamics(";
  for (size_t i = 0; i < dyn.size(); ++i) {
    if (i) s += (i % 16 == 0) ? ",\n  " : ",";
    s += fmt(dyn[i], 1);
  }
  return s + ");\n";
}

}  // namespace analysis
}  // namespace cw
