// CodeWave Studio - audio -> script analysis: the noise model.
//
// Everything the partials do not explain (drums, breath, hiss, rumble, reverb tails) is rebuilt from a few
// band-passed noise layers whose level follows the sound. This module finds those levels: it measures the
// leftover energy per band (original minus what the emitted partials will actually sound like) and solves for
// the white-noise volume each band filter needs, accounting for the overlap between neighbouring filters.
#pragma once

#include <vector>

namespace cw {
namespace analysis {

struct Bands {
  int nb = 0;
  std::vector<double> edge;    // nb + 1
  std::vector<double> center;  // nb
  std::vector<double> q;       // nb (per biquad, two biquads in series)
};

// `nb` log-spaced bands between 60 Hz and 16 kHz (fewer when the sample rate or the count does not allow it).
Bands makeBands(int nb, int sr);

struct NoiseLevels {
  double hopSec = 0.0;
  std::vector<std::vector<float>> v;  // per band, per frame: white-noise volume that reproduces the leftover energy
};

// `tonal` is what the emitted partials sound like (same length as x; empty = no partials).
NoiseLevels analyseNoise(const std::vector<float>& x, const std::vector<float>& tonal, int sr, const Bands& B);

}  // namespace analysis
}  // namespace cw
