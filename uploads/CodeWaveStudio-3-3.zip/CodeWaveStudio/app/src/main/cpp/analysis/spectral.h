// CodeWave Studio - audio -> script analysis: spectral building blocks (FFT, STFT, hearing weight).
#pragma once

#include <cmath>
#include <functional>
#include <vector>

namespace cw {
namespace analysis {

inline int nextPow2(int v) {
  int p = 1;
  while (p < v) p <<= 1;
  return p;
}

inline double semis(double hz) { return 12.0 * std::log2(hz); }

// How much a frequency matters to a listener (A-weighting, softened, 1.0 at 1 kHz). Used only to decide what
// is worth spending commands on - never to change a level.
double hearingWeight(double hz);

// Hann-window STFT. Frame f is centred on sample f*H (zero padded at both ends), frames = len/H + 2. Two real
// frames share one complex FFT. cb(frame, |X|[0..N/2]) receives the raw (unnormalised) magnitudes.
//   amplitude of a steady sine  = |X| * hannAmp(N)
//   variance share of a bin     = |X|^2 * hannPow(N)   (sums over bins to the signal variance)
using FrameFn = std::function<void(int frame, const float* mag)>;
void forEachFrame(const std::vector<float>& x, int N, int H, const FrameFn& cb);

inline double hannAmp(int N) { return 4.0 / N; }
inline double hannPow(int N) { return 16.0 / (3.0 * (double)N * (double)N); }

}  // namespace analysis
}  // namespace cw
