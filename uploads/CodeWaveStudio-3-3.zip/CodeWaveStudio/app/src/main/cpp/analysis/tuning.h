// CodeWave Studio - audio -> script analysis: development hooks.
//
// Release builds see constants and empty functions, so none of this costs anything. Building the analyser with
// -DA2C_DEBUG (tools/eval/build_debug.sh) turns on
//   knob("A_...", default)   override any tuning value from the environment, to tune against tools/eval
//   Lap                      per-stage timings on stderr
//   A2C_LOG(...)             statistics on stderr
#pragma once

#ifdef A2C_DEBUG
#include <chrono>
#include <cstdio>
#include <cstdlib>

namespace cw {
namespace analysis {

inline double knob(const char* name, double def) {
  const char* v = std::getenv(name);
  return v ? std::atof(v) : def;
}

struct Lap {
  std::chrono::steady_clock::time_point last = std::chrono::steady_clock::now();
  void operator()(const char* stage) {
    const auto now = std::chrono::steady_clock::now();
    std::fprintf(stderr, "[a2c] %-14s %7.0f ms\n", stage, std::chrono::duration<double, std::milli>(now - last).count());
    last = now;
  }
};

}  // namespace analysis
}  // namespace cw
#define A2C_LOG(...) std::fprintf(stderr, __VA_ARGS__)

#else

namespace cw {
namespace analysis {

constexpr double knob(const char*, double def) { return def; }

struct Lap {
  void operator()(const char*) const {}
};

}  // namespace analysis
}  // namespace cw
#define A2C_LOG(...) ((void)0)

#endif
