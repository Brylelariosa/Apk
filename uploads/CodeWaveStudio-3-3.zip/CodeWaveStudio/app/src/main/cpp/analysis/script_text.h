// CodeWave Studio - audio -> script analysis: turning numbers into script text.
#pragma once

#include <string>
#include <vector>

#include "curve_fit.h"

namespace cw {
namespace analysis {

std::string fmt(double v, int decimals);  // fixed decimals, trailing zeros removed
inline double round3(double v) { return std::round(v * 1000.0) / 1000.0; }
std::string fmtHz(double hz);   // 2 decimals below 100 Hz, 1 below 1 kHz, whole Hz above: always within ~2 cents
std::string fmtAmp(double v);   // two significant digits
std::string noteName(double hz);
std::string clockText(double sec);
std::string sanitizeName(const std::string& in);  // one-line, printable ASCII, short

// envelope.custom(...): short ones on one line, long ones wrapped (the parser treats line breaks as spaces).
std::string envelopeText(const std::vector<Pt2>& env);

// envelope.deltas(...): the same envelope with every time written as milliseconds since the previous point.
std::string envelopeDeltasText(const std::vector<Pt2>& env);

// partial.track(...) with volumes divided by `scale`; wrapped every few points.
std::string partialTrackText(const std::vector<TrackPt>& pts, double scale);

// partial.harmonics(...)
std::string partialHarmonicsText(const std::vector<float>& gains);

// partial.dynamics(...)
std::string partialDynamicsText(const std::vector<float>& dyn);

}  // namespace analysis
}  // namespace cw
