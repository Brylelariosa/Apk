// CodeWave Studio - audio -> script analysis: voices.
//
// A voice is what one partial.track command plays: a single partial, or a harmonic stack (one pitch curve and
// one volume curve shared by many harmonics, each with its own fixed volume). Real instruments and voices are
// mostly harmonic, so collapsing their partials into stacks is how a lot of sound fits into little script.
#pragma once

#include <vector>

#include "partials.h"

namespace cw {
namespace analysis {

struct Voice {
  std::vector<TrackPt> pts;  // (time, Hz of harmonic 1, amplitude of the loudest harmonic; input peak = 1)
  std::vector<float> gains;  // empty = a plain partial; else harmonic k's volume at the voice's peak (loudest = 1)
  std::vector<float> dyn;    // per harmonic: exponent of the volume it follows (1 = in proportion); empty = all 1
  double peak = 0.0;         // largest amplitude of any harmonic
  double energy = 0.0;       // hearing-weighted energy it explains
  double heard = 0.0;        // largest amplitude x hearing weight
  double t0 = 0.0, t1 = 0.0;
  int members = 1;           // analysed partials it stands for
};

struct VoiceParams {
  bool stacks = true;        // group harmonic partials
  double maxFitErrDb = 5.0;  // a stack must follow its members' volume curves this closely (rms, dB)
  double minCoverage = 0.55; // ... and be seen at least this much of the time (weighted by loudness)
  int maxHarmonics = 24;
  double ampTolDb = 2.0;     // fit tolerance of the stack's curves
  double freqTolCents = 10.0;
  int maxPoints = 40;
};

std::vector<Voice> buildVoices(std::vector<Partial>&& partials, const VoiceParams& vp);

}  // namespace analysis
}  // namespace cw
