#include "detail_levels.h"

#include "tuning.h"

namespace cw {
namespace analysis {
namespace {

const Params& preset(int detail) {
  static const Params kPresets[3] = {
      // Simple: short code
      {/*partial*/ {15.0, -55.0, 42.0, 24, 0.080, 3.5, 25.0, 14, 8000.0},
       /*voice*/ {true, 6.0, 0.5, 12, 3.5, 25.0, 14},
       /*toneRelDb*/ 30.0, /*nBands*/ 8, /*noiseRelDb*/ 45.0, /*bandTolDb*/ 3.0, /*maxChars*/ 60000, /*charShare*/ 0.45,
       /*minBandPtsPerSec*/ 8.0, "Simple"},
      // Normal
      {{12.0, -62.0, 50.0, 48, 0.050, 2.5, 15.0, 24, 10000.0},
       {true, 5.5, 0.55, 18, 2.5, 15.0, 24},
       40.0, 12, 50.0, 2.0, 150000, 0.45, 8.0, "Normal"},
      // Detailed: as much as fits
      {{10.0, -70.0, 58.0, 96, 0.035, 2.2, 12.0, 40, 12000.0},
       {true, 5.0, 0.55, 24, 2.2, 12.0, 40},
       55.0, 16, 55.0, 1.2, kLargestScript, 0.42, 8.0, "Detailed"},
  };
  return kPresets[detail < 0 ? 0 : (detail > 2 ? 2 : detail)];
}

}  // namespace

Params paramsFor(int detail) {
  Params P = preset(detail);
  // (development builds only: every value can be overridden from the environment, see tuning.h)
  P.partial.snrDb = knob("A_SNR", P.partial.snrDb);
  P.partial.floorDb = knob("A_FLOOR", P.partial.floorDb);
  P.partial.dynDb = knob("A_DYN", P.partial.dynDb);
  P.partial.maxPeaks = (int)knob("A_PEAKS", P.partial.maxPeaks);
  P.partial.minTrackSec = knob("A_MINT", P.partial.minTrackSec);
  P.partial.ampTolDb = knob("A_ATOL", P.partial.ampTolDb);
  P.partial.freqTolCents = knob("A_FTOL", P.partial.freqTolCents);
  P.partial.maxPoints = (int)knob("A_PTS", P.partial.maxPoints);
  P.partial.maxHz = knob("A_MAXHZ", P.partial.maxHz);
  P.voice.stacks = knob("A_STACKS", P.voice.stacks ? 1 : 0) > 0.5;
  P.voice.maxFitErrDb = knob("A_FIT", P.voice.maxFitErrDb);
  P.voice.minCoverage = knob("A_COV", P.voice.minCoverage);
  P.voice.maxHarmonics = (int)knob("A_MAXK", P.voice.maxHarmonics);
  P.voice.ampTolDb = knob("A_VATOL", P.voice.ampTolDb);
  P.voice.freqTolCents = knob("A_VFTOL", P.voice.freqTolCents);
  P.voice.maxPoints = (int)knob("A_VPTS", P.voice.maxPoints);
  P.toneRelDb = knob("A_REL", P.toneRelDb);
  P.nBands = (int)knob("A_NB", P.nBands);
  P.noiseRelDb = knob("A_NREL", P.noiseRelDb);
  P.bandTolDb = knob("A_BTOL", P.bandTolDb);
  P.charShare = knob("A_SHARE", P.charShare);
  P.maxChars = (size_t)knob("A_CHARS", (double)P.maxChars);
  P.minBandPtsPerSec = knob("A_MINBPS", P.minBandPtsPerSec);
  return P;
}

}  // namespace analysis
}  // namespace cw
