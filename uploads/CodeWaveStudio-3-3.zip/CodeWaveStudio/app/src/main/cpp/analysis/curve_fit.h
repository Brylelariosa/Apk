// CodeWave Studio - audio -> script analysis: piece-wise linear curve fitting (envelopes and partial tracks).
#pragma once

#include <algorithm>
#include <cmath>
#include <queue>
#include <utility>
#include <vector>

#include "../dsp/common.h"

namespace cw {
namespace analysis {

using Pt2 = std::pair<double, double>;  // (time, value)

// One breakpoint of a partial: seconds, Hz, linear amplitude (input peak = 1).
struct TrackPt {
  double t = 0.0, f = 0.0, a = 0.0;
};

// Priority-queue Ramer-Douglas-Peucker over n points. worst(a, b, &w) returns the largest normalised error
// (1.0 = exactly on tolerance) among the points strictly between a and b and stores its index in w (-1 when
// there are none). Segments are split, worst first, until every error is <= 1 or maxPts points are selected.
// Returns the sorted indices of the selected points (always includes 0 and n - 1). O(n log n).
template <class Worst>
std::vector<int> selectBreakpoints(int n, int maxPts, Worst worst) {
  std::vector<int> sel;
  if (n <= 0) return sel;
  if (n <= 2) {
    for (int i = 0; i < n; ++i) sel.push_back(i);
    return sel;
  }
  struct Seg {
    double err;
    int a, b, w;
  };
  auto cmp = [](const Seg& x, const Seg& y) { return x.err < y.err; };
  std::priority_queue<Seg, std::vector<Seg>, decltype(cmp)> heap(cmp);
  sel = {0, n - 1};
  auto push = [&](int a, int b) {
    if (b - a < 2) return;
    int w = -1;
    const double e = worst(a, b, &w);
    if (w >= 0 && e > 1.0) heap.push(Seg{e, a, b, w});
  };
  push(0, n - 1);
  while (!heap.empty() && (int)sel.size() < maxPts) {
    const Seg top = heap.top();
    heap.pop();
    sel.push_back(top.w);
    push(top.a, top.w);
    push(top.w, top.b);
  }
  std::sort(sel.begin(), sel.end());
  return sel;
}

// Several envelopes share one point budget (judged against how envelope.deltas joins points: straight lines on a dB
// scale): the segment whose dB error (times the curve's weight) is the largest anywhere gets the next point. A
// smooth band keeps few points, a band that follows a beat gets many.
//
// Errors are only counted above a floor (values below it count as the floor): what is more than ~25 dB under a
// band's loudest moment is inaudible next to it and must not eat points. Floors are used from the highest to the
// lowest: when every audible error is within tolerance and budget is left, the next lower floor refines further
// (a short sound has plenty of budget and gets its quiet tails too; a long one never gets there).
struct EnvCurve {
  const std::vector<Pt2>* pts;
  double tolDb;
  double weight;  // how much a dB of error in this curve matters (0..1)
};

//
// Every curve first gets up to `minPts` points of its own (so a quiet band never goes flat), then the shared budget
// is spent where the error is largest.
inline std::vector<std::vector<Pt2>> simplifyEnvelopes(const std::vector<EnvCurve>& curves, int totalPts,
                                                        const std::vector<double>& floors, int minPts) {
  struct Seg {
    double err;
    int c, a, b, w;
  };
  auto cmp = [](const Seg& x, const Seg& y) { return x.err < y.err; };
  const int nc = (int)curves.size();
  std::vector<std::vector<int>> sel((size_t)nc);
  std::vector<std::vector<double>> db((size_t)nc);
  int used = 0;
  for (int c = 0; c < nc; ++c) {
    const int n = (int)curves[(size_t)c].pts->size();
    if (n >= 1) sel[(size_t)c].push_back(0);
    if (n >= 2) sel[(size_t)c].push_back(n - 1);
    used += (int)sel[(size_t)c].size();
  }
  // each curve on its own, down to the first (highest) floor
  if (!floors.empty() && minPts > 2) {
    const int each = std::max(2, std::min(minPts, nc > 0 ? totalPts / (2 * nc) : 2));
    for (int c = 0; c < nc; ++c) {
      const std::vector<Pt2>& in = *curves[(size_t)c].pts;
      const EnvCurve& cv = curves[(size_t)c];
      const int n = (int)in.size();
      if (n < 3) continue;
      std::vector<double> dbl((size_t)n);
      for (int i = 0; i < n; ++i) dbl[(size_t)i] = 20.0 * std::log10(std::max(in[(size_t)i].second, floors[0]));
      auto worst = [&](int a, int b, int* w) {
        double best = 0.0;
        *w = -1;
        const double ta = in[(size_t)a].first, span = std::max(1e-9, in[(size_t)b].first - ta);
        for (int i = a + 1; i < b; ++i) {
          const double u = (in[(size_t)i].first - ta) / span;
          const double v = joinVolume(in[(size_t)a].second, in[(size_t)b].second, u);
          const double e = std::fabs(20.0 * std::log10(std::max(v, floors[0])) - dbl[(size_t)i]) / cv.tolDb;
          if (e > best) {
            best = e;
            *w = i;
          }
        }
        return best;
      };
      sel[(size_t)c] = selectBreakpoints(n, each, worst);
      used += (int)sel[(size_t)c].size() - 2;
    }
  }
  for (double floorV : floors) {
    if (used >= totalPts) break;
    std::priority_queue<Seg, std::vector<Seg>, decltype(cmp)> heap(cmp);
    auto push = [&](int c, int a, int b) {
      if (b - a < 2) return;
      const std::vector<Pt2>& in = *curves[(size_t)c].pts;
      const EnvCurve& cv = curves[(size_t)c];
      const double ta = in[(size_t)a].first, span = std::max(1e-9, in[(size_t)b].first - ta);
      const double va = in[(size_t)a].second, vb = in[(size_t)b].second;
      double best = 0.0;
      int w = -1;
      for (int i = a + 1; i < b; ++i) {
        const double u = (in[(size_t)i].first - ta) / span;
        const double v = joinVolume(va, vb, u);  // how the engine joins the points
        const double e = std::fabs(20.0 * std::log10(std::max(v, floorV)) - db[(size_t)c][(size_t)i]) / cv.tolDb;
        if (e > best) {
          best = e;
          w = i;
        }
      }
      if (w >= 0 && best > 1.0) heap.push(Seg{best * cv.weight, c, a, b, w});
    };
    for (int c = 0; c < nc; ++c) {
      const std::vector<Pt2>& in = *curves[(size_t)c].pts;
      db[(size_t)c].resize(in.size());
      for (size_t i = 0; i < in.size(); ++i) db[(size_t)c][i] = 20.0 * std::log10(std::max(in[i].second, floorV));
      std::sort(sel[(size_t)c].begin(), sel[(size_t)c].end());
      for (size_t k = 0; k + 1 < sel[(size_t)c].size(); ++k) push(c, sel[(size_t)c][k], sel[(size_t)c][k + 1]);
    }
    while (!heap.empty() && used < totalPts) {
      const Seg top = heap.top();
      heap.pop();
      sel[(size_t)top.c].push_back(top.w);
      ++used;
      push(top.c, top.a, top.w);
      push(top.c, top.w, top.b);
    }
  }
  std::vector<std::vector<Pt2>> out((size_t)nc);
  for (int c = 0; c < nc; ++c) {
    std::sort(sel[(size_t)c].begin(), sel[(size_t)c].end());
    for (int i : sel[(size_t)c]) out[(size_t)c].push_back((*curves[(size_t)c].pts)[(size_t)i]);
  }
  return out;
}

// Partial fit: amplitude in dB and frequency in cents, both judged against how the engine joins the points
// (volume straight on a dB scale, frequency straight in Hz).
inline std::vector<TrackPt> simplifyTrack(const std::vector<TrackPt>& in, int maxPts, double tolDb, double tolCents,
                                          double floorA) {
  const int n = (int)in.size();
  if (n <= 2) return in;
  std::vector<double> db((size_t)n);
  for (int i = 0; i < n; ++i) db[(size_t)i] = 20.0 * std::log10(std::max(in[(size_t)i].a, floorA));
  auto worst = [&](int a, int b, int* w) {
    double best = 0.0;
    *w = -1;
    const TrackPt& A = in[(size_t)a];
    const TrackPt& B = in[(size_t)b];
    const double span = std::max(1e-9, B.t - A.t);
    for (int i = a + 1; i < b; ++i) {
      const TrackPt& P = in[(size_t)i];
      const double u = (P.t - A.t) / span;
      const double amp = joinVolume(A.a, B.a, u), fr = A.f + (B.f - A.f) * u;
      const double ea = std::fabs(20.0 * std::log10(std::max(amp, floorA)) - db[(size_t)i]) / tolDb;
      const double ef = 1200.0 * std::fabs(std::log2(fr / P.f)) / tolCents;
      const double e = std::max(ea, ef);
      if (e > best) {
        best = e;
        *w = i;
      }
    }
    return best;
  };
  std::vector<TrackPt> out;
  for (int i : selectBreakpoints(n, maxPts, worst)) out.push_back(in[(size_t)i]);
  return out;
}

}  // namespace analysis
}  // namespace cw
