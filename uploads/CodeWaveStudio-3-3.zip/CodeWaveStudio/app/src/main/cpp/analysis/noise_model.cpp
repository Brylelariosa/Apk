#include "noise_model.h"

#include <algorithm>
#include <cmath>

#include "../dsp/dsp.h"
#include "spectral.h"
#include "tuning.h"

namespace cw {
namespace analysis {
namespace {

// How the bins of one STFT feed the bands. A bin is as wide as the spectrum it stands for, so a bin that straddles
// a band edge is split between the two bands in proportion (a narrow band holds only a handful of bins; counting
// whole bins would make some bands read several dB too loud or quiet).
struct BinShare {
  int b0 = -1, b1 = -1;
  float w0 = 0.0f, w1 = 0.0f;
};

std::vector<BinShare> binShares(const Bands& B, int N, int sr) {
  std::vector<BinShare> r((size_t)N / 2 + 1);
  const double df = (double)sr / N;
  for (int k = 1; k <= N / 2; ++k) {
    const double lo = (k - 0.5) * df, hi = (k + 0.5) * df;
    for (int j = 0; j < B.nb; ++j) {
      const double ov = std::min(hi, B.edge[(size_t)j + 1]) - std::max(lo, B.edge[(size_t)j]);
      if (ov <= 0.0) continue;
      BinShare& s = r[(size_t)k];
      if (s.b0 < 0) {
        s.b0 = j;
        s.w0 = (float)(ov / df);
      } else if (s.b1 < 0) {
        s.b1 = j;
        s.w1 = (float)(ov / df);
      }
    }
  }
  return r;
}

// M[j][i]: share of the variance of white noise, filtered by band filter i, that the STFT with `rowN[j]` bins
// assigns to analysis band j. Built from the very same bin shares the measurement uses.
std::vector<double> bandMixMatrix(const Bands& B, int sr, const std::vector<int>& rowN) {
  const int G = 8192;
  std::vector<std::vector<BinShare>> shares;  // by distinct N
  std::vector<int> distinct;
  auto sharesFor = [&](int N) -> const std::vector<BinShare>& {
    for (size_t t = 0; t < distinct.size(); ++t)
      if (distinct[t] == N) return shares[t];
    distinct.push_back(N);
    shares.push_back(binShares(B, N, sr));
    return shares.back();
  };
  for (int j = 0; j < B.nb; ++j) sharesFor(rowN[(size_t)j]);  // (fill first: references must stay valid)
  std::vector<double> M((size_t)B.nb * (size_t)B.nb, 0.0);
  for (int i = 0; i < B.nb; ++i) {
    const BiquadCoef co = designBiquad(FilterType::Band, B.center[(size_t)i], B.q[(size_t)i], sr);
    for (int g = 0; g < G; ++g) {
      const double w = kPi * (g + 0.5) / G;
      const double c1 = std::cos(w), s1 = std::sin(w), c2 = std::cos(2 * w), s2 = std::sin(2 * w);
      const double nr = co.b0 + co.b1 * c1 + co.b2 * c2, ni = -(co.b1 * s1 + co.b2 * s2);
      const double dr = 1.0 + co.a1 * c1 + co.a2 * c2, di = -(co.a1 * s1 + co.a2 * s2);
      const double h2 = (nr * nr + ni * ni) / (dr * dr + di * di);
      const double h4 = h2 * h2 / G;  // two biquads in series
      for (int j = 0; j < B.nb; ++j) {
        const int N = rowN[(size_t)j];
        const int k = std::min(N / 2, (int)std::lround(w * N / kTwoPi));
        const BinShare& sh = sharesFor(N)[(size_t)k];
        double wt = 0.0;
        if (sh.b0 == j) wt = sh.w0;
        else if (sh.b1 == j) wt = sh.w1;
        if (wt > 0.0) M[(size_t)j * (size_t)B.nb + (size_t)i] += h4 * wt;
      }
    }
  }
  return M;
}

// Variance of every analysis band in every frame of one STFT (frames x nb).
std::vector<double> bandPowers(const std::vector<float>& x, int N, int H, const std::vector<BinShare>& share, int nb) {
  const int F = (int)x.size() / H + 2;
  std::vector<double> V((size_t)F * (size_t)nb, 0.0);
  if (x.empty()) return V;
  const double powNorm = hannPow(N);
  forEachFrame(x, N, H, [&](int f, const float* mag) {
    double* v = &V[(size_t)f * (size_t)nb];
    for (int k = 1; k <= N / 2; ++k) {
      const BinShare& s = share[(size_t)k];
      if (s.b0 < 0) continue;
      const double p = (double)mag[k] * mag[k] * powNorm;
      v[s.b0] += s.w0 * p;
      if (s.b1 >= 0) v[s.b1] += s.w1 * p;
    }
  });
  return V;
}

}  // namespace

Bands makeBands(int nb, int sr) {
  Bands B;
  const double flo = 60.0;
  const double fhi = std::min(0.45 * sr, 16000.0);
  while (nb > 2 && fhi / flo < std::pow(1.22, nb)) --nb;
  B.nb = nb;
  B.edge.resize((size_t)nb + 1);
  for (int j = 0; j <= nb; ++j) B.edge[(size_t)j] = flo * std::pow(fhi / flo, (double)j / nb);
  for (int j = 0; j < nb; ++j) {
    const double lo = B.edge[(size_t)j], hi = B.edge[(size_t)j + 1];
    const double fc = std::sqrt(lo * hi);
    B.center.push_back(fc);
    B.q.push_back(clampd(0.7 * fc / (hi - lo), 0.3, 12.0));
  }
  return B;
}

NoiseLevels analyseNoise(const std::vector<float>& x, const std::vector<float>& tonal, int sr, const Bands& B) {
  Lap lap;
  const int n = (int)x.size();
  const int nb = B.nb;
  // Every band is measured with its own window: just long enough to hold a few bins of the band (a narrow bass
  // band needs a long one, a wide treble band a very short one, so a hi-hat keeps its sharp start).
  const int Hc = std::max(32, (int)std::lround(0.0029 * sr));  // common time grid of the result
  const int Fc = n / Hc + 2;
  NoiseLevels R;
  R.hopSec = (double)Hc / sr;

  std::vector<int> bandN((size_t)nb);
  std::vector<int> distinct;
  for (int b = 0; b < nb; ++b) {
    const double width = B.edge[(size_t)b + 1] - B.edge[(size_t)b];
    int N = nextPow2((int)std::lround(4.0 * sr / width));
    N = std::max(256, std::min(4096, N));
    bandN[(size_t)b] = N;
    if (std::find(distinct.begin(), distinct.end(), N) == distinct.end()) distinct.push_back(N);
  }
  // leftover[b][c]: variance of band b at common frame c that the partials do not explain
  std::vector<double> V((size_t)Fc * (size_t)nb, 0.0);
  auto leftover = [](double orig, double ton) {
    const double r = orig - ton;
    return r > 0.04 * orig ? r : 0.0;
  };
  for (int N : distinct) {
    const int H = std::max(Hc, std::min(N / 4, 1024) / Hc * Hc);  // (long windows barely move: a coarse hop is enough)
    const int F = n / H + 2;
    const std::vector<BinShare> share = binShares(B, N, sr);
    const std::vector<double> orig = bandPowers(x, N, H, share, nb);
    const std::vector<double> ton = tonal.empty() ? std::vector<double>((size_t)F * (size_t)nb, 0.0) : bandPowers(tonal, N, H, share, nb);
    for (int c = 0; c < Fc; ++c) {
      const double u = (double)c * Hc / H;
      const int i0 = std::min(F - 1, (int)std::floor(u));
      const int i1 = std::min(F - 1, i0 + 1);
      const double fr = u - std::floor(u);
      for (int b = 0; b < nb; ++b) {
        if (bandN[(size_t)b] != N) continue;
        const size_t a0 = (size_t)i0 * (size_t)nb + (size_t)b, a1 = (size_t)i1 * (size_t)nb + (size_t)b;
        V[(size_t)c * (size_t)nb + (size_t)b] = (1.0 - fr) * leftover(orig[a0], ton[a0]) + fr * leftover(orig[a1], ton[a1]);
      }
    }
  }

  lap("noise/stft");
  // Smooth each band over time. A band of width W cannot show events shorter than about 1/W seconds, and a
  // single-frame estimate of a narrow band is very noisy (few bins): fitting a curve to that noise would lock onto
  // its dips and make the rendered band too quiet. So narrow (low) bands are smoothed more than wide ones.
  std::vector<double> S((size_t)Fc * (size_t)nb, 0.0);
  for (int b = 0; b < nb; ++b) {
    const double width = B.edge[(size_t)b + 1] - B.edge[(size_t)b];
    const int hw = std::max(1, std::min(24, (int)std::ceil(0.5 / (width * R.hopSec))));
    double norm = 0.0;
    for (int d = -hw; d <= hw; ++d) norm += (double)(hw + 1 - std::abs(d));
    for (int f = 0; f < Fc; ++f) {
      double acc = 0.0;
      for (int d = -hw; d <= hw; ++d) {
        const int g = std::max(0, std::min(Fc - 1, f + d));
        acc += (double)(hw + 1 - std::abs(d)) * V[(size_t)g * (size_t)nb + (size_t)b];
      }
      S[(size_t)f * (size_t)nb + (size_t)b] = acc / norm;
    }
  }

  // Non-negative least squares against the real filters (multiplicative KL updates).
  const std::vector<double> M = bandMixMatrix(B, sr, bandN);
  lap("noise/mixmatrix");
  std::vector<double> colSum((size_t)nb, 0.0);
  for (int i = 0; i < nb; ++i)
    for (int j = 0; j < nb; ++j) colSum[(size_t)i] += M[(size_t)j * (size_t)nb + (size_t)i];
  R.v.assign((size_t)nb, std::vector<float>((size_t)Fc, 0.0f));
  std::vector<double> a((size_t)nb), est((size_t)nb);
  for (int f = 0; f < Fc; ++f) {
    const double* v = &S[(size_t)f * (size_t)nb];
    double tot = 0.0;
    for (int j = 0; j < nb; ++j) tot += v[j];
    if (tot < 1e-14) continue;
    for (int i = 0; i < nb; ++i) a[(size_t)i] = v[i] / std::max(0.05, M[(size_t)i * (size_t)nb + (size_t)i]) + 1e-12;
    for (int it = 0; it < 24; ++it) {
      for (int j = 0; j < nb; ++j) {
        double e = 1e-20;
        for (int i = 0; i < nb; ++i) e += M[(size_t)j * (size_t)nb + (size_t)i] * a[(size_t)i];
        est[(size_t)j] = e;
      }
      for (int i = 0; i < nb; ++i) {
        double num = 0.0;
        for (int j = 0; j < nb; ++j) num += M[(size_t)j * (size_t)nb + (size_t)i] * v[j] / est[(size_t)j];
        a[(size_t)i] *= num / std::max(1e-12, colSum[(size_t)i]);
      }
    }
    for (int i = 0; i < nb; ++i) R.v[(size_t)i][(size_t)f] = (float)std::sqrt(3.0 * std::max(0.0, a[(size_t)i]));
  }
  lap("noise/nnls");
  return R;
}

}  // namespace analysis
}  // namespace cw
