// partial.track / partial.harmonics / partial.dynamics - additive synthesis from (time, frequency, volume) points.
//
// The frequency is interpolated linearly between points, the volume in straight lines on a decibel scale (see
// joinVolume: decays and swells stay natural with few points; a fade from / to silence is a plain ramp). The phase
// is the running integral of the frequency (so a gliding or vibrato partial stays smooth), and every harmonic of
// a stack shares that phase.
// Harmonic k plays at k x the track frequency with the volume g_k * peak * (volume / peak)^p_k: g_k from
// partial.harmonics, p_k from partial.dynamics (1 = in proportion). Sines come from a 4096 point table with
// linear interpolation (error below -130 dB) and a 32-bit fixed point phase, which makes the inner loop a few
// nanoseconds per harmonic.
#include "dsp.h"

namespace cw {
namespace {

constexpr int kTableBits = 12;
constexpr int kTableSize = 1 << kTableBits;
constexpr int kFracBits = 32 - kTableBits;

struct SineTable {
  float v[kTableSize + 2];
  SineTable() {
    for (int i = 0; i < kTableSize + 2; ++i) v[i] = (float)std::sin(kTwoPi * (double)i / (double)kTableSize);
  }
};

const float* sineTable() {
  static const SineTable t;
  return t.v;
}

// sin(2 pi x) for a 32-bit phase (2^32 = one cycle).
inline float tableSin(const float* tab, uint32_t ph) {
  const uint32_t i = ph >> kFracBits;
  const float fr = (float)(ph & ((1u << kFracBits) - 1u)) * (1.0f / (float)(1u << kFracBits));
  return tab[i] + (tab[i + 1] - tab[i]) * fr;
}

// Harmonics start at different, fixed phases (a golden-ratio sequence) so a stack does not begin as a
// needle-sharp pulse; the fundamental starts at 0.
inline uint32_t startPhase(int k) {
  if (k <= 1) return 0u;
  const double x = (double)k * (double)k * 0.6180339887498949;
  return (uint32_t)((x - std::floor(x)) * 4294967296.0);
}

}  // namespace

void renderPartialTrack(const double* pts, size_t count, const double* harm, size_t nHarm, const double* dyn, size_t nDyn,
                        float* out, int n, double pitchMul, double gain, int sampleRate, RenderCtx* cx) {
  if (!pts || count < 2 || n < 1 || sampleRate < 1) return;
  const float* tab = sineTable();
  const double inv = 1.0 / (double)sampleRate;
  const double nyq = 0.49 * (double)sampleRate;
  const double fadeBand = 0.04 * (double)sampleRate;  // harmonics fade out over the last 4 % below Nyquist
  const int K = nHarm > 0 ? (int)std::min<size_t>(nHarm, (size_t)limits::kMaxPartialHarmonics) : 1;
  float level[limits::kMaxPartialHarmonics + 1];   // g_k
  double expo[limits::kMaxPartialHarmonics + 1];   // p_k
  uint32_t starts[limits::kMaxPartialHarmonics + 1];
  bool anyExpo = false;
  for (int k = 1; k <= K; ++k) {
    level[k] = nHarm > 0 ? (float)harm[k - 1] : 1.0f;
    expo[k] = (dyn && (size_t)k <= nDyn) ? dyn[k - 1] : 1.0;
    if (expo[k] != 1.0) anyExpo = true;
    starts[k] = startPhase(k);
  }
  double peak = 0.0;
  for (size_t s = 0; s < count; ++s) peak = std::max(peak, pts[3 * s + 2]);
  if (peak <= 0.0) return;

  const long iFirst = std::lround(pts[0] * sampleRate);
  const long iLast = std::lround(pts[3 * (count - 1)] * sampleRate);
  if (iLast <= iFirst || iFirst >= n || iLast <= 0) return;
  const long total = std::min<long>(iLast, n) - std::max<long>(iFirst, 0);
  if (cx) cx->spend((double)total * (12.0 + 7.0 * (double)K));

  // volume of harmonic k at a breakpoint with track volume a
  auto harmVolume = [&](int k, double a) -> double {
    if (!anyExpo || expo[k] == 1.0) return (double)level[k] * a;
    return (double)level[k] * peak * std::pow(a / peak, expo[k]);
  };

  // 0.5 ms edge ramps keep a track whose first / last volume is not zero from clicking.
  const long ramp = std::max<long>(1, std::min<long>(std::lround(0.0005 * sampleRate), (iLast - iFirst) / 2));
  uint32_t phase = 0;
  long sinceCheck = 0;
  // per harmonic, volume(next sample) = volume * mul + add: a geometric segment multiplies, a linear one adds
  double amp[limits::kMaxPartialHarmonics + 1], mul[limits::kMaxPartialHarmonics + 1], add[limits::kMaxPartialHarmonics + 1];
  for (size_t s = 0; s + 1 < count; ++s) {
    const double f0 = clampd(pts[3 * s + 1] * pitchMul, 1.0, nyq);
    const double f1 = clampd(pts[3 * s + 4] * pitchMul, 1.0, nyq);
    const long i0 = std::lround(pts[3 * s] * sampleRate), i1 = std::lround(pts[3 * s + 3] * sampleRate);
    if (i1 <= i0) continue;
    const long from = std::max<long>(i0, 0), to = std::min<long>(i1, n);
    if (from >= to) continue;  // the segment lies outside the buffer
    const double span = 1.0 / (double)(i1 - i0);
    // per harmonic volume: value at the first rendered sample of this segment and how it moves per sample
    const double skip = (double)(from - i0);
    for (int k = 1; k <= K; ++k) {
      const double v0 = harmVolume(k, pts[3 * s + 2]), v1 = harmVolume(k, pts[3 * s + 5]);
      if (v0 >= kGeoMin && v1 >= kGeoMin) {
        mul[k] = std::pow(v1 / v0, span);
        add[k] = 0.0;
        amp[k] = v0 * std::pow(v1 / v0, skip * span);
      } else {
        mul[k] = 1.0;
        add[k] = (v1 - v0) * span;
        amp[k] = v0 + add[k] * skip;
      }
    }
    for (long i = from; i < to; ++i) {
      const double u = (double)(i - i0) * span;
      const double f = f0 + (f1 - f0) * u;
      double edge = 1.0;
      if (i < iFirst + ramp) edge = (double)(i - iFirst + 1) / (double)ramp;
      else if (i > iLast - ramp) edge = (double)(iLast - i) / (double)ramp;
      phase += (uint32_t)(int64_t)(f * inv * 4294967296.0);
      float v;
      if (K == 1) {
        v = tableSin(tab, phase + starts[1]) * (float)amp[1];
        amp[1] = amp[1] * mul[1] + add[1];
      } else {
        const int kmax = std::min(K, (int)(nyq / f));
        float acc = 0.0f;
        for (int k = 1; k <= kmax; ++k) {
          float g = (float)amp[k];
          amp[k] = amp[k] * mul[k] + add[k];
          if (g == 0.0f) continue;
          const double fk = f * k;
          if (fk > nyq - fadeBand) g *= (float)((nyq - fk) / fadeBand);
          acc += g * tableSin(tab, (uint32_t)k * phase + starts[k]);
        }
        for (int k = kmax + 1; k <= K; ++k) amp[k] = amp[k] * mul[k] + add[k];
        v = acc;
      }
      out[i] += (float)((double)v * edge * gain);
    }
    if (cx) {
      sinceCheck += to - from;
      if (sinceCheck >= 16384) {
        sinceCheck = 0;
        cx->check();
      }
    }
  }
}

}  // namespace cw
