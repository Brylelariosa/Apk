package com.hzcm.duelforge.model

/**
 * Static, immutable definition of a card - this is what gets loaded from cards.json
 * (plus an [com.hzcm.duelforge.data.EffectRegistry] entry for anything with [effects]).
 *
 * To add a brand-new vanilla Normal Monster: just add an entry to cards.json and drop
 * an image named "<id>.png" / "<id>.jpg" into assets/cards/. No code changes needed.
 *
 * To add a card with an effect (Trigger/Ignition/Quick/Continuous/Flip), also add a
 * matching block in EffectRegistry.kt keyed by the same id.
 */
data class Card(
    val id: String,
    val name: String,
    val cardType: CardType,
    val description: String,

    // Monster fields
    val attribute: Attribute? = null,
    val race: Race? = null,
    val level: Int? = null,
    val atk: Int? = null,
    val def: Int? = null,
    val monsterCategory: MonsterCategory? = null,
    val fusionMaterials: List<FusionMaterial>? = null,

    // Spell / Trap fields
    val spellType: SpellType? = null,
    val trapType: TrapType? = null,

    /** Filename (without extension) to look for under assets/cards/. Defaults to [id]. */
    val imageId: String = id,

    /** True if this card lives in the Extra Deck (Fusion monsters). */
    val isExtraDeck: Boolean = false,

    /** Ids referenced in EffectRegistry for this card. Empty = vanilla card, no effect. */
    val effectIds: List<String> = emptyList()
) {
    val isMonster get() = cardType == CardType.MONSTER
    val isSpell get() = cardType == CardType.SPELL
    val isTrap get() = cardType == CardType.TRAP

    /** Tributes required for a Normal Summon based on Level. Levels 1-4: 0, 5-6: 1, 7+: 2. */
    val tributesRequired: Int
        get() = when {
            level == null -> 0
            level <= 4 -> 0
            level <= 6 -> 1
            else -> 2
        }
}
