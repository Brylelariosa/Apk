package com.hzcm.duelforge.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.hzcm.duelforge.data.EffectRegistry
import com.hzcm.duelforge.engine.*
import com.hzcm.duelforge.model.*

private val DbgBg      = Color(0xFF0A1520)
private val DbgPanel   = Color(0xFF1A2535)
private val DbgAccent  = Color(0xFF2A9D8F)
private val DbgWarn    = Color(0xFFE76F51)
private val DbgLog     = Color(0xFF0D1A28)
private val DbgChain   = Color(0xFF264653)
private val DbgTab     = Color(0xFF1E3448)

@Composable
fun DebugDuelScreen(
    onExit: () -> Unit,
    vm: DebugViewModel = viewModel()
) {
    @Suppress("UNUSED_EXPRESSION") vm.refresh
    val state = vm.engine.state

    Box(modifier = Modifier.fillMaxSize().background(DbgBg)) {
        Row(modifier = Modifier.fillMaxSize().padding(4.dp)) {

            // ── LEFT: Both fields + log ─────────────────────────────────────────────
            Column(
                modifier = Modifier.weight(1.7f).fillMaxHeight(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Header
                DebugHeader(vm, onExit, modifier = Modifier.fillMaxWidth())

                Spacer(modifier = Modifier.height(4.dp))

                // AI field
                DebugFieldPanel(state, PlayerId.AI, vm, modifier = Modifier.fillMaxWidth())

                Spacer(modifier = Modifier.height(2.dp))

                // Game state bar (phase, turn, LP controls)
                DebugStateBar(vm, modifier = Modifier.fillMaxWidth())

                Spacer(modifier = Modifier.height(2.dp))

                // Player field
                DebugFieldPanel(state, PlayerId.PLAYER, vm, modifier = Modifier.fillMaxWidth())

                Spacer(modifier = Modifier.height(4.dp))

                // Log
                DebugLog(state, modifier = Modifier.weight(1f).fillMaxWidth())
            }

            Spacer(modifier = Modifier.width(4.dp))

            // ── RIGHT: Chain stack + tabs ───────────────────────────────────────────
            Column(modifier = Modifier.weight(1f).fillMaxHeight()) {
                ChainStackPanel(vm, modifier = Modifier.fillMaxWidth())
                Spacer(modifier = Modifier.height(4.dp))
                DebugTabPanel(vm, modifier = Modifier.weight(1f).fillMaxWidth())
            }
        }

        // Priority dialog (can appear if openPriorityWindow was called in Chain Lab)
        state.pendingHumanPriority?.let { prompt ->
            DebugPriorityDialog(prompt, vm)
        }

        // Game over notice (just informational in debug; no restart flow)
        if (state.gameOver) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(8.dp)
                    .background(DbgWarn, RoundedCornerShape(4.dp))
                    .padding(horizontal = 12.dp, vertical = 4.dp)
            ) {
                Text("GAME OVER — ${state.winner?.name ?: "?"} wins  (Reset to continue)",
                    color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

// ──────────────────────────────────────────────────────────────────────────────
// Header
// ──────────────────────────────────────────────────────────────────────────────

@Composable
private fun DebugHeader(vm: DebugViewModel, onExit: () -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier.background(DbgPanel).padding(horizontal = 6.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("🔧 Debug Duel", color = DbgAccent, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        Spacer(modifier = Modifier.weight(1f))
        SmallBtn("Reset", onClick = { vm.resetBoard() })
        Spacer(modifier = Modifier.width(4.dp))
        SmallBtn("← Exit", color = DbgWarn, onClick = onExit)
    }
}

// ──────────────────────────────────────────────────────────────────────────────
// Field panel (one player's side)
// ──────────────────────────────────────────────────────────────────────────────

@Composable
private fun DebugFieldPanel(
    state: GameState,
    player: PlayerId,
    vm: DebugViewModel,
    modifier: Modifier = Modifier
) {
    val field = state.field(player)
    val label = if (player == PlayerId.AI) "AI" else "Player"

    Column(modifier = modifier.background(DbgPanel).padding(4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("$label  LP:${field.lifePoints}", color = Color.White,
                fontWeight = FontWeight.Bold, fontSize = 10.sp)
            Text("Hand:${field.hand.size}  Deck:${field.deck.size}  GY:${field.graveyard.size}  Banished:${field.banished.size}",
                color = Color(0xFF888888), fontSize = 8.sp)
        }
        Spacer(modifier = Modifier.height(2.dp))

        // Monster zones + field zone row
        Row(verticalAlignment = Alignment.CenterVertically) {
            MiniZoneCard(field.fieldZone, label = "FZ", vm)
            Spacer(modifier = Modifier.width(3.dp))
            for (i in 0..4) {
                MiniZoneCard(field.monsterZones[i], label = "M$i", vm)
                if (i < 4) Spacer(modifier = Modifier.width(2.dp))
            }
        }
        Spacer(modifier = Modifier.height(2.dp))

        // Spell/Trap zones row
        Row(verticalAlignment = Alignment.CenterVertically) {
            Spacer(modifier = Modifier.width(42.dp)) // offset to align with M zones
            for (i in 0..4) {
                MiniZoneCard(field.spellTrapZones[i], label = "S$i", vm)
                if (i < 4) Spacer(modifier = Modifier.width(2.dp))
            }
        }
        Spacer(modifier = Modifier.height(2.dp))

        // Hand preview
        if (field.hand.isNotEmpty()) {
            LazyRow {
                items(field.hand) { card ->
                    MiniHandCard(card)
                    Spacer(modifier = Modifier.width(2.dp))
                }
            }
        }
    }
}

@Composable
private fun MiniZoneCard(card: CardInstance?, label: String, vm: DebugViewModel) {
    val atk = card?.let { vm.engine.computeAtk(it) }
    val boxColor = when {
        card == null -> Color(0xFF1A2535)
        card.card.isMonster -> Color(0xFF1A3520)
        card.card.isSpell   -> Color(0xFF1A2540)
        else                -> Color(0xFF352020)
    }
    Box(
        modifier = Modifier
            .size(width = 40.dp, height = 44.dp)
            .background(boxColor, RoundedCornerShape(3.dp))
            .border(0.5.dp, if (card != null) DbgAccent.copy(alpha = 0.5f) else Color(0xFF2A3545), RoundedCornerShape(3.dp)),
        contentAlignment = Alignment.Center
    ) {
        if (card == null) {
            Text(label, color = Color(0xFF3A4555), fontSize = 7.sp)
        } else {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    card.card.name.take(8) + if (card.card.name.length > 8) "…" else "",
                    color = Color.White, fontSize = 6.sp, lineHeight = 7.sp,
                    maxLines = 2, overflow = TextOverflow.Ellipsis
                )
                if (!card.faceUp) {
                    Text("↓", color = Color(0xFFAAAAAA), fontSize = 8.sp)
                } else if (atk != null) {
                    Text("${atk}", color = Color(0xFFFFDD88), fontSize = 7.sp, fontWeight = FontWeight.Bold)
                }
                if (card.battlePosition == BattlePosition.DEFENSE && card.card.isMonster) {
                    Text("DEF", color = Color(0xFF88CCFF), fontSize = 6.sp)
                }
            }
        }
    }
}

@Composable
private fun MiniHandCard(card: CardInstance) {
    val color = when {
        card.card.isMonster -> Color(0xFF1F4030)
        card.card.isSpell   -> Color(0xFF1F3050)
        else                -> Color(0xFF403020)
    }
    Box(
        modifier = Modifier
            .size(width = 36.dp, height = 22.dp)
            .background(color, RoundedCornerShape(2.dp))
            .border(0.5.dp, Color(0xFF445566), RoundedCornerShape(2.dp)),
        contentAlignment = Alignment.Center
    ) {
        Text(card.card.name.take(7), color = Color.White, fontSize = 5.5.sp, maxLines = 1)
    }
}

// ──────────────────────────────────────────────────────────────────────────────
// Game state bar (phase, turn player, LP adjustments)
// ──────────────────────────────────────────────────────────────────────────────

@Composable
private fun DebugStateBar(vm: DebugViewModel, modifier: Modifier = Modifier) {
    val state = vm.engine.state
    Column(modifier = modifier.background(DbgPanel).padding(4.dp)) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Turn ${state.turnCount}  •  ${if (state.turnPlayer == PlayerId.PLAYER) "Player's turn" else "AI's turn"}  •  ${state.phase.name}",
                color = DbgAccent, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            Row {
                SmallBtn("P Turn", onClick = { vm.setTurnPlayer(PlayerId.PLAYER) })
                Spacer(Modifier.width(2.dp))
                SmallBtn("AI Turn", onClick = { vm.setTurnPlayer(PlayerId.AI) })
            }
        }
        Spacer(Modifier.height(3.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Phase:", color = Color.LightGray, fontSize = 8.sp)
            Spacer(Modifier.width(4.dp))
            for (phase in listOf(Phase.DRAW, Phase.MAIN1, Phase.BATTLE, Phase.MAIN2, Phase.END)) {
                val active = state.phase == phase
                Box(
                    modifier = Modifier
                        .background(
                            if (active) DbgAccent else Color(0xFF1E3448),
                            RoundedCornerShape(3.dp)
                        )
                        .clickable { vm.setPhase(phase) }
                        .padding(horizontal = 5.dp, vertical = 2.dp)
                ) {
                    Text(phase.name.take(5), color = if (active) Color.Black else Color.LightGray, fontSize = 8.sp)
                }
                Spacer(Modifier.width(2.dp))
            }
        }
        Spacer(Modifier.height(3.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("LP:", color = Color.LightGray, fontSize = 8.sp)
            Spacer(Modifier.width(4.dp))
            for (p in PlayerId.entries) {
                val name = if (p == PlayerId.PLAYER) "P" else "AI"
                Text("$name:", color = Color.Gray, fontSize = 8.sp)
                Spacer(Modifier.width(2.dp))
                SmallBtn("-1k",  onClick = { vm.adjustLP(p, -1000) })
                SmallBtn("+1k",  onClick = { vm.adjustLP(p, +1000) })
                SmallBtn("8k",   onClick = { vm.setLP(p, 8000) })
                Spacer(Modifier.width(8.dp))
            }
        }
    }
}

// ──────────────────────────────────────────────────────────────────────────────
// Chain stack panel (always visible on right column)
// ──────────────────────────────────────────────────────────────────────────────

@Composable
private fun ChainStackPanel(vm: DebugViewModel, modifier: Modifier = Modifier) {
    val chain = vm.engine.state.chain
    Column(
        modifier = modifier
            .background(DbgChain)
            .padding(6.dp)
            .heightIn(max = 130.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("⛓ CHAIN  (${chain.size} link${if (chain.size != 1) "s" else ""}  — resolves LIFO)",
                color = DbgAccent, fontWeight = FontWeight.Bold, fontSize = 10.sp)
            if (chain.isNotEmpty()) {
                Row {
                    SmallBtn("Resolve", onClick = { vm.resolveChain() })
                    Spacer(Modifier.width(3.dp))
                    SmallBtn("Clear", color = DbgWarn, onClick = { vm.clearChain() })
                }
            }
        }
        if (chain.isEmpty()) {
            Text("(empty — use Chain Lab to push effects)", color = Color(0xFF556677), fontSize = 9.sp)
        } else {
            chain.reversed().forEachIndexed { i, link ->
                val linkNum = chain.size - i
                val resolveOrder = i + 1
                Text(
                    "#$linkNum [resolves $resolveOrder${resolveOrderSuffix(resolveOrder)}] " +
                    "${link.source.card.name} — ${link.effect.description.take(40)}",
                    color = if (i == 0) Color.White else Color(0xFFAAAAAA),
                    fontSize = 8.sp, lineHeight = 10.sp
                )
            }
        }
    }
}

private fun resolveOrderSuffix(n: Int) = when (n) { 1 -> "st"; 2 -> "nd"; 3 -> "rd"; else -> "th" }

// ──────────────────────────────────────────────────────────────────────────────
// Tab panel
// ──────────────────────────────────────────────────────────────────────────────

@Composable
private fun DebugTabPanel(vm: DebugViewModel, modifier: Modifier = Modifier) {
    val tabs = listOf("⚙ Setup", "⛓ Chain Lab", "🎯 Scenarios")
    Column(modifier = modifier.background(DbgTab)) {
        TabRow(
            selectedTabIndex = vm.activeTab,
            containerColor = DbgPanel,
            contentColor = DbgAccent
        ) {
            tabs.forEachIndexed { i, label ->
                Tab(
                    selected = vm.activeTab == i,
                    onClick = { vm.activeTab = i },
                    text = { Text(label, fontSize = 9.sp, maxLines = 1) }
                )
            }
        }
        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            when (vm.activeTab) {
                0 -> SetupTab(vm)
                1 -> ChainLabTab(vm)
                2 -> ScenariosTab(vm)
            }
        }
    }
}

// ──────────────────────────────────────────────────────────────────────────────
// Tab 0: Board Setup
// ──────────────────────────────────────────────────────────────────────────────

@Composable
private fun SetupTab(vm: DebugViewModel) {
    val allCards = remember(vm.engine.cardDb) { vm.engine.cardDb.allCards() }
    val filtered = if (vm.cardFilter.isBlank()) allCards
                   else allCards.filter { it.name.contains(vm.cardFilter, ignoreCase = true) ||
                                          it.id.contains(vm.cardFilter, ignoreCase = true) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(6.dp)
    ) {
        // Player selector
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Add to:", color = Color.LightGray, fontSize = 9.sp)
            Spacer(Modifier.width(6.dp))
            for (p in PlayerId.entries) {
                val name = if (p == PlayerId.PLAYER) "Player" else "AI"
                val sel = vm.setupPlayer == p
                Box(
                    modifier = Modifier
                        .background(if (sel) DbgAccent else DbgPanel, RoundedCornerShape(3.dp))
                        .clickable { vm.setupPlayer = p }
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(name, color = if (sel) Color.Black else Color.LightGray, fontSize = 9.sp)
                }
                Spacer(Modifier.width(3.dp))
            }
        }
        Spacer(Modifier.height(4.dp))

        // Zone selector
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Zone:", color = Color.LightGray, fontSize = 9.sp)
            Spacer(Modifier.width(4.dp))
        }
        LazyRow(modifier = Modifier.fillMaxWidth()) {
            items(DebugZone.entries.toList()) { zone ->
                val sel = vm.setupZone == zone
                Box(
                    modifier = Modifier
                        .background(if (sel) DbgAccent else DbgPanel, RoundedCornerShape(3.dp))
                        .clickable { vm.setupZone = zone }
                        .padding(horizontal = 6.dp, vertical = 3.dp)
                ) {
                    Text(zone.label, color = if (sel) Color.Black else Color.LightGray, fontSize = 8.sp)
                }
                Spacer(Modifier.width(3.dp))
            }
        }
        Spacer(Modifier.height(4.dp))

        // Extra options for monster zone
        if (vm.setupZone == DebugZone.MONSTER_ZONE) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Face:", color = Color.LightGray, fontSize = 9.sp)
                Spacer(Modifier.width(4.dp))
                for ((label, faceUp) in listOf("Up" to true, "Down" to false)) {
                    val sel = vm.setupFaceUp == faceUp
                    Box(
                        modifier = Modifier
                            .background(if (sel) DbgAccent else DbgPanel, RoundedCornerShape(3.dp))
                            .clickable { vm.setupFaceUp = faceUp }
                            .padding(horizontal = 6.dp, vertical = 3.dp)
                    ) { Text(label, color = if (sel) Color.Black else Color.LightGray, fontSize = 8.sp) }
                    Spacer(Modifier.width(3.dp))
                }
                Spacer(Modifier.width(8.dp))
                Text("Pos:", color = Color.LightGray, fontSize = 9.sp)
                Spacer(Modifier.width(4.dp))
                for (pos in BattlePosition.entries) {
                    val sel = vm.setupPosition == pos
                    Box(
                        modifier = Modifier
                            .background(if (sel) DbgAccent else DbgPanel, RoundedCornerShape(3.dp))
                            .clickable { vm.setupPosition = pos }
                            .padding(horizontal = 6.dp, vertical = 3.dp)
                    ) { Text(pos.name.take(3), color = if (sel) Color.Black else Color.LightGray, fontSize = 8.sp) }
                    Spacer(Modifier.width(3.dp))
                }
            }
            Spacer(Modifier.height(4.dp))
        }

        // Card filter
        OutlinedTextField(
            value = vm.cardFilter,
            onValueChange = { vm.cardFilter = it },
            label = { Text("Filter cards…", fontSize = 9.sp) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().height(52.dp),
            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 10.sp, color = Color.White)
        )
        Spacer(Modifier.height(4.dp))

        Text("Tap to add to ${vm.setupPlayer.name}'s ${vm.setupZone.label}:",
            color = Color.Gray, fontSize = 8.sp)
        Spacer(Modifier.height(2.dp))

        // Card list
        LazyColumn(modifier = Modifier.weight(1f)) {
            items(filtered) { card ->
                val typeColor = when {
                    card.isMonster -> Color(0xFF2A5040)
                    card.isSpell   -> Color(0xFF2A3A55)
                    else           -> Color(0xFF503030)
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 1.dp)
                        .background(typeColor, RoundedCornerShape(3.dp))
                        .clickable {
                            vm.placeCard(card, vm.setupPlayer, vm.setupZone, vm.setupFaceUp, vm.setupPosition)
                        }
                        .padding(horizontal = 6.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val typeTag = when {
                        card.isMonster -> "${card.monsterCategory?.name?.take(3) ?: "MON"} Lv${card.level}"
                        card.isSpell   -> card.spellType?.name?.replace('_', '-') ?: "SPELL"
                        else           -> card.trapType?.name?.replace('_', '-') ?: "TRAP"
                    }
                    Text(card.name, color = Color.White, fontSize = 9.sp,
                        modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(typeTag, color = Color(0xFFAAAAAA), fontSize = 7.sp)
                    if (EffectRegistry.allEffectCardIds().contains(card.id)) {
                        Spacer(Modifier.width(4.dp))
                        Text("✦", color = DbgAccent, fontSize = 8.sp)
                    }
                }
            }
        }
    }
}

// ──────────────────────────────────────────────────────────────────────────────
// Tab 1: Chain Lab
// ──────────────────────────────────────────────────────────────────────────────

@Composable
private fun ChainLabTab(vm: DebugViewModel) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(6.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text("Force-push any effect onto the chain (bypasses timing / location checks).",
            color = Color.Gray, fontSize = 8.sp, lineHeight = 10.sp)
        Spacer(Modifier.height(6.dp))

        // Player selector for which side to show effects for
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Show cards for:", color = Color.LightGray, fontSize = 9.sp)
            Spacer(Modifier.width(6.dp))
            for (p in PlayerId.entries) {
                val name = if (p == PlayerId.PLAYER) "Player" else "AI"
                val sel = vm.chainLabPlayer == p
                Box(
                    modifier = Modifier
                        .background(if (sel) DbgAccent else DbgPanel, RoundedCornerShape(3.dp))
                        .clickable { vm.chainLabPlayer = p }
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) { Text(name, color = if (sel) Color.Black else Color.LightGray, fontSize = 9.sp) }
                Spacer(Modifier.width(3.dp))
            }
        }
        Spacer(Modifier.height(6.dp))

        val effects = vm.fieldCardsWithEffects(vm.chainLabPlayer)
        if (effects.isEmpty()) {
            Text("No cards with non-CONTINUOUS effects are currently in ${vm.chainLabPlayer.name}'s hand or on their field.",
                color = Color(0xFF556677), fontSize = 9.sp, lineHeight = 11.sp)
        } else {
            effects.forEach { (card, effect) ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 2.dp)
                        .background(DbgPanel, RoundedCornerShape(4.dp))
                        .padding(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(card.card.name, color = Color.White, fontSize = 9.sp,
                            fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("[${effect.timing.name}] ${effect.description}",
                            color = Color(0xFF99AABB), fontSize = 7.5.sp, lineHeight = 9.sp, maxLines = 2)
                        Text("Location: ${card.location.name}  FaceUp: ${card.faceUp}",
                            color = Color(0xFF556677), fontSize = 7.sp)
                    }
                    Spacer(Modifier.width(6.dp))
                    SmallBtn("Push →", onClick = { vm.forcePushEffect(card, effect) })
                }
            }
        }

        Spacer(Modifier.height(8.dp))
        Divider(color = Color(0xFF2A3A4A))
        Spacer(Modifier.height(6.dp))

        // Event injection
        Text("Inject a game event (helps TRIGGER/QUICK canActivate checks):",
            color = Color.Gray, fontSize = 8.sp)
        Spacer(Modifier.height(4.dp))

        val playerMonsters = vm.engine.state.field(PlayerId.PLAYER).monsters()
        val aiMonsters     = vm.engine.state.field(PlayerId.AI).monsters()

        if (playerMonsters.isNotEmpty()) {
            SmallBtnFull("Event: Player Normal-Summons ${playerMonsters.first().card.name}") {
                vm.setLastEvent(GameEvent.NormalSummon(playerMonsters.first()))
            }
        }
        if (aiMonsters.isNotEmpty() && playerMonsters.isNotEmpty()) {
            Spacer(Modifier.height(3.dp))
            SmallBtnFull("Event: AI attacks Player's ${playerMonsters.first().card.name}") {
                vm.setLastEvent(GameEvent.AttackDeclared(aiMonsters.first(), playerMonsters.first()))
            }
        }
        Spacer(Modifier.height(3.dp))
        SmallBtnFull("Event: Reset to None") { vm.setLastEvent(GameEvent.None) }

        Spacer(Modifier.height(8.dp))
        Divider(color = Color(0xFF2A3A4A))
        Spacer(Modifier.height(6.dp))

        // Priority window
        Text("Open priority window (checks all legal responses):", color = Color.Gray, fontSize = 8.sp)
        Spacer(Modifier.height(4.dp))
        Row {
            SmallBtn("Player responds", onClick = { vm.openPriorityWindow(PlayerId.AI) })
            Spacer(Modifier.width(4.dp))
            SmallBtn("AI responds", onClick = { vm.openPriorityWindow(PlayerId.PLAYER) })
        }
    }
}

// ──────────────────────────────────────────────────────────────────────────────
// Tab 2: Scenarios
// ──────────────────────────────────────────────────────────────────────────────

@Composable
private fun ScenariosTab(vm: DebugViewModel) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(6.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text("One-tap test scenarios — each resets the board then places cards to test a specific interaction.",
            color = Color.Gray, fontSize = 8.sp, lineHeight = 11.sp)
        Spacer(Modifier.height(8.dp))

        DebugScenario.entries.forEach { scenario ->
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 3.dp)
                    .background(DbgPanel, RoundedCornerShape(4.dp))
                    .padding(8.dp)
            ) {
                Text(scenario.label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                Text(scenario.description, color = Color(0xFF99AABB), fontSize = 8.sp)
                Spacer(Modifier.height(5.dp))
                SmallBtn("▶ Run", onClick = { vm.runScenario(scenario) })
            }
            Spacer(Modifier.height(3.dp))
        }

        Spacer(Modifier.height(8.dp))
        Divider(color = Color(0xFF2A3A4A))
        Spacer(Modifier.height(6.dp))

        Text("Continuous stat test", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 10.sp)
        Text("Place Battlefield Overgrowth (field zone) + any EARTH monster to see computeAtk() apply the +200 buff automatically via the EffectRegistry atkBonus lambda.",
            color = Color(0xFF99AABB), fontSize = 8.sp, lineHeight = 10.sp)
        Spacer(Modifier.height(4.dp))
        val bfog = remember(vm.engine.cardDb) { vm.engine.cardDb.allCards().firstOrNull { it.id == "battlefield_overgrowth" } }
        val tiger = remember(vm.engine.cardDb) { vm.engine.cardDb.allCards().firstOrNull { it.id == "wildclaw_tiger" } }
        if (bfog != null && tiger != null) {
            Text("Wildclaw Tiger base ATK: 1700  |  With Overgrowth: ${
                run {
                    // Live compute preview using a dummy inst
                    val f = vm.engine.state.field(PlayerId.PLAYER)
                    val ovField = f.allFieldCards().any { it.card.id == "battlefield_overgrowth" && it.faceUp }
                    if (ovField) "1900 ✓" else "1700 (add Overgrowth to field to test)"
                }
            }", color = DbgAccent, fontSize = 9.sp)
        }
    }
}

// ──────────────────────────────────────────────────────────────────────────────
// Log
// ──────────────────────────────────────────────────────────────────────────────

@Composable
private fun DebugLog(state: GameState, modifier: Modifier = Modifier) {
    val listState = rememberLazyListState()
    LaunchedEffect(state.log.size) {
        if (state.log.isNotEmpty()) listState.animateScrollToItem(state.log.size - 1)
    }
    LazyColumn(
        state = listState,
        modifier = modifier.background(DbgLog).padding(4.dp)
    ) {
        items(state.log) { line ->
            val color = when {
                line.startsWith("DEBUG ✗") -> DbgWarn
                line.startsWith("DEBUG ▶") -> DbgAccent
                line.startsWith("===")     -> Color(0xFFFFFFAA)
                else                       -> Color(0xFFCCCCCC)
            }
            Text(line, color = color, fontSize = 8.sp, lineHeight = 10.sp)
        }
    }
}

// ──────────────────────────────────────────────────────────────────────────────
// Priority dialog (re-used from Chain Lab's openPriorityWindow calls)
// ──────────────────────────────────────────────────────────────────────────────

@Composable
private fun DebugPriorityDialog(prompt: PriorityPrompt, vm: DebugViewModel) {
    AlertDialog(
        onDismissRequest = { },
        title = { Text("🔧 Debug: Respond?", fontSize = 13.sp) },
        text = {
            Column {
                Text(prompt.reason, fontSize = 10.sp, color = Color.LightGray)
                Spacer(Modifier.height(6.dp))
                prompt.optionLabels.forEachIndexed { i, label ->
                    Button(
                        onClick = { vm.submitPriorityChoice(i) },
                        modifier = Modifier.padding(vertical = 2.dp).fillMaxWidth()
                    ) { Text(label, fontSize = 9.sp) }
                }
            }
        },
        confirmButton = {
            Button(onClick = { vm.submitPriorityChoice(null) }) { Text("Pass") }
        }
    )
}

// ──────────────────────────────────────────────────────────────────────────────
// Shared button helpers
// ──────────────────────────────────────────────────────────────────────────────

@Composable
private fun SmallBtn(
    label: String,
    color: Color = DbgAccent,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .background(color.copy(alpha = 0.85f), RoundedCornerShape(3.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 7.dp, vertical = 3.dp)
    ) {
        Text(label, color = Color.Black, fontSize = 8.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun SmallBtnFull(label: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(DbgPanel, RoundedCornerShape(3.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 5.dp)
    ) {
        Text(label, color = DbgAccent, fontSize = 8.5.sp)
    }
}
