package com.hzcm.duelforge.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hzcm.duelforge.model.*

/** Default card dimensions used throughout the field/hand. */
val CardWidth  = 44.dp
val CardHeight = 60.dp

/**
 * Renders one card zone.
 *  - [instance] null  → empty zone outline.
 *  - Face-down + not [revealFaceDown] → card back (loaded from assets/card_back.webp).
 *  - Defense Position monsters → rotated 90° like real YGO, face-up or face-down.
 *  - Otherwise → artwork from assets/cards/<imageId>.{png,jpg,jpeg,webp} or a generated
 *    placeholder colored by card type.
 *
 * [revealFaceDown] lets the human see their own set/face-down-defense cards.
 */
@Composable
fun CardView(
    instance: CardInstance?,
    modifier: Modifier = Modifier,
    revealFaceDown: Boolean = false,
    selected: Boolean = false,
    onClick: (() -> Unit)? = null
) {
    val isDefense = instance != null &&
        instance.card.isMonster &&
        instance.battlePosition == BattlePosition.DEFENSE

    // Defense cards occupy a wider footprint (rotated) — keep layout tidy by using a
    // fixed outer box that stays the same as a normal card slot but draws the content rotated.
    val outerMod = modifier
        .size(CardWidth, CardHeight)
        .let { m -> if (onClick != null) m.clickable { onClick() } else m }

    if (instance == null) {
        Box(modifier = outerMod.background(Color(0xFF1A1A1A), RoundedCornerShape(6.dp))
            .border(1.dp, Color(0xFF333333), RoundedCornerShape(6.dp))) {}
        return
    }

    val showFace = instance.faceUp || revealFaceDown

    // Rotation for Defense Position — applies to both face-up and face-down
    val rotation = if (isDefense) 90f else 0f

    Box(modifier = outerMod, contentAlignment = Alignment.Center) {
        Box(
            modifier = Modifier
                .size(CardWidth, CardHeight)
                .graphicsLayer { rotationZ = rotation }
                .clip(RoundedCornerShape(6.dp))
                .border(
                    width = if (selected) 3.dp else 1.dp,
                    color = when {
                        selected -> Color(0xFFFFD54F)
                        isDefense && showFace -> Color(0xFF5599FF)  // blue tint for defense
                        else -> Color(0xFF555555)
                    },
                    shape = RoundedCornerShape(6.dp)
                )
        ) {
            if (!showFace) {
                CardBack()
            } else {
                val context = LocalContext.current
                val bitmap = remember(instance.card.imageId) {
                    ImageLoader.loadCardImage(context, instance.card.imageId)
                }
                Box(modifier = Modifier.fillMaxSize().background(cardTypeColor(instance.card))) {
                    if (bitmap != null) {
                        Image(
                            bitmap = bitmap.asImageBitmap(),
                            contentDescription = instance.card.name,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                        if (instance.card.isMonster) StatOverlay(instance)
                    } else {
                        PlaceholderCardContent(instance)
                    }
                    // Dim player's own face-down card (face revealed via revealFaceDown)
                    if (!instance.faceUp) {
                        Box(modifier = Modifier.fillMaxSize().background(Color(0x55000000)))
                    }
                }
            }
        }

        // Defense label — small badge below the rotated card
        if (isDefense && showFace) {
            Text(
                "DEF",
                color = Color(0xFF88BBFF),
                fontSize = 5.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.BottomCenter).offset(y = 2.dp)
            )
        }
    }
}

// ------------------------------------------------------------------
// Card back — uses the real card back art from assets/card_back.webp
// ------------------------------------------------------------------

@Composable
fun CardBack(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val backBitmap = remember { ImageLoader.loadCardBack(context) }

    Box(
        modifier = modifier.fillMaxSize().background(Color(0xFF2B2D6E)),
        contentAlignment = Alignment.Center
    ) {
        if (backBitmap != null) {
            Image(
                bitmap = backBitmap.asImageBitmap(),
                contentDescription = "Card back",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        } else {
            // Fallback if asset is missing
            Box(
                modifier = Modifier
                    .size(CardWidth - 16.dp, CardHeight - 16.dp)
                    .border(1.dp, Color(0xFF6E72C7), RoundedCornerShape(4.dp))
            )
        }
    }
}

// ------------------------------------------------------------------
// Placeholder (no artwork file)
// ------------------------------------------------------------------

@Composable
private fun PlaceholderCardContent(instance: CardInstance) {
    val card = instance.card
    Column(
        modifier = Modifier.fillMaxSize().padding(3.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = card.name,
            color = Color.Black,
            fontSize = 8.sp,
            fontWeight = FontWeight.Bold,
            lineHeight = 9.sp,
            maxLines = 3,
            overflow = TextOverflow.Ellipsis
        )
        if (card.isMonster) {
            Column {
                Text(
                    text = "${card.attribute?.name ?: ""} ${card.race?.name?.replace('_', ' ') ?: ""}".trim(),
                    color = Color(0xFF222222), fontSize = 6.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "Lv${card.level ?: 0}  ${card.atk ?: 0}/${card.def ?: 0}",
                    color = Color.Black, fontSize = 6.5.sp,
                    fontWeight = FontWeight.Bold, maxLines = 1
                )
            }
        } else {
            Text(
                text = if (card.isSpell) "SPELL" else "TRAP",
                color = Color.Black, fontSize = 6.5.sp, fontWeight = FontWeight.Bold
            )
        }
    }
}

// ------------------------------------------------------------------
// ATK/DEF stat overlay drawn over real artwork
// ------------------------------------------------------------------

@Composable
private fun StatOverlay(instance: CardInstance) {
    Box(modifier = Modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(Color(0xAA000000))
        ) {
            val posLabel = if (instance.battlePosition == BattlePosition.ATTACK) "ATK" else "DEF"
            Text(
                text = "${instance.effectiveAtk}/${instance.effectiveDef} $posLabel",
                color = Color.White, fontSize = 7.sp, fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(vertical = 1.dp)
            )
        }
    }
}

private fun cardTypeColor(card: Card): Color = when (card.cardType) {
    CardType.MONSTER -> when (card.monsterCategory) {
        MonsterCategory.NORMAL -> Color(0xFFE8C77A)
        MonsterCategory.EFFECT -> Color(0xFFE8915A)
        MonsterCategory.FUSION -> Color(0xFFC79BE8)
        null                   -> Color(0xFFE8C77A)
    }
    CardType.SPELL -> Color(0xFF7FBF7F)
    CardType.TRAP  -> Color(0xFFE07FA8)
}
