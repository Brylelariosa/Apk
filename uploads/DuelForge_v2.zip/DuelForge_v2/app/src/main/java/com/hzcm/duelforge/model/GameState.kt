package com.hzcm.duelforge.model

/** Everything that belongs to one player's side of the field. */
class PlayerField {
    val hand: MutableList<CardInstance> = mutableListOf()
    val deck: MutableList<CardInstance> = mutableListOf()
    val graveyard: MutableList<CardInstance> = mutableListOf()
    val banished: MutableList<CardInstance> = mutableListOf()
    val extraDeck: MutableList<CardInstance> = mutableListOf()

    val monsterZones: Array<CardInstance?> = arrayOfNulls(5)
    val spellTrapZones: Array<CardInstance?> = arrayOfNulls(5)
    var fieldZone: CardInstance? = null

    var lifePoints: Int = 8000
    var normalSummonsUsed: Int = 0
    var normalSummonsAllowed: Int = 1

    fun monsters(): List<CardInstance> = monsterZones.filterNotNull()
    fun spellsAndTraps(): List<CardInstance> = spellTrapZones.filterNotNull()
    fun allFieldCards(): List<CardInstance> =
        monsters() + spellsAndTraps() + listOfNotNull(fieldZone)

    fun firstEmptyMonsterZone(): Int? = monsterZones.indices.firstOrNull { monsterZones[it] == null }
    fun firstEmptySpellTrapZone(): Int? = spellTrapZones.indices.firstOrNull { spellTrapZones[it] == null }
}

/** One link in the chain - a single effect activation waiting to resolve, LIFO order. */
data class ChainLink(
    val source: CardInstance,
    val effect: CardEffect,
    val controller: PlayerId,
    val targets: List<CardInstance> = emptyList()
)

/**
 * A description of "what just happened" used by Trigger / Quick effects to decide whether
 * they can respond. The engine updates [GameState.lastEvent] before opening a priority window.
 */
sealed class GameEvent {
    object None : GameEvent()
    data class NormalSummon(val card: CardInstance) : GameEvent()
    data class SpecialSummon(val card: CardInstance) : GameEvent()
    data class FlipSummon(val card: CardInstance) : GameEvent()
    data class SpellActivated(val card: CardInstance) : GameEvent()
    data class TrapActivated(val card: CardInstance) : GameEvent()
    data class MonsterEffectActivated(val card: CardInstance) : GameEvent()
    data class AttackDeclared(val attacker: CardInstance, val target: CardInstance?) : GameEvent()
    data class Destroyed(val card: CardInstance) : GameEvent()
    data class PhaseChanged(val phase: Phase) : GameEvent()
}

/**
 * Sent to the UI when an effect needs the human player to pick card(s) to discard.
 * Stored in [GameState.pendingDiscard]; cleared after [GameViewModel.confirmDiscard].
 */
data class DiscardRequest(
    val player: PlayerId,
    val count: Int,
    val reason: String
)

/** Top-level mutable state for an entire duel. */
class GameState {
    val fields: Map<PlayerId, PlayerField> = mapOf(
        PlayerId.PLAYER to PlayerField(),
        PlayerId.AI to PlayerField()
    )

    var turnPlayer: PlayerId = PlayerId.PLAYER
    var turnCount: Int = 1
    var phase: Phase = Phase.DRAW

    /** The active chain stack. Index 0 = first link activated (resolves last). */
    val chain: MutableList<ChainLink> = mutableListOf()

    var lastEvent: GameEvent = GameEvent.None

    val log: MutableList<String> = mutableListOf()
    var winner: PlayerId? = null
    var gameOver: Boolean = false

    /** When non-null the UI must show a priority prompt for the human player. */
    var pendingHumanPriority: PriorityPrompt? = null

    /**
     * When non-null, an effect is waiting for the human player to choose [DiscardRequest.count]
     * card(s) to discard. The UI shows a hand-picker; [GameViewModel.confirmDiscard] resumes
     * chain resolution after the player commits.
     */
    var pendingDiscard: DiscardRequest? = null

    fun field(p: PlayerId): PlayerField = fields.getValue(p)

    fun addLog(message: String) {
        log.add(message)
        if (log.size > 200) log.removeAt(0)
    }
}

/**
 * Data the UI needs to ask the human player "you may respond with X, Y, or pass".
 * [optionEffects] are aligned with [optionLabels] by index.
 */
data class PriorityPrompt(
    val optionLabels: List<String>,
    val optionSources: List<CardInstance>,
    val optionEffects: List<CardEffect>,
    val reason: String
)
