package com.hzcm.duelforge.engine

import android.content.Context
import com.hzcm.duelforge.data.CardDatabase
import com.hzcm.duelforge.data.EffectRegistry
import com.hzcm.duelforge.model.*
import com.hzcm.duelforge.model.EffectTiming

/**
 * Central orchestrator for one duel. Gameplay logic is split across this file and
 * SummonManager / BattleManager / ChainManager / AIController as extension functions
 * on [GameEngine], all operating on the shared [state].
 *
 * Long sequences (an AI turn, a chain resolving, a battle) are written in
 * continuation-passing style: every step takes an `onDone: () -> Unit` that is invoked
 * once that step (including any chain/priority resolution it triggers) is fully settled.
 * This lets a human-priority prompt pause an in-progress AI turn cleanly - the UI calls
 * [submitPriorityChoice] later, which resumes exactly where things left off.
 */
class GameEngine(context: Context) {
    val state = GameState()
    val cardDb = CardDatabase.getInstance(context)

    private var instanceCounter = 0
    private fun nextInstanceId(): String = "ci_${instanceCounter++}"

    /** Set by ChainManager when a human priority prompt is shown; resumed by submitPriorityChoice(). */
    var pendingResume: (() -> Unit)? = null

    /** Callback stored when an effect needs a human-chosen discard; called from GameViewModel.confirmDiscard(). */
    var pendingDiscardResume: ((List<CardInstance>) -> Unit)? = null

    /** Transient flag so a card's own "if destroyed by battle" Trigger effects can tell how they died. */
    var lastDestructionWasBattle: Boolean = false

    fun displayName(p: PlayerId): String = if (p == PlayerId.PLAYER) "You" else "Opponent"

    // ------------------------------------------------------------------
    // Setup
    // ------------------------------------------------------------------

    fun startGame() {
        for (player in PlayerId.entries) {
            val field = state.field(player)
            field.deck.clear()
            field.deck.addAll(cardDb.buildMainDeck(player).map { card ->
                CardInstance(nextInstanceId(), card, player, player).also { it.location = Location.DECK }
            })
            field.deck.shuffle()

            field.extraDeck.clear()
            field.extraDeck.addAll(cardDb.buildExtraDeck(player).map { card ->
                CardInstance(nextInstanceId(), card, player, player).also { it.location = Location.EXTRA_DECK }
            })

            field.lifePoints = 8000
            field.normalSummonsUsed = 0
            field.normalSummonsAllowed = 1
        }

        state.turnPlayer = PlayerId.PLAYER
        state.turnCount = 1
        state.phase = Phase.DRAW
        state.gameOver = false
        state.winner = null
        state.chain.clear()
        state.log.clear()

        drawCards(PlayerId.PLAYER, 5)
        drawCards(PlayerId.AI, 5)

        state.addLog("=== Duel Start! You go first (no draw this turn). ===")
        advancePhase()
    }

    // ------------------------------------------------------------------
    // Zone management
    // ------------------------------------------------------------------

    fun drawCards(player: PlayerId, count: Int) {
        val field = state.field(player)
        repeat(count) {
            if (state.gameOver) return@repeat
            if (field.deck.isEmpty()) {
                state.winner = player.opponent()
                state.gameOver = true
                state.addLog("${displayName(player)} has no cards left to draw! ${displayName(player.opponent())} wins!")
                return@repeat
            }
            val card = field.deck.removeAt(0)
            card.location = Location.HAND
            card.faceUp = true
            field.hand.add(card)
        }
    }

    /** Removes [card] from whatever zone it currently occupies on its controller's field. */
    fun removeFromCurrentZone(card: CardInstance) {
        val field = state.field(card.controller)
        when (card.location) {
            Location.MONSTER_ZONE -> card.zoneIndex?.let { idx -> if (field.monsterZones[idx] === card) field.monsterZones[idx] = null }
            Location.SPELL_TRAP_ZONE -> card.zoneIndex?.let { idx -> if (field.spellTrapZones[idx] === card) field.spellTrapZones[idx] = null }
            Location.FIELD_ZONE -> if (field.fieldZone === card) field.fieldZone = null
            Location.HAND -> field.hand.remove(card)
            Location.GRAVEYARD -> field.graveyard.remove(card)
            Location.BANISHED -> field.banished.remove(card)
            Location.DECK -> field.deck.remove(card)
            Location.EXTRA_DECK -> field.extraDeck.remove(card)
        }
        card.zoneIndex = null
    }

    fun sendToGraveyard(card: CardInstance) {
        removeFromCurrentZone(card)
        card.location = Location.GRAVEYARD
        card.faceUp = true
        card.atkModifier = 0
        card.defModifier = 0
        state.field(card.controller).graveyard.add(card)
        // Cards return to their owner's GY, not the controller's (matters if control changed - not used in v1 but kept correct)
        if (card.controller != card.owner) {
            state.field(card.controller).graveyard.remove(card)
            state.field(card.owner).graveyard.add(card)
            card.controller = card.owner
        }
    }

    fun banishCard(card: CardInstance) {
        removeFromCurrentZone(card)
        card.location = Location.BANISHED
        card.faceUp = true
        state.field(card.controller).banished.add(card)
    }

    fun returnToExtraDeck(card: CardInstance) {
        removeFromCurrentZone(card)
        card.location = Location.EXTRA_DECK
        state.field(card.controller).extraDeck.add(card)
    }

    /**
     * Destroys a card already on the field, sending it to the Graveyard and firing the Destroyed event.
     * [byBattle] lets the destroyed card's own "destroyed by battle" Trigger effects (if any) know
     * how they died - v1 simplification: such Trigger effects auto-resolve immediately rather
     * than joining the chain, since the card has already left the field.
     */
    fun destroyCard(card: CardInstance, byBattle: Boolean = false, onDone: () -> Unit = {}) {
        if (card.location != Location.MONSTER_ZONE &&
            card.location != Location.SPELL_TRAP_ZONE &&
            card.location != Location.FIELD_ZONE
        ) { onDone(); return }

        state.addLog("${card.card.name} is destroyed.")
        sendToGraveyard(card)
        state.lastEvent = GameEvent.Destroyed(card)
        lastDestructionWasBattle = byBattle

        for (effect in EffectRegistry.effectsFor(card.card.id)) {
            if (effect.timing == EffectTiming.TRIGGER && effect.canActivate(this, card)) {
                state.addLog("${card.card.name}'s effect triggers: ${effect.description}")
                effect.resolve(this, card, emptyList())
            }
        }
        // Reset immediately - this flag is only meant for the just-destroyed card's own
        // "if this card is destroyed by battle" check above. Leaving it set could cause
        // a DIFFERENT surviving copy of the same card to spuriously trigger via the
        // auto-trigger loop in openPriorityWindow (called just below).
        lastDestructionWasBattle = false

        checkWinConditions()
        if (state.gameOver) { onDone(); return }
        openPriorityWindow(card.controller, onDone)
    }

    // ------------------------------------------------------------------
    // Turn / phase flow
    // ------------------------------------------------------------------

    private fun setPhase(phase: Phase) {
        state.phase = phase
        state.lastEvent = GameEvent.PhaseChanged(phase)
        state.addLog("— ${phaseLabel(phase)} —")
    }

    private fun phaseLabel(phase: Phase): String = when (phase) {
        Phase.DRAW -> "Draw Phase"
        Phase.STANDBY -> "Standby Phase"
        Phase.MAIN1 -> "Main Phase 1"
        Phase.BATTLE_START -> "Battle Phase"
        Phase.BATTLE -> "Battle Phase"
        Phase.MAIN2 -> "Main Phase 2"
        Phase.END -> "End Phase"
    }

    /**
     * Advances past the current phase. Called by the UI ("Next Phase" button) during the
     * human turn, and internally by [aiRunTurn] to step through the AI's own phases.
     *
     * Only the END->endTurn() transition can hand control to the AI, so that's the only
     * place [aiRunTurn] is triggered from here - this keeps aiRunTurn's own internal
     * advancePhase() calls (for the AI's MAIN1/BATTLE/MAIN2/etc.) from recursively
     * re-triggering aiRunTurn.
     */
    fun advancePhase() {
        if (state.gameOver) return
        if (state.chain.isNotEmpty() || state.pendingHumanPriority != null) return

        when (state.phase) {
            Phase.DRAW -> {
                if (!(state.turnCount == 1 && state.turnPlayer == PlayerId.PLAYER)) {
                    drawCards(state.turnPlayer, 1)
                }
                if (state.gameOver) return
                setPhase(Phase.STANDBY)
                setPhase(Phase.MAIN1)
            }
            Phase.STANDBY -> setPhase(Phase.MAIN1)
            Phase.MAIN1 -> {
                // Skip BATTLE_START so the player reaches the actual battle in one tap.
                // BATTLE_START events still fire via setPhase for any triggers that listen.
                setPhase(Phase.BATTLE_START)
                setPhase(Phase.BATTLE)
            }
            Phase.BATTLE_START -> setPhase(Phase.BATTLE)
            Phase.BATTLE -> setPhase(Phase.MAIN2)
            Phase.MAIN2 -> setPhase(Phase.END)
            Phase.END -> {
                endTurn()
                if (!state.gameOver && state.turnPlayer == PlayerId.AI) {
                    aiRunTurn()
                }
            }
        }
    }

    /** Cleans up end-of-turn state and switches the active player. */
    fun endTurn() {
        if (state.gameOver) return
        state.turnPlayer = state.turnPlayer.opponent()
        state.turnCount++
        state.phase = Phase.DRAW
        state.lastEvent = GameEvent.PhaseChanged(Phase.DRAW)
        for (card in state.field(state.turnPlayer).allFieldCards()) card.resetForNewTurn()
        state.field(state.turnPlayer).normalSummonsUsed = 0
        state.addLog("===== Turn ${state.turnCount}: ${displayName(state.turnPlayer)}'s turn =====")
    }

    // ------------------------------------------------------------------
    // Stat queries (incorporate continuous field-wide effects)
    // ------------------------------------------------------------------

    /**
     * Effective ATK for [card] including instance modifiers AND all CONTINUOUS field-wide
     * stat buffs. Buffs are declared entirely in EffectRegistry via [CardEffect.atkBonus] —
     * to add a new continuous ATK buff, supply an [atkBonus] lambda there; no changes here.
     */
    fun computeAtk(card: CardInstance): Int {
        var atk = card.effectiveAtk
        for (p in PlayerId.entries) {
            for (fieldCard in state.field(p).allFieldCards()) {
                if (!fieldCard.faceUp) continue
                for (effect in EffectRegistry.effectsFor(fieldCard.card.id)) {
                    if (effect.timing == EffectTiming.CONTINUOUS) {
                        atk += effect.atkBonus?.invoke(this, fieldCard, card) ?: 0
                    }
                }
            }
        }
        return atk.coerceAtLeast(0)
    }

    /**
     * Effective DEF for [card] including instance modifiers AND all CONTINUOUS field-wide
     * DEF buffs. Declare new buffs via [CardEffect.defBonus] in EffectRegistry.
     */
    fun computeDef(card: CardInstance): Int {
        var def = card.effectiveDef
        for (p in PlayerId.entries) {
            for (fieldCard in state.field(p).allFieldCards()) {
                if (!fieldCard.faceUp) continue
                for (effect in EffectRegistry.effectsFor(fieldCard.card.id)) {
                    if (effect.timing == EffectTiming.CONTINUOUS) {
                        def += effect.defBonus?.invoke(this, fieldCard, card) ?: 0
                    }
                }
            }
        }
        return def.coerceAtLeast(0)
    }

    // ------------------------------------------------------------------
    // Win conditions
    // ------------------------------------------------------------------

    fun checkWinConditions() {
        if (state.gameOver) return
        for (player in PlayerId.entries) {
            if (state.field(player).lifePoints <= 0) {
                state.gameOver = true
                state.winner = player.opponent()
                state.addLog("${displayName(player)}'s Life Points hit 0! ${displayName(player.opponent())} wins!")
            }
        }
    }
}
