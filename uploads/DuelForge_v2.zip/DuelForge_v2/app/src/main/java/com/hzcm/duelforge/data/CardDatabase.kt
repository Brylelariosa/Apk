package com.hzcm.duelforge.data

import android.content.Context
import com.hzcm.duelforge.model.*
import org.json.JSONArray
import org.json.JSONObject

/**
 * Loads the static card pool from assets/cards.json. To add a brand-new vanilla card,
 * just add an entry here (and drop a matching image into assets/cards/) - no code
 * changes needed. Cards with effects also need a matching entry in EffectRegistry.kt,
 * referenced by the ids listed in [Card.effectIds].
 */
class CardDatabase private constructor(context: Context) {

    /** All unique card definitions, paired with how many copies go in a deck. */
    private val entries: List<Pair<Card, Int>>

    init {
        val json = context.assets.open("cards.json").bufferedReader().use { it.readText() }
        val array = JSONArray(json)
        val list = mutableListOf<Pair<Card, Int>>()
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            list.add(parseCard(obj) to obj.optInt("count", 1))
        }
        entries = list
    }

    private fun parseCard(obj: JSONObject): Card {
        val id = obj.getString("id")
        return Card(
            id = id,
            name = obj.getString("name"),
            cardType = CardType.valueOf(obj.getString("cardType")),
            description = obj.optString("description", ""),
            attribute = obj.optString("attribute", "").takeIf { it.isNotEmpty() }?.let { Attribute.valueOf(it) },
            race = obj.optString("race", "").takeIf { it.isNotEmpty() }?.let { Race.valueOf(it) },
            level = if (obj.has("level")) obj.getInt("level") else null,
            atk = if (obj.has("atk")) obj.getInt("atk") else null,
            def = if (obj.has("def")) obj.getInt("def") else null,
            monsterCategory = obj.optString("monsterCategory", "").takeIf { it.isNotEmpty() }?.let { MonsterCategory.valueOf(it) },
            fusionMaterials = if (obj.has("fusionMaterials")) parseFusionMaterials(obj.getJSONArray("fusionMaterials")) else null,
            spellType = obj.optString("spellType", "").takeIf { it.isNotEmpty() }?.let { SpellType.valueOf(it) },
            trapType = obj.optString("trapType", "").takeIf { it.isNotEmpty() }?.let { TrapType.valueOf(it) },
            imageId = obj.optString("imageId", id),
            isExtraDeck = obj.optBoolean("isExtraDeck", false),
            effectIds = if (obj.has("effectIds")) parseStringArray(obj.getJSONArray("effectIds")) else emptyList()
        )
    }

    /**
     * Parses Fusion Material requirement strings:
     *  - "SPECIFIC:<card_id>"        -> FusionMaterial.Specific
     *  - "RACE:<RACE_NAME>:<count>"  -> FusionMaterial.AnyOfRace
     *  - "ANY:<count>"               -> FusionMaterial.AnyMonster
     */
    private fun parseFusionMaterials(array: JSONArray): List<FusionMaterial> {
        val result = mutableListOf<FusionMaterial>()
        for (i in 0 until array.length()) {
            val parts = array.getString(i).split(":")
            when (parts[0]) {
                "SPECIFIC" -> result.add(FusionMaterial.Specific(parts[1]))
                "RACE" -> result.add(FusionMaterial.AnyOfRace(Race.valueOf(parts[1]), parts.getOrNull(2)?.toIntOrNull() ?: 1))
                "ANY" -> result.add(FusionMaterial.AnyMonster(parts.getOrNull(1)?.toIntOrNull() ?: 1))
            }
        }
        return result
    }

    private fun parseStringArray(array: JSONArray): List<String> {
        val result = mutableListOf<String>()
        for (i in 0 until array.length()) result.add(array.getString(i))
        return result
    }

    /** All cards in the pool (main deck + extra deck), one entry per unique card. */
    fun allCards(): List<Card> = entries.map { it.first }

    /**
     * Builds the ~33-card main deck (unshuffled - the caller shuffles). Currently both
     * players use the same card pool; [player] is accepted for future use (e.g. giving
     * the AI a distinct deck list).
     */
    fun buildMainDeck(player: PlayerId): List<Card> {
        val deck = mutableListOf<Card>()
        for ((card, count) in entries) {
            if (card.isExtraDeck) continue
            repeat(count) { deck.add(card) }
        }
        return deck
    }

    /** Builds the Extra Deck (Fusion Monsters). */
    fun buildExtraDeck(player: PlayerId): List<Card> {
        val deck = mutableListOf<Card>()
        for ((card, count) in entries) {
            if (!card.isExtraDeck) continue
            repeat(count) { deck.add(card) }
        }
        return deck
    }

    companion object {
        @Volatile private var instance: CardDatabase? = null

        fun getInstance(context: Context): CardDatabase =
            instance ?: synchronized(this) {
                instance ?: CardDatabase(context.applicationContext).also { instance = it }
            }
    }
}
