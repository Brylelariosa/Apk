package com.hzcm.duelforge.model

/** Which side of the table. AI is always the opponent in this build. */
enum class PlayerId { PLAYER, AI }

fun PlayerId.opponent(): PlayerId = if (this == PlayerId.PLAYER) PlayerId.AI else PlayerId.PLAYER

/** Top-level card category. */
enum class CardType { MONSTER, SPELL, TRAP }

/** Monster sub-category. Synchro/Xyz/Pendulum/Link are intentionally left out of v1
 *  but Location.EXTRA_DECK + the fusion pathway gives a template for adding them later. */
enum class MonsterCategory { NORMAL, EFFECT, FUSION }

enum class SpellType { NORMAL, QUICK_PLAY, CONTINUOUS, FIELD, EQUIP }

enum class TrapType { NORMAL, CONTINUOUS, COUNTER }

enum class Attribute { DARK, LIGHT, EARTH, WATER, FIRE, WIND, DIVINE }

enum class Race {
    WARRIOR, SPELLCASTER, DRAGON, MACHINE, FIEND, BEAST, BEAST_WARRIOR,
    ZOMBIE, AQUA, PYRO, ROCK, WINGED_BEAST, FAIRY, INSECT, PLANT
}

/** Turn structure. BATTLE is split into sub-steps for priority handling. */
enum class Phase {
    DRAW, STANDBY, MAIN1, BATTLE_START, BATTLE, MAIN2, END
}

/** Where a physical card currently is. */
enum class Location {
    DECK, HAND, GRAVEYARD, BANISHED, EXTRA_DECK,
    MONSTER_ZONE, SPELL_TRAP_ZONE, FIELD_ZONE
}

/** Battle position for monsters. Face-down state is tracked separately via [com.hzcm.duelforge.model.CardInstance.faceUp]. */
enum class BattlePosition { ATTACK, DEFENSE }

/** When a card effect can be activated / how it resolves. */
enum class EffectTiming {
    /** Normal Spell activation from hand, Main Phase only, your turn. Uses the chain. */
    NORMAL,
    /** Main Phase only, once per turn unless the effect says otherwise. Uses the chain. */
    IGNITION,
    /** Activates automatically (with the controller's ok) when its condition becomes true. Uses the chain. */
    TRIGGER,
    /** Can be activated during either player's turn in response to something (Quick-Play Spell, Trap, Quick Effect). Uses the chain. */
    QUICK,
    /** Always "on" while face-up on the field. Does not use the chain. */
    CONTINUOUS,
    /** Triggers once when a face-down monster is flipped face-up. Uses the chain. */
    FLIP
}

/** Describes what a Fusion Monster needs as Fusion Material. */
sealed class FusionMaterial {
    /** A specific named card, by id. */
    data class Specific(val cardId: String) : FusionMaterial()
    /** Any monster(s) of the given Race. */
    data class AnyOfRace(val race: Race, val count: Int = 1) : FusionMaterial()
    /** Any monster(s) at all - the generic "+1 monster" slot. */
    data class AnyMonster(val count: Int = 1) : FusionMaterial()
}
