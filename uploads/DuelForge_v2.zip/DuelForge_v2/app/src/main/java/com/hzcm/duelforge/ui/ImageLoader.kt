package com.hzcm.duelforge.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory

/**
 * Loads card art from `assets/cards/<imageId>.{png,jpg,jpeg,webp}`. If no matching file
 * exists, [loadCardImage] returns null and [CardView] falls back to a generated
 * placeholder (colored by card type, with name/stats text) - so the app works even
 * before any artwork has been added.
 *
 * To add art for a card: drop an image named `<id>.png` (or .jpg/.jpeg/.webp) into
 * `app/src/main/assets/cards/`, where `<id>` matches the card's `id` (or its
 * `imageId` override) in cards.json.
 */
object ImageLoader {
    private val cache = mutableMapOf<String, Bitmap?>()
    private val extensions = listOf("png", "jpg", "jpeg", "webp")

    fun loadCardImage(context: Context, imageId: String): Bitmap? {
        if (cache.containsKey(imageId)) return cache[imageId]

        for (ext in extensions) {
            try {
                context.assets.open("cards/$imageId.$ext").use { stream ->
                    val bmp = BitmapFactory.decodeStream(stream)
                    if (bmp != null) {
                        cache[imageId] = bmp
                        return bmp
                    }
                }
            } catch (e: Exception) {
                // File doesn't exist with this extension - try the next one.
            }
        }
        cache[imageId] = null
        return null
    }

    /** Loads the card back art from assets/card_back.webp (or .png/.jpg/.jpeg fallback). */
    fun loadCardBack(context: Context): Bitmap? {
        val key = "__card_back__"
        if (cache.containsKey(key)) return cache[key]
        for (ext in extensions) {
            try {
                context.assets.open("card_back.$ext").use { stream ->
                    val bmp = BitmapFactory.decodeStream(stream)
                    if (bmp != null) { cache[key] = bmp; return bmp }
                }
            } catch (_: Exception) {}
        }
        cache[key] = null
        return null
    }
}
