package com.hzcm.duelforge.model

import com.hzcm.duelforge.engine.GameEngine

/**
 * Effects are plain Kotlin lambdas registered per-card in EffectRegistry.kt. This keeps
 * cards.json pure data (name/stats/image) while gameplay logic lives in code.
 *
 * - [canActivate]: is this effect legal to activate / does its Trigger condition currently hold?
 * - [targetSelector]: if the effect needs a target, return the list of legal targets
 *   (engine will ask the controller to choose one when there's more than one option).
 * - [payCost]: pay any cost (discard, tribute self, etc). Return false to abort activation.
 * - [resolve]: the actual effect. Runs when the chain link resolves.
 * - [atkBonus] / [defBonus]: CONTINUOUS timing only. Queried by GameEngine.computeAtk/Def
 *   for every face-up field card; return how much ATK/DEF to add to [target], or 0.
 *   This replaces hard-coded card-id checks in the engine — to add a new continuous
 *   stat buff, just supply [atkBonus] here; no GameEngine changes needed.
 */
typealias EffectCondition = (engine: GameEngine, source: CardInstance) -> Boolean
typealias EffectCost      = (engine: GameEngine, source: CardInstance) -> Boolean
typealias TargetSelector  = (engine: GameEngine, source: CardInstance) -> List<CardInstance>
typealias EffectResolve   = (engine: GameEngine, source: CardInstance, targets: List<CardInstance>) -> Unit

/** For CONTINUOUS timing: ATK or DEF bonus granted to [target] while [source] is face-up on the field. */
typealias StatBonus = (engine: GameEngine, source: CardInstance, target: CardInstance) -> Int

data class CardEffect(
    val id: String,
    val timing: EffectTiming,
    val description: String,
    /** Most Ignition/Quick effects are hard-once-per-turn per card. */
    val oncePerTurn: Boolean = false,
    val canActivate: EffectCondition,
    val targetSelector: TargetSelector? = null,
    val payCost: EffectCost? = null,
    val resolve: EffectResolve,
    /**
     * CONTINUOUS timing only. Return how many ATK points to add to [target] while
     * [source] is face-up on the field. Return 0 if this buff doesn't apply to [target].
     * Queried in GameEngine.computeAtk() — do NOT add new continuous buffs there.
     */
    val atkBonus: StatBonus? = null,
    /**
     * CONTINUOUS timing only. Like [atkBonus] but for DEF.
     * Queried in GameEngine.computeDef().
     */
    val defBonus: StatBonus? = null,
)
