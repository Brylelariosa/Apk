package com.hzcm.duelforge.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import com.hzcm.duelforge.data.EffectRegistry
import com.hzcm.duelforge.engine.*
import com.hzcm.duelforge.model.*

/**
 * State holder for the Debug Duel screen. Wraps a standalone [GameEngine] instance
 * (separate from the real game) and exposes debug-only helpers:
 *  - Place any card into any zone directly (bypasses normal summon rules).
 *  - Force-push any effect onto the chain (bypasses canActivate / canActivateEffect).
 *  - Force-resolve or clear the chain at will.
 *  - Manually set phase, LP, turn player, and game events.
 *
 * Use this to test effect interactions, chain ordering, and CONTINUOUS stat calculations
 * without having to play through a real duel to set up the board state.
 */
class DebugViewModel(application: Application) : AndroidViewModel(application) {

    val engine = GameEngine(application.applicationContext)
    val cardDb get() = engine.cardDb

    /** Bumped after every engine mutation; read by composables that need to recompose. */
    var refresh by mutableIntStateOf(0)
        private set

    // ── Setup tab state ────────────────────────────────────────────────────────────────
    var setupPlayer by mutableStateOf(PlayerId.PLAYER)
    var setupZone by mutableStateOf(DebugZone.HAND)
    var setupFaceUp by mutableStateOf(true)
    var setupPosition by mutableStateOf(BattlePosition.ATTACK)
    var cardFilter by mutableStateOf("")

    // ── Chain lab tab state ───────────────────────────────────────────────────────────
    /** Which player we're pushing effects for in the Chain Lab. */
    var chainLabPlayer by mutableStateOf(PlayerId.PLAYER)

    // ── Tab selection ─────────────────────────────────────────────────────────────────
    var activeTab by mutableIntStateOf(0)

    private var instanceCounter = 9000

    init { resetBoard() }

    fun bump() { refresh++ }

    // ── Board reset ────────────────────────────────────────────────────────────────────

    /** Clears everything and starts with a blank board (no decks, just LP). */
    fun resetBoard() {
        val state = engine.state
        state.gameOver = false
        state.winner = null
        state.chain.clear()
        state.log.clear()
        state.turnPlayer = PlayerId.PLAYER
        state.turnCount = 1
        state.phase = Phase.MAIN1
        state.lastEvent = GameEvent.None
        state.pendingHumanPriority = null
        engine.pendingDiscardResume = null
        state.pendingDiscard = null
        engine.pendingResume = null

        for (p in PlayerId.entries) {
            val f = state.field(p)
            f.hand.clear()
            f.graveyard.clear()
            f.banished.clear()
            f.deck.clear()
            f.extraDeck.clear()
            f.monsterZones.fill(null)
            f.spellTrapZones.fill(null)
            f.fieldZone = null
            f.lifePoints = 8000
            f.normalSummonsUsed = 0
            f.normalSummonsAllowed = 1
        }
        state.addLog("=== Debug board initialized — place cards freely ===")
        bump()
    }

    // ── Card placement ─────────────────────────────────────────────────────────────────

    fun placeCard(card: Card, player: PlayerId, zone: DebugZone, faceUp: Boolean, pos: BattlePosition) {
        val state = engine.state
        val field = state.field(player)
        val id = "dbg_${instanceCounter++}"

        when (zone) {
            DebugZone.HAND -> {
                val inst = CardInstance(id, card, player, player).apply {
                    location = Location.HAND; this.faceUp = true
                }
                field.hand.add(inst)
                state.addLog("DEBUG ▶ ${card.name} → ${engine.displayName(player)}'s hand.")
            }
            DebugZone.MONSTER_ZONE -> {
                val idx = field.firstEmptyMonsterZone() ?: run {
                    state.addLog("DEBUG ✗ No empty monster zone for ${engine.displayName(player)}."); bump(); return
                }
                val inst = CardInstance(id, card, player, player).apply {
                    location = Location.MONSTER_ZONE
                    this.faceUp = faceUp
                    battlePosition = pos
                    zoneIndex = idx
                    turnEnteredField = state.turnCount - 1
                }
                field.monsterZones[idx] = inst
                val posStr = if (faceUp) "${pos.name} pos" else "face-down DEF"
                state.addLog("DEBUG ▶ ${card.name} → ${engine.displayName(player)}'s monster zone ($posStr).")
            }
            DebugZone.SPELL_TRAP_ZONE -> {
                val idx = field.firstEmptySpellTrapZone() ?: run {
                    state.addLog("DEBUG ✗ No empty s/t zone for ${engine.displayName(player)}."); bump(); return
                }
                val inst = CardInstance(id, card, player, player).apply {
                    location = Location.SPELL_TRAP_ZONE
                    this.faceUp = faceUp
                    zoneIndex = idx
                    turnEnteredField = state.turnCount - 1
                }
                field.spellTrapZones[idx] = inst
                state.addLog("DEBUG ▶ ${card.name} → ${engine.displayName(player)}'s s/t zone (${if(faceUp) "face-up" else "set"}).")
            }
            DebugZone.FIELD_ZONE -> {
                field.fieldZone?.let { engine.sendToGraveyard(it) }
                val inst = CardInstance(id, card, player, player).apply {
                    location = Location.FIELD_ZONE; this.faceUp = true
                    turnEnteredField = state.turnCount - 1
                }
                field.fieldZone = inst
                state.addLog("DEBUG ▶ ${card.name} → ${engine.displayName(player)}'s field zone.")
            }
            DebugZone.GRAVEYARD -> {
                val inst = CardInstance(id, card, player, player).apply {
                    location = Location.GRAVEYARD; this.faceUp = true
                }
                field.graveyard.add(inst)
                state.addLog("DEBUG ▶ ${card.name} → ${engine.displayName(player)}'s GY.")
            }
        }
        bump()
    }

    // ── Phase / game state controls ────────────────────────────────────────────────────

    fun setPhase(phase: Phase) {
        engine.state.phase = phase
        engine.state.addLog("DEBUG ▶ Phase → ${phase.name}.")
        bump()
    }

    fun setTurnPlayer(player: PlayerId) {
        engine.state.turnPlayer = player
        engine.state.addLog("DEBUG ▶ Turn player → ${engine.displayName(player)}.")
        bump()
    }

    fun setLP(player: PlayerId, lp: Int) {
        engine.state.field(player).lifePoints = lp.coerceAtLeast(0)
        engine.state.addLog("DEBUG ▶ ${engine.displayName(player)} LP → $lp.")
        bump()
    }

    fun adjustLP(player: PlayerId, delta: Int) {
        val field = engine.state.field(player)
        field.lifePoints = (field.lifePoints + delta).coerceAtLeast(0)
        engine.state.addLog("DEBUG ▶ ${engine.displayName(player)} LP ${if(delta>0) "+$delta" else "$delta"} → ${field.lifePoints}.")
        bump()
    }

    fun setLastEvent(event: GameEvent) {
        engine.state.lastEvent = event
        engine.state.addLog("DEBUG ▶ Event → ${engine.describeLastEvent()}")
        bump()
    }

    // ── Chain lab controls ─────────────────────────────────────────────────────────────

    /**
     * Force-pushes [effect] for [source] onto the chain without canActivate / timing
     * / location checks. Cost is still paid (to test cost-paying behavior). Use this to
     * manually build up multi-link chains and see how they resolve.
     */
    fun forcePushEffect(source: CardInstance, effect: CardEffect) {
        val targets = engine.resolveTargets(effect, source, source.controller)
        val ok = engine.pushChainLink(source, effect, source.controller, targets)
        engine.state.addLog(if (ok) "DEBUG ▶ Pushed ${source.card.name}: ${effect.description} (${engine.state.chain.size} on chain)."
                            else "DEBUG ✗ Cost failed for ${source.card.name}: ${effect.description}.")
        bump()
    }

    fun resolveChain() {
        if (engine.state.chain.isEmpty()) {
            engine.state.addLog("DEBUG ✗ Chain is empty.")
        } else {
            engine.state.addLog("DEBUG ▶ Force-resolving chain (${engine.state.chain.size} link(s)) LIFO...")
            engine.resolveChain()
        }
        bump()
    }

    fun clearChain() {
        engine.state.chain.clear()
        engine.state.addLog("DEBUG ▶ Chain cleared.")
        bump()
    }

    fun submitPriorityChoice(index: Int?) {
        engine.submitPriorityChoice(index)
        bump()
    }

    fun openPriorityWindow(player: PlayerId) {
        engine.openPriorityWindow(player) { bump() }
        bump()
    }

    // ── All field cards with effects, for Chain Lab card picker ────────────────────────

    fun fieldCardsWithEffects(player: PlayerId): List<Pair<CardInstance, CardEffect>> {
        val field = engine.state.field(player)
        val result = mutableListOf<Pair<CardInstance, CardEffect>>()
        val allCards = field.hand + field.monsters() + field.spellsAndTraps() + listOfNotNull(field.fieldZone)
        for (card in allCards) {
            for (effect in EffectRegistry.effectsFor(card.card.id)) {
                if (effect.timing != EffectTiming.CONTINUOUS) {
                    result.add(card to effect)
                }
            }
        }
        return result
    }

    // ── Predefined test scenarios ──────────────────────────────────────────────────────

    fun runScenario(scenario: DebugScenario) {
        resetBoard()
        val state = engine.state
        when (scenario) {
            DebugScenario.TRIGGER_ON_SUMMON -> {
                state.addLog("=== SCENARIO: Trigger on Normal Summon ===")
                // Place Stormcaller Falcon in hand, then simulate a normal summon event
                val card = cardDb.allCards().first { it.id == "stormcaller_falcon" }
                placeCard(card, PlayerId.PLAYER, DebugZone.HAND, faceUp = true, pos = BattlePosition.ATTACK)
                // Add some deck cards so draw works
                repeat(5) { placeCard(card, PlayerId.PLAYER, DebugZone.GRAVEYARD, faceUp = true, pos = BattlePosition.ATTACK) }
                state.addLog("→ Place Stormcaller Falcon on the monster zone, then force a NormalSummon event to see draw trigger.")
            }
            DebugScenario.COUNTER_TRAP_NEGATION -> {
                state.addLog("=== SCENARIO: Counter Trap negating a Spell ===")
                val negBarrier = cardDb.allCards().first { it.id == "negation_barrier" }
                val tactReinf  = cardDb.allCards().first { it.id == "tactical_reinforcement" }
                // Player has the spell in hand, AI has the counter trap set
                placeCard(tactReinf,  PlayerId.PLAYER, DebugZone.HAND,          faceUp = true,  pos = BattlePosition.ATTACK)
                placeCard(negBarrier, PlayerId.AI,     DebugZone.SPELL_TRAP_ZONE, faceUp = false, pos = BattlePosition.ATTACK)
                state.addLog("→ Activate Tactical Reinforcement (player) then check if AI can respond with Negation Barrier.")
                state.addLog("→ Use Chain Lab: push Tactical Reinforcement first, then push Negation Barrier, then Resolve.")
            }
            DebugScenario.MULTI_LINK_CHAIN -> {
                state.addLog("=== SCENARIO: 3-link chain ===")
                val rapid    = cardDb.allCards().first { it.id == "rapid_strike" }
                val sentinel = cardDb.allCards().first { it.id == "sentinel_of_the_sealed_gate" }
                val wyrm     = cardDb.allCards().first { it.id == "crimson_war_wyrm" }
                val dummy    = cardDb.allCards().first { it.id == "wildclaw_tiger" }
                // Set up a full board
                placeCard(rapid,    PlayerId.PLAYER, DebugZone.HAND,          faceUp = true, pos = BattlePosition.ATTACK)
                placeCard(sentinel, PlayerId.PLAYER, DebugZone.MONSTER_ZONE,  faceUp = true, pos = BattlePosition.ATTACK)
                placeCard(dummy,    PlayerId.PLAYER, DebugZone.HAND,          faceUp = true, pos = BattlePosition.ATTACK) // discard fodder
                placeCard(wyrm,     PlayerId.AI,     DebugZone.MONSTER_ZONE,  faceUp = true, pos = BattlePosition.ATTACK)
                setPhase(Phase.BATTLE)
                state.lastEvent = GameEvent.AttackDeclared(
                    engine.state.field(PlayerId.PLAYER).monsters().first(),
                    engine.state.field(PlayerId.AI).monsters().first()
                )
                state.addLog("→ Force-push Rapid Strike, then Sentinel, then Resolve to see LIFO order.")
            }
            DebugScenario.CONTINUOUS_BUFF -> {
                state.addLog("=== SCENARIO: Battlefield Overgrowth continuous buff ===")
                val bfog  = cardDb.allCards().first { it.id == "battlefield_overgrowth" }
                val tiger = cardDb.allCards().first { it.id == "wildclaw_tiger" }
                val golem = cardDb.allCards().first { it.id == "obsidian_golem_titan" }
                placeCard(bfog,  PlayerId.PLAYER, DebugZone.FIELD_ZONE,    faceUp = true, pos = BattlePosition.ATTACK)
                placeCard(tiger, PlayerId.PLAYER, DebugZone.MONSTER_ZONE,  faceUp = true, pos = BattlePosition.ATTACK)
                placeCard(golem, PlayerId.AI,     DebugZone.MONSTER_ZONE,  faceUp = true, pos = BattlePosition.ATTACK)
                state.addLog("→ Wildclaw Tiger (EARTH) should show ATK 1900 (1700+200). Obsidian Golem (EARTH) should show 3100 (2900+200).")
                state.addLog("→ Check the ATK values shown on the monster cards in the field view.")
            }
        }
        bump()
    }
}

enum class DebugZone(val label: String) {
    HAND("Hand"),
    MONSTER_ZONE("Monster Zone"),
    SPELL_TRAP_ZONE("S/T Zone"),
    FIELD_ZONE("Field Zone"),
    GRAVEYARD("Graveyard")
}

enum class DebugScenario(val label: String, val description: String) {
    TRIGGER_ON_SUMMON("Trigger: Draw on Summon",       "Stormcaller Falcon draw trigger"),
    COUNTER_TRAP_NEGATION("Chain: Counter Trap",       "Tactical Reinforcement vs Negation Barrier"),
    MULTI_LINK_CHAIN("Chain: 3-Link Chain",            "Rapid Strike + Sentinel vs opponent"),
    CONTINUOUS_BUFF("Continuous: EARTH ATK buff",      "Battlefield Overgrowth +200 ATK on EARTH monsters")
}
