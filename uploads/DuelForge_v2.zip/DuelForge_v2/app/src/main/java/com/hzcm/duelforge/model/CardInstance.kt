package com.hzcm.duelforge.model

/**
 * A specific physical copy of a [Card] as it exists during a duel. Two copies of the
 * same Card in a deck get two different CardInstances with different [instanceId]s.
 */
class CardInstance(
    val instanceId: String,
    val card: Card,
    var owner: PlayerId,
    var controller: PlayerId
) {
    var location: Location = Location.DECK
    var zoneIndex: Int? = null

    // Battle state (monsters only)
    var battlePosition: BattlePosition = BattlePosition.ATTACK
    var faceUp: Boolean = true
    var hasAttackedThisTurn: Boolean = false
    var positionChangedThisTurn: Boolean = false
    var turnEnteredField: Int = -1

    // Temporary stat modifiers, cleared at End Phase by the engine for "until end of turn" effects
    var atkModifier: Int = 0
    var defModifier: Int = 0

    // Once-per-turn effect usage tracking, keyed by effect id
    val effectUsedThisTurn: MutableSet<String> = mutableSetOf()

    // Counters used by some effects (e.g. extra attacks granted this turn)
    var extraAttacksAllowed: Int = 0

    /** Set by Counter Trap effects (e.g. Negation Barrier) on the chain link's source
     *  before it resolves, to negate (and usually destroy) the activation. */
    var isNegated: Boolean = false

    val effectiveAtk: Int get() = ((card.atk ?: 0) + atkModifier).coerceAtLeast(0)
    val effectiveDef: Int get() = ((card.def ?: 0) + defModifier).coerceAtLeast(0)

    /** A trap can't be activated the turn it was Set. */
    fun canActivateAsTrap(currentTurn: Int): Boolean =
        card.cardType == CardType.TRAP && location == Location.SPELL_TRAP_ZONE && turnEnteredField < currentTurn

    fun resetForNewTurn() {
        hasAttackedThisTurn = false
        positionChangedThisTurn = false
        atkModifier = 0
        defModifier = 0
        extraAttacksAllowed = 0
        isNegated = false
        effectUsedThisTurn.clear()
    }

    /** Human-readable label for logs / UI. */
    override fun toString(): String = card.name
}
