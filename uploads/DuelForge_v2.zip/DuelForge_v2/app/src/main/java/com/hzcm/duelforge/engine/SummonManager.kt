package com.hzcm.duelforge.engine

import com.hzcm.duelforge.data.EffectRegistry
import com.hzcm.duelforge.model.*

// ------------------------------------------------------------------
// Normal Summon / Set
// ------------------------------------------------------------------

/** True if [card] (a monster in hand) could be Normal Summoned or Set right now, ignoring tribute count. */
fun GameEngine.canNormalSummon(card: CardInstance): Boolean {
    if (state.gameOver) return false
    if (state.chain.isNotEmpty() || state.pendingHumanPriority != null) return false
    if (card.controller != state.turnPlayer) return false
    if (state.phase != Phase.MAIN1 && state.phase != Phase.MAIN2) return false
    if (card.location != Location.HAND || !card.card.isMonster) return false
    val field = state.field(card.controller)
    if (field.normalSummonsUsed >= field.normalSummonsAllowed) return false
    return true
}

private fun GameEngine.validTributeSet(card: CardInstance, tributes: List<CardInstance>): Boolean {
    val required = card.card.tributesRequired
    if (tributes.size != required) return false
    if (tributes.distinct().size != tributes.size) return false
    return tributes.all { it.location == Location.MONSTER_ZONE && it.controller == card.controller }
}

/**
 * Normal Summons [card] from hand face-up in Attack Position, tributing [tributes] if required.
 * Opens a priority window afterward for Trigger effects like "draw 1 on Normal Summon".
 */
fun GameEngine.normalSummon(card: CardInstance, tributes: List<CardInstance> = emptyList(), onDone: () -> Unit = {}): Boolean {
    if (!canNormalSummon(card) || !validTributeSet(card, tributes)) { onDone(); return false }
    val field = state.field(card.controller)

    for (t in tributes) sendToGraveyard(t)

    val idx = field.firstEmptyMonsterZone()
    if (idx == null) { onDone(); return false }

    removeFromCurrentZone(card)
    card.location = Location.MONSTER_ZONE
    card.zoneIndex = idx
    field.monsterZones[idx] = card
    card.faceUp = true
    card.battlePosition = BattlePosition.ATTACK
    card.turnEnteredField = state.turnCount
    field.normalSummonsUsed++

    val tributeText = if (tributes.isNotEmpty()) " (tributing ${tributes.joinToString { it.card.name }})" else ""
    state.addLog("${displayName(card.controller)} Normal Summons ${card.card.name}$tributeText.")
    state.lastEvent = GameEvent.NormalSummon(card)

    openPriorityWindow(card.controller, onDone)
    return true
}

/**
 * Sets [card] from hand face-down in Defense Position, tributing [tributes] if required.
 * v1 simplification: Setting a monster does not open a priority window (no card in the
 * sample set reacts to a Set).
 */
fun GameEngine.setMonster(card: CardInstance, tributes: List<CardInstance> = emptyList(), onDone: () -> Unit = {}): Boolean {
    if (!canNormalSummon(card) || !validTributeSet(card, tributes)) { onDone(); return false }
    val field = state.field(card.controller)

    for (t in tributes) sendToGraveyard(t)

    val idx = field.firstEmptyMonsterZone()
    if (idx == null) { onDone(); return false }

    removeFromCurrentZone(card)
    card.location = Location.MONSTER_ZONE
    card.zoneIndex = idx
    field.monsterZones[idx] = card
    card.faceUp = false
    card.battlePosition = BattlePosition.DEFENSE
    card.turnEnteredField = state.turnCount
    field.normalSummonsUsed++

    state.addLog("${displayName(card.controller)} sets a monster face-down in Defense Position.")
    onDone()
    return true
}

// ------------------------------------------------------------------
// Set Spell / Trap face-down
// ------------------------------------------------------------------

/**
 * True if [card] (a Trap card in hand) can be Set face-down in the Spell/Trap Zone
 * right now. v1 simplification: only Traps can be Set. Normal/Field Spells are
 * activated directly from hand via [activateEffect]; Quick-Play Spells are also
 * activated directly from hand (a face-down Quick-Play Spell would have no path to
 * activation in v1's priority-window design, so Setting one is disallowed to avoid
 * creating a dead card).
 */
fun GameEngine.canSetSpellOrTrap(card: CardInstance): Boolean {
    if (state.gameOver) return false
    if (state.chain.isNotEmpty() || state.pendingHumanPriority != null) return false
    if (card.controller != state.turnPlayer) return false
    if (state.phase != Phase.MAIN1 && state.phase != Phase.MAIN2) return false
    if (card.location != Location.HAND) return false
    if (card.card.cardType != CardType.TRAP) return false
    return state.field(card.controller).firstEmptySpellTrapZone() != null
}

fun GameEngine.setSpellOrTrap(card: CardInstance, onDone: () -> Unit = {}): Boolean {
    if (!canSetSpellOrTrap(card)) { onDone(); return false }
    val field = state.field(card.controller)
    val idx = field.firstEmptySpellTrapZone()
    if (idx == null) { onDone(); return false }

    removeFromCurrentZone(card)
    card.location = Location.SPELL_TRAP_ZONE
    card.zoneIndex = idx
    field.spellTrapZones[idx] = card
    card.faceUp = false
    card.turnEnteredField = state.turnCount

    state.addLog("${displayName(card.controller)} sets a card face-down.")
    onDone()
    return true
}

// ------------------------------------------------------------------
// Flip Summon
// ------------------------------------------------------------------

/** True if a face-down Defense Position [card] can be manually Flip Summoned right now. */
fun GameEngine.canFlipSummon(card: CardInstance): Boolean {
    if (state.gameOver) return false
    if (state.chain.isNotEmpty() || state.pendingHumanPriority != null) return false
    if (card.controller != state.turnPlayer) return false
    if (state.phase != Phase.MAIN1 && state.phase != Phase.MAIN2) return false
    if (card.location != Location.MONSTER_ZONE || card.faceUp) return false
    // v1 simplification: cannot Flip Summon a monster that was Set this same turn.
    if (card.turnEnteredField >= state.turnCount) return false
    return true
}

fun GameEngine.flipSummon(card: CardInstance, onDone: () -> Unit = {}): Boolean {
    if (!canFlipSummon(card)) { onDone(); return false }
    card.faceUp = true
    card.battlePosition = BattlePosition.ATTACK
    card.positionChangedThisTurn = true
    state.lastEvent = GameEvent.FlipSummon(card)
    state.addLog("${displayName(card.controller)} Flip Summons ${card.card.name}!")
    triggerFlipEffects(card, onDone)
    return true
}

/**
 * Resolves any FLIP-timing effects on [card] (which was just turned face-up, either via
 * Flip Summon or by being attacked while face-down). v1 simplification: FLIP effects
 * auto-activate (pushed onto the chain) without an "ask permission" prompt, then a
 * priority window opens normally so the opponent can respond.
 */
fun GameEngine.triggerFlipEffects(card: CardInstance, onDone: () -> Unit = {}) {
    val effects = EffectRegistry.effectsFor(card.card.id).filter { it.timing == EffectTiming.FLIP && it.canActivate(this, card) }
    for (effect in effects) {
        val targets = resolveTargets(effect, card, card.controller)
        pushChainLink(card, effect, card.controller, targets)
    }
    openPriorityWindow(card.controller, onDone)
}

// ------------------------------------------------------------------
// Battle position change
// ------------------------------------------------------------------

/**
 * True if face-up [card] can switch to [newPosition] right now. Per the real rules, a
 * monster cannot change battle position the turn it was Summoned/Set, the turn it
 * attacked, or more than once per turn.
 */
fun GameEngine.canChangeBattlePosition(card: CardInstance, newPosition: BattlePosition): Boolean {
    if (state.gameOver) return false
    if (state.chain.isNotEmpty() || state.pendingHumanPriority != null) return false
    if (card.controller != state.turnPlayer) return false
    if (state.phase != Phase.MAIN1 && state.phase != Phase.MAIN2) return false
    if (card.location != Location.MONSTER_ZONE || !card.faceUp) return false
    if (card.turnEnteredField >= state.turnCount) return false
    if (card.hasAttackedThisTurn) return false
    if (card.positionChangedThisTurn) return false
    return card.battlePosition != newPosition
}

fun GameEngine.changeBattlePosition(card: CardInstance, newPosition: BattlePosition, onDone: () -> Unit = {}): Boolean {
    if (!canChangeBattlePosition(card, newPosition)) { onDone(); return false }
    card.battlePosition = newPosition
    card.positionChangedThisTurn = true
    val posName = if (newPosition == BattlePosition.ATTACK) "Attack" else "Defense"
    state.addLog("${card.card.name} changes to $posName Position.")
    onDone()
    return true
}

// ------------------------------------------------------------------
// Special Summon (generic) + Fusion Summon
// ------------------------------------------------------------------

/**
 * Generic Special Summon helper used by the Fusion pathway (and available for future
 * effects). Places [card] face-up/face-down per [faceUp] in [position], moving it
 * directly from wherever it currently is into the first empty Monster Zone of [controller]'s
 * field. Opens a priority window afterward. Returns false if there's no room.
 */
fun GameEngine.specialSummon(
    card: CardInstance,
    controller: PlayerId,
    position: BattlePosition = BattlePosition.ATTACK,
    faceUp: Boolean = true,
    onDone: () -> Unit = {}
): Boolean {
    val field = state.field(controller)
    val idx = field.firstEmptyMonsterZone() ?: return false

    removeFromCurrentZone(card)
    card.location = Location.MONSTER_ZONE
    card.zoneIndex = idx
    field.monsterZones[idx] = card
    card.controller = controller
    card.faceUp = faceUp
    card.battlePosition = position
    card.turnEnteredField = state.turnCount

    val posName = if (position == BattlePosition.ATTACK) "Attack" else "Defense"
    state.addLog("${displayName(controller)} Special Summons ${card.card.name} ($posName Position)!")
    state.lastEvent = GameEvent.SpecialSummon(card)

    openPriorityWindow(controller, onDone)
    return true
}

/** Finds the first Fusion Monster in [player]'s Extra Deck whose material cost can be paid right now. */
fun GameEngine.findFusionCombo(player: PlayerId): Pair<CardInstance, List<CardInstance>>? {
    val field = state.field(player)
    val fieldMonsters = field.monsters()
    for (fusionCard in field.extraDeck) {
        val requirements = fusionCard.card.fusionMaterials ?: continue
        val combo = matchFusionMaterials(requirements, fieldMonsters)
        if (combo != null) return fusionCard to combo
    }
    return null
}

/** True if [player] currently has both a valid Fusion combo AND room for the resulting monster. */
fun GameEngine.canFusionSummon(player: PlayerId): Boolean {
    if (findFusionCombo(player) == null) return false
    return state.field(player).firstEmptyMonsterZone() != null
}

/**
 * Performs a Fusion Summon for [player]: sends the first valid material combination to the
 * Graveyard and Special Summons the matching Fusion Monster face-up in Attack Position.
 * v1 simplification: the combination is chosen automatically (first valid match found) -
 * there's no separate "choose your materials" UI step.
 */
fun GameEngine.performFusionSummon(player: PlayerId, onDone: () -> Unit = {}) {
    val combo = findFusionCombo(player)
    if (combo == null) { onDone(); return }
    val (fusionCard, materials) = combo

    state.addLog("${displayName(player)} sends ${materials.joinToString { it.card.name }} to the Graveyard for Fusion Summon.")
    for (m in materials) sendToGraveyard(m)

    val ok = specialSummon(fusionCard, player, BattlePosition.ATTACK, faceUp = true, onDone = onDone)
    if (!ok) onDone()
}

/**
 * Greedily matches [requirements] against [available] monsters, one requirement at a time,
 * never reusing a monster. Returns null if any requirement can't be satisfied.
 */
private fun matchFusionMaterials(requirements: List<FusionMaterial>, available: List<CardInstance>): List<CardInstance>? {
    val remaining = available.toMutableList()
    val chosen = mutableListOf<CardInstance>()
    for (req in requirements) {
        when (req) {
            is FusionMaterial.Specific -> {
                val match = remaining.firstOrNull { it.card.id == req.cardId } ?: return null
                remaining.remove(match)
                chosen.add(match)
            }
            is FusionMaterial.AnyOfRace -> {
                repeat(req.count) {
                    val match = remaining.firstOrNull { it.card.race == req.race } ?: return null
                    remaining.remove(match)
                    chosen.add(match)
                }
            }
            is FusionMaterial.AnyMonster -> {
                repeat(req.count) {
                    val match = remaining.firstOrNull() ?: return null
                    remaining.remove(match)
                    chosen.add(match)
                }
            }
        }
    }
    return chosen
}
