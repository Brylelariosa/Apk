package com.hzcm.duelforge.engine

import com.hzcm.duelforge.data.EffectRegistry
import com.hzcm.duelforge.model.*

/**
 * Drives the AI's entire turn in continuation-passing style. Called once from
 * [GameEngine.advancePhase] when the End Phase hands the turn over to the AI. Each
 * sub-step (summoning, activating effects, attacking) may open a priority window that
 * pauses on a HUMAN response (via [GameState.pendingHumanPriority]); when that's the
 * case, the rest of this chain of callbacks simply doesn't run until
 * [submitPriorityChoice] resumes it later.
 */
fun GameEngine.aiRunTurn(onDone: () -> Unit = {}) {
    if (state.gameOver) { onDone(); return }

    // We're sitting at Phase.DRAW for the AI - advance through Draw/Standby into Main Phase 1.
    advancePhase()
    if (state.gameOver) { onDone(); return }

    aiMainPhaseActions {
        if (state.gameOver) { onDone(); return@aiMainPhaseActions }
        advancePhase() // MAIN1 -> BATTLE_START
        advancePhase() // BATTLE_START -> BATTLE
        if (state.gameOver) { onDone(); return@aiMainPhaseActions }

        aiBattlePhaseActions {
            if (state.gameOver) { onDone(); return@aiBattlePhaseActions }
            advancePhase() // BATTLE -> MAIN2
            if (state.gameOver) { onDone(); return@aiBattlePhaseActions }

            aiMainPhaseActions {
                if (state.gameOver) { onDone(); return@aiMainPhaseActions }
                advancePhase() // MAIN2 -> END
                advancePhase() // END -> endTurn() switches control back to the human player
                if (!state.gameOver) advancePhase() // human's Draw Phase -> Main Phase 1
                onDone()
            }
        }
    }
}

// ------------------------------------------------------------------
// Main Phase
// ------------------------------------------------------------------

/** Repeatedly performs Summons / Sets / effect activations until the AI has nothing more useful to do. */
fun GameEngine.aiMainPhaseActions(onDone: () -> Unit = {}) {
    aiMainPhaseStep(onDone)
}

private fun GameEngine.aiMainPhaseStep(onDone: () -> Unit) {
    if (state.gameOver) { onDone(); return }
    val ai = PlayerId.AI
    val field = state.field(ai)

    // 1. Normal Summon / Set the best available monster, if the Normal Summon hasn't been used.
    if (field.normalSummonsUsed < field.normalSummonsAllowed) {
        val choice = aiPickSummon(ai)
        if (choice != null) {
            val (card, tributes) = choice
            if (aiShouldSetFaceDown(card)) {
                setMonster(card, tributes) { aiMainPhaseStep(onDone) }
            } else {
                normalSummon(card, tributes) { aiMainPhaseStep(onDone) }
            }
            return
        }
    }

    // 2. Activate any currently-useful Normal Spell / Ignition Monster Effect / proactive Quick effect.
    val activation = aiPickActivation(ai)
    if (activation != null) {
        val (source, effect) = activation
        activateEffect(source, effect) { aiMainPhaseStep(onDone) }
        return
    }

    onDone()
}

/** Picks the best monster in hand to Summon this turn, along with the tributes (if any) to pay for it. */
private fun GameEngine.aiPickSummon(ai: PlayerId): Pair<CardInstance, List<CardInstance>>? {
    val field = state.field(ai)
    if (field.firstEmptyMonsterZone() == null) return null

    val handMonsters = field.hand.filter { it.card.isMonster }
    val fieldMonsters = field.monsters()

    var best: Pair<CardInstance, List<CardInstance>>? = null
    var bestScore = Int.MIN_VALUE

    for (card in handMonsters) {
        val required = card.card.tributesRequired
        val tributes: List<CardInstance> = when {
            required == 0 -> emptyList()
            fieldMonsters.size >= required -> fieldMonsters.sortedBy { computeAtk(it) }.take(required)
            else -> continue
        }
        val tributeCost = tributes.sumOf { computeAtk(it) }
        val score = (card.card.atk ?: 0) - tributeCost
        // 0-tribute summons are always worth considering even at 0 ATK; tribute summons
        // only if they're a net upgrade over what's being given up.
        if (tributes.isNotEmpty() && score <= 0) continue
        if (score > bestScore) {
            bestScore = score
            best = card to tributes
        }
    }
    return best
}

/** Defensive (high-DEF, low-ATK) monsters are Set face-down rather than Normal Summoned. */
private fun aiShouldSetFaceDown(card: CardInstance): Boolean {
    val atk = card.card.atk ?: 0
    val def = card.card.def ?: 0
    return def > atk
}

/** Picks the first currently-activatable Ignition / Normal Spell / proactive Quick effect for the AI. */
private fun GameEngine.aiPickActivation(ai: PlayerId): Pair<CardInstance, CardEffect>? {
    val field = state.field(ai)

    for (card in field.monsters()) {
        if (!card.faceUp) continue
        for (effect in EffectRegistry.effectsFor(card.card.id)) {
            if (effect.timing == EffectTiming.IGNITION && canActivateEffect(card, effect)) return card to effect
        }
    }

    for (card in field.hand.toList()) {
        if (card.card.cardType != CardType.SPELL) continue
        for (effect in EffectRegistry.effectsFor(card.card.id)) {
            if ((effect.timing == EffectTiming.NORMAL || effect.timing == EffectTiming.QUICK) && canActivateEffect(card, effect)) {
                return card to effect
            }
        }
    }

    return null
}

// ------------------------------------------------------------------
// Battle Phase
// ------------------------------------------------------------------

/** Attacks with every AI monster that has a sensible attack available, one at a time. */
fun GameEngine.aiBattlePhaseActions(onDone: () -> Unit = {}) {
    val candidates = state.field(PlayerId.AI).monsters()
        .filter { it.faceUp && it.battlePosition == BattlePosition.ATTACK && (!it.hasAttackedThisTurn || it.extraAttacksAllowed > 0) }
    aiBattleStep(candidates, 0, onDone)
}

private fun GameEngine.aiBattleStep(candidates: List<CardInstance>, index: Int, onDone: () -> Unit) {
    if (state.gameOver || index >= candidates.size) { onDone(); return }
    val attacker = candidates[index]

    if (attacker.location != Location.MONSTER_ZONE) {
        aiBattleStep(candidates, index + 1, onDone)
        return
    }

    val opponentMonsters = state.field(PlayerId.AI.opponent()).monsters()
    val target = if (opponentMonsters.isEmpty()) null else aiChooseAttackTarget(attacker)
    val willAttack = canDeclareAttack(attacker, target)

    if (!willAttack) {
        aiBattleStep(candidates, index + 1, onDone)
        return
    }

    declareAttack(attacker, target) {
        aiBattleStep(candidates, index + 1, onDone)
    }
}

/**
 * Picks the best attack target for [attacker]: a target it can destroy without itself
 * being destroyed, preferring the biggest threat. Returns null if no such "safe" target
 * exists (the AI declines to attack into a losing trade).
 */
private fun GameEngine.aiChooseAttackTarget(attacker: CardInstance): CardInstance? {
    val atk = computeAtk(attacker)
    val opponentMonsters = state.field(PlayerId.AI.opponent()).monsters()

    val safeTargets = opponentMonsters.filter { target ->
        val targetStat = if (target.battlePosition == BattlePosition.ATTACK) computeAtk(target) else computeDef(target)
        atk > targetStat
    }

    return safeTargets.maxByOrNull { target ->
        if (target.battlePosition == BattlePosition.ATTACK) computeAtk(target) else computeDef(target)
    }
}

// ------------------------------------------------------------------
// Chain / priority decisions
// ------------------------------------------------------------------

/**
 * Picks which (if any) of [options] the AI activates in response to something. v1
 * simplification: each effect's [CardEffect.canActivate] is written to only return true
 * in situations where activating is genuinely sensible, so the AI simply takes the first
 * available option.
 */
fun GameEngine.aiChooseResponse(options: List<Pair<CardInstance, CardEffect>>): Pair<CardInstance, CardEffect>? =
    options.firstOrNull()

/** When an effect has multiple legal targets, the AI picks the biggest threat / strongest stat. */
fun GameEngine.aiChooseTargets(effect: CardEffect, source: CardInstance, candidates: List<CardInstance>): List<CardInstance> {
    if (candidates.isEmpty()) return emptyList()
    val best = candidates.maxByOrNull { c ->
        if (c.battlePosition == BattlePosition.ATTACK) computeAtk(c) else computeDef(c)
    }
    return listOfNotNull(best)
}
