package com.hzcm.duelforge.engine

import com.hzcm.duelforge.data.EffectRegistry
import com.hzcm.duelforge.model.*
/**
 * CHAIN & PRIORITY MODEL (v1 simplification, documented):
 *
 * Whenever something happens that the *other* player could respond to (a card is
 * activated, a monster is Normal/Special/Flip Summoned, an attack is declared, a card
 * is destroyed...), call [openPriorityWindow]. It checks the responding player for any
 * Quick-Play Spell / Trap / Quick Monster Effect (and pending Trigger effects) they could
 * activate right now:
 *
 *  - If they activate one, it's pushed onto [GameState.chain] and priority flips back to
 *    the other side to respond to THIS new link.
 *  - If they have nothing (or pass), and the chain is empty, play just continues normally.
 *  - If they have nothing (or pass) and the chain is NOT empty, the chain resolves
 *    top-to-bottom (LIFO) in one go via [resolveChain].
 *
 * Simplification: once a link is added and the other side passes, the chain resolves -
 * the side that just added the link doesn't get one extra "chain on your own link again"
 * check first. In practice this still supports real multi-link chains and Counter Traps
 * negating Spells/Effects; it just doesn't model every edge case of the real rules.
 *
 * For the human player, a pending response is surfaced via [GameState.pendingHumanPriority]
 * and resolved by the UI calling [submitPriorityChoice]. The "what happens after" is
 * captured in [GameEngine.pendingResume].
 */

fun GameEngine.openPriorityWindow(actingPlayer: PlayerId, onDone: () -> Unit = {}) {
    if (state.gameOver) { onDone(); return }

    // The acting player's own Trigger effects (e.g. "draw 1 on Normal Summon") fire first.
    // v1 simplification: these auto-activate without an "activate?" prompt, same as FLIP effects.
    for (card in state.field(actingPlayer).monsters()) {
        if (!card.faceUp) continue
        for (effect in EffectRegistry.effectsFor(card.card.id)) {
            if (effect.timing == EffectTiming.TRIGGER &&
                (!effect.oncePerTurn || !card.effectUsedThisTurn.contains(effect.id)) &&
                effect.canActivate(this, card)
            ) {
                val targets = resolveTargets(effect, card, actingPlayer)
                pushChainLink(card, effect, actingPlayer, targets)
            }
        }
    }

    val responder = actingPlayer.opponent()
    val options = getActivatableEffects(responder)

    if (options.isEmpty()) {
        if (state.chain.isEmpty()) {
            onDone()
        } else {
            resolveChain()
            onDone()
        }
        return
    }

    if (responder == PlayerId.AI) {
        val choice = aiChooseResponse(options)
        if (choice == null) {
            if (state.chain.isEmpty()) onDone() else { resolveChain(); onDone() }
        } else {
            val (source, effect) = choice
            val targets = resolveTargets(effect, source, responder)
            val ok = pushChainLink(source, effect, responder, targets)
            if (!ok) {
                if (state.chain.isEmpty()) onDone() else { resolveChain(); onDone() }
            } else {
                openPriorityWindow(responder, onDone)
            }
        }
    } else {
        val labels = options.map { (src, eff) -> "${src.card.name}: ${eff.description}" }
        state.pendingHumanPriority = PriorityPrompt(
            optionLabels = labels,
            optionSources = options.map { it.first },
            optionEffects = options.map { it.second },
            reason = describeLastEvent()
        )
        pendingResume = {
            openPriorityWindow(responder, onDone)
        }
    }
}

/** UI calls this after the human picks an option from [GameState.pendingHumanPriority], or null for "Pass". */
fun GameEngine.submitPriorityChoice(index: Int?) {
    val prompt = state.pendingHumanPriority ?: return
    state.pendingHumanPriority = null

    if (index != null && index in prompt.optionSources.indices) {
        val source = prompt.optionSources[index]
        val effect = prompt.optionEffects[index]
        val targets = resolveTargets(effect, source, PlayerId.PLAYER)
        pushChainLink(source, effect, PlayerId.PLAYER, targets)
    }
    // If index is null (Pass) or invalid, we simply continue - pendingResume re-opens the
    // window from the other side, which will resolve the chain if nobody has anything left.

    val resume = pendingResume
    pendingResume = null
    resume?.invoke()
}

/**
 * Pays costs, marks once-per-turn usage, moves/flips the activated card as appropriate,
 * and pushes a new [ChainLink]. Returns false (and does nothing else) if the cost couldn't be paid.
 */
fun GameEngine.pushChainLink(
    source: CardInstance,
    effect: CardEffect,
    controller: PlayerId,
    targets: List<CardInstance> = emptyList()
): Boolean {
    if (effect.payCost != null && !effect.payCost.invoke(this, source)) {
        state.addLog("${source.card.name}'s effect fizzled - cost could not be paid.")
        return false
    }

    if (effect.oncePerTurn) source.effectUsedThisTurn.add(effect.id)

    when (source.card.cardType) {
        CardType.SPELL -> {
            if (source.location == Location.HAND) {
                removeFromCurrentZone(source)
                source.faceUp = true
                source.turnEnteredField = state.turnCount

                if (source.card.spellType == SpellType.FIELD) {
                    val field = state.field(controller)
                    field.fieldZone?.let { old -> sendToGraveyard(old) }
                    source.location = Location.FIELD_ZONE
                    field.fieldZone = source
                } else {
                    val field = state.field(controller)
                    val idx = field.firstEmptySpellTrapZone()
                    source.location = Location.SPELL_TRAP_ZONE
                    if (idx != null) {
                        source.zoneIndex = idx
                        field.spellTrapZones[idx] = source
                    }
                }
            } else {
                source.faceUp = true
            }
            state.lastEvent = GameEvent.SpellActivated(source)
        }
        CardType.TRAP -> {
            source.faceUp = true
            state.lastEvent = GameEvent.TrapActivated(source)
        }
        CardType.MONSTER -> {
            state.lastEvent = GameEvent.MonsterEffectActivated(source)
        }
    }

    state.chain.add(ChainLink(source, effect, controller, targets))
    val targetText = if (targets.isNotEmpty()) " → ${targets.joinToString { it.card.name }}" else ""
    state.addLog("${displayName(controller)} activates ${source.card.name}: ${effect.description}$targetText")
    return true
}

/** Resolves the whole chain LIFO (top of chain resolves first). */
fun GameEngine.resolveChain() {
    while (state.chain.isNotEmpty()) {
        val link = state.chain.removeAt(state.chain.size - 1)
        if (link.source.isNegated) {
            state.addLog("${link.source.card.name}'s activation was negated.")
        } else {
            link.effect.resolve(this, link.source, link.targets)
            postResolveCleanup(link.source)
        }
        // Pause here if the resolve set a pendingDiscard — GameViewModel.confirmDiscard()
        // will call resolveChain() again after the player picks cards.
        if (state.pendingDiscard != null) return
        checkWinConditions()
        if (state.gameOver) { state.chain.clear(); return }
    }
}

/**
 * Ask [player] to discard [count] card(s) from hand.
 *  - AI / only one card possible → auto-picks last card(s).
 *  - Human with a real choice     → sets [GameState.pendingDiscard] and stores [onDone]
 *    in [GameEngine.pendingDiscardResume]; [resolveChain] will pause until the UI resumes.
 * Call this from inside a resolve lambda. Do NOT add code after calling this for the
 * human-player path — [onDone] handles continuation.
 */
fun GameEngine.requestDiscard(player: PlayerId, count: Int, reason: String, onDone: (List<CardInstance>) -> Unit) {
    val hand = state.field(player).hand
    val needed = count.coerceAtMost(hand.size)
    if (player == PlayerId.AI || hand.size <= count) {
        // Auto-pick: send the last [needed] cards (AI "least valuable" heuristic = last added).
        val chosen = hand.takeLast(needed).toList()
        chosen.forEach { sendToGraveyard(it) }
        if (chosen.isNotEmpty())
            state.addLog("${displayName(player)} discards: ${chosen.joinToString { it.card.name }}.")
        onDone(chosen)
    } else {
        // Human player with a real choice — pause resolution for UI pick.
        state.pendingDiscard = DiscardRequest(player, count, reason)
        pendingDiscardResume = onDone
    }
}

private fun GameEngine.postResolveCleanup(source: CardInstance) {
    if (source.isNegated) return
    when (source.card.cardType) {
        CardType.SPELL -> when (source.card.spellType) {
            SpellType.NORMAL, SpellType.QUICK_PLAY ->
                if (source.location == Location.SPELL_TRAP_ZONE || source.location == Location.HAND) sendToGraveyard(source)
            else -> {} // Field / Continuous / Equip remain on the field
        }
        CardType.TRAP -> when (source.card.trapType) {
            TrapType.NORMAL, TrapType.COUNTER -> sendToGraveyard(source)
            TrapType.CONTINUOUS, null -> {}
        }
        CardType.MONSTER -> {} // monster effects don't move the monster
    }
}

/** All Trigger/Quick/Ignition-via-priority effects [player] could legally activate right now. */
fun GameEngine.getActivatableEffects(player: PlayerId): List<Pair<CardInstance, CardEffect>> {
    val field = state.field(player)
    val result = mutableListOf<Pair<CardInstance, CardEffect>>()

    fun consider(card: CardInstance, effect: CardEffect, mustBeQuickOrTrigger: Boolean) {
        if (mustBeQuickOrTrigger && effect.timing != EffectTiming.QUICK && effect.timing != EffectTiming.TRIGGER) return
        if (effect.oncePerTurn && card.effectUsedThisTurn.contains(effect.id)) return
        if (!effect.canActivate(this, card)) return
        result.add(card to effect)
    }

    // Quick-Play Spells from hand
    for (card in field.hand) {
        if (card.card.cardType == CardType.SPELL && card.card.spellType == SpellType.QUICK_PLAY) {
            for (effect in EffectRegistry.effectsFor(card.card.id)) consider(card, effect, true)
        }
    }

    // Face-up monsters on the field: Quick Effects and Trigger effects
    for (card in field.monsters()) {
        if (!card.faceUp) continue
        for (effect in EffectRegistry.effectsFor(card.card.id)) consider(card, effect, true)
    }

    // Spell/Trap zone cards
    for (card in field.spellsAndTraps()) {
        val legalToActivate = when (card.card.cardType) {
            CardType.TRAP -> card.canActivateAsTrap(state.turnCount)
            CardType.SPELL -> card.faceUp || card.card.spellType == SpellType.QUICK_PLAY
            else -> false
        }
        if (!legalToActivate) continue
        for (effect in EffectRegistry.effectsFor(card.card.id)) consider(card, effect, true)
    }

    return result
}

/** Picks targets for an effect's activation. v1 auto-selects sensible defaults (no extra UI prompt). */
fun GameEngine.resolveTargets(effect: CardEffect, source: CardInstance, controller: PlayerId): List<CardInstance> {
    val selector = effect.targetSelector ?: return emptyList()
    val candidates = selector(this, source)
    if (candidates.size <= 1) return candidates
    return if (controller == PlayerId.AI) aiChooseTargets(effect, source, candidates) else listOf(candidates.first())
}

/**
 * General entry point for player-initiated effect activation: Normal Spells, Ignition Monster
 * Effects, and Quick effects/Quick-Play Spells activated proactively on your own turn (as
 * opposed to in response to something via [openPriorityWindow]/[getActivatableEffects]).
 */
fun GameEngine.canActivateEffect(source: CardInstance, effect: CardEffect): Boolean {
    if (state.gameOver) return false
    if (state.chain.isNotEmpty() || state.pendingHumanPriority != null) return false
    if (effect.oncePerTurn && source.effectUsedThisTurn.contains(effect.id)) return false
    if (!effect.canActivate(this, source)) return false

    when (effect.timing) {
        EffectTiming.NORMAL, EffectTiming.IGNITION -> {
            if (source.controller != state.turnPlayer) return false
            if (state.phase != Phase.MAIN1 && state.phase != Phase.MAIN2) return false
        }
        EffectTiming.QUICK -> {
            // v1 simplification: proactive Quick activation only on your own turn.
            // Responding to the opponent's actions goes through openPriorityWindow instead.
            if (source.controller != state.turnPlayer) return false
        }
        else -> return false // TRIGGER/CONTINUOUS/FLIP aren't activated this way
    }

    when (source.card.cardType) {
        CardType.MONSTER -> if (source.location != Location.MONSTER_ZONE || !source.faceUp) return false
        CardType.SPELL -> if (source.location != Location.HAND) return false
        CardType.TRAP -> return false
    }
    return true
}

fun GameEngine.activateEffect(source: CardInstance, effect: CardEffect, onDone: () -> Unit = {}): Boolean {
    if (!canActivateEffect(source, effect)) { onDone(); return false }
    val targets = resolveTargets(effect, source, source.controller)
    val ok = pushChainLink(source, effect, source.controller, targets)
    if (!ok) { onDone(); return false }
    openPriorityWindow(source.controller, onDone)
    return true
}

fun GameEngine.describeLastEvent(): String = when (val e = state.lastEvent) {
    is GameEvent.NormalSummon -> "${e.card.card.name} was Normal Summoned."
    is GameEvent.SpecialSummon -> "${e.card.card.name} was Special Summoned."
    is GameEvent.FlipSummon -> "${e.card.card.name} was Flip Summoned."
    is GameEvent.SpellActivated -> "${e.card.card.name} was activated."
    is GameEvent.TrapActivated -> "${e.card.card.name} was activated."
    is GameEvent.MonsterEffectActivated -> "${e.card.card.name}'s effect was activated."
    is GameEvent.AttackDeclared -> "${e.attacker.card.name} declared an attack."
    is GameEvent.Destroyed -> "${e.card.card.name} was destroyed."
    is GameEvent.PhaseChanged -> "Entering ${e.phase.name}."
    GameEvent.None -> "You may respond."
}
