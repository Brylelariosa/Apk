# DuelForge

A Yu-Gi-Oh-style Trading Card Game engine for Android, built with Kotlin and Jetpack
Compose. Play a full duel (Draw/Standby/Main 1/Battle/Main 2/End phases, Normal/Flip/
Fusion/Special Summons, a real chain/priority system, Spell/Trap activation, Counter
Traps, etc.) against a simple AI opponent, using a 17-card original sample deck plus
2 Extra Deck Fusion Monsters.

## How to play

- The screen is split into: opponent's field (top), turn/phase bar, a battle log +
  action panel (middle), and your field + hand (bottom).
- **Tap a card** (in your hand, on your field, or in your Spell/Trap zone) to see
  available actions in the right-hand panel: Normal Summon, Set, Flip Summon, switch
  Attack/Defense Position, or Activate an effect.
- **Tributes**: if a monster needs tributes, after choosing Normal Summon/Set you'll
  be asked to tap that many of your own field monsters, then press Confirm.
- **Attacking**: during your Battle Phase, tap one of your face-up Attack Position
  monsters to select it as an attacker, then tap an opponent's monster to attack it
  (or press "Attack Directly" if they have no monsters).
- **Responding**: when the opponent does something you can respond to (with a
  face-up Quick Effect, a Quick-Play Spell in hand, or a Trap on your field), a
  dialog pops up listing your options, plus "Pass".
- Press **Next Phase** to advance; pressing it during your End Phase ends your turn
  and the AI plays its entire turn automatically (pausing for any response prompts
  of yours along the way).

## What's implemented

- Full turn structure: Draw -> Standby -> Main 1 -> Battle -> Main 2 -> End, with the
  turn player skipping their first Draw Phase.
- Normal Summon and Set (face-down Defense), with tribute requirements based on Level
  (1-4: none, 5-6: one, 7+: two).
- Flip Summon (manually flipping a Set monster face-up) and flipping via battle, both
  triggering FLIP effects.
- Battle Position changes (once per turn, not the turn a monster was Summoned/Set or
  attacked).
- Battle: ATK-vs-ATK, ATK-vs-DEF, and direct attacks, including piercing-style "you
  take the difference" damage when your attacker's ATK is less than a Defense
  Position target's DEF.
- A real chain/priority system: Quick-Play Spells, Quick Effects, Traps (including
  Counter Traps that negate-and-destroy), and Trigger effects can all be chained,
  resolving LIFO.
- Fusion Summon via "Fusion Catalyst", which finds a valid Fusion Monster + material
  combination on your field and Special Summons it.
- A Field Spell (Battlefield Overgrowth) that buffs all EARTH monsters' ATK.
- A simple AI opponent that plays its whole turn: summons/sets the best available
  monster (tributing when it's a net upgrade), activates useful Spells/Effects,
  attacks only into favorable trades, and responds to your actions with its own
  Quick Effects/Traps when it has them.

## v1 simplifications (by design)

These keep the engine manageable while still feeling like "real" Yu-Gi-Oh. Worth
knowing if a duel plays out unexpectedly:

- **No Synchro/Xyz/Pendulum/Link monsters.** The Extra Deck + Fusion Summon pathway
  is built to be extended to these later if you want.
- **Fusion Summon auto-picks materials** - the first valid combination found on your
  field is used automatically; there's no "choose your fusion materials" screen.
- **Trigger and FLIP effects auto-activate** (no "would you like to activate?"
  prompt) - they just happen and then the opponent gets a chance to respond.
- **Chains resolve fully once both sides pass once** - real Yu-Gi-Oh re-opens
  priority after every single chain link resolves; here, once nobody adds a new
  link, the whole stack resolves top-to-bottom in one go. Multi-link chains and
  Counter Traps still work correctly, but some very specific real-game edge cases
  (e.g. responding mid-resolution to something a lower chain link does) aren't
  modeled.
- **No hand-size limit** at the End Phase.
- **Quick-Play Spells can't be Set face-down** - they're activated directly from
  hand only (a Set Quick-Play Spell would have no path to activation in this
  engine's priority design).
- **A monster Set face-down can't be Flip Summoned the same turn it was Set.**
- **The AI doesn't use Quick-Play Spells during its Battle Phase**, and doesn't Flip
  Summon its own Set monsters - both remain possible for the human player.

## Adding cards / art

See `app/src/main/assets/cards/README.md` for full instructions. Short version:
drop `<card_id>.png` into `app/src/main/assets/cards/` for artwork (placeholders are
used otherwise), and add new card data to `app/src/main/assets/cards.json` - effect
cards also need an entry in `app/src/main/java/com/hzcm/duelforge/data/EffectRegistry.kt`.

## Building via GitHub Actions

This project is set up for the same GitHub Actions pipeline as your other Android
projects:

1. Zip this whole `DuelForge/` folder (keep `gradlew` executable inside the zip).
2. Push the zip into your repo's `uploads/` folder.
3. The workflow extracts it, locates `settings.gradle.kts`, fetches the Gradle 8.6
   wrapper jar, and builds a debug APK with AGP 8.2.2 / Kotlin 1.9.22 / JDK 17.
4. Download the APK from the workflow run's artifacts.

## Project structure

```
app/src/main/java/com/hzcm/duelforge/
  model/    - Card, CardInstance, GameState, Enums, CardEffect (pure data types)
  data/     - CardDatabase (loads cards.json), EffectRegistry (effect implementations)
  engine/   - GameEngine (core), ChainManager, SummonManager, BattleManager, AIController
  ui/       - GameViewModel, GameScreen, CardView, ImageLoader
  MainActivity.kt
app/src/main/assets/
  cards.json      - all card data
  cards/          - card artwork (add your own PNGs here)
```

See `devlog.md` for a running development log of architecture decisions and
known issues.
