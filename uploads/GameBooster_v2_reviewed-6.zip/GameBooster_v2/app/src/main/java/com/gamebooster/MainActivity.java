package com.gamebooster;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.net.VpnService;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.content.ContextCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Dashboard Activity for GameBooster.
 *
 * <h3>Revert bug — final fix</h3>
 * Root cause: {@code onResume} read the SharedPreferences flag before the service
 * had written it (async {@code apply()}), saw {@code false}, and called
 * {@code syncBoostUi(false)}, reverting the button.
 *
 * <p>Two-part fix:
 * <ol>
 *   <li>{@link BoostService} now uses {@code commit()} (synchronous) when writing
 *       {@code KEY_IS_RUNNING}, so the flag is guaranteed to be on disk before
 *       the service returns from {@code onStartCommand}.</li>
 *   <li>{@code onResume} skips the flag check if the boost was started within the
 *       last {@link #BOOST_GRACE_MS} (3 s) — the optimistic UI is trusted during
 *       this window and the broadcast from the service will confirm it shortly.</li>
 * </ol>
 *
 * <h3>New features</h3>
 * <ul>
 *   <li>Recently selected games shown in My Games list — tap to switch quickly.</li>
 *   <li>"Add manually" button added to the hero card.</li>
 *   <li>Three-finger screenshot disabled on boost-on, restored on boost-off (via
 *       {@link ThreeFingerScreenshotHelper} inside the service).</li>
 *   <li>If the device doesn't support three-finger screenshot, the option is hidden.</li>
 * </ul>
 */
public class MainActivity extends AppCompatActivity {

    private static final String TAG              = "MainActivity";
    private static final String KEY_SELECTED_PKG   = "sel_pkg";
    private static final String KEY_SELECTED_LABEL = "sel_label";
    private static final String PREFS_APP          = "gamebooster_app";
    private static final String KEY_XOS_GUIDE_SHOWN = "xos_guide_shown";

    /**
     * Grace window after tapping Boost during which {@code onResume} will NOT
     * override the optimistic UI with the SharedPreferences flag.
     * 3 s is more than enough for the service to write the flag synchronously
     * and for any system animation to complete.
     */
    private static final long BOOST_GRACE_MS = 3_000L;

    // ── Views — Hero ──────────────────────────────────────────────────────────
    private ImageView    ivHeroIcon;
    private TextView     tvHeroGameName;
    private TextView     tvHeroStatus;
    private TextView     tvHeroTweaks;

    // ── Views — Warning banners ───────────────────────────────────────────────
    private View     bannerThermal;
    private TextView tvThermalMsg;
    private View     bannerRam;
    private TextView tvRamMsg;

    // ── Views — Permission cards ──────────────────────────────────────────────
    private MaterialCardView cardPermUsage,      cardPermDnd;
    private MaterialCardView cardPermBrightness, cardPermBattery;
    private ImageView        ivPermUsage,        ivPermDnd;
    private ImageView        ivPermBrightness,   ivPermBattery;
    private TextView         tvPermUsage,        tvPermDnd;
    private TextView         tvPermBrightness,   tvPermBattery;

    // ── Views — Profiles ──────────────────────────────────────────────────────
    private MaterialCardView cardBattery, cardBalanced, cardMax;

    // ── Views — Stats + Options + Action ─────────────────────────────────────
    private View           statsSection;
    private TextView       tvStatRam, tvStatCpu, tvStatBattery;
    private SwitchCompat   switchVpn;
    private MaterialButton btnBoost;
    private MaterialButton btnPickGame;

    // ── Views — My Games list ─────────────────────────────────────────────────
    private LinearLayout llMyGames;
    private TextView     tvNoGames;

    // ── State ─────────────────────────────────────────────────────────────────
    private AppInfo         selectedApp;
    private BoostProfile    selectedProfile;
    private boolean         isBoosting    = false;
    private long            boostStartedAt = 0L;   // timestamp for grace-window check
    private GamePreferences prefs;

    // ── Sound ─────────────────────────────────────────────────────────────────
    private BoostSoundManager soundManager;

    // ── Executors ─────────────────────────────────────────────────────────────
    private final ExecutorService iconExecutor = Executors.newSingleThreadExecutor();
    private final Handler         mainHandler  = new Handler(Looper.getMainLooper());
    private final Handler         statsHandler = new Handler(Looper.getMainLooper());

    // ── Activity result launchers ─────────────────────────────────────────────
    private ActivityResultLauncher<Intent> permLauncher;
    private ActivityResultLauncher<Intent> vpnConsentLauncher;
    private String pendingVpnPackage;

    // ── Broadcast receiver ────────────────────────────────────────────────────
    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override public void onReceive(Context ctx, Intent intent) {
            if (intent == null || intent.getAction() == null) return;
            switch (intent.getAction()) {
                case BoostService.ACTION_STATE_CHANGED:
                    boolean running = intent.getBooleanExtra(
                        BoostService.EXTRA_IS_RUNNING, false);
                    // Always trust an explicit broadcast from the service —
                    // this is the authoritative signal (grace window does not apply here).
                    syncBoostUi(running);
                    break;
                case BoostService.ACTION_THERMAL_WARNING:
                    showThermalBanner(intent.getFloatExtra(
                        BoostService.EXTRA_THERMAL_HEADROOM, 0f));
                    break;
                case BoostService.ACTION_THERMAL_OK:
                    hideThermalBanner();
                    break;
                case BoostService.ACTION_RAM_WARNING:
                    showRamBanner(intent.getLongExtra(BoostService.EXTRA_RAM_FREE_MB, 0));
                    break;
                case BoostService.ACTION_RAM_OK:
                    hideRamBanner();
                    break;
            }
        }
    };

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs        = new GamePreferences(this);
        soundManager = new BoostSoundManager(this);

        bindViews();
        setupActivityResultLaunchers();
        setupProfileCards();
        setupVpnSwitch();
        setupPickGameButton();
        updateThreeFingerCard();

        if (savedInstanceState != null) {
            String pkg   = savedInstanceState.getString(KEY_SELECTED_PKG);
            String label = savedInstanceState.getString(KEY_SELECTED_LABEL);
            if (pkg != null) {
                AppInfo a = new AppInfo(label != null ? label : pkg, pkg);
                a.isFavorite = prefs.isFavorite(pkg);
                onAppSelected(a, false);
            }
        } else {
            restoreLastGame();
        }

        selectedProfile = prefs.getProfile();
        switchVpn.setChecked(prefs.isVpnEnabled());
        highlightProfileCard(selectedProfile);
        showXosGuideOnFirstLaunch();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updatePermissionCards();
        updateThreeFingerCard();
        refreshMyGames();
        registerBroadcasts();

        // REVERT FIX — two-part guard:
        // 1. If we just started the boost within BOOST_GRACE_MS, don't check the flag —
        //    the service is still starting up and the optimistic UI is correct.
        // 2. Otherwise read the synchronously-written SharedPreferences flag.
        boolean inGraceWindow = isBoosting
            && (System.currentTimeMillis() - boostStartedAt) < BOOST_GRACE_MS;

        if (!inGraceWindow) {
            boolean serviceRunning = getBoostServiceFlag();
            if (isBoosting != serviceRunning) {
                syncBoostUi(serviceRunning);
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        LocalBroadcastManager.getInstance(this).unregisterReceiver(receiver);
        stopStatsPolling();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        soundManager.release();
        iconExecutor.shutdownNow();
        mainHandler.removeCallbacksAndMessages(null);
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        if (selectedApp != null) {
            out.putString(KEY_SELECTED_PKG,   selectedApp.packageName);
            out.putString(KEY_SELECTED_LABEL, selectedApp.label);
        }
    }

    // ── View binding ──────────────────────────────────────────────────────────

    private void bindViews() {
        ivHeroIcon     = findViewById(R.id.iv_hero_icon);
        tvHeroGameName = findViewById(R.id.tv_hero_game_name);
        tvHeroStatus   = findViewById(R.id.tv_hero_status);
        tvHeroTweaks   = findViewById(R.id.tv_hero_tweaks);

        bannerThermal = findViewById(R.id.banner_thermal);
        tvThermalMsg  = findViewById(R.id.tv_thermal_msg);
        bannerRam     = findViewById(R.id.banner_ram);
        tvRamMsg      = findViewById(R.id.tv_ram_msg);

        cardPermUsage      = findViewById(R.id.card_perm_usage);
        cardPermDnd        = findViewById(R.id.card_perm_dnd);
        cardPermBrightness = findViewById(R.id.card_perm_brightness);
        cardPermBattery    = findViewById(R.id.card_perm_battery);
        ivPermUsage        = findViewById(R.id.iv_perm_usage);
        ivPermDnd          = findViewById(R.id.iv_perm_dnd);
        ivPermBrightness   = findViewById(R.id.iv_perm_brightness);
        ivPermBattery      = findViewById(R.id.iv_perm_battery);
        tvPermUsage        = findViewById(R.id.tv_perm_usage_label);
        tvPermDnd          = findViewById(R.id.tv_perm_dnd_label);
        tvPermBrightness   = findViewById(R.id.tv_perm_brightness_label);
        tvPermBattery      = findViewById(R.id.tv_perm_battery_label);

        cardBattery  = findViewById(R.id.card_profile_battery);
        cardBalanced = findViewById(R.id.card_profile_balanced);
        cardMax      = findViewById(R.id.card_profile_max);

        statsSection  = findViewById(R.id.section_live_stats);
        tvStatRam     = findViewById(R.id.tv_stat_ram);
        tvStatCpu     = findViewById(R.id.tv_stat_cpu);
        tvStatBattery = findViewById(R.id.tv_stat_battery);

        switchVpn    = findViewById(R.id.switch_vpn);
        btnBoost     = findViewById(R.id.btn_boost);
        btnPickGame  = findViewById(R.id.btn_pick_game);
        llMyGames    = findViewById(R.id.ll_my_games);
        tvNoGames    = findViewById(R.id.tv_no_games);

        btnBoost.setOnClickListener(v -> onBoostClicked());
    }

    // ── Activity result launchers ─────────────────────────────────────────────

    private void setupActivityResultLaunchers() {
        permLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            r -> updatePermissionCards());
        vpnConsentLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            r -> {
                if (r.getResultCode() == Activity.RESULT_OK && pendingVpnPackage != null)
                    launchVpnService(pendingVpnPackage);
                pendingVpnPackage = null;
            });
    }

    // ── Profile cards ─────────────────────────────────────────────────────────

    private void setupProfileCards() {
        cardBattery.setOnClickListener(v -> selectProfile(BoostProfile.BATTERY_SAVER));
        cardBalanced.setOnClickListener(v -> selectProfile(BoostProfile.BALANCED));
        cardMax.setOnClickListener(v -> selectProfile(BoostProfile.MAX_PERFORMANCE));
    }

    private void selectProfile(BoostProfile p) {
        selectedProfile = p;
        prefs.saveProfile(p);
        highlightProfileCard(p);
        updateHeroTweaks();
        if (p == BoostProfile.MAX_PERFORMANCE && !switchVpn.isChecked()) {
            switchVpn.setChecked(true);
            prefs.saveVpnEnabled(true);
        }
    }

    private void highlightProfileCard(BoostProfile p) {
        int sS = ContextCompat.getColor(this, R.color.boost_color);
        int nS = ContextCompat.getColor(this, R.color.card_stroke);
        int sB = ContextCompat.getColor(this, R.color.profile_selected_bg);
        int nB = ContextCompat.getColor(this, R.color.bg_card);
        resetProfileCard(cardBattery, nS, nB);
        resetProfileCard(cardBalanced, nS, nB);
        resetProfileCard(cardMax, nS, nB);
        MaterialCardView sel = p == BoostProfile.BATTERY_SAVER ? cardBattery
            : p == BoostProfile.MAX_PERFORMANCE ? cardMax : cardBalanced;
        sel.setStrokeColor(sS); sel.setStrokeWidth(dpToPx(2)); sel.setCardBackgroundColor(sB);
    }

    private void resetProfileCard(MaterialCardView c, int s, int b) {
        c.setStrokeColor(s); c.setStrokeWidth(dpToPx(1)); c.setCardBackgroundColor(b);
    }

    // ── VPN switch ────────────────────────────────────────────────────────────

    private void setupVpnSwitch() {
        switchVpn.setOnCheckedChangeListener((b, c) -> prefs.saveVpnEnabled(c));
    }

    // ── App picker ────────────────────────────────────────────────────────────

    private void setupPickGameButton() {
        btnPickGame.setOnClickListener(v -> {
            AppPickerBottomSheet sheet = AppPickerBottomSheet.newInstance();
            sheet.setOnAppPicked(app -> onAppSelected(app, true));
            sheet.show(getSupportFragmentManager(), AppPickerBottomSheet.TAG);
        });
    }

    private void setupAddManualButton() {
        // removed — manual entry replaced by My Games list
    }

    /** Updates the three-finger card: hidden if unsupported, warning if WRITE_SETTINGS not granted. */
    private void updateThreeFingerCard() {
        View card = findViewById(R.id.card_option_three_finger);
        if (card == null) return;

        if (!ThreeFingerScreenshotHelper.isSupported(this)) {
            card.setVisibility(View.GONE);
            return;
        }
        card.setVisibility(View.VISIBLE);

        ImageView statusIcon = card.findViewById(R.id.iv_three_finger_status);
        if (statusIcon == null) return;

        boolean canWrite = PermissionHelper.canWriteSettings(this);
        if (canWrite) {
            statusIcon.setImageResource(R.drawable.ic_check_circle);
            statusIcon.setColorFilter(ContextCompat.getColor(this, R.color.perm_ok));
            card.setOnClickListener(null);
            card.setClickable(false);
        } else {
            statusIcon.setImageResource(R.drawable.ic_warning);
            statusIcon.setColorFilter(ContextCompat.getColor(this, R.color.perm_warn));
            card.setClickable(true);
            card.setOnClickListener(v ->
                permLauncher.launch(PermissionHelper.writeSettingsIntent(this)));
        }
    }

    // ── My Games list ─────────────────────────────────────────────────────────

    /** Rebuilds the My Games list from recent packages. Loads labels+icons in background. */
    private void refreshMyGames() {
        java.util.List<String> recents = prefs.getRecentPackages();
        if (recents.isEmpty()) {
            tvNoGames.setVisibility(View.VISIBLE);
            llMyGames.setVisibility(View.GONE);
            return;
        }
        tvNoGames.setVisibility(View.GONE);
        llMyGames.setVisibility(View.VISIBLE);
        llMyGames.removeAllViews();

        LayoutInflater inflater = LayoutInflater.from(this);
        for (String pkg : recents) {
            View row = inflater.inflate(R.layout.item_game_row, llMyGames, false);
            ImageView icon   = row.findViewById(R.id.iv_game_icon);
            TextView  label  = row.findViewById(R.id.tv_game_label);
            ImageView active = row.findViewById(R.id.iv_game_active);

            label.setText(pkg); // placeholder until background resolves real label
            active.setVisibility(
                selectedApp != null && pkg.equals(selectedApp.packageName)
                    ? View.VISIBLE : View.GONE);

            llMyGames.addView(row);

            // Resolve real label + icon in background
            final String finalPkg = pkg;
            iconExecutor.execute(() -> {
                String resolvedLabel = finalPkg;
                Drawable resolvedIcon = null;
                try {
                    PackageManager pm = getPackageManager();
                    resolvedLabel = pm.getApplicationLabel(
                        pm.getApplicationInfo(finalPkg, 0)).toString();
                    resolvedIcon = pm.getApplicationIcon(finalPkg);
                } catch (Exception ignored) {}

                final String fl = resolvedLabel;
                final Drawable fi = resolvedIcon;
                mainHandler.post(() -> {
                    if (row.getParent() == null) return; // row was removed
                    label.setText(fl);
                    if (fi != null) icon.setImageDrawable(fi);
                    row.setOnClickListener(v -> {
                        AppInfo app = new AppInfo(fl, finalPkg);
                        app.isFavorite = prefs.isFavorite(finalPkg);
                        onAppSelected(app, true);
                    });
                });
            });

            // Set initial click listener (uses pkg as fallback label until bg resolves)
            row.setOnClickListener(v -> {
                AppInfo app = new AppInfo(label.getText().toString(), finalPkg);
                app.isFavorite = prefs.isFavorite(finalPkg);
                onAppSelected(app, true);
            });
        }
    }

    private void onAppSelected(AppInfo app, boolean playSound) {
        selectedApp = app;
        prefs.saveLastGame(app);
        tvHeroGameName.setText(app.label);
        tvHeroTweaks.setVisibility(View.VISIBLE);
        updateHeroTweaks();
        if (playSound) soundManager.playGameSelected();
        refreshMyGames(); // update active indicator + add to list

        if (app.icon != null) {
            ivHeroIcon.setImageDrawable(app.icon);
        } else {
            ivHeroIcon.setImageResource(R.drawable.ic_gamepad);
            final String pkg = app.packageName;
            iconExecutor.execute(() -> {
                Drawable icon = null;
                try { icon = getPackageManager().getApplicationIcon(pkg); }
                catch (Exception ignored) {}
                final Drawable fi = icon;
                mainHandler.post(() -> {
                    if (selectedApp != null && selectedApp.packageName.equals(pkg)) {
                        if (fi != null) { app.icon = fi; ivHeroIcon.setImageDrawable(fi); }
                    }
                });
            });
        }
    }

    private void restoreLastGame() {
        String pkg = prefs.getLastPackage(), label = prefs.getLastLabel();
        if (pkg != null) {
            AppInfo a = new AppInfo(label != null ? label : pkg, pkg);
            a.isFavorite = prefs.isFavorite(pkg);
            onAppSelected(a, false);
        }
    }

    // ── Boost control ─────────────────────────────────────────────────────────

    private void onBoostClicked() {
        if (isBoosting) stopBoosting();
        else            startBoosting();
    }

    private void startBoosting() {
        if (!PermissionHelper.hasUsageAccess(this)) {
            showSettingsDialog("Usage Access Required",
                "GameBooster needs Usage Access to detect when your game exits.\n\n"
                    + "Tap OK → enable GameBooster under Usage access.",
                PermissionHelper.usageAccessIntent());
            return;
        }

        if (PermissionHelper.isXosDevice()
                && !PermissionHelper.isBatteryOptimizationIgnored(this)) {
            new AlertDialog.Builder(this)
                .setTitle("⚠️  Battery Restriction Active")
                .setMessage("XOS will kill the boost within seconds because GameBooster "
                    + "is battery-restricted.\n\nTap \"Allow\" to exempt it, "
                    + "then start the boost again.")
                .setPositiveButton("Allow", (d, w) ->
                    permLauncher.launch(PermissionHelper.batteryOptimizationIntent(this)))
                .setNegativeButton("Boost Anyway", (d, w) -> doStartBoosting())
                .show();
            return;
        }

        doStartBoosting();
    }

    private void doStartBoosting() {
        if (selectedApp == null) {
            toast("Tap \"Select Game\" to choose a game first");
            return;
        }
        if (selectedProfile.enableDnd && !PermissionHelper.hasNotificationPolicyAccess(this))
            toast("DND access not granted — silence mode will be skipped");
        if (selectedProfile.enableMaxBrightness && !PermissionHelper.canWriteSettings(this))
            toast("Write Settings not granted — brightness boost will be skipped");

        startForegroundService(new Intent(this, BoostService.class)
            .putExtra(BoostService.EXTRA_PACKAGE, selectedApp.packageName)
            .putExtra(BoostService.EXTRA_LABEL,   selectedApp.label)
            .putExtra(BoostService.EXTRA_PROFILE,  selectedProfile.name()));

        if (selectedProfile.enableVpn && switchVpn.isChecked())
            requestVpnConsent(selectedApp.packageName);

        // Record the exact time we started so onResume can respect the grace window
        boostStartedAt = System.currentTimeMillis();
        syncBoostUi(true);
        soundManager.playBoostOn();
        toast("⚡ Boost started — " + selectedProfile.displayName);
        moveTaskToBack(true); // return to game / home screen
    }

    private void stopBoosting() {
        stopService(new Intent(this, BoostService.class));
        if (BoostVpnService.isRunning)
            startService(new Intent(this, BoostVpnService.class)
                .setAction(BoostVpnService.ACTION_STOP));
        boostStartedAt = 0L;
        syncBoostUi(false);
        soundManager.playBoostOff();
        toast("Boost stopped");
    }

    // ── VPN consent ───────────────────────────────────────────────────────────

    private void requestVpnConsent(String pkg) {
        Intent prepare = VpnService.prepare(this);
        if (prepare != null) { pendingVpnPackage = pkg; vpnConsentLauncher.launch(prepare); }
        else launchVpnService(pkg);
    }

    private void launchVpnService(String pkg) {
        startService(new Intent(this, BoostVpnService.class)
            .putExtra(BoostVpnService.EXTRA_GAME_PACKAGE, pkg));
    }

    // ── UI sync ───────────────────────────────────────────────────────────────

    private void syncBoostUi(boolean boosting) {
        isBoosting = boosting;
        if (boosting) {
            btnBoost.setText(R.string.btn_stop);
            btnBoost.setBackgroundTintList(
                ContextCompat.getColorStateList(this, R.color.stop_color));
            tvHeroStatus.setText(R.string.status_active);
            tvHeroStatus.setTextColor(ContextCompat.getColor(this, R.color.perm_ok));
            statsSection.setVisibility(View.VISIBLE);
            startStatsPolling();
        } else {
            btnBoost.setText(R.string.btn_boost);
            btnBoost.setBackgroundTintList(
                ContextCompat.getColorStateList(this, R.color.boost_color));
            tvHeroStatus.setText(
                selectedApp != null ? R.string.status_ready : R.string.status_no_game);
            tvHeroStatus.setTextColor(ContextCompat.getColor(this, R.color.text_secondary));
            statsSection.setVisibility(View.GONE);
            stopStatsPolling();
            hideThermalBanner();
            hideRamBanner();
        }
    }

    // ── Permission cards ──────────────────────────────────────────────────────

    private void updatePermissionCards() {
        setPermCard(cardPermUsage, ivPermUsage, tvPermUsage,
            PermissionHelper.hasUsageAccess(this),
            getString(R.string.perm_usage_short), PermissionHelper.usageAccessIntent());
        setPermCard(cardPermDnd, ivPermDnd, tvPermDnd,
            PermissionHelper.hasNotificationPolicyAccess(this),
            getString(R.string.perm_dnd_short), PermissionHelper.notificationPolicyIntent());
        setPermCard(cardPermBrightness, ivPermBrightness, tvPermBrightness,
            PermissionHelper.canWriteSettings(this),
            getString(R.string.perm_brightness_short), PermissionHelper.writeSettingsIntent(this));
        setPermCard(cardPermBattery, ivPermBattery, tvPermBattery,
            PermissionHelper.isBatteryOptimizationIgnored(this),
            getString(R.string.perm_battery_short),
            PermissionHelper.batteryOptimizationIntent(this));
    }

    private void setPermCard(MaterialCardView card, ImageView icon, TextView label,
                              boolean granted, String text, Intent intent) {
        int okC = ContextCompat.getColor(this, R.color.perm_ok);
        int wC  = ContextCompat.getColor(this, R.color.perm_warn);
        int okS = ContextCompat.getColor(this, R.color.perm_ok_stroke);
        int wS  = ContextCompat.getColor(this, R.color.perm_warn_stroke);
        label.setText(text);
        if (granted) {
            icon.setImageResource(R.drawable.ic_check_circle);
            icon.setColorFilter(okC);
            card.setStrokeColor(okS);
            card.setOnClickListener(null);
        } else {
            icon.setImageResource(R.drawable.ic_warning);
            icon.setColorFilter(wC);
            card.setStrokeColor(wS);
            card.setOnClickListener(v -> permLauncher.launch(intent));
        }
    }

    // ── Warning banners ───────────────────────────────────────────────────────

    private void showThermalBanner(float h) {
        tvThermalMsg.setText("🌡️  Phone heating up (" + (int)(h*100) + "% — throttle risk). "
            + "Consider a short break to cool down.");
        bannerThermal.setVisibility(View.VISIBLE);
    }

    private void hideThermalBanner() {
        if (bannerThermal != null) bannerThermal.setVisibility(View.GONE);
    }

    private void showRamBanner(long mb) {
        tvRamMsg.setText("💾  Low RAM: " + mb + " MB free. "
            + "Close background apps to keep the boost stable.");
        bannerRam.setVisibility(View.VISIBLE);
    }

    private void hideRamBanner() {
        if (bannerRam != null) bannerRam.setVisibility(View.GONE);
    }

    // Public dismiss handlers referenced by android:onClick in XML
    public void dismissThermalBanner(View v) { hideThermalBanner(); }
    public void dismissRamBanner(View v)     { hideRamBanner(); }

    // ── XOS first-launch guide ────────────────────────────────────────────────

    private void showXosGuideOnFirstLaunch() {
        if (!PermissionHelper.isXosDevice()) return;
        SharedPreferences sp = getSharedPreferences(PREFS_APP, MODE_PRIVATE);
        if (sp.getBoolean(KEY_XOS_GUIDE_SHOWN, false)) return;
        sp.edit().putBoolean(KEY_XOS_GUIDE_SHOWN, true).apply();
        mainHandler.postDelayed(() -> XosGuideDialog.showIfNeeded(this, null), 800L);
    }

    // ── Hero tweaks count ─────────────────────────────────────────────────────

    private void updateHeroTweaks() {
        if (selectedProfile == null) return;
        int n = selectedProfile.activeTweakCount();
        tvHeroTweaks.setText(n + " optimization" + (n == 1 ? "" : "s") + " active");
    }

    // ── Live stats ────────────────────────────────────────────────────────────

    private final Runnable statsRunnable = this::refreshStats;

    private void startStatsPolling() {
        statsHandler.removeCallbacks(statsRunnable);
        statsHandler.post(statsRunnable);
    }

    private void stopStatsPolling() { statsHandler.removeCallbacks(statsRunnable); }

    private void refreshStats() {
        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        tvStatRam.setText((mi.totalMem - mi.availMem) / (1024*1024)
            + " / " + mi.totalMem / (1024*1024) + " MB");

        IntentFilter f = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        Intent bat = registerReceiver(null, f);
        int lvl = bat != null ? bat.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) : -1;
        int scl = bat != null ? bat.getIntExtra(BatteryManager.EXTRA_SCALE, -1) : -1;
        tvStatBattery.setText((lvl >= 0 && scl > 0) ? ((int)(lvl*100f/scl)) + "%" : "—");
        tvStatCpu.setText((int)(100 - mi.availMem * 100.0 / mi.totalMem) + "%");

        if (isBoosting) statsHandler.postDelayed(statsRunnable, 2_000L);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private boolean getBoostServiceFlag() {
        return getSharedPreferences(BoostService.PREFS_BOOST, MODE_PRIVATE)
            .getBoolean(BoostService.KEY_IS_RUNNING, false);
    }

    private void registerBroadcasts() {
        IntentFilter f = new IntentFilter();
        f.addAction(BoostService.ACTION_STATE_CHANGED);
        f.addAction(BoostService.ACTION_THERMAL_WARNING);
        f.addAction(BoostService.ACTION_THERMAL_OK);
        f.addAction(BoostService.ACTION_RAM_WARNING);
        f.addAction(BoostService.ACTION_RAM_OK);
        LocalBroadcastManager.getInstance(this).registerReceiver(receiver, f);
    }

    private void showSettingsDialog(String title, String msg, Intent intent) {
        new AlertDialog.Builder(this).setTitle(title).setMessage(msg)
            .setPositiveButton("Open Settings", (d, w) -> permLauncher.launch(intent))
            .setNegativeButton("Cancel", null).show();
    }

    private void toast(String msg) { Toast.makeText(this, msg, Toast.LENGTH_LONG).show(); }

    private int dpToPx(int dp) {
        return (int)(dp * getResources().getDisplayMetrics().density + 0.5f);
    }
}
