package com.gamepad.overlay

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

class InputService : AccessibilityService() {

    companion object {
        @Volatile var instance: InputService? = null
    }

    override fun onServiceConnected() { super.onServiceConnected(); instance = this }
    override fun onDestroy()         { super.onDestroy();           instance = null }

    fun performTap(x: Float, y: Float, duration: Long = 60L) {
        val path   = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, duration)
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    fun performSwipe(startX: Float, startY: Float, dx: Float, dy: Float, duration: Long) {
        val path = Path().apply {
            moveTo(startX, startY); lineTo(startX + dx, startY + dy)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0L, duration.coerceAtLeast(50L))
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
}
