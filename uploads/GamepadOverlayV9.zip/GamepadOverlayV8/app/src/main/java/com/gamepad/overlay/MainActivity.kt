package com.gamepad.overlay

import android.accessibilityservice.AccessibilityServiceInfo
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.accessibility.AccessibilityManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val prefs by lazy { getSharedPreferences(OverlayService.PREFS, Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setupPermissionButtons()
        setupLaunchButtons()
        setupButtonManager()
        setupSettings()
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
        refreshButtonList()
    }

    // ── Status ────────────────────────────────────────────────────────────────

    private fun updateStatus() {
        val overlayOk = Settings.canDrawOverlays(this)
        val accessOk  = isAccessibilityServiceEnabled()
        findViewById<TextView>(R.id.tvOverlayStatus).apply {
            text = if (overlayOk) "✅  Overlay Permission: Granted" else "❌  Overlay Permission: Not Granted"
            setTextColor(if (overlayOk) 0xFF7aff9a.toInt() else 0xFFff6060.toInt())
        }
        findViewById<TextView>(R.id.tvAccessibilityStatus).apply {
            text = if (accessOk) "✅  Accessibility Service: Enabled" else "❌  Accessibility Service: Disabled"
            setTextColor(if (accessOk) 0xFF7aff9a.toInt() else 0xFFff9060.toInt())
        }
        findViewById<Button>(R.id.btnLaunchOverlay).isEnabled = overlayOk
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val am = getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        return am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .any { it.resolveInfo.serviceInfo.packageName == packageName }
    }

    // ── Permission / launch ───────────────────────────────────────────────────

    private fun setupPermissionButtons() {
        findViewById<Button>(R.id.btnOverlayPermission).setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")))
        }
        findViewById<Button>(R.id.btnAccessibility).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
    }

    private fun setupLaunchButtons() {
        findViewById<Button>(R.id.btnLaunchOverlay).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Grant overlay permission first", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val intent = Intent(this, OverlayService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
            else startService(intent)
            Toast.makeText(this, "Overlay launched — drag each button on top of the game's button!", Toast.LENGTH_LONG).show()
            moveTaskToBack(true)
        }
        findViewById<Button>(R.id.btnStopOverlay).setOnClickListener {
            stopService(Intent(this, OverlayService::class.java))
            Toast.makeText(this, "Overlay stopped", Toast.LENGTH_SHORT).show()
        }
    }

    // ── Button manager ────────────────────────────────────────────────────────

    private fun getActiveSet(): MutableSet<String> =
        (prefs.getStringSet("active_buttons", null) ?: OverlayService.DEFAULT_ACTIVE).toMutableSet()

    private fun saveActiveSet(set: Set<String>) {
        prefs.edit().putStringSet("active_buttons", set).apply()
    }

    private fun setupButtonManager() {
        // Populate add-button grid
        val grid = findViewById<LinearLayout>(R.id.addButtonGrid)
        grid.removeAllViews()
        val dp = resources.displayMetrics.density

        var row: LinearLayout? = null
        OverlayService.ALL_BUTTONS.forEachIndexed { i, def ->
            if (i % 4 == 0) {
                row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply { bottomMargin = (6 * dp).toInt() }
                }
                grid.addView(row)
            }
            val btn = Button(this).apply {
                text = def.label
                textSize = 13f
                setTextColor(Color.WHITE)
                background = android.graphics.drawable.GradientDrawable().apply {
                    shape = android.graphics.drawable.GradientDrawable.OVAL
                    setColor(def.color)
                    setStroke(2, Color.argb(100, 255, 255, 255))
                }
                val sz = (48 * dp).toInt()
                layoutParams = LinearLayout.LayoutParams(sz, sz).apply {
                    marginEnd = (6 * dp).toInt()
                }
                setOnClickListener { addButton(def.tag) }
            }
            row?.addView(btn)
        }
    }

    private fun addButton(tag: String) {
        val active = getActiveSet()
        if (tag in active) {
            Toast.makeText(this, "Already added — remove it first if you want to re-add", Toast.LENGTH_SHORT).show()
            return
        }
        active.add(tag)
        saveActiveSet(active)
        refreshOverlay()
        refreshButtonList()
        val label = OverlayService.defFor(tag)?.label ?: tag
        Toast.makeText(this, "Added $label — drag it into position on the game", Toast.LENGTH_SHORT).show()
    }

    private fun removeButton(tag: String) {
        val active = getActiveSet()
        active.remove(tag)
        saveActiveSet(active)
        refreshOverlay()
        refreshButtonList()
    }

    private fun refreshButtonList() {
        val container = findViewById<LinearLayout>(R.id.activeButtonList)
        container.removeAllViews()
        val dp = resources.displayMetrics.density
        val active = getActiveSet()

        if (active.isEmpty()) {
            val empty = TextView(this).apply {
                text = "No buttons added yet — tap the circles above to add some."
                setTextColor(0xFF888888.toInt())
                textSize = 13f
                setPadding(0, (8 * dp).toInt(), 0, 0)
            }
            container.addView(empty)
            return
        }

        // Show active buttons in defined order
        OverlayService.ALL_BUTTONS.filter { it.tag in active }.forEach { def ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    (44 * dp).toInt()
                ).apply { bottomMargin = (4 * dp).toInt() }
            }

            // Colour swatch circle
            val swatch = TextView(this).apply {
                text = def.label
                setTextColor(Color.WHITE)
                textSize = 12f
                gravity = Gravity.CENTER
                background = android.graphics.drawable.GradientDrawable().apply {
                    shape = android.graphics.drawable.GradientDrawable.OVAL
                    setColor(def.color)
                }
                val sz = (36 * dp).toInt()
                layoutParams = LinearLayout.LayoutParams(sz, sz).apply {
                    marginEnd = (12 * dp).toInt()
                }
            }

            val name = TextView(this).apply {
                text = friendlyName(def.tag)
                setTextColor(0xFFDDDDDD.toInt())
                textSize = 14f
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }

            val removeBtn = Button(this).apply {
                text = "✕"
                textSize = 13f
                setTextColor(0xFFFF8888.toInt())
                background = android.graphics.drawable.GradientDrawable().apply {
                    shape = android.graphics.drawable.GradientDrawable.RECTANGLE
                    cornerRadius = 16f * dp
                    setColor(Color.argb(80, 80, 30, 30))
                }
                val p = (6 * dp).toInt()
                setPadding(p * 2, p, p * 2, p)
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                setOnClickListener { removeButton(def.tag) }
            }

            row.addView(swatch)
            row.addView(name)
            row.addView(removeBtn)
            container.addView(row)
        }
    }

    private fun friendlyName(tag: String): String = when (tag) {
        "btn_a"     -> "A Button"
        "btn_b"     -> "B Button"
        "btn_x"     -> "X Button"
        "btn_y"     -> "Y Button"
        "btn_lb"    -> "LB  (Left Bumper)"
        "btn_rb"    -> "RB  (Right Bumper)"
        "btn_lt"    -> "LT  (Left Trigger)"
        "btn_rt"    -> "RT  (Right Trigger)"
        "btn_start" -> "Start"
        "btn_select"-> "Select"
        "dpad_up"   -> "D-Pad  ▲  Up"
        "dpad_dn"   -> "D-Pad  ▼  Down"
        "dpad_lt"   -> "D-Pad  ◄  Left"
        "dpad_rt"   -> "D-Pad  ►  Right"
        "btn_l3"    -> "L3  (Left Stick Press)"
        "btn_r3"    -> "R3  (Right Stick Press)"
        "btn_c"     -> "C Button"
        "btn_z"     -> "Z Button"
        "joy"       -> "Joystick"
        else        -> tag
    }

    // ── Settings ──────────────────────────────────────────────────────────────

    private fun setupSettings() {
        val swVib = findViewById<Switch>(R.id.swVibration)
        swVib.isChecked = prefs.getBoolean("vibration_enabled", true)
        swVib.setOnCheckedChangeListener { _, on ->
            prefs.edit().putBoolean("vibration_enabled", on).apply()
        }

        findViewById<Button>(R.id.btnResetPositions).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Reset Button Positions")
                .setMessage("Move all buttons back to their default positions?")
                .setPositiveButton("Reset") { _, _ ->
                    val edit = prefs.edit()
                    prefs.all.keys.filter { it.endsWith("_x") || it.endsWith("_y") }
                        .forEach { edit.remove(it) }
                    edit.apply()
                    refreshOverlay()
                    Toast.makeText(this, "Positions reset", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Cancel", null).show()
        }

        findViewById<Button>(R.id.btnRemoveAll).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Remove All Buttons")
                .setMessage("Remove every button from the overlay?")
                .setPositiveButton("Remove All") { _, _ ->
                    saveActiveSet(emptySet())
                    refreshOverlay()
                    refreshButtonList()
                    Toast.makeText(this, "All buttons removed", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Cancel", null).show()
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private fun refreshOverlay() {
        val intent = Intent(this, OverlayService::class.java).apply { action = "ACTION_REFRESH" }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
        else startService(intent)
    }
}
