package com.melodiq.player

import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.res.Configuration
import android.os.Handler
import android.os.Looper
import androidx.core.app.NotificationManagerCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.melodiq.MainActivity
import com.melodiq.R
import com.melodiq.crash.AppLog
import com.melodiq.overlay.FloatingLyricsOverlay
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@OptIn(UnstableApi::class)
@AndroidEntryPoint
class MusicService : MediaSessionService() {

    @Inject lateinit var floatingLyrics: FloatingLyricsOverlay
    @Inject lateinit var playerManager: PlayerManager

    private lateinit var player: ExoPlayer
    private lateinit var mediaSession: MediaSession

    private val mainHandler = Handler(Looper.getMainLooper())

    /** True once the service is shutting down, so the player events that causes are ignored. */
    private var closing = false

    override fun onCreate() {
        super.onCreate()
        AppLog.i(TAG, "onCreate")

        // The playback notification: Lyrix's own status-bar icon instead of the library's generic one.
        setMediaNotificationProvider(
            DefaultMediaNotificationProvider(this).apply { setSmallIcon(R.drawable.ic_stat_lyrix) }
        )

        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .build()

        player = ExoPlayer.Builder(this)
            .setAudioAttributes(audioAttributes, /* handleAudioFocus= */ true)
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
            .also {
                it.shuffleModeEnabled = false
                it.addListener(PlaybackLogger())
                // plays every song once per pass, never repeats one inside a pass (see the class docs)
                it.addListener(ShuffleCoordinator(it))
            }

        // "Stop" arrives when the playback notification is swiped away (and from a headset or a car): the
        // player goes idle but keeps its queue and has no error. An error also ends idle, but that must
        // not close the app, hence the check.
        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_IDLE && !closing &&
                    player.mediaItemCount > 0 && player.playerError == null
                ) {
                    AppLog.i(TAG, "playback was stopped (notification dismissed?): closing")
                    mainHandler.post { closeEverything() }
                }
            }
        })

        val sessionActivityIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        // SkippablePlayer keeps "previous" and "next" in the notification at all times (see its docs).
        // NotificationButtons adds shuffle and repeat next to them (see its docs).
        val extraButtons = NotificationButtons(player)
        mediaSession = MediaSession.Builder(this, SkippablePlayer(player))
            .setSessionActivity(sessionActivityIntent)
            .setCallback(extraButtons)
            .build()
        extraButtons.attach(mediaSession)

        // The floating lyrics window lives in this service: it is a foreground service while music
        // plays, so the window is not killed when the app is closed.
        try {
            floatingLyrics.start()
        } catch (e: Throwable) {
            AppLog.w(TAG, "floating lyrics could not start", e)
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        try {
            floatingLyrics.refreshLayout()
        } catch (e: Throwable) {
            AppLog.w(TAG, "floating lyrics could not re-layout", e)
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession = mediaSession

    override fun onTaskRemoved(rootIntent: Intent?) {
        AppLog.i(TAG, "onTaskRemoved (playWhenReady=${player.playWhenReady}, items=${player.mediaItemCount}): closing")
        // The app was swiped away from the recent apps: close everything, music and floating lyrics included.
        closeEverything()
    }

    /**
     * Ends everything at once: the floating lyrics window, the music, the notification and this service.
     *
     * [PlayerManager.release] is the step that matters. The app's own controller keeps this service
     * bound, and a bound service never stops, so stopSelf() alone left the lyrics window on screen.
     */
    private fun closeEverything() {
        if (closing) return
        closing = true
        AppLog.i(TAG, "closing: lyrics window, playback, notification")
        try {
            floatingLyrics.stop()
        } catch (e: Throwable) {
            AppLog.w(TAG, "floating lyrics could not stop", e)
        }
        try {
            player.stop()
            player.clearMediaItems()
        } catch (e: Throwable) {
            AppLog.w(TAG, "player could not stop", e)
        }
        try {
            stopForeground(Service.STOP_FOREGROUND_REMOVE)
            NotificationManagerCompat.from(this).cancel(MEDIA_NOTIFICATION_ID)
        } catch (e: Throwable) {
            AppLog.w(TAG, "notification could not be removed", e)
        }
        playerManager.release()
        stopSelf()
    }

    override fun onDestroy() {
        AppLog.i(TAG, "onDestroy")
        closing = true
        mainHandler.removeCallbacksAndMessages(null)
        try {
            floatingLyrics.stop()
        } catch (e: Throwable) {
            AppLog.w(TAG, "floating lyrics could not stop", e)
        }
        mediaSession.release()
        player.release()
        super.onDestroy()
    }

    private companion object {
        const val TAG = "MusicService"

        /** The id media3's DefaultMediaNotificationProvider gives the playback notification. */
        const val MEDIA_NOTIFICATION_ID = 1001
    }
}
