package com.hzcm.duelforge.engine

import android.content.Context
import com.hzcm.duelforge.data.CardDatabase
import com.hzcm.duelforge.data.EffectRegistry
import com.hzcm.duelforge.model.*
import com.hzcm.duelforge.model.EffectTiming

/**
 * Central orchestrator for one duel. Gameplay logic is split across this file and
 * SummonManager / BattleManager / ChainManager / AIController as extension functions
 * on [GameEngine], all operating on the shared [state].
 *
 * Long sequences (an AI turn, a chain resolving, a battle) are written in
 * continuation-passing style: every step takes an `onDone: () -> Unit` that is invoked
 * once that step (including any chain/priority resolution it triggers) is fully settled.
 * This lets a human-priority prompt pause an in-progress AI turn cleanly - the UI calls
 * [submitPriorityChoice] later, which resumes exactly where things left off.
 */
class GameEngine(context: Context) {
    val state = GameState()
    val cardDb = CardDatabase.getInstance(context)

    private var instanceCounter = 0
    private fun nextInstanceId(): String = "ci_${instanceCounter++}"

    /** Set by ChainManager when a human priority prompt is shown; resumed by submitPriorityChoice(). */
    var pendingResume: (() -> Unit)? = null

    /** Callback stored when an effect needs a human-chosen discard; called from GameViewModel.confirmDiscard(). */
    var pendingDiscardResume: ((List<CardInstance>) -> Unit)? = null

    /** Callback stored when an effect needs a human-called coin side; called from GameViewModel.callCoinToss(). */
    var pendingCoinCallResume: ((CoinSide) -> Unit)? = null

    /** Transient flag so a card's own "if destroyed by battle" Trigger effects can tell how they died. */
    var lastDestructionWasBattle: Boolean = false

    /**
     * Set to true only for the duration of computeAtk() during battle damage calculation
     * against a monster that was face-down when the attack was declared. Used by the
     * 8-Claws Scorpion continuous effect to boost ATK vs face-down defenders.
     */
    var attackingFaceDownTarget: Boolean = false

    /** The monster that won a battle (destroyed the other monster) this turn. Set for BOTH
     *  the attacking and defending side, whichever one's stat was higher. Used by effects
     *  like Absorbing Kid from the Sky ("when this card destroys a monster by battle..."). */
    var lastBattleWinner: CardInstance? = null

    /** The monster destroyed by [lastBattleWinner] in that same battle. */
    var lastBattleLoser: CardInstance? = null

    fun displayName(p: PlayerId): String = if (p == PlayerId.PLAYER) "You" else "Opponent"

    // ------------------------------------------------------------------
    // Setup
    // ------------------------------------------------------------------

    fun startGame() {
        for (player in PlayerId.entries) {
            val field = state.field(player)

            // ── Clear ALL zones so a restart from Game Over is truly fresh ──
            field.hand.clear()
            field.graveyard.clear()
            field.banished.clear()
            for (i in field.monsterZones.indices)   field.monsterZones[i]   = null
            for (i in field.spellTrapZones.indices) field.spellTrapZones[i] = null
            field.fieldZone = null

            field.deck.clear()
            field.deck.addAll(cardDb.buildMainDeck(player).map { card ->
                CardInstance(nextInstanceId(), card, player, player).also { it.location = Location.DECK }
            })
            field.deck.shuffle()

            field.extraDeck.clear()
            field.extraDeck.addAll(cardDb.buildExtraDeck(player).map { card ->
                CardInstance(nextInstanceId(), card, player, player).also { it.location = Location.EXTRA_DECK }
            })

            field.lifePoints = 8000
            field.normalSummonsUsed = 0
            field.normalSummonsAllowed = 1
            field.cannotSetCardsThisTurn = false
            field.specialSummonRestriction = null
        }

        state.turnPlayer = PlayerId.PLAYER
        state.turnCount = 1
        state.phase = Phase.DRAW
        state.gameOver = false
        state.winner = null
        state.chain.clear()
        state.log.clear()
        state.pendingHumanPriority = null
        state.pendingDiscard = null
        state.pendingCoinCall = null
        state.lastCoinFlip = null
        pendingResume = null
        pendingDiscardResume = null
        pendingCoinCallResume = null
        lastDestructionWasBattle = false
        attackingFaceDownTarget = false
        lastBattleWinner = null
        lastBattleLoser = null

        drawCards(PlayerId.PLAYER, 5)
        drawCards(PlayerId.AI, 5)

        state.addLog("=== Duel Start! You go first (no draw this turn). ===")
        advancePhase()
    }

    // ------------------------------------------------------------------
    // Zone management
    // ------------------------------------------------------------------

    fun drawCards(player: PlayerId, count: Int) {
        val field = state.field(player)
        repeat(count) {
            if (state.gameOver) return@repeat
            if (field.deck.isEmpty()) {
                state.winner = player.opponent()
                state.gameOver = true
                state.addLog("${displayName(player)} has no cards left to draw! ${displayName(player.opponent())} wins!")
                return@repeat
            }
            val card = field.deck.removeAt(0)
            card.location = Location.HAND
            card.faceUp = true
            field.hand.add(card)
        }
    }

    /** Removes [card] from whatever zone it currently occupies on its controller's field. */
    fun removeFromCurrentZone(card: CardInstance) {
        val field = state.field(card.controller)
        when (card.location) {
            Location.MONSTER_ZONE -> card.zoneIndex?.let { idx -> if (field.monsterZones[idx] === card) field.monsterZones[idx] = null }
            Location.SPELL_TRAP_ZONE -> card.zoneIndex?.let { idx -> if (field.spellTrapZones[idx] === card) field.spellTrapZones[idx] = null }
            Location.FIELD_ZONE -> if (field.fieldZone === card) field.fieldZone = null
            Location.HAND -> field.hand.remove(card)
            Location.GRAVEYARD -> field.graveyard.remove(card)
            Location.BANISHED -> field.banished.remove(card)
            Location.DECK -> field.deck.remove(card)
            Location.EXTRA_DECK -> field.extraDeck.remove(card)
        }
        card.zoneIndex = null
    }

    fun sendToGraveyard(card: CardInstance) {
        removeFromCurrentZone(card)
        card.location = Location.GRAVEYARD
        card.faceUp = true
        card.atkModifier = 0
        card.defModifier = 0
        state.field(card.controller).graveyard.add(card)
        // Cards return to their owner's GY, not the controller's (matters if control changed - not used in v1 but kept correct)
        if (card.controller != card.owner) {
            state.field(card.controller).graveyard.remove(card)
            state.field(card.owner).graveyard.add(card)
            card.controller = card.owner
        }
    }

    fun banishCard(card: CardInstance) {
        removeFromCurrentZone(card)
        card.location = Location.BANISHED
        card.faceUp = true
        state.field(card.controller).banished.add(card)
    }

    fun returnToExtraDeck(card: CardInstance) {
        removeFromCurrentZone(card)
        card.location = Location.EXTRA_DECK
        state.field(card.controller).extraDeck.add(card)
    }

    /** Returns [card] to its owner's hand from wherever it currently is (field or GY,
     *  typically). Control reverts to the owner, same as [sendToGraveyard]. */
    fun returnToHand(card: CardInstance) {
        removeFromCurrentZone(card)
        card.controller = card.owner
        card.location = Location.HAND
        card.faceUp = true
        card.atkModifier = 0
        card.defModifier = 0
        card.battlePosition = BattlePosition.ATTACK
        state.field(card.owner).hand.add(card)
    }

    /** Shuffles [card] back into its owner's Deck, on top if [toTop] else on the bottom. */
    fun returnToDeck(card: CardInstance, toTop: Boolean) {
        removeFromCurrentZone(card)
        card.controller = card.owner
        card.location = Location.DECK
        card.faceUp = true
        card.atkModifier = 0
        card.defModifier = 0
        card.battlePosition = BattlePosition.ATTACK
        val deck = state.field(card.owner).deck
        if (toTop) deck.add(0, card) else deck.add(card)
    }

    /**
     * Searches [player]'s Deck for the first card matching [predicate] and moves it to
     * their hand (a "add 1 X monster from your Deck to your hand" effect). Returns the
     * card found, or null if nothing matched - callers should log accordingly either way.
     */
    fun addFromDeckToHand(player: PlayerId, predicate: (CardInstance) -> Boolean): CardInstance? {
        val deck = state.field(player).deck
        val found = deck.firstOrNull(predicate) ?: return null
        deck.remove(found)
        found.location = Location.HAND
        found.faceUp = true
        state.field(player).hand.add(found)
        return found
    }

    /**
     * Destroys a card already on the field, sending it to the Graveyard and firing the Destroyed event.
     * [byBattle] lets the destroyed card's own "destroyed by battle" Trigger effects (if any) know
     * how they died - v1 simplification: such Trigger effects auto-resolve immediately rather
     * than joining the chain, since the card has already left the field.
     */
    fun destroyCard(card: CardInstance, byBattle: Boolean = false, onDone: () -> Unit = {}) {
        if (card.location != Location.MONSTER_ZONE &&
            card.location != Location.SPELL_TRAP_ZONE &&
            card.location != Location.FIELD_ZONE
        ) { onDone(); return }

        // Abyssal Kingshark: "Once per turn, if this card would be destroyed by an effect
        // that does not target it, it is not destroyed." v1 simplification: protects
        // against ANY non-battle destruction once per turn (drops the "does not target
        // it" nuance - the engine doesn't track whether a given destroyCard() call came
        // from a targeted effect or a board-wide sweep). Hardcoded here rather than as a
        // generic subsystem since it's currently the only card with this kind of ability.
        if (!byBattle && card.card.id == "abyssal_kingshark" &&
            !card.effectUsedThisTurn.contains("abyssal_kingshark_protect")
        ) {
            card.effectUsedThisTurn.add("abyssal_kingshark_protect")
            state.addLog("${card.card.name} isn't destroyed by that effect!")
            onDone()
            return
        }

        state.addLog("${card.card.name} is destroyed.")
        card.turnDestroyedOnField = state.turnCount
        sendToGraveyard(card)
        state.lastEvent = GameEvent.Destroyed(card)
        lastDestructionWasBattle = byBattle

        for (effect in EffectRegistry.effectsFor(card.card.id)) {
            if (effect.timing == EffectTiming.TRIGGER && effect.canActivate(this, card)) {
                state.addLog("${card.card.name}'s effect triggers: ${effect.description}")
                effect.resolve(this, card, emptyList())
            }
        }
        // Reset immediately - this flag is only meant for the just-destroyed card's own
        // "if this card is destroyed by battle" check above. Leaving it set could cause
        // a DIFFERENT surviving copy of the same card to spuriously trigger via the
        // auto-trigger loop in openPriorityWindow (called just below).
        lastDestructionWasBattle = false

        checkWinConditions()
        if (state.gameOver) { onDone(); return }
        openPriorityWindow(card.controller, onDone)
    }

    // ------------------------------------------------------------------
    // Turn / phase flow
    // ------------------------------------------------------------------

    private fun setPhase(phase: Phase) {
        state.phase = phase
        state.lastEvent = GameEvent.PhaseChanged(phase)
        state.addLog("— ${phaseLabel(phase)} —")
    }

    private fun phaseLabel(phase: Phase): String = when (phase) {
        Phase.DRAW -> "Draw Phase"
        Phase.STANDBY -> "Standby Phase"
        Phase.MAIN1 -> "Main Phase 1"
        Phase.BATTLE_START -> "Battle Phase"
        Phase.BATTLE -> "Battle Phase"
        Phase.MAIN2 -> "Main Phase 2"
        Phase.END -> "End Phase"
    }

    /**
     * Advances past the current phase. Called by the UI ("Next Phase" button) during the
     * human turn, and internally by [aiRunTurn] to step through the AI's own phases.
     *
     * [onDone] fires once the transition is fully complete. For most phases that's
     * immediate, but entering STANDBY or END opens a priority window (Standby/End-Phase
     * Trigger effects, e.g. "during each of your Standby Phases...") which can pause
     * waiting on a human response - in that case [onDone] doesn't fire until the player
     * resolves it via [submitPriorityChoice]. Callers that chain further phase
     * transitions (like [aiRunTurn]) MUST do so from inside [onDone], not after this call
     * returns, or they'll race ahead of a pending human decision.
     *
     * Only the END->endTurn() transition can hand control to the AI, so that's the only
     * place [aiRunTurn] is triggered from here - this keeps aiRunTurn's own internal
     * advancePhase() calls (for the AI's MAIN1/BATTLE/MAIN2/etc.) from recursively
     * re-triggering aiRunTurn.
     */
    fun advancePhase(onDone: () -> Unit = {}) {
        if (state.gameOver) { onDone(); return }
        if (state.chain.isNotEmpty() || state.pendingHumanPriority != null) { onDone(); return }

        when (state.phase) {
            Phase.DRAW -> {
                if (!(state.turnCount == 1 && state.turnPlayer == PlayerId.PLAYER)) {
                    drawCards(state.turnPlayer, 1)
                }
                if (state.gameOver) { onDone(); return }
                setPhase(Phase.STANDBY)
                // Gives Standby-Phase-timed Trigger effects (e.g. "during each of your
                // Standby Phases...") a chance to fire before Main Phase 1 begins.
                openPriorityWindow(state.turnPlayer) {
                    if (!state.gameOver) setPhase(Phase.MAIN1)
                    onDone()
                }
            }
            Phase.STANDBY -> { setPhase(Phase.MAIN1); onDone() }
            Phase.MAIN1 -> { setPhase(Phase.BATTLE_START); onDone() }
            Phase.BATTLE_START -> { setPhase(Phase.BATTLE); onDone() }
            Phase.BATTLE -> { setPhase(Phase.MAIN2); onDone() }
            Phase.MAIN2 -> {
                setPhase(Phase.END)
                // Gives End-Phase-timed Trigger effects (e.g. "if this card was destroyed
                // this turn, you can Special Summon it during the End Phase") a chance to fire.
                openPriorityWindow(state.turnPlayer) { onDone() }
            }
            Phase.END -> {
                endTurn()
                if (!state.gameOver && state.turnPlayer == PlayerId.AI) {
                    aiRunTurn(onDone)
                } else {
                    onDone()
                }
            }
        }
    }

    /** Cleans up end-of-turn state and switches the active player. */
    fun endTurn() {
        if (state.gameOver) return
        state.turnPlayer = state.turnPlayer.opponent()
        state.turnCount++
        state.phase = Phase.DRAW
        state.lastEvent = GameEvent.PhaseChanged(Phase.DRAW)
        // "Until the end of this turn" field-wide restrictions (e.g. Absorbing Jar's
        // "you cannot Set any cards this turn") always expire at the turn boundary.
        for (p in PlayerId.entries) {
            state.field(p).cannotSetCardsThisTurn = false
            state.field(p).specialSummonRestriction = null
        }
        for (card in state.field(state.turnPlayer).allFieldCards()) card.resetForNewTurn()
        state.field(state.turnPlayer).normalSummonsUsed = 0
        state.addLog("===== Turn ${state.turnCount}: ${displayName(state.turnPlayer)}'s turn =====")
    }

    // ------------------------------------------------------------------
    // Stat queries (incorporate continuous field-wide effects)
    // ------------------------------------------------------------------

    /**
     * Effective ATK for [card] including instance modifiers AND all CONTINUOUS field-wide
     * stat buffs. Buffs are declared entirely in EffectRegistry via [CardEffect.atkBonus] —
     * to add a new continuous ATK buff, supply an [atkBonus] lambda there; no changes here.
     */
    fun computeAtk(card: CardInstance): Int {
        var atk = card.effectiveAtk
        for (p in PlayerId.entries) {
            for (fieldCard in state.field(p).allFieldCards()) {
                if (!fieldCard.faceUp) continue
                for (effect in EffectRegistry.effectsFor(fieldCard.card.id)) {
                    if (effect.timing == EffectTiming.CONTINUOUS) {
                        atk += effect.atkBonus?.invoke(this, fieldCard, card) ?: 0
                    }
                }
            }
        }
        return atk.coerceAtLeast(0)
    }

    /**
     * Effective DEF for [card] including instance modifiers AND all CONTINUOUS field-wide
     * DEF buffs. Declare new buffs via [CardEffect.defBonus] in EffectRegistry.
     */
    fun computeDef(card: CardInstance): Int {
        var def = card.effectiveDef
        for (p in PlayerId.entries) {
            for (fieldCard in state.field(p).allFieldCards()) {
                if (!fieldCard.faceUp) continue
                for (effect in EffectRegistry.effectsFor(fieldCard.card.id)) {
                    if (effect.timing == EffectTiming.CONTINUOUS) {
                        def += effect.defBonus?.invoke(this, fieldCard, card) ?: 0
                    }
                }
            }
        }
        return def.coerceAtLeast(0)
    }

    // ------------------------------------------------------------------
    // Win conditions
    // ------------------------------------------------------------------

    fun checkWinConditions() {
        if (state.gameOver) return
        for (player in PlayerId.entries) {
            if (state.field(player).lifePoints <= 0) {
                state.gameOver = true
                state.winner = player.opponent()
                state.addLog("${displayName(player)}'s Life Points hit 0! ${displayName(player.opponent())} wins!")
            }
        }
    }
}
