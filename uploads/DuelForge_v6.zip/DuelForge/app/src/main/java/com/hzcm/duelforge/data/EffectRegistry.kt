package com.hzcm.duelforge.data

import com.hzcm.duelforge.engine.*
import com.hzcm.duelforge.model.*

/**
 * Maps a card's [Card.id] to the [CardEffect]s it has. cards.json stays pure data
 * (name/stats/image); all gameplay logic lives here. To give a card an effect:
 *  1. Set its `monsterCategory` to "EFFECT" (or leave Spells/Traps as-is) in cards.json.
 *  2. Add an entry below keyed by the card's id, with one [CardEffect] per ability.
 *
 * [CardEffect.id] (distinct from the card's id) is only used for once-per-turn tracking
 * via [CardInstance.effectUsedThisTurn] — it just needs to be unique per ability.
 *
 * ── Shared effect factories ──────────────────────────────────────────────────────────────
 * Common behaviors (draw-on-summon, gain-LP-on-flip, continuous stat buffs, etc.) are
 * implemented ONCE as private factory functions below and reused across cards. If you need
 * to fix or extend a shared behavior, change the factory — every card using it updates
 * automatically. To add a new card with "draw 1 on Normal Summon", just write:
 *   "your_card_id" to listOf(drawOnNormalSummon(1))
 */
object EffectRegistry {

    private val registry: Map<String, List<CardEffect>> = mapOf(

        // ── Ironclad Defender: FLIP - gain 1000 LP ─────────────────────────────────────
        "ironclad_defender" to listOf(
            gainLPOnFlip(1000)
        ),

        // ── Stormcaller Falcon: Trigger - draw 1 on Normal Summon ──────────────────────
        "stormcaller_falcon" to listOf(
            drawOnNormalSummon(count = 1)
        ),

        // ── Crimson War Wyrm: Ignition - halve an opponent monster's ATK until EOT ──────
        "crimson_war_wyrm" to listOf(
            CardEffect(
                id = "crimson_war_wyrm_ignition",
                timing = EffectTiming.IGNITION,
                description = "Target 1 monster your opponent controls; halve its ATK until the end of this turn.",
                oncePerTurn = true,
                canActivate = { engine, source ->
                    source.location == Location.MONSTER_ZONE && source.faceUp &&
                        engine.state.field(source.controller.opponent()).monsters().isNotEmpty()
                },
                targetSelector = { engine, source -> engine.state.field(source.controller.opponent()).monsters() },
                resolve = { engine, _, targets ->
                    targets.firstOrNull()?.let { target ->
                        val halved = engine.computeAtk(target) / 2
                        target.atkModifier -= halved
                        engine.state.addLog("${target.card.name}'s ATK is halved until the end of this turn!")
                    }
                }
            )
        ),

        // ── Tactical Reinforcement: Normal Spell - draw 2, discard 1 ───────────────────
        "tactical_reinforcement" to listOf(
            CardEffect(
                id = "tactical_reinforcement_effect",
                timing = EffectTiming.NORMAL,
                description = "Draw 2 cards, then discard 1 card.",
                canActivate = { engine, source -> engine.state.field(source.controller).deck.size >= 2 },
                resolve = { engine, source, _ ->
                    val controller = source.controller
                    engine.drawCards(controller, 2)
                    engine.requestDiscard(controller, 1, "Tactical Reinforcement: choose 1 card to discard") { discarded ->
                        engine.state.addLog("${engine.displayName(controller)} discards ${discarded.joinToString { it.card.name }}.")
                    }
                }
            )
        ),

        // ── Fusion Catalyst: Normal Spell - Fusion Summon from the Extra Deck ───────────
        "fusion_catalyst" to listOf(
            CardEffect(
                id = "fusion_catalyst_effect",
                timing = EffectTiming.NORMAL,
                description = "Fusion Summon 1 Fusion Monster from your Extra Deck using monsters you control as material.",
                canActivate = { engine, source -> engine.canFusionSummon(source.controller) },
                resolve = { engine, source, _ -> engine.performFusionSummon(source.controller) }
            )
        ),

        // ── Battlefield Overgrowth: Field Spell ────────────────────────────────────────
        // The NORMAL entry handles "activating from hand". The CONTINUOUS entry applies the
        // +200 ATK buff via GameEngine.computeAtk() — no engine code changes needed to
        // add future field-spell buffs; just supply an atkBonus lambda here.
        "battlefield_overgrowth" to listOf(
            CardEffect(
                id = "battlefield_overgrowth_activate",
                timing = EffectTiming.NORMAL,
                description = "All EARTH monsters on the field gain 200 ATK.",
                canActivate = { _, _ -> true },
                resolve = { engine, source, _ ->
                    engine.state.addLog("${engine.displayName(source.controller)}'s Field Spell empowers all EARTH monsters!")
                }
            ),
            earthAtkBuff(amount = 200)
        ),

        // ── Rapid Strike: Quick-Play Spell - grant a monster a second attack ─────────────
        "rapid_strike" to listOf(
            CardEffect(
                id = "rapid_strike_effect",
                timing = EffectTiming.QUICK,
                description = "Target 1 of your face-up Attack Position monsters that has already attacked this turn; it can attack again this Battle Phase.",
                canActivate = { engine, source -> engine.state.phase == Phase.BATTLE && rapidStrikeTargets(engine, source).isNotEmpty() },
                targetSelector = { engine, source -> rapidStrikeTargets(engine, source) },
                resolve = { engine, _, targets ->
                    targets.firstOrNull()?.let { target ->
                        target.extraAttacksAllowed += 1
                        engine.state.addLog("${target.card.name} can attack again this Battle Phase!")
                    }
                }
            )
        ),

        // ── Shield Wall: Continuous Trap - once per turn, force attacked monster to Defense
        "shield_wall" to listOf(
            CardEffect(
                id = "shield_wall_activate",
                timing = EffectTiming.QUICK,
                description = "Activate this card.",
                canActivate = { _, source -> !source.faceUp },
                resolve = { engine, source, _ ->
                    engine.state.addLog("${source.card.name} is activated and remains face-up on the field.")
                }
            ),
            CardEffect(
                id = "shield_wall_effect",
                timing = EffectTiming.QUICK,
                description = "Change the attacked monster to Defense Position.",
                oncePerTurn = true,
                canActivate = { engine, source ->
                    source.faceUp && shieldWallTarget(engine, source) != null
                },
                targetSelector = { engine, source -> listOfNotNull(shieldWallTarget(engine, source)) },
                resolve = { engine, _, targets ->
                    targets.firstOrNull()?.let { target ->
                        target.battlePosition = BattlePosition.DEFENSE
                        engine.state.addLog("${target.card.name} is switched to Defense Position!")
                    }
                }
            )
        ),

        // ── Reversal Ambush: Normal Trap - destroy the attacking monster ────────────────
        "reversal_ambush" to listOf(
            CardEffect(
                id = "reversal_ambush_effect",
                timing = EffectTiming.QUICK,
                description = "Destroy the attacking monster.",
                canActivate = { engine, source ->
                    !source.faceUp && attackingMonster(engine, source) != null
                },
                targetSelector = { engine, source -> listOfNotNull(attackingMonster(engine, source)) },
                resolve = { engine, _, targets ->
                    targets.firstOrNull()?.let { target -> engine.destroyCard(target) }
                }
            )
        ),

        // ── Negation Barrier: Counter Trap - negate and destroy a Spell/Monster Effect ──
        "negation_barrier" to listOf(
            CardEffect(
                id = "negation_barrier_effect",
                timing = EffectTiming.QUICK,
                description = "Negate the activation of a Spell Card or Monster Effect, then destroy it.",
                canActivate = { engine, source ->
                    !source.faceUp && engine.state.chain.isNotEmpty() &&
                        engine.state.chain.last().source.card.cardType != CardType.TRAP
                },
                targetSelector = { engine, _ -> listOfNotNull(engine.state.chain.lastOrNull()?.source) },
                resolve = { engine, _, targets ->
                    targets.firstOrNull()?.let { target ->
                        target.isNegated = true
                        engine.state.addLog("${target.card.name}'s activation is negated!")
                        engine.destroyCard(target)
                    }
                }
            )
        ),

        // ── Sentinel of the Sealed Gate: Quick Effect - discard to negate+destroy a Trap
        "sentinel_of_the_sealed_gate" to listOf(
            CardEffect(
                id = "sentinel_quick",
                timing = EffectTiming.QUICK,
                description = "Discard 1 card to negate the activation of a Trap Card, then destroy it.",
                oncePerTurn = true,
                canActivate = { engine, source ->
                    source.location == Location.MONSTER_ZONE && source.faceUp &&
                        engine.state.chain.isNotEmpty() &&
                        engine.state.chain.last().source.card.cardType == CardType.TRAP &&
                        engine.state.field(source.controller).hand.isNotEmpty()
                },
                targetSelector = { engine, _ -> listOfNotNull(engine.state.chain.lastOrNull()?.source) },
                payCost = { engine, source ->
                    val hand = engine.state.field(source.controller).hand
                    if (hand.isEmpty()) {
                        false
                    } else {
                        val discard = hand.last()
                        engine.sendToGraveyard(discard)
                        engine.state.addLog("${engine.displayName(source.controller)} discards ${discard.card.name}.")
                        true
                    }
                },
                resolve = { engine, _, targets ->
                    targets.firstOrNull()?.let { target ->
                        target.isNegated = true
                        engine.state.addLog("${target.card.name}'s activation is negated!")
                        engine.destroyCard(target)
                    }
                }
            )
        ),

        // ── Spark Imp: Ignition - tribute self to inflict 500 damage ───────────────────
        "spark_imp" to listOf(
            inflictDamageOnSelfTribute(damage = 500)
        ),

        // ── 3-Hump Lacooda: Ignition - tribute 2 of 3 Lacoodas to draw 3 ───────────────
        "three_hump_lacooda" to listOf(
            CardEffect(
                id = "three_hump_lacooda_ignition",
                timing = EffectTiming.IGNITION,
                description = "Tribute 2 other 3-Hump Lacoodas to draw 3 cards (need 3 face-up).",
                oncePerTurn = true,
                canActivate = { engine, source ->
                    source.location == Location.MONSTER_ZONE && source.faceUp &&
                        engine.state.field(source.controller).monsters()
                            .count { it.card.id == "three_hump_lacooda" && it.faceUp } >= 3
                },
                payCost = { engine, source ->
                    val tributes = engine.state.field(source.controller).monsters()
                        .filter { it.card.id == "three_hump_lacooda" && it.faceUp && it !== source }
                        .take(2)
                    if (tributes.size < 2) {
                        false
                    } else {
                        tributes.forEach { engine.sendToGraveyard(it) }
                        engine.state.addLog("${engine.displayName(source.controller)} tributes 2 \"3-Hump Lacooda\".")
                        true
                    }
                },
                resolve = { engine, source, _ ->
                    engine.drawCards(source.controller, 3)
                    engine.state.addLog("${engine.displayName(source.controller)} draws 3 cards!")
                }
            )
        ),

        // ── Glacier Hound: Trigger - draw 1 if destroyed by battle ─────────────────────
        "glacier_hound" to listOf(
            drawIfDestroyedByBattle(count = 1)
        ),

        // ── 8-Claws Scorpion: Ignition (once/turn flip self face-down) + Continuous ATK boost ──
        "eight_claws_scorpion" to listOf(
            CardEffect(
                id = "eight_claws_scorpion_flip_self",
                timing = EffectTiming.IGNITION,
                description = "Flip this card into face-down Defense Position.",
                oncePerTurn = true,
                canActivate = { _, source ->
                    // Extra guards beyond canActivateEffect: hasn't changed position this turn
                    !source.positionChangedThisTurn
                },
                resolve = { engine, source, _ ->
                    source.faceUp = false
                    source.battlePosition = BattlePosition.DEFENSE
                    source.positionChangedThisTurn = true
                    engine.state.addLog("${source.card.name} flips itself face-down in Defense Position.")
                }
            ),
            CardEffect(
                id = "eight_claws_scorpion_atk_boost",
                timing = EffectTiming.CONTINUOUS,
                description = "ATK becomes 2400 when attacking a face-down Defense Position monster.",
                canActivate = { _, _ -> false },
                resolve = { _, _, _ -> },
                // Only fires while GameEngine.attackingFaceDownTarget is true (set in BattleManager)
                atkBonus = { engine, source, target ->
                    if (target === source && engine.attackingFaceDownTarget)
                        (2400 - (source.card.atk ?: 300)).coerceAtLeast(0)
                    else 0
                }
            )
        ),

        // ── A Cat of Ill Omen: FLIP - place 1 Trap from Deck on top of Deck ──────────
        "a_cat_of_ill_omen" to listOf(
            CardEffect(
                id = "a_cat_of_ill_omen_flip",
                timing = EffectTiming.FLIP,
                description = "Place 1 Trap from your Deck on top of your Deck.",
                canActivate = { engine, source ->
                    engine.state.field(source.controller).deck.any { it.card.cardType == CardType.TRAP }
                },
                resolve = { engine, source, _ ->
                    val deck = engine.state.field(source.controller).deck
                    // Auto-pick first Trap found (v1 simplification - no deck-search UI)
                    val trap = deck.firstOrNull { it.card.cardType == CardType.TRAP }
                    if (trap != null) {
                        deck.remove(trap)
                        deck.add(0, trap) // place on top
                        engine.state.addLog(
                            "${engine.displayName(source.controller)} places ${trap.card.name} on top of their Deck."
                        )
                    } else {
                        engine.state.addLog("No Trap found in Deck.")
                    }
                }
            )
        ),

        // ── 4-Starred Ladybug of Doom: FLIP - destroy all Level 4 opp monsters ───────
        "four_starred_ladybug_of_doom" to listOf(
            CardEffect(
                id = "four_starred_ladybug_of_doom_flip",
                timing = EffectTiming.FLIP,
                description = "Destroy all Level 4 monsters your opponent controls.",
                canActivate = { _, _ -> true },
                resolve = { engine, source, _ ->
                    val targets = engine.state
                        .field(source.controller.opponent())
                        .monsters()
                        .filter { it.card.level == 4 }
                        .toList() // snapshot before any removal
                    if (targets.isEmpty()) {
                        engine.state.addLog("No Level 4 monsters to destroy.")
                    } else {
                        targets.forEach { target ->
                            engine.state.addLog("${target.card.name} is destroyed by 4-Starred Ladybug of Doom!")
                            engine.sendToGraveyard(target)
                        }
                        engine.checkWinConditions()
                    }
                }
            )
        ),

        // ── Absolute King Back Jack: Quick (GY) excavation + Trigger deck-peek ─────────
        // v1 simplification: reachable via the priority-response prompt (like a Trap),
        // not a tappable Graveyard browser - there's no GY-card UI yet. The deck-peek
        // trigger reveals the top 3 cards via the log but keeps their order unchanged
        // (no reorder UI yet).
        "absolute_king_back_jack" to listOf(
            CardEffect(
                id = "absolute_king_back_jack_gy_excavate",
                timing = EffectTiming.QUICK,
                description = "Banish this card from the GY; excavate the top card of your Deck - if it's a Normal Trap, Set it (activatable this turn); otherwise send it to the GY.",
                oncePerTurn = true,
                canActivate = { engine, source ->
                    source.location == Location.GRAVEYARD &&
                        source.controller != engine.state.turnPlayer &&
                        engine.state.field(source.controller).deck.isNotEmpty()
                },
                payCost = { engine, source -> engine.banishCard(source); true },
                resolve = { engine, source, _ ->
                    val controller = source.controller
                    val field = engine.state.field(controller)
                    val top = field.deck.removeAt(0)
                    if (top.card.cardType == CardType.TRAP && top.card.trapType == TrapType.NORMAL) {
                        val idx = field.firstEmptySpellTrapZone()
                        if (idx != null) {
                            top.location = Location.SPELL_TRAP_ZONE
                            top.zoneIndex = idx
                            field.spellTrapZones[idx] = top
                            top.faceUp = false
                            top.turnEnteredField = engine.state.turnCount
                            top.ignoreSetTurnRestriction = true
                            engine.state.addLog(
                                "${engine.displayName(controller)} excavates ${top.card.name} and Sets it - it can be activated this turn!"
                            )
                        } else {
                            top.location = Location.GRAVEYARD
                            field.graveyard.add(top)
                            top.faceUp = true
                            engine.state.addLog("${engine.displayName(controller)} excavates ${top.card.name}, but has no Spell/Trap Zone space - it's sent to the GY.")
                        }
                    } else {
                        top.location = Location.GRAVEYARD
                        field.graveyard.add(top)
                        top.faceUp = true
                        engine.state.addLog("${engine.displayName(controller)} excavates ${top.card.name} - not a Normal Trap, so it's sent to the GY.")
                    }
                }
            ),
            CardEffect(
                id = "absolute_king_back_jack_destroyed",
                timing = EffectTiming.TRIGGER,
                description = "If this card is destroyed and sent to the GY: look at the top 3 cards of your Deck (kept in the same order).",
                canActivate = { engine, source ->
                    engine.state.lastEvent.let { it is GameEvent.Destroyed && it.card === source }
                },
                resolve = { engine, source, _ ->
                    val deck = engine.state.field(source.controller).deck
                    val peek = deck.take(3)
                    if (peek.isEmpty()) {
                        engine.state.addLog("${source.card.name}: no cards left atop the Deck to look at.")
                    } else {
                        engine.state.addLog(
                            "${engine.displayName(source.controller)} looks at the top ${peek.size} card(s) of their Deck: " +
                            peek.joinToString { it.card.name } + "."
                        )
                    }
                }
            )
        ),

        // ── Absolute Crusader: Trigger - punish a Level 5+ Special Summon ──────────────
        // Fires for EITHER player's Special Summon (checked via lastEvent), on whichever
        // side controls a face-up copy - matches the real card's "if a Level 5+ monster(s)
        // is Special Summoned" wording (no "your opponent's" restriction).
        "absolute_crusader" to listOf(
            CardEffect(
                id = "absolute_crusader_trigger",
                timing = EffectTiming.TRIGGER,
                description = "Tribute this face-up card; destroy that Level 5+ Special Summoned monster.",
                canActivate = { engine, source ->
                    source.location == Location.MONSTER_ZONE && source.faceUp &&
                        (engine.state.lastEvent as? GameEvent.SpecialSummon)?.card?.let {
                            (it.card.level ?: 0) >= 5 && it.location == Location.MONSTER_ZONE
                        } == true
                },
                targetSelector = { engine, _ ->
                    listOfNotNull((engine.state.lastEvent as? GameEvent.SpecialSummon)?.card)
                },
                payCost = { engine, source -> engine.sendToGraveyard(source); true },
                resolve = { engine, source, targets ->
                    targets.firstOrNull()?.let { target ->
                        engine.state.addLog("${source.card.name} tributes itself to destroy ${target.card.name}!")
                        engine.destroyCard(target)
                    }
                }
            )
        ),

        // ── Abaki: Trigger - 500 damage to both players when destroyed by battle ───────
        "abaki" to listOf(
            CardEffect(
                id = "abaki_battle_destroyed",
                timing = EffectTiming.TRIGGER,
                description = "When this card is destroyed by battle, both players take 500 damage.",
                canActivate = { engine, _ -> engine.lastDestructionWasBattle },
                resolve = { engine, _, _ ->
                    val you = engine.state.field(PlayerId.PLAYER)
                    val opp = engine.state.field(PlayerId.AI)
                    you.lifePoints -= 500
                    opp.lifePoints -= 500
                    engine.state.addLog(
                        "Abaki's destruction deals 500 damage to both players! " +
                        "(Your LP: ${you.lifePoints}, Opponent LP: ${opp.lifePoints})"
                    )
                    engine.checkWinConditions()
                }
            )
        ),

        // ── A Man with Wdjat: Trigger - peek at an opponent Set card on Summon/Standby ──
        // v1 simplification: the card looked at is revealed via the log only; it's
        // physically returned to its original (still-Set, still-hidden) position exactly
        // as the real card text describes, so nothing about board state actually changes.
        "a_man_with_wdjat" to listOf(
            CardEffect(
                id = "a_man_with_wdjat_summon",
                timing = EffectTiming.TRIGGER,
                description = "Look at 1 Set card your opponent controls.",
                canActivate = { engine, source ->
                    engine.state.lastEvent.let { it is GameEvent.NormalSummon && it.card === source } &&
                        engine.state.field(source.controller.opponent()).allFieldCards().any { !it.faceUp }
                },
                resolve = { engine, source, _ -> peekOpponentSetCard(engine, source) }
            ),
            CardEffect(
                id = "a_man_with_wdjat_standby",
                timing = EffectTiming.TRIGGER,
                description = "During your Standby Phase: look at 1 Set card your opponent controls.",
                canActivate = { engine, source ->
                    engine.state.lastEvent.let { it is GameEvent.PhaseChanged && it.phase == Phase.STANDBY } &&
                        engine.state.turnPlayer == source.controller &&
                        source.location == Location.MONSTER_ZONE && source.faceUp &&
                        engine.state.field(source.controller.opponent()).allFieldCards().any { !it.faceUp }
                },
                resolve = { engine, source, _ -> peekOpponentSetCard(engine, source) }
            )
        ),

        // ── A/D Changer: Quick (GY) - banish from GY to flip a monster's battle position ─
        // v1 simplification: reachable via the priority-response prompt (like a Trap),
        // not a tappable Graveyard browser - there's no GY-card UI yet.
        "ad_changer" to listOf(
            CardEffect(
                id = "ad_changer_gy_effect",
                timing = EffectTiming.QUICK,
                description = "Banish this card from your GY; change 1 monster's battle position.",
                oncePerTurn = true,
                canActivate = { engine, source ->
                    source.location == Location.GRAVEYARD &&
                        (engine.state.field(PlayerId.PLAYER).monsters() + engine.state.field(PlayerId.AI).monsters())
                            .any { it.faceUp }
                },
                targetSelector = { engine, _ ->
                    (engine.state.field(PlayerId.PLAYER).monsters() + engine.state.field(PlayerId.AI).monsters())
                        .filter { it.faceUp }
                },
                payCost = { engine, source -> engine.banishCard(source); true },
                resolve = { engine, _, targets ->
                    targets.firstOrNull()?.let { target ->
                        target.battlePosition =
                            if (target.battlePosition == BattlePosition.ATTACK) BattlePosition.DEFENSE else BattlePosition.ATTACK
                        target.positionChangedThisTurn = true
                        engine.state.addLog("${target.card.name}'s battle position is changed!")
                    }
                }
            )
        ),

        // ── A-Team: Trap Disposal Unit: Quick - tribute self to negate an opponent Trap ─
        "a_team_trap_disposal" to listOf(
            CardEffect(
                id = "a_team_trap_disposal_negate",
                timing = EffectTiming.QUICK,
                description = "Tribute this card to negate your opponent's activated Trap Card and destroy it.",
                canActivate = { engine, source ->
                    source.location == Location.MONSTER_ZONE && source.faceUp &&
                        engine.state.chain.isNotEmpty() &&
                        engine.state.chain.last().source.card.cardType == CardType.TRAP &&
                        engine.state.chain.last().controller != source.controller
                },
                targetSelector = { engine, _ -> listOfNotNull(engine.state.chain.lastOrNull()?.source) },
                payCost = { engine, source -> engine.sendToGraveyard(source); true },
                resolve = { engine, _, targets ->
                    targets.firstOrNull()?.let { target ->
                        target.isNegated = true
                        engine.state.addLog("${target.card.name}'s activation is negated and destroyed by A-Team: Trap Disposal Unit!")
                        engine.destroyCard(target)
                    }
                }
            )
        ),

        // ── A-Assault Core: Ignition - boost a LIGHT Machine ally's ATK ─────────────────
        // v1 simplification of its original Union equip/unequip/protection ability, which
        // would need an equip-tracking + effect-immunity subsystem the engine doesn't have.
        "a_assault_core" to listOf(
            CardEffect(
                id = "a_assault_core_boost",
                timing = EffectTiming.IGNITION,
                description = "Target 1 LIGHT Machine monster you control; it gains 500 ATK until the end of this turn.",
                oncePerTurn = true,
                canActivate = { engine, source ->
                    source.location == Location.MONSTER_ZONE && source.faceUp &&
                        engine.state.field(source.controller).monsters()
                            .any { it.card.attribute == Attribute.LIGHT && it.card.race == Race.MACHINE }
                },
                targetSelector = { engine, source ->
                    engine.state.field(source.controller).monsters()
                        .filter { it.card.attribute == Attribute.LIGHT && it.card.race == Race.MACHINE }
                },
                resolve = { engine, _, targets ->
                    targets.firstOrNull()?.let { target ->
                        target.atkModifier += 500
                        engine.state.addLog("${target.card.name} gains 500 ATK until the end of this turn!")
                    }
                }
            )
        ),

        // ── Abominable Unchained Soul: revenge Special Summon + on-summon removal + ─────
        // ── End Phase revival. v1 simplification: the "place on the bottom of the Deck
        // when it leaves the field" clause on the End Phase revival isn't tracked (would
        // need a redirect hook on every removal pathway); it just leaves the field normally.
        "abominable_unchained_soul" to listOf(
            CardEffect(
                id = "abominable_unchained_soul_revenge",
                timing = EffectTiming.TRIGGER,
                description = "If a card you control is destroyed: Special Summon this card from your hand.",
                oncePerTurn = true,
                canActivate = { engine, source ->
                    source.location == Location.HAND &&
                        engine.state.field(source.controller).firstEmptyMonsterZone() != null &&
                        (engine.state.lastEvent as? GameEvent.Destroyed)?.card?.controller == source.controller
                },
                resolve = { engine, source, _ ->
                    val ok = engine.specialSummon(source, source.controller, BattlePosition.ATTACK, faceUp = true)
                    if (!ok) engine.state.addLog("${source.card.name} couldn't be Special Summoned - no room.")
                }
            ),
            CardEffect(
                id = "abominable_unchained_soul_on_summon",
                timing = EffectTiming.TRIGGER,
                description = "Discard 1 card; destroy 1 card on the field.",
                canActivate = { engine, source ->
                    source.location == Location.MONSTER_ZONE && source.faceUp &&
                        engine.state.lastEvent.let { it is GameEvent.SpecialSummon && it.card === source } &&
                        engine.state.field(source.controller).hand.isNotEmpty() &&
                        (engine.state.field(PlayerId.PLAYER).allFieldCards() + engine.state.field(PlayerId.AI).allFieldCards()).isNotEmpty()
                },
                targetSelector = { engine, _ ->
                    engine.state.field(PlayerId.PLAYER).allFieldCards() + engine.state.field(PlayerId.AI).allFieldCards()
                },
                payCost = { engine, source ->
                    val hand = engine.state.field(source.controller).hand
                    if (hand.isEmpty()) false else {
                        val discard = hand.last()
                        engine.sendToGraveyard(discard)
                        engine.state.addLog("${engine.displayName(source.controller)} discards ${discard.card.name}.")
                        true
                    }
                },
                resolve = { engine, _, targets ->
                    targets.firstOrNull()?.let { target -> engine.destroyCard(target) }
                }
            ),
            CardEffect(
                id = "abominable_unchained_soul_end_phase_revival",
                timing = EffectTiming.TRIGGER,
                description = "If destroyed and sent to the GY this turn: Special Summon it during the End Phase.",
                oncePerTurn = true,
                canActivate = { engine, source ->
                    source.location == Location.GRAVEYARD &&
                        source.turnDestroyedOnField == engine.state.turnCount &&
                        engine.state.phase == Phase.END &&
                        engine.state.field(source.controller).firstEmptyMonsterZone() != null
                },
                resolve = { engine, source, _ ->
                    val ok = engine.specialSummon(source, source.controller, BattlePosition.ATTACK, faceUp = true)
                    if (ok) engine.state.addLog("${source.card.name} rises again during the End Phase!")
                }
            )
        ),

        // ── Abare Ushioni: Ignition - coin toss for 1000 damage either way ──────────────
        "abare_ushioni" to listOf(
            CardEffect(
                id = "abare_ushioni_coin_toss",
                timing = EffectTiming.IGNITION,
                description = "Call it: Heads or Tails. Win: inflict 1000 damage to your opponent. Lose: take 1000 damage.",
                oncePerTurn = true,
                canActivate = { _, source -> source.location == Location.MONSTER_ZONE && source.faceUp },
                resolve = { engine, source, _ ->
                    val controller = source.controller
                    engine.requestCoinCall(controller, "${source.card.name}: call it - Heads or Tails?") { called ->
                        val landed = if (kotlin.random.Random.nextBoolean()) CoinSide.HEADS else CoinSide.TAILS
                        val win = called == landed
                        engine.state.lastCoinFlip = CoinFlipReveal(called, landed, win)
                        if (win) {
                            val opp = controller.opponent()
                            val field = engine.state.field(opp)
                            field.lifePoints -= 1000
                            engine.state.addLog(
                                "${source.card.name}: the coin lands on ${landed.displayName} - " +
                                "${engine.displayName(controller)} called it right! " +
                                "${engine.displayName(opp)} takes 1000 damage. (LP: ${field.lifePoints})"
                            )
                        } else {
                            val field = engine.state.field(controller)
                            field.lifePoints -= 1000
                            engine.state.addLog(
                                "${source.card.name}: the coin lands on ${landed.displayName} - " +
                                "${engine.displayName(controller)} called it wrong and takes 1000 damage! (LP: ${field.lifePoints})"
                            )
                        }
                        engine.checkWinConditions()
                    }
                }
            )
        ),

        // ── Absorbing Jar: FLIP - wipe Set Spell/Traps, draw replacements, lock Sets ─────
        "absorbing_jar" to listOf(
            CardEffect(
                id = "absorbing_jar_flip",
                timing = EffectTiming.FLIP,
                description = "Destroy all Set Spell/Trap Cards; each player draws 1 per their own card destroyed this way. No one can Set cards this turn.",
                canActivate = { _, _ -> true },
                resolve = { engine, _, _ ->
                    for (player in PlayerId.entries) {
                        val field = engine.state.field(player)
                        val setCards = field.spellsAndTraps().filter { !it.faceUp }.toList()
                        if (setCards.isNotEmpty()) {
                            setCards.forEach { engine.sendToGraveyard(it) }
                            engine.state.addLog("${engine.displayName(player)}'s ${setCards.size} Set card(s) are destroyed!")
                            engine.drawCards(player, setCards.size)
                        }
                        field.cannotSetCardsThisTurn = true
                    }
                }
            )
        ),

        // ── Absorbing Kid from the Sky: Trigger - gain LP when it destroys by battle ────
        "absorbing_kid_from_sky" to listOf(
            CardEffect(
                id = "absorbing_kid_battle_destroy_lp",
                timing = EffectTiming.TRIGGER,
                description = "When this card destroys a monster by battle: gain LP equal to its Level x 300.",
                canActivate = { engine, source -> engine.lastBattleWinner === source && engine.lastBattleLoser != null },
                resolve = { engine, source, _ ->
                    val victim = engine.lastBattleLoser
                    val level = victim?.card?.level ?: 0
                    val gain = level * 300
                    val field = engine.state.field(source.controller)
                    field.lifePoints += gain
                    engine.state.addLog(
                        "${source.card.name} destroys ${victim?.card?.name ?: "a monster"} by battle! " +
                        "${engine.displayName(source.controller)} gains $gain LP. (LP: ${field.lifePoints})"
                    )
                }
            )
        ),

        // ── Adamancipator Crystal - Dragite: Trigger - draw on Special Summon ──────────
        // v1 simplification: drops "by an Adamancipator card" qualifier (fires on any
        // Special Summon of itself) - still synergizes with Adamancipator Analyzer below.
        "adamancipator_crystal_dragite" to listOf(
            CardEffect(
                id = "adamancipator_crystal_dragite_draw",
                timing = EffectTiming.TRIGGER,
                description = "If this card is Special Summoned: draw 1 card.",
                oncePerTurn = true,
                canActivate = { engine, source ->
                    source.location == Location.MONSTER_ZONE && source.faceUp &&
                        engine.state.lastEvent.let { it is GameEvent.SpecialSummon && it.card === source }
                },
                resolve = { engine, source, _ ->
                    engine.drawCards(source.controller, 1)
                    engine.state.addLog("${source.card.name} lets ${engine.displayName(source.controller)} draw 1 card!")
                }
            )
        ),

        // ── Adamancipator Analyzer: hand Special Summon condition + excavate-and-summon ─
        "adamancipator_analyzer" to listOf(
            CardEffect(
                id = "adamancipator_analyzer_summon",
                timing = EffectTiming.TRIGGER,
                description = "If you control no monsters and your opponent controls a monster: Special Summon this card from your hand.",
                oncePerTurn = true,
                canActivate = { engine, source ->
                    source.location == Location.HAND &&
                        engine.state.field(source.controller).firstEmptyMonsterZone() != null &&
                        engine.state.field(source.controller).monsters().isEmpty() &&
                        engine.state.field(source.controller.opponent()).monsters().isNotEmpty()
                },
                resolve = { engine, source, _ ->
                    engine.specialSummon(source, source.controller, BattlePosition.ATTACK, faceUp = true)
                }
            ),
            CardEffect(
                id = "adamancipator_analyzer_excavate",
                timing = EffectTiming.IGNITION,
                description = "Excavate the top 5 cards of your Deck; Special Summon 1 excavated Level 4 or lower Rock monster, then place the rest on the bottom of your Deck.",
                oncePerTurn = true,
                canActivate = { _, source -> source.location == Location.MONSTER_ZONE && source.faceUp },
                resolve = { engine, source, _ ->
                    val field = engine.state.field(source.controller)
                    val excavated = ArrayList<CardInstance>()
                    repeat(5) { if (field.deck.isNotEmpty()) excavated.add(field.deck.removeAt(0)) }
                    if (excavated.isEmpty()) {
                        engine.state.addLog("${source.card.name}: no cards left to excavate.")
                    } else {
                        engine.state.addLog(
                            "${source.card.name} excavates: " + excavated.joinToString { it.card.name }
                        )
                        val pick = excavated.firstOrNull {
                            it.card.isMonster && it.card.race == Race.ROCK && (it.card.level ?: 99) <= 4
                        }
                        val remaining = excavated.toMutableList()
                        if (pick != null) {
                            remaining.remove(pick)
                            val summoned = engine.specialSummon(pick, source.controller, BattlePosition.ATTACK, faceUp = true)
                            if (summoned) {
                                engine.state.addLog("${source.card.name} Special Summons ${pick.card.name} from the excavated cards!")
                            } else {
                                remaining.add(0, pick)
                            }
                        }
                        field.deck.addAll(remaining)
                    }
                }
            )
        ),

        // ── Achichi @Ignister: Trigger - search a Cyberse monster on Summon ─────────────
        "achichi_at_ignister" to listOf(
            CardEffect(
                id = "achichi_at_ignister_summon",
                timing = EffectTiming.TRIGGER,
                description = "If Normal or Special Summoned: add 1 Level 4 or lower Cyberse monster from your Deck to your hand, except this card.",
                oncePerTurn = true,
                canActivate = { engine, source ->
                    source.location == Location.MONSTER_ZONE && source.faceUp &&
                        engine.state.lastEvent.let {
                            (it is GameEvent.NormalSummon && it.card === source) ||
                            (it is GameEvent.SpecialSummon && it.card === source)
                        }
                },
                resolve = { engine, source, _ ->
                    val found = engine.addFromDeckToHand(source.controller) {
                        it.card.isMonster && it.card.race == Race.CYBERSE &&
                            (it.card.level ?: 99) <= 4 && it.card.id != source.card.id
                    }
                    if (found != null) {
                        engine.state.addLog("${source.card.name} adds ${found.card.name} from the Deck to the hand!")
                    } else {
                        engine.state.addLog("${source.card.name}: no Cyberse monster found in the Deck.")
                    }
                }
            )
        ),

        // ── Abyssrhine, the Atlantean Spirit: Quick (GY) - banish + discard to draw ─────
        // v1 simplification: drops the archetype-specific (Mermail/Atlantean) tribute
        // search effect entirely - no such cards exist in this card pool.
        "abyssrhine_atlantean_spirit" to listOf(
            CardEffect(
                id = "abyssrhine_gy_draw",
                timing = EffectTiming.QUICK,
                description = "Banish this card from the GY and discard 1 card; draw 1 card.",
                oncePerTurn = true,
                canActivate = { engine, source ->
                    source.location == Location.GRAVEYARD &&
                        source.controller != engine.state.turnPlayer &&
                        engine.state.field(source.controller).hand.isNotEmpty()
                },
                payCost = { engine, source ->
                    val hand = engine.state.field(source.controller).hand
                    if (hand.isEmpty()) false else {
                        engine.banishCard(source)
                        val discard = hand.last()
                        engine.sendToGraveyard(discard)
                        engine.state.addLog("${engine.displayName(source.controller)} discards ${discard.card.name}.")
                        true
                    }
                },
                resolve = { engine, source, _ ->
                    engine.drawCards(source.controller, 1)
                    engine.state.addLog("${source.card.name}: ${engine.displayName(source.controller)} draws 1 card!")
                }
            )
        ),

        // ── Abyss Soldier: Ignition - discard a WATER monster to bounce any card ────────
        "abyss_soldier" to listOf(
            CardEffect(
                id = "abyss_soldier_bounce",
                timing = EffectTiming.IGNITION,
                description = "Discard 1 WATER monster; return 1 card on the field to the hand.",
                oncePerTurn = true,
                canActivate = { engine, source ->
                    source.location == Location.MONSTER_ZONE && source.faceUp &&
                        engine.state.field(source.controller).hand.any { it.card.isMonster && it.card.attribute == Attribute.WATER } &&
                        (engine.state.field(PlayerId.PLAYER).allFieldCards() + engine.state.field(PlayerId.AI).allFieldCards()).isNotEmpty()
                },
                targetSelector = { engine, _ ->
                    engine.state.field(PlayerId.PLAYER).allFieldCards() + engine.state.field(PlayerId.AI).allFieldCards()
                },
                payCost = { engine, source ->
                    val candidate = engine.state.field(source.controller).hand
                        .firstOrNull { it.card.isMonster && it.card.attribute == Attribute.WATER }
                    if (candidate == null) false else { engine.sendToGraveyard(candidate); true }
                },
                resolve = { engine, _, targets ->
                    targets.firstOrNull()?.let { target ->
                        engine.state.addLog("${target.card.name} is returned to the hand!")
                        engine.returnToHand(target)
                    }
                }
            )
        ),

        // ── Acorno: Ignition (hand) - discard 1 to Special Summon itself ────────────────
        // v1 simplification: the real card requires discarding a specific co-archetype
        // card ("Pinecono"), which doesn't exist in this pool - genericized to any card.
        "acorno" to listOf(
            CardEffect(
                id = "acorno_discard_summon",
                timing = EffectTiming.IGNITION,
                description = "Discard 1 card; Special Summon this card from your hand.",
                oncePerTurn = true,
                canActivate = { engine, source ->
                    source.location == Location.HAND &&
                        engine.state.field(source.controller).hand.any { it !== source } &&
                        engine.state.field(source.controller).firstEmptyMonsterZone() != null
                },
                payCost = { engine, source ->
                    val candidate = engine.state.field(source.controller).hand.firstOrNull { it !== source }
                    if (candidate == null) false else { engine.sendToGraveyard(candidate); true }
                },
                resolve = { engine, source, _ ->
                    engine.specialSummon(source, source.controller, BattlePosition.ATTACK, faceUp = true)
                }
            )
        ),

        // ── Abyss Shark: Trigger (hand) - Special Summon when your board is all WATER ───
        // v1 simplification: drops the Xyz/"Number"-monster-specific clauses entirely.
        "abyss_shark" to listOf(
            CardEffect(
                id = "abyss_shark_summon",
                timing = EffectTiming.TRIGGER,
                description = "If all your monsters are WATER: Special Summon this card from your hand, then add 1 Level 3/4/5 Fish monster from your Deck to your hand. You can only Special Summon WATER monsters for the rest of this turn.",
                oncePerTurn = true,
                canActivate = { engine, source ->
                    source.location == Location.HAND &&
                        engine.state.field(source.controller).firstEmptyMonsterZone() != null &&
                        engine.state.field(source.controller).monsters().isNotEmpty() &&
                        engine.state.field(source.controller).monsters().all { it.card.attribute == Attribute.WATER }
                },
                resolve = { engine, source, _ ->
                    val controller = source.controller
                    val ok = engine.specialSummon(source, controller, BattlePosition.ATTACK, faceUp = true)
                    if (ok) {
                        val found = engine.addFromDeckToHand(controller) {
                            it.card.isMonster && it.card.race == Race.FISH &&
                                (it.card.level ?: -1) in 3..5 && it.card.id != source.card.id
                        }
                        if (found != null) {
                            engine.state.addLog("${source.card.name} adds ${found.card.name} from the Deck to the hand!")
                        } else {
                            engine.state.addLog("${source.card.name}: no Fish monster found in the Deck.")
                        }
                        engine.state.field(controller).specialSummonRestriction = Attribute.WATER
                        engine.state.addLog("${engine.displayName(controller)} can only Special Summon WATER monsters for the rest of this turn.")
                    }
                }
            )
        ),

        // ── Achacha Chanbara: Trigger (hand) - Special Summon on any Spell/Trap/Monster ──
        // ── effect activation, either player's turn. v1 simplification: drops the
        // "will inflict damage when it resolves" qualifier (too deep an introspection
        // requirement) - fires on any activation.
        "achacha_chanbara" to listOf(
            CardEffect(
                id = "achacha_chanbara_summon",
                timing = EffectTiming.TRIGGER,
                description = "When a Spell, Trap, or Monster effect is activated (either turn): Special Summon this card from your hand; inflict 400 damage to your opponent.",
                oncePerTurn = true,
                canActivate = { engine, source ->
                    source.location == Location.HAND &&
                        engine.state.field(source.controller).firstEmptyMonsterZone() != null &&
                        engine.state.lastEvent.let {
                            it is GameEvent.SpellActivated || it is GameEvent.TrapActivated || it is GameEvent.MonsterEffectActivated
                        }
                },
                resolve = { engine, source, _ ->
                    val controller = source.controller
                    val ok = engine.specialSummon(source, controller, BattlePosition.ATTACK, faceUp = true)
                    if (ok) {
                        val opp = controller.opponent()
                        val field = engine.state.field(opp)
                        field.lifePoints -= 400
                        engine.state.addLog("${source.card.name} inflicts 400 damage to ${engine.displayName(opp)}! (LP: ${field.lifePoints})")
                        engine.checkWinConditions()
                    }
                }
            )
        ),

        // ── Absorouter Dragon: hand Special Summon condition + GY draw ──────────────────
        // v1 simplification: drops the "Rokket" archetype search entirely (replaced with
        // a plain draw) - no such cards exist in this pool.
        "absorouter_dragon" to listOf(
            CardEffect(
                id = "absorouter_dragon_summon",
                timing = EffectTiming.TRIGGER,
                description = "If you control a DARK Dragon monster other than this card: Special Summon this card from your hand.",
                oncePerTurn = true,
                canActivate = { engine, source ->
                    source.location == Location.HAND &&
                        engine.state.field(source.controller).firstEmptyMonsterZone() != null &&
                        engine.state.field(source.controller).monsters().any {
                            it.card.attribute == Attribute.DARK && it.card.race == Race.DRAGON && it.card.id != source.card.id
                        }
                },
                resolve = { engine, source, _ ->
                    engine.specialSummon(source, source.controller, BattlePosition.ATTACK, faceUp = true)
                }
            ),
            CardEffect(
                id = "absorouter_dragon_gy_draw",
                timing = EffectTiming.TRIGGER,
                description = "If this card is destroyed and sent to the GY: draw 1 card.",
                oncePerTurn = true,
                canActivate = { engine, source ->
                    engine.state.lastEvent.let { it is GameEvent.Destroyed && it.card === source }
                },
                resolve = { engine, source, _ ->
                    engine.drawCards(source.controller, 1)
                    engine.state.addLog("${source.card.name}: ${engine.displayName(source.controller)} draws 1 card!")
                }
            )
        ),

        // ── Ad Libitum of Despia: Ignition - field-wide Level-based ATK buff ────────────
        // v1 simplification: duration shortened to "until the end of this turn" (matches
        // how every other temporary buff in this engine already resets) instead of the
        // real card's "until the end of the opponent's turn," which would need a
        // different reset hook than the per-turn one atkModifier already uses. Also
        // drops the archetype-specific (Despia) Fusion-material-reuse second effect.
        "ad_libitum_of_despia" to listOf(
            CardEffect(
                id = "ad_libitum_buff",
                timing = EffectTiming.IGNITION,
                description = "All monsters on the field gain ATK equal to their Level x 100, until the end of this turn.",
                oncePerTurn = true,
                canActivate = { _, source -> source.location == Location.MONSTER_ZONE && source.faceUp },
                resolve = { engine, source, _ ->
                    val all = engine.state.field(PlayerId.PLAYER).monsters() + engine.state.field(PlayerId.AI).monsters()
                    for (m in all) {
                        m.atkModifier += (m.card.level ?: 0) * 100
                    }
                    engine.state.addLog("${source.card.name}: every monster on the field gains ATK equal to its Level x 100!")
                }
            )
        ),

        // ── Abyss Warrior: Ignition - discard a WATER monster to recycle a GY monster ───
        // v1 simplification: auto-picks "top of the Deck" instead of offering a top/bottom choice.
        "abyss_warrior" to listOf(
            CardEffect(
                id = "abyss_warrior_recycle",
                timing = EffectTiming.IGNITION,
                description = "Discard 1 WATER monster; return 1 monster in either GY to the top of the Deck.",
                oncePerTurn = true,
                canActivate = { engine, source ->
                    source.location == Location.MONSTER_ZONE && source.faceUp &&
                        engine.state.field(source.controller).hand.any { it.card.isMonster && it.card.attribute == Attribute.WATER } &&
                        (engine.state.field(PlayerId.PLAYER).graveyard + engine.state.field(PlayerId.AI).graveyard).any { it.card.isMonster }
                },
                targetSelector = { engine, _ ->
                    (engine.state.field(PlayerId.PLAYER).graveyard + engine.state.field(PlayerId.AI).graveyard)
                        .filter { it.card.isMonster }
                },
                payCost = { engine, source ->
                    val candidate = engine.state.field(source.controller).hand
                        .firstOrNull { it.card.isMonster && it.card.attribute == Attribute.WATER }
                    if (candidate == null) false else { engine.sendToGraveyard(candidate); true }
                },
                resolve = { engine, _, targets ->
                    targets.firstOrNull()?.let { target ->
                        engine.state.addLog("${target.card.name} is returned to the top of the Deck!")
                        engine.returnToDeck(target, toTop = true)
                    }
                }
            )
        ),

        // ── Achacha Archer: Trigger - damage on Normal or Flip Summon ───────────────────
        "achacha_archer" to listOf(
            CardEffect(
                id = "achacha_archer_summon",
                timing = EffectTiming.TRIGGER,
                description = "When this card is Normal or Flip Summoned: inflict 500 damage to your opponent.",
                canActivate = { engine, source ->
                    source.location == Location.MONSTER_ZONE && source.faceUp &&
                        engine.state.lastEvent.let {
                            (it is GameEvent.NormalSummon && it.card === source) ||
                            (it is GameEvent.FlipSummon && it.card === source)
                        }
                },
                resolve = { engine, source, _ ->
                    val opp = source.controller.opponent()
                    val field = engine.state.field(opp)
                    field.lifePoints -= 500
                    engine.state.addLog("${source.card.name} inflicts 500 damage to ${engine.displayName(opp)}! (LP: ${field.lifePoints})")
                    engine.checkWinConditions()
                }
            )
        )
    )

    /**
     * Shared by A Man with Wdjat's two Trigger effects: looks at one of the opponent's
     * Set cards and reveals it in the log (v1 simplification - the card is conceptually
     * "picked up and looked at" then returned to the exact same hidden position, so no
     * board state actually changes).
     */
    private fun peekOpponentSetCard(engine: GameEngine, source: CardInstance) {
        val oppField = engine.state.field(source.controller.opponent())
        val setCards = (oppField.spellsAndTraps() + oppField.monsters()).filter { !it.faceUp }
        val target = setCards.randomOrNull()
        if (target == null) {
            engine.state.addLog("${source.card.name}: opponent has no Set cards to look at.")
        } else {
            engine.state.addLog(
                "${engine.displayName(source.controller)} uses ${source.card.name} to peek at a Set card - it's ${target.card.name}!"
            )
        }
    }

    fun effectsFor(cardId: String): List<CardEffect> = registry[cardId] ?: emptyList()

    /** All card IDs that have at least one registered effect. Used by the debug screen. */
    fun allEffectCardIds(): Set<String> = registry.keys

    // ──────────────────────────────────────────────────────────────────────────────────────
    // Shared effect factories
    // Implement each common behavior ONCE here. To add a new card with an existing behavior,
    // call the factory — no other code changes needed.
    // ──────────────────────────────────────────────────────────────────────────────────────

    /** FLIP effect: controller gains [amount] Life Points. */
    private fun gainLPOnFlip(amount: Int) = CardEffect(
        id = "gain_lp_on_flip_$amount",
        timing = EffectTiming.FLIP,
        description = "Gain $amount Life Points.",
        canActivate = { _, _ -> true },
        resolve = { engine, source, _ ->
            val field = engine.state.field(source.controller)
            field.lifePoints += amount
            engine.state.addLog("${engine.displayName(source.controller)} gains $amount Life Points. (LP: ${field.lifePoints})")
        }
    )

    /** TRIGGER effect: draw [count] card(s) when this monster is Normal Summoned. */
    private fun drawOnNormalSummon(count: Int = 1) = CardEffect(
        id = "draw_on_normal_summon_$count",
        timing = EffectTiming.TRIGGER,
        description = if (count == 1) "Draw 1 card." else "Draw $count cards.",
        canActivate = { engine, source ->
            engine.state.lastEvent.let { it is GameEvent.NormalSummon && it.card === source }
        },
        resolve = { engine, source, _ ->
            engine.drawCards(source.controller, count)
            engine.state.addLog("${engine.displayName(source.controller)} draws $count card(s).")
        }
    )

    /** TRIGGER effect: draw [count] card(s) if this monster is destroyed by battle. */
    private fun drawIfDestroyedByBattle(count: Int = 1) = CardEffect(
        id = "draw_if_destroyed_by_battle_$count",
        timing = EffectTiming.TRIGGER,
        description = if (count == 1) "Draw 1 card." else "Draw $count cards.",
        canActivate = { engine, _ -> engine.lastDestructionWasBattle },
        resolve = { engine, source, _ ->
            engine.drawCards(source.controller, count)
            engine.state.addLog("${engine.displayName(source.controller)} draws $count card(s).")
        }
    )

    /**
     * IGNITION effect: tribute this monster to deal [damage] to the opponent.
     * Self-tribute is paid as cost (happens even if the effect is later negated).
     */
    private fun inflictDamageOnSelfTribute(damage: Int) = CardEffect(
        id = "inflict_damage_self_tribute_$damage",
        timing = EffectTiming.IGNITION,
        description = "Tribute this card to inflict $damage damage to your opponent.",
        canActivate = { _, source -> source.location == Location.MONSTER_ZONE && source.faceUp },
        payCost = { engine, source ->
            engine.sendToGraveyard(source)
            true
        },
        resolve = { engine, source, _ ->
            val opponent = source.controller.opponent()
            val field = engine.state.field(opponent)
            field.lifePoints -= damage
            engine.state.addLog("${engine.displayName(opponent)} takes $damage damage! (LP: ${field.lifePoints})")
            engine.checkWinConditions()
        }
    )

    /**
     * CONTINUOUS effect: all EARTH monsters on the field gain [amount] ATK.
     * No engine code changes needed — GameEngine.computeAtk() queries atkBonus automatically.
     */
    private fun earthAtkBuff(amount: Int) = CardEffect(
        id = "earth_atk_buff_continuous_$amount",
        timing = EffectTiming.CONTINUOUS,
        description = "All EARTH monsters on the field gain $amount ATK.",
        canActivate = { _, _ -> false }, // continuous effects are never "activated" via the chain
        resolve = { _, _, _ -> },
        atkBonus = { _, _, target ->
            if (target.card.attribute == Attribute.EARTH && target.location == Location.MONSTER_ZONE) amount else 0
        }
    )

    // ------------------------------------------------------------------
    // Shared target-finding helpers
    // ------------------------------------------------------------------

    /** For Rapid Strike: your face-up Attack Position monsters that attacked but have no extra attack pending. */
    private fun rapidStrikeTargets(engine: GameEngine, source: CardInstance): List<CardInstance> =
        engine.state.field(source.controller).monsters().filter {
            it.faceUp && it.battlePosition == BattlePosition.ATTACK &&
                it.hasAttackedThisTurn && it.extraAttacksAllowed <= 0
        }

    /** For Shield Wall: the monster of [source]'s controller currently being attacked, if any. */
    private fun shieldWallTarget(engine: GameEngine, source: CardInstance): CardInstance? {
        val event = engine.state.lastEvent as? GameEvent.AttackDeclared ?: return null
        val target = event.target ?: return null
        if (target.controller != source.controller) return null
        if (target.battlePosition != BattlePosition.ATTACK) return null
        if (event.attacker.controller == source.controller) return null
        return target
    }

    /** For Reversal Ambush: the opponent's monster that just declared an attack, if any. */
    private fun attackingMonster(engine: GameEngine, source: CardInstance): CardInstance? {
        val event = engine.state.lastEvent as? GameEvent.AttackDeclared ?: return null
        if (event.attacker.controller == source.controller) return null
        return event.attacker
    }
}
