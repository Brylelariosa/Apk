package com.mgba.android

// Split out of MainActivity.kt (pass 46 — "refactor main activity into
// separate classes so organized") as internal extension functions on
// MainActivity, exactly the pattern already established in SharedUi.kt's
// own top-of-file comment (Thirty-second pass) for the same reason: every
// existing unqualified call site inside MainActivity.kt (and inside every
// other split-out file) keeps compiling completely unchanged, since Kotlin
// resolves an unqualified call to an internal extension function on the
// enclosing receiver type the same way it resolves a member call — no
// behavior change, purely a file-organization move. See MainActivity.kt's
// own top-of-file comment for the full file map.

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
// BUILD FIX (pass 46): SaveEntry is an `inner class` of MainActivity (see
// MainActivity.kt's FILE MAP comment for why it stays nested, unlike
// LayoutEntry/SlotInfo/etc. — moved to MainActivityShared.kt this same
// pass), so its bare type name needs this import to resolve inside an
// extension-function file. Constructing it still needs an explicit `this.`
// receiver below — an import only makes the *type name* resolve, an inner
// class's constructor separately needs its outer instance provided
// explicitly, so every `SaveEntry(...)` call below reads `this.SaveEntry(...)`.
import com.mgba.android.MainActivity.SaveEntry
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.text.InputType
import android.text.TextUtils
import android.text.format.DateFormat
import android.util.Log
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.Closeable
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.io.PrintWriter
import java.io.StringWriter
import java.util.concurrent.atomic.AtomicInteger
import java.util.zip.ZipInputStream
import kotlin.math.abs
import kotlin.math.roundToInt


internal fun MainActivity.savesDir():  File = File(filesDir, "saves").apply  { mkdirs() }

internal fun MainActivity.statesDir(): File = File(filesDir, "states").apply { mkdirs() }


/** Path for the cartridge's battery save (SRAM/Flash/EEPROM), in this
 *  app's own internal storage — the ONLY location before this feature
 *  existed, and still the fallback location: see SaveEntry below for
 *  where a save/state/screenshot actually ends up once a Storage
 *  folder has been chosen. */
internal fun MainActivity.batterySaveFile(baseName: String): File =
    File(savesDir(), "$baseName.sav")


/** Legacy path for save-state slot [slot] (1-based). See batterySaveFile
 *  above re: "legacy". */
internal fun MainActivity.stateSlotFile(slot: Int): File =
    File(statesDir(), "$currentRomBaseName.state$slot")


/**
 * Legacy path for save-state slot [slot]'s thumbnail PNG, sitting next
 * to the state file itself (same dir, same base name, `.png`
 * appended). Written by [captureStateThumbnail] right after a
 * successful save; simply absent for an empty slot, or for a slot
 * saved before this feature existed — both cases are handled the same
 * way by [showSaveStateSlotDialog].
 */
internal fun MainActivity.stateThumbFile(slot: Int): File =
    File(statesDir(), "$currentRomBaseName.state$slot.png")


/** Legacy path for the dedicated "quick save" slot — separate from the
 *  numbered Slot 1..SAVE_STATE_SLOTS files above, so a tap on the
 *  on-screen Quick Save/Quick Load buttons (see actionButtonAt/
 *  triggerActionButton) never collides with, or gets confused for, a
 *  save the user deliberately put in one of the numbered slots via
 *  showSaveStateSlotDialog().
 *
 *  FIX (direct report: "make a slot for quick save slot ... idk did it
 *  really save because there no quicksave slot so i can't check"): this
 *  used to have no thumbnail and never appeared in showSaveStateSlotDialog()
 *  at all — by design, per the old version of this comment — which was
 *  exactly the gap behind that report: a one-tap quick save with no way
 *  to ever see whether it actually landed. It's now SlotKind.QuickSave,
 *  shown in that same dialog alongside the numbered slots and Autosave —
 *  see quickThumbFile() right below and SlotKind's own doc comment. */
internal fun MainActivity.quickStateFile(): File =
    File(statesDir(), "$currentRomBaseName.quicksave")


/** Thumbnail sibling for quickStateFile() above — added alongside
 *  SlotKind.QuickSave becoming a real, visible row in
 *  showSaveStateSlotDialog(); see quickStateFile()'s own comment. */
internal fun MainActivity.quickThumbFile(): File =
    File(statesDir(), "$currentRomBaseName.quicksave.png")


/** Dedicated "Autosave" slot — written automatically on exit and read
 *  automatically on start when the Misc → Auto Save & Load setting is
 *  on (see onPause()/loadRomFromUri(), and autoSaveLoadEnabled's own
 *  field comment). A separate file from quickStateFile() above so the
 *  automatic save can never silently overwrite a deliberate one-tap
 *  Quick Save, or vice versa — same reasoning quickStateFile()'s own
 *  comment already gives for keeping it separate from the numbered
 *  slots. Shown in showSaveStateSlotDialog() as SlotKind.Autosave. */
internal fun MainActivity.autoStateFile(): File =
    File(statesDir(), "$currentRomBaseName.autosave")


/** Thumbnail sibling for autoStateFile() above. */
internal fun MainActivity.autoThumbFile(): File =
    File(statesDir(), "$currentRomBaseName.autosave.png")


// ── FEATURE: Storage folder (saves/states/screenshots outside app data) ──
//
// Everything above this comment is untouched from before this feature
// existed, and stays the fallback: someone who never opens Settings →
// Storage sees exactly the same behavior as always, saves included.
//
// What's new: PREF_DATA_FOLDER_URI, set via showStorageSettings() below,
// points at a folder the user picked with the system folder-picker
// (SAF's OpenDocumentTree, via dataFolderPicker below — the ROM
// browser used this same mechanism too until this pass, see
// CHANGELOG.md/FILE_CHANGES.md's free-roam-file-manager entry for why
// it moved to plain java.io.File instead; this feature has a
// different tradeoff, see dataFolderPicker's own comment, and keeps
// the SAF tree it already had). Once set, THREE
// subfolders inside it — "save", "cheat", "screenshot" — hold
// everything that used to live under this app's own internal storage:
// battery saves and every save-state/thumbnail/quicksave under "save"
// (there's only one user-facing "Save" action even though this app
// internally has both battery saves and save-states, so they share one
// folder rather than splitting a distinction the user never asked
// for), "cheat" sits ready and empty for whenever a cheat-file feature
// exists (see MainActivity's own "Cheats — not implemented yet" row —
// this doesn't add that feature, just gives it somewhere to write once
// it exists), and "screenshot" replaces the old
// getExternalFilesDir()/Screenshots location (see saveScreenshotBitmap
// further down).
//
// Deliberately still SAF, not MANAGE_EXTERNAL_STORAGE (the ROM browser's
// own choice as of Thirty-second pass — see RomBrowserActivity.kt's
// top-of-file comment): this feature only ever needs ONE folder, picked
// once, with no reason to ever browse elsewhere afterward — exactly what
// SAF's OpenDocumentTree is for. No scary system permission dialog for
// something this occasional, no Play Store policy risk, works
// identically across Android versions. The ROM browser needed the
// broader permission specifically because free navigation *anywhere*
// was the actual feature being asked for there — a different
// requirement this one doesn't share, not a reason to switch this one
// too just because that one did. The one wrinkle specific to
// *this* feature: nativeSaveState()/nativeLoadState()/nativeLoadROM()'s
// save path all expect a plain fopen()-able path string (they hand it
// straight to mGBA's VFileOpen — see mgba_jni.c), and a SAF document's
// content:// URI is not one.
//
// FIX (Twenty-first pass): the previous pass bridged that gap via
// /proc/self/fd/<N> — reopening a ParcelFileDescriptor's fd as a plain
// path and handing THAT straight to native VFileOpen, including for the
// battery save, which the core mmaps for the entire session. That was
// flagged in KNOWN_LIMITATIONS.md as unconfirmed on a real device, and a
// real-device test this pass showed it doesn't hold up — the reported
// symptom was exactly "doesn't save and load" once a Storage folder was
// in use. Root cause: nothing forces a re-opened SAF fd to support
// mmap/seek/O_TRUNC the way native VFileOpen needs, and that support is
// provider-specific, not guaranteed by the framework.
//
// Replaced with a strictly simpler scheme native code can't get wrong:
// native NEVER touches a SAF document directly. It always fopen()s a
// plain file under this app's own internal storage — exactly as it did
// before this feature existed — and Kotlin copies bytes to/from the
// chosen folder's document on either side of that call, using
// ContentResolver's stream APIs, which every DocumentsProvider is
// required to support (unlike mmap/seek/truncate through a re-opened
// descriptor). See SaveEntry.stageForRead()/stageForWrite()/
// commitWrite() for the one-shot save-state/thumbnail case, and
// batteryMirrorPath()/syncBatteryMirror() for the session-long battery
// save. Slightly more I/O (a copy instead of a direct mmap), never
// measurable next to a save file's actual size (a few KB to maybe a few
// hundred KB), in exchange for not depending on undocumented provider
// behavior for the one thing this feature actually has to get right.
//
// No migration: switching to a folder here does NOT move whatever
// already exists under internal storage — only new saves/states/
// screenshots go to the new location from that point on. Doing that
// move automatically would mean silently rewriting or deleting a
// user's actual game-save data with no real device available anywhere
// in this project's history to verify it against — see
// KNOWN_LIMITATIONS.md. showStorageSettings() says this plainly before
// anyone taps "Choose folder".

/** The user's chosen Storage folder, or null if none has been picked
 *  (the default — see the block comment above) or the app's
 *  permission for it is no longer valid (folder deleted/moved outside
 *  the app, permission revoked in system Settings, etc.) — in which
 *  case every SaveEntry below transparently falls back to its legacy
 *  internal-storage path, same as if nothing had ever been picked. */
internal fun MainActivity.dataFolderTree(): DocumentFile? {
    val uriStr = getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(PREF_DATA_FOLDER_URI, null)
        ?: return null
    return try {
        val uri = Uri.parse(uriStr)
        val stillGranted = contentResolver.persistedUriPermissions.any {
            it.uri == uri && it.isReadPermission && it.isWritePermission
        }
        if (!stillGranted) return null
        DocumentFile.fromTreeUri(this, uri)?.takeIf { it.exists() && it.canWrite() }
    } catch (e: Exception) {
        Log.w(TAG, "dataFolderTree() unusable, falling back to internal storage", e)
        null
    }
}


/** Gets-or-creates one of the three fixed subfolders ("save", "cheat",
 *  "screenshot") inside the chosen Storage folder. Null if no folder is
 *  configured, or if creating the subfolder failed for any reason. */
internal fun MainActivity.dataSubfolder(name: String): DocumentFile? {
    val root = dataFolderTree() ?: return null
    return try {
        root.findFile(name)?.takeIf { it.isDirectory } ?: root.createDirectory(name)
    } catch (e: Exception) {
        Log.w(TAG, "dataSubfolder($name) failed", e)
        null
    }
}


// ── FEATURE (pass 43): automatic own-folder mirror ────────────────────
//
// Everything above (dataFolderTree()/dataSubfolder()/SaveEntry below) is
// opt-in — nothing leaves this app's internal storage unless someone
// actually visits Settings → Storage and picks a folder through the SAF
// tree picker. Two direct reports this pass point at the same gap: this
// app's own control layout resetting when its cache is cleared (see
// exportLayoutBackup()/importLayoutBackupIfNeeded() near
// saveCustomLayout()/loadCustomLayout() — loadCustomLayout() itself is
// already untouched, it just had nothing durable outside this app's own
// storage to fall back to), and a request for "its own folder, like My
// Boy" — one obvious place saves/screenshots/layout always live, with no
// setup trip required first the way the SAF picker above needs.
//
// This adds exactly that, without touching anything above: an automatic
// mirror folder — Android/data/<pkg>/files/mGBA, entirely inside this
// app's own external-files directory — created and kept in sync with NO
// permission prompt and NO Settings visit, the same zero-permission
// location screenshots already fell back to before this pass (see
// saveScreenshotBitmap()'s "Legacy/fallback location" branch, now
// nested one level deeper under this same root instead of sitting bare
// under getExternalFilesDir()). It's always a MIRROR, never the only
// copy: native save/state I/O still goes exactly where it always has
// (SaveEntry's own [legacy], savesDir()/statesDir(), all untouched by
// this feature) — this only ever copies bytes outward, best-effort,
// after a write is already known to have succeeded, the same
// "never risk the real save" discipline commitWrite()/
// syncBatteryMirror() below already follow for the SAF case.
//
// Steps aside entirely once a Storage folder IS configured
// (autoFolderMirrorActive() below) rather than keeping a second, less
// visible copy next to a folder someone deliberately picked — one
// visible "own folder" at a time, not two silently disagreeing ones.
// Same reasoning extends to layout: exportLayoutBackup() only ever
// writes into THIS folder, never into a chosen SAF one, since the SAF
// side of this feature (dataSubfolder()'s fixed save/cheat/screenshot
// set) was never extended to a 4th "layout" case and doesn't need to be
// for what this pass's report actually asked for.

/** True once the person has explicitly chosen a Storage folder above —
 *  see dataFolderTree(). The automatic mirror below only ever runs when
 *  this is false: a folder that was deliberately picked already IS this
 *  app's "own folder" going forward. */
internal fun MainActivity.autoFolderMirrorActive(): Boolean = dataFolderTree() == null


/** Root of the automatic own-folder mirror. Lives at the top level of
 *  shared storage — /storage/emulated/0/mGBA, a sibling of /Android,
 *  not a folder inside it — matching the "like my boy emulator" ask
 *  this feature's own direct report already named, and matching this
 *  app's own free-roam file manager's storage model too (see
 *  RomBrowserActivity's own deviceRoot).
 *
 *  FIX (this pass — direct report: "not on Android data its hard to
 *  access... make it like myboy the folder is on same level as
 *  android folder not inside"): the previous pass's own version of
 *  this feature put this folder at getExternalFilesDir()/mGBA —
 *  Android/data/<pkg>/files/mGBA — which technically needs no
 *  permission at all, but is exactly the "hard to access" location
 *  this was supposed to be an alternative to: Android 11+ hides
 *  Android/data from every normal file manager (this app's own
 *  RomBrowserActivity included — it can no longer browse into its own
 *  package's Android/data on API 30+), so the previous fix solved
 *  "does the app make its own folder" without actually solving
 *  "...that a person can find". A genuinely top-level folder needs the
 *  same broad storage permission RomBrowserActivity's free-roam
 *  browsing already needs (MANAGE_EXTERNAL_STORAGE on API 30+,
 *  READ_EXTERNAL_STORAGE below that — see hasBroadFileAccess() in
 *  SharedUi.kt) — this only ever attempts the top-level path once
 *  that's actually granted, and falls back to the old zero-permission
 *  Android/data location otherwise, so a save/screenshot/layout mirror
 *  is never the reason someone hits a permission prompt they haven't
 *  already seen. In practice that permission is very rarely still
 *  ungranted by the time this matters: changeRom() (onCreate, below)
 *  sends every fresh install straight into RomBrowserActivity, whose
 *  own onCreate() already asks for exactly this permission before a
 *  ROM can even be picked — long before there's anything to mirror.
 *
 *  Null only in the genuinely rare case external storage isn't
 *  currently available at all (removable/unmounted, mid-swap, etc.) —
 *  every caller below already treats that as "skip this sync, there'll
 *  be another chance" rather than a hard failure, the same spirit as a
 *  failed SAF copy elsewhere in this feature. */
internal fun MainActivity.autoFolderRoot(): File? {
    val base = if (hasBroadFileAccess()) Environment.getExternalStorageDirectory()
               else getExternalFilesDir(null)
    return base?.let { File(it, "mGBA") }
}


/** Gets-or-creates one of this mirror's named subfolders — "Saves",
 *  "Screenshots", "Layout" — mirroring dataSubfolder()'s role for the
 *  SAF side just above. */
internal fun MainActivity.autoMirrorSubdir(name: String): File? =
    autoFolderRoot()?.let { File(it, name).apply { mkdirs() } }


internal fun MainActivity.batterySaveEntry(baseName: String): SaveEntry = this.SaveEntry(batterySaveFile(baseName), "save")

internal fun MainActivity.stateSlotEntry(slot: Int): SaveEntry = this.SaveEntry(stateSlotFile(slot), "save")

internal fun MainActivity.stateThumbEntry(slot: Int): SaveEntry = this.SaveEntry(stateThumbFile(slot), "save")

internal fun MainActivity.quickStateEntry(): SaveEntry = this.SaveEntry(quickStateFile(), "save")

internal fun MainActivity.quickThumbEntry(): SaveEntry = this.SaveEntry(quickThumbFile(), "save")

internal fun MainActivity.autoStateEntry(): SaveEntry = this.SaveEntry(autoStateFile(), "save")

internal fun MainActivity.autoThumbEntry(): SaveEntry = this.SaveEntry(autoThumbFile(), "save")


/** Single dispatch point from a SlotKind (see its own doc comment,
 *  near SlotInfo) to the SaveEntry that actually holds its state
 *  bytes — showSaveStateSlotDialog()'s save/load flow and
 *  captureStateThumbnail() both go through this instead of each
 *  separately switching on Numbered/QuickSave/Autosave. */
internal fun MainActivity.stateEntryFor(kind: SlotKind): SaveEntry = when (kind) {
    SlotKind.QuickSave -> quickStateEntry()
    SlotKind.Autosave -> autoStateEntry()
    is SlotKind.Numbered -> stateSlotEntry(kind.slot)
}


/** Same dispatch as stateEntryFor() above, for the thumbnail sibling. */
internal fun MainActivity.stateThumbEntryFor(kind: SlotKind): SaveEntry = when (kind) {
    SlotKind.QuickSave -> quickThumbEntry()
    SlotKind.Autosave -> autoThumbEntry()
    is SlotKind.Numbered -> stateThumbEntry(kind.slot)
}


internal fun MainActivity.quickSaveState() {
    // FIX (direct ask: remove the Quick Save/Load/Screenshot popups):
    // every uiToast() in this function is gone — both guard-clause
    // toasts below and the save-result toast that used to sit where
    // the FEATURE comment now starts. Every branch still returns/
    // aborts exactly where it did before; saveStateBusy's own
    // compareAndSet guard and the actual save/thumbnail calls are
    // byte-for-byte unchanged.
    if (!romLoaded) { return }
    if (!saveStateBusy.compareAndSet(false, true)) {
        return
    }
    val entry = quickStateEntry()
    // Off the UI thread — same reasoning as showSaveStateSlotDialog's
    // Thread below: touches disk and briefly holds the native core's
    // mutex against the running game thread.
    Thread {
        try {
            backupIfExists(entry)
            val localPath = entry.stageForWrite()
            val ok = EmulatorEngine.nativeSaveState(localPath)
            // FIX (save-state reliability pass): `ok` used to be treated
            // as the whole save's success/failure — commitWrite() was
            // Unit, called and its result ignored. It now reports whether
            // the write actually landed (the crash-safe rename for local
            // storage, or the SAF copy), so that's what mirrorToAutoFolder()
            // and the thumbnail below are gated on instead. A native write
            // that reported failure discards its now-useless temp file
            // rather than leaving it behind.
            val committed = if (ok) entry.commitWrite(localPath) else {
                entry.discardWrite(localPath)
                false
            }
            if (committed) {
                entry.mirrorToAutoFolder()
                // FEATURE (direct report: "make a slot for quick save
                // slot... idk did it really save because there no
                // quicksave slot so i can't check"): Quick Save now shows
                // up in showSaveStateSlotDialog() as SlotKind.QuickSave,
                // same as any numbered slot — this keeps its thumbnail
                // current there too, exactly like a save made through
                // that dialog already does, so a one-tap Quick Save is
                // just as checkable as one made through the slot list.
                captureStateThumbnail(SlotKind.QuickSave)
            }
        } finally {
            saveStateBusy.set(false)
        }
    }.apply { name = "mGBA-quicksave" }.start()
}


internal fun MainActivity.quickLoadState() {
    // FIX (direct ask: remove the Quick Save/Load/Screenshot popups):
    // same change as quickSaveState() above — every uiToast() in this
    // function removed (both guards, "No quick save yet", and the
    // load-result toast), every return/abort path unchanged. `ok`
    // below is unused after this — left in place rather than also
    // restructuring the load call itself, so this stays a pure
    // notification removal; still runs nativeLoadState() exactly as
    // before via the same short-circuited `&&`.
    if (!romLoaded) { return }
    if (!saveStateBusy.compareAndSet(false, true)) {
        return
    }
    val entry = quickStateEntry()
    // FIX (lag pass): entry.exists() used to run right here, on the UI
    // thread, before ever spawning a background thread — the same
    // SAF-round-trip cost as showSaveStateSlotDialog's old exists()
    // calls, just once instead of a dozen. Moved inside the thread
    // below so a slow/SAF-backed check can't stall the UI either.
    Thread {
        try {
            if (!entry.exists()) { return@Thread }
            val localPath = entry.stageForRead()
            val ok = localPath != null && EmulatorEngine.nativeLoadState(localPath)
        } finally {
            saveStateBusy.set(false)
        }
    }.apply { name = "mGBA-quickload" }.start()
}


/**
 * FEATURE: auto save backup. Copies [entry] to its sibling
 * [SaveEntry.backupEntry] — same folder [entry] itself resolves to,
 * legacy internal storage or the chosen Storage folder alike — if it
 * already exists, right before it's about to be overwritten: the
 * battery save is re-opened read/write and mmap'd by the native core
 * on every ROM load (see nativeLoadROM), and a save-state slot is
 * truncated the instant "Save State" is tapped (see nativeSaveState/
 * showSaveStateSlotDialog). Best-effort and silent: a backup failure
 * must never block the actual save, so any exception here is only
 * logged, never surfaced to the user.
 *
 * This is a single rolling backup, not a history — each new backup
 * replaces the last. It's a one-level rollback if the current session's
 * save turns out to be corrupt (app killed mid-write, storage fills up,
 * a bad ROM stomps save memory it shouldn't, etc.), not a substitute
 * for the user making their own backups of anything precious. There is
 * currently no in-app "restore from backup" UI — see KNOWN_LIMITATIONS.md.
 */
internal fun MainActivity.backupIfExists(entry: SaveEntry) {
    if (!entry.exists()) return
    try {
        entry.moveInto(entry.backupEntry())
    } catch (e: Exception) {
        Log.w(TAG, "Backup failed (continuing without one)", e)
    }
}

