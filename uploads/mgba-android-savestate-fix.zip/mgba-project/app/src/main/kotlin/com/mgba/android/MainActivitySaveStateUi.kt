package com.mgba.android

// Split out of MainActivity.kt (pass 46 — "refactor main activity into
// separate classes so organized") as internal extension functions on
// MainActivity, exactly the pattern already established in SharedUi.kt's
// own top-of-file comment (Thirty-second pass) for the same reason: every
// existing unqualified call site inside MainActivity.kt (and inside every
// other split-out file) keeps compiling completely unchanged, since Kotlin
// resolves an unqualified call to an internal extension function on the
// enclosing receiver type the same way it resolves a member call — no
// behavior change, purely a file-organization move. See MainActivity.kt's
// own top-of-file comment for the full file map.

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.text.InputType
import android.text.TextUtils
import android.text.format.DateFormat
import android.util.Log
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.Closeable
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.io.PrintWriter
import java.io.StringWriter
import java.util.concurrent.atomic.AtomicInteger
import java.util.zip.ZipInputStream
import kotlin.math.abs
import kotlin.math.roundToInt


// ── Save states ──────────────────────────────────────────────────────
// Independent of the automatic battery save (see romPicker/nativeLoadROM)
// — that persists whatever the *game itself* lets you save; these are
// full emulator snapshots that let you resume from any exact moment,
// GBA-hardware-save-menu or not. SAVE_STATE_SLOTS per-ROM slots, each a
// plain file under statesDir(), named/keyed by currentRomBaseName so
// switching ROMs never shows another game's slots.

internal fun MainActivity.showSaveStateMenu() {
    if (!romLoaded) { return }
    AlertDialog.Builder(this)
        .setTitle("Save States")
        .setItems(arrayOf("Save State", "Load State")) { _, which ->
            showSaveStateSlotDialog(forSave = which == 0)
        }
        .setNegativeButton("Cancel", null)
        .show()
}


// ── Save-state thumbnails ────────────────────────────────────────────
// FEATURE: new. Shares captureGameFrameBitmap() with takeScreenshot()
// (see that function's own "── Screenshot ──" comment above it)
// instead of a second, independent PixelCopy/CountDownLatch capture —
// this pass's own change; see captureGameFrameBitmap()'s own doc
// comment for why plain PixelCopy-and-crop, used by both call sites
// through last pass, still isn't enough on its own.

/** Returns a fresh, controls-free copy of the currently displayed game
 *  frame, scaled to [targetW]x[targetH]. Copies directly from the raw
 *  emulator framebuffer (frameBuffers[displayIdx]) instead of
 *  PixelCopy-ing the SurfaceView, so the result can never contain an
 *  on-screen button — not just the ones outside gameScreenRect that
 *  cropToGameScreen() (deleted this pass) could already exclude, but
 *  ones dragged on top of the game image too, and *every* button at
 *  once under Stretch to Fit, where gameScreenRect is the full screen
 *  and a crop to it was always a no-op.
 *
 *  FIX (direct report, after cropToGameScreen()'s own fix last pass:
 *  "the png on save still capture button on game screen it should be
 *  only game screen no button even if there one on game screen"):
 *  cropToGameScreen() only ever removed a button whose bounding box
 *  fell entirely *outside* gameScreenRect — anything the layout
 *  editor let you drag on top of the game area stayed in the cropped
 *  result, because renderFrame() draws buttons onto the exact same
 *  Canvas as the game image, with no controls-free surface left
 *  afterward for any crop to recover (see renderFrame()'s own body —
 *  still exactly why, cropToGameScreen()'s own doc comment was right
 *  about that part). Reading frameBuffers[displayIdx] directly
 *  sidesteps the problem instead of narrowing it: drawControls() is
 *  simply never called on this bitmap, so there is no button pixel to
 *  crop out in the first place, regardless of where any button sits.
 *
 *  Safe to call from any thread. The actual pixel copy runs inside
 *  bufferLock — the same lock doFrame() and the game thread's own
 *  readyIdx/writeIdx publish (both above) already synchronize on.
 *  Without that, a screenshot/thumbnail taken at just the wrong
 *  moment could start reading a buffer the instant before the game
 *  thread picks that same index as its next writeIdx and starts
 *  drawing a new frame into it underneath the read — Bitmap isn't
 *  documented as safe for that kind of concurrent read/write. Holding
 *  bufferLock only for the copy itself (a small, fixed-size bitmap —
 *  not the scale below, which runs after the lock is released) blocks
 *  the game thread's own publish step for as long as that copy takes:
 *  a small, one-off cost on a deliberate user action, the same trade
 *  saveCustomLayout()'s own commit() fix already accepts elsewhere in
 *  this file, not a per-frame one.
 *
 *  Returns null if no frame has been rendered yet. */
internal fun MainActivity.captureGameFrameBitmap(targetW: Int, targetH: Int): Bitmap? {
    val bufs = frameBuffers ?: return null
    val raw = synchronized(bufferLock) {
        val idx = displayIdx
        if (idx == -1) null else bufs[idx].copy(Bitmap.Config.ARGB_8888, false)
    } ?: return null
    if (targetW <= 0 || targetH <= 0) return raw
    return Bitmap.createScaledBitmap(raw, targetW, targetH, linearFilterEnabled)
}


/** High-frequency, zero-(steady-state)-allocation sibling of
 *  captureGameFrameBitmap() above, purpose-built for
 *  GameScreenRecorder's capture loop (20-30+ calls/sec for the
 *  duration of a recording) rather than that function's occasional,
 *  one-shot callers (a screenshot tap, a save-state thumbnail), which
 *  still use the original and still get their own independent Bitmap
 *  each time, unchanged.
 *
 *  FIX (contributing cause of a direct report: recorded audio
 *  "disappear[s] sometimes" — see GameScreenRecorder.feedAudio()'s own
 *  fix for the actual failure mechanism, but this is very likely what
 *  was triggering it in practice): captureGameFrameBitmap() does two
 *  fresh allocations per call — bufs[idx].copy() for the raw
 *  framebuffer, then createScaledBitmap() for the actual ~1.4MB
 *  720x480 result — which is a non-issue for an occasional
 *  user-triggered capture but, called on every single recorded frame,
 *  is ~1.4MB+ of garbage roughly every 33-50ms for as long as a
 *  recording runs (GameScreenRecorder's own class doc already flagged
 *  this tradeoff and kept VIDEO_FPS low specifically because of it).
 *  That steady churn is a plausible source of GC pauses long enough,
 *  back to back, to let feedAudio()'s dequeueInputBuffer() fail
 *  several times in a row — which is what actually wedges the audio
 *  encoder; see that function's doc comment for the mechanism. Cutting
 *  the churn off at its source, rather than only surviving it, is the
 *  more direct fix, and it's also what makes raising VIDEO_FPS back up
 *  affordable.
 *
 *  Draws the raw framebuffer directly onto [dest] via
 *  Canvas.drawBitmap()'s own src-rect-to-dst-rect scaling — the same
 *  scale createScaledBitmap() did, just performed as a blit into
 *  memory the caller already owns instead of a new Bitmap every time —
 *  so nothing is allocated here at all once [dest] exists. [dest] must
 *  already be sized/configured the way the caller wants the result
 *  (GameScreenRecorder allocates it once, at VIDEO_WIDTH x
 *  VIDEO_HEIGHT, for a whole recording's lifetime — see its own
 *  captureBitmap field). Reuses gamePaint (MainActivity.kt) — the same
 *  Paint the live on-screen render path already draws the raw
 *  framebuffer with, kept in sync with the user's linear-filter
 *  setting by updateLinearFilterPaint() — instead of a third paint
 *  tracking that same setting independently.
 *
 *  Holds bufferLock for the drawBitmap() blit itself, same as
 *  captureGameFrameBitmap() does for its own copy — but NOT quite the
 *  same shape as that function overall: that one deliberately scopes
 *  the lock to just the raw copy and does its own scale afterward,
 *  unlocked (see its own doc comment for why — minimizing how long a
 *  rare, one-off call blocks the game thread's publish step). Copy and
 *  scale are one and the same drawBitmap() call here, so splitting
 *  them the same way would need a second reused scratch bitmap at the
 *  framebuffer's own native size, kept in step with it. Given a blit
 *  this small (240x160 source) is genuinely fast, and this is already
 *  called every recorded frame today (the old captureGameFrameBitmap()
 *  call here held the lock for its own copy the same way), that extra
 *  moving part didn't earn its keep — held a little longer than the
 *  one-off case needs, not longer than what this call site already
 *  accepted before this fix.
 *
 *  Returns false, leaving [dest]'s previous contents untouched, if no
 *  frame has been rendered yet, so the caller can just skip that one
 *  capture rather than encode a blank/stale frame. */
internal fun MainActivity.captureGameFrameBitmapInto(dest: Bitmap): Boolean {
    val bufs = frameBuffers ?: return false
    synchronized(bufferLock) {
        val idx = displayIdx
        if (idx == -1) return false
        // gamePaint's isFilterBitmap is already kept in sync with
        // linearFilterEnabled by updateLinearFilterPaint() — not
        // re-touched here, same "shared paint, single source of truth"
        // reasoning as drawOutlineButton()'s own doc comment.
        gameFrameScratchDstRect.set(0f, 0f, dest.width.toFloat(), dest.height.toFloat())
        gameFrameScratchCanvas.setBitmap(dest)
        gameFrameScratchCanvas.drawBitmap(bufs[idx], null, gameFrameScratchDstRect, gamePaint)
    }
    return true
}


internal fun MainActivity.captureStateThumbnail(kind: SlotKind) {
    try {
        val bufs = frameBuffers ?: return
        val rw = bufs[0].width
        val rh = bufs[0].height
        if (rw <= 0 || rh <= 0) return
        // Derive height from the raw frame's own aspect ratio instead
        // of hardcoding one — see STATE_THUMB_WIDTH_PX's own comment.
        val thumbH = (STATE_THUMB_WIDTH_PX.toLong() * rh / rw).toInt().coerceAtLeast(1)
        val thumb = captureGameFrameBitmap(STATE_THUMB_WIDTH_PX, thumbH) ?: return
        val thumbEntry = stateThumbEntryFor(kind)
        thumbEntry.outputStream().use { out -> thumb.compress(Bitmap.CompressFormat.PNG, 90, out) }
        thumbEntry.mirrorToAutoFolder()
    } catch (e: Exception) {
        // Best-effort, same spirit as backupIfExists(): a thumbnail
        // failure must never be surfaced as a save failure.
        Log.w(TAG, "State thumbnail capture failed (save itself is unaffected)", e)
    }
}


/**
 *  Row view for showSaveStateSlotDialog()'s ListView.
 *
 *  FIX (Eleventh pass) applies here too, deliberately: do NOT set
 *  isClickable/isFocusable on this row or on either child, and do not
 *  give the row its own setOnClickListener. This is a ListView item
 *  inside an AlertDialog exactly like gameMenuRow() — see that
 *  function's comment and BUGS_FIXED.md's Eleventh-pass entry for the
 *  full explanation of why that combination silently eats every tap.
 *  Clicks here are meant to reach the ListView's own OnItemClickListener
 *  (the `{ _, which -> ... }` lambda passed to setAdapter() below) and
 *  nothing else.
 */
internal fun MainActivity.stateSlotRow(): LinearLayout {
    return LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(24), dp(14), dp(24), dp(14))
        setBackgroundResource(rippleBackgroundResId())
        addView(ImageView(this@stateSlotRow).apply {
            layoutParams = LinearLayout.LayoutParams(dp(96), dp(64))
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(Color.parseColor("#2A2A2A"))
        })
        addView(TextView(this@stateSlotRow).apply {
            layoutParams = LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f
            ).apply { marginStart = dp(24) }
            textSize = 16f
            setTextColor(Color.WHITE)
        })
    }
}

internal fun MainActivity.cacheSlotInfo(key: String, info: SlotInfo): SlotInfo {
    if (slotInfoCache.size >= SLOT_INFO_CACHE_MAX) slotInfoCache.clear()
    slotInfoCache[key] = info
    return info
}


/** Resolves one slot row's current on-disk state — exists/modified/
 *  label/thumbnail — reusing slotInfoCache exactly like the numbered
 *  slots always have (a plain disk-read-plus-PNG-decode round trip on
 *  every dialog open otherwise). Extracted out of
 *  showSaveStateSlotDialog()'s own listing pass (this pass — see
 *  SlotKind's doc comment) so the same logic serves QuickSave/
 *  Autosave/Numbered alike instead of being duplicated per kind.
 *  [docsByName] is the Storage folder's already-listed contents (or
 *  null if none is configured) — passed in rather than re-resolved
 *  per slot, same reasoning as before this pass. */
internal fun MainActivity.loadSlotInfo(kind: SlotKind, docsByName: Map<String, DocumentFile>?): SlotInfo {
    val entry = stateEntryFor(kind)
    val stateFileName = when (kind) {
        SlotKind.QuickSave -> quickStateFile().name
        SlotKind.Autosave -> autoStateFile().name
        is SlotKind.Numbered -> stateSlotFile(kind.slot).name
    }
    val exists: Boolean
    val modified: Long
    if (docsByName != null) {
        val stateDoc = docsByName[stateFileName]
        exists = stateDoc != null
        modified = stateDoc?.lastModified() ?: 0L
    } else {
        // No Storage folder configured — plain internal-storage File
        // calls, same as before this pass, just now shared across
        // every kind instead of only the numbered slots.
        exists = entry.exists()
        modified = entry.lastModified()
    }

    val cacheKey = "$currentRomBaseName:${kind.cacheKeySuffix()}"
    val cached = slotInfoCache[cacheKey]
    if (cached != null && cached.exists == exists && cached.modified == modified) {
        // Cache hit — nothing about this slot has changed since the
        // last time we decoded it, so skip the disk read and PNG
        // decode entirely.
        return cached
    }

    val thumbFileName = when (kind) {
        SlotKind.QuickSave -> quickThumbFile().name
        SlotKind.Autosave -> autoThumbFile().name
        is SlotKind.Numbered -> stateThumbFile(kind.slot).name
    }
    val thumbStream: InputStream? = if (docsByName != null) {
        docsByName[thumbFileName]?.let {
            try { contentResolver.openInputStream(it.uri) } catch (e: Exception) { null }
        }
    } else {
        stateThumbEntryFor(kind).inputStream()
    }
    val label = if (exists) "${kind.displayName()} — ${DateFormat.format("MMM d, h:mm a", modified)}"
                else         "${kind.displayName()} — Empty"
    val bmp = try {
        thumbStream?.use { BitmapFactory.decodeStream(it) }
    } catch (e: Exception) {
        Log.w(TAG, "Corrupt state thumbnail for ${kind.displayName()}", e); null
    }
    return cacheSlotInfo(cacheKey, SlotInfo(kind, entry, exists, modified, label, bmp))
}


internal fun MainActivity.showSaveStateSlotDialog(forSave: Boolean) {
    Thread {
        // One folder resolution + one listing, reused for every slot
        // and every thumbnail below — instead of SaveEntry.doc()
        // re-resolving and re-listing this same folder from scratch
        // for each of the ~12 lookups this dialog used to make.
        val folderRoot = dataSubfolder("save")
        val docsByName: Map<String, DocumentFile>? =
            folderRoot?.listFiles()?.mapNotNull { d -> d.name?.let { it to d } }?.toMap()

        // Quick Save and Autosave first (the two most-reached-for
        // slots — one a deliberate one-tap save, the other kept fresh
        // automatically), then the numbered slots. Direct report:
        // "make a slot for quick save slot and autosave slot" —
        // before this pass neither one was visible anywhere in this
        // dialog at all; see SlotKind's own doc comment.
        val kinds: List<SlotKind> = listOf(SlotKind.QuickSave, SlotKind.Autosave) +
            (1..SAVE_STATE_SLOTS).map { SlotKind.Numbered(it) }
        val slots = kinds.map { kind -> loadSlotInfo(kind, docsByName) }.toMutableList()

        Handler(Looper.getMainLooper()).post {
            if (isFinishing || isDestroyed) return@post

            val adapter = object : ArrayAdapter<SlotInfo>(this, 0, slots) {
                override fun getView(position: Int, recycled: View?, parent: ViewGroup): View {
                    val row = recycled as? LinearLayout ?: stateSlotRow()
                    // FIX (audit F5): was getItem(position)!! — the sole `!!`
                    // in the non-link codebase. Safe today regardless (this
                    // adapter's backing `slots` list is fixed at construction,
                    // just above, and never mutated, so position is always in
                    // range) — this just removes the assertion for
                    // refactor-proofing. Returns the row un-bound rather than
                    // crashing in the (unreachable) null case.
                    val info = getItem(position) ?: return row
                    (row.getChildAt(1) as TextView).text = info.label
                    val icon = row.getChildAt(0) as ImageView
                    if (info.thumb != null) icon.setImageBitmap(info.thumb) else icon.setImageDrawable(null)
                    return row
                }

                // Lets the hold-to-delete update below (slots[position] =
                // emptied) actually reach the screen: this adapter's own
                // internal copy of `slots`, made once at construction just
                // above, would otherwise never see a later element-level
                // change to the external `slots` list. Reading straight
                // from `slots` here instead keeps this adapter always in
                // sync with it, so a plain notifyDataSetChanged() after
                // that assignment is enough — no remove()/insert() needed.
                override fun getItem(position: Int): SlotInfo? = slots.getOrNull(position)
            }

            val dialog = AlertDialog.Builder(this)
                .setTitle(if (forSave) "Save to which slot?" else "Load which slot?")
                .setAdapter(adapter) { _, index ->
                    val info = slots[index]
                    val kind = info.kind
                    val entry = info.entry
                    // Reuses the exists flag this same background pass
                    // already computed, instead of calling
                    // entry.exists() again here on the UI thread.
                    if (!forSave && !info.exists) {
                        return@setAdapter
                    }
                    // FIX (audit pass): same guard quickSaveState()/
                    // quickLoadState() already have and for the same
                    // reason — see saveStateBusy's own doc comment.
                    // Picking a slot dismisses this dialog, so hitting
                    // this needs two separate menu visits in quick
                    // succession rather than one fast double-tap, but
                    // the underlying race (two unordered Threads both
                    // calling nativeSaveState()/nativeLoadState()) is
                    // identical.
                    if (!saveStateBusy.compareAndSet(false, true)) {
                        return@setAdapter
                    }
                    // Runs off the UI thread — same pattern as romPicker above —
                    // since this touches disk and briefly holds the native
                    // core's mutex against the running game thread.
                    Thread {
                        try {
                        // FEATURE: auto save backup — nativeSaveState() truncates
                        // this slot's file the instant it's called (VFileOpen
                        // uses O_TRUNC — see mgba_jni.c), so anything already in
                        // it is gone the moment a save starts, even if the write
                        // itself then fails partway through. The thumbnail gets
                        // the same one-level rolling backup, for the same reason.
                        val thumbEntry = stateThumbEntryFor(kind)
                        if (forSave) { backupIfExists(entry); backupIfExists(thumbEntry) }
                        val ok = if (forSave) {
                            val localPath = entry.stageForWrite()
                            val saved = EmulatorEngine.nativeSaveState(localPath)
                            // FIX (save-state reliability pass): `saved`
                            // used to double as this slot's whole result —
                            // commitWrite() was Unit, called and ignored.
                            // It now reports whether the write actually
                            // landed (crash-safe rename for local storage,
                            // or the SAF copy), so that's what this slot's
                            // result — and the mirror below — are gated on
                            // instead. A native write that reported
                            // failure discards its now-useless temp file.
                            val committed = if (saved) entry.commitWrite(localPath) else {
                                entry.discardWrite(localPath)
                                false
                            }
                            if (committed) entry.mirrorToAutoFolder()
                            committed
                        } else {
                            val localPath = entry.stageForRead()
                            localPath != null && EmulatorEngine.nativeLoadState(localPath)
                        }
                        // FIX (this pass — direct ask: remove the remaining
                        // Save/Load menu popups): the success/failure
                        // uiToast() that used to sit here (and the comment
                        // explaining its old timing) is gone. The actual
                        // save/load call above is fully unchanged and
                        // already completes — state written or read, or
                        // not — before this point either way; only the
                        // notification itself is removed, same as
                        // quickSaveState()/quickLoadState() already got.
                        // Thumbnail only on a *successful* save — an old
                        // thumbnail surviving a failed save (whose backupIfExists
                        // call above already preserved it under .bak regardless)
                        // is more useful than no thumbnail at all.
                        if (ok && forSave) captureStateThumbnail(kind)
                        } finally {
                            // FIX (audit pass): mirrors quickSaveState()/
                            // quickLoadState()'s finally block — always
                            // clears the guard, success or failure, so a
                            // save/load that throws can't leave every
                            // future attempt permanently blocked.
                            saveStateBusy.set(false)
                        }
                    }.apply { name = "mGBA-state" }.start()
                }
                .setNegativeButton("Cancel", null)
                .show()

            // FEATURE: hold-to-delete for save-state entries (Save State
            // menu and Load State menu alike — this one function serves
            // both, via `forSave`). Attaches to the ListView this same
            // dialog's own setAdapter() call above already created and
            // owns — stateSlotRow()'s own doc comment above is exactly
            // why this adds no new child view to the row itself: a
            // clickable/focusable child there would eat the touch before
            // either this or the existing tap-to-select ever saw it, the
            // same "Eleventh pass" bug gameMenuRow()'s own comment
            // documents for a plain tap. OnItemLongClickListener is the
            // ListView's own existing, built-in long-click path — the
            // "existing item long-click listener" this feature was asked
            // to prefer over a custom touch/timing implementation — and
            // it already tells a held finger apart from a scroll/fling/
            // rapid tap on its own (framework behavior; nothing extra
            // needed here for that).
            dialog.listView?.setOnItemLongClickListener { _, _, position, _ ->
                val info = slots.getOrNull(position)
                // Nothing to delete in an already-empty slot. Always
                // consumed (`true`) either way, so a long-press can never
                // also fall through afterward as a normal tap on release.
                if (info == null || !info.exists) return@setOnItemLongClickListener true
                val kind = info.kind
                val entry = info.entry
                AlertDialog.Builder(this)
                    .setTitle("Delete this save state?")
                    .setMessage("${info.label}\n\nThis can't be undone.")
                    .setPositiveButton("Delete") { _, _ ->
                        // Same saveStateBusy guard the save/load Thread
                        // above uses, for the same reason (see that
                        // guard's own comment) — a delete must not run
                        // concurrently with a save/load already in
                        // flight. Silently does nothing if busy, matching
                        // this whole menu's now-silent behavior elsewhere,
                        // rather than a toast; the file is simply left as
                        // it was, same as tapping Cancel.
                        if (!saveStateBusy.compareAndSet(false, true)) {
                            return@setPositiveButton
                        }
                        Thread {
                            try {
                                // Only this one slot's own state file and
                                // its own thumbnail — entry/thumbEntry are
                                // both resolved from this specific row's
                                // SlotKind (stateEntryFor()/
                                // stateThumbEntryFor(), same as every other
                                // call site in this file), never a
                                // directory, the ROM, or another slot.
                                // SaveEntry.delete() already no-ops safely
                                // (returns false, doesn't throw) if the
                                // file is already gone, on both the
                                // legacy-file and Storage-folder paths —
                                // see its own doc comment.
                                entry.delete()
                                stateThumbEntryFor(kind).delete()
                                // Keeps slotInfoCache truthful for the next
                                // time this dialog opens — loadSlotInfo()'s
                                // own cache check already re-verifies
                                // exists/modified against disk on every
                                // open regardless, so this isn't required
                                // for correctness, only so a reopen doesn't
                                // even briefly show stale cached data.
                                val emptied = SlotInfo(
                                    kind, entry, exists = false, modified = 0L,
                                    label = "${kind.displayName()} — Empty", thumb = null
                                )
                                cacheSlotInfo("$currentRomBaseName:${kind.cacheKeySuffix()}", emptied)
                                Handler(Looper.getMainLooper()).post {
                                    if (isFinishing || isDestroyed) return@post
                                    // The slot itself stays in the list, at
                                    // the same position — numbered save
                                    // slots are never removed, only this
                                    // one slot's own save data — so this
                                    // replaces the item in place (the
                                    // adapter's overridden getItem() above
                                    // reads straight from `slots`, so this
                                    // assignment IS the update the adapter
                                    // sees) rather than remove()+insert(),
                                    // then asks the adapter to redraw. Same
                                    // "row for an empty slot" this same
                                    // adapter already renders for one that
                                    // was simply never saved to.
                                    slots[position] = emptied
                                    adapter.notifyDataSetChanged()
                                }
                            } finally {
                                saveStateBusy.set(false)
                            }
                        }.apply { name = "mGBA-state-delete" }.start()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
                true
            }
        }
    }.apply { name = "mGBA-slot-list" }.start()
}

