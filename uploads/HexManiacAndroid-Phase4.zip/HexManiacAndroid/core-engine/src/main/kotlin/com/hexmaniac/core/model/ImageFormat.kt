package com.hexmaniac.core.model

/** Thrown by [ImageFormat]'s parse functions with a message meant to be shown directly to the user. */
class ImageFormatException(message: String) : Exception(message)

private val VALID_BITS_PER_PIXEL = setOf(1, 2, 4, 8)

/**
 * A tile-based image: [tileWidth] x [tileHeight] tiles, each 8x8 pixels of [bitsPerPixel]-bit
 * palette indices. Used both for a standalone sprite and for a tileset a [TilemapRun] draws
 * from - HMA keeps those as separate classes (SpriteRun/TilesetRun, each with an Lz-compressed
 * sibling); this project folds them into one, since a tileset is exactly "a sprite whose tiles
 * get reused by index" and the pixel-packing math ([decodeTilePixels]/[encodeTilePixels]) is
 * identical either way - see [SpriteRun]'s doc comment for the rest of that reasoning.
 */
data class SpriteFormat(
    val bitsPerPixel: Int,
    val tileWidth: Int,
    val tileHeight: Int,
    val compressed: Boolean,
    val allowLengthErrors: Boolean = false,
) {
    init {
        require(bitsPerPixel in VALID_BITS_PER_PIXEL) { "bitsPerPixel must be 1, 2, 4, or 8, was $bitsPerPixel." }
        require(tileWidth in 1..100) { "tileWidth must be 1-100, was $tileWidth." }
        require(tileHeight in 1..1024) { "tileHeight must be 1-1024, was $tileHeight." }
    }

    val pixelWidth: Int get() = tileWidth * 8
    val pixelHeight: Int get() = tileHeight * 8

    /** Bytes one full page of pixels occupies once decompressed - see [SpriteRun.decodedBytes]. */
    val bytesPerPage: Int get() = tileWidth * tileHeight * 8 * bitsPerPixel
}

/**
 * A palette: [pages] banks of `2^bits` colors each, starting at slot [initialBlankPages] of
 * whatever larger virtual palette a paired tilemap's per-tile palette nibble indexes into
 * (0 for a palette that starts at slot 0, same as most). Reference: PaletteFormat in the
 * original's Sprites.cs.
 */
data class PaletteFormat(
    val bits: Int,
    val pages: Int = 1,
    val initialBlankPages: Int = 0,
    val compressed: Boolean,
    val allowLengthErrors: Boolean = false,
) {
    init {
        require(bits in VALID_BITS_PER_PIXEL) { "bits must be 1, 2, 4, or 8, was $bits." }
        require(pages >= 1) { "pages must be at least 1, was $pages." }
        require(initialBlankPages >= 0) { "initialBlankPages can't be negative, was $initialBlankPages." }
    }

    val colorCount: Int get() = 1 shl bits
    val bytesPerPage: Int get() = colorCount * 2
}

/**
 * A GBA background tilemap: [tileWidth] x [tileHeight] entries, each a 2-byte record of which
 * tile from the [matchingTilesetAddress] tileset to draw, with optional flips and a palette-
 * page nibble - see [TilemapRun.readEntry]. [bitsPerPixel] here describes the *tileset's* bit
 * depth (needed to render composed pixels), not the tilemap's own bytes, which are always
 * 2 bytes/entry - see [TilemapRun]'s doc comment for the 1-byte/entry legacy variant this
 * project doesn't support.
 *
 * HMA's own format names the tileset by anchor - this project has no anchor/naming system (see
 * README: table and string recognition are both manual-by-address too), so this identifies it
 * by raw address instead, same substitution every other cross-reference in this app makes.
 */
data class TilemapFormat(
    val bitsPerPixel: Int,
    val tileWidth: Int,
    val tileHeight: Int,
    val matchingTilesetAddress: Int,
    val compressed: Boolean,
    val allowLengthErrors: Boolean = false,
) {
    init {
        require(bitsPerPixel in VALID_BITS_PER_PIXEL) { "bitsPerPixel must be 1, 2, 4, or 8, was $bitsPerPixel." }
        require(tileWidth in 1..100) { "tileWidth must be 1-100, was $tileWidth." }
        require(tileHeight in 1..100) { "tileHeight must be 1-100, was $tileHeight." }
        require(matchingTilesetAddress >= 0) { "Tileset address must be non-negative." }
    }

    val bytesPerEntry: Int get() = 2
    val decompressedLength: Int get() = tileWidth * tileHeight * bytesPerEntry
}

/**
 * Parses HexManiacAdvance's `` `ucs`/`lzs`/`ucp`/`lzp`/`ucm`/`lzm` `` image format-string DSL
 * into [SpriteFormat]/[PaletteFormat]/[TilemapFormat]. Reference: `TryParseDimensions`/
 * `TryParseGeneralTilemapFormat` across LzSpriteRun.cs/LzPaletteRun.cs/LzTilemapRun.cs (this
 * project uses HMA's source as a spec to read, not code to reuse - see README).
 *
 * Deliberate subset, matching what [SpriteFormat]/[PaletteFormat]/[TilemapFormat] support:
 *   - Sprite/tileset: `` `ucs{bpp}x{tileWidth}x{tileHeight}` `` or the Lz-compressed `` `lzs...` ``.
 *     No palette-hint suffix (the original's `|hintName`) - HMA uses it only to help its own
 *     auto-detection guess which palette to pair with a sprite; this project pairs them
 *     explicitly by address instead (see ImageEditorViewModel), so a hint would be dead weight.
 *   - Palette: `` `ucp{bits}` `` / `` `lzp{bits}` ``, optionally `` :{startHex}{endHex}` `` for a
 *     multi-page palette occupying slots startHex..endHex inclusive (both single hex digits) of
 *     a larger virtual palette. This is a cleaner equivalent of the original's page-range
 *     notation (which allows some quirkier forms - a single trailing character, an unbounded
 *     open range) rather than a byte-for-byte port of its parsing.
 *   - Tilemap: `` `ucm{bpp}x{tileWidth}x{tileHeight}|{tilesetAddressHex}` `` / the Lz-compressed
 *     `` `lzm...` ``. No table-member suffix (the original's second `|`) - that disambiguates
 *     which pointer field of a table element supplies the tileset when a hint name alone is
 *     ambiguous, which doesn't apply here since the tileset is already a specific address, not
 *     a name.
 *   - A trailing `!` (before the closing backtick) on any of the three sets `allowLengthErrors`,
 *     same meaning and position as the original.
 * Not supported at all: enum/table-driven dimensions, the 1-byte-per-tilemap-entry legacy
 * variant - see [TilemapRun]'s doc comment.
 */
object ImageFormat {
    private val HEX_DIGITS = "0123456789ABCDEF"

    fun parseSprite(formatText: String): SpriteFormat {
        val (prefix, body, allowLengthErrors) = splitPrefixBody(formatText, "ucs", "lzs")
        val parts = body.split("x")
        if (parts.size != 3) {
            throw ImageFormatException("Expected '${prefix}{bits}x{tileWidth}x{tileHeight}', e.g. '${prefix}4x4x4'.")
        }
        val bpp = parts[0].toIntOrNull() ?: throw ImageFormatException("'${parts[0]}' isn't a valid bits-per-pixel.")
        val width = parts[1].toIntOrNull() ?: throw ImageFormatException("'${parts[1]}' isn't a valid tile width.")
        val height = parts[2].toIntOrNull() ?: throw ImageFormatException("'${parts[2]}' isn't a valid tile height.")
        return try {
            SpriteFormat(bpp, width, height, compressed = prefix == "lzs", allowLengthErrors = allowLengthErrors)
        } catch (e: IllegalArgumentException) {
            throw ImageFormatException(e.message ?: "Invalid sprite format.")
        }
    }

    fun parsePalette(formatText: String): PaletteFormat {
        val (prefix, body, allowLengthErrors) = splitPrefixBody(formatText, "ucp", "lzp")
        val pageSplit = body.split(":")
        val bits = pageSplit[0].toIntOrNull()
            ?: throw ImageFormatException("Expected '${prefix}{bits}', e.g. '${prefix}4', optionally '${prefix}4:03'.")

        var pages = 1
        var initialBlankPages = 0
        if (pageSplit.size == 2) {
            val range = pageSplit[1].uppercase()
            if (range.length != 2) {
                throw ImageFormatException("Page range must be exactly 2 hex digits (start, end), e.g. ':03'.")
            }
            val startIndex = HEX_DIGITS.indexOf(range[0])
            val endIndex = HEX_DIGITS.indexOf(range[1])
            if (startIndex < 0 || endIndex < 0) throw ImageFormatException("'${pageSplit[1]}' isn't a valid hex page range.")
            if (endIndex < startIndex) throw ImageFormatException("Page range end can't be before its start.")
            initialBlankPages = startIndex
            pages = endIndex - startIndex + 1
        } else if (pageSplit.size > 2) {
            throw ImageFormatException("Expected at most one ':' in a palette format.")
        }

        return try {
            PaletteFormat(bits, pages, initialBlankPages, compressed = prefix == "lzp", allowLengthErrors = allowLengthErrors)
        } catch (e: IllegalArgumentException) {
            throw ImageFormatException(e.message ?: "Invalid palette format.")
        }
    }

    fun parseTilemap(formatText: String): TilemapFormat {
        val (prefix, body, allowLengthErrors) = splitPrefixBody(formatText, "ucm", "lzm")
        val pipeIndex = body.indexOf('|')
        if (pipeIndex < 0) {
            throw ImageFormatException(
                "Expected '${prefix}{bits}x{tileWidth}x{tileHeight}|{tilesetAddress}', e.g. '${prefix}4x4x4|1A2B3C'."
            )
        }
        val dimensions = body.substring(0, pipeIndex).split("x")
        if (dimensions.size != 3) {
            throw ImageFormatException("Expected '{bits}x{tileWidth}x{tileHeight}' before '|', got '${body.substring(0, pipeIndex)}'.")
        }
        val bpp = dimensions[0].toIntOrNull() ?: throw ImageFormatException("'${dimensions[0]}' isn't a valid bits-per-pixel.")
        val width = dimensions[1].toIntOrNull() ?: throw ImageFormatException("'${dimensions[1]}' isn't a valid tile width.")
        val height = dimensions[2].toIntOrNull() ?: throw ImageFormatException("'${dimensions[2]}' isn't a valid tile height.")

        val addressText = body.substring(pipeIndex + 1).trim().removePrefix("0x")
        val tilesetAddress = addressText.toIntOrNull(16)
            ?: throw ImageFormatException("'$addressText' isn't a valid hex tileset address.")

        return try {
            TilemapFormat(bpp, width, height, tilesetAddress, compressed = prefix == "lzm", allowLengthErrors = allowLengthErrors)
        } catch (e: IllegalArgumentException) {
            throw ImageFormatException(e.message ?: "Invalid tilemap format.")
        }
    }

    /** Strips the leading `` `uc?``/`lz?` `` prefix, trailing backtick, and optional `!`, and
     *  reports which of the two prefixes matched - shared by all three parse functions above. */
    private fun splitPrefixBody(formatText: String, uncompressedPrefix: String, compressedPrefix: String): Triple<String, String, Boolean> {
        val text = formatText.trim()
        val prefix = when {
            text.startsWith("`$uncompressedPrefix") -> uncompressedPrefix
            text.startsWith("`$compressedPrefix") -> compressedPrefix
            else -> throw ImageFormatException("Expected a format starting with '`$uncompressedPrefix' or '`$compressedPrefix'.")
        }
        if (!text.endsWith("`")) throw ImageFormatException("Format must end with a closing backtick.")
        var body = text.substring(1 + prefix.length, text.length - 1)
        val allowLengthErrors = body.endsWith("!")
        if (allowLengthErrors) body = body.dropLast(1)
        return Triple(prefix, body, allowLengthErrors)
    }
}
