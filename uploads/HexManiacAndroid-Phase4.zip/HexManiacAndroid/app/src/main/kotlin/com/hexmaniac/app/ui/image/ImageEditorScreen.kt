package com.hexmaniac.app.ui.image

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hexmaniac.app.ui.EmptyRomState
import com.hexmaniac.app.ui.HexManiacTopBar

/**
 * Sprite/tileset, palette, and tilemap editing in one screen, switched between with
 * [ModeSwitcher] rather than three separate [com.hexmaniac.app.ui.HexManiacScreen] destinations -
 * see [ImageEditorMode]'s doc comment for why. Each sub-panel follows the same
 * define-then-edit shape [TableEditorScreen][com.hexmaniac.app.ui.table.TableEditorScreen] and
 * [TextEditorScreen][com.hexmaniac.app.ui.text.TextEditorScreen] use: an address+format form
 * until something is open, then a viewer with a bottom edit bar.
 */
@Composable
fun ImageEditorScreen(
    viewModel: ImageEditorViewModel,
    onBack: () -> Unit,
    onOpenRomRequested: () -> Unit,
    onSaveRomRequested: () -> Unit,
) {
    val state = viewModel.uiState

    Scaffold(
        topBar = {
            HexManiacTopBar(
                title = "Image Editor",
                navigationIcon = { TextButton(onClick = onBack) { Text("Back") } },
                actions = {
                    // Saves the whole ROM session, same as the hex viewer's Save - every screen
                    // shares RomSessionRepository, so there's no separate "image changes" to save.
                    TextButton(onClick = onSaveRomRequested, enabled = state.romLoaded) { Text("Save") }
                    TextButton(onClick = viewModel::undo, enabled = state.canUndo) { Text("Undo") }
                    TextButton(onClick = viewModel::redo, enabled = state.canRedo) { Text("Redo") }
                },
            )
        },
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {
            if (!state.romLoaded) {
                EmptyRomState("Open a .gba file before viewing sprites, palettes, or tilemaps.", onOpenRomRequested)
            } else {
                ModeSwitcher(state.mode, viewModel::setMode)
                Column(modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp)) {
                    when (state.mode) {
                        ImageEditorMode.SPRITE -> SpritePanel(viewModel, state)
                        ImageEditorMode.PALETTE -> PalettePanel(viewModel, state)
                        ImageEditorMode.TILEMAP -> TilemapPanel(viewModel, state)
                    }
                }
            }
            Text(
                text = state.statusMessage,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
            )
        }
    }
}

@Composable
private fun ModeSwitcher(mode: ImageEditorMode, onModeChange: (ImageEditorMode) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        for (candidate in ImageEditorMode.entries) {
            val label = when (candidate) {
                ImageEditorMode.SPRITE -> "Sprite"
                ImageEditorMode.PALETTE -> "Palette"
                ImageEditorMode.TILEMAP -> "Tilemap"
            }
            val selected = candidate == mode
            TextButton(
                onClick = { onModeChange(candidate) },
                colors = if (selected) {
                    ButtonDefaults.textButtonColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                } else {
                    ButtonDefaults.textButtonColors()
                },
            ) { Text(label) }
        }
    }
}

@Composable
private fun DefineForm(
    addressText: String,
    onAddressChange: (String) -> Unit,
    formatText: String,
    onFormatChange: (String) -> Unit,
    formatHint: String,
    onOpen: () -> Unit,
) {
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp)) {
        OutlinedTextField(
            value = addressText,
            onValueChange = onAddressChange,
            label = { Text("Start address (hex)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
            value = formatText,
            onValueChange = onFormatChange,
            label = { Text("Format") },
            placeholder = { Text(formatHint) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(modifier = Modifier.height(12.dp))
        TextButton(onClick = onOpen) { Text("Open") }
    }
}

// --- sprite / tileset ---

@Composable
private fun SpritePanel(viewModel: ImageEditorViewModel, state: ImageEditorUiState) {
    val run = state.sprite
    if (run == null) {
        DefineForm(
            addressText = state.spriteAddressText,
            onAddressChange = viewModel::updateSpriteAddressText,
            formatText = state.spriteFormatText,
            onFormatChange = viewModel::updateSpriteFormatText,
            formatHint = "`ucs4x4x4` or `lzs4x4x4`",
            onOpen = viewModel::openSprite,
        )
        return
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "0x${run.start.toString(16).uppercase()} - ${run.format.pixelWidth}x${run.format.pixelHeight}px",
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.weight(1f),
            )
            TextButton(onClick = viewModel::clearSprite) { Text("Close") }
        }

        if (state.spritePageCount > 1) {
            PageSelector(count = state.spritePageCount, current = state.spritePage, onSelect = viewModel::setSpritePage)
        }

        val pixels = viewModel.renderedSpritePixels()
        if (pixels != null) {
            PixelGridImage(
                pixelsArgb = pixels,
                width = run.format.pixelWidth,
                height = run.format.pixelHeight,
                onSelect = viewModel::selectPixel,
                modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
            )
        }

        val paletteColors = viewModel.paletteSwatchArgbColors()
        if (paletteColors != null) {
            Text(
                "Paired palette - tap a pixel above, then type its index below:",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            SwatchRow(colors = paletteColors, selectedIndex = null, onSelect = null, modifier = Modifier.padding(vertical = 6.dp))
        }

        if (state.selectedPixelX != null && state.selectedPixelY != null) {
            SpriteEditBar(viewModel, state)
        }
    }
}

@Composable
private fun SpriteEditBar(viewModel: ImageEditorViewModel, state: ImageEditorUiState) {
    val x = state.selectedPixelX ?: return
    val y = state.selectedPixelY ?: return
    var text by remember(x, y, state.revision) {
        val current = viewModel.selectedPixelIndex()?.toString(16)?.uppercase() ?: ""
        mutableStateOf(current)
    }
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("Pixel ($x, $y):", fontFamily = FontFamily.Monospace, modifier = Modifier.padding(end = 8.dp))
        OutlinedTextField(
            value = text,
            onValueChange = { text = it.take(2) },
            modifier = Modifier.size(width = 72.dp, height = 56.dp),
            singleLine = true,
        )
        TextButton(onClick = { viewModel.writeSelectedPixel(text) }) { Text("Set") }
    }
}

// --- palette ---

@Composable
private fun PalettePanel(viewModel: ImageEditorViewModel, state: ImageEditorUiState) {
    val run = state.palette
    if (run == null) {
        DefineForm(
            addressText = state.paletteAddressText,
            onAddressChange = viewModel::updatePaletteAddressText,
            formatText = state.paletteFormatText,
            onFormatChange = viewModel::updatePaletteFormatText,
            formatHint = "`ucp4` or `lzp4:03`",
            onOpen = viewModel::openPalette,
        )
        return
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "0x${run.start.toString(16).uppercase()} - ${run.format.colorCount} colors",
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.weight(1f),
            )
            TextButton(onClick = viewModel::clearPalette) { Text("Close") }
        }

        if (run.format.pages > 1) {
            PageSelector(count = run.format.pages, current = state.palettePage, onSelect = viewModel::setPalettePage)
        }

        val colors = viewModel.paletteSwatchArgbColors()
        Text(
            "Tap a color, then type its new value as RRGGBB hex:",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(vertical = 8.dp),
        )
        SwatchRow(colors = colors, selectedIndex = state.selectedSwatch, onSelect = viewModel::selectSwatch)

        if (state.selectedSwatch != null) {
            PaletteEditBar(viewModel, state)
        }
    }
}

@Composable
private fun PaletteEditBar(viewModel: ImageEditorViewModel, state: ImageEditorUiState) {
    val index = state.selectedSwatch ?: return
    var text by remember(index, state.revision) {
        val current = viewModel.selectedSwatchArgb()?.let { (it and 0xFFFFFF).toString(16).uppercase().padStart(6, '0') } ?: ""
        mutableStateOf(current)
    }
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("Color ${index.toString(16).uppercase()}:", fontFamily = FontFamily.Monospace, modifier = Modifier.padding(end = 8.dp))
        OutlinedTextField(
            value = text,
            onValueChange = { text = it.take(6) },
            modifier = Modifier.width(100.dp),
            singleLine = true,
            placeholder = { Text("RRGGBB") },
        )
        TextButton(onClick = { viewModel.writeSelectedSwatch(text) }) { Text("Set") }
    }
}

// --- tilemap ---

@Composable
private fun TilemapPanel(viewModel: ImageEditorViewModel, state: ImageEditorUiState) {
    val run = state.tilemap
    if (run == null) {
        DefineForm(
            addressText = state.tilemapAddressText,
            onAddressChange = viewModel::updateTilemapAddressText,
            formatText = state.tilemapFormatText,
            onFormatChange = viewModel::updateTilemapFormatText,
            formatHint = "`ucm4x4x4|<tileset addr>` or `lzm4x4x4|<tileset addr>`",
            onOpen = viewModel::openTilemap,
        )
        return
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "0x${run.start.toString(16).uppercase()} - ${run.format.tileWidth}x${run.format.tileHeight} tiles",
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.weight(1f),
            )
            TextButton(onClick = viewModel::clearTilemap) { Text("Close") }
        }
        Text(
            "Tileset: 0x${run.format.matchingTilesetAddress.toString(16).uppercase()}",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        val pixels = viewModel.renderedTilemapPixels()
        if (pixels != null) {
            PixelGridImage(
                pixelsArgb = pixels,
                width = run.format.tileWidth * 8,
                height = run.format.tileHeight * 8,
                onSelect = { px, py -> viewModel.selectTile(px / 8, py / 8) },
                modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
            )
        }

        if (state.selectedTileX != null && state.selectedTileY != null) {
            TilemapEditBar(viewModel, state)
        }
    }
}

@Composable
private fun TilemapEditBar(viewModel: ImageEditorViewModel, state: ImageEditorUiState) {
    val x = state.selectedTileX ?: return
    val y = state.selectedTileY ?: return
    val entry = viewModel.selectedTileEntry()
    var text by remember(x, y, state.revision) {
        mutableStateOf(entry?.pack()?.toString(16)?.uppercase()?.padStart(4, '0') ?: "0000")
    }
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Text(
            "Tile ($x, $y)" + (entry?.let { ": $it" } ?: ""),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it.take(4) },
                modifier = Modifier.width(96.dp),
                singleLine = true,
                placeholder = { Text("hex entry") },
            )
            TextButton(onClick = { viewModel.writeSelectedTile(text) }, modifier = Modifier.padding(start = 8.dp)) { Text("Set") }
        }
    }
}

// --- shared ---

@Composable
private fun PageSelector(count: Int, current: Int, onSelect: (Int) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 4.dp)) {
        Text("Page:", modifier = Modifier.padding(end = 8.dp), style = MaterialTheme.typography.bodySmall)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            items(count) { page ->
                TextButton(
                    onClick = { onSelect(page) },
                    colors = if (page == current) {
                        ButtonDefaults.textButtonColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                    } else {
                        ButtonDefaults.textButtonColors()
                    },
                ) { Text("$page") }
            }
        }
    }
}

@Composable
private fun SwatchRow(
    colors: IntArray?,
    selectedIndex: Int?,
    onSelect: ((Int) -> Unit)?,
    modifier: Modifier = Modifier,
) {
    if (colors == null) return
    LazyRow(modifier = modifier, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        itemsIndexed(colors.toList()) { index, argb ->
            val isSelected = index == selectedIndex
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .background(Color(argb))
                        .border(
                            width = if (isSelected) 2.dp else 1.dp,
                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                        )
                        .let { base -> if (onSelect != null) base.clickable { onSelect(index) } else base },
                )
                Text(index.toString(16).uppercase(), fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            }
        }
    }
}

/**
 * Renders [pixelsArgb] ([width] x [height], row-major) as a real [Bitmap] rather than a grid of
 * individual Composables - unlike [com.hexmaniac.app.ui.HexViewerScreen]'s byte grid, an image
 * here can be tens of thousands of pixels (a full tileset, a large tilemap), and a `Box` per
 * pixel at that scale is both slower to compose and a worse visual result (no true image
 * scaling) than letting Android's own Bitmap pipeline do it. [FilterQuality.None] keeps pixel
 * art crisp when scaled up rather than blurring it.
 *
 * [onSelect] always reports *pixel* coordinates; a caller working in a coarser unit (e.g.
 * [TilemapPanel] selecting a whole 8x8 tile) divides down itself; that keeps this composable
 * generic rather than baking in a "tile size" concept it otherwise has no use for.
 */
@Composable
private fun PixelGridImage(
    pixelsArgb: IntArray,
    width: Int,
    height: Int,
    onSelect: (x: Int, y: Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val bitmap = remember(pixelsArgb.contentHashCode(), width, height) {
        Bitmap.createBitmap(pixelsArgb, width, height, Bitmap.Config.ARGB_8888).asImageBitmap()
    }
    var boxSize by remember { mutableStateOf(IntSize.Zero) }

    Image(
        bitmap = bitmap,
        contentDescription = null,
        filterQuality = FilterQuality.None,
        modifier = modifier
            .aspectRatio(width.toFloat() / height.toFloat())
            .onSizeChanged { boxSize = it }
            .pointerInput(width, height) {
                detectTapGestures(onTap = { offset ->
                    val size = boxSize
                    if (size.width <= 0 || size.height <= 0) return@detectTapGestures
                    val x = (offset.x / size.width * width).toInt().coerceIn(0, width - 1)
                    val y = (offset.y / size.height * height).toInt().coerceIn(0, height - 1)
                    onSelect(x, y)
                })
            },
    )
}
