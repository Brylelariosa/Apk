package com.menushell.billiards

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import androidx.core.content.ContextCompat
import com.menushell.R
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Draws a pool table — wooden rail, felt, cushions, rail diamonds, and
 * pockets — fit to whatever size this View is given.
 *
 * [tableGeometry] is the exact same model a future ball would collide
 * against; this View only turns it into pixels; it doesn't own any
 * gameplay state itself. No ball or cue yet.
 */
class BilliardsTableView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    /** Recomputed whenever this View is resized; read by whatever eventually simulates a ball. */
    var tableGeometry: TableGeometry? = null
        private set

    private val feltPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val railPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(context, R.color.billiards_rail)
    }
    private val railHighlightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(context, R.color.billiards_rail_light)
        style = Paint.Style.STROKE
    }
    private val cushionPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(context, R.color.billiards_felt_dark)
        style = Paint.Style.FILL
    }
    private val diamondPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(context, R.color.accent_amber)
    }
    private val feltLightColor = ContextCompat.getColor(context, R.color.billiards_felt)
    private val feltDarkColor = ContextCompat.getColor(context, R.color.billiards_felt_dark)
    private val pocketRimColor = ContextCompat.getColor(context, R.color.billiards_rail_light)
    private val pocketCoreColor = ContextCompat.getColor(context, R.color.black)

    private val railPath = Path()
    private val feltBounds = RectF()
    private var pocketPaints: List<Paint> = emptyList()
    private var cushionPaths: List<Path> = emptyList()
    private var diamondPoints: List<PointF> = emptyList()
    private var diamondRadius = 0f

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w > 0 && h > 0) layoutTable(w.toFloat(), h.toFloat())
    }

    /**
     * Fits a 2:1 table inside the View, centered, and derives every paint
     * that depends on that layout (gradients, stroke widths) once here —
     * not in [onDraw], which can run every frame once something animates.
     */
    private fun layoutTable(viewWidth: Float, viewHeight: Float) {
        val margin = min(viewWidth, viewHeight) * MARGIN_FRACTION
        val availableW = viewWidth - margin * 2f
        val availableH = viewHeight - margin * 2f

        var tableW = availableW
        var tableH = tableW / TABLE_ASPECT
        if (tableH > availableH) {
            tableH = availableH
            tableW = tableH * TABLE_ASPECT
        }

        val railLeft = (viewWidth - tableW) / 2f
        val railTop = (viewHeight - tableH) / 2f
        val railRect = RectF(railLeft, railTop, railLeft + tableW, railTop + tableH)

        val railThickness = tableH * RAIL_THICKNESS_FRACTION
        feltBounds.set(
            railRect.left + railThickness,
            railRect.top + railThickness,
            railRect.right - railThickness,
            railRect.bottom - railThickness
        )

        val feltHalfW = feltBounds.width() / 2f
        val feltHalfH = feltBounds.height() / 2f
        feltPaint.shader = RadialGradient(
            feltBounds.centerX(), feltBounds.centerY(),
            sqrt(feltHalfW * feltHalfW + feltHalfH * feltHalfH),
            feltLightColor, feltDarkColor, Shader.TileMode.CLAMP
        )

        val geometry = TableGeometry(
            left = feltBounds.left,
            top = feltBounds.top,
            right = feltBounds.right,
            bottom = feltBounds.bottom,
            cornerPocketRadius = feltBounds.height() * CORNER_POCKET_FRACTION,
            sidePocketRadius = feltBounds.height() * SIDE_POCKET_FRACTION
        )
        tableGeometry = geometry

        val railCorner = railThickness * 0.4f
        railPath.reset()
        railPath.addRoundRect(railRect, railCorner, railCorner, Path.Direction.CW)

        // Cushions taper to a point at each pocket instead of ending in a
        // round cap — that taper is the classic pocket "jaw", and coming
        // to an exact point at the pocket boundary means it can never
        // overlap the pocket circle the way a thick round-capped line did.
        val cushionHalfWidth = railThickness * CUSHION_HALF_WIDTH_FRACTION
        val cushionTaper = railThickness * CUSHION_TAPER_FRACTION
        cushionPaths = geometry.cushions.map { cushion ->
            cushionNosePath(cushion, cushionHalfWidth, cushionTaper)
        }
        railHighlightPaint.strokeWidth = railThickness * 0.06f

        // Each pocket's gradient depends on its own position/radius, so
        // these are rebuilt here on resize rather than allocated in onDraw.
        // Mostly-black throat with a warm rim band is what reads as a real
        // opening — the earlier version used two near-black tones and the
        // gradient was invisible.
        pocketPaints = geometry.pockets.map { pocket ->
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = RadialGradient(
                    pocket.center.x, pocket.center.y, pocket.radius,
                    intArrayOf(pocketCoreColor, pocketCoreColor, pocketRimColor),
                    floatArrayOf(0f, 0.72f, 1f),
                    Shader.TileMode.CLAMP
                )
            }
        }

        diamondRadius = railThickness * 0.09f
        diamondPoints = geometry.cushions.map { cushion -> diamondFor(cushion, railThickness) }
    }

    /** A sight-mark position on the wood rail, just outside the cushion's midpoint. */
    private fun diamondFor(cushion: Cushion, railThickness: Float): PointF {
        val mid = (cushion.start + cushion.end) * 0.5f
        val outward = when {
            abs(mid.y - feltBounds.top) < 1f -> Vec2(0f, -1f)
            abs(mid.y - feltBounds.bottom) < 1f -> Vec2(0f, 1f)
            mid.x - feltBounds.left < feltBounds.width() / 2f -> Vec2(-1f, 0f)
            else -> Vec2(1f, 0f)
        }
        val diamond = mid + outward * (railThickness * 0.5f)
        return PointF(diamond.x, diamond.y)
    }

    /**
     * A hexagon that's full [halfWidth]-wide through the middle of the
     * cushion and narrows to an exact point at [Cushion.start] and
     * [Cushion.end] — those endpoints already sit exactly on the pocket's
     * mouth boundary, so tapering to a point there (rather than a round
     * stroke cap) is what makes this meet the pocket cleanly instead of
     * bulging into it.
     */
    private fun cushionNosePath(cushion: Cushion, halfWidth: Float, taper: Float): Path {
        val edge = cushion.end - cushion.start
        val length = edge.length()
        val along = if (length > 0f) edge * (1f / length) else Vec2(1f, 0f)
        val normal = cushion.normal
        val t = min(taper, length / 2f)

        val innerStart = cushion.start + along * t
        val innerEnd = cushion.end - along * t
        val topNear = innerStart + normal * halfWidth
        val topFar = innerEnd + normal * halfWidth
        val bottomFar = innerEnd - normal * halfWidth
        val bottomNear = innerStart - normal * halfWidth

        return Path().apply {
            moveTo(cushion.start.x, cushion.start.y)
            lineTo(topNear.x, topNear.y)
            lineTo(topFar.x, topFar.y)
            lineTo(cushion.end.x, cushion.end.y)
            lineTo(bottomFar.x, bottomFar.y)
            lineTo(bottomNear.x, bottomNear.y)
            close()
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val geometry = tableGeometry ?: return

        canvas.drawPath(railPath, railPaint)
        canvas.drawPath(railPath, railHighlightPaint)
        canvas.drawRoundRect(
            feltBounds, feltBounds.height() * 0.02f, feltBounds.height() * 0.02f, feltPaint
        )

        diamondPoints.forEach { p -> canvas.drawCircle(p.x, p.y, diamondRadius, diamondPaint) }

        cushionPaths.forEach { path -> canvas.drawPath(path, cushionPaint) }

        geometry.pockets.forEachIndexed { index, pocket ->
            canvas.drawCircle(pocket.center.x, pocket.center.y, pocket.radius, pocketPaints[index])
        }
    }

    companion object {
        private const val TABLE_ASPECT = 2f // standard pool table length:width
        private const val MARGIN_FRACTION = 0.05f
        private const val RAIL_THICKNESS_FRACTION = 0.09f
        private const val CORNER_POCKET_FRACTION = 0.058f
        private const val SIDE_POCKET_FRACTION = 0.05f
        private const val CUSHION_HALF_WIDTH_FRACTION = 0.11f
        private const val CUSHION_TAPER_FRACTION = 0.7f
    }
}
