VoxelGame GPU Chunk Fix

Applied fixes:
- Prevent READY state when GPU allocation fails
- Invalid clusters now reset to EMPTY
- Invalid GPU offsets no longer render
- Added allocator failure logging
- Prevent permanent invisible chunk holes

Expected improvements:
- RD 12+ should no longer create permanent missing chunk regions
- MegaBuffer exhaustion handled more safely
- Failed uploads no longer create ghost chunks
