//! Draws the far terrain (see `lod`): each tile is one vertex buffer plus one index buffer, whose triangles are
//! stored quarter by quarter. The quarters that a finer tile covers are left out of the draw (a tile that has none
//! missing is a single draw call).
//!
//! The far terrain is drawn first, then the depth buffer is cleared and the real blocks are drawn over it, so it
//! only shows where there are no blocks: beyond the block world and wherever chunks have not loaded yet.

use std::collections::HashMap;
use std::os::raw::c_void;

use super::gl::*;
use super::shader::*;
use super::shaders::{FAR_FS, FAR_VS};
use crate::core::math::{Frustum, Mat4};
use crate::lod::{draw_runs, FarManager, FarTileData, TileKey, FAR_VERTEX_SIZE};

struct FarProg {
    prog: Program,
    view_proj: GLint,
    offset: GLint,
    fog_color: GLint,
    fog_start: GLint,
    fog_end: GLint,
}

struct GpuTile {
    vao: GLuint,
    vbo: GLuint,
    ibo: GLuint,
    quarter_starts: [u32; 5],
    min_y: f32,
    max_y: f32,
}

/// What a far-terrain draw did, for the debug log.
#[derive(Clone, Copy, Debug, Default)]
pub struct FarDrawn {
    pub tiles: u32,
    pub calls: u32,
    pub triangles: u64,
}

pub struct FarRenderer {
    prog: FarProg,
    tiles: HashMap<TileKey, GpuTile>,
    /// Scratch list reused every frame: the tiles to draw and their hole masks.
    visible: Vec<(TileKey, u8)>,
}

impl FarRenderer {
    /// Needs a current GL context. Fails (and the game goes on without far terrain) if the shader does not build.
    pub fn new() -> Result<FarRenderer, String> {
        let p = Program::new(FAR_VS, FAR_FS).map_err(|e| format!("far terrain {}", e))?;
        let prog = FarProg {
            view_proj: p.uniform("uViewProj"),
            offset: p.uniform("uOffset"),
            fog_color: p.uniform("uFogColor"),
            fog_start: p.uniform("uFogStart"),
            fog_end: p.uniform("uFogEnd"),
            prog: p,
        };
        Ok(FarRenderer { prog, tiles: HashMap::new(), visible: Vec::new() })
    }

    pub fn tile_count(&self) -> usize {
        self.tiles.len()
    }

    /// The GL context is gone: forget every handle.
    pub fn forget(&mut self) {
        self.tiles.clear();
    }

    pub fn remove(&mut self, key: TileKey) {
        if let Some(t) = self.tiles.remove(&key) {
            delete_vertex_array(t.vao);
            delete_buffer(t.vbo);
            delete_buffer(t.ibo);
        }
    }

    pub fn clear(&mut self) {
        let keys: Vec<TileKey> = self.tiles.keys().copied().collect();
        for k in keys {
            self.remove(k);
        }
    }

    /// Copies a finished tile into GPU buffers.
    pub fn upload(&mut self, tile: FarTileData) {
        self.remove(tile.key);
        let vao = gen_vertex_array();
        let vbo = gen_buffer();
        let ibo = gen_buffer();
        unsafe {
            glBindVertexArray(vao);
            glBindBuffer(GL_ARRAY_BUFFER, vbo);
            upload_buffer(GL_ARRAY_BUFFER, &tile.vertices, GL_STATIC_DRAW);
            let stride = FAR_VERTEX_SIZE as GLsizei;
            glEnableVertexAttribArray(0);
            glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, 0 as *const c_void);
            glEnableVertexAttribArray(1);
            glVertexAttribPointer(1, 4, GL_UNSIGNED_BYTE, GL_TRUE, stride, 12 as *const c_void);
            // the element buffer binding is part of the vertex array's state
            glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo);
            upload_buffer(GL_ELEMENT_ARRAY_BUFFER, &tile.indices, GL_STATIC_DRAW);
            glBindVertexArray(0);
            glBindBuffer(GL_ARRAY_BUFFER, 0);
            glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
        }
        self.tiles.insert(tile.key, GpuTile { vao, vbo, ibo, quarter_starts: tile.quarter_starts, min_y: tile.min_y, max_y: tile.max_y });
    }

    /// Draws every visible tile. `vp` and `frustum` are for the far-terrain projection (camera-relative
    /// coordinates), `cam` is the camera's world position.
    pub fn draw(&mut self, far: &FarManager, vp: &Mat4, frustum: &Frustum, cam: [f64; 3], fog_color: [f32; 3], fog_start: f32, fog_end: f32) -> FarDrawn {
        self.visible.clear();
        for (key, t) in self.tiles.iter() {
            let ox = (key.origin_x() as f64 - cam[0]) as f32;
            let oz = (key.origin_z() as f64 - cam[2]) as f32;
            let size = key.size() as f32;
            let min = [ox, t.min_y - cam[1] as f32, oz];
            let max = [ox + size, t.max_y - cam[1] as f32, oz + size];
            if !frustum.box_visible(min, max) {
                continue;
            }
            let mask = far.hole_mask(*key);
            if mask == 0b1111 {
                continue; // four finer tiles cover it
            }
            self.visible.push((*key, mask));
        }
        let mut drawn = FarDrawn::default();
        if self.visible.is_empty() {
            return drawn;
        }
        unsafe {
            glEnable(GL_DEPTH_TEST);
            glDepthFunc(GL_LEQUAL);
            glDepthMask(GL_TRUE);
            // every face of the far terrain is a front face seen from outside (the tops from above, the cliffs
            // from the low side), so the ones facing away can be skipped
            glEnable(GL_CULL_FACE);
            glCullFace(GL_BACK);
            glFrontFace(GL_CCW);
            glDisable(GL_BLEND);
            let p = &self.prog;
            p.prog.use_program();
            set_mat4(p.view_proj, vp);
            glUniform3f(p.fog_color, fog_color[0], fog_color[1], fog_color[2]);
            glUniform1f(p.fog_start, fog_start);
            glUniform1f(p.fog_end, fog_end);
            for (key, mask) in self.visible.iter() {
                let t = match self.tiles.get(key) {
                    Some(t) => t,
                    None => continue,
                };
                let ox = (key.origin_x() as f64 - cam[0]) as f32;
                let oz = (key.origin_z() as f64 - cam[2]) as f32;
                glUniform3f(p.offset, ox, -(cam[1] as f32), oz);
                glBindVertexArray(t.vao);
                let (runs, n) = draw_runs(&t.quarter_starts, *mask);
                for &(first, count) in runs[..n].iter() {
                    glDrawElements(GL_TRIANGLES, count as GLsizei, GL_UNSIGNED_SHORT, (first as usize * 2) as *const c_void);
                    drawn.calls += 1;
                    drawn.triangles += (count / 3) as u64;
                }
                drawn.tiles += 1;
            }
            glBindVertexArray(0);
        }
        drawn
    }
}
