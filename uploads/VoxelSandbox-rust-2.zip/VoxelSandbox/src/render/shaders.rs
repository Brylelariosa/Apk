//! GLSL ES 3.00 sources.

pub const TERRAIN_VS: &str = r#"#version 300 es
precision highp float;
layout(location = 0) in vec3 aPos;
layout(location = 1) in vec2 aUv;
layout(location = 2) in vec4 aColor;
layout(location = 3) in uvec4 aInfo;

uniform mat4 uViewProj;
uniform vec3 uOffset;

out vec3 vRel;
out vec2 vUv;
out vec4 vColor;
flat out uint vLayer;
flat out uint vMode;

void main() {
    vec3 rel = aPos + uOffset;
    vRel = rel;
    gl_Position = uViewProj * vec4(rel, 1.0);
    vUv = aUv;
    vColor = aColor;
    vLayer = aInfo.x;
    vMode = aInfo.y;
}
"#;

pub const TERRAIN_FS: &str = r#"#version 300 es
precision highp float;
precision highp sampler2DArray;

in vec3 vRel;
in vec2 vUv;
in vec4 vColor;
flat in uint vLayer;
flat in uint vMode;

uniform sampler2DArray uTex;
uniform vec3 uFogColor;
uniform float uFogStart;
uniform float uFogEnd;
uniform float uAlphaTest;

out vec4 fragColor;

void main() {
    vec4 t = texture(uTex, vec3(vUv, float(vLayer)));
    if (uAlphaTest > 0.5 && t.a < 0.5) discard;
    vec3 tint = vColor.rgb * 2.0;
    vec3 rgb = t.rgb;
    if (vMode == 1u) {
        rgb *= tint;
    } else if (vMode == 2u) {
        float m = clamp((1.0 - t.a) * 12.75, 0.0, 1.0);
        rgb *= mix(vec3(1.0), tint, m);
    }
    rgb *= vColor.a;
    float d = length(vRel);
    float f = clamp((d - uFogStart) / max(uFogEnd - uFogStart, 0.001), 0.0, 1.0);
    rgb = mix(rgb, uFogColor, f);
    fragColor = vec4(rgb, 1.0);
}
"#;

pub const WATER_FS: &str = r#"#version 300 es
precision highp float;
precision highp sampler2DArray;

in vec3 vRel;
in vec2 vUv;
in vec4 vColor;
flat in uint vLayer;
flat in uint vMode;

uniform sampler2DArray uTex;
uniform vec3 uFogColor;
uniform float uFogStart;
uniform float uFogEnd;
uniform float uTime;

out vec4 fragColor;

void main() {
    vec3 base = texture(uTex, vec3(vUv, float(vLayer))).rgb;
    float w1 = sin(vUv.x * 0.78539816 + uTime * 1.1);
    float w2 = sin(vUv.y * 1.57079633 - uTime * 0.8);
    float w3 = sin((vUv.x + vUv.y) * 0.39269908 + uTime * 0.6);
    float ripple = (w1 * w2 + w3) * 0.5;
    vec3 rgb = base * (0.90 + 0.07 * ripple) * vColor.a;
    rgb += vec3(0.10, 0.12, 0.14) * max(ripple, 0.0) * vColor.a;
    float d = length(vRel);
    float f = clamp((d - uFogStart) / max(uFogEnd - uFogStart, 0.001), 0.0, 1.0);
    rgb = mix(rgb, uFogColor, f);
    float alpha = mix(0.62, 1.0, f);
    fragColor = vec4(rgb, alpha);
}
"#;

/// Far terrain: coloured height-map tiles, shaded by the slope of each triangle (worked out in the fragment
/// shader from screen-space derivatives, so the tiles need no normals) and faded into the fog like the blocks.
pub const FAR_VS: &str = r#"#version 300 es
precision highp float;
layout(location = 0) in vec3 aPos;
layout(location = 1) in vec4 aColor;

uniform mat4 uViewProj;
uniform vec3 uOffset;

out vec3 vRel;
out vec3 vColor;

void main() {
    vec3 rel = aPos + uOffset;
    vRel = rel;
    vColor = aColor.rgb;
    gl_Position = uViewProj * vec4(rel, 1.0);
}
"#;

pub const FAR_FS: &str = r#"#version 300 es
precision highp float;

in vec3 vRel;
in vec3 vColor;

uniform vec3 uFogColor;
uniform float uFogStart;
uniform float uFogEnd;

out vec4 fragColor;

// The face shading is already in the vertex colours (the far terrain is built from flat faces), so all that is
// left is the fog.
void main() {
    float d = length(vRel);
    float f = clamp((d - uFogStart) / max(uFogEnd - uFogStart, 0.001), 0.0, 1.0);
    fragColor = vec4(mix(vColor, uFogColor, f), 1.0);
}
"#;

pub const LINE_VS: &str = r#"#version 300 es
precision highp float;
layout(location = 0) in vec3 aPos;
uniform mat4 uViewProj;
void main() {
    gl_Position = uViewProj * vec4(aPos, 1.0);
}
"#;

pub const LINE_FS: &str = r#"#version 300 es
precision highp float;
uniform vec4 uColor;
out vec4 fragColor;
void main() {
    fragColor = uColor;
}
"#;

pub const SKY_VS: &str = r#"#version 300 es
out vec2 vNdc;
void main() {
    vec2 corner = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));
    vNdc = corner * 2.0 - 1.0;
    gl_Position = vec4(vNdc, 1.0, 1.0);
}
"#;

pub const SKY_FS: &str = r#"#version 300 es
precision highp float;
in vec2 vNdc;
uniform vec3 uForward;
uniform vec3 uRight;
uniform vec3 uUp;
uniform vec2 uTan;
uniform vec3 uHorizon;
uniform vec3 uZenith;
uniform vec3 uSunDir;
out vec4 fragColor;
void main() {
    vec3 dir = normalize(uForward + uRight * (vNdc.x * uTan.x) + uUp * (vNdc.y * uTan.y));
    float h = clamp(dir.y, 0.0, 1.0);
    vec3 col = mix(uHorizon, uZenith, sqrt(h));
    float sd = dot(dir, uSunDir);
    if (sd > 0.6) {
        col += vec3(1.0, 0.90, 0.68) * (pow(sd, 1500.0) * 2.0 + pow(sd, 10.0) * 0.14);
    }
    fragColor = vec4(col, 1.0);
}
"#;

pub const CLOUD_VS: &str = r#"#version 300 es
precision highp float;
uniform mat4 uViewProj;
uniform vec3 uCam;
uniform float uCloudY;
uniform float uHalf;
out vec2 vWorldXZ;
out float vDist;
void main() {
    vec2 c = vec2(float(gl_VertexID & 1), float((gl_VertexID >> 1) & 1)) * 2.0 - 1.0;
    vec3 rel = vec3(c.x * uHalf, uCloudY - uCam.y, c.y * uHalf);
    vWorldXZ = rel.xz + uCam.xz;
    vDist = length(rel.xz);
    gl_Position = uViewProj * vec4(rel, 1.0);
}
"#;

pub const CLOUD_FS: &str = r#"#version 300 es
precision highp float;
in vec2 vWorldXZ;
in float vDist;
uniform float uTime;
uniform float uHalf;
out vec4 fragColor;

float hash(vec2 p) {
    p = fract(p * vec2(123.34, 456.21));
    p += dot(p, p + 45.32);
    return fract(p.x * p.y);
}

float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = hash(i);
    float b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0));
    float d = hash(i + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float fbm(vec2 p) {
    float v = 0.0;
    float a = 0.5;
    for (int i = 0; i < 4; i++) {
        v += a * noise(p);
        p *= 2.03;
        a *= 0.5;
    }
    return v;
}

void main() {
    vec2 p = vWorldXZ * 0.0032 + vec2(uTime * 0.0035, uTime * 0.0012);
    float n = fbm(p);
    float a = smoothstep(0.50, 0.68, n);
    float fade = 1.0 - smoothstep(0.55 * uHalf, 0.98 * uHalf, vDist);
    vec3 col = mix(vec3(0.80, 0.85, 0.93), vec3(1.0), smoothstep(0.52, 0.85, n));
    fragColor = vec4(col, a * 0.92 * fade);
}
"#;

pub const UI_VS: &str = r#"#version 300 es
precision highp float;
layout(location = 0) in vec2 aPos;
layout(location = 1) in vec2 aUv;
layout(location = 2) in vec4 aColor;
layout(location = 3) in float aLayer;
uniform mat4 uProj;
out vec2 vUv;
out vec4 vColor;
flat out float vLayer;
void main() {
    gl_Position = uProj * vec4(aPos, 0.0, 1.0);
    vUv = aUv;
    vColor = aColor;
    vLayer = aLayer;
}
"#;

pub const UI_FS: &str = r#"#version 300 es
precision highp float;
precision highp sampler2DArray;
in vec2 vUv;
in vec4 vColor;
flat in float vLayer;
uniform sampler2DArray uTex;
uniform sampler2D uFont;
out vec4 fragColor;
void main() {
    if (vLayer > -0.5) {
        fragColor = texture(uTex, vec3(vUv, vLayer)) * vColor;
    } else if (vLayer > -1.5) {
        fragColor = vColor;
    } else {
        fragColor = vec4(vColor.rgb, vColor.a * texture(uFont, vUv).a);
    }
}
"#;
