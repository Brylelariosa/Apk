//! Draws a frame: sky, clouds, the far terrain, the block world in four passes, the block outline and finally
//! the UI. The pieces live in their own modules: `chunks` (block meshes, culling), `far` (far terrain),
//! `target` (lower-resolution drawing) and `programs` (shaders).

use std::collections::VecDeque;
use std::ffi::CStr;
use std::os::raw::{c_char, c_void};
use std::time::Instant;

use super::chunks::{ChunkStore, CullStats, DrawList, DrawTotals};
use super::far::{FarDrawn, FarRenderer};
use super::gl::*;
use super::programs::*;
use super::shader::*;
use super::shaders::*;
use super::target::{scaled_size, SceneTarget};
use crate::core::math::{mat4_mul, mat4_ortho_pixels, mat4_perspective, mat4_view_dir, Frustum, Vec3};
use crate::diag::probe::{self, Counter, Stage};
use crate::mesh::ChunkMeshData;
use crate::tex::{self, cells};
use crate::ui::app::{App, CameraState, Screen};
use crate::ui::batch::{UiBatch, UI_VERTEX_SIZE};
use crate::ui::font;
use crate::world::pos::ChunkPos;

const FOV_DEGREES: f32 = 70.0;
const NEAR_PLANE: f32 = 0.1;
/// The far terrain is only ever seen beyond the block world, so it can use a much larger near plane, which keeps
/// the depth buffer precise out to 16 km.
const FAR_NEAR_PLANE: f32 = 8.0;
const HORIZON: [f32; 3] = [0.66, 0.79, 0.93];
const ZENITH: [f32; 3] = [0.27, 0.48, 0.85];
const UNDERWATER: [f32; 3] = [0.16, 0.36, 0.70];
const SUN: [f32; 3] = [0.5156, 0.4688, -0.6282];
const CLOUD_HEIGHT: f32 = 200.0;
const CLOUD_HALF: f32 = 3000.0;

/// How much of a frame the renderer may spend copying new meshes to the GPU (more while the loading screen is up).
const UPLOAD_BUDGET_NS: u64 = 2_500_000;
const UPLOAD_BUDGET_LOADING_NS: u64 = 14_000_000;
const UPLOAD_MAX_CHUNKS: usize = 12;
const UPLOAD_MAX_CHUNKS_LOADING: usize = 64;
const UPLOAD_MAX_TILES: usize = 6;
const UPLOAD_MAX_TILES_LOADING: usize = 24;
/// Sizes the GPU refused for the lower-resolution target are remembered (so it is not retried every frame).
const REFUSED_SIZES_KEPT: usize = 16;

/// What the renderer knows about the GPU, for the debug log.
#[derive(Clone, Debug, Default)]
pub struct GlInfo {
    pub vendor: String,
    pub renderer: String,
    pub version: String,
}

/// Numbers from the last frame for the debug log's one-second lines.
#[derive(Clone, Copy, Debug, Default)]
pub struct RenderGauges {
    pub gpu_chunks: u32,
    pub gpu_tiles: u32,
    /// The size the 3D world was drawn at (smaller than the screen when the resolution setting is below 100%).
    pub view_w: i32,
    pub view_h: i32,
    pub cull: CullStats,
    pub occlusion_searches: u64,
}

pub struct Renderer {
    ui: UiProg,
    world: Option<WorldGl>,
    far: Option<FarRenderer>,
    error: Option<String>,
    block_tex: GLuint,
    font_tex: GLuint,
    ui_vao: GLuint,
    ui_vbo: GLuint,
    line_vao: GLuint,
    line_vbo: GLuint,
    dummy_vao: GLuint,
    chunks: ChunkStore,
    draw_list: DrawList,
    pending: VecDeque<(ChunkPos, ChunkMeshData)>,
    target: Option<SceneTarget>,
    refused_sizes: Vec<(i32, i32)>,
    presents_checked: u32,
    time: f32,
    error_batch: UiBatch,
    info: GlInfo,
    gauges: RenderGauges,
}

fn create_block_texture() -> GLuint {
    let rgba = tex::build_layers_rgba();
    let mut id: GLuint = 0;
    unsafe {
        glGenTextures(1, &mut id as *mut GLuint);
        glBindTexture(GL_TEXTURE_2D_ARRAY, id);
        glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
        glTexImage3D(
            GL_TEXTURE_2D_ARRAY,
            0,
            GL_RGBA8,
            tex::TILE_SIZE as GLsizei,
            tex::TILE_SIZE as GLsizei,
            cells::TILE_COUNT as GLsizei,
            0,
            GL_RGBA,
            GL_UNSIGNED_BYTE,
            rgba.as_ptr() as *const c_void,
        );
        glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_MIN_FILTER, GL_NEAREST_MIPMAP_LINEAR);
        glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_WRAP_T, GL_REPEAT);
        glGenerateMipmap(GL_TEXTURE_2D_ARRAY);
    }
    id
}

fn create_font_texture() -> GLuint {
    let rgba = font::build_atlas();
    let mut id: GLuint = 0;
    unsafe {
        glGenTextures(1, &mut id as *mut GLuint);
        glBindTexture(GL_TEXTURE_2D, id);
        glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
        glTexImage2D(
            GL_TEXTURE_2D,
            0,
            GL_RGBA8,
            font::ATLAS_W as GLsizei,
            font::ATLAS_H as GLsizei,
            0,
            GL_RGBA,
            GL_UNSIGNED_BYTE,
            rgba.as_ptr() as *const c_void,
        );
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    }
    id
}

fn gl_string(name: GLenum) -> String {
    unsafe {
        let p = glGetString(name);
        if p.is_null() {
            return String::from("?");
        }
        CStr::from_ptr(p as *const c_char).to_string_lossy().to_string()
    }
}


fn push_box(out: &mut Vec<f32>, min: [f32; 3], max: [f32; 3]) {
    let c = |x: usize, y: usize, z: usize| -> [f32; 3] {
        [if x == 0 { min[0] } else { max[0] }, if y == 0 { min[1] } else { max[1] }, if z == 0 { min[2] } else { max[2] }]
    };
    let faces: [[[usize; 3]; 4]; 6] = [
        [[0, 0, 0], [1, 0, 0], [1, 1, 0], [0, 1, 0]],
        [[0, 0, 1], [1, 0, 1], [1, 1, 1], [0, 1, 1]],
        [[0, 0, 0], [0, 0, 1], [0, 1, 1], [0, 1, 0]],
        [[1, 0, 0], [1, 0, 1], [1, 1, 1], [1, 1, 0]],
        [[0, 0, 0], [1, 0, 0], [1, 0, 1], [0, 0, 1]],
        [[0, 1, 0], [1, 1, 0], [1, 1, 1], [0, 1, 1]],
    ];
    for f in faces.iter() {
        let idx = [0usize, 1, 2, 0, 2, 3];
        for &i in idx.iter() {
            let p = c(f[i][0], f[i][1], f[i][2]);
            out.extend_from_slice(&p);
        }
    }
}

/// The twelve edges of a box as thin boxes (a wireframe that is the same thickness on every screen).
fn outline_vertices(min: [f32; 3], max: [f32; 3], t: f32) -> Vec<f32> {
    let mut out = Vec::with_capacity(12 * 36 * 3);
    for axis in 0..3 {
        for a in 0..2 {
            for b in 0..2 {
                let mut lo = [0.0f32; 3];
                let mut hi = [0.0f32; 3];
                for k in 0..3 {
                    if k == axis {
                        lo[k] = min[k] - t;
                        hi[k] = max[k] + t;
                    } else {
                        let which = if (k + 3 - axis) % 3 == 1 { a } else { b };
                        let v = if which == 0 { min[k] } else { max[k] };
                        lo[k] = v - t;
                        hi[k] = v + t;
                    }
                }
                push_box(&mut out, lo, hi);
            }
        }
    }
    out
}


fn draw_sky(wg: &WorldGl, dummy_vao: GLuint, yaw: f32, pitch: f32, aspect: f32) {
    let cp = pitch.cos();
    let f = Vec3::new(cp * yaw.sin(), pitch.sin(), -cp * yaw.cos());
    let right = f.cross(Vec3::new(0.0, 1.0, 0.0)).normalized();
    let up = right.cross(f);
    let tan_half = (FOV_DEGREES.to_radians() * 0.5).tan();
    unsafe {
        glDisable(GL_DEPTH_TEST);
        glDepthMask(GL_FALSE);
        glDisable(GL_CULL_FACE);
        wg.sky.prog.use_program();
        glUniform3f(wg.sky.forward, f.x, f.y, f.z);
        glUniform3f(wg.sky.right, right.x, right.y, right.z);
        glUniform3f(wg.sky.up, up.x, up.y, up.z);
        glUniform2f(wg.sky.tan, tan_half * aspect, tan_half);
        glUniform3f(wg.sky.horizon, HORIZON[0], HORIZON[1], HORIZON[2]);
        glUniform3f(wg.sky.zenith, ZENITH[0], ZENITH[1], ZENITH[2]);
        glUniform3f(wg.sky.sun, SUN[0], SUN[1], SUN[2]);
        glBindVertexArray(dummy_vao);
        glDrawArrays(GL_TRIANGLES, 0, 3);
        glBindVertexArray(0);
        glDepthMask(GL_TRUE);
    }
}

fn bind_textures(block_tex: GLuint, font_tex: GLuint) {
    unsafe {
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D_ARRAY, block_tex);
        glActiveTexture(GL_TEXTURE1);
        glBindTexture(GL_TEXTURE_2D, font_tex);
        glActiveTexture(GL_TEXTURE0);
    }
}

impl Renderer {
    /// Needs a current GL context. Fails only if the UI itself cannot be drawn.
    pub fn new() -> Result<Renderer, String> {
        let info = GlInfo { vendor: gl_string(GL_VENDOR), renderer: gl_string(GL_RENDERER), version: gl_string(GL_VERSION) };
        crate::logi!("GL {} on {} ({})", info.version, info.renderer, info.vendor);
        let up = Program::new(UI_VS, UI_FS).map_err(|e| format!("ui {}", e))?;
        let ui = UiProg { proj: up.uniform("uProj"), tex: up.uniform("uTex"), font: up.uniform("uFont"), prog: up };
        let (world, error) = match WorldGl::new() {
            Ok(w) => (Some(w), None),
            Err(e) => {
                crate::loge!("world shaders failed: {}", e);
                (None, Some(e))
            }
        };
        let far = if world.is_some() {
            match FarRenderer::new() {
                Ok(f) => Some(f),
                Err(e) => {
                    // the game still works, it just cannot show anything beyond the block world
                    crate::loge!("far terrain disabled: {}", e);
                    None
                }
            }
        } else {
            None
        };
        let block_tex = create_block_texture();
        let font_tex = create_font_texture();

        let ui_vao = gen_vertex_array();
        let ui_vbo = gen_buffer();
        unsafe {
            glBindVertexArray(ui_vao);
            glBindBuffer(GL_ARRAY_BUFFER, ui_vbo);
            let stride = UI_VERTEX_SIZE as GLsizei;
            glEnableVertexAttribArray(0);
            glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, stride, 0 as *const c_void);
            glEnableVertexAttribArray(1);
            glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, stride, 8 as *const c_void);
            glEnableVertexAttribArray(2);
            glVertexAttribPointer(2, 4, GL_UNSIGNED_BYTE, GL_TRUE, stride, 16 as *const c_void);
            glEnableVertexAttribArray(3);
            glVertexAttribPointer(3, 1, GL_FLOAT, GL_FALSE, stride, 20 as *const c_void);
            glBindVertexArray(0);
        }
        let line_vao = gen_vertex_array();
        let line_vbo = gen_buffer();
        unsafe {
            glBindVertexArray(line_vao);
            glBindBuffer(GL_ARRAY_BUFFER, line_vbo);
            glEnableVertexAttribArray(0);
            glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 12, 0 as *const c_void);
            glBindVertexArray(0);
        }
        let dummy_vao = gen_vertex_array();

        let mut error_batch = UiBatch::new();
        if let Some(e) = error.as_ref() {
            let mut y = 20.0;
            error_batch.text(20.0, y, 3.0, "SHADER ERROR - WORLD NOT DRAWN", [255, 120, 120, 255]);
            y += 40.0;
            for line in e.lines().take(14) {
                let short: String = line.chars().take(70).collect();
                error_batch.text(20.0, y, 2.0, &short, [255, 255, 255, 255]);
                y += 20.0;
            }
        }

        Ok(Renderer {
            ui,
            world,
            far,
            error,
            block_tex,
            font_tex,
            ui_vao,
            ui_vbo,
            line_vao,
            line_vbo,
            dummy_vao,
            chunks: ChunkStore::new(),
            draw_list: DrawList::new(),
            pending: VecDeque::new(),
            target: None,
            refused_sizes: Vec::new(),
            presents_checked: 0,
            time: 0.0,
            error_batch,
            info,
            gauges: RenderGauges::default(),
        })
    }

    pub fn has_world_pipeline(&self) -> bool {
        self.world.is_some()
    }

    /// True when far terrain can be drawn (its shader built).
    pub fn has_far_terrain(&self) -> bool {
        self.far.is_some()
    }

    pub fn gl_info(&self) -> &GlInfo {
        &self.info
    }

    /// The numbers of the last frame, for the debug log.
    pub fn gauges(&self) -> RenderGauges {
        self.gauges
    }

    /// The GL context is gone: forget every handle (they are invalid anyway).
    pub fn forget_gpu_objects(&mut self) {
        self.chunks.forget();
        self.pending.clear();
        if let Some(f) = self.far.as_mut() {
            f.forget();
        }
        // the target's handles died with the context
        if let Some(t) = self.target.take() {
            std::mem::forget(t);
        }
    }

    /// Chooses whether the world is drawn into a smaller off-screen picture this frame; returns true if so (and
    /// the picture is then ready to draw into).
    fn choose_target(&mut self, width: i32, height: i32, percent: i32) -> bool {
        let (sw, sh) = scaled_size(width, height, percent);
        if percent >= 100 || (sw, sh) == (width, height) || self.refused_sizes.contains(&(sw, sh)) {
            if let Some(t) = self.target.take() {
                t.delete();
            }
            return false;
        }
        if let Some(t) = self.target.as_ref() {
            if t.size() == (sw, sh) {
                return true;
            }
        }
        if let Some(t) = self.target.take() {
            t.delete();
        }
        match SceneTarget::create(sw, sh) {
            Some(t) => {
                crate::logi!("drawing the world at {}x{} ({}% of {}x{})", sw, sh, percent, width, height);
                self.target = Some(t);
                self.presents_checked = 0;
                true
            }
            None => {
                if self.refused_sizes.len() >= REFUSED_SIZES_KEPT {
                    self.refused_sizes.clear();
                }
                self.refused_sizes.push((sw, sh));
                false
            }
        }
    }

    /// Brings the GPU's copies in line with the game: frees what was dropped and copies new meshes over, but
    /// only as many as fit the time budget so a burst of finished chunks cannot stall a frame.
    fn sync_meshes(&mut self, app: &mut App) {
        let _upload_time = probe::scope(Stage::Upload);
        let loading = app.screen == Screen::Loading;
        let mut uploaded_chunks = 0u64;
        let mut uploaded_bytes = 0u64;
        let mut uploaded_tiles = 0u64;
        match app.engine.as_mut() {
            Some(engine) => {
                // far terrain that the renderer cannot draw is not worth building
                engine.far_available = self.far.is_some();
                for p in engine.manager.take_removed() {
                    self.chunks.remove(p);
                }
                for up in engine.manager.take_uploads() {
                    self.pending.push_back(up);
                }
                if let Some(far) = self.far.as_mut() {
                    for key in engine.far.take_removed() {
                        far.remove(key);
                    }
                }
                let budget = if loading { UPLOAD_BUDGET_LOADING_NS } else { UPLOAD_BUDGET_NS };
                let start = Instant::now();
                let max_chunks = if loading { UPLOAD_MAX_CHUNKS_LOADING } else { UPLOAD_MAX_CHUNKS };
                while let Some((p, m)) = self.pending.pop_front() {
                    if !engine.manager.world.contains(p) {
                        continue; // unloaded while it waited
                    }
                    uploaded_bytes += self.chunks.upload(p, m) as u64;
                    uploaded_chunks += 1;
                    if uploaded_chunks as usize >= max_chunks || start.elapsed().as_nanos() as u64 > budget {
                        break;
                    }
                }
                if let Some(far) = self.far.as_mut() {
                    let max_tiles = if loading { UPLOAD_MAX_TILES_LOADING } else { UPLOAD_MAX_TILES };
                    while (uploaded_tiles as usize) < max_tiles {
                        // one at a time: a tile counts as present (and its parent leaves a hole for it) once taken
                        let mut ready = engine.far.take_ready(1);
                        let tile = match ready.pop() {
                            Some(t) => t,
                            None => break,
                        };
                        far.upload(tile);
                        uploaded_tiles += 1;
                        if start.elapsed().as_nanos() as u64 > budget {
                            break;
                        }
                    }
                }
            }
            None => {
                if !self.chunks.is_empty() {
                    self.chunks.clear();
                }
                if let Some(f) = self.far.as_mut() {
                    if f.tile_count() > 0 {
                        f.clear();
                    }
                }
                self.pending.clear();
            }
        }
        probe::count(Counter::UploadChunks, uploaded_chunks);
        probe::count(Counter::UploadBytes, uploaded_bytes);
        probe::count(Counter::UploadTiles, uploaded_tiles);
    }

    /// Draws one frame of `app` into the current surface (`width` x `height` pixels).
    pub fn render(&mut self, app: &mut App, width: i32, height: i32, dt: f32) {
        let _render_time = probe::scope(Stage::Render);
        self.time += dt;
        self.sync_meshes(app);
        self.chunks.set_occlusion(app.settings.occlusion_culling);

        let cam = app.camera();
        let sky = match cam {
            Some(c) if c.underwater => UNDERWATER,
            _ => HORIZON,
        };
        let world_on = app.world_visible() && cam.is_some() && self.world.is_some();
        let scaled = world_on && self.choose_target(width, height, app.settings.resolution_percent);
        unsafe {
            glViewport(0, 0, width, height);
            glDepthMask(GL_TRUE);
            glDisable(GL_BLEND);
            glClearColor(sky[0], sky[1], sky[2], 1.0);
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        }
        let mut view = (width, height);
        if scaled {
            if let Some(t) = self.target.as_ref() {
                t.bind();
                view = t.size();
                unsafe { glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT) };
            }
        }
        if world_on {
            if let Some(c) = cam {
                self.draw_world(app, &c, view.0, view.1);
            }
        } else if let Some(wg) = self.world.as_ref() {
            draw_sky(wg, self.dummy_vao, app.time * 0.05, 0.25, width as f32 / height.max(1) as f32);
        }
        if scaled {
            let mut ok = true;
            if let Some(t) = self.target.as_ref() {
                let check = self.presents_checked < 3;
                self.presents_checked += 1;
                ok = t.present(width, height, check);
            }
            if !ok {
                crate::logw!("copying the lower-resolution picture to the screen failed: drawing at full size from now on");
                if let Some(t) = self.target.take() {
                    self.refused_sizes.push(t.size());
                    t.delete();
                }
            }
        }
        self.gauges.view_w = view.0;
        self.gauges.view_h = view.1;
        self.gauges.gpu_chunks = self.chunks.len() as u32;
        self.gauges.gpu_tiles = self.far.as_ref().map(|f| f.tile_count() as u32).unwrap_or(0);
        self.gauges.occlusion_searches = self.chunks.searches;
        {
            let _ui_time = probe::scope(Stage::DrawUi);
            self.draw_ui(&app.ui, width, height);
            if self.error.is_some() {
                let batch = std::mem::take(&mut self.error_batch);
                self.draw_ui(&batch, width, height);
                self.error_batch = batch;
            }
        }
    }

    /// The world: sky, clouds, far terrain, then the blocks, the aim outline and the water. `width` x `height` is
    /// the size of the surface being drawn into.
    fn draw_world(&mut self, app: &App, cam: &CameraState, width: i32, height: i32) {
        let wg = match self.world.as_ref() {
            Some(w) => w,
            None => return,
        };
        let aspect = width as f32 / height.max(1) as f32;
        let fov = FOV_DEGREES.to_radians();
        let view_chunks = app.settings.render_distance as f32;
        let fog_end_clear = (view_chunks * 16.0 - 8.0).max(48.0);
        let (fog_start, fog_end, fog_color) = if cam.underwater {
            (0.0, 26.0, UNDERWATER)
        } else {
            (fog_end_clear * 0.55, fog_end_clear, HORIZON)
        };
        // far terrain is only drawn when the render distance reaches beyond the block world, and not under water
        let far_terrain = match app.engine.as_ref() {
            Some(e) => !cam.underwater && self.far.is_some() && e.far.active() && app.settings.far_terrain_wanted(),
            None => false,
        };
        // the block world only needs a depth range as deep as the real blocks go (see below), the rest is far terrain
        let far_plane = if far_terrain {
            let detail_blocks = app.settings.detail_radius() as f32 * 16.0;
            // farthest corner of the farthest chunk, counting the height the world can have
            ((detail_blocks + 16.0).powi(2) + 160.0 * 160.0).sqrt().max(96.0)
        } else {
            (fog_end * 1.08 + 24.0).max(64.0)
        };

        let cp = cam.pitch.cos();
        let forward = Vec3::new(cp * cam.yaw.sin(), cam.pitch.sin(), -cp * cam.yaw.cos());
        let view = mat4_view_dir(forward, Vec3::new(0.0, 1.0, 0.0));
        let vp = mat4_mul(&mat4_perspective(fov, aspect, NEAR_PLANE, far_plane), &view);
        let frustum = Frustum::from_matrix(&vp);

        // sky and clouds go behind everything
        if !cam.underwater {
            draw_sky(wg, self.dummy_vao, cam.yaw, cam.pitch, aspect);
            if app.settings.clouds {
                let vp_far = mat4_mul(&mat4_perspective(fov, aspect, 1.0, 9000.0), &view);
                unsafe {
                    glDisable(GL_DEPTH_TEST);
                    glDepthMask(GL_FALSE);
                    glDisable(GL_CULL_FACE);
                    glEnable(GL_BLEND);
                    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
                    wg.cloud.prog.use_program();
                    set_mat4(wg.cloud.view_proj, &vp_far);
                    glUniform3f(wg.cloud.cam, cam.x as f32, cam.y as f32, cam.z as f32);
                    glUniform1f(wg.cloud.cloud_y, CLOUD_HEIGHT);
                    glUniform1f(wg.cloud.half, CLOUD_HALF);
                    glUniform1f(wg.cloud.time, self.time);
                    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
                    glDisable(GL_BLEND);
                    glDepthMask(GL_TRUE);
                }
            }
        }

        // far terrain: drawn first with its own depth range, then the depth buffer is cleared so the blocks
        // always end up in front of it
        if far_terrain {
            if let (Some(far), Some(engine)) = (self.far.as_mut(), app.engine.as_ref()) {
                let _far_time = probe::scope(Stage::DrawFar);
                let far_end = fog_end * 1.05 + 64.0;
                let vp_far = mat4_mul(&mat4_perspective(fov, aspect, FAR_NEAR_PLANE, far_end), &view);
                let far_frustum = Frustum::from_matrix(&vp_far);
                let drawn: FarDrawn = far.draw(&engine.far, &vp_far, &far_frustum, [cam.x, cam.y, cam.z], fog_color, fog_start, fog_end);
                probe::count(Counter::TilesDrawn, drawn.tiles as u64);
                probe::count(Counter::DrawCalls, drawn.calls as u64);
                probe::count(Counter::Triangles, drawn.triangles);
                unsafe {
                    glDepthMask(GL_TRUE);
                    glClear(GL_DEPTH_BUFFER_BIT);
                }
            }
        }

        // what to draw, nearest first
        let stats = {
            let _cull_time = probe::scope(Stage::Cull);
            self.chunks.update_visibility(cam.x, cam.y, cam.z);
            self.draw_list.collect(&self.chunks, &frustum, [cam.x, cam.y, cam.z], far_plane + 24.0)
        };
        self.gauges.cull = stats;

        let mut totals = DrawTotals::default();
        {
            let _world_time = probe::scope(Stage::DrawWorld);
            bind_textures(self.block_tex, self.font_tex);
            unsafe {
                glEnable(GL_DEPTH_TEST);
                glDepthFunc(GL_LEQUAL);
                glDepthMask(GL_TRUE);
                glEnable(GL_CULL_FACE);
                glCullFace(GL_BACK);
                glFrontFace(GL_CCW);
                glDisable(GL_BLEND);

                let t = &wg.terrain;
                t.prog.use_program();
                set_mat4(t.view_proj, &vp);
                glUniform1i(t.tex, 0);
                glUniform3f(t.fog_color, fog_color[0], fog_color[1], fog_color[2]);
                glUniform1f(t.fog_start, fog_start);
                glUniform1f(t.fog_end, fog_end);
            }
            totals.add(self.draw_list.draw_solid(wg.terrain.offset, wg.terrain.alpha_test));

            // the block the player is aiming at
            if let Some(engine) = app.engine.as_ref() {
                if let Some(hit) = engine.last_hit {
                    if app.screen == Screen::Playing {
                        let min = [hit.bx as f32 - cam.x as f32 - 0.003, hit.by as f32 - cam.y as f32 - 0.003, hit.bz as f32 - cam.z as f32 - 0.003];
                        let max = [min[0] + 1.006, min[1] + 1.006, min[2] + 1.006];
                        let verts = outline_vertices(min, max, 0.012);
                        unsafe {
                            glEnable(GL_BLEND);
                            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
                            glDepthMask(GL_FALSE);
                            wg.line.prog.use_program();
                            set_mat4(wg.line.view_proj, &vp);
                            glUniform4f(wg.line.color, 0.0, 0.0, 0.0, 0.78);
                            glBindVertexArray(self.line_vao);
                            glBindBuffer(GL_ARRAY_BUFFER, self.line_vbo);
                            upload_buffer(GL_ARRAY_BUFFER, &verts, GL_STREAM_DRAW);
                            glDrawArrays(GL_TRIANGLES, 0, (verts.len() / 3) as GLsizei);
                            glBindVertexArray(0);
                            glDepthMask(GL_TRUE);
                            glDisable(GL_BLEND);
                        }
                    }
                }
            }

            // water last, far to near
            unsafe {
                glEnable(GL_BLEND);
                glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
                glDepthMask(GL_FALSE);
                glDisable(GL_CULL_FACE);
                let w = &wg.water;
                w.prog.use_program();
                set_mat4(w.view_proj, &vp);
                glUniform1i(w.tex, 0);
                glUniform3f(w.fog_color, fog_color[0], fog_color[1], fog_color[2]);
                glUniform1f(w.fog_start, fog_start);
                glUniform1f(w.fog_end, fog_end);
                glUniform1f(w.time, self.time);
            }
            totals.add(self.draw_list.draw_water(wg.water.offset));
            unsafe {
                glBindVertexArray(0);
                glDepthMask(GL_TRUE);
                glDisable(GL_BLEND);
            }
        }
        probe::count(Counter::ChunksDrawn, stats.drawn as u64);
        probe::count(Counter::DrawCalls, totals.calls as u64);
        probe::count(Counter::Triangles, totals.triangles);
    }

    fn draw_ui(&self, batch: &UiBatch, width: i32, height: i32) {
        if batch.verts.is_empty() {
            return;
        }
        bind_textures(self.block_tex, self.font_tex);
        unsafe {
            glDisable(GL_DEPTH_TEST);
            glDisable(GL_CULL_FACE);
            glDepthMask(GL_FALSE);
            glEnable(GL_BLEND);
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
            self.ui.prog.use_program();
            set_mat4(self.ui.proj, &mat4_ortho_pixels(width as f32, height as f32));
            glUniform1i(self.ui.tex, 0);
            glUniform1i(self.ui.font, 1);
            glBindVertexArray(self.ui_vao);
            glBindBuffer(GL_ARRAY_BUFFER, self.ui_vbo);
            upload_buffer(GL_ARRAY_BUFFER, &batch.verts, GL_STREAM_DRAW);
            glDrawArrays(GL_TRIANGLES, 0, batch.verts.len() as GLsizei);
            glBindVertexArray(0);
            glDepthMask(GL_TRUE);
            glDisable(GL_BLEND);
        }
    }
}
