//! The block-world meshes on the GPU: a store with one entry per chunk column, the list of what to draw this
//! frame (distance, frustum and occlusion culling down to 16-block-high sections) and the draw passes.

use std::os::raw::c_void;

use super::gl::*;
use super::shader::*;
use crate::core::fasthash::FastMap;
use crate::core::math::{Frustum, Overlap};
use crate::mesh::occlusion::{Column, Occlusion};
use crate::mesh::{ChunkMeshData, PASS_COUNT, PASS_CUTOUT, PASS_DOUBLE, PASS_OPAQUE, PASS_WATER, VERTEX_SIZE};
use crate::world::config::SECTIONS;
use crate::world::pos::ChunkPos;

/// Every section bit set.
const ALL_SECTIONS: u16 = 0xFFFF;
/// Faces never stick out of their section by more than this (water surfaces, plants).
const SECTION_SLACK: f32 = 0.5;

/// One chunk column's mesh in GPU memory.
pub struct GpuChunk {
    pos: ChunkPos,
    /// All zero for a column without anything to draw (it is kept for the occlusion search).
    vao: GLuint,
    vbo: GLuint,
    ibo: GLuint,
    starts: [[u32; SECTIONS + 1]; PASS_COUNT],
    vis: [u16; SECTIONS],
    min_y: f32,
    max_y: f32,
    /// Sections the occlusion search says can be seen (everything until a search has included this chunk).
    reach: u16,
    /// Sections that have anything to draw.
    filled: u16,
    triangles: u32,
    bytes: u32,
}

/// What the store holds, for the debug log.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct StoreStats {
    pub chunks: u32,
    pub with_geometry: u32,
    pub triangles: u64,
    pub bytes: u64,
}

pub struct ChunkStore {
    slots: Vec<Option<GpuChunk>>,
    free: Vec<u32>,
    index: FastMap<ChunkPos, u32>,
    /// Goes up whenever a chunk is added, replaced or removed.
    generation: u64,
    occlusion_on: bool,
    /// What the visible-section masks were last computed for: (generation, camera chunk x, z, camera section).
    searched_for: Option<(u64, i32, i32, usize)>,
    search: Occlusion,
    columns: Vec<Column>,
    column_slot: Vec<u32>,
    reach: Vec<u16>,
    /// How many searches have run (for the debug log).
    pub searches: u64,
}

impl Default for ChunkStore {
    fn default() -> ChunkStore {
        ChunkStore::new()
    }
}

impl ChunkStore {
    pub fn new() -> ChunkStore {
        ChunkStore {
            slots: Vec::new(),
            free: Vec::new(),
            index: FastMap::default(),
            generation: 0,
            occlusion_on: true,
            searched_for: None,
            search: Occlusion::new(),
            columns: Vec::new(),
            column_slot: Vec::new(),
            reach: Vec::new(),
            searches: 0,
        }
    }

    pub fn len(&self) -> usize {
        self.index.len()
    }

    pub fn is_empty(&self) -> bool {
        self.index.is_empty()
    }

    pub fn contains(&self, pos: ChunkPos) -> bool {
        self.index.contains_key(&pos)
    }

    pub fn stats(&self) -> StoreStats {
        let mut s = StoreStats::default();
        for g in self.slots.iter().flatten() {
            s.chunks += 1;
            if g.vao != 0 {
                s.with_geometry += 1;
            }
            s.triangles += g.triangles as u64;
            s.bytes += g.bytes as u64;
        }
        s
    }

    /// Turns occlusion culling on or off.
    pub fn set_occlusion(&mut self, on: bool) {
        if on == self.occlusion_on {
            return;
        }
        self.occlusion_on = on;
        self.searched_for = None;
        if !on {
            for g in self.slots.iter_mut().flatten() {
                g.reach = ALL_SECTIONS;
            }
        }
    }

    /// Copies a finished mesh into GPU buffers (replacing the chunk's old one). Returns the bytes uploaded.
    pub fn upload(&mut self, pos: ChunkPos, mesh: ChunkMeshData) -> usize {
        self.remove(pos);
        let mut filled = 0u16;
        for s in 0..SECTIONS {
            if (0..PASS_COUNT).any(|p| mesh.section_starts[p][s + 1] > mesh.section_starts[p][s]) {
                filled |= 1 << s;
            }
        }
        let (mut vao, mut vbo, mut ibo) = (0, 0, 0);
        let mut bytes = 0usize;
        if !mesh.is_empty() {
            vao = gen_vertex_array();
            vbo = gen_buffer();
            ibo = gen_buffer();
            unsafe {
                glBindVertexArray(vao);
                glBindBuffer(GL_ARRAY_BUFFER, vbo);
                upload_buffer(GL_ARRAY_BUFFER, &mesh.vertices, GL_STATIC_DRAW);
                glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo);
                upload_buffer(GL_ELEMENT_ARRAY_BUFFER, &mesh.indices, GL_STATIC_DRAW);
                let stride = VERTEX_SIZE as GLsizei;
                glEnableVertexAttribArray(0);
                glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, 0 as *const c_void);
                glEnableVertexAttribArray(1);
                glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, stride, 12 as *const c_void);
                glEnableVertexAttribArray(2);
                glVertexAttribPointer(2, 4, GL_UNSIGNED_BYTE, GL_TRUE, stride, 20 as *const c_void);
                glEnableVertexAttribArray(3);
                glVertexAttribIPointer(3, 4, GL_UNSIGNED_BYTE, stride, 24 as *const c_void);
                glBindVertexArray(0);
                glBindBuffer(GL_ARRAY_BUFFER, 0);
            }
            bytes = mesh.vertices.len() * VERTEX_SIZE + mesh.indices.len() * 4;
        }
        let chunk = GpuChunk {
            pos,
            vao,
            vbo,
            ibo,
            starts: mesh.section_starts,
            vis: mesh.vis,
            min_y: mesh.min_y,
            max_y: mesh.max_y,
            reach: ALL_SECTIONS,
            filled,
            triangles: (mesh.indices.len() / 3) as u32,
            bytes: bytes as u32,
        };
        let slot = match self.free.pop() {
            Some(i) => {
                self.slots[i as usize] = Some(chunk);
                i
            }
            None => {
                self.slots.push(Some(chunk));
                (self.slots.len() - 1) as u32
            }
        };
        self.index.insert(pos, slot);
        self.generation += 1;
        bytes
    }

    pub fn remove(&mut self, pos: ChunkPos) -> bool {
        let slot = match self.index.remove(&pos) {
            Some(s) => s,
            None => return false,
        };
        if let Some(g) = self.slots[slot as usize].take() {
            if g.vao != 0 {
                delete_vertex_array(g.vao);
                delete_buffer(g.vbo);
                delete_buffer(g.ibo);
            }
        }
        self.free.push(slot);
        self.generation += 1;
        true
    }

    pub fn clear(&mut self) {
        let positions: Vec<ChunkPos> = self.index.keys().copied().collect();
        for p in positions {
            self.remove(p);
        }
    }

    /// The GL context is gone: forget every handle (they are invalid anyway).
    pub fn forget(&mut self) {
        self.slots.clear();
        self.free.clear();
        self.index.clear();
        self.generation += 1;
        self.searched_for = None;
    }

    /// Works out which sections can be seen from the camera (occlusion culling). Does nothing when neither the
    /// camera's section nor the set of chunks has changed since the last call.
    pub fn update_visibility(&mut self, cam_x: f64, cam_y: f64, cam_z: f64) {
        if !self.occlusion_on {
            return;
        }
        let cx = (cam_x / 16.0).floor() as i32;
        let cz = (cam_z / 16.0).floor() as i32;
        let section = ((cam_y / 16.0).floor() as i32).max(0).min(SECTIONS as i32 - 1) as usize;
        let key = (self.generation, cx, cz, section);
        if self.searched_for == Some(key) {
            return;
        }
        self.searched_for = Some(key);
        self.searches += 1;
        self.columns.clear();
        self.column_slot.clear();
        for (i, slot) in self.slots.iter().enumerate() {
            if let Some(g) = slot {
                self.columns.push(Column { x: g.pos.x, z: g.pos.z, vis: g.vis });
                self.column_slot.push(i as u32);
            }
        }
        self.search.compute(cx, cz, section, &self.columns, &mut self.reach);
        for (k, &slot) in self.column_slot.iter().enumerate() {
            if let Some(g) = self.slots[slot as usize].as_mut() {
                g.reach = self.reach[k];
            }
        }
    }
}

/// One chunk that is going to be drawn.
struct Visible {
    off: [f32; 3],
    dist2: f32,
    vao: GLuint,
    ranges: [(u32, u32); PASS_COUNT],
}

/// What the culling did and what drawing cost, for the debug log.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct CullStats {
    /// Chunks looked at.
    pub considered: u32,
    /// Chunks in the draw list.
    pub drawn: u32,
    pub out_of_range: u32,
    pub out_of_view: u32,
    /// Chunks left out because the occlusion search found none of their sections visible.
    pub hidden: u32,
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct DrawTotals {
    pub calls: u32,
    pub triangles: u64,
}

impl DrawTotals {
    pub fn add(&mut self, other: DrawTotals) {
        self.calls += other.calls;
        self.triangles += other.triangles;
    }
}

/// The chunks to draw this frame, nearest first (reused from frame to frame so nothing is allocated).
#[derive(Default)]
pub struct DrawList {
    items: Vec<Visible>,
}

fn draw_range(first: u32, count: u32, totals: &mut DrawTotals) {
    if count > 0 {
        unsafe {
            glDrawElements(GL_TRIANGLES, count as GLsizei, GL_UNSIGNED_INT, (first as usize * 4) as *const c_void);
        }
        totals.calls += 1;
        totals.triangles += (count / 3) as u64;
    }
}

impl DrawList {
    pub fn new() -> DrawList {
        DrawList { items: Vec::new() }
    }

    pub fn len(&self) -> usize {
        self.items.len()
    }

    /// Picks the chunks to draw: within `reach` blocks of the camera, inside the view frustum, and (with
    /// occlusion culling) only the sections that can be seen. A column that is partly in view is cut down to
    /// the sections that are, and what is drawn from it is the run from its lowest to its highest such section.
    pub fn collect(&mut self, store: &ChunkStore, frustum: &Frustum, cam: [f64; 3], reach: f32) -> CullStats {
        let mut stats = CullStats::default();
        self.items.clear();
        let reach2 = reach * reach;
        for g in store.slots.iter().flatten() {
            if g.vao == 0 {
                continue;
            }
            stats.considered += 1;
            let ox = (g.pos.x as f64 * 16.0 - cam[0]) as f32;
            let oz = (g.pos.z as f64 * 16.0 - cam[2]) as f32;
            let oy = (0.0 - cam[1]) as f32;
            let cx = ox + 8.0;
            let cz = oz + 8.0;
            let d2 = cx * cx + cz * cz;
            if d2 > reach2 {
                stats.out_of_range += 1;
                continue;
            }
            let mut mask = g.filled & g.reach;
            if mask == 0 {
                stats.hidden += 1;
                continue;
            }
            match frustum.classify([ox, oy + g.min_y, oz], [ox + 16.0, oy + g.max_y, oz + 16.0]) {
                Overlap::Outside => {
                    stats.out_of_view += 1;
                    continue;
                }
                Overlap::Partial => {
                    // the whole column touches the frustum's edge: keep the sections that really do
                    let mut kept = 0u16;
                    for s in 0..SECTIONS {
                        if mask & (1 << s) == 0 {
                            continue;
                        }
                        let y0 = oy + (s * 16) as f32;
                        let min = [ox, y0 - SECTION_SLACK, oz];
                        let max = [ox + 16.0, y0 + 16.0 + SECTION_SLACK, oz + 16.0];
                        if frustum.classify(min, max) != Overlap::Outside {
                            kept |= 1 << s;
                        }
                    }
                    mask = kept;
                    if mask == 0 {
                        stats.out_of_view += 1;
                        continue;
                    }
                }
                Overlap::Inside => {}
            }
            let lo = mask.trailing_zeros() as usize;
            let hi = 15 - mask.leading_zeros() as usize;
            let mut ranges = [(0u32, 0u32); PASS_COUNT];
            for p in 0..PASS_COUNT {
                let first = g.starts[p][lo];
                ranges[p] = (first, g.starts[p][hi + 1] - first);
            }
            self.items.push(Visible { off: [ox, oy, oz], dist2: d2, vao: g.vao, ranges });
            stats.drawn += 1;
        }
        self.items.sort_unstable_by(|a, b| a.dist2.total_cmp(&b.dist2));
        stats
    }

    /// Opaque blocks, then leaves (alpha tested), then plants (alpha tested, both sides). The terrain program
    /// must already be in use.
    pub fn draw_solid(&self, offset: GLint, alpha_test: GLint) -> DrawTotals {
        let mut totals = DrawTotals::default();
        unsafe {
            glEnable(GL_CULL_FACE);
            glUniform1f(alpha_test, 0.0);
            for v in self.items.iter() {
                glUniform3f(offset, v.off[0], v.off[1], v.off[2]);
                glBindVertexArray(v.vao);
                draw_range(v.ranges[PASS_OPAQUE].0, v.ranges[PASS_OPAQUE].1, &mut totals);
            }
            glUniform1f(alpha_test, 1.0);
            for v in self.items.iter() {
                if v.ranges[PASS_CUTOUT].1 == 0 {
                    continue;
                }
                glUniform3f(offset, v.off[0], v.off[1], v.off[2]);
                glBindVertexArray(v.vao);
                draw_range(v.ranges[PASS_CUTOUT].0, v.ranges[PASS_CUTOUT].1, &mut totals);
            }
            glDisable(GL_CULL_FACE);
            for v in self.items.iter() {
                if v.ranges[PASS_DOUBLE].1 == 0 {
                    continue;
                }
                glUniform3f(offset, v.off[0], v.off[1], v.off[2]);
                glBindVertexArray(v.vao);
                draw_range(v.ranges[PASS_DOUBLE].0, v.ranges[PASS_DOUBLE].1, &mut totals);
            }
            glBindVertexArray(0);
        }
        totals
    }

    /// Water, far to near. The water program must already be in use, with blending on.
    pub fn draw_water(&self, offset: GLint) -> DrawTotals {
        let mut totals = DrawTotals::default();
        unsafe {
            for v in self.items.iter().rev() {
                if v.ranges[PASS_WATER].1 == 0 {
                    continue;
                }
                glUniform3f(offset, v.off[0], v.off[1], v.off[2]);
                glBindVertexArray(v.vao);
                draw_range(v.ranges[PASS_WATER].0, v.ranges[PASS_WATER].1, &mut totals);
            }
            glBindVertexArray(0);
        }
        totals
    }
}
