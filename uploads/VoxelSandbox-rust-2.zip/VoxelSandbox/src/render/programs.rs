//! The GLSL programs the world and the UI are drawn with, and the uniform locations they need.

use super::gl::*;
use super::shader::Program;
use super::shaders::*;

pub struct TerrainProg {
    pub prog: Program,
    pub view_proj: GLint,
    pub offset: GLint,
    pub tex: GLint,
    pub fog_color: GLint,
    pub fog_start: GLint,
    pub fog_end: GLint,
    pub alpha_test: GLint,
}

pub struct WaterProg {
    pub prog: Program,
    pub view_proj: GLint,
    pub offset: GLint,
    pub tex: GLint,
    pub fog_color: GLint,
    pub fog_start: GLint,
    pub fog_end: GLint,
    pub time: GLint,
}

pub struct SkyProg {
    pub prog: Program,
    pub forward: GLint,
    pub right: GLint,
    pub up: GLint,
    pub tan: GLint,
    pub horizon: GLint,
    pub zenith: GLint,
    pub sun: GLint,
}

pub struct CloudProg {
    pub prog: Program,
    pub view_proj: GLint,
    pub cam: GLint,
    pub cloud_y: GLint,
    pub half: GLint,
    pub time: GLint,
}

pub struct LineProg {
    pub prog: Program,
    pub view_proj: GLint,
    pub color: GLint,
}

pub struct UiProg {
    pub prog: Program,
    pub proj: GLint,
    pub tex: GLint,
    pub font: GLint,
}

pub struct WorldGl {
    pub terrain: TerrainProg,
    pub water: WaterProg,
    pub sky: SkyProg,
    pub cloud: CloudProg,
    pub line: LineProg,
}

impl WorldGl {
    pub fn new() -> Result<WorldGl, String> {
        let tp = Program::new(TERRAIN_VS, TERRAIN_FS).map_err(|e| format!("terrain {}", e))?;
        let terrain = TerrainProg {
            view_proj: tp.uniform("uViewProj"),
            offset: tp.uniform("uOffset"),
            tex: tp.uniform("uTex"),
            fog_color: tp.uniform("uFogColor"),
            fog_start: tp.uniform("uFogStart"),
            fog_end: tp.uniform("uFogEnd"),
            alpha_test: tp.uniform("uAlphaTest"),
            prog: tp,
        };
        let wp = Program::new(TERRAIN_VS, WATER_FS).map_err(|e| format!("water {}", e))?;
        let water = WaterProg {
            view_proj: wp.uniform("uViewProj"),
            offset: wp.uniform("uOffset"),
            tex: wp.uniform("uTex"),
            fog_color: wp.uniform("uFogColor"),
            fog_start: wp.uniform("uFogStart"),
            fog_end: wp.uniform("uFogEnd"),
            time: wp.uniform("uTime"),
            prog: wp,
        };
        let sp = Program::new(SKY_VS, SKY_FS).map_err(|e| format!("sky {}", e))?;
        let sky = SkyProg {
            forward: sp.uniform("uForward"),
            right: sp.uniform("uRight"),
            up: sp.uniform("uUp"),
            tan: sp.uniform("uTan"),
            horizon: sp.uniform("uHorizon"),
            zenith: sp.uniform("uZenith"),
            sun: sp.uniform("uSunDir"),
            prog: sp,
        };
        let cp = Program::new(CLOUD_VS, CLOUD_FS).map_err(|e| format!("cloud {}", e))?;
        let cloud = CloudProg {
            view_proj: cp.uniform("uViewProj"),
            cam: cp.uniform("uCam"),
            cloud_y: cp.uniform("uCloudY"),
            half: cp.uniform("uHalf"),
            time: cp.uniform("uTime"),
            prog: cp,
        };
        let lp = Program::new(LINE_VS, LINE_FS).map_err(|e| format!("line {}", e))?;
        let line = LineProg { view_proj: lp.uniform("uViewProj"), color: lp.uniform("uColor"), prog: lp };
        Ok(WorldGl { terrain, water, sky, cloud, line })
    }
}
