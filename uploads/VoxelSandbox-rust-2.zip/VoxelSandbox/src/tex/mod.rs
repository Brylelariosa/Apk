//! Block textures: the hand-made 16x16 tiles (decoded from palette tables) packed into the layers of a
//! GL texture array.

pub mod cells;
mod tiles_data;

use tiles_data::{TileSrc, TILE_SRCS};

pub const TILE_SIZE: usize = 16;
pub const TILE_PIXELS: usize = TILE_SIZE * TILE_SIZE;
/// How far the alpha of a tinted "fringe" texel (grass on the side of a soil block) is lowered, so the
/// shader can tell it from the soil. The shader reads `(1 - alpha) * 255 / MASK_ALPHA_DROP` as the mask.
pub const MASK_ALPHA_DROP: u32 = 20;

fn decode(src: &TileSrc) -> [u32; TILE_PIXELS] {
    let lut: Vec<u32> = src
        .palette
        .split(' ')
        .map(|p| 0xFF00_0000 | u32::from_str_radix(p, 16).unwrap_or(0))
        .collect();
    let mut out = [0u32; TILE_PIXELS];
    for (i, ch) in src.rows.chars().enumerate() {
        if i >= TILE_PIXELS {
            break;
        }
        if ch == '.' {
            continue;
        }
        let d = if ch <= '9' { (ch as i32) - ('0' as i32) } else { (ch as i32) - ('a' as i32) + 10 };
        if d >= 0 && (d as usize) < lut.len() {
            out[i] = lut[d as usize];
        }
    }
    out
}

/// The flat colour of the water tile (it is made in code, not decoded from a hand-made tile).
pub const WATER_RGB: [u32; 3] = [60, 116, 206];

/// The decoded hand-made tile of a layer as ARGB, or `None` for layers made in code (water, white) or unused.
pub fn tile_argb(cell: i32) -> Option<[u32; TILE_PIXELS]> {
    for src in TILE_SRCS.iter() {
        if src.cell as i32 == cell {
            return Some(decode(src));
        }
    }
    None
}

/// Mean colour of the opaque texels of a tile, per channel (integer mean, like the v15 game).
pub fn average_rgb(tile: &[u32; TILE_PIXELS]) -> [u32; 3] {
    let mut r = 0u32;
    let mut g = 0u32;
    let mut b = 0u32;
    let mut n = 0u32;
    for &p in tile.iter() {
        if (p >> 24) < 128 {
            continue;
        }
        r += (p >> 16) & 0xFF;
        g += (p >> 8) & 0xFF;
        b += p & 0xFF;
        n += 1;
    }
    if n == 0 {
        return [128, 128, 128];
    }
    [r / n, g / n, b / n]
}

fn is_grass_texel(argb: u32) -> bool {
    if (argb >> 24) < 128 {
        return false;
    }
    let g = ((argb >> 8) & 0xFF) as i32;
    let r = ((argb >> 16) & 0xFF) as i32;
    g >= r - 4
}

fn is_fringe_cell(cell: usize) -> bool {
    cell as i32 == cells::GRASS_SIDE || cell as i32 == cells::DRY_GRASS_SIDE || cell as i32 == cells::SWAMP_GRASS_SIDE
}

/// All layers as tightly packed RGBA8 (`TILE_COUNT * 16 * 16 * 4` bytes), ready for `glTexImage3D`.
pub fn build_layers_rgba() -> Vec<u8> {
    let mut out = vec![0u8; cells::TILE_COUNT * TILE_PIXELS * 4];
    for layer in 0..cells::TILE_COUNT {
        let mut px = [0u32; TILE_PIXELS];
        let cell = layer as i32;
        if cell == cells::WATER {
            for p in px.iter_mut() {
                *p = 0xFF00_0000 | (WATER_RGB[0] << 16) | (WATER_RGB[1] << 8) | WATER_RGB[2];
            }
        } else if cell == cells::WHITE {
            for p in px.iter_mut() {
                *p = 0xFFFF_FFFF;
            }
        } else if let Some(tile) = tile_argb(cell) {
            px = tile;
            if is_fringe_cell(layer) {
                for p in px.iter_mut() {
                    if is_grass_texel(*p) {
                        *p = ((255 - MASK_ALPHA_DROP) << 24) | (*p & 0x00FF_FFFF);
                    }
                }
            }
            // Transparent texels take the tile's mean colour, so mip-mapping does not bleed black into the edges.
            let mean = average_rgb(&px);
            let fill = (mean[0] << 16) | (mean[1] << 8) | mean[2];
            for p in px.iter_mut() {
                if (*p >> 24) == 0 {
                    *p = fill;
                }
            }
        }
        for (i, p) in px.iter().enumerate() {
            let o = (layer * TILE_PIXELS + i) * 4;
            out[o] = ((*p >> 16) & 0xFF) as u8;
            out[o + 1] = ((*p >> 8) & 0xFF) as u8;
            out[o + 2] = (*p & 0xFF) as u8;
            out[o + 3] = ((*p >> 24) & 0xFF) as u8;
        }
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn every_source_tile_decodes_inside_the_array() {
        for src in TILE_SRCS.iter() {
            assert!(src.cell < cells::TILE_COUNT, "tile {} out of range", src.name);
            assert_eq!(src.rows.len(), TILE_PIXELS, "tile {} has the wrong size", src.name);
        }
    }

    #[test]
    fn layer_buffer_has_the_right_size() {
        assert_eq!(build_layers_rgba().len(), cells::TILE_COUNT * TILE_PIXELS * 4);
    }

    #[test]
    fn grass_tiles_have_a_colour() {
        let t = tile_argb(cells::GRASS_TOP).unwrap();
        let m = average_rgb(&t);
        assert!(m[1] > m[0]);
    }
}
