//! Where the far-terrain tiles are. Far terrain is a "clipmap": several levels of square tiles around the
//! player, each level with cells twice as big as the one before and tiles twice as large, so detail drops with
//! distance and the whole thing needs only a few dozen tiles to reach 16 kilometres.
//!
//! * level `k` has cells of `8 << k` blocks; a tile is `CELLS` x `CELLS` cells, so it is `256 << k` blocks wide;
//! * level `k` keeps a 5 x 5 window of tiles around the player (so it always reaches at least 2 tiles away);
//! * a tile of level `k` is made of four quarters, each of which is exactly one tile of level `k - 1`. Where the
//!   finer tile exists, the quarter of the coarser tile under it is left out (see `mesh::draw_runs`).

/// Levels of detail. Level 5 reaches 16 384 blocks, a little over the largest render distance (1000 chunks).
pub const LEVELS: usize = 6;
/// Cells along one side of a tile.
pub const CELLS: usize = 32;
/// Vertices along one side of a tile.
pub const VERTS: usize = CELLS + 1;
/// Cell size, in blocks, of the finest level.
pub const BASE_CELL: i32 = 8;
/// A level wants the tiles up to this many tiles away from the one the player is in (a 5 x 5 window).
pub const WINDOW_RADIUS: i32 = 2;
/// Tiles stay loaded until they are this far (in tiles) from the player's tile; a little more than the window
/// so that walking back and forth over a tile edge does not rebuild tiles over and over.
pub const KEEP_RADIUS: i32 = 3;

pub fn cell_size(level: usize) -> i32 {
    BASE_CELL << level
}

/// Width of a tile, in blocks.
pub fn tile_size(level: usize) -> i32 {
    (CELLS as i32 * BASE_CELL) << level
}

/// Distance (blocks) from the player that the window of a level always covers, wherever in its tile the player is.
pub fn guaranteed_reach(level: usize) -> f32 {
    (WINDOW_RADIUS * tile_size(level)) as f32
}

/// How many levels are needed to see `view_blocks` far (0 when nothing is to be seen).
pub fn levels_needed(view_blocks: f32) -> usize {
    if view_blocks <= 0.0 {
        return 0;
    }
    for level in 0..LEVELS {
        if guaranteed_reach(level) >= view_blocks {
            return level + 1;
        }
    }
    LEVELS
}

/// One tile: its level and its position on that level's grid (tile `tx` covers `tx * size .. (tx + 1) * size`).
#[derive(Clone, Copy, PartialEq, Eq, Hash, Debug, PartialOrd, Ord)]
pub struct TileKey {
    pub level: u8,
    pub tx: i32,
    pub tz: i32,
}

impl TileKey {
    pub fn new(level: usize, tx: i32, tz: i32) -> TileKey {
        TileKey { level: level as u8, tx, tz }
    }

    pub fn level(self) -> usize {
        self.level as usize
    }

    pub fn size(self) -> i32 {
        tile_size(self.level())
    }

    pub fn cell(self) -> i32 {
        cell_size(self.level())
    }

    /// World x of the tile's west edge.
    pub fn origin_x(self) -> i64 {
        self.tx as i64 * self.size() as i64
    }

    /// World z of the tile's north edge.
    pub fn origin_z(self) -> i64 {
        self.tz as i64 * self.size() as i64
    }

    /// The tile of the next finer level that fills quarter (`qx`, `qz`) of this one (each 0 or 1).
    pub fn child(self, qx: i32, qz: i32) -> TileKey {
        TileKey { level: self.level.saturating_sub(1), tx: self.tx * 2 + qx, tz: self.tz * 2 + qz }
    }

    /// Distance from the point (`x`, `z`) to the nearest edge of the tile (0 inside it).
    pub fn min_distance(self, x: f64, z: f64) -> f64 {
        let size = self.size() as f64;
        let x0 = self.origin_x() as f64;
        let z0 = self.origin_z() as f64;
        let dx = (x0 - x).max(x - (x0 + size)).max(0.0);
        let dz = (z0 - z).max(z - (z0 + size)).max(0.0);
        (dx * dx + dz * dz).sqrt()
    }
}

/// The tile of `level` that contains the point (`x`, `z`).
pub fn tile_containing(level: usize, x: f64, z: f64) -> (i32, i32) {
    let size = tile_size(level) as f64;
    ((x / size).floor() as i32, (z / size).floor() as i32)
}

/// Bit of quarter (`qx`, `qz`) in a hole mask.
pub fn quarter_bit(qx: i32, qz: i32) -> u8 {
    1u8 << (qx + 2 * qz)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn each_level_doubles_the_cell_and_the_tile() {
        assert_eq!(cell_size(0), 8);
        assert_eq!(tile_size(0), 256);
        for l in 1..LEVELS {
            assert_eq!(cell_size(l), cell_size(l - 1) * 2);
            assert_eq!(tile_size(l), tile_size(l - 1) * 2);
        }
        assert_eq!(tile_size(0) as usize, CELLS * cell_size(0) as usize);
    }

    #[test]
    fn six_levels_reach_the_largest_render_distance() {
        assert_eq!(levels_needed(0.0), 0);
        assert_eq!(levels_needed(100.0), 1);
        assert_eq!(levels_needed(512.0), 1);
        assert_eq!(levels_needed(513.0), 2);
        assert_eq!(levels_needed(1000.0 * 16.0), LEVELS, "1000 chunks");
        assert!(guaranteed_reach(LEVELS - 1) >= 1000.0 * 16.0);
        assert_eq!(levels_needed(1.0e9), LEVELS);
    }

    #[test]
    fn a_tile_is_exactly_four_tiles_of_the_finer_level() {
        for l in 1..LEVELS {
            let t = TileKey::new(l, -3, 5);
            for qz in 0..2 {
                for qx in 0..2 {
                    let c = t.child(qx, qz);
                    assert_eq!(c.level(), l - 1);
                    assert_eq!(c.origin_x(), t.origin_x() + qx as i64 * c.size() as i64);
                    assert_eq!(c.origin_z(), t.origin_z() + qz as i64 * c.size() as i64);
                    assert_eq!(c.size() * 2, t.size());
                }
            }
        }
    }

    #[test]
    fn tiles_are_found_by_floor_division_so_negatives_work() {
        assert_eq!(tile_containing(0, 0.0, 0.0), (0, 0));
        assert_eq!(tile_containing(0, 255.9, 256.0), (0, 1));
        assert_eq!(tile_containing(0, -0.1, -256.1), (-1, -2));
        assert_eq!(tile_containing(3, -1.0, 2047.0), (-1, 0));
    }

    #[test]
    fn distance_to_a_tile_is_zero_inside_and_euclidean_outside() {
        let t = TileKey::new(0, 1, 0); // x 256..512, z 0..256
        assert_eq!(t.min_distance(300.0, 100.0), 0.0);
        assert_eq!(t.min_distance(256.0, 0.0), 0.0);
        assert!((t.min_distance(256.0 - 30.0, 100.0) - 30.0).abs() < 1e-9);
        assert!((t.min_distance(512.0 + 30.0, 256.0 + 40.0) - 50.0).abs() < 1e-9);
    }

    #[test]
    fn quarter_bits_are_distinct() {
        let mut seen = 0u8;
        for qz in 0..2 {
            for qx in 0..2 {
                let b = quarter_bit(qx, qz);
                assert_eq!(seen & b, 0);
                seen |= b;
            }
        }
        assert_eq!(seen, 0b1111);
    }
}
