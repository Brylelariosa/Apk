//! Reads the terrain generator to fill the cells of a far-terrain tile: ground height and ground colour at the
//! middle of every cell, taken from the same land-form and climate functions the real chunks are generated from, so
//! the far hills line up with the real ones. Nothing here touches OpenGL, so it runs (and is tested) on a normal
//! computer.

use std::sync::Arc;

use super::cells::{cell_noise, Cell, CellGrid, GRID};
use super::mesh::{build_tile_mesh, FarTileData};
use super::tiles::{TileKey, CELLS};
use crate::gen::climate::{Biome, SurfaceKind};
use crate::gen::terrain::TerrainGenerator;
use crate::mesh::biome_color::{BiomeColorField, BiomePalette};
use crate::tex::{self, cells, WATER_RGB};
use crate::world::config::SEA_LEVEL;

const SEA: f64 = SEA_LEVEL as f64;
/// Where the far sea surface is: a little below the top of a block, like the real water.
pub const WATER_TOP: f32 = SEA_LEVEL as f32 - 0.125;
/// Darkest forest: how much of the ground colour is left under a closed canopy.
const FOREST_DARKEN: f32 = 0.42;
/// How much darker than the ground colour a column's top can be (each column gets its own amount, so the columns
/// read as separate blocks).
const LAND_VARIATION: f32 = 0.10;
/// Sea depth is rounded to steps of this many blocks, so that stretches of sea of one depth share one colour.
const DEPTH_STEP: f32 = 2.0;
const DEPTH_STEPS: f32 = 12.0;
/// Where inside a cell of the finest level the ground is also looked at (fractions of the cell from its middle).
const PROBES: [(f64, f64); 4] = [(-0.25, -0.25), (0.25, -0.25), (-0.25, 0.25), (0.25, 0.25)];

/// Average colours of the ground tiles (0..255).
#[derive(Clone, Copy, Debug)]
struct GroundColors {
    sand: [f32; 3],
    gravel: [f32; 3],
    stone: [f32; 3],
    snow: [f32; 3],
    dirt: [f32; 3],
    water: [f32; 3],
}

fn tile_mean(cell: i32) -> [f32; 3] {
    match tex::tile_argb(cell) {
        Some(t) => {
            let m = tex::average_rgb(&t);
            [m[0] as f32, m[1] as f32, m[2] as f32]
        }
        None => [128.0, 128.0, 128.0],
    }
}

impl GroundColors {
    fn from_tiles() -> GroundColors {
        GroundColors {
            sand: tile_mean(cells::SAND),
            gravel: tile_mean(cells::GRAVEL),
            stone: tile_mean(cells::STONE),
            snow: tile_mean(cells::SNOW),
            dirt: tile_mean(cells::DIRT),
            water: [WATER_RGB[0] as f32, WATER_RGB[1] as f32, WATER_RGB[2] as f32],
        }
    }
}

fn mix(a: [f32; 3], b: [f32; 3], t: f32) -> [f32; 3] {
    let t = t.max(0.0).min(1.0);
    [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t]
}

fn scale(a: [f32; 3], k: f32) -> [f32; 3] {
    [a[0] * k, a[1] * k, a[2] * k]
}

fn to_bytes(c: [f32; 3]) -> [u8; 3] {
    let b = |v: f32| v.max(0.0).min(255.0).round() as u8;
    [b(c[0]), b(c[1]), b(c[2])]
}

/// What the ground of one land column looks like.
struct Ground {
    top: [f32; 3],
    wall: [f32; 3],
}

/// World coordinate of the middle of cell number `index` of a level whose cells are `cell` blocks wide.
fn cell_middle(index: i64, cell: f64) -> f64 {
    (index as f64 + 0.5) * cell
}

pub struct FarSampler {
    gen: Arc<TerrainGenerator>,
    field: BiomeColorField,
    colors: GroundColors,
}

impl FarSampler {
    pub fn new(gen: Arc<TerrainGenerator>) -> FarSampler {
        let field = BiomeColorField::new(gen.climate.clone(), gen.shape.clone(), BiomePalette::from_tiles());
        FarSampler { gen, field, colors: GroundColors::from_tiles() }
    }

    /// Colour of the sea over a sea floor `h` blocks high: a blend of the floor and the water colour, darker and
    /// less see-through where it is deep, in a few steps of depth.
    fn sea_color(&self, h: f64) -> [u8; 3] {
        let c = &self.colors;
        let step = (((SEA - h) as f32) / DEPTH_STEP).floor().max(0.0).min(DEPTH_STEPS);
        let depth = step * DEPTH_STEP + DEPTH_STEP * 0.5;
        let shallow = 1.0 - (depth / 10.0).min(1.0);
        let floor = mix(scale(c.gravel, 0.55), c.sand, shallow);
        let tint = scale(c.water, 0.95 - 0.28 * (depth / 20.0).min(1.0));
        to_bytes(mix(floor, tint, 0.62 + 0.28 * (1.0 - shallow)))
    }

    /// Colours of a land column. `slope` is rise over run of the surrounding ground.
    fn ground(&self, wx: f64, wz: f64, h: f64, coast: f64, slope: f64) -> Ground {
        let climate = &self.gen.climate;
        let c = &self.colors;
        let ground = h.floor();
        let t0 = climate.base_temperature(wx, wz);
        let hum = climate.humidity(wx, wz);
        let biome = climate.biome_with(wx, wz, ground, slope, coast, t0, hum);
        let kind = climate.surface_for(biome, wx, wz, ground, slope);
        let (mut top, mut wall) = match kind {
            SurfaceKind::Grass | SurfaceKind::DryGrass | SurfaceKind::Swamp => {
                let grass = self.field.grass(wx, wz, h, coast, t0, hum);
                // the side of a step in grass land is mostly the dirt under the grass
                (grass, mix(grass, c.dirt, 0.6))
            }
            SurfaceKind::Desert | SurfaceKind::Beach => (c.sand, scale(c.sand, 0.96)),
            SurfaceKind::Snow => (c.snow, mix(c.snow, c.dirt, 0.45)),
            SurfaceKind::Rock => (scale(c.stone, 0.95), scale(c.stone, 0.85)),
            SurfaceKind::Gravel => (c.gravel, scale(c.gravel, 0.9)),
        };
        // Trees: a forest is a dark green carpet from far away.
        let trees = self.gen.tree_density(biome);
        if trees > 0.0 && kind != SurfaceKind::Rock && kind != SurfaceKind::Gravel {
            let cover = (climate.forest(wx, wz) * trees) as f32;
            if cover > 0.0 {
                let canopy = |rgb: [f32; 3]| {
                    if kind == SurfaceKind::Snow {
                        [44.0, 74.0, 52.0]
                    } else if biome == Biome::Taiga {
                        [rgb[0] * 0.45, rgb[1] * 0.62, rgb[2] * 0.5]
                    } else {
                        scale(rgb, FOREST_DARKEN)
                    }
                };
                top = mix(top, canopy(top), 0.8 * cover);
                wall = mix(wall, canopy(wall), 0.8 * cover);
            }
        }
        Ground { top, wall }
    }

    /// The columns of a tile and the ring of columns around it.
    pub fn sample_grid(&self, key: TileKey) -> CellGrid {
        let level = key.level();
        let lod = level as i32;
        let cell = key.cell() as f64;
        let first_x = key.tx as i64 * CELLS as i64;
        let first_z = key.tz as i64 * CELLS as i64;
        let shape = &self.gen.shape;
        // Heights at the middle of every cell (smooth, for colours and slopes) and the lowest height the column
        // should stand on.
        let mut middle = vec![0.0f32; GRID * GRID];
        let mut lowest = vec![0.0f32; GRID * GRID];
        let mut coast = vec![0.0f32; GRID * GRID];
        for gz in 0..GRID {
            for gx in 0..GRID {
                let wx = cell_middle(first_x + gx as i64 - 1, cell);
                let wz = cell_middle(first_z + gz as i64 - 1, cell);
                let (h, c) = shape.height_and_coast(wx, wz, lod);
                let mut low = h;
                if level == 0 {
                    // The real blocks of the finest level are drawn over these columns, so a column must not stand
                    // higher than the blocks it stands for: use the lowest of a few spots.
                    for (dx, dz) in PROBES.iter() {
                        low = low.min(shape.height(wx + dx * cell, wz + dz * cell, 0));
                    }
                }
                let i = gz * GRID + gx;
                middle[i] = h as f32;
                lowest[i] = low as f32;
                coast[i] = c as f32;
            }
        }
        let mut grid = CellGrid::filled(Cell::land(0.0, [0; 3], [0; 3]));
        for gz in 0..GRID {
            for gx in 0..GRID {
                let i = gz * GRID + gx;
                let (cx, cz) = (gx as i32 - 1, gz as i32 - 1);
                let inside = gx >= 1 && gx <= CELLS && gz >= 1 && gz <= CELLS;
                let h = middle[i] as f64;
                if h < SEA {
                    let color = if inside { self.sea_color(h) } else { [0; 3] };
                    grid.set(cx, cz, Cell::sea(WATER_TOP, color));
                    continue;
                }
                // A block's top face is at floor(height) + 1; the column is one block lower, and never lower than
                // the shore, so that the sea is always the lower of the two.
                let top = lowest[i].floor().max(SEA_LEVEL as f32 + 1.0);
                if !inside {
                    grid.set(cx, cz, Cell::land(top, [0; 3], [0; 3]));
                    continue;
                }
                let dx = (middle[i + 1] - middle[i - 1]) as f64 / (2.0 * cell);
                let dz = (middle[i + GRID] - middle[i - GRID]) as f64 / (2.0 * cell);
                // heights taken over a whole cell look flatter than the real ground, which has block-sized detail
                let slope_gain = if level >= 2 { 1.4 } else { 1.0 };
                let slope = (dx * dx + dz * dz).sqrt() * slope_gain;
                let wx = cell_middle(first_x + cx as i64, cell);
                let wz = cell_middle(first_z + cz as i64, cell);
                let ground = self.ground(wx, wz, h, coast[i] as f64, slope);
                let k = 1.0 - LAND_VARIATION * cell_noise(level, first_x + cx as i64, first_z + cz as i64);
                grid.set(cx, cz, Cell::land(top, to_bytes(scale(ground.top, k)), to_bytes(scale(ground.wall, k))));
            }
        }
        grid
    }

    /// The finished tile.
    pub fn build_tile(&self, key: TileKey) -> FarTileData {
        build_tile_mesh(key, &self.sample_grid(key))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::time::Instant;

    fn sampler(seed: i64) -> FarSampler {
        FarSampler::new(Arc::new(TerrainGenerator::new(seed)))
    }

    #[test]
    fn neighbouring_tiles_agree_exactly_about_the_cells_along_their_shared_edge() {
        let s = sampler(3);
        for level in [0usize, 2, 4] {
            let a = s.sample_grid(TileKey::new(level, 4, -2));
            let b = s.sample_grid(TileKey::new(level, 5, -2));
            let n = CELLS as i32;
            for cz in 0..n {
                // the ring of one tile is the edge row of the other
                assert_eq!(a.get(n, cz).top, b.get(0, cz).top, "east seam, level {} row {}", level, cz);
                assert_eq!(a.get(n, cz).water, b.get(0, cz).water);
                assert_eq!(b.get(-1, cz).top, a.get(n - 1, cz).top, "west seam, level {} row {}", level, cz);
                assert_eq!(b.get(-1, cz).water, a.get(n - 1, cz).water);
            }
            let c = s.sample_grid(TileKey::new(level, 4, -1));
            for cx in 0..n {
                assert_eq!(a.get(cx, n).top, c.get(cx, 0).top, "south seam, level {} column {}", level, cx);
                assert_eq!(c.get(cx, -1).top, a.get(cx, n - 1).top, "north seam, level {} column {}", level, cx);
            }
        }
    }

    #[test]
    fn building_a_tile_twice_gives_the_same_triangles() {
        let s = sampler(4);
        let k = TileKey::new(1, 3, 3);
        let (a, b) = (s.build_tile(k), s.build_tile(k));
        assert_eq!(a.vertices, b.vertices);
        assert_eq!(a.indices, b.indices);
        assert_eq!(a.quarter_starts, b.quarter_starts);
    }

    #[test]
    fn a_tile_has_triangles_in_every_quarter_and_a_sensible_height_range() {
        let s = sampler(1);
        let t = s.build_tile(TileKey::new(0, 0, 0));
        for q in 0..4 {
            assert!(t.quarter_starts[q + 1] > t.quarter_starts[q], "quarter {} is empty", q);
        }
        assert!(t.min_y < t.max_y);
        assert!(t.vertices.iter().all(|v| v.pos[1] >= t.min_y && v.pos[1] <= t.max_y));
        assert!(t.vertices.iter().all(|v| v.color[3] == 255));
        assert!(t.indices.iter().all(|&i| (i as usize) < t.vertices.len()));
    }

    #[test]
    fn vertex_positions_are_blocks_from_the_tiles_corner() {
        let s = sampler(2);
        let t = s.build_tile(TileKey::new(2, -1, 3)); // cell 32, tile 1024 wide
        // sea quads are grown a little past their cells (see `mesh::sea_grow`), everything else is on the grid
        let slack = 0.2;
        for v in t.vertices.iter() {
            assert!(v.pos[0] >= -slack && v.pos[0] <= 1024.0 + slack && v.pos[2] >= -slack && v.pos[2] <= 1024.0 + slack, "{:?}", v.pos);
            for axis in [0usize, 2] {
                let m = v.pos[axis] % 32.0;
                assert!(m.min(32.0 - m) <= slack, "{:?} is off the 32-block grid", v.pos);
            }
        }
    }

    #[test]
    fn the_far_columns_never_stand_higher_than_the_real_ground_of_level_zero() {
        let gen = Arc::new(TerrainGenerator::new(5));
        let s = FarSampler::new(gen.clone());
        let key = TileKey::new(0, 1, 1);
        let g = s.sample_grid(key);
        let mut checked = 0;
        for cz in (0..CELLS as i32).step_by(3) {
            for cx in (0..CELLS as i32).step_by(3) {
                let c = g.get(cx, cz);
                // the middle of the cell, as a block column
                let wx = 256 + cx * 8 + 4;
                let wz = 256 + cz * 8 + 4;
                let real = gen.surface_height(wx, wz);
                if real < SEA_LEVEL {
                    assert!(c.water, "({}, {}) is sea in the real world", wx, wz);
                    assert_eq!(c.top, WATER_TOP);
                } else {
                    assert!(!c.water, "({}, {}) is land in the real world", wx, wz);
                    // the real top face is at real + 1; despiking can move a column by a block or two
                    assert!(c.top <= real as f32 + 2.0, "column at ({}, {}) is {} but the real top face is {}", wx, wz, c.top, real + 1);
                    assert!(c.top >= real as f32 - 14.0, "column at ({}, {}) is {} but the real top face is {}", wx, wz, c.top, real + 1);
                }
                checked += 1;
            }
        }
        assert!(checked > 100);
    }

    #[test]
    fn land_is_always_above_the_sea_plane_and_sea_is_a_flat_blue_sheet() {
        let gen = Arc::new(TerrainGenerator::new(6));
        let s = FarSampler::new(gen);
        let mut water = 0;
        let mut land = 0;
        for tx in -6..6 {
            for tz in -6..6 {
                let g = s.sample_grid(TileKey::new(5, tx, tz));
                for cz in 0..CELLS as i32 {
                    for cx in 0..CELLS as i32 {
                        let c = g.get(cx, cz);
                        if c.water {
                            assert_eq!(c.top, WATER_TOP);
                            if c.color[2] > c.color[0] + 20 {
                                water += 1;
                            }
                        } else {
                            assert!(c.top >= SEA_LEVEL as f32 + 1.0, "land at {}", c.top);
                            land += 1;
                        }
                    }
                }
            }
        }
        assert!(water > 100, "no sea found ({})", water);
        assert!(land > 100, "no land found ({})", land);
    }

    #[test]
    fn colours_are_plausible_ground_colours_and_columns_differ_a_little() {
        let s = sampler(7);
        let g = s.sample_grid(TileKey::new(3, 0, 0));
        let mut sum = [0u64; 3];
        let mut n = 0u64;
        let mut distinct = std::collections::HashSet::new();
        for cz in 0..CELLS as i32 {
            for cx in 0..CELLS as i32 {
                let c = g.get(cx, cz);
                for k in 0..3 {
                    sum[k] += c.color[k] as u64;
                }
                distinct.insert(c.color);
                n += 1;
            }
        }
        for k in 0..3 {
            let avg = sum[k] / n;
            assert!(avg > 20 && avg < 250, "channel {} averages {}", k, avg);
        }
        assert!(distinct.len() > 20, "only {} different colours", distinct.len());
    }

    #[test]
    fn sea_comes_in_few_colours_so_that_it_can_be_merged() {
        let gen = Arc::new(TerrainGenerator::new(6));
        let s = FarSampler::new(gen);
        let mut colours = std::collections::HashSet::new();
        for tx in -4..4 {
            for tz in -4..4 {
                let g = s.sample_grid(TileKey::new(4, tx, tz));
                for cz in 0..CELLS as i32 {
                    for cx in 0..CELLS as i32 {
                        let c = g.get(cx, cz);
                        if c.water {
                            colours.insert(c.color);
                        }
                    }
                }
            }
        }
        assert!(!colours.is_empty());
        assert!(colours.len() <= DEPTH_STEPS as usize + 2, "{} sea colours", colours.len());
    }

    #[test]
    fn a_tile_is_cheap_enough_to_build_in_the_background() {
        let s = sampler(8);
        let start = Instant::now();
        for i in 0..6 {
            s.build_tile(TileKey::new(i, 7, -3));
        }
        let per_tile = start.elapsed().as_secs_f64() / 6.0;
        eprintln!("far tile build: {:.1} ms each", per_tile * 1000.0);
        assert!(per_tile < 1.0, "a tile took {:.2} s", per_tile);
    }
}
