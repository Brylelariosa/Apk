//! The settings screen: three tabs (graphics, controls, debug). The render distance has a slider, hold-to-repeat
//! `-` / `+` buttons and a MAX button, so crossing 4 to 1000 chunks takes a moment instead of a thousand taps. The
//! graphics tab also has switches for the two optimisations that change how chunks are built and culled.

use super::{wrap_lines, App, GOLD, GREY, WHITE};
use crate::game::settings::{
    MAX_DETAIL_CHUNKS, MAX_FLY_SPEED, MAX_RENDER_CHUNKS, MAX_RESOLUTION_PERCENT, MIN_DETAIL_CHUNKS, MIN_FLY_SPEED,
    MIN_RENDER_CHUNKS, MIN_RESOLUTION_PERCENT,
};
use crate::ui::batch::UiBatch;
use crate::ui::widgets::{self, Scale};

const TABS: [&str; 3] = ["GRAPHICS", "CONTROLS", "DEBUG"];
const TAB_GRAPHICS: usize = 0;
const TAB_CONTROLS: usize = 1;

impl App {
    pub(super) fn settings_menu(&mut self, taps: &[(f32, f32)]) {
        self.dim(if self.engine.is_some() { 170 } else { 90 });
        let cx = self.width * 0.5;
        let panel_w = self.dp(590.0).min(self.width - self.dp(16.0));
        let panel_h = self.dp(326.0).min(self.height - self.dp(8.0));
        let px0 = cx - panel_w * 0.5;
        let py0 = (self.height - panel_h) * 0.5;
        self.panel(px0, py0, panel_w, panel_h);
        let title = self.font_px(14.0);
        self.ui.text_centered(cx, py0 + self.dp(8.0), title, "SETTINGS", WHITE);

        let left = px0 + self.dp(16.0);
        let inner_w = panel_w - self.dp(32.0);
        let tab_y = py0 + self.dp(34.0);
        let tab_h = self.dp(26.0);
        if let Some(i) = self.tab_bar(left, tab_y, inner_w, tab_h, &TABS, self.settings_tab, taps) {
            self.settings_tab = i;
            self.repeat.reset();
        }
        let top = py0 + self.dp(74.0);
        match self.settings_tab {
            TAB_GRAPHICS => self.settings_graphics(left, top, inner_w, taps),
            TAB_CONTROLS => self.settings_controls(left, top, inner_w, taps),
            _ => self.settings_debug(left, top, inner_w, taps),
        }

        let bw = self.dp(200.0);
        let bh = self.dp(36.0);
        if self.button(cx - bw * 0.5, py0 + panel_h - bh - self.dp(10.0), bw, bh, "BACK", taps) {
            self.settings.sanitize();
            self.settings.save(&self.data_dir.join("settings.txt"));
            let back = self.settings_return;
            self.go(back);
        }
    }

    fn settings_graphics(&mut self, x: f32, y: f32, w: f32, taps: &[(f32, f32)]) {
        let rd = self.settings.render_distance;
        let text = format!("{} CHUNKS - {}", rd, widgets::blocks_label(rd));
        let range = (MIN_RENDER_CHUNKS, MAX_RENDER_CHUNKS);
        if let Some(v) = self.slider_row(10, "render-slider", x, y, w, "RENDER DISTANCE", &text, rd, range, Scale::Log, true, taps) {
            self.settings.render_distance = v;
        }

        let y2 = y + self.dp(52.0);
        let detail = self.settings.detail_distance;
        let effective = self.settings.detail_radius();
        let text = if effective == detail {
            format!("{} CHUNKS", detail)
        } else {
            format!("{} OF {} CHUNKS", effective, detail)
        };
        let range = (MIN_DETAIL_CHUNKS, MAX_DETAIL_CHUNKS);
        if let Some(v) = self.slider_row(20, "detail-slider", x, y2, w, "DETAIL DISTANCE (REAL BLOCKS)", &text, detail, range, Scale::Linear, false, taps) {
            self.settings.detail_distance = v;
        }

        let y3 = y2 + self.dp(54.0);
        let col_gap = self.dp(24.0);
        let col_w = (w - col_gap) * 0.5;
        let right = x + col_w + col_gap;
        let res = self.settings.resolution_percent;
        let d = self.stepper_row(x, y3, col_w, "RESOLUTION", &format!("{}%", res), taps);
        if d != 0 {
            self.settings.resolution_percent = (res + d * 5).max(MIN_RESOLUTION_PERCENT).min(MAX_RESOLUTION_PERCENT);
        }
        let clouds = self.settings.clouds;
        if self.toggle_row(right, y3, col_w, "CLOUDS", clouds, taps) {
            self.settings.clouds = !clouds;
        }

        // two optimisations that can be switched off to compare (or to work around a driver problem)
        let y4 = y3 + self.dp(40.0);
        let greedy = self.settings.greedy_meshing;
        if self.toggle_row(x, y4, col_w, "GREEDY MESHING", greedy, taps) {
            self.settings.greedy_meshing = !greedy;
        }
        let occlusion = self.settings.occlusion_culling;
        if self.toggle_row(right, y4, col_w, "OCCLUSION CULLING", occlusion, taps) {
            self.settings.occlusion_culling = !occlusion;
        }

        let hint = if self.settings.far_terrain_wanted() {
            "FAR TERRAIN FILLS THE VIEW BEYOND THE DETAIL DISTANCE"
        } else {
            "RENDER DISTANCE IS INSIDE THE DETAIL DISTANCE: NO FAR TERRAIN NEEDED"
        };
        let px = self.font_px(7.0);
        let hy = y4 + self.dp(38.0);
        let cx = x + w * 0.5;
        self.ui.text_centered(cx, hy, px, hint, GREY);
    }

    fn settings_controls(&mut self, x: f32, y: f32, w: f32, taps: &[(f32, f32)]) {
        let col_gap = self.dp(24.0);
        let col_w = (w - col_gap) * 0.5;
        let right = x + col_w + col_gap;
        let row = self.dp(40.0);

        let ls = self.settings.look_sensitivity;
        let d = self.stepper_row(x, y, col_w, "LOOK SPEED", &format!("{:.0}%", ls * 100.0), taps);
        if d != 0 {
            self.settings.look_sensitivity = (ls + d as f32 * 0.1).max(0.0).min(1.0);
        }
        let ts = self.settings.touch_sensitivity;
        let d = self.stepper_row(x, y + row, col_w, "MOVE SPEED", &format!("{:.0}%", ts * 100.0), taps);
        if d != 0 {
            self.settings.touch_sensitivity = (ts + d as f32 * 0.1).max(0.0).min(1.0);
        }
        let fs = self.settings.fly_speed;
        let d = self.stepper_row(x, y + row * 2.0, col_w, "FLY SPEED", &format!("{:.0}", fs), taps);
        if d != 0 {
            let step = if fs >= 60.0 { 10.0 } else { 5.0 };
            self.settings.fly_speed = (fs + d as f32 * step).max(MIN_FLY_SPEED).min(MAX_FLY_SPEED);
        }

        let aj = self.settings.auto_jump;
        if self.toggle_row(right, y, col_w, "AUTO JUMP", aj, taps) {
            self.settings.auto_jump = !aj;
        }
        let vb = self.settings.view_bobbing;
        if self.toggle_row(right, y + row, col_w, "VIEW BOBBING", vb, taps) {
            self.settings.view_bobbing = !vb;
        }
    }

    fn settings_debug(&mut self, x: f32, y: f32, w: f32, taps: &[(f32, f32)]) {
        let col_gap = self.dp(24.0);
        let col_w = (w - col_gap) * 0.5;
        let right = x + col_w + col_gap;

        let log = self.settings.debug_log;
        if self.toggle_row(x, y, col_w, "DEBUG LOG FILE", log, taps) {
            self.settings.debug_log = !log;
        }
        let fps = self.settings.show_fps;
        if self.toggle_row(right, y, col_w, "SHOW FPS + STATS", fps, taps) {
            self.settings.show_fps = !fps;
        }

        let px = self.font_px(7.0);
        let adv = 6.0 * px;
        let max_chars = ((w / adv).floor() as usize).max(10);
        let line_h = UiBatch::text_height(px) + self.dp(4.0);
        let mut ty = y + self.dp(46.0);

        let status = if self.settings.debug_log {
            if self.log_status.is_empty() {
                "LOG: STARTING...".to_string()
            } else {
                self.log_status.clone()
            }
        } else {
            "LOG: OFF".to_string()
        };
        for l in wrap_lines(&status, max_chars) {
            self.ui.text(x, ty, px, &l, GOLD);
            ty += line_h;
        }
        ty += self.dp(4.0);
        let help = "IF THE GAME LAGS, SEND ME THE LOG FILE FROM YOUR DOWNLOAD FOLDER. \
                    IT SHOWS EVERY SECOND WHETHER THE CPU (CALCULATION) OR THE GPU (DRAWING) IS THE SLOW PART.";
        for l in wrap_lines(help, max_chars) {
            self.ui.text(x, ty, px, &l, GREY);
            ty += line_h;
        }
    }
}
