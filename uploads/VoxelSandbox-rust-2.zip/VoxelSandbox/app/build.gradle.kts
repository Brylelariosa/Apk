// The app module is only a packaging shell: it contains the manifest and icons and bundles the Rust
// library (libvoxelsandbox.so) built by cargo-ndk into src/main/jniLibs.
plugins {
    id("com.android.application")
}

val rustAbis: List<String> =
    (project.findProperty("rustAbis") as String? ?: "arm64-v8a")
        .split(",")
        .map { it.trim() }
        .filter { it.isNotEmpty() }
val jniLibsDir = layout.projectDirectory.dir("src/main/jniLibs")

android {
    namespace = "com.voxelsandbox.game"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.voxelsandbox.game"
        minSdk = 24
        targetSdk = 34
        versionCode = 21
        versionName = "0.3.0-rust"
        ndk {
            abiFilters += rustAbis
        }
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
        }
        release {
            // Nothing to shrink: there is no Java/Kotlin code. The Rust library is optimised by cargo.
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }

    packaging {
        resources.excludes.add("META-INF/*")
    }
}

// Builds the Rust library for every ABI. The GitHub workflow runs the very same cargo-ndk command in its
// own step first (clearer logs) and passes -PrustPrebuilt=true so this task is skipped there.
val buildRust by tasks.registering(Exec::class) {
    description = "Compiles the Rust crate with cargo-ndk into src/main/jniLibs"
    workingDir = rootProject.projectDir
    val cmd = mutableListOf("cargo", "ndk")
    rustAbis.forEach { abi ->
        cmd.add("-t")
        cmd.add(abi)
    }
    cmd.addAll(listOf("-o", jniLibsDir.asFile.absolutePath, "build", "--release"))
    commandLine(cmd)
}

if (!project.hasProperty("rustPrebuilt")) {
    tasks.matching { it.name == "preBuild" }.configureEach {
        dependsOn(buildRust)
    }
}
