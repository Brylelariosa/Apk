package com.hexmaniac.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Text actions instead of icons throughout this screen: material-icons-extended was
// deliberately dropped from NovaShare for APK size, so the same call applies here -
// a handful of TextButtons cost nothing extra to ship.

@Composable
fun HexViewerScreen(
    viewModel: HexViewerViewModel,
    onOpenRomRequested: () -> Unit,
    onSaveRomRequested: () -> Unit,
) {
    val state = viewModel.uiState

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(state.romName ?: "HexManiac", style = MaterialTheme.typography.titleMedium) },
                actions = {
                    TextButton(onClick = onOpenRomRequested) { Text("Open") }
                    TextButton(onClick = onSaveRomRequested, enabled = state.romLoaded) { Text("Save") }
                    TextButton(onClick = viewModel::scanForPointers, enabled = state.romLoaded) { Text("Scan") }
                    TextButton(onClick = viewModel::undo, enabled = state.canUndo) { Text("Undo") }
                    TextButton(onClick = viewModel::redo, enabled = state.canRedo) { Text("Redo") }
                },
            )
        },
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {
            if (!state.romLoaded) {
                EmptyState(onOpenRomRequested)
            } else {
                HexGrid(
                    viewModel = viewModel,
                    rowCount = state.rowCount,
                    bytesPerRow = state.bytesPerRow,
                    selectedIndex = state.selectedIndex,
                    revision = state.revision,
                    modifier = Modifier.weight(1f),
                )
                EditBar(viewModel, state.selectedIndex, state.revision)
            }
            Text(
                text = state.statusMessage,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
            )
        }
    }
}

@Composable
private fun EmptyState(onOpenRomRequested: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("No ROM loaded", style = MaterialTheme.typography.titleMedium)
        Text(
            "Open a .gba file to view and edit its raw bytes.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 8.dp, bottom = 16.dp),
        )
        TextButton(onClick = onOpenRomRequested) { Text("Open ROM") }
    }
}

@Composable
private fun HexGrid(
    viewModel: HexViewerViewModel,
    rowCount: Int,
    bytesPerRow: Int,
    selectedIndex: Int?,
    revision: Int,
    modifier: Modifier = Modifier,
) {
    LazyColumn(modifier = modifier) {
        // The key folds in `revision` so every visible row is treated as a fresh slot
        // after an edit/scan, not just a re-invocation Compose might skip.
        items(count = rowCount, key = { row -> "$row:$revision" }) { row ->
            HexRow(viewModel, row, bytesPerRow, selectedIndex, revision)
        }
    }
}

@Suppress("UNUSED_PARAMETER") // revision isn't read directly; see comment below
@Composable
private fun HexRow(
    viewModel: HexViewerViewModel,
    row: Int,
    bytesPerRow: Int,
    selectedIndex: Int?,
    revision: Int,
) {
    // viewModel.byteAt()/isPointerByte() read plain mutable fields, not Compose State -
    // Compose has no way to know they can return something new. Taking `revision` as an
    // explicit parameter (compared against its previous value) is what stops this call
    // from being skipped after an edit or scan, so the loop below actually re-reads bytes
    // instead of showing stale ones.
    val rowStart = row * bytesPerRow
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = rowStart.toString(16).uppercase().padStart(6, '0'),
            fontFamily = FontFamily.Monospace,
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(end = 12.dp),
        )
        for (col in 0 until bytesPerRow) {
            val index = rowStart + col
            val value = viewModel.byteAt(index)
            ByteCell(
                value = value,
                selected = index == selectedIndex,
                isPointer = value != null && viewModel.isPointerByte(index),
                onClick = { viewModel.selectByte(index) },
            )
        }
    }
}

@Composable
private fun ByteCell(
    value: Int?,
    selected: Boolean,
    isPointer: Boolean,
    onClick: () -> Unit,
) {
    val background = when {
        selected -> MaterialTheme.colorScheme.primary
        isPointer -> MaterialTheme.colorScheme.tertiaryContainer
        else -> MaterialTheme.colorScheme.background
    }
    val textColor = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onBackground
    Box(
        modifier = Modifier
            .size(28.dp)
            .background(background)
            .clickable(enabled = value != null, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = value?.let { it.toString(16).uppercase().padStart(2, '0') } ?: "  ",
            fontFamily = FontFamily.Monospace,
            fontSize = 13.sp,
            color = textColor,
        )
    }
}

@Composable
private fun EditBar(viewModel: HexViewerViewModel, selectedIndex: Int?, revision: Int) {
    if (selectedIndex == null) return
    var text by remember(selectedIndex, revision) {
        val current = viewModel.byteAt(selectedIndex)?.toString(16)?.uppercase()?.padStart(2, '0') ?: ""
        mutableStateOf(current)
    }
    Row(
        modifier = Modifier.fillMaxWidth().padding(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = "Byte ${selectedIndex.toString(16).uppercase()}:",
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(end = 8.dp),
        )
        OutlinedTextField(
            value = text,
            onValueChange = { text = it.take(2) },
            modifier = Modifier.size(width = 72.dp, height = 56.dp),
            singleLine = true,
        )
        TextButton(onClick = { viewModel.writeSelectedByte(text) }) { Text("Set") }
    }
}
