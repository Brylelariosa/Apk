package com.hexmaniac.app

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import com.hexmaniac.app.ui.HexViewerScreen
import com.hexmaniac.app.ui.HexViewerViewModel
import com.hexmaniac.app.ui.theme.HexManiacTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    private val viewModel: HexViewerViewModel by viewModels()

    private val openRomLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            uri?.let { viewModel.loadRom(contentResolver, it) }
        }

    private val saveRomLauncher =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri: Uri? ->
            uri?.let { viewModel.saveRom(contentResolver, it) }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            HexManiacTheme {
                HexViewerScreen(
                    viewModel = viewModel,
                    onOpenRomRequested = { openRomLauncher.launch(arrayOf("*/*")) },
                    onSaveRomRequested = { saveRomLauncher.launch(viewModel.uiState.romName ?: "rom.gba") },
                )
            }
        }
    }
}
