package com.hexmaniac.app.ui

import android.content.ContentResolver
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.hexmaniac.core.model.PointerScanner
import com.hexmaniac.core.model.RomDataModel
import com.hexmaniac.core.undo.ModelDelta
import com.hexmaniac.core.undo.UndoRedoStack
import dagger.hilt.android.lifecycle.HiltViewModel
import java.io.ByteArrayOutputStream
import java.util.BitSet
import javax.inject.Inject

data class HexViewerUiState(
    val romLoaded: Boolean = false,
    val romName: String? = null,
    val romSize: Int = 0,
    val bytesPerRow: Int = 16,
    val rowCount: Int = 0,
    val selectedIndex: Int? = null,
    val pointerByteCount: Int = 0,
    val canUndo: Boolean = false,
    val canRedo: Boolean = false,
    val statusMessage: String = "Open a ROM to begin.",
    // Bumped on every mutation that doesn't otherwise change uiState's identity, so the
    // (lazily-composed, engine-backed) byte grid knows to recompose after an edit or scan.
    val revision: Int = 0,
)

@HiltViewModel
class HexViewerViewModel @Inject constructor() : ViewModel() {

    private var model: RomDataModel? = null
    private var undoRedo = UndoRedoStack()

    // BitSet, not Set<Int>: a 32MB ROM can have millions of pointer-covered bytes: this is
    // one bit each instead of a boxed Integer each, which matters at that scale.
    private var pointerHighlights = BitSet()

    var uiState by mutableStateOf(HexViewerUiState())
        private set

    fun loadRom(resolver: ContentResolver, uri: Uri) {
        val bytes = resolver.openInputStream(uri)?.use { input ->
            val buffer = ByteArrayOutputStream()
            input.copyTo(buffer)
            buffer.toByteArray()
        }
        if (bytes == null) {
            uiState = uiState.copy(statusMessage = "Could not open that file.")
            return
        }

        model = RomDataModel(bytes)
        undoRedo = UndoRedoStack()
        pointerHighlights = BitSet()
        uiState = HexViewerUiState(
            romLoaded = true,
            romName = uri.lastPathSegment ?: "ROM",
            romSize = bytes.size,
            rowCount = (bytes.size + 15) / 16,
            statusMessage = "Loaded ${bytes.size} bytes.",
        )
    }

    fun saveRom(resolver: ContentResolver, uri: Uri) {
        val m = model ?: return
        resolver.openOutputStream(uri)?.use { out -> out.write(m.snapshotBytes()) }
        uiState = uiState.copy(statusMessage = "Saved ${m.size} bytes.")
    }

    fun byteAt(index: Int): Int? = model?.let { if (index < it.size) it[index] else null }

    fun isPointerByte(index: Int): Boolean = pointerHighlights.get(index)

    fun selectByte(index: Int) {
        uiState = uiState.copy(selectedIndex = index)
    }

    fun writeSelectedByte(hexValue: String) {
        val m = model ?: return
        val index = uiState.selectedIndex ?: return
        val value = hexValue.toIntOrNull(16)
        if (value == null) {
            uiState = uiState.copy(statusMessage = "'$hexValue' isn't valid hex.")
            return
        }
        if (value !in 0..255) {
            uiState = uiState.copy(statusMessage = "Byte value must be 00-FF.")
            return
        }
        val delta = ModelDelta()
        delta.setByte(m, index, value)
        undoRedo.push(delta)
        refreshAfterEdit("Set byte ${index.toHexAddress()} = ${value.toString(16).uppercase()}")
    }

    fun undo() {
        val m = model ?: return
        undoRedo.undo(m)
        refreshAfterEdit("Undid last edit.")
    }

    fun redo() {
        val m = model ?: return
        undoRedo.redo(m)
        refreshAfterEdit("Redid edit.")
    }

    fun scanForPointers() {
        val m = model ?: return
        val found = PointerScanner.scan(m)
        val bits = BitSet(m.size)
        for (run in found) {
            for (i in run.start until run.start + run.length) bits.set(i)
        }
        pointerHighlights = bits
        uiState = uiState.copy(
            statusMessage = "Found ${found.size} candidate pointers.",
            pointerByteCount = bits.cardinality(),
            revision = uiState.revision + 1,
        )
    }

    private fun refreshAfterEdit(message: String) {
        uiState = uiState.copy(
            statusMessage = message,
            canUndo = undoRedo.canUndo,
            canRedo = undoRedo.canRedo,
            revision = uiState.revision + 1,
        )
    }
}

private fun Int.toHexAddress(): String = "0x" + toString(16).uppercase().padStart(6, '0')
