# HexManiac Android

A native Android rewrite of [HexManiacAdvance](https://github.com/haven1433/HexManiacAdvance) (HMA),
the C#/WPF hex editor for GBA Pokémon ROM hacking. HMA itself isn't portable (WPF/WinForms are
Windows-only, and its scripting system depends on IronPython) - this rebuilds the feature set
natively in Kotlin, using HMA's source as the reference spec rather than code to reuse.

## Status: Phase 1 - data engine + hex viewer

This is the foundation every later feature builds on. Nothing here is HMA-specific yet in the UI;
it's the minimum needed to open a ROM, view/edit raw bytes, undo/redo, and auto-detect pointers.

**Working:**
- Open any file via SAF, view it as a scrollable hex grid (address | hex | tap-to-edit)
- Byte-accurate undo/redo, tracked per edit
- Pointer auto-detection scan (GBA convention: 4-byte LE value, top byte `0x08`/`0x09`,
  value − `0x08000000` = file offset), with detected bytes highlighted in the grid
- Save back to a file via SAF
- `core-engine` unit tests covering the above (pointer round-trip, scanner, undo/redo ordering,
  run containment lookup at boundaries)

**Not yet implemented** (see the phase order below): tables, text, images, maps, code/scripts,
patches.

## Architecture

Two modules, one direction of dependency:

```
core-engine/   pure Kotlin/JVM, zero Android dependency
  model/       Run (sealed interface), RomDataModel, PointerScanner
  undo/        ModelDelta, UndoRedoStack

app/           Android application (Compose, Material3, Hilt)
  ui/          HexViewerViewModel, HexViewerScreen, theme/
```

`core-engine` doesn't know Android exists, on purpose - it's plain JVM, so its tests run in
milliseconds with no emulator, and it stays reusable if a desktop or CLI front end ever makes
sense. `app` depends on it; never the reverse.

**Where this deliberately differs from the original:**
- `Run` is a Kotlin `sealed interface` (`UnknownRun`, `PointerRun` so far). Every exhaustive
  `when (run)` elsewhere fails to compile until updated when a new run type is added - HMA's C#
  base-class version doesn't get that check for free.
- All byte mutation is `internal` on `RomDataModel`; the only public write path is through a
  `ModelDelta`. It's not possible to accidentally make a non-undoable edit.
- Pointer-highlight membership uses `BitSet` instead of a boxed `Set<Int>` - relevant once a ROM
  (up to 32MB) has a dense pointer table; one bit per byte instead of ~20 bytes per entry.

## Build order (why this order)

1. **Data engine + hex viewer** *(this phase)* - nothing else works without it
2. **Table editor** - Pokémon/move/item/trainer grids; highest value-to-effort, most-used day to day
3. **Text editor** - PCS string encoding, auto-repoint on edit
4. **Image editor** - sprites, tilemaps, palettes
5. **Map editor** - maps, events, connections, warps, wild encounters
6. **Code editor + patch DSL** - Thumb disassembler, event/battle/AI scripts, the `.hma` patch
   format - hardest subsystem, saved for once the engine's proven under real use

IronPython's live-scripting console (table automation) has no clean Android equivalent and isn't
scoped into any phase yet; it's the one piece of the original worth deferring rather than
matching feature-for-feature.

## Building

Same pipeline as the rest of the projects - zip this folder, push through ZipApkBuilder. No NDK/
CMake needed (pure Kotlin, no native code), though the workflow installing them anyway is
harmless. Toolchain: JDK 17, Gradle 8.6, AGP 8.4.0, Kotlin 2.0.0.

Local validation note: this sandbox had a JRE but no `javac`/network, so the core algorithms
(pointer encode/decode, scanning, undo/redo ordering, run lookup at boundaries) were verified with
a throwaway Python harness before the Kotlin was written, then ported into the real `core-engine`
tests above. Actual Gradle/Kotlin compilation happens for the first time in CI - version pins
(Compose BOM, Hilt, KGP) are my best-confidence picks for this AGP/Gradle/JDK combination, not
locally verified; a version-mismatch error there is a quick one-line fix, not a structural problem.
