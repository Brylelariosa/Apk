package com.claudemanager.app.util

import com.claudemanager.app.data.Account
import com.claudemanager.app.data.ActivityStatus
import com.claudemanager.app.data.Project

/** One thing that still stops an account from being idle. */
sealed interface IdleReason {

    /** When this reason stops holding the account back. */
    val endsAt: Long

    /**
     * RUNNING, BUILDING, TESTING or a custom status, and the account was used through this project
     * less than [IdleCheck.IDLE_AFTER_MILLIS] ago. The reason ends that long after [lastUsedAt], so
     * a project left in RUNNING and forgotten does not keep the account in use for ever.
     */
    data class Working(val project: Project, val lastUsedAt: Long) : IdleReason {
        override val endsAt: Long
            get() = lastUsedAt + IdleCheck.IDLE_AFTER_MILLIS
    }

    /** The project's reset time has not been reached yet. */
    data class ResetPending(val project: Project, override val endsAt: Long) : IdleReason

    /** A project of this account was deleted; the account stays in use until [endsAt]. */
    data class DeleteHold(override val endsAt: Long) : IdleReason
}

class IdleReport(val reasons: List<IdleReason>) {

    /** True only when every check passed. */
    val isIdle: Boolean
        get() = reasons.isEmpty()

    /**
     * When the account turns idle by itself, as long as it is not used again: the latest end time
     * among the reasons. Null when it is already idle.
     */
    val idleAt: Long?
        get() = reasons.maxOfOrNull { it.endsAt }
}

/**
 * "Is this account really idle?" An account is idle only when ALL of these hold:
 *
 *   1. No project is RUNNING, BUILDING, TESTING or has a custom status, unless the account was
 *      used through it within the last [IDLE_AFTER_MILLIS]. Work nobody has touched for that long
 *      is forgotten, not in progress, so the account turns idle by itself.
 *   2. Every project's reset time has passed (or was never set).
 *   3. The hold after a deleted project is over.
 *
 * READY, WAITING, FINISHED and ERROR projects do not block by themselves; their reset time (2)
 * still does. A WAITING project is waiting for exactly that reset time, and a FINISHED project's
 * reset time is the window DONE just started (see FinishRule), so a finished account stays in use
 * for the full window instead of turning idle at once.
 *
 * Pure Kotlin on purpose: the clock is passed in, so the result depends on nothing else.
 */
object IdleCheck {

    /**
     * How long an account counts as in use after it was last used: one Claude usage window.
     * Deleting a project counts as use, so this is also how long the account is held afterwards.
     */
    const val IDLE_AFTER_MILLIS: Long = 5L * 60L * 60L * 1000L

    /**
     * When the account was last used through [project]: its latest start, status change or
     * reset-time edit. A project with none of these dates from when it was created.
     */
    fun lastUsedAt(project: Project): Long = maxOf(
        project.createdAt,
        project.lastActivityChangeAt ?: 0L,
        maxOf(project.lastStartedAt ?: 0L, project.timerStartTimestamp ?: 0L)
    )

    fun report(account: Account, projects: List<Project>, now: Long): IdleReport {
        val working = mutableListOf<IdleReason.Working>()
        val resets = mutableListOf<IdleReason.ResetPending>()

        for (p in projects) {
            if (p.accountId != account.id) continue

            when (p.activityStatus) {
                ActivityStatus.RUNNING,
                ActivityStatus.BUILDING,
                ActivityStatus.TESTING,
                ActivityStatus.CUSTOM -> {
                    val reason = IdleReason.Working(p, lastUsedAt(p))
                    if (reason.endsAt > now) working.add(reason)
                }

                ActivityStatus.READY,
                ActivityStatus.WAITING,
                ActivityStatus.FINISHED,
                ActivityStatus.ERROR -> Unit
            }

            val end = p.timerEndTimestamp
            if (end != null && end > now) resets.add(IdleReason.ResetPending(p, end))
        }

        val reasons = mutableListOf<IdleReason>()
        reasons.addAll(working)
        reasons.addAll(resets.sortedBy { it.endsAt })

        val hold = account.holdUntil
        if (hold != null && hold > now) reasons.add(IdleReason.DeleteHold(hold))

        return IdleReport(reasons)
    }
}
