package com.claudemanager.app.util

import com.claudemanager.app.data.Account
import com.claudemanager.app.data.ActivityStatus
import com.claudemanager.app.data.Project
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class IdleCheckTest {

    private val hour = 60L * 60L * 1000L
    private val window = IdleCheck.IDLE_AFTER_MILLIS
    private val now = 100L * hour
    private val account = Account(id = 1L, email = "me@example.com")

    private fun project(
        status: ActivityStatus,
        accountId: Long? = account.id,
        createdAt: Long = 0L,
        lastStartedAt: Long? = null,
        lastActivityChangeAt: Long? = null,
        timerStartTimestamp: Long? = null,
        timerEndTimestamp: Long? = null
    ) = Project(
        name = "Demo",
        accountId = accountId,
        defaultDurationMillis = window,
        timerStartTimestamp = timerStartTimestamp,
        timerEndTimestamp = timerEndTimestamp,
        activityStatus = status,
        createdAt = createdAt,
        lastStartedAt = lastStartedAt,
        lastActivityChangeAt = lastActivityChangeAt
    )

    private fun report(vararg projects: Project): IdleReport =
        IdleCheck.report(account, projects.toList(), now)

    @Test
    fun workUsedRecentlyKeepsTheAccountInUse() {
        val usedAt = now - 1 * hour
        val r = report(project(ActivityStatus.RUNNING, lastActivityChangeAt = usedAt))
        assertFalse(r.isIdle)
        assertEquals(usedAt + window, r.idleAt)
    }

    @Test
    fun workNotUsedForTheWholeWindowLetsTheAccountGoIdle() {
        val r = report(project(ActivityStatus.RUNNING, lastActivityChangeAt = now - window - 1L))
        assertTrue(r.isIdle)
        assertNull(r.idleAt)
    }

    @Test
    fun accountIsIdleExactlyWhenTheWindowEnds() {
        val r = report(project(ActivityStatus.BUILDING, lastActivityChangeAt = now - window))
        assertTrue(r.isIdle)
    }

    @Test
    fun theLatestUseCountsNotTheFirstStart() {
        val usedAt = now - 2 * hour
        val r = report(
            project(
                ActivityStatus.TESTING,
                lastStartedAt = now - 9 * hour,
                lastActivityChangeAt = usedAt
            )
        )
        assertFalse(r.isIdle)
        assertEquals(usedAt + window, r.idleAt)
    }

    @Test
    fun lastUsedAtIsTheLatestOfStartStatusChangeAndResetEdit() {
        val p = project(
            ActivityStatus.RUNNING,
            createdAt = 1 * hour,
            lastStartedAt = 5 * hour,
            lastActivityChangeAt = 7 * hour,
            timerStartTimestamp = 6 * hour
        )
        assertEquals(7 * hour, IdleCheck.lastUsedAt(p))
        assertEquals(6 * hour, IdleCheck.lastUsedAt(p.copy(lastActivityChangeAt = null)))
        assertEquals(5 * hour, IdleCheck.lastUsedAt(p.copy(lastActivityChangeAt = null, timerStartTimestamp = null)))
    }

    @Test
    fun aProjectWithoutAnyDateFallsBackToItsCreationTime() {
        val fresh = report(project(ActivityStatus.CUSTOM, createdAt = now - 1 * hour))
        assertFalse(fresh.isIdle)
        val old = report(project(ActivityStatus.CUSTOM, createdAt = now - 6 * hour))
        assertTrue(old.isIdle)
    }

    @Test
    fun aPendingResetStillKeepsTheAccountInUse() {
        val resetAt = now + 2 * hour
        val r = report(
            project(
                ActivityStatus.RUNNING,
                lastActivityChangeAt = now - 6 * hour,
                timerEndTimestamp = resetAt
            )
        )
        assertFalse(r.isIdle)
        assertEquals(1, r.reasons.size)
        assertEquals(resetAt, r.idleAt)
    }

    @Test
    fun statusesThatAreNotWorkNeverBlockOnTheirOwn() {
        val quiet = listOf(
            ActivityStatus.READY,
            ActivityStatus.WAITING,
            ActivityStatus.FINISHED,
            ActivityStatus.ERROR
        )
        for (status in quiet) {
            val r = report(project(status, lastActivityChangeAt = now))
            assertTrue(status.name, r.isIdle)
        }
    }

    @Test
    fun theDeleteHoldKeepsTheAccountInUseUntilItEnds() {
        val held = account.copy(holdUntil = now + 3 * hour)
        val r = IdleCheck.report(held, emptyList(), now)
        assertFalse(r.isIdle)
        assertEquals(now + 3 * hour, r.idleAt)

        val over = account.copy(holdUntil = now - 1L)
        assertTrue(IdleCheck.report(over, emptyList(), now).isIdle)
    }

    @Test
    fun idleAtIsTheLatestEndAmongAllReasons() {
        val resetAt = now + 3 * hour
        val r = report(
            // Used 4h ago: still counts for one more hour.
            project(ActivityStatus.RUNNING, lastActivityChangeAt = now - 4 * hour),
            project(ActivityStatus.WAITING, timerEndTimestamp = resetAt)
        )
        assertEquals(2, r.reasons.size)
        assertEquals(resetAt, r.idleAt)
    }

    @Test
    fun projectsOfOtherAccountsAreIgnored() {
        val r = report(project(ActivityStatus.RUNNING, accountId = 2L, lastActivityChangeAt = now))
        assertTrue(r.isIdle)
    }
}
