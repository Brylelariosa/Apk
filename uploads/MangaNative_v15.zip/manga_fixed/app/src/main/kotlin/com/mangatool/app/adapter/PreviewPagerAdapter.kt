package com.mangatool.app.adapter

import android.graphics.Bitmap
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import androidx.recyclerview.widget.RecyclerView
import com.mangatool.app.R
import com.mangatool.app.model.MergePairDescriptor
import com.mangatool.app.util.BitmapUtils
import com.mangatool.app.util.ImageMerger
import kotlinx.coroutines.*

/** Items are String (filePath for single images) or MergePairDescriptor (lazy merge). */
class PreviewPagerAdapter(
    items: List<Any>
) : RecyclerView.Adapter<PreviewPagerAdapter.VH>() {

    val items: MutableList<Any> = items.toMutableList()

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val image: ImageView     = v.findViewById(R.id.preview_image)
        val progress: ProgressBar = v.findViewById(R.id.preview_progress)
        var job: Job? = null
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_preview_image, parent, false)
        return VH(v)
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.job?.cancel()
        holder.image.setImageBitmap(null)
        holder.progress.visibility = View.VISIBLE

        val item = items[position]
        when (item) {
            is MergePairDescriptor -> {
                // Decode this pair on the bounded decode pool — only the visible
                // (and prefetched adjacent) pages are ever in memory at once.
                holder.job = scope.launch {
                    val bm = withContext(BitmapUtils.decodeDispatcher) {
                        ImageMerger.merge(item.pair, item.swapped)
                    }
                    holder.progress.visibility = View.GONE
                    holder.image.setImageBitmap(bm)
                }
            }
            is String -> {
                holder.job = scope.launch {
                    val bm: Bitmap? = withContext(BitmapUtils.decodeDispatcher) {
                        BitmapUtils.decodeFull(item)
                    }
                    holder.progress.visibility = View.GONE
                    holder.image.setImageBitmap(bm)
                }
            }
        }
    }

    override fun onViewRecycled(holder: VH) {
        holder.job?.cancel()
        super.onViewRecycled(holder)
    }

    /** Remove the item at [index] and notify the pager. */
    fun removeAt(index: Int) {
        if (index in items.indices) {
            items.removeAt(index)
            notifyItemRemoved(index)
        }
    }

    /** Re-insert an item at [index] (used by Undo). */
    fun insertAt(index: Int, item: Any) {
        val safeIdx = index.coerceIn(0, items.size)
        items.add(safeIdx, item)
        notifyItemInserted(safeIdx)
    }

    fun destroy() = scope.cancel()
}
