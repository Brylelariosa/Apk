package com.melodiq.data.model

sealed class LyricsResult {
    object Loading : LyricsResult()
    object NotFound : LyricsResult()
    data class Synced(val lines: List<LyricLine>) : LyricsResult()
    data class Plain(val text: String) : LyricsResult()
}
