package com.melodiq

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class MelodiqApp : Application()
