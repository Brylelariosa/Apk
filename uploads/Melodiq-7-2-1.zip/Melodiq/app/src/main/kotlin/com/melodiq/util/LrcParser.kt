package com.melodiq.util

import com.melodiq.data.model.LyricLine

object LrcParser {
    // Matches [mm:ss.xx] or [mm:ss.xxx]
    private val TIMESTAMP_REGEX = Regex("""\[(\d{2}):(\d{2})\.(\d{2,3})\]""")
    // Metadata tags like [ar:Artist], [ti:Title], etc.
    private val METADATA_REGEX = Regex("""\[[a-zA-Z]+:.*?\]""")

    fun parse(lrc: String): List<LyricLine> {
        val lines = mutableListOf<LyricLine>()
        lrc.lines().forEach { line ->
            val trimmed = line.trim()
            if (METADATA_REGEX.matches(trimmed)) return@forEach
            val timestamps = TIMESTAMP_REGEX.findAll(trimmed)
            if (timestamps.none()) return@forEach
            val text = TIMESTAMP_REGEX.replace(trimmed, "").trim()
            if (text.isEmpty()) return@forEach
            timestamps.forEach { match ->
                val minutes = match.groupValues[1].toLong()
                val seconds = match.groupValues[2].toLong()
                val raw = match.groupValues[3]
                val millis = when (raw.length) {
                    2 -> raw.toLong() * 10L   // centiseconds → ms
                    else -> raw.padEnd(3, '0').take(3).toLong()
                }
                val timeMs = minutes * 60_000L + seconds * 1_000L + millis
                lines.add(LyricLine(timeMs, text))
            }
        }
        return lines.sortedBy { it.timeMs }
    }

    /** Binary search: returns index of the active lyric for [positionMs]. */
    fun activeIndex(lines: List<LyricLine>, positionMs: Long): Int {
        if (lines.isEmpty()) return -1
        var lo = 0
        var hi = lines.size - 1
        while (lo < hi) {
            val mid = (lo + hi + 1) / 2
            if (lines[mid].timeMs <= positionMs) lo = mid else hi = mid - 1
        }
        return if (lines[lo].timeMs <= positionMs) lo else -1
    }
}
