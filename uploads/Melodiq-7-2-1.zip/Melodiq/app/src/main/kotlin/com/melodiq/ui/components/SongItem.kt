package com.melodiq.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.melodiq.data.model.Song
import com.melodiq.ui.theme.*
import com.melodiq.util.TimeFormatter

@Composable
fun SongItem(
    song: Song,
    isPlaying: Boolean = false,
    onClick: () -> Unit,
    onFavoriteClick: (() -> Unit)? = null,
    onMoreClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Album art
        Box(
            modifier = Modifier
                .size(52.dp)
                .clip(RoundedCornerShape(10.dp))
        ) {
            AsyncImage(
                model           = song.artworkUri,
                contentDescription = null,
                contentScale    = ContentScale.Crop,
                modifier        = Modifier.fillMaxSize()
            )
            if (isPlaying) {
                PlayingIndicator(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(4.dp)
                )
            }
        }

        Spacer(Modifier.width(12.dp))

        // Title + artist
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text     = song.title,
                style    = MaterialTheme.typography.titleSmall,
                color    = if (isPlaying) PrimaryPurple else TextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(2.dp))
            Text(
                text     = "${song.artist} • ${TimeFormatter.formatMs(song.duration)}",
                style    = MaterialTheme.typography.bodySmall,
                color    = TextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        // Favorite button
        if (onFavoriteClick != null) {
            IconButton(onClick = onFavoriteClick, modifier = Modifier.size(36.dp)) {
                Icon(
                    imageVector = if (song.isFavorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                    contentDescription = null,
                    tint = if (song.isFavorite) AccentPink else TextMuted,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        // More button
        if (onMoreClick != null) {
            IconButton(onClick = onMoreClick, modifier = Modifier.size(36.dp)) {
                Icon(
                    imageVector    = Icons.Filled.MoreVert,
                    contentDescription = null,
                    tint           = TextMuted,
                    modifier       = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
private fun PlayingIndicator(modifier: Modifier = Modifier) {
    Surface(
        modifier  = modifier.size(18.dp),
        shape     = RoundedCornerShape(4.dp),
        color     = PrimaryPurple.copy(alpha = 0.85f)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text("▶", style = MaterialTheme.typography.labelSmall, color = Color.White)
        }
    }
}
