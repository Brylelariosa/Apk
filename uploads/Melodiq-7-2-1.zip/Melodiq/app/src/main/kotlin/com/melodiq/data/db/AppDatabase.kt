package com.melodiq.data.db

import androidx.room.Database
import androidx.room.RoomDatabase
import com.melodiq.data.db.dao.*
import com.melodiq.data.db.entity.*

@Database(
    entities = [
        SongEntity::class,
        LyricsEntity::class,
        PlaylistEntity::class,
        RecentlyPlayedEntity::class,
        FavoriteEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun songDao(): SongDao
    abstract fun lyricsDao(): LyricsDao
    abstract fun playlistDao(): PlaylistDao
    abstract fun recentlyPlayedDao(): RecentlyPlayedDao
    abstract fun favoriteDao(): FavoriteDao
}
