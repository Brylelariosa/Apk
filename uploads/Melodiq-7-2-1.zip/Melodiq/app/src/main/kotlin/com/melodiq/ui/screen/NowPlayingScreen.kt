package com.melodiq.ui.screen

import android.graphics.Bitmap
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.ImageLoader
import coil.request.ImageRequest
import coil.request.SuccessResult
import com.melodiq.data.model.LyricsResult
import com.melodiq.data.model.PlayerState
import com.melodiq.data.model.Song
import com.melodiq.ui.components.*
import com.melodiq.ui.theme.*
import com.melodiq.ui.viewmodel.LyricsViewModel
import com.melodiq.ui.viewmodel.PlayerViewModel
import com.melodiq.util.ColorExtractor
import com.melodiq.util.ExtractedColors
import kotlinx.coroutines.launch

@Composable
fun NowPlayingScreen(
    onBack: () -> Unit,
    playerVm: PlayerViewModel = hiltViewModel(),
    lyricsVm: LyricsViewModel = hiltViewModel()
) {
    val state by playerVm.state.collectAsStateWithLifecycle()
    val lyricsResult by lyricsVm.lyricsResult.collectAsStateWithLifecycle()
    val currentIndex by lyricsVm.currentLineIndex.collectAsStateWithLifecycle()
    val sleepTimer by playerVm.sleepTimer.collectAsStateWithLifecycle()

    var extractedColors by remember { mutableStateOf(ExtractedColors()) }
    var showLyrics by remember { mutableStateOf(false) }
    var showSleepTimer by remember { mutableStateOf(false) }

    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // Extract colors from album art
    LaunchedEffect(state.currentSong?.artworkUri) {
        state.currentSong?.artworkUri?.let { uri ->
            try {
                val loader  = ImageLoader(context)
                val req     = ImageRequest.Builder(context).data(uri).allowHardware(false).build()
                val result  = loader.execute(req)
                if (result is SuccessResult) {
                    val bmp = result.drawable.let {
                        (it as? android.graphics.drawable.BitmapDrawable)?.bitmap
                    }
                    if (bmp != null) {
                        extractedColors = ColorExtractor.extract(bmp)
                    }
                }
            } catch (_: Exception) {}
        }
    }

    // Load lyrics when song changes
    LaunchedEffect(state.currentSong?.id) {
        state.currentSong?.let { lyricsVm.loadLyrics(it) }
    }

    val bg1 = ColorExtractor.darken(extractedColors.dominant, 0.4f)
    val bg2 = ColorExtractor.darken(extractedColors.vibrant, 0.35f)
    val bg3 = Color(0xFF0D0D1A)

    AnimatedGradientBackground(color1 = bg1, color2 = bg2, color3 = bg3) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
        ) {
            // Top bar
            TopBar(
                onBack         = onBack,
                onSleepTimer   = { showSleepTimer = true },
                accentColor    = extractedColors.vibrant,
                sleepActive    = sleepTimer != null
            )

            AnimatedContent(
                targetState = showLyrics,
                transitionSpec = {
                    slideInHorizontally { if (targetState) it else -it } + fadeIn() togetherWith
                    slideOutHorizontally { if (targetState) -it else it } + fadeOut()
                },
                label = "now_playing_panels"
            ) { lyricsMode ->
                if (lyricsMode) {
                    // Lyrics panel
                    Column(modifier = Modifier.fillMaxSize()) {
                        Spacer(Modifier.height(16.dp))
                        LyricsView(
                            result       = lyricsResult,
                            currentIndex = currentIndex,
                            accentColor  = extractedColors.vibrant,
                            modifier     = Modifier.weight(1f)
                        )
                        ControlsSection(
                            state          = state,
                            accentColor    = extractedColors.vibrant,
                            onTogglePlayPause = playerVm::togglePlayPause,
                            onSeekToNext   = playerVm::seekToNext,
                            onSeekToPrevious = playerVm::seekToPrevious,
                            onSeekTo       = playerVm::seekTo,
                            onToggleShuffle = playerVm::toggleShuffle,
                            onCycleRepeat  = playerVm::cycleRepeatMode,
                            onToggleLyrics = { showLyrics = false },
                            showingLyrics  = true,
                            onFavorite     = { state.currentSong?.let { playerVm.toggleFavorite(it) } }
                        )
                    }
                } else {
                    // Album art panel
                    Column(
                        modifier             = Modifier.fillMaxSize(),
                        horizontalAlignment  = Alignment.CenterHorizontally
                    ) {
                        Spacer(Modifier.height(16.dp))
                        AlbumArtSection(
                            song        = state.currentSong,
                            isPlaying   = state.isPlaying,
                            modifier    = Modifier.weight(1f)
                        )
                        SongInfoSection(
                            song        = state.currentSong,
                            accentColor = extractedColors.vibrant,
                            onFavorite  = { state.currentSong?.let { playerVm.toggleFavorite(it) } }
                        )
                        ControlsSection(
                            state          = state,
                            accentColor    = extractedColors.vibrant,
                            onTogglePlayPause = playerVm::togglePlayPause,
                            onSeekToNext   = playerVm::seekToNext,
                            onSeekToPrevious = playerVm::seekToPrevious,
                            onSeekTo       = playerVm::seekTo,
                            onToggleShuffle = playerVm::toggleShuffle,
                            onCycleRepeat  = playerVm::cycleRepeatMode,
                            onToggleLyrics = { showLyrics = true },
                            showingLyrics  = false,
                            onFavorite     = { state.currentSong?.let { playerVm.toggleFavorite(it) } }
                        )
                    }
                }
            }
        }
    }

    // Sleep timer dialog
    if (showSleepTimer) {
        SleepTimerDialog(
            currentTimer = sleepTimer,
            onDismiss    = { showSleepTimer = false },
            onSetTimer   = { mins ->
                playerVm.setSleepTimer(mins)
                showSleepTimer = false
            },
            onCancel     = {
                playerVm.cancelSleepTimer()
                showSleepTimer = false
            }
        )
    }
}

@Composable
private fun TopBar(
    onBack: () -> Unit,
    onSleepTimer: () -> Unit,
    accentColor: Color,
    sleepActive: Boolean
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment     = Alignment.CenterVertically
    ) {
        IconButton(onClick = onBack) {
            Icon(Icons.Rounded.KeyboardArrowDown, null, tint = Color.White, modifier = Modifier.size(28.dp))
        }
        Text("Now Playing", style = MaterialTheme.typography.titleMedium, color = Color.White)
        IconButton(onClick = onSleepTimer) {
            Icon(
                imageVector = if (sleepActive) Icons.Filled.Bedtime else Icons.Filled.BedtimeOff,
                contentDescription = null,
                tint = if (sleepActive) accentColor else TextSecondary,
                modifier = Modifier.size(22.dp)
            )
        }
    }
}

@Composable
private fun AlbumArtSection(song: Song?, isPlaying: Boolean, modifier: Modifier) {
    Box(modifier = modifier.padding(horizontal = 32.dp), contentAlignment = Alignment.Center) {
        val rotation by rememberInfiniteTransition(label = "art_rotate").animateFloat(
            initialValue   = 0f,
            targetValue    = 360f,
            animationSpec  = infiniteRepeatable(tween(20000, easing = LinearEasing)),
            label          = "rotation"
        )
        coil.compose.AsyncImage(
            model              = song?.artworkUri,
            contentDescription = null,
            contentScale       = ContentScale.Crop,
            modifier           = Modifier
                .size(280.dp)
                .clip(CircleShape)
                .rotate(if (isPlaying) rotation else 0f)
        )
    }
}

@Composable
private fun SongInfoSection(song: Song?, accentColor: Color, onFavorite: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text      = song?.title ?: "No track",
                style     = MaterialTheme.typography.headlineSmall,
                color     = Color.White,
                maxLines  = 1,
                overflow  = TextOverflow.Ellipsis
            )
            Text(
                text     = song?.artist ?: "",
                style    = MaterialTheme.typography.bodyMedium,
                color    = TextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        IconButton(onClick = onFavorite, modifier = Modifier.size(48.dp)) {
            Icon(
                imageVector = if (song?.isFavorite == true) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                contentDescription = null,
                tint = if (song?.isFavorite == true) AccentPink else TextSecondary,
                modifier = Modifier.size(26.dp)
            )
        }
    }
}

@Composable
private fun ControlsSection(
    state: PlayerState,
    accentColor: Color,
    onTogglePlayPause: () -> Unit,
    onSeekToNext: () -> Unit,
    onSeekToPrevious: () -> Unit,
    onSeekTo: (Long) -> Unit,
    onToggleShuffle: () -> Unit,
    onCycleRepeat: () -> Unit,
    onToggleLyrics: () -> Unit,
    showingLyrics: Boolean,
    onFavorite: () -> Unit
) {
    Column(modifier = Modifier.padding(bottom = 16.dp)) {
        PlayerControls(
            state             = state,
            onTogglePlayPause = onTogglePlayPause,
            onSeekToNext      = onSeekToNext,
            onSeekToPrevious  = onSeekToPrevious,
            onSeekTo          = onSeekTo,
            onToggleShuffle   = onToggleShuffle,
            onCycleRepeat     = onCycleRepeat,
            accentColor       = accentColor,
            modifier          = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp)
        )
        Spacer(Modifier.height(8.dp))
        Row(
            modifier              = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center
        ) {
            IconButton(onClick = onToggleLyrics) {
                Icon(
                    imageVector = Icons.Rounded.Lyrics,
                    contentDescription = "Lyrics",
                    tint = if (showingLyrics) accentColor else TextSecondary,
                    modifier = Modifier.size(22.dp)
                )
            }
        }
    }
}

@Composable
private fun SleepTimerDialog(
    currentTimer: com.melodiq.data.model.SleepTimer?,
    onDismiss: () -> Unit,
    onSetTimer: (Int) -> Unit,
    onCancel: () -> Unit
) {
    val options = listOf(5, 10, 15, 30, 45, 60, 90)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Sleep Timer") },
        text = {
            Column {
                if (currentTimer != null) {
                    Text("Timer active", color = PrimaryPurple, style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(8.dp))
                    TextButton(onClick = onCancel) { Text("Cancel Timer", color = AccentPink) }
                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                }
                Text("Set timer:", style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(8.dp))
                options.chunked(4).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { mins ->
                            FilterChip(
                                selected = currentTimer?.durationMinutes == mins,
                                onClick  = { onSetTimer(mins) },
                                label    = { Text("${mins}m") }
                            )
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}
