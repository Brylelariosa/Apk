package com.melodiq.data.db.dao

import androidx.room.*
import com.melodiq.data.db.entity.LyricsEntity

@Dao
interface LyricsDao {
    @Upsert
    suspend fun upsert(entity: LyricsEntity)

    @Query("SELECT * FROM lyrics_cache WHERE cacheKey = :key LIMIT 1")
    suspend fun getByKey(key: String): LyricsEntity?

    @Query("DELETE FROM lyrics_cache WHERE fetchedAt < :olderThan")
    suspend fun purgeOlderThan(olderThan: Long)
}
