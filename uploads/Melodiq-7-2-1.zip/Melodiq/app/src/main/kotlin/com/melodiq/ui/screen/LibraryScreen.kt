package com.melodiq.ui.screen

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.*
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.melodiq.ui.components.SongItem
import com.melodiq.ui.theme.*
import com.melodiq.ui.viewmodel.LibraryViewModel
import com.melodiq.ui.viewmodel.PlayerViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LibraryScreen(
    onNavigateToNowPlaying: () -> Unit,
    libraryVm: LibraryViewModel = hiltViewModel(),
    playerVm: PlayerViewModel   = hiltViewModel()
) {
    val uiState     by libraryVm.uiState.collectAsStateWithLifecycle()
    val playerState by playerVm.state.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) {
        if (uiState.allSongs.isEmpty()) libraryVm.syncLibrary()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title   = { Text("Library", style = MaterialTheme.typography.titleLarge, color = TextPrimary) },
                actions = {
                    if (uiState.isLoading) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp).padding(4.dp), strokeWidth = 2.dp, color = PrimaryPurple)
                    } else {
                        IconButton(onClick = libraryVm::syncLibrary) {
                            Icon(Icons.Rounded.Refresh, null, tint = TextSecondary)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = androidx.compose.ui.graphics.Color.Transparent)
            )
        },
        containerColor = androidx.compose.ui.graphics.Color.Transparent
    ) { padding ->
        if (uiState.allSongs.isEmpty() && !uiState.isLoading) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("🎵", style = MaterialTheme.typography.displayLarge)
                    Spacer(Modifier.height(16.dp))
                    Text("No songs found", color = TextSecondary, style = MaterialTheme.typography.bodyLarge)
                    Spacer(Modifier.height(8.dp))
                    Text("Make sure storage permission is granted", color = TextMuted, style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = libraryVm::syncLibrary) { Text("Scan Library") }
                }
            }
        } else {
            LazyColumn(
                modifier       = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(top = padding.calculateTopPadding(), bottom = 16.dp)
            ) {
                item {
                    Text(
                        "${uiState.allSongs.size} songs",
                        style    = MaterialTheme.typography.labelMedium,
                        color    = TextMuted,
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
                    )
                }
                itemsIndexed(uiState.allSongs, key = { _, s -> s.id }) { idx, song ->
                    SongItem(
                        song            = song,
                        isPlaying       = playerState.currentSong?.id == song.id && playerState.isPlaying,
                        onClick         = {
                            playerVm.playSongs(uiState.allSongs, idx)
                            onNavigateToNowPlaying()
                        },
                        onFavoriteClick = { playerVm.toggleFavorite(song) }
                    )
                    if (idx < uiState.allSongs.lastIndex) {
                        HorizontalDivider(
                            modifier  = Modifier.padding(start = 80.dp, end = 16.dp),
                            thickness = 0.5.dp,
                            color     = Divider
                        )
                    }
                }
            }
        }
    }
}
