package com.melodiq.data.repository

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import com.melodiq.data.db.dao.FavoriteDao
import com.melodiq.data.db.dao.RecentlyPlayedDao
import com.melodiq.data.db.dao.SongDao
import com.melodiq.data.db.entity.FavoriteEntity
import com.melodiq.data.db.entity.RecentlyPlayedEntity
import com.melodiq.data.db.entity.SongEntity
import com.melodiq.data.model.Song
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MusicRepository @Inject constructor(
    @ApplicationContext private val context: Context,
    private val songDao: SongDao,
    private val recentlyPlayedDao: RecentlyPlayedDao,
    private val favoriteDao: FavoriteDao
) {
    private val albumArtBaseUri = Uri.parse("content://media/external/audio/albumart")

    val allSongs: Flow<List<Song>> = combine(
        songDao.observeAll(),
        favoriteDao.observeAll()
    ) { entities, favoriteIds ->
        val favSet = favoriteIds.toSet()
        entities.map { it.toSong(favSet.contains(it.id)) }
    }

    val recentSongs: Flow<List<Song>> = combine(
        recentlyPlayedDao.observeRecentIds(),
        songDao.observeAll(),
        favoriteDao.observeAll()
    ) { recentIds, allEntities, favoriteIds ->
        val map = allEntities.associateBy { it.id }
        val favSet = favoriteIds.toSet()
        recentIds.mapNotNull { id -> map[id]?.toSong(favSet.contains(id)) }
    }

    val favoriteSongs: Flow<List<Song>> = combine(
        favoriteDao.observeAll(),
        songDao.observeAll()
    ) { favoriteIds, allEntities ->
        val favSet = favoriteIds.toSet()
        val map = allEntities.associateBy { it.id }
        favoriteIds.mapNotNull { id -> map[id]?.toSong(true) }
    }

    fun searchSongs(query: String): Flow<List<Song>> = combine(
        songDao.search(query),
        favoriteDao.observeAll()
    ) { entities, favoriteIds ->
        val favSet = favoriteIds.toSet()
        entities.map { it.toSong(favSet.contains(it.id)) }
    }

    suspend fun syncLibrary(): Int = withContext(Dispatchers.IO) {
        val songs = scanMediaStore()
        songDao.upsertAll(songs.map { it.toEntity() })
        songDao.deleteOrphans(songs.map { it.id })
        songs.size
    }

    suspend fun getSongById(id: Long): Song? = withContext(Dispatchers.IO) {
        val favSet = favoriteDao.observeAll().let { emptySet<Long>() }
        songDao.getById(id)?.toSong(false)
    }

    suspend fun markRecentlyPlayed(songId: Long) = withContext(Dispatchers.IO) {
        recentlyPlayedDao.upsert(RecentlyPlayedEntity(songId = songId))
        recentlyPlayedDao.trimToMax()
    }

    suspend fun toggleFavorite(songId: Long, isFavorite: Boolean) = withContext(Dispatchers.IO) {
        if (isFavorite) favoriteDao.upsert(FavoriteEntity(songId = songId))
        else favoriteDao.delete(songId)
    }

    fun isFavorite(songId: Long): Flow<Boolean> = favoriteDao.isFavorite(songId)

    // ── MediaStore scanning ──────────────────────────────────────────────────
    private fun scanMediaStore(): List<Song> {
        val songs = mutableListOf<Song>()
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.ALBUM_ID
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= 30000"
        val sortOrder = "${MediaStore.Audio.Media.TITLE} ASC"

        context.contentResolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            projection, selection, null, sortOrder
        )?.use { cursor ->
            val idCol       = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol    = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol   = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumCol    = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val sizeCol     = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
            val dateCol     = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
            val albumIdCol  = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)

            while (cursor.moveToNext()) {
                val id      = cursor.getLong(idCol)
                val albumId = cursor.getLong(albumIdCol)
                val uri     = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
                val artUri  = ContentUris.withAppendedId(albumArtBaseUri, albumId)
                songs.add(
                    Song(
                        id          = id,
                        title       = cursor.getString(titleCol) ?: "Unknown",
                        artist      = cursor.getString(artistCol) ?: "Unknown Artist",
                        album       = cursor.getString(albumCol) ?: "Unknown Album",
                        duration    = cursor.getLong(durationCol),
                        uri         = uri,
                        artworkUri  = artUri,
                        size        = cursor.getLong(sizeCol),
                        dateAdded   = cursor.getLong(dateCol),
                        albumId     = albumId
                    )
                )
            }
        }
        return songs
    }

    private fun Song.toEntity() = SongEntity(
        id = id, title = title, artist = artist, album = album,
        duration = duration, uriString = uri.toString(),
        artworkUriString = artworkUri?.toString(), size = size,
        dateAdded = dateAdded, albumId = albumId
    )

    private fun SongEntity.toSong(isFav: Boolean) = Song(
        id = id, title = title, artist = artist, album = album,
        duration = duration,
        uri = Uri.parse(uriString),
        artworkUri = artworkUriString?.let { Uri.parse(it) },
        size = size, dateAdded = dateAdded, albumId = albumId,
        isFavorite = isFav
    )
}
