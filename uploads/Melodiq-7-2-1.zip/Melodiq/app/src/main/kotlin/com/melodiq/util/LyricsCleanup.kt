package com.melodiq.util

enum class SectionType { VERSE, CHORUS, BRIDGE, INTRO, OUTRO, PRE_CHORUS, HOOK, UNKNOWN }

data class ProcessedLyric(
    val text: String,
    val section: SectionType? = null,
    val isSection: Boolean = false
)

object LyricsCleanup {
    // [text](url) → text
    private val MARKDOWN_LINK = Regex("""\[([^\]]+)]\([^)]+\)""")
    // {annotation}
    private val ANNOTATION = Regex("""\{[^}]*}""")
    // Brackets that are NOT timestamps → [Chorus], [Verse 1], etc.
    private val SECTION_TAG = Regex("""^\[([^\d:][^\]]*)]$""")

    fun clean(raw: String): String = raw
        .replace(MARKDOWN_LINK, "$1")
        .replace(ANNOTATION, "")
        .trim()

    fun detectSection(line: String): SectionType? {
        val lower = line.lowercase().trim()
            .removePrefix("[").removeSuffix("]").trim()
        return when {
            lower.startsWith("chorus") || lower == "hook" -> SectionType.CHORUS
            lower.startsWith("verse")                     -> SectionType.VERSE
            lower.startsWith("bridge")                    -> SectionType.BRIDGE
            lower.startsWith("intro")                     -> SectionType.INTRO
            lower.startsWith("outro")                     -> SectionType.OUTRO
            lower.startsWith("pre-chorus") || lower.startsWith("pre chorus") -> SectionType.PRE_CHORUS
            lower.startsWith("hook")                      -> SectionType.HOOK
            else                                          -> null
        }
    }

    fun processPlainLyrics(plain: String): List<ProcessedLyric> {
        return plain.lines().mapNotNull { raw ->
            val line = clean(raw.trim())
            if (line.isBlank()) return@mapNotNull null
            val sectionMatch = SECTION_TAG.find(line)
            if (sectionMatch != null) {
                val section = detectSection(line)
                ProcessedLyric(
                    text = sectionMatch.groupValues[1].trim(),
                    section = section ?: SectionType.UNKNOWN,
                    isSection = true
                )
            } else {
                ProcessedLyric(text = line)
            }
        }
    }
}
