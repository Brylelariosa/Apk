package com.melodiq.data.repository

import com.melodiq.data.db.dao.LyricsDao
import com.melodiq.data.db.entity.LyricsEntity
import com.melodiq.data.model.LyricLine
import com.melodiq.data.model.LyricsResult
import com.melodiq.data.model.Song
import com.melodiq.data.network.LrcLibService
import com.melodiq.util.LrcParser
import com.melodiq.util.LyricsCleanup
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import retrofit2.Response
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class LyricsRepository @Inject constructor(
    private val lrcLibService: LrcLibService,
    private val lyricsDao: LyricsDao
) {
    companion object {
        // Cache valid for 30 days
        private const val CACHE_TTL_MS = 30L * 24 * 60 * 60 * 1000
        // MediaStore placeholder when tag is absent
        private const val UNKNOWN_TAG = "<unknown>"
    }

    suspend fun getLyrics(song: Song, offsetMs: Long = 0L): LyricsResult =
        withContext(Dispatchers.IO) {
            val key = cacheKey(song)

            // 1. Check cache
            val cached = lyricsDao.getByKey(key)
            if (cached != null && System.currentTimeMillis() - cached.fetchedAt < CACHE_TTL_MS) {
                return@withContext parseCached(cached, offsetMs)
            }

            // 2. Fetch from LRCLIB
            return@withContext try {
                // MediaStore uses "<unknown>" when tags are missing — omit those fields
                // so LRCLIB can match on title + duration alone
                val cleanArtist = song.artist.takeIf { it.isNotBlank() && it != UNKNOWN_TAG }
                val cleanAlbum  = song.album.takeIf  { it.isNotBlank() && it != UNKNOWN_TAG }
                val httpResp = lrcLibService.getLyrics(
                    artistName = cleanArtist,
                    trackName  = song.title,
                    albumName  = cleanAlbum,
                    duration   = (song.duration / 1000).toInt().takeIf { it > 0 }
                )
                val response = if (httpResp.isSuccessful) httpResp.body() else null

                if (response != null) {
                    // Cache result
                    lyricsDao.upsert(
                        LyricsEntity(
                            cacheKey     = key,
                            syncedLyrics = response.syncedLyrics,
                            plainLyrics  = response.plainLyrics,
                            trackTitle   = song.title,
                            artistName   = song.artist,
                            albumName    = song.album
                        )
                    )
                    parseCached(
                        LyricsEntity(
                            cacheKey     = key,
                            syncedLyrics = response.syncedLyrics,
                            plainLyrics  = response.plainLyrics,
                            trackTitle   = song.title,
                            artistName   = song.artist,
                            albumName    = song.album
                        ),
                        offsetMs
                    )
                } else {
                    // Cache the miss to avoid hammering the API
                    lyricsDao.upsert(
                        LyricsEntity(
                            cacheKey     = key,
                            syncedLyrics = null,
                            plainLyrics  = null,
                            trackTitle   = song.title,
                            artistName   = song.artist,
                            albumName    = song.album
                        )
                    )
                    LyricsResult.NotFound
                }
            } catch (e: CancellationException) {
                // FIX: always rethrow CancellationException — swallowing it breaks
                //      coroutine cancellation and keeps cancelled fetches running
                throw e
            } catch (e: Exception) {
                // Network error — return cached miss or NotFound
                cached?.let { parseCached(it, offsetMs) } ?: LyricsResult.NotFound
            }
        }

    suspend fun storeLrcFile(song: Song, lrcContent: String) = withContext(Dispatchers.IO) {
        val key = cacheKey(song)
        lyricsDao.upsert(
            LyricsEntity(
                cacheKey     = key,
                syncedLyrics = lrcContent,
                plainLyrics  = null,
                trackTitle   = song.title,
                artistName   = song.artist,
                albumName    = song.album
            )
        )
    }

    suspend fun purgeOldCache() = withContext(Dispatchers.IO) {
        lyricsDao.purgeOlderThan(System.currentTimeMillis() - CACHE_TTL_MS)
    }

    // ── Helpers ──────────────────────────────────────────────────────────────
    private fun cacheKey(song: Song): String {
        val durationSec = song.duration / 1000
        return "${song.title.lowercase()}|${song.artist.lowercase()}|$durationSec"
    }

    private fun parseCached(entity: LyricsEntity, offsetMs: Long): LyricsResult {
        val synced = entity.syncedLyrics
        if (!synced.isNullOrBlank()) {
            val lines = LrcParser.parse(synced).map { line ->
                line.copy(
                    text  = LyricsCleanup.clean(line.text),
                    timeMs = (line.timeMs + offsetMs).coerceAtLeast(0L)
                )
            }.filter { it.text.isNotBlank() }
            if (lines.isNotEmpty()) return LyricsResult.Synced(lines)
        }

        val plain = entity.plainLyrics
        if (!plain.isNullOrBlank()) {
            return LyricsResult.Plain(plain)
        }

        return LyricsResult.NotFound
    }
}
