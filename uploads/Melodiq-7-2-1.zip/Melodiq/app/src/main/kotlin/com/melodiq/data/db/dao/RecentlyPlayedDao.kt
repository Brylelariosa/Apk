package com.melodiq.data.db.dao

import androidx.room.*
import com.melodiq.data.db.entity.RecentlyPlayedEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface RecentlyPlayedDao {
    @Upsert
    suspend fun upsert(entity: RecentlyPlayedEntity)

    @Query("SELECT songId FROM recently_played ORDER BY playedAt DESC LIMIT :limit")
    fun observeRecentIds(limit: Int = 30): Flow<List<Long>>

    @Query("SELECT songId FROM recently_played ORDER BY playedAt DESC LIMIT :limit")
    suspend fun getRecentIds(limit: Int = 30): List<Long>

    @Query("DELETE FROM recently_played WHERE songId NOT IN (SELECT songId FROM recently_played ORDER BY playedAt DESC LIMIT 50)")
    suspend fun trimToMax()
}
