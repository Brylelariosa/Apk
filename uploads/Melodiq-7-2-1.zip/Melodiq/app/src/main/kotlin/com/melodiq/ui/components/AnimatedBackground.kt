package com.melodiq.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.melodiq.ui.theme.DeepPurple
import com.melodiq.ui.theme.MidnightBlue

@Composable
fun AnimatedGradientBackground(
    color1: Color = DeepPurple,
    color2: Color = MidnightBlue,
    color3: Color = Color(0xFF0D0D1A),
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    val animColor1 by animateColorAsState(
        targetValue = color1,
        animationSpec = tween(durationMillis = 800, easing = FastOutSlowInEasing),
        label = "bg_color1"
    )
    val animColor2 by animateColorAsState(
        targetValue = color2,
        animationSpec = tween(durationMillis = 900, easing = FastOutSlowInEasing),
        label = "bg_color2"
    )
    val animColor3 by animateColorAsState(
        targetValue = color3,
        animationSpec = tween(durationMillis = 1000, easing = FastOutSlowInEasing),
        label = "bg_color3"
    )

    val infiniteTransition = rememberInfiniteTransition(label = "bg_gradient")
    val shift by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue  = 1f,
        animationSpec = infiniteRepeatable(
            animation  = tween(6000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "bg_shift"
    )

    val brush = Brush.linearGradient(
        colors = listOf(animColor1, animColor2, animColor3),
        start  = Offset(shift * 600f, 0f),
        end    = Offset(600f, shift * 1200f)
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(brush),
        content = content
    )
}
