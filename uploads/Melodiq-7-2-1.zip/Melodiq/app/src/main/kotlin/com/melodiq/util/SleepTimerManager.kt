package com.melodiq.util

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SleepTimerManager @Inject constructor() {
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var job: Job? = null

    private val _remainingMs = MutableStateFlow(-1L)
    val remainingMs: StateFlow<Long> = _remainingMs.asStateFlow()

    fun start(durationMinutes: Int, onExpire: () -> Unit) {
        job?.cancel()
        val endAt = System.currentTimeMillis() + durationMinutes * 60_000L
        job = scope.launch {
            while (isActive) {
                val remaining = endAt - System.currentTimeMillis()
                if (remaining <= 0) {
                    _remainingMs.value = 0L
                    withContext(Dispatchers.Main) { onExpire() }
                    cancel()
                    return@launch
                }
                _remainingMs.value = remaining
                delay(1000L)
            }
        }
    }

    fun cancel() {
        job?.cancel()
        job = null
        _remainingMs.value = -1L
    }

    fun isActive(): Boolean = job?.isActive == true
}
