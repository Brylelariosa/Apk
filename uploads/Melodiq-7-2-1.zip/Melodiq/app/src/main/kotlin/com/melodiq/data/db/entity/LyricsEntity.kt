package com.melodiq.data.db.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "lyrics_cache")
data class LyricsEntity(
    @PrimaryKey val cacheKey: String,   // "title|artist|durationSec"
    val syncedLyrics: String?,          // raw LRC string
    val plainLyrics: String?,
    val trackTitle: String,
    val artistName: String,
    val albumName: String,
    val fetchedAt: Long = System.currentTimeMillis()
)
