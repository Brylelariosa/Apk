package com.melodiq.ui.theme

import androidx.compose.ui.graphics.Color

// Base palette
val DeepPurple    = Color(0xFF1A0A2E)
val MidnightBlue  = Color(0xFF0F0F23)
val SurfaceDark   = Color(0xFF1E1B2E)
val SurfaceCard   = Color(0xFF252336)
val PrimaryPurple = Color(0xFF6C63FF)
val AccentViolet  = Color(0xFF9C88FF)
val AccentPink    = Color(0xFFFF6B9D)
val GlowPurple    = Color(0x406C63FF)
val GlowPink      = Color(0x40FF6B9D)
val TextPrimary   = Color(0xFFEEEEFF)
val TextSecondary = Color(0xFFAAAAAC)
val TextMuted     = Color(0xFF6B6B80)
val OnSurface     = Color(0xFFE8E8F0)
val Divider       = Color(0xFF2A273D)
val White10       = Color(0x1AFFFFFF)
val White20       = Color(0x33FFFFFF)
val White30       = Color(0x4DFFFFFF)
val Black60       = Color(0x99000000)
