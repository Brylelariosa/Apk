package com.melodiq.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.melodiq.data.model.LyricsResult
import com.melodiq.data.model.Song
import com.melodiq.data.repository.LyricsRepository
import com.melodiq.player.PlayerManager
import com.melodiq.util.LrcParser
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class LyricsViewModel @Inject constructor(
    private val lyricsRepository: LyricsRepository,
    private val playerManager: PlayerManager
) : ViewModel() {

    private val _lyricsResult = MutableStateFlow<LyricsResult>(LyricsResult.Loading)
    val lyricsResult: StateFlow<LyricsResult> = _lyricsResult.asStateFlow()

    private val _currentLineIndex = MutableStateFlow(-1)
    val currentLineIndex: StateFlow<Int> = _currentLineIndex.asStateFlow()

    private val _lyricOffset = MutableStateFlow(0L)
    val lyricOffset: StateFlow<Long> = _lyricOffset.asStateFlow()

    private var syncJob: Job? = null
    private var fetchJob: Job? = null   // FIX: track the fetch so it can be cancelled
    private var currentSong: Song? = null

    fun loadLyrics(song: Song) {
        if (song.id == currentSong?.id) return
        currentSong = song
        syncJob?.cancel()
        fetchJob?.cancel()  // FIX: cancel any in-flight fetch for the previous song
        _lyricsResult.value = LyricsResult.Loading
        _currentLineIndex.value = -1

        fetchJob = viewModelScope.launch {
            // FIX: wrap in try/catch so any DB or network exception doesn't leave
            //      the UI frozen in Loading state forever
            val result = try {
                lyricsRepository.getLyrics(song, _lyricOffset.value)
            } catch (e: Exception) {
                LyricsResult.NotFound
            }
            _lyricsResult.value = result
            if (result is LyricsResult.Synced) {
                startSyncLoop(result)
            }
        }
    }

    fun setOffset(offsetMs: Long) {
        _lyricOffset.value = offsetMs
        currentSong?.let { song ->
            currentSong = null   // force reload
            loadLyrics(song)
        }
    }

    private fun startSyncLoop(synced: LyricsResult.Synced) {
        syncJob?.cancel()
        syncJob = viewModelScope.launch {
            while (isActive) {
                val position = playerManager.getCurrentPosition()
                val idx = LrcParser.activeIndex(synced.lines, position)
                if (_currentLineIndex.value != idx) {
                    _currentLineIndex.value = idx
                }
                delay(100L)
            }
        }
    }

    override fun onCleared() {
        syncJob?.cancel()
        fetchJob?.cancel()
        super.onCleared()
    }
}
