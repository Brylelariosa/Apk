package com.melodiq.data.db.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val songIdsJson: String,   // JSON array of Long
    val createdAt: Long = System.currentTimeMillis()
)
