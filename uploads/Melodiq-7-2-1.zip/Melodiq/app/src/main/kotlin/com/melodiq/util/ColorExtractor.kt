package com.melodiq.util

import android.graphics.Bitmap
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.palette.graphics.Palette
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class ExtractedColors(
    val dominant: Color = Color(0xFF1A0A2E.toInt()),
    val vibrant: Color = Color(0xFF6C63FF.toInt()),
    val muted: Color = Color(0xFF2D2D44.toInt())
)

object ColorExtractor {
    suspend fun extract(bitmap: Bitmap): ExtractedColors = withContext(Dispatchers.Default) {
        try {
            val palette = Palette.from(bitmap).maximumColorCount(16).generate()
            ExtractedColors(
                dominant = Color(palette.getDominantColor(Color(0xFF1A0A2E.toInt()).toArgb())),
                vibrant  = Color(palette.getVibrantColor(Color(0xFF6C63FF.toInt()).toArgb())),
                muted    = Color(palette.getMutedColor(Color(0xFF2D2D44.toInt()).toArgb()))
            )
        } catch (e: Exception) {
            ExtractedColors()
        }
    }

    fun darken(color: Color, factor: Float = 0.35f): Color {
        return Color(
            red   = color.red   * factor,
            green = color.green * factor,
            blue  = color.blue  * factor,
            alpha = 1f
        )
    }
}
