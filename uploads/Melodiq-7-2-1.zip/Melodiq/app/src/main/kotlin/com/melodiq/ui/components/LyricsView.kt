package com.melodiq.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.melodiq.data.model.LyricLine
import com.melodiq.data.model.LyricsResult
import com.melodiq.ui.theme.*
import com.melodiq.util.LyricsCleanup
import com.melodiq.util.ProcessedLyric
import kotlinx.coroutines.launch

@Composable
fun LyricsView(
    result: LyricsResult,
    currentIndex: Int,
    modifier: Modifier = Modifier,
    accentColor: Color = PrimaryPurple
) {
    when (result) {
        is LyricsResult.Loading  -> LyricsLoading(modifier)
        is LyricsResult.NotFound -> LyricsEmpty(modifier)
        is LyricsResult.Synced   -> SyncedLyricsContent(result.lines, currentIndex, accentColor, modifier)
        is LyricsResult.Plain    -> PlainLyricsContent(result.text, modifier)
    }
}

// ── Synced lyrics ─────────────────────────────────────────────────────────────
@Composable
private fun SyncedLyricsContent(
    lines: List<LyricLine>,
    activeIndex: Int,
    accentColor: Color,
    modifier: Modifier
) {
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    // Scroll to keep active line centered, with 2-item offset for context
    LaunchedEffect(activeIndex) {
        if (activeIndex >= 0 && lines.isNotEmpty()) {
            scope.launch {
                val targetIdx = (activeIndex - 2).coerceAtLeast(0)
                listState.animateScrollToItem(targetIdx, scrollOffset = 0)
            }
        }
    }

    LazyColumn(
        state         = listState,
        modifier      = modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 24.dp, vertical = 80.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        itemsIndexed(items = lines, key = { idx, _ -> idx }) { index, line ->
            SyncedLyricLine(
                text        = line.text,
                isActive    = index == activeIndex,
                accentColor = accentColor
            )
        }
    }
}

@Composable
private fun SyncedLyricLine(
    text: String,
    isActive: Boolean,
    accentColor: Color
) {
    val scale by animateFloatAsState(
        targetValue  = if (isActive) 1.08f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label        = "lyric_scale"
    )
    val textColor by animateColorAsState(
        targetValue  = if (isActive) Color.White else TextMuted,
        animationSpec = tween(250),
        label        = "lyric_color"
    )
    val glowAlpha by animateFloatAsState(
        targetValue  = if (isActive) 1f else 0f,
        animationSpec = tween(300),
        label        = "lyric_glow"
    )

    Text(
        text      = text,
        color     = textColor,
        fontSize  = if (isActive) 18.sp else 16.sp,
        fontWeight = if (isActive) FontWeight.SemiBold else FontWeight.Normal,
        textAlign = TextAlign.Center,
        lineHeight = 28.sp,
        modifier  = Modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .drawBehind {
                if (glowAlpha > 0f) {
                    drawRect(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                accentColor.copy(alpha = 0.15f * glowAlpha),
                                Color.Transparent
                            ),
                            radius = size.width * 0.7f
                        ),
                        blendMode = BlendMode.Screen
                    )
                }
            }
    )
}

// ── Plain lyrics ──────────────────────────────────────────────────────────────
@Composable
private fun PlainLyricsContent(text: String, modifier: Modifier) {
    val processed = remember(text) { LyricsCleanup.processPlainLyrics(text) }
    LazyColumn(
        modifier       = modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 24.dp, vertical = 40.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        itemsIndexed(processed, key = { i, _ -> i }) { _, item: ProcessedLyric ->
            if (item.isSection) {
                SectionLabel(item.text)
            } else {
                Text(
                    text      = item.text,
                    color     = TextSecondary,
                    fontSize  = 16.sp,
                    textAlign = TextAlign.Center,
                    lineHeight = 26.sp,
                    modifier  = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                )
            }
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text      = text.uppercase(),
        color     = PrimaryPurple,
        style     = MaterialTheme.typography.labelSmall,
        letterSpacing = 3.sp,
        modifier  = Modifier.padding(top = 24.dp, bottom = 8.dp)
    )
}

// ── States ────────────────────────────────────────────────────────────────────
@Composable
private fun LyricsLoading(modifier: Modifier) {
    Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator(color = PrimaryPurple, modifier = Modifier.size(32.dp))
            Spacer(Modifier.height(16.dp))
            Text("Fetching lyrics…", color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun LyricsEmpty(modifier: Modifier) {
    Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("🎵", fontSize = 40.sp)
            Spacer(Modifier.height(12.dp))
            Text("Lyrics not available", color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(4.dp))
            Text("Play a song to search online", color = TextMuted, style = MaterialTheme.typography.bodySmall)
        }
    }
}
