package com.melodiq.ui.screen

import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Clear
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.melodiq.ui.components.SongItem
import com.melodiq.ui.theme.*
import com.melodiq.ui.viewmodel.PlayerViewModel
import com.melodiq.ui.viewmodel.SearchViewModel

@Composable
fun SearchScreen(
    onNavigateToNowPlaying: () -> Unit,
    searchVm: SearchViewModel = hiltViewModel(),
    playerVm: PlayerViewModel = hiltViewModel()
) {
    val query   by searchVm.query.collectAsStateWithLifecycle()
    val results by searchVm.searchResults.collectAsStateWithLifecycle()
    val playerState by playerVm.state.collectAsStateWithLifecycle()

    val focusRequester = remember { FocusRequester() }

    LaunchedEffect(Unit) {
        try { focusRequester.requestFocus() } catch (_: Exception) {}
    }

    Column(modifier = Modifier.fillMaxSize().padding(top = 16.dp)) {
        // Search bar
        OutlinedTextField(
            value         = query,
            onValueChange = searchVm::updateQuery,
            placeholder   = { Text("Songs, artists, albums…", color = TextMuted) },
            leadingIcon   = { Icon(Icons.Rounded.Search, null, tint = TextSecondary) },
            trailingIcon  = if (query.isNotEmpty()) ({
                IconButton(onClick = searchVm::clearQuery) {
                    Icon(Icons.Rounded.Clear, null, tint = TextSecondary)
                }
            }) else null,
            singleLine    = true,
            shape         = RoundedCornerShape(16.dp),
            colors        = OutlinedTextFieldDefaults.colors(
                focusedBorderColor   = PrimaryPurple,
                unfocusedBorderColor = Divider,
                cursorColor          = PrimaryPurple,
                focusedTextColor     = TextPrimary,
                unfocusedTextColor   = TextPrimary
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .focusRequester(focusRequester)
        )

        Spacer(Modifier.height(8.dp))

        AnimatedVisibility(
            visible = query.isNotEmpty() && results.isEmpty(),
            enter   = fadeIn(),
            exit    = fadeOut()
        ) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("🔍", style = MaterialTheme.typography.displayMedium)
                    Spacer(Modifier.height(12.dp))
                    Text("No results for \"$query\"", color = TextSecondary)
                }
            }
        }

        AnimatedVisibility(
            visible = query.isEmpty(),
            enter   = fadeIn(),
            exit    = fadeOut()
        ) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("🎵", style = MaterialTheme.typography.displayMedium)
                    Spacer(Modifier.height(12.dp))
                    Text("Search your music", color = TextSecondary, style = MaterialTheme.typography.bodyLarge)
                }
            }
        }

        LazyColumn(
            modifier       = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 16.dp)
        ) {
            item {
                if (results.isNotEmpty()) {
                    Text(
                        "${results.size} results",
                        style    = MaterialTheme.typography.labelMedium,
                        color    = TextMuted,
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
                    )
                }
            }
            itemsIndexed(results, key = { _, s -> s.id }) { idx, song ->
                SongItem(
                    song            = song,
                    isPlaying       = playerState.currentSong?.id == song.id && playerState.isPlaying,
                    onClick         = {
                        playerVm.playSongs(results, idx)
                        onNavigateToNowPlaying()
                    },
                    onFavoriteClick = { playerVm.toggleFavorite(song) }
                )
            }
        }
    }
}
