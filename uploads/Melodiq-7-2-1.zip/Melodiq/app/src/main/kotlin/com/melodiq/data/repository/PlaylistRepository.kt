package com.melodiq.data.repository

import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.melodiq.data.db.dao.PlaylistDao
import com.melodiq.data.db.entity.PlaylistEntity
import com.melodiq.data.model.Playlist
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PlaylistRepository @Inject constructor(
    private val playlistDao: PlaylistDao,
    private val gson: Gson
) {
    val allPlaylists: Flow<List<Playlist>> = playlistDao.observeAll().map { entities ->
        entities.map { it.toPlaylist() }
    }

    suspend fun createPlaylist(name: String): Long = withContext(Dispatchers.IO) {
        playlistDao.insert(
            PlaylistEntity(name = name, songIdsJson = gson.toJson(emptyList<Long>()))
        )
    }

    suspend fun addSongToPlaylist(playlistId: Long, songId: Long) = withContext(Dispatchers.IO) {
        val entity = playlistDao.getById(playlistId) ?: return@withContext
        val ids = entity.parseSongIds().toMutableList()
        if (!ids.contains(songId)) {
            ids.add(songId)
            playlistDao.update(entity.copy(songIdsJson = gson.toJson(ids)))
        }
    }

    suspend fun removeSongFromPlaylist(playlistId: Long, songId: Long) = withContext(Dispatchers.IO) {
        val entity = playlistDao.getById(playlistId) ?: return@withContext
        val ids = entity.parseSongIds().filter { it != songId }
        playlistDao.update(entity.copy(songIdsJson = gson.toJson(ids)))
    }

    suspend fun deletePlaylist(playlist: Playlist) = withContext(Dispatchers.IO) {
        playlistDao.delete(PlaylistEntity(
            id          = playlist.id,
            name        = playlist.name,
            songIdsJson = gson.toJson(playlist.songIds)
        ))
    }

    private fun PlaylistEntity.toPlaylist() = Playlist(
        id        = id,
        name      = name,
        songIds   = parseSongIds(),
        createdAt = createdAt
    )

    private fun PlaylistEntity.parseSongIds(): List<Long> = try {
        val type = object : TypeToken<List<Long>>() {}.type
        gson.fromJson(songIdsJson, type) ?: emptyList()
    } catch (e: Exception) { emptyList() }
}
