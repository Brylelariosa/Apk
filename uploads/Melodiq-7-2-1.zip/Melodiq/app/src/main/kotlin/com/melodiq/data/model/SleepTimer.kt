package com.melodiq.data.model

data class SleepTimer(
    val durationMinutes: Int,
    val startedAt: Long = System.currentTimeMillis()
) {
    val endAt: Long get() = startedAt + durationMinutes * 60_000L
    val remainingMs: Long get() = endAt - System.currentTimeMillis()
    val isExpired: Boolean get() = remainingMs <= 0
}
