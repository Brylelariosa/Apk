package com.melodiq.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.melodiq.data.model.Song
import com.melodiq.data.repository.MusicRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class LibraryUiState(
    val allSongs: List<Song> = emptyList(),
    val recentSongs: List<Song> = emptyList(),
    val favoriteSongs: List<Song> = emptyList(),
    val isLoading: Boolean = false,
    val permissionGranted: Boolean = false,
    val syncCount: Int = 0
)

@HiltViewModel
class LibraryViewModel @Inject constructor(
    private val musicRepository: MusicRepository
) : ViewModel() {

    private val _isLoading = MutableStateFlow(false)

    val uiState: StateFlow<LibraryUiState> = combine(
        musicRepository.allSongs,
        musicRepository.recentSongs,
        musicRepository.favoriteSongs,
        _isLoading
    ) { all, recent, fav, loading ->
        LibraryUiState(
            allSongs      = all,
            recentSongs   = recent,
            favoriteSongs = fav,
            isLoading     = loading
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), LibraryUiState())

    fun syncLibrary() {
        viewModelScope.launch {
            _isLoading.value = true
            musicRepository.syncLibrary()
            _isLoading.value = false
        }
    }
}
