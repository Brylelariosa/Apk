package com.melodiq.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary          = PrimaryPurple,
    onPrimary        = Color.White,
    primaryContainer = Color(0xFF2D2750),
    onPrimaryContainer = AccentViolet,
    secondary        = AccentViolet,
    onSecondary      = Color.White,
    secondaryContainer = Color(0xFF292540),
    tertiary         = AccentPink,
    onTertiary       = Color.White,
    background       = MidnightBlue,
    onBackground     = TextPrimary,
    surface          = SurfaceDark,
    onSurface        = OnSurface,
    surfaceVariant   = SurfaceCard,
    onSurfaceVariant = TextSecondary,
    outline          = Divider,
    outlineVariant   = White10,
    error            = Color(0xFFFF5252),
    onError          = Color.White,
    scrim            = Black60,
)

@Composable
fun MelodiqTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography  = MelodiqTypography,
        content     = content
    )
}
