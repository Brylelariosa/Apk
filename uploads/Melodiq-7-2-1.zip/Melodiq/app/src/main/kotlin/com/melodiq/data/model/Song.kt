package com.melodiq.data.model

import android.net.Uri

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val duration: Long,          // milliseconds
    val uri: Uri,
    val artworkUri: Uri?,
    val size: Long,
    val dateAdded: Long,
    val albumId: Long,
    val isFavorite: Boolean = false
)
