package com.melodiq.ui

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*
import com.melodiq.ui.components.AnimatedGradientBackground
import com.melodiq.ui.components.MiniPlayer
import com.melodiq.ui.screen.*
import com.melodiq.ui.theme.*
import com.melodiq.ui.viewmodel.LibraryViewModel
import com.melodiq.ui.viewmodel.PlayerViewModel
import com.melodiq.util.hasAudioPermission

sealed class NavRoute(val route: String) {
    object Home       : NavRoute("home")
    object Library    : NavRoute("library")
    object Search     : NavRoute("search")
    object NowPlaying : NavRoute("now_playing")
}

data class BottomNavItem(val route: NavRoute, val label: String, val icon: ImageVector)

val bottomNavItems = listOf(
    BottomNavItem(NavRoute.Home,    "Home",    Icons.Rounded.Home),
    BottomNavItem(NavRoute.Library, "Library", Icons.Rounded.LibraryMusic),
    BottomNavItem(NavRoute.Search,  "Search",  Icons.Rounded.Search)
)

@Composable
fun AppRoot() {
    val context   = LocalContext.current
    val playerVm: PlayerViewModel   = hiltViewModel()
    val libraryVm: LibraryViewModel = hiltViewModel()
    val playerState by playerVm.state.collectAsStateWithLifecycle()

    var permissionGranted by remember { mutableStateOf(context.hasAudioPermission()) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        permissionGranted = granted
        if (granted) libraryVm.syncLibrary()
    }

    LaunchedEffect(Unit) {
        if (!permissionGranted) {
            val perm = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
                Manifest.permission.READ_MEDIA_AUDIO
            else
                Manifest.permission.READ_EXTERNAL_STORAGE
            permissionLauncher.launch(perm)
        } else {
            libraryVm.syncLibrary()
        }
    }

    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val showMiniPlayer = playerState.currentSong != null && currentRoute != NavRoute.NowPlaying.route
    val showBottomBar  = currentRoute != NavRoute.NowPlaying.route

    AnimatedGradientBackground {
        Scaffold(
            containerColor = Color.Transparent,
            bottomBar = {
                if (showBottomBar) {
                    Column {
                        AnimatedVisibility(
                            visible = showMiniPlayer,
                            enter   = slideInVertically { it } + fadeIn(),
                            exit    = slideOutVertically { it } + fadeOut()
                        ) {
                            MiniPlayer(
                                state             = playerState,
                                onTogglePlayPause = playerVm::togglePlayPause,
                                onSkipNext        = playerVm::seekToNext,
                                onClick           = {
                                    navController.navigate(NavRoute.NowPlaying.route) {
                                        launchSingleTop = true
                                    }
                                }
                            )
                        }
                        NavigationBar(
                            containerColor = SurfaceCard.copy(alpha = 0.85f),
                            tonalElevation = 0.dp
                        ) {
                            bottomNavItems.forEach { item ->
                                val selected = currentRoute == item.route.route
                                NavigationBarItem(
                                    selected = selected,
                                    onClick  = {
                                        navController.navigate(item.route.route) {
                                            popUpTo(navController.graph.findStartDestination().id) {
                                                saveState = true
                                            }
                                            launchSingleTop = true
                                            restoreState    = true
                                        }
                                    },
                                    icon = {
                                        Icon(
                                            item.icon,
                                            contentDescription = item.label,
                                            modifier = Modifier.size(if (selected) 26.dp else 22.dp)
                                        )
                                    },
                                    label  = { Text(item.label, style = MaterialTheme.typography.labelSmall) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor   = PrimaryPurple,
                                        selectedTextColor   = PrimaryPurple,
                                        unselectedIconColor = TextSecondary,
                                        unselectedTextColor = TextSecondary,
                                        indicatorColor      = PrimaryPurple.copy(alpha = 0.15f)
                                    )
                                )
                            }
                        }
                    }
                }
            }
        ) { padding ->
            NavHost(
                navController    = navController,
                startDestination = NavRoute.Home.route,
                modifier         = Modifier.padding(padding),
                enterTransition  = {
                    fadeIn(tween(220)) + scaleIn(tween(220), initialScale = 0.96f)
                },
                exitTransition   = { fadeOut(tween(180)) },
                popEnterTransition  = { fadeIn(tween(220)) },
                popExitTransition   = {
                    fadeOut(tween(180)) + scaleOut(tween(180), targetScale = 0.96f)
                }
            ) {
                composable(NavRoute.Home.route) {
                    HomeScreen(
                        onNavigateToNowPlaying = {
                            navController.navigate(NavRoute.NowPlaying.route) {
                                launchSingleTop = true
                            }
                        }
                    )
                }
                composable(NavRoute.Library.route) {
                    LibraryScreen(
                        onNavigateToNowPlaying = {
                            navController.navigate(NavRoute.NowPlaying.route) {
                                launchSingleTop = true
                            }
                        }
                    )
                }
                composable(NavRoute.Search.route) {
                    SearchScreen(
                        onNavigateToNowPlaying = {
                            navController.navigate(NavRoute.NowPlaying.route) {
                                launchSingleTop = true
                            }
                        }
                    )
                }
                composable(
                    route = NavRoute.NowPlaying.route,
                    enterTransition  = { slideInVertically { it } + fadeIn(tween(300)) },
                    exitTransition   = { fadeOut(tween(200)) },
                    popExitTransition = { slideOutVertically { it } + fadeOut(tween(300)) }
                ) {
                    NowPlayingScreen(
                        onBack = { navController.popBackStack() }
                    )
                }
            }
        }
    }
}
