package com.melodiq.data.model

data class PlayerState(
    val currentSong: Song? = null,
    val isPlaying: Boolean = false,
    val currentPosition: Long = 0L,
    val duration: Long = 0L,
    val shuffleEnabled: Boolean = false,
    val repeatMode: Int = 0,          // 0=off 1=one 2=all
    val queue: List<Song> = emptyList(),
    val currentIndex: Int = 0,
    val isLoading: Boolean = false
)
