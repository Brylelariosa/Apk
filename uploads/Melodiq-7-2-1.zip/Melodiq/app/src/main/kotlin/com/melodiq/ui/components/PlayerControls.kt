package com.melodiq.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.melodiq.data.model.PlayerState
import com.melodiq.ui.theme.*
import com.melodiq.util.TimeFormatter

@Composable
fun PlayerControls(
    state: PlayerState,
    onTogglePlayPause: () -> Unit,
    onSeekToNext: () -> Unit,
    onSeekToPrevious: () -> Unit,
    onSeekTo: (Long) -> Unit,
    onToggleShuffle: () -> Unit,
    onCycleRepeat: () -> Unit,
    accentColor: Color = PrimaryPurple,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        // Seek bar
        var isDragging by remember { mutableStateOf(false) }
        var dragPosition by remember { mutableFloatStateOf(0f) }

        val sliderValue = if (isDragging) dragPosition else {
            if (state.duration > 0) state.currentPosition.toFloat() / state.duration else 0f
        }

        Slider(
            value        = sliderValue.coerceIn(0f, 1f),
            onValueChange = { v ->
                isDragging   = true
                dragPosition = v
            },
            onValueChangeFinished = {
                onSeekTo((dragPosition * state.duration).toLong())
                isDragging = false
            },
            colors = SliderDefaults.colors(
                thumbColor              = accentColor,
                activeTrackColor        = accentColor,
                inactiveTrackColor      = White20
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp)
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(TimeFormatter.formatMs(state.currentPosition), color = TextMuted, style = androidx.compose.material3.MaterialTheme.typography.labelSmall)
            Text(TimeFormatter.formatMs(state.duration),        color = TextMuted, style = androidx.compose.material3.MaterialTheme.typography.labelSmall)
        }

        Spacer(Modifier.height(20.dp))

        // Control row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment     = Alignment.CenterVertically
        ) {
            // Shuffle
            val shuffleColor by animateColorAsState(
                if (state.shuffleEnabled) accentColor else TextSecondary, label = "shuffle_color"
            )
            IconButton(onClick = onToggleShuffle, modifier = Modifier.size(44.dp)) {
                Icon(Icons.Rounded.Shuffle, null, tint = shuffleColor, modifier = Modifier.size(22.dp))
            }

            // Previous
            IconButton(onClick = onSeekToPrevious, modifier = Modifier.size(52.dp)) {
                Icon(Icons.Rounded.SkipPrevious, null, tint = Color.White, modifier = Modifier.size(32.dp))
            }

            // Play/Pause
            var pressed by remember { mutableStateOf(false) }
            val playScale by animateFloatAsState(if (pressed) 0.92f else 1f, tween(100), label = "play_scale")
            IconButton(
                onClick  = { onTogglePlayPause(); pressed = false },
                modifier = Modifier
                    .size(68.dp)
                    .scale(playScale)
                    .background(accentColor, CircleShape)
            ) {
                Icon(
                    imageVector = if (state.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    contentDescription = null,
                    tint     = Color.White,
                    modifier = Modifier.size(36.dp)
                )
            }

            // Next
            IconButton(onClick = onSeekToNext, modifier = Modifier.size(52.dp)) {
                Icon(Icons.Rounded.SkipNext, null, tint = Color.White, modifier = Modifier.size(32.dp))
            }

            // Repeat
            val repeatColor by animateColorAsState(
                if (state.repeatMode != 0) accentColor else TextSecondary, label = "repeat_color"
            )
            IconButton(onClick = onCycleRepeat, modifier = Modifier.size(44.dp)) {
                Icon(
                    imageVector = if (state.repeatMode == 1) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                    contentDescription = null,
                    tint = repeatColor,
                    modifier = Modifier.size(22.dp)
                )
            }
        }
    }
}
