# Keep Media3 / ExoPlayer
-keep class androidx.media3.** { *; }
-keep class androidx.media3.session.** { *; }
-dontwarn androidx.media3.**

# Keep Retrofit models
-keepattributes Signature
-keepattributes *Annotation*
-keep class com.melodiq.data.network.** { *; }
-keep class retrofit2.** { *; }
-keep class okhttp3.** { *; }

# Keep Room
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class *
-keep @androidx.room.Dao interface *
-dontwarn androidx.room.**

# Keep Gson
-keep class com.google.gson.** { *; }
-keepclassmembers class * {
    @com.google.gson.annotations.SerializedName <fields>;
}

# ── Hilt ──────────────────────────────────────────────────────────────────────
-keep class dagger.hilt.** { *; }
-keep @dagger.hilt.android.HiltAndroidApp class *
-keep @dagger.hilt.android.AndroidEntryPoint class *
-dontwarn dagger.hilt.**

# Keep ALL Hilt-generated classes (Hilt_MainActivity, Hilt_MelodiqApp, etc.)
-keep class **Hilt_* { *; }
-keep class **_HiltModules* { *; }
-keep class **_HiltComponents* { *; }
-keep class **_GeneratedInjector { *; }
-keep class **_ComponentTreeDeps { *; }

-keep @dagger.hilt.InstallIn class * { *; }
-keep @dagger.hilt.EntryPoint class * { *; }
-keepclasseswithmembers class * {
    @javax.inject.Inject <init>(...);
}

# ── ViewModel ─────────────────────────────────────────────────────────────────
-keep class * extends androidx.lifecycle.ViewModel {
    <init>(...);
}
-keepclassmembers class * extends androidx.lifecycle.ViewModel {
    <init>(...);
}

# ── Compose + Lifecycle bridge (fixes: LocalLifecycleOwner not present) ───────
# AndroidComposeView uses ViewTreeLifecycleOwner.get(view) at onAttachedToWindow.
# R8 renames/removes these classes causing the composition to crash immediately.

# Keep the ViewTree owner lookup mechanism
-keep class androidx.lifecycle.ViewTreeLifecycleOwner { *; }
-keep class androidx.savedstate.ViewTreeSavedStateRegistryOwner { *; }
-keep class androidx.lifecycle.ViewTreeViewModelStoreOwner { *; }

# Keep Compose platform internals that wire up CompositionLocals
-keep class androidx.compose.ui.platform.** { *; }
-keep class androidx.compose.ui.platform.AndroidComposeView { *; }
-keep class androidx.compose.ui.platform.AbstractComposeView { *; }

# Keep lifecycle-compose bridge (provides LocalLifecycleOwner to compositions)
-keep class androidx.lifecycle.compose.** { *; }

# Keep activity-compose bridge (ComponentActivity.setContent provides owners)
-keep class androidx.activity.compose.** { *; }

# Keep SavedState (required by ViewTreeSavedStateRegistryOwner)
-keep class androidx.savedstate.** { *; }
-dontwarn androidx.savedstate.**

# ── Data models ───────────────────────────────────────────────────────────────
-keep class com.melodiq.data.model.** { *; }
-keep class com.melodiq.data.db.entity.** { *; }

# ── Coil ──────────────────────────────────────────────────────────────────────
-keep class coil.** { *; }
-dontwarn coil.**

# ── Palette ───────────────────────────────────────────────────────────────────
-keep class androidx.palette.** { *; }

# ── Kotlin Coroutines ─────────────────────────────────────────────────────────
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}
-keep class kotlinx.coroutines.android.** { *; }

# ── General ───────────────────────────────────────────────────────────────────
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
