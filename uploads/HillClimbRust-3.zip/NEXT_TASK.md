# NEXT_TASK

## Task 2.1 — build the smoke-test APK and report back (you)
1. Upload HillClimbRust-3.zip the same way as before.
   - Run #1956 compiled the Rust library, then stopped because the ZIP had no `gradlew`. HillClimbRust-3.zip adds it, so this should be the first run to reach Gradle packaging.
2. Send me the build log again, whatever the result. Look for `test result:` lines in the Rust unit-test step (they could not run last time) and for the Gradle outcome.
3. If it builds, install the APK from the artifact.

Acceptance (checked on the phone before anything is marked done)
1. Installs next to the original; the original is untouched.
2. The launcher shows "Hill Climb Racing Rust" with the wheel-on-hill icon.
3. Launches full-screen landscape; the Stats page shows live numbers; a tap cycles Stats, GPU/EGL info, Off.
4. Send screenshots of the Stats page and the GPU/EGL info page (this records the GPU model and GL limits).
5. The Rust unit-test step reports no failures.

## Then (me): Task 2.2 — asset provider, policy A
- `hcr-assets` crate: provider trait; reader for the installed original's APKs (small JNI call to PackageManager for the paths, `<queries>` entry in the manifest); verification against docs/asset_manifest.csv hashes.
- First proof: load one atlas page and draw a sprite. No game logic yet.
- If you confirm written permission from the rights holder (policy C), a second provider reads bundled assets instead; the rest of the code does not change.

## Asset policy note
C needs written permission from the rights holder. PocketGamer.biz lists business@fingersoft.com as Fingersoft's business contact, and Wikipedia states the Hill Climb Racing IP is owned by Hill Climb Racing Oy, so ask that the letter covers the IP owner. Until you have it in hand, policy A applies.

## Inputs for Stage 4 (when ready)
- Which stages and vehicles are unlocked in your original install?
- Screen recordings of the original (landscape, 60 fps if possible): stage start, about 30 s of driving, a crash, the results screen, the garage.
- Does Wireless debugging work on this phone (Developer options)? That decides how the original is measured.

## Do not
Start gameplay code, bundle Fingersoft assets, or mark any feature done before it is implemented and tested on the phone.
