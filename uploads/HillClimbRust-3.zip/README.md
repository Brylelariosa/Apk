# Hill Climb Racing Rust

Independent Rust reimplementation of Hill Climb Racing, built to compare performance with the original on the same phone. It installs next to the original (`com.fingersoft.hillclimb`) as **Hill Climb Racing Rust** (`dev.hcrrust.hillclimb`).

**Status: Task 2.1 smoke test. There is no game yet.** The Rust code compiles for arm64-v8a (CI run #1956) but has never run on a phone; PROJECT_STATE.md lists exactly what is and is not verified.

## What the smoke test does
- NativeActivity app (no Java or Kotlin), OpenGL ES 2.0 through EGL, sensor-landscape, arm64-v8a, Android 11+ (minSdk 30).
- Tap to cycle the overlay: **Stats** (FPS avg / min / 1% low, frame-time percentiles, jitter, CPU work per frame, process CPU, RSS, startup time, frame-interval graph), **GPU/EGL info** (vendor, renderer, limits, extension list), **Off**.

## Layout
| Path | Purpose |
|---|---|
| `Cargo.toml`, `crates/` | Cargo workspace (below) |
| `settings.gradle`, `build.gradle`, `app/` | Gradle Android app (AGP 8.2.2): packages the prebuilt `libhcr_app.so`, signs, names the app |
| `gradlew`, `gradle/wrapper/gradle-wrapper.properties` | Gradle wrapper script and settings (Gradle 8.6). The CI workflow downloads `gradle-wrapper.jar` itself |
| `app/src/main/` | manifest and resources (name, icon, theme); no Java sources |
| `signing/` | public DEV keystore used for the release build type |
| `docs/` | APK analysis and asset manifest (metadata only) |

| Crate | Purpose |
|---|---|
| `hcr-bench` | frame statistics and /proc metrics (pure Rust, unit-tested) |
| `hcr-gfx` | draw list, built-in 5x7 font, GLES2 bindings and uploader (GL part Android-only) |
| `hcr-overlay` | overlay pages (pure Rust, unit-tested) |
| `hcr-platform` | logcat logging, panic hook, EGL (Android-only parts) |
| `hcr-app` | NativeActivity entry point (`libhcr_app.so`); empty on non-Android targets |

## Build
Upload the ZIP to the repo's `uploads/` folder as usual. The workflow unzips it, finds `settings.gradle`, and because a `Cargo.toml` exists it: installs Rust and the Android target, runs `cargo test --lib` (non-blocking), builds the library with `cargo ndk -t arm64-v8a -o app/src/main/jniLibs build --release`, downloads `gradle-wrapper.jar`, and runs Gradle. `gradle.properties` carries `rustAbis=arm64-v8a`, which the workflow reads.

All crates compile on the build machine too (`hcr-app` is empty there), so `cargo test --lib` covers `hcr-bench`, `hcr-gfx` and `hcr-overlay`.

## Signing
The `release` build type is signed with the public DEV key in `signing/` (fine for sideloading; anyone can sign with it). The `debug` build type uses the usual debug key. Switching between signing keys requires uninstalling the previous build first.

## Notes
- No Fingersoft assets are in this repository or APK.
- Frame time is measured between consecutive buffer swaps (what the display sees). "CPU work per frame" is the time before the swap call.
- 1% low = 1 / (mean interval of the slowest 1% of frames). Percentiles use nearest-rank.
