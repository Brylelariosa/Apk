//! Hill Climb Racing Rust: Task 2.1 smoke-test app.
//!
//! Proves the toolchain, the side-by-side install and the measurement plumbing:
//! a GLES2 context on the phone, frame-time capture, process metrics and a
//! toggleable overlay. No game logic and no assets yet.
//!
//! This crate contains no `unsafe`: EGL lives in `hcr-platform`, GL in `hcr-gfx`.
//!
//! The whole crate is Android-only; on other targets it compiles to nothing so that
//! `cargo test` on the build machine can cover the pure crates.
#![cfg(target_os = "android")]

use std::any::Any;
use std::ffi::c_void;
use std::time::{Duration, Instant};

use android_activity::input::{InputEvent, MotionAction};
use android_activity::{AndroidApp, InputStatus, MainEvent, PollEvent};
use hcr_bench::{procfs, CpuMeter, FrameRecorder};
use hcr_gfx::renderer::{DebugRenderer, GlInfo};
use hcr_gfx::DrawList;
use hcr_overlay::{DeviceInfo, LiveStats, Overlay};
use hcr_platform::egl::{EglCore, EglInfo, SwapOutcome};

/// Frames kept for statistics and the graph (about 10 s at 60 fps).
const RING_FRAMES: usize = 600;
/// How often the on-screen numbers are recomputed.
const STATS_PERIOD: Duration = Duration::from_millis(500);
/// How often the slower procfs readings are taken.
const SLOW_PERIOD: Duration = Duration::from_secs(1);
const CLEAR_COLOR: [f32; 4] = [0.04, 0.05, 0.08, 1.0];

/// GL objects that exist only while a context is alive.
struct Gfx {
    renderer: DebugRenderer,
    device: DeviceInfo,
}

struct State {
    app: AndroidApp,
    egl: Option<EglCore>,
    /// Keeps the ANativeWindow reference alive for as long as an EGL surface uses it.
    window_guard: Option<Box<dyn Any>>,
    gfx: Option<Gfx>,
    draw: DrawList,
    rec: FrameRecorder,
    cpu: CpuMeter,
    overlay: Overlay,
    live: LiveStats,
    paused: bool,
    quit: bool,
    last_swap: Option<Instant>,
    last_stats: Instant,
    last_slow: Instant,
    startup_ms: Option<f64>,
}

impl State {
    fn new(app: AndroidApp) -> Self {
        let now = Instant::now();
        Self {
            app,
            egl: None,
            window_guard: None,
            gfx: None,
            draw: DrawList::with_capacity_quads(8192),
            rec: FrameRecorder::new(RING_FRAMES),
            cpu: CpuMeter::new(),
            overlay: Overlay::new(),
            live: LiveStats::default(),
            paused: false,
            quit: false,
            last_swap: None,
            last_stats: now,
            last_slow: now,
            startup_ms: None,
        }
    }

    fn should_render(&self) -> bool {
        !self.paused
            && !self.quit
            && self.gfx.is_some()
            && self.egl.as_ref().map_or(false, |egl| egl.has_surface())
    }

    fn on_main_event(&mut self, event: &MainEvent) {
        match event {
            MainEvent::InitWindow { .. } => self.on_init_window(),
            MainEvent::TerminateWindow { .. } => self.on_terminate_window(),
            MainEvent::Pause { .. } => {
                self.paused = true;
                self.last_swap = None;
            }
            MainEvent::Resume { .. } => {
                self.paused = false;
                self.last_swap = None;
            }
            MainEvent::Destroy { .. } => self.quit = true,
            _ => {}
        }
    }

    fn on_init_window(&mut self) {
        let Some(window) = self.app.native_window() else {
            return;
        };
        let raw = window.ptr().as_ptr() as *mut c_void;
        if self.egl.is_none() {
            match EglCore::new() {
                Ok(egl) => self.egl = Some(egl),
                Err(e) => {
                    log::error!("EGL init failed: {e}");
                    return;
                }
            }
        }
        if let Some(egl) = self.egl.as_mut() {
            if let Err(e) = egl.attach_window(raw) {
                log::error!("attaching window failed: {e}");
                return;
            }
        }
        // Replaces (and releases) any older window reference only after the old surface is gone.
        self.window_guard = Some(Box::new(window));
        if self.gfx.is_none() {
            self.init_gfx();
        }
        self.last_swap = None;
    }

    fn on_terminate_window(&mut self) {
        if let Some(egl) = self.egl.as_mut() {
            egl.detach_window();
        }
        self.window_guard = None;
        self.last_swap = None;
    }

    fn init_gfx(&mut self) {
        let Some(egl) = self.egl.as_ref() else {
            return;
        };
        let gl_info = GlInfo::query();
        let renderer = match DebugRenderer::new() {
            Ok(renderer) => renderer,
            Err(e) => {
                log::error!("renderer init failed: {e}");
                return;
            }
        };
        log::info!(
            "GL_RENDERER {} | GL_VERSION {} | EGL {}",
            gl_info.renderer,
            gl_info.version,
            egl.info().version
        );
        self.gfx = Some(Gfx {
            renderer,
            device: build_device_info(egl.info(), &gl_info),
        });
    }

    /// The GL context is gone: its objects died with it, so drop them without GL calls
    /// and build everything again if a window is still available.
    fn rebuild_gl(&mut self) {
        self.gfx = None;
        self.egl = None; // EglCore::drop destroys the surface, then the context
        self.window_guard = None;
        self.last_swap = None;
        self.on_init_window();
    }

    /// A tap anywhere cycles the overlay page.
    fn pump_input(&mut self) {
        let mut tapped = false;
        match self.app.input_events_iter() {
            Ok(mut iter) => loop {
                let more = iter.next(|event| match event {
                    InputEvent::MotionEvent(motion) => {
                        if matches!(motion.action(), MotionAction::Down) {
                            tapped = true;
                        }
                        InputStatus::Handled
                    }
                    _ => InputStatus::Unhandled,
                });
                if !more {
                    break;
                }
            },
            Err(_) => log::warn!("input event iterator unavailable"),
        }
        if tapped {
            self.overlay.next_page();
        }
    }

    fn frame(&mut self) {
        let started = Instant::now();
        let (width, height) = match self.egl.as_ref() {
            Some(egl) => egl.size(),
            None => return,
        };
        let Some(gfx) = self.gfx.as_mut() else {
            return;
        };

        gfx.renderer.begin_frame(width, height, CLEAR_COLOR);
        self.draw.clear();
        self.overlay
            .draw(&mut self.draw, &self.rec, &gfx.device, width as f32, height as f32);
        gfx.renderer.draw(&self.draw, width, height);
        let work_us = micros_u32(started.elapsed());

        let outcome = match self.egl.as_mut() {
            Some(egl) => egl.swap(),
            None => return,
        };
        let now = Instant::now();
        match outcome {
            SwapOutcome::Presented => {
                if let Some(prev) = self.last_swap {
                    self.rec.push(micros_u32(now.duration_since(prev)), work_us);
                }
                self.last_swap = Some(now);
                if self.startup_ms.is_none() {
                    self.startup_ms = procfs::process_age_ms();
                    log::info!("first frame presented; process age {:?} ms", self.startup_ms);
                }
                self.refresh_stats(now);
            }
            SwapOutcome::SurfaceLost => {
                log::warn!("surface lost; waiting for a new window");
                self.on_terminate_window();
            }
            SwapOutcome::ContextLost => {
                log::warn!("EGL context lost; rebuilding GL state");
                self.rebuild_gl();
            }
            SwapOutcome::Failed(code) => log::warn!("eglSwapBuffers failed: 0x{code:04x}"),
        }
    }

    fn refresh_stats(&mut self, now: Instant) {
        if now.duration_since(self.last_stats) < STATS_PERIOD {
            return;
        }
        self.last_stats = now;
        if let Some(egl) = self.egl.as_mut() {
            egl.refresh_size();
        }
        self.live.frame = self.rec.stats();
        self.live.total_frames = self.rec.total_frames();
        self.live.startup_ms = self.startup_ms;
        if now.duration_since(self.last_slow) >= SLOW_PERIOD {
            self.last_slow = now;
            self.live.cpu_pct = self.cpu.sample();
            if let Some(mem) = procfs::read_mem() {
                self.live.rss_kb = Some(mem.rss_kb);
                self.live.peak_rss_kb = Some(mem.peak_rss_kb);
            }
        }
        let (width, height) = self.egl.as_ref().map_or((0, 0), |egl| egl.size());
        self.overlay.update_text(&self.live, width, height);
    }
}

fn micros_u32(d: Duration) -> u32 {
    d.as_micros().min(u32::MAX as u128) as u32
}

fn build_device_info(egl: &EglInfo, gl: &GlInfo) -> DeviceInfo {
    DeviceInfo {
        lines: vec![
            format!("GL_VENDOR    {}", gl.vendor),
            format!("GL_RENDERER  {}", gl.renderer),
            format!("GL_VERSION   {}", gl.version),
            format!("GLSL         {}", gl.glsl),
            format!("EGL vendor   {}", egl.vendor),
            format!(
                "EGL version  {}   client APIs: {}",
                egl.version, egl.client_apis
            ),
            format!(
                "EGL config   R{} G{} B{} A{}  depth {}  stencil {}  samples {}",
                egl.red, egl.green, egl.blue, egl.alpha, egl.depth, egl.stencil, egl.samples
            ),
            format!(
                "Limits       texture {}  vertex attribs {}  varyings {}  vertex uniforms {}  fragment uniforms {}  texture units {}",
                gl.max_texture_size,
                gl.max_vertex_attribs,
                gl.max_varying_vectors,
                gl.max_vertex_uniform_vectors,
                gl.max_fragment_uniform_vectors,
                gl.max_texture_units
            ),
        ],
        extensions: gl.extensions.clone(),
    }
}

#[no_mangle]
fn android_main(app: AndroidApp) {
    hcr_platform::init_logging();
    hcr_platform::install_panic_hook();
    log::info!("HCR Rust smoke test {} starting", env!("CARGO_PKG_VERSION"));

    let mut state = State::new(app.clone());
    while !state.quit {
        // Render continuously while a surface exists (the swap blocks on vsync);
        // otherwise sleep until the system sends an event.
        let timeout = if state.should_render() {
            Some(Duration::ZERO)
        } else {
            None
        };
        app.poll_events(timeout, |event| {
            if let PollEvent::Main(main_event) = event {
                state.on_main_event(&main_event);
            }
        });
        if state.quit {
            break;
        }
        state.pump_input();
        if state.should_render() {
            state.frame();
        }
    }
    log::info!("exiting");
}
