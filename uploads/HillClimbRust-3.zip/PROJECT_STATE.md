# PROJECT_STATE — Hill Climb Racing Rust

Last updated: 2026-11-12
Current stage: **2 — toolchain and smoke test.** The Rust code now compiles for arm64-v8a in CI (run #1956). It has not run on a phone, its unit tests have not run, and Gradle packaging has never been reached. No game logic exists.

## Goal
Independent Rust reimplementation of Hill Climb Racing, installed next to the untouched original, to measure whether Rust performs better on the same phone with identical visuals and gameplay. No speed claim without measured results.

## Stage tracker
| # | Stage | Status |
|---|-------|--------|
| 1 | Analyze uploaded APK | Done (static analysis only, see docs/ANALYSIS.md) |
| 2 | Understand architecture and functionality | Partial: static structure mapped; runtime behaviour not yet observed |
| 3 | Extract and catalog resources | Done as metadata only (docs/asset_manifest.csv); no asset content copied into the project |
| 4 | Document original graphics and gameplay | Not started (needs on-device observation of the original) |
| 5 | Rust architecture | In progress: 5-crate workspace skeleton, compiled for Android |
| 6 | Reimplement game systems | Not started |
| 7 | Recreate visuals | Not started |
| 8 | Performance optimization | Not started |
| 9 | Build separate APK | In progress: Rust library builds in CI; Gradle packaging not yet reached |
| 10 | Test and compare | Not started |

## CI runs so far
| Run | ZIP | Result |
|---|---|---|
| #1953 | HillClimbRust-1 | Failed at "Find project directory": a pure Cargo project has no `settings.gradle`. No Rust compiled |
| #1956 | HillClimbRust-2 | Rust **built** (cargo-ndk 4.1.2, rustc 1.99.1, NDK r30, 25.7 s; `libhcr_app.so` 673,832 bytes). Host tests could not compile Android-only crates (non-blocking). Failed at "Make gradlew executable": no `gradlew` in the ZIP |
| next | HillClimbRust-3 | Adds `gradlew` + wrapper properties, makes `hcr-app` compile on the host. First run expected to reach Gradle/AGP packaging |

## Build pipeline (from the logs; the repo's fixed workflow, Brylelariosa/Apk)
1. Takes the newest ZIP in `uploads/`, unzips to `extracted/`, finds `settings.gradle[.kts]` within 4 levels (project dir). A workflow file inside the ZIP is never used.
2. If a `Cargo.toml` exists within 2 levels: reads `rustAbis=` from `gradle.properties` (default arm64-v8a), installs stable Rust and the Android targets, selects the NDK from `ANDROID_NDK_LATEST_HOME` (r30), runs `cargo test --lib` (non-blocking), then `cargo ndk -t <abi> -o app/src/main/jniLibs build --release` (default API level 21).
3. Downloads `gradle-wrapper.jar` (Gradle 8.6) and runs `chmod +x gradlew`: **the ZIP must contain `gradlew` and `gradle/wrapper/gradle-wrapper.properties`.**
4. Then Gradle (command not yet seen). On failure it uploads `app/build/reports`, `build/reports`, `rust-build.log`, `rust-test.log`.
- Toolchain: JDK 17, Gradle 8.6, NDK r25 for AGP (default NDK of AGP 8.2), runner Ubuntu 26.04.
- Consequence: the Rust build is owned by the workflow. The Gradle project only packages `app/src/main/jniLibs`.

## Task 2.1 smoke test: what exists and what is verified
| Item | State |
|---|---|
| Cargo workspace: `hcr-bench`, `hcr-gfx`, `hcr-overlay`, `hcr-platform`, `hcr-app` | **Compiles for arm64-v8a** (run #1956; no warnings printed) |
| Host unit tests (frame statistics, procfs parsers, font atlas, draw list, text wrap, overlay) | Written; **never run**. Run #1956 failed to compile `ndk-sys` on the host because `hcr-app` pulled Android-only dependencies; fixed in HillClimbRust-3 by cfg-gating, unverified |
| Gradle packaging (AGP 8.2.2), manifest/resources, release signing with the DEV key | Written; never run |
| Overlay, EGL/GLES2 context, input, lifecycle on the phone | Not run |
| Local static checks (XML well-formed, TOML parse, bracket balance, gradlew launcher test with a fake java) | Passed. They cannot catch Gradle or runtime errors |

## Decisions
| Topic | Status |
|---|---|
| Asset policy | User replied "c and how or a". C (bundle) needs written permission from the rights holder, which is not confirmed. **Working default: A** (read assets at runtime from the installed original; nothing copied into repo or APK). Asset code is not part of Task 2.1 and will sit behind one provider interface, so A to C is a switch |
| Renderer | OpenGL ES 2.0 through EGL with raw bindings (same API as the original; its shaders usable as-is). Not confirmed by the user |
| Package ID, name, icon | `dev.hcrrust.hillclimb`, "Hill Climb Racing Rust", independently drawn vector icon. Not confirmed by the user |
| Packaging | Gradle + AGP (required by the pipeline); Rust built by the workflow's cargo-ndk |
| Physics | Proposed: Box2D port, calibrated against the original by observation. Not started |

## Key findings from the APK analysis (details in docs/ANALYSIS.md)
1. Original: Cocos2d-x 2.x C++ (`libgame.so`, arm64) on a Java GLSurfaceView shell; GLES 2.0; OpenSL ES audio; Box2D-style physics (R.U.B.E. JSON vehicle models).
2. 2,399 asset files in standard formats; one unidentified 26 KB high-entropy file (`garage/aaa.dat`), not decoded.
3. Only 7 vehicle models are data-defined. Classic terrain, most vehicle tuning, game rules, camera and UI layout are in stripped native code.
4. Scale: 42 stage folders, 30+ vehicle types, 150 audio files, 68 shaders, 18 languages. A benchmarkable vertical slice comes first.

## Risks
- Gradle/AGP packaging has never run; the first run may surface build-script or manifest errors.
- Exact physics and terrain parity cannot be guaranteed (stripped native code); plan is black-box calibration, not decompilation.
- Out of scope (SDK/server-bound): ads, IAP, Play Games/cloud saves, Firebase, LiveOps, promos, Helpshift, consent.
- No PC: measuring the original needs an on-device shell (wireless debugging) or screen-recording analysis. Not yet verified on the phone.
- The original declares `com.android.graphics.driver.prefer_angle=true`; whether its GL path differs from this app's plain EGL on the phone must be checked.

## Environment
- Device: Infinix Hot 11 2022, Android 11, 4 GB RAM, 1080x2400, no root/Shizuku (GPU model not yet recorded; the smoke test displays it).
- Build: the user's GitHub Actions ZIP-upload workflow (above). Target arm64-v8a, Android 11+ (minSdk 30).

## Rules carried from the brief
Preserve the original exactly (no redesign, no placeholders). Reuse only authorized assets. Do not wrap the original code. Do not lower quality to gain FPS. Separate package and data directory; original stays untouched. Never mark a feature complete until it is implemented and tested.
