# FEATURES — Hill Climb Racing Rust

Status legend: Not started → Written (not built) → Built, not yet run on phone → Tested on phone.
Nothing is beyond "Built, not yet run on phone". "Built" means it compiled into `libhcr_app.so` for arm64-v8a in CI run #1956. "Evidence" = what the original's files show; it is not a claim about the Rust app.

## Gameplay core
| Feature | Evidence in original | Rust status |
|---|---|---|
| Touch pedals (gas/brake) | `pedal-gas-*`, `pedal-brake-*`, `skins/Pedals` | Not started |
| Vehicle physics (Box2D) | 7 R.U.B.E. models in `vehicles/`; others in native code | Not started |
| Classic terrain generator | stage manifests use a native `algorithm` block | Not started |
| JSON-block terrain and objects | `stages/jungle/*_blocks.json`, `*_objects.json` | Not started |
| Per-stage physics params (gravity, friction, traction) | stage manifest JSON | Not started |
| Fuel, coins, diamonds, distance | `fuel-*`, `coin*`, `diamond*`, `distance-icon` | Not started |
| Nitro / boost power-ups | `nitro_*`, `powerups/boost-icon-*` | Not started |
| Crash, game over, results | `PauseScreen`, `finishline-*`, `record-sign` | Not started |
| Camera and zoom | native only (unknown) | Not started |
| Race start lights | `traffic/*` | Not started |
| Stage hazards and props | stage assets, particle plists | Not started |
| Vehicle-specific mechanics (UFO, hovercraft, sleigh, snowmobile) | `ufo_model.json`, `hovercraftskirt.*` shaders | Not started |

## Content
| Feature | Evidence in original | Rust status |
|---|---|---|
| Stages (42 asset folders; list in docs/ANALYSIS.md §4) | `assets/stages/*` | Not started |
| Vehicles (30+ types by icon names) | `caricons/`, `garage/`, `atlas/vehicles-*` | Not started |
| Upgrades | `MainMenuUpgrade*`, `upgrade-*` | Not started |
| Drivers, passengers, skins | `driver-*`, `passenger*`, `skins/` | Not started |
| Events (pinball, party, seasons) | `events/*`, `specialevent/`, `stages/party`, `stages/seasons` | Not started |
| Missions, achievements, daily challenge | `missions_*`, `achievement_*`, `daily_bg` (server/SDK-linked parts out of scope) | Not started |
| Local multiplayer (mode unconfirmed) | `multiplayer-1p..4p` | Not started |

## Rendering
| Feature | Evidence in original | Rust status |
|---|---|---|
| OpenGL ES 2.0 context via EGL | manifest requires GLES 2.0 | Built, not yet run on phone: `hcr-platform::egl` |
| Debug 2D renderer (textured quads, built-in 5x7 font) | n/a (diagnostic only) | Built, not yet run on phone: `hcr-gfx` |
| Sprite batching and atlases | 28 atlas plists + pages | Not started |
| Terrain, sky, fog, liquid shaders | 35 `.fsh` / 33 `.vsh` (GLSL ES 1.00) | Not started |
| Post-process (glow, pixelate, edge-glow) | `postprocess_*` shaders | Not started |
| Particle systems | plists | Not started |
| Bitmap-font text | `fonts/gamefont(-hd)` | Not started |
| System-font text | Java `Cocos2dxBitmap` (font unknown) | Not started |
| Parallax and backgrounds | `*-bg*`, `stage_data/*_background.json` | Not started |
| Design-resolution scaling at 2400x1080, max aspect 2.4 | manifest + native | Not started (max aspect 2.4 and non-resizable are in the manifest) |

## Audio
| Feature | Evidence in original | Rust status |
|---|---|---|
| Engine loops | 33 OGG | Not started |
| Music | `bgmusic*`, `8bit-*` | Not started |
| Sound effects | remaining OGG | Not started |
| Music/sound toggles | `button-music-*`, `button-sound-*` | Not started |

## UI and platform
| Feature | Evidence in original | Rust status |
|---|---|---|
| NativeActivity shell, sensor-landscape, lifecycle (pause/resume, window loss, context loss) | manifest | Built, not yet run on phone: `hcr-app` |
| Tap input | n/a | Built, not yet run on phone: taps cycle overlay pages only |
| Main menu, stage select, garage, shop, settings, pause | UI assets | Not started |
| Language selection (18 languages) | `lang-*`, 73 `.po` | Not started |
| Gamepad support | JNI controller events, `Moga_*` | Not started |
| Save data | native (format unknown) | Not started |

## Rust-only: benchmark and packaging
| Feature | Rust status |
|---|---|
| Frame-time capture: average FPS, minimum FPS, 1% low, percentiles, jitter | Built, not yet run on phone: `hcr-bench::frame` (unit tests written, not run) |
| CPU work per frame (time before swap) | Built, not yet run on phone |
| Process CPU and RAM (RSS, peak) from /proc | Built, not yet run on phone: `hcr-bench::procfs` |
| GPU usage, battery consumption | Not started |
| Startup time (process start to first frame, 10 ms resolution) | Built, not yet run on phone |
| Toggleable overlay (stats + graph / GPU-EGL info / off) | Built, not yet run on phone: `hcr-overlay` |
| Overlay overhead measured to be negligible | Not started (needs the phone) |
| Export of results (CSV) | Not started |
| Package ID, name "Hill Climb Racing Rust", independently drawn icon | Written (manifest, resources); Gradle packaging not reached yet |
| Signed release APK, arm64-v8a, Android 11+ (minSdk 30), built by the user's Gradle ZIP-upload workflow | Rust library built by the workflow (run #1956); Gradle packaging and signing written, never run |

## Out of scope (SDK/server-bound; not reproduced)
Ads and ad breaks, in-app purchases, Play Games sign-in / achievements / cloud saves, Firebase (analytics, crash reporting, messaging, remote config), LiveOps events, cross-promotion, Helpshift support, consent flow, push notifications.
