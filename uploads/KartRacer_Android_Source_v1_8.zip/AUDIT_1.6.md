# Kart Racer 1.6 graphics audit

> Superseded in part by `AUDIT_1.7.md`: the 1.6 colour grade (saturation 1.22, contrast 0.40) was pulled back toward natural in 1.7, and the foliage turned out to be drawn unlit.

## How the graphics were checked

Earlier audits could only read code. This time a CPU preview renderer was written (`tools/preview/Soft.java`): it rasterizes the **real** track, prop and kart meshes with the **real** procedural textures and a Java port of the lit, sky and water shaders (sun, ambient, fog, soft shadows, grade). The start view of all four tracks and the six karts were rendered before and after every change and looked at, and the generated textures were dumped to PNG.

Limits: it is a CPU approximation (no anti-aliasing, a simple 1024 px shadow map, no GPU texture filtering quirks). It cannot show your phone's resolution, frame rate or the automatic quality state. The GLSL edits were **not** compiled on a GPU, and nothing was run on a device. `graphics_before_after.png` shows the preview of 1.5 (left) and 1.6 (right).

## Correction to the 1.5 audit

Item 9 of `AUDIT_1.5.md` said sunlit sand computes to about 1.27 and clipped to flat white. That was wrong: the numbers used the unscaled light colours, but the game scales sun and ambient before use (`SceneGfx`), so bright surfaces mostly stay below 1.0. The soft shoulder added in 1.5 was not a real fix and slightly darkened bright areas. It is removed in 1.6.

## What the preview showed, and what was changed

1. **Volcano road looked like a tiled floor.** Square slabs with a rectangular grid of orange lines. Now irregular cracked basalt slabs (cellular noise) with glowing cracks. The glow is stored in the texture's alpha channel and lit by the shader (alpha below 1 means emissive, `1.0 - alpha`), so it stays bright in shadow. Textures are uploaded as plain RGBA, so alpha is preserved.
2. **Flat ground.** The ground detail texture only had soft blobs between 0.76 and 1.0, so large areas of sand and grass looked like plain colour. New texture: broad mottling, patches 0.3 to 0.5 m across (the scale seen from the camera), grain and flecks, with the same average brightness.
3. **Terrain colours.** Soft vertex-scale mottling on every theme, stronger sand and grass variation, cooler basalt on the volcano so it separates from the red sky and fog. Baked occlusion: a terrain vertex lower than its surroundings is darker, a ridge a little lighter, so hills and hollows read better.
4. **Flat lighting.** Ambient fill was strong against the sun. Scene scales changed from sun 0.85 / sky ambient 0.52 / ground ambient 0.45 to 1.00 / 0.44 / 0.38. Grade: saturation 1.14 to 1.22, contrast curve 0.28 to 0.40, light split tone. Four variants were compared side by side on the beach and jungle tracks and this one was chosen. The difference is modest: deeper shadows and richer colour, not a new look.
5. **Start gate.** The white squares were mid grey (they face away from the sun). They now carry some emissive light.
6. **Automatic quality was too eager (affects what you see on a phone).** It lowered quality when the average frame took over 21 ms (about 47 fps), by 10 % resolution every 3.5 s, then switched off the soft shadow filter, then the shadows, then dropped to 60 % resolution, and never recovered. A phone running at 45 to 55 fps could end up permanently blurry without shadows. Now: reacts above 26 ms (about 38 fps), waits 5 s between steps, goes to 88 % resolution, then drops the soft shadow filter, then 78 % resolution, and switches shadows off only as a last resort. Nothing goes below 78 %.
7. **Smaller:** grain and pebbles on the shortcut dirt road, dune grass on the beach (no collision, own random stream, so nothing else moves).

## Honest assessment

In the preview the base look was already a decent cartoon style (palms, sky, shadows, detailed karts). The changes above are visible but they improve it, they do not turn it into something else. What your phone shows may differ a lot from a CPU preview: resolution, anti-aliasing, frame rate, and the automatic quality state (item 6) all change the picture. A screenshot of the part you dislike would let me aim at the real problem.

## Not done, and why

* **Bloom / other post-processing.** Needs an offscreen render target and a different frame structure. A mistake there means a black screen or a big frame-rate drop on some phones, and it cannot be tested here.
* **Resolution cap at start, refresh-rate hint, anti-aliasing level without restart.** Need measurements on a real phone.
* **New models or animation.** The karts and props looked fine in the preview.

## Verification status

| Part | Status |
|---|---|
| `util`, `world`, `sim`, `net`, `gfx` (textures, terrain, meshes) | compiled and run headless |
| Textures and scenes | rendered with the preview and looked at |
| Android files and GLSL | **not compiled / not run**: a before / after compiler comparison without the SDK shows no syntax errors and no new errors except unresolved Android classes; the shader edits are plain GLSL in the existing style but only a real build and run can confirm them |
| Behaviour on a device | **not run** |

If the GitHub build turns red, send the red error text. If the picture looks wrong on the phone (black, wrong colours), tell me which track and send a screenshot.

## Files changed since 1.5

- `AUDIT_1.5.md`
- `README.md`
- `app/build.gradle`
- `app/src/main/java/com/kartracer/gfx/ObjModels.java`
- `app/src/main/java/com/kartracer/gfx/TexGen.java`
- `app/src/main/java/com/kartracer/gfx/WorldMesher.java`
- `app/src/main/java/com/kartracer/gl/GameRenderer.java`
- `app/src/main/java/com/kartracer/gl/SceneGfx.java`
- `app/src/main/java/com/kartracer/gl/Shaders.java`
- `app/src/main/java/com/kartracer/world/Terrain.java`
- `app/src/main/java/com/kartracer/world/TrackData.java`
- `(new) tools`
