# Kart Racer 1.5 audit

Scope: graphics, controls, UI and animation of `KartRacer_Android_Source_v1_4.zip`. Everything below says whether it was measured, read in code, or only reasoned about.

## How it was checked

* **Read in code:** `sim/Kart`, `sim/Race` (countdown / start), `sim/AiDriver`, `app/RaceOverlay` (touch and HUD), `app/Settings`, `app/SettingsStore`, `app/Ui`, the main menu in `app/Screens`, `app/MainActivity` (GL setup, immersive mode, render scale, EGL chooser), `gl/GameRenderer` (frame loop, quality, render path), the lit shader in `gl/Shaders`, `gfx/CameraRig`, `gfx/Quality`, `gfx/TexGen`.
* **Not read in full:** the garage / lobby / settings / diagnostics screens in `Screens` (layout code), `net/*`, `audio/*`, the mesh and model builders (`KartModels`, `PropModels`, `MeshBuilder`, `WorldMesher`), `Fx` (particles).
* **Run headless (JDK only, no phone):** kart step response, scripted lap driver on all four tracks, the countdown / start-boost logic, texture dump to PNG. The `util`, `world`, `sim`, `net` and `gfx` packages compile and run this way. Lint on those packages: one warning (a redundant cast).
* **Could not be done here:** a Gradle build, a real Android compile (no Android SDK), compiling the GLSL on a GPU, running the game on a device.

## Findings and what was done

### Controls
1. **Gas off by default (fixed).** The old default layout has Gas under the right thumb and Drift, Nitro and Item well above it, so drifting needed a third finger. Auto accelerate is now the default (migration: one time, existing installs; notice shown; can be turned off). Gas is hidden while it is on, the default layout was rearranged around the right thumb (Drift where Gas was), and toggling the setting recomputes the layout unless it was customised.
2. **Brake and auto accelerate (fixed, by reading the code).** Braking did not cancel the auto gas, so brake fought the throttle and the kart could not reverse. Brake now overrides it.
3. **Start penalty with auto gas (found by measurement, fixed).** Holding the gas through the whole countdown slows the kart for 0.48 s at GO (measured; `Race.goRace` penalises a hold over 1.8 s). The start boost needs the gas held continuously for 0.05 to 0.75 s before GO. The gas is now pressed for the last 0.5 s of the countdown and held through GO. Measured: boost on, no penalty, 38.1 m/s two seconds after GO versus 26.7 m/s without the boost. Design decision: auto accelerate always gets the start boost, manual gas has to time it. Easy to change in `GameRenderer.pumpInput` if you want it harder.
4. **Steering model (measured, left unchanged).** Two laps, kart 0, instant tap-style left/right steering versus analog steering: Sunny Shores 92.3 s vs 91.1 s, Jungle Run 93.6 vs 96.5, Magma Peak 105.3 vs 105.9, Dusty Canyon 91.8 vs 91.2, no time off the road. Half of the final turn rate is reached 0.23 to 0.40 s after pressing full lock. The model is sound. A scripted driver with a 120 ms reaction delay weaved (about 4 m off the line, 15 to 22 s off the road), but that mostly shows the limits of my simple script, so it says nothing firm about how the controls feel for a person.

### HUD and animation
5. **HUD redraw (fixed).** It re-invalidated on a 30 ms timer: uneven, at most about 33 fps next to a 60 fps game. It now redraws once per display frame, capped at roughly 70 per second on 90 / 120 Hz screens.
6. **HUD allocations (fixed).** Place, lap and similar strings were rebuilt every frame. They are cached now.
7. **Added:** place number pops and flashes green (gained) or red (lost), GO! pops in, the edit-layout screen no longer shows a label for the hidden Gas button.

### UI
8. **Almost no animation (fixed).** Added press feedback on buttons, an animated switch knob, a slide plus fade for screen changes (was a 180 ms fade), a staggered entrance for the main menu buttons, and the menu kart now glides to its new position between screens (it jumped before).

### Graphics
9. **Highlight clipping (CORRECTED in 1.6).** This item claimed that sunlit sand computed to about 1.27 and clipped. The numbers were wrong: they used the unscaled light colours, while the game scales sun / ambient before use. The real values stay mostly below 1.0, so the shoulder added in 1.5 was not a real fix and slightly darkened bright areas. 1.6 removes it (see `AUDIT_1.6.md`).
10. **Asphalt grain (fixed, visually checked on the generated texture).** The grain was about plus or minus 5 percent and mostly vanished in the mip levels. Added pixel speckle and light / dark stone chips. Jungle Run's dirt road and the shortcut dirt texture are unchanged.
11. **Checked and fine:** texture upload, uniform location caching, preallocated render buffers (no per-frame allocation in the renderer), the road texture itself.

## Left alone on purpose (may matter on your phone)

* **Resolution and anti-aliasing.** Medium and High render at native resolution with 4x MSAA. On a 2400x1080 screen that is 2.6 million pixels. Automatic quality only ever lowers the scale, and every change recreates the surface (a visible hitch), so making it go both ways could oscillate. If your problem is lag, capping the pixel count at start (about 2 million on Medium) is the first thing to try. Not changed because it cannot be measured without your phone.
* **Anti-aliasing level** is chosen when the app starts, so changing quality in Settings does not change it until a restart.
* **No refresh-rate hint** is set (no `setFrameRate` or preferred display mode anywhere); untested idea for 90 / 120 Hz phones.
* **No bloom or other post-processing.** Needs an offscreen render target and a different frame structure. Too risky to do blind.

## Verification status of this release

| Part | Status |
|---|---|
| `sim`, `world`, `util`, `net`, `gfx` | compiled and run headless |
| Start boost / countdown logic | tested headless (see item 3) |
| Asphalt texture | generated and looked at |
| Android files (HUD, UI, settings, activity, renderer glue) | **not compiled**: before / after compiler comparison without the SDK shows no syntax errors and no new errors except unresolved Android classes, so only a real build can confirm |
| GLSL change | **not compiled on a GPU** |
| Behaviour on a device | **not run** |

If the GitHub build turns red, send the red error text.

## Files changed in 1.5

- `app/build.gradle`
- `app/src/main/java/com/kartracer/app/MainActivity.java`
- `app/src/main/java/com/kartracer/app/RaceOverlay.java`
- `app/src/main/java/com/kartracer/app/Screens.java`
- `app/src/main/java/com/kartracer/app/Settings.java`
- `app/src/main/java/com/kartracer/app/SettingsStore.java`
- `app/src/main/java/com/kartracer/app/Ui.java`
- `app/src/main/java/com/kartracer/gfx/TexGen.java`
- `app/src/main/java/com/kartracer/gl/GameRenderer.java`
- `app/src/main/java/com/kartracer/gl/Shaders.java`
- `README.md`
- `AUDIT_1.5.md` (new)
