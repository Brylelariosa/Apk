# Kart Racer (Android)

An original 3D arcade kart racer with real local-network multiplayer.
Pure Java + OpenGL ES 3.0 (no game engine, no native code, no third-party libraries), so the APK is small and runs on every CPU type.
Everything (karts, drivers, tracks, textures, particles and all sound effects) is generated in code, there are no art or audio files to go missing. Textures are uploaded as plain RGBA with mipmaps and anisotropic filtering.

## What's new in 1.8 (driver, wheel guards, hits)

* **Driver.** The sphere head on a bean body is gone. The figure now has sloping shoulders, a neck with collar and neck restraint, upper arms with stripe bands, elbows with pads, forearms with cuffs, gloves whose fingers wrap round the steering wheel grips, a harness, and a race helmet with an angular chin bar, a lens shaped mirror visor with seal and pivot screws, ear covers, intake, rear vent and wing, and a livery stripe in the driver's colour.
* **Wheel guards.** They were a 3.5 cm shell hugging the tyre, so they looked like paper. They are now 8.5 cm thick, stand 10 cm clear of the tyre, are wider, and have rolled lips along both edges (all six karts).
* **Hits.** Torches, beach umbrellas, mushrooms and the corner signs are no longer solid: you drive over them. Hitting a solid prop (tree, rock, cactus...) or a wall now slides along it: it used to bounce at 1.4 and cost 8 % of the speed on every touch, now it keeps 98 %; the stun after a hard hit is 0.10 s instead of 0.25 s, and a stunned kart keeps 60 % of the gas instead of 30 %. A kart pressed head on against a prop slips sideways instead of sticking. Kart to kart bumps stun for 0.18 s and keep 85 % of the speed (were 0.4 s and 72 %). Item hits are shorter and keep more speed: spin-out 20 % shorter, oil 20 % shorter, flip 18 % shorter. Normal laps are unchanged within 1 %.
* No change to the network protocol. Each phone decides the hits of its own kart, so older versions can still race with this one.

## What's new in 1.7 (realistic look)

You said the map, the car, the driver and the trees looked bad and too cartoon-like. A CPU preview of the game (see `tools/preview/`) showed why, and this version changes the following.

* **Foliage was drawn unlit.** Palm fronds and tree canopies were flagged "emissive" by the shader, so they were flat colour with no light and shade. Swaying foliage is now lit like leaves: the sun shades it, light comes through from behind, and sky light reaches the underside.
* **Trees.** New palm (curved ringed trunk, real pinnate fronds made of leaflets, coconuts, dead fronds), new jungle tree (buttress roots, limbs, lumpy canopy built from many leaf clumps, lianas), new bush and grass tufts. Far versions are simpler (view distance switching is unchanged).
* **Driver.** The cartoon child with a huge head is replaced by a race driver: fire suit, harness, neck restraint, gloves and a full face helmet with a dark visor in the kart's paint colour.
* **Car.** New tyres (curved side walls, road grooves or off-road lugs), alloy rims with brake discs and calipers, projector headlamps, LED tail lamps, stainless exhausts, a bucket seat, a flat-bottom steering wheel; the toy antenna with the flag is gone. Paint now has a clear coat glint and mirrors the sky. **The body shapes themselves are unchanged.**
* **Map.** Natural colours instead of neon (olive grass, sand, cooler basalt), less saturation and contrast in the grade, aged asphalt (hairline cracks, a repaired patch, dust at the edges), grass tufts as thin blades. Bigger view-culling radii for the larger trees.
* No change to the network protocol or to where anything collides, so 1.3 to 1.7 devices can still race together.

## What's new in 1.6 (graphics)

* **Volcano road.** The road was a grid of square slabs. It is now cracked basalt with glowing lava cracks (the glow is stored in the texture and lit by the shader, so it does not dim in shadow).
* **Ground.** The ground detail texture had almost no contrast (soft blobs), so sand and grass looked flat. It now has mottling at the scale you see from the driving camera plus grain and flecks. Terrain colours get soft vertex-scale mottling, richer sand / grass variation and a cooler basalt on the volcano track, and the terrain gets baked occlusion (hollows a little darker, ridges a little lighter) so hills have more form.
* **Lighting and colour.** More sun and less flat ambient fill, slightly higher saturation and contrast, and a light split tone (cooler shadows, warmer highlights). This replaces the 1.5 highlight shoulder, which was based on wrong numbers (see `AUDIT_1.6.md`).
* **Smaller things.** The white squares on the start gate were mid grey; the shortcut dirt road has grain and pebbles; the beach gets dune grass.
* **Automatic quality is gentler.** It used to react at about 47 fps and could drop to 60 % resolution with shadows off, which left many phones permanently blurry. It now reacts at about 38 fps, never goes below 78 % resolution, and switches shadows off only as a last resort.
* `tools/preview/` holds a CPU preview renderer used to look at these changes without a phone. It is not part of the Android build.
* No change to the network protocol or to where anything collides, so 1.3 to 1.6 devices can still race together.

## What's new in 1.5

* **Controls.** Auto accelerate is now on by default (one-time switch for existing installs, with a notice; Settings > Controls turns it off again).
  With the gas on one thumb the right thumb could not also reach Drift, Nitro and Item. The Gas button is hidden while auto accelerate is on, Brake now cancels it
  (so you can slow down and reverse), and the default layout puts Drift where the thumb rests with Brake, Nitro and Item around it. Custom layouts are kept.
  The gas is pressed for you during the last half second of the countdown and held through GO, which gives the start boost every race
  (holding the gas for the whole countdown would have slowed the kart for half a second at GO).
* **HUD and animation.** The HUD now redraws in step with the screen (it was a 30 ms timer, so uneven and about 33 fps) and no longer allocates strings every frame.
  The place number pops and flashes green or red when it changes, GO! pops in, buttons shrink slightly while pressed, switches slide, screens slide in,
  the main menu buttons come in one after the other and the menu kart glides between screens instead of jumping.
* **Graphics.** A soft highlight shoulder in the lighting shader (bright sunlit surfaces keep some shading instead of clipping) and finer asphalt grain with stone chips.
* See `AUDIT_1.5.md` for the full audit, what was measured, what is untested and what was left alone on purpose.
* No change to the network protocol, so 1.3, 1.4 and 1.5 devices can still race together.

## What's new in 1.4

* **New drift.** The old drift locked the kart into one tight turn (about 20 m radius) that steering could barely change, and on these wide tracks that felt wrong.
  Now: press Drift while steering and the kart hops and the drift starts *immediately* (even in the middle of the hop, so no waiting for the landing);
  steering shapes the slide: lean into the turn to tighten it (hairpins), steer the other way to open the arc up until the kart is almost straight (long bends),
  and the wheel responds faster while drifting. The kart keeps its speed in the slide, the tail swings out smoothly and the body shows the drift angle.
  Charging is quicker (blue 0.75 s, orange 1.55 s, purple 2.5 s of leaning in; counter steering charges a little slower) and the mini-turbos are a bit longer.
* **Drift feedback.** Thicker tyre smoke, sparks in the colour of the charge level that fly from the outside tyre, a glow on the tyres, a ring flash and a click of haptics
  every time the next level is reached, a three-segment charge bar at the top of the screen, a coloured burst and coloured exhaust flames when you release,
  the camera swings to look along the path of the slide (a little FOV and a slight bank), tyre squeal that follows the slide angle and a little hop sound.
* **Graphics (the big one).** The textures were compressed with a very crude on-the-fly ETC2 encoder, which turned the road and the ground into blocky, off-colour blotches.
  Textures are now uploaded uncompressed (they are tiny) with anisotropic filtering, and the road is rendered at twice the resolution with finer asphalt grain, gravel on the dirt road
  and darker oil patches. The ground gets a second, larger layer of detail so it no longer looks tiled.
  Default quality is higher: full resolution on Medium and High (Low runs at 85%), 4x anti-aliasing on Medium and High (2x on Low), softer shadows with a rotated 8-tap filter on High,
  and the automatic quality drop is much gentler (it lowers the resolution only down to 75% first, then the shadow filter, then the shadows).
  New light screen effects (vignette, speed lines at high speed and a coloured edge glow during a mini-turbo), particles with a glowing core, continuous skid marks without seams,
  a softer light terminator on the karts and Magma Peak is brighter so the road and the slopes can be seen.
* No change to the network protocol, so 1.3 and 1.4 devices can still race together (the drift only changes how your own kart drives).

## What's new in 1.3

* **Rockets no longer turn you around.** A hit used to spin the kart's real heading about one and a half times (and the camera with it), so you came out facing a random way.
  Now only the kart model spins (one whole turn for a rocket or oil, two for a geyser) while the real heading and the camera stay put, so you carry on in the same direction
  and always know where to go. A kart that was facing against the road when it got hit is gently turned back toward it.
* **Wrong-way help.** "Wrong way" is now also detected when the kart merely *points* back against the road (for example after a crash), not only when it drives back.
  The banner shows which way to turn, and with Steering assist on the kart turns itself round (slows down, creeps forward when stopped, swings back onto the road).
  If it is still wrong way after 5 seconds it is put back on the road facing the right way.
* **Steering assist** (Settings > Controls: Off / Low / Medium / High, default Medium). When you let go of the steering it nudges the kart along the road ahead.
  It fades out the moment you steer yourself and stays off while drifting, in the air, off the road and around shortcut forks, so it never fights a deliberate line.
* **Better touch controls.** Roll your thumb from the left to the right steering button (or gas to brake) without lifting. "Drift first, steer second" works now:
  press Drift, land the hop and steer within half a second to start the drift.
* **Graphics.** Anti-aliased edges (4x on High, 2x on Medium where the phone supports it), soft shadows on Medium, richer colour grading, cooler shadow tint,
  clear-coat reflection, rim light and a sharper highlight on the karts, sun glow in the distance haze that matches the sky, a bright flash and shock ring on explosions,
  and dizzy stars circling a spun-out kart.
* Version 1.3 uses network protocol 3, so devices running 1.2 can no longer join a 1.3 host.

## What's new in 1.2

* **New karts and drivers.** All six karts are rebuilt from smooth lofted bodies (rounded shoulders, fenders over the wheels, chrome, lamps, painted stripes,
  engines, roll cages, wings, flames) with fat tyres and painted rims, and every driver is a proper character (helmet or hair, face, arms on the wheel, number badge).
* **Calmer, more controllable steering.** Full lock turns about 25-30% less sharply, the wheel winds on progressively instead of snapping to full lock
  (a short tap is a small correction), touch tilt / slide steering need a bigger movement for full lock, and the AI drivers were retuned to match.
* **Air control.** In the air the nose is pulled toward the direction of travel so jumps end with a straight landing (before, steering in the air meant a sideways
  landing that threw away almost all your speed). You can still nudge the kart left and right while flying.
* **Jungle boulder fixed.** The swinging boulder used to rotate around a point on the ground, so it sank into the track and popped back out. It now rolls around its own centre
  (new rock model, dust trail).
* **New track layouts and real shortcuts.** All four tracks have new layouts with more corners and more variety. Every track has a proper shortcut that forks off the road
  (wedge-shaped mouth, gate props, a boost pad inside, gentle curves, no obstacles) and saves roughly 90-100 m.
* Version 1.2 uses network protocol 2, so devices running 1.1 can no longer join a 1.2 host (tracks and physics differ).

## Get the APK (phone only, GitHub Actions)

1. Open your GitHub repository (browser or GitHub app) and go to the `uploads` folder.
2. Tap **Add file > Upload files**, pick `KartRacer_Android_Source.zip`, then **Commit changes**.
3. Open the **Actions** tab. The **Build APK** run starts by itself and takes about 5-10 minutes.
4. When it turns green, open the run and scroll to **Artifacts**. Download `KartRacer_Android_Source-debug-vN`, unzip it and install `app-debug.apk`
   (allow "install unknown apps" for your file manager or browser if Android asks).
5. If the run turns red, open it, tap the failed step and copy the red error text (or download the `...build-reports` artifact) and send it over.

The workflow in `.github/workflows/build-apk.yml` finds the newest ZIP in the repository, unzips it, finds `settings.gradle` and runs `./gradlew assembleDebug`
(Gradle 8.6, JDK 17, Android Gradle Plugin 8.2.2, compileSdk 34, minSdk 24). If you add the `KEYSTORE_BASE64`, `STORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`
secrets it builds a signed release APK instead.

Requirements on the phone: Android 7.0 or newer with OpenGL ES 3.0 (almost every phone from 2015 on).

## Playing

* **Quick Race**: pick one of 4 tracks, laps, opponents (0-7), difficulty and power-ups.
* **Garage**: 6 karts with different speed / acceleration / handling / toughness, 8 paint colors, 6 drivers.
* **Sound**: engine that follows your speed, tyre squeal, countdown, power-ups, hits, crashes, lap and finish jingles, all synthesised at start-up (`audio/`). Settings > Sound has an on/off switch and a volume slider.
* **Controls** (landscape): left thumb steers, right thumb has Gas, Brake, Drift (hop + slide, release for a mini-turbo), Nitro (spends the meter filled by drifting)
  and the Item button. Every button is labelled, the Item button shows the power-up you hold (name, picture and a short hint when you pick it up) and a shield timer bar appears while a shield is active. Settings offer Buttons / Tilt / Slide steering, auto-accelerate, left-handed layout, button size/opacity and a drag-to-place layout editor.
* **Power-ups**: Turbo (instant boost), Rocket (homing), Coconut (straight shot), Oil slick (drop behind you), Shield. Smash crates, hit boost pads, use ramps and shortcuts, avoid the
  hazards (swinging boulders, geysers, lava, deep water). Start boost: press gas just before GO.

## Multiplayer over Wi-Fi or hotspot (no internet needed)

1. Put the phones on the same Wi-Fi network, or turn on a mobile hotspot on one phone and connect the others to it.
2. One player: **Multiplayer > Host game**. The lobby shows the IP address(es) of the host.
3. Everyone else: **Multiplayer > Join game**. Hosts show up automatically (UDP broadcast discovery). If your router blocks broadcasts, type the host IP manually.
4. The host sets track, laps, AI count and difficulty. Others press **Ready**, the host presses **Start**. Up to 8 racers total (humans + AI).

How it works: TCP (port 47231) for the lobby and race events, UDP (47232) for kart state at 40 Hz with TCP fallback, UDP broadcast on 47233 for discovery.
Every device simulates its own kart, the host runs the AI, items and projectiles. Remote karts are drawn with a smooth (cubic Hermite) path and an adaptive delay of
about 50-170 ms that follows the measured age of incoming packets (typically 60-80 ms on a good Wi-Fi), the shared clock glides instead of jumping, and the
Wi-Fi chip is kept in its low-latency mode while a session is running. Own power-up shots give instant feedback while the host spawns the real projectile. A dropped player is replaced by AI and can reconnect during the race.

## If something goes wrong

**Settings > Diagnostics** shows an in-app log (graphics driver info, shader errors, crashes, network events).
Use *Save to Downloads* (writes `Download/KartRacer/kartracer-log-*.txt`), *Copy* or *Share* and send that text. After a crash the game offers to open the log on the next start.
Graphics: Settings > Graphics has Low / Medium / High presets, shadows, resolution scale, 30/60 FPS cap and automatic resolution lowering when the frame rate drops.

## Project layout

```
app/src/main/java/com/kartracer/
  util/   math, matrices, noise, deterministic RNG, diagnostics log
  audio/  procedural sound synthesizer and SoundPool player
  world/  track definitions, spline roads, terrain generation, scenery, world queries
  sim/    kart physics, AI drivers, race rules, items, hazards, network hooks
  net/    wire protocol, host server, client link, LAN discovery
  gfx/    procedural meshes (karts, props, terrain), textures, particles, camera
  gl/     OpenGL ES 3 renderer (shadow map, instancing, water, sky, particles)
  app/    activity, menus, HUD / touch controls, settings, engine glue
```
