/*
 * CPU preview of the game's look (NOT part of the Android build). It rasterizes the real track, prop and kart meshes with the real procedural
 * textures and a Java port of the lit / sky / water shaders, so graphics changes can be looked at without a phone.
 * It is an approximation: no MSAA, no GPU filtering quirks, shadows are a simple 1024 px map.
 *
 *   cd app/src/main/java
 *   java -m jdk.compiler/com.sun.tools.javac.Main -nowarn -d /tmp/kr $(find com/kartracer/util com/kartracer/world com/kartracer/sim com/kartracer/net com/kartracer/gfx -name '*.java')
 *   java -m jdk.compiler/com.sun.tools.javac.Main -nowarn -cp /tmp/kr -d /tmp/kr ../../../../tools/preview/Soft.java
 *   java -Djava.awt.headless=true -Xmx3g -cp /tmp/kr Soft mytag 3 race0      # writes prev_mytag_race0.png (race0..race3, karts, driver0..driver5, prop:<track>:<name>, cmp0..cmp3)
 */
import com.kartracer.gfx.*;
import com.kartracer.util.*;
import com.kartracer.world.*;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.*;

/** CPU preview of the game's look: real meshes and textures, the lit / sky / water shaders ported to Java. */
public class Soft {
    // ------------------------------------------------------------------------------------------ textures
    static final class Tx {
        final int n; final int[] w, h; final float[][] d;
        Tx(TexGen.Tex t) {
            int lv = 1, s = Math.min(t.w, t.h);
            while (s > 1) { s >>= 1; lv++; }
            n = lv; w = new int[lv]; h = new int[lv]; d = new float[lv][];
            w[0] = t.w; h[0] = t.h; d[0] = new float[t.w * t.h * 4];
            for (int i = 0; i < t.w * t.h; i++) for (int c = 0; c < 4; c++) d[0][i * 4 + c] = (t.rgba[i * 4 + c] & 255) / 255f;
            for (int l = 1; l < lv; l++) {
                w[l] = Math.max(1, w[l - 1] / 2); h[l] = Math.max(1, h[l - 1] / 2); d[l] = new float[w[l] * h[l] * 4];
                for (int y = 0; y < h[l]; y++) for (int x = 0; x < w[l]; x++) for (int c = 0; c < 4; c++) {
                    float s2 = 0;
                    for (int dy = 0; dy < 2; dy++) for (int dx = 0; dx < 2; dx++) {
                        int sx = Math.min(w[l - 1] - 1, x * 2 + dx), sy = Math.min(h[l - 1] - 1, y * 2 + dy);
                        s2 += d[l - 1][(sy * w[l - 1] + sx) * 4 + c];
                    }
                    d[l][(y * w[l] + x) * 4 + c] = s2 * 0.25f;
                }
            }
        }
        void bil(int l, float u, float v, float[] o, float k) {
            int W = w[l], H = h[l];
            float fx = u * W - 0.5f, fy = v * H - 0.5f;
            int x0 = (int) Math.floor(fx), y0 = (int) Math.floor(fy);
            float tx = fx - x0, ty = fy - y0;
            int xa = Math.floorMod(x0, W), xb = Math.floorMod(x0 + 1, W), ya = Math.floorMod(y0, H), yb = Math.floorMod(y0 + 1, H);
            float[] dd = d[l];
            for (int c = 0; c < 4; c++) {
                float a = dd[(ya * W + xa) * 4 + c] * (1 - tx) + dd[(ya * W + xb) * 4 + c] * tx;
                float b = dd[(yb * W + xa) * 4 + c] * (1 - tx) + dd[(yb * W + xb) * 4 + c] * tx;
                o[c] += (a * (1 - ty) + b * ty) * k;
            }
        }
        void sample(float u, float v, float lod, float[] o) {
            lod = Math.max(0f, Math.min(n - 1, lod));
            int l0 = (int) lod; float f = lod - l0;
            o[0] = o[1] = o[2] = o[3] = 0f;
            bil(l0, u, v, o, 1f - f);
            if (f > 0.001f && l0 + 1 < n) bil(l0 + 1, u, v, o, f);
            else if (f > 0.001f) bil(l0, u, v, o, f);
        }
    }

    // ------------------------------------------------------------------------------------------ meshes
    static final class Dec {
        int n; float[] p, nr, c, uv; short[] idx;
        Dec(MeshData m) { this(m.vcount, m.verts, m.indices); }
        Dec(int vc, byte[] vb, short[] ix) {
            ByteBuffer b = ByteBuffer.wrap(vb).order(ByteOrder.LITTLE_ENDIAN);
            n = vc; p = new float[n * 3]; nr = new float[n * 3]; c = new float[n * 4]; uv = new float[n * 2]; idx = ix;
            for (int i = 0; i < n; i++) {
                int o = i * MeshData.STRIDE;
                p[i * 3] = b.getFloat(o); p[i * 3 + 1] = b.getFloat(o + 4); p[i * 3 + 2] = b.getFloat(o + 8);
                nr[i * 3] = vb[o + 12] / 127f; nr[i * 3 + 1] = vb[o + 13] / 127f; nr[i * 3 + 2] = vb[o + 14] / 127f;
                c[i * 4] = (vb[o + 16] & 255) / 255f; c[i * 4 + 1] = (vb[o + 17] & 255) / 255f; c[i * 4 + 2] = (vb[o + 18] & 255) / 255f; c[i * 4 + 3] = (vb[o + 19] & 255) / 255f;
                uv[i * 2] = b.getFloat(o + 20); uv[i * 2 + 1] = b.getFloat(o + 24);
            }
        }
    }
    static final Map<Object, Dec> decCache = new IdentityHashMap<>();
    static Dec dec(MeshData m) { return decCache.computeIfAbsent(m, k -> new Dec(m)); }

    // ------------------------------------------------------------------------------------------ raster
    static final int NA = 12;   // wx wy wz nx ny nz r g b a u v
    static final class V { float x, y, z, w; final float[] a = new float[NA]; }

    static int W, H;
    static float[] zb, cr, cg, cb;
    static float[] vp = new float[16];
    static final float NEAR = 0.6f;

    // shading state
    static final int M_STATIC = 0, M_INST = 1, M_KART = 2, M_WATER = 3;
    static float[] sunDir = new float[3], sunCol = new float[3], ambSky = new float[3], ambGround = new float[3], fogCol = new float[3];
    static float fogDen; static float[] cam = new float[3];
    static float[] paint = {1, 1, 1}; static boolean detail2;
    static float[] top = new float[3], horizon = new float[3], shallow = new float[3], deep = new float[3];
    static boolean lava;
    static float[] lightVP = new float[16]; static float[] smap; static int SM = 1024; static boolean shadowOn;
    static int GRADE = 3;   // 0 = as shipped in 1.5, 1 = original 1.4 grade, 3 = new grade
    static float SUN_K = 0.85f, AMBS_K = 0.52f, AMBG_K = 0.45f; static boolean TEX_EMIS = true;
    static Tx noiseTx;

    static float clamp(float x, float a, float b) { return x < a ? a : (x > b ? b : x); }
    static float sat(float x) { return clamp(x, 0, 1); }
    static float smooth(float a, float b, float x) { float t = sat((x - a) / (b - a)); return t * t * (3 - 2 * t); }
    static float mix(float a, float b, float t) { return a + (b - a) * t; }

    static void clearTarget(int w, int h) {
        W = w; H = h; zb = new float[w * h]; cr = new float[w * h]; cg = new float[w * h]; cb = new float[w * h];
        Arrays.fill(zb, Float.POSITIVE_INFINITY);
    }

    static V xf(float[] m, float x, float y, float z, float[] attr) {
        V v = new V();
        v.x = m[0] * x + m[4] * y + m[8] * z + m[12];
        v.y = m[1] * x + m[5] * y + m[9] * z + m[13];
        v.z = m[2] * x + m[6] * y + m[10] * z + m[14];
        v.w = m[3] * x + m[7] * y + m[11] * z + m[15];
        if (attr != null) System.arraycopy(attr, 0, v.a, 0, NA);
        return v;
    }

    static V lerpV(V p, V q, float t) {
        V r = new V();
        r.x = p.x + (q.x - p.x) * t; r.y = p.y + (q.y - p.y) * t; r.z = p.z + (q.z - p.z) * t; r.w = p.w + (q.w - p.w) * t;
        for (int i = 0; i < NA; i++) r.a[i] = p.a[i] + (q.a[i] - p.a[i]) * t;
        return r;
    }

    static void tri(V a, V b, V c, int mode, Tx tx, boolean cull, boolean depthOnly) {
        if (a.w <= 1e-6f && b.w <= 1e-6f && c.w <= 1e-6f) return;
        if (a.x > a.w && b.x > b.w && c.x > c.w) return;
        if (a.x < -a.w && b.x < -b.w && c.x < -c.w) return;
        if (a.y > a.w && b.y > b.w && c.y > c.w) return;
        if (a.y < -a.w && b.y < -b.w && c.y < -c.w) return;
        if (a.z > a.w && b.z > b.w && c.z > c.w) return;
        boolean ia = a.z >= -a.w, ib = b.z >= -b.w, ic = c.z >= -c.w;
        if (ia && ib && ic) { fill(a, b, c, mode, tx, cull, depthOnly); return; }
        if (!ia && !ib && !ic) return;
        V[] in = {a, b, c}; V[] out = new V[4]; int n = 0;
        for (int i = 0; i < 3; i++) {
            V p = in[i], q = in[(i + 1) % 3];
            float dp = p.z + p.w, dq = q.z + q.w;
            if (dp >= 0) out[n++] = p;
            if ((dp >= 0) != (dq >= 0)) out[n++] = lerpV(p, q, dp / (dp - dq));
        }
        for (int i = 1; i + 1 < n; i++) fill(out[0], out[i], out[i + 1], mode, tx, cull, depthOnly);
    }

    static final float[] attr = new float[NA], rgbOut = new float[4];

    static void fill(V v0, V v1, V v2, int mode, Tx tx, boolean cull, boolean depthOnly) {
        float iw0 = 1f / v0.w, iw1 = 1f / v1.w, iw2 = 1f / v2.w;
        float x0 = (v0.x * iw0 * 0.5f + 0.5f) * W, y0 = (0.5f - v0.y * iw0 * 0.5f) * H, z0 = v0.z * iw0;
        float x1 = (v1.x * iw1 * 0.5f + 0.5f) * W, y1 = (0.5f - v1.y * iw1 * 0.5f) * H, z1 = v1.z * iw1;
        float x2 = (v2.x * iw2 * 0.5f + 0.5f) * W, y2 = (0.5f - v2.y * iw2 * 0.5f) * H, z2 = v2.z * iw2;
        float area = (x1 - x0) * (y2 - y0) - (y1 - y0) * (x2 - x0);
        if (Math.abs(area) < 1e-8f) return;
        if (cull && area >= 0) return;   // screen space y is flipped: front faces have negative area
        int minX = Math.max(0, (int) Math.floor(Math.min(x0, Math.min(x1, x2)))), maxX = Math.min(W - 1, (int) Math.ceil(Math.max(x0, Math.max(x1, x2))));
        int minY = Math.max(0, (int) Math.floor(Math.min(y0, Math.min(y1, y2)))), maxY = Math.min(H - 1, (int) Math.ceil(Math.max(y0, Math.max(y1, y2))));
        if (minX > maxX || minY > maxY) return;
        float lod = 0f;
        if (tx != null && !depthOnly) {
            float du1 = v1.a[10] - v0.a[10], dv1 = v1.a[11] - v0.a[11], du2 = v2.a[10] - v0.a[10], dv2 = v2.a[11] - v0.a[11];
            float uvA = Math.abs(du1 * dv2 - dv1 * du2) * tx.w[0] * tx.h[0];
            lod = (float) (0.5 * Math.log(Math.max(1e-9, uvA / Math.abs(area))) / Math.log(2)) + 0.45f;
        }
        float inv = 1f / area;
        float[] a0 = v0.a, a1 = v1.a, a2 = v2.a;
        for (int y = minY; y <= maxY; y++) {
            float py = y + 0.5f;
            for (int x = minX; x <= maxX; x++) {
                float px = x + 0.5f;
                float l0 = ((x2 - x1) * (py - y1) - (y2 - y1) * (px - x1)) * inv;
                float l1 = ((x0 - x2) * (py - y2) - (y0 - y2) * (px - x2)) * inv;
                float l2 = 1f - l0 - l1;
                if (l0 < 0 || l1 < 0 || l2 < 0) continue;
                float z = l0 * z0 + l1 * z1 + l2 * z2;
                if (z < -1f || z > 1f) continue;
                int id = y * W + x;
                if (z >= zb[id]) continue;
                if (depthOnly) { zb[id] = z; continue; }
                float iw = l0 * iw0 + l1 * iw1 + l2 * iw2;
                float k0 = l0 * iw0 / iw, k1 = l1 * iw1 / iw, k2 = l2 * iw2 / iw;
                for (int i = 0; i < NA; i++) attr[i] = a0[i] * k0 + a1[i] * k1 + a2[i] * k2;
                if (mode == M_WATER) {
                    water(attr, rgbOut);
                    float al = rgbOut[3];
                    cr[id] = cr[id] * (1 - al) + rgbOut[0] * al; cg[id] = cg[id] * (1 - al) + rgbOut[1] * al; cb[id] = cb[id] * (1 - al) + rgbOut[2] * al;
                    continue;
                }
                zb[id] = z;
                shadeLit(attr, lod, mode, tx, rgbOut);
                cr[id] = rgbOut[0]; cg[id] = rgbOut[1]; cb[id] = rgbOut[2];
            }
        }
    }

    // ------------------------------------------------------------------------------------------ shading (ports of the GLSL)
    static final float[] t1 = new float[4], t2 = new float[4];

    static float shadowFactor(float wx, float wy, float wz) {
        float[] m = lightVP;
        float cx = m[0] * wx + m[4] * wy + m[8] * wz + m[12], cy = m[1] * wx + m[5] * wy + m[9] * wz + m[13], cz = m[2] * wx + m[6] * wy + m[10] * wz + m[14];
        float sx = cx * 0.5f + 0.5f, sy = cy * 0.5f + 0.5f, sz = cz * 0.5f + 0.5f;
        if (sz > 1 || sz < 0 || sx < 0 || sx > 1 || sy < 0 || sy > 1) return 1f;
        float edge = Math.max(Math.abs(sx - 0.5f), Math.abs(sy - 0.5f)) * 2f;
        float fade = smooth(0.78f, 1f, edge);
        float z = sz - 0.0010f;
        float s = 0; int cnt = 0;
        for (int j = -1; j <= 1; j++) for (int i = -1; i <= 1; i++) {
            int ix = (int) (sx * SM) + i, iy = (int) ((1f - sy) * SM) + j;
            if (ix < 0 || iy < 0 || ix >= SM || iy >= SM) { s += 1; cnt++; continue; }
            float d = smap[iy * SM + ix] * 0.5f + 0.5f;
            s += z <= d ? 1f : 0f; cnt++;
        }
        s /= cnt;
        return mix(s, 1f, fade);
    }

    static void grade(float[] lit) {
        if (GRADE == 0) {
            for (int c = 0; c < 3; c++) { float over = Math.max(lit[c] - 0.78f, 0); lit[c] = Math.min(lit[c], 0.78f) + 0.22f * (1f - (float) Math.exp(-over * 4.5454f)); }
        }
        float satK = GRADE == 3 ? 1.08f : 1.14f, curveK = GRADE == 3 ? 0.32f : 0.28f;
        float lum = lit[0] * 0.299f + lit[1] * 0.587f + lit[2] * 0.114f;
        for (int c = 0; c < 3; c++) lit[c] = mix(lum, lit[c], satK);
        for (int c = 0; c < 3; c++) { float cl = sat(lit[c]); lit[c] = mix(lit[c], cl * cl * (3 - 2 * cl), curveK); }
        if (GRADE == 3) {
            // split toning: slightly cool shadows, slightly warm highlights
            float l2 = sat(lum);
            lit[0] *= 1f - 0.035f * (1f - l2) + 0.03f * l2;
            lit[2] *= 1f + 0.05f * (1f - l2) - 0.03f * l2;
        }
    }

    static void shadeLit(float[] a, float lod, int mode, Tx tx, float[] out) {
        float wx = a[0], wy = a[1], wz = a[2];
        float nx = a[3], ny = a[4], nz = a[5];
        float nl = (float) Math.sqrt(nx * nx + ny * ny + nz * nz); if (nl < 1e-6f) nl = 1; nx /= nl; ny /= nl; nz /= nl;
        float tr = 1, tg = 1, tb = 1;
        if (tx != null) {
            tx.sample(a[10], a[11], lod, t1); tr = t1[0]; tg = t1[1]; tb = t1[2];
            if (detail2) {
                float u2 = a[10] * 0.31f + a[11] * 0.19f + 0.37f, v2 = a[11] * 0.31f - a[10] * 0.19f + 0.11f;
                tx.sample(u2, v2, lod - 1.46f, t2); tr *= t2[0] * 1.1f; tg *= t2[1] * 1.1f; tb *= t2[2] * 1.1f;
            }
        }
        float ar = a[6] * tr, ag = a[7] * tg, ab = a[8] * tb;
        float emis = a[9];
        float texEmis = (tx != null && TEX_EMIS && mode != M_KART) ? 1f - t1[3] : 0f;
        if (texEmis > emis) emis = texEmis;
        if (mode == M_KART) {
            float k = a[9];
            ar = mix(a[6], a[6] * paint[0], k); ag = mix(a[7], a[7] * paint[1], k); ab = mix(a[8], a[8] * paint[2], k); emis = 0;
        }
        float nd0 = nx * sunDir[0] + ny * sunDir[1] + nz * sunDir[2];
        float ndl = Math.max((nd0 + 0.12f) / 1.12f, 0f);
        if (mode == M_INST && a[10] > 0.5f) ndl = Math.max(nd0, 0f) + 0.40f * Math.max(-nd0, 0f);
        float sh = shadowOn ? shadowFactor(wx, wy, wz) : 1f;
        float hy = ny * 0.5f + 0.5f;
        float[] amb = {mix(ambGround[0], ambSky[0], hy), mix(ambGround[1], ambSky[1], hy), mix(ambGround[2], ambSky[2], hy)};
        if (mode == M_INST && a[10] > 0.5f) for (int c = 0; c < 3; c++) amb[c] = mix(amb[c], ambSky[c] * 1.15f, 0.45f);
        amb[0] *= 1f - 0.05f * (1f - sh); amb[2] *= 1f + 0.08f * (1f - sh);
        float[] lit = {ar * (amb[0] + sunCol[0] * ndl * sh), ag * (amb[1] + sunCol[1] * ndl * sh), ab * (amb[2] + sunCol[2] * ndl * sh)};
        lit[0] = mix(lit[0], ar * 1.2f, emis); lit[1] = mix(lit[1], ag * 1.2f, emis); lit[2] = mix(lit[2], ab * 1.2f, emis);
        float dx = cam[0] - wx, dy = cam[1] - wy, dz = cam[2] - wz;
        float d = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (mode == M_KART) {
            float vx = dx / d, vy = dy / d, vz = dz / d;
            float hx = sunDir[0] + vx, hyy = sunDir[1] + vy, hz = sunDir[2] + vz;
            float hl = (float) Math.sqrt(hx * hx + hyy * hyy + hz * hz); hx /= hl; hyy /= hl; hz /= hl;
            float ka = a[9];
            float ndv = Math.max(nx * vx + ny * vy + nz * vz, 0f);
            float fres = (float) Math.pow(1f - ndv, 4);
            float nh = Math.max(nx * hx + ny * hyy + nz * hz, 0f);
            float spec = (float) Math.pow(nh, 48) * 0.40f * sh;
            float coat = (float) Math.pow(nh, 260) * 1.6f * sh * ka;
            for (int c = 0; c < 3; c++) lit[c] += sunCol[c] * (spec * (0.25f + ka) + coat);
            float rvy = -vy + 2f * (nx * vx + ny * vy + nz * vz) * ny;
            float ev = smooth(-0.3f, 0.6f, rvy);
            float em = (0.10f + 0.50f * fres) * ka;
            for (int c = 0; c < 3; c++) { float env = mix(ambGround[c], ambSky[c], ev) * 1.55f; lit[c] = mix(lit[c], env, em); }
            float rim = (float) Math.pow(1f - ndv, 3);
            for (int c = 0; c < 3; c++) lit[c] += mix(ambSky[c], sunCol[c], 0.4f) * rim * (0.12f + 0.3f * ka);
        }
        if (texEmis > 0f) { lit[0] += ar * texEmis * 0.5f; lit[1] += ag * texEmis * 0.5f; lit[2] += ab * texEmis * 0.5f; }
        grade(lit);
        float f = 1f - (float) Math.exp(-d * d * fogDen * fogDen);
        float rdx = -dx / d, rdy = -dy / d, rdz = -dz / d;
        float sg = (float) Math.pow(Math.max(rdx * sunDir[0] + rdy * sunDir[1] + rdz * sunDir[2], 0), 8) * 0.22f;
        f = sat(f);
        for (int c = 0; c < 3; c++) lit[c] = mix(lit[c], fogCol[c] + sunCol[c] * sg, f);
        out[0] = lit[0]; out[1] = lit[1]; out[2] = lit[2];
    }

    static void water(float[] a, float[] out) {
        float wx = a[0], wy = a[1], wz = a[2];
        float depth = a[9] * 3.5f - 0.5f;
        float dx = cam[0] - wx, dy = cam[1] - wy, dz = cam[2] - wz;
        float dist = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        float vx = dx / dist, vy = dy / dist, vz = dz / dist;
        float[] col = new float[3]; float alpha;
        float t = 0.8f, qx = wx, qy = wz;
        if (lava) {
            float aa = 0.5f + 0.5f * (float) Math.sin(qx * 0.15f + qy * 0.11f + t * 0.4f);
            float bb = 0.5f + 0.5f * (float) Math.sin(qx * 0.9f - t * 0.6f) * (float) Math.sin(qy * 0.8f + t * 0.5f);
            for (int c = 0; c < 3; c++) col[c] = mix(deep[c], shallow[c], aa * 0.6f + bb * 0.5f);
            col[0] += 0.5f * bb; col[1] += 0.25f * bb; col[2] += 0.05f * bb; alpha = 1f;
        } else {
            float nx = 0.12f * ((float) Math.cos(qx * 0.8f + t * 1.2f) + 0.6f * (float) Math.cos((qx + qy) * 1.6f - t * 1.9f)), ny = 1f,
                  nz = 0.12f * ((float) Math.cos(qy * 0.9f - t) + 0.6f * (float) Math.cos((qx - qy) * 1.4f + t * 1.5f));
            float nl = (float) Math.sqrt(nx * nx + 1 + nz * nz); nx /= nl; ny /= nl; nz /= nl;
            float d01 = sat(depth / 3f);
            float fres = (float) Math.pow(1f - Math.max(nx * vx + ny * vy + nz * vz, 0), 4);
            for (int c = 0; c < 3; c++) { float base = mix(shallow[c], deep[c], d01); col[c] = mix(base, top[c] * 0.9f + 0.1f, 0.5f * fres + 0.08f); }
            float hx = sunDir[0] + vx, hy = sunDir[1] + vy, hz = sunDir[2] + vz; float hl = (float) Math.sqrt(hx * hx + hy * hy + hz * hz);
            float sp = (float) Math.pow(Math.max((nx * hx + ny * hy + nz * hz) / hl, 0), 120) * 1.3f;
            for (int c = 0; c < 3; c++) col[c] += sunCol[c] * sp;
            float shore = depth + 0.05f * (float) Math.sin(t * 1.6f + qx * 0.7f);
            float foam = (1f - smooth(0f, 0.32f, shore)) * (0.6f + 0.4f * (float) Math.sin(qx * 1.9f + qy * 1.3f + t * 2f));
            foam = sat(foam);
            for (int c = 0; c < 3; c++) col[c] = mix(col[c], 1f, foam * 0.85f);
            alpha = mix(0.45f, 0.93f, smooth(0f, 1.2f, depth)); alpha = Math.max(alpha, foam * 0.9f);
        }
        float f = sat(1f - (float) Math.exp(-dist * dist * fogDen * fogDen));
        float sg = (float) Math.pow(Math.max(-(vx * sunDir[0] + vy * sunDir[1] + vz * sunDir[2]), 0), 8) * 0.22f;
        for (int c = 0; c < 3; c++) col[c] = mix(col[c], fogCol[c] + sunCol[c] * sg, f);
        out[0] = col[0]; out[1] = col[1]; out[2] = col[2]; out[3] = alpha;
    }

    // ------------------------------------------------------------------------------------------ drawing helpers
    static void drawDec(Dec m, float[] model, int mode, Tx tx, boolean cull, boolean depthOnly, float[] mvp) {
        V[] vs = new V[m.n];
        float[] at = new float[NA];
        for (int i = 0; i < m.n; i++) {
            float x = m.p[i * 3], y = m.p[i * 3 + 1], z = m.p[i * 3 + 2];
            float nx = m.nr[i * 3], ny = m.nr[i * 3 + 1], nz = m.nr[i * 3 + 2];
            float wx = x, wy = y, wz = z, wnx = nx, wny = ny, wnz = nz;
            if (model != null) {
                wx = model[0] * x + model[4] * y + model[8] * z + model[12];
                wy = model[1] * x + model[5] * y + model[9] * z + model[13];
                wz = model[2] * x + model[6] * y + model[10] * z + model[14];
                wnx = model[0] * nx + model[4] * ny + model[8] * nz; wny = model[1] * nx + model[5] * ny + model[9] * nz; wnz = model[2] * nx + model[6] * ny + model[10] * nz;
            }
            at[0] = wx; at[1] = wy; at[2] = wz; at[3] = wnx; at[4] = wny; at[5] = wnz;
            at[6] = m.c[i * 4]; at[7] = m.c[i * 4 + 1]; at[8] = m.c[i * 4 + 2]; at[9] = m.c[i * 4 + 3]; at[10] = m.uv[i * 2]; at[11] = m.uv[i * 2 + 1];
            vs[i] = xf(mvp, wx, wy, wz, at);
        }
        short[] ix = m.idx;
        for (int i = 0; i + 2 < ix.length; i += 3) tri(vs[ix[i] & 0xFFFF], vs[ix[i + 1] & 0xFFFF], vs[ix[i + 2] & 0xFFFF], mode, tx, cull, depthOnly);
    }

    static void drawInst(Dec m, float px, float py, float pz, float yaw, float sc, float tint, float[] mvp, boolean depthOnly, Tx tx) {
        V[] vs = new V[m.n];
        float[] at = new float[NA];
        float c = (float) Math.cos(yaw), s = (float) Math.sin(yaw);
        for (int i = 0; i < m.n; i++) {
            float x = m.p[i * 3] * sc, y = m.p[i * 3 + 1] * sc, z = m.p[i * 3 + 2] * sc;
            float wx = c * x - s * z + px, wy = y + py, wz = s * x + c * z + pz;
            float nx = m.nr[i * 3], ny = m.nr[i * 3 + 1], nz = m.nr[i * 3 + 2];
            at[0] = wx; at[1] = wy; at[2] = wz; at[3] = c * nx - s * nz; at[4] = ny; at[5] = s * nx + c * nz;
            at[6] = m.c[i * 4] * tint; at[7] = m.c[i * 4 + 1] * tint; at[8] = m.c[i * 4 + 2] * tint;
            float a8 = m.c[i * 4 + 3] * 255f; boolean ef = a8 >= 127.5f; float swy = (a8 - (ef ? 128f : 0f)) / 127f; boolean fol = ef && swy >= 0.02f;
            at[9] = (ef && !fol) ? 1f : 0f; at[10] = fol ? 1f : 0f; at[11] = 0;
            vs[i] = xf(mvp, wx, wy, wz, at);
        }
        short[] ix = m.idx;
        for (int i = 0; i + 2 < ix.length; i += 3) tri(vs[ix[i] & 0xFFFF], vs[ix[i + 1] & 0xFFFF], vs[ix[i + 2] & 0xFFFF], M_INST, tx, true, depthOnly);
    }

    static void rgb(int hex, float k, float[] o) { o[0] = ((hex >> 16) & 255) / 255f * k; o[1] = ((hex >> 8) & 255) / 255f * k; o[2] = (hex & 255) / 255f * k; }

    static void setupScene(TrackDef def) {
        float el = def.sunEl * MathX.DEG, az = def.sunAz * MathX.DEG;
        sunDir[0] = (float) (Math.cos(el) * Math.sin(az)); sunDir[1] = (float) Math.sin(el); sunDir[2] = (float) (Math.cos(el) * Math.cos(az));
        rgb(def.sunColor, SUN_K, sunCol); rgb(def.ambSky, AMBS_K, ambSky); rgb(def.ambGround, AMBG_K, ambGround); rgb(def.fogColor, 1f, fogCol);
        rgb(def.skyTop, 1f, top); rgb(def.skyHorizon, 1f, horizon); rgb(def.waterShallow, 1f, shallow); rgb(def.waterDeep, 1f, deep);
        fogDen = def.fogDensity; lava = def.lava;
    }

    static class KartSpec { int type, driver, paintHex; float x, y, z, yaw; }

    static float[] yawM(float yaw, float x, float y, float z) { float[] m = Mat4.create(); Mat4.yaw(m, yaw, x, y, z); return m; }

    static void kartMats(KartSpec k, float[][] out) {   // out[0] body, [1] driver, [2..5] wheels
        float[] m1 = Mat4.create(), m2 = Mat4.create();
        float[] body = Mat4.create();
        Mat4.yaw(body, k.yaw, k.x, k.y + 0.02f, k.z);
        out[0] = body;
        Mat4.translation(m1, 0f, KartModels.SEAT_Y[k.type], KartModels.SEAT_Z[k.type]);
        out[1] = Mat4.create(); Mat4.mul(out[1], body, m1);
        for (int w = 0; w < 4; w++) {
            float sx = (w & 1) == 0 ? -1f : 1f, sz = w < 2 ? -1f : 1f;
            float rad = w < 2 ? KartModels.FRONT_R[k.type] : KartModels.REAR_R[k.type];
            Mat4.translation(m1, sx * KartModels.TRACK_HALF[k.type], rad, sz * KartModels.BASE_HALF[k.type]);
            out[2 + w] = Mat4.create(); Mat4.mul(out[2 + w], body, m1);
        }
    }

    static final Map<TrackDef, SceneData> scenes = new HashMap<>();
    static SceneData scene(TrackDef d) { return scenes.computeIfAbsent(d, SceneData::build); }

    // ------------------------------------------------------------------------------------------ the frame
    static BufferedImage render(TrackDef def, float[] eye, float[] tgt, float fov, int outW, int outH, int ss, List<KartSpec> karts, float[] shadowFocus, boolean shadows, boolean water) {
        SceneData sd = scene(def); TrackData td = sd.td;
        StaticAssets sa = StaticAssets.get();
        setupScene(def);
        cam[0] = eye[0]; cam[1] = eye[1]; cam[2] = eye[2];
        W = outW * ss; H = outH * ss;
        clearTarget(W, H);
        float[] proj = Mat4.create(), view = Mat4.create();
        float q_draw = 360f;
        Mat4.perspective(proj, fov * MathX.DEG, outW / (float) outH, NEAR, q_draw + 220f);
        Mat4.lookAt(view, eye[0], eye[1], eye[2], tgt[0], tgt[1], tgt[2], 0, 1, 0);
        Mat4.mul(vp, proj, view);

        float[][][] km = new float[karts.size()][6][];
        for (int i = 0; i < karts.size(); i++) kartMats(karts.get(i), km[i]);

        // ---- shadow map
        shadowOn = shadows;
        if (shadows) {
            SM = 1024;
            float half = 36f;
            float[] lv = Mat4.create(), lp = Mat4.create();
            Mat4.lookAt(lv, shadowFocus[0] + sunDir[0] * 110f, shadowFocus[1] + sunDir[1] * 110f, shadowFocus[2] + sunDir[2] * 110f, shadowFocus[0], shadowFocus[1], shadowFocus[2], 0, 1, 0);
            Mat4.ortho(lp, -half, half, -half, half, 20f, 220f);
            Mat4.mul(lightVP, lp, lv);
            // depth pass into a separate target
            int sW = W, sH = H; float[] szb = zb, scr = cr, scg = cg, scb = cb; float[] svp = vp.clone();
            W = SM; H = SM; zb = new float[SM * SM]; Arrays.fill(zb, Float.POSITIVE_INFINITY);
            float[] lvp = lightVP.clone();
            for (int i = 0; i < karts.size(); i++) {
                KartSpec k = karts.get(i);
                drawDec(dec(sa.bodies[k.type]), km[i][0], M_KART, null, false, true, lvp);
                drawDec(dec(sa.drivers[k.driver]), km[i][1], M_KART, null, false, true, lvp);
                for (int w = 0; w < 4; w++) drawDec(dec(w < 2 ? sa.wheelsF[k.type] : sa.wheelsR[k.type]), km[i][2 + w], M_KART, null, false, true, lvp);
            }
            for (int i = 0; i < td.scN; i++) {
                int type = td.scType[i];
                if (!Props.castsShadow(type)) continue;
                float dx = td.scX[i] - shadowFocus[0], dz = td.scZ[i] - shadowFocus[2];
                if (dx * dx + dz * dz > 62f * 62f) continue;
                MeshData pm = sd.props[type][1]; if (pm == null) continue;
                drawInst(dec(pm), td.scX[i], td.scY[i], td.scZ[i], td.scYaw[i], td.scScale[i], 1f, lvp, true, null);
            }
            drawDec(dec(sd.gate), yawM(sd.gateYaw, sd.gateX, sd.gateY, sd.gateZ), M_STATIC, null, false, true, lvp);
            smap = zb;
            W = sW; H = sH; zb = szb; cr = scr; cg = scg; cb = scb; vp = svp;
        }

        // ---- opaque pass
        Tx detail = new Tx(sa.detail);
        Tx white = new Tx(sa.white);
        Tx roadTx = new Tx(sd.roadTex), dirtTx = new Tx(sd.dirtTex);
        detail2 = true;
        WorldMesher.ChunkMesh[] cm = sd.chunks;
        for (int i = 0; i < cm.length; i++) {
            WorldMesher.ChunkMesh c = cm[i];
            float dx = c.cx - eye[0], dz = c.cz - eye[2];
            float d = (float) Math.sqrt(dx * dx + dz * dz);
            if (d - c.radius > q_draw + 60f) continue;
            int lod = d < 100f ? 0 : (d < 210f ? 1 : 2);
            Dec dd = decCache.computeIfAbsent(c.idx[lod], k -> new Dec(c.vcount, c.verts, c.idx[lod]));
            drawDec(dd, null, M_STATIC, detail, true, false, vp);
        }
        detail2 = false;
        drawDec(dec(sd.roads[0]), null, M_STATIC, roadTx, true, false, vp);
        for (int k = 1; k < sd.roads.length; k++) drawDec(dec(sd.roads[k]), null, M_STATIC, dirtTx, true, false, vp);
        for (int i = 0; i < td.ramps.length; i++) { TrackData.Ramp r = td.ramps[i]; drawDec(dec(sd.rampMeshes[i]), yawM(r.yaw, r.x, td.groundHeight(r.x, r.z), r.z), M_STATIC, white, true, false, vp); }
        drawDec(dec(sd.gate), yawM(sd.gateYaw, sd.gateX, sd.gateY, sd.gateZ), M_STATIC, white, true, false, vp);
        for (int i = 0; i < td.crates.length; i++) { TrackData.Crate c = td.crates[i]; drawDec(dec(sd.crate), yawM(0.4f * i, c.x, c.y, c.z), M_STATIC, white, true, false, vp); }
        for (int b = 0; b < td.nBoxes; b++) drawDec(dec(sd.itemBox), yawM(1.7f + b, td.boxX[b], td.boxY[b], td.boxZ[b]), M_STATIC, white, true, false, vp);
        for (int i = 0; i < td.hazards.length; i++) {
            TrackData.Haz h = td.hazards[i];
            if (h.type == 1) drawDec(dec(sd.vent), yawM(0f, h.x0, h.y, h.z0), M_STATIC, white, true, false, vp);
        }
        // scenery
        for (int i = 0; i < td.scN; i++) {
            int type = td.scType[i];
            float dx = td.scX[i] - eye[0], dz = td.scZ[i] - eye[2];
            float d2 = dx * dx + dz * dz;
            float dd = Math.min(Props.DRAW[type], q_draw + 40f);
            if (d2 > dd * dd) continue;
            float s = td.scScale[i];
            float lodD = Props.LOD[type] * Math.max(1f, s * 0.6f);
            int lod = d2 > lodD * lodD ? 1 : 0;
            MeshData pm = sd.props[type][lod]; if (pm == null) continue;
            drawInst(dec(pm), td.scX[i], td.scY[i], td.scZ[i], td.scYaw[i], s, sd.scTint[i], vp, false, white);
        }
        // karts
        for (int i = 0; i < karts.size(); i++) {
            KartSpec k = karts.get(i);
            rgb(k.paintHex, 1f, paint);
            drawDec(dec(sa.bodies[k.type]), km[i][0], M_KART, white, true, false, vp);
            drawDec(dec(sa.drivers[k.driver]), km[i][1], M_KART, white, true, false, vp);
            for (int w = 0; w < 4; w++) drawDec(dec(w < 2 ? sa.wheelsF[k.type] : sa.wheelsR[k.type]), km[i][2 + w], M_KART, white, true, false, vp);
        }
        shadowOn = false;

        // ---- sky
        if (noiseTx == null) noiseTx = new Tx(sa.noise);
        float[] f = {tgt[0] - eye[0], tgt[1] - eye[1], tgt[2] - eye[2]};
        float fl = (float) Math.sqrt(f[0] * f[0] + f[1] * f[1] + f[2] * f[2]); f[0] /= fl; f[1] /= fl; f[2] /= fl;
        float[] r = {f[1] * 0 - f[2] * 1, f[2] * 0 - f[0] * 0, f[0] * 1 - f[1] * 0};   // cross(f, up)
        float rl = (float) Math.sqrt(r[0] * r[0] + r[1] * r[1] + r[2] * r[2]); r[0] /= rl; r[1] /= rl; r[2] /= rl;
        float[] u = {r[1] * f[2] - r[2] * f[1], r[2] * f[0] - r[0] * f[2], r[0] * f[1] - r[1] * f[0]};
        float tanY = (float) Math.tan(fov * MathX.DEG * 0.5f), tanX = tanY * outW / outH;
        float[] sunC = {sunCol[0] * 1.3f, sunCol[1] * 1.3f, sunCol[2] * 1.3f};
        for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) {
            int id = y * W + x;
            if (zb[id] != Float.POSITIVE_INFINITY) continue;
            float ndx = (x + 0.5f) / W * 2f - 1f, ndy = 1f - (y + 0.5f) / H * 2f;
            float dx = f[0] + r[0] * ndx * tanX + u[0] * ndy * tanY, dy = f[1] + r[1] * ndx * tanX + u[1] * ndy * tanY, dz = f[2] + r[2] * ndx * tanX + u[2] * ndy * tanY;
            float dl = (float) Math.sqrt(dx * dx + dy * dy + dz * dz); dx /= dl; dy /= dl; dz /= dl;
            float h = dy;
            float[] col = new float[3];
            for (int c = 0; c < 3; c++) col[c] = mix(horizon[c], top[c], (float) Math.pow(sat(h), 0.5));
            if (h < 0) for (int c = 0; c < 3; c++) col[c] = mix(horizon[c], fogCol[c], sat(-h * 4f));
            float sd2 = Math.max(dx * sunDir[0] + dy * sunDir[1] + dz * sunDir[2], 0f);
            float glow = (float) Math.pow(sd2, 600) * 3f + (float) Math.pow(sd2, 8) * 0.22f;
            for (int c = 0; c < 3; c++) col[c] += sunC[c] * glow;
            if (h > 0.01f) {
                float uu = dx / (h + 0.12f) * 0.55f + 0.3f, vv = dz / (h + 0.12f) * 0.55f + 0.1f;
                noiseTx.sample(uu, vv, 0f, t1); float c1 = t1[0];
                noiseTx.sample(uu * 2.7f + 3.1f, vv * 2.7f + 3.1f, 0f, t1); float c2 = t1[0];
                float cl = smooth(0.45f, 0.85f, c1 * 0.7f + c2 * 0.35f);
                float fade = smooth(0.01f, 0.22f, h);
                float dd2 = dx * sunDir[0] + dy * sunDir[1] + dz * sunDir[2];
                float cmix = sat(0.55f + 0.6f * dd2);
                float[] cc = {mix(0.62f, 1f, cmix), mix(0.66f, 1f, cmix), mix(0.74f, 1f, cmix)};
                for (int c = 0; c < 3; c++) { cc[c] = mix(cc[c], horizon[c] * 0.8f + 0.2f, 0.25f); col[c] = mix(col[c], cc[c], cl * fade * 0.85f); }
            }
            cr[id] = col[0]; cg[id] = col[1]; cb[id] = col[2];
        }

        // ---- water (blended)
        if (water) {
            for (int i = 0; i < cm.length; i++) {
                WorldMesher.ChunkMesh c = cm[i];
                if (!c.hasWater()) continue;
                float dx = c.cx - eye[0], dz = c.cz - eye[2];
                float d = (float) Math.sqrt(dx * dx + dz * dz);
                if (d - c.radius > q_draw + 60f) continue;
                int lod = d < 100f ? 0 : (d < 210f ? 1 : 2);
                final int lodF = lod;
                Dec dd = decCache.computeIfAbsent(c.widx[lod], k -> new Dec(c.wcount, c.wverts, c.widx[lodF]));
                drawDec(dd, null, M_WATER, null, false, false, vp);
            }
        }

        // ---- vignette like drawFxOverlay (uVig 0.28) and resolve
        BufferedImage img = new BufferedImage(outW, outH, BufferedImage.TYPE_INT_RGB);
        for (int y = 0; y < outH; y++) for (int x = 0; x < outW; x++) {
            float r2 = 0, g2 = 0, b2 = 0;
            for (int j = 0; j < ss; j++) for (int i = 0; i < ss; i++) { int id = (y * ss + j) * W + x * ss + i; r2 += cr[id]; g2 += cg[id]; b2 += cb[id]; }
            float k = 1f / (ss * ss);
            r2 *= k; g2 *= k; b2 *= k;
            float vx = (x + 0.5f) / outW * 2 - 1, vy = ((y + 0.5f) / outH * 2 - 1) * 0.75f;
            float vg = 1f - 0.28f * smooth(0.35f, 1.35f, (float) Math.sqrt(vx * vx + vy * vy));
            r2 *= vg; g2 *= vg; b2 *= vg;
            int ri = (int) (sat(r2) * 255 + 0.5f), gi = (int) (sat(g2) * 255 + 0.5f), bi = (int) (sat(b2) * 255 + 0.5f);
            img.setRGB(x, y, (ri << 16) | (gi << 8) | bi);
        }
        return img;
    }

    // ------------------------------------------------------------------------------------------ scenes
    static List<KartSpec> grid(TrackData td, int count) {
        List<KartSpec> l = new ArrayList<>();
        int[] types = {0, 1, 2, 3, 4, 5, 0, 3};
        for (int i = 0; i < count; i++) {
            KartSpec k = new KartSpec();
            k.type = types[i % types.length]; k.driver = i % KartModels.DRIVERS; k.paintHex = KartModels.PAINTS[i % KartModels.PAINTS.length];
            k.x = td.gridX[i]; k.y = td.gridY[i]; k.z = td.gridZ[i]; k.yaw = td.gridYaw[i];
            l.add(k);
        }
        return l;
    }

    static BufferedImage raceView(int trackId, int outW, int outH, int ss, boolean back) {
        TrackDef def = Tracks.get(trackId);
        SceneData sd = scene(def); TrackData td = sd.td;
        List<KartSpec> ks = grid(td, 8);
        KartSpec me = ks.get(0);
        float fx = (float) Math.sin(me.yaw), fz = (float) -Math.cos(me.yaw);
        float[] eye = {me.x - fx * 7.4f, me.y + 3.3f, me.z - fz * 7.4f};
        float[] tgt = {me.x + fx * 6f, me.y + 1.2f, me.z + fz * 6f};
        return render(def, eye, tgt, 64f, outW, outH, ss, ks, new float[]{me.x, me.y, me.z}, true, true);
    }

    static BufferedImage kartView(int trackId, int type, int driver, int paintIdx, int outW, int outH, int ss) {
        TrackDef def = Tracks.get(trackId);
        SceneData sd = scene(def); TrackData td = sd.td;
        KartSpec k = new KartSpec();
        k.type = type; k.driver = driver; k.paintHex = KartModels.PAINTS[paintIdx];
        k.x = td.gridX[0]; k.y = td.gridY[0]; k.z = td.gridZ[0]; k.yaw = td.gridYaw[0] + 0.5f;
        float fx = (float) Math.sin(k.yaw), fz = (float) -Math.cos(k.yaw), rx = (float) Math.cos(k.yaw), rz = (float) Math.sin(k.yaw);
        float[] eye = {k.x + fx * 3.6f + rx * 3.0f, k.y + 1.9f, k.z + fz * 3.6f + rz * 3.0f};
        float[] tgt = {k.x, k.y + 0.7f, k.z};
        return render(def, eye, tgt, 38f, outW, outH, ss, Collections.singletonList(k), new float[]{k.x, k.y, k.z}, true, false);
    }

    static BufferedImage propView(int trackId, String name, int outW, int outH, int ss, float dist, float h) {
        TrackDef def = Tracks.get(trackId);
        SceneData sd = scene(def); TrackData td = sd.td;
        int type = -1;
        try { type = (Integer) Props.class.getField(name.toUpperCase()).get(null); } catch (Exception e) { throw new RuntimeException("unknown prop " + name); }
        int pick = -1; float best = 1e9f;
        for (int i = 0; i < td.scN; i++) if (td.scType[i] == type && td.scScale[i] > 0.9f) {
            float d = (float) Math.hypot(td.scX[i] - td.gridX[0], td.scZ[i] - td.gridZ[0]);
            if (d > 25f && d < best) { best = d; pick = i; }
        }
        if (pick < 0) throw new RuntimeException("no instance");
        float px = td.scX[pick], py = td.scY[pick], pz = td.scZ[pick];
        float az = def.sunAz * MathX.DEG + 1.5f;
        float[] eye = {px + (float) Math.sin(az) * dist, py + h * 0.55f, pz + (float) Math.cos(az) * dist};
        float[] tgt = {px, py + h * 0.5f, pz};
        return render(def, eye, tgt, 42f, outW, outH, ss, new ArrayList<KartSpec>(), new float[]{px, py, pz}, true, true);
    }

    /** Close-ups of the driver (3/4 front, side, back) and of the front fender, for judging the figure. */
    static BufferedImage driverSheet(int type, int driver, int paintIdx, int tw, int th, int ss) {
        TrackDef def = Tracks.get(0);
        SceneData sd = scene(def); TrackData td = sd.td;
        KartSpec k = new KartSpec();
        k.type = type; k.driver = driver; k.paintHex = KartModels.PAINTS[paintIdx];
        k.x = td.gridX[0]; k.y = td.gridY[0]; k.z = td.gridZ[0]; k.yaw = td.gridYaw[0];
        float fx = (float) Math.sin(k.yaw), fz = (float) -Math.cos(k.yaw), rx = (float) Math.cos(k.yaw), rz = (float) Math.sin(k.yaw);
        float cy = k.y + KartModels.SEAT_Y[type] + 0.62f, cf = KartModels.SEAT_Z[type];
        float cxw = k.x + fz * 0f + fx * -cf * 0f;
        // driver centre in world: seat position along the kart's forward axis
        float sx = k.x + fx * (-KartModels.SEAT_Z[type]) * -1f, sz = k.z + fz * (-KartModels.SEAT_Z[type]) * -1f;
        float[][] views = {{0.9f, 1.0f}, {1.57f, 1.0f}, {3.14f, 0.9f}};   // azimuth relative to the kart's forward, distance factor
        BufferedImage sheet = new BufferedImage(tw * 3, th, BufferedImage.TYPE_INT_RGB);
        for (int v = 0; v < 3; v++) {
            float az = views[v][0], dist = 2.6f * views[v][1];
            // direction in kart frame: forward = (fx,fz), right = (rx,rz)
            float dx = fx * (float) Math.cos(az) + rx * (float) Math.sin(az), dz = fz * (float) Math.cos(az) + rz * (float) Math.sin(az);
            float[] tgt = {sx, cy, sz};
            float[] eye = {sx + dx * dist, cy + 0.35f, sz + dz * dist};
            BufferedImage im = render(def, eye, tgt, 36f, tw, th, ss, Collections.singletonList(k), new float[]{k.x, k.y, k.z}, true, false);
            sheet.getGraphics().drawImage(im, v * tw, 0, null);
        }
        return sheet;
    }

    public static void main(String[] a) throws Exception {
        String tag = a.length > 0 ? a[0] : "base";
        if (a.length > 1) GRADE = Integer.parseInt(a[1]);
        if (System.getProperty("sun") != null) SUN_K = Float.parseFloat(System.getProperty("sun"));
        if (System.getProperty("ambs") != null) AMBS_K = Float.parseFloat(System.getProperty("ambs"));
        if (System.getProperty("ambg") != null) AMBG_K = Float.parseFloat(System.getProperty("ambg"));
        String what = a.length > 2 ? a[2] : "race0";
        long t0 = System.currentTimeMillis();
        if (what.startsWith("race")) {
            int tr = Integer.parseInt(what.substring(4));
            ImageIO.write(raceView(tr, 1280, 720, 2, false), "png", new File("prev_" + tag + "_race" + tr + ".png"));
        } else if (what.startsWith("prop:")) {
            String[] pp = what.split(":");
            float dist = pp.length > 3 ? Float.parseFloat(pp[3]) : 16f, hh = pp.length > 4 ? Float.parseFloat(pp[4]) : 9f;
            ImageIO.write(propView(Integer.parseInt(pp[1]), pp[2], 1000, 700, 2, dist, hh), "png", new File("prev_" + tag + "_prop_" + pp[2] + ".png"));
        } else if (what.startsWith("driver")) {
            int ty = what.length() > 6 ? Integer.parseInt(what.substring(6)) : 0;
            ImageIO.write(driverSheet(ty, ty, ty, 560, 640, 2), "png", new File("prev_" + tag + "_driver" + ty + ".png"));
        } else if (what.startsWith("cmp")) {
            int tr = Integer.parseInt(what.substring(3));
            float[][] vars = {{1, 0.85f, 0.52f, 0.45f}, {3, 0.85f, 0.52f, 0.45f}, {3, 1.00f, 0.44f, 0.38f}, {3, 1.08f, 0.38f, 0.32f}};
            int tw = 640, th = 360;
            BufferedImage sheet = new BufferedImage(tw * 2, th * 2, BufferedImage.TYPE_INT_RGB);
            for (int i = 0; i < 4; i++) {
                GRADE = (int) vars[i][0]; SUN_K = vars[i][1]; AMBS_K = vars[i][2]; AMBG_K = vars[i][3];
                BufferedImage im = raceView(tr, tw, th, 3, false);
                sheet.getGraphics().drawImage(im, (i % 2) * tw, (i / 2) * th, null);
            }
            ImageIO.write(sheet, "png", new File("prev_" + tag + "_cmp" + tr + ".png"));
        } else if (what.equals("karts")) {
            int tw = 640, th = 400;
            BufferedImage sheet = new BufferedImage(tw * 3, th * 2, BufferedImage.TYPE_INT_RGB);
            for (int t = 0; t < 6; t++) {
                BufferedImage im = kartView(0, t, t, t, tw, th, 2);
                sheet.getGraphics().drawImage(im, (t % 3) * tw, (t / 3) * th, null);
            }
            ImageIO.write(sheet, "png", new File("prev_" + tag + "_karts.png"));
        }
        System.out.println(what + " done in " + (System.currentTimeMillis() - t0) + " ms");
    }
}
