Software preview renderer used to check the graphics without a phone. See the comment at the top of Soft.java for how to run it.
It is not compiled by Gradle (it lives outside app/src).
