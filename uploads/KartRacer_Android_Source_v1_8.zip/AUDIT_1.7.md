# Kart Racer 1.7 graphics audit (realistic look)

## What was asked

"Only the map, the car and the character are so bad, and the trees still look bad, so cartoon-like." The goal of 1.7 is a more realistic look for those four things.

## How it was checked

The CPU preview renderer in `tools/preview/Soft.java` draws the real track, prop and kart meshes with the real procedural textures and a Java port of the lit, sky and water shaders. Every change below was rendered and looked at. It is an approximation: no anti-aliasing, a simple shadow map, no GPU filtering. It cannot show your phone's resolution, frame rate or automatic quality state. The GLSL changes were **not** compiled on a GPU and nothing was run on a device.

## Findings and changes

1. **Foliage was unlit (the main reason the trees looked like cartoons).** In the instanced-prop vertex shader any vertex alpha of 128 or more means "emissive", and palm fronds and jungle canopies used alpha 150 to 200 for their sway weight. In the fragment shader emissive means flat `albedo * 1.2`, so all swaying foliage ignored the sun. Now vertex alpha above 128 with a sway weight is "foliage": lit by the sun with light also coming through from behind (0.4 of the back side), sky light under the leaves, and shadows. Only alpha exactly 128 (torch flames, lighthouse lamp) stays emissive.
2. **Trees.** The palm had a few flat paddle blades and the jungle tree was a lollipop of smooth blobs. New palm: 20 trunk rings with a root flare, 14 fronds of 16 leaflet pairs (double sided, lit from the top face, darker underneath), crown shaft, coconuts, hanging dead fronds; far version is a simplified feathered ribbon. New jungle tree: buttress roots, three trunk segments, five limbs, 22 lumpy foliage clumps whose normals point away from the canopy centre so the tree shades as one soft mass, lianas. New bush with flowers, new grass tuft with 11 thin blades.
3. **Driver.** The old driver was a cartoon child (head radius 0.30 with a face, big ears). New: fire suit with stripe band and number patch, harness, neck restraint, gloves, full face helmet (glossy shell in the kart's paint colour, dark visor, stripe, chin vent, rear wing).
4. **Car parts.** Tyres with curved side walls, rounded shoulders and road grooves or off-road lugs; alloy rims with 10 spokes (6 on the off-road karts), polished lip, brake disc and caliper, lug nuts; projector headlamps; LED tail lamps; stainless exhaust with heat tint; bucket seat; flat-bottom steering wheel with carbon hub; the toy antenna was removed. Paint shader: tight clear-coat glint plus a sky reflection that gets stronger at grazing angles (only on painted parts).
5. **Map.** Neon greens and yellows were replaced by natural ones (olive grass with straw patches, sand, cooler basalt); grade saturation 1.22 to 1.08 and contrast curve 0.40 to 0.32 (1.6 had pushed it further from realistic). Asphalt now has hairline cracks, a repaired patch and dust at the edges.
6. **Culling radii** for palm (7 to 9) and jungle tree (7 to 11) were raised because the new trees are bigger. They are only used for view culling.

## Cost (performance)

Measured triangle counts: palm 2060 near / 454 far (before about 700 / 140), jungle tree 1504 near / 138 far, bush 580 / 36, tuft 22 / 10. A kart is now about 4.3k body + 4 x 1.6k wheels + 2.2k driver = about 13k triangles (before about 11k). The near versions are used within 55 m (palm) and 60 m (jungle tree). This is heavier than 1.6 but modest; if a phone struggles, the automatic quality still reacts at about 38 fps.

## Honest limits

* **The car bodies are the same shapes as before.** Their rounded fenders and pod bodies are still stylized. Making them look like real cars means remodelling each of the six bodies. That is a separate job; tell me which kart you use most and I will do that one first.
* The base look was already a stylized low-poly scene; 1.7 moves it toward realistic but it is not photorealistic (no real foliage textures, no normal maps, no reflections of the scene, no bloom).
* The ground textures are procedural. Real photo textures would need image files in the project.

## Verification status

| Part | Status |
|---|---|
| `util`, `world`, `sim`, `net`, `gfx` (models, textures, terrain) | compiled and run headless, all four scenes built and rendered in the preview |
| Android files and GLSL | **not compiled / not run**. The before / after compiler comparison without the SDK shows no syntax errors and no new errors except unresolved Android classes; the shader edits keep the existing style (all four programs share one vertex and one fragment shader, so the new varying links everywhere) |
| Behaviour on a device | **not run** |

If the GitHub build turns red, send the red error text. If the picture looks wrong on the phone (black, strange colours, missing trees), tell me which track and send a screenshot.

## Files changed since 1.6

- `README.md`
- `app/build.gradle`
- `app/src/main/java/com/kartracer/gfx/KartModels.java`
- `app/src/main/java/com/kartracer/gfx/ObjModels.java`
- `app/src/main/java/com/kartracer/gfx/PropModels.java`
- `app/src/main/java/com/kartracer/gfx/TexGen.java`
- `app/src/main/java/com/kartracer/gl/Shaders.java`
- `app/src/main/java/com/kartracer/world/Props.java`
- `app/src/main/java/com/kartracer/world/Terrain.java`
- `tools/preview/Soft.java`
