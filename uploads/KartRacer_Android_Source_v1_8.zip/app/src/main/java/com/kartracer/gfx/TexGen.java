package com.kartracer.gfx;

import com.kartracer.util.Col;
import com.kartracer.util.MathX;
import com.kartracer.util.Noise;

/** Procedural textures as RGBA bytes. Small, tileable, mipmapped on upload. */
public final class TexGen {
    private TexGen() {}

    public static final class Tex {
        public final int w, h;
        public final byte[] rgba;
        /** Optional ETC2 compressed mip chain (see Etc), built on a worker thread. */
        public Etc.Level[] etcChain;
        Tex(int w, int h) { this.w = w; this.h = h; rgba = new byte[w * h * 4]; }

        /** Builds the compressed mip chain once (textures of at least 16x16 pixels). */
        public Tex compress() {
            if (etcChain == null && w >= 16 && h >= 16) etcChain = Etc.buildChain(rgba, w, h);
            return this;
        }
        void set(int x, int y, int r, int g, int b, int a) {
            int o = (y * w + x) * 4;
            rgba[o] = (byte) MathX.clamp(r, 0, 255); rgba[o + 1] = (byte) MathX.clamp(g, 0, 255);
            rgba[o + 2] = (byte) MathX.clamp(b, 0, 255); rgba[o + 3] = (byte) MathX.clamp(a, 0, 255);
        }
    }

    public static Tex white() {
        Tex t = new Tex(1, 1);
        t.set(0, 0, 255, 255, 255, 255);
        return t;
    }

    private static float fbmTile(float u, float v, int baseCells, int octaves, int seed) {
        float sum = 0f, amp = 0.5f, norm = 0f;
        int cells = baseCells;
        for (int i = 0; i < octaves; i++) {
            sum += Noise.tile(u * cells, v * cells, cells, seed + i * 13) * amp;
            norm += amp; amp *= 0.5f; cells *= 2;
        }
        return sum / norm;
    }

    /**
     * Gray detail multiplier (mean about 0.9). It is laid over the ground at 8 m per tile (and again, larger, at about 22 m), so the features are
     * chosen for that scale: broad mottling, patches 0.3 to 0.5 m across that read as ground texture from the driving camera, fine grain and a few flecks.
     */
    public static Tex detail(int size) {   // used at 256 px
        Tex t = new Tex(size, size);
        for (int y = 0; y < size; y++) for (int x = 0; x < size; x++) {
            float u = x / (float) size, v = y / (float) size;
            float macro = fbmTile(u, v, 4, 3, 5);
            float meso = fbmTile(u, v, 16, 3, 17);
            float grain = Noise.tile(u * 128, v * 128, 128, 29);
            float speck = Noise.hash(x, y, 41);
            float sh = 0.90f + 0.22f * (macro - 0.5f) + 0.30f * (meso - 0.5f) + 0.12f * (grain - 0.5f) + 0.08f * (speck - 0.5f);
            float fleck = Noise.hash(x >> 1, y >> 1, 53);
            if (fleck > 0.986f) sh *= 0.76f; else if (fleck < 0.010f) sh *= 1.10f;
            int g = (int) (255f * MathX.sat(sh));
            t.set(x, y, g, g, g, 255);
        }
        return t;
    }

    /** Cloud / generic noise in all channels. */
    public static Tex noise(int size) {
        Tex t = new Tex(size, size);
        for (int y = 0; y < size; y++) for (int x = 0; x < size; x++) {
            float n = fbmTile(x / (float) size, y / (float) size, 4, 5, 9);
            int v = (int) (255f * MathX.sat((n - 0.25f) * 1.6f));
            t.set(x, y, v, v, v, 255);
        }
        return t;
    }

    private static int mixRgb(int a, int b, float k) {
        int r = (int) (((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * k);
        int g = (int) (((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * k);
        int bl = (int) ((a & 255) + ((b & 255) - (a & 255)) * k);
        return (r << 16) | (g << 8) | bl;
    }

    private static void put(Tex t, int x, int y, int rgb, float shade) {
        t.set(x, y, (int) (((rgb >> 16) & 255) * shade), (int) (((rgb >> 8) & 255) * shade), (int) ((rgb & 255) * shade), 255);
    }

    /** Tileable cellular noise: {distance to the nearest point, distance to the second nearest, random id of the nearest cell}. */
    private static float[] voronoi(float x, float y, int px, int py, int seed) {
        int ix = (int) Math.floor(x), iy = (int) Math.floor(y);
        float f1 = 9f, f2 = 9f, id = 0f;
        for (int j = -1; j <= 1; j++) for (int i = -1; i <= 1; i++) {
            int cx = ix + i, cy = iy + j;
            int hx = Math.floorMod(cx, px), hy = Math.floorMod(cy, py);
            float ox = cx + 0.15f + 0.7f * Noise.hash(hx, hy, seed), oy = cy + 0.15f + 0.7f * Noise.hash(hx, hy, seed + 1);
            float dx = ox - x, dy = oy - y;
            float d = (float) Math.sqrt(dx * dx + dy * dy);
            if (d < f1) { f2 = f1; f1 = d; id = Noise.hash(hx, hy, seed + 2); } else if (d < f2) f2 = d;
        }
        return new float[]{f1, f2, id};
    }

    /** Road strip: u across (shoulder | edge line | road | edge line | shoulder), v along (12 m per tile). */
    public static Tex road(int theme) {
        int S = 512;   // 32 pixels per metre across the road, so the lines and rumble strips stay crisp
        Tex t = new Tex(S, S);
        int base, line, dash, shoulder;
        boolean lines = true, dashes = true, cracks = false, ruts = false;
        switch (theme) {
            case 1: base = 0xA67C52; line = 0x8A6840; dash = 0xB89060; shoulder = 0x6E6240; lines = false; dashes = false; ruts = true; break;
            case 2: base = 0x4A454D; line = 0xFFA028; dash = 0xFFA028; shoulder = 0x5A5152; cracks = true; dashes = false; break;
            case 3: base = 0xC49668; line = 0xF2EADA; dash = 0xF2EADA; shoulder = 0xD8B078; break;
            default: base = 0x5C5C62; line = 0xF4F4F4; dash = 0xF0C83C; shoulder = 0xDCC896; break;
        }
        for (int y = 0; y < S; y++) for (int x = 0; x < S; x++) {
            float u = x / (float) S, v = y / (float) S;
            float n = fbmTile(u, v, 8, 4, 31);
            float fine = Noise.tile(u * 64, v * 64, 64, 77);
            float grain = Noise.tile(u * 192, v * 192, 192, 91);   // asphalt / gravel grain
            int rgb; float emisA = 0f; float shade = 0.86f + 0.28f * n + 0.06f * fine + 0.10f * (grain - 0.5f);
            float edgeU = Math.min(u, 1f - u);
            if (lines && theme != 1 && edgeU >= 0.11f && edgeU < 0.17f) {
                // rumble strips along both road edges
                boolean even = (((int) (v * 16f)) & 1) == 0;
                rgb = theme == 2 ? (even ? 0xFFA028 : 0x1E1A1E) : (even ? 0xD8322E : 0xF4F4F4);
                shade = 0.93f + 0.1f * fine - (n < 0.3f ? 0.12f : 0f);
            } else if (u < 0.14f || u > 0.86f) {
                rgb = shoulder; shade = 0.8f + 0.35f * n;
            } else if (lines && (u < 0.17f || u > 0.83f)) {
                rgb = line; shade = 0.9f + 0.1f * fine - (n < 0.35f ? 0.2f : 0f);
            } else {
                rgb = base;
                float rut = ruts ? Math.max(0f, 1f - Math.abs(u - 0.33f) / 0.06f) + Math.max(0f, 1f - Math.abs(u - 0.67f) / 0.06f) : 0.35f * (Math.max(0f, 1f - Math.abs(u - 0.33f) / 0.07f) + Math.max(0f, 1f - Math.abs(u - 0.67f) / 0.07f));
                shade *= 1f - 0.18f * rut;
                if (ruts) {
                    shade *= 1f + 0.12f * Math.max(0f, 1f - Math.abs(u - 0.5f) / 0.08f);
                    float peb = Noise.tile(u * 96, v * 96, 96, 113);   // pebbles and mud patches in the dirt
                    if (peb > 0.86f) shade *= 1.16f; else if (peb < 0.14f) shade *= 0.86f;
                } else {
                    float stain = MathX.smooth(0.70f, 0.90f, fbmTile(u, v, 4, 2, 211));   // darker oil / rubber patches
                    shade *= 1f - 0.12f * stain;
                    // ageing: hairline cracks, a repaired patch and dust blown in from the edges
                    float crack = Noise.tile(u * 24f, v * 24f, 24, 83);
                    if (Math.abs(crack - 0.5f) < 0.008f) shade *= 0.72f;
                    float patch = MathX.smooth(0.74f, 0.80f, fbmTile(u, v, 3, 2, 87));
                    shade *= 1f - 0.10f * patch;
                    float edge = Math.min(u - 0.14f, 0.86f - u);
                    if (edge < 0.10f) shade *= 1f + 0.10f * (1f - Math.max(0f, edge) / 0.10f) * (Noise.hash(x >> 1, y >> 1, 89) > 0.45f ? 1f : 0.4f);
                    // pixel level speckle and a few light / dark stone chips: gives the asphalt real texture close up and a shimmer that sells the speed far away
                    shade *= 1f + 0.16f * (Noise.hash(x, y, 17) - 0.5f);
                    float chip = Noise.hash(x >> 1, y >> 1, 29);
                    if (chip > 0.965f) shade *= 1.22f; else if (chip < 0.03f) shade *= 0.78f;
                }
                if (dashes && Math.abs(u - 0.5f) < 0.011f && ((v * 2f) % 1f) < 0.5f) { rgb = dash; shade = 1f; }
                if (cracks) {
                    // irregular basalt slabs separated by cracks; the glow comes and goes along the cracks and is emissive (alpha channel)
                    float uu = (u - 0.14f) / 0.72f;
                    float[] vc = voronoi(uu * 5f, v * 6f, 5, 6, 301);
                    float gap = vc[1] - vc[0];
                    shade *= (0.78f + 0.42f * vc[2]) * (0.70f + 0.30f * MathX.smooth(0f, 0.25f, gap));
                    if (gap < 0.11f) {
                        float g = MathX.smooth(0.38f, 0.62f, fbmTile(u, v, 6, 2, 133));
                        float core = MathX.smooth(0.11f, 0.02f, gap);
                        float glow = g * (0.25f + 0.75f * core);
                        rgb = mixRgb(0x1C1012, 0xFF7A1C, MathX.sat(glow * 1.15f));
                        shade = 0.55f + 0.45f * MathX.sat(glow * 1.6f);
                        emisA = glow;
                    }
                }
            }
            put(t, x, y, rgb, shade);
            if (emisA > 0.01f) t.rgba[(y * S + x) * 4 + 3] = (byte) (255 - (int) (255f * MathX.sat(emisA)));
        }
        return t;
    }

    public static Tex dirt() {
        int S = 256;
        Tex t = new Tex(S, S);
        for (int y = 0; y < S; y++) for (int x = 0; x < S; x++) {
            float u = x / (float) S, v = y / (float) S;
            float n = fbmTile(u, v, 8, 3, 47) + 0.06f * (Noise.tile(u * 96, v * 96, 96, 51) - 0.5f);
            float rut = Math.max(0f, 1f - Math.abs(u - 0.33f) / 0.06f) + Math.max(0f, 1f - Math.abs(u - 0.67f) / 0.06f);
            float shade = (0.88f + 0.3f * n) * (1f - 0.18f * rut);
            shade *= 1f + 0.14f * (Noise.hash(x, y, 61) - 0.5f);
            float peb = Noise.tile(u * 64, v * 64, 64, 67);
            if (peb > 0.88f) shade *= 1.14f; else if (peb < 0.12f) shade *= 0.84f;
            if (u < 0.14f || u > 0.86f) shade *= 1.05f;
            put(t, x, y, 0xB08A5E, shade);
        }
        return t;
    }
}
