package com.kartracer.gfx;

/** Graphics quality presets. */
public final class Quality {
    public int shadowSize;      // 0 = blob shadows only
    public boolean pcf;         // 4 tap shadow filter
    public float renderScale;   // 0.5 .. 1
    public float drawDist;      // meters
    public int particleCap;
    public boolean waterWaves = true;
    public float terrainLodNear, terrainLodFar;
    public float propDensity = 1f;

    public static final String[] NAMES = {"Low", "Medium", "High"};

    public static Quality preset(int level) {
        Quality q = new Quality();
        switch (level) {
            case 0:
                q.shadowSize = 0; q.pcf = false; q.renderScale = 0.85f; q.drawDist = 260f; q.particleCap = 450;
                q.waterWaves = false; q.terrainLodNear = 75f; q.terrainLodFar = 160f; q.propDensity = 0.7f; break;
            case 1:
                q.shadowSize = 1024; q.pcf = true; q.renderScale = 1f; q.drawDist = 360f; q.particleCap = 1000;
                q.terrainLodNear = 100f; q.terrainLodFar = 210f; q.propDensity = 0.9f; break;
            default:
                q.shadowSize = 2048; q.pcf = true; q.renderScale = 1f; q.drawDist = 480f; q.particleCap = 1600;
                q.terrainLodNear = 125f; q.terrainLodFar = 260f; q.propDensity = 1f; break;
        }
        return q;
    }
}
