package com.kartracer.gl;

import android.opengl.GLES30;
import android.opengl.GLSurfaceView;

import com.kartracer.app.ItemArt;
import com.kartracer.app.Settings;
import com.kartracer.audio.Sfx;
import com.kartracer.audio.Snd;
import com.kartracer.gfx.CameraRig;
import com.kartracer.gfx.Fx;
import com.kartracer.gfx.HudData;
import com.kartracer.gfx.KartModels;
import com.kartracer.gfx.MeshData;
import com.kartracer.gfx.Quality;
import com.kartracer.gfx.SceneData;
import com.kartracer.gfx.StaticAssets;
import com.kartracer.gfx.WorldMesher;
import com.kartracer.sim.FxEvents;
import com.kartracer.sim.Kart;
import com.kartracer.sim.PlayerInput;
import com.kartracer.sim.Race;
import com.kartracer.util.Diag;
import com.kartracer.util.Mat4;
import com.kartracer.util.MathX;
import com.kartracer.world.Props;
import com.kartracer.world.TrackData;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.concurrent.ConcurrentLinkedQueue;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/** OpenGL ES 3.0 renderer and game loop driver. Everything except post()/volatile setters runs on the GL thread. */
public final class GameRenderer implements GLSurfaceView.Renderer {
    public interface Host {
        void onSceneReady();
        void onStats(int fps, float frameMs);
        void onError(String message);
        void suggestRenderScale(float scale);
    }

    public final PlayerInput input = new PlayerInput();
    public final HudData hud = new HudData();
    private final Settings settings;
    private final Host host;
    private final ConcurrentLinkedQueue<Runnable> cmds = new ConcurrentLinkedQueue<Runnable>();

    // menu showcase
    private volatile int menuKart, menuPaint, menuDriver;
    private volatile float menuShift = 0.28f;
    private float menuShiftCur = Float.NaN;   // GL thread only: the shift actually drawn (eased toward menuShift)
    private volatile boolean menuKartVisible = true;
    private volatile float menuYawOffset;

    // GL objects
    private boolean glReady;
    private GlUtil.Prog pStatic, pInst, pKart, pPad, pShadow, pShadowInst, pWater, pSky, pParticle, pDecal, pFx;
    private GlTex tWhite, tDetail, tNoise;
    private ShadowMap shadow;
    private GlMesh[] bodies, wheelsF, wheelsR, drivers;
    private GlMesh mRocket, mCoconut, mSlick;
    private int vaoEmpty, pVao, pQuadVbo, pInstVbo, dVaoSkid, dVboSkid, dVaoBlob, dVboBlob;
    private FloatBuffer pFb, skidFb, blobFb;
    private float[] pBuf = new float[8];

    // scene / game
    private SceneData sceneData;
    private volatile SceneGfx scene;
    private Race race;
    private Fx fx;
    private final CameraRig cam = new CameraRig();
    private Quality q = Quality.preset(1);
    private int appliedQuality = -1;
    private boolean shadowsOn;
    private int width = 1, height = 1;

    // timing
    private long lastNs, fpsT0;
    private float time;
    private int frames;
    private float accMs;
    private long lastScaleChange;
    private int autoStep;
    private long lastErrLog;

    // matrices
    private final float[] view = new float[16], proj = new float[16], vp = new float[16], planes = new float[24];
    private final float[] lightView = new float[16], lightProj = new float[16], lightVP = new float[16], shadowMat = new float[16];
    private final float[] bias = new float[16], ident = new float[16], m1 = new float[16], m2 = new float[16], m3 = new float[16];
    private final float[][] kBody = new float[8][16], kDrv = new float[8][16];
    private final float[][][] kWheel = new float[8][4][16];
    private final boolean[] kVis = new boolean[8];
    private final int[] kType = new int[8], kPaint = new int[8], kDriver = new int[8];
    private final float[] kFlash = new float[8];
    private final float[] hzp = new float[2];
    private int menuKartCount;

    public GameRenderer(Settings settings, Host host) {
        this.settings = settings;
        this.host = host;
        Mat4.identity(ident);
        for (int i = 0; i < 16; i++) bias[i] = 0f;
        bias[0] = bias[5] = bias[10] = 0.5f; bias[12] = bias[13] = bias[14] = 0.5f; bias[15] = 1f;
    }

    // ---------------------------------------------------------------- thread safe API

    public void post(Runnable r) { cmds.add(r); }

    public void setMenuKart(int kart, int paint, int driver) { menuKart = kart; menuPaint = paint; menuDriver = driver; }
    public void setMenuShift(float s) { menuShift = s; }
    public void setMenuKartVisible(boolean v) { menuKartVisible = v; }
    public void setMenuYawOffset(float a) { menuYawOffset = a; }

    /** GL thread only (call through post). */
    public void setScene(SceneData sd) {
        race = null;
        if (scene != null) scene.release();
        scene = null;
        sceneData = sd;
        if (glReady) buildScene();
    }

    public void setRace(Race r) {
        race = r;
        cam.reset();
        if (glReady) newFx();
        hud.active = r != null;
        sfxCountN = 99; sfxGo = false; sfxWasWrong = false;
    }

    public void clearRace() { race = null; hud.active = false; if (fx != null) fx.reset(); silence(); }

    public Race race() { return race; }
    public boolean hasScene() { return scene != null; }

    // ---------------------------------------------------------------- GL lifecycle

    @Override
    public void onSurfaceCreated(GL10 unused, EGLConfig config) {
        try {
            Diag.log("GL", "surface created: " + GLES30.glGetString(GLES30.GL_RENDERER) + " | " + GLES30.glGetString(GLES30.GL_VERSION));
            createGlObjects();
            glReady = true;
            if (sceneData != null) buildScene();
        } catch (Throwable t) {
            Diag.err("GL", "init failed", t);
            glReady = false;
            host.onError("Graphics initialisation failed: " + t.getMessage());
        }
    }

    @Override
    public void onSurfaceChanged(GL10 unused, int w, int h) {
        width = Math.max(1, w);
        height = Math.max(1, h);
        Diag.log("GL", "surface size " + w + "x" + h);
    }

    private void createGlObjects() {
        shadow = null;
        pVao = 0; pQuadVbo = 0; pInstVbo = 0;
        pStatic = GlUtil.program("static", Shaders.LIT_VS, Shaders.LIT_FS, "");
        pInst = GlUtil.program("instanced", Shaders.LIT_VS, Shaders.LIT_FS, "#define INSTANCED\n");
        pKart = GlUtil.program("kart", Shaders.LIT_VS, Shaders.LIT_FS, "#define KART\n");
        pPad = GlUtil.program("pad", Shaders.LIT_VS, Shaders.LIT_FS, "#define PAD\n");
        pShadow = GlUtil.program("shadow", Shaders.SHADOW_VS, Shaders.SHADOW_FS, "");
        pShadowInst = GlUtil.program("shadowInst", Shaders.SHADOW_VS, Shaders.SHADOW_FS, "#define INSTANCED\n");
        pWater = GlUtil.program("water", Shaders.WATER_VS, Shaders.WATER_FS, "");
        pSky = GlUtil.program("sky", Shaders.SKY_VS, Shaders.SKY_FS, "");
        pParticle = GlUtil.program("particle", Shaders.PARTICLE_VS, Shaders.PARTICLE_FS, "");
        pDecal = GlUtil.program("decal", Shaders.DECAL_VS, Shaders.DECAL_FS, "");
        try {
            pFx = GlUtil.program("fx", Shaders.FX_VS, Shaders.FX_FS, "");
        } catch (Throwable t) {
            pFx = null;   // the screen overlay is only decoration: the game runs fine without it
            Diag.err("GL", "screen overlay shader unavailable", t);
        }
        StaticAssets sa = StaticAssets.get();
        tWhite = new GlTex(sa.white); tWhite.upload();
        tDetail = new GlTex(sa.detail); tDetail.upload();
        tNoise = new GlTex(sa.noise); tNoise.upload();
        bodies = new GlMesh[KartModels.TYPES]; wheelsF = new GlMesh[KartModels.TYPES]; wheelsR = new GlMesh[KartModels.TYPES];
        for (int i = 0; i < KartModels.TYPES; i++) {
            bodies[i] = new GlMesh(sa.bodies[i], 0); bodies[i].upload();
            wheelsF[i] = new GlMesh(sa.wheelsF[i], 0); wheelsF[i].upload();
            wheelsR[i] = new GlMesh(sa.wheelsR[i], 0); wheelsR[i].upload();
        }
        drivers = new GlMesh[KartModels.DRIVERS];
        for (int i = 0; i < KartModels.DRIVERS; i++) { drivers[i] = new GlMesh(sa.drivers[i], 0); drivers[i].upload(); }
        mRocket = new GlMesh(sa.rocket, 0); mRocket.upload();
        mCoconut = new GlMesh(sa.coconut, 0); mCoconut.upload();
        mSlick = new GlMesh(sa.slick, 0); mSlick.upload();
        int[] id = new int[1];
        GLES30.glGenVertexArrays(1, id, 0); vaoEmpty = id[0];
        setupParticleBuffers(2000);
        setupDecalBuffers();
        appliedQuality = -1;
        applyQuality();
        GlUtil.checkError("createGlObjects");
    }

    private void setupParticleBuffers(int cap) {
        int[] id = new int[1];
        if (pVao == 0) { GLES30.glGenVertexArrays(1, id, 0); pVao = id[0]; GLES30.glGenBuffers(1, id, 0); pQuadVbo = id[0]; GLES30.glGenBuffers(1, id, 0); pInstVbo = id[0]; }
        float[] quad = {-1, -1, 1, -1, -1, 1, 1, 1};
        FloatBuffer qb = ByteBuffer.allocateDirect(32).order(ByteOrder.nativeOrder()).asFloatBuffer();
        qb.put(quad); qb.position(0);
        GLES30.glBindVertexArray(pVao);
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, pQuadVbo);
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, 32, qb, GLES30.GL_STATIC_DRAW);
        GLES30.glEnableVertexAttribArray(0); GLES30.glVertexAttribPointer(0, 2, GLES30.GL_FLOAT, false, 8, 0);
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, pInstVbo);
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, cap * 32, null, GLES30.GL_STREAM_DRAW);
        GLES30.glEnableVertexAttribArray(1); GLES30.glVertexAttribPointer(1, 4, GLES30.GL_FLOAT, false, 32, 0); GLES30.glVertexAttribDivisor(1, 1);
        GLES30.glEnableVertexAttribArray(2); GLES30.glVertexAttribPointer(2, 4, GLES30.GL_FLOAT, false, 32, 16); GLES30.glVertexAttribDivisor(2, 1);
        GLES30.glBindVertexArray(0);
        pFb = ByteBuffer.allocateDirect(cap * 32).order(ByteOrder.nativeOrder()).asFloatBuffer();
        pBuf = new float[cap * 8];
    }

    private void setupDecalBuffers() {
        int[] id = new int[1];
        GLES30.glGenVertexArrays(1, id, 0); dVaoSkid = id[0];
        GLES30.glGenBuffers(1, id, 0); dVboSkid = id[0];
        GLES30.glGenVertexArrays(1, id, 0); dVaoBlob = id[0];
        GLES30.glGenBuffers(1, id, 0); dVboBlob = id[0];
        int skidBytes = Fx.SKID_CAP * 6 * Fx.DECAL_FLOATS * 4, blobBytes = 8 * 6 * Fx.DECAL_FLOATS * 4;
        decalVao(dVaoSkid, dVboSkid, skidBytes);
        decalVao(dVaoBlob, dVboBlob, blobBytes);
        skidFb = ByteBuffer.allocateDirect(skidBytes).order(ByteOrder.nativeOrder()).asFloatBuffer();
        blobFb = ByteBuffer.allocateDirect(blobBytes).order(ByteOrder.nativeOrder()).asFloatBuffer();
    }

    private void decalVao(int vao, int vbo, int bytes) {
        GLES30.glBindVertexArray(vao);
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vbo);
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, bytes, null, GLES30.GL_STREAM_DRAW);
        int s = Fx.DECAL_FLOATS * 4;
        GLES30.glEnableVertexAttribArray(0); GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, s, 0);
        GLES30.glEnableVertexAttribArray(1); GLES30.glVertexAttribPointer(1, 2, GLES30.GL_FLOAT, false, s, 12);
        GLES30.glEnableVertexAttribArray(2); GLES30.glVertexAttribPointer(2, 1, GLES30.GL_FLOAT, false, s, 20);
        GLES30.glEnableVertexAttribArray(3); GLES30.glVertexAttribPointer(3, 1, GLES30.GL_FLOAT, false, s, 24);
        GLES30.glBindVertexArray(0);
    }

    /** Picks the quality preset from settings and (re)creates quality dependent objects. */
    public void applyQuality() {
        if (!glReady) return;
        Quality nq = Quality.preset(settings.quality);
        if (!settings.shadows) nq.shadowSize = 0;
        if (settings.scalePct > 0) nq.renderScale = settings.scalePct / 100f;
        int want = nq.shadowSize == 0 ? 16 : nq.shadowSize;
        if (shadow == null || shadow.size != want) {
            if (shadow != null) shadow.release();
            shadow = new ShadowMap();
            shadow.create(want);
        }
        boolean changedCap = q == null || q.particleCap != nq.particleCap;
        q = nq;
        shadowsOn = q.shadowSize > 0 && shadow.ok;
        if (changedCap) newFx();
        appliedQuality = settings.quality * 10 + (settings.shadows ? 1 : 0);
        host.suggestRenderScale(q.renderScale);
    }

    private void newFx() { fx = new Fx(Math.max(200, q.particleCap)); }

    private void buildScene() {
        try {
            scene = new SceneGfx(sceneData);
            scene.upload();
            Diag.log("GL", "scene uploaded: " + sceneData.td.def.name + ", chunks=" + sceneData.chunks.length + ", props=" + sceneData.td.scN);
            GlUtil.checkError("buildScene");
            host.onSceneReady();
        } catch (Throwable t) {
            Diag.err("GL", "scene upload failed", t);
            scene = null;
            host.onError("Could not upload the track to the GPU: " + t.getMessage());
        }
    }

    // ---------------------------------------------------------------- frame

    @Override
    public void onDrawFrame(GL10 unused) {
        long t0 = System.nanoTime();
        Runnable r;
        while ((r = cmds.poll()) != null) {
            try { r.run(); } catch (Throwable e) { Diag.err("GL", "command failed", e); }
        }
        if (!glReady) {
            GLES30.glClearColor(0.05f, 0.08f, 0.15f, 1f);
            GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT);
            return;
        }
        if (appliedQuality != settings.quality * 10 + (settings.shadows ? 1 : 0)) applyQuality();
        float dt = lastNs == 0 ? 0.016f : (t0 - lastNs) / 1e9f;
        lastNs = t0;
        dt = MathX.clamp(dt, 0.001f, 0.05f);
        time += dt;
        try {
            frame(dt);
        } catch (Throwable e) {
            long now = System.currentTimeMillis();
            if (now - lastErrLog > 2000) { lastErrLog = now; Diag.err("GL", "frame failed", e); }
        }
        // stats and adaptive resolution
        frames++;
        accMs += dt * 1000f;
        if (t0 - fpsT0 > 1000000000L) {
            int fps = frames;
            float avg = accMs / Math.max(1, frames);
            hud.fps = fps;
            host.onStats(fps, avg);
            adapt(avg);
            frames = 0; accMs = 0f; fpsT0 = t0;
        }
        if (settings.fpsCap <= 30) {
            long el = System.nanoTime() - t0;
            long target = 33000000L;
            if (el < target) { try { Thread.sleep((target - el) / 1000000L); } catch (InterruptedException ignored) { } }
        }
    }

    private void adapt(float avgMs) {
        if (!settings.autoQuality || race == null || race.phase == Race.PH_COUNTDOWN) return;
        long now = System.currentTimeMillis();
        // Only react to a clearly struggling frame rate (about 38 fps for a 60 fps target), and keep the picture sharp and shadowed for as long
        // as possible: a little resolution first, then the soft shadow filter, a bit more resolution and only as a last resort the shadows.
        // (Before 1.6 it reacted at about 47 fps and went down to 60 % resolution, which left many phones permanently blurry.)
        float limit = settings.fpsCap <= 30 ? 40f : 26f;
        if (avgMs > limit && now - lastScaleChange > 5000) {
            lastScaleChange = now;
            autoStep++;
            if (q.renderScale > 0.9f) { q.renderScale = 0.88f; host.suggestRenderScale(q.renderScale); }
            else if (q.pcf) q.pcf = false;
            else if (q.renderScale > 0.8f) { q.renderScale = 0.78f; host.suggestRenderScale(q.renderScale); }
            else if (shadowsOn) shadowsOn = false;
            Diag.log("GL", "auto quality step " + autoStep + ": avg frame " + avgMs + " ms -> scale " + q.renderScale + " shadows " + shadowsOn);
        }
    }

    private void frame(float dt) {
        if (scene == null || fx == null) {
            GLES30.glClearColor(0.04f, 0.07f, 0.14f, 1f);
            GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT | GLES30.GL_DEPTH_BUFFER_BIT);
            return;
        }
        TrackData td = scene.sd.td;
        float alpha = 1f;
        Kart focus = null;
        float shiftX = 0f;
        if (race != null) {
            Race rc = race;
            pumpInput(rc);
            rc.update(dt);
            alpha = rc.alpha();
            toasts(rc);
            sounds(rc, dt);
            fx.processEvents(rc, rc.localSlot, cam, hud);
            focus = rc.localKart();
            cam.chase(rc, focus, alpha, dt, settings.cameraMode, settings.fov, settings.camShake);
            fx.setTime(time);
            fx.update(rc, dt, time, alpha, cam.ex, cam.ey, cam.ez, !shadowsOn);
            fillHud(rc);
        } else {
            float gx = td.gridX[0], gy = td.gridY[0], gz = td.gridZ[0];
            boolean tall = Math.floorMod(menuKart, KartModels.TYPES) == 2; // the monster truck with its cage is almost twice as tall as the others
            cam.orbit(gx, gy + (tall ? 0.45f : 0f), gz, time, tall ? 8.0f : 6.2f, tall ? 2.5f : 2.0f, menuYawOffset);
            // glide to the new horizontal position of the menu kart instead of jumping when the screen changes
            if (Float.isNaN(menuShiftCur)) menuShiftCur = menuShift;
            menuShiftCur += (menuShift - menuShiftCur) * (1f - (float) Math.exp(-7f * dt));
            shiftX = menuShiftCur;
            hud.active = false;
            Sfx.engine(false, 1f, 0f);
            Sfx.skid(0f);
        }
        render(td, alpha, focus, shiftX);
    }

    private void pumpInput(Race rc) {
        rc.localInput.steer = input.steer; rc.localInput.throttle = input.throttle; rc.localInput.brake = input.brake;
        rc.localInput.drift = input.drift; rc.localInput.boost = input.boost;
        rc.localInput.assist = settings.assistStrength();
        if (settings.autoGas && rc.phase == Race.PH_COUNTDOWN) {
            // Auto accelerate would hold the gas for the whole countdown, which costs the start boost (and slows the kart at GO if held for
            // more than 1.8 s). So the gas is pressed for the last half second before GO and stays held through it (the boost needs the gas to
            // be held continuously, 0.05 to 0.75 s before GO), which gives the start boost every race.
            rc.localInput.throttle = (rc.raceTime > -0.5f && input.brake <= 0f) ? 1f : 0f;
        }
        if (input.takeItem()) rc.pressItem();
        if (input.takeRespawn()) rc.forceRespawnLocal();
    }


    // ------------------------------------------------------------------ sound

    private int sfxCountN = 99;
    private boolean sfxGo, sfxWasWrong;
    private long sfxSplashMs, sfxWrongMs;
    private float engRate = 0.8f, engVol, skidVol;

    private static float att(float dist) {
        if (dist >= 65f) return 0f;
        float k = 1f - dist / 65f;
        return k * (float) Math.sqrt(k);
    }

    /** Plays a one-shot for an event that happened `dist` metres away, panned by `pan` (-1 left .. 1 right). */
    private void sfxAt(int id, float vol, float dist, float pan, float rate) {
        float a = att(dist);
        if (a <= 0f) return;
        Sfx.play(id, vol * a, rate, pan * Math.min(1f, dist / 12f));
    }

    /** Turns the simulation events of this frame into sound, and drives the engine and tyre loops. */
    private void sounds(Race rc, float dt) {
        Kart me = rc.localKart();
        FxEvents e = rc.fx;
        float fwx = cam.tx - cam.ex, fwz = cam.tz - cam.ez;
        float fl = (float) Math.sqrt(fwx * fwx + fwz * fwz);
        if (fl < 1e-3f) { fwx = 0f; fwz = -1f; fl = 1f; }
        float rx = -fwz / fl, rz = fwx / fl;
        long now = System.currentTimeMillis();
        boolean paused = rc.isPaused();
        for (int i = 0; i < e.count && !paused; i++) {
            float dx = e.x[i] - me.x, dz = e.z[i] - me.z;
            float dist = (float) Math.sqrt(dx * dx + dz * dz);
            float pan = dist < 0.5f ? 0f : (dx * rx + dz * rz) / dist;
            boolean mine = (int) e.a[i] == rc.localSlot;
            switch (e.type[i]) {
                case FxEvents.BOOST:
                    if (mine) Sfx.play(Snd.BOOST, 0.85f); else sfxAt(Snd.BOOST, 0.5f, dist, pan, 1f);
                    break;
                case FxEvents.PAD:
                    if (mine) Sfx.play(Snd.PAD, 0.9f); else sfxAt(Snd.PAD, 0.5f, dist, pan, 1f);
                    break;
                case FxEvents.HIT:
                    if (e.a[i] == Kart.HIT_BUMP) sfxAt(Snd.BUMP, dist < 3.5f ? 0.9f : 0.5f, dist, pan, 1f);
                    else sfxAt(Snd.SPIN, dist < 3.5f ? 1f : 0.6f, dist, pan, 1f);
                    break;
                case FxEvents.EXPLODE:
                    sfxAt(Snd.EXPLODE, 1f, dist, pan, 1f);
                    break;
                case FxEvents.SMASH:
                    sfxAt(Snd.SMASH, 0.85f, dist, pan, 0.9f + 0.2f * ((i * 37) % 10) / 10f);
                    break;
                case FxEvents.LAND:
                    if (e.a[i] >= 5f) sfxAt(Snd.LAND, Math.min(1f, 0.25f + e.a[i] / 20f), dist, pan, 1f);
                    break;
                case FxEvents.SPLASH:
                    if (dist < 28f && now - sfxSplashMs > 160L) { sfxSplashMs = now; sfxAt(Snd.SPLASH, 0.55f, dist, pan, 0.9f + 0.2f * ((i * 53) % 10) / 10f); }
                    break;
                case FxEvents.BUMP:
                    sfxAt(Snd.BUMP, Math.min(1f, 0.3f + e.a[i] / 18f), dist, pan, 0.9f + 0.2f * ((i * 29) % 10) / 10f);
                    break;
                case FxEvents.ITEM_PICK:
                    if (mine) Sfx.play(Snd.ITEM_PICK, 0.95f); else sfxAt(Snd.ITEM_PICK, 0.35f, dist, pan, 1f);
                    break;
                case FxEvents.LAUNCH: {
                    int it = (int) e.a[i];
                    int snd = it == Race.I_ROCKET ? Snd.ROCKET : (it == Race.I_COCONUT ? Snd.COCONUT : Snd.OIL);
                    sfxAt(snd, 0.9f, dist, pan, 1f);
                    break;
                }
                case FxEvents.RESPAWN:
                    if (mine) Sfx.play(Snd.RESPAWN, 0.8f); else sfxAt(Snd.RESPAWN, 0.4f, dist, pan, 1f);
                    break;
                case FxEvents.SHIELD_POP:
                    if (mine) Sfx.play(Snd.SHIELD_POP, 1f); else sfxAt(Snd.SHIELD_POP, 0.5f, dist, pan, 1f);
                    break;
                case FxEvents.SHIELD_ON:
                    if (mine) Sfx.play(Snd.SHIELD_ON, 0.85f); else sfxAt(Snd.SHIELD_ON, 0.4f, dist, pan, 1f);
                    break;
                case FxEvents.CHECKPOINT:
                    if (e.a[i] == rc.cfg.laps) Sfx.play(Snd.FINAL_LAP, 0.9f);
                    else if (e.a[i] < rc.cfg.laps) Sfx.play(Snd.LAP, 0.85f);
                    break;
                case FxEvents.DRIFT_SPARK:
                    if (dist < 3.5f) Sfx.play(Snd.SPARK, 0.6f, 0.85f + 0.18f * Math.max(1f, e.a[i]), 0f);
                    break;
                case FxEvents.HOP:
                    if (mine) Sfx.play(Snd.JUMP, 0.5f, 1.25f, 0f); else sfxAt(Snd.JUMP, 0.28f, dist, pan, 1.25f);
                    break;
                case FxEvents.FINISH:
                    if (mine) Sfx.play(Snd.FINISH, 1f);
                    break;
                default: break;
            }
        }

        // countdown beeps and the start signal
        if (!paused && rc.phase == Race.PH_COUNTDOWN) {
            if (rc.raceTime > -3.3f) {
                int n = (int) Math.ceil(-rc.raceTime);
                if (n != sfxCountN && n >= 1 && n <= 3) { sfxCountN = n; Sfx.play(Snd.BEEP, 0.9f); }
            }
        } else if (!sfxGo && rc.phase != Race.PH_COUNTDOWN) {
            sfxGo = true;
            if (rc.raceTime < 1.5f) Sfx.play(Snd.GO, 1f);
        }

        // wrong way warning
        if (me.wrongWay && !sfxWasWrong && now - sfxWrongMs > 6000L && rc.phase == Race.PH_RACING && !paused) {
            sfxWrongMs = now;
            Sfx.play(Snd.WRONG_WAY, 0.8f);
        }
        sfxWasWrong = me.wrongWay;

        // engine: pitch follows speed (with three gears), louder with throttle
        boolean engineOn = !paused && !me.finished && rc.phase != Race.PH_ENDED;
        float sp01 = Math.min(1.15f, me.speed() / 38f);
        float thr = rc.localInput.throttle;
        float gearPos = Math.min(2.999f, sp01 * 3f);
        int gear = (int) gearPos;
        float within = gearPos - gear;
        float rate = 0.8f + 0.45f * within + 0.2f * gear;
        if (rc.phase == Race.PH_COUNTDOWN) rate = 0.8f + 0.5f * thr; // revving on the grid
        if (me.boostTime > 0f) rate *= 1.1f;
        if (!me.grounded) rate *= 1.08f;
        float tv = 0.2f + 0.26f * Math.min(1f, sp01) + 0.1f * thr + (me.boostTime > 0f ? 0.08f : 0f);
        float k = Math.min(1f, dt * 9f);
        engRate += (rate - engRate) * k;
        engVol += (tv - engVol) * k;
        Sfx.engine(engineOn, engRate, engVol);

        // tyre squeal while drifting, sliding or braking hard
        float sk = 0f;
        if (engineOn && me.grounded && me.speed() > 8f) {
            if (me.drifting) {
                // louder the further the tail has slid out
                float slipA = Math.abs(MathX.angleDiff((float) Math.atan2(me.vx, -me.vz), me.yaw));
                sk = 0.34f + 0.26f * MathX.sat(slipA / 0.4f);
            }
            else if (me.spinTime > 0f) sk = 0.5f;
            else if (rc.localInput.brake > 0.6f && me.speed() > 14f) sk = 0.28f;
        }
        skidVol += (sk - skidVol) * Math.min(1f, dt * 12f);
        Sfx.skid(skidVol);
    }

    private void silence() {
        sfxCountN = 99; sfxGo = false; sfxWasWrong = false;
        engVol = 0f; skidVol = 0f;
        Sfx.engine(false, 1f, 0f);
        Sfx.skid(0f);
    }

    private void toasts(Race rc) {
        FxEvents e = rc.fx;
        Kart me = rc.localKart();
        for (int i = 0; i < e.count; i++) {
            switch (e.type[i]) {
                case FxEvents.CHECKPOINT:
                    if (e.a[i] <= rc.cfg.laps) hud.toast("LAP " + (int) e.a[i] + " / " + rc.cfg.laps, 1800);
                    break;
                case FxEvents.HIT: {
                    float dx = me.x - e.x[i], dz = me.z - e.z[i];
                    if (dx * dx + dz * dz < 9f) hud.toast(e.a[i] == Kart.HIT_BURN ? "Burned!" : "Spun out!", 1400);
                    break;
                }
                case FxEvents.ITEM_PICK:
                    if ((int) e.a[i] == rc.localSlot) {
                        int it = me.item;
                        if (it >= 1 && it < ItemArt.NAME.length) hud.toast(ItemArt.NAME[it] + "!", ItemArt.HINT[it], 2800);
                        else hud.toast("Item!", 700);
                    }
                    break;
                case FxEvents.RESPAWN:
                    if ((int) e.a[i] == rc.localSlot) hud.toast("Back on track", 1200);
                    break;
                case FxEvents.SHIELD_POP:
                    if ((int) e.a[i] == rc.localSlot) hud.toast("Shield blocked a hit", 1200);
                    break;
                case FxEvents.FINISH:
                    if ((int) e.a[i] == rc.localSlot) hud.toast("FINISH!", 4000);
                    break;
                case FxEvents.BOOST:
                    if ((int) e.a[i] == rc.localSlot && me.boostTime > 0.5f) hud.toast("Boost!", 700);
                    break;
                default: break;
            }
        }
    }

    private void fillHud(Race rc) {
        Kart me = rc.localKart();
        HudData h = hud;
        h.active = true; h.phase = rc.phase; h.raceTime = rc.raceTime; h.speedKmh = me.speed() * 3.6f;
        h.place = me.place; h.nKarts = rc.nKarts; h.lap = Math.min(rc.cfg.laps, Math.max(1, me.crossings)); h.laps = rc.cfg.laps;
        h.shieldTime = me.shield; h.item = me.item; h.nitro = me.nitro; h.drifting = me.drifting; h.driftLevel = me.drifting ? me.driftLevel : -1; h.driftTime = me.driftTime;
        h.boosting = me.boostTime > 0f; h.wrongWay = me.wrongWay; h.turnHint = me.turnHint; h.finished = me.finished; h.finishTimeSec = me.finishTime;
        h.localSlot = rc.localSlot; h.netMode = rc.net != null; h.itemsOn = rc.itemsOn; h.paused = rc.isPaused();
        h.mapN = Math.min(8, rc.nKarts);
        for (int i = 0; i < h.mapN; i++) {
            Kart k = rc.karts[i];
            h.mapX[i] = k.x; h.mapZ[i] = k.z; h.mapYaw[i] = k.yaw; h.mapColor[i] = KartModels.PAINTS[Math.floorMod(k.color, KartModels.PAINTS.length)];
            h.mapPlace[i] = k.place; h.mapHuman[i] = k.ctrl != Kart.CTRL_AI;
        }
    }

    // ---------------------------------------------------------------- rendering

    private void render(TrackData td, float alpha, Kart focus, float shiftX) {
        float aspect = width / (float) height;
        float far = q.drawDist + 220f;
        Mat4.perspective(proj, cam.fov * MathX.DEG, aspect, 0.6f, far);
        proj[8] = -shiftX;
        float upx = 0f, upy = 1f, upz = 0f;
        if (Math.abs(cam.roll) > 1e-4f) {
            // bank the camera a little (up vector tilted toward the right-hand side of the view)
            float fwx = cam.tx - cam.ex, fwz = cam.tz - cam.ez, fwl = (float) Math.sqrt(fwx * fwx + fwz * fwz);
            if (fwl > 1e-3f) { float sr = (float) Math.sin(cam.roll); upx = -fwz / fwl * sr; upz = fwx / fwl * sr; upy = (float) Math.cos(cam.roll); }
        }
        Mat4.lookAt(view, cam.ex, cam.ey, cam.ez, cam.tx, cam.ty, cam.tz, upx, upy, upz);
        Mat4.mul(vp, proj, view);
        Mat4.frustum(vp, planes);
        prepareKarts(td, alpha);
        float fx0 = cam.tx, fy0 = cam.ty, fz0 = cam.tz;
        if (focus != null) { fx0 = focus.x; fy0 = focus.y; fz0 = focus.z; }
        boolean useShadow = shadowsOn;
        if (useShadow) {
            computeShadow(fx0, fy0, fz0);
            shadowPass(td);
        }
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0);
        GLES30.glViewport(0, 0, width, height);
        GLES30.glClearColor(scene.fogCol[0], scene.fogCol[1], scene.fogCol[2], 1f);
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT | GLES30.GL_DEPTH_BUFFER_BIT);
        GLES30.glEnable(GLES30.GL_DEPTH_TEST);
        GLES30.glDepthFunc(GLES30.GL_LEQUAL);
        GLES30.glDepthMask(true);
        GLES30.glEnable(GLES30.GL_CULL_FACE);
        GLES30.glCullFace(GLES30.GL_BACK);
        GLES30.glDisable(GLES30.GL_BLEND);

        drawTerrainAndObjects(td, useShadow);
        drawScenery(td, useShadow);
        drawKarts(useShadow);
        drawDecals(useShadow);
        drawSky(shiftX, aspect);
        drawWater();
        drawParticles();
        drawFxOverlay(focus);
        GLES30.glDepthMask(true);
        GLES30.glDisable(GLES30.GL_BLEND);
    }

    /** Light vignette plus speed lines and a coloured edge glow while a mini-turbo runs: one cheap full screen pass. */
    private void drawFxOverlay(Kart focus) {
        if (pFx == null || settings.quality == 0) return;   // skipped on the Low preset to save fill rate
        float speedAmt = 0f, tintA = 0f;
        float[] tint = {1f, 0.6f, 0.15f};
        if (focus != null && race != null && race.phase != Race.PH_COUNTDOWN) {
            float sp = focus.speed();
            speedAmt = MathX.sat((sp - 28f) / 26f) * 0.45f;
            if (focus.boostTime > 0f) {
                speedAmt = Math.max(speedAmt, 0.55f + 0.45f * MathX.sat(focus.boostTime / 0.5f));
                tintA = 0.25f * MathX.sat(focus.boostTime / 0.4f);
                if (focus.boostTint == 1) { tint[0] = 0.25f; tint[1] = 0.6f; tint[2] = 1f; }
                else if (focus.boostTint == 3) { tint[0] = 0.8f; tint[1] = 0.3f; tint[2] = 1f; }
            }
        }
        GLES30.glDisable(GLES30.GL_CULL_FACE);
        GLES30.glDisable(GLES30.GL_DEPTH_TEST);
        GLES30.glDepthMask(false);
        GLES30.glEnable(GLES30.GL_BLEND);
        GLES30.glBlendFunc(GLES30.GL_ONE, GLES30.GL_ONE_MINUS_SRC_ALPHA);
        pFx.use();
        pFx.set1f("uVig", 0.28f);
        pFx.set1f("uSpeed", speedAmt);
        pFx.set1f("uTime", time);
        pFx.set1f("uAspect", width / (float) height);
        pFx.set3f("uTint", tint[0], tint[1], tint[2]);
        pFx.set1f("uTintA", tintA);
        GLES30.glBindVertexArray(vaoEmpty);
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3);
        GLES30.glEnable(GLES30.GL_DEPTH_TEST);
        GLES30.glEnable(GLES30.GL_CULL_FACE);
        GLES30.glDisable(GLES30.GL_BLEND);
    }

    private void lightUniforms(GlUtil.Prog p, boolean useShadow) {
        p.use();
        p.setMat("uVP", vp);
        p.setMat("uShadowVP", shadowMat);
        p.set3f("uSunDir", scene.sunDir[0], scene.sunDir[1], scene.sunDir[2]);
        p.set3f("uSunCol", scene.sunCol[0], scene.sunCol[1], scene.sunCol[2]);
        p.set3f("uAmbSky", scene.ambSky[0], scene.ambSky[1], scene.ambSky[2]);
        p.set3f("uAmbGround", scene.ambGround[0], scene.ambGround[1], scene.ambGround[2]);
        p.set3f("uFogCol", scene.fogCol[0], scene.fogCol[1], scene.fogCol[2]);
        p.set1f("uFogDen", scene.fogDen);
        p.set3f("uCamPos", cam.ex, cam.ey, cam.ez);
        p.set1f("uShadowOn", useShadow ? 1f : 0f);
        p.set1f("uShadowTexel", 1f / shadow.size);
        p.set1f("uPcf", q.pcf ? (q.shadowSize >= 2048 ? 2f : 1f) : 0f);
        p.set1f("uTime", time);
        p.set2f("uWind", 0.16f, 1.5f);
        p.set1i("uTex", 0);
        p.set1i("uShadow", 1);
        p.set1f("uFlash", 0f);
        p.set3f("uPaint", 1f, 1f, 1f);
        p.setMat("uModel", ident);
        GLES30.glActiveTexture(GLES30.GL_TEXTURE1);
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, shadow.tex);
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0);
    }

    private void drawTerrainAndObjects(TrackData td, boolean useShadow) {
        lightUniforms(pStatic, useShadow);
        pStatic.set1f("uDetail2", 1f);   // the ground gets a second, larger layer of the detail texture so it does not look tiled
        tDetail.bind(0);
        WorldMesher.ChunkMesh[] cm = scene.sd.chunks;
        for (int i = 0; i < cm.length; i++) {
            WorldMesher.ChunkMesh c = cm[i];
            float dx = c.cx - cam.ex, dz = c.cz - cam.ez;
            float d = (float) Math.sqrt(dx * dx + dz * dz);
            if (d - c.radius > q.drawDist + 60f) continue;
            if (!Mat4.sphereVisible(planes, c.cx, c.cy, c.cz, c.radius)) continue;
            scene.terrain[i].draw(d < q.terrainLodNear ? 0 : (d < q.terrainLodFar ? 1 : 2));
        }
        pStatic.set1f("uDetail2", 0f);
        scene.roadTex.bind(0);
        scene.roads[0].draw();
        scene.dirtTex.bind(0);
        for (int k = 1; k < scene.roads.length; k++) scene.roads[k].draw();
        tWhite.bind(0);
        for (int i = 0; i < td.ramps.length; i++) {
            TrackData.Ramp r = td.ramps[i];
            Mat4.yaw(m1, r.yaw, r.x, td.groundHeight(r.x, r.z), r.z);
            pStatic.setMat("uModel", m1);
            scene.ramps[i].draw();
        }
        if (td.pads.length > 0) {
            // animated boost pads: scrolling chevrons are computed in the fragment shader
            lightUniforms(pPad, useShadow);
            tWhite.bind(0);
            for (int i = 0; i < td.pads.length; i++) {
                TrackData.Pad p = td.pads[i];
                Mat4.yaw(m1, p.yaw, p.x, p.y, p.z);
                pPad.setMat("uModel", m1);
                pPad.set2f("uPadSize", p.wid * 0.5f, p.len * 0.5f);
                scene.pads[i].draw();
            }
            pStatic.use();
        }
        Mat4.yaw(m1, scene.sd.gateYaw, scene.sd.gateX, scene.sd.gateY, scene.sd.gateZ);
        pStatic.setMat("uModel", m1);
        scene.gate.draw();
        for (int i = 0; i < td.crates.length; i++) {
            if (race != null && !race.crateAlive[i]) continue;
            TrackData.Crate c = td.crates[i];
            Mat4.yaw(m1, 0.4f * i, c.x, c.y, c.z);
            pStatic.setMat("uModel", m1);
            scene.crate.draw();
        }
        boolean boxes = race == null || race.itemsOn;
        for (int b = 0; boxes && b < td.nBoxes; b++) {
            if (race != null && !race.boxActive[b]) continue;
            float bob = (float) Math.sin(time * 2.4f + b) * 0.14f;
            Mat4.yaw(m1, time * 1.7f + b, td.boxX[b], td.boxY[b] + bob, td.boxZ[b]);
            pStatic.setMat("uModel", m1);
            scene.itemBox.draw();
        }
        float t = race != null ? race.raceTime : time;
        for (int i = 0; i < td.hazards.length; i++) {
            TrackData.Haz h = td.hazards[i];
            if (h.type == 1) {
                Mat4.yaw(m1, 0f, h.x0, h.y, h.z0);
                pStatic.setMat("uModel", m1);
                scene.vent.draw();
            } else {
                Race.boulderPos(h, t, hzp);
                float dx = h.x1 - h.x0, dz = h.z1 - h.z0, len = MathX.len2(dx, dz);
                float f = 0.5f - 0.5f * (float) Math.cos(MathX.TAU * (t + h.phase) / h.period);
                float ang = f * len / com.kartracer.gfx.ObjModels.BOULDER_R;
                float yaw = (float) Math.atan2(dx, -dz);
                float gy = td.groundHeight(hzp[0], hzp[1]);
                // the boulder mesh is centred on its own middle: lift it by its radius and roll it around that centre (no more bobbing through the ground)
                Mat4.yaw(m1, yaw, hzp[0], gy + com.kartracer.gfx.ObjModels.BOULDER_R * 0.94f, hzp[1]);
                Mat4.rotationX(m2, -ang);
                Mat4.mul(m1, m1, m2);
                pStatic.setMat("uModel", m1);
                scene.boulder.draw();
            }
        }
        if (race != null) drawEntities();
    }

    private void drawEntities() {
        Race rc = race;
        tWhite.bind(0);
        for (int e = 0; e < Race.MAXE; e++) {
            if (!rc.eAlive[e]) continue;
            float y = rc.ey[e] + (rc.eType[e] == Race.E_SLICK ? 0.02f : 0f);
            float spin = rc.eType[e] == Race.E_COCONUT ? time * 12f : 0f;
            Mat4.yaw(m1, rc.eYaw[e], rc.ex[e], y, rc.ez[e]);
            if (spin != 0f) { Mat4.rotationX(m2, -spin); Mat4.mul(m1, m1, m2); }
            pStatic.setMat("uModel", m1);
            (rc.eType[e] == Race.E_SLICK ? mSlick : (rc.eType[e] == Race.E_ROCKET ? mRocket : mCoconut)).draw();
        }
    }

    private int[] cntBuf = new int[Props.COUNT * 2];

    private void resetInstanceBuffers() {
        for (int t = 0; t < Props.COUNT; t++) for (int l = 0; l < 2; l++) {
            GlMesh m = scene.props[t][l];
            if (m != null) m.instanceBuffer().position(0);
            cntBuf[t * 2 + l] = 0;
        }
    }

    private void drawScenery(TrackData td, boolean useShadow) {
        lightUniforms(pInst, useShadow);
        tWhite.bind(0);
        resetInstanceBuffers();
        SceneData sd = scene.sd;
        float ex = cam.ex, ez = cam.ez;
        float density = q.propDensity;
        for (int i = 0; i < td.scN; i++) {
            int type = td.scType[i];
            float dx = td.scX[i] - ex, dz = td.scZ[i] - ez;
            float d2 = dx * dx + dz * dz;
            float dd = Math.min(Props.DRAW[type], q.drawDist + 40f);
            if (d2 > dd * dd) continue;
            if (density < 0.99f && type != Props.SIGN_L && type != Props.SIGN_R && type != Props.LIGHTHOUSE && type != Props.MESA
                    && ((i * 37) % 100) >= density * 100f) continue;
            float s = td.scScale[i];
            float rad = Props.BOUND[type] * s;
            if (!Mat4.sphereVisible(planes, td.scX[i], td.scY[i] + rad * 0.5f, td.scZ[i], rad)) continue;
            float lodD = Props.LOD[type] * Math.max(1f, s * 0.6f);
            int lod = d2 > lodD * lodD ? 1 : 0;
            GlMesh m = scene.props[type][lod];
            if (m == null) continue;
            int ci = type * 2 + lod;
            if (cntBuf[ci] >= m.capacity()) continue;
            FloatBuffer fb = m.instanceBuffer();
            fb.put(td.scX[i]).put(td.scY[i]).put(td.scZ[i]).put(td.scYaw[i]).put(s).put(sd.scTint[i]).put(sd.scPhase[i]).put(0f);
            cntBuf[ci]++;
        }
        for (int t = 0; t < Props.COUNT; t++) for (int l = 0; l < 2; l++) {
            GlMesh m = scene.props[t][l];
            if (m != null && cntBuf[t * 2 + l] > 0) m.drawInstances(cntBuf[t * 2 + l]);
        }
    }

    // kart matrices -------------------------------------------------------

    private void prepareKarts(TrackData td, float alpha) {
        if (race == null) {
            menuKartCount = menuKartVisible ? 1 : 0;
            for (int i = 0; i < 8; i++) kVis[i] = false;
            if (!menuKartVisible) return;
            int t = Math.floorMod(menuKart, KartModels.TYPES);
            float sway = (float) Math.sin(time * 0.6f) * 0.05f;
            kVis[0] = true; kType[0] = t; kPaint[0] = KartModels.PAINTS[Math.floorMod(menuPaint, KartModels.PAINTS.length)];
            kDriver[0] = Math.floorMod(menuDriver, KartModels.DRIVERS); kFlash[0] = 0f;
            float[] wo = {0f, 0f, 0f, 0f};
            buildKartMatrices(0, t, td.gridX[0], td.gridY[0], td.gridZ[0], td.gridYaw[0] + 0.5f, 0f, sway, 0.005f * (float) Math.sin(time * 2f), time * 0.5f, 0f, wo, 0f);
            return;
        }
        for (int i = 0; i < race.nKarts && i < 8; i++) {
            Kart k = race.karts[i];
            boolean remote = k.ctrl == Kart.CTRL_REMOTE;
            float x = remote ? k.x : MathX.lerp(k.ox, k.x, alpha);
            float y = remote ? k.y : MathX.lerp(k.oy, k.y, alpha);
            float z = remote ? k.z : MathX.lerp(k.oz, k.z, alpha);
            float yaw = remote ? k.yaw : k.oyaw + MathX.angleDiff(k.yaw, k.oyaw) * alpha;
            float spin = k.spinVis;   // spin-out animation: whole turns around the real heading, so it never ends facing another way
            kVis[i] = Mat4.sphereVisible(planes, x, y + 1f, z, 3f);
            if (remote && !k.hasRemote()) kVis[i] = false;
            if (k.invuln > 0f && k.spinTime <= 0f && k.respawnTimer <= 0f && ((int) (time * 14f) & 1) == 0 && k.ctrl == Kart.CTRL_LOCAL && k.invuln < 2.0f) kVis[i] = false;
            kType[i] = Math.floorMod(k.kartType, KartModels.TYPES);
            kPaint[i] = KartModels.PAINTS[Math.floorMod(k.color, KartModels.PAINTS.length)];
            kDriver[i] = Math.floorMod(k.driver, KartModels.DRIVERS);
            kFlash[i] = k.invuln > 0f ? 0.5f + 0.5f * (float) Math.sin(time * 25f) : 0f;
            if (k.boostTime > 0.05f) kFlash[i] = Math.max(kFlash[i], 0.12f);
            buildKartMatrices(i, kType[i], x, y, z, yaw + spin, k.pitchVis, k.rollVis, k.suspY, k.wheelSpin, k.steerVis, k.wheelOff, k.driftVisSlide);
        }
    }

    private void buildKartMatrices(int i, int type, float x, float y, float z, float yaw, float pitch, float roll, float suspY,
                                   float spin, float steerVis, float[] wheelOff, float slide) {
        float[] m = kBody[i];
        Mat4.yaw(m, yaw + slide, x, y + suspY + 0.02f, z);
        Mat4.rotationX(m1, pitch); Mat4.mul(m, m, m1);
        Mat4.rotationZ(m1, roll); Mat4.mul(m, m, m1);
        Mat4.translation(m1, 0f, KartModels.SEAT_Y[type], KartModels.SEAT_Z[type]);
        Mat4.mul(kDrv[i], m, m1);
        for (int w = 0; w < 4; w++) {
            float sx = (w & 1) == 0 ? -1f : 1f, sz = w < 2 ? -1f : 1f;
            float rad = w < 2 ? KartModels.FRONT_R[type] : KartModels.REAR_R[type];
            Mat4.translation(m1, sx * KartModels.TRACK_HALF[type], rad + wheelOff[w] - suspY * 0.5f, sz * KartModels.BASE_HALF[type]);
            Mat4.mul(kWheel[i][w], m, m1);
            if (w < 2) { Mat4.rotationY(m2, -steerVis); Mat4.mul(kWheel[i][w], kWheel[i][w], m2); }
            Mat4.rotationX(m2, -spin);
            Mat4.mul(kWheel[i][w], kWheel[i][w], m2);
        }
    }

    private void drawKarts(boolean useShadow) {
        lightUniforms(pKart, useShadow);
        tWhite.bind(0);
        int n = race == null ? 1 : Math.min(8, race.nKarts);
        for (int i = 0; i < n; i++) {
            if (!kVis[i]) continue;
            int hex = kPaint[i];
            pKart.set3f("uPaint", ((hex >> 16) & 255) / 255f, ((hex >> 8) & 255) / 255f, (hex & 255) / 255f);
            pKart.set1f("uFlash", kFlash[i]);
            pKart.setMat("uModel", kBody[i]);
            bodies[kType[i]].draw();
            pKart.setMat("uModel", kDrv[i]);
            drivers[kDriver[i]].draw();
            for (int w = 0; w < 4; w++) {
                pKart.setMat("uModel", kWheel[i][w]);
                (w < 2 ? wheelsF : wheelsR)[kType[i]].draw();
            }
        }
    }

    // shadows --------------------------------------------------------------

    private void computeShadow(float fx, float fy, float fz) {
        float half = q.shadowSize >= 2048 ? 42f : 36f;
        float[] L = scene.sunDir;
        Mat4.lookAt(lightView, fx + L[0] * 110f, fy + L[1] * 110f, fz + L[2] * 110f, fx, fy, fz, 0f, 1f, 0f);
        float texel = 2f * half / shadow.size;
        float lx = lightView[0] * fx + lightView[4] * fy + lightView[8] * fz + lightView[12];
        float ly = lightView[1] * fx + lightView[5] * fy + lightView[9] * fz + lightView[13];
        lightView[12] += Math.round(lx / texel) * texel - lx;
        lightView[13] += Math.round(ly / texel) * texel - ly;
        Mat4.ortho(lightProj, -half, half, -half, half, 20f, 220f);
        Mat4.mul(lightVP, lightProj, lightView);
        Mat4.mul(shadowMat, bias, lightVP);
    }

    private void shadowPass(TrackData td) {
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, shadow.fbo);
        GLES30.glViewport(0, 0, shadow.size, shadow.size);
        GLES30.glDepthMask(true);
        GLES30.glEnable(GLES30.GL_DEPTH_TEST);
        GLES30.glClear(GLES30.GL_DEPTH_BUFFER_BIT);
        GLES30.glEnable(GLES30.GL_CULL_FACE);
        GLES30.glCullFace(GLES30.GL_FRONT);
        GLES30.glEnable(GLES30.GL_POLYGON_OFFSET_FILL);
        GLES30.glPolygonOffset(1.5f, 4f);
        pShadow.use();
        pShadow.setMat("uLightVP", lightVP);
        int n = race == null ? 1 : Math.min(8, race.nKarts);
        for (int i = 0; i < n; i++) {
            if (race != null && race.karts[i].ctrl == Kart.CTRL_REMOTE && !race.karts[i].hasRemote()) continue;
            pShadow.setMat("uModel", kBody[i]); bodies[kType[i]].draw();
            pShadow.setMat("uModel", kDrv[i]); drivers[kDriver[i]].draw();
            for (int w = 0; w < 4; w++) { pShadow.setMat("uModel", kWheel[i][w]); (w < 2 ? wheelsF : wheelsR)[kType[i]].draw(); }
        }
        // scenery casters near the focus
        pShadowInst.use();
        pShadowInst.setMat("uLightVP", lightVP);
        resetInstanceBuffers();
        float cx = race != null ? race.localKart().x : cam.tx, cz = race != null ? race.localKart().z : cam.tz;
        float r2 = 62f * 62f;
        for (int i = 0; i < td.scN; i++) {
            int type = td.scType[i];
            if (!Props.castsShadow(type)) continue;
            float dx = td.scX[i] - cx, dz = td.scZ[i] - cz;
            if (dx * dx + dz * dz > r2) continue;
            GlMesh m = scene.props[type][1];
            if (m == null || cntBuf[type * 2 + 1] >= m.capacity()) continue;
            m.instanceBuffer().put(td.scX[i]).put(td.scY[i]).put(td.scZ[i]).put(td.scYaw[i]).put(td.scScale[i]).put(1f).put(0f).put(0f);
            cntBuf[type * 2 + 1]++;
        }
        for (int t = 0; t < Props.COUNT; t++) {
            GlMesh m = scene.props[t][1];
            if (m != null && cntBuf[t * 2 + 1] > 0) m.drawInstances(cntBuf[t * 2 + 1]);
        }
        GLES30.glDisable(GLES30.GL_POLYGON_OFFSET_FILL);
        GLES30.glCullFace(GLES30.GL_BACK);
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0);
    }

    // decals / sky / water / particles -------------------------------------

    private void drawDecals(boolean useShadow) {
        if (race == null) return;
        GLES30.glEnable(GLES30.GL_BLEND);
        GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE_MINUS_SRC_ALPHA);
        GLES30.glDepthMask(false);
        GLES30.glDisable(GLES30.GL_CULL_FACE);
        GLES30.glEnable(GLES30.GL_POLYGON_OFFSET_FILL);
        GLES30.glPolygonOffset(-2f, -4f);
        pDecal.use();
        pDecal.setMat("uVP", vp);
        pDecal.set1f("uNow", time);
        if (fx.skidQuads > 0) {
            int verts = (fx.skidQuads >= Fx.SKID_CAP ? Fx.SKID_CAP : fx.skidQuads) * 6;
            skidFb.clear();
            skidFb.put(fx.skid, 0, verts * Fx.DECAL_FLOATS);
            skidFb.position(0);
            GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, dVboSkid);
            GLES30.glBufferSubData(GLES30.GL_ARRAY_BUFFER, 0, verts * Fx.DECAL_FLOATS * 4, skidFb);
            pDecal.set1f("uFade", 9f);
            pDecal.set1f("uSoft", 0.55f);
            GLES30.glUniform4f(pDecal.u("uColor"), 0.04f, 0.04f, 0.045f, 0.55f);
            GLES30.glBindVertexArray(dVaoSkid);
            GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, verts);
        }
        if (!useShadow && fx.blobVerts > 0) {
            blobFb.clear();
            blobFb.put(fx.blob, 0, fx.blobVerts * Fx.DECAL_FLOATS);
            blobFb.position(0);
            GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, dVboBlob);
            GLES30.glBufferSubData(GLES30.GL_ARRAY_BUFFER, 0, fx.blobVerts * Fx.DECAL_FLOATS * 4, blobFb);
            pDecal.set1f("uFade", 1e6f);
            pDecal.set1f("uSoft", 0.15f);
            GLES30.glUniform4f(pDecal.u("uColor"), 0f, 0f, 0f, 1f);
            GLES30.glBindVertexArray(dVaoBlob);
            GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, fx.blobVerts);
        }
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0);
        GLES30.glDisable(GLES30.GL_POLYGON_OFFSET_FILL);
        GLES30.glEnable(GLES30.GL_CULL_FACE);
        GLES30.glDepthMask(true);
        GLES30.glDisable(GLES30.GL_BLEND);
    }

    private void drawSky(float shiftX, float aspect) {
        GLES30.glDisable(GLES30.GL_CULL_FACE);
        GLES30.glDepthMask(false);
        pSky.use();
        float tanY = (float) Math.tan(cam.fov * MathX.DEG * 0.5f);
        pSky.set3f("uRight", view[0], view[4], view[8]);
        pSky.set3f("uUp", view[1], view[5], view[9]);
        pSky.set3f("uFwd", -view[2], -view[6], -view[10]);
        pSky.set2f("uTan", tanY * aspect, tanY);
        pSky.set2f("uShift", shiftX, 0f);
        pSky.set3f("uTop", scene.top[0], scene.top[1], scene.top[2]);
        pSky.set3f("uHorizon", scene.horizon[0], scene.horizon[1], scene.horizon[2]);
        pSky.set3f("uFogCol", scene.fogCol[0], scene.fogCol[1], scene.fogCol[2]);
        pSky.set3f("uSunDir", scene.sunDir[0], scene.sunDir[1], scene.sunDir[2]);
        pSky.set3f("uSunCol", scene.sunCol[0] * 1.3f, scene.sunCol[1] * 1.3f, scene.sunCol[2] * 1.3f);
        pSky.set1f("uTime", time);
        pSky.set1i("uNoise", 0);
        tNoise.bind(0);
        GLES30.glBindVertexArray(vaoEmpty);
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3);
        GLES30.glEnable(GLES30.GL_CULL_FACE);
        GLES30.glDepthMask(true);
    }

    private void drawWater() {
        if (scene.def.waterLevel < -50f) return;
        GLES30.glEnable(GLES30.GL_BLEND);
        GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE_MINUS_SRC_ALPHA);
        GLES30.glDepthMask(false);
        GLES30.glDisable(GLES30.GL_CULL_FACE);
        pWater.use();
        pWater.setMat("uVP", vp);
        pWater.set3f("uCamPos", cam.ex, cam.ey, cam.ez);
        pWater.set3f("uSunDir", scene.sunDir[0], scene.sunDir[1], scene.sunDir[2]);
        pWater.set3f("uSunCol", scene.sunCol[0], scene.sunCol[1], scene.sunCol[2]);
        pWater.set3f("uFogCol", scene.fogCol[0], scene.fogCol[1], scene.fogCol[2]);
        pWater.set3f("uShallow", scene.shallow[0], scene.shallow[1], scene.shallow[2]);
        pWater.set3f("uDeep", scene.deep[0], scene.deep[1], scene.deep[2]);
        pWater.set3f("uSkyCol", scene.horizon[0], scene.horizon[1], scene.horizon[2]);
        pWater.set1f("uFogDen", scene.fogDen);
        pWater.set1f("uTime", time);
        pWater.set1f("uLava", scene.def.lava ? 1f : 0f);
        pWater.set1f("uWaves", q.waterWaves ? 1f : 0f);
        WorldMesher.ChunkMesh[] cm = scene.sd.chunks;
        for (int i = 0; i < cm.length; i++) {
            GlChunk w = scene.water[i];
            if (w == null) continue;
            WorldMesher.ChunkMesh c = cm[i];
            float dx = c.cx - cam.ex, dz = c.cz - cam.ez;
            float d = (float) Math.sqrt(dx * dx + dz * dz);
            if (d - c.radius > q.drawDist + 60f) continue;
            if (!Mat4.sphereVisible(planes, c.cx, scene.def.waterLevel, c.cz, c.radius)) continue;
            w.draw(d < q.terrainLodNear ? 0 : (d < q.terrainLodFar ? 1 : 2));
        }
        GLES30.glEnable(GLES30.GL_CULL_FACE);
        GLES30.glDepthMask(true);
        GLES30.glDisable(GLES30.GL_BLEND);
    }

    private void drawParticles() {
        if (fx == null || fx.ps.count() == 0) return;
        GLES30.glEnable(GLES30.GL_BLEND);
        GLES30.glDepthMask(false);
        GLES30.glDisable(GLES30.GL_CULL_FACE);
        pParticle.use();
        pParticle.setMat("uVP", vp);
        pParticle.set3f("uRight", view[0], view[4], view[8]);
        pParticle.set3f("uUp", view[1], view[5], view[9]);
        for (int pass = 0; pass < 2; pass++) {
            boolean add = pass == 1;
            int n = fx.ps.fill(pBuf, add);
            if (n == 0) continue;
            pParticle.set1f("uGlow", add ? 1f : 0f);
            if (add) GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE);
            else GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE_MINUS_SRC_ALPHA);
            pFb.clear();
            pFb.put(pBuf, 0, n * 8);
            pFb.position(0);
            GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, pInstVbo);
            GLES30.glBufferSubData(GLES30.GL_ARRAY_BUFFER, 0, n * 32, pFb);
            GLES30.glBindVertexArray(pVao);
            GLES30.glDrawArraysInstanced(GLES30.GL_TRIANGLE_STRIP, 0, 4, n);
        }
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0);
        GLES30.glEnable(GLES30.GL_CULL_FACE);
        GLES30.glDepthMask(true);
        GLES30.glDisable(GLES30.GL_BLEND);
    }
}
