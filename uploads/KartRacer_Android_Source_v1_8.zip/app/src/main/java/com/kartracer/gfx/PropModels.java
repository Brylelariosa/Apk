package com.kartracer.gfx;

import com.kartracer.util.Col;
import com.kartracer.util.MathX;
import com.kartracer.util.Noise;
import com.kartracer.world.Props;

/**
 * Scenery meshes. Vertex alpha: 0..127 = wind sway weight, 128..255 = emissive (+ sway weight - 128).
 * LOD 0 is the detailed mesh, LOD 1 the cheap far version.
 */
public final class PropModels {
    private PropModels() {}

    private static int c(int hex, int a) { return Col.withAlpha(Col.hex(hex), a); }

    public static MeshData build(int type, int lod) { return build(type, lod, 0); }

    /** theme tints the rocks: 0 beach, 1 jungle, 2 volcano, 3 desert. */
    public static MeshData build(int type, int lod, int theme) {
        MeshBuilder b = new MeshBuilder();
        switch (type) {
            case Props.PALM: palm(b, lod); break;
            case Props.BUSH: bush(b, lod); break;
            case Props.ROCK: {
                int[][] cols = {{0x8C877F, 0x5E5A55}, {0x7C8574, 0x4A5342}, {0x4C4852, 0x26232B}, {0xB88458, 0x7A4E34}};
                int[] c = cols[Math.max(0, Math.min(3, theme))];
                rock(b, lod, 11 + theme, 1.0f, c[0], c[1]);
                break;
            }
            case Props.JTREE: jungleTree(b, lod); break;
            case Props.FERN: fern(b, lod); break;
            case Props.MUSHROOM: mushroom(b, lod); break;
            case Props.CACTUS: cactus(b, lod); break;
            case Props.DEADTREE: deadTree(b, lod); break;
            case Props.SPIRE: spire(b, lod); break;
            case Props.MESA: mesa(b, lod); break;
            case Props.UMBRELLA: umbrella(b, lod); break;
            case Props.TORCH: torch(b, lod); break;
            case Props.LIGHTHOUSE: lighthouse(b); break;
            case Props.SIGN_L: sign(b, false); break;
            case Props.SIGN_R: sign(b, true); break;
            case Props.TUFT: tuft(b, lod); break;
            case Props.BANNER: banner(b, lod); break;
            default: totem(b, lod); break;
        }
        return b.build();
    }

    // ---------------------------------------------------------------- vegetation

    // ---------------------------------------------------------------- realistic vegetation helpers

    /** Blend of two 0xRRGGBB colours (no alpha). */
    private static int mixHex(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
        int g = (int) (((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t);
        int bl = (int) ((a & 255) + ((b & 255) - (a & 255)) * t);
        return (r << 16) | (g << 8) | bl;
    }

    /** Swaying foliage colour: alpha 136..255 is read by the shader as "lit foliage that sways" (weight 0..1). */
    private static int fol(int hex, float sway) { return Col.withAlpha(Col.hex(hex), 136 + (int) (MathX.sat(sway) * 119f)); }

    /** Trunk / branch colour: alpha 0..127 is only the sway weight. */
    private static int trk(int hex, float sway) { return Col.withAlpha(Col.hex(hex), (int) (MathX.sat(sway) * 120f)); }

    /** One leaf blade (single triangle), double sided: lit from the top face, darker from below. */
    private static void leaf(MeshBuilder b, float ax, float ay, float az, float bx, float by, float bz, float tx, float ty, float tz, int cBase, int cTip) {
        float ux = bx - ax, uy = by - ay, uz = bz - az, vx = tx - ax, vy = ty - ay, vz = tz - az;
        float nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
        float l = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
        if (l < 1e-9f) return;
        nx /= l; ny /= l; nz /= l;
        if (ny < 0f) {
            float t0 = ax; ax = bx; bx = t0; t0 = ay; ay = by; by = t0; t0 = az; az = bz; bz = t0;
            nx = -nx; ny = -ny; nz = -nz;
        }
        float sx = nx * 0.6f, sy = ny * 0.6f + 0.55f, sz = nz * 0.6f;
        int a0 = b.vert(ax, ay, az, sx, sy, sz, cBase), b0 = b.vert(bx, by, bz, sx, sy, sz, cBase), c0 = b.vert(tx, ty, tz, sx, sy, sz, cTip);
        b.tri(a0, b0, c0);
        int dB = Col.scale(cBase, 0.62f), dT = Col.scale(cTip, 0.70f);
        float ox = -nx * 0.6f, oy = -ny * 0.6f - 0.35f, oz = -nz * 0.6f;
        int a1 = b.vert(ax, ay, az, ox, oy, oz, dB), b1 = b.vert(bx, by, bz, ox, oy, oz, dB), c1 = b.vert(tx, ty, tz, ox, oy, oz, dT);
        b.tri(a1, c1, b1);
    }

    /** One pinnate palm frond: an arching spine with pairs of drooping leaflets. */
    private static void frond(MeshBuilder b, float ox, float oy, float oz, float yaw, float len, float rise, float fall, int pairs, int seed, int dark, int light, float swayTip) {
        float dx = (float) Math.cos(yaw), dz = (float) Math.sin(yaw), sx = -dz, sz = dx;
        float[] px = new float[pairs + 1], py = new float[pairs + 1], pz = new float[pairs + 1];
        for (int j = 0; j <= pairs; j++) {
            float s = j / (float) pairs;
            px[j] = ox + dx * s * len; pz[j] = oz + dz * s * len; py[j] = oy + rise * s - fall * s * s;
        }
        int spine = trk(0x6B6A34, 0.30f);
        int segs = Math.max(3, pairs / 4);
        for (int q = 0; q < segs; q++) {
            int j0 = q * pairs / segs, j1 = (q + 1) * pairs / segs;
            float w0 = 0.032f * (1f - 0.75f * j0 / pairs), w1 = 0.032f * (1f - 0.75f * j1 / pairs);
            b.tube(px[j0], py[j0], pz[j0], px[j1], py[j1], pz[j1], w0, w1, 4, spine, spine, false);
        }
        for (int j = 1; j <= pairs; j++) {
            float s = j / (float) pairs;
            float tx = px[j] - px[j - 1], ty = py[j] - py[j - 1], tz = pz[j] - pz[j - 1];
            float tl = (float) Math.sqrt(tx * tx + ty * ty + tz * tz); tx /= tl; ty /= tl; tz /= tl;
            float env = (float) Math.sin(MathX.PI * Math.min(1f, 0.10f + 0.90f * s));
            float L = (0.28f + 0.98f * env) * (0.88f + 0.24f * Noise.hash(j, seed, 77));
            float sway = 0.12f + swayTip * s;
            int cb = fol(mixHex(dark, light, 0.15f + 0.2f * s), sway), ct = fol(mixHex(dark, light, 0.75f + 0.25f * s), sway + 0.1f);
            for (int side = -1; side <= 1; side += 2) {
                float alpha = 0.85f + 0.25f * Noise.hash(j, seed + side, 79);
                float fx = tx * (float) Math.cos(alpha) + sx * side * (float) Math.sin(alpha);
                float fy = ty * (float) Math.cos(alpha) - (0.55f + 0.45f * s);
                float fz = tz * (float) Math.cos(alpha) + sz * side * (float) Math.sin(alpha);
                float fl = (float) Math.sqrt(fx * fx + fy * fy + fz * fz); fx /= fl; fy /= fl; fz /= fl;
                float w = 0.075f;
                leaf(b, px[j] - tx * w, py[j] - ty * w, pz[j] - tz * w, px[j] + tx * w, py[j] + ty * w, pz[j] + tz * w, px[j] + fx * L, py[j] + fy * L, pz[j] + fz * L, cb, ct);
            }
        }
    }

    /** Foliage clump: a lumpy ellipsoid whose normals mostly point away from the canopy centre, so a tree is shaded like one soft mass. */
    private static void clump(MeshBuilder b, float cx, float cy, float cz, float rx, float ry, float rz, int segs, int rings, int seed,
                              int colBot, int colTop, float ax, float ay, float az, float soft) {
        int[][] g = new int[rings + 1][segs + 1];
        for (int k = 0; k <= rings; k++) {
            float ph = -MathX.PI / 2f + MathX.PI * k / rings;
            float cp = (float) Math.cos(ph), sp = (float) Math.sin(ph);
            for (int i = 0; i <= segs; i++) {
                float th = MathX.TAU * (i % segs) / segs;
                float ux = cp * (float) Math.cos(th), uy = sp, uz = cp * (float) Math.sin(th);
                int qx = Math.round(ux * 6f), qy = Math.round(uy * 6f), qz = Math.round(uz * 6f);
                float j = 1f + 0.30f * (Noise.hash(qx + 31 * qz, qy, seed) - 0.5f);
                float x = cx + rx * ux * j, y = cy + ry * uy * j, z = cz + rz * uz * j;
                float dxn = x - ax, dyn = y - ay, dzn = z - az;
                float dl = (float) Math.sqrt(dxn * dxn + dyn * dyn + dzn * dzn); if (dl < 1e-6f) dl = 1f;
                float nx = ux * (1f - soft) + dxn / dl * soft, ny = uy * (1f - soft) + dyn / dl * soft, nz = uz * (1f - soft) + dzn / dl * soft;
                int c = Col.mix(colBot, colTop, MathX.sat((uy + 0.75f) * 0.62f));
                c = Col.scale(c, 0.90f + 0.20f * Noise.hash(qx * 7 + qz, qy + 3, seed + 5));
                g[k][i] = b.vert(x, y, z, nx, ny, nz, c);
            }
        }
        for (int k = 0; k < rings; k++) for (int i = 0; i < segs; i++) {
            int a = g[k][i], bb = g[k][i + 1], c = g[k + 1][i], d = g[k + 1][i + 1];
            b.tri(a, c, bb);
            b.tri(bb, c, d);
        }
    }

    // ---------------------------------------------------------------- vegetation

    private static void palm(MeshBuilder b, int lod) {
        boolean hi = lod == 0;
        int segs = hi ? 20 : 4;
        float h = 7.2f;
        float[] tx = new float[segs + 1], ty = new float[segs + 1], tz = new float[segs + 1];
        for (int i = 0; i <= segs; i++) {
            float t = i / (float) segs;
            ty[i] = t * h;
            tx[i] = 1.10f * t * t + 0.12f * (float) Math.sin(t * 5.5f);
            tz[i] = 0.20f * (float) Math.sin(t * 3.2f);
        }
        for (int i = 0; i < segs; i++) {
            float t0 = i / (float) segs, t1 = (i + 1) / (float) segs;
            float flare0 = t0 < 0.07f ? 0.16f * (1f - t0 / 0.07f) * (1f - t0 / 0.07f) : 0f, flare1 = t1 < 0.07f ? 0.16f * (1f - t1 / 0.07f) * (1f - t1 / 0.07f) : 0f;
            float ring = hi && (i & 1) == 0 ? 1.035f : 0.985f;
            float r0 = (0.29f - 0.13f * t0 + flare0) * ring, r1 = (0.29f - 0.13f * t1 + flare1) * ring;
            int shade = hi ? ((i & 1) == 0 ? 0xB3A286 : 0x9A8A70) : 0xA89880;
            float v = 0.92f + 0.14f * Noise.hash(i, 3, 91);
            int c0 = Col.scale(trk(shade, t0 * 0.7f), v), c1 = Col.scale(trk(shade, t1 * 0.7f), v);
            b.tube(tx[i], ty[i], tz[i], tx[i + 1], ty[i + 1], tz[i + 1], r0, r1, hi ? 9 : 5, c0, c1, false);
        }
        float cx = tx[segs], cz = tz[segs];
        // crown shaft (green) where the fronds start
        b.sphere(cx, h + 0.10f, cz, 0.22f, 0.40f, 0.22f, hi ? 8 : 5, hi ? 5 : 3, trk(0x59652B, 0.7f), trk(0x7C8A3A, 0.7f));
        int fronds = hi ? 14 : 8;
        for (int k = 0; k < fronds; k++) {
            float a = k * MathX.TAU / fronds + 0.35f * (float) Math.sin(k * 1.7f) + 0.2f;
            float tier = (k % 3) / 2f;
            float len = 3.25f - 0.55f * tier + 0.4f * Noise.hash(k, 1, 5);
            float rise = 0.7f + 1.5f * tier, fall = 2.9f - 1.4f * tier;
            boolean old = !hi ? false : (k % 7 == 3);
            int dark = old ? 0x6E6A30 : (tier > 0.6f ? 0x2F5F26 : 0x2A5522), light = old ? 0x9C9A44 : (tier > 0.6f ? 0x7BA73A : 0x5F9132);
            if (hi) frond(b, cx, h + 0.30f, cz, a, len, rise, fall, 16, k * 13 + 1, dark, light, 0.55f);
            else {
                int pts = 7;
                float[] px = new float[pts], py = new float[pts], pz = new float[pts], hw = new float[pts];
                for (int j = 0; j < pts; j++) {
                    float s = j / (float) (pts - 1);
                    px[j] = cx + (float) Math.cos(a) * s * len; pz[j] = cz + (float) Math.sin(a) * s * len; py[j] = h + 0.3f + rise * s - fall * s * s;
                    hw[j] = (0.50f * (float) Math.sin(MathX.PI * (0.10f + 0.90f * s)) + 0.03f) * ((j & 1) == 0 ? 1f : 0.55f);
                }
                float wx = -(float) Math.sin(a), wz = (float) Math.cos(a);
                int cb = fol(dark, 0.3f), ct = fol(light, 0.5f);
                b.ribbon(px, py, pz, hw, wx, 0.45f, wz, cb, ct);
                b.ribbon(px, py, pz, hw, wx, -0.45f, wz, Col.scale(cb, 0.65f), Col.scale(ct, 0.7f));
            }
        }
        if (hi) {
            // a few dead hanging fronds and a coconut cluster under the crown
            for (int k = 0; k < 3; k++) {
                float a = k * 2.1f + 0.7f;
                float[] px = new float[4], py = new float[4], pz = new float[4], hw = new float[4];
                for (int j = 0; j < 4; j++) {
                    float s = j / 3f;
                    px[j] = cx + (float) Math.cos(a) * (0.15f + 0.9f * s); pz[j] = cz + (float) Math.sin(a) * (0.15f + 0.9f * s);
                    py[j] = h - 0.1f - 1.5f * s; hw[j] = (0.13f + 0.05f * (j & 1)) * (1f - 0.55f * s);
                }
                b.ribbon(px, py, pz, hw, -(float) Math.sin(a), 0f, (float) Math.cos(a), fol(0x8A7A40, 0.3f), fol(0x6A5A2A, 0.4f));
            }
            for (int k = 0; k < 5; k++) {
                float a = k * 1.3f;
                b.sphere(cx + (float) Math.cos(a) * 0.27f, h - 0.15f - (k % 2) * 0.12f, cz + (float) Math.sin(a) * 0.27f, 0.13f, 0.15f, 0.13f, 6, 4, trk(0x4A3A1E, 0.7f), trk(0x6E7A32, 0.7f));
            }
        }
    }

    private static void bush(MeshBuilder b, int lod) {
        int dark = fol(0x3A5E2A, 0.15f), light = fol(0x7BA23E, 0.30f);
        if (lod == 1) { clump(b, 0f, 0.5f, 0f, 1.0f, 0.62f, 1.0f, 6, 3, 3, dark, light, 0f, 0.2f, 0f, 0.55f); return; }
        float[][] cl = {{0f, 0.52f, 0f, 0.95f, 0.62f}, {0.62f, 0.38f, 0.28f, 0.62f, 0.42f}, {-0.55f, 0.36f, -0.34f, 0.58f, 0.40f}, {0.08f, 0.32f, 0.68f, 0.50f, 0.34f}, {-0.35f, 0.34f, 0.5f, 0.45f, 0.32f}};
        for (int i = 0; i < cl.length; i++) {
            float[] o = cl[i];
            int dk = Col.scale(dark, 0.92f + 0.08f * (i % 3)), lt = Col.mix(light, fol(0x8AAE44, 0.3f), 0.25f * (i % 2));
            clump(b, o[0], o[1], o[2], o[3], o[4], o[3], 8, 5, 20 + i, dk, lt, 0f, 0.15f, 0f, 0.55f);
        }
        // a few small flowers on top
        int[] petals = {0xFF8FB0, 0xFFE28A, 0xFFFFFF, 0xFFA24A, 0xFF8FB0, 0xFFE28A};
        for (int k = 0; k < petals.length; k++) {
            float a = k * 2.4f + 0.4f, rho = 0.25f + 0.11f * ((k * 5) % 6);
            float fx = (float) Math.cos(a) * rho, fz = (float) Math.sin(a) * rho;
            float fy = 0.52f + 0.62f * (float) Math.sqrt(Math.max(0.05f, 1f - (rho / 0.95f) * (rho / 0.95f))) + 0.02f;
            b.sphere(fx, fy, fz, 0.07f, 5, 3, c(petals[k], 60));
        }
    }

    /** Low poly jagged rock, flat shaded. */
    public static void rock(MeshBuilder b, int lod, int seed, float r, int hiHex, int loHex) {
        int segs = lod == 0 ? 8 : 5, rings = lod == 0 ? 5 : 3;
        float[][][] p = new float[rings + 1][segs + 1][3];
        for (int k = 0; k <= rings; k++) {
            float ph = -MathX.PI / 2f + MathX.PI * k / rings;
            for (int i = 0; i <= segs; i++) {
                int ii = i % segs;
                float th = MathX.TAU * ii / segs;
                float jit = (k == 0 || k == rings) ? 1f : 0.72f + 0.55f * Noise.hash(ii, k, seed);
                float x = (float) (Math.cos(ph) * Math.cos(th)) * 1.1f * jit * r;
                float y = (float) Math.sin(ph) * 0.78f * jit * r + 0.42f * r;
                float z = (float) (Math.cos(ph) * Math.sin(th)) * 1.0f * jit * r;
                p[k][i][0] = x; p[k][i][1] = Math.max(y, -0.08f); p[k][i][2] = z;
            }
        }
        int hi = Col.hex(hiHex), lo = Col.hex(loHex);
        for (int k = 0; k < rings; k++) for (int i = 0; i < segs; i++) {
            float[] a = p[k][i], bb = p[k][i + 1], cc = p[k + 1][i], d = p[k + 1][i + 1];
            tri(b, a, cc, bb, hi, lo);
            tri(b, bb, cc, d, hi, lo);
        }
    }

    private static void tri(MeshBuilder b, float[] a, float[] bb, float[] c, int hi, int lo) {
        float ux = bb[0] - a[0], uy = bb[1] - a[1], uz = bb[2] - a[2], vx = c[0] - a[0], vy = c[1] - a[1], vz = c[2] - a[2];
        float ny = uz * vx - ux * vz;
        float l = (float) Math.sqrt((uy * vz - uz * vy) * (uy * vz - uz * vy) + ny * ny + (ux * vy - uy * vx) * (ux * vy - uy * vx));
        float t = l < 1e-9f ? 0.5f : MathX.sat(ny / l * 0.5f + 0.5f);
        b.flatTri(a[0], a[1], a[2], bb[0], bb[1], bb[2], c[0], c[1], c[2], Col.mix(lo, hi, t));
    }

    private static void jungleTree(MeshBuilder b, int lod) {
        float h = 9.5f;
        int bark = 0x7D6A55, barkD = 0x5E4E3F;
        boolean hi = lod == 0;
        if (hi) {
            b.tube(0, 0, 0, 0.12f, h * 0.30f, 0.08f, 0.78f, 0.56f, 9, trk(barkD, 0f), trk(bark, 0.1f), false);
            b.tube(0.12f, h * 0.30f, 0.08f, 0.22f, h * 0.62f, -0.06f, 0.56f, 0.46f, 9, trk(bark, 0.1f), trk(bark, 0.3f), false);
            b.tube(0.22f, h * 0.62f, -0.06f, 0f, h * 0.98f, 0f, 0.46f, 0.38f, 9, trk(bark, 0.3f), trk(bark, 0.5f), false);
            for (int k = 0; k < 6; k++) {
                float a = k * MathX.TAU / 6f + 0.4f;
                float ca = (float) Math.cos(a), sa = (float) Math.sin(a);
                b.tube(ca * 1.9f, 0f, sa * 1.9f, ca * 0.55f, 1.6f, sa * 0.55f, 0.18f, 0.30f, 5, trk(barkD, 0f), trk(barkD, 0f), false);
                b.tube(ca * 0.55f, 1.6f, sa * 0.55f, ca * 0.30f, 3.2f, sa * 0.30f, 0.30f, 0.12f, 5, trk(barkD, 0f), trk(bark, 0.1f), false);
            }
            // limbs into the canopy
            float[][] limbs = {{2.2f, h + 0.3f, 1.0f}, {-2.1f, h + 0.1f, -0.9f}, {0.4f, h + 1.6f, -2.0f}, {-1.0f, h + 0.2f, 2.2f}, {1.2f, h + 1.8f, 1.6f}};
            for (float[] l : limbs) b.tube(0f, h * 0.84f, 0f, l[0], l[1], l[2], 0.26f, 0.12f, 5, trk(bark, 0.4f), trk(bark, 0.7f), false);
        } else b.tube(0, 0, 0, 0, h, 0, 0.76f, 0.40f, 5, trk(bark, 0.1f), trk(bark, 0.5f), false);
        int dark = fol(0x2C4E22, 0.15f), mid = fol(0x4A7A30, 0.28f), light = fol(0x86AE42, 0.40f), sun = fol(0xB2C658, 0.50f);
        float ccx = 0f, ccy = h + 1.3f, ccz = 0f;
        if (hi) {
            int n = 22;
            for (int i = 0; i < n; i++) {
                float a = i * 2.39996f;
                float ring = (float) Math.sqrt((i + 0.5f) / n);
                float rr = 3.7f * ring;
                float x = (float) Math.cos(a) * rr, z = (float) Math.sin(a) * rr;
                float yy = h + 1.1f + 1.6f * (1f - ring * ring) * (0.6f + 0.4f * Noise.hash(i, 2, 41)) - 0.25f * ring + 0.5f * (Noise.hash(i, 9, 43) - 0.5f);
                float r = 1.25f + 0.85f * (1f - ring) + 0.35f * Noise.hash(i, 4, 47);
                int dk = yy > h + 2.2f ? mid : dark, lt = yy > h + 2.2f ? sun : light;
                clump(b, x, yy, z, r * 1.1f, r * 0.80f, r * 1.1f, 7, 4, 100 + i, dk, lt, ccx, ccy - 0.6f, ccz, 0.62f);
            }
            // lianas hanging from the canopy edge
            for (int k = 0; k < 6; k++) {
                float a = k * 1.1f + 0.3f;
                float x = (float) Math.cos(a) * 3.1f, z = (float) Math.sin(a) * 2.8f;
                float len = 2.2f + 2.4f * Noise.hash(k, 6, 53);
                b.tube(x, h - 0.2f, z, x + 0.08f, h - 0.2f - len, z + 0.05f, 0.035f, 0.02f, 4, fol(0x35552A, 0.5f), fol(0x4A6A30, 0.7f), false);
            }
        } else {
            clump(b, 0f, h + 1.5f, 0f, 3.9f, 2.5f, 3.9f, 7, 4, 100, dark, light, ccx, ccy - 0.6f, ccz, 0.62f);
            clump(b, 1.6f, h + 0.6f, 0.9f, 2.4f, 1.7f, 2.4f, 6, 3, 101, mid, sun, ccx, ccy - 0.6f, ccz, 0.62f);
            clump(b, -1.7f, h + 0.5f, -0.8f, 2.3f, 1.7f, 2.3f, 6, 3, 102, dark, mid, ccx, ccy - 0.6f, ccz, 0.62f);
        }
    }

    private static void banner(MeshBuilder b, int lod) {
        int pole = c(0xCFD3D8, 0);
        b.tube(0, 0, 0, 0, 4.6f, 0, 0.07f, 0.05f, lod == 0 ? 6 : 4, pole, pole, true);
        if (lod != 0) return;
        b.sphere(0, 4.68f, 0, 0.1f, 6, 4, c(0xFFD54F, 0));
        int n = 6;
        float[] px = new float[n], py = new float[n], pz = new float[n], pz2 = new float[n], hw = new float[n], hw2 = new float[n];
        for (int j = 0; j < n; j++) {
            float s = j / (float) (n - 1);
            px[j] = 0.05f + s * 1.6f;
            py[j] = 4.05f - 0.10f * s - 0.06f * (float) Math.sin(s * 6f);
            pz[j] = 0.0f;
            pz2[j] = 0.012f;
            hw[j] = 0.44f * (1f - 0.85f * s);
            hw2[j] = hw[j] * 0.32f;
        }
        b.ribbon(px, py, pz, hw, 0f, 1f, 0f, c(0xE53935, 30), c(0xE53935, 230));
        b.ribbon(px, py, pz2, hw2, 0f, 1f, 0f, c(0xFFFFFF, 30), c(0xFFFFFF, 230));
    }

    private static void fern(MeshBuilder b, int lod) {
        int leaves = lod == 0 ? 7 : 4, pts = lod == 0 ? 5 : 3;
        for (int k = 0; k < leaves; k++) {
            float a = k * MathX.TAU / leaves + 0.4f;
            float[] px = new float[pts], py = new float[pts], pz = new float[pts], hw = new float[pts];
            for (int j = 0; j < pts; j++) {
                float s = j / (float) (pts - 1);
                px[j] = (float) Math.cos(a) * 1.8f * s; pz[j] = (float) Math.sin(a) * 1.8f * s;
                py[j] = 0.1f + 0.9f * s - 0.9f * s * s;
                hw[j] = 0.2f * (float) Math.sin(MathX.PI * (0.1f + 0.9f * s)) + 0.02f;
            }
            b.ribbon(px, py, pz, hw, -(float) Math.sin(a), 0f, (float) Math.cos(a), c(0x2F8A3A, 40), c(0x7CCB52, 127));
        }
    }

    private static void mushroom(MeshBuilder b, int lod) {
        b.cyl(0, 0, 0, 0.20f, 0.14f, 0.85f, 7, c(0xD9CDB0, 0), c(0xF2E9D0, 0), false, false);
        b.sphere(0, 0.88f, 0, 0.80f, 0.42f, 0.80f, lod == 0 ? 10 : 6, lod == 0 ? 6 : 4, c(0x9E2020, 0), c(0xE53A30, 0));
        if (lod == 0) for (int k = 0; k < 6; k++) {
            float a = k * 1.05f, rr = 0.42f + (k % 2) * 0.2f;
            b.sphere((float) Math.cos(a) * rr, 1.12f - rr * 0.35f, (float) Math.sin(a) * rr, 0.13f, 0.06f, 0.13f, 6, 3, c(0xFFFFFF, 0), c(0xFFFFFF, 0));
        }
    }

    private static void cactus(MeshBuilder b, int lod) {
        int g0 = c(0x3F8A4A, 0), g1 = c(0x5FB063, 30);
        b.cyl(0, 0, 0, 0.42f, 0.36f, 3.5f, 8, g0, g1, false, false);
        b.sphere(0, 3.5f, 0, 0.36f, 0.4f, 0.36f, 8, 4, g1, g1);
        b.tube(-0.3f, 1.5f, 0, -1.0f, 1.65f, 0, 0.22f, 0.22f, 7, g0, g0, false);
        b.tube(-1.0f, 1.65f, 0, -1.05f, 2.9f, 0, 0.22f, 0.2f, 7, g0, g1, false);
        b.sphere(-1.05f, 2.9f, 0, 0.2f, 0.22f, 0.2f, 6, 4, g1, g1);
        if (lod == 0) {
            b.tube(0.3f, 2.1f, 0, 0.85f, 2.2f, 0.1f, 0.2f, 0.2f, 7, g0, g0, false);
            b.tube(0.85f, 2.2f, 0.1f, 0.9f, 3.1f, 0.1f, 0.2f, 0.18f, 7, g0, g1, false);
            b.sphere(0.9f, 3.1f, 0.1f, 0.18f, 0.2f, 0.18f, 6, 4, g1, g1);
            b.sphere(0.1f, 3.9f, 0, 0.12f, 6, 4, c(0xF06292, 40));
        }
    }

    private static void deadTree(MeshBuilder b, int lod) {
        int bark = 0x7A6A5A;
        b.tube(0, 0, 0, 0.3f, 4.2f, 0, 0.35f, 0.12f, 6, c(bark, 0), c(bark, 40), false);
        b.tube(0.1f, 2.5f, 0, 1.5f, 4.0f, 0.5f, 0.12f, 0.04f, 5, c(bark, 10), c(bark, 60), false);
        b.tube(-0.1f, 3.0f, 0, -1.3f, 4.3f, -0.4f, 0.11f, 0.04f, 5, c(bark, 10), c(bark, 60), false);
        if (lod == 0) {
            b.tube(0.2f, 3.6f, 0, 0.9f, 5.2f, 0.8f, 0.09f, 0.03f, 5, c(bark, 10), c(bark, 60), false);
            b.tube(0.1f, 1.8f, 0, -0.9f, 2.9f, 0.9f, 0.1f, 0.03f, 5, c(bark, 10), c(bark, 60), false);
        }
    }

    // ---------------------------------------------------------------- rock formations

    private static void spire(MeshBuilder b, int lod) {
        int lo = c(0x2A2830, 0), mid = c(0x4A4652, 0), hi = c(0x6A6474, 0);
        if (lod == 1) { b.cyl(0, 0, 0, 2.0f, 0f, 7.5f, 6, lo, hi, false, false); return; }
        b.cyl(0, -0.3f, 0, 2.1f, 1.5f, 3.3f, 6, lo, mid, false, false);
        b.push().translate(0.25f, 2.9f, 0.1f).rotZ(0.06f).cyl(0, 0, 0, 1.5f, 0.95f, 3.0f, 6, mid, mid, false, false).pop();
        b.push().translate(0.5f, 5.7f, 0.2f).rotZ(0.1f).cyl(0, 0, 0, 0.95f, 0f, 3.6f, 6, mid, hi, false, false).pop();
        b.push().translate(-1.3f, 0f, 0.9f).cyl(0, 0, 0, 0.8f, 0f, 3.2f, 5, lo, mid, false, false).pop();
    }

    private static void mesa(MeshBuilder b, int lod) {
        int[] cols = {0xB8643C, 0xD2825A, 0xAA5232, 0xC87846, 0xE1AA6E};
        float[][] layers = {{0, 3.0f, 10f, 9f}, {3.0f, 2.5f, 9f, 9.5f}, {5.5f, 2.5f, 9.5f, 8.2f}, {8.0f, 3.0f, 8.2f, 8.0f}, {11.0f, 0.6f, 8.0f, 7.2f}};
        int n = lod == 0 ? layers.length : 2;
        for (int i = 0; i < n; i++) {
            float[] l = layers[i];
            int col = c(cols[i], 0);
            b.push().rotY(i * 0.35f).cyl(0, l[0], 0, l[2], l[3], l[1], 10, Col.scale(col, 0.85f), col, false, i == layers.length - 1).pop();
        }
        if (lod == 1) b.cyl(0, 5.5f, 0, 9.5f, 8f, 6f, 10, c(0xC87846, 0), c(0xE1AA6E, 0), false, true);
    }

    // ---------------------------------------------------------------- man made

    private static void umbrella(MeshBuilder b, int lod) {
        b.tube(0, 0, 0, 0, 2.5f, 0, 0.045f, 0.04f, 5, c(0xF0F0F0, 0), c(0xF0F0F0, 0), false);
        int n = 8;
        float r = 1.7f;
        for (int i = 0; i < n; i++) {
            float a0 = MathX.TAU * i / n, a1 = MathX.TAU * (i + 1) / n;
            int col = (i & 1) == 0 ? c(0xE53935, 0) : c(0xFFFFFF, 0);
            b.flatTri(0, 3.0f, 0, (float) Math.cos(a1) * r, 2.35f, (float) Math.sin(a1) * r, (float) Math.cos(a0) * r, 2.35f, (float) Math.sin(a0) * r, col);
        }
        b.cyl(0, 2.35f, 0, r, r * 0.97f, 0.0f, n, c(0xFFFFFF, 0), c(0xFFFFFF, 0), false, false);
    }

    private static void torch(MeshBuilder b, int lod) {
        b.tube(0, 0, 0, 0, 1.9f, 0, 0.07f, 0.06f, 5, c(0x7A5230, 0), c(0x7A5230, 0), false);
        b.cyl(0, 1.85f, 0, 0.14f, 0.22f, 0.22f, 7, c(0x3A2A20, 0), c(0x5A4030, 0), false, false);
        b.cyl(0, 2.05f, 0, 0.16f, 0.0f, 0.55f, 6, c(0xFF7A10, 128), c(0xFFE060, 128), false, false);
    }

    private static void lighthouse(MeshBuilder b) {
        float y = 0f;
        for (int i = 0; i < 6; i++) {
            float r0 = 2.7f - i * 0.18f, r1 = 2.7f - (i + 1) * 0.18f;
            int col = (i & 1) == 0 ? c(0xF5F5F5, 0) : c(0xD32F2F, 0);
            b.cyl(0, y, 0, r0, r1, 3.0f, 12, Col.scale(col, 0.88f), col, false, false);
            y += 3.0f;
        }
        b.cyl(0, y, 0, 2.2f, 2.2f, 0.35f, 12, c(0x37474F, 0), c(0x546E7A, 0), false, true);
        b.cyl(0, y + 0.35f, 0, 1.1f, 1.0f, 1.7f, 10, c(0xFFD54F, 128), c(0xFFF59D, 128), false, false);
        b.cyl(0, y + 2.05f, 0, 1.6f, 0f, 1.6f, 10, c(0xB71C1C, 0), c(0xE53935, 0), false, false);
        b.box(0, 0.9f, -2.65f, 0.5f, 0.9f, 0.1f, c(0x5D4037, 0));
    }

    private static void sign(MeshBuilder b, boolean right) {
        b.tube(0, 0, 0, 0, 2.2f, 0, 0.06f, 0.06f, 5, c(0x6D4C41, 0), c(0x6D4C41, 0), false);
        b.box(0, 2.55f, -0.015f, 1.0f, 0.55f, 0.03f, c(0x263238, 0));
        b.box(0, 2.55f, 0.02f, 0.93f, 0.48f, 0.02f, c(0xFFC400, 0));
        float s = right ? 1f : -1f;
        int dk = c(0x263238, 0);
        b.box(-0.12f * s, 2.55f, 0.045f, 0.4f, 0.1f, 0.01f, dk);
        if (right) b.flatTri(0.28f, 2.92f, 0.052f, 0.28f, 2.18f, 0.052f, 0.80f, 2.55f, 0.052f, dk);
        else b.flatTri(-0.28f, 2.18f, 0.052f, -0.28f, 2.92f, 0.052f, -0.80f, 2.55f, 0.052f, dk);
    }

    private static void tuft(MeshBuilder b, int lod) {
        // a clump of thin curved grass blades (lit like foliage), straw green at the tips
        int blades = lod == 0 ? 11 : 5;
        for (int k = 0; k < blades; k++) {
            float a = k * 2.39996f + 0.4f;
            float rr = 0.05f + 0.10f * Noise.hash(k, 3, 61);
            float bx = (float) Math.cos(a) * rr, bz = (float) Math.sin(a) * rr;
            float len = 0.50f + 0.45f * Noise.hash(k, 4, 62);
            float lean = 0.20f + 0.30f * Noise.hash(k, 5, 63);
            float tx = bx + (float) Math.cos(a) * lean * len, tz = bz + (float) Math.sin(a) * lean * len;
            float ty = len * (0.88f - 0.25f * lean);
            float w = lod == 0 ? 0.040f : 0.07f;
            float sx = -(float) Math.sin(a) * w, sz = (float) Math.cos(a) * w;
            leaf(b, bx - sx, 0f, bz - sz, bx + sx, 0f, bz + sz, tx, ty, tz, fol(0x6A8530, 0.25f), fol(0xB8C85C, 0.55f));
        }
    }

    private static void totem(MeshBuilder b, int lod) {
        int w0 = c(0x825532, 0), w1 = c(0x966440, 0), w2 = c(0x784B2D, 0);
        b.box(0, 0.6f, 0, 0.45f, 0.6f, 0.45f, w0);
        b.box(0, 1.8f, 0, 0.40f, 0.6f, 0.40f, w1);
        b.box(0, 2.9f, 0, 0.45f, 0.5f, 0.45f, w2);
        b.cyl(0, 3.4f, 0, 0.52f, 0f, 0.7f, 6, c(0x1E9E8A, 0), c(0xFFB300, 0), false, false);
        for (int lvl = 0; lvl < 3; lvl++) {
            float y = lvl == 0 ? 0.75f : (lvl == 1 ? 1.95f : 3.0f);
            float hw = lvl == 1 ? 0.40f : 0.45f;
            b.box(-0.18f, y + 0.12f, hw + 0.01f, 0.1f, 0.08f, 0.01f, c(0xFFFFFF, 0));
            b.box(0.18f, y + 0.12f, hw + 0.01f, 0.1f, 0.08f, 0.01f, c(0xFFFFFF, 0));
            b.box(-0.18f, y + 0.12f, hw + 0.02f, 0.04f, 0.04f, 0.01f, c(0x101010, 0));
            b.box(0.18f, y + 0.12f, hw + 0.02f, 0.04f, 0.04f, 0.01f, c(0x101010, 0));
            b.box(0, y - 0.15f, hw + 0.01f, 0.2f, 0.07f, 0.01f, c(0x3A1A10, 0));
        }
        b.box(0, 1.2f, 0.0f, 0.5f, 0.05f, 0.5f, c(0xD84315, 0));
        b.box(0, 2.4f, 0.0f, 0.45f, 0.05f, 0.45f, c(0x1E9E8A, 0));
    }

}
