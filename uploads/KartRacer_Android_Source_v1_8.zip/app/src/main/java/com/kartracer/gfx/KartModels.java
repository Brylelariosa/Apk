package com.kartracer.gfx;

import com.kartracer.util.Col;
import com.kartracer.util.MathX;

import java.util.ArrayList;

/**
 * Procedural kart, wheel and driver meshes. Body space: forward = -Z, right = +X, ground at y = 0.
 * Bodies are lofted from smooth cross sections (rounded shoulders, fenders over the wheels, chrome, lamps and a painted
 * racing stripe) instead of stacked boxes; drivers are chunky characters with helmets, faces, arms on the wheel and a number badge.
 */
public final class KartModels {
    private KartModels() {}

    public static final int TYPES = 6, DRIVERS = 6;
    public static final String[] DRIVER_NAMES = {"Rex", "Coco", "Bolt", "Mango", "Zippy", "Tiki"};
    /** Paint colors (0xRRGGBB) offered in the garage. */
    public static final int[] PAINTS = {0xE53935, 0xFF9800, 0xFDD835, 0x43A047, 0x00ACC1, 0x1E88E5, 0x8E24AA, 0xEC407A};
    public static final String[] PAINT_NAMES = {"Red", "Orange", "Yellow", "Green", "Teal", "Blue", "Purple", "Pink"};

    // wheel layout per kart type
    public static final float[] FRONT_R = {0.42f, 0.36f, 0.64f, 0.40f, 0.36f, 0.52f};
    public static final float[] REAR_R = {0.46f, 0.42f, 0.64f, 0.40f, 0.52f, 0.52f};
    public static final float[] WHEEL_W = {0.34f, 0.28f, 0.46f, 0.32f, 0.34f, 0.38f};
    public static final float[] TRACK_HALF = {0.84f, 0.80f, 1.02f, 0.82f, 0.86f, 0.94f};
    public static final float[] BASE_HALF = {0.95f, 1.05f, 1.00f, 0.90f, 1.00f, 1.00f};
    public static final float[] SEAT_Y = {0.84f, 0.62f, 1.50f, 0.84f, 0.90f, 1.00f};
    public static final float[] SEAT_Z = {0.20f, 0.25f, 0.38f, 0.30f, 0.45f, 0.30f};

    private static int paint(int shade) { return Col.rgba(shade, shade, shade, 255); }
    private static int fixed(int r, int g, int b) { return Col.rgba(r, g, b, 0); }

    private static final int STEEL = fixed(170, 176, 186), CHROME = fixed(226, 232, 240), DARK = fixed(46, 50, 58), BLACK = fixed(24, 26, 30),
            LIGHT = fixed(255, 248, 200), LIGHT_DIM = fixed(236, 214, 150), WHITE = fixed(246, 246, 240), RED = fixed(205, 30, 36), GLOW = fixed(255, 110, 84),
            SEAT = fixed(40, 44, 54), GLASS = fixed(120, 190, 225), INK = fixed(30, 32, 38);

    public static MeshData body(int type) {
        MeshBuilder b = new MeshBuilder();
        switch (Math.floorMod(type, TYPES)) {
            case 0: duneHopper(b); break;
            case 1: sandViper(b); break;
            case 2: rockCrusher(b); break;
            case 3: waveRunner(b); break;
            case 4: lavaRod(b); break;
            default: jungleRover(b); break;
        }
        return b.build();
    }

    // ---------------------------------------------------------------- shared parts

    private static float topAt(float[][] sec, float z) {
        if (z <= sec[0][0]) return sec[0][3];
        for (int i = 0; i + 1 < sec.length; i++) {
            if (z <= sec[i + 1][0]) {
                float t = (z - sec[i][0]) / (sec[i + 1][0] - sec[i][0]);
                return sec[i][3] + (sec[i + 1][3] - sec[i][3]) * t;
            }
        }
        return sec[sec.length - 1][3];
    }

    /** A narrow painted band lying on top of a lofted body between z0 and z1 (racing stripe). */
    private static void topStripe(MeshBuilder b, float[][] sec, float z0, float z1, float hw, int color, float x) {
        ArrayList<float[]> s = new ArrayList<>();
        s.add(new float[]{z0, hw, topAt(sec, z0) - 0.04f, topAt(sec, z0) + 0.012f, 6f, 6f, x});
        for (float[] q : sec) if (q[0] > z0 + 0.01f && q[0] < z1 - 0.01f) s.add(new float[]{q[0], hw, q[3] - 0.04f, q[3] + 0.012f, 6f, 6f, x});
        s.add(new float[]{z1, hw, topAt(sec, z1) - 0.04f, topAt(sec, z1) + 0.012f, 6f, 6f, x});
        b.loft(s.toArray(new float[0][]), 8, color, color, true, true);
    }

    /** Projector headlamp: black housing, chrome bezel, glass lens and a bright LED ring. */
    private static void headlamp(MeshBuilder b, float x, float y, float z, float r) {
        b.softBox(x, y, z + r * 0.05f, r * 1.05f, r * 0.92f, r * 0.55f, 2.6f, 10, 5, BLACK, DARK);
        b.push().translate(x, y, z - r * 0.38f).rotX(MathX.PI / 2f).torus(0, 0, 0, r * 0.80f, r * 0.07f, 16, 4, CHROME).pop();
        b.sphere(x, y, z - r * 0.36f, r * 0.74f, r * 0.74f, r * 0.20f, 10, 5, fixed(150, 166, 178), fixed(226, 236, 244));
        b.push().translate(x, y, z - r * 0.50f).rotX(MathX.PI / 2f).torus(0, 0, 0, r * 0.42f, r * 0.045f, 14, 4, LIGHT).pop();
    }

    private static void taillamp(MeshBuilder b, float x, float y, float z, float w, float h) {
        b.softBox(x, y, z, w, h * 0.85f, 0.03f, 3f, 8, 3, fixed(70, 8, 12), fixed(130, 14, 20));
        b.softBox(x, y, z + 0.016f, w * 0.86f, h * 0.36f, 0.02f, 3f, 8, 3, fixed(236, 40, 40), fixed(255, 90, 76));
    }

    /** Chrome exhaust pipe pointing along (dx, dy, dz) with a dark opening. */
    private static void exhaust(MeshBuilder b, float x, float y, float z, float dx, float dy, float dz, float r) {
        b.tube(x, y, z, x + dx, y + dy, z + dz, r * 0.85f, r, 10, fixed(118, 122, 130), fixed(172, 176, 184), true);
        b.tube(x + dx * 0.55f, y + dy * 0.55f, z + dz * 0.55f, x + dx * 0.72f, y + dy * 0.72f, z + dz * 0.72f, r * 0.96f, r * 0.98f, 10, fixed(150, 124, 70), fixed(120, 104, 150), false);
        b.tube(x + dx * 0.93f, y + dy * 0.93f, z + dz * 0.93f, x + dx, y + dy, z + dz, r * 1.10f, r * 1.10f, 10, fixed(150, 152, 160), fixed(214, 216, 222), true);
        float l = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        float ex = dx / l * 0.012f, ey = dy / l * 0.012f, ez = dz / l * 0.012f;
        b.tube(x + dx, y + dy, z + dz, x + dx + ex, y + dy + ey, z + dz + ez, r * 0.92f, r * 0.92f, 10, BLACK, BLACK, true);
    }

    /** Dark seat pad with a painted coaming ring: the cockpit opening. */
    private static void cockpit(MeshBuilder b, float cx, float cy, float cz, float rx, float rz, int rim) {
        b.softBox(cx, cy + 0.01f, cz, rx * 0.95f, 0.06f, rz * 0.95f, 4f, 14, 5, SEAT, fixed(58, 62, 74));
        b.push().translate(cx, cy + 0.02f, cz).torus(0, 0, 0, rx, rz, 0.05f, 20, 6, rim).pop();
    }

    /** Bucket seat: shell, side bolsters, head restraint and padding. */
    private static void seatBack(MeshBuilder b, float y, float z, float w, float h) {
        b.softBox(0, y, z, w, h, 0.07f, 3f, 12, 6, fixed(28, 30, 36), fixed(50, 54, 64));
        for (int sd = -1; sd <= 1; sd += 2) b.softBox(sd * w * 0.86f, y - h * 0.1f, z - 0.075f, w * 0.16f, h * 0.78f, 0.07f, 3f, 8, 5, fixed(32, 34, 40), fixed(58, 62, 72));
        b.softBox(0, y + h * 0.98f, z - 0.02f, w * 0.52f, h * 0.22f, 0.08f, 3f, 8, 5, fixed(34, 36, 42), fixed(60, 64, 74));
        b.softBox(0, y + h * 0.10f, z - 0.085f, w * 0.58f, h * 0.62f, 0.02f, 3.5f, 8, 4, fixed(62, 66, 80), fixed(62, 66, 80));
    }

    /** Steering wheel and column in front of a driver sitting at (0, seatY, seatZ) of this body. */
    private static void steering(MeshBuilder b, int t, float colY0, float colZ0) {
        float wy = SEAT_Y[t] + 0.26f, wz = SEAT_Z[t] - 0.52f;
        b.push().translate(wy * 0f, wy, wz).rotX(1.05f);
        b.torus(0, 0, 0, 0.15f, 0.024f, 18, 6, BLACK);                                   // rim
        for (int sd = -1; sd <= 1; sd += 2) b.sphere(sd * 0.15f, 0, 0, 0.04f, 0.04f, 0.075f, 8, 5, fixed(54, 56, 62), fixed(80, 82, 90));   // grips
        b.softBox(0, 0, 0, 0.065f, 0.026f, 0.05f, 2.6f, 10, 5, fixed(36, 38, 44), fixed(58, 60, 68));   // carbon hub
        for (int sd = -1; sd <= 1; sd += 2) b.box(sd * 0.085f, 0, 0, 0.07f, 0.010f, 0.016f, fixed(30, 32, 38));
        for (int i = 0; i < 3; i++) b.sphere(-0.03f + i * 0.03f, -0.024f, -0.012f, 0.009f, 5, 3, i == 1 ? fixed(220, 40, 40) : fixed(220, 190, 40));   // buttons
        b.pop();
        b.tube(0, wy - 0.02f, wz + 0.02f, 0, colY0, colZ0, 0.028f, 0.034f, 8, STEEL, STEEL, false);
    }

    /** A wheel arch: curved painted mudguard above a wheel centred at (x, y, z). */
    private static void arch(MeshBuilder b, float x, float y, float z, float tireR, float tireW, int col, float a0, float a1) {
        float R = tireR + 0.10f, hw = tireW * 0.5f + 0.07f, th = 0.085f;
        b.fender(x, y, z, R, hw, th, a0, a1, 14, col, paint(170));
        // rolled lips along both edges, so the guard has real substance instead of a paper edge
        float Rm = R + th * 0.5f;
        int segs = 14;
        for (int sd = -1; sd <= 1; sd += 2) for (int i = 0; i < segs; i++) {
            float aa = a0 + (a1 - a0) * i / segs, ab = a0 + (a1 - a0) * (i + 1) / segs;
            b.tube(x + sd * hw, y + (float) Math.cos(aa) * Rm, z - (float) Math.sin(aa) * Rm, x + sd * hw, y + (float) Math.cos(ab) * Rm, z - (float) Math.sin(ab) * Rm, 0.052f, 0.052f, 6, col, col, false);
        }
    }

    private static void antenna(MeshBuilder b, float x, float y, float z, int flagCol) {
        // removed in 1.7: a toy antenna with a flag and a glowing ball does not belong on a realistic kart
    }

    private static void plate(MeshBuilder b, float x, float y, float z, float hw) {
        b.softBox(x, y, z, hw, 0.08f, 0.014f, 3f, 6, 4, WHITE, WHITE);
        b.box(x - hw * 0.4f, y, z + 0.014f, 0.025f, 0.05f, 0.004f, INK);
        b.box(x + hw * 0.4f, y, z + 0.014f, 0.025f, 0.05f, 0.004f, INK);
        b.box(x, y + 0.03f, z + 0.014f, hw * 0.35f, 0.012f, 0.004f, INK);
    }

    private static float sgnp(float v, float p) {
        float a = Math.abs(v);
        return a < 1e-6f ? 0f : (v < 0f ? -1f : 1f) * (float) Math.pow(a, p);
    }

    /** Point on the surface of a lofted body at ring angle th (0 = right flank, PI/2 = top, PI = left) and depth z, lifted along the outward normal. */
    private static void surf(float[][] sec, float z, float th, float lift, float[] out) {
        int i = 0;
        while (i + 2 < sec.length && z > sec[i + 1][0]) i++;
        float t = MathX.clamp((z - sec[i][0]) / (sec[i + 1][0] - sec[i][0]), 0f, 1f);
        float hw = sec[i][1] + (sec[i + 1][1] - sec[i][1]) * t, yb = sec[i][2] + (sec[i + 1][2] - sec[i][2]) * t, yt = sec[i][3] + (sec[i + 1][3] - sec[i][3]) * t;
        float c = (float) Math.cos(th), s = (float) Math.sin(th);
        float n = s >= 0f ? sec[i][4] + (sec[i + 1][4] - sec[i][4]) * t : sec[i][5] + (sec[i + 1][5] - sec[i][5]) * t;
        float ym = (yb + yt) * 0.5f, hh = (yt - yb) * 0.5f;
        float e = 2f / n;
        float px = hw * sgnp(c, e), py = hh * sgnp(s, e);
        float gx = sgnp(px / hw, n - 1f) / hw, gy = sgnp(py / hh, n - 1f) / hh;
        float gl = (float) Math.sqrt(gx * gx + gy * gy);
        if (gl < 1e-6f) { gx = 1f; gy = 0f; gl = 1f; }
        out[0] = px + gx / gl * lift; out[1] = ym + py + gy / gl * lift; out[2] = z;
    }

    /** A flame tongue painted on the flank of a lofted body: starts wide at zFront and tapers to a point at zBack. */
    private static void flameTongue(MeshBuilder b, float[][] sec, int side, float zFront, float zBack, float th0, float amp, float w0, float phase, int c0, int c1) {
        int n = 14;
        float[][] l = new float[n + 1][3], r = new float[n + 1][3];
        for (int i = 0; i <= n; i++) {
            float u = i / (float) n;
            float z = zFront + (zBack - zFront) * u;
            float c = th0 + amp * (float) Math.sin(u * 6.5f + phase);
            float w = w0 * (float) Math.pow(1f - u, 0.85f) * (0.8f + 0.2f * (float) Math.sin(u * 17f + phase));
            float a = c - w, bb = c + w;
            if (side < 0) { a = MathX.PI - a; bb = MathX.PI - bb; }
            surf(sec, z, a, 0.014f, l[i]);
            surf(sec, z, bb, 0.014f, r[i]);
        }
        for (int i = 0; i < n; i++) {
            int col = Col.mix(c0, c1, (i + 0.5f) / n);
            float cy = (sec[0][2] + sec[0][3]) * 0.5f;
            float[][] tri1 = {l[i], r[i], l[i + 1]}, tri2 = {r[i], r[i + 1], l[i + 1]};
            for (float[][] tr : new float[][][]{tri1, tri2}) {
                float ux = tr[1][0] - tr[0][0], uy = tr[1][1] - tr[0][1], uz = tr[1][2] - tr[0][2], vx = tr[2][0] - tr[0][0], vy = tr[2][1] - tr[0][1], vz = tr[2][2] - tr[0][2];
                float nx = uy * vz - uz * vy;
                // outward means pointing away from the body axis in x for flank decals
                boolean flip = nx * side < 0f;
                float[] p1 = flip ? tr[2] : tr[1], p2 = flip ? tr[1] : tr[2];
                b.flatTri(tr[0][0], tr[0][1], tr[0][2], p1[0], p1[1], p1[2], p2[0], p2[1], p2[2], col);
            }
        }
    }

    private static void axle(MeshBuilder b, float y, float z, float halfSpan) {
        b.tube(-halfSpan, y, z, halfSpan, y, z, 0.05f, 0.05f, 8, DARK, DARK, false);
    }

    // ---------------------------------------------------------------- 0: Dune Hopper (balanced buggy)

    private static final float[][] DUNE = {
            {-1.62f, 0.15f, 0.40f, 0.58f, 2.4f, 2.4f},
            {-1.48f, 0.34f, 0.34f, 0.66f, 2.8f, 2.6f},
            {-1.20f, 0.50f, 0.30f, 0.76f, 3.0f, 3.0f},
            {-0.80f, 0.60f, 0.30f, 0.84f, 3.2f, 3.2f},
            {-0.30f, 0.64f, 0.30f, 0.86f, 3.4f, 3.4f},
            {0.30f, 0.66f, 0.32f, 0.90f, 3.4f, 3.4f},
            {0.90f, 0.62f, 0.34f, 0.94f, 3.2f, 3.2f},
            {1.30f, 0.48f, 0.38f, 0.90f, 3.0f, 3.0f},
            {1.50f, 0.26f, 0.44f, 0.80f, 2.4f, 2.4f}};

    private static void duneHopper(MeshBuilder b) {
        int p = paint(248), pd = paint(190);
        b.loft(DUNE, 20, paint(150), p, true, true);
        topStripe(b, DUNE, -1.50f, -0.42f, 0.12f, WHITE, 0f);
        topStripe(b, DUNE, 0.86f, 1.40f, 0.12f, WHITE, 0f);
        axle(b, 0.42f, -0.95f, 0.8f);
        axle(b, 0.46f, 0.95f, 0.8f);
        for (int s = -1; s <= 1; s += 2) {
            arch(b, s * 0.84f, 0.42f, -0.95f, 0.42f, 0.34f, p, -0.95f, 1.10f);
            arch(b, s * 0.84f, 0.46f, 0.95f, 0.46f, 0.34f, p, -1.10f, 0.95f);
            headlamp(b, s * 0.27f, 0.57f, -1.47f, 0.105f);
            taillamp(b, s * 0.30f, 0.66f, 1.37f, 0.10f, 0.05f);
            // roll hoop and braces
            b.tube(s * 0.55f, 0.80f, 0.56f, s * 0.50f, 1.86f, 0.46f, 0.05f, 0.05f, 7, STEEL, CHROME, true);
            b.tube(s * 0.50f, 1.86f, 0.46f, s * 0.44f, 0.98f, 1.12f, 0.04f, 0.04f, 8, CHROME, STEEL, true);
            b.sphere(s * 0.50f, 1.86f, 0.46f, 0.055f, 7, 4, STEEL);
            // exhausts
            exhaust(b, s * 0.26f, 0.92f, 1.04f, 0f, -0.04f, 0.90f, 0.07f);
            // front strut
            b.tube(s * 0.50f, 0.50f, -1.40f, s * 0.50f, 0.44f, -1.62f, 0.035f, 0.035f, 6, STEEL, STEEL, false);
        }
        b.tube(0, 1.86f, 0.46f, 0, 1.86f, 0.46f, 0.05f, 0.05f, 8, CHROME, CHROME, false);
        b.tube(-0.50f, 1.86f, 0.46f, 0.50f, 1.86f, 0.46f, 0.05f, 0.05f, 8, CHROME, STEEL, true);
        b.tube(-0.52f, 0.46f, -1.64f, 0.52f, 0.46f, -1.64f, 0.05f, 0.05f, 8, STEEL, CHROME, true);
        // engine block with air filters behind the seat
        b.softBox(0, 0.98f, 1.02f, 0.36f, 0.15f, 0.24f, 3.2f, 12, 6, fixed(40, 44, 52), fixed(86, 92, 104));
        for (int s = -1; s <= 1; s += 2) b.cyl(s * 0.17f, 1.10f, 1.02f, 0.085f, 0.07f, 0.11f, 8, CHROME, STEEL, true, true);
        cockpit(b, 0, 0.90f, 0.22f, 0.44f, 0.56f, p);
        seatBack(b, 1.00f, 0.62f, 0.34f, 0.17f);
        steering(b, 0, 0.90f, -0.20f);
        plate(b, 0, 0.62f, 1.44f, 0.20f);
        antenna(b, 0.70f, 0.88f, 1.00f, p);
    }

    // ---------------------------------------------------------------- 1: Sand Viper (low, sleek and fast)

    private static final float[][] VIPER = {
            {-2.10f, 0.05f, 0.38f, 0.46f, 2.2f, 2.2f},
            {-1.85f, 0.15f, 0.34f, 0.50f, 2.4f, 2.4f},
            {-1.40f, 0.30f, 0.30f, 0.58f, 2.8f, 2.6f},
            {-0.80f, 0.42f, 0.28f, 0.66f, 3.0f, 3.0f},
            {-0.20f, 0.50f, 0.28f, 0.72f, 3.2f, 3.2f},
            {0.40f, 0.52f, 0.28f, 0.74f, 3.2f, 3.2f},
            {0.95f, 0.46f, 0.30f, 0.72f, 3.0f, 3.0f},
            {1.40f, 0.34f, 0.34f, 0.68f, 2.6f, 2.6f},
            {1.62f, 0.16f, 0.40f, 0.60f, 2.2f, 2.2f}};

    private static void sandViper(MeshBuilder b) {
        int p = paint(248), pd = paint(172), gold = fixed(255, 196, 40);
        b.loft(VIPER, 20, paint(150), p, true, true);
        topStripe(b, VIPER, -2.00f, -0.40f, 0.045f, gold, -0.11f);
        topStripe(b, VIPER, -2.00f, -0.40f, 0.045f, gold, 0.11f);
        topStripe(b, VIPER, 0.90f, 1.55f, 0.045f, gold, -0.11f);
        topStripe(b, VIPER, 0.90f, 1.55f, 0.045f, gold, 0.11f);
        axle(b, 0.36f, -1.05f, 0.74f);
        axle(b, 0.42f, 1.05f, 0.74f);
        for (int s = -1; s <= 1; s += 2) {
            // side pods with dark intakes bridging body and wheels
            b.softBox(s * 0.62f, 0.50f, 0.10f, 0.15f, 0.17f, 0.66f, 3f, 12, 6, pd, p);
            b.box(s * 0.62f, 0.54f, -0.46f, 0.151f, 0.07f, 0.03f, BLACK);
            arch(b, s * 0.80f, 0.36f, -1.05f, 0.36f, 0.28f, p, -0.80f, 1.05f);
            arch(b, s * 0.80f, 0.42f, 1.05f, 0.42f, 0.28f, p, -1.00f, 0.85f);
            headlamp(b, s * 0.17f, 0.50f, -1.78f, 0.075f);
            taillamp(b, s * 0.26f, 0.60f, 1.52f, 0.08f, 0.04f);
            // rear wing: pylons and end plates
            b.tube(s * 0.20f, 0.66f, 1.36f, s * 0.20f, 1.18f, 1.52f, 0.035f, 0.03f, 6, STEEL, CHROME, true);
            b.softBox(s * 0.66f, 1.22f, 1.52f, 0.025f, 0.16f, 0.24f, 3f, 6, 5, pd, pd);
            // exhausts tucked under the tail
            exhaust(b, s * 0.17f, 0.46f, 1.46f, 0f, 0.02f, 0.44f, 0.055f);
            // front wing end plates
            b.softBox(s * 0.64f, 0.38f, -1.98f, 0.025f, 0.09f, 0.17f, 3f, 6, 4, pd, pd);
        }
        b.softBox(0, 1.22f, 1.52f, 0.66f, 0.03f, 0.22f, 4f, 14, 5, pd, p);
        b.softBox(0, 0.32f, -1.98f, 0.64f, 0.025f, 0.17f, 4f, 14, 4, pd, p);
        // tinted aero screen, airbox behind the driver
        b.push().translate(0, 0.94f, -0.62f).rotX(-0.95f).softBox(0, 0, 0, 0.27f, 0.015f, 0.14f, 3f, 10, 4, GLASS, fixed(190, 226, 244)).pop();
        b.softBox(0, 1.02f, 0.86f, 0.17f, 0.20f, 0.15f, 3f, 10, 6, fixed(34, 36, 44), fixed(70, 76, 92));
        b.softBox(0, 1.02f, 0.72f, 0.12f, 0.13f, 0.03f, 3f, 8, 4, BLACK, BLACK);
        cockpit(b, 0, 0.74f, 0.25f, 0.36f, 0.50f, pd);
        steering(b, 1, 0.76f, -0.50f);
        plate(b, 0, 1.22f, 1.78f, 0.17f);
    }

    // ---------------------------------------------------------------- 2: Rock Crusher (monster truck)

    private static final float[][] CRUSH = {
            {-1.55f, 0.46f, 0.92f, 1.40f, 3.6f, 3.2f},
            {-1.40f, 0.58f, 0.90f, 1.52f, 3.8f, 3.4f},
            {-0.95f, 0.66f, 0.90f, 1.62f, 3.6f, 3.4f},
            {-0.40f, 0.68f, 0.90f, 1.66f, 3.6f, 3.4f},
            {0.20f, 0.68f, 0.90f, 1.62f, 3.6f, 3.4f},
            {0.80f, 0.68f, 0.92f, 1.58f, 3.6f, 3.4f},
            {1.30f, 0.62f, 0.94f, 1.52f, 3.6f, 3.4f},
            {1.55f, 0.50f, 0.96f, 1.46f, 3.4f, 3.2f}};

    private static void rockCrusher(MeshBuilder b) {
        int p = paint(246), pd = paint(170);
        b.loft(CRUSH, 20, paint(140), p, true, true);
        topStripe(b, CRUSH, -1.50f, -0.50f, 0.13f, WHITE, 0f);
        topStripe(b, CRUSH, 0.85f, 1.50f, 0.13f, WHITE, 0f);
        // chassis rails, axles and differentials
        for (int s = -1; s <= 1; s += 2) b.box(s * 0.42f, 0.82f, 0f, 0.07f, 0.07f, 1.45f, DARK);
        for (int z = -1; z <= 1; z += 2) {
            axle(b, 0.64f, z * 1.0f, 0.95f);
            b.sphere(0, 0.64f, z * 1.0f, 0.17f, 8, 6, fixed(66, 72, 84));
        }
        for (int s = -1; s <= 1; s += 2) {
            arch(b, s * 1.02f, 0.64f, -1.00f, 0.64f, 0.46f, p, -0.95f, 1.00f);
            arch(b, s * 1.02f, 0.64f, 1.00f, 0.64f, 0.46f, p, -1.00f, 0.95f);
            headlamp(b, s * 0.40f, 1.18f, -1.56f, 0.13f);
            headlamp(b, s * 0.40f, 0.98f, -1.62f, 0.07f);
            taillamp(b, s * 0.40f, 1.18f, 1.60f, 0.12f, 0.06f);
            // roll cage: tall rear hoop, lower front hoop, roof rails
            b.tube(s * 0.62f, 1.55f, 0.84f, s * 0.60f, 2.75f, 0.78f, 0.06f, 0.06f, 7, STEEL, CHROME, true);
            b.tube(s * 0.62f, 1.62f, -0.18f, s * 0.60f, 2.40f, -0.12f, 0.06f, 0.06f, 7, STEEL, CHROME, true);
            b.tube(s * 0.60f, 2.75f, 0.78f, s * 0.60f, 2.55f, -0.12f, 0.055f, 0.055f, 7, CHROME, CHROME, true);
            b.sphere(s * 0.60f, 2.75f, 0.78f, 0.065f, 7, 4, STEEL);
            b.sphere(s * 0.60f, 2.40f, -0.12f, 0.065f, 7, 4, STEEL);
            b.tube(s * 0.62f, 1.60f, 0.84f, s * 0.52f, 1.60f, 1.50f, 0.045f, 0.045f, 6, STEEL, STEEL, false);
            // exhaust stacks behind the cab
            exhaust(b, s * 0.44f, 1.52f, 1.18f, 0f, 1.20f, 0f, 0.075f);
            // mud flaps
            b.box(s * 1.02f, 0.46f, 1.72f, 0.20f, 0.20f, 0.015f, DARK);
            b.box(s * 1.02f, 0.46f, -1.72f, 0.20f, 0.20f, 0.015f, DARK);
        }
        b.tube(-0.60f, 2.75f, 0.78f, 0.60f, 2.75f, 0.78f, 0.055f, 0.055f, 7, CHROME, CHROME, true);
        b.tube(-0.60f, 2.40f, -0.12f, 0.60f, 2.40f, -0.12f, 0.055f, 0.055f, 7, CHROME, CHROME, true);
        // light bar on the front hoop
        b.box(0, 2.52f, -0.18f, 0.50f, 0.06f, 0.05f, DARK);
        for (int i = 0; i < 5; i++) b.sphere(-0.40f + i * 0.20f, 2.52f, -0.25f, 0.075f, 0.075f, 0.04f, 8, 5, LIGHT_DIM, LIGHT);
        // bull bar and skid plate
        b.tube(-0.52f, 1.02f, -1.68f, 0.52f, 1.02f, -1.68f, 0.07f, 0.07f, 8, STEEL, CHROME, true);
        b.tube(-0.52f, 1.42f, -1.68f, 0.52f, 1.42f, -1.68f, 0.06f, 0.06f, 8, STEEL, CHROME, true);
        for (int s = -1; s <= 1; s += 2) b.tube(s * 0.52f, 0.98f, -1.68f, s * 0.52f, 1.46f, -1.68f, 0.06f, 0.06f, 7, STEEL, CHROME, true);
        b.softBox(0, 0.96f, -1.50f, 0.42f, 0.10f, 0.22f, 3f, 10, 5, DARK, DARK);
        cockpit(b, 0, 1.60f, 0.38f, 0.50f, 0.58f, p);
        seatBack(b, 1.78f, 0.88f, 0.38f, 0.26f);
        steering(b, 2, 1.62f, -0.10f);
        plate(b, 0, 1.18f, 1.62f, 0.20f);
    }

    // ---------------------------------------------------------------- 3: Wave Runner (round, sleek hull)

    private static final float[][] WAVE = {
            {-1.75f, 0.07f, 0.40f, 0.50f, 2.2f, 2.2f},
            {-1.52f, 0.27f, 0.34f, 0.66f, 2.3f, 2.2f},
            {-1.05f, 0.47f, 0.30f, 0.80f, 2.5f, 2.4f},
            {-0.45f, 0.60f, 0.28f, 0.88f, 2.7f, 2.5f},
            {0.20f, 0.64f, 0.28f, 0.92f, 2.7f, 2.5f},
            {0.80f, 0.58f, 0.30f, 0.90f, 2.7f, 2.5f},
            {1.28f, 0.44f, 0.34f, 0.82f, 2.5f, 2.4f},
            {1.55f, 0.22f, 0.40f, 0.72f, 2.2f, 2.2f}};

    private static void waveRunner(MeshBuilder b) {
        int p = paint(248), pd = paint(176), yel = fixed(255, 214, 0);
        b.loft(WAVE, 22, paint(150), p, true, true);
        topStripe(b, WAVE, -1.60f, -0.40f, 0.05f, yel, -0.13f);
        topStripe(b, WAVE, -1.60f, -0.40f, 0.05f, yel, 0.13f);
        topStripe(b, WAVE, 0.80f, 1.45f, 0.05f, yel, -0.13f);
        topStripe(b, WAVE, 0.80f, 1.45f, 0.05f, yel, 0.13f);
        axle(b, 0.40f, -0.90f, 0.76f);
        axle(b, 0.40f, 0.90f, 0.76f);
        for (int s = -1; s <= 1; s += 2) {
            arch(b, s * 0.82f, 0.40f, -0.90f, 0.40f, 0.32f, p, -0.85f, 1.00f);
            arch(b, s * 0.82f, 0.40f, 0.90f, 0.40f, 0.32f, p, -1.00f, 0.85f);
            headlamp(b, s * 0.26f, 0.58f, -1.48f, 0.09f);
            taillamp(b, s * 0.30f, 0.62f, 1.38f, 0.09f, 0.045f);
            // small stabiliser fins at the tail corners
            b.push().translate(s * 0.50f, 0.98f, 1.20f).rotZ(-s * 0.55f).softBox(0, 0, 0, 0.025f, 0.15f, 0.20f, 3f, 6, 4, pd, p).pop();
        }
        // tall tail fin, jet nozzle, curved windscreen
        b.push().translate(0, 1.26f, 1.18f).rotX(0.50f).softBox(0, 0, 0, 0.04f, 0.36f, 0.30f, 3f, 10, 7, pd, p).pop();
        b.cyl(0, 0.54f, 1.52f, 0.10f, 0.07f, 0.0f + 0.14f, 10, DARK, BLACK, true, true);
        b.push().translate(0, 1.10f, -0.42f).rotX(-0.80f).softBox(0, 0, 0, 0.40f, 0.02f, 0.17f, 3f, 12, 4, GLASS, fixed(196, 230, 246)).pop();
        b.softBox(0, 0.36f, -1.54f, 0.24f, 0.06f, 0.20f, 3f, 10, 4, DARK, DARK);
        cockpit(b, 0, 0.90f, 0.30f, 0.42f, 0.52f, pd);
        seatBack(b, 1.04f, 0.74f, 0.34f, 0.16f);
        steering(b, 3, 0.90f, -0.20f);
        plate(b, 0, 0.60f, 1.52f, 0.14f);
    }

    // ---------------------------------------------------------------- 4: Lava Rod (hot rod with a blown engine)

    private static final float[][] ROD = {
            {-1.95f, 0.10f, 0.48f, 0.64f, 2.4f, 2.4f},
            {-1.70f, 0.28f, 0.42f, 0.74f, 2.8f, 2.6f},
            {-1.20f, 0.40f, 0.38f, 0.84f, 3.0f, 3.0f},
            {-0.60f, 0.44f, 0.36f, 0.90f, 3.2f, 3.0f},
            {-0.10f, 0.54f, 0.36f, 0.94f, 3.2f, 3.0f},
            {0.50f, 0.60f, 0.36f, 1.00f, 3.0f, 3.0f},
            {1.00f, 0.62f, 0.38f, 1.06f, 3.0f, 3.0f},
            {1.40f, 0.50f, 0.42f, 1.04f, 2.8f, 2.8f},
            {1.64f, 0.26f, 0.46f, 0.94f, 2.4f, 2.4f}};

    private static void lavaRod(MeshBuilder b) {
        int p = paint(248), pd = paint(176);
        int fl0 = fixed(255, 106, 20), fl1 = fixed(255, 214, 60);
        b.loft(ROD, 22, paint(150), p, true, true);
        axle(b, 0.36f, -1.00f, 0.80f);
        axle(b, 0.52f, 1.00f, 0.80f);
        for (int s = -1; s <= 1; s += 2) {
            // flames licking back along the hood and flanks
            flameTongue(b, ROD, s, -1.82f, -0.25f, 0.02f, 0.10f, 0.60f, 0.0f, fl0, fl1);
            flameTongue(b, ROD, s, -1.75f, -0.55f, 0.78f, 0.08f, 0.34f, 1.7f, fl0, fl1);
            flameTongue(b, ROD, s, -1.75f, -0.62f, -0.62f, 0.08f, 0.30f, 3.1f, fl0, fl1);
            arch(b, s * 0.86f, 0.52f, 1.00f, 0.52f, 0.34f, p, -1.10f, 0.95f);
            // side pipes
            b.tube(s * 0.62f, 0.44f, -1.10f, s * 0.62f, 0.44f, 0.85f, 0.055f, 0.055f, 8, STEEL, CHROME, true);
            for (int k = 0; k < 4; k++) b.tube(s * 0.46f, 0.72f + k * 0.02f, -1.30f + k * 0.26f, s * 0.60f, 0.46f, -1.30f + k * 0.26f, 0.035f, 0.035f, 5, CHROME, STEEL, false);
            headlamp(b, s * 0.34f, 0.74f, -1.62f, 0.10f);
            taillamp(b, s * 0.32f, 0.70f, 1.52f, 0.10f, 0.05f);
            // tail fins and front springs
            b.push().translate(s * 0.50f, 1.12f, 1.26f).rotZ(-s * 0.35f).softBox(0, 0, 0, 0.03f, 0.16f, 0.24f, 3f, 6, 4, pd, p).pop();
            b.tube(s * 0.55f, 0.38f, -1.00f, s * 0.80f, 0.38f, -1.00f, 0.03f, 0.03f, 5, DARK, DARK, false);
        }
        // blown engine on the hood: chrome blower, intake and air filters
        b.softBox(0, 1.02f, -0.92f, 0.22f, 0.14f, 0.34f, 3f, 12, 6, fixed(104, 110, 122), fixed(196, 202, 214));
        b.softBox(0, 1.20f, -0.92f, 0.12f, 0.06f, 0.20f, 3f, 10, 5, BLACK, fixed(50, 52, 60));
        for (int i = 0; i < 3; i++) b.cyl(0, 0.92f, -1.14f + i * 0.20f, 0.0f + 0.09f, 0.08f, 0.0f + 0.08f, 8, STEEL, CHROME, false, true);
        // front bumper and grille
        b.tube(-0.38f, 0.50f, -1.98f, 0.38f, 0.50f, -1.98f, 0.045f, 0.045f, 7, STEEL, CHROME, true);
        b.softBox(0, 0.56f, -1.94f, 0.17f, 0.10f, 0.05f, 3f, 8, 4, DARK, BLACK);
        cockpit(b, 0, 1.01f, 0.52f, 0.42f, 0.52f, p);
        seatBack(b, 1.26f, 0.98f, 0.36f, 0.24f);
        // chrome roll hoop
        for (int s = -1; s <= 1; s += 2) b.tube(s * 0.46f, 0.98f, 0.98f, s * 0.42f, 1.78f, 1.04f, 0.045f, 0.045f, 7, STEEL, CHROME, true);
        b.tube(-0.42f, 1.78f, 1.04f, 0.42f, 1.78f, 1.04f, 0.045f, 0.045f, 7, CHROME, STEEL, true);
        steering(b, 4, 1.02f, -0.05f);
        plate(b, 0, 0.72f, 1.68f, 0.18f);
    }

    private static float[] reverse(float[] a) {
        float[] r = new float[a.length];
        for (int i = 0; i < a.length; i++) r[i] = a[a.length - 1 - i];
        return r;
    }

    // ---------------------------------------------------------------- 5: Jungle Rover (safari jeep)

    private static final float[][] ROVER = {
            {-1.60f, 0.42f, 0.56f, 0.94f, 3.8f, 3.4f},
            {-1.46f, 0.60f, 0.52f, 1.02f, 3.8f, 3.6f},
            {-1.00f, 0.70f, 0.50f, 1.08f, 3.8f, 3.6f},
            {-0.30f, 0.74f, 0.50f, 1.12f, 3.8f, 3.6f},
            {0.40f, 0.74f, 0.50f, 1.10f, 3.8f, 3.6f},
            {1.00f, 0.74f, 0.52f, 1.08f, 3.8f, 3.6f},
            {1.42f, 0.70f, 0.54f, 1.04f, 3.8f, 3.6f},
            {1.54f, 0.60f, 0.56f, 0.98f, 3.8f, 3.4f}};

    private static void jungleRover(MeshBuilder b) {
        int p = paint(248), pd = paint(176);
        int canvas = fixed(214, 188, 134), canvasD = fixed(170, 146, 100), olive = fixed(86, 96, 60);
        b.loft(ROVER, 20, paint(150), p, true, true);
        // dark cladding rails along the flanks
        for (int s = -1; s <= 1; s += 2) {
            b.softBox(s * 0.75f, 0.66f, 0.05f, 0.035f, 0.075f, 1.30f, 3f, 6, 5, DARK, DARK);
            arch(b, s * 0.94f, 0.52f, -1.00f, 0.52f, 0.38f, p, -0.95f, 1.00f);
            arch(b, s * 0.94f, 0.52f, 1.00f, 0.52f, 0.38f, p, -1.00f, 0.95f);
            headlamp(b, s * 0.46f, 0.80f, -1.62f, 0.13f);
            taillamp(b, s * 0.50f, 0.80f, 1.55f, 0.10f, 0.055f);
            // safari cage with a canvas roof
            b.tube(s * 0.74f, 1.08f, 0.86f, s * 0.72f, 2.50f, 0.80f, 0.05f, 0.05f, 7, olive, olive, true);
            b.tube(s * 0.74f, 1.12f, -0.34f, s * 0.72f, 2.42f, -0.28f, 0.05f, 0.05f, 7, olive, olive, true);
            b.tube(s * 0.72f, 2.50f, 0.80f, s * 0.72f, 2.42f, -0.28f, 0.045f, 0.045f, 7, olive, olive, true);
            b.sphere(s * 0.72f, 2.50f, 0.80f, 0.055f, 7, 4, olive);
            b.sphere(s * 0.72f, 2.42f, -0.28f, 0.055f, 7, 4, olive);
            // extra lamps on the bull bar
            b.sphere(s * 0.74f, 0.66f, -1.64f, 0.075f, 0.075f, 0.04f, 8, 5, LIGHT_DIM, LIGHT);
        }
        b.push().translate(0, 2.54f, 0.26f).rotX(0.0f).softBox(0, 0, 0, 0.88f, 0.045f, 1.12f, 4f, 14, 5, canvasD, canvas).pop();
        for (int i = -2; i <= 2; i++) b.box(i * 0.28f, 2.60f, 0.26f, 0.045f, 0.008f, 1.02f, fixed(240, 228, 196));
        b.tube(-0.72f, 2.46f, 0.80f, 0.72f, 2.46f, 0.80f, 0.045f, 0.045f, 7, olive, olive, true);
        b.tube(-0.72f, 2.38f, -0.28f, 0.72f, 2.38f, -0.28f, 0.045f, 0.045f, 7, olive, olive, true);
        // windscreen frame with glass
        b.tube(-0.66f, 1.92f, -0.62f, 0.66f, 1.92f, -0.62f, 0.035f, 0.035f, 6, olive, olive, true);
        b.tube(-0.66f, 1.14f, -0.40f, -0.66f, 1.92f, -0.62f, 0.035f, 0.035f, 6, olive, olive, true);
        b.tube(0.66f, 1.14f, -0.40f, 0.66f, 1.92f, -0.62f, 0.035f, 0.035f, 6, olive, olive, true);
        // grille, bull bar and winch
        for (int i = 0; i < 4; i++) b.box(0, 0.62f + i * 0.08f, -1.61f, 0.30f, 0.025f, 0.02f, BLACK);
        b.tube(-0.74f, 0.60f, -1.72f, 0.74f, 0.60f, -1.72f, 0.06f, 0.06f, 8, STEEL, CHROME, true);
        b.softBox(0, 0.48f, -1.66f, 0.20f, 0.09f, 0.10f, 3f, 8, 4, DARK, DARK);
        // spare tyre on the back, snorkel up the right pillar
        b.push().translate(0, 1.00f, 1.74f).rotX(MathX.PI / 2f).torus(0, 0, 0, 0.36f, 0.15f, 16, 7, fixed(32, 32, 36)).pop();
        b.push().translate(0, 1.00f, 1.80f).rotX(MathX.PI / 2f).cyl(0, 0, 0, 0.26f, 0.26f, 0.02f, 12, pd, p, true, true).pop();
        b.tube(0.80f, 0.90f, -0.78f, 0.84f, 2.30f, -0.78f, 0.05f, 0.05f, 7, BLACK, DARK, true);
        b.tube(0.84f, 2.30f, -0.78f, 0.84f, 2.40f, -0.60f, 0.05f, 0.05f, 7, DARK, BLACK, true);
        cockpit(b, 0, 1.10f, 0.30f, 0.50f, 0.58f, p);
        seatBack(b, 1.34f, 0.82f, 0.38f, 0.24f);
        steering(b, 5, 1.12f, -0.30f);
        plate(b, 0, 0.74f, 1.56f, 0.20f);
        antenna(b, -0.78f, 1.10f, 1.30f, p);
    }

    // ---------------------------------------------------------------- wheels

    public static MeshData wheel(int type, boolean rear) {
        int t = Math.floorMod(type, TYPES);
        float r = rear ? REAR_R[t] : FRONT_R[t], w = WHEEL_W[t];
        MeshBuilder b = new MeshBuilder();
        boolean off = t == 2 || t == 5;
        int rubber = fixed(24, 24, 27), wall = fixed(38, 38, 42), groove = fixed(12, 12, 14), lug = fixed(44, 44, 48);
        float h = w * 0.5f, cr = w * 0.22f, rimR = r * (off ? 0.54f : 0.64f);
        // tyre: convex side walls, rounded shoulders, flat tread
        ArrayList<float[]> prof = new ArrayList<>();
        ArrayList<Integer> pc = new ArrayList<>();
        prof.add(new float[]{rimR * 0.97f, -h * 0.80f}); pc.add(rubber);
        prof.add(new float[]{rimR + (r - rimR) * 0.35f, -h * 0.97f}); pc.add(wall);
        prof.add(new float[]{rimR + (r - rimR) * 0.70f, -h}); pc.add(wall);
        for (int i = 0; i <= 4; i++) {
            float a = -MathX.PI / 2f + (MathX.PI / 2f) * i / 4f;
            prof.add(new float[]{r - cr + cr * (float) Math.cos(a), -h + cr + cr * (float) Math.sin(a)}); pc.add(i < 2 ? wall : rubber);
        }
        for (int i = 0; i <= 4; i++) {
            float a = (MathX.PI / 2f) * i / 4f;
            prof.add(new float[]{r - cr + cr * (float) Math.cos(a), h - cr + cr * (float) Math.sin(a)}); pc.add(i > 2 ? wall : rubber);
        }
        prof.add(new float[]{rimR + (r - rimR) * 0.70f, h}); pc.add(wall);
        prof.add(new float[]{rimR + (r - rimR) * 0.35f, h * 0.97f}); pc.add(wall);
        prof.add(new float[]{rimR * 0.97f, h * 0.80f}); pc.add(rubber);
        int[] cols = new int[pc.size()];
        for (int i = 0; i < cols.length; i++) cols[i] = pc.get(i);
        b.push().rotZ(MathX.PI / 2f).lathe(0, 0, 0, prof.toArray(new float[0][]), 18, cols).pop();
        if (!off) {
            // road tyre: circumferential grooves
            b.push().rotZ(MathX.PI / 2f).torus(0, 0, 0, r - 0.004f, 0.010f, 20, 3, groove).pop();
        } else {
            // off-road tyre: two staggered rows of lugs
            int blocks = t == 2 ? 14 : 12;
            for (int i = 0; i < blocks; i++) for (int sd = -1; sd <= 1; sd += 2) {
                float a = MathX.TAU * (i + (sd > 0 ? 0.5f : 0f)) / blocks;
                b.push().rotX(a).translate(0, r, 0).box(sd * w * 0.21f, 0.010f, 0, w * 0.19f, 0.040f, r * 0.10f, lug).pop();
            }
        }
        // alloy rim: barrel, polished lip, spokes, hub with lug nuts, brake disc and caliper behind the spokes
        int alloy = off ? fixed(86, 90, 100) : fixed(190, 194, 202), alloyD = Col.scale(alloy, 0.5f), steelC = fixed(150, 154, 162);
        b.push().rotZ(MathX.PI / 2f).cyl(0, -h * 0.84f, 0, rimR, rimR, h * 1.68f, 14, alloyD, alloyD, true, true).pop();
        for (int sd = -1; sd <= 1; sd += 2) {
            float fx = sd * h * 0.86f;
            b.push().rotZ(MathX.PI / 2f).translate(0, -fx, 0).torus(0, 0, 0, rimR, 0.018f, 14, 3, off ? steelC : fixed(214, 218, 224)).pop();
            b.push().rotZ(MathX.PI / 2f).translate(0, -sd * h * 0.52f, 0).cyl(0, -0.012f, 0, rimR * 0.80f, rimR * 0.80f, 0.024f, 14, fixed(96, 98, 104), fixed(120, 122, 130), true, true).pop();
            if (!off) b.push().rotZ(MathX.PI / 2f).translate(0, -sd * h * 0.56f, 0).rotY(0.6f).softBox(0, 0, rimR * 0.60f, 0.05f, 0.04f, 0.10f, 3f, 6, 4, fixed(188, 28, 34), fixed(226, 50, 54)).pop();
            int n = off ? 6 : 8;
            for (int i = 0; i < n; i++) {
                float a = MathX.TAU * i / n + (sd > 0 ? 0f : 0.3f);
                b.push().rotZ(MathX.PI / 2f).translate(0, -fx, 0).rotY(a).box(0, 0, rimR * 0.52f, off ? 0.040f : 0.022f, 0.012f, rimR * 0.44f, alloy).pop();
            }
            b.push().rotZ(MathX.PI / 2f).translate(0, -fx, 0).cyl(0, -0.02f, 0, rimR * 0.22f, rimR * 0.20f, 0.05f, 10, alloy, steelC, true, true).pop();
            for (int i = 0; i < 4; i++) {
                float a = MathX.TAU * i / 4f;
                b.push().rotZ(MathX.PI / 2f).translate(0, -fx - sd * 0.02f, 0).rotY(a).translate(0, 0, rimR * 0.13f).cyl(0, 0, 0, 0.015f, 0.015f, 0.02f, 4, steelC, steelC, true, true).pop();
            }
        }
        return b.build();
    }

    // ---------------------------------------------------------------- drivers

    private static final int[] SKIN = {0xFFD6AA, 0x8D5C3C, 0xFFC8A0, 0xDCAA78, 0x5A3C28, 0xFADCBE};
    private static final int[] SHIRT = {0xE63C32, 0xFABE28, 0x3278E6, 0x3CBE6E, 0xB450DC, 0xF07828};

    /** Polyline of small tubes (with round joints) through the given points. */
    private static void path(MeshBuilder b, float[][] pts, float r, int color) {
        for (int i = 0; i + 1 < pts.length; i++) b.tube(pts[i][0], pts[i][1], pts[i][2], pts[i + 1][0], pts[i + 1][1], pts[i + 1][2], r, r, 5, color, color, false);
        for (float[] p : pts) b.sphere(p[0], p[1], p[2], r, 5, 3, color);
    }

    /** Arc in the YZ plane (a = 0 front, PI/2 top, PI back) on an ellipsoid of radii (ry, rz), centred at (cx, cy, cz). */
    private static void arcYZ(MeshBuilder b, float cx, float cy, float cz, float ry, float rz, float a0, float a1, float r, int color, int n) {
        float[][] pts = new float[n + 1][];
        for (int i = 0; i <= n; i++) {
            float a = a0 + (a1 - a0) * i / n;
            pts[i] = new float[]{cx, cy + ry * (float) Math.sin(a), cz - rz * (float) Math.cos(a)};
        }
        path(b, pts, r, color);
    }

    private static float[] sph(float cx, float cy, float cz, float rx, float ry, float rz, float ph, float th) {
        return new float[]{cx + rx * (float) (Math.cos(ph) * Math.cos(th)), cy + ry * (float) Math.sin(ph), cz + rz * (float) (Math.cos(ph) * Math.sin(th))};
    }

    /** Open-face racing helmet (or hair cap): dome with the face window cut out and a trim band along the opening. */
    private static void helmet(MeshBuilder b, float cx, float cy, float cz, float rad, int shell, int trim, float phi0, int kW) {
        int segs = 20, rings = 7;
        b.domeOpen(cx, cy, cz, rad, rad, rad, segs, rings, phi0, Col.scale(shell, 0.74f), shell, 12, 18, kW);
        float step = (MathX.PI / 2f - phi0) / rings;
        float rr = rad * 1.006f;
        float topPh = phi0 + step * kW;
        float thL = MathX.TAU * 12f / segs, thR = MathX.TAU * 18f / segs;
        java.util.ArrayList<float[]> l = new java.util.ArrayList<>();
        l.add(sph(cx, cy, cz, rr, rr, rr, phi0, thL));
        l.add(sph(cx, cy, cz, rr, rr, rr, topPh, thL));
        for (int i = 13; i <= 17; i++) l.add(sph(cx, cy, cz, rr, rr, rr, topPh, MathX.TAU * i / segs));
        l.add(sph(cx, cy, cz, rr, rr, rr, topPh, thR));
        l.add(sph(cx, cy, cz, rr, rr, rr, phi0, thR));
        path(b, l.toArray(new float[0][]), 0.02f, trim);
        // rubber trim around the back of the bottom edge
        java.util.ArrayList<float[]> bk = new java.util.ArrayList<>();
        for (int i = 18; i <= 32; i += 2) bk.add(sph(cx, cy, cz, rr, rr, rr, phi0, MathX.TAU * i / segs));
        path(b, bk.toArray(new float[0][]), 0.02f, trim);
    }

    /** Driver in seat space: origin at the seat, forward -Z. */
    private static final int[] SUIT = {0xC9302A, 0xE0A02A, 0x2F67C8, 0x2E9C5A, 0x8A3FB0, 0xD9651E};
    private static final int[] STRIPE = {0xF4F4F4, 0xE8508A, 0x1F5FBF, 0xF6F6F6, 0x8A3FC0, 0xF2C230};

    private static int fx(int hex, float k) {
        return Col.rgba(MathX.clamp((int) (((hex >> 16) & 255) * k), 0, 255), MathX.clamp((int) (((hex >> 8) & 255) * k), 0, 255), MathX.clamp((int) ((hex & 255) * k), 0, 255), 0);
    }

    /** Curved patch on an ellipsoid (helmet visor, stripes): th = angle around the vertical axis (0 = front, -Z), ph = elevation. */
    private static void ellipsoidPatch(MeshBuilder b, float cx, float cy, float cz, float rx, float ry, float rz, float th0, float th1, float ph0, float ph1, int nt, int np, float lift, int col) {
        ellipsoidPatch(b, cx, cy, cz, rx, ry, rz, th0, th1, ph0, ph1, nt, np, lift, col, 0f);
    }

    private static void ellipsoidPatch(MeshBuilder b, float cx, float cy, float cz, float rx, float ry, float rz, float th0, float th1, float ph0, float ph1, int nt, int np, float lift, int col, float pinch) {
        int[][] g = new int[np + 1][nt + 1];
        for (int j = 0; j <= np; j++) {
            for (int i = 0; i <= nt; i++) {
                float th = th0 + (th1 - th0) * i / nt;
                float u = (th0 + th1) * 0.5f == 0f ? Math.abs(th) / Math.max(1e-4f, Math.max(Math.abs(th0), Math.abs(th1))) : 0f;
                float pm = (ph0 + ph1) * 0.5f, ph_half = (ph1 - ph0) * 0.5f * (1f - pinch * u * u);
                float ph = pm - ph_half + 2f * ph_half * j / np;
                float ux = (float) (Math.cos(ph) * Math.sin(th)), uy = (float) Math.sin(ph), uz = (float) (-Math.cos(ph) * Math.cos(th));
                g[j][i] = b.vert(cx + rx * (1f + lift) * ux, cy + ry * (1f + lift) * uy, cz + rz * (1f + lift) * uz, ux / rx, uy / ry, uz / rz, col);
            }
        }
        for (int j = 0; j < np; j++) for (int i = 0; i < nt; i++) {
            int a = g[j][i], bb = g[j][i + 1], c = g[j + 1][i], d = g[j + 1][i + 1];
            b.tri(a, c, bb);
            b.tri(bb, c, d);
        }
    }

    /** Point on the helmet ellipsoid for the angles (th around the vertical axis, 0 = front; ph = elevation). */
    private static float[] hp(float cx, float cy, float cz, float rx, float ry, float rz, float th, float ph, float lift) {
        return new float[]{cx + rx * (1f + lift) * (float) (Math.cos(ph) * Math.sin(th)), cy + ry * (1f + lift) * (float) Math.sin(ph), cz - rz * (1f + lift) * (float) (Math.cos(ph) * Math.cos(th))};
    }

    /** Full face race helmet: elongated shell in the kart colour, chin bar, wrap around visor with a seal and pivots, ear covers, vents, wing and livery. */
    private static void helmet(MeshBuilder b, float cx, float hy, float cz, int stripe, int black, int steelC) {
        float rx = 0.205f, ry = 0.232f, rz = 0.275f;
        int shB = Col.rgba(150, 150, 150, 255), shT = Col.rgba(255, 255, 255, 255), shM = Col.rgba(205, 205, 205, 255);
        b.sphere(cx, hy, cz, rx, ry, rz, 18, 10, shB, shT);                                           // shell
        b.softBox(cx, hy - 0.172f, cz - 0.150f, 0.135f, 0.062f, 0.095f, 3.4f, 14, 5, shB, shM);         // chin bar (angular, not a snout)
        b.softBox(cx, hy - 0.178f, cz - 0.238f, 0.060f, 0.026f, 0.014f, 3f, 8, 3, black, black);      // breath box
        for (int k = -1; k <= 1; k++) b.box(cx + k * 0.030f, hy - 0.178f, cz - 0.254f, 0.007f, 0.017f, 0.004f, steelC);
        ellipsoidPatch(b, cx, hy, cz, rx, ry, rz, -1.32f, 1.32f, -0.28f, 0.50f, 16, 4, 0.007f, black, 0.62f);   // visor seal
        ellipsoidPatch(b, cx, hy, cz, rx, ry, rz, -1.24f, 1.24f, -0.20f, 0.43f, 16, 4, 0.014f, Col.rgba(30, 40, 54, 255), 0.62f);   // smoked mirror visor
        ellipsoidPatch(b, cx, hy, cz, rx, ry, rz, -0.50f, 0.50f, 0.455f, 0.52f, 6, 1, 0.016f, steelC);   // visor top trim
        for (int sd = -1; sd <= 1; sd += 2) {
            float[] pv = hp(cx, hy, cz, rx, ry, rz, sd * 1.34f, 0.12f, 0.02f);
            b.sphere(pv[0], pv[1], pv[2], 0.026f, 0.026f, 0.026f, 7, 4, steelC, steelC);               // pivot screws
            b.sphere(cx + sd * 0.200f, hy - 0.015f, cz + 0.035f, 0.040f, 0.082f, 0.070f, 8, 5, shB, shM);   // ear covers
        }
        b.softBox(cx, hy + 0.222f, cz - 0.07f, 0.045f, 0.022f, 0.085f, 3f, 8, 3, black, black);      // top intake
        for (int k = -1; k <= 1; k += 2) b.box(cx + k * 0.016f, hy + 0.236f, cz - 0.07f, 0.006f, 0.008f, 0.06f, steelC);
        b.softBox(cx, hy - 0.115f, cz + 0.255f, 0.07f, 0.045f, 0.022f, 3f, 8, 3, black, black);       // rear exhaust vent
        b.softBox(cx, hy + 0.105f, cz + 0.285f, 0.115f, 0.008f, 0.062f, 3f, 8, 2, stripe, stripe);    // rear wing
        for (int sd = -1; sd <= 1; sd += 2) b.box(cx + sd * 0.115f, hy + 0.10f, cz + 0.265f, 0.006f, 0.04f, 0.03f, black);
        ellipsoidPatch(b, cx, hy, cz, rx, ry, rz, -0.085f, 0.085f, 0.46f, 1.50f, 2, 6, 0.010f, stripe);   // centre stripe front
        ellipsoidPatch(b, cx, hy, cz, rx, ry, rz, MathX.PI - 0.085f, MathX.PI + 0.085f, 0.20f, 1.50f, 2, 6, 0.010f, stripe);   // centre stripe rear
        for (int sd = -1; sd <= 1; sd += 2) ellipsoidPatch(b, cx, hy, cz, rx, ry, rz, sd * 1.72f - 0.05f, sd * 1.72f + 0.05f, -0.55f, 0.95f, 2, 6, 0.010f, stripe);   // side stripes
        b.torus(cx, hy - 0.215f, cz - 0.005f, rx * 0.86f, rz * 0.80f, 0.020f, 18, 4, black);          // rubber edge around the neck opening
    }

    /** Racing driver in seat space (origin at the seat, forward -Z): sloping shoulders, neck, arms with elbows, hands that grip the wheel, harness and a full face helmet. */
    public static MeshData driver(int id) {
        int d = Math.floorMod(id, DRIVERS);
        MeshBuilder b = new MeshBuilder();
        int suit = fx(SUIT[d], 1f), suitD = fx(SUIT[d], 0.62f), suitL = fx(SUIT[d], 1.16f), stripe = fx(STRIPE[d], 1f);
        int white = fixed(238, 238, 234), black = fixed(24, 26, 30), glove = fixed(34, 35, 40), steelC = fixed(176, 182, 192), belt = fixed(28, 30, 34);
        // pelvis and thighs (inside the cowl)
        b.sphere(0, 0.10f, 0.08f, 0.25f, 0.14f, 0.20f, 8, 4, suitD, suit);
        for (int sd = -1; sd <= 1; sd += 2) {
            b.tube(sd * 0.13f, 0.12f, 0.06f, sd * 0.17f, 0.25f, -0.38f, 0.108f, 0.086f, 6, suit, suit, false);
        }
        // torso built from overlapping masses: waist, chest, shoulder girdle, shoulder blades
        b.sphere(0, 0.20f, 0.06f, 0.225f, 0.16f, 0.17f, 12, 6, suitD, suit);
        b.sphere(0, 0.41f, 0.01f, 0.275f, 0.26f, 0.175f, 14, 8, suit, suitL);
        b.sphere(0, 0.585f, 0.03f, 0.315f, 0.105f, 0.165f, 14, 6, suit, suitL);
        for (int sd = -1; sd <= 1; sd += 2) b.sphere(sd * 0.115f, 0.50f, 0.15f, 0.115f, 0.14f, 0.055f, 7, 4, suit, suitL);
        // stripe band, chest panel, number patch on the back
        b.sphere(0, 0.45f, 0.01f, 0.282f, 0.032f, 0.181f, 16, 3, stripe, stripe);
        b.softBox(0, 0.36f, -0.172f, 0.12f, 0.085f, 0.008f, 3f, 8, 4, fx(SUIT[d], 0.80f), fx(SUIT[d], 0.80f));
        b.softBox(0, 0.40f, 0.182f, 0.125f, 0.085f, 0.008f, 3f, 8, 4, white, white);
        b.box(0, 0.40f, 0.19f, 0.052f, 0.012f, 0.004f, black);
        // neck, fire suit collar, neck roll and head and neck restraint
        b.cyl(0, 0.64f, 0.0f, 0.088f, 0.078f, 0.15f, 12, fixed(176, 138, 112), fixed(176, 138, 112), false, false);
        b.cyl(0, 0.635f, 0.0f, 0.112f, 0.100f, 0.085f, 14, suitD, suitD, false, true);
        b.torus(0, 0.725f, 0.0f, 0.100f, 0.092f, 0.022f, 16, 4, black);
        for (int sd = -1; sd <= 1; sd += 2) {
            b.tube(sd * 0.20f, 0.645f, 0.06f, sd * 0.135f, 0.585f, -0.15f, 0.040f, 0.030f, 6, black, black, false);
        }
        // harness: shoulder belts, lap belt, buckle
        for (int sd = -1; sd <= 1; sd += 2) {
            b.tube(sd * 0.20f, 0.66f, 0.16f, sd * 0.19f, 0.64f, -0.06f, 0.026f, 0.026f, 5, belt, belt, false);
            b.tube(sd * 0.19f, 0.64f, -0.06f, sd * 0.05f, 0.25f, -0.185f, 0.026f, 0.026f, 5, belt, belt, false);
        }
        b.tube(-0.22f, 0.15f, -0.15f, 0.22f, 0.15f, -0.15f, 0.026f, 0.026f, 5, belt, belt, false);
        b.softBox(0, 0.215f, -0.19f, 0.040f, 0.030f, 0.012f, 2.6f, 8, 3, steelC, steelC);
        // arms: deltoids, upper arms, elbows with pads, forearms, cuffs, gloves with fingers wrapped round the grips
        for (int sd = -1; sd <= 1; sd += 2) {
            b.sphere(sd * 0.315f, 0.565f, 0.02f, 0.108f, 0.100f, 0.105f, 8, 5, suit, suitL);
            b.tube(sd * 0.32f, 0.55f, 0.02f, sd * 0.405f, 0.33f, -0.13f, 0.092f, 0.074f, 8, suit, suit, false);
            b.tube(sd * 0.352f, 0.45f, -0.03f, sd * 0.372f, 0.405f, -0.055f, 0.097f, 0.097f, 8, stripe, stripe, false);
            b.sphere(sd * 0.405f, 0.33f, -0.13f, 0.080f, 7, 4, suit);
            b.sphere(sd * 0.415f, 0.33f, -0.105f, 0.060f, 0.065f, 0.050f, 6, 3, suitL, suitL);
            b.tube(sd * 0.405f, 0.33f, -0.13f, sd * 0.215f, 0.285f, -0.455f, 0.076f, 0.054f, 8, suit, suit, false);
            b.tube(sd * 0.222f, 0.286f, -0.435f, sd * 0.208f, 0.282f, -0.47f, 0.064f, 0.064f, 8, stripe, stripe, false);
            // hand: palm, four fingers curling over the grip, thumb
            b.softBox(sd * 0.205f, 0.285f, -0.505f, 0.052f, 0.034f, 0.058f, 2.6f, 8, 4, glove, glove);
            for (int f = 0; f < 4; f++) {
                float fz = -0.545f + f * 0.030f, fy = 0.305f - f * 0.006f;
                b.tube(sd * 0.215f, fy, fz, sd * 0.150f, fy + 0.030f, fz, 0.0165f, 0.0150f, 4, glove, glove, false);
                b.tube(sd * 0.150f, fy + 0.030f, fz, sd * 0.118f, fy - 0.012f, fz, 0.0150f, 0.0135f, 4, glove, glove, false);
            }
            b.tube(sd * 0.205f, 0.270f, -0.470f, sd * 0.150f, 0.322f, -0.505f, 0.020f, 0.016f, 5, glove, glove, false);
        }
        helmet(b, 0f, 0.945f, -0.02f, stripe, black, steelC);
        return b.build();
    }

    private static final int DARKF = Col.hex(0x37474F);
}
