package com.kartracer.gl;

import android.opengl.GLES30;

import com.kartracer.gfx.Etc;
import com.kartracer.gfx.TexGen;
import com.kartracer.util.Diag;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/** RGBA texture with mipmaps and repeat wrapping. */
public final class GlTex {
    private final TexGen.Tex src;
    public int id;

    public GlTex(TexGen.Tex src) { this.src = src; }

    /** Largest anisotropy level to use (0 = not supported); queried once. */
    private static float maxAniso = -1f;

    private static void queryAniso() {
        if (maxAniso >= 0f) return;
        maxAniso = 0f;
        try {
            while (GLES30.glGetError() != GLES30.GL_NO_ERROR) { /* drain */ }
            String ext = GLES30.glGetString(GLES30.GL_EXTENSIONS);
            if (ext != null && ext.contains("GL_EXT_texture_filter_anisotropic")) {
                float[] v = new float[1];
                GLES30.glGetFloatv(0x84FF, v, 0);   // GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT
                if (GLES30.glGetError() == GLES30.GL_NO_ERROR && v[0] > 1f) maxAniso = Math.min(8f, v[0]);
            }
            while (GLES30.glGetError() != GLES30.GL_NO_ERROR) { /* drain */ }
        } catch (Throwable t) {
            maxAniso = 0f;
        }
    }

    /**
     * The textures are small (a few hundred KB in total), so they are always uploaded as plain RGBA with mipmaps.
     * (The old on-the-fly ETC2 compression was a crude encoder: it turned the road and the ground into blocky, off-colour blotches.)
     */
    public void upload() {
        uploadRaw();
    }

    /** ETC2 (mandatory in OpenGL ES 3.0): 4 bits per pixel, falls back to RGBA if the driver refuses. */
    private boolean uploadCompressed() {
        Etc.Level[] ch = src.etcChain;
        while (GLES30.glGetError() != GLES30.GL_NO_ERROR) { /* drain */ }
        int[] t = new int[1];
        GLES30.glGenTextures(1, t, 0);
        id = t[0];
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, id);
        boolean ok = true;
        for (int i = 0; i < ch.length && ok; i++) {
            ByteBuffer b = ByteBuffer.allocateDirect(ch[i].etc.length).order(ByteOrder.nativeOrder());
            b.put(ch[i].etc); b.position(0);
            GLES30.glCompressedTexImage2D(GLES30.GL_TEXTURE_2D, i, GLES30.GL_COMPRESSED_RGB8_ETC2, ch[i].w, ch[i].h, 0, ch[i].etc.length, b);
            if (GLES30.glGetError() != GLES30.GL_NO_ERROR) ok = false;
        }
        if (!ok) {
            Diag.log("GL", "ETC2 texture upload failed, using uncompressed RGBA");
            int[] d = {id};
            GLES30.glDeleteTextures(1, d, 0);
            id = 0;
            return false;
        }
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR_MIPMAP_LINEAR);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_REPEAT);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_REPEAT);
        return true;
    }

    private void uploadRaw() {
        int[] t = new int[1];
        GLES30.glGenTextures(1, t, 0);
        id = t[0];
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, id);
        ByteBuffer b = ByteBuffer.allocateDirect(src.rgba.length).order(ByteOrder.nativeOrder());
        b.put(src.rgba); b.position(0);
        GLES30.glPixelStorei(GLES30.GL_UNPACK_ALIGNMENT, 1);
        GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGBA, src.w, src.h, 0, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, b);
        boolean mips = src.w > 1;
        if (mips) GLES30.glGenerateMipmap(GLES30.GL_TEXTURE_2D);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, mips ? GLES30.GL_LINEAR_MIPMAP_LINEAR : GLES30.GL_LINEAR);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_REPEAT);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_REPEAT);
        if (mips && src.w >= 64) {
            // anisotropic filtering keeps the road lines and the ground sharp at a grazing angle
            queryAniso();
            if (maxAniso > 1f) GLES30.glTexParameterf(GLES30.GL_TEXTURE_2D, 0x84FE, maxAniso);   // GL_TEXTURE_MAX_ANISOTROPY_EXT
        }
    }

    public void bind(int unit) {
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0 + unit);
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, id);
    }

    public void release() {
        int[] t = {id};
        GLES30.glDeleteTextures(1, t, 0);
        id = 0;
    }
}
