package com.kartracer.gfx;

import com.kartracer.util.Rng;
import com.kartracer.world.Props;
import com.kartracer.world.TrackData;
import com.kartracer.world.TrackDef;

/** All CPU side render data for one track. Built on a worker thread, uploaded on the GL thread. */
public final class SceneData {
    public TrackData td;
    public WorldMesher.ChunkMesh[] chunks;
    public int ncx, ncz;
    public MeshData[] roads;
    public MeshData[][] props = new MeshData[Props.COUNT][2];
    public int[] typeCount = new int[Props.COUNT];
    public float[] scTint, scPhase;
    public MeshData[] rampMeshes, padMeshes;
    public MeshData gate, crate, itemBox, boulder, vent;
    public float gateX, gateY, gateZ, gateYaw;
    public TexGen.Tex roadTex, dirtTex;

    public static SceneData build(TrackDef def) {
        SceneData s = new SceneData();
        TrackData td = TrackData.build(def);
        s.td = td;
        s.chunks = WorldMesher.terrain(td);
        s.ncx = WorldMesher.chunksX(td);
        s.ncz = WorldMesher.chunksZ(td);
        s.roads = new MeshData[td.roads.length];
        for (int k = 0; k < s.roads.length; k++) s.roads[k] = WorldMesher.road(td, k);
        for (int i = 0; i < td.scN; i++) s.typeCount[td.scType[i]]++;
        for (int t = 0; t < Props.COUNT; t++) {
            if (s.typeCount[t] == 0) continue;
            s.props[t][0] = PropModels.build(t, 0, def.theme);
            s.props[t][1] = PropModels.build(t, 1, def.theme);
        }
        Rng r = new Rng(def.seed + 99);
        s.scTint = new float[td.scN];
        s.scPhase = new float[td.scN];
        for (int i = 0; i < td.scN; i++) { s.scTint[i] = 0.88f + 0.24f * r.next(); s.scPhase[i] = r.next() * 6.28f; }
        s.rampMeshes = new MeshData[td.ramps.length];
        for (int i = 0; i < s.rampMeshes.length; i++) s.rampMeshes[i] = ObjModels.ramp(td.ramps[i]);
        s.padMeshes = new MeshData[td.pads.length];
        for (int i = 0; i < s.padMeshes.length; i++) s.padMeshes[i] = ObjModels.pad(td.pads[i]);
        float[] p = new float[6];
        td.mainPointAt(0f, p);
        s.gate = ObjModels.startGate(p[5], def.theme);
        s.gateX = p[0]; s.gateY = p[2]; s.gateZ = p[1]; s.gateYaw = (float) Math.atan2(p[3], -p[4]);
        s.crate = ObjModels.crate();
        s.itemBox = ObjModels.itemBox();
        s.boulder = ObjModels.boulder(def.theme);
        s.vent = ObjModels.vent(def.theme);
        s.roadTex = TexGen.road(def.theme);
        s.dirtTex = TexGen.dirt();
        return s;
    }
}
