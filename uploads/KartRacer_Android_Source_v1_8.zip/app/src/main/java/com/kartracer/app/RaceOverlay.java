package com.kartracer.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.view.Display;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.View;

import com.kartracer.gfx.HudData;
import com.kartracer.sim.Kart;
import com.kartracer.sim.PlayerInput;
import com.kartracer.world.TrackData;

/** In-race HUD, touch controls (buttons / tilt / slide), minimap and the control layout editor. */
public final class RaceOverlay extends View implements SensorEventListener {
    public interface Callbacks {
        void onPausePressed();
        void onEditDone();
    }

    private static final int LEFT = 0, RIGHT = 1, GAS = 2, BRAKE = 3, DRIFT = 4, ITEM = 5, BOOST = 6;
    private static final float[] BASE_R = {40, 40, 54, 42, 44, 38, 36};
    private static final int[] CTL_COL = {0xFF2A4A6B, 0xFF2A4A6B, 0xFF2E9E4F, 0xFFC62828, 0xFF00838F, 0xFF6A1B9A, 0xFFEF6C00};
    private static final int[] CTL_ICON = {Icons.ARROW_L, Icons.ARROW_R, Icons.PEDAL, Icons.BRAKE, Icons.DRIFT, Icons.BOX, Icons.FLAME};
    /** Text shown inside each button so every control says what it does. */
    private static final String[] CTL_LABEL = {null, null, "GAS", "BRAKE", "DRIFT", "ITEM", "NITRO"};
    private static final int[] LEVEL_COL = {0xFFFFFFFF, 0xFF4FC3F7, 0xFFFFA726, 0xFFE040FB};

    private final Settings settings;
    private final HudData hud;
    private final PlayerInput input;
    private final Callbacks cb;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG), text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final Path mapPath = new Path();
    private final float[] fit = new float[3];
    private MapPaths.Data mapData;
    private float mapBoxX, mapBoxY, mapBoxS;
    private int lastItem;
    private long itemGotMs;
    private final float[] cx = new float[7], cy = new float[7], cr = new float[7];
    private final boolean[] down = new boolean[7];
    private final int[] ptrCtl = new int[24];
    private final boolean[] ptrActive = new boolean[24];
    private int slidePtr = -1;
    private float slideStartX, slideSteer, tiltSteer, tiltFiltered;
    private boolean tiltOn;
    private boolean editMode;
    private int editCtl = -1;
    private float pauseX, pauseY, pauseR;
    private int lastSpeed = -1;
    private int lastDriftLvl = -1;
    private String speedStr = "0";
    private boolean looping;
    private long lastInvNs;
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!looping) return;
            long now = System.nanoTime();
            if (now - lastInvNs < 13000000L) { postOnAnimation(this); return; }   // at most about 70 redraws per second (90/120 Hz screens)
            lastInvNs = now;
            invalidate();
        }
    };
    // cached HUD strings (no allocation per frame) and the place change animation
    private int cPlace = -1, cKarts = -1, cLap = -1, cLaps = -1;
    private String placeStr = "", ordStr = "", kartsStr = "", lapStr = "";
    private long placeAnimMs;
    private boolean placeGain;

    public RaceOverlay(Context c, Settings s, HudData hud, PlayerInput input, Callbacks cb) {
        super(c);
        settings = s; this.hud = hud; this.input = input; this.cb = cb;
        text.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        for (int i = 0; i < ptrCtl.length; i++) ptrCtl[i] = -1;
        setClickable(true);
    }

    // ------------------------------------------------------------------ public API

    public void setTrack(TrackData td) {
        mapData = MapPaths.forTrack(td);
        mapBoxS = 0f;
    }

    public void startLoop() {
        looping = true;
        invalidate();
        refreshSensors();
    }

    public void stopLoop() {
        looping = false;
        removeCallbacks(tick);
        unregisterSensors();
        input.clear();
        for (int i = 0; i < down.length; i++) down[i] = false;
        for (int i = 0; i < ptrActive.length; i++) { ptrActive[i] = false; ptrCtl[i] = -1; }
        slidePtr = -1;
    }

    public void startEditing() {
        editMode = true;
        editCtl = -1;
        looping = true;
        invalidate();
    }

    public boolean isEditing() { return editMode; }

    public void refreshSensors() {
        unregisterSensors();
        if (settings.steerMode == 1 && looping) {
            SensorManager sm = (SensorManager) getContext().getSystemService(Context.SENSOR_SERVICE);
            Sensor a = sm == null ? null : sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            if (a != null) { sm.registerListener(this, a, SensorManager.SENSOR_DELAY_GAME); tiltOn = true; }
        }
    }

    private void unregisterSensors() {
        if (tiltOn) {
            SensorManager sm = (SensorManager) getContext().getSystemService(Context.SENSOR_SERVICE);
            if (sm != null) sm.unregisterListener(this);
            tiltOn = false;
        }
        tiltSteer = tiltFiltered = 0f;
    }

    @Override protected void onDetachedFromWindow() { unregisterSensors(); super.onDetachedFromWindow(); }

    @Override
    public void onSensorChanged(SensorEvent ev) {
        float ax = ev.values[0], ay = ev.values[1];
        Display d = getDisplay();
        int rot = d != null ? d.getRotation() : Surface.ROTATION_90;
        float sx;
        if (rot == Surface.ROTATION_90) sx = ay;
        else if (rot == Surface.ROTATION_270) sx = -ay;
        else if (rot == Surface.ROTATION_180) sx = -ax;
        else sx = ax;
        float raw = -sx / (9.81f * 0.62f) * (settings.tiltSens / 100f);   // full lock at about 39 degrees of tilt (was 30): calmer
        if (Math.abs(raw) < 0.06f) raw = 0f;
        raw = Math.max(-1f, Math.min(1f, raw));
        tiltFiltered += (raw - tiltFiltered) * 0.35f;
        tiltSteer = tiltFiltered;
        if (settings.steerMode == 1 && !editMode) input.steer = tiltSteer;
    }

    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) { }

    // ------------------------------------------------------------------ layout

    private boolean visible(int i) {
        if (i == GAS && settings.autoGas) return false;   // no pedal needed: the thumb stays free for Drift / Nitro / Item
        if (editMode) return true;
        if (i == LEFT || i == RIGHT) return settings.steerMode == 0;
        if (i == ITEM) return hud.itemsOn;
        return true;
    }

    private void layoutControls(int W, int H) {
        float sc = settings.buttonScale / 100f;
        for (int i = 0; i < 7; i++) {
            cx[i] = settings.layout[i * 2] * W;
            cy[i] = settings.layout[i * 2 + 1] * H;
            cr[i] = Ui.dp(BASE_R[i]) * sc;
        }
        pauseR = Ui.dp(22);
        pauseX = W - Ui.dp(16) - pauseR;
        pauseY = Ui.dp(14) + pauseR;
    }

    // ------------------------------------------------------------------ touch

    private int hit(float x, float y) {
        int best = -1;
        float bestD = 1e9f;
        for (int i = 0; i < 7; i++) {
            if (!visible(i)) continue;
            float dx = x - cx[i], dy = y - cy[i];
            float d = (float) Math.sqrt(dx * dx + dy * dy) / cr[i];
            if (d < 1.25f && d < bestD) { bestD = d; best = i; }
        }
        return best;
    }

    private static boolean sameGroup(int a, int b) {
        boolean steerA = a == LEFT || a == RIGHT, steerB = b == LEFT || b == RIGHT;
        boolean pedalA = a == GAS || a == BRAKE, pedalB = b == GAS || b == BRAKE;
        return (steerA && steerB) || (pedalA && pedalB);
    }

    private void haptic() {
        if (settings.haptics) performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
    }

    /** A short tick each time the drift charge reaches the next mini-turbo level. */
    private void hapticTick() {
        if (settings.haptics) performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int W = getWidth(), H = getHeight();
        layoutControls(W, H);
        if (editMode) return editTouch(e, W, H);
        if (!hud.active) return false;
        int action = e.getActionMasked();
        if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
            int idx = e.getActionIndex(), id = e.getPointerId(idx);
            if (id >= ptrCtl.length) return true;
            float x = e.getX(idx), y = e.getY(idx);
            ptrActive[id] = true;
            int c = hit(x, y);
            if (c >= 0) {
                ptrCtl[id] = c;
                if (c == ITEM) { input.pressItem(); haptic(); }
                else if (c == DRIFT || c == BOOST) haptic();
            } else if ((x - pauseX) * (x - pauseX) + (y - pauseY) * (y - pauseY) < pauseR * pauseR * 2.2f) {
                ptrCtl[id] = -1;
                cb.onPausePressed();
            } else if (settings.steerMode == 2 && x < W * 0.55f && slidePtr < 0) {
                slidePtr = id; slideStartX = x; slideSteer = 0f; ptrCtl[id] = -2;
            } else ptrCtl[id] = -1;
        } else if (action == MotionEvent.ACTION_MOVE) {
            for (int i = 0; i < e.getPointerCount(); i++) {
                int id = e.getPointerId(i);
                if (id == slidePtr) slideSteer = Math.max(-1f, Math.min(1f, (e.getX(i) - slideStartX) / Ui.dp(84)));   // a longer drag for full lock (was 60 dp)
                else if (id < ptrCtl.length && ptrActive[id] && ptrCtl[id] >= 0) {
                    // a thumb that rolls from one steering button to the other (or gas <-> brake) switches over without lifting
                    int cur = ptrCtl[id], to = hit(e.getX(i), e.getY(i));
                    if (to >= 0 && to != cur && sameGroup(cur, to)) ptrCtl[id] = to;
                }
            }
        } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_POINTER_UP || action == MotionEvent.ACTION_CANCEL) {
            if (action == MotionEvent.ACTION_CANCEL) {
                for (int i = 0; i < ptrActive.length; i++) { ptrActive[i] = false; ptrCtl[i] = -1; }
                slidePtr = -1; slideSteer = 0f;
            } else {
                int idx = e.getActionIndex(), id = e.getPointerId(idx);
                if (id < ptrCtl.length) { ptrActive[id] = false; ptrCtl[id] = -1; }
                if (id == slidePtr) { slidePtr = -1; slideSteer = 0f; }
            }
        }
        publish();
        return true;
    }

    private void publish() {
        for (int i = 0; i < 7; i++) down[i] = false;
        for (int i = 0; i < ptrCtl.length; i++) if (ptrActive[i] && ptrCtl[i] >= 0) down[ptrCtl[i]] = true;
        float steer;
        if (settings.steerMode == 1) steer = tiltSteer;
        else if (settings.steerMode == 2) steer = slideSteer;
        else steer = (down[RIGHT] ? 1f : 0f) - (down[LEFT] ? 1f : 0f);
        input.steer = steer;
        input.throttle = (down[GAS] || (settings.autoGas && !down[BRAKE])) ? 1f : 0f;   // braking cancels auto accelerate (and lets the kart reverse)
        input.brake = down[BRAKE] ? 1f : 0f;
        input.drift = down[DRIFT];
        input.boost = down[BOOST];
    }

    private boolean editTouch(MotionEvent e, int W, int H) {
        float x = e.getX(), y = e.getY();
        int a = e.getActionMasked();
        float bw = Ui.dp(110), bh = Ui.dp(40), by = Ui.dp(14);
        float resetX = W / 2f - bw - Ui.dp(8), doneX = W / 2f + Ui.dp(8);
        if (a == MotionEvent.ACTION_DOWN) {
            if (y > by && y < by + bh && x > doneX && x < doneX + bw) { editMode = false; settings.customLayout = true; cb.onEditDone(); return true; }
            if (y > by && y < by + bh && x > resetX && x < resetX + bw) { settings.resetLayout(); invalidate(); return true; }
            editCtl = hit(x, y);
        } else if (a == MotionEvent.ACTION_MOVE && editCtl >= 0) {
            settings.layout[editCtl * 2] = Math.max(0.05f, Math.min(0.95f, x / W));
            settings.layout[editCtl * 2 + 1] = Math.max(0.08f, Math.min(0.94f, y / H));
            settings.customLayout = true;
            invalidate();
        } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) editCtl = -1;
        return true;
    }

    // ------------------------------------------------------------------ drawing

    private void label(Canvas c, String s, float x, float y, float size, int color, Paint.Align align, boolean shadow) {
        text.setTextSize(size);
        text.setTextAlign(align);
        if (shadow) { text.setColor(0xAA000000); c.drawText(s, x + Ui.dp(1.5f), y + Ui.dp(1.5f), text); }
        text.setColor(color);
        c.drawText(s, x, y, text);
    }

    private static String ordinal(int n) {
        if (n % 100 >= 11 && n % 100 <= 13) return "th";
        switch (n % 10) { case 1: return "st"; case 2: return "nd"; case 3: return "rd"; default: return "th"; }
    }

    @Override
    protected void onDraw(Canvas c) {
        int W = getWidth(), H = getHeight();
        layoutControls(W, H);
        if (editMode) { drawEdit(c, W, H); return; }
        if (!looping) return;
        // The race becomes active on the GL thread a few frames after the HUD starts. Keep polling until then,
        // otherwise the HUD would stop redrawing for good and the buttons would never show up.
        if (!hud.active) { postInvalidateDelayed(40); return; }
        publish();
        float d = Ui.density();
        drawPlace(c, d);
        drawMinimap(c, W, d);
        drawPause(c);
        drawCenter(c, W, H, d);
        drawShield(c, W, H, d);
        drawSpeed(c, W, H, d);
        drawDriftMeter(c, W, d);
        drawControls(c, false);
        if (settings.showFps) label(c, hud.fps + " fps", W * 0.5f, Ui.dp(22), 13 * d, 0xCCFFFFFF, Paint.Align.CENTER, true);
        postOnAnimation(tick);
    }

    private static int lerpColor(int a, int b, float t) {
        int ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        return 0xFF000000 | ((int) (ar + (br - ar) * t) << 16) | ((int) (ag + (bg - ag) * t) << 8) | (int) (ab + (bb - ab) * t);
    }

    private void drawPlace(Canvas c, float d) {
        long now = System.currentTimeMillis();
        float x = Ui.dp(18), y = Ui.dp(14);
        if (hud.place != cPlace || hud.nKarts != cKarts) {
            // pop + colour flash (green: gained a place, red: lost one), not during the countdown
            if (cPlace > 0 && hud.place != cPlace && hud.phase != 0) { placeAnimMs = now; placeGain = hud.place < cPlace; }
            cPlace = hud.place; cKarts = hud.nKarts;
            placeStr = String.valueOf(cPlace); ordStr = ordinal(cPlace); kartsStr = "/ " + cKarts;
        }
        if (hud.lap != cLap || hud.laps != cLaps) { cLap = hud.lap; cLaps = hud.laps; lapStr = "LAP " + cLap + "/" + cLaps; }
        float age = (now - placeAnimMs) / 520f;
        float pop = 1f, flash = 0f;
        if (age >= 0f && age < 1f) { float k = 1f - age; pop = 1f + 0.38f * k * k; flash = k; }
        int numCol = flash > 0f ? lerpColor(0xFFFFFFFF, placeGain ? 0xFF7CFF8A : 0xFFFF6F61, flash) : 0xFFFFFFFF;
        text.setTextSize(52 * d);
        float nw = text.measureText(placeStr);
        c.save();
        c.scale(pop, pop, x, y + Ui.dp(46));
        label(c, placeStr, x, y + Ui.dp(46), 52 * d, numCol, Paint.Align.LEFT, true);
        c.restore();
        label(c, ordStr, x + nw + Ui.dp(2), y + Ui.dp(20), 18 * d, 0xFFFFD54F, Paint.Align.LEFT, true);
        label(c, kartsStr, x + nw + Ui.dp(2), y + Ui.dp(44), 14 * d, 0xCCFFFFFF, Paint.Align.LEFT, true);
        text.setTextSize(13 * d);
        float lw = text.measureText(lapStr) + Ui.dp(20);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0x99000000);
        rect.set(x, y + Ui.dp(56), x + lw, y + Ui.dp(82));
        c.drawRoundRect(rect, Ui.dp(13), Ui.dp(13), paint);
        label(c, lapStr, x + lw / 2f, y + Ui.dp(74), 13 * d, 0xFFFFFFFF, Paint.Align.CENTER, false);
    }

    private void drawPause(Canvas c) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0x99000000);
        c.drawCircle(pauseX, pauseY, pauseR, paint);
        paint.setColor(0xFFFFFFFF);
        Icons.draw(c, Icons.PAUSE, pauseX, pauseY, pauseR * 0.5f, paint);
    }

    private void drawMinimap(Canvas c, int W, float d) {
        if (mapData == null) return;
        // keep the minimap on the side that has no item button so the two never overlap
        boolean itemRight = visible(ITEM) ? cx[ITEM] > W * 0.5f : cx[DRIFT] > W * 0.5f;
        float S = Ui.dp(104);
        float x = itemRight ? Ui.dp(18) : W - Ui.dp(16) - S;
        float y = itemRight ? Ui.dp(14) + Ui.dp(82) + Ui.dp(10) : Ui.dp(14) + Ui.dp(44) + Ui.dp(10);
        if (mapBoxS != S || mapBoxX != x || mapBoxY != y) {
            mapBoxS = S; mapBoxX = x; mapBoxY = y;
            MapPaths.fit(mapData, x, y, S, S, Ui.dp(11), fit);
            MapPaths.buildPath(mapData, fit, mapPath);
        }
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0x88000000);
        rect.set(x, y, x + S, y + S);
        c.drawRoundRect(rect, Ui.dp(12), Ui.dp(12), paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Ui.dp(1));
        paint.setColor(0x33FFFFFF);
        c.drawRoundRect(rect, Ui.dp(12), Ui.dp(12), paint);
        paint.setStrokeJoin(Paint.Join.ROUND);
        paint.setStrokeWidth(Ui.dp(5));
        paint.setColor(0xFF1A1A1A);
        c.drawPath(mapPath, paint);
        paint.setStrokeWidth(Ui.dp(2.6f));
        paint.setColor(0xEEFFFFFF);
        c.drawPath(mapPath, paint);
        // start / finish line
        float sx = mapData.x[0] * fit[0] + fit[1], sz = mapData.z[0] * fit[0] + fit[2];
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0xFF111111);
        c.drawRect(sx - Ui.dp(3.6f), sz - Ui.dp(3.6f), sx + Ui.dp(3.6f), sz + Ui.dp(3.6f), paint);
        paint.setColor(0xFFFFFFFF);
        c.drawRect(sx - Ui.dp(3.6f), sz - Ui.dp(3.6f), sx, sz, paint);
        c.drawRect(sx, sz, sx + Ui.dp(3.6f), sz + Ui.dp(3.6f), paint);
        for (int pass = 0; pass < 2; pass++) {
            for (int i = 0; i < hud.mapN; i++) {
                boolean me = i == hud.localSlot;
                if ((pass == 1) != me) continue;
                float u = hud.mapX[i] * fit[0] + fit[1], v = hud.mapZ[i] * fit[0] + fit[2];
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(0xFFFFFFFF);
                c.drawCircle(u, v, Ui.dp(me ? 6.5f : 4.6f), paint);
                paint.setColor(0xFF000000 | hud.mapColor[i]);
                c.drawCircle(u, v, Ui.dp(me ? 4.8f : 3.2f), paint);
                if (me) {
                    float fx = (float) Math.sin(hud.mapYaw[i]), fz = -(float) Math.cos(hud.mapYaw[i]);
                    paint.setStrokeWidth(Ui.dp(2));
                    paint.setStyle(Paint.Style.STROKE);
                    paint.setColor(0xFFFFFFFF);
                    c.drawLine(u, v, u + fx * Ui.dp(11), v + fz * Ui.dp(11), paint);
                    paint.setStyle(Paint.Style.FILL);
                }
            }
        }
    }

    private void drawCenter(Canvas c, int W, int H, float d) {
        float x = W / 2f, y = H * 0.36f;
        long now = System.currentTimeMillis();
        if (hud.phase == 0) {
            float rt = hud.raceTime;
            if (rt < -3.2f) {
                label(c, hud.netMode ? "WAITING FOR PLAYERS" : "GET READY", x, y, 26 * d, 0xFFFFFFFF, Paint.Align.CENTER, true);
            } else {
                int n = (int) Math.ceil(-rt);
                float frac = n - (-rt);
                int col = n >= 3 ? 0xFFEF5350 : (n == 2 ? 0xFFFFA726 : 0xFFFFEE58);
                float size = 110 * d * (1f + 0.35f * (1f - frac));
                label(c, String.valueOf(Math.max(1, n)), x, y + Ui.dp(40), size, col, Paint.Align.CENTER, true);
            }
        } else if (hud.phase == 1 && hud.raceTime < 1.0f && hud.raceTime >= 0f) {
            float u = 1f - hud.raceTime;
            int a = (int) (255 * u);
            float goSize = 96 * d * (1f + 0.45f * u * u);   // starts big and settles while it fades out
            label(c, "GO!", x, y + Ui.dp(30), goSize, (a << 24) | 0x66FF66, Paint.Align.CENTER, true);
        }
        if (now < hud.toastUntilMs && hud.toast != null && hud.toast.length() > 0 && !hud.finished) {
            label(c, hud.toast, x, H * 0.22f, 26 * d, 0xFFFFFFFF, Paint.Align.CENTER, true);
            if (now < hud.hintUntilMs && hud.hint != null && hud.hint.length() > 0) {
                label(c, hud.hint, x, H * 0.22f + Ui.dp(24), 14 * d, 0xFFFFEE88, Paint.Align.CENTER, true);
            }
        }
        if (hud.wrongWay && !hud.finished) drawWrongWay(c, x, H, d, now);
        if (hud.finished) {
            label(c, "FINISHED  " + hud.place + ordinal(hud.place), x, H * 0.30f, 40 * d, 0xFFFFD54F, Paint.Align.CENTER, true);
            if (hud.phase != 2) label(c, "Waiting for the other racers...", x, H * 0.30f + Ui.dp(34), 16 * d, 0xDDFFFFFF, Paint.Align.CENTER, true);
        }
        if (hud.paused) label(c, "PAUSED", x, y, 40 * d, 0xFFFFFFFF, Paint.Align.CENTER, true);
    }

    /** Hard to miss "WRONG WAY" banner that also says which way to turn to face the road again. */
    private void drawWrongWay(Canvas c, float x, int H, float d, long now) {
        float pulse = 0.5f + 0.5f * (float) Math.sin(now / 130.0);
        float y = H * 0.46f, hw = Ui.dp(120);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0xDDB71C1C);
        rect.set(x - hw, y - Ui.dp(24), x + hw, y + Ui.dp(24));
        c.drawRoundRect(rect, Ui.dp(12), Ui.dp(12), paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Ui.dp(2));
        paint.setColor(((int) (110 + 145 * pulse) << 24) | 0xFFFFFF);
        c.drawRoundRect(rect, Ui.dp(12), Ui.dp(12), paint);
        paint.setStyle(Paint.Style.FILL);
        label(c, "WRONG WAY", x, y + Ui.dp(8), 22 * d, 0xFFFFFFFF, Paint.Align.CENTER, false);
        if (hud.turnHint != 0) {
            // big arrow on the side the kart has to turn toward, plus a short instruction under the banner
            float ax = x + hud.turnHint * (hw + Ui.dp(40)), r = Ui.dp(26) * (0.92f + 0.16f * pulse);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(0xCC000000);
            c.drawCircle(ax, y, r + Ui.dp(8), paint);
            paint.setColor(0xFFFFEE58);
            Icons.draw(c, hud.turnHint < 0 ? Icons.ARROW_L : Icons.ARROW_R, ax, y, r, paint);
            label(c, hud.turnHint < 0 ? "TURN LEFT" : "TURN RIGHT", x, y + Ui.dp(48), 16 * d, 0xFFFFEE58, Paint.Align.CENTER, true);
        }
    }

    /** Three-segment drift charge bar at the top centre (blue, orange, purple mini-turbo); only shown while drifting. */
    private void drawDriftMeter(Canvas c, int W, float d) {
        if (!hud.drifting || hud.finished) { lastDriftLvl = -1; return; }
        if (hud.driftLevel > lastDriftLvl && hud.driftLevel >= 1) hapticTick();
        lastDriftLvl = hud.driftLevel;
        float x = W / 2f, y = Ui.dp(22), bw = Ui.dp(190), bh = Ui.dp(11), gap = Ui.dp(4);
        float segW = (bw - 2f * gap) / 3f;
        float[] at = Kart.DRIFT_AT;
        float prev = 0f;
        long now = System.currentTimeMillis();
        paint.setStyle(Paint.Style.FILL);
        for (int s = 0; s < 3; s++) {
            float x0 = x - bw / 2f + s * (segW + gap);
            paint.setColor(0x77000000);
            rect.set(x0, y, x0 + segW, y + bh);
            c.drawRoundRect(rect, bh / 2f, bh / 2f, paint);
            float f = Math.max(0f, Math.min(1f, (hud.driftTime - prev) / (at[s] - prev)));
            if (f > 0.01f) {
                boolean full = f >= 0.999f;
                float pulse = full ? 0.78f + 0.22f * (float) Math.sin(now / 90.0) : 1f;
                paint.setColor(((int) (255 * pulse) << 24) | (LEVEL_COL[s + 1] & 0xFFFFFF));
                rect.set(x0, y, x0 + segW * f, y + bh);
                c.drawRoundRect(rect, bh / 2f, bh / 2f, paint);
            }
            prev = at[s];
        }
    }

    private void drawSpeed(Canvas c, int W, int H, float d) {
        int sp = (int) hud.speedKmh;
        if (sp != lastSpeed) { lastSpeed = sp; speedStr = String.valueOf(sp); }
        float x = W / 2f;
        label(c, speedStr, x, H - Ui.dp(62), 40 * d, 0xFFFFFFFF, Paint.Align.CENTER, true);
        label(c, "KM/H", x, H - Ui.dp(46), 11 * d, 0xCCB0C4DE, Paint.Align.CENTER, true);
        float bw = Ui.dp(150), bh = Ui.dp(8), by = H - Ui.dp(30);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0x66000000);
        rect.set(x - bw / 2f, by, x + bw / 2f, by + bh);
        c.drawRoundRect(rect, bh / 2f, bh / 2f, paint);
        paint.setColor(hud.boosting ? 0xFFFF9800 : 0xFF26C6DA);
        rect.set(x - bw / 2f, by, x - bw / 2f + bw * Math.max(0.03f, Math.min(1f, hud.nitro)), by + bh);
        c.drawRoundRect(rect, bh / 2f, bh / 2f, paint);
        label(c, "NITRO", x, by + Ui.dp(22), 10 * d, 0xAAB0C4DE, Paint.Align.CENTER, false);
    }

    /** Small blue bar with a shield icon showing how long the shield still protects the kart. */
    private void drawShield(Canvas c, int W, int H, float d) {
        if (hud.shieldTime <= 0f || hud.finished) return;
        float x = W / 2f, y = H - Ui.dp(106);
        float bw = Ui.dp(110), bh = Ui.dp(6);
        ItemArt.draw(c, 5, x - bw / 2f - Ui.dp(14), y, Ui.dp(10), paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0x66000000);
        rect.set(x - bw / 2f, y - bh / 2f, x + bw / 2f, y + bh / 2f);
        c.drawRoundRect(rect, bh / 2f, bh / 2f, paint);
        float k = Math.max(0.02f, Math.min(1f, hud.shieldTime / 8f));
        boolean blink = hud.shieldTime < 2f && ((System.currentTimeMillis() / 150) & 1) == 0;
        paint.setColor(blink ? 0x884FC3F7 : 0xFF4FC3F7);
        rect.set(x - bw / 2f, y - bh / 2f, x - bw / 2f + bw * k, y + bh / 2f);
        c.drawRoundRect(rect, bh / 2f, bh / 2f, paint);
    }

    private void drawControls(Canvas c, boolean edit) {
        float op = settings.controlOpacity / 100f;
        long now = System.currentTimeMillis();
        if (hud.item != lastItem) { if (hud.item != 0) itemGotMs = now; lastItem = hud.item; }
        int itemId = Math.max(0, Math.min(ItemArt.NAME.length - 1, hud.item));
        for (int i = 0; i < 7; i++) {
            if (!visible(i)) continue;
            boolean pressed = down[i] || (i == GAS && settings.autoGas && !edit);
            float x = cx[i], y = cy[i], r = cr[i];
            boolean hasItem = i == ITEM && itemId != 0 && !edit;
            float pop = 1f;
            if (hasItem) {
                float age = (now - itemGotMs) / 380f;
                if (age < 1f) pop = 1f + 0.28f * (1f - age) * (1f - age);
            }
            float dim = 1f;
            if (!edit && i == BOOST && hud.nitro < 0.02f) dim = 0.6f;
            if (!edit && i == ITEM && !hasItem) dim = 0.72f;
            int base = hasItem ? 0xFF222B45 : CTL_COL[i];
            int a = (int) (255 * op * (pressed ? 1f : 0.74f) * dim);
            float rr = r * (pressed ? 0.94f : 1f) * pop;
            paint.setStyle(Paint.Style.FILL);
            paint.setColor((a << 24) | (base & 0xFFFFFF));
            c.drawCircle(x, y, rr, paint);
            // soft highlight along the top edge
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeWidth(Ui.dp(2.4f));
            paint.setColor(((int) (80 * op * dim) << 24) | 0xFFFFFF);
            rect.set(x - rr * 0.82f, y - rr * 0.82f, x + rr * 0.82f, y + rr * 0.82f);
            c.drawArc(rect, 200f, 120f, false, paint);
            paint.setStrokeWidth(Ui.dp(2));
            paint.setColor(((int) (255 * op * 0.8f) << 24) | 0xFFFFFF);
            c.drawCircle(x, y, rr, paint);
            if (hasItem) {
                float pulse = 0.5f + 0.5f * (float) Math.sin(now / 160.0);
                paint.setColor(((int) (190 * pulse + 40) << 24) | (ItemArt.COLOR[itemId] & 0xFFFFFF));
                paint.setStrokeWidth(Ui.dp(4));
                c.drawCircle(x, y, rr + Ui.dp(3), paint);
            }
            String lab = edit ? null : (i == ITEM ? ItemArt.NAME[itemId] : CTL_LABEL[i]);
            float iconR = rr * (lab != null ? 0.46f : 0.54f);
            float iconY = lab != null ? y - rr * 0.14f : y;
            paint.setStyle(Paint.Style.FILL);
            if (i == ITEM) {
                ItemArt.draw(c, itemId, x, iconY, iconR * 1.2f, paint);
                if (!hasItem) { // empty slot: fade the artwork out
                    paint.setStyle(Paint.Style.FILL);
                    paint.setColor((0x99 << 24) | (CTL_COL[ITEM] & 0xFFFFFF));
                    c.drawCircle(x, y, rr * 0.98f, paint);
                }
            } else {
                paint.setColor(0xFFFFFFFF);
                Icons.draw(c, CTL_ICON[i], x, iconY, iconR, paint);
            }
            if (lab != null) {
                float size = rr * 0.27f;
                text.setTextSize(size);
                float w = text.measureText(lab), maxW = rr * 1.5f;
                if (w > maxW) size *= maxW / w;
                int col = hasItem ? ItemArt.COLOR[itemId] : 0xFFFFFFFF;
                if (i == ITEM && !hasItem) col = 0xAAFFFFFF;
                label(c, lab, x, y + rr * 0.74f, size, col, Paint.Align.CENTER, true);
            }
            if (!edit && i == DRIFT && hud.drifting) {
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(Ui.dp(5));
                paint.setStrokeCap(Paint.Cap.ROUND);
                paint.setColor(LEVEL_COL[Math.max(0, Math.min(3, hud.driftLevel))]);
                rect.set(x - r - Ui.dp(6), y - r - Ui.dp(6), x + r + Ui.dp(6), y + r + Ui.dp(6));
                c.drawArc(rect, -90, Math.min(360f, hud.driftTime / Kart.DRIFT_AT[2] * 360f), false, paint);
            }
            if (!edit && i == BOOST && hud.nitro > 0.01f) {
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(Ui.dp(4));
                paint.setStrokeCap(Paint.Cap.ROUND);
                paint.setColor(0xFFFFEE58);
                rect.set(x - r - Ui.dp(5), y - r - Ui.dp(5), x + r + Ui.dp(5), y + r + Ui.dp(5));
                c.drawArc(rect, -90, 360f * hud.nitro, false, paint);
            }
            paint.setStyle(Paint.Style.FILL);
            paint.setStrokeCap(Paint.Cap.BUTT);
        }
    }

    private void drawEdit(Canvas c, int W, int H) {
        float d = Ui.density();
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0x88000000);
        c.drawRect(0, 0, W, H, paint);
        drawControls(c, true);
        for (int i = 0; i < 7; i++) {
            if (!visible(i)) continue;
            label(c, Settings.CONTROL_NAMES[i], cx[i], cy[i] + cr[i] + Ui.dp(16), 11 * d, i == editCtl ? 0xFFFFA726 : 0xFFFFFFFF, Paint.Align.CENTER, true);
            if (i == editCtl) {
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(Ui.dp(3));
                paint.setColor(0xFFFFA726);
                c.drawCircle(cx[i], cy[i], cr[i] + Ui.dp(4), paint);
                paint.setStyle(Paint.Style.FILL);
            }
        }
        label(c, "Drag the buttons where you want them", W / 2f, Ui.dp(76), 15 * d, 0xFFFFFFFF, Paint.Align.CENTER, true);
        float bw = Ui.dp(110), bh = Ui.dp(40), by = Ui.dp(14);
        float resetX = W / 2f - bw - Ui.dp(8), doneX = W / 2f + Ui.dp(8);
        paint.setColor(0xFF244566);
        rect.set(resetX, by, resetX + bw, by + bh);
        c.drawRoundRect(rect, Ui.dp(10), Ui.dp(10), paint);
        label(c, "RESET", resetX + bw / 2f, by + bh / 2f + Ui.dp(5), 14 * d, 0xFFFFFFFF, Paint.Align.CENTER, false);
        paint.setColor(0xFFFFA726);
        rect.set(doneX, by, doneX + bw, by + bh);
        c.drawRoundRect(rect, Ui.dp(10), Ui.dp(10), paint);
        label(c, "DONE", doneX + bw / 2f, by + bh / 2f + Ui.dp(5), 14 * d, 0xFF1A1000, Paint.Align.CENTER, false);
    }
}
