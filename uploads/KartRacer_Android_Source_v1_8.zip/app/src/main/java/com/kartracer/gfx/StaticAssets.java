package com.kartracer.gfx;

/** Meshes and textures shared by every track (built once). */
public final class StaticAssets {
    public final MeshData[] bodies = new MeshData[KartModels.TYPES];
    public final MeshData[] wheelsF = new MeshData[KartModels.TYPES], wheelsR = new MeshData[KartModels.TYPES];
    public final MeshData[] drivers = new MeshData[KartModels.DRIVERS];
    public final MeshData rocket = ObjModels.rocket(), coconut = ObjModels.coconut(), slick = ObjModels.slick();
    public final TexGen.Tex detail = TexGen.detail(256), noise = TexGen.noise(256), white = TexGen.white();

    private static StaticAssets instance;

    public static synchronized StaticAssets get() {
        if (instance == null) instance = new StaticAssets();
        return instance;
    }

    private StaticAssets() {
        for (int i = 0; i < KartModels.TYPES; i++) {
            bodies[i] = KartModels.body(i);
            wheelsF[i] = KartModels.wheel(i, false);
            wheelsR[i] = KartModels.wheel(i, true);
        }
        for (int i = 0; i < KartModels.DRIVERS; i++) drivers[i] = KartModels.driver(i);
    }
}
