package com.kartracer.sim;

/** Driver intent for one kart (from touch controls, tilt or AI). */
public final class KartInput {
    public float steer, throttle, brake;
    public boolean drift, boost;
    /** Set true for one step when the item button was pressed. */
    public boolean item;
    /** Steering assist strength of a human driver: 0 = off .. 1 = strong. Always 0 for AI karts. */
    public float assist;

    public void clear() { steer = throttle = brake = assist = 0f; drift = boost = item = false; }

    public void set(KartInput o) { steer = o.steer; throttle = o.throttle; brake = o.brake; drift = o.drift; boost = o.boost; item = o.item; assist = o.assist; }
}
