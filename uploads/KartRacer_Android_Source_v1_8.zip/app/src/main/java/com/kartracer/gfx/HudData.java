package com.kartracer.gfx;

/** Snapshot of race state for the HUD overlay. Written by the game thread, read by the UI thread (benign races). */
public final class HudData {
    public volatile boolean active;
    public float speedKmh, nitro, driftTime, raceTime, serverPing;
    public int place = 1, nKarts = 1, lap = 1, laps = 3, item, driftLevel, phase, localSlot;
    public boolean boosting, wrongWay, finished, drifting, netMode, paused, itemsOn;
    /** While wrongWay: which way to turn to face the road again (-1 left, +1 right, 0 unknown). */
    public int turnHint;
    public String toast = "";
    public long toastUntilMs;
    /** Second line under the toast (short explanation of a picked up item). */
    public String hint = "";
    public long hintUntilMs;
    /** Seconds of shield left on the local kart. */
    public float shieldTime;
    public int mapN;
    public final float[] mapX = new float[8], mapZ = new float[8], mapYaw = new float[8];
    public final int[] mapColor = new int[8], mapPlace = new int[8];
    public final boolean[] mapHuman = new boolean[8];
    public float finishTimeSec;
    public int fps;
    public float renderScale = 1f;
    public String perfLine = "";

    public void toast(String s, long ms) { toast = s; toastUntilMs = System.currentTimeMillis() + ms; hint = ""; hintUntilMs = 0L; }

    public void toast(String s, String sub, long ms) { toast = s; hint = sub == null ? "" : sub; toastUntilMs = hintUntilMs = System.currentTimeMillis() + ms; }
}
