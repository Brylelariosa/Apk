package com.kartracer.gfx;

import com.kartracer.sim.Kart;
import com.kartracer.sim.Race;
import com.kartracer.util.MathX;
import com.kartracer.world.TrackData;

/** Chase camera with smoothing, speed FOV and shake, plus a menu orbit mode. */
public final class CameraRig {
    public float ex, ey, ez, tx, ty, tz, fov = 62f;
    public float shake;
    private float camYaw, px, py, pz;
    private boolean init;
    private float fovCur = 62f;
    private float seed;
    /** Camera roll in radians (a slight bank into a drift) and the smoothed 0..1 amount of "drift camera". */
    public float roll;
    private float driftCam;

    public void reset() { init = false; roll = 0f; driftCam = 0f; }

    public void addShake(float s) { shake = Math.min(1f, Math.max(shake, s)); }

    /** mode 0 close, 1 normal, 2 far. */
    public void chase(Race race, Kart k, float alpha, float dt, int mode, float fovBase, boolean shakeOn) {
        TrackData w = race.track;
        float kx = k.ctrl == Kart.CTRL_REMOTE ? k.x : MathX.lerp(k.ox, k.x, alpha);
        float ky = k.ctrl == Kart.CTRL_REMOTE ? k.y : MathX.lerp(k.oy, k.y, alpha);
        float kz = k.ctrl == Kart.CTRL_REMOTE ? k.z : MathX.lerp(k.oz, k.z, alpha);
        float speed = k.speed();
        float heading = k.yaw;
        driftCam += ((k.drifting && k.grounded ? 1f : 0f) - driftCam) * (1f - (float) Math.exp(-6f * dt));
        if (speed > 7f && k.grounded) {
            // the camera looks along the path of travel, so in a drift the kart is seen slightly side-on (more so than in a normal turn)
            float vh = (float) Math.atan2(k.vx, -k.vz);
            heading = k.yaw + MathX.angleDiff(vh, k.yaw) * (0.35f + 0.27f * driftCam);
        }
        if (!init) { camYaw = k.yaw; px = kx; py = ky; pz = kz; init = true; }
        camYaw += MathX.angleDiff(heading, camYaw) * (1f - (float) Math.exp(-5.5f * dt));
        float dist = mode == 0 ? 5.6f : (mode == 1 ? 7.2f : 9.4f);
        float height = mode == 0 ? 2.5f : (mode == 1 ? 3.1f : 4.0f);
        dist += speed * 0.05f + (k.boostTime > 0f ? 0.8f : 0f);
        float fx = (float) Math.sin(camYaw), fz = -(float) Math.cos(camYaw);
        float k1 = 1f - (float) Math.exp(-12f * dt);
        px += (kx - px) * k1; py += (ky - py) * (1f - (float) Math.exp(-6f * dt)); pz += (kz - pz) * k1;
        if (Math.abs(kx - px) + Math.abs(kz - pz) > 30f) { px = kx; py = ky; pz = kz; }
        float dx = px - fx * dist, dz = pz - fz * dist, dy = py + height;
        float ground = w.groundHeight(dx, dz) + 1.1f;
        if (dy < ground) dy = ground;
        ex = dx; ey = dy; ez = dz;
        tx = px + fx * 5.5f; ty = py + 1.3f; tz = pz + fz * 5.5f;
        float tf = fovBase + MathX.clamp(speed - 20f, 0f, 30f) * 0.18f + (k.boostTime > 0f ? 8f : 0f) + 3.5f * driftCam;
        fovCur += (tf - fovCur) * (1f - (float) Math.exp(-4f * dt));
        fov = fovCur;
        float rollT = k.drifting ? k.driftDir * 0.045f * driftCam : 0f;
        roll += (rollT - roll) * (1f - (float) Math.exp(-5f * dt));
        applyShake(dt, shakeOn);
    }

    private void applyShake(float dt, boolean on) {
        if (shake > 0.001f) {
            if (on) {
                seed += dt * 60f;
                float s = shake * 0.35f;
                ex += (float) Math.sin(seed * 12.9898f) * s; ey += (float) Math.sin(seed * 78.233f) * s * 0.7f; ez += (float) Math.sin(seed * 37.719f) * s;
            }
            shake = Math.max(0f, shake - dt * 2.2f);
        }
    }

    /** Menu orbit around a point. */
    public void orbit(float cx, float cy, float cz, float time, float dist, float height, float yawOffset) {
        float a = time * 0.35f + yawOffset;
        ex = cx + (float) Math.sin(a) * dist; ez = cz + (float) Math.cos(a) * dist; ey = cy + height;
        tx = cx; ty = cy + 0.9f; tz = cz;
        fov = 40f;
        roll = 0f;
    }
}
