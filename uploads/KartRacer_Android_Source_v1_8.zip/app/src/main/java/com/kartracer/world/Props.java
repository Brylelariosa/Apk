package com.kartracer.world;

/** Scenery prop type ids with collision and culling data. */
public final class Props {
    private Props() {}

    public static final int PALM = 0, BUSH = 1, ROCK = 2, JTREE = 3, FERN = 4, MUSHROOM = 5, CACTUS = 6, DEADTREE = 7,
            SPIRE = 8, MESA = 9, UMBRELLA = 10, TORCH = 11, LIGHTHOUSE = 12, SIGN_L = 13, SIGN_R = 14, TUFT = 15,
            TOTEM = 16, BANNER = 17, COUNT = 18;

    /** Collision radius at scale 1 (0 = none). */
    public static final float[] COLL = {0.45f, 0f, 1.0f, 0.75f, 0f, 0f, 0.55f, 0.45f, 1.5f, 0f, 0f, 0f, 3.6f, 0f, 0f, 0f, 0.7f, 0f};   // 1.8: mushroom, umbrella, torch and corner signs are no longer solid (you drive over them)
    /** Bounding sphere radius at scale 1 used for culling. */
    public static final float[] BOUND = {9f, 2.2f, 2.2f, 11f, 1.6f, 2f, 3.5f, 4f, 7f, 10f, 2.5f, 2.2f, 14f, 3f, 3f, 1f, 4f, 4.2f};   // palm and jungle tree grew with the more detailed models (only used for view culling)
    /** Maximum draw distance in meters. */
    public static final float[] DRAW = {300f, 130f, 220f, 300f, 90f, 150f, 220f, 220f, 380f, 650f, 160f, 150f, 700f, 200f, 200f, 55f, 220f, 200f};
    /** Distance beyond which the LOD1 mesh is used. */
    public static final float[] LOD = {55f, 40f, 60f, 60f, 30f, 40f, 50f, 50f, 90f, 160f, 40f, 40f, 160f, 60f, 60f, 20f, 60f, 50f};
    public static boolean castsShadow(int t) { return t != FERN && t != TUFT && t != MESA && t != LIGHTHOUSE; }
}
