package com.kartracer.gl;

import com.kartracer.gfx.MeshData;
import com.kartracer.gfx.SceneData;
import com.kartracer.gfx.WorldMesher;
import com.kartracer.util.MathX;
import com.kartracer.world.Props;
import com.kartracer.world.TrackDef;

/** GPU resources and lighting parameters for one track. */
public final class SceneGfx {
    public final SceneData sd;
    public final TrackDef def;
    public GlChunk[] terrain, water;
    public GlMesh[] roads;
    public final GlMesh[][] props = new GlMesh[Props.COUNT][2];
    public GlMesh[] ramps, pads;
    public GlMesh gate, crate, itemBox, boulder, vent;
    public GlTex roadTex, dirtTex;

    public final float[] sunDir = new float[3], sunCol = new float[3], ambSky = new float[3], ambGround = new float[3];
    public final float[] fogCol = new float[3], top = new float[3], horizon = new float[3], shallow = new float[3], deep = new float[3];
    public float fogDen;

    public SceneGfx(SceneData sd) {
        this.sd = sd;
        this.def = sd.td.def;
        float el = def.sunEl * MathX.DEG, az = def.sunAz * MathX.DEG;
        sunDir[0] = (float) (Math.cos(el) * Math.sin(az)); sunDir[1] = (float) Math.sin(el); sunDir[2] = (float) (Math.cos(el) * Math.cos(az));
        rgb(def.sunColor, 1.00f, sunCol);
        rgb(def.ambSky, 0.44f, ambSky);
        rgb(def.ambGround, 0.38f, ambGround);
        rgb(def.fogColor, 1f, fogCol);
        rgb(def.skyTop, 1f, top);
        rgb(def.skyHorizon, 1f, horizon);
        rgb(def.waterShallow, 1f, shallow);
        rgb(def.waterDeep, 1f, deep);
        fogDen = def.fogDensity;
    }

    private static void rgb(int hex, float k, float[] out) {
        out[0] = ((hex >> 16) & 255) / 255f * k; out[1] = ((hex >> 8) & 255) / 255f * k; out[2] = (hex & 255) / 255f * k;
    }

    public void upload() {
        WorldMesher.ChunkMesh[] cm = sd.chunks;
        terrain = new GlChunk[cm.length];
        water = new GlChunk[cm.length];
        for (int i = 0; i < cm.length; i++) {
            terrain[i] = new GlChunk(cm[i].verts, cm[i].idx);
            terrain[i].upload();
            if (cm[i].hasWater()) { water[i] = new GlChunk(cm[i].wverts, cm[i].widx); water[i].upload(); }
        }
        roads = new GlMesh[sd.roads.length];
        for (int i = 0; i < roads.length; i++) { roads[i] = new GlMesh(sd.roads[i], 0); roads[i].upload(); }
        for (int t = 0; t < Props.COUNT; t++) {
            if (sd.props[t][0] == null) continue;
            for (int l = 0; l < 2; l++) { props[t][l] = new GlMesh(sd.props[t][l], sd.typeCount[t]); props[t][l].upload(); }
        }
        ramps = new GlMesh[sd.rampMeshes.length];
        for (int i = 0; i < ramps.length; i++) { ramps[i] = new GlMesh(sd.rampMeshes[i], 0); ramps[i].upload(); }
        pads = new GlMesh[sd.padMeshes.length];
        for (int i = 0; i < pads.length; i++) { pads[i] = new GlMesh(sd.padMeshes[i], 0); pads[i].upload(); }
        gate = mesh(sd.gate); crate = mesh(sd.crate); itemBox = mesh(sd.itemBox); boulder = mesh(sd.boulder); vent = mesh(sd.vent);
        roadTex = new GlTex(sd.roadTex); roadTex.upload();
        dirtTex = new GlTex(sd.dirtTex); dirtTex.upload();
    }

    private static GlMesh mesh(MeshData d) { GlMesh m = new GlMesh(d, 0); m.upload(); return m; }

    public void release() {
        // GL objects die with the context; explicit deletes only matter when the context survives
        try {
            for (GlChunk c : terrain) c.release();
            for (GlChunk c : water) if (c != null) c.release();
            for (GlMesh m : roads) m.release();
            for (int t = 0; t < Props.COUNT; t++) for (int l = 0; l < 2; l++) if (props[t][l] != null) props[t][l].release();
            for (GlMesh m : ramps) m.release();
            for (GlMesh m : pads) m.release();
            gate.release(); crate.release(); itemBox.release(); boulder.release(); vent.release();
            roadTex.release(); dirtTex.release();
        } catch (RuntimeException ignored) { }
    }
}
