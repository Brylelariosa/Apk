# Kart Racer 1.8 audit (driver, wheel guards, hits)

## What was asked

You marked up the 1.7 kart picture: "wheel guard thin as paper and character is just a circle for head and a bean for body so bad", and then: "hit control its hard and some props like torch is hard, I can't just run it over". I read the last part as: hits are too harsh, and some props (torches) are solid when you should be able to drive over them. If you meant the touch buttons or the steering instead, tell me which part feels hard and I will change that.

## How it was checked

The CPU preview (`tools/preview/Soft.java`, now with a driver close-up view from three angles) rendered every change. The hit changes were measured headless: the same kart driven straight at the same prop at 28 m/s, old code against new code, and the same test lap with the old and new code. The preview is an approximation and nothing was run on a device.

## Findings and changes

1. **Driver ("circle head, bean body").** Accurate: it was a sphere with a black rectangle on top of a rounded box, with no neck or shoulders. Now: shoulder girdle and deltoids, chest, waist, shoulder blades, neck with collar, neck roll and restraint; upper arms with stripe bands, elbows with pads, forearms with cuffs; gloves with four fingers and a thumb wrapped round the steering wheel grips; harness and buckle; helmet with chin bar, lens shaped mirror visor with seal and pivot screws, ear covers, top intake, rear vent and wing, stripes. Built from overlapping ellipsoids, tubes and boxes, about 3.6k triangles (before 2.2k).
2. **Wheel guards ("thin as paper").** Accurate: the shared `arch()` helper made a 0.035 thick shell 0.06 above the tyre. Now 0.085 thick, 0.10 clearance, wider, with rolled lips (tube sectors) along both edges. One helper, so all six karts changed. The guards are bulkier; the body shapes are otherwise unchanged.
3. **Hits.** In `Kart.collideWorld` every touch of a solid prop reflected the speed at 1.4 and then multiplied by 0.92 (so grinding along a prop cost a lot), a hard hit stunned for 0.25 s and a stunned kart kept only 30 % of the gas. Kart to kart bumps stunned 0.4 s and kept 72 % of the speed. Now: reflect 1.35 and keep 98 %, stun only above 9 m/s impact and for 0.10 s, 60 % gas while stunned, bumps 0.18 s and 85 %; a nearly stopped kart pressed against a prop is nudged sideways so it cannot stick. Item hits: spin-out 20 % shorter and keeps 45 % speed (was 35 %), oil 20 % shorter and keeps 70 % (was 60 %), flip 1.4 s (was 1.7 s) and keeps 50 % (was 40 %).
4. **Solid props.** `Props.COLL` is now 0 for mushroom, beach umbrella, torch, and the two corner signs, so there is no collider at all for them. Trees, rocks, cactus, dead tree, spire, totem and lighthouse stay solid. Colliders are only used by the kart physics; nothing else reads them.

## Measured effect of the hit changes

Kart at 28 m/s aimed at a 0.54 m solid prop, 3 s with the gas held, old / new: sideways offset 0.4 m: lowest speed 0.1 / 0.4, average 13.7 / 14.8; offset 0.8 m: lowest 16.1 / 17.2, average 23.9 / 24.7; offset 1.1 m: lowest 22.1 / 23.9, average 26.7 / 27.7. Stun after the hit 0.25 s / 0.10 s. Dead centre head on (no steering at all) still stops the kart, as it would against a tree, but it now slips off instead of staying pinned (speed after 3 s 1.9 / 4.0 m/s). A scripted lap on all four tracks: 91.1 / 92.0, 96.5 / 95.7, 105.9 / 104.8, 91.2 / 91.2 seconds (the differences come from a graze of a prop that the old code handled harder), so normal driving is unchanged.

## Limits

* The car **bodies** are still the same stylized shapes (only fenders, wheels, lamps, seat, steering wheel and driver changed). Remodelling a body is a separate job; tell me which kart you use most.
* The driver is still low-poly: no face (it is under a visor), fingers are tubes.
* Hits are decided by each phone for its own kart, so in an online race you may still see another player's kart bump a torch that is not solid for you. It does not desync the race.
* The preview shows an approximation of the picture, not your phone's.

## Verification status

| Part | Status |
|---|---|
| Models, kart physics, props (pure Java) | compiled and run headless; hit tests and test laps above |
| Android files and GLSL | unchanged since 1.7 (not compiled here, no SDK; before / after compiler comparison clean in 1.7) |
| Behaviour on a device | **not run** |

If the GitHub build turns red, send the red error text.

## Files changed since 1.7

- `README.md`
- `app/build.gradle`
- `app/src/main/java/com/kartracer/gfx/KartModels.java`
- `app/src/main/java/com/kartracer/sim/Kart.java`
- `app/src/main/java/com/kartracer/world/Props.java`
- `tools/preview/Soft.java`
