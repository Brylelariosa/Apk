package com.novaenhance.ai.training.trainer

import com.novaenhance.ai.database.entities.TrainingSessionEntity
import com.novaenhance.ai.storage.SettingsRepository
import com.novaenhance.ai.utils.Constants
import com.novaenhance.ai.utils.DeviceCapabilities
import com.novaenhance.ai.utils.ThermalStatus
import kotlinx.coroutines.flow.first
import kotlin.math.min

/**
 * "Adaptive Training System": a rule-based (not learned/RL) controller that
 * derives a training plan from live device conditions, the trend in recent
 * sessions' loss improvement, AND the user's explicit Settings choices
 * (thermal protection, low-RAM mode). Documented here as heuristic on
 * purpose - this is a set of defensible engineering rules, not a claim of
 * a novel learned meta-optimizer.
 */
class AdaptiveTrainingController(
    private val deviceCapabilities: DeviceCapabilities,
    private val settingsRepository: SettingsRepository
) {

    data class TrainingPlan(
        val batchSize: Int,
        val epochs: Int,
        val learningRate: Float,
        val l2SpLambda: Float,
        val replayFraction: Float,
        val deviceRamMbAtStart: Long,
        val shouldThrottleForThermal: Boolean
    )

    suspend fun planSession(
        datasetSize: Int,
        recentSessions: List<TrainingSessionEntity>,
        uniqueSourceCount: Int = datasetSize
    ): TrainingPlan {
        val snapshot = deviceCapabilities.snapshot()
        val settings = settingsRepository.settings.first()

        val batchSize = when {
            settings.lowRamModeEnabled -> Constants.MIN_BATCH_SIZE
            snapshot.availableRamMb < Constants.CRITICAL_RAM_THRESHOLD_MB -> Constants.MIN_BATCH_SIZE
            snapshot.availableRamMb < Constants.LOW_RAM_THRESHOLD_MB -> 2
            snapshot.availableRamMb > 4096 -> min(Constants.MAX_BATCH_SIZE, Constants.DEFAULT_BATCH_SIZE * 2)
            else -> Constants.DEFAULT_BATCH_SIZE
        }.coerceIn(Constants.MIN_BATCH_SIZE, min(Constants.MAX_BATCH_SIZE, datasetSize.coerceAtLeast(1)))

        val epochs = when {
            datasetSize < 20 -> 2 // small dataset: fewer epochs to avoid overfitting
            // Raw pair count alone misses the case where most pairs are
            // several synthetic degradation variants of the same handful of
            // source photos - DatasetAnalyzer's dedup only catches near-
            // identical low-quality images, not "different degradation,
            // same underlying source." Low distinct-source diversity is the
            // same overfitting risk as a literally small dataset even when
            // datasetSize itself looks large.
            uniqueSourceCount < 20 -> 2
            datasetSize > 200 -> 5
            else -> Constants.DEFAULT_EPOCHS
        }

        val improvementTrend = recentImprovementTrend(recentSessions)
        var learningRate = Constants.DEFAULT_LEARNING_RATE
        if (improvementTrend != null) {
            learningRate = when {
                improvementTrend < 0f -> Constants.DEFAULT_LEARNING_RATE * 0.5f // recent regressions -> be conservative
                improvementTrend < 0.02f -> Constants.DEFAULT_LEARNING_RATE * 1.5f // plateauing -> nudge harder
                else -> Constants.DEFAULT_LEARNING_RATE
            }
        }

        // The more sessions already contributed to this model, the more
        // there is to protect from being overwritten by a new batch of
        // examples - scale the anti-forgetting penalty up accordingly,
        // capped so it can never overwhelm the reconstruction loss.
        val l2SpLambda = if (recentSessions.isEmpty()) {
            0f // nothing learned yet to protect
        } else {
            (0.0005f * min(recentSessions.size, 10)).coerceAtMost(0.005f)
        }
        val replayFraction = if (recentSessions.isEmpty()) 0f else Constants.REPLAY_BATCH_FRACTION

        val shouldThrottle = snapshot.thermalStatus == ThermalStatus.SEVERE ||
            snapshot.thermalStatus == ThermalStatus.CRITICAL

        return TrainingPlan(
            batchSize = batchSize,
            epochs = epochs,
            learningRate = learningRate,
            l2SpLambda = l2SpLambda,
            replayFraction = replayFraction,
            deviceRamMbAtStart = snapshot.availableRamMb,
            shouldThrottleForThermal = shouldThrottle
        )
    }

    /**
     * Re-checked periodically mid-session by [ModelTrainer] to decide
     * whether to auto-pause. Respects the user's "thermal protection"
     * toggle for the SEVERE early-warning threshold, but CRITICAL status
     * (the platform's own "needs to shut down" signal) always pauses
     * regardless of that setting - this is a hardware-safety floor, not a
     * configurable preference.
     */
    suspend fun shouldPauseForDeviceSafety(): Boolean {
        val snapshot = deviceCapabilities.snapshot()
        val settings = settingsRepository.settings.first()

        if (snapshot.thermalStatus == ThermalStatus.CRITICAL) return true
        if (settings.thermalProtectionEnabled && snapshot.thermalStatus == ThermalStatus.SEVERE) return true

        return snapshot.availableRamMb < Constants.CRITICAL_RAM_THRESHOLD_MB / 2
    }

    private fun recentImprovementTrend(sessions: List<TrainingSessionEntity>): Float? {
        val usable = sessions
            .filter { it.initialLoss != null && it.finalLoss != null && it.initialLoss > 0f }
            .take(3)
        if (usable.isEmpty()) return null
        val fractionalImprovements = usable.map { (it.initialLoss!! - it.finalLoss!!) / it.initialLoss!! }
        return fractionalImprovements.average().toFloat()
    }
}
