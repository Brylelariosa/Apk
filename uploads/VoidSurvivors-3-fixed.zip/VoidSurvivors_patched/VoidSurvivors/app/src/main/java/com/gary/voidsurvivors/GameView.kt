package com.gary.voidsurvivors

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import kotlin.math.*

class GameView(context: Context) : SurfaceView(context), SurfaceHolder.Callback, Runnable {

    // ── Thread ───────────────────────────────────────────────────
    private var thread: Thread? = null
    @Volatile private var running = false
    private var lastNano = 0L

    // ── Game state ───────────────────────────────────────────────
    private var state: GameState? = null
    private var sw = 1f; private var sh = 1f

    // ── Meta upgrades (persistent) ───────────────────────────────
    private val meta = MetaUpgrades()
    private val prefs get() = context.getSharedPreferences("VoidSurvivors", Context.MODE_PRIVATE)

    // ── Joystick ─────────────────────────────────────────────────
    private val jBase    = PointF()
    private val jKnob    = PointF()
    private var jActive  = false
    private var jPointer = -1
    private val jRadius  = 90f
    @Volatile private var moveX = 0f
    @Volatile private var moveY = 0f

    // ── Ability buttons ──────────────────────────────────────────
    //  Layout: 3 columns × 2 rows in bottom-right
    private val abilityRects = Array(6) { RectF() }
    private val pauseRect    = RectF()
    @Volatile private var pendingAbility: AbilityId? = null
    private val abilityOrder = AbilityId.values()  // same order as state.abilities

    // ── Level-up card regions ────────────────────────────────────
    private var cardStartY = 0f; private var cardH = 0f
    private var cardSpacing = 0f; private var cardX = 0f; private var cardW = 0f

    // ── Death-screen meta-buy button regions ─────────────────────
    private val metaBuyRects = Array(5) { RectF() }

    // ── Pause screen button regions ──────────────────────────────
    private val resumeRect = RectF(); private val quitRect = RectF()

    // ── Paints ───────────────────────────────────────────────────
    private val pFill   = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val pText   = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textAlign = Paint.Align.CENTER
    }
    private val pArc    = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
    }
    private val shapePath = Path()
    private val arcRect   = RectF()
    private val rng       = kotlin.random.Random.Default  // for shake jitter (render only)

    // ── Colours ──────────────────────────────────────────────────
    private val C_BG          = Color.parseColor("#0B0B1A")
    private val C_GRID        = Color.parseColor("#14142A")
    private val C_PLAYER      = Color.parseColor("#00E5FF")
    private val C_GLOW        = Color.parseColor("#4400CCFF")
    private val C_BASIC       = Color.parseColor("#EE3333")
    private val C_FAST        = Color.parseColor("#FF8800")
    private val C_TANK        = Color.parseColor("#992222")
    private val C_SHOOTER     = Color.parseColor("#CC00CC")
    private val C_SWARM       = Color.parseColor("#FF5577")
    private val C_CHARGER     = Color.parseColor("#FF6600")
    private val C_RANGED      = Color.parseColor("#AA00FF")
    private val C_EXPLODER    = Color.parseColor("#FF8C00")
    private val C_SHIELD_ENM  = Color.parseColor("#0088FF")
    private val C_TELEPORTER  = Color.parseColor("#FF00AA")
    private val C_ELITE       = Color.parseColor("#FFD700")
    private val C_BOSS        = Color.parseColor("#CC0000")
    private val C_BULP        = Color.parseColor("#FFFF33")
    private val C_BULE        = Color.parseColor("#FF2200")
    private val C_XP          = Color.parseColor("#33FF88")
    private val C_HP_BAR      = Color.parseColor("#FF3355")
    private val C_XP_BAR      = Color.parseColor("#00EE66")
    private val C_RANGE       = Color.parseColor("#181835")
    private val C_ORB         = Color.parseColor("#FFDD00")
    private val C_BH          = Color.parseColor("#6600CC")

    // Ability button accent colours (index matches AbilityId ordinal)
    private val C_AB = intArrayOf(
        Color.parseColor("#00AAFF"),  // DASH
        Color.parseColor("#FF6600"),  // SHOCKWAVE
        Color.parseColor("#8800FF"),  // BLACK_HOLE
        Color.parseColor("#00FFCC"),  // TIME_SLOW
        Color.parseColor("#4488FF"),  // SHIELD_PULSE
        Color.parseColor("#FFDD00")   // ENERGY_ORB
    )

    init { holder.addCallback(this) }

    // ── Lifecycle ────────────────────────────────────────────────

    override fun surfaceCreated(holder: SurfaceHolder) {
        sw = width.toFloat().coerceAtLeast(1f)
        sh = height.toFloat().coerceAtLeast(1f)
        loadMeta()
        if (state == null) { state = GameState(sw, sh); GameLogic.reset(state!!, meta) }
        computeLayout()
        startThread()
    }

    override fun surfaceChanged(holder: SurfaceHolder, fmt: Int, w: Int, h: Int) {
        sw = w.toFloat(); sh = h.toFloat()
        // Update the game world bounds to match new screen size
        state?.let { s ->
            val scaleX = sw / s.worldW
            val scaleY = sh / s.worldH
            s.worldW = sw; s.worldH = sh
            // Re-clamp player position to new bounds
            s.player.x = (s.player.x * scaleX).coerceIn(s.player.radius, sw - s.player.radius)
            s.player.y = (s.player.y * scaleY).coerceIn(s.player.radius, sh - s.player.radius)
        }
        computeLayout()
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) = stopThread()

    fun pause()  = stopThread()
    fun resume() { state?.let { startThread() } }

    private fun startThread() {
        if (running) return
        running = true; lastNano = System.nanoTime()
        thread = Thread(this, "GameLoop").also { it.start() }
    }

    private fun stopThread() {
        running = false; thread?.join(300); thread = null
    }

    // ── Layout pre-computation ───────────────────────────────────

    private fun computeLayout() {
        val btnSz = 76f; val gap = 8f; val rPad = 12f
        val totalW = 3 * btnSz + 2 * gap
        val totalH = 2 * btnSz + 1 * gap
        val startX = sw - totalW - rPad
        val startY = sh - totalH - 110f   // above bottom edge

        for (i in 0..5) {
            val col = i % 3; val row = i / 3
            val x   = startX + col * (btnSz + gap)
            val y   = startY + row * (btnSz + gap)
            abilityRects[i].set(x, y, x + btnSz, y + btnSz)
        }

        // Pause button: top-right
        pauseRect.set(sw - 64f, 10f, sw - 10f, 64f)

        // Pause screen buttons
        resumeRect.set(sw * 0.25f, sh * 0.44f, sw * 0.75f, sh * 0.56f)
        quitRect.set(  sw * 0.25f, sh * 0.62f, sw * 0.75f, sh * 0.74f)
    }

    // ── Game loop ────────────────────────────────────────────────

    override fun run() {
        while (running) {
            val now = System.nanoTime()
            val dt  = ((now - lastNano) / 1_000_000_000f).coerceIn(0f, 0.05f)
            lastNano = now
            val s = state ?: continue

            // Consume pending ability press from UI thread
            pendingAbility?.let { id ->
                GameLogic.activateAbility(s, id, moveX, moveY)
                pendingAbility = null
            }

            GameLogic.update(s, dt, moveX, moveY)

            val canvas = holder.lockCanvas() ?: continue
            try { drawFrame(canvas, s) } finally { holder.unlockCanvasAndPost(canvas) }

            val usedMs = (System.nanoTime() - now) / 1_000_000L
            val sleepMs = 16L - usedMs
            if (sleepMs > 1) Thread.sleep(sleepMs)
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  Top-level draw dispatch
    // ═══════════════════════════════════════════════════════════════

    private fun drawFrame(c: Canvas, s: GameState) {
        when (s.phase) {
            Phase.PLAYING  -> drawGame(c, s)
            Phase.LEVEL_UP -> { drawGame(c, s); drawLevelUp(c, s) }
            Phase.DEAD     -> drawDead(c, s)
            Phase.PAUSED   -> { drawGame(c, s); drawPause(c, s) }
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  Game world
    // ═══════════════════════════════════════════════════════════════

    private fun drawGame(c: Canvas, s: GameState) {
        val p = s.player

        // ── Screen shake: wrap world in a translate ──────────────
        val shaking = s.shakeTimer > 0f
        if (shaking) {
            c.save()
            val amt = s.shakeAmt * (s.shakeTimer / 1.5f).coerceIn(0f, 1f)
            c.translate(rng.nextFloat() * amt * 2f - amt, rng.nextFloat() * amt * 2f - amt)
        }

        // Background
        val darkEvt = s.currentEvent == EventType.DARKNESS
        pFill.color = if (darkEvt) Color.parseColor("#020208") else C_BG
        c.drawRect(0f, 0f, sw, sh, pFill)

        // Grid (skip during darkness for effect)
        if (!darkEvt) {
            pStroke.color = C_GRID; pStroke.strokeWidth = 1f
            val gs = 70f
            var gx = 0f; while (gx <= sw) { c.drawLine(gx, 0f, gx, sh, pStroke); gx += gs }
            var gy = 0f; while (gy <= sh) { c.drawLine(0f, gy, sw, gy, pStroke); gy += gs }
        }

        // Range ring
        pStroke.color = C_RANGE; pStroke.strokeWidth = 1.5f
        c.drawCircle(p.x, p.y, p.range, pStroke)

        // Black holes
        for (bh in s.blackHoles) {
            val lifeF = (bh.life / bh.maxLife).coerceIn(0f, 1f)
            pFill.color = Color.argb((190 * lifeF).toInt(), 30, 0, 80)
            c.drawCircle(bh.x, bh.y, bh.radius * lifeF, pFill)
            pStroke.color = Color.argb((180 * lifeF).toInt(), 136, 0, 255)
            pStroke.strokeWidth = 3f
            c.drawCircle(bh.x, bh.y, bh.radius * lifeF + 10f, pStroke)
            // Inner swirl ring
            pStroke.color = Color.argb((100 * lifeF).toInt(), 200, 0, 255)
            pStroke.strokeWidth = 1.5f
            c.drawCircle(bh.x, bh.y, bh.radius * lifeF * 0.5f, pStroke)
        }

        // XP orbs (soft glow)
        for (orb in s.orbs) {
            pFill.color = Color.argb(60, 0, 255, 128)
            c.drawCircle(orb.x, orb.y, orb.radius + 4f, pFill)
            pFill.color = C_XP
            c.drawCircle(orb.x, orb.y, orb.radius, pFill)
        }

        // Bullets
        for (b in s.bullets) {
            if (b.fromPlayer) {
                pFill.color = Color.argb(80, 255, 255, 0)
                c.drawCircle(b.x, b.y, b.radius + 4f, pFill)
                pFill.color = C_BULP
            } else {
                pFill.color = C_BULE
            }
            c.drawCircle(b.x, b.y, b.radius, pFill)
        }

        // Enemies
        drawEnemies(c, s, p)

        // Particles
        for (pt in s.particles) {
            if (!pt.active) continue
            val lifeF = (pt.life / pt.maxLife).coerceIn(0f, 1f)
            val alpha = (lifeF * 230).toInt().coerceIn(0, 255)
            pFill.color = Color.argb(alpha, Color.red(pt.color), Color.green(pt.color), Color.blue(pt.color))
            c.drawCircle(pt.x, pt.y, pt.radius * lifeF, pFill)
        }

        // Energy orbs orbiting player
        drawOrbsAround(c, s, p)

        // Shield ring around player
        if (p.shieldActive) {
            val sf = (p.shieldTimer / p.shieldDuration).coerceIn(0f, 1f)
            pFill.color  = Color.argb((40 * sf).toInt(), 68, 136, 255)
            c.drawCircle(p.x, p.y, p.radius + 24f, pFill)
            pStroke.color = Color.argb((200 * sf).toInt(), 68, 136, 255)
            pStroke.strokeWidth = 5f
            c.drawCircle(p.x, p.y, p.radius + 24f, pStroke)
        }

        // Player glow
        pFill.color = C_GLOW
        c.drawCircle(p.x, p.y, p.radius + 16f, pFill)

        // Player body (blinks during i-frames)
        val blink = p.iFrames > 0f && (p.iFrames * 10).toInt() % 2 == 0
        pFill.color = if (blink) Color.WHITE else C_PLAYER
        c.drawCircle(p.x, p.y, p.radius, pFill)
        pStroke.color = Color.WHITE; pStroke.strokeWidth = 2.5f
        c.drawCircle(p.x, p.y, p.radius, pStroke)

        // Time slow full-screen tint
        if (s.timeSlowActive) {
            pFill.color = Color.argb(22, 0, 255, 200)
            c.drawRect(0f, 0f, sw, sh, pFill)
            pStroke.color = Color.argb(55, 0, 255, 200); pStroke.strokeWidth = 5f
            c.drawRect(2f, 2f, sw - 2f, sh - 2f, pStroke)
        }

        // Float texts
        for (ft in s.floatTexts) {
            val alpha = ((ft.life / 0.9f) * 255).toInt().coerceIn(0, 255)
            pText.color = (ft.color and 0x00FFFFFF) or (alpha shl 24)
            pText.textSize = 26f * ft.scale
            pText.isFakeBoldText = ft.isCrit
            c.drawText(ft.text, ft.x, ft.y, pText)
        }
        pText.isFakeBoldText = false

        if (shaking) c.restore()

        // ── HUD (not affected by shake) ──────────────────────────
        drawHUD(c, s)
        drawAbilityButtons(c, s)
        if (s.boss != null)              drawBossBar(c, s)
        s.eventAnnouncement?.let         { drawEventBanner(c, it) }
        if (s.showBossWarning)           drawBossWarning(c, s)
    }

    // ── Enemy shapes ─────────────────────────────────────────────

    private fun drawEnemies(c: Canvas, s: GameState, p: Player) {
        for (e in s.enemies) {
            if (e.hp <= 0f) continue

            // Shield ring
            if (e.type == EnemyType.SHIELD_ENEMY && !e.shieldBroken && e.shieldHp > 0f) {
                val sf = e.shieldHp / e.maxShieldHp
                pStroke.color = Color.argb((200 * sf).toInt(), 0, 136, 255)
                pStroke.strokeWidth = 5f
                c.drawCircle(e.x, e.y, e.radius + 15f, pStroke)
            }

            val baseColor = when (e.type) {
                EnemyType.BASIC        -> C_BASIC
                EnemyType.FAST         -> C_FAST
                EnemyType.TANK         -> C_TANK
                EnemyType.SHOOTER      -> C_SHOOTER
                EnemyType.SWARM        -> C_SWARM
                EnemyType.CHARGER      -> C_CHARGER
                EnemyType.RANGED       -> C_RANGED
                EnemyType.EXPLODER     -> C_EXPLODER
                EnemyType.SHIELD_ENEMY -> C_SHIELD_ENM
                EnemyType.TELEPORTER   -> C_TELEPORTER
                EnemyType.ELITE        -> C_ELITE
                EnemyType.BOSS         -> C_BOSS
            }
            val rage = e.hp < e.maxHp * 0.3f

            // Elite / Boss outer glow
            if (e.type == EnemyType.ELITE || e.type == EnemyType.BOSS) {
                pFill.color = Color.argb(if (rage) 110 else 65,
                    Color.red(baseColor), Color.green(baseColor), Color.blue(baseColor))
                c.drawCircle(e.x, e.y, e.radius + 14f, pFill)
            }

            pFill.color = when {
                e.flashTimer > 0f                 -> Color.WHITE
                rage && e.type != EnemyType.BOSS  -> Color.parseColor("#FF5500")
                else                              -> baseColor
            }

            when (e.type) {
                EnemyType.BASIC        -> drawSquare(c, e.x, e.y, e.radius)
                EnemyType.FAST         -> drawTriangle(c, e.x, e.y, e.radius, atan2(p.y - e.y, p.x - e.x))
                EnemyType.TANK         -> drawHexagon(c, e.x, e.y, e.radius)
                EnemyType.SHOOTER      -> drawDiamond(c, e.x, e.y, e.radius)
                EnemyType.SWARM        -> c.drawCircle(e.x, e.y, e.radius, pFill)
                EnemyType.CHARGER      -> drawArrow(c, e.x, e.y, e.radius, atan2(p.y - e.y, p.x - e.x))
                EnemyType.RANGED       -> drawCross(c, e.x, e.y, e.radius)
                EnemyType.EXPLODER     -> drawExploder(c, e)
                EnemyType.SHIELD_ENEMY -> drawPentagon(c, e.x, e.y, e.radius)
                EnemyType.TELEPORTER   -> drawStar(c, e.x, e.y, e.radius)
                EnemyType.ELITE        -> { drawHexagon(c, e.x, e.y, e.radius); drawEliteCrown(c, e) }
                EnemyType.BOSS         -> drawBossShape(c, e)
            }

            // HP mini-bar
            if (e.type != EnemyType.BOSS) {
                val hpF   = (e.hp / e.maxHp).coerceIn(0f, 1f)
                val barY  = e.y - e.radius - 10f
                pFill.color = Color.parseColor("#55000000")
                c.drawRect(e.x - e.radius, barY - 4f, e.x + e.radius, barY + 4f, pFill)
                pFill.color = when { hpF > 0.5f -> C_HP_BAR; hpF > 0.25f -> Color.parseColor("#FF8800"); else -> Color.parseColor("#FF2200") }
                if (hpF > 0f) c.drawRect(e.x - e.radius, barY - 4f, e.x - e.radius + e.radius * 2f * hpF, barY + 4f, pFill)
            }
        }
    }

    // ── Orbs orbiting player ─────────────────────────────────────

    private fun drawOrbsAround(c: Canvas, s: GameState, p: Player) {
        val ab = s.abilities.find { it.id == AbilityId.ENERGY_ORB }
        if ((ab?.level ?: 0) == 0) return
        val orbCount = ab!!.level.coerceAtMost(3)
        val orbR     = 75f + p.areaScale * 15f

        repeat(orbCount) { i ->
            val angle = p.orbAngle + i * (2f * PI.toFloat() / orbCount)
            val ox    = p.x + cos(angle) * orbR
            val oy    = p.y + sin(angle) * orbR
            // Glow halo
            pFill.color = if (p.orbBurst) Color.argb(120, 255, 255, 200) else Color.argb(70, 255, 220, 0)
            c.drawCircle(ox, oy, 20f, pFill)
            // Core
            pFill.color = if (p.orbBurst) Color.WHITE else C_ORB
            c.drawCircle(ox, oy, 13f, pFill)
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  HUD
    // ═══════════════════════════════════════════════════════════════

    private fun drawHUD(c: Canvas, s: GameState) {
        val p   = s.player
        val pad = 16f; val bh = 22f; val bw = sw * 0.50f; val rr = 6f

        // HP bar
        pFill.color = Color.parseColor("#55000000")
        c.drawRoundRect(pad - 4f, pad - 4f, pad + bw + 4f, pad + bh + 4f, rr, rr, pFill)
        pFill.color = Color.parseColor("#33FF0033")
        c.drawRoundRect(pad, pad, pad + bw, pad + bh, rr, rr, pFill)
        val hpF    = (p.hp / p.maxHp).coerceIn(0f, 1f)
        pFill.color = when { hpF > 0.5f -> C_HP_BAR; hpF > 0.25f -> Color.parseColor("#FF8800"); else -> Color.parseColor("#FF2200") }
        if (hpF > 0f) c.drawRoundRect(pad, pad, pad + bw * hpF, pad + bh, rr, rr, pFill)
        pText.textAlign = Paint.Align.LEFT; pText.textSize = 17f; pText.color = Color.WHITE
        c.drawText("HP  ${p.hp.toInt()} / ${p.maxHp.toInt()}", pad + 6f, pad + bh - 3f, pText)

        // XP bar
        val xy = pad + bh + 8f
        pFill.color = Color.parseColor("#55000000")
        c.drawRoundRect(pad - 4f, xy - 4f, pad + bw + 4f, xy + bh + 4f, rr, rr, pFill)
        pFill.color = Color.parseColor("#2200FF55")
        c.drawRoundRect(pad, xy, pad + bw, xy + bh, rr, rr, pFill)
        val xpF = (p.xp / p.xpNext).coerceIn(0f, 1f)
        pFill.color = C_XP_BAR
        if (xpF > 0f) c.drawRoundRect(pad, xy, pad + bw * xpF, xy + bh, rr, rr, pFill)
        pText.textSize = 17f
        c.drawText("LV ${p.level}   XP ${p.xp.toInt()} / ${p.xpNext.toInt()}", pad + 6f, xy + bh - 3f, pText)

        // Top-right stats
        pText.textAlign = Paint.Align.RIGHT; pText.textSize = 21f; pText.color = Color.WHITE
        val el = s.elapsed.toInt()
        c.drawText("Wave ${s.wave}   ${el / 60}:%02d".format(el % 60), sw - pad, pad + 20f, pText)
        pText.textSize = 18f
        c.drawText("Kills  ${s.kills}", sw - pad, pad + 44f, pText)

        // Active event label
        s.currentEvent?.let { evt ->
            pText.textAlign = Paint.Align.CENTER; pText.textSize = 20f
            pText.color = Color.parseColor("#FFAA00")
            c.drawText(eventLabel(evt), sw / 2f, sh * 0.06f, pText)
        }

        // Pause button
        pFill.color = Color.parseColor("#40FFFFFF")
        c.drawRoundRect(pauseRect, 10f, 10f, pFill)
        pText.textAlign = Paint.Align.CENTER; pText.textSize = 19f; pText.color = Color.WHITE
        c.drawText("II", (pauseRect.left + pauseRect.right) / 2f,
            (pauseRect.top + pauseRect.bottom) / 2f + 7f, pText)

        // Joystick
        if (jActive) {
            pFill.color = Color.parseColor("#30FFFFFF")
            c.drawCircle(jBase.x, jBase.y, jRadius, pFill)
            pStroke.color = Color.parseColor("#55FFFFFF"); pStroke.strokeWidth = 2f
            c.drawCircle(jBase.x, jBase.y, jRadius, pStroke)
            pFill.color = Color.parseColor("#60FFFFFF")
            c.drawCircle(jKnob.x, jKnob.y, jRadius * 0.42f, pFill)
        }
    }

    // ── Ability buttons ──────────────────────────────────────────

    private fun drawAbilityButtons(c: Canvas, s: GameState) {
        val p = s.player
        for (i in 0..5) {
            val rect = abilityRects[i]
            val ab   = s.abilities.find { it.id == abilityOrder[i] } ?: continue
            val col  = C_AB[i]
            val locked = ab.level == 0

            // Card background
            pFill.color = if (locked) Color.parseColor("#40111111") else Color.parseColor("#BB000000")
            c.drawRoundRect(rect, 14f, 14f, pFill)

            // Border
            pStroke.strokeWidth = 2.5f
            pStroke.color = when {
                locked       -> Color.parseColor("#33FFFFFF")
                ab.isReady() -> col
                else         -> Color.parseColor("#55FFFFFF")
            }
            c.drawRoundRect(rect, 14f, 14f, pStroke)

            if (!locked) {
                if (!ab.isReady()) {
                    // Cooldown: dark overlay + arc
                    val cd   = ab.effectiveCd(p.cdr)
                    val frac = (ab.cdTimer / cd).coerceIn(0f, 1f)
                    pFill.color = Color.parseColor("#88000000")
                    c.drawRoundRect(rect, 14f, 14f, pFill)

                    pArc.color = col; pArc.strokeWidth = 5f
                    arcRect.set(rect.left + 8f, rect.top + 8f, rect.right - 8f, rect.bottom - 8f)
                    c.drawArc(arcRect, -90f, (1f - frac) * 360f, false, pArc)

                    pText.textSize = 17f; pText.color = Color.WHITE
                    pText.textAlign = Paint.Align.CENTER
                    c.drawText("%.1f".format(ab.cdTimer),
                        (rect.left + rect.right) / 2f, (rect.top + rect.bottom) / 2f + 6f, pText)
                } else {
                    // Ready: subtle colour fill
                    pFill.color = Color.argb(45, Color.red(col), Color.green(col), Color.blue(col))
                    c.drawRoundRect(rect, 14f, 14f, pFill)
                }
            }

            // Label
            val cx = (rect.left + rect.right) / 2f
            val cy = (rect.top  + rect.bottom) / 2f
            pText.textAlign = Paint.Align.CENTER
            pText.textSize  = if (locked) 14f else 15f
            pText.color     = if (locked) Color.parseColor("#44FFFFFF") else Color.WHITE
            pText.isFakeBoldText = !locked
            c.drawText(ab.label, cx, cy + 5f, pText)
            pText.isFakeBoldText = false

            // Level indicator dots
            if (!locked) {
                val dotR = 4f; val dotY = rect.bottom - 11f
                val spread = (ab.level - 1) * 10f
                repeat(ab.level) { j ->
                    pFill.color = col
                    c.drawCircle(cx - spread / 2f + j * 10f, dotY, dotR, pFill)
                }
            }
        }
    }

    // ── Boss HP bar ──────────────────────────────────────────────

    private fun drawBossBar(c: Canvas, s: GameState) {
        val boss = s.boss ?: return
        val bw   = sw * 0.70f; val bx = (sw - bw) / 2f
        val by   = sh - 78f;  val bh = 28f; val rr = 8f
        val hpF  = (boss.hp / boss.maxHp).coerceIn(0f, 1f)

        pFill.color = Color.parseColor("#AA000000")
        c.drawRoundRect(bx - 4f, by - 4f, bx + bw + 4f, by + bh + 4f, rr, rr, pFill)
        pFill.color = Color.parseColor("#44FF0000")
        c.drawRoundRect(bx, by, bx + bw, by + bh, rr, rr, pFill)

        val bossCol = when (boss.bossPhase) {
            3 -> Color.parseColor("#FF4400"); 2 -> Color.parseColor("#FF2200"); else -> Color.parseColor("#CC0022")
        }
        pFill.color = bossCol
        if (hpF > 0f) c.drawRoundRect(bx, by, bx + bw * hpF, by + bh, rr, rr, pFill)

        pStroke.color = Color.parseColor("#FF4444"); pStroke.strokeWidth = 2.5f
        c.drawRoundRect(bx, by, bx + bw, by + bh, rr, rr, pStroke)

        pText.textAlign = Paint.Align.CENTER; pText.textSize = 18f; pText.color = Color.WHITE
        c.drawText("BOSS  ${boss.hp.toInt()} / ${boss.maxHp.toInt()}  [Phase ${boss.bossPhase}]",
            sw / 2f, by + bh - 5f, pText)
    }

    // ── Event banner ─────────────────────────────────────────────

    private fun drawEventBanner(c: Canvas, ann: EventAnnouncement) {
        val alpha = ((ann.warningTimer / 2.5f) * 255).toInt().coerceIn(0, 255)
        pFill.color = Color.argb(alpha * 2 / 3, 20, 0, 40)
        c.drawRoundRect(sw * 0.10f, sh * 0.37f, sw * 0.90f, sh * 0.55f, 22f, 22f, pFill)

        pText.textAlign = Paint.Align.CENTER
        pText.textSize  = 50f; pText.color = Color.argb(alpha, 255, 180, 0)
        c.drawText(eventLabel(ann.type), sw / 2f, sh * 0.47f, pText)
        pText.textSize = 22f; pText.color = Color.argb(alpha, 200, 200, 200)
        c.drawText("INCOMING!", sw / 2f, sh * 0.525f, pText)
    }

    private fun eventLabel(e: EventType) = when (e) {
        EventType.SWARM_RUSH  -> "!! SWARM RUSH"
        EventType.DARKNESS    -> "!! DARKNESS"
        EventType.METEOR_RAIN -> "!! METEOR RAIN"
        EventType.ELITE_ONLY  -> "!! ELITE WAVE"
        EventType.SLOW_MOTION -> "!! SLOW MOTION"
    }

    // ── Boss warning overlay ──────────────────────────────────────

    private fun drawBossWarning(c: Canvas, s: GameState) {
        val a = ((s.bossWarningTimer / 3f) * 255).toInt().coerceIn(0, 255)
        pFill.color = Color.argb(a / 3, 80, 0, 0)
        c.drawRect(0f, 0f, sw, sh, pFill)
        pText.textAlign = Paint.Align.CENTER
        pText.textSize  = 60f; pText.color = Color.argb(a, 255, 50, 50)
        c.drawText("BOSS APPROACHING!", sw / 2f, sh * 0.38f, pText)
        pText.textSize = 28f; pText.color = Color.argb(a, 255, 180, 180)
        c.drawText("Wave ${s.wave}", sw / 2f, sh * 0.50f, pText)
    }

    // ═══════════════════════════════════════════════════════════════
    //  Level-up screen
    // ═══════════════════════════════════════════════════════════════

    private fun drawLevelUp(c: Canvas, s: GameState) {
        pFill.color = Color.parseColor("#CC000015")
        c.drawRect(0f, 0f, sw, sh, pFill)

        pText.textAlign = Paint.Align.CENTER
        pText.color = Color.WHITE; pText.textSize = 52f; pText.isFakeBoldText = true
        c.drawText("LEVEL  UP!", sw / 2f, sh * 0.16f, pText)
        pText.isFakeBoldText = false
        pText.textSize = 22f; pText.color = Color.parseColor("#AAFFCC")
        c.drawText("Choose an upgrade", sw / 2f, sh * 0.24f, pText)

        val cw  = sw * 0.82f; val ch = 102f
        val cx  = (sw - cw) / 2f
        val spc = ch + 16f; val sy = sh * 0.30f
        cardStartY = sy; cardH = ch; cardSpacing = spc; cardX = cx; cardW = cw

        s.pendingUpgrades.forEachIndexed { i, up ->
            val cy2 = sy + i * spc
            pFill.color = when (up.rarity) {
                3 -> Color.parseColor("#AA6600CC"); 2 -> Color.parseColor("#AA0055CC")
                else -> Color.parseColor("#AA003320")
            }
            c.drawRoundRect(cx, cy2, cx + cw, cy2 + ch, 16f, 16f, pFill)

            pStroke.strokeWidth = 3f; pStroke.color = when (up.rarity) {
                3 -> Color.parseColor("#CC55FF"); 2 -> Color.parseColor("#55AAFF"); else -> Color.parseColor("#55FF99")
            }
            c.drawRoundRect(cx, cy2, cx + cw, cy2 + ch, 16f, 16f, pStroke)

            val rl = when (up.rarity) { 3 -> "EVO  /  EPIC"; 2 -> "** RARE"; else -> "* COMMON" }
            pText.textSize = 16f; pText.color = pStroke.color
            c.drawText(rl, sw / 2f, cy2 + 22f, pText)
            pText.color = Color.WHITE; pText.textSize = 27f; pText.isFakeBoldText = true
            c.drawText(up.name, sw / 2f, cy2 + 52f, pText)
            pText.isFakeBoldText = false
            pText.color = Color.parseColor("#CCCCCC"); pText.textSize = 19f
            c.drawText(up.desc, sw / 2f, cy2 + 80f, pText)
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  Death screen + meta upgrades
    // ═══════════════════════════════════════════════════════════════

    private fun drawDead(c: Canvas, s: GameState) {
        pFill.color = Color.parseColor("#1A0000")
        c.drawRect(0f, 0f, sw, sh, pFill)

        pText.textAlign = Paint.Align.CENTER
        pText.color = Color.parseColor("#FF3333"); pText.textSize = 60f; pText.isFakeBoldText = true
        c.drawText("YOU DIED", sw / 2f, sh * 0.20f, pText)
        pText.isFakeBoldText = false

        val el = s.elapsed.toInt()
        pText.color = Color.WHITE; pText.textSize = 24f
        c.drawText("Survived  ${el / 60}m %02ds".format(el % 60), sw / 2f, sh * 0.31f, pText)
        c.drawText("Wave ${s.wave}    Kills ${s.kills}    Lv ${s.player.level}", sw / 2f, sh * 0.38f, pText)
        pText.color = Color.parseColor("#FFCC44"); pText.textSize = 20f
        c.drawText("Coins earned: ${s.runCurrency}  /  Total: ${meta.currency + s.runCurrency}",
            sw / 2f, sh * 0.44f, pText)

        // Meta header
        pText.textSize = 18f; pText.color = Color.parseColor("#AAAAFF")
        c.drawText("PERMANENT UPGRADES  (${meta.currency + s.runCurrency} coins)", sw / 2f, sh * 0.50f, pText)

        val labels = arrayOf(
            "HP +20   (Lv ${meta.hpLevel})   Cost: ${meta.costHp()}",
            "Speed +15   (Lv ${meta.speedLevel})   Cost: ${meta.costSpeed()}",
            "CDR -5%   (Lv ${meta.cdrLevel})   Cost: ${meta.costCdr()}",
            "XP Gain +10%   (Lv ${meta.xpLevel})   Cost: ${meta.costXp()}",
            "SAVE & PLAY AGAIN"
        )
        val mBtnW = sw * 0.72f; val mBtnH = 46f; val mBtnX = (sw - mBtnW) / 2f
        val mStart = sh * 0.54f; val mGap = mBtnH + 7f

        for (i in 0..4) {
            val my = mStart + i * mGap
            metaBuyRects[i].set(mBtnX, my, mBtnX + mBtnW, my + mBtnH)
            pFill.color = if (i == 4) Color.parseColor("#AA441111") else Color.parseColor("#AA002244")
            c.drawRoundRect(metaBuyRects[i], 10f, 10f, pFill)
            pStroke.strokeWidth = 2f
            pStroke.color = if (i == 4) Color.parseColor("#FF4444") else Color.parseColor("#4488FF")
            c.drawRoundRect(metaBuyRects[i], 10f, 10f, pStroke)
            pText.color = Color.WHITE; pText.textSize = 19f
            c.drawText(labels[i], sw / 2f, my + mBtnH * 0.66f, pText)
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  Pause screen
    // ═══════════════════════════════════════════════════════════════

    private fun drawPause(c: Canvas, s: GameState) {
        pFill.color = Color.parseColor("#CC000015")
        c.drawRect(0f, 0f, sw, sh, pFill)
        pText.textAlign = Paint.Align.CENTER
        pText.color = Color.WHITE; pText.textSize = 58f; pText.isFakeBoldText = true
        c.drawText("PAUSED", sw / 2f, sh * 0.28f, pText)
        pText.isFakeBoldText = false

        // Resume
        pFill.color = Color.parseColor("#AA003322")
        c.drawRoundRect(resumeRect, 16f, 16f, pFill)
        pStroke.color = Color.parseColor("#44FF88"); pStroke.strokeWidth = 3f
        c.drawRoundRect(resumeRect, 16f, 16f, pStroke)
        pText.textSize = 32f; pText.color = Color.WHITE
        c.drawText("RESUME", sw / 2f, (resumeRect.top + resumeRect.bottom) / 2f + 11f, pText)

        // Quit
        pFill.color = Color.parseColor("#AA330000")
        c.drawRoundRect(quitRect, 16f, 16f, pFill)
        pStroke.color = Color.parseColor("#FF4444"); pStroke.strokeWidth = 3f
        c.drawRoundRect(quitRect, 16f, 16f, pStroke)
        pText.textSize = 32f; pText.color = Color.WHITE
        c.drawText("QUIT RUN", sw / 2f, (quitRect.top + quitRect.bottom) / 2f + 11f, pText)
    }

    // ═══════════════════════════════════════════════════════════════
    //  Shape helpers
    // ═══════════════════════════════════════════════════════════════

    private fun drawSquare(c: Canvas, cx: Float, cy: Float, r: Float) {
        c.drawRect(cx - r, cy - r, cx + r, cy + r, pFill)
    }

    private fun drawTriangle(c: Canvas, cx: Float, cy: Float, r: Float, angle: Float) {
        shapePath.reset()
        for (i in 0..2) {
            val a = angle + i * (2f * PI.toFloat() / 3f)
            val x = cx + cos(a) * r; val y = cy + sin(a) * r
            if (i == 0) shapePath.moveTo(x, y) else shapePath.lineTo(x, y)
        }
        shapePath.close(); c.drawPath(shapePath, pFill)
    }

    private fun drawHexagon(c: Canvas, cx: Float, cy: Float, r: Float) {
        shapePath.reset()
        for (i in 0..5) {
            val a = i * (PI.toFloat() / 3f)
            val x = cx + cos(a) * r; val y = cy + sin(a) * r
            if (i == 0) shapePath.moveTo(x, y) else shapePath.lineTo(x, y)
        }
        shapePath.close(); c.drawPath(shapePath, pFill)
    }

    private fun drawDiamond(c: Canvas, cx: Float, cy: Float, r: Float) {
        shapePath.reset()
        shapePath.moveTo(cx, cy - r); shapePath.lineTo(cx + r, cy)
        shapePath.lineTo(cx, cy + r); shapePath.lineTo(cx - r, cy)
        shapePath.close(); c.drawPath(shapePath, pFill)
    }

    // Charger: fat arrow pointing toward player
    private fun drawArrow(c: Canvas, cx: Float, cy: Float, r: Float, angle: Float) {
        shapePath.reset()
        val tip = angle
        val back = angle + PI.toFloat()
        shapePath.moveTo(cx + cos(tip) * r, cy + sin(tip) * r)
        shapePath.lineTo(cx + cos(back + 0.9f) * r * 0.8f, cy + sin(back + 0.9f) * r * 0.8f)
        shapePath.lineTo(cx + cos(back) * r * 0.4f, cy + sin(back) * r * 0.4f)
        shapePath.lineTo(cx + cos(back - 0.9f) * r * 0.8f, cy + sin(back - 0.9f) * r * 0.8f)
        shapePath.close(); c.drawPath(shapePath, pFill)
    }

    // Ranged: plus/cross
    private fun drawCross(c: Canvas, cx: Float, cy: Float, r: Float) {
        val arm = r * 0.4f
        pFill.color.also {
            c.drawRect(cx - arm, cy - r, cx + arm, cy + r, pFill)
            c.drawRect(cx - r, cy - arm, cx + r, cy + arm, pFill)
        }
    }

    // Exploder: circle + warning marks
    private fun drawExploder(c: Canvas, e: Enemy) {
        c.drawCircle(e.x, e.y, e.radius, pFill)
        // Draw three warning lines radiating out
        val warnCol = pFill.color
        pStroke.color = Color.parseColor("#FFFF00"); pStroke.strokeWidth = 2.5f
        repeat(3) { i ->
            val a = i * (2f * PI.toFloat() / 3f)
            c.drawLine(e.x + cos(a) * e.radius * 0.4f, e.y + sin(a) * e.radius * 0.4f,
                e.x + cos(a) * e.radius * 0.9f, e.y + sin(a) * e.radius * 0.9f, pStroke)
        }
    }

    // Shield enemy: pentagon
    private fun drawPentagon(c: Canvas, cx: Float, cy: Float, r: Float) {
        shapePath.reset()
        for (i in 0..4) {
            val a = i * (2f * PI.toFloat() / 5f) - PI.toFloat() / 2f
            val x = cx + cos(a) * r; val y = cy + sin(a) * r
            if (i == 0) shapePath.moveTo(x, y) else shapePath.lineTo(x, y)
        }
        shapePath.close(); c.drawPath(shapePath, pFill)
    }

    // Teleporter: 4-point star
    private fun drawStar(c: Canvas, cx: Float, cy: Float, r: Float) {
        shapePath.reset()
        for (i in 0..7) {
            val a     = i * (PI.toFloat() / 4f)
            val rInst = if (i % 2 == 0) r else r * 0.45f
            val x = cx + cos(a) * rInst; val y = cy + sin(a) * rInst
            if (i == 0) shapePath.moveTo(x, y) else shapePath.lineTo(x, y)
        }
        shapePath.close(); c.drawPath(shapePath, pFill)
    }

    // Elite: hexagon + small crown on top
    private fun drawEliteCrown(c: Canvas, e: Enemy) {
        val goldCol = pFill.color
        pStroke.color = Color.parseColor("#FFD700"); pStroke.strokeWidth = 2f
        c.drawCircle(e.x, e.y, e.radius + 6f, pStroke)
    }

    // Boss: large layered shape with phase details
    private fun drawBossShape(c: Canvas, e: Enemy) {
        // Outer ring
        pFill.color = Color.argb(80, 180, 0, 0)
        c.drawCircle(e.x, e.y, e.radius + 12f, pFill)
        // Main body — hexagon
        pFill.color = when {
            e.flashTimer > 0f -> Color.WHITE
            e.bossPhase == 3  -> Color.parseColor("#FF4400")
            e.bossPhase == 2  -> Color.parseColor("#CC2200")
            else              -> C_BOSS
        }
        drawHexagon(c, e.x, e.y, e.radius)
        // Inner core circle
        pFill.color = Color.parseColor("#440000")
        c.drawCircle(e.x, e.y, e.radius * 0.45f, pFill)
        // Phase ring lines
        pStroke.color = Color.parseColor("#FF4444"); pStroke.strokeWidth = 2f
        c.drawCircle(e.x, e.y, e.radius * 0.72f, pStroke)
    }

    // ═══════════════════════════════════════════════════════════════
    //  Touch input
    // ═══════════════════════════════════════════════════════════════

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        val action  = ev.actionMasked
        val idx     = ev.actionIndex
        val pid     = ev.getPointerId(idx)
        val tx      = ev.getX(idx)
        val ty      = ev.getY(idx)
        val s       = state ?: return true

        when (action) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                when (s.phase) {
                    Phase.DEAD -> handleDeadTap(s, tx, ty)
                    Phase.LEVEL_UP -> {
                        s.pendingUpgrades.forEachIndexed { i, up ->
                            val cy = cardStartY + i * cardSpacing
                            if (tx >= cardX && tx <= cardX + cardW && ty >= cy && ty <= cy + cardH) {
                                GameLogic.applyUpgrade(s, up)
                            }
                        }
                    }
                    Phase.PAUSED -> {
                        if (resumeRect.contains(tx, ty)) s.phase = Phase.PLAYING
                        if (quitRect.contains(tx, ty)) {
                            saveMeta(s)
                            GameLogic.reset(s, meta)
                        }
                    }
                    Phase.PLAYING -> {
                        // Pause button
                        if (pauseRect.contains(tx, ty)) { s.phase = Phase.PAUSED; return true }
                        // Ability buttons
                        var handled = false
                        for (i in 0..5) {
                            if (abilityRects[i].contains(tx, ty)) {
                                pendingAbility = abilityOrder[i]; handled = true; break
                            }
                        }
                        // Joystick (if not on ability buttons)
                        if (!handled && !jActive) {
                            jPointer = pid; jBase.set(tx, ty); jKnob.set(tx, ty)
                            jActive = true; moveX = 0f; moveY = 0f
                        }
                    }
                }
            }

            MotionEvent.ACTION_MOVE -> {
                if (s.phase == Phase.PLAYING && jActive) {
                    val ji = ev.findPointerIndex(jPointer)
                    if (ji >= 0) {
                        val jx = ev.getX(ji); val jy = ev.getY(ji)
                        val dx = jx - jBase.x; val dy = jy - jBase.y
                        val d  = sqrt(dx * dx + dy * dy)
                        val cl = d.coerceAtMost(jRadius)
                        val nx = if (d > 0f) dx / d else 0f
                        val ny = if (d > 0f) dy / d else 0f
                        jKnob.set(jBase.x + nx * cl, jBase.y + ny * cl)
                        moveX = cl / jRadius * nx
                        moveY = cl / jRadius * ny
                    }
                }
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                if (pid == jPointer) { jActive = false; jPointer = -1; moveX = 0f; moveY = 0f }
            }
        }
        return true
    }

    private fun handleDeadTap(s: GameState, tx: Float, ty: Float) {
        for (i in 0..4) {
            if (!metaBuyRects[i].contains(tx, ty)) continue
            when (i) {
                0 -> { val cost = meta.costHp();    if (canAfford(s, cost)) { meta.hpLevel++;    meta.currency -= cost - s.runCurrency; s.runCurrency = 0; meta.currency = maxOf(meta.currency, 0) } }
                1 -> { val cost = meta.costSpeed(); if (canAfford(s, cost)) { meta.speedLevel++; spendMeta(s, cost) } }
                2 -> { val cost = meta.costCdr();   if (canAfford(s, cost)) { meta.cdrLevel++;   spendMeta(s, cost) } }
                3 -> { val cost = meta.costXp();    if (canAfford(s, cost)) { meta.xpLevel++;    spendMeta(s, cost) } }
                4 -> { saveMeta(s); GameLogic.reset(s, meta) }
            }
            break
        }
    }

    private fun totalCoins(s: GameState) = meta.currency + s.runCurrency
    private fun canAfford(s: GameState, cost: Int) = totalCoins(s) >= cost
    private fun spendMeta(s: GameState, cost: Int) {
        val total = totalCoins(s)
        val newTotal = total - cost
        // Drain runCurrency first, then meta.currency
        if (s.runCurrency >= cost) {
            s.runCurrency -= cost
        } else {
            val fromMeta = cost - s.runCurrency
            s.runCurrency = 0; meta.currency -= fromMeta
        }
        meta.currency = maxOf(meta.currency, 0)
    }

    // ── SharedPreferences (meta persistence) ─────────────────────

    private fun loadMeta() {
        val p = prefs
        meta.currency    = p.getInt("currency",    0)
        meta.hpLevel     = p.getInt("hpLevel",     0)
        meta.speedLevel  = p.getInt("speedLevel",  0)
        meta.cdrLevel    = p.getInt("cdrLevel",    0)
        meta.xpLevel     = p.getInt("xpLevel",     0)
        val abStr        = p.getString("startAbility", null)
        meta.startAbility = abStr?.let { runCatching { AbilityId.valueOf(it) }.getOrNull() }
    }

    private fun saveMeta(s: GameState) {
        meta.currency += s.runCurrency; s.runCurrency = 0
        meta.currency = maxOf(meta.currency, 0)
        prefs.edit()
            .putInt("currency",    meta.currency)
            .putInt("hpLevel",     meta.hpLevel)
            .putInt("speedLevel",  meta.speedLevel)
            .putInt("cdrLevel",    meta.cdrLevel)
            .putInt("xpLevel",     meta.xpLevel)
            .putString("startAbility", meta.startAbility?.name)
            .apply()
    }
}
