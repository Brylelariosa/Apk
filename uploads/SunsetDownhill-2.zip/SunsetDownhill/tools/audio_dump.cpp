// audio_dump: renders a scripted session of the procedural audio to /tmp/audio_test.wav and prints levels.
// Build: g++ -std=c++17 -O2 -I../app/src/main/cpp/core audio_dump.cpp ../app/src/main/cpp/core/audio_synth.cpp
#include "audio_synth.h"
#include <cstdio>
#include <cmath>
#include <vector>
using namespace sd;
int main(){
  AudioSynth a; std::vector<int16_t> all; const int N=1024; std::vector<int16_t> buf(N);
  auto run=[&](float seconds, AudioState s, const char* label){
    a.setState(s); double sum=0; int peak=0; long cnt=0;
    for(int i=0;i<(int)(seconds*AudioSynth::kSampleRate/N);++i){ a.render(buf.data(),N); for(int v: buf){ sum+= (double)v*v; peak=std::max(peak, std::abs((int)v)); ++cnt; all.push_back(v);} }
    printf("%-30s rms=%6.0f (%6.1f dBFS)  peak=%5d (%6.1f dBFS)\n", label, std::sqrt(sum/cnt), 20*std::log10(std::sqrt(sum/cnt)/32768.0+1e-9), peak, 20*std::log10(peak/32768.0+1e-9));
  };
  AudioState s; s.master=1;
  s.speed=0; run(0.5f,s,"idle");
  a.trigger(AudioEvent::Tick); run(0.4f,s,"countdown tick");
  a.trigger(AudioEvent::Go); run(0.8f,s,"go");
  // standing start: four kicks, then the foot goes back on the deck
  for(int k=0;k<4;++k){ s.speed=1.5f+2.0f*k; a.trigger(AudioEvent::Push); run(0.56f,s,k==0?"kick-push #1 (1.5 m/s)":(k==3?"kick-push #4 (7.5 m/s)":"kick-push")); }
  a.trigger(AudioEvent::FootOn); run(0.4f,s,"foot back on deck");
  s.speed=8; run(2.0f,s,"8 m/s (29 km/h)");
  s.speed=20; run(2.0f,s,"20 m/s (72 km/h)");
  s.speed=33; s.tuck=1; run(2.0f,s,"33 m/s tucked (119 km/h)");
  s.tuck=0; s.speed=12; s.slide=1; run(1.5f,s,"Coleman slide at 12 m/s");
  s.speed=33; run(1.5f,s,"Coleman slide at 33 m/s");
  s.slide=0; run(1.0f,s,"after the slide (33 m/s)");
  s.offroad=1; run(1.5f,s,"offroad gravel");
  s.offroad=0; a.trigger(AudioEvent::Scrape); run(0.5f,s,"rail scrape");
  a.trigger(AudioEvent::NearMiss); run(0.6f,s,"near miss");
  a.trigger(AudioEvent::ConeHit); run(0.4f,s,"cone hit");
  a.trigger(AudioEvent::Crash); run(1.8f,s,"crash");
  s.speed=0; a.trigger(AudioEvent::NewBest); run(1.2f,s,"new best jingle");
  s.master=0; run(0.5f,s,"muted");
  printf("samples=%zu\n", all.size());
  FILE* f=fopen("/tmp/audio_test.wav","wb"); int dataBytes=(int)all.size()*2; int rate=AudioSynth::kSampleRate;
  fwrite("RIFF",1,4,f); int v32=36+dataBytes; fwrite(&v32,4,1,f); fwrite("WAVEfmt ",1,8,f); v32=16; fwrite(&v32,4,1,f); short s16=1; fwrite(&s16,2,1,f); fwrite(&s16,2,1,f); fwrite(&rate,4,1,f); v32=rate*2; fwrite(&v32,4,1,f); s16=2; fwrite(&s16,2,1,f); s16=16; fwrite(&s16,2,1,f); fwrite("data",1,4,f); fwrite(&dataBytes,4,1,f); fwrite(all.data(),2,all.size(),f); fclose(f);
}
