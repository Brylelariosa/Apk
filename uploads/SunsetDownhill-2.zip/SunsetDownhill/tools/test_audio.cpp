// test_audio: guards against the "flapping / gear change" sound.
//
// An earlier version of the synth modulated the wheel noise once per wheel turn (and the slide chatter with a steady
// 30-60 Hz oscillator). Played at a constant speed that is a clear tone in the *loudness* of the sound, and since
// its pitch follows the speed it sounds like a flapping card when slow and like an engine changing gear when the
// speed changes. This test renders constant-speed rolling and sliding, takes the loudness envelope of the audible
// band and checks that no single modulation frequency stands out of the noise floor.
//
// Build: g++ -std=c++17 -O2 -I../app/src/main/cpp/core test_audio.cpp ../app/src/main/cpp/core/audio_synth.cpp
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <vector>

#include "audio_synth.h"

using namespace sd;

namespace {

constexpr double kPi = 3.14159265358979323846;
constexpr double kFs = AudioSynth::kSampleRate;

struct Biquad {   // RBJ cookbook, Butterworth Q
    double b0 = 1, b1 = 0, b2 = 0, a1 = 0, a2 = 0, x1 = 0, x2 = 0, y1 = 0, y2 = 0;
    static Biquad make(bool highPass, double fc) {
        const double w = 2 * kPi * fc / kFs, c = std::cos(w), a = std::sin(w) / (2 * 0.70710678);
        const double a0 = 1 + a;
        Biquad q;
        q.b0 = (highPass ? (1 + c) / 2 : (1 - c) / 2) / a0;
        q.b1 = (highPass ? -(1 + c) : (1 - c)) / a0;
        q.b2 = q.b0;
        q.a1 = -2 * c / a0;
        q.a2 = (1 - a) / a0;
        return q;
    }
    double run(double x) {
        const double y = b0 * x + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2;
        x2 = x1; x1 = x; y2 = y1; y1 = y;
        return y;
    }
};

std::vector<int16_t> render(float speed, float slide, float seconds) {
    AudioSynth a;
    AudioState s;
    s.master = 1.0f;
    s.speed = speed;
    s.slide = slide;
    a.setState(s);
    std::vector<int16_t> buf(512), out;
    for (int i = 0; i < static_cast<int>(seconds * kFs / 512); ++i) {
        a.render(buf.data(), 512);
        out.insert(out.end(), buf.begin(), buf.end());
    }
    return out;
}

// How far (dB) the strongest loudness-modulation frequency between 10 and 250 Hz stands out of its neighbourhood.
double modulationProminenceDb(const std::vector<int16_t>& pcm, double* peakHz) {
    Biquad hp1 = Biquad::make(true, 400), hp2 = hp1, lp1 = Biquad::make(false, 4000), lp2 = lp1, env1 = Biquad::make(false, 300);
    const int skip = static_cast<int>(1.5 * kFs), decim = 8;
    std::vector<double> env;
    for (size_t i = 0; i < pcm.size(); ++i) {
        double x = pcm[i] / 32768.0;
        x = lp2.run(lp1.run(hp2.run(hp1.run(x))));
        const double e = env1.run(std::fabs(x));
        if (static_cast<int>(i) >= skip && (i % decim) == 0) env.push_back(e);
    }
    const double fs = kFs / decim;
    double mean = 0;
    for (double v : env) mean += v;
    mean /= env.size();
    const size_t n = env.size();
    std::vector<double> w(n);
    for (size_t i = 0; i < n; ++i) w[i] = (env[i] - mean) * (0.5 - 0.5 * std::cos(2 * kPi * i / (n - 1)));
    std::vector<double> amp;   // 10..250 Hz in 1 Hz steps (Goertzel)
    for (int f = 10; f <= 250; ++f) {
        const double c = 2 * std::cos(2 * kPi * f / fs);
        double s1 = 0, s2 = 0;
        for (size_t i = 0; i < n; ++i) { const double s0 = w[i] + c * s1 - s2; s2 = s1; s1 = s0; }
        amp.push_back(std::sqrt(s1 * s1 + s2 * s2 - c * s1 * s2));
    }
    size_t k = 0;
    for (size_t i = 0; i < amp.size(); ++i) if (amp[i] > amp[k]) k = i;
    std::vector<double> around;
    for (size_t i = 0; i < amp.size(); ++i) {
        const int d = std::abs(static_cast<int>(i) - static_cast<int>(k));
        if (d > 3 && d <= 25) around.push_back(amp[i]);
    }
    std::nth_element(around.begin(), around.begin() + around.size() / 2, around.end());
    if (peakHz) *peakHz = 10.0 + static_cast<double>(k);
    return 20 * std::log10(amp[k] / around[around.size() / 2]);
}

}  // namespace

int main() {
    // Pure noise gives ~9-10 dB here (the maximum of ~240 random bins over their median). The old synth's wheel
    // flutter / slide chatter stood out by 21-24 dB. Anything above this limit is a tone that follows the speed.
    constexpr double kLimitDb = 15.0;
    int failed = 0;
    std::printf("%-22s %10s %12s %8s\n", "sound", "peak (Hz)", "prominence", "");
    auto check = [&](const char* name, float speed, float slide) {
        double hz = 0;
        const double db = modulationProminenceDb(render(speed, slide, 8.0f), &hz);
        const bool ok = db < kLimitDb;
        failed += ok ? 0 : 1;
        std::printf("%-22s %10.0f %9.1f dB %8s\n", name, hz, db, ok ? "ok" : "TONAL!");
    };
    check("rolling  3 m/s", 3, 0);
    check("rolling  6 m/s", 6, 0);
    check("rolling 10 m/s", 10, 0);
    check("rolling 15 m/s", 15, 0);
    check("rolling 20 m/s", 20, 0);
    check("rolling 30 m/s", 30, 0);
    check("sliding 10 m/s", 10, 1);
    check("sliding 20 m/s", 20, 1);
    check("sliding 30 m/s", 30, 1);
    std::printf("%s\n", failed == 0 ? "no tone follows the speed" : "a tone follows the speed: it will sound like an engine / flapping");
    return failed == 0 ? 0 : 1;
}
