# Desktop tools

These are optional developer tools for the platform independent engine in
`app/src/main/cpp/core`. They are **not** part of the Android build.

```bash
cmake -S tools -B build-tools && cmake --build build-tools -j
./build-tools/sim_physics        # speed / crash balance of the skater physics
./build-tools/sim_game           # autopilot plays full runs with obstacles and traffic
./build-tools/audio_dump         # synthesises a test session to /tmp/audio_test.wav
./build-tools/test_controls      # control schemes, button layout editor, tilt maths, HUD fit on every aspect ratio
./build-tools/test_audio         # no engine-like tone may follow the wheel speed (guards the "flapping / gear change" bug)
./build-tools/dump_ui /tmp/ui    # the HUD and the CONTROLS screen in every steering mode as PPM images (no GPU needed)
ctest --test-dir build-tools     # runs test_controls + test_audio
# needs Mesa EGL/GLES (apt install libegl-dev libgles-dev libgl1-mesa-dri):
LIBGL_ALWAYS_SOFTWARE=1 ./build-tools/render_session 1600 720 /tmp/shots 3
```

`render_session` runs the real engine on a software GLES 3 context and writes PPM screenshots
(`python3 -c "from PIL import Image; Image.open('a_menu.ppm').save('a_menu.png')"` converts them).
All gameplay constants live in `core/config.h`.

`test_controls`, `test_audio` and `dump_ui` need neither a GPU nor a phone: the control code (`controls*.cpp`, `tilt.cpp`,
`input.cpp`, `hud.cpp`) is platform independent and free of OpenGL on purpose.
