// dump_ui: renders the HUD, the control schemes and the CONTROLS screen to PPM images with a tiny software
// rasteriser, so the UI can be reviewed without a phone or a GPU. The background is just a sunset gradient.
//   ./dump_ui <out_dir>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <functional>
#include <string>
#include <vector>

#include "controls.h"
#include "hud.h"
#include "ui_batch.h"

using namespace sd;

namespace {

struct Image {
    int w, h;
    std::vector<float> rgb;   // 0..255
    Image(int w_, int h_) : w(w_), h(h_), rgb(static_cast<size_t>(w_) * h_ * 3) {
        for (int y = 0; y < h; ++y) {
            const float t = static_cast<float>(y) / static_cast<float>(h);
            float r, g, b;
            if (t < 0.55f) { const float k = t / 0.55f; r = 40 + 215 * k; g = 20 + 110 * k; b = 90 - 10 * k; }   // sky: purple -> orange
            else { const float k = (t - 0.55f) / 0.45f; r = 70 - 40 * k; g = 40 - 25 * k; b = 60 - 30 * k; }     // road
            for (int x = 0; x < w; ++x) { float* p = &rgb[(static_cast<size_t>(y) * w + x) * 3]; p[0] = r; p[1] = g; p[2] = b; }
        }
    }
};

// Alpha-blended triangle fill with 2x2 supersampling and per-vertex colours.
void fillTriangle(Image& img, const UiVertex& a, const UiVertex& b, const UiVertex& c) {
    const float minX = std::floor(std::min({a.x, b.x, c.x})), maxX = std::ceil(std::max({a.x, b.x, c.x}));
    const float minY = std::floor(std::min({a.y, b.y, c.y})), maxY = std::ceil(std::max({a.y, b.y, c.y}));
    const float det = (b.y - c.y) * (a.x - c.x) + (c.x - b.x) * (a.y - c.y);
    if (std::fabs(det) < 1e-9f) return;
    for (int y = std::max(0, static_cast<int>(minY)); y < std::min(img.h, static_cast<int>(maxY) + 1); ++y) {
        for (int x = std::max(0, static_cast<int>(minX)); x < std::min(img.w, static_cast<int>(maxX) + 1); ++x) {
            float cov = 0, cr = 0, cg = 0, cb = 0, ca = 0;
            for (int sy = 0; sy < 2; ++sy) {
                for (int sx = 0; sx < 2; ++sx) {
                    const float px = x + 0.25f + 0.5f * sx, py = y + 0.25f + 0.5f * sy;
                    const float l1 = ((b.y - c.y) * (px - c.x) + (c.x - b.x) * (py - c.y)) / det;
                    const float l2 = ((c.y - a.y) * (px - c.x) + (a.x - c.x) * (py - c.y)) / det;
                    const float l3 = 1.0f - l1 - l2;
                    if (l1 < 0 || l2 < 0 || l3 < 0) continue;
                    cov += 0.25f;
                    cr += 0.25f * (l1 * a.r + l2 * b.r + l3 * c.r);
                    cg += 0.25f * (l1 * a.g + l2 * b.g + l3 * c.g);
                    cb += 0.25f * (l1 * a.b + l2 * b.b + l3 * c.b);
                    ca += 0.25f * (l1 * a.a + l2 * b.a + l3 * c.a);
                }
            }
            if (cov <= 0) continue;
            const float al = (ca / cov) / 255.0f * cov;
            float* p = &img.rgb[(static_cast<size_t>(y) * img.w + x) * 3];
            p[0] = p[0] * (1 - al) + (cr / cov) * al;
            p[1] = p[1] * (1 - al) + (cg / cov) * al;
            p[2] = p[2] * (1 - al) + (cb / cov) * al;
        }
    }
}

void savePPM(const Image& img, const std::string& path) {
    FILE* f = std::fopen(path.c_str(), "wb");
    if (!f) { std::perror(path.c_str()); std::exit(1); }
    std::fprintf(f, "P6\n%d %d\n255\n", img.w, img.h);
    for (float v : img.rgb) std::fputc(static_cast<int>(std::lround(std::min(255.0f, std::max(0.0f, v)))), f);
    std::fclose(f);
}

void render(const std::string& dir, const std::string& name, int w, int h, const std::function<void(UiBatch&, Controls&)>& draw,
            const std::function<void(Controls&)>& setup) {
    Controls c;
    c.setScreen(static_cast<float>(w), static_cast<float>(h));
    c.setTiltAvailable(true);
    setup(c);
    UiBatch ui;
    ui.setScreen(static_cast<float>(w), static_cast<float>(h));
    draw(ui, c);
    Image img(w, h);
    for (size_t i = 0; i + 2 < ui.vertexCount(); i += 3) fillTriangle(img, ui.data()[i], ui.data()[i + 1], ui.data()[i + 2]);
    savePPM(img, dir + "/" + name + ".ppm");
    std::printf("wrote %s (%dx%d, %zu vertices)\n", name.c_str(), w, h, ui.vertexCount());
}

HudModel model(const Controls& c, Phase phase) {
    HudModel m;
    m.phase = phase;
    m.phaseTime = 2.0f;
    m.time = 1.3f;
    m.speedKmh = 87;
    m.distanceM = 1840;
    m.score = 5320;
    m.best = 9800;
    m.topSpeedKmh = 96;
    m.nearMisses = 7;
    m.countdown = 2;
    m.countdownProgress = 0.4f;
    m.mode = c.mode();
    m.opacity = c.opacity();
    m.tilt = c.tiltSteer();
    return m;
}

ControlsConfig mode(SteerMode m) {
    ControlsConfig cfg;
    cfg.mode = m;
    return cfg;
}

void press(Controls& c, Vec2 p) { c.onTouch(kTouchDown, 1, p.x, p.y); c.onTouch(kTouchUp, 1, p.x, p.y); }
Vec2 widget(const Controls& c, ControlsEditor::Widget w) {
    Rect r;
    ControlsEditor::widgetRect(w, c.layout(), c.mode(), &r);
    return {r.x + r.w * 0.5f, r.y + r.h * 0.5f};
}

}  // namespace

int main(int argc, char** argv) {
    const std::string dir = argc > 1 ? argv[1] : ".";
    const int W = 1920, H = 1080;
    using W_ = ControlsEditor::Widget;

    // ---- in the game
    render(dir, "menu_stick", W, H, [](UiBatch& ui, Controls& c) { drawHud(ui, c.layout(), model(c, Phase::Menu)); }, [](Controls&) {});
    render(dir, "running_stick", W, H, [](UiBatch& ui, Controls& c) {
        HudModel m = model(c, Phase::Running);
        m.steerActive = true; m.stickOrigin = {330, 700}; m.stickKnob = {420, 700}; m.tuckDown = true;
        drawHud(ui, c.layout(), m);
    }, [](Controls&) {});
    render(dir, "running_arrows", W, H, [](UiBatch& ui, Controls& c) {
        HudModel m = model(c, Phase::Running);
        m.rightDown = true;
        drawHud(ui, c.layout(), m);
    }, [](Controls& c) { c.setConfig(mode(SteerMode::Arrows)); });
    render(dir, "running_tilt", W, H, [](UiBatch& ui, Controls& c) {
        HudModel m = model(c, Phase::Running);
        m.tilt = 0.55f; m.slideDown = true;
        drawHud(ui, c.layout(), m);
    }, [](Controls& c) { c.setConfig(mode(SteerMode::Tilt)); });
    render(dir, "running_both_faded", W, H, [](UiBatch& ui, Controls& c) {
        HudModel m = model(c, Phase::Running);
        m.tilt = -0.35f; m.leftDown = true;
        drawHud(ui, c.layout(), m);
    }, [](Controls& c) { ControlsConfig cfg = mode(SteerMode::ArrowsTilt); cfg.opacity = 0.5f; c.setConfig(cfg); });
    render(dir, "paused", W, H, [](UiBatch& ui, Controls& c) { drawHud(ui, c.layout(), model(c, Phase::Paused)); }, [](Controls&) {});
    render(dir, "menu_tilt", W, H, [](UiBatch& ui, Controls& c) { drawHud(ui, c.layout(), model(c, Phase::Menu)); }, [](Controls& c) { c.setConfig(mode(SteerMode::ArrowsTilt)); });

    // ---- the CONTROLS screen
    render(dir, "editor_stick", W, H, [](UiBatch&ui, Controls& c) { c.drawEditor(ui); }, [](Controls& c) { c.openEditor(); });
    render(dir, "editor_arrows", W, H, [](UiBatch& ui, Controls& c) { c.drawEditor(ui); }, [](Controls& c) {
        c.setConfig(mode(SteerMode::Arrows)); c.openEditor();
        press(c, c.layout().center(ButtonId::Left));                // select the left arrow ...
        press(c, widget(c, W_::SizeUp)); press(c, widget(c, W_::SizeUp));   // ... and make it a bit bigger
        press(c, widget(c, W_::OpacityDown));
    });
    render(dir, "editor_tilt", W, H, [](UiBatch& ui, Controls& c) { c.drawEditor(ui); }, [](Controls& c) {
        c.setConfig(mode(SteerMode::Tilt)); c.openEditor();
        c.setTiltGravity(-9.81f * std::sin(10 * kDeg2Rad), 9.81f * std::cos(10 * kDeg2Rad));
        for (int i = 0; i < 90; ++i) c.update(1.0f / 60.0f, false, false);
        press(c, c.layout().center(ButtonId::Slide));
    });
    render(dir, "editor_both_dragging", W, H, [](UiBatch& ui, Controls& c) { c.drawEditor(ui); }, [](Controls& c) {
        c.setConfig(mode(SteerMode::ArrowsTilt)); c.openEditor();
        const Vec2 t = c.layout().center(ButtonId::Tuck);
        c.onTouch(kTouchDown, 1, t.x, t.y);
        c.onTouch(kTouchMove, 1, 1500, 560);                       // mid-drag, finger still down
    });
    // narrow / wide / small screens
    render(dir, "editor_arrows_4x3", 1440, 1080, [](UiBatch& ui, Controls& c) { c.drawEditor(ui); }, [](Controls& c) { c.setConfig(mode(SteerMode::ArrowsTilt)); c.openEditor(); });
    render(dir, "editor_tilt_20x9", 2400, 1080, [](UiBatch& ui, Controls& c) { c.drawEditor(ui); }, [](Controls& c) { c.setConfig(mode(SteerMode::Tilt)); c.openEditor(); });
    render(dir, "running_arrows_4x3", 1440, 1080, [](UiBatch& ui, Controls& c) { drawHud(ui, c.layout(), model(c, Phase::Running)); }, [](Controls& c) { c.setConfig(mode(SteerMode::Arrows)); });
    return 0;
}
