// render_session: drives the real Engine headlessly (software GLES 3 via Mesa EGL, surfaceless) with simulated
// touch input and writes PPM screenshots of the menu, countdown, HUD, pause, crash and results screens.
// Usage: render_session [width height outDir tier]
// Drives the real Engine like the Android shell does: touch events in, frames out (headless Mesa GLES 3).
#include <EGL/egl.h>
#include <EGL/eglext.h>
#include <GLES3/gl3.h>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include "audio_synth.h"
#include "engine.h"
using namespace sd;

static void savePPM(const char* path, int w, int h) {
    std::vector<unsigned char> px(static_cast<size_t>(w) * h * 4), out(static_cast<size_t>(w) * h * 3);
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    glReadPixels(0, 0, w, h, GL_RGBA, GL_UNSIGNED_BYTE, px.data());
    for (int y = 0; y < h; ++y) for (int x = 0; x < w; ++x) { const unsigned char* s = &px[((h - 1 - y) * w + x) * 4]; unsigned char* d = &out[(y * w + x) * 3]; d[0]=s[0]; d[1]=s[1]; d[2]=s[2]; }
    FILE* f = std::fopen(path, "wb"); std::fprintf(f, "P6\n%d %d\n255\n", w, h); std::fwrite(out.data(), 1, out.size(), f); std::fclose(f);
}

int main(int argc, char** argv) {
    const int W = argc > 1 ? std::atoi(argv[1]) : 1600;
    const int H = argc > 2 ? std::atoi(argv[2]) : 720;
    const char* outDir = argc > 3 ? argv[3] : "/tmp/ui";
    const int tier = argc > 4 ? std::atoi(argv[4]) : 3;

    auto getPD = (PFNEGLGETPLATFORMDISPLAYEXTPROC)eglGetProcAddress("eglGetPlatformDisplayEXT");
    EGLDisplay dpy = getPD(EGL_PLATFORM_SURFACELESS_MESA, EGL_DEFAULT_DISPLAY, nullptr);
    EGLint maj, min; eglInitialize(dpy, &maj, &min); eglBindAPI(EGL_OPENGL_ES_API);
    const EGLint ca[] = {EGL_SURFACE_TYPE, EGL_PBUFFER_BIT, EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT, EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8, EGL_ALPHA_SIZE, 8, EGL_DEPTH_SIZE, 24, EGL_NONE};
    EGLConfig cfg; EGLint n; eglChooseConfig(dpy, ca, &cfg, 1, &n);
    const EGLint pa[] = {EGL_WIDTH, W, EGL_HEIGHT, H, EGL_NONE};
    EGLSurface surf = eglCreatePbufferSurface(dpy, cfg, pa);
    const EGLint xa[] = {EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE};
    EGLContext ctx = eglCreateContext(dpy, cfg, EGL_NO_CONTEXT, xa);
    eglMakeCurrent(dpy, surf, surf, ctx);

    Engine eng;
    eng.setSettings(4321, true);
    eng.renderer().setQualityTier(tier);
    eng.game().setBaseSeed(777);
    eng.onSurfaceCreated();
    eng.onSurfaceChanged(W, H);
    if (!eng.renderer().ready()) { std::fprintf(stderr, "renderer not ready\n"); return 2; }

    const float dt = 1.0f / 60.0f;
    std::vector<int16_t> abuf(1024);
    auto step = [&](int frames) { for (int i = 0; i < frames; ++i) { eng.stepFrame(dt); audioSynth().render(abuf.data(), 367); } };
    auto shot = [&](const char* name) {
        char path[256]; std::snprintf(path, sizeof(path), "%s/%s.ppm", outDir, name);
        savePPM(path, W, H);
        std::fprintf(stderr, "wrote %-14s phase=%d speed=%5.1f km/h dist=%6.0f score=%d\n", name, (int)eng.game().phase(), eng.game().speedKmh(), eng.game().distanceM(), eng.game().score());
    };
    auto tapAt = [&](float x, float y) { eng.onTouch(kTouchDown, 100, x, y); step(2); eng.onTouch(kTouchUp, 100, x, y); step(1); };

    step(100); shot("a_menu");
    tapAt(W * 0.5f, H * 0.5f);                       // tap to start
    step(40); shot("b_countdown");
    step(120);                                       // through GO!
    shot("c_go");
    // steering with the left thumb, tuck held with the right
    const UiLayout L = eng.controls().layout();
    const Vec2 tuckC = L.center(ButtonId::Tuck), slideC = L.center(ButtonId::Slide);
    eng.onTouch(kTouchDown, 1, L.w * 0.18f, L.h * 0.72f);
    eng.onTouch(kTouchDown, 2, tuckC.x, tuckC.y);
    for (int i = 0; i < 60 * 6; ++i) {
        const float sx = L.w * 0.18f + std::sin(i * 0.05f) * 70.0f * L.u;
        eng.onTouch(kTouchMove, 1, sx, L.h * 0.72f);
        eng.stepFrame(dt); audioSynth().render(abuf.data(), 367);
    }
    shot("d_running_tuck");
    eng.onTouch(kTouchUp, 2, tuckC.x, tuckC.y);
    eng.onTouch(kTouchDown, 3, slideC.x, slideC.y);
    for (int i = 0; i < 40; ++i) { eng.onTouch(kTouchMove, 1, L.w * 0.18f + 90.0f * L.u, L.h * 0.72f); eng.stepFrame(dt); audioSynth().render(abuf.data(), 367); }
    shot("e_running_slide");
    eng.onTouch(kTouchUp, 3, slideC.x, slideC.y);
    // pause via the Activity lifecycle path
    eng.requestPause(); step(3); shot("f_paused");
    tapAt(W * 0.5f, H * 0.4f);                       // resume
    step(10);
    // hold full steer until the rider wipes out
    int guard = 0;
    while (eng.game().phase() == Phase::Running && guard++ < 60 * 90) { eng.onTouch(kTouchMove, 1, L.w * 0.18f + 200.0f * L.u, L.h * 0.72f); eng.stepFrame(dt); }
    step(30); shot("g_crash");
    step(190); shot("h_gameover");
    step(60);
    tapAt(L.menuX + L.menuW * 0.5f, L.menuY + L.menuH * 0.5f);   // MENU button
    step(5); shot("i_back_in_menu");
    // back button semantics
    bool consumedInMenu = eng.requestBack();
    tapAt(W * 0.5f, H * 0.5f); step(60);
    bool consumedInRun = eng.requestBack(); step(2);
    std::fprintf(stderr, "back in menu consumed=%d (expect 0), back during countdown consumed=%d (expect 1), phase now=%d (expect Paused=5), best=%d\n", consumedInMenu, consumedInRun, (int)eng.game().phase(), eng.bestScore());
    std::fprintf(stderr, "frames OK\n");
    return 0;
}
