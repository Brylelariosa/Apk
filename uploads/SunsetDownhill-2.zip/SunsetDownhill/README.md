# Sunset Downhill

A 3D downhill longboard game for Android. Carve a winding mountain road at golden hour, tuck for speed,
slide into the corners, and dodge cones, boulders and traffic as the sun sinks toward dusk.

Native C++ (OpenGL ES 3.0) engine with a very thin Kotlin shell. No assets: the world, the rider,
the HUD font and all audio are generated procedurally.

## Build the APK with your GitHub Action

1. Put `SunsetDownhill.zip` in the `uploads/` folder of your repository and push.
2. The *Build APK* workflow unzips it, finds `settings.gradle`, builds, and uploads
   `SunsetDownhill-debug-v<run>` (or `-release-` when the keystore secrets exist) as a workflow artifact.

The project is pinned to what that workflow provisions: Gradle 8.6, JDK 17, NDK 25.2.9519653,
CMake 3.22.1, AGP 8.2.2, Kotlin 1.9.22, `compileSdk`/`targetSdk` 34, `minSdk` 24 (needs OpenGL ES 3.0).
ABIs: `arm64-v8a`, `armeabi-v7a`, `x86_64`.

## Controls (landscape)

Choose how you steer in **CONTROLS** (a button on the main menu and on the pause screen). The choice and your
button layout are saved.

| Steering | How it works |
|---|---|
| **Stick** (default) | Drag on the **left half** of the screen. The first touch becomes the neutral point (floating stick). |
| **Arrows** | Two arrow buttons (bottom left). A tap nudges, holding turns harder; letting go straightens out. |
| **Tilt** | Turn the phone like a steering wheel. The straight-ahead position is taken from how you hold the phone during the 3-2-1 countdown (press **RECENTER** in CONTROLS to redo it); **TILT SENS** sets how far you must lean for full lock. A small gauge at the bottom shows what the tilt is doing. |
| **Arrows + Tilt** | Both at once. |

Tilt needs a gravity or accelerometer sensor; without one the tilt options are greyed out and the arrows are used.

These are the same in every scheme:

| Control | Action |
|---|---|
| Hold **TUCK** (bottom right) | Crouch: much less drag, higher top speed, but less grip. |
| Hold **SLIDE** (bottom right) | **Coleman slide**: the board kicks out sideways, the rider drops into a deep crouch with a hand on the road. Scrubs speed, more turning authority, tyre smoke + sparks. |
| **SLIDE + steer** left / right | Throws the slide out to that side, and further out the harder you steer. SLIDE alone slides to the side you last steered. |
| Pause button / Back | Pause; Back again returns to the menu. (With CONTROLS open, Back closes it first.) |

### Customising the buttons

In **CONTROLS**: drag any button to move it; the ringed one is selected, and **SIZE - / +** resizes it (60-160 %,
hold to repeat). **OPACITY** makes all buttons more see-through, **RESET** brings back the factory layout (keeping
your steering choice). Buttons stay on screen and below the HUD band, are kept from overlapping each other and from covering
the pause button. Changes are saved when you lift your finger.

Every run starts with a **kick-push**: the rider waits with a foot planted on the road, then kicks off four times
before settling onto the board. After two kicks, TUCK or SLIDE cuts the push short.

Tips: tuck on straights, brake **before** a corner, and use the Coleman slide to rotate through it.
Rubbing the guard rail scrapes speed off; grinding it for more than a second wipes you out.
Close calls and long Coleman slides score bonus points on top of distance.

## Architecture

```
app/src/main/java/.../game/      Kotlin shell (5 small files)
    GameActivity                 immersive landscape window, lifecycle, persistence of best score / sound / controls
    GameSurfaceView              GLSurfaceView (ES 3.0) + multi-touch forwarding
    AudioEngine                  AudioTrack feeder thread
    TiltSensor                   gravity sensor -> screen axes (all tilt maths is native)
    NativeBridge                 the entire JNI surface
app/src/main/cpp/
    jni_bridge.cpp               JNI <-> Engine
    core/                        platform independent engine (flat folder, namespace sd)
        math3d.h rng.h color.h config.h log.h      foundations; config.h holds every tunable
        track.*      procedural road: curvature/pitch/banking, terrain profile
        world.*      obstacles + traffic, chunked scenery, terrain mesh window
        skater.*     physics in road space (grip limit, tuck, slide, rail scrape, stall bail-out)
        autopilot.*  menu demo driver and test bot
        game.*       state machine (menu/countdown/run/crash/results/pause), scoring, effects
        camera.* atmosphere.* particles.* skater_model.* mesh_data.* mesh_library.*
        scene_builder.*   game state -> renderer input (the only bridge between the two halves)
        renderer.* gl_util.* shaders.*   GLES3: sun shadow map, scene FBO, post FX, UI pass
        ui_batch.* ui_font.* ui_layout.* ui_widgets.* hud.*   in-engine UI: drawing, geometry, shared buttons, HUD
        controls.*        everything the player steers with, behind one interface (all GL free, tested on a desktop):
            controls_config.*   steering scheme + button layout + the text format it is saved in
            input.*             multi-touch: floating stick, arrow buttons, TUCK / SLIDE, UI taps
            tilt.*              phone tilt -> steering (smoothing, neutral, dead zone, sensitivity)
            controls_editor.*   the CONTROLS screen: scheme, drag / resize buttons, opacity, tilt settings
        audio_synth.*     procedural wheels / seams / wind / Coleman slide / kick-push / crash / beeps
        engine.*          the one object the shell talks to (+ adaptive quality governor)
tools/                            optional desktop simulators and a headless renderer (see tools/README.md)
```

Rendering highlights: procedural sky with sun, clouds and mountain ranges; road with wear, markings and
a sun sheen; instanced pines/autumn trees/rocks/rails (a few draw calls); a 1024px sun shadow map; scene
rendered to an offscreen target with FXAA, radial speed blur, glare, vignette and grading.
Quality adapts automatically: the engine measures frame time and steps between four presets
(render scale, shadow size, tree density, blur taps).

## Tuning

Open `app/src/main/cpp/core/config.h`: gravity scale, drag, grip, steering response, tuck/slide effects,
road width, countdown length, difficulty ramp, kick-push (`kPush*`) and Coleman slide angle (`kColeSlip*`).
`tools/sim_game` shows the effect on difficulty without a phone.

Controls: `TiltSteer::kFullLockDeg` (tilt.h) is the lean for full steering at 100 % sensitivity, and `kArrowRise` /
`kArrowFall` (input.cpp) set how quickly the arrow buttons turn in and out. Factory button positions are in
`controls_config.cpp`.

**Volume:** `AudioSynth::kMasterVolume` in `app/src/main/cpp/core/audio_synth.h` is the one knob for all game sound
(0.5 by default; lower = quieter). `tools/audio_dump` prints the level of every sound in dBFS.

**Sound design rule:** the wheel and slide sounds are broadband noise only. Nothing in them may repeat at a rate that
follows the speed (the wheels used to be modulated once per turn): that is heard as a "flapping" when slow and as an
engine changing gear when the speed changes. `tools/test_audio` fails if such a tone comes back.
