// controls_editor.h - the CONTROLS screen: pick the steering scheme, drag and resize the buttons, tune the
// button opacity and the tilt sensitivity. It edits a ControlsConfig in place and owns nothing but its own
// touch state, so it is easy to test without a screen.
#pragma once

#include <cstdint>

#include "controls_config.h"
#include "ui_batch.h"
#include "ui_layout.h"

namespace sd {

class ControlsEditor {
public:
    struct Result {
        bool changed = false;    // the configuration was modified: rebuild the layout
        bool recenter = false;   // RECENTER was pressed
        bool done = false;       // DONE was pressed
    };
    struct View {                // what the screen needs to know about the outside world
        bool tiltAvailable = false;
        float tilt = 0.0f;       // live tilt steering for the test gauge (-1..1)
    };

    // The clickable parts of the panel (public only so the implementation's helpers can name them).
    enum class Widget : uint8_t {
        None, Done, Reset, Recenter,
        ModeStick, ModeArrows, ModeTilt, ModeBoth,   // in SteerMode order
        SizeDown, SizeUp, OpacityDown, OpacityUp, TiltDown, TiltUp
    };

    // Where a widget sits, for tests and tools that script taps. False if it is not shown for this steering.
    static bool widgetRect(Widget w, const UiLayout& L, SteerMode shown, Rect* out);

    void open();
    void close();
    bool isOpen() const { return open_; }

    Result onTouch(int action, int id, float x, float y, ControlsConfig& cfg, const UiLayout& L, bool tiltAvailable);
    // Auto-repeat while a + / - is held. Returns true if the configuration changed.
    bool update(float dt, ControlsConfig& cfg, const UiLayout& L, bool tiltAvailable);
    void draw(UiBatch& ui, const UiLayout& L, const ControlsConfig& cfg, const View& view) const;

private:
    enum class Grab : uint8_t { None, Button, Widget };

    bool apply(Widget w, ControlsConfig& cfg, const UiLayout& L, bool tiltAvailable);
    ButtonId activeButton(SteerMode shown) const;   // the selected button, or TUCK if the selected one is hidden

    bool open_ = false;
    ButtonId selected_ = ButtonId::Tuck;
    int pointer_ = -1;
    Grab grab_ = Grab::None;
    Widget pressed_ = Widget::None;
    Vec2 grabOffset_;
    float repeat_ = 0.0f;
};

}  // namespace sd
