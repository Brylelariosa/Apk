#include "audio_synth.h"

#include <algorithm>
#include <cmath>

#include "math3d.h"

namespace sd {

namespace {
constexpr float kFs = static_cast<float>(AudioSynth::kSampleRate);
constexpr float kDt = 1.0f / kFs;
constexpr float kWheelbase = 0.62f;   // front trucks -> rear trucks: every road seam is hit twice, "ta-tak"

inline float onePole(float fc) { return 1.0f - std::exp(-kTwoPi * fc / kFs); }
inline float sine(float freq, float t) { return std::sin(kTwoPi * freq * t); }
inline float svfCoef(float fc) { return 2.0f * std::sin(kPi * std::min(fc, 4500.0f) / kFs); }

// Linear below the knee, smoothly squashed towards full scale above it: loud moments never clip.
inline float limiter(float x) {
    constexpr float knee = 0.55f;
    const float a = std::fabs(x);
    if (a <= knee) return x;
    const float y = knee + (1.0f - knee) * std::tanh((a - knee) / (1.0f - knee));
    return x < 0.0f ? -y : y;
}

// ---- mix levels (before kMasterVolume). Tuned so that riding sits around -30..-24 dBFS RMS and only the
// crash gets close to full scale. Change kMasterVolume in audio_synth.h to make everything louder / quieter.
constexpr float gRum = 1.4f, gRoar = 0.32f, gWind = 0.16f, gGravel = 0.05f, gThump = 0.11f, gGrit = 0.05f;
constexpr float gSlideBody = 0.46f, gSlideHiss = 0.135f, gSqueal = 0.032f, gScritch = 0.15f;
constexpr float gScrape = 0.17f, gPushHiss = 0.14f, gPushScuff = 0.10f, gPushThud = 0.05f;
constexpr float gFoot = 0.08f, gFootNoise = 0.24f, gCrash = 0.27f, gMiss = 0.22f, gPing = 0.03f, gCone = 0.22f;
constexpr float gTick = 0.26f, gGo = 0.24f, gBest = 0.18f;
}  // namespace

AudioSynth::AudioSynth() {
    for (int i = 0; i < kEvents; ++i) {
        counters_[i].store(0u);
        seen_[i] = 0u;
    }
}

AudioSynth& audioSynth() {
    static AudioSynth instance;
    return instance;
}

void AudioSynth::setState(const AudioState& s) {
    speed_.store(s.speed, std::memory_order_relaxed);
    slide_.store(s.slide, std::memory_order_relaxed);
    offroad_.store(s.offroad, std::memory_order_relaxed);
    tuck_.store(s.tuck, std::memory_order_relaxed);
    master_.store(s.master, std::memory_order_relaxed);
}

void AudioSynth::trigger(AudioEvent e) {
    counters_[static_cast<int>(e)].fetch_add(1u, std::memory_order_relaxed);
}

float AudioSynth::noise() {
    rng_ ^= rng_ << 13;
    rng_ ^= rng_ >> 17;
    rng_ ^= rng_ << 5;
    return static_cast<float>(static_cast<int32_t>(rng_)) * (1.0f / 2147483648.0f);
}

void AudioSynth::addThump(float wait, float amp, float freq) {
    for (Thump& th : thumps_) {
        if (th.active) continue;
        th.active = true;
        th.wait = wait;
        th.t = 0.0f;
        th.amp = amp;
        th.freq = freq;
        return;
    }
}

void AudioSynth::render(int16_t* out, int frames) {
    const float speedT = speed_.load(std::memory_order_relaxed);
    const float slideT = slide_.load(std::memory_order_relaxed);
    const float offT = offroad_.load(std::memory_order_relaxed);
    const float tuckT = tuck_.load(std::memory_order_relaxed);
    const float masterT = master_.load(std::memory_order_relaxed);

    // one-shot events
    for (int i = 0; i < kEvents; ++i) {
        const uint32_t c = counters_[i].load(std::memory_order_relaxed);
        if (c == seen_[i]) continue;
        seen_[i] = c;
        switch (static_cast<AudioEvent>(i)) {
            case AudioEvent::Tick: tickT_ = 0.0f; break;
            case AudioEvent::Go: goT_ = 0.0f; break;
            case AudioEvent::Crash: crashT_ = 0.0f; break;
            case AudioEvent::Scrape: scrapeEnv_ = 1.0f; break;
            case AudioEvent::NearMiss: missT_ = 0.0f; break;
            case AudioEvent::ConeHit: coneT_ = 0.0f; break;
            case AudioEvent::NewBest: bestT_ = 0.0f; break;
            case AudioEvent::Push: pushT_ = 0.0f; break;
            case AudioEvent::FootOn: footT_ = 0.0f; break;
            default: break;
        }
    }

    const float smooth = 0.0016f;
    const float speedSmooth = 0.0006f;   // ~75 ms: kick-pushes and bumps must not make the rolling sound pulse
    for (int n = 0; n < frames; ++n) {
        speedS_ += (speedT - speedS_) * speedSmooth;
        slideS_ += (slideT - slideS_) * (slideT > slideS_ ? 0.0030f : 0.0012f);  // bites quickly, fades slowly
        offroadS_ += (offT - offroadS_) * smooth;
        tuckS_ += (tuckT - tuckS_) * smooth;
        masterS_ += (masterT - masterS_) * 0.002f;
        const float v = speedS_;
        const float sp = std::min(v / 38.0f, 1.3f);
        const float nz = noise();
        float mix = 0.0f;

        // ---------------------------------------------------------------- wheels rolling on asphalt
        // A low rumble plus a mid "roar", both swelling and brightening with speed. This is broadband noise and
        // nothing in it is periodic. (An earlier version modulated the level once per wheel turn: a "flapping" brrr
        // when slow and an engine-like hum whose pitch rose and fell with the speed, i.e. it sounded like a car
        // changing gear.) The life comes from random, un-pitched variation: the road surface changes slowly, the
        // level shimmers a little, and fine asphalt grit crackles under the wheels.
        if (v > 0.05f) {
            texLp_ += (nz - texLp_) * onePole(2.5f);  // slowly changing road texture
            const float tex = std::max(0.35f, 1.0f + 9.0f * texLp_);
            shim1_ += (nz - shim1_) * onePole(14.0f);  // random shimmer (band-limited noise, ~8% deep)
            shim2_ += (shim1_ - shim2_) * onePole(14.0f);
            const float shimmer = std::max(0.4f, 1.0f + 4.5f * shim2_);
            const float ar = onePole(90.0f + 140.0f * sp);
            rum1_ += (nz - rum1_) * ar;
            rum2_ += (rum1_ - rum2_) * ar;
            const float ao = onePole(500.0f + 1500.0f * sp);
            roar1_ += (nz - roar1_) * ao;
            roar2_ += (roar1_ - roar2_) * ao;
            const float amp = std::sqrt(sp) * std::sqrt(std::sqrt(sp));  // sp^0.75: clearly audible at jogging speed, fuller as it gets fast
            const float trim = 0.72f + 0.15f * std::min(1.0f, v / 25.0f);  // keeps the level where the old, fluttering mix sat
            mix += (rum2_ * gRum * (1.0f + 0.9f * offroadS_) + (roar2_ - rum2_) * gRoar) * shimmer * tex * amp * trim;
            // asphalt grit: tiny random ticks, more of them the faster the wheels turn (too dense to ever sound like a rhythm)
            if (std::fabs(noise()) > 1.0f - (6.0f + 4.5f * v) * kDt) gritEnv_ = 1.0f;
            gritLp_ += (nz - gritLp_) * onePole(900.0f);
            mix += (nz - gritLp_) * gritEnv_ * gGrit * amp;
            gritEnv_ *= 0.985f;
            // gravel crunch off the road
            const float hp = nz - gravelLp_;
            gravelLp_ += (nz - gravelLp_) * onePole(1800.0f);
            mix += hp * offroadS_ * sp * gGravel;
        }

        // road seams: a pair of low "toks" (front wheels, then rear wheels) every so often. The spacing and the
        // strength of every seam are random, so they read as a road and never as a beat.
        if (v > 1.5f) {
            distAcc_ += v * kDt;
            if (distAcc_ >= nextSeam_) {
                distAcc_ -= nextSeam_;
                nextSeam_ = 4.5f + 8.0f * (0.5f + 0.5f * noise());
                const float a = (0.30f + 0.45f * std::min(1.0f, sp * 1.4f)) * (0.75f + 0.25f * noise());
                addThump(0.0f, a, 96.0f);
                addThump(kWheelbase / std::max(v, 2.0f), a * (0.60f + 0.25f * noise()), 82.0f);
            }
        }
        thumpLp_ += (nz - thumpLp_) * onePole(1400.0f);
        for (Thump& th : thumps_) {
            if (!th.active) continue;
            if (th.wait > 0.0f) {
                th.wait -= kDt;
                continue;
            }
            const float t = th.t;
            mix += (sine(th.freq, t) * std::exp(-t * 55.0f) + thumpLp_ * 2.5f * std::exp(-t * 150.0f)) * th.amp * gThump;
            th.t += kDt;
            if (th.t > 0.2f) th.active = false;
        }

        // ---------------------------------------------------------------- wind (kept soft: it is only ever a background hush)
        const float aw = onePole(150.0f + 1900.0f * sp);
        wind1_ += (nz - wind1_) * aw;
        wind2_ += (wind1_ - wind2_) * aw;
        gustPhase_ += kTwoPi * 0.33f * kDt;
        if (gustPhase_ > kTwoPi) gustPhase_ -= kTwoPi;
        const float gust = 0.85f + 0.15f * std::sin(gustPhase_);
        mix += wind2_ * (0.01f + sp * sp * (1.0f + 0.25f * sp)) * (1.0f + 0.35f * tuckS_) * gust * gWind;

        // ---------------------------------------------------------------- Coleman slide: urethane skidding on asphalt
        if (slideS_ > 0.002f) {
            const float sl = slideS_;
            // stick-slip chatter: the wheels grab and let go, irregularly. The level wanders randomly (band-limited
            // noise); the earlier regular flutter was a ~30-60 Hz buzz that rose and fell with the speed like an engine.
            chat1_ += (nz - chat1_) * onePole(30.0f);
            chat2_ += (chat1_ - chat2_) * onePole(30.0f);
            const float chat = 0.62f + 0.38f * saturate(0.5f + 8.2f * chat2_);
            const float lvl = sl * (0.30f + 0.70f * std::min(1.0f, v / 16.0f));  // a slow slide is a quiet slide
            const float body = slideBody_.run(nz, svfCoef(380.0f + 420.0f * sp), 0.85f);
            const float hiss = slideHiss_.run(nz, svfCoef(1700.0f + 700.0f * sp), 0.60f);
            mix += (body * gSlideBody + hiss * gSlideHiss) * chat * lvl;
            // a thin squeal that comes and goes: a narrow band of ringing noise, never a pure whistling tone
            squealLfo_ += kTwoPi * 0.45f * kDt;
            if (squealLfo_ > kTwoPi * 1000.0f) squealLfo_ -= kTwoPi * 1000.0f;   // (1000 whole turns: seamless for the 0.43x term too)
            const float gate = std::max(0.0f, std::sin(squealLfo_) * std::sin(squealLfo_ * 0.43f + 1.1f));
            const float sq = squealBand_.run(nz, svfCoef(1750.0f + 650.0f * sp + 120.0f * std::sin(squealLfo_ * 0.7f)), 0.12f);
            mix += sq * gate * lvl * gSqueal * 0.6f;
            // the glove puck scritching along the road
            if (nz > 0.9965f) scritchEnv_ = 1.0f;
            scritchLp_ += (nz - scritchLp_) * onePole(3200.0f);
            mix += (nz - scritchLp_) * scritchEnv_ * lvl * gScritch;
        }
        scritchEnv_ *= 0.9965f;
        if (scritchEnv_ < 1e-4f) scritchEnv_ = 0.0f;

        // rail scrape
        if (scrapeEnv_ > 0.001f) {
            mix += scrapeBand_.run(nz, svfCoef(1800.0f), 0.6f) * scrapeEnv_ * gScrape;
            scrapeEnv_ *= 0.9996f;
        }

        // ---------------------------------------------------------------- kick-push
        if (pushT_ >= 0.0f) {  // shoe slaps down and scuffs back along the asphalt
            const float t = pushT_;
            const float attack = 1.0f - std::exp(-t * 700.0f);
            const float shff = pushHiss_.run(nz, svfCoef(2400.0f), 0.8f) * attack * std::exp(-t * 14.0f);
            const float scuff = pushScuff_.run(nz, svfCoef(760.0f), 0.9f) * attack * std::exp(-t * 4.5f);
            const float thud = sine(118.0f, t) * std::exp(-t * 38.0f);
            mix += shff * gPushHiss + scuff * gPushScuff + thud * gPushThud;
            pushT_ += kDt;
            if (pushT_ > 0.6f) pushT_ = -1.0f;
        }
        if (footT_ >= 0.0f) {  // foot back on the deck
            const float t = footT_;
            footLp_ += (nz - footLp_) * onePole(1200.0f);
            mix += sine(168.0f, t) * std::exp(-t * 46.0f) * gFoot + footLp_ * std::exp(-t * 170.0f) * gFootNoise;
            footT_ += kDt;
            if (footT_ > 0.25f) footT_ = -1.0f;
        }

        // ---------------------------------------------------------------- events
        if (tickT_ >= 0.0f) {
            mix += sine(660.0f, tickT_) * std::exp(-tickT_ * 26.0f) * gTick;
            tickT_ += kDt;
            if (tickT_ > 0.25f) tickT_ = -1.0f;
        }
        if (goT_ >= 0.0f) {
            mix += (sine(990.0f, goT_) + 0.5f * sine(1485.0f, goT_)) * std::exp(-goT_ * 7.0f) * gGo;
            goT_ += kDt;
            if (goT_ > 0.7f) goT_ = -1.0f;
        }
        if (crashT_ >= 0.0f) {
            const float t = crashT_;
            // the impact: a low thud with a falling pitch, and the dull body of the hit
            crashPhase_ += kTwoPi * (42.0f + 70.0f * std::exp(-t * 10.0f)) * kDt;
            if (crashPhase_ > kTwoPi) crashPhase_ -= kTwoPi;
            float c = std::sin(crashPhase_) * std::exp(-t * 6.0f) * 0.9f;
            crashLp_ += (nz - crashLp_) * onePole(150.0f + 1100.0f * std::exp(-t * 4.0f));
            c += crashLp_ * std::exp(-t * 7.0f) * 2.0f;
            // skidding along the tarmac
            const float graze = crashScrape_.run(nz, svfCoef(900.0f + 300.0f * std::exp(-t * 2.0f)), 0.7f);
            c += graze * std::exp(-t * 2.2f) * (0.6f + 0.4f * std::sin(kTwoPi * 17.0f * t));
            // board and helmet clattering after the hit
            static const float kClatter[5] = {0.30f, 0.47f, 0.59f, 0.67f, 0.73f};
            for (int k = 0; k < 5; ++k) {
                const float tc = t - kClatter[k];
                if (tc > 0.0f && tc < 0.12f) {
                    c += ((nz - crashLp_) * 0.5f + sine(210.0f + 40.0f * static_cast<float>(k), tc) * 0.5f) *
                         std::exp(-tc * 85.0f) * (0.55f - 0.08f * static_cast<float>(k));
                }
            }
            mix += c * gCrash;
            crashT_ += kDt;
            if (crashT_ > 1.8f) crashT_ = -1.0f;
        }
        if (missT_ >= 0.0f) {
            const float t = missT_;
            const float bell = std::sin(kPi * std::min(t / 0.5f, 1.0f));
            const float w = missBand_.run(nz, svfCoef(450.0f + 5600.0f * t), 0.7f);
            mix += w * bell * bell * gMiss + sine(1760.0f, t) * std::exp(-t * 14.0f) * gPing;
            missT_ += kDt;
            if (missT_ > 0.5f) missT_ = -1.0f;
        }
        if (coneT_ >= 0.0f) {
            mix += (sine(165.0f, coneT_) * std::exp(-coneT_ * 24.0f) * 0.8f + nz * std::exp(-coneT_ * 70.0f) * 0.45f) * gCone;
            coneT_ += kDt;
            if (coneT_ > 0.3f) coneT_ = -1.0f;
        }
        if (bestT_ >= 0.0f) {
            const float freqs[3] = {660.0f, 880.0f, 1320.0f};
            for (int k = 0; k < 3; ++k) {
                const float t = bestT_ - 0.12f * static_cast<float>(k);
                if (t >= 0.0f) mix += sine(freqs[k], t) * std::exp(-t * 9.0f) * gBest;
            }
            bestT_ += kDt;
            if (bestT_ > 1.0f) bestT_ = -1.0f;
        }

        // ---------------------------------------------------------------- master: level, DC / sub-bass trim, soft limiter
        mix *= masterS_ * AudioSynth::kMasterVolume;
        dc_ += (mix - dc_) * onePole(40.0f);
        mix -= dc_;
        out[n] = static_cast<int16_t>(clampf(limiter(mix), -1.0f, 1.0f) * 30000.0f);
    }
}

}  // namespace sd
