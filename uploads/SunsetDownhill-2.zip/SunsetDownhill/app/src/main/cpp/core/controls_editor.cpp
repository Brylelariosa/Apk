#include "controls_editor.h"

#include <cmath>
#include <cstdio>

#include "input.h"   // TouchAction
#include "ui_font.h"
#include "ui_widgets.h"

namespace sd {
namespace {

using namespace widgets;
using Widget = ControlsEditor::Widget;

constexpr float kRepeatDelay = 0.40f;    // seconds a + / - must be held before it starts repeating
constexpr float kRepeatPeriod = 0.09f;

constexpr int kModeCount = static_cast<int>(SteerMode::Count);
constexpr const char* kModeLabels[kModeCount] = {"STICK", "ARROWS", "TILT", "ARROWS+TILT"};
static_assert(kModeCount == 4, "the selector below has one segment per steering mode");

// ---------------------------------------------------------------------------------------------------------------
// Panel geometry (top band of the screen). Shared by drawing and hit testing so they can never disagree.
// ---------------------------------------------------------------------------------------------------------------
struct Panel {
    Rect done, reset, recenter;
    Rect seg[kModeCount];
    Rect size, opacity, tilt;
    bool showTilt = false;
    float segText = 0.0f, pillText = 0.0f, labelSize = 0.0f, valueSize = 0.0f;
};

Panel makePanel(const UiLayout& L, SteerMode shown) {
    Panel P;
    const float u = L.u;
    const float rowH = 76.0f * u, gap = 12.0f * u, top = 24.0f * u;
    const float availW = L.w - 2.0f * L.margin;
    P.showTilt = usesTilt(shown);
    P.pillText = 28.0f * u;

    // row 1 (the title sits on the left): RESET and DONE on the right
    const float bw = 190.0f * u;
    P.done = {L.w - L.margin - bw, top, bw, rowH};
    P.reset = {P.done.x - 14.0f * u - bw, top, bw, rowH};

    // row 2: the steering selector, centred; squeezed to fit narrow screens
    const float y2 = top + rowH + gap;
    float segText = 28.0f * u, pad = 52.0f * u, sgap = 8.0f * u;
    float total = static_cast<float>(kModeCount - 1) * sgap;
    for (const char* label : kModeLabels) total += textWidth(label, segText) + pad;
    const float k2 = total > availW ? availW / total : 1.0f;
    segText *= k2;
    pad *= k2;
    sgap *= k2;
    float x = (L.w - total * k2) * 0.5f;
    for (int i = 0; i < kModeCount; ++i) {
        const float w = textWidth(kModeLabels[i], segText) + pad;
        P.seg[i] = {x, y2, w, rowH};
        x += w + sgap;
    }
    P.segText = segText;

    // row 3: steppers (and RECENTER when tilt is in use), centred; squeezed to fit narrow screens
    const float y3 = y2 + rowH + gap;
    float stepW = 330.0f * u, recW = 230.0f * u, rgap = 16.0f * u;
    const float total3 = P.showTilt ? 3.0f * stepW + recW + 3.0f * rgap : 2.0f * stepW + rgap;
    const float k3 = total3 > availW ? availW / total3 : 1.0f;
    stepW *= k3;
    recW *= k3;
    rgap *= k3;
    P.labelSize = 16.0f * u * k3;
    P.valueSize = 26.0f * u * k3;
    float x3 = (L.w - total3 * k3) * 0.5f;
    P.size = {x3, y3, stepW, rowH};
    x3 += stepW + rgap;
    P.opacity = {x3, y3, stepW, rowH};
    x3 += stepW + rgap;
    if (P.showTilt) {
        P.tilt = {x3, y3, stepW, rowH};
        x3 += stepW + rgap;
        P.recenter = {x3, y3, recW, rowH};
    }
    return P;
}

// A stepper is [ - ][ label / value ][ + ]; the outer zones are the touch targets.
float zoneWidth(const Rect& r) { return r.h * 1.1f; }
Rect minusZone(const Rect& r) { return {r.x, r.y, zoneWidth(r), r.h}; }
Rect plusZone(const Rect& r) { return {r.x + r.w - zoneWidth(r), r.y, zoneWidth(r), r.h}; }

Widget hitWidget(const Panel& P, float x, float y) {
    if (P.done.contains(x, y)) return Widget::Done;
    if (P.reset.contains(x, y)) return Widget::Reset;
    for (int i = 0; i < kModeCount; ++i)
        if (P.seg[i].contains(x, y)) return static_cast<Widget>(static_cast<int>(Widget::ModeStick) + i);
    if (minusZone(P.size).contains(x, y)) return Widget::SizeDown;
    if (plusZone(P.size).contains(x, y)) return Widget::SizeUp;
    if (minusZone(P.opacity).contains(x, y)) return Widget::OpacityDown;
    if (plusZone(P.opacity).contains(x, y)) return Widget::OpacityUp;
    if (P.showTilt) {
        if (minusZone(P.tilt).contains(x, y)) return Widget::TiltDown;
        if (plusZone(P.tilt).contains(x, y)) return Widget::TiltUp;
        if (P.recenter.contains(x, y)) return Widget::Recenter;
    }
    return Widget::None;
}

bool isStepper(Widget w) { return w >= Widget::SizeDown; }
bool isMode(Widget w) { return w >= Widget::ModeStick && w <= Widget::ModeBoth; }

// ---------------------------------------------------------------------------------------------------------------
// Placing buttons
// ---------------------------------------------------------------------------------------------------------------
bool visible(ButtonId b, SteerMode shown) { return !isArrowButton(b) || usesArrows(shown); }

float radiusOf(const ControlsConfig& cfg, const UiLayout& L, ButtonId b) {
    return UiLayout::baseRadius(b, L.u) * cfg.button[toIndex(b)].scale;
}

Vec2 pushApart(Vec2 p, Vec2 other, float minDist) {
    const Vec2 d = p - other;
    const float len = length(d);
    if (len >= minDist) return p;
    if (len < 1e-3f) return Vec2(other.x + minDist, other.y);   // exactly on top: pick a side
    return other + d * (minDist / len);
}

// Is a button of radius r with its centre at c clear of every other visible button and of the pause button
// (which has to stay reachable)? c is assumed to be on screen already.
bool isFree(const ControlsConfig& cfg, const UiLayout& L, ButtonId id, SteerMode shown, Vec2 c, float r) {
    const float gap = 10.0f * L.u, eps = 0.01f;
    for (int i = 0; i < kButtonCount; ++i) {
        const ButtonId other = static_cast<ButtonId>(i);
        if (other == id || !visible(other, shown)) continue;
        if (length(c - L.btnC[i]) < r + radiusOf(cfg, L, other) + gap - eps) return false;
    }
    return length(c - L.pauseC) >= r + L.pauseR * 1.5f + gap - eps;
}

// The nearest legal spot for button `id` near `target`: on screen and clear of the other buttons.
// Pushing out of one obstacle is exact and glides smoothly along its edge while dragging; if that still leaves the
// button on top of something (a crowded corner), fall back to searching outwards for the closest free spot.
Vec2 legalCenter(const ControlsConfig& cfg, const UiLayout& L, ButtonId id, SteerMode shown, Vec2 target) {
    const int self = toIndex(id);
    const float r = radiusOf(cfg, L, id);
    const float gap = 10.0f * L.u;
    const Vec2 start = L.clampCenter(r, target);
    Vec2 c = start;
    for (int pass = 0; pass < 3; ++pass) {
        for (int i = 0; i < kButtonCount; ++i) {
            const ButtonId other = static_cast<ButtonId>(i);
            if (i == self || !visible(other, shown)) continue;
            c = pushApart(c, L.btnC[i], r + radiusOf(cfg, L, other) + gap);
        }
        c = pushApart(c, L.pauseC, r + L.pauseR * 1.5f + gap);
        c = L.clampCenter(r, c);
    }
    if (isFree(cfg, L, id, shown, c, r)) return c;

    const float step = 8.0f * L.u, reach = std::max(L.w, L.h);
    for (float ring = step; ring <= reach; ring += step) {
        Vec2 best = start;
        float bestDist = 1e30f;
        for (int k = 0; k < 48; ++k) {
            const float a = kTwoPi * static_cast<float>(k) / 48.0f;
            const Vec2 cand = L.clampCenter(r, start + Vec2(std::cos(a), std::sin(a)) * ring);
            const float d = length(cand - start);
            if (d < bestDist && isFree(cfg, L, id, shown, cand, r)) {
                bestDist = d;
                best = cand;
            }
        }
        if (bestDist < 1e29f) return best;
    }
    return c;   // a hopelessly cramped screen: leave it where the push put it
}

void settle(ControlsConfig& cfg, const UiLayout& L, ButtonId id, SteerMode shown) {
    ButtonSpec& s = cfg.button[toIndex(id)];
    const Vec2 c = legalCenter(cfg, L, id, shown, L.specToPx(s));
    s.x = L.pxToX(c.x);
    s.y = c.y / L.h;
}

// The visible button under (x, y); with overlapping touch circles the relatively closest centre wins.
int buttonAt(const UiLayout& L, SteerMode shown, float x, float y) {
    int best = -1;
    float bestScore = 1e30f;
    for (int i = 0; i < kButtonCount; ++i) {
        if (!visible(static_cast<ButtonId>(i), shown)) continue;
        const float dx = x - L.btnC[i].x, dy = y - L.btnC[i].y;
        const float score = (dx * dx + dy * dy) / (L.btnHit[i] * L.btnHit[i]);
        if (score <= 1.0f && score < bestScore) {
            bestScore = score;
            best = i;
        }
    }
    return best;
}

float snap(float v, float step) { return std::round(v / step) * step; }

// ---------------------------------------------------------------------------------------------------------------
// Drawing helpers
// ---------------------------------------------------------------------------------------------------------------
void drawStepper(UiBatch& ui, const Rect& r, const char* label, const char* value, bool canDown, bool canUp,
                 bool downPressed, bool upPressed, const Panel& P) {
    ui.roundRect(r.x, r.y, r.w, r.h, r.h * 0.4f, alpha(Rgba8{30, 20, 60, 255}, 0.67f));
    const float cy = r.y + r.h * 0.5f, rad = r.h * 0.30f;
    auto zone = [&](float cx, bool enabled, bool pressed, bool plus) {
        ui.circle(cx, cy, rad * 1.18f, alpha(kWhite, enabled ? (pressed ? 0.50f : 0.18f) : 0.06f), 28);
        const Rgba8 g = alpha(kWhite, enabled ? 0.95f : 0.30f);
        ui.rect(cx - rad * 0.55f, cy - rad * 0.10f, rad * 1.10f, rad * 0.20f, g);
        if (plus) ui.rect(cx - rad * 0.10f, cy - rad * 0.55f, rad * 0.20f, rad * 1.10f, g);
    };
    zone(r.x + zoneWidth(r) * 0.5f, canDown, downPressed, false);
    zone(r.x + r.w - zoneWidth(r) * 0.5f, canUp, upPressed, true);
    const float mx = r.x + r.w * 0.5f;
    const float ly = r.y + r.h * 0.13f;
    drawText(ui, label, mx, ly, P.labelSize, alpha(kAccent, 0.95f), TextAlign::Center);
    drawText(ui, value, mx, ly + P.labelSize + r.h * 0.09f, P.valueSize, kWhite, TextAlign::Center);
}

// Four small arrow heads around the selected button: "this one moves".
void moveCue(UiBatch& ui, Vec2 c, float r, float u, Rgba8 col) {
    const float d = r * 1.12f + 10.0f * u, s = 9.0f * u, b = s * 0.6f;
    ui.triangle({c.x - d - s, c.y}, {c.x - d + b, c.y - s}, {c.x - d + b, c.y + s}, col);
    ui.triangle({c.x + d + s, c.y}, {c.x + d - b, c.y - s}, {c.x + d - b, c.y + s}, col);
    ui.triangle({c.x, c.y - d - s}, {c.x - s, c.y - d + b}, {c.x + s, c.y - d + b}, col);
    ui.triangle({c.x, c.y + d + s}, {c.x - s, c.y + d - b}, {c.x + s, c.y + d - b}, col);
}

// What the floating stick looks like, drawn into the zone where it lives.
void drawStickZone(UiBatch& ui, const UiLayout& L) {
    const float u = L.u;
    const float inset = 0.55f * L.margin;
    const float zx = inset, zy = L.buttonTop + 40.0f * u;
    const float zw = L.steerZoneRight - zx - 10.0f * u, zh = L.h - inset - zy;
    ui.roundRect(zx, zy, zw, zh, 36.0f * u, alpha(kWhite, 0.05f));
    const float cx = zx + zw * 0.5f, cy = zy + zh * 0.5f;
    ui.ring(cx, cy, L.stickRange, L.stickRange + 4.0f * u, alpha(kWhite, 0.28f), 56);
    arrowHead(ui, cx - L.stickRange - 26.0f * u, cy, 15.0f * u, -1, alpha(kWhite, 0.30f));
    arrowHead(ui, cx + L.stickRange + 26.0f * u, cy, 15.0f * u, 1, alpha(kWhite, 0.30f));
    ui.circle(cx + L.stickRange * 0.45f, cy, 52.0f * u, alpha(kWhite, 0.30f), 36);
    const float ts = fitSize("THE STICK APPEARS WHERE YOU TOUCH", 22.0f * u, zw * 0.9f);
    drawText(ui, "THE STICK APPEARS WHERE YOU TOUCH", cx, cy + L.stickRange + 40.0f * u, ts, alpha(kWhite, 0.55f), TextAlign::Center);
}

}  // namespace

// ---------------------------------------------------------------------------------------------------------------
// ControlsEditor
// ---------------------------------------------------------------------------------------------------------------
bool ControlsEditor::widgetRect(Widget w, const UiLayout& L, SteerMode shown, Rect* out) {
    const Panel P = makePanel(L, shown);
    Rect r;
    switch (w) {
        case Widget::Done: r = P.done; break;
        case Widget::Reset: r = P.reset; break;
        case Widget::ModeStick:
        case Widget::ModeArrows:
        case Widget::ModeTilt:
        case Widget::ModeBoth: r = P.seg[static_cast<int>(w) - static_cast<int>(Widget::ModeStick)]; break;
        case Widget::SizeDown: r = minusZone(P.size); break;
        case Widget::SizeUp: r = plusZone(P.size); break;
        case Widget::OpacityDown: r = minusZone(P.opacity); break;
        case Widget::OpacityUp: r = plusZone(P.opacity); break;
        case Widget::TiltDown:
        case Widget::TiltUp:
        case Widget::Recenter:
            if (!P.showTilt) return false;
            r = w == Widget::TiltDown ? minusZone(P.tilt) : (w == Widget::TiltUp ? plusZone(P.tilt) : P.recenter);
            break;
        default: return false;
    }
    if (out) *out = r;
    return true;
}

void ControlsEditor::open() {
    open_ = true;
    selected_ = ButtonId::Tuck;
    pointer_ = -1;
    grab_ = Grab::None;
    pressed_ = Widget::None;
}

void ControlsEditor::close() {
    open_ = false;
    pointer_ = -1;
    grab_ = Grab::None;
    pressed_ = Widget::None;
}

ButtonId ControlsEditor::activeButton(SteerMode shown) const {
    return visible(selected_, shown) ? selected_ : ButtonId::Tuck;
}

bool ControlsEditor::apply(Widget w, ControlsConfig& cfg, const UiLayout& L, bool tiltAvailable) {
    const SteerMode shown = effectiveMode(cfg.mode, tiltAvailable);
    if (isMode(w)) {
        const SteerMode m = static_cast<SteerMode>(static_cast<int>(w) - static_cast<int>(Widget::ModeStick));
        if ((usesTilt(m) && !tiltAvailable) || cfg.mode == m) return false;
        cfg.mode = m;
        if (usesArrows(m) && !usesArrows(shown)) {   // the arrows were hidden: keep them from landing on another button
            settle(cfg, L, ButtonId::Left, m);
            settle(cfg, L, ButtonId::Right, m);
        }
        return true;
    }
    switch (w) {
        case Widget::SizeDown:
        case Widget::SizeUp: {
            const ButtonId sel = activeButton(shown);
            ButtonSpec& b = cfg.button[toIndex(sel)];
            const float step = ControlsConfig::kScaleStep * (w == Widget::SizeUp ? 1.0f : -1.0f);
            const float s = clampf(snap(b.scale + step, ControlsConfig::kScaleStep), ControlsConfig::kMinScale, ControlsConfig::kMaxScale);
            if (std::fabs(s - b.scale) < 1e-4f) return false;
            b.scale = s;
            settle(cfg, L, sel, shown);   // a bigger button may need to move off the edge or away from a neighbour
            return true;
        }
        case Widget::OpacityDown:
        case Widget::OpacityUp: {
            const float step = ControlsConfig::kOpacityStep * (w == Widget::OpacityUp ? 1.0f : -1.0f);
            const float v = clampf(snap(cfg.opacity + step, ControlsConfig::kOpacityStep), ControlsConfig::kMinOpacity, ControlsConfig::kMaxOpacity);
            if (std::fabs(v - cfg.opacity) < 1e-4f) return false;
            cfg.opacity = v;
            return true;
        }
        case Widget::TiltDown:
        case Widget::TiltUp: {
            const float step = ControlsConfig::kTiltStep * (w == Widget::TiltUp ? 1.0f : -1.0f);
            const float v = clampf(snap(cfg.tiltSensitivity + step, ControlsConfig::kTiltStep), ControlsConfig::kMinTilt, ControlsConfig::kMaxTilt);
            if (std::fabs(v - cfg.tiltSensitivity) < 1e-4f) return false;
            cfg.tiltSensitivity = v;
            return true;
        }
        default: return false;
    }
}

ControlsEditor::Result ControlsEditor::onTouch(int action, int id, float x, float y, ControlsConfig& cfg, const UiLayout& L, bool tiltAvailable) {
    Result res;
    if (!open_) return res;
    if (action == kTouchCancel) {
        pointer_ = -1;
        grab_ = Grab::None;
        pressed_ = Widget::None;
        return res;
    }
    const SteerMode shown = effectiveMode(cfg.mode, tiltAvailable);
    const Panel P = makePanel(L, shown);

    if (action == kTouchDown) {
        if (pointer_ >= 0) return res;   // one finger at a time keeps dragging unambiguous
        const Widget w = hitWidget(P, x, y);
        if (w != Widget::None) {
            pointer_ = id;
            grab_ = Grab::Widget;
            pressed_ = w;
            repeat_ = kRepeatDelay;
            if (isMode(w) || isStepper(w)) res.changed = apply(w, cfg, L, tiltAvailable);   // these act on press
            return res;                                                                      // DONE / RESET / RECENTER act on release
        }
        const int b = buttonAt(L, shown, x, y);
        if (b >= 0) {
            pointer_ = id;
            grab_ = Grab::Button;
            selected_ = static_cast<ButtonId>(b);
            grabOffset_ = L.btnC[b] - Vec2(x, y);
        }
        return res;
    }
    if (id != pointer_) return res;

    if (action == kTouchMove) {
        if (grab_ == Grab::Button) {
            const ButtonId sel = selected_;
            const Vec2 c = legalCenter(cfg, L, sel, shown, Vec2(x, y) + grabOffset_);
            ButtonSpec& s = cfg.button[toIndex(sel)];
            const float nx = L.pxToX(c.x), ny = c.y / L.h;
            if (nx != s.x || ny != s.y) {
                s.x = nx;
                s.y = ny;
                res.changed = true;
            }
        } else if (grab_ == Grab::Widget && hitWidget(P, x, y) != pressed_) {
            pressed_ = Widget::None;   // the finger slid off: no more repeats and nothing happens on release
        }
    } else if (action == kTouchUp) {
        if (grab_ == Grab::Widget && pressed_ != Widget::None && hitWidget(P, x, y) == pressed_) {
            switch (pressed_) {
                case Widget::Done: res.done = true; break;
                case Widget::Reset:
                    cfg.resetLayout();
                    res.changed = true;
                    break;
                case Widget::Recenter: res.recenter = true; break;
                default: break;
            }
        }
        pointer_ = -1;
        grab_ = Grab::None;
        pressed_ = Widget::None;
    }
    return res;
}

bool ControlsEditor::update(float dt, ControlsConfig& cfg, const UiLayout& L, bool tiltAvailable) {
    if (!open_ || grab_ != Grab::Widget || !isStepper(pressed_)) return false;
    repeat_ -= dt;
    bool changed = false;
    while (repeat_ <= 0.0f) {
        changed |= apply(pressed_, cfg, L, tiltAvailable);
        repeat_ += kRepeatPeriod;
    }
    return changed;
}

void ControlsEditor::draw(UiBatch& ui, const UiLayout& L, const ControlsConfig& cfg, const View& view) const {
    if (!open_) return;
    const float u = L.u;
    const SteerMode shown = effectiveMode(cfg.mode, view.tiltAvailable);
    const Panel P = makePanel(L, shown);
    const ButtonId sel = activeButton(shown);

    ui.rect(0.0f, 0.0f, L.w, L.h, Rgba8{10, 4, 24, 165});   // mute the scene behind

    if (usesStick(shown)) drawStickZone(ui, L);
    if (usesTilt(cfg.mode)) {
        if (view.tiltAvailable) {
            tiltGauge(ui, L, view.tilt, 1.0f, true);
        } else {
            const float cy = L.h - 0.62f * L.margin - 8.0f * u;
            text(ui, "NO TILT SENSOR - USING THE ARROWS", L.w * 0.5f, cy - 40.0f * u, 24.0f * u, alpha(kRed, 0.95f), TextAlign::Center);
        }
    }

    // the buttons exactly as they look in the game; the selected one is ringed
    for (int i = 0; i < kButtonCount; ++i) {
        const ButtonId b = static_cast<ButtonId>(i);
        if (visible(b, shown)) controlButton(ui, L, b, false, cfg.opacity);
    }
    {
        const Vec2 c = L.center(sel);
        const float r = L.radius(sel);
        ui.ring(c.x, c.y, r * 1.06f, r * 1.12f, alpha(kAccent, 0.95f), 56);
        moveCue(ui, c, r, u, alpha(kAccent, 0.85f));
    }

    // the panel
    ui.rectGradient(0.0f, 0.0f, L.w, P.size.y + P.size.h + 44.0f * u, Rgba8{12, 4, 30, 225}, Rgba8{12, 4, 30, 0});
    const float titleSize = 46.0f * u;
    text(ui, "CONTROLS", L.margin, P.done.y + (P.done.h - titleSize) * 0.5f, titleSize, kWhite);
    pill(ui, P.reset, "RESET", P.pillText, 1.0f, pressed_ == Widget::Reset);
    pill(ui, P.done, "DONE", P.pillText, 1.0f, true);

    for (int i = 0; i < kModeCount; ++i) {
        const SteerMode m = static_cast<SteerMode>(i);
        const bool selectedMode = cfg.mode == m;
        const bool usable = !usesTilt(m) || view.tiltAvailable;
        const Rect& r = P.seg[i];
        const float fade = usable ? 1.0f : 0.40f;
        ui.roundRect(r.x, r.y, r.w, r.h, r.h * 0.4f, selectedMode ? alpha(kAccent, 0.92f * fade) : alpha(Rgba8{30, 20, 60, 255}, 0.67f * fade));
        drawText(ui, kModeLabels[i], r.x + r.w * 0.5f, r.y + (r.h - P.segText) * 0.5f, P.segText,
                 selectedMode ? kInk : alpha(kWhite, usable ? 1.0f : 0.40f), TextAlign::Center);
    }

    char value[16];
    static const char* kSizeLabels[kButtonCount] = {"TUCK SIZE", "SLIDE SIZE", "LEFT SIZE", "RIGHT SIZE"};
    const float scale = cfg.button[toIndex(sel)].scale;
    std::snprintf(value, sizeof(value), "%d%%", static_cast<int>(std::lround(scale * 100.0f)));
    drawStepper(ui, P.size, kSizeLabels[toIndex(sel)], value, scale > ControlsConfig::kMinScale + 1e-3f, scale < ControlsConfig::kMaxScale - 1e-3f,
                pressed_ == Widget::SizeDown, pressed_ == Widget::SizeUp, P);
    std::snprintf(value, sizeof(value), "%d%%", static_cast<int>(std::lround(cfg.opacity * 100.0f)));
    drawStepper(ui, P.opacity, "OPACITY", value, cfg.opacity > ControlsConfig::kMinOpacity + 1e-3f, cfg.opacity < ControlsConfig::kMaxOpacity - 1e-3f,
                pressed_ == Widget::OpacityDown, pressed_ == Widget::OpacityUp, P);
    if (P.showTilt) {
        std::snprintf(value, sizeof(value), "%d%%", static_cast<int>(std::lround(cfg.tiltSensitivity * 100.0f)));
        drawStepper(ui, P.tilt, "TILT SENS", value, cfg.tiltSensitivity > ControlsConfig::kMinTilt + 1e-3f,
                    cfg.tiltSensitivity < ControlsConfig::kMaxTilt - 1e-3f, pressed_ == Widget::TiltDown, pressed_ == Widget::TiltUp, P);
        pill(ui, P.recenter, "RECENTER", P.pillText * 0.8f, 1.0f, pressed_ == Widget::Recenter);
    }

    const char* hint = "DRAG A BUTTON TO MOVE IT   SIZE RESIZES THE RINGED ONE";
    const float hs = fitSize(hint, 20.0f * u, L.w - 2.0f * L.margin);
    text(ui, hint, L.w * 0.5f, L.buttonTop + 6.0f * u, hs, alpha(kWhite, 0.70f), TextAlign::Center);
}

}  // namespace sd
