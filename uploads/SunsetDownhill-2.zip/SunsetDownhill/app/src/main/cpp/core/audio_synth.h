// audio_synth.h - procedural sound (wheels, wind, slides, kick-pushes, crashes, UI beeps). No audio assets needed.
// The game thread publishes state through atomics; the audio thread calls render().
#pragma once

#include <atomic>
#include <cstdint>

namespace sd {

enum class AudioEvent : int { Tick = 0, Go, Crash, Scrape, NearMiss, ConeHit, NewBest, Push, FootOn, Count };

struct AudioState {
    float speed = 0.0f;    // m/s
    float slide = 0.0f;    // 0..1 (Coleman slide)
    float offroad = 0.0f;  // 0..1
    float tuck = 0.0f;     // 0..1
    float master = 1.0f;   // 0 = silent
};

class AudioSynth {
public:
    static constexpr int kSampleRate = 22050;
    // THE volume knob. Everything is mixed relative to this; 0.5 is a comfortable level on a phone at normal
    // media volume. (The first version of the game mixed at roughly 3x this level, which was far too loud.)
    static constexpr float kMasterVolume = 0.5f;

    AudioSynth();
    // ---- game thread
    void setState(const AudioState& s);
    void trigger(AudioEvent e);
    // ---- audio thread
    void render(int16_t* out, int frames);

private:
    static constexpr int kEvents = static_cast<int>(AudioEvent::Count);
    static constexpr int kThumps = 6;

    struct Svf {  // state variable filter (band-pass tap)
        float low = 0.0f, band = 0.0f;
        float run(float x, float f, float damp) {
            low += f * band;
            const float high = x - low - damp * band;
            band += f * high;
            return band;
        }
    };
    struct Thump {  // a short low "tok" (road seam, deck bounce)
        bool active = false;
        float wait = 0.0f, t = 0.0f, amp = 0.0f, freq = 90.0f;
    };

    float noise();
    void addThump(float wait, float amp, float freq);

    std::atomic<float> speed_{0.0f}, slide_{0.0f}, offroad_{0.0f}, tuck_{0.0f}, master_{1.0f};
    std::atomic<uint32_t> counters_[kEvents];

    // audio-thread state
    uint32_t seen_[kEvents];
    uint32_t rng_ = 0x2545F491u;
    float speedS_ = 0.0f, slideS_ = 0.0f, offroadS_ = 0.0f, tuckS_ = 0.0f, masterS_ = 0.0f;

    // wheels / road / wind (everything here is random noise: nothing is periodic, so no pitch follows the speed)
    float texLp_ = 0.0f, shim1_ = 0.0f, shim2_ = 0.0f, rum1_ = 0.0f, rum2_ = 0.0f, roar1_ = 0.0f, roar2_ = 0.0f;
    float wind1_ = 0.0f, wind2_ = 0.0f, gustPhase_ = 0.0f, gravelLp_ = 0.0f, thumpLp_ = 0.0f;
    float gritEnv_ = 0.0f, gritLp_ = 0.0f;
    float distAcc_ = 0.0f, nextSeam_ = 7.0f;
    Thump thumps_[kThumps];

    // slide
    Svf slideBody_, slideHiss_, squealBand_;
    float chat1_ = 0.0f, chat2_ = 0.0f, squealLfo_ = 0.0f, scritchEnv_ = 0.0f, scritchLp_ = 0.0f;

    // one-shots
    float tickT_ = -1.0f, goT_ = -1.0f, crashT_ = -1.0f, missT_ = -1.0f, coneT_ = -1.0f, bestT_ = -1.0f;
    float pushT_ = -1.0f, footT_ = -1.0f;
    float scrapeEnv_ = 0.0f;
    Svf scrapeBand_, pushHiss_, pushScuff_, crashScrape_, missBand_;
    float crashLp_ = 0.0f, crashPhase_ = 0.0f, footLp_ = 0.0f;
    float dc_ = 0.0f;
};

AudioSynth& audioSynth();

}  // namespace sd
