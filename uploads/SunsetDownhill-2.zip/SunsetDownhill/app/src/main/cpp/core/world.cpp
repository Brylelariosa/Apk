#include "world.h"

#include <algorithm>
#include <cmath>

namespace sd {
namespace {

Instance makeInstance(const Vec3& p, float yaw, float sx, float sy, float phase, float pitch, Rgba8 tint) {
    Instance in;
    in.x = p.x; in.y = p.y; in.z = p.z;
    in.yaw = yaw;
    in.sx = sx; in.sy = sy;
    in.phase = phase;
    in.pitch = pitch;
    in.r = tint.r; in.g = tint.g; in.b = tint.b; in.a = tint.a;
    return in;
}

// NOTE: the alpha channel of an instance tint is "extra fog" (0 = none, 255 = completely fogged), not opacity.
const Rgba8 kCarColors[] = {
    {217, 26, 26, 0}, {26, 77, 204, 0}, {235, 235, 235, 0}, {242, 191, 26, 0},
    {26, 153, 77, 0}, {153, 158, 168, 0}, {41, 41, 46, 0}, {230, 110, 30, 0}};

}  // namespace

void World::reset(uint32_t seed) {
    track_.reset(seed);
    obstacleRng_.reseed(seed ^ 0x51ED270Bu);
    obstacles_.clear();
    chunks_.clear();
    nextObstacleS_ = 190.0f;
    track_.ensureGenerated(cfg::kViewAhead + 200.0f);
}

void World::update(float dt, float playerS) {
    track_.ensureGenerated(playerS + cfg::kViewAhead + 160.0f);
    spawnUpTo(playerS + 440.0f);
    for (Obstacle& o : obstacles_) {
        if (o.kind == ObstacleKind::Car) o.s += o.vel * dt;
        if (o.hit) o.hitTime += dt;
    }
    obstacles_.erase(std::remove_if(obstacles_.begin(), obstacles_.end(),
                                    [playerS](const Obstacle& o) { return o.s < playerS - 70.0f || o.s > playerS + 900.0f || (o.hit && o.hitTime > 1.5f); }),
                     obstacles_.end());
    const int keepFrom = static_cast<int>(std::floor((playerS - 160.0f) / cfg::kChunkLength));
    for (auto it = chunks_.begin(); it != chunks_.end();) {
        if (it->first < keepFrom) it = chunks_.erase(it);
        else ++it;
    }
}

void World::spawnUpTo(float sLimit) {
    while (nextObstacleS_ < sLimit) {
        const float s = nextObstacleS_;
        const float diff = track_.difficultyAt(s);
        nextObstacleS_ += lerpf(150.0f, 80.0f, diff) * obstacleRng_.range(0.75f, 1.35f);
        // Always consume the same random numbers so the course is identical whatever the settings.
        const float roll = obstacleRng_.uniform();
        const float a = obstacleRng_.uniform(), b = obstacleRng_.uniform(), c = obstacleRng_.uniform();
        const int colorIdx = obstacleRng_.rangeInt(0, 7);
        if (!obstaclesEnabled_) continue;

        const bool carsAllowed = s > 380.0f;
        if (roll < 0.36f || (!carsAllowed && roll > 0.6f)) {
            // diagonal taper of cones that pushes the rider toward the middle
            const float side = a < 0.5f ? -1.0f : 1.0f;
            const int n = 4 + static_cast<int>(b * 2.99f);
            for (int i = 0; i < n; ++i) {
                Obstacle o;
                o.kind = ObstacleKind::Cone;
                o.s = s + 2.6f * static_cast<float>(i);
                o.x = side * (3.0f - 0.55f * static_cast<float>(i));
                o.hs = 0.28f; o.hx = 0.28f;
                obstacles_.push_back(o);
            }
        } else if (roll < 0.58f) {
            Obstacle o;
            o.kind = ObstacleKind::Rock;
            o.s = s;
            o.x = (a - 0.5f) * 5.0f;
            o.scale = 0.75f + b * 0.55f;
            o.hs = 0.78f * o.scale; o.hx = 0.78f * o.scale;
            o.yaw = c * kTwoPi;
            o.tint = rgba(0.75f + 0.25f * a, 0.72f + 0.2f * b, 0.7f, 0.0f);
            obstacles_.push_back(o);
        } else {
            Obstacle o;
            o.kind = ObstacleKind::Car;
            o.s = s;
            o.hs = 2.25f; o.hx = 0.95f;
            o.tint = kCarColors[colorIdx];
            if (roll < 0.8f) {  // same direction, right lane, slower than the rider
                o.x = cfg::kLaneCenter;
                o.vel = 9.0f + 4.0f * b;
            } else {            // oncoming in the left lane, sometimes drifting over the line
                o.x = a < 0.25f ? -0.85f : -cfg::kLaneCenter;
                o.vel = -(10.0f + 4.0f * b);
                o.yaw = kPi;
            }
            obstacles_.push_back(o);
        }
    }
}

// --------------------------------------------------------------------------------------
// Scenery
// --------------------------------------------------------------------------------------

const World::Chunk& World::chunkAt(int index) {
    auto it = chunks_.find(index);
    if (it != chunks_.end()) return it->second;
    Chunk& c = chunks_[index];
    generateChunk(index, c);
    return c;
}

void World::generateChunk(int index, Chunk& chunk) {
    const float L = cfg::kChunkLength;
    const float s0 = static_cast<float>(index) * L;
    track_.ensureGenerated(s0 + L + 12.0f);

    for (int side = 0; side < 2; ++side) {
        const float sd = side == 0 ? -1.0f : 1.0f;
        Rng r(hash2(track_.seed(), static_cast<uint32_t>(index * 2 + side + 1000)));

        // ---- trees
        for (int k = 0; k < 22; ++k) {
            const float da = 9.0f + std::pow(r.uniform(), 1.5f) * 46.0f;
            const float s = s0 + r.uniform() * L;
            const float rank = r.uniform();
            const float typeRoll = r.uniform();
            const float hRand = r.uniform(), wRand = r.uniform(), yawRand = r.uniform(), shade = r.uniform();
            const float hueA = r.uniform(), hueB = r.uniform();
            if (s < 24.0f && da < 16.0f) continue;  // keep the start area open
            const TrackSample f = track_.at(s);
            if (sd * f.curvature > 0.0f && da > Track::insideLimit(f.curvature) * 0.92f) continue;
            const Vec3 p = track_.terrainPoint(s, sd * da);
            const float edge = smoothstep(0.55f, 1.0f, da / cfg::kTerrainMaxOffset);
            Rgba8 tint;
            Batch batch;
            float sy;
            if (typeRoll < 0.74f) {
                batch = kBatchPine;
                sy = 0.8f + 0.75f * hRand;
                const float b = 0.62f + 0.38f * shade;
                tint = rgba(b * (0.85f + 0.15f * hueA), b, b * (0.75f + 0.25f * hueB), edge);
            } else {
                batch = kBatchAutumn;
                sy = 0.70f + 0.45f * hRand;
                tint = rgba(0.85f + 0.15f * hueA, 0.55f + 0.45f * hueB * hueB, 0.35f + 0.5f * shade * hueA, edge);
            }
            const float sx = sy * (0.82f + 0.36f * wRand);
            chunk.items[batch].push_back({makeInstance(p - Vec3(0.0f, 0.12f, 0.0f), yawRand * kTwoPi, sx, sy, hueA * 6.28f, 0.0f, tint), rank});
        }

        // ---- boulders near the road
        const int nRocks = r.rangeInt(0, 2);
        for (int k = 0; k < nRocks; ++k) {
            const float da = 5.9f + r.uniform() * 9.0f;
            const float s = s0 + r.uniform() * L;
            const float sc = 0.6f + r.uniform() * 1.7f;
            const float yaw = r.uniform() * kTwoPi;
            const float lum = r.uniform();
            if (s < 24.0f) continue;
            const TrackSample f = track_.at(s);
            if (sd * f.curvature > 0.0f && da > Track::insideLimit(f.curvature) * 0.92f) continue;
            const Vec3 p = track_.terrainPoint(s, sd * da);
            chunk.items[kBatchRock].push_back({makeInstance(p - Vec3(0.0f, 0.18f * sc, 0.0f), yaw, sc, sc * 0.9f, 0.0f, 0.0f,
                                                            rgba(0.7f + 0.3f * lum, 0.68f + 0.25f * lum, 0.66f + 0.2f * lum, 0.0f)), 0.0f});
        }

        // ---- guard rails (where the ground drops away) and delineator posts
        const int r0 = static_cast<int>(std::ceil(s0 / 4.0f)), r1 = static_cast<int>(std::ceil((s0 + L) / 4.0f));
        for (int k = r0; k < r1; ++k) {
            const float sc = 4.0f * static_cast<float>(k) + 2.0f;
            if (sc < 6.0f) continue;
            if (track_.hillBias(sc) * sd >= 0.10f) continue;
            const TrackSample f = track_.at(sc);
            const Vec3 p = track_.terrainPoint(sc, sd * 5.5f);
            const float yaw = f.heading + (sd < 0.0f ? kPi : 0.0f);
            const float pitch = sd < 0.0f ? -f.pitch : f.pitch;
            chunk.items[kBatchRail].push_back({makeInstance(p, yaw, 1.0f, 1.0f, 0.0f, pitch, Rgba8{255, 255, 255, 0}), 0.0f});
        }
        const int p0 = static_cast<int>(std::ceil(s0 / 12.0f)), p1 = static_cast<int>(std::ceil((s0 + L) / 12.0f));
        for (int k = p0; k < p1; ++k) {
            const float sp = 12.0f * static_cast<float>(k);
            if (sp < 6.0f || track_.hillBias(sp) * sd < 0.10f) continue;  // rails already cover it
            const Vec3 p = track_.terrainPoint(sp, sd * 5.3f);
            chunk.items[kBatchPost].push_back({makeInstance(p, 0.0f, 1.0f, 1.0f, 0.0f, 0.0f, Rgba8{255, 255, 255, 0}), 0.0f});
        }
    }
}

void World::buildScenery(float focusS, const Vec3& origin, const Vec3& camFwd, float density, SceneGeometry& out) {
    const float L = cfg::kChunkLength;
    const int c0 = std::max(0, static_cast<int>(std::floor((focusS - 50.0f) / L)));
    const int c1 = static_cast<int>(std::floor((focusS + cfg::kViewAhead - 24.0f) / L));
    for (int c = c0; c <= c1; ++c) {
        const Chunk& ch = chunkAt(c);
        for (int b = 0; b < kBatchCount; ++b) {
            for (const Placed& p : ch.items[b]) {
                if (p.rank > density) continue;
                Instance in = p.inst;
                in.x -= origin.x; in.y -= origin.y; in.z -= origin.z;
                if (in.x * camFwd.x + in.y * camFwd.y + in.z * camFwd.z < -16.0f) continue;
                out.instances[b].push_back(in);
            }
        }
    }
}

void World::buildObstacles(const Vec3& origin, SceneGeometry& out) const {
    for (const Obstacle& o : obstacles_) {
        const TrackSample f = track_.at(o.s);
        Vec3 p = Track::surfacePoint(f, o.x);
        float yaw = f.heading + o.yaw;
        float pitch = 0.0f;
        float spin = 0.0f;
        switch (o.kind) {
            case ObstacleKind::Cone: {
                if (o.hit) {
                    const float t = o.hitTime;
                    const float dy = std::max(0.0f, 3.6f * t - 4.9f * t * t);
                    p += f.right0 * (o.knockDir * 3.2f * t) + f.fwd * (4.0f * t) + Vec3(0.0f, dy, 0.0f);
                    spin = t * 9.0f;
                }
                const Vec3 q = p - origin;
                Instance in = makeInstance(q, yaw + spin, 1.0f, 1.0f, 0.0f, spin * 0.5f, Rgba8{255, 255, 255, 0});
                out.instances[kBatchCone].push_back(in);
                break;
            }
            case ObstacleKind::Rock: {
                const Vec3 q = p - origin - Vec3(0.0f, 0.15f * o.scale, 0.0f);
                out.instances[kBatchRock].push_back(makeInstance(q, yaw, o.scale, o.scale * 0.9f, 0.0f, 0.0f, withAlpha(o.tint, 0.0f)));
                break;
            }
            case ObstacleKind::Car: {
                pitch = o.vel < 0.0f ? -f.pitch : f.pitch;
                const Vec3 q = p - origin;
                out.instances[kBatchCar].push_back(makeInstance(q, yaw, 1.0f, 1.0f, 0.0f, pitch, withAlpha(o.tint, 0.0f)));
                break;
            }
        }
    }
}

void World::buildStartGate(float focusS, const Vec3& origin, SceneGeometry& out) const {
    if (focusS > 150.0f) return;
    const TrackSample f = track_.at(14.0f);
    const Vec3 bz = cross(f.right0, f.up0);
    auto frame = [&](const Vec3& worldPos) { return Mat4::fromBasis(f.right0, f.up0, bz, worldPos - origin); };
    const Rgba8 steel = rgba(0.78f, 0.78f, 0.8f);
    const Rgba8 orange = rgba(1.0f, 0.42f, 0.10f);
    for (int sgn = -1; sgn <= 1; sgn += 2) {
        const Vec3 base = Track::surfacePoint(f, 4.7f * static_cast<float>(sgn));
        MeshData& m = out.dynamicMesh;
        m.addBox(frame(base + f.up0 * 2.7f), Vec3(0.17f, 2.7f, 0.17f), steel, Material{});
        m.addBox(frame(base + f.up0 * 0.2f), Vec3(0.34f, 0.2f, 0.34f), rgba(0.3f, 0.3f, 0.32f), Material{});
    }
    const Vec3 mid = Track::surfacePoint(f, 0.0f, 5.2f);
    out.dynamicMesh.addBox(frame(mid), Vec3(4.85f, 0.5f, 0.14f), orange, Material{0, 70, 0, 0});
    const int n = 22;
    for (int i = 0; i < n; ++i) {
        const float lx = -4.4f + 8.8f * (static_cast<float>(i) + 0.5f) / static_cast<float>(n);
        for (int row = 0; row < 2; ++row) {
            const bool white = ((i + row) & 1) == 0;
            const Vec3 pos = mid + f.right0 * lx + f.up0 * (0.18f - 0.2f * static_cast<float>(row));
            out.dynamicMesh.addBox(frame(pos), Vec3(0.2f, 0.1f, 0.16f), white ? rgba(0.95f, 0.95f, 0.95f) : rgba(0.06f, 0.06f, 0.07f), Material{});
        }
    }
}

// --------------------------------------------------------------------------------------
// Terrain mesh
// --------------------------------------------------------------------------------------

void World::buildTerrain(float focusS, const Vec3& origin, SceneGeometry& out) const {
    constexpr int cols = cfg::kTerrainCols;
    constexpr int rings = cfg::kTerrainRings;
    int i0 = static_cast<int>(std::floor((focusS - cfg::kViewBehind) / cfg::kTrackStep));
    i0 = std::max(i0, 1);
    const int maxStart = track_.sampleCount() - rings - 2;
    if (maxStart < 1) {
        out.terrain.clear();
        return;
    }
    i0 = std::min(i0, maxStart);

    scratch_.resize(static_cast<size_t>(rings + 2) * cols);
    for (int r = 0; r < rings + 2; ++r) {
        for (int j = 0; j < cols; ++j) scratch_[static_cast<size_t>(r) * cols + static_cast<size_t>(j)] = track_.ringVertex(i0 - 1 + r, j);
    }
    out.terrain.resize(static_cast<size_t>(rings) * cols);
    for (int r = 0; r < rings; ++r) {
        const TrackSample& f = track_.sampleAt(i0 + r);
        for (int j = 0; j < cols; ++j) {
            const size_t center = static_cast<size_t>(r + 1) * cols + static_cast<size_t>(j);
            const Vec3 ds = scratch_[center + cols] - scratch_[center - cols];
            const Vec3 dd = scratch_[static_cast<size_t>(r + 1) * cols + static_cast<size_t>(std::min(j + 1, cols - 1))] -
                            scratch_[static_cast<size_t>(r + 1) * cols + static_cast<size_t>(std::max(j - 1, 0))];
            Vec3 n = normalize(cross(dd, ds));
            if (n.y < 0.0f) n = -n;
            const Vec3 p = scratch_[center] - origin;
            TerrainVertex& v = out.terrain[static_cast<size_t>(r) * cols + static_cast<size_t>(j)];
            v.px = p.x; v.py = p.y; v.pz = p.z;
            v.nx = n.x; v.ny = n.y; v.nz = n.z;
            v.d = cfg::kTerrainOffsets[j];
            v.s = f.s;
            v.edge = std::fabs(cfg::kTerrainOffsets[j]) / cfg::kTerrainMaxOffset;
        }
    }
}

}  // namespace sd
