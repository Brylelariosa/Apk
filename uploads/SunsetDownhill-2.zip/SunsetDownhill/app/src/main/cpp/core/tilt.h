// tilt.h - steering by tilting the phone like a steering wheel.
// The Kotlin shell only forwards the gravity direction; all of the maths (smoothing, neutral, dead zone,
// sensitivity) lives here so it behaves the same everywhere and can be tested on a desktop.
#pragma once

#include <atomic>

namespace sd {

class TiltSteer {
public:
    static constexpr float kFullLockDeg = 25.0f;   // tilt that gives full steering at sensitivity 1

    // ---- any thread (the sensor callback)
    // Direction of "up" in the screen plane in m/s^2: x to the right, y up. It is (0, +9.8) with the phone held
    // upright in landscape, and turning the phone clockwise like a wheel makes x negative.
    void setGravity(float x, float y) {
        gx_.store(x, std::memory_order_relaxed);
        gy_.store(y, std::memory_order_relaxed);
    }
    void setAvailable(bool a) { available_.store(a); }
    bool available() const { return available_.load(); }

    // ---- game thread
    // `calibrating`: let the neutral position follow the player's grip (used during the countdown).
    void update(float dt, bool calibrating);
    void recenter() { recenter_ = true; }   // take the current tilt as "straight ahead"
    float steer(float sensitivity) const;   // -1 (left) .. +1 (right)
    float angleDeg() const;                 // tilt relative to neutral in degrees, + = clockwise

private:
    std::atomic<float> gx_{0.0f}, gy_{9.81f};
    std::atomic<bool> available_{false};
    float fx_ = 0.0f, fy_ = 9.81f;   // smoothed gravity vector
    float roll_ = 0.0f;              // radians, + = clockwise
    float neutral_ = 0.0f;
    bool haveReading_ = false, recenter_ = false;
};

}  // namespace sd
