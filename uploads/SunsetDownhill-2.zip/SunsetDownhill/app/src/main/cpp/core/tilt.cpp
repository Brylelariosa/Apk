#include "tilt.h"

#include <algorithm>
#include <cmath>

#include "math3d.h"

namespace sd {
namespace {

constexpr float kMinPlaneG = 3.0f;     // below this the phone is lying flat and its roll is meaningless
constexpr float kFilterRate = 16.0f;   // 1/s: takes the sensor noise and hand tremor out (~60 ms)
constexpr float kCalibRate = 8.0f;     // 1/s: how fast the neutral follows the grip while calibrating
constexpr float kDeadZone = 0.06f;     // share of full lock that does nothing at all

float wrapAngle(float a) { return a - kTwoPi * std::floor(a / kTwoPi + 0.5f); }

}  // namespace

void TiltSteer::update(float dt, bool calibrating) {
    const float x = gx_.load(std::memory_order_relaxed);
    const float y = gy_.load(std::memory_order_relaxed);
    if (std::isfinite(x) && std::isfinite(y) && x * x + y * y > kMinPlaneG * kMinPlaneG) {
        if (!haveReading_) {
            fx_ = x;
            fy_ = y;
            haveReading_ = true;
        } else {
            const float a = smoothing(kFilterRate, dt);
            fx_ += (x - fx_) * a;
            fy_ += (y - fy_) * a;
        }
        roll_ = std::atan2(-fx_, fy_);
    }
    if (calibrating && haveReading_) neutral_ += wrapAngle(roll_ - neutral_) * smoothing(kCalibRate, dt);
    if (recenter_ && haveReading_) {
        neutral_ = roll_;
        recenter_ = false;
    }
}

float TiltSteer::angleDeg() const {
    if (!available_.load() || !haveReading_) return 0.0f;
    return wrapAngle(roll_ - neutral_) / kDeg2Rad;
}

float TiltSteer::steer(float sensitivity) const {
    if (!available_.load() || !haveReading_) return 0.0f;
    const float lock = kFullLockDeg * kDeg2Rad / std::max(0.1f, sensitivity);
    const float v = clampf(wrapAngle(roll_ - neutral_) / lock, -1.0f, 1.0f);
    const float mag = std::max(0.0f, (std::fabs(v) - kDeadZone) / (1.0f - kDeadZone));
    return sign1(v) * std::pow(mag, 1.2f);
}

}  // namespace sd
