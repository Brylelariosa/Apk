#include "input.h"

#include <cmath>

namespace sd {
namespace {

// Arrow buttons ease the steering in (a tap is a nudge, a hold turns hard) and let go a little faster. The rider's own
// steering response (config.h) comes on top of this.
constexpr float kArrowRise = 6.0f;    // 1/s
constexpr float kArrowFall = 10.0f;   // 1/s (also used when switching straight from one arrow to the other)

}  // namespace

int TouchController::find(int id) const {
    for (int i = 0; i < kMaxPointers; ++i)
        if (ptr_[i].active && ptr_[i].id == id) return i;
    return -1;
}

int TouchController::allocate(int id) {
    for (int i = 0; i < kMaxPointers; ++i) {
        if (!ptr_[i].active) {
            ptr_[i].active = true;
            ptr_[i].id = id;
            ptr_[i].role = Role::None;
            return i;
        }
    }
    return -1;
}

bool TouchController::held(Role r) const {
    for (const Pointer& p : ptr_)
        if (p.active && p.role == r) return true;
    return false;
}

void TouchController::releaseAll() {
    for (Pointer& p : ptr_) p = Pointer();
    steerPtr_ = -1;
    steer_ = 0.0f;
    arrow_ = 0.0f;
}

// The control button under (x, y), if any. When touch circles overlap the button whose centre is relatively
// closest wins, so a big button never swallows a small neighbour.
TouchController::Role TouchController::buttonAt(float x, float y) const {
    static const Role kRoles[kButtonCount] = {Role::Tuck, Role::Slide, Role::Left, Role::Right};
    int best = -1;
    float bestScore = 1e30f;
    for (int i = 0; i < kButtonCount; ++i) {
        if (isArrowButton(static_cast<ButtonId>(i)) && !usesArrows(mode_)) continue;
        const float dx = x - layout_.btnC[i].x, dy = y - layout_.btnC[i].y;
        const float lim = layout_.btnHit[i];
        const float score = (dx * dx + dy * dy) / (lim * lim);
        if (score <= 1.0f && score < bestScore) {
            bestScore = score;
            best = i;
        }
    }
    return best < 0 ? Role::None : kRoles[best];
}

void TouchController::updateSteer(float x) {
    const float range = layout_.stickRange;
    float dx = x - stickOrigin_.x;
    if (std::fabs(dx) > range) {            // drag the origin along so reversing direction is immediate
        stickOrigin_.x = x - sign1(dx) * range;
        dx = sign1(dx) * range;
    }
    stickKnob_ = Vec2(stickOrigin_.x + dx, stickOrigin_.y);
    float v = clampf(dx / range, -1.0f, 1.0f);
    const float mag = std::max(0.0f, (std::fabs(v) - 0.06f) / 0.94f);
    steer_ = sign1(v) * std::pow(mag, 1.25f);
}

void TouchController::onTouch(int action, int id, float x, float y) {
    if (action == kTouchCancel) {
        releaseAll();
        return;
    }
    if (action == kTouchDown) {
        const int slot = allocate(id);
        if (slot < 0) return;
        Pointer& p = ptr_[slot];
        if (!gameplay_) {
            p.role = Role::Tap;
            if (tapCount_ < 8) taps_[tapCount_++] = Vec2(x, y);
            return;
        }
        const Role button = buttonAt(x, y);
        if (button != Role::None) {
            p.role = button;
        } else if (usesStick(mode_) && x < layout_.steerZoneRight && steerPtr_ < 0 && y > layout_.margin) {
            p.role = Role::Steer;
            steerPtr_ = slot;
            stickOrigin_ = Vec2(x, y);
            stickKnob_ = stickOrigin_;
            steer_ = 0.0f;
        } else {
            p.role = Role::Tap;
            if (tapCount_ < 8) taps_[tapCount_++] = Vec2(x, y);
        }
        return;
    }
    const int slot = find(id);
    if (slot < 0) return;
    if (action == kTouchMove) {
        if (slot == steerPtr_) {
            updateSteer(x);
        } else if (ptr_[slot].role == Role::Left || ptr_[slot].role == Role::Right) {
            // rolling the thumb from one arrow onto the other switches direction; sliding off both keeps the last one
            const Role b = buttonAt(x, y);
            if (b == Role::Left || b == Role::Right) ptr_[slot].role = b;
        }
    } else if (action == kTouchUp) {
        if (slot == steerPtr_) {
            steerPtr_ = -1;
            steer_ = 0.0f;
        }
        ptr_[slot] = Pointer();
    }
}

void TouchController::update(float dt) {
    const float target = (held(Role::Right) ? 1.0f : 0.0f) - (held(Role::Left) ? 1.0f : 0.0f);
    const bool reversing = target * arrow_ < 0.0f;
    const float rate = (target == 0.0f || reversing) ? kArrowFall : kArrowRise;
    arrow_ += (target - arrow_) * smoothing(rate, dt);
    if (target == 0.0f && std::fabs(arrow_) < 0.002f) arrow_ = 0.0f;
}

SkaterInput TouchController::input() const {
    SkaterInput in;
    const float stick = steerPtr_ >= 0 ? steer_ : 0.0f;
    in.steer = clampf(stick + arrow_, -1.0f, 1.0f);
    in.tuck = held(Role::Tuck);
    in.slide = held(Role::Slide);
    return in;
}

bool TouchController::popTap(Vec2& out) {
    if (tapCount_ == 0) return false;
    out = taps_[0];
    for (int i = 1; i < tapCount_; ++i) taps_[i - 1] = taps_[i];
    --tapCount_;
    return true;
}

}  // namespace sd
