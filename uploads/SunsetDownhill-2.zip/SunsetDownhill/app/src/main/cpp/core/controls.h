// controls.h - everything the player uses to control the rider, behind one small interface for the Engine:
// the saved configuration, the touch screen (stick / arrows / TUCK / SLIDE), phone tilt and the CONTROLS screen.
// Platform independent and free of OpenGL, so the whole input path can be tested on a desktop.
#pragma once

#include "controls_config.h"
#include "controls_editor.h"
#include "input.h"
#include "tilt.h"
#include "ui_batch.h"
#include "ui_layout.h"

namespace sd {

class Controls {
public:
    Controls();

    // ---- configuration (GL thread, or before the first frame)
    void setConfig(const ControlsConfig& cfg);   // sanitises; does not count as a change to persist
    const ControlsConfig& config() const { return cfg_; }
    SteerMode mode() const { return effectiveMode(cfg_.mode, tilt_.available()); }   // what is really in use
    bool takeChanged();                          // true once after the player changed the configuration

    // ---- screen
    void setScreen(float w, float h);
    const UiLayout& layout() const { return layout_; }

    // ---- sensor (any thread)
    void setTiltGravity(float x, float y) { tilt_.setGravity(x, y); }
    void setTiltAvailable(bool a) { tilt_.setAvailable(a); }

    // ---- per frame (GL thread)
    void onTouch(int action, int id, float x, float y);
    // `countdown`: the tilt neutral follows the player's grip. `running`: touches are gameplay controls.
    void update(float dt, bool countdown, bool running);
    bool popTap(Vec2& out) { return touch_.popTap(out); }
    SkaterInput skaterInput() const;   // touch + tilt, ready for the physics
    void releaseAll() { touch_.releaseAll(); }

    // ---- the CONTROLS screen
    void openEditor();
    void closeEditor();
    bool editorOpen() const { return editor_.isOpen(); }
    void drawEditor(UiBatch& ui) const;

    // ---- state the HUD draws
    bool steerActive() const { return touch_.steerActive(); }
    Vec2 stickOrigin() const { return touch_.stickOrigin(); }
    Vec2 stickKnob() const { return touch_.stickKnob(); }
    bool tuckDown() const { return touch_.tuckDown(); }
    bool slideDown() const { return touch_.slideDown(); }
    bool leftDown() const { return touch_.leftDown(); }
    bool rightDown() const { return touch_.rightDown(); }
    float tiltSteer() const;   // what the tilt is steering right now (-1..1); 0 when tilt is not in use
    float opacity() const { return cfg_.opacity; }

private:
    void rebuildLayout();
    void flush();   // a finished edit becomes a change to persist

    ControlsConfig cfg_;
    UiLayout layout_;
    TouchController touch_;
    TiltSteer tilt_;
    ControlsEditor editor_;
    float w_ = 1920.0f, h_ = 1080.0f;
    bool dirty_ = false;     // edited, finger still down
    bool changed_ = false;   // edited and finished: waiting to be persisted
};

}  // namespace sd
