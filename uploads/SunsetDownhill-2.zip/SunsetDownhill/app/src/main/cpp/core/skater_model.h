// skater_model.h - procedural blocky rider + longboard built from boxes each frame.
#pragma once

#include "math3d.h"
#include "mesh_data.h"

namespace sd {

struct SkaterPose {
    Vec3 origin;            // board centre on the road surface
    Vec3 right, up, fwd;    // board basis (orthonormal)
    Vec3 roadUp = Vec3(0.0f, 1.0f, 0.0f);   // road surface normal (hands and feet are planted on this plane)
    float tuck = 0.0f;      // 0..1 crouch
    float lean = 0.0f;      // rider lean into the turn (rad, + right)
    float slide = 0.0f;     // 0..1 Coleman slide (deep crouch, hand on the road)
    float slideDir = 1.0f;  // side of the slide (+1 right, -1 left)
    float slip = 0.0f;      // board angle to the travel direction (rad, + = nose to the right)
    float push = 0.0f;      // 0..1 kick-push pose weight
    float pushPhase = 0.0f; // kick cycles since the first kick (0 = foot planted, ready to drive)
    float time = 0.0f;
    bool crashed = false;
    float crashTime = 0.0f;
    float crashSpeed = 0.0f;
};

void buildSkaterMesh(const SkaterPose& pose, MeshData& out);

}  // namespace sd
