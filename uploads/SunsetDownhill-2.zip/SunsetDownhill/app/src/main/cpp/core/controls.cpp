#include "controls.h"

namespace sd {

Controls::Controls() {
    rebuildLayout();
}

void Controls::setConfig(const ControlsConfig& cfg) {
    cfg_ = cfg;
    cfg_.sanitize();
    dirty_ = changed_ = false;
    rebuildLayout();
}

bool Controls::takeChanged() {
    const bool c = changed_;
    changed_ = false;
    return c;
}

void Controls::setScreen(float w, float h) {
    w_ = w;
    h_ = h;
    rebuildLayout();
}

void Controls::rebuildLayout() {
    layout_ = UiLayout::make(w_, h_, cfg_);
    touch_.setLayout(layout_);
}

void Controls::flush() {
    if (dirty_) {
        dirty_ = false;
        changed_ = true;
    }
}

void Controls::onTouch(int action, int id, float x, float y) {
    if (!editor_.isOpen()) {
        touch_.onTouch(action, id, x, y);
        return;
    }
    const ControlsEditor::Result r = editor_.onTouch(action, id, x, y, cfg_, layout_, tilt_.available());
    if (r.changed) {
        rebuildLayout();
        dirty_ = true;
    }
    if (r.recenter) tilt_.recenter();
    if (r.done) editor_.close();
    if (action == kTouchUp || action == kTouchCancel) flush();   // persist when the finger lifts, not on every drag step
}

void Controls::update(float dt, bool countdown, bool running) {
    if (editor_.isOpen() && editor_.update(dt, cfg_, layout_, tilt_.available())) {
        rebuildLayout();
        dirty_ = true;
    }
    touch_.setMode(mode());
    touch_.setGameplay(running && !editor_.isOpen());
    touch_.update(dt);
    tilt_.update(dt, countdown);
}

SkaterInput Controls::skaterInput() const {
    SkaterInput in = touch_.input();
    if (usesTilt(mode())) in.steer = clampf(in.steer + tilt_.steer(cfg_.tiltSensitivity), -1.0f, 1.0f);
    return in;
}

float Controls::tiltSteer() const {
    return usesTilt(mode()) ? tilt_.steer(cfg_.tiltSensitivity) : 0.0f;
}

void Controls::openEditor() {
    touch_.releaseAll();
    touch_.clearTaps();
    editor_.open();
}

void Controls::closeEditor() {
    editor_.close();
    flush();
}

void Controls::drawEditor(UiBatch& ui) const {
    ControlsEditor::View v;
    v.tiltAvailable = tilt_.available();
    v.tilt = tilt_.steer(cfg_.tiltSensitivity);
    editor_.draw(ui, layout_, cfg_, v);
}

}  // namespace sd
