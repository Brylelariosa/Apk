// skater.h - downhill longboard physics in road space (Frenet frame).
#pragma once

#include "math3d.h"
#include "track.h"

namespace sd {

struct SkaterInput {
    float steer = 0.0f;   // -1 (left) .. +1 (right)
    bool tuck = false;
    bool slide = false;
};

enum class SkaterEvent : uint8_t { None = 0, Scrape, Crash };
enum class CrashCause : uint8_t { None = 0, Rail, Obstacle, Stall };

struct Skater {
    // kinematics in road space
    float s = 0.0f;       // distance along the road
    float x = 0.0f;       // lateral offset (+ right)
    float alpha = 0.0f;   // travel heading relative to the road tangent
    float speed = 0.0f;   // m/s

    // smoothed controls
    float steer = 0.0f, tuck = 0.0f, slide = 0.0f;

    // visual state
    float yawVis = 0.0f;      // board angle to the travel direction while sliding (+ = nose to the right)
    float yawVel = 0.0f;      // (spring state for yawVis)
    float lean = 0.0f;        // roll toward the turn
    float slideDir = 1.0f;    // side the Coleman slide is kicked out to
    float pushPhase = 0.0f;   // kick cycles since the push began (0 .. cfg::kPushStrokes)
    float pushAmount = 0.0f;  // 0..1 weight of the kick-push pose
    int pushSteps = 0;        // counts kicks (foot plants) - drives the push sound
    int pushLands = 0;        // counts "foot back on the deck" - drives the landing sound
    float scrape = 0.0f;      // recent rail contact intensity (0..1)
    float railTime = 0.0f;    // accumulated rail contact (decays after a clear spell)
    float railClear = 0.0f;   // time since the last rail contact
    float stallTime = 0.0f;   // time spent (almost) stopped

    // status
    bool crashed = false;
    CrashCause crashCause = CrashCause::None;
    float crashTime = 0.0f;
    float crashSpeed = 0.0f;
    bool onShoulder = false;
    float pushTimer = 0.0f;
    float distance = 0.0f;
    float topSpeed = 0.0f;

    void reset(float s0, float speed0 = 0.0f);
    void startPush();
    SkaterEvent step(const SkaterInput& in, const Track& track, float dt);
    void crash(CrashCause cause);
    float speedKmh() const { return speed * 3.6f; }
    // lateral acceleration capacity at the current state (m/s^2)
    float gripNow() const;
};

}  // namespace sd
