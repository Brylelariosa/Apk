#include "skater_model.h"

#include <algorithm>
#include <cmath>

#include "config.h"

namespace sd {
namespace {

// Palette
const Rgba8 kHoodieLo = rgba(0.07f, 0.07f, 0.09f), kHoodieHi = rgba(0.15f, 0.15f, 0.19f);
const Rgba8 kPants = rgba(0.11f, 0.15f, 0.27f);
const Rgba8 kShoe = rgba(0.92f, 0.92f, 0.94f), kSole = rgba(0.12f, 0.12f, 0.14f);
const Rgba8 kSkin = rgba(0.88f, 0.66f, 0.52f);
const Rgba8 kHelmet = rgba(0.96f, 0.96f, 0.98f), kHelmetStripe = rgba(1.0f, 0.42f, 0.12f);
const Rgba8 kDeck = rgba(1.0f, 0.46f, 0.12f), kGrip = rgba(0.05f, 0.05f, 0.06f);
const Rgba8 kWheel = rgba(0.25f, 0.95f, 1.0f), kTruck = rgba(0.62f, 0.64f, 0.68f);

struct Rig {
    const SkaterPose& p;
    MeshData& out;
    Vec3 o, r, u, f;

    Vec3 W(float x, float y, float z) const { return o + r * x + u * y + f * z; }

    // Box between two points (long axis A->B).
    void limb(const Vec3& a, const Vec3& b, float hw, float hd, Rgba8 c0, Rgba8 c1, const Vec3& hint) const {
        const Vec3 d = b - a;
        const float len = length(d);
        if (len < 1e-4f) return;
        const Basis ba = basisFromY(d, hint);
        out.addBox(Mat4::fromBasis(ba.x, ba.y, ba.z, (a + b) * 0.5f), Vec3(hw, len * 0.5f, hd), c0, c1);
    }
    void box(const Vec3& centre, const Vec3& axisX, const Vec3& axisY, const Vec3& axisZ, const Vec3& half, Rgba8 c0,
             Rgba8 c1, Material m = {}) const {
        out.addBox(Mat4::fromBasis(axisX, axisY, axisZ, centre), half, c0, c1, m);
    }
};

Vec3 solveJoint(const Vec3& root, const Vec3& target, float l1, float l2, const Vec3& pole, Vec3& endOut) {
    const Vec3 d = target - root;
    float dist = length(d);
    const float maxD = (l1 + l2) * 0.998f, minD = std::fabs(l1 - l2) * 1.002f + 0.01f;
    dist = clampf(dist, minD, maxD);
    const Vec3 dir = dist > 1e-5f ? normalize(d) : Vec3(0.0f, -1.0f, 0.0f);
    endOut = root + dir * dist;
    const float a = (l1 * l1 - l2 * l2 + dist * dist) / (2.0f * dist);
    const float h = std::sqrt(std::max(0.0f, l1 * l1 - a * a));
    Vec3 pv = pole - dir * dot(pole, dir);
    if (dot(pv, pv) < 1e-6f) pv = Vec3(0.0f, 0.0f, 1.0f) - dir * dot(Vec3(0.0f, 0.0f, 1.0f), dir);
    return root + dir * a + normalize(pv) * h;
}

void buildBoard(const Rig& g, float spin, const Vec3& offset, float hop) {
    // Optionally detached board (crash): rotate its basis around the up vector by `spin`.
    const Vec3 o = g.o + offset + g.u * hop;
    const Vec3 f = rotateAround(g.f, g.u, spin), r = rotateAround(g.r, g.u, spin), u = g.u;
    auto Wb = [&](float x, float y, float z) { return o + r * x + u * y + f * z; };
    const Basis bx{r, u, f};
    g.box(Wb(0.0f, 0.105f, 0.0f), bx.x, bx.y, bx.z, Vec3(0.125f, 0.013f, 0.52f), kDeck, kDeck);
    g.box(Wb(0.0f, 0.122f, 0.0f), bx.x, bx.y, bx.z, Vec3(0.105f, 0.004f, 0.46f), kGrip, kGrip);
    g.box(Wb(0.0f, 0.121f, 0.54f), bx.x, bx.y, bx.z, Vec3(0.125f, 0.01f, 0.04f), kDeck, kDeck);  // tail kick
    g.box(Wb(0.0f, 0.121f, -0.54f), bx.x, bx.y, bx.z, Vec3(0.125f, 0.01f, 0.04f), kDeck, kDeck);
    for (int i = 0; i < 2; ++i) {
        const float z = i == 0 ? 0.31f : -0.31f;
        g.box(Wb(0.0f, 0.07f, z), bx.x, bx.y, bx.z, Vec3(0.135f, 0.014f, 0.014f), kTruck, kTruck);
        g.box(Wb(0.0f, 0.09f, z), bx.x, bx.y, bx.z, Vec3(0.05f, 0.022f, 0.05f), kTruck, kTruck);
        for (int s = -1; s <= 1; s += 2) {
            const Vec3 c = Wb(0.135f * static_cast<float>(s), 0.048f, z);
            const Basis cb = basisFromY(r, u);
            g.out.addFrustum(Mat4::fromBasis(cb.x, cb.y, cb.z, c - r * 0.026f), 0.048f, 0.048f, 0.052f, 8, kWheel, kWheel,
                             Material{0, 170, 0, 0}, 0.0f, true, true);
        }
    }
}

// Rider on the board. Three poses are blended by weight:
//   riding stance (stand <-> tuck), kick-push (foot plants, drives back, swings forward) and Coleman slide
//   (board kicked out sideways, deep crouch, inside hand on the road, free arm out for balance).
void buildStanding(const Rig& g, const SkaterPose& p) {
    const float t = p.tuck;
    const float L = p.lean;
    const float sd = p.slideDir;
    const float pw = saturate(p.push);
    const float cw = saturate(p.slide) * (1.0f - pw);
    const Vec3 roadUp = normalize(p.roadUp);
    auto mixv = [](const Vec3& a, const Vec3& b, float k) { return a + (b - a) * k; };
    // point `pt` moved along the road normal so that it sits `h` above the road surface
    auto onRoad = [&](const Vec3& pt, float h) { return pt - roadUp * (dot(pt - g.o, roadUp) - h); };

    // axes aligned with the travel direction: the rider keeps looking where the road goes while the board kicks out
    const float cs = std::cos(p.slip), sn = std::sin(p.slip);
    const Vec3 fT = g.f * cs - g.r * sn;
    const Vec3 rT = g.r * cs + g.f * sn;

    // ---- riding stance
    Vec3 ankleL = g.W(0.0f, 0.15f, 0.20f);    // left leg = front foot
    Vec3 ankleR = g.W(0.0f, 0.15f, -0.20f);   // right leg = back (kicking) foot
    const float hipY = lerpf(0.78f, 0.48f, t);
    Vec3 hip = g.W(L * 0.10f, hipY, lerpf(0.0f, -0.03f, t));
    const float twist = lerpf(0.40f, 0.95f, t);
    Vec3 facing = normalize(g.r * std::cos(twist) + g.f * std::sin(twist));
    const float pitchT = lerpf(0.12f, 1.02f, t);
    Vec3 td = normalize(g.u * std::cos(pitchT) + facing * std::sin(pitchT) + g.r * (L * 0.30f));
    float toeL = 0.0f, toeR = 0.0f;           // shoe yaw: 0 = across the board, pi/2 = pointing at the nose
    Vec3 headFace = g.f;
    float armSwing = 0.0f;                    // kick-push arm swing, +1 = left arm forward

    // ---- kick-push
    if (pw > 0.001f) {
        const float N = static_cast<float>(cfg::kPushStrokes);
        const float cyc = std::min(p.pushPhase, N);
        const float u = cyc - std::floor(cyc);
        const float c = cfg::kPushContact;
        float fx, fy, fz, kp;   // kicking foot (board space x right / z forward, height above the road) and kick progress 0..1
        if (u < c) {            // drive: the foot is on the road and slides back past the board
            const float s = u / c;
            fz = lerpf(0.10f, -0.50f, s);
            fx = lerpf(0.34f, 0.25f, s);
            fy = lerpf(0.050f, 0.090f, s * s);   // heel comes up at the end of the drive
            kp = s;
        } else {                // recovery: lift the foot and swing it forward to the next plant
            const float s = (u - c) / (1.0f - c);
            const float e = s * s * (3.0f - 2.0f * s);
            fz = lerpf(-0.50f, 0.10f, e);
            fx = lerpf(0.25f, 0.34f, e) + 0.03f * std::sin(kPi * s);
            fy = lerpf(0.090f, 0.050f, s) + 0.17f * std::sin(kPi * s);
            kp = 1.0f - e;
        }
        Vec3 kick = onRoad(g.o + g.r * fx + g.f * fz, fy);
        // the last recovery brings the foot back onto the deck instead of planting again
        const float landing = smoothstep(N - 0.55f, N, cyc);
        kick = mixv(kick, g.W(0.0f, 0.15f, -0.20f), landing);
        const float lunge = kp * (1.0f - landing);

        const Vec3 hipP = g.W(0.08f, 0.64f - 0.03f * lunge, lerpf(-0.04f, 0.05f, lunge));
        const Vec3 facingP = normalize(g.r * std::cos(1.0f) + g.f * std::sin(1.0f));
        const float pitchP = 0.36f + 0.12f * lunge;
        const Vec3 tdP = normalize(g.u * std::cos(pitchP) + facingP * std::sin(pitchP));
        ankleR = mixv(ankleR, kick, pw);
        hip = mixv(hip, hipP, pw);
        facing = normalize(mixv(facing, facingP, pw));
        td = normalize(mixv(td, tdP, pw));
        toeL = lerpf(toeL, 0.95f, pw);
        toeR = lerpf(toeR, lerpf(1.30f, 0.0f, landing), pw);
        armSwing = (lunge * 2.0f - 1.0f) * (1.0f - landing) * pw;
    }

    // ---- Coleman slide
    if (cw > 0.001f) {
        const float mag = saturate((std::fabs(p.slip) - 0.80f) / 0.5f);
        const Vec3 hipC = g.o + g.u * 0.38f - g.f * 0.10f + rT * (sd * 0.04f);
        const Vec3 facingC = normalize(fT * 0.85f + rT * (sd * 0.55f));
        const float phi = lerpf(0.85f, 1.10f, mag);
        const Vec3 leanDir = normalize(rT * (sd * 0.9f) + fT * 0.35f);
        const Vec3 tdC = normalize(g.u * std::cos(phi) + leanDir * std::sin(phi));
        // each foot stays on its own side of the board so the legs never cross
        const Vec3 aF = g.W(0.0f, 0.15f, 0.22f), aB = g.W(0.0f, 0.15f, -0.22f);
        const bool frontOnLeft = dot(aF - aB, rT) < 0.0f;
        ankleL = mixv(ankleL, frontOnLeft ? aF : aB, cw);
        ankleR = mixv(ankleR, frontOnLeft ? aB : aF, cw);
        hip = mixv(hip, hipC, cw);
        facing = normalize(mixv(facing, facingC, cw));
        td = normalize(mixv(td, tdC, cw));
        headFace = normalize(mixv(headFace, normalize(fT + rT * (sd * 0.40f)), cw));
    }

    const Vec3 left = normalize(cross(g.u, facing));     // rider's left
    const Vec3 neck = hip + td * 0.50f;

    // ---- legs
    const Vec3 hipL = hip + left * 0.085f, hipR = hip - left * 0.085f;
    Vec3 endL, endR;
    // knees point along the board when riding (unchanged), and along the chest direction while kicking / sliding
    Vec3 poleL = normalize(g.r * 1.0f + g.u * 0.15f + g.f * 0.1f);
    Vec3 poleR = normalize(g.r * 1.0f + g.u * 0.15f - g.f * 0.1f);
    const float wMode = std::max(pw, cw);
    if (wMode > 0.001f) {
        poleL = normalize(mixv(poleL, normalize(facing + g.u * 0.15f + left * 0.10f), wMode));
        poleR = normalize(mixv(poleR, normalize(facing + g.u * 0.15f - left * 0.10f), wMode));
    }
    const Vec3 kneeL = solveJoint(hipL, ankleL, 0.38f, 0.38f, poleL, endL);
    const Vec3 kneeR = solveJoint(hipR, ankleR, 0.38f, 0.38f, poleR, endR);
    g.limb(hipL, kneeL, 0.075f, 0.075f, kPants, kPants, g.r);
    g.limb(kneeL, endL, 0.065f, 0.065f, kPants, kPants, g.r);
    g.limb(hipR, kneeR, 0.075f, 0.075f, kPants, kPants, g.r);
    g.limb(kneeR, endR, 0.065f, 0.065f, kPants, kPants, g.r);
    // shoes: toes along `dir` (yaw measured from "across the board" toward the nose)
    for (int i = 0; i < 2; ++i) {
        const Vec3 a = i == 0 ? endL : endR;
        const float yaw = i == 0 ? toeL : toeR;
        const Vec3 dir = normalize(g.r * std::cos(yaw) + g.f * std::sin(yaw));
        const Vec3 side = cross(g.u, dir);
        g.box(a + g.u * 0.02f + dir * 0.05f, side, g.u, dir, Vec3(0.055f, 0.045f, 0.14f), kShoe, kShoe);
        g.box(a - g.u * 0.03f + dir * 0.05f, side, g.u, dir, Vec3(0.058f, 0.015f, 0.145f), kSole, kSole);
    }

    // ---- pelvis + chest
    const Basis pb = basisFromY(normalize(g.u * 1.0f + td * 0.25f), facing);
    g.box(hip + g.u * 0.02f, pb.x, pb.y, pb.z, Vec3(0.175f, 0.10f, 0.105f), kPants, kHoodieLo);
    const Basis cb = basisFromY(td, facing);
    g.box(hip + td * 0.29f, cb.x, cb.y, cb.z, Vec3(0.205f, 0.265f, 0.115f), kHoodieLo, kHoodieHi);
    // backpack-ish hood bulge on the back
    g.box(hip + td * 0.45f - facing * 0.09f, cb.x, cb.y, cb.z, Vec3(0.13f, 0.09f, 0.05f), kHoodieHi, kHoodieHi);

    // ---- head + helmet (looks along the board, or along the road while sliding)
    const Vec3 headUp = normalize(td + g.u * (1.2f * cw));
    const Vec3 headC = neck + headUp * 0.17f + g.u * 0.03f;
    const Vec3 hf = normalize(headFace - g.u * dot(headFace, g.u));
    const Vec3 hr = cross(hf, g.u);
    g.box(headC, hr, g.u, hf, Vec3(0.150f, 0.140f, 0.160f), kHelmet, kHelmet);
    g.box(headC + g.u * 0.125f, hr, g.u, hf, Vec3(0.022f, 0.028f, 0.165f), kHelmetStripe, kHelmetStripe);
    g.box(headC - g.u * 0.08f + hf * 0.11f, hr, g.u, hf, Vec3(0.125f, 0.045f, 0.055f), kSkin, kSkin);

    // ---- arms: relaxed -> hands behind the back (tuck) -> swinging (kick-push) -> inside hand on the road (Coleman)
    const Vec3 shL = neck + left * 0.235f - td * 0.04f, shR = neck - left * 0.235f - td * 0.04f;
    auto handFor = [&](int side) {
        const float sgn = side == 0 ? 1.0f : -1.0f;
        const Vec3 sh = side == 0 ? shL : shR;
        const float sway = std::sin(p.time * 2.3f + sgn) * 0.04f;
        Vec3 relaxed = sh + left * (sgn * 0.17f) - td * 0.46f + facing * 0.12f + g.r * (L * 0.2f) + g.u * sway;
        // balance arms swing wide when carving
        relaxed += left * (sgn * 0.10f * std::fabs(L) * 2.0f);
        const Vec3 back = hip - facing * 0.17f + left * (sgn * 0.16f) + g.u * 0.06f;
        Vec3 h = relaxed + (back - relaxed) * t;
        if (pw > 0.001f) {
            const float swing = side == 0 ? armSwing : -armSwing;   // opposite arm to the kicking leg swings forward
            h += g.f * (swing * 0.34f) + g.u * (0.10f * pw);
        }
        if (cw > 0.001f) {
            const bool inside = dot(sh - neck, rT * sd) > 0.0f;    // the shoulder on the side we slide toward
            Vec3 target;
            if (inside) {
                // hand flat on the road under the shoulder, as far out as the arm reaches
                const float drop = dot(sh - g.o, roadUp) - 0.05f;
                const float reach = 0.56f;
                const float horiz = std::sqrt(std::max(0.0f, reach * reach - drop * drop));
                const Vec3 outDir = normalize(rT * (sd * 0.85f) - fT * 0.30f);
                target = onRoad(sh + outDir * horiz, 0.05f);
            } else {
                // free arm thrown out behind and up for balance
                target = sh + rT * (-sd * 0.55f) + g.u * 0.12f - fT * 0.30f;
            }
            h += (target - h) * cw;
        }
        return h;
    };
    for (int side = 0; side < 2; ++side) {
        const float sgn = side == 0 ? 1.0f : -1.0f;
        const Vec3 sh = side == 0 ? shL : shR;
        Vec3 hand = handFor(side), end;
        const Vec3 pole = normalize(-td * 0.4f - facing * 0.4f + left * (sgn * 0.5f) - g.u * 0.3f);
        const Vec3 elbow = solveJoint(sh, hand, 0.30f, 0.29f, pole, end);
        g.limb(sh, elbow, 0.062f, 0.062f, kHoodieHi, kHoodieLo, facing);
        g.limb(elbow, end, 0.055f, 0.055f, kHoodieLo, kHoodieLo, facing);
        g.box(end, g.r, g.u, g.f, Vec3(0.05f, 0.05f, 0.05f), kSkin, kSkin);
    }
}

void buildCrashed(const Rig& g, const SkaterPose& p) {
    const float t = p.crashTime;
    const float u1 = saturate(t / 1.4f);
    const float ease = 1.0f - (1.0f - u1) * (1.0f - u1);
    const float phi = ease * (kPi * 0.5f + kTwoPi);            // somersault then land on the back
    const float hopT = saturate(t / 0.95f);
    const float hop = 1.0f * std::sin(hopT * kPi) * (1.0f - u1 * 0.6f);
    const float restY = 0.20f;

    // board flies ahead and spins
    const float ahead = p.crashSpeed * 0.55f * (1.0f - std::exp(-1.4f * t)) / 1.4f;
    buildBoard(g, 7.0f * (1.0f - std::exp(-1.4f * t)), g.f * ahead + g.r * (0.7f * (1.0f - std::exp(-2.0f * t))),
               0.35f * std::sin(saturate(t / 0.8f) * kPi));

    // limp rider rotating around the board-right axis
    const Vec3 axis = g.r;
    auto R = [&](const Vec3& v) { return rotateAround(v, axis, phi); };
    const Vec3 pivot = g.o + g.u * (restY + hop) - g.f * 0.1f;
    const float splay = 0.5f + 0.5f * saturate(t / 0.8f);
    const Vec3 up = R(g.u), fw = R(g.f), rt = g.r;
    auto P = [&](float x, float y, float z) { return pivot + rt * x + up * y + fw * z; };
    const Basis tb{rt, up, fw};
    const float ty = 0.0f;
    // torso, pelvis, head
    g.box(P(0, ty + 0.30f, 0), tb.x, tb.y, tb.z, Vec3(0.205f, 0.265f, 0.115f), kHoodieLo, kHoodieHi);
    g.box(P(0, ty + 0.02f, 0), tb.x, tb.y, tb.z, Vec3(0.175f, 0.10f, 0.105f), kPants, kPants);
    g.box(P(0, ty + 0.71f, 0.02f), tb.x, tb.y, tb.z, Vec3(0.125f, 0.125f, 0.14f), kHelmet, kHelmet);
    // legs and arms (rigid, splayed)
    for (int s = -1; s <= 1; s += 2) {
        const float sg = static_cast<float>(s);
        g.limb(P(0.09f * sg, ty - 0.02f, 0), P(0.16f * sg * splay, ty - 0.42f, 0.05f * sg), 0.075f, 0.075f, kPants, kPants, rt);
        g.limb(P(0.16f * sg * splay, ty - 0.42f, 0.05f * sg), P(0.27f * sg * splay, ty - 0.84f, 0.02f), 0.065f, 0.065f, kPants, kShoe, rt);
        g.limb(P(0.24f * sg, ty + 0.50f, 0), P(0.50f * sg * splay, ty + 0.36f, -0.05f * sg), 0.06f, 0.06f, kHoodieHi, kHoodieLo, fw);
        g.limb(P(0.50f * sg * splay, ty + 0.36f, -0.05f * sg), P(0.76f * sg * splay, ty + 0.22f, -0.12f * sg), 0.052f, 0.052f, kHoodieLo, kSkin, fw);
    }
}

}  // namespace

void buildSkaterMesh(const SkaterPose& pose, MeshData& out) {
    // Build at natural size, then scale up around the board so the rider reads well on a phone screen.
    constexpr float kRiderScale = 1.2f;
    MeshData tmp;
    Rig g{pose, tmp, pose.origin, pose.right, pose.up, pose.fwd};
    if (pose.crashed) {
        buildCrashed(g, pose);
    } else {
        buildBoard(g, 0.0f, Vec3(), 0.0f);
        buildStanding(g, pose);
    }
    const Mat4 xf = Mat4::translation(pose.origin) * Mat4::scaling(Vec3(kRiderScale, kRiderScale, kRiderScale)) *
                    Mat4::translation(-pose.origin);
    out.append(tmp, xf);
}

}  // namespace sd
