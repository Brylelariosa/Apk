#include "ui_widgets.h"

#include <cmath>

namespace sd {
namespace widgets {
namespace {

// Disc, white rim and a thin tinted inner ring: the common body of every round button.
void buttonBody(UiBatch& ui, Vec2 c, float r, bool down, Rgba8 tint, float op) {
    ui.circle(c.x, c.y, r, down ? alpha(tint, 0.55f * op) : alpha(Rgba8{30, 20, 60, 255}, 0.43f * op));
    ui.ring(c.x, c.y, r * 0.92f, r, alpha(kWhite, (down ? 0.9f : 0.45f) * op), 48);
    ui.ring(c.x, c.y, r * 0.70f, r * 0.74f, alpha(tint, (down ? 0.9f : 0.35f) * op), 48);
}

}  // namespace

Rgba8 alpha(Rgba8 c, float a) {
    c.a = to8(a * static_cast<float>(c.a) / 255.0f);
    return c;
}

float text(UiBatch& ui, const char* s, float x, float y, float size, Rgba8 c, TextAlign a) {
    const float o = std::max(1.5f, size * 0.055f);
    Rgba8 sh = kShadow;
    sh.a = to8(static_cast<float>(kShadow.a) / 255.0f * static_cast<float>(c.a) / 255.0f);   // shadow fades with the text
    drawText(ui, s, x + o, y + o, size, sh, a);
    return drawText(ui, s, x, y, size, c, a);
}

float fitSize(const char* s, float size, float maxWidth) {
    const float w = textWidth(s, size);
    return (w > maxWidth && w > 0.0f) ? size * maxWidth / w : size;
}

void arrowHead(UiBatch& ui, float cx, float cy, float s, int dir, Rgba8 c) {
    const float d = static_cast<float>(dir);
    ui.triangle({cx + d * s, cy}, {cx - d * s * 0.7f, cy - s}, {cx - d * s * 0.7f, cy + s}, c);
}

void roundButton(UiBatch& ui, Vec2 c, float r, bool down, const char* label, float labelSize, Rgba8 tint, float opacity) {
    buttonBody(ui, c, r, down, tint, opacity);
    drawText(ui, label, c.x, c.y - labelSize * 0.5f, labelSize, alpha(kWhite, (down ? 1.0f : 0.85f) * opacity), TextAlign::Center);
}

void arrowButton(UiBatch& ui, Vec2 c, float r, int dir, bool down, Rgba8 tint, float opacity) {
    buttonBody(ui, c, r, down, tint, opacity);
    const float s = r * 0.40f;
    arrowHead(ui, c.x - static_cast<float>(dir) * s * 0.15f, c.y, s, dir, alpha(kWhite, (down ? 1.0f : 0.85f) * opacity));   // (the triangle's weight sits toward its base)
}

void controlButton(UiBatch& ui, const UiLayout& L, ButtonId b, bool down, float opacity) {
    const Vec2 c = L.center(b);
    const float r = L.radius(b);
    switch (b) {
        case ButtonId::Tuck: roundButton(ui, c, r, down, "TUCK", r * 0.2833f, kCyan, opacity); break;
        case ButtonId::Slide: roundButton(ui, c, r, down, "SLIDE", r * 0.3261f, kAccent, opacity); break;
        case ButtonId::Left: arrowButton(ui, c, r, -1, down, kGold, opacity); break;
        case ButtonId::Right: arrowButton(ui, c, r, 1, down, kGold, opacity); break;
        default: break;
    }
}

void pill(UiBatch& ui, const Rect& r, const char* label, float labelSize, float opacity, bool accent) {
    ui.roundRect(r.x, r.y, r.w, r.h, r.h * 0.4f, accent ? alpha(kAccent, 0.92f * opacity) : alpha(Rgba8{30, 20, 60, 255}, 0.67f * opacity));
    const float size = fitSize(label, labelSize, r.w * 0.86f);
    drawText(ui, label, r.x + r.w * 0.5f, r.y + r.h * 0.5f - size * 0.5f, size, accent ? kInk : kWhite, TextAlign::Center);
}

void tiltGauge(UiBatch& ui, const UiLayout& L, float steer, float opacity, bool withLabel) {
    const float u = L.u;
    const float w = 360.0f * u, h = 14.0f * u;
    const float cx = L.w * 0.5f, cy = L.h - 0.62f * L.margin - 8.0f * u;
    const float s = clampf(steer, -1.0f, 1.0f);
    ui.roundRect(cx - w * 0.5f, cy - h * 0.5f, w, h, h * 0.5f, alpha(Rgba8{20, 10, 40, 255}, 0.60f * opacity));
    if (std::fabs(s) > 0.01f) {
        const float half = w * 0.5f * std::fabs(s);
        const Rgba8 col = mix(Rgba8{255, 214, 120, 255}, Rgba8{255, 120, 70, 255}, std::fabs(s));
        ui.rect(s < 0.0f ? cx - half : cx, cy - h * 0.5f + 2.0f * u, half, h - 4.0f * u, alpha(col, 0.9f * opacity));
    }
    ui.rect(cx - 1.5f * u, cy - h * 0.9f, 3.0f * u, h * 1.8f, alpha(kWhite, 0.7f * opacity));
    ui.circle(cx + s * w * 0.5f, cy, h * 0.95f, alpha(kWhite, 0.92f * opacity), 24);
    arrowHead(ui, cx - w * 0.5f - 28.0f * u, cy, 11.0f * u, -1, alpha(kWhite, 0.40f * opacity));
    arrowHead(ui, cx + w * 0.5f + 28.0f * u, cy, 11.0f * u, 1, alpha(kWhite, 0.40f * opacity));
    if (withLabel) drawText(ui, "TILT", cx, cy - h - 34.0f * u, 22.0f * u, alpha(kWhite, 0.6f * opacity), TextAlign::Center);
}

}  // namespace widgets
}  // namespace sd
