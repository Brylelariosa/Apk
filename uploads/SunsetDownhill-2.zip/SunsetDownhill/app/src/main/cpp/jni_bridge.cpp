// jni_bridge.cpp - thin JNI layer between the Kotlin shell and the native engine.
#include <jni.h>

#include <memory>
#include <vector>

#include "core/audio_synth.h"
#include "core/engine.h"

namespace {

std::shared_ptr<sd::Engine> g_engine;

std::shared_ptr<sd::Engine> engine() { return std::atomic_load(&g_engine); }

}  // namespace

#define JNI_FN(name) Java_com_sunsetdownhill_game_NativeBridge_##name

extern "C" {

JNIEXPORT void JNICALL JNI_FN(create)(JNIEnv* env, jclass, jint best, jboolean soundOn, jstring controls) {
    auto e = std::make_shared<sd::Engine>();
    e->setSettings(static_cast<int>(best), soundOn == JNI_TRUE);
    if (controls != nullptr) {
        const char* text = env->GetStringUTFChars(controls, nullptr);
        if (text != nullptr) {
            e->setControls(text);
            env->ReleaseStringUTFChars(controls, text);
        }
    }
    std::atomic_store(&g_engine, e);
}

JNIEXPORT void JNICALL JNI_FN(surfaceCreated)(JNIEnv*, jclass) {
    if (auto e = engine()) e->onSurfaceCreated();
}

JNIEXPORT void JNICALL JNI_FN(surfaceChanged)(JNIEnv*, jclass, jint width, jint height) {
    if (auto e = engine()) e->onSurfaceChanged(static_cast<int>(width), static_cast<int>(height));
}

JNIEXPORT void JNICALL JNI_FN(drawFrame)(JNIEnv*, jclass) {
    if (auto e = engine()) e->onDrawFrame();
}

JNIEXPORT void JNICALL JNI_FN(touch)(JNIEnv*, jclass, jint action, jint id, jfloat x, jfloat y) {
    if (auto e = engine()) e->onTouch(static_cast<int>(action), static_cast<int>(id), x, y);
}

JNIEXPORT void JNICALL JNI_FN(pause)(JNIEnv*, jclass) {
    if (auto e = engine()) e->requestPause();
}

JNIEXPORT jboolean JNICALL JNI_FN(back)(JNIEnv*, jclass) {
    auto e = engine();
    return (e && e->requestBack()) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL JNI_FN(setTilt)(JNIEnv*, jclass, jfloat x, jfloat y) {
    if (auto e = engine()) e->setTilt(x, y);
}

JNIEXPORT void JNICALL JNI_FN(setTiltAvailable)(JNIEnv*, jclass, jboolean available) {
    if (auto e = engine()) e->setTiltAvailable(available == JNI_TRUE);
}

JNIEXPORT jint JNICALL JNI_FN(settingsRevision)(JNIEnv*, jclass) {
    auto e = engine();
    return e ? static_cast<jint>(e->settingsRevision()) : 0;
}

JNIEXPORT jstring JNICALL JNI_FN(controlsString)(JNIEnv* env, jclass) {
    auto e = engine();
    return env->NewStringUTF(e ? e->controlsString().c_str() : "");
}

JNIEXPORT jint JNICALL JNI_FN(bestScore)(JNIEnv*, jclass) {
    auto e = engine();
    return e ? static_cast<jint>(e->bestScore()) : 0;
}

JNIEXPORT jboolean JNICALL JNI_FN(soundEnabled)(JNIEnv*, jclass) {
    auto e = engine();
    return (!e || e->soundEnabled()) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL JNI_FN(fillAudio)(JNIEnv* env, jclass, jshortArray buffer, jint frames) {
    static thread_local std::vector<int16_t> scratch;
    const int n = static_cast<int>(frames);
    if (n <= 0) return;
    scratch.resize(static_cast<size_t>(n));
    sd::audioSynth().render(scratch.data(), n);
    env->SetShortArrayRegion(buffer, 0, n, reinterpret_cast<const jshort*>(scratch.data()));
}

}  // extern "C"
