package com.sunsetdownhill.game

import android.app.Activity
import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.view.Surface

/**
 * Feeds the direction of gravity to the engine for tilt steering.
 *
 * The engine does all the maths (smoothing, neutral position, dead zone, sensitivity); this class only turns the
 * sensor's axes, which follow the phone's natural orientation, into screen axes (x right, y up) for whichever way
 * the display is currently turned. Held upright in landscape the engine receives (0, +9.8); turning the phone
 * clockwise like a steering wheel makes x negative.
 */
class TiltSensor(private val activity: Activity) : SensorEventListener {
    private val manager = activity.getSystemService(Context.SENSOR_SERVICE) as? SensorManager

    // TYPE_GRAVITY is already filtered by the system; fall back to the raw accelerometer where it is missing.
    private val sensor: Sensor? =
        manager?.getDefaultSensor(Sensor.TYPE_GRAVITY) ?: manager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

    val available: Boolean get() = sensor != null

    fun start() {
        val s = sensor ?: return
        manager?.registerListener(this, s, SensorManager.SENSOR_DELAY_GAME)
    }

    fun stop() {
        manager?.unregisterListener(this)
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.values.size < 2) return
        val ax = event.values[0]
        val ay = event.values[1]
        when (rotation()) {
            Surface.ROTATION_90 -> NativeBridge.setTilt(-ay, ax)
            Surface.ROTATION_180 -> NativeBridge.setTilt(-ax, -ay)
            Surface.ROTATION_270 -> NativeBridge.setTilt(ay, -ax)
            else -> NativeBridge.setTilt(ax, ay)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    @Suppress("DEPRECATION")
    private fun rotation(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            activity.display?.rotation ?: Surface.ROTATION_0
        } else {
            activity.windowManager.defaultDisplay.rotation
        }
}
