# GameBooster

An Android utility app that applies four performance boosts while a selected game is running.

## What it does

| Boost | API used | Permission required |
|---|---|---|
| CPU full-speed | `PowerManager.PARTIAL_WAKE_LOCK` | `WAKE_LOCK` (install-time) |
| Wi-Fi low latency | `WifiManager.WIFI_MODE_FULL_LOW_LATENCY` | `CHANGE_WIFI_STATE` (install-time) |
| Total silence (DND) | `NotificationManager.setInterruptionFilter` | **User grants** DND policy access |
| Max screen brightness | `Settings.System.SCREEN_BRIGHTNESS = 255` | **User grants** Write Settings |
| Block other apps' network (optional) | `VpnService` tunnel | **User consents** to VPN dialog |

The app polls `UsageStatsManager` every 5 seconds to detect when the game exits and automatically stops boosting (requires **User grants** Usage Access).  All settings are restored on stop.

---

## Requirements

- Android Studio **Hedgehog (2023.1.1)** or newer  
- Android device or emulator running **API 30 (Android 11)** or higher  
- JDK 17 (bundled with recent Android Studio)

---

## Build and run

### Option A — Android Studio (recommended)

1. Open Android Studio → **File › Open** → select the `GameBooster/` folder.
2. Wait for Gradle sync to finish (it downloads dependencies automatically).
3. Connect a physical device (**USB debugging on**) or launch an AVD (API 30+).
4. Click **Run ▶** (or press `Shift+F10`).

### Option B — Command line

```bash
cd GameBooster
# macOS / Linux
./gradlew assembleDebug

# Windows
gradlew.bat assembleDebug
```

The signed APK lands at:
```
app/build/outputs/apk/debug/app-debug.apk
```

Install with:
```bash
adb install app/build/outputs/apk/debug/app-debug.apk
```

---

## First-run permission setup

Three permissions require manual grants in Android Settings.  
The app's **Permissions card** shows their status and opens the correct Settings page when tapped.

| Permission | Path in Settings |
|---|---|
| Usage Access *(required)* | Settings › Apps › Special app access › Usage access → enable GameBooster |
| Do Not Disturb *(optional)* | Settings › Apps › Special app access › Do Not Disturb access → enable GameBooster |
| Modify system settings *(optional)* | Settings › Apps › Special app access › Modify system settings → enable GameBooster |

---

## Project structure

```
GameBooster/
├── app/src/main/
│   ├── AndroidManifest.xml
│   ├── java/com/gamebooster/
│   │   ├── App.java               — creates notification channel
│   │   ├── MainActivity.java      — UI: game picker, permission status, boost button
│   │   ├── BoostService.java      — foreground service: WakeLock, WifiLock, DND, brightness, monitor
│   │   ├── BoostVpnService.java   — optional VPN: drops other apps' traffic
│   │   └── PermissionHelper.java  — checks & intents for the three special permissions
│   └── res/
│       ├── layout/activity_main.xml
│       ├── layout/spinner_item.xml
│       ├── values/strings.xml
│       ├── values/colors.xml
│       ├── values/themes.xml
│       ├── drawable/ic_notification.xml
│       ├── drawable/ic_launcher_foreground.xml
│       └── mipmap-anydpi-v26/ic_launcher*.xml
├── build.gradle
├── settings.gradle
└── gradle/wrapper/gradle-wrapper.properties
```

---

## Notes

- **`QUERY_ALL_PACKAGES`** — lets the spinner list all installed apps.  If distributing via Google Play, replace with a `<queries>` block listing only the game packages you need to enumerate.
- **VPN feature** — the VPN tunnel only drops packets; it does not inspect, log or decrypt any traffic.
- **targetSdk 33** — avoids the mandatory `foregroundServiceType` requirement introduced in API 34, keeping the service declaration minimal.
