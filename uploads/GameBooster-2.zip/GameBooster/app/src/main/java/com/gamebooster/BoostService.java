package com.gamebooster;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.Intent;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.util.Log;

import androidx.core.app.NotificationCompat;

import java.util.List;

/**
 * Foreground service that applies four performance boosts while a game is running:
 *
 *  1. {@code PARTIAL_WAKE_LOCK}         — keeps the CPU running at full speed.
 *  2. {@code WIFI_MODE_FULL_LOW_LATENCY} — disables Wi-Fi power-saving for low latency.
 *  3. {@code INTERRUPTION_FILTER_NONE}  — enables "total silence" DND (if permitted).
 *  4. Screen brightness → 255           — prevents auto-dim (if permitted).
 *
 * The service polls {@link UsageStatsManager} every {@value #MONITOR_INTERVAL_MS} ms.
 * When the target game has not been in the foreground for longer than
 * {@value #GAME_INACTIVE_TIMEOUT_MS} ms, the service stops itself and restores
 * all modified settings.
 *
 * <h3>Lifecycle summary</h3>
 * <pre>
 *   startForegroundService(intent with EXTRA_PACKAGE)
 *     → onCreate()  → startForeground()
 *     → acquireWakeLock / acquireWifiLock
 *     → applyDnd / applyMaxBrightness  (skipped if permissions absent)
 *     → scheduleMonitor()              (polls every 5 s)
 *
 *   Game exits (or user taps "Stop" in notification)
 *     → stopSelf() → onDestroy()
 *     → releaseWakeLock / releaseWifiLock
 *     → restoreDnd / restoreBrightness
 * </pre>
 */
public class BoostService extends Service {

    private static final String TAG = "BoostService";

    /** Intent extra: fully-qualified package name of the game to monitor. */
    public static final String EXTRA_PACKAGE = "extra_package_name";

    /** Action used by the notification "Stop" button. */
    public static final String ACTION_STOP   = "com.gamebooster.action.STOP";

    /** {@code true} while the service is running; read from any thread. */
    public static volatile boolean isRunning  = false;

    // Notification
    private static final int NOTIFICATION_ID = 1001;

    // Monitoring
    private static final long MONITOR_INTERVAL_MS      =  5_000L;   // poll every 5 s
    private static final long GAME_INACTIVE_TIMEOUT_MS = 120_000L;  // stop after 2 min idle
    private static final long USAGE_LOOKBACK_MS        = 600_000L;  // look back 10 min

    // ── Fields ────────────────────────────────────────────────────────────────

    private String                  gamePackage;
    private PowerManager.WakeLock   wakeLock;
    private WifiManager.WifiLock    wifiLock;
    private Handler                 handler;

    // Saved values for clean restoration on stop
    private int     savedDndFilter    = NotificationManager.INTERRUPTION_FILTER_UNKNOWN;
    private boolean dndApplied        = false;
    private int     savedBrightness   = -1;
    private boolean brightnessApplied = false;

    // ── Service lifecycle ─────────────────────────────────────────────────────

    @Override
    public void onCreate() {
        super.onCreate();
        handler   = new Handler(Looper.getMainLooper());
        isRunning = true;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // Handle "Stop" tap from the notification action button
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }

        gamePackage = (intent != null) ? intent.getStringExtra(EXTRA_PACKAGE) : null;

        // Must call startForeground() within ~5 s of startForegroundService() to avoid ANR
        startForeground(NOTIFICATION_ID, buildNotification());

        acquireWakeLock();
        acquireWifiLock();
        applyDnd();
        applyMaxBrightness();

        if (gamePackage != null) {
            handler.postDelayed(monitorRunnable, MONITOR_INTERVAL_MS);
        }

        Log.i(TAG, "Boost started for: " + gamePackage);
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        isRunning = false;
        handler.removeCallbacksAndMessages(null);
        releaseWakeLock();
        releaseWifiLock();
        restoreDnd();
        restoreBrightness();
        Log.i(TAG, "Boost stopped, all settings restored.");
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    // ── Notification ──────────────────────────────────────────────────────────

    private Notification buildNotification() {
        // Tap notification → reopen the main activity
        PendingIntent openApp = PendingIntent.getActivity(
            this, 0,
            new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE
        );

        // "Stop" action button
        Intent stopIntent = new Intent(this, BoostService.class).setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(
            this, 1, stopIntent,
            PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT
        );

        String subtitle = (gamePackage != null)
            ? "Boosting: " + gamePackage
            : "Boost active";

        return new NotificationCompat.Builder(this, App.BOOST_CHANNEL_ID)
            .setContentTitle("GameBooster Active")
            .setContentText(subtitle)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(openApp)
            .addAction(android.R.drawable.ic_media_pause, "Stop", stopPi)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build();
    }

    // ── WakeLock ──────────────────────────────────────────────────────────────

    private void acquireWakeLock() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "GameBooster:boost");
            wakeLock.acquire();
            Log.d(TAG, "WakeLock acquired");
        } catch (Exception e) {
            Log.w(TAG, "WakeLock acquire failed", e);
        }
    }

    private void releaseWakeLock() {
        if (wakeLock != null && wakeLock.isHeld()) {
            wakeLock.release();
            Log.d(TAG, "WakeLock released");
        }
        wakeLock = null;
    }

    // ── WifiLock ──────────────────────────────────────────────────────────────

    /**
     * {@code WIFI_MODE_FULL_LOW_LATENCY} (API 29+): keeps the Wi-Fi chip fully active
     * and disables power-save intervals that normally introduce ~100 ms spikes.
     * Only effective while the screen is on and the app is in the foreground.
     */
    private void acquireWifiLock() {
        try {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
            wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_LOW_LATENCY, "GameBooster:wifi");
            wifiLock.setReferenceCounted(false);
            wifiLock.acquire();
            Log.d(TAG, "WifiLock (LOW_LATENCY) acquired");
        } catch (Exception e) {
            Log.w(TAG, "WifiLock acquire failed", e);
        }
    }

    private void releaseWifiLock() {
        if (wifiLock != null && wifiLock.isHeld()) {
            wifiLock.release();
            Log.d(TAG, "WifiLock released");
        }
        wifiLock = null;
    }

    // ── Do Not Disturb ────────────────────────────────────────────────────────

    private void applyDnd() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (!nm.isNotificationPolicyAccessGranted()) {
            Log.d(TAG, "DND: policy access not granted — skipping");
            return;
        }
        savedDndFilter = nm.getCurrentInterruptionFilter();
        nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_NONE);
        dndApplied = true;
        Log.d(TAG, "DND: total silence applied (saved filter=" + savedDndFilter + ")");
    }

    private void restoreDnd() {
        if (!dndApplied) return;
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm.isNotificationPolicyAccessGranted()
                && savedDndFilter != NotificationManager.INTERRUPTION_FILTER_UNKNOWN) {
            nm.setInterruptionFilter(savedDndFilter);
            Log.d(TAG, "DND: restored to " + savedDndFilter);
        }
        dndApplied = false;
    }

    // ── Screen brightness ─────────────────────────────────────────────────────

    private void applyMaxBrightness() {
        if (!Settings.System.canWrite(this)) {
            Log.d(TAG, "Brightness: WRITE_SETTINGS not granted — skipping");
            return;
        }
        try {
            savedBrightness = Settings.System.getInt(
                getContentResolver(), Settings.System.SCREEN_BRIGHTNESS);
            Settings.System.putInt(
                getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, 255);
            brightnessApplied = true;
            Log.d(TAG, "Brightness: set to 255 (saved=" + savedBrightness + ")");
        } catch (Settings.SettingNotFoundException e) {
            Log.w(TAG, "Brightness: could not read current value", e);
        }
    }

    private void restoreBrightness() {
        if (!brightnessApplied || savedBrightness < 0) return;
        if (Settings.System.canWrite(this)) {
            Settings.System.putInt(
                getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, savedBrightness);
            Log.d(TAG, "Brightness: restored to " + savedBrightness);
        }
        brightnessApplied = false;
    }

    // ── Game monitor ──────────────────────────────────────────────────────────

    private final Runnable monitorRunnable = new Runnable() {
        @Override
        public void run() {
            if (!isGameRecentlyActive()) {
                Log.i(TAG, gamePackage + " inactive for >" + (GAME_INACTIVE_TIMEOUT_MS / 1000)
                    + "s — stopping boost");
                stopSelf();
                return;
            }
            handler.postDelayed(this, MONITOR_INTERVAL_MS);
        }
    };

    /**
     * Returns {@code true} if the game was the foreground app within the last
     * {@value #GAME_INACTIVE_TIMEOUT_MS} ms.
     *
     * <p>Using "last used within N seconds" rather than "current top app" makes
     * the check resilient to brief home-screen or notification-shade visits.
     *
     * <p>Falls back to {@code true} (keep boosting) if UsageStats are empty —
     * which usually means Usage Access was not granted.
     */
    private boolean isGameRecentlyActive() {
        UsageStatsManager usm = (UsageStatsManager) getSystemService(USAGE_STATS_SERVICE);
        long now = System.currentTimeMillis();
        List<UsageStats> stats = usm.queryUsageStats(
            UsageStatsManager.INTERVAL_DAILY,
            now - USAGE_LOOKBACK_MS,
            now
        );

        if (stats == null || stats.isEmpty()) {
            Log.d(TAG, "UsageStats empty — Usage Access may not be granted; keeping boost alive");
            return true;
        }

        for (UsageStats s : stats) {
            if (gamePackage.equals(s.getPackageName())) {
                long lastUsed = s.getLastTimeUsed();
                boolean active = (now - lastUsed) < GAME_INACTIVE_TIMEOUT_MS;
                Log.d(TAG, gamePackage + " last used " + ((now - lastUsed) / 1000) + "s ago → " + active);
                return active;
            }
        }

        // Package not found in recent stats → game not launched yet or already purged
        return false;
    }
}
