package com.gamebooster;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.VpnService;
import android.os.ParcelFileDescriptor;
import android.util.Log;

import java.io.IOException;

/**
 * Optional VPN-based network isolation service.
 *
 * <h3>How it works</h3>
 * <ol>
 *   <li>Establishes a VPN interface that captures <em>all</em> IPv4 and IPv6 traffic
 *       via a 0.0.0.0/0 + ::/0 route.</li>
 *   <li>Uses {@link Builder#addDisallowedApplication(String)} so the selected
 *       <strong>game bypasses the tunnel entirely</strong> — its packets go straight
 *       to the real network interface at full speed.</li>
 *   <li>Also excludes this app itself from the tunnel so the UI stays responsive.</li>
 *   <li>The read-end of the tunnel ({@link ParcelFileDescriptor}) is intentionally
 *       never consumed — packets from other apps enter the tunnel and are silently
 *       dropped by the OS, effectively blocking their network access.</li>
 * </ol>
 *
 * <p>This is a best-effort feature. It does <strong>not</strong> inspect, decrypt,
 * log, or store any traffic. It will not interfere with the game's own packets.
 *
 * <h3>Prerequisites</h3>
 * The user must consent via the system VPN dialog (shown by
 * {@link VpnService#prepare(android.content.Context)}) before this service starts.
 */
public class BoostVpnService extends VpnService {

    private static final String TAG = "BoostVpnService";

    /** Intent extra: package name of the game that should bypass the VPN. */
    public static final String EXTRA_GAME_PACKAGE = "extra_game_package";

    /** Action used to request a clean stop. */
    public static final String ACTION_STOP = "com.gamebooster.vpn.action.STOP";

    /** {@code true} while the VPN tunnel is active; read from any thread. */
    public static volatile boolean isRunning = false;

    private ParcelFileDescriptor vpnInterface;

    // ── Service lifecycle ─────────────────────────────────────────────────────

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            tearDown();
            return START_NOT_STICKY;
        }
        String gamePackage = (intent != null)
            ? intent.getStringExtra(EXTRA_GAME_PACKAGE) : null;
        setUp(gamePackage);
        return START_STICKY;
    }

    @Override
    public void onRevoke() {
        // Called by the system when another VPN app takes over, or the user revokes consent.
        tearDown();
        super.onRevoke();
    }

    @Override
    public void onDestroy() {
        tearDown();
        super.onDestroy();
    }

    // ── VPN setup / teardown ──────────────────────────────────────────────────

    private void setUp(String gamePackage) {
        try {
            Builder builder = new Builder()
                .setSession("GameBooster")
                .setMtu(1500)
                // Assign a private address to our virtual interface
                .addAddress("10.99.0.1", 24)
                // Route ALL traffic through this interface …
                .addRoute("0.0.0.0", 0)   // all IPv4
                .addRoute("::", 0);        // all IPv6

            // … EXCEPT the game itself — its packets skip the tunnel.
            if (gamePackage != null) {
                try {
                    builder.addDisallowedApplication(gamePackage);
                    Log.d(TAG, "Game bypasses VPN: " + gamePackage);
                } catch (PackageManager.NameNotFoundException e) {
                    Log.w(TAG, "Game package not found: " + gamePackage);
                }
            }

            // Also let our own app bypass (keeps the UI reachable).
            try {
                builder.addDisallowedApplication(getPackageName());
            } catch (PackageManager.NameNotFoundException ignored) {}

            vpnInterface = builder.establish();
            isRunning    = (vpnInterface != null);

            if (isRunning) {
                Log.i(TAG, "VPN tunnel established — game traffic bypasses, others dropped.");
                // Intentionally NOT reading from vpnInterface.
                // Packets from disallowed apps arrive at the fd and are silently dropped.
            } else {
                Log.w(TAG, "VPN establish() returned null — another VPN may be active.");
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to establish VPN", e);
            isRunning = false;
        }
    }

    private void tearDown() {
        isRunning = false;
        if (vpnInterface != null) {
            try {
                vpnInterface.close();
                Log.i(TAG, "VPN tunnel closed.");
            } catch (IOException e) {
                Log.w(TAG, "Error closing VPN interface", e);
            }
            vpnInterface = null;
        }
        stopSelf();
    }
}
