package com.gamebooster;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.net.VpnService;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Main screen — lets the user pick a game/app, review permission status,
 * and start/stop the boost session.
 *
 * <h3>Permission flow</h3>
 * <ul>
 *   <li><b>Usage Access</b> — required; user is shown a dialog before the boost
 *       can start.</li>
 *   <li><b>DND / Brightness</b> — optional; missing ones are silently skipped
 *       with a toast message.</li>
 *   <li><b>VPN consent</b> — system dialog shown by {@link VpnService#prepare}
 *       when the VPN switch is on.</li>
 * </ul>
 */
public class MainActivity extends AppCompatActivity {

    // ── Views ─────────────────────────────────────────────────────────────────
    private Spinner      spinnerGames;
    private SwitchCompat switchVpn;
    private Button       btnBoost;
    private TextView     tvStatus;
    private TextView     tvPermUsage;
    private TextView     tvPermDnd;
    private TextView     tvPermBrightness;

    // ── State ─────────────────────────────────────────────────────────────────
    private final List<AppInfo> appList = new ArrayList<>();

    /** Holds the game package name while waiting for the VPN consent result. */
    private String pendingVpnPackage;

    // ── Activity result launchers ─────────────────────────────────────────────
    private ActivityResultLauncher<Intent> permLauncher;
    private ActivityResultLauncher<Intent> vpnConsentLauncher;

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spinnerGames      = findViewById(R.id.spinner_games);
        switchVpn         = findViewById(R.id.switch_vpn);
        btnBoost          = findViewById(R.id.btn_boost);
        tvStatus          = findViewById(R.id.tv_status);
        tvPermUsage       = findViewById(R.id.tv_perm_usage);
        tvPermDnd         = findViewById(R.id.tv_perm_dnd);
        tvPermBrightness  = findViewById(R.id.tv_perm_brightness);

        // Re-check permission UI after the user returns from a Settings page
        permLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            r -> updatePermissionStatus()
        );

        // Handle VPN consent dialog result
        vpnConsentLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            r -> {
                if (r.getResultCode() == Activity.RESULT_OK && pendingVpnPackage != null) {
                    launchVpnService(pendingVpnPackage);
                }
                pendingVpnPackage = null;
            }
        );

        // Load the app list off the main thread (PackageManager can be slow)
        loadInstalledAppsAsync();
        updatePermissionStatus();

        btnBoost.setOnClickListener(v -> onBoostClicked());
    }

    @Override
    protected void onResume() {
        super.onResume();
        updatePermissionStatus();
        syncBoostUi(BoostService.isRunning);
    }

    // ── Boost control ─────────────────────────────────────────────────────────

    private void onBoostClicked() {
        if (BoostService.isRunning) {
            stopBoosting();
        } else {
            startBoosting();
        }
    }

    private void startBoosting() {
        // Usage Access is the only hard requirement (needed to detect game exit)
        if (!PermissionHelper.hasUsageAccess(this)) {
            showSettingsDialog(
                "Usage Access Required",
                "GameBooster needs Usage Access to detect when your game exits and "
                    + "automatically stop the boost.\n\n"
                    + "Tap OK → enable GameBooster under Usage access.",
                PermissionHelper.usageAccessIntent()
            );
            return;
        }

        AppInfo selected = (AppInfo) spinnerGames.getSelectedItem();
        if (selected == null) {
            Toast.makeText(this, "Select a game first", Toast.LENGTH_SHORT).show();
            return;
        }

        // Warn about optional missing permissions — don't block
        if (!PermissionHelper.hasNotificationPolicyAccess(this)) {
            toast("DND access not granted — silence mode will be skipped");
        }
        if (!PermissionHelper.canWriteSettings(this)) {
            toast("Write Settings not granted — brightness boost will be skipped");
        }

        // Start the main boost foreground service
        Intent svc = new Intent(this, BoostService.class)
            .putExtra(BoostService.EXTRA_PACKAGE, selected.packageName);
        startForegroundService(svc);

        // Optionally start the VPN network-isolation service
        if (switchVpn.isChecked()) {
            requestVpnConsent(selected.packageName);
        }

        syncBoostUi(true);
    }

    private void stopBoosting() {
        stopService(new Intent(this, BoostService.class));
        // Also stop VPN if it was running
        Intent vpnStop = new Intent(this, BoostVpnService.class)
            .setAction(BoostVpnService.ACTION_STOP);
        startService(vpnStop);
        syncBoostUi(false);
    }

    // ── VPN ───────────────────────────────────────────────────────────────────

    private void requestVpnConsent(String gamePackage) {
        Intent prepare = VpnService.prepare(this);
        if (prepare != null) {
            // The system shows its "GameBooster wants to set up a VPN" dialog
            pendingVpnPackage = gamePackage;
            vpnConsentLauncher.launch(prepare);
        } else {
            // User already consented previously
            launchVpnService(gamePackage);
        }
    }

    private void launchVpnService(String gamePackage) {
        Intent vpn = new Intent(this, BoostVpnService.class)
            .putExtra(BoostVpnService.EXTRA_GAME_PACKAGE, gamePackage);
        startService(vpn);
    }

    // ── App list loader ───────────────────────────────────────────────────────

    private void loadInstalledAppsAsync() {
        new Thread(() -> {
            PackageManager pm = getPackageManager();
            List<ApplicationInfo> all = pm.getInstalledApplications(PackageManager.GET_META_DATA);
            List<AppInfo> list = new ArrayList<>();
            for (ApplicationInfo info : all) {
                boolean isSystem  = (info.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
                boolean isUpdated = (info.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0;
                if (!isSystem || isUpdated) {
                    list.add(new AppInfo(pm.getApplicationLabel(info).toString(), info.packageName));
                }
            }
            Collections.sort(list, (a, b) -> a.label.compareToIgnoreCase(b.label));

            new Handler(Looper.getMainLooper()).post(() -> {
                appList.clear();
                appList.addAll(list);
                ArrayAdapter<AppInfo> adapter = new ArrayAdapter<>(
                    this, R.layout.spinner_item, appList);
                adapter.setDropDownViewResource(R.layout.spinner_item);
                spinnerGames.setAdapter(adapter);
            });
        }).start();
    }

    // ── UI helpers ────────────────────────────────────────────────────────────

    private void syncBoostUi(boolean boosting) {
        if (boosting) {
            btnBoost.setText(getString(R.string.btn_stop));
            btnBoost.setBackgroundTintList(
                ContextCompat.getColorStateList(this, R.color.stop_color));
            tvStatus.setText(R.string.status_active);
        } else {
            btnBoost.setText(getString(R.string.btn_boost));
            btnBoost.setBackgroundTintList(
                ContextCompat.getColorStateList(this, R.color.boost_color));
            tvStatus.setText(R.string.status_ready);
        }
    }

    private void updatePermissionStatus() {
        setPermRow(tvPermUsage,
            PermissionHelper.hasUsageAccess(this),
            getString(R.string.perm_usage),
            PermissionHelper.usageAccessIntent());

        setPermRow(tvPermDnd,
            PermissionHelper.hasNotificationPolicyAccess(this),
            getString(R.string.perm_dnd),
            PermissionHelper.notificationPolicyIntent());

        setPermRow(tvPermBrightness,
            PermissionHelper.canWriteSettings(this),
            getString(R.string.perm_brightness),
            PermissionHelper.writeSettingsIntent(this));
    }

    private void setPermRow(TextView tv, boolean granted, String label, Intent settingsIntent) {
        if (granted) {
            tv.setText("\u2714  " + label);
            tv.setTextColor(ContextCompat.getColor(this, R.color.perm_ok));
            tv.setOnClickListener(null);
        } else {
            tv.setText("\u2718  " + label + "  (tap to grant)");
            tv.setTextColor(ContextCompat.getColor(this, R.color.perm_warn));
            tv.setOnClickListener(v -> permLauncher.launch(settingsIntent));
        }
    }

    private void showSettingsDialog(String title, String message, Intent intent) {
        new AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("Open Settings", (d, w) -> permLauncher.launch(intent))
            .setNegativeButton("Cancel", null)
            .show();
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }

    // ── AppInfo ───────────────────────────────────────────────────────────────

    static final class AppInfo {
        final String label;
        final String packageName;

        AppInfo(String label, String packageName) {
            this.label       = label;
            this.packageName = packageName;
        }

        @Override
        public String toString() {
            // Shown in the Spinner dropdown
            return label + "  \u00B7  " + packageName;
        }
    }
}
