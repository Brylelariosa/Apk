# GameBooster ProGuard rules
# Add project-specific rules here if minifyEnabled is turned on.
-keep class com.gamebooster.** { *; }
