# No reflection is used; default Android rules are enough.
-keep class com.neuralfeed.MainActivity { *; }
