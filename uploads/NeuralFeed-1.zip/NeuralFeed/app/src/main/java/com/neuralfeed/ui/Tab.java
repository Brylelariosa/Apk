package com.neuralfeed.ui;

import android.graphics.Canvas;
import android.graphics.Typeface;

import java.util.ArrayList;

/** One scrolling page of the hub. draw() must set contentH. */
abstract class Tab {
    protected final App app;
    protected final HubScreen hub;
    float contentH;

    Tab(App app, HubScreen hub) { this.app = app; this.hub = hub; }

    abstract void draw(Canvas c, float x, float y, float w, float h, float scroll);
    abstract void click(int id);

    /** True if a rect of height bh at by is mostly inside the viewport [ay, ay+ah]. */
    protected static boolean vis(float by, float bh, float ay, float ah) { return by + bh * 0.5f > ay && by + bh * 0.5f < ay + ah; }

    /** Greedy word wrap for static text (cache the result; this allocates). */
    protected String[] wrap(String s, float maxW, float sp, Typeface tf) {
        ArrayList<String> out = new ArrayList<String>();
        String[] words = s.split(" ");
        StringBuilder line = new StringBuilder();
        for (int i = 0; i < words.length; i++) {
            String trial = line.length() == 0 ? words[i] : line + " " + words[i];
            if (app.gfx.measure(trial, sp, tf) > maxW && line.length() > 0) {
                out.add(line.toString());
                line.setLength(0);
                line.append(words[i]);
            } else {
                line.setLength(0);
                line.append(trial);
            }
        }
        if (line.length() > 0) out.add(line.toString());
        return out.toArray(new String[0]);
    }
}
