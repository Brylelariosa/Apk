package com.neuralfeed.game;

import com.neuralfeed.meta.Defs;

/** Data fragments (struct-of-arrays pool). When full, new value merges into an existing common fragment. */
public final class Orbs {
    public final int cap;
    public final float[] x, y, vx, vy, v, t;
    public final byte[] type;
    public final boolean[] on;
    public int count, hi;
    private int cursor;

    public Orbs(int cap) {
        this.cap = cap;
        x = new float[cap]; y = new float[cap]; vx = new float[cap]; vy = new float[cap]; v = new float[cap]; t = new float[cap];
        type = new byte[cap]; on = new boolean[cap];
    }

    public void clear() { for (int i = 0; i < cap; i++) on[i] = false; count = 0; hi = 0; }

    public int spawn(float px, float py, float pvx, float pvy, float val, int ty) {
        int idx = -1;
        if (count < cap) {
            for (int k = 0; k < cap; k++) {
                int i = (cursor + k) % cap;
                if (!on[i]) { idx = i; cursor = i + 1; break; }
            }
        }
        if (idx < 0) {
            for (int k = 0; k < 64; k++) {
                int i = (cursor++) % cap;
                if (on[i] && type[i] <= Defs.O_COMP) { v[i] += val; return i; }
            }
            idx = (cursor++) % cap;
            if (on[idx]) count--;
        }
        on[idx] = true; count++;
        x[idx] = px; y[idx] = py; vx[idx] = pvx; vy[idx] = pvy; v[idx] = val; type[idx] = (byte) ty; t[idx] = 0.45f;
        if (idx >= hi) hi = idx + 1;
        return idx;
    }

    public void remove(int i) { if (on[i]) { on[i] = false; count--; } }
}
