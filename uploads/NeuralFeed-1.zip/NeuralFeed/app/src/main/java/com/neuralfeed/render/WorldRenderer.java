package com.neuralfeed.render;

import android.graphics.Canvas;
import android.graphics.Paint;

import com.neuralfeed.core.Mx;
import com.neuralfeed.game.Arena;
import com.neuralfeed.game.Bullets;
import com.neuralfeed.game.Enemy;
import com.neuralfeed.game.Kinds;
import com.neuralfeed.game.Orbs;
import com.neuralfeed.game.Particles;
import com.neuralfeed.game.Player;
import com.neuralfeed.game.Popups;
import com.neuralfeed.game.World;
import com.neuralfeed.meta.Defs;

/** Draws the arena and everything in it with batched primitives. No allocation inside draw(). */
public final class WorldRenderer {
    private final Gfx g;
    public final Theme th = new Theme();
    private final Batch[] eb = new Batch[Kinds.N];
    private final Batch flashB = new Batch(2048), frozenB = new Batch(1024), convB = new Batch(1024);
    private final Batch hpBg = new Batch(512), hpFg = new Batch(512), teleB = new Batch(256), beamB = new Batch(512), dots = new Batch(512);
    private final Batch[] orbB = new Batch[5], bulB = new Batch[4];
    private final float[][] pbuf = new float[Particles.KINDS * 6][];
    private final int[] pn = new int[Particles.KINDS * 6];
    private final int[] kc = new int[Kinds.N];
    private static final int[] PCOL = {0, 0, 0, 0xFFFFFFFF, 0xFFD6C7FF, 0xFFFF7ADF, 0xFFFF5A5A};
    private static final float[] RM_STAR3 = {1f, 0.45f}, RM_STAR5 = {1f, 0.55f}, RM_ONE = {1f};
    private int sw, sh;
    private float sc, ox, oy;

    public WorldRenderer(Gfx g) {
        this.g = g;
        for (int i = 0; i < eb.length; i++) eb[i] = new Batch(1536);
        for (int i = 0; i < orbB.length; i++) orbB[i] = new Batch(1100);
        for (int i = 0; i < bulB.length; i++) bulB[i] = new Batch(256);
        for (int i = 0; i < pbuf.length; i++) pbuf[i] = new float[640];
        th.set(0);
        colors();
    }

    public void setTheme(int timeline) { th.set(timeline); colors(); }

    private void colors() {
        int h = th.hostile;
        kc[Kinds.DRONE] = h; kc[Kinds.VIRUS] = Gfx.mix(h, 0xFFFFFFFF, 0.25f); kc[Kinds.FIREWALL] = Gfx.mix(h, 0xFF000000, 0.2f);
        kc[Kinds.LEECH] = th.data; kc[Kinds.HUNTER] = Gfx.mix(h, 0xFFFFFFFF, 0.45f); kc[Kinds.CORRUPT] = 0xFFFF7ADF;
        kc[Kinds.SECURITY] = 0xFF9FB4D8; kc[Kinds.EATER] = 0xFFB48CFF; kc[Kinds.UNKNOWN] = 0xFFE0D4FF; kc[Kinds.NEST] = h;
        kc[Kinds.MINI] = h; kc[Kinds.ECHO] = Gfx.alpha(th.accent, 150); kc[Kinds.MEMFRAG] = 0xFFD6C7FF; kc[Kinds.FRIEND] = 0xFF9CFFC0; kc[Kinds.BOSS] = h;
        PCOL[Particles.SPARK] = th.accent; PCOL[Particles.DATA] = th.data; PCOL[Particles.HOSTILE] = h;
    }

    private boolean vis(float x, float y, float m) { return x > -m && x < sw + m && y > -m && y < sh + m; }

    public void draw(Canvas c, World w, int width, int height, boolean noFlash) {
        sw = width; sh = height;
        sc = w.scale;
        ox = sw * 0.5f - w.camX * sc + w.shakeX;
        oy = sh * 0.5f - w.camY * sc + w.shakeY;
        float t = w.time;
        Arena ar = w.arena;
        c.drawColor(th.bg);
        backdrop(c, w);
        // outside-of-arena shade
        float ax0 = ox, ay0 = oy, ax1 = ar.W * sc + ox, ay1 = ar.H * sc + oy;
        int shade = 0x99000000;
        if (ay0 > 0) g.rectFill(c, 0, 0, sw, Math.min(sh, ay0), shade);
        if (ay1 < sh) g.rectFill(c, 0, Math.max(0, ay1), sw, sh - Math.max(0, ay1), shade);
        if (ax0 > 0) g.rectFill(c, 0, Math.max(0, ay0), Math.min(sw, ax0), Math.min(sh, ay1) - Math.max(0, ay0), shade);
        if (ax1 < sw) g.rectFill(c, Math.max(0, ax1), Math.max(0, ay0), sw - Math.max(0, ax1), Math.min(sh, ay1) - Math.max(0, ay0), shade);
        g.rrectLine(c, ax0, ay0, ax1 - ax0, ay1 - ay0, 6f * g.dp, 2f * g.dp, Gfx.alpha(th.wall, 200));

        zones(c, w, t);
        obstacles(c, w);
        specials(c, w, t);
        orbs(c, w, t);
        enemies(c, w, t);
        bullets(c, w);
        particles(c, w);
        player(c, w, t);
        popups(c, w);
        post(c, w, noFlash);
    }

    // ------------------------------------------------------------------ backdrop & arena

    private void backdrop(Canvas c, World w) {
        if (g.quality < 1 || th.pattern == 4) return;
        float sp = th.cell * sc;
        if (sp < 14f) sp = 14f * Mx.max(1f, 14f / sp);
        float x0 = ((ox % sp) + sp) % sp, y0 = ((oy % sp) + sp) % sp;
        g.line.setStrokeWidth(Math.max(1f, g.dp * 0.7f));
        g.line.setColor(th.grid);
        switch (th.pattern) {
            case 0:
                for (float x = x0; x < sw; x += sp) g.lb.line(x, 0, x, sh);
                for (float y = y0; y < sh; y += sp) g.lb.line(0, y, sw, y);
                g.lb.lines(c, g.line);
                break;
            case 1:
                for (float y = y0; y < sh; y += sp) for (float x = x0; x < sw; x += sp) g.pb.pt(x, y);
                g.pts.setStrokeWidth(g.dp * 1.8f); g.pts.setColor(th.grid);
                g.pb.points(c, g.pts);
                break;
            case 2:
                for (float x = x0 - sh; x < sw; x += sp) g.lb.line(x, sh, x + sh, 0);
                g.lb.lines(c, g.line);
                break;
            default: {
                float s2 = Math.max(g.dp * 3f, sp * 0.25f);
                float yy = ((oy % s2) + s2) % s2;
                for (float y = yy; y < sh; y += s2) g.lb.line(0, y, sw, y);
                g.lb.lines(c, g.line);
                break;
            }
        }
    }

    private void zones(Canvas c, World w, float t) {
        Arena ar = w.arena;
        for (int i = 0; i < ar.nz; i++) {
            float x = ar.zx[i] * sc + ox, y = ar.zy[i] * sc + oy, r = ar.zr[i] * sc;
            if (!vis(x, y, r)) continue;
            g.circle(c, x, y, r, Gfx.alpha(th.hostile, 26));
            g.ring(c, x, y, r, 1.6f * g.dp, Gfx.alpha(th.hostile, 110));
            g.ring(c, x, y, r * (0.55f + 0.1f * Mx.sin(t * 3f + i)), g.dp, Gfx.alpha(th.hostile, 60));
        }
        for (int i = 0; i < ar.nd; i++) {
            float x = ar.dfx[i] * sc + ox, y = ar.dfy[i] * sc + oy;
            if (vis(x, y, ar.dfr[i] * sc)) g.ring(c, x, y, ar.dfr[i] * sc * 1.3f, g.dp, Gfx.alpha(th.data, 22));
        }
        for (int i = 0; i < 3; i++) {
            if (w.riftT[i] <= 0) continue;
            float x = w.riftX[i] * sc + ox, y = w.riftY[i] * sc + oy, r = w.riftR[i] * sc;
            g.circle(c, x, y, r, 0x228C6BFF);
            g.ring(c, x, y, r, 1.6f * g.dp, 0xAAC9B6FF);
            g.ring(c, x, y, r * (0.6f + 0.2f * Mx.sin(t * 5f)), g.dp, 0x66C9B6FF);
        }
    }

    private void obstacles(Canvas c, World w) {
        Arena ar = w.arena;
        int wl = Gfx.alpha(th.wall, 230), wf = Gfx.alpha(th.wall, 60);
        for (int i = 0; i < ar.nc; i++) {
            float x = ar.cx[i] * sc + ox, y = ar.cy[i] * sc + oy, r = ar.cr[i] * sc;
            if (!vis(x, y, r)) continue;
            g.circle(c, x, y, r, wf);
            g.ring(c, x, y, r, 1.8f * g.dp, wl);
        }
        for (int i = 0; i < ar.nr; i++) {
            float x = ar.rx[i] * sc + ox, y = ar.ry[i] * sc + oy, rw = ar.rw[i] * sc, rh = ar.rh[i] * sc;
            if (x > sw || y > sh || x + rw < 0 || y + rh < 0) continue;
            g.rectFill(c, x, y, rw, rh, wf);
            g.rrectLine(c, x, y, rw, rh, 2f * g.dp, 1.8f * g.dp, wl);
        }
        for (int i = 0; i < Arena.MB; i++) {
            if (ar.bt[i] <= 0) continue;
            float x = ar.bx[i] * sc + ox, y = ar.by[i] * sc + oy, r = ar.br[i] * sc;
            float a = Mx.min(1f, ar.bt[i] * 2f);
            g.circle(c, x, y, r, Gfx.alpha(0xFF9FB4D8, (int) (60 * a)));
            g.ring(c, x, y, r, 2f * g.dp, Gfx.alpha(0xFF9FB4D8, (int) (220 * a)));
            g.ring(c, x, y, r * 0.6f, g.dp, Gfx.alpha(0xFF9FB4D8, (int) (120 * a)));
        }
    }

    private void specials(Canvas c, World w, float t) {
        Arena ar = w.arena;
        Player pl = w.pl;
        for (int i = 0; i < ar.nv; i++) {
            float x = ar.vx[i] * sc + ox, y = ar.vy[i] * sc + oy, r = 0.5f * sc;
            if (!vis(x, y, r * 2)) continue;
            boolean done = ar.vdone[i];
            int col = Gfx.alpha(th.data2, done ? 60 : 230);
            for (int k = 0; k < 6; k++) {
                float a1 = k * Mx.TAU / 6f + t * 0.3f, a2 = (k + 1) * Mx.TAU / 6f + t * 0.3f;
                g.lb.line(x + Mx.cos(a1) * r, y + Mx.sin(a1) * r, x + Mx.cos(a2) * r, y + Mx.sin(a2) * r);
            }
            g.line.setStrokeWidth(1.8f * g.dp); g.line.setColor(col);
            g.lb.lines(c, g.line);
            if (!done) {
                g.arc(c, x, y, r * 1.35f, -90f, 360f * ar.vp[i], 2.4f * g.dp, th.accent);
                g.circle(c, x, y, r * 0.22f, col);
            }
        }
        for (int i = 0; i < ar.nm; i++) {
            if (ar.mgot[i]) continue;
            float x = ar.mx[i] * sc + ox, y = ar.my[i] * sc + oy;
            float d = Mx.len(ar.mx[i] - pl.x, ar.my[i] - pl.y);
            if (!vis(x, y, 80f)) continue;
            float a = ar.hidden && Mx.abs(ar.mx[i] - ar.hx) < 0.1f ? Mx.clamp(1f - (d - 5f) / 4f, 0f, 1f) : 1f;
            if (a <= 0.02f) continue;
            float s = (0.3f + 0.05f * Mx.sin(t * 4f)) * sc;
            g.glow(c, x, y, s * 3f, 0xFFD6C7FF, (int) (150 * a));
            g.lb.line(x, y - s, x + s, y); g.lb.line(x + s, y, x, y + s); g.lb.line(x, y + s, x - s, y); g.lb.line(x - s, y, x, y - s);
            g.line.setStrokeWidth(1.8f * g.dp); g.line.setColor(Gfx.alpha(0xFFFFFFFF, (int) (230 * a)));
            g.lb.lines(c, g.line);
        }
    }

    // ------------------------------------------------------------------ orbs, enemies, bullets, particles

    private void orbs(Canvas c, World w, float t) {
        Orbs o = w.orbs;
        float base = Mx.max(3f * g.dp, 0.07f * sc);
        for (int i = 0; i < o.hi; i++) {
            if (!o.on[i]) continue;
            float x = o.x[i] * sc + ox, y = o.y[i] * sc + oy;
            if (!vis(x, y, 20f)) continue;
            orbB[o.type[i]].pt(x, y);
        }
        int[] cols = {th.data, th.data2, 0xFFFF7ADF, 0xFFFF4D4D, 0xFFD6C7FF};
        float[] sz = {1f, 1.5f, 1.9f, 1.7f, 2.3f};
        for (int k = 0; k < 5; k++) {
            Batch b = orbB[k];
            if (b.n == 0) continue;
            float s = base * sz[k] * (k == Defs.O_UNK ? 1f + 0.2f * Mx.sin(t * 6f) : 1f);
            if (g.quality >= 2) { g.pts.setStrokeWidth(s * 2.4f); g.pts.setColor(Gfx.alpha(cols[k], 45)); g.pts.setStrokeCap(Paint.Cap.ROUND); c.drawPoints(b.a, 0, b.n & ~1, g.pts); }
            g.pts.setStrokeWidth(s); g.pts.setColor(cols[k]);
            b.points(c, g.pts);
        }
    }

    private void shape(Batch b, int kind, float x, float y, float r, float rot, float t, int id) {
        switch (kind) {
            case Kinds.DRONE: poly(b, x, y, r, 4, rot + 0.785f, RM_ONE); break;
            case Kinds.VIRUS: poly(b, x, y, r, 6, rot, RM_STAR3); break;
            case Kinds.FIREWALL: poly(b, x, y, r, 8, 0.39f, RM_ONE); poly(b, x, y, r * 0.55f, 4, 0.785f + rot * 0.3f, RM_ONE); break;
            case Kinds.LEECH: case Kinds.MINI: poly(b, x, y, r, 3, rot, RM_ONE); break;
            case Kinds.HUNTER: {
                float ca = Mx.cos(rot), sa = Mx.sin(rot);
                float x1 = x + ca * r * 1.5f, y1 = y + sa * r * 1.5f;
                float x2 = x + (-ca * 0.9f - sa * 0.65f) * r, y2 = y + (-sa * 0.9f + ca * 0.65f) * r;
                float x3 = x + (-ca * 0.9f + sa * 0.65f) * r, y3 = y + (-sa * 0.9f - ca * 0.65f) * r;
                b.line(x1, y1, x2, y2); b.line(x2, y2, x3, y3); b.line(x3, y3, x1, y1);
                break;
            }
            case Kinds.CORRUPT: {
                int seed = (int) (t * 12f) + id * 7;
                for (int i = 0; i < 6; i++) {
                    float a1 = i * Mx.TAU / 6f + rot * 0.4f, a2 = (i + 1) * Mx.TAU / 6f + rot * 0.4f;
                    float r1 = r * (0.8f + 0.35f * Mx.hash(seed + i)), r2 = r * (0.8f + 0.35f * Mx.hash(seed + (i + 1) % 6));
                    b.line(x + Mx.cos(a1) * r1, y + Mx.sin(a1) * r1, x + Mx.cos(a2) * r2, y + Mx.sin(a2) * r2);
                }
                break;
            }
            case Kinds.SECURITY: {
                poly(b, x, y, r, 4, 0.785f, RM_ONE);
                b.line(x - r * 0.6f, y, x + r * 0.6f, y); b.line(x, y - r * 0.6f, x, y + r * 0.6f);
                break;
            }
            case Kinds.EATER: poly(b, x, y, r, 10, rot * 0.3f, RM_ONE); poly(b, x, y, r * 0.5f, 5, -rot, RM_ONE); break;
            case Kinds.UNKNOWN: {
                int seed = (int) (t * 10f) + id * 13;
                float[] rm = {0.8f + 0.4f * Mx.hash(seed), 0.45f + 0.2f * Mx.hash(seed + 1), 0.8f + 0.4f * Mx.hash(seed + 2), 0.45f + 0.2f * Mx.hash(seed + 3), 0.9f};
                poly(b, x, y, r, 5, rot, RM_STAR5);
                b.line(x - r * rm[0], y, x + r * rm[2], y);
                break;
            }
            case Kinds.NEST: poly(b, x, y, r, 6, 0f, RM_ONE); poly(b, x, y, r * 0.55f, 3, rot, RM_ONE); break;
            case Kinds.ECHO: poly(b, x, y, r, 8, rot * 0.5f, RM_ONE); break;
            case Kinds.MEMFRAG: poly(b, x, y, r, 4, 0f, RM_ONE); break;
            case Kinds.FRIEND: poly(b, x, y, r, 12, 0f, RM_ONE); b.line(x - r * 0.5f, y, x + r * 0.5f, y); b.line(x, y - r * 0.5f, x, y + r * 0.5f); break;
            default: poly(b, x, y, r, 6, rot, RM_ONE); break;
        }
    }

    private static void poly(Batch b, float x, float y, float r, int n, float rot, float[] rm) {
        float px = 0, py = 0, fx = 0, fy = 0;
        for (int i = 0; i < n; i++) {
            float a = rot + i * Mx.TAU / n, rr = r * rm[i % rm.length];
            float vx = x + Mx.cos(a) * rr, vy = y + Mx.sin(a) * rr;
            if (i == 0) { fx = vx; fy = vy; } else b.line(px, py, vx, vy);
            px = vx; py = vy;
        }
        b.line(px, py, fx, fy);
    }

    private void enemies(Canvas c, World w, float t) {
        int prot = 0;
        for (int i = 0; i < w.enHi; i++) {
            Enemy e = w.en[i];
            if (!e.alive) continue;
            float x = e.x * sc + ox, y = e.y * sc + oy, r = e.r * sc;
            if (!vis(x, y, r * 3f + 40f)) continue;
            if (e.kind == Kinds.BOSS) { boss(c, w, e, x, y, r, t); continue; }
            Batch b = e.flash > 0 ? flashB : (e.conv > 0 ? convB : (e.slowT > 0 ? frozenB : eb[e.kind]));
            float rot = e.rot;
            if (e.kind == Kinds.HUNTER) rot = Mx.atan2(e.st == 2 ? e.t3 : e.vy, e.st == 2 ? e.t2 : e.vx);
            else if (e.kind == Kinds.SECURITY || e.kind == Kinds.MEMFRAG) rot = 0f;
            float rr = e.phase > 0 ? r * 0.6f : r;
            shape(b, e.kind, x, y, rr, rot, t, e.id);
            if (e.kind == Kinds.DRONE || e.kind == Kinds.VIRUS || e.kind == Kinds.LEECH || e.kind == Kinds.UNKNOWN || e.kind == Kinds.MINI) dots.pt(x, y);
            if (e.kind == Kinds.HUNTER && e.st == 1) teleB.line(x, y, e.ax * sc + ox, e.ay * sc + oy);
            if (e.hp < e.maxHp && (e.maxHp > 0 && (Kinds.HP[e.kind] >= 28f || e.elite != 0))) {
                float bw = r * 2.2f, by = y + r + 6f * g.dp;
                hpBg.line(x - bw * 0.5f, by, x + bw * 0.5f, by);
                hpFg.line(x - bw * 0.5f, by, x - bw * 0.5f + bw * Mx.clamp(e.hp / e.maxHp, 0f, 1f), by);
            }
            if (e.prot && prot < 24) { prot++; g.ring(c, x, y, r * 1.6f, g.dp, Gfx.alpha(0xFF9FB4D8, 150)); }
            if ((e.elite & 8) != 0) {
                g.ring(c, x, y, r * 1.4f, 2f * g.dp, 0xFFFFE08A);
                if ((e.elite & 1) != 0) g.ring(c, x, y, r * 1.7f, g.dp, 0x88FFE08A);
            }
            if (e.kind == Kinds.EATER && g.quality >= 1) g.ring(c, x, y, 3.0f * sc, g.dp, Gfx.alpha(0xFFB48CFF, 36));
        }
        float lw = (g.quality >= 2 ? 1.9f : 1.5f) * g.dp;
        for (int k = 0; k < Kinds.N; k++) {
            Batch b = eb[k];
            if (b.n == 0) continue;
            g.line.setStrokeWidth(lw); g.line.setColor(kc[k]);
            b.lines(c, g.line);
        }
        g.line.setStrokeWidth(lw); g.line.setColor(0xFFFFFFFF); flashB.lines(c, g.line);
        g.line.setColor(0xFF9FE8FF); frozenB.lines(c, g.line);
        g.line.setColor(0xFFFF7ADF); convB.lines(c, g.line);
        g.pts.setStrokeWidth(3.2f * g.dp); g.pts.setColor(Gfx.alpha(th.hostile, 230)); dots.points(c, g.pts);
        g.line.setStrokeWidth(2.4f * g.dp); g.line.setColor(0x66000000); hpBg.lines(c, g.line);
        g.line.setColor(0xFFFFB0B0); hpFg.lines(c, g.line);
        g.line.setStrokeWidth(g.dp); g.line.setColor(Gfx.alpha(th.hostile, 150)); teleB.lines(c, g.line);
    }

    private void boss(Canvas c, World w, Enemy b, float x, float y, float r, float t) {
        int col = b.flash > 0 ? 0xFFFFFFFF : th.hostile;
        float lw = 2.4f * g.dp;
        g.glow(c, x, y, r * 2.6f, th.hostile, 70 + b.ph * 30);
        switch (b.bossId) {
            case Defs.B_FIREWALL: {
                poly(g.lb, x, y, r, 8, b.rot, RM_ONE); poly(g.lb, x, y, r * 0.6f, 4, -b.rot * 1.5f, RM_ONE);
                g.line.setStrokeWidth(lw); g.line.setColor(col); g.lb.lines(c, g.line);
                float px = 0, py = 0; boolean has = false;
                for (int k = 0; k < 18; k++) {
                    if (k < 4) { has = false; continue; }
                    float rr = (4.4f + 0.3f * Mx.sin(b.t3 * 1.5f)) * sc, ang = b.ax + k * Mx.TAU / 18f;
                    float nx = x + Mx.cos(ang) * rr, ny = y + Mx.sin(ang) * rr;
                    g.pb.pt(nx, ny);
                    if (has) g.lb.line(px, py, nx, ny);
                    px = nx; py = ny; has = true;
                }
                g.line.setStrokeWidth(g.dp); g.line.setColor(Gfx.alpha(th.hostile, 110)); g.lb.lines(c, g.line);
                g.pts.setStrokeWidth(0.5f * sc); g.pts.setColor(Gfx.alpha(th.hostile, 230)); g.pb.points(c, g.pts);
                break;
            }
            case Defs.B_ARCHIVIST: {
                for (int k = 0; k < 3; k++) poly(g.lb, x, y, r * (1f - 0.25f * k), 4, b.rot * (k % 2 == 0 ? 1f : -1.4f) + k * 0.4f, RM_ONE);
                g.line.setStrokeWidth(lw); g.line.setColor(col); g.lb.lines(c, g.line);
                if (b.immune) { g.ring(c, x, y, r * 1.6f, 2.4f * g.dp, 0xCCD6C7FF); g.glow(c, x, y, r * 2f, 0xFFD6C7FF, 80); }
                break;
            }
            case Defs.B_EATER: {
                g.circle(c, x, y, r * 0.8f, 0xFF160A28);
                g.arc(c, x, y, r, b.rot * 57f, 290f, lw * 1.4f, 0xFFB48CFF);
                g.ring(c, x, y, 4.2f * sc, g.dp, Gfx.alpha(0xFFB48CFF, 40));
                if (b.st == 1) g.ring(c, x, y, b.ay * sc, 3f * g.dp, Gfx.alpha(0xFFB48CFF, 200));
                break;
            }
            case Defs.B_OBSERVER: {
                g.rect.set(x - r, y - r * 0.55f, x + r, y + r * 0.55f);
                g.line.setStrokeWidth(lw); g.line.setColor(col); c.drawOval(g.rect, g.line);
                float dx = w.pl.x - b.x, dy = w.pl.y - b.y, d = Mx.max(0.01f, Mx.len(dx, dy));
                float ix = x + dx / d * r * 0.3f, iy = y + dy / d * r * 0.18f;
                g.circle(c, ix, iy, r * 0.32f, Gfx.alpha(th.hostile, 200));
                g.circle(c, ix, iy, r * 0.14f, 0xFFFFFFFF);
                if (b.st == 1) { g.seg(c, x, y, b.ax * sc + ox, b.ay * sc + oy, g.dp * 1.2f, Gfx.alpha(0xFFFFFFFF, 140)); g.ring(c, b.ax * sc + ox, b.ay * sc + oy, 0.4f * sc, 1.5f * g.dp, 0xAAFFFFFF); }
                break;
            }
            default: {
                int seed = (int) (t * 14f);
                for (int k = 0; k < 2; k++) {
                    float jx = (Mx.hash(seed * 3 + k) - 0.5f) * r * 0.25f, jy = (Mx.hash(seed * 5 + k) - 0.5f) * r * 0.25f;
                    poly(g.lb, x + jx * k, y + jy * k, r * (1f - 0.3f * k), 6, b.rot * (k == 0 ? 1f : -1.3f), RM_ONE);
                    g.line.setStrokeWidth(lw); g.line.setColor(k == 0 ? col : Gfx.alpha(0xFFFFFFFF, 140)); g.lb.lines(c, g.line);
                }
                break;
            }
        }
        g.ring(c, x, y, r * 1.18f, g.dp * 1.4f, Gfx.alpha(col, 90 + 50 * b.ph));
    }

    private void bullets(Canvas c, World w) {
        Bullets bl = w.bul;
        for (int i = 0; i < bl.hi; i++) {
            if (!bl.on[i]) continue;
            float x = bl.x[i] * sc + ox, y = bl.y[i] * sc + oy;
            if (!vis(x, y, 30f)) continue;
            bulB[bl.type[i]].pt(x, y);
            if (w.base.predict && Mx.len(bl.x[i] - w.pl.x, bl.y[i] - w.pl.y) < 6f) g.lb.line(x, y, x + bl.vx[i] * sc * 0.6f, y + bl.vy[i] * sc * 0.6f);
        }
        g.line.setStrokeWidth(g.dp); g.line.setColor(Gfx.alpha(0xFFFFFFFF, 50)); g.lb.lines(c, g.line);
        int[] cols = {th.hostile, 0xFFC9B6FF, th.accent, 0xFFFFB060};
        float[] sz = {0.16f, 0.22f, 0.15f, 0.18f};
        for (int k = 0; k < 4; k++) {
            Batch b = bulB[k];
            if (b.n == 0) continue;
            float s = sz[k] * sc;
            if (g.quality >= 2) { g.pts.setStrokeWidth(s * 2.2f); g.pts.setColor(Gfx.alpha(cols[k], 60)); c.drawPoints(b.a, 0, b.n & ~1, g.pts); }
            g.pts.setStrokeWidth(s); g.pts.setColor(cols[k]);
            b.points(c, g.pts);
        }
    }

    private void particles(Canvas c, World w) {
        Particles p = w.parts;
        for (int i = 0; i < pn.length; i++) pn[i] = 0;
        for (int i = 0; i < p.cap; i++) {
            if (!p.on[i]) continue;
            float x = p.x[i] * sc + ox, y = p.y[i] * sc + oy;
            if (x < -10 || x > sw + 10 || y < -10 || y > sh + 10) continue;
            float f = p.life[i] / p.max[i];
            int at = f > 0.66f ? 0 : (f > 0.33f ? 1 : 2);
            int st = p.size[i] >= 2.1f ? 1 : 0;
            int bi = (p.kind[i] * 3 + at) * 2 + st;
            int n = pn[bi];
            if (n + 2 > pbuf[bi].length) continue;
            pbuf[bi][n] = x; pbuf[bi][n + 1] = y; pn[bi] = n + 2;
        }
        int[] alphas = {255, 170, 90};
        for (int k = 0; k < Particles.KINDS; k++) {
            for (int at = 0; at < 3; at++) {
                for (int st = 0; st < 2; st++) {
                    int bi = (k * 3 + at) * 2 + st;
                    if (pn[bi] == 0) continue;
                    g.pts.setStrokeWidth((st == 1 ? 2.6f : 1.7f) * g.dp);
                    g.pts.setColor(Gfx.alpha(PCOL[k], alphas[at]));
                    c.drawPoints(pbuf[bi], 0, pn[bi], g.pts);
                }
            }
        }
    }

    // ------------------------------------------------------------------ player

    private void player(Canvas c, World w, float t) {
        Player pl = w.pl;
        float x = pl.x * sc + ox, y = pl.y * sc + oy;
        float coreR = pl.r * sc;
        float energy = w.fieldEnergy;
        int acc = th.accent;
        for (int i = 0; i < pl.trA.length; i++) {
            if (pl.trA[i] <= 0.02f) continue;
            g.circle(c, pl.trX[i] * sc + ox, pl.trY[i] * sc + oy, coreR * (0.5f + 0.5f * pl.trA[i]), Gfx.alpha(acc, (int) (110 * pl.trA[i])));
        }
        float R = w.live.range * sc;
        if (g.quality >= 1 && w.orbs.count > 0) {
            float cr = w.live.collect * (w.stormT > 0 ? 3.2f : 1f) * sc;
            g.ring(c, x, y, cr, g.dp, Gfx.alpha(acc, w.stormT > 0 ? 70 : 24));
        }
        boolean off = pl.fieldOff > 0f;
        int fc = off ? 0xFFC9B6FF : acc;
        if (!off || ((int) (t * 24f) & 1) == 0) {
            g.circle(c, x, y, R, Gfx.alpha(fc, 8 + (int) (20 * energy)));
            g.ring(c, x, y, R * (1f + 0.025f * w.ringPulse), (1.3f + energy * 1.7f + w.ringPulse * 1.5f) * g.dp, Gfx.alpha(fc, 70 + (int) (110 * w.ringPulse) + (int) (60 * energy)));
            if (!off) {
                int arcs = 1 + (int) (energy * 3f);
                for (int k = 0; k < arcs; k++) g.arc(c, x, y, R, t * (140f + 260f * energy) + k * (360f / arcs), 34f, 2f * g.dp, Gfx.alpha(fc, 160));
            }
        }
        if (w.comboFlash > 0f) g.ring(c, x, y, R * (1f + 0.25f * (1f - w.comboFlash)), 2f * g.dp, Gfx.alpha(0xFFFFFFFF, (int) (150 * w.comboFlash)));
        if (pl.abT[Defs.AB_FREEZE] > 0f) g.ring(c, x, y, R * 1.35f, 2f * g.dp, 0x889FE8FF);
        if (pl.abT[Defs.AB_IMPLOSION] > 0f) {
            for (int k = 0; k < 3; k++) {
                float f = (t * 1.6f + k / 3f) % 1f;
                g.ring(c, x, y, 9f * sc * (1f - f), g.dp * 1.3f, Gfx.alpha(acc, (int) (110 * f)));
            }
        }
        if (pl.abT[Defs.AB_CORRUPT] > 0f) g.ring(c, x, y, R * 1.1f, 2f * g.dp, Gfx.alpha(0xFFFF7ADF, 130));
        if (pl.abT[Defs.AB_OVERCLOCK] > 0f && !off) g.ring(c, x, y, R * 0.8f, g.dp * 1.4f, Gfx.alpha(0xFFFFE08A, 130));
        if (w.shockA > 0f) g.ring(c, x, y, w.shockR * sc, 3f * g.dp, Gfx.alpha(0xFFFFFFFF, (int) (200 * w.shockA)));
        if (w.stormT > 0f) g.ring(c, x, y, w.live.collect * 3.2f * sc * (0.5f + 0.5f * ((t * 1.3f) % 1f)), g.dp * 1.3f, Gfx.alpha(th.data, 90));

        // neural beams
        float lim = g.quality == 0 ? 6 : 24;
        int cnt = 0;
        int frame = (int) (t * 40f);
        for (int i = 0; i < World.MAXB; i++) {
            if (w.beamL[i] <= 0f || cnt >= lim) continue;
            float bx = w.beamX[i] * sc + ox, by = w.beamY[i] * sc + oy;
            float mx = (x + bx) * 0.5f + (Mx.hash(frame + i) - 0.5f) * 18f * g.dp / 3f, my = (y + by) * 0.5f + (Mx.hash(frame * 3 + i) - 0.5f) * 18f * g.dp / 3f;
            beamB.line(x, y, mx, my); beamB.line(mx, my, bx, by);
            cnt++;
        }
        if (beamB.n > 0) {
            if (g.quality >= 2) { g.line.setStrokeWidth(4f * g.dp); g.line.setColor(Gfx.alpha(acc, 36)); c.drawLines(beamB.a, 0, beamB.n & ~3, g.line); }
            g.line.setStrokeWidth(1.2f * g.dp); g.line.setColor(Gfx.alpha(acc, 190));
            beamB.lines(c, g.line);
        }
        if (pl.shield > 0f && pl.maxShield > 0f) g.ring(c, x, y, coreR * 1.75f, 2f * g.dp, Gfx.alpha(0xFF9FE8FF, 60 + (int) (140 * pl.shield / pl.maxShield)));
        if (pl.invuln > 0f && pl.dashT <= 0f && ((int) (t * 18f) & 1) == 0) g.ring(c, x, y, coreR * 2f, g.dp, 0x66FFFFFF);
        CoreArt.draw(g, c, x, y, coreR, w.lastTier, t, energy, acc, th.data2, Mx.clamp(pl.hitFlash * 4f, 0f, 1f));
    }

    private void popups(Canvas c, World w) {
        Popups p = w.pops;
        for (int i = 0; i < Popups.N; i++) {
            if (!p.on[i]) continue;
            float f = p.life[i] / p.max[i];
            int a = (int) (255 * Mx.min(1f, f * 1.8f));
            g.chars(c, p.txt[i], p.len[i], p.x[i] * sc + ox, p.y[i] * sc + oy, 26f * p.size[i], Gfx.alpha(p.col[i], a), Paint.Align.CENTER, g.condB);
        }
    }

    private void post(Canvas c, World w, boolean noFlash) {
        if (w.damageFlash > 0.02f) {
            int a = (int) (Mx.min(1f, w.damageFlash) * (noFlash ? 50 : 110));
            int col = Gfx.alpha(0xFFFF2A3A, a);
            float e = sh * 0.05f;
            g.rectFill(c, 0, 0, sw, e, col); g.rectFill(c, 0, sh - e, sw, e, col);
            g.rectFill(c, 0, 0, e * 0.7f, sh, col); g.rectFill(c, sw - e * 0.7f, 0, e * 0.7f, sh, col);
        }
        if (w.glitch > 0.06f && !noFlash && g.quality >= 1) {
            int n = 1 + (int) (w.glitch * 5f), seed = (int) (w.time * 16f);
            for (int i = 0; i < n; i++) {
                float y = Mx.hash(seed * 13 + i) * sh, h = (4f + Mx.hash(seed * 7 + i) * 26f) * g.dp * 0.5f;
                float x = Mx.hash(seed * 3 + i) * sw * 0.5f;
                g.rectFill(c, x, y, sw * (0.3f + 0.7f * Mx.hash(seed + i)), h, Gfx.alpha(th.accent, (int) (14 + 40 * w.glitch)));
                g.seg(c, 0, y, sw, y, g.dp, Gfx.alpha(0xFFFFFFFF, (int) (30 * w.glitch)));
            }
        }
    }

    public float scale() { return sc; }
    public float offX() { return ox; }
    public float offY() { return oy; }
}
