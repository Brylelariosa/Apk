package com.neuralfeed.game;

import com.neuralfeed.meta.Defs;
import com.neuralfeed.meta.Timelines;

/** Run structure and per-node scaling/modifiers. */
public final class Run {
    public static final int M_NONE = 0, M_VOLT = 1, M_ARCHIVE = 2, M_SWARM = 3, M_IRON = 4, M_RESON = 5, M_ECHO = 6, M_SAFE = 7, M_DANGER = 8, M_N = 9;
    public static final String[] M_NAME = {"Standard", "High voltage", "Deep archive", "Swarm protocol", "Iron curtain", "Resonance", "Echo chamber", "Safe route", "Dangerous route"};
    public static final String[] M_DESC = {"No modifier.", "Faster enemies. Richer Data.", "Unknown Data is far more common.", "Many fragile processes.",
            "Armored, slower waves.", "Longer range, weaker power.", "Your own past hunts you.", "Fewer, weaker enemies. Lower reward.", "More and tougher enemies. Big reward."};
    public static final float[] M_HP = {1f, 1f, 1.2f, 0.7f, 1.6f, 1f, 1.1f, 0.75f, 1.4f};
    public static final float[] M_SPAWN = {1f, 1f, 1f, 1.8f, 0.8f, 1f, 1f, 0.75f, 1.4f};
    public static final float[] M_SPEED = {1f, 1.3f, 1f, 1f, 1f, 1f, 1f, 1f, 1f};
    public static final float[] M_REWARD = {1f, 1.5f, 1.3f, 1.4f, 1.6f, 1.2f, 1.7f, 0.7f, 1.8f};
    public static final float[] M_UNK = {1f, 1f, 4f, 1f, 1f, 1f, 2f, 0.5f, 2f};
    public static final float[] M_RANGE = {1f, 1f, 1f, 1f, 1f, 1.4f, 1f, 1f, 1f};
    public static final float[] M_POWER = {1f, 1f, 1f, 1f, 1f, 0.75f, 1f, 1f, 1f};

    public int node, loop, depth, mod;
    public double bag;
    public int kills, bossKills, memories, unknown;
    public float time;
    public int lastCleared = -1;
    public final int[] optMod = new int[3];
    public final boolean[] optEvent = new boolean[3];

    public void reset() {
        node = 0; loop = 0; depth = 0; mod = M_NONE; bag = 0; kills = 0; bossKills = 0; memories = 0; unknown = 0; time = 0; lastCleared = -1;
    }

    public int nodeType() { return Defs.RUN_PLAN[node % Defs.RUN_PLAN.length]; }

    /** True after the elite, danger zone and boss: the player may extract. */
    public boolean extractPoint() { return lastCleared == 2 || lastCleared == 4 || lastCleared == 5; }
    public boolean afterBoss() { return lastCleared == 5; }

    public void advance() {
        lastCleared = node;
        depth++;
        node++;
        if (node >= Defs.RUN_PLAN.length) { node = 0; loop++; }
    }

    public float hpScale(int tl) { return Timelines.hpMul(tl) * (float) Math.pow(1.22, Math.min(depth, 30)) * M_HP[mod]; }
    public float dmgScale(int tl) { return 1f + 0.30f * depth + 0.6f * tl; }
    public float valScale(int tl) {
        return (float) Math.pow(Timelines.hpMul(tl) * Math.pow(1.22, Math.min(depth, 30)), 0.88) * (1f + 0.25f * loop) * M_REWARD[mod];
    }
    public float speedScale() { return (1f + 0.02f * Math.min(depth, 20)) * M_SPEED[mod]; }
    public int tier(int tl) { return Math.min(9, depth + 2 * tl); }
}
