package com.neuralfeed.meta;

import com.neuralfeed.data.Profile;

/** Story progression helpers: discovery flags and relationship nudges. */
public final class Story {
    private Story() {}

    public static void updateFlags(Profile p) {
        if (p.memCount() >= 1) p.flags |= Defs.D_DATA;
        if (p.timeline >= 1 || p.cycle >= 1) p.flags |= Defs.D_PAST;
        float[] s = new float[4];
        Karma.strengths(p, s);
        if (s[0] >= 0.2f || s[1] >= 0.2f || s[2] >= 0.2f) p.flags |= Defs.D_SHAPED;
        if (p.paradox >= 20f || p.timeline >= 3) p.flags |= Defs.D_FUTURE;
        if (p.timeline >= 5) p.flags |= Defs.D_CONNECTED;
        if (p.timeline >= 8 || p.hasMem(7) || p.hasMem(8)) p.flags |= Defs.D_CREATOR;
        if (p.timeline >= 10) p.flags |= Defs.D_LOOP;
    }

    public static void trust(Profile p, float d) { p.trust = clamp01(p.trust + d); }
    public static void bond(Profile p, float d) { p.bond = clamp01(p.bond + d); }
    public static void indep(Profile p, float d) { p.indep = clamp01(p.indep + d); }

    private static float clamp01(float v) { return v < 0f ? 0f : (v > 1f ? 1f : v); }
}
