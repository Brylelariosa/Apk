package com.neuralfeed.core;

/** Small float math helpers (keeps game code free of double casts). */
public final class Mx {
    public static final float PI = 3.14159265f, TAU = 6.28318531f;

    private Mx() {}

    public static float sin(float a) { return (float) Math.sin(a); }
    public static float cos(float a) { return (float) Math.cos(a); }
    public static float sqrt(float a) { return (float) Math.sqrt(a); }
    public static float atan2(float y, float x) { return (float) Math.atan2(y, x); }
    public static float pow(float a, float b) { return (float) Math.pow(a, b); }
    public static float exp(float a) { return (float) Math.exp(a); }
    public static float abs(float a) { return a < 0 ? -a : a; }
    public static float min(float a, float b) { return a < b ? a : b; }
    public static float max(float a, float b) { return a > b ? a : b; }
    public static int mini(int a, int b) { return a < b ? a : b; }
    public static int maxi(int a, int b) { return a > b ? a : b; }
    public static float len(float x, float y) { return (float) Math.sqrt(x * x + y * y); }

    public static float clamp(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }
    public static int clampi(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }
    public static float lerp(float a, float b, float t) { return a + (b - a) * t; }
    public static float smooth(float t) { t = clamp(t, 0f, 1f); return t * t * (3f - 2f * t); }

    /** Frame-rate independent exponential approach. */
    public static float damp(float cur, float target, float rate, float dt) {
        return cur + (target - cur) * (1f - (float) Math.exp(-rate * dt));
    }

    public static float approach(float v, float target, float step) {
        if (v < target) { v += step; return v > target ? target : v; }
        v -= step; return v < target ? target : v;
    }

    public static float wrapAngle(float a) {
        while (a > PI) a -= TAU;
        while (a < -PI) a += TAU;
        return a;
    }

    /** Deterministic pseudo-random 0..1 from an int. */
    public static float hash(int n) {
        n = (n << 13) ^ n;
        int v = (n * (n * n * 15731 + 789221) + 1376312589) & 0x7fffffff;
        return v / 2147483648f;
    }
}
