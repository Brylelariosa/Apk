package com.neuralfeed.ui;

import android.graphics.Canvas;
import android.graphics.Paint;

import com.neuralfeed.audio.Sfx;
import com.neuralfeed.data.Profile;
import com.neuralfeed.render.Gfx;
import com.neuralfeed.render.Theme;
import com.neuralfeed.render.Ui;

/** Settings and save management. */
final class SysTab extends Tab {
    private static final String[] Q = {"Performance", "Low", "Medium", "High"};
    private float armedReset;

    SysTab(App app, HubScreen hub) { super(app, hub); }

    @Override void draw(Canvas c, float x, float y, float w, float h, float scroll) {
        Gfx g = app.gfx;
        Ui ui = app.ui;
        Theme th = app.wr.th;
        Profile pf = app.pf;
        float dp = g.dp, yy = y - scroll + 22f * dp;
        if (armedReset > 0f) armedReset -= 1f / 60f;
        g.text(c, "Audio", x, yy - 6f * dp, 15f, th.text, Paint.Align.LEFT, g.condB);
        yy += 22f * dp;
        pf.vMaster = ui.slider(c, 501, "Master volume", x, yy, w, pf.vMaster, th.accent, th.text); yy += 54f * dp;
        pf.vMusic = ui.slider(c, 502, "Music volume", x, yy, w, pf.vMusic, th.accent, th.text); yy += 54f * dp;
        pf.vSfx = ui.slider(c, 503, "Effects volume", x, yy, w, pf.vSfx, th.accent, th.text); yy += 54f * dp;
        pf.vVoice = ui.slider(c, 504, "AI voice volume", x, yy, w, pf.vVoice, th.accent, th.text); yy += 62f * dp;
        app.audio.applySettings(pf);
        g.text(c, "Gameplay", x, yy - 6f * dp, 15f, th.text, Paint.Align.LEFT, g.condB);
        yy += 24f * dp;
        ui.toggle(c, 510, "Vibration", x, yy, w, pf.vibrate, th.accent, th.text); yy += 44f * dp;
        ui.toggle(c, 511, "Screen shake", x, yy, w, pf.shake, th.accent, th.text); yy += 44f * dp;
        ui.toggle(c, 512, "Floating joystick", x, yy, w, pf.floatStick, th.accent, th.text); yy += 44f * dp;
        ui.toggle(c, 513, "Damage numbers", x, yy, w, pf.dmgNums, th.accent, th.text); yy += 44f * dp;
        ui.toggle(c, 514, "Reduce flashing", x, yy, w, pf.noFlash, th.accent, th.text); yy += 56f * dp;
        g.text(c, "Graphics", x, yy - 6f * dp, 15f, th.text, Paint.Align.LEFT, g.condB);
        yy += 18f * dp;
        float qw = (w - 18f * dp) / 4f;
        for (int i = 0; i < 4; i++) ui.button(c, 520 + i, Q[i], x + i * (qw + 6f * dp), yy, qw, 38f * dp, true, pf.quality == i ? Ui.ST_PRIMARY : Ui.ST_NORMAL, th.accent, th.text, th.bg);
        yy += 62f * dp;
        pf.density = Math.max(0.2f, ui.slider(c, 505, "Particle density", x, yy, w, pf.density, th.accent, th.text)); yy += 54f * dp;
        pf.hudOpacity = Math.max(0.2f, ui.slider(c, 506, "HUD opacity", x, yy, w, pf.hudOpacity, th.accent, th.text)); yy += 62f * dp;
        app.applySettings();
        if (vis(yy, 44f * dp, y, h)) ui.button(c, 530, "Customize HUD", x, yy, w, 44f * dp, true, Ui.ST_NORMAL, th.accent, th.text, th.bg);
        yy += 66f * dp;
        g.text(c, "Save", x, yy - 6f * dp, 15f, th.text, Paint.Align.LEFT, g.condB);
        yy += 18f * dp;
        float hw = (w - 8f * dp) * 0.5f;
        if (vis(yy, 44f * dp, y, h)) {
            ui.button(c, 531, "Save now", x, yy, hw, 44f * dp, true, Ui.ST_NORMAL, th.accent, th.text, th.bg);
            ui.button(c, 532, "Copy export", x + hw + 8f * dp, yy, hw, 44f * dp, true, Ui.ST_NORMAL, th.accent, th.text, th.bg);
        }
        yy += 54f * dp;
        if (vis(yy, 44f * dp, y, h)) {
            ui.button(c, 533, "Import from clipboard", x, yy, hw, 44f * dp, true, Ui.ST_NORMAL, th.accent, th.text, th.bg);
            ui.button(c, 534, "Share export", x + hw + 8f * dp, yy, hw, 44f * dp, true, Ui.ST_NORMAL, th.accent, th.text, th.bg);
        }
        yy += 54f * dp;
        if (vis(yy, 44f * dp, y, h)) ui.button(c, 535, armedReset > 0f ? "Tap again to erase everything" : "Reset progress", x, yy, w, 44f * dp, true, Ui.ST_DANGER, th.accent, th.text, th.bg);
        yy += 64f * dp;
        g.text(c, "NEURAL//FEED  \u00b7  offline  \u00b7  no accounts, no network", x + w * 0.5f, yy, 11f, Gfx.alpha(th.text, 90), Paint.Align.CENTER, g.cond);
        yy += 30f * dp;
        contentH = yy + scroll - y;
    }

    @Override void click(int id) {
        Profile pf = app.pf;
        switch (id) {
            case 510: pf.vibrate = !pf.vibrate; break;
            case 511: pf.shake = !pf.shake; break;
            case 512: pf.floatStick = !pf.floatStick; break;
            case 513: pf.dmgNums = !pf.dmgNums; break;
            case 514: pf.noFlash = !pf.noFlash; break;
            case 520: case 521: case 522: case 523: pf.quality = id - 520; app.applySettings(); break;
            case 530: app.setScreen(new HudEditorScreen(app, hub)); return;
            case 531: app.saveNow(); app.plat.toast("Saved"); break;
            case 532: app.plat.copy(app.saves.export(pf)); app.plat.toast("Save copied to clipboard"); break;
            case 534: app.plat.share(app.saves.export(pf)); break;
            case 533: {
                Profile p = app.saves.importText(app.plat.paste());
                if (p == null) { app.plat.toast("No valid save in clipboard"); app.audio.sfx(Sfx.UI_DENY, 0.8f); return; }
                app.pf = p;
                p.sanitize();
                app.refreshIdeology();
                app.wr.setTheme(p.timeline);
                app.applySettings();
                app.saveNow();
                app.plat.toast("Save imported");
                app.setScreen(new HubScreen(app));
                return;
            }
            case 535:
                if (armedReset <= 0f) { armedReset = 4f; app.tap(); return; }
                Profile n = new Profile();
                n.vMaster = pf.vMaster; n.vMusic = pf.vMusic; n.vSfx = pf.vSfx; n.vVoice = pf.vVoice; n.vibrate = pf.vibrate; n.shake = pf.shake;
                n.floatStick = pf.floatStick; n.noFlash = pf.noFlash; n.dmgNums = pf.dmgNums; n.quality = pf.quality; n.density = pf.density; n.hudOpacity = pf.hudOpacity;
                System.arraycopy(pf.hud, 0, n.hud, 0, n.hud.length);
                n.sessions = 1;
                app.pf = n;
                app.refreshIdeology();
                for (int i = 0; i < 4; i++) n.ideoTier[i] = com.neuralfeed.meta.Karma.tier(app.ideo[i]);
                app.wr.setTheme(0);
                app.saveNow();
                app.setScreen(new TitleScreen(app));
                return;
            default: return;
        }
        app.tap();
        if (id >= 510 && id <= 514) app.saveNow();
    }
}
