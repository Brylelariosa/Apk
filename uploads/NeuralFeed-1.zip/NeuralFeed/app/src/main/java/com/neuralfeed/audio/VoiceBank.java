package com.neuralfeed.audio;

/** The AI's voice: pre-rendered speech blips. Stage = how evolved the AI is, tone = ideology. */
public final class VoiceBank {
    public static final int STAGES = 3, TONES = 4, VARS = 6;
    private final short[][][][] b = new short[STAGES][TONES][VARS][];
    private static final float[][] FORM = {{800, 1200}, {500, 1800}, {300, 2300}, {500, 900}, {350, 700}, {500, 1500}};

    public VoiceBank() {
        for (int s = 0; s < STAGES; s++) for (int t = 0; t < TONES; t++) for (int v = 0; v < VARS; v++) b[s][t][v] = make(s, t, v);
    }

    public short[] get(int stage, int tone, int v) { return b[stage % STAGES][tone % TONES][v % VARS]; }

    private static short[] make(int stage, int tone, int v) {
        float[] f0t = {170f, 108f, 150f, 135f};
        float f0 = f0t[tone] * (1f + 0.13f * (v - 2.5f) / 2.5f);
        float dur = stage == 0 ? 0.05f : (stage == 1 ? 0.065f : 0.08f);
        if (tone == 2) dur *= 0.75f;
        Synth s = new Synth(dur + 0.01f);
        int n = s.n;
        if (stage < 2) {
            int shape = stage == 0 ? Synth.SQR : Synth.TRI;
            s.osc(0f, dur, f0 * 1.3f, f0 * (1.1f + 0.08f * v / 5f), shape, 0.5f, 0.004f, 1.2f);
            s.osc(0f, dur, f0 * 2.01f, f0 * 2.0f, Synth.SINE, 0.18f, 0.004f, 1.5f);
            if (stage == 0) s.crush(0f, dur, 4);
        } else {
            float[] fm = FORM[v % FORM.length];
            float vib = tone == 2 ? 0f : 5.5f;
            for (int h = 1; h <= 14; h++) {
                float fh = f0 * h;
                if (fh > 4200f) break;
                float a = (float) (Math.exp(-Math.pow((fh - fm[0]) / 260f, 2)) + 0.7 * Math.exp(-Math.pow((fh - fm[1]) / 380f, 2)));
                if (a < 0.03f) continue;
                s.oscV(0f, dur, fh, fh * 0.97f, Synth.SINE, 0.34f * a / h * 2.2f, 0.01f, 0.9f, vib, 0.012f);
            }
        }
        if (tone == 1) { s.osc(0f, dur, f0 * 0.5f, f0 * 0.5f, Synth.SQR, 0.22f, 0.005f, 1.2f); }
        s.drive(1.2f);
        return s.pcm(0.55f);
    }
}
