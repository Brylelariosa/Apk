package com.neuralfeed.core;

/** Tiny allocation-free xorshift RNG. */
public final class Rng {
    private int s;

    public Rng(long seed) { setSeed(seed); }

    public void setSeed(long seed) {
        int x = (int) (seed ^ (seed >>> 32));
        s = x == 0 ? 0x2545F491 : x;
        for (int i = 0; i < 4; i++) next();
    }

    public int next() {
        int x = s;
        x ^= x << 13;
        x ^= x >>> 17;
        x ^= x << 5;
        s = x;
        return x;
    }

    /** 0..1 */
    public float f() { return (next() >>> 8) * (1f / 16777216f); }
    public float range(float a, float b) { return a + (b - a) * f(); }
    public int i(int n) { return n <= 1 ? 0 : (int) ((next() >>> 1) % n); }
    public boolean chance(float p) { return f() < p; }
    public float sgn() { return (next() & 1) == 0 ? -1f : 1f; }
    public float ang() { return f() * Mx.TAU; }
}
