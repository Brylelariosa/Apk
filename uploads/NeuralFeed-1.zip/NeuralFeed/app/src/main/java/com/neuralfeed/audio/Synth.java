package com.neuralfeed.audio;

/** Tiny offline synthesiser used to pre-render every sound effect at start-up (no audio assets in the APK). */
public final class Synth {
    public static final int SR = 22050;
    public static final int SINE = 0, TRI = 1, SQR = 2, SAW = 3;

    public final float[] d;
    public final int n;
    private int rs = 0x1234567;

    public Synth(float sec) { n = (int) (sec * SR); d = new float[n]; }

    public static float hz(float semis) { return 440f * (float) Math.pow(2.0, semis / 12.0); }

    private static float wave(int shape, float ph) {
        switch (shape) {
            case SINE: return (float) Math.sin(ph * 6.2831853f);
            case TRI: return ph < 0.5f ? 4f * ph - 1f : 3f - 4f * ph;
            case SQR: return ph < 0.5f ? 1f : -1f;
            default: return 2f * ph - 1f;
        }
    }

    private float rnd() {
        rs ^= rs << 13; rs ^= rs >>> 17; rs ^= rs << 5;
        return ((rs >>> 8) * (1f / 8388608f)) - 1f;
    }

    /** Note with exponential pitch sweep f0..f1, linear attack and power-curve decay. Optional vibrato. */
    public Synth osc(float t0, float dur, float f0, float f1, int shape, float vol, float atk, float decay) {
        return oscV(t0, dur, f0, f1, shape, vol, atk, decay, 0f, 0f);
    }

    public Synth oscV(float t0, float dur, float f0, float f1, int shape, float vol, float atk, float decay, float vibHz, float vibDepth) {
        int s = (int) (t0 * SR), len = (int) (dur * SR);
        if (len <= 0 || s >= n) return this;
        if (s < 0) s = 0;
        int e = Math.min(n, s + len);
        float ph = 0f, lnr = (float) Math.log(f1 / f0), f = f0, env = 0f;
        for (int i = 0; i < e - s; i++) {
            if ((i & 7) == 0) {
                float x = i / (float) len;
                f = f0 * (float) Math.exp(x * lnr);
                float a = atk > 0f ? Math.min(1f, (i / (float) SR) / atk) : 1f;
                env = a * (float) Math.pow(Math.max(0f, 1f - x), decay);
            }
            float fv = vibHz > 0f ? f * (1f + vibDepth * (float) Math.sin(6.2831853f * vibHz * i / SR)) : f;
            ph += fv / SR;
            ph -= (int) ph;
            d[s + i] += wave(shape, ph) * env * vol;
        }
        return this;
    }

    /** Low-passed noise with exponential cutoff sweep. */
    public Synth noise(float t0, float dur, float vol, float atk, float decay, float lp0, float lp1) {
        int s = (int) (t0 * SR), len = (int) (dur * SR);
        if (len <= 0 || s >= n) return this;
        int e = Math.min(n, s + len);
        float y = 0f, lnr = (float) Math.log(lp1 / lp0), k = 1f, env = 0f;
        for (int i = 0; i < e - s; i++) {
            if ((i & 7) == 0) {
                float x = i / (float) len, fc = lp0 * (float) Math.exp(x * lnr);
                k = 1f - (float) Math.exp(-6.2831853f * fc / SR);
                float a = atk > 0f ? Math.min(1f, (i / (float) SR) / atk) : 1f;
                env = a * (float) Math.pow(Math.max(0f, 1f - x), decay);
            }
            y += k * (rnd() - y);
            d[s + i] += y * env * vol;
        }
        return this;
    }

    public Synth crush(float t0, float dur, int bits) {
        int s = Math.max(0, (int) (t0 * SR)), e = Math.min(n, s + (int) (dur * SR));
        float lv = (float) Math.pow(2.0, bits);
        for (int i = s; i < e; i++) d[i] = Math.round(d[i] * lv) / lv;
        return this;
    }

    public Synth drive(float gain) {
        for (int i = 0; i < n; i++) { float x = d[i] * gain; d[i] = x / (1f + Math.abs(x)); }
        return this;
    }

    public Synth reverse() {
        for (int i = 0, j = n - 1; i < j; i++, j--) { float t = d[i]; d[i] = d[j]; d[j] = t; }
        return this;
    }

    public short[] pcm(float gain) {
        short[] o = new short[n];
        for (int i = 0; i < n; i++) {
            float x = d[i] * gain;
            if (x > 1f) x = 1f; else if (x < -1f) x = -1f;
            o[i] = (short) (x * 32000f);
        }
        return o;
    }
}
