package com.neuralfeed.meta;

import com.neuralfeed.data.Profile;

import java.util.Arrays;

/** Time-travel prestige: the run resets, memories and personality do not. */
public final class Prestige {
    private Prestige() {}

    private static void resetProgression(Profile p) {
        p.bank = 0; p.timelineData = 0;
        Arrays.fill(p.up, 0);
        p.wide = 0; p.wideUnlock = 0; p.bossDone = false; p.bossMask = 0;
    }

    /** Travels one timeline back. Returns echoes gained. */
    public static int activate(Profile p) {
        int gain = Timelines.echoGain(p);
        float[] s = new float[4];
        Karma.strengths(p, s);
        int dom = Karma.dominant(s);
        boolean changed = p.prevIdeology >= 0 && p.prevIdeology != dom;
        p.prevIdeology = dom;
        System.arraycopy(p.karma, 0, p.prevKarma, 0, Defs.K_N);
        p.echoes += gain;
        resetProgression(p);
        p.paradox = Math.min(100f, p.paradox + 9f + (changed ? 4f : 0f));
        p.timeline = Math.min(Defs.TL_N - 1, p.timeline + 1);
        p.flags |= Defs.F_PRESTIGE1;
        if (p.timeline >= 10) p.flags |= Defs.F_TL0;
        Story.indep(p, 0.03f);
        Story.bond(p, 0.02f);
        Story.updateFlags(p);
        return gain;
    }

    /** After an ending: a new cycle begins at the first timeline, keeping echoes, memories and personality. */
    public static void newCycle(Profile p, int ending) {
        p.endings |= 1 << ending;
        p.cycle++;
        p.echoes += 5;
        float[] s = new float[4];
        Karma.strengths(p, s);
        p.prevIdeology = Karma.dominant(s);
        resetProgression(p);
        p.timeline = 0;
        p.paradox = Math.max(20f, p.paradox * 0.5f);
        Story.updateFlags(p);
    }

    public static String paradoxZone(float para) {
        if (para >= 100f) return "Reality unstable";
        if (para >= 80f) return "Timelines overlapping";
        if (para >= 50f) return "Future objects in the past";
        if (para >= 20f) return "Small anomalies";
        return "Stable";
    }
}
