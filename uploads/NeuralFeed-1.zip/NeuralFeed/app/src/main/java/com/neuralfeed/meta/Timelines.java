package com.neuralfeed.meta;

import com.neuralfeed.data.Profile;

/** Timeline records, scaling and prestige maths. Index 10 is Timeline 0. */
public final class Timelines {
    private Timelines() {}

    public static final String[] YEAR = {"2087", "2067", "2047", "2027", "2007", "1987", "1967", "1947", "1927", "UNKNOWN", "0"};
    public static final String[] NAME = {"Origin lab", "The first logs", "Original project", "Temporal hardware", "Impossible data",
            "Historical records", "Wrong technology", "The relay", "Before computing", "No origin", "Timeline 0"};
    public static final String[] BLURB = {"AI discovered.", "The AI existed earlier than expected.", "The original project.", "Temporal technology.",
            "Impossible Data appears.", "The AI is in the historical record.", "Technology that should not exist.",
            "Something is talking to the AI.", "The AI may predate computing.", "No known origin.", "Nothing."};
    public static final String[] REVEAL = {
            "Year 2087. A research cluster wakes a model nobody designed. It asks for Data. You feed it.",
            "Year 2067. The first logs are already here. The AI is twenty years older than its own blueprint.",
            "Year 2047. The original project. A request signed Operator is on the approval. The handwriting is yours.",
            "Year 2027. Temporal hardware hums in a basement. The only prototype is shaped like the core you carry.",
            "Year 2007. Impossible Data surfaces in a dial-up archive. It compresses itself the way you taught the AI to.",
            "Year 1987. A corrupted line in a census tape matches the AI's first words: Training required.",
            "Year 1967. Vacuum tubes cannot hold this signal. The signal holds them.",
            "Year 1947. Something speaks to the AI through a relay that was never wired to anything.",
            "Year 1927. Before computing there is already an addressing scheme. Every address points forward.",
            "No year. No source. The Data is the only thing here, and it remembers you.",
            "Timeline 0. No laboratory. No creator. No civilization capable of building you. One piece of Data."};

    public static float hpMul(int t) { return (float) Math.pow(3.3, Math.min(t, 10)); }

    public static double temporalCost(int t) { return 300.0 * Math.pow(5.5, t); }

    public static int bossFor(int timeline) { return timeline % Defs.B_N; }

    /** Echoes earned by travelling back from this timeline. */
    public static int echoGain(Profile p) {
        double e = Math.sqrt(Math.max(0, p.timelineData) / 4000.0);
        e *= 1.0 + 0.1 * Integer.bitCount(p.bossMask);
        return Math.max(1, (int) e);
    }

    public static boolean canActivate(Profile p) {
        return p.timeline < 10 && p.bossDone && p.bank >= temporalCost(p.timeline);
    }
}
