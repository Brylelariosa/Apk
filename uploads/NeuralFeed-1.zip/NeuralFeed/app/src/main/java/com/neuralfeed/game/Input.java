package com.neuralfeed.game;

/** Per-frame player intent, written by the touch layer and read by the world. */
public final class Input {
    public float jx, jy, mag;
    public boolean dash, act;
    public final boolean[] ab = new boolean[3];

    public void clearEvents() { dash = false; act = false; ab[0] = ab[1] = ab[2] = false; }
}
