package com.neuralfeed.game;

/** Typewriter dialogue ticker shared by hub and gameplay. */
public final class Dialogue {
    public static final int SYS = 0, AI = 1;

    public interface Voice { void blip(int speaker, int index); }

    private final String[] q = new String[6];
    private final int[] qs = new int[6];
    private int qn;
    public String cur = "";
    public int speaker;
    public float shown, hold;
    public boolean active;
    private int lastIdx = -1;

    public void say(int spk, String text) {
        if (text == null || text.length() == 0) return;
        if (qn == q.length) {
            for (int i = 1; i < qn; i++) { q[i - 1] = q[i]; qs[i - 1] = qs[i]; }
            qn--;
        }
        q[qn] = text; qs[qn] = spk; qn++;
    }

    public void clear() { qn = 0; active = false; }

    public void update(float dt, Voice v) {
        if (!active) {
            if (qn == 0) return;
            cur = q[0]; speaker = qs[0];
            for (int i = 1; i < qn; i++) { q[i - 1] = q[i]; qs[i - 1] = qs[i]; }
            qn--;
            active = true; shown = 0; lastIdx = -1;
            hold = 1.7f + cur.length() * 0.03f + (qn > 0 ? -0.5f : 0f);
        }
        int len = cur.length();
        if (shown < len) {
            shown += dt * 38f;
            int idx = (int) shown;
            if (idx > len) idx = len;
            while (lastIdx < idx - 1) {
                lastIdx++;
                char c = cur.charAt(lastIdx);
                if (c != ' ' && (lastIdx & 1) == 0 && v != null) v.blip(speaker, lastIdx);
            }
        } else {
            hold -= dt;
            if (hold <= 0) active = false;
        }
    }

    public int visible() { int n = (int) shown; return n > cur.length() ? cur.length() : n; }

    public float alpha() {
        if (!active) return 0f;
        if (shown < cur.length()) return 1f;
        return hold < 0.4f ? Math.max(0f, hold / 0.4f) : 1f;
    }
}
