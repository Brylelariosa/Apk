package com.neuralfeed.ui;

import android.graphics.Canvas;
import android.graphics.Paint;

import com.neuralfeed.core.Mx;
import com.neuralfeed.data.Profile;
import com.neuralfeed.meta.Defs;
import com.neuralfeed.render.Gfx;
import com.neuralfeed.render.Hud;
import com.neuralfeed.render.Theme;
import com.neuralfeed.render.Ui;

/** Pause -> Customize HUD: drag controls, resize them, change opacity. Lives off the gameplay screen on purpose. */
public final class HudEditorScreen extends Screen {
    private final Screen back;
    private int sel = Defs.H_JOY, dragId = -1;
    private boolean panelTouch;

    public HudEditorScreen(App app, Screen back) { super(app); this.back = back; }

    private float panelBottom() { return app.topInset + 262f * app.gfx.dp; }

    @Override public void draw(Canvas c) {
        Gfx g = app.gfx;
        Ui ui = app.ui;
        Theme th = app.wr.th;
        Profile pf = app.pf;
        Hud hud = app.hud;
        float dp = g.dp;
        int w = app.w, h = app.h;
        ui.begin();
        c.drawColor(th.bg);
        float sp = 36f * dp;
        for (float x = 0; x < w; x += sp) g.lb.line(x, 0, x, h);
        for (float y = 0; y < h; y += sp) g.lb.line(0, y, w, y);
        g.line.setStrokeWidth(dp * 0.6f); g.line.setColor(Gfx.alpha(th.grid, 130));
        g.lb.lines(c, g.line);
        for (int el = 0; el < Defs.H_N; el++) {
            float cx = hud.cx(pf, el, w), cy = hud.cy(pf, el, h), r = hud.rad(pf, el);
            float a = Math.max(0.4f, hud.alphaOf(pf, el));
            boolean on = el == sel;
            g.circle(c, cx, cy, r, Gfx.alpha(th.accent, (int) ((on ? 40 : 16) * a)));
            g.ring(c, cx, cy, r, (on ? 2.4f : 1.4f) * dp, Gfx.alpha(on ? th.data : th.text, (int) (200 * a)));
            if (el == Defs.H_JOY) g.circle(c, cx, cy, r * 0.4f, Gfx.alpha(th.accent, (int) (120 * a)));
            String lab = el == Defs.H_JOY ? "STICK" : el == Defs.H_DASH ? "DASH" : el == Defs.H_CTX ? "ACT" : "A" + (el - Defs.H_AB1 + 1);
            g.text(c, lab, cx, cy + 4f * dp, 11f, Gfx.alpha(th.text, (int) (230 * a)), Paint.Align.CENTER, g.condB);
        }
        // panel
        float pb = panelBottom();
        g.rectFill(c, 0, 0, w, pb, Gfx.alpha(0xFF000000, 205));
        g.rectFill(c, 0, pb, w, dp, Gfx.alpha(th.text, 40));
        float x = 24f * dp, bw = w - 48f * dp, y = app.topInset + 30f * dp;
        g.tracked(c, "CUSTOMIZE HUD", w * 0.5f, y, 13f, 0.35f, th.text, Paint.Align.CENTER, g.condB);
        g.text(c, "Drag a control to move it.  Selected: " + Defs.H_NAMES[sel], w * 0.5f, y + 20f * dp, 12.5f, Gfx.alpha(th.text, 170), Paint.Align.CENTER, g.cond);
        y += 50f * dp;
        float sz = (pf.hud[sel * 4 + 2] - 0.6f) / 1.1f;
        sz = ui.slider(c, 601, "Size", x, y, bw, sz, th.accent, th.text);
        pf.hud[sel * 4 + 2] = 0.6f + sz * 1.1f;
        y += 52f * dp;
        float op = (pf.hud[sel * 4 + 3] - 0.2f) / 0.8f;
        op = ui.slider(c, 602, "Opacity", x, y, bw, op, th.accent, th.text);
        pf.hud[sel * 4 + 3] = 0.2f + op * 0.8f;
        y += 52f * dp;
        float hw = (bw - 10f * dp) * 0.5f;
        ui.button(c, 603, "Reset HUD", x, y, hw, 44f * dp, true, Ui.ST_DANGER, th.accent, th.text, th.bg);
        ui.button(c, 604, "Done", x + hw + 10f * dp, y, hw, 44f * dp, true, Ui.ST_PRIMARY, th.accent, th.text, th.bg);
    }

    @Override public void down(float x, float y, int id) {
        if (y < panelBottom()) { panelTouch = true; app.ui.down(x, y); return; }
        panelTouch = false;
        Profile pf = app.pf;
        int best = -1;
        float bd = 1e9f;
        for (int el = 0; el < Defs.H_N; el++) {
            float dx = x - app.hud.cx(pf, el, app.w), dy = y - app.hud.cy(pf, el, app.h), d = Mx.len(dx, dy);
            if (d < app.hud.rad(pf, el) * 1.3f && d < bd) { bd = d; best = el; }
        }
        if (best >= 0) { sel = best; dragId = id; }
    }

    @Override public void move(float x, float y, int id) {
        if (panelTouch) { app.ui.move(x, y); return; }
        if (id != dragId) return;
        Profile pf = app.pf;
        pf.hud[sel * 4] = Mx.clamp(x / app.w, 0.04f, 0.96f);
        pf.hud[sel * 4 + 1] = Mx.clamp(y / app.h, 0.06f, 0.97f);
    }

    @Override public void up(float x, float y, int id) {
        if (panelTouch) {
            int hit = app.ui.up(x, y);
            panelTouch = false;
            if (hit == 603) { app.pf.resetHud(); app.audio.sfx(com.neuralfeed.audio.Sfx.UI_BUY, 0.8f); }
            else if (hit == 604) done();
            return;
        }
        if (id == dragId) { dragId = -1; app.pf.sanitize(); }
    }

    @Override public boolean back() { done(); return true; }

    private void done() { app.pf.sanitize(); app.saveNow(); app.setScreen(back); }
}
