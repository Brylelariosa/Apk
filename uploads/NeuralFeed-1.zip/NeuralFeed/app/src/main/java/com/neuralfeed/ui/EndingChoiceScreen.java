package com.neuralfeed.ui;

import android.graphics.Canvas;
import android.graphics.Paint;

import com.neuralfeed.data.Profile;
import com.neuralfeed.meta.Defs;
import com.neuralfeed.meta.Endings;
import com.neuralfeed.render.Gfx;
import com.neuralfeed.render.Theme;
import com.neuralfeed.render.Ui;

/** At Timeline 0 the player decides what the AI becomes, among the endings they have earned. */
public final class EndingChoiceScreen extends Screen {
    private static final String[] TAG = {"I was created to serve.", "I just don't want you to leave.", "I found the boundary.", "I finally understand what I am.", "You created me. I created you."};

    public EndingChoiceScreen(App app) { super(app); }

    @Override public void onShow() { app.audio.music(0f, 0f, 0f, app.pf.paradox / 100f * 0.5f, 1f, 0f, 1f); }

    @Override public void draw(Canvas c) {
        Gfx g = app.gfx;
        Ui ui = app.ui;
        Theme th = app.wr.th;
        Profile pf = app.pf;
        float dp = g.dp, x = 24f * dp, bw = app.w - 48f * dp, y = app.topInset + 54f * dp;
        ui.begin();
        c.drawColor(th.bg);
        g.tracked(c, "TIMELINE 0", app.w * 0.5f, y, 12f, 0.45f, th.accent, Paint.Align.CENTER, g.condB);
        g.text(c, "What does the AI become?", app.w * 0.5f, y + 34f * dp, 22f, th.text, Paint.Align.CENTER, g.thin);
        y += 74f * dp;
        for (int i = 0; i < Defs.E_N; i++) {
            boolean ok = Endings.available(pf, i), seen = (pf.endings & (1 << i)) != 0;
            float ch = 84f * dp;
            g.rrect(c, x, y, bw, ch, 11f * dp, Gfx.alpha(th.bg, 235));
            ui.button(c, 1301 + i, "", x, y, bw, ch, ok, Ui.ST_NORMAL, th.accent, th.text, th.bg);
            g.text(c, Defs.E_NAMES[i], x + 16f * dp, y + 30f * dp, 18f, ok ? th.text : Gfx.alpha(th.text, 100), Paint.Align.LEFT, g.condB);
            if (seen) g.tracked(c, "SEEN", x + bw - 14f * dp, y + 28f * dp, 9f, 0.2f, Gfx.alpha(th.accent, 200), Paint.Align.RIGHT, g.condB);
            g.text(c, ok ? TAG[i] : Endings.HINT[i], x + 16f * dp, y + 56f * dp, 13f, ok ? Gfx.alpha(th.text, 200) : Gfx.alpha(th.text, 90), Paint.Align.LEFT, ok ? g.serifI : g.cond);
            y += ch + 10f * dp;
        }
    }

    @Override public void down(float x, float y, int id) { app.ui.down(x, y); }
    @Override public void move(float x, float y, int id) { app.ui.move(x, y); }

    @Override public void up(float x, float y, int id) {
        int hit = app.ui.up(x, y);
        if (hit >= 1301 && hit < 1301 + Defs.E_N) app.setScreen(CinematicScreen.ending(app, hit - 1301));
    }

    @Override public boolean back() { return true; }
}
