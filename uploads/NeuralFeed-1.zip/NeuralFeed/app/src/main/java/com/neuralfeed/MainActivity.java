package com.neuralfeed;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

import com.neuralfeed.ui.App;
import com.neuralfeed.ui.Platform;

/** Thin Android shell: window setup, lifecycle, clipboard/share/vibration. All game code lives behind App. */
public final class MainActivity extends Activity implements Platform {
    private GameView view;
    private App app;
    private Vibrator vib;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }
        immersive();
        vib = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        float density = getResources().getDisplayMetrics().density;
        app = new App(this, getFilesDir(), density);
        view = new GameView(this, app);
        setContentView(view);
    }

    private void immersive() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override
    protected void onResume() {
        super.onResume();
        immersive();
        app.onResume();
        view.resume();
    }

    @Override
    protected void onPause() {
        view.pause();
        app.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        app.onDestroy();
        super.onDestroy();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) immersive();
    }

    @Override
    public void onBackPressed() {
        if (!app.back()) super.onBackPressed();
    }

    // ---- Platform ----

    @Override
    public void vibrate(int ms) {
        if (vib == null || !vib.hasVibrator()) return;
        try {
            if (Build.VERSION.SDK_INT >= 26) vib.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE));
            else vib.vibrate(ms);
        } catch (RuntimeException ignored) { /* haptics are optional */ }
    }

    @Override
    public void copy(String text) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("NEURAL//FEED save", text));
    }

    @Override
    public String paste() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm == null || !cm.hasPrimaryClip()) return "";
        ClipData d = cm.getPrimaryClip();
        if (d == null || d.getItemCount() == 0) return "";
        CharSequence cs = d.getItemAt(0).coerceToText(this);
        return cs == null ? "" : cs.toString();
    }

    @Override
    public void share(String text) {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TEXT, text);
        startActivity(Intent.createChooser(i, "Export save"));
    }

    @Override
    public void toast(final String text) {
        runOnUiThread(new Runnable() {
            @Override public void run() { Toast.makeText(MainActivity.this, text, Toast.LENGTH_SHORT).show(); }
        });
    }
}
