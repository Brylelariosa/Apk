package com.neuralfeed.game;

/** Pooled enemy. All kinds share one flat structure; kind-specific meaning of the aux fields lives in EnemyAI/BossAI. */
public final class Enemy {
    public boolean alive, prot, immune;
    public int kind, id, st, ph, gen, elite, bossId;
    public float x, y, vx, vy, kx, ky, r, hp, maxHp, speed, dmg, val, rot, flash;
    public float t, t2, t3, ax, ay, contactCd, conv, slowT, phase;
    public double carry;

    public void reset(int k) {
        alive = true; prot = false; immune = false;
        kind = k; st = 0; ph = 0; gen = 0; elite = 0; bossId = 0;
        vx = vy = kx = ky = 0; flash = 0; t = t2 = t3 = ax = ay = 0; contactCd = 0.3f; conv = 0; slowT = 0; phase = 0;
        carry = 0; rot = 0;
    }
}
