package com.neuralfeed.game;

/** Enemy kind ids and base stat tables. */
public final class Kinds {
    private Kinds() {}

    public static final int DRONE = 0, VIRUS = 1, FIREWALL = 2, LEECH = 3, HUNTER = 4, CORRUPT = 5, SECURITY = 6, EATER = 7,
            UNKNOWN = 8, NEST = 9, MINI = 10, ECHO = 11, MEMFRAG = 12, FRIEND = 13, BOSS = 14, N = 15;

    public static final String[] NAME = {"Process drone", "Virus", "Firewall node", "Data leech", "Hunter process", "Corrupted AI",
            "Security system", "Memory eater", "Unknown process", "Enemy nest", "Fragment", "Echo", "Memory fragment", "Lost process", "Boss"};

    //                              drn    vir    fwl    lch    hnt    cor    sec    eat    unk    nst    min    ech    mfr    frd    boss
    public static final float[] R = {0.24f, 0.17f, 0.46f, 0.22f, 0.26f, 0.30f, 0.40f, 0.42f, 0.28f, 0.58f, 0.11f, 0.26f, 0.20f, 0.24f, 1.25f};
    public static final float[] HP = {12, 6, 70, 16, 28, 45, 70, 110, 38, 130, 3, 22, 18, 40, 1};
    public static final float[] SPD = {1.9f, 3.3f, 0, 2.6f, 2.4f, 1.6f, 1.4f, 1.5f, 2.2f, 0, 3.6f, 3.0f, 0, 1.8f, 0};
    public static final float[] DMG = {7, 5, 0, 3, 12, 8, 6, 9, 10, 0, 3, 9, 5, 0, 12};
    public static final float[] VAL = {1.0f, 0.8f, 4, 2, 3, 5, 5, 7, 8, 10, 0.3f, 1.5f, 3, 0, 0};
    public static final int[] MIN_TIER = {0, 0, 1, 1, 2, 3, 3, 4, 5};

    public static boolean stationary(int k) { return k == FIREWALL || k == NEST || k == MEMFRAG || k == BOSS; }
}
