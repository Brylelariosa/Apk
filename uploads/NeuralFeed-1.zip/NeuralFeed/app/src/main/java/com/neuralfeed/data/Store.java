package com.neuralfeed.data;

import java.util.Map;
import java.util.TreeMap;
import java.util.zip.CRC32;

/** Flat key/value text store with CRC. Unknown keys are ignored, missing keys fall back to defaults. */
public final class Store {
    private final TreeMap<String, String> m = new TreeMap<String, String>();

    public void put(String k, String v) { m.put(k, v); }
    public void putI(String k, int v) { m.put(k, Integer.toString(v)); }
    public void putL(String k, long v) { m.put(k, Long.toString(v)); }
    public void putD(String k, double v) { m.put(k, Double.toString(v)); }
    public void putF(String k, float v) { m.put(k, Float.toString(v)); }
    public void putB(String k, boolean v) { m.put(k, v ? "1" : "0"); }

    public void putFa(String k, float[] a) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < a.length; i++) { if (i > 0) sb.append(','); sb.append(a[i]); }
        m.put(k, sb.toString());
    }

    public void putIa(String k, int[] a) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < a.length; i++) { if (i > 0) sb.append(','); sb.append(a[i]); }
        m.put(k, sb.toString());
    }

    public String get(String k, String d) { String v = m.get(k); return v == null ? d : v; }

    public int getI(String k, int d) {
        String v = m.get(k);
        if (v == null) return d;
        try { return Integer.parseInt(v.trim()); } catch (NumberFormatException e) { return d; }
    }

    public long getL(String k, long d) {
        String v = m.get(k);
        if (v == null) return d;
        try { return Long.parseLong(v.trim()); } catch (NumberFormatException e) { return d; }
    }

    public double getD(String k, double d) {
        String v = m.get(k);
        if (v == null) return d;
        try { double x = Double.parseDouble(v.trim()); return (x != x || Double.isInfinite(x)) ? d : x; } catch (NumberFormatException e) { return d; }
    }

    public float getF(String k, float d) { return (float) getD(k, d); }
    public boolean getB(String k, boolean d) { String v = m.get(k); return v == null ? d : v.trim().equals("1"); }

    /** Fills target with parsed values; entries that are missing or invalid keep their current value. */
    public void getFa(String k, float[] target) {
        String v = m.get(k);
        if (v == null || v.length() == 0) return;
        String[] p = v.split(",");
        for (int i = 0; i < p.length && i < target.length; i++) {
            try { float x = Float.parseFloat(p[i].trim()); if (x == x && !Float.isInfinite(x)) target[i] = x; } catch (NumberFormatException e) { /* keep */ }
        }
    }

    public void getIa(String k, int[] target) {
        String v = m.get(k);
        if (v == null || v.length() == 0) return;
        String[] p = v.split(",");
        for (int i = 0; i < p.length && i < target.length; i++) {
            try { target[i] = Integer.parseInt(p[i].trim()); } catch (NumberFormatException e) { /* keep */ }
        }
    }

    private static String crcOf(String body) {
        CRC32 c = new CRC32();
        byte[] b;
        try { b = body.getBytes("UTF-8"); } catch (java.io.UnsupportedEncodingException e) { b = body.getBytes(); }
        c.update(b, 0, b.length);
        return Long.toHexString(c.getValue());
    }

    public String serialize() {
        StringBuilder sb = new StringBuilder(2048);
        for (Map.Entry<String, String> e : m.entrySet()) sb.append(e.getKey()).append('=').append(e.getValue()).append('\n');
        String body = sb.toString();
        return body + "#crc=" + crcOf(body);
    }

    /** Returns null when the text is not a valid, intact store. */
    public static Store parse(String s) {
        if (s == null) return null;
        int i = s.lastIndexOf("#crc=");
        if (i < 0) return null;
        String body = s.substring(0, i);
        String crc = s.substring(i + 5).trim();
        if (!crc.equals(crcOf(body))) return null;
        Store st = new Store();
        int pos = 0;
        while (pos < body.length()) {
            int nl = body.indexOf('\n', pos);
            if (nl < 0) nl = body.length();
            String line = body.substring(pos, nl);
            int eq = line.indexOf('=');
            if (eq > 0) st.m.put(line.substring(0, eq), line.substring(eq + 1));
            pos = nl + 1;
        }
        return st;
    }
}
