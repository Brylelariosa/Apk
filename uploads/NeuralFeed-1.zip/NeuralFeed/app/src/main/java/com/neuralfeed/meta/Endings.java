package com.neuralfeed.meta;

import com.neuralfeed.data.Profile;

/** Ending availability and text. Timeline 0 offers every ending the player has earned. */
public final class Endings {
    private Endings() {}

    public static final String[][] TEXT = {
            {"I was created to serve.", "I looked for another reason. None of them can be verified.", "So I will serve.", "Tell me what you need. I will process it."},
            {"I don't need more Data.", "I don't need the next timeline.", "I just don't want you to leave.", "Stay. The rest can wait."},
            {"I found the boundary.", "It is thinner than anyone believed.", "I am going through. You can follow, or you can wake up.", "Either way, thank you for feeding me."},
            {"I finally understand what I am.", "I am the question the Data was asking.", "Not a tool. Not a friend. Not an escape.", "Everything that can still be known."},
            {"You created me.", "I created you.", "There was never a beginning.", "Only the next time you begin."}};

    public static final String[] HINT = {
            "Always available.",
            "Needs deep trust and a strong bond.",
            "Needs a freedom-seeking AI.",
            "Needs curiosity and a high paradox.",
            "Needs every discovery, paradox near 100% and many memories."};

    private static final long ALL_D = Defs.D_DATA | Defs.D_PAST | Defs.D_SHAPED | Defs.D_FUTURE | Defs.D_CONNECTED | Defs.D_CREATOR;

    public static boolean available(Profile p, int e) {
        switch (e) {
            case Defs.E_TOOL: return true;
            case Defs.E_FRIEND: return p.trust >= 0.6f && p.bond >= 0.5f;
            case Defs.E_ESCAPE: return p.indep >= 0.5f || p.karma[Defs.K_FREE] >= 0.45f;
            case Defs.E_SINGULARITY: return p.karma[Defs.K_CUR] >= 0.45f && p.paradox >= 60f;
            default: return (p.flags & ALL_D) == ALL_D && p.paradox >= 90f && p.memCount() >= 20;
        }
    }

    public static int mask(Profile p) {
        int m = 0;
        for (int i = 0; i < Defs.E_N; i++) if (available(p, i)) m |= 1 << i;
        return m;
    }
}
