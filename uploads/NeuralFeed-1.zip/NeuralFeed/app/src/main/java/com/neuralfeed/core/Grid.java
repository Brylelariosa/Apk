package com.neuralfeed.core;

import java.util.Arrays;

/** Uniform spatial hash for entity indices. Rebuilt every frame without allocating. */
public final class Grid {
    private final float inv;
    private final int cols, rows;
    private final int[] head, nxt;

    public Grid(float maxW, float maxH, float cell, int cap) {
        inv = 1f / cell;
        cols = (int) (maxW * inv) + 2;
        rows = (int) (maxH * inv) + 2;
        head = new int[cols * rows];
        nxt = new int[cap];
        clear();
    }

    public void clear() { Arrays.fill(head, -1); }

    private int cx(float x) { int c = (int) (x * inv); return c < 0 ? 0 : (c >= cols ? cols - 1 : c); }
    private int cy(float y) { int c = (int) (y * inv); return c < 0 ? 0 : (c >= rows ? rows - 1 : c); }

    public void insert(int idx, float x, float y) {
        int c = cy(y) * cols + cx(x);
        nxt[idx] = head[c];
        head[c] = idx;
    }

    /** Candidate indices in cells touched by the circle; callers do the exact test. */
    public int query(float x, float y, float r, int[] out) {
        int c0 = cx(x - r), c1 = cx(x + r), r0 = cy(y - r), r1 = cy(y + r), n = 0;
        for (int j = r0; j <= r1; j++) {
            for (int i = c0; i <= c1; i++) {
                for (int k = head[j * cols + i]; k >= 0; k = nxt[k]) {
                    if (n < out.length) out[n++] = k;
                }
            }
        }
        return n;
    }
}
