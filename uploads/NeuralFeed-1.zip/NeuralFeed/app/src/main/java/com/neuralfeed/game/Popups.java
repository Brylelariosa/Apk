package com.neuralfeed.game;

import com.neuralfeed.core.Fmt;

/** Floating numbers/words. Text lives in preallocated char buffers, so spawning never allocates. */
public final class Popups {
    public static final int N = 28;
    public final float[] x = new float[N], y = new float[N], vy = new float[N], life = new float[N], max = new float[N], size = new float[N];
    public final int[] col = new int[N], len = new int[N];
    public final char[][] txt = new char[N][16];
    public final boolean[] on = new boolean[N];
    private int cursor;

    public void clear() { for (int i = 0; i < N; i++) on[i] = false; }

    private int slot() { int i = cursor % N; cursor = i + 1; return i; }

    public void addNum(float px, float py, double v, int color, float sz) {
        int i = slot();
        len[i] = Fmt.chars(v, txt[i]);
        init(i, px, py, color, sz);
    }

    public void addText(float px, float py, String s, int color, float sz) {
        int i = slot();
        int n = Math.min(s.length(), 15);
        for (int k = 0; k < n; k++) txt[i][k] = s.charAt(k);
        len[i] = n;
        init(i, px, py, color, sz);
    }

    private void init(int i, float px, float py, int color, float sz) {
        on[i] = true; x[i] = px; y[i] = py; vy[i] = -1.1f; life[i] = max[i] = 0.7f; col[i] = color; size[i] = sz;
    }

    public void update(float dt) {
        for (int i = 0; i < N; i++) {
            if (!on[i]) continue;
            life[i] -= dt;
            if (life[i] <= 0) { on[i] = false; continue; }
            y[i] += vy[i] * dt;
            vy[i] *= 1f - 1.5f * dt;
        }
    }
}
