package com.neuralfeed.ui;

import android.graphics.Canvas;
import android.graphics.Paint;

import com.neuralfeed.core.Fmt;
import com.neuralfeed.data.Profile;
import com.neuralfeed.meta.Prestige;
import com.neuralfeed.meta.Timelines;
import com.neuralfeed.render.Gfx;
import com.neuralfeed.render.Theme;
import com.neuralfeed.render.Ui;

/** Timeline ladder, paradox and the Temporal Core (prestige). */
final class TimeTab extends Tab {
    private float armed;

    TimeTab(App app, HubScreen hub) { super(app, hub); }

    @Override void draw(Canvas c, float x, float y, float w, float h, float scroll) {
        Gfx g = app.gfx;
        Ui ui = app.ui;
        Theme th = app.wr.th;
        Profile pf = app.pf;
        float dp = g.dp, yy = y - scroll + 8f * dp, cx = x + w * 0.5f;
        if (armed > 0f) armed -= 1f / 60f;
        // paradox
        g.tracked(c, "PARADOX", x, yy + 6f * dp, 10f, 0.3f, Gfx.alpha(th.text, 140), Paint.Align.LEFT, g.cond);
        g.text(c, Prestige.paradoxZone(pf.paradox), x + w, yy + 6f * dp, 12.5f, pf.paradox >= 50f ? th.hostile : Gfx.alpha(th.text, 200), Paint.Align.RIGHT, g.cond);
        g.rectFill(c, x, yy + 16f * dp, w, 3f * dp, Gfx.alpha(th.text, 28));
        g.rectFill(c, x, yy + 16f * dp, w * pf.paradox / 100f, 3f * dp, pf.paradox >= 50f ? th.hostile : th.accent);
        g.text(c, (int) pf.paradox + "%", x, yy + 38f * dp, 12f, Gfx.alpha(th.text, 170), Paint.Align.LEFT, g.cond);
        yy += 62f * dp;
        // temporal core
        g.text(c, "Temporal core", x, yy, 15f, th.text, Paint.Align.LEFT, g.condB);
        yy += 8f * dp;
        double cost = Timelines.temporalCost(pf.timeline);
        if (pf.timeline >= 10) {
            g.text(c, "Timeline 0 reached. Nothing is left to travel to.", x, yy + 20f * dp, 12.5f, Gfx.alpha(th.text, 170), Paint.Align.LEFT, g.cond);
            yy += 40f * dp;
        } else {
            boolean b1 = pf.bossDone, b2 = pf.bank >= cost;
            g.text(c, (b1 ? "\u2713  " : "\u2717  ") + "Defeat the boss of this timeline", x, yy + 22f * dp, 13.5f, b1 ? th.accent : Gfx.alpha(th.text, 160), Paint.Align.LEFT, g.cond);
            g.text(c, (b2 ? "\u2713  " : "\u2717  ") + "Data  " + Fmt.num(pf.bank) + " / " + Fmt.num(cost), x, yy + 44f * dp, 13.5f, b2 ? th.accent : Gfx.alpha(th.text, 160), Paint.Align.LEFT, g.cond);
            g.text(c, "Echoes " + pf.echoes + "   (+" + Timelines.echoGain(pf) + " on travel)", x, yy + 66f * dp, 12.5f, Gfx.alpha(th.text, 160), Paint.Align.LEFT, g.cond);
            g.text(c, "Echo bonus: +" + (int) (12f * Math.pow(pf.echoes, 0.9)) + "% power, +" + (int) (10f * Math.pow(pf.echoes, 0.9)) + "% Data", x, yy + 84f * dp, 12.5f, Gfx.alpha(th.text, 160), Paint.Align.LEFT, g.cond);
            yy += 100f * dp;
            boolean can = Timelines.canActivate(pf);
            String lab = armed > 0f ? "CONFIRM \u2014 COLLAPSE THIS TIMELINE" : "ACTIVATE TEMPORAL CORE";
            if (vis(yy, 52f * dp, y, h)) ui.button(c, 401, lab, x, yy, w, 52f * dp, can, armed > 0f ? Ui.ST_DANGER : Ui.ST_PRIMARY, th.accent, th.text, th.bg);
            yy += 62f * dp;
            if (can) { g.text(c, "Your Data and upgrades reset. Memories and personality remain.", cx, yy, 11.5f, Gfx.alpha(th.text, 140), Paint.Align.CENTER, g.cond); yy += 22f * dp; }
        }
        yy += 10f * dp;
        // ladder
        g.text(c, "Timelines", x, yy, 15f, th.text, Paint.Align.LEFT, g.condB);
        yy += 10f * dp;
        for (int i = 0; i < Timelines.YEAR.length; i++) {
            boolean past = i < pf.timeline, cur = i == pf.timeline, fut = i > pf.timeline;
            float ry = yy + 20f * dp;
            if (cur) g.rrect(c, x - 6f * dp, yy + 4f * dp, w + 12f * dp, 38f * dp, 8f * dp, Gfx.alpha(th.accent, 26));
            g.circle(c, x + 6f * dp, ry + 6f * dp, cur ? 5f * dp : 3f * dp, cur ? th.accent : Gfx.alpha(th.text, past ? 160 : 60));
            if (i < Timelines.YEAR.length - 1) g.seg(c, x + 6f * dp, ry + 12f * dp, x + 6f * dp, ry + 36f * dp, dp, Gfx.alpha(th.text, 40));
            g.text(c, fut && i > pf.timeline + 1 ? "????" : Timelines.YEAR[i], x + 24f * dp, ry + 10f * dp, 16f, fut ? Gfx.alpha(th.text, 90) : th.text, Paint.Align.LEFT, g.condB);
            g.text(c, fut && i > pf.timeline + 1 ? "" : Timelines.BLURB[i], x + 96f * dp, ry + 10f * dp, 12f, Gfx.alpha(th.text, fut ? 70 : 170), Paint.Align.LEFT, g.cond);
            yy += 40f * dp;
        }
        yy += 20f * dp;
        contentH = yy + scroll - y;
    }

    @Override void click(int id) {
        if (id != 401) return;
        Profile pf = app.pf;
        if (!Timelines.canActivate(pf)) { app.audio.sfx(com.neuralfeed.audio.Sfx.UI_DENY, 0.8f); return; }
        if (armed <= 0f) { armed = 4f; app.tap(); return; }
        armed = 0f;
        app.saveNow();
        app.setScreen(CinematicScreen.rewind(app));
    }
}
