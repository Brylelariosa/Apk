package com.neuralfeed.ui;

/** Things only the Android activity can do. Implemented by MainActivity. */
public interface Platform {
    void vibrate(int ms);
    void copy(String text);
    String paste();
    void share(String text);
    void toast(String text);
}
