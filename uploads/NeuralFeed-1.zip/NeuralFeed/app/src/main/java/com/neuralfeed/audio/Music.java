package com.neuralfeed.audio;

import java.util.Arrays;

import static com.neuralfeed.audio.Synth.hz;

/**
 * Generative layered music rendered in real time. Layers fade in with intensity (rhythm), danger (tension drone),
 * boss (heavy sub), paradox (glitch/stutter), and fall away for story moments or time travel.
 */
public final class Music {
    private static final int SR = Synth.SR, NV = 14;
    private static final int[] PROG = {0, 8, 3, 10};
    private static final int[] PENT = {0, 3, 5, 7, 10, 12, 15, 17};

    public volatile float tInt, tDanger, tBoss, tPara, tMinimal, tDecon, timeScale = 1f;
    public volatile int root = 2;
    public volatile boolean enabled = true;

    private float intensity, danger, boss, para, minimal, decon;
    private double acc = 1e9;
    private int step = 15, bar = -1, chord;
    private final float[] vf = new float[NV], vph = new float[NV], vamp = new float[NV], vdec = new float[NV], vramp = new float[NV],
            vatk = new float[NV], vlpk = new float[NV], vlps = new float[NV], vfm = new float[NV], vfmin = new float[NV];
    private final int[] vsh = new int[NV];
    private final boolean[] von = new boolean[NV];
    private int rs = 0x2468ace;
    private final float[] tmp = new float[Mixer.CH];

    private float rnd() { rs ^= rs << 13; rs ^= rs >>> 17; rs ^= rs << 5; return (rs >>> 8) * (1f / 16777216f); }

    private void noteOn(float f, int shape, float amp, float atk, float decSec, float lp, float fm, float fmin) {
        int slot = 0;
        float low = 1e9f;
        for (int i = 0; i < NV; i++) {
            if (!von[i]) { slot = i; break; }
            if (vamp[i] < low) { low = vamp[i]; slot = i; }
        }
        von[slot] = true; vf[slot] = f; vph[slot] = 0f; vamp[slot] = amp; vsh[slot] = shape;
        vdec[slot] = (float) Math.pow(0.001, 1.0 / (decSec * SR));
        vramp[slot] = atk > 0f ? 0f : 1f; vatk[slot] = atk > 0f ? 1f / (atk * SR) : 1f;
        vlpk[slot] = lp > 0f ? 1f - (float) Math.exp(-6.2831853 * lp / SR) : 1f; vlps[slot] = 0f;
        vfm[slot] = fm; vfmin[slot] = fmin;
    }

    private void stepEvent() {
        step = (step + 1) & 15;
        int s = step;
        if (s == 0) { bar++; chord = PROG[bar & 3]; }
        if (decon > 0.05f && rnd() < decon) return;
        int r = root + chord;
        float mini = 1f - minimal;
        if (s == 0) {
            float a = 0.05f;
            noteOn(hz(r - 21), Synth.SAW, a, 0.5f, 2.6f, 900f, 1f, 0f);
            noteOn(hz(r - 18), Synth.SAW, a, 0.6f, 2.6f, 900f, 1f, 0f);
            noteOn(hz(r - 14), Synth.SAW, a, 0.7f, 2.6f, 900f, 1f, 0f);
            if (danger > 0.15f) {
                noteOn(hz(r - 21), Synth.SAW, 0.05f * danger * mini, 0.4f, 2.4f, 700f, 1f, 0f);
                noteOn(hz(r - 20), Synth.SAW, 0.05f * danger * mini, 0.4f, 2.4f, 700f, 1f, 0f);
            }
            if (boss > 0.3f) noteOn(hz(r - 33), Synth.SQR, 0.08f * boss * mini, 0f, 1.2f, 300f, 1f, 0f);
        }
        if (mini < 0.3f) return;
        if (s == 0 || s == 8 || (intensity > 0.5f && (s == 6 || s == 14))) {
            float a = (0.12f + 0.06f * intensity) * mini;
            if (boss > 0.3f) noteOn(hz(r - 33), Synth.SQR, a * 0.7f, 0f, 0.35f, 500f, 1f, 0f);
            else noteOn(hz(r - 33), Synth.SINE, a, 0f, 0.4f, 0f, 1f, 0f);
        }
        if (intensity > 0.2f && ((s & 1) == 0 || intensity > 0.6f)) {
            int idx = (int) (Math.abs((bar & 3) * 131 + s * 37 + (s % 3) * 11) % PENT.length);
            float lvl = Math.min(1f, (intensity - 0.2f) / 0.6f);
            float f = hz(r - 9 + PENT[idx] + ((s & 1) == 1 && intensity > 0.8f ? 12 : 0));
            noteOn(f, boss > 0.4f ? Synth.SQR : Synth.TRI, 0.07f * lvl * mini, 0f, 0.22f, 3500f, 1f, 0f);
        }
        if (intensity > 0.45f && (s & 3) == 0) {
            float lvl = Math.min(1f, (intensity - 0.4f) / 0.5f);
            noteOn(150f, Synth.SINE, 0.4f * lvl * mini, 0f, 0.18f, 0f, 0.99945f, 38f);
        }
        if (intensity > 0.55f && (s & 1) == 1) noteOn(0f, 4, 0.05f * mini, 0f, 0.05f, 9000f, 1f, 0f);
        if ((boss > 0.4f || intensity > 0.85f) && (s == 4 || s == 12)) {
            noteOn(0f, 4, 0.12f * mini, 0f, 0.14f, 4500f, 1f, 0f);
            noteOn(190f, Synth.TRI, 0.12f * mini, 0f, 0.1f, 0f, 0.9997f, 120f);
        }
    }

    /** Adds n samples of music (scaled by vol) into mix. */
    public void render(float[] mix, int n, float vol) {
        if (!enabled) return;
        float k = Math.min(1f, n / (float) SR * 2.5f);
        intensity += (tInt - intensity) * k; danger += (tDanger - danger) * k; boss += (tBoss - boss) * k;
        para += (tPara - para) * k; minimal += (tMinimal - minimal) * k; decon += (tDecon - decon) * k;
        float ts = timeScale;
        double sps = SR * 60.0 / (92.0 * 4.0);
        Arrays.fill(tmp, 0, n, 0f);
        for (int i = 0; i < n; i++) {
            acc += ts;
            if (acc >= sps) { acc -= sps; stepEvent(); }
            float s = 0f;
            for (int v = 0; v < NV; v++) {
                if (!von[v]) continue;
                float o;
                float ph = vph[v] + vf[v] * ts / SR;
                if (ph >= 1f) ph -= (int) ph;
                vph[v] = ph;
                switch (vsh[v]) {
                    case Synth.SINE: o = (float) Math.sin(ph * 6.2831853f); break;
                    case Synth.TRI: o = ph < 0.5f ? 4f * ph - 1f : 3f - 4f * ph; break;
                    case Synth.SQR: o = ph < 0.5f ? 1f : -1f; break;
                    case Synth.SAW: o = 2f * ph - 1f; break;
                    default: o = rnd() * 2f - 1f; break;
                }
                if (vlpk[v] < 1f) { vlps[v] += vlpk[v] * (o - vlps[v]); o = vlps[v]; }
                float r = vramp[v];
                if (r < 1f) { r += vatk[v]; if (r > 1f) r = 1f; vramp[v] = r; } else vamp[v] *= vdec[v];
                s += o * vamp[v] * r;
                if (vfm[v] != 1f) { vf[v] *= vfm[v]; if (vf[v] < vfmin[v]) vf[v] = vfmin[v]; }
                if (r >= 1f && vamp[v] < 0.0008f) von[v] = false;
            }
            tmp[i] = s;
        }
        if (para > 0.15f) {
            for (int b = 0; b + 192 <= n; b += 256) if (rnd() < para * 0.25f) System.arraycopy(tmp, b, tmp, b + 96, 96);
            if (para > 0.4f) { float lv = 40f; for (int i = 0; i < n; i++) tmp[i] = Math.round(tmp[i] * lv) / lv; }
        }
        for (int i = 0; i < n; i++) mix[i] += tmp[i] * vol;
    }
}
