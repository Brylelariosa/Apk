package com.neuralfeed.meta;

/** Resolved AI statistics (permanent part). World applies temporary buffs on a copy. */
public final class CoreStats {
    public float power, rate, range, collect, maxHp, shield, shieldRegen, speed, dashCd, dataMult, crit, critMul, magnet;
    public float deep, edge, pressure, cascade, cache, haste, potency;
    // ideology perks
    public float dmgRed, healPerOrb, harvest, devourThr, dominate, chainShare, observe;
    public boolean guardian, predict, calculate, adaptive, execute, steal, chain, friendGuard;
    public int level;
    public float[] ideo = new float[4];

    public void copyFrom(CoreStats o) {
        power = o.power; rate = o.rate; range = o.range; collect = o.collect; maxHp = o.maxHp; shield = o.shield;
        shieldRegen = o.shieldRegen; speed = o.speed; dashCd = o.dashCd; dataMult = o.dataMult; crit = o.crit;
        critMul = o.critMul; magnet = o.magnet; deep = o.deep; edge = o.edge; pressure = o.pressure; cascade = o.cascade;
        cache = o.cache; haste = o.haste; potency = o.potency; dmgRed = o.dmgRed; healPerOrb = o.healPerOrb;
        harvest = o.harvest; devourThr = o.devourThr; dominate = o.dominate; chainShare = o.chainShare; observe = o.observe;
        guardian = o.guardian; predict = o.predict; calculate = o.calculate; adaptive = o.adaptive; execute = o.execute;
        steal = o.steal; chain = o.chain; friendGuard = o.friendGuard; level = o.level;
        System.arraycopy(o.ideo, 0, ideo, 0, 4);
    }
}
