package com.neuralfeed.game;

import com.neuralfeed.audio.Sfx;
import com.neuralfeed.core.Mx;
import com.neuralfeed.data.Profile;
import com.neuralfeed.meta.Defs;
import com.neuralfeed.meta.StatsCalc;

/** Abilities: they reshape the field rather than act as weapons. */
public final class AbilitySys {
    private AbilitySys() {}

    /** Ability id equipped in a slot, or -1 when empty/locked. */
    public static int slotAbility(Profile p, int slot) {
        if (slot >= StatsCalc.slotCount(p)) return -1;
        int a = p.slots[slot];
        if (a < 0 || !StatsCalc.abilityUnlocked(p, a)) return -1;
        return a;
    }

    public static float cooldown(World w, int ab) { return Defs.AB_CD[ab] * w.base.haste; }

    static void update(World w, float dt) {
        Player pl = w.pl;
        for (int k = 0; k < 3; k++) if (pl.abCd[k] > 0) pl.abCd[k] -= dt;
        for (int i = 0; i < pl.abT.length; i++) if (pl.abT[i] > 0) pl.abT[i] -= dt;
        boolean can = w.phase == World.P_FIGHT || w.phase == World.P_INTRO;
        for (int k = 0; k < 3; k++) {
            if (!w.in.ab[k]) continue;
            int a = slotAbility(w.pf, k);
            if (a >= 0 && pl.abCd[k] <= 0f && can) trigger(w, k, a);
        }
        float px = pl.x, py = pl.y;
        if (pl.abT[Defs.AB_IMPLOSION] > 0f) {
            int n = w.grid.query(px, py, 9f, w.tmp2);
            for (int i = 0; i < n; i++) {
                Enemy e = w.en[w.tmp2[i]];
                if (!e.alive || Kinds.stationary(e.kind) || e.kind == Kinds.FRIEND) continue;
                float dx = px - e.x, dy = py - e.y, d = Mx.len(dx, dy);
                if (d < 0.4f || d > 9f) continue;
                e.kx += dx / d * 42f * dt; e.ky += dy / d * 42f * dt;
            }
        }
        if (pl.abT[Defs.AB_FREEZE] > 0f) {
            float r = w.live.range * 1.35f;
            int n = w.grid.query(px, py, r + 1f, w.tmp2);
            for (int i = 0; i < n; i++) {
                Enemy e = w.en[w.tmp2[i]];
                if (e.alive && e.kind != Kinds.BOSS && Mx.len(e.x - px, e.y - py) < r) e.slowT = 0.2f;
            }
        }
    }

    static void trigger(World w, int slot, int a) {
        Player pl = w.pl;
        pl.abCd[slot] = cooldown(w, a);
        float pot = w.base.potency;
        float dur = Defs.AB_DUR[a] * pot;
        float px = pl.x, py = pl.y;
        w.env.vibrate(14);
        switch (a) {
            case Defs.AB_OVERCLOCK:
                pl.abT[a] = dur; w.env.sfx(Sfx.AB_OVERCLOCK, 1f);
                w.burst(Particles.SPARK, px, py, 24, 6f, 0.6f, 2.2f);
                break;
            case Defs.AB_EXPANSION:
                pl.abT[a] = dur; w.env.sfx(Sfx.AB_EXPAND, 1f);
                w.shockR = 0f; w.shockA = 0.8f;
                break;
            case Defs.AB_IMPLOSION:
                pl.abT[a] = dur; w.env.sfx(Sfx.AB_IMPLODE, 1f);
                w.shake(8f);
                break;
            case Defs.AB_STORM:
                w.stormT = dur; w.env.sfx(Sfx.AB_STORM, 1f);
                w.burst(Particles.DATA, px, py, 30, 7f, 0.7f, 2f);
                break;
            case Defs.AB_PULSE: {
                w.env.sfx(Sfx.AB_PULSE, 1f);
                w.shockR = 0f; w.shockA = 1f; w.shake(16f); w.hitStop = 0.06f;
                float r = w.live.range * 1.15f;
                int n = w.grid.query(px, py, r + 1.7f, w.tmp2);
                for (int i = 0; i < n; i++) {
                    Enemy e = w.en[w.tmp2[i]];
                    if (!e.alive || e.kind == Kinds.FRIEND) continue;
                    if (Mx.len(e.x - px, e.y - py) > r + e.r) continue;
                    boolean crit = w.rng.f() < w.live.crit;
                    float dmg = w.live.power * 5f * pot * (crit ? w.live.critMul : 1f);
                    w.hit(e, dmg, crit);
                    if (w.pf.dmgNums) w.pops.addNum(e.x, e.y - e.r, dmg, 0xFFFFE08A, 0.62f);
                }
                w.burst(Particles.WHITE, px, py, 40, 9f, 0.5f, 2.6f);
                break;
            }
            case Defs.AB_FREEZE:
                pl.abT[a] = dur; w.env.sfx(Sfx.AB_FREEZE, 1f);
                w.shockR = 0f; w.shockA = 0.6f;
                break;
            default: {
                pl.abT[a] = dur; w.env.sfx(Sfx.AB_CORRUPT, 1f);
                float r = w.live.range * 1.1f;
                int n = w.grid.query(px, py, r + 1.7f, w.tmp2), c = 0;
                for (int i = 0; i < n && c < 40; i++) {
                    Enemy e = w.en[w.tmp2[i]];
                    if (!e.alive || e.kind == Kinds.BOSS || e.kind == Kinds.FRIEND) continue;
                    if (Mx.len(e.x - px, e.y - py) > r + e.r) continue;
                    e.conv = dur; c++;
                }
                w.burst(Particles.MAGENTA, px, py, 24, 6f, 0.6f, 2.2f);
                break;
            }
        }
    }
}
