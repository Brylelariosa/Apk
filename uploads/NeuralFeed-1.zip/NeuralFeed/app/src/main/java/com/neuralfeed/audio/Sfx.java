package com.neuralfeed.audio;

/** Sound effect ids (see SfxBank for the procedural recipes). */
public final class Sfx {
    private Sfx() {}

    public static final int UI_TAP = 0, UI_BUY = 1, UI_DENY = 2, UI_OPEN = 3,
            PICK0 = 4, // PICK0..PICK0+9 ascending ladder
            PICK_M = 14, PICK_RARE = 15, PICK_UNK = 16, PICK_BAD = 17,
            TICK1 = 18, TICK2 = 19, TICK3 = 20, KILL = 21, KILL_BIG = 22, CASCADE = 23, TIER_UP = 24,
            DASH = 25, HIT = 26, SHIELD_BREAK = 27, HEAL = 28,
            AB_OVERCLOCK = 29, AB_EXPAND = 30, AB_IMPLODE = 31, AB_STORM = 32, AB_PULSE = 33, AB_FREEZE = 34, AB_CORRUPT = 35,
            EVOLVE = 36, LEVELUP = 37,
            BOSS_SPAWN = 38, BOSS_WARN = 39, BOSS_HIT = 40, BOSS_DIE = 41,
            STAGE_CLEAR = 42, EXTRACT = 43, DEATH = 44, MEMORY = 45, LOCK = 46, DECRYPT = 47, REWIND = 48, ARRIVE = 49, ENDING = 50,
            COUNT = 51;
}
