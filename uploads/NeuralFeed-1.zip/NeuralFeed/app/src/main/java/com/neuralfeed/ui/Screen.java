package com.neuralfeed.ui;

import android.graphics.Canvas;

/** A full-screen state (title, hub, gameplay ...). */
public abstract class Screen {
    protected final App app;

    protected Screen(App app) { this.app = app; }

    public void onShow() {}
    /** Activity paused (app backgrounded). */
    public void onPause() {}
    public void update(float dt) {}
    public abstract void draw(Canvas c);
    public void down(float x, float y, int id) {}
    public void move(float x, float y, int id) {}
    public void up(float x, float y, int id) {}
    /** Back button. Return true if handled. */
    public boolean back() { return false; }
}
