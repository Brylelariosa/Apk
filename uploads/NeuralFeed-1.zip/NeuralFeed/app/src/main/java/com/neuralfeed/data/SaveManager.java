package com.neuralfeed.data;

import android.util.Base64;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

/** Versioned, checksummed, atomically written save files with a rolling backup. */
public final class SaveManager {
    private static final String PREFIX = "NF1:";
    private final File main, bak, tmp;

    public SaveManager(File dir) {
        if (dir != null && !dir.exists()) dir.mkdirs();
        main = new File(dir, "neuralfeed.sav");
        bak = new File(dir, "neuralfeed.bak");
        tmp = new File(dir, "neuralfeed.tmp");
    }

    private static String readFile(File f) {
        if (!f.exists()) return null;
        FileInputStream in = null;
        try {
            in = new FileInputStream(f);
            byte[] b = new byte[(int) f.length()];
            int off = 0;
            while (off < b.length) { int r = in.read(b, off, b.length - off); if (r < 0) break; off += r; }
            return new String(b, 0, off, "UTF-8");
        } catch (IOException e) {
            return null;
        } finally {
            if (in != null) try { in.close(); } catch (IOException ignored) { /* ignore */ }
        }
    }

    private static Profile fromText(String text) {
        Store s = Store.parse(text);
        if (s == null) return null;
        Profile p = new Profile();
        p.read(s);
        return p;
    }

    /** Loads the newest intact save, or returns null when there is none (new game). */
    public Profile load() {
        File[] order = {main, bak, tmp};
        for (File f : order) {
            Profile p = fromText(readFile(f));
            if (p != null) return p;
        }
        return null;
    }

    public boolean save(Profile p) {
        Store s = new Store();
        p.write(s);
        FileOutputStream out = null;
        try {
            byte[] data = s.serialize().getBytes("UTF-8");
            out = new FileOutputStream(tmp);
            out.write(data);
            out.flush();
            out.getFD().sync();
            out.close();
            out = null;
            if (main.exists()) {
                if (bak.exists()) bak.delete();
                main.renameTo(bak);
            }
            if (!tmp.renameTo(main)) {
                // rename failed (unusual): keep the backup valid and report failure
                return false;
            }
            return true;
        } catch (IOException e) {
            return false;
        } finally {
            if (out != null) try { out.close(); } catch (IOException ignored) { /* ignore */ }
        }
    }

    public String export(Profile p) {
        Store s = new Store();
        p.write(s);
        try {
            return PREFIX + Base64.encodeToString(s.serialize().getBytes("UTF-8"), Base64.NO_WRAP | Base64.URL_SAFE);
        } catch (java.io.UnsupportedEncodingException e) {
            return "";
        }
    }

    /** Returns a profile, or null when the text is not a valid export. */
    public Profile importText(String text) {
        if (text == null) return null;
        text = text.trim();
        if (!text.startsWith(PREFIX)) return null;
        try {
            byte[] raw = Base64.decode(text.substring(PREFIX.length()), Base64.URL_SAFE);
            return fromText(new String(raw, "UTF-8"));
        } catch (IllegalArgumentException e) {
            return null;
        } catch (java.io.UnsupportedEncodingException e) {
            return null;
        }
    }
}
