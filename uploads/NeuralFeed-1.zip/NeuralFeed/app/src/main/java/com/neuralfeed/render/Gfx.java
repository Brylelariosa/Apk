package com.neuralfeed.render;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;

/** Shared paints, fonts and tiny drawing helpers. Nothing here allocates per call. */
public final class Gfx {
    public final float dp;
    public final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    public final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    public final Paint pts = new Paint(Paint.ANTI_ALIAS_FLAG);
    public final Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);
    public final RectF rect = new RectF();
    public final Batch lb = new Batch(4096), pb = new Batch(2048);
    public Typeface cond, condB, light, serifI, thin;
    public int quality = 2;

    private final int[] gcol = new int[24];
    private final Paint[] gpaint = new Paint[24];
    private int gn;

    public Gfx(float density) {
        dp = density;
        fill.setStyle(Paint.Style.FILL);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.ROUND);
        pts.setStyle(Paint.Style.STROKE);
        pts.setStrokeCap(Paint.Cap.ROUND);
        cond = Typeface.create("sans-serif-condensed", Typeface.NORMAL);
        condB = Typeface.create("sans-serif-condensed", Typeface.BOLD);
        light = Typeface.create("sans-serif-light", Typeface.NORMAL);
        thin = Typeface.create("sans-serif-thin", Typeface.NORMAL);
        serifI = Typeface.create("serif", Typeface.ITALIC);
    }

    public static int alpha(int c, int a) { return (Math.max(0, Math.min(255, a)) << 24) | (c & 0xFFFFFF); }

    public static int mix(int a, int b, float t) {
        if (t < 0f) t = 0f; else if (t > 1f) t = 1f;
        int ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255, br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        return 0xFF000000 | ((int) (ar + (br - ar) * t) << 16) | ((int) (ag + (bg - ag) * t) << 8) | (int) (ab + (bb - ab) * t);
    }

    // ---- primitives ----
    public void circle(Canvas c, float x, float y, float r, int color) { fill.setColor(color); c.drawCircle(x, y, r, fill); }

    public void ring(Canvas c, float x, float y, float r, float w, int color) {
        line.setStrokeWidth(w); line.setColor(color); c.drawCircle(x, y, r, line);
    }

    public void arc(Canvas c, float x, float y, float r, float start, float sweep, float w, int color) {
        rect.set(x - r, y - r, x + r, y + r);
        line.setStrokeWidth(w); line.setColor(color);
        c.drawArc(rect, start, sweep, false, line);
    }

    public void rrect(Canvas c, float x, float y, float w, float h, float rad, int color) {
        rect.set(x, y, x + w, y + h); fill.setColor(color); c.drawRoundRect(rect.left, rect.top, rect.right, rect.bottom, rad, rad, fill);
    }

    public void rrectLine(Canvas c, float x, float y, float w, float h, float rad, float sw, int color) {
        line.setStrokeWidth(sw); line.setColor(color); c.drawRoundRect(x, y, x + w, y + h, rad, rad, line);
    }

    public void rectFill(Canvas c, float x, float y, float w, float h, int color) { fill.setColor(color); c.drawRect(x, y, x + w, y + h, fill); }

    public void seg(Canvas c, float x1, float y1, float x2, float y2, float w, int color) {
        line.setStrokeWidth(w); line.setColor(color); c.drawLine(x1, y1, x2, y2, line);
    }

    /** Soft radial glow (cached gradient per colour, drawn via matrix scale so no allocation). */
    public void glow(Canvas c, float x, float y, float r, int rgb, int a) {
        if (quality < 2 || a <= 0 || r < 1f) return;
        rgb &= 0xFFFFFF;
        Paint p = null;
        for (int i = 0; i < gn; i++) if (gcol[i] == rgb) { p = gpaint[i]; break; }
        if (p == null) {
            if (gn >= gcol.length) { circle(c, x, y, r * 0.5f, alpha(rgb, a / 3)); return; }
            p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setShader(new RadialGradient(0f, 0f, 1f, new int[]{0xFF000000 | rgb, rgb}, new float[]{0f, 1f}, Shader.TileMode.CLAMP));
            gcol[gn] = rgb; gpaint[gn] = p; gn++;
        }
        p.setAlpha(Math.min(255, a));
        c.save();
        c.translate(x, y);
        c.scale(r, r);
        c.drawCircle(0f, 0f, 1f, p);
        c.restore();
    }

    // ---- text ----
    public void text(Canvas c, String s, float x, float y, float sp, int color, Paint.Align al, Typeface tf) {
        txt.setTypeface(tf); txt.setTextSize(sp * dp); txt.setColor(color); txt.setTextAlign(al); txt.setLetterSpacing(0f);
        c.drawText(s, x, y, txt);
    }

    public void tracked(Canvas c, String s, float x, float y, float sp, float ls, int color, Paint.Align al, Typeface tf) {
        txt.setTypeface(tf); txt.setTextSize(sp * dp); txt.setColor(color); txt.setTextAlign(al); txt.setLetterSpacing(ls);
        c.drawText(s, x, y, txt);
        txt.setLetterSpacing(0f);
    }

    public void chars(Canvas c, char[] s, int n, float x, float y, float sp, int color, Paint.Align al, Typeface tf) {
        txt.setTypeface(tf); txt.setTextSize(sp * dp); txt.setColor(color); txt.setTextAlign(al); txt.setLetterSpacing(0f);
        c.drawText(s, 0, n, x, y, txt);
    }

    public float measure(String s, float sp, Typeface tf) {
        txt.setTypeface(tf); txt.setTextSize(sp * dp); txt.setLetterSpacing(0f);
        return txt.measureText(s);
    }
}
