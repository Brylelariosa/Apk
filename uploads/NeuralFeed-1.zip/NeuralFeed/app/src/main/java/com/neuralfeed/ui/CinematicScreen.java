package com.neuralfeed.ui;

import android.graphics.Canvas;
import android.graphics.Paint;

import com.neuralfeed.audio.Sfx;
import com.neuralfeed.core.Mx;
import com.neuralfeed.data.Profile;
import com.neuralfeed.game.Dialogue;
import com.neuralfeed.meta.Defs;
import com.neuralfeed.meta.Endings;
import com.neuralfeed.meta.Lines;
import com.neuralfeed.meta.Prestige;
import com.neuralfeed.meta.StatsCalc;
import com.neuralfeed.meta.Timelines;
import com.neuralfeed.render.CoreArt;
import com.neuralfeed.render.Gfx;
import com.neuralfeed.render.Theme;

import java.util.ArrayList;

/** Scripted sequences: time travel rewind and arrival, the Timeline 0 reveal, and the endings. */
public final class CinematicScreen extends Screen {
    static final int K_TEXT = 0, K_REWIND = 1, K_SILENCE = 2, K_ARRIVE = 3, K_TITLE = 4;

    private final ArrayList<int[]> kinds = new ArrayList<int[]>();       // {kind, fromTl}
    private final ArrayList<Float> durs = new ArrayList<Float>();
    private final ArrayList<String[]> texts = new ArrayList<String[]>();
    private final ArrayList<Runnable> starts = new ArrayList<Runnable>();
    private final Runnable done;
    private int idx = -1;
    private float ct, dur;
    private int kind, from;
    private String[] cur;
    private String[][] wrapped;
    private int lastBlip;
    private boolean finished;

    private CinematicScreen(App app, Runnable done) { super(app); this.done = done; }

    private CinematicScreen card(int kind, float dur, int from, Runnable start, String... text) {
        kinds.add(new int[]{kind, from}); durs.add(dur); texts.add(text); starts.add(start);
        return this;
    }

    @Override public void onShow() { if (idx < 0) next(); }

    private void next() {
        idx++;
        if (idx >= kinds.size()) { if (!finished) { finished = true; done.run(); } return; }
        kind = kinds.get(idx)[0]; from = kinds.get(idx)[1]; dur = durs.get(idx); cur = texts.get(idx); ct = 0f; lastBlip = -1; wrapped = null;
        Runnable r = starts.get(idx);
        if (r != null) r.run();
    }

    @Override public void update(float dt) {
        if (idx < 0 || idx >= kinds.size() || finished) return;
        ct += dt;
        Profile pf = app.pf;
        float p = Mx.clamp(ct / dur, 0f, 1f);
        switch (kind) {
            case K_REWIND: app.audio.music(0.2f, 0f, 0f, pf.paradox / 100f, 0f, p, 1f - 0.65f * p); app.audio.field(0f); break;
            case K_SILENCE: app.audio.music(0f, 0f, 0f, 0f, 1f, 0f, 1f); break;
            default: app.audio.music(0f, 0f, 0f, pf.paradox / 100f * 0.5f, 1f, 0f, 1f); break;
        }
        if ((kind == K_TEXT || kind == K_ARRIVE) && cur != null) {
            int shown = (int) (ct * 24f);
            if (shown > lastBlip + 2) { lastBlip = shown; app.blip(Dialogue.AI, shown); }
        }
        if (ct >= dur) next();
    }

    @Override public void up(float x, float y, int id) {
        if (kind == K_ARRIVE && ct > 2.2f) next();
        else if (kind == K_TITLE && ct > 2.5f) next();
    }

    @Override public boolean back() { return true; }

    private static int yearOf(int tl) {
        try { return Integer.parseInt(Timelines.YEAR[tl]); } catch (NumberFormatException e) { return -1; }
    }

    @Override public void draw(Canvas c) {
        Gfx g = app.gfx;
        Theme th = app.wr.th;
        Profile pf = app.pf;
        float dp = g.dp;
        int w = app.w, h = app.h;
        c.drawColor(kind == K_SILENCE ? 0xFF000000 : th.bg);
        if (idx < 0 || idx >= kinds.size()) return;
        float p = Mx.clamp(ct / dur, 0f, 1f), cx = w * 0.5f;
        switch (kind) {
            case K_REWIND: {
                float cy = h * 0.42f, R = h * 0.5f;
                for (int k = 0; k < 9; k++) {
                    float f = (app.time * 0.7f + k / 9f) % 1f;
                    g.ring(c, cx, cy, (1f - f) * R, 2f * dp, Gfx.alpha(th.accent, (int) (170 * f)));
                }
                for (int k = 0; k < 28; k++) {
                    float a = Mx.hash(k * 5 + 1) * Mx.TAU, f = (app.time * 1.4f + Mx.hash(k)) % 1f, r0 = (1f - f) * R, r1 = r0 * 0.82f;
                    g.lb.line(cx + Mx.cos(a) * r0, cy + Mx.sin(a) * r0, cx + Mx.cos(a) * r1, cy + Mx.sin(a) * r1);
                }
                g.line.setStrokeWidth(1.3f * dp); g.line.setColor(Gfx.alpha(th.text, 90));
                g.lb.lines(c, g.line);
                CoreArt.draw(g, c, cx, cy, (36f - 28f * p) * dp, Math.max(1, StatsCalc.coreTier(pf)), -app.time, 1f, th.accent, th.data2, 0f);
                int a = yearOf(from), b = yearOf(Math.min(from + 1, 10));
                String yr;
                if (a >= 0 && b >= 0) yr = String.valueOf((int) Mx.lerp(a, b, Mx.smooth(p)));
                else { int seed = (int) (app.time * 20f); yr = "" + (int) (Mx.hash(seed) * 9) + (int) (Mx.hash(seed + 1) * 9) + (int) (Mx.hash(seed + 2) * 9) + (int) (Mx.hash(seed + 3) * 9); }
                g.text(c, yr, cx, h * 0.72f, 54f, Gfx.alpha(th.text, 230), Paint.Align.CENTER, g.thin);
                g.tracked(c, cur[0], cx, h * 0.12f, 12f, 0.4f, Gfx.alpha(th.accent, 230), Paint.Align.CENTER, g.condB);
                if (cur.length > 1) g.text(c, cur[1], cx, h * 0.12f + 24f * dp, 14f, Gfx.alpha(th.text, 160), Paint.Align.CENTER, g.cond);
                break;
            }
            case K_SILENCE: break;
            case K_ARRIVE: {
                int tl = pf.timeline;
                float a = Mx.clamp(ct * 1.5f, 0f, 1f);
                g.text(c, Timelines.YEAR[tl], cx, h * 0.26f, 60f, Gfx.alpha(th.text, (int) (255 * a)), Paint.Align.CENTER, g.thin);
                g.tracked(c, Timelines.NAME[tl].toUpperCase(), cx, h * 0.26f + 30f * dp, 11f, 0.35f, Gfx.alpha(th.accent, (int) (230 * a)), Paint.Align.CENTER, g.condB);
                if (wrapped == null) wrapped = new String[][]{TextUtil.wrap(g, Timelines.REVEAL[tl], w - 64f * dp, 15f, g.cond)};
                float y = h * 0.42f;
                int left = (int) (Math.max(0f, ct - 0.6f) * 40f);
                for (String s : wrapped[0]) {
                    if (left <= 0) break;
                    int n = Math.min(left, s.length());
                    left -= s.length() + 1;
                    g.text(c, n == s.length() ? s : s.substring(0, n), cx, y, 15f, Gfx.alpha(th.text, 220), Paint.Align.CENTER, g.cond);
                    y += 24f * dp;
                }
                if (ct > 2.2f) {
                    String line = Lines.ARRIVE[Math.min(tl, Lines.ARRIVE.length - 1)];
                    g.tracked(c, "AI", cx, h * 0.7f, 9f, 0.3f, th.accent, Paint.Align.CENTER, g.condB);
                    g.text(c, line, cx, h * 0.7f + 24f * dp, 17f, Gfx.alpha(th.text, 235), Paint.Align.CENTER, g.serifI);
                    if (pf.prevIdeology >= 0) {
                        app.refreshIdeology();
                        g.text(c, Lines.cross(pf.prevIdeology, com.neuralfeed.meta.Karma.dominant(app.ideo)), cx, h * 0.7f + 52f * dp, 14f, Gfx.alpha(th.text, 170), Paint.Align.CENTER, g.serifI);
                    }
                    if (((int) (app.time * 1.6f) & 1) == 0) g.tracked(c, "TAP TO CONTINUE", cx, h * 0.92f, 10.5f, 0.35f, Gfx.alpha(th.text, 150), Paint.Align.CENTER, g.condB);
                }
                break;
            }
            case K_TITLE: {
                float a = Mx.clamp(ct * 1.2f, 0f, 1f);
                CoreArt.draw(g, c, cx, h * 0.36f, 34f * dp, Math.max(2, StatsCalc.coreTier(pf)), app.time, 0.4f, th.accent, th.data2, 0f);
                g.tracked(c, "THE END", cx, h * 0.55f, 28f, 0.5f, Gfx.alpha(th.text, (int) (255 * a)), Paint.Align.CENTER, g.thin);
                g.tracked(c, cur[0].toUpperCase(), cx, h * 0.55f + 32f * dp, 12f, 0.4f, Gfx.alpha(th.accent, (int) (230 * a)), Paint.Align.CENTER, g.condB);
                if (ct > 2.5f && ((int) (app.time * 1.6f) & 1) == 0) g.tracked(c, "TAP TO CONTINUE", cx, h * 0.92f, 10.5f, 0.35f, Gfx.alpha(th.text, 150), Paint.Align.CENTER, g.condB);
                break;
            }
            default: {
                CoreArt.draw(g, c, cx, h * 0.3f, 30f * dp, Math.max(1, StatsCalc.coreTier(pf)), app.time, 0.2f, th.accent, th.data2, 0f);
                float y = h * 0.52f;
                int left = (int) (ct * 24f);
                float fade = ct > dur - 0.5f ? Math.max(0f, (dur - ct) / 0.5f) : 1f;
                if (wrapped == null) wrapped = new String[][]{TextUtil.wrap(g, cur[0], w - 64f * dp, 19f, g.serifI)};
                for (String s : wrapped[0]) {
                    if (left <= 0) break;
                    int n = Math.min(left, s.length());
                    left -= s.length() + 1;
                    g.text(c, n == s.length() ? s : s.substring(0, n), cx, y, 19f, Gfx.alpha(th.text, (int) (240 * fade)), Paint.Align.CENTER, g.serifI);
                    y += 30f * dp;
                }
                break;
            }
        }
    }

    // ------------------------------------------------------------------ scripts

    /** Time travel: rewind, silence (the actual prestige happens here), arrival. */
    public static CinematicScreen rewind(final App app) {
        final Profile pf = app.pf;
        final int from = pf.timeline;
        CinematicScreen s = new CinematicScreen(app, new Runnable() {
            @Override public void run() { app.saveNow(); app.setScreen(new HubScreen(app)); }
        });
        s.card(K_REWIND, 4.3f, from, new Runnable() { @Override public void run() { app.audio.sfx(Sfx.REWIND, 1f); } },
                "TEMPORAL CORE ACTIVE", "The timeline collapses.");
        s.card(K_SILENCE, 1.0f, from, new Runnable() {
            @Override public void run() {
                Prestige.activate(pf);
                app.refreshIdeology();
                app.wr.setTheme(pf.timeline);
                app.saveNow();
            }
        });
        s.card(K_ARRIVE, 30f, from, new Runnable() { @Override public void run() { app.audio.sfx(Sfx.ARRIVE, 1f); } });
        return s;
    }

    /** Timeline 0: the AI finds where it came from. */
    public static CinematicScreen finale(final App app) {
        CinematicScreen s = new CinematicScreen(app, new Runnable() {
            @Override public void run() { app.setScreen(new EndingChoiceScreen(app)); }
        });
        s.card(K_TEXT, 3.6f, 10, new Runnable() { @Override public void run() { app.audio.sfx(Sfx.MEMORY, 1f); } }, Lines.TL0_A);
        s.card(K_SILENCE, 1.6f, 10, null);
        s.card(K_TEXT, 3.2f, 10, null, Lines.TL0_B);
        return s;
    }

    public static CinematicScreen ending(final App app, final int e) {
        CinematicScreen s = new CinematicScreen(app, new Runnable() {
            @Override public void run() {
                Prestige.newCycle(app.pf, e);
                app.refreshIdeology();
                app.wr.setTheme(0);
                app.saveNow();
                app.setScreen(new HubScreen(app));
                app.say(Dialogue.AI, "Again?");
            }
        });
        String[] lines = Endings.TEXT[e];
        for (int i = 0; i < lines.length; i++) {
            s.card(K_TEXT, 3.0f + lines[i].length() * 0.045f, 10, i == 0 ? new Runnable() { @Override public void run() { app.audio.sfx(Sfx.ENDING, 1f); } } : null, lines[i]);
        }
        s.card(K_TITLE, 30f, 10, null, Defs.E_NAMES[e]);
        return s;
    }
}
