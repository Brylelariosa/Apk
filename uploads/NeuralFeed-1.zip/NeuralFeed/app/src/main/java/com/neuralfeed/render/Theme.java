package com.neuralfeed.render;

/** Per-timeline palette and backdrop pattern. */
public final class Theme {
    public int bg, grid, wall, accent, hostile, data, data2, text;
    public int pattern;   // 0 lines, 1 dots, 2 diagonal, 3 scanlines, 4 none
    public float cell;    // world units between pattern marks

    private static final int[][] COL = {
            {0xFF070B16, 0xFF14203A, 0xFF2A4568, 0xFF8FE3FF, 0xFFFF6F7D, 0xFFFFC857, 0xFFFFE9A8, 0xFFE8F1FF},
            {0xFF06131A, 0xFF10303A, 0xFF23585F, 0xFF7FF0D2, 0xFFFF8A5B, 0xFFF4D35E, 0xFFFFF0B0, 0xFFE6FFF8},
            {0xFF0D0A1E, 0xFF241A4E, 0xFF43347F, 0xFFB7A6FF, 0xFFFF6B9A, 0xFFFFD27A, 0xFFFFEBC0, 0xFFEFEBFF},
            {0xFF0E1114, 0xFF1F272E, 0xFF414850, 0xFFFFB86B, 0xFFFF5D73, 0xFF6FE3FF, 0xFFC4F4FF, 0xFFF4EFE8},
            {0xFF07120B, 0xFF13361F, 0xFF22603D, 0xFF9CFFC0, 0xFFFFB04D, 0xFFE8FF9C, 0xFFF6FFC8, 0xFFEAFFF0},
            {0xFF140A06, 0xFF3A2112, 0xFF80502A, 0xFFFFC27A, 0xFFFF5A4D, 0xFFFFE7B0, 0xFFFFF4D8, 0xFFFFF1E0},
            {0xFF101319, 0xFF242B38, 0xFF5A6682, 0xFFF2EFE6, 0xFFFF9AA2, 0xFFDDE6FF, 0xFFFFFFFF, 0xFFF2EFE6},
            {0xFF17110A, 0xFF3A2E1C, 0xFF8F7348, 0xFFF3E0B5, 0xFFD6503F, 0xFFFFD98A, 0xFFFFEEC6, 0xFFF7EBD2},
            {0xFF0B0B0C, 0xFF1C1C20, 0xFF52525A, 0xFFE7C873, 0xFFF26B6B, 0xFFEFE6C8, 0xFFFFFFFF, 0xFFF3EEDC},
            {0xFF020203, 0xFF17171C, 0xFF3A3A46, 0xFFFFFFFF, 0xFFFF4FD8, 0xFFC9B6FF, 0xFFFFFFFF, 0xFFFFFFFF},
            {0xFF000000, 0xFF0A0A0A, 0xFF222222, 0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF}};
    private static final int[] PATTERN = {0, 1, 2, 0, 3, 2, 1, 3, 0, 1, 4};
    private static final float[] CELL = {2f, 1.6f, 2.2f, 3f, 1.2f, 2.4f, 1.8f, 1.4f, 4f, 1.5f, 4f};

    public void set(int timeline) {
        int t = timeline < 0 ? 0 : (timeline >= COL.length ? COL.length - 1 : timeline);
        int[] c = COL[t];
        bg = c[0]; grid = c[1]; wall = c[2]; accent = c[3]; hostile = c[4]; data = c[5]; data2 = c[6]; text = c[7];
        pattern = PATTERN[t]; cell = CELL[t];
    }
}
