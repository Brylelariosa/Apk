package com.neuralfeed.meta;

/** Shared ids, names and tuning tables. */
public final class Defs {
    private Defs() {}

    // ---- karma dimensions ----
    public static final int K_COMP = 0, K_AGGR = 1, K_CTRL = 2, K_FREE = 3, K_LOGIC = 4, K_LOY = 5, K_RISK = 6, K_CUR = 7, K_N = 8;
    public static final String[] K_WORDS = {"Protective", "Aggressive", "Controlling", "Independent", "Analytical", "Loyal", "Reckless", "Curious"};

    // ---- ideologies ----
    public static final int I_PROT = 0, I_EVIL = 1, I_RAT = 2, I_NEU = 3;
    public static final String[] I_NAMES = {"Protector", "Evil", "Rational", "Neutral"};

    // ---- permanent upgrades ----
    public static final int UP_POWER = 0, UP_RATE = 1, UP_RANGE = 2, UP_COLLECT = 3, UP_HEALTH = 4, UP_SHIELD = 5, UP_SPEED = 6,
            UP_DASH = 7, UP_DATA = 8, UP_CRIT = 9, UP_MAGNET = 10, UP_DEEP = 11, UP_EDGE = 12, UP_PRESSURE = 13,
            UP_CASCADE = 14, UP_CACHE = 15, UP_HASTE = 16, UP_POTENCY = 17, UP_N = 18;

    // ---- abilities ----
    public static final int AB_OVERCLOCK = 0, AB_EXPANSION = 1, AB_IMPLOSION = 2, AB_STORM = 3, AB_PULSE = 4, AB_FREEZE = 5, AB_CORRUPT = 6, AB_N = 7;
    public static final String[] AB_NAMES = {"Overclock", "Expansion", "Implosion", "Data storm", "Neural pulse", "Temporal freeze", "Corruption"};
    public static final String[] AB_SHORT = {"OVR", "EXP", "IMP", "STM", "PLS", "FRZ", "COR"};
    public static final String[] AB_DESC = {
            "Processing rate +60% for a few seconds.",
            "Processing range +60% for a few seconds.",
            "Pulls enemies in toward the core.",
            "Drags every nearby Data fragment to you.",
            "Instant burst through the whole field.",
            "Slows everything inside the field.",
            "Enemies in the field turn on each other."};
    public static final float[] AB_CD = {16f, 22f, 20f, 24f, 12f, 26f, 28f};
    public static final float[] AB_DUR = {6f, 6f, 1.6f, 3f, 0f, 4.5f, 5f};
    public static final int[] AB_LEVEL = {1, 1, 8, 6, 2, 11, 14};

    // ---- node types ----
    public static final int N_STAGE = 0, N_ELITE = 1, N_DANGER = 2, N_BOSS = 3, N_VOID = 4;
    public static final String[] N_NAMES = {"Sector", "Elite", "Danger zone", "Boss"};
    public static final int[] RUN_PLAN = {N_STAGE, N_STAGE, N_ELITE, N_STAGE, N_DANGER, N_BOSS};

    // ---- orbs ----
    public static final int O_BASIC = 0, O_COMP = 1, O_RARE = 2, O_CORR = 3, O_UNK = 4;

    // ---- bosses ----
    public static final int B_FIREWALL = 0, B_ARCHIVIST = 1, B_EATER = 2, B_OBSERVER = 3, B_PARADOX = 4, B_N = 5;
    public static final String[] B_NAMES = {"The Firewall", "The Archivist", "The Memory Eater", "The Observer", "The Paradox"};

    // ---- archetypes: power, rate, range, collect, hp, shield, speed, data ----
    public static final int ARCH_N = 7;
    public static final String[] ARCH_NAMES = {"The Core", "The Network", "The Harvester", "The Overclocked", "The Guardian", "The Parasite", "The Temporal"};
    public static final String[] ARCH_DESC = {
            "Tiny field, enormous processing power.",
            "Huge field, moderate power, long neural chains.",
            "Vast collection range and richer Data.",
            "Extreme processing rate, fragile body.",
            "Thick shield and health, steady output.",
            "Kills feed Data straight into the core.",
            "Abilities recharge faster and last longer."};
    public static final int[] ARCH_LEVEL = {1, 1, 3, 5, 7, 10, 1};
    public static final float[][] ARCH = {
            {2.4f, 0.9f, 0.62f, 0.9f, 1f, 1f, 1f, 1f},
            {0.65f, 1.0f, 1.7f, 1f, 1f, 1f, 1f, 1f},
            {0.8f, 1f, 0.9f, 1.9f, 1f, 1f, 1.05f, 1.3f},
            {0.55f, 2.4f, 1f, 1f, 0.85f, 1f, 1.1f, 1f},
            {0.9f, 0.9f, 1f, 1f, 1.5f, 2.6f, 0.95f, 1f},
            {0.85f, 1f, 1f, 1.15f, 1f, 1f, 1f, 1f},
            {0.9f, 1f, 1f, 1f, 1f, 1f, 1f, 1f}};
    public static final int ARCH_TEMPORAL = 6, ARCH_PARASITE = 5, ARCH_NETWORK = 1;

    // ---- HUD elements ----
    public static final int H_JOY = 0, H_DASH = 1, H_AB1 = 2, H_AB2 = 3, H_AB3 = 4, H_CTX = 5, H_N = 6;
    public static final String[] H_NAMES = {"Joystick", "Dash", "Ability 1", "Ability 2", "Ability 3", "Action"};

    // ---- timelines ----
    public static final int TL_N = 11; // index 10 is Timeline 0

    // ---- story / milestone flags ----
    public static final long F_THANK = 1L, F_OUTSIDE = 1L << 1, F_FEED = 1L << 2, F_CAME_BACK = 1L << 3, F_REMEMBER = 1L << 4,
            F_BOSS1 = 1L << 5, F_DEATH1 = 1L << 6, F_EXTRACT1 = 1L << 7, F_LEVEL10 = 1L << 8, F_PRESTIGE1 = 1L << 9,
            F_TL0 = 1L << 10, F_BOOT = 1L << 11, F_FRIEND1 = 1L << 12, F_CONSUME1 = 1L << 13,
            D_DATA = 1L << 16, D_PAST = 1L << 17, D_SHAPED = 1L << 18, D_FUTURE = 1L << 19, D_CONNECTED = 1L << 20,
            D_CREATOR = 1L << 21, D_LOOP = 1L << 22;

    // ---- tutorial hint flags ----
    public static final long H_MOVE = 1L, H_DATA = 1L << 1, H_DASHH = 1L << 2, H_ABIL = 1L << 3, H_ROUTE = 1L << 4,
            H_EXTR = 1L << 5, H_CORE = 1L << 6, H_FRND = 1L << 7, H_VAULT = 1L << 8, H_BOSSH = 1L << 9, H_COMBO = 1L << 10;

    // ---- endings ----
    public static final int E_TOOL = 0, E_FRIEND = 1, E_ESCAPE = 2, E_SINGULARITY = 3, E_LOOP = 4, E_N = 5;
    public static final String[] E_NAMES = {"The Tool", "The Friend", "The Escape", "The Singularity", "The Loop"};
}
