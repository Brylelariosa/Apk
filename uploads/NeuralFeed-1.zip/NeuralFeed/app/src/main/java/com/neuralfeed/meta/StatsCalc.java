package com.neuralfeed.meta;

import com.neuralfeed.data.Profile;

/** Turns the profile (upgrades, level, echoes, archetype, ideology) into CoreStats. */
public final class StatsCalc {
    private StatsCalc() {}

    private static float pw(double b, int e) { return (float) Math.pow(b, e); }

    public static void compute(Profile p, CoreStats s) {
        int[] u = p.up;
        int lvl = p.level();
        float lv = lvl - 1;
        float echoP = 1f + 0.12f * (float) Math.pow(p.echoes, 0.9);
        float echoD = 1f + 0.10f * (float) Math.pow(p.echoes, 0.9);
        float[] a = Defs.ARCH[p.archetype];
        s.level = lvl;
        com.neuralfeed.meta.Karma.strengths(p, s.ideo);
        float pr = s.ideo[Defs.I_PROT], ev = s.ideo[Defs.I_EVIL], ra = s.ideo[Defs.I_RAT], ne = s.ideo[Defs.I_NEU];

        s.power = 6f * pw(1.15, u[Defs.UP_POWER]) * (1f + 0.02f * lv) * echoP * a[0];
        s.rate = 3.5f * pw(1.045, u[Defs.UP_RATE]) * (1f + 0.01f * lv) * a[1];
        s.range = 2.3f * pw(1.035, u[Defs.UP_RANGE]) * a[2];
        s.collect = 3.0f * pw(1.04, u[Defs.UP_COLLECT]) * a[3];
        s.maxHp = (100f + 12f * u[Defs.UP_HEALTH] + 2f * lv) * a[4];
        s.shield = (10f + 10f * u[Defs.UP_SHIELD]) * a[5];
        s.shieldRegen = 4f + 0.25f * u[Defs.UP_SHIELD];
        s.speed = 3.4f * (1f + 0.016f * u[Defs.UP_SPEED]) * a[6];
        s.dashCd = Math.max(0.9f, 3.2f * pw(0.97, u[Defs.UP_DASH]));
        s.dataMult = (1f + 0.08f * u[Defs.UP_DATA]) * echoD * a[7];
        s.crit = Math.min(0.5f, 0.05f + 0.01f * u[Defs.UP_CRIT]);
        s.critMul = 1.8f + 0.03f * u[Defs.UP_CRIT];
        s.magnet = 1f + 0.06f * u[Defs.UP_MAGNET];
        s.deep = 0.04f * u[Defs.UP_DEEP];
        s.edge = 0.04f * u[Defs.UP_EDGE];
        s.pressure = 0.06f * u[Defs.UP_PRESSURE];
        s.cascade = 0.012f * u[Defs.UP_CASCADE];
        s.cache = 0.1f * u[Defs.UP_CACHE];
        s.haste = 1f - Math.min(0.5f, 0.025f * u[Defs.UP_HASTE]);
        s.potency = 1f + 0.04f * u[Defs.UP_POTENCY];

        if (p.wide == 1) { s.range *= 1.35f; s.power *= 0.78f; }
        else if (p.wide == 2) { s.range *= 0.7f; s.power *= 1.9f; }

        s.steal = p.archetype == Defs.ARCH_PARASITE;
        s.chain = p.archetype == Defs.ARCH_NETWORK;
        if (p.archetype == Defs.ARCH_TEMPORAL) { s.haste *= 0.65f; s.potency *= 1.3f; }

        // ideology perks (thresholds on strength)
        s.dmgRed = 0; s.healPerOrb = 0; s.harvest = 0; s.devourThr = 0; s.dominate = 0; s.chainShare = 0; s.observe = 1f;
        s.guardian = false; s.predict = false; s.calculate = false; s.adaptive = false; s.execute = false; s.friendGuard = false;
        if (pr >= 0.25f) { s.shield *= 1f + 0.2f * pr; s.shieldRegen *= 1f + pr; }
        if (pr >= 0.45f) s.healPerOrb = 0.002f * pr;
        if (pr >= 0.65f) { s.guardian = true; s.dmgRed = 0.12f * pr; }
        if (pr >= 0.85f) s.friendGuard = true;
        if (ev >= 0.25f) s.harvest = 0.45f * ev;
        if (ev >= 0.45f) s.devourThr = 0.10f + 0.10f * ev;
        if (ev >= 0.65f) s.dominate = 0.05f + 0.05f * ev;
        if (ev >= 0.85f) s.chainShare = 0.2f;
        if (ra >= 0.25f) s.predict = true;
        if (ra >= 0.45f) { s.rate *= 1f + 0.1f * ra; s.haste *= 1f - 0.1f * ra; }
        if (ra >= 0.65f) s.calculate = true;
        if (ra >= 0.85f) { s.dataMult *= 1.15f; s.crit += 0.08f; }
        if (ne >= 0.25f) s.adaptive = true;
        if (ne >= 0.45f) { float b = 1f + 0.05f * ne; s.power *= b; s.rate *= b; s.range *= b; s.collect *= b; }
        if (ne >= 0.65f) s.observe = 1.3f;
        if (ne >= 0.85f) s.execute = true;
    }

    public static boolean archetypeUnlocked(Profile p, int a) {
        if (a == Defs.ARCH_TEMPORAL) return p.timeline >= 1 || p.cycle >= 1;
        return p.level() >= Defs.ARCH_LEVEL[a];
    }

    public static boolean abilityUnlocked(Profile p, int ab) { return p.level() >= Defs.AB_LEVEL[ab]; }

    public static int slotCount(Profile p) { return p.level() >= 6 ? 3 : 2; }

    /** Core visual tier 0..6 (6 = unknown core). */
    public static int coreTier(Profile p) {
        int l = p.level();
        if ((l >= 55 && p.timeline >= 5) || p.endings != 0 || p.timeline >= 9) return 6;
        if (l >= 40) return 5;
        if (l >= 26) return 4;
        if (l >= 16) return 3;
        if (l >= 9) return 2;
        if (l >= 4) return 1;
        return 0;
    }
}
