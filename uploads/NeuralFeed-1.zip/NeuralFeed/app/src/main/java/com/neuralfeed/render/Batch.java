package com.neuralfeed.render;

import android.graphics.Canvas;
import android.graphics.Paint;

/** Reusable float buffer for batched drawLines/drawPoints calls. Overflow is dropped, never grown. */
public final class Batch {
    public final float[] a;
    public int n;

    public Batch(int cap) { a = new float[cap]; }

    public void line(float x1, float y1, float x2, float y2) {
        if (n + 4 > a.length) return;
        a[n++] = x1; a[n++] = y1; a[n++] = x2; a[n++] = y2;
    }

    public void pt(float x, float y) {
        if (n + 2 > a.length) return;
        a[n++] = x; a[n++] = y;
    }

    public void lines(Canvas c, Paint p) { if (n >= 4) c.drawLines(a, 0, n & ~3, p); n = 0; }
    public void points(Canvas c, Paint p) { if (n >= 2) c.drawPoints(a, 0, n & ~1, p); n = 0; }
}
