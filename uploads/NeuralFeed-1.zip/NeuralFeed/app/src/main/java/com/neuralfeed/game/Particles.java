package com.neuralfeed.game;

/** Capped particle pool; oldest particles are recycled when the budget is exhausted. */
public final class Particles {
    public static final int SPARK = 0, DATA = 1, HOSTILE = 2, WHITE = 3, VIOLET = 4, MAGENTA = 5, RED = 6, KINDS = 7;
    public final int cap;
    public int limit;
    public float density = 1f;
    public final float[] x, y, vx, vy, life, max, size;
    public final byte[] kind;
    public final boolean[] on;
    public int alive;
    private int cursor;
    private int seed = 12345;

    public Particles(int cap) {
        this.cap = cap; this.limit = cap;
        x = new float[cap]; y = new float[cap]; vx = new float[cap]; vy = new float[cap];
        life = new float[cap]; max = new float[cap]; size = new float[cap];
        kind = new byte[cap]; on = new boolean[cap];
    }

    public void clear() { for (int i = 0; i < cap; i++) on[i] = false; alive = 0; }

    /** Scales an emit count by density with random rounding so low densities still show something. */
    public int count(int n) {
        float f = n * density;
        int whole = (int) f;
        seed = seed * 1103515245 + 12345;
        float frac = ((seed >>> 8) & 0xffff) / 65536f;
        return whole + (frac < f - whole ? 1 : 0);
    }

    public void emit(int k, float px, float py, float pvx, float pvy, float lifeT, float sz) {
        int i = cursor % limit;
        cursor = i + 1;
        on[i] = true; kind[i] = (byte) k; x[i] = px; y[i] = py; vx[i] = pvx; vy[i] = pvy; life[i] = lifeT; max[i] = lifeT; size[i] = sz;
    }

    public void update(float dt) {
        int a = 0;
        float drag = 1f - 2.4f * dt;
        if (drag < 0) drag = 0;
        for (int i = 0; i < cap; i++) {
            if (!on[i]) continue;
            life[i] -= dt;
            if (life[i] <= 0) { on[i] = false; continue; }
            x[i] += vx[i] * dt; y[i] += vy[i] * dt;
            vx[i] *= drag; vy[i] *= drag;
            a++;
        }
        alive = a;
    }
}
