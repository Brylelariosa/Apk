package com.neuralfeed.render;

import android.graphics.Canvas;

import com.neuralfeed.core.Mx;

/** Procedural AI core visuals, tiers 0..6 (6 = unknown core). Pure primitives, no textures. */
public final class CoreArt {
    private CoreArt() {}

    public static void draw(Gfx g, Canvas c, float cx, float cy, float r, int tier, float t, float energy, int accent, int accent2, float hurt) {
        float spin = t * (1f + energy * 1.5f);
        int white = Gfx.mix(Gfx.mix(accent, 0xFFFFFFFF, 0.8f), 0xFFFF5A5A, hurt);
        float lw = Math.max(1.2f, r * 0.07f);
        g.glow(c, cx, cy, r * 3.4f, accent, 120 + (int) (70 * energy));

        if (tier >= 6) {
            int seed = (int) (t * 9f);
            for (int k = 0; k < 3; k++) {
                float ox = (Mx.hash(seed * 3 + k) - 0.5f) * r * 1.1f, oy = (Mx.hash(seed * 5 + k + 11) - 0.5f) * r * 1.1f;
                g.circle(c, cx + ox, cy + oy, r * 0.62f, Gfx.alpha(accent2, 60));
            }
            for (int k = 0; k < 5; k++) {
                float a = Mx.hash(seed * 7 + k) * Mx.TAU, d0 = r * (1f + Mx.hash(seed + k) * 0.6f), d1 = d0 + r * (0.8f + Mx.hash(seed * 2 + k) * 1.6f);
                g.lb.line(cx + Mx.cos(a) * d0, cy + Mx.sin(a) * d0, cx + Mx.cos(a) * d1, cy + Mx.sin(a) * d1);
            }
            g.line.setStrokeWidth(lw); g.line.setColor(Gfx.alpha(accent2, 170));
            g.lb.lines(c, g.line);
        }
        if (tier >= 3) {
            for (int k = 0; k < 3; k++) g.arc(c, cx, cy, r * 1.15f, spin * 70f + k * 120f, 70f, lw * 1.3f, Gfx.alpha(accent, 210));
            for (int k = 0; k < 2; k++) g.arc(c, cx, cy, r * 1.9f, -spin * 50f + k * 180f, 100f, lw, Gfx.alpha(accent2, 170));
        }
        if (tier >= 5) {
            for (int h = 0; h < 2; h++) {
                float hr = r * (h == 0 ? 2.5f : 1.75f), rot = (h == 0 ? 1f : -1f) * spin * 0.4f;
                for (int k = 0; k < 6; k++) {
                    float a1 = rot + k * Mx.TAU / 6f, a2 = rot + (k + 1) * Mx.TAU / 6f;
                    g.lb.line(cx + Mx.cos(a1) * hr, cy + Mx.sin(a1) * hr, cx + Mx.cos(a2) * hr, cy + Mx.sin(a2) * hr);
                    if (h == 0) g.lb.line(cx, cy, cx + Mx.cos(a1) * hr, cy + Mx.sin(a1) * hr);
                }
            }
            g.line.setStrokeWidth(lw * 0.8f); g.line.setColor(Gfx.alpha(accent, 120));
            g.lb.lines(c, g.line);
        }
        if (tier >= 4) {
            float sr = r * 1.3f;
            g.line.setStrokeWidth(lw * 0.8f); g.line.setColor(Gfx.alpha(accent, 150));
            for (int k = 0; k < 3; k++) {
                float ph = spin * 0.6f + k * Mx.PI / 3f, wx = Math.max(1f, sr * Mx.abs(Mx.cos(ph)));
                g.rect.set(cx - wx, cy - sr, cx + wx, cy + sr);
                c.drawOval(g.rect, g.line);
            }
            g.rect.set(cx - sr, cy - sr * 0.28f, cx + sr, cy + sr * 0.28f);
            c.drawOval(g.rect, g.line);
            for (int i = 0; i < 8; i++) {
                float lon = spin * 0.9f + i * 0.785f, lat = ((i * 37) % 100 / 100f - 0.5f) * 2.2f;
                float x = Mx.cos(lat) * Mx.sin(lon), y = Mx.sin(lat), z = Mx.cos(lat) * Mx.cos(lon);
                if (z > -0.2f) g.pb.pt(cx + sr * x, cy + sr * y);
            }
            g.pts.setStrokeWidth(r * 0.2f); g.pts.setColor(Gfx.alpha(accent2, 230));
            g.pb.points(c, g.pts);
        }
        if (tier >= 1) {
            int nodes = tier >= 5 ? 6 : 3;
            float orR = r * (tier >= 4 ? 2.6f : 1.55f);
            for (int k = 0; k < nodes; k++) {
                float a = spin * 1.1f + k * Mx.TAU / nodes, a2 = spin * 1.1f + (k + 1) * Mx.TAU / nodes;
                float nx = cx + Mx.cos(a) * orR, ny = cy + Mx.sin(a) * orR;
                g.pb.pt(nx, ny);
                if (tier >= 2) {
                    g.lb.line(cx, cy, nx, ny);
                    g.lb.line(nx, ny, cx + Mx.cos(a2) * orR, cy + Mx.sin(a2) * orR);
                }
            }
            if (tier >= 2) { g.line.setStrokeWidth(lw * 0.7f); g.line.setColor(Gfx.alpha(accent, 110)); g.lb.lines(c, g.line); }
            g.pts.setStrokeWidth(r * 0.3f); g.pts.setColor(accent);
            g.pb.points(c, g.pts);
        }
        g.circle(c, cx, cy, r * 0.62f, white);
        g.circle(c, cx - r * 0.12f, cy - r * 0.12f, r * 0.26f, Gfx.alpha(0xFFFFFFFF, 190));
    }
}
