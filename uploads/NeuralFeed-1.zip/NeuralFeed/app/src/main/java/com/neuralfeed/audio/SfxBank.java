package com.neuralfeed.audio;

import static com.neuralfeed.audio.Synth.SAW;
import static com.neuralfeed.audio.Synth.SINE;
import static com.neuralfeed.audio.Synth.SQR;
import static com.neuralfeed.audio.Synth.TRI;
import static com.neuralfeed.audio.Synth.hz;

/** Every sound effect, synthesised from recipes. Built once on a background thread. */
public final class SfxBank {
    private final short[][] b = new short[Sfx.COUNT][];

    public short[] get(int id) { return b[id]; }

    private static final int[] LADDER = {0, 2, 4, 7, 9, 12, 14, 16, 19, 21};

    public SfxBank() {
        b[Sfx.UI_TAP] = new Synth(0.06f).osc(0f, 0.05f, 1500f, 1000f, SINE, 0.6f, 0f, 3f).pcm(0.8f);
        b[Sfx.UI_BUY] = new Synth(0.3f).osc(0f, 0.1f, 660f, 660f, TRI, 0.5f, 0f, 2f).osc(0.07f, 0.2f, 990f, 990f, TRI, 0.5f, 0f, 2f).pcm(0.8f);
        b[Sfx.UI_DENY] = new Synth(0.16f).osc(0f, 0.13f, 190f, 140f, SQR, 0.35f, 0f, 1.5f).pcm(0.8f);
        b[Sfx.UI_OPEN] = new Synth(0.2f).osc(0f, 0.16f, 500f, 900f, SINE, 0.45f, 0.01f, 2f).pcm(0.8f);
        for (int k = 0; k < 10; k++) {
            float f = 523.25f * (float) Math.pow(2.0, LADDER[k] / 12.0);
            b[Sfx.PICK0 + k] = new Synth(0.16f).osc(0f, 0.14f, f, f * 1.01f, SINE, 0.55f, 0.002f, 2.5f)
                    .osc(0f, 0.1f, f * 2f, f * 2f, TRI, 0.18f, 0f, 3f).noise(0f, 0.012f, 0.12f, 0f, 1f, 9000f, 6000f).pcm(0.8f);
        }
        b[Sfx.PICK_M] = new Synth(0.3f).osc(0f, 0.12f, 1046f, 1046f, SINE, 0.5f, 0.002f, 2f).osc(0.07f, 0.2f, 1318f, 1318f, SINE, 0.5f, 0.002f, 2.2f)
                .osc(0.07f, 0.15f, 2636f, 2636f, TRI, 0.12f, 0f, 3f).pcm(0.8f);
        Synth rare = new Synth(1.0f);
        float[] pr = {1f, 2.76f, 5.4f, 8.9f}, pa = {0.5f, 0.3f, 0.18f, 0.1f};
        for (int i = 0; i < 4; i++) rare.osc(0f, 0.9f, 1046f * pr[i], 1046f * pr[i], SINE, pa[i], 0.001f, 2.4f);
        b[Sfx.PICK_RARE] = rare.pcm(0.8f);
        Synth unk = new Synth(1.8f);
        for (int i = 1; i <= 4; i++) unk.oscV(0f, 1.7f, 55f * i, 55f * i, SINE, 0.5f / i, 0.15f, 1.3f, 5f, 0.004f);
        unk.oscV(0.1f, 1.4f, 1568f, 1568f, SINE, 0.08f, 0.2f, 2f, 6f, 0.01f);
        b[Sfx.PICK_UNK] = unk.pcm(0.9f);
        b[Sfx.PICK_BAD] = new Synth(0.4f).osc(0f, 0.3f, 240f, 90f, SAW, 0.4f, 0f, 1.5f).noise(0f, 0.15f, 0.3f, 0f, 2f, 3000f, 400f).crush(0f, 0.4f, 5).pcm(0.8f);

        b[Sfx.TICK1] = new Synth(0.08f).osc(0f, 0.06f, 880f, 700f, SINE, 0.5f, 0f, 3f).pcm(0.7f);
        b[Sfx.TICK2] = new Synth(0.1f).osc(0f, 0.07f, 660f, 520f, TRI, 0.45f, 0f, 2.5f).osc(0.01f, 0.06f, 990f, 880f, SINE, 0.3f, 0f, 3f).pcm(0.7f);
        b[Sfx.TICK3] = new Synth(0.14f).osc(0f, 0.1f, 330f, 200f, TRI, 0.5f, 0f, 2f).osc(0f, 0.08f, 660f, 500f, SINE, 0.3f, 0f, 3f)
                .noise(0f, 0.05f, 0.25f, 0f, 2f, 7000f, 2500f).pcm(0.7f);
        b[Sfx.KILL] = new Synth(0.1f).osc(0f, 0.07f, 1200f, 600f, SINE, 0.5f, 0f, 3f).pcm(0.7f);
        Synth kb = new Synth(0.5f);
        for (int i = 0; i < 3; i++) kb.osc(i * 0.07f, 0.16f, 523f * (float) Math.pow(2.0, new int[]{0, 4, 7}[i] / 12.0), 523f * (float) Math.pow(2.0, new int[]{0, 4, 7}[i] / 12.0), TRI, 0.4f, 0f, 2.2f);
        b[Sfx.KILL_BIG] = kb.noise(0f, 0.3f, 0.2f, 0.02f, 2f, 5000f, 800f).pcm(0.8f);
        Synth cas = new Synth(0.9f).osc(0f, 0.8f, 55f, 33f, SINE, 0.7f, 0.01f, 1.4f).osc(0f, 0.6f, 110f, 55f, SAW, 0.18f, 0f, 2f);
        for (int i = 0; i < 6; i++) cas.osc(i * 0.07f, 0.05f, 400f - i * 45f, 380f - i * 45f, SQR, 0.15f, 0f, 2f);
        b[Sfx.CASCADE] = cas.drive(1.5f).pcm(0.8f);
        b[Sfx.TIER_UP] = new Synth(0.35f).osc(0f, 0.16f, 440f, 880f, TRI, 0.4f, 0f, 1.5f).osc(0.05f, 0.25f, 660f, 1320f, SINE, 0.4f, 0f, 2f).pcm(0.8f);

        b[Sfx.DASH] = new Synth(0.25f).noise(0f, 0.2f, 0.5f, 0.02f, 1.5f, 2400f, 500f).osc(0f, 0.12f, 300f, 900f, SINE, 0.2f, 0f, 2f).pcm(0.8f);
        b[Sfx.HIT] = new Synth(0.18f).osc(0f, 0.13f, 170f, 55f, SQR, 0.5f, 0f, 2f).noise(0f, 0.1f, 0.4f, 0f, 2f, 1600f, 300f).pcm(0.9f);
        b[Sfx.SHIELD_BREAK] = new Synth(0.3f).noise(0f, 0.25f, 0.5f, 0f, 1.5f, 4000f, 500f).osc(0f, 0.2f, 900f, 200f, SAW, 0.25f, 0f, 2f).pcm(0.8f);
        b[Sfx.HEAL] = new Synth(0.3f).osc(0f, 0.22f, 523f, 784f, SINE, 0.4f, 0.01f, 1.5f).pcm(0.7f);

        b[Sfx.AB_OVERCLOCK] = new Synth(0.7f).osc(0f, 0.55f, 200f, 1600f, SAW, 0.3f, 0.05f, 0.6f).osc(0f, 0.55f, 100f, 800f, SINE, 0.4f, 0.05f, 0.6f).crush(0f, 0.7f, 6).pcm(0.8f);
        b[Sfx.AB_EXPAND] = new Synth(0.6f).noise(0f, 0.5f, 0.45f, 0.1f, 1.2f, 300f, 5000f).osc(0f, 0.4f, 300f, 900f, TRI, 0.25f, 0.05f, 1.5f).pcm(0.8f);
        b[Sfx.AB_IMPLODE] = new Synth(0.9f).noise(0f, 0.8f, 0.55f, 0.4f, 0.6f, 3000f, 200f).osc(0f, 0.8f, 120f, 40f, SINE, 0.7f, 0.05f, 1.2f).pcm(0.9f);
        Synth st = new Synth(0.6f);
        for (int i = 0; i < 8; i++) { float f = 659f * (float) Math.pow(2.0, LADDER[i] / 12.0); st.osc(i * 0.05f, 0.14f, f, f, i % 2 == 0 ? SINE : TRI, 0.28f, 0f, 2.5f); }
        b[Sfx.AB_STORM] = st.pcm(0.8f);
        b[Sfx.AB_PULSE] = new Synth(0.7f).osc(0f, 0.55f, 125f, 30f, SINE, 0.9f, 0f, 2f).noise(0f, 0.3f, 0.7f, 0f, 2f, 6000f, 300f)
                .osc(0f, 0.15f, 800f, 100f, SAW, 0.35f, 0f, 2f).drive(1.6f).pcm(0.9f);
        b[Sfx.AB_FREEZE] = new Synth(0.8f).oscV(0f, 0.7f, 800f, 200f, TRI, 0.35f, 0.02f, 1.2f, 14f, 0.08f).noise(0f, 0.6f, 0.15f, 0.1f, 1.5f, 5000f, 800f).pcm(0.8f);
        Synth cor = new Synth(0.55f);
        for (int i = 0; i < 12; i++) { float f = 200f + ((i * 7919) % 1800); cor.osc(i * 0.04f, 0.035f, f, f * 0.8f, SQR, 0.28f, 0f, 1f); }
        b[Sfx.AB_CORRUPT] = cor.noise(0f, 0.4f, 0.15f, 0f, 1f, 4000f, 1000f).crush(0f, 0.55f, 4).pcm(0.8f);

        Synth ev = new Synth(2.8f).osc(0f, 0.6f, 60f, 60f, SINE, 0.85f, 0.01f, 1.6f).osc(0.4f, 1.0f, 200f, 1200f, SAW, 0.2f, 0.3f, 0.7f);
        int[] chord = {0, 4, 7, 12};
        for (int i = 0; i < 4; i++) { float f = 523f * (float) Math.pow(2.0, chord[i] / 12.0); ev.osc(1.4f, 1.3f, f, f, SINE, 0.28f, 0.01f, 2f).osc(1.4f, 1.0f, f * 2f, f * 2f, TRI, 0.08f, 0f, 2.5f); }
        b[Sfx.EVOLVE] = ev.pcm(0.85f);
        Synth lv = new Synth(0.9f);
        for (int i = 0; i < 4; i++) { float f = 523f * (float) Math.pow(2.0, new int[]{0, 4, 7, 12}[i] / 12.0); lv.osc(i * 0.08f, 0.3f, f, f, TRI, 0.38f, 0f, 2f); }
        b[Sfx.LEVELUP] = lv.osc(0.3f, 0.5f, 1568f, 1568f, SINE, 0.15f, 0.01f, 2.5f).pcm(0.8f);

        Synth bs = new Synth(2.2f).noise(0f, 2.0f, 0.7f, 0.2f, 0.8f, 220f, 110f).osc(0f, 2.0f, 45f, 38f, SINE, 0.7f, 0.2f, 1f);
        for (int i = 0; i < 3; i++) bs.osc(0.5f + i * 0.4f, 0.16f, 800f, 800f, SQR, 0.2f, 0f, 1.5f);
        b[Sfx.BOSS_SPAWN] = bs.pcm(0.9f);
        b[Sfx.BOSS_WARN] = new Synth(0.3f).osc(0f, 0.08f, 1000f, 1000f, SQR, 0.25f, 0f, 1.2f).osc(0.13f, 0.08f, 1000f, 1000f, SQR, 0.25f, 0f, 1.2f).pcm(0.7f);
        b[Sfx.BOSS_HIT] = new Synth(0.3f).osc(0f, 0.25f, 95f, 40f, SINE, 0.8f, 0f, 2f).noise(0f, 0.12f, 0.4f, 0f, 2f, 2500f, 300f).pcm(0.9f);
        Synth bd = new Synth(2.6f).noise(0f, 2.4f, 0.75f, 0f, 1.5f, 4000f, 100f).osc(0f, 2.4f, 80f, 25f, SINE, 0.8f, 0f, 1.2f);
        for (int i = 0; i < 5; i++) bd.osc(i * 0.28f, 0.4f, 110f - i * 12f, 35f, SINE, 0.6f, 0f, 2f).noise(i * 0.28f, 0.25f, 0.4f, 0f, 2f, 5000f, 400f);
        b[Sfx.BOSS_DIE] = bd.drive(1.4f).pcm(0.9f);

        Synth sc = new Synth(1.3f);
        for (int i = 0; i < 4; i++) { float f = 523f * (float) Math.pow(2.0, new int[]{0, 4, 7, 12}[i] / 12.0); sc.osc(i * 0.1f, 0.6f, f, f, TRI, 0.35f, 0f, 2f).osc(i * 0.1f + 0.22f, 0.5f, f, f, TRI, 0.12f, 0f, 2f); }
        b[Sfx.STAGE_CLEAR] = sc.pcm(0.8f);
        b[Sfx.EXTRACT] = new Synth(0.6f).osc(0f, 0.1f, 660f, 660f, SINE, 0.4f, 0f, 1.5f).osc(0.1f, 0.1f, 880f, 880f, SINE, 0.4f, 0f, 1.5f).osc(0.2f, 0.4f, 1320f, 1320f, SINE, 0.45f, 0.005f, 2f).pcm(0.8f);
        b[Sfx.DEATH] = new Synth(1.4f).osc(0f, 1.2f, 440f, 55f, SAW, 0.4f, 0f, 1f).noise(0f, 0.5f, 0.3f, 0f, 1.5f, 3000f, 200f).crush(0f, 1.4f, 5).pcm(0.9f);
        Synth mem = new Synth(1.9f);
        for (int i = 0; i < 3; i++) { float f = 392f * (float) Math.pow(2.0, new int[]{0, 3, 7}[i] / 12.0); mem.osc(0f, 1.7f, f, f, SINE, 0.3f, 0.3f, 1.5f); }
        b[Sfx.MEMORY] = mem.oscV(0.2f, 1.4f, 1568f, 1568f, SINE, 0.1f, 0.2f, 2f, 5f, 0.01f).pcm(0.85f);
        b[Sfx.LOCK] = new Synth(0.3f).osc(0f, 0.25f, 1400f, 200f, SAW, 0.35f, 0f, 1.5f).noise(0f, 0.1f, 0.3f, 0f, 2f, 5000f, 1000f).pcm(0.8f);
        Synth dc = new Synth(0.9f);
        for (int i = 0; i < 5; i++) { float f = 523f * (float) Math.pow(2.0, LADDER[i] / 12.0); dc.osc(i * 0.07f, 0.15f, f, f, SINE, 0.3f, 0f, 2f); }
        b[Sfx.DECRYPT] = dc.osc(0.4f, 0.5f, 1046f, 1046f, TRI, 0.3f, 0.01f, 2f).osc(0.4f, 0.5f, 1568f, 1568f, SINE, 0.2f, 0.01f, 2f).pcm(0.8f);

        Synth rw = new Synth(4.0f).oscV(0f, 1.3f, 400f, 70f, SAW, 0.3f, 0.01f, 0.5f, 6f, 0.03f).noise(0f, 1.2f, 0.25f, 0.05f, 0.8f, 3000f, 300f);
        rw.osc(1.2f, 0.4f, 60f, 35f, SINE, 0.8f, 0f, 1.5f).osc(2.0f, 0.4f, 60f, 35f, SINE, 0.8f, 0f, 1.5f).osc(2.6f, 0.4f, 60f, 35f, SINE, 0.9f, 0f, 1.5f);
        rw.noise(1.3f, 1.8f, 0.35f, 1.4f, 0.4f, 6000f, 200f).oscV(1.3f, 1.8f, 100f, 1400f, SAW, 0.12f, 1.2f, 0.5f, 9f, 0.05f);
        b[Sfx.REWIND] = rw.pcm(0.85f);
        Synth ar = new Synth(2.2f);
        ar.osc(0f, 1.9f, 523f, 523f, SINE, 0.35f, 0.05f, 2f).osc(0.15f, 1.7f, 784f, 784f, SINE, 0.3f, 0.05f, 2f).osc(0.3f, 1.5f, 1046f, 1046f, SINE, 0.25f, 0.05f, 2f);
        b[Sfx.ARRIVE] = ar.pcm(0.85f);
        Synth en = new Synth(4.5f);
        int[] pad = {-24, -17, -12, -8};
        for (int i = 0; i < 4; i++) { float f = hz(pad[i]); en.oscV(0f, 4.4f, f, f, i % 2 == 0 ? SINE : TRI, 0.28f, 1.2f, 1.2f, 0.4f, 0.003f); }
        b[Sfx.ENDING] = en.pcm(0.8f);
    }
}
