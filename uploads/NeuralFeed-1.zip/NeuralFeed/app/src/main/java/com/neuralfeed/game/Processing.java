package com.neuralfeed.game;

import com.neuralfeed.audio.Sfx;
import com.neuralfeed.core.Mx;
import com.neuralfeed.meta.CoreStats;

/** The Processing Field: automatic area damage around the AI core. */
final class Processing {
    private Processing() {}

    private static final float[] COMBO_MUL = {1f, 1.12f, 1.25f, 1.45f, 1.8f};
    private static float cascadeSfx;

    static void tick(World w, float dt) {
        Player pl = w.pl;
        CoreStats s = w.live;
        cascadeSfx -= dt;
        if (pl.fieldOff > 0 || w.phase == World.P_DEAD) {
            w.lastTargets = 0; w.comboTier = 0;
            w.fieldEnergy = Mx.damp(w.fieldEnergy, 0f, 6f, dt);
            return;
        }
        float rate = Mx.max(0.5f, s.rate);
        float interval = 1f / rate, mult = 1f;
        if (interval < 1f / 45f) { mult = rate * (1f / 45f); interval = 1f / 45f; }
        w.procAcc += dt;
        if (w.procAcc >= interval) {
            int k = (int) (w.procAcc / interval);
            if (k > 4) { k = 4; w.procAcc = 0f; } else w.procAcc -= k * interval;
            pass(w, mult * k);
        }
        w.fieldEnergy = Mx.damp(w.fieldEnergy, Mx.min(1f, w.lastTargets / 25f), 5f, dt);
    }

    private static void pass(World w, float mult) {
        Player pl = w.pl;
        CoreStats s = w.live;
        float R = s.range, px = pl.x, py = pl.y;
        int nc = w.grid.query(px, py, R + 1.7f, w.tmp);
        int n = 0;
        for (int i = 0; i < nc; i++) {
            Enemy e = w.en[w.tmp[i]];
            if (!e.alive || e.kind == Kinds.FRIEND) continue;
            float dx = e.x - px, dy = e.y - py, rr = R + e.r;
            if (dx * dx + dy * dy <= rr * rr) w.tmp[n++] = w.tmp[i];
        }
        w.lastTargets = n;
        if (n > w.maxTargets) w.maxTargets = n;
        int tier = n >= 50 ? 4 : n >= 25 ? 3 : n >= 10 ? 2 : n >= 5 ? 1 : 0;
        if (tier > w.comboTier) { w.comboFlash = 1f; w.env.sfx(Sfx.TIER_UP, 0.8f, 0.9f + 0.08f * tier); }
        w.comboTier = tier;
        if (n == 0) return;

        float cm = COMBO_MUL[tier];
        w.ringPulse = 1f;
        w.env.sfx(n <= 2 ? Sfx.TICK1 : (n <= 8 ? Sfx.TICK2 : Sfx.TICK3), 0.6f);
        if (tier >= 3 && cascadeSfx <= 0f) { cascadeSfx = 0.9f; w.env.sfx(Sfx.CASCADE, 0.7f); }
        int shown = 0;
        for (int i = 0; i < n; i++) {
            Enemy e = w.en[w.tmp[i]];
            if (!e.alive) continue;
            float dx = e.x - px, dy = e.y - py, d = Mx.len(dx, dy);
            float t = Mx.clamp(d / R, 0f, 1f);
            float dmg = s.power * mult * cm;
            dmg *= 1f + s.deep * (1f - t) + s.edge * t + (t < 0.4f ? s.pressure * (0.4f - t) / 0.4f : 0f);
            boolean crit = w.rng.f() < s.crit;
            if (crit) dmg *= s.critMul;
            boolean devour = false;
            if (s.devourThr > 0f && e.kind != Kinds.BOSS && !e.immune && e.hp - dmg <= s.devourThr * e.maxHp) { devour = true; dmg = Mx.max(dmg, e.hp + 1f); }
            w.hit(e, dmg, crit);
            if (devour && !e.alive) pl.hp = Mx.min(pl.maxHp, pl.hp + 0.015f * pl.maxHp);
            if (w.pf.dmgNums && shown < 3 && (crit || w.rng.f() < 0.5f)) {
                w.pops.addNum(e.x, e.y - e.r, dmg, crit ? 0xFFFFE08A : 0xFFFFFFFF, crit ? 0.62f : 0.46f);
                shown++;
            }
            if (i < 24) w.addBeam(e.x, e.y);
            if (i < 10) { float a = w.rng.ang(); w.parts.emit(Particles.SPARK, e.x, e.y, Mx.cos(a) * 2.5f, Mx.sin(a) * 2.5f, 0.25f, 1.6f); }
        }
        if ((s.chain || s.chainShare > 0f) && n > 0) chain(w, n, mult * cm);
    }

    /** Neural chain: a share of damage arcs to enemies next to the first few targets. */
    private static void chain(World w, int n, float m) {
        float share = w.live.chain ? 0.18f : w.live.chainShare;
        int lim = Math.min(n, 4);
        for (int i = 0; i < lim; i++) {
            Enemy src = w.en[w.tmp[i]];
            int k = w.grid.query(src.x, src.y, 2.4f, w.tmp2);
            int hits = 0;
            for (int j = 0; j < k && hits < 2; j++) {
                Enemy o = w.en[w.tmp2[j]];
                if (o == src || !o.alive || o.kind == Kinds.FRIEND) continue;
                float dx = o.x - src.x, dy = o.y - src.y;
                if (dx * dx + dy * dy > 5.76f) continue;
                w.hit(o, w.live.power * m * share, false);
                w.addBeam(o.x, o.y);
                hits++;
            }
        }
    }
}
