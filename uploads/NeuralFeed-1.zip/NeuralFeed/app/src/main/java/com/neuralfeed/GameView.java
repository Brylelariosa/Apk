package com.neuralfeed;

import android.content.Context;
import android.graphics.Canvas;
import android.view.MotionEvent;
import android.view.View;

import com.neuralfeed.ui.App;

/** Single hardware-accelerated view: update + draw once per vsync, multi-touch routed to the active screen. */
public final class GameView extends View {
    private final App app;
    private long last;
    private boolean running;

    public GameView(Context context, App app) {
        super(context);
        this.app = app;
        setFocusable(true);
        setKeepScreenOn(true);
    }

    private int topInset() {
        float dp = getResources().getDisplayMetrics().density;
        int res = getResources().getIdentifier("status_bar_height", "dimen", "android");
        int sb = res > 0 ? getResources().getDimensionPixelSize(res) : 0;
        return (int) Math.max(26f * dp, sb);
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        app.resize(w, h, topInset());
    }

    @Override
    protected void onDraw(Canvas canvas) {
        long now = System.nanoTime();
        float dt = last == 0 ? 0.016f : (now - last) / 1e9f;
        last = now;
        if (dt > 0.25f) dt = 0.016f;
        app.update(dt);
        app.draw(canvas);
        if (running) postInvalidateOnAnimation();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int a = e.getActionMasked();
        switch (a) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN: {
                int i = e.getActionIndex();
                app.down(e.getX(i), e.getY(i), e.getPointerId(i));
                break;
            }
            case MotionEvent.ACTION_MOVE:
                for (int i = 0; i < e.getPointerCount(); i++) app.move(e.getX(i), e.getY(i), e.getPointerId(i));
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP: {
                int i = e.getActionIndex();
                app.up(e.getX(i), e.getY(i), e.getPointerId(i));
                break;
            }
            case MotionEvent.ACTION_CANCEL:
                for (int i = 0; i < e.getPointerCount(); i++) app.up(e.getX(i), e.getY(i), e.getPointerId(i));
                break;
            default:
                break;
        }
        return true;
    }

    public void resume() {
        running = true;
        last = 0;
        postInvalidateOnAnimation();
    }

    public void pause() { running = false; }
}
