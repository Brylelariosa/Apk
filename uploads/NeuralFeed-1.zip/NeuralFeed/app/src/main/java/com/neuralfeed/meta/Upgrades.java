package com.neuralfeed.meta;

/** Permanent upgrade catalogue (bought with Data between runs). */
public final class Upgrades {
    private Upgrades() {}

    public static final class Up {
        public final int id, max, req;
        public final String name, desc;
        public final double base, growth;

        Up(int id, String name, String desc, int max, double base, double growth, int req) {
            this.id = id; this.name = name; this.desc = desc; this.max = max; this.base = base; this.growth = growth; this.req = req;
        }

        public double cost(int level) { return base * Math.pow(growth, level); }
    }

    public static final Up[] ALL = new Up[Defs.UP_N];

    private static void def(int id, String name, String desc, int max, double base, double growth, int req) {
        ALL[id] = new Up(id, name, desc, max, base, growth, req);
    }

    static {
        def(Defs.UP_POWER, "Processing power", "+15% damage every tick", 100, 12, 1.19, 1);
        def(Defs.UP_RATE, "Processing rate", "+4.5% processing ticks per second", 60, 20, 1.23, 1);
        def(Defs.UP_RANGE, "Processing range", "+3.5% field radius", 40, 25, 1.27, 1);
        def(Defs.UP_COLLECT, "Collection range", "+4% pickup radius", 40, 15, 1.22, 1);
        def(Defs.UP_HEALTH, "Maximum health", "+12 health", 60, 18, 1.20, 1);
        def(Defs.UP_SHIELD, "Shield", "+10 shield that regenerates", 50, 30, 1.22, 1);
        def(Defs.UP_SPEED, "Movement speed", "+1.6% speed", 25, 40, 1.28, 1);
        def(Defs.UP_DASH, "Dash cooldown", "-3% cooldown", 20, 50, 1.30, 1);
        def(Defs.UP_DATA, "Data multiplier", "+8% Data from everything", 80, 60, 1.24, 1);
        def(Defs.UP_CRIT, "Critical processing", "+1% chance, +3% crit power", 30, 45, 1.25, 1);
        def(Defs.UP_MAGNET, "Data magnet", "Fragments are pulled harder and farther", 30, 35, 1.24, 1);
        def(Defs.UP_DEEP, "Deep scan", "Bonus damage to targets close to the core", 20, 400, 1.35, 3);
        def(Defs.UP_EDGE, "Edge breaker", "Bonus damage to targets at the field edge", 20, 400, 1.35, 3);
        def(Defs.UP_PRESSURE, "Core pressure", "Large bonus right next to the core", 20, 700, 1.38, 5);
        def(Defs.UP_CASCADE, "Neural cascade", "Each kill briefly stacks processing rate", 20, 900, 1.40, 7);
        def(Defs.UP_CACHE, "Memory cache", "Keep temporary bonuses between arenas", 10, 1500, 1.45, 9);
        def(Defs.UP_HASTE, "Ability haste", "-2.5% ability cooldowns", 20, 250, 1.30, 4);
        def(Defs.UP_POTENCY, "Ability potency", "+4% ability duration and strength", 20, 250, 1.30, 4);
    }

    public static double modeCost(int timeline) { return 2000.0 * Math.pow(3.0, timeline); }

    /** Total cost of buying n levels starting at level. */
    public static double costMany(Up u, int level, int n) {
        double t = 0;
        for (int i = 0; i < n; i++) t += u.cost(level + i);
        return t;
    }

    /** Largest number of levels (<= want) affordable with budget. */
    public static int affordable(Up u, int level, double budget, int want) {
        int n = 0;
        double spent = 0;
        while (n < want && level + n < u.max) {
            double c = u.cost(level + n);
            if (spent + c > budget) break;
            spent += c;
            n++;
        }
        return n;
    }
}
