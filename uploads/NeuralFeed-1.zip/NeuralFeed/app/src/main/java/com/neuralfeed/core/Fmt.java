package com.neuralfeed.core;

/** Number/time formatting. char[] variants are allocation-free for HUD use. */
public final class Fmt {
    private static final String[] SUF = {"", "K", "M", "B", "T", "Qa", "Qi", "Sx", "Sp", "Oc", "No", "Dc"};

    private Fmt() {}

    /** Writes an abbreviated number (1.23K, 45.6M ...) into o, returns length. o needs >= 12 chars. */
    public static int chars(double v, char[] o) {
        int n = 0;
        if (v != v) { o[0] = '0'; return 1; }
        if (v < 0) { o[n++] = '-'; v = -v; }
        if (v < 1000) {
            long x = (long) v;
            if (x == 0) { o[n++] = '0'; return n; }
            int start = n;
            long t = x; int digits = 0;
            while (t > 0) { digits++; t /= 10; }
            n = start + digits;
            for (int i = n - 1; i >= start; i--) { o[i] = (char) ('0' + (x % 10)); x /= 10; }
            return n;
        }
        int e = 0;
        while (v >= 1000 && e < SUF.length - 1) { v /= 1000; e++; }
        if (v >= 1000) { v = 999; }
        if (v < 10) {
            long x = (long) (v * 100);
            o[n++] = (char) ('0' + x / 100); o[n++] = '.'; o[n++] = (char) ('0' + (x / 10) % 10); o[n++] = (char) ('0' + x % 10);
        } else if (v < 100) {
            long x = (long) (v * 10);
            o[n++] = (char) ('0' + x / 100); o[n++] = (char) ('0' + (x / 10) % 10); o[n++] = '.'; o[n++] = (char) ('0' + x % 10);
        } else {
            long x = (long) v;
            o[n++] = (char) ('0' + x / 100); o[n++] = (char) ('0' + (x / 10) % 10); o[n++] = (char) ('0' + x % 10);
        }
        String s = SUF[e];
        for (int i = 0; i < s.length(); i++) o[n++] = s.charAt(i);
        return n;
    }

    public static String num(double v) {
        char[] b = new char[16];
        int n = chars(v, b);
        return new String(b, 0, n);
    }

    public static String f1(float v) {
        boolean neg = v < 0; if (neg) v = -v;
        int x = (int) (v * 10f + 0.5f);
        return (neg ? "-" : "") + (x / 10) + "." + (x % 10);
    }

    public static String f2(float v) {
        boolean neg = v < 0; if (neg) v = -v;
        int x = (int) (v * 100f + 0.5f);
        int fr = x % 100;
        return (neg ? "-" : "") + (x / 100) + "." + (fr < 10 ? "0" : "") + fr;
    }

    public static String pct(float v) { return (int) (v * 100f + 0.5f) + "%"; }

    /** "5h 24m", "12m 03s", "42s" */
    public static String dur(long secs) {
        if (secs < 0) secs = 0;
        long h = secs / 3600, m = (secs / 60) % 60, s = secs % 60;
        if (h > 0) return h + "h " + m + "m";
        if (m > 0) return m + "m " + (s < 10 ? "0" : "") + s + "s";
        return s + "s";
    }

    public static int intChars(int v, char[] o, int at) {
        if (v < 0) { o[at++] = '-'; v = -v; }
        if (v == 0) { o[at++] = '0'; return at; }
        int digits = 0, t = v;
        while (t > 0) { digits++; t /= 10; }
        int end = at + digits;
        for (int i = end - 1; i >= at; i--) { o[i] = (char) ('0' + v % 10); v /= 10; }
        return end;
    }
}
