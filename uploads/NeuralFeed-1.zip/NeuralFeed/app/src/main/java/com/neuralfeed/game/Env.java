package com.neuralfeed.game;

import com.neuralfeed.data.Profile;

/** Services the simulation needs from the host app (audio, dialogue, haptics). Keeps game logic free of UI code. */
public interface Env {
    Profile profile();
    void sfx(int id, float vol);
    void sfx(int id, float vol, float pitch);
    void pick(int type, int chain);
    void say(int speaker, String text);
    void hint(long flag, String text);
    void vibrate(int ms);
    float particleDensity();
    boolean shakeEnabled();
}
