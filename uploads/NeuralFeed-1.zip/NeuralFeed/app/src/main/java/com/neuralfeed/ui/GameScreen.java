package com.neuralfeed.ui;

import android.graphics.Canvas;
import android.graphics.Paint;

import com.neuralfeed.audio.Sfx;
import com.neuralfeed.core.Fmt;
import com.neuralfeed.core.Mx;
import com.neuralfeed.data.Profile;
import com.neuralfeed.game.AbilitySys;
import com.neuralfeed.game.Dialogue;
import com.neuralfeed.game.Input;
import com.neuralfeed.game.Run;
import com.neuralfeed.game.World;
import com.neuralfeed.meta.Defs;
import com.neuralfeed.meta.Events;
import com.neuralfeed.meta.Karma;
import com.neuralfeed.meta.Lines;
import com.neuralfeed.meta.Memories;
import com.neuralfeed.meta.StatsCalc;
import com.neuralfeed.meta.Story;
import com.neuralfeed.render.Gfx;
import com.neuralfeed.render.Hud;
import com.neuralfeed.render.Theme;
import com.neuralfeed.render.Ui;

/** A run: gameplay plus the overlays that frame it (pause, route choice, events, memories, results). */
public final class GameScreen extends Screen {
    private static final int M_PLAY = 0, M_PAUSE = 1, M_ROUTE = 2, M_EVENT = 3, M_RESULT = 4, M_MEMORY = 5, M_CONFIRM = 6;

    private final World w;
    private int mode = M_PLAY;
    private boolean started;
    private int joyId = -1;
    private float stickBx, stickBy, evolveFlash, t, overlayT;
    // route / event
    private int recommended = -1, evId, evChosen = -1;
    private String evResult;
    // result
    private boolean extracted;
    private double gained;
    private int lvl0, tier0;
    private String resultLine;
    // memory
    private int memId = -1;
    private String[] memLines;
    private float memShown;
    private String[] evLines, evResLines;
    private String evFor;

    public GameScreen(App app) {
        super(app);
        int q = app.pf.quality;
        int orbs = q >= 3 ? 520 : q == 2 ? 420 : q == 1 ? 320 : 240;
        int parts = q >= 3 ? 900 : q == 2 ? 650 : q == 1 ? 420 : 260;
        w = new World(app, orbs, parts);
        w.setView(app.w, app.h);
    }

    @Override public void onShow() {
        if (started) return;
        started = true;
        Profile pf = app.pf;
        app.wr.setTheme(pf.timeline);
        w.setView(app.w, app.h);
        w.beginRun();
        lvl0 = pf.level();
        tier0 = StatsCalc.coreTier(pf);
        app.audio.musicRoot((2 + 3 * pf.timeline) % 12);
        app.refreshIdeology();
        int dom = Karma.dominant(app.ideo);
        if (pf.runs == 3 && !pf.flag(Defs.F_FEED)) { pf.flags |= Defs.F_FEED; app.say(Dialogue.AI, Lines.FEED); }
        else if (pf.prevIdeology >= 0 && app.rng.chance(0.35f)) app.say(Dialogue.AI, Lines.cross(pf.prevIdeology, dom));
        else if (pf.paradox >= 50f && app.rng.chance(0.5f)) app.say(Dialogue.AI, Lines.PARADOX[app.rng.i(Lines.PARADOX.length)]);
        else if (pf.timeline >= 10) app.say(Dialogue.AI, "...");
        else if (pf.timeline > 0 && pf.runs % 4 == 1) app.say(Dialogue.AI, Lines.ARRIVE[Math.min(pf.timeline, Lines.ARRIVE.length - 1)]);
    }

    @Override public void onPause() { if (mode == M_PLAY && started) openPause(); }

    // ------------------------------------------------------------------ update

    @Override public void update(float dt) {
        t += dt;
        overlayT += dt;
        Profile pf = app.pf;
        Input in = w.in;
        if (evolveFlash > 0f) evolveFlash = Math.max(0f, evolveFlash - dt * 1.2f);
        if (mode == M_PLAY || mode == M_ROUTE || mode == M_RESULT) {
            w.parts.limit = Math.max(40, (int) (w.parts.cap * pf.density * app.autoDrop));
            w.parts.density = pf.density * app.autoDrop;
            w.setView(app.w, app.h);
            w.update(dt);
            if (mode == M_PLAY) in.clearEvents();
        }
        if (mode == M_PLAY) {
            if (w.memEvent >= 0) { openMemory(w.memEvent); w.memEvent = -1; }
            if (w.evolved) { w.evolved = false; evolveFlash = 1f; }
            w.levelUp = false;
            if (w.voidDone) { app.setScreen(CinematicScreen.finale(app)); return; }
            if (w.phase == World.P_ROUTE) enterRoute();
            else if (w.phase == World.P_DONE) finish(false);
        }
        float hpf = w.pl.maxHp > 0 ? w.pl.hp / w.pl.maxHp : 1f;
        float intensity = Mx.clamp(0.18f + w.fieldEnergy * 0.9f + (w.comboTier >= 2 ? 0.15f : 0f), 0f, 1f);
        float danger = (hpf < 0.35f ? 0.8f : 0f) + (w.boss != null ? 0.2f : 0f);
        float minimal = (mode == M_MEMORY || mode == M_EVENT || mode == M_RESULT) ? 1f : 0f;
        app.audio.field(mode == M_PLAY ? w.fieldEnergy : 0f);
        app.audio.music(intensity, danger, w.boss != null && w.boss.alive ? 1f : 0f, pf.paradox / 100f, minimal, 0f, Mx.clamp(w.timeScale, 0.4f, 1f));
        if (mode == M_MEMORY) memShown += dt * 55f;
        Hud hud = app.hud;
        hud.stickActive = joyId >= 0;
        hud.stickX = in.jx; hud.stickY = in.jy;
    }

    // ------------------------------------------------------------------ flow

    private void openPause() { mode = M_PAUSE; overlayT = 0f; app.audio.sfx(Sfx.UI_OPEN, 0.8f); releaseStick(); }

    private void releaseStick() { joyId = -1; w.in.jx = 0; w.in.jy = 0; w.in.mag = 0; }

    private void enterRoute() {
        mode = M_ROUTE; overlayT = 0f; releaseStick();
        app.checkIdeologyTier();
        app.checkRelationship();
        app.saveNow();
        recommended = -1;
        if (w.base.calculate) {
            float best = -1f;
            for (int i = 0; i < 3; i++) {
                int m = w.run.optMod[i];
                float sc = w.run.optEvent[i] ? 1.1f : Run.M_REWARD[m] / Mx.pow(Run.M_HP[m] * Run.M_SPAWN[m], 0.7f);
                if (sc > best) { best = sc; recommended = i; }
            }
        }
        app.hint(Defs.H_ROUTE, Lines.H_ROUTE);
        if (w.run.extractPoint()) app.hint(Defs.H_EXTR, Lines.H_EXTR);
    }

    private void finish(boolean ex) {
        extracted = ex;
        gained = w.finishRun(ex);
        app.checkIdeologyTier();
        app.checkRelationship();
        String[] pool = ex ? Lines.EXTRACT : Lines.DEATH;
        resultLine = pool[app.rng.i(pool.length)];
        app.sfx(ex ? Sfx.EXTRACT : Sfx.DEATH, 0.9f);
        app.say(Dialogue.AI, resultLine);
        mode = M_RESULT; overlayT = 0f;
        app.saveNow();
    }

    private void openMemory(int id) {
        memId = id; memShown = 0f; mode = M_MEMORY; overlayT = 0f; releaseStick();
        memLines = TextUtil.wrap(app.gfx, Memories.BODY[id], app.w - 80f * app.gfx.dp, 16f, app.gfx.serifI);
    }

    private void nextNode() {
        w.startNode();
        mode = M_PLAY;
        overlayT = 0f;
    }

    private void applyChoice(int idx) {
        Events.Ev ev = Events.ALL[evId];
        Events.Choice ch = ev.ch[idx];
        Profile pf = app.pf;
        double pool = w.run.bag + pf.bank;
        double cost = ch.cost(pool);
        double take = Math.min(w.run.bag, cost);
        w.run.bag -= take;
        pf.bank = Math.max(0, pf.bank - (cost - take));
        w.run.bag += ch.gain(pool);
        for (int i = 0; i < Defs.K_N; i++) if (ch.k[i] != 0f) Karma.add(pf, i, ch.k[i]);
        Story.trust(pf, ch.trust);
        pf.paradox = Mx.clamp(pf.paradox + ch.paradox, 0f, 100f);
        pf.eventsSeen |= 1 << evId;
        evResult = ch.result;
        evResLines = null;
        evChosen = idx;
        app.sfx(Sfx.UI_BUY, 0.8f);
        app.checkIdeologyTier();
        app.checkRelationship();
        if (ch.memory) w.giveMemory();
    }

    // ------------------------------------------------------------------ input

    private int buttonAt(float x, float y) {
        Profile pf = app.pf;
        Hud hud = app.hud;
        int[] els = {Defs.H_DASH, Defs.H_AB1, Defs.H_AB2, Defs.H_AB3, Defs.H_CTX};
        for (int el : els) {
            if (el >= Defs.H_AB1 && el <= Defs.H_AB3 && AbilitySys.slotAbility(pf, el - Defs.H_AB1) < 0) continue;
            if (el == Defs.H_CTX && !w.friendNear()) continue;
            float cx = hud.cx(pf, el, app.w), cy = hud.cy(pf, el, app.h), r = hud.rad(pf, el) * 1.25f;
            if ((x - cx) * (x - cx) + (y - cy) * (y - cy) <= r * r) return el;
        }
        return -1;
    }

    private void stick(float x, float y) {
        Profile pf = app.pf;
        float r = app.hud.rad(pf, Defs.H_JOY);
        float bx = pf.floatStick ? stickBx : app.hud.cx(pf, Defs.H_JOY, app.w), by = pf.floatStick ? stickBy : app.hud.cy(pf, Defs.H_JOY, app.h);
        float dx = x - bx, dy = y - by, d = Mx.len(dx, dy);
        float m = Mx.min(1f, d / (r * 0.9f));
        m = m < 0.1f ? 0f : (m - 0.1f) / 0.9f;
        m = Mx.pow(m, 1.1f);
        if (d < 1e-3f || m <= 0f) { w.in.jx = 0; w.in.jy = 0; w.in.mag = 0; return; }
        w.in.jx = dx / d * m; w.in.jy = dy / d * m; w.in.mag = m;
    }

    @Override public void down(float x, float y, int id) {
        if (mode != M_PLAY) { app.ui.down(x, y); return; }
        Profile pf = app.pf;
        if (app.hud.pauseHit(x, y, app.w)) { openPause(); return; }
        int el = buttonAt(x, y);
        if (el >= 0) {
            if (el == Defs.H_DASH) w.in.dash = true;
            else if (el == Defs.H_CTX) w.in.act = true;
            else w.in.ab[el - Defs.H_AB1] = true;
            return;
        }
        if (joyId >= 0) return;
        if (pf.floatStick) {
            if (x < app.w * 0.62f && y > app.h * 0.25f) { joyId = id; stickBx = x; stickBy = y; app.hud.stickBx = x; app.hud.stickBy = y; stick(x, y); }
        } else {
            float cx = app.hud.cx(pf, Defs.H_JOY, app.w), cy = app.hud.cy(pf, Defs.H_JOY, app.h), r = app.hud.rad(pf, Defs.H_JOY) * 1.9f;
            if ((x - cx) * (x - cx) + (y - cy) * (y - cy) <= r * r) { joyId = id; stick(x, y); }
        }
    }

    @Override public void move(float x, float y, int id) {
        if (mode != M_PLAY) { app.ui.move(x, y); return; }
        if (id == joyId) stick(x, y);
    }

    @Override public void up(float x, float y, int id) {
        if (mode == M_PLAY) { if (id == joyId) releaseStick(); return; }
        int hit = app.ui.up(x, y);
        if (hit >= 0) click(hit);
    }

    @Override public boolean back() {
        if (mode == M_PLAY) { openPause(); return true; }
        if (mode == M_PAUSE) { mode = M_PLAY; return true; }
        if (mode == M_CONFIRM) { mode = M_PAUSE; return true; }
        return true;
    }

    private void click(int id) {
        switch (id) {
            case 701: mode = M_PLAY; app.tap(); break;
            case 702: app.setScreen(new HudEditorScreen(app, this)); break;
            case 703: mode = M_CONFIRM; app.tap(); break;
            case 1201: finish(false); break;
            case 1202: mode = M_PAUSE; app.tap(); break;
            case 801: finish(true); break;
            case 802: case 803: case 804: {
                int opt = id - 802;
                if (w.run.extractPoint()) w.continueDeeper();
                boolean ev = w.chooseRoute(opt);
                app.checkIdeologyTier();
                app.tap();
                if (ev) { evId = Events.pick(app.pf, app.rng); evChosen = -1; evResult = null; evLines = null; mode = M_EVENT; overlayT = 0f; }
                else nextNode();
                break;
            }
            case 901: case 902: case 903:
                if (evChosen < 0) applyChoice(id - 901);
                break;
            case 904: nextNode(); break;
            case 1001: app.saveNow(); app.setScreen(new HubScreen(app)); break;
            case 1101:
                if (memShown < Memories.BODY[memId].length()) memShown = 9999f;
                else { mode = M_PLAY; app.tap(); }
                break;
            default: break;
        }
    }

    // ------------------------------------------------------------------ draw

    @Override public void draw(Canvas c) {
        Gfx g = app.gfx;
        Profile pf = app.pf;
        Theme th = app.wr.th;
        w.setView(app.w, app.h);
        app.wr.draw(c, w, app.w, app.h, pf.noFlash);
        app.hud.draw(c, w, pf, app.dlg, th, app.w, app.h);
        if (evolveFlash > 0f && !pf.noFlash) g.rectFill(c, 0, 0, app.w, app.h, Gfx.alpha(0xFFFFFFFF, (int) (150 * evolveFlash)));
        if (evolveFlash > 0.3f) g.tracked(c, "EVOLUTION", app.w * 0.5f, app.h * 0.3f, 22f, 0.4f, Gfx.alpha(th.text, (int) (255 * Math.min(1f, evolveFlash))), Paint.Align.CENTER, g.thin);
        app.ui.begin();
        switch (mode) {
            case M_PAUSE: drawPause(c, g, th); break;
            case M_CONFIRM: drawConfirm(c, g, th); break;
            case M_ROUTE: drawRoute(c, g, th); break;
            case M_EVENT: drawEvent(c, g, th); break;
            case M_RESULT: drawResult(c, g, th); break;
            case M_MEMORY: drawMemory(c, g, th); break;
            default: break;
        }
    }

    private void dim(Canvas c, int a) { app.gfx.rectFill(c, 0, 0, app.w, app.h, Gfx.alpha(0xFF000000, a)); }

    private void drawPause(Canvas c, Gfx g, Theme th) {
        Ui ui = app.ui;
        Profile pf = app.pf;
        float dp = g.dp, x = 28f * dp, bw = app.w - 56f * dp, y = app.h * 0.2f;
        dim(c, 190);
        g.tracked(c, "PAUSED", app.w * 0.5f, y, 15f, 0.4f, th.text, Paint.Align.CENTER, g.condB);
        y += 30f * dp;
        ui.button(c, 701, "RESUME", x, y, bw, 52f * dp, true, Ui.ST_PRIMARY, th.accent, th.text, th.bg); y += 64f * dp;
        ui.button(c, 702, "Customize HUD", x, y, bw, 46f * dp, true, Ui.ST_NORMAL, th.accent, th.text, th.bg); y += 70f * dp;
        pf.vMaster = ui.slider(c, 710, "Master volume", x, y, bw, pf.vMaster, th.accent, th.text); y += 54f * dp;
        pf.vMusic = ui.slider(c, 711, "Music volume", x, y, bw, pf.vMusic, th.accent, th.text); y += 54f * dp;
        pf.vSfx = ui.slider(c, 712, "Effects volume", x, y, bw, pf.vSfx, th.accent, th.text); y += 62f * dp;
        app.audio.applySettings(pf);
        ui.button(c, 703, "Leave run", x, y, bw, 46f * dp, true, Ui.ST_DANGER, th.accent, th.text, th.bg);
    }

    private void drawConfirm(Canvas c, Gfx g, Theme th) {
        Ui ui = app.ui;
        float dp = g.dp, x = 28f * dp, bw = app.w - 56f * dp, y = app.h * 0.34f;
        dim(c, 215);
        g.text(c, "Leave this run?", app.w * 0.5f, y, 20f, th.text, Paint.Align.CENTER, g.condB);
        g.text(c, "You keep 30% of the Data in your bag.", app.w * 0.5f, y + 28f * dp, 14f, Gfx.alpha(th.text, 180), Paint.Align.CENTER, g.cond);
        g.text(c, "Unsecured: " + Fmt.num(w.run.bag), app.w * 0.5f, y + 54f * dp, 14f, th.data, Paint.Align.CENTER, g.cond);
        ui.button(c, 1201, "LEAVE", x, y + 84f * dp, bw, 48f * dp, true, Ui.ST_DANGER, th.accent, th.text, th.bg);
        ui.button(c, 1202, "STAY", x, y + 144f * dp, bw, 48f * dp, true, Ui.ST_PRIMARY, th.accent, th.text, th.bg);
    }

    private String cardTitle(int o) { return o == 0 ? "Safe route" : (o == 1 ? "Dangerous route" : "Unknown signal"); }

    private void drawRoute(Canvas c, Gfx g, Theme th) {
        Ui ui = app.ui;
        float dp = g.dp, x = 22f * dp, bw = app.w - 44f * dp, y = app.h * 0.12f;
        float a = Mx.min(1f, overlayT * 3f);
        dim(c, (int) (200 * a));
        int cleared = w.run.lastCleared;
        String[] head = {"SECTOR PURGED", "SECTOR PURGED", "ELITE DESTROYED", "SECTOR PURGED", "DANGER ZONE CLEARED", "BOSS DEFEATED"};
        g.tracked(c, head[Math.max(0, Math.min(5, cleared))], app.w * 0.5f, y, 14f, 0.35f, th.text, Paint.Align.CENTER, g.condB);
        g.tracked(c, "UNSECURED DATA", app.w * 0.5f, y + 34f * dp, 9.5f, 0.3f, Gfx.alpha(th.text, 130), Paint.Align.CENTER, g.cond);
        g.text(c, Fmt.num(w.run.bag), app.w * 0.5f, y + 64f * dp, 32f, th.data, Paint.Align.CENTER, g.condB);
        y += 92f * dp;
        if (w.run.extractPoint()) {
            ui.button(c, 801, "EXTRACT  \u00b7  BANK " + Fmt.num(w.run.bag * (1.0 + 0.05 * w.run.loop)), x, y, bw, 54f * dp, true, Ui.ST_PRIMARY, th.accent, th.text, th.bg);
            y += 66f * dp;
            g.text(c, w.run.afterBoss() ? "or go deeper: tougher enemies, richer Data" : "or continue: risk more for more", app.w * 0.5f, y, 12.5f, Gfx.alpha(th.text, 160), Paint.Align.CENTER, g.cond);
            y += 16f * dp;
        } else {
            g.text(c, "Choose the next sector", app.w * 0.5f, y, 13f, Gfx.alpha(th.text, 160), Paint.Align.CENTER, g.cond);
            y += 14f * dp;
        }
        for (int o = 0; o < 3; o++) {
            float ch = 86f * dp;
            int mod = w.run.optMod[o];
            boolean hidden = o == 2 && !w.base.calculate;
            g.rrect(c, x, y, bw, ch, 11f * dp, Gfx.alpha(th.bg, 235));
            ui.button(c, 802 + o, "", x, y, bw, ch, true, Ui.ST_NORMAL, o == 0 ? th.accent : (o == 1 ? th.hostile : th.data), th.text, th.bg);
            g.text(c, cardTitle(o), x + 16f * dp, y + 28f * dp, 17f, th.text, Paint.Align.LEFT, g.condB);
            if (o == recommended) g.tracked(c, "RECOMMENDED", x + bw - 14f * dp, y + 26f * dp, 9f, 0.2f, th.accent, Paint.Align.RIGHT, g.condB);
            String l1, l2;
            if (hidden) { l1 = "Unknown modifier."; l2 = "Rare Data possible."; }
            else if (w.run.optEvent[o]) { l1 = "A decision awaits."; l2 = "Choices shape the AI."; }
            else {
                l1 = Run.M_NAME[mod] + "  \u00b7  reward x" + Fmt.f1(Run.M_REWARD[mod]) + "  \u00b7  enemies x" + Fmt.f1(Run.M_HP[mod] * Run.M_SPAWN[mod]);
                l2 = Run.M_DESC[mod];
            }
            g.text(c, l1, x + 16f * dp, y + 50f * dp, 12.5f, Gfx.alpha(th.text, 210), Paint.Align.LEFT, g.cond);
            g.text(c, l2, x + 16f * dp, y + 69f * dp, 12f, Gfx.alpha(th.text, 140), Paint.Align.LEFT, g.cond);
            y += ch + 10f * dp;
        }
    }

    private void drawEvent(Canvas c, Gfx g, Theme th) {
        Ui ui = app.ui;
        Profile pf = app.pf;
        Events.Ev ev = Events.ALL[evId];
        float dp = g.dp, x = 22f * dp, bw = app.w - 44f * dp, y = app.h * 0.13f;
        dim(c, 225);
        g.tracked(c, "DECISION", app.w * 0.5f, y, 10.5f, 0.4f, Gfx.alpha(th.text, 140), Paint.Align.CENTER, g.cond);
        g.text(c, ev.title, app.w * 0.5f, y + 32f * dp, 22f, th.text, Paint.Align.CENTER, g.condB);
        if (evLines == null || evFor != ev.body) { evLines = TextUtil.wrap(g, ev.body, bw, 15f, g.serifI); evFor = ev.body; }
        y += 64f * dp;
        for (String s : evLines) { g.text(c, s, app.w * 0.5f, y, 15f, Gfx.alpha(th.text, 215), Paint.Align.CENTER, g.serifI); y += 22f * dp; }
        y += 16f * dp;
        double pool = w.run.bag + pf.bank;
        if (evChosen < 0) {
            int rec = w.base.calculate ? Events.recommend(ev) : -1;
            if (rec >= 0) {
                Events.Choice rc = ev.ch[rec];
                g.text(c, "Expected future benefit: " + rc.benefit + "%.  Recommendation: " + rc.label.toLowerCase() + ".", app.w * 0.5f, y, 12.5f, th.accent, Paint.Align.CENTER, g.cond);
                y += 22f * dp;
            }
            for (int i = 0; i < ev.ch.length; i++) {
                Events.Choice ch = ev.ch[i];
                double cost = ch.cost(pool), gain = ch.gain(pool);
                String tag = cost > 0 ? "  \u00b7  costs " + Fmt.num(cost) : (gain > 0 ? "  \u00b7  +" + Fmt.num(gain) : "");
                boolean can = cost <= pool;
                ui.button(c, 901 + i, ch.label + tag, x, y, bw, 52f * dp, can, i == rec ? Ui.ST_PRIMARY : Ui.ST_NORMAL, th.accent, th.text, th.bg);
                y += 62f * dp;
            }
        } else {
            if (evResLines == null) evResLines = TextUtil.wrap(g, evResult, bw, 15f, g.serifI);
            for (String s : evResLines) { g.text(c, s, app.w * 0.5f, y, 15f, th.accent, Paint.Align.CENTER, g.serifI); y += 22f * dp; }
            y += 20f * dp;
            ui.button(c, 904, "CONTINUE", x, y, bw, 52f * dp, true, Ui.ST_PRIMARY, th.accent, th.text, th.bg);
        }
    }

    private void drawResult(Canvas c, Gfx g, Theme th) {
        Ui ui = app.ui;
        Profile pf = app.pf;
        float dp = g.dp, x = 28f * dp, bw = app.w - 56f * dp, y = app.h * 0.14f;
        dim(c, 215);
        g.tracked(c, extracted ? "RUN COMPLETE" : "CONNECTION LOST", app.w * 0.5f, y, 15f, 0.4f, extracted ? th.accent : th.hostile, Paint.Align.CENTER, g.condB);
        y += 50f * dp;
        g.tracked(c, extracted ? "DATA BANKED" : "DATA RECOVERED (30%)", app.w * 0.5f, y, 9.5f, 0.3f, Gfx.alpha(th.text, 130), Paint.Align.CENTER, g.cond);
        g.text(c, "+" + Fmt.num(gained), app.w * 0.5f, y + 34f * dp, 34f, th.data, Paint.Align.CENTER, g.condB);
        y += 76f * dp;
        double xp = pf.xp - w.xp0;
        int lvl = pf.level(), tier = StatsCalc.coreTier(pf);
        String[] rows = {"Training  +" + Fmt.num(xp), "Level  " + lvl0 + " \u2192 " + lvl, "Enemies processed  " + w.run.kills, "Sectors cleared  " + w.run.depth,
                "Memories recovered  " + w.run.memories, "Bosses defeated  " + w.run.bossKills};
        for (String s : rows) { g.text(c, s, app.w * 0.5f, y, 14.5f, Gfx.alpha(th.text, 215), Paint.Align.CENTER, g.cond); y += 24f * dp; }
        if (tier != tier0) { g.text(c, "The core has evolved.", app.w * 0.5f, y + 6f * dp, 15f, th.accent, Paint.Align.CENTER, g.condB); y += 30f * dp; }
        y += 20f * dp;
        ui.button(c, 1001, "RETURN TO CORE", x, y, bw, 54f * dp, true, Ui.ST_PRIMARY, th.accent, th.text, th.bg);
    }

    private void drawMemory(Canvas c, Gfx g, Theme th) {
        Ui ui = app.ui;
        float dp = g.dp, y = app.h * 0.2f;
        dim(c, 235);
        g.tracked(c, "MEMORY FRAGMENT RECOVERED", app.w * 0.5f, y, 11f, 0.35f, th.data2, Paint.Align.CENTER, g.condB);
        g.text(c, Memories.TITLE[memId], app.w * 0.5f, y + 38f * dp, 24f, th.text, Paint.Align.CENTER, g.thin);
        y += 84f * dp;
        int left = (int) memShown;
        for (String s : memLines) {
            if (left <= 0) break;
            int n = Math.min(left, s.length());
            left -= s.length() + 1;
            g.text(c, n == s.length() ? s : s.substring(0, n), app.w * 0.5f, y, 16f, Gfx.alpha(th.text, 230), Paint.Align.CENTER, g.serifI);
            y += 26f * dp;
        }
        ui.button(c, 1101, memShown < Memories.BODY[memId].length() ? "..." : "CONTINUE", 28f * dp, app.h * 0.78f, app.w - 56f * dp, 50f * dp, true, Ui.ST_NORMAL, th.accent, th.text, th.bg);
    }
}
