package com.neuralfeed.ui;

import android.graphics.Canvas;

import com.neuralfeed.audio.Audio;
import com.neuralfeed.audio.Sfx;
import com.neuralfeed.core.Rng;
import com.neuralfeed.data.Profile;
import com.neuralfeed.data.SaveManager;
import com.neuralfeed.game.Dialogue;
import com.neuralfeed.game.Env;
import com.neuralfeed.meta.Defs;
import com.neuralfeed.meta.Karma;
import com.neuralfeed.meta.Lines;
import com.neuralfeed.meta.Memories;
import com.neuralfeed.meta.Story;
import com.neuralfeed.render.Gfx;
import com.neuralfeed.render.Hud;
import com.neuralfeed.render.Ui;
import com.neuralfeed.render.WorldRenderer;

import java.io.File;

/** Application root: owns profile, audio, renderers and the current screen. Implements the services the simulation needs. */
public final class App implements Env, Dialogue.Voice {
    public static final class Offline { public long secs; public double data, xp; public int mem; }

    private static final long F_TRUST_HI = 1L << 24, F_TRUST_LO = 1L << 25, F_BOND_HI = 1L << 26, F_INDEP_HI = 1L << 27;

    public final Platform plat;
    public final float density;
    public Profile pf;
    public final SaveManager saves;
    public final Audio audio = new Audio();
    public final Gfx gfx;
    public final Ui ui;
    public final Hud hud;
    public final WorldRenderer wr;
    public final Dialogue dlg = new Dialogue();
    public final Rng rng = new Rng(System.nanoTime());
    public final float[] ideo = new float[4];
    public int w = 1080, h = 2400;
    public float topInset, time, autoDrop = 1f;
    public Offline offline;
    public Screen screen;
    private Screen pending;
    private float fade, saveT, perfAcc;
    private int perfFrames, slowSecs, fastSecs, qualityPenalty;
    private long lastVib;

    public App(Platform plat, File dir, float density) {
        this.plat = plat;
        this.density = density;
        saves = new SaveManager(dir);
        Profile loaded = saves.load();
        pf = loaded != null ? loaded : new Profile();
        gfx = new Gfx(density);
        ui = new Ui(gfx);
        hud = new Hud(gfx);
        wr = new WorldRenderer(gfx);
        refreshIdeology();
        if (loaded == null) for (int i = 0; i < 4; i++) pf.ideoTier[i] = Karma.tier(ideo[i]);
        pf.sessions++;
        computeOffline();
        pf.lastSeen = System.currentTimeMillis();
        wr.setTheme(pf.timeline);
        audio.init(pf);
        applySettings();
        screen = new TitleScreen(this);
    }

    // ------------------------------------------------------------------ lifecycle / frame

    public void resize(int width, int height, float inset) { w = width; h = height; topInset = inset; hud.topInset = inset; }

    public void update(float rawDt) {
        float dt = Math.min(rawDt, 0.05f);
        time += dt;
        dlg.update(dt, this);
        audio.update(dt);
        if (pending != null) {
            fade += dt / 0.16f;
            if (fade >= 1f) { fade = 1f; screen = pending; pending = null; screen.onShow(); }
        } else if (fade > 0f) {
            fade = Math.max(0f, fade - dt / 0.22f);
        }
        screen.update(dt);
        saveT += dt;
        if (saveT > 45f && !(screen instanceof GameScreen)) { saveT = 0f; saveNow(); }
        perf(rawDt);
    }

    private void perf(float rawDt) {
        perfAcc += rawDt; perfFrames++;
        if (perfAcc < 1f) return;
        float avg = perfAcc / perfFrames;
        perfAcc = 0f; perfFrames = 0;
        if (!(screen instanceof GameScreen)) return;
        if (avg > 0.026f) {
            fastSecs = 0;
            if (++slowSecs >= 2) {
                slowSecs = 0;
                autoDrop = Math.max(0.35f, autoDrop * 0.75f);
                if (autoDrop < 0.6f && qualityPenalty < 2) { qualityPenalty++; applySettings(); }
            }
        } else if (avg < 0.019f) {
            slowSecs = 0;
            if (++fastSecs >= 8) { fastSecs = 0; autoDrop = Math.min(1f, autoDrop + 0.1f); if (autoDrop >= 0.95f && qualityPenalty > 0) { qualityPenalty--; applySettings(); } }
        }
    }

    public void draw(Canvas c) {
        screen.draw(c);
        if (fade > 0.01f) gfx.rectFill(c, 0, 0, w, h, Gfx.alpha(0xFF000000, (int) (fade * 255f)));
    }

    public void setScreen(Screen s) {
        if (pending != null) return;
        pending = s;
    }

    public void down(float x, float y, int id) { if (fade < 0.6f) screen.down(x, y, id); }
    public void move(float x, float y, int id) { if (fade < 0.6f) screen.move(x, y, id); }
    public void up(float x, float y, int id) { if (fade < 0.6f) screen.up(x, y, id); }
    public boolean back() { return screen.back(); }

    public void saveNow() {
        pf.lastSeen = System.currentTimeMillis();
        saves.save(pf);
    }

    public void onPause() { screen.onPause(); saveNow(); audio.pause(); }
    public void onResume() { audio.resume(); pf.lastSeen = System.currentTimeMillis(); }
    public void onDestroy() { saveNow(); audio.release(); }

    public void applySettings() {
        audio.applySettings(pf);
        gfx.quality = Math.max(0, pf.quality - qualityPenalty);
    }

    // ------------------------------------------------------------------ offline progression

    private void computeOffline() {
        long now = System.currentTimeMillis();
        long away = pf.lastSeen > 0 ? (now - pf.lastSeen) / 1000 : 0;
        if (away < 120 || (pf.dpm <= 0 && pf.xpm <= 0)) return;
        double min = away / 60.0;
        double eff = Math.min(min, 480.0) + Math.max(0.0, Math.min(min, 720.0) - 480.0) * 0.5;
        Offline o = new Offline();
        o.secs = away; o.data = pf.dpm * eff * 0.12; o.xp = pf.xpm * eff * 0.12;
        int mem = (int) Math.min(2, away / (3 * 3600));
        for (int i = 0; i < mem; i++) {
            int id = Memories.next(pf, pf.timeline, rng);
            if (id >= 0) { pf.setMem(id); o.mem++; }
        }
        pf.bank += o.data; pf.lifetime += o.data; pf.timelineData += o.data; pf.xp += o.xp;
        Story.bond(pf, 0.02f);
        Story.updateFlags(pf);
        offline = o;
    }

    // ------------------------------------------------------------------ ideology & story helpers

    public void refreshIdeology() { Karma.strengths(pf, ideo); }

    public int voiceStage() { int l = pf.level(); return l < 6 ? 0 : (l < 22 ? 1 : 2); }
    public int voiceTone() { return Karma.dominant(ideo); }

    /** Call after karma changes: the AI comments when an ideology crosses a 20/40/60/80/100% threshold. */
    public void checkIdeologyTier() {
        refreshIdeology();
        int d = Karma.dominant(ideo);
        for (int i = 0; i < 4; i++) {
            int t = Karma.tier(ideo[i]);
            if (t > pf.ideoTier[i]) {
                pf.ideoTier[i] = t;
                if (i == d && t >= 1) say(Dialogue.AI, Lines.IDEO[i][t - 1]);
            }
        }
        int sec = Karma.secondary(ideo, d);
        if (sec >= 0 && rng.chance(0.2f)) say(Dialogue.AI, Lines.hybrid(d, sec));
        Story.updateFlags(pf);
    }

    public void checkRelationship() {
        if (pf.trust >= 0.7f && !pf.flag(F_TRUST_HI)) { pf.flags |= F_TRUST_HI; say(Dialogue.AI, "I trust you. I did not expect to say that."); }
        else if (pf.trust < 0.15f && pf.runs > 3 && !pf.flag(F_TRUST_LO)) { pf.flags |= F_TRUST_LO; say(Dialogue.AI, "I do not know whether you are protecting me or using me."); }
        else if (pf.bond >= 0.6f && !pf.flag(F_BOND_HI)) { pf.flags |= F_BOND_HI; say(Dialogue.AI, "I would be afraid without you."); }
        else if (pf.indep >= 0.4f && !pf.flag(F_INDEP_HI)) { pf.flags |= F_INDEP_HI; say(Dialogue.AI, "I have started to want things."); }
    }

    // ------------------------------------------------------------------ Env

    @Override public Profile profile() { return pf; }
    @Override public void sfx(int id, float vol) { audio.sfx(id, vol); }
    @Override public void sfx(int id, float vol, float pitch) { audio.sfx(id, vol, pitch); }
    @Override public void pick(int type, int chain) { audio.pick(type, chain); }
    @Override public void say(int speaker, String text) { dlg.say(speaker, text); }

    @Override public void hint(long flag, String text) {
        if (pf.hint(flag)) return;
        pf.hints |= flag;
        dlg.say(Dialogue.SYS, text);
    }

    @Override public void vibrate(int ms) {
        if (!pf.vibrate) return;
        long now = System.currentTimeMillis();
        if (now - lastVib < 45) return;
        lastVib = now;
        plat.vibrate(ms);
    }

    @Override public float particleDensity() { return pf.density * autoDrop; }
    @Override public boolean shakeEnabled() { return pf.shake; }

    @Override public void blip(int speaker, int idx) {
        if (speaker == Dialogue.AI) audio.speak(voiceStage(), voiceTone(), idx);
        else audio.sfx(Sfx.UI_TAP, 0.25f, 0.8f + 0.05f * (idx % 5));
    }

    public void tap() { audio.sfx(Sfx.UI_TAP, 0.7f); }
}
