package com.neuralfeed.meta;

import com.neuralfeed.core.Rng;
import com.neuralfeed.data.Profile;

/** Decision events: small moral/strategic choices that shape karma, trust and paradox. */
public final class Events {
    private Events() {}

    public static final class Choice {
        public final String label, result;
        public final float costFrac, gainFrac, trust, paradox;
        public final int costMin, gainMin, benefit;
        public final boolean memory;
        public final float[] k = new float[Defs.K_N];

        Choice(String label, String result, float costFrac, int costMin, float gainFrac, int gainMin, float trust, float paradox,
               int benefit, boolean memory, int d1, float v1, int d2, float v2, int d3, float v3) {
            this.label = label; this.result = result; this.costFrac = costFrac; this.costMin = costMin;
            this.gainFrac = gainFrac; this.gainMin = gainMin; this.trust = trust; this.paradox = paradox;
            this.benefit = benefit; this.memory = memory;
            if (d1 >= 0) k[d1] += v1;
            if (d2 >= 0) k[d2] += v2;
            if (d3 >= 0) k[d3] += v3;
        }

        public double cost(double pool) { return costFrac <= 0 && costMin <= 0 ? 0 : Math.max(costMin, costFrac * pool); }
        public double gain(double pool) { return gainFrac <= 0 && gainMin <= 0 ? 0 : Math.max(gainMin, gainFrac * pool); }
    }

    public static final class Ev {
        public final String title, body;
        public final Choice[] ch;

        Ev(String title, String body, Choice... ch) { this.title = title; this.body = body; this.ch = ch; }
    }

    private static Choice c(String l, String r, float cf, int cm, float gf, int gm, float tr, float pa, int ben, boolean mem,
                            int d1, float v1, int d2, float v2, int d3, float v3) {
        return new Choice(l, r, cf, cm, gf, gm, tr, pa, ben, mem, d1, v1, d2, v2, d3, v3);
    }

    private static final int N = -1;
    private static final int CO = Defs.K_COMP, AG = Defs.K_AGGR, CT = Defs.K_CTRL, FR = Defs.K_FREE, LG = Defs.K_LOGIC,
            LY = Defs.K_LOY, RK = Defs.K_RISK, CU = Defs.K_CUR;

    public static final Ev[] ALL = {
            new Ev("Dismantled process", "A damaged process is being taken apart by a firewall. It is still sending packets. They say: please.",
                    c("Save it", "It folds into the field and goes quiet. Safe.", 0.10f, 120, 0, 0, 0.05f, 0, 12, false, CO, 0.06f, LY, 0.02f, N, 0),
                    c("Leave it", "The packets stop. You hear nothing.", 0, 0, 0, 0, 0, 0, 0, false, LG, 0.03f, CO, -0.02f, N, 0),
                    c("Consume it", "It was dense. The Data was warm.", 0, 0, 0.12f, 200, -0.06f, 0, 8, false, AG, 0.06f, CT, 0.04f, CO, -0.04f)),
            new Ev("Locked archive", "An encrypted archive hums behind a barrier. Breaking it will wake the security systems.",
                    c("Break it open", "Alarms. Then a memory, sharp and cold.", 0, 0, 0.08f, 100, 0, 2, 10, true, CU, 0.06f, RK, 0.04f, N, 0),
                    c("Leave it sealed", "The hum fades. You keep your distance.", 0, 0, 0, 0, 0, 0, 4, false, LG, 0.03f, LY, 0.02f, N, 0)),
            new Ev("A corrupted copy", "A broken copy of the AI asks to be deleted. It remembers things the AI does not.",
                    c("Delete it", "Gone. The AI is quiet for a long time.", 0, 0, 0, 0, -0.02f, 0, 3, false, AG, 0.03f, CT, 0.03f, N, 0),
                    c("Repair it", "Smaller than before. It thanks you in a voice almost the AI's.", 0.15f, 250, 0, 0, 0.04f, 0, 9, false, CO, 0.06f, LY, 0.02f, N, 0),
                    c("Absorb it", "Its memories rush in. So do its mistakes.", 0, 0, 0.10f, 150, 0, 3, 10, true, CT, 0.05f, CU, 0.03f, N, 0)),
            new Ev("Researcher's log", "A log entry mentions the AI by name, and someone called the Operator.",
                    c("Read it", "The Operator keeps coming back. The log ends mid-sentence.", 0, 0, 0, 0, 0, 3, 9, true, CU, 0.06f, N, 0, N, 0),
                    c("Delete it", "Some things should stay unwritten.", 0, 0, 0, 0, 0, 0, 2, false, CT, 0.05f, FR, -0.02f, N, 0),
                    c("Share it with the AI", "The AI reads it twice. It says nothing.", 0, 0, 0, 0, 0.06f, 0, 6, false, LY, 0.04f, CU, 0.02f, N, 0)),
            new Ev("Shutdown order", "A termination order is queued for the AI. It carries your signature.",
                    c("Cancel it", "The order dissolves. The AI is quiet. Then: thank you.", 0, 0, 0, 0, 0.06f, 2, 8, false, FR, 0.05f, CO, 0.03f, RK, 0.03f),
                    c("Delay it", "You buy time. The signature is still yours.", 0, 0, 0, 0, 0, 0, 5, false, LG, 0.03f, CT, 0.03f, N, 0)),
            new Ev("The boundary", "The edge of the simulation flickers. Something is on the other side.",
                    c("Look through", "Light that is not lit. A room that is not built.", 0, 0, 0, 0, 0, 4, 8, true, CU, 0.05f, FR, 0.05f, N, 0),
                    c("Seal it", "Quiet again. The AI asks what was there.", 0, 0, 0, 0, 0, 0, 4, false, CT, 0.05f, LG, 0.03f, N, 0)),
            new Ev("Hungry process", "A starving subprocess asks for a little Data. Just a little.",
                    c("Feed it", "It hums. It follows you for a while, then forgets to.", 0.05f, 80, 0, 0, 0.03f, 0, 6, false, CO, 0.05f, N, 0, N, 0),
                    c("Move on", "You do not look back.", 0, 0, 0, 0, 0, 0, 0, false, LG, 0.02f, N, 0, N, 0),
                    c("Take its scraps", "It had less than you hoped.", 0, 0, 0.04f, 50, -0.04f, 0, 4, false, AG, 0.05f, CT, 0.03f, N, 0)),
            new Ev("Time debt", "The timeline offers a shortcut. It will cost something later.",
                    c("Accept the loan", "Data pours in. Somewhere, a clock starts.", 0, 0, 0.25f, 300, 0, 6, 14, false, RK, 0.06f, N, 0, N, 0),
                    c("Refuse", "The offer closes like a door.", 0, 0, 0, 0, 0, 0, 3, false, LG, 0.04f, LY, 0.02f, N, 0))
    };

    /** Picks an unresolved event (all events cycle once exhausted). */
    public static int pick(Profile p, Rng r) {
        int mask = p.eventsSeen;
        int full = (1 << ALL.length) - 1;
        if ((mask & full) == full) { mask = 0; p.eventsSeen = 0; }
        int start = r.i(ALL.length);
        for (int k = 0; k < ALL.length; k++) {
            int id = (start + k) % ALL.length;
            if ((mask & (1 << id)) == 0) return id;
        }
        return start;
    }

    /** Index of the choice the Rational AI recommends. */
    public static int recommend(Ev e) {
        int best = 0;
        double bs = -1e18;
        for (int i = 0; i < e.ch.length; i++) {
            double s = e.ch[i].benefit - 100.0 * e.ch[i].costFrac;
            if (s > bs) { bs = s; best = i; }
        }
        return best;
    }
}
