package com.neuralfeed.game;

import com.neuralfeed.audio.Sfx;
import com.neuralfeed.core.Mx;
import com.neuralfeed.meta.Defs;

/** Boss mechanics. Each boss has its own signature: barriers, memory shield, bonus-eating aura, prediction, arena manipulation. */
final class BossAI {
    private BossAI() {}

    static final int RING_N = 18, GAP = 4;

    static boolean present(int k) { return k >= GAP; }
    static float ringR(Enemy b) { return 4.4f + 0.3f * Mx.sin(b.t3 * 1.5f); }
    static float nodeX(Enemy b, int k) { return b.x + Mx.cos(b.ax + k * Mx.TAU / RING_N) * ringR(b); }
    static float nodeY(Enemy b, int k) { return b.y + Mx.sin(b.ax + k * Mx.TAU / RING_N) * ringR(b); }

    static void update(World w, Enemy b, float dt) {
        float hpf = b.hp / b.maxHp;
        int ph = hpf < 0.33f ? 2 : (hpf < 0.66f ? 1 : 0);
        if (ph != b.ph) { b.ph = ph; phaseChange(w, b); }
        b.rot += dt * 0.5f;
        switch (b.bossId) {
            case Defs.B_FIREWALL: firewall(w, b, dt); break;
            case Defs.B_ARCHIVIST: archivist(w, b, dt); break;
            case Defs.B_EATER: eater(w, b, dt); break;
            case Defs.B_OBSERVER: observer(w, b, dt); break;
            default: paradox(w, b, dt); break;
        }
    }

    private static void phaseChange(World w, Enemy b) {
        w.shake(18f);
        w.env.sfx(Sfx.BOSS_WARN, 1f);
        w.burst(Particles.WHITE, b.x, b.y, 40, 9f, 0.8f, 3f);
        for (int i = 0; i < 6; i++) {
            float a = i * Mx.TAU / 6f;
            w.spawn(i % 2 == 0 ? Kinds.DRONE : Kinds.VIRUS, Mx.clamp(b.x + Mx.cos(a) * 2.4f, 1f, w.arena.W - 1f), Mx.clamp(b.y + Mx.sin(a) * 2.4f, 1f, w.arena.H - 1f));
        }
        if (b.bossId == Defs.B_FIREWALL && b.ph == 2) {
            w.spawn(Kinds.FIREWALL, Mx.clamp(b.x - 5f, 1f, w.arena.W - 1f), b.y + 3f);
            w.spawn(Kinds.FIREWALL, Mx.clamp(b.x + 5f, 1f, w.arena.W - 1f), b.y + 3f);
        }
        if (b.bossId == Defs.B_PARADOX) w.glitch = 1f;
    }

    private static void firewall(World w, Enemy b, float dt) {
        Player pl = w.pl;
        b.t3 += dt;
        b.vx = Mx.sin(w.time * 0.4f) * 1.2f;
        b.vy = (w.arena.bossY - b.y) * 1f;
        b.ax += (0.6f + 0.25f * b.ph) * dt;
        if (pl.invuln <= 0f && pl.dashT <= 0f) {
            for (int k = 0; k < RING_N; k++) {
                if (!present(k)) continue;
                float dx = nodeX(b, k) - pl.x, dy = nodeY(b, k) - pl.y, rr = 0.34f + pl.r;
                if (dx * dx + dy * dy < rr * rr) { w.damagePlayer(b.dmg, false); break; }
            }
        }
        b.t -= dt;
        if (b.t <= 0f) {
            b.t = 2.8f - 0.3f * b.ph;
            int n = 3 + b.ph;
            float base = Mx.atan2(pl.y - b.y, pl.x - b.x);
            float dmg = 6f * w.dmgScale();
            for (int i = 0; i < n; i++) {
                float a = base + (i - (n - 1) * 0.5f) * 0.22f;
                w.bul.spawn(b.x, b.y, Mx.cos(a) * 4.5f, Mx.sin(a) * 4.5f, dmg, Bullets.PACKET, 5f);
            }
            if (b.ph >= 1) w.ring(b.x, b.y, 8, 3f, dmg, Bullets.PACKET, w.rng.ang(), 4f);
            w.env.sfx(Sfx.BOSS_WARN, 0.4f, 1.3f);
        }
    }

    private static void archivist(World w, Enemy b, float dt) {
        b.t3 += dt * 0.35f;
        float tx = w.arena.W * 0.5f + Mx.cos(b.t3) * 5f, ty = w.arena.H * 0.32f + Mx.sin(b.t3 * 1.3f) * 3f;
        b.vx = (tx - b.x) * 1.5f; b.vy = (ty - b.y) * 1.5f;
        int frag = 0;
        for (int i = 0; i < w.enHi; i++) if (w.en[i].alive && w.en[i].kind == Kinds.MEMFRAG) frag++;
        b.immune = frag > 0;
        b.t2 -= dt;
        if (frag == 0 && b.t2 <= 0f) {
            int n = 4 + 2 * b.ph;
            for (int i = 0; i < n; i++) {
                Enemy f = w.spawn(Kinds.MEMFRAG, b.x, b.y);
                if (f != null) f.ax = i * Mx.TAU / n;
            }
            b.t2 = 8f;
            w.env.sfx(Sfx.BOSS_WARN, 0.8f);
            w.burst(Particles.VIOLET, b.x, b.y, 30, 6f, 0.7f, 2.5f);
        }
        b.t -= dt;
        if (b.t <= 0f) {
            b.t = 0.28f - 0.04f * b.ph;
            b.ay += 0.55f;
            float dmg = 5f * w.dmgScale();
            w.bul.spawn(b.x, b.y, Mx.cos(b.ay) * 3.4f, Mx.sin(b.ay) * 3.4f, dmg, Bullets.PACKET, 5f);
            if (b.ph >= 1) w.bul.spawn(b.x, b.y, Mx.cos(b.ay + Mx.PI) * 3.4f, Mx.sin(b.ay + Mx.PI) * 3.4f, dmg, Bullets.PACKET, 5f);
        }
    }

    private static void eater(World w, Enemy b, float dt) {
        Player pl = w.pl;
        float spd = 1.7f + 0.25f * b.ph;
        EnemyAI.steer(b, pl.x, pl.y, spd, 2f, dt);
        float d = Mx.len(pl.x - b.x, pl.y - b.y);
        if (d < 4.2f) pl.supp = Mx.max(pl.supp, 0.6f);
        b.t -= dt;
        if (b.t <= 0f) { b.t = 6.5f; b.st = 1; b.ay = 0.5f; b.t3 = 0f; w.env.sfx(Sfx.BOSS_WARN, 1f); }
        if (b.st == 1) {
            b.ay += 6f * dt;
            if (b.t3 == 0f && Mx.abs(d - b.ay) < 0.5f && pl.dashT <= 0f) {
                b.t3 = 1f;
                pl.supp = 3f;
                w.stripBonuses();
                w.shake(10f);
            }
            if (b.ay > 9f) b.st = 0;
        }
    }

    private static void observer(World w, Enemy b, float dt) {
        Player pl = w.pl;
        float dx = b.x - pl.x, dy = b.y - pl.y, d = Mx.max(0.01f, Mx.len(dx, dy));
        float rad = d < 6.5f ? 1f : (d > 8.5f ? -1f : 0f);
        float tvx = dx / d * rad * 2.4f - dy / d * 1.2f, tvy = dy / d * rad * 2.4f + dx / d * 1.2f;
        float k = Mx.min(1f, 2f * dt);
        b.vx += (tvx - b.vx) * k; b.vy += (tvy - b.vy) * k;
        b.t -= dt;
        if (b.st == 0 && b.t <= 0f) {
            b.st = 1; b.t2 = 0.5f;
            float tHit = d / 6f;
            b.ax = pl.x + pl.vx * tHit; b.ay = pl.y + pl.vy * tHit;
            w.env.sfx(Sfx.BOSS_WARN, 0.5f, 1.6f);
        } else if (b.st == 1) {
            b.t2 -= dt;
            if (b.t2 <= 0f) {
                int n = b.ph >= 1 ? 3 : 1;
                float base = Mx.atan2(b.ay - b.y, b.ax - b.x);
                float dmg = 7f * w.dmgScale();
                for (int i = 0; i < n; i++) {
                    float a = base + (i - (n - 1) * 0.5f) * 0.18f;
                    w.bul.spawn(b.x, b.y, Mx.cos(a) * 6f, Mx.sin(a) * 6f, dmg, Bullets.SHOT, 4f);
                }
                b.st = 0; b.t = 1.7f - 0.3f * b.ph;
            }
        }
        if (b.ph == 2) {
            b.t3 -= dt;
            if (b.t3 <= 0f) { b.t3 = 8f; w.spawn(Kinds.HUNTER, b.x, b.y); }
        }
    }

    private static void paradox(World w, Enemy b, float dt) {
        Player pl = w.pl;
        Arena ar = w.arena;
        b.vx *= Mx.exp(-3f * dt); b.vy *= Mx.exp(-3f * dt);
        b.t -= dt;
        if (b.t <= 0f) {
            b.t = 5f;
            w.burst(Particles.WHITE, b.x, b.y, 24, 6f, 0.5f, 2.6f);
            b.x = w.rng.range(4f, ar.W - 4f); b.y = w.rng.range(4f, ar.H * 0.5f);
            w.burst(Particles.WHITE, b.x, b.y, 24, 6f, 0.5f, 2.6f);
            w.glitch = 1f;
        }
        b.t2 -= dt;
        if (b.t2 <= 0f) {
            b.t2 = 7.5f;
            w.env.sfx(Sfx.BOSS_WARN, 1f, 0.8f);
            w.shake(14f);
            w.glitch = 1f;
            for (int i = 0; i < ar.nc; i++) {
                if (w.rng.chance(0.4f)) {
                    float x = w.rng.range(2f, ar.W - 2f), y = w.rng.range(2f, ar.H - 2f);
                    if (Mx.len(x - pl.x, y - pl.y) > 3f) { ar.cx[i] = x; ar.cy[i] = y; }
                }
            }
            int echoes = b.ph >= 2 ? 2 : 1;
            for (int i = 0; i < echoes; i++) {
                int idx = w.histIndex(30 + i * 10);
                w.spawn(Kinds.ECHO, w.histX[idx], w.histY[idx]);
            }
            int slot = 0;
            for (int i = 0; i < 3; i++) if (w.riftT[i] <= 0f) { slot = i; break; }
            w.riftX[slot] = Mx.clamp(pl.x + w.rng.range(-3f, 3f), 2f, ar.W - 2f);
            w.riftY[slot] = Mx.clamp(pl.y + w.rng.range(-3f, 3f), 2f, ar.H - 2f);
            w.riftR[slot] = 2.6f; w.riftT[slot] = 9f; w.riftType[slot] = 0;
        }
        b.t3 -= dt;
        if (b.t3 <= 0f) {
            b.t3 = 3.6f;
            w.ring(b.x, b.y, 10, 3f, 6f * w.dmgScale(), Bullets.RING, w.rng.ang(), 5f);
        }
    }
}
