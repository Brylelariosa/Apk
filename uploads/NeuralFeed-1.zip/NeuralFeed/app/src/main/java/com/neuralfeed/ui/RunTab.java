package com.neuralfeed.ui;

import android.graphics.Canvas;
import android.graphics.Paint;

import com.neuralfeed.audio.Sfx;
import com.neuralfeed.core.Fmt;
import com.neuralfeed.data.Profile;
import com.neuralfeed.meta.CoreStats;
import com.neuralfeed.meta.Defs;
import com.neuralfeed.meta.StatsCalc;
import com.neuralfeed.meta.Timelines;
import com.neuralfeed.render.CoreArt;
import com.neuralfeed.render.Gfx;
import com.neuralfeed.render.Theme;
import com.neuralfeed.render.Ui;

/** Loadout and run start. */
final class RunTab extends Tab {
    private final CoreStats cs = new CoreStats();
    private int viewArch;

    RunTab(App app, HubScreen hub) { super(app, hub); viewArch = app.pf.archetype; }

    @Override void draw(Canvas c, float x, float y, float w, float h, float scroll) {
        Gfx g = app.gfx;
        Ui ui = app.ui;
        Theme th = app.wr.th;
        Profile pf = app.pf;
        float dp = g.dp, cx = x + w * 0.5f, yy = y - scroll + 8f * dp;
        StatsCalc.compute(pf, cs);
        // core preview
        float coreY = yy + 78f * dp;
        g.ring(c, cx, coreY, 64f * dp, dp, Gfx.alpha(th.accent, 70));
        g.arc(c, cx, coreY, 64f * dp, app.time * 50f, 50f, 2f * dp, Gfx.alpha(th.accent, 170));
        CoreArt.draw(g, c, cx, coreY, 28f * dp, StatsCalc.coreTier(pf), app.time, 0.25f, th.accent, th.data2, 0f);
        yy += 160f * dp;
        g.text(c, "Archetype", cx, yy, 11f, Gfx.alpha(th.text, 120), Paint.Align.CENTER, g.cond);
        yy += 24f * dp;
        // archetype selector
        boolean unlocked = StatsCalc.archetypeUnlocked(pf, viewArch);
        if (vis(yy - 20f * dp, 44f * dp, y, h)) {
            ui.button(c, 101, "\u2039", x, yy - 22f * dp, 44f * dp, 40f * dp, true, Ui.ST_NORMAL, th.accent, th.text, th.bg);
            ui.button(c, 102, "\u203a", x + w - 44f * dp, yy - 22f * dp, 44f * dp, 40f * dp, true, Ui.ST_NORMAL, th.accent, th.text, th.bg);
        }
        g.text(c, Defs.ARCH_NAMES[viewArch], cx, yy + 2f * dp, 19f, unlocked ? th.text : Gfx.alpha(th.text, 120), Paint.Align.CENTER, g.condB);
        yy += 26f * dp;
        g.text(c, Defs.ARCH_DESC[viewArch], cx, yy, 12.5f, Gfx.alpha(th.text, 170), Paint.Align.CENTER, g.cond);
        yy += 24f * dp;
        if (!unlocked) {
            String need = viewArch == Defs.ARCH_TEMPORAL ? "Unlocks after your first time travel" : "Unlocks at AI level " + Defs.ARCH_LEVEL[viewArch];
            g.text(c, need, cx, yy, 12f, th.hostile, Paint.Align.CENTER, g.cond);
        } else if (vis(yy - 14f * dp, 40f * dp, y, h)) {
            boolean eq = pf.archetype == viewArch;
            ui.button(c, 103, eq ? "EQUIPPED" : "EQUIP", cx - 60f * dp, yy - 14f * dp, 120f * dp, 34f * dp, !eq, Ui.ST_NORMAL, th.accent, th.text, th.bg);
        }
        yy += 40f * dp;
        // stats
        g.text(c, "POWER " + Fmt.num(cs.power) + "   RATE " + Fmt.f1(cs.rate) + "/s   RANGE " + Fmt.f1(cs.range) + "   COLLECT " + Fmt.f1(cs.collect), cx, yy, 11.5f, Gfx.alpha(th.text, 190), Paint.Align.CENTER, g.cond);
        yy += 14f * dp;
        g.text(c, "HEALTH " + Fmt.num(cs.maxHp) + "   SHIELD " + Fmt.num(cs.shield) + "   SPEED " + Fmt.f1(cs.speed), cx, yy + 4f * dp, 11.5f, Gfx.alpha(th.text, 150), Paint.Align.CENTER, g.cond);
        yy += 38f * dp;
        // ability slots
        g.text(c, "Abilities", cx, yy, 11f, Gfx.alpha(th.text, 120), Paint.Align.CENTER, g.cond);
        yy += 12f * dp;
        float sw = (w - 20f * dp) / 3f;
        int slots = StatsCalc.slotCount(pf);
        for (int k = 0; k < 3; k++) {
            float sx = x + k * (sw + 10f * dp);
            if (k < slots) {
                int ab = pf.slots[k];
                boolean has = ab >= 0 && StatsCalc.abilityUnlocked(pf, ab);
                if (vis(yy, 62f * dp, y, h)) ui.button(c, 104 + k, has ? Defs.AB_NAMES[ab] : "Empty", sx, yy, sw, 62f * dp, true, Ui.ST_NORMAL, th.accent, th.text, th.bg);
            } else {
                g.rrectLine(c, sx, yy, sw, 62f * dp, 9f * dp, dp, Gfx.alpha(th.text, 40));
                g.text(c, "AI LV 6", sx + sw * 0.5f, yy + 36f * dp, 11f, Gfx.alpha(th.text, 90), Paint.Align.CENTER, g.cond);
            }
        }
        yy += 82f * dp;
        // plan
        g.text(c, "Run plan", cx, yy, 11f, Gfx.alpha(th.text, 120), Paint.Align.CENTER, g.cond);
        yy += 24f * dp;
        float step = (w - 40f * dp) / 5f, px = x + 20f * dp;
        String[] lab = {"S", "S", "E", "S", "D", "B"};
        g.seg(c, px, yy, px + step * 5f, yy, dp, Gfx.alpha(th.text, 60));
        for (int i = 0; i < 6; i++) {
            float nx = px + step * i;
            boolean boss = i == 5;
            g.circle(c, nx, yy, (boss ? 13f : 10f) * dp, th.bg);
            g.ring(c, nx, yy, (boss ? 13f : 10f) * dp, 1.4f * dp, i == 2 || i == 4 || boss ? th.data : Gfx.alpha(th.accent, 200));
            g.text(c, lab[i], nx, yy + 4f * dp, 10.5f, th.text, Paint.Align.CENTER, g.condB);
            if (i == 2 || i == 4 || boss) g.text(c, "extract", nx, yy + 26f * dp, 9f, Gfx.alpha(th.data, 200), Paint.Align.CENTER, g.cond);
        }
        yy += 52f * dp;
        if (Timelines.canActivate(pf)) {
            g.text(c, "Temporal core ready \u2014 see TIME", cx, yy, 12.5f, th.data, Paint.Align.CENTER, g.condB);
            yy += 22f * dp;
        }
        String label = pf.timeline >= 10 ? "ENTER TIMELINE 0" : "BEGIN RUN";
        if (vis(yy, 56f * dp, y, h)) ui.button(c, 107, label, x, yy, w, 56f * dp, true, Ui.ST_PRIMARY, th.accent, th.text, th.bg);
        yy += 76f * dp;
        contentH = yy + scroll - y;
    }

    @Override void click(int id) {
        Profile pf = app.pf;
        switch (id) {
            case 101: viewArch = (viewArch + Defs.ARCH_N - 1) % Defs.ARCH_N; app.tap(); break;
            case 102: viewArch = (viewArch + 1) % Defs.ARCH_N; app.tap(); break;
            case 103:
                if (StatsCalc.archetypeUnlocked(pf, viewArch)) { pf.archetype = viewArch; app.audio.sfx(Sfx.UI_BUY, 0.8f); app.saveNow(); }
                break;
            case 104: case 105: case 106: {
                int k = id - 104, cur = pf.slots[k], next = cur;
                for (int i = 0; i <= Defs.AB_N; i++) {
                    next = next + 1 > Defs.AB_N - 1 ? -1 : next + 1;
                    if (next < 0) break;
                    boolean used = false;
                    for (int s = 0; s < 3; s++) if (s != k && pf.slots[s] == next) used = true;
                    if (!used && StatsCalc.abilityUnlocked(pf, next)) break;
                }
                pf.slots[k] = next;
                app.tap();
                break;
            }
            case 107:
                app.audio.sfx(Sfx.UI_OPEN, 0.9f);
                app.saveNow();
                app.setScreen(new GameScreen(app));
                break;
            default: break;
        }
    }
}
