package com.neuralfeed.render;

import android.graphics.Canvas;
import android.graphics.Paint;

/** Immediate-mode widgets: draw calls register hit rectangles that the next touch events resolve. */
public final class Ui {
    public static final int MAXW = 128;
    public static final int ST_NORMAL = 0, ST_PRIMARY = 1, ST_DANGER = 2, ST_QUIET = 3;
    private static final int K_BTN = 0, K_SLIDER = 1;

    private final Gfx g;
    private final float[] x = new float[MAXW], y = new float[MAXW], w = new float[MAXW], h = new float[MAXW];
    private final int[] id = new int[MAXW];
    private final byte[] kind = new byte[MAXW];
    private int n;
    private int downId = -1, activeSlider = -1;
    private float downX, downY, lastY, touchX;
    public boolean moved;
    public float dragDy;

    public Ui(Gfx g) { this.g = g; }

    public void begin() { n = 0; dragDy = 0f; }

    private void reg(int wid, float rx, float ry, float rw, float rh, int k) {
        if (n >= MAXW) return;
        x[n] = rx; y[n] = ry; w[n] = rw; h[n] = rh; id[n] = wid; kind[n] = (byte) k; n++;
    }

    private int hit(float px, float py) {
        for (int i = n - 1; i >= 0; i--) if (px >= x[i] && px <= x[i] + w[i] && py >= y[i] && py <= y[i] + h[i]) return i;
        return -1;
    }

    private boolean pressed(int wid) { return downId == wid && !moved; }

    public void button(Canvas c, int wid, String label, float bx, float by, float bw, float bh, boolean enabled, int style, int accent, int text, int bg) {
        float dp = g.dp, rad = 9f * dp;
        boolean pr = enabled && pressed(wid);
        int col = style == ST_DANGER ? 0xFFFF6B7A : accent;
        switch (style) {
            case ST_PRIMARY:
                g.rrect(c, bx, by, bw, bh, rad, enabled ? Gfx.alpha(col, pr ? 190 : 255) : Gfx.alpha(col, 50));
                g.text(c, label, bx + bw * 0.5f, by + bh * 0.5f + 5.5f * dp, 16f, enabled ? bg : Gfx.alpha(text, 110), Paint.Align.CENTER, g.condB);
                break;
            case ST_QUIET:
                if (pr) g.rrect(c, bx, by, bw, bh, rad, Gfx.alpha(col, 30));
                g.text(c, label, bx + bw * 0.5f, by + bh * 0.5f + 5f * dp, 14f, enabled ? Gfx.alpha(text, pr ? 255 : 200) : Gfx.alpha(text, 90), Paint.Align.CENTER, g.cond);
                break;
            default:
                if (pr) g.rrect(c, bx, by, bw, bh, rad, Gfx.alpha(col, 46));
                g.rrectLine(c, bx, by, bw, bh, rad, 1.3f * dp, Gfx.alpha(col, enabled ? 200 : 60));
                g.text(c, label, bx + bw * 0.5f, by + bh * 0.5f + 5f * dp, 15f, enabled ? text : Gfx.alpha(text, 100), Paint.Align.CENTER, g.cond);
                break;
        }
        if (enabled) reg(wid, bx, by, bw, bh, K_BTN);
    }

    /** Returns the (possibly user-updated) value 0..1. */
    public float slider(Canvas c, int wid, String label, float sx, float sy, float sw, float value, int accent, int text) {
        float dp = g.dp;
        if (activeSlider >= 0 && id[activeSlider] == wid) value = Math.max(0f, Math.min(1f, (touchX - sx) / sw));
        g.text(c, label, sx, sy, 13f, Gfx.alpha(text, 220), Paint.Align.LEFT, g.cond);
        g.text(c, (int) (value * 100f + 0.5f) + "%", sx + sw, sy, 13f, Gfx.alpha(text, 150), Paint.Align.RIGHT, g.cond);
        float ty = sy + 14f * dp;
        g.seg(c, sx, ty, sx + sw, ty, 2f * dp, Gfx.alpha(text, 50));
        g.seg(c, sx, ty, sx + sw * value, ty, 2f * dp, accent);
        g.circle(c, sx + sw * value, ty, 7f * dp, accent);
        reg(wid, sx - 10f * dp, sy - 14f * dp, sw + 20f * dp, 44f * dp, K_SLIDER);
        return value;
    }

    public void toggle(Canvas c, int wid, String label, float tx, float ty, float tw, boolean on, int accent, int text) {
        float dp = g.dp, ph = 22f * dp, pw = 40f * dp;
        g.text(c, label, tx, ty + 6f * dp, 14f, Gfx.alpha(text, 230), Paint.Align.LEFT, g.cond);
        float px = tx + tw - pw, py = ty - ph * 0.5f + 1f * dp;
        g.rrectLine(c, px, py, pw, ph, ph * 0.5f, 1.3f * dp, Gfx.alpha(on ? accent : text, on ? 220 : 90));
        g.circle(c, on ? px + pw - ph * 0.5f : px + ph * 0.5f, py + ph * 0.5f, ph * 0.32f, on ? accent : Gfx.alpha(text, 120));
        reg(wid, tx, ty - 18f * dp, tw, 40f * dp, K_BTN);
    }

    // ---- touch ----
    public void down(float px, float py) {
        int i = hit(px, py);
        downId = i >= 0 ? id[i] : -1;
        activeSlider = i >= 0 && kind[i] == K_SLIDER ? i : -1;
        downX = px; downY = py; lastY = py; touchX = px; moved = false;
    }

    public void move(float px, float py) {
        touchX = px;
        dragDy += py - lastY;
        lastY = py;
        float s = 10f * g.dp;
        if (Math.abs(px - downX) > s || Math.abs(py - downY) > s) moved = true;
    }

    /** Returns the id of a clicked button, or -1. */
    public int up(float px, float py) {
        int res = -1;
        if (activeSlider < 0 && downId >= 0 && !moved) {
            int i = hit(px, py);
            if (i >= 0 && id[i] == downId) res = downId;
        }
        downId = -1; activeSlider = -1; moved = false;
        return res;
    }

    public boolean sliding() { return activeSlider >= 0; }
    public boolean scrolling() { return moved && activeSlider < 0; }
}
