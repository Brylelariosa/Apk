package com.neuralfeed.ui;

import android.graphics.Canvas;
import android.graphics.Paint;

import com.neuralfeed.core.Mx;
import com.neuralfeed.game.Dialogue;
import com.neuralfeed.meta.Defs;
import com.neuralfeed.meta.Lines;
import com.neuralfeed.meta.StatsCalc;
import com.neuralfeed.render.CoreArt;
import com.neuralfeed.render.Gfx;
import com.neuralfeed.render.Theme;

/** Title: drifting data, the core, a glitching wordmark. Tap to enter. */
public final class TitleScreen extends Screen {
    private float t;
    private boolean said;

    public TitleScreen(App app) { super(app); }

    @Override public void update(float dt) {
        t += dt;
        if (!said && t > 1.0f) {
            said = true;
            if (!app.pf.flag(Defs.F_BOOT)) { app.pf.flags |= Defs.F_BOOT; app.say(Dialogue.SYS, Lines.BOOT); }
            else if (app.pf.sessions >= 2 && !app.pf.flag(Defs.F_CAME_BACK)) { app.pf.flags |= Defs.F_CAME_BACK; app.say(Dialogue.AI, Lines.CAME_BACK); }
        }
    }

    @Override public void draw(Canvas c) {
        Gfx g = app.gfx;
        Theme th = app.wr.th;
        int w = app.w, h = app.h;
        float dp = g.dp;
        c.drawColor(th.bg);
        for (int i = 0; i < 46; i++) {
            float fx = Mx.hash(i * 3 + 1), fy = (Mx.hash(i * 7 + 2) + t * (0.015f + 0.03f * Mx.hash(i))) % 1f;
            g.pb.pt(fx * w, fy * h);
        }
        g.pts.setStrokeWidth(2.2f * dp); g.pts.setColor(Gfx.alpha(th.data, 90));
        g.pb.points(c, g.pts);
        float cx = w * 0.5f, cy = h * 0.37f;
        g.ring(c, cx, cy, 118f * dp, dp, Gfx.alpha(th.accent, 50));
        g.arc(c, cx, cy, 118f * dp, t * 40f, 60f, 2f * dp, Gfx.alpha(th.accent, 160));
        CoreArt.draw(g, c, cx, cy, 36f * dp, Math.max(1, StatsCalc.coreTier(app.pf)), t, 0.3f, th.accent, th.data2, 0f);
        float ty = h * 0.58f;
        float ph = t % 4.2f;
        if (ph < 0.16f && !app.pf.noFlash) {
            g.tracked(c, "NEURAL//FEED", w * 0.5f - 4f * dp, ty, 34f, 0.16f, Gfx.alpha(th.accent, 130), Paint.Align.CENTER, g.thin);
            g.tracked(c, "NEURAL//FEED", w * 0.5f + 4f * dp, ty + 1f * dp, 34f, 0.16f, Gfx.alpha(th.hostile, 130), Paint.Align.CENTER, g.thin);
        }
        g.tracked(c, "NEURAL//FEED", w * 0.5f, ty, 34f, 0.16f, th.text, Paint.Align.CENTER, g.thin);
        g.tracked(c, "AN AI IS WAITING TO BE FED", w * 0.5f, ty + 26f * dp, 10.5f, 0.3f, Gfx.alpha(th.text, 120), Paint.Align.CENTER, g.cond);
        if (((int) (t * 1.6f) & 1) == 0 || t < 1.5f) g.tracked(c, "TAP TO ENTER", w * 0.5f, h * 0.9f, 11f, 0.35f, Gfx.alpha(th.text, 170), Paint.Align.CENTER, g.condB);
        app.hud.dialogue(c, app.dlg, 24f * dp, h * 0.7f, w - 48f * dp, th.accent, th.text);
    }

    @Override public void up(float x, float y, int id) {
        app.tap();
        app.setScreen(new HubScreen(app));
    }
}
