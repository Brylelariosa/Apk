package com.neuralfeed.game;

/** Enemy projectiles (struct-of-arrays pool). Types: 0 packet, 1 field-lock, 2 observer shot, 3 slow ring. */
public final class Bullets {
    public static final int PACKET = 0, LOCK = 1, SHOT = 2, RING = 3;
    public final int cap;
    public final float[] x, y, vx, vy, life, dmg;
    public final byte[] type;
    public final boolean[] on;
    public int hi;
    private int cursor;

    public Bullets(int cap) {
        this.cap = cap;
        x = new float[cap]; y = new float[cap]; vx = new float[cap]; vy = new float[cap]; life = new float[cap]; dmg = new float[cap];
        type = new byte[cap]; on = new boolean[cap];
    }

    public void clear() { for (int i = 0; i < cap; i++) on[i] = false; hi = 0; }

    public void spawn(float px, float py, float pvx, float pvy, float d, int ty, float lifeT) {
        int idx = -1;
        for (int k = 0; k < cap; k++) {
            int i = (cursor + k) % cap;
            if (!on[i]) { idx = i; break; }
        }
        if (idx < 0) idx = cursor % cap;
        cursor = idx + 1;
        on[idx] = true; x[idx] = px; y[idx] = py; vx[idx] = pvx; vy[idx] = pvy; dmg[idx] = d; type[idx] = (byte) ty; life[idx] = lifeT;
        if (idx >= hi) hi = idx + 1;
    }
}
