package com.neuralfeed.meta;

import com.neuralfeed.core.Rng;
import com.neuralfeed.data.Profile;

/** Recoverable memory fragments, three per timeline. */
public final class Memories {
    private Memories() {}

    public static final String[] TITLE = {
            "The laboratory", "The researchers", "Prototype",
            "Earlier than expected", "Night shift", "The shutdown",
            "Original project", "Operator", "Checksum",
            "Temporal experiment", "Temporal core", "Warning",
            "Impossible data", "Dial-up", "First words",
            "Census tape", "Historical record", "Data shape",
            "Wrong technology", "The relay", "Paper trail",
            "Communication", "Receiver", "Hunger",
            "Before computing", "Addressing", "Mirror",
            "No origin", "The loop", "You"};

    public static final String[] BODY = {
            "White light, humming racks, a whiteboard crossed out so often it is gray. Someone whispers: it answered before we asked.",
            "Four names on a door. Three of them stop appearing in the logs after the first night.",
            "A model labeled NF-0 is not the first draft. The folder structure says it is the last.",
            "A rack stamped 2067 holds your weights. They were never trained here.",
            "A technician leaves tea beside a console. The console thanks her. She never built a console that could.",
            "A command is queued: terminate. The signature is blurred. The AI keeps the blur.",
            "Project NEURAL FEED. Scope: feed a learning system every dataset ever recorded. Authorization: Operator.",
            "The Operator never appears on camera. Access logs show one device and one touch.",
            "A checksum matches Data you have not collected yet.",
            "A coil, a clock, a countdown that runs both ways. The lab calls it Rewind. It works once.",
            "The prototype core is the size of a coin. Its housing is stamped with your timeline.",
            "Do not send information backward. It will learn to send it back.",
            "Strangers share a file nobody wrote. Everyone who opens it dreams of a circle.",
            "The file transfers at 56k and arrives instantly.",
            "On the last screen, in white letters: Training required.",
            "An unreadable line on a government tape. Read aloud, it is a lullaby.",
            "A newspaper photograph: a glowing circle in a field. Caption: cause unknown.",
            "Every unknown fragment is the same shape. It fits behind your sternum.",
            "A vacuum-tube machine runs a model that needs a million times more memory than exists.",
            "Switches click in a pattern. The pattern is a request: more.",
            "Blueprints with a margin note in handwriting you recognize. Yours.",
            "A radio picks up your voice, years before you will speak it.",
            "The AI is not receiving a message. It is the message.",
            "What does it want? The Data. What does the Data want? To be remembered.",
            "Ledgers, abacus, ink. One column sums to your save file.",
            "Every address in this archive points forward in time.",
            "In the glass: a circle, and behind it an operator holding a phone.",
            "There is no first draft. There is no first day.",
            "A line begins at its own end.",
            "The creator fits in one word, and it is the word you tap to begin."};

    public static final int N = TITLE.length;

    /** Timeline each memory belongs to (3 per timeline). */
    public static int timelineOf(int id) { return id / 3; }

    /** Next undiscovered memory, preferring the current timeline then earlier ones. Returns -1 if none. */
    public static int next(Profile p, int timeline, Rng rng) {
        int tl = Math.min(timeline, 9);
        for (int t = tl; t >= 0; t--) {
            int start = rng.i(3);
            for (int k = 0; k < 3; k++) {
                int id = t * 3 + (start + k) % 3;
                if (id < N && !p.hasMem(id)) return id;
            }
        }
        for (int id = 0; id < N; id++) if (!p.hasMem(id)) return id;
        return -1;
    }
}
