package com.neuralfeed.data;

import com.neuralfeed.core.Mx;
import com.neuralfeed.meta.Defs;

/** Everything that persists: progress, story, karma, settings, HUD layout. */
public final class Profile {
    public static final int VERSION = 1;

    // economy
    public double bank, lifetime, timelineData, xp;
    public final int[] up = new int[Defs.UP_N];
    public int wide;          // 0 none, 1 wide process, 2 condensed process
    public int wideUnlock;    // bit0 wide, bit1 condensed
    public int archetype;
    public final int[] slots = {Defs.AB_OVERCLOCK, Defs.AB_PULSE, -1};

    // personality
    public final float[] karma = new float[Defs.K_N];
    public final float[] prevKarma = new float[Defs.K_N];
    public int prevIdeology = -1;
    public float trust = 0.25f, bond = 0.1f, indep = 0f;
    public final int[] ideoTier = new int[4];

    // time
    public int timeline;      // 0..10
    public int cycle;
    public float paradox;     // 0..100
    public int echoes;
    public boolean bossDone;  // final boss of this timeline defeated
    public int bossMask;
    public int sacrifices;

    // story
    public long memLo, memHi, flags, hints;
    public int endings, unknownFound;
    public int eventsSeen;    // bitmask of decision events resolved

    // stats
    public int runs, deaths, extracts, kills, bossKills, sessions, maxDepth;
    public long lastSeen, playMs;
    public double dpm, xpm;   // data/min and training/min (EMA)

    // settings
    public float vMaster = 0.8f, vMusic = 0.55f, vSfx = 0.9f, vVoice = 0.8f;
    public boolean vibrate = true, shake = true, floatStick = false, noFlash = false, dmgNums = true;
    public int quality = 2;   // 0 performance, 1 low, 2 medium, 3 high
    public float density = 1f, hudOpacity = 0.85f;
    public final float[] hud = new float[Defs.H_N * 4];

    public Profile() {
        for (int i = 0; i < Defs.K_N; i++) { karma[i] = 0.15f; prevKarma[i] = 0.15f; }
        resetHud();
    }

    public void resetHud() {
        float[] d = {
                0.20f, 0.855f, 1f, 1f,
                0.83f, 0.865f, 1f, 1f,
                0.60f, 0.905f, 1f, 1f,
                0.645f, 0.795f, 1f, 1f,
                0.77f, 0.735f, 1f, 1f,
                0.80f, 0.60f, 1f, 1f};
        System.arraycopy(d, 0, hud, 0, d.length);
    }

    // ---- training level ----
    public static double xpForLevel(int level) { return level <= 1 ? 0 : 45.0 * Math.pow(level - 1, 1.75); }

    public int level() {
        int l = (int) Math.pow(Math.max(0, xp) / 45.0, 1.0 / 1.75) + 1;
        return Mx.clampi(l, 1, 99);
    }

    public float levelProgress() {
        int l = level();
        if (l >= 99) return 1f;
        double a = xpForLevel(l), b = xpForLevel(l + 1);
        return (float) Mx.clamp((float) ((xp - a) / (b - a)), 0f, 1f);
    }

    // ---- memories (0..127) ----
    public boolean hasMem(int id) { return id < 64 ? (memLo & (1L << id)) != 0 : (memHi & (1L << (id - 64))) != 0; }
    public void setMem(int id) { if (id < 64) memLo |= 1L << id; else memHi |= 1L << (id - 64); }
    public int memCount() { return Long.bitCount(memLo) + Long.bitCount(memHi); }

    public boolean flag(long f) { return (flags & f) != 0; }
    public boolean hint(long f) { return (hints & f) != 0; }

    // ---- persistence ----
    public void write(Store s) {
        s.putI("v", VERSION);
        s.putD("bank", bank); s.putD("life", lifetime); s.putD("tld", timelineData); s.putD("xp", xp);
        s.putIa("up", up); s.putI("wide", wide); s.putI("wideU", wideUnlock); s.putI("arch", archetype); s.putIa("slots", slots);
        s.putFa("karma", karma); s.putFa("pkarma", prevKarma); s.putI("pideo", prevIdeology);
        s.putF("trust", trust); s.putF("bond", bond); s.putF("indep", indep); s.putIa("itier", ideoTier);
        s.putI("tl", timeline); s.putI("cycle", cycle); s.putF("para", paradox); s.putI("echo", echoes);
        s.putB("bdone", bossDone); s.putI("bmask", bossMask); s.putI("sacr", sacrifices);
        s.putL("memLo", memLo); s.putL("memHi", memHi); s.putL("flags", flags); s.putL("hints", hints);
        s.putI("endings", endings); s.putI("unk", unknownFound); s.putI("evs", eventsSeen);
        s.putI("runs", runs); s.putI("deaths", deaths); s.putI("extracts", extracts); s.putI("kills", kills);
        s.putI("bkills", bossKills); s.putI("sess", sessions); s.putI("depth", maxDepth);
        s.putL("seen", lastSeen); s.putL("play", playMs); s.putD("dpm", dpm); s.putD("xpm", xpm);
        s.putF("vM", vMaster); s.putF("vMu", vMusic); s.putF("vS", vSfx); s.putF("vV", vVoice);
        s.putB("vib", vibrate); s.putB("shake", shake); s.putB("fstick", floatStick); s.putB("noflash", noFlash); s.putB("dnum", dmgNums);
        s.putI("qual", quality); s.putF("dens", density); s.putF("hudop", hudOpacity); s.putFa("hud", hud);
    }

    public void read(Store s) {
        bank = s.getD("bank", 0); lifetime = s.getD("life", 0); timelineData = s.getD("tld", 0); xp = s.getD("xp", 0);
        s.getIa("up", up); wide = s.getI("wide", 0); wideUnlock = s.getI("wideU", 0); archetype = s.getI("arch", 0); s.getIa("slots", slots);
        s.getFa("karma", karma); s.getFa("pkarma", prevKarma); prevIdeology = s.getI("pideo", -1);
        trust = s.getF("trust", trust); bond = s.getF("bond", bond); indep = s.getF("indep", indep); s.getIa("itier", ideoTier);
        timeline = s.getI("tl", 0); cycle = s.getI("cycle", 0); paradox = s.getF("para", 0); echoes = s.getI("echo", 0);
        bossDone = s.getB("bdone", false); bossMask = s.getI("bmask", 0); sacrifices = s.getI("sacr", 0);
        memLo = s.getL("memLo", 0); memHi = s.getL("memHi", 0); flags = s.getL("flags", 0); hints = s.getL("hints", 0);
        endings = s.getI("endings", 0); unknownFound = s.getI("unk", 0); eventsSeen = s.getI("evs", 0);
        runs = s.getI("runs", 0); deaths = s.getI("deaths", 0); extracts = s.getI("extracts", 0); kills = s.getI("kills", 0);
        bossKills = s.getI("bkills", 0); sessions = s.getI("sess", 0); maxDepth = s.getI("depth", 0);
        lastSeen = s.getL("seen", 0); playMs = s.getL("play", 0); dpm = s.getD("dpm", 0); xpm = s.getD("xpm", 0);
        vMaster = s.getF("vM", vMaster); vMusic = s.getF("vMu", vMusic); vSfx = s.getF("vS", vSfx); vVoice = s.getF("vV", vVoice);
        vibrate = s.getB("vib", true); shake = s.getB("shake", true); floatStick = s.getB("fstick", false);
        noFlash = s.getB("noflash", false); dmgNums = s.getB("dnum", true);
        quality = s.getI("qual", 2); density = s.getF("dens", 1f); hudOpacity = s.getF("hudop", 0.85f); s.getFa("hud", hud);
        sanitize();
    }

    /** Clamp everything so a hand-edited or damaged save can never break the game. */
    public void sanitize() {
        if (bank < 0 || bank != bank) bank = 0;
        if (xp < 0 || xp != xp) xp = 0;
        if (lifetime < 0) lifetime = 0;
        if (timelineData < 0) timelineData = 0;
        for (int i = 0; i < up.length; i++) up[i] = Mx.clampi(up[i], 0, 500);
        wide = Mx.clampi(wide, 0, 2);
        archetype = Mx.clampi(archetype, 0, Defs.ARCH_N - 1);
        for (int i = 0; i < slots.length; i++) slots[i] = Mx.clampi(slots[i], -1, Defs.AB_N - 1);
        for (int i = 0; i < Defs.K_N; i++) { karma[i] = Mx.clamp(karma[i], 0f, 1f); prevKarma[i] = Mx.clamp(prevKarma[i], 0f, 1f); }
        trust = Mx.clamp(trust, 0f, 1f); bond = Mx.clamp(bond, 0f, 1f); indep = Mx.clamp(indep, 0f, 1f);
        for (int i = 0; i < 4; i++) ideoTier[i] = Mx.clampi(ideoTier[i], 0, 5);
        timeline = Mx.clampi(timeline, 0, Defs.TL_N - 1);
        paradox = Mx.clamp(paradox, 0f, 100f);
        echoes = Mx.clampi(echoes, 0, 100000);
        vMaster = Mx.clamp(vMaster, 0f, 1f); vMusic = Mx.clamp(vMusic, 0f, 1f); vSfx = Mx.clamp(vSfx, 0f, 1f); vVoice = Mx.clamp(vVoice, 0f, 1f);
        quality = Mx.clampi(quality, 0, 3);
        density = Mx.clamp(density, 0.2f, 1f);
        hudOpacity = Mx.clamp(hudOpacity, 0.2f, 1f);
        for (int i = 0; i < Defs.H_N; i++) {
            hud[i * 4] = Mx.clamp(hud[i * 4], 0.04f, 0.96f);
            hud[i * 4 + 1] = Mx.clamp(hud[i * 4 + 1], 0.06f, 0.97f);
            hud[i * 4 + 2] = Mx.clamp(hud[i * 4 + 2], 0.6f, 1.7f);
            hud[i * 4 + 3] = Mx.clamp(hud[i * 4 + 3], 0.2f, 1f);
        }
    }
}
