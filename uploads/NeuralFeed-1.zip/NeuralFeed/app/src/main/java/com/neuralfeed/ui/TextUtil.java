package com.neuralfeed.ui;

import android.graphics.Typeface;

import com.neuralfeed.render.Gfx;

import java.util.ArrayList;

/** Word wrapping for static text. Allocates, so cache the result. */
final class TextUtil {
    private TextUtil() {}

    static String[] wrap(Gfx g, String s, float maxW, float sp, Typeface tf) {
        ArrayList<String> out = new ArrayList<String>();
        String[] words = s.split(" ");
        StringBuilder line = new StringBuilder();
        for (int i = 0; i < words.length; i++) {
            String trial = line.length() == 0 ? words[i] : line + " " + words[i];
            if (g.measure(trial, sp, tf) > maxW && line.length() > 0) {
                out.add(line.toString());
                line.setLength(0);
                line.append(words[i]);
            } else {
                line.setLength(0);
                line.append(trial);
            }
        }
        if (line.length() > 0) out.add(line.toString());
        return out.toArray(new String[0]);
    }
}
