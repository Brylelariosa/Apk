package com.neuralfeed.ui;

import android.graphics.Canvas;
import android.graphics.Paint;

import com.neuralfeed.audio.Sfx;
import com.neuralfeed.core.Fmt;
import com.neuralfeed.data.Profile;
import com.neuralfeed.meta.Upgrades;
import com.neuralfeed.render.Gfx;
import com.neuralfeed.render.Theme;
import com.neuralfeed.render.Ui;

/** Permanent upgrades bought with Data. */
final class CoreTab extends Tab {
    private int mode;   // 0 x1, 1 x10, 2 max

    CoreTab(App app, HubScreen hub) { super(app, hub); }

    private int want() { return mode == 0 ? 1 : (mode == 1 ? 10 : 999); }

    @Override void draw(Canvas c, float x, float y, float w, float h, float scroll) {
        Gfx g = app.gfx;
        Ui ui = app.ui;
        Theme th = app.wr.th;
        Profile pf = app.pf;
        float dp = g.dp, yy = y - scroll + 4f * dp;
        String[] ml = {"x1", "x10", "MAX"};
        float bw = 56f * dp;
        for (int i = 0; i < 3; i++) {
            float bx = x + w - (3 - i) * (bw + 6f * dp) + 6f * dp;
            if (vis(yy, 34f * dp, y, h)) ui.button(c, 201 + i, ml[i], bx, yy, bw, 32f * dp, true, mode == i ? Ui.ST_PRIMARY : Ui.ST_NORMAL, th.accent, th.text, th.bg);
        }
        g.text(c, "Upgrades", x, yy + 21f * dp, 15f, th.text, Paint.Align.LEFT, g.condB);
        yy += 46f * dp;
        int lvl = pf.level();
        for (Upgrades.Up u : Upgrades.ALL) {
            float rh = 74f * dp;
            int lv = pf.up[u.id];
            boolean locked = lvl < u.req;
            if (yy + rh > y - 10f && yy < y + h + 10f) {
                g.text(c, u.name, x, yy + 18f * dp, 15.5f, locked ? Gfx.alpha(th.text, 110) : th.text, Paint.Align.LEFT, g.condB);
                g.text(c, "LV " + lv + "/" + u.max, x + g.measure(u.name, 15.5f, g.condB) + 10f * dp, yy + 18f * dp, 11.5f, Gfx.alpha(th.accent, 220), Paint.Align.LEFT, g.cond);
                g.text(c, u.desc, x, yy + 38f * dp, 12.5f, Gfx.alpha(th.text, 150), Paint.Align.LEFT, g.cond);
                float prog = lv / (float) u.max;
                g.rectFill(c, x, yy + 50f * dp, w - 112f * dp, 2f * dp, Gfx.alpha(th.text, 28));
                g.rectFill(c, x, yy + 50f * dp, (w - 112f * dp) * prog, 2f * dp, Gfx.alpha(th.accent, 200));
                float bx = x + w - 100f * dp;
                if (locked) {
                    ui.button(c, 210 + u.id, "AI LV " + u.req, bx, yy + 8f * dp, 100f * dp, 46f * dp, false, Ui.ST_NORMAL, th.accent, th.text, th.bg);
                } else if (lv >= u.max) {
                    ui.button(c, 210 + u.id, "MAX", bx, yy + 8f * dp, 100f * dp, 46f * dp, false, Ui.ST_NORMAL, th.accent, th.text, th.bg);
                } else if (vis(yy, rh, y, h)) {
                    int n = Upgrades.affordable(u, lv, pf.bank, want());
                    boolean can = n > 0;
                    String lab = can ? (n > 1 ? "+" + n + "  " : "") + Fmt.num(Upgrades.costMany(u, lv, n)) : Fmt.num(u.cost(lv));
                    ui.button(c, 210 + u.id, lab, bx, yy + 8f * dp, 100f * dp, 46f * dp, can, can ? Ui.ST_PRIMARY : Ui.ST_NORMAL, th.accent, th.text, th.bg);
                }
                g.rectFill(c, x, yy + rh - 4f * dp, w, dp, Gfx.alpha(th.text, 18));
            }
            yy += rh;
        }
        // process modes
        yy += 8f * dp;
        g.text(c, "Process modes", x, yy + 12f * dp, 15f, th.text, Paint.Align.LEFT, g.condB);
        yy += 28f * dp;
        double cost = Upgrades.modeCost(pf.timeline);
        for (int k = 1; k <= 2; k++) {
            boolean un = (pf.wideUnlock & k) != 0;
            String nm = k == 1 ? "Wide process" : "Condensed process";
            String ds = k == 1 ? "Larger field, lower processing power." : "Smaller field, much higher power.";
            g.text(c, nm, x, yy + 18f * dp, 15.5f, th.text, Paint.Align.LEFT, g.condB);
            g.text(c, ds, x, yy + 38f * dp, 12.5f, Gfx.alpha(th.text, 150), Paint.Align.LEFT, g.cond);
            String lab = un ? (pf.wide == k ? "ACTIVE" : "ACTIVATE") : Fmt.num(cost);
            boolean en = un || pf.bank >= cost;
            if (vis(yy, 60f * dp, y, h)) ui.button(c, 239 + k, lab, x + w - 100f * dp, yy + 8f * dp, 100f * dp, 46f * dp, en, (un && pf.wide == k) ? Ui.ST_PRIMARY : Ui.ST_NORMAL, th.accent, th.text, th.bg);
            yy += 68f * dp;
        }
        yy += 20f * dp;
        contentH = yy + scroll - y;
    }

    @Override void click(int id) {
        Profile pf = app.pf;
        if (id >= 201 && id <= 203) { mode = id - 201; app.tap(); return; }
        if (id == 240 || id == 241) {
            int k = id - 239;
            if ((pf.wideUnlock & k) != 0) { pf.wide = pf.wide == k ? 0 : k; app.audio.sfx(Sfx.UI_BUY, 0.8f); }
            else {
                double cost = Upgrades.modeCost(pf.timeline);
                if (pf.bank >= cost) { pf.bank -= cost; pf.wideUnlock |= k; pf.wide = k; app.audio.sfx(Sfx.UI_BUY, 1f); }
                else app.audio.sfx(Sfx.UI_DENY, 0.8f);
            }
            app.saveNow();
            return;
        }
        int uid = id - 210;
        if (uid < 0 || uid >= Upgrades.ALL.length) return;
        Upgrades.Up u = Upgrades.ALL[uid];
        int n = Upgrades.affordable(u, pf.up[uid], pf.bank, want());
        if (n <= 0) { app.audio.sfx(Sfx.UI_DENY, 0.8f); return; }
        pf.bank -= Upgrades.costMany(u, pf.up[uid], n);
        pf.up[uid] += n;
        app.audio.sfx(Sfx.UI_BUY, 1f);
        app.saveNow();
    }
}
