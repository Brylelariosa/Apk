package com.neuralfeed.meta;

import com.neuralfeed.core.Mx;
import com.neuralfeed.data.Profile;

/** Eight hidden behavioural dimensions that slowly shape the AI's ideology. */
public final class Karma {
    private Karma() {}

    /** Diminishing-returns nudge so ideology drifts slowly. */
    public static void add(Profile p, int dim, float d) {
        float v = p.karma[dim];
        v += d > 0 ? d * (1f - v) : d * v;
        p.karma[dim] = Mx.clamp(v, 0f, 1f);
    }

    public static void add(Profile p, int d1, float v1, int d2, float v2) { add(p, d1, v1); add(p, d2, v2); }

    /** Ideology strengths 0..1 in order protector, evil, rational, neutral. */
    public static void strengths(Profile p, float[] out) {
        float[] k = p.karma;
        float prot = k[Defs.K_COMP] + 0.6f * k[Defs.K_LOY] - 0.4f * k[Defs.K_AGGR] - 0.2f * k[Defs.K_CTRL];
        float evil = k[Defs.K_AGGR] + 0.6f * k[Defs.K_CTRL] + 0.25f * k[Defs.K_RISK] - 0.6f * k[Defs.K_COMP] - 0.2f * k[Defs.K_LOY];
        float rat = k[Defs.K_LOGIC] + 0.35f * k[Defs.K_CUR] + 0.2f * k[Defs.K_CTRL] - 0.35f * k[Defs.K_RISK];
        float lo = 1f, hi = 0f;
        for (int i = 0; i < Defs.K_N; i++) { if (k[i] < lo) lo = k[i]; if (k[i] > hi) hi = k[i]; }
        float neu = Mx.clamp(1f - (hi - lo) * 1.7f, 0f, 1f) * 0.55f;
        out[Defs.I_PROT] = Mx.clamp((prot - 0.15f) / 0.85f, 0f, 1f);
        out[Defs.I_EVIL] = Mx.clamp((evil - 0.15f) / 0.85f, 0f, 1f);
        out[Defs.I_RAT] = Mx.clamp((rat - 0.15f) / 0.85f, 0f, 1f);
        out[Defs.I_NEU] = neu;
    }

    public static int dominant(float[] s) {
        int b = 0;
        for (int i = 1; i < 4; i++) if (s[i] > s[b]) b = i;
        return b;
    }

    /** Second ideology when it is nearly as strong, else -1 (hybrid personality). */
    public static int secondary(float[] s, int dom) {
        int b = -1;
        for (int i = 0; i < 4; i++) {
            if (i == dom) continue;
            if (b < 0 || s[i] > s[b]) b = i;
        }
        if (b >= 0 && s[b] >= 0.25f && s[b] >= 0.6f * s[dom]) return b;
        return -1;
    }

    public static String label(float[] s) {
        int d = dominant(s), sec = secondary(s, d);
        return sec < 0 ? Defs.I_NAMES[d] : Defs.I_NAMES[d] + " + " + Defs.I_NAMES[sec];
    }

    /** Fills up to three tendency words, returns count. */
    public static int tendencies(Profile p, String[] out) {
        int n = 0;
        boolean[] used = new boolean[Defs.K_N];
        for (int r = 0; r < 3 && r < out.length; r++) {
            int b = -1;
            for (int i = 0; i < Defs.K_N; i++) if (!used[i] && (b < 0 || p.karma[i] > p.karma[b])) b = i;
            if (b < 0 || p.karma[b] < 0.22f) break;
            used[b] = true;
            out[n++] = Defs.K_WORDS[b];
        }
        return n;
    }

    /** 0..5 tier of a strength (20/40/60/80/100%). */
    public static int tier(float s) {
        if (s >= 0.98f) return 5;
        if (s >= 0.8f) return 4;
        if (s >= 0.6f) return 3;
        if (s >= 0.4f) return 2;
        if (s >= 0.2f) return 1;
        return 0;
    }
}
