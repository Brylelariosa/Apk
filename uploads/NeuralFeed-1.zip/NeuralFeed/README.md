# NEURAL//FEED

Offline action-incremental Android game. You move an AI core with one joystick; its Processing Field
automatically damages everything inside it. Collect Data, grow, discover what the Data really is,
and travel back through time.

## Controls
- Left joystick: move (drag in the lower-left; "Floating joystick" in System settings lets you start anywhere on the left).
- Dash: bottom-right big button. Abilities: the smaller buttons (equip them on the RUN tab).
- Pause (top-right): resume, Customize HUD (move/resize/opacity/reset), volume, leave run.

## Project layout (`app/src/main/java/com/neuralfeed`)
- `core`    math, RNG, spatial grid, number formatting
- `data`    profile, versioned/checksummed key-value saves (atomic write + backup), export/import
- `meta`    upgrades, stats, karma/ideology, story text, events, timelines, prestige, endings
- `game`    world simulation (pooled enemies/orbs/bullets/particles), AI, bosses, abilities, arenas
- `render`  Canvas renderer (batched primitives), AI core art, HUD, immediate-mode UI
- `audio`   procedural SFX/voice/music synthesised at start-up, real-time mixer (AudioTrack)
- `ui`      App root, screens (title, hub tabs, gameplay + overlays, HUD editor, cinematics)

No native code, no third-party libraries, no assets besides the launcher icon. Build with Gradle 8.6, JDK 17, AGP 8.4.2.
