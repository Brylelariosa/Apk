package com.menushell.billiards

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import androidx.core.content.ContextCompat
import com.menushell.R
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Draws a pool table — wooden rail, felt, cushions, rail diamonds, and
 * pockets — fit to whatever size this View is given.
 *
 * [tableGeometry] is the exact same model a future ball would collide
 * against; this View only turns it into pixels; it doesn't own any
 * gameplay state itself. No ball or cue yet.
 */
class BilliardsTableView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    /** Recomputed whenever this View is resized; read by whatever eventually simulates a ball. */
    var tableGeometry: TableGeometry? = null
        private set

    private val feltPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val railPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(context, R.color.billiards_rail)
    }
    private val railHighlightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(context, R.color.billiards_rail_light)
        style = Paint.Style.STROKE
    }
    private val diamondPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(context, R.color.accent_amber)
    }
    private val feltLightColor = ContextCompat.getColor(context, R.color.billiards_felt)
    private val feltDarkColor = ContextCompat.getColor(context, R.color.billiards_felt_dark)
    private val pocketRimColor = ContextCompat.getColor(context, R.color.billiards_rail_light)
    private val pocketCoreColor = ContextCompat.getColor(context, R.color.black)
    private val cushionOuterColor = ContextCompat.getColor(context, R.color.billiards_cushion_light)
    private val cushionInnerColor = ContextCompat.getColor(context, R.color.billiards_cushion_dark)

    private val railPath = Path()
    private val feltBounds = RectF()
    private var pocketPaints: List<Paint> = emptyList()
    private var pocketMouthPaths: List<Path> = emptyList()
    private var cushionPaths: List<Path> = emptyList()
    private var cushionPaints: List<Paint> = emptyList()
    private var diamondPoints: List<PointF> = emptyList()
    private var diamondRadius = 0f

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w > 0 && h > 0) layoutTable(w.toFloat(), h.toFloat())
    }

    /**
     * Fits a 2:1 table inside the View, centered, and derives every paint
     * that depends on that layout (gradients, stroke widths) once here —
     * not in [onDraw], which can run every frame once something animates.
     */
    private fun layoutTable(viewWidth: Float, viewHeight: Float) {
        val margin = min(viewWidth, viewHeight) * MARGIN_FRACTION
        val availableW = viewWidth - margin * 2f
        val availableH = viewHeight - margin * 2f

        var tableW = availableW
        var tableH = tableW / TABLE_ASPECT
        if (tableH > availableH) {
            tableH = availableH
            tableW = tableH * TABLE_ASPECT
        }

        val railLeft = (viewWidth - tableW) / 2f
        val railTop = (viewHeight - tableH) / 2f
        val railRect = RectF(railLeft, railTop, railLeft + tableW, railTop + tableH)

        val railThickness = tableH * RAIL_THICKNESS_FRACTION
        feltBounds.set(
            railRect.left + railThickness,
            railRect.top + railThickness,
            railRect.right - railThickness,
            railRect.bottom - railThickness
        )

        val feltHalfW = feltBounds.width() / 2f
        val feltHalfH = feltBounds.height() / 2f
        feltPaint.shader = RadialGradient(
            feltBounds.centerX(), feltBounds.centerY(),
            sqrt(feltHalfW * feltHalfW + feltHalfH * feltHalfH),
            feltLightColor, feltDarkColor, Shader.TileMode.CLAMP
        )

        val geometry = TableGeometry(
            left = feltBounds.left,
            top = feltBounds.top,
            right = feltBounds.right,
            bottom = feltBounds.bottom,
            cornerPocketRadius = feltBounds.height() * CORNER_POCKET_FRACTION,
            sidePocketRadius = feltBounds.height() * SIDE_POCKET_FRACTION
        )
        tableGeometry = geometry

        val railCorner = railThickness * 0.4f
        railPath.reset()
        railPath.addRoundRect(railRect, railCorner, railCorner, Path.Direction.CW)
        railHighlightPaint.strokeWidth = railThickness * 0.06f

        val feltCenter = Vec2(feltBounds.centerX(), feltBounds.centerY())

        // The cushion is a band running inward from the rail seam, tapering
        // to an exact point at each pocket (the classic "jaw"). It's given
        // its own gradient — bright at the seam, fading toward the felt's
        // own dark tone — rather than a flat fill, so it always reads as a
        // distinct raised strip no matter how light or dark the felt's own
        // gradient happens to be at that point along the rail.
        val cushionDepth = railThickness * CUSHION_DEPTH_FRACTION
        val cushionTaper = railThickness * CUSHION_TAPER_FRACTION
        cushionPaths = geometry.cushions.map { cushion ->
            pathFromPoints(cushionBand(cushion, cushionDepth, cushionTaper, feltCenter))
        }
        cushionPaints = geometry.cushions.map { cushion ->
            val normal = inwardNormal(cushion, feltCenter)
            val outer = cushion.start
            val inner = outer + normal * cushionDepth
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = LinearGradient(
                    outer.x, outer.y, inner.x, inner.y,
                    cushionOuterColor, cushionInnerColor, Shader.TileMode.CLAMP
                )
            }
        }

        // Each pocket's gradient depends on its own position/radius, so
        // these are rebuilt here on resize rather than allocated in onDraw.
        // Mostly-black throat with a warm rim band is what reads as a real
        // opening — the earlier version used two near-black tones and the
        // gradient was invisible.
        pocketPaints = geometry.pockets.map { pocket ->
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = RadialGradient(
                    pocket.center.x, pocket.center.y, pocket.radius,
                    intArrayOf(pocketCoreColor, pocketCoreColor, pocketRimColor),
                    floatArrayOf(0f, 0.72f, 1f),
                    Shader.TileMode.CLAMP
                )
            }
        }

        // A real pocket is a mouth flaring away from the table between two
        // cushion jaws, not a circle laid on top of the felt — see
        // pocketMouth(). Tables built with an unusual layout (not exactly
        // two jaws per pocket) fall back to the plain circle instead of
        // guessing at a shape.
        pocketMouthPaths = geometry.pockets.map { pocket ->
            val mouth = pocketMouth(pocket, geometry.cushions, feltCenter, MOUTH_CONTROL_FRACTION)
            Path().apply {
                if (mouth != null) {
                    moveTo(mouth.jawA.x, mouth.jawA.y)
                    cubicTo(
                        mouth.controlA.x, mouth.controlA.y,
                        mouth.controlB.x, mouth.controlB.y,
                        mouth.jawB.x, mouth.jawB.y
                    )
                    close()
                } else {
                    addCircle(pocket.center.x, pocket.center.y, pocket.radius, Path.Direction.CW)
                }
            }
        }

        diamondRadius = railThickness * 0.09f
        diamondPoints = geometry.cushions.map { cushion -> diamondFor(cushion, railThickness) }
    }

    private fun pathFromPoints(points: List<Vec2>): Path = Path().apply {
        moveTo(points.first().x, points.first().y)
        points.drop(1).forEach { lineTo(it.x, it.y) }
        close()
    }

    /** A sight-mark position on the wood rail, just outside the cushion's midpoint. */
    private fun diamondFor(cushion: Cushion, railThickness: Float): PointF {
        val mid = (cushion.start + cushion.end) * 0.5f
        val outward = when {
            abs(mid.y - feltBounds.top) < 1f -> Vec2(0f, -1f)
            abs(mid.y - feltBounds.bottom) < 1f -> Vec2(0f, 1f)
            mid.x - feltBounds.left < feltBounds.width() / 2f -> Vec2(-1f, 0f)
            else -> Vec2(1f, 0f)
        }
        val diamond = mid + outward * (railThickness * 0.5f)
        return PointF(diamond.x, diamond.y)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        tableGeometry ?: return

        canvas.drawPath(railPath, railPaint)
        canvas.drawPath(railPath, railHighlightPaint)
        canvas.drawRoundRect(
            feltBounds, feltBounds.height() * 0.02f, feltBounds.height() * 0.02f, feltPaint
        )

        diamondPoints.forEach { p -> canvas.drawCircle(p.x, p.y, diamondRadius, diamondPaint) }

        cushionPaths.forEachIndexed { index, path -> canvas.drawPath(path, cushionPaints[index]) }

        pocketMouthPaths.forEachIndexed { index, path -> canvas.drawPath(path, pocketPaints[index]) }
    }

    companion object {
        private const val TABLE_ASPECT = 2f // standard pool table length:width
        private const val MARGIN_FRACTION = 0.05f
        private const val RAIL_THICKNESS_FRACTION = 0.09f
        private const val CORNER_POCKET_FRACTION = 0.058f
        private const val SIDE_POCKET_FRACTION = 0.05f
        private const val CUSHION_DEPTH_FRACTION = 0.40f
        private const val CUSHION_TAPER_FRACTION = 0.30f
        private const val MOUTH_CONTROL_FRACTION = 1.05f
    }
}
