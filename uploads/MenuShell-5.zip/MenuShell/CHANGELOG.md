# Changelog

## Pass 6 — cushion visibility/straightness + real pocket mouths
- Cushions were filled with `billiards_felt_dark` — the same color the
  felt's own radial gradient fades to — so wherever the two happened to
  match, the cushion effectively disappeared into the felt, and the
  varying contrast along its length read as a wavy edge instead of a
  straight one
- Cushions now get their own per-cushion `LinearGradient` (bright at the
  rail seam, fading toward the felt's dark tone), built the same way
  `pocketPaints` already were — visible against the felt regardless of
  what the felt's own gradient is doing at that point along the rail
- The cushion band now sits entirely on the felt side of the rail seam
  (previously it straddled the seam symmetrically). While fixing this,
  found and fixed a real bug: `Cushion.normal`'s sign is arbitrary (only
  guaranteed consistent for reflection, not for "which way is inward"), and
  3 of the 6 cushions had it pointing outward into the rail — invisible
  only because that half's inner color happened to be close to the felt's.
  New `inwardNormal()` resolves the sign explicitly against the felt center
  instead of trusting it
- Pockets were `canvas.drawCircle()` — a perfect circle straddling the rail
  seam. Real pockets are a flared mouth between two jaws, not a circle
  sitting on top of the felt; new `pocketMouth()` builds that shape from
  the two cushion endpoints already touching each pocket (found by
  proximity, not index, so it isn't tied to the standard 6-pocket layout)
  and a bezier flare away from the table. `BilliardsTableView` turns this
  into a `moveTo`/`cubicTo` path; falls back to the old circle if a pocket
  doesn't have exactly two jaws
- New file `TableVisualShapes.kt`: `inwardNormal`, `cushionBand`,
  `jawsForPocket`, `pocketMouth` — kept framework-agnostic like
  `Cushion`/`Pocket`/`TableGeometry`, since these are derived shapes for
  drawing, not new collision behavior. `Pocket.captures()` still uses the
  plain circle for the capture check — only the visual shape changed
- New colors `billiards_cushion_light`/`billiards_cushion_dark`, replacing
  reliance on the felt colors for the cushion fill

## Pass 5 — pocket jaws instead of round-capped cushions
- Cushions were drawn as thick lines with round end caps; the round cap
  sat right at the pocket boundary and visually bulged into the pocket
  circle instead of meeting it cleanly
- Cushions are now tapered hexagons (`BilliardsTableView.cushionNosePath`)
  that narrow to an exact point at each pocket — the taper reads as the
  standard pocket "jaw"/"fang" shape, and since the point lands exactly on
  the pocket's radius, it can't overlap the pocket the way the round cap
  did. Same treatment at all 6 pockets, corners included
- `TableGeometry`/`Cushion` (the collision model) are unchanged — this was
  a rendering-only fix, which is the point of keeping physics and drawing
  separate

## Pass 4 — pocket size + table polish fix
- Pockets were sized way off a real table: corner/side radius fractions
  were roughly double what they should be (~23%/19% of table width in
  diameter, vs. a regulation table's ~11.5%/10% for 5"/4.5" pocket mouths
  on a 44" bed) — halved both
- Pocket gradient's rim tone was a near-black gray barely distinguishable
  from the black core, so the "hole" read as a flat disc; swapped it for
  the rail's lighter brown and pushed the gradient into the outer ~28% of
  the radius so the rim actually shows
- Felt is now a soft radial gradient (lighter center, darker edge) instead
  of a flat fill
- Dropped the now-unused `billiards_pocket_rim` color — the pocket rim
  reuses `billiards_rail_light` instead

## Pass 3 — billiards table screen
- `Play` now opens a new `GameActivity` instead of showing a placeholder
  Toast; `Settings` is unchanged for now
- Added a `billiards` package: `TableGeometry` builds the standard 6-pocket
  layout (4 corner + 2 side, sized off the felt rect) with 6 cushion
  segments that stop short of each pocket mouth. `Cushion.reflect()` and
  `Pocket.captures()` are real collision/sink checks — just not called by
  anything yet, since there's no ball or cue in this pass
- `BilliardsTableView` draws the table (wood rail, felt, cushions, rail
  diamonds, pockets) fit to a 2:1 aspect ratio, centered, at whatever size
  it's given; gradients and stroke widths are rebuilt only on size change,
  not per frame
- Menu: title and Play/Settings are now horizontally centered instead of
  pinned to a left-side guideline

## Pass 2 — release build fix + APK size pass
- Fixed release build failure: `activity_main.xml` declared the `app`
  namespace as `res/app` instead of `res-auto`, so aapt2 couldn't
  resolve any `app:layout_constraint*`/MaterialButton attribute and
  failed resource linking for every one of them
- Release build now runs R8 (`isMinifyEnabled = true`, full mode by
  default under AGP 8.4.2) with `isShrinkResources = true`; no new
  keep rules needed — nothing reflection-based in the dependency graph
- Release build now restricts bundled locales to English
  (`resConfigs("en")`), dropping the other-language string tables
  AppCompat/Material ship for their own widgets — language resources
  only, no ABI split

## Pass 1 — initial menu shell
- Landscape/reverse-landscape only (`sensorLandscape`), no portrait
- Immersive fullscreen, system bars hidden, cutout excluded from layout
  (`LAYOUT_IN_DISPLAY_CUTOUT_MODE_NEVER`) so nothing sits behind the camera
- Black background throughout, matching the cutout exclusion so the
  excluded area reads as an intentional margin, not a gap
- `ImmersiveActivity` base class holding the window/orientation setup,
  so future screens reuse it instead of duplicating window flags
- Main menu: title + Play/Settings, both currently placeholder actions
