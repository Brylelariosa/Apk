package com.mgba.android

import android.content.Context
import android.graphics.Color
import android.text.InputType
import android.util.Log
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import org.json.JSONArray
import org.json.JSONObject

// ─────────────────────────────────────────────────────────────────────────
// FEATURE — direct report: "in layout setting delete all on there and make
// it that you can make layout like plus button and it go to button
// customization edit and save name the layout and save you can add more or
// edit existing layout you save." Named, savable/loadable layout PRESETS —
// a new concept, separate from (and built on top of) the single active
// per-orientation layout customLayout/removedButtons/addedExtraButtons
// already persist via PREF_LAYOUT_PREFIX/PREF_REMOVED_PREFIX/
// PREF_EXTRAS_PREFIX (see loadCustomLayout()/saveCustomLayout(),
// MainActivityControlLayout.kt). That single active layout is unchanged
// and still exactly what's actually drawn/hit-tested at any moment — a
// preset is a named, storable SNAPSHOT of it, either captured from what's
// currently active (captureCurrentAsPreset()) or loaded back into it
// (applyLayoutPreset()).
//
// The control layout editor's own top-of-file comment (see
// MainActivityControlEditorGeometry.kt) previously flagged "named/
// duplicatable layout profiles" as deliberately out of scope pending a
// ROM-identity concept this codebase doesn't have. That comment was about
// *per-game* layouts auto-selected by which ROM is loaded — a different
// (and still out-of-scope) feature from this one: these presets are
// manually named/saved/applied by the person, nothing to do with which
// game happens to be running.
//
// Stored as a single JSON-array blob under PREF_LAYOUT_PRESETS — the same
// "one key, one blob" shape the active layout's own 3 prefixed keys use,
// just wrapped into a list with a name and orientation tag per entry.
// ─────────────────────────────────────────────────────────────────────────

internal const val PREF_LAYOUT_PRESETS = "layout_presets"

internal data class LayoutPreset(
    val name: String,
    val orientation: String,
    val layoutJson: String,
    val removedJson: String,
    val extrasJson: String
)

internal fun MainActivity.loadLayoutPresets(): MutableList<LayoutPreset> {
    val raw = getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(PREF_LAYOUT_PRESETS, null)
        ?: return mutableListOf()
    val out = mutableListOf<LayoutPreset>()
    try {
        val arr = JSONArray(raw)
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out += LayoutPreset(
                name = o.getString("name"),
                orientation = o.optString("orientation", "land"),
                layoutJson = o.optString("layout", "[]"),
                removedJson = o.optString("removed", "[]"),
                extrasJson = o.optString("extras", "[]")
            )
        }
    } catch (e: Exception) {
        Log.e(TAG, "Corrupt layout presets, ignoring", e)
    }
    return out
}

internal fun MainActivity.saveLayoutPresets(presets: List<LayoutPreset>) {
    try {
        val arr = JSONArray()
        for (p in presets) {
            arr.put(JSONObject().apply {
                put("name", p.name)
                put("orientation", p.orientation)
                put("layout", JSONArray(p.layoutJson))
                put("removed", JSONArray(p.removedJson))
                put("extras", JSONArray(p.extrasJson))
            })
        }
        // commit(), not apply(): same "must survive an abrupt process
        // kill right after Save" reasoning as saveCustomLayout()'s own
        // fix (mid-pass-44 report: layout reset if the app was swiped
        // away shortly after saving) — see that function's comment.
        val committed = getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(PREF_LAYOUT_PRESETS, arr.toString())
            .commit()
        if (!committed) Log.w(TAG, "saveLayoutPresets(): SharedPreferences.commit() reported failure")
    } catch (e: Exception) {
        Log.e(TAG, "Failed to save layout presets", e)
        uiToast("Couldn't save layout")
    }
}

/** Snapshots the CURRENT live layout (customLayout/removedButtons/
 *  addedExtraButtons — whatever's actually on screen right now) under
 *  [name], replacing any existing preset with that same name. */
internal fun MainActivity.captureCurrentAsPreset(name: String) {
    val layoutArr = JSONArray()
    for ((id, e) in customLayout) {
        layoutArr.put(JSONObject().apply {
            put("id", id)
            put("x", e.xFrac.toDouble()); put("y", e.yFrac.toDouble())
            put("scale", e.scale.toDouble()); put("alpha", e.alphaOverride); put("locked", e.locked)
        })
    }
    val removedArr = JSONArray().apply { removedButtons.forEach { put(it) } }
    val extrasArr = JSONArray().apply { addedExtraButtons.forEach { put(it) } }
    val preset = LayoutPreset(name, orientationTag(), layoutArr.toString(), removedArr.toString(), extrasArr.toString())
    val presets = loadLayoutPresets()
    val idx = presets.indexOfFirst { it.name == name }
    if (idx >= 0) presets[idx] = preset else presets += preset
    saveLayoutPresets(presets)
}

/** Loads [preset] into the live layout and makes it the active layout. */
internal fun MainActivity.applyLayoutPreset(preset: LayoutPreset) {
    if (preset.orientation == orientationTag()) {
        val newLayout = mutableMapOf<String, LayoutEntry>()
        val newRemoved = mutableSetOf<String>()
        val newExtras = mutableSetOf<String>()
        try {
            val arr = JSONArray(preset.layoutJson)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                newLayout[o.getString("id")] = LayoutEntry(
                    xFrac = o.getDouble("x").toFloat(), yFrac = o.getDouble("y").toFloat(),
                    scale = o.optDouble("scale", 1.0).toFloat(),
                    alphaOverride = o.optInt("alpha", -1), locked = o.optBoolean("locked", false)
                )
            }
            val removedArr = JSONArray(preset.removedJson)
            for (i in 0 until removedArr.length()) newRemoved.add(removedArr.getString(i))
            val extrasArr = JSONArray(preset.extrasJson)
            for (i in 0 until extrasArr.length()) newExtras.add(extrasArr.getString(i))
        } catch (e: Exception) {
            // Parsed into local collections first, above, specifically so
            // a corrupt preset is caught here and bails BEFORE touching
            // the live layout at all — a half-applied layout would be
            // worse than just refusing this one and leaving the current
            // layout exactly as it was.
            Log.e(TAG, "Corrupt layout preset '${preset.name}', ignoring", e)
            uiToast("Couldn't apply \"${preset.name}\" — saved data looks corrupt")
            return
        }
        customLayout.clear(); customLayout.putAll(newLayout)
        removedButtons.clear(); removedButtons.addAll(newRemoved)
        addedExtraButtons.clear(); addedExtraButtons.addAll(newExtras)
        saveCustomLayout()
        buildControlLayout(lastSw, lastSh)
        uiToast("\"${preset.name}\" applied")
    } else {
        // Reachable: this app has a real Portrait option (Video
        // settings) now, not just landscape (see LayoutEntry's own doc
        // comment, MainActivityShared.kt, for that history), so a
        // preset saved in one orientation and applied while the other
        // is current is a real case. Writes the preset straight into
        // ITS OWN orientation's stored slot, ready and waiting the
        // moment that orientation is actually loaded, without touching
        // the currently-active orientation's in-memory layout at all.
        getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(PREF_LAYOUT_PREFIX + preset.orientation, preset.layoutJson)
            .putString(PREF_REMOVED_PREFIX + preset.orientation, preset.removedJson)
            .putString(PREF_EXTRAS_PREFIX + preset.orientation, preset.extrasJson)
            .apply()
        uiToast("\"${preset.name}\" saved for ${preset.orientation} — switch orientation to see it")
    }
}

internal fun MainActivity.deleteLayoutPreset(name: String) {
    val presets = loadLayoutPresets()
    if (presets.removeAll { it.name == name }) saveLayoutPresets(presets)
}

// ── Editor entry points ─────────────────────────────────────────────────
// Both funnel into the SAME control layout editor "Edit Button Layout…"
// already uses (enterEditMode()) — editingPresetName is what tells
// exitEditMode() (MainActivityControlEditorMode.kt) this particular
// session should also save/update a named preset, not just the active
// layout. See that field's own comment (MainActivity.kt).

internal fun MainActivity.startNewLayoutPreset() {
    editingPresetName = ""
    enterEditMode()
}

internal fun MainActivity.editExistingLayoutPreset(preset: LayoutPreset) {
    if (preset.orientation != orientationTag()) {
        uiToast("Rotate to ${preset.orientation} to edit \"${preset.name}\"")
        return
    }
    applyLayoutPreset(preset)
    editingPresetName = preset.name
    enterEditMode()
}

/** Shown right after Done on a "+ New layout" edit session — see
 *  exitEditMode()'s pendingPresetName == "" case. */
internal fun MainActivity.promptNewLayoutPresetName() {
    val ctx = this
    val input = EditText(ctx).apply {
        hint = "Layout name"
        setTextColor(Color.WHITE)
        setHintTextColor(Color.parseColor("#888892"))
        inputType = InputType.TYPE_CLASS_TEXT
        setPadding(dp(20), dp(12), dp(20), dp(12))
    }
    AlertDialog.Builder(ctx)
        .setTitle("Save layout as…")
        .setView(input)
        .setPositiveButton("Save") { _, _ ->
            val name = input.text.toString().trim()
            if (name.isEmpty()) { uiToast("Not saved — no name entered"); return@setPositiveButton }
            captureCurrentAsPreset(name)
            uiToast("\"$name\" saved")
        }
        .setNegativeButton("Discard", null)
        .show()
}

/** One row in the Layouts list — name (tap to apply), ✎ (tap to edit),
 *  a trash icon (tap to delete). A "dumb" row: showLayoutsSettings()
 *  wires what each tap actually does, so this stays reusable/testable on
 *  its own — see that function for why deletion re-opens the whole
 *  dialog rather than removing the row in place. */
internal fun MainActivity.layoutPresetRow(
    name: String, onApply: () -> Unit, onEdit: () -> Unit, onDelete: () -> Unit
): View {
    val ctx = this
    return LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(4), dp(2), dp(16), dp(2))
        addView(TextView(ctx).apply {
            text = name; textSize = 15f; setTextColor(Color.WHITE)
            setPadding(dp(16), dp(14), dp(8), dp(14))
            isClickable = true; isFocusable = true
            setBackgroundResource(rippleBackgroundResId())
            setOnClickListener { onApply() }
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        addView(TextView(ctx).apply {
            text = "✎"; textSize = 15f; setTextColor(colorAccentLight)
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(8), dp(14), dp(8))
            isClickable = true; isFocusable = true
            background = iconChipBackground()
            setOnClickListener { onEdit() }
        }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { marginStart = dp(8) })
        addView(FrameLayout(ctx).apply {
            // FIX (direct report: "on setting there a lot of emoji stuff
            // remove those add real button like vector") — this row's own
            // delete action carried a 🗑 emoji; see SettingsIcons.kt.
            addView(SettingsIconView(ctx, SettingsGlyph.TRASH, tint = Color.parseColor("#FF6B6B")),
                FrameLayout.LayoutParams(dp(18), dp(18), Gravity.CENTER))
            isClickable = true; isFocusable = true
            setPadding(dp(14), dp(8), dp(14), dp(8))
            background = iconChipBackground()
            setOnClickListener { onDelete() }
        }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { marginStart = dp(8) })
    }
}
