package com.mgba.android

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View

// ─────────────────────────────────────────────────────────────────────────
// FIX — direct report: "on setting there a lot of emoji stuff remove those
// add real button like vector." Every settings-menu row icon (and a
// couple of standalone row glyphs elsewhere — Layouts' delete row,
// Storage's folder-picker button) used a plain emoji character, which
// renders as a full-color pictograph pulled from the system's own emoji
// font — completely different visual language from the rest of this
// app's controls, which are all hand-drawn stroke-only vector shapes (see
// MainActivityControlLayout.kt's drawOutlineButton()/drawActionButtonIcon()
// for the controller overlay's own version of the same idea). This file
// is that same approach adapted for ordinary Android Views (Settings is
// built from LinearLayout/TextView/AlertDialog, not the game's own
// per-frame Canvas), so a Settings row's icon and a controller button's
// icon are drawn by the same hand, just through two different entry
// points (one a live game Canvas, one a small View's onDraw).
//
// Dialog *titles* (showAudioSettings() etc.) and a few purely-decorative
// inline glyphs (the ↺ reset/undo arrows) are deliberately left alone:
// those are Unicode symbols with a plain, monochrome default rendering
// already, not the colorful emoji-block pictographs this fix targets —
// see this app's other ⚙/✕ glyphs, already exactly the "real button, not
// emoji" look this report is asking for. Only the actual emoji go away;
// a matching vector glyph replaces each one that anchored an interactive
// row (a settings-menu entry, a delete/choose-folder action).
// ─────────────────────────────────────────────────────────────────────────

internal enum class SettingsGlyph {
    VIDEO, AUDIO, GAMEPAD, LAYOUTS, MISC, STORAGE, WIFI, BLUETOOTH, ADVANCED, DEBUG, INFO,
    TRASH, PLAY, PAUSE, SHUFFLE, NEXT, STOP
}

/** A single small vector glyph, drawn fresh in onDraw() rather than
 *  loaded from a drawable resource — this app has no drawable icon
 *  resources at all (see MainActivityControlLayout.kt's own equivalent),
 *  everything is hand-drawn shapes, so a Settings icon follows the same
 *  convention instead of introducing a second, bitmap/XML-drawable-based
 *  icon system alongside it. Square by construction: draws into
 *  whatever box the caller's LayoutParams give it, centered, with a
 *  fixed proportion of padding — callers just need to size the View,
 *  never the glyph coordinates themselves. */
internal class SettingsIconView(
    context: Context,
    glyph: SettingsGlyph,
    tint: Int = colorAccentLight
) : View(context) {

    private var glyph: SettingsGlyph = glyph

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = context.dp(2).toFloat().coerceAtLeast(2f)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = tint
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = tint }
    private val scratchRect = RectF()
    private val scratchPath = Path()

    /** Swaps the tint at runtime — used for the music-control row (play/
     *  pause and shuffle need to reflect live playback state) rather than
     *  rebuilding the View. */
    fun setTint(color: Int) {
        paint.color = color
        fillPaint.color = color
        invalidate()
    }

    /** Swaps the glyph itself at runtime — the music row's Play/Pause
     *  button is one View whose shape flips with playback state, rather
     *  than two Views swapped in and out. */
    fun setGlyph(newGlyph: SettingsGlyph) {
        glyph = newGlyph
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val s = minOf(width, height) / 2f * 0.72f
        if (s <= 0f) return
        when (glyph) {
            SettingsGlyph.VIDEO -> {
                canvas.drawRoundRect(cx - s, cy - s * 0.85f, cx + s, cy + s * 0.30f, s * 0.16f, s * 0.16f, paint)
                canvas.drawLine(cx, cy + s * 0.30f, cx, cy + s * 0.65f, paint)
                canvas.drawLine(cx - s * 0.45f, cy + s * 0.85f, cx + s * 0.45f, cy + s * 0.85f, paint)
            }
            SettingsGlyph.AUDIO -> {
                canvas.drawRect(cx - s, cy - s * 0.3f, cx - s * 0.4f, cy + s * 0.3f, paint)
                scratchPath.reset()
                scratchPath.moveTo(cx - s * 0.4f, cy - s * 0.3f)
                scratchPath.lineTo(cx + s * 0.15f, cy - s * 0.75f)
                scratchPath.lineTo(cx + s * 0.15f, cy + s * 0.75f)
                scratchPath.lineTo(cx - s * 0.4f, cy + s * 0.3f)
                scratchPath.close()
                canvas.drawPath(scratchPath, paint)
                scratchRect.set(cx + s * 0.05f - s * 0.35f, cy - s * 0.35f, cx + s * 0.05f + s * 0.35f, cy + s * 0.35f)
                canvas.drawArc(scratchRect, -40f, 80f, false, paint)
                scratchRect.set(cx + s * 0.05f - s * 0.62f, cy - s * 0.62f, cx + s * 0.05f + s * 0.62f, cy + s * 0.62f)
                canvas.drawArc(scratchRect, -35f, 70f, false, paint)
            }
            SettingsGlyph.GAMEPAD -> {
                canvas.drawRoundRect(cx - s, cy - s * 0.55f, cx + s, cy + s * 0.35f, s * 0.35f, s * 0.35f, paint)
                canvas.drawLine(cx - s * 0.62f, cy - s * 0.28f, cx - s * 0.62f, cy + s * 0.08f, paint)
                canvas.drawLine(cx - s * 0.80f, cy - s * 0.10f, cx - s * 0.44f, cy - s * 0.10f, paint)
                canvas.drawCircle(cx + s * 0.45f, cy - s * 0.22f, s * 0.10f, paint)
                canvas.drawCircle(cx + s * 0.68f, cy + s * 0.02f, s * 0.10f, paint)
            }
            SettingsGlyph.LAYOUTS -> {
                canvas.drawRoundRect(cx - s, cy - s, cx + s, cy + s, s * 0.16f, s * 0.16f, paint)
                canvas.drawLine(cx, cy - s, cx, cy + s, paint)
                canvas.drawLine(cx - s, cy, cx + s, cy, paint)
            }
            SettingsGlyph.MISC -> {
                val ys = floatArrayOf(-s * 0.55f, 0f, s * 0.55f)
                val handleX = floatArrayOf(-s * 0.25f, s * 0.30f, -s * 0.05f)
                for (i in 0..2) {
                    canvas.drawLine(cx - s, cy + ys[i], cx + s, cy + ys[i], paint)
                    canvas.drawCircle(cx + handleX[i], cy + ys[i], s * 0.16f, fillPaint)
                }
            }
            SettingsGlyph.STORAGE -> drawFloppyDiskIcon(canvas, paint, cx, cy, s)
            SettingsGlyph.WIFI -> {
                canvas.drawCircle(cx, cy + s * 0.68f, s * 0.10f, fillPaint)
                for (i in 1..3) {
                    val r = s * 0.32f * i
                    scratchRect.set(cx - r, cy + s * 0.68f - r, cx + r, cy + s * 0.68f + r)
                    canvas.drawArc(scratchRect, 215f, 110f, false, paint)
                }
            }
            SettingsGlyph.BLUETOOTH -> {
                canvas.drawLine(cx, cy - s, cx, cy + s, paint)
                scratchPath.reset()
                scratchPath.moveTo(cx, cy - s)
                scratchPath.lineTo(cx + s * 0.55f, cy - s * 0.42f)
                scratchPath.lineTo(cx - s * 0.55f, cy + s * 0.42f)
                scratchPath.lineTo(cx, cy + s)
                canvas.drawPath(scratchPath, paint)
                scratchPath.reset()
                scratchPath.moveTo(cx, cy - s)
                scratchPath.lineTo(cx - s * 0.55f, cy - s * 0.42f)
                scratchPath.lineTo(cx + s * 0.55f, cy + s * 0.42f)
                scratchPath.lineTo(cx, cy + s)
                canvas.drawPath(scratchPath, paint)
            }
            SettingsGlyph.ADVANCED -> {
                canvas.drawLine(cx - s, cy - s * 0.4f, cx + s, cy - s * 0.4f, paint)
                canvas.drawLine(cx - s * 0.35f, cy - s * 0.75f, cx - s * 0.35f, cy - s * 0.05f, paint)
                canvas.drawLine(cx - s, cy + s * 0.4f, cx + s, cy + s * 0.4f, paint)
                canvas.drawLine(cx + s * 0.20f, cy + s * 0.05f, cx + s * 0.20f, cy + s * 0.75f, paint)
            }
            SettingsGlyph.DEBUG -> {
                canvas.drawCircle(cx - s * 0.12f, cy - s * 0.12f, s * 0.55f, paint)
                canvas.drawLine(cx + s * 0.28f, cy + s * 0.28f, cx + s * 0.85f, cy + s * 0.85f, paint)
            }
            SettingsGlyph.INFO -> {
                canvas.drawCircle(cx, cy, s, paint)
                canvas.drawCircle(cx, cy - s * 0.42f, s * 0.09f, fillPaint)
                canvas.drawLine(cx, cy - s * 0.05f, cx, cy + s * 0.48f, paint)
            }
            SettingsGlyph.TRASH -> {
                canvas.drawLine(cx - s * 0.5f, cy - s * 0.75f, cx + s * 0.5f, cy - s * 0.75f, paint)
                canvas.drawLine(cx - s * 0.2f, cy - s * 0.9f, cx + s * 0.2f, cy - s * 0.9f, paint)
                canvas.drawRoundRect(cx - s * 0.65f, cy - s * 0.6f, cx + s * 0.65f, cy + s, s * 0.08f, s * 0.08f, paint)
                canvas.drawLine(cx - s * 0.25f, cy - s * 0.3f, cx - s * 0.25f, cy + s * 0.65f, paint)
                canvas.drawLine(cx + s * 0.25f, cy - s * 0.3f, cx + s * 0.25f, cy + s * 0.65f, paint)
            }
            SettingsGlyph.PLAY -> {
                scratchPath.reset()
                scratchPath.moveTo(cx - s * 0.55f, cy - s * 0.8f)
                scratchPath.lineTo(cx + s * 0.85f, cy)
                scratchPath.lineTo(cx - s * 0.55f, cy + s * 0.8f)
                scratchPath.close()
                canvas.drawPath(scratchPath, fillPaint)
            }
            SettingsGlyph.PAUSE -> {
                canvas.drawRoundRect(cx - s * 0.75f, cy - s * 0.8f, cx - s * 0.2f, cy + s * 0.8f, s * 0.12f, s * 0.12f, fillPaint)
                canvas.drawRoundRect(cx + s * 0.2f, cy - s * 0.8f, cx + s * 0.75f, cy + s * 0.8f, s * 0.12f, s * 0.12f, fillPaint)
            }
            SettingsGlyph.STOP -> canvas.drawRoundRect(cx - s * 0.72f, cy - s * 0.72f, cx + s * 0.72f, cy + s * 0.72f, s * 0.14f, s * 0.14f, fillPaint)
            SettingsGlyph.NEXT -> {
                scratchPath.reset()
                scratchPath.moveTo(cx - s * 0.75f, cy - s * 0.8f)
                scratchPath.lineTo(cx + s * 0.15f, cy)
                scratchPath.lineTo(cx - s * 0.75f, cy + s * 0.8f)
                scratchPath.close()
                canvas.drawPath(scratchPath, fillPaint)
                canvas.drawRoundRect(cx + s * 0.35f, cy - s * 0.8f, cx + s * 0.62f, cy + s * 0.8f, s * 0.08f, s * 0.08f, fillPaint)
            }
            SettingsGlyph.SHUFFLE -> {
                scratchPath.reset()
                scratchPath.moveTo(cx - s, cy - s * 0.55f)
                scratchPath.lineTo(cx + s * 0.35f, cy - s * 0.55f)
                scratchPath.lineTo(cx + s * 0.85f, cy + s * 0.55f)
                canvas.drawPath(scratchPath, paint)
                scratchPath.reset()
                scratchPath.moveTo(cx - s, cy + s * 0.55f)
                scratchPath.lineTo(cx - s * 0.35f, cy + s * 0.55f)
                scratchPath.lineTo(cx + s * 0.85f, cy - s * 0.55f)
                canvas.drawPath(scratchPath, paint)
                val headSize = s * 0.22f
                canvas.drawLine(cx + s * 0.85f, cy + s * 0.55f, cx + s * 0.85f - headSize, cy + s * 0.55f - headSize * 0.4f, paint)
                canvas.drawLine(cx + s * 0.85f, cy + s * 0.55f, cx + s * 0.85f - headSize * 0.4f, cy + s * 0.55f - headSize, paint)
                canvas.drawLine(cx + s * 0.85f, cy - s * 0.55f, cx + s * 0.85f - headSize, cy - s * 0.55f + headSize * 0.4f, paint)
                canvas.drawLine(cx + s * 0.85f, cy - s * 0.55f, cx + s * 0.85f - headSize * 0.4f, cy - s * 0.55f + headSize, paint)
            }
        }
    }
}
