package com.mgba.android

import android.graphics.Canvas
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.util.Log
import android.view.Surface
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Encodes the emulator's own framebuffer + game audio into an MP4,
 *  entirely independent of the phone's actual on-screen display. FEATURE
 *  — direct report: "add features screen recorder on it but only the
 *  game screen will record and sound no button."
 *
 *  Drawing the SAME bitmap captureGameFrameBitmap() already hands out for
 *  screenshots/save-state thumbnails (MainActivitySaveStateUi.kt) — which
 *  is already the pre-controls game frame, not a screen grab of the
 *  whole display — is what guarantees the on-screen buttons can never
 *  appear in the recording: they're simply never drawn to this class's
 *  own encoder input Surface in the first place, not filtered out after
 *  the fact. No MediaProjection/screen-capture permission needed at all,
 *  for the same reason — this never touches the device's actual display
 *  output.
 *
 *  Video: MediaCodec H.264 in Surface-input mode — the encoder handles
 *  the RGB->YUV conversion internally via its own EGL pipeline, which
 *  sidesteps the real device-to-device fragmentation a hand-rolled
 *  ByteBuffer approach would run into (which raw YUV byte layout — planar
 *  vs semi-planar, and which one a given encoder actually wants — varies
 *  per device/vendor). Fed by drawing to the input Surface's own
 *  *hardware* canvas (lockHardwareCanvas/unlockCanvasAndPost — see
 *  captureAndDrawFrame()'s own comment for why it has to be that one
 *  specifically) from a dedicated capture thread this class owns — see
 *  startCaptureLoop(). 20fps/720x480 rather than
 *  something higher: this is a 2D handheld-console capture, not
 *  fast-paced 3D/FPS footage, and every captured frame is a fresh ~1.4MB
 *  ARGB_8888 Bitmap (captureGameFrameBitmap() itself, unmodified, doing
 *  what it already does for screenshots/thumbnails) — keeping the rate
 *  modest keeps that allocation churn reasonable over a longer clip.
 *  720x480 specifically because it's exactly 3x the GBA's native
 *  240x160, so it's undistorted at the source aspect ratio with no
 *  letterboxing math needed, and divisible by 16 (encoder-friendly).
 *
 *  Audio: MediaCodec AAC in the standard ByteBuffer-input mode, fed PCM
 *  directly from MainActivityAudio.kt's writePcm() (see feedAudio()) —
 *  the exact same samples a listener actually hears, not a separate or
 *  duplicated read of anything.
 *
 *  Both encoders' output gets muxed into one MP4 via MediaMuxer, written
 *  to a temp file under cacheDir rather than directly into the chosen
 *  Storage folder — MediaMuxer's own String-path constructor (guaranteed
 *  available at any API level this app supports, unlike its
 *  FileDescriptor overload) needs a plain java.io.File path, not a SAF
 *  DocumentFile/content:// Uri directly. See
 *  MainActivityRecorder.kt's finishRecordingAndSave() for the copy-out
 *  step afterward — same "stage locally, then copy to the real
 *  destination" shape SaveEntry.stageForWrite()/commitWrite() already
 *  established for save-states.
 *
 *  Everything encoder/muxer-related is behind [lock]: video frames arrive
 *  from this class's own capture thread, audio arrives from the
 *  emulator's own game thread (MainActivityRender.kt's gameThread), and
 *  start()/stop() get called from the main thread by a button tap —
 *  three different threads that all need to agree on encoder/muxer state
 *  without corrupting it. */
internal class GameScreenRecorder(private val activity: MainActivity) {

    companion object {
        private const val VIDEO_WIDTH = 720
        private const val VIDEO_HEIGHT = 480
        private const val VIDEO_BITRATE = 4_000_000
        private const val VIDEO_FPS = 20
        private const val AUDIO_SAMPLE_RATE = 44100
        private const val AUDIO_CHANNELS = 2
        private const val AUDIO_BITRATE = 128_000
    }

    @Volatile var isRecording = false
        private set

    private val lock = Object()
    private var videoCodec: MediaCodec? = null
    private var audioCodec: MediaCodec? = null
    private var inputSurface: Surface? = null
    private var muxer: MediaMuxer? = null
    private var videoTrackIndex = -1
    private var audioTrackIndex = -1
    private var muxerStarted = false
    private val videoBufferInfo = MediaCodec.BufferInfo()
    private val audioBufferInfo = MediaCodec.BufferInfo()
    private var audioPresentationTimeUs = 0L
    // Reused across every feedAudio() call rather than allocated fresh
    // each time — this runs on the game thread at up to ~60Hz while
    // recording, so a per-call allocation here would be real GC
    // pressure on exactly the thread that can least afford a pause.
    // 4096 shorts is comfortably above audioBuffer's own fixed 2048-short
    // size (MainActivityAudio.kt) — writePcm() always hands this at most
    // that many, whatever accumulated it upstream during fast-forward.
    private val audioScratch = ByteBuffer.allocate(4096 * 2).order(ByteOrder.LITTLE_ENDIAN)

    private var captureThread: Thread? = null
    @Volatile private var captureRunning = false
    private var tempFile: File? = null

    /** Starts a new recording into a temp file under cacheDir. Returns
     *  the temp file on success, null on any setup failure (codec
     *  unavailable, etc.) — the caller (MainActivityRecorder.kt) toasts
     *  accordingly; this class doesn't know about UI. */
    fun start(): File? = synchronized(lock) {
        if (isRecording) return@synchronized null
        try {
            val file = File(activity.cacheDir, "recording_${System.currentTimeMillis()}.mp4")

            val videoFormat = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, VIDEO_WIDTH, VIDEO_HEIGHT).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, VIDEO_BITRATE)
                setInteger(MediaFormat.KEY_FRAME_RATE, VIDEO_FPS)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
            }
            val vCodec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            vCodec.configure(videoFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            val surface = vCodec.createInputSurface()
            vCodec.start()

            val audioFormat = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, AUDIO_SAMPLE_RATE, AUDIO_CHANNELS).apply {
                setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_BIT_RATE, AUDIO_BITRATE)
            }
            val aCodec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            aCodec.configure(audioFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            aCodec.start()

            val mux = MediaMuxer(file.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

            videoCodec = vCodec; audioCodec = aCodec; inputSurface = surface; muxer = mux
            videoTrackIndex = -1; audioTrackIndex = -1; muxerStarted = false
            tempFile = file
            audioPresentationTimeUs = 0L
            isRecording = true
            startCaptureLoop()
            file
        } catch (e: Exception) {
            Log.e(TAG, "GameScreenRecorder.start() failed", e)
            teardownLocked()
            null
        }
    }

    /** Stops capture, signals end-of-stream to the video encoder, drains
     *  whatever's left from both, finalizes the muxer, and releases
     *  everything. Deliberately synchronous — MainActivityRecorder.kt's
     *  caller already runs this off the main thread. Returns the temp
     *  file (now a finished, valid MP4) for the caller to copy out to
     *  its real destination, or null if nothing was recording. */
    fun stop(): File? = synchronized(lock) {
        if (!isRecording) return@synchronized null
        isRecording = false
        stopCaptureLoopLocked()
        try {
            videoCodec?.signalEndOfInputStream()
            drainVideoLocked(endOfStream = true)
            drainAudioLocked(endOfStream = true)
        } catch (e: Exception) {
            Log.e(TAG, "GameScreenRecorder.stop() drain failed", e)
        }
        val result = tempFile
        teardownLocked()
        result
    }

    /** Called from the emulator's own game thread (see writePcm()'s own
     *  hook, MainActivityAudio.kt) — deliberately non-blocking: this
     *  runs on the same thread that drives actual emulation timing, so
     *  stalling here to wait for an encoder input buffer would mean
     *  stalling gameplay for an optional recording feature. Drops
     *  (doesn't retry/queue) a chunk if the encoder has no input buffer
     *  ready right this instant — audio encoders are fast enough in
     *  practice that this should be rare, and an occasional dropped
     *  ~20ms chunk is inaudible next to actually-stalled gameplay.
     *  [pcm]/[pairs] are exactly writePcm()'s own already-processed
     *  buffer/count — same audio a listener actually hears. */
    fun feedAudio(pcm: ShortArray, pairs: Int) {
        if (pairs <= 0) return
        synchronized(lock) {
            if (!isRecording) return
            val codec = audioCodec ?: return
            try {
                val inIndex = codec.dequeueInputBuffer(0)
                if (inIndex < 0) return // no buffer ready right now — drop this chunk, see doc above
                val buf = codec.getInputBuffer(inIndex) ?: return
                buf.clear()
                val maxShorts = minOf(pairs * 2, buf.remaining() / 2, audioScratch.capacity() / 2)
                if (maxShorts <= 0) return
                audioScratch.clear()
                for (i in 0 until maxShorts) audioScratch.putShort(pcm[i])
                audioScratch.flip()
                buf.put(audioScratch)
                val byteCount = maxShorts * 2
                codec.queueInputBuffer(inIndex, 0, byteCount, audioPresentationTimeUs, 0)
                // maxShorts/2 == stereo sample pairs actually queued.
                audioPresentationTimeUs += (maxShorts / 2).toLong() * 1_000_000L / AUDIO_SAMPLE_RATE
                drainAudioLocked(endOfStream = false)
            } catch (e: Exception) {
                Log.w(TAG, "GameScreenRecorder.feedAudio()", e)
            }
        }
    }

    /** Called from this class's own capture thread only (startCaptureLoop). */
    private fun captureAndDrawFrame() {
        val bmp = activity.captureGameFrameBitmap(VIDEO_WIDTH, VIDEO_HEIGHT) ?: return
        // Snapshot the Surface reference under the lock, then draw
        // OUTSIDE it — lockCanvas/drawBitmap/unlockCanvasAndPost can
        // take a few ms, and holding `lock` for that whole span would
        // block feedAudio() (game thread) and stop() (main thread)
        // pointlessly. If stop() races in and releases the real Surface
        // in between, the calls below throw on this now-stale local
        // reference — caught below, that frame is simply skipped, which
        // is exactly the right outcome for a recording that's ending
        // anyway.
        val surface = synchronized(lock) { inputSurface } ?: return
        val canvas: Canvas
        try {
            // FIX (direct report: "screen record is bad it record sound
            // but not frame it show only 1 frame"): this used to be
            // surface.lockCanvas(null) — the plain *software* canvas.
            // MediaCodec's own createInputSurface() docs are explicit
            // that the surface it hands back "must be rendered with a
            // hardware-accelerated API, such as OpenGL ES" and that
            // lockCanvas() specifically "may fail or produce unexpected
            // results" on it. In practice that "unexpected result" was
            // exactly the reported symptom: the very first
            // lockCanvas()/unlockCanvasAndPost() got a real frame to the
            // encoder (which is why one frame did show up), but the
            // software-canvas path this surface was never meant to
            // support left the encoder's input queue unable to make
            // proper forward progress after that, so every later capture
            // never advanced the video beyond that first frame — while
            // audio, on its own completely separate ByteBuffer-input
            // codec, kept encoding normally the whole time. Audio never
            // touched this surface at all, which is why the recorded
            // sound was fine. lockHardwareCanvas() is the same drawBitmap
            // call site, but backed by the GPU-rendered canvas this
            // Surface actually expects — same method signature, same
            // unlockCanvasAndPost() below, only the acquisition changes.
            canvas = surface.lockHardwareCanvas()
        } catch (e: Exception) {
            return
        }
        try {
            canvas.drawBitmap(bmp, 0f, 0f, null)
        } finally {
            try { surface.unlockCanvasAndPost(canvas) } catch (e: Exception) { Log.w(TAG, "GameScreenRecorder: unlockCanvasAndPost", e) }
        }
        synchronized(lock) { if (isRecording) drainVideoLocked(endOfStream = false) }
    }

    private fun startCaptureLoop() {
        captureRunning = true
        captureThread = Thread {
            val frameIntervalMs = 1000L / VIDEO_FPS
            while (captureRunning) {
                val frameStart = System.currentTimeMillis()
                try {
                    captureAndDrawFrame()
                } catch (e: Exception) {
                    Log.w(TAG, "GameScreenRecorder capture loop", e)
                }
                val sleepMs = frameIntervalMs - (System.currentTimeMillis() - frameStart)
                if (sleepMs > 0) {
                    try { Thread.sleep(sleepMs) } catch (e: InterruptedException) { return@Thread }
                }
            }
        }.apply { name = "mGBA-screen-recorder"; start() }
    }

    /** Must be called with [lock] held (called only from stop() above). */
    private fun stopCaptureLoopLocked() {
        captureRunning = false
        // Deliberately NOT captureThread?.join() here: this runs inside
        // the very `lock` captureAndDrawFrame()'s own drain call
        // (synchronized(lock) { ... }, above) needs to finish its
        // current iteration — joining would wait for that thread while
        // holding the lock it needs to exit, an easy self-deadlock.
        // captureRunning = false is enough on its own: the loop checks
        // it every iteration and exits within one frame interval
        // regardless, and whatever's already mid-flight when
        // isRecording flips false just no-ops via captureAndDrawFrame()'s
        // own `if (isRecording)` guard around its drain call.
        captureThread = null
    }

    /** Must be called with [lock] held. Releases every resource
     *  regardless of how far start() got before failing, so a partial
     *  setup failure never leaks a codec/muxer. */
    private fun teardownLocked() {
        try { videoCodec?.stop() } catch (e: Exception) {}
        try { videoCodec?.release() } catch (e: Exception) {}
        try { audioCodec?.stop() } catch (e: Exception) {}
        try { audioCodec?.release() } catch (e: Exception) {}
        try { inputSurface?.release() } catch (e: Exception) {}
        try { if (muxerStarted) muxer?.stop() } catch (e: Exception) { Log.w(TAG, "MediaMuxer.stop()", e) }
        try { muxer?.release() } catch (e: Exception) {}
        videoCodec = null; audioCodec = null; inputSurface = null; muxer = null
        videoTrackIndex = -1; audioTrackIndex = -1; muxerStarted = false
        tempFile = null
    }

    /** Must be called with [lock] held. */
    private fun drainVideoLocked(endOfStream: Boolean) {
        val codec = videoCodec ?: return
        val timeoutUs = if (endOfStream) 10_000L else 0L
        while (true) {
            val outIndex = try {
                codec.dequeueOutputBuffer(videoBufferInfo, timeoutUs)
            } catch (e: Exception) { Log.w(TAG, "drainVideoLocked", e); return }
            when {
                outIndex == MediaCodec.INFO_TRY_AGAIN_LATER -> return
                outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    if (videoTrackIndex >= 0) continue
                    videoTrackIndex = muxer?.addTrack(codec.outputFormat) ?: return
                    maybeStartMuxerLocked()
                }
                outIndex >= 0 -> {
                    val buf = codec.getOutputBuffer(outIndex)
                    if (buf != null && videoBufferInfo.size > 0 && muxerStarted) {
                        muxer?.writeSampleData(videoTrackIndex, buf, videoBufferInfo)
                    }
                    codec.releaseOutputBuffer(outIndex, false)
                    if (videoBufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
                }
                else -> return
            }
        }
    }

    /** Must be called with [lock] held. */
    private fun drainAudioLocked(endOfStream: Boolean) {
        val codec = audioCodec ?: return
        val timeoutUs = if (endOfStream) 10_000L else 0L
        while (true) {
            val outIndex = try {
                codec.dequeueOutputBuffer(audioBufferInfo, timeoutUs)
            } catch (e: Exception) { Log.w(TAG, "drainAudioLocked", e); return }
            when {
                outIndex == MediaCodec.INFO_TRY_AGAIN_LATER -> return
                outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    if (audioTrackIndex >= 0) continue
                    audioTrackIndex = muxer?.addTrack(codec.outputFormat) ?: return
                    maybeStartMuxerLocked()
                }
                outIndex >= 0 -> {
                    val buf = codec.getOutputBuffer(outIndex)
                    if (buf != null && audioBufferInfo.size > 0 && muxerStarted) {
                        muxer?.writeSampleData(audioTrackIndex, buf, audioBufferInfo)
                    }
                    codec.releaseOutputBuffer(outIndex, false)
                    if (audioBufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
                }
                else -> return
            }
        }
    }

    /** Must be called with [lock] held. MediaMuxer requires BOTH tracks
     *  added before start() — whichever encoder reports its output
     *  format second (video and audio each do, exactly once, before
     *  producing any actual encoded data) is what actually triggers
     *  this to fire. */
    private fun maybeStartMuxerLocked() {
        if (muxerStarted) return
        if (videoTrackIndex >= 0 && audioTrackIndex >= 0) {
            try {
                muxer?.start()
                muxerStarted = true
            } catch (e: Exception) {
                Log.e(TAG, "MediaMuxer.start() failed", e)
            }
        }
    }
}
