## v27 → v28

### 🐛 Fix: Downloads still used system DownloadManager

**File:** `app/src/main/java/com/browser/app/MainActivity.kt`

**Problem:** `setDownloadListener` was enqueuing to Android's `DownloadManager`, which pops the system download notification and routes files through the OS Downloads app — bypassing the in-app download tracker entirely.

**Fix:** Replaced with a fully in-app downloader using `HttpURLConnection` on a background `Thread`.
- File is saved to `getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)` (no `WRITE_EXTERNAL_STORAGE` permission needed on API 29+).
- Progress feedback: Toast on start, Toast on completion/failure.
- Status is stored as a `status` field (`"downloading"` / `"complete"` / `"failed"`) in the `downloads_v1` JSON pref entry, alongside a new `path` field (absolute path to the saved file).
- `saveDownloadEntry(id, fn, url, path, status)` updated with the two new params.
- New `updateDownloadStatus(id, status)` patches the entry once the thread finishes.
- `showDownloadsDialog()` now reads `status` and `path` from the JSON directly instead of querying `DownloadManager`. The `DownloadManager` import and `dm` variable are fully removed.
- Completed files are opened via `FileProvider` (`$packageName.fileprovider`) so `ACTION_VIEW` works on Android 7+.

**New files:**
- `app/src/main/res/xml/file_paths.xml` — FileProvider paths config (`external-files-path/Download/`).
- `<provider>` block added to `AndroidManifest.xml`.

> **Note:** Old `downloads_v1` entries from v27 (which stored a `DownloadManager` numeric ID) will show as `✓ Complete` in the dialog — the `else` branch. Their files won't be openable since no `path` is stored. This is expected; they'll disappear after "Clear Downloads List".

---

### 🐛 Fix: Ad popups still opened as real tabs

**File:** `app/src/main/java/com/browser/app/MainActivity.kt`

**Problem:** `onCreateWindow` blocked non-gesture popups when ad-block was on, but `isUserGesture = true` popups (ads that hijack a user click to call `window.open()`) still opened as real tabs unchecked.

**Fix:** `onCreateWindow` now routes all new-window requests through a **staging `WebView`** instead of creating a real tab immediately. The staging WebView intercepts the first URL navigation via `shouldOverrideUrlLoading`:
- If `AdBlocker.shouldBlockNavigation(host)` returns true → drop it, show `🛡 Blocked popup` Toast.
- Otherwise → create a real tab, switch to it, and load the URL normally.

The staging WebView is never added to the layout; it exists only to capture the first URL the JS engine navigates it to. Ad tabs that somehow show blank content (no URL navigation) are silently ignored.

---

### ✨ Larger tab thumbnails

**File:** `app/src/main/java/com/browser/app/MainActivity.kt`

Increased tab card thumbnail height from **88 dp → 140 dp**. The extra height gives a much more useful page preview in the tab switcher without affecting the capture scale (still 40%, `RGB_565`).

---

## v27 — Remove double-tap indicator, tap-to-hide URL bar, tab persistence, download manager

### 🐛 Remove: Double-tap zone indicator strip

The thin 3dp hint strip (`bottomTapHint`) shown at the screen edge in Hidden URL Bar Mode (mode 2) has been removed. The `updateDoubleTapHint` function now always sets the view to `GONE`. The view remains in the layout but is never shown.

### ✨ Tap page to hide URL bar (mode 2)

In Hidden URL Bar Mode, once the URL bar is visible a **single tap anywhere on the page** now hides it. Implemented by adding `onSingleTapConfirmed` to the `GestureDetector` in `buildGestureDetector()` — when `urlBarMode == 2 && urlBarVisible`, it calls `hideUrlBar()`. This is consistent with the existing double-tap toggle: since mode 2 already uses double-tap detection, the 300ms delay is already present.

### 🐛 Fix: Tabs disappear on app restart

Tabs were not persisted across restarts — every launch opened a single home-page tab regardless of what was open before.

**Fix:** Added `saveTabs()` and `restoreTabs()`.
- `saveTabs()` serialises all non-incognito tabs to a JSON array (`saved_tabs` key in SharedPreferences), recording each tab's `url` and `isDesktopMode`. The active tab index among non-incognito tabs is stored separately (`saved_tab_index`).
- `restoreTabs()` reads those entries, calls `createTab()` for each, loads the saved URL (or home page if blank), then switches to the previously-active tab. Returns `false` if nothing to restore so `onCreate()` falls back to the default home tab.
- `saveTabs()` is called from `onPause()` so state is saved whenever the app goes to background.
- Incognito tabs are intentionally excluded from persistence.

### ✨ Download manager dialog

Previously downloads were silently queued into the system DownloadManager with no in-app tracking.

**Changes:**
- `saveDownloadEntry(id, filename, url)` — called from the download listener after every `DownloadManager.enqueue()`. Stores `{id, fn, url, ts}` as JSON in prefs key `downloads_v1` (newest-100 kept).
- `showDownloadsDialog()` — shows a list of all tracked downloads newest-first. Each row queries the system DownloadManager for current status (`✓ Complete`, `↓ Downloading…`, `⏳ Pending`, `⏸ Paused`, `✗ Failed`). Tapping a completed row opens the file via `ACTION_VIEW` using `DownloadManager.getUriForDownloadedFile(id)` (no FileProvider needed). A "Clear Downloads List" button at the bottom clears the prefs key.
- Added **"⬇️ Downloads"** entry to the overflow menu (⋮), between History and Bookmarks.

---

## v26 — Pull-to-refresh false trigger fix

### 🐛 Fix: Pull-to-refresh fires when scrolling back up to top

**File:** `app/src/main/java/com/browser/app/ScrollAwareWebView.kt`

**Problem:** If the user started a gesture at the top (`scrollY == 0`), scrolled down into the page (`scrollY > 0`), then scrolled back up to the top in the same continuous gesture, pull-to-refresh would fire. The root cause: `pullStartY` was set at `ACTION_DOWN` (when `scrollY == 0`) but was never cleared when `scrollY` went above zero mid-gesture. On the way back up, `scrollY == 0` again and the accumulated `ev.y − pullStartY` exceeded the 120dp threshold.

**Fix:** Added a guard at the start of `ACTION_MOVE`: if `scrollY > 0`, set `pullStartY = -1f` to disarm pull-to-refresh for the remainder of that gesture. Pull-to-refresh can now only fire if the user's finger has been continuously at the top of the page for the entire swipe — which is the correct intent.

---

## v25 — Navigation overhaul, draggable globe, keyboard fix, swipe improvements

### Navigation simplified
- Removed 6 overlapping settings (Hidden URL Bar Mode, Hide Method, Auto-hide Delay, Scroll to Hide, Globe Button behavior, FAB behavior) and replaced with **one setting**: URL Bar mode
  - **Auto-hide** (default): bar hides on scroll down, shows on scroll up; globe FAB as fallback
  - **Always visible**: bar stays at top, no FAB
  - **Hidden**: bar only shows when globe is tapped or top-edge zone is touched

### Draggable globe FAB
- Globe button now supports **drag-to-reposition** — drag it anywhere on screen, snaps to nearest edge on release with spring animation
- Position is saved to prefs and restored across restarts
- Short tap still toggles the URL bar

### Keyboard fix
- URL bar no longer auto-shows keyboard when revealed (e.g. globe tap, scroll up)
- Keyboard only appears when user **taps the URL input field** explicitly
- Home page search bar tap still opens bar with keyboard (intentional)

### Swipe navigation improvements
- Destination panel now shows **parallax effect** (moves at 25% of overlay speed) for depth
- Commit threshold reduced from 28% → 24% of screen width (easier to trigger)
- Rubber-band resistance unchanged (0.08×) for wrong-direction pulls

### Internals
- Removed `fabBehavior`, `hiddenUrlBarMode`, `autoHideDelayMs`, `hiddenHideMethod`, `scrollHideEnabled`, `autoHideRunnable` fields
- Removed `scheduleAutoHide` / `cancelAutoHide` functions (no longer needed)
- Added `urlBarMode: Int` (0/1/2) as single source of truth for bar behavior
- Added `focusUrlInput()` helper (centralises keyboard show logic)
- Added `setupDraggableFab()` (touch handler, snap animation, prefs save/restore)

# BrowserApp — Development Log

## v20 → v21

---

### ✨ Hidden URL Bar Mode

The FAB-based URL bar system has been extended with a clean "Hidden URL Bar Mode":

- When enabled in Settings → Navigation, the URL bar **and** the globe FAB are both hidden during browsing.
- A transparent 44dp touch strip (`topEdgeZone`) sits at the very top of the screen at elevation 25dp, above the WebView. Tapping it reveals the URL bar without the website below registering the touch (no conflicts with website inputs like Google's search bar — the overlay captures the event first).
- **Auto-hide delay** is configurable: 2 s / 5 s / 10 s / Never. The delay resets each time the URL bar is shown.
- **Double-tap** the page to toggle the URL bar at any time.
- **Scroll down** hides the URL bar; **scroll up** reveals it (when `scrollHideEnabled` is on).
- All preferences persist across restarts.

---

### ✨ Bookmarks

- Star button (`btnBookmark`) in the URL bar replaces the old Speed Dial star.
- Tap star on an unvisited page → bookmarks instantly with vibration confirmation.
- Tap star on a bookmarked page → shows "Edit / Remove / Done" dialog.
- **Bookmarks dialog** (via ⋮ menu): searchable list, swipe-friendly delete (✕), sorted newest-first.
- Stored in SharedPreferences as JSON under key `bookmarks_v2`.
- Star icon turns gold (filled) when the current page is bookmarked; fades otherwise.

---

### ✨ History

- Every page load is recorded automatically (incognito tabs are excluded).
- **History dialog** (via ⋮ menu): grouped into Today / Yesterday / This Week / Older, each entry shows title + timestamp + URL.
- Full text search across title and URL.
- Delete individual entries (✕) or clear all (with confirmation prompt).
- Stores up to 500 entries in `history_v2` SharedPreferences key.

---

### ✨ Incognito Tabs

- "New Incognito Tab" in the ⋮ menu opens a tab with:
  - `WebSettings.cacheMode = LOAD_NO_CACHE`
  - `saveFormData = false`, `savePassword = false`
  - Third-party cookies disabled
  - History recording skipped
- A **purple 3dp indicator strip** appears at the top of the screen when an incognito tab is active (color `#9C27B0`).
- Grid tab switcher shows a 🕵 icon and purple card accent for incognito tabs.
- Closing the last incognito tab triggers `CookieManager.removeAllCookies()` (best-effort cleanup).

---

### ✨ Find in Page

- Activated from ⋮ → "Find in Page".
- A slide-up bar at the bottom of the screen contains:
  - Search EditText
  - Live match counter (`X/Y` format, via `setFindListener`)
  - ↑ Previous / ↓ Next navigation buttons
  - ✕ Close button
- Uses `WebView.findAllAsync()` for non-blocking search.
- Find bar dismisses on back press. Clears `WebView.clearMatches()` on close.
- **Background:** `find_bar_bg.xml` — frosted-glass dark with rounded top corners.

---

### ✨ Share Menu (⋮ overflow)

All share/page actions live in the **⋮ overflow menu** for a clean URL bar:

| Item | Action |
|---|---|
| Copy URL | Clipboard + toast + haptic |
| Copy Title | Clipboard + toast |
| Share Page | Android `ACTION_SEND` chooser |
| Open in Browser | `ACTION_VIEW` external intent |
| QR Code | Opens `api.qrserver.com` in a new tab (no library dependency) |

---

### ✨ Search Engine Selection

- Settings → Search → "Search Engine"
- Built-in: **Google**, **Bing**, **DuckDuckGo**, **Brave Search**, **Startpage**
- **Custom**: prompts for a search URL with `?q=` placeholder
- Selection persists in prefs; used in `navigateTo()` for all non-URL queries.

---

### ✨ Desktop Site Toggle

- ⋮ → "Request Desktop Site" / "Switch to Mobile Site"
- Switches `userAgentString` between `MOBILE_UA` and `DESKTOP_UA`, then reloads.
- State stored per-tab in `BrowserTab.isDesktopMode`.

---

### ✨ Reader Mode

- ⋮ → "Reader Mode"
- Injects JavaScript that:
  1. Extracts the best candidate element (`article`, `[role=main]`, `main`, `.post-content`, etc.)
  2. Creates a full-screen fixed overlay (`z-index: 2147483647`) with dark background (`#121212`) and serif font
  3. Removes `script`, `style`, `iframe`, `nav`, `header`, `footer`, `aside`, `.ad` elements
  4. Adds a sticky "✕ Close Reader" button at the top
- Toggling a second time removes the overlay and restores the page.
- No external libraries; pure JS injection via `WebView.evaluateJavascript()`.

---

### ✨ Pull to Refresh

- Detected natively in `ScrollAwareWebView.onTouchEvent()`.
- When `scrollY == 0` and the user drags down ≥ 120dp, `onPullToRefresh` fires.
- Triggers `webView.reload()` + progress bar + short haptic vibration.
- Avoids false positives by resetting the pull state on `ACTION_UP` / `ACTION_CANCEL`.

---

### ✨ Haptic Feedback

- All meaningful interactions vibrate: bookmark add, swipe navigation commit, pull-to-refresh, download start, copy actions.
- Configurable toggle in Settings → Appearance → "Haptic Feedback".
- Uses `VibrationEffect.createOneShot()` on API 26+ with graceful fallback.

---

### ✨ Grid Tab Switcher

- Replaced the old scrolling list with a **2-column grid** of cards.
- Each card shows: colored initial circle, title (2 lines), URL, ✕ close.
- Active tab highlighted with blue accent (`#1A4FC3F7` background).
- Incognito tabs show 🕵 icon in purple.
- Action row at top: **+ New Tab** | **+ Incognito** | **↩ Reopen** (last closed, when available).
- "Close All Tabs" button at the bottom (with confirmation).

---

### ✨ Recently Closed Tabs

- `closedTabs: ArrayDeque<Pair<String, String>>` stores the last 10 closed tab URLs + titles.
- "↩ Reopen" button appears in the grid tab switcher header when the list is non-empty.

---

### ✨ Long-Press Refresh = Hard Reload

- Long-press the refresh button calls `webView.clearCache(true)` then `webView.reload()`.
- Shows a "Hard reloaded" toast.

---

### ✨ URL-Scheme Intent Handling

- `AndroidManifest.xml` now includes an `ACTION_VIEW` intent filter for `http://` and `https://` schemes.
- The app can be selected as a browser from external app link taps.

---

### 🔧 Architecture Changes

| Before | After |
|---|---|
| Settings star = Speed Dial | Settings star = Bookmark; Speed Dial still accessible from home |
| `btnSettings` in URL bar | `btnOverflow` (⋮) in URL bar; Settings inside overflow menu |
| `fabBehavior` 0–3 | `hiddenUrlBarMode` (boolean) + `fabBehavior` 0–2 for non-hidden modes |
| `ScrollAwareWebView` scroll only | Scroll + pull-to-refresh detection in `onTouchEvent` |
| Single MainActivity | `BookmarkManager.kt` + `HistoryManager.kt` extracted |

---

### 🐛 Known Constraints

- Reader mode is best-effort; complex SPAs or paywalled sites may not extract cleanly.
- QR code requires internet (loads `api.qrserver.com`).
- Incognito cookie isolation is partial — Android's `CookieManager` is process-wide; `removeAllCookies` on incognito close affects all sessions.
- Pull-to-refresh threshold (120dp) is intentionally high to avoid accidental triggers on bounce-heavy pages.

---

## v21 → v22

### 🐛 Fix: `Unresolved reference: bmDialog` (build error)

**File:** `app/src/main/java/com/browser/app/MainActivity.kt`

**Problem:** In `showBookmarksDialog()`, `var bmDialog: AlertDialog? = null` was declared *after* the `buildList()` inner function whose lambda captured it (`bmDialog?.dismiss()`). Kotlin requires a variable to be declared before any closure that references it, so the compiler emitted `Unresolved reference: bmDialog` at the call site inside `buildList`.

**Fix:** Moved the `var bmDialog: AlertDialog? = null` declaration to immediately before `fun buildList(...)`, keeping the assignment (`bmDialog = AlertDialog.Builder(this)...`) in its original position. No logic change — only declaration order corrected.

---

## v22 → v23

### ✨ Hidden URL Bar Mode — Configurable Hide Method + Hide Button

#### Hide Method setting
Under Settings → Navigation → Hidden URL Bar Mode, a new **Hide Method** chevron lets you choose how the URL bar dismisses itself after being revealed:

| Option | Behaviour |
|---|---|
| **Scroll + Timer** (default) | Scroll down hides it; auto-hide timer also fires |
| **Scroll only** | Scroll down hides it; timer is disabled |
| **Timer only** | Only the auto-hide timer hides it; scrolling does not |
| **Manual (button only)** | Neither scroll nor timer — bar stays until you tap ⌄ |

The **Auto-hide Delay** sub-option is now hidden when the selected method doesn't use a timer (Scroll only / Manual), reducing clutter.

#### ⌄ Hide button in URL bar
A new chevron-down button (`⌄`) appears at the right end of the URL bar whenever Hidden URL Bar Mode is active. Tapping it instantly dismisses the bar and restores the top-edge touch zone — useful when you've finished typing and want to go back to full-screen browsing without waiting for the timer or scrolling.

The button is only visible in Hidden URL Bar Mode; in normal mode the URL bar slot stays unchanged.

#### Scroll logic cleanup
The scroll callback was refactored to branch on `hiddenUrlBarMode` rather than sharing the same `scrollHideEnabled` gate for both modes. In hidden mode, scroll-up no longer accidentally re-reveals the URL bar (the top-edge zone is the only reveal trigger), and scroll-down behaviour is now fully governed by the new Hide Method setting.

---

## v23 → v24

### ✨ Tab thumbnails

Each tab card in the tab switcher now shows a live screenshot preview at the top of the card. Screenshots are captured 600ms after `onPageFinished` (to let the page paint) at 40% scale using `RGB_565` to keep memory low. Old thumbnails are recycled when tabs are closed.

### ✨ Swipe navigation destination preview

When you swipe left or right to go back/forward, the panel revealed behind the sliding page now shows a screenshot of the destination page (the page you previously visited at that URL) instead of a plain dark-blue background. A semi-transparent dim overlay keeps the title and URL text readable. If no screenshot is cached for that URL yet, the original text-only panel is shown as a fallback.

Screenshots are stored per-URL in a cache on each tab (max 12 entries, oldest evicted first). This means you'll see previews for pages you've already visited within that tab.

### 🐛 Fix: Home screen search bar not opening keyboard

Tapping the search bar on the home screen called `showUrlBar()` which focused the URL `EditText` but never explicitly requested the soft keyboard. Fixed by calling `InputMethodManager.showSoftInput(urlInput, SHOW_IMPLICIT)` immediately after `requestFocus()` — the keyboard now reliably opens.
