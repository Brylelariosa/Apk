#!/bin/sh
# Builds the native engine for the host machine and renders every preset (no Android SDK needed).
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CPP="$ROOT/app/src/main/cpp"
OUT="${TMPDIR:-/tmp}/cwtest_out"
mkdir -p "$OUT"
g++ -std=c++17 -O2 -Wall -Wextra -I"$CPP" "$ROOT/tools/desktop_test.cpp" \
  "$CPP"/dsp/*.cpp "$CPP"/parser/*.cpp "$CPP"/engine/*.cpp "$CPP"/audio/*.cpp -o "$OUT/cwtest"
for f in "$ROOT"/app/src/main/assets/presets/*.cws; do
  printf '%-28s ' "$(basename "$f")"
  "$OUT/cwtest" "$f" "$OUT/$(basename "$f" .cws).wav"
done

# Native crash reporter: provoke a real SIGSEGV and check the report file.
g++ -std=c++17 -O0 -g -rdynamic -I"$CPP" "$ROOT/tools/crash_handler_test.cpp" "$CPP/crash/crash_handler.cpp" -o "$OUT/crash_test" -ldl
rm -f "$OUT/native_crash.txt"
"$OUT/crash_test" "$OUT/native_crash.txt" >/dev/null 2>&1 || true
grep -q "SIGSEGV" "$OUT/native_crash.txt" && echo "crash reporter: OK (SIGSEGV captured)" || { echo "crash reporter: FAILED"; exit 1; }
