// Desktop check of the native crash reporter: ./crash_handler_test /tmp/report.txt [abort]   (see tools/build_and_test.sh)
#include <csignal>
#include <cstdio>
#include <cstdlib>
#include "crash/crash_handler.h"
static int __attribute__((noinline)) deep(int n) { if (n == 0) { volatile int* p = nullptr; *p = 42; return 0; } return deep(n - 1) + 1; }
extern "C" void Java_fake_entry() { deep(3); }
int main(int argc, char** argv) {
  cw::installCrashHandler(argv[1]);
  if (argc > 2 && argv[2][0] == 'a') abort();
  Java_fake_entry();
  return 0;
}
