package com.codewave.studio.crash

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.codewave.studio.MainActivity
import java.io.File

/**
 * Shows a crash report. Runs in its own process (":crash") and is built from plain views with fixed
 * colors, so it still works when the main screen, its theme or its layouts are what is broken.
 */
class CrashReportActivity : Activity() {

    private lateinit var headerView: TextView
    private lateinit var infoView: TextView
    private lateinit var bodyView: TextView
    private var current: File? = null
    private var reportText: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CrashLog.markSeen(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
            setPadding(dp(16), dp(16), dp(16), dp(10))
        }
        headerView = TextView(this).apply {
            textSize = 20f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(RED)
        }
        infoView = TextView(this).apply {
            textSize = 12f
            setTextColor(DIM)
            setPadding(0, dp(4), 0, dp(10))
        }
        bodyView = TextView(this).apply {
            typeface = Typeface.MONOSPACE
            textSize = 11f
            setTextColor(FG)
            setTextIsSelectable(true)
        }
        val scroll = ScrollView(this).apply {
            setBackgroundColor(PANEL)
            setPadding(dp(10), dp(8), dp(10), dp(8))
            addView(bodyView, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        root.addView(headerView)
        root.addView(infoView)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(row(button("Copy") { copy() }, button("Share") { share() }))
        root.addView(row(button("Save as...") { saveAs() }, button("Older reports") { older() }))
        root.addView(row(button("Restart app") { restart() }, button("Close") { finish() }))
        setContentView(root)

        val path = intent?.getStringExtra(EXTRA_FILE)
        show(if (path != null) File(path) else CrashLog.latest(this))
    }

    private fun show(file: File?) {
        current = file
        if (file == null || !file.exists()) {
            headerView.text = "Crash log"
            infoView.text = ""
            reportText = "No crash reports recorded."
        } else {
            headerView.text = "CodeWave Studio crashed"
            infoView.text = file.name + "  -  report saved in the app and in Download/CodeWaveStudio (Android 10+)"
            reportText = CrashLog.read(file)
        }
        bodyView.text = reportText
    }

    private fun copy() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("CodeWave crash report", reportText))
        Toast.makeText(this, "Copied to the clipboard", Toast.LENGTH_SHORT).show()
    }

    private fun share() {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "CodeWave Studio crash report")
            putExtra(Intent.EXTRA_TEXT, reportText)
        }
        try {
            startActivity(Intent.createChooser(send, "Share crash report"))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "Nothing can handle sharing here", Toast.LENGTH_SHORT).show()
        }
    }

    private fun saveAs() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/plain"
            putExtra(Intent.EXTRA_TITLE, current?.name ?: "codewave_crash.txt")
        }
        try {
            @Suppress("DEPRECATION")
            startActivityForResult(intent, REQ_SAVE)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "No file picker is available", Toast.LENGTH_SHORT).show()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode == REQ_SAVE && resultCode == RESULT_OK && uri != null) {
            val ok = try {
                contentResolver.openOutputStream(uri, "wt")?.use { it.write(reportText.toByteArray(Charsets.UTF_8)) }
                true
            } catch (e: Exception) {
                false
            }
            Toast.makeText(this, if (ok) "Saved" else "Could not save the file", Toast.LENGTH_SHORT).show()
        }
    }

    private fun older() {
        val files = CrashLog.list(this)
        if (files.isEmpty()) {
            Toast.makeText(this, "No reports recorded", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Crash reports")
            .setItems(files.map { it.name }.toTypedArray()) { _, which -> show(files[which]) }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun restart() {
        val intent = Intent(this, MainActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        startActivity(intent)
        finish()
    }

    // ---------------------------------------------------------------- tiny view helpers

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun button(label: String, onClick: () -> Unit): Button = Button(this).apply {
        text = label
        transformationMethod = null // no forced upper-case
        setOnClickListener { onClick() }
    }

    private fun row(left: Button, right: Button): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        val lp = { start: Int, end: Int ->
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).also {
                it.setMargins(dp(start), 0, dp(end), 0)
            }
        }
        addView(left, lp(0, 4))
        addView(right, lp(4, 0))
    }

    companion object {
        const val EXTRA_FILE = "report_file"
        private const val REQ_SAVE = 5001
        private const val BG = 0xFF0B0F14.toInt()
        private const val PANEL = 0xFF121821.toInt()
        private const val FG = 0xFFE6EDF3.toInt()
        private const val DIM = 0xFF8B98A9.toInt()
        private const val RED = 0xFFFF6B6B.toInt()
    }
}
