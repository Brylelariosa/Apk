package com.codewave.studio.crash

import android.app.Activity
import android.app.Application
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Process
import android.provider.MediaStore
import com.codewave.studio.engine.NativeBridge
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * In-app crash log: no root, no Shizuku, no PC, no permissions.
 *
 *  - Java/Kotlin crashes are caught by a default uncaught-exception handler.
 *  - Native (C++) crashes are caught by a signal handler (crash_handler.cpp) that writes a small
 *    file, which is turned into a normal report on the next launch.
 *  - Every report is saved in the app's private storage and, on Android 10+, also as a plain text
 *    file in Download/CodeWaveStudio (visible in any file manager; not Android/data).
 *  - A separate-process screen ([CrashReportActivity]) shows the report with Copy / Share / Save.
 *
 * "Recent events" (breadcrumbs) record what the app was doing just before the crash.
 */
object CrashLog {
    private const val DIR = "crashlogs"
    private const val UNSEEN = "unseen.flag"
    private const val NATIVE = "native_crash.txt"
    private const val CRUMBS = "breadcrumbs.txt"
    private const val MAX_REPORTS = 10
    private const val MAX_CRUMBS = 80

    private val crumbs = ArrayList<String>()
    private var crumbFile: File? = null

    @Volatile
    private var handling = false

    // ------------------------------------------------------------------ setup

    /** Call once from Application.onCreate. Never throws. */
    fun install(app: Application) {
        try {
            if (isCrashProcess()) return
            val dir = dir(app)
            val file = File(dir, CRUMBS)
            val previousCrumbs = try {
                if (file.exists()) file.readLines().takeLast(MAX_CRUMBS) else emptyList()
            } catch (e: Exception) {
                emptyList()
            }
            try {
                file.writeText("")
            } catch (e: Exception) {
                // breadcrumbs stay in memory only
            }
            crumbFile = file

            Thread.setDefaultUncaughtExceptionHandler(JavaCrashHandler(app, Thread.getDefaultUncaughtExceptionHandler()))
            note("App start ${versionString(app)} | Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}) | ${Build.MANUFACTURER} ${Build.MODEL}")

            importNativeCrash(app, previousCrumbs)

            if (NativeBridge.available) {
                NativeBridge.installCrashHandler(File(dir, NATIVE).absolutePath)
                note("Native engine loaded, native crash handler installed")
            } else {
                note("Native engine NOT loaded (libcodewave.so missing or incompatible)")
            }
        } catch (t: Throwable) {
            // crash logging must never be the reason the app fails to start
        }
    }

    /** Adds a line to the "recent events" list that is attached to every crash report. */
    fun note(message: String) {
        try {
            val line = SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date()) + "  " + message
            synchronized(crumbs) {
                crumbs.add(line)
                while (crumbs.size > MAX_CRUMBS) crumbs.removeAt(0)
                val f = crumbFile
                if (f != null) {
                    if (f.length() > 24_000) f.writeText(crumbs.joinToString("\n") + "\n") else f.appendText(line + "\n")
                }
            }
        } catch (t: Throwable) {
            // ignore
        }
    }

    // ---------------------------------------------------------------- reports

    fun list(context: Context): List<File> =
        (dir(context).listFiles { f -> f.name.startsWith("crash_") && f.name.endsWith(".txt") } ?: emptyArray())
            .sortedByDescending { it.name }

    fun latest(context: Context): File? = list(context).firstOrNull()

    fun read(file: File): String = try {
        file.readText()
    } catch (e: Exception) {
        "Could not read ${file.name}: ${e.message}"
    }

    fun hasUnseen(context: Context): Boolean = File(dir(context), UNSEEN).exists()

    fun markSeen(context: Context) {
        File(dir(context), UNSEEN).delete()
    }

    fun clear(context: Context) {
        list(context).forEach { it.delete() }
        markSeen(context)
    }

    /** Opens the crash screen (it runs in its own process, so it works even if the app is broken). */
    fun showViewer(context: Context, file: File? = null) {
        val intent = Intent(context, CrashReportActivity::class.java)
        if (file != null) intent.putExtra(CrashReportActivity.EXTRA_FILE, file.absolutePath)
        if (context !is Activity) intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        context.startActivity(intent)
    }

    /** A deliberate test crash so you can check that logging works on your device. */
    fun crashForTest(): Nothing {
        note("Test crash requested from Settings")
        throw IllegalStateException("Test crash from CodeWave Studio settings (this is expected)")
    }

    // --------------------------------------------------------------- internals

    private fun dir(context: Context): File {
        val d = File(context.filesDir, DIR)
        if (!d.exists()) d.mkdirs()
        return d
    }

    private fun isCrashProcess(): Boolean {
        val name = if (Build.VERSION.SDK_INT >= 28) {
            Application.getProcessName() ?: ""
        } else {
            try {
                File("/proc/self/cmdline").readText().trim('\u0000', ' ', '\n')
            } catch (e: Exception) {
                ""
            }
        }
        return name.endsWith(":crash")
    }

    private fun versionString(context: Context): String = try {
        @Suppress("DEPRECATION")
        val pi = context.packageManager.getPackageInfo(context.packageName, 0)
        @Suppress("DEPRECATION")
        "${pi.versionName} (code ${pi.versionCode})"
    } catch (e: Exception) {
        "unknown version"
    }

    private fun importNativeCrash(app: Context, previousCrumbs: List<String>) {
        val f = File(dir(app), NATIVE)
        if (!f.exists()) return
        val text = try {
            f.readText()
        } catch (e: Exception) {
            ""
        }
        f.delete()
        if (text.isBlank()) return
        val epoch = Regex("time: (\\d+)").find(text)?.groupValues?.get(1)?.toLongOrNull()
        val whenCrashed = if (epoch != null) Date(epoch * 1000L) else Date()
        saveReport(app, "Native crash (C++ signal)", text, previousCrumbs, whenCrashed)
    }

    private fun saveReport(
        context: Context,
        kind: String,
        body: String,
        breadcrumbs: List<String>,
        time: Date = Date()
    ): File {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(time)
        val name = "crash_$stamp.txt"
        val text = buildString {
            append("CodeWave Studio crash report\n")
            append("============================\n")
            append("Time:     ").append(SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(time)).append('\n')
            append("Kind:     ").append(kind).append('\n')
            append("App:      ").append(versionString(context)).append("  ").append(context.packageName).append('\n')
            append("Device:   ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL).append('\n')
            append("Android:  ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT)
                .append(")  ABIs: ").append(Build.SUPPORTED_ABIS.joinToString(", ")).append('\n')
            append('\n')
            append(body.trimEnd())
            append("\n\nRecent events (oldest first):\n")
            if (breadcrumbs.isEmpty()) append("  (none)\n") else breadcrumbs.forEach { append("  ").append(it).append('\n') }
        }
        val publicNote = savePublicCopy(context, name, text)
        val file = File(dir(context), name)
        file.writeText(text + "\n" + publicNote + "\n")
        File(dir(context), UNSEEN).createNewFile()
        list(context).drop(MAX_REPORTS).forEach { it.delete() }
        return file
    }

    /** Android 10+: writes Download/CodeWaveStudio/<name> through MediaStore (no permission needed). */
    private fun savePublicCopy(context: Context, name: String, text: String): String {
        if (Build.VERSION.SDK_INT < 29) {
            return "Public copy: not saved (needs Android 10+). Use Share or Save as... on this screen."
        }
        return try {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, "text/plain")
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/CodeWaveStudio")
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            if (uri == null) {
                "Public copy: not saved"
            } else {
                resolver.openOutputStream(uri)?.use { it.write(text.toByteArray(Charsets.UTF_8)) }
                "Public copy: Download/CodeWaveStudio/$name"
            }
        } catch (e: Exception) {
            "Public copy: not saved (${e.javaClass.simpleName})"
        }
    }

    private fun snapshotCrumbs(): List<String> = synchronized(crumbs) { ArrayList(crumbs) }

    private class JavaCrashHandler(
        private val app: Application,
        private val previous: Thread.UncaughtExceptionHandler?
    ) : Thread.UncaughtExceptionHandler {

        override fun uncaughtException(thread: Thread, error: Throwable) {
            if (CrashLog.handling) { // crashed inside the handler: hand over to the system
                previous?.uncaughtException(thread, error)
                return
            }
            CrashLog.handling = true
            var shown = false
            try {
                val trace = try {
                    val sw = StringWriter()
                    error.printStackTrace(PrintWriter(sw))
                    sw.toString()
                } catch (t: Throwable) {
                    error.toString()
                }
                val file = CrashLog.saveReport(app, "Java/Kotlin exception", "Thread: ${thread.name}\n\n$trace", CrashLog.snapshotCrumbs())
                CrashLog.showViewer(app, file)
                shown = true
            } catch (t: Throwable) {
                // fall through to the default behaviour
            }
            if (shown) {
                try {
                    Thread.sleep(250) // let the system accept the activity start
                } catch (e: InterruptedException) {
                    // ignore
                }
                Process.killProcess(Process.myPid())
                System.exit(10)
            } else {
                previous?.uncaughtException(thread, error)
            }
        }
    }
}
