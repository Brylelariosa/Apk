package com.codewave.studio

import android.app.Application
import com.codewave.studio.crash.CrashLog

/** Installs the crash logger before any screen is created. */
class CodeWaveApp : Application() {
    override fun onCreate() {
        super.onCreate()
        CrashLog.install(this)
    }
}
