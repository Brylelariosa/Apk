package com.codewave.studio.player

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import com.codewave.studio.crash.CrashLog
import com.codewave.studio.data.AppSettings
import com.codewave.studio.engine.AudioEngine

/**
 * Plays the engine's current sound through an AudioTrack (MODE_STREAM). Every play/seek
 * creates a fresh track and a short-lived writer thread, so the head position is always
 * exact and nothing is left running while paused, stopped or backgrounded.
 *
 * All public methods must be called from the main thread.
 */
class PcmPlayer(private val engine: AudioEngine, private val settings: AppSettings) {

    enum class State { IDLE, PLAYING, PAUSED }

    interface Listener {
        fun onPlayerStateChanged(state: State)
        fun onPlayerError(message: String)
    }

    var listener: Listener? = null

    var state: State = State.IDLE
        private set

    @Volatile
    var loop: Boolean = false

    var volume: Float = 1f
        set(value) {
            field = value.coerceIn(0f, 1f)
            try {
                active?.track?.setVolume(field)
            } catch (e: IllegalStateException) {
                // track already released
            }
        }

    val totalFrames: Int get() = total

    private val main = Handler(Looper.getMainLooper())
    private var total = 0
    private var sampleRate = 44100
    private var channels = 2
    private var positionFrames = 0
    private var active: Run? = null

    private inner class Run(val track: AudioTrack, val startFrame: Int, val chunkFrames: Int, val drainMs: Long) {
        @Volatile
        var quit = false

        @Volatile
        var wrapped = false
        val thread: Thread = Thread({ writerLoop(this) }, "cw-player").apply { isDaemon = true }
    }

    /** Replaces the loaded sound (after a successful generation). Stops playback. */
    fun load(info: AudioEngine.SoundInfo) {
        stop()
        total = info.frames
        sampleRate = info.sampleRate
        channels = info.channels
        positionFrames = 0
    }

    fun play() {
        if (total <= 0 || state == State.PLAYING) return
        startRun(if (positionFrames >= total) 0 else positionFrames)
    }

    fun pause() {
        val r = active ?: return
        positionFrames = currentFrame()
        CrashLog.note("Player: pause at frame $positionFrames")
        stopRun(r)
        state = State.PAUSED
        notifyState()
    }

    fun stop() {
        active?.let { stopRun(it) }
        positionFrames = 0
        if (state != State.IDLE) {
            state = State.IDLE
            notifyState()
        }
    }

    fun seekTo(frame: Int) {
        val f = frame.coerceIn(0, total)
        val r = active
        if (r != null) {
            stopRun(r)
            startRun(f)
        } else {
            positionFrames = f
        }
    }

    /** Current position in frames (exact: derived from the AudioTrack's playback head). */
    fun currentFrame(): Int {
        val r = active ?: return positionFrames
        val head = try {
            r.track.playbackHeadPosition.toLong() and 0xFFFFFFFFL
        } catch (e: IllegalStateException) {
            0L
        }
        val pos = r.startFrame.toLong() + head
        return if (r.wrapped && total > 0) (pos % total).toInt() else minOf(pos, total.toLong()).toInt()
    }

    /** Releases everything. The player must not be used afterwards. */
    fun release() {
        stop()
        listener = null
    }

    // ------------------------------------------------------------------ internals

    private fun notifyState() {
        listener?.onPlayerStateChanged(state)
    }

    private fun startRun(startFrame: Int) {
        val mask = if (channels == 1) AudioFormat.CHANNEL_OUT_MONO else AudioFormat.CHANNEL_OUT_STEREO
        val frameBytes = channels * 2
        val minBytes = AudioTrack.getMinBufferSize(sampleRate, mask, AudioFormat.ENCODING_PCM_16BIT)
        val mult = when (settings.bufferSize) {
            AppSettings.BUFFER_SMALL -> 1
            AppSettings.BUFFER_LARGE -> 4
            else -> 2
        }
        var bufferBytes = (if (minBytes > 0) minBytes else 4096 * frameBytes) * mult
        bufferBytes -= bufferBytes % frameBytes

        val track = try {
            val t = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(mask)
                        .build()
                )
                .setBufferSizeInBytes(bufferBytes)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            if (t.state != AudioTrack.STATE_INITIALIZED) {
                t.release()
                throw IllegalStateException("the audio output could not be initialised")
            }
            t.setVolume(volume)
            t.play()
            t
        } catch (e: Exception) {
            positionFrames = startFrame
            state = if (state == State.PLAYING) State.PAUSED else state
            CrashLog.note("Player: AudioTrack failed: ${e.javaClass.simpleName} ${e.message}")
            listener?.onPlayerError("Audio playback failed: ${e.message ?: e.javaClass.simpleName}")
            notifyState()
            return
        }

        val bufferFrames = bufferBytes / frameBytes
        val drain = bufferFrames * 1000L / sampleRate + 400L
        val r = Run(track, startFrame, maxOf(512, bufferFrames / 2), drain)
        CrashLog.note("Player: start at frame $startFrame (buffer ${bufferBytes} B, loop=$loop)")
        active = r
        state = State.PLAYING
        r.thread.start()
        notifyState()
    }

    private fun stopRun(r: Run) {
        r.quit = true
        try {
            r.track.pause() // wakes a blocked write()
            r.track.flush()
        } catch (e: IllegalStateException) {
            // already stopped
        }
        if (Thread.currentThread() !== r.thread) {
            try {
                r.thread.join(250)
            } catch (e: InterruptedException) {
                Thread.currentThread().interrupt()
            }
        }
        try {
            r.track.release()
        } catch (e: IllegalStateException) {
            // already released
        }
        if (active === r) active = null
    }

    /** Runs on the writer thread: streams PCM from the native engine into the AudioTrack. */
    private fun writerLoop(r: Run) {
        val ch = channels
        val chunk = ShortArray(r.chunkFrames * ch)
        var frame = r.startFrame
        var written = 0L
        var failure: String? = null
        try {
            while (!r.quit) {
                if (frame >= total) {
                    if (loop) {
                        frame = 0
                        r.wrapped = true
                    } else {
                        break
                    }
                }
                val got = engine.copyPcm16(chunk, frame, minOf(r.chunkFrames, total - frame))
                if (got <= 0) break
                val shorts = got * ch
                var off = 0
                while (off < shorts && !r.quit) {
                    val w = r.track.write(chunk, off, shorts - off)
                    if (w < 0) {
                        failure = "Audio output error ($w)"
                        break
                    }
                    if (w == 0) Thread.sleep(2)
                    off += w
                }
                if (failure != null || r.quit) break
                written += got
                frame += got
            }
            if (failure == null && !r.quit) {
                r.track.stop() // plays out what is buffered
                val deadline = SystemClock.uptimeMillis() + r.drainMs
                while (!r.quit && SystemClock.uptimeMillis() < deadline) {
                    val head = r.track.playbackHeadPosition.toLong() and 0xFFFFFFFFL
                    if (head >= written) break
                    Thread.sleep(10)
                }
            }
        } catch (e: InterruptedException) {
            return
        } catch (e: IllegalStateException) {
            if (!r.quit) failure = "Audio output stopped unexpectedly"
        }
        if (r.quit) return
        val msg = failure
        main.post { onRunEnded(r, msg) }
    }

    private fun onRunEnded(r: Run, failure: String?) {
        if (active !== r) return
        stopRun(r)
        positionFrames = 0
        state = State.IDLE
        if (failure != null) listener?.onPlayerError(failure)
        notifyState()
    }
}
