// Native crash capture for devices without logcat access. The Kotlin side reads the file on the
// next launch and shows it in the in-app crash viewer.
#include "crash_handler.h"

#include <dlfcn.h>
#include <fcntl.h>
#include <signal.h>
#include <string.h>
#include <time.h>
#include <ucontext.h>
#include <unistd.h>
#include <unwind.h>

#include <cerrno>
#include <cstdint>

namespace {

constexpr int kSignals[] = {SIGSEGV, SIGABRT, SIGBUS, SIGFPE, SIGILL};
constexpr int kCount = (int)(sizeof(kSignals) / sizeof(kSignals[0]));

char g_path[512] = {0};
struct sigaction g_old[kCount];
volatile sig_atomic_t g_installed = 0;
volatile sig_atomic_t g_inHandler = 0;

int slotOf(int sig) {
  for (int i = 0; i < kCount; ++i)
    if (kSignals[i] == sig) return i;
  return -1;
}

const char* signalName(int sig) {
  switch (sig) {
    case SIGSEGV: return "SIGSEGV (invalid memory access)";
    case SIGABRT: return "SIGABRT (abort / failed assertion)";
    case SIGBUS: return "SIGBUS (bus error)";
    case SIGFPE: return "SIGFPE (arithmetic error)";
    case SIGILL: return "SIGILL (illegal instruction)";
    default: return "unknown";
  }
}

// ---- async-signal-safe output helpers (no malloc, no stdio) ----
void put(int fd, const char* s) {
  size_t n = strlen(s);
  while (n > 0) {
    const ssize_t w = ::write(fd, s, n);
    if (w < 0) {
      if (errno == EINTR) continue;
      return;
    }
    s += w;
    n -= (size_t)w;
  }
}

void putDec(int fd, long long v) {
  char buf[24];
  int i = (int)sizeof(buf);
  buf[--i] = 0;
  const bool neg = v < 0;
  unsigned long long u = neg ? (unsigned long long)(-v) : (unsigned long long)v;
  do {
    buf[--i] = (char)('0' + (u % 10));
    u /= 10;
  } while (u && i > 1);
  if (neg) buf[--i] = '-';
  put(fd, buf + i);
}

void putHex(int fd, uintptr_t v) {
  char buf[2 + sizeof(uintptr_t) * 2 + 1];
  int i = (int)sizeof(buf);
  buf[--i] = 0;
  do {
    buf[--i] = "0123456789abcdef"[v & 0xF];
    v >>= 4;
  } while (v && i > 2);
  buf[--i] = 'x';
  buf[--i] = '0';
  put(fd, buf + i);
}

const char* baseName(const char* path) {
  const char* slash = strrchr(path, '/');
  return slash ? slash + 1 : path;
}

void putFrame(int fd, int index, uintptr_t pc) {
  put(fd, "  #");
  putDec(fd, index);
  put(fd, "  pc ");
  putHex(fd, pc);
  Dl_info info;
  if (pc && dladdr(reinterpret_cast<void*>(pc), &info) && info.dli_fname) {
    put(fd, "  ");
    put(fd, baseName(info.dli_fname));
    put(fd, " +");
    putHex(fd, pc - reinterpret_cast<uintptr_t>(info.dli_fbase));
    if (info.dli_sname) {
      put(fd, "  (");
      put(fd, info.dli_sname);
      put(fd, ")");
    }
  }
  put(fd, "\n");
}

struct Trace {
  int fd;
  int n;
};

_Unwind_Reason_Code onFrame(struct _Unwind_Context* ctx, void* arg) {
  Trace* t = static_cast<Trace*>(arg);
  const uintptr_t pc = _Unwind_GetIP(ctx);
  if (pc == 0) return _URC_END_OF_STACK;
  putFrame(t->fd, t->n, pc);
  return ++t->n >= 48 ? _URC_END_OF_STACK : _URC_NO_REASON;
}

uintptr_t faultPc(void* ctx) {
#if defined(__aarch64__)
  return ctx ? (uintptr_t)static_cast<ucontext_t*>(ctx)->uc_mcontext.pc : 0;
#elif defined(__arm__)
  return ctx ? (uintptr_t)static_cast<ucontext_t*>(ctx)->uc_mcontext.arm_pc : 0;
#elif defined(__x86_64__) && defined(REG_RIP)
  return ctx ? (uintptr_t)static_cast<ucontext_t*>(ctx)->uc_mcontext.gregs[REG_RIP] : 0;
#else
  (void)ctx;
  return 0;
#endif
}

void writeReport(int sig, siginfo_t* info, void* ctx) {
  const int fd = ::open(g_path, O_WRONLY | O_CREAT | O_TRUNC, 0600);
  if (fd < 0) return;
  put(fd, "time: ");
  putDec(fd, (long long)time(nullptr));
  put(fd, "\nsignal: ");
  putDec(fd, sig);
  put(fd, " ");
  put(fd, signalName(sig));
  put(fd, "\ncode: ");
  putDec(fd, info ? info->si_code : 0);
  put(fd, "\nfault address: ");
  putHex(fd, info ? reinterpret_cast<uintptr_t>(info->si_addr) : 0);
  put(fd, "\ncrashing instruction:\n");
  putFrame(fd, 0, faultPc(ctx));
  put(fd, "backtrace:\n");
  Trace t = {fd, 0};
  _Unwind_Backtrace(onFrame, &t);
  ::close(fd);
}

void handler(int sig, siginfo_t* info, void* ctx) {
  const int slot = slotOf(sig);
  if (g_inHandler || slot < 0) {  // crashed while crashing: give up, let the system handle it
    signal(sig, SIG_DFL);
    return;
  }
  g_inHandler = 1;
  writeReport(sig, info, ctx);

  const struct sigaction& old = g_old[slot];
  if ((old.sa_flags & SA_SIGINFO) && old.sa_sigaction) {
    old.sa_sigaction(sig, info, ctx);
  } else if (!(old.sa_flags & SA_SIGINFO) && old.sa_handler != SIG_DFL && old.sa_handler != SIG_IGN && old.sa_handler) {
    old.sa_handler(sig);
  } else {
    signal(sig, SIG_DFL);  // returning re-runs the fault / lets abort() continue with the default action
  }
}

}  // namespace

namespace cw {

void installCrashHandler(const char* path) {
  if (!path || g_installed) return;
  strncpy(g_path, path, sizeof(g_path) - 1);
  g_path[sizeof(g_path) - 1] = 0;
  for (int i = 0; i < kCount; ++i) {
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_sigaction = handler;
    sa.sa_flags = SA_SIGINFO | SA_ONSTACK;
    sigemptyset(&sa.sa_mask);
    sigaction(kSignals[i], &sa, &g_old[i]);
  }
  g_installed = 1;
}

}  // namespace cw
