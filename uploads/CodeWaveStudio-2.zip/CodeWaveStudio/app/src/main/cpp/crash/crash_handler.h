#pragma once

namespace cw {

// Installs handlers for SIGSEGV/SIGABRT/SIGBUS/SIGFPE/SIGILL that write a short report
// (signal, fault address, backtrace) to `path` using only async-signal-safe calls, then pass
// the signal on to the previously installed handler (so Android still produces its tombstone).
// Safe to call more than once.
void installCrashHandler(const char* path);

}  // namespace cw
