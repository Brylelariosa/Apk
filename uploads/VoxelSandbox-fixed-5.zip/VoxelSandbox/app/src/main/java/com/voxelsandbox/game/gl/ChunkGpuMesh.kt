package com.voxelsandbox.game.gl

import android.opengl.GLES30
import com.voxelsandbox.game.world.WorldConfig
import com.voxelsandbox.game.world.mesh.MeshData
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Owns one GPU vertex/index buffer pair (a whole chunk column's terrain, or one of the
 * small particle/cloud/highlight meshes). Every method here issues GL calls, so
 * instances must only ever be touched from the GL thread (GameRenderer enforces this
 * by only creating/uploading/disposing from onDrawFrame).
 */
class ChunkGpuMesh {
    private var vao = 0
    private var vbo = 0
    private var ibo = 0
    private var indexCount = 0
    private var allocated = false

    /** Tight world-space vertical extent of the uploaded geometry, so GameRenderer's
     *  frustum test can use a box that hugs the real terrain (e.g. Y 0..34) instead of
     *  the full 0..64 world height. Only meaningful after [uploadColumn]. */
    var minY: Float = 0f
        private set
    var maxY: Float = WorldConfig.WORLD_HEIGHT.toFloat()
        private set

    /** True once this mesh has real geometry to draw. GameRenderer checks this
     *  before doing the 6-plane frustum test, so empty columns cost nothing per
     *  frame beyond this one flag check. */
    val hasContent: Boolean get() = allocated && indexCount > 0

    val triangleCount: Int get() = indexCount / 3

    // Shared staging buffers, reused across every upload instead of a fresh
    // ByteBuffer.allocateDirect(...) per call: hundreds of columns can finish meshing in
    // a short burst (e.g. right after changing render distance), and allocating a new
    // native buffer per upload on the GL thread for each of them is an avoidable source
    // of frame-time spikes/GC churn. Buffers only grow (by 1.5x, so they settle after a
    // couple of uploads), never shrink. GL-thread only, like everything else here.
    private object Scratch {
        var vertexBuf: ByteBuffer = ByteBuffer.allocateDirect(0).order(ByteOrder.nativeOrder())
        var indexBuf: ByteBuffer = ByteBuffer.allocateDirect(0).order(ByteOrder.nativeOrder())
        var indexStage: IntArray = IntArray(0)

        fun vertexFloats(count: Int): java.nio.FloatBuffer {
            val bytes = count * 4
            if (vertexBuf.capacity() < bytes) {
                vertexBuf = ByteBuffer.allocateDirect(maxOf(bytes, vertexBuf.capacity() * 3 / 2)).order(ByteOrder.nativeOrder())
            }
            vertexBuf.clear()
            return vertexBuf.asFloatBuffer()
        }

        fun indexInts(count: Int): java.nio.IntBuffer {
            val bytes = count * 4
            if (indexBuf.capacity() < bytes) {
                indexBuf = ByteBuffer.allocateDirect(maxOf(bytes, indexBuf.capacity() * 3 / 2)).order(ByteOrder.nativeOrder())
            }
            indexBuf.clear()
            return indexBuf.asIntBuffer()
        }

        fun stagingInts(count: Int): IntArray {
            if (indexStage.size < count) indexStage = IntArray(maxOf(count, indexStage.size * 3 / 2, 4096))
            return indexStage
        }
    }

    private fun ensureAllocated() {
        if (allocated) return
        val vaoIds = IntArray(1)
        GLES30.glGenVertexArrays(1, vaoIds, 0)
        vao = vaoIds[0]
        val ids = IntArray(2)
        GLES30.glGenBuffers(2, ids, 0)
        vbo = ids[0]
        ibo = ids[1]

        // The vertex layout below is identical for every mesh in the game and, for a
        // given vbo/ibo pair, never changes again after this — so it's recorded into
        // the VAO exactly once here, rather than reissued on every draw() call for
        // every visible chunk, every frame. Binding the element buffer while this vao
        // is bound records that association into the vao too.
        GLES30.glBindVertexArray(vao)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vbo)
        GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, ibo)
        val stride = 6 * 4
        GLES30.glEnableVertexAttribArray(0)
        GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, stride, 0)
        GLES30.glEnableVertexAttribArray(1)
        GLES30.glVertexAttribPointer(1, 2, GLES30.GL_FLOAT, false, stride, 3 * 4)
        GLES30.glEnableVertexAttribArray(2)
        GLES30.glVertexAttribPointer(2, 1, GLES30.GL_FLOAT, false, stride, 5 * 4)
        GLES30.glBindVertexArray(0)

        allocated = true
    }

    private fun commit(vertexBuffer: java.nio.FloatBuffer, floatCount: Int, indexBuffer: java.nio.IntBuffer, idxCount: Int) {
        ensureAllocated()
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vbo)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, floatCount * 4, vertexBuffer, GLES30.GL_STATIC_DRAW)
        GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, ibo)
        GLES30.glBufferData(GLES30.GL_ELEMENT_ARRAY_BUFFER, idxCount * 4, indexBuffer, GLES30.GL_STATIC_DRAW)
        indexCount = idxCount
    }

    /** Uploads the first [floatCount] floats / [idxCount] ints of the given arrays. The
     *  arrays may be larger than what's used (callers reuse scratch arrays), which is
     *  why counts are explicit rather than taken from .size. */
    fun uploadRaw(vertexData: FloatArray, floatCount: Int, indices: IntArray, idxCount: Int) {
        if (floatCount == 0 || idxCount == 0) {
            dispose()
            return
        }
        val vb = Scratch.vertexFloats(floatCount)
        vb.put(vertexData, 0, floatCount)
        vb.position(0)
        val ib = Scratch.indexInts(idxCount)
        ib.put(indices, 0, idxCount)
        ib.position(0)
        commit(vb, floatCount, ib, idxCount)
    }

    fun upload(data: MeshData) {
        if (data.isEmpty()) {
            dispose()
            return
        }
        uploadRaw(data.vertexData, data.vertexData.size, data.indices, data.indices.size)
    }

    /** Uploads several subchunk meshes as ONE combined buffer (one draw call for the
     *  whole column). Vertex positions are already in world space (see ChunkMesher), so
     *  the vertex floats are copied straight from each part into the direct staging
     *  buffer; only indices need shifting by however many vertices precede their part.
     *  No intermediate column-sized float/int arrays are allocated. */
    fun uploadColumn(parts: Array<MeshData?>) {
        var totalFloats = 0
        var totalIndices = 0
        var lo = Float.MAX_VALUE
        var hi = -Float.MAX_VALUE
        for (p in parts) {
            if (p == null || p.vertexCount == 0) continue
            totalFloats += p.vertexData.size
            totalIndices += p.indices.size
            if (p.minY < lo) lo = p.minY
            if (p.maxY > hi) hi = p.maxY
        }
        if (totalFloats == 0 || totalIndices == 0) {
            dispose()
            return
        }

        val vb = Scratch.vertexFloats(totalFloats)
        val stage = Scratch.stagingInts(totalIndices)
        var vertOffset = 0
        var idxOffset = 0
        for (p in parts) {
            if (p == null || p.vertexCount == 0) continue
            vb.put(p.vertexData, 0, p.vertexData.size)
            val src = p.indices
            for (k in src.indices) stage[idxOffset + k] = src[k] + vertOffset
            idxOffset += src.size
            vertOffset += p.vertexCount
        }
        vb.position(0)
        val ib = Scratch.indexInts(totalIndices)
        ib.put(stage, 0, totalIndices)
        ib.position(0)

        commit(vb, totalFloats, ib, totalIndices)
        minY = lo
        maxY = hi
    }

    /** [mode] defaults to GL_TRIANGLES for normal terrain/particle/cloud meshes;
     *  GameRenderer passes GL_LINES for the block-highlight wireframe so it can
     *  reuse this same buffer/shader plumbing instead of a separate code path. */
    fun draw(mode: Int = GLES30.GL_TRIANGLES) {
        if (!allocated || indexCount == 0) return
        GLES30.glBindVertexArray(vao)
        GLES30.glDrawElements(mode, indexCount, GLES30.GL_UNSIGNED_INT, 0)
    }

    fun dispose() {
        if (allocated) {
            GLES30.glDeleteBuffers(2, intArrayOf(vbo, ibo), 0)
            GLES30.glDeleteVertexArrays(1, intArrayOf(vao), 0)
            allocated = false
            indexCount = 0
        }
    }

    /** Marks this mesh's GL objects as gone WITHOUT issuing glDelete* calls — for
     *  when the EGL context itself was just destroyed and recreated (see
     *  GameRenderer.onSurfaceCreated). The old vao/vbo/ibo handles are already
     *  meaningless in the new context (deleting them would at best be a no-op,
     *  and at worst silently target unrelated objects that happen to reuse the
     *  same integer names in the new context), so this just clears the flag and
     *  lets the next upload() allocate fresh objects instead. */
    fun invalidateForContextLoss() {
        allocated = false
        indexCount = 0
    }
}
