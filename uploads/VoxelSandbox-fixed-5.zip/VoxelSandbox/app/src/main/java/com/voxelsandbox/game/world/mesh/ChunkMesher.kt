package com.voxelsandbox.game.world.mesh

import com.voxelsandbox.game.gl.TextureAtlas
import com.voxelsandbox.game.world.BlockType
import com.voxelsandbox.game.world.Chunk
import com.voxelsandbox.game.world.ChunkPos
import com.voxelsandbox.game.world.Face
import com.voxelsandbox.game.world.World
import com.voxelsandbox.game.world.WorldConfig

class MeshData(
    val vertexData: FloatArray,
    val indices: IntArray,
    val vertexCount: Int,
    /** Lowest / highest world-space Y of any vertex. Lets the renderer build a tight
     *  frustum-culling box per column instead of always testing the full world height. */
    val minY: Float = 0f,
    val maxY: Float = 0f
) {
    fun isEmpty(): Boolean = vertexCount == 0

    companion object {
        val EMPTY = MeshData(FloatArray(0), IntArray(0), 0)

        /** Floats per vertex in [vertexData]: position(3) + uv(2) + shade(1). Public
         *  (unlike MeshBuilder's private copy of the same number) so GameRenderer can
         *  correctly concatenate multiple subchunks' MeshData into one combined
         *  per-column buffer without duplicating/guessing the stride. */
        const val FLOATS_PER_VERTEX = 6
    }
}

/** Interleaved vertex layout: position(3) + uv(2) + shade(1) = 6 floats/vertex. Kept
 *  private to this file — nothing outside the mesher needs to know the layout details,
 *  only the resulting MeshData.
 *
 *  One builder is kept per mesh-worker thread and reset between jobs (see
 *  ChunkMesher.builders): its arrays only ever grow to the high-water mark of the
 *  biggest subchunk that thread has meshed, instead of every job re-growing fresh
 *  arrays from 128 vertices by repeated doubling (~3x the final size in garbage). */
private class MeshBuilder(initialVerts: Int = 1024) {
    companion object { const val FLOATS_PER_VERTEX = 6 }

    private var floats = FloatArray(initialVerts * FLOATS_PER_VERTEX)
    private var indices = IntArray(initialVerts * 3 / 2)
    private var vertCount = 0
    private var indexCount = 0
    private var minY = Float.MAX_VALUE
    private var maxY = -Float.MAX_VALUE

    fun reset() {
        vertCount = 0
        indexCount = 0
        minY = Float.MAX_VALUE
        maxY = -Float.MAX_VALUE
    }

    /** Emits one quad (4 vertices, 2 triangles). [flip] reverses the triangle index
     *  order without touching vertex positions or UVs, which is how TOP/BOTTOM faces
     *  get the same counter-clockwise-from-outside winding the four side faces are
     *  already authored with (see ChunkMesher.emitFace) so back-face culling can be on. */
    fun quad(
        x0: Float, y0: Float, z0: Float,
        x1: Float, y1: Float, z1: Float,
        x2: Float, y2: Float, z2: Float,
        x3: Float, y3: Float, z3: Float,
        u0: Float, v0: Float, u1: Float, v1: Float,
        shade: Float,
        flip: Boolean
    ) {
        val neededFloats = (vertCount + 4) * FLOATS_PER_VERTEX
        if (neededFloats > floats.size) floats = floats.copyOf(maxOf(floats.size * 2, neededFloats))
        val neededIdx = indexCount + 6
        if (neededIdx > indices.size) indices = indices.copyOf(maxOf(indices.size * 2, neededIdx))

        val f = floats
        var i = vertCount * FLOATS_PER_VERTEX
        f[i++] = x0; f[i++] = y0; f[i++] = z0; f[i++] = u0; f[i++] = v0; f[i++] = shade
        f[i++] = x1; f[i++] = y1; f[i++] = z1; f[i++] = u1; f[i++] = v0; f[i++] = shade
        f[i++] = x2; f[i++] = y2; f[i++] = z2; f[i++] = u1; f[i++] = v1; f[i++] = shade
        f[i++] = x3; f[i++] = y3; f[i++] = z3; f[i++] = u0; f[i++] = v1; f[i] = shade

        val lo = minOf(minOf(y0, y1), minOf(y2, y3))
        val hi = maxOf(maxOf(y0, y1), maxOf(y2, y3))
        if (lo < minY) minY = lo
        if (hi > maxY) maxY = hi

        val base = vertCount
        val ix = indices
        var k = indexCount
        if (flip) {
            ix[k++] = base; ix[k++] = base + 2; ix[k++] = base + 1
            ix[k++] = base; ix[k++] = base + 3; ix[k] = base + 2
        } else {
            ix[k++] = base; ix[k++] = base + 1; ix[k++] = base + 2
            ix[k++] = base; ix[k++] = base + 2; ix[k] = base + 3
        }
        vertCount += 4
        indexCount += 6
    }

    fun build(): MeshData =
        if (vertCount == 0) MeshData.EMPTY
        else MeshData(
            floats.copyOf(vertCount * FLOATS_PER_VERTEX),
            indices.copyOf(indexCount),
            vertCount,
            minY,
            maxY
        )
}

/**
 * Builds one mesh per subchunk using face culling: a face is emitted only when the
 * neighboring cell is non-opaque (an unloaded neighbor chunk reads as non-opaque too
 * — see World — so boundary faces render rather than leaving holes, until the real
 * neighbor loads and both sides remesh).
 *
 * Faces that can never be seen are not emitted at all:
 *  - water against water (water is drawn opaque, so the interior of a lake/ocean was
 *    ~95% pure waste: every block of water used to emit up to six hidden faces);
 *  - the bottom faces of the world floor (y = 0), which no legal camera position can
 *    ever see (that alone was ~30% of a typical chunk's geometry).
 * All-air subchunks return immediately without scanning their 4096 cells.
 *
 * Winding: the four side faces are authored counter-clockwise as seen from outside;
 * TOP and BOTTOM were authored clockwise, so they are emitted with flip = true. That
 * makes every face front-facing from outside, which lets GameRenderer enable back-face
 * culling.
 */
object ChunkMesher {
    private val builders = object : ThreadLocal<MeshBuilder>() {
        override fun initialValue(): MeshBuilder = MeshBuilder()
    }

    fun buildSubChunkMesh(world: World, chunkX: Int, chunkZ: Int, subY: Int, atlas: TextureAtlas): MeshData {
        // The caller (WorldManager's mesh worker) already confirmed this chunk is
        // GENERATED and loaded before enqueueing the job; getChunk returning null
        // here would only mean it was unloaded in the tiny window since then, in
        // which case there's nothing left to mesh.
        val chunk = world.getChunk(ChunkPos(chunkX, chunkZ)) ?: return MeshData.EMPTY
        if (subY < 0 || subY >= WorldConfig.SUBCHUNKS_PER_CHUNK) return MeshData.EMPTY

        val sub = chunk.subChunks[subY]
        if (sub.isAllAir()) return MeshData.EMPTY
        val blocks = sub.blocks

        val builder = builders.get()
        builder.reset()

        val size = WorldConfig.CHUNK_SIZE
        val subHeight = WorldConfig.SUBCHUNK_HEIGHT
        val baseX = chunkX * size
        val baseZ = chunkZ * size
        val baseY = subY * subHeight

        for (ly in 0 until subHeight) {
            val wy = baseY + ly
            for (lz in 0 until size) {
                for (lx in 0 until size) {
                    val block = BlockType.fromId(blocks[(ly * size + lz) * size + lx])
                    if (block == BlockType.AIR) continue

                    val wx = baseX + lx
                    val wz = baseZ + lz
                    for (face in Face.ALL) {
                        val wny = wy + face.dy
                        if (wny < 0) continue // below the world floor: never visible

                        val nx = lx + face.dx
                        val ny = ly + face.dy
                        val nz = lz + face.dz
                        // Neighbors inside this same subchunk (the overwhelming majority)
                        // are read straight from the local array; only the one-cell rim
                        // falls back to chunk/world lookups.
                        val neighbor = if (nx >= 0 && nx < size && nz >= 0 && nz < size && ny >= 0 && ny < subHeight) {
                            BlockType.fromId(blocks[(ny * size + nz) * size + nx])
                        } else {
                            outsideBlockAt(world, chunk, baseX, baseZ, nx, wny, nz)
                        }
                        if (neighbor.opaque) continue
                        if (block == BlockType.WATER && neighbor == BlockType.WATER) continue
                        emitFace(builder, atlas, block, face, wx, wy, wz)
                    }
                }
            }
        }
        return builder.build()
    }

    /** Neighbor lookup for cells that fall outside this subchunk's own array: still
     *  inside this chunk (another subchunk) -> this chunk's own arrays; across the
     *  chunk edge -> World, where an unloaded neighbor reads as AIR (see World). */
    private fun outsideBlockAt(world: World, chunk: Chunk, baseX: Int, baseZ: Int, lx: Int, y: Int, lz: Int): BlockType =
        if (lx >= 0 && lx < WorldConfig.CHUNK_SIZE && lz >= 0 && lz < WorldConfig.CHUNK_SIZE) {
            chunk.getBlock(lx, y, lz)
        } else {
            world.getBlock(baseX + lx, y, baseZ + lz)
        }

    private fun emitFace(builder: MeshBuilder, atlas: TextureAtlas, block: BlockType, face: Face, x: Int, y: Int, z: Int) {
        val fx = x.toFloat(); val fy = y.toFloat(); val fz = z.toFloat()
        val uv = atlas.uvFor(block.cellFor(face))
        val shade = shadeFor(face)

        when (face) {
            Face.TOP -> builder.quad(
                fx, fy + 1, fz, fx + 1, fy + 1, fz, fx + 1, fy + 1, fz + 1, fx, fy + 1, fz + 1,
                uv.u0, uv.v0, uv.u1, uv.v1, shade, true
            )
            Face.BOTTOM -> builder.quad(
                fx, fy, fz + 1, fx + 1, fy, fz + 1, fx + 1, fy, fz, fx, fy, fz,
                uv.u0, uv.v0, uv.u1, uv.v1, shade, true
            )
            Face.NORTH -> builder.quad(
                fx + 1, fy, fz, fx, fy, fz, fx, fy + 1, fz, fx + 1, fy + 1, fz,
                uv.u0, uv.v0, uv.u1, uv.v1, shade, false
            )
            Face.SOUTH -> builder.quad(
                fx, fy, fz + 1, fx + 1, fy, fz + 1, fx + 1, fy + 1, fz + 1, fx, fy + 1, fz + 1,
                uv.u0, uv.v0, uv.u1, uv.v1, shade, false
            )
            Face.WEST -> builder.quad(
                fx, fy, fz, fx, fy, fz + 1, fx, fy + 1, fz + 1, fx, fy + 1, fz,
                uv.u0, uv.v0, uv.u1, uv.v1, shade, false
            )
            Face.EAST -> builder.quad(
                fx + 1, fy, fz + 1, fx + 1, fy, fz, fx + 1, fy + 1, fz, fx + 1, fy + 1, fz + 1,
                uv.u0, uv.v0, uv.u1, uv.v1, shade, false
            )
        }
    }

    private fun shadeFor(face: Face): Float = when (face) {
        Face.TOP -> 1.0f
        Face.BOTTOM -> 0.4f
        Face.NORTH, Face.SOUTH -> 0.75f
        Face.EAST, Face.WEST -> 0.65f
    }
}
