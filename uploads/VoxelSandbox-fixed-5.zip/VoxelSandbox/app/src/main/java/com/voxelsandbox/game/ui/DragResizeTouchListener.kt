package com.voxelsandbox.game.ui

import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View

/**
 * Attached to a HUD element only while HUD-customize mode is active (see
 * HudController.enterCustomizeMode). One finger drags the view by adjusting its
 * translationX/Y; a two-finger pinch resizes it by adjusting scaleX/Y uniformly,
 * pivoting on the view's own center (View's default pivot, so it grows/shrinks in
 * place rather than from a corner). [onAdjusted] fires once per gesture, on finger-up,
 * so the caller can persist the resulting position/scale.
 *
 * Dragging only ever reads event.rawX/rawY, which the platform defines as pointer
 * INDEX 0's screen position, and only acts while exactly one finger is down — the one
 * situation where index 0 unambiguously IS the dragging finger. Whenever a finger joins
 * or leaves, which finger sits at index 0 (and where it is) can change under us, so
 * [needsRebase] makes the next single-finger move just re-record the baseline instead
 * of diffing against a different finger's old position (which showed up as the button
 * jumping). That replaces reconstructing other pointers' raw positions from their
 * view-local coordinates, which is only exact while the view is unscaled.
 */
class DragResizeTouchListener(
    private val view: View,
    private val minScale: Float = 0.6f,
    private val maxScale: Float = 1.8f,
    private val onAdjusted: () -> Unit
) : View.OnTouchListener {
    private var lastRawX = 0f
    private var lastRawY = 0f
    private var needsRebase = true

    private val scaleDetector = ScaleGestureDetector(
        view.context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val next = (view.scaleX * detector.scaleFactor).coerceIn(minScale, maxScale)
                view.scaleX = next
                view.scaleY = next
                clampTranslationToScreen(view) // growing the view can push its edge off-screen too
                return true
            }
        }
    )

    override fun onTouch(v: View, event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastRawX = event.rawX
                lastRawY = event.rawY
                needsRebase = false
            }
            MotionEvent.ACTION_POINTER_DOWN, MotionEvent.ACTION_POINTER_UP -> needsRebase = true
            MotionEvent.ACTION_MOVE -> if (event.pointerCount == 1 && !scaleDetector.isInProgress) {
                val x = event.rawX
                val y = event.rawY
                if (needsRebase) {
                    needsRebase = false
                } else {
                    v.translationX += x - lastRawX
                    v.translationY += y - lastRawY
                    clampTranslationToScreen(v)
                }
                lastRawX = x
                lastRawY = y
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> onAdjusted()
        }
        return true
    }
}
