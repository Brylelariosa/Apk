package com.browser.app

import android.annotation.SuppressLint
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

class MainActivity : AppCompatActivity() {

    // ── Views ──────────────────────────────────────────────────────────
    private lateinit var webView: ScrollAwareWebView
    private lateinit var urlBar: LinearLayout
    private lateinit var urlInput: EditText
    private lateinit var btnBack: ImageButton
    private lateinit var btnForward: ImageButton
    private lateinit var btnRefresh: ImageButton
    private lateinit var btnSettings: ImageButton
    private lateinit var btnToggle: ImageButton

    // ── State ──────────────────────────────────────────────────────────
    private var urlBarVisible  = false
    private var toggleVisible  = true

    @Volatile private var currentHost: String? = null
    @Volatile private var adBlockEnabled  = true
    @Volatile private var dataSaverEnabled = false

    private val scrollHandler = Handler(Looper.getMainLooper())
    private val showToggleRunnable = Runnable { showToggleFab(animate = true) }

    companion object {
        private const val HOME_URL   = "https://www.google.com"
        private const val SHOW_DELAY = 2_500L

        // ── Mobile UA — makes Google/sites render properly on phone ──
        private const val MOBILE_UA =
            "Mozilla/5.0 (Linux; Android 13; Pixel 7) " +
            "AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/124.0.0.0 Mobile Safari/537.36"

        private val TINT_OFF    = Color.WHITE
        private val TINT_SHIELD = Color.parseColor("#4FC3F7")
        private val TINT_BOLT   = Color.parseColor("#FFB74D")
    }

    // ══════════════════════════════════════════════════════════════════
    // Lifecycle
    // ══════════════════════════════════════════════════════════════════

    override fun onCreate(savedInstanceState: Bundle?) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        WindowCompat.setDecorFitsSystemWindows(window, false)

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        applyImmersiveMode()
        bindViews()
        configureWebView()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) applyImmersiveMode()
    }

    // ══════════════════════════════════════════════════════════════════
    // Immersive mode
    // ══════════════════════════════════════════════════════════════════

    private fun applyImmersiveMode() {
        val ctrl = WindowInsetsControllerCompat(window, window.decorView)
        ctrl.hide(WindowInsetsCompat.Type.systemBars())
        ctrl.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    // ══════════════════════════════════════════════════════════════════
    // View binding
    // ══════════════════════════════════════════════════════════════════

    private fun bindViews() {
        webView      = findViewById(R.id.webView)
        urlBar       = findViewById(R.id.urlBar)
        urlInput     = findViewById(R.id.urlInput)
        btnBack      = findViewById(R.id.btnBack)
        btnForward   = findViewById(R.id.btnForward)
        btnRefresh   = findViewById(R.id.btnRefresh)
        btnSettings  = findViewById(R.id.btnSettings)
        btnToggle    = findViewById(R.id.btnToggleUrlBar)

        urlBar.post {
            urlBar.translationY = -urlBar.height.toFloat()
        }

        // ── Button listeners ─────────────────────────────────────────
        btnToggle.setOnClickListener   { toggleUrlBar() }
        btnBack.setOnClickListener     { if (webView.canGoBack())    webView.goBack()    }
        btnForward.setOnClickListener  { if (webView.canGoForward()) webView.goForward() }
        btnRefresh.setOnClickListener  { webView.reload() }
        btnSettings.setOnClickListener { showSettingsDialog() }

        // ── URL input: handle Go/Search/Done/Enter on any keyboard ───
        urlInput.setOnEditorActionListener { _, actionId, event ->
            val isAction = actionId == EditorInfo.IME_ACTION_GO
                        || actionId == EditorInfo.IME_ACTION_SEARCH
                        || actionId == EditorInfo.IME_ACTION_DONE
                        || actionId == EditorInfo.IME_ACTION_UNSPECIFIED
            val isEnter  = event?.keyCode == KeyEvent.KEYCODE_ENTER &&
                           event.action   == KeyEvent.ACTION_DOWN
            if (isAction || isEnter) {
                navigateTo(urlInput.text.toString())
                true
            } else false
        }

        // Extra safety: hardware Enter key
        urlInput.setOnKeyListener { _, keyCode, event ->
            if (keyCode == KeyEvent.KEYCODE_ENTER &&
                event.action == KeyEvent.ACTION_DOWN) {
                navigateTo(urlInput.text.toString())
                true
            } else false
        }

        // ── Scroll → auto-hide the floating toggle button ────────────
        webView.onScrollCallback = { dy ->
            if (!urlBarVisible) {
                if (dy > 8) {
                    hideToggleFab()
                    scrollHandler.removeCallbacks(showToggleRunnable)
                    scrollHandler.postDelayed(showToggleRunnable, SHOW_DELAY)
                } else if (dy < -8) {
                    scrollHandler.removeCallbacks(showToggleRunnable)
                    showToggleFab(animate = true)
                }
            }
        }
    }

    // ══════════════════════════════════════════════════════════════════
    // Settings dialog
    // ══════════════════════════════════════════════════════════════════

    @SuppressLint("UseSwitchCompatOrMaterialCode")
    private fun showSettingsDialog() {
        val dp = resources.displayMetrics.density

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(
                (20 * dp).toInt(), (12 * dp).toInt(),
                (20 * dp).toInt(), (8  * dp).toInt()
            )
        }

        // ── Row helper ───────────────────────────────────────────────
        fun addRow(label: String, desc: String, checked: Boolean,
                   onToggle: (Boolean) -> Unit) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding(0, (10 * dp).toInt(), 0, (10 * dp).toInt())
            }
            val textBox = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            textBox.addView(TextView(this).apply {
                text = label
                textSize = 15f
                setTextColor(Color.WHITE)
            })
            textBox.addView(TextView(this).apply {
                text = desc
                textSize = 12f
                setTextColor(Color.parseColor("#99FFFFFF"))
                setPadding(0, (2 * dp).toInt(), 0, 0)
            })
            val sw = Switch(this).apply {
                isChecked = checked
                setOnCheckedChangeListener { _, isOn -> onToggle(isOn) }
            }
            row.addView(textBox)
            row.addView(sw)
            container.addView(row)

            // divider
            container.addView(View(this).apply {
                setBackgroundColor(Color.parseColor("#33FFFFFF"))
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, 1)
            })
        }

        addRow(
            "Ad Blocker",
            "Block ads and trackers",
            adBlockEnabled
        ) { on ->
            adBlockEnabled = on
            webView.reload()
        }

        addRow(
            "Data Saver",
            "Block third-party images to save data",
            dataSaverEnabled
        ) { on ->
            dataSaverEnabled = on
            applyDataSaverSettings()
            webView.reload()
        }

        AlertDialog.Builder(this)
            .setTitle("Settings")
            .setView(container)
            .setPositiveButton("Done", null)
            .show()
            .apply {
                // Dark background to match the browser theme
                window?.setBackgroundDrawableResource(android.R.color.background_dark)
                getButton(AlertDialog.BUTTON_POSITIVE)
                    ?.setTextColor(Color.parseColor("#4FC3F7"))
            }
    }

    // ══════════════════════════════════════════════════════════════════
    // WebView configuration
    // ══════════════════════════════════════════════════════════════════

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView() {
        webView.settings.apply {
            javaScriptEnabled    = true
            domStorageEnabled    = true
            databaseEnabled      = true
            setSupportZoom(true)
            builtInZoomControls  = true
            displayZoomControls  = false
            userAgentString      = MOBILE_UA   // mobile UA → proper phone layout
            loadWithOverviewMode = true
            useWideViewPort      = true
            allowFileAccess      = false
            @Suppress("DEPRECATION")
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        }
        applyDataSaverSettings()

        webView.webViewClient = object : WebViewClient() {

            override fun onPageStarted(view: WebView, url: String?,
                                       favicon: android.graphics.Bitmap?) {
                currentHost = url?.let {
                    try { java.net.URI(it).host?.removePrefix("www.") }
                    catch (_: Exception) { null }
                }
                urlInput.setText(url ?: "")
                syncNavButtons()
            }

            override fun onPageFinished(view: WebView, url: String?) {
                urlInput.setText(url ?: "")
                syncNavButtons()
            }

            override fun shouldOverrideUrlLoading(
                view: WebView, request: WebResourceRequest
            ): Boolean = false

            override fun shouldInterceptRequest(
                view: WebView, request: WebResourceRequest
            ): android.webkit.WebResourceResponse? {
                if (adBlockEnabled && AdBlocker.shouldBlock(request, currentHost))
                    return AdBlocker.emptyResponse()
                if (dataSaverEnabled && AdBlocker.shouldBlockForDataSaver(request, currentHost))
                    return AdBlocker.emptyResponse()
                return null
            }
        }

        webView.webChromeClient = WebChromeClient()
        webView.loadUrl(HOME_URL)
    }

    private fun applyDataSaverSettings() {
        webView.settings.cacheMode = if (dataSaverEnabled)
            WebSettings.LOAD_CACHE_ELSE_NETWORK
        else
            WebSettings.LOAD_DEFAULT
    }

    private fun syncNavButtons() {
        btnBack.alpha    = if (webView.canGoBack())    1f else 0.32f
        btnForward.alpha = if (webView.canGoForward()) 1f else 0.32f
    }

    // ══════════════════════════════════════════════════════════════════
    // URL bar show / hide
    // ══════════════════════════════════════════════════════════════════

    private fun toggleUrlBar() {
        if (urlBarVisible) hideUrlBar() else showUrlBar()
    }

    private fun showUrlBar() {
        if (urlBarVisible) return
        urlBarVisible = true
        showToggleFab(animate = false)
        urlBar.visibility = View.VISIBLE
        urlBar.animate().translationY(0f).setDuration(270).start()
        urlInput.post { urlInput.requestFocus() }
    }

    private fun hideUrlBar() {
        if (!urlBarVisible) return
        urlBarVisible = false
        dismissKeyboard()
        urlBar.animate()
            .translationY(-urlBar.height.toFloat())
            .setDuration(220)
            .withEndAction { urlBar.visibility = View.INVISIBLE }
            .start()
    }

    // ══════════════════════════════════════════════════════════════════
    // Floating toggle-button show / hide
    // ══════════════════════════════════════════════════════════════════

    private fun showToggleFab(animate: Boolean) {
        if (toggleVisible) return
        toggleVisible = true
        if (animate) {
            btnToggle.animate().alpha(1f).translationY(0f).setDuration(220).start()
        } else {
            btnToggle.alpha        = 1f
            btnToggle.translationY = 0f
        }
    }

    private fun hideToggleFab() {
        if (!toggleVisible) return
        toggleVisible = false
        btnToggle.animate()
            .alpha(0f)
            .translationY(28f * resources.displayMetrics.density)
            .setDuration(200)
            .start()
    }

    // ══════════════════════════════════════════════════════════════════
    // Navigation
    // ══════════════════════════════════════════════════════════════════

    private fun navigateTo(raw: String) {
        val s = raw.trim()
        if (s.isEmpty()) return
        val url = when {
            s.startsWith("http://") || s.startsWith("https://") -> s
            s.contains(".") && !s.contains(" ")                 -> "https://$s"
            else -> "https://www.google.com/search?q=${android.net.Uri.encode(s)}"
        }
        webView.loadUrl(url)
        hideUrlBar()
    }

    private fun dismissKeyboard() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(urlInput.windowToken, 0)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            urlBarVisible       -> hideUrlBar()
            webView.canGoBack() -> webView.goBack()
            else                -> @Suppress("DEPRECATION") super.onBackPressed()
        }
    }
}
