package com.browser.app

import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream

/**
 * Lightweight host-based ad / tracker blocker.
 *
 * shouldBlock()           – used for the ad-blocker feature
 * shouldBlockForDataSaver() – blocks third-party media/fonts to cut data usage
 *
 * Both functions are called on a WebView background thread; all state is
 * read-only after init so no synchronisation is needed.
 */
object AdBlocker {

    // ── Ad / tracker domain blocklist ────────────────────────────────
    private val BLOCKED_HOSTS: Set<String> = hashSetOf(
        // Google advertising
        "googleadservices.com", "googlesyndication.com", "googletagservices.com",
        "pagead2.googlesyndication.com", "adservice.google.com",
        "doubleclick.net", "ad.doubleclick.net", "stats.g.doubleclick.net",
        // Google Analytics / Tag Manager (tracking, not content)
        "google-analytics.com", "ssl.google-analytics.com",
        "googletagmanager.com", "www.googletagmanager.com",
        // Facebook / Meta
        "connect.facebook.net", "an.facebook.com",
        "pixel.facebook.com", "www.facebook.com",          // pixel endpoint
        // Amazon Ads
        "amazon-adsystem.com", "aax.amazon-adsystem.com",
        "fls-na.amazon-adsystem.com",
        // AppNexus / Xandr
        "adnxs.com", "ib.adnxs.com",
        // Rubicon / Magnite
        "rubiconproject.com", "fastlane.rubiconproject.com",
        // OpenX
        "openx.net", "openx.com", "us-u.openx.net",
        // PubMatic
        "pubmatic.com", "ads.pubmatic.com",
        // Criteo
        "criteo.com", "criteo.net", "static.criteo.net",
        // Index Exchange
        "casalemedia.com", "sas.casalemedia.com",
        // The Trade Desk
        "adsrvr.org",
        // MediaMath
        "turn.com",
        // Outbrain / Taboola (native ad widgets)
        "taboola.com", "cdn.taboola.com", "trc.taboola.com",
        "outbrain.com", "widgets.outbrain.com",
        "revcontent.com",
        // Advertising.com / AOL
        "advertising.com",
        // Yieldmo
        "yieldmo.com",
        // Sharethrough
        "sharethrough.com",
        // TripleLift
        "triplelift.com",
        // Conversant
        "conversantmedia.com",
        // Lotame
        "crwdcntrl.net",
        // ScoreCard Research
        "scorecardresearch.com",
        // Quantcast
        "quantserve.com",
        // Nielsen
        "imrworldwide.com",
        // Moat
        "moat.com",
        // Integral Ad Science
        "adsafeprotected.com",
        // DoubleVerify
        "doubleverify.com",
        // TrafficJunky / adult ad networks
        "trafficjunky.net", "trafficjunky.com",
        "exoclick.com",
        "juicyads.com",
        "adsterra.com",
        "propellerads.com",
        // Analytics / session recorders (privacy trackers)
        "mixpanel.com", "api.mixpanel.com",
        "amplitude.com", "api.amplitude.com",
        "hotjar.com", "static.hotjar.com",
        "segment.io", "api.segment.io",
        "segment.com", "cdn.segment.com",
        "heap.io", "heapanalytics.com",
        "fullstory.com", "edge.fullstory.com",
        "mouseflow.com",
        "logrocket.com",
        "rlcdn.com",
        // Chartbeat
        "chartbeat.com", "static.chartbeat.com",
        // ComScore
        "comscore.com",
        // Parse.ly
        "parsely.com",
        // Disqus tracking
        "disqus.com",
        // Twitter/X advertising
        "ads.twitter.com", "analytics.twitter.com",
        "p.twitter.com",
        // LinkedIn Insight Tag
        "snap.licdn.com", "platform.linkedin.com",
        // Pinterest ads
        "log.pinterest.com", "ads.pinterest.com",
        // TikTok pixel
        "analytics.tiktok.com",
    )

    private val IMAGE_EXT  = setOf(".jpg", ".jpeg", ".png", ".gif", ".webp",
                                    ".avif", ".svg", ".bmp", ".ico")
    private val FONT_EXT   = setOf(".woff", ".woff2", ".ttf", ".otf", ".eot")
    private val VIDEO_EXT  = setOf(".mp4", ".webm", ".ogg", ".avi", ".mov",
                                    ".m3u8", ".ts")

    private val EMPTY = WebResourceResponse(
        "text/plain", "utf-8", ByteArrayInputStream(ByteArray(0))
    )

    // ── Public API ────────────────────────────────────────────────────

    /**
     * Returns true if the request should be blocked by the ad / tracker blocker.
     * Never blocks the main page host itself.
     */
    fun shouldBlock(request: WebResourceRequest, pageHost: String?): Boolean {
        val host = request.url?.host?.removePrefix("www.") ?: return false
        val page = pageHost?.removePrefix("www.") ?: ""

        // Never block the page's own origin
        if (page.isNotEmpty() && (host == page || host.endsWith(".$page"))) return false

        return BLOCKED_HOSTS.any { blocked ->
            host == blocked || host.endsWith(".$blocked")
        }
    }

    /**
     * Returns true if the request should be blocked in data-saver mode.
     * Blocks third-party images, fonts, and video — keeps same-domain assets.
     */
    fun shouldBlockForDataSaver(request: WebResourceRequest, pageHost: String?): Boolean {
        val url  = request.url ?: return false
        val host = url.host?.removePrefix("www.") ?: return false
        val page = pageHost?.removePrefix("www.") ?: return false

        if (page.isEmpty()) return false
        // Keep same-origin resources
        if (host == page || host.endsWith(".$page") || page.endsWith(".$host")) return false

        val path = url.path?.lowercase() ?: ""
        return IMAGE_EXT.any { path.endsWith(it) }
            || FONT_EXT.any  { path.endsWith(it) }
            || VIDEO_EXT.any { path.endsWith(it) }
    }

    fun emptyResponse(): WebResourceResponse = EMPTY
}
