package com.game.topdown;

import android.os.Bundle;
import android.view.WindowManager;
import androidx.appcompat.app.AppCompatActivity;

public class GameActivity extends AppCompatActivity {
    private GameView gameView;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                           | WindowManager.LayoutParams.FLAG_FULLSCREEN);
        String name   = getIntent().getStringExtra("name");
        boolean host  = getIntent().getBooleanExtra("isHost", false);
        String hostIp = getIntent().getStringExtra("hostIp");
        gameView = new GameView(this, name, host, hostIp);
        setContentView(gameView);
    }

    @Override protected void onPause()   { super.onPause();   if(gameView!=null) gameView.pause(); }
    @Override protected void onResume()  { super.onResume();  if(gameView!=null) gameView.resume(); }
    @Override protected void onDestroy() { super.onDestroy(); if(gameView!=null) gameView.stopGame(); }
    @Override public void onBackPressed(){ if(gameView!=null) gameView.stopGame(); super.onBackPressed(); }
}
