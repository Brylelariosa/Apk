package com.game.topdown;

public class Bullet {
    public int   id, ownerId;
    public float x, y, dx, dy, damage;
    public float spawnX, spawnY, range;   // for per-gun range culling
    public long  spawnTime;

    public Bullet(float x, float y, float dx, float dy,
                  int owner, float dmg, int id, float range) {
        this.x=x; this.y=y; this.dx=dx; this.dy=dy;
        this.ownerId=owner; this.damage=dmg; this.id=id;
        this.spawnX=x; this.spawnY=y; this.range=range;
        this.spawnTime=System.currentTimeMillis();
    }
}
