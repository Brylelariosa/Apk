package com.screenshottile

import android.accessibilityservice.AccessibilityService
import android.app.Activity
import android.os.Bundle

/**
 * Invisible zero-UI activity.
 * startActivityAndCollapse() collapses the QS panel before this runs.
 * onWindowFocusChanged(hasFocus=true) is the precise system signal that the
 * panel animation is complete and the screen is clean — no fixed delay needed.
 */
class TriggerActivity : Activity() {

    // Guard against double-fire (onWindowFocusChanged can be called multiple times)
    private var screenshotTaken = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (ScreenshotAccessibilityService.instance == null) { finish(); return }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && !screenshotTaken) {
            screenshotTaken = true
            ScreenshotAccessibilityService.instance
                ?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)
            // performGlobalAction() is async — the system still needs time to capture
            // and queue the save. Calling finish() immediately tears down the window
            // mid-pipeline, which causes the preview to flash and the file to not save.
            // 300 ms is enough slack without being perceptible to the user.
            window.decorView.postDelayed({ finish() }, 300L)
        }
    }
}
