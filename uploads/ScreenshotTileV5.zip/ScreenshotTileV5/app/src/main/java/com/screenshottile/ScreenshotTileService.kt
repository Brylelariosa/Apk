package com.screenshottile

import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

class ScreenshotTileService : TileService() {

    private var triggerPendingIntent: PendingIntent? = null

    override fun onStartListening() {
        super.onStartListening()

        val newState = if (ScreenshotAccessibilityService.instance != null)
            Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        qsTile?.apply {
            if (state != newState) {
                state = newState
                updateTile()
            }
        }

        // Pre-warm the PendingIntent while the panel is still opening.
        // getActivity() is a Binder IPC — doing it here moves that cost
        // off the tap critical path so every tap (not just after the first)
        // hits the cache. The panel-open animation gives us ~300 ms of slack.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE
                && triggerPendingIntent == null) {
            triggerPendingIntent = PendingIntent.getActivity(
                this, 0,
                Intent(this, TriggerActivity::class.java).withLaunchFlags(),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }
    }

    override fun onTileRemoved() {
        super.onTileRemoved()
        triggerPendingIntent = null   // release; will be rebuilt if tile is re-added
    }

    override fun onClick() {
        super.onClick()
        if (ScreenshotAccessibilityService.instance == null) launchSettings()
        else launchTrigger()
    }

    private fun launchTrigger() {
        val intent = Intent(this, TriggerActivity::class.java).withLaunchFlags()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            val pi = triggerPendingIntent ?: PendingIntent.getActivity(
                this, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            ).also { triggerPendingIntent = it }
            startActivityAndCollapse(pi)
        } else {
            @Suppress("DEPRECATION")
            startActivityAndCollapse(intent)
        }
    }

    private fun launchSettings() {
        // Don't use withLaunchFlags() here — FLAG_ACTIVITY_CLEAR_TASK on an external
        // Settings intent would wipe the Settings app's back stack.
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startActivityAndCollapse(
                PendingIntent.getActivity(
                    this, 1, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
            )
        } else {
            @Suppress("DEPRECATION")
            startActivityAndCollapse(intent)
        }
    }

    private fun Intent.withLaunchFlags(): Intent = apply {
        addFlags(
            Intent.FLAG_ACTIVITY_NEW_TASK or
            Intent.FLAG_ACTIVITY_CLEAR_TASK or
            Intent.FLAG_ACTIVITY_NO_ANIMATION or
            Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS
        )
    }
}
