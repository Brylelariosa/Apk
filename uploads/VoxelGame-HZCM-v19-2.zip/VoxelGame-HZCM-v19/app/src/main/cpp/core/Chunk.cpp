// ============================================================================
// HZCM v4 — Chunk.cpp
// ============================================================================
#include "Chunk.h"
#include <android/log.h>
#include <cstring>
#include <cmath>
#include <algorithm>

#define TAG "HZCMChunk"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)

// ── Constructor ────────────────────────────────────────────────────────────────
Chunk::Chunk(int cx, int cz) : cx(cx), cz(cz) {
    memset(blocks, BLOCK_AIR, sizeof(blocks));
    for (int i = 0; i < CLUSTER_STACK; ++i) {
        clusterState[i].store(ClusterState::EMPTY, std::memory_order_relaxed);
        clusterGPUOffset[i] = MEGA_INVALID;
        clusterFaceCount[i] = 0;
        clusterDirtyGen[i]  = 0;
    }
}

// ── Terrain generation ─────────────────────────────────────────────────────────
//
// v18 layered terrain system:
//
//   Layer 1 — Continental base (fbm, very low freq ~0.004)
//     Broad hills and lowlands.  Drives sea-level / beach / plains splits.
//
//   Layer 2 — Mountain ridges (fbmRidged × continental mask, freq ~0.013)
//     Ridged noise × clamped continental value adds dramatic peaks ONLY in
//     already-elevated regions → separate mountain ranges, not random spikes.
//
//   Layer 3 — Detail (fbm, freq ~0.055)
//     Fine surface texture.  ±4 blocks.
//
// Biome surface block driven by:
//   • altitude (beach near sea level, stone/snow on peaks)
//   • temperature noise (large-scale, 0.005)
//
// Tree canopy uses an ellipsoidal 5-layer profile with probabilistic border
// thinning for an organic silhouette instead of a rectangular box.
//
void Chunk::generate(const Noise& noise) {

    // ── Tuning constants ──────────────────────────────────────────────────────
    static constexpr int   SEA_LEVEL    = 24;
    static constexpr float WARP_SCALE   = 80.0f;   // domain warp magnitude (blocks)
    static constexpr float WARP_FREQ    = 0.0015f;  // warp feature size
    static constexpr int   TREE_BORDER  = 3;        // inset from chunk edge for trunks

    for (int lz = 0; lz < CHUNK_D; ++lz) {
        for (int lx = 0; lx < CHUNK_W; ++lx) {
            const float wx = (float)(cx * CHUNK_W + lx);
            const float wz = (float)(cz * CHUNK_D + lz);

            // ── Domain warp — offset coordinates before sampling ───────────
            // Two independent fbm samples warp X and Z separately, bending
            // mountain chains, coastlines and biome borders into organic curves
            // that break the grid-aligned appearance of axis-aligned noise.
            float wox = noise.fbm(wx * WARP_FREQ + 3.7f,
                                  wz * WARP_FREQ + 1.3f, 2, 2.0f, 0.5f);
            float woz = noise.fbm(wx * WARP_FREQ + 8.1f,
                                  wz * WARP_FREQ + 5.9f, 2, 2.0f, 0.5f);
            float swx = wx + wox * WARP_SCALE;
            float swz = wz + woz * WARP_SCALE;

            // A second, coarser warp layer applied to the mountain pass only
            // gives peaks an independent curl from the broad landscape.
            float pwox = noise.fbm(wx * WARP_FREQ * 1.8f + 15.3f,
                                   wz * WARP_FREQ * 1.8f + 22.7f, 2, 2.0f, 0.5f);
            float pwoz = noise.fbm(wx * WARP_FREQ * 1.8f + 44.1f,
                                   wz * WARP_FREQ * 1.8f + 31.5f, 2, 2.0f, 0.5f);
            float pwx = wx + pwox * (WARP_SCALE * 0.6f);
            float pwz = wz + pwoz * (WARP_SCALE * 0.6f);

            // ── Layer 1: Continentalness (warped) ─────────────────────────
            // Low-frequency fbm controls the ocean/continent split.
            // Negative values → below-sea terrain; positive → dry land.
            float contN = noise.fbm(swx * 0.0035f,
                                    swz * 0.0035f, 4, 2.0f, 0.5f);
            float contH = 26.0f + contN * 14.0f;   // [12, 40] blocks

            // ── Layer 2: Erosion (warped, separate offset) ─────────────────
            // Controls how worn-down the landscape is.
            // High erosion (positive) → flat plains/valleys.
            // Low erosion (negative)  → sharp ridges, cliffs, rugged peaks.
            float erosN   = noise.fbm(swx * 0.006f + 200.0f,
                                      swz * 0.006f + 200.0f, 3, 2.0f, 0.55f);
            float erosion = (erosN + 1.0f) * 0.5f;  // remap [-1,1] → [0,1]

            // ── Layer 3: Peaks & Valleys (doubly warped ridged noise) ──────
            // Ridged FBM produces sharp mountain ridgelines.
            // Squaring the mountain mask concentrates peaks in elevated areas.
            float ridgeN = noise.fbmRidged(pwx * 0.012f + 50.0f,
                                           pwz * 0.012f + 50.0f, 4, 2.0f, 0.5f);

            // Mountain mask: ridge height only grows where the continent is
            // already elevated and erosion is low (rugged region).
            float mountMask = std::max(0.0f, contN) * (1.0f - erosion * 0.75f);
            mountMask = mountMask * mountMask;   // square → only strong peaks

            // Power curve on ridged noise sharpens peak tips vs broad bases.
            float peakH = powf(ridgeN, 2.2f) * mountMask * 26.0f;

            // ── Layer 4: Valley carving ────────────────────────────────────
            // High-erosion zones are pushed downward, carving valleys and
            // river basins between mountain ranges.
            float valleyCarve = std::max(0.0f, erosion - 0.55f) * 12.0f;

            // ── Layer 5: Fine surface detail ───────────────────────────────
            float detailN = noise.fbm(wx * 0.06f + 20.0f,
                                      wz * 0.06f + 20.0f, 3, 2.0f, 0.45f);
            float detailH = detailN * 3.0f;

            // ── Combine all layers ─────────────────────────────────────────
            int h = (int)(contH + peakH - valleyCarve + detailH);
            h = std::max(2, std::min(CHUNK_H - 4, h));

            // ── Climate sampling ───────────────────────────────────────────
            // Temperature and humidity are sampled at scales independent of
            // terrain noise to decouple climate from topography (cold valleys
            // and warm peaks are possible, as in real geography).
            float tempN  = noise.noise2D(wx * 0.004f + 500.0f,
                                         wz * 0.004f + 500.0f);
            float humidN = noise.noise2D(wx * 0.005f + 900.0f,
                                         wz * 0.005f + 900.0f);

            // ── Biome classification ───────────────────────────────────────
            bool isOcean      = (h <  SEA_LEVEL - 2);
            bool isBeach      = (h >= SEA_LEVEL - 2) && (h <= SEA_LEVEL + 2);
            bool isMidMount   = (h >= 40);
            bool isHighPeak   = (h >= 50);
            // Volcanic: extreme continental uplift combined with a sharp ridge
            bool isVolcanic   = (contN > 0.55f && ridgeN > 0.72f && mountMask > 0.35f);
            // Glacier: high peaks in cold climates
            bool isGlacier    = (isHighPeak && tempN > 0.45f);

            uint8_t surfBlock;
            if (isGlacier) {
                surfBlock = BLOCK_ICE;
            } else if (isVolcanic) {
                surfBlock = BLOCK_BASALT;
            } else if (isHighPeak) {
                // Above snow line: snow in cold/temperate, bare cobble in warm
                surfBlock = (tempN > -0.05f) ? BLOCK_SNOW : BLOCK_COBBLE;
            } else if (isMidMount) {
                // Mid-altitude: stone default; snow only in cold; cobble in
                // eroded (rugged) areas
                if (tempN > 0.30f)        surfBlock = BLOCK_SNOW;
                else if (erosion < 0.4f)  surfBlock = BLOCK_COBBLE;
                else                      surfBlock = BLOCK_STONE;
            } else if (isBeach) {
                // Beach colour tied to temperature: hot = red sand, cold = sand
                surfBlock = (tempN < -0.30f) ? BLOCK_RED_SAND : BLOCK_SAND;
            } else if (tempN > 0.42f) {
                // Cold biome flat land
                surfBlock = BLOCK_SNOW;
            } else if (tempN < -0.38f && humidN < -0.05f) {
                // Hot dry biome: badlands vs desert
                surfBlock = (humidN < -0.45f) ? BLOCK_RED_SAND : BLOCK_SAND;
            } else {
                // Temperate: grass everywhere else
                surfBlock = BLOCK_GRASS;
            }

            // ── Block fill ─────────────────────────────────────────────────
            bool mountainZone = (h >= 40);
            bool sandSurf     = (surfBlock == BLOCK_SAND || surfBlock == BLOCK_RED_SAND);
            // Clay appears in humid shores just above/below sea level
            bool hasClay      = (humidN > 0.28f
                                 && h >= SEA_LEVEL - 2
                                 && h <= SEA_LEVEL + 4);

            for (int ly = 0; ly < CHUNK_H; ++ly) {
                uint8_t bt = BLOCK_AIR;

                if (ly == 0) {
                    bt = BLOCK_STONE;
                } else if (ly <= h - 4) {
                    bt = isVolcanic ? BLOCK_BASALT : BLOCK_STONE;
                } else if (ly <= h - 1) {
                    // Sub-surface fill: matches surface material theme
                    if (sandSurf)          bt = surfBlock;          // sand/red-sand column
                    else if (hasClay)      bt = BLOCK_CLAY;
                    else if (mountainZone) bt = BLOCK_STONE;
                    else                   bt = BLOCK_DIRT;
                } else if (ly == h) {
                    bt = surfBlock;
                } else if (ly <= SEA_LEVEL && h < SEA_LEVEL) {
                    // Water or ice depending on climate
                    bt = (isGlacier || (h < SEA_LEVEL - 5 && tempN > 0.35f))
                            ? BLOCK_ICE : BLOCK_WATER;
                }
                setBlock(lx, ly, lz, bt);
            }

            // ── Trees (grass biome; trunk must be TREE_BORDER from edge) ──
            // Inset guard prevents canopy leaves from being clipped at chunk
            // borders, which left ugly flat-edged tree faces on the seam.
            if (surfBlock == BLOCK_GRASS
                && h < CHUNK_H - 10
                && lx >= TREE_BORDER && lx < CHUNK_W - TREE_BORDER
                && lz >= TREE_BORDER && lz < CHUNK_D - TREE_BORDER)
            {
                unsigned seed = (unsigned)(cx * 7919 + lx * 131 + cz * 4001 + lz * 37);
                seed = seed * 1664525u + 1013904223u;

                // Tree density scales with humidity: wet biomes are denser.
                unsigned treeThresh = (humidN > 0.25f) ? 20u : 10u;

                if ((seed & 0xFF) < treeThresh) {
                    int treeH = 4 + (int)((seed >> 8) & 3);  // 4–7 blocks

                    // Trunk
                    for (int ty = h + 1; ty <= h + treeH && ty < CHUNK_H; ++ty)
                        setBlock(lx, ty, lz, BLOCK_WOOD);

                    // 5-layer ellipsoidal canopy with probabilistic border thinning
                    static const float LEAF_RSQ[5] = {
                        1.5f,  // dy=-2  lower skirt
                        5.0f,  // dy=-1  lower canopy
                        5.5f,  // dy= 0  widest band
                        4.5f,  // dy=+1  upper canopy
                        1.5f,  // dy=+2  cap
                    };
                    int top = h + treeH;
                    for (int dyIdx = 0; dyIdx < 5; ++dyIdx) {
                        int ly2 = top + (dyIdx - 2);
                        if (ly2 < 0 || ly2 >= CHUNK_H) continue;
                        float maxRsq = LEAF_RSQ[dyIdx];
                        int   maxR   = (int)sqrtf(maxRsq) + 1;
                        for (int dx = -maxR; dx <= maxR; ++dx) {
                            for (int dz2 = -maxR; dz2 <= maxR; ++dz2) {
                                float distSq = (float)(dx * dx + dz2 * dz2);
                                if (distSq > maxRsq + 0.5f) continue;
                                if (distSq > maxRsq - 0.5f) {
                                    unsigned ls = seed
                                        ^ (unsigned)(dx * 37 + dz2 * 53 + (dyIdx - 2) * 97);
                                    ls = ls * 1664525u + 1013904223u;
                                    if ((ls & 3) == 0) continue;
                                }
                                int lx2 = lx + dx, lz3 = lz + dz2;
                                if (lx2 >= 0 && lx2 < CHUNK_W &&
                                    lz3 >= 0 && lz3 < CHUNK_D)
                                    if (getBlock(lx2, ly2, lz3) == BLOCK_AIR)
                                        setBlock(lx2, ly2, lz3, BLOCK_LEAVES);
                            }
                        }
                    }
                }
            }

            // ── Cactus (hot dry biomes) ────────────────────────────────────
            // Single-column with 25% chance of a 3rd block; never at chunk edge
            // (cactus needs air on all sides to be valid, but we skip that check
            // here and let the mesher handle the face culling naturally).
            if ((surfBlock == BLOCK_SAND || surfBlock == BLOCK_RED_SAND)
                && h < CHUNK_H - 5
                && lx >= 1 && lx < CHUNK_W - 1
                && lz >= 1 && lz < CHUNK_D - 1)
            {
                unsigned cs = (unsigned)(cx * 3571 + lx * 211 + cz * 6131 + lz * 103);
                cs = cs * 1664525u + 1013904223u;
                if ((cs & 0xFF) < 5u) {  // ~2% chance
                    int cH = 2 + (int)((cs >> 8) & 1);  // 2–3 blocks
                    for (int ty = h + 1; ty <= h + cH && ty < CHUNK_H; ++ty)
                        setBlock(lx, ty, lz, BLOCK_CACTUS);
                }
            }

            // ── Gravel pockets (unchanged) ─────────────────────────────────
            {
                unsigned seed2 = (unsigned)(cx * 1231 + lx * 53 + cz * 9973 + lz * 73);
                seed2 = seed2 * 1664525u + 1013904223u;
                if ((seed2 & 0xFF) < 20u) {
                    int gy = 2 + (int)((seed2 >> 8) & 15);
                    if (gy < h - 4) setBlock(lx, gy, lz, BLOCK_GRAVEL);
                }
            }
        }
    }

    generated.store(true, std::memory_order_release);
    for (int ci = 0; ci < CLUSTER_STACK; ++ci) {
        clusterState[ci].store(ClusterState::DIRTY, std::memory_order_release);
        clusterDirtyGen[ci]++;
    }
}

// ── Extract 16³ voxels for cluster ci ─────────────────────────────────────────
void Chunk::extractClusterVoxels(int ci, uint8_t out[CL_VOLUME]) const {
    const int baseY = ci * CL_SIZE;
    for (int z = 0; z < CL_SIZE; ++z) {
        for (int y = 0; y < CL_SIZE; ++y) {
            const uint8_t* src = &blocks[0 + CHUNK_W * ((baseY + y) + CHUNK_H * z)];
            uint8_t*       dst = &out[0 + CL_SIZE * (y + CL_SIZE * z)];
            memcpy(dst, src, CL_SIZE);
        }
    }
}

// ── Build cluster mesh ─────────────────────────────────────────────────────────
void Chunk::buildClusterMesh(int ci,
                               const Chunk* nxC, const Chunk* pxC,
                               const Chunk* nzC, const Chunk* pzC)
{
    static thread_local uint8_t selfVox[CL_VOLUME];
    static thread_local uint8_t nxVox[CL_VOLUME], pxVox[CL_VOLUME];
    static thread_local uint8_t nyVox[CL_VOLUME], pyVox[CL_VOLUME];
    static thread_local uint8_t nzVox[CL_VOLUME], pzVox[CL_VOLUME];

    extractClusterVoxels(ci, selfVox);

    NeighbourVoxels nb;
    if (nxC && nxC->generated.load(std::memory_order_acquire))
        { nxC->extractClusterVoxels(ci, nxVox); nb.nx = nxVox; }
    if (pxC && pxC->generated.load(std::memory_order_acquire))
        { pxC->extractClusterVoxels(ci, pxVox); nb.px = pxVox; }
    if (nzC && nzC->generated.load(std::memory_order_acquire))
        { nzC->extractClusterVoxels(ci, nzVox); nb.nz = nzVox; }
    if (pzC && pzC->generated.load(std::memory_order_acquire))
        { pzC->extractClusterVoxels(ci, pzVox); nb.pz = pzVox; }
    if (ci > 0)               { extractClusterVoxels(ci - 1, nyVox); nb.ny = nyVox; }
    if (ci < CLUSTER_STACK-1) { extractClusterVoxels(ci + 1, pyVox); nb.py = pyVox; }

    std::vector<PackedFace> localFaces;
    ClusterMesher::buildCluster(selfVox, nb, localFaces);

    {
        std::lock_guard<std::mutex> lock(clusterMutex[ci]);
        clusterFaces[ci] = std::move(localFaces);
    }
    clusterState[ci].store(ClusterState::MESHED, std::memory_order_release);
}

// ── AABB ───────────────────────────────────────────────────────────────────────
void Chunk::getAABB(float& mnX, float& mnY, float& mnZ,
                     float& mxX, float& mxY, float& mxZ) const {
    mnX = (float)(cx * CHUNK_W); mnY = 0.f;            mnZ = (float)(cz * CHUNK_D);
    mxX = mnX + CHUNK_W;         mxY = (float)CHUNK_H; mxZ = mnZ + CHUNK_D;
}
