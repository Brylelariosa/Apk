package com.photopuzzle.game.puzzle.render3d

/** GLSL ES 1.00 sources. One program each for the table, the pieces, and flat soft decals (shadows, the turn ring). */
internal object PuzzleShaders {

    /**
     * The table is one quad covering the whole screen. The fragment shader works out which
     * point of the table lies under each pixel (see TableCamera.screenToPlane), so there is no
     * vast ground polygon to clip and its texture can never smear or swim.
     */
    const val TABLE_VERTEX = """
attribute vec2 aCorner;
varying vec2 vNdc;
void main() {
    vNdc = aCorner;
    gl_Position = vec4(aCorner, 0.0, 1.0);
}
"""

    /**
     * One fragment shader paints every tabletop; [uKind] picks the pattern (see [TableStyles]) and
     * the colours come in as uniforms. Patterns are made from a little hashed noise rather than
     * textures, and fade out where they are too fine for the screen to resolve (a fine weave seen
     * from far away would only shimmer), which [uPixelUnit] measures.
     */
    const val TABLE_FRAGMENT = """
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
uniform sampler2D uWood;
uniform mat3 uScreenToTable;
uniform float uTileSize;
uniform float uDetail;
uniform float uKind;
uniform vec3 uColorA;
uniform vec3 uColorB;
uniform vec3 uColorC;
uniform float uExposure;
uniform float uSheen;
uniform float uPixelUnit;
varying vec2 vNdc;

float hash12(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

float vnoise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash12(i), hash12(i + vec2(1.0, 0.0)), f.x),
               mix(hash12(i + vec2(0.0, 1.0)), hash12(i + vec2(1.0, 1.0)), f.x), f.y);
}

float fbm(vec2 p) {
    float v = 0.0;
    float a = 0.5;
    for (int i = 0; i < 4; i++) {
        v += a * vnoise(p);
        p = p * 2.03 + vec2(17.3, 9.1);
        a *= 0.5;
    }
    return v;
}

// 1 where a pattern this many table units across is still resolved on screen, fading to 0 where
// it would only shimmer.
float resolved(float size) {
    return smoothstep(1.6, 3.0, size / uPixelUnit);
}

// The photographed wood under a table point.
vec3 woodAt(vec2 pos) {
    vec2 uv = pos / uTileSize;
    vec3 wood = texture2D(uWood, uv).rgb;
    // Zoomed in close, the texture alone turns soft. Finer grain taken from the same picture
    // (just its small detail, not its large shapes) is laid over it.
    if (uDetail > 0.01) {
        vec2 uv2 = uv * 4.7 + vec2(0.37, 0.61);
        float fine = texture2D(uWood, uv2).g - texture2D(uWood, uv2, 3.0).g;
        wood *= 1.0 + fine * 2.4 * uDetail;
    }
    return wood;
}

void main() {
    // The point of the table under this pixel, perspective and all.
    vec3 h = uScreenToTable * vec3(vNdc, 1.0);
    vec2 pos = h.xy / h.z;
    vec3 base;

    if (uKind < 0.5) {
        // Walnut: the photographed wood as it is.
        base = woodAt(pos);
    } else if (uKind < 1.5) {
        // The other woods: the same grain, repainted between a dark and a light tone.
        vec3 wood = woodAt(pos);
        float lum = dot(wood, vec3(0.299, 0.587, 0.114));
        base = mix(uColorA, uColorB, clamp((lum - 0.13) * 4.0, 0.0, 1.0));
    } else if (uKind < 2.5) {
        // Felt: soft mottling and a faint nap.
        float mottle = vnoise(pos / 38.0);
        float nap = vnoise(pos / 3.2) * resolved(3.2);
        base = uColorA * (0.88 + 0.16 * mottle + 0.07 * nap);
    } else if (uKind < 3.5) {
        // Marble: soft clouds, a few bold veins and some hairlines, all bent by the same noise.
        vec2 p = pos / 420.0;
        float warp = fbm(p * 2.4 + 3.7);
        float cloud = fbm(p * 4.5 + 11.0);
        float band = sin((p.x * 1.1 + p.y * 0.8) * 7.0 + warp * 6.5);
        float vein = pow(max(1.0 - abs(band), 0.0), 14.0);
        float hair = pow(max(1.0 - abs(sin((p.x * 0.7 - p.y * 1.3) * 11.0 + warp * 9.0)), 0.0), 38.0) * resolved(3.0);
        base = mix(uColorA, uColorB, smoothstep(0.30, 0.85, cloud) * 0.75);
        base = mix(base, uColorC, vein * 0.55 + hair * 0.30);
    } else if (uKind < 4.5) {
        // Slate: mottled stone with fine speckle.
        float n = fbm(pos / 70.0);
        float speck = vnoise(pos / 2.6) * resolved(2.6);
        base = mix(uColorA, uColorB, n) * (0.92 + 0.16 * speck);
    } else if (uKind < 5.5) {
        // Linen: a plain weave (each thread over one, under one) with uneven slubs in the yarn.
        float pitch = 6.0;
        vec2 g = pos / pitch;
        vec2 cell = floor(g);
        vec2 f = fract(g);
        float over = mod(cell.x + cell.y, 2.0);
        float warpThread = 0.5 + 0.5 * cos((f.x - 0.5) * 6.2831853);
        float weftThread = 0.5 + 0.5 * cos((f.y - 0.5) * 6.2831853);
        float thread = mix(warpThread, weftThread, over);
        float slub = vnoise(vec2(pos.x / 90.0, pos.y / 3.5)) * 0.5 + vnoise(vec2(pos.x / 3.5, pos.y / 90.0)) * 0.5;
        float weave = mix(0.5, thread, resolved(pitch));
        base = mix(uColorA, uColorB, 0.35 + 0.45 * weave) * (0.9 + 0.2 * slub);
    } else {
        // Gingham: stripes of two strengths crossing, so the crossings are the deepest colour.
        float size = 64.0;
        vec2 g = pos / size;
        float e = max(uPixelUnit / size, 0.004) * 1.2;
        float sx = smoothstep(0.5 - e, 0.5 + e, abs(fract(g.x) - 0.5) * 2.0);
        float sy = smoothstep(0.5 - e, 0.5 + e, abs(fract(g.y) - 0.5) * 2.0);
        float tone = 0.5 * (sx + sy);
        float cloth = 0.92 + 0.08 * vnoise(pos / 2.4) * resolved(2.4) + 0.05 * vnoise(pos / 25.0);
        base = mix(uColorB, uColorA, tone) * cloth;
    }

    // A lamp over the table: bright in the middle of the screen, falling off to the corners.
    vec2 q = vec2(vNdc.x * 0.5, vNdc.y * 0.5 - 0.02) * vec2(1.0, 0.82);
    float d = length(q);
    float lamp = 1.0 - smoothstep(0.18, 0.78, d);
    vec3 color = base * uExposure * mix(0.46, 1.08, lamp);

    // A faint sheen where the lamp is brightest (varnish, polished stone).
    color += vec3(1.0, 0.9, 0.75) * pow(max(0.0, 1.0 - d * 1.7), 2.5) * uSheen;
    gl_FragColor = vec4(color, 1.0);
}
"""

    const val PIECE_VERTEX = """
uniform mat4 uViewProj;
uniform vec2 uRot;
uniform vec3 uTrans;
uniform vec2 uSlope;
uniform float uThickness;
uniform float uFlatten;
attribute vec3 aPosition;
attribute vec3 aNormal;
attribute vec2 aTexCoord;
attribute float aFace;
varying vec3 vNormal;
varying vec3 vWorld;
varying vec2 vUv;
varying float vFace;
void main() {
    // Once the puzzle is solved the chamfer and wall tops rise to the printed surface,
    // so the finished picture is one unbroken sheet.
    float y = aPosition.y;
    if (aFace > 0.5 && y > 0.5 * uThickness) {
        y = mix(y, uThickness, uFlatten);
    }
    vec2 r = vec2(aPosition.x * uRot.x - aPosition.z * uRot.y,
                  aPosition.x * uRot.y + aPosition.z * uRot.x);
    // A piece leaning on the pieces below lies on a sloping plane: its height changes with
    // where on the piece you are (uSlope is the rise per unit along x and along z).
    y += dot(uSlope, r);
    vec3 p = vec3(r.x, y, r.y) + uTrans;
    vec3 n = vec3(aNormal.x * uRot.x - aNormal.z * uRot.y,
                  aNormal.y,
                  aNormal.x * uRot.y + aNormal.z * uRot.x);
    // The lean shears the piece, and normals follow the inverse transpose of a shear.
    vNormal = vec3(n.x - uSlope.x * n.y, n.y, n.z - uSlope.y * n.y);
    vWorld = p;
    vUv = aTexCoord;
    vFace = aFace;
    gl_Position = uViewProj * vec4(p, 1.0);
}
"""

    const val PIECE_FRAGMENT = """
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
uniform sampler2D uPhoto;
uniform vec3 uLightDir;
uniform vec3 uEyePos;
uniform float uSolved;
varying vec3 vNormal;
varying vec3 vWorld;
varying vec2 vUv;
varying float vFace;

// Soft fill light from the front (unit length).
const vec3 FILL_DIR = vec3(0.1474, 0.4423, 0.8847);

void main() {
    vec3 l = uLightDir; // unit length, set by the renderer
    vec3 v = normalize(uEyePos - vWorld);
    vec3 h = normalize(l + v);
    vec3 photo = texture2D(uPhoto, vUv).rgb;
    // The normal matters for the printed top too now: a piece leaning on others is tilted.
    vec3 n = normalize(vNormal);
    float key = max(dot(n, l), 0.0);
    float fill = max(dot(n, FILL_DIR), 0.0) * 0.22;
    float spec = pow(max(dot(n, h), 0.0), 36.0);
    float topShade = 0.60 + 0.47 * key + 0.4 * fill;

    vec3 color;
    if (vFace < 0.5) {
        // Printed top: the photo's own colours, a soft key light, a whisper of gloss.
        color = photo * topShade + vec3(spec * 0.055);
    } else if (vFace < 1.5) {
        // Chamfered cut: paper catching the light. Fades away once the puzzle is solved.
        vec3 edge = mix(photo, vec3(0.93, 0.90, 0.85), 0.30);
        vec3 bevel = edge * (0.50 + 0.62 * key + fill) + vec3(spec * 0.20);
        color = mix(bevel, photo * topShade, uSolved);
    } else {
        // Wall: grey chipboard core with a thin line of printed paper at the very top.
        float paper = smoothstep(0.80, 0.90, vUv.y);
        vec3 base = mix(vec3(0.60, 0.55, 0.47), vec3(0.93, 0.91, 0.86), paper);
        color = base * (0.42 + 0.55 * key + fill * 1.2);
    }
    gl_FragColor = vec4(color, 1.0);
}
"""

    const val DECAL_VERTEX = """
uniform mat4 uViewProj;
uniform vec3 uCenter;
uniform vec2 uRot;
uniform vec2 uHalf;
attribute vec2 aCorner;
varying vec2 vUv;
void main() {
    vec2 local = aCorner * uHalf;
    vec3 p = vec3(local.x * uRot.x - local.y * uRot.y,
                  0.0,
                  local.x * uRot.y + local.y * uRot.x) + uCenter;
    vUv = aCorner * 0.5 + 0.5;
    gl_Position = uViewProj * vec4(p, 1.0);
}
"""

    const val DECAL_FRAGMENT = """
precision mediump float;
uniform sampler2D uMask;
uniform vec4 uColor;
varying vec2 vUv;
void main() {
    float a = texture2D(uMask, vUv).a * uColor.a;
    gl_FragColor = vec4(uColor.rgb, a);
}
"""
}
