package com.photopuzzle.game.puzzle

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin
import kotlin.random.Random

/**
 * The few sounds a puzzle table makes -- a soft tick when a piece is picked up, a wooden
 * click when pieces fit, a little chime at the end -- synthesised in code so the app ships no
 * audio files. Everything here is best-effort: if the platform refuses, the game is simply quiet.
 */
internal class PuzzleSounds(context: Context) {

    private var pool: SoundPool? = null
    private var liftId = 0
    private var snapId = 0
    private var winId = 0
    private var thudId = 0
    private val random = Random(7)

    init {
        try {
            val attributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            val soundPool = SoundPool.Builder()
                .setMaxStreams(4)
                .setAudioAttributes(attributes)
                .build()
            liftId = soundPool.load(writeWav(context, "lift.wav", synthLift()), 1)
            snapId = soundPool.load(writeWav(context, "snap.wav", synthSnap()), 1)
            winId = soundPool.load(writeWav(context, "win.wav", synthWin()), 1)
            thudId = soundPool.load(writeWav(context, "thud.wav", synthThud()), 1)
            pool = soundPool
        } catch (error: Throwable) {
            pool = null
        }
    }

    fun lift() = play(liftId, 0.35f, 0.96f + random.nextFloat() * 0.08f)

    fun snap() = play(snapId, 0.9f, 0.95f + random.nextFloat() * 0.10f)

    fun win() = play(winId, 0.8f, 1f)

    fun thud() = play(thudId, 0.55f, 0.94f + random.nextFloat() * 0.12f)

    fun release() {
        pool?.release()
        pool = null
    }

    private fun play(id: Int, volume: Float, rate: Float) {
        if (id == 0) return
        try {
            pool?.play(id, volume, volume, 1, 0, rate)
        } catch (error: Throwable) {
            // Quiet is fine.
        }
    }

    // ---- synthesis -----------------------------------------------------------------------

    /** A piece of cardboard meeting its neighbour: a low thump with a bright wooden click on top. */
    private fun synthSnap(): ShortArray {
        val noise = Random(11)
        return render(0.16f) { t ->
            val thump = sin(2.0 * PI * 150.0 * t) * exp(-t * 38.0) * 0.75
            val click = sin(2.0 * PI * 1700.0 * t) * exp(-t * 220.0) * 0.45
            val grain = (noise.nextDouble() * 2.0 - 1.0) * exp(-t * 500.0) * 0.5
            thump + click + grain
        }
    }

    /** Cardboard pieces dropping onto the table: a dull, short thump with a little paper rustle. */
    private fun synthThud(): ShortArray {
        val noise = Random(23)
        return render(0.13f) { t ->
            val thump = sin(2.0 * PI * 95.0 * t) * exp(-t * 46.0) * 0.7
            val body = sin(2.0 * PI * 230.0 * t) * exp(-t * 70.0) * 0.3
            val rustle = (noise.nextDouble() * 2.0 - 1.0) * exp(-t * 160.0) * 0.18
            thump + body + rustle
        }
    }

    private fun synthLift(): ShortArray {
        val noise = Random(5)
        return render(0.07f) { t ->
            val tick = sin(2.0 * PI * 700.0 * t) * exp(-t * 90.0) * 0.25
            val grain = (noise.nextDouble() * 2.0 - 1.0) * exp(-t * 300.0) * 0.15
            tick + grain
        }
    }

    /** A short rising arpeggio, each note a soft bell. */
    private fun synthWin(): ShortArray {
        val notes = doubleArrayOf(523.25, 659.25, 783.99, 1046.50)
        return render(1.3f) { t ->
            var sum = 0.0
            for (i in notes.indices) {
                val local = t - i * 0.12
                if (local >= 0.0) {
                    sum += (sin(2.0 * PI * notes[i] * local) + 0.35 * sin(2.0 * PI * notes[i] * 2.0 * local)) *
                        exp(-local * 4.0) * 0.28
                }
            }
            sum
        }
    }

    private fun render(seconds: Float, sample: (Double) -> Double): ShortArray {
        val count = (SAMPLE_RATE * seconds).toInt()
        val out = ShortArray(count)
        for (i in 0 until count) {
            val v = sample(i.toDouble() / SAMPLE_RATE).coerceIn(-1.0, 1.0)
            out[i] = (v * 32000.0).toInt().toShort()
        }
        return out
    }

    private fun writeWav(context: Context, name: String, samples: ShortArray): String {
        val dataBytes = samples.size * 2
        val buffer = ByteBuffer.allocate(44 + dataBytes).order(ByteOrder.LITTLE_ENDIAN)
        buffer.put("RIFF".toByteArray(Charsets.US_ASCII))
        buffer.putInt(36 + dataBytes)
        buffer.put("WAVE".toByteArray(Charsets.US_ASCII))
        buffer.put("fmt ".toByteArray(Charsets.US_ASCII))
        buffer.putInt(16)
        buffer.putShort(1)
        buffer.putShort(1)
        buffer.putInt(SAMPLE_RATE)
        buffer.putInt(SAMPLE_RATE * 2)
        buffer.putShort(2)
        buffer.putShort(16)
        buffer.put("data".toByteArray(Charsets.US_ASCII))
        buffer.putInt(dataBytes)
        for (s in samples) buffer.putShort(s)

        val file = File(context.cacheDir, name)
        FileOutputStream(file).use { it.write(buffer.array()) }
        return file.absolutePath
    }

    private companion object {
        const val SAMPLE_RATE = 22050
    }
}
