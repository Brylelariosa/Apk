package com.photopuzzle.game.puzzle.render3d

import com.photopuzzle.game.R

/**
 * One tabletop: which pattern the table shader paints ([kind], see [TableStyles]), the colours it
 * paints it in, and the two colours of the little round swatch shown in the picker.
 *
 * What the three colours mean depends on the pattern: for the graded woods A is the dark end of
 * the grain and B the light end; for marble they are the base stone, the clouds and the veins; for
 * linen and gingham, the thread and the highlight (or the stripe and the cloth).
 */
internal class TableStyle(
    val nameRes: Int,
    val kind: Float,
    rgbA: Int,
    rgbB: Int,
    rgbC: Int,
    /** Brightness of the whole table; pale surfaces are turned down so the lamp does not wash them out. */
    val exposure: Float,
    /** How much lamp gloss the surface shows. */
    val sheen: Float,
    /** Swatch colours (ARGB), top-left to bottom-right. */
    val swatchTop: Int,
    val swatchBottom: Int
) {
    val colorA: FloatArray = unpack(rgbA)
    val colorB: FloatArray = unpack(rgbB)
    val colorC: FloatArray = unpack(rgbC)

    private companion object {
        fun unpack(rgb: Int): FloatArray = floatArrayOf(
            ((rgb shr 16) and 0xFF) / 255f,
            ((rgb shr 8) and 0xFF) / 255f,
            (rgb and 0xFF) / 255f
        )
    }
}

internal object TableStyles {

    // Patterns the table shader knows (keep in step with PuzzleShaders.TABLE_FRAGMENT).
    const val KIND_WOOD = 0f
    const val KIND_WOOD_GRADED = 1f
    const val KIND_FELT = 2f
    const val KIND_MARBLE = 3f
    const val KIND_STONE = 4f
    const val KIND_LINEN = 5f
    const val KIND_GINGHAM = 6f

    /** The first one is the table the game has always had. */
    val all: List<TableStyle> = listOf(
        TableStyle(
            R.string.table_walnut, KIND_WOOD, 0, 0, 0,
            exposure = 1.00f, sheen = 0.07f,
            swatchTop = 0xFF8A5530.toInt(), swatchBottom = 0xFF4A2A14.toInt()
        ),
        TableStyle(
            R.string.table_cherry, KIND_WOOD_GRADED, 0x5A1C10, 0xC15A38, 0,
            exposure = 0.95f, sheen = 0.07f,
            swatchTop = 0xFFC15A38.toInt(), swatchBottom = 0xFF6A2214.toInt()
        ),
        TableStyle(
            R.string.table_oak, KIND_WOOD_GRADED, 0x7E5430, 0xE4BC83, 0,
            exposure = 0.92f, sheen = 0.07f,
            swatchTop = 0xFFE4BC83.toInt(), swatchBottom = 0xFF9A6C3E.toInt()
        ),
        TableStyle(
            R.string.table_driftwood, KIND_WOOD_GRADED, 0x4B4A47, 0xB5B0A6, 0,
            exposure = 0.95f, sheen = 0.04f,
            swatchTop = 0xFFB5B0A6.toInt(), swatchBottom = 0xFF6A6863.toInt()
        ),
        TableStyle(
            R.string.table_ebony, KIND_WOOD_GRADED, 0x070606, 0x3A3030, 0,
            exposure = 1.00f, sheen = 0.10f,
            swatchTop = 0xFF3A3030.toInt(), swatchBottom = 0xFF0B0909.toInt()
        ),
        TableStyle(
            R.string.table_felt_green, KIND_FELT, 0x17583A, 0, 0,
            exposure = 1.00f, sheen = 0f,
            swatchTop = 0xFF1F7048.toInt(), swatchBottom = 0xFF124630.toInt()
        ),
        TableStyle(
            R.string.table_felt_navy, KIND_FELT, 0x1B2D5C, 0, 0,
            exposure = 1.00f, sheen = 0f,
            swatchTop = 0xFF2A4488.toInt(), swatchBottom = 0xFF16254C.toInt()
        ),
        TableStyle(
            R.string.table_marble, KIND_MARBLE, 0xEDEBE6, 0xB4B8C2, 0x4C5565,
            exposure = 0.80f, sheen = 0.14f,
            swatchTop = 0xFFF4F2EE.toInt(), swatchBottom = 0xFFA9AEB9.toInt()
        ),
        TableStyle(
            R.string.table_slate, KIND_STONE, 0x1D1F24, 0x474B54, 0,
            exposure = 1.00f, sheen = 0.05f,
            swatchTop = 0xFF4A4E58.toInt(), swatchBottom = 0xFF202228.toInt()
        ),
        TableStyle(
            R.string.table_linen, KIND_LINEN, 0xC8B391, 0xE9DDC4, 0,
            exposure = 0.85f, sheen = 0f,
            swatchTop = 0xFFE9DDC4.toInt(), swatchBottom = 0xFFC8B391.toInt()
        ),
        TableStyle(
            R.string.table_gingham, KIND_GINGHAM, 0xC62A31, 0xF4EFE6, 0,
            exposure = 0.85f, sheen = 0f,
            swatchTop = 0xFFF4EFE6.toInt(), swatchBottom = 0xFFC62A31.toInt()
        )
    )

    val count: Int get() = all.size

    /** The style at [index], clamped into range so a stale saved value is harmless. */
    fun get(index: Int): TableStyle = all[index.coerceIn(0, all.size - 1)]
}
