package com.photopuzzle.game.puzzle.engine

import com.photopuzzle.game.R

/**
 * One way of looking at the table: how steeply down, which side of the table the camera stands
 * on, and how wide the lens is. A wider lens exaggerates the perspective, a narrow one flattens it.
 */
internal class CameraPreset(
    val nameRes: Int,
    tiltDegrees: Float,
    yawDegrees: Float,
    val fovDegrees: Float
) {
    /** Radians away from looking straight down. */
    val tilt: Float = Math.toRadians(tiltDegrees.toDouble()).toFloat()

    /** Radians round the table; negative is the left-hand side, positive the right. */
    val yaw: Float = Math.toRadians(yawDegrees.toDouble()).toFloat()
}

internal object CameraPresets {

    /** The first one is the view the game has always had. */
    val all: List<CameraPreset> = listOf(
        CameraPreset(R.string.camera_classic, 28f, 0f, TableCamera.FOV_Y_DEGREES),
        CameraPreset(R.string.camera_top, 0f, 0f, TableCamera.FOV_Y_DEGREES),
        CameraPreset(R.string.camera_low, 56f, 0f, TableCamera.FOV_Y_DEGREES),
        CameraPreset(R.string.camera_left, 40f, -38f, TableCamera.FOV_Y_DEGREES),
        CameraPreset(R.string.camera_right, 40f, 38f, TableCamera.FOV_Y_DEGREES),
        CameraPreset(R.string.camera_wide, 36f, 0f, 52f),
        CameraPreset(R.string.camera_iso, 50f, 45f, 12f)
    )

    val count: Int get() = all.size

    /** The preset at [index], which is clamped into range so a stale saved value is harmless. */
    fun get(index: Int): CameraPreset = all[index.coerceIn(0, all.size - 1)]
}
