package com.photopuzzle.game.puzzle.engine

import com.photopuzzle.game.puzzle.PieceSide
import com.photopuzzle.game.puzzle.model.AngleMath
import com.photopuzzle.game.puzzle.model.PieceGroup
import com.photopuzzle.game.puzzle.model.PuzzleGame
import com.photopuzzle.game.puzzle.model.PuzzlePiece
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.max

/**
 * Turns finger input into what a hand does at a real puzzle table.
 *
 *  - Touch a piece anywhere and drag: the piece (with everything joined to it) slides. It never
 *    turns by accident: one finger on a piece only ever moves it.
 *  - To turn a piece, hold it with one finger and put a second finger down anywhere: twisting
 *    the two fingers round each other turns the piece about the first finger, like pinning it
 *    to the table and pushing it round.
 *  - With "edge turning" switched on, touching a piece by its rim (not the middle) and swiping
 *    around it turns it about its centre instead.
 *  - Touch bare table and drag: the view pans. Pinch: zoom.
 *
 * The mode is decided once, when the finger lands, so a gesture never changes character
 * half-way. Moves only record where the fingers are; the work is done once per frame in
 * [update], which also copes with the view moving under a stationary finger (edge auto-pan).
 *
 * Everything runs on the GL thread.
 */
internal class TouchInteraction(private val engine: PuzzleEngine) {

    private enum class Mode { IDLE, DRAG, ROTATE, PAN, ZOOM }

    private var mode = Mode.IDLE
    private var group: PieceGroup? = null

    /** A finger is on the table doing something, so every frame matters. */
    val isActive: Boolean get() = mode != Mode.IDLE

    private var fingerX = 0f
    private var fingerY = 0f
    private var lastTableX = 0f
    private var lastTableZ = 0f
    private var pivotX = 0f
    private var pivotZ = 0f
    private var lastAngle = 0f
    private var haveAngle = false
    private var anchorX = 0f
    private var anchorZ = 0f

    // The second finger of a twist, and the angle between the two fingers last frame.
    private var twisting = false
    private var secondX = 0f
    private var secondY = 0f
    private var twistAngle = 0f

    private val point = FloatArray(2)
    private val other = FloatArray(2)
    private val local = FloatArray(2)

    fun reset() {
        group?.held = false
        mode = Mode.IDLE
        group = null
        twisting = false
    }

    fun pointerDown(sx: Float, sy: Float) {
        val game = engine.game
        if (game == null || engine.isCelebrating) {
            mode = Mode.IDLE
            return
        }
        fingerX = sx
        fingerY = sy
        twisting = false
        val camera = engine.camera
        camera.cancelAnimation()
        if (!camera.screenToTable(sx, sy, 0f, point)) {
            mode = Mode.IDLE
            return
        }
        val tx = point[0]
        val tz = point[1]

        // Pieces lie at different heights, so the finger is followed through each piece's own top.
        val piece = game.findTopPieceAt { planeY, out -> camera.screenToTable(sx, sy, planeY, out) }
        if (piece == null) {
            mode = Mode.PAN
            anchorX = tx
            anchorZ = tz
            return
        }

        val g = piece.group
        group = g
        val fallen = game.grab(g)
        game.updateHover(g, engine.liftHeight)
        game.toLocal(piece, tx, tz, local)

        if (engine.turnMode && engine.rotationEnabled && isTurnHandle(game, piece, local[0], local[1])) {
            game.centroid(g, point)
            pivotX = point[0]
            pivotZ = point[1]
            val dx = tx - pivotX
            val dz = tz - pivotZ
            haveAngle = hypot(dx, dz) > game.minCell * TURN_DEAD_ZONE
            lastAngle = if (haveAngle) atan2(dz, dx) else 0f
            mode = Mode.ROTATE
            engine.notifyTurnStarted()
        } else {
            lastTableX = tx
            lastTableZ = tz
            mode = Mode.DRAG
        }
        engine.notifyPieceLifted()
        if (fallen > 0) engine.notifyPileCollapsed()
    }

    fun pointerMove(sx: Float, sy: Float) {
        fingerX = sx
        fingerY = sy
    }

    fun pointerUp() {
        val g = group
        val previous = mode
        mode = Mode.IDLE
        group = null
        twisting = false
        engine.hideRing()
        if ((previous == Mode.DRAG || previous == Mode.ROTATE) && g != null) {
            engine.onGroupReleased(g)
        }
    }

    /** One finger of a pinch stayed down: carry on by panning with it. */
    fun pointerRebase(sx: Float, sy: Float) {
        if (mode != Mode.IDLE && mode != Mode.ZOOM && mode != Mode.PAN) return
        fingerX = sx
        fingerY = sy
        if (engine.camera.screenToTable(sx, sy, 0f, point)) {
            anchorX = point[0]
            anchorZ = point[1]
            mode = Mode.PAN
        }
    }

    fun pinchBegin(fx: Float, fy: Float) {
        if (mode == Mode.PAN || mode == Mode.IDLE) {
            mode = Mode.ZOOM
            engine.camera.cancelAnimation()
            engine.camera.beginAnchor(fx, fy)
        }
    }

    fun pinch(scaleFactor: Float, fx: Float, fy: Float) {
        if (mode == Mode.ZOOM) engine.camera.applyPinch(scaleFactor, fx, fy)
    }

    fun pinchEnd() {
        if (mode == Mode.ZOOM) mode = Mode.IDLE
    }

    // ---- the second finger -----------------------------------------------------------------

    /** A second finger landed while the first holds a piece: twisting the two turns it. */
    fun secondaryDown(sx: Float, sy: Float) {
        val game = engine.game ?: return
        if (mode != Mode.DRAG || group == null || !engine.rotationEnabled) return
        val camera = engine.camera
        if (!camera.screenToTable(fingerX, fingerY, 0f, point)) return
        if (!camera.screenToTable(sx, sy, 0f, other)) return
        secondX = sx
        secondY = sy
        twistAngle = atan2(other[1] - point[1], other[0] - point[0])
        twisting = true
        engine.notifyTurnStarted()
        showTwistRing(game, group ?: return)
    }

    fun secondaryMove(sx: Float, sy: Float) {
        secondX = sx
        secondY = sy
    }

    fun secondaryUp() {
        if (!twisting) return
        twisting = false
        engine.hideRing()
    }

    // ---- per frame -------------------------------------------------------------------------

    fun update(dt: Float) {
        val game = engine.game ?: return
        val camera = engine.camera
        when (mode) {
            Mode.DRAG -> {
                val g = group ?: return
                if (camera.screenToTable(fingerX, fingerY, 0f, point)) {
                    game.translate(g, point[0] - lastTableX, point[1] - lastTableZ)
                    if (twisting) applyTwist(game, g)
                    game.keepOnTable(g)
                    lastTableX = point[0]
                    lastTableZ = point[1]
                }
                game.updateHover(g, engine.liftHeight)
                autoPan(dt)
            }
            Mode.ROTATE -> {
                val g = group ?: return
                if (camera.screenToTable(fingerX, fingerY, 0f, point)) {
                    val dx = point[0] - pivotX
                    val dz = point[1] - pivotZ
                    // Too close to the pivot the angle is meaningless noise.
                    if (hypot(dx, dz) > game.minCell * TURN_DEAD_ZONE) {
                        val a = atan2(dz, dx)
                        if (haveAngle) {
                            val da = AngleMath.wrap(a - lastAngle)
                            if (da != 0f) game.rotate(g, da, pivotX, pivotZ)
                        }
                        lastAngle = a
                        haveAngle = true
                    }
                }
                game.updateHover(g, engine.liftHeight)
                engine.showRing(
                    pivotX, pivotZ, game.extentFrom(g, pivotX, pivotZ) + 0.62f * game.minCell,
                    lastAngle, g.lift
                )
            }
            Mode.PAN -> {
                if (camera.screenToTable(fingerX, fingerY, 0f, point)) {
                    camera.panBy(anchorX - point[0], anchorZ - point[1])
                }
            }
            else -> {
            }
        }
    }

    /**
     * Turns the held group by however far the line between the two fingers has turned since the
     * last frame, about the first finger (whose table point is in [point]).
     */
    private fun applyTwist(game: PuzzleGame, g: PieceGroup) {
        if (!engine.camera.screenToTable(secondX, secondY, 0f, other)) return
        val dx = other[0] - point[0]
        val dz = other[1] - point[1]
        // Fingers almost touching: the angle between them is just noise.
        if (hypot(dx, dz) < game.minCell * TWIST_MIN_SPAN) return
        val a = atan2(dz, dx)
        val da = AngleMath.wrap(a - twistAngle)
        if (da != 0f) game.rotate(g, da, point[0], point[1])
        twistAngle = a
        showTwistRing(game, g)
    }

    private fun showTwistRing(game: PuzzleGame, g: PieceGroup) {
        game.centroid(g, other)
        engine.showRing(
            other[0], other[1], game.extentFrom(g, other[0], other[1]) + 0.62f * game.minCell,
            twistAngle, g.lift
        )
    }

    /**
     * Is this touch on an exposed edge of the piece? Not the middle (that is for dragging), and
     * not a side already joined to a neighbour in the same group (an interior seam is not
     * something you can take hold of). The middle is never smaller than a fingertip, so tiny
     * pieces can still be dragged; zoom in to turn them. Only asked in edge-turning mode.
     */
    private fun isTurnHandle(game: PuzzleGame, piece: PuzzlePiece, lx: Float, lz: Float): Boolean {
        val core = max(
            CORE_FRACTION * game.minCell,
            CORE_MIN_DP * engine.density / engine.camera.zoom
        )
        if (hypot(lx, lz) <= core) return false

        val side = if (abs(lx) * game.cellHeight >= abs(lz) * game.cellWidth) {
            if (lx > 0f) PieceSide.RIGHT else PieceSide.LEFT
        } else {
            if (lz > 0f) PieceSide.BOTTOM else PieceSide.TOP
        }
        val neighbor = game.neighbor(piece, side)
        return neighbor == null || neighbor.group !== piece.group
    }

    /** Drags near the screen edge scroll the table along so a held piece can go further. */
    private fun autoPan(dt: Float) {
        val camera = engine.camera
        val margin = AUTO_PAN_MARGIN_DP * engine.density
        val right = camera.viewWidth - margin
        val bottom = camera.viewHeight - margin
        var vx = 0f
        var vy = 0f
        if (fingerX < margin) vx = -(margin - fingerX) / margin
        else if (fingerX > right) vx = (fingerX - right) / margin
        if (fingerY < margin) vy = -(margin - fingerY) / margin
        else if (fingerY > bottom) vy = (fingerY - bottom) / margin
        if (vx != 0f || vy != 0f) {
            // Screen pixels per frame, turned into table units by the camera, so the pace is the
            // same whichever way the view is turned.
            val speed = AUTO_PAN_SPEED * dt
            camera.panByScreen(vx.coerceIn(-1f, 1f) * speed, vy.coerceIn(-1f, 1f) * speed)
        }
    }

    private companion object {
        /** Radius of the "grab to drag" middle, as a fraction of the smaller cell side. */
        const val CORE_FRACTION = 0.33f

        /** ...but never smaller than this on screen. */
        const val CORE_MIN_DP = 14f

        /** Touching this close to the centre (in cells) gives no usable turning angle. */
        const val TURN_DEAD_ZONE = 0.08f

        /** Two fingers must be at least this far apart (in cells) for their angle to count. */
        const val TWIST_MIN_SPAN = 0.15f

        const val AUTO_PAN_MARGIN_DP = 52f
        const val AUTO_PAN_SPEED = 750f
    }
}
