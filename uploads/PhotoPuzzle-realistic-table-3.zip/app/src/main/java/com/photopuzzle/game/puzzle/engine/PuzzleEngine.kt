package com.photopuzzle.game.puzzle.engine

import android.graphics.Bitmap
import com.photopuzzle.game.puzzle.geometry.SoftMask
import com.photopuzzle.game.puzzle.model.PieceGroup
import com.photopuzzle.game.puzzle.model.PieceScatter
import com.photopuzzle.game.puzzle.model.PuzzleGame
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

/**
 * Owns one puzzle on one table: the rules ([PuzzleGame]), the camera, the touch handling, and
 * the animations that tie them to time. The renderer reads its state every frame and draws it.
 *
 * Single-threaded by design: all calls, and the renderer, run on the GL thread, so there is no
 * locking anywhere. The view forwards touches and requests to that thread.
 */
internal class PuzzleEngine(
    private val listener: PuzzleListener,
    /** Screen density, to turn dp thresholds into pixels. */
    val density: Float
) {
    val camera = TableCamera()

    var game: PuzzleGame? = null
        private set

    /** The photo as a power-of-two bitmap, for the renderer to turn into a texture. */
    var atlas: Bitmap? = null
        private set

    /** One pre-blurred shadow silhouette per piece (by piece id), for the renderer to upload. */
    var shadows: Array<SoftMask?>? = null
        private set

    /** Bumped whenever a different puzzle is installed, so the renderer knows to rebuild. */
    var generation: Int = 0
        private set

    var rotationEnabled = true
        private set

    /** 0 while playing, easing to 1 once solved (the cut lines fade away). */
    var solvedMix = 0f
        private set

    /** How high a held group is lifted above the table. */
    var liftHeight = 0f
        private set

    var isCelebrating = false
        private set

    /** Edge turning: touching a piece by its rim and swiping around it turns it. */
    var turnMode = false
        private set

    /** Which tabletop to draw (an index into the renderer's list of styles). */
    var tableStyle = 0
        private set

    /** The camera angle the player chose (an index into [CameraPresets]). */
    var cameraPresetIndex = 0
        private set

    // The ring shown around a group while it is being turned.
    var ringAlpha = 0f
        private set
    var ringX = 0f
        private set
    var ringY = 0f
        private set
    var ringZ = 0f
        private set
    var ringRadius = 0f
        private set
    var ringAngle = 0f
        private set

    private val interaction = TouchInteraction(this)
    private var scatterBounds: ScatterBounds? = null
    private var celebrationTime = 0f
    private var solvedNotified = false
    private var ringVisible = false

    // ---- lifecycle -----------------------------------------------------------------------

    /** Puts a freshly built puzzle on the table and pours the pieces out. */
    fun install(built: BuiltPuzzle) {
        interaction.reset()
        game = built.game
        atlas = built.atlas
        shadows = built.shadows
        rotationEnabled = built.rotatePieces
        scatterBounds = built.scatter
        liftHeight = LIFT_FRACTION * built.game.minCell

        camera.resize(built.viewWidth, built.viewHeight)
        camera.limitX = max(0f, built.game.tableHalfWidth - 0.25f * built.viewWidth)
        camera.limitZ = max(
            0f,
            built.game.tableHalfDepth - 0.25f * built.viewHeight / cos(TableCamera.TILT_RADIANS)
        )

        generation++
        startRound(Random(built.seed + 977L))
        listener.onReady()
    }

    /** Scoops everything back up and pours it out again. */
    fun shuffle() {
        startRound(Random(System.nanoTime()))
    }

    fun resizeSurface(width: Int, height: Int) {
        camera.resize(width, height)
    }

    private fun startRound(random: Random) {
        val g = game ?: return
        val b = scatterBounds ?: return
        interaction.reset()
        hideRing()
        g.resetGroups()
        PieceScatter.scatter(g, random, b.left, b.right, b.top, b.bottom, b.windowTop, rotationEnabled)
        solvedMix = 0f
        isCelebrating = false
        celebrationTime = 0f
        solvedNotified = false
        camera.snapTo(0f, 0f, 1f)
        applyCameraPreset(animate = false)
        listener.onProgress(0, g.pieces.size)
    }

    private fun applyCameraPreset(animate: Boolean) {
        val preset = CameraPresets.get(cameraPresetIndex)
        camera.setAngles(preset.tilt, preset.yaw, preset.fovDegrees, animate)
    }

    // ---- look and feel (chosen by the player) --------------------------------------------

    fun setTurnMode(enabled: Boolean) {
        turnMode = enabled
    }

    fun setTableStyle(index: Int) {
        tableStyle = index
    }

    fun setCameraPreset(index: Int, animate: Boolean) {
        cameraPresetIndex = index.coerceIn(0, CameraPresets.count - 1)
        // The finished picture is shown from a fixed angle; the choice takes effect next round.
        if (!isCelebrating) applyCameraPreset(animate)
    }

    /** Re-centres and re-fits the view on the table. */
    fun fitView() {
        camera.animateTo(0f, 0f, 1f)
    }

    // ---- input (forwarded from the view) -------------------------------------------------

    fun pointerDown(x: Float, y: Float) = interaction.pointerDown(x, y)
    fun pointerMove(x: Float, y: Float) = interaction.pointerMove(x, y)
    fun pointerUp() = interaction.pointerUp()
    fun pointerRebase(x: Float, y: Float) = interaction.pointerRebase(x, y)
    fun pinchBegin(fx: Float, fy: Float) = interaction.pinchBegin(fx, fy)
    fun pinch(scaleFactor: Float, fx: Float, fy: Float) = interaction.pinch(scaleFactor, fx, fy)
    fun pinchEnd() = interaction.pinchEnd()
    fun secondaryDown(x: Float, y: Float) = interaction.secondaryDown(x, y)
    fun secondaryMove(x: Float, y: Float) = interaction.secondaryMove(x, y)
    fun secondaryUp() = interaction.secondaryUp()

    // ---- called by TouchInteraction ------------------------------------------------------

    fun notifyPieceLifted() = listener.onPieceLifted()

    fun notifyPileCollapsed() = listener.onPileCollapsed()

    fun notifyTurnStarted() = listener.onTurnStarted()

    fun showRing(x: Float, z: Float, radius: Float, angle: Float, y: Float) {
        ringVisible = true
        ringX = x
        ringY = y
        ringZ = z
        ringRadius = radius
        ringAngle = angle
    }

    fun hideRing() {
        ringVisible = false
    }

    /** A group was let go: see whether it fits against anything. */
    fun onGroupReleased(group: PieceGroup) {
        val g = game ?: return
        // Joins it to what it fits, and lets it (and anything it left unsupported) settle.
        val merged = g.release(group)
        if (merged > 0) {
            listener.onPieceJoined()
            listener.onProgress(g.joinedPieces(), g.pieces.size)
            if (g.isSolved) beginCelebration(g)
        }
    }

    // ---- per frame -----------------------------------------------------------------------

    fun update(dt: Float) {
        val g = game
        if (g != null) {
            interaction.update(dt)
            updateLifts(g, dt)
            updateAnimations(g, dt)
            updateCelebration(g, dt)
        }
        camera.update(dt)
        updateRing(dt)
    }

    /**
     * True while anything is still moving or fading, so another frame is needed. When the table
     * is at rest nothing is redrawn at all, which keeps the phone cool and the battery happy.
     */
    fun isAnimating(): Boolean {
        if (camera.isAnimating || interaction.isActive || ringVisible || ringAlpha > 0f) return true
        if (isCelebrating && celebrationTime < CELEBRATION_SECONDS + CELEBRATION_TAIL) return true
        val g = game ?: return false
        for (i in 0 until g.groups.size) {
            val group = g.groups[i]
            if (group.lift != group.liftTarget || group.liftVelocity != 0f) return true
            if (group.tiltX != group.tiltTargetX || group.tiltZ != group.tiltTargetZ) return true
        }
        for (i in 0 until g.pieces.size) {
            val p = g.pieces[i]
            if (p.animDelay > 0f || p.animX != 0f || p.animZ != 0f || p.animAngle != 0f) return true
        }
        return false
    }

    /**
     * Raises and lowers the groups, and eases their lean. A held group glides to where it hovers;
     * a group with nothing under it any more (just let go, or its support was pulled away) falls
     * under gravity, so a collapsing pile drops rather than floats.
     */
    private fun updateLifts(g: PuzzleGame, dt: Float) {
        val k = 1f - exp(-dt * LIFT_RATE)
        val tiltK = 1f - exp(-dt * TILT_RATE)
        val gravity = FALL_GRAVITY * g.minCell
        for (i in 0 until g.groups.size) {
            val group = g.groups[i]
            // A piece still waiting for its turn in the pour hangs where it is.
            if (group.pieces[0].animDelay > 0f) continue

            if (!group.held && group.lift > group.liftTarget) {
                group.liftVelocity += gravity * dt
                group.lift -= group.liftVelocity * dt
                if (group.lift <= group.liftTarget) {
                    group.lift = group.liftTarget
                    group.liftVelocity = 0f
                }
            } else {
                group.liftVelocity = 0f
                group.lift += (group.liftTarget - group.lift) * k
                if (abs(group.liftTarget - group.lift) < 0.01f) group.lift = group.liftTarget
            }

            group.tiltX += (group.tiltTargetX - group.tiltX) * tiltK
            group.tiltZ += (group.tiltTargetZ - group.tiltZ) * tiltK
            if (abs(group.tiltTargetX - group.tiltX) < 0.0005f) group.tiltX = group.tiltTargetX
            if (abs(group.tiltTargetZ - group.tiltZ) < 0.0005f) group.tiltZ = group.tiltTargetZ
        }
    }

    private fun updateAnimations(g: PuzzleGame, dt: Float) {
        val decay = exp(-dt * ANIMATION_RATE)
        for (i in 0 until g.pieces.size) {
            val p = g.pieces[i]
            if (p.animDelay > 0f) {
                p.animDelay -= dt
                continue
            }
            if (p.animX != 0f || p.animZ != 0f || p.animAngle != 0f) {
                p.animX *= decay
                p.animZ *= decay
                p.animAngle *= decay
                if (abs(p.animX) < 0.05f && abs(p.animZ) < 0.05f && abs(p.animAngle) < 0.002f) {
                    p.animX = 0f
                    p.animZ = 0f
                    p.animAngle = 0f
                }
            }
        }
    }

    private fun beginCelebration(g: PuzzleGame) {
        interaction.reset()
        hideRing()
        isCelebrating = true
        celebrationTime = 0f
        // Lay the finished picture upright where the player is looking, and frame it.
        g.settleSolved(camera.focusX, camera.focusZ)
        val pictureWidth = g.cols * g.cellWidth
        val fit = (0.84f * camera.viewWidth / pictureWidth).coerceIn(TableCamera.MIN_ZOOM, TableCamera.MAX_ZOOM)
        camera.animateTo(camera.focusX, camera.focusZ, fit)
        // ... from the front, whichever side of the table the player had been looking from.
        camera.setAngles(min(camera.tilt, TableCamera.TILT_RADIANS), 0f, TableCamera.FOV_Y_DEGREES, true)
        listener.onCelebrationStarted()
    }

    private fun updateCelebration(g: PuzzleGame, dt: Float) {
        if (!isCelebrating) return
        celebrationTime += dt
        solvedMix = min(1f, max(0f, (celebrationTime - 0.5f) / 1.1f))
        if (celebrationTime >= CELEBRATION_SECONDS && !solvedNotified) {
            solvedNotified = true
            listener.onSolved()
        }
    }

    private fun updateRing(dt: Float) {
        val target = if (ringVisible) 1f else 0f
        ringAlpha += (target - ringAlpha) * (1f - exp(-dt * 12f))
        if (!ringVisible && ringAlpha < 0.01f) ringAlpha = 0f
    }

    private companion object {
        const val LIFT_FRACTION = 0.20f
        const val LIFT_RATE = 14f

        /** How fast a group's lean eases to its resting lean. */
        const val TILT_RATE = 12f

        /** Pull of gravity on a falling group, in piece sizes per second squared. */
        const val FALL_GRAVITY = 16f
        const val ANIMATION_RATE = 7f
        const val CELEBRATION_SECONDS = 1.9f

        /** Frames to keep drawing after the celebration starts, so the fade-in can finish. */
        const val CELEBRATION_TAIL = 0.6f
    }
}
