package com.photopuzzle.game.puzzle

import android.graphics.Bitmap
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.HapticFeedbackConstants
import android.view.View
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import com.photopuzzle.game.R
import com.photopuzzle.game.puzzle.engine.CameraPresets
import com.photopuzzle.game.puzzle.engine.PuzzleListener
import com.photopuzzle.game.puzzle.render3d.PuzzleBoardView
import com.photopuzzle.game.puzzle.render3d.TableStyles
import com.photopuzzle.game.util.ImageUtils
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * The puzzle screen: the 3D table plus the small amount of interface around it -- progress and
 * timer, a "picture on the box" preview, buttons for the camera angle, the tabletop, edge turning
 * and fitting the table, hints and the results sheet. All the game lives in [PuzzleBoardView];
 * this class only listens to it.
 */
class PuzzleActivity : ComponentActivity(), PuzzleListener {

    private lateinit var boardView: PuzzleBoardView
    private lateinit var progressText: TextView
    private lateinit var timerText: TextView
    private lateinit var hintText: TextView
    private lateinit var previewOverlay: View
    private lateinit var previewImage: ImageView
    private lateinit var confettiView: ConfettiView
    private lateinit var winOverlay: View
    private lateinit var winTime: TextView
    private lateinit var loadingOverlay: View
    private lateinit var turnButton: ImageButton
    private lateinit var tableButton: ImageButton
    private lateinit var modeLabel: TextView
    private lateinit var tablePicker: LinearLayout

    private val swatchViews = ArrayList<View>()
    private var cameraIndex = 0
    private var tableIndex = 0
    private var edgeTurning = false

    private var sounds: PuzzleSounds? = null
    private var rotateEnabled = true

    private val handler = Handler(Looper.getMainLooper())
    private val timerTick = object : Runnable {
        override fun run() {
            updateTimerText()
            handler.postDelayed(this, 500L)
        }
    }
    private var playing = false
    private var timerRunning = false
    private var timerStartedAt = 0L
    private var timerAccumulatedMs = 0L

    private var hintDismissed = false
    private val hideHint = Runnable { dismissHint() }
    private val hideLabel = Runnable { fadeOutLabel() }
    private val hidePicker = Runnable { setTablePickerVisible(false) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_puzzle)

        boardView = findViewById(R.id.boardView)
        progressText = findViewById(R.id.progressText)
        timerText = findViewById(R.id.timerText)
        hintText = findViewById(R.id.hintText)
        previewOverlay = findViewById(R.id.previewOverlay)
        previewImage = findViewById(R.id.previewImage)
        confettiView = findViewById(R.id.confettiView)
        winOverlay = findViewById(R.id.winOverlay)
        winTime = findViewById(R.id.winTime)
        loadingOverlay = findViewById(R.id.loadingOverlay)
        turnButton = findViewById(R.id.turnButton)
        tableButton = findViewById(R.id.tableButton)
        modeLabel = findViewById(R.id.modeLabel)
        tablePicker = findViewById(R.id.tablePicker)

        val imagePath = intent.getStringExtra(EXTRA_IMAGE_PATH)
        val pieceCount = intent.getIntExtra(EXTRA_PIECE_COUNT, 9)
        rotateEnabled = intent.getBooleanExtra(EXTRA_ROTATE_PIECES, true)
        if (imagePath == null) {
            finish()
            return
        }

        sounds = PuzzleSounds(this)
        boardView.puzzleListener = this
        setUpLookAndFeel()

        findViewById<ImageButton>(R.id.backButton).setOnClickListener { finish() }
        findViewById<ImageButton>(R.id.previewButton).setOnClickListener { togglePreview() }
        findViewById<ImageButton>(R.id.fitButton).setOnClickListener { boardView.fitView() }
        previewOverlay.setOnClickListener { hidePreview() }
        findViewById<View>(R.id.playAgainButton).setOnClickListener { playAgain() }
        findViewById<View>(R.id.newPhotoButton).setOnClickListener { finish() }

        progressText.text = getString(R.string.progress_format, 0, 0)
        updateTimerText()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (previewOverlay.visibility == View.VISIBLE) {
                    hidePreview()
                } else if (tablePicker.visibility == View.VISIBLE) {
                    setTablePickerVisible(false)
                } else {
                    finish()
                }
            }
        })

        loadPuzzle(imagePath, pieceCount)
    }

    override fun onResume() {
        super.onResume()
        boardView.onResume()
        if (playing) startTimer()
    }

    override fun onPause() {
        pauseTimer()
        boardView.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        boardView.puzzleListener = null
        sounds?.release()
        sounds = null
        super.onDestroy()
    }

    // ---- loading -------------------------------------------------------------------------

    private fun loadPuzzle(imagePath: String, pieceCount: Int) {
        Thread {
            val bitmap = ImageUtils.loadOrientedBitmap(imagePath, MAX_PHOTO_DIMENSION)
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                if (bitmap == null) {
                    onFailed()
                    return@runOnUiThread
                }
                val (rows, cols) = PuzzleGridSizing.forPhoto(pieceCount, bitmap.width, bitmap.height)
                previewImage.setImageBitmap(makePreview(bitmap))
                boardView.start(bitmap, rows, cols, rotateEnabled)
            }
        }.start()
    }

    /** A modest independent copy for the preview card; the board takes ownership of the full-size photo. */
    private fun makePreview(source: Bitmap): Bitmap {
        val scale = min(1f, PREVIEW_MAX_SIDE / max(source.width, source.height).toFloat())
        val w = max(1, (source.width * scale).roundToInt())
        val h = max(1, (source.height * scale).roundToInt())
        val scaled = Bitmap.createScaledBitmap(source, w, h, true)
        if (scaled !== source) return scaled
        return source.copy(Bitmap.Config.ARGB_8888, false) ?: source
    }

    // ---- PuzzleListener (arrives on the main thread via the board view) ------------------

    override fun onReady() {
        loadingOverlay.animate().alpha(0f).setDuration(260L).withEndAction {
            loadingOverlay.visibility = View.GONE
        }.start()
        playing = true
        timerAccumulatedMs = 0L
        startTimer()
        showHint(getString(if (rotateEnabled) R.string.hint_turn else R.string.hint_drag))
    }

    override fun onProgress(joined: Int, total: Int) {
        progressText.text = getString(R.string.progress_format, joined, total)
    }

    override fun onPieceLifted() {
        sounds?.lift()
        if (tablePicker.visibility == View.VISIBLE) setTablePickerVisible(false)
    }

    override fun onPileCollapsed() {
        sounds?.thud()
    }

    override fun onPieceJoined() {
        sounds?.snap()
        boardView.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        dismissHint()
    }

    override fun onTurnStarted() {
        boardView.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
        dismissHint()
    }

    override fun onCelebrationStarted() {
        playing = false
        pauseTimer()
        sounds?.win()
        boardView.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
    }

    override fun onSolved() {
        winTime.text = getString(R.string.solved_in_format, formatTime(elapsedMs()))
        winOverlay.visibility = View.VISIBLE
        winOverlay.alpha = 0f
        winOverlay.translationY = 240f
        winOverlay.animate().alpha(1f).translationY(0f).setDuration(420L).start()
        confettiView.celebrate()
    }

    override fun onFailed() {
        Toast.makeText(this, R.string.load_failed, Toast.LENGTH_LONG).show()
        finish()
    }

    // ---- camera angle, tabletop, edge turning ---------------------------------------------

    private fun prefs() = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)

    /** Restores the camera angle and tabletop from last time and wires up their buttons. */
    private fun setUpLookAndFeel() {
        cameraIndex = prefs().getInt(KEY_CAMERA, 0).coerceIn(0, CameraPresets.count - 1)
        tableIndex = prefs().getInt(KEY_TABLE, 0).coerceIn(0, TableStyles.count - 1)
        boardView.setCameraPreset(cameraIndex, false)
        boardView.setTableStyle(tableIndex)

        findViewById<ImageButton>(R.id.cameraButton).setOnClickListener { nextCameraAngle() }
        tableButton.setOnClickListener { setTablePickerVisible(tablePicker.visibility != View.VISIBLE) }
        buildTablePicker()

        if (rotateEnabled) {
            turnButton.setOnClickListener { toggleEdgeTurning() }
        } else {
            // Nothing turns in this puzzle, so there is nothing to switch.
            turnButton.visibility = View.GONE
        }
    }

    private fun nextCameraAngle() {
        cameraIndex = (cameraIndex + 1) % CameraPresets.count
        boardView.setCameraPreset(cameraIndex, true)
        prefs().edit().putInt(KEY_CAMERA, cameraIndex).apply()
        showLabel(getString(CameraPresets.get(cameraIndex).nameRes))
        dismissHint()
    }

    private fun toggleEdgeTurning() {
        edgeTurning = !edgeTurning
        boardView.setTurnMode(edgeTurning)
        turnButton.isActivated = edgeTurning
        turnButton.setColorFilter(getColor(if (edgeTurning) R.color.colorAccent else R.color.colorCream))
        showLabel(getString(if (edgeTurning) R.string.edge_turn_on else R.string.edge_turn_off))
        dismissHint()
    }

    /** Lays the tabletop swatches out in even rows, as many to a row as the screen is wide enough for. */
    private fun buildTablePicker() {
        val density = resources.displayMetrics.density
        val size = (SWATCH_DP * density).roundToInt()
        val gap = (SWATCH_GAP_DP * density).roundToInt()
        val available = resources.displayMetrics.widthPixels - PICKER_EDGE_DP * density
        val fitting = max(3, (available / (size + 2 * gap)).toInt())
        val count = TableStyles.count
        val rows = (count + fitting - 1) / fitting
        val perRow = (count + rows - 1) / rows

        var index = 0
        while (index < count) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            tablePicker.addView(row)
            val end = min(count, index + perRow)
            while (index < end) {
                val chosen = index
                val swatch = View(this)
                val params = LinearLayout.LayoutParams(size, size)
                params.setMargins(gap, gap, gap, gap)
                swatch.layoutParams = params
                swatch.contentDescription = getString(TableStyles.get(chosen).nameRes)
                swatch.setOnClickListener { chooseTable(chosen) }
                row.addView(swatch)
                swatchViews.add(swatch)
                index++
            }
        }
        refreshSwatches()
    }

    /** Paints each swatch in its table's colours, with a brass ring round the chosen one. */
    private fun refreshSwatches() {
        val density = resources.displayMetrics.density
        for (index in 0 until swatchViews.size) {
            val style = TableStyles.get(index)
            val selected = index == tableIndex
            val swatch = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(style.swatchTop, style.swatchBottom)
            )
            swatch.setShape(GradientDrawable.OVAL)
            swatch.setStroke(
                ((if (selected) 3f else 1f) * density).roundToInt(),
                getColor(if (selected) R.color.colorAccent else R.color.colorHudBorder)
            )
            swatchViews[index].background = swatch
        }
    }

    private fun chooseTable(index: Int) {
        tableIndex = index
        boardView.setTableStyle(index)
        prefs().edit().putInt(KEY_TABLE, index).apply()
        refreshSwatches()
        showLabel(getString(TableStyles.get(index).nameRes))
        // Leave it open a while longer so a few can be tried in a row.
        handler.removeCallbacks(hidePicker)
        handler.postDelayed(hidePicker, PICKER_SECONDS * 1000L)
    }

    private fun setTablePickerVisible(visible: Boolean) {
        handler.removeCallbacks(hidePicker)
        tableButton.isActivated = visible
        tablePicker.animate().cancel()
        if (visible) {
            dismissHint()
            tablePicker.alpha = 0f
            tablePicker.visibility = View.VISIBLE
            tablePicker.animate().alpha(1f).setDuration(160L).start()
            handler.postDelayed(hidePicker, PICKER_SECONDS * 1000L)
        } else {
            tablePicker.animate().alpha(0f).setDuration(140L).withEndAction {
                tablePicker.visibility = View.GONE
            }.start()
        }
    }

    /** A short caption naming what was just chosen; fades away by itself. */
    private fun showLabel(text: String) {
        modeLabel.animate().cancel()
        modeLabel.text = text
        modeLabel.alpha = 1f
        modeLabel.visibility = View.VISIBLE
        handler.removeCallbacks(hideLabel)
        handler.postDelayed(hideLabel, LABEL_MILLIS)
    }

    private fun fadeOutLabel() {
        modeLabel.animate().alpha(0f).setDuration(250L).withEndAction {
            modeLabel.visibility = View.GONE
        }.start()
    }

    // ---- interface -----------------------------------------------------------------------

    private fun playAgain() {
        winOverlay.visibility = View.GONE
        boardView.shuffle()
        timerAccumulatedMs = 0L
        playing = true
        startTimer()
        updateTimerText()
    }

    private fun togglePreview() {
        if (previewOverlay.visibility == View.VISIBLE) hidePreview() else showPreview()
    }

    private fun showPreview() {
        previewOverlay.alpha = 0f
        previewOverlay.visibility = View.VISIBLE
        previewOverlay.animate().alpha(1f).setDuration(180L).start()
    }

    private fun hidePreview() {
        previewOverlay.animate().alpha(0f).setDuration(150L).withEndAction {
            previewOverlay.visibility = View.GONE
        }.start()
    }

    private fun showHint(text: String) {
        if (hintDismissed) return
        hintText.text = text
        hintText.alpha = 0f
        hintText.visibility = View.VISIBLE
        hintText.animate().alpha(1f).setDuration(300L).start()
        handler.removeCallbacks(hideHint)
        handler.postDelayed(hideHint, HINT_SECONDS * 1000L)
    }

    private fun dismissHint() {
        hintDismissed = true
        handler.removeCallbacks(hideHint)
        if (hintText.visibility != View.VISIBLE) return
        hintText.animate().alpha(0f).setDuration(250L).withEndAction {
            hintText.visibility = View.GONE
        }.start()
    }

    // ---- timer ---------------------------------------------------------------------------

    private fun startTimer() {
        if (timerRunning) return
        timerRunning = true
        timerStartedAt = SystemClock.elapsedRealtime()
        handler.post(timerTick)
    }

    private fun pauseTimer() {
        if (!timerRunning) return
        timerAccumulatedMs += SystemClock.elapsedRealtime() - timerStartedAt
        timerRunning = false
        handler.removeCallbacks(timerTick)
    }

    private fun elapsedMs(): Long =
        timerAccumulatedMs + if (timerRunning) SystemClock.elapsedRealtime() - timerStartedAt else 0L

    private fun updateTimerText() {
        timerText.text = formatTime(elapsedMs())
    }

    private fun formatTime(ms: Long): String {
        val totalSeconds = ms / 1000
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60
        return if (hours > 0) {
            String.format("%d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format("%02d:%02d", minutes, seconds)
        }
    }

    companion object {
        const val EXTRA_IMAGE_PATH = "extra_image_path"
        const val EXTRA_PIECE_COUNT = "extra_piece_count"
        const val EXTRA_ROTATE_PIECES = "extra_rotate_pieces"

        private const val MAX_PHOTO_DIMENSION = 2048
        private const val PREVIEW_MAX_SIDE = 900f
        private const val HINT_SECONDS = 8

        private const val PREFS_NAME = "photo_puzzle_look"
        private const val KEY_CAMERA = "camera_angle"
        private const val KEY_TABLE = "tabletop"

        private const val SWATCH_DP = 40f
        private const val SWATCH_GAP_DP = 5f

        /** The picker's side margins (2 x 12dp) plus its padding (2 x 8dp). */
        private const val PICKER_EDGE_DP = 40f
        private const val PICKER_SECONDS = 6
        private const val LABEL_MILLIS = 1500L
    }
}
