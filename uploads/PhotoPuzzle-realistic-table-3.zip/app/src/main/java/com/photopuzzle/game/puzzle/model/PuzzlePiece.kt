package com.photopuzzle.game.puzzle.model

import com.photopuzzle.game.puzzle.geometry.PieceMeshData

/**
 * Immutable geometry of one piece: its outline relative to its own cell centre (x / z pairs,
 * z pointing down the screen), plus the 3D mesh built from that outline.
 *
 * [cellWidth] / [cellHeight] size the grid of [loadPoints]: the spots that stand in for the
 * piece's footprint when the heap is worked out (what it rests on, whether it balances).
 */
internal class PieceShape(
    val polygon: FloatArray,
    val mesh: PieceMeshData,
    cellWidth: Float,
    cellHeight: Float
) {

    val boundingRadius: Float
    val minX: Float
    val maxX: Float
    val minZ: Float
    val maxZ: Float

    /** x / z pairs inside the outline, spread evenly over the body (sockets are skipped). */
    val loadPoints: FloatArray

    init {
        var lowX = Float.MAX_VALUE
        var highX = -Float.MAX_VALUE
        var lowZ = Float.MAX_VALUE
        var highZ = -Float.MAX_VALUE
        var radiusSquared = 0f
        for (i in 0 until polygon.size / 2) {
            val x = polygon[i * 2]
            val z = polygon[i * 2 + 1]
            if (x < lowX) lowX = x
            if (x > highX) highX = x
            if (z < lowZ) lowZ = z
            if (z > highZ) highZ = z
            val d = x * x + z * z
            if (d > radiusSquared) radiusSquared = d
        }
        minX = lowX
        maxX = highX
        minZ = lowZ
        maxZ = highZ
        boundingRadius = kotlin.math.sqrt(radiusSquared)
        loadPoints = buildLoadPoints(cellWidth, cellHeight)
    }

    private fun buildLoadPoints(cellWidth: Float, cellHeight: Float): FloatArray {
        val found = FloatArray(LOAD_GRID * LOAD_GRID * 2)
        var count = 0
        for (iz in 0 until LOAD_GRID) {
            for (ix in 0 until LOAD_GRID) {
                val x = (ix - (LOAD_GRID - 1) * 0.5f) * LOAD_SPACING * cellWidth
                val z = (iz - (LOAD_GRID - 1) * 0.5f) * LOAD_SPACING * cellHeight
                if (contains(x, z)) {
                    found[count++] = x
                    found[count++] = z
                }
            }
        }
        // A pathological outline: fall back to the middle and four spots around it.
        if (count < 6) {
            val dx = 0.25f * cellWidth
            val dz = 0.25f * cellHeight
            return floatArrayOf(0f, 0f, dx, dz, -dx, dz, dx, -dz, -dx, -dz)
        }
        return found.copyOf(count)
    }

    /** Even-odd point-in-polygon test in the piece's own frame. */
    fun contains(lx: Float, lz: Float): Boolean {
        var inside = false
        val n = polygon.size / 2
        var j = n - 1
        for (i in 0 until n) {
            val xi = polygon[i * 2]
            val zi = polygon[i * 2 + 1]
            val xj = polygon[j * 2]
            val zj = polygon[j * 2 + 1]
            if ((zi > lz) != (zj > lz) && lx < (xj - xi) * (lz - zi) / (zj - zi) + xi) {
                inside = !inside
            }
            j = i
        }
        return inside
    }

    private companion object {
        /** Load points form a LOAD_GRID x LOAD_GRID lattice, LOAD_SPACING of a cell apart. */
        const val LOAD_GRID = 5
        const val LOAD_SPACING = 0.2f
    }
}

/**
 * One piece on the table. (x, z) is where its cell centre lies, [angle] how far it is turned
 * (clockwise-positive, radians). The anim* fields are a purely visual offset that eases back
 * to zero, so a logical change of pose (snapping into place, the opening pour, the final
 * straightening) glides instead of jumping.
 */
internal class PuzzlePiece(
    val id: Int,
    val row: Int,
    val col: Int,
    /** Cell centre in the assembled picture, relative to the picture's centre. */
    val homeX: Float,
    val homeZ: Float,
    val shape: PieceShape
) {
    var x = 0f
    var z = 0f
    var angle = 0f

    var animX = 0f
    var animZ = 0f
    var animAngle = 0f

    /** Seconds before the visual offset starts easing out (staggers the opening pour). */
    var animDelay = 0f

    lateinit var group: PieceGroup

    val visualX: Float get() = x + animX
    val visualZ: Float get() = z + animZ
    val visualAngle: Float get() = angle + animAngle
}

/**
 * Pieces joined together; they move and turn as one rigid body.
 *
 * A group lies on a plane: [lift] is the height of that plane above the table at the group's
 * centre, [tiltX] / [tiltZ] how much the height changes per unit moved along x / z (a group
 * leaning on the edge of another piece is tilted).
 */
internal class PieceGroup(first: PuzzlePiece) {
    val pieces = ArrayList<PuzzlePiece>()

    /** True while a finger holds the group: it hovers over the heap and supports nothing. */
    var held = false

    // What is drawn right now (eased every frame) ...
    var lift = 0f
    var liftVelocity = 0f
    var tiltX = 0f
    var tiltZ = 0f

    // ... and what it is easing towards.
    var liftTarget = 0f
    var tiltTargetX = 0f
    var tiltTargetZ = 0f

    /** Height of the surface the group rests on (or hovers over); its shadow falls there. */
    var supportY = 0f

    // Where the group came to rest: the plane through (poseX, poseZ) at height restLift.
    var restLift = 0f
    var restSlopeX = 0f
    var restSlopeZ = 0f
    var poseX = 0f
    var poseZ = 0f

    init {
        pieces.add(first)
        first.group = this
    }
}
