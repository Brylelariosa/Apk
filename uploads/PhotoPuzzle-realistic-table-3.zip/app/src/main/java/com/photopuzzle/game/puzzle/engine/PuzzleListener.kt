package com.photopuzzle.game.puzzle.engine

/**
 * What the table tells the screen around it. Every call arrives on the GL thread, so an
 * implementation that touches views must hop to the main thread itself.
 */
interface PuzzleListener {
    /** The pieces are cut and on the table. */
    fun onReady()

    /** [joined] pieces are currently attached to at least one other piece, out of [total]. */
    fun onProgress(joined: Int, total: Int)

    fun onPieceLifted()

    /** Lifting a piece took the support from others: part of the heap just fell in. */
    fun onPileCollapsed() {}

    /** Two or more pieces just clicked together. */
    fun onPieceJoined()

    /** The player began turning a piece by its edge. */
    fun onTurnStarted()

    /** The last piece went in; the finished picture is straightening itself. */
    fun onCelebrationStarted()

    /** The celebration has played out; time for the results screen. */
    fun onSolved()

    /** The puzzle could not be built (for example, the device ran out of memory). */
    fun onFailed()
}
