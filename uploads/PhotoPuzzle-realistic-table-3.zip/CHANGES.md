# What changed in 2.1

## Piles behave like piles
* Pieces now have real heights. A piece dropped on others rests on top of them, and a piece that
  overlaps the edge of another one leans on it (`model/PileStacker.kt`).
* Lift a piece out from under others and whatever rested on it falls (gravity, a soft thud) and
  re-settles on what is left underneath.
* A piece whose centre hangs past the edge of the piece below slides off and lies down instead of
  balancing there.
* Tuning knobs live at the bottom of `PileStacker.kt` (`FRICTION_SLOPE`, `SLIDE_*`) and in
  `PuzzleEngine` (`FALL_GRAVITY`, `TILT_RATE`).
* Picking follows the finger through each piece's own height, so the piece you see under your
  finger is the piece you get.

## Moving no longer turns
* One finger on a piece only ever moves it.
* To turn: hold a piece and twist a second finger anywhere (the piece pivots about the first
  finger), or switch on "edge turning" (bottom-left button) for the old rim-swipe turn.

## More camera angles (bottom-right camera button)
Classic, Top view, Low angle, Left corner, Right corner, Wide lens, Isometric
(`engine/CameraPreset.kt`). The choice is remembered.

## More tables (bottom-left table button)
Walnut (the original), Cherry, Oak, Driftwood, Ebony, Green felt, Navy felt, Marble, Slate, Linen,
Gingham (`render3d/TableStyles.kt`; patterns are in the table shader). The choice is remembered.
