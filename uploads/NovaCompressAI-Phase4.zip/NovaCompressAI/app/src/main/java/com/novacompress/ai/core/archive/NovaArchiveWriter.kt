package com.novacompress.ai.core.archive

import com.novacompress.ai.core.common.BinaryIO
import com.novacompress.ai.core.common.Constants
import com.novacompress.ai.core.genome.CompressionGenome
import com.novacompress.ai.core.pipeline.CompressionPipeline
import com.novacompress.ai.core.verification.VerificationEngine
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.security.MessageDigest

/** Thrown when a chunk fails its round-trip self-check during writing. The archive is never finalized in this case. */
class PipelineVerificationException(message: String) : Exception(message)

/**
 * Writes a .nova archive to [output], reading the original data from
 * [input] in bounded [chunkSize] pieces so peak memory stays roughly
 * constant regardless of file size (never loading the whole file into RAM).
 *
 * Every chunk is round-trip verified (compress -> decompress -> compare)
 * before its compressed bytes are written out. If verification ever fails,
 * this throws [PipelineVerificationException] immediately rather than
 * writing untrustworthy data - callers are expected to write to a temp
 * file and only move it into place after [write] returns successfully.
 */
object NovaArchiveWriter {

    fun write(
        output: OutputStream,
        input: InputStream,
        originalFileName: String,
        originalSize: Long,
        genome: CompressionGenome,
        chunkSize: Int = Constants.DEFAULT_CHUNK_SIZE
    ): ArchiveMetadata {
        val chunkCount = if (originalSize == 0L) 0 else ((originalSize + chunkSize - 1) / chunkSize).toInt()

        val metadata = ArchiveMetadata(
            originalFileName = originalFileName,
            originalSize = originalSize,
            chunkSize = chunkSize,
            chunkCount = chunkCount,
            createdAtEpochMillis = System.currentTimeMillis(),
            genomeId = genome.genomeId,
            pipelinePluginIds = genome.pipeline.pluginIds
        )

        output.write(NovaArchiveFormat.MAGIC)
        output.write(Constants.ARCHIVE_FORMAT_VERSION)

        val metaBytes = ArchiveMetadataCodec.encode(metadata)
        writeU32Direct(output, metaBytes.size)
        output.write(metaBytes)
        writeU32Direct(output, chunkCount)

        val pipeline = CompressionPipeline(genome.pipeline)
        val wholeDigest = MessageDigest.getInstance("SHA-256")
        val buffer = ByteArray(chunkSize)

        var chunksWritten = 0
        while (chunksWritten < chunkCount) {
            var readTotal = 0
            while (readTotal < chunkSize) {
                val r = input.read(buffer, readTotal, chunkSize - readTotal)
                if (r == -1) break
                readTotal += r
            }
            if (readTotal == 0) break // stream ended earlier than originalSize claimed; stop gracefully

            val chunk = if (readTotal == buffer.size) buffer else buffer.copyOf(readTotal)
            wholeDigest.update(chunk)

            val compressed = pipeline.compress(chunk)

            // Verify this exact compressed output before trusting it, without
            // recompressing: decompress it right back and compare to the
            // original chunk bytes (plus an independent SHA-256 check).
            val roundTripOk = try {
                val decompressedCheck = pipeline.decompress(compressed)
                decompressedCheck.contentEquals(chunk) &&
                    VerificationEngine.sha256(decompressedCheck).contentEquals(VerificationEngine.sha256(chunk))
            } catch (e: Exception) {
                throw PipelineVerificationException(
                    "Chunk $chunksWritten failed verification with pipeline ${genome.pipeline.describe()}: decompression threw ${e.message}"
                )
            }
            if (!roundTripOk) {
                throw PipelineVerificationException(
                    "Chunk $chunksWritten failed verification with pipeline ${genome.pipeline.describe()}: decompressed output did not match the original."
                )
            }

            val chunkHash = MessageDigest.getInstance("SHA-256").digest(compressed)

            writeU32Direct(output, compressed.size)
            output.write(compressed)
            output.write(chunkHash)

            chunksWritten++
        }

        output.write(wholeDigest.digest())
        output.write(NovaArchiveFormat.FOOTER_MAGIC)
        output.flush()

        return metadata
    }

    private fun writeU32Direct(output: OutputStream, value: Int) {
        val buf = ByteArrayOutputStream(4)
        BinaryIO.writeU32(buf, value)
        output.write(buf.toByteArray())
    }
}
