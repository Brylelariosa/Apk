package com.novacompress.ai.di

import android.content.Context
import com.novacompress.ai.core.evolution.EvolutionEngine
import com.novacompress.ai.core.service.CompressionService
import com.novacompress.ai.core.service.DecompressionService
import com.novacompress.ai.data.database.NovaDatabase
import com.novacompress.ai.data.repository.CompressionRepository
import com.novacompress.ai.data.repository.EvolutionStatsRepository
import com.novacompress.ai.data.repository.KnowledgeMaintenanceService
import com.novacompress.ai.data.repository.RoomGenomeRepository
import com.novacompress.ai.data.repository.SettingsRepository

/**
 * Minimal hand-rolled dependency container for Phases 1-4. The spec allows
 * Hilt "only when necessary" - this handful of singletons wired up in one
 * place doesn't yet justify the extra KSP/annotation-processor surface
 * area, so this stays plain. [BackgroundResearchWorker] reaches this via
 * a plain applicationContext cast rather than constructor injection, which
 * is the point at which Hilt would normally start earning its keep - a
 * reasonable Phase 5+ upgrade once there's a second injected Worker.
 */
class ServiceLocator(context: Context) {
    private val database: NovaDatabase = NovaDatabase.getInstance(context)
    private val genomeRepository = RoomGenomeRepository(database.genomeDao(), database.benchmarkRecordDao())

    val evolutionEngine = EvolutionEngine(genomeRepository)
    val repository: CompressionRepository = CompressionRepository(database.compressionRecordDao())
    val evolutionStatsRepository = EvolutionStatsRepository(database.genomeDao(), database.benchmarkRecordDao())
    val settingsRepository = SettingsRepository(context)
    val knowledgeMaintenanceService = KnowledgeMaintenanceService(
        context = context.applicationContext,
        database = database,
        genomeDao = database.genomeDao(),
        benchmarkRecordDao = database.benchmarkRecordDao()
    )
    val compressionService: CompressionService = CompressionService(evolutionEngine = evolutionEngine)
    val decompressionService: DecompressionService = DecompressionService()
}
