package com.novacompress.ai.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.novacompress.ai.data.repository.SettingsRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(private val settingsRepository: SettingsRepository) : ViewModel() {

    val backgroundLearningEnabled: StateFlow<Boolean> = settingsRepository.backgroundLearningEnabled
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), initialValue = true)

    fun setBackgroundLearningEnabled(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepository.setBackgroundLearningEnabled(enabled)
        }
    }
}
