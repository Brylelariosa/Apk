package com.novacompress.ai

import android.app.Application
import com.novacompress.ai.di.ServiceLocator
import com.novacompress.ai.work.BackgroundResearchScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class NovaCompressApplication : Application() {

    lateinit var serviceLocator: ServiceLocator
        private set

    /** Long-lived scope for reactive, app-lifetime background wiring (not tied to any UI screen). */
    private val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onCreate() {
        super.onCreate()
        serviceLocator = ServiceLocator(this)

        // Reactively enqueue/cancel the background research job as the
        // user's preference changes (including once, right away, using
        // whatever value is currently stored - defaults to enabled).
        applicationScope.launch {
            serviceLocator.settingsRepository.backgroundLearningEnabled.collect { enabled ->
                if (enabled) {
                    BackgroundResearchScheduler.enable(this@NovaCompressApplication)
                } else {
                    BackgroundResearchScheduler.disable(this@NovaCompressApplication)
                }
            }
        }
    }
}
