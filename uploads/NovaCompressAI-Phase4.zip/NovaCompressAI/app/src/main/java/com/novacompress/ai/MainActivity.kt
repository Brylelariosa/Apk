package com.novacompress.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.novacompress.ai.ui.navigation.NovaNavHost
import com.novacompress.ai.ui.theme.NovaCompressTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            NovaCompressTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    NovaNavHost()
                }
            }
        }
    }
}
