package com.novacompress.ai.core.service

import com.novacompress.ai.core.archive.ArchiveMetadata
import com.novacompress.ai.core.archive.ArchiveReadResult
import com.novacompress.ai.core.archive.NovaArchiveReader
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream

sealed class DecompressionOutcome {
    data class Success(val metadata: ArchiveMetadata) : DecompressionOutcome()
    data class Failed(val reason: String) : DecompressionOutcome()
}

/**
 * Orchestrates a full decompress job with the same "never trust unverified
 * output" discipline as [CompressionService]: the temp file is deleted
 * unless [NovaArchiveReader] reports full success.
 */
class DecompressionService {

    fun decompress(openStream: () -> InputStream, tempDestination: File): DecompressionOutcome {
        return try {
            openStream().use { input ->
                FileOutputStream(tempDestination).use { output ->
                    when (val result = NovaArchiveReader.readAndVerify(input, output)) {
                        is ArchiveReadResult.Success -> DecompressionOutcome.Success(result.metadata)
                        is ArchiveReadResult.Corrupted -> {
                            tempDestination.delete()
                            DecompressionOutcome.Failed(result.reason)
                        }
                    }
                }
            }
        } catch (e: Exception) {
            tempDestination.delete()
            DecompressionOutcome.Failed(e.message ?: "Unknown error while decompressing.")
        }
    }
}
