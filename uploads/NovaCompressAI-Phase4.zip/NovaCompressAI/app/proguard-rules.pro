# Phase 1: release minification (isMinifyEnabled) is currently disabled in
# app/build.gradle.kts, so this file has no effect yet. It is kept in place,
# wired into the release buildType, so that enabling R8 shrinking in a later
# phase is a one-line change plus filling in keep rules below for:
#   - Room entities / DAOs (androidx.room:room-runtime already ships consumer rules)
#   - Compression plugin classes discovered via PluginRegistry
#   - Kotlinx serialization models used by the Nova archive metadata block
