# NovaCompress AI — Phase Progress

Tracking status against the full multi-part master spec. Each phase is only
marked done when it is fully generated, internally reviewed, and (where
this sandbox allows) tested — never partially.

## Phase 1 — Core Engine & Minimal Working App — ✅ DONE

- File Analyzer (entropy, histogram, run-length score, repeated-block score)
- 4 compression plugins: Delta, RLE, Huffman, LZ77 (all Python-prototyped
  and round-trip-tested before porting to Kotlin)
- Pipeline engine (chains plugins, reverses correctly)
- 4 hand-crafted genome presets + heuristic selector (behind a
  `GenomeSelector` interface so Phase 2's real Evolution Engine slots in
  without touching callers)
- Verification Engine enforcing compress→decompress→compare→SHA-256 before
  any chunk is trusted
- Full streaming, chunked `.nova` archive format v1 with per-chunk and
  whole-file SHA-256, corruption detection, truncation detection
- Room database for compression history; Dashboard/Compress/Decompress/
  Settings Compose screens
- JUnit tests covering every plugin, pipeline combination, and the archive
  format (including deliberate corruption injection); GitHub Actions CI
  workflow (regenerates the Gradle wrapper, runs tests, assembles a debug
  APK). See the Phase 2 entry below for the corrected, accurate test count.

## Phase 2 — Genome Evolution & Real Benchmark Laboratory — ✅ DONE

- **Real Benchmark Laboratory**: every candidate genome is actually
  compressed, decompressed, timed (`System.nanoTime()`), and verified
  against the real file sample - no estimates, no guessing.
- **Real Evolution Engine**: `MutationEngine` (insert/delete/swap/replace,
  always producing a structurally valid, duplicate-free pipeline) and
  `CrossoverEngine` (single-point recombination of two parent pipelines,
  de-duplicated). Every compression job benchmarks the best 3 known
  genomes plus a fresh mutation and a fresh crossover child, records
  *every* result as knowledge (win or lose), and picks the genuinely
  measured winner.
- **Multidimensional fitness**: `FitnessCalculator` combines ratio with a
  speed penalty, matching the spec's "Compression Ratio x ... x Reliability
  x ... x Battery Score" idea in a simplified, explainable form.
- **Knowledge Database expansion**: new `genomes` and `benchmark_records`
  Room tables. Genomes carry generation, species (classified from which
  plugins they use), lifecycle status (Experimental -> Verified -> Stable
  -> Elite -> Retired), and parent lineage.
- **Fixed a real spec-compliance gap while building this**: the master
  spec explicitly requires rejecting duplicate-plugin pipelines during
  validation, which Phase 1 hadn't enforced. Added the check to
  `PipelineDescriptor`, which required corresponding fixes to
  `MutationEngine` (only insert/replace with an unused plugin) and
  `CrossoverEngine` (de-duplicate overlapping parent plugins) so neither
  could ever attempt to construct an invalid pipeline.
- **New plugin**: Move-To-Front (Python-prototyped and round-trip-tested
  first, like every other plugin). Burrows-Wheeler Transform, Arithmetic
  Coding, and Predictive Coding are deliberately deferred - see the Phase 3
  note below for why.
- **Dashboard now shows real population growth**: "Genomes Discovered" and
  "Benchmarks Run" stat cards, reactively observed from Room.
- `EvolutionEngine`'s logic is tested against an `InMemoryGenomeRepository`
  fake (Room's SQLite backing doesn't work in plain JVM unit tests without
  Robolectric, and the evolutionary logic has nothing to do with SQL) - the
  production `RoomGenomeRepository` implements the same interface.
- 20 net new test methods this phase (19 in new Phase 2 test files, plus 1
  added to Phase 1's `CompressionPipelineTest` for the duplicate-rejection
  fix above) - 50 test methods total across the project now. Phase 1's
  chat summary said 68, which was a miscount; 50 is the accurate, verified
  number, and many methods loop over 14 shared samples internally rather
  than being one-scenario-per-method.

## Phase 3 — More Plugins, Research Dashboard & Visualization — ✅ DONE

- **Burrows-Wheeler Transform**: built the way it deserved - a suffix array
  of the cyclic rotations via prefix-doubling (no sentinel byte needed,
  since every byte value 0-255 is already valid input), cross-validated
  byte-for-byte against a brute-force textbook reference implementation
  across 509 small inputs before being ported to Kotlin, then round-trip
  tested on periodic/large/random data. Paired with Move-To-Front into a
  new "Block Sorting" genome preset (the classic bzip2-style pipeline).
- **Arithmetic Coding**: classic Witten-Neal-Cleary integer coder with
  E1/E2/E3 underflow handling. Stress-tested in Python across 300 random
  alphabet-size/length combinations before porting; the Kotlin port uses
  `Long` throughout since intermediate products reach ~2^50 and would
  overflow a 32-bit `Int`. Powers a new "Research Mode" preset.
  "Bit Packing" (a separate catalog entry in the spec, for densely packing
  known-small-range values) is still deferred - it wasn't needed for any
  plugin built so far and deserves its own use case to design around
  rather than being added speculatively.
- **Predictive Coding**: a second-order linear predictor, genuinely
  different from Delta's first-order approach (handles linear trends -
  sensor readings, audio envelopes - rather than just slowly-changing
  values; confirmed empirically that it zeros out 767/768 residuals on a
  clean linear ramp). Powers a new "Signal Optimized" preset.
- **8 plugins registered now**: Delta, RLE, Huffman, LZ77, MTF, BWT,
  Arithmetic, Predictive. 7 genome presets seed the population.
- **Research Lab screen** (5th bottom-nav destination): Species breakdown
  with a real (if simple, dependency-free) bar chart built from proportional
  Compose boxes, and a Genome Explorer list (sorted by fitness, tap to
  expand for rationale + parent lineage), reactively observed from Room.
- **Archive Inspector**: `NovaArchiveInspector.peek()` reads just the magic
  header + metadata block of a `.nova` file - original filename/size,
  pipeline, chunk count - without touching any chunk data or verifying
  hashes. Wired into the Decompress screen as an "Inspect Archive" button
  before committing to a full decompress.
- 17 new test methods (67 total now), including a from-scratch
  brute-force BWT reference implementation used only in tests, and a
  150-configuration arithmetic-coding stress test mirroring the Python
  prototype's validation methodology.
- What's *not* here: the full Evolution Timeline / Mutation Viewer /
  AI Brain Visualization / interactive zoomable charts from the spec's UI
  parts - those are meaningful polish, not core functionality, and fit
  better in Phase 7 (Developer Mode) once there's more benchmark history
  to visualize meaningfully.

## Phase 4 — Android Runtime Maturity — ✅ DONE

- **Battery/Thermal/Memory awareness**: real Android-backed providers
  (`BatteryManager.BATTERY_PROPERTY_STATUS`/`_CAPACITY`,
  `PowerManager.currentThermalStatus` with a graceful pre-API-29
  fallback, `ActivityManager.MemoryInfo.lowMemory`) feeding a pure-Kotlin
  `ResearchScheduler` that decides whether background research may run
  right now - fully unit tested against fake providers.
- **Real background research via WorkManager**: a periodic
  `BackgroundResearchWorker` (charging + battery-not-low as WorkManager's
  own constraints, thermal/memory re-checked inside `doWork` since
  WorkManager has no built-in constraint for either) runs
  `BackgroundResearchRunner` against synthetic samples (random/repetitive/
  text-like/structured byte patterns - there's no real user file to
  research against between compression jobs) through the same
  `EvolutionEngine` a live compression job uses. Reactively enqueued/
  cancelled based on a DataStore-backed "Background Learning" toggle in
  Settings (the first setting that actually controls something).
- **Fixed an unbounded-growth bug caught during review**: background
  research running every 6 hours forever, with nothing capping the
  Knowledge Database, would have grown storage indefinitely - directly
  contradicting the spec's own explicit "Knowledge database Maximum 128 MB"
  and "Population: Normal 500 genomes" limits. Added
  `KnowledgeMaintenanceService`, run as part of every background research
  pass: prunes benchmark records older than 30 days, retires (not deletes -
  matching the spec's "not deleted immediately... move to Archive")
  the weakest genomes beyond the 500-genome cap, and runs `VACUUM` if the
  database file is still over 128 MB after pruning.
- 9 new test methods for `ResearchScheduler` and the background research
  pass logic (76 total now). `KnowledgeMaintenanceService` itself isn't
  directly unit tested - like `RoomGenomeRepository`, it's a thin,
  carefully-reviewed wrapper over a few individually-simple Room queries
  (deliberately avoiding one complex correlated-subquery UPDATE in favor of
  three obviously-correct ones) rather than logic dense enough to warrant
  its own interface+fake abstraction.
- Hilt is still deferred - `BackgroundResearchWorker` reaches
  `ServiceLocator` via an `applicationContext` cast rather than
  constructor injection, which works fine for one Worker with no
  constructor dependencies of its own.

## Phase 5 — Archive Format Completion — planned next

- Checkpointing/resume for interrupted compression or research jobs -
  originally planned for Phase 4, carried forward: Phase 4's actual review
  turned up the storage-bounding gap instead, which took priority since
  unbounded growth affects every user automatically, while an interrupted-
  job resume only matters for the (much rarer) case of a crash or reboot
  mid-compression.
- Multi-file archives, dictionary section, recovery/repair mode
- Archive Export/Import (`.nova-backup`)
- R8/minification enabled with real keep rules

## Phase 6 — Plugin SDK & External Integration — planned

- Formal Plugin SDK (`PluginContext`, sandboxing, automatic plugin testing
  against the standard corpus: random/repeated/binary/APK/ROM/etc.)
- "Share to compress" / "Open with" external intents (removed from Phase 1's
  manifest deliberately until the handling code exists — see README)

## Phase 7 — Developer Mode & Polish — planned

- Genome/Pipeline/Plugin/Database inspectors, live thread/memory monitors
- Full Settings categories (research budget, thermal/battery limits, plugin
  permissions)
- Tablet/landscape layouts, accessibility pass
