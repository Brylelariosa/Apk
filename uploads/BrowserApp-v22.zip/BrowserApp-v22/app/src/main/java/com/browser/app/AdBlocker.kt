package com.browser.app

import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream

/**
 * Lightweight host-based ad / tracker blocker + data-saver interceptor.
 *
 * shouldBlock()             – used for the ad-blocker feature
 * shouldBlockForDataSaver() – blocks resources based on data-saver level:
 *   1 = High Quality   → block 3rd-party fonts + video only
 *   2 = Medium Quality → block 3rd-party images + fonts + video
 *   3 = Low Quality    → block ALL images + fonts + video
 *   4 = No Images      → block ALL images (loadsImagesAutomatically=false
 *                         handles most; interceptor catches edge cases)
 */
object AdBlocker {

    // ── Ad / tracker domain blocklist ────────────────────────────────
    private val BLOCKED_HOSTS: Set<String> = hashSetOf(
        // Google advertising
        "googleadservices.com", "googlesyndication.com", "googletagservices.com",
        "pagead2.googlesyndication.com", "adservice.google.com",
        "doubleclick.net", "ad.doubleclick.net", "stats.g.doubleclick.net",
        // Google Analytics / Tag Manager
        "google-analytics.com", "ssl.google-analytics.com",
        "googletagmanager.com", "www.googletagmanager.com",
        // Facebook / Meta
        "connect.facebook.net", "an.facebook.com",
        "pixel.facebook.com",
        // Amazon Ads
        "amazon-adsystem.com", "aax.amazon-adsystem.com",
        "fls-na.amazon-adsystem.com",
        // AppNexus / Xandr
        "adnxs.com", "ib.adnxs.com",
        // Rubicon / Magnite
        "rubiconproject.com", "fastlane.rubiconproject.com",
        // OpenX
        "openx.net", "openx.com", "us-u.openx.net",
        // PubMatic
        "pubmatic.com", "ads.pubmatic.com",
        // Criteo
        "criteo.com", "criteo.net", "static.criteo.net",
        // Index Exchange
        "casalemedia.com", "sas.casalemedia.com",
        // The Trade Desk
        "adsrvr.org",
        // MediaMath
        "turn.com",
        // Outbrain / Taboola
        "taboola.com", "cdn.taboola.com", "trc.taboola.com",
        "outbrain.com", "widgets.outbrain.com",
        "revcontent.com",
        // Advertising.com / AOL
        "advertising.com",
        // Yieldmo
        "yieldmo.com",
        // Sharethrough
        "sharethrough.com",
        // TripleLift
        "triplelift.com",
        // Conversant
        "conversantmedia.com",
        // Lotame
        "crwdcntrl.net",
        // ScoreCard Research
        "scorecardresearch.com",
        // Quantcast
        "quantserve.com",
        // Nielsen
        "imrworldwide.com",
        // Moat
        "moat.com",
        // Integral Ad Science
        "adsafeprotected.com",
        // DoubleVerify
        "doubleverify.com",
        // TrafficJunky / adult ad networks
        "trafficjunky.net", "trafficjunky.com",
        "exoclick.com",
        "juicyads.com",
        "adsterra.com",
        "propellerads.com",
        // Analytics / session recorders
        "mixpanel.com", "api.mixpanel.com",
        "amplitude.com", "api.amplitude.com",
        "hotjar.com", "static.hotjar.com",
        "segment.io", "api.segment.io",
        "segment.com", "cdn.segment.com",
        "heap.io", "heapanalytics.com",
        "fullstory.com", "edge.fullstory.com",
        "mouseflow.com",
        "logrocket.com",
        "rlcdn.com",
        // Malware redirectors / push notification spam
        "rlcdn.com",
        // Chartbeat
        "chartbeat.com", "static.chartbeat.com",
        // ComScore
        "comscore.com",
        // Parse.ly
        "parsely.com",
        // Disqus tracking
        "disqus.com",
        // Twitter/X advertising
        "ads.twitter.com", "analytics.twitter.com",
        "p.twitter.com",
        // LinkedIn Insight Tag
        "snap.licdn.com", "platform.linkedin.com",
        // Pinterest ads
        "log.pinterest.com", "ads.pinterest.com",
        // TikTok pixel
        "analytics.tiktok.com",
        // Pop-under / click-redirect ad networks (common cause of gambling redirects)
        "popads.net", "popcash.net", "clickadu.com", "hilltopads.net",
        "admaven.com", "bidvertiser.com", "monetizer101.com", "evadav.com",
        "adcash.com", "zeropark.com", "adskeeper.com", "kadam.net",
        "richpush.co", "pushground.com", "megapu.sh", "datspush.com",
        "coinis.com", "admaven.com", "traffic-stars.com", "trafficshop.com",
        "clicksfly.com", "shorte.st", "ouo.io", "adf.ly",
        // Fake prize / survey redirectors
        "youhaveprize.com", "win-prize.net", "surprisegifts.net",
        // Additional adult ad networks
        "ero-advertising.com", "juicyadsnw.com", "plugrush.com",
        "beachfront.com", "adnium.com",
    )

    private val IMAGE_EXT = setOf(
        ".jpg", ".jpeg", ".png", ".gif", ".webp",
        ".avif", ".svg", ".bmp", ".ico"
    )
    private val FONT_EXT  = setOf(".woff", ".woff2", ".ttf", ".otf", ".eot")
    private val VIDEO_EXT = setOf(
        ".mp4", ".webm", ".ogg", ".avi", ".mov",
        ".m3u8", ".ts"
    )

    private val EMPTY = WebResourceResponse(
        "text/plain", "utf-8", ByteArrayInputStream(ByteArray(0))
    )

    // ── Public API ────────────────────────────────────────────────────

    fun shouldBlock(request: WebResourceRequest, pageHost: String?): Boolean {
        val host = request.url?.host?.removePrefix("www.") ?: return false
        val page = pageHost?.removePrefix("www.") ?: ""
        if (page.isNotEmpty() && (host == page || host.endsWith(".$page"))) return false
        return BLOCKED_HOSTS.any { blocked ->
            host == blocked || host.endsWith(".$blocked")
        }
    }

    /**
     * Used by shouldOverrideUrlLoading to catch JS redirects and click-hijacks
     * that bypass shouldInterceptRequest (which only sees sub-resources).
     * Returns true if the navigation target is a known ad/tracker/redirect domain.
     */
    fun shouldBlockNavigation(host: String?): Boolean {
        val h = host?.removePrefix("www.") ?: return false
        return BLOCKED_HOSTS.any { blocked -> h == blocked || h.endsWith(".$blocked") }
    }

    /**
     * Data-saver interceptor.
     * level: 0=Off, 1=High, 2=Medium, 3=Low, 4=NoImages
     */
    fun shouldBlockForDataSaver(
        request: WebResourceRequest,
        pageHost: String?,
        level: Int
    ): Boolean {
        if (level == 0) return false
        val url   = request.url  ?: return false
        val host  = url.host?.removePrefix("www.") ?: return false
        val path  = url.path?.lowercase() ?: ""
        val page  = pageHost?.removePrefix("www.") ?: ""

        val isSameOrigin = page.isNotEmpty() &&
            (host == page || host.endsWith(".$page") || page.endsWith(".$host"))

        val isImage = IMAGE_EXT.any { path.endsWith(it) }
        val isFont  = FONT_EXT.any  { path.endsWith(it) }
        val isVideo = VIDEO_EXT.any { path.endsWith(it) }

        return when (level) {
            // High Quality — block 3rd-party fonts + video only
            1 -> !isSameOrigin && (isFont || isVideo)

            // Medium Quality — block 3rd-party images + fonts + video
            2 -> !isSameOrigin && (isImage || isFont || isVideo)

            // Low Quality — block ALL images + fonts + video
            3 -> isImage || isFont || isVideo

            // No Images — block ALL image requests
            // (WebSettings.loadsImagesAutomatically=false handles most,
            //  this catches any that slip through)
            4 -> isImage

            else -> false
        }
    }

    fun emptyResponse(): WebResourceResponse = EMPTY
}
