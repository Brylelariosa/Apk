package com.browser.app

import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

data class HistoryEntry(
    val url: String,
    val title: String,
    val timestamp: Long
)

class HistoryManager(private val prefs: SharedPreferences) {

    companion object { private const val MAX = 500 }

    fun record(url: String, title: String) {
        if (url.isBlank() || url.startsWith("data:") || url.startsWith("file:") ||
            url.startsWith("https://home.local")) return
        val list = getAll().toMutableList()
        // move to top if already present
        list.removeAll { it.url == url }
        list.add(0, HistoryEntry(url, title.ifBlank { url }, System.currentTimeMillis()))
        if (list.size > MAX) list.subList(MAX, list.size).clear()
        save(list)
    }

    fun getAll(): List<HistoryEntry> {
        val json = prefs.getString("history_v2", "[]") ?: "[]"
        return try {
            val arr = JSONArray(json)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                HistoryEntry(o.optString("url"), o.optString("title", o.optString("url")), o.optLong("ts", 0L))
            }
        } catch (_: Exception) { emptyList() }
    }

    fun search(query: String): List<HistoryEntry> {
        if (query.isBlank()) return getAll()
        val q = query.lowercase()
        return getAll().filter { it.title.lowercase().contains(q) || it.url.lowercase().contains(q) }
    }

    fun remove(url: String) { save(getAll().filter { it.url != url }) }

    fun clear() { prefs.edit().remove("history_v2").apply() }

    /** Group entries: "Today", "Yesterday", "This Week", "Older" */
    fun getGrouped(): List<Pair<String, List<HistoryEntry>>> {
        val all = getAll()
        if (all.isEmpty()) return emptyList()
        val now   = System.currentTimeMillis()
        val day   = 86_400_000L
        val today = now - (now % day) - java.util.TimeZone.getDefault().getOffset(now)
        fun bucket(ts: Long) = when {
            ts >= today          -> "Today"
            ts >= today - day    -> "Yesterday"
            ts >= today - 6*day  -> "This Week"
            else                 -> "Older"
        }
        return all.groupBy { bucket(it.timestamp) }
            .entries
            .sortedBy { listOf("Today","Yesterday","This Week","Older").indexOf(it.key) }
            .map { it.key to it.value }
    }

    private fun save(list: List<HistoryEntry>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("url", it.url).put("title", it.title).put("ts", it.timestamp)) }
        prefs.edit().putString("history_v2", arr.toString()).apply()
    }
}
