package com.browser.app

import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

data class Bookmark(
    val url: String,
    val title: String,
    val timestamp: Long = System.currentTimeMillis()
)

class BookmarkManager(private val prefs: SharedPreferences) {

    fun getAll(): List<Bookmark> {
        val json = prefs.getString("bookmarks_v2", "[]") ?: "[]"
        return try {
            val arr = JSONArray(json)
            (0 until arr.length()).map { arr.getJSONObject(it).toBookmark() }
        } catch (_: Exception) { emptyList() }
    }

    fun add(url: String, title: String) {
        val list = getAll().toMutableList()
        if (list.any { it.url == url }) return
        list.add(0, Bookmark(url, title.ifBlank { url }, System.currentTimeMillis()))
        save(list)
    }

    fun remove(url: String) { save(getAll().filter { it.url != url }) }

    fun isBookmarked(url: String) = getAll().any { it.url == url }

    fun search(query: String): List<Bookmark> {
        if (query.isBlank()) return getAll()
        val q = query.lowercase()
        return getAll().filter { it.title.lowercase().contains(q) || it.url.lowercase().contains(q) }
    }

    private fun save(list: List<Bookmark>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("url", it.url).put("title", it.title).put("ts", it.timestamp))
        }
        prefs.edit().putString("bookmarks_v2", arr.toString()).apply()
    }

    private fun JSONObject.toBookmark() = Bookmark(
        url       = optString("url"),
        title     = optString("title", optString("url")),
        timestamp = optLong("ts", 0L)
    )
}
