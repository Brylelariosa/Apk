package com.browser.app

import android.content.Context
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.webkit.WebView

class ScrollAwareWebView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : WebView(context, attrs, defStyleAttr) {

    var onScrollCallback: ((dy: Int) -> Unit)? = null

    /**
     * Invoked after onCreateInputConnection returns a non-null IC and the
     * IMM has had a chance (50 ms) to register it.
     */
    var onWebInputFocused: (() -> Unit)? = null
    var onDebugEvent: ((String) -> Unit)? = null

    /** Fires when user pulls down from the very top of the page. */
    var onPullToRefresh: (() -> Unit)? = null

    private var pullStartY = -1f
    private var pullRefreshFired = false
    private val PULL_THRESHOLD_DP = 120f
    private val pullThresholdPx get() = PULL_THRESHOLD_DP * resources.displayMetrics.density

    override fun onScrollChanged(l: Int, t: Int, oldl: Int, oldt: Int) {
        super.onScrollChanged(l, t, oldl, oldt)
        onScrollCallback?.invoke(t - oldt)
    }

    override fun onCheckIsTextEditor(): Boolean = true

    override fun onCreateInputConnection(outAttrs: EditorInfo): InputConnection? {
        val ic = super.onCreateInputConnection(outAttrs)
        onDebugEvent?.invoke("onCreateIC: ic=${if (ic != null) "OK" else "NULL"}")
        if (ic != null) {
            postDelayed({ onWebInputFocused?.invoke() }, 50)
        }
        return ic
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        // Pull-to-refresh detection when page is at the very top
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                pullRefreshFired = false
                pullStartY = if (scrollY == 0) ev.y else -1f
            }
            MotionEvent.ACTION_MOVE -> {
                if (!pullRefreshFired && pullStartY >= 0 && scrollY == 0) {
                    val delta = ev.y - pullStartY
                    if (delta > pullThresholdPx) {
                        pullRefreshFired = true
                        onPullToRefresh?.invoke()
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                pullStartY = -1f; pullRefreshFired = false
            }
        }
        return super.onTouchEvent(ev)
    }
}
