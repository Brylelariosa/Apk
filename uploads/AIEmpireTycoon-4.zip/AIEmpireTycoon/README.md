# AI Empire Tycoon

An original idle tycoon for Android. You found **Lumora AI**, a tiny fictional AI startup, and grow it into a global
corporation: research new technology, train and release ten generations of AI models (BasicBot to SuperAI), earn from six
revenue streams, build data centers, open new regions, outpace four rival companies and finally reinvent your company for
permanent bonuses. Every name, brand and number is fictional.

The whole game is HTML/JavaScript in `app/src/main/assets/web` running inside a full-screen WebView. Everything, including all art
(isometric campus, icons, map) and all sound, is generated in code, so the game needs no internet and no permissions.

## Build the APK with the "Build APK" workflow

1. Upload the project zip (for example `AIEmpireTycoon.zip`) to the `uploads/` folder of your repository and commit it.
2. The workflow unzips it, downloads `gradle-wrapper.jar`, runs `./gradlew assembleDebug` and uploads the APK as an artifact
   named `<zip name>-debug-v<run number>`. Set the `KEYSTORE_BASE64`, `STORE_PASSWORD`, `KEY_ALIAS` and `KEY_PASSWORD`
   secrets if you want a signed release build instead.
3. Open the finished run, download the artifact, unzip it and install `app-debug.apk`.

Requirements are the ones your workflow already provides: JDK 17, Gradle 8.6 (wrapper), Android Gradle Plugin 8.2.2,
compileSdk 34, minSdk 24 (Android 7.0+). There is no native code, no external dependency and no `INTERNET` permission.

To build locally: `./gradlew assembleDebug` (needs `gradle/wrapper/gradle-wrapper.jar`; copy it from any Gradle 8.6 project).

## What is new in 1.4 - the game plays itself, and it is fun to watch

* **Lumo, your AI CEO.** A small glowing robot flies around the campus and runs the company the way a sensible player would: it buys servers and
  racks, builds and upgrades buildings, picks research, trains and releases models, opens regions, signs deals and tunes price and marketing, and
  it says out loud what it is about to do before it does it. Every decision is a "what would this do to my income?" question answered by
  the real economy, so Lumo never disagrees with the game. The first time you play, a "Meet Lumo" card asks whether Lumo should run it
  (**Let Lumo run it**) or whether you will play yourself (**I'll play myself**). Tap the Lumo chip any time for the control panel:
  autopilot on or off, style (Cautious, Balanced or Bold), which parts Lumo takes care of (each one can be switched off and done by hand),
  game speed, the cinematic camera, and a log of what Lumo did lately.
* **Game speed 1x / 2x / 4x** (the Speed button on the island, or Lumo's panel). It runs the whole company faster: income, research,
  construction, rivals and the day.
* **A living island.** Staff walk the paths between the buildings (they show their backs when they walk away), cars drive the roads, builders
  hammer at construction sites, customer requests stream down from the sky and become coins flying to your cash counter, drones deliver new
  servers, rival airships drift past, the lamps come on at dusk and the edge of the island drips glowing water.
* **Day and night.** A sun and a moon cross the sky with sunrise and sunset, stars and northern lights at night, birds by day. The cycle follows
  game time, so it runs faster when you speed the game up. Windows light up at dusk.
* **Company stories and milestones.** Every few minutes something happens: a viral video, an investor visit, a heatwave. A card slides in,
  Lumo decides in character, and the result (a timed boost, some cash, a little hype) applies at once. With autopilot off the card waits for you
  and decides for you after a while, so nothing is ever stuck. Reaching user and company-value milestones sets off banners, fireworks and confetti.
* **A cinematic camera.** When Lumo starts on something the camera glides to that building and returns to the whole campus by itself. It never
  fights you: if you are steering the camera it stays where it is. Switch it off in Lumo's panel.
* **Every building was redrawn and brought to life.** The headquarters (garage, startup office, office block, corporate tower, the Spire), the
  research lab (three tiers), the server closet, all five data halls (cut-away glass halls with racks, cold aisles, cable trays, wall monitors,
  cooling units and a technician walking the aisle), cooling (six tiers, from air fans to zero-point monoliths), power (five tiers, from a transformer
  yard to an orbital power array) and the network tower (six tiers, from a pole to a crystal beacon). Each tier is a different building, not a
  recolour, with things that spin, blink, flow and glow: fans, radar, rotors, steam, cables with light pulses, holograms, orbiting rings,
  satellites. The lights come on at night.
* **New people.** Everyone on the island was redrawn: round heads with big eyes, a dark outline round every shape, seven hair styles and colours,
  caps, glasses, headsets, badges, backpacks, six skin tones, hi-vis vests and hard hats for the builders and the data hall technician. They are
  about as tall as a server rack, walk with a real stride and arm swing, and type at the desks in the garage and the startup office.
* **On the island screen:** the Lumo chip says in words what Lumo is doing right now (tap it for his panel), and the Speed button cycles
  1x, 2x and 4x.
* **Fixed:** a visual effect (an expanding ring) could throw an error after the game had been frozen for a moment, for instance when the phone
  stuttered. Frame times can no longer run backwards.
* Older saves load as they are: everything new starts from its default (autopilot asks on first launch), nothing is lost.

## What was new in 1.3

* **The server room shows your servers.** Every rack has four slots. An empty slot is a dark bay, and every server you own is a lit
  unit in its own colour (steel, blue fans, violet chip, plum neurons, gold beam, frosted quantum, star shard). Buy a rack and a rack
  appears, buy a server and a slot fills, sell one and it empties, with a soft pulse of light over the room when something changes.
  Servers move into the newest room first, best hardware first, so the big room is the one that fills up and the old closet is what
  is left over. The closet shows the same racks through its open door, and its status strip turns red when it holds no servers.
* **Upgrades: a big campus.** The picture at the top of the Upgrades screen is now about 2.5 times taller and is framed on the kind of
  building the list is about, with a dashed outline on the ground and a name tag (the Servers and Racks lists frame the room the
  servers are in). The list scrolls up over the picture and the category chips stay pinned at the top. The picture stops drawing
  while it is scrolled out of sight.
* The walking people were taken off the paths in this version (they came back, redrawn, in 1.4).
* **Global: a turning globe.** The flat map is now a dot-matrix globe that fills the top of the screen. It turns to the region you pick,
  every open region glows in its own colour with a patch that grows with the hub level, data arcs run out from your home market, and
  two satellites circle it. Tap a marker or a chip, or drag to turn it. The big stat grid and the long list of regions are replaced
  by region chips on the globe and one short card (users, reach, hub level, spending, the button); the other numbers are behind
  "More details".
* **Fixed:** after the first visit the Global map was drawn cropped and magnified (the canvas was not resized when the screen was
  rebuilt, which happens every time you tap a region). The globe canvas is now created once and moved between screens.
* **Warning badges on the island.** A power, cooling or overload problem now shows as a small badge over the building at fault.

## What was new in 1.2

* **Upgrades: one list for each kind of upgrade.** Servers, Racks, Data center, Cooling, Power, Network, Office and Labs each have
  their own list, switched with the chips under the campus picture. Every list starts on the first screen, so you never scroll to
  find what to buy: a short status line, at most one red banner, then the rows. Tap the (i) on the status line to read what that
  part of the company is for.
* **Every row says what it does to your money.** Each upgrade has its own picture, a one-line verdict such as
  "+$308/s income, +$89/s costs" (or "Not needed yet" when your servers already serve everyone), and its button. Tap a row for the
  details. The numbers come from running the real economy on a copy of your company, so they match what the game then does.
* **"Holding your income back" banner.** When servers, racks, power, cooling or the data center stop users from being served, one banner
  says so in plain words with a one-tap fix (or a shortcut to the research that unlocks it). It keeps its numbers current by itself.
* **Money screen.** It explains how the company makes money, shows profit right now, and has a ranked list of ideas for earning more.
  Every cost has an explanation of what drives it, what changed lately and how to lower it, so "why did my expenses go up?" has an
  answer.
* **HQ.** A dock under the campus shows income, costs and profit, and whether servers, power and cooling cope. Each part is a
  shortcut to the screen that fixes it.
* **Seven different server tiers.** Entry GPU Server, High-Performance GPU Server, Advanced AI Accelerator, Neuromorphic Accelerator Pod,
  Photonic Compute Core, Quantum Tensor Array and Stellar Compute Shard each have their own shape, colour and lights, both in the data
  halls on the island and on the upgrade cards. Data centers, cooling, power plants, the network tower, offices and labs have a picture
  for every level too.
* **No overlapping buildings.** The server closet no longer sits on top of the office, and buildings are painted in the right order
  at every level of the campus.
* Fixed in the advisor: a what-if could show income that a purchase would not really bring (it compared numbers taken a moment
  apart), and with little cash the "income is held back" banner could disappear.

All names (companies, products, hardware, regions) are fictional.

## What was new in 1.1

* **True full screen.** The game now draws behind the camera cutout (notch or punch hole), so there is no black strip at the top. The
  page is told how big the safe area is, so the header never sits under the camera.
* **Release bug fixed.** After pressing Release, the launch screen could not be dismissed (the Continue button ignored taps and the
  back key was swallowed), so the only way out was closing the game. Continue, the back key and a tap on the screen all work now.
* **HQ.** Floating island with sky, planet, clouds, rock underside and drifting motes; name tags with levels and upgrade arrows; an
  empty lot for the research lab that appears once it is nearly affordable (tap it to build); income popups; bigger Next step chip;
  labelled Center and News buttons; a clearer Campus upgrades sheet with the cheapest buildable upgrade first.
* **AI Models.** New lab picture with an AI core and progress ring; plain-language stats (Intelligence, Speed, Popularity) with
  differences against your live model; a one-line explanation of what each action does ("How it works"); sorted list as described
  above; the lab picture no longer shrinks after the screen refreshes.
* **Infrastructure.** Hardware is listed best tier first, locked tiers are compact rows, and facility upgrades show what you can
  build right now first.

## Playing

* **HQ** - your evolving, animated campus on a floating island. Pinch and drag to explore, tap a building (or its name tag) to inspect
  it. The dock under the campus has Upgrades, Earn more, Look and News, and shows income, costs and profit with health tiles for servers,
  power and cooling. A gold arrow on a name tag means you can afford that upgrade. The "Next step" chip always points at something useful, and every stat chip at the top is a shortcut
  to the screen behind it (Income goes to Money, Users to Global, Model to AI Models, Servers to Upgrades).
* **AI Models** - the laboratory. The top of the screen always says what the lab is doing. Train a new model (timed, reserves compute
  while it trains), release it when it is ready (launch animation, user surge, hype), fine-tune your live model, or deploy an older
  model to save serving costs. The list is sorted by what you can act on: ready to release, in training, next model, live model, other
  models, then later models. Buttons that are disabled always say why, with a shortcut to fix it.
* **Research** - a 49-node tree in five branches (AI, Computing, Products, Business, Infrastructure) with prerequisites, costs,
  timers and meaningful effects. More labs mean faster research and more parallel projects.
* **Upgrades** - eight lists: seven server tiers, racks and floor space, data-center buildings, cooling, power, networking, the office
  and labs. Every purchase changes the campus view at the top of the screen. Construction takes real time.
* **Money** - how you earn and spend, ideas for earning more, pricing, ads, marketing, R&D budget, market share against rivals, enterprise
  partnerships.
* **Global** - an interactive world map. Each region has its own population, spending, costs, growth and competition, and a hub
  you can upgrade to reach more people.
* **Goals** - daily missions, a long-term roadmap, 35 achievements and **Corporate Reinvention** (prestige).

### How the economy works (short version)

`users x quality x share` decides how many people want your AI. Your servers must be able to serve them: if demand exceeds
compute capacity, overheats or runs out of power, uptime and satisfaction fall and revenue is lost. Revenue comes from ads,
premium subscriptions, the developer API, enterprise contracts, image generation and AI agents. Net profit is revenue minus
payroll, serving, power, upkeep, marketing and R&D. One in-game month lasts ten real minutes.

Offline: progress continues while the app is closed (training, research and construction finish on time). Earnings run at 50%
efficiency (more with automation research) up to 6 hours (more with automation research). A summary is shown on return.

Corporate Reinvention unlocks at a $20B valuation. It resets the company but keeps achievements, looks and *Legacy Patents*,
which buy permanent upgrades (research speed, user growth, lower costs, training efficiency, seed capital, sparse
architectures, founder knowledge) and add a permanent revenue bonus.

## Settings, saving and safety

* Autosave every 10 s and whenever the app is paused; manual save and an export/import backup code in Settings.
* Saves are written natively with an atomic write plus a backup copy (`save.json` / `save.bak`) and mirrored in `localStorage`.
* Music, sound effects and animation intensity (Low / Medium / High) are separate. The game lowers effects by itself on slow phones.
* If the game ever crashes, the next start shows the crash report (Settings > Diagnostics also shows recent errors), which can be
  copied with one tap. Useful because phones make logcat hard to reach.

## Project layout

```
settings.gradle, build.gradle, gradle.properties, gradlew, gradle/wrapper/gradle-wrapper.properties
app/build.gradle
app/src/main/AndroidManifest.xml
app/src/main/java/com/lumora/aiempire/MainActivity.java   WebView host, native save, crash log
app/src/main/res/                                          launcher icons, theme
app/src/main/assets/web/
  index.html, css/style.css, css/spectate.css (Lumo, speed, stories, day and night)
  js/util.js     number formatting, colour helpers, original SVG icon set
  js/data.js     models, research tree, hardware tiers, buildings, regions, rivals, partners, achievements, legacy
  js/game.js     economy (G.calcFor is a pure function), tick, offline progression, actions, missions, prestige, save/load (no DOM)
  js/advisor.js  economy advisor (no DOM): "what if I buy this?", ranked ideas for earning more, why costs are what they are
  js/ceo.js      Lumo's brain: what the autopilot decides and when (no DOM)
  js/lumo.js     Lumo's drawing and moods, his flight and speech bubbles, the control panel (autopilot, style, speed, camera)
  js/director.js the cinematic camera
  js/story.js    company stories and milestones (data first: a story is one more entry in EVENTS)
  js/art.js      isometric primitives, land, roads and the shared drawing helpers
  js/art-kit.js  drawing kit for buildings: shaded walls, flat-painted facades skewed onto walls, lit-window layers, roofs and details
  js/art-people.js the one figure used for every person on the island (A.person)
  js/art-live.js everything that moves on a building (fans, radar, steam, cable pulses, orbits ...), a list of parts per building
  js/art-hw.js   the seven server tiers, the rack slots and the thumbnails used on upgrade cards
  js/art-hq.js   the headquarters, five tiers
  js/art-lab.js  the research lab, three tiers
  js/art-dc.js   the server closet and the five data halls
  js/art-infra.js cooling (six tiers), power (five tiers) and the network tower (six tiers)
  js/racks.js    which server sits in which rack slot of which room (no DOM)
  js/scene.js    campus renderer: sprite cache, painter's-order sort, camera, input, animation, construction
  js/life.js     the living island: staff, cars, builders, request streams, drones, airships, lamps
  js/sky.js      day and night, sun, moon, stars, northern lights, birds
  js/fx.js       flying coins, fireworks, confetti, rings and sparks (only runs while something is alive)
  js/lab.js      animated neural network for the AI laboratory
  js/map.js      dot-matrix globe (continents, regions, hub patches, arcs, touch)
  js/audio.js    synthesized effects and generative ambient music
  js/ui.js       interface core: top bar, tabs, buttons, binding helpers
  js/widgets.js  shared pieces: upgrade pictures, income/cost chips, fold-open rows, the income banner, comparison tables
  js/panels.js   Models, Research, Global and Goals screens
  js/upgrades.js the Upgrades screen (one list per kind of upgrade)
  js/money.js    the Money screen
  js/hq.js       the HQ screen (campus, next step, dock)
  js/main.js     boot, game loops, lifecycle
```

## Tuning the economy

All costs are written as `[stage, minutes]` in `data.js`: "this much of the net income a healthy company has at that stage".
Change `D.NT` (net income per stage) to rebalance everything at once. Constants such as revenue per user, expenses and growth speed
are in `G.K` at the top of `game.js`.
