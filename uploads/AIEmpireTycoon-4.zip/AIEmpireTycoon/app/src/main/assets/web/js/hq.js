/* AI Empire Tycoon - HQ screen.
   The campus, the next step to take, and a dock under it that shows the state of the company at a glance: money in and
   out, and whether servers, power and cooling cope. Every part of the dock is a shortcut to the screen that fixes it. */
(function () {
  'use strict';
  const G = window.G, D = G.D, U = G.U, S = G.scene, UI = G.ui, ADV = G.adv, W = UI.w, h = U.h;
  const I = UI.I, T = UI.T, CL = UI.CL, bind = UI.bind, btn = UI.btn;
  const tap = (fn) => () => { G.audio.init(); G.audio.sfx('tap'); fn(); };

  /* ---------- what a tapped building says about itself ---------- */
  // kind -> [title, one line]. The picture uses the same drawing as the Upgrades lists.
  const FACTS = {
    hq: (s) => { const t = D.ladders.hq[s.inf.hq]; return [t.name, t.staff + ' staff. ' + t.desc]; },
    lab: (s, C) => [D.ladders.lab[s.inf.lab].name, 'Research speed x' + C.M.resSpeed.toFixed(2) + ' · ' + C.resSlots + ' project' + (C.resSlots > 1 ? 's' : '') + ' at once'],
    dc: (s, C, p) => { const t = D.ladders.dc[p.lv || 0]; return [t.name, t.racks + ' rack spaces · ' + s.inf.racks + ' racks · ' + C.nServers + ' servers · ' + U.tf(C.capEff) + ' online']; },
    cool: (s, C) => [D.ladders.cool[s.inf.cool].name, 'Heat ' + U.mw(C.heat) + ' of ' + U.mw(C.coolCap) + ' it can remove'],
    pwr: (s, C) => [D.ladders.pwr[s.inf.pwr].name, 'Servers draw ' + U.mw(C.powerDraw) + ' of ' + U.mw(C.powerCap)],
    net: (s, C) => [D.ladders.net[s.inf.net].name, Math.round(C.netEff * 100) + '% of your computing power is usable']
  };
  const level = (p, s) => (p.kind === 'dc' ? p.lv || 0 : p.kind === 'pwr' && p.lv ? p.lv : s.inf[p.kind] || 0);

  let infoEl = null;
  function closeInfo() { UI.st.pick = null; if (infoEl) infoEl.remove(); infoEl = null; }
  function infoBody(p) {
    const s = G.state, C = G.C, box = h('div', { class: 'col gap8' });
    if (p.id === 'labslot') {
      const t = G.ladderNext('lab'), cost = t ? G.ladderCost(t) : 0;
      box.append(h('div', { class: 'row' }, h('div', { class: 'ico' }, I('research', 20)), h('div', { class: 'grow' }, h('h4', {}, 'Research lab (not built yet)'), h('div', { class: 'xs mut' }, 'Build it to research faster and unlock more research slots.'))));
      if (t) {
        const why = () => (t.req && !s.res.done[t.req] ? { t: 'Research ' + D.rmap[t.req].name + ' first.', go: 'research', label: 'Open Research' } : s.cash < cost ? { t: 'You need ' + U.money(cost - s.cash) + ' more cash.' } : null);
        const blk = UI.actionBlock('Build ' + t.name + ' · ' + U.money(cost), null, 'pri', why, () => { closeInfo(); UI.act(() => G.act.build('lab'), 'build'); });
        box.append(blk);
      }
    } else if (FACTS[p.kind]) {
      const f = FACTS[p.kind](s, C, p);
      box.append(h('div', { class: 'row' }, W.pic(p.kind, level(p, s), 84, 66), h('div', { class: 'grow' }, h('h4', {}, f[0]), h('div', { class: 'xs mut' }, f[1]))),
        h('div', { class: 'row' }, btn('Upgrade this', { cls: 'pri grow', icon: 'upgrade', onclick: () => { closeInfo(); UI.follow({ tab: 'upgrades', cat: p.kind }); } })));
    } else {
      box.append(h('div', { class: 'row' }, h('div', { class: 'ico' }, I('build', 20)), h('div', { class: 'grow' }, h('h4', {}, 'Under construction'), h('div', { class: 'xs mut' }, 'This will be ready soon.'))));
    }
    box.append(btn('Close', { cls: 'ghost sm blk', onclick: closeInfo }));
    return box;
  }
  function drawInfo(slot) {
    if (infoEl) { infoEl.remove(); infoEl = null; }
    if (!UI.st.pick || !slot) return;
    infoEl = h('div', { class: 'info' }, infoBody(UI.st.pick));
    slot.append(infoEl);
  }

  /* ---------- look and news (opened from the dock) ---------- */
  function lookModal() {
    const s = G.state, ids = Object.keys(D.skins);
    const grid = h('div', { class: 'row wrap gap12' }, ids.map((id) => {
      const k = D.skins[id];
      return h('button', { class: 'skin' + (s.pres.skin === id ? ' on' : '') + (s.pres.skins[id] ? '' : ' lock'), type: 'button',
        onclick: () => { if (UI.act(() => G.act.setSkin(id), 'tap').ok) { S.sync(true); grid.querySelectorAll('.skin').forEach((b, i) => b.classList.toggle('on', ids[i] === id)); } } },
      h('i', { style: { background: 'linear-gradient(135deg,' + k.glass + ',' + k.accent + ')' } }), k.name);
    }));
    const locked = ids.filter((id) => !s.pres.skins[id]).map((id) => D.skins[id].name + ': ' + D.skins[id].how).join(' · ');
    UI.modal(h('div', { class: 'col gap12' }, h('h2', {}, 'Campus look'), h('div', { class: 'xs mut' }, 'Choose a look for your campus. Some are unlocked by achievements and reinventions.'), grid, h('div', { class: 'xs dimt' }, locked || 'Every look is unlocked.')));
  }
  function newsModal() {
    const feed = G.state.feed.slice(0, 20);
    const rows = feed.length ? feed.map((f) => h('div', { class: 'row' }, h('div', { class: 'ico dim' }, I(UI.TI[f.k] || 'info', 16)), h('div', { class: 'grow sm' }, f.x), h('span', { class: 'xs dimt' }, UI.ago(f.t))))
      : [h('div', { class: 'empty' }, 'No news yet. Grow your company and the headlines will follow.')];
    UI.modal(h('div', { class: 'col gap12' }, h('h2', {}, 'Company news'), h('div', { class: 'col gap12' }, rows)));
  }

  /* ---------- the dock ---------- */
  function moneyStrip() {
    const cells = [['Income', 'pos'], ['Costs', 'neg'], ['Profit', '']].map((c) => { const v = h('b', { class: c[1] }); return { v, el: h('div', { class: 'dm' }, h('span', { class: 'dml' }, c[0]), v) }; });
    const el = h('button', { class: 'dmoney', type: 'button', 'aria-label': 'Income and costs. Open the Money screen', onclick: tap(() => UI.follow({ tab: 'business', seg: 'money' })) }, cells.map((c) => c.el), I('chev', 16));
    bind(el, () => {
      const C = G.C;
      T(cells[0].v, '+' + U.fine(C.rev.total) + '/s'); T(cells[1].v, '−' + U.fine(C.exp.total) + '/s');
      T(cells[2].v, (C.net < 0 ? '−' : '+') + U.fine(Math.abs(C.net)) + '/s'); CL(cells[2].v, 'neg', C.net < 0); CL(cells[2].v, 'pos', C.net >= 0);
    });
    return el;
  }
  // a health tile: its colour and short text come from the same status the Upgrades lists show
  const health = (label, icon, id) => W.tile(label, icon, () => { const st = UI.upgradeStatus(id); return { f: st.f, text: st.short, tone: st.tone }; }, () => UI.follow({ tab: 'upgrades', cat: id }));
  // badge() -> null | { cls: 'gold' | 'bad', text }
  function dockAction(icon, label, fn, badge) {
    const dot = h('i', { class: 'ad', hidden: true });
    const el = h('button', { class: 'dact', type: 'button', onclick: tap(fn) }, I(icon, 20), h('span', {}, label), dot);
    if (badge) bind(el, () => { const b = badge(); dot.hidden = !b; if (b) { T(dot, b.text || ''); dot.className = 'ad ' + b.cls; } });
    return el;
  }
  function dock() {
    const upBadge = () => (ADV.capacity() ? { cls: 'bad', text: '!' } : ['dc', 'cool', 'pwr', 'net', 'hq', 'lab'].some(G.canBuild) ? { cls: 'gold' } : null);
    const earnBadge = () => { const n = ADV.coach().filter((t) => t.afford && t.head > 0).length; return n ? { cls: 'gold', text: String(n) } : null; };
    return h('div', { class: 'dock' },
      moneyStrip(),
      h('div', { class: 'dtiles' }, health('Servers', 'cpu', 'servers'), health('Power', 'bolt', 'pwr'), health('Cooling', 'snow', 'cool')),
      h('div', { class: 'dacts' },
        dockAction('upgrade', 'Upgrades', () => UI.follow({ tab: 'upgrades' }), upBadge),
        dockAction('bulb', 'Earn more', () => UI.follow({ tab: 'business', seg: 'money' }), earnBadge),
        dockAction('palette', 'Look', lookModal),
        dockAction('list', 'News', newsModal)));
  }

  /* ---------- Lumo on the HQ screen ---------- */
  // A chip with what the AI CEO is up to (tap it for his control panel) and a button that cycles the game speed 1x / 2x / 4x.
  // Lumo himself flies over the campus (lumo.js); the chip is the same thought in words, for when he is out of frame.
  function lumoChip() {
    const Lu = G.lumo, av = Lu.avatar(34, 'happy');
    const lx = h('div', { class: 'lx' }), ll = h('div', { class: 'll' });
    const el = h('button', { class: 'lumochip', type: 'button', 'aria-label': 'Lumo, your AI CEO. Open his control panel', onclick: tap(() => Lu.open()) }, av, h('div', { class: 'lt' }, ll, lx));
    bind(el, () => {
      const l = Lu.line(), on = G.ceo.enabled();
      if (lx._t !== l.text) { el.classList.remove('pop'); void el.offsetWidth; el.classList.add('pop'); }
      T(lx, l.text); T(ll, on ? 'LUMO · AUTOPILOT' : 'LUMO · PAUSED'); Lu.setMood(av, on ? Lu.mood() : 'sleepy'); CL(el, 'off', !on);
    });
    return el;
  }
  function speedTool() {
    const Lu = G.lumo, v = h('b', { class: 'spv' }), el = h('button', { class: 'vt spd', type: 'button', 'aria-label': 'Game speed. Tap to change', onclick: () => { G.audio.init(); Lu.cycleSpeed(); } }, v, h('span', {}, 'Speed'));
    bind(el, () => { const k = G.state.speed || 1; T(v, k + '×'); CL(el, 'fast', k > 1); });
    return el;
  }

  /* ---------- the screen ---------- */
  UI.tabs.hq = function () {
    const root = h('div', { class: 'tab-hq-in' }), slot = h('div', { class: 'vpslot' });
    const hint = h('button', { class: 'hint', type: 'button' }, h('div', { class: 'hi' }, I('target', 16)), h('div', { class: 'ht' }, h('div', { class: 'hl' }, 'NEXT STEP'), h('div', { class: 'hx' })), h('span', { class: 'hc' }, I('chev', 16)));
    bind(hint, () => {
      const t = G.hint();
      hint.hidden = !t;
      if (t) { T(hint.querySelector('.hx'), t.text); hint._go = t; }
      S.setInset(t ? Math.round(hint.offsetHeight + 16) : 0, 56); // keep the campus out from under the chips
    });
    hint.addEventListener('click', tap(() => UI.follow(hint._go)));
    const tools = h('div', { class: 'vtools' }, h('button', { class: 'vt', type: 'button', 'aria-label': 'Center the view on your campus', onclick: tap(() => S.recenter()) }, I('target', 19), h('span', {}, 'Center')), speedTool());
    slot.append(hint, tools, G.story.pills(), lumoChip());
    root.append(slot, dock());
    setTimeout(() => { UI.mountVp(slot, 'all'); drawInfo(slot); }, 0);
    UI.hqSlot = slot;
    return root;
  };
  UI.picks.hq = () => drawInfo(UI.hqSlot);
})();
