/* AI Empire Tycoon - which server sits in which rack slot (no DOM).
   The game stores servers as one count per tier (state.inf.g1..g7) and racks as a single number. The campus draws every server,
   so this module lays them out. The racks are shared between the rooms in the order the rooms were built (closet first, then each
   hall). Servers move into the newest room first, best hardware first, rack after rack and from the bottom slot up, so the biggest
   room on the island is the one that visibly fills up and the old closet is what is left over.
   A "cell" is one drawn rack: an array of D.rack.slots tier numbers, bottom slot first, with -1 for an empty slot. */
(function () {
  'use strict';
  const G = window.G, D = G.D;
  const R = (G.racks = {});
  const N = D.rack.slots;
  R.EMPTY = -1;

  // The rooms of the campus and the racks each one holds. Index 0 is the closet, index lv the hall of that level.
  //   r0 = first rack (of all racks) that stands in the room    n = racks in it    cap = racks it can hold in the end
  R.rooms = function (inf) {
    const caps = D.ladders.dc.map((t) => t.racks), racks = inf.racks || 0;
    const out = [{ r0: 0, n: Math.min(racks, caps[0]), cap: caps[0] }];
    for (let lv = 1; lv <= (inf.dc || 0); lv++) {
      const lo = caps[lv - 1], cap = caps[lv] - lo;
      out.push({ r0: lo, n: Math.max(0, Math.min(racks - lo, cap)), cap });
    }
    return out;
  };

  // One tier number per slot for every rack the company owns, rack after rack (-1 = empty). Servers beyond the free slots cannot
  // happen in a real game (buying checks the room), so they are simply not drawn.
  R.slots = function (inf) {
    const out = new Array((inf.racks || 0) * N).fill(R.EMPTY), servers = [];
    for (let t = D.hw.length - 1; t >= 0; t--) for (let i = 0; i < (inf[D.hw[t].k] || 0); i++) servers.push(t);
    let next = 0;
    const rooms = R.rooms(inf);
    for (let i = rooms.length - 1; i >= 0 && next < servers.length; i--) {
      const rm = rooms[i];
      for (let s = rm.r0 * N; s < (rm.r0 + rm.n) * N && next < servers.length; s++) out[s] = servers[next++];
    }
    return out;
  };

  // The racks of one room as the picture draws them. `pos` is how many racks the picture has room for.
  // A room whose picture has space for every rack draws them one to one: buying a rack adds a rack, buying a server fills a slot.
  // A bigger room cannot show all its racks, so one drawn rack stands for a few and shows how full that group is.
  R.room = function (slots, rm, pos) {
    if (rm.n <= 0) return [];
    const per = Math.max(1, rm.cap / pos), draw = Math.max(1, Math.min(pos, Math.ceil(rm.n / per))), out = [];
    for (let k = 0; k < draw; k++) {
      const a = rm.r0 + Math.floor((k * rm.n) / draw), b = rm.r0 + Math.floor(((k + 1) * rm.n) / draw);
      const tiers = [];
      for (let i = a * N; i < b * N; i++) if (slots[i] >= 0) tiers.push(slots[i]);
      const have = tiers.length, fill = have ? Math.max(1, Math.round((have / ((b - a) * N)) * N)) : 0;
      const cell = new Array(N).fill(R.EMPTY);
      for (let j = 0; j < fill; j++) cell[j] = tiers[Math.min(have - 1, Math.floor(((j + 0.5) / fill) * have))];
      out.push(cell);
    }
    return out;
  };

  // A short text that is the same for the same picture, so a sprite is only redrawn when a slot really changed.
  R.key = (cells) => cells.map((c) => c.map((t) => (t < 0 ? '.' : t)).join('')).join(',');
  // Servers shown in these racks.
  R.filled = (cells) => cells.reduce((s, c) => s + c.filter((t) => t >= 0).length, 0);
})();
