/* AI Empire Tycoon - the world globe: a dot-matrix sphere that turns to the region you pick.
   The continents are stylised polygons, sampled into dots that are spread evenly over a sphere and projected every frame.
   Opened regions glow in their own colour and a hub shows how far it reaches; data arcs run out from the home market.
   Tap a marker or a label to pick a region, drag to turn the globe. The canvas is created once and moved from screen to
   screen, so the globe keeps turning when the screen around it is rebuilt. */
(function () {
  'use strict';
  const G = window.G, D = G.D, U = G.U;
  const M = (G.map = {});
  const POLYS = [
    [[-168, 65.5], [-163, 69], [-156, 71.3], [-142, 70], [-128, 70], [-115, 68.5], [-95, 69], [-85, 69.5], [-82, 66], [-78, 62], [-72, 61], [-65, 60], [-62, 57], [-57, 53], [-55, 50], [-60, 46], [-66, 44.5], [-70, 43], [-74, 40], [-76, 37], [-78, 34.5], [-81, 31], [-80, 26], [-82, 26], [-83, 29.5], [-86, 30.2], [-90, 29.3], [-94, 29.6], [-97, 27.5], [-97.5, 22.5], [-95.5, 18.8], [-91, 18.5], [-90.5, 21], [-87, 21.5], [-88, 18], [-88.5, 15.8], [-84, 15.9], [-83.2, 11], [-81, 8.8], [-79.5, 9.5], [-77.5, 8.7], [-79, 7.4], [-81.5, 7.8], [-84, 9.2], [-86, 11.5], [-88, 13.2], [-92, 14.5], [-96, 15.8], [-100, 17], [-105.5, 20], [-106.5, 23.5], [-110, 27], [-113.5, 31.5], [-117, 32.5], [-121, 35], [-124, 40], [-124.5, 43], [-124, 47], [-124.5, 48.5], [-127, 50.5], [-131, 54], [-134, 57], [-139, 59.5], [-146, 60.5], [-152, 59], [-158, 57], [-162, 55.5], [-165, 60]],
    [[-77.5, 8.5], [-75, 11], [-72, 12], [-68, 10.8], [-63, 10.8], [-60, 8.5], [-57, 6], [-52, 5], [-50, 1.5], [-49, -0.5], [-44, -2.5], [-39, -3.5], [-35, -5.5], [-35, -9], [-37, -12], [-39, -15], [-39.5, -19], [-41, -22], [-44, -23.2], [-48, -26], [-48.8, -28.5], [-52, -32], [-54, -34.5], [-57, -35], [-58, -38.5], [-62, -39], [-65, -41], [-65, -45], [-67.5, -46.5], [-66, -48], [-68.5, -50.5], [-69, -52.5], [-68, -54.5], [-71, -54], [-73.5, -51], [-74, -47], [-73, -42], [-73.5, -37], [-71.5, -33], [-71.5, -28], [-70.5, -23], [-70.3, -18.5], [-75, -15], [-76.5, -12.5], [-79, -8], [-81, -5.5], [-80, -3], [-80, 0.5], [-78.5, 1.5], [-77.5, 4]],
    [[-9.5, 37], [-9.5, 43.2], [-2, 43.5], [-1.2, 46], [-4.7, 48.4], [-1.5, 49.6], [1.5, 51], [4.5, 52.5], [8.5, 54], [8.2, 57], [10.5, 57.7], [11, 59], [5.5, 58.7], [5, 62], [10, 64], [14, 67.5], [19, 70], [26, 71], [31, 70], [41, 67.5], [40, 65], [44, 66.5], [52, 68], [60, 68.7], [66, 69.5], [72, 73], [80, 73.5], [88, 75.5], [100, 77], [112, 76], [113, 73.5], [130, 71], [140, 72.5], [150, 71], [160, 69.5], [170, 70], [180, 68.5], [180, 65], [175, 62], [165, 60], [162, 56], [156, 51.2], [153, 54], [143, 59], [138, 56], [141, 52], [140, 48], [135, 43.5], [131, 42.5], [129.5, 40], [129.2, 35.2], [126.5, 34.5], [126, 37.5], [125, 39.5], [121.5, 40.7], [121, 39], [118, 39], [119, 37], [122.5, 37], [120.5, 35], [121.8, 31.5], [121.5, 28], [119.5, 25.5], [116, 22.8], [111, 21.5], [108, 21.8], [106.5, 19], [108.5, 15.5], [109.2, 12], [107, 10.5], [105, 8.7], [104.8, 10.3], [102, 12.5], [100, 13.2], [99.5, 10], [101, 6.8], [103.3, 4.5], [104.2, 1.4], [101.3, 2.8], [98.5, 8.2], [98.5, 13], [97.5, 16.5], [94.5, 16], [94.2, 19], [92, 21.5], [91, 22.5], [88.5, 21.8], [86.8, 20.5], [84.5, 19], [82.2, 16.5], [80.3, 15.5], [80.2, 12], [79.8, 10.3], [78.2, 8.9], [77.2, 8.1], [76, 10], [74.8, 13], [73.2, 17.5], [72.7, 21.3], [70.2, 20.8], [68.5, 23.3], [66.5, 25.2], [62, 25.2], [57.5, 25.7], [56.3, 27.2], [52, 27.8], [50, 30], [48.5, 29.8], [47.8, 28.5], [50, 26.2], [51.5, 24.2], [54, 24.2], [56, 26], [57, 23.7], [59.8, 22.5], [58.5, 20.5], [55.2, 17.3], [52.2, 16], [48, 14], [45, 12.7], [43.2, 12.7], [42.8, 15], [41, 19], [39, 21.5], [37, 25], [35, 28], [34.8, 29.5], [32.5, 30], [34.2, 31.3], [35.2, 33.5], [36, 35.8], [34.2, 36.8], [32, 36.3], [30, 36.3], [28, 36.8], [26.5, 38.2], [26.2, 40], [23.5, 40.3], [24, 38], [22.5, 36.5], [21.2, 38], [19.5, 40], [19.5, 42], [17, 43], [13.7, 45.2], [12.3, 45.4], [12.7, 43.6], [14.2, 42.2], [16, 41.2], [18.5, 40.2], [17, 39], [16, 38], [15.7, 39.9], [13.5, 41.2], [12.2, 42], [10.5, 43], [9, 44.3], [7.5, 43.8], [4.8, 43.4], [3, 42.7], [3.2, 41.8], [0.8, 41], [-0.5, 38.8], [-0.7, 37.6], [-2.2, 36.7], [-5.4, 36], [-6.2, 36.5]],
    [[-17.3, 21], [-16.5, 19], [-17.2, 14.7], [-16.7, 12.5], [-13.5, 9.5], [-11.4, 7], [-8, 4.5], [-4, 5.2], [-1, 4.8], [2, 6.2], [5, 5.8], [8.5, 4.4], [9.7, 2.5], [9.5, -1], [12, -4.5], [13.5, -9], [13.2, -12], [12.2, -16], [14.5, -22.5], [15.2, -27], [17.8, -32], [18.5, -34.2], [20.5, -34.8], [25, -34], [27.5, -33.3], [30, -31], [32.5, -28.5], [32.7, -25.5], [35.3, -23.5], [35.5, -20], [34.8, -17], [36.5, -15], [40.3, -14], [40.5, -10.5], [39.3, -6.5], [39.5, -4.5], [41.5, -1.8], [44, 1.5], [48, 5], [51, 10.5], [51, 12], [47, 11.2], [43.3, 12.2], [41, 14.8], [39.5, 16], [37.3, 19.5], [36, 22.8], [34, 26], [32.5, 29.9], [31, 31.5], [27, 31.2], [24, 32.3], [20.2, 32], [19.2, 30.4], [15, 32.2], [11, 33.2], [10.2, 34.5], [11, 37.2], [9.5, 37.3], [5, 36.8], [1, 36.5], [-2.5, 35.3], [-5.5, 35.8], [-7, 33.7], [-9.6, 30.5], [-10.5, 28.2], [-13.2, 27.7], [-15, 24.5], [-16.3, 22.7]],
    [[113.5, -22], [114.2, -26], [115, -33.5], [118, -35], [123.5, -34], [127, -32.2], [131.2, -31.5], [134, -32.7], [135.5, -34.7], [137.8, -35.5], [140, -37.8], [143.5, -38.8], [146.5, -39], [150, -37.5], [151.2, -34], [153.2, -30], [153.5, -26], [151, -23], [148.5, -20], [146, -18.2], [145.3, -15], [143.5, -14], [142.5, -10.8], [141.5, -13], [141.5, -16.5], [139, -17.5], [136.7, -15.8], [135.5, -14.7], [136.8, -12.2], [132.5, -11.5], [130.2, -12.4], [129.5, -15], [127, -14], [124.5, -16], [122, -17.2], [122.4, -18.5], [118.5, -20.4], [114.5, -21.7]],
    [[-5.5, 50], [-3, 50.2], [1.4, 51], [1.7, 52.8], [0, 53.6], [-1.5, 55.5], [-2, 57.5], [-3.5, 58.6], [-5.5, 58.5], [-6, 56.5], [-5, 55], [-3.2, 54.8], [-3, 53.4], [-4.7, 53], [-4.2, 51.6]],
    [[-10, 51.6], [-6, 52], [-6, 54.2], [-8, 55.2], [-10, 54]],
    [[-24, 64.4], [-19, 63.4], [-14, 64.4], [-14.5, 66], [-22, 66.4]],
    [[130.8, 31.2], [132, 33.8], [135, 33.5], [137, 34.6], [140, 35], [141, 38], [142, 40], [141.5, 41.5], [140, 40.6], [139.5, 38], [136.5, 37], [134, 35.6], [131, 34.4]],
    [[140, 41.5], [141.5, 43], [145, 43.5], [142, 45.5], [140, 43.5]],
    [[120, 18.5], [122.2, 18.3], [121.7, 14.2], [124, 12.7], [120.5, 14]],
    [[122, 7.2], [126.5, 7.5], [126, 6], [124, 6.2]],
    [[95.3, 5.6], [98, 4], [104, -1.5], [106, -3.2], [105.8, -5.8], [102, -4], [98.5, 0.5]],
    [[105.2, -6.3], [108, -6.1], [112, -6.8], [114.5, -7.8], [111, -8.3], [106, -7.2]],
    [[109, 1.5], [111, 2.5], [114, 4.5], [117, 7], [119, 5.2], [117.5, 1.5], [116.5, -3], [114.5, -4], [111, -3], [109.5, -1]],
    [[119.4, -5.5], [120.5, 1], [125, 1.5], [121.5, -1], [123, -5], [121.5, -4.8]],
    [[131, -1.3], [135, -3.3], [138.5, -8], [141, -9], [144, -7.8], [147.5, -10], [150.5, -10.5], [147, -6.5], [145.5, -4.5], [141, -2.6], [135, -0.8]],
    [[172.7, -34.5], [175.8, -37], [178.5, -37.7], [176.5, -39.8], [175.2, -41.5], [174.5, -39.3], [173.8, -36.6]],
    [[172.7, -40.6], [174.3, -41.7], [173, -43.7], [171.2, -44.4], [169, -46.6], [166.5, -46], [168.5, -44], [171, -42.4]],
    [[49.3, -12], [50.5, -15.5], [47.5, -24.8], [44.2, -24.8], [43.3, -21.5], [44.5, -16.5], [47, -15]],
    [[-72, 78], [-60, 82], [-30, 83.5], [-17, 80], [-20, 72], [-24, 69.5], [-42, 60], [-49, 61], [-53, 67], [-58, 76]],
    [[-85, 22], [-82, 23.2], [-77, 21.3], [-74, 20.2], [-78, 20.5], [-82.5, 22.5]],
    [[80, 9.8], [81.7, 7.5], [80.3, 6], [79.8, 8]]
  ];
  const COL = { na: '#5b9bf2', eu: '#9b8cff', ea: '#f59e6b', sea: '#4fd6a0', sa: '#f6b84a', gl: '#ff7fa3' };
  const NAME = { na: 'N. America', eu: 'Europe', ea: 'E. Asia', sea: 'SE Asia', sa: 'S. America', gl: 'Global' };
  const RAD = Math.PI / 180, TAU = Math.PI * 2;
  M.COL = COL; M.NAME = NAME;
  M.visible = false;
  M.onPick = null;
  let cv = null, c = null, W = 0, H = 0, dpr = 1, R = 100, cx = 0, cy = 0, T = 0, last = 0;
  let dots = null, bodyImg = null, starImg = null, layoutSig = '';
  let sel = 'na', yaw = 0, tilt = 0.2, goYaw = 0, goTilt = 0.2, manual = false, entering = true;
  const inset = { t: 0, b: 0 };
  const hits = [], pills = [];      // what can be tapped this frame: marker discs and label rectangles
  const P3 = [0, 0, 0];             // scratch result of project()

  /* ---------- the dots ---------- */
  function inPoly(x, y, p) {
    let ins = false;
    for (let i = 0, j = p.length - 1; i < p.length; j = i++) {
      const a = p[i], b = p[j];
      if ((a[1] > y) !== (b[1] > y) && x < ((b[0] - a[0]) * (y - a[1])) / (b[1] - a[1]) + a[0]) ins = !ins;
    }
    return ins;
  }
  function regionOf(lon, lat) {
    if (lon > -85 && lon < -30 && lat < 12) return 'sa';
    if (lon < -50 && lat >= 7) return 'na';
    if (lon > 60 && lat >= 54) return 'eu';
    if (lon > -12 && lon < 60 && lat >= 36 && !(lon > 32 && lat < 42)) return 'eu';
    if (lon > 92 && lon < 142 && lat >= -11 && lat < 24) return 'sea';
    if (lon > 73 && lon < 150 && lat >= 18 && lat < 54) return 'ea';
    return 'gl';
  }
  // Rows of dots from north to south. A row near a pole is a small circle, so it gets fewer dots: that keeps them evenly spread.
  function makeDots() {
    dots = [];
    const step = 2.9, rowStep = step * 0.9;
    let row = 0;
    for (let lat = 80; lat > -58; lat -= rowStep, row++) {
      const cl = Math.cos(lat * RAD), lstep = step / Math.max(0.3, cl), off = (row % 2) * lstep * 0.5;
      for (let lon = -180 + off; lon < 180; lon += lstep) {
        let hit = false;
        for (const p of POLYS) { if (inPoly(lon, lat, p)) { hit = true; break; } }
        if (!hit) continue;
        const lo = lon * RAD, la = lat * RAD;
        dots.push({ x: cl * Math.sin(lo), y: Math.sin(la), z: cl * Math.cos(lo), reg: regionOf(lon, lat) });
      }
    }
  }

  /* ---------- the sphere ---------- */
  // Turns a point (longitude, latitude in radians) by the current view. Returns [screen x, screen y, depth]; depth > 0 faces us.
  function project(lon, lat, lift) {
    const cl = Math.cos(lat), x0 = cl * Math.sin(lon), y0 = Math.sin(lat), z0 = cl * Math.cos(lon);
    return spin(x0, y0, z0, lift || 1);
  }
  let cY = 1, sY = 0, cT = 1, sT = 0;
  function spin(x0, y0, z0, k) {
    const x1 = x0 * cY - z0 * sY, z1 = x0 * sY + z0 * cY, y2 = y0 * cT - z1 * sT, z2 = y0 * sT + z1 * cT;
    P3[0] = cx + R * k * x1; P3[1] = cy - R * k * y2; P3[2] = z2 * k;
    return P3;
  }
  function setView(a, t) { yaw = a; tilt = t; cY = Math.cos(a); sY = Math.sin(a); cT = Math.cos(t); sT = Math.sin(t); }
  const angDiff = (to, from) => { let d = (to - from) % TAU; if (d > Math.PI) d -= TAU; if (d < -Math.PI) d += TAU; return d; };

  /* ---------- size and cached pictures ---------- */
  M.setInset = function (t, b) { inset.t = t; inset.b = b; layoutSig = ''; };
  M.resize = function () {
    if (!cv || !cv.parentElement) return;
    const r = cv.parentElement.getBoundingClientRect();
    if (r.width < 10 || r.height < 10) return;
    const nd = Math.min(window.devicePixelRatio || 1, 2);
    if (Math.abs(r.width - W) >= 1 || Math.abs(r.height - H) >= 1 || nd !== dpr || !cv.width) {
      W = r.width; H = r.height; dpr = nd;
      cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr);
      cv.style.width = W + 'px'; cv.style.height = H + 'px';
      layoutSig = '';
    }
    const sg = W + 'x' + H + 'x' + dpr + 'x' + inset.t + 'x' + inset.b;
    if (sg === layoutSig) return;
    layoutSig = sg;
    R = Math.max(40, Math.min(W * 0.43, (H - inset.t - inset.b) * 0.45));
    cx = W / 2; cy = inset.t + (H - inset.t - inset.b) / 2;
    bodyImg = makeBody(); starImg = makeStars();
  };
  function makeBody() {
    const s = Math.ceil(R * 2.8), cvs = document.createElement('canvas'), m = s / 2;
    cvs.width = cvs.height = Math.round(s * dpr);
    const g = cvs.getContext('2d'); g.scale(dpr, dpr);
    let gr = g.createRadialGradient(m, m, R * 0.92, m, m, R * 1.36);                       // the thin air around the planet
    gr.addColorStop(0, 'rgba(80,205,255,.34)'); gr.addColorStop(0.3, 'rgba(60,140,255,.13)'); gr.addColorStop(1, 'rgba(40,90,255,0)');
    g.fillStyle = gr; g.beginPath(); g.arc(m, m, R * 1.36, 0, TAU); g.fill();
    gr = g.createRadialGradient(m - R * 0.38, m - R * 0.42, R * 0.08, m, m, R);             // the ocean, lit from the upper left
    gr.addColorStop(0, '#21458f'); gr.addColorStop(0.55, '#10265d'); gr.addColorStop(1, '#060d27');
    g.fillStyle = gr; g.beginPath(); g.arc(m, m, R, 0, TAU); g.fill();
    g.save(); g.beginPath(); g.arc(m, m, R, 0, TAU); g.clip();
    gr = g.createRadialGradient(m + R * 0.55, m + R * 0.55, R * 0.2, m + R * 0.55, m + R * 0.55, R * 1.35);   // night side
    gr.addColorStop(0, 'rgba(2,6,20,0)'); gr.addColorStop(1, 'rgba(2,6,20,.6)');
    g.fillStyle = gr; g.fillRect(0, 0, s, s);
    gr = g.createRadialGradient(m, m, R * 0.8, m, m, R);                                   // bright rim
    gr.addColorStop(0, 'rgba(100,215,255,0)'); gr.addColorStop(1, 'rgba(120,225,255,.5)');
    g.fillStyle = gr; g.fillRect(0, 0, s, s);
    g.restore();
    return { cv: cvs, s };
  }
  function makeStars() {
    const cvs = document.createElement('canvas'); cvs.width = Math.round(W * dpr); cvs.height = Math.round(H * dpr);
    const g = cvs.getContext('2d'); g.scale(dpr, dpr);
    const rnd = U.rng(77);
    for (let i = 0; i < 70; i++) {
      const x = rnd() * W, y = rnd() * H;
      if (Math.hypot(x - cx, y - cy) < R * 1.05) continue;
      g.globalAlpha = 0.25 + rnd() * 0.55; g.fillStyle = '#dbe9ff'; g.beginPath(); g.arc(x, y, 0.4 + rnd() * 1.0, 0, TAU); g.fill();
    }
    return cvs;
  }

  /* ---------- what is open, what is being built ---------- */
  function status(id) { const s = G.state; return s.regions[id] ? 'open' : G.building('reg', id) ? 'building' : 'closed'; }
  // reach of a hub as an angle on the globe: a bigger hub lights a bigger patch
  const patchAngle = (id) => { const rs = G.state.regions[id]; return rs ? (6 + rs.hub * 4) * RAD : 0; };

  /* ---------- choosing a region ---------- */
  M.select = function (id) {
    const rg = D.rgmap[id];
    if (!rg) return;
    sel = id; manual = false;
    goYaw = rg.lon * RAD; goTilt = U.clamp(rg.lat * RAD * 0.55 + 0.1, -0.5, 0.75);
  };
  function pickAt(x, y) {
    for (const p of pills) if (x >= p.x && x <= p.x + p.w && y >= p.y && y <= p.y + p.h) return p.id;
    let best = null, bd = 30;
    for (const h of hits) { const d = Math.hypot(h.x - x, h.y - y); if (d < bd) { bd = d; best = h.id; } }
    return best;
  }
  function bind() {
    const ptr = new Map();
    let down = null;
    const rel = (e) => { const r = cv.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; };
    cv.addEventListener('pointerdown', (e) => {
      cv.setPointerCapture(e.pointerId);
      ptr.set(e.pointerId, rel(e));
      down = { p: rel(e), moved: false, t: performance.now() };
    });
    cv.addEventListener('pointermove', (e) => {
      if (!ptr.has(e.pointerId) || !down) return;
      const p = rel(e), old = ptr.get(e.pointerId);
      ptr.set(e.pointerId, p);
      if (!down.moved && Math.hypot(p[0] - down.p[0], p[1] - down.p[1]) > 7) down.moved = true;
      if (down.moved) {
        manual = true; entering = false;
        setView(yaw - (p[0] - old[0]) / (R * Math.max(0.35, Math.cos(tilt))), U.clamp(tilt + (p[1] - old[1]) / R, -1.15, 1.15));
        goYaw = yaw; goTilt = tilt;
      }
    });
    cv.addEventListener('pointerup', (e) => {
      const had = ptr.has(e.pointerId);
      ptr.delete(e.pointerId);
      if (had && down && !down.moved && performance.now() - down.t < 600) {
        const id = pickAt(down.p[0], down.p[1]);
        if (id) { M.select(id); if (M.onPick) M.onPick(id); }
      }
      down = null;
    });
    cv.addEventListener('pointercancel', (e) => { ptr.delete(e.pointerId); down = null; });
  }
  // Puts the globe into a screen. The same canvas is moved each time, so nothing is lost when the screen is rebuilt.
  M.mount = function (slot) {
    if (!cv) {
      cv = document.createElement('canvas'); cv.className = 'globecv'; c = cv.getContext('2d'); makeDots(); bind();
      setView(D.rgmap[sel].lon * RAD + 1.5, 0.05);   // the first time, the globe turns in from the side
    }
    slot.insertBefore(cv, slot.firstChild);
    M.visible = true;
    W = 0; layoutSig = '';
    requestAnimationFrame(() => { M.resize(); });
  };

  /* ---------- drawing ---------- */
  const rgba = (hex, a) => U.rgba(hex, a);
  function paintDots() {
    // one batch per region colour and brightness, so a frame costs a few dozen fills however many dots there are
    const nreg = D.regions.length, groups = [];
    for (let i = 0; i < nreg * 3; i++) groups.push([]);
    const regIdx = {}; D.regions.forEach((r, i) => (regIdx[r.id] = i));
    const base = Math.max(2.1, R * 0.0235), lx = -0.35, ly = 0.4, lz = 0.85;
    for (let i = 0; i < dots.length; i++) {
      const d = dots[i], x1 = d.x * cY - d.z * sY, z1 = d.x * sY + d.z * cY, y2 = d.y * cT - z1 * sT, z2 = d.y * sT + z1 * cT;
      if (z2 <= 0.03) continue;
      const lit = 0.45 * z2 + 0.55 * Math.max(0, x1 * lx + y2 * ly + z2 * lz), lvl = lit < 0.34 ? 0 : lit < 0.64 ? 1 : 2;
      groups[regIdx[d.reg] * 3 + lvl].push(cx + R * x1, cy - R * y2, base * (0.5 + 0.5 * z2));
    }
    const LV = [0.42, 0.72, 1];
    D.regions.forEach((r, ri) => {
      const st = status(r.id), on = sel === r.id, col = COL[r.id];
      for (let lvl = 0; lvl < 3; lvl++) {
        const g = groups[ri * 3 + lvl];
        if (!g.length) continue;
        const a = st === 'open' ? (on ? 1 : 0.92) : st === 'building' ? 0.6 : on ? 0.7 : 0.4;
        c.fillStyle = st === 'closed' && !on ? 'rgba(125,146,200,' + (0.34 * LV[lvl]) + ')' : rgba(col, a * LV[lvl]);
        c.beginPath();
        for (let k = 0; k < g.length; k += 3) { const s = g[k + 2]; c.rect(g[k] - s / 2, g[k + 1] - s / 2, s, s); }
        c.fill();
      }
    });
  }
  function paintGrid() {
    c.strokeStyle = 'rgba(140,190,255,.09)'; c.lineWidth = 1; c.beginPath();
    for (let lo = -180; lo < 180; lo += 30) {
      let pen = false;
      for (let la = -80; la <= 80; la += 5) { const p = project(lo * RAD, la * RAD); if (p[2] > 0) { if (pen) c.lineTo(p[0], p[1]); else c.moveTo(p[0], p[1]); pen = true; } else pen = false; }
    }
    for (let la = -60; la <= 60; la += 30) {
      let pen = false;
      for (let lo = -180; lo <= 180; lo += 6) { const p = project(lo * RAD, la * RAD); if (p[2] > 0) { if (pen) c.lineTo(p[0], p[1]); else c.moveTo(p[0], p[1]); pen = true; } else pen = false; }
    }
    c.stroke();
  }
  // a soft coloured patch on the ground around an open region: the bigger the hub, the bigger the patch
  function paintPatch(rg, on) {
    const a = patchAngle(rg.id);
    if (!a) return;
    const lo0 = rg.lon * RAD, la0 = rg.lat * RAD, sl = Math.sin(la0), cl = Math.cos(la0);
    c.beginPath();
    let n = 0;
    for (let i = 0; i < 28; i++) {
      const b = (i / 28) * TAU, la = Math.asin(sl * Math.cos(a) + cl * Math.sin(a) * Math.cos(b));
      const lo = lo0 + Math.atan2(Math.sin(b) * Math.sin(a) * cl, Math.cos(a) - sl * Math.sin(la));
      const p = project(lo, la);
      if (p[2] <= 0.02) continue;
      if (n++) c.lineTo(p[0], p[1]); else c.moveTo(p[0], p[1]);
    }
    if (n < 3) return;
    c.closePath();
    c.fillStyle = rgba(COL[rg.id], on ? 0.2 : 0.12); c.fill();
    c.strokeStyle = rgba(COL[rg.id], on ? 0.75 : 0.45); c.lineWidth = on ? 1.6 : 1; c.stroke();
  }
  // great-circle arcs from the home market to every open region, with a pulse of data running along each
  function paintArcs() {
    const home = D.rgmap.na, h0 = [home.lon * RAD, home.lat * RAD];
    const v0 = [Math.cos(h0[1]) * Math.sin(h0[0]), Math.sin(h0[1]), Math.cos(h0[1]) * Math.cos(h0[0])];
    let idx = 0;
    for (const rg of D.regions) {
      if (rg.id === 'na' || !G.state.regions[rg.id]) continue;
      const la1 = rg.lat * RAD, lo1 = rg.lon * RAD, v1 = [Math.cos(la1) * Math.sin(lo1), Math.sin(la1), Math.cos(la1) * Math.cos(lo1)];
      const dot = U.clamp(v0[0] * v1[0] + v0[1] * v1[1] + v0[2] * v1[2], -1, 1), om = Math.acos(dot), so = Math.sin(om) || 1;
      const pts = [];
      for (let i = 0; i <= 28; i++) {
        const t = i / 28, a = Math.sin((1 - t) * om) / so, b = Math.sin(t * om) / so;
        const x = a * v0[0] + b * v1[0], y = a * v0[1] + b * v1[1], z = a * v0[2] + b * v1[2], p = spin(x, y, z, 1 + Math.sin(t * Math.PI) * (0.1 + om * 0.1));
        pts.push(p[0], p[1], P3[2]);
      }
      c.strokeStyle = rgba(COL[rg.id], 0.55); c.lineWidth = 1.4; c.beginPath();
      let pen = false;
      for (let i = 0; i < pts.length; i += 3) { if (pts[i + 2] > -0.02) { if (pen) c.lineTo(pts[i], pts[i + 1]); else c.moveTo(pts[i], pts[i + 1]); pen = true; } else pen = false; }
      c.stroke();
      if (S_Q() > 0) {
        const t = (T * 0.3 + idx * 0.31) % 1, k = Math.min(27, Math.floor(t * 28)) * 3;
        if (pts[k + 2] > -0.02) { c.globalCompositeOperation = 'lighter'; c.drawImage(G.art.glow(COL[rg.id]), pts[k] - 9, pts[k + 1] - 9, 18, 18); c.globalCompositeOperation = 'source-over'; }
      }
      idx++;
    }
  }
  const S_Q = () => (G.scene && G.scene.q !== undefined ? G.scene.q : 1);
  function paintMarker(rg, p) {
    const st = status(rg.id), on = sel === rg.id, col = COL[rg.id], x = p[0], y = p[1], fade = Math.min(1, p[2] * 3);
    c.globalAlpha = fade;
    if (st === 'open') {
      const pulse = 0.5 + 0.5 * Math.sin(T * 2.4 + rg.lon);
      if (S_Q() > 0) { c.strokeStyle = rgba(col, 0.55 * (1 - pulse)); c.lineWidth = 1.6; c.beginPath(); c.arc(x, y, 6 + pulse * 11, 0, TAU); c.stroke(); }
      c.globalCompositeOperation = 'lighter'; c.drawImage(G.art.glow(col), x - 16, y - 16, 32, 32); c.globalCompositeOperation = 'source-over';
    }
    c.fillStyle = st === 'open' ? col : st === 'building' ? '#ffb347' : '#0d1530';
    c.strokeStyle = st === 'closed' ? 'rgba(180,200,245,.7)' : '#fff'; c.lineWidth = on ? 2.6 : 1.5;
    c.beginPath(); c.arc(x, y, on ? 6.6 : 5, 0, TAU); c.fill(); c.stroke();
    if (st === 'building') { c.strokeStyle = '#ffb347'; c.lineWidth = 1.6; c.beginPath(); c.arc(x, y, 10, T * 3, T * 3 + 2.4); c.stroke(); }
    if (on) { c.strokeStyle = 'rgba(255,255,255,.55)'; c.lineWidth = 1; c.beginPath(); c.arc(x, y, 11 + Math.sin(T * 3) * 1.2, 0, TAU); c.stroke(); }
    c.globalAlpha = 1;
  }
  const FONT_B = '700 10.5px Inter, system-ui, sans-serif', FONT_S = '600 9px Inter, system-ui, sans-serif';
  function label(rg, p, placed) {
    const st = G.state, open = !!st.regions[rg.id], on = sel === rg.id, name = NAME[rg.id];
    const sub = open ? U.num((G.C.reg[rg.id] || { pot: 0 }).pot) + ' users' : G.regionStatus(rg.id) === 'ready' ? 'Ready to open' : G.regionStatus(rg.id) === 'building' ? 'Building…' : 'Locked';
    c.font = FONT_B; const nw = c.measureText(name).width; c.font = FONT_S; const sw = c.measureText(sub).width;
    const w = Math.max(nw, sw) + 16, h = 29;
    let x = p[0] + 11, y = p[1] - h / 2;
    if (x + w > W - 4) x = p[0] - 11 - w;
    x = U.clamp(x, 4, W - w - 4);
    for (let tries = 0; tries < 6; tries++) {
      let hit = false;
      for (const r of placed) if (x < r.x + r.w + 2 && x + w + 2 > r.x && y < r.y + r.h + 2 && y + h + 2 > r.y) { hit = true; y += (tries % 2 ? -1 : 1) * (h + 3) * Math.ceil((tries + 1) / 2); break; }
      if (!hit) break;
    }
    y = U.clamp(y, 4, H - inset.b - h - 2);
    const rect = { x, y, w, h, id: rg.id }; placed.push(rect); pills.push(rect);
    c.globalAlpha = Math.min(1, p[2] * 2.4);
    c.fillStyle = on ? 'rgba(10,20,46,.94)' : 'rgba(7,12,30,.8)';
    c.beginPath(); c.roundRect ? c.roundRect(x, y, w, h, 9) : c.rect(x, y, w, h); c.fill();
    c.lineWidth = on ? 1.6 : 1; c.strokeStyle = on ? rgba(COL[rg.id], 0.95) : 'rgba(190,215,255,.22)'; c.stroke();
    c.textAlign = 'left'; c.textBaseline = 'middle';
    c.font = FONT_B; c.fillStyle = on ? '#ffffff' : '#dfe8ff'; c.fillText(name, x + 8, y + 10.5);
    c.font = FONT_S; c.fillStyle = open ? rgba(COL[rg.id], 1) : '#8fa0cf'; c.fillText(sub, x + 8, y + 22);
    c.globalAlpha = 1; c.textBaseline = 'alphabetic';
  }
  // a thin ring around the globe with two satellites riding it
  function paintRing(front) {
    const rx = R * 1.36, ry = R * 0.3, rot = -0.34, cr = Math.cos(rot), sr = Math.sin(rot);
    c.strokeStyle = 'rgba(160,205,255,.2)'; c.lineWidth = 1; c.beginPath();
    for (let i = 0; i <= 40; i++) {
      const a = (front ? 0 : Math.PI) + (i / 40) * Math.PI, x = Math.cos(a) * rx, y = Math.sin(a) * ry;
      const X = cx + x * cr - y * sr, Y = cy + x * sr + y * cr;
      if (i) c.lineTo(X, Y); else c.moveTo(X, Y);
    }
    c.stroke();
    if (S_Q() === 0) return;
    for (let k = 0; k < 2; k++) {
      const a = (T * (0.32 + k * 0.1) + k * 3.1) % TAU, s = Math.sin(a);
      if ((s >= 0) !== front) continue;
      const x = Math.cos(a) * rx, y = s * ry, X = cx + x * cr - y * sr, Y = cy + x * sr + y * cr;
      c.globalCompositeOperation = 'lighter'; c.drawImage(G.art.glow('#9fe6ff'), X - 9, Y - 9, 18, 18); c.globalCompositeOperation = 'source-over';
      c.fillStyle = '#eafcff'; c.fillRect(X - 1.6, Y - 1.6, 3.2, 3.2);
    }
  }

  M.render = function (ms) {
    if (!cv || !c) return;
    M.resize();
    if (!bodyImg || !dots) return;
    const dt = last ? U.clamp((ms - last) / 1000, 0, 0.1) : 0.033;
    last = ms; T += dt;
    // The globe turns to the chosen region, then sways a little so it never looks frozen. After a drag it stays where the player left it.
    {
      const k = 1 - Math.exp(-dt * (entering ? 1.6 : 3));
      const sway = manual ? 0 : Math.sin(T * 0.35) * 0.07;
      setView(yaw + angDiff(goYaw + sway, yaw) * k, tilt + (goTilt - tilt) * k);
      if (entering && Math.abs(angDiff(goYaw, yaw)) < 0.03) entering = false;
    }
    c.setTransform(dpr, 0, 0, dpr, 0, 0);
    c.clearRect(0, 0, W, H);
    c.drawImage(starImg, 0, 0, W, H);
    paintRing(false);
    c.drawImage(bodyImg.cv, cx - bodyImg.s / 2, cy - bodyImg.s / 2, bodyImg.s, bodyImg.s);
    paintGrid();
    for (const rg of D.regions) if (G.state.regions[rg.id]) paintPatch(rg, sel === rg.id);
    paintDots();
    paintArcs();
    // markers, then name tags (the selected region first, so it gets the best spot)
    hits.length = 0; pills.length = 0;
    const vis = [];
    for (const rg of D.regions) { const p = project(rg.lon * RAD, rg.lat * RAD); if (p[2] > 0.04) vis.push({ rg, p: [p[0], p[1], p[2]] }); }
    vis.sort((a, b) => a.p[2] - b.p[2]);
    for (const v of vis) { paintMarker(v.rg, v.p); hits.push({ id: v.rg.id, x: v.p[0], y: v.p[1] }); }
    const placed = [];
    vis.sort((a, b) => (sel === b.rg.id) - (sel === a.rg.id) || b.p[2] - a.p[2]);
    for (const v of vis) if (v.p[2] > 0.3 || sel === v.rg.id) label(v.rg, v.p, placed);
    paintRing(true);
  };
})();
