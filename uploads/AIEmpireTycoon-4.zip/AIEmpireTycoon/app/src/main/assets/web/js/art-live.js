/* AI Empire Tycoon - what moves on a building.
   The building itself is drawn once into a sprite (art-office.js, art-dc.js, art-infra.js). Everything that blinks, spins, flows or
   glows is drawn here, every frame, on top of that sprite, from a plain list of parts the building filled in while it was drawn:
       o.parts = [ { t: 'fan', p: [x, y], r: 8 }, { t: 'blink', p: [x, y], col: '#ff4d5e' }, ... ]
   A new kind of animation is one more entry in PARTS. Positions are in the building's own picture space (the same as the drawing),
   colours are hex strings. env = { q (0 low, 1 medium, 2 high), util, active, lamp (0 day .. 1 night), acc } comes from the scene.
   A.paintLive(c, o, T, env) is also what the upgrade thumbnails and the test sheet use, so every place shows the same picture. */
(function () {
  'use strict';
  const G = window.G, U = G.U, A = G.art;
  const TAU = Math.PI * 2;
  const PARTS = (A.parts = {});
  const hash = A.hash;

  const dot = (c, x, y, r, col) => { c.fillStyle = col; c.beginPath(); c.arc(x, y, r, 0, TAU); c.fill(); };
  function halo(c, x, y, r, hex, a) {
    if (a <= 0.01) return;
    c.globalCompositeOperation = 'lighter'; c.globalAlpha = Math.min(1, a);
    c.drawImage(A.glow(hex), x - r, y - r, r * 2, r * 2);
    c.globalAlpha = 1; c.globalCompositeOperation = 'source-over';
  }
  // Soft round puffs: one small radial sprite per colour, drawn scaled and faded (a gradient per puff per frame would cost too much).
  const puffCache = {};
  function puffSprite(col) {
    if (puffCache[col] !== undefined) return puffCache[col];
    const m = /^rgba?\((\d+),\s*(\d+),\s*(\d+)/.exec(col);
    if (!m) return (puffCache[col] = null);
    const s = document.createElement('canvas'); s.width = s.height = 32;
    const g = s.getContext('2d'), gr = g.createRadialGradient(16, 16, 0, 16, 16, 16), base = 'rgba(' + m[1] + ',' + m[2] + ',' + m[3] + ',';
    gr.addColorStop(0, base + '1)'); gr.addColorStop(0.45, base + '0.62)'); gr.addColorStop(1, base + '0)');
    g.fillStyle = gr; g.fillRect(0, 0, 32, 32);
    return (puffCache[col] = s);
  }
  function puffs(c, x, y, n, col, rise, size, speed, a) {
    const spr = puffSprite(col);
    for (let k = 0; k < n; k++) {
      const ph = (puffs.T * (speed || 0.3) + k / n) % 1, px = x + Math.sin(ph * 6 + k * 2) * 4, py = y - ph * rise, rx = size * (0.6 + ph), ry = size * (0.42 + ph * 0.6);
      c.globalAlpha = (1 - ph) * (a === undefined ? 0.4 : a);
      if (spr) c.drawImage(spr, px - rx * 1.5, py - ry * 1.5, rx * 3, ry * 3);
      else { c.fillStyle = col; c.beginPath(); c.ellipse(px, py, rx, ry, 0, 0, TAU); c.fill(); }
    }
    c.globalAlpha = 1;
  }
  puffs.T = 0;
  // a point that travels along a polyline; seg holds the lengths of the pieces (cached on the part)
  function track(p, key) {
    const pts = p[key || 'pts'];
    if (!p._len) { p._seg = []; let L = 0; for (let i = 1; i < pts.length; i++) { const l = Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]); p._seg.push(l); L += l; } p._len = L || 1; }
    return (t) => {
      let s = (((t % 1) + 1) % 1) * p._len, i = 0;
      while (i < p._seg.length - 1 && s > p._seg[i]) { s -= p._seg[i]; i++; }
      const k = p._seg[i] ? s / p._seg[i] : 0, a = pts[i], b = pts[i + 1];
      return [a[0] + (b[0] - a[0]) * k, a[1] + (b[1] - a[1]) * k];
    };
  }
  const few = (env, n) => (env.q >= 2 ? n : Math.max(1, Math.ceil(n / 2)));

  /* ---------- the parts ---------- */
  PARTS.fan = (c, p, T, env) => {
    c.save(); c.translate(p.p[0], p.p[1]); c.scale(1, 0.55); c.rotate(T * (p.spd || 7 + (env.util || 0) * 4));
    c.fillStyle = 'rgba(14,22,44,.9)'; c.beginPath(); c.arc(0, 0, p.r, 0, TAU); c.fill();
    c.strokeStyle = 'rgba(200,218,245,.9)'; c.lineWidth = 1.8; c.beginPath();
    for (let i = 0; i < 3; i++) { const a = i * 2.094; c.moveTo(0, 0); c.lineTo(Math.cos(a) * p.r * 0.92, Math.sin(a) * p.r * 0.92); }
    c.stroke(); c.restore();
  };
  // a light that blinks: per = seconds per blink, duty = share of it that is on, ph = offset in blinks
  PARTS.blink = (c, p, T) => {
    const per = p.per || 1.2, on = (T / per + (p.ph || 0)) % 1 < (p.duty || 0.5), x = p.p[0], y = p.p[1];
    dot(c, x, y, p.r || 2, on ? p.col || '#ff4d5e' : 'rgba(60,24,34,.85)');
    if (on && p.glow) halo(c, x, y, p.glow, p.col || '#ff4d5e', 0.5);
  };
  // a street lamp or a window lamp: only glows when it is dark
  PARTS.lamp = (c, p, T, env) => halo(c, p.p[0], p.p[1], p.r || 14, p.col || '#ffd28a', (p.a || 0.4) * (env.lamp === undefined ? 1 : env.lamp));
  // a steady or breathing glow
  PARTS.glow = (c, p, T) => halo(c, p.p[0], p.p[1], p.r || 20, p.col || '#7fe9ff', (p.a || 0.3) * (p.pulse ? 0.75 + 0.25 * Math.sin(T * p.pulse + (p.ph || 0)) : 1));
  // a radar bar that turns (with a faint sweep behind it)
  PARTS.radar = (c, p, T, env) => {
    const x = p.p[0], y = p.p[1], r = p.r || 9, a = T * (p.spd || 1.1) + (p.ph || 0), dx = Math.cos(a) * r, dy = Math.sin(a) * r * 0.5;
    if (env.q > 0) { c.fillStyle = U.rgba(p.col || '#3dd6c6', 0.1); c.beginPath(); c.moveTo(x, y); c.ellipse(x, y, r * 2.6, r * 1.3, 0, a - 0.5, a); c.closePath(); c.fill(); }
    c.strokeStyle = '#dbe6ff'; c.lineWidth = 2.2; c.lineCap = 'round'; c.beginPath(); c.moveTo(x - dx, y - dy); c.lineTo(x + dx, y + dy); c.stroke();
    c.strokeStyle = '#7a8aa8'; c.lineWidth = 1; c.beginPath(); c.moveTo(x - dx * 0.9, y - dy * 0.9 + 1.4); c.lineTo(x + dx * 0.9, y + dy * 0.9 + 1.4); c.stroke();
    dot(c, x, y, 2, '#9fb0d4'); dot(c, x + dx, y + dy, 1.5, p.feed || '#ff9f6b');
  };
  // rotor blades turning in the plane of a wall (a wind turbine, a ventilation wheel)
  PARTS.rotor = (c, p, T) => {
    const x = p.p[0], y = p.p[1], r = p.r || 12, a = T * (p.spd || 2.2);
    c.strokeStyle = p.col || '#e8f0ff'; c.lineWidth = p.w || 1.8; c.lineCap = 'round'; c.beginPath();
    for (let k = 0; k < (p.n || 3); k++) { const t = a + (k * TAU) / (p.n || 3); c.moveTo(x, y); c.lineTo(x + Math.cos(t) * r * 0.6, y + Math.sin(t) * r); }
    c.stroke(); dot(c, x, y, 2, '#c3d0ee');
  };
  PARTS.flag = (c, p, T) => {
    const x = p.p[0], y = p.p[1], w = p.w || 13, h = p.h || 7, n = 6, top = [], bot = [];
    for (let i = 0; i <= n; i++) { const t = i / n, dy = Math.sin(T * 4.2 + i * 0.9) * 1.8 * t; top.push([x + t * w, y + dy + t * 1.5]); bot.push([x + t * w, y + h + dy + t * 1.5]); }
    c.fillStyle = p.col || '#3dd6c6'; c.beginPath(); top.forEach((q, i) => (i ? c.lineTo(q[0], q[1]) : c.moveTo(q[0], q[1]))); for (let i = n; i >= 0; i--) c.lineTo(bot[i][0], bot[i][1]); c.closePath(); c.fill();
    c.fillStyle = 'rgba(255,255,255,.28)'; c.fillRect(x + 1, y + h * 0.4, w * 0.45, 1.4);
  };
  PARTS.steam = (c, p, T, env) => { puffs.T = T; puffs(c, p.p[0], p.p[1], few(env, p.n || 4), p.col || 'rgba(210,220,235,1)', p.rise || 40, p.size || 7, p.speed || 0.25, p.a); };
  // dots that travel along a pipe or a cable (coolant, data, power)
  PARTS.flow = (c, p, T, env) => {
    const at = track(p), n = few(env, p.n || 5), sp = (p.spd || 0.35) * (p.dir || 1);
    c.fillStyle = p.col || '#7fe9ff';
    for (let k = 0; k < n; k++) { const q = at(T * sp + k / n); c.beginPath(); c.arc(q[0], q[1], p.size || 1.6, 0, TAU); c.fill(); }
  };
  // lights that run along a line (the edges of a tower, a track)
  PARTS.chase = (c, p, T, env) => {
    const at = track(p), n = few(env, p.n || 3);
    for (let k = 0; k < n; k++) { const q = at(T * (p.spd || 0.3) + k / n + (p.ph || 0)); dot(c, q[0], q[1], p.size || 1.8, p.col || '#bff7ff'); halo(c, q[0], q[1], p.glow || 9, p.col || '#7fe9ff', 0.55); }
  };
  // a flicker of electricity between two points
  PARTS.arc = (c, p, T) => {
    const slot = Math.floor(T * 14 + (p.ph || 0) * 7), id = Math.round((p.ph || 0) * 9);
    if (hash(slot, id, 3) > (p.rate || 0.25)) return;
    const a = p.a, b = p.b, j = p.jit || 6, pts = [a];
    for (let i = 1; i < 5; i++) { const t = i / 5; pts.push([a[0] + (b[0] - a[0]) * t + (hash(slot, i, 11) - 0.5) * j, a[1] + (b[1] - a[1]) * t + (hash(slot, i, 17) - 0.5) * j]); }
    pts.push(b);
    c.strokeStyle = p.col || '#bfe9ff'; c.lineWidth = 1.3; c.lineJoin = 'round'; c.beginPath(); pts.forEach((q, i) => (i ? c.lineTo(q[0], q[1]) : c.moveTo(q[0], q[1]))); c.stroke();
    halo(c, b[0], b[1], 14, p.col || '#9fd8ff', 0.5);
  };
  // signal waves spreading from a point
  PARTS.rings = (c, p, T, env) => {
    const n = few(env, p.n || 3);
    for (let k = 0; k < n; k++) {
      const ph = (T * (p.spd || 0.5) + k / n) % 1;
      c.strokeStyle = U.rgba(p.col || '#3dd6c6', (1 - ph) * (p.a || 0.7)); c.lineWidth = p.w || 1.4;
      c.beginPath(); c.ellipse(p.p[0], p.p[1], (p.rx || 24) * (0.15 + ph), (p.ry || 12) * (0.15 + ph), 0, 0, TAU); c.stroke();
    }
  };
  // something that rides up and down a line (a lift in a glass shaft)
  PARTS.lift = (c, p, T) => {
    const per = p.per || 7, t = ((T + (p.ph || 0) * per) % per) / per, k = t < 0.5 ? t * 2 : (1 - t) * 2, e = k * k * (3 - 2 * k);
    const x = p.a[0] + (p.b[0] - p.a[0]) * e, y = p.a[1] + (p.b[1] - p.a[1]) * e;
    dot(c, x, y, 1.8, p.col || '#fff2c4'); halo(c, x, y, 8, p.col || '#ffd28a', 0.5);
  };
  // anything animated painted onto a wall: fn(cc, W, H, T, env), flat, W x H pixels (screens, bar charts, status panels)
  PARTS.face = (c, p, T, env) => A.kit.sheet(c, p.f, (cc, W, H) => p.fn(cc, W, H, T, env));
  // dots on an ellipse (particles in a ring, planets round a core)
  PARTS.orbit = (c, p, T, env) => {
    const n = few(env, p.n || 6), rot = p.rot || 0, cr = Math.cos(rot), sr = Math.sin(rot);
    if (p.line) { c.strokeStyle = U.rgba(p.col || '#7fe9ff', p.line); c.lineWidth = 1; c.beginPath(); c.ellipse(p.p[0], p.p[1], p.rx, p.ry, rot, 0, TAU); c.stroke(); }
    for (let k = 0; k < n; k++) {
      const a = T * (p.spd || 1) + (k * TAU) / n + (p.ph || 0), ex = Math.cos(a) * p.rx, ey = Math.sin(a) * p.ry, x = p.p[0] + ex * cr - ey * sr, y = p.p[1] + ex * sr + ey * cr;
      if (p.front && Math.sin(a) < 0) continue;
      if (p.back && Math.sin(a) >= 0) continue;
      dot(c, x, y, p.size || 1.8, p.col || '#bff7ff'); if (p.glow) halo(c, x, y, p.glow, p.col || '#7fe9ff', 0.5);
    }
  };
  // dark windows that light up for a while at night: rects are [x, y, w, h] in the face's own pixels
  PARTS.twinkle = (c, p, T, env) => {
    const night = env.lamp === undefined ? 1 : env.lamp;
    if (night < 0.08) return;
    A.kit.sheet(c, p.f, (cc) => {
      for (const q of p.rects) {
        const a = Math.max(0, Math.min(1, Math.sin((T / q.per + q.ph) * TAU) * 2.2)) * night;
        if (a < 0.02) continue;
        const r = q.r, g = cc.createLinearGradient(0, r[1], 0, r[1] + r[3]);
        g.addColorStop(0, p.col(0.95 * a)); g.addColorStop(1, p.col(0.6 * a));
        cc.fillStyle = g; cc.fillRect(r[0], r[1], r[2], r[3]);
      }
    });
  };
  // a floating crystal that turns slowly (the crown of the spire, the heart of a quantum core)
  PARTS.crystal = (c, p, T, env) => {
    const x = p.p[0], y = p.p[1] + Math.sin(T * 1.3 + (p.ph || 0)) * (p.bob === undefined ? 2.2 : p.bob), h = p.h || 18, w = p.w || 8, col = p.col || '#7fe9ff';
    halo(c, x, y, h * 2.2, col, 0.32 + 0.12 * Math.sin(T * 2));
    const k = Math.cos(T * (p.spd || 0.9)), sx = w * Math.abs(k) + 1.2;
    c.save(); c.translate(x, y);
    const top = [0, -h], bot = [0, h * 0.78], L = [-sx, 0], R = [sx, 0], mid = [k * w * 0.35, -h * 0.12];
    const face = (pts, fill) => { c.fillStyle = fill; c.beginPath(); pts.forEach((q, i) => (i ? c.lineTo(q[0], q[1]) : c.moveTo(q[0], q[1]))); c.closePath(); c.fill(); };
    face([top, L, mid], U.rgba(col, k > 0 ? 0.95 : 0.55)); face([top, mid, R], U.rgba(col, k > 0 ? 0.55 : 0.95));
    face([L, bot, mid], U.shade(col, 0.55)); face([mid, bot, R], U.shade(col, 0.4));
    c.strokeStyle = 'rgba(255,255,255,.7)'; c.lineWidth = 0.9; c.beginPath(); c.moveTo(top[0], top[1]); c.lineTo(L[0], L[1]); c.lineTo(bot[0], bot[1]); c.lineTo(R[0], R[1]); c.closePath(); c.moveTo(top[0], top[1]); c.lineTo(mid[0], mid[1]); c.lineTo(bot[0], bot[1]); c.stroke();
    c.restore();
    dot(c, x, y - h * 0.1, 1.6, '#ffffff');
  };
  // a string of party bulbs: pts = their positions, cols = the colours they take in turn
  PARTS.bulbs = (c, p, T) => {
    p.pts.forEach((q, i) => {
      const col = p.cols[i % p.cols.length], a = 0.55 + 0.45 * Math.sin(T * 2.4 + i * 1.7);
      dot(c, q[0], q[1], p.size || 1.7, U.rgba(col, a));
      if (a > 0.78) halo(c, q[0], q[1], 6, col, 0.35);
    });
  };
  // a hologram: a glowing core inside two turning rings
  PARTS.holo = (c, p, T, env) => {
    const x = p.p[0], y = p.p[1], r = p.r || 14, col = p.col || '#9be7ff';
    halo(c, x, y, r * 1.8, col, 0.35 + 0.15 * Math.sin(T * 2));
    c.lineWidth = 1.2;
    for (let k = 0; k < (env.q >= 2 ? 2 : 1); k++) {
      c.strokeStyle = U.rgba(col, 0.75); c.beginPath(); c.ellipse(x, y, r, r * 0.34, T * (0.9 + k * 0.5) + k * 1.2, 0, TAU); c.stroke();
    }
    dot(c, x, y, r * 0.2, '#f2feff');
  };
  // a satellite going round
  PARTS.sat = (c, p, T) => {
    const a = T * (p.spd || 0.25) + (p.ph || 0), x = p.p[0] + Math.cos(a) * p.rx, y = p.p[1] + Math.sin(a) * p.ry;
    c.save(); c.translate(x, y);
    c.fillStyle = '#cfd9ee'; c.fillRect(-1.6, -1.6, 3.2, 3.2);
    c.fillStyle = '#4d86d6'; c.fillRect(-7, -1, 4.5, 2); c.fillRect(2.5, -1, 4.5, 2);
    c.restore(); dot(c, x, y + 0.2, 0.7, '#ff4d5e');
  };
  // a sheen that slides over glass panels (solar fields): poly = the panel outline in picture space
  PARTS.glint = (c, p, T) => {
    const k = ((T * (p.spd || 0.22) + (p.ph || 0)) % 1) * 1.6 - 0.3, pt = p.poly;
    let x0 = 1e9, x1 = -1e9, y0 = 1e9, y1 = -1e9; for (const q of pt) { x0 = Math.min(x0, q[0]); x1 = Math.max(x1, q[0]); y0 = Math.min(y0, q[1]); y1 = Math.max(y1, q[1]); }
    c.save(); c.beginPath(); pt.forEach((q, i) => (i ? c.lineTo(q[0], q[1]) : c.moveTo(q[0], q[1]))); c.closePath(); c.clip();
    const bx = x0 + (x1 - x0) * k, w = (x1 - x0) * 0.18;
    c.fillStyle = 'rgba(255,255,255,.3)'; c.beginPath(); c.moveTo(bx, y1); c.lineTo(bx + w, y1); c.lineTo(bx + w + (y1 - y0) * 0.5, y0); c.lineTo(bx + (y1 - y0) * 0.5, y0); c.closePath(); c.fill();
    c.restore();
  };
  // a beam of light between two points that breathes
  PARTS.beam = (c, p, T) => {
    const a = p.a, b = p.b, k = 0.7 + 0.3 * Math.sin(T * (p.spd || 3)), w = (p.w || 3) * k;
    const g = c.createLinearGradient(a[0], a[1], b[0], b[1]); g.addColorStop(0, U.rgba(p.col || '#ffe08a', 0.85)); g.addColorStop(1, U.rgba(p.col || '#ffe08a', 0));
    c.strokeStyle = g; c.lineWidth = w; c.lineCap = 'round'; c.beginPath(); c.moveTo(a[0], a[1]); c.lineTo(b[0], b[1]); c.stroke();
    c.lineWidth = 1; c.strokeStyle = U.rgba('#ffffff', 0.5 * k); c.beginPath(); c.moveTo(a[0], a[1]); c.lineTo(b[0], b[1]); c.stroke();
  };

  /* ---------- the older overlays (still used by the halls, the lab and the HQ interiors) ---------- */
  function orb(c, o, T, active) {
    const x = o.p[0], y = o.p[1], r = o.r, pts = [];
    for (let i = 0; i < 7; i++) { const a = T * (active ? 1.3 : 0.6) + i * 0.9; pts.push([x + Math.cos(a) * r, y + Math.sin(a) * r * 0.55 + Math.sin(T * 1.3 + i) * 2.5]); }
    c.strokeStyle = U.rgba('#9be7ff', 0.55); c.lineWidth = 1; c.beginPath();
    for (let i = 0; i < 7; i++) { c.moveTo(pts[i][0], pts[i][1]); c.lineTo(pts[(i + 1) % 7][0], pts[(i + 1) % 7][1]); c.moveTo(pts[i][0], pts[i][1]); c.lineTo(pts[(i + 3) % 7][0], pts[(i + 3) % 7][1]); }
    c.stroke();
    c.fillStyle = '#eafcff';
    for (const q of pts) { c.beginPath(); c.arc(q[0], q[1], 1.8, 0, TAU); c.fill(); }
  }
  function ring(c, o, T, spd, acc) {
    const p = o.c;
    c.strokeStyle = U.rgba(acc, 0.95); c.lineWidth = 2.4;
    for (let k = 0; k < 2; k++) { const a = T * spd + k * Math.PI; c.beginPath(); c.ellipse(p[0], p[1], o.rx, o.ry, 0, a, a + 1.9); c.stroke(); }
  }

  /* ---------- everything on one building ---------- */
  A.paintLive = function (c, o, T, env) {
    env = env || {};
    const q = env.q === undefined ? 2 : env.q, acc = env.acc || '#3dd6c6';
    c.save();
    if (o.shift) c.translate(o.shift[0], o.shift[1]);
    if (o.fans) for (const f of o.fans) PARTS.fan(c, f, T, env);
    if (o.screens) { c.fillStyle = 'rgba(150,240,255,' + (0.25 + 0.2 * Math.sin(T * 5)) + ')'; for (const s of o.screens) { c.beginPath(); c.moveTo(s[0][0], s[0][1]); for (let i = 1; i < 4; i++) c.lineTo(s[i][0], s[i][1]); c.closePath(); c.fill(); } }
    if (o.ledPts) for (let i = 0; i < o.ledPts.length; i++) { c.fillStyle = Math.sin(T * 6 + i * 2) > 0 ? '#2be3b8' : '#1a4f4a'; c.fillRect(o.ledPts[i][0] - 1.5, o.ledPts[i][1] - 1, 3, 2); }
    if (o.lights) o.lights.forEach((p, i) => { c.fillStyle = 'rgba(255,214,150,' + (0.55 + 0.4 * Math.sin(T * 3 + i)) + ')'; c.beginPath(); c.arc(p[0], p[1], 1.6, 0, TAU); c.fill(); });
    puffs.T = T;
    if (o.smoke) for (const sm of o.smoke) puffs(c, sm.p[0], sm.p[1], q === 2 ? 4 : 2, 'rgba(210,220,235,1)', 40, 7 * sm.s, 0.25);
    if (o.bubbles) for (const b of o.bubbles) {
      if (b.mist) puffs(c, b.p[0], b.p[1], 3, 'rgba(190,225,255,1)', 26, 6, 0.35);
      else { c.fillStyle = 'rgba(200,245,255,.7)'; for (let i = 0; i < 4; i++) { const ph = (T * 0.6 + i / 4) % 1; c.beginPath(); c.arc(b.p[0] - 6 + i * 4, b.p[1] + 10 - ph * 16, 1.4, 0, TAU); c.fill(); } }
    }
    if (o.ring) ring(c, o.ring, T, o.ring.small ? 1.4 : 0.9, acc);
    if (o.ringC) ring(c, { c: o.ringC, rx: 62, ry: 24 }, T, 0.7, acc);
    if (o.orb) orb(c, o.orb, T, !!env.active);
    if (o.beacon) { c.fillStyle = Math.sin(T * 3) > 0.1 ? '#ff4d5e' : '#5a2430'; c.beginPath(); c.arc(o.beacon[0], o.beacon[1], 2.2, 0, TAU); c.fill(); }
    if (o.top) { c.fillStyle = Math.sin(T * 4 + 1) > 0 ? '#ff4d5e' : '#5a2430'; c.beginPath(); c.arc(o.top[0], o.top[1], 2, 0, TAU); c.fill(); }
    if (o.seats && q > 0) o.seats.forEach((s, i) => { const p = A.P(s[0], s[1], 4 + 3); A.person(c, p[0], p[1] + 2, T * 7 + i, ['#ff9f6b', '#6bb8ff', '#b78cff', '#6be3b0', '#ffd16b', '#ff7f9e'][i % 6], true, A.people.skin(i + 1), { look: i * 3 + 2, face: i % 2 ? -1 : 1 }); });
    if (o.parts) for (const p of o.parts) { const fn = PARTS[p.t]; if (fn && !(p.q > q)) fn(c, p, T, env, o); }
    if (o.live) o.live(c, T, env);
    c.restore();
  };
})();
