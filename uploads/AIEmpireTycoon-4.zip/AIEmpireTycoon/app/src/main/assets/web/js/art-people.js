/* AI Empire Tycoon - people. One figure (A.person) is used by everyone on the island: staff walking the roads, builders on the sites,
   the people at the desks in the garage and the office, the technician in the data hall.
   The figure is drawn in a friendly cartoon style that still reads when the island is zoomed out: a big round head, large eyes, a dark
   outline round every shape, two-tone cloth, and a stride and arm swing that follow the walking phase. About 30 px tall standing, which
   is the height of a server rack, so a person fits the world they walk in.
   A figure is made from a "look", a small integer: hair style and colour, trousers, shoes, glasses, headset, bag, lanyard and build all
   follow from it, so the same number is always the same person and a crowd never looks cloned.
   A.person(c, px, py, ph, shirt, seated, skin, opts)
     ph    walking phase in radians (legs and arms swing with it); when seated it drives the typing hands
     opts  { look, face (+1 / -1: the screen direction it looks), back (true: walking away, so only the back of the head shows),
             hat (a hard hat colour), vest (hi-vis stripes), coat (a white lab coat), still (no walking bob),
             arm ([x, y]: where the right hand goes, in the figure's own pixels, feet at 0,0) }
   It returns where the right hand is (in the caller's coordinates), so a tool can be put in it. */
(function () {
  'use strict';
  const G = window.G, U = G.U, A = G.art;
  const TAU = Math.PI * 2;
  const SKINS = ['#f6dcc6', '#ecc9a4', '#d6a57d', '#b9805a', '#8f5d3e', '#6b4530'];
  const HAIRS = ['#1a1622', '#2c2336', '#4a2f1f', '#6e4a2a', '#b04a2c', '#e0b95e', '#9b9bab'];
  const PANTS = ['#26324f', '#3a4666', '#4d4466', '#3c5046', '#5e4d3c', '#6c7490'];
  const SHOES = ['#171a26', '#f2f4fa', '#2d3550', '#8a4b32'];
  const OL = 0.95;                         // width of the dark outline, in figure pixels
  const EYE = '#1b1730';
  const sh = U.shade;
  const hashOf = (s) => { let h = 7; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0; return Math.abs(h); };

  /* ---------- who is this: everything that is not the shirt, from one integer ---------- */
  const looks = {};
  // a small integer hash, so each attribute of a look is picked independently
  const pick = (n, a, salt) => { let h = Math.imul(a + 1 + salt * 7919, 0x2c1b3c6d); h ^= h >>> 15; h = Math.imul(h, 0x297a2d39); h ^= h >>> 13; return (h >>> 0) % n; };
  function lookOf(k, skin) {
    const a = Math.abs(k | 0), key = a + '|' + (skin || '');
    return looks[key] || (looks[key] = {
      key,
      skin: skin || SKINS[pick(SKINS.length, a, 1)],
      hair: HAIRS[pick(HAIRS.length, a, 2)],
      pants: PANTS[pick(PANTS.length, a, 3)],
      shoe: SHOES[pick(SHOES.length, a, 4)],
      style: pick(7, a, 5),                        // 0 short, 1 long, 2 ponytail, 3 curly, 4 buzz, 5 bob, 6 cap
      glasses: pick(5, a, 6) === 0,
      headset: pick(8, a, 7) === 0,
      bag: pick(4, a, 8) === 0,
      badge: pick(3, a, 9) !== 0,
      shorts: pick(9, a, 10) === 0,
      size: 0.96 + pick(7, a, 11) * 0.016,         // legs a little longer or shorter from person to person
      wide: 0.94 + pick(5, a, 12) * 0.04           // slimmer or broader
    });
  }

  /* ---------- every colour a figure needs, worked out once per (look, shirt, hat) ---------- */
  const styles = {};
  function styleOf(l, shirt, o) {
    const key = l.key + '|' + shirt + '|' + (o.hat || '') + (o.vest ? 'v' : '') + (o.coat ? 'c' : '');
    if (styles[key]) return styles[key];
    const base = o.coat ? '#f1f5fc' : shirt;
    return (styles[key] = {
      skinD: sh(l.skin, 0.86), skinO: sh(l.skin, 0.46), cheek: 'rgba(255,105,120,.3)',
      hairH: sh(l.hair, 1.55), hairO: sh(l.hair, 0.42), hairD: sh(l.hair, 0.78),
      pantsD: sh(l.pants, 0.72), pantsO: sh(l.pants, 0.36), pantsH: sh(l.pants, 1.25),
      shoeO: '#0a0c14', sole: l.shoe === '#f2f4fa' ? '#9aa3bb' : '#2b3147',
      cloth: base, clothL: sh(base, 1.16), clothD: sh(base, 0.78), clothO: sh(base, 0.4),
      capC: sh(shirt, 0.82), capO: sh(shirt, 0.4),
      hatD: o.hat ? sh(o.hat, 0.74) : '', hatO: o.hat ? sh(o.hat, 0.4) : ''
    });
  }

  /* ---------- little drawing helpers (all in figure pixels) ---------- */
  function rr(c, x, y, w, h, r) { c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath(); }
  function fillOut(c, fill, ol) { c.fillStyle = fill; c.fill(); c.lineWidth = OL; c.strokeStyle = ol; c.stroke(); }
  function ell(c, x, y, rx, ry, fill, ol) { c.beginPath(); c.ellipse(x, y, rx, ry, 0, 0, TAU); if (ol) fillOut(c, fill, ol); else { c.fillStyle = fill; c.fill(); } }
  // a thick round-ended stroke with a dark edge: legs and arms
  function limb(c, pts, w, fill, ol) {
    c.beginPath(); c.moveTo(pts[0], pts[1]);
    if (pts.length > 4) c.quadraticCurveTo(pts[2], pts[3], pts[4], pts[5]); else c.lineTo(pts[2], pts[3]);
    if (pts.length > 6) c.lineTo(pts[6], pts[7]);
    c.lineWidth = w + OL * 2; c.strokeStyle = ol; c.stroke();
    c.lineWidth = w; c.strokeStyle = fill; c.stroke();
  }

  /* ---------- hair that sits behind the head and shoulders ---------- */
  function hairBack(c, l, st, hx, hy, f, ph, o) {
    if (o.hat && l.style !== 1) return;
    if (l.style === 1) { rr(c, hx - 4.9, hy - 1, 9.8, 10.2, 3.6); fillOut(c, l.hair, st.hairO); }                          // long hair falls behind the shoulders
    else if (l.style === 2 && !o.hat) { const sw = Math.sin(ph * 2) * 0.9; c.beginPath(); c.ellipse(hx - f * 5.6, hy + 0.6 + sw * 0.3, 1.9, 3.1, f * 0.5 + sw * 0.12, 0, TAU); fillOut(c, l.hair, st.hairO); }   // ponytail
    else if (l.style === 3) { c.beginPath(); c.arc(hx, hy - 0.9, 5.7, 0, TAU); fillOut(c, l.hair, st.hairO); c.fillStyle = st.hairH; c.beginPath(); c.arc(hx - 1.8, hy - 3.6, 1.2, 0, TAU); c.fill(); }   // curly puff
  }

  /* ---------- hair, caps and hats in front of the face ---------- */
  function hairFront(c, l, st, hx, hy, f, o, back) {
    const dome = (col, ol, rx, ry, dy) => { c.beginPath(); c.ellipse(hx, hy + dy, rx, ry, 0, Math.PI, TAU); c.closePath(); fillOut(c, col, ol); };
    if (o.hat) {                                                                   // hard hat: round crown, brim, ridge and a bright highlight
      dome(o.hat, st.hatO, 4.95, 4.5, -0.5);
      c.fillStyle = st.hatD; c.fillRect(hx - 0.7, hy - 5.0, 1.4, 4.3);
      c.beginPath(); c.ellipse(hx + f * 0.4, hy - 0.9, 6.0, 1.3, 0, 0, TAU); fillOut(c, st.hatD, st.hatO);
      c.fillStyle = 'rgba(255,255,255,.5)'; c.beginPath(); c.ellipse(hx - 1.8, hy - 3.5, 1.2, 0.7, -0.5, 0, TAU); c.fill();
      return;
    }
    if (back) {                                                                    // seen from behind: all hair
      c.beginPath(); c.ellipse(hx, hy - 0.2, 4.6, 4.7, 0, 0, TAU); fillOut(c, l.style === 6 ? st.capC : l.hair, l.style === 6 ? st.capO : st.hairO);
      if (l.style === 2) { c.beginPath(); c.ellipse(hx, hy + 1.2, 1.9, 3.0, 0, 0, TAU); fillOut(c, l.hair, st.hairO); }
      c.fillStyle = st.hairH; c.beginPath(); c.ellipse(hx - 1.3, hy - 2.8, 1.5, 0.8, -0.4, 0, TAU); c.fill();
      return;
    }
    const fringe = (dx, ry) => { c.fillStyle = l.hair; c.beginPath(); c.ellipse(hx + dx, hy - 2.1, 4.2, ry, 0, 0, TAU); c.fill(); };
    switch (l.style) {
      case 0: dome(l.hair, st.hairO, 4.75, 4.7, -0.15); c.fillStyle = l.hair; c.fillRect(hx - 4.7, hy - 0.4, 1.2, 2.2); c.fillRect(hx + 3.5, hy - 0.4, 1.2, 2.2); fringe(f * 0.9, 1.7); break;
      case 1: dome(l.hair, st.hairO, 4.75, 4.7, -0.15); c.fillStyle = l.hair; c.fillRect(hx - 4.75, hy - 0.4, 1.5, 5.2); c.fillRect(hx + 3.25, hy - 0.4, 1.5, 5.2); fringe(f * 0.8, 1.9); break;
      case 2: dome(l.hair, st.hairO, 4.7, 4.55, -0.2); fringe(f * 0.6, 1.8); break;
      case 3: c.fillStyle = l.hair; c.beginPath(); c.ellipse(hx, hy - 2.7, 4.5, 1.9, 0, 0, TAU); c.fill(); break;
      case 4: dome(st.hairD, st.hairO, 4.5, 3.9, -0.55); break;
      case 5: dome(l.hair, st.hairO, 4.8, 4.75, -0.1); c.fillStyle = l.hair; c.fillRect(hx - 4.8, hy - 0.4, 1.7, 3.8); c.fillRect(hx + 3.1, hy - 0.4, 1.7, 3.8); fringe(f * 0.5, 2.0); break;
      default:                                                                     // baseball cap: crown, brim to the front
        dome(st.capC, st.capO, 4.8, 4.5, -0.45);
        c.beginPath(); c.ellipse(hx + f * 4.2, hy - 0.9, 2.9, 1.0, f * 0.12, 0, TAU); fillOut(c, st.capC, st.capO);
        c.fillStyle = 'rgba(255,255,255,.28)'; c.beginPath(); c.ellipse(hx - 1.4, hy - 3.5, 1.4, 0.7, -0.4, 0, TAU); c.fill();
        c.fillStyle = l.hair; c.fillRect(hx - f * 4.7, hy - 0.5, 1.2, 2.6);
    }
    if (l.style !== 6) { c.fillStyle = st.hairH; c.beginPath(); c.ellipse(hx - 1.5, hy - 3.6, 1.5, 0.7, -0.35, 0, TAU); c.fill(); }   // a shine on the hair
  }

  // one arm: a sleeve to the elbow, skin below it, a round hand. Seated: the hands type on the desk
  const Z = { behind: [false, false] };
  function arm(c, side) {
    const { f, cx, sw, shY, s, cs, moving, seated, o, l, st, ph } = Z;
    const sx = cx + side * (sw - 0.9), sy = shY + 1.5, right = side === 1, raised = right && o.arm;
    let ax, ay;
    if (seated) { const t = Math.sin(ph * 2 + side * 1.7) * 0.75; ax = cx + side * 2.6 + f * 1.4; ay = shY + 9.3 + t; }
    else if (raised) { ax = o.arm[0]; ay = o.arm[1]; }
    else { ax = sx + side * 0.5 - f * side * s * 2.9 * (moving ? 1 : 0); ay = sy + 8.0 - Math.max(0, -side * cs) * (moving ? 1.1 : 0); }
    const ex = (sx + ax) / 2 + (seated ? side * 1.4 : f * 0.8), ey = (sy + ay) / 2 + (seated ? 1.0 : 0.1);
    const dark = !seated && !raised && moving && -side * s < 0, sleeve = dark ? st.clothD : st.cloth, skinC = dark ? st.skinD : l.skin;
    limb(c, [sx, sy, ex, ey], 3.1, sleeve, st.clothO);
    limb(c, [ex, ey, ax, ay], 2.4, skinC, st.skinO);
    c.beginPath(); c.arc(ax, ay, 1.45, 0, TAU); fillOut(c, skinC, st.skinO);
    if (right) { Z.hand[0] = ax; Z.hand[1] = ay; }
  }

  function person(c, px, py, ph, shirt, seated, skin, o) {
    o = o || {};
    const f = o.face < 0 ? -1 : 1, back = !!o.back && !seated;
    const l = lookOf(o.look !== undefined ? o.look : hashOf(shirt), skin), st = styleOf(l, shirt, o);
    const s = Math.sin(ph), cs = Math.cos(ph), moving = !seated && !o.still;
    const bob = moving ? Math.abs(s) * 1.0 : 0, S = seated ? 0.92 : 1, W = l.wide;
    const LEG = 10.2 * l.size, hipY = -LEG - bob, shY = seated ? -15.4 : hipY - 9.2, top = seated ? shY + 8.6 : hipY + 0.9;
    const cx = seated ? f * 0.4 : 0, hx = cx + f * 0.55, hy = shY - 5.1 + (seated ? Math.sin(ph * 2) * 0.12 : 0);
    const hand = [0, 0];
    c.save(); c.translate(px, py); if (S !== 1) c.scale(S, S);
    c.lineCap = 'round'; c.lineJoin = 'round';
    // shadow on the ground
    c.fillStyle = 'rgba(0,0,0,.3)'; c.beginPath(); c.ellipse(0, 0.4, seated ? 6.2 : 5.6, 2.4, 0, 0, TAU); c.fill();
    hairBack(c, l, st, hx, hy, f, ph, o);
    // legs: the one swinging back is darker, which gives the stride its depth
    if (!seated) {
      for (const side of [-1, 1]) {
        const a = side * s, lift = Math.max(0, side * cs) * 2.1, ax = side * 1.9 + f * a * 4.0 * (moving ? 1 : 0), ay = -lift - 1.0;
        const hipX = side * 1.9 * W, kx = (hipX + ax) / 2 + f * (0.7 + Math.abs(ax - hipX) * 0.12), ky = (hipY + ay) / 2 + 0.2;
        const dark = a < 0 && moving;
        limb(c, [hipX, hipY + 1, kx, ky, ax, ay], 3.5, dark ? st.pantsD : l.pants, st.pantsO);
        if (l.shorts) { c.strokeStyle = dark ? sh(l.skin, 0.78) : l.skin; c.lineWidth = 2.6; c.beginPath(); c.moveTo((kx + ax) / 2, (ky + ay) / 2 - 0.4); c.lineTo(ax, ay); c.stroke(); }
        c.beginPath(); c.ellipse(ax + f * 1.0, ay + 0.35, 3.0, 1.55, 0, 0, TAU); fillOut(c, dark ? sh(l.shoe, 0.8) : l.shoe, st.shoeO);
        c.fillStyle = st.sole; c.fillRect(ax - 1.9 + f * 1.0, ay + 1.0, 3.8, 0.55);
      }
    } else {
      rr(c, cx - 4.4, top - 1.4, 8.8, 4.6, 2.0); fillOut(c, l.pants, st.pantsO);
      c.fillStyle = 'rgba(255,255,255,.12)'; c.fillRect(cx - 3.6, top - 0.8, 7.2, 0.8);
    }
    if (l.bag) { rr(c, cx - f * 5.2 - 1.7, shY + 0.8, 3.4, 7.6, 1.4); fillOut(c, '#56607c', '#262c40'); }                    // a backpack on the back
    // what the arms need to know (kept in one object so a frame of thirty people does not allocate)
    Z.f = f; Z.cx = cx; Z.sw = 4.55 * W; Z.shY = shY; Z.s = s; Z.cs = cs; Z.moving = moving; Z.seated = seated; Z.o = o; Z.l = l; Z.st = st; Z.ph = ph; Z.hand = hand;
    for (const side of [-1, 1]) { Z.behind[side + 1] = moving && -side * s < 0 && !(side === 1 && o.arm); if (Z.behind[side + 1]) arm(c, side); }   // the arm swinging back is behind the body
    // torso: broad shoulders, narrower waist; light on the left, shade on the right
    const sw = 4.55 * W, ww = 3.8 * W;
    c.beginPath(); c.moveTo(cx - ww, top); c.lineTo(cx - sw, shY + 2.4);
    c.quadraticCurveTo(cx - sw - 0.15, shY - 0.3, cx - sw + 2.0, shY - 0.3); c.lineTo(cx + sw - 2.0, shY - 0.3);
    c.quadraticCurveTo(cx + sw + 0.15, shY - 0.3, cx + sw, shY + 2.4); c.lineTo(cx + ww, top); c.closePath();
    fillOut(c, st.cloth, st.clothO);
    c.fillStyle = st.clothL; c.beginPath(); c.moveTo(cx - ww + 0.5, top - 0.3); c.lineTo(cx - sw + 0.5, shY + 2.4); c.quadraticCurveTo(cx - sw + 0.4, shY + 0.2, cx - sw + 2.0, shY + 0.1); c.lineTo(cx - sw + 3.3, shY + 0.1); c.lineTo(cx - ww + 2.4, top - 0.3); c.closePath(); c.fill();
    c.fillStyle = st.clothD; c.beginPath(); c.moveTo(cx + ww - 2.0, top - 0.3); c.lineTo(cx + sw - 2.2, shY + 0.1); c.lineTo(cx + sw - 0.4, shY + 2.2); c.lineTo(cx + ww - 0.4, top - 0.3); c.closePath(); c.fill();
    if (!seated) { c.fillStyle = st.pantsO; c.fillRect(cx - ww + 0.2, top - 1.1, ww * 2 - 0.4, 1.1); }                         // belt
    if (o.vest) {                                                                  // hi-vis: two bands round the chest and braces over the shoulders
      c.fillStyle = 'rgba(240,245,255,.92)'; c.fillRect(cx - sw + 0.5, shY + 3.6, sw * 2 - 1, 1.15); c.fillRect(cx - ww + 0.2, shY + 6.6, ww * 2 - 0.4, 1.0);
      c.fillRect(cx - 2.7, shY - 0.1, 1.15, 8.5); c.fillRect(cx + 1.55, shY - 0.1, 1.15, 8.5);
    } else if (o.coat) {                                                           // lab coat: collar and a breast pocket
      c.strokeStyle = st.clothO; c.lineWidth = 0.6; c.beginPath(); c.moveTo(cx, shY + 0.6); c.lineTo(cx, top); c.stroke();
      c.fillStyle = shirt; c.beginPath(); c.moveTo(cx - 1.4, shY - 0.2); c.lineTo(cx, shY + 2.6); c.lineTo(cx + 1.4, shY - 0.2); c.closePath(); c.fill();
      c.strokeStyle = st.clothO; c.strokeRect(cx + 1.4, shY + 3.6, 2.0, 1.8);
    } else if (l.badge) {                                                          // a lanyard and a pass card
      c.strokeStyle = '#3d8bff'; c.lineWidth = 0.75; c.beginPath(); c.moveTo(cx - 1.5, shY - 0.2); c.lineTo(cx, shY + 3.4); c.lineTo(cx + 1.5, shY - 0.2); c.stroke();
      c.fillStyle = '#f5f8ff'; c.fillRect(cx - 1.0, shY + 3.2, 2.0, 2.5); c.fillStyle = '#4dc8ff'; c.fillRect(cx - 1.0, shY + 3.2, 2.0, 0.75);
    }
    for (const side of [-1, 1]) if (!Z.behind[side + 1]) arm(c, side);                // the arm swinging forward is in front of the body
    // head: ear, face, cheeks, eyes, brows, mouth; then the hair, cap or hat over it
    c.beginPath(); c.ellipse(hx - f * 4.0, hy + 0.9, 1.0, 1.3, 0, 0, TAU); fillOut(c, l.skin, st.skinO);
    c.beginPath(); c.ellipse(hx, hy, 4.35, 4.5, 0, 0, TAU); fillOut(c, l.skin, st.skinO);
    c.fillStyle = st.skinD; c.beginPath(); c.ellipse(hx - f * 0.2, hy + 3.3, 3.2, 1.0, 0, 0, Math.PI); c.fill();            // shade under the chin
    if (!back) {
      const e1 = hx + f * 0.35, e2 = hx + f * 2.85, ey2 = hy + 0.65;
      c.fillStyle = st.cheek; c.beginPath(); c.ellipse(hx + f * 3.1, hy + 2.05, 1.0, 0.62, 0, 0, TAU); c.fill();
      c.fillStyle = EYE; c.beginPath(); c.ellipse(e1, ey2, 0.78, 1.1, 0, 0, TAU); c.ellipse(e2, ey2, 0.78, 1.1, 0, 0, TAU); c.fill();
      c.fillStyle = 'rgba(255,255,255,.9)'; c.fillRect(e1 - 0.45, ey2 - 0.7, 0.45, 0.45); c.fillRect(e2 - 0.45, ey2 - 0.7, 0.45, 0.45);
      c.strokeStyle = l.style === 6 || o.hat ? st.hairD : st.hairO; c.lineWidth = 0.5; c.beginPath(); c.moveTo(e1 - 0.8, ey2 - 1.7); c.lineTo(e1 + 0.8, ey2 - 1.85); c.moveTo(e2 - 0.8, ey2 - 1.85); c.lineTo(e2 + 0.8, ey2 - 1.7); c.stroke();
      c.strokeStyle = st.skinO; c.lineWidth = 0.55; c.beginPath(); c.arc(hx + f * 1.7, hy + 1.85, 1.0, 0.2, Math.PI - 0.2); c.stroke();
      if (l.glasses) { c.fillStyle = 'rgba(205,232,255,.3)'; c.beginPath(); c.arc(e1, ey2, 1.4, 0, TAU); c.fill(); c.beginPath(); c.arc(e2, ey2, 1.4, 0, TAU); c.fill(); c.strokeStyle = '#3a4468'; c.lineWidth = 0.5; c.beginPath(); c.arc(e1, ey2, 1.4, 0, TAU); c.moveTo(e2 + 1.4, ey2); c.arc(e2, ey2, 1.4, 0, TAU); c.moveTo(e1 + 1.4, ey2); c.lineTo(e2 - 1.4, ey2); c.stroke(); }
    }
    hairFront(c, l, st, hx, hy, f, o, back);
    if (l.headset && !o.hat && l.style !== 6) {                                    // a headset: band over the head, a cup over the ear, a mic
      c.strokeStyle = '#2b3350'; c.lineWidth = 0.9; c.beginPath(); c.arc(hx, hy - 0.4, 4.9, Math.PI * 1.02, Math.PI * 1.98); c.stroke();
      c.beginPath(); c.ellipse(hx - f * 4.3, hy + 0.9, 1.1, 1.7, 0, 0, TAU); fillOut(c, '#46557e', '#1b2036');
      if (!back) { c.strokeStyle = '#2b3350'; c.lineWidth = 0.6; c.beginPath(); c.moveTo(hx - f * 4.2, hy + 2.4); c.quadraticCurveTo(hx - f * 2.6, hy + 4.4, hx + f * 0.6, hy + 3.7); c.stroke(); }
    }
    c.restore();
    return [px + hand[0] * S, py + hand[1] * S];
  }

  A.person = person;
  A.people = { look: lookOf, skin: (i) => SKINS[(Math.abs(i | 0) * 3 + 1) % SKINS.length], SKINS, HAIRS, PANTS };
})();
