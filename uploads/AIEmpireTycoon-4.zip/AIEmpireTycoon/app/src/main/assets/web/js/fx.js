/* AI Empire Tycoon - screen effects: coins that fly to the cash counter, fireworks, confetti, rings, sparks.
   One transparent canvas lives inside #fx. It only runs while something is alive, so an idle game pays nothing for it.
   Everything here works in screen pixels, so it can be used from any screen (the island converts its own positions first). */
(function () {
  'use strict';
  const G = window.G, U = G.U, A = G.art;
  const F = (G.fx = {});
  const TAU = Math.PI * 2;
  let cv = null, c = null, W = 0, H = 0, dpr = 1, raf = 0, last = 0, coinSpr = null;
  const sparks = [], conf = [], coins = [], shells = [], rings = [], queue = [];
  let lastTick = 0, shakeEl = null;

  // 0 = animation off (Settings), 1 = medium, 2 = high. Effects thin out on slow devices, never disappear completely.
  const level = () => { const q = G.scene ? G.scene.q : 1; return q < 0 ? 0 : q; };
  const cap = () => [90, 220, 420][level()];

  function ensure() {
    if (cv) return true;
    const host = document.getElementById('fx');
    if (!host) return false;
    cv = document.createElement('canvas');
    cv.id = 'fxc';
    cv.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;pointer-events:none';
    host.prepend(cv);
    c = cv.getContext('2d');
    size();
    window.addEventListener('resize', size);
    return true;
  }
  function size() {
    if (!cv) return;
    dpr = Math.min(window.devicePixelRatio || 1, 1.75);
    W = window.innerWidth; H = window.innerHeight;
    cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr);
  }
  function wake() {
    if (!ensure()) return;
    if (!raf) { last = performance.now(); raf = requestAnimationFrame(loop); }
  }
  function idle() { return !sparks.length && !conf.length && !coins.length && !shells.length && !rings.length && !queue.length; }

  /* ---------- sprites ---------- */
  function coinSprite() {
    if (coinSpr) return coinSpr;
    const s = 44, k = document.createElement('canvas'); k.width = k.height = s;
    const g = k.getContext('2d');
    const rg = g.createRadialGradient(s * 0.38, s * 0.34, 2, s / 2, s / 2, s * 0.5);
    rg.addColorStop(0, '#fff3b8'); rg.addColorStop(0.55, '#f6b84a'); rg.addColorStop(1, '#b97a10');
    g.fillStyle = rg; g.beginPath(); g.arc(s / 2, s / 2, s * 0.46, 0, TAU); g.fill();
    g.strokeStyle = 'rgba(255,240,180,.9)'; g.lineWidth = 2; g.stroke();
    g.strokeStyle = 'rgba(150,90,10,.55)'; g.lineWidth = 1.6; g.beginPath(); g.arc(s / 2, s / 2, s * 0.32, 0, TAU); g.stroke();
    g.fillStyle = 'rgba(120,70,0,.8)'; g.font = '700 ' + Math.round(s * 0.44) + 'px system-ui, sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle';
    g.fillText('$', s / 2, s / 2 + 1);
    return (coinSpr = k);
  }

  /* ---------- the cash counter: where the coins go ---------- */
  function cashSpot() {
    const el = document.querySelector('.cashv');
    if (!el) return [W - 60, 30];
    const r = el.getBoundingClientRect();
    return [r.left + r.width * 0.62, r.top + r.height * 0.5];
  }
  function bump() {
    const el = document.querySelector('.cashv');
    if (!el) return;
    el.classList.remove('bump'); void el.offsetWidth; el.classList.add('bump');
  }

  /* ---------- public effects ---------- */
  // n coins leave (x, y) and arc up to the cash counter one after another.
  F.coin = function (x, y, n, big) {
    if (!ensure()) return;
    n = Math.max(1, Math.min(n || 1, level() === 0 ? 2 : 8));
    const to = cashSpot();
    for (let i = 0; i < n; i++) {
      const dur = 0.85 + Math.random() * 0.35 + i * 0.03;
      const ang = -Math.PI / 2 + (Math.random() - 0.5) * 2.2, d = 30 + Math.random() * 40;
      coins.push({ x0: x, y0: y, cx: x + Math.cos(ang) * d, cy: y + Math.sin(ang) * d - 30, x1: to[0], y1: to[1], t: -i * 0.07, dur, sp: Math.random() * TAU, size: big ? 17 : 13 });
    }
    wake();
  };
  F.burst = function (x, y, color, n, o) {
    if (!ensure()) return;
    o = o || {};
    n = Math.round((n || 20) * [0.35, 0.7, 1][level()]);
    for (let i = 0; i < n && sparks.length < cap(); i++) {
      const a = o.arc ? o.arc[0] + Math.random() * (o.arc[1] - o.arc[0]) : Math.random() * TAU, v = (o.speed || 120) * (0.35 + Math.random() * 0.75);
      sparks.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, g: o.g === undefined ? 90 : o.g, drag: o.drag || 1.6, t: 0, ttl: (o.ttl || 0.9) * (0.7 + Math.random() * 0.6), s: (o.size || 9) * (0.6 + Math.random() * 0.7), col: Array.isArray(color) ? color[i % color.length] : color });
    }
    wake();
  };
  F.ring = function (x, y, color, r1, dur) {
    if (!ensure()) return;
    rings.push({ x, y, r0: 4, r1: r1 || 60, t: 0, dur: dur || 0.8, col: color || '#8af0e6' });
    wake();
  };
  // paper confetti falling from the top (x = null) or thrown from a point
  F.confetti = function (n, x, y) {
    if (!ensure()) return;
    n = Math.round((n || 60) * [0.3, 0.6, 1][level()]);
    const cols = ['#3dd6c6', '#f6b84a', '#8b7cf6', '#ff7fa3', '#6bb8ff', '#ffffff'];
    for (let i = 0; i < n && conf.length < cap(); i++) {
      const fromTop = x === undefined || x === null;
      const a = -Math.PI / 2 + (Math.random() - 0.5) * 1.6, v = 160 + Math.random() * 260;
      conf.push({ x: fromTop ? Math.random() * W : x, y: fromTop ? -10 - Math.random() * 120 : y, vx: fromTop ? (Math.random() - 0.5) * 60 : Math.cos(a) * v, vy: fromTop ? 60 + Math.random() * 90 : Math.sin(a) * v, r: Math.random() * TAU, vr: (Math.random() - 0.5) * 12, w: 5 + Math.random() * 5, h: 3 + Math.random() * 4, col: cols[i % cols.length], t: 0, ttl: 3.2 + Math.random() * 1.6, ph: Math.random() * TAU });
    }
    wake();
  };
  // one firework: a shell climbs from the bottom of the screen and bursts at (x, y)
  F.firework = function (x, y, colors) {
    if (!ensure()) return;
    const cols = colors || U.pick([['#ffd27a', '#fff3c4'], ['#8af0e6', '#3dd6c6'], ['#b9aeff', '#8b7cf6'], ['#ff9fbf', '#ff7fa3'], ['#9be7ff', '#5b9bf2']]);
    shells.push({ x: x + (Math.random() - 0.5) * 60, y: H + 10, tx: x, ty: y, t: 0, dur: 0.75 + Math.random() * 0.3, cols });
    wake();
  };
  // a show of n shells spread over `secs` seconds, aimed at the upper part of the screen
  F.show = function (n, secs) {
    if (!ensure()) return;
    n = Math.max(1, Math.round(n * [0.4, 0.7, 1][level()]));
    secs = secs || 3;
    for (let i = 0; i < n; i++) queue.push({ at: (i / n) * secs + Math.random() * 0.25, fn: () => F.firework(W * (0.14 + Math.random() * 0.72), H * (0.12 + Math.random() * 0.3)) });
    wake();
  };
  F.shake = function (ms) {
    const el = document.getElementById('app');
    if (!el || level() === 0) return;
    el.classList.remove('shake'); void el.offsetWidth; el.classList.add('shake');
    clearTimeout(shakeEl); shakeEl = setTimeout(() => el.classList.remove('shake'), ms || 380);
  };
  F.clear = function () { sparks.length = conf.length = coins.length = shells.length = rings.length = queue.length = 0; };

  /* ---------- simulation and drawing ---------- */
  function pop(x, y, cols) {
    const n = [26, 44, 64][level()];
    const big = Math.random() < 0.3;
    for (let i = 0; i < n && sparks.length < cap(); i++) {
      const a = (i / n) * TAU + Math.random() * 0.2, v = (big ? 150 : 115) * (0.55 + Math.random() * 0.55);
      sparks.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, g: 70, drag: 1.7, t: 0, ttl: 1.1 + Math.random() * 0.8, s: 10 + Math.random() * 5, col: cols[i % cols.length], trail: true });
    }
    rings.push({ x, y, r0: 6, r1: 38, t: 0, dur: 0.45, col: cols[0] });
    try { G.audio.sfx('firework'); } catch (e) { /* ignore */ }
  }
  function loop(now) {
    raf = 0;
    if (!cv) return;
    const dt = Math.max(0, Math.min(0.05, (now - last) / 1000)); last = now;   // never negative: a frame stamp can be older than the time wake() noted
    if (document.hidden) { raf = requestAnimationFrame(loop); return; }
    c.setTransform(dpr, 0, 0, dpr, 0, 0);
    c.clearRect(0, 0, W, H);
    // scheduled effects
    for (let i = queue.length - 1; i >= 0; i--) { queue[i].at -= dt; if (queue[i].at <= 0) { const q = queue.splice(i, 1)[0]; try { q.fn(); } catch (e) { if (G.err) G.err(e); } } }
    // coins: a curve from the start through a bounce point to the counter
    if (coins.length) {
      const spr = coinSprite();
      for (let i = coins.length - 1; i >= 0; i--) {
        const k = coins[i];
        k.t += dt;
        if (k.t < 0) continue;
        const p = Math.min(1, k.t / k.dur), e = p * p * (3 - 2 * p), u = 1 - e;
        const x = u * u * k.x0 + 2 * u * e * k.cx + e * e * k.x1, y = u * u * k.y0 + 2 * u * e * k.cy + e * e * k.y1;
        const flip = Math.abs(Math.cos(k.sp + k.t * 11)), sz = k.size * (1 - 0.35 * p);
        c.globalAlpha = Math.min(1, k.t * 8);
        c.drawImage(spr, x - sz * flip / 2, y - sz / 2, sz * flip, sz);
        if (level() > 0 && Math.random() < 0.35 && sparks.length < cap()) sparks.push({ x, y, vx: (Math.random() - 0.5) * 30, vy: (Math.random() - 0.5) * 30, g: 0, drag: 2, t: 0, ttl: 0.35, s: 6, col: '#ffd27a' });
        if (p >= 1) {
          coins.splice(i, 1);
          bump();
          if (performance.now() - lastTick > 90) { lastTick = performance.now(); try { G.audio.sfx('tick'); } catch (e) { /* ignore */ } }
          if (level() > 0) F.burst(k.x1, k.y1, '#ffd27a', 4, { speed: 50, size: 7, ttl: 0.4, g: 0 });
        }
      }
      c.globalAlpha = 1;
    }
    // shells
    for (let i = shells.length - 1; i >= 0; i--) {
      const s = shells[i];
      s.t += dt;
      const p = Math.min(1, s.t / s.dur), e = 1 - (1 - p) * (1 - p);
      const x = U.lerp(s.x, s.tx, e), y = U.lerp(s.y, s.ty, e);
      if (level() > 0 && sparks.length < cap()) sparks.push({ x, y, vx: (Math.random() - 0.5) * 20, vy: 20 + Math.random() * 30, g: 0, drag: 2.5, t: 0, ttl: 0.45, s: 7, col: '#ffe9a8' });
      if (p >= 1) { shells.splice(i, 1); pop(s.tx, s.ty, s.cols); }
    }
    // sparks, glowing and additive
    c.globalCompositeOperation = 'lighter';
    for (let i = sparks.length - 1; i >= 0; i--) {
      const s = sparks[i];
      s.t += dt;
      if (s.t >= s.ttl) { sparks.splice(i, 1); continue; }
      const dr = Math.exp(-s.drag * dt);
      s.vx *= dr; s.vy = s.vy * dr + s.g * dt;
      s.x += s.vx * dt; s.y += s.vy * dt;
      const k = 1 - s.t / s.ttl, sz = s.s * (0.55 + 0.6 * k);
      c.globalAlpha = Math.min(1, k * 1.5);
      c.drawImage(A.glow(s.col), s.x - sz, s.y - sz, sz * 2, sz * 2);
    }
    // rings
    for (let i = rings.length - 1; i >= 0; i--) {
      const r = rings[i];
      r.t += dt;
      const p = r.t / r.dur;
      if (p >= 1) { rings.splice(i, 1); continue; }
      c.globalAlpha = (1 - p) * 0.9; c.strokeStyle = r.col; c.lineWidth = 2.4 * (1 - p) + 0.6;
      c.beginPath(); c.arc(r.x, r.y, Math.max(0, U.lerp(r.r0, r.r1, 1 - (1 - p) * (1 - p))), 0, TAU); c.stroke();
    }
    c.globalCompositeOperation = 'source-over';
    // confetti
    for (let i = conf.length - 1; i >= 0; i--) {
      const f = conf[i];
      f.t += dt;
      if (f.t >= f.ttl || f.y > H + 20) { conf.splice(i, 1); continue; }
      f.vy += 140 * dt; f.vx *= Math.exp(-0.9 * dt); f.vy *= Math.exp(-0.7 * dt);
      f.x += (f.vx + Math.sin(f.t * 3 + f.ph) * 26) * dt; f.y += f.vy * dt; f.r += f.vr * dt;
      c.globalAlpha = Math.min(1, (f.ttl - f.t) * 1.5);
      c.save(); c.translate(f.x, f.y); c.rotate(f.r); c.scale(1, Math.abs(Math.cos(f.t * 6 + f.ph)) * 0.8 + 0.2);
      c.fillStyle = f.col; c.fillRect(-f.w / 2, -f.h / 2, f.w, f.h); c.restore();
    }
    c.globalAlpha = 1;
    if (idle()) { c.clearRect(0, 0, W, H); return; }
    raf = requestAnimationFrame(loop);
  }
})();
