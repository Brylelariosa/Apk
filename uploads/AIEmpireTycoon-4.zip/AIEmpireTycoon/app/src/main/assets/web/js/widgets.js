/* AI Empire Tycoon - shared interface widgets.
   Small reusable pieces used by more than one screen: upgrade pictures, "what will this do to my money" chips, comparison
   tables, health meters and the income-coach card. Screens (upgrades.js, money.js, ui.js) build on these instead of
   repeating markup. */
(function () {
  'use strict';
  const G = window.G, D = G.D, U = G.U, UI = G.ui, ADV = G.adv, HW = G.art.hw, h = U.h;
  const I = UI.I, T = UI.T, CL = UI.CL, ST = UI.ST, DIS = UI.DIS, bind = UI.bind, btn = UI.btn;
  const W = (UI.w = {});

  /* ---------- tiny helpers ---------- */
  // Amounts smaller than this (per second) are treated as "no change" so the screen is not full of $0.0001.
  W.eps = () => Math.max(2e-5, 0.004 * Math.max(0.05, G.C ? G.C.rev.total : 0));
  W.pct = (v, d) => (v * 100).toFixed(d || 0) + '%';
  // "+$0.31/s" with the sign always shown; cost = true flips the colour (a cost that rises is bad news)
  W.sgn = (v) => (Math.abs(v) < W.eps() ? '$0' : (v < 0 ? '−' : '+') + U.fine(Math.abs(v)));
  W.tone = (v, cost) => (Math.abs(v) < W.eps() ? 'zero' : (v > 0) !== !!cost ? 'pos' : 'neg');

  /* ---------- pictures ---------- */
  // The drawing of an upgrade (made by art-hw.js from the same art the campus uses). Locked upgrades are dimmed.
  W.pic = function (kind, lv, w, ht, o) {
    const cv = document.createElement('canvas');
    cv.className = 'upc';
    HW.paint(cv, kind, lv, Object.assign({ w, h: ht }, o || {}));
    return h('div', { class: 'upic' + (o && o.dim ? ' dim' : ''), style: { width: w + 'px', height: ht + 'px' } }, cv);
  };

  /* ---------- income / cost chips ---------- */
  // imp = result of ADV.impact(): { inc, exp, net, soonInc, soonNet }. Shows what changes per second if the player does it.
  W.impact = function (imp, o) {
    o = o || {};
    const e = W.eps(), none = Math.abs(imp.inc) < e && Math.abs(imp.exp) < e && Math.abs(imp.net) < e;
    const box = h('div', { class: 'impact' });
    if (none) {
      box.append(h('div', { class: 'imp0' }, I('info', 14), h('span', {}, o.none || 'No change to your income or costs.')));
    } else {
      const chip = (label, v, cost) => h('div', { class: 'imp ' + W.tone(v, cost) }, h('span', { class: 'il' }, label), h('b', {}, W.sgn(v) + (Math.abs(v) < e ? '' : '/s')));
      box.append(h('div', { class: 'imps' }, chip('Income', imp.inc, false), chip('Costs', imp.exp, true), chip('Profit', imp.net, false)));
      if (o.note) box.append(h('div', { class: 'xs dimt' }, o.note));
    }
    // growth that arrives later, once more users have joined
    const lateInc = imp.soonInc - imp.inc, lateNet = imp.soonNet - imp.net;
    if (!o.noLater && (lateInc > Math.max(e * 4, Math.abs(imp.inc) * 0.25) || lateNet > Math.max(e * 4, Math.abs(imp.net) * 0.25))) {
      box.append(h('div', { class: 'xs acc' }, 'Once more users join: income ' + W.sgn(imp.soonInc) + '/s, profit ' + W.sgn(imp.soonNet) + '/s.'));
    }
    return box;
  };

  // The same box, but it keeps itself current: whenever the advisor refreshes (every couple of seconds) it asks again and
  // redraws only if the numbers moved. get() -> ADV.impact(...); o = options, or a function (imp) => options.
  W.liveImpact = function (get, o) {
    const box = h('div', { class: 'imbox' });
    bind(box, () => {
      const x = ADV.ctx();
      if (box._x === x) return;
      box._x = x;
      const imp = get(), sig = [imp.inc, imp.exp, imp.net, imp.soonInc, imp.soonNet].map((v) => v.toPrecision(3)).join('|');
      if (box._sig === sig) return;
      box._sig = sig;
      box.textContent = '';
      box.append(W.impact(imp, typeof o === 'function' ? o(imp) : o));
    });
    return box;
  };

  // One line that says what a change does to income and costs: "+$0.35/s income · +$0.04/s costs". Call .set(imp) as often as
  // you like; it only touches the page when the words change. o.none = text when nothing changes, o.noIncome = text put in front
  // of the costs when income does not move (so the line never reads as good news by itself).
  W.gainLine = function (o) {
    o = o || {};
    const el = h('div', { class: 'gline' });
    el.set = (imp) => {
      const e = W.eps(), parts = [];
      const inc = Math.abs(imp.inc) >= e, exp = Math.abs(imp.exp) >= e;
      if (!inc && exp && o.noIncome) parts.push([o.noIncome, 'zero']);
      if (inc) parts.push([W.sgn(imp.inc) + '/s income', W.tone(imp.inc, false)]);
      if (exp) parts.push([W.sgn(imp.exp) + '/s costs', W.tone(imp.exp, true)]);
      if (!parts.length) parts.push([o.none || 'No change to income or costs', 'zero']);
      const sig = parts.map((p) => p.join('~')).join('|');
      if (el._k === sig) return el;
      el._k = sig; el.textContent = '';
      parts.forEach((p, i) => { if (i) el.append(' · '); el.append(h('span', { class: p[1] === 'zero' ? 'mut' : p[1] }, p[0])); });
      return el;
    };
    return el;
  };

  // "income +$0.31/s, costs +$0.02/s" for a ledger entry ({ dr, de }); amounts too small to matter are left out.
  W.ledgerParts = function (e) {
    const out = [];
    if (Math.abs(e.dr) >= 1e-4) out.push('income ' + U.delta(e.dr));
    if (Math.abs(e.de) >= 1e-4) out.push('costs ' + U.delta(e.de));
    return out.join(', ');
  };

  /* ---------- comparison table ---------- */
  // rows: [label, nowText, nextText]; shows "now → after" so the player sees exactly what improves
  W.compare = function (rows) {
    if (!rows || !rows.length) return null;
    return h('div', { class: 'cmp' }, rows.map((r) => h('div', { class: 'cmpr' }, h('span', { class: 'cl' }, r[0]), h('span', { class: 'cv' }, h('span', { class: 'mut' }, String(r[1])), I('chev', 11), h('b', { class: 'acc' }, String(r[2]))))));
  };

  /* ---------- health tile (a number, a bar and a colour) ---------- */
  // get() -> { f: 0..1+, text, tone?: 'good'|'warn'|'bad' }
  W.tile = function (label, icon, get, onTap) {
    const b = UI.bar('thin'), v = h('div', { class: 'hv' });
    const el = h(onTap ? 'button' : 'div', { class: 'ht2', type: onTap ? 'button' : null, 'aria-label': label }, h('div', { class: 'hl2' }, I(icon, 12), label), v, b);
    if (onTap) el.addEventListener('click', () => { G.audio.init(); G.audio.sfx('tap'); onTap(); });
    bind(el, () => {
      const r = get();
      T(v, r.text); UI.setBar(b, Math.min(1, r.f));
      const tone = r.tone || (r.f > 1 ? 'bad' : r.f > 0.8 ? 'warn' : 'good');
      CL(b, 'bad', tone === 'bad'); CL(b, 'gold', tone === 'warn'); CL(b, 'good', tone === 'good');
      CL(el, 'tbad', tone === 'bad'); CL(el, 'twarn', tone === 'warn');
    });
    return el;
  };

  /* ---------- rows that open ---------- */
  // A card made of a head that is always visible and a body that opens when the head is tapped. Taps on buttons inside the head
  // do their own job. key keeps the state through a rebuild of the screen (UI.st.open); o.open is the state the first time.
  // Put W.caret() in the head where the arrow should show.
  W.caret = () => h('span', { class: 'cfc' }, I('chev', 13));
  W.fold = function (key, head, body, o) {
    o = o || {};
    const open = UI.st.open || (UI.st.open = {});
    const el = h('div', { class: 'card cfold' + (o.cls ? ' ' + o.cls : '') });
    const hd = h('div', { class: 'cfh', role: 'button', tabindex: '0', 'aria-expanded': 'false' }, head);
    const set = (on) => { open[key] = !!on; el.classList.toggle('open', !!on); hd.setAttribute('aria-expanded', on ? 'true' : 'false'); };
    const flip = () => { G.audio.init(); G.audio.sfx('tap'); set(!el.classList.contains('open')); };
    hd.addEventListener('click', (e) => { if (!e.target.closest('button, a, input')) flip(); });
    hd.addEventListener('keydown', (e) => { if ((e.key === 'Enter' || e.key === ' ') && e.target === hd) { e.preventDefault(); flip(); } });
    el.append(hd, h('div', { class: 'cfb' }, body));
    set(key in open ? open[key] : o.open);
    return el;
  };

  /* ---------- navigation ---------- */
  // Send the player to where a suggestion or hint points: { tab, cat, seg, region }.
  UI.follow = function (go, soft) {
    if (!go) return;
    if (typeof go === 'string') go = { tab: go };
    const tab = go.tab === 'infra' ? 'upgrades' : go.tab;
    if (tab === 'upgrades' && go.cat) UI.st.upCat = go.cat;
    if (tab === 'business') UI.st.bizSeg = go.seg || UI.st.bizSeg;
    if (tab === 'global' && go.region) UI.st.region = go.region;
    UI.go(tab, soft);
  };

  // A button that explains itself: when it is disabled, a line below says exactly why (and offers a shortcut when there is one).
  // getWhy() -> null (go ahead) or { t: 'text', go: tab | { tab, cat }, label: 'button text' }.
  // The two halves of it, for layouts that put the button and the reason in different places: { b: button, row: the reason }.
  UI.actionParts = function (label, icon, cls, getWhy, run) {
    const b = btn(label, { cls, icon, onclick: run });
    const whyT = h('div', { class: 'xs warn grow' });
    const whyB = btn('', { cls: 'sm ghost', onclick: () => UI.follow(whyB._go) });
    const row = h('div', { class: 'row why', hidden: true }, I('warn', 14), whyT, whyB);
    bind(row, () => {
      const w = getWhy();
      DIS(b, !!w);
      row.hidden = !w;
      if (w) { T(whyT, w.t); whyB.hidden = !w.go; if (w.go) { whyB._go = w.go; T(whyB._l, w.label); } }
    });
    return { b, row };
  };
  UI.actionBlock = function (label, icon, cls, getWhy, run) {
    const p = UI.actionParts(label, icon, cls + ' blk', getWhy, run);
    return h('div', { class: 'col gap8' }, p.b, p.row);
  };

  /* ---------- an income-coach suggestion ---------- */
  // t = suggestion from ADV.coach(): { icon, title, why, cost, now, soon, blocked, run, btn, go, goReq, payback ... }
  W.coachCard = function (t, o) {
    o = o || {};
    const card = h('div', { class: 'card coach' + (o.hot ? ' hl' : '') });
    card.append(h('div', { class: 'row' }, h('div', { class: 'ico' }, I(t.icon || 'trend', 18)), h('div', { class: 'grow' }, h('div', { class: 'h3' }, t.title)), t.cost > 0 ? h('div', { class: 'tr' }, h('div', { class: 'micro' }, 'Price'), h('b', { class: 'gold' }, U.money(t.cost))) : h('span', { class: 'badge good' }, 'FREE')));
    card.append(h('div', { class: 'sm mut' }, t.why));
    const gainNow = t.now.net, gainSoon = t.soon.net, e = W.eps();
    if (t.unlocks && !(gainNow > e) && !(gainSoon > e)) {
      card.append(h('div', { class: 'impact' }, h('div', { class: 'imp0' }, I('info', 14), h('span', {}, 'Earns nothing by itself, but it lets you add servers worth up to ' + U.fine(t.unlocks) + '/s.'))));
    } else {
      card.append(W.impact({ inc: t.now.rev, exp: t.now.exp, net: t.now.net, soonInc: t.soon.rev, soonNet: t.soon.net }, { none: 'No change right away.' }));
      if (t.now.net < -e && gainSoon > e) card.append(h('div', { class: 'xs warn' }, 'Profit dips at first, then grows as users arrive.'));
    }
    const pay = t.payback > 0 && t.payback < 7200 ? 'Pays for itself in about ' + U.dur(t.payback) + '.' : '';
    if (pay) card.append(h('div', { class: 'xs good' }, pay));
    const row = h('div', { class: 'row', style: { marginTop: '2px' } });
    const label = t.btn + (t.cost > 0 && t.btn !== 'Open' ? ' · ' + U.money(t.cost) : '');
    const run = btn2(label, 'pri grow', () => { const r = UI.act(() => t.run(), 'buy'); if (r && r.ok) { ADV.dirty(); if (o.onDone) o.onDone(t, r); } });
    bind(run, () => { const s = G.state; UI.DIS(run, !!t.blocked || s.cash < t.cost); });
    row.append(run);
    if (t.go) row.append(btn2('Show me', 'ghost', () => UI.follow(t.go)));
    card.append(row);
    const why = h('div', { class: 'xs warn', hidden: true });
    bind(why, () => {
      const s = G.state, msg = t.blocked ? t.blocked + '.' : s.cash < t.cost ? 'You need ' + U.money(t.cost - s.cash) + ' more cash.' : '';
      why.hidden = !msg; T(why, msg);
    });
    card.append(why);
    if (t.blocked && t.goReq) card.append(btn2('Open Research', 'sm ghost', () => UI.follow(t.goReq)));
    return card;
  };
  // The short version of a suggestion, for a banner that must not push the list off the screen: what to do, what it does to your
  // income and costs, and one button. The reason opens from the (i) and stays open when the screen refreshes. The banner keeps its
  // own numbers current (the advisor moves every couple of seconds), so a screen only has to rebuild it when the suggestion
  // itself changes. t0 = suggestion from ADV.coach(); o.here = the list the banner sits on (hides "Show me" when you are already there).
  W.alertBar = function (t0, o) {
    o = o || {};
    const live = () => ADV.coach().find((x) => x.id === t0.id) || t0;
    const mem = () => UI.st.open || (UI.st.open = {}), wk = 'why:' + t0.id;
    const whyT = h('div', {}), later = h('div', { class: 'acc', hidden: true });
    const why = h('div', { class: 'abwhy xs mut', hidden: !mem()[wk] }, whyT, later);
    if (t0.go && o.here !== (t0.go.cat || t0.go.tab)) why.append(btn('Show me', { cls: 'sm ghost', onclick: () => UI.follow(live().go || t0.go) }));
    const tog = h('button', { class: 'abi' + (mem()[wk] ? ' on' : ''), type: 'button', 'aria-label': 'Why is this a problem?', 'aria-expanded': mem()[wk] ? 'true' : 'false' }, I('info', 15));
    tog.addEventListener('click', () => {
      const on = why.hidden; why.hidden = !on; mem()[wk] = on;
      tog.classList.toggle('on', on); tog.setAttribute('aria-expanded', on ? 'true' : 'false');
    });
    const gain = W.gainLine({ none: 'No change to income right away' }), lock = h('div', { class: 'gline mut', hidden: true });
    const note = h('div', { class: 'xs warn', hidden: true });
    const run = btn(t0.btn, { cls: 'two pri', onclick: () => { const r = UI.act(() => live().run(), 'buy'); if (r && r.ok) ADV.dirty(); } });
    const sub = h('span', { class: 'sub' }); run._l.after(sub);
    // a fix that is locked behind research sends you there instead
    const req = btn('Research', { cls: 'two ghost', onclick: () => UI.follow(live().goReq || t0.goReq) });
    const card = h('div', { class: 'card alertbar' },
      h('div', { class: 'chead top' }, h('div', { class: 'ico bad' }, I('warn', 18)),
        h('div', { class: 'cmain' }, h('div', { class: 'row between' }, h('div', { class: 'micro neg' }, 'Holding your income back'), tog), h('div', { class: 'cname' }, t0.title), gain, lock, note),
        h('div', { class: 'cact' }, run, req)),
      why);
    bind(card, () => {
      const t = live(), s = G.state, e = W.eps();
      const lockOnly = !!t.unlocks && !(t.now.net > e) && !(t.soon.net > e);
      gain.hidden = lockOnly; lock.hidden = !lockOnly;
      if (lockOnly) T(lock, 'Lets you add servers worth up to ' + U.fine(t.unlocks) + '/s'); else gain.set({ inc: t.now.rev, exp: t.now.exp });
      T(whyT, t.why);
      const lateShow = t.soon.rev - t.now.rev > Math.max(e * 4, Math.abs(t.now.rev) * 0.25);
      later.hidden = !lateShow;
      if (lateShow) T(later, 'Once more users join: income ' + W.sgn(t.soon.rev) + '/s, profit ' + W.sgn(t.soon.net) + '/s.');
      const needReq = !!(t.blocked && t.goReq);
      run.hidden = needReq; req.hidden = !needReq;
      T(run._l, t.btn); T(sub, t.cost > 0 ? U.money(t.cost) : 'Free');
      const msg = t.blocked ? t.blocked + '.' : s.cash < t.cost ? 'You need ' + U.money(t.cost - s.cash) + ' more cash.' : '';
      note.hidden = !msg; T(note, msg);
      DIS(run, !!t.blocked || s.cash < t.cost);
    });
    return card;
  };
  function btn2(label, cls, fn) { return btn(label, { cls, onclick: fn }); }
  W.btn = btn2;
})();
