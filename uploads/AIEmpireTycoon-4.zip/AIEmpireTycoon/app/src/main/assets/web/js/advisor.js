/* AI Empire Tycoon - economy advisor (no DOM access in this file).
   It answers the three questions a player keeps asking:
     1. "What happens to my money if I buy this?"      -> adv.what(), adv.impact()
     2. "How do I earn more?"                          -> adv.coach(), adv.capacity(), adv.topTip()
     3. "Why are my costs what they are / why did they rise?" -> adv.costs(), adv.trend() (and the ledger in game.js)
   Everything is computed by running the real economy (G.calcFor) on a modified copy of the state, so the advice can
   never disagree with what the game actually does. */
(function () {
  'use strict';
  const G = window.G, D = G.D, U = G.U, K = G.K;
  const adv = (G.adv = {});
  const assign = (s, ...patches) => Object.assign({}, s, ...patches);

  /* ---------- state patches: tiny helpers that return a modified copy ---------- */
  const P = {
    inf: (s, o, extraValue) => ({ inf: assign(s.inf, o), infraValue: s.infraValue + (extraValue || 0) }),
    done: (s, id) => ({ res: assign(s.res, { done: assign(s.res.done, { [id]: 1 }) }) }),
    model: (s, id, o) => ({ models: assign(s.models, { [id]: assign(s.models[id] || {}, o) }) }),
    hw: (s, k, n, cost) => P.inf(s, { [k]: (s.inf[k] || 0) + n }, cost)
  };
  adv.patch = P;

  /* ---------- what-if engine ---------- */
  // Where the company settles once users and satisfaction have caught up with the current setup.
  adv.steady = function (s) {
    let C = G.calcFor(s);
    for (let i = 0; i < 4; i++) C = G.calcFor(assign(s, { users: C.pot, sat: C.satT }));
    return C;
  };
  const diff = (b, a) => ({ rev: a.rev.total - b.rev.total, exp: a.exp.total - b.exp.total, net: a.net - b.net, sr: a.sr - b.sr, pot: a.pot - b.pot });

  // A complete copy of the state, nested objects included. The game keeps changing those while it runs (rival companies,
  // regions, contracts, models), so a copy that shared them would drift between the "before" and the "after" of a what-if
  // and the drift would show up as if the player's change had caused it. The state is small, so this takes microseconds.
  const frozen = (v) => {
    if (!v || typeof v !== 'object') return v;
    if (Array.isArray(v)) { const a = new Array(v.length); for (let i = 0; i < v.length; i++) a[i] = frozen(v[i]); return a; }
    const o = {};
    for (const k in v) o[k] = frozen(v[k]);
    return o;
  };

  // A context holds the "before" numbers once, so a whole batch of what-ifs shares them. It is refreshed every couple of
  // seconds and whenever the player does something. It works on a frozen copy of the state: users, satisfaction, cash and
  // the rivals keep moving while the game runs, and a "before" and "after" taken a moment apart would show that drift as if
  // the change itself had caused it.
  let ctx = null, dirty = true;
  adv.dirty = () => { dirty = true; };
  function context() {
    const live = G.state, now = Date.now();
    if (ctx && !dirty && ctx.live === live && now - ctx.t < 2500) return ctx;
    dirty = false;
    const s = frozen(live);
    ctx = { live, s, t: now, b0: G.calcFor(s), b1: null, coach: null, memo: {} };
    ctx.what = (patch) => {
      const next = typeof patch === 'function' ? patch(s) : assign(s, patch);
      if (!ctx.b1) ctx.b1 = adv.steady(s);
      const a0 = G.calcFor(next);
      return { now: diff(ctx.b0, a0), soon: diff(ctx.b1, adv.steady(next)), after: a0 };
    };
    // cheaper variant that only looks at the situation right now (users and satisfaction unchanged)
    ctx.quick = (patch) => {
      const next = typeof patch === 'function' ? patch(s) : assign(s, patch);
      const a0 = G.calcFor(next);
      return { now: diff(ctx.b0, a0), after: a0 };
    };
    return ctx;
  }
  adv.ctx = context;
  adv.what = (patch) => context().what(patch);
  // Memoise something expensive for as long as the current context lives (a few seconds). Cards use this so that a screen
  // that refreshes twice a second does not run the economy again for every number on it.
  adv.cached = (key, fn) => { const x = context(); return key in x.memo ? x.memo[key] : (x.memo[key] = fn(x)); };
  // Plain income / cost effect of a change, for upgrade cards.
  adv.impact = function (patch) {
    const w = context().what(patch);
    return { inc: w.now.rev, exp: w.now.exp, net: w.now.net, soonInc: w.soon.rev, soonNet: w.soon.net, w };
  };
  G.on('purchase', adv.dirty);
  G.on('build_done', adv.dirty);
  G.on('research_done', adv.dirty);
  G.on('release', adv.dirty);

  /* ======================= income coach ======================= */
  const plural = (name, n) => (n > 1 ? name + 's' : name);

  // 1) Bottlenecks: anything that stops your servers from earning what they could (heat, power, or simply too few servers).
  // Returns the problems that apply right now, worst first. Each one is a ready-to-run suggestion.
  function bottlenecks(x) {
    const s = x.s, C = x.b0, out = [];
    const needs = (nx) => (nx.req && !s.res.done[nx.req] ? 'Research ' + D.rmap[nx.req].name + ' first' : null);
    // upgrading a building (cooling, power, data center) is the same shape every time
    const ladder = (k, sev, title, why, patch) => {
      const nx = G.ladderNext(k);
      if (!nx || G.building(k)) return;
      const cost = G.ladderCost(nx), blocked = needs(nx), w = x.what((st) => assign(st, P.inf(st, patch(st), cost)));
      out.push({ id: 'cap-' + k, icon: 'cpu', sev, title: title(nx), cost, blocked, why: why(nx), now: w.now, soon: w.soon, enabler: true,
        run: () => G.act.build(k), btn: 'Build', go: { tab: 'upgrades', cat: k }, goReq: blocked ? { tab: 'research' } : null });
    };
    if (C.rel < 0.97) {
      const heat = Math.round((C.heat / Math.max(1e-9, C.coolCap)) * 100);
      ladder('cool', 1 - C.rel, (nx) => 'Upgrade cooling to ' + nx.name,
        () => 'Your servers produce ' + heat + '% of the heat your cooling can remove, so they slow down and customers get unhappy. Better cooling fixes both.',
        (st) => ({ cool: st.inf.cool + 1 }));
    }
    if (C.powerRatio < 0.97) {
      ladder('pwr', 1 - C.powerRatio, (nx) => 'Upgrade power to ' + nx.name,
        () => 'Your servers want ' + U.mw(C.powerDraw) + ' but your power supply only gives ' + U.mw(C.powerCap) + ', so they run slower than they should.',
        (st) => ({ pwr: st.inf.pwr + 1 }));
    }
    if (C.sr < 0.985 && C.demand > 0) {
      const lost = Math.round((1 - C.sr) * 100), potential = C.rev.total * (1 / Math.max(0.05, C.sr) - 1);
      const room = C.slotsTotal - C.slotsUsed, rackRoom = C.rackCap - s.inf.racks, deficit = Math.max(0, C.demand - C.capAvail);
      let item = null;
      if (room > 0) {
        // which server gives the most extra income per dollar? Only purchases that really earn count (a pile of small servers can
        // overload the power supply and lose money), and one the player can pay for now comes first. Without enough cash the
        // size of the purchase shrinks to what the player can afford, so the suggestion never vanishes just because money is tight.
        let best = null;
        for (const h of D.hw) {
          if (!G.hwUnlocked(h.k)) continue;
          const one = x.quick((st) => assign(st, P.hw(st, h.k, 1, G.hwCost(h.k, 1))));
          const perUnit = one.after.capAvail - C.capAvail;
          if (!(perUnit > 0)) continue;
          let n = Math.max(1, Math.min(room, 12, Math.ceil(deficit / perUnit)));
          while (n > 1 && G.hwCost(h.k, n) > s.cash) n--;
          const cost = G.hwCost(h.k, n);
          const w = n === 1 ? one : x.quick((st) => assign(st, P.hw(st, h.k, n, cost)));
          if (!(w.now.net > 0)) continue;
          const cand = { h, n, cost, w, ratio: w.now.net / Math.max(1, cost), afford: s.cash >= cost };
          if (!best || (cand.afford && !best.afford) || (cand.afford === best.afford && cand.ratio > best.ratio)) best = cand;
        }
        if (best) {
          const k = best.h.k, n = best.n, ww = x.what((st) => assign(st, P.hw(st, k, n, best.cost)));
          const back = (best.w.after.sr - C.sr) / Math.max(1e-9, 1 - C.sr); // how much of the lost service this brings back
          item = { id: 'cap-servers', icon: 'cpu', title: 'Add ' + n + ' ' + plural(best.h.name, n), cost: best.cost, now: ww.now, soon: ww.soon, hw: k, n,
            why: 'Right now you can only serve ' + Math.round(C.sr * 100) + '% of your users, so ' + lost + '% of your possible income is lost. ' + (best.w.after.sr >= 0.985 ? 'This fixes it.' : back >= 0.5 ? 'This wins back most of it.' : 'This wins back part of it; add more as cash comes in.'),
            run: () => G.act.buyHw(k, n), btn: 'Buy ' + n, go: { tab: 'upgrades', cat: 'servers' } };
        }
      } else if (rackRoom > 0) {
        const n = Math.min(rackRoom, 2), cost = G.rackCost(n);
        item = { id: 'cap-racks', icon: 'cpu', title: 'Add ' + n + ' server rack' + (n > 1 ? 's' : ''), cost, unlocks: potential,
          why: 'All your rack slots are full while ' + lost + '% of users cannot be served. A rack holds ' + D.rack.slots + ' servers; it adds no income by itself but makes room for them.',
          run: () => G.act.buyRack(n), btn: 'Buy ' + n, go: { tab: 'upgrades', cat: 'racks' } };
      } else {
        const nx = G.ladderNext('dc');
        if (nx && !G.building('dc')) {
          const cost = G.ladderCost(nx);
          item = { id: 'cap-dc', icon: 'cpu', title: 'Build a ' + nx.name, cost, blocked: needs(nx), unlocks: potential,
            why: 'Your data center is full and ' + lost + '% of users cannot be served. A bigger building has floor space for more racks and servers.',
            run: () => G.act.build('dc'), btn: 'Build', go: { tab: 'upgrades', cat: 'dc' } };
        }
      }
      if (item && (item.unlocks || (item.now && Math.max(item.now.net, item.soon.net) > 0))) out.push(Object.assign({ sev: 1 - C.sr, blocked: null, enabler: true }, item));
    }
    return out.sort((p, q) => q.sev - p.sev);
  }
  // The worst bottleneck right now (null when nothing holds income back). Reads the coach list, which is memoised.
  adv.capacity = () => adv.coach().filter((t) => t.id.indexOf('cap-') === 0).sort((a, b) => b.sev - a.sev)[0] || null;

  // 2) Research that raises income by itself (new revenue streams, higher conversion, more appeal...)
  function research(x) {
    const s = x.s, C = x.b0, out = [];
    for (const n of D.research) {
      if (G.researchStatus(n.id) !== 'ready') continue;
      const w = x.what((st) => assign(st, P.done(st, n.id)));
      if (Math.max(w.now.net, w.soon.net) <= 0) continue;
      const fx = D.effText(n.eff).slice(0, 2).join(', ');
      out.push({
        id: 'res-' + n.id, icon: n.icon || 'research', title: 'Research ' + n.name, cost: G.researchCost(n), now: w.now, soon: w.soon,
        why: (fx || n.desc) + '. Takes ' + U.dur(n.time / C.M.resSpeed) + '.',
        blocked: s.res.q.length >= C.resSlots ? 'All research slots are busy' : null,
        run: () => G.act.research(n.id), btn: 'Research', go: { tab: 'research' }
      });
    }
    return out.sort((a, b) => Math.max(b.now.net, b.soon.net) - Math.max(a.now.net, a.soon.net)).slice(0, 2);
  }

  // 3) Subscription price: the best price is usually lower than players expect (more people subscribe)
  function pricing(x) {
    const s = x.s, C = x.b0;
    if (!C.st.premium) return null;
    const fair = Math.max(1, C.fair), seen = {};
    let best = null;
    for (const f of [0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1, 1.15, 1.3, 1.5]) {
      const p = Math.max(1, Math.min(100, Math.round(fair * f)));
      if (seen[p]) continue;
      seen[p] = 1;
      if (p === s.price) continue;
      const w = x.what({ price: p });
      if (!best || w.soon.net > best.w.soon.net) best = { p, w };
    }
    if (!best) return null;
    const dir = best.p < s.price ? 'lower' : 'raise';
    const subsNow = Math.round(C.conv * 1000) / 10;
    return {
      id: 'price', icon: 'tag', title: (best.p < s.price ? 'Lower' : 'Raise') + ' the subscription price to $' + best.p, cost: 0, now: best.w.now, soon: best.w.soon,
      why: best.p < s.price ? 'At $' + s.price + ' only ' + subsNow + '% of users subscribe. A lower price brings in many more subscribers and earns more in total.' : 'Subscribers would still sign up at $' + best.p + ', so you earn more from each of them.',
      run: () => { const r = G.act.setPrice(best.p); G.calc(); return r; }, btn: 'Set $' + best.p, go: { tab: 'business', seg: 'strategy' }, free: true, dir
    };
  }

  // 4) Models: release, train, fine-tune
  function models(x) {
    const s = x.s, C = x.b0, out = [];
    const rel = (id) => (st) => assign(st, P.model(st, id, { st: 'rel', tune: (st.models[id] && st.models[id].tune) || 0 }), { active: id });
    const heads = (w) => (w.now.sr < -0.03 ? ' Heads up: it needs more server power, so add servers too.' : '');
    for (const m of D.models) {
      const st = G.modelStatus(m.id);
      if (st === 'trained') {
        const w = x.what(rel(m.id));
        out.push({ id: 'rel-' + m.id, icon: 'rocket', title: 'Release ' + m.name, cost: 0, now: w.now, soon: w.soon,
          why: 'It is trained and waiting. Releasing makes it your live model: smarter, more popular, and a surge of new users.' + heads(w), run: () => G.act.release(m.id), btn: 'Release', go: { tab: 'models' }, free: true });
      }
    }
    // next model to train
    const next = D.models.find((m) => !s.models[m.id]);
    if (next && !s.job) {
      const w = x.what(rel(next.id));
      const stt = G.modelStatus(next.id);
      if (stt === 'ready' && Math.max(w.now.net, w.soon.net) > 0) {
        const cost = G.trainCost(next), free = C.capEff - C.ctf;
        out.push({ id: 'train-' + next.id, icon: next.icon, title: 'Train ' + next.name, cost, now: w.now, soon: w.soon,
          why: next.tag + '. Training takes ' + U.dur(next.time / C.M.trainSpeed) + ' and reserves ' + U.tf(next.tf) + ' of server power meanwhile. The income shown is what you get once it is trained and released.' + heads(w),
          blocked: free < next.tf ? 'Needs ' + U.tf(next.tf) + ' of free server power' : null, goReq: free < next.tf ? { tab: 'upgrades', cat: 'servers' } : null,
          run: () => G.act.train(next.id), btn: 'Train', go: { tab: 'models' } });
      } else if (stt === 'locked' && Math.max(w.now.net, w.soon.net) > 0) {
        const miss = next.req.find((r) => !s.res.done[r]);
        const rn = miss && D.rmap[miss];
        if (rn && G.researchStatus(rn.id) === 'ready') {
          out.push({ id: 'unlock-' + next.id, icon: rn.icon || 'research', title: 'Research ' + rn.name, cost: G.researchCost(rn), now: { net: 0, rev: 0, exp: 0 }, soon: w.soon,
            why: 'Unlocks ' + next.name + ' (' + next.tag.toLowerCase() + '), your next model. Once you train and release it, income could grow by about ' + U.fine(w.soon.net) + '/s.', blocked: s.res.q.length >= C.resSlots ? 'All research slots are busy' : null,
            run: () => G.act.research(rn.id), btn: 'Research', go: { tab: 'research' } });
        }
      }
    }
    // fine-tune the live model
    const ti = G.tuneInfo(s.active);
    if (ti && !s.job) {
      const w = x.what((z) => assign(z, P.model(z, z.active, { tune: ti.lvl + 1 })));
      if (Math.max(w.now.net, w.soon.net) > 0) {
        const free = C.capEff - C.ctf;
        out.push({ id: 'tune', icon: 'gauge', title: 'Fine-tune ' + (D.mmap[s.active] || D.models[0]).name, cost: ti.cost, now: w.now, soon: w.soon,
          why: 'Makes your live model 8% smarter and 5% faster, so more people choose it. Takes ' + U.dur(ti.time / C.M.trainSpeed) + '.',
          blocked: free < ti.tf ? 'Needs ' + U.tf(ti.tf) + ' of free server power' : null, goReq: free < ti.tf ? { tab: 'upgrades', cat: 'servers' } : null,
          run: () => G.act.tune(s.active), btn: 'Fine-tune', go: { tab: 'models' } });
      }
    }
    return out;
  }

  // 5) Ads and marketing
  function levers(x) {
    const s = x.s, out = [];
    if (!s.ads) {
      const w = x.what({ ads: true });
      out.push({ id: 'ads', icon: 'mega', title: 'Turn ads on', cost: 0, now: w.now, soon: w.soon, free: true,
        why: 'Free users would pay you through ads. Satisfaction drops a little, and user growth slows a bit.', run: () => G.act.setAds(true), btn: 'Turn on', go: { tab: 'business', seg: 'strategy' } });
    }
    if (s.mkt < 4) {
      const w = x.what({ mkt: s.mkt + 1 });
      out.push({ id: 'mkt', icon: 'mega', title: 'Raise marketing to ' + G.MKT_NAMES[s.mkt + 1], cost: 0, now: w.now, soon: w.soon, free: true,
        why: 'Costs ' + Math.round(K.mkt[s.mkt + 1] * 100) + '% of your income but brings in more users, and faster.', run: () => G.act.setMkt(s.mkt + 1), btn: 'Raise', go: { tab: 'business', seg: 'strategy' } });
    }
    return out;
  }

  // 6) Enterprise contracts
  function contracts(x) {
    const s = x.s, C = x.b0;
    if (!C.F.ent || C.nContracts >= G.contractSlots()) return null;
    let best = null;
    for (const p of D.partners) {
      if (s.contracts[p.id] || C.intel < p.intel || C.uptime < 90) continue;
      const w = x.what((st) => assign(st, { contracts: assign(st.contracts, { [p.id]: 1 }) }));
      if (w.now.net <= 0) continue;
      const cand = { p, w, afford: s.cash >= p.fee && C.capAvail >= p.tf };
      if (!best || (cand.afford && !best.afford) || (cand.afford === best.afford && w.now.net > best.w.now.net)) best = cand;
    }
    if (!best) return null;
    const p = best.p;
    return { id: 'ent-' + p.id, icon: 'doc', title: 'Sign ' + p.name, cost: p.fee, now: best.w.now, soon: best.w.soon,
      why: p.sector + ' company paying ' + U.money(p.mrr) + ' a month. It reserves ' + U.tf(p.tf) + ' of your server power.',
      blocked: C.capAvail < p.tf ? 'Needs ' + U.tf(p.tf) + ' of free server power' : null, goReq: C.capAvail < p.tf ? { tab: 'upgrades', cat: 'servers' } : null,
      run: () => G.act.signContract(p.id), btn: 'Sign', go: { tab: 'business', seg: 'partners' } };
  }

  // 7) New regions / hubs
  function regions(x) {
    const s = x.s;
    let best = null;
    for (const r of D.regions) {
      const st = G.regionStatus(r.id);
      if (st !== 'ready' && st !== 'open') continue;
      const nx = G.regionNext(r.id);
      if (!nx) continue;
      const w = x.what((z) => assign(z, { regions: assign(z.regions, { [r.id]: { hub: nx.to } }) }));
      const g = Math.max(w.now.net, w.soon.net);
      if (g <= 0) continue;
      const cand = { r, nx, w, g, afford: s.cash >= nx.cost };
      if (!best || (cand.afford && !best.afford) || (cand.afford === best.afford && g / Math.max(1, nx.cost) > best.g / Math.max(1, best.nx.cost))) best = cand;
    }
    if (!best) return null;
    const r = best.r;
    return { id: 'reg-' + r.id, icon: 'globe', title: (G.state.regions[r.id] ? 'Upgrade your ' + r.name + ' hub' : 'Open ' + r.name), cost: best.nx.cost, now: best.w.now, soon: best.w.soon,
      why: G.state.regions[r.id] ? 'A bigger hub reaches more of the local population.' : r.blurb, run: () => G.act.region(r.id), btn: G.state.regions[r.id] ? 'Upgrade' : 'Open', go: { tab: 'global', region: r.id } };
  }

  const GEN = [bottlenecks, research, pricing, models, levers, contracts, regions];
  // Ranked, de-duplicated suggestions. group 'now' = pays off immediately, 'grow' = pays off as users catch up.
  adv.coach = function () {
    const x = context();
    if (x.coach) return x.coach;
    const s = x.s, C = x.b0, floor = Math.max(1e-4, 0.004 * Math.max(0.05, C.rev.total)), out = [], seen = {};
    for (const gen of GEN) {
      let r = null;
      try { r = gen(x); } catch (e) { if (G.err) G.err(e); }
      for (const t of [].concat(r || [])) {
        if (!t || seen[t.id]) continue;
        seen[t.id] = 1;
        const now = t.now || { net: 0, rev: 0, exp: 0 }, soon = t.soon || now;
        t.now = now; t.soon = soon; // always present, so the UI never needs to guard
        t.gainNow = now.net; t.gainSoon = Math.max(soon.net, now.net, t.unlocks || 0);
        t.group = now.net > floor ? 'now' : 'grow';
        t.head = t.gainSoon;
        t.afford = !t.blocked && s.cash >= t.cost;
        t.payback = t.cost > 0 && t.gainSoon > 0 ? t.cost / t.gainSoon : 0; // seconds of extra income needed to earn the price back
        if (t.head <= floor && !t.enabler) continue;
        out.push(t);
      }
    }
    // affordable first, then biggest gain
    out.sort((a, b) => (b.afford - a.afford) || (a.blocked ? 1 : 0) - (b.blocked ? 1 : 0) || b.head - a.head);
    x.coach = out;
    return out;
  };
  // The single best thing to do right now, in the shape the "Next step" chip wants.
  adv.topTip = function () {
    const list = adv.coach().filter((t) => t.afford && t.head > 0);
    const t = list[0];
    if (!t) return null;
    const g = t.go || { tab: 'business', seg: 'money' };
    return Object.assign({ text: t.title + (t.head > 0 ? ' (+' + U.fine(t.head) + '/s)' : '') }, g);
  };

  /* ======================= why are my costs what they are ======================= */
  const pct = (v) => (v * 100).toFixed(v < 0.1 ? 1 : 0).replace(/\.0$/, '') + '%';
  adv.costs = function () {
    const s = G.state, C = G.C, E = C.exp, M = C.M, m = C.m, tot = Math.max(1e-9, E.total);
    const cool = D.ladders.cool[s.inf.cool], pw = D.ladders.pwr[s.inf.pwr], hq = D.ladders.hq[s.inf.hq];
    const payBase = K.payBase * Math.pow(6, s.inf.hq) * M.opex * C.opexMul, payVar = K.payPct * C.rev.total * M.opex * C.opexMul;
    const perM = m.op * 1e6 * M.serve * C.opexMul;
    const tip = (t, go) => ({ t, go });
    const nextCool = G.ladderNext('cool'), nextPwr = G.ladderNext('pwr'), nextHq = G.ladderNext('hq');
    const L = {
      payroll: {
        what: 'Salaries for your team. A bigger office hires more people, and support and sales staff grow with your income.',
        drivers: [[hq.name + ' (' + hq.staff + ' staff)', payBase], ['Income-linked staff (' + pct(K.payPct) + ' of what you earn)', payVar]],
        tips: [tip('This part rises when income rises, so it is a healthy cost.'), nextHq ? tip('The next office (' + nextHq.name + ') multiplies the base salary by 6.', { tab: 'upgrades', cat: 'hq' }) : null]
      },
      serve: {
        what: 'The computing cost of every chat you answer. More users, or a bigger model, means a bigger bill.',
        drivers: [[U.num(C.served) + ' users served', null], [m.name + ' costs ' + U.fine(perM) + '/s for every 1M users', null]],
        tips: [tip('A newer model costs more per user. Deploy an older model in AI Models to save money.', { tab: 'models' })]
      },
      power: {
        what: 'Electricity for your servers and the cooling around them.',
        drivers: [['Servers draw ' + U.mw(C.powerDraw), null], ['Cooling overhead x' + cool.pue + ' (' + cool.name + ')', null], ['Electricity price x' + pw.price + ' (' + pw.name + ')', null]],
        tips: [nextCool ? tip('Better cooling ("' + nextCool.name + '") cuts the overhead to x' + nextCool.pue + '.', { tab: 'upgrades', cat: 'cool' }) : null, nextPwr ? tip('A better power source ("' + nextPwr.name + '") makes electricity x' + nextPwr.price + ' as expensive.', { tab: 'upgrades', cat: 'pwr' }) : null,
          !s.res.done.i2 ? tip('Research Energy Efficiency to cut the bill by 10%.', { tab: 'research' }) : null]
      },
      upkeep: {
        what: 'Maintenance for everything you own: servers, racks and buildings.',
        drivers: [['Equipment and buildings worth ' + U.money(s.infraValue), null], ['Maintenance is ' + (K.upkeep * 100).toFixed(4) + '% of that, every second', null]],
        tips: [tip('Every server you buy adds to this. Sell servers you have outgrown to lower it.', { tab: 'upgrades', cat: 'servers' })]
      },
      mkt: {
        what: 'Advertising to win new users. It is a share of your income.',
        drivers: [['Marketing level: ' + G.MKT_NAMES[s.mkt] + ' (' + pct(K.mkt[s.mkt]) + ' of income)', null]],
        tips: [tip('Change it in Business > Strategy. Higher marketing grows users faster.', { tab: 'business', seg: 'strategy' })]
      },
      rd: {
        what: 'A budget for extra research effort. It is a share of your income.',
        drivers: [['R&D budget: ' + G.RD_NAMES[s.rd] + ' (' + pct(K.rd[s.rd]) + ' of income)', null]],
        tips: [tip('Higher R&D makes every research project finish faster.', { tab: 'business', seg: 'strategy' })]
      }
    };
    return D.expLines.map((d) => Object.assign({ id: d.id, name: d.name, color: d.color, icon: d.icon, value: E[d.id], share: E[d.id] / tot }, L[d.id], { tips: L[d.id].tips.filter(Boolean) }));
  };

  // What moved over the last minute or so (uses the per-second history kept by the game loop).
  adv.trend = function () {
    const hs = G.hist;
    if (!hs || hs.length < 15) return null;
    const a = hs[Math.max(0, hs.length - 61)], b = hs[hs.length - 1];
    if (!a.x || !b.x) return null;
    const lines = [];
    for (const d of D.expLines) {
      const dv = b.x[d.id] - a.x[d.id];
      if (Math.abs(dv) < Math.max(1e-6, a.e * 0.01)) continue;
      let cause = '';
      switch (d.id) {
        case 'power': cause = b.d.srv !== a.d.srv ? 'you ' + (b.d.srv > a.d.srv ? 'added' : 'removed') + ' servers' : 'your cooling or power setup changed'; break;
        case 'serve': cause = 'you are serving ' + (b.d.served > a.d.served ? 'more' : 'fewer') + ' users'; break;
        case 'payroll': cause = b.d.hq !== a.d.hq ? 'your office size changed' : 'income ' + (b.r > a.r ? 'grew' : 'fell') + ' and staff scale with it'; break;
        case 'upkeep': cause = 'you ' + (b.d.val > a.d.val ? 'bought' : 'sold') + ' equipment'; break;
        default: cause = b.r !== a.r ? 'it is a share of income, which changed' : 'you changed the budget';
      }
      lines.push({ id: d.id, name: d.name, d: dv, cause });
    }
    lines.sort((p, q) => Math.abs(q.d) - Math.abs(p.d));
    return { secs: Math.max(1, hs.length - Math.max(0, hs.length - 61) - 1), dE: b.e - a.e, pE: a.e > 0 ? (b.e - a.e) / a.e : 0, dR: b.r - a.r, lines: lines.slice(0, 3) };
  };
})();
