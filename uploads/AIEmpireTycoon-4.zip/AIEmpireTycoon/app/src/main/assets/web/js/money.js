/* AI Empire Tycoon - Money screen (Money tab, first section).
   It answers the two questions every player has:
     "How do I earn more?"          -> ranked ideas from the economy advisor, each tested on a copy of your company
     "Why am I spending so much?"   -> every cost explained: what drives it, what changed lately, how to lower it
   Nothing here changes the economy; it only explains and links to the screens where things are done. */
(function () {
  'use strict';
  const G = window.G, D = G.D, U = G.U, UI = G.ui, ADV = G.adv, W = UI.w, h = U.h;
  const I = UI.I, T = UI.T, ST = UI.ST, CL = UI.CL, bind = UI.bind, btn = UI.btn, tile = UI.tile;

  const sech = (title, sub) => h('div', { class: 'full col', style: { gap: '2px' } }, h('div', { class: 'sech' }, title), sub ? h('div', { class: 'xs mut', style: { margin: '0 2px' } }, sub) : null);
  const signed = (v) => (v < 0 ? '−' : '+') + U.fine(Math.abs(v)) + '/s';

  /* ---------- 1. the three ideas behind the whole game ---------- */
  function basics() {
    const row = (icon, title, text) => h('div', { class: 'row', style: { alignItems: 'flex-start' } }, h('div', { class: 'ico' }, I(icon, 18)), h('div', { class: 'grow' }, h('div', { class: 'sm b' }, title), h('div', { class: 'xs mut' }, text)));
    if (UI.st.basics === null) UI.st.basics = G.state.stats.play < 900; // open for a new company, closed for an experienced one
    const body = h('div', { class: 'col gap8', hidden: !UI.st.basics },
      row('users', '1. Users come to you', 'A smarter model, marketing and new regions bring more people.'),
      row('cpu', '2. Servers answer them', 'If your servers, power or cooling are too small, people are turned away and you earn less.'),
      row('cash', '3. Every user you serve earns money', 'Through ads, subscriptions, API customers and more. Costs are staff, electricity, serving and upkeep.'));
    const arrow = h('span', { class: 'mut' }, I(UI.st.basics ? 'up' : 'chev', 16));
    const head = h('button', { class: 'row between', type: 'button', style: { width: '100%' }, onclick: () => { UI.st.basics = !UI.st.basics; body.hidden = !UI.st.basics; arrow.replaceChildren(I(UI.st.basics ? 'up' : 'chev', 16)); } },
      h('span', { class: 'row' }, I('question', 16), h('b', { class: 'sm' }, 'How your company makes money')), arrow);
    return h('div', { class: 'card col full' }, head, body);
  }

  /* ---------- 2. profit now, and the last 90 seconds ---------- */
  function spark() {
    const NS = 'http://www.w3.org/2000/svg', svg = document.createElementNS(NS, 'svg');
    svg.setAttribute('class', 'spark'); svg.setAttribute('viewBox', '0 0 300 74'); svg.setAttribute('preserveAspectRatio', 'none');
    const line = (c) => { const p = document.createElementNS(NS, 'polyline'); p.setAttribute('fill', 'none'); p.setAttribute('stroke', c); p.setAttribute('stroke-width', '2'); p.setAttribute('stroke-linejoin', 'round'); p.setAttribute('vector-effect', 'non-scaling-stroke'); svg.append(p); return p; };
    const lines = { r: line('#3dd6c6'), e: line('#ff6b81'), n: line('#f6b84a') };
    bind(svg, () => {
      const hs = G.hist;
      if (hs.length < 2) return;
      const mx = Math.max(1e-9, ...hs.map((x) => Math.max(x.r, x.e)));
      for (const k in lines) lines[k].setAttribute('points', hs.map((x, i) => (i / (hs.length - 1)) * 300 + ',' + (70 - (Math.max(0, x[k]) / mx) * 64)).join(' '));
    });
    return svg;
  }
  function hero() {
    const net = h('div', { class: 'mh-v' }), msg = h('div', { class: 'sm mut' }), per = h('div', { class: 'xs dimt' });
    const inc = h('div', { class: 'tv pos' }), exp = h('div', { class: 'tv neg' });
    const card = h('div', { class: 'card col full mhero' },
      h('div', { class: 'micro' }, 'Your profit right now'), net, msg,
      h('div', { class: 'grid2', style: { marginTop: '4px' } }, tile('Money in (income)', inc), tile('Money out (costs)', exp)),
      h('div', { class: 'row between', style: { marginTop: '6px' } }, h('span', { class: 'micro' }, 'Last 90 seconds'), h('span', { class: 'xs row gap12' }, h('span', { class: 'acc' }, 'income'), h('span', { class: 'neg' }, 'costs'), h('span', { class: 'gold' }, 'profit'))),
      spark(), per);
    bind(card, () => {
      const C = G.C;
      T(net, signed(C.net)); CL(net, 'neg', C.net < 0); CL(net, 'pos', C.net >= 0);
      T(inc, U.fine(C.rev.total) + '/s'); T(exp, U.fine(C.exp.total) + '/s');
      T(msg, C.net < 0 ? 'You spend more than you earn. The ideas below show how to turn that around.' : 'Every second you earn ' + U.fine(C.rev.total) + ' and spend ' + U.fine(C.exp.total) + '.');
      T(per, '≈ ' + U.money(C.net * 60) + ' a minute · ' + U.money(C.net * 3600) + ' an hour');
    });
    return card;
  }

  /* ---------- 3. how to earn more ---------- */
  function earnMore() {
    const list = h('div', { class: 'col gap8' }), TOP = 4;
    bind(list, () => {
      const all = ADV.coach().filter((t) => t.head > 0 || t.unlocks), shown = UI.st.moneyAll ? all : all.slice(0, TOP);
      const key = [UI.st.moneyAll, all.length].concat(shown.map((t) => [t.id, Math.round(t.cost), t.head.toPrecision(2), t.afford ? 1 : 0, t.blocked || ''].join(':'))).join('|');
      if (list._k === key) return;
      list._k = key; list.textContent = '';
      if (!shown.length) list.append(h('div', { class: 'card xs mut' }, 'Nothing obvious to improve right now. Keep growing: as more users arrive, the next thing that holds you back will show up here.'));
      shown.forEach((t) => list.append(W.coachCard(t, { hot: t.afford && t === shown[0] })));
      if (all.length > TOP) list.append(btn(UI.st.moneyAll ? 'Show fewer ideas' : 'Show all ' + all.length + ' ideas', { cls: 'sm ghost blk', onclick: () => { UI.st.moneyAll = !UI.st.moneyAll; UI.refresh(); } }));
    });
    return h('div', { class: 'col gap8 full' }, sech('How to earn more', 'Ideas ranked by what they would add. Each one is tested on a copy of your company, so the numbers are what you would really get.'), list);
  }

  /* ---------- 4. where income comes from ---------- */
  function stackBar(list, key) {
    const el = h('div', { class: 'stack' }, list.map((x) => h('i', { style: { background: x.color } })));
    bind(el, () => { const src = G.C[key], tot = Math.max(1e-9, src.total); list.forEach((x, i) => ST(el.children[i], 'width', (src[x.id] / tot * 100).toFixed(1) + '%')); });
    return el;
  }
  const need = (id) => (G.state.res.done[id] ? null : { text: 'Research ' + D.rmap[id].name, go: { tab: 'research' }, label: 'Research' });
  // Why a stream earns nothing yet (null when it is working)
  const OFF = {
    ads: () => (G.state.ads ? null : { text: 'Ads are switched off', go: { tab: 'business', seg: 'strategy' }, label: 'Strategy' }),
    subs: () => need('p1'),
    api: () => need('p2'),
    ent: () => need('b3') || (G.C.nContracts < 1 ? { text: 'No partner signed yet', go: { tab: 'business', seg: 'partners' }, label: 'Partners' } : null),
    img: () => need('p3') || (G.C.st.img ? null : { text: 'Needs an image model live (CreatorAI or newer)', go: { tab: 'models' }, label: 'AI Models' }),
    agent: () => need('p7') || (G.C.st.agent ? null : { text: 'Needs AgentAI or newer live', go: { tab: 'models' }, label: 'AI Models' })
  };
  function streamRow(d) {
    const val = h('b'), share = h('div', { class: 'xs dimt' }), go = btn('', { cls: 'sm ghost', onclick: () => UI.follow(go._go) });
    const why = h('div', { class: 'row why', hidden: true }, I('lock', 12), h('span', { class: 'xs warn grow' }), go);
    const row = h('div', { class: 'srow' },
      h('div', { class: 'row' }, h('div', { class: 'ico', style: { background: d.color + '26', color: d.color, width: '30px', height: '30px' } }, I(d.icon, 16)), h('div', { class: 'grow sm b' }, d.name), h('div', { class: 'tr' }, val, share)),
      h('div', { class: 'xs mut' }, d.how), why);
    bind(row, () => {
      const C = G.C, v = C.rev[d.id], off = OFF[d.id]();
      T(val, U.fine(v) + '/s'); T(share, Math.round((v / Math.max(1e-9, C.rev.total)) * 100) + '%');
      why.hidden = !off;
      if (off) { T(why.children[1], off.text); go._go = off.go; T(go._l, off.label); }
      CL(row, 'off', !!off && v <= 0);
    });
    return row;
  }
  function sources() {
    return h('div', { class: 'col gap8 full' }, sech('Where your income comes from'),
      h('div', { class: 'card col' }, stackBar(D.streams, 'rev'), D.streams.map(streamRow)));
  }

  /* ---------- 5. why you spend what you spend ---------- */
  function trendCard() {
    const card = h('div', { class: 'card col', hidden: true });
    bind(card, () => {
      const t = ADV.trend();
      card.hidden = !t;
      if (!t) return;
      const sig = [t.dE.toPrecision(2), t.lines.map((l) => l.id + l.d.toPrecision(2)).join()].join('|');
      if (card._sig === sig) return;
      card._sig = sig; card.textContent = '';
      const pct = Math.abs(t.pE) >= 0.01 ? ' (' + (t.pE > 0 ? '+' : '−') + Math.round(Math.abs(t.pE) * 100) + '%)' : '';
      card.append(h('div', { class: 'micro' }, 'What changed in the last ' + U.dur(t.secs)),
        h('div', { class: 'sm b' }, Math.abs(t.dE) < 1e-6 ? 'Your costs have been steady.' : 'Your costs ' + (t.dE > 0 ? 'rose' : 'fell') + ' by ' + U.fine(Math.abs(t.dE)) + '/s' + pct + '.'),
        t.lines.map((l) => h('div', { class: 'xs' }, h('b', { class: l.d > 0 ? 'neg' : 'pos' }, l.name + ' ' + U.delta(l.d)), h('span', { class: 'mut' }, ' · ' + l.cause))));
    });
    return card;
  }
  // One expense: collapsed it shows the amount and share; opened it says what it is, what drives it and how to lower it.
  function costRow(d0, rows) {
    const val = h('b'), share = h('div', { class: 'xs dimt' }), fill = UI.bar('thin'), body = h('div', { class: 'xbody col gap8' });
    const row = h('div', { class: 'xrow' + (UI.st.costOpen === d0.id ? ' open' : '') },
      h('button', { class: 'xhead', type: 'button', 'aria-label': d0.name + '. Tap to see why', onclick: () => { UI.st.costOpen = UI.st.costOpen === d0.id ? '' : d0.id; rows.forEach((r) => r.el.classList.toggle('open', r.id === UI.st.costOpen)); } },
        h('div', { class: 'ico', style: { background: d0.color + '26', color: d0.color, width: '30px', height: '30px' } }, I(d0.icon, 16)),
        h('div', { class: 'grow' }, h('div', { class: 'sm b' }, d0.name), fill),
        h('div', { class: 'tr' }, val, share), h('span', { class: 'xch mut' }, I('chev', 14))),
      body);
    fill.firstChild.style.background = d0.color;
    rows.push({ id: d0.id, el: row, val, share, fill, body });
    return row;
  }
  function expenses() {
    const rows = [], data = ADV.costs();
    const open = UI.st.costOpen === null ? data.reduce((a, b) => (b.share > a.share ? b : a)).id : UI.st.costOpen;
    UI.st.costOpen = open;
    const card = h('div', { class: 'card col' }, stackBar(D.expLines, 'exp'), data.map((d) => costRow(d, rows)));
    bind(card, () => {
      for (const d of ADV.costs()) {
        const r = rows.find((x) => x.id === d.id);
        T(r.val, U.fine(d.value) + '/s'); T(r.share, Math.round(d.share * 100) + '%'); UI.setBar(r.fill, d.share);
        const sig = d.what + d.drivers.map((x) => x[0] + (x[1] == null ? '' : Math.round(x[1] * 1e5))).join() + d.tips.map((x) => x.t).join();
        if (r.sig === sig) continue;
        r.sig = sig; r.body.textContent = '';
        r.body.append(h('div', { class: 'xs mut' }, d.what),
          h('div', { class: 'col', style: { gap: '3px' } }, d.drivers.map((x) => h('div', { class: 'kv' }, h('span', {}, x[0]), x[1] == null ? null : h('b', {}, U.fine(x[1]) + '/s')))),
          d.tips.map((x) => h('div', { class: 'tipr' }, I('bulb', 13), h('span', { class: 'xs grow' }, x.t), x.go ? btn('Show', { cls: 'sm ghost', onclick: () => UI.follow(x.go) }) : null)));
      }
    });
    return h('div', { class: 'col gap8 full' }, sech('Why you spend what you spend', 'Tap a cost to see what drives it and how to lower it.'), trendCard(), card);
  }

  /* ---------- 6. recent changes ---------- */
  function recent() {
    const card = h('div', { class: 'card col' });
    bind(card, () => {
      const l = G.state.ledger, key = l.length + ':' + (l[0] ? l[0].t : 0);
      if (card._k === key) return;
      card._k = key; card.textContent = '';
      if (!l.length) { card.append(h('div', { class: 'xs mut' }, 'Nothing yet. Every purchase and research shows here with what it did to your income and costs.')); return; }
      l.slice(0, 8).forEach((e) => {
        const chip = (label, v, cost) => (Math.abs(v) < 1e-4 ? null : h('span', { class: 'lchip ' + W.tone(v, cost) }, label + ' ' + U.delta(v)));
        card.append(h('div', { class: 'lrow' }, h('div', { class: 'row between' }, h('span', { class: 'sm b' }, e.x), h('span', { class: 'xs dimt' }, UI.ago(e.t))), h('div', { class: 'row wrap gap4' }, chip('income', e.dr, false), chip('costs', e.de, true))));
      });
    });
    return h('div', { class: 'col gap8 full' }, sech('Recent changes', 'What you did lately, and how it moved income and costs.'), card);
  }

  /* ---------- 7. the numbers behind it ---------- */
  function numbers() {
    const kv = (label, get) => { const v = h('b'), r = h('div', { class: 'kv' }, h('span', {}, label), v); bind(r, () => T(v, get())); return r; };
    const C = () => G.C, s = () => G.state;
    return h('div', { class: 'col gap8 full' }, sech('The numbers behind your income'), h('div', { class: 'card col' },
      kv('Active users', () => U.num(s().users) + ' (' + U.num(C().served) + ' served)'),
      kv('Premium subscribers', () => (C().st.premium ? U.num(C().subs) + ' · ' + (C().conv * 100).toFixed(1) + '%' : 'Research Subscription Plans')),
      kv('API customers', () => (C().st.api ? U.num(C().apiCust) : 'Locked')),
      kv('Enterprise contracts', () => C().nContracts + ' / ' + G.contractSlots()),
      kv('Image users / agents', () => (C().st.img ? U.num(C().imgUsers) : '—') + ' / ' + (C().st.agent ? U.num(C().agents) : '—')),
      kv('Model intelligence', () => U.num(C().intel)),
      kv('Launch hype', () => 'x' + (1 + 0.6 * Math.min(s().hype, 3)).toFixed(2)),
      kv('Service uptime', () => C().uptime.toFixed(2) + '%'),
      kv('Share of demand served', () => Math.round(C().sr * 100) + '%'),
      kv('Customer satisfaction', () => Math.round(s().sat) + '% → ' + Math.round(C().satT) + '%'),
      kv('Market share', () => (C().share * 100).toFixed(1) + '%')));
  }

  UI.biz.money = () => [basics(), hero(), earnMore(), sources(), expenses(), recent(), numbers()];
})();
