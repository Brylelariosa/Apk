/* AI Empire Tycoon - the headquarters, in five tiers.
   Tiers 0 and 1 (the garage and the startup office) are cut open so you can watch the team work; tiers 2 to 4 (office block,
   corporate tower, the Spire) are closed buildings with a lit-windows layer. They are built with the kit in art-kit.js, and everything
   that moves on them is listed in o.parts (see art-live.js). The footprints (o.fp) are the ones the scene and the map already know. */
(function () {
  'use strict';
  const G = window.G, U = G.U, D = G.D, A = G.art, K = A.kit;
  const P = A.P, poly = A.poly, hash = A.hash, ell = A.ell;
  const TAU = Math.PI * 2;
  const base = (tier, fp, bb, tb) => ({ id: 'hq', kind: 'hq', tier, name: D.ladders.hq[tier].name, fp, b: bb, tb: tb || null });
  const line = (c, pts, col, w) => { c.strokeStyle = col; c.lineWidth = w || 1; c.beginPath(); pts.forEach((p, i) => (i ? c.lineTo(p[0], p[1]) : c.moveTo(p[0], p[1]))); c.stroke(); };

  /* ---------- flat painters for the walls of the cut-open rooms (pixels, y down) ---------- */
  function skyView(cc, x, y, w, h) {   // a window onto a dusk city, the same at any hour (the sprite is drawn once)
    cc.fillStyle = 'rgba(6,10,24,.92)'; cc.fillRect(x - 1.5, y - 1.5, w + 3, h + 3);
    const g = cc.createLinearGradient(0, y, 0, y + h);
    g.addColorStop(0, '#1b2a63'); g.addColorStop(0.55, '#7a5aa8'); g.addColorStop(1, '#ffb27a');
    cc.fillStyle = g; cc.fillRect(x, y, w, h);
    cc.fillStyle = 'rgba(255,255,255,.85)';
    for (let i = 0; i < 6; i++) cc.fillRect(x + hash(i, 1, 5) * w, y + hash(i, 2, 5) * h * 0.4, 1, 1);
    cc.fillStyle = 'rgba(22,16,52,.9)';
    for (let bx = x, i = 0; bx < x + w; i++) { const bw = 3 + hash(i, 3, 8) * 5, bh = 4 + hash(i, 4, 8) * h * 0.45; cc.fillRect(bx, y + h - bh, Math.min(bw, x + w - bx), bh); bx += bw + 0.6; }
    cc.fillStyle = 'rgba(6,10,24,.9)'; cc.fillRect(x + w / 2 - 0.6, y, 1.2, h); cc.fillRect(x, y + h * 0.5 - 0.6, w, 1.2);
    cc.fillStyle = 'rgba(255,255,255,.16)'; cc.beginPath(); cc.moveTo(x + w * 0.1, y + h); cc.lineTo(x + w * 0.34, y + h); cc.lineTo(x + w * 0.8, y); cc.lineTo(x + w * 0.56, y); cc.fill();
    cc.fillStyle = 'rgba(255,255,255,.4)'; cc.fillRect(x - 2, y + h + 1.5, w + 4, 1.6);
  }
  function board(cc, x, y, w, h) {   // a whiteboard with the plan on it: data -> model -> money
    cc.fillStyle = '#8c9ab8'; cc.fillRect(x - 1.5, y - 1.5, w + 3, h + 3);
    cc.fillStyle = '#eef3fb'; cc.fillRect(x, y, w, h);
    cc.fillStyle = 'rgba(40,60,110,.07)'; cc.fillRect(x, y + h * 0.58, w, h * 0.42);
    const by = y + h * 0.16, bh = h * 0.3, bw = w * 0.22;
    cc.lineWidth = 1;
    [0.07, 0.39, 0.71].forEach((u, i) => { cc.strokeStyle = i === 2 ? '#d4502c' : '#3d78be'; cc.strokeRect(x + w * u, by, bw, bh); });
    cc.strokeStyle = '#3d78be'; cc.beginPath();
    for (const u of [0.3, 0.62]) { const ax = x + w * u, bx = x + w * (u + 0.07), my = by + bh / 2; cc.moveTo(ax, my); cc.lineTo(bx, my); cc.moveTo(bx - 1.6, my - 1.5); cc.lineTo(bx, my); cc.lineTo(bx - 1.6, my + 1.5); }
    cc.stroke();
    cc.strokeStyle = '#d4502c'; cc.beginPath(); cc.moveTo(x + w * 0.08, y + h * 0.9); cc.lineTo(x + w * 0.3, y + h * 0.78); cc.lineTo(x + w * 0.5, y + h * 0.83); cc.lineTo(x + w * 0.72, y + h * 0.64); cc.lineTo(x + w * 0.92, y + h * 0.56); cc.stroke();
    cc.fillStyle = '#6b7a99'; cc.fillRect(x + w * 0.2, y + h + 1.5, w * 0.6, 1.8);
  }
  function poster(cc, x, y, w, h, hex) {
    cc.fillStyle = 'rgba(6,10,24,.85)'; cc.fillRect(x - 1, y - 1, w + 2, h + 2);
    const g = cc.createLinearGradient(x, y, x + w, y + h); g.addColorStop(0, U.shade(hex, 1.3)); g.addColorStop(1, U.shade(hex, 0.7));
    cc.fillStyle = g; cc.fillRect(x, y, w, h);
    cc.fillStyle = 'rgba(255,255,255,.6)'; cc.beginPath(); cc.arc(x + w * 0.5, y + h * 0.4, Math.min(w, h) * 0.2, 0, TAU); cc.fill();
    cc.fillRect(x + w * 0.2, y + h * 0.76, w * 0.6, 1.2); cc.fillRect(x + w * 0.3, y + h * 0.86, w * 0.4, 1);
  }
  function shelf(cc, x, y, w, seed) {   // a plank with a row of books and boxes on it
    cc.fillStyle = '#7a5c3f'; cc.fillRect(x, y, w, 1.8);
    cc.fillStyle = 'rgba(0,0,0,.3)'; cc.fillRect(x, y + 1.8, w, 1);
    const cols = ['#e0603a', '#3d78be', '#e8c85a', '#58c092', '#b78cff'];
    for (let bx = x + 1.5, i = 0; bx < x + w - 4; i++) {
      const bw = 2.5 + hash(i, 1, seed) * 3.5, bh = 4 + hash(i, 2, seed) * 5;
      cc.fillStyle = cols[Math.floor(hash(i, 3, seed) * 5)]; cc.fillRect(bx, y - bh, bw, bh); bx += bw + 0.6;
    }
  }
  function neon(cc, x, y, w, h, str, hex, glow) {
    cc.fillStyle = 'rgba(6,10,24,.94)'; K.rrect(cc, x, y, w, h, 3); cc.fill();
    cc.strokeStyle = U.rgba(hex, 0.9); cc.lineWidth = 1.2; K.rrect(cc, x + 0.6, y + 0.6, w - 1.2, h - 1.2, 3); cc.stroke();
    cc.save(); cc.shadowColor = hex; cc.shadowBlur = glow === undefined ? 5 : glow;
    K.text(cc, str, x + w / 2, y + h / 2 + 0.5, h * 0.56, '#f4fffd', { align: 'center', sp: 1.4 });
    cc.restore();
  }
  function roller(cc, x, y, w, h) {   // a garage door that is half open: slats at the top, dusk outside
    cc.fillStyle = 'rgba(6,10,24,.92)'; cc.fillRect(x - 1.5, y - 1.5, w + 3, h + 3);
    const g = cc.createLinearGradient(0, y, 0, y + h); g.addColorStop(0, '#1a2250'); g.addColorStop(1, '#ffb27a');
    cc.fillStyle = g; cc.fillRect(x, y, w, h);
    cc.fillStyle = '#1b2a4a'; cc.fillRect(x, y + h - 4, w, 4);
    const dh = h * 0.46;
    for (let i = 0; i * 3.2 < dh; i++) { cc.fillStyle = i % 2 ? '#93a2c4' : '#7f8eb2'; cc.fillRect(x, y + i * 3.2, w, 2.7); }
    cc.fillStyle = 'rgba(0,0,0,.4)'; cc.fillRect(x, y + dh, w, 2.4);
    cc.fillStyle = 'rgba(255,255,255,.5)'; cc.fillRect(x + w / 2 - 3, y + dh - 3.6, 6, 1.4);
  }
  function codeScreen(cc, W, H, i) {   // a monitor with a few lines of code on it
    const g = cc.createLinearGradient(0, 0, 0, H); g.addColorStop(0, '#0f2447'); g.addColorStop(1, '#091630');
    cc.fillStyle = g; cc.fillRect(0, 0, W, H);
    const cols = ['#69d4ee', '#9be7a6', '#ffd27a', '#c3a3ff'], n = Math.max(2, Math.floor((H - 2) / 2.4));
    for (let k = 0; k < n; k++) {
      const ind = hash(i, k, 21) > 0.55 ? W * 0.14 : 0, len = W * (0.3 + hash(i, k, 22) * 0.5);
      cc.fillStyle = cols[Math.floor(hash(i, k, 23) * 4)]; cc.fillRect(1.4 + ind, 1.3 + k * 2.4, Math.min(len, W - 2.8 - ind), 1.2);
    }
  }

  /* ---------- tiers 0 and 1: rooms cut open ---------- */
  function interior(tier, pal) {
    const t1 = tier === 1, x0 = t1 ? 1.3 : 1.7, sz = t1 ? 4.7 : 4, H = t1 ? 50 : 44, FZ = 4, E = x0 + sz;
    const o = base(tier, [x0, x0, sz, sz, H], A.bbox(x0 - 0.35, x0 - 0.35, sz + 0.7, sz + 0.7, H + 14, 10));
    o.seats = []; o.screens = [];
    const L = K.rig(o); o.lit = null;   // furniture stands in front of these walls, so the lit-windows layer would draw over it
    const desks = t1 ? [[1.9, 1.75], [3.05, 1.75], [4.2, 1.75], [1.7, 3.0], [1.7, 4.25], [3.4, 3.6]] : [[2.35, 2.0], [3.65, 2.0], [2.05, 3.4]];
    const along = (d) => d[0] < 2.3 && d[1] > 2.6;
    desks.forEach((d) => o.seats.push(along(d) ? [d[0] + 0.95, d[1] + 0.55] : [d[0] + 0.55, d[1] + 0.85]));
    o.entry = P(x0 + sz * 0.5, E + 0.3);
    o.glow = [{ p: P(x0 + 1.5, x0 + 1.5, 28), r: 55, c: '#ffc98a', a: 0.12 }];
    const wallBase = (cc, W, Hh, k) => {
      const g = cc.createLinearGradient(0, 0, 0, Hh);
      g.addColorStop(0, U.shade(pal.wall.hex, 1.4 * k)); g.addColorStop(1, U.shade(pal.wall.hex, 0.98 * k));
      cc.fillStyle = g; cc.fillRect(0, 0, W, Hh);
      cc.fillStyle = 'rgba(8,12,28,.38)'; cc.fillRect(0, Hh - 5, W, 5);
      cc.fillStyle = 'rgba(255,255,255,.14)'; cc.fillRect(0, Hh - 5.8, W, 0.8);
      cc.fillStyle = 'rgba(255,255,255,.12)'; cc.fillRect(0, 0, W, 1.3);
    };
    o.draw = (c) => {
      L.begin(); o.screens.length = 0;
      // ---- the floor ----
      K.shadow(c, x0 - 0.15, x0 - 0.15, sz + 0.3, sz + 0.3, 0.6, 0.55);
      K.bx(c, x0, x0, sz, sz, FZ, 0, pal.floor);
      poly(c, [P(x0, x0, FZ), P(E, x0, FZ), P(E, E, FZ), P(x0, E, FZ)], U.shade(pal.floor.hex, 1.08));
      if (t1) {   // wooden boards
        const n = Math.round(sz / 0.3);
        for (let k = 0; k < n; k++) { const xa = x0 + (sz * k) / n, xb = x0 + (sz * (k + 1)) / n; poly(c, [P(xa, x0, FZ), P(xb, x0, FZ), P(xb, E, FZ), P(xa, E, FZ)], hash(k, 1, 3) > 0.5 ? 'rgba(255,255,255,.05)' : 'rgba(0,0,0,.08)'); }
      } else {    // poured concrete with joints and an oil stain
        c.strokeStyle = 'rgba(0,0,0,.2)'; c.lineWidth = 1; c.beginPath();
        for (let u = 1; u < sz; u++) { let a = P(x0 + u, x0, FZ), b = P(x0 + u, E, FZ); c.moveTo(a[0], a[1]); c.lineTo(b[0], b[1]); a = P(x0, x0 + u, FZ); b = P(E, x0 + u, FZ); c.moveTo(a[0], a[1]); c.lineTo(b[0], b[1]); }
        c.stroke();
        const s = P(x0 + 3.1, x0 + 1.7, FZ); ell(c, s[0], s[1], 17, 7); c.fillStyle = 'rgba(0,0,0,.16)'; c.fill();
      }
      // light falling in from the door and the window
      poly(c, [P(x0 + 0.3, x0 + 0.2, FZ), P(x0 + sz * 0.46, x0 + 0.2, FZ), P(x0 + sz * 0.46 + 1.5, x0 + 2.4, FZ), P(x0 + 1.8, x0 + 2.4, FZ)], 'rgba(255,205,150,.11)');
      if (t1) poly(c, [P(x0 + 0.2, x0 + 0.3, FZ), P(x0 + 0.2, x0 + 1.6, FZ), P(x0 + 1.8, x0 + 2.6, FZ), P(x0 + 1.8, x0 + 1.3, FZ)], 'rgba(255,205,150,.1)');
      // a rug in the middle
      const rx = t1 ? 2.45 : 3.1, ry = t1 ? 2.8 : 2.95, rw = t1 ? 1.7 : 1.9, rd = t1 ? 1.5 : 1.7;
      poly(c, [P(rx, ry, FZ), P(rx + rw, ry, FZ), P(rx + rw, ry + rd, FZ), P(rx, ry + rd, FZ)], U.rgba(pal.acc, 0.22), U.rgba(pal.acc, 0.55));
      poly(c, [P(rx + 0.12, ry + 0.12, FZ), P(rx + rw - 0.12, ry + 0.12, FZ), P(rx + rw - 0.12, ry + rd - 0.12, FZ), P(rx + 0.12, ry + rd - 0.12, FZ)], null, 'rgba(255,255,255,.16)');
      // ---- the two back walls ----
      const wl = K.bx(c, x0, x0, 0.2, sz, H, FZ, pal.wall), wr = K.bx(c, x0, x0, sz, 0.2, H, FZ, pal.wall);
      K.sheet(c, wl.R, (cc, W, Hh) => {
        wallBase(cc, W, Hh, 0.92);
        skyView(cc, 9, 8, 38, 22);
        board(cc, 58, 8, 52, 25);
        shelf(cc, W - 36, 22, 30, 4);
        poster(cc, W - 22, 4, 13, 13, t1 ? '#b78cff' : '#e0603a');
      });
      K.sheet(c, wr.L, (cc, W, Hh) => {
        wallBase(cc, W, Hh, 1.12);
        if (t1) { skyView(cc, W - 52, 8, 38, 22); poster(cc, W * 0.62 - 8, 6, 14, 18, '#3d78be'); }
        else { roller(cc, 8, 5, 56, 33); neon(cc, 76, 7, W - 90, 14, 'LUMORA', pal.acc); }
      });
      if (t1) {   // a wall display with live numbers (the team's pride)
        const tv = (cc, W, Hh, T) => {
          const bx = 12, by = 6, bw = 58, bh = 23;
          cc.fillStyle = '#05080f'; cc.fillRect(bx - 1.5, by - 1.5, bw + 3, bh + 3);
          const g = cc.createLinearGradient(0, by, 0, by + bh); g.addColorStop(0, '#0b1f3a'); g.addColorStop(1, '#061226'); cc.fillStyle = g; cc.fillRect(bx, by, bw, bh);
          for (let i = 0; i < 9; i++) {
            const v = 0.3 + 0.4 * (i / 9) + 0.22 * Math.sin(T * 1.6 + i * 0.9), h = bh * 0.7 * v;
            cc.fillStyle = U.rgba(pal.acc, 0.85); cc.fillRect(bx + 4 + i * 6, by + bh - 3 - h, 4, h);
          }
          K.text(cc, 'MRR  $$$', bx + 3, by + 4, 4.4, '#cfeeff', { weight: 700, sp: 0.6 });
        };
        L.part({ t: 'face', f: wr.L, fn: tv });
      } else {
        L.part({ t: 'face', f: wr.L, fn: (cc, W, Hh, T) => {   // the neon sign flickers now and then
          const fl = hash(Math.floor(T * 9), 4, 9) > 0.9 ? 0.25 : 0.55 + 0.25 * Math.sin(T * 2.2);
          cc.globalAlpha = fl; neon(cc, 76, 7, W - 90, 14, 'LUMORA', pal.acc, 9); cc.globalAlpha = 1;
        } });
      }
      L.part({ t: 'lamp', p: P(x0 + 0.25, x0 + 1.0, 36), r: 34, col: '#ffc98a', a: 0.3 });
      // ---- furniture, back to front ----
      const items = [];
      const add = (key, fn) => items.push([key, fn]);
      desks.forEach((d, i) => add(d[0] + d[1] + (along(d) ? 0.4 : 0), () => {
        const al = along(d), dw = al ? 0.62 : 1.15, dd = al ? 1.15 : 0.62;
        const dk = K.bx(c, d[0], d[1], dw, dd, 12, FZ, pal.wood, { shade: false });
        K.sheet(c, al ? dk.R : dk.L, (cc, W, Hh) => { cc.fillStyle = 'rgba(8,10,24,.55)'; cc.fillRect(W * 0.08, 3, W * 0.84, Hh - 3); cc.fillStyle = 'rgba(255,255,255,.14)'; cc.fillRect(0, 0, W, 1.3); });
        const mx = al ? d[0] + 0.1 : d[0] + 0.3, my = al ? d[1] + 0.3 : d[1] + 0.08, mw = al ? 0.08 : 0.5, md = al ? 0.5 : 0.08;
        const mb = K.bx(c, mx, my, mw, md, 9, FZ + 12, pal.dark, { shade: false }), f = al ? mb.R : mb.L;
        K.sheet(c, f, (cc, W, Hh) => codeScreen(cc, W, Hh, i + (t1 ? 3 : 0)));
        o.screens.push([f(0.1, 0.12), f(0.9, 0.12), f(0.9, 0.88), f(0.1, 0.88)]);
        if (al) K.bx(c, d[0] + 0.3, d[1] + 0.35, 0.18, 0.45, 1.2, FZ + 12, A.tri('#cfd9ee'), { shade: false }); else K.bx(c, d[0] + 0.35, d[1] + 0.3, 0.45, 0.18, 1.2, FZ + 12, A.tri('#cfd9ee'), { shade: false });
        K.bx(c, d[0] + dw - 0.22, d[1] + (al ? 0.9 : 0.3), 0.1, 0.1, 3, FZ + 12, A.tri(['#e0603a', '#58c092', '#e8c85a'][i % 3]), { shade: false });
        const s = o.seats[i]; K.bx(c, s[0] - 0.2, s[1] - 0.2, 0.4, 0.4, 7, FZ, pal.dark, { shade: false });
      }));
      const tx = t1 ? E - 0.65 : E - 0.75, ty = x0 + 0.32;
      add(tx + ty + 0.6, () => {   // a server tower with a window of blinking lights
        const sv = K.bx(c, tx, ty, 0.6, 0.6, 26, FZ, pal.dark);
        K.sheet(c, sv.L, (cc, W, Hh) => { for (let k = 0; k < 5; k++) { cc.fillStyle = 'rgba(255,255,255,.06)'; cc.fillRect(2, 2 + k * 4.4, W - 4, 3.4); cc.fillStyle = 'rgba(8,12,24,.7)'; cc.fillRect(3, 3 + k * 4.4, W - 9, 1.4); } });
        const z = FZ + 22; o.ledPts = [P(tx + 0.5, ty + 0.6, z), P(tx + 0.5, ty + 0.6, z - 4.4), P(tx + 0.5, ty + 0.6, z - 8.8), P(tx + 0.5, ty + 0.6, z - 13.2)];
        L.part({ t: 'glow', p: P(tx + 0.3, ty + 0.3, FZ + 14), r: 20, col: pal.acc, a: 0.16, pulse: 1.4 });
      });
      // the coffee corner
      const cx = t1 ? 4.9 : 4.55, cy = t1 ? 4.0 : 4.85;
      add(cx + cy + 0.5, () => {
        K.bx(c, cx, cy, 0.7, 0.45, 9, FZ, A.tri('#c9b79a'));
        K.bx(c, cx + 0.1, cy + 0.05, 0.3, 0.3, 7, FZ + 9, A.tri('#2a3350'));
        const t = P(cx + 0.25, cy + 0.2, FZ + 17); L.part({ t: 'steam', p: [t[0], t[1]], n: 3, rise: 16, size: 3, a: 0.5 });
      });
      if (!t1) {   // the garage: a bean bag with a cat on it, a skateboard, a stack of boxes
        add(2.25 + 4.55, () => {
          const p = P(2.3, 4.75, FZ + 1);
          const g = c.createRadialGradient(p[0] - 4, p[1] - 8, 2, p[0], p[1] - 4, 17); g.addColorStop(0, '#ff9f8a'); g.addColorStop(1, '#a8403a');
          c.fillStyle = g; c.beginPath(); c.ellipse(p[0], p[1] - 4, 15, 9, 0, 0, TAU); c.fill();
          c.fillStyle = 'rgba(0,0,0,.14)'; c.beginPath(); c.ellipse(p[0] + 3, p[1] - 3, 8, 3.5, 0, 0, TAU); c.fill();
          c.fillStyle = '#d99a52'; c.beginPath(); c.ellipse(p[0] - 1, p[1] - 11.5, 6, 3.4, 0, 0, TAU); c.fill();    // the cat, curled up
          c.beginPath(); c.arc(p[0] + 4.6, p[1] - 12.4, 2.6, 0, TAU); c.fill();
          c.beginPath(); c.moveTo(p[0] + 3, p[1] - 14.4); c.lineTo(p[0] + 3.4, p[1] - 17); c.lineTo(p[0] + 5, p[1] - 15); c.moveTo(p[0] + 5.2, p[1] - 15); c.lineTo(p[0] + 6.6, p[1] - 17); c.lineTo(p[0] + 6.8, p[1] - 14.4); c.fill();
          c.strokeStyle = '#a8703a'; c.lineWidth = 1; c.beginPath(); c.moveTo(p[0] - 6, p[1] - 11); c.quadraticCurveTo(p[0] - 9, p[1] - 8, p[0] - 4, p[1] - 7); c.stroke();
        });
        add(5.3 + 3.0, () => { K.crates(c, 5.1, 3.0, '#a8793f', FZ); });
        add(3.3 + 3.2, () => {   // a skateboard on the rug
          poly(c, [P(3.35, 3.25, FZ + 0.6), P(4.15, 3.25, FZ + 0.6), P(4.15, 3.5, FZ + 0.6), P(3.35, 3.5, FZ + 0.6)], '#e0603a', 'rgba(0,0,0,.4)');
          for (const wx of [3.5, 4.0]) for (const wy of [3.3, 3.45]) { const p = P(wx, wy, FZ + 0.5); c.fillStyle = '#f2f2f2'; c.beginPath(); c.arc(p[0], p[1] + 0.6, 1.1, 0, TAU); c.fill(); }
        });
      } else {      // the office: a meeting pod behind glass and a sofa
        const px = E - 1.5, py = E - 1.5;
        add(px + py + 0.2, () => {
          poly(c, [P(px, py, FZ), P(px + 1.4, py, FZ), P(px + 1.4, py + 1.4, FZ), P(px, py + 1.4, FZ)], 'rgba(160,120,255,.26)', 'rgba(210,190,255,.6)');
          for (const q of [[P(px, py, FZ), P(px, py + 1.4, FZ), P(px, py + 1.4, FZ + 17), P(px, py, FZ + 17)], [P(px, py, FZ), P(px + 1.4, py, FZ), P(px + 1.4, py, FZ + 17), P(px, py, FZ + 17)]]) {
            poly(c, q, 'rgba(170,205,255,.16)', 'rgba(225,238,255,.6)');
            c.strokeStyle = 'rgba(255,255,255,.22)'; c.lineWidth = 1; c.beginPath(); c.moveTo(U.lerp(q[0][0], q[1][0], 0.3), U.lerp(q[0][1], q[1][1], 0.3)); c.lineTo(U.lerp(q[3][0], q[2][0], 0.55), U.lerp(q[3][1], q[2][1], 0.55)); c.stroke();
          }
          K.bx(c, px + 0.1, py + 0.55, 0.28, 0.28, 6, FZ, pal.dark, { shade: false });
          K.bx(c, px + 0.55, py + 0.12, 0.28, 0.28, 6, FZ, pal.dark, { shade: false });
          A.cyl(c, px + 0.7, py + 0.7, 0.36, 10, FZ, A.tri('#cfd9ee'));
          K.bx(c, px + 1.05, py + 0.55, 0.28, 0.28, 6, FZ, pal.dark, { shade: false });
          K.bx(c, px + 0.55, py + 1.05, 0.28, 0.28, 6, FZ, pal.dark, { shade: false });
        });
        add(2.5 + 4.9, () => {   // a sofa against the left wall's front end
          K.bx(c, 1.65, 5.05, 0.75, 1.05, 6, FZ, A.tri('#5a6fa8'));
          K.bx(c, 1.65, 5.05, 0.2, 1.05, 12, FZ, A.tri('#5a6fa8'));
          K.bx(c, 1.7, 6.1, 0.65, 0.08, 1, FZ, pal.dark, { shade: false });
        });
      }
      const ppx = t1 ? E - 0.55 : E - 0.65, ppy = t1 ? 3.1 : E - 0.65;
      add(ppx + ppy + 0.3, () => {   // a plant in a pot
        const px = ppx, py = ppy;
        K.bx(c, px, py, 0.34, 0.34, 6, FZ, A.tri('#5a3d2c'));
        const p = P(px + 0.17, py + 0.17, FZ + 8); A.tree(c, p[0], p[1], 0.62, '#43b283');
      });
      items.sort((a, b) => a[0] - b[0]).forEach((it) => it[1]());
      // ---- string lights along the wall tops ----
      const zt = FZ + H - 2, pts = [], bulbs = [];
      const wire = [P(x0, E, zt), P(x0, x0 + sz * 0.5, zt), P(x0, x0, zt), P(x0 + sz * 0.5, x0, zt), P(E, x0, zt)];
      for (let s = 0; s < wire.length - 1; s++) {
        const a = wire[s], b = wire[s + 1];
        c.strokeStyle = 'rgba(255,255,255,.28)'; c.lineWidth = 1; c.beginPath(); c.moveTo(a[0], a[1]); c.quadraticCurveTo((a[0] + b[0]) / 2, (a[1] + b[1]) / 2 + 12, b[0], b[1]); c.stroke();
        for (let i = 1; i < 4; i++) { const t = i / 4; bulbs.push([U.lerp(a[0], b[0], t), U.lerp(a[1], b[1], t) + Math.sin(t * Math.PI) * 6]); }
      }
      L.part({ t: 'bulbs', pts: bulbs, cols: ['#ffd27a', '#ff9fc2', '#8fe9ff', '#b8ff9f'] });
    };
    return o;
  }


  /* ---------- closed buildings: shared pieces ---------- */
  const TOWERS = {};
  // a lit room behind a big pane of glass (shop fronts, lobbies)
  function pane(cc, pal, x, y, w, h, lit, seed, glass) {
    if (lit) {
      const g = cc.createLinearGradient(0, y, 0, y + h); g.addColorStop(0, U.rgba(pal.lamp, 0.95)); g.addColorStop(1, U.rgba(pal.lamp, 0.62));
      cc.fillStyle = g; cc.fillRect(x, y, w, h);
      cc.fillStyle = 'rgba(40,24,10,.3)'; cc.fillRect(x, y + h * 0.72, w, h * 0.28);
      if (hash(seed, 1, 5) > 0.35) cc.fillRect(x + w * (0.2 + hash(seed, 2, 5) * 0.5), y + h * 0.3, Math.max(1.4, w * 0.1), h * 0.7);
      return;
    }
    cc.fillStyle = 'rgba(6,10,24,.92)'; cc.fillRect(x - 1, y - 1, w + 2, h + 2);
    const g = cc.createLinearGradient(0, y, 0, y + h); g.addColorStop(0, glass[0]); g.addColorStop(1, glass[1]);
    cc.fillStyle = g; cc.fillRect(x, y, w, h);
    cc.fillStyle = 'rgba(255,255,255,.16)'; cc.beginPath(); cc.moveTo(x + w * 0.1, y + h); cc.lineTo(x + w * 0.4, y + h); cc.lineTo(x + w * 0.85, y); cc.lineTo(x + w * 0.55, y); cc.fill();
  }
  // a line of neon along an edge: dim by day, bright in the lit pass
  const edgeGlow = (L, c, pts, hex, w) => L.draw(c, (cc, lit) => { cc.lineJoin = 'round'; line(cc, pts, U.rgba(hex, lit ? 0.95 : 0.5), lit ? (w || 1.6) + 0.6 : w || 1.6); });

  /* ---------- tier 2: the office block ---------- */
  TOWERS[2] = function (pal) {
    const X = 1.4, S = 4.4, E = X + S, Z = 3, H = 78, T = Z + H, gnd = 26, Lc = K.lights(pal);
    const o = base(2, [X, X, S, S, 84], A.bbox(0.5, 0.5, 6.1, 6.1, 106, 10), A.bbox(X, X, S, S, H + 26, 8));
    const L = K.rig(o), darkL = [], darkR = [];
    const glass = [K.hex(pal.glassHex, 1.55), K.hex(pal.glassHex, 0.55)];
    const patL = K.pattern(pal, 11, 0.36, 0.14), patR = K.pattern(pal, 23, 0.4, 0.14);
    o.entry = P(X + S * 0.5, E + 0.4);
    o.glow = [{ p: P(3.6, 3.6, 92), r: 36, c: pal.acc, a: 0.22 }];
    const face = (cc, W, Hh, lit, front) => {
      const mx = 9, cols = 5, rows = 3, b = gnd + 3, t = 6, ch = (Hh - b - t) / rows;
      if (!lit) {
        cc.fillStyle = 'rgba(255,255,255,.1)';
        for (let k = 0; k <= cols; k++) cc.fillRect(mx + (k * (W - mx * 2)) / cols - 1.1, 0, 2.2, Hh - gnd);
        for (let j = 0; j <= rows; j++) { const y = Hh - b - j * ch; cc.fillStyle = 'rgba(255,255,255,.11)'; cc.fillRect(0, y - 0.6, W, 1.2); cc.fillStyle = 'rgba(0,0,0,.2)'; cc.fillRect(0, y + 0.6, W, 1); }
        cc.fillStyle = 'rgba(255,255,255,.18)'; cc.fillRect(0, 0, W, 2.2); cc.fillStyle = 'rgba(0,0,0,.3)'; cc.fillRect(0, 2.2, W, 1.8);
        cc.fillStyle = 'rgba(8,14,32,.34)'; cc.fillRect(0, Hh - gnd, W, gnd);
        cc.fillStyle = 'rgba(255,255,255,.22)'; cc.fillRect(0, Hh - gnd, W, 1.2);
      }
      K.punched(cc, W, Hh, { cols, rows, mx, b, t, pw: 0.7, ph: 0.6, glass, on: front ? patL : patR, seed: front ? 11 : 23, mull: true, out: front ? darkL : darkR }, lit);
      const y0 = Hh - gnd + 3, hh = gnd - 5;
      if (front) {
        const dx = W * 0.5, bw = (dx - 14 - 6) / 2;
        for (let side = 0; side < 2; side++) for (let i = 0; i < 2; i++) pane(cc, pal, (side ? dx + 14 : 6) + i * bw + 1, y0 + 6, bw - 2, hh - 7, lit, 31 + side * 2 + i, glass);
        K.door(cc, dx - 8, Hh - 19, 16, 18, lit, glass);
      } else {
        for (let i = 0; i < 3; i++) pane(cc, pal, 8 + i * (W * 0.19), y0 + 3, W * 0.19 - 3, hh - 3, lit, 41 + i, glass);
        if (!lit) {   // a loading door with ribs
          const x = W * 0.66, w = W * 0.26; cc.fillStyle = 'rgba(6,10,24,.9)'; cc.fillRect(x - 1, Hh - 20, w + 2, 19);
          for (let k = 0; k < 6; k++) { cc.fillStyle = k % 2 ? '#7f8eb2' : '#93a2c4'; cc.fillRect(x, Hh - 19 + k * 3, w, 2.6); }
          cc.fillStyle = 'rgba(255,200,60,.9)'; cc.fillRect(x, Hh - 3, w, 1.6);
        }
      }
      // the lit corner: a strip of light running up the front edge
      cc.fillStyle = U.rgba(pal.acc, lit ? 0.95 : 0.38); cc.fillRect(front ? W - 1.8 : 0, 0, 1.8, Hh - 1);
    };
    o.draw = (c) => {
      L.begin(); darkL.length = 0; darkR.length = 0;
      K.shadow(c, 0.7, 0.7, 5.8, 5.8, 0.5, 0.5);
      K.slab(c, 0.9, 0.9, 5.4, 5.4, Z, pal.concrete, { accent: pal.acc });
      poly(c, [P(3.05, E, Z), P(4.15, E, Z), P(4.15, 6.3, Z), P(3.05, 6.3, Z)], 'rgba(255,255,255,.1)');
      const b = K.bx(c, X, X, S, S, H, Z, pal.wall);
      L.sheet(c, b.L, (cc, W, Hh, lit) => face(cc, W, Hh, lit, true));
      L.sheet(c, b.R, (cc, W, Hh, lit) => face(cc, W, Hh, lit, false));
      { const sz = K.size(b.L), sx = sz[0] * 0.5 - 21, sy = sz[1] - gnd + 1.5; K.cutRect(L, b.L, sx, sy, 42, 7.5); L.sign(c, b.L, (cc, W, Hh, lit) => K.plate(cc, sx, sy, 42, 7.5, 'LUMORA', pal.acc, lit, { size: 4.8, sp: 0.9 })); }
      K.twinkle(L, b.L, darkL, Lc.warm, 5, 2); K.twinkle(L, b.R, darkR, Lc.warm, 5, 3);
      // ---- the roof ----
      K.roof(c, X, X, S, S, T, pal.roof);
      edgeGlow(L, c, [P(X, E, T), P(E, E, T), P(E, X, T)], pal.acc, 1.5);
      const pen = K.bx(c, 1.8, 1.8, 1.4, 1.2, 10, T, pal.metal);
      K.sheet(c, pen.L, (cc, W, Hh) => { cc.fillStyle = 'rgba(6,10,24,.8)'; cc.fillRect(W * 0.3, Hh * 0.3, W * 0.4, Hh * 0.7); cc.fillStyle = U.rgba(pal.acc, 0.8); cc.fillRect(W * 0.3, Hh * 0.22, W * 0.4, 1.4); });
      K.hvac(c, L, pal, 3.9, 1.8, T, 1.2, 0.9, 6);
      K.antenna(c, L, 5.25, 2.0, T, 24, '#ff4d5e');
      K.tank(c, 2.2, 3.4, T, 0.36, 12, '#a8bad9');
      K.hvac(c, L, pal, 3.5, 3.3, T, 1.0, 0.8, 5);
      const vs = P(4.7, 4.3, T);
      c.fillStyle = '#8da0c6'; c.fillRect(vs[0] - 2.6, vs[1] - 9, 5.2, 9); c.fillStyle = '#31405f'; ell(c, vs[0], vs[1] - 9, 3.2, 1.6); c.fill();
      L.part({ t: 'steam', p: [vs[0], vs[1] - 10], n: 3, rise: 28, size: 4, a: 0.35 });
      K.solar(c, 2.0, 4.5, T, 1.8, 1.0, 2);
      const fp = P(5.45, 5.3, T), ft = P(5.45, 5.3, T + 28);
      line(c, [fp, ft], '#cfd9ee', 1.4); L.part({ t: 'flag', p: [ft[0] + 1, ft[1]], col: pal.acc, w: 14, h: 7 });
      // ---- the plaza ----
      for (const [px, py] of [[1.05, 6.1], [6.1, 6.1], [6.1, 1.05]]) K.lamp(c, L, px, py, 18, pal.lamp, Z);
      K.planter(c, 2.1, 6.0, 0.8, 0.26, '#58c092', Z, '#3b4a6e'); K.planter(c, 4.3, 6.0, 0.8, 0.26, '#58c092', Z, '#3b4a6e');
      K.bench(c, 1.4, 6.0, 0.7, Z);
      K.bench(c, 5.25, 6.0, 0.7, Z);
      L.part({ t: 'lamp', p: P(X + S * 0.5, E + 0.1, 14), r: 34, col: pal.lamp, a: 0.42 });
    };
    return o;
  };

  /* ---------- tier 3: the corporate tower ---------- */
  TOWERS[3] = function (pal) {
    const PX = 1, PS = 5, PE = PX + PS, PZ = 3, PH = 19, ZT = PZ + PH;            // the podium
    const X = 1.85, S = 3.3, E = X + S, H = 124, T = ZT + H, Lc = K.lights(pal);   // the tower on top of it
    const o = base(3, [1, 1, 5, 5, 150], A.bbox(0.5, 0.5, 6.1, 6.1, 184, 10), A.bbox(1, 1, 5, 5, 186, 8));
    const L = K.rig(o), darkP = [], darkL = [], darkR = [];
    const glass = [K.hex(pal.glassHex, 1.6), K.hex(pal.glassHex, 0.5)];
    const patP = K.pattern(pal, 4, 0.2, 0.1), patL = K.pattern(pal, 3, 0.42, 0.16), patR = K.pattern(pal, 6, 0.45, 0.16);
    o.entry = P(PX + PS * 0.5, PE + 0.4);
    o.glow = [{ p: P(3.5, 3.5, 138), r: 44, c: pal.acc, a: 0.2 }];
    const podium = (cc, W, Hh, lit, front) => {
      K.curtain(cc, W, Hh, { cols: front ? 10 : 9, rows: 1, ix: 3, b: 1, t: 4, glass, k: front ? 1 : 0.8, on: patP, seed: front ? 4 : 5, band: 0.14, out: front ? darkP : null }, lit);
      if (!lit) { cc.fillStyle = 'rgba(255,255,255,.22)'; cc.fillRect(0, 0, W, 2.4); cc.fillStyle = 'rgba(0,0,0,.28)'; cc.fillRect(0, 2.4, W, 1.6); }
      cc.fillStyle = U.rgba(pal.acc, lit ? 0.95 : 0.45); cc.fillRect(0, 0, W, 1.2);
      if (front) { K.door(cc, W / 2 - 9, Hh - 15, 18, 14, lit, glass); }
    };
    const shaft = (cc, W, Hh, lit, front) => {
      const cols = 6, rows = 10;
      K.curtain(cc, W, Hh, { cols, rows, ix: 2, b: 2, t: 5, glass, k: front ? 1 : 0.78, on: front ? patL : patR, seed: front ? 3 : 6, band: 0.2, out: front ? darkL : darkR }, lit);
      // two belts of light and the lit corner
      for (const j of [3, 7]) { const y = Hh - 2 - (j * (Hh - 7)) / rows; cc.fillStyle = U.rgba(pal.acc, lit ? 0.9 : 0.32); cc.fillRect(2, y - 0.8, W - 4, 1.6); }
      cc.fillStyle = U.rgba(pal.acc, lit ? 0.95 : 0.4); cc.fillRect(front ? W - 1.6 : 0, 0, 1.6, Hh);
      if (front && !lit) { cc.fillStyle = 'rgba(6,10,24,.5)'; cc.fillRect(W * 0.86, 22, 5, Hh - 26); }   // the lift shaft
    };
    o.draw = (c) => {
      L.begin(); darkP.length = 0; darkL.length = 0; darkR.length = 0;
      K.shadow(c, 0.7, 0.7, 5.8, 5.8, 0.5, 0.5);
      K.slab(c, 0.8, 0.8, 5.4, 5.4, PZ, pal.concrete, { accent: pal.acc });
      poly(c, [P(3.05, PE, PZ), P(3.95, PE, PZ), P(3.95, 6.2, PZ), P(3.05, 6.2, PZ)], 'rgba(255,255,255,.1)');
      const pb = K.bx(c, PX, PX, PS, PS, PH, PZ, pal.wall);
      L.sheet(c, pb.L, (cc, W, Hh, lit) => podium(cc, W, Hh, lit, true));
      L.sheet(c, pb.R, (cc, W, Hh, lit) => podium(cc, W, Hh, lit, false));
      K.twinkle(L, pb.L, darkP, Lc.warm, 3, 7);
      // the terrace on the podium roof: planters and a rail
      K.roof(c, PX, PX, PS, PS, ZT, pal.roof, { m: 0.1 });
      K.railing(c, PX + 0.05, PX + 0.05, PS - 0.1, PS - 0.1, ZT);
      const tb = K.bx(c, X, X, S, S, H, ZT, pal.glass);
      L.sheet(c, tb.L, (cc, W, Hh, lit) => shaft(cc, W, Hh, lit, true));
      L.sheet(c, tb.R, (cc, W, Hh, lit) => shaft(cc, W, Hh, lit, false));
      { const sz = K.size(tb.L), sx = sz[0] * 0.5 - 28, sy = 9; K.cutRect(L, tb.L, sx, sy, 56, 11); L.sign(c, tb.L, (cc, W, Hh, lit) => K.plate(cc, sx, sy, 56, 11, 'LUMORA', pal.acc, lit, { size: 6.2, sp: 1.2 })); }
      K.twinkle(L, tb.L, darkL, Lc.warm, 6, 8); K.twinkle(L, tb.R, darkR, Lc.warm, 6, 9);
      L.part({ t: 'lift', a: tb.L(0.88, 0.04), b: tb.L(0.88, 0.9), per: 11, col: '#fff2c4' });
      K.planter(c, 1.95, 5.5, 3.1, 0.28, '#58c092', ZT, '#3b4a6e');
      K.planter(c, 5.5, 1.95, 0.28, 3.1, '#58c092', ZT, '#3b4a6e');
      for (const [tx, ty] of [[1.35, 5.65], [5.65, 5.65], [5.65, 1.35]]) { const p = P(tx, ty, ZT); A.tree(c, p[0], p[1], 0.5, '#43b283'); }
      // ---- the crown: a rooftop garden, a glass pavilion, a mast, a dish ----
      K.bx(c, 1.7, 1.7, 3.6, 3.6, 4, T, pal.concrete);
      K.roof(c, 1.7, 1.7, 3.6, 3.6, T + 4, pal.roof, { m: 0.1 });
      edgeGlow(L, c, [P(1.7, 5.3, T + 4), P(5.3, 5.3, T + 4), P(5.3, 1.7, T + 4)], pal.acc, 1.5);
      const gz = T + 4;
      K.bx(c, 2.05, 2.05, 1.1, 1.0, 4, gz, A.tri('#2f6a55')); K.bx(c, 3.6, 3.7, 1.1, 1.0, 4, gz, A.tri('#2f6a55'));
      const t1 = P(2.6, 2.55, gz + 4), t2 = P(4.15, 4.2, gz + 4);
      A.tree(c, t1[0], t1[1], 0.55, '#43b283'); A.tree(c, t2[0], t2[1], 0.5, '#58c092');
      K.skylight(c, 3.55, 2.15, gz, 1.1, 1.0, '#9be7ff');
      K.antenna(c, L, 2.95, 4.2, gz, 34, '#ff4d5e', { bars: [0.5, 0.74] });
      K.dish(c, 4.7, 2.35, gz, 4.5, { h: 8 });
      L.part({ t: 'lamp', p: P(PX + PS * 0.5, PE + 0.1, 14), r: 36, col: pal.lamp, a: 0.42 });
      for (const [px, py] of [[1.0, 6.15], [6.15, 6.15], [6.15, 1.0]]) K.lamp(c, L, px, py, 18, pal.lamp, PZ);
    };
    return o;
  };

  /* ---------- tier 4: the Spire ---------- */
  TOWERS[4] = function (pal) {
    const o = base(4, [1, 1, 5, 5, 205], A.bbox(0.4, 0.4, 6.2, 6.2, 250, 10), A.bbox(1, 1, 5, 5, 240, 8));
    const L = K.rig(o), Lc = K.lights(pal);
    const tiers = [{ x: 1.4, s: 4.2, h: 64, z: 16, cols: 6, rows: 6, seed: 5 }, { x: 2.0, s: 3.0, h: 56, z: 80, cols: 4, rows: 6, seed: 7 }, { x: 2.5, s: 2.0, h: 40, z: 136, cols: 3, rows: 5, seed: 9 }];
    const glass = [K.hex(pal.glassHex, 1.15), K.hex(pal.glassHex, 0.3)];
    const cool = (a) => U.rgba('#d8f2ff', a * 0.9), accOn = Lc.acc;
    const pat = (seed) => (i, j) => { const r = hash(i, j, seed); return r < 0.46 ? null : r < 0.86 ? cool : accOn; };
    const dark = tiers.map(() => [[], []]);
    o.glow = [{ p: P(3.5, 3.5, 160), r: 70, c: pal.acc, a: 0.22 }, { p: P(3.5, 3.5, 212), r: 40, c: '#bff7ff', a: 0.25 }];
    o.ringC = P(3.5, 3.5, 150);
    o.entry = P(3.5, 6.35);
    const face = (cc, W, Hh, lit, ti, front) => {
      const t = tiers[ti];
      K.curtain(cc, W, Hh, { cols: t.cols, rows: t.rows, ix: 2, b: ti === 0 ? 3 : 2, t: 4, glass, k: front ? 1 : 0.74, on: pat(t.seed + (front ? 0 : 9)), seed: t.seed, band: 0.22, mull: 'rgba(6,10,28,.85)', out: dark[ti][front ? 0 : 1] }, lit);
      cc.fillStyle = U.rgba(pal.acc, lit ? 0.97 : 0.42); cc.fillRect(front ? W - 1.8 : 0, 0, 1.8, Hh);            // the lit corner
      cc.fillStyle = U.rgba(pal.acc, lit ? 0.9 : 0.4); cc.fillRect(0, 0, W, 1.6);                                   // the lit top edge
      if (ti === 0 && front) {   // the gate: a tall arch with light behind it
        const ax = W * 0.5, aw = 22, ah = 24;
        cc.save();
        cc.beginPath(); cc.moveTo(ax - aw / 2, Hh - 3); cc.lineTo(ax - aw / 2, Hh - 3 - ah + aw / 2); cc.arc(ax, Hh - 3 - ah + aw / 2, aw / 2, Math.PI, 0); cc.lineTo(ax + aw / 2, Hh - 3); cc.closePath();
        if (lit) { const g = cc.createLinearGradient(0, Hh - 3 - ah, 0, Hh - 3); g.addColorStop(0, 'rgba(235,250,255,.98)'); g.addColorStop(1, U.rgba(pal.acc, 0.8)); cc.fillStyle = g; cc.fill(); }
        else { cc.fillStyle = 'rgba(4,8,22,.95)'; cc.fill(); cc.strokeStyle = U.rgba(pal.acc, 0.8); cc.lineWidth = 1.6; cc.stroke(); }
        cc.restore();
      }
    };
    o.draw = (c) => {
      L.begin(); dark.forEach((d) => { d[0].length = 0; d[1].length = 0; });
      K.shadow(c, 0.5, 0.5, 6.0, 6.0, 0.6, 0.55);
      K.slab(c, 0.6, 0.6, 5.8, 5.8, 6, pal.concrete, { accent: pal.acc });
      K.slab(c, 1, 1, 5, 5, 16, pal.concrete, { accent: pal.acc });
      // the plaza lines: light running in to the gate
      c.strokeStyle = U.rgba(pal.acc, 0.5); c.lineWidth = 1.4; c.beginPath();
      for (const u of [-0.55, 0.55]) { const a = P(3.5 + u, 6.0, 6), b = P(3.5 + u, 6.4, 6); c.moveTo(a[0], a[1]); c.lineTo(b[0], b[1]); }
      c.stroke();
      const bs = [];
      tiers.forEach((t, ti) => {
        const b = K.bx(c, t.x, t.x, t.s, t.s, t.h, t.z, pal.glass); bs.push(b);
        K.roof(c, t.x, t.x, t.s, t.s, t.z + t.h, pal.roof, { m: 0.1 });
        L.sheet(c, b.L, (cc, W, Hh, lit) => face(cc, W, Hh, lit, ti, true));
        L.sheet(c, b.R, (cc, W, Hh, lit) => face(cc, W, Hh, lit, ti, false));
        K.twinkle(L, b.L, dark[ti][0], Lc.ice, 4, 10 + ti); K.twinkle(L, b.R, dark[ti][1], Lc.ice, 4, 20 + ti);
        edgeGlow(L, c, [P(t.x, t.x + t.s, t.z + t.h), P(t.x + t.s, t.x + t.s, t.z + t.h), P(t.x + t.s, t.x, t.z + t.h)], pal.acc, 1.6);
      });
      { const sx = K.size(bs[1].L)[0] * 0.5 - 27; K.cutRect(L, bs[1].L, sx, 7, 54, 10); L.sign(c, bs[1].L, (cc, W, Hh, lit) => K.plate(cc, sx, 7, 54, 10, 'LUMORA', pal.acc, lit, { size: 5.8, sp: 1.2 })); }
      // a garden on the first roof, in front of the second tier
      K.planter(c, 2.3, 5.1, 2.6, 0.3, '#58c092', 80, '#3b4a6e');
      K.planter(c, 5.15, 2.4, 0.3, 2.4, '#58c092', 80, '#3b4a6e');
      K.planter(c, 2.75, 4.7, 1.9, 0.26, '#58c092', 136, '#3b4a6e'); K.planter(c, 4.75, 2.9, 0.26, 1.6, '#58c092', 136, '#3b4a6e');
      // the crown: a cap, a needle, and a crystal that floats above it
      K.bx(c, 2.4, 2.4, 2.2, 2.2, 3, 176, pal.metal);
      edgeGlow(L, c, [P(2.4, 4.6, 179), P(4.6, 4.6, 179), P(4.6, 2.4, 179)], '#bff7ff', 1.4);
      const n0 = P(3.5, 3.5, 179), n1 = P(3.5, 3.5, 204);
      c.strokeStyle = '#d5e1fa'; c.lineWidth = 1.6; c.beginPath(); c.moveTo(n0[0], n0[1]); c.lineTo(n1[0], n1[1]); c.stroke();
      c.strokeStyle = U.rgba(pal.acc, 0.9); c.lineWidth = 1; c.beginPath(); c.moveTo(n0[0] + 2, n0[1]); c.lineTo(n1[0] + 0.4, n1[1]); c.stroke();
      const cr = P(3.5, 3.5, 214);
      L.part({ t: 'beam', a: [cr[0], cr[1] - 14], b: [cr[0], cr[1] - 130], col: '#bff7ff', w: 3, spd: 2 });
      L.part({ t: 'rings', p: P(3.5, 3.5, 196), rx: 74, ry: 28, col: pal.acc, spd: 0.3, n: 2, a: 0.55, w: 1.2 });
      L.part({ t: 'crystal', p: cr, h: 19, w: 9, col: pal.acc });
      L.part({ t: 'sat', p: P(3.5, 3.5, 196), rx: 62, ry: 20, spd: 0.4 });
      L.part({ t: 'sat', p: P(3.5, 3.5, 196), rx: 62, ry: 20, spd: 0.4, ph: Math.PI });
      // lights climbing the three corners
      const climb = (ax, ay, col, ph) => {
        const q = (n, z) => P(ax(n), ay(n), z);
        L.part({ t: 'chase', pts: [q(0, 16), q(0, 80), q(1, 80), q(1, 136), q(2, 136), q(2, 176)], n: 3, spd: 0.2, ph, col, size: 1.8, glow: 11 });
      };
      climb((n) => [5.6, 5.0, 4.5][n], (n) => [5.6, 5.0, 4.5][n], '#bff7ff');
      climb((n) => [1.4, 2.0, 2.5][n], (n) => [5.6, 5.0, 4.5][n], pal.acc);
      climb((n) => [5.6, 5.0, 4.5][n], (n) => [1.4, 2.0, 2.5][n], pal.acc);
      L.part({ t: 'lamp', p: P(3.5, 6.2, 16), r: 40, col: pal.acc, a: 0.45 });
      for (const [px, py] of [[0.85, 6.15], [6.15, 6.15], [6.15, 0.85]]) K.lamp(c, L, px, py, 18, pal.lamp, 6);
    };
    return o;
  };

  A.hq = function (tier, pal) { return tier <= 1 ? interior(tier, pal) : TOWERS[tier](pal); };
})();
