/* AI Empire Tycoon - company stories and milestones.
   Every few minutes something happens to the company: a viral video, an investor visit, a heatwave. A story is a short card that slides in
   over the game and never blocks it. Lumo decides by himself, in character, and the outcome (a timed boost, some cash, a little hype)
   applies at once. With autopilot off the card waits for the player and decides for them after a while, so nothing is ever stuck.
   Milestones (users, company value) set off a celebration: banner, fireworks, confetti, northern lights.
   Data first: a new story is one more entry in EVENTS. */
(function () {
  'use strict';
  const G = window.G, U = G.U, h = U.h;
  const St = (G.story = {});

  /* ---------- the stories ---------- */
  // kind: 'good' | 'bad' | 'ask' (a choice). w: how often. when(s, C): can it happen now.
  // opts: what can be done. run(x) applies the outcome and returns one sentence for the card.
  //       x = { s, C, m (the model people use), pay (about 90 seconds of profit, never under 2,500) }.
  // lumo(style, x): which option Lumo picks (cautious / balanced / bold). def: the option picked for a player who does not answer.
  const boost = (id, name, icon, secs, eff, good) => G.addBuff({ id, name, icon, secs, eff, good: good !== false });
  const dur = (secs) => (secs >= 120 ? Math.round(secs / 60) + ' minutes' : Math.round(secs) + ' seconds');
  const hype = (s, v) => { s.hype = U.clamp(s.hype + v, 0, 4); };
  const EVENTS = [
    { id: 'viral', kind: 'good', icon: 'sparkle', title: 'Gone viral', w: 3,
      text: (x) => 'A popular creator made a video about ' + x.m.name + '. Sign-ups are pouring in.',
      opts: [{ label: 'Ride the wave', run: (x) => { boost('viral', 'Viral video', 'users', 90, { growth: 0.8 }); hype(x.s, 0.4); return 'Growth is up for ' + dur(90) + '.'; } }] },
    { id: 'press', kind: 'good', icon: 'doc', title: 'Cover story', w: 2,
      text: (x) => x.m.name + ' made the cover of a big tech magazine.',
      opts: [{ label: 'Enjoy the fame', run: (x) => { boost('press', 'Cover story', 'doc', 150, { appeal: 0.2 }); hype(x.s, 0.5); return 'More people want to try it for ' + dur(150) + '.'; } }] },
    { id: 'grant', kind: 'good', icon: 'research', title: 'Research grant', w: 2,
      text: () => 'A university picked the company as its research partner and sent a grant.',
      opts: [{ label: 'Accept the grant', run: (x) => { x.s.cash += x.pay * 1.5; boost('grant', 'Fresh ideas', 'research', 120, { resSpeed: 0.15 }); return '+' + U.money(x.pay * 1.5) + ' and faster research for ' + dur(120) + '.'; } }] },
    { id: 'devcon', kind: 'good', icon: 'ai', title: 'Developer conference', w: 2,
      when: (s, C) => C.st && C.st.api,
      text: () => 'Lumo gave a talk and developers lined up to build on the API.',
      opts: [{ label: 'Wave to the crowd', run: () => { boost('devcon', 'API buzz', 'ai', 120, { api: 0.5 }); return 'API income is up for ' + dur(120) + '.'; } }] },
    { id: 'award', kind: 'good', icon: 'trophy', title: 'Industry award', w: 2,
      text: () => 'The company won “AI of the Year”. Customers like a winner.',
      opts: [{ label: 'Hold the trophy', run: () => { boost('award', 'Award winner', 'trophy', 180, { revMul: 0.12 }); return 'Revenue is up for ' + dur(180) + '.'; } }] },
    { id: 'fan', kind: 'good', icon: 'sparkle', title: 'Fan art', w: 1.5,
      text: () => 'Fans drew Lumo as a superhero. He is blushing.',
      opts: [{ label: 'Say thanks', run: (x) => { boost('fan', 'Fan love', 'sparkle', 90, { appeal: 0.1 }); hype(x.s, 0.3); G.ceo.react('excited', 4); return 'A little extra buzz for ' + dur(90) + '.'; } }] },
    { id: 'coffee', kind: 'good', icon: 'research', title: 'Coffee delivery', w: 1.5,
      text: () => 'A grateful customer sent four hundred coffees. The team is buzzing.',
      opts: [{ label: 'Share them out', run: () => { boost('coffee', 'Coffee buzz', 'research', 90, { resSpeed: 0.2, trainSpeed: 0.2 }); return 'Research and training are faster for ' + dur(90) + '.'; } }] },

    { id: 'investor', kind: 'ask', icon: 'cash', title: 'Investor visit', w: 2,
      text: () => 'A venture fund would like to invest. What now?',
      opts: [
        { label: 'Take the money', note: 'Cash now, a little reporting work', run: (x) => { x.s.cash += x.pay * 2.5; boost('reports', 'Reporting', 'doc', 240, { revMul: -0.06 }, false); return '+' + U.money(x.pay * 2.5) + ' now. Revenue −6% for ' + dur(240) + '.'; } },
        { label: 'Stay independent', note: 'Pride and attention', run: (x) => { hype(x.s, 0.3); boost('pride', 'Independent', 'sparkle', 150, { appeal: 0.15 }); return 'The press loves it. More people try it for ' + dur(150) + '.'; } }],
      lumo: (st, x) => (st === 'cautious' ? 0 : st === 'bold' ? 1 : x.s.cash < x.pay * 3 ? 0 : 1), def: 0 },
    { id: 'cloud', kind: 'ask', icon: 'infra', title: 'Cloud partnership', w: 1.5,
      when: (s, C) => C.nServers >= 4,
      text: () => 'A cloud provider offers a deal on computing power.',
      opts: [
        { label: 'Take the discount', note: 'Safe: lower running costs', run: () => { boost('disc', 'Cloud discount', 'infra', 300, { opex: 0.12 }); return 'Running costs −12% for ' + dur(300) + '.'; } },
        { label: 'Go exclusive', note: 'More power, higher bill', run: () => { boost('excl', 'Exclusive deal', 'infra', 240, { cap: 0.2, opex: -0.08 }); return 'Computing power +20%, costs +8% for ' + dur(240) + '.'; } }],
      lumo: (st, x) => (st === 'cautious' ? 0 : st === 'bold' ? 1 : x.C.sr < 1 ? 1 : 0), def: 0 },
    { id: 'poach', kind: 'ask', icon: 'users', title: 'Poaching attempt', w: 1.5,
      when: (s) => Object.keys(s.res.done).length >= 6,
      text: () => 'A rival is trying to hire the lead scientist away.',
      opts: [
        { label: 'Match the offer', note: 'Costs cash, keeps the team happy', run: (x) => { const c = Math.min(x.s.cash * 0.5, x.pay * 0.6); x.s.cash -= c; boost('team', 'Loyal team', 'users', 240, { resSpeed: 0.25 }); return 'Paid ' + U.money(c) + '. Research is faster for ' + dur(240) + '.'; } },
        { label: 'Offer equity', note: 'A gamble: it may or may not work', run: () => { if (Math.random() < 0.65) { boost('team', 'Inspired team', 'users', 300, { resSpeed: 0.4 }); return 'It worked! Research is much faster for ' + dur(300) + '.'; } boost('gap', 'Short-staffed', 'warn', 150, { resSpeed: -0.2 }, false); return 'They left anyway. Research is slower for ' + dur(150) + '.'; } }],
      lumo: (st, x) => (st === 'cautious' ? 0 : st === 'bold' ? 1 : Math.random() < 0.5 ? 0 : 1), def: 0 },
    { id: 'rumor', kind: 'ask', icon: 'warn', title: 'Rival rumours', w: 1,
      when: (s) => s.hype < 2,
      text: () => 'Word is that a rival is about to launch something big.',
      opts: [
        { label: 'Keep building', note: 'Calm and steady', run: () => { boost('focus', 'Laser focus', 'research', 150, { trainSpeed: 0.15 }); return 'Training is faster for ' + dur(150) + '.'; } },
        { label: 'Counter-campaign', note: 'Costs cash, makes noise', run: (x) => { const c = Math.min(x.s.cash * 0.4, x.pay * 0.5); x.s.cash -= c; hype(x.s, 0.7); return 'Spent ' + U.money(c) + ' on ads. Hype is up.'; } }],
      lumo: (st) => (st === 'cautious' ? 0 : st === 'bold' ? 1 : Math.random() < 0.5 ? 0 : 1), def: 0 },

    { id: 'heat', kind: 'bad', icon: 'warn', title: 'Heatwave', w: 1.2,
      when: (s, C) => C.nServers >= 3,
      text: () => 'A heatwave hit the region and the server hall is running warm. Lumo opened every vent.',
      opts: [{ label: 'Open the vents', run: () => { boost('heat', 'Heatwave', 'warn', 60, { cap: -0.1 }, false); return 'Computing power −10% for ' + dur(60) + '.'; } }] },
    { id: 'fibre', kind: 'bad', icon: 'warn', title: 'Cut cable', w: 1.2,
      text: () => 'A digger cut a fibre line. Lumo rerouted the traffic, but a few users bounced.',
      opts: [{ label: 'Reroute', run: () => { boost('fibre', 'Network hiccup', 'warn', 60, { growth: -0.35 }, false); return 'Growth is slower for ' + dur(60) + '.'; } }] },
    { id: 'glitch', kind: 'bad', icon: 'warn', title: 'Funny wrong answer', w: 1,
      text: () => 'A silly wrong answer went around social media. Lumo replied with a friendly joke.',
      opts: [{ label: 'Reply with a joke', run: (x) => { hype(x.s, -0.2); boost('glitch', 'Meme storm', 'warn', 90, { appeal: -0.1 }, false); return 'Slightly less interest for ' + dur(90) + '.'; } }] }
  ];
  St.EVENTS = EVENTS;

  /* ---------- the clock ---------- */
  const rt = (St.rt = { card: null, idle: 0, ms: 0 });
  const quiet = () => !document.querySelector('.launch, .banner') && !document.getElementById('modals').children.length;
  const autopilot = () => !!(G.state.set.lumo && G.ceo && G.ceo.enabled());

  // dt: real seconds. The wait for the next story counts game time, so it is shorter when the game is sped up.
  St.step = function (dt) {
    const s = G.state, C = G.C;
    if (!s || !C || !(dt > 0)) return;
    if (rt.card && rt.card.s0 !== s) drop();   // the company was reinvented or reset: that card belongs to the old one
    if (rt.card) { cardStep(dt); return; }
    rt.idle += dt;
    if (rt.idle < 1) return;
    const k = rt.idle; rt.idle = 0;
    milestones(s, C);
    s.story.next -= k * Math.max(1, s.speed || 1);
    if (s.story.next > 0) return;
    if (!quiet()) { s.story.next = 3; return; }
    const ev = choose(s, C);
    s.story.next = 170 + Math.random() * 190;
    if (ev) open(ev);
  };
  function choose(s, C) {
    const pool = EVENTS.filter((e) => e.id !== s.story.last && (!e.when || e.when(s, C)));
    // never two bad ones in a row
    const list = s.story.bad ? pool.filter((e) => e.kind !== 'bad') : pool;
    let tot = 0; for (const e of list) tot += e.w;
    if (!tot) return null;
    let r = Math.random() * tot;
    for (const e of list) { r -= e.w; if (r <= 0) return e; }
    return list[0] || null;
  }
  function ctx() {
    const s = G.state, C = G.C;
    return { s, C, m: G.D.mmap[s.active] || G.D.models[0], pay: Math.max(2500, Math.max(0, C.net) * 90) };
  }

  /* ---------- the card ---------- */
  function open(ev) {
    const s = G.state, x = ctx(), UI = G.ui;
    const host = document.getElementById('fx');
    if (!host) return;
    s.story.last = ev.id; s.story.n = (s.story.n || 0) + 1; s.story.bad = ev.kind === 'bad' ? 1 : 0;
    const auto = ev.opts.length === 1 || autopilot();
    const av = G.lumo.avatar(30, ev.kind === 'bad' ? 'worried' : 'excited');
    const res = h('div', { class: 'str' }, ev.opts.length > 1 ? (auto ? 'Lumo is thinking it over…' : 'Your call. If you do not answer, Lumo decides.') : (ev.kind === 'bad' ? 'Lumo is on it…' : ''));
    const opts = h('div', { class: 'sto' });
    const buttons = ev.opts.length > 1 ? ev.opts.map((o, i) => h('button', { class: 'sopt', type: 'button', onclick: () => { if (rt.card && rt.card.phase === 'ask' && !rt.card.auto) { G.audio.init(); G.audio.sfx('tap'); decide(i, 'you'); } } }, h('b', {}, o.label), h('span', {}, o.note || ''))) : [];
    buttons.forEach((b) => opts.append(b));
    const el = h('div', { class: 'story ' + ev.kind + (buttons.length ? ' ask' : '') },
      h('div', { class: 'sth' }, h('div', { class: 'sti' }, UI.I(ev.icon, 20)), h('div', { class: 'stb' }, h('div', { class: 'stk' }, ev.kind === 'bad' ? 'COMPANY NEWS · BAD LUCK' : 'COMPANY NEWS'), h('div', { class: 'stt' }, ev.title), h('div', { class: 'sts' }, ev.text(x)))),
      opts, h('div', { class: 'stl' }, av, res));
    host.append(el);
    document.body.classList.add('story-on');
    G.audio.sfx(ev.kind === 'bad' ? 'event_bad' : 'event');
    G.ceo.react(ev.kind === 'bad' ? 'worried' : 'excited', 3);
    rt.card = { ev, el, res, buttons, av, s0: s, phase: 'ask', t: 0, i: -1, auto };
    // Lumo says it out loud as well (the island shows the speech bubble)
    G.ceo.say(ev.kind === 'bad' ? 'Uh-oh: ' + ev.title.toLowerCase() + '.' : ev.title + '!', ev.kind === 'bad' ? 'worried' : 'excited');
  }
  function cardStep(dt) {
    const c = rt.card;
    c.t += dt;
    if (c.phase === 'ask') {
      if (c.ev.opts.length === 1) { if (c.t > 1.1) decide(0, 'lumo'); }
      else if (c.auto) { if (c.t > 2.2) decide(pickFor(c.ev), 'lumo'); }
      else {
        if (!G.state.set.lumo || c.t > 28) decide(c.ev.def || 0, 'time');
        else if (c.t > 0.01 && !c.waiting) { c.waiting = true; c.el.classList.add('wait'); }
      }
    } else if (c.phase === 'done') {
      if (c.t > 5.6) { c.phase = 'out'; c.t = 0; c.el.classList.add('out'); document.body.classList.remove('story-on'); }
    } else if (c.t > 0.5) drop();
  }
  function drop() {
    if (rt.card) rt.card.el.remove();
    rt.card = null;
    document.body.classList.remove('story-on');
  }
  function pickFor(ev) {
    const st = G.state.ceo.style, x = ctx();
    const i = ev.lumo ? ev.lumo(st, x) : 0;
    return U.clamp(i | 0, 0, ev.opts.length - 1);
  }
  // who: 'lumo' | 'you' | 'time' (the player did not answer)
  function decide(i, who) {
    const c = rt.card, s = G.state, x = ctx();
    if (!c || c.phase !== 'ask') return;
    const o = c.ev.opts[i];
    let text = '';
    try { text = o.run(x) || ''; } catch (e) { if (G.err) G.err(e); }
    c.phase = 'done'; c.t = 0; c.i = i;
    c.buttons.forEach((b, j) => { b.disabled = true; b.classList.toggle('pick', j === i); b.classList.toggle('skip', j !== i); });
    c.el.classList.remove('wait'); c.el.classList.add('done');
    const by = who === 'you' ? 'You chose' : who === 'time' ? 'No answer, so Lumo chose' : 'Lumo chose';
    c.res.textContent = '';
    c.res.append(h('div', {}, h('b', {}, c.ev.opts.length > 1 ? by + ': ' + o.label : o.label), h('span', {}, ' ' + text)));
    G.lumo.setMood(c.av, c.ev.kind === 'bad' ? 'worried' : 'happy');
    try { G.ceo.log('event', c.ev.title + (c.ev.opts.length > 1 ? ' · ' + o.label : ''), text); } catch (e) { /* ignore */ }
    G.emit('story', { ev: c.ev, opt: i, who, text });
    if (G.fx) {
      if (c.ev.kind === 'bad') G.fx.shake(260);
      else G.fx.burst(window.innerWidth / 2, 96, ['#8af0e6', '#f6b84a', '#b9aeff'], 18, { speed: 140, size: 9, g: 60 });
    }
    if (G.life && G.life.surge && (c.ev.id === 'viral' || c.ev.id === 'press')) G.life.surge(14);   // a crowd of visitors on the island
    const mood = c.ev.kind === 'bad' ? 'worried' : 'happy';
    setTimeout(() => { try { G.ceo.say(c.ev.opts.length > 1 ? (who === 'lumo' ? 'Decision made: ' + o.label.toLowerCase() + '.' : 'Good choice!') : (c.ev.kind === 'bad' ? 'Handled. Moving on.' : 'Lovely!'), mood); } catch (e) { /* ignore */ } }, 500);
    void s;
  }
  St.active = () => rt.card;
  // Starts a story right now (for testing and for anything that wants to trigger one). False when a card is already up.
  St.fire = function (id) {
    const ev = EVENTS.find((e) => e.id === id);
    if (!ev || rt.card || !G.state) return false;
    open(ev);
    return true;
  };

  /* ---------- timed boosts, as small pills (the HQ screen shows them) ---------- */
  St.pills = function () {
    const UI = G.ui, row = h('div', { class: 'bufrow' });
    let key = '', pills = [];
    const fmt = (sec) => { sec = Math.max(0, Math.ceil(sec)); return Math.floor(sec / 60) + ':' + String(sec % 60).padStart(2, '0'); };
    UI.bind(row, () => {
      const bs = G.state.buffs || [], k = bs.map((b) => b.id).join();
      if (k !== key) {
        key = k; row.textContent = ''; pills = [];
        for (const b of bs) {
          const t = h('b'), bar = UI.bar(b.good ? 'good thin' : 'bad thin');
          row.append(h('div', { class: 'bpill ' + (b.good ? 'good' : 'bad') }, h('div', { class: 'bpr' }, UI.I(b.icon, 13), h('span', {}, b.name), t), bar));
          pills.push({ b, t, bar });
        }
      }
      row.hidden = !bs.length;
      for (const p of pills) { UI.T(p.t, fmt(p.b.left)); UI.setBar(p.bar, p.b.left / p.b.total); }
    });
    return row;
  };

  /* ---------- milestones ---------- */
  // 10^p users, 10^p dollars of company value. Each is celebrated once; a save that is already past them stays quiet.
  const MS = [];
  for (let p = 3; p <= 12; p++) MS.push({ id: 'u' + p, p, kind: 'users', test: (s) => s.users >= Math.pow(10, p), title: U.num(Math.pow(10, p)) + ' users', icon: 'users' });
  for (let p = 6; p <= 15; p++) MS.push({ id: 'v' + p, p, kind: 'value', test: (s, C) => C.val >= Math.pow(10, p), title: 'Worth ' + U.money(Math.pow(10, p)), icon: 'trend' });
  function milestones(s, C) {
    const first = !s.seen.init;
    for (const m of MS) {
      if (s.seen[m.id]) continue;
      let ok = false;
      try { ok = m.test(s, C); } catch (e) { ok = false; }
      if (!ok) continue;
      s.seen[m.id] = 1;
      if (!first) celebrate(m);
    }
    s.seen.init = 1;
  }
  // size 0..2 by how big the number is; a few lines for each
  const SAY = ['Look at that!', 'We did it!', 'Another one for the wall!', 'The team is going wild.'];
  function celebrate(m) {
    const UI = G.ui, big = m.p >= (m.kind === 'users' ? 8 : 11) ? 2 : m.p >= (m.kind === 'users' ? 5 : 8) ? 1 : 0;
    UI.banner(m.icon, m.title, 'MILESTONE');
    G.audio.sfx('ach');
    if (G.fx) { G.fx.confetti([40, 70, 110][big]); if (big) G.fx.show([0, 4, 9][big], [0, 2.4, 4.5][big]); }
    if (G.sky && big) G.sky.boost([0, 6, 12][big]);
    if (G.lumo) G.lumo.party([4, 6, 9][big]);
    try { G.ceo.say(SAY[Math.floor(Math.random() * SAY.length)], 'excited'); G.ceo.log('ach', 'Milestone: ' + m.title, ''); } catch (e) { /* ignore */ }
    G.emit('milestone', { m, big });
  }
  St.celebrate = celebrate;

  // the achievements that are marked "long" are the big ones
  G.on('ach', (o) => { if (o && o.a && o.a.long && G.fx) { G.fx.confetti(60); G.fx.show(3, 2); if (G.lumo) G.lumo.party(5); } });
})();
