/* AI Empire Tycoon - drawing kit for the buildings.
   art.js has the isometric primitives (boxes, cylinders, domes). This file adds what makes a building look built:
   - walls that are shaded from the ground up, and facades that are painted flat and then skewed onto a wall (K.sheet),
     so windows, mullions, signs and screens are easy to draw and read right on a slanted face;
   - a "lit windows" layer per building (K.rig) that the scene fades in at night, so the same drawing works in daylight;
   - roofs, rooftop equipment and ground details (slabs, shadows, lamps, planters, pipes) to put around a building;
   - a list of animated parts (o.parts, see art-live.js) that the building asks for while it is drawn.
   A building is built like this:
       const L = K.rig(o);                      // once, when the object is made
       o.draw = (c) => { L.begin(); ...; L.sheet(c, face, (cc, W, H, lit) => K.punched(cc, W, H, spec, lit)); ...; };
   The sheet function is called twice: once to draw the wall now (lit = false) and once, later, to draw only what glows (lit = true). */
(function () {
  'use strict';
  const G = window.G, U = G.U, A = G.art;
  const P = A.P, poly = A.poly, ell = A.ell, hash = A.hash, box = A.box;
  const K = (A.kit = {});
  const clamp = U.clamp;
  const FONT = '"Inter", system-ui, -apple-system, "Segoe UI", Roboto, sans-serif';

  /* ---------- colours that stay hex (K.punched and K.curtain shade the glass they are given) ---------- */
  const h2 = (x) => Math.max(0, Math.min(255, Math.round(x))).toString(16).padStart(2, '0');
  K.hex = function (hex, k) { const c = U.rgb(hex); return '#' + h2(c[0] * k) + h2(c[1] * k) + h2(c[2] * k); };
  K.hexMix = function (a, b, t) { const x = U.rgb(a), y = U.rgb(b); return '#' + h2(x[0] + (y[0] - x[0]) * t) + h2(x[1] + (y[1] - x[1]) * t) + h2(x[2] + (y[2] - x[2]) * t); };

  /* ---------- faces: paint flat, show skewed ---------- */
  // Calls fn(cc, W, H) with the context set up so that (0,0) is the top-left corner of the face and (W,H) the bottom-right one,
  // in pixels along the face's own edges. Everything drawn there lands on the wall with the right slant.
  K.sheet = function (c, f, fn) {
    const o = f(0, 0), a = f(1, 0), b = f(0, 1);
    const W = Math.hypot(a[0] - o[0], a[1] - o[1]), H = Math.hypot(b[0] - o[0], b[1] - o[1]);
    c.save();
    c.transform((a[0] - o[0]) / W, (a[1] - o[1]) / W, (o[0] - b[0]) / H, (o[1] - b[1]) / H, b[0], b[1]);
    fn(c, W, H);
    c.restore();
  };
  K.size = (f) => { const o = f(0, 0), a = f(1, 0), b = f(0, 1); return [Math.hypot(a[0] - o[0], a[1] - o[1]), Math.hypot(b[0] - o[0], b[1] - o[1])]; };
  const facePts = (f, u0, u1, v0, v1) => [f(u0, v0), f(u1, v0), f(u1, v1), f(u0, v1)];
  K.facePts = facePts;
  // top-to-bottom shading of a whole face (light at the top, dark at the foot): this is what stops a wall from looking flat
  K.faceGrad = function (c, f, top, bot, u0, u1, v0, v1) {
    const p = facePts(f, u0 === undefined ? 0 : u0, u1 === undefined ? 1 : u1, v0 === undefined ? 0 : v0, v1 === undefined ? 1 : v1);
    let y0 = 1e9, y1 = -1e9;
    for (const q of p) { y0 = Math.min(y0, q[1]); y1 = Math.max(y1, q[1]); }
    const g = c.createLinearGradient(0, y0, 0, y1);
    g.addColorStop(0, top); g.addColorStop(1, bot);
    poly(c, p, g);
  };
  K.vgrad = function (c, y0, y1, top, bot, x, w) {   // a vertical gradient as a fill style
    const g = c.createLinearGradient(0, y0, 0, y1);
    g.addColorStop(0, top); g.addColorStop(1, bot);
    return g;
  };

  /* ---------- the lit layer and the animated parts ---------- */
  // Every building gets a rig: L.sheet() draws a face now and remembers it, so the "lit" pass can run the same painter again later
  // and paint only the windows that glow. L.cut() takes lit pixels away again where something stands in front of a lit wall.
  K.rig = function (o) {
    const list = [], cuts = [], lines = [], signs = [];
    o.parts = [];
    const L = {
      begin() { list.length = 0; cuts.length = 0; lines.length = 0; signs.length = 0; o.parts.length = 0; },
      // a sign painted on a wall: like sheet(), but its glow is drawn after the cuts, so it can sit where the windows were cut away
      sign(c, f, fn) { K.sheet(c, f, (cc, W, H) => fn(cc, W, H, false)); signs.push({ f, fn }); },
      // anything drawn straight onto the sprite (not on a wall) that also glows at night: fn(c, lit) runs now with lit = false and again later with lit = true
      draw(c, fn) { fn(c, false); lines.push(fn); },
      sheet(c, f, fn) { K.sheet(c, f, (cc, W, H) => fn(cc, W, H, false)); list.push({ f, fn }); },
      cut(pts) { cuts.push(pts); },
      part(p) { o.parts.push(p); return p; },
      paint(c) {
        for (const e of list) K.sheet(c, e.f, (cc, W, H) => e.fn(cc, W, H, true));
        for (const fn of lines) fn(c, true);
        if (cuts.length) { c.globalCompositeOperation = 'destination-out'; for (const q of cuts) poly(c, q, '#000'); c.globalCompositeOperation = 'source-over'; }
        for (const e of signs) K.sheet(c, e.f, (cc, W, H) => e.fn(cc, W, H, true));
      }
    };
    o.lit = L.paint;
    return L;
  };

  // Take the glow away behind a plate or a sign painted on a lit wall: x, y, w, h are in the face's own pixels.
  K.cutRect = function (L, f, x, y, w, h) {
    const sz = K.size(f), u0 = x / sz[0], u1 = (x + w) / sz[0], v0 = 1 - (y + h) / sz[1], v1 = 1 - y / sz[1];
    L.cut(facePts(f, u0, u1, v0, v1));
  };

  /* ---------- text ---------- */
  K.text = function (cc, str, x, y, size, fill, o) {
    o = o || {};
    cc.font = (o.weight || 800) + ' ' + size + 'px ' + FONT;
    cc.textBaseline = 'middle'; cc.fillStyle = fill;
    const sp = o.sp || 0, al = o.align || 'left';
    if (!sp) { cc.textAlign = al; cc.fillText(str, x, y); return; }
    const chars = Array.from(str), ws = chars.map((ch) => cc.measureText(ch).width);
    let w = sp * (chars.length - 1); for (const v of ws) w += v;
    let px = al === 'center' ? x - w / 2 : al === 'right' ? x - w : x;
    cc.textAlign = 'left';
    chars.forEach((ch, i) => { cc.fillText(ch, px, y); px += ws[i] + sp; });
  };
  const rrect = (cc, x, y, w, h, r) => {
    r = Math.min(r, w / 2, h / 2);
    cc.beginPath(); cc.moveTo(x + r, y); cc.arcTo(x + w, y, x + w, y + h, r); cc.arcTo(x + w, y + h, x, y + h, r); cc.arcTo(x, y + h, x, y, r); cc.arcTo(x, y, x + w, y, r); cc.closePath();
  };
  K.rrect = rrect;

  /* ---------- boxes with some life in them ---------- */
  // A.box plus a shaded wall and a bright corner. Returns the two visible faces so that facades can be painted on them.
  K.bx = function (c, x, y, w, d, h, z0, col, o) {
    z0 = z0 || 0; o = o || {};
    box(c, x, y, w, d, h, z0, col);
    const L = A.fL(x, y, w, d, h, z0), R = A.fR(x, y, w, d, h, z0);
    if (o.shade !== false) {
      K.faceGrad(c, L, 'rgba(255,255,255,.07)', 'rgba(0,0,0,.26)');
      K.faceGrad(c, R, 'rgba(255,255,255,.03)', 'rgba(0,0,0,.30)');
      const a = P(x + w, y + d, z0 + h), b = P(x + w, y + d, z0);
      c.strokeStyle = 'rgba(255,255,255,.2)'; c.lineWidth = 1; c.beginPath(); c.moveTo(a[0], a[1]); c.lineTo(b[0], b[1]); c.stroke();
    }
    return { x, y, w, d, h, z0, L, R, col };
  };
  // The top of a building: a parapet lip, a darker membrane inside it and seams. z = height of the roof surface.
  K.roof = function (c, x, y, w, d, z, col, o) {
    o = o || {};
    const m = o.m === undefined ? 0.13 : o.m;
    const inner = [P(x + m, y + m, z), P(x + w - m, y + m, z), P(x + w - m, y + d - m, z), P(x + m, y + d - m, z)];
    poly(c, inner, o.fill || U.shade(col.hex, 0.86));
    // the parapet throws a thin shadow on the roof along its two far edges
    c.fillStyle = 'rgba(0,0,0,.2)';
    poly(c, [P(x + m, y + m, z), P(x + w - m, y + m, z), P(x + w - m - 0.1, y + m + 0.12, z), P(x + m + 0.12, y + m + 0.12, z), P(x + m + 0.12, y + d - m - 0.1, z), P(x + m, y + d - m, z)], 'rgba(0,0,0,.2)');
    if (o.seams !== false) {
      c.strokeStyle = 'rgba(255,255,255,.05)'; c.lineWidth = 1; c.beginPath();
      for (let u = 1; u < w; u += 1) { const a = P(x + u, y + m, z), b = P(x + u, y + d - m, z); c.moveTo(a[0], a[1]); c.lineTo(b[0], b[1]); }
      c.stroke();
    }
    // bright edge on the front lips
    c.strokeStyle = 'rgba(255,255,255,.3)'; c.lineWidth = 1; c.beginPath();
    const a = P(x, y + d, z), b = P(x + w, y + d, z), e = P(x + w, y, z);
    c.moveTo(a[0], a[1]); c.lineTo(b[0], b[1]); c.lineTo(e[0], e[1]); c.stroke();
  };
  // A paved base with a bevelled lip and joints, so a building stands on something.
  K.slab = function (c, x, y, w, d, h, col, o) {
    o = o || {};
    box(c, x, y, w, d, h, 0, col);
    const jc = o.joint || 'rgba(255,255,255,.06)';
    c.strokeStyle = jc; c.lineWidth = 1; c.beginPath();
    for (let u = 1; u < w; u++) { const a = P(x + u, y, h), b = P(x + u, y + d, h); c.moveTo(a[0], a[1]); c.lineTo(b[0], b[1]); }
    for (let v = 1; v < d; v++) { const a = P(x, y + v, h), b = P(x + w, y + v, h); c.moveTo(a[0], a[1]); c.lineTo(b[0], b[1]); }
    c.stroke();
    K.faceGrad(c, A.fL(x, y, w, d, h, 0), 'rgba(255,255,255,.06)', 'rgba(0,0,0,.25)');
    K.faceGrad(c, A.fR(x, y, w, d, h, 0), 'rgba(255,255,255,.02)', 'rgba(0,0,0,.28)');
    if (o.accent) {   // a thin light strip along the front lip
      c.strokeStyle = U.rgba(o.accent, 0.7); c.lineWidth = 1.2; c.beginPath();
      const a = P(x, y + d, h), b = P(x + w, y + d, h), e = P(x + w, y, h); c.moveTo(a[0], a[1]); c.lineTo(b[0], b[1]); c.lineTo(e[0], e[1]); c.stroke();
    }
  };
  // Soft contact shadow on the ground around a footprint.
  K.shadow = function (c, x, y, w, d, e, a) {
    e = e || 0.7; a = a === undefined ? 0.5 : a;
    for (let i = 4; i >= 1; i--) {
      const g = (e * i) / 4;
      poly(c, [P(x - g, y - g, 0), P(x + w + g, y - g, 0), P(x + w + g, y + d + g, 0), P(x - g, y + d + g, 0)], 'rgba(2,6,18,' + (a * 0.16).toFixed(3) + ')');
    }
  };

  /* ---------- painters for facades (called inside K.sheet, flat, W x H pixels) ---------- */
  const warm = (pal, a) => U.rgba((pal && pal.lamp) || '#ffd28a', a);
  K.warm = warm;
  // A lit pane: a warm gradient with a little furniture in it, so the lights look like rooms and not like tiles.
  function litPane(cc, x, y, w, h, i, j, seed, col, k) {
    k = k === undefined ? 1 : k;
    const g = cc.createLinearGradient(0, y, 0, y + h);
    g.addColorStop(0, col(1 * k)); g.addColorStop(1, col(0.62 * k));
    cc.fillStyle = g; cc.fillRect(x, y, w, h);
    if (w < 6 || h < 6) return;
    const r = hash(i, j, seed + 40);
    cc.fillStyle = 'rgba(40,24,10,.30)';
    if (r < 0.28) cc.fillRect(x, y + h * 0.66, w, h * 0.34);                               // a desk or a counter
    else if (r < 0.45) cc.fillRect(x + w * 0.18, y + h * 0.28, w * 0.16, h * 0.72);        // someone standing
    else if (r < 0.6) { cc.fillRect(x, y, w, h * 0.22); }                                  // blinds half down
    else if (r < 0.7) { cc.fillRect(x + w * 0.62, y + h * 0.5, w * 0.3, h * 0.5); }        // a plant or a cabinet
  }
  // Windows punched into a wall. s: cols, rows, mx (side margin px), b / t (margin at the bottom / top px), pw / ph (pane size as a
  // share of its cell), glass [top, bottom], frame, k (brightness of this wall: the right one is darker),
  // on(i, j) -> colour fn(alpha) or null (j counts from the bottom), seed, mull (a mullion down the middle of each pane).
  K.punched = function (cc, W, H, s, lit) {
    const cols = s.cols, rows = s.rows, mx = s.mx === undefined ? W * 0.06 : s.mx, y0 = s.b === undefined ? H * 0.08 : s.b, y1 = s.t === undefined ? H * 0.08 : s.t;
    const cw = (W - mx * 2) / cols, ch = (H - y0 - y1) / rows, pw = cw * (s.pw || 0.62), ph = ch * (s.ph || 0.58), seed = s.seed || 0, k = s.k === undefined ? 1 : s.k;
    const gl = s.glass || ['#5c8fc4', '#24406e'];
    for (let j = 0; j < rows; j++) for (let i = 0; i < cols; i++) {
      const x = mx + i * cw + (cw - pw) / 2, y = H - y0 - (j + 1) * ch + (ch - ph) / 2;
      const col = s.on ? s.on(i, j) : null;
      if (lit) { if (col) litPane(cc, x, y, pw, ph, i, j, seed, col, 1); continue; }
      if (s.out && !col) s.out.push([x, y, pw, ph]);   // panes that are dark at night: some of them can switch on (K.twinkle)
      cc.fillStyle = s.frame || 'rgba(6,10,24,.9)'; cc.fillRect(x - 1.2, y - 1.2, pw + 2.4, ph + 2.4);
      const g = cc.createLinearGradient(0, y, 0, y + ph);
      g.addColorStop(0, U.shade(gl[0], k)); g.addColorStop(1, U.shade(gl[1], k));
      cc.fillStyle = g; cc.fillRect(x, y, pw, ph);
      if (hash(i, j, seed + 9) > 0.35) {   // a streak of sky in the glass
        cc.fillStyle = 'rgba(255,255,255,.15)';
        cc.beginPath(); cc.moveTo(x + pw * 0.08, y + ph); cc.lineTo(x + pw * 0.34, y + ph); cc.lineTo(x + pw * 0.78, y); cc.lineTo(x + pw * 0.52, y); cc.closePath(); cc.fill();
      }
      if (s.mull) { cc.fillStyle = s.frame || 'rgba(6,10,24,.9)'; cc.fillRect(x + pw / 2 - 0.5, y, 1, ph); }
      cc.fillStyle = 'rgba(255,255,255,.2)'; cc.fillRect(x - 1.5, y + ph + 1.2, pw + 3, 1.3);   // the sill
    }
  };
  // A glass skin: one sheet of glass with a grid of mullions and a darker band for the floor slab at every storey.
  // s: cols, rows, ix (side margin), b / t (margins), glass [top, bottom], mull colour, k, on(i, j) like above, seed, band (slab share of a floor).
  K.curtain = function (cc, W, H, s, lit) {
    const cols = s.cols, rows = s.rows, ix = s.ix || 0, y0 = s.b || 0, y1 = s.t || 0, x1 = W - ix, top = y1, bot = H - y0;
    const cw = (x1 - ix) / cols, ch = (bot - top) / rows, band = (s.band === undefined ? 0.2 : s.band) * ch, seed = s.seed || 0, k = s.k === undefined ? 1 : s.k;
    const gl = s.glass || ['#5c8fc4', '#24406e'];
    if (!lit) {
      const g = cc.createLinearGradient(0, top, 0, bot);
      g.addColorStop(0, U.shade(gl[0], k)); g.addColorStop(1, U.shade(gl[1], k));
      cc.fillStyle = g; cc.fillRect(ix, top, x1 - ix, bot - top);
      // two broad reflections running up the glass
      cc.fillStyle = 'rgba(255,255,255,.10)';
      for (const [a, b] of [[0.18, 0.3], [0.62, 0.68]]) { cc.beginPath(); cc.moveTo(ix + (x1 - ix) * a, bot); cc.lineTo(ix + (x1 - ix) * (a + 0.14), bot); cc.lineTo(ix + (x1 - ix) * (b + 0.14), top); cc.lineTo(ix + (x1 - ix) * b, top); cc.closePath(); cc.fill(); }
      // slab bands (the dark strip at the foot of each floor) and mullions
      cc.fillStyle = 'rgba(4,8,22,.36)';
      for (let j = 0; j < rows; j++) cc.fillRect(ix, bot - j * ch - band, x1 - ix, band);
      cc.fillStyle = s.mull || 'rgba(8,14,32,.8)';
      for (let i = 0; i <= cols; i++) cc.fillRect(ix + i * cw - 0.6, top, 1.2, bot - top);
      for (let j = 0; j <= rows; j++) cc.fillRect(ix, bot - j * ch - 0.7, x1 - ix, 1.4);
      cc.fillStyle = 'rgba(255,255,255,.18)'; for (let j = 1; j <= rows; j++) cc.fillRect(ix, bot - j * ch + 0.9, x1 - ix, 0.8);
      if (s.out) for (let j = 0; j < rows; j++) for (let i = 0; i < cols; i++) if (!(s.on && s.on(i, j))) s.out.push([ix + i * cw + 1, bot - (j + 1) * ch + 1.5, cw - 2, ch - band - 1.5]);
      return;
    }
    if (!s.on) return;
    for (let j = 0; j < rows; j++) for (let i = 0; i < cols; i++) {
      const col = s.on(i, j);
      if (!col) continue;
      litPane(cc, ix + i * cw + 1, bot - (j + 1) * ch + 1.5, cw - 2, ch - band - 1.5, i, j, seed, col, 1);
    }
  };
  // Vertical lines of light (the Spire) / horizontal strips: a plain rectangle of glow for the lit pass, an inset dark channel for the dark pass.
  K.strip = function (cc, x, y, w, h, col, lit) {
    if (lit) { cc.fillStyle = col; cc.fillRect(x, y, w, h); return; }
    cc.fillStyle = 'rgba(4,8,22,.7)'; cc.fillRect(x - 0.6, y - 0.6, w + 1.2, h + 1.2);
  };
  // A name plate: dark plate with a light border and spaced letters. In the lit pass the letters glow.
  K.plate = function (cc, x, y, w, h, str, col, lit, o) {
    o = o || {};
    if (!lit) {
      cc.fillStyle = o.plate || 'rgba(6,10,24,.92)'; rrect(cc, x, y, w, h, Math.min(3, h * 0.25)); cc.fill();
      cc.strokeStyle = U.rgba(col, 0.55); cc.lineWidth = 1; rrect(cc, x + 0.5, y + 0.5, w - 1, h - 1, Math.min(3, h * 0.25)); cc.stroke();
    }
    K.text(cc, str, o.align === 'left' ? x + h * 0.4 : x + w / 2, y + h / 2 + 0.5, o.size || h * 0.55, lit ? col : U.rgba(col, 0.55), { align: o.align === 'left' ? 'left' : 'center', sp: o.sp === undefined ? 1 : o.sp });
  };
  // A glass door with a frame, a lit interior and a push bar (for the lobby).
  K.door = function (cc, x, y, w, h, lit, glass) {
    if (lit) {
      const g = cc.createLinearGradient(0, y, 0, y + h); g.addColorStop(0, 'rgba(255,224,170,.95)'); g.addColorStop(1, 'rgba(255,190,110,.7)');
      cc.fillStyle = g; cc.fillRect(x + 1.5, y + 1.5, w - 3, h - 1.5); return;
    }
    cc.fillStyle = 'rgba(6,10,24,.95)'; cc.fillRect(x, y, w, h);
    const g = cc.createLinearGradient(0, y, 0, y + h); g.addColorStop(0, (glass && glass[0]) || '#6aa0d6'); g.addColorStop(1, (glass && glass[1]) || '#274a7a');
    cc.fillStyle = g; cc.fillRect(x + 1.5, y + 1.5, w - 3, h - 1.5);
    cc.fillStyle = 'rgba(6,10,24,.9)'; cc.fillRect(x + w / 2 - 0.7, y, 1.4, h);
    cc.fillStyle = 'rgba(255,255,255,.55)'; cc.fillRect(x + w / 2 - 3, y + h * 0.5, 1.4, 4); cc.fillRect(x + w / 2 + 1.6, y + h * 0.5, 1.4, 4);
  };

  // Light colours for windows (functions of alpha, as K.punched / K.curtain want them) and the usual patterns of lit rooms.
  K.lights = function (pal) {
    if (pal._lights) return pal._lights;
    return (pal._lights = { warm: (a) => U.rgba(pal.lamp, a), ice: (a) => U.rgba('#bfe6ff', a), acc: (a) => U.rgba(pal.acc, a), pink: (a) => U.rgba('#ffb4d2', a) });
  };
  // on(i, j) for a wall: `off` is the share of rooms that are dark, `ice` the share of the lit ones that glow cool (screens) instead of warm.
  K.pattern = function (pal, seed, off, ice) {
    const Lc = K.lights(pal);
    return (i, j) => { const r = hash(i, j, seed); if (r < off) return null; return hash(i, j, seed + 5) < (ice || 0.12) ? Lc.ice : Lc.warm; };
  };
  // Lets some of the dark windows of a wall switch on and off now and then at night. rects come from the `out` list of K.punched / K.curtain.
  K.twinkle = function (L, f, rects, col, n, seed) {
    if (!rects || !rects.length) return;
    const pick = [];
    for (let k = 0; k < Math.min(n || 4, rects.length); k++) {
      const r = rects[Math.floor(hash(k, rects.length, (seed || 0) + 21) * rects.length)];
      if (r && pick.indexOf(r) < 0) pick.push(r);
    }
    L.part({ t: 'twinkle', f, rects: pick.map((r, k) => ({ r, per: 16 + hash(k, 3, seed || 0) * 22, ph: hash(k, 7, seed || 0) })), col, q: 1 });
  };

  /* ---------- roof equipment ---------- */
  K.hvac = function (c, L, pal, x, y, z, w, d, h) {
    const b = K.bx(c, x, y, w, d, h, z, pal.metal || A.tri('#5f6f92'));
    K.sheet(c, b.L, (cc, W, H) => { cc.fillStyle = 'rgba(6,10,24,.55)'; for (let i = 0; i < 3; i++) cc.fillRect(W * 0.12, H * (0.18 + i * 0.26), W * 0.76, H * 0.12); });
    K.sheet(c, b.R, (cc, W, H) => { cc.fillStyle = 'rgba(6,10,24,.55)'; for (let i = 0; i < 3; i++) cc.fillRect(W * 0.12, H * (0.18 + i * 0.26), W * 0.76, H * 0.12); });
    const p = P(x + w / 2, y + d / 2, z + h), r = Math.min(w, d) * 9;
    ell(c, p[0], p[1], r * 1.25, r * 0.7); c.fillStyle = 'rgba(8,14,30,.85)'; c.fill();
    L.part({ t: 'fan', p, r });
    return b;
  };
  K.tank = function (c, x, y, z, r, h, hex) {
    const col = A.tri(hex || '#9fb3d6');
    const top = A.cyl(c, x, y, r, h, z, col);
    c.strokeStyle = 'rgba(0,0,0,.28)'; c.lineWidth = 1;
    for (const k of [0.3, 0.65]) { const p = P(x, y, z + h * k); c.beginPath(); c.ellipse(p[0], p[1], r * 32 * 1.414, r * 16 * 1.414, 0, 0, Math.PI); c.stroke(); }
    return top;
  };
  K.antenna = function (c, L, x, y, z, h, col, o) {
    o = o || {};
    const a = P(x, y, z), t = P(x, y, z + h);
    c.strokeStyle = o.col || '#aebfe0'; c.lineWidth = o.w || 1.4; c.beginPath(); c.moveTo(a[0], a[1]); c.lineTo(t[0], t[1]); c.stroke();
    c.lineWidth = 1;
    for (const k of o.bars || [0.55, 0.78]) { const p = P(x, y, z + h * k), s = (1 - k) * 12 + 3; c.beginPath(); c.moveTo(p[0] - s, p[1] + s * 0.4); c.lineTo(p[0] + s, p[1] - s * 0.4); c.stroke(); }
    L.part({ t: 'blink', p: [t[0], t[1] - 1], col: col || '#ff4d5e', per: 1.4, ph: o.ph || 0, r: 2, glow: 12 });
    return t;
  };
  // A satellite dish standing on a post (static; art-live.js has a rotating radar for the places that want one).
  K.dish = function (c, x, y, z, r, o) {
    o = o || {};
    const a = P(x, y, z), t = P(x, y, z + (o.h || 10));
    c.strokeStyle = '#8a9cc4'; c.lineWidth = 1.6; c.beginPath(); c.moveTo(a[0], a[1]); c.lineTo(t[0], t[1]); c.stroke();
    c.save(); c.translate(t[0], t[1] - r * 0.3); c.rotate(o.rot === undefined ? -0.5 : o.rot);
    const g = c.createRadialGradient(-r * 0.2, -r * 0.1, 1, 0, 0, r);
    g.addColorStop(0, '#ffffff'); g.addColorStop(1, '#8fa4cf');
    c.fillStyle = g; c.beginPath(); c.ellipse(0, 0, r * 0.6, r, 0, 0, 6.283); c.fill();
    c.strokeStyle = 'rgba(20,30,60,.5)'; c.lineWidth = 1; c.stroke();
    c.strokeStyle = '#cfd9ee'; c.lineWidth = 1.2; c.beginPath(); c.moveTo(0, 0); c.lineTo(r * 0.75, -r * 0.1); c.stroke();
    c.fillStyle = o.feed || '#ff9f6b'; c.beginPath(); c.arc(r * 0.78, -r * 0.1, 1.4, 0, 6.283); c.fill();
    c.restore();
  };
  // Solar panels on a roof: tilted glassy rows with a sheen.
  K.solar = function (c, x, y, z, w, d, n) {
    const n2 = n || 3, gap = d / n2;
    for (let i = 0; i < n2; i++) {
      const yy = y + i * gap + gap * 0.12, hh = gap * 0.76;
      const pts = [P(x, yy, z + 5), P(x + w, yy, z + 5), P(x + w, yy + hh, z + 1.5), P(x, yy + hh, z + 1.5)];
      const g = c.createLinearGradient(pts[0][0], pts[0][1], pts[2][0], pts[2][1]);
      g.addColorStop(0, '#5c9be0'); g.addColorStop(1, '#1d4685');
      poly(c, pts, g, 'rgba(200,225,255,.5)');
      c.strokeStyle = 'rgba(200,225,255,.22)'; c.lineWidth = 1; c.beginPath();
      for (let u = 1; u < 4; u++) { const a = P(x + (w * u) / 4, yy, z + 5), b = P(x + (w * u) / 4, yy + hh, z + 1.5); c.moveTo(a[0], a[1]); c.lineTo(b[0], b[1]); }
      c.stroke();
    }
  };
  K.hedge = function (c, x, y, z, w, d, h, hex) {
    K.bx(c, x, y, w, d, h || 6, z, A.tri(hex || '#2f7a5a'), { shade: true });
    const p = P(x + w / 2, y + d / 2, z + (h || 6));
    c.fillStyle = 'rgba(120,230,170,.25)'; ell(c, p[0], p[1], w * 14, w * 7); c.fill();
  };
  K.railing = function (c, x, y, w, d, z, col) {
    const post = (px, py) => { const a = P(px, py, z), b = P(px, py, z + 7); c.beginPath(); c.moveTo(a[0], a[1]); c.lineTo(b[0], b[1]); c.stroke(); };
    c.strokeStyle = col || 'rgba(210,225,255,.7)'; c.lineWidth = 1;
    for (let u = 0; u <= w + 0.01; u += 0.8) post(x + u, y + d);
    for (let v = 0; v < d; v += 0.8) post(x + w, y + d - v);
    c.beginPath(); const a = P(x, y + d, z + 7), b = P(x + w, y + d, z + 7), e = P(x + w, y, z + 7);
    c.moveTo(a[0], a[1]); c.lineTo(b[0], b[1]); c.lineTo(e[0], e[1]); c.stroke();
  };
  K.skylight = function (c, x, y, z, w, d, hex) {
    const pts = [P(x, y, z + 3), P(x + w, y, z + 3), P(x + w, y + d, z + 1), P(x, y + d, z + 1)];
    poly(c, pts, U.rgba(hex || '#9be7ff', 0.45), 'rgba(255,255,255,.6)');
    c.strokeStyle = 'rgba(255,255,255,.4)'; c.lineWidth = 1; c.beginPath();
    for (let u = 1; u < 3; u++) { const a = P(x + (w * u) / 3, y, z + 3), b = P(x + (w * u) / 3, y + d, z + 1); c.moveTo(a[0], a[1]); c.lineTo(b[0], b[1]); }
    c.stroke();
  };
  K.helipad = function (c, x, y, z, r, col) {
    const p = P(x, y, z + 0.5);
    ell(c, p[0], p[1], r * 45, r * 22.6); c.fillStyle = '#2b3652'; c.fill();
    c.strokeStyle = col || '#ffd28a'; c.lineWidth = 1.5; ell(c, p[0], p[1], r * 40, r * 20); c.stroke();
    c.save(); c.translate(p[0], p[1]); c.scale(1, 0.5); K.text(c, 'H', 0, 0, r * 34, col || '#ffd28a', { align: 'center' }); c.restore();
  };

  // A glass dome standing on a ring of metal: a tinted shell with ribs and a reflection. x, y, z0 = centre on the ground, r in tiles, h in pixels.
  // o.open: the dome roofs a room you can look into, so no floor is painted under it and the rim is only a ring.
  K.glassDome = function (c, x, y, z0, r, h, hex, o) {
    o = o || {};
    const p = P(x, y, z0), rx = r * 45.25, ry = r * 22.6;
    if (o.open) { c.strokeStyle = '#2a3552'; c.lineWidth = 3.2; ell(c, p[0], p[1] + 1, rx + 1, ry + 0.6); c.stroke(); }
    else {
      c.fillStyle = '#2a3552'; ell(c, p[0], p[1] + 2, rx + 2.4, ry + 1.4); c.fill();
      ell(c, p[0], p[1], rx, ry); c.fillStyle = 'rgba(6,14,36,.92)'; c.fill();
    }
    const g = c.createRadialGradient(p[0] - rx * 0.35, p[1] - h * 0.7, 2, p[0], p[1] - h * 0.35, Math.max(rx, h));
    const k = o.open ? 0.75 : 1;
    g.addColorStop(0, U.rgba(hex, 0.85 * k)); g.addColorStop(0.6, U.rgba(hex, 0.36 * k)); g.addColorStop(1, U.rgba(hex, 0.14 * k));
    c.fillStyle = g; c.beginPath(); c.moveTo(p[0] - rx, p[1]); c.ellipse(p[0], p[1], rx, h, 0, Math.PI, Math.PI * 2); c.ellipse(p[0], p[1], rx, ry, 0, 0, Math.PI); c.closePath(); c.fill();
    c.strokeStyle = 'rgba(255,255,255,.3)'; c.lineWidth = 1;
    for (const k of [0.4, 0.74]) { c.beginPath(); c.ellipse(p[0], p[1], rx * k, h, 0, Math.PI, Math.PI * 2); c.stroke(); }
    c.beginPath(); c.moveTo(p[0], p[1] - h); c.lineTo(p[0], p[1] + ry); c.stroke();
    c.beginPath(); c.ellipse(p[0], p[1] - h * 0.5, rx * 0.86, ry * 0.86, 0, 0, Math.PI); c.stroke();
    c.strokeStyle = 'rgba(255,255,255,.6)'; c.lineWidth = 1.3; c.beginPath(); c.ellipse(p[0], p[1], rx, ry, 0, 0, Math.PI); c.stroke();
    c.fillStyle = 'rgba(255,255,255,.22)'; c.beginPath(); c.ellipse(p[0] - rx * 0.42, p[1] - h * 0.6, rx * 0.16, h * 0.28, -0.5, 0, 6.283); c.fill();
  };

  /* ---------- ground details ---------- */
  K.lamp = function (c, L, x, y, h, hex, z0) {
    z0 = z0 || 0;
    const a = P(x, y, z0), t = P(x, y, z0 + (h || 18));
    c.strokeStyle = '#8fa2c8'; c.lineWidth = 1.5; c.beginPath(); c.moveTo(a[0], a[1]); c.lineTo(t[0], t[1]); c.stroke();
    c.fillStyle = '#2b3652'; ell(c, a[0], a[1], 3, 1.5); c.fill();
    c.fillStyle = hex || '#ffe9b8'; c.beginPath(); c.arc(t[0], t[1] - 1, 2, 0, 6.283); c.fill();
    L.part({ t: 'lamp', p: [t[0], t[1] - 1], r: 15, col: hex || '#ffd28a', a: 0.5 });
  };
  K.planter = function (c, x, y, w, d, hex, z0, base) {
    z0 = z0 || 0;
    K.bx(c, x, y, w, d, 4, z0, A.tri(base || '#5a4a40'));
    // shrubs along the long side
    const long = w >= d, z = z0 + 4;
    const a0 = long ? P(x + d / 2, y + d / 2, z) : P(x + w / 2, y + d - w / 2, z), a1 = long ? P(x + w - d / 2, y + d / 2, z) : P(x + w / 2, y + w / 2, z);
    const n = Math.max(2, Math.round((long ? w : d) * 1.8));
    for (let i = 0; i < n; i++) {
      const t = i / (n - 1), px = a0[0] + (a1[0] - a0[0]) * t, py = a0[1] + (a1[1] - a0[1]) * t, r = 5 + (i % 2) * 1.2, k = 0.95 + (i % 3) * 0.12;
      const g = c.createRadialGradient(px - 1, py - 5, 1, px, py - 3, r);
      g.addColorStop(0, U.shade(hex || '#58c092', 1.25 * k)); g.addColorStop(1, U.shade(hex || '#58c092', 0.6 * k));
      c.fillStyle = g; c.beginPath(); c.arc(px, py - 3, r, 0, 6.283); c.fill();
    }
  };
  K.bench = function (c, x, y, w, z0) {
    z0 = z0 || 0;
    K.bx(c, x, y, w || 0.8, 0.28, 3, z0, A.tri('#8b6a4a'), { shade: false });
    K.bx(c, x, y + 0.2, w || 0.8, 0.08, 5, z0 + 3, A.tri('#7a5c3f'), { shade: false });
  };
  K.crates = function (c, x, y, hex, z0) {
    z0 = z0 || 0;
    K.bx(c, x, y, 0.5, 0.5, 6, z0, A.tri(hex || '#a8793f'));
    K.bx(c, x + 0.55, y + 0.1, 0.4, 0.4, 4, z0, A.tri(hex || '#b8894f'));
    K.bx(c, x + 0.1, y + 0.1, 0.34, 0.34, 5, z0 + 6, A.tri('#c9995a'));
  };
  // A pipe or a cable run: a dark stroke with a lighter line on top, through screen points.
  K.pipe = function (c, pts, w, hex, o) {
    o = o || {};
    c.lineJoin = 'round'; c.lineCap = 'round';
    c.strokeStyle = o.dark || 'rgba(4,8,20,.7)'; c.lineWidth = w + 1.6; c.beginPath();
    pts.forEach((p, i) => (i ? c.lineTo(p[0], p[1]) : c.moveTo(p[0], p[1]))); c.stroke();
    c.strokeStyle = hex || '#9fb3d6'; c.lineWidth = w; c.beginPath();
    pts.forEach((p, i) => (i ? c.lineTo(p[0], p[1]) : c.moveTo(p[0], p[1]))); c.stroke();
    c.strokeStyle = 'rgba(255,255,255,.35)'; c.lineWidth = Math.max(0.8, w * 0.28); c.beginPath();
    pts.forEach((p, i) => (i ? c.lineTo(p[0], p[1] - w * 0.22) : c.moveTo(p[0], p[1] - w * 0.22))); c.stroke();
  };
  // A bright glow baked into a sprite (screens, signs): use sparingly, the live layer has proper additive glows.
  K.bake = function (c, x, y, r, hex, a) {
    c.save(); c.globalCompositeOperation = 'lighter'; c.globalAlpha = a; c.drawImage(A.glow(hex), x - r, y - r, r * 2, r * 2); c.restore();
  };
})();
