/* AI Empire Tycoon - Lumo, the AI CEO you can see.
   This file is the character: his drawing and moods, how he flies around the campus, the speech bubbles above him, a small animated
   face for the interface and the control panel (autopilot, style, speed). What Lumo decides lives in ceo.js; this file only shows it. */
(function () {
  'use strict';
  const G = window.G, D = G.D, U = G.U, A = G.art, S = G.scene, h = U.h;
  const Lu = (G.lumo = {});
  const TAU = Math.PI * 2, clamp = U.clamp, lerp = U.lerp;
  const MOOD = { happy: '#4fd6a0', excited: '#f6b84a', thinking: '#8b7cf6', worried: '#ff6b81', sleepy: '#93a3cc', party: '#ff7fa3' };
  Lu.MOOD = MOOD;
  let party = 0;
  Lu.party = function (secs) { party = Math.max(party, secs || 8); G.ceo.react('excited', secs || 8); };
  // the face to show right now: Lumo naps when the autopilot is off and nothing is going on
  Lu.mood = function () {
    if (party > 0) return 'party';
    const ce = G.ceo, rt = ce.rt;
    if (!ce.enabled() && rt.t >= rt.moodUntil) return 'sleepy';
    return ce.mood();
  };
  // what the chip on the HQ screen says
  Lu.line = function () {
    const ce = G.ceo, th = ce.thought();
    if (!ce.enabled()) return { text: 'Autopilot is off. Tap me to put Lumo back to work.', mood: 'sleepy' };
    if (th) return { text: th, mood: 'thinking' };
    const sv = ce.saving();
    if (sv) return { text: 'Saving ' + U.money(sv.cost) + ' to ' + sv.title.charAt(0).toLowerCase() + sv.title.slice(1) + '.', mood: 'thinking' };
    return { text: ce.rt.said || 'Watching over the company.', mood: Lu.mood() };
  };

  /* ---------- the small face used in the interface (plain DOM, animated by CSS) ---------- */
  Lu.avatar = function (size, m) {
    const el = h('div', { class: 'lumo-av m-' + (m || 'happy'), style: { '--s': (size || 40) + 'px' } },
      h('i', { class: 'ant' }), h('i', { class: 'ear l' }), h('i', { class: 'ear r' }), h('div', { class: 'bd' }, h('div', { class: 'vz' }, h('b', { class: 'eye' }), h('b', { class: 'eye' }), h('u', { class: 'mo' }))));
    el._m = m || 'happy';
    return el;
  };
  Lu.setMood = function (el, m) { if (el._m !== m) { el._m = m; el.className = 'lumo-av m-' + m; } };

  /* ---------- the character on the island ---------- */
  const lu = { x: 0, y: 0, vx: 0, vy: 0, tx: 0, ty: 0, init: false, kind: 'hq', any: false, work: false, roam: 2, hop: 0, face: 1, sx: 0, sy: 0, sc: 1, wave: 0 };
  Lu.pos = () => lu;
  function rr(c, x, y, w, hh, r) { c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + hh, r); c.arcTo(x + w, y + hh, x, y + hh, r); c.arcTo(x, y + hh, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath(); }
  function eyes(c, m, T, r, blink) {
    const vw = r * 1.36, vh = r * 0.92;
    c.fillStyle = '#0a1226'; rr(c, -vw / 2, -vh / 2 - r * 0.06, vw, vh, vh * 0.46); c.fill();
    c.strokeStyle = 'rgba(138,240,230,.4)'; c.lineWidth = 1; c.stroke();
    const ec = m === 'worried' ? '#ffb3bf' : m === 'excited' || m === 'party' ? '#ffe9a8' : m === 'sleepy' ? '#9fb3d9' : '#7ff6ea';
    c.fillStyle = ec; c.strokeStyle = ec; c.lineCap = 'round';
    const ey = -r * 0.08, ex = r * 0.3;
    c.lineWidth = r * 0.12;
    if (m === 'excited' || m === 'party') {
      for (const sx of [-1, 1]) { c.beginPath(); c.arc(sx * ex, ey + r * 0.1, r * 0.15, Math.PI * 1.1, Math.PI * 1.9); c.stroke(); }
      c.beginPath(); c.arc(0, ey + r * 0.2, r * 0.18, 0.05, Math.PI - 0.05); c.fill();
    } else if (m === 'sleepy') {
      for (const sx of [-1, 1]) { c.beginPath(); c.moveTo(sx * ex - r * 0.14, ey + r * 0.04); c.quadraticCurveTo(sx * ex, ey + r * 0.14, sx * ex + r * 0.14, ey + r * 0.04); c.stroke(); }
      c.lineWidth = r * 0.07; c.beginPath(); c.arc(0, ey + r * 0.3, r * 0.07, 0, TAU); c.stroke();
    } else {
      const open = blink ? 0.1 : 1, dx = m === 'thinking' ? r * 0.08 + Math.sin(T * 0.9) * r * 0.05 : 0, dy = m === 'thinking' ? -r * 0.08 : 0;
      for (const sx of [-1, 1]) { c.beginPath(); c.ellipse(sx * ex + dx, ey + dy, r * 0.12, r * 0.17 * open * (m === 'worried' ? 0.85 : 1), 0, 0, TAU); c.fill(); }
      c.lineWidth = r * 0.085; c.beginPath();
      if (m === 'worried') { c.moveTo(-r * 0.15, ey + r * 0.38); c.quadraticCurveTo(0, ey + r * 0.28, r * 0.15, ey + r * 0.38); }
      else if (m === 'thinking') { c.moveTo(-r * 0.1, ey + r * 0.32); c.lineTo(r * 0.13, ey + r * 0.29); }
      else c.arc(0, ey + r * 0.2, r * 0.15, 0.25, Math.PI - 0.25);
      c.stroke();
      if (m === 'worried') {
        c.lineWidth = r * 0.07; c.beginPath();
        c.moveTo(-ex - r * 0.14, ey - r * 0.2); c.lineTo(-ex + r * 0.14, ey - r * 0.31); c.moveTo(ex + r * 0.14, ey - r * 0.2); c.lineTo(ex - r * 0.14, ey - r * 0.31); c.stroke();
      }
    }
    c.lineCap = 'butt';
  }
  function drawLumo(c, FR, o) {
    const T = FR.T, m = o.m, s = o.sc, r = 13 * s, x = o.x, y = o.y;
    const bob = Math.sin(T * 2.4) * 2.4 * s - (o.hop > 0 ? Math.sin(o.hop * Math.PI) * 15 * s : 0);
    // soft shadow on the ground far below and the thrust glow
    c.fillStyle = 'rgba(0,0,0,.18)'; c.beginPath(); c.ellipse(x, y + r * 3.1, r * 0.9, r * 0.32, 0, 0, TAU); c.fill();
    c.globalCompositeOperation = 'lighter';
    c.globalAlpha = 0.55 + 0.2 * Math.sin(T * 9); c.drawImage(A.glow('#7ff6ea'), x - r * 0.9, y + bob + r * 0.75, r * 1.8, r * 1.5);
    c.globalAlpha = 0.28; c.drawImage(A.glow(MOOD[m] || '#3dd6c6'), x - r * 2.3, y + bob - r * 2.2, r * 4.6, r * 4.6);
    c.globalAlpha = 1; c.globalCompositeOperation = 'source-over';
    c.save(); c.translate(x, y + bob);
    if (o.face < 0) c.scale(-1, 1);
    // antenna
    c.strokeStyle = '#7d94c4'; c.lineWidth = Math.max(1.3, r * 0.1); c.beginPath(); c.moveTo(0, -r * 0.95); c.lineTo(0, -r * 1.5); c.stroke();
    const ap = 0.65 + 0.35 * Math.sin(T * (m === 'thinking' ? 8 : 3));
    c.globalCompositeOperation = 'lighter'; c.globalAlpha = 0.8 * ap; c.drawImage(A.glow(m === 'worried' ? '#ff6b81' : '#f6b84a'), -r * 0.6, -r * 2.1, r * 1.2, r * 1.2); c.globalAlpha = 1; c.globalCompositeOperation = 'source-over';
    c.fillStyle = m === 'worried' ? '#ff8798' : '#ffd27a'; c.beginPath(); c.arc(0, -r * 1.55, r * 0.15, 0, TAU); c.fill();
    // ears
    for (const sx of [-1, 1]) {
      c.fillStyle = '#4f7fc4'; rr(c, sx * r * 1.0 - r * 0.12, -r * 0.3, r * 0.24, r * 0.6, r * 0.1); c.fill();
      c.fillStyle = Math.sin(T * 4 + sx) > 0 ? '#7ff6ea' : '#2b6f78'; c.fillRect(sx * r * 1.0 - r * 0.05, -r * 0.12, r * 0.1, r * 0.1);
    }
    // body
    const g = c.createRadialGradient(-r * 0.35, -r * 0.45, r * 0.1, 0, 0, r * 1.15);
    g.addColorStop(0, '#ffffff'); g.addColorStop(0.45, '#cde8ff'); g.addColorStop(1, '#5a86cc');
    c.fillStyle = g; c.beginPath(); c.arc(0, 0, r, 0, TAU); c.fill();
    c.strokeStyle = 'rgba(255,255,255,.7)'; c.lineWidth = 1; c.stroke();
    // a thin ring that tilts around him
    c.strokeStyle = 'rgba(61,214,198,.75)'; c.lineWidth = Math.max(1, r * 0.09); c.beginPath(); c.ellipse(0, r * 0.62, r * 0.95, r * 0.22, 0, 0.1, Math.PI - 0.1); c.stroke();
    // face
    const blink = (T % 4.3) < 0.13;
    c.save(); c.translate(0, -r * 0.02); eyes(c, m, T, r, blink); c.restore();
    // hands
    const wv = m === 'excited' || m === 'party' || o.hop > 0;
    for (const sx of [-1, 1]) {
      const hx = sx * r * 1.42, hy = sx > 0 && wv ? -r * 0.35 + Math.sin(T * 11) * r * 0.2 : r * 0.55 + Math.sin(T * 2.6 + sx) * r * 0.1;
      c.fillStyle = '#e3f1ff'; c.beginPath(); c.arc(hx, hy, r * 0.23, 0, TAU); c.fill(); c.strokeStyle = 'rgba(90,134,204,.6)'; c.lineWidth = 1; c.stroke();
    }
    // extras for the mood
    if (m === 'party') {
      c.save(); c.translate(r * 0.1, -r * 0.92); c.rotate(0.28);
      c.fillStyle = '#ff7fa3'; c.beginPath(); c.moveTo(-r * 0.4, 0); c.lineTo(r * 0.4, 0); c.lineTo(0, -r * 0.95); c.closePath(); c.fill();
      c.fillStyle = '#ffd27a'; for (let i = 0; i < 3; i++) c.fillRect(-r * 0.3 + i * r * 0.22, -r * 0.2 - i * r * 0.12, r * 0.12, r * 0.07);
      c.fillStyle = '#8af0e6'; c.beginPath(); c.arc(0, -r * 0.98, r * 0.14, 0, TAU); c.fill(); c.restore();
    }
    c.restore();
    if (m === 'thinking') {
      c.fillStyle = 'rgba(220,235,255,.95)';
      for (let i = 0; i < 3; i++) { const a = 0.3 + 0.7 * Math.max(0, Math.sin(T * 5 - i * 0.9)); c.globalAlpha = a; c.beginPath(); c.arc(x + r * (1.25 + i * 0.4), y + bob - r * 1.35 - i * r * 0.18, r * (0.11 + i * 0.03), 0, TAU); c.fill(); }
      c.globalAlpha = 1;
    } else if (m === 'sleepy') {
      c.fillStyle = 'rgba(190,210,245,.9)'; c.font = 'italic 700 ' + Math.round(r * 0.8) + 'px Inter, system-ui, sans-serif';
      for (let i = 0; i < 2; i++) { const ph = (T * 0.45 + i * 0.5) % 1; c.globalAlpha = Math.sin(ph * Math.PI); c.fillText('z', x + r * (1.0 + ph * 0.7 + i * 0.35), y + bob - r * (0.9 + ph * 1.2)); }
      c.globalAlpha = 1;
    } else if (m === 'worried') {
      const bounce = Math.abs(Math.sin(T * 3)) * r * 0.1;
      c.fillStyle = 'rgba(126,200,255,.95)'; c.beginPath(); c.moveTo(x + r * 0.95, y + bob - r * 0.75 + bounce); c.quadraticCurveTo(x + r * 1.15, y + bob - r * 0.35 + bounce, x + r * 0.95, y + bob - r * 0.28 + bounce); c.quadraticCurveTo(x + r * 0.75, y + bob - r * 0.35 + bounce, x + r * 0.95, y + bob - r * 0.75 + bounce); c.fill();
    }
  }

  /* ---------- flying around ---------- */
  const KINDS = ['hq', 'lab', 'dc', 'net', 'pwr', 'cool'];
  function goTo(kind, any, lift) {
    const t = G.life.top(kind, lift === undefined ? 34 : lift, any) || G.life.top('hq', 34);
    if (!t) return false;
    lu.tx = t[0] + (Math.random() - 0.5) * 28; lu.ty = t[1] - 4 + (Math.random() - 0.5) * 10;
    return true;
  }
  function stepLumo(FR, dt) {
    if (!lu.init) {
      const t = G.life.top('hq', 40);
      if (!t) return;
      lu.x = lu.tx = t[0]; lu.y = lu.ty = t[1] - 10; lu.init = true;
    }
    lu.sc = clamp(1.05 / FR.cam.z, 1.2, 3.6);   // about 27 screen pixels across whatever the zoom, so he is easy to find
    party = Math.max(0, party - dt);
    const w = lu.work;
    if (!w) {
      lu.roam -= dt;
      if (lu.roam <= 0) { lu.roam = 5 + Math.random() * 5; lu.kind = KINDS[Math.floor(Math.random() * KINDS.length)]; lu.any = lu.kind === 'dc'; if (!goTo(lu.kind, lu.any)) goTo('hq', false); }
    }
    if (party > 0) { const t = G.life.top('hq', 70); if (t) { lu.tx = t[0] + Math.cos(FR.T * 1.8) * 46; lu.ty = t[1] + Math.sin(FR.T * 2.6) * 18; } }
    const k = 1 - Math.exp(-dt * 2.6);
    const ax = (lu.tx - lu.x) * 9 - lu.vx * 4.4, ay = (lu.ty - lu.y) * 9 - lu.vy * 4.4;
    lu.vx += ax * dt; lu.vy += ay * dt; lu.x += lu.vx * dt; lu.y += lu.vy * dt;
    if (Math.abs(lu.vx) > 14) lu.face = lu.vx > 0 ? 1 : -1;
    if (lu.hop > 0) lu.hop = lu.hop + dt * 1.9 >= 1 ? 0 : lu.hop + dt * 1.9;
    if (party > 0 && Math.random() < dt * 4 && FR.visible) { const p = FR.toScreen(lu.x, lu.y), r = FR.cv.getBoundingClientRect(); G.fx.confetti(5, r.left + p[0], r.top + p[1]); }
    lu.m = Lu.mood();
  }
  function airLayer(FR) {
    stepLumo(FR, Math.min(FR.dt, 0.05));
    if (!lu.init) return;
    drawLumo(FR.c, FR, { x: lu.x, y: lu.y, sc: lu.sc, m: lu.m, face: lu.face, hop: lu.hop });
    const p = FR.toScreen(lu.x, lu.y); lu.sx = p[0]; lu.sy = p[1];
  }
  S.use('air', airLayer);
  // tapping Lumo opens his panel
  S.taps.push((sx, sy) => {
    if (!lu.init || !S.ctx.all) return false;
    const r = 24 * lu.sc * S.getCam().z + 10;
    if (Math.hypot(sx - lu.sx, sy - lu.sy) <= r) { G.audio.sfx('chirp'); Lu.open(); return true; }
    return false;
  });

  /* ---------- speech ---------- */
  const bub = { cur: null, q: [] };
  const wrapCache = {};
  Lu.say = function (text, mood, secs) {
    if (!text) return;
    const b = { text, mood: mood || 'happy', t: 0, dur: secs || clamp(2.6 + text.length * 0.05, 3.2, 7.5), lines: null };
    if (bub.cur && bub.cur.text === text) return;
    bub.q = bub.q.filter((x) => x.text !== text);
    bub.q.push(b);
    if (bub.q.length > 2) bub.q.shift();
    if (bub.cur && bub.cur.t > 1.6) bub.cur.t = Math.max(bub.cur.t, bub.cur.dur - 0.35);
    G.audio.sfx('chirp');
  };
  function wrap(c, text, maxW) {
    const key = text + '|' + maxW;
    if (wrapCache[key]) return wrapCache[key];
    const words = text.split(' '), out = [];
    let line = '';
    for (const w of words) {
      const t = line ? line + ' ' + w : w;
      if (c.measureText(t).width > maxW && line) { out.push(line); line = w; } else line = t;
    }
    if (line) out.push(line);
    if (out.length > 3) { out.length = 3; out[2] = out[2].replace(/\s*\S*$/, '') + '…'; }
    const keys = Object.keys(wrapCache); if (keys.length > 40) delete wrapCache[keys[0]];
    return (wrapCache[key] = out);
  }
  function bubbleLayer(FR) {
    if (!bub.cur && bub.q.length) bub.cur = bub.q.shift();
    const b = bub.cur;
    if (!b) return;
    b.t += FR.dt;
    if (b.t >= b.dur) { bub.cur = null; return; }
    if (!FR.all || !lu.init) return;
    const c = FR.c, col = MOOD[b.mood] || '#3dd6c6';
    const a = b.t < 0.25 ? U.ease.back(b.t / 0.25) : b.t > b.dur - 0.4 ? (b.dur - b.t) / 0.4 : 1;
    c.font = '600 11.5px Inter, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif';
    const maxW = Math.min(210, FR.W - 60);
    if (!b.lines) b.lines = wrap(c, b.text, maxW);
    let tw = 0; for (const l of b.lines) tw = Math.max(tw, c.measureText(l).width);
    const pw = tw + 24, ph = 18 + b.lines.length * 15 + 6, lift = 26 * lu.sc * FR.cam.z;
    let x = clamp(lu.sx - pw / 2 + 10, 8, FR.W - pw - 8), y = lu.sy - lift - ph - 14, below = false;
    if (y < FR.inset.t + 6) { y = lu.sy + lift * 0.9 + 18; below = true; }
    y = clamp(y, FR.inset.t + 6, Math.max(FR.inset.t + 6, FR.H - FR.inset.b - ph - 6));   // never under the hint chip or the Lumo chip
    const cr = S.chatRect && S.chatRect();   // keep clear of the demo chat window above the headquarters
    if (cr && x < cr.x + cr.w && x + pw > cr.x && y < cr.y + cr.h && y + ph > cr.y) y = below ? cr.y + cr.h + 6 : Math.max(FR.inset.t + 6, cr.y - ph - 8);
    c.save();
    c.globalAlpha = clamp(a, 0, 1);
    c.translate(x + pw / 2, y + ph / 2); c.scale(0.85 + 0.15 * clamp(a, 0, 1), 0.85 + 0.15 * clamp(a, 0, 1)); c.translate(-(x + pw / 2), -(y + ph / 2));
    c.fillStyle = 'rgba(7,12,30,.94)'; rr(c, x, y, pw, ph, 13); c.fill();
    c.lineWidth = 1.2; c.strokeStyle = col; c.globalAlpha = clamp(a, 0, 1) * 0.85; c.stroke(); c.globalAlpha = clamp(a, 0, 1);
    const ax = clamp(lu.sx, x + 16, x + pw - 16);
    c.fillStyle = 'rgba(7,12,30,.94)'; c.beginPath();
    if (below) { c.moveTo(ax - 6, y + 0.5); c.lineTo(ax + 6, y + 0.5); c.lineTo(ax, y - 7); } else { c.moveTo(ax - 6, y + ph - 0.5); c.lineTo(ax + 6, y + ph - 0.5); c.lineTo(ax, y + ph + 7); }
    c.closePath(); c.fill();
    c.fillStyle = col; c.font = '700 8.5px Inter, system-ui, sans-serif'; c.textBaseline = 'middle'; c.fillText('LUMO', x + 12, y + 11);
    c.beginPath(); c.arc(x + 12 + 28, y + 11, 2.2, 0, TAU); c.fill();
    c.fillStyle = '#eef3ff'; c.font = '600 11.5px Inter, system-ui, sans-serif';
    b.lines.forEach((l, i) => c.fillText(l, x + 12, y + 28 + i * 15));
    c.restore(); c.textBaseline = 'alphabetic'; c.globalAlpha = 1;
  }
  S.use('hud', bubbleLayer);

  /* ---------- what Lumo reacts to ---------- */
  G.on('ceo_say', (o) => Lu.say(o.text, o.mood));
  G.on('ceo_plan', (o) => {
    const p = o.plan;
    Lu.say(p.think, 'thinking', 3.4);
    lu.work = true; lu.kind = p.target || 'hq'; lu.any = lu.kind === 'dc';
    if (!goTo(lu.kind, lu.any, 36)) goTo('hq', false);
  });
  G.on('ceo_do', (o) => {
    lu.work = false; lu.roam = 3.5; lu.hop = 0.001;
    if (!o.ok) return;
    if (S.visible && S.ctx) {
      const r = S.ctx.cv.getBoundingClientRect();
      if (lu.init) G.fx.burst(r.left + lu.sx, r.top + lu.sy, ['#8af0e6', '#ffd27a'], 12, { speed: 90, size: 8, ttl: 0.7, g: 30 });
    }
    Lu.say(o.effect ? 'Done! ' + o.effect + '.' : 'Done!', 'excited', 3);
  });
  G.on('buff', (o) => { if (o.on && o.buff && o.buff.good !== false) { G.ceo.react('excited', 3); } });

  /* ---------- the control panel ---------- */
  const CAT_ICON = { servers: 'cpu', build: 'build', research: 'research', models: 'ai', regions: 'globe', deals: 'doc', levers: 'tag' };
  function toggle(on, fn) {
    const b = h('button', { class: 'sw' + (on ? ' on' : ''), type: 'button', role: 'switch', 'aria-checked': on ? 'true' : 'false' }, h('i'));
    b.addEventListener('click', () => { G.audio.init(); G.audio.sfx('tap'); fn(!on); });
    return b;
  }
  function seg(items, cur, fn) {
    return h('div', { class: 'seg' }, items.map((it) => h('button', { class: it[0] === cur ? 'on' : '', type: 'button', onclick: () => { G.audio.sfx('tap'); fn(it[0]); } }, it[1])));
  }
  Lu.setSpeed = function (v) {
    const s = G.state;
    s.speed = v;
    G.audio.sfx('fast');
    if (G.fx) { const r = document.querySelector('.vt.spd'); if (r) { const b = r.getBoundingClientRect(); G.fx.ring(b.left + b.width / 2, b.top + b.height / 2, '#8af0e6', 36, 0.5); } }
  };
  Lu.cycleSpeed = function () { const s = G.state; Lu.setSpeed(s.speed === 1 ? 2 : s.speed === 2 ? 4 : 1); };
  Lu.open = function () {
    const UI = G.ui, s = G.state, c = s.ceo, ce = G.ceo;
    let m;
    const body = h('div', { class: 'col gap12 ceo' });
    function paint() {
      const on = ce.enabled();
      body.textContent = '';
      const line = Lu.line();
      body.append(
        h('div', { class: 'row lhead' }, Lu.avatar(54, on ? Lu.mood() : 'sleepy'),
          h('div', { class: 'grow' }, h('h2', { style: { margin: 0 } }, 'Lumo'), h('div', { class: 'xs mut' }, on ? 'Your AI CEO · autopilot on' : 'Your AI CEO · autopilot off')),
          toggle(on, (v) => { ce.toggle(v); paint(); })),
        h('div', { class: 'ceo-say' }, line.text),
        h('div', { class: 'col gap4' }, h('div', { class: 'micro' }, 'Style'), seg(Object.keys(ce.STYLES).map((k) => [k, ce.STYLES[k].name]), c.style, (v) => { c.style = v; G.adv.dirty(); paint(); }), h('div', { class: 'xs dimt' }, ce.STYLES[c.style].note)),
        h('div', { class: 'col gap4' }, h('div', { class: 'micro' }, 'Lumo takes care of'),
          h('div', { class: 'chips' }, ce.ALLOW.map((a) => h('button', { class: 'pill' + (c.allow[a[0]] ? ' on' : ''), type: 'button', onclick: () => { G.audio.sfx('tap'); c.allow[a[0]] = c.allow[a[0]] ? 0 : 1; paint(); } }, a[1])))),
        h('div', { class: 'col gap4' }, h('div', { class: 'micro' }, 'Game speed'), seg([[1, '1×'], [2, '2×'], [4, '4×']], s.speed, (v) => { Lu.setSpeed(v); paint(); }), h('div', { class: 'xs dimt' }, 'Faster speeds run the whole company faster: income, research, building and rivals.')),
        h('div', { class: 'row between' }, h('div', { class: 'grow' }, h('div', { class: 'sm b' }, 'Cinematic camera'), h('div', { class: 'xs dimt' }, 'Swoops in on what Lumo is building.')), toggle(!!s.cine, (v) => { s.cine = v ? 1 : 0; paint(); })),
        h('div', { class: 'micro' }, 'What Lumo did lately'),
        h('div', { class: 'col' }, c.log.length ? c.log.slice(0, 14).map((l) => h('div', { class: 'row loge' }, h('div', { class: 'ico dim' }, UI.I(CAT_ICON[l.k] || 'info', 16)), h('div', { class: 'grow sm' }, l.x, l.d ? h('div', { class: 'xs ' + (/^\+.*income/.test(l.d) ? 'pos' : 'mut') }, l.d) : null), h('span', { class: 'xs dimt' }, UI.ago(l.t)))) : [h('div', { class: 'empty' }, 'Nothing yet. Turn the autopilot on and watch.')]));
    }
    paint();
    m = UI.modal(body);
    return m;
  };

  /* ---------- first meeting ---------- */
  Lu.intro = function (done) {
    const UI = G.ui, s = G.state;
    let m;
    const go = (on) => { s.set.lumo = 1; s.ceo.on = on; G.ceo.rt.acc = 0; m.close(); G.audio.init(); G.audio.sfx('ach'); if (on) setTimeout(() => G.ceo.say('Let’s build an AI empire. Watch this!', 'excited'), 600); if (done) done(); };
    m = UI.modal(h('div', { class: 'col gap12 tc' },
      h('div', { class: 'lumo-big' }, Lu.avatar(92, 'excited')),
      h('h2', {}, 'Meet Lumo'),
      h('div', { class: 'mut' }, 'Lumo is your AI CEO. He can run the whole company for you: research, servers, buildings, new models and new regions, and he tells you what he is doing as he goes.'),
      h('div', { class: 'xs dimt' }, 'Sit back and watch, speed things up with the 1× 2× 4× button, or take over any part whenever you like.'),
      UI.btn('Let Lumo run it', { cls: 'pri blk', onclick: () => go(true) }),
      UI.btn('I’ll play myself', { cls: 'ghost blk', onclick: () => go(false) })), { center: true, lock: true });
  };
})();
