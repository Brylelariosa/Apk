/* AI Empire Tycoon - isometric campus renderer (canvas 2D, sprite cached, mobile friendly) */
(function () {
  'use strict';
  const G = window.G, D = G.D, U = G.U, A = G.art;
  const S = (G.scene = {});
  const P = A.P;
  const clamp = U.clamp;
  let cv = null, c = null, W = 300, H = 300, dpr = 1;
  let cache = {}, items = [], land = null, landSig = '', roads = [], sites = [], decor = null;
  let sig = '', lastT = 0, T = 0, frames = 0;
  let pickObj = null, pickT = 0;
  const cam = { x: 0, y: 0, z: 1, tx: 0, ty: 0, tz: 1, manual: false, hold: 0 };   // hold: the time until which the camera stays where a scene put it (see S.focus)
  // Part of the canvas that is covered by interface (hint chip, tool buttons, dock). The camera centres the campus in what is left.
  const inset = { t: 0, b: 0 };
  const oy = () => (inset.t - inset.b) / 2;
  // Which buildings each focused view frames. 'all' (anything else) shows the whole campus with labels.
  // The first kind is the one the list is about (it gets the outline and the name tag); the rest only has to be in the picture.
  const FOCUS = { dc: ['dc', 'cool'], hq: ['hq'], lab: ['lab'], cool: ['cool'], pwr: ['pwr'], net: ['net'] };
  const showAll = () => !FOCUS[S.view];
  S.q = 1;
  S.view = 'all';
  S.onPick = null;
  S.visible = false;

  /* ---------- layers: how the rest of the game draws onto the island ---------- */
  // Effects live in their own files and join the frame with S.use(layer, fn). fn(FR, list) is called once a frame with the frame
  // context FR (the canvas, time, camera, buildings, roads, a world -> screen conversion); only 'actors' gets a list, to push
  // [depth, 2, (c) => draw] onto so a person or a car is sorted in with the buildings and trees.
  // In frame order:  sky      screen space, behind everything (sun, moon, northern lights, meteors)
  //                  back     world space, behind the island
  //                  ground   world space, on the lawn and the roads
  //                  actors   world space, sorted with the buildings
  //                  air      world space, over the buildings
  //                  grade    the colour of the light (sunrise, daylight, sunset) laid over everything drawn so far
  //                  hud      screen space, over the labels
  // A layer that throws is switched off after a few tries, so a bug in an effect can never stop the island from drawing.
  const layers = { sky: [], back: [], ground: [], actors: [], air: [], grade: [], hud: [] };
  const SPACE = { sky: 0, back: 1, ground: 1, actors: 1, air: 1, grade: 0, hud: 0 };   // 0 = screen pixels, 1 = world pixels
  const FR = { c: null, cv: null, W: 0, H: 0, dpr: 1, T: 0, dt: 0, q: 1, items: [], roads: [], sites: [], ghosts: [], land: null, cam, inset, all: true, visible: false, toScreen: null };
  S.layers = layers;
  S.ctx = null;     // the frame context once the first frame has been drawn; effects that react to game events (outside a frame) read it
  S.taps = [];      // (sx, sy) => true when it used the tap; tried before the buildings, so something drawn on top can take it
  S.use = function (layer, fn) { if (layers[layer] && typeof fn === 'function') layers[layer].push(fn); };
  function toScreenSpace() { c.setTransform(dpr, 0, 0, dpr, 0, 0); }
  function toWorldSpace() { const z = cam.z * dpr; c.setTransform(z, 0, 0, z, dpr * W / 2 - cam.x * z, dpr * (H / 2 + oy()) - cam.y * z); }
  function run(name, list) {
    const l = layers[name];
    if (!l.length) return;
    const world = SPACE[name] === 1;
    for (let i = 0; i < l.length; i++) {
      const f = l[i];
      if (f.off) continue;
      if (world) toWorldSpace(); else toScreenSpace();
      c.globalAlpha = 1; c.globalCompositeOperation = 'source-over';
      try { f(FR, list); } catch (e) {
        f.bad = (f.bad || 0) + 1;
        if (f.bad >= 3) f.off = true;
        c.globalAlpha = 1; c.globalCompositeOperation = 'source-over'; c.textAlign = 'left'; c.textBaseline = 'alphabetic';
        try { (G.err || console.error)(e); } catch (x) { /* ignore */ }
      }
    }
    if (world) toWorldSpace(); else toScreenSpace();
    c.globalAlpha = 1; c.globalCompositeOperation = 'source-over';
  }
  function fillFrame(dt) {
    FR.c = c; FR.cv = cv; FR.W = W; FR.H = H; FR.dpr = dpr; FR.T = T; FR.dt = dt; FR.q = S.q;
    FR.items = items; FR.roads = roads; FR.sites = sites; FR.ghosts = ghosts; FR.land = land;
    FR.all = showAll(); FR.visible = S.visible; FR.toScreen = toScreen;
    S.ctx = FR;
  }

  const popAt = {}, flashAt = {};   // popAt: a building was just built; flashAt: servers or racks in a room just changed
  const SKIN = () => G.state.pres.skin || 'midnight';
  // Empty plots (construction sites, the lab slot). Where a building stands once built is decided by its drawing in art.js.
  const PLOTS = {
    hq: [1, 1, 5, 5], lab: [8.1 + A.PLAN.lab.dx, 1.3, 5, 4.4], cool: [A.COOLX, 7.6, 1.2, 4.8], net: [A.PLAN.net.x - 0.1, A.PLAN.net.y - 0.2, 1, 1]
  };
  const PWR = { 1: [14.3, 1.1, 2, 2], 2: [16.9, 1.0, 4, 3.2], 3: [14.3, 3.7, 2.6, 2.6], 4: [17.4, 4.4, 3, 3], 5: [17.8, 15.4, 3.2, 3.2] };
  const TREES = [[0.4, 6.2], [0.5, 12.6], [6.6, 20], [0.4, 19.4], [8.4, 6.5], [13.6, 6.6], [20.8, 6.6], [14.1, 14.6], [21.4, 15.4], [18.1, 21.8], [21.2, 20.6], [0.6, 3.4], [7.4, 4.4], [13.8, 0.5], [21.3, 0.8]];

  /* ---------- setup ---------- */
  S.init = function (canvas, skyCanvas) {
    cv = canvas; c = cv.getContext('2d'); skyEl = skyCanvas || null;
    bindInput();
    S.resize();
  };
  S.resize = function () {
    if (!cv) return;
    const r = cv.parentElement.getBoundingClientRect();
    if (r.width < 10 || r.height < 10) return;
    const nd = Math.min(window.devicePixelRatio || 1, S.q === 0 ? 1.25 : 2);
    if (r.width === W && r.height === H && nd === dpr) return;
    W = r.width; H = r.height; dpr = nd;
    cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr);
    cv.style.width = W + 'px'; cv.style.height = H + 'px';
    const res = clamp(dpr * (S.q === 0 ? 0.7 : 0.8), 1, 1.75);
    if (Math.abs(res - A.res) > 0.01) { A.res = res; cache = {}; land = null; decor = null; sig = ''; }
    S.fit(true);
  };
  S.setQuality = function (q) {
    if (q === S.q) return;
    S.q = q;
    S.resize();
    sig = '';
  };

  /* ---------- state -> items ---------- */
  // The empty lot for the research lab is shown once it is (nearly) affordable, and then stays until it is built.
  let slotSeen = false;
  function labSlotOn() {
    const s = G.state;
    if (s.inf.lab !== 0 || G.building('lab')) { slotSeen = false; return false; }
    const t = G.ladderNext('lab');
    if (!t) return false;
    if (slotSeen) return true;
    if (s.cash >= G.ladderCost(t) * 0.8) { slotSeen = true; return true; }
    return false;
  }
  function signature() {
    const s = G.state, i = s.inf;
    return [SKIN(), i.hq, i.lab, i.dc, i.cool, i.pwr, i.net, i.racks, D.hw.map((h) => i[h.k]).join(','), s.build.map((b) => b.k + b.to).join(','), S.q, labSlotOn() ? 1 : 0].join('|');
  }
  function mk(id, sg, make) {
    const e = cache[id];
    if (e && e.sig === sg) return e;
    const obj = make();
    if (e && obj.kind === 'dc') flashAt[id] = T;   // the room was redrawn because a rack or a server was added or sold
    const spr = A.sprite(obj.b, obj.draw);
    const lit = obj.lit ? A.sprite(obj.b, obj.lit) : null;   // the windows that glow at night (must come after draw, which records them)
    let led = null;
    if (obj.leds && S.q > 0) led = [0, 1, 2].map((k) => A.sprite(obj.ledB, (cc) => obj.leds(cc, k), Math.min(A.res, 1.0)));
    const poly = hitPoly(obj.fp);
    return (cache[id] = { sig: sg, obj, spr, lit, led, poly, sum: obj.fp[0] + obj.fp[2] + obj.fp[1] + obj.fp[3], depth: 0 });
  }
  // Back-to-front order of the buildings. A building has to be drawn before anything that stands in front of it; seen from the
  // front corner of the island that means it ends before the other begins along x or along y. (Ranking by the far corner alone drew
  // a big office on top of the small closet beside it.) When neither holds the plots overlap and the old sum decides.
  // The order is also written to `depth`, the scale that trees are sorted on in S.render, so they still interleave with the buildings.
  function paintOrder(list) {
    const n = list.length, fp = list.map((e) => e.obj.fp), eps = 1e-6;
    const behind = (a, b) => a[0] + a[2] <= b[0] + eps || a[1] + a[3] <= b[1] + eps;
    const wait = new Array(n).fill(0), then = list.map(() => []), used = new Array(n).fill(false), out = [];
    for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++) {
      const ij = behind(fp[i], fp[j]), ji = behind(fp[j], fp[i]);
      if (ij !== ji) { const a = ij ? i : j, b = ij ? j : i; then[a].push(b); wait[b]++; }
    }
    for (let k = 0; k < n; k++) {
      let pick = -1;
      for (let pass = 0; pass < 2 && pick < 0; pass++) // the second pass only runs if the rules ever form a loop
        for (let i = 0; i < n; i++) if (!used[i] && (pass || wait[i] <= 0) && (pick < 0 || list[i].sum < list[pick].sum)) pick = i;
      used[pick] = true; out.push(list[pick]);
      for (const t of then[pick]) wait[t]--;
    }
    const scale = list.map((e) => e.sum).sort((a, b) => a - b);
    out.forEach((e, k) => { e.depth = scale[k]; });
    return out;
  }
  function hitPoly(fp) {
    const [x, y, w, d, h] = fp;
    return [P(x, y, h), P(x + w, y, h), P(x + w, y, 0), P(x + w, y + d, 0), P(x, y + d, 0), P(x, y + d, h)];
  }
  S.sync = function (force) {
    if (!cv) return;
    const sg = signature();
    if (sg === sig && !force) return;
    sig = sg;
    build();
  };
  function build() {
    const s = G.state, pal = A.palette(SKIN()), inf = s.inf, sk = SKIN();
    const list = [];
    const keep = {};
    const add = (id, sg, make) => { const e = mk(id, sg, make); keep[id] = 1; list.push(e); return e; };
    add('hq', 'hq' + inf.hq + sk, () => A.hq(inf.hq, pal));
    if (inf.lab >= 1) add('lab', 'lab' + inf.lab + sk, () => A.lab(inf.lab, pal));
    // Every server sits in a rack slot of some room, and each room is drawn from exactly those slots (see racks.js).
    const rooms = G.racks.rooms(inf), slots = G.racks.slots(inf);
    const closet = G.racks.room(slots, rooms[0], rooms[0].cap);
    add('dc0', 'shed|' + sk + '|' + G.racks.key(closet), () => A.shed(pal, closet));
    for (let lv = 1; lv <= inf.dc; lv++) {
      const g = A.hallGrid(lv), cells = G.racks.room(slots, rooms[lv], g.cols * g.rows);
      add('dc' + lv, ['hall', lv, rooms[lv].n, G.racks.key(cells), inf.cool, sk].join('|'), () => A.hall(lv, cells, inf.cool, pal));
    }
    if (inf.dc >= 1) add('cool', 'cool' + inf.cool + sk, () => A.cooling(inf.cool, pal));
    for (let lv = 1; lv <= Math.min(5, inf.pwr); lv++) add('pwr' + lv, 'pwr' + lv + sk, () => A.power(lv, pal));
    if (inf.net >= 1) add('net', 'net' + inf.net + sk, () => A.tower(inf.net, pal));
    // construction sites (new buildings) and crane overlays (upgrades)
    sites = [];
    for (const b of s.build) {
      let fp = null, isNew = false;
      if (b.k === 'dc') { const h = A.HALLS[b.to]; fp = [h.x, h.y, h.w, h.d]; isNew = true; }
      else if (b.k === 'lab') { fp = PLOTS.lab; isNew = b.to === 1; }
      else if (b.k === 'pwr') { fp = PWR[b.to] || null; isNew = !!fp; }
      else if (PLOTS[b.k]) fp = PLOTS[b.k];
      if (!fp) continue;
      let e = null;
      if (isNew) e = add('site' + b.k + b.to, 'site' + fp.join(','), () => A.site(fp));
      sites.push({ b, fp, e });
    }
    ghosts = [];
    if (labSlotOn()) {
      const f = PLOTS.lab;
      ghosts.push({ obj: { id: 'labslot', kind: 'lab', lv: 0, ghost: true, fp: f }, fp: f, poly: [P(f[0], f[1]), P(f[0] + f[2], f[1]), P(f[0] + f[2], f[1] + f[3]), P(f[0], f[1] + f[3])] });
    }
    for (const id in cache) if (!keep[id]) delete cache[id];
    items = paintOrder(list);
    // land and roads
    let lx = 9.2, ly = 7.8;
    { const f = PLOTS.lab; lx = Math.max(lx, f[0] + f[2] + 1.3); ly = Math.max(ly, f[1] + f[3] + 1.3); }
    for (const e of items) { lx = Math.max(lx, e.obj.fp[0] + e.obj.fp[2] + 1.3); ly = Math.max(ly, e.obj.fp[1] + e.obj.fp[3] + 1.3); }
    roads = [[2.4, 6.9, inf.lab >= 1 ? 12.2 : 7.9, 6.9]];
    if (inf.dc >= 2) roads.push([7.9, 6.9, 7.9, inf.dc >= 3 ? 13.2 : 12.6]);
    if (inf.dc >= 3) roads.push([7.9, 13.2, inf.dc >= 5 ? 15.6 : 8.5, 13.2]);
    if (inf.dc >= 4) roads.push([8.5, 13.2, 8.5, 19.6]);
    const ls = lx.toFixed(1) + ',' + ly.toFixed(1) + sk + roads.join(';');
    if (!land || ls !== landSig) { landSig = ls; land = A.land(lx, ly, pal, roads); land.lx = lx; land.ly = ly; }
    // decor trees
    if (!decor) decor = TREES.map((t, i) => ({ x: t[0], y: t[1], s: 0.8 + (i % 3) * 0.14, col: ['#3fa37a', '#4bb58a', '#37966f'][i % 3] }));
    if (!cam.manual) S.fit(false);
  }

  /* ---------- camera ---------- */
  S.fit = function (snap, force) {
    if (!snap && !force && cam.hold > T) return;   // a scene has the camera for a moment (S.focus); it hands it back by itself
    cam.hold = 0;
    if (!items.length) { sig = ''; if (G.state) S.sync(true); if (!items.length) return; }
    let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
    const kinds = FOCUS[S.view];
    let use = kinds ? items.filter((e) => kinds.includes(e.obj.kind)) : items;
    if (S.view === 'dc') {   // the servers live in the biggest room, so frame that one (and the cooling beside it), not the whole row of rooms
      const top = use.reduce((m, e) => (e.obj.kind === 'dc' && (!m || e.obj.lv > m.obj.lv) ? e : m), null);
      use = use.filter((e) => e.obj.kind !== 'dc' || e === top);
    }
    for (const e of (use.length ? use : items)) { const b = e.obj.b; x0 = Math.min(x0, b[0]); y0 = Math.min(y0, b[1]); x1 = Math.max(x1, b[2]); y1 = Math.max(y1, b[3]); }
    for (const sx of sites) { const f = sx.fp; x0 = Math.min(x0, P(f[0], f[1] + f[3])[0] - 10); x1 = Math.max(x1, P(f[0] + f[2], f[1])[0] + 10); y1 = Math.max(y1, P(f[0] + f[2], f[1] + f[3])[1] + 10); y0 = Math.min(y0, P(f[0], f[1], 90)[1]); }
    if (!kinds) {
      // the empty build slot, the labels above the buildings and the rock under the island all belong in the picture
      for (const g of ghosts) { const f = g.fp; x0 = Math.min(x0, P(f[0], f[1] + f[3])[0] - 10); x1 = Math.max(x1, P(f[0] + f[2], f[1])[0] + 10); y0 = Math.min(y0, P(f[0], f[1])[1] - 50); y1 = Math.max(y1, P(f[0] + f[2], f[1] + f[3])[1] + 10); }
      y0 -= 34;
      if (land) y1 = Math.max(y1, land.tip + land.depth * 0.85);
    } else y0 -= 30;   // room for the name tag above the building
    const pad = 30, bw = x1 - x0 + pad * 2, bh = y1 - y0 + pad * 2;
    cam.tz = clamp(Math.min(W / bw, (H - inset.t - inset.b) / bh), 0.22, kinds ? 1.4 : 1.15);
    let cx = (x0 + x1) / 2, cy = (y0 + y1) / 2;
    cam.tx = cx; cam.ty = cy;
    if (snap || !cam.init) { cam.x = cam.tx; cam.y = cam.ty; cam.z = cam.tz; cam.init = true; }
    cam.manual = false;
  };
  S.setView = function (v) { if (S.view !== v) { S.view = v; S.fit(false, true); } };
  // Tell the scene how much of its top and bottom is covered by interface, so the campus is centred in the free area.
  S.setInset = function (t, b) { if (inset.t === t && inset.b === b) return; inset.t = t; inset.b = b; if (cv && !cam.manual) S.fit(false); };
  S.recenter = function () { S.fit(false, true); };
  // The camera glides to one building for a few seconds and then back to the whole campus (the cinematic camera uses this).
  // It says no (false) when it should not take over: the player is steering, a list is open that frames its own building, or the
  // building is not there yet. `zoom` is a multiplier on the zoom that just fits the building.
  S.focus = function (kind, secs, zoom) {
    if (!showAll() || cam.manual || !items.length) return false;
    let e = null;
    for (const it of items) if (it.obj.kind === kind && it.obj.b && (!e || (it.obj.lv || 0) >= (e.obj.lv || 0))) e = it;
    if (!e) return false;
    const b = e.obj.b, pad = 46, bw = b[2] - b[0] + pad * 2, bh = b[3] - b[1] + pad * 2;
    cam.tx = (b[0] + b[2]) / 2; cam.ty = (b[1] + b[3]) / 2;
    cam.tz = clamp(Math.min(W / bw, (H - inset.t - inset.b) / bh) * (zoom || 1), 0.3, 1.5);
    cam.hold = T + (secs || 4);
    return true;
  };
  S.holding = () => cam.hold > T;
  S.chatRect = () => chat.rect;
  S.pop = function (id) { popAt[id] = T; S.sync(true); };

  /* ---------- input ---------- */
  function bindInput() {
    const ptr = new Map();
    let down = null, pinch = 0;
    const rel = (e) => { const r = cv.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; };
    cv.addEventListener('pointerdown', (e) => {
      cv.setPointerCapture(e.pointerId);
      ptr.set(e.pointerId, rel(e));
      down = { p: rel(e), moved: false, t: performance.now() };
      if (ptr.size === 2) { const a = [...ptr.values()]; pinch = Math.hypot(a[0][0] - a[1][0], a[0][1] - a[1][1]); down.moved = true; }
    });
    cv.addEventListener('pointermove', (e) => {
      if (!ptr.has(e.pointerId)) return;
      const p = rel(e), old = ptr.get(e.pointerId);
      ptr.set(e.pointerId, p);
      if (ptr.size === 2) {
        const a = [...ptr.values()], d = Math.hypot(a[0][0] - a[1][0], a[0][1] - a[1][1]);
        if (pinch > 0) zoomAt((a[0][0] + a[1][0]) / 2, (a[0][1] + a[1][1]) / 2, d / pinch);
        pinch = d; cam.manual = true;
      } else if (ptr.size === 1) {
        if (!down.moved && Math.hypot(p[0] - down.p[0], p[1] - down.p[1]) > 6) down.moved = true;
        if (down.moved) { cam.x -= (p[0] - old[0]) / cam.z; cam.y -= (p[1] - old[1]) / cam.z; cam.tx = cam.x; cam.ty = cam.y; cam.manual = true; }
      }
    });
    const up = (e) => {
      const had = ptr.has(e.pointerId);
      ptr.delete(e.pointerId);
      if (had && ptr.size === 0 && down && !down.moved && performance.now() - down.t < 500) S.tap(down.p[0], down.p[1]);
      if (ptr.size < 2) pinch = 0;
    };
    cv.addEventListener('pointerup', up);
    // the browser took the touch over (to scroll the list): that is not a tap
    cv.addEventListener('pointercancel', (e) => { ptr.delete(e.pointerId); if (ptr.size < 2) pinch = 0; down = null; });
    cv.addEventListener('wheel', (e) => { e.preventDefault(); const p = rel(e); zoomAt(p[0], p[1], Math.exp(-e.deltaY * 0.0015)); cam.manual = true; }, { passive: false });
    cv.addEventListener('dblclick', () => S.recenter());
  }
  function zoomAt(sx, sy, f) {
    const nz = clamp(cam.z * f, 0.2, 2.2);
    const hy = H / 2 + oy();
    const ix = (sx - W / 2) / cam.z + cam.x, iy = (sy - hy) / cam.z + cam.y;
    cam.z = cam.tz = nz;
    cam.x = cam.tx = ix - (sx - W / 2) / nz; cam.y = cam.ty = iy - (sy - hy) / nz;
  }
  function inPoly(p, poly) {
    let ins = false;
    for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
      const a = poly[i], b = poly[j];
      if ((a[1] > p[1]) !== (b[1] > p[1]) && p[0] < ((b[0] - a[0]) * (p[1] - a[1])) / (b[1] - a[1]) + a[0]) ins = !ins;
    }
    return ins;
  }
  S.tap = function (sx, sy) {
    for (const f of S.taps) { try { if (f(sx, sy)) return null; } catch (e) { (G.err || console.error)(e); } }
    for (let i = labelRects.length - 1; i >= 0; i--) {
      const r = labelRects[i];
      if (sx >= r.x - 2 && sx <= r.x + r.w + 2 && sy >= r.y - 2 && sy <= r.y + r.h + 8) { pickObj = r.e; pickT = T; if (S.onPick) S.onPick(r.obj); return r.obj; }
    }
    const p = [(sx - W / 2) / cam.z + cam.x, (sy - H / 2 - oy()) / cam.z + cam.y];
    for (let i = items.length - 1; i >= 0; i--) {
      const e = items[i];
      if (e.obj.kind === 'site') continue;
      if (inPoly(p, e.poly)) { pickObj = e; pickT = T; if (S.onPick) S.onPick(e.obj); return e.obj; }
    }
    if (showAll()) for (const g of ghosts) if (inPoly(p, g.poly)) { pickObj = g; pickT = T; if (S.onPick) S.onPick(g.obj); return g.obj; }
    pickObj = null;
    if (S.onPick) S.onPick(null);
    return null;
  };

  /* ---------- drawing helpers ---------- */
  function glow(x, y, r, hex, a) {
    c.globalAlpha = a; c.drawImage(A.glow(hex), x - r, y - r, r * 2, r * 2); c.globalAlpha = 1;
  }
  function ground(e) {
    const dt = T - (popAt[e.obj.id] || -9);
    return dt >= 0 && dt < 1.2 ? dt / 1.2 : 1;
  }
  S.popAt = (id) => popAt[id];

  // what the animated parts of a building need to know (see art-live.js); filled once per frame
  const live = { q: 2, util: 0, active: false, lamp: 1, night: 1, acc: '#3dd6c6' };
  function liveEnv() {
    const k = G.sky ? G.sky.now() : null, sk = D.skins[SKIN()];
    live.q = S.q; live.util = G.C ? G.C.util : 0; live.active = G.state.res.q.length > 0;
    live.lamp = k ? k.lamp : 1; live.night = k ? k.night : 1; live.acc = (sk || D.skins.midnight).accent;
    return live;
  }
  function drawItem(e) {
    const o = e.obj, k = ground(e), spr = e.spr, lit = e.lit;
    const litA = 0.2 + 0.8 * live.lamp;   // office lights burn at night and are hard to see in the sun
    if (k < 1) {
      const ez = U.ease.out(k);
      c.globalAlpha = Math.min(1, ez * 1.4); c.save(); c.translate(0, (1 - ez) * -26);
      c.drawImage(spr.cv, spr.x, spr.y, spr.w, spr.h);
      if (lit) { c.globalAlpha *= litA; c.drawImage(lit.cv, lit.x, lit.y, lit.w, lit.h); }
      c.restore(); c.globalAlpha = 1;
      const f = o.fp, cp = P(f[0] + f[2] / 2, f[1] + f[3] / 2), rr = (f[2] + f[3]) * 24 * ez;
      c.strokeStyle = 'rgba(160,240,230,' + (0.6 * (1 - k)) + ')'; c.lineWidth = 2; c.beginPath(); c.ellipse(cp[0], cp[1], rr, rr * 0.5, 0, 0, 6.283); c.stroke();
      return;
    }
    c.drawImage(spr.cv, spr.x, spr.y, spr.w, spr.h);
    if (lit) { c.globalAlpha = litA; c.drawImage(lit.cv, lit.x, lit.y, lit.w, lit.h); c.globalAlpha = 1; }
    if (e.led && S.q > 0) {
      const L = e.led[S.q === 1 ? (Math.floor(T * 2.5 + o.lv) % 3) : (Math.floor(T * 4 + o.lv * 1.7) % 3)];
      c.drawImage(L.cv, L.x, L.y, L.w, L.h);
    }
    if (S.q > 0) A.paintLive(c, o, T, live);
  }
  function drawGlows() {
    c.globalCompositeOperation = 'lighter';
    const pulse = (0.75 + 0.25 * Math.sin(T * 1.6)) * (G.sky ? G.sky.glowK() : 1);   // lights are paler in daylight
    for (const e of items) {
      const gl = e.obj.glow;
      if (!gl) continue;
      for (const g of gl) glow(g.p[0], g.p[1], g.r, g.c, g.a * pulse * (e.obj.kind === 'dc' && G.C ? 0.6 + 0.6 * Math.min(1, G.C.util) : 1));
    }
    // a soft pulse over a room whose racks or servers just changed
    for (const e of items) {
      const t0 = flashAt[e.obj.id];
      if (t0 === undefined) continue;
      const k = (T - t0) / 1.1;
      if (k >= 1) { delete flashAt[e.obj.id]; continue; }
      const f = e.obj.fp, p = P(f[0] + f[2] / 2, f[1] + f[3] / 2, 12);
      glow(p[0], p[1], 36 + f[2] * 9 + k * 46, '#a8f5ea', 0.85 * (1 - k) * (1 - k));
    }
    c.globalCompositeOperation = 'source-over';
  }

  /* ---------- the building an Upgrades list is about ---------- */
  // On an Upgrades list the campus is framed around one kind of building. A dashed outline on the ground marks which one it is.
  function drawFocus() {
    const kinds = FOCUS[S.view];
    if (!kinds) return;
    const pulse = S.q === 0 ? 0.5 : 0.5 + 0.5 * Math.sin(T * 2.2), g = 0.2;
    for (const e of items) {
      if (e.obj.kind !== kinds[0]) continue;
      const f = e.obj.fp, pts = [P(f[0] - g, f[1] - g), P(f[0] + f[2] + g, f[1] - g), P(f[0] + f[2] + g, f[1] + f[3] + g), P(f[0] - g, f[1] + f[3] + g)];
      c.beginPath(); pts.forEach((q, i) => (i ? c.lineTo(q[0], q[1]) : c.moveTo(q[0], q[1]))); c.closePath();
      c.fillStyle = 'rgba(61,214,198,' + (0.05 + 0.07 * pulse) + ')'; c.fill();
      c.strokeStyle = 'rgba(120,240,225,' + (0.45 + 0.35 * pulse) + ')'; c.lineWidth = 1.8;
      if (S.q > 0) { c.setLineDash([7, 6]); c.lineDashOffset = -T * 8; }
      c.stroke(); c.setLineDash([]); c.lineDashOffset = 0;
    }
  }

  /* ---------- data flow ---------- */
  function drawFlow(dt) {
    if (!roads.length) return;
    const nl = G.state.inf.net;
    c.strokeStyle = U.rgba(A.palette(SKIN()).acc, 0.22); c.lineWidth = 1.4;
    c.beginPath();
    for (const r of roads) { const a = P(r[0], r[1]), b = P(r[2], r[3]); c.moveTo(a[0], a[1] - 1); c.lineTo(b[0], b[1] - 1); }
    c.stroke();
    if (S.q === 0) return;
    const n = (S.q === 1 ? 6 : 12) + nl * 2;
    c.globalCompositeOperation = 'lighter';
    const col = A.palette(SKIN()).acc;
    for (let i = 0; i < n; i++) {
      const r = roads[i % roads.length], u = (T * (0.14 + nl * 0.03) + i * 0.37) % 1;
      const p = P(U.lerp(r[0], r[2], u), U.lerp(r[1], r[3], u));
      glow(p[0], p[1] - 2, 7, col, 0.9);
    }
    c.globalCompositeOperation = 'source-over';
  }

  /* ---------- construction ---------- */
  function drawSites() {
    for (const sx of sites) {
      const f = sx.fp, frac = 1 - sx.b.left / Math.max(1, sx.b.total);
      const top = P(f[0] + f[2] - 0.5, f[1] + f[3] - 0.5, 90);
      if (!sx.e) {
        const base = P(f[0] + f[2] - 0.4, f[1] + f[3] + 0.4, 2);
        c.strokeStyle = '#e8b030'; c.lineWidth = 2.2; c.beginPath(); c.moveTo(base[0], base[1]); c.lineTo(base[0], base[1] - 88); c.stroke();
        top[0] = base[0]; top[1] = base[1] - 88;
      }
      const a = T * 0.6 + sx.b.to, jx = Math.cos(a) * 34, jy = Math.sin(a) * 17;
      c.strokeStyle = '#e8b030'; c.lineWidth = 2; c.beginPath(); c.moveTo(top[0], top[1]); c.lineTo(top[0] + jx, top[1] + jy); c.stroke();
      c.strokeStyle = 'rgba(255,255,255,.5)'; c.lineWidth = 1; c.beginPath(); c.moveTo(top[0] + jx, top[1] + jy); c.lineTo(top[0] + jx, top[1] + jy + 14 + Math.sin(T * 2) * 3); c.stroke();
      // scaffold rising with progress
      if (sx.e) {
        const hh = 8 + 40 * frac, x = f[0], y = f[1], w = f[2], d = f[3];
        c.strokeStyle = 'rgba(255,200,90,.65)'; c.lineWidth = 1;
        for (const [px, py] of [[x, y + d], [x + w, y + d], [x + w, y]]) { const p0 = P(px, py, 2), p1 = P(px, py, 2 + hh); c.beginPath(); c.moveTo(p0[0], p0[1]); c.lineTo(p1[0], p1[1]); c.stroke(); }
        const q0 = P(x, y + d, 2 + hh), q1 = P(x + w, y + d, 2 + hh), q2 = P(x + w, y, 2 + hh); c.beginPath(); c.moveTo(q0[0], q0[1]); c.lineTo(q1[0], q1[1]); c.lineTo(q2[0], q2[1]); c.stroke();
      }
      // progress bar
      const bx = P(f[0] + f[2] / 2, f[1] + f[3] / 2, 70);
      const bw = 62;
      c.fillStyle = 'rgba(8,14,30,.85)'; rrect(bx[0] - bw / 2 - 2, bx[1] - 18, bw + 4, 14, 7); c.fill();
      c.fillStyle = '#3dd6c6'; rrect(bx[0] - bw / 2, bx[1] - 16, Math.max(6, bw * frac), 10, 5); c.fill();
      c.fillStyle = '#fff'; c.font = '600 8px system-ui, sans-serif'; c.textAlign = 'center'; c.fillText(Math.floor(frac * 100) + '%', bx[0], bx[1] - 8.4);
    }
  }
  function rrect(x, y, w, h, r) { c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath(); }

  /* ---------- sky, clouds and atmosphere ---------- */
  let skyEl = null, sky = null, skyKey = '', stars = null, clouds = null, cloudSpr = null, cloudSig = '', motes = null, rocks = null, shoot = null, shootNext = 5;
  let ghosts = [], popAcc = 0;
  const labelRects = [], popups = [], textW = {};
  S.labelRects = labelRects;
  const FONT = '600 11px Inter, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif';

  function makeCloud(seed) {
    const w = 240, h = 100, sc = Math.min(1.5, dpr);
    const cvs = document.createElement('canvas'); cvs.width = Math.round(w * sc); cvs.height = Math.round(h * sc);
    const g = cvs.getContext('2d'); g.scale(sc, sc);
    const rnd = U.rng(seed * 131 + 7), n = 9;
    for (let i = 0; i < n; i++) {
      const t = i / (n - 1), x = 40 + t * 160 + (rnd() - 0.5) * 20, r = 20 + Math.sin(t * Math.PI) * 20 + rnd() * 8, y = h * 0.62 - Math.sin(t * Math.PI) * 14 + (rnd() - 0.5) * 8;
      const rg = g.createRadialGradient(x - r * 0.2, y - r * 0.3, 1, x, y, r);
      rg.addColorStop(0, 'rgba(210,228,255,.6)'); rg.addColorStop(0.6, 'rgba(150,182,238,.3)'); rg.addColorStop(1, 'rgba(120,150,222,0)');
      g.fillStyle = rg; g.beginPath(); g.arc(x, y, r, 0, 6.283); g.fill();
    }
    return cvs;
  }
  function ensureAtmo() {
    if (!stars) { const r = U.rng(4242); stars = []; for (let i = 0; i < 80; i++) stars.push({ x: r(), y: r() * 0.8, r: 0.5 + r() * 1.1, a: 0.28 + r() * 0.5, ph: r() * 6.28, sp: 0.6 + r() * 2, tw: r() < 0.35 }); }
    if (!cloudSpr) cloudSpr = [makeCloud(1), makeCloud(2), makeCloud(3)];
    if (land && cloudSig !== land.lx + ',' + land.ly) {
      cloudSig = land.lx + ',' + land.ly;
      const r = U.rng(99), tip = land.tip, dep = land.depth, cx = (P(0, land.ly)[0] + P(land.lx, 0)[0]) / 2;
      clouds = [];
      for (let i = 0; i < 10; i++) {
        const near = i % 3 === 2;
        clouds.push({ x: r() * 1300, y: near ? tip + dep * (0.4 + r() * 0.55) : tip - 80 + r() * dep * 0.95, s: near ? 1.15 + r() * 0.6 : 0.8 + r() * 0.5, v: (near ? 7 : 3.5) * (0.6 + r() * 0.8), a: near ? 0.5 : 0.42, near, spr: i % 3, cx });
      }
      motes = []; for (let i = 0; i < 18; i++) motes.push({ x: r(), y: r(), ph: r() * 6.28, sp: 0.03 + r() * 0.05, r: 6 + r() * 7 });
      rocks = [{ dx: -0.5, dy: 0.5, s: 12, ph: 0 }, { dx: 0.55, dy: 0.34, s: 16, ph: 2 }, { dx: 0.2, dy: 0.95, s: 9, ph: 4 }];
    }
  }
  function buildSky() {
    skyKey = W + 'x' + H + 'x' + dpr;
    // The static sky lives on its own canvas behind the scene, so it is painted once instead of every frame.
    const cvs = skyEl || document.createElement('canvas'); cvs.width = Math.max(1, Math.round(W * dpr)); cvs.height = Math.max(1, Math.round(H * dpr));
    if (skyEl) { cvs.style.width = W + 'px'; cvs.style.height = H + 'px'; }
    const g = cvs.getContext('2d'); g.setTransform(dpr, 0, 0, dpr, 0, 0);
    const bg = g.createLinearGradient(0, 0, 0, H);
    bg.addColorStop(0, '#040816'); bg.addColorStop(0.36, '#0a1434'); bg.addColorStop(0.68, '#112a4f'); bg.addColorStop(1, '#0b1a36');
    g.fillStyle = bg; g.fillRect(0, 0, W, H);
    const blob = (x, y, r, col, a) => { const rg = g.createRadialGradient(x, y, 0, x, y, r); rg.addColorStop(0, U.rgba(col, a)); rg.addColorStop(1, U.rgba(col, 0)); g.fillStyle = rg; g.fillRect(x - r, y - r, r * 2, r * 2); };
    blob(W * 0.18, H * 0.2, W * 0.75, '#5a3fd0', 0.17); blob(W * 0.9, H * 0.46, W * 0.8, '#1fb8c9', 0.12); blob(W * 0.5, H * 0.74, W * 0.95, '#2a78d6', 0.14);
    for (const st of stars) if (!st.tw) { g.globalAlpha = st.a; g.fillStyle = '#dbe9ff'; g.beginPath(); g.arc(st.x * W, st.y * H, st.r * 0.8, 0, 6.283); g.fill(); }
    g.globalAlpha = 1;
    // a ringed planet in the sky
    const px = W * 0.7, py = H * 0.2, R = Math.max(24, Math.min(W, H) * 0.105);
    const halo = g.createRadialGradient(px, py, R * 0.9, px, py, R * 2.3); halo.addColorStop(0, 'rgba(110,170,255,.22)'); halo.addColorStop(1, 'rgba(110,170,255,0)');
    g.fillStyle = halo; g.beginPath(); g.arc(px, py, R * 2.3, 0, 6.283); g.fill();
    const ring = (front) => {
      g.save(); g.translate(px, py); g.rotate(-0.36); g.scale(1, 0.24);
      const rg = g.createLinearGradient(-R * 2, 0, R * 2, 0); rg.addColorStop(0, 'rgba(150,200,255,0)'); rg.addColorStop(0.2, 'rgba(160,205,255,.5)'); rg.addColorStop(0.8, 'rgba(160,205,255,.5)'); rg.addColorStop(1, 'rgba(150,200,255,0)');
      g.strokeStyle = rg; g.lineWidth = R * 0.34; g.beginPath(); g.arc(0, 0, R * 1.75, front ? 0 : Math.PI, front ? Math.PI : Math.PI * 2); g.stroke();
      g.lineWidth = R * 0.1; g.strokeStyle = 'rgba(200,225,255,.45)'; g.beginPath(); g.arc(0, 0, R * 2.08, front ? 0 : Math.PI, front ? Math.PI : Math.PI * 2); g.stroke(); g.restore();
    };
    ring(false);
    const body = g.createRadialGradient(px - R * 0.45, py - R * 0.45, R * 0.1, px, py, R * 1.08);
    body.addColorStop(0, '#9fe0ff'); body.addColorStop(0.45, '#3f78d0'); body.addColorStop(1, '#0a1642');
    g.fillStyle = body; g.beginPath(); g.arc(px, py, R, 0, 6.283); g.fill();
    g.save(); g.beginPath(); g.arc(px, py, R, 0, 6.283); g.clip();
    for (let i = 0; i < 6; i++) { g.fillStyle = 'rgba(' + (i % 2 ? '255,255,255' : '20,40,110') + ',' + (0.06 + (i % 3) * 0.02) + ')'; g.fillRect(px - R, py - R * 0.8 + i * R * 0.3, R * 2, R * 0.15); }
    const sh = g.createRadialGradient(px + R * 0.55, py + R * 0.5, R * 0.2, px + R * 0.55, py + R * 0.5, R * 1.3); sh.addColorStop(0, 'rgba(2,6,24,0)'); sh.addColorStop(1, 'rgba(2,6,24,.72)');
    g.fillStyle = sh; g.fillRect(px - R, py - R, R * 2, R * 2); g.restore();
    ring(true);
    sky = cvs;
  }
  function drawSky(dt) {
    ensureAtmo();
    if (!sky || skyKey !== W + 'x' + H + 'x' + dpr) buildSky();
    c.setTransform(dpr, 0, 0, dpr, 0, 0);
    if (!skyEl) c.drawImage(sky, 0, 0, W, H);
    if (S.q === 0) return;
    const night = G.sky ? G.sky.now().night : 1;   // the stars fade out with the daylight (G.sky, sky.js)
    if (night < 0.03) return;
    const gl = A.glow('#cfe6ff');
    for (const st of stars) if (st.tw) { c.globalAlpha = night * st.a * (0.35 + 0.65 * (0.5 + 0.5 * Math.sin(T * st.sp * 2 + st.ph))); c.drawImage(gl, st.x * W - st.r * 3.4, st.y * H - st.r * 3.4, st.r * 6.8, st.r * 6.8); }
    c.globalAlpha = 1;
    if (S.q === 2 && night > 0.6) {
      shootNext -= dt;
      if (!shoot && shootNext <= 0) { shoot = { x: W * (0.1 + Math.random() * 0.5), y: H * (0.04 + Math.random() * 0.2), t: 0 }; shootNext = 8 + Math.random() * 8; }
      if (shoot) {
        shoot.t += dt; const k = shoot.t / 0.9;
        if (k >= 1) shoot = null;
        else {
          const x = shoot.x + k * 150, y = shoot.y + k * 62, g2 = c.createLinearGradient(x - 46, y - 19, x, y);
          g2.addColorStop(0, 'rgba(190,230,255,0)'); g2.addColorStop(1, 'rgba(235,248,255,' + (0.9 * (1 - k)) + ')');
          c.strokeStyle = g2; c.lineWidth = 1.6; c.beginPath(); c.moveTo(x - 46, y - 19); c.lineTo(x, y); c.stroke();
        }
      }
    }
  }
  function drawClouds(near) {
    if (!clouds || S.q === 0) return;
    for (const k of clouds) {
      if (k.near !== near) continue;
      const u = ((((k.x + T * k.v) % 1300) + 1300) % 1300) - 650, edge = U.clamp(1 - Math.abs(u) / 650, 0, 1);
      c.globalAlpha = k.a * Math.min(1, edge * 2.2);
      const w = 240 * k.s, h = 100 * k.s;
      c.drawImage(cloudSpr[k.spr], k.cx + u - w / 2, k.y + Math.sin(T * 0.25 + k.x) * 3 - h / 2, w, h);
    }
    c.globalAlpha = 1;
  }
  function drawRocks() {
    if (!rocks || !land || S.q === 0) return;
    const tip = land.tip, dep = land.depth, cx = (P(0, land.ly)[0] + P(land.lx, 0)[0]) / 2, half = (land.lx + land.ly) * 16;
    for (const r of rocks) {
      const x = cx + r.dx * half * 1.15, y = tip + r.dy * dep + Math.sin(T * 0.7 + r.ph) * 4, k = r.s;
      c.fillStyle = '#16233f'; c.beginPath(); c.moveTo(x - k, y - k * 0.2); c.lineTo(x - k * 0.2, y - k * 0.8); c.lineTo(x + k * 0.9, y - k * 0.3); c.lineTo(x + k * 0.3, y + k * 0.8); c.lineTo(x - k * 0.6, y + k * 0.5); c.closePath(); c.fill();
      c.fillStyle = '#0a1226'; c.beginPath(); c.moveTo(x + k * 0.9, y - k * 0.3); c.lineTo(x + k * 0.3, y + k * 0.8); c.lineTo(x - k * 0.2, y + k * 0.1); c.closePath(); c.fill();
      c.globalCompositeOperation = 'lighter'; c.globalAlpha = 0.45; c.drawImage(A.glow(A.palette(SKIN()).acc), x - k * 1.4, y + k * 0.4, k * 2.8, k * 2.2); c.globalAlpha = 1; c.globalCompositeOperation = 'source-over';
    }
  }
  function drawMotes() {
    if (!motes || !land || S.q === 0) return;
    const x0 = P(0, land.ly)[0], x1 = P(land.lx, 0)[0], y0 = P(0, 0)[1] - 70, y1 = land.tip - 30;
    const col = A.palette(SKIN()).acc, gl = A.glow(col), n = S.q === 1 ? 10 : motes.length;
    c.globalCompositeOperation = 'lighter';
    for (let i = 0; i < n; i++) {
      const m = motes[i], ph = (m.y - T * m.sp) % 1, y = U.lerp(y0, y1, ph < 0 ? ph + 1 : ph), x = U.lerp(x0, x1, m.x) + Math.sin(T * 0.6 + m.ph) * 10;
      c.globalAlpha = 0.5 * Math.sin(((ph < 0 ? ph + 1 : ph)) * Math.PI);
      c.drawImage(gl, x - m.r * 0.5, y - m.r * 0.5, m.r, m.r);
    }
    c.globalAlpha = 1; c.globalCompositeOperation = 'source-over';
  }

  /* ---------- labels above buildings, build slots and income popups ---------- */
  const toScreen = (wx, wy) => [(wx - cam.x) * cam.z + W / 2, (wy - cam.y) * cam.z + H / 2 + oy()];
  const canUp = (k) => G.canBuild(k);
  function tw(text) { const k = c.font + '|' + text; return textW[k] || (textW[k] = c.measureText(text).width); }
  const clip = (t, n) => (t.length > n ? t.slice(0, n - 1) + '…' : t);
  const inter = (x, y, w, h, r) => Math.max(0, Math.min(x + w, r.x + r.w) - Math.max(x, r.x)) * Math.max(0, Math.min(y + h, r.y + r.h) - Math.max(y, r.y));
  /* ---------- a chat window floating above the HQ: the product your customers actually use ---------- */
  const CHAT = [
    ['Plan a 3-day trip to Kyoto', 'Day 1: sunrise at the temple gates…'], ['Explain black holes simply', 'Think of a drain in space…'],
    ['Fix my Python bug', 'Found it: line 12 never ends.'], ['Draft a polite email', 'Here is a friendly version…'],
    ['Summarize this report', 'Three takeaways: growth, risk…'], ['Help me learn guitar', 'Start with three easy chords…']
  ];
  const CHAT_LEN = 9;
  const chat = { t: 0, i: 0, rect: null };
  // Where the bubble goes this frame (labels use the rectangle to stay clear of it), or null when it should not show.
  function chatPlan() {
    chat.rect = null;
    if (!showAll() || S.q === 0 || cam.z < 0.42 || !G.C || G.C.served < 1) return null;
    const hq = items.find((e) => e.obj.kind === 'hq');
    if (!hq) return null;
    const b = hq.obj.b, p = toScreen((b[0] + b[2]) / 2 + 24, b[1] + 4), w = 154, h = 50;
    chat.rect = { x: clamp(p[0] - 12, 6, W - w - 6), y: Math.max(inset.t + 6, p[1] - h - 26), w, h, chat: true };
    return chat.rect;
  }
  function drawChat(dt) {
    const r = chat.rect;
    if (!r) return;
    chat.t += dt;
    if (chat.t >= CHAT_LEN) { chat.t -= CHAT_LEN; chat.i = (chat.i + 1) % CHAT.length; }
    const k = chat.t, q = CHAT[chat.i][0], a = CHAT[chat.i][1];
    c.setTransform(dpr, 0, 0, dpr, 0, 0);
    c.globalAlpha = 0.96 * (k < 0.4 ? k / 0.4 : k > CHAT_LEN - 0.7 ? (CHAT_LEN - k) / 0.7 : 1);
    c.fillStyle = 'rgba(6,11,28,.86)'; rrect(r.x, r.y, r.w, r.h, 12); c.fill();
    c.lineWidth = 1; c.strokeStyle = 'rgba(190,215,255,.24)'; c.stroke();
    c.beginPath(); c.moveTo(r.x + 18, r.y + r.h - 0.5); c.lineTo(r.x + 30, r.y + r.h - 0.5); c.lineTo(r.x + 20, r.y + r.h + 7); c.closePath(); c.fillStyle = 'rgba(6,11,28,.86)'; c.fill();
    c.font = '600 9.5px Inter, system-ui, sans-serif'; c.textBaseline = 'middle'; c.textAlign = 'left';
    const you = clip(q, 27), yw = c.measureText(you).width + 14;
    c.fillStyle = 'rgba(61,214,198,.92)'; rrect(r.x + r.w - 6 - yw, r.y + 6, yw, 17, 8.5); c.fill();
    c.fillStyle = '#04211f'; c.fillText(you, r.x + r.w - 6 - yw + 7, r.y + 15);
    if (k > 1.1) {
      const typed = k < 2.5 ? '' : a.slice(0, Math.floor((k - 2.5) * 16)), txt = clip(typed, 30), aw = typed ? Math.min(r.w - 12, c.measureText(txt).width + 14) : 34;
      c.fillStyle = 'rgba(255,255,255,.12)'; rrect(r.x + 6, r.y + 27, aw, 17, 8.5); c.fill();
      if (typed) { c.fillStyle = '#eef3ff'; c.fillText(txt, r.x + 13, r.y + 36); }
      else for (let i = 0; i < 3; i++) { c.fillStyle = 'rgba(220,235,255,' + (0.35 + 0.5 * Math.max(0, Math.sin(T * 7 - i * 0.9))) + ')'; c.beginPath(); c.arc(r.x + 15 + i * 6, r.y + 36 - Math.max(0, Math.sin(T * 7 - i * 0.9)) * 1.6, 1.7, 0, 6.283); c.fill(); }
    }
    c.globalAlpha = 1; c.textBaseline = 'alphabetic';
  }

  // A small warning badge over the building that is the problem: servers overloaded, too little power, too little cooling.
  // It is the picture version of the warnings on the dock, so a problem can be spotted without reading anything.
  function drawAlerts() {
    const C = G.C;
    if (!C || !showAll() || S.q === 0 || cam.z < 0.3) return;
    const list = [];
    if (C.powerRatio < 0.97) list.push({ kind: 'pwr', glyph: 'bolt', col: '#ffb347' });
    if (C.overheat > 0.02) list.push({ kind: 'cool', glyph: 'snow', col: '#7fd6ff' });
    if (C.util > 1.02) list.push({ kind: 'dc', glyph: 'bang', col: '#ff6b81' });
    if (!list.length) return;
    c.setTransform(dpr, 0, 0, dpr, 0, 0);
    for (const al of list) {
      let e = null; for (const it of items) if (it.obj.kind === al.kind && it.obj.b && (!e || (it.obj.lv || 0) >= (e.obj.lv || 0))) e = it;
      if (!e) continue;
      const b = e.obj.b, p = toScreen(b[2] - (b[2] - b[0]) * 0.2, b[1] + 26), x = p[0], y = p[1] - 10 + Math.sin(T * 4 + b[0]) * 2;
      c.fillStyle = 'rgba(14,8,22,.92)'; c.beginPath(); c.arc(x, y, 11, 0, 6.283); c.fill();
      c.lineWidth = 2; c.strokeStyle = al.col; c.stroke();
      c.strokeStyle = al.col; c.fillStyle = al.col; c.lineWidth = 2; c.lineCap = 'round'; c.lineJoin = 'round';
      c.beginPath();
      if (al.glyph === 'bolt') { c.moveTo(x + 2, y - 7); c.lineTo(x - 4, y + 1); c.lineTo(x, y + 1); c.lineTo(x - 2, y + 7); c.lineTo(x + 4, y - 2); c.lineTo(x, y - 2); c.closePath(); c.fill(); }
      else if (al.glyph === 'snow') { for (let k = 0; k < 3; k++) { const a = (k * Math.PI) / 3; c.moveTo(x - Math.cos(a) * 6, y - Math.sin(a) * 6); c.lineTo(x + Math.cos(a) * 6, y + Math.sin(a) * 6); } c.lineWidth = 1.6; c.stroke(); }
      else { c.moveTo(x, y - 6); c.lineTo(x, y + 1.5); c.stroke(); c.beginPath(); c.arc(x, y + 5.2, 1.5, 0, 6.283); c.fill(); }
      c.lineCap = 'butt'; c.lineJoin = 'miter';
    }
  }

  function drawLabels() {
    labelRects.length = 0;
    chat.rect = null;
    if (cam.z < 0.28) return;
    c.setTransform(dpr, 0, 0, dpr, 0, 0);
    c.font = FONT; c.textBaseline = 'middle';
    const s = G.state, want = [];
    // The HQ screen tags the three main buildings. An Upgrades list tags the kind of building that list is about.
    for (const kind of showAll() ? ['hq', 'lab', 'dc'] : [FOCUS[S.view][0]]) {
      let e = null; for (const it of items) if (it.obj.kind === kind && (!e || (it.obj.lv || 0) >= (e.obj.lv || 0))) e = it;
      if (e) want.push({ e, name: D.ladders[kind][s.inf[kind]].name, lv: s.inf[kind] + 1, up: canUp(kind) });
    }
    if (showAll()) for (const g of ghosts) { const t = G.ladderNext('lab'); want.push({ e: g, name: 'Build a research lab', lv: 0, up: canUp('lab'), cost: t ? G.ladderCost(t) : 0, ghost: true }); }
    // screen rectangles of every building, so a label can pick the spot that hides the least
    const boxes = [];
    for (const e of items) {
      const b = e.obj.b; if (!b || e.obj.kind === 'site') continue;
      const p0 = toScreen(b[0], b[1] + 14), p1 = toScreen(b[2], b[3] - 6);
      boxes.push({ e, x: p0[0], y: p0[1], w: p1[0] - p0[0], h: p1[1] - p0[1] });
    }
    const placed = [], acc = A.palette(SKIN()).acc, topMin = showAll() ? Math.max(W > H ? 64 : 80, inset.t + 6) : 8;
    const cr = chatPlan(); if (cr) placed.push(cr); // labels keep out of the chat bubble's way
    for (const w of want) {
      const o = w.e.obj;
      let top, front;
      if (w.ghost) {
        const m = P(o.fp[0] + o.fp[2] / 2, o.fp[1] + o.fp[3] / 2), q = toScreen(m[0], m[1] - 18), fr = P(o.fp[0] + o.fp[2], o.fp[1] + o.fp[3]);
        top = q; front = toScreen(fr[0], fr[1]);
      } else {
        const b = o.b, f = o.fp, fr = P(f[0] + f[2], f[1] + f[3]);
        top = toScreen((b[0] + b[2]) / 2, b[1] + 10); front = toScreen(fr[0], fr[1]);
      }
      const name = clip(w.name, 27), sub = w.ghost ? U.money(w.cost) : 'Lv ' + w.lv, upW = w.up ? 20 : 0;
      const tW = tw(name), sW = (c.font = '700 9.5px Inter, system-ui, sans-serif', tw(sub)); c.font = FONT;
      const pw = 10 + tW + 8 + sW + 8 + upW, ph = 22, bob = w.up ? Math.sin(T * 3) * 2 : 0;
      const cands = [{ x: top[0] - pw / 2, y: top[1] - ph - 9 - bob, ax: top[0], down: true, bias: 0 }];
      if (front) cands.push({ x: front[0] - pw / 2, y: front[1] + 9 + bob, ax: front[0], down: false, bias: 1.2 });
      let best = null;
      for (const cd of cands) {
        cd.x = U.clamp(cd.x, 4, W - pw - 4); cd.y = Math.max(topMin, cd.y);
        let sc = cd.bias;
        for (const bx of boxes) if (bx.e !== w.e) sc += inter(cd.x, cd.y, pw, ph, bx) / 260;
        for (const r of placed) sc += inter(cd.x, cd.y, pw, ph, r) / 40;
        if (cd.y + ph > H - inset.b - 8) sc += 50;
        if (!best || sc < best.sc) best = Object.assign(cd, { sc });
      }
      // still touching another label? slide it away from it
      for (let i = 0; i < 4; i++) {
        let hit = false;
        for (const r of placed) if (inter(best.x, best.y, pw, ph, r) > 0 || (best.x < r.x + r.w + 3 && best.x + pw + 3 > r.x && Math.abs(best.y - r.y) < ph + 3)) { best.y += best.down ? -(ph + 4) : ph + 4; hit = true; break; }
        if (!hit) break;
      }
      best.y = Math.max(topMin, best.y);
      const x = best.x, y = best.y, ax = U.clamp(best.ax, x + 12, x + pw - 12), hot = w.up;
      c.fillStyle = 'rgba(6,11,28,.86)'; rrect(x, y, pw, ph, 11); c.fill();
      c.lineWidth = 1; c.strokeStyle = hot ? 'rgba(246,184,74,.85)' : 'rgba(190,215,255,.26)'; c.stroke();
      c.fillStyle = 'rgba(6,11,28,.86)'; c.beginPath();
      if (best.down) { c.moveTo(ax - 5, y + ph - 0.5); c.lineTo(ax + 5, y + ph - 0.5); c.lineTo(ax, y + ph + 5); } else { c.moveTo(ax - 5, y + 0.5); c.lineTo(ax + 5, y + 0.5); c.lineTo(ax, y - 5); }
      c.closePath(); c.fill();
      c.fillStyle = '#eef3ff'; c.textAlign = 'left'; c.fillText(name, x + 10, y + ph / 2 + 0.5);
      c.font = '700 9.5px Inter, system-ui, sans-serif'; c.fillStyle = w.ghost ? '#f6b84a' : acc; c.fillText(sub, x + 10 + tW + 8, y + ph / 2 + 0.5); c.font = FONT;
      if (w.up) {
        const ux = x + pw - 14, uy = y + ph / 2, pulse = 0.5 + 0.5 * Math.sin(T * 4);
        c.fillStyle = 'rgba(246,184,74,' + (0.75 + 0.25 * pulse) + ')'; c.beginPath(); c.arc(ux, uy, 7.5, 0, 6.283); c.fill();
        c.strokeStyle = '#2b1b00'; c.lineWidth = 1.8; c.lineCap = 'round'; c.beginPath(); c.moveTo(ux, uy + 3); c.lineTo(ux, uy - 3); c.moveTo(ux - 3, uy - 0.2); c.lineTo(ux, uy - 3.2); c.lineTo(ux + 3, uy - 0.2); c.stroke(); c.lineCap = 'butt';
      }
      const rect = { x, y, w: pw, h: ph, e: w.e, obj: o };
      placed.push(rect); labelRects.push(rect);
    }
    c.textBaseline = 'alphabetic';
  }
  function drawGhosts() {
    if (!showAll()) return;
    for (const g of ghosts) {
      const f = g.fp, pts = [P(f[0], f[1]), P(f[0] + f[2], f[1]), P(f[0] + f[2], f[1] + f[3]), P(f[0], f[1] + f[3])], pulse = 0.5 + 0.5 * Math.sin(T * 2.2);
      c.fillStyle = 'rgba(61,214,198,' + (0.06 + 0.08 * pulse) + ')'; c.beginPath(); pts.forEach((p, i) => (i ? c.lineTo(p[0], p[1]) : c.moveTo(p[0], p[1]))); c.closePath(); c.fill();
      c.strokeStyle = 'rgba(120,240,225,' + (0.5 + 0.3 * pulse) + ')'; c.lineWidth = 1.6; c.setLineDash([7, 6]); c.lineDashOffset = -T * 8; c.stroke(); c.setLineDash([]); c.lineDashOffset = 0;
      const m = P(f[0] + f[2] / 2, f[1] + f[3] / 2);
      c.strokeStyle = 'rgba(160,250,238,.9)'; c.lineWidth = 2.4; c.lineCap = 'round'; c.beginPath(); c.moveTo(m[0] - 9, m[1]); c.lineTo(m[0] + 9, m[1]); c.moveTo(m[0], m[1] - 5); c.lineTo(m[0], m[1] + 5); c.stroke(); c.lineCap = 'butt';
    }
  }
  function drawPopups(dt) {
    if (!G.C || S.q === 0 || !showAll()) return;
    popAcc += dt;
    const hqE = items.find((e) => e.obj.kind === 'hq');
    if (popAcc > 1.9 && hqE) {
      popAcc = 0;
      const net = G.C.net;
      if (Math.abs(net) > 1e-9) { const b = hqE.obj.b; popups.push({ t: 0, x: (b[0] + b[2]) / 2 + (Math.random() - 0.5) * 30, y: b[1] + 74, v: net * 1.9 }); }
    }
    c.setTransform(dpr, 0, 0, dpr, 0, 0);
    c.font = '700 13px Inter, system-ui, sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle';
    for (let i = popups.length - 1; i >= 0; i--) {
      const p = popups[i]; p.t += dt;
      if (p.t > 1.7) { popups.splice(i, 1); continue; }
      const q = toScreen(p.x, p.y), k = p.t / 1.7, a = k < 0.15 ? k / 0.15 : 1 - Math.pow((k - 0.15) / 0.85, 1.6), txt = (p.v >= 0 ? '+' : '-') + U.money(Math.abs(p.v));
      c.globalAlpha = Math.max(0, a); c.lineWidth = 3.4; c.strokeStyle = 'rgba(4,8,20,.85)'; c.strokeText(txt, q[0], q[1] - k * 34);
      c.fillStyle = p.v >= 0 ? '#ffd27a' : '#ff8798'; c.fillText(txt, q[0], q[1] - k * 34);
    }
    c.globalAlpha = 1; c.textAlign = 'left'; c.textBaseline = 'alphabetic';
  }

  /* ---------- frame ---------- */
  S.render = function (nowMs) {
    if (!cv || !c || !G.state) return 0;
    const t0 = performance.now();
    const dt = lastT ? U.clamp((nowMs - lastT) / 1000, 0, 0.1) : 0.033;   // never negative, even if the clock steps back
    lastT = nowMs; T += dt; frames++;
    S.resize();
    if (frames % 15 === 1) S.sync();
    if (cam.hold && T >= cam.hold) { cam.hold = 0; if (!cam.manual) S.fit(false, true); }   // the scene is over: back to the whole campus
    // a camera move that a scene asked for is slower and softer than the usual fit
    const k = 1 - Math.exp(-dt * (cam.hold ? 2.2 : 5));
    cam.x += (cam.tx - cam.x) * (cam.manual ? 0 : k); cam.y += (cam.ty - cam.y) * (cam.manual ? 0 : k); cam.z += (cam.tz - cam.z) * (cam.manual ? 0 : k);
    fillFrame(dt);
    if (G.sky) G.sky.update();
    c.setTransform(1, 0, 0, 1, 0, 0);
    c.clearRect(0, 0, cv.width, cv.height);
    drawSky(dt);
    run('sky');
    const z = cam.z * dpr;
    c.setTransform(z, 0, 0, z, dpr * W / 2 - cam.x * z, dpr * (H / 2 + oy()) - cam.y * z);
    c.imageSmoothingQuality = 'medium';
    if (land) {
      const sP = P(land.lx, land.ly);
      const gx = (P(land.lx, 0)[0] + P(0, land.ly)[0]) / 2, gy = (P(0, 0)[1] + sP[1]) / 2 + 30, gr = (land.lx + land.ly) * 20;
      const gg = c.createRadialGradient(gx, gy, 0, gx, gy, gr);
      gg.addColorStop(0, 'rgba(61,214,198,.16)'); gg.addColorStop(1, 'rgba(61,214,198,0)');
      c.fillStyle = gg; c.fillRect(gx - gr, gy - gr, gr * 2, gr * 2);
      // soft glow from the crystals below the island
      c.globalCompositeOperation = 'lighter'; c.globalAlpha = 0.5 + 0.12 * Math.sin(T * 1.4);
      c.drawImage(A.glow(A.palette(SKIN()).acc), gx - gr * 0.9, land.tip + land.depth * 0.25, gr * 1.8, land.depth * 1.15);
      c.globalAlpha = 1; c.globalCompositeOperation = 'source-over';
      drawClouds(false);
      run('back');
      c.drawImage(land.cv, land.x, land.y, land.w, land.h);
      drawRocks();
      drawGhosts();
      drawFocus();
      run('ground');
    }
    drawFlow(dt);
    // sorted draw of buildings, trees and whatever walks or drives between them
    const dl = [];
    for (const e of items) dl.push([e.depth, 0, e]);
    if (decor) for (const d of decor) if (land && d.x < land.lx - 0.3 && d.y < land.ly - 0.3 && !blocked(d.x, d.y)) dl.push([d.x + d.y + 0.3, 1, d]);
    run('actors', dl);
    dl.sort((a, b) => a[0] - b[0]);
    liveEnv();
    for (const [, kind, o] of dl) {
      if (kind === 0) drawItem(o);
      else if (kind === 1) drawTree(o);
      else o(c);
    }
    drawSites();
    if (S.q > 0) drawGlows();
    if (pickObj && T - pickT < 4) {
      const e = pickObj, a = 0.5 + 0.3 * Math.sin(T * 5);
      c.strokeStyle = 'rgba(120,255,235,' + a + ')'; c.lineWidth = 2.2; c.beginPath();
      e.poly.forEach((p, i) => (i ? c.lineTo(p[0], p[1]) : c.moveTo(p[0], p[1]))); c.closePath(); c.stroke();
    }
    run('air');
    drawClouds(true);
    drawMotes();
    run('grade');
    toScreenSpace();
    drawLabels();
    drawAlerts();
    drawChat(dt);
    drawPopups(dt);
    run('hud');
    return performance.now() - t0;
  };
  // trees sway a little in the wind; the picture is sheared around the foot of the trunk
  function drawTree(o) {
    const p = P(o.x, o.y);
    if (S.q === 0) { A.tree(c, p[0], p[1], o.s, o.col); return; }
    const k = Math.sin(T * 1.25 + o.x * 1.7 + o.y * 0.9) * 0.04 + Math.sin(T * 0.45 + o.y) * 0.02;
    c.save(); c.transform(1, 0, k, 1, -k * p[1], 0);
    A.tree(c, p[0], p[1], o.s, o.col);
    c.restore();
  }
  function blocked(x, y) {
    for (const e of items) { const f = e.obj.fp; if (x > f[0] - 0.9 && x < f[0] + f[2] + 0.9 && y > f[1] - 0.9 && y < f[1] + f[3] + 0.9) return true; }
    for (const r of roads) { if (Math.abs(r[1] - r[3]) < 0.01 ? (Math.abs(y - r[1]) < 0.9 && x > r[0] - 0.5 && x < r[2] + 0.5) : (Math.abs(x - r[0]) < 0.9 && y > r[1] - 0.5 && y < r[3] + 0.5)) return true; }
    for (const sx of sites) { const f = sx.fp; if (x > f[0] - 1 && x < f[0] + f[2] + 1 && y > f[1] - 1 && y < f[1] + f[3] + 1) return true; }
    return false;
  }
  S.itemInfo = function (obj) { return obj; };
  S.getCam = () => cam;
  S.__dbg = () => { let px = 0, n = 0; for (const k in cache) { const e = cache[k]; px += e.spr.cv.width * e.spr.cv.height; n++; if (e.led) for (const l of e.led) { px += l.cv.width * l.cv.height; n++; } } if (land) { px += land.cv.width * land.cv.height; n++; } return { sprites: n, megapixels: +(px / 1e6).toFixed(2), mb: +(px * 4 / 1048576).toFixed(1), res: A.res, q: S.q, dpr }; };
})();
