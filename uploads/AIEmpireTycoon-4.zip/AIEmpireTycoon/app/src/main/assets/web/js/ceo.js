/* AI Empire Tycoon - Lumo, the AI CEO (autopilot). No DOM access in this file.
   Lumo runs the company the way a sensible player would and says what it is doing, so the game is fun to watch and needs no menus.
   It builds on the economy advisor (advisor.js): every decision is a "what would this do to my income" question answered by running the
   real economy, so Lumo can never disagree with what the game then does.

   Life of one decision (times are real seconds, shortened a little when the game runs at 2x or 4x):
     idle  ->  decide()  ->  think (Lumo flies to the building and says what it is about to do)  ->  act  ->  idle
   Events other parts of the game listen to:  ceo_plan {plan}   ceo_do {plan, ok, effect}   ceo_say {text, mood, target}  */
(function () {
  'use strict';
  const G = window.G, D = G.D, U = G.U;
  const ceo = (G.ceo = {});
  const assign = (s, ...p) => Object.assign({}, s, ...p);

  /* ---------- personalities ---------- */
  // reserve: seconds of running costs kept in cash.  payback: longest wait (seconds of extra income) before an optional purchase has
  // earned its price back.  fac: how many times its price the cash must be before Lumo builds an office or a lab.
  ceo.STYLES = {
    cautious: { name: 'Cautious', note: 'Keeps a big cash cushion and only buys sure things.', reserve: 120, payback: 1800, fac: 2.4 },
    balanced: { name: 'Balanced', note: 'A sensible mix of saving and growing.', reserve: 45, payback: 5400, fac: 1.4 },
    bold: { name: 'Bold', note: 'Spends almost everything on growth.', reserve: 8, payback: 14400, fac: 1.05 }
  };
  // what Lumo is allowed to manage (the player can switch each part off and do it by hand)
  ceo.ALLOW = [['servers', 'Servers and racks'], ['build', 'Buildings'], ['research', 'Research'], ['models', 'AI models'], ['regions', 'New regions'], ['deals', 'Enterprise deals'], ['levers', 'Price and marketing']];
  const cs = () => G.state.ceo;
  const cfg = () => ceo.STYLES[cs().style] || ceo.STYLES.balanced;
  const IDLE_GAP = 2.6;   // seconds between decisions
  const rt = (ceo.rt = { acc: IDLE_GAP, phase: 'idle', plan: null, wait: 0, chat: 14, lastPrice: -1e9, lastMkt: -1e9, saving: null, thought: '', mood: 'happy', moodUntil: 0, t: 0, said: '' });
  const speedK = () => Math.sqrt(Math.max(1, (G.state && G.state.speed) || 1));
  const pick = (a) => a[Math.floor(Math.random() * a.length)];
  const plural = (n, w) => n + ' ' + w + (n === 1 ? '' : 's');
  const lower = (t) => t.charAt(0).toLowerCase() + t.slice(1);

  /* ---------- state of mind ---------- */
  ceo.enabled = () => !!(G.state && G.state.ceo && G.state.ceo.on);
  ceo.plan = () => rt.plan;
  ceo.saving = () => rt.saving;
  ceo.thought = () => rt.thought;
  ceo.react = function (mood, secs) { rt.mood = mood; rt.moodUntil = rt.t + (secs || 3); };
  ceo.mood = function () {
    const s = G.state, C = G.C;
    if (!C) return 'happy';
    if (rt.t < rt.moodUntil) return rt.mood;
    if (rt.phase === 'think') return 'thinking';
    if (C.sr < 0.9 || C.overheat > 0.1 || C.powerRatio < 0.9 || C.net < 0) return 'worried';
    if (s.hype > 1.2) return 'excited';
    return 'happy';
  };
  ceo.log = function (kind, text, effect) {
    const l = cs().log;
    l.unshift({ t: Date.now(), k: kind, x: text, d: effect || '' });
    if (l.length > 40) l.length = 40;
  };
  ceo.say = function (text, mood, target) {
    rt.said = text;
    if (mood) ceo.react(mood, 3.5);
    G.emit('ceo_say', { text, mood: mood || ceo.mood(), target: target || null });
  };

  /* ---------- research: which project is worth starting ---------- */
  // The first project that can be started on the way to `id` (id itself when it is ready), or null.
  function firstReady(id, depth) {
    const st = G.researchStatus(id);
    if (st === 'ready') return id;
    if (st !== 'locked' || (depth || 0) > 12) return null;
    for (const r of D.rmap[id].req) if (!G.state.res.done[r]) { const f = firstReady(r, (depth || 0) + 1); if (f) return f; }
    return null;
  }
  // research that unlocks the next model, the next server tier and the next level of each building
  function gateIds(extra) {
    const s = G.state, out = Object.assign({}, extra);
    const mark = (id) => { const r = firstReady(id); if (r) out[r] = 1; };
    const nm = D.models.find((m) => !s.models[m.id]);
    if (nm) nm.req.forEach((r) => { if (!s.res.done[r]) mark(r); });
    const nh = D.hw.find((h) => h.req && !s.res.done[h.req]);
    if (nh) mark(nh.req);
    for (const k of ['cool', 'pwr', 'net', 'dc', 'hq', 'lab']) { const nx = G.ladderNext(k); if (nx && nx.req && !s.res.done[nx.req]) mark(nx.req); }
    return out;
  }
  const USEFUL = ['intel', 'appeal', 'trainSpeed', 'trainCost', 'dem', 'cap', 'util', 'serve', 'conv', 'growth', 'sat', 'ent', 'entSlots', 'api', 'img', 'agent', 'resSpeed', 'resSlots', 'net', 'cool', 'pw', 'opex', 'rev', 'flag'];
  const useful = (e) => USEFUL.some((k) => k in e);

  /* ---------- candidates ---------- */
  // Every candidate looks like an advisor suggestion and adds: cat (the part of the company it belongs to), tier (lower = more urgent),
  // target (the building Lumo flies to), rate (extra income per dollar) and must (research that unlocks something: payback does not matter).
  const TARGET = { servers: 'dc', research: 'lab', models: 'lab', levers: 'hq', deals: 'hq', regions: 'net', build: 'hq' };
  function fromCoach(t) {
    const id = t.id;
    let tier = 5, cat = 'build', target = null;
    if (id.indexOf('rel-') === 0) { tier = 0; cat = 'models'; }
    else if (id === 'ads') { tier = 1; cat = 'levers'; }
    else if (id === 'price') { tier = 1; cat = 'levers'; }
    else if (id === 'mkt') { tier = 3; cat = 'levers'; }
    else if (id === 'cap-servers' || id === 'cap-racks') { tier = 1; cat = 'servers'; }
    else if (id.indexOf('cap-') === 0) { tier = 1; cat = 'build'; target = id.slice(4); }
    else if (id.indexOf('train-') === 0) { tier = 2; cat = 'models'; }
    else if (id.indexOf('ent-') === 0) { tier = 3; cat = 'deals'; }
    else if (id.indexOf('reg-') === 0) { tier = 3; cat = 'regions'; }
    else if (id === 'tune') { tier = 4; cat = 'models'; }
    return Object.assign({ cat, tier, target: target || TARGET[cat], rate: t.head > 0 && t.cost > 0 ? t.head / t.cost : t.head > 0 ? 1e9 : 0, src: 'coach' }, t);
  }

  function researchCands(x, gates, out) {
    const s = x.s, C = x.b0, P = G.adv.patch;
    const busy = s.res.q.length >= C.resSlots;
    for (const n of D.research) {
      if (G.researchStatus(n.id) !== 'ready') continue;
      const gate = !!gates[n.id], cost = G.researchCost(n);
      const w = x.what((st) => assign(st, P.done(st, n.id)));
      const gain = Math.max(w.now.net, w.soon.net, 0);
      if (!gate && !(gain > 0) && !useful(n.eff)) continue;
      out.push({ id: 'ru-' + n.id, icon: n.icon || 'research', title: 'Research ' + n.name, cost, head: gain, rate: gain > 0 ? gain / Math.max(1, cost) : 0, payback: gain > 0 ? cost / gain : 0,
        enabler: false, must: gate, tier: gate ? 2 : gain > 0 ? 2.4 : 4.5, cat: 'research', target: 'lab', src: 'research', util: !gate && !(gain > 0),
        blocked: busy ? 'All research slots are busy' : null, run: () => G.act.research(n.id) });
    }
  }

  // The cheapest way to get `wantTf` more free server power right now (or the best server for the money when it cannot be reached)
  function serverBuy(x, wantTf) {
    const s = x.s, C = x.b0, P = G.adv.patch, room = C.slotsTotal - C.slotsUsed;
    if (room <= 0) return null;
    let best = null;
    for (const h of D.hw) {
      if (!G.hwUnlocked(h.k)) continue;
      const one = x.quick((st) => assign(st, P.hw(st, h.k, 1, G.hwCost(h.k, 1))));
      const per = one.after.capAvail - C.capAvail;
      if (!(per > 0)) continue;
      let n = Math.max(1, Math.min(room, 12, Math.ceil(wantTf / per)));
      while (n > 1 && G.hwCost(h.k, n) > s.cash) n--;
      const cost = G.hwCost(h.k, n);
      const cand = { h, n, cost, per, afford: s.cash >= cost, unit: cost / (per * n) };
      if (!best || (cand.afford && !best.afford) || (cand.afford === best.afford && cand.unit < best.unit)) best = cand;
    }
    return best;
  }
  // Free server power is needed (to train a model, for example): servers, then racks, then a bigger data center
  function computeCand(x, need) {
    const s = x.s, C = x.b0, base = { head: 0, rate: 1e3, payback: 0, enabler: true, tier: 1.5, blocked: null };
    const b = serverBuy(x, Math.max(1, need));
    if (b) return Object.assign({ id: 'cmp-hw', icon: 'cpu', title: 'Add ' + plural(b.n, b.h.name), cost: b.cost, cat: 'servers', target: 'dc', src: 'cmp', run: () => G.act.buyHw(b.h.k, b.n) }, base);
    const rackRoom = C.rackCap - s.inf.racks;
    if (rackRoom > 0) { const n = Math.min(rackRoom, 2); return Object.assign({ id: 'cmp-rack', icon: 'cpu', title: 'Add ' + plural(n, 'server rack'), cost: G.rackCost(n), cat: 'servers', target: 'dc', src: 'cmp', run: () => G.act.buyRack(n) }, base); }
    const nx = G.ladderNext('dc');
    if (nx && !G.building('dc') && !(nx.req && !s.res.done[nx.req])) return Object.assign({ id: 'cmp-dc', icon: 'infra', title: 'Build a ' + nx.name, cost: G.ladderCost(nx), cat: 'build', target: 'dc', src: 'cmp', run: () => G.act.build('dc') }, base);
    return null;
  }

  // Better servers in place of weak ones when every rack slot is taken
  function modernize(x, out) {
    const s = x.s, C = x.b0, P = G.adv.patch;
    if (C.slotsTotal - C.slotsUsed > 0) return;
    let best = null;
    for (let i = D.hw.length - 1; i >= 1; i--) {
      const h = D.hw[i];
      if (!G.hwUnlocked(h.k)) continue;
      const low = D.hw.find((q) => q.tf < h.tf && (s.inf[q.k] || 0) > 0);
      if (!low) continue;
      const price = G.unitPrice(h.k, s.inf[h.k]), back = 0.5 * G.unitPrice(low.k, s.inf[low.k] - 1);
      if (!(price > back)) continue;
      const n = Math.max(1, Math.min(s.inf[low.k], Math.floor(s.cash / Math.max(1, price * 1.04)), 16));
      const cost = Math.max(0, (price - back) * n);
      const w = x.what((st) => assign(st, P.inf(st, { [low.k]: st.inf[low.k] - n, [h.k]: (st.inf[h.k] || 0) + n }, cost)));
      const gain = Math.max(w.now.net, w.soon.net);
      if (!(gain > 0)) continue;
      const cand = { h, low, n, cost, gain, rate: gain / Math.max(1, cost) };
      if (!best || cand.rate > best.rate) best = cand;
    }
    if (!best) return;
    const { h, low, n, cost, gain } = best, hurt = C.sr < 0.985;
    out.push({ id: 'mod-' + h.k, icon: 'cpu', title: 'Swap ' + plural(n, low.name) + ' for ' + h.name + (n > 1 ? 's' : ''), cost, head: gain, rate: best.rate, payback: cost / gain, enabler: hurt, tier: hurt ? 1 : 3, cat: 'servers', target: 'dc', src: 'mod', blocked: null,
      run: () => G.act.upgradeHw(h.k, n) });
  }

  // Buildings the coach does not suggest by itself: network, office and lab
  function facilities(x, out) {
    const s = x.s, P = G.adv.patch;
    for (const k of ['net', 'lab', 'hq']) {
      const nx = G.ladderNext(k);
      if (!nx || G.building(k) || (nx.req && !s.res.done[nx.req])) continue;
      const cost = G.ladderCost(nx);
      let gain = 0;
      if (k === 'net') {
        const w = x.what((st) => assign(st, P.inf(st, { net: st.inf.net + 1 }, cost)));
        gain = Math.max(w.now.net, w.soon.net);
        if (!(gain > 0)) continue;
      }
      out.push({ id: 'fac-' + k, icon: D.ladderMeta[k].icon, title: 'Build ' + nx.name, cost, head: gain, rate: gain > 0 ? gain / cost : 0, payback: gain > 0 ? cost / gain : 0, enabler: false, tier: k === 'net' ? 3 : 3.8,
        cat: 'build', target: k, src: 'fac', blocked: null, fac: k !== 'net', early: k === 'hq' && s.inf.hq === 0, run: () => G.act.build(k) });
    }
  }

  /* ---------- the decision ---------- */
  function decide() {
    const s = G.state, C = G.C, x = G.adv.ctx(), st = cfg(), al = cs().allow;
    const reserve = Math.max(4, C.exp.total * st.reserve), cash = s.cash;
    const list = [], gates = {};
    const free = C.capEff - C.ctf;
    for (const t of G.adv.coach()) {
      if (t.id.indexOf('res-') === 0 || t.id.indexOf('unlock-') === 0) continue;   // research is chosen below, by what it unlocks
      const c = fromCoach(t);
      if (c.blocked) {
        const m = /^Research (.+) first$/.exec(c.blocked), n = m && D.research.find((r) => r.name === m[1]), id = n && firstReady(n.id);
        if (id) gates[id] = 1;                                                   // the building or server waits for this research
        else if (/free server power/.test(c.blocked)) {
          const mid = t.id.indexOf('train-') === 0 ? D.mmap[t.id.slice(6)].tf : t.id === 'tune' ? (G.tuneInfo(s.active) || { tf: 0 }).tf : 0;
          const cc = mid ? computeCand(x, mid - free) : null;
          if (cc) list.push(cc);
        }
      }
      list.push(c);
    }
    researchCands(x, gateIds(gates), list);
    modernize(x, list);
    facilities(x, list);
    const pool = list.filter((c) => al[c.cat]);
    pool.sort((a, b) => a.tier - b.tier || (b.rate - a.rate));

    // Is it worth buying right now?
    const okay = (c) => {
      if (c.blocked || c.cost > cash) return false;
      if (c.cost > 0 && !c.enabler && cash - c.cost < reserve) return false;
      if (c.id === 'mkt') return c.head >= 0.03 * Math.max(0.01, C.net) && cash > reserve * 3 && C.sr > 0.97 && C.rev.total > 3 && rt.t - rt.lastMkt > 180;
      if (c.id === 'price') return c.head >= 0.04 * Math.max(0.01, C.net) && rt.t - rt.lastPrice > 120;
      if (c.src === 'research' && c.util) return c.cost <= 0.2 * cash;
      if (c.src === 'fac' && c.fac) return cash >= c.cost * (c.early ? 1 : st.fac) + reserve && (C.sr > 0.985 || c.early);
      if (c.id === 'tune') return c.cost <= 0.1 * cash && !pool.some((q) => q.id.indexOf('train-') === 0);
      const sure = c.enabler || c.must || c.id.indexOf('train-') === 0 || c.id === 'ads' || c.cost === 0;
      return sure || !(c.payback > 0) || c.payback <= st.payback;
    };
    // Saving up: something important that cannot be paid for yet holds back purchases that matter less
    let want = null;
    for (const c of pool) {
      if (c.blocked || c.tier > 2.5 || c.cost <= 0 || okay(c)) continue;
      const short = c.cost > cash || (!c.enabler && cash - c.cost < reserve);   // it is the money that is missing, not a rule
      if (!short || c.cost > cash + Math.max(0.01, C.net) * 1200) continue;
      want = c; break;
    }
    rt.saving = want;
    if (ceo.debug) ceo.lastPool = pool.map((c) => ({ id: c.id, title: c.title, tier: c.tier, cost: Math.round(c.cost), ok: okay(c), blocked: c.blocked || '', head: c.head, payback: Math.round(c.payback || 0), enabler: !!c.enabler })).concat([{ want: want && want.title, reserve, cash }]);
    for (const c of pool) {
      if (!okay(c)) continue;
      if (want && c.tier > want.tier && c.cost > 0.15 * want.cost && !(c.rate >= want.rate * 0.8 && c.rate > 0)) continue;
      return plan(c);
    }
    return null;
  }

  const OPEN = ['On it:', 'Next up:', 'Decision made:', 'Let’s go:', 'Okay, time to:', 'Plan:'];
  function plan(c) {
    return { id: c.id, cat: c.cat, target: c.target, title: c.title, cost: c.cost, run: c.run, icon: c.icon, think: pick(OPEN) + ' ' + lower(c.title) + '.', tier: c.tier, src: c.src };
  }

  /* ---------- acting ---------- */
  function begin(p) {
    rt.plan = p; rt.phase = 'think'; rt.wait = 1.7 + Math.random() * 0.9; rt.thought = p.think;
    G.emit('ceo_plan', { plan: p });
  }
  function effectText(before) {
    const e = G.state.ledger[0];
    if (!e || e === before) return '';
    const parts = [];
    if (Math.abs(e.dr) > 1e-6) parts.push((e.dr >= 0 ? '+' : '−') + U.fine(Math.abs(e.dr)) + '/s income');
    if (Math.abs(e.de) > 1e-6) parts.push((e.de >= 0 ? '+' : '−') + U.fine(Math.abs(e.de)) + '/s costs');
    return parts.join(', ');
  }
  function finish() {
    const p = rt.plan, s = G.state;
    rt.phase = 'idle'; rt.plan = null; rt.acc = IDLE_GAP - 1.1;
    if (!p) return;
    const before = s.ledger[0];
    let r = null;
    G.mute++;
    try { r = p.run(); } catch (e) { if (G.err) G.err(e); } finally { G.mute--; }
    G.adv.dirty();
    rt.thought = '';
    if (!r || !r.ok) { G.emit('ceo_do', { plan: p, ok: false }); return; }
    if (p.id === 'price') rt.lastPrice = rt.t;
    if (p.id === 'mkt') rt.lastMkt = rt.t;
    const fx = effectText(before);
    s.ceo.did = (s.ceo.did || 0) + 1;
    ceo.log(p.cat, p.title + (p.cost > 0 ? ' · ' + U.money(p.cost) : ''), fx);
    G.emit('ceo_do', { plan: p, ok: true, effect: fx });
    ceo.react('excited', 2.2);
  }

  /* ---------- the clock ---------- */
  // dt: real seconds since the last call
  ceo.step = function (dt) {
    if (!G.state || !G.C || !(dt > 0)) return;
    const c = cs(), k = speedK();
    rt.t += dt;
    rt.chat -= dt * k;
    if (c.on) {
      if (rt.phase === 'idle') {
        rt.acc += dt * k;
        if (rt.acc >= IDLE_GAP) {
          rt.acc = 0;
          let p = null;
          try { p = decide(); } catch (e) { if (G.err) G.err(e); }
          if (p) begin(p);
        }
      } else if (rt.phase === 'think') {
        rt.wait -= dt * k;
        if (rt.wait <= 0) finish();
      }
    } else if (rt.phase !== 'idle') { rt.phase = 'idle'; rt.plan = null; rt.thought = ''; }
    if (rt.chat <= 0 && rt.phase === 'idle') {
      rt.chat = c.on ? 20 + Math.random() * 14 : 40 + Math.random() * 20;
      try { ceo.chatter(); } catch (e) { if (G.err) G.err(e); }
    }
  };
  ceo.toggle = function (on) {
    const c = cs();
    c.on = on === undefined ? !c.on : !!on;
    rt.phase = 'idle'; rt.plan = null; rt.acc = IDLE_GAP - 0.8; rt.thought = '';
    ceo.say(c.on ? pick(['I’m on it. Sit back and watch.', 'Autopilot on. I’ll run the company.', 'Leave it to me!']) : pick(['Okay, you’re in charge now.', 'Autopilot off. Your call, boss.']), c.on ? 'excited' : 'happy');
  };

  /* ---------- small talk: what is happening, in Lumo's words ---------- */
  ceo.chatter = function () {
    const s = G.state, C = G.C, m = C.m, c = cs();
    const users = U.num(s.users);
    const top = C.shares.slice(1).sort((a, b) => b.share - a.share)[0];
    const lines = [];
    const add = (w, text, mood) => lines.push({ w, text, mood });
    if (C.sr < 0.9) add(5, 'Too many people, not enough servers. ' + (c.on ? 'Fixing it.' : 'We should add some.'), 'worried');
    if (C.powerRatio < 0.95) add(5, 'The servers want more power than we can supply.', 'worried');
    if (C.overheat > 0.05) add(5, 'It’s getting hot in the server hall. Better cooling, please.', 'worried');
    if (C.net < 0) add(4, 'We’re losing ' + U.fine(-C.net) + ' every second. Not great.', 'worried');
    if (s.hype > 1.2) add(4, 'Everyone is talking about ' + m.name + '!', 'excited');
    if (rt.saving && c.on) add(4, 'Saving ' + U.money(rt.saving.cost) + ' to ' + lower(rt.saving.title) + '.', 'thinking');
    if (C.net > 0) add(2, 'Making ' + U.fine(C.net) + ' profit every second. I like this.', 'happy');
    add(2, users + ' people are chatting with ' + m.name + ' right now.', 'happy');
    if (top && top.share > 0.05) add(2, top.name + ' holds ' + Math.round(top.share * 100) + '% of the market. We’ll catch up.', 'thinking');
    if (C.rev.subs > 0) add(1.5, 'Subscribers love ' + m.name + '. That’s steady money.', 'happy');
    if (C.rev.api > C.rev.total * 0.2) add(1.5, 'Developers are building on our API. Nice!', 'happy');
    if (C.nContracts > 0) add(1.5, plural(C.nContracts, 'enterprise client') + ' trust us with their work.', 'happy');
    if (s.job) add(2, 'The lab is busy training. I can feel it humming.', 'thinking');
    if (s.res.q.length) add(1.5, 'Research in progress. Science takes time.', 'thinking');
    if (s.build.length) add(1.5, 'The builders are hard at work.', 'happy');
    if (G.canReinvent()) add(3, 'We could reinvent the company for Legacy Patents. Tap me to see.', 'excited');
    add(1, pick(['Beep boop. Counting money.', 'Another day, another billion tokens.', 'Fun fact: I never sleep. Neither do the servers.', 'Do I dream of electric sheep? I dream of revenue.', 'Just thinking about gradients.']), 'happy');
    let tot = 0; for (const l of lines) tot += l.w;
    let r = Math.random() * tot, chosen = lines[0];
    for (const l of lines) { r -= l.w; if (r <= 0) { chosen = l; break; } }
    if (chosen.text === rt.said) return;
    ceo.say(chosen.text, chosen.mood);
  };
})();
