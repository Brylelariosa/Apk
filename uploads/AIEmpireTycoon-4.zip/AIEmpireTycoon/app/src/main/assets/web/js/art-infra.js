/* AI Empire Tycoon - the plant around the halls: the cooling yard (6 tiers), the power plants (5) and the network tower (6).
   Each tier is its own small drawing built from the kit in art-kit.js (and the animated parts in art-live.js): fans that turn, steam that
   rises, coolant that flows, arcs between insulators, a plasma ring, a beam of power from orbit, pulses of light running up a mast. */
(function () {
  'use strict';
  const G = window.G, U = G.U, D = G.D, A = G.art, K = A.kit;
  const P = A.P, poly = A.poly, ell = A.ell, hash = A.hash, box = A.box, tri = A.tri, cyl = A.cyl;
  const TAU = Math.PI * 2;

  /* ---------- small shared pieces ---------- */
  const line = (c, pts, col, w) => { c.strokeStyle = col; c.lineWidth = w || 1; c.beginPath(); pts.forEach((p, i) => (i ? c.lineTo(p[0], p[1]) : c.moveTo(p[0], p[1]))); c.stroke(); };
  // a wire hanging between two points
  const wire = (c, a, b, sag, col, w) => { c.strokeStyle = col || 'rgba(20,28,50,.85)'; c.lineWidth = w || 1; c.beginPath(); c.moveTo(a[0], a[1]); c.quadraticCurveTo((a[0] + b[0]) / 2, (a[1] + b[1]) / 2 + sag, b[0], b[1]); c.stroke(); };
  // horizontal slats painted on a face (grilles, louvres)
  const slats = (cc, W, Hh, n, x0, x1, y0, y1, col) => { cc.fillStyle = col; const st = (y1 - y0) / n; for (let i = 0; i < n; i++) cc.fillRect(W * x0, Hh * y0 + i * Hh * st, W * (x1 - x0), Hh * st * 0.5); };
  // a satellite dish seen from the side, centred on p
  function dish(c, p, r, rot, feed) {
    c.save(); c.translate(p[0], p[1]); c.rotate(rot || 0);
    const g = c.createRadialGradient(-r * 0.2, -r * 0.1, 1, 0, 0, r); g.addColorStop(0, '#ffffff'); g.addColorStop(1, '#8fa4cf');
    c.fillStyle = g; c.beginPath(); c.ellipse(0, 0, r * 0.6, r, 0, 0, TAU); c.fill();
    c.strokeStyle = 'rgba(20,30,60,.5)'; c.lineWidth = 1; c.stroke();
    c.strokeStyle = '#cfd9ee'; c.lineWidth = 1.1; c.beginPath(); c.moveTo(0, 0); c.lineTo(r * 0.75, -r * 0.1); c.stroke();
    c.fillStyle = feed || '#ff9f6b'; c.beginPath(); c.arc(r * 0.78, -r * 0.1, 1.2, 0, TAU); c.fill();
    c.restore();
  }
  // A lattice mast: four legs that lean in towards the top, X bracing in every bay. cx, cy = centre on the ground, hb / ht = half width at the foot / top (tiles).
  function lattice(c, cx, cy, z0, H, hb, ht, bays, col) {
    col = col || '#b4c3e0';
    const leg = (s, t) => { const k = U.lerp(hb, ht, t); return P(cx + s[0] * k, cy + s[1] * k, z0 + H * t); };
    const legs = [[-1, -1], [1, -1], [-1, 1], [1, 1]], faces = [[0, 1], [0, 2], [1, 3], [2, 3]];   // the first two faces are the ones at the back
    c.lineCap = 'round'; c.lineJoin = 'round';
    for (let b = 0; b < bays; b++) {
      const t0 = b / bays, t1 = (b + 1) / bays;
      faces.forEach(([a, d], fi) => {
        c.strokeStyle = fi >= 2 ? col : 'rgba(150,170,205,.5)'; c.lineWidth = fi >= 2 ? 1 : 0.8; c.beginPath();
        const A0 = leg(legs[a], t0), A1 = leg(legs[a], t1), B0 = leg(legs[d], t0), B1 = leg(legs[d], t1);
        c.moveTo(A0[0], A0[1]); c.lineTo(B1[0], B1[1]); c.moveTo(B0[0], B0[1]); c.lineTo(A1[0], A1[1]); c.moveTo(A1[0], A1[1]); c.lineTo(B1[0], B1[1]); c.stroke();
      });
    }
    legs.forEach((s, i) => { const a = leg(s, 0), b = leg(s, 1); line(c, [a, b], i === 3 ? col : i === 0 ? 'rgba(150,170,205,.55)' : 'rgba(176,192,222,.85)', i === 3 ? 1.8 : i === 0 ? 1.1 : 1.5); });
  }
  const platform = (c, cx, cy, z, k) => poly(c, [P(cx - k, cy - k, z), P(cx + k, cy - k, z), P(cx + k, cy + k, z), P(cx - k, cy + k, z)], '#39466a', 'rgba(220,232,255,.5)');
  // a unit on a plant: the shared base of every plant drawing
  const mk = (id, kind, lv, fp, bb) => ({ id, kind, lv, name: D.ladders[kind][lv].name, fp, b: bb });

  /* ================= COOLING YARD ================= */
  // Units stand in a row along the yard between the first hall and the road; the better the cooling, the more units and the stranger they are.
  A.COOLX = 6.2;
  const CY0 = 7.6, CW = 1.2, CD = 4.8;
  const COOL_UNIT = [
    // 0 Air fans: plain boxes with louvres and a fan on top
    (c, L, pal, x, y, w, d) => {
      const h = 9, b = K.bx(c, x, y, w, d, h, 2, pal.white), g = (cc, W, Hh) => slats(cc, W, Hh, 3, 0.12, 0.88, 0.18, 0.84, 'rgba(30,48,86,.55)');
      K.sheet(c, b.L, g); K.sheet(c, b.R, g);
      const t = P(x + w / 2, y + d / 2, 2 + h); ell(c, t[0], t[1], 11, 5.8); c.fillStyle = 'rgba(8,14,30,.88)'; c.fill();
      L.part({ t: 'fan', p: t, r: 8 });
    },
    // 1 Chilled air: taller units with a blue band, fins and a cool breath
    (c, L, pal, x, y, w, d) => {
      const h = 15, b = K.bx(c, x, y, w, d, h, 2, pal.white);
      const g = (cc, W, Hh) => { cc.fillStyle = 'rgba(30,48,86,.4)'; for (let i = 0; i < 9; i++) cc.fillRect(W * (0.1 + i * 0.09), Hh * 0.14, 1.1, Hh * 0.46); cc.fillStyle = '#4dc8ff'; cc.fillRect(0, Hh * 0.66, W, Hh * 0.1); cc.fillStyle = 'rgba(6,14,30,.5)'; cc.fillRect(W * 0.12, Hh * 0.82, W * 0.3, Hh * 0.08); };
      K.sheet(c, b.L, g); K.sheet(c, b.R, g);
      const t = P(x + w / 2, y + d / 2, 2 + h); ell(c, t[0], t[1], 11.5, 6); c.fillStyle = 'rgba(8,14,30,.88)'; c.fill();
      L.part({ t: 'fan', p: t, r: 8.6 });
      L.part({ t: 'steam', p: [t[0], t[1] - 2], n: 2, rise: 13, size: 3.6, a: 0.24, col: 'rgba(170,225,255,1)', speed: 0.5, q: 1 });
    },
    // 2 Liquid loops: cooling towers with wet louvres, a fan in a collar and a plume of vapour
    (c, L, pal, x, y, w, d) => {
      const h = 21, b = K.bx(c, x, y, w, d, h, 2, pal.metal);
      const g = (cc, W, Hh) => {
        cc.fillStyle = 'rgba(190,215,250,.22)'; for (let i = -3; i < 12; i++) { cc.beginPath(); cc.moveTo(W * i * 0.11, Hh * 0.8); cc.lineTo(W * i * 0.11 + 3, Hh * 0.8); cc.lineTo(W * i * 0.11 + 3 + Hh * 0.5, Hh * 0.12); cc.lineTo(W * i * 0.11 + Hh * 0.5, Hh * 0.12); cc.fill(); }
        cc.fillStyle = 'rgba(20,70,130,.55)'; cc.fillRect(0, Hh * 0.84, W, Hh * 0.16); cc.fillStyle = 'rgba(255,255,255,.18)'; cc.fillRect(0, Hh * 0.84, W, 0.8);
      };
      K.sheet(c, b.L, g); K.sheet(c, b.R, g);
      const t = P(x + w / 2, y + d / 2, 2 + h); ell(c, t[0], t[1], 12.5, 6.6); c.fillStyle = '#30405f'; c.fill(); ell(c, t[0], t[1], 10.4, 5.4); c.fillStyle = 'rgba(6,12,28,.92)'; c.fill();
      L.part({ t: 'fan', p: t, r: 9 });
      L.part({ t: 'steam', p: [t[0], t[1] - 3], n: 3, rise: 30, size: 5.4, a: 0.38, col: 'rgba(238,244,252,1)', speed: 0.22 });
    },
    // 3 Immersion tanks: glass tanks of glowing fluid with server blades in them and bubbles rising
    (c, L, pal, x, y, w, d, i) => {
      const h = 19, b = K.bx(c, x, y, w, d, h, 2, tri('#3d5a7a'));
      K.sheet(c, b.R, (cc, W, Hh) => {
        const wx = W * 0.1, wy = Hh * 0.1, ww = W * 0.8, wh = Hh * 0.74;
        cc.fillStyle = '#04101a'; cc.fillRect(wx - 1.2, wy - 1.2, ww + 2.4, wh + 2.4);
        const g = cc.createLinearGradient(0, wy, 0, wy + wh); g.addColorStop(0, '#4cf0dc'); g.addColorStop(1, '#0a5864'); cc.fillStyle = g; cc.fillRect(wx, wy, ww, wh);
        for (let k = 0; k < 4; k++) { const bx = wx + ww * (0.08 + k * 0.23); cc.fillStyle = 'rgba(6,22,38,.88)'; cc.fillRect(bx, wy + wh * 0.14, ww * 0.13, wh * 0.84); cc.fillStyle = '#b8fff4'; cc.fillRect(bx + ww * 0.04, wy + wh * (0.25 + (k % 2) * 0.12), 1.2, 1.2); cc.fillRect(bx + ww * 0.04, wy + wh * (0.5 + (k % 2) * 0.1), 1.2, 1.2); }
        cc.fillStyle = 'rgba(255,255,255,.45)'; cc.fillRect(wx, wy + wh * 0.1, ww, 0.9);
        cc.fillStyle = 'rgba(255,255,255,.12)'; cc.beginPath(); cc.moveTo(wx + ww * 0.1, wy + wh); cc.lineTo(wx + ww * 0.3, wy + wh); cc.lineTo(wx + ww * 0.7, wy); cc.lineTo(wx + ww * 0.5, wy); cc.fill();
      });
      K.sheet(c, b.L, (cc, W, Hh) => { cc.fillStyle = 'rgba(6,12,28,.45)'; cc.fillRect(W * 0.14, Hh * 0.2, W * 0.5, Hh * 0.5); cc.fillStyle = '#7fe9ff'; cc.fillRect(W * 0.72, Hh * 0.3, 2.4, 2.4); cc.fillStyle = '#ffb347'; cc.fillRect(W * 0.72, Hh * 0.5, 2.4, 2.4); });
      const tl = P(x + w / 2, y + d / 2, 2 + h); poly(c, [P(x + 0.05, y + d - 0.05, 2 + h + 1.5), P(x + w - 0.05, y + d - 0.05, 2 + h + 1.5), P(x + w - 0.05, y + 0.05, 2 + h + 1.5), P(x + 0.05, y + 0.05, 2 + h + 1.5)], 'rgba(190,225,240,.2)');
      [0.3, 0.55, 0.78].forEach((u, k) => L.part({ t: 'flow', pts: [b.R(u, 0.14), b.R(u, 0.78)], col: 'rgba(214,255,250,.85)', n: 3, spd: 0.28 + 0.05 * ((i + k) % 3), size: 0.95, q: 1 }));
      if (i === 0) L.part({ t: 'glow', p: [tl[0], tl[1] + 6], r: 34, col: '#37e6d2', a: 0.12 });
    },
    // 4 Cryo chillers: tall frosted cylinders with cold mist falling off them
    (c, L, pal, x, y, w, d, i) => {
      const cx = x + w / 2, cy = y + d / 2, r = Math.min(0.3, d / 2), h = 26;
      const top = cyl(c, cx, cy, r, h, 2, tri('#d6e8fb'));
      c.strokeStyle = 'rgba(90,140,200,.55)'; c.lineWidth = 1; for (const k of [0.25, 0.5, 0.75]) { const p = P(cx, cy, 2 + h * k); c.beginPath(); c.ellipse(p[0], p[1], r * 32 * 1.414, r * 16 * 1.414, 0, 0, Math.PI); c.stroke(); }
      c.fillStyle = 'rgba(255,255,255,.55)'; for (let k = 0; k < 5; k++) { const p = P(cx - r * 0.7, cy + r * 0.2, 2 + 4 + k * 4.4); c.fillRect(p[0] + hash(i, k, 6) * 6, p[1], 1.6, 1.4); }   // frost crystals
      c.fillStyle = '#e8f4ff'; ell(c, top[0], top[1], top[2] * 0.62, top[3] * 0.62); c.fill();
      const gp = P(cx + r * 0.2, cy + r, 2 + 9); c.fillStyle = '#10223c'; c.beginPath(); c.arc(gp[0], gp[1], 2.4, 0, TAU); c.fill(); c.strokeStyle = '#9fe2ff'; c.lineWidth = 0.8; c.beginPath(); c.arc(gp[0], gp[1], 2.4, 0, TAU); c.stroke(); c.beginPath(); c.moveTo(gp[0], gp[1]); c.lineTo(gp[0] + 1.3, gp[1] - 1.3); c.stroke();
      L.part({ t: 'steam', p: [top[0], top[1] - 2], n: 3, rise: 22, size: 5.2, a: 0.4, col: 'rgba(205,236,255,1)', speed: 0.3 + 0.03 * (i % 3), q: 1 });
    },
    // 5 Zero-point exchangers: dark monoliths with seams of violet light, arcs between their tips
    (c, L, pal, x, y, w, d, i) => {
      const h = 33, b = K.bx(c, x + 0.1, y, w - 0.2, d, h, 2, tri('#2a1d58'));
      const g = (cc, W, Hh) => {
        cc.fillStyle = '#d6baff'; cc.fillRect(W * 0.46, Hh * 0.08, W * 0.08, Hh * 0.84); cc.fillStyle = 'rgba(183,140,255,.35)'; cc.fillRect(W * 0.38, Hh * 0.08, W * 0.24, Hh * 0.84);
        cc.fillStyle = 'rgba(255,255,255,.25)'; cc.fillRect(0, 0, W, 1.2); cc.fillStyle = '#ff9fe0'; cc.fillRect(W * 0.1, Hh * (0.3 + (i % 3) * 0.15), W * 0.18, 1.3);
      };
      K.sheet(c, b.L, g); K.sheet(c, b.R, g);
      const t = P(x + w / 2, y + d / 2, 2 + h);
      L.part({ t: 'glow', p: t, r: 16, col: '#b78cff', a: 0.4, pulse: 1.5 + 0.2 * (i % 3), ph: i });
      L.part({ t: 'orbit', p: [t[0], t[1] - 7], rx: 9, ry: 3.2, n: 2, spd: 1.5 + 0.2 * (i % 2), ph: i, col: '#e8d6ff', size: 1.1, q: 1 });
      if (i % 2 === 0) L.part({ t: 'arc', a: [t[0], t[1] - 2], b: [t[0] + 17, t[1] - 4], rate: 0.16, ph: i * 0.37, col: '#d6baff', jit: 4, q: 1 });
    }
  ];
  A.cooling = function (lv, pal) {
    const X = A.COOLX, n = 3 + lv, sp = (CD - 0.3) / n, ud = Math.min(0.8, sp - 0.08);
    const o = mk('cool', 'cool', lv, [X, CY0, CW, CD, 40], A.bbox(X, CY0, CW, CD, 70, 12));
    const L = K.rig(o); o.lit = null;
    const cold = ['#9fb3d6', '#7fd0ff', '#4dc8ff', '#37e6d2', '#9fe2ff', '#b78cff'][lv];
    o.draw = (c) => {
      L.begin();
      K.shadow(c, X - 0.05, CY0 - 0.05, CW + 0.1, CD + 0.1, 0.6, 0.5);
      K.slab(c, X - 0.05, CY0 - 0.05, CW + 0.1, CD + 0.1, 2, pal.concrete, { accent: pal.acc });
      // a yellow safety line round the pad
      c.strokeStyle = 'rgba(255,205,80,.45)'; c.lineWidth = 1; c.beginPath(); { const a = P(X + 0.04, CY0 + CD - 0.05, 2), b = P(X + CW - 0.04, CY0 + CD - 0.05, 2), e = P(X + CW - 0.04, CY0 + 0.05, 2); c.moveTo(a[0], a[1]); c.lineTo(b[0], b[1]); c.lineTo(e[0], e[1]); } c.stroke();
      for (let i = 0; i < n; i++) COOL_UNIT[lv](c, L, pal, X + 0.2, CY0 + 0.15 + i * sp + (sp - ud) / 2, 0.8, ud, i);
      // the coolant manifold along the front of the row, with a stub to every unit
      const yA = CY0 + 0.2, yB = CY0 + CD - 0.2, xm = X + 1.04;
      for (let i = 0; i < n; i++) { const yy = CY0 + 0.15 + i * sp + sp / 2; line(c, [P(X + 1.0, yy, 4), P(xm, yy, 4)], '#6f7f9f', 1.6); }
      K.pipe(c, [P(xm, yA, 4), P(xm, yB, 4)], 2.4, lv >= 2 ? '#3f8fc8' : '#8a9bc0');
      if (lv >= 2) K.pipe(c, [P(xm + 0.1, yA, 3), P(xm + 0.1, yB, 3)], 1.8, '#c8584a');
      L.part({ t: 'flow', pts: [P(xm, yB, 4.5), P(xm, yA, 4.5)], col: cold, n: 6, spd: 0.3, size: 1.3, q: 1 });
      if (lv >= 2) L.part({ t: 'flow', pts: [P(xm + 0.1, yA, 3.5), P(xm + 0.1, yB, 3.5)], col: '#ffb08a', n: 5, spd: 0.26, size: 1.1, q: 1 });
      if (lv === 4) L.part({ t: 'steam', p: P(X + 0.6, CY0 + CD * 0.5, 4), n: 3, rise: 6, size: 15, a: 0.1, col: 'rgba(205,236,255,1)', speed: 0.12, q: 1 });
    };
    if (lv >= 3) o.glow = [{ p: P(X + 0.6, CY0 + CD / 2, 16), r: 44 + lv * 4, c: cold, a: 0.1 + lv * 0.015 }];
    return o;
  };

  /* ================= POWER ================= */
  const PWR = [null,
    // 1 Transformer yard: two transformers under a lattice pylon, wires, a fence and a sodium lamp
    (pal) => {
      const o = mk('pwr1', 'pwr', 1, [14.3, 1.1, 2, 2, 50], A.bbox(14.2, 1.0, 2.2, 2.2, 70, 12)), L = K.rig(o); o.lit = null;
      o.glow = [{ p: P(15, 2, 20), r: 30, c: '#ffd28a', a: 0.12 }];
      const xf = (c, x, y, k) => {
        const b = K.bx(c, x, y, 0.85, 0.9, 14, 2, tri('#6f9079'));
        K.sheet(c, b.R, (cc, W, Hh) => { cc.fillStyle = 'rgba(0,0,0,.28)'; for (let i = 0; i < 10; i++) cc.fillRect(W * (0.08 + i * 0.09), Hh * 0.12, 1.4, Hh * 0.76); });
        K.sheet(c, b.L, (cc, W, Hh) => { cc.fillStyle = '#ffcf3a'; cc.beginPath(); cc.moveTo(W * 0.5, Hh * 0.2); cc.lineTo(W * 0.72, Hh * 0.7); cc.lineTo(W * 0.28, Hh * 0.7); cc.closePath(); cc.fill(); cc.fillStyle = '#1a1a1a'; cc.fillRect(W * 0.49, Hh * 0.34, 1.6, Hh * 0.18); });
        const tops = [];
        for (let i = 0; i < 3; i++) { cyl(c, x + 0.17 + i * 0.25, y + 0.45, 0.07, 7, 16, tri('#d6c3a2')); tops.push(P(x + 0.17 + i * 0.25, y + 0.45, 23)); }
        return tops;
      };
      o.draw = (c) => {
        L.begin();
        K.shadow(c, 14.2, 1.0, 2.2, 2.2, 0.6, 0.5); K.slab(c, 14.2, 1.0, 2.2, 2.2, 2, pal.concrete, { accent: pal.acc });
        const t1 = xf(c, 14.45, 1.3);
        lattice(c, 14.5, 2.6, 2, 54, 0.2, 0.06, 5);
        const arm = [P(14.5 - 0.34, 2.6 + 0.34, 50), P(14.5 + 0.34, 2.6 - 0.34, 50)]; line(c, arm, '#cfdaf0', 2);
        const t2 = xf(c, 15.45, 1.7);
        for (let i = 0; i < 3; i++) {
          const u = [P(14.5 - 0.3 + i * 0.3, 2.6 + 0.3 - i * 0.3, 50)], e = [u[0][0], u[0][1] + 5];
          line(c, [u[0], e], '#c9b79a', 2.2);
          wire(c, e, i === 0 ? t1[0] : i === 1 ? t1[2] : t2[1], 9);
        }
        L.part({ t: 'blink', p: P(14.5, 2.6, 57), col: '#ff4d5e', per: 1.5, r: 1.8, glow: 11 });
        L.part({ t: 'arc', a: [arm[0][0], arm[0][1] + 5], b: t1[0], rate: 0.1, ph: 0.2, col: '#bfe0ff', jit: 4, q: 1 });
        L.part({ t: 'arc', a: [arm[1][0], arm[1][1] + 5], b: t2[2], rate: 0.08, ph: 0.6, col: '#bfe0ff', jit: 4, q: 1 });
        K.lamp(c, L, 16.2, 1.25, 17, '#ffcf8a', 2);
        K.railing(c, 14.2, 1.0, 2.2, 2.2, 2, 'rgba(210,225,255,.6)');
      };
      return o;
    },
    // 2 Solar + battery farm: rows of tilted panels that glint, battery containers with charge lights
    (pal) => {
      const o = mk('pwr2', 'pwr', 2, [16.9, 1.0, 4, 3.2, 20], A.bbox(16.9, 1.0, 4, 3.2, 36, 10)), L = K.rig(o); o.lit = null;
      o.glow = [{ p: P(18.9, 2.6, 10), r: 44, c: '#5aa8ff', a: 0.1 }];
      o.draw = (c) => {
        L.begin();
        K.shadow(c, 16.9, 1.0, 4, 3.2, 0.6, 0.5); K.slab(c, 16.9, 1.0, 4, 3.2, 2, pal.concrete, { accent: pal.acc });
        for (const yy of [1.25, 2.1]) {
          for (let i = 0; i < 4; i++) {
            const x = 17.1 + i * 0.93, pts = [P(x, yy, 15), P(x + 0.84, yy, 15), P(x + 0.84, yy + 0.7, 7.5), P(x, yy + 0.7, 7.5)];
            const g = c.createLinearGradient(pts[0][0], pts[0][1], pts[2][0], pts[2][1]); g.addColorStop(0, '#6ba8ea'); g.addColorStop(1, '#1b4684');
            for (const lx of [0.2, 0.62]) line(c, [P(x + lx, yy + 0.7, 7.5), P(x + lx, yy + 0.7, 2)], '#7a8aa8', 1.2);
            poly(c, pts, g, 'rgba(210,230,255,.7)');
            c.strokeStyle = 'rgba(200,225,255,.28)'; c.lineWidth = 1; c.beginPath();
            for (let u = 1; u < 4; u++) { const a = P(x + (0.84 * u) / 4, yy, 15), b = P(x + (0.84 * u) / 4, yy + 0.7, 7.5); c.moveTo(a[0], a[1]); c.lineTo(b[0], b[1]); }
            for (let v = 1; v < 3; v++) { const a = P(x, yy + (0.7 * v) / 3, 15 - (7.5 * v) / 3), b = P(x + 0.84, yy + (0.7 * v) / 3, 15 - (7.5 * v) / 3); c.moveTo(a[0], a[1]); c.lineTo(b[0], b[1]); }
            c.stroke();
          }
          L.part({ t: 'glint', poly: [P(17.1, yy, 15), P(20.7, yy, 15), P(20.7, yy + 0.7, 7.5), P(17.1, yy + 0.7, 7.5)], spd: 0.2, ph: yy * 0.3, q: 1 });
        }
        // two battery containers and an inverter
        [[17.1, 0], [18.75, 1]].forEach(([x, k]) => {
          const b = K.bx(c, x, 3.0, 1.45, 0.75, 11, 2, pal.white);
          K.sheet(c, b.L, (cc, W, Hh) => {
            cc.fillStyle = 'rgba(30,48,86,.3)'; cc.fillRect(W * 0.04, Hh * 0.1, W * 0.44, Hh * 0.8); cc.fillRect(W * 0.52, Hh * 0.1, W * 0.44, Hh * 0.8);
            cc.fillStyle = '#071022'; cc.fillRect(W * 0.1, Hh * 0.22, W * 0.32, Hh * 0.18); cc.fillRect(W * 0.58, Hh * 0.22, W * 0.32, Hh * 0.18);
            cc.fillStyle = 'rgba(255,255,255,.4)'; cc.fillRect(W * 0.47, Hh * 0.44, 1.2, Hh * 0.14);
          });
          K.sheet(c, b.R, (cc, W, Hh) => { slats(cc, W, Hh, 4, 0.2, 0.8, 0.2, 0.8, 'rgba(30,48,86,.5)'); });
          L.part({ t: 'face', f: b.L, q: 1, fn: (cc, W, Hh, T) => { for (let s = 0; s < 2; s++) { const x0 = W * (0.1 + s * 0.48), lev = (Math.sin(T * 0.5 + k + s) * 0.5 + 0.5); for (let i = 0; i < 6; i++) { cc.fillStyle = i / 6 < lev ? '#46e39a' : 'rgba(40,90,70,.6)'; cc.fillRect(x0 + i * W * 0.05, Hh * 0.25, W * 0.04, Hh * 0.12); } } } });
          for (const fx of [0.3, 0.7]) { const t = P(x + 1.45 * fx, 3.375, 13); ell(c, t[0], t[1], 5.4, 2.8); c.fillStyle = 'rgba(8,14,30,.9)'; c.fill(); L.part({ t: 'fan', p: t, r: 3.8, spd: 8 }); }
        });
        const inv = K.bx(c, 20.35, 3.1, 0.4, 0.6, 12, 2, tri('#8fa0c4'));
        K.sheet(c, inv.R, (cc, W, Hh) => { cc.fillStyle = '#071022'; cc.fillRect(W * 0.2, Hh * 0.18, W * 0.6, Hh * 0.22); cc.fillStyle = '#ffd24a'; cc.fillRect(W * 0.28, Hh * 0.26, W * 0.3, 1.4); });
        L.part({ t: 'blink', p: P(20.55, 3.4, 14.5), col: '#46e39a', per: 1.6, r: 1.4, glow: 8, q: 1 });
        K.pipe(c, [P(17.1, 3.95, 3), P(20.7, 3.95, 3)], 1.6, '#e0a34a');
        K.lamp(c, L, 16.95, 3.95, 15, '#cfe8ff', 2);
      };
      return o;
    },
    // 3 Gas turbine plant: a turbine hall with a glowing slit, two striped stacks breathing smoke, a gas sphere and radiators
    (pal) => {
      const o = mk('pwr3', 'pwr', 3, [14.3, 3.7, 2.6, 2.6, 66], A.bbox(14.2, 3.6, 2.8, 2.8, 86, 12)), L = K.rig(o); o.lit = null;
      o.glow = [{ p: P(15.5, 5.4, 14), r: 38, c: '#ffb066', a: 0.16 }];
      o.draw = (c) => {
        L.begin();
        K.shadow(c, 14.2, 3.6, 2.8, 2.8, 0.6, 0.5); K.slab(c, 14.2, 3.6, 2.8, 2.8, 2, pal.concrete, { accent: pal.acc });
        // gas sphere on legs, behind the hall
        { const p = P(16.3, 4.2, 20); for (const dx of [-8, 0, 8]) line(c, [[p[0] + dx * 0.9, p[1] + 6], [p[0] + dx, p[1] + 20 + Math.abs(dx) * 0.2]], '#6f7f9f', 1.4);
          const g = c.createRadialGradient(p[0] - 5, p[1] - 5, 2, p[0], p[1], 14); g.addColorStop(0, '#ffffff'); g.addColorStop(1, '#8da2cc'); c.fillStyle = g; c.beginPath(); c.arc(p[0], p[1], 13, 0, TAU); c.fill();
          c.strokeStyle = 'rgba(40,60,100,.45)'; c.lineWidth = 1; c.beginPath(); c.ellipse(p[0], p[1], 13, 4.5, 0, 0, TAU); c.stroke(); }
        // radiator bank with fans
        { const b = K.bx(c, 14.35, 3.75, 1.3, 0.5, 9, 2, pal.metal); K.sheet(c, b.L, (cc, W, Hh) => slats(cc, W, Hh, 4, 0.06, 0.94, 0.12, 0.9, 'rgba(10,16,34,.5)'));
          for (const fx of [0.25, 0.75]) { const t = P(14.35 + 1.3 * fx, 4.0, 11); ell(c, t[0], t[1], 6.2, 3.2); c.fillStyle = 'rgba(8,14,30,.9)'; c.fill(); L.part({ t: 'fan', p: t, r: 4.4, spd: 9 }); } }
        // the two stacks (striped), then the hall in front of their feet
        const stacks = [[15.0, 4.25, 46], [15.7, 4.25, 38]];
        for (const [sx, sy, sh] of stacks) {
          const top = cyl(c, sx, sy, 0.22, sh, 2, pal.white);
          c.save(); c.beginPath(); c.rect(top[0] - top[2] - 1, top[1], top[2] * 2 + 2, sh + top[3]); c.clip();
          c.fillStyle = 'rgba(214,56,47,.85)'; for (const k of [0.62, 0.84]) { const p = P(sx, sy, 2 + sh * k); c.beginPath(); c.ellipse(p[0], p[1], top[2], top[3], 0, 0, Math.PI); c.lineTo(p[0] - top[2], p[1] - 4); c.ellipse(p[0], p[1] - 4, top[2], top[3], 0, Math.PI, 0, true); c.lineTo(p[0] + top[2], p[1]); c.fill(); }
          c.restore();
          ell(c, top[0], top[1], top[2] * 0.7, top[3] * 0.7); c.fillStyle = '#2a2530'; c.fill();
          L.part({ t: 'steam', p: [top[0], top[1] - 2], n: 4, rise: 40, size: 6.5, a: 0.34, col: 'rgba(196,202,214,1)', speed: 0.22 });
          L.part({ t: 'glow', p: [top[0], top[1] - 1], r: 13, col: '#ff9a4a', a: 0.32, pulse: 5, ph: sx });
        }
        const h = K.bx(c, 14.4, 4.7, 2.3, 1.5, 22, 2, pal.metal);
        K.sheet(c, h.L, (cc, W, Hh) => {
          for (let x = 0; x < W; x += 3) { cc.fillStyle = 'rgba(255,255,255,.06)'; cc.fillRect(x, 0, 1, Hh); cc.fillStyle = 'rgba(0,0,0,.1)'; cc.fillRect(x + 1.2, 0, 1, Hh); }
          cc.fillStyle = '#05080f'; cc.fillRect(W * 0.08, Hh * 0.5, W * 0.4, Hh * 0.46); cc.fillStyle = 'rgba(190,210,245,.3)'; for (let i = 0; i < 6; i++) cc.fillRect(W * 0.08, Hh * 0.5 + i * Hh * 0.075, W * 0.4, 0.8);   // the roller door
          cc.fillStyle = '#ffa24a'; cc.fillRect(W * 0.1, Hh * 0.16, W * 0.8, Hh * 0.1); cc.fillStyle = 'rgba(255,200,120,.35)'; cc.fillRect(W * 0.1, Hh * 0.26, W * 0.8, Hh * 0.05);
          cc.fillStyle = 'rgba(255,205,80,.7)'; for (let x = 0; x < W; x += 6) { cc.beginPath(); cc.moveTo(x, Hh); cc.lineTo(x + 3, Hh); cc.lineTo(x + 6, Hh - 3); cc.lineTo(x + 3, Hh - 3); cc.fill(); }
        });
        K.sheet(c, h.R, (cc, W, Hh) => { slats(cc, W, Hh, 5, 0.15, 0.85, 0.14, 0.8, 'rgba(10,16,34,.5)'); });
        K.roof(c, 14.4, 4.7, 2.3, 1.5, 24, pal.roof);
        K.hvac(c, L, pal, 15.3, 5.0, 24, 0.6, 0.5, 4);
        K.pipe(c, [P(16.3, 4.4, 4), P(16.3, 4.7, 4), P(16.0, 4.7, 4)], 1.8, '#c8a24a');
        K.lamp(c, L, 14.35, 6.3, 15, '#ffcf8a', 2);
      };
      return o;
    },
    // 4 Fusion microreactor: a white drum under a glass dome with a ring of plasma in it, coil pylons throwing sparks to the dome
    (pal) => {
      const cx = 18.9, cy = 5.9, o = mk('pwr4', 'pwr', 4, [17.4, 4.4, 3, 3, 46], A.bbox(17.3, 4.3, 3.2, 3.2, 80, 12)), L = K.rig(o); o.lit = null;
      o.glow = [{ p: P(cx, cy, 30), r: 64, c: '#7fe9ff', a: 0.3 }];
      o.draw = (c) => {
        L.begin();
        K.shadow(c, 17.3, 4.3, 3.2, 3.2, 0.7, 0.5); K.slab(c, 17.3, 4.3, 3.2, 3.2, 2, pal.concrete, { accent: pal.acc });
        const ring = P(cx, cy, 2); c.strokeStyle = U.rgba(pal.acc, 0.5); c.lineWidth = 1.4; ell(c, ring[0], ring[1], 70, 35); c.stroke();
        // coil pylons at the back corners, drawn before the drum
        const pyl = [[17.75, 4.65], [20.05, 4.65], [17.75, 6.9]];
        const tip = (p) => P(p[0], p[1], 40);
        pyl.slice(0, 2).forEach((p) => { K.bx(c, p[0] - 0.12, p[1] - 0.12, 0.24, 0.24, 36, 2, tri('#9fb3d6')); L.part({ t: 'glow', p: tip(p), r: 12, col: '#7fe9ff', a: 0.55, pulse: 3 }); });
        const dr = P(cx, cy, 2);
        const drum = cyl(c, cx, cy, 1.12, 15, 2, tri('#dbe6f6'));
        c.save(); c.beginPath(); c.rect(drum[0] - drum[2], drum[1], drum[2] * 2, 16 + drum[3]); c.clip();
        c.fillStyle = '#ffcf3a'; for (let i = -10; i < 12; i++) { c.beginPath(); c.moveTo(dr[0] + i * 8, dr[1] + 6); c.lineTo(dr[0] + i * 8 + 4, dr[1] + 6); c.lineTo(dr[0] + i * 8 + 8, dr[1] - 6); c.lineTo(dr[0] + i * 8 + 4, dr[1] - 6); c.fill(); }   // hazard band
        c.fillStyle = 'rgba(10,18,36,.5)'; for (let i = 0; i < 6; i++) c.fillRect(dr[0] - 40 + i * 14, dr[1] - 10, 7, 3);
        c.restore();
        c.fillStyle = 'rgba(0,0,0,.2)'; c.fillRect(dr[0] - drum[2], dr[1] - 15 + drum[3] * 0.3, drum[2] * 2, 2);
        const z0 = 17;
        K.glassDome(c, cx, cy, z0, 0.98, 31, '#7fe9ff');
        const core = P(cx, cy, z0 + 9);
        L.part({ t: 'glow', p: core, r: 30, col: '#bff7ff', a: 0.5, pulse: 2 });
        L.part({ t: 'orbit', p: core, rx: 24, ry: 9, rot: -0.15, n: 9, spd: 2.4, col: '#e8ffff', size: 1.7, glow: 8, line: 0.35 });
        L.part({ t: 'orbit', p: core, rx: 18, ry: 7, rot: 0.55, n: 6, spd: -3.1, ph: 1.1, col: '#7fe9ff', size: 1.4, glow: 6, line: 0.25, q: 1 });
        L.part({ t: 'rings', p: P(cx, cy, z0), rx: 52, ry: 24, n: 2, spd: 0.4, col: '#7fe9ff', a: 0.5, q: 1 });
        pyl.slice(0, 2).forEach((p, i) => L.part({ t: 'arc', a: tip(p), b: [core[0], core[1] - 6], rate: 0.22, ph: 0.3 + i * 0.4, col: '#bff7ff', jit: 8, q: 1 }));
        // the front pylon and the cooling stub in front of the drum
        const fp = pyl[2]; K.bx(c, fp[0] - 0.12, fp[1] - 0.12, 0.24, 0.24, 36, 2, tri('#9fb3d6')); L.part({ t: 'glow', p: tip(fp), r: 12, col: '#7fe9ff', a: 0.55, pulse: 3, ph: 1 });
        L.part({ t: 'arc', a: tip(fp), b: [core[0], core[1] + 4], rate: 0.2, ph: 0.9, col: '#bff7ff', jit: 8, q: 1 });
        const sw = K.bx(c, 20.2, 7.05, 0.7, 0.4, 9, 2, tri('#8fa0c4')); K.sheet(c, sw.L, (cc, W, Hh) => { cc.fillStyle = '#071022'; cc.fillRect(W * 0.12, Hh * 0.2, W * 0.76, Hh * 0.3); cc.fillStyle = '#7fe9ff'; cc.fillRect(W * 0.18, Hh * 0.3, W * 0.4, 1.4); });
        L.part({ t: 'steam', p: P(17.8, 7.2, 12), n: 3, rise: 22, size: 4.4, a: 0.3, col: 'rgba(230,240,250,1)', speed: 0.25 });
        K.bx(c, 17.6, 7.05, 0.5, 0.45, 11, 2, tri('#c8d4ea'));
      };
      return o;
    },
    // 5 Orbital solar array: a field of rectenna panels, a receiver mast and a beam of power coming down from a satellite
    (pal) => {
      const mx = 19.4, my = 17.0, o = mk('pwr5', 'pwr', 5, [17.8, 15.4, 3.2, 3.2, 90], A.bbox(17.7, 15.3, 3.4, 3.4, 140, 14)), L = K.rig(o); o.lit = null;
      o.glow = [{ p: P(mx, my, 90), r: 70, c: '#ffe08a', a: 0.28 }];
      o.draw = (c) => {
        L.begin();
        K.shadow(c, 17.7, 15.3, 3.4, 3.4, 0.7, 0.5); K.slab(c, 17.7, 15.3, 3.4, 3.4, 2, pal.concrete, { accent: pal.acc });
        const cell = (i, j) => {
          const x = 17.95 + i * 1.0, y = 15.55 + j * 1.0, pts = [P(x, y, 13), P(x + 0.86, y, 13), P(x + 0.86, y + 0.86, 6), P(x, y + 0.86, 6)];
          const g = c.createLinearGradient(pts[0][0], pts[0][1], pts[2][0], pts[2][1]); g.addColorStop(0, '#5f9ae6'); g.addColorStop(1, '#17428a');
          line(c, [P(x + 0.43, y + 0.86, 6), P(x + 0.43, y + 0.86, 2)], '#7a8aa8', 1.3);
          poly(c, pts, g, 'rgba(255,224,150,.8)');
          c.strokeStyle = 'rgba(255,224,150,.45)'; c.lineWidth = 0.8; c.beginPath();
          for (let u = 1; u < 4; u++) { const a = P(x + (0.86 * u) / 4, y, 13), b = P(x + (0.86 * u) / 4, y + 0.86, 6); c.moveTo(a[0], a[1]); c.lineTo(b[0], b[1]); }
          for (let v = 1; v < 4; v++) { const a = P(x, y + (0.86 * v) / 4, 13 - (7 * v) / 4), b = P(x + 0.86, y + (0.86 * v) / 4, 13 - (7 * v) / 4); c.moveTo(a[0], a[1]); c.lineTo(b[0], b[1]); }
          c.stroke();
          return pts;
        };
        for (let j = 0; j < 3; j++) for (let i = 0; i < 3; i++) {
          if (i === 1 && j === 1) { // the receiver mast stands in the middle of the field
            const m0 = P(mx, my, 2), m1 = P(mx, my, 92);
            lattice(c, mx, my, 2, 92, 0.2, 0.05, 8, '#dbe6ff');
            const cone = P(mx, my, 94); c.fillStyle = '#ffe08a'; c.beginPath(); c.moveTo(cone[0] - 11, cone[1]); c.lineTo(cone[0] + 11, cone[1]); c.lineTo(cone[0], cone[1] + 9); c.closePath(); c.fill(); ell(c, cone[0], cone[1], 11, 4.5); c.fillStyle = '#fff3c4'; c.fill();
            continue;
          }
          cell(i, j);
        }
        for (const yy of [15.55, 16.55, 17.55]) L.part({ t: 'glint', poly: [P(17.95, yy, 13), P(20.8, yy, 13), P(20.8, yy + 0.86, 6), P(17.95, yy + 0.86, 6)], spd: 0.25, ph: yy * 0.4, q: 1 });
        const top = P(mx, my, 94);
        L.part({ t: 'beam', a: [top[0], top[1] + 2], b: [top[0] + 16, top[1] - 66], col: '#ffe08a', w: 9, spd: 3 });
        L.part({ t: 'rings', p: [top[0], top[1] + 4], rx: 26, ry: 11, n: 3, spd: 0.6, col: '#ffe08a', a: 0.7 });
        L.part({ t: 'sat', p: [top[0] + 16, top[1] - 66], rx: 0, ry: 0, spd: 0 });
        L.part({ t: 'glow', p: [top[0], top[1] + 3], r: 34, col: '#ffe08a', a: 0.4, pulse: 2.4 });
        L.part({ t: 'blink', p: [top[0], top[1] - 4], col: '#ff4d5e', per: 1.3, r: 1.8, glow: 10 });
        K.lamp(c, L, 17.85, 18.5, 16, '#ffe9b8', 2); K.lamp(c, L, 20.9, 18.5, 16, '#ffe9b8', 2);
      };
      return o;
    }
  ];
  A.power = (lv, pal) => PWR[lv](pal);

  /* ================= NETWORK TOWER ================= */
  // Six tiers: a pole with a dish and a cabinet, a mast, a lattice tower with a ring of dishes, laser links, light-pipe legs and a quantum crystal.
  A.tower = function (lv, pal) {
    const N = A.PLAN.net, nx = N.x + N.s / 2, ny = N.y + N.s / 2, h = 40 + lv * 7;
    const o = mk('net', 'net', lv, [N.x, N.y, N.s, N.s, 70], A.bbox(N.x, N.y, N.s, N.s, 96, 26));
    const bp = P(nx, ny); o.tb = [bp[0] - 30, bp[1] - h - 26, bp[0] + 30, bp[1] + 12];
    const L = K.rig(o); o.lit = null;
    const mast = P(nx, ny, 2 + h), acc = pal.acc;
    if (lv >= 3) o.glow = [{ p: P(nx, ny, h), r: 22 + lv * 4, c: acc, a: 0.22 }];
    o.draw = (c) => {
      L.begin();
      K.shadow(c, N.x - 0.1, N.y - 0.1, N.s + 0.2, N.s + 0.2, 0.4, 0.5);
      K.slab(c, N.x - 0.1, N.y - 0.1, N.s + 0.2, N.s + 0.2, 2, pal.concrete, { accent: acc });
      // the equipment cabinet beside the mast: lights that blink, one more for each tier
      const cab = K.bx(c, N.x + 0.02, N.y + 0.5, 0.34, 0.26, 10 + Math.min(lv, 3) * 2, 2, tri('#c8d4ea'));
      K.sheet(c, cab.L, (cc, W, Hh) => { cc.fillStyle = '#071022'; cc.fillRect(W * 0.12, Hh * 0.14, W * 0.76, Hh * 0.72); for (let i = 0; i < 3 + Math.min(lv, 3); i++) { cc.fillStyle = i % 3 === 0 ? '#ffb347' : '#46e39a'; cc.fillRect(W * 0.2, Hh * (0.2 + i * 0.1), W * 0.5, 1.1); } });
      L.part({ t: 'blink', p: cab.L(0.8, 0.5), col: '#46e39a', per: 0.9, r: 1.1, q: 1 });
      const base = P(nx, ny, 2);
      if (lv <= 1) {
        // a steel pole with guy wires
        line(c, [base, [mast[0], mast[1]]], '#c3d0ee', 2.2);
        for (const [dx, dz] of [[-16, 0.6], [14, 0.55]]) line(c, [[mast[0], mast[1] + 8], [base[0] + dx, base[1] + 3]], 'rgba(176,192,222,.55)', 0.8);
        dish(c, [mast[0] + 5, mast[1] + 9], 6.4, -0.55);
        if (lv === 1) dish(c, [mast[0] - 5, mast[1] + 17], 5.4, 0.5, '#7fe9ff');
        c.fillStyle = '#dbe6ff'; c.fillRect(mast[0] - 1.6, mast[1] + (lv ? 25 : 18), 3.2, 8);
      } else {
        const hb = 0.2 + lv * 0.004, ht = 0.05;
        lattice(c, nx, ny, 2, h, hb, ht, 4 + lv, lv >= 4 ? '#cfe0ff' : '#b4c3e0');
        // platforms and the dishes on them
        const lev = lv === 2 ? [0.5] : lv === 3 ? [0.4, 0.68] : [0.36, 0.6, 0.8];
        lev.forEach((t, k) => {
          const z = 2 + h * t, pk = U.lerp(hb, ht, t) + 0.05;
          platform(c, nx, ny, z, pk);
          const side = k % 2 ? 1 : -1, p = P(nx + side * pk, ny - side * pk, z);
          dish(c, [p[0] + side * 4, p[1] - 3], 6.4 - k * 0.6, side > 0 ? -0.5 : Math.PI + 0.5);
          const q = P(nx + pk, ny + pk, z); c.fillStyle = '#dbe6ff'; c.fillRect(q[0] - 1.6, q[1] - 9, 3.2, 9);
          if (lv === 3 && k === 1) L.part({ t: 'beam', a: [p[0] + 10, p[1] - 3], b: [p[0] + 52, p[1] + 20], col: acc, w: 2, spd: 4 });
        });
        // data pulses climbing the legs
        const legTop = P(nx, ny, 2 + h);
        L.part({ t: 'chase', pts: [P(nx + hb, ny + hb, 2), P(nx + ht, ny + ht, 2 + h)], n: 3, spd: lv >= 4 ? 0.5 : 0.3, col: acc, size: 1.3, glow: 7, q: 1 });
        if (lv >= 4) L.part({ t: 'chase', pts: [P(nx + hb, ny - hb, 2), P(nx + ht, ny - ht, 2 + h)], n: 3, spd: 0.42, ph: 0.4, col: '#bff7ff', size: 1.2, glow: 6, q: 1 });
        if (lv >= 2) L.part({ t: 'radar', p: [legTop[0], legTop[1] - 3], r: lv >= 3 ? 6 : 8, col: acc, spd: 1.4 });
        // the better the network, the more it glows: a halo ring, then a crystal, then a beam to the sky
        if (lv === 3) { const p = P(nx, ny, 2 + h); L.part({ t: 'glow', p: [p[0], p[1] - 6], r: 18, col: acc, a: 0.6, pulse: 2 }); }
        if (lv >= 4) L.part({ t: 'orbit', p: P(nx, ny, 2 + h * 0.55), rx: 17, ry: 6.5, n: 5, spd: 1.2, col: '#e8ffff', size: 1.4, glow: 6, line: 0.35 });
        if (lv >= 5) {
          L.part({ t: 'crystal', p: [legTop[0], legTop[1] - 15], h: 12, w: 5.5, col: acc, bob: 1.6, spd: 0.9 });
          L.part({ t: 'beam', a: [legTop[0], legTop[1] - 30], b: [legTop[0], legTop[1] - 78], col: acc, w: 5, spd: 2.6 });
          L.part({ t: 'rings', p: [legTop[0], legTop[1] - 6], rx: 24, ry: 9, n: 3, spd: 0.55, col: acc, a: 0.7 });
          L.part({ t: 'orbit', p: [legTop[0], legTop[1] - 15], rx: 15, ry: 5, rot: -0.4, n: 4, spd: -1.7, col: '#ffffff', size: 1.2, glow: 6, q: 1 });
        }
      }
      o.top = null;
      if (lv < 5) L.part({ t: 'blink', p: [mast[0], mast[1] - (lv <= 1 ? 1 : 2)], col: '#ff4d5e', per: 1.3, ph: lv * 0.17, r: 2, glow: 12 });
      K.lamp(c, L, N.x + 0.9, N.y + 0.7, 13, pal.lamp, 2);
    };
    return o;
  };
})();
