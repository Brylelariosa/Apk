/* AI Empire Tycoon - the server closet and the five data halls (A.shed, A.hall).
   A hall is a cutaway room: two solid back walls and glass along the two front edges, so you look straight in at the racks.
   Everything that is not a rack is built from small painters below (walls, monitors, cooling units, cable trays, glass, dome), and
   what moves (fans, mist, rising heat, data pulses, the wall monitors, the technician) is a list of parts for art-live.js.
   The racks themselves come from art-hw.js: a hall is drawn from the cells it is given, one entry per rack (see racks.js). */
(function () {
  'use strict';
  const G = window.G, U = G.U, D = G.D, A = G.art, K = A.kit;
  const P = A.P, poly = A.poly, ell = A.ell, hash = A.hash, box = A.box, tri = A.tri, fL = A.fL, fR = A.fR, quad = A.quad;
  const TAU = Math.PI * 2;
  const TILE = 35.78;                    // a tile edge is this long on screen, so a wall of w tiles is w * TILE wide when painted flat
  const FZ = 6, WT = 0.22;               // top of the raised floor; thickness of the two back walls
  const RX = 0.95, RDX = 0.72, RY = 0.75, RDY = 1.55;   // where the racks stand (the first one, and the step along a row and from row to row)
  const TRAY_Z = FZ + 38 + 3;            // cable trays run just above the racks (A.hw.RACK_H = 38)

  /* ---------- plan ---------- */
  // [0] is the closet; the rooms are as tall as their ceiling frame needs (the neighbours in front of them hide a little of their foot)
  A.HALLS = [
    { x: 6.6, y: 1.4, w: 1.3, d: 1.5, h: 30 },
    { x: 1, y: 7.5, w: 5, d: 4.5, h: 46 },
    { x: 8.5, y: 7.5, w: 6, d: 5, h: 48 },
    { x: 1, y: 13.5, w: 7, d: 5.2, h: 50 },
    { x: 9, y: 15, w: 8, d: 6, h: 54 },
    { x: 15.2, y: 8.2, w: 6, d: 6, h: 58 }
  ];
  A.hallGrid = (lv) => { const H = A.HALLS[lv]; return { cols: Math.max(2, Math.floor((H.w - 1) / RDX)), rows: Math.max(1, Math.floor((H.d - 0.9) / RDY)) }; };
  const rackAt = (H, g, k) => ({ x: H.x + RX + (k % g.cols) * RDX, y: H.y + RY + Math.floor(k / g.cols) * RDY });

  // What each room has. noc: wall monitors (what each one shows is in SCREENS); tray: overhead cable trays; floor: LED strips in the floor;
  // bot: a maintenance robot; holo: a hologram in the aisle; dome: a glass dome over the room.
  const CFG = [
    null,
    { name: 'SERVER ROOM', noc: [1], tray: 0, floor: 0, bot: 0, holo: 0, dome: 0, aisle: 0 },
    { name: 'DATA HALL', noc: [0, 1], tray: 0, floor: 0, bot: 0, holo: 0, dome: 0, aisle: 1 },
    { name: 'HYPERSCALE', noc: [2, 0, 1], tray: 1, floor: 0, bot: 0, holo: 0, dome: 0, aisle: 1 },
    { name: 'AI SUPERCAMPUS', noc: [0, 2, 5, 1, 3], tray: 1, floor: 1, bot: 1, holo: 1, dome: 0, aisle: 1 },
    { name: 'PLANETARY GRID', noc: [0, 2, 4, 1, 3], tray: 1, floor: 1, bot: 1, holo: 0, dome: 1, aisle: 1 }
  ];

  /* ---------- colours (taken from the skin, so the halls match the rest of the island) ---------- */
  function cols(pal) {
    if (pal._dc) return pal._dc;
    return (pal._dc = {
      wall: tri(K.hexMix(pal.wall.hex, '#2a3a66', 0.6)),
      floor: tri(K.hexMix('#243258', pal.acc, 0.06)),
      steel: tri('#8a9bc0'),
      beam: tri('#4a5880'),
      dark: tri('#141c36'),
      cab: tri('#c9d4ea'),
      glass: [K.hexMix(pal.glassHex, '#a4e6ff', 0.4), K.hex(K.hexMix(pal.glassHex, '#1d4a78', 0.5), 0.6)]
    });
  }

  /* ---------- flat painters (K.sheet: x runs along the wall, y down from its top, in pixels) ---------- */
  // Paint on the floor instead of a wall: (0, 0) is the north corner of the room, x runs along +x and y along +y, one pixel = one pixel along a tile edge.
  function floorSheet(c, x, y, fn) {
    const o = P(x, y, FZ);
    c.save(); c.transform(32 / TILE, 16 / TILE, -32 / TILE, 16 / TILE, o[0], o[1]); fn(c); c.restore();
  }

  // The inside of a back wall: light from above, panel seams, a cove light under the ceiling, conduit with brackets and a dark kick plate.
  function wallBase(cc, W, Hh, pal) {
    const g = cc.createLinearGradient(0, 0, 0, Hh);
    g.addColorStop(0, 'rgba(255,255,255,.12)'); g.addColorStop(0.5, 'rgba(255,255,255,0)'); g.addColorStop(1, 'rgba(0,0,0,.4)');
    cc.fillStyle = g; cc.fillRect(0, 0, W, Hh);
    cc.fillStyle = 'rgba(0,0,0,.17)'; for (let x = TILE * 0.5; x < W - 1; x += TILE * 0.5) cc.fillRect(x, 0, 0.9, Hh);
    cc.fillStyle = 'rgba(255,255,255,.06)'; for (let x = TILE * 0.5 + 0.9; x < W - 1; x += TILE * 0.5) cc.fillRect(x, 0, 0.7, Hh);
    cc.fillStyle = U.rgba(pal.acc, 0.85); cc.fillRect(0, 2.6, W, 1.2);                                  // the cove light
    cc.fillStyle = U.rgba(pal.acc, 0.14); cc.fillRect(0, 3.8, W, 3);
    cc.fillStyle = '#6f80a6'; cc.fillRect(0, 5.8, W, 2.2); cc.fillStyle = 'rgba(255,255,255,.35)'; cc.fillRect(0, 5.8, W, 0.8);   // conduit
    cc.fillStyle = '#3c4a6e'; for (let x = TILE * 0.3; x < W; x += TILE * 0.9) cc.fillRect(x, 4.8, 1.6, 4.4);
    cc.fillStyle = 'rgba(6,10,24,.5)'; cc.fillRect(0, Hh - 5, W, 5);
  }

  /* ---------- what the wall monitors show (drawn live) ---------- */
  const SCREENS = [
    // 0: load bars
    (cc, x, y, w, h, T, i, acc) => {
      const n = Math.max(4, Math.floor(w / 4)), bw = (w - 3) / n;
      for (let j = 0; j < n; j++) {
        const v = 0.25 + 0.7 * (0.5 + 0.5 * Math.sin(T * (1.3 + j * 0.17) + j * 1.9 + i * 2.3));
        cc.fillStyle = v > 0.86 ? '#ffb347' : acc; cc.fillRect(x + 1.5 + j * bw, y + h - 1.5 - (h - 3) * v, bw - 1, (h - 3) * v);
      }
    },
    // 1: a throughput graph
    (cc, x, y, w, h, T, i, acc) => {
      cc.fillStyle = 'rgba(255,255,255,.12)'; cc.fillRect(x + 1, y + h * 0.5, w - 2, 0.6);
      cc.strokeStyle = acc; cc.lineWidth = 1.1; cc.beginPath();
      for (let j = 0; j <= 14; j++) { const t = j / 14, v = 0.5 + 0.26 * Math.sin(T * 1.2 + t * 6 + i) + 0.14 * Math.sin(T * 2.9 + t * 13), px = x + 1.5 + t * (w - 3), py = y + h - 2 - v * (h - 4); j ? cc.lineTo(px, py) : cc.moveTo(px, py); }
      cc.stroke();
    },
    // 2: a heat map of the racks
    (cc, x, y, w, h, T, i) => {
      const cw = 4, ch = 3.4, nx = Math.floor((w - 2) / cw), ny = Math.floor((h - 2) / ch), s = Math.floor(T * 1.6) % 9 + 3;
      for (let a = 0; a < nx; a++) for (let b = 0; b < ny; b++) {
        const r = hash(a + i * 5, b, s);
        cc.fillStyle = r > 0.9 ? '#ff6b6b' : r > 0.64 ? '#ffd27a' : 'rgba(61,214,198,' + (0.22 + r * 0.5).toFixed(2) + ')';
        cc.fillRect(x + 1 + a * cw, y + 1 + b * ch, cw - 0.8, ch - 0.8);
      }
    },
    // 3: a gauge
    (cc, x, y, w, h, T, i, acc) => {
      const r = Math.min(w, h) * 0.36, cx = x + w / 2, cy = y + h * 0.58, v = 0.55 + 0.3 * Math.sin(T * 0.7 + i);
      cc.lineWidth = 2; cc.strokeStyle = 'rgba(255,255,255,.14)'; cc.beginPath(); cc.arc(cx, cy, r, Math.PI, TAU); cc.stroke();
      cc.strokeStyle = acc; cc.beginPath(); cc.arc(cx, cy, r, Math.PI, Math.PI + Math.PI * v); cc.stroke();
      cc.fillStyle = '#f2feff'; cc.fillRect(cx - 0.8, cy - r * 0.2, 1.6, r * 0.2 + 1);
    },
    // 4: the planet, turning
    (cc, x, y, w, h, T, i, acc) => {
      const r = Math.min(w * 0.5, h) * 0.42, cx = x + w / 2, cy = y + h / 2;
      cc.fillStyle = U.rgba(acc, 0.14); cc.beginPath(); cc.arc(cx, cy, r, 0, TAU); cc.fill();
      cc.strokeStyle = U.rgba(acc, 0.85); cc.lineWidth = 0.9; cc.beginPath(); cc.arc(cx, cy, r, 0, TAU); cc.stroke();
      for (let m = 0; m < 3; m++) { const a = T * 0.6 + (m * Math.PI) / 3; cc.beginPath(); cc.ellipse(cx, cy, Math.max(0.5, Math.abs(Math.cos(a)) * r), r, 0, 0, TAU); cc.stroke(); }
      cc.beginPath(); cc.ellipse(cx, cy, r, r * 0.3, 0, 0, TAU); cc.stroke();
      for (let j = 0; j < 9; j++) {
        const a = T * 0.6 + j * 2.4, lat = (hash(j, 3, 5) - 0.5) * 1.5;
        if (Math.cos(a) < 0) continue;
        cc.fillStyle = hash(j, 7, 3) > 0.5 ? '#ffe08a' : '#f2feff'; cc.fillRect(cx + Math.sin(a) * Math.cos(lat) * r - 0.7, cy + Math.sin(lat) * r - 0.7, 1.4, 1.4);
      }
    },
    // 5: a neural net with signals running through it
    (cc, x, y, w, h, T, i, acc) => {
      const L3 = [3, 4, 3], px = (l) => x + w * (0.2 + l * 0.3), py = (l, k) => y + h * ((k + 1) / (L3[l] + 1));
      cc.strokeStyle = U.rgba(acc, 0.28); cc.lineWidth = 0.7; cc.beginPath();
      for (let l = 0; l < 2; l++) for (let a = 0; a < L3[l]; a++) for (let b = 0; b < L3[l + 1]; b++) { cc.moveTo(px(l), py(l, a)); cc.lineTo(px(l + 1), py(l + 1, b)); }
      cc.stroke();
      for (let l = 0; l < 3; l++) for (let k = 0; k < L3[l]; k++) {
        const on = Math.sin(T * 3 - l * 1.4 + k * 1.7) > 0.3;
        cc.fillStyle = on ? '#f2feff' : U.rgba(acc, 0.6); cc.beginPath(); cc.arc(px(l), py(l, k), on ? 1.6 : 1.2, 0, TAU); cc.fill();
      }
    }
  ];

  // The wall of monitors: where each one sits on the north wall (flat pixels), widths 1 or 1.45 of a unit.
  function nocLayout(kinds, W, band) {
    const n = kinds.length, wm = kinds.map((k, i) => (n === 5 && i === 2 ? 1.45 : 1)), units = wm.reduce((a, b) => a + b, 0), gap = 3;
    const sw = Math.min(34, (W - 22 - gap * (n - 1)) / units), h = Math.max(8, Math.min(16, band - 10)), out = [];
    let x = (W - (sw * units + gap * (n - 1))) / 2;
    kinds.forEach((k, i) => { out.push({ x, y: 9, w: sw * wm[i], h, k }); x += sw * wm[i] + gap; });
    return out;
  }
  function monitorFrames(cc, list, pal) {
    for (const s of list) {
      cc.fillStyle = U.rgba(pal.acc, 0.1); cc.fillRect(s.x - 3, s.y - 3, s.w + 6, s.h + 6);
      cc.fillStyle = '#04070f'; K.rrect(cc, s.x - 1.5, s.y - 1.5, s.w + 3, s.h + 3, 1.6); cc.fill();
      cc.fillStyle = '#07121f'; cc.fillRect(s.x, s.y, s.w, s.h);
      cc.strokeStyle = U.rgba(pal.acc, 0.5); cc.lineWidth = 0.7; cc.strokeRect(s.x - 1.2, s.y - 1.2, s.w + 2.4, s.h + 2.4);
    }
  }

  /* ---------- the parts of a hall ---------- */
  function drawFloor(c, H, F, pal, C, spans) {
    // raised floor: panels of half a tile
    c.strokeStyle = 'rgba(255,255,255,.06)'; c.lineWidth = 1; c.beginPath();
    for (let i = 0.5; i < H.w; i += 0.5) { const a = P(H.x + i, H.y, FZ), b = P(H.x + i, H.y + H.d, FZ); c.moveTo(a[0], a[1]); c.lineTo(b[0], b[1]); }
    for (let j = 0.5; j < H.d; j += 0.5) { const a = P(H.x, H.y + j, FZ), b = P(H.x + H.w, H.y + j, FZ); c.moveTo(a[0], a[1]); c.lineTo(b[0], b[1]); }
    c.stroke();
    c.strokeStyle = 'rgba(0,0,0,.18)'; c.beginPath();
    for (let i = 0.5; i < H.w; i += 0.5) { const a = P(H.x + i + 0.03, H.y, FZ), b = P(H.x + i + 0.03, H.y + H.d, FZ); c.moveTo(a[0], a[1]); c.lineTo(b[0], b[1]); }
    c.stroke();
    // cold air comes up through perforated tiles in front of every row; the floor lights up in the biggest halls
    for (const s of spans) {
      const ya = s.y + 0.93, yb = s.y + 1.42, xa = s.x0 - 0.1, xb = s.x1 + 0.1;
      poly(c, [P(xa, ya, FZ), P(xb, ya, FZ), P(xb, yb, FZ), P(xa, yb, FZ)], 'rgba(77,200,255,.10)');
      c.fillStyle = 'rgba(160,225,255,.32)';
      for (let x = xa + 0.1; x < xb; x += 0.2) for (let y = ya + 0.08; y < yb; y += 0.2) { const p = P(x, y, FZ); c.fillRect(p[0] - 0.5, p[1] - 0.3, 1, 0.8); }
      if (F.floor) {
        const a = P(xa, s.y + 0.97, FZ), b = P(xb, s.y + 0.97, FZ);
        c.lineCap = 'round'; c.strokeStyle = U.rgba(pal.acc, 0.16); c.lineWidth = 5; c.beginPath(); c.moveTo(a[0], a[1]); c.lineTo(b[0], b[1]); c.stroke();
        c.strokeStyle = U.rgba(pal.acc, 0.75); c.lineWidth = 1.5; c.beginPath(); c.moveTo(a[0], a[1]); c.lineTo(b[0], b[1]); c.stroke();
      }
    }
    // a safety line along the front and the name of the aisle on the floor
    floorSheet(c, H.x, H.y, (cc) => {
      cc.fillStyle = 'rgba(255,205,80,.5)'; cc.fillRect(0.7 * TILE, (H.d - 0.42) * TILE, (H.w - 1.4) * TILE, 1.5);
      if (F.aisle && spans.length) {
        const s = spans[spans.length - 1];
        K.text(cc, 'COLD AISLE', (s.x0 - H.x + (s.x1 - s.x0) / 2) * TILE, (s.y + 1.18 - H.y) * TILE, 4.8, 'rgba(130,220,255,.5)', { align: 'center', sp: 1.6, weight: 700 });
      }
    });
  }

  // A cooling unit (CRAC) against the west wall, with a fan on top that breathes out cold mist.
  function crac(c, L, C, x, y) {
    const w = 0.5, d = 0.9, h = 22, b = K.bx(c, x, y, w, d, h, FZ, C.cab);
    K.sheet(c, b.R, (cc, W, Hh) => {
      cc.fillStyle = 'rgba(28,44,82,.65)'; cc.fillRect(W * 0.1, Hh * 0.1, W * 0.8, Hh * 0.52);
      cc.fillStyle = 'rgba(190,210,245,.35)'; for (let s = 0; s < 6; s++) cc.fillRect(W * 0.1, Hh * 0.1 + s * Hh * 0.088 + 1.2, W * 0.8, 0.9);
      cc.fillStyle = '#071022'; cc.fillRect(W * 0.1, Hh * 0.7, W * 0.44, Hh * 0.2);
      cc.fillStyle = '#6bffd0'; cc.fillRect(W * 0.13, Hh * 0.76, W * 0.2, 1.4); cc.fillRect(W * 0.13, Hh * 0.82, W * 0.3, 1);
      cc.fillStyle = '#4dc8ff'; cc.fillRect(W * 0.64, Hh * 0.76, 2, 2); cc.fillStyle = '#ffb347'; cc.fillRect(W * 0.78, Hh * 0.76, 2, 2);
    });
    K.sheet(c, b.L, (cc, W, Hh) => {
      cc.fillStyle = 'rgba(40,60,100,.35)'; cc.fillRect(W * 0.12, Hh * 0.1, W * 0.76, Hh * 0.8);
      cc.fillStyle = 'rgba(255,255,255,.4)'; cc.fillRect(W * 0.7, Hh * 0.45, 1, Hh * 0.14);
    });
    const t = P(x + w / 2, y + d / 2, FZ + h);
    ell(c, t[0], t[1], 8.4, 4.4); c.fillStyle = 'rgba(8,14,30,.9)'; c.fill();
    L.part({ t: 'fan', p: t, r: 6.2, spd: 9 });
    L.part({ t: 'steam', p: [t[0], t[1] - 3], n: 3, rise: 15, size: 3.2, a: 0.2, col: 'rgba(150,215,255,1)', speed: 0.5, q: 1 });
  }

  // The power distribution cabinet at the end of a row of racks.
  function pdu(c, L, C, x, y, seed) {
    const b = K.bx(c, x, y, 0.2, 0.9, 40, FZ, C.dark);
    K.sheet(c, b.R, (cc, W, Hh) => {
      for (let j = 0; j < 6; j++) for (let i = 0; i < 3; i++) { cc.fillStyle = hash(i + j * 3, seed, 4) > 0.18 ? '#3dffb0' : '#ffb347'; cc.fillRect(W * 0.18 + i * W * 0.26, Hh * 0.1 + j * Hh * 0.09, 1.6, 1.6); }
      cc.fillStyle = 'rgba(190,210,245,.4)'; for (let j = 0; j < 3; j++) cc.fillRect(W * 0.16, Hh * 0.66 + j * Hh * 0.08, W * 0.68, 1.2);
    });
    L.part({ t: 'blink', p: P(x + 0.1, y + 0.45, FZ + 41), col: '#ffb347', per: 1.8, ph: hash(seed, 2, 9), r: 1.5, glow: 8, q: 1 });
  }

  // Overhead cable trays above a row: two rails, rungs, bundles of cable and a drop to every rack. Data pulses run along them.
  function tray(c, L, pal, s, row) {
    const y1 = s.y + 0.12, y2 = s.y + 0.78, ym = s.y + 0.45, x0 = s.x0 - 0.05, x1 = s.x1 + 0.05;
    const line = (a, b, col, w) => { c.strokeStyle = col; c.lineWidth = w; c.beginPath(); c.moveTo(a[0], a[1]); c.lineTo(b[0], b[1]); c.stroke(); };
    [['rgba(255,159,67,.85)', 0.25], ['rgba(77,200,255,.85)', 0.45], ['rgba(183,140,255,.85)', 0.65]].forEach(([col, f]) => line(P(x0, s.y + f, TRAY_Z - 0.6), P(x1, s.y + f, TRAY_Z - 0.6), col, 1.2));
    c.lineCap = 'butt'; c.strokeStyle = 'rgba(150,170,210,.55)'; c.lineWidth = 1; c.beginPath();
    for (let x = x0; x <= x1; x += 0.4) { const a = P(x, y1, TRAY_Z), b = P(x, y2, TRAY_Z); c.moveTo(a[0], a[1]); c.lineTo(b[0], b[1]); }
    c.stroke();
    line(P(x0, y1, TRAY_Z), P(x1, y1, TRAY_Z), '#aebfe0', 1.5); line(P(x0, y2, TRAY_Z), P(x1, y2, TRAY_Z), '#cfdaf0', 1.5);
    for (const r of s.racks) line(P(r.x + 0.28, ym, TRAY_Z), P(r.x + 0.28, ym, TRAY_Z - 3), 'rgba(255,159,67,.7)', 1);
    L.part({ t: 'chase', pts: [P(x0, ym, TRAY_Z + 0.5), P(x1, ym, TRAY_Z + 0.5)], n: 2, spd: 0.16 + 0.03 * row, ph: row * 0.31, col: pal.acc, size: 1.2, glow: 6, q: 1 });
  }

  // Glass along a front edge: a faint tint, streaks of reflection, mullions, a kick plate and (on the south side) a door.
  function glassPane(cc, W, Hh, C, o) {
    const g = cc.createLinearGradient(0, 0, 0, Hh);
    g.addColorStop(0, U.rgba(C.glass[0], 0.2)); g.addColorStop(0.55, U.rgba(C.glass[0], 0.06)); g.addColorStop(1, U.rgba(C.glass[1], 0.18));
    cc.fillStyle = g; cc.fillRect(0, 0, W, Hh);
    cc.save(); cc.beginPath(); cc.rect(0, 0, W, Hh); cc.clip();
    cc.fillStyle = 'rgba(255,255,255,.085)';
    for (let x = W * 0.08 + o.off; x < W + Hh; x += W * 0.36) { cc.beginPath(); cc.moveTo(x, Hh); cc.lineTo(x + 7, Hh); cc.lineTo(x + 7 + Hh * 0.5, 0); cc.lineTo(x + Hh * 0.5, 0); cc.closePath(); cc.fill(); }
    cc.restore();
    const n = Math.max(2, Math.round(W / TILE)), st = W / n;
    for (let i = 1; i < n; i++) { cc.fillStyle = 'rgba(190,210,245,.5)'; cc.fillRect(i * st - 0.6, 0, 1.2, Hh); cc.fillStyle = 'rgba(8,14,32,.45)'; cc.fillRect(i * st + 0.6, 0, 0.8, Hh); }
    cc.fillStyle = 'rgba(190,210,245,.35)'; cc.fillRect(0, Hh * 0.42, W, 1);
    cc.fillStyle = 'rgba(40,52,86,.9)'; cc.fillRect(0, Hh - 5, W, 5); cc.fillStyle = 'rgba(255,255,255,.25)'; cc.fillRect(0, Hh - 5, W, 0.9);
    if (o.door) {
      const d = o.door, top = Hh - d.h;
      cc.fillStyle = 'rgba(6,12,30,.35)'; cc.fillRect(d.x, top, d.w, d.h - 5);
      cc.strokeStyle = 'rgba(214,226,250,.85)'; cc.lineWidth = 1.5; cc.strokeRect(d.x, top, d.w, d.h - 5);
      cc.fillStyle = 'rgba(214,226,250,.9)'; cc.fillRect(d.x + d.w / 2 - 0.6, top, 1.2, d.h - 5); cc.fillRect(d.x + d.w * 0.5 - 4, Hh * 0.55, 1.4, 5); cc.fillRect(d.x + d.w * 0.5 + 2.6, Hh * 0.55, 1.4, 5);
      cc.fillStyle = '#071022'; cc.fillRect(d.x + d.w + 3, Hh * 0.5, 4, 7); cc.fillStyle = '#6bffd0'; cc.fillRect(d.x + d.w + 4.2, Hh * 0.5 + 1.4, 1.6, 1.6);
    }
  }

  // The dome over the planetary grid: glass, a crystal that turns at its heart and particles in orbit round it.
  function domeParts(L, pal, cx, cy, z) {
    const p = P(cx, cy, z + 26);
    L.part({ t: 'crystal', p, h: 17, w: 8, col: pal.acc, bob: 2.4, spd: 0.8 });
    L.part({ t: 'orbit', p, rx: 46, ry: 14, rot: -0.35, n: 7, spd: 0.7, col: '#bff7ff', size: 1.5, glow: 7, line: 0.18, q: 1 });
    L.part({ t: 'orbit', p, rx: 38, ry: 11, rot: 0.5, n: 5, spd: -1.0, ph: 1.2, col: pal.acc, size: 1.4, glow: 6, q: 1 });
    L.part({ t: 'sat', p: P(cx, cy, z + 40), rx: 74, ry: 24, spd: 0.3 });
    L.part({ t: 'glow', p: P(cx, cy, z + 20), r: 54, col: pal.acc, a: 0.16, pulse: 1.1 });
  }

  // The technician walks the front aisle and now and then stops to read a rack; in the biggest halls a robot patrols the other way.
  function walkers(H, F, spans) {
    const y = H.y + H.d - 0.62, x0 = H.x + 1.0, x1 = H.x + H.w - 0.9;
    return (c, T) => {
      const t = (T / 26) % 1, moving = t < 0.42 || (t >= 0.5 && t < 0.92);
      const k = t < 0.42 ? t / 0.42 : t < 0.5 ? 1 : t < 0.92 ? 1 - (t - 0.5) / 0.42 : 0;
      const p = P(U.lerp(x0, x1, k), y, FZ);
      c.save(); c.translate(p[0], p[1]);
      const hand = A.person(c, 0, 0, moving ? T * 7 : 0, '#ff9f43', false, undefined, { look: 5, face: k === 1 || (t >= 0.5 && t < 0.92) ? -1 : 1, vest: true, hat: '#ffd24a', still: !moving, arm: moving ? undefined : [7.4, -14.4] });
      if (!moving) { c.fillStyle = '#1b2236'; c.fillRect(hand[0] - 1.4, hand[1] - 5.2, 5.8, 4.6); c.fillStyle = 'rgba(120,235,255,.92)'; c.fillRect(hand[0] - 0.6, hand[1] - 4.5, 4.2, 3.2); }
      c.restore();
      if (F.bot) {
        const u = (T / 17) % 1, q = P(U.lerp(x1 - 0.4, x0 + 0.6, u < 0.5 ? u * 2 : 2 - u * 2), y - 0.38, FZ);
        c.fillStyle = 'rgba(0,0,0,.3)'; ell(c, q[0], q[1] + 1, 7, 2.6); c.fill();
        c.fillStyle = '#d8e3f7'; K.rrect(c, q[0] - 6, q[1] - 6.5, 12, 5.4, 1.8); c.fill();
        c.fillStyle = '#2a3552'; c.fillRect(q[0] - 5, q[1] - 1.8, 10, 1.7);
        c.fillStyle = '#7fe9ff'; c.fillRect(q[0] - 3, q[1] - 5.2, 6, 1.6);
        c.fillStyle = Math.sin(T * 6) > 0 ? '#ffb347' : '#5a3c18'; c.beginPath(); c.arc(q[0], q[1] - 8, 1.3, 0, TAU); c.fill();
      }
    };
  }

  /* ================= the data halls ================= */
  /* A hall holds the racks it is given. cells = one entry per drawn rack, four slots each (see racks.js): a slot is empty or holds a
     server of some tier, so buying a rack adds a rack and buying a server fills a slot. */
  A.hall = function (lv, cells, coolLv, pal) {
    const H = A.HALLS[lv], g = A.hallGrid(lv), HWa = A.hw, RK = G.racks, C = cols(pal), F = CFG[lv];
    const RZ = H.h + 3, WH = RZ - FZ, cx = H.x + H.w / 2, cy = H.y + H.d / 2;
    const o = { id: 'dc' + lv, kind: 'dc', lv, name: D.ladders.dc[lv].name, fp: [H.x, H.y, H.w, H.d, H.h], nDraw: cells.length };
    const rp = cells.map((cell, k) => Object.assign(rackAt(H, g, k), { cell }));
    o.racks = rp;
    // one entry per row that has racks: where the row runs and which racks stand in it
    const spans = [];
    for (let r = 0; r * g.cols < cells.length; r++) {
      const mine = rp.slice(r * g.cols, (r + 1) * g.cols);
      spans.push({ y: mine[0].y, x0: mine[0].x, x1: mine[mine.length - 1].x + HWa.RW, racks: mine });
    }
    const filled = RK.filled(cells), top = cells.reduce((m, cl) => Math.max(m, HWa.bestTier(cl)), -1), frac = cells.length ? filled / (cells.length * D.rack.slots) : 0;
    o.b = A.bbox(H.x - 0.2, H.y - 0.2, H.w + 0.4, H.d + 0.4, RZ + (F.dome ? 82 : 16), 12);
    // quantum arrays let off a little mist
    o.bubbles = rp.filter((r) => HWa.bestTier(r.cell) === 5).slice(0, 4).map((r) => ({ p: HWa.rackTop(r.x, r.y, FZ), mist: 1 }));
    const L = K.rig(o);   // the lit layer only holds the sign and the rails along the glass: the walls and the equipment stand behind other things
    const noc = nocLayout(F.noc, H.w * TILE, RZ - 27);
    const nCool = Math.max(1, Math.min(Math.floor((H.d - 0.8) / 1.35), 1 + coolLv));
    const walk = walkers(H, F, spans);
    o.live = (c, T) => walk(c, T);
    o.draw = (c) => {
      L.begin();
      // ---- ground and floor ----
      K.shadow(c, H.x - 0.2, H.y - 0.2, H.w + 0.4, H.d + 0.4, 0.7, 0.55);
      K.slab(c, H.x - 0.2, H.y - 0.2, H.w + 0.4, H.d + 0.4, 3, pal.concrete, { accent: pal.acc });
      box(c, H.x, H.y, H.w, H.d, FZ - 3, 3, C.floor);
      drawFloor(c, H, F, pal, C, spans);
      // ---- the two back walls ----
      box(c, H.x, H.y, H.w, WT, WH, FZ, C.wall);
      const wn = fL(H.x, H.y, H.w, WT, WH, FZ);
      K.sheet(c, wn, (cc, W, Hh) => { wallBase(cc, W, Hh, pal); monitorFrames(cc, noc, pal); });
      L.part({ t: 'face', f: wn, q: 1, fn: (cc, W, Hh, T) => noc.forEach((s, i) => { cc.save(); cc.beginPath(); cc.rect(s.x, s.y, s.w, s.h); cc.clip(); cc.fillStyle = '#06101f'; cc.fillRect(s.x, s.y, s.w, s.h); SCREENS[s.k](cc, s.x, s.y, s.w, s.h, T, i, pal.acc); cc.fillStyle = 'rgba(255,255,255,.07)'; cc.fillRect(s.x, s.y + ((T * 9 + i * 7) % s.h), s.w, 1.2); cc.restore(); }) });
      box(c, H.x, H.y, WT, H.d, WH, FZ, C.wall);
      const ww = fR(H.x, H.y, WT, H.d, WH, FZ);
      K.sheet(c, ww, (cc, W, Hh) => {
        wallBase(cc, W, Hh, pal);
        // an exit sign and a fire extinguisher at the front end
        cc.fillStyle = '#05140d'; cc.fillRect(9, 10, 17, 7); cc.fillStyle = '#35e08a'; cc.fillRect(9.8, 10.8, 15.4, 5.4); K.text(cc, 'EXIT', 17.5, 13.7, 4.2, '#04210f', { align: 'center', sp: 0.6 });
        cc.fillStyle = '#d7382f'; cc.fillRect(0.55 * TILE, Hh - 15, 4.4, 10); cc.fillStyle = '#1a1a1a'; cc.fillRect(0.55 * TILE + 0.8, Hh - 17, 2.8, 2);
      });
      L.part({ t: 'glow', p: ww(0.18, 0.74), r: 13, col: '#6bffb0', a: 0.2 });
      // ---- cooling units and the hall's own equipment, left to right ----
      for (let i = nCool - 1; i >= 0; i--) crac(c, L, C, H.x + 0.28, H.y + 0.5 + i * 1.35);
      // ---- racks, back to front: empty bays are dark, every server is a lit unit with the colour of its tier (see art-hw.js) ----
      rp.slice().sort((a, b) => (a.x + a.y) - (b.x + b.y)).forEach((r) => HWa.slotRack(c, r.cell, r.x, r.y, FZ));
      spans.forEach((s, i) => { if (lv >= 2) pdu(c, L, C, s.x1 + 0.1, s.y, i + lv * 3); });
      // heat rises from the racks to the ceiling
      rp.forEach((r, k) => { if (k % 3 === 1) L.part({ t: 'flow', pts: [P(r.x + 0.28, r.y + 0.45, FZ + 41), P(r.x + 0.28, r.y + 0.45, RZ - 5)], col: 'rgba(255,150,90,.65)', n: 3, spd: 0.2 + 0.02 * (k % 4), size: 1.1, q: 1 }); });
      // ---- overhead ----
      if (F.tray) spans.forEach((s, i) => tray(c, L, pal, s, i));
      for (let x = H.x + 1.8, n = 0; x < H.x + H.w - 0.5; x += 1.8, n++) {
        K.bx(c, x, H.y + WT, 0.09, H.d - WT - 0.07, 2.5, RZ - 2.5, C.beam, { shade: false });
        if (n < 4) L.part({ t: 'lamp', p: P(x + 0.05, H.y + H.d * 0.35, RZ - 3), r: 24, col: '#d8ecff', a: 0.3 });
      }
      if (F.holo) L.part({ t: 'holo', p: P(H.x + H.w * 0.5, H.y + H.d - 1.1, FZ + 24), r: 10, col: pal.acc, q: 1 });
      // ---- glass along the two front edges, with the name of the room and a door ----
      const gs = fL(H.x, H.y, H.w, H.d, WH, FZ), ge = fR(H.x, H.y, H.w, H.d, WH, FZ);
      K.sheet(c, gs, (cc, W, Hh) => glassPane(cc, W, Hh, C, { off: 0, door: { x: W * 0.64, w: 0.95 * TILE * 0.8, h: Math.min(30, Hh - 4) } }));
      K.sheet(c, ge, (cc, W, Hh) => glassPane(cc, W, Hh, C, { off: 9 }));
      { const w = Math.min(H.w * TILE * 0.5, 14 + F.name.length * 5.6), x = (H.w * TILE - w) * 0.28; L.sign(c, gs, (cc, W, Hh, lit) => K.plate(cc, x, 6, w, 8, F.name, pal.acc, lit, { size: 4.8, sp: 0.9 })); }
      // ---- the frame: columns at the three front corners, beams along the top and a rail of light on them ----
      K.bx(c, H.x, H.y + H.d - 0.07, H.w, 0.14, 4, RZ - 4, C.steel);
      K.bx(c, H.x + H.w - 0.07, H.y, 0.14, H.d, 4, RZ - 4, C.steel);
      for (const [px, py] of [[H.x, H.y + H.d], [H.x + H.w, H.y + H.d], [H.x + H.w, H.y]]) K.bx(c, px - 0.06, py - 0.06, 0.12, 0.12, WH, FZ, C.steel);
      const rail = [P(H.x, H.y + H.d, RZ), P(H.x + H.w, H.y + H.d, RZ), P(H.x + H.w, H.y, RZ)];
      L.draw(c, (cc, lit) => { cc.lineJoin = 'round'; cc.strokeStyle = U.rgba(pal.acc, lit ? 0.95 : 0.6); cc.lineWidth = lit ? 2.2 : 1.6; cc.beginPath(); rail.forEach((q, i) => (i ? cc.lineTo(q[0], q[1]) : cc.moveTo(q[0], q[1]))); cc.stroke(); });
      if (F.dome) {
        K.glassDome(c, cx, cy, RZ, 2.85, 66, '#8fd6ff', { open: true });
        domeParts(L, pal, cx, cy, RZ);
      }
    };
    // blinking LED layers (drawn into small sprites by the scene)
    o.ledB = A.bbox(H.x, H.y, H.w, H.d, FZ + HWa.RACK_H + 12, 6);
    o.leds = (c, k) => rp.forEach((r, ri) => HWa.slotLeds(c, r.cell, r.x, r.y, FZ, k, ri));
    o.glow = filled > 0 ? [{ p: P(cx, cy, 14), r: Math.min(95, 28 + H.w * 9), c: HWa.accent(top), a: 0.05 + 0.12 * frac }] : [];
    return o;
  };

  /* ================= the server closet ================= */
  // A prefab cabin behind the office. Its door stands open so you can see the racks inside.
  // cells = the racks in it, one entry per rack with four slots each (see racks.js), so the picture shows how many servers there are.
  A.shed = function (pal, cells) {
    const H = A.HALLS[0], C = cols(pal), HWa = A.hw;
    const o = { id: 'dc0', kind: 'dc', lv: 0, name: D.ladders.dc[0].name, fp: [H.x, H.y, H.w, H.d, H.h] };
    cells = cells && cells.length ? cells : [[-1, -1, -1, -1]];
    const n = cells.length, u0 = 0.15, u1 = 0.9, top = 0.8, gap = 0.03, wd = ((u1 - u0) - 0.04 - gap * (n - 1)) / n;
    const live = G.racks.filled(cells) > 0, spot = (i) => { const a = u0 + 0.02 + i * (wd + gap); return [a, a + wd]; };
    const Z = 2, T = Z + H.h, cabin = tri(K.hexMix(pal.metal.hex, pal.wall.hex, 0.25));
    o.b = A.bbox(H.x - 0.15, H.y - 0.15, H.w + 0.3, H.d + 0.3, H.h + 34, 10);
    const L = K.rig(o); o.lit = null;
    const fl = fL(H.x, H.y, H.w, H.d, H.h, Z);
    o.draw = (c) => {
      L.begin();
      K.shadow(c, H.x - 0.15, H.y - 0.15, H.w + 0.3, H.d + 0.3, 0.5, 0.5);
      K.slab(c, H.x - 0.15, H.y - 0.15, H.w + 0.3, H.d + 0.3, Z, pal.concrete, { accent: pal.acc });
      const b = K.bx(c, H.x, H.y, H.w, H.d, H.h, Z, cabin);
      // corrugated walls
      const ribs = (cc, W, Hh, a) => { for (let x = 0; x < W; x += 3) { cc.fillStyle = 'rgba(255,255,255,' + a + ')'; cc.fillRect(x, 0, 1, Hh); cc.fillStyle = 'rgba(0,0,0,' + a * 1.4 + ')'; cc.fillRect(x + 1.2, 0, 0.9, Hh); } };
      K.sheet(c, b.L, (cc, W, Hh) => { ribs(cc, W, Hh, 0.07); cc.fillStyle = 'rgba(255,205,80,.55)'; for (let x = 0; x < W; x += 6) { cc.beginPath(); cc.moveTo(x, Hh); cc.lineTo(x + 3, Hh); cc.lineTo(x + 6, Hh - 3); cc.lineTo(x + 3, Hh - 3); cc.fill(); } });
      K.sheet(c, b.R, (cc, W, Hh) => {
        ribs(cc, W, Hh, 0.06);
        cc.fillStyle = 'rgba(6,10,24,.55)'; for (let i = 0; i < 4; i++) cc.fillRect(W * 0.14, Hh * (0.14 + i * 0.1), W * 0.34, Hh * 0.05);   // louvres
        cc.fillStyle = 'rgba(8,14,30,.85)'; cc.beginPath(); cc.arc(W * 0.72, Hh * 0.4, 7.4, 0, TAU); cc.fill();                                  // the wall AC unit
        cc.strokeStyle = 'rgba(190,210,245,.5)'; cc.lineWidth = 0.9; cc.beginPath(); cc.arc(W * 0.72, Hh * 0.4, 7.4, 0, TAU); cc.stroke();
      });
      L.part({ t: 'face', f: b.R, q: 1, fn: (cc, W, Hh, Tm) => { cc.save(); cc.translate(W * 0.72, Hh * 0.4); cc.rotate(Tm * 9); cc.strokeStyle = 'rgba(205,220,245,.9)'; cc.lineWidth = 1.6; cc.beginPath(); for (let i = 0; i < 4; i++) { const a = (i * TAU) / 4; cc.moveTo(0, 0); cc.lineTo(Math.cos(a) * 6.2, Math.sin(a) * 6.2); } cc.stroke(); cc.restore(); } });
      // the doorway: a dark room, its lit floor, the racks seen straight on, a light along the ceiling, the open door leaf and a status strip
      A.quad(c, fl, u0, u1, 0, top, '#080d1c');
      A.quad(c, fl, u0, u1, 0, 0.07, U.rgba(pal.acc, live ? 0.22 : 0.06));
      cells.forEach((cell, i) => { const [a, bb] = spot(i); HWa.slotsFlat(c, fl, a, bb, 0.05, top - 0.03, cell); });
      A.quad(c, fl, u0 + 0.02, u1 - 0.02, top - 0.07, top - 0.035, 'rgba(210,235,255,.85)');
      A.quad(c, fl, u0, u0 + 0.035, 0, top, 'rgba(0,0,0,.35)'); A.quad(c, fl, u1 - 0.035, u1, 0, top, 'rgba(0,0,0,.28)');
      A.quad(c, fl, 0.04, u0, 0, top, '#3b4868'); A.quad(c, fl, 0.04, 0.065, 0, top, 'rgba(255,255,255,.14)'); A.quad(c, fl, 0.075, 0.13, 0.5, 0.7, 'rgba(120,190,255,.35)');
      A.quad(c, fl, u0, u1, top, top + 0.06, '#3b4868');
      A.quad(c, fl, 0.2, 0.84, top + 0.1, top + 0.17, live ? U.rgba(pal.acc, 0.75) : 'rgba(255,107,129,.55)');
      // the roof: an air conditioner, a dish and a mast with a status light (green while servers run)
      K.roof(c, H.x, H.y, H.w, H.d, T, pal.roof);
      K.hvac(c, L, pal, H.x + 0.2, H.y + 0.28, T, 0.7, 0.55, 7);
      K.dish(c, H.x + H.w - 0.28, H.y + 0.32, T, 5, { h: 8 });
      K.antenna(c, L, H.x + H.w - 0.2, H.y + H.d - 0.3, T, 15, live ? '#46e39a' : '#ff4d5e', { bars: [0.6] });
      K.lamp(c, L, H.x - 0.1, H.y + H.d + 0.12, 15, pal.lamp, Z);
      L.part({ t: 'glow', p: P(H.x + H.w * 0.5, H.y + H.d, Z + 6), r: 22, col: pal.acc, a: live ? 0.16 : 0.05 });
    };
    o.leds = (c, k) => cells.forEach((cell, i) => { const [a, b] = spot(i); HWa.slotsFlatLeds(c, fl, a, b, 0.05, top - 0.03, cell, k, i); });
    o.ledB = A.bbox(H.x, H.y, H.w, H.d, H.h, 6);
    return o;
  };
})();
