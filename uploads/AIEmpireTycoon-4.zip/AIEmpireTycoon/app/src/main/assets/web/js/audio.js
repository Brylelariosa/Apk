/* AI Empire Tycoon - synthesized audio (WebAudio). Nothing is downloaded or decoded. */
(function () {
  'use strict';
  const G = window.G;
  const Au = (G.audio = {});
  let ctx = null, master = null, mg = null, sg = null, timer = null, step = 0, running = false;
  Au.vol = { music: 0.3, sfx: 0.7 };
  const NOTE = (n) => 440 * Math.pow(2, (n - 69) / 12);

  Au.init = function () {
    if (ctx) { if (ctx.state === 'suspended') ctx.resume(); return; }
    try {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return;
      ctx = new AC();
      master = ctx.createGain(); master.gain.value = 0.9; master.connect(ctx.destination);
      mg = ctx.createGain(); mg.connect(master);
      sg = ctx.createGain(); sg.connect(master);
      Au.apply();
    } catch (e) { ctx = null; }
  };
  Au.apply = function () {
    if (!ctx) return;
    mg.gain.value = Au.vol.music * 0.4;
    sg.gain.value = Au.vol.sfx;
    if (Au.vol.music > 0.01 && !document.hidden) start(); else stop();
  };
  Au.suspend = function () { stop(); if (ctx && ctx.state === 'running') ctx.suspend(); };
  Au.resume = function () { if (ctx && ctx.state === 'suspended') ctx.resume(); Au.apply(); };

  function tone(f, d, type, v, when, to, bus) {
    if (!ctx || Au.vol.sfx <= 0.01) return;
    const t = ctx.currentTime + (when || 0), o = ctx.createOscillator(), g = ctx.createGain();
    o.type = type || 'sine';
    o.frequency.setValueAtTime(f, t);
    if (to) o.frequency.exponentialRampToValueAtTime(to, t + d);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(v || 0.2, t + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t + d);
    o.connect(g); g.connect(bus || sg);
    o.start(t); o.stop(t + d + 0.05);
  }
  // a short burst of filtered noise that sweeps from one pitch to another (wind, fireworks, lightning)
  function noise(d, f0, f1, v, when) {
    if (!ctx || Au.vol.sfx <= 0.01) return;
    const t = ctx.currentTime + (when || 0), n = Math.max(1, Math.floor(ctx.sampleRate * d)), buf = ctx.createBuffer(1, n, ctx.sampleRate), ch = buf.getChannelData(0);
    for (let i = 0; i < n; i++) ch[i] = Math.random() * 2 - 1;
    const src = ctx.createBufferSource(), f = ctx.createBiquadFilter(), g = ctx.createGain();
    src.buffer = buf; f.type = 'bandpass'; f.Q.value = 0.9;
    f.frequency.setValueAtTime(f0, t); f.frequency.exponentialRampToValueAtTime(f1, t + d);
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(v, t + d * 0.3); g.gain.exponentialRampToValueAtTime(0.0001, t + d);
    src.connect(f); f.connect(g); g.connect(sg);
    src.start(t); src.stop(t + d + 0.05);
  }
  // the busy sounds of the living island are rate limited, so a shower of coins is a sparkle and not a buzz
  const GAP = { tick: 0.09, chirp: 0.3, firework: 0.12, zap: 0.4, whoosh: 0.6, fast: 0.08, event: 0.4, event_bad: 0.4 };
  const lastAt = {};
  function limited(n) {
    if (!GAP[n]) return false;
    const t = ctx.currentTime;
    if (lastAt[n] !== undefined && t - lastAt[n] < GAP[n]) return true;
    lastAt[n] = t;
    return false;
  }
  Au.sfx = function (n) {
    if (!ctx || ctx.state === 'suspended' || limited(n)) return;
    switch (n) {
      case 'tick': tone(NOTE(96 + Math.floor(Math.random() * 3) * 2), 0.07, 'sine', 0.045); break;            // a coin lands on the counter
      case 'chirp': tone(NOTE(88), 0.06, 'sine', 0.07); tone(NOTE(93), 0.09, 'sine', 0.06, 0.05); break;       // Lumo says something
      case 'fast': tone(NOTE(79), 0.06, 'triangle', 0.1); tone(NOTE(86), 0.09, 'triangle', 0.1, 0.05); break;   // the speed changed
      case 'whoosh': noise(0.9, 300, 2600, 0.16); break;                                                         // a rocket leaves
      case 'firework': noise(0.4, 3200, 500, 0.1); tone(NOTE(96), 0.12, 'sine', 0.05, 0.04); break;
      case 'zap': noise(0.28, 4200, 260, 0.18); tone(120, 0.22, 'sawtooth', 0.07, 0, 55); break;                 // lightning
      case 'event': tone(NOTE(81), 0.3, 'sine', 0.11); tone(NOTE(86), 0.4, 'sine', 0.1, 0.12); tone(NOTE(90), 0.55, 'sine', 0.08, 0.24); break;
      case 'event_bad': tone(NOTE(65), 0.25, 'triangle', 0.1); tone(NOTE(62), 0.4, 'triangle', 0.1, 0.16); break;
      case 'tap': tone(560, 0.05, 'triangle', 0.1); break;
      case 'buy': tone(NOTE(76), 0.1, 'triangle', 0.17); tone(NOTE(83), 0.16, 'triangle', 0.15, 0.07); break;
      case 'err': tone(180, 0.16, 'square', 0.07, 0, 120); break;
      case 'research': [72, 76, 79, 84].forEach((m, i) => tone(NOTE(m), 0.22, 'sine', 0.15, i * 0.08)); break;
      case 'build': tone(120, 0.08, 'square', 0.1); tone(160, 0.08, 'square', 0.08, 0.1); tone(NOTE(79), 0.3, 'triangle', 0.12, 0.2); break;
      case 'train': tone(NOTE(60), 0.5, 'sine', 0.14); tone(NOTE(67), 0.5, 'sine', 0.1, 0.1); break;
      case 'release': [60, 64, 67, 72, 76].forEach((m, i) => { tone(NOTE(m), 1.2, 'triangle', 0.13, i * 0.1); tone(NOTE(m + 12), 1.0, 'sine', 0.06, i * 0.1 + 0.05); }); break;
      case 'ach': tone(NOTE(84), 0.5, 'sine', 0.16); tone(NOTE(88), 0.6, 'sine', 0.13, 0.12); tone(NOTE(91), 0.8, 'sine', 0.1, 0.24); break;
      case 'coin': tone(NOTE(88), 0.12, 'square', 0.05); tone(NOTE(95), 0.2, 'square', 0.05, 0.06); break;
      case 'warn': tone(NOTE(70), 0.18, 'triangle', 0.1); tone(NOTE(66), 0.24, 'triangle', 0.1, 0.12); break;
      case 'prestige': [48, 55, 60, 64, 67, 72, 79].forEach((m, i) => tone(NOTE(m), 1.8, 'sine', 0.12, i * 0.14)); break;
    }
  };

  /* quiet generative ambience: a slow pad and the odd pluck */
  const PROG = [[57, 60, 64, 67], [53, 57, 60, 64], [60, 64, 67, 71], [55, 59, 62, 66]];
  const SCALE = [69, 72, 74, 76, 79, 81, 84];
  function pad(notes) {
    const t = ctx.currentTime;
    for (const n of notes) {
      const o = ctx.createOscillator(), g = ctx.createGain(), f = ctx.createBiquadFilter();
      o.type = 'triangle'; o.frequency.value = NOTE(n) * (Math.random() < 0.5 ? 1 : 1.003);
      f.type = 'lowpass'; f.frequency.value = 900;
      g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(0.09, t + 2.2); g.gain.linearRampToValueAtTime(0.0001, t + 7.5);
      o.connect(f); f.connect(g); g.connect(mg); o.start(t); o.stop(t + 7.7);
    }
  }
  function pluck() {
    const t = ctx.currentTime, n = SCALE[Math.floor(Math.random() * SCALE.length)];
    const o = ctx.createOscillator(), g = ctx.createGain();
    o.type = 'sine'; o.frequency.value = NOTE(n);
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.1, t + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, t + 1.8);
    o.connect(g); g.connect(mg); o.start(t); o.stop(t + 1.9);
  }
  function tick() {
    if (!running || !ctx) return;
    if (step % 8 === 0) pad(PROG[(step >> 3) % PROG.length]);
    if (step % 2 === 1 && Math.random() < 0.55) pluck();
    step++;
    timer = setTimeout(tick, 800);
  }
  function start() { if (running || !ctx) return; running = true; tick(); }
  function stop() { running = false; if (timer) { clearTimeout(timer); timer = null; } }
})();
