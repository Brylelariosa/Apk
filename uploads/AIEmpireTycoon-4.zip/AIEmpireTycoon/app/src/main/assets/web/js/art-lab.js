/* AI Empire Tycoon - the research lab, in three tiers: a lab with a training cluster, a campus around a holo-dome, and the Quantum
   Institute. Built with the kit in art-kit.js; the animated parts are listed in o.parts (art-live.js). Like the other buildings of the
   north row they are drawn at the coordinates below and then slid east by A.PLAN.lab.dx, which keeps the gap beside the closet open. */
(function () {
  'use strict';
  const G = window.G, U = G.U, D = G.D, A = G.art, K = A.kit;
  const P = A.P, poly = A.poly, hash = A.hash, ell = A.ell;
  const TAU = Math.PI * 2;
  const base = (tier, fp, bb, tb) => ({ id: 'lab', kind: 'lab', tier, name: D.ladders.lab[tier].name, fp, b: bb, tb });
  const line = (c, pts, col, w) => { c.strokeStyle = col; c.lineWidth = w || 1; c.beginPath(); pts.forEach((p, i) => (i ? c.lineTo(p[0], p[1]) : c.moveTo(p[0], p[1]))); c.stroke(); };
  const edgeGlow = (L, c, pts, hex, w) => L.draw(c, (cc, lit) => { cc.lineJoin = 'round'; line(cc, pts, U.rgba(hex, lit ? 0.95 : 0.5), lit ? (w || 1.6) + 0.6 : w || 1.6); });
  // the walls of the lab are a clean light grey-blue taken from the skin's wall colour
  const labWall = (pal) => pal._labWall || (pal._labWall = A.tri(K.hexMix(pal.wall.hex, '#e6efff', 0.5)));
  const labGlass = (pal) => [K.hexMix(pal.glassHex, '#9fe6ff', 0.45), K.hex(K.hexMix(pal.glassHex, '#1d4a78', 0.5), 0.6)];

  /* ---------- flat painters ---------- */
  // A lab window: cool glass by day, a bright room with a bench and a screen at night.
  function labPane(cc, x, y, w, h, lit, seed, glass) {
    if (lit) {
      const g = cc.createLinearGradient(0, y, 0, y + h); g.addColorStop(0, 'rgba(214,250,255,.98)'); g.addColorStop(1, 'rgba(96,204,240,.72)');
      cc.fillStyle = g; cc.fillRect(x, y, w, h);
      cc.fillStyle = 'rgba(8,40,74,.3)'; cc.fillRect(x, y + h * 0.7, w, h * 0.3);
      cc.fillStyle = 'rgba(255,255,255,.92)'; cc.fillRect(x + w * (0.15 + hash(seed, 1, 6) * 0.5), y + h * 0.4, w * 0.22, h * 0.2);
      return;
    }
    cc.fillStyle = 'rgba(6,10,24,.92)'; cc.fillRect(x - 1.2, y - 1.2, w + 2.4, h + 2.4);
    const g = cc.createLinearGradient(0, y, 0, y + h); g.addColorStop(0, glass[0]); g.addColorStop(1, glass[1]);
    cc.fillStyle = g; cc.fillRect(x, y, w, h);
    cc.fillStyle = 'rgba(255,255,255,.2)'; cc.beginPath(); cc.moveTo(x + w * 0.08, y + h); cc.lineTo(x + w * 0.36, y + h); cc.lineTo(x + w * 0.82, y); cc.lineTo(x + w * 0.54, y); cc.fill();
    cc.fillStyle = 'rgba(255,255,255,.3)'; cc.fillRect(x - 1.5, y + h + 1.2, w + 3, 1.2);
  }
  // The panels, the cornice and the foot of a light wall.
  function skin(cc, W, Hh, lit, pitch) {
    if (lit) return;
    cc.fillStyle = 'rgba(0,0,0,.1)'; for (let x = pitch; x < W - 2; x += pitch) cc.fillRect(x, 0, 0.8, Hh - 4);
    cc.fillStyle = 'rgba(255,255,255,.3)'; cc.fillRect(0, 0, W, 2); cc.fillStyle = 'rgba(0,0,0,.22)'; cc.fillRect(0, 2, W, 1.5);
    cc.fillStyle = 'rgba(8,14,32,.35)'; cc.fillRect(0, Hh - 4, W, 4);
  }
  // Racks seen through a window: dark cabinets with rows of small lights (the lights themselves blink in the live layer).
  function racks(cc, x, y, w, h, n, lit, pal) {
    if (!lit) {
      cc.fillStyle = 'rgba(6,10,24,.95)'; cc.fillRect(x - 1.4, y - 1.4, w + 2.8, h + 2.8);
      const g = cc.createLinearGradient(0, y, 0, y + h); g.addColorStop(0, '#0d2748'); g.addColorStop(1, '#06142c'); cc.fillStyle = g; cc.fillRect(x, y, w, h);
    } else { cc.fillStyle = U.rgba(pal.acc, 0.18); cc.fillRect(x, y, w, h); }
    const rw = (w - 3) / n;
    for (let i = 0; i < n; i++) {
      const rx = x + 1.5 + i * rw;
      if (!lit) { cc.fillStyle = 'rgba(14,26,52,.95)'; cc.fillRect(rx + 0.8, y + 1.5, rw - 1.6, h - 1.5); cc.strokeStyle = 'rgba(120,180,255,.35)'; cc.lineWidth = 0.8; cc.strokeRect(rx + 0.8, y + 1.5, rw - 1.6, h - 1.5); }
      for (let k = 0; k < 4; k++) { cc.fillStyle = lit ? U.rgba(pal.acc, 0.95) : 'rgba(80,200,200,.5)'; cc.fillRect(rx + 2.2, y + 3.4 + k * ((h - 6) / 4), rw * 0.5, 1.3); }
    }
  }
  // blinking lights over those racks, drawn live
  const rackLeds = (x, y, w, h, n, pal) => (cc, W, Hh, T) => {
    const rw = (w - 3) / n;
    for (let i = 0; i < n; i++) for (let k = 0; k < 4; k++) {
      const on = hash(Math.floor(T * 2.6 + hash(i, k, 3) * 5), i * 9 + k, 11) > 0.45;
      cc.fillStyle = on ? (hash(i, k, 5) > 0.8 ? '#ffd27a' : '#6bffd8') : 'rgba(40,90,100,.6)';
      cc.fillRect(x + 1.5 + i * rw + rw * 0.62, y + 3.4 + k * ((h - 6) / 4), 1.6, 1.3);
    }
  };

  /* ---------- tier 1: the AI Research Lab ---------- */
  function lab1(pal) {
    const X = 8.4, Y = 1.5, W = 4.2, D2 = 3.7, Z = 3, H = 32, T = Z + H, E = X + W, YE = Y + D2, wall = labWall(pal), glass = labGlass(pal), Lc = K.lights(pal);
    const o = base(1, [X, Y, W, D2, 52], A.bbox(7.7, 0.9, 5.8, 5.2, 96, 10), A.bbox(X, Y, W, D2, 90, 8));
    const L = K.rig(o), dark = [];
    o.glow = [{ p: P(10.4, 3.2, 50), r: 38, c: pal.acc, a: 0.25 }];
    o.orb = { p: P(10.4, 3.2, 78), r: 12 };
    o.entry = P(11.4, YE + 0.4);
    const front = (cc, Wd, Hh, lit) => {
      skin(cc, Wd, Hh, lit, 18.8);
      for (let i = 0; i < 3; i++) labPane(cc, 9 + i * 27, 8, 22, 17, lit, i, glass);
      K.door(cc, 100, Hh - 20, 16, 19, lit, glass);
      labPane(cc, 124, 8, 20, 17, lit, 5, glass);
      cc.fillStyle = U.rgba(pal.acc, lit ? 0.95 : 0.45); cc.fillRect(Wd - 1.6, 0, 1.6, Hh);
    };
    const rx = 10, ry = 7, rw = 112, rh = 19;
    const side = (cc, Wd, Hh, lit) => {
      skin(cc, Wd, Hh, lit, 22);
      racks(cc, rx, ry, rw, rh, 6, lit, pal);
      if (!lit) { cc.fillStyle = 'rgba(255,255,255,.14)'; cc.beginPath(); cc.moveTo(rx + 8, ry + rh); cc.lineTo(rx + 30, ry + rh); cc.lineTo(rx + 60, ry); cc.lineTo(rx + 38, ry); cc.fill(); }
      cc.fillStyle = U.rgba(pal.acc, lit ? 0.95 : 0.4); cc.fillRect(0, 0, 1.6, Hh);
    };
    o.draw = (c) => {
      L.begin();
      K.shadow(c, 7.5, 0.8, 5.5, 5.0, 0.5, 0.5);
      K.slab(c, 7.9, 1.1, 5.3, 4.6, Z, pal.concrete, { accent: pal.acc });
      poly(c, [P(11.05, YE, Z), P(11.75, YE, Z), P(11.75, 5.65, Z), P(11.05, 5.65, Z)], 'rgba(255,255,255,.1)');
      const b = K.bx(c, X, Y, W, D2, H, Z, wall);
      L.sheet(c, b.L, (cc, Wd, Hh, lit) => front(cc, Wd, Hh, lit));
      L.sheet(c, b.R, (cc, Wd, Hh, lit) => side(cc, Wd, Hh, lit));
      { const sx = 92; K.cutRect(L, b.L, sx, 3, 32, 7); L.sign(c, b.L, (cc, Wd, Hh, lit) => K.plate(cc, sx, 3, 32, 7, 'AI LAB', pal.acc, lit, { size: 4.8, sp: 1 })); }
      L.part({ t: 'face', f: b.R, fn: rackLeds(rx, ry, rw, rh, 6, pal) });
      // ---- the roof ----
      K.roof(c, X, Y, W, D2, T, pal.roof);
      edgeGlow(L, c, [P(X, YE, T), P(E, YE, T), P(E, Y, T)], pal.acc, 1.5);
      const st = P(12.1, 2.1, T), sh = 13;
      A.cyl(c, 12.1, 2.1, 0.22, sh, T, pal.metal);
      L.part({ t: 'steam', p: [st[0], st[1] - sh - 1], n: 3, rise: 30, size: 4, a: 0.4 });
      const rp = P(9.2, 2.3, T), rt = P(9.2, 2.3, T + 11);
      line(c, [rp, rt], '#aab9d8', 1.6); L.part({ t: 'radar', p: [rt[0], rt[1] - 1], r: 8, col: pal.acc });
      K.hvac(c, L, pal, 11.3, 3.85, T, 0.9, 0.7, 5);
      K.bx(c, X + 0.4, YE - 1.1, 1.0, 0.7, 4, T, pal.metal);
      K.glassDome(c, 10.4, 3.2, T, 1.05, 24, '#9be7ff');
      L.part({ t: 'glow', p: P(10.4, 3.2, T + 8), r: 30, col: pal.acc, a: 0.22, pulse: 1.2 });
      // ---- the yard ----
      K.lamp(c, L, 8.0, 5.55, 17, pal.lamp, Z); K.lamp(c, L, 13.05, 5.55, 17, pal.lamp, Z);
      K.planter(c, 8.7, 5.55, 1.1, 0.26, '#58c092', Z, '#3b4a6e'); K.planter(c, 12.1, 5.55, 0.8, 0.26, '#58c092', Z, '#3b4a6e');
      K.crates(c, 12.35, 5.2, '#a8793f', Z);
      L.part({ t: 'lamp', p: P(11.4, YE + 0.1, 12), r: 30, col: '#bff3ff', a: 0.4 });
    };
    return A.slide(o, A.PLAN.lab.dx, 0);
  }

  /* ---------- tier 2: the AI Research Campus ---------- */
  function lab2(pal) {
    const wall = labWall(pal), glass = labGlass(pal), Lc = K.lights(pal);
    const AX = 8.1, AW = 2.1, AH = 40, BX = 11.6, BW = 1.5, BH = 32, Y = 1.3, D2 = 4.2, Z = 3, YE = Y + D2;
    const o = base(2, [8.1, 1.3, 5.0, 4.3, 70], A.bbox(7.5, 0.7, 6.2, 5.5, 118, 10), A.bbox(8.1, 1.3, 5.0, 4.3, 108, 8));
    const L = K.rig(o), dk = { af: [], as: [], bf: [], bs: [] };
    o.glow = [{ p: P(10.9, 3.6, 52), r: 52, c: pal.acc, a: 0.28 }];
    o.entry = P(10.9, YE + 0.5);
    const patA = K.pattern(pal, 41, 0.3, 0.45), patB = K.pattern(pal, 47, 0.3, 0.3);
    const wingA = (cc, W, Hh, lit, front) => {
      if (front) {
        K.curtain(cc, W, Hh, { cols: 3, rows: 4, ix: 3, b: 3, t: 8, glass, k: 1, on: patA, seed: 41, band: 0.2, out: dk.af }, lit);
        if (!lit) { cc.fillStyle = 'rgba(236,246,255,.6)'; for (let i = 0; i <= 3; i++) cc.fillRect(3 + (i * (W - 6)) / 3 - 1.6, 0, 3.2, Hh); cc.fillStyle = 'rgba(255,255,255,.3)'; cc.fillRect(0, 0, W, 2); }
        cc.fillStyle = U.rgba(pal.acc, lit ? 0.95 : 0.45); cc.fillRect(0, 0, W, 1.4);
      } else {
        skin(cc, W, Hh, lit, 25);
        K.punched(cc, W, Hh, { cols: 6, rows: 3, mx: 8, b: 5, t: 6, pw: 0.7, ph: 0.62, glass, on: K.pattern(pal, 43, 0.3, 0.4), seed: 43, out: dk.as }, lit);
      }
    };
    const wingB = (cc, W, Hh, lit, front) => {
      skin(cc, W, Hh, lit, front ? 19 : 25);
      K.punched(cc, W, Hh, { cols: front ? 4 : 6, rows: 2, mx: 8, b: 6, t: 7, pw: 0.7, ph: 0.6, glass, on: front ? patB : K.pattern(pal, 49, 0.3, 0.3), seed: front ? 47 : 49, mull: true, out: front ? dk.bf : dk.bs }, lit);
      cc.fillStyle = U.rgba(pal.acc, lit ? 0.95 : 0.4); cc.fillRect(front ? W - 1.6 : 0, 0, 1.6, Hh);
    };
    o.draw = (c) => {
      L.begin(); for (const k in dk) dk[k].length = 0;
      K.shadow(c, 7.4, 0.7, 5.8, 5.2, 0.5, 0.5);
      K.slab(c, 7.9, 1.1, 5.4, 4.7, Z, pal.concrete, { accent: pal.acc });
      // the courtyard: a light ring round the dome
      const cp = P(10.9, 4.95, Z); ell(c, cp[0], cp[1], 38, 19); c.fillStyle = 'rgba(255,255,255,.07)'; c.fill(); c.strokeStyle = U.rgba(pal.acc, 0.6); c.lineWidth = 1.3; c.stroke();
      // wing A, the research tower
      const a = K.bx(c, AX, Y, AW, D2, AH, Z, wall);
      L.sheet(c, a.L, (cc, W, Hh, lit) => wingA(cc, W, Hh, lit, true));
      L.sheet(c, a.R, (cc, W, Hh, lit) => wingA(cc, W, Hh, lit, false));
      K.twinkle(L, a.L, dk.af, Lc.ice, 3, 2); K.twinkle(L, a.R, dk.as, Lc.ice, 2, 3);
      { const sz = K.size(a.L), sx = sz[0] * 0.5 - 22; K.cutRect(L, a.L, sx, 1.4, 44, 6.4); L.sign(c, a.L, (cc, W, Hh, lit) => K.plate(cc, sx, 1.4, 44, 6.4, 'LUMORA LABS', pal.acc, lit, { size: 3.9, sp: 0.6 })); }
      K.roof(c, AX, Y, AW, D2, Z + AH, pal.roof);
      edgeGlow(L, c, [P(AX, YE, Z + AH), P(AX + AW, YE, Z + AH), P(AX + AW, Y, Z + AH)], pal.acc, 1.4);
      // the covered bridge between the wings sits behind wing B's edge, so it is drawn first; a pillar holds it up
      K.bx(c, 10.8, 1.85, 0.22, 0.22, 19, Z, pal.metal);
      const br = K.bx(c, 10.2, 1.6, 1.4, 0.9, 10, 22, wall);
      L.sheet(c, br.L, (cc, W, Hh, lit) => {
        const x = 2.5, y = 2.2, w = W - 5, h = Hh - 5;
        if (lit) { const g = cc.createLinearGradient(0, y, 0, y + h); g.addColorStop(0, 'rgba(214,250,255,.98)'); g.addColorStop(1, 'rgba(96,204,240,.72)'); cc.fillStyle = g; cc.fillRect(x, y, w, h); return; }
        cc.fillStyle = 'rgba(6,10,24,.92)'; cc.fillRect(x - 1, y - 1, w + 2, h + 2);
        const g = cc.createLinearGradient(0, y, 0, y + h); g.addColorStop(0, glass[0]); g.addColorStop(1, glass[1]); cc.fillStyle = g; cc.fillRect(x, y, w, h);
        cc.fillStyle = 'rgba(255,255,255,.22)'; for (let i = 1; i < 4; i++) cc.fillRect(x + (i * w) / 4 - 0.5, y, 1, h);
        cc.fillStyle = U.rgba(pal.acc, 0.55); cc.fillRect(0, Hh - 1.4, W, 1.4);
      });
      K.roof(c, 10.2, 1.6, 1.4, 0.9, 32, pal.roof);
      L.part({ t: 'flow', pts: [P(10.2, 2.5, 28), P(11.6, 2.5, 28)], n: 3, spd: 0.7, col: '#ffffff', size: 1.3 });
      // wing B, the labs
      const bb = K.bx(c, BX, Y, BW, D2, BH, Z, wall);
      L.sheet(c, bb.L, (cc, W, Hh, lit) => wingB(cc, W, Hh, lit, true));
      L.sheet(c, bb.R, (cc, W, Hh, lit) => wingB(cc, W, Hh, lit, false));
      K.twinkle(L, bb.L, dk.bf, Lc.warm, 3, 4); K.twinkle(L, bb.R, dk.bs, Lc.warm, 3, 5);
      K.roof(c, BX, Y, BW, D2, Z + BH, pal.roof);
      edgeGlow(L, c, [P(BX, YE, Z + BH), P(BX + BW, YE, Z + BH), P(BX + BW, Y, Z + BH)], pal.acc, 1.4);
      // roof gear: a radar tower on A, solar panels and a stack on B
      const rp = P(9.2, 2.2, Z + AH), rt = P(9.2, 2.2, Z + AH + 16);
      line(c, [rp, rt], '#aab9d8', 1.8); L.part({ t: 'radar', p: [rt[0], rt[1] - 1], r: 9, col: pal.acc });
      K.hvac(c, L, pal, 8.5, 3.9, Z + AH, 0.9, 0.7, 5);
      const st = P(12.55, 1.85, Z + BH); A.cyl(c, 12.55, 1.85, 0.2, 11, Z + BH, pal.metal);
      L.part({ t: 'steam', p: [st[0], st[1] - 12], n: 3, rise: 28, size: 4, a: 0.38 });
      K.antenna(c, L, 12.8, 3.1, Z + BH, 16, '#ff4d5e');
      K.solar(c, 11.75, 3.75, Z + BH, 1.2, 1.45, 2);
      // the yard
      K.lamp(c, L, 7.95, 5.55, 17, pal.lamp, Z); K.lamp(c, L, 13.1, 5.55, 17, pal.lamp, Z);
      // the holo-dome stands at the mouth of the courtyard, in front of both wings
      K.glassDome(c, 10.9, 4.95, Z, 0.55, 40, '#9be7ff');
      L.part({ t: 'holo', p: P(10.9, 4.95, Z + 21), r: 11, col: '#bff7ff' });
      L.part({ t: 'orbit', p: P(10.9, 4.95, Z + 21), rx: 18, ry: 6, rot: -0.5, n: 3, spd: 1.4, col: '#ffffff', size: 1.3, glow: 6 });
      K.planter(c, 8.5, 5.6, 1.2, 0.26, '#58c092', Z, '#3b4a6e'); K.planter(c, 11.9, 5.6, 1.0, 0.26, '#58c092', Z, '#3b4a6e');
      L.part({ t: 'lamp', p: P(10.9, YE + 0.2, 14), r: 36, col: '#bff3ff', a: 0.4 });
    };
    return A.slide(o, A.PLAN.lab.dx, 0);
  }

  /* ---------- tier 3: the Quantum Research Institute ---------- */
  function lab3(pal) {
    const CX = 10.6, CY = 3.5, Lc = K.lights(pal), glass = [K.hexMix(pal.glassHex, '#9fe6ff', 0.55), K.hex(pal.glassHex, 0.4)];
    const o = base(3, [8.0, 1.2, 5.2, 4.6, 100], A.bbox(7.6, 0.8, 6.0, 5.4, 150, 14), A.bbox(8.0, 1.2, 5.2, 4.6, 148, 10));
    const L = K.rig(o), dark = [], dark2 = [];
    const TX = 9.95, TY = 2.85, TS = 1.3, TH = 86, ZT = 6;
    o.glow = [{ p: P(CX, CY, 70), r: 70, c: pal.acc, a: 0.3 }, { p: P(CX, CY, 120), r: 34, c: '#bff7ff', a: 0.25 }];
    o.ring = { c: P(CX, CY, 72), rx: 50, ry: 19 };
    o.orb = { p: P(CX, CY, 116), r: 14 };
    o.entry = P(CX, 6.2);
    const pat = K.pattern(pal, 61, 0.34, 0.55), pat2 = K.pattern(pal, 67, 0.4, 0.55);
    const shaft = (cc, W, Hh, lit, front) => {
      K.curtain(cc, W, Hh, { cols: 3, rows: 8, ix: 2, b: 2, t: 4, glass, k: front ? 1 : 0.75, on: front ? pat : pat2, seed: front ? 61 : 67, band: 0.22, out: front ? dark : dark2 }, lit);
      cc.fillStyle = U.rgba(pal.acc, lit ? 0.95 : 0.4); cc.fillRect(front ? W - 1.6 : 0, 0, 1.6, Hh);
      for (const j of [2, 5]) { const y = Hh - 2 - (j * (Hh - 6)) / 8; cc.fillStyle = U.rgba(pal.acc, lit ? 0.9 : 0.3); cc.fillRect(2, y - 0.8, W - 4, 1.6); }
    };
    // the four cryostats: pale tanks that stand on the ring
    const tanks = [[9.19, 2.09, 38], [12.01, 2.09, 30], [9.19, 4.91, 22], [12.01, 4.91, 22]];
    o.draw = (c) => {
      L.begin(); dark.length = 0; dark2.length = 0;
      const p0 = P(CX, CY, 0), rx = 2.55 * 45.25, ry = 2.55 * 22.6;
      // the ground: a slab with a glowing track set into it
      ell(c, p0[0], p0[1] + 7, rx + 4, ry + 2.4); c.fillStyle = 'rgba(2,6,18,.45)'; c.fill();
      ell(c, p0[0], p0[1] + 6, rx, ry); c.fillStyle = '#0c1430'; c.fill();
      ell(c, p0[0], p0[1], rx, ry); c.fillStyle = '#27375f'; c.fill();
      c.strokeStyle = 'rgba(255,255,255,.14)'; c.lineWidth = 1; c.stroke();
      ell(c, p0[0], p0[1], rx * 0.84, ry * 0.84); c.fillStyle = '#1a2748'; c.fill();
      for (const [k, w] of [[0.62, 7], [0.62, 3]]) { ell(c, p0[0], p0[1], rx * k, ry * k); c.strokeStyle = w > 5 ? 'rgba(4,8,22,.85)' : U.rgba(pal.acc, 0.85); c.lineWidth = w; c.stroke(); }
      ell(c, p0[0], p0[1], rx * 0.62, ry * 0.62); c.strokeStyle = 'rgba(255,255,255,.35)'; c.lineWidth = 0.8; c.stroke();
      L.part({ t: 'orbit', p: [p0[0], p0[1]], rx: rx * 0.62, ry: ry * 0.62, n: 3, spd: 1.7, col: '#e8fdff', size: 2.1, glow: 11 });
      L.part({ t: 'orbit', p: [p0[0], p0[1]], rx: rx * 0.62, ry: ry * 0.62, n: 2, spd: -1.15, ph: 0.8, col: pal.acc, size: 2, glow: 10 });
      // back cryostats first
      tanks.forEach(([tx, ty, th], i) => {
        if (i > 1) return;
        K.tank(c, tx, ty, 0, 0.42, th, '#c3d6f7');
        const tp = P(tx, ty, th);
        L.part({ t: 'steam', p: [tp[0], tp[1] - 3], n: 3, rise: 20, size: 4, a: 0.34, col: 'rgba(210,235,255,1)' });
        L.part({ t: 'arc', a: [tp[0], tp[1] - 2], b: P(CX, CY, TH - 6 + ZT), rate: 0.2, jit: 7, col: '#cfeaff', ph: 0.2 + i * 0.3 });
      });
      // the tower
      const tb = K.bx(c, TX, TY, TS, TS, TH, ZT, pal.glass);
      K.bx(c, TX - 0.12, TY - 0.12, TS + 0.24, TS + 0.24, ZT, 0, pal.concrete);
      L.sheet(c, tb.L, (cc, W, Hh, lit) => shaft(cc, W, Hh, lit, true));
      L.sheet(c, tb.R, (cc, W, Hh, lit) => shaft(cc, W, Hh, lit, false));
      K.twinkle(L, tb.L, dark, Lc.ice, 3, 5); K.twinkle(L, tb.R, dark2, Lc.ice, 3, 6);
      K.roof(c, TX, TY, TS, TS, ZT + TH, pal.roof, { m: 0.08 });
      edgeGlow(L, c, [P(TX, TY + TS, ZT + TH), P(TX + TS, TY + TS, ZT + TH), P(TX + TS, TY, ZT + TH)], '#bff7ff', 1.5);
      // front cryostats
      tanks.forEach(([tx, ty, th], i) => {
        if (i < 2) return;
        K.tank(c, tx, ty, 0, 0.4, th, '#c3d6f7');
        const tp = P(tx, ty, th);
        L.part({ t: 'steam', p: [tp[0], tp[1] - 3], n: 3, rise: 18, size: 3.6, a: 0.32, col: 'rgba(210,235,255,1)' });
        L.part({ t: 'arc', a: [tp[0], tp[1] - 2], b: P(CX, CY, ZT + TH - 20), rate: 0.18, jit: 7, col: '#cfeaff', ph: 0.5 + i * 0.25 });
      });
      // the core above the roof: an atom of three orbits
      const cp = P(CX, CY, 116);
      L.part({ t: 'orbit', p: cp, rx: 30, ry: 10, rot: 0, n: 1, spd: 2.0, col: '#ffffff', size: 1.9, glow: 8, line: 0.28 });
      L.part({ t: 'orbit', p: cp, rx: 30, ry: 10, rot: 1.05, n: 1, spd: -1.7, ph: 2, col: pal.acc, size: 1.9, glow: 8, line: 0.28 });
      L.part({ t: 'orbit', p: cp, rx: 30, ry: 10, rot: -1.05, n: 1, spd: 1.5, ph: 4, col: '#bff7ff', size: 1.9, glow: 8, line: 0.28 });
      L.part({ t: 'blink', p: P(CX - 0.5, CY - 0.5, ZT + TH + 1), col: '#ff4d5e', per: 1.5, r: 2, glow: 12 });
      // lamps round the slab
      for (const [px, py] of [[8.1, 5.6], [13.0, 5.6]]) K.lamp(c, L, px, py, 17, pal.lamp, 0);
      L.part({ t: 'lamp', p: P(CX, 5.9, 10), r: 40, col: '#bff3ff', a: 0.4 });
    };
    return A.slide(o, A.PLAN.lab.dx, 0);
  }

  const TIERS = { 1: lab1, 2: lab2, 3: lab3 };
  A.lab = function (tier, pal) { return TIERS[tier](pal); };
})();
