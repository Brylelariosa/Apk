/* AI Empire Tycoon - isometric art. Everything is drawn procedurally (no image files). */
(function () {
  'use strict';
  const G = window.G, U = G.U, D = G.D;
  const A = (G.art = {});
  const HW = 32, HH = 16;
  const P = (x, y, z) => [(x - y) * HW, (x + y) * HH - (z || 0)];
  A.P = P; A.HW = HW; A.HH = HH;
  A.res = 1.5;

  /* ---------- colours ---------- */
  const triCache = {};
  function tri(hex, k) {
    k = k || 1;
    const key = hex + k;
    if (triCache[key]) return triCache[key];
    return (triCache[key] = { t: U.shade(hex, 1.22 * k), l: U.shade(hex, 0.96 * k), r: U.shade(hex, 0.7 * k), e: 'rgba(255,255,255,.18)', hex });
  }
  A.tri = tri;
  A.palette = function (skin) {
    const k = D.skins[skin] || D.skins.midnight;
    return {
      acc: k.accent, lamp: k.lamp, glassHex: k.glass,
      wall: tri(k.wall), roof: tri(k.roof), glass: tri(k.glass),
      concrete: tri('#51608a'), dark: tri('#1a2238'), metal: tri('#5f6f92'), rack: tri('#2a3350'),
      floor: tri('#33436a'), hall: tri('#182240'), white: tri('#cfd9ee'), cyan: tri('#2d9fc2'), wood: tri('#8b6a4a')
    };
  };

  /* ---------- primitives ---------- */
  function poly(c, pts, fill, stroke) {
    c.beginPath();
    c.moveTo(pts[0][0], pts[0][1]);
    for (let i = 1; i < pts.length; i++) c.lineTo(pts[i][0], pts[i][1]);
    c.closePath();
    if (fill) { c.fillStyle = fill; c.fill(); }
    if (stroke) { c.strokeStyle = stroke; c.lineWidth = 1; c.stroke(); }
  }
  A.poly = poly;
  function box(c, x, y, w, d, h, z0, col, noEdge) {
    z0 = z0 || 0;
    const nT = P(x, y, z0 + h), eT = P(x + w, y, z0 + h), sT = P(x + w, y + d, z0 + h), wT = P(x, y + d, z0 + h);
    const sB = P(x + w, y + d, z0), wB = P(x, y + d, z0), eB = P(x + w, y, z0);
    poly(c, [wT, sT, sB, wB], col.l);
    poly(c, [sT, eT, eB, sB], col.r);
    poly(c, [nT, eT, sT, wT], col.t);
    if (!noEdge) {
      c.strokeStyle = col.e; c.lineWidth = 1; c.beginPath();
      c.moveTo(wT[0], wT[1]); c.lineTo(sT[0], sT[1]); c.lineTo(eT[0], eT[1]); c.stroke();
    }
  }
  A.box = box;
  const fL = (x, y, w, d, h, z0) => (u, v) => P(x + u * w, y + d, (z0 || 0) + v * h);
  const fR = (x, y, w, d, h, z0) => (u, v) => P(x + w, y + d - u * d, (z0 || 0) + v * h);
  function quad(c, f, u0, u1, v0, v1, fill) { poly(c, [f(u0, v0), f(u1, v0), f(u1, v1), f(u0, v1)], fill); }
  function wins(c, f, cols, rows, mx, my, fillFn) {
    for (let i = 0; i < cols; i++) for (let j = 0; j < rows; j++) {
      const fl = fillFn(i, j);
      if (fl) quad(c, f, (i + mx) / cols, (i + 1 - mx) / cols, (j + my) / rows, (j + 1 - my) / rows, fl);
    }
  }
  A.fL = fL; A.fR = fR; A.quad = quad; A.wins = wins;
  const hash = (a, b, s) => {
    let h = (Math.imul(a + 7, 374761393) + Math.imul(b + 13, 668265263) + Math.imul((s || 0) + 3, 1274126177)) >>> 0;
    h = Math.imul(h ^ (h >>> 13), 1274126177) >>> 0;
    return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
  };
  A.hash = hash;
  function ell(c, cx, cy, rx, ry) { c.beginPath(); c.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2); }
  A.ell = ell;
  function cyl(c, x, y, r, h, z0, col) {
    const p = P(x, y, z0 || 0), cx = p[0], cy = p[1], rx = r * HW * 1.414, ry = r * HH * 1.414;
    const g = c.createLinearGradient(cx - rx, 0, cx + rx, 0);
    g.addColorStop(0, col.l); g.addColorStop(0.45, col.t); g.addColorStop(1, col.r);
    c.fillStyle = g; c.beginPath();
    c.moveTo(cx - rx, cy - h); c.lineTo(cx - rx, cy); c.ellipse(cx, cy, rx, ry, 0, Math.PI, 0, true);
    c.lineTo(cx + rx, cy - h); c.ellipse(cx, cy - h, rx, ry, 0, 0, Math.PI, true); c.closePath(); c.fill();
    ell(c, cx, cy - h, rx, ry); c.fillStyle = col.t; c.fill();
    c.strokeStyle = col.e; c.lineWidth = 1; c.stroke();
    return [cx, cy - h, rx, ry];
  }
  A.cyl = cyl;
  function dome(c, x, y, r, h, z0, hex, a) {
    const p = P(x, y, z0 || 0), cx = p[0], cy = p[1], rx = r * HW * 1.414, ry = r * HH * 1.414;
    const g = c.createRadialGradient(cx - rx * 0.35, cy - h * 0.7, 2, cx, cy - h * 0.3, Math.max(rx, h) * 1.05);
    g.addColorStop(0, U.rgba(hex, 0.95 * a)); g.addColorStop(0.55, U.rgba(hex, 0.5 * a)); g.addColorStop(1, U.rgba(hex, 0.2 * a));
    c.fillStyle = g; c.beginPath();
    c.moveTo(cx - rx, cy); c.ellipse(cx, cy, rx, h, 0, Math.PI, Math.PI * 2, false);
    c.ellipse(cx, cy, rx, ry, 0, 0, Math.PI, false); c.closePath(); c.fill();
    c.strokeStyle = 'rgba(255,255,255,.28)'; c.lineWidth = 1; c.stroke();
    return [cx, cy - h * 0.55];
  }
  A.dome = dome;
  const glowC = {};
  A.glow = function (hex) {
    if (glowC[hex]) return glowC[hex];
    const s = document.createElement('canvas'); s.width = s.height = 64;
    const g = s.getContext('2d'), gr = g.createRadialGradient(32, 32, 0, 32, 32, 32);
    gr.addColorStop(0, U.rgba(hex, 1)); gr.addColorStop(0.28, U.rgba(hex, 0.42)); gr.addColorStop(1, U.rgba(hex, 0));
    g.fillStyle = gr; g.fillRect(0, 0, 64, 64);
    return (glowC[hex] = s);
  };
  A.sprite = function (b, fn, res) {
    const sc = res || A.res, w = Math.ceil((b[2] - b[0]) * sc), h = Math.ceil((b[3] - b[1]) * sc);
    const cv = document.createElement('canvas');
    cv.width = Math.max(1, w); cv.height = Math.max(1, h);
    const c = cv.getContext('2d');
    c.scale(sc, sc); c.translate(-b[0], -b[1]); c.lineJoin = 'round'; c.lineCap = 'round';
    fn(c);
    return { cv, x: b[0], y: b[1], w: b[2] - b[0], h: b[3] - b[1] };
  };
  A.bbox = (x, y, w, d, h, pad) => {
    pad = pad === undefined ? 8 : pad;
    return [P(x, y + d)[0] - pad, P(x, y, h)[1] - pad - 6, P(x + w, y)[0] + pad, P(x + w, y + d)[1] + pad];
  };

  /* ---------- plan of the campus ---------- */
  // The north row, left to right: the office (plots 1..6), a gap that holds the closet (A.HALLS[0]) and the network tower, and the lab.
  // The gap must fit a building with open ground on both sides, so the lab sits `lab.dx` further east than its drawing says.
  // Everything else keeps the coordinates written in its own drawing code.
  A.PLAN = { lab: { dx: 0.5 }, net: { x: 6.85, y: 5.2, s: 0.8 } };
  // Slide a finished building along the ground: its picture, hit area, lights and glow all move with it, so a plot can change
  // without editing the drawing code. Only for buildings that set their lights and glow up front (the lab does), not ones that
  // fill them in while they are drawn.
  A.slide = function (o, dx, dy) {
    if (!dx && !dy) return o;
    const s = P(dx, dy), draw = o.draw, lit = o.lit;
    o.draw = (c) => { c.save(); c.translate(s[0], s[1]); draw(c); c.restore(); };
    if (lit) o.lit = (c) => { c.save(); c.translate(s[0], s[1]); lit(c); c.restore(); };
    o.shift = [(o.shift ? o.shift[0] : 0) + s[0], (o.shift ? o.shift[1] : 0) + s[1]];   // the animated parts (art-live.js) are drawn moved by this
    o.fp = [o.fp[0] + dx, o.fp[1] + dy, o.fp[2], o.fp[3], o.fp[4]];
    o.b = [o.b[0] + s[0], o.b[1] + s[1], o.b[2] + s[0], o.b[3] + s[1]];
    if (o.tb) o.tb = [o.tb[0] + s[0], o.tb[1] + s[1], o.tb[2] + s[0], o.tb[3] + s[1]];
    if (o.glow) o.glow.forEach((q) => { q.p = [q.p[0] + s[0], q.p[1] + s[1]]; });   // the glows are drawn by the scene, so they move here
    return o;
  };
  // A.person (everyone on the island) is in art-people.js.
  A.tree = function (c, px, py, s, hexA) {
    s = s || 1;
    c.fillStyle = 'rgba(0,0,0,.25)'; ell(c, px, py, 9 * s, 4 * s); c.fill();
    c.fillStyle = '#4a3a2c'; c.fillRect(px - 1.4 * s, py - 9 * s, 2.8 * s, 9 * s);
    const g = c.createRadialGradient(px - 3 * s, py - 20 * s, 1, px, py - 17 * s, 13 * s);
    g.addColorStop(0, U.shade(hexA || '#3fa37a', 1.25)); g.addColorStop(1, U.shade(hexA || '#3fa37a', 0.62));
    c.fillStyle = g; ell(c, px, py - 17 * s, 9 * s, 10.5 * s); c.fill();
  };

  /* ---------- land and roads ---------- */
  // The campus is a floating island: a lawn slab on top of a tapering rock with glowing crystal veins underneath.
  A.landDepth = (Lx, Ly) => Math.round(34 + (Lx + Ly) * 5);
  A.land = function (Lx, Ly, pal, roads) {
    const T = 16, DEPTH = A.landDepth(Lx, Ly);
    const b = [P(0, Ly)[0] - 10, P(0, 0)[1] - 10, P(Lx, 0)[0] + 10, P(Lx, Ly)[1] + T + DEPTH + 14];
    const spr = A.sprite(b, (c) => {
      const n = P(0, 0), e = P(Lx, 0), s = P(Lx, Ly), w = P(0, Ly);
      // ---- rock underside: two faces that meet at a point below the middle of the island ----
      const wl = [w[0], w[1] + T], sl = [s[0], s[1] + T], el = [e[0], e[1] + T];
      const apex = [(w[0] + e[0]) / 2 + 4, s[1] + T + DEPTH];
      const face = (p0, p1, light, dark) => {
        const g = c.createLinearGradient(0, p0[1], 0, apex[1]);
        g.addColorStop(0, light); g.addColorStop(1, dark);
        c.fillStyle = g; c.beginPath(); c.moveTo(p0[0], p0[1]); c.lineTo(p1[0], p1[1]); c.lineTo(apex[0], apex[1]); c.closePath(); c.fill();
      };
      face(wl, sl, '#22345a', '#0c1630');
      face(sl, el, '#142140', '#070d1f');
      // facets: shards running from the rim down to the point
      const rnd = U.rng(Math.round(Lx * 31 + Ly * 17));
      for (let side = 0; side < 2; side++) {
        const p0 = side ? sl : wl, p1 = side ? el : sl;
        for (let i = 1; i < 7; i++) {
          const t = i / 7 + (rnd() - 0.5) * 0.06, px = U.lerp(p0[0], p1[0], t), py = U.lerp(p0[1], p1[1], t);
          const k = 0.45 + rnd() * 0.4, mx = U.lerp(px, apex[0], k), my = U.lerp(py, apex[1], k) + (rnd() - 0.5) * 6;
          c.fillStyle = side ? 'rgba(2,6,16,' + (0.16 + rnd() * 0.2) + ')' : 'rgba(150,185,255,' + (0.05 + rnd() * 0.07) + ')';
          c.beginPath(); c.moveTo(px - 5, py); c.lineTo(px + 5, py); c.lineTo(mx, my); c.closePath(); c.fill();
        }
      }
      // glowing veins
      c.lineWidth = 1.1; c.lineCap = 'round';
      for (let i = 0; i < 6; i++) {
        const t = 0.12 + rnd() * 0.76, side = i % 2, p0 = side ? sl : wl, p1 = side ? el : sl;
        const px = U.lerp(p0[0], p1[0], t), py = U.lerp(p0[1], p1[1], t) + 2, k = 0.3 + rnd() * 0.4;
        const g = c.createLinearGradient(px, py, U.lerp(px, apex[0], k), U.lerp(py, apex[1], k));
        g.addColorStop(0, U.rgba(pal.acc, 0.5)); g.addColorStop(1, U.rgba(pal.acc, 0));
        c.strokeStyle = g; c.beginPath(); c.moveTo(px, py); c.lineTo(U.lerp(px, apex[0], k), U.lerp(py, apex[1], k) + (rnd() - 0.5) * 8); c.stroke();
      }
      // crystal cluster at the tip
      const crystal = (x, y, h, wd, a) => { c.fillStyle = U.rgba(pal.acc, a); c.beginPath(); c.moveTo(x - wd, y); c.lineTo(x, y - h); c.lineTo(x + wd, y); c.lineTo(x + wd * 0.4, y + h * 0.28); c.lineTo(x - wd * 0.4, y + h * 0.28); c.closePath(); c.fill(); c.strokeStyle = 'rgba(255,255,255,.45)'; c.lineWidth = 0.8; c.stroke(); };
      crystal(apex[0] - 8, apex[1] - 4, 18, 4.5, 0.55); crystal(apex[0] + 6, apex[1] - 2, 24, 5.5, 0.75); crystal(apex[0] - 1, apex[1] + 2, 15, 4, 0.9);
      // ---- lawn slab ----
      poly(c, [w, s, [s[0], s[1] + T], [w[0], w[1] + T]], '#0e1a33');
      poly(c, [s, e, [e[0], e[1] + T], [s[0], s[1] + T]], '#080f21');
      c.strokeStyle = 'rgba(255,255,255,.06)'; c.lineWidth = 1; c.beginPath(); c.moveTo(w[0], w[1] + T); c.lineTo(s[0], s[1] + T); c.lineTo(e[0], e[1] + T); c.stroke();
      const g = c.createLinearGradient(0, n[1], 0, s[1]);
      g.addColorStop(0, '#16494a'); g.addColorStop(0.55, '#10393c'); g.addColorStop(1, '#0d2e35');
      poly(c, [n, e, s, w], g);
      // paver grid
      c.strokeStyle = 'rgba(160,230,220,.06)'; c.lineWidth = 1; c.beginPath();
      for (let i = 1; i < Lx; i++) { const a = P(i, 0), z = P(i, Ly); c.moveTo(a[0], a[1]); c.lineTo(z[0], z[1]); }
      for (let j = 1; j < Ly; j++) { const a = P(0, j), z = P(Lx, j); c.moveTo(a[0], a[1]); c.lineTo(z[0], z[1]); }
      c.stroke();
      // lighter lawn patches
      for (let i = 0; i < Lx; i++) for (let j = 0; j < Ly; j++) {
        if (hash(i, j, 5) > 0.8) poly(c, [P(i, j), P(i + 1, j), P(i + 1, j + 1), P(i, j + 1)], 'rgba(80,190,150,.08)');
        else if (hash(i, j, 9) > 0.9) poly(c, [P(i, j), P(i + 1, j), P(i + 1, j + 1), P(i, j + 1)], 'rgba(0,0,0,.1)');
      }
      // roads
      for (const r of roads || []) {
        const x0 = r[0], y0 = r[1], x1 = r[2], y1 = r[3], hw = 0.42;
        const horiz = Math.abs(x1 - x0) >= Math.abs(y1 - y0);
        const pts = horiz ? [P(x0, y0 - hw), P(x1, y0 - hw), P(x1, y0 + hw), P(x0, y0 + hw)] : [P(x0 - hw, y0), P(x0 + hw, y0), P(x0 + hw, y1), P(x0 - hw, y1)];
        poly(c, pts, '#1d2845');
        c.strokeStyle = U.rgba(pal.acc, 0.35); c.lineWidth = 1; c.setLineDash([5, 6]); c.beginPath();
        const a = P(x0, y0), z = P(x1, y1); c.moveTo(a[0], a[1]); c.lineTo(z[0], z[1]); c.stroke(); c.setLineDash([]);
      }
      // glowing rim
      c.strokeStyle = U.rgba(pal.acc, 0.5); c.lineWidth = 1.8; c.beginPath();
      c.moveTo(w[0], w[1]); c.lineTo(s[0], s[1]); c.lineTo(e[0], e[1]); c.stroke();
      c.strokeStyle = U.rgba(pal.acc, 0.16); c.lineWidth = 1; c.beginPath();
      c.moveTo(w[0], w[1]); c.lineTo(n[0], n[1]); c.lineTo(e[0], e[1]); c.stroke();
    });
    spr.depth = DEPTH; spr.tip = P(Lx, Ly)[1] + T;
    return spr;
  };

  /* The headquarters are in art-hq.js and the research lab in art-lab.js (both built with the kit in art-kit.js). */

  /* The server closet and the data halls are in art-dc.js. */

  /* The cooling yard, the power plants and the network tower are in art-infra.js. */

  /* ================= CONSTRUCTION SITE ================= */
  A.site = function (fp, name) {
    const x = fp[0], y = fp[1], w = fp[2], d = fp[3];
    const o = { id: 'site', kind: 'site', name: 'Under construction', fp: [x, y, w, d, 40] };
    o.b = A.bbox(x, y, w, d, 96, 14);
    o.draw = (c) => {
      box(c, x, y, w, d, 2, 0, tri('#3a3f52'));
      c.strokeStyle = 'rgba(255,190,70,.8)'; c.lineWidth = 2; c.setLineDash([6, 5]);
      const a = P(x, y + d, 3), z = P(x + w, y + d, 3), e = P(x + w, y, 3); c.beginPath(); c.moveTo(a[0], a[1]); c.lineTo(z[0], z[1]); c.lineTo(e[0], e[1]); c.stroke(); c.setLineDash([]);
      const cx = x + w - 0.5, cy = y + d - 0.5, base = P(cx, cy, 2), top = P(cx, cy, 90);
      c.strokeStyle = '#e8b030'; c.lineWidth = 2.2; c.beginPath(); c.moveTo(base[0], base[1]); c.lineTo(top[0], top[1]); c.stroke();
      c.lineWidth = 1; for (let i = 1; i < 9; i++) { const p = P(cx, cy, 2 + i * 10); c.beginPath(); c.moveTo(p[0] - 3, p[1]); c.lineTo(p[0] + 3, p[1] - 5); c.stroke(); }
      o.crane = top;
      box(c, x + 0.3, y + 0.3, 0.8, 0.8, 8, 2, tri('#e8b030')); box(c, x + 1.3, y + 0.4, 0.6, 0.6, 5, 2, tri('#4b5ca0'));
    };
    return o;
  };
})();
