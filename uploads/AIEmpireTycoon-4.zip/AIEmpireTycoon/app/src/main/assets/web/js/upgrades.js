/* AI Empire Tycoon - Upgrades screen.
   One list for each kind of upgrade (servers, racks, data center, cooling, power, network, office, labs).
   The list starts on the first screen: a short status line, at most one banner and then the rows. Every row has a picture,
   a one-line verdict (what it does to income and costs) and its button; tapping a row opens the details. The numbers come
   from the economy advisor (it runs the real economy on a copy of your company), so they match what the game really does. */
(function () {
  'use strict';
  const G = window.G, D = G.D, U = G.U, S = G.scene, UI = G.ui, ADV = G.adv, h = U.h, W = UI.w, PT = ADV.patch;
  const I = UI.I, T = UI.T, CL = UI.CL, DIS = UI.DIS, bind = UI.bind, btn = UI.btn, bar = UI.bar, setBar = UI.setBar;
  const col = (style) => ({ display: 'flex', flexDirection: 'column', flex: 1, minHeight: 0, ...(style || {}) });
  const merge = (st, patch) => Object.assign({}, st, patch);

  /* ---------- the categories ---------- */
  // kind = picture set in art-hw.js, lad = building ladder in data.js, view = what the campus camera frames
  const CATS = [
    { id: 'servers', name: 'Servers', icon: 'cpu', kind: 'hw', view: 'dc',
      what: 'Servers are the computers that answer your users. More computing power means more users served, and more users served means more income.',
      cost: 'Every server also adds to your electricity and maintenance costs.' },
    { id: 'racks', name: 'Racks', icon: 'infra', kind: 'rack', view: 'dc',
      what: 'A rack is the metal shelf that servers sit in. Each rack holds four servers.',
      cost: 'Racks earn nothing by themselves. They only make room for servers.' },
    { id: 'dc', name: 'Data center', icon: 'infra', kind: 'dc', lad: 'dc', view: 'dc',
      what: 'The building around your racks. A bigger building has floor space for many more racks, plus a small bonus to computing power.',
      cost: 'Bigger buildings raise your maintenance costs a little.' },
    { id: 'cool', name: 'Cooling', icon: 'snow', kind: 'cool', lad: 'cool', view: 'cool',
      what: 'Servers make heat. If cooling cannot remove it, servers slow down and customers get unhappy.',
      cost: 'Better cooling also wastes less electricity on cooling, so it lowers your power bill.' },
    { id: 'pwr', name: 'Power', icon: 'bolt', kind: 'pwr', lad: 'pwr', view: 'pwr',
      what: 'Servers need electricity. When the supply runs short they slow down and earn less.',
      cost: 'Better power sources also make every unit of electricity cheaper.' },
    { id: 'net', name: 'Network', icon: 'net', kind: 'net', lad: 'net', view: 'net',
      what: 'The links between your servers. A slow network wastes computing power; a fast one lets every server do its full share.',
      cost: 'It matters more the more servers you own.' },
    { id: 'hq', name: 'Office', icon: 'hq', kind: 'hq', lad: 'hq', view: 'hq',
      what: 'Your headquarters. A bigger office hires more people, speeds up research and helps the company grow.',
      cost: 'More staff means a bigger payroll every second.' },
    { id: 'lab', name: 'Labs', icon: 'research', kind: 'lab', lad: 'lab', view: 'lab',
      what: 'Where new technology is invented. Better labs finish research faster and can work on more projects at once.',
      cost: 'Labs do not change your income directly. They get you to better models sooner.' }
  ];
  const CMAP = {};
  CATS.forEach((c) => (CMAP[c.id] = c));
  UI.upgradeCats = CATS;
  UI.picks = UI.picks || {};

  /* ---------- plain-language texts per ladder ---------- */
  const EFF = { resSpeed: ['Research speed', 'p'], growth: ['User growth', 'p'], entSlots: ['Enterprise slots', 'n'], sat: ['Satisfaction', 'n'], appeal: ['User appeal', 'p'], resSlots: ['Extra research slots', 'n'], intel: ['Model intelligence', 'p'] };
  function effRows(a, b) {
    const ea = a.eff || {}, eb = b.eff || {};
    return Object.keys(Object.assign({}, ea, eb)).filter((k) => (ea[k] || 0) !== (eb[k] || 0)).map((k) => {
      const m = EFF[k] || [k, 'n'], f = (v) => (m[1] === 'p' ? '+' + Math.round(v * 100) + '%' : '+' + v);
      return [m[0], f(ea[k] || 0), f(eb[k] || 0)];
    });
  }
  const CMP = {
    dc: (a, b) => [['Rack spaces', a.racks, b.racks], ['Computing power bonus', '+' + W.pct(a.bonus), '+' + W.pct(b.bonus)]],
    cool: (a, b) => [['Heat it can remove', U.mw(a.cap), U.mw(b.cap)], ['Extra power spent on cooling', '+' + Math.round((a.pue - 1) * 100) + '%', '+' + Math.round((b.pue - 1) * 100) + '%']],
    pwr: (a, b) => [['Power supply', U.mw(a.cap), U.mw(b.cap)], ['Electricity price', W.pct(a.price), W.pct(b.price)]],
    net: (a, b) => [['Computing power you can use', W.pct(a.eff), W.pct(b.eff)]],
    hq: (a, b) => [['Staff', a.staff, b.staff]].concat(effRows(a, b)),
    lab: (a, b) => effRows(a, b)
  };
  const ZERO = {
    dc: 'Earns nothing by itself. It gives you room for more racks and servers.',
    cool: 'Your cooling already copes with the heat, so this does not change your income yet.',
    pwr: 'Your power supply already covers your servers, so this does not change your income yet.',
    net: 'Your network is already fast enough for your servers. It matters more as you add servers.',
    hq: 'An office does not earn money directly. It hires more people and speeds up research and growth.',
    lab: 'Labs do not change your income directly. They make research faster.'
  };
  const NOTE = { hq: 'A bigger team needs salaries, so your payroll goes up. Research and growth get faster.' };

  /* ---------- live status of each category (a colour, a sentence, a short label and a fill from 0 to 1; f = null when there is nothing to fill) ---------- */
  const pc = (v) => Math.round(Math.min(9.99, v) * 100) + '%';
  const STATUS = {
    servers() {
      const C = G.C;
      if (C.sr < 0.985 && C.demand > 0) return { tone: 'bad', f: Math.min(1.2, C.util), short: 'Overloaded', text: 'Overloaded: ' + Math.round((1 - C.sr) * 100) + '% of users get no service' };
      return { tone: C.util > 0.8 ? 'warn' : 'good', f: C.util, short: pc(C.util) + ' busy', text: pc(C.util) + ' of your computing power is in use' };
    },
    racks() {
      const C = G.C, f = C.slotsTotal ? C.slotsUsed / C.slotsTotal : 1;
      return { tone: f >= 1 ? 'warn' : 'good', f, short: C.slotsUsed + '/' + C.slotsTotal, text: C.slotsUsed + ' of ' + C.slotsTotal + ' server slots used' };
    },
    dc() {
      const C = G.C, n = G.state.inf.racks, f = C.rackCap ? n / C.rackCap : 1;
      return { tone: f >= 1 ? 'warn' : 'good', f, short: n + '/' + C.rackCap + ' racks', text: n + ' of ' + C.rackCap + ' rack spaces used' };
    },
    cool() {
      const C = G.C, f = C.coolCap ? C.heat / C.coolCap : 0;
      if (C.rel < 0.97) return { tone: 'bad', f, short: 'Overheating', text: 'Overheating: servers make ' + pc(f) + ' of the heat cooling can remove' };
      return { tone: f > 0.75 ? 'warn' : 'good', f, short: pc(f) + ' of limit', text: 'Heat ' + U.mw(C.heat) + ' of ' + U.mw(C.coolCap) + ' (' + pc(f) + ')' };
    },
    pwr() {
      const C = G.C, f = C.powerCap ? C.powerDraw / C.powerCap : 0;
      if (C.powerRatio < 0.97) return { tone: 'bad', f, short: 'Short on power', text: 'Short of power: servers want ' + U.mw(C.powerDraw) + ', supply is ' + U.mw(C.powerCap) };
      return { tone: f > 0.75 ? 'warn' : 'good', f, short: pc(f) + ' used', text: 'Using ' + U.mw(C.powerDraw) + ' of ' + U.mw(C.powerCap) + ' (' + pc(f) + ')' };
    },
    net() {
      const C = G.C;
      return { tone: C.netEff < 0.8 ? 'warn' : 'good', f: 1 - C.netEff, short: pc(C.netEff) + ' usable', text: pc(C.netEff) + ' of your computing power is usable' };
    },
    hq() { const st = D.ladders.hq[G.state.inf.hq].staff; return { tone: 'good', f: null, short: st + ' staff', text: st + ' staff · payroll ' + U.fine(G.C.exp.payroll) + '/s' }; },
    lab() { const C = G.C; return { tone: 'good', f: null, short: 'x' + C.M.resSpeed.toFixed(2) + ' speed', text: 'Research speed x' + C.M.resSpeed.toFixed(2) + ' · ' + C.resSlots + ' project' + (C.resSlots > 1 ? 's' : '') + ' at once' }; }
  };
  UI.upgradeStatus = (id) => STATUS[id]();

  /* ---------- building blocks ---------- */
  function buildWhy(next, cost) {
    const s = G.state;
    if (next.req && !s.res.done[next.req]) return { t: 'Research ' + D.rmap[next.req].name + ' first.', go: 'research', label: 'Open Research' };
    if (s.cash < cost) return { t: 'You need ' + U.money(cost - s.cash) + ' more cash.' };
    return null;
  }
  const stat = (icon, text) => h('span', { class: 'stch' }, I(icon, 12), text);
  const open = () => UI.st.open || (UI.st.open = {});
  // a button with a second line under the label (the price), for rows where the player buys
  const buyBtn = (label, onclick, cls) => { const b = btn(label, { cls: 'two ' + (cls || 'sm grow'), onclick }); b._sub = h('span', { class: 'sub' }); b._l.after(b._sub); return b; };

  // The line under the category chips: how healthy this part of the company is right now. The (i) opens what it is for.
  function strip(cat) {
    const lad = cat.lad ? D.ladders[cat.lad] : null, key = 'info:' + cat.id;
    const badge = h('span', { class: 'badge' }), line = h('div', { class: 'xs' }), meter = bar('thin');
    const name = h('div', { class: 'b' });
    const tog = h('button', { class: 'abi', type: 'button', 'aria-label': 'What are ' + cat.name + ' for?' }, I('info', 16));
    const info = h('div', { class: 'ustrip-info xs' }, h('div', { class: 'mut' }, cat.what), h('div', { class: 'dimt row gap4', style: { alignItems: 'flex-start' } }, I('info', 12), h('span', {}, cat.cost)));
    const card = h('div', { class: 'card ustrip' }, h('div', { class: 'row' }, h('div', { class: 'ico' }, I(cat.icon, 18)),
      h('div', { class: 'grow' }, h('div', { class: 'row between' }, name, badge), line), tog), meter, info);
    const show = (on) => { open()[key] = on; card.classList.toggle('open', on); CL(tog, 'on', on); };
    tog.addEventListener('click', () => { G.audio.sfx('tap'); show(!card.classList.contains('open')); });
    show(!!open()[key]);
    bind(card, () => {
      const st = STATUS[cat.id]();
      T(name, lad ? cat.name + ' · ' + lad[G.state.inf[cat.lad]].name : cat.name);
      const gauge = st.f != null; // office and labs have no "how full" to show: no bar, no badge
      meter.hidden = !gauge; badge.hidden = !gauge;
      T(line, st.text); if (gauge) setBar(meter, Math.min(1, st.f));
      CL(meter, 'bad', st.tone === 'bad'); CL(meter, 'gold', st.tone === 'warn'); CL(meter, 'good', st.tone === 'good');
      T(badge, { good: 'HEALTHY', warn: 'WATCH', bad: 'PROBLEM' }[st.tone]); badge.className = 'badge ' + { good: 'good', warn: 'gold', bad: 'bad' }[st.tone];
      line.className = 'xs ' + (st.tone === 'bad' ? 'neg' : st.tone === 'warn' ? 'gold' : 'mut');
    });
    return card;
  }

  /* ---------- servers ---------- */
  // What one more of this server does to income and costs (asked again whenever the advisor refreshes).
  const hwImpact = (hw) => () => ADV.cached('hw1:' + hw.k, () => ADV.impact((st) => merge(st, PT.hw(st, hw.k, 1, G.hwCost(hw.k, 1)))));
  const SERVER_NOTE = 'Your servers already handle every user, so a new one only adds power and maintenance costs until more users arrive.';
  const SERVER_NONE = 'Not needed yet: your servers already serve all your users, so more will not earn more.';
  const toRacks = () => UI.follow({ tab: 'upgrades', cat: 'racks' });

  // A server you cannot use yet: dimmed, and says what unlocks it.
  function lockedRow(hw) {
    return h('div', { class: 'card cfold lockc' }, h('div', { class: 'chead' }, W.pic('hw', hw.idx, 72, 58, { dim: true, tint: hw.color, pad: 3 }),
      h('div', { class: 'cmain' }, h('div', { class: 'cname' }, hw.name), h('div', { class: 'xs dimt' }, U.tf(hw.tf) + ' · ' + U.mw(hw.mw) + ' each'),
        h('div', { class: 'xs warn row gap4' }, I('lock', 11), 'Research ' + D.rmap[hw.req].name)),
      h('div', { class: 'cact' }, btn('Research', { cls: 'sm ghost', onclick: () => UI.follow({ tab: 'research' }) }))));
  }
  // A server you can buy. The row shows the verdict and the button; the details open on tap.
  function hwRow(hw) {
    const tf = U.tf(hw.tf), mw = U.mw(hw.mw);
    const line = h('div', { class: 'xs mut' }), gain = W.gainLine({ none: 'Not needed yet', noIncome: 'Not needed yet' }), why = h('div', { class: 'xs warn', hidden: true });
    const b1 = buyBtn('Buy 1', () => UI.act(() => G.act.buyHw(hw.k, 1), 'buy'), 'sm pri');
    const racks = btn('Add racks', { cls: 'sm ghost', onclick: toRacks });
    const head = h('div', { class: 'chead' }, W.pic('hw', hw.idx, 72, 58, { tint: hw.color, pad: 3 }),
      h('div', { class: 'cmain' }, h('div', { class: 'cname' }, h('span', { class: 'grow' }, hw.name), W.caret()), line, gain, why),
      h('div', { class: 'cact' }, b1, racks));
    const impact = h('div', { class: 'col gap4' }, h('div', { class: 'micro' }, 'If you buy 1 more'),
      W.liveImpact(hwImpact(hw), (imp) => ({ none: SERVER_NONE, note: imp.inc > W.eps() ? null : SERVER_NOTE })));
    const b10 = buyBtn('Buy 10', () => UI.act(() => G.act.buyHw(hw.k, 10), 'buy')), bm = buyBtn('Max', () => UI.act(() => G.act.buyHw(hw.k, G.maxHw(hw.k)), 'buy'));
    const up = btn('Replace weaker', { cls: 'sm pri grow', onclick: () => UI.act(() => G.act.upgradeHw(hw.k, 1), 'buy') });
    const sell = btn('Sell', { cls: 'sm ghost grow', onclick: () => UI.act(() => G.act.sellHw(hw.k, 1), 'tap') });
    const body = h('div', { class: 'col gap8' }, h('div', { class: 'xs dimt' }, hw.desc), h('div', { class: 'stchs' }, stat('cpu', tf + ' each'), stat('bolt', mw + ' each'), stat('chat', hw.use)),
      impact, h('div', { class: 'row' }, b10, bm), h('div', { class: 'row' }, up, sell));
    const card = W.fold('srv:' + hw.k, head, body);
    bind(card, () => {
      const s = G.state, C = G.C, r = C.slotsTotal - C.nServers, n = s.inf[hw.k], c1 = G.hwCost(hw.k, 1), c10 = G.hwCost(hw.k, 10), mx = G.maxHw(hw.k);
      T(line, (n ? 'Own ' + n + ' · ' : '') + tf + ' · ' + mw + ' each');
      T(b1._sub, U.money(c1)); T(b10._sub, U.money(c10)); T(bm._sub, mx > 0 ? '×' + mx + ' · ' + U.money(G.hwCost(hw.k, mx)) : '—');
      DIS(b1, s.cash < c1); DIS(b10, r < 10 || s.cash < c10); DIS(bm, mx < 1);
      b1.hidden = r < 1; racks.hidden = r >= 1; gain.hidden = r < 1; impact.hidden = r < 1;
      if (r >= 1) gain.set(hwImpact(hw)());
      const msg = r < 1 ? 'No free rack slots' : s.cash < c1 ? 'Need ' + U.money(c1 - s.cash) + ' more' : '';
      why.hidden = !msg; T(why, msg);
      up.hidden = !(r < 1 && D.hw.some((x) => x.tf < hw.tf && s.inf[x.k] > 0));
      sell.hidden = n < 1;
      T(sell._l, 'Sell 1 · ' + U.money(G.sellValue(hw.k)));
    });
    return card;
  }
  function serversList() {
    const out = [];
    const un = D.hw.filter((x) => G.hwUnlocked(x.k)).reverse(), lk = D.hw.filter((x) => !G.hwUnlocked(x.k));
    out.push(UI.sec('Servers you can buy · best first'));
    un.forEach((hw) => out.push(hwRow(hw)));
    if (lk.length) { out.push(UI.sec('Locked: unlock with research')); lk.forEach((hw) => out.push(lockedRow(hw))); }
    return out;
  }

  /* ---------- racks ---------- */
  function racksList() {
    const own = h('b'), note = h('div', { class: 'xs' });
    const r1 = buyBtn('Buy 1', () => UI.act(() => G.act.buyRack(1), 'buy')), r4 = buyBtn('Buy 4', () => UI.act(() => G.act.buyRack(4), 'buy')), rm = buyBtn('Max', () => UI.act(() => G.act.buyRack(G.maxRack()), 'buy'));
    const full = btn('Open Data center', { cls: 'sm pri blk', onclick: () => UI.follow({ tab: 'upgrades', cat: 'dc' }) });
    const card = h('div', { class: 'card ucard' },
      h('div', { class: 'chead top' }, W.pic('rack', 0, 72, 58, { pad: 3 }),
        h('div', { class: 'cmain' }, h('div', { class: 'row between' }, h('div', { class: 'cname' }, D.rack.name), h('div', { class: 'xs mut' }, 'Racks ', own)),
          h('div', { class: 'xs dimt' }, 'Holds ' + D.rack.slots + ' servers. Earns nothing by itself: it only makes room for servers.'), note)),
      h('div', { class: 'row' }, r1, r4, rm), full);
    bind(card, () => {
      T(own, G.state.inf.racks + '/' + G.C.rackCap);
      const room = G.C.rackCap - G.state.inf.racks, mx = G.maxRack(), cash = G.state.cash;
      T(r1._sub, U.money(G.rackCost(1))); T(r4._sub, U.money(G.rackCost(4))); T(rm._sub, mx > 0 ? '×' + mx : '—');
      DIS(r1, room < 1 || cash < G.rackCost(1)); DIS(r4, room < 4 || cash < G.rackCost(4)); DIS(rm, mx < 1);
      full.hidden = room > 0;
      T(note, room < 1 ? 'Your floor is full. A bigger data center has room for more racks.' : 'Floor space left for ' + room + ' more rack' + (room > 1 ? 's' : '') + '.');
      CL(note, 'warn', room < 1);
    });
    return [UI.sec('Buy racks'), card];
  }

  /* ---------- buildings (data center, cooling, power, network, office, labs) ---------- */
  function buildingCard(cat, b) {
    const lad = D.ladders[cat.lad], t = lad[b.to], card = h('div', { class: 'card ucard hl' });
    const pb = bar('gold anim'), eta = h('b', { class: 'gold' });
    card.append(h('div', { class: 'chead top' }, W.pic(cat.kind, b.to, 84, 68, { pad: 3 }),
      h('div', { class: 'cmain' }, h('div', { class: 'micro gold' }, 'Being built'), h('div', { class: 'cname' }, t.name), h('div', { class: 'xs mut' }, D.ladderMeta[cat.lad].stat(t)))),
    h('div', { class: 'col gap4' }, h('div', { class: 'row between sm' }, h('span', {}, 'Construction'), eta), pb),
    h('div', { class: 'xs dimt' }, 'Your current ' + lad[b.to - 1].name + ' keeps working while the new one is built.'));
    bind(pb, () => { setBar(pb, 1 - b.left / b.total); T(eta, Math.floor((1 - b.left / b.total) * 100) + '% · ' + U.dur(b.left) + ' left'); });
    return card;
  }
  function nextCard(cat, nx) {
    const k = cat.lad, s = G.state, lvl = s.inf[k], cur = D.ladders[k][lvl], meta = D.ladderMeta[k], cost = G.ladderCost(nx);
    const card = h('div', { class: 'card ucard hl' });
    // the button sits in the head, like the Buy buttons in the server rows; the reason it is switched off goes right under the head
    const act = UI.actionParts('Build', null, 'two pri', () => buildWhy(nx, cost), () => UI.act(() => G.act.build(k), 'build'));
    act.b._l.after(h('span', { class: 'sub' }, U.money(cost)));
    card.append(h('div', { class: 'chead top' }, W.pic(cat.kind, lvl + 1, 84, 68, { pad: 3 }),
      h('div', { class: 'cmain' }, h('div', { class: 'row between' }, h('span', { class: 'micro acc' }, 'Next upgrade'), h('span', { class: 'badge acc' }, 'LV ' + (lvl + 2) + '/' + D.ladders[k].length)),
        h('div', { class: 'cname' }, nx.name), h('div', { class: 'xs mut' }, meta.stat(nx)),
        h('div', { class: 'stchs' }, stat('clock', U.dur(nx.time) + ' to build'))),
      h('div', { class: 'cact' }, act.b)), act.row);
    card.append(W.compare(CMP[k](cur, nx)));
    const impact = () => ADV.cached('lad:' + k + lvl, () => ADV.impact((st) => merge(st, PT.inf(st, { [k]: st.inf[k] + 1 }, cost))));
    card.append(h('div', { class: 'col gap4' }, h('div', { class: 'micro' }, 'If you build it'), W.liveImpact(impact, { none: ZERO[k], note: NOTE[k] })));
    if (nx.desc) card.append(h('div', { class: 'xs dimt clamp2' }, nx.desc));
    return card;
  }
  function laterRow(cat, i) {
    const lad = D.ladders[cat.lad], t = lad[i], req = t.req && !G.state.res.done[t.req] ? D.rmap[t.req].name : null;
    return h('div', { class: 'mrow later' }, W.pic(cat.kind, i, 72, 58, { dim: true, pad: 3 }),
      h('div', { class: 'grow' }, h('div', { class: 'sm b' }, t.name), h('div', { class: 'xs mut' }, D.ladderMeta[cat.lad].stat(t)), req ? h('div', { class: 'xs dimt row gap4' }, I('lock', 11), 'Needs ' + req) : null),
      h('div', { class: 'tr' }, h('div', { class: 'sm gold b' }, U.money(G.ladderCost(t))), h('div', { class: 'xs dimt' }, U.dur(t.time))));
  }
  function ladderList(cat) {
    const k = cat.lad, s = G.state, lad = D.ladders[k], lv = s.inf[k], b = G.building(k), nx = lad[lv + 1], out = [];
    if (k === 'hq' && G.canReinvent()) {
      out.push(h('div', { class: 'card vio' }, h('div', { class: 'row' }, h('div', { class: 'ico vio' }, I('refresh', 20)), h('div', { class: 'grow' }, h('div', { class: 'h3' }, 'Corporate Reinvention'), h('div', { class: 'xs mut' }, 'Your company is ready to be reinvented for ' + G.reinventGain() + ' Legacy Patents.'))), btn('Learn more', { cls: 'vio blk', onclick: () => { UI.st.achSeg = 'legacy'; UI.go('achv'); } })));
    }
    if (b) out.push(buildingCard(cat, b));
    else if (nx) out.push(nextCard(cat, nx));
    else out.push(h('div', { class: 'card row' }, h('span', { class: 'badge good' }, 'MAX LEVEL'), h('span', { class: 'sm mut' }, 'There is nothing left to upgrade here.')));
    const from = (b ? b.to : lv + 1) + 1;
    if (from < lad.length) {
      out.push(UI.sec('Coming later'));
      const rows = []; for (let i = from; i < lad.length; i++) rows.push(laterRow(cat, i));
      out.push(h('div', { class: 'card full mlist' }, rows));
    }
    return out;
  }

  /* ---------- category chips ---------- */
  function pills(onPick) {
    const el = h('div', { class: 'upills', 'data-keep': 'uppills' });
    const dots = {};
    CATS.forEach((c) => {
      const dot = h('i', { class: 'pd' }), b = h('button', { class: 'upill' + (UI.st.upCat === c.id ? ' on' : ''), type: 'button', 'data-c': c.id, 'aria-label': c.name }, I(c.icon, 16), h('span', {}, c.name), dot);
      b.addEventListener('click', () => { G.audio.init(); G.audio.sfx('tap'); onPick(c); });
      dots[c.id] = dot; el.append(b);
    });
    // a coloured dot on a chip: red = a problem there, gold = you can build something now, teal = being built
    bind(el, () => {
      const prob = {};
      for (const t of ADV.coach()) if (t.id.indexOf('cap-') === 0 && t.sev > 0.03) prob[t.id.slice(4)] = 1;
      for (const c of CATS) {
        let st = '';
        if (prob[c.id]) st = 'bad';
        else if (c.lad && G.building(c.lad)) st = 'busy';
        else if (c.lad && G.canBuild(c.lad)) st = 'gold';
        const d = dots[c.id]; if (d._s !== st) { d._s = st; d.className = 'pd ' + st; }
      }
    });
    return el;
  }

  /* ---------- the screen ---------- */
  // Where to start when the player has not picked a list yet: the problem that holds income back, else something buildable.
  function startCat() {
    const t = ADV.capacity();
    if (t && CMAP[t.id.slice(4)]) return t.id.slice(4);
    const ready = CATS.find((c) => c.lad && G.canBuild(c.lad));
    return ready ? ready.id : 'servers';
  }
  const LISTS = { servers: serversList, racks: racksList };

  UI.tabs.upgrades = function () {
    if (!CMAP[UI.st.upCat]) UI.st.upCat = startCat();
    const cat = CMAP[UI.st.upCat];
    // Portrait: one scrolling column. The campus on top is big, the list scrolls up over it and the category chips stay at the top.
    // Landscape: the campus on the left and the list on the right (see the media query in style.css).
    const root = h('div', { class: 'tab-split ups', 'data-keep': 'upsroot', style: col() });
    const vpbox = h('div', { class: 'vpbox upv' });
    const panel = h('div', { class: 'panel cols', 'data-keep': 'ups' });
    // The one thing that holds income back right now, as a short banner. It heads every list, except where the list itself is that fix.
    const alert = h('div', { class: 'full col gap8' });
    bind(alert, () => {
      const t = ADV.capacity(), show = t && !(t.id === 'cap-' + cat.id && cat.id !== 'servers');
      const key = show ? t.id + '|' + t.title : ''; // the banner keeps its own numbers current, so only a different problem rebuilds it
      if (alert._k === key) return;
      alert._k = key; alert.textContent = ''; alert.hidden = !show; // an empty block would still take its share of the gap
      if (show) alert.append(W.alertBar(t, { here: cat.id }));
    });
    panel.append(alert, strip(cat));
    (LISTS[cat.id] || (() => ladderList(cat)))().forEach((n) => panel.append(n));
    const chips = pills((c) => { UI.st.upCat = c.id; UI.go('upgrades', true); });
    root.append(vpbox, h('div', { class: 'upcol' }, chips, panel));
    // The campus is only drawn while it is on screen: once the list has scrolled up over it, the frames are saved.
    const onScreen = () => { S.visible = root.scrollTop < vpbox.offsetHeight - 24 || root.scrollHeight <= root.clientHeight + 2; };
    root.addEventListener('scroll', onScreen, { passive: true });
    setTimeout(() => {
      UI.mountVp(vpbox, cat.view);
      onScreen();
      const on = chips.querySelector('.on');
      if (on) chips.scrollLeft = Math.max(0, on.offsetLeft - (chips.clientWidth - on.offsetWidth) / 2);
    }, 0);
    return root;
  };

  // Tapping a building on the campus jumps to its list (the data hall keeps the Servers and Racks lists open).
  UI.picks.upgrades = function (obj) {
    if (!obj || !CMAP[obj.kind]) return;
    if (obj.kind === 'dc' && (UI.st.upCat === 'servers' || UI.st.upCat === 'racks')) return;
    if (UI.st.upCat !== obj.kind) UI.follow({ tab: 'upgrades', cat: obj.kind });
  };
})();
