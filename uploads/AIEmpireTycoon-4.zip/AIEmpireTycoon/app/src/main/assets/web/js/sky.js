/* AI Empire Tycoon - the sky above the island: a day and night cycle with sunrise and sunset, a sun and a moon crossing the sky,
   the northern lights at night and a flock of birds by day. The cycle follows game time, so it runs faster when the game does.
   The island is drawn in night colours; in daylight a colour layer is laid over what is drawn (see grade) and a gradient sits
   between the stars and the island (a plain DOM layer, so the browser composites it for free). */
(function () {
  'use strict';
  const G = window.G, U = G.U, A = G.art;
  const K = (G.sky = {});
  const TAU = Math.PI * 2;
  K.DAY = 480;       // game seconds in one full day: eight minutes at normal speed
  K.START = 0.965;   // a new company starts a moment before sunrise
  const ss = (a, b, x) => { const t = U.clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
  const st = { u: K.START, alt: -0.2, light: 0, warm: 0.3, night: 1, lamp: 1 };
  let hold = null;
  K.now = () => st;
  K.set = (u) => { hold = u; };   // pins the time of day (tests and screenshots); null lets it run again

  /* ---------- the clock ---------- */
  K.update = function () {
    const s = G.state;
    const u = hold !== null && hold !== undefined ? hold : ((((s ? s.gt : 0) / K.DAY) + K.START) % 1 + 1) % 1;
    const alt = Math.sin(u * TAU);               // height of the sun: above 0 by day, below 0 by night
    st.u = u; st.alt = alt;
    st.light = ss(-0.1, 0.38, alt);
    st.warm = alt > -0.4 ? Math.exp(-Math.pow(alt / 0.2, 2)) : 0;   // golden hour around both horizon crossings
    st.night = 1 - st.light;
    st.lamp = 1 - ss(-0.02, 0.3, alt);
    paintDom();
    return st;
  };

  /* ---------- the sky gradient (DOM) ---------- */
  let el = null, dayEl = null, warmEl = null, dd = -1, dw = -1, dv = -1;
  K.el = function () {
    if (el) return el;
    el = document.createElement('div'); el.className = 'skyfx';
    dayEl = document.createElement('i'); dayEl.className = 'sk-day';
    warmEl = document.createElement('i'); warmEl.className = 'sk-warm';
    el.append(dayEl, warmEl);
    return el;
  };
  function paintDom() {
    if (!el) return;
    const a = Math.round(0.96 * st.light * 50) / 50, b = Math.round(0.9 * st.warm * 50) / 50, v = Math.round((1 - 0.6 * st.light) * 20) / 20;
    if (a !== dd) { dd = a; dayEl.style.opacity = a; }
    if (b !== dw) { dw = b; warmEl.style.opacity = b; }
    if (v !== dv && el.parentNode) { dv = v; el.parentNode.style.setProperty('--vig', v); }
  }

  /* ---------- sprites ---------- */
  let moonSpr = null, strips = {};
  function moon() {
    if (moonSpr) return moonSpr;
    const s = 64, k = document.createElement('canvas'); k.width = k.height = s;
    const g = k.getContext('2d'), r = 15;
    const body = g.createRadialGradient(s / 2 - 5, s / 2 - 5, 2, s / 2, s / 2, r + 2);
    body.addColorStop(0, '#ffffff'); body.addColorStop(1, '#bcd0f0');
    g.fillStyle = body; g.beginPath(); g.arc(s / 2, s / 2, r, 0, TAU); g.fill();
    g.fillStyle = 'rgba(120,145,190,.35)';
    [[-5, -3, 3.2], [4, 4, 2.4], [5, -6, 1.8], [-3, 7, 1.6]].forEach((p) => { g.beginPath(); g.arc(s / 2 + p[0], s / 2 + p[1], p[2], 0, TAU); g.fill(); });
    return (moonSpr = k);
  }
  function strip(col) {
    if (strips[col]) return strips[col];
    const k = document.createElement('canvas'); k.width = 4; k.height = 128;
    const g = k.getContext('2d'), gr = g.createLinearGradient(0, 0, 0, 128);
    gr.addColorStop(0, U.rgba(col, 0)); gr.addColorStop(0.25, U.rgba(col, 0.85)); gr.addColorStop(1, U.rgba(col, 0));
    g.fillStyle = gr; g.fillRect(0, 0, 4, 128);
    return (strips[col] = k);
  }

  /* ---------- birds ---------- */
  const flocks = [];
  let nextBirds = 6;
  function birds(FR) {
    const dt = FR.dt, c = FR.c;
    if (FR.q > 0) {
      nextBirds -= dt;
      if (nextBirds <= 0) {
        nextBirds = 22 + Math.random() * 30;
        if (st.light > 0.45 && flocks.length < 2) {
          const dir = Math.random() < 0.5 ? 1 : -1, n = 3 + Math.floor(Math.random() * 3);
          flocks.push({ x: dir > 0 ? -50 : FR.W + 50, y: FR.H * (0.1 + Math.random() * 0.2), v: dir * (38 + Math.random() * 30), ph: Math.random() * 6, n });
        }
      }
    }
    if (!flocks.length) return;
    c.lineWidth = 1.5; c.lineCap = 'round';
    for (let i = flocks.length - 1; i >= 0; i--) {
      const f = flocks[i];
      f.x += f.v * dt;
      if (f.x < -80 || f.x > FR.W + 80) { flocks.splice(i, 1); continue; }
      c.strokeStyle = 'rgba(14,30,66,' + (0.5 * st.light + 0.15) + ')';
      for (let k = 0; k < f.n; k++) {
        const x = f.x - Math.sign(f.v) * (k % 2 ? 1 : -1) * Math.ceil(k / 2) * 15, y = f.y + Math.ceil(k / 2) * 9 + Math.sin(FR.T * 0.8 + f.ph + k) * 4;
        const w = Math.sin(FR.T * 9 + k * 1.7 + f.ph) * 4.2;
        c.beginPath(); c.moveTo(x - 7, y - w * 0.6); c.quadraticCurveTo(x - 3, y - 4 + w * 0.4, x, y); c.quadraticCurveTo(x + 3, y - 4 + w * 0.4, x + 7, y - w * 0.6); c.stroke();
      }
    }
    c.lineCap = 'butt';
  }

  /* ---------- the celestial bodies and the northern lights (screen space, behind the island) ---------- */
  K.aurora = 0;   // celebrations raise this for a few seconds (the sky lights up)
  K.boost = function (secs) { K.aurora = Math.max(K.aurora, secs || 8); };
  K.draw = function (FR) {
    const c = FR.c, W = FR.W, H = FR.H, T = FR.T, q = FR.q;
    K.aurora = Math.max(0, K.aurora - FR.dt);
    // sun
    const sv = ss(-0.14, 0.04, st.alt);
    if (sv > 0.01) {
      const p = st.u < 0.75 ? U.clamp(st.u / 0.5, 0, 1) : U.clamp((st.u - 1) / 0.5, 0, 1);
      const x = W * (0.1 + 0.8 * p), y = H * (0.52 - 0.3 * Math.sin(Math.PI * p)), warm = st.warm;   // the arc stays under the chips at the top
      const col = warm > 0.5 ? '#ffb35c' : '#ffe08a';
      c.globalCompositeOperation = 'lighter';
      c.globalAlpha = 0.5 * sv; c.drawImage(A.glow(col), x - 120, y - 120, 240, 240);
      c.globalAlpha = 0.9 * sv; c.drawImage(A.glow('#fff1c2'), x - 44, y - 44, 88, 88);
      c.globalCompositeOperation = 'source-over';
      c.globalAlpha = sv;
      const g = c.createRadialGradient(x - 3, y - 3, 1, x, y, 17);
      g.addColorStop(0, '#ffffff'); g.addColorStop(0.6, warm > 0.5 ? '#ffc477' : '#fff0b0'); g.addColorStop(1, warm > 0.5 ? '#ff9d4a' : '#ffd25a');
      c.fillStyle = g; c.beginPath(); c.arc(x, y, 16, 0, TAU); c.fill();
      c.globalAlpha = 1;
    }
    // moon
    const mv = ss(-0.05, -0.35, st.alt);
    if (mv > 0.01) {
      const p2 = st.u >= 0.5 ? U.clamp((st.u - 0.5) / 0.5, 0, 1) : 0;
      const x = W * (0.9 - 0.8 * p2), y = H * (0.52 - 0.3 * Math.sin(Math.PI * p2));
      c.globalCompositeOperation = 'lighter'; c.globalAlpha = 0.5 * mv; c.drawImage(A.glow('#9fc0ff'), x - 60, y - 60, 120, 120);
      c.globalCompositeOperation = 'source-over'; c.globalAlpha = mv; c.drawImage(moon(), x - 32 * 0.8, y - 32 * 0.8, 64 * 0.8, 64 * 0.8);
      c.globalAlpha = 1;
    }
    // northern lights: soft ribbons high in the sky at night (and whenever something is being celebrated)
    const au = Math.max(st.night * st.night * 0.6, Math.min(1, K.aurora / 3)) * (q === 0 ? 0 : 1);
    if (au > 0.03) {
      c.globalCompositeOperation = 'lighter';
      const ribbons = q === 1 ? 2 : 3, step = q === 1 ? 14 : 9, cols = ['#3dffb0', '#3dd6c6', '#8b7cf6'];
      for (let r = 0; r < ribbons; r++) {
        const sp = strip(cols[r]), base = H * (0.1 + r * 0.075), amp = 16 + r * 6;
        for (let x = -step; x < W + step; x += step) {
          const w = Math.sin(x * 0.011 + T * (0.35 + r * 0.12) + r * 2) * amp + Math.sin(x * 0.027 - T * 0.5 + r) * amp * 0.5;
          const hh = 46 + Math.sin(x * 0.02 + T * 0.4 + r * 3) * 16 + r * 10;
          c.globalAlpha = au * (0.4 + 0.22 * Math.sin(x * 0.015 + T * 0.7 + r));
          c.drawImage(sp, x, base + w, step + 1, hh);
        }
      }
      c.globalAlpha = 1; c.globalCompositeOperation = 'source-over';
    }
    birds(FR);
  };

  /* ---------- colour of the light, laid over what is drawn ---------- */
  // 'source-atop' paints only where the island, sun, clouds and so on already are, so the sky layer behind stays untouched.
  K.grade = function (FR) {
    const a1 = 0.17 * st.light, a2 = 0.26 * st.warm;
    if (a1 < 0.01 && a2 < 0.01) return;
    const c = FR.c, w = FR.cv.width, h = FR.cv.height;
    c.save();
    c.setTransform(1, 0, 0, 1, 0, 0);
    c.globalCompositeOperation = 'source-atop';
    if (a1 >= 0.01) { c.fillStyle = 'rgba(255,246,226,' + a1.toFixed(3) + ')'; c.fillRect(0, 0, w, h); }
    if (a2 >= 0.01) { c.fillStyle = 'rgba(255,124,80,' + a2.toFixed(3) + ')'; c.fillRect(0, 0, w, h); }
    c.restore();
  };
  // how strong glows and lamps should be right now (they fade in daylight)
  K.glowK = () => 1 - 0.6 * st.light;

  if (G.scene && G.scene.use) { G.scene.use('sky', K.draw); G.scene.use('grade', K.grade); }
})();
