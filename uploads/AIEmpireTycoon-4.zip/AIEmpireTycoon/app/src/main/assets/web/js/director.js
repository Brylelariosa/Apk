/* AI Empire Tycoon - the cinematic camera.
   When Lumo starts on something the camera glides to that building and comes back to the whole campus by itself. It only ever uses
   S.focus, which says no when the player is steering the camera or when a list is showing its own building, and it rests between moves
   (longer at higher game speed) so it never feels like a ride. Switch it off in Lumo's panel. */
(function () {
  'use strict';
  const G = window.G, S = G.scene;
  const Dr = (G.director = {});
  let last = -99;   // when the camera last moved (seconds on the page clock)
  const clock = () => performance.now() / 1000;
  const enabled = () => {
    const s = G.state, UI = G.ui;
    return !!(s && s.cine && s.set && s.set.lumo && S.visible && UI && UI.tab() === 'hq' && !document.hidden);
  };
  // the pause between two moves: calmer when the game runs fast
  const rest = () => 6.5 + 2.5 * Math.log2(Math.max(1, G.state.speed || 1));

  // Look at a building for a few seconds. `urgent` skips the pause (something just finished there).
  Dr.go = function (kind, secs, zoom, urgent) {
    if (!kind || !enabled()) return false;
    const t = clock();
    if (!urgent && (t - last < rest() || (S.holding && S.holding()))) return false;
    if (!S.focus(kind, secs || 3.4, zoom || 1)) return false;
    last = t;
    return true;
  };
  // Back to the whole campus, but only when the camera is ours.
  Dr.home = function () {
    if (S.holding && S.holding()) { S.fit(false, true); last = clock(); }
  };

  G.on('ceo_plan', (o) => { const p = o && o.plan; if (p && p.target) Dr.go(p.target, 3.4, 1); });
  G.on('build_done', (o) => { const b = o && o.b; if (b && b.k) Dr.go(b.k, 3.6, 1, true); });
  G.on('launch_done', () => Dr.home());          // the rocket needs the whole island
  G.on('milestone', (o) => { if (o && o.big) Dr.home(); });   // so do the fireworks
})();
