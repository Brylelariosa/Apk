/* AI Empire Tycoon - the living island.
   Staff walk between the buildings, cars drive the roads, builders hammer at construction sites, customer requests stream in from the
   sky and become coins, drones deliver new servers, rival airships cruise past, the lamps come on at dusk and the island's edge drips
   glowing water. Everything is cosmetic: it reads the economy (and listens to game events) but never changes it.

   The scene (scene.js) calls into this file from its layers and passes a frame context FR: the canvas, time, camera, buildings and roads.
   Positions are tile coordinates (x, y, height) unless a name says "world", which means the projected pixels the scene draws in. */
(function () {
  'use strict';
  const G = window.G, D = G.D, U = G.U, A = G.art, S = G.scene;
  const L = (G.life = {});
  const P = A.P, clamp = U.clamp, lerp = U.lerp, TAU = Math.PI * 2, rnd = Math.random;
  const lit = () => G.sky.now();
  const speedK = () => Math.sqrt(Math.max(1, (G.state && G.state.speed) || 1));
  const pickOne = (a) => a[Math.floor(rnd() * a.length)];

  /* ---------- places ---------- */
  const bigOf = (FR, kind) => { let e = null; for (const it of FR.items) if (it.obj.kind === kind && (!e || (it.obj.lv || 0) >= (e.obj.lv || 0))) e = it; return e; };
  const anyOf = (FR, kind) => { const a = FR.items.filter((it) => it.obj.kind === kind); return a.length ? pickOne(a) : null; };
  const topOf = (e, lift) => { const f = e.obj.fp; return P(f[0] + f[2] / 2, f[1] + f[3] / 2, (f[4] || 40) + (lift || 0)); };
  // world position above a kind of building ('hq', 'lab', 'dc', 'cool', 'pwr', 'net'); `any` picks one of several halls at random
  L.top = function (kind, lift, any) { const FR = S.ctx, e = any ? anyOf(FR, kind) : bigOf(FR, kind); return e ? topOf(e, lift) : null; };
  const half = (FR) => (FR.land ? (FR.land.lx + FR.land.ly) * 16 : 300);
  const midX = (FR) => (FR.land ? (FR.land.lx - FR.land.ly) * 16 : 0);
  // where a world point is in the browser window (the effects canvas covers the whole window)
  function winPos(FR, wx, wy) {
    const p = FR.toScreen(wx, wy), r = FR.cv.getBoundingClientRect();
    return [r.left + p[0], r.top + p[1]];
  }

  // Where something standing at tile (x, y) goes in the back-to-front drawing order. A building is behind it when the building ends before
  // the actor along x or along y (the same rule scene.js uses between buildings); it is in front when the actor ends first.
  function depthAt(FR, x, y) {
    let lo = -1e9, hi = 1e9;
    for (const e of FR.items) {
      const f = e.obj.fp;
      if (!f || e.obj.kind === 'site') continue;
      let behind = f[0] + f[2] <= x + 1e-3 || f[1] + f[3] <= y + 1e-3, ahead = x <= f[0] + 1e-3 || y <= f[1] + 1e-3;
      if (behind && ahead) { behind = x + y >= e.sum; ahead = !behind; }
      if (behind) lo = Math.max(lo, e.depth); else if (ahead) hi = Math.min(hi, e.depth);
    }
    if (lo > -1e8) return Math.min(lo + 1e-3, hi - 1e-3);
    return hi < 1e8 ? hi - 1e-3 : x + y;
  }

  /* ---------- the roads, as a small network ---------- */
  const net = { sig: '', segs: [], conn: [] };
  function buildNet(FR) {
    const sig = FR.roads.map((r) => r.join(',')).join(';') + '|' + FR.items.map((e) => e.obj.id).join(',');
    if (sig === net.sig) return;
    net.sig = sig;
    net.segs = FR.roads.map((r) => ({ x0: r[0], y0: r[1], x1: r[2], y1: r[3], horiz: Math.abs(r[3] - r[1]) < 0.01, len: Math.max(0.5, Math.hypot(r[2] - r[0], r[3] - r[1])), stops: [] }));
    for (const sg of net.segs) {
      for (const e of FR.items) {
        const f = e.obj.fp;
        if (e.obj.kind === 'site' || !f) continue;
        let x, y, d, door;
        if (sg.horiz) {
          x = clamp(f[0] + f[2] / 2, Math.min(sg.x0, sg.x1), Math.max(sg.x0, sg.x1)); y = sg.y0;
          if (x < f[0] + 0.2 || x > f[0] + f[2] - 0.2) continue;
          d = y < f[1] ? f[1] - y : y > f[1] + f[3] ? y - f[1] - f[3] : 0; door = [x, y < f[1] ? f[1] : f[1] + f[3]];
        } else {
          y = clamp(f[1] + f[3] / 2, Math.min(sg.y0, sg.y1), Math.max(sg.y0, sg.y1)); x = sg.x0;
          if (y < f[1] + 0.2 || y > f[1] + f[3] - 0.2) continue;
          d = x < f[0] ? f[0] - x : x > f[0] + f[2] ? x - f[0] - f[2] : 0; door = [x < f[0] ? f[0] : f[0] + f[2], y];
        }
        if (d < 0.3 || d > 2.2) continue;
        sg.stops.push({ u: sg.horiz ? (x - sg.x0) / (sg.x1 - sg.x0) : (y - sg.y0) / (sg.y1 - sg.y0), door, x, y, id: e.obj.id });
      }
    }
    // where two roads meet, so people and cars can turn the corner
    net.conn = net.segs.map((a, i) => [0, 1].map((end) => {
      const px = end ? a.x1 : a.x0, py = end ? a.y1 : a.y0, out = [];
      net.segs.forEach((b, j) => {
        if (j === i) return;
        const dx = b.x1 - b.x0, dy = b.y1 - b.y0, l2 = dx * dx + dy * dy || 1, u = clamp(((px - b.x0) * dx + (py - b.y0) * dy) / l2, 0, 1);
        if (Math.hypot(b.x0 + dx * u - px, b.y0 + dy * u - py) < 0.2) out.push({ seg: j, u });
      });
      return out;
    }));
  }
  // moves something along its road; at the end of a road it turns into a connecting road or turns around
  function advance(o, dt) {
    if (o.seg >= net.segs.length) { o.seg = 0; o.u = 0.5; }
    const sg = net.segs[o.seg];
    o.u += (o.dir * o.v * dt) / sg.len;
    if (o.u > 1 || o.u < 0) {
      const end = o.u > 1 ? 1 : 0, c = net.conn[o.seg][end];
      o.u = end;
      if (c.length && rnd() < 0.65) { const n = pickOne(c); o.seg = n.seg; o.u = n.u; o.dir = n.u <= 0.02 ? 1 : n.u >= 0.98 ? -1 : rnd() < 0.5 ? 1 : -1; } else o.dir = -o.dir;
      return true;
    }
    return false;
  }
  const roadAt = (o, lane) => { const sg = net.segs[o.seg], x = lerp(sg.x0, sg.x1, o.u), y = lerp(sg.y0, sg.y1, o.u); return sg.horiz ? [x, y + lane] : [x + lane, y]; };

  /* ---------- staff on foot ---------- */
  const walkers = [];
  const SHIRT = ['#ff9f6b', '#6bb8ff', '#b78cff', '#6be3b0', '#ffd16b', '#ff7f9e', '#7de3ff'], SKINS = ['#e8c39e', '#c68b64', '#8d5a3b', '#f1d1b5', '#a9714b'];
  function newWalker() {
    const w = { seg: Math.floor(rnd() * net.segs.length), u: rnd(), dir: rnd() < 0.5 ? 1 : -1, v: 0.9 + rnd() * 0.7, ph: rnd() * 6, col: pickOne(SHIRT), skin: pickOne(SKINS), look: Math.floor(rnd() * 997), face: 1, back: false, lane: (rnd() - 0.5) * 0.36, mode: 'road', t: 0, cool: 1 + rnd() * 5, stop: null, dist: 1, x: 0, y: 0, a: 1, vis: true };
    w.fn = (c) => {
      if (!w.vis) return;
      const p = P(w.x, w.y);
      c.globalAlpha = w.a;
      A.person(c, p[0], p[1], w.ph, w.col, false, w.skin, { look: w.look, face: w.face, back: w.back });
      c.globalAlpha = 1;
    };
    return w;
  }
  function stepWalker(w, dt) {
    const ox = w.x, oy = w.y;
    w.ph += dt * 9 * w.v;
    w.vis = true; w.a = 1;
    if (w.mode === 'road') {
      const u0 = w.u;
      advance(w, dt);
      w.cool -= dt;
      if (w.cool <= 0 && net.segs[w.seg]) {
        for (const st of net.segs[w.seg].stops) {
          if ((st.u - u0) * (st.u - w.u) <= 0 && Math.abs(w.u - u0) < 0.4 && rnd() < 0.55) {
            w.mode = 'to'; w.stop = st; w.t = 0; w.dist = Math.max(0.2, Math.hypot(st.door[0] - st.x, st.door[1] - st.y)); w.cool = 7 + rnd() * 9;
            break;
          }
        }
      }
      const p = roadAt(w, w.lane); w.x = p[0]; w.y = p[1];
    } else if (w.mode === 'to') {
      w.t += (dt * w.v) / w.dist;
      const k = Math.min(1, w.t);
      w.x = lerp(w.stop.x, w.stop.door[0], k); w.y = lerp(w.stop.y, w.stop.door[1], k);
      w.a = k < 0.7 ? 1 : (1 - k) / 0.3;
      if (w.t >= 1) { w.mode = 'wait'; w.t = 2 + rnd() * 7; }
    } else if (w.mode === 'wait') {
      w.vis = false; w.t -= dt;
      if (w.t <= 0) { w.mode = 'from'; w.t = 0; }
    } else {
      w.t += (dt * w.v) / w.dist;
      const k = Math.min(1, w.t);
      w.x = lerp(w.stop.door[0], w.stop.x, k); w.y = lerp(w.stop.door[1], w.stop.y, k);
      w.a = k < 0.3 ? k / 0.3 : 1;
      if (w.t >= 1) { w.mode = 'road'; w.u = w.stop.u; }
    }
    const sx = (w.x - ox) - (w.y - oy);   // which way it moved on the screen (x - y is the screen's horizontal)
    if (Math.abs(sx) > 1e-4) w.face = sx > 0 ? 1 : -1;
    const sy = (w.x - ox) + (w.y - oy);   // and up or down the screen (x + y): walking up the screen shows the back of the head
    if (Math.abs(sy) > 1e-4) w.back = sy < 0;
  }

  /* ---------- cars ---------- */
  const cars = [];
  const CARS = ['#6bb8ff', '#ff9f6b', '#e8eef8', '#6be3b0', '#b78cff'];
  function newCar(vip) {
    const k = { seg: 0, u: vip ? 0.02 : rnd(), dir: 1, v: vip ? 2.4 : 1.4 + rnd() * 0.9, col: vip ? '#12182b' : pickOne(CARS), wait: 0, vip: !!vip, done: false, x: 0, y: 0, horiz: true };
    if (!vip) { k.seg = Math.floor(rnd() * net.segs.length); k.dir = rnd() < 0.5 ? 1 : -1; }
    k.fn = (c) => drawCar(c, k);
    return k;
  }
  function stepCar(k, dt) {
    if (k.wait > 0) k.wait -= dt;
    else {
      const u0 = k.u;
      const bounced = advance(k, dt);
      if (k.vip) {
        if (bounced) { k.done = true; return; }
        if (!k.stopped) { const st = net.segs[0].stops.find((s) => s.id === 'hq'); if (st && (st.u - u0) * (st.u - k.u) <= 0) { k.stopped = true; k.wait = 3.4; } }
      }
    }
    const sg = net.segs[k.seg] || net.segs[0];
    k.horiz = sg.horiz;
    const p = roadAt(k, (k.dir > 0 ? 1 : -1) * 0.17); k.x = p[0]; k.y = p[1];
  }
  function drawCar(c, k) {
    const w = k.horiz ? (k.vip ? 1.0 : 0.76) : 0.4, d = k.horiz ? 0.4 : (k.vip ? 1.0 : 0.76), x = k.x - w / 2, y = k.y - d / 2, col = A.tri(k.col);
    const sp = P(k.x, k.y);
    c.fillStyle = 'rgba(0,0,0,.3)'; c.beginPath(); c.ellipse(sp[0], sp[1] + 1.5, 14, 5.5, 0, 0, TAU); c.fill();
    A.box(c, x, y, w, d, 3.4, 1.4, col, true);
    const cw = k.horiz ? w * 0.5 : w * 0.8, cd = k.horiz ? d * 0.8 : d * 0.5;
    A.box(c, k.x - cw / 2, k.y - cd / 2, cw, cd, 2.6, 4.8, A.tri(k.vip ? '#3a4a70' : '#cfe6ff'), true);
    const k2 = lit().lamp;
    if (k2 > 0.12) {
      const fx = k.x + (k.horiz ? k.dir * w / 2 : 0), fy = k.y + (k.horiz ? 0 : k.dir * d / 2), hp = P(fx, fy, 3.5);
      c.globalCompositeOperation = 'lighter'; c.globalAlpha = 0.75 * k2;
      c.drawImage(A.glow('#ffe9a8'), hp[0] - 11, hp[1] - 11, 22, 22);
      c.globalAlpha = 1; c.globalCompositeOperation = 'source-over';
    }
  }
  // the investor's limousine: it drives up to the headquarters, waits a moment, and leaves
  L.vip = function () { if (S.ctx && net.segs.length) cars.push(newCar(true)); };

  /* ---------- builders at work ---------- */
  function builders(FR, dl) {
    for (const sx of FR.sites) {
      const f = sx.fp;
      const spots = [[f[0] + f[2] * 0.3, f[1] + f[3] + 0.35, 0], [f[0] + f[2] + 0.35, f[1] + f[3] * 0.45, 1.7]];
      for (const sp of spots) {
        const x = sp[0], y = sp[1], ph = sp[2];
        dl.push([depthAt(FR, x, y), 2, (c) => {
          const p = P(x, y), T = FR.T, a = Math.sin(T * 7 + ph);
          const hand = A.person(c, p[0], p[1], 0, '#ffb347', false, '#e8c39e', { look: 11 + Math.floor(ph * 3), face: ph ? -1 : 1, hat: '#ffd24a', vest: true, still: true, arm: [7.2 + Math.cos(a * 1.1 - 0.4) * 4.5, -19.5 + Math.sin(a * 1.1 - 0.4) * 6.5] });
          const hx = hand[0], hy = hand[1];
          c.lineCap = 'round'; c.strokeStyle = '#2a2f44'; c.lineWidth = 3.0; c.beginPath(); c.moveTo(hx, hy); c.lineTo(hx - 2.6, hy + 5.6); c.stroke();
          c.strokeStyle = '#b7885a'; c.lineWidth = 1.6; c.beginPath(); c.moveTo(hx, hy); c.lineTo(hx - 2.6, hy + 5.6); c.stroke();
          c.fillStyle = '#8b94a8'; c.fillRect(hx - 3.6, hy - 2.6, 7.2, 3.8); c.strokeStyle = '#2a2f44'; c.lineWidth = 0.8; c.strokeRect(hx - 3.6, hy - 2.6, 7.2, 3.8);
          if (a > 0.9 && FR.q > 0) { c.globalCompositeOperation = 'lighter'; c.drawImage(A.glow('#ffd27a'), hx - 10, hy - 10, 20, 20); c.globalCompositeOperation = 'source-over'; }
        }]);
      }
    }
  }

  /* ---------- customer requests: orbs from the sky that the servers answer ---------- */
  const orbs = [], flashes = [];
  let orbAcc = 0, surgeLeft = 0, coinTokens = 3;
  L.surge = function (secs) { surgeLeft = Math.max(surgeLeft, secs || 12); };
  function streamColor() {
    const R = G.C && G.C.rev;
    if (!R || !(R.total > 0)) return '#3dd6c6';
    let r = rnd() * R.total;
    for (const st of D.streams) { r -= R[st.id] || 0; if (r <= 0) return st.color; }
    return '#3dd6c6';
  }
  function spawnOrb(FR) {
    const dc = anyOf(FR, 'dc') || bigOf(FR, 'hq');
    if (!dc) return;
    const side = rnd() < 0.5 ? -1 : 1, cx = midX(FR), hw = half(FR);
    const sx = cx + side * (hw + 160 + rnd() * 200), sy = -60 + rnd() * hw * 0.9;
    const t = topOf(dc, rnd() * 6), C = G.C, fail = C ? clamp(1 - C.sr, 0, 0.9) : 0;
    orbs.push({ x0: sx, y0: sy, x1: t[0] + (rnd() - 0.5) * 16, y1: t[1], cy: Math.min(sy, t[1]) - 50 - rnd() * 60, t: 0, dur: 1.5 + rnd() * 0.9, col: streamColor(), fail: rnd() < fail ? 0.78 + rnd() * 0.12 : 2, size: 2 + rnd() * 1.4 });
  }
  const bez = (o, t) => { const u = 1 - t; return [u * u * o.x0 + 2 * u * t * ((o.x0 + o.x1) / 2) + t * t * o.x1, u * u * o.y0 + 2 * u * t * o.cy + t * t * o.y1]; };
  function stepOrbs(FR, dt) {
    const C = G.C, q = FR.q;
    if (C && FR.all) {
      const rate = clamp(0.5 + Math.log10(1 + Math.max(0, C.served)) * 0.55, 0.5, 4.2) * (surgeLeft > 0 ? 2.6 : 1) * speedK() * [0, 0.8, 1][q];
      orbAcc += rate * dt;
      const max = [0, 16, 34][q];
      while (orbAcc >= 1) { orbAcc -= 1; if (orbs.length < max) spawnOrb(FR); }
    } else orbAcc = 0;
    surgeLeft = Math.max(0, surgeLeft - dt);
    coinTokens = Math.min(5, coinTokens + dt * 2.4 * Math.min(2, speedK()));
    for (let i = orbs.length - 1; i >= 0; i--) {
      const o = orbs[i];
      o.t += dt / o.dur;
      if (o.t >= o.fail && o.t < 2) {
        // overloaded servers drop this request: a red puff where it stopped
        const p = bez(o, Math.min(1, o.t));
        flashes.push({ x: p[0], y: p[1], t: 0, col: '#ff6b81', r: 14, bad: true });
        orbs.splice(i, 1);
        continue;
      }
      if (o.t >= 1) {
        orbs.splice(i, 1);
        flashes.push({ x: o.x1, y: o.y1, t: 0, col: o.col, r: 18 });
        if (coinTokens >= 1 && FR.visible) { coinTokens -= 1; const w = winPos(FR, o.x1, o.y1 - 14); G.fx.coin(w[0], w[1], 1, false); }
      }
    }
    for (let i = flashes.length - 1; i >= 0; i--) { flashes[i].t += dt * 2.2; if (flashes[i].t >= 1) flashes.splice(i, 1); }
  }
  function drawOrbs(FR) {
    const c = FR.c;
    c.globalCompositeOperation = 'lighter';
    for (const o of orbs) {
      const t = Math.min(1, o.t);
      for (let k = 3; k >= 0; k--) {
        const p = bez(o, Math.max(0, t - k * 0.035)), s = (o.size + 3.5) * (1 - k * 0.2);
        c.globalAlpha = (k === 0 ? 0.95 : 0.4 - k * 0.09) * Math.min(1, t * 6);
        c.drawImage(A.glow(o.col), p[0] - s * 1.6, p[1] - s * 1.6, s * 3.2, s * 3.2);
      }
      const p = bez(o, t);
      c.globalAlpha = 0.95; c.drawImage(A.glow('#ffffff'), p[0] - 3, p[1] - 3, 6, 6);
    }
    for (const f of flashes) {
      const e = 1 - (1 - f.t) * (1 - f.t), r = f.r * (0.4 + e * 1.6);
      c.globalAlpha = (1 - f.t) * (f.bad ? 0.75 : 0.9);
      c.drawImage(A.glow(f.col), f.x - r, f.y - r * 0.8, r * 2, r * 1.6);
      if (f.bad) { c.strokeStyle = f.col; c.lineWidth = 1.6; const s = 3 + f.t * 3; c.beginPath(); c.moveTo(f.x - s, f.y - s); c.lineTo(f.x + s, f.y + s); c.moveTo(f.x + s, f.y - s); c.lineTo(f.x - s, f.y + s); c.stroke(); }
    }
    c.globalAlpha = 1; c.globalCompositeOperation = 'source-over';
  }

  /* ---------- drones that deliver what was bought ---------- */
  const drones = [], crates = [];
  const KIND_COL = { hw: '#3dd6c6', rack: '#8b7cf6', contract: '#f6b84a', pack: '#ff9f6b' };
  L.drone = function (kind, col) {
    const FR = S.ctx;
    if (!FR || !S.visible || FR.q === 0 || drones.length > 5) return;
    const e = kind === 'hq' ? bigOf(FR, 'hq') : anyOf(FR, kind || 'dc');
    if (!e) return;
    const t = topOf(e, 0), side = rnd() < 0.5 ? -1 : 1, cx = midX(FR), hw = half(FR);
    drones.push({ t: 0, side, a: [cx + side * (hw + 260), t[1] - 240], h: [t[0] + (rnd() - 0.5) * 12, t[1] - 52], b: [cx - side * (hw + 300), t[1] - 280], land: [t[0], t[1] + 2], col: col || '#3dd6c6', dropped: false });
  };
  function stepDrones(FR, dt) {
    for (let i = drones.length - 1; i >= 0; i--) {
      const d = drones[i];
      d.t += dt;
      if (!d.dropped && d.t >= 1.7) {
        d.dropped = true;
        crates.push({ x: d.h[0], y: d.h[1] + 17, vy: 0, land: d.land[1], col: d.col, t: 0 });
      }
      if (d.t > 3.6) drones.splice(i, 1);
    }
    for (let i = crates.length - 1; i >= 0; i--) {
      const k = crates[i];
      k.vy += 520 * dt; k.y += k.vy * dt;
      if (k.y >= k.land) { flashes.push({ x: k.x, y: k.land, t: 0, col: k.col, r: 22 }); if (FR.q > 0 && FR.visible) { const w = winPos(FR, k.x, k.land - 6); G.fx.burst(w[0], w[1], k.col, 9, { speed: 70, size: 8, ttl: 0.6, arc: [-Math.PI, 0] }); } crates.splice(i, 1); }
    }
  }
  function crate(c, x, y, s, hex) {
    const t = A.tri(hex), hw = s, hh = s * 0.5, h = s * 0.95;
    A.poly(c, [[x - hw, y - h], [x, y - h + hh], [x, y + hh], [x - hw, y]], t.l);
    A.poly(c, [[x + hw, y - h], [x, y - h + hh], [x, y + hh], [x + hw, y]], t.r);
    A.poly(c, [[x, y - h - hh], [x + hw, y - h], [x, y - h + hh], [x - hw, y - h]], t.t);
    c.strokeStyle = 'rgba(255,255,255,.55)'; c.lineWidth = 1; c.beginPath(); c.moveTo(x, y - h - hh); c.lineTo(x, y + hh); c.stroke();
  }
  function drawDrones(FR) {
    const c = FR.c, T = FR.T;
    for (const d of drones) {
      const k = d.t < 1.7 ? U.ease.out(clamp(d.t / 1.7, 0, 1)) : 1, lv = d.t > 2.3 ? U.ease.out(clamp((d.t - 2.3) / 1.3, 0, 1)) : 0;
      const x = d.t < 2.3 ? lerp(d.a[0], d.h[0], k) : lerp(d.h[0], d.b[0], lv), y = (d.t < 2.3 ? lerp(d.a[1], d.h[1], k) : lerp(d.h[1], d.b[1], lv)) + Math.sin(T * 5) * 1.5;
      c.strokeStyle = '#1b2440'; c.lineWidth = 2; c.beginPath(); c.moveTo(x - 9, y); c.lineTo(x + 9, y); c.stroke();
      for (const dx of [-9, 9]) { c.fillStyle = 'rgba(190,230,255,.5)'; c.beginPath(); c.ellipse(x + dx, y - 2, 6.5, 1.3 + Math.abs(Math.sin(T * 38 + dx)) * 0.9, 0, 0, TAU); c.fill(); }
      c.fillStyle = '#e8eef8'; c.beginPath(); c.ellipse(x, y, 5.6, 3.6, 0, 0, TAU); c.fill();
      c.fillStyle = '#3dd6c6'; c.beginPath(); c.arc(x, y + 0.6, 1.5, 0, TAU); c.fill();
      if (!d.dropped) { c.strokeStyle = 'rgba(255,255,255,.6)'; c.lineWidth = 1; c.beginPath(); c.moveTo(x - 3, y + 3); c.lineTo(x - 3, y + 11); c.moveTo(x + 3, y + 3); c.lineTo(x + 3, y + 11); c.stroke(); crate(c, x, y + 19, 5.5, d.col); }
    }
    for (const k of crates) crate(c, k.x, k.y, 5.5, k.col);
  }

  /* ---------- rival airships ---------- */
  const ships = [];
  L.ship = function (r) {
    if (!S.ctx || !S.visible || ships.length > 2) return;
    const dir = rnd() < 0.5 ? 1 : -1, FR = S.ctx, hw = half(FR);
    ships.push({ x: midX(FR) - dir * (hw + 380), y: -45 - rnd() * 70, dir, v: 46 + rnd() * 14, col: r.color || '#ff7a8a', text: r.name + ' · ' + r.product, ph: rnd() * 6, t: 0, end: midX(FR) + dir * (hw + 460) });
  };
  function drawShips(FR) {
    const c = FR.c, T = FR.T, dt = FR.dt;
    for (let i = ships.length - 1; i >= 0; i--) {
      const s = ships[i];
      s.x += s.dir * s.v * dt * speedK();
      if ((s.dir > 0 && s.x > s.end) || (s.dir < 0 && s.x < s.end)) { ships.splice(i, 1); continue; }
      const y = s.y + Math.sin(T * 0.8 + s.ph) * 5;
      // banner trailing behind
      const bx = s.x - s.dir * 44, bw = 92, wave = Math.sin(T * 4 + s.ph) * 2;
      c.strokeStyle = 'rgba(220,230,255,.6)'; c.lineWidth = 1; c.beginPath(); c.moveTo(s.x - s.dir * 30, y + 4); c.lineTo(bx, y + 14 + wave); c.stroke();
      c.fillStyle = 'rgba(8,14,32,.88)'; c.strokeStyle = U.rgba(s.col, 0.8); c.lineWidth = 1.2;
      const x0 = s.dir > 0 ? bx - bw : bx;
      c.beginPath(); c.rect(x0, y + 8 + wave, bw, 15); c.fill(); c.stroke();
      c.fillStyle = '#eef3ff'; c.font = '700 8.5px Inter, system-ui, sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle';
      c.fillText(s.text.length > 22 ? s.text.slice(0, 21) + '…' : s.text, x0 + bw / 2, y + 15.8 + wave);
      c.textAlign = 'left'; c.textBaseline = 'alphabetic';
      // the envelope
      c.save(); c.translate(s.x, y); c.scale(s.dir, 1);
      const g = c.createLinearGradient(0, -14, 0, 14);
      g.addColorStop(0, U.shade(s.col, 1.35)); g.addColorStop(0.5, s.col); g.addColorStop(1, U.shade(s.col, 0.55));
      c.fillStyle = g; c.beginPath(); c.ellipse(0, 0, 36, 13, 0, 0, TAU); c.fill();
      c.strokeStyle = 'rgba(255,255,255,.28)'; c.lineWidth = 1; for (const k of [-16, 0, 16]) { c.beginPath(); c.ellipse(k, 0, 5, 12.4, 0, -1.4, 1.4); c.stroke(); }
      c.fillStyle = U.shade(s.col, 0.7); c.beginPath(); c.moveTo(-30, -3); c.lineTo(-44, -13); c.lineTo(-40, 0); c.lineTo(-44, 13); c.lineTo(-30, 3); c.closePath(); c.fill();
      c.fillStyle = '#1b2236'; c.fillRect(-8, 12, 16, 6);
      c.fillStyle = 'rgba(255,224,150,.9)'; for (let k = 0; k < 3; k++) c.fillRect(-6 + k * 4.5, 13.4, 3, 2.4);
      c.strokeStyle = '#cdd6ea'; c.lineWidth = 1.6; const a = T * 30; c.beginPath(); c.moveTo(-46, Math.sin(a) * 6); c.lineTo(-46, -Math.sin(a) * 6); c.stroke();
      c.restore();
    }
  }

  /* ---------- the lamps, water over the edge and fireflies ---------- */
  const drops = [], flies = [];
  let dropAcc = 0;
  function ground(FR) {
    const c = FR.c, dt = FR.dt, q = FR.q, k = lit().lamp * G.sky.glowK();
    // water that spills over the rim of the island and falls into the dark
    if (FR.land && q > 0) {
      const lx = FR.land.lx, ly = FR.land.ly, w = P(0, ly), s = P(lx, ly), e = P(lx, 0), pal = A.palette(G.state.pres.skin || 'midnight');
      dropAcc += dt * [0, 5, 10][q];
      while (dropAcc >= 1) {
        dropAcc -= 1;
        if (drops.length > 90) break;
        const side = rnd() < 0.5, t = 0.08 + rnd() * 0.84, a = side ? w : s, b = side ? s : e;
        drops.push({ x: lerp(a[0], b[0], t), y: lerp(a[1], b[1], t) + 16, vx: (side ? -1 : 1) * (4 + rnd() * 10), vy: 10 + rnd() * 30, t: 0, ttl: 1.2 + rnd() * 0.9, col: pal.acc });
      }
      c.globalCompositeOperation = 'lighter';
      for (let i = drops.length - 1; i >= 0; i--) {
        const d = drops[i];
        d.t += dt; d.vy += 360 * dt; d.x += d.vx * dt; d.y += d.vy * dt;
        if (d.t >= d.ttl) { drops.splice(i, 1); continue; }
        const a = 1 - d.t / d.ttl;
        c.globalAlpha = 0.55 * a; c.strokeStyle = d.col; c.lineWidth = 1.6; c.beginPath(); c.moveTo(d.x, d.y); c.lineTo(d.x - d.vx * 0.05, d.y - d.vy * 0.06); c.stroke();
        c.globalAlpha = 0.5 * a; c.drawImage(A.glow(d.col), d.x - 4, d.y - 4, 8, 8);
      }
      c.globalAlpha = 1; c.globalCompositeOperation = 'source-over';
    }
    // street lamps with a pool of light on the road
    if (k > 0.06) {
      c.lineCap = 'round';
      for (const sg of net.segs) {
        const n = Math.max(1, Math.floor(sg.len / 2.6));
        for (let i = 0; i < n; i++) {
          const u = (i + 0.5) / n, x = lerp(sg.x0, sg.x1, u) + (sg.horiz ? 0 : -0.62), y = lerp(sg.y0, sg.y1, u) + (sg.horiz ? -0.62 : 0);
          const b = P(x, y), h = P(x, y, 13);
          c.strokeStyle = '#2a3558'; c.lineWidth = 1.4; c.beginPath(); c.moveTo(b[0], b[1]); c.lineTo(h[0], h[1]); c.stroke();
          c.globalCompositeOperation = 'lighter';
          c.globalAlpha = 0.14 * k; c.drawImage(A.glow('#ffd9a0'), b[0] - 26, b[1] - 12, 52, 24);
          c.globalAlpha = 0.85 * k; c.drawImage(A.glow('#ffe2b0'), h[0] - 9, h[1] - 9, 18, 18);
          c.globalCompositeOperation = 'source-over';
        }
      }
      c.lineCap = 'butt'; c.globalAlpha = 1;
    }
  }
  function fireflies(FR) {
    const c = FR.c, k = clamp((1 - lit().light) * 1.2, 0, 1);
    if (FR.q === 0 || k < 0.05 || !FR.land) return;
    if (!flies.length) for (let i = 0; i < 16; i++) flies.push({ x: rnd(), y: rnd(), ph: rnd() * 6.28, sp: 0.2 + rnd() * 0.4, r: 0.5 + rnd() * 1.5 });
    const lx = FR.land.lx, ly = FR.land.ly, T = FR.T, n = FR.q === 1 ? 8 : flies.length;
    c.globalCompositeOperation = 'lighter';
    for (let i = 0; i < n; i++) {
      const f = flies[i], x = 1 + (lx - 2) * (0.5 + 0.5 * Math.sin(T * f.sp * 0.7 + f.ph + f.x * 6)), y = 1 + (ly - 2) * (0.5 + 0.5 * Math.cos(T * f.sp * 0.6 + f.ph * 1.3 + f.y * 6));
      const p = P(x, y, 6 + 10 * (0.5 + 0.5 * Math.sin(T * f.sp * 2 + f.ph)));
      c.globalAlpha = k * (0.35 + 0.65 * Math.max(0, Math.sin(T * 2.2 * f.r + f.ph)));
      c.drawImage(A.glow('#d8ff8a'), p[0] - 5, p[1] - 5, 10, 10);
    }
    c.globalAlpha = 1; c.globalCompositeOperation = 'source-over';
  }

  /* ---------- sky shows: spotlights, meteors, lightning, rocket ---------- */
  let beam = null;
  function beamSprite() {
    if (beam) return beam;
    const k = document.createElement('canvas'); k.width = 48; k.height = 256;
    const g = k.getContext('2d'), gr = g.createLinearGradient(0, 256, 0, 0);
    gr.addColorStop(0, 'rgba(255,255,255,.9)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = gr; g.beginPath(); g.moveTo(21, 256); g.lineTo(27, 256); g.lineTo(48, 0); g.lineTo(0, 0); g.closePath(); g.fill();
    return (beam = k);
  }
  function spotlights(FR) {
    const s = G.state, hype = s ? Math.min(2, s.hype) : 0, boost = party > 0 ? 1 : 0;
    const k = Math.max(hype > 0.55 ? Math.min(1, (hype - 0.4) / 0.9) : 0, boost) * (0.3 + 0.7 * lit().night);
    if (k < 0.05 || FR.q === 0 || !FR.all) return;
    const hq = bigOf(FR, 'hq');
    if (!hq) return;
    const t = topOf(hq, 6), c = FR.c, spr = beamSprite();
    c.globalCompositeOperation = 'lighter';
    for (let i = 0; i < 2; i++) {
      const a = Math.sin(FR.T * 0.7 + i * 2.4) * 0.65 + (i ? 0.25 : -0.25);
      c.save(); c.translate(t[0], t[1]); c.rotate(a); c.globalAlpha = 0.17 * k;
      c.drawImage(spr, -24 * 2.2, -256 * 2.2, 48 * 2.2, 256 * 2.2);
      c.restore();
    }
    c.globalAlpha = 1; c.globalCompositeOperation = 'source-over';
  }
  let party = 0;
  L.party = function (secs) { party = Math.max(party, secs || 8); };

  const meteors = [];
  L.meteors = function (n) {
    const FR = S.ctx; if (!FR) return;
    for (let i = 0; i < n; i++) meteors.push({ at: i * 0.45 + rnd() * 0.4, x: FR.W * (0.2 + rnd() * 0.9), y: -20, vx: -(220 + rnd() * 160), vy: 130 + rnd() * 90, t: 0, ttl: 1.1 });
  };
  function drawMeteors(FR) {
    if (!meteors.length) return;
    const c = FR.c;
    c.globalCompositeOperation = 'lighter';
    for (let i = meteors.length - 1; i >= 0; i--) {
      const m = meteors[i];
      if (m.at > 0) { m.at -= FR.dt; continue; }
      m.t += FR.dt; m.x += m.vx * FR.dt; m.y += m.vy * FR.dt;
      if (m.t > m.ttl) { meteors.splice(i, 1); continue; }
      const a = Math.sin((m.t / m.ttl) * Math.PI), len = 0.16;
      const g = c.createLinearGradient(m.x - m.vx * len, m.y - m.vy * len, m.x, m.y);
      g.addColorStop(0, 'rgba(160,210,255,0)'); g.addColorStop(1, 'rgba(255,255,255,' + (0.95 * a) + ')');
      c.strokeStyle = g; c.lineWidth = 2; c.beginPath(); c.moveTo(m.x - m.vx * len, m.y - m.vy * len); c.lineTo(m.x, m.y); c.stroke();
      c.globalAlpha = a; c.drawImage(A.glow('#cfe8ff'), m.x - 7, m.y - 7, 14, 14); c.globalAlpha = 1;
    }
    c.globalCompositeOperation = 'source-over';
  }

  let bolt = null;
  L.lightning = function (kind) {
    const FR = S.ctx; if (!FR) return;
    const t = L.top(kind || 'pwr', 0, false) || L.top('hq', 0);
    if (!t) return;
    const pts = [[t[0] + (rnd() - 0.5) * 30, t[1] - 320]];
    for (let i = 1; i < 7; i++) pts.push([lerp(pts[0][0], t[0], i / 6) + (rnd() - 0.5) * 34, lerp(pts[0][1], t[1], i / 6)]);
    bolt = { pts, t: 0, x: t[0], y: t[1] };
    if (S.visible) { G.fx.shake(300); try { G.audio.sfx('zap'); } catch (e) { /* ignore */ } }
  };
  function drawBolt(FR) {
    if (!bolt) return;
    bolt.t += FR.dt;
    if (bolt.t > 0.7) { bolt = null; return; }
    const c = FR.c, flick = bolt.t < 0.12 || (bolt.t > 0.2 && bolt.t < 0.3) ? 1 : 0.35 * (1 - bolt.t / 0.7);
    c.globalCompositeOperation = 'lighter';
    c.strokeStyle = 'rgba(200,225,255,' + flick + ')'; c.lineWidth = 3; c.lineJoin = 'round';
    c.beginPath(); bolt.pts.forEach((p, i) => (i ? c.lineTo(p[0], p[1]) : c.moveTo(p[0], p[1]))); c.stroke();
    c.strokeStyle = 'rgba(255,255,255,' + flick + ')'; c.lineWidth = 1.2; c.stroke();
    c.globalAlpha = flick; c.drawImage(A.glow('#bcd8ff'), bolt.x - 40, bolt.y - 30, 80, 60);
    c.globalAlpha = 1; c.globalCompositeOperation = 'source-over'; c.lineJoin = 'miter';
  }

  let rocket = null;
  L.rocket = function () {
    const FR = S.ctx; if (!FR || !S.visible) return;
    const t = L.top('lab', 4) || L.top('hq', 4);
    if (!t) return;
    rocket = { x: t[0], y: t[1], x0: t[0], y0: t[1], t: 0, trail: [], burst: false };
    try { G.audio.sfx('whoosh'); } catch (e) { /* ignore */ }
  };
  function drawRocket(FR) {
    if (!rocket) return;
    const r = rocket, c = FR.c;
    r.t += FR.dt;
    const e = r.t * r.t * 0.5;   // accelerates
    r.x = r.x0 + Math.sin(r.t * 2) * 6 + e * 18; r.y = r.y0 - e * 150;
    r.trail.push([r.x, r.y + 8]); if (r.trail.length > 26) r.trail.shift();
    c.globalCompositeOperation = 'lighter';
    r.trail.forEach((p, i) => { const k = i / r.trail.length; c.globalAlpha = 0.5 * k; c.drawImage(A.glow(i % 2 ? '#ffd27a' : '#ff9a5a'), p[0] - 8 * k - 2, p[1] - 8 * k - 2, 16 * k + 4, 16 * k + 4); });
    c.globalAlpha = 0.9; c.drawImage(A.glow('#ffb35c'), r.x - 14, r.y + 2, 28, 28);
    c.globalCompositeOperation = 'source-over'; c.globalAlpha = 1;
    c.save(); c.translate(r.x, r.y); c.rotate(0.12);
    c.fillStyle = '#eef3ff'; c.beginPath(); c.moveTo(0, -14); c.quadraticCurveTo(6, -4, 4.5, 8); c.lineTo(-4.5, 8); c.quadraticCurveTo(-6, -4, 0, -14); c.fill();
    c.fillStyle = '#ff5d73'; c.beginPath(); c.moveTo(0, -14); c.quadraticCurveTo(3.4, -9, 3.8, -6); c.lineTo(-3.8, -6); c.quadraticCurveTo(-3.4, -9, 0, -14); c.fill();
    c.fillStyle = '#5b9bf2'; c.beginPath(); c.moveTo(-4.5, 3); c.lineTo(-9, 10); c.lineTo(-4.5, 8); c.closePath(); c.moveTo(4.5, 3); c.lineTo(9, 10); c.lineTo(4.5, 8); c.closePath(); c.fill();
    c.fillStyle = '#8af0e6'; c.beginPath(); c.arc(0, -3, 2, 0, TAU); c.fill();
    c.restore();
    if (!r.burst && r.t > 2.3) {
      r.burst = true;
      const w = winPos(FR, r.x, r.y);
      G.fx.firework(w[0], w[1], ['#ffd27a', '#fff3c4']); G.fx.ring(w[0], w[1], '#ffd27a', 90, 1);
      G.fx.show(5, 2.2); G.fx.confetti(70);
      G.sky.boost(10); party = Math.max(party, 10);
    }
    if (r.t > 3.4) rocket = null;
  }

  // a short cheer where something finished: sparks, a ring on the ground and a few coins
  L.cheer = function (kind, big) {
    const FR = S.ctx; if (!FR || !S.visible) return;
    const t = L.top(kind, 0); if (!t) return;
    const w = winPos(FR, t[0], t[1] + 10);
    G.fx.burst(w[0], w[1], ['#ffd27a', '#8af0e6', '#ffffff'], big ? 34 : 18, { speed: 130, size: 9 });
    G.fx.ring(w[0], w[1] + 10, '#8af0e6', big ? 80 : 50, 0.8);
    flashes.push({ x: t[0], y: t[1] + 20, t: 0, col: '#8af0e6', r: 30 });
  };
  L.coins = function (kind, n) {
    const FR = S.ctx; if (!FR || !S.visible) return;
    const t = L.top(kind || 'hq', 0); if (!t) return;
    const w = winPos(FR, t[0], t[1] + 14);
    G.fx.coin(w[0], w[1], n || 6, true);
  };

  /* ---------- layers ---------- */
  function actors(FR, dl) {
    buildNet(FR);
    const dt = FR.dt * speedK(), q = FR.q;
    if (!net.segs.length) return;
    // staff: more people as the company grows
    const staff = D.ladders.hq[G.state.inf.hq].staff, wantW = [2, Math.min(7, 2 + Math.round(staff / 10)), Math.min(11, 2 + Math.round(staff / 6))][q];
    while (walkers.length < wantW) walkers.push(newWalker());
    while (walkers.length > wantW) walkers.pop();
    const wantC = [1, 1 + Math.min(2, Math.floor(G.state.inf.dc / 2)), 1 + Math.min(3, Math.floor(G.state.inf.dc / 2) + 1)][q];
    let regular = 0; for (const k of cars) if (!k.vip) regular++;
    if (regular < wantC) cars.push(newCar(false));
    else if (regular > wantC) { const i = cars.findIndex((k) => !k.vip); if (i >= 0) cars.splice(i, 1); }
    for (const w of walkers) { stepWalker(w, dt); dl.push([depthAt(FR, w.x, w.y), 2, w.fn]); }
    for (let i = cars.length - 1; i >= 0; i--) { const k = cars[i]; stepCar(k, dt); if (k.done) { cars.splice(i, 1); continue; } dl.push([depthAt(FR, k.x, k.y), 2, k.fn]); }
    builders(FR, dl);
  }
  function air(FR) {
    stepOrbs(FR, FR.dt);
    stepDrones(FR, FR.dt);
    party = Math.max(0, party - FR.dt);
    spotlights(FR);
    fireflies(FR);
    drawOrbs(FR);
    drawDrones(FR);
    drawRocket(FR);
    drawBolt(FR);
  }
  function hudFlash(FR) {
    if (!bolt || bolt.t > 0.3) return;
    const c = FR.c, a = bolt.t < 0.1 ? 0.22 : 0.1 * (1 - bolt.t / 0.3);
    c.fillStyle = 'rgba(210,228,255,' + a + ')'; c.fillRect(0, 0, FR.W, FR.H);
  }
  S.use('sky', drawMeteors);
  S.use('back', drawShips);
  S.use('ground', ground);
  S.use('actors', actors);
  S.use('air', air);
  S.use('hud', hudFlash);

  /* ---------- what the game tells us ---------- */
  const mapKind = { hw: 'hw', rack: 'rack', contract: 'contract' };
  G.on('purchase', (p) => {
    if (!p || !mapKind[p.kind]) return;
    if (G.mute) return;
    L.drone(p.kind === 'contract' ? 'hq' : 'dc', KIND_COL[p.kind]);
  });
  G.on('ceo_do', (o) => { if (o && o.ok && o.plan && (o.plan.cat === 'servers')) L.drone('dc', KIND_COL.hw); });
  G.on('build_done', (b) => L.cheer(b.k, true));
  G.on('research_done', () => L.cheer('lab', false));
  G.on('train_done', () => L.cheer('lab', true));
  G.on('launch_done', () => setTimeout(() => L.rocket(), 350));
  G.on('rival', (r) => L.ship(r));
  L.reset = function () { walkers.length = cars.length = orbs.length = drones.length = crates.length = ships.length = 0; };
})();
