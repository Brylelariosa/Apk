package com.lumora.aiempire;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.view.DisplayCutout;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;

/**
 * AI Empire Tycoon - Android host.
 * The whole game is HTML/JS in assets/web. This class only provides a true edge-to-edge full-screen WebView
 * (it draws into the camera cutout and tells the page how big the safe area is),
 * safe native save files (atomic write + backup), a clipboard helper and a crash log that the
 * game can show on the next start (useful because crash logs are hard to read on a phone).
 */
public class MainActivity extends Activity {
    private static final int BG = 0xFF080D1B;
    private WebView web;
    private FrameLayout root;
    private final ArrayDeque<String> log = new ArrayDeque<String>();
    private long lastBack = 0;
    // display cutout insets in physical pixels (top, right, bottom, left)
    private volatile int insT = 0, insR = 0, insB = 0, insL = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        installCrashHandler();
        try {
            root = new FrameLayout(this);
            root.setBackgroundColor(BG);
            setContentView(root);
            applyCutoutMode();
            root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
                @Override
                public WindowInsets onApplyWindowInsets(View v, WindowInsets insets) {
                    readInsets(insets);
                    return insets;
                }
            });
            hideSystemUi();
            createWebView();
            root.requestApplyInsets();
        } catch (Throwable t) {
            showError(t);
        }
    }

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    private void createWebView() {
        web = new WebView(this);
        web.setBackgroundColor(BG);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setTextZoom(100);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setVerticalScrollBarEnabled(false);
        web.setHorizontalScrollBarEnabled(false);
        web.setLongClickable(false);
        web.setHapticFeedbackEnabled(false);
        web.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "NativeBridge");
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onConsoleMessage(ConsoleMessage m) {
                if (m.messageLevel() == ConsoleMessage.MessageLevel.ERROR || m.messageLevel() == ConsoleMessage.MessageLevel.WARNING) {
                    addLog(m.messageLevel() + " " + m.message() + " (" + m.sourceId() + ":" + m.lineNumber() + ")");
                }
                return true;
            }
        });
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                addLog("Render process gone. crashed=" + detail.didCrash());
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            root.removeAllViews();
                            web.destroy();
                            createWebView();
                        } catch (Throwable t) {
                            showError(t);
                        }
                    }
                });
                return true;
            }
        });
        root.addView(web, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        web.loadUrl("file:///android_asset/web/index.html");
    }

    /* ---------- JavaScript bridge ---------- */
    public class Bridge {
        @JavascriptInterface
        public void save(String data) {
            writeSave(data);
        }

        @JavascriptInterface
        public String load() {
            return readSave();
        }

        /** Safe-area insets in CSS pixels as "top,right,bottom,left" (the camera cutout). */
        @JavascriptInterface
        public String getInsets() {
            float d = getResources().getDisplayMetrics().density;
            if (d <= 0f) d = 1f;
            return (insT / d) + "," + (insR / d) + "," + (insB / d) + "," + (insL / d);
        }

        @JavascriptInterface
        public String getCrash() {
            return readFile(new File(getFilesDir(), "crash.txt"));
        }

        @JavascriptInterface
        public void clearCrash() {
            new File(getFilesDir(), "crash.txt").delete();
        }

        @JavascriptInterface
        public void copy(final String text) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("AI Empire Tycoon", text));
                    } catch (Throwable ignored) {
                        // clipboard is optional
                    }
                }
            });
        }

        @JavascriptInterface
        public String getLog() {
            synchronized (log) {
                StringBuilder sb = new StringBuilder();
                for (String l : log) sb.append(l).append('\n');
                return sb.toString();
            }
        }

        @JavascriptInterface
        public void logError(String message) {
            addLog("JS " + message);
        }
    }

    /* ---------- save files: atomic write with a backup copy ---------- */
    private synchronized void writeSave(String data) {
        try {
            File dir = getFilesDir();
            File tmp = new File(dir, "save.tmp");
            File cur = new File(dir, "save.json");
            File bak = new File(dir, "save.bak");
            FileOutputStream out = new FileOutputStream(tmp);
            try {
                out.write(data.getBytes(StandardCharsets.UTF_8));
                out.getFD().sync();
            } finally {
                out.close();
            }
            if (cur.exists()) {
                if (bak.exists()) bak.delete();
                cur.renameTo(bak);
            }
            if (!tmp.renameTo(cur)) {
                // last resort: copy the bytes over
                FileOutputStream o2 = new FileOutputStream(cur);
                try {
                    o2.write(data.getBytes(StandardCharsets.UTF_8));
                } finally {
                    o2.close();
                }
            }
        } catch (Throwable t) {
            addLog("save failed: " + t);
        }
    }

    private synchronized String readSave() {
        File dir = getFilesDir();
        String s = readFile(new File(dir, "save.json"));
        if (s.length() == 0) s = readFile(new File(dir, "save.bak"));
        return s;
    }

    private String readFile(File f) {
        if (!f.exists()) return "";
        FileInputStream in = null;
        try {
            in = new FileInputStream(f);
            byte[] buf = new byte[(int) f.length()];
            int off = 0;
            while (off < buf.length) {
                int n = in.read(buf, off, buf.length - off);
                if (n < 0) break;
                off += n;
            }
            return new String(buf, 0, off, StandardCharsets.UTF_8);
        } catch (Throwable t) {
            return "";
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (Throwable ignored) {
                    // nothing to do
                }
            }
        }
    }

    private void writeText(File f, String text) {
        try {
            FileOutputStream out = new FileOutputStream(f);
            try {
                out.write(text.getBytes(StandardCharsets.UTF_8));
            } finally {
                out.close();
            }
        } catch (Throwable ignored) {
            // best effort
        }
    }

    private void addLog(String line) {
        synchronized (log) {
            log.addLast(line);
            while (log.size() > 60) log.removeFirst();
        }
    }

    /* ---------- crash reporting ---------- */
    private void installCrashHandler() {
        final Thread.UncaughtExceptionHandler previous = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override
            public void uncaughtException(Thread t, Throwable e) {
                try {
                    StringWriter sw = new StringWriter();
                    e.printStackTrace(new PrintWriter(sw));
                    writeText(new File(getFilesDir(), "crash.txt"), "Thread " + t.getName() + "\n" + sw);
                } catch (Throwable ignored) {
                    // never throw from a crash handler
                }
                if (previous != null) previous.uncaughtException(t, e);
                else System.exit(2);
            }
        });
    }

    private void showError(Throwable t) {
        StringWriter sw = new StringWriter();
        t.printStackTrace(new PrintWriter(sw));
        TextView tv = new TextView(this);
        tv.setText("AI Empire Tycoon could not start\n\n" + sw);
        tv.setTextColor(0xFFE9EFFF);
        tv.setTextSize(12);
        tv.setPadding(32, 64, 32, 32);
        tv.setTextIsSelectable(true);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        sv.addView(tv);
        setContentView(sv);
    }

    /* ---------- window and lifecycle ---------- */

    /** Let the game draw behind the camera cutout so there is no black strip at the top of the screen. */
    private void applyCutoutMode() {
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            if (Build.VERSION.SDK_INT >= 30) {
                lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
            } else {
                lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            }
            getWindow().setAttributes(lp);
        }
    }

    /** Remember how much of each screen edge is covered by the camera cutout (system bars are hidden by immersive mode). */
    private void readInsets(WindowInsets wi) {
        int t = 0, r = 0, b = 0, l = 0;
        if (Build.VERSION.SDK_INT >= 28) {
            DisplayCutout dc = wi.getDisplayCutout();
            if (dc != null) {
                t = dc.getSafeInsetTop();
                r = dc.getSafeInsetRight();
                b = dc.getSafeInsetBottom();
                l = dc.getSafeInsetLeft();
            }
        }
        boolean changed = t != insT || r != insR || b != insB || l != insL;
        insT = t;
        insR = r;
        insB = b;
        insL = l;
        if (changed && web != null) {
            web.evaluateJavascript("window.__insets&&window.__insets()", null);
        }
    }

    @SuppressWarnings("deprecation")
    private void hideSystemUi() {
        Window w = getWindow();
        w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUi();
    }

    @Override
    protected void onPause() {
        if (web != null) {
            web.evaluateJavascript("window.__gamePause&&window.__gamePause()", null);
            web.onPause();
        }
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) {
            web.onResume();
            web.evaluateJavascript("window.__gameResume&&window.__gameResume()", null);
        }
        hideSystemUi();
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            try {
                root.removeAllViews();
                web.destroy();
            } catch (Throwable ignored) {
                // closing anyway
            }
            web = null;
        }
        super.onDestroy();
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        if (web == null) {
            super.onBackPressed();
            return;
        }
        web.evaluateJavascript("(window.G&&G.ui&&G.ui.back())?'1':'0'", new android.webkit.ValueCallback<String>() {
            @Override
            public void onReceiveValue(String value) {
                if (value != null && value.contains("1")) return;
                long now = System.currentTimeMillis();
                if (now - lastBack < 2000) {
                    finish();
                } else {
                    lastBack = now;
                    Toast.makeText(MainActivity.this, "Press back again to leave", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
