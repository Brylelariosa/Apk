# NovaEnhance AI

An offline, on-device AI photo enhancement app for Android. You teach the
model with your own low-quality/high-quality image pairs; it keeps improving
through real on-device training - no cloud, no accounts, no servers, no API
keys, and (deliberately) no TensorFlow or Python step required by anyone
building this project.

## What's actually running on-device

- **Inference & training**: a small residual CNN, entirely hand-written in
  C++ (`app/src/main/cpp/nn/network.cpp`) - forward pass, backward pass
  (backpropagation), and an Adam optimizer, all implemented from scratch. No
  TensorFlow, no TFLite, no ONNX Runtime, no bundled model asset, and no
  external generation step for anyone building this app: a fresh model is
  just `NativeNeuralEngine.TOTAL_PARAMS` randomly-initialized floats,
  created directly in Kotlin the first time the app runs (see
  `ai/model/ModelRepository.createModel`). "Training" is real gradient
  descent against your image pairs, not a simulated progress bar.
- **Correctness verification**: the hand-derived backward-pass math is
  checked against numerical (finite-difference) gradients before being
  trusted - see `tools/nn_verification/`. All checked gradients match
  analytically to within ~1e-5 relative error (effectively floating-point
  precision limits), which is the standard, rigorous way to confirm a
  backprop implementation is correct.
- **Classical image processing**: a separate native library doing
  tile-based Gaussian blur, edge-aware sharpening (a halo-free edge push plus a
  gated unsharp stage), compression-artifact removal (the Noise reduction
  slider), Lanczos upscaling, bilinear resize, and the synthetic degradations
  (noise/JPEG-blocking/motion-blur/color-fade) used by the automatic dataset
  generator. (The 5x5 bilateral denoise is still in the library but no longer
  used by the enhancement pipeline.)
- **Anti-forgetting**: experience replay (a curated buffer of past training
  pairs mixed into every new session) + L2-SP regularization (a penalty for
  drifting away from an anchored snapshot of pre-session weights, computed
  directly in `network.cpp`'s `trainStep`). Described honestly as replay +
  L2-SP, not as full Elastic Weight Consolidation, which would need
  Fisher-information machinery this project doesn't implement.
- **Adaptive training / self-improvement loop**: rule-based heuristics
  (batch size / learning rate / epochs derived from RAM, thermal state, and
  recent loss trends) and a weak-area rescoring pass after each promoted
  session - see `training/trainer/AdaptiveTrainingController.kt` and
  `SelfImprovementOrchestrator.kt` for exactly what each does and why.
  Thermal/RAM safety itself lives in one place, `utils/ThermalGovernor.kt`,
  and is re-checked continuously (not just once at session start) by every
  sustained-compute path that shares it: the training batch loop,
  validation, rescoring, AND a manual "Enhance" tap on a photo - see that
  file's doc comment for the graduated NONE/LIGHT (full speed) ->
  MODERATE (paced) -> SEVERE/CRITICAL (paused, or paced hard if the user
  disabled the hard pause) behavior.

## Before your first build

Nothing extra required. Unlike an earlier version of this project (which
used TensorFlow Lite's on-device training feature and needed a one-time
Python step to author the initial model graph), the app now creates its own
default model the first time it runs - no bundled asset, no Python, no
network access needed by the build pipeline or the app itself. If you're
looking at an old build log or an older copy of this README that mentions
`tools/model_builder/build_model.py` or a `.tflite` asset, that's the
previous architecture; it's gone.

## Build commands

```
./gradlew assembleDebug --no-daemon --configuration-cache --build-cache --parallel
./gradlew assembleRelease --no-daemon --configuration-cache --build-cache --parallel
```

Requires JDK 17, Gradle 8.6 (the CI workflow materializes the wrapper itself
- see the workflow file's comments for why a wrapper jar isn't hand-committed),
Android SDK, NDK 25.2.9519653, CMake 3.22.1. Release builds fall back to
debug signing if no `RELEASE_STORE_*` secrets/`app/keystore.properties` are
configured, so `assembleRelease` succeeds on a brand-new checkout with zero
manual setup - replace that with real signing before shipping to users.

## Testing

`app/src/test` has JVM unit tests for every piece of pure logic that doesn't
need a real Android framework/device (pixel-buffer padding/cropping, tensor
codec round-trips including a regression test for a rounding-bias fix, the
`.novamodel` bundle format, model metadata JSON round-tripping,
degradation-recipe range invariants, the bitmap-lifetime hold/retire
bookkeeping, the zoom/pan math, the auto-generate progress summaries, and the result-type helpers). Run them
with:

```
./gradlew testDebugUnitTest
```

The neural network's own correctness is verified separately, outside the
Android test framework entirely - see `tools/nn_verification/README.md`
(`tools/nn_verification/run_all.sh` builds and runs everything with plain
g++). The classical image filters have their own bit-exactness check against
the original implementation in `tools/filter_verification/`. The Lanczos upscaler
and edge-aware sharpener have theirs in `tools/upscale_verification/` (band
splits must be bit-identical, plus a naive double-precision reference), and so does the
artifact-removal filter in `tools/restore_verification/`. `tools/jni_crosscheck.py` compares
every Kotlin `external fun` with its C++ `Java_...` function (names, parameter and return types),
and `tools/quality_eval/` reproduces the before/after numbers quoted in this README.
That's deliberate: gradient checking needs double-precision arithmetic to
be trustworthy (see that README for why), which is a property of the
*verification* tooling, not something the production (float32, performance-
oriented) engine should carry.

Code that needs `android.graphics.Bitmap`, `Context`, or other
framework/device behavior (dataset analysis, the DAOs) is written to be
exercised by instrumented tests (`app/src/androidTest`) on a real
device/emulator - none are included yet, since I can't run an emulator in
the environment this was built in to verify them.

## Architecture

```
ui/            Jetpack Compose screens, ViewModels, navigation, theme;
               ui/components/zoom = reusable pinch-zoom/pan (math, state, gestures)
ai/
  engine/      NovaModelEngine (model state + checkpoint I/O), NativeNeuralEngine
               (JNI bridge to the C++ CNN), BandProcessor (seam-free band-by-band
               image processing), classical filters
  model/       Model metadata + registry/version repository
training/
  trainer/     Adaptive controller, experience replay, validator, the training
               orchestrator itself, and the self-improvement loop
  dataset/     Dataset analysis (dedup/quality/difficulty), degradation generator,
               dataset manager (add/remove/import/export, multi-photo auto-generate)
  checkpoint/  The .novamodel export/import bundle format
database/      Room entities/DAOs (model registry, versions, dataset, sessions,
               loss history, validation metrics, replay buffer)
storage/       Centralized file-path resolution + DataStore-backed settings
workers/       WorkManager (constraint scheduling) + the training foreground service
di/            Manual dependency-injection container (see ServiceLocator's doc
               comment for why this isn't Hilt)
```

`app/src/main/cpp` holds the native code: `nn/` is the from-scratch neural
network (NEON/portable SIMD kernels, fused streaming inference, parallel
training), `filters/` is the classical image-processing library, and `util/`
holds the shared worker thread pool. `tools/nn_verification/` and
`tools/filter_verification/` hold the (non-Android, standalone) correctness
checks for the native code.

## The network architecture

```
input (64x64x3, float32, [0,1])
  -> Conv 3x3, 3->48, ReLU
  -> Conv 3x3, 48->48, ReLU
  -> Conv 3x3, 48->48, ReLU
  -> Conv 3x3, 48->3            (near-zero init, see below)
  -> output = clip(input + conv4_out, 0, 1)     (global residual)
```

~44,211 parameters (widened from an original ~20,259 on 2026-09-06 - C1/C2
went 32->48 for more capacity headroom; see `network.h`'s dated comment).
Deliberately small: every layer's backward pass is hand-derived and
gradient-checked, and this runs on a phone CPU with cache-friendly
nested-loop convolution the compiler can auto-vectorize (no hand-written
SIMD intrinsics, no BLAS, no GPU delegate) - capacity is traded for being
small enough to verify correctly and fast enough to actually train in the
background. `conv2dForward`/`conv2dBackward` take Cin/Cout as arguments
rather than hardcoding them, so widening channels is a `network.h` constants
change, not new backward-pass math; adding another *layer* (depth, not
width) would be the real undertaking, since `inferForward`/`trainStep` call
each layer by hand in sequence rather than looping over a layer list. The
tail convolution is initialized with a very small standard deviation so a
fresh install "enhances" photos as an approximate no-op rather than emitting
random-noise garbage, visibly improving from there as the user trains it -
the same identity-at-init rationale as before, just implemented as a plain
`std::normal_distribution` call now instead of a Keras initializer.

## Performance and quality work for the Infinix HOT 11 (2022)

Target hardware: Unisoc T610 - 2x Cortex-A75 + 6x Cortex-A55 (all at 1.8 GHz,
ARMv8.2), 4 GB RAM, 5000 mAh, Android 11. The work below is about using all
eight cores well, keeping the working set inside the small caches of those
cores, and not waiting on I/O - and it is written so the same code also runs
well on other phones (it adapts to the core count and falls back to 32-bit
NEON or portable code).

**What was slow, and what changed**

| Before | Now |
|---|---|
| `NovaModelEngine.inferTile` took the engine mutex per tile, so tiles ran one at a time on ONE core however many were "in flight" | One native call per image band; a persistent thread pool hands out work one job at a time, so the fast A75 cores simply take more jobs than the A55 cores and nothing idles |
| Forward pass allocated ~6.5 MB of scratch per 64x64 tile and ran each layer over a whole-tile array (0.8 MB per layer, far beyond the A55's L2) | Fused streaming: each layer keeps only its 3 newest rows in a ring buffer (a few hundred KB working set per core), nothing is allocated per tile |
| Convolution = load-multiply-store per output channel (3 memory ops per FMA) | Register-blocked kernel: 4 pixels x 12 output channels held in registers for the whole 3x3x48 reduction, FMLA-by-lane (16 loads per 48 FMAs). AArch64 and ARMv7 NEON versions, portable fallback |
| Training step: single-threaded; also computed a gradient w.r.t. the input image that nothing used | Layer-synchronous forward/backward over (sample x 4-row band) jobs on the pool - scales even for batch 1; backward-data reuses the forward kernel with flipped weights; the unused input gradient is gone |
| 64x64 tiles with an 8 px feathered overlap: ~30% of all compute was redundant overlap, and every tile edge was computed from zero padding, then blended (visible grid seams) | Column strips with 4 px halos streamed over whole images: ~12% halo, and the result equals one fully-convolutional pass over the image - **no tile seams** |
| Bilateral denoise: 50 `exp()` calls per pixel (the next bottleneck once the network got fast); all filters single-threaded | Weight lookup tables, luma computed once, row-parallel: bit-identical output, ~6x faster on a single host core before threading |
| Training decoded 4 pairs x (2 bounds + 2 regions) per step, on the training thread, for ONE 64x64 patch each | A background loader prefetches the next batch, decodes one 256 px crop per pair and cuts 4 patches from it, each with a random rotation/mirror (applied identically to the degraded and clean patch) |
| Debug builds compiled the numeric code at `-O0` (AGP appends it after our flags) | `-O3` is forced for the native library in every build type |

**Thread budget** (`ComputeBudget`, then narrowed by `ThermalGovernor`): all
cores for interactive enhancement; cores minus two for background training
(six threads on this phone) so a plastic budget phone is not pinned at 100%
for the minutes a session lasts.

**Enhancement quality.** The seam fix above is the main change: band edges and
strip edges are computed from real neighbouring pixels, so the output no longer
has the faint grid pattern a tile-and-feather pass leaves. The classical
filters (artifact removal, sharpen) also run on bands with real context rows, so they
are seamless too. Training sees ~4x more patches per image pair per epoch,
with 8-way flip/rotate augmentation, for the same decode cost.

**What was measured, and what was not.** Measured on an x86 server core, one
thread, so NOT representative of a phone. With the host built to resemble
AArch64 (FMA, 128-bit vectors, 32 vector registers) the new code takes 9.5-9.8
ms per 64x64 tile of image area against 14.9-16.9 ms for the original (1.6x;
about 2.1x per image once the old tiles' 30% overlap is counted), and a
batch-4 training step takes 99-114 ms against 275-322 ms (2.8x). The inner loop
compiles to 46 FMAs per ~15 loads with no register spills - the structure
needed to approach peak throughput. On a plain SSE2 x86 build (no FMA-by-lane,
which is an ARM instruction) inference is only on par with the old code and the
training step ~2x faster: the portable backend is a correctness fallback, not a
fast path.

A big out-of-order x86 core with large caches hides most of what makes the old
code slow on an in-order Cortex-A55, and this host cannot show the effect of
removing the mutex serialization or of using eight cores, so **the gain on the
phone should be considerably larger than those figures - several-fold, and
plausibly around an order of magnitude for enhancement - but I could not
measure it.**
Everything NEON was exercised through an instruction-level emulation shim on
x86 (see `tools/nn_verification/neon_shim.h`), not on ARM silicon.

**Checking it on the phone (two minutes).** (1) The in-app debug info now
lists `Native kernels:` - it must say `neon-aarch64` (or `neon-armv7` on a
32-bit userland). `portable` means NEON was not compiled in and the speedup
will be much smaller. (2) Enhance a photo and look in Logcat for the
`EnhancementEngine` line, e.g. `AI pass 4208x3120 done in ... ms`, and the
`BandProcessor` line next to it.

## Upscaling and sharpening

**What the 2x/4x buttons do.** The neural network runs at the photo's own resolution
(it restores - denoise, de-blocking, mild sharpening - it does not enlarge), and the
enlargement afterwards is classical. Until build 9 that enlargement was
`Bitmap.createScaledBitmap` (bilinear) followed by a plain unsharp mask. Bilinear turns
every edge into a soft ramp, and no sharpening filter can fully undo that; the unsharp mask
also boosted compression noise in flat areas and left halos next to strong edges. On
manga/webtoon panels - thin black lines on flat colour, usually saved as lossy WebP/JPEG -
that is exactly what looked soft and "plasticky".

**What it does now** (`filters/upscale.{h,cpp}`, driven by `ai/engine/UpscaleStage.kt`):

1. *Lanczos-3 resampling*, separable, computed natively in bands of the OUTPUT image straight
   into the destination bitmap (no `int[]` round trip, bounded scratch memory). Since build 11
   every sample is also clamped to the range of the 2x2 source pixels around it, which removes
   the ringing Lanczos puts next to hard edges and nothing else.
2. *Edge push* (build 11), at the final resolution: a halo-free restorer for blurred edges - see
   "Cleaner results (build 11)" below.
3. *Edge-aware unsharp stage*, once, at the final resolution: the detail signal is measured on
   luma only, multiplied by a gate that stays closed on flat/noisy areas and opens on real
   edges (smoothstep of the Sobel gradient), and the result is clamped to the local min/max
   so no halos can appear (since build 11 strictly - the old 5-8% overshoot is gone). The
   Sharpness slider scales its gain. The same two stages replace the plain unsharp mask on the 1x path.
4. *A size cap* (`UpscalePlan`): Android refuses to draw any bitmap over 100 MB, so the
   factor steps down for big photos (a 512x658 panel keeps 4x, a 1080p frame gets 3x, a 12 MP
   camera photo stays 1x) instead of crashing the preview.

Measured with the shipped C++ code, downscale -> upscale -> compare with the original
(PSNR dB / SSIM, same slider position for both pipelines; higher is better):

| test image, factor, Sharpness | old | new |
|---|---|---|
| manga panel, 2x, 0.3 | 25.56 / 0.910 | 27.32 / 0.929 |
| manga panel, 2x, 1.0 | 25.12 / 0.910 | 27.03 / 0.930 |
| manga panel, 4x, 0.3 | 20.14 / 0.760 | 21.11 / 0.782 |
| manga panel, 4x, 1.0 | 20.14 / 0.768 | 21.23 / 0.791 |
| photo (astronaut), 4x, 1.0 | 24.71 / 0.842 | 25.85 / 0.863 |
| photo (cat), 4x, 1.0 | 29.25 / 0.822 | 30.23 / 0.820 |

It wins on both metrics in 11 of the 12 combinations measured; the one exception (the cat
photo at 4x, Sharpness 1.0) is a tie on SSIM and still +1 dB PSNR. These are proxies - the
real judge is looking at the result - and the "ground truth" for the manga panel is itself a
compressed 512 px image.

**What this cannot do.** Nothing classical invents detail that is not in the source. A
4x enlargement of a 512 px panel is a clean, crisp 4x enlargement, not a re-drawn
high-resolution panel; that needs a learned super-resolution model far larger than the
~44K-parameter network here (a 9x9-pixel receptive field), and training this one longer
does not change that.

**Should you keep training?** It helps the part of the pipeline that is learned: removing
JPEG/WebP blocking and noise. Three things decide whether it helps: (1) *how many pairs* -
the in-app debug log shows training on only a handful (3 pairs analysed); with so few,
extra sessions mostly memorise those images, so add dozens of varied pairs (clean source
images are enough - the app degrades them itself); (2) *variety* - include the kind of
panels you actually enhance; (3) *whether validation improves* - when a session is not
promoted, more of the same data will not change that. The classical stages above need no
training at all and work with every existing checkpoint.

**Multi-select.** "Select Images" opens the system photo picker with multi-selection. One
photo behaves as before; with several, a thumbnail strip appears (tap one to preview and
tune it) and "Enhance & save all" runs every photo, one at a time, with the current
settings, saving each result to the Gallery the moment it is done (`BatchEnhancer`). One
photo is decoded, enhanced, saved and freed before the next starts, so memory stays at one
photo whatever the batch size; a photo that fails is reported and skipped; Cancel keeps
everything already saved.

**Zoom.** The before/after preview (also the full-screen compare view in the Dataset Manager)
zooms: pinch, drag to pan, double-tap to step in (4x, 12x, 32x, as far as the photo allows) and
back out; the pill at the bottom shows the zoom and resets it. The limit is the depth at which one
pixel of the sharper image is 12 screen pixels wide (never below 16x, never above 80x), so a 12 MP
photo goes to about 49x. Beyond 3 screen pixels per image pixel the pixels are drawn crisp instead
of smoothed, so you judge the real detail rather than an interpolation of it. "Before" and "after"
share one transform, so the wipe compares the same spot at any depth; while zoomed, the divider is
moved by dragging its line or handle (a touch anywhere else pans). The zoom belongs to the photo:
changing a slider re-enhances it but keeps the zoom, so the effect can be judged at the same spot.
The math (`ZoomMath`), the state (`ZoomPanState`), the gesture loop (`detectZoomGestures`) and the
pill (`ZoomBadge`) live in `ui/components/zoom` and know nothing about before/after images.

**Auto-generate from several photos.** "Auto-Generate" in the Dataset Manager opens the photo
picker with multi-selection. Each photo yields 3 degraded copies (`DEFAULT_SYNTHETIC_VARIANTS`);
photos are processed one at a time (`DatasetManager.addSyntheticPairsFromPhotos`), so memory stays
at one photo whatever the selection size, and the pairs appear in the list as they are made. A
progress panel shows "photo X of N", and Cancel stops after the photo in progress (a pair is never
left half-made; everything finished is kept). A photo that cannot be read is skipped and counted in
the summary line. Each photo is decoded upright and capped at 24 MP like in Enhance, and its
high-quality JPEG is encoded once and copied to each variant instead of re-encoded per variant.

## Cleaner results (build 11)

**Why this build exists.** Before/after screenshots of a compressed webtoon panel showed an "after" that was only a
little better than the "before". The reason is structural: the network is a ~44K-parameter, 9x9-receptive-field
model that starts out close to an identity, so what you see right after install is the *classical* stages, and on lossy
line art those had three weak spots:

1. *Colour blotches and mosquito noise survived.* Lossy JPEG/WebP stores colour at half resolution and quantises it
   hard, leaving mottled patches 8-16 px across and faint ripples beside every sharp line. A 5x5 bilateral filter
   (and a larger range sigma only blurs detail) is far smaller than the damage.
2. *Every strong line got a halo.* An unsharp mask can only ADD contrast around an edge, so a white outline on a grey
   background came out with a dark band beside it (visible in the screenshots).
3. *Upscaling rang.* Lanczos-3 overshoots beside hard edges; the unsharp mask then sharpened the ringing.

**Artifact removal** (`filters/restore.{h,cpp}`, the **Noise reduction** slider). The picture is converted to
YCbCr and filtered by a separable joint bilateral filter (17 taps per axis, so 8 context rows). The chroma planes are
averaged widely but only with pixels that look alike in luma AND colour: blotches melt away, while a line or a real
colour boundary stops the averaging, so colour never bleeds. The luma plane is averaged only with near-identical
pixels, which flattens the ripples and leaves every genuine edge alone. The slider value is the filter strength.
It runs before any upscaling, where the damage is still small. A flat colour stays exactly flat, a hard edge
stays within 1 level, and bands carrying `restoreReachRows()` context rows reproduce a whole-image pass bit for bit
(`tools/restore_verification`).

**Edge push** (`edgePush` in `filters/upscale.cpp`, the **Sharpness** slider). For each pixel on a blurred step edge it
finds the edge direction (a Sobel gradient of lightly blurred luma, one of 8 directions), averages the colour of 3
pixels on the lighter side and 3 on the darker side, works out where the pixel sits on the ramp between them, and moves
it towards the near side with a steep S-curve. The target is always a blend of two colours that already sit next to the
pixel, so **no value can overshoot - there is no halo by construction**, and since colour moves as a whole there are no
colour fringes either. Flat areas, low-level noise (the gradient gate stays closed) and "edges" whose two sides differ
by under 8 levels are copied unchanged. The Sharpness slider sets the push strength (`min(1, 1.6 x slider)`) and the
now strictly halo-clamped unsharp stage (`1.5 x slider^2` at 1x, `1.5 x slider` after an upscale).

**Measured** with the shipped C++ code (`tools/quality_eval/run.sh`): a synthetic webtoon-like panel (flat colours, thick
and thin outlines, a white outline on a dark gradient, low-contrast blush strokes) and three photos, degraded
(blur, resample, JPEG q20-35 with 4:2:0 chroma) and compared with the clean original. PSNR dB / SSIM, higher is better:

| Noise reduction / Sharpness | line art, build 10 | line art, build 11 | photos, build 10 | photos, build 11 |
|---|---|---|---|---|
| 0.3 / 0.3 (defaults) | 28.21 / 0.9492 | 29.27 / 0.9618 | 30.77 / 0.8758 | 30.55 / 0.8803 |
| 0.3 / 0.6 | 28.76 / 0.9537 | 30.30 / 0.9715 | 30.41 / 0.8743 | 28.61 / 0.8635 |
| 1.0 / 1.0 | 28.63 / 0.9520 | 29.29 / 0.9669 | 30.07 / 0.8602 | 27.95 / 0.8314 |

Halo energy (luma excursion beyond the true local range) is 14% lower and colour error 10% lower on line art at the
defaults. After upscaling (build-10 upscaler vs build 11, measured once with the build-10 binary against a
high-resolution original): +0.4 to +0.8 dB at the default and mid slider, -0.15 to +0.17 dB at Sharpness 1.0, SSIM unchanged
within +-0.001, halo energy about 14% lower - upscaling mostly gets cleaner edges, the big gain is the 1x cleaning.

**What this does not do.** The edge push is made for line art, where nearly every edge really is a blurred step. On
*photos* it behaves like a strong sharpener: at the defaults they are about where they were, but Sharpness above ~0.5 costs
PSNR (a photo's soft edges and texture are not steps) and gives a slightly painted look. Several ways of making the push
back off automatically in photo-like regions (flatness of the two sides, texture density) were tried; none separated
the two kinds of image without also removing the line-art gain, so the slider stays the control. And as before,
nothing classical invents detail that is not in the source.

## Honest limitations

- This was built without the ability to run an actual Android/Gradle build
  end-to-end - there's no Android SDK, emulator, or network access in the
  environment it was written in. What COULD be verified, was: the C++ math
  (compiled and gradient-checked standalone with plain g++, independent of
  Android), and static consistency checks (JNI method names, parameter and
  return types matching exactly between Kotlin and C++ - `tools/jni_crosscheck.py` -,
  package declarations matching directory structure, import resolution, dependency
  injection wiring). The build-11 Kotlin edits were not compiled at all (no
  kotlinc here); the native code behind them is verified on the host. "The CI badge
  is green" is still the actual end-to-end verification step.
- The four validation metrics (detail recovery, noise reduction, sharpness
  improvement, artifact removal) are deliberately simple, explainable
  proxies (PSNR, a Laplacian-based sharpness/noise estimate, a block-edge
  gradient ratio) - not a claim of research-grade no-reference image quality
  assessment, which remains an open problem.
- The NEON code (and the multi-threaded paths) have only been run on x86:
  the SIMD layer (`nn/simd.h`) is compiled against an emulation of the NEON
  intrinsics it uses (AArch64 and ARMv7 flavours), AND against the portable
  fallback, and every flavour matches the original scalar implementation
  (forward pass, gradients, a 25-step Adam trajectory, whole-image inference
  versus a naive double-precision convolution) and passes AddressSanitizer,
  UBSan and ThreadSanitizer. That validates the algorithm, indexing and the
  wrappers' semantics; it does not validate real ARM compilation (no NDK in
  the environment this was written in), instruction scheduling on a Cortex-A55,
  or real-world speed. There is still no INT8/FP16 path.
- Multi-threaded training sums per-thread gradient partial sums in a
  scheduling-dependent order, so two runs differ at float rounding level
  (`threads = 1` is bit-exact repeatable). Loss, gradients and the resulting
  weights match the original implementation to within ~1e-4 relative.
- The native upscaler/sharpener was compiled and run on x86 only (band-split
  bit-exactness, a naive double-precision reference, ASan/UBSan); the JNI wrappers
  were syntax-checked against stub headers, not built with the NDK. The Kotlin that
  drives it, and the multi-select UI, were not compiled here.
- The Kotlin changes (band pipeline, patch loader, JNI bridge, compute
  budget) could not be compiled here either: they were checked by reading,
  by a bracket/identifier consistency pass, and by running the equivalent
  algorithms (the rotation/mirror math, the band/halo arithmetic) in
  independent form. Expect to need to fix a compile error or two, if any, on
  the first Gradle build.
