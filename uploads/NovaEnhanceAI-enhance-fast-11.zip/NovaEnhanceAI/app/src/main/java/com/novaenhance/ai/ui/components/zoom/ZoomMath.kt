package com.novaenhance.ai.ui.components.zoom

/**
 * The arithmetic behind pinch-zoom and pan, kept free of Compose and Android types so it can be unit-tested on the JVM
 * (see ZoomMathTest).
 *
 * The model: content is laid out once at "scale 1" (already fitted and centred in the viewport), then magnified by
 * `scale` about the viewport's centre and shifted by an `offset`. A coordinate `p` of the unmagnified layout therefore
 * lands at [toScreen]:
 *
 *     centre + (p - centre) * scale + offset
 *
 * Every function here works on a single axis; callers apply it to x and to y.
 */
object ZoomMath {

    /** No magnification: the content fits the viewport. */
    const val MIN_SCALE = 1f

    /** From here up the view counts as "zoomed in": a touch away from the divider pans instead of moving the divider. */
    const val ZOOMED_THRESHOLD = 1.05f

    /**
     * "Very zoomed in" means seeing individual pixels, so the zoom limit is the one at which a pixel of the sharper
     * image is this many screen pixels wide...
     */
    const val TARGET_PIXEL_SIZE = 12f

    /** ...but never lower than this, so even a small image can be inspected closely... */
    const val MAX_SCALE_FLOOR = 16f

    /** ...and never higher than this, so a huge image can't be zoomed into a view that is only a handful of pixels. */
    const val MAX_SCALE_CEILING = 80f

    /** Zoom levels a double-tap steps through (each only if the zoom limit allows it) before returning to fit. */
    private val DOUBLE_TAP_STEPS = floatArrayOf(4f, 12f, 32f)

    /** A double-tap only counts a step as "next" if it is at least this much further in than where the view is now. */
    private const val DOUBLE_TAP_MIN_STEP_RATIO = 1.25f

    /**
     * The zoom limit for content whose sharper image shows one of its pixels as [fitScreenPxPerImagePx] screen pixels
     * when fitted (that is `fitted width / image width`, the smaller of the compared images' values).
     */
    fun maxScale(fitScreenPxPerImagePx: Float): Float {
        if (fitScreenPxPerImagePx.isNaN() || fitScreenPxPerImagePx <= 0f) return MAX_SCALE_FLOOR
        return (TARGET_PIXEL_SIZE / fitScreenPxPerImagePx).coerceIn(MAX_SCALE_FLOOR, MAX_SCALE_CEILING)
    }

    /** [scale] limited to the range the view can actually show. */
    fun clampScale(scale: Float, maxScale: Float): Float =
        scale.coerceIn(MIN_SCALE, maxOf(MIN_SCALE, maxScale))

    /**
     * [offset] limited so the magnified content ([content] * [scale] long) still covers the [viewport] on this axis,
     * or exactly centred (offset 0) when it is smaller than the viewport.
     */
    fun clampOffset(offset: Float, viewport: Float, content: Float, scale: Float): Float {
        val overflow = (content * scale - viewport) / 2f
        return if (overflow <= 0f) 0f else offset.coerceIn(-overflow, overflow)
    }

    /** Where the unmagnified layout coordinate [layoutCoordinate] ends up on screen at [scale] and [offset]. */
    fun toScreen(layoutCoordinate: Float, viewport: Float, scale: Float, offset: Float): Float {
        val centre = viewport / 2f
        return centre + (layoutCoordinate - centre) * scale + offset
    }

    /**
     * The offset after one pinch/pan step: the content point that was under [from] (a viewport coordinate, the fingers'
     * centre before the step) ends up under [to] (their centre after it) once the scale has gone from [oldScale] to
     * [newScale]. A pure zoom about a fixed point passes the same coordinate for both; a pure pan has equal scales.
     */
    fun offsetFollowing(from: Float, to: Float, viewport: Float, oldOffset: Float, oldScale: Float, newScale: Float): Float {
        val centre = viewport / 2f
        return (to - centre) - (from - centre - oldOffset) * (newScale / oldScale)
    }

    /** The zoom a double-tap goes to from [current], or null when it should return to fit instead. */
    fun nextDoubleTapScale(current: Float, maxScale: Float): Float? =
        DOUBLE_TAP_STEPS.firstOrNull { it > current * DOUBLE_TAP_MIN_STEP_RATIO && it <= maxScale }
}
