package com.novaenhance.ai.ui.screens

import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.res.painterResource
import com.novaenhance.ai.R
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.IconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.novaenhance.ai.ui.components.BatchRunPanel
import com.novaenhance.ai.ui.components.BatchThumbnailStrip
import com.novaenhance.ai.ui.components.BeforeAfterSlider
import com.novaenhance.ai.ui.components.LabeledSlider
import com.novaenhance.ai.ui.viewmodel.EnhanceViewModel
import com.novaenhance.ai.ui.viewmodel.NovaViewModelFactory
import java.io.File

@Composable
fun EnhanceScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val viewModel: EnhanceViewModel = viewModel(factory = NovaViewModelFactory(context))
    val state by viewModel.uiState.collectAsState()
    val batch by viewModel.batchState.collectAsState()

    LaunchedEffect(state.savedUri) {
        if (state.savedUri != null) {
            Toast.makeText(context, "Saved to your Gallery", Toast.LENGTH_SHORT).show()
        }
    }

    // Multi-select: the system photo picker lets the user tick several photos at once (Android falls back to the
    // document picker, which also allows multiple selection, where the photo picker isn't available). One photo
    // behaves exactly as before; several enable the thumbnail strip and "Enhance & save all" below.
    val pickImagesLauncher = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia()) { uris ->
        if (uris.isNotEmpty()) viewModel.onImagesSelected(uris)
    }
    val launchImagePicker = {
        pickImagesLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }

    var pendingCaptureFile by remember { mutableStateOf<File?>(null) }
    val captureLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        if (success) {
            pendingCaptureFile?.let { file ->
                val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                viewModel.onImageSelected(uri)
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Enhance Image") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(painterResource(R.drawable.ic_back_arrow), contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (state.originalBitmap == null) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(onClick = { launchImagePicker() }, modifier = Modifier.fillMaxWidth()) {
                        Text("Select Images")
                    }
                    OutlinedButton(
                        onClick = {
                            val file = File(context.cacheDir, "capture_${System.currentTimeMillis()}.jpg")
                            pendingCaptureFile = file
                            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                            captureLauncher.launch(uri)
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Capture Image")
                    }
                }
            } else {
                Box(modifier = Modifier.fillMaxWidth().height(360.dp)) {
                    if (state.enhancedBitmap != null) {
                        BeforeAfterSlider(
                            original = state.originalBitmap!!,
                            enhanced = state.enhancedBitmap!!,
                            modifier = Modifier.fillMaxSize(),
                            onOriginalDisplayChanged = viewModel::onBitmapDisplayChanged,
                            onEnhancedDisplayChanged = viewModel::onBitmapDisplayChanged
                        )
                    }
                    if (state.isProcessing) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(progress = { state.progressFraction })
                        }
                    }
                }
                if (state.enhancedBitmap != null) {
                    Text(
                        "Pinch or double-tap to zoom in, drag the divider to compare",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                if (batch.isBatch) {
                    Text(
                        "Photo ${batch.activeIndex + 1} of ${batch.items.size} - tap a photo to preview it",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    BatchThumbnailStrip(
                        items = batch.items,
                        activeIndex = batch.activeIndex,
                        enabled = !batch.isRunning,
                        onSelect = viewModel::selectBatchItem
                    )
                }
                OutlinedButton(
                    onClick = { launchImagePicker() },
                    enabled = !batch.isRunning,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(if (batch.isBatch) "Choose different photos" else "Choose other photos")
                }

                if (state.activeModelTrainingSessionCount == 0 && state.enhancedBitmap != null) {
                    Text(
                        "This model hasn't been trained yet, so the AI pass above is an " +
                            "intentional near-no-op - what you're seeing is mostly the classical " +
                            "sharpen/denoise/color controls below. Train it in Train AI to see " +
                            "real learned enhancement.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }

                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    LabeledSlider("Enhancement strength", state.options.strength, enabled = !batch.isRunning) {
                        viewModel.onOptionsChanged(state.options.copy(strength = it))
                    }
                    LabeledSlider("Sharpness", state.options.sharpness, enabled = !batch.isRunning) {
                        viewModel.onOptionsChanged(state.options.copy(sharpness = it))
                    }
                    LabeledSlider("Noise reduction", state.options.noiseReduction, enabled = !batch.isRunning) {
                        viewModel.onOptionsChanged(state.options.copy(noiseReduction = it))
                    }
                    LabeledSlider("Color restoration", state.options.colorRestoration, enabled = !batch.isRunning) {
                        viewModel.onOptionsChanged(state.options.copy(colorRestoration = it))
                    }
                    Text("Upscaling", style = MaterialTheme.typography.bodyMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(1, 2, 4).forEach { factor ->
                            val selected = state.options.upscaleFactor == factor
                            OutlinedButton(
                                onClick = { viewModel.onOptionsChanged(state.options.copy(upscaleFactor = factor)) },
                                enabled = !batch.isRunning
                            ) {
                                Text(if (selected) "[${factor}x]" else "${factor}x")
                            }
                        }
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { viewModel.saveResult() },
                        modifier = Modifier.weight(1f),
                        enabled = !state.isSaving
                    ) {
                        if (state.isSaving) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                strokeWidth = 2.dp,
                                color = MaterialTheme.colorScheme.onPrimary
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Saving…")
                        } else {
                            Text(if (state.savedUri != null) "Saved" else "Save")
                        }
                    }
                    OutlinedButton(
                        onClick = {
                            state.savedUri?.let { uri ->
                                val intent = Intent(Intent.ACTION_SEND).apply {
                                    type = "image/jpeg"
                                    putExtra(Intent.EXTRA_STREAM, uri)
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                context.startActivity(Intent.createChooser(intent, "Share enhanced image"))
                            }
                        },
                        enabled = state.savedUri != null,
                        modifier = Modifier.weight(1f)
                    ) { Text("Share") }
                }

                if (batch.isBatch) {
                    BatchRunPanel(
                        batch = batch,
                        onEnhanceAll = viewModel::enhanceAndSaveAll,
                        onCancel = viewModel::cancelBatch
                    )
                }
            }

            state.errorMessage?.let {
                Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}
