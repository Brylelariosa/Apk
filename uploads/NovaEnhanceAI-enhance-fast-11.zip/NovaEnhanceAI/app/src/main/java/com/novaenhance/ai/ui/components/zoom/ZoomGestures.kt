package com.novaenhance.ai.ui.components.zoom

import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculateCentroidSize
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.isSpecified
import androidx.compose.ui.input.pointer.PointerInputChange
import androidx.compose.ui.input.pointer.PointerInputScope
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.coroutineScope
import kotlin.math.abs

/** A second tap within this distance of the first still counts as a double-tap. */
private val DoubleTapRadius = 48.dp

private const val NO_TAP = Long.MIN_VALUE

/**
 * Pinch to zoom, drag to pan, double-tap to step in and back out - all driving [state].
 *
 * One gesture loop does all of it, rather than stacking detectTransformGestures and detectTapGestures: two detectors on
 * the same node compete for the same pointer events (the tap detector consumes the touch the transform detector
 * needs), and a single loop is the only place that can decide, per touch, what a ONE-finger drag means.
 *
 * A one-finger drag normally pans. The owner of the content may claim it instead - [claimsDragAt] is asked once, when a
 * finger goes down, and a "yes" routes that drag to [onClaimedDrag] (with the finger's position) for as long as it is
 * the only finger. BeforeAfterSlider claims every drag while not zoomed (the drag moves its divider, as it always did)
 * and, once zoomed, only drags that start on the divider. A second finger always turns the gesture into a pinch.
 *
 * Motion is ignored until it passes the touch slop, so a tap or a slightly shaky press neither pans nor zooms, and
 * once it counts the touch is consumed so a scrolling parent does not also react to it.
 *
 * @param boundsFor builds the current [ZoomBounds] for a viewport of the given size (read fresh on every use, so the
 *   content may change while the pointer input stays installed).
 */
suspend fun PointerInputScope.detectZoomGestures(
    state: ZoomPanState,
    boundsFor: (viewport: Size) -> ZoomBounds,
    claimsDragAt: (down: Offset) -> Boolean = { false },
    onClaimedDrag: (position: Offset) -> Unit = {}
) {
    coroutineScope {
        val scope = this
        val doubleTapRadiusPx = DoubleTapRadius.toPx()
        var previousTapUptime = NO_TAP
        var previousTapPosition = Offset.Zero

        awaitEachGesture {
            val down = awaitFirstDown()
            state.stopAnimation() // touching the view takes over from a running double-tap / reset animation

            val viewport = Size(size.width.toFloat(), size.height.toFloat())
            val touchSlop = viewConfiguration.touchSlop
            var claimed = claimsDragAt(down.position)
            var pastSlop = false
            var multiTouch = false
            var cancelled = false
            var zoomSinceDown = 1f
            var panSinceDown = Offset.Zero
            var last: PointerInputChange = down

            do {
                val event = awaitPointerEvent()
                if (event.changes.any { it.isConsumed }) {
                    cancelled = true // somebody else (a child, a scrolling parent) took this touch
                } else {
                    if (event.changes.count { it.pressed } > 1) {
                        multiTouch = true
                        claimed = false
                    }
                    val zoomChange = event.calculateZoom()
                    val panChange = event.calculatePan()

                    if (!pastSlop) {
                        zoomSinceDown *= zoomChange
                        panSinceDown += panChange
                        val spread = event.calculateCentroidSize(useCurrent = false)
                        if (abs(1f - zoomSinceDown) * spread > touchSlop || panSinceDown.getDistance() > touchSlop) {
                            pastSlop = true
                        }
                    }

                    if (pastSlop) {
                        if (claimed) {
                            event.changes.firstOrNull { it.pressed }?.let { onClaimedDrag(it.position) }
                        } else {
                            val previousCentroid = event.calculateCentroid(useCurrent = false)
                            if (previousCentroid.isSpecified && (zoomChange != 1f || panChange != Offset.Zero)) {
                                state.applyGesture(boundsFor(viewport), previousCentroid, panChange, zoomChange)
                            }
                        }
                        event.changes.forEach { if (it.positionChanged()) it.consume() }
                    }
                    last = event.changes.firstOrNull { it.id == down.id } ?: last
                }
            } while (!cancelled && event.changes.any { it.pressed })

            // A quick press-and-release that never moved is a tap; two of them close together are a double-tap.
            val isTap = !cancelled && !pastSlop && !multiTouch &&
                last.uptimeMillis - down.uptimeMillis < viewConfiguration.longPressTimeoutMillis
            if (!isTap) return@awaitEachGesture

            val isDoubleTap = previousTapUptime != NO_TAP &&
                down.uptimeMillis - previousTapUptime < viewConfiguration.doubleTapTimeoutMillis &&
                (down.position - previousTapPosition).getDistance() < doubleTapRadiusPx
            if (isDoubleTap) {
                previousTapUptime = NO_TAP // a third tap starts a new pair instead of chaining
                state.animateDoubleTap(scope, boundsFor(viewport), last.position)
            } else {
                previousTapUptime = last.uptimeMillis
                previousTapPosition = last.position
            }
        }
    }
}
