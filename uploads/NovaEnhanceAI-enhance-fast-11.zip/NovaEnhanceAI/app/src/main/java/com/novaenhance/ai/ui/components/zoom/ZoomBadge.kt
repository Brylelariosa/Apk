package com.novaenhance.ai.ui.components.zoom

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val BadgeShape = RoundedCornerShape(50)

/**
 * A small pill showing how far in a [ZoomPanState] is, which doubles as the way back out: tap it to animate to fit.
 * Shown only while zoomed in.
 *
 * Self-contained on purpose: it reads the zoom state itself, through derivedStateOf, so only this pill recomposes while
 * the user pinches - the composable that hosts the zoomed content stays untouched (see BeforeAfterSlider for why that
 * one must not be recomposed needlessly).
 */
@Composable
fun ZoomBadge(state: ZoomPanState, modifier: Modifier = Modifier) {
    val zoomed by remember(state) { derivedStateOf { state.isZoomed } }
    if (zoomed) {
        val label by remember(state) { derivedStateOf { formatZoom(state.scale) } }
        val scope = rememberCoroutineScope()
        Surface(
            modifier = modifier
                .clip(BadgeShape)
                .clickable(onClickLabel = "Reset zoom") { state.animateReset(scope) },
            shape = BadgeShape,
            color = Color.Black.copy(alpha = 0.6f)
        ) {
            Text(
                text = "$label - tap to reset",
                color = Color.White,
                style = MaterialTheme.typography.labelMedium,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
            )
        }
    }
}

/** "12.4x": one decimal is enough resolution to see a pinch is working, without the label flickering. */
internal fun formatZoom(scale: Float): String = "%.1fx".format(scale)
