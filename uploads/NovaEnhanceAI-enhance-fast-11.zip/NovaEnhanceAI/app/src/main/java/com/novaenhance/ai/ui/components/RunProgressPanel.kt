package com.novaenhance.ai.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/**
 * Progress for a long-running job: a title line, a progress bar, an optional smaller [detail] line and, if the job can
 * be stopped, a Cancel button.
 *
 * @param fraction 0..1, or null for "working, no idea how far" (an indeterminate bar).
 * @param onCancel the Cancel action, or null when the job can't usefully be stopped (no button is shown then).
 * @param cancelEnabled false once a cancel has been requested but the job is still winding down.
 */
@Composable
fun RunProgressPanel(
    title: String,
    fraction: Float?,
    modifier: Modifier = Modifier,
    detail: String? = null,
    onCancel: (() -> Unit)? = null,
    cancelEnabled: Boolean = true
) {
    Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, style = MaterialTheme.typography.bodyMedium)
        if (fraction == null) {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
        } else {
            LinearProgressIndicator(progress = { fraction }, modifier = Modifier.fillMaxWidth())
        }
        detail?.let {
            Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (onCancel != null) {
            OutlinedButton(onClick = onCancel, enabled = cancelEnabled, modifier = Modifier.fillMaxWidth()) {
                Text("Cancel")
            }
        }
    }
}
