package com.novaenhance.ai.ui.viewmodel

import com.novaenhance.ai.training.dataset.SyntheticPhotoResult

private const val MAX_REASON_CHARS = 80

/**
 * How far an Auto-Generate run over several photos has got. [done] photos are finished, successfully or not.
 * [stopping] is set once the user cancelled: the photo in progress is still finished first (see
 * [com.novaenhance.ai.training.dataset.DatasetManager.addSyntheticPairsFromPhotos]).
 */
data class GenerationProgress(
    val total: Int,
    val done: Int = 0,
    val pairsCreated: Int = 0,
    val failedPhotos: Int = 0,
    /** Why the first failed photo failed; later failures are only counted. */
    val firstError: String? = null,
    val stopping: Boolean = false
) {
    /** 1-based number of the photo being worked on (the last one's, once all are done). */
    val currentPhoto: Int get() = (done + 1).coerceAtMost(total)

    /** 0..1 over finished photos only: how long one takes is not known in advance. */
    val fraction: Float get() = if (total <= 0) 0f else done.toFloat() / total

    /** This progress after one more photo finished with [result]. */
    fun after(result: SyntheticPhotoResult): GenerationProgress = copy(
        done = done + 1,
        pairsCreated = pairsCreated + result.pairsCreated,
        failedPhotos = failedPhotos + if (result.isSuccess) 0 else 1,
        firstError = firstError ?: result.error
    )

    /** One line on how the run went, for the screen's message area. [stopped] = the user cancelled before the end. */
    fun summary(stopped: Boolean): String {
        val pairs = count(pairsCreated, "pair")
        val usable = done - failedPhotos
        val reason = firstError?.let { " (${shortReason(it)})" }.orEmpty()
        return when {
            stopped -> "Stopped - $pairs added from $usable of ${count(total, "photo")}" +
                if (failedPhotos > 0) " - $failedPhotos couldn't be used" else ""
            failedPhotos == 0 -> "Added $pairs from ${count(total, "photo")}"
            usable == 0 ->
                (if (total == 1) "That photo couldn't be used" else "None of the $total photos could be used") + reason
            else -> "Added $pairs from $usable of ${count(total, "photo")} - $failedPhotos couldn't be used" + reason
        }
    }

    private fun count(n: Int, noun: String): String = if (n == 1) "1 $noun" else "$n ${noun}s"

    private fun shortReason(text: String): String =
        if (text.length > MAX_REASON_CHARS) text.take(MAX_REASON_CHARS - 1) + "…" else text
}
