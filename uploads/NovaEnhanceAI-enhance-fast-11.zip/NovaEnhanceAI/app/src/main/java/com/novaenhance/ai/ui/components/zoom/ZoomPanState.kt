package com.novaenhance.ai.ui.components.zoom

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlin.math.pow

/**
 * What a zoom step needs to know about the layout. [content] is the content's size at scale 1 (already fitted, centred in
 * [viewport]); [maxScale] is how far in the view may go (see [ZoomMath.maxScale]). Cheap to build, so callers make a fresh
 * one from the current sizes whenever they need it rather than caching one that could go stale.
 */
@Immutable
class ZoomBounds(val viewport: Size, val content: Size, val maxScale: Float)

/**
 * The zoom level and pan of a magnified view. Reusable: it knows nothing about what is drawn, only the transform
 *
 *     screen = centre + (layoutPoint - centre) * scale + offset
 *
 * (see [ZoomMath]).
 *
 * [scale], [offsetX] and [offsetY] are snapshot state, but meant to be READ ONLY while drawing (inside a Canvas or
 * drawBehind block), where a change redraws without recomposing anything. Gestures write them through [applyGesture];
 * double-tap and reset animate them.
 */
@Stable
class ZoomPanState {

    var scale by mutableFloatStateOf(ZoomMath.MIN_SCALE)
        private set
    var offsetX by mutableFloatStateOf(0f)
        private set
    var offsetY by mutableFloatStateOf(0f)
        private set

    /** True once magnified enough that dragging should pan. */
    val isZoomed: Boolean get() = scale >= ZoomMath.ZOOMED_THRESHOLD

    private var animationJob: Job? = null

    /**
     * The pan to draw with: [offsetX]/[offsetY] limited to what [bounds] allows right now. Drawing always goes through
     * this, so a changed container size (rotation, split-screen) or a result of another shape can never leave the
     * content off-screen.
     */
    fun clampedOffset(bounds: ZoomBounds): Offset = Offset(
        ZoomMath.clampOffset(offsetX, bounds.viewport.width, bounds.content.width, scale),
        ZoomMath.clampOffset(offsetY, bounds.viewport.height, bounds.content.height, scale)
    )

    /**
     * One step of a pinch and/or pan: the fingers' centre was at [previousCentroid] and moved by [pan] while the spread
     * of the fingers changed by the factor [zoomChange]. The content under the fingers stays under them.
     */
    fun applyGesture(bounds: ZoomBounds, previousCentroid: Offset, pan: Offset, zoomChange: Float) {
        val oldScale = scale
        val newScale = ZoomMath.clampScale(oldScale * zoomChange, bounds.maxScale)
        // Start from what is on screen (the clamped pan), not from a stored value that a resize may have left out of range.
        val shown = clampedOffset(bounds)
        val centroid = previousCentroid + pan
        setTransform(
            bounds,
            newScale,
            ZoomMath.offsetFollowing(previousCentroid.x, centroid.x, bounds.viewport.width, shown.x, oldScale, newScale),
            ZoomMath.offsetFollowing(previousCentroid.y, centroid.y, bounds.viewport.height, shown.y, oldScale, newScale)
        )
    }

    /** Stops a double-tap/reset animation in progress, e.g. because the user touched the view again. */
    fun stopAnimation() {
        animationJob?.cancel()
        animationJob = null
    }

    /**
     * Double-tap at [focal]: step in to the next zoom level there (see [ZoomMath.nextDoubleTapScale]), or, from the
     * deepest level, back out to fit.
     */
    fun animateDoubleTap(scope: CoroutineScope, bounds: ZoomBounds, focal: Offset) {
        val target = ZoomMath.nextDoubleTapScale(scale, bounds.maxScale)
        if (target == null) {
            animateReset(scope)
            return
        }
        val startScale = scale
        val start = clampedOffset(bounds)
        animate(scope) { eased ->
            // Zooming about the tapped point at every frame keeps it exactly where it was tapped.
            val s = startScale * (target / startScale).pow(eased)
            setTransform(
                bounds,
                s,
                ZoomMath.offsetFollowing(focal.x, focal.x, bounds.viewport.width, start.x, startScale, s),
                ZoomMath.offsetFollowing(focal.y, focal.y, bounds.viewport.height, start.y, startScale, s)
            )
        }
    }

    /** Animates back to the unmagnified, centred view. */
    fun animateReset(scope: CoroutineScope) {
        val startScale = scale
        val startX = offsetX
        val startY = offsetY
        animate(scope) { eased ->
            // startScale^(1 - eased) is the geometric path startScale -> 1. Offsets shrink linearly; drawing clamps
            // them (see clampedOffset), so no bounds are needed here.
            scale = startScale.pow(1f - eased)
            offsetX = startX * (1f - eased)
            offsetY = startY * (1f - eased)
        }
    }

    private fun setTransform(bounds: ZoomBounds, newScale: Float, newOffsetX: Float, newOffsetY: Float) {
        scale = newScale
        offsetX = ZoomMath.clampOffset(newOffsetX, bounds.viewport.width, bounds.content.width, newScale)
        offsetY = ZoomMath.clampOffset(newOffsetY, bounds.viewport.height, bounds.content.height, newScale)
    }

    /** Runs [step] once per frame for [ANIMATION_MILLIS] with an eased 0..1 progress; replaces any animation running. */
    private fun animate(scope: CoroutineScope, step: (eased: Float) -> Unit) {
        stopAnimation()
        animationJob = scope.launch {
            val startNanos = withFrameNanos { it }
            do {
                val elapsedNanos = withFrameNanos { it } - startNanos
                val t = (elapsedNanos / (ANIMATION_MILLIS * 1_000_000f)).coerceIn(0f, 1f)
                step(1f - (1f - t) * (1f - t) * (1f - t)) // ease-out cubic
            } while (t < 1f)
        }
    }

    private companion object {
        const val ANIMATION_MILLIS = 250
    }
}
