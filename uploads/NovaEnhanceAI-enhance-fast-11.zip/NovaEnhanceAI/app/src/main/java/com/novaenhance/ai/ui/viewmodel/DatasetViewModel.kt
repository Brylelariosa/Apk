package com.novaenhance.ai.ui.viewmodel

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.novaenhance.ai.ai.model.ModelRepository
import com.novaenhance.ai.database.dao.ModelDao
import com.novaenhance.ai.database.entities.DatasetPairEntity
import com.novaenhance.ai.database.entities.ModelEntity
import com.novaenhance.ai.training.dataset.DEFAULT_SYNTHETIC_VARIANTS
import com.novaenhance.ai.training.dataset.DatasetManager
import com.novaenhance.ai.workers.DatasetAnalysisWorker
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/** A one-line note for the screen: errors are drawn in the error colour, anything else plainly. */
data class DatasetMessage(val text: String, val isError: Boolean = true)

data class DatasetUiState(
    val activeModel: ModelEntity? = null,
    val pairs: List<DatasetPairEntity> = emptyList(),
    val totalSizeBytes: Long = 0L,
    val isBusy: Boolean = false,
    val message: DatasetMessage? = null,
    /** The Auto-Generate run in progress, or null when none is running. */
    val generation: GenerationProgress? = null
)

class DatasetViewModel(
    private val appContext: Context,
    private val modelDao: ModelDao,
    private val modelRepository: ModelRepository,
    private val datasetManager: DatasetManager
) : ViewModel() {

    private val busy = MutableStateFlow(false)
    private val message = MutableStateFlow<DatasetMessage?>(null)
    private val sizeBytes = MutableStateFlow(0L)
    private val generation = MutableStateFlow<GenerationProgress?>(null)
    private var generationJob: Job? = null

    val uiState: StateFlow<DatasetUiState> = modelDao.observeActive()
        .flatMapLatest { model ->
            if (model == null) {
                flowOf(DatasetUiState())
            } else {
                refreshSize(model.id)
                combine(datasetManager.observePairs(model.id), busy, message, sizeBytes, generation) { pairs, isBusy, msg, size, gen ->
                    DatasetUiState(
                        activeModel = model, pairs = pairs, totalSizeBytes = size,
                        isBusy = isBusy, message = msg, generation = gen
                    )
                }
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DatasetUiState())

    fun addManualPair(lowUri: Uri, highUri: Uri) = withActiveModel { model ->
        datasetManager.addManualPair(model.id, lowUri, highUri)
        refreshSize(model.id)
    }

    /**
     * Auto-Generate: makes [variantCount] degraded (low, high) pairs from each of [sourceUris] - a single photo is just
     * a one-photo selection. The photos are processed one after another
     * ([DatasetManager.addSyntheticPairsFromPhotos]), the pairs show up in the list as they are made, and
     * [DatasetUiState.generation] reports how far along the run is. Ignored while a run is already in progress.
     */
    fun addSyntheticPairsFromPhotos(sourceUris: List<Uri>, variantCount: Int = DEFAULT_SYNTHETIC_VARIANTS) {
        val photos = sourceUris.distinct()
        if (photos.isEmpty() || generationJob?.isActive == true) return
        message.value = null
        generationJob = launchWithActiveModel { model ->
            generation.value = GenerationProgress(total = photos.size)
            try {
                datasetManager.addSyntheticPairsFromPhotos(
                    modelId = model.id,
                    sourceUris = photos,
                    variantCount = variantCount,
                    onPhotoFinished = { _, result ->
                        generation.update { it?.after(result) }
                        refreshSize(model.id)
                    }
                )
                postGenerationSummary(stopped = false)
            } catch (c: CancellationException) {
                postGenerationSummary(stopped = true)
                throw c
            } finally {
                generation.value = null
                refreshSize(model.id)
            }
        }
    }

    /** Asks the running Auto-Generate to stop: the photo in progress is finished, the remaining ones are skipped. */
    fun cancelGeneration() {
        val job = generationJob ?: return
        if (!job.isActive) return
        generation.update { it?.copy(stopping = true) }
        job.cancel()
    }

    private fun postGenerationSummary(stopped: Boolean) {
        val progress = generation.value ?: return
        message.value = DatasetMessage(progress.summary(stopped), isError = progress.failedPhotos > 0)
    }

    fun removePair(pair: DatasetPairEntity) = withActiveModel { model ->
        datasetManager.removePair(pair)
        refreshSize(model.id)
    }

    fun importDataset(zipUri: Uri) = withActiveModel { model ->
        val count = datasetManager.importDataset(model.id, zipUri)
        DatasetAnalysisWorker.enqueue(appContext, model.id)
        message.value = DatasetMessage("Imported $count pairs - analyzing in the background", isError = false)
        refreshSize(model.id)
    }

    fun exportDataset(onExported: (java.io.File) -> Unit) = withActiveModel { model ->
        val file = datasetManager.exportDataset(model.id)
        onExported(file)
    }

    fun clearMessage() {
        message.value = null
    }

    /** Runs [block] with the active model, as a fire-and-forget operation: see [launchWithActiveModel]. */
    private fun withActiveModel(block: suspend (ModelEntity) -> Unit) {
        launchWithActiveModel(block)
    }

    /**
     * Resolves the active model via [ModelRepository.getOrCreateActiveModel]
     * - not a plain null-check against [uiState]'s current snapshot - so
     * this can never fail with a "no model" error: unlike this project's
     * earlier TFLite-based design, creating a model needs no external asset
     * or generation step, so there's no legitimate reason a dataset action
     * should ever be blocked by "no model exists yet." Any exception caught
     * here is a genuine, unexpected failure (e.g. a disk I/O problem), not
     * a missing-setup-step case.
     *
     * Returns the launched [Job] for the one operation that can be cancelled (Auto-Generate). A cancellation is
     * rethrown, not reported: it is the user's own request, not "something that didn't work".
     */
    private fun launchWithActiveModel(block: suspend (ModelEntity) -> Unit): Job =
        viewModelScope.launch {
            busy.value = true
            try {
                val model = modelRepository.getOrCreateActiveModel()
                block(model)
            } catch (c: CancellationException) {
                throw c
            } catch (t: Throwable) {
                message.value = DatasetMessage("That didn't work: ${t.message ?: t::class.simpleName}")
            } finally {
                busy.value = false
            }
        }

    private fun refreshSize(modelId: String) {
        viewModelScope.launch {
            sizeBytes.value = datasetManager.datasetSizeBytes(modelId)
        }
    }
}
