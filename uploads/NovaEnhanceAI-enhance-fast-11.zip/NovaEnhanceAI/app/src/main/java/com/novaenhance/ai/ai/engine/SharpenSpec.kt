package com.novaenhance.ai.ai.engine

/**
 * Parameters of the native sharpening (see `filters/upscale.h`, which this mirrors field for field). It is two stages
 * that run in this order:
 *
 *  1. The EDGE PUSH ([push]) - the one that makes soft line art crisp. Where the picture has a blurred step edge it
 *     moves each pixel of the ramp towards the flat colour on its own side, so the edge steepens without ever leaving
 *     the range of colours already next to it: no overshoot, no halo, no colour fringes.
 *  2. The edge-aware UNSHARP stage ([amount]) - a plain unsharp mask adds `amount * (pixel - blur)` everywhere,
 *     which boosts compression noise in flat areas and leaves halos around strong edges. The "smart" variant
 *     measures the detail on luma only, scales it by a gate that is closed in flat/noisy areas and open on real
 *     edges, and clamps the result to the local min..max (plus a small [overshoot]) so no halos appear.
 *
 * @property amount unsharp detail gain; 0 disables that stage. Useful range 0..3.
 * @property sigma Gaussian sigma, in OUTPUT pixels, of the blur the detail is measured against (native clamps to 0.3..8).
 * @property overshoot how far past the local min/max a pixel may go, as a fraction of the local range (0..1).
 * @property clampRadius radius of the local min/max window (native clamps to 1..4).
 * @property gateLow gradient (levels per pixel) at or below which detail is not boosted at all.
 * @property gateHigh gradient at or above which detail gets the full [amount]; when `<= gateLow` the gate is off.
 * @property push edge-push strength, 0..1; 0 disables that stage. Made for line art (manga, webtoons, logos); on soft
 *   natural photos keep it low.
 * @property pushRadius distance, in OUTPUT pixels, at which the push samples the two sides of an edge (native clamps
 *   to 1..4): about the width of an edge ramp, so it grows with the upscale factor.
 */
data class SharpenSpec(
    val amount: Float,
    val sigma: Float,
    val overshoot: Float = DEFAULT_OVERSHOOT,
    val clampRadius: Int = 1,
    val gateLow: Float = DEFAULT_GATE_LOW,
    val gateHigh: Float = DEFAULT_GATE_HIGH,
    val push: Float = 0f,
    val pushRadius: Int = 1
) {
    /** True when either stage would change a pixel. */
    val isEnabled: Boolean get() = amount > 0f || push > 0f

    companion object {
        const val DEFAULT_OVERSHOOT = 0.08f
        const val DEFAULT_GATE_LOW = 2f
        const val DEFAULT_GATE_HIGH = 12f

        /** A spec that changes nothing. */
        val NONE = SharpenSpec(amount = 0f, sigma = 1f)
    }
}
