package com.novaenhance.ai.training.dataset

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import com.novaenhance.ai.database.dao.DatasetPairDao
import com.novaenhance.ai.database.entities.DatasetPairEntity
import com.novaenhance.ai.storage.AppStorage
import com.novaenhance.ai.utils.NovaLog
import com.novaenhance.ai.utils.decodeUriBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.UUID
import kotlin.random.Random

/** How many degraded copies Auto-Generate makes of each photo. */
const val DEFAULT_SYNTHETIC_VARIANTS = 3

/** What happened to one photo of an Auto-Generate run: how many pairs it produced, or why it produced none. */
data class SyntheticPhotoResult(val pairsCreated: Int, val error: String? = null) {
    val isSuccess: Boolean get() = error == null
}

/**
 * Dataset Manager screen's backing repository: add/remove/preview pairs,
 * import/export a dataset, and the post-training "keep or delete images"
 * decision. Per the product requirement, deleting a pair here only removes
 * the *dataset* copy - anything already promoted into
 * [com.novaenhance.ai.training.trainer.ExperienceMemory]'s replay buffer has
 * its own independent copy and is unaffected.
 *
 * Every function below that touches disk, a Bitmap, or a native filter is
 * wrapped in `withContext(Dispatchers.IO)`, making this repository main-safe
 * on its own: callers (currently just [com.novaenhance.ai.ui.viewmodel.DatasetViewModel],
 * which invokes these via a plain `viewModelScope.launch { }` with no
 * dispatcher override) can call any of them directly from Main without
 * blocking the UI thread. [addSyntheticPairs] in particular chains a decode
 * plus, per variant, up to several full-resolution native degradation passes
 * (see [DegradationGenerator.degrade]) and a JPEG encode - multiple
 * seconds of real work for a large source photo, all of which used to run
 * synchronously on whichever thread called it. [addSyntheticPairsFromPhotos]
 * runs that for a whole selection of photos, one at a time.
 */
class DatasetManager(
    private val context: Context,
    private val storage: AppStorage,
    private val datasetPairDao: DatasetPairDao,
    private val analyzer: DatasetAnalyzer,
    private val degradationGenerator: DegradationGenerator = DegradationGenerator()
) {

    fun observePairs(modelId: String): Flow<List<DatasetPairEntity>> = datasetPairDao.observeForModel(modelId)

    /** Adds a manually-selected (low, high) pair, copying both images into app-private storage. */
    suspend fun addManualPair(modelId: String, lowQualityUri: Uri, highQualityUri: Uri): DatasetPairEntity =
        withContext(Dispatchers.IO) {
            val pairId = UUID.randomUUID().toString()
            val lowDest = File(storage.datasetLowQualityDir(modelId), "$pairId.jpg")
            val highDest = File(storage.datasetHighQualityDir(modelId), "$pairId.jpg")

            copyUriToFile(lowQualityUri, lowDest)
            copyUriToFile(highQualityUri, highDest)

            val entity = DatasetPairEntity(
                modelId = modelId,
                lowQualityPath = lowDest.path,
                highQualityPath = highDest.path,
                addedAt = System.currentTimeMillis(),
                isSynthetic = false
            )
            val id = datasetPairDao.insert(entity)
            val saved = entity.copy(id = id)
            analyzer.analyzeNewPairs(modelId)
            saved
        }

    /**
     * Generates [variantCount] synthetic (low, high) pairs from one high-quality source photo.
     *
     * The photo is decoded upright (EXIF-aware) and capped at [com.novaenhance.ai.utils.MAX_ENHANCE_SOURCE_PIXELS]
     * (see decodeUriBitmap), and JPEG-encoded ONCE: every variant stores its own copy of those bytes (each pair owns its
     * files, so deleting one never touches another) instead of paying for the same multi-megapixel encode per variant.
     */
    suspend fun addSyntheticPairs(
        modelId: String,
        highQualitySourceUri: Uri,
        variantCount: Int = DEFAULT_SYNTHETIC_VARIANTS
    ): List<DatasetPairEntity> =
        withContext(Dispatchers.IO) {
            val sourceBitmap = decodeUriBitmap(context, highQualitySourceUri)
                ?: error("Could not decode source image")

            val created = mutableListOf<DatasetPairEntity>()
            try {
                val highJpeg = encodeJpeg(sourceBitmap)
                repeat(variantCount) { created.add(createSyntheticPair(modelId, sourceBitmap, highJpeg)) }
            } finally {
                sourceBitmap.recycle()
            }

            analyzer.analyzeNewPairs(modelId)
            created
        }

    /**
     * Auto-Generate for a whole selection: [addSyntheticPairs] for each of [sourceUris], one photo at a time.
     *
     * One at a time because a photo plus its degraded copies is tens of MB and the degradation filters are native
     * and multi-threaded: the next photo is only decoded once the previous one has been freed, so peak memory is that
     * of ONE photo whatever the size of the selection. A photo that fails (unreadable file, out of memory, disk full)
     * is reported through [onPhotoFinished] and the run carries on with the next one.
     *
     * Cancellation takes effect BETWEEN photos: the photo being generated is always finished (so a cancelled run never
     * leaves a half-made pair, and the count it reports is exact) and everything finished so far is kept.
     *
     * @param onPhotoStarted called with the photo's index just before it is decoded.
     * @param onPhotoFinished called with the photo's index and its [SyntheticPhotoResult].
     * @throws kotlinx.coroutines.CancellationException if the calling coroutine is cancelled.
     */
    suspend fun addSyntheticPairsFromPhotos(
        modelId: String,
        sourceUris: List<Uri>,
        variantCount: Int = DEFAULT_SYNTHETIC_VARIANTS,
        onPhotoStarted: (index: Int) -> Unit = {},
        onPhotoFinished: (index: Int, result: SyntheticPhotoResult) -> Unit = { _, _ -> }
    ) {
        NovaLog.i(TAG, "AUTOGEN_BEGIN ${sourceUris.size} photo(s) x $variantCount variant(s)")
        for ((index, uri) in sourceUris.withIndex()) {
            currentCoroutineContext().ensureActive()
            onPhotoStarted(index)
            val result = withContext(NonCancellable) {
                try {
                    SyntheticPhotoResult(pairsCreated = addSyntheticPairs(modelId, uri, variantCount).size)
                } catch (t: Throwable) {
                    NovaLog.w(TAG, "AUTOGEN_PHOTO $index failed", t)
                    SyntheticPhotoResult(pairsCreated = 0, error = t.message ?: t::class.java.simpleName)
                }
            }
            onPhotoFinished(index, result)
        }
        NovaLog.i(TAG, "AUTOGEN_END ${sourceUris.size} photo(s)")
    }

    /**
     * Writes one synthetic pair - the high-quality bytes plus a freshly degraded low-quality copy - and records it.
     * Whatever a failing pair already wrote (disk full, an error while degrading) is removed again, so a failed variant
     * leaves nothing orphaned on disk.
     */
    private suspend fun createSyntheticPair(modelId: String, source: Bitmap, highJpeg: ByteArray): DatasetPairEntity {
        val pairId = UUID.randomUUID().toString()
        val highDest = File(storage.datasetHighQualityDir(modelId), "$pairId.jpg")
        val lowDest = File(storage.datasetLowQualityDir(modelId), "$pairId.jpg")
        try {
            highDest.writeBytes(highJpeg)

            val degraded = degradationGenerator.degrade(source, pickRecipe())
            try {
                saveBitmap(degraded, lowDest)
            } finally {
                degraded.recycle()
            }

            val entity = DatasetPairEntity(
                modelId = modelId,
                lowQualityPath = lowDest.path,
                highQualityPath = highDest.path,
                addedAt = System.currentTimeMillis(),
                isSynthetic = true
            )
            return entity.copy(id = datasetPairDao.insert(entity))
        } catch (t: Throwable) {
            highDest.delete()
            lowDest.delete()
            throw t
        }
    }

    /**
     * randomRecipe()'s default severity floor (0.4) means every synthetic pair otherwise guarantees a real correction
     * is needed - the model never sees a rewarded "this is already mostly fine, go easy" example, which risks
     * over-correcting (over-sharpening/over-denoising) genuinely good photos at inference. A minority of variants
     * deliberately draw from a low severity range instead - not zero, so this still keeps DegradationGenerator's own
     * guarantee that some blur/noise is always applied and doesn't produce a functionally identical pair.
     */
    private fun pickRecipe(): DegradationGenerator.DegradationRecipe =
        if (Random.nextFloat() < LOW_SEVERITY_VARIANT_CHANCE) {
            degradationGenerator.randomRecipe(severity = Random.nextFloat() * LOW_SEVERITY_CEILING)
        } else {
            degradationGenerator.randomRecipe()
        }

    suspend fun removePair(pair: DatasetPairEntity) {
        withContext(Dispatchers.IO) {
            File(pair.lowQualityPath).delete()
            File(pair.highQualityPath).delete()
            datasetPairDao.delete(pair.id)
        }
    }

    /** "Training completed. Delete training images?" -> Delete Dataset option. Learned weights are unaffected. */
    suspend fun deleteAllForModel(modelId: String) {
        withContext(Dispatchers.IO) {
            val pairs = datasetPairDao.getUsablePairs(modelId)
            pairs.forEach {
                File(it.lowQualityPath).delete()
                File(it.highQualityPath).delete()
            }
            datasetPairDao.deleteAllForModel(modelId)
            storage.datasetDir(modelId).deleteRecursively()
        }
    }

    suspend fun datasetSizeBytes(modelId: String): Long = withContext(Dispatchers.IO) {
        storage.datasetDir(modelId).walkTopDown().filter { it.isFile }.sumOf { it.length() }
    }

    /** Exports every usable pair as a single zip (`low/pair_0001.jpg` + `high/pair_0001.jpg`, ...) for backup/sharing. */
    suspend fun exportDataset(modelId: String): File = withContext(Dispatchers.IO) {
        val destZip = File(storage.datasetsDir(), "${modelId}_dataset_${System.currentTimeMillis()}.zip")
        java.util.zip.ZipOutputStream(destZip.outputStream().buffered()).use { zip ->
            val pairs = datasetPairDao.getUsablePairs(modelId)
            for ((index, pair) in pairs.withIndex()) {
                val name = "pair_%04d.jpg".format(index)
                addZipEntry(zip, "low/$name", File(pair.lowQualityPath))
                addZipEntry(zip, "high/$name", File(pair.highQualityPath))
            }
        }
        destZip
    }

    /**
     * Imports a dataset zip previously produced by [exportDataset] (or hand-built
     * with the same `low/`+`high/` matching-filename convention).
     *
     * Deliberately does NOT run [DatasetAnalyzer] itself - a bulk import can be
     * large, and analysis belongs on a durable background worker
     * (`DatasetAnalysisWorker`) rather than blocking this call or risking
     * losing progress to process death. Callers should enqueue that worker
     * for [modelId] after a successful import; this keeps `training.dataset`
     * from depending on the `workers` package, which depends on it instead.
     *
     * Returns the number of pairs imported.
     */
    suspend fun importDataset(modelId: String, zipUri: Uri): Int = withContext(Dispatchers.IO) {
        val tempDir = File(context.cacheDir, "dataset_import_${System.currentTimeMillis()}").apply { mkdirs() }
        try {
            context.contentResolver.openInputStream(zipUri)?.use { input ->
                java.util.zip.ZipInputStream(input.buffered()).use { zip ->
                    var entry = zip.nextEntry
                    while (entry != null) {
                        if (!entry.isDirectory) {
                            val dest = File(tempDir, entry.name)
                            dest.parentFile?.mkdirs()
                            dest.outputStream().use { out -> zip.copyTo(out) }
                        }
                        zip.closeEntry()
                        entry = zip.nextEntry
                    }
                }
            } ?: error("Could not open $zipUri")

            val lowFiles = File(tempDir, "low").listFiles()?.associateBy { it.name } ?: emptyMap()
            val highFiles = File(tempDir, "high").listFiles()?.associateBy { it.name } ?: emptyMap()

            val newPairs = lowFiles.mapNotNull { (name, lowFile) ->
                val highFile = highFiles[name] ?: return@mapNotNull null
                val pairId = UUID.randomUUID().toString()
                val lowDest = File(storage.datasetLowQualityDir(modelId), "$pairId.jpg")
                val highDest = File(storage.datasetHighQualityDir(modelId), "$pairId.jpg")
                lowFile.copyTo(lowDest, overwrite = true)
                highFile.copyTo(highDest, overwrite = true)
                DatasetPairEntity(
                    modelId = modelId, lowQualityPath = lowDest.path, highQualityPath = highDest.path,
                    addedAt = System.currentTimeMillis(), isSynthetic = false
                )
            }

            if (newPairs.isNotEmpty()) datasetPairDao.insertAll(newPairs)
            newPairs.size
        } finally {
            tempDir.deleteRecursively()
        }
    }

    private fun addZipEntry(zip: java.util.zip.ZipOutputStream, name: String, file: File) {
        zip.putNextEntry(java.util.zip.ZipEntry(name))
        file.inputStream().use { it.copyTo(zip) }
        zip.closeEntry()
    }

    private fun copyUriToFile(uri: Uri, dest: File) {
        context.contentResolver.openInputStream(uri)?.use { input ->
            dest.outputStream().use { output -> input.copyTo(output) }
        } ?: error("Could not open $uri")
    }

    private fun saveBitmap(bitmap: Bitmap, dest: File) {
        dest.outputStream().use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, out)
        }
    }

    private fun encodeJpeg(bitmap: Bitmap): ByteArray {
        val out = ByteArrayOutputStream()
        check(bitmap.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, out)) { "Could not encode the photo as JPEG" }
        return out.toByteArray()
    }

    private companion object {
        const val TAG = "DatasetManager"
        const val JPEG_QUALITY = 95
        /** Fraction of synthetic variants that get a low-severity (rather than default) recipe. */
        const val LOW_SEVERITY_VARIANT_CHANCE = 0.15f
        /** Upper bound of the severity range those low-severity variants are drawn from. */
        const val LOW_SEVERITY_CEILING = 0.15f
    }
}
