package com.novaenhance.ai.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.novaenhance.ai.R
import com.novaenhance.ai.ui.components.zoom.ZoomBadge
import com.novaenhance.ai.ui.components.zoom.ZoomBounds
import com.novaenhance.ai.ui.components.zoom.ZoomMath
import com.novaenhance.ai.ui.components.zoom.ZoomPanState
import com.novaenhance.ai.ui.components.zoom.detectZoomGestures
import com.novaenhance.ai.utils.NovaLog
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

private const val TAG = "BeforeAfterSlider"

/** While zoomed in, a touch this close (horizontally) to the divider drags the divider; anywhere else it pans. */
private val DividerGrabRadius = 28.dp

/**
 * From this many screen pixels per image pixel up, pixels are drawn as crisp squares instead of being smoothed:
 * smoothing a heavily magnified photo only blurs it, and the point of zooming in is to judge the detail.
 */
private const val CRISP_PIXELS_FROM = 3f

/**
 * The app's signature interaction: drag the teal divider to wipe between
 * the original (left) and AI-enhanced (right) image. This is the one place
 * the app takes a real visual/interaction risk - everywhere else in the UI
 * is calm and information-dense by comparison, which is deliberate (see
 * ui/theme's design note on the palette telling the enhancement story).
 *
 * Zoom: pinch to zoom in (down to individual pixels - see [ZoomMath.maxScale]), drag to pan once zoomed, double-tap
 * to step in and back out; the badge at the bottom shows the zoom and resets it. Both images share ONE transform, so
 * the wipe compares the same spot of "before" and "after" at any depth, and the divider keeps its place on screen.
 * While zoomed, only a drag that starts on the divider moves it (anywhere else pans). The zoom belongs to the
 * [original] photo: a re-enhanced result of the same photo keeps it, so a slider tweak can be judged at the same spot,
 * and a different photo starts fresh.
 *
 * Bitmap lifetime contract (see [com.novaenhance.ai.utils.ResourceRetirement]):
 * whoever owns [original]/[enhanced] may recycle an instance once it has been
 * replaced AND this composable has reported - through the *DisplayChanged
 * callbacks - that it no longer draws it. "No longer draws it" is only true
 * once the draw code that captured the old instance has itself been replaced,
 * which is why this composable is deliberately ONE plain composition:
 *
 *  - The ownership reports ([ReportBitmapUse]), the ImageBitmap wrappers and
 *    the [Canvas] whose draw lambda captures the bitmaps are all applied by a
 *    single applyChanges(). That pass updates the nodes first (installing the
 *    new draw lambda) and only then runs the old effect's onDispose (the
 *    release), so the release can never overtake the draw code.
 *  - It must NOT use BoxWithConstraints (or any SubcomposeLayout) around the
 *    Canvas. Its content is a separate composition that is updated on its own
 *    schedule, not in the parent's applyChanges. The previous version did
 *    exactly that: the release was reported from the parent's composition and
 *    the old bitmap was recycled while the Canvas, inside the subcomposition,
 *    still held a draw lambda capturing it. The next re-record of that layer
 *    - which happens in the very frame that a finished enhancement flips
 *    isProcessing and removes the progress overlay - then crashed with
 *    "Canvas: trying to use a recycled bitmap". Nothing here needs the
 *    constraints anyway: the Canvas reports its own size, and the handle only
 *    needs the container width, which [onSizeChanged] provides.
 *
 * The [isRecycled] check in [drawFitted] is a last line of defence (a skipped
 * frame instead of a crash, plus one log line saying the contract was
 * broken), not the mechanism.
 */
@Composable
fun BeforeAfterSlider(
    original: Bitmap,
    enhanced: Bitmap,
    modifier: Modifier = Modifier,
    beforeLabel: String = "Before",
    afterLabel: String = "After",
    onOriginalDisplayChanged: (bitmap: Bitmap, displayed: Boolean) -> Unit = { _, _ -> },
    onEnhancedDisplayChanged: (bitmap: Bitmap, displayed: Boolean) -> Unit = { _, _ -> }
) {
    ReportBitmapUse(original, onOriginalDisplayChanged)
    ReportBitmapUse(enhanced, onEnhancedDisplayChanged)

    var dividerFraction by remember { mutableFloatStateOf(0.5f) }
    var containerWidthPx by remember { mutableIntStateOf(0) }
    val originalImage = remember(original) { original.asImageBitmap() }
    val enhancedImage = remember(enhanced) { enhanced.asImageBitmap() }
    // Keyed on the photo, not the result: see the class doc.
    val zoom = remember(original) { ZoomPanState() }
    // The gesture loop outlives recompositions, so it reads the images through these instead of capturing the first ones.
    val latestOriginal by rememberUpdatedState(originalImage)
    val latestEnhanced by rememberUpdatedState(enhancedImage)
    val staleBitmapWarning = remember {
        WarnOnce("Skipped drawing a recycled bitmap (stale frame) - its owner recycled it before the slider let go")
    }
    val handleColor = MaterialTheme.colorScheme.primary
    val handleDiameter = 40.dp

    Box(
        modifier = modifier
            .fillMaxSize()
            .onSizeChanged { containerWidthPx = it.width }
            .pointerInput(zoom) {
                val grabRadiusPx = DividerGrabRadius.toPx()
                detectZoomGestures(
                    state = zoom,
                    boundsFor = { viewport -> zoomBoundsFor(viewport, latestOriginal, latestEnhanced) },
                    // Not zoomed: any drag moves the divider, as it always did. Zoomed: only one that starts on it.
                    claimsDragAt = { down -> !zoom.isZoomed || abs(down.x - size.width * dividerFraction) <= grabRadiusPx },
                    onClaimedDrag = { position -> dividerFraction = (position.x / size.width).coerceIn(0f, 1f) }
                )
            }
    ) {
        // Both bitmaps are drawn here, in the same Canvas, each fitted with
        // identical ContentScale.Fit math - rather than the previous
        // approach of an auto-scaled Image() for "enhanced" underneath a
        // raw Canvas.drawImage() for "original". That second call defaults
        // to the bitmap's native pixel size at the top-left corner when no
        // dstSize is given, so whenever the two bitmaps weren't already the
        // exact same pixel dimensions - which is the common case: the
        // enhancer can change resolution, and dataset pairs are decoded
        // independently in decodeSampledBitmap - "original" rendered at a
        // different size and origin than "enhanced", showing through the
        // wipe as a second, misaligned copy instead of a clean comparison.
        // "After" fills the whole frame; "before" is clipped over the left
        // portion up to the divider, so dragging right reveals more of the
        // original and dragging left reveals more of the AI result.
        //
        // dividerFraction is only read inside this draw block and inside the
        // handle's offset lambda below (layout phase), never during
        // composition, so dragging the divider re-draws and re-lays-out but
        // does not recompose anything.
        Canvas(modifier = Modifier.fillMaxSize()) {
            val originalFit = fitRect(originalImage, size)
            val enhancedFit = fitRect(enhancedImage, size)
            // The same transform for both images (and the pan clamped to what the current sizes allow), so the wipe
            // always compares the very same spot. zoom's state is read here, in the draw phase only: a pinch redraws
            // but recomposes nothing.
            val bounds = zoomBoundsFor(size, originalImage, originalFit, enhancedImage, enhancedFit)
            val shift = zoom.clampedOffset(bounds)
            val zoomScale = zoom.scale

            drawFitted(enhanced, enhancedImage, enhancedFit, zoomScale, shift, staleBitmapWarning)

            val dividerX = size.width * dividerFraction
            clipRect(right = dividerX) {
                drawFitted(original, originalImage, originalFit, zoomScale, shift, staleBitmapWarning)
            }

            drawLine(
                color = handleColor,
                start = Offset(dividerX, 0f),
                end = Offset(dividerX, size.height),
                strokeWidth = 3.dp.toPx()
            )
        }

        CompareLabel(text = beforeLabel, modifier = Modifier.align(Alignment.TopStart).padding(12.dp))
        CompareLabel(text = afterLabel, modifier = Modifier.align(Alignment.TopEnd).padding(12.dp))

        Surface(
            modifier = Modifier
                .align(Alignment.CenterStart)
                .offset { IntOffset(x = (containerWidthPx * dividerFraction - handleDiameter.toPx() / 2f).roundToInt(), y = 0) }
                .size(handleDiameter),
            shape = CircleShape,
            color = handleColor,
            shadowElevation = 6.dp
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    painter = painterResource(R.drawable.ic_swap_horizontal),
                    contentDescription = "Drag to compare before and after",
                    tint = Color.White,
                    modifier = Modifier.padding(8.dp)
                )
            }
        }

        ZoomBadge(state = zoom, modifier = Modifier.align(Alignment.BottomCenter).padding(12.dp))
    }
}

/**
 * Reports to [onDisplayChanged] every time THIS composition's use of a
 * specific [bitmap] instance starts or ends: once when it first receives it,
 * again if a newer bitmap replaces it in place, and again if the composition
 * leaves. Keyed on the bitmap itself (not e.g. Unit) so it fires exactly
 * when that instance's tenure here starts/ends.
 *
 * Must be called from the same composition that draws [bitmap] - see
 * [BeforeAfterSlider]. The callback is read through rememberUpdatedState so
 * a changed callback instance never re-keys the effect or gets a stale call.
 */
@Composable
private fun ReportBitmapUse(
    bitmap: Bitmap,
    onDisplayChanged: (bitmap: Bitmap, displayed: Boolean) -> Unit
) {
    val currentOnDisplayChanged by rememberUpdatedState(onDisplayChanged)
    DisposableEffect(bitmap) {
        currentOnDisplayChanged(bitmap, true)
        onDispose { currentOnDisplayChanged(bitmap, false) }
    }
}

/** Logs [message] at most once, so a stale frame that keeps redrawing can't flood the on-disk crash log. */
private class WarnOnce(private val message: String) {
    private val warned = AtomicBoolean(false)

    fun warn() {
        if (warned.compareAndSet(false, true)) NovaLog.w(TAG, message)
    }
}

/**
 * Draws [image] (the ImageBitmap wrapper of [bitmap]) into this DrawScope, or draws nothing if [bitmap] has been
 * recycled: drawing a recycled bitmap throws, and a skipped frame is better than a crash. Both the check and the
 * recycle happen on the main thread, so nothing can recycle it between the two lines.
 *
 * [fitted] is where the image sits unmagnified (see [fitRect]); [scale] and [shift] are the zoom, applied with
 * [ZoomMath.toScreen] - at scale 1 and no shift this is exactly the plain fitted draw.
 */
private fun DrawScope.drawFitted(
    bitmap: Bitmap,
    image: ImageBitmap,
    fitted: Rect,
    scale: Float,
    shift: Offset,
    warning: WarnOnce
) {
    if (bitmap.isRecycled) {
        warning.warn()
        return
    }
    val left = ZoomMath.toScreen(fitted.left, size.width, scale, shift.x)
    val top = ZoomMath.toScreen(fitted.top, size.height, scale, shift.y)
    val screenPxPerImagePx = fitted.width / image.width * scale
    drawImage(
        image = image,
        dstOffset = IntOffset(left.roundToInt(), top.roundToInt()),
        dstSize = IntSize((fitted.width * scale).roundToInt(), (fitted.height * scale).roundToInt()),
        filterQuality = if (screenPxPerImagePx >= CRISP_PIXELS_FROM) FilterQuality.None else FilterQuality.Low
    )
}

/** A small pill badge for labeling which side of the slider is which. Stays fixed in its corner regardless of divider position - only the underlying image content is clipped by the drag. */
@Composable
private fun CompareLabel(text: String, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(50),
        color = Color.Black.copy(alpha = 0.6f)
    ) {
        Text(
            text = text.uppercase(),
            color = Color.White,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}

/**
 * The on-screen rectangle [image] would occupy inside [containerSize] under
 * [ContentScale.Fit] semantics (uniform scale-to-fit, centered) - i.e.
 * exactly what an `Image(contentScale = ContentScale.Fit)` composable would
 * render for that bitmap in a box of that size. Lets a manually-drawn
 * `DrawScope.drawImage` call match that layout instead of falling back to
 * its own default (the bitmap's native pixel size, top-left aligned) - see
 * the comment above where this is used in [BeforeAfterSlider].
 */
private fun fitRect(image: ImageBitmap, containerSize: Size): Rect {
    val imageSize = Size(image.width.toFloat(), image.height.toFloat())
    if (imageSize.width <= 0f || imageSize.height <= 0f ||
        containerSize.width <= 0f || containerSize.height <= 0f
    ) {
        return Rect(Offset.Zero, containerSize)
    }
    val scale = ContentScale.Fit.computeScaleFactor(imageSize, containerSize).scaleX
    val scaledSize = Size(imageSize.width * scale, imageSize.height * scale)
    val topLeft = Offset(
        x = (containerSize.width - scaledSize.width) / 2f,
        y = (containerSize.height - scaledSize.height) / 2f
    )
    return Rect(topLeft, scaledSize)
}

/** [ZoomBounds] for a viewport showing [original] and [enhanced], each fitted on its own. */
private fun zoomBoundsFor(viewport: Size, original: ImageBitmap, enhanced: ImageBitmap): ZoomBounds =
    zoomBoundsFor(viewport, original, fitRect(original, viewport), enhanced, fitRect(enhanced, viewport))

/**
 * [ZoomBounds] when the fitted rectangles are already known. The content is as big as the larger of the two fitted
 * images (the pair is normally the same shape, to within a pixel), and how deep zooming goes is decided by the SHARPER
 * image: the one whose pixels are smallest on screen when fitted.
 */
private fun zoomBoundsFor(
    viewport: Size,
    original: ImageBitmap,
    originalFit: Rect,
    enhanced: ImageBitmap,
    enhancedFit: Rect
): ZoomBounds {
    val content = Size(max(originalFit.width, enhancedFit.width), max(originalFit.height, enhancedFit.height))
    val screenPxPerImagePx = min(originalFit.width / original.width, enhancedFit.width / enhanced.width)
    return ZoomBounds(viewport, content, ZoomMath.maxScale(screenPxPerImagePx))
}
