package com.novaenhance.ai.ai.engine

import android.graphics.Bitmap

/**
 * Thin JNI bridge over the native (`app/src/main/cpp`) image filter library.
 *
 * All tile-based operations work on plain [IntArray] pixel buffers in
 * Android's ARGB_8888 int layout (as produced by [Bitmap.getPixels]), which
 * keeps the JNI surface simple and lets [com.novaenhance.ai.ai.engine.BandProcessor]
 * own all memory/tiling decisions. [resizeBitmapInto] is the one exception -
 * it operates on raw bitmap memory directly for cheap whole-image thumbnails
 * where an extra IntArray round trip isn't worth it.
 *
 * These are classic (non-learned) filters: they back the manual enhancement
 * sliders (sharpness/noise-reduction controls a user can drag) and the
 * synthetic dataset degradation generator. The *learned* part of the pipeline
 * (the part that actually improves from training) lives in [NovaModelEngine].
 */
object NativeImageProcessor {

    init {
        System.loadLibrary("novaenhance_native")
    }

    fun gaussianBlur(pixels: IntArray, width: Int, height: Int, sigma: Float): IntArray {
        validateTileArgs(pixels, width, height, "gaussianBlur")
        return nativeGaussianBlur(pixels, width, height, sigma)
    }

    fun unsharpMask(pixels: IntArray, width: Int, height: Int, sigma: Float, amount: Float): IntArray {
        validateTileArgs(pixels, width, height, "unsharpMask")
        return nativeUnsharpMask(pixels, width, height, sigma, amount)
    }

    fun denoiseBilateral(
        pixels: IntArray,
        width: Int,
        height: Int,
        spatialSigma: Float,
        rangeSigma: Float
    ): IntArray {
        validateTileArgs(pixels, width, height, "denoiseBilateral")
        return nativeDenoiseBilateral(pixels, width, height, spatialSigma, rangeSigma)
    }

    fun resizeBilinear(
        pixels: IntArray,
        srcWidth: Int,
        srcHeight: Int,
        dstWidth: Int,
        dstHeight: Int
    ): IntArray = nativeResizeBilinear(pixels, srcWidth, srcHeight, dstWidth, dstHeight)

    /**
     * Edge-aware sharpening (see [SharpenSpec] and `filters/upscale.h`) of an ARGB_8888 pixel buffer; alpha is
     * preserved. Returns [pixels] itself when [spec] is disabled. [threads] <= 0 means "all pool threads".
     */
    fun smartSharpen(pixels: IntArray, width: Int, height: Int, spec: SharpenSpec, threads: Int = 0): IntArray {
        validateTileArgs(pixels, width, height, "smartSharpen")
        if (!spec.isEnabled) return pixels
        return nativeSmartSharpen(
            pixels, width, height, spec.amount, spec.sigma, spec.overshoot, spec.clampRadius,
            spec.gateLow, spec.gateHigh, spec.push, spec.pushRadius, threads
        )
    }

    /**
     * Real context rows above and below a band that [smartSharpen] needs so a band's own rows come out exactly as
     * a whole-image pass would. Answered by the native code that does the work, so the two cannot drift apart.
     */
    fun sharpenReachRows(spec: SharpenSpec): Int =
        if (!spec.isEnabled) 0
        else nativeSharpenReachRows(spec.amount, spec.sigma, spec.clampRadius, spec.push, spec.pushRadius)

    /**
     * Compression-artifact removal (see `filters/restore.h`): colour-blotch/blocking removal on the chroma planes and
     * de-ringing on luma, both edge-preserving. This is what the "Noise reduction" slider drives. [strength] is
     * 0..1; 0 returns [pixels] itself. Alpha is preserved. [threads] <= 0 means "all pool threads".
     */
    fun restoreArtifacts(pixels: IntArray, width: Int, height: Int, strength: Float, threads: Int = 0): IntArray {
        validateTileArgs(pixels, width, height, "restoreArtifacts")
        if (!(strength > 0f)) return pixels
        return nativeRestoreArtifacts(pixels, width, height, strength, threads)
    }

    /**
     * Real context rows above and below a band that [restoreArtifacts] needs so a band's own rows come out exactly
     * as a whole-image pass would (0 when [strength] disables it). Answered by the native code that does the work.
     */
    fun restoreReachRows(strength: Float): Int = if (!(strength > 0f)) 0 else nativeRestoreReachRows(strength)

    /**
     * Lanczos-3 upscales [src] by the integer [factor] into [dst] (ringing clamped to the range of the 2x2 source
     * pixels around each sample) - rows [y0] until [y1] only - and applies the [spec] sharpening: the halo-free
     * edge push first, then the edge-aware unsharp stage. [dst] must be an ARGB_8888 bitmap of exactly `factor x` [src]'s size; it is
     * written in place, so a whole image is produced by calling this for consecutive row ranges (see
     * [UpscaleStage]). Every call recomputes the few extra rows the sharpening needs, so the result is identical
     * to one whole-image call whatever the band split - no seams. Neither bitmap may be recycled or a hardware
     * bitmap.
     */
    fun upscaleBand(src: Bitmap, dst: Bitmap, factor: Int, y0: Int, y1: Int, spec: SharpenSpec, threads: Int = 0) {
        require(factor in 1..MAX_UPSCALE_FACTOR) { "upscaleBand: factor must be in 1..$MAX_UPSCALE_FACTOR (got $factor)" }
        require(
            dst.width.toLong() == src.width.toLong() * factor && dst.height.toLong() == src.height.toLong() * factor
        ) { "upscaleBand: ${dst.width}x${dst.height} is not ${factor}x ${src.width}x${src.height}" }
        require(y0 in 0..y1 && y1 <= dst.height) { "upscaleBand: rows $y0..$y1 are outside the ${dst.height}-row destination" }
        check(
            nativeUpscaleBand(
                src, dst, factor, y0, y1, spec.amount, spec.sigma, spec.overshoot, spec.clampRadius,
                spec.gateLow, spec.gateHigh, spec.push, spec.pushRadius, threads
            )
        ) { "native upscaleBand failed (see logcat tag NovaEnhanceNative) - is a bitmap recycled?" }
    }

    /** Fast proxy similarity in [0,1]; used by the validator, not a full SSIM. */
    fun quickSimilarityScore(a: IntArray, b: IntArray, width: Int, height: Int): Float =
        nativeQuickSimilarityScore(a, b, width, height)

    fun addGaussianNoise(pixels: IntArray, width: Int, height: Int, amount: Float, seed: Int): IntArray =
        nativeAddGaussianNoise(pixels, width, height, amount, seed)

    fun simulateJpegArtifacts(pixels: IntArray, width: Int, height: Int, qualityPercent: Int): IntArray =
        nativeSimulateJpegArtifacts(pixels, width, height, qualityPercent)

    fun motionBlur(pixels: IntArray, width: Int, height: Int, angleDegrees: Float, lengthPx: Int): IntArray =
        nativeMotionBlur(pixels, width, height, angleDegrees, lengthPx)

    fun colorFade(pixels: IntArray, width: Int, height: Int, fadeAmount: Float): IntArray =
        nativeColorFade(pixels, width, height, fadeAmount)

    /** Resizes [src] directly into [dst] (must be pre-allocated at the target size). */
    fun resizeBitmapInto(src: Bitmap, dst: Bitmap): Boolean = nativeResizeBitmapInto(src, dst)

    // A reasonable ceiling on any one dimension passed into a native image call.
    // Enhancement works in full-width bands (BandProcessor), so a "tile" here can
    // be as wide as a whole photo - the HOT 11's 13 MP main camera is already 4208px
    // wide, and a 4x upscale of one is wider still - which is why this is no longer the
    // 4096px it was when every caller passed 64px tiles. It exists purely to reject an
    // obviously-wrong value before it reaches JNI, rather than let width*height
    // silently overflow or allocate something huge. Mirrors native-lib.cpp's
    // kMaxImageDimension.
    private const val MAX_IMAGE_DIMENSION = 16384

    /** Mirrors native-lib.cpp's kMaxUpscaleFactor. */
    private const val MAX_UPSCALE_FACTOR = 8

    /**
     * Explicit validation before any tile-based JNI call - see the class doc
     * comment. Kotlin's non-nullable IntArray already rules out passing a
     * literal null pixels array from code compiled against this signature,
     * but width/height/array-length agreement is a call-site invariant
     * nothing in the type system enforces, and a mismatch here would
     * otherwise reach C++ as an unchecked `pixels[y*width+x]` index -
     * undefined behavior, not a catchable error. Native-lib.cpp repeats an
     * equivalent check at the JNI boundary itself (see its
     * `validatePixelArray`) as defense in depth, but failing fast here with
     * a clear Kotlin stack trace pointing at the actual misuse is more
     * useful than only ever seeing it after crossing into native code.
     */
    private fun validateTileArgs(pixels: IntArray, width: Int, height: Int, fnName: String) {
        require(width > 0 && height > 0) { "$fnName: width and height must be positive (got ${width}x$height)" }
        require(width <= MAX_IMAGE_DIMENSION && height <= MAX_IMAGE_DIMENSION) {
            "$fnName: ${width}x$height exceeds the $MAX_IMAGE_DIMENSION px per-dimension ceiling for a native image call"
        }
        val expected = width.toLong() * height.toLong()
        require(pixels.size.toLong() == expected) {
            "$fnName: pixels.size (${pixels.size}) does not match width*height ($expected for ${width}x$height)"
        }
    }

    // --- JNI declarations, implemented in native-lib.cpp ---
    private external fun nativeGaussianBlur(pixels: IntArray, width: Int, height: Int, sigma: Float): IntArray
    private external fun nativeUnsharpMask(
        pixels: IntArray, width: Int, height: Int, sigma: Float, amount: Float
    ): IntArray
    private external fun nativeDenoiseBilateral(
        pixels: IntArray, width: Int, height: Int, spatialSigma: Float, rangeSigma: Float
    ): IntArray
    private external fun nativeResizeBilinear(
        pixels: IntArray, srcWidth: Int, srcHeight: Int, dstWidth: Int, dstHeight: Int
    ): IntArray
    private external fun nativeQuickSimilarityScore(a: IntArray, b: IntArray, width: Int, height: Int): Float
    private external fun nativeAddGaussianNoise(
        pixels: IntArray, width: Int, height: Int, amount: Float, seed: Int
    ): IntArray
    private external fun nativeSimulateJpegArtifacts(
        pixels: IntArray, width: Int, height: Int, qualityPercent: Int
    ): IntArray
    private external fun nativeMotionBlur(
        pixels: IntArray, width: Int, height: Int, angleDegrees: Float, lengthPx: Int
    ): IntArray
    private external fun nativeColorFade(pixels: IntArray, width: Int, height: Int, fadeAmount: Float): IntArray
    private external fun nativeResizeBitmapInto(src: Bitmap, dst: Bitmap): Boolean
    private external fun nativeSmartSharpen(
        pixels: IntArray, width: Int, height: Int, amount: Float, sigma: Float, overshoot: Float,
        clampRadius: Int, gateLow: Float, gateHigh: Float, push: Float, pushRadius: Int, threads: Int
    ): IntArray
    private external fun nativeSharpenReachRows(
        amount: Float, sigma: Float, clampRadius: Int, push: Float, pushRadius: Int
    ): Int
    private external fun nativeUpscaleBand(
        src: Bitmap, dst: Bitmap, factor: Int, y0: Int, y1: Int, amount: Float, sigma: Float, overshoot: Float,
        clampRadius: Int, gateLow: Float, gateHigh: Float, push: Float, pushRadius: Int, threads: Int
    ): Boolean
    private external fun nativeRestoreArtifacts(
        pixels: IntArray, width: Int, height: Int, strength: Float, threads: Int
    ): IntArray
    private external fun nativeRestoreReachRows(strength: Float): Int
}
