#include "upscale.h"

#include <algorithm>
#include <cmath>
#include <cstring>

#include "filters/row_parallel.h"

namespace novaenhance {

namespace {

constexpr int kLanczosA = 3;
constexpr int kTaps = 2 * kLanczosA;  // 6 taps per output sample
constexpr double kPi = 3.14159265358979323846;
constexpr int kMaxPushRadius = 4;  // largest SharpenParams::pushRadius the edge push accepts

inline int clampi(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }
inline float clampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }

SharpenParams sanitize(SharpenParams p) {
    p.amount = std::max(0.0f, p.amount);
    p.sigma = clampf(p.sigma, 0.3f, 8.0f);
    p.overshoot = clampf(p.overshoot, 0.0f, 1.0f);
    p.clampRadius = clampi(p.clampRadius, 1, 4);
    p.push = p.push > 0.0f ? clampf(p.push, 0.0f, 1.0f) : 0.0f;  // also turns NaN into 0
    p.pushRadius = clampi(p.pushRadius, 1, kMaxPushRadius);
    return p;
}

int gaussianRadius(float sigma) { return std::max(1, static_cast<int>(std::ceil(sigma * 3.0f))); }

std::vector<float> makeGaussian(float sigma, int radius) {
    std::vector<double> raw(static_cast<size_t>(2 * radius + 1));
    double sum = 0.0;
    const double twoSigmaSq = 2.0 * static_cast<double>(sigma) * static_cast<double>(sigma);
    for (int i = -radius; i <= radius; ++i) {
        const double v = std::exp(-(static_cast<double>(i) * i) / twoSigmaSq);
        raw[static_cast<size_t>(i + radius)] = v;
        sum += v;
    }
    std::vector<float> kernel(raw.size());
    for (size_t i = 0; i < raw.size(); ++i) kernel[i] = static_cast<float>(raw[i] / sum);
    return kernel;
}

/**
 * Separable Gaussian blur of a float plane (w x h), image edges replicated: out = G(sigma) * Y.
 * Each output pixel reads Y within gaussianRadius(sigma) rows/columns of it and sums its taps in a fixed order, so
 * the result does not depend on how rows are split across threads or bands.
 */
void gaussianPlane(const float* Y, float* delta, int w, int h, float sigma, int threads) {
    const size_t n = static_cast<size_t>(w) * static_cast<size_t>(h);
    const int R = gaussianRadius(sigma);
    const std::vector<float> g = makeGaussian(sigma, R);
    std::vector<float> tmp(n);
    const int rpj = rowsPerJobFor(w);

    // Horizontal Gaussian: Y -> tmp. Interior columns need no clamping; the k loop is outermost there so the
    // inner x loop is contiguous (and vectorizes) while each pixel still accumulates its taps in the same order.
    forRowBlocks(h, rpj, threads, [&](int a, int b) {
        for (int y = a; y < b; ++y) {
            const float* row = Y + static_cast<size_t>(y) * w;
            float* out = tmp.data() + static_cast<size_t>(y) * w;
            const int xBegin = std::min(R, w);
            const int xEnd = std::max(xBegin, w - R);
            for (int x = 0; x < xBegin; ++x) {
                float acc = 0.0f;
                for (int k = -R; k <= R; ++k) acc += g[static_cast<size_t>(k + R)] * row[clampi(x + k, 0, w - 1)];
                out[x] = acc;
            }
            for (int x = xBegin; x < xEnd; ++x) out[x] = 0.0f;
            for (int k = -R; k <= R; ++k) {
                const float wk = g[static_cast<size_t>(k + R)];
                for (int x = xBegin; x < xEnd; ++x) out[x] += wk * row[x + k];
            }
            for (int x = xEnd; x < w; ++x) {
                float acc = 0.0f;
                for (int k = -R; k <= R; ++k) acc += g[static_cast<size_t>(k + R)] * row[clampi(x + k, 0, w - 1)];
                out[x] = acc;
            }
        }
    });

    // Vertical Gaussian: tmp -> delta.
    forRowBlocks(h, rpj, threads, [&](int a, int b) {
        for (int y = a; y < b; ++y) {
            float* out = delta + static_cast<size_t>(y) * w;
            for (int x = 0; x < w; ++x) out[x] = 0.0f;
            for (int k = -R; k <= R; ++k) {
                const float wk = g[static_cast<size_t>(k + R)];
                const float* src = tmp.data() + static_cast<size_t>(clampi(y + k, 0, h - 1)) * w;
                for (int x = 0; x < w; ++x) out[x] += wk * src[x];
            }
        }
    });
}

// ----------------------------------------------------------------------------------------------------------
// Luma detail: the shared core of the 1x (ARGB int) and upscaled (RGBA float) sharpening paths.
// ----------------------------------------------------------------------------------------------------------

/**
 * For a luma plane Y (w x h, 0..255) computes, per pixel, the luma change the smart sharpen wants to apply:
 *
 *   detail   = Y - gaussian(Y, sigma)
 *   gate     = smoothstep(gateLow, gateHigh, |sobel(Y)| / 8)          // flat/noisy areas -> 0, edges -> 1
 *   sharp    = Y + amount * gate * detail
 *   result   = clamp(sharp, min - overshoot*range, max + overshoot*range)    // min/max over the (2r+1)^2 window
 *   delta    = result - Y
 *
 * Image edges replicate. Every pixel only reads Y within max(gaussianRadius, clampRadius, 1) rows/columns of it.
 */
void lumaDetailDelta(const float* Y, int w, int h, const SharpenParams& p, float* delta, int threads) {
    const int rpj = rowsPerJobFor(w);

    // Blurred luma lands in delta first; the final stage below overwrites it in place with the luma change.
    gaussianPlane(Y, delta, w, h, p.sigma, threads);

    // Final stage: gate, sharpen, clamp to the local range; delta[i] goes from "blurred luma" to "luma change".
    const int r = p.clampRadius;  // sanitized: 1..4
    std::vector<int> xcl(static_cast<size_t>(w) + 2 * static_cast<size_t>(r));
    for (int i = 0; i < w + 2 * r; ++i) xcl[static_cast<size_t>(i)] = clampi(i - r, 0, w - 1);
    const bool gated = p.gateHigh > p.gateLow;
    const float gateLow = p.gateLow;
    const float gateInv = gated ? 1.0f / (p.gateHigh - p.gateLow) : 0.0f;
    const float amount = p.amount;
    const float overshoot = p.overshoot;

    forRowBlocks(h, rpj, threads, [&](int a, int b) {
        std::vector<const float*> rows(static_cast<size_t>(2 * r + 1));
        for (int y = a; y < b; ++y) {
            for (int dy = -r; dy <= r; ++dy) {
                rows[static_cast<size_t>(dy + r)] = Y + static_cast<size_t>(clampi(y + dy, 0, h - 1)) * w;
            }
            const float* ru = rows[static_cast<size_t>(r - 1)];
            const float* rc = rows[static_cast<size_t>(r)];
            const float* rd = rows[static_cast<size_t>(r + 1)];
            float* out = delta + static_cast<size_t>(y) * w;
            for (int x = 0; x < w; ++x) {
                const int* xc = &xcl[static_cast<size_t>(x + r)];  // xc[dx] = clamped column of x + dx
                const float yc = rc[x];

                float mn = yc, mx = yc;
                for (int dy = 0; dy <= 2 * r; ++dy) {
                    const float* rr = rows[static_cast<size_t>(dy)];
                    for (int dx = -r; dx <= r; ++dx) {
                        const float v = rr[xc[dx]];
                        mn = v < mn ? v : mn;
                        mx = v > mx ? v : mx;
                    }
                }

                const int xl = xc[-1], xr = xc[1];
                const float gx = (ru[xr] + 2.0f * rc[xr] + rd[xr]) - (ru[xl] + 2.0f * rc[xl] + rd[xl]);
                const float gy = (rd[xl] + 2.0f * rd[x] + rd[xr]) - (ru[xl] + 2.0f * ru[x] + ru[xr]);
                const float grad = std::sqrt(gx * gx + gy * gy) * 0.125f;

                float gate = 1.0f;
                if (gated) {
                    const float t = clampf((grad - gateLow) * gateInv, 0.0f, 1.0f);
                    gate = t * t * (3.0f - 2.0f * t);
                }

                const float blur = out[x];
                float sharp = yc + amount * gate * (yc - blur);
                const float range = mx - mn;
                sharp = clampf(sharp, mn - overshoot * range, mx + overshoot * range);
                out[x] = sharp - yc;
            }
        }
    });
}

inline float lumaOf(float r, float g, float b) { return 0.299f * r + 0.587f * g + 0.114f * b; }

inline uint8_t toByte(float v) {
    const int i = static_cast<int>(v + 0.5f);
    return static_cast<uint8_t>(i < 0 ? 0 : (i > 255 ? 255 : i));
}

// ----------------------------------------------------------------------------------------------------------
// Edge push: halo-free restoration of blurred step edges (line art)
// ----------------------------------------------------------------------------------------------------------

constexpr float kPushSteepness = 8.0f;   // how hard the ramp between the two plateaus is steepened around its midpoint
constexpr float kPushMinSpan = 8.0f;     // plateaus closer than this (levels of luma) do not form an edge
constexpr float kPushGateLow = 4.0f;     // gradient gate (levels per pixel) at pushRadius 1; both thresholds are divided
constexpr float kPushGateHigh = 20.0f;   // by the radius, because a ramp ~radius times wider is ~radius times less steep
constexpr float kPushDirectionSlope = 0.41421356f;  // tan(22.5 degrees): where one of the 8 directions hands over to the next

/** Sigma of the blur the edge direction is measured on: calmer for the wider ramps of an upscaled picture. */
inline float pushSigma(int radius) { return 0.6f + 0.2f * static_cast<float>(radius); }

/** Rows above/below a pixel that the push reads: the luma blur around the sampled positions plus the sampling distance. */
int pushReachRows(const SharpenParams& p) {
    return p.push > 0.0f ? gaussianRadius(pushSigma(p.pushRadius)) + p.pushRadius : 0;
}

/**
 * Edge push on an interleaved float RGBA image (w x h, values 0..255). `out` (same layout, must not alias `in`)
 * receives the result; `in` is not modified.
 *
 *   Ys         = gaussian(luma(in), pushSigma)                  steady luma for finding the edge direction
 *   direction  = Sobel gradient of Ys, quantised to one of 8 directions pointing UPHILL (towards the lighter side)
 *   front/back = mean colour and mean Ys of the 3 pixels `pushRadius` away on the uphill / downhill side
 *   t          = (Ys - Lback) / (Lfront - Lback), clamped to 0..1   where the pixel sits on the ramp
 *   t'         = clamp(0.5 + (t - 0.5) * steepness, 0, 1)           the same ramp, almost a step
 *   target     = lerp(Cback, Cfront, t')
 *   out        = in + push * gate(|gradient|) * (target - in)
 *
 * The target is always a blend of two colours that already sit next to the pixel, so no value can leave the range
 * of its surroundings: there is no overshoot, hence no halo, and the colour moves as a whole, so no fringes either.
 * That is the difference from an unsharp mask, which can only ADD contrast around an edge. Pixels whose gradient is
 * under the gate, or whose two sides differ by less than kPushMinSpan, are copied unchanged, so flat areas and
 * low-level noise are never touched.
 *
 * Every output pixel reads `in` within pushReachRows(p) rows/columns of it and does fixed-order float math, so a band
 * that carries that many real context rows reproduces a whole-image pass bit for bit. Image edges replicate.
 */
void edgePush(const float* in, float* out, int w, int h, const SharpenParams& p, int threads) {
    const size_t n = static_cast<size_t>(w) * static_cast<size_t>(h);
    const int rpj = rowsPerJobFor(w);

    std::vector<float> Y(n);
    std::vector<float> Ys(n);
    forRowBlocks(h, rpj, threads, [&](int a, int b) {
        for (int y = a; y < b; ++y) {
            const float* px = in + static_cast<size_t>(y) * w * 4;
            float* o = Y.data() + static_cast<size_t>(y) * w;
            for (int x = 0; x < w; ++x) o[x] = lumaOf(px[x * 4], px[x * 4 + 1], px[x * 4 + 2]);
        }
    });
    gaussianPlane(Y.data(), Ys.data(), w, h, pushSigma(p.pushRadius), threads);
    std::vector<float>().swap(Y);  // the raw luma is not needed past this point

    const int r = p.pushRadius;  // sanitized: 1..kMaxPushRadius
    const float gateLow = kPushGateLow / static_cast<float>(r);
    const float gateInv = static_cast<float>(r) / (kPushGateHigh - kPushGateLow);
    const float strength = p.push;
    constexpr float kThird = 1.0f / 3.0f;

    // xcl[x + 1 + dx] = clamped column of x + dx, for dx in -1..1 (the Sobel neighbours).
    std::vector<int> xcl(static_cast<size_t>(w) + 2);
    for (int i = 0; i < w + 2; ++i) xcl[static_cast<size_t>(i)] = clampi(i - 1, 0, w - 1);

    forRowBlocks(h, rpj, threads, [&](int a, int b) {
        for (int y = a; y < b; ++y) {
            const float* ru = Ys.data() + static_cast<size_t>(clampi(y - 1, 0, h - 1)) * w;
            const float* rc = Ys.data() + static_cast<size_t>(y) * w;
            const float* rd = Ys.data() + static_cast<size_t>(clampi(y + 1, 0, h - 1)) * w;
            const float* srcRow = in + static_cast<size_t>(y) * w * 4;
            float* dstRow = out + static_cast<size_t>(y) * w * 4;
            for (int x = 0; x < w; ++x) {
                const float* s = srcRow + static_cast<size_t>(x) * 4;
                float* d = dstRow + static_cast<size_t>(x) * 4;
                d[0] = s[0];
                d[1] = s[1];
                d[2] = s[2];
                d[3] = s[3];

                const int xl = xcl[static_cast<size_t>(x)];
                const int xr = xcl[static_cast<size_t>(x) + 2];
                const float gx = (ru[xr] + 2.0f * rc[xr] + rd[xr]) - (ru[xl] + 2.0f * rc[xl] + rd[xl]);
                const float gy = (rd[xl] + 2.0f * rd[x] + rd[xr]) - (ru[xl] + 2.0f * ru[x] + ru[xr]);
                const float grad = std::sqrt(gx * gx + gy * gy) * 0.125f;
                if (!(grad > gateLow)) continue;  // gate closed: flat area or noise
                const float gt = clampf((grad - gateLow) * gateInv, 0.0f, 1.0f);
                const float weight = strength * (gt * gt * (3.0f - 2.0f * gt));

                // Direction of steepest ascent, one of 8 (|gradient| > 0 here, so at least one component is set).
                const float ax = std::fabs(gx);
                const float ay = std::fabs(gy);
                const int dx = ax > kPushDirectionSlope * ay ? (gx > 0.0f ? 1 : -1) : 0;
                const int dy = ay > kPushDirectionSlope * ax ? (gy > 0.0f ? 1 : -1) : 0;

                // The three samples on the uphill side; the downhill side mirrors them through the pixel.
                int ox[3];
                int oy[3];
                if (dx == 0 || dy == 0) {  // axis-aligned: a short line across the direction of travel
                    for (int i = 0; i < 3; ++i) {
                        ox[i] = dx * r + dy * (i - 1);
                        oy[i] = dy * r + dx * (i - 1);
                    }
                } else {  // diagonal: the pixel diagonally ahead and its two axis-aligned neighbours
                    ox[0] = dx * r; oy[0] = dy * r;
                    ox[1] = dx * r; oy[1] = 0;
                    ox[2] = 0;      oy[2] = dy * r;
                }

                float fR = 0.0f, fG = 0.0f, fB = 0.0f, fL = 0.0f;  // front (uphill, lighter) side
                float bR = 0.0f, bG = 0.0f, bB = 0.0f, bL = 0.0f;  // back (downhill, darker) side
                for (int i = 0; i < 3; ++i) {
                    const size_t fi = static_cast<size_t>(clampi(y + oy[i], 0, h - 1)) * w + static_cast<size_t>(clampi(x + ox[i], 0, w - 1));
                    const size_t bi = static_cast<size_t>(clampi(y - oy[i], 0, h - 1)) * w + static_cast<size_t>(clampi(x - ox[i], 0, w - 1));
                    const float* fp = in + fi * 4;
                    const float* bp = in + bi * 4;
                    fR += fp[0]; fG += fp[1]; fB += fp[2]; fL += Ys[fi];
                    bR += bp[0]; bG += bp[1]; bB += bp[2]; bL += Ys[bi];
                }
                fR *= kThird; fG *= kThird; fB *= kThird; fL *= kThird;
                bR *= kThird; bG *= kThird; bB *= kThird; bL *= kThird;

                const float span = fL - bL;
                if (!(span > kPushMinSpan)) continue;  // the two sides are too alike to be an edge
                const float pos = clampf((rc[x] - bL) / span, 0.0f, 1.0f);
                const float t = clampf(0.5f + (pos - 0.5f) * kPushSteepness, 0.0f, 1.0f);
                d[0] = s[0] + weight * ((bR + t * (fR - bR)) - s[0]);
                d[1] = s[1] + weight * ((bG + t * (fG - bG)) - s[1]);
                d[2] = s[2] + weight * ((bB + t * (fB - bB)) - s[2]);
            }
        }
    });
}

// ----------------------------------------------------------------------------------------------------------
// Lanczos-3 resampling tables
// ----------------------------------------------------------------------------------------------------------

double lanczos3(double x) {
    const double ax = std::fabs(x);
    if (ax < 1e-9) return 1.0;
    if (ax >= kLanczosA) return 0.0;
    const double px = kPi * x;
    return kLanczosA * std::sin(px) * std::sin(px / kLanczosA) / (px * px);
}

/** Taps for output samples [first, first + count) of one axis: source indices (clamped) and normalised weights. */
struct AxisTable {
    std::vector<int> idx;
    std::vector<float> w;
};

AxisTable makeAxisTable(int first, int count, int srcN, int factor) {
    AxisTable t;
    t.idx.resize(static_cast<size_t>(count) * kTaps);
    t.w.resize(static_cast<size_t>(count) * kTaps);
    for (int i = 0; i < count; ++i) {
        const int out = first + i;
        // Half-pixel-centre mapping, the convention every mainstream resampler uses.
        const double s = (static_cast<double>(out) + 0.5) / factor - 0.5;
        const int base = static_cast<int>(std::floor(s));
        double raw[kTaps];
        double sum = 0.0;
        for (int k = 0; k < kTaps; ++k) {
            raw[k] = lanczos3(s - static_cast<double>(base - (kLanczosA - 1) + k));
            sum += raw[k];
        }
        for (int k = 0; k < kTaps; ++k) {
            t.w[static_cast<size_t>(i) * kTaps + k] = static_cast<float>(raw[k] / sum);
            t.idx[static_cast<size_t>(i) * kTaps + k] = clampi(base - (kLanczosA - 1) + k, 0, srcN - 1);
        }
    }
    return t;
}

}  // namespace

int sharpenReachRows(const SharpenParams& params) {
    const SharpenParams p = sanitize(params);
    // The edge push runs first and the unsharp stage reads ITS output, so the two reaches add up.
    const int unsharp = p.amount > 0.0f ? std::max(std::max(gaussianRadius(p.sigma), p.clampRadius), 1) : 0;
    return std::max(pushReachRows(p) + unsharp, 1);
}

std::vector<int32_t> smartSharpen(const std::vector<int32_t>& pixels, int width, int height,
                                  const SharpenParams& params, int threads) {
    if (pixels.empty() || width <= 0 || height <= 0 || !sharpenEnabled(params)) return pixels;
    const size_t n = static_cast<size_t>(width) * static_cast<size_t>(height);
    if (pixels.size() != n) return pixels;
    const SharpenParams p = sanitize(params);
    if (!sharpenEnabled(p)) return pixels;  // sanitising can switch a stage off (e.g. a NaN amount)

    const int rpj = rowsPerJobFor(width);
    std::vector<int32_t> out(n);

    if (p.push <= 0.0f) {
        // Unsharp stage only, straight on the integer pixels (the path every build before 11 used).
        std::vector<float> luma(n);
        std::vector<float> delta(n);
        forRowBlocks(height, rpj, threads, [&](int a, int b) {
            for (size_t i = static_cast<size_t>(a) * width; i < static_cast<size_t>(b) * width; ++i) {
                const uint32_t px = static_cast<uint32_t>(pixels[i]);
                luma[i] = lumaOf(static_cast<float>((px >> 16) & 0xFF), static_cast<float>((px >> 8) & 0xFF),
                                 static_cast<float>(px & 0xFF));
            }
        });
        lumaDetailDelta(luma.data(), width, height, p, delta.data(), threads);

        forRowBlocks(height, rpj, threads, [&](int a, int b) {
            for (size_t i = static_cast<size_t>(a) * width; i < static_cast<size_t>(b) * width; ++i) {
                const uint32_t px = static_cast<uint32_t>(pixels[i]);
                const float d = delta[i];
                const uint32_t alpha = (px >> 24) & 0xFF;
                const uint32_t r = toByte(static_cast<float>((px >> 16) & 0xFF) + d);
                const uint32_t g = toByte(static_cast<float>((px >> 8) & 0xFF) + d);
                const uint32_t bl = toByte(static_cast<float>(px & 0xFF) + d);
                out[i] = static_cast<int32_t>((alpha << 24) | (r << 16) | (g << 8) | bl);
            }
        });
        return out;
    }

    // Edge push first (it needs colour, so it works on float RGBA), then the unsharp stage on its result.
    std::vector<float> rgba(n * 4);
    forRowBlocks(height, rpj, threads, [&](int a, int b) {
        for (size_t i = static_cast<size_t>(a) * width; i < static_cast<size_t>(b) * width; ++i) {
            const uint32_t px = static_cast<uint32_t>(pixels[i]);
            rgba[i * 4] = static_cast<float>((px >> 16) & 0xFF);
            rgba[i * 4 + 1] = static_cast<float>((px >> 8) & 0xFF);
            rgba[i * 4 + 2] = static_cast<float>(px & 0xFF);
            rgba[i * 4 + 3] = static_cast<float>((px >> 24) & 0xFF);
        }
    });
    {
        std::vector<float> pushed(n * 4);
        edgePush(rgba.data(), pushed.data(), width, height, p, threads);
        rgba.swap(pushed);
    }  // the un-pushed copy is released here

    std::vector<float> delta;  // luma change of the unsharp stage; stays empty when that stage is off
    if (p.amount > 0.0f) {
        std::vector<float> luma(n);
        delta.resize(n);
        forRowBlocks(height, rpj, threads, [&](int a, int b) {
            for (size_t i = static_cast<size_t>(a) * width; i < static_cast<size_t>(b) * width; ++i) {
                luma[i] = lumaOf(rgba[i * 4], rgba[i * 4 + 1], rgba[i * 4 + 2]);
            }
        });
        lumaDetailDelta(luma.data(), width, height, p, delta.data(), threads);
    }

    forRowBlocks(height, rpj, threads, [&](int a, int b) {
        for (size_t i = static_cast<size_t>(a) * width; i < static_cast<size_t>(b) * width; ++i) {
            const float d = delta.empty() ? 0.0f : delta[i];
            const uint32_t alpha = (static_cast<uint32_t>(pixels[i]) >> 24) & 0xFF;
            const uint32_t r = toByte(rgba[i * 4] + d);
            const uint32_t g = toByte(rgba[i * 4 + 1] + d);
            const uint32_t bl = toByte(rgba[i * 4 + 2] + d);
            out[i] = static_cast<int32_t>((alpha << 24) | (r << 16) | (g << 8) | bl);
        }
    });
    return out;
}

void upscaleRows(const uint8_t* src, size_t srcStride, int srcW, int srcH,
                 uint8_t* dst, size_t dstStride, int factor, int y0, int y1,
                 const SharpenParams& sharpenIn, int threads) {
    if (src == nullptr || dst == nullptr || srcW <= 0 || srcH <= 0 || factor < 1) return;
    const int dstW = srcW * factor;
    const int dstH = srcH * factor;
    y0 = std::max(0, y0);
    y1 = std::min(dstH, y1);
    if (y0 >= y1) return;

    const SharpenParams sharpen = sanitize(sharpenIn);
    const bool doSharpen = sharpenEnabled(sharpen);
    // Output rows recomputed above/below the band purely as sharpening context (only where the image has them).
    const int reach = doSharpen ? sharpenReachRows(sharpen) : 0;
    const int ys = std::max(0, y0 - reach);
    const int ye = std::min(dstH, y1 + reach);
    const int bandRows = ye - ys;

    const AxisTable xt = makeAxisTable(0, dstW, srcW, factor);
    const AxisTable yt = makeAxisTable(ys, bandRows, srcH, factor);

    // Source rows the vertical taps of this band touch (after edge clamping).
    int r0 = srcH - 1, r1 = 0;
    for (int idx : yt.idx) {
        r0 = std::min(r0, idx);
        r1 = std::max(r1, idx);
    }
    const int srcRows = r1 - r0 + 1;
    const size_t rowFloats = static_cast<size_t>(dstW) * 4;
    const int rpj = rowsPerJobFor(dstW);

    // 1) Horizontal pass: each needed source row, resampled to the output width (float RGBA). Alongside, the range
    //    of the two source pixels that bracket every output sample (the two INNER taps) - the anti-ringing bounds.
    std::vector<float> hbuf(static_cast<size_t>(srcRows) * rowFloats);
    std::vector<float> hlo(hbuf.size());
    std::vector<float> hhi(hbuf.size());
    forRowBlocks(srcRows, rpj, threads, [&](int a, int b) {
        for (int r = a; r < b; ++r) {
            const uint8_t* srow = src + static_cast<size_t>(r0 + r) * srcStride;
            float* out = hbuf.data() + static_cast<size_t>(r) * rowFloats;
            float* lo = hlo.data() + static_cast<size_t>(r) * rowFloats;
            float* hi = hhi.data() + static_cast<size_t>(r) * rowFloats;
            for (int x = 0; x < dstW; ++x) {
                const int* ix = &xt.idx[static_cast<size_t>(x) * kTaps];
                const float* wx = &xt.w[static_cast<size_t>(x) * kTaps];
                float c0 = 0.0f, c1 = 0.0f, c2 = 0.0f, c3 = 0.0f;
                for (int k = 0; k < kTaps; ++k) {
                    const uint8_t* q = srow + static_cast<size_t>(ix[k]) * 4;
                    const float wk = wx[k];
                    c0 += wk * static_cast<float>(q[0]);
                    c1 += wk * static_cast<float>(q[1]);
                    c2 += wk * static_cast<float>(q[2]);
                    c3 += wk * static_cast<float>(q[3]);
                }
                float* o = out + static_cast<size_t>(x) * 4;
                o[0] = c0;
                o[1] = c1;
                o[2] = c2;
                o[3] = c3;

                const uint8_t* qa = srow + static_cast<size_t>(ix[kLanczosA - 1]) * 4;
                const uint8_t* qb = srow + static_cast<size_t>(ix[kLanczosA]) * 4;
                float* l = lo + static_cast<size_t>(x) * 4;
                float* hgh = hi + static_cast<size_t>(x) * 4;
                for (int c = 0; c < 3; ++c) {
                    l[c] = static_cast<float>(std::min(qa[c], qb[c]));
                    hgh[c] = static_cast<float>(std::max(qa[c], qb[c]));
                }
                l[3] = 0.0f;  // alpha is not range-limited here; it is clamped to 0..255 when written
                hgh[3] = 255.0f;
            }
        }
    });

    // 2) Vertical pass: the six taps of every output row, summed in a fixed order, then ANTI-RINGING: the result is
    //    clamped to the range of the 2x2 source pixels that surround the sample. Lanczos overshoots next to a hard
    //    edge (a dark band beside a white line, a bright one beside a dark line); that overshoot is exactly what
    //    reads as a halo once the picture is enlarged, and no value of the 2x2 neighbourhood is ever beyond the
    //    flat colours the edge joins, so the clamp removes the ringing and nothing else.
    std::vector<float> band(static_cast<size_t>(bandRows) * rowFloats);
    forRowBlocks(bandRows, rpj, threads, [&](int a, int b) {
        for (int r = a; r < b; ++r) {
            const int* iy = &yt.idx[static_cast<size_t>(r) * kTaps];
            const float* wy = &yt.w[static_cast<size_t>(r) * kTaps];
            const float* s0 = hbuf.data() + static_cast<size_t>(iy[0] - r0) * rowFloats;
            const float* s1 = hbuf.data() + static_cast<size_t>(iy[1] - r0) * rowFloats;
            const float* s2 = hbuf.data() + static_cast<size_t>(iy[2] - r0) * rowFloats;
            const float* s3 = hbuf.data() + static_cast<size_t>(iy[3] - r0) * rowFloats;
            const float* s4 = hbuf.data() + static_cast<size_t>(iy[4] - r0) * rowFloats;
            const float* s5 = hbuf.data() + static_cast<size_t>(iy[5] - r0) * rowFloats;
            const float* lo2 = hlo.data() + static_cast<size_t>(iy[kLanczosA - 1] - r0) * rowFloats;
            const float* lo3 = hlo.data() + static_cast<size_t>(iy[kLanczosA] - r0) * rowFloats;
            const float* hi2 = hhi.data() + static_cast<size_t>(iy[kLanczosA - 1] - r0) * rowFloats;
            const float* hi3 = hhi.data() + static_cast<size_t>(iy[kLanczosA] - r0) * rowFloats;
            const float w0 = wy[0], w1 = wy[1], w2 = wy[2], w3 = wy[3], w4 = wy[4], w5 = wy[5];
            float* o = band.data() + static_cast<size_t>(r) * rowFloats;
            for (size_t i = 0; i < rowFloats; ++i) {
                const float v = w0 * s0[i] + w1 * s1[i] + w2 * s2[i] + w3 * s3[i] + w4 * s4[i] + w5 * s5[i];
                o[i] = clampf(v, std::min(lo2[i], lo3[i]), std::max(hi2[i], hi3[i]));
            }
        }
    });
    std::vector<float>().swap(hbuf);  // release before the sharpening scratch is allocated
    std::vector<float>().swap(hlo);
    std::vector<float>().swap(hhi);

    // 3) Sharpening on the float band (context rows included so the rows we keep are exact): the edge push first,
    //    then the unsharp stage on its result.
    if (sharpen.push > 0.0f) {
        std::vector<float> pushed(band.size());
        edgePush(band.data(), pushed.data(), dstW, bandRows, sharpen, threads);
        band.swap(pushed);
    }
    if (sharpen.amount > 0.0f) {
        const size_t n = static_cast<size_t>(dstW) * static_cast<size_t>(bandRows);
        std::vector<float> luma(n);
        std::vector<float> delta(n);
        forRowBlocks(bandRows, rpj, threads, [&](int a, int b) {
            for (int y = a; y < b; ++y) {
                const float* px = band.data() + static_cast<size_t>(y) * rowFloats;
                float* out = luma.data() + static_cast<size_t>(y) * dstW;
                for (int x = 0; x < dstW; ++x) out[x] = lumaOf(px[x * 4], px[x * 4 + 1], px[x * 4 + 2]);
            }
        });
        lumaDetailDelta(luma.data(), dstW, bandRows, sharpen, delta.data(), threads);
        forRowBlocks(bandRows, rpj, threads, [&](int a, int b) {
            for (int y = a; y < b; ++y) {
                float* px = band.data() + static_cast<size_t>(y) * rowFloats;
                const float* d = delta.data() + static_cast<size_t>(y) * dstW;
                for (int x = 0; x < dstW; ++x) {
                    px[x * 4] = clampf(px[x * 4] + d[x], 0.0f, 255.0f);
                    px[x * 4 + 1] = clampf(px[x * 4 + 1] + d[x], 0.0f, 255.0f);
                    px[x * 4 + 2] = clampf(px[x * 4 + 2] + d[x], 0.0f, 255.0f);
                }
            }
        });
    }

    // 4) Write the band's own rows. Colour is capped at alpha (premultiplied RGBA); for opaque images a no-op.
    forRowBlocks(y1 - y0, rpj, threads, [&](int a, int b) {
        for (int r = a; r < b; ++r) {
            const float* in = band.data() + static_cast<size_t>(y0 - ys + r) * rowFloats;
            uint8_t* out = dst + static_cast<size_t>(y0 + r) * dstStride;
            for (int x = 0; x < dstW; ++x) {
                const float* px = in + static_cast<size_t>(x) * 4;
                const float alpha = clampf(px[3], 0.0f, 255.0f);
                out[x * 4] = toByte(clampf(px[0], 0.0f, alpha));
                out[x * 4 + 1] = toByte(clampf(px[1], 0.0f, alpha));
                out[x * 4 + 2] = toByte(clampf(px[2], 0.0f, alpha));
                out[x * 4 + 3] = toByte(alpha);
            }
        }
    });
}

}  // namespace novaenhance
