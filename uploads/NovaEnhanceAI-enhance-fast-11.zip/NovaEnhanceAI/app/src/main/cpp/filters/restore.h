#ifndef NOVAENHANCE_RESTORE_H
#define NOVAENHANCE_RESTORE_H

#include <cstdint>
#include <vector>

namespace novaenhance {

/**
 * Compression-artifact removal for the "Noise reduction" control.
 *
 * What lossy JPEG/WebP leaves behind is not "noise" in the sensor sense, and a small bilateral filter (the 5x5 one in
 * convolution.h) is the wrong size for it:
 *   - COLOUR BLOTCHES / BLOCKING. Chroma is stored at half resolution and quantised hard, so flat colour areas come
 *     out as mottled patches 8-16 pixels across, and colour smears past outlines. Too big for a 5x5 window.
 *   - MOSQUITO NOISE / RINGING. Faint ripples (a few levels to a dozen) in the flat area next to every sharp line.
 *
 * restoreArtifacts() converts to YCbCr and runs a separable (two 1-D passes) joint bilateral filter, 17 taps each:
 *   - the CHROMA planes are averaged over a wide window, but only with pixels that look alike in luma AND colour, so
 *     blotches melt away while a real colour boundary - or a line - stops the averaging dead (no colour bleeding);
 *   - the LUMA plane is averaged with pixels whose luma is within a few levels, which flattens ripples and leaves
 *     every genuine edge (differences of tens of levels) untouched.
 * Edges are therefore not blurred, which is why this can be much stronger than the old 5x5 filter at the same visual
 * cost: on JPEG-damaged line art it raises PSNR where the old filter lowered it, and it does not soften fine detail.
 */
struct RestoreParams {
    float strength = 0.0f;  // 0 disables; 1 = strongest. Clamped to 0..1 (NaN counts as 0).
};

/** Taps on each side of a pixel along each axis; fixed, so callers can budget context rows without asking. */
constexpr int kRestoreRadius = 8;

inline bool restoreEnabled(const RestoreParams& p) { return p.strength > 0.0f; }

/**
 * Real context rows above and below a band that restoreArtifacts() needs so a band's own rows come out bit-identical
 * to a whole-image pass: kRestoreRadius when enabled, 0 otherwise.
 */
int restoreReachRows(const RestoreParams& p);

/**
 * Artifact removal on an ARGB_8888 int buffer (0xAARRGGBB, as Bitmap.getPixels returns). Alpha is preserved. Returns
 * the input unchanged when disabled or when pixels.size() != width * height. `threads` <= 0 means "all pool threads".
 * Image edges replicate, the same convention as the other filters.
 */
std::vector<int32_t> restoreArtifacts(const std::vector<int32_t>& pixels, int width, int height,
                                      const RestoreParams& params, int threads);

}  // namespace novaenhance

#endif  // NOVAENHANCE_RESTORE_H
