#ifndef NOVAENHANCE_UPSCALE_H
#define NOVAENHANCE_UPSCALE_H

#include <cstddef>
#include <cstdint>
#include <vector>

namespace novaenhance {

/**
 * Edge-aware ("smart") sharpening. The classic unsharp mask adds `amount * (pixel - blur)` everywhere, which
 *  (a) amplifies compression noise and mosquito artifacts in flat areas, and
 *  (b) overshoots on strong edges, leaving bright/dark halos.
 * This variant fixes both:
 *  - the detail signal is taken from LUMA only (no colour fringes),
 *  - it is multiplied by a smooth GATE driven by the local gradient, so flat/noisy areas are left alone and real
 *    edges get the full amount, and
 *  - the sharpened luma is clamped to the local min..max of the unsharpened luma (plus a small `overshoot`
 *    fraction of the local range), which removes halos.
 * On manga/anime line art and on photos it scored better than a plain unsharp mask in every PSNR/SSIM test
 * (see tools/upscale_verification and README -> "Upscaling and sharpening").
 *
 * Build 11 adds an optional first stage, the EDGE PUSH (SharpenParams::push): the unsharp stage can only add
 * contrast around an edge, which always leaves a faint halo; the push instead snaps blurred edge ramps to the flat
 * colours on either side, which is what actually makes soft line art crisp.
 */
struct SharpenParams {
    float amount = 0.0f;       // unsharp detail gain; 0 disables the unsharp stage
    float sigma = 1.0f;        // Gaussian sigma, in OUTPUT pixels, of the blur the detail is measured against
    float overshoot = 0.08f;   // result may exceed the local min/max by this fraction of the local range
    int clampRadius = 1;       // radius of the local min/max window
    float gateLow = 2.0f;      // gradient (levels per pixel) at or below which detail is not boosted
    float gateHigh = 12.0f;    // gradient at or above which detail gets the full amount

    // Edge push - a halo-free edge restorer that runs BEFORE the unsharp stage (see edgePush in upscale.cpp).
    // Where the picture has a blurred step edge it moves each pixel of the ramp towards the flat colour on its own
    // side, so the edge becomes steeper without ever leaving the range of colours already present next to it: no
    // overshoot, no halos, no colour fringes. Made for line art (manga, webtoons, logos), where nearly every edge is
    // such a step; on soft natural photos keep it low.
    float push = 0.0f;         // 0 disables the stage, 1 = full strength
    int pushRadius = 1;        // distance, in OUTPUT pixels, at which the two sides of an edge are sampled (clamped 1..4);
                               // about the width of an edge ramp, so ~the upscale factor after an upscale
};

/** True if the parameters would change any pixel at all. */
inline bool sharpenEnabled(const SharpenParams& p) { return p.amount > 0.0f || p.push > 0.0f; }

/**
 * Number of real context rows above and below a band that [smartSharpen] needs in order to give a band's own
 * rows exactly the values a whole-image pass would: the edge push's reach plus the unsharp stage's reach (the second
 * reads the first's output). Kotlin asks for it instead of duplicating the arithmetic.
 */
int sharpenReachRows(const SharpenParams& p);

/**
 * Smart sharpening of an ARGB_8888 int buffer (0xAARRGGBB, as Bitmap.getPixels returns). Alpha is preserved.
 * `threads` <= 0 means "all pool threads".
 */
std::vector<int32_t> smartSharpen(const std::vector<int32_t>& pixels, int width, int height,
                                  const SharpenParams& params, int threads);

/**
 * Lanczos-3 upscale by an integer `factor` (1..8) followed by smart sharpening, computed ONLY for output rows
 * [y0, y1) of the (srcW*factor) x (srcH*factor) result.
 *
 *  - `src`/`dst` are RGBA_8888 in memory byte order (R, G, B, A) - what AndroidBitmap_lockPixels exposes - with
 *    the given row strides in bytes. `dst` must be the FULL output size; only rows [y0, y1) are written.
 *  - The function reads whatever extra source rows the filter taps need and, for the sharpening, recomputes up to
 *    sharpenReachRows() extra output rows above and below the band internally. Consequently the pixels written
 *    are bit-identical to what one call over the whole image produces, whatever band split the caller uses:
 *    there are no band seams.
 *  - Edges are handled by replication (clamp-to-edge), the same convention as the other filters.
 *
 * Memory is bounded by the band: roughly 28 bytes per output pixel of (band + context rows).
 */
void upscaleRows(const uint8_t* src, size_t srcStride, int srcW, int srcH,
                 uint8_t* dst, size_t dstStride, int factor, int y0, int y1,
                 const SharpenParams& sharpen, int threads);

}  // namespace novaenhance

#endif  // NOVAENHANCE_UPSCALE_H
