#ifndef NOVAENHANCE_ROW_PARALLEL_H
#define NOVAENHANCE_ROW_PARALLEL_H

#include <algorithm>
#include <functional>

#include "util/thread_pool.h"

namespace novaenhance {

/** Rows handed to one pool job: enough pixels (~8K) that a job is worth scheduling. */
inline int rowsPerJobFor(int width) { return std::max(2, 8192 / std::max(1, width)); }

/**
 * Runs fn(rowBegin, rowEnd) over [0, rows) in blocks on the shared pool and returns when every block is done.
 * Every stage that uses this computes "output row = f(a few input rows)", so blocks never write the same memory and
 * the result does not depend on how rows are split or which thread ran them.
 */
template <typename Fn>
void forRowBlocks(int rows, int rowsPerJob, int threads, Fn&& fn) {
    if (rows <= 0) return;
    const int jobs = (rows + rowsPerJob - 1) / rowsPerJob;
    if (jobs <= 1) {
        fn(0, rows);
        return;
    }
    const std::function<void(int, int)> job = [&](int j, int /*worker*/) {
        fn(j * rowsPerJob, std::min(rows, (j + 1) * rowsPerJob));
    };
    ThreadPool::instance().parallelFor(jobs, threads, job);
}

}  // namespace novaenhance

#endif  // NOVAENHANCE_ROW_PARALLEL_H
