#include "restore.h"

#include <algorithm>
#include <cmath>
#include <cstring>

#include "filters/row_parallel.h"

namespace novaenhance {

namespace {

constexpr int kR = kRestoreRadius;
constexpr int kTaps = 2 * kR + 1;

// BT.601 full-range chroma, without the +128 offset: Cb = (B - Y) * 0.564, Cr = (R - Y) * 0.713.
constexpr float kCbScale = 0.564f;
constexpr float kCrScale = 0.713f;
constexpr float kInvCb = 1.0f / 0.564f;
constexpr float kInvCr = 1.0f / 0.713f;
constexpr float kInvGreen = 1.0f / 0.587f;

// Range-weight tables are indexed by the rounded absolute difference of two planes. Luma spans 0..255; Cb/Cr swing
// at most about +-145, so a difference never exceeds ~290 and 320 entries cover it (larger values clamp to the end).
constexpr int kLumaLut = 256;
constexpr int kChromaLut = 320;

inline int clampi(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }

inline uint32_t toByte(float v) {
    const int i = static_cast<int>(v + 0.5f);
    return static_cast<uint32_t>(i < 0 ? 0 : (i > 255 ? 255 : i));
}

inline int lutIndex(float diff, int last) {
    const int i = static_cast<int>(std::fabs(diff) + 0.5f);
    return i < last ? i : last;
}

/**
 * Weights of one filter tap = spatial * range(luma) * range(Cb) * range(Cr), each a Gaussian, tabulated once per call.
 * Two weight sets: the one that averages LUMA (tight luma range, loose chroma guard) and the one that averages
 * CHROMA (loose luma range, because shading varies inside a flat-coloured area; tight chroma range, so a real colour
 * boundary is never averaged across).
 */
struct Tables {
    float spatial[kTaps];
    float lumaOutLuma[kLumaLut];
    float lumaOutChroma[kChromaLut];
    float chromaOutLuma[kLumaLut];
    float chromaOutChroma[kChromaLut];
};

void fillGaussian(float* table, int size, float sigma) {
    const double twoSigmaSq = 2.0 * static_cast<double>(sigma) * static_cast<double>(sigma);
    for (int i = 0; i < size; ++i) table[i] = static_cast<float>(std::exp(-(static_cast<double>(i) * i) / twoSigmaSq));
}

Tables makeTables(float strength) {
    Tables t;
    const double spatialTwoSigmaSq = 2.0 * (kR / 2.0) * (kR / 2.0);  // sigma = radius / 2
    for (int k = 0; k < kTaps; ++k) {
        const double d = k - kR;
        t.spatial[k] = static_cast<float>(std::exp(-(d * d) / spatialTwoSigmaSq));
    }
    // Tuned on JPEG-damaged line art and photos (tools/restore_verification, README -> "Removing compression artifacts").
    fillGaussian(t.lumaOutLuma, kLumaLut, 3.0f + 9.0f * strength);
    fillGaussian(t.lumaOutChroma, kChromaLut, 40.0f);
    fillGaussian(t.chromaOutLuma, kLumaLut, 14.0f + 12.0f * strength);
    fillGaussian(t.chromaOutChroma, kChromaLut, 5.0f + 12.0f * strength);
    return t;
}

/**
 * One filtered pixel: the weighted mean, over the kTaps neighbours `at(k)` returns ([Y, Cb, Cr, ...] of tap k), of
 * luma (with the luma weights) and of Cb/Cr (with the chroma weights), relative to the centre pixel (cy, ccb, ccr).
 * The centre tap has weight 1, so the denominators are never zero. Taps are summed in the same order for every
 * pixel, which is what makes the result independent of how the image is split into bands or threads.
 */
template <typename At>
inline void smoothPixel(const Tables& t, float cy, float ccb, float ccr, At&& at, float* out) {
    float lumaSum = 0.0f, lumaWeight = 0.0f;
    float cbSum = 0.0f, crSum = 0.0f, chromaWeight = 0.0f;
    for (int k = 0; k < kTaps; ++k) {
        const float* q = at(k);
        const float vy = q[0], vcb = q[1], vcr = q[2];
        const int iy = lutIndex(vy - cy, kLumaLut - 1);
        const int icb = lutIndex(vcb - ccb, kChromaLut - 1);
        const int icr = lutIndex(vcr - ccr, kChromaLut - 1);
        const float spatial = t.spatial[k];
        const float wl = spatial * t.lumaOutLuma[iy] * t.lumaOutChroma[icb] * t.lumaOutChroma[icr];
        const float wc = spatial * t.chromaOutLuma[iy] * t.chromaOutChroma[icb] * t.chromaOutChroma[icr];
        lumaSum += wl * vy;
        lumaWeight += wl;
        cbSum += wc * vcb;
        crSum += wc * vcr;
        chromaWeight += wc;
    }
    out[0] = lumaSum / lumaWeight;
    out[1] = cbSum / chromaWeight;
    out[2] = crSum / chromaWeight;
}

}  // namespace

int restoreReachRows(const RestoreParams& p) { return restoreEnabled(p) ? kRestoreRadius : 0; }

std::vector<int32_t> restoreArtifacts(const std::vector<int32_t>& pixels, int width, int height,
                                      const RestoreParams& params, int threads) {
    const size_t n = static_cast<size_t>(std::max(width, 0)) * static_cast<size_t>(std::max(height, 0));
    if (pixels.empty() || width <= 0 || height <= 0 || pixels.size() != n || !restoreEnabled(params)) return pixels;
    const Tables tables = makeTables(std::min(1.0f, params.strength));
    const int rpj = rowsPerJobFor(width);
    const size_t rowFloats = static_cast<size_t>(width) * 4;

    // 1) RGB -> [Y, Cb, Cr, unused] floats.
    std::vector<float> ycc(n * 4);
    forRowBlocks(height, rpj, threads, [&](int a, int b) {
        for (size_t i = static_cast<size_t>(a) * width; i < static_cast<size_t>(b) * width; ++i) {
            const uint32_t px = static_cast<uint32_t>(pixels[i]);
            const float r = static_cast<float>((px >> 16) & 0xFF);
            const float g = static_cast<float>((px >> 8) & 0xFF);
            const float bl = static_cast<float>(px & 0xFF);
            const float y = 0.299f * r + 0.587f * g + 0.114f * bl;
            float* o = &ycc[i * 4];
            o[0] = y;
            o[1] = (bl - y) * kCbScale;
            o[2] = (r - y) * kCrScale;
            o[3] = 0.0f;
        }
    });

    // 2) Horizontal pass, row by row (a row never reads another row). The row is copied into a padded buffer with
    //    replicated ends, so the tap loop needs no clamping.
    std::vector<float> tmp(n * 4);
    forRowBlocks(height, rpj, threads, [&](int a, int b) {
        std::vector<float> pad((static_cast<size_t>(width) + 2 * kR) * 4);
        for (int y = a; y < b; ++y) {
            const float* row = ycc.data() + static_cast<size_t>(y) * rowFloats;
            for (int i = 0; i < width + 2 * kR; ++i) {
                std::memcpy(&pad[static_cast<size_t>(i) * 4], row + static_cast<size_t>(clampi(i - kR, 0, width - 1)) * 4,
                            4 * sizeof(float));
            }
            float* out = tmp.data() + static_cast<size_t>(y) * rowFloats;
            for (int x = 0; x < width; ++x) {
                const float* c = &pad[static_cast<size_t>(x + kR) * 4];
                smoothPixel(tables, c[0], c[1], c[2],
                            [&](int k) { return &pad[static_cast<size_t>(x + k) * 4]; }, out + static_cast<size_t>(x) * 4);
            }
        }
    });

    // 3) Vertical pass over the horizontally filtered rows (replicated at the top/bottom), straight back to RGB.
    std::vector<int32_t> out(n);
    forRowBlocks(height, rpj, threads, [&](int a, int b) {
        const float* rows[kTaps];
        for (int y = a; y < b; ++y) {
            for (int k = 0; k < kTaps; ++k) {
                rows[k] = tmp.data() + static_cast<size_t>(clampi(y + k - kR, 0, height - 1)) * rowFloats;
            }
            const float* centre = rows[kR];
            for (int x = 0; x < width; ++x) {
                const float* c = centre + static_cast<size_t>(x) * 4;
                float res[3];
                smoothPixel(tables, c[0], c[1], c[2], [&](int k) { return rows[k] + static_cast<size_t>(x) * 4; }, res);

                const float r = res[0] + res[2] * kInvCr;
                const float bl = res[0] + res[1] * kInvCb;
                const float g = (res[0] - 0.299f * r - 0.114f * bl) * kInvGreen;
                const size_t i = static_cast<size_t>(y) * width + x;
                const uint32_t alpha = (static_cast<uint32_t>(pixels[i]) >> 24) & 0xFF;
                out[i] = static_cast<int32_t>((alpha << 24) | (toByte(r) << 16) | (toByte(g) << 8) | toByte(bl));
            }
        }
    });
    return out;
}

}  // namespace novaenhance
