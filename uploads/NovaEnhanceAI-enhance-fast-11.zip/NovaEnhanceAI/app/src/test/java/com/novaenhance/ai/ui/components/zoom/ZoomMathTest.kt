package com.novaenhance.ai.ui.components.zoom

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ZoomMathTest {

    private val delta = 1e-3f

    // ---- how deep zooming goes ----

    @Test
    fun `a 12 MP photo zooms until each of its pixels is 12 screen pixels wide`() {
        // 4000 px fitted into ~984 px is 0.246 screen px per image px; 12 / 0.246
        assertEquals(48.78f, ZoomMath.maxScale(0.246f), 0.01f)
    }

    @Test
    fun `a tiny image still gets the floor`() {
        assertEquals(ZoomMath.MAX_SCALE_FLOOR, ZoomMath.maxScale(3.84f), delta)
    }

    @Test
    fun `a huge image is held to the ceiling`() {
        assertEquals(ZoomMath.MAX_SCALE_CEILING, ZoomMath.maxScale(0.05f), delta)
    }

    @Test
    fun `nonsense sizes fall back to the floor`() {
        assertEquals(ZoomMath.MAX_SCALE_FLOOR, ZoomMath.maxScale(0f), delta)
        assertEquals(ZoomMath.MAX_SCALE_FLOOR, ZoomMath.maxScale(-1f), delta)
        assertEquals(ZoomMath.MAX_SCALE_FLOOR, ZoomMath.maxScale(Float.NaN), delta)
    }

    @Test
    fun `the limit always stays between the floor and the ceiling`() {
        for (fit in listOf(0.001f, 0.01f, 0.1f, 0.5f, 1f, 2f, 10f, 100f)) {
            assertTrue("fit $fit", ZoomMath.maxScale(fit) in ZoomMath.MAX_SCALE_FLOOR..ZoomMath.MAX_SCALE_CEILING)
        }
    }

    // ---- scale limits ----

    @Test
    fun `scale is kept between fit and the limit`() {
        assertEquals(1f, ZoomMath.clampScale(0.5f, 40f), delta)
        assertEquals(40f, ZoomMath.clampScale(100f, 40f), delta)
        assertEquals(5f, ZoomMath.clampScale(5f, 40f), delta)
    }

    @Test
    fun `a limit below fit never forces a zoom-out past fit`() {
        assertEquals(1f, ZoomMath.clampScale(3f, 0.5f), delta)
    }

    // ---- keeping the content on screen ----

    @Test
    fun `content narrower than the viewport stays centred until it outgrows it`() {
        // viewport 1000, content 800: at 1.25x the content is exactly as wide as the viewport
        assertEquals(0f, ZoomMath.clampOffset(300f, 1000f, 800f, 1f), delta)
        assertEquals(0f, ZoomMath.clampOffset(300f, 1000f, 800f, 1.25f), delta)
    }

    @Test
    fun `a pan within the overflow is left alone`() {
        // at 2x the content is 1600 wide: 300 px of overflow each side
        assertEquals(300f, ZoomMath.clampOffset(300f, 1000f, 800f, 2f), delta)
        assertEquals(-300f, ZoomMath.clampOffset(-300f, 1000f, 800f, 2f), delta)
        assertEquals(99f, ZoomMath.clampOffset(99f, 1000f, 800f, 2f), delta)
    }

    @Test
    fun `a pan beyond the overflow is pulled back to the edge`() {
        assertEquals(700f, ZoomMath.clampOffset(5000f, 1000f, 800f, 3f), delta)
        assertEquals(-700f, ZoomMath.clampOffset(-5000f, 1000f, 800f, 3f), delta)
        assertEquals(500f, ZoomMath.clampOffset(700f, 1000f, 1000f, 2f), delta)
    }

    @Test
    fun `content as big as the viewport cannot be panned at fit`() {
        assertEquals(0f, ZoomMath.clampOffset(50f, 1000f, 1000f, 1f), delta)
    }

    // ---- the transform itself ----

    @Test
    fun `no zoom and no pan leaves coordinates where they are`() {
        assertEquals(123f, ZoomMath.toScreen(123f, 1000f, 1f, 0f), delta)
    }

    @Test
    fun `zooming magnifies about the centre of the viewport`() {
        assertEquals(500f, ZoomMath.toScreen(500f, 1000f, 2f, 0f), delta)
        assertEquals(700f, ZoomMath.toScreen(600f, 1000f, 2f, 0f), delta)
        assertEquals(740f, ZoomMath.toScreen(600f, 1000f, 2f, 40f), delta)
    }

    @Test
    fun `zooming about the centre needs no pan`() {
        assertEquals(0f, ZoomMath.offsetFollowing(500f, 500f, 1000f, 0f, 1f, 4f), delta)
    }

    @Test
    fun `a pure pan moves the content by exactly the finger movement`() {
        assertEquals(130f, ZoomMath.offsetFollowing(400f, 430f, 1000f, 100f, 3f, 3f), delta)
    }

    @Test
    fun `zooming about an off-centre point pans so that point stays put`() {
        val offset = ZoomMath.offsetFollowing(800f, 800f, 1000f, 0f, 1f, 2f)
        assertEquals(-300f, offset, delta)
        // the layout coordinate that sat at 800 before the zoom is still at 800 after it
        assertEquals(800f, ZoomMath.toScreen(800f, 1000f, 2f, offset), delta)
    }

    @Test
    fun `the point under the fingers stays under them through any pinch step`() {
        for (viewport in listOf(400f, 1000f)) {
            for (oldScale in listOf(1f, 2.5f, 12f, 40f)) {
                for (newScale in listOf(1f, 2.5f, 12f, 40f)) {
                    for (oldOffset in listOf(-500f, 0f, 700f)) {
                        for (fromFraction in listOf(0.1f, 0.5f, 0.9f)) {
                            for (toFraction in listOf(0.1f, 0.5f, 0.9f)) {
                                val from = viewport * fromFraction
                                val to = viewport * toFraction
                                // the layout coordinate under the fingers before the step
                                val layout = (from - viewport / 2f - oldOffset) / oldScale + viewport / 2f
                                val newOffset = ZoomMath.offsetFollowing(from, to, viewport, oldOffset, oldScale, newScale)
                                assertEquals(to, ZoomMath.toScreen(layout, viewport, newScale, newOffset), 0.05f)
                            }
                        }
                    }
                }
            }
        }
    }

    // ---- double-tap ----

    @Test
    fun `double-tap steps in through the zoom levels`() {
        assertEquals(4f, ZoomMath.nextDoubleTapScale(1f, 80f))
        assertEquals(12f, ZoomMath.nextDoubleTapScale(4f, 80f))
        assertEquals(32f, ZoomMath.nextDoubleTapScale(12f, 80f))
    }

    @Test
    fun `double-tap from the deepest level goes back to fit`() {
        assertNull(ZoomMath.nextDoubleTapScale(32f, 80f))
    }

    @Test
    fun `a level the zoom limit does not allow is skipped`() {
        assertEquals(12f, ZoomMath.nextDoubleTapScale(4f, 16f))
        assertNull(ZoomMath.nextDoubleTapScale(12f, 16f))
        assertNull(ZoomMath.nextDoubleTapScale(1f, 3f))
    }

    @Test
    fun `a zoom just short of a level goes on to the next one`() {
        assertEquals(12f, ZoomMath.nextDoubleTapScale(3.9f, 80f))
        assertEquals(32f, ZoomMath.nextDoubleTapScale(11f, 80f))
    }

    @Test
    fun `tapping repeatedly always ends back at fit`() {
        for (limit in listOf(16f, 30f, 80f)) {
            var scale = 1f
            var taps = 0
            while (true) {
                val next = ZoomMath.nextDoubleTapScale(scale, limit) ?: break
                assertTrue("each tap goes deeper", next > scale)
                assertTrue("never past the limit", next <= limit)
                scale = next
                taps++
                assertTrue("terminates", taps < 10)
            }
        }
    }
}
