package com.novaenhance.ai.ui.viewmodel

import com.novaenhance.ai.training.dataset.SyntheticPhotoResult
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GenerationProgressTest {

    private fun ok(pairs: Int = 3) = SyntheticPhotoResult(pairsCreated = pairs)
    private fun failed(reason: String) = SyntheticPhotoResult(pairsCreated = 0, error = reason)

    // ---- progress ----

    @Test
    fun `a fresh run is at photo 1 with an empty bar`() {
        val progress = GenerationProgress(total = 4)
        assertEquals(1, progress.currentPhoto)
        assertEquals(0f, progress.fraction, 1e-6f)
    }

    @Test
    fun `each finished photo advances the bar and the pair count`() {
        val progress = GenerationProgress(total = 4).after(ok()).after(ok())
        assertEquals(3, progress.currentPhoto)
        assertEquals(0.5f, progress.fraction, 1e-6f)
        assertEquals(6, progress.pairsCreated)
        assertEquals(0, progress.failedPhotos)
    }

    @Test
    fun `the photo number never runs past the last photo`() {
        val progress = GenerationProgress(total = 2).after(ok()).after(ok())
        assertEquals(2, progress.currentPhoto)
        assertEquals(1f, progress.fraction, 1e-6f)
    }

    @Test
    fun `a failed photo is counted and only the first reason is kept`() {
        val progress = GenerationProgress(total = 3).after(failed("first")).after(ok()).after(failed("second"))
        assertEquals(2, progress.failedPhotos)
        assertEquals("first", progress.firstError)
        assertEquals(3, progress.pairsCreated)
    }

    @Test
    fun `an empty selection has no progress instead of dividing by zero`() {
        assertEquals(0f, GenerationProgress(total = 0).fraction, 1e-6f)
    }

    @Test
    fun `a photo result is a success exactly when it has no error`() {
        assertTrue(ok().isSuccess)
        assertTrue(!failed("x").isSuccess)
    }

    // ---- the one-line summary ----

    @Test
    fun `all photos used`() {
        var progress = GenerationProgress(total = 7)
        repeat(7) { progress = progress.after(ok()) }
        assertEquals("Added 21 pairs from 7 photos", progress.summary(stopped = false))
    }

    @Test
    fun `one photo and one pair read in the singular`() {
        val progress = GenerationProgress(total = 1).after(ok(pairs = 1))
        assertEquals("Added 1 pair from 1 photo", progress.summary(stopped = false))
    }

    @Test
    fun `some photos failed`() {
        val progress = GenerationProgress(total = 3)
            .after(ok())
            .after(failed("Could not decode source image"))
            .after(ok())
        assertEquals(
            "Added 6 pairs from 2 of 3 photos - 1 couldn't be used (Could not decode source image)",
            progress.summary(stopped = false)
        )
    }

    @Test
    fun `no photo could be used`() {
        val progress = GenerationProgress(total = 2).after(failed("boom")).after(failed("later"))
        assertEquals("None of the 2 photos could be used (boom)", progress.summary(stopped = false))
    }

    @Test
    fun `a single photo that could not be used`() {
        val progress = GenerationProgress(total = 1).after(failed("Could not decode source image"))
        assertEquals("That photo couldn't be used (Could not decode source image)", progress.summary(stopped = false))
    }

    @Test
    fun `a cancelled run says what was kept`() {
        val progress = GenerationProgress(total = 5).after(ok()).after(ok())
        assertEquals("Stopped - 6 pairs added from 2 of 5 photos", progress.summary(stopped = true))
    }

    @Test
    fun `a cancelled run still mentions a failure`() {
        val progress = GenerationProgress(total = 5).after(ok()).after(failed("x"))
        assertEquals("Stopped - 3 pairs added from 1 of 5 photos - 1 couldn't be used", progress.summary(stopped = true))
    }

    @Test
    fun `a very long reason is shortened`() {
        val summary = GenerationProgress(total = 1).after(failed("x".repeat(200))).summary(stopped = false)
        assertTrue(summary.endsWith("…)"))
        assertTrue("summary was ${summary.length} chars", summary.length < 120)
    }
}
