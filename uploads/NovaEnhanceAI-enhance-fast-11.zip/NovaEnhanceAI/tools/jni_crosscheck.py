"""Cross-checks every Kotlin `external fun nativeX(...)` against its C++ `Java_..._nativeX(JNIEnv*, jobject, ...)`:
same name, same parameter count, same parameter types, same return type. Run from the repo root."""
import re, sys, glob
KT_TO_JNI = {'Int': 'jint', 'Float': 'jfloat', 'Boolean': 'jboolean', 'Long': 'jlong', 'Double': 'jdouble',
             'Unit': 'void', 'IntArray': 'jintArray', 'FloatArray': 'jfloatArray', 'ByteArray': 'jbyteArray', 'Bitmap': 'jobject', 'String': 'jstring'}
cpp = open('app/src/main/cpp/native-lib.cpp').read()
# C++: JNIEXPORT <ret> JNICALL\nJava_<pkg>_<Class>_<fn>(\n JNIEnv* env, jobject, <params>) {
cpp_funcs = {}
for m in re.finditer(r'JNIEXPORT\s+(\w+)\s+JNICALL\s+Java_com_novaenhance_ai_ai_engine_(\w+?)_(native\w+)\s*\((.*?)\)\s*\{', cpp, re.S):
    ret, cls, name, params = m.groups()
    params = re.sub(r'//[^\n]*', '', params)   # strip line comments inside the parameter list
    plist = [p.strip() for p in params.split(',')]
    assert plist[0].startswith('JNIEnv'), (name, plist)
    plist = plist[2:]   # drop JNIEnv*, jobject
    types = [re.split(r'\s+', p)[0] for p in plist if p]
    cpp_funcs[(cls, name)] = (ret, types)
bad = 0; checked = 0
for kt in glob.glob('app/src/main/java/com/novaenhance/ai/ai/engine/*.kt'):
    src = open(kt).read()
    cls_m = re.search(r'\bobject\s+(\w+)', src) or re.search(r'\bclass\s+(\w+)', src)
    for m in re.finditer(r'private\s+external\s+fun\s+(native\w+)\s*\(([^)]*)\)\s*(?::\s*(\w+)\??)?', src):
        name, params, ret = m.groups()
        ret = ret or 'Unit'
        cls = cls_m.group(1)
        plist = [p.strip() for p in params.replace('\n', ' ').split(',') if p.strip()]
        types = []
        for p in plist:
            t = p.split(':')[1].strip().rstrip('?'); types.append(KT_TO_JNI[t])
        kret = KT_TO_JNI.get(ret, ret)
        key = (cls, name)
        checked += 1
        if key not in cpp_funcs:
            print('MISSING in C++:', key); bad += 1; continue
        cret, ctypes = cpp_funcs[key]
        if ctypes != types or cret != kret:
            print('MISMATCH', key, '\n  kotlin:', types, '->', kret, '\n  c++   :', ctypes, '->', cret); bad += 1
print(f'{checked} Kotlin external functions checked against {len(cpp_funcs)} C++ JNI functions: {"ALL MATCH" if bad == 0 else str(bad) + " PROBLEMS"}')
extra = set(cpp_funcs) - {(c, n) for c, n in cpp_funcs if False}
sys.exit(1 if bad else 0)
