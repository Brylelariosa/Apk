// Dev harness (not shipped in the app): the build-11 chain assembled from the SAME native code the app runs, in the
// order EnhancementEngine applies it: restoreArtifacts -> (smartSharpen at 1x | Lanczos upscale + sharpen at factor > 1).
//   pipe_tool in.raw out.raw restoreStrength pushK pushRadius unsharpAmount [factor [sigma [clampRadius [overshoot]]]]
#include "filters/restore.h"
#include "filters/upscale.h"
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <cstdint>
using namespace novaenhance;
int main(int argc, char** argv) {
    if (argc < 7) { fprintf(stderr, "in out restore pushK pushR unsharp [factor]\n"); return 1; }
    FILE* f = fopen(argv[1], "rb"); int w, h; if (fread(&w, 4, 1, f) != 1 || fread(&h, 4, 1, f) != 1) return 2;
    std::vector<int32_t> px((size_t)w * h); if (fread(px.data(), 4, px.size(), f) != px.size()) return 2; fclose(f);
    RestoreParams rp; rp.strength = (float)atof(argv[3]);
    SharpenParams sp; sp.push = (float)atof(argv[4]); sp.pushRadius = atoi(argv[5]); sp.amount = (float)atof(argv[6]);
    sp.sigma = argc > 8 ? (float)atof(argv[8]) : 1.0f; sp.overshoot = argc > 10 ? (float)atof(argv[10]) : 0.0f; sp.clampRadius = argc > 9 ? atoi(argv[9]) : 1;
    const int factor = argc > 7 ? atoi(argv[7]) : 1;
    std::vector<int32_t> r = restoreArtifacts(px, w, h, rp, 0);
    int ow = w, oh = h;
    if (factor > 1) {
        ow = w * factor; oh = h * factor;
        std::vector<uint8_t> src((size_t)w * h * 4), dst((size_t)ow * oh * 4);
        for (size_t i = 0; i < r.size(); ++i) { uint32_t p = (uint32_t)r[i]; src[i*4] = (p>>16)&255; src[i*4+1] = (p>>8)&255; src[i*4+2] = p&255; src[i*4+3] = 255; }
        upscaleRows(src.data(), (size_t)w * 4, w, h, dst.data(), (size_t)ow * 4, factor, 0, oh, sp, 0);
        r.assign((size_t)ow * oh, 0);
        for (size_t i = 0; i < r.size(); ++i) r[i] = (int32_t)((0xFFu << 24) | (dst[i*4] << 16) | (dst[i*4+1] << 8) | dst[i*4+2]);
    } else {
        r = smartSharpen(r, w, h, sp, 0);
    }
    f = fopen(argv[2], "wb"); fwrite(&ow, 4, 1, f); fwrite(&oh, 4, 1, f); fwrite(r.data(), 4, r.size(), f); fclose(f);
    return 0;
}
