"""Metrics and glue for run_eval.py. Needs numpy, scipy-free: numpy, Pillow, opencv-python, scikit-image."""
import os, struct, subprocess
import cv2
import numpy as np
from PIL import Image
from skimage.metrics import structural_similarity as ssim_fn

BIN = os.environ.get('NOVA_BIN', '.')   # directory holding the compiled cur_pipeline and pipe_tool (run.sh sets it)


def load(path):
    return np.asarray(Image.open(path).convert('RGB')).astype(np.float32)


def psnr(x, y):
    m = ((x - y) ** 2).mean()
    return 10 * np.log10(255 ** 2 / max(m, 1e-9))


def ssim(x, y):
    return ssim_fn(x.astype(np.uint8), y.astype(np.uint8), channel_axis=2, data_range=255)


def luma(x):
    return x[..., 0] * .299 + x[..., 1] * .587 + x[..., 2] * .114


def halo(out, clean, r=2):
    """Mean luma excursion outside the CLEAN image's local [min, max] (5x5): halos and ringing. Lower is better."""
    L = luma(clean)
    k = np.ones((2 * r + 1, 2 * r + 1), np.uint8)
    mn, mx, O = cv2.erode(L, k), cv2.dilate(L, k), luma(out)
    return float((np.maximum(O - mx, 0) + np.maximum(mn - O, 0)).mean())


def chroma_rms(out, clean):
    """RMS error of the Cb/Cr planes: colour blotches and colour bleeding. Lower is better."""
    def cc(x):
        return cv2.cvtColor(x.clip(0, 255).astype(np.uint8), cv2.COLOR_RGB2YCrCb).astype(np.float32)[..., 1:]
    return float(np.sqrt(((cc(out) - cc(clean)) ** 2).mean()))


def _write_raw(arr, path):
    a = arr.clip(0, 255).round().astype(np.uint32)
    h, w, _ = a.shape
    argb = (0xFF << 24) | (a[..., 0] << 16) | (a[..., 1] << 8) | a[..., 2]
    with open(path, 'wb') as f:
        f.write(struct.pack('<ii', w, h))
        f.write(argb.astype('<u4').tobytes())


def _read_raw(path):
    with open(path, 'rb') as f:
        w, h = struct.unpack('<ii', f.read(8))
        a = np.frombuffer(f.read(), dtype='<u4').reshape(h, w)
    return np.stack([(a >> 16) & 255, (a >> 8) & 255, a & 255], -1).astype(np.float32)


def _run(tool, img, *args):
    tmp = os.environ.get('TMPDIR', '/tmp')
    i, o = os.path.join(tmp, 'nova_eval_in.raw'), os.path.join(tmp, 'nova_eval_out.raw')
    _write_raw(img, i)
    subprocess.run([os.path.join(BIN, tool), i, o, *map(str, args)], check=True)
    return _read_raw(o)


def build10_1x(img, noise_reduction, sharpness, color=0.0):
    """The build-10 1x chain (5x5 bilateral + unsharp-only sharpen + saturation)."""
    return _run('cur_pipeline', img, noise_reduction, sharpness, color)


def build11(img, restore=0.0, push=0.0, push_radius=1, unsharp=0.0, factor=1, sigma=1.0, clamp_radius=1, overshoot=0.0):
    """The build-11 chain from explicit stage parameters."""
    return _run('pipe_tool', img, restore, push, push_radius, unsharp, factor, sigma, clamp_radius, overshoot)


def build11_engine_mapping(img, noise_reduction, sharpness):
    """Build-11 1x chain with the slider mapping EnhancementEngine uses (keep in sync with EnhancementEngine.kt):
    restore = noiseReduction, push = min(1, 1.6 * sharpness), unsharp = 1.5 * sharpness^2."""
    return build11(img, restore=max(0.0, noise_reduction), push=min(1.0, 1.6 * sharpness) if sharpness > 0 else 0.0,
                   push_radius=1, unsharp=1.5 * sharpness * sharpness if sharpness > 0 else 0.0)
