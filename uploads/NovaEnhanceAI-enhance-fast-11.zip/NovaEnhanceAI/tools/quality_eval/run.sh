#!/usr/bin/env bash
# Rebuilds the two native harnesses and prints the line-art / photo comparison (see run_eval.py).
# Needs g++ and python3 with numpy, Pillow, opencv-python, scikit-image. Desktop only.
set -euo pipefail
cd "$(dirname "$0")"
CPP=../../app/src/main/cpp
OUT=$(mktemp -d)
FLAGS="-std=c++17 -O2 -pthread -I$CPP"
${CXX:-g++} $FLAGS cur_pipeline.cpp $CPP/filters/convolution.cpp $CPP/filters/upscale.cpp $CPP/util/thread_pool.cpp -o "$OUT/cur_pipeline"
${CXX:-g++} $FLAGS pipe_tool.cpp $CPP/filters/restore.cpp $CPP/filters/upscale.cpp $CPP/util/thread_pool.cpp -o "$OUT/pipe_tool"
[ -f testset/toon_clean.png ] || python3 make_testset.py testset
NOVA_BIN="$OUT" python3 run_eval.py testset
