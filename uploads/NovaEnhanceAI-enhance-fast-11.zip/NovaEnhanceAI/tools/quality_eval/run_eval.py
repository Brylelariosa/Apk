"""Prints the numbers quoted in README -> "Cleaner results (build 11)": the build-10 1x chain against the build-11 chain on
synthetic JPEG-damaged line art and on JPEG-damaged photos.  Usage: python3 run_eval.py [testset_dir]"""
import sys, os
import numpy as np
from evalkit import *

d = sys.argv[1] if len(sys.argv) > 1 else 'testset'
P = lambda n: os.path.join(d, n)
sets = {'toon_q20': ('toon_clean.png', 'toon_q20.png'), 'toon_q35': ('toon_clean.png', 'toon_q35.png'),
        'astronaut': ('astronaut_clean.png', 'astronaut_q30.png'), 'cat': ('cat_clean.png', 'cat_q30.png'),
        'coffee': ('coffee_clean.png', 'coffee_q30.png')}
data = {n: (load(P(c)), load(P(g))) for n, (c, g) in sets.items()}
TOONS, PHOTOS = ['toon_q20', 'toon_q35'], ['astronaut', 'cat', 'coffee']


def avg(fn, names):
    rows = []
    for n in names:
        clean, deg = data[n]
        o = fn(deg)
        rows.append((psnr(o, clean), ssim(o, clean), halo(o, clean), chroma_rms(o, clean)))
    return np.mean(rows, axis=0)


def line(label, fn):
    t, p = avg(fn, TOONS), avg(fn, PHOTOS)
    print(f'{label:34s} line art {t[0]:5.2f} dB / {t[1]:.4f} (halo {t[2]:.2f}, chroma {t[3]:.2f})  |  photos {p[0]:5.2f} dB / {p[1]:.4f}')


print('PSNR / SSIM against the clean original (higher is better); halo and chroma error: lower is better.\n')
line('JPEG-damaged input, untouched', lambda g: g)
for nr, sh in ((0.3, 0.3), (0.3, 0.6), (1.0, 1.0)):
    print(f'\nNoise reduction {nr}, Sharpness {sh}:')
    line('  build 10 (5x5 bilateral + unsharp)', lambda g: build10_1x(g, nr, sh))
    line('  build 11 (restore + edge push)', lambda g: build11_engine_mapping(g, nr, sh))
