"""Synthetic webtoon-like ground truth + realistic degradation (blur -> resample -> JPEG q~30, 4:2:0).

  python3 make_testset.py [outdir]     writes toon_clean.png, toon_q{20,35,55}.png, {astronaut,cat,coffee}_{clean,q30}.png
                                       and hr_x{2,4}.png / lr_x{2,4}_q35.png (for the upscale test)
"""
import os, sys
import numpy as np, io, math
from PIL import Image, ImageDraw, ImageFilter
import skimage.data as sd

def cartoon(W=512, H=585, S=4):
    w, h = W*S, H*S
    im = Image.new('RGB', (w, h), (30, 30, 34))
    d = ImageDraw.Draw(im)
    # background vertical gradient (dark grey)
    for y in range(h):
        v = int(28 + 40 * y / h); d.line([(0, y), (w, y)], fill=(v, v, v+4))
    def P(*pts): return [(x*S, y*S) for x, y in pts]
    # hair (spiky) with white outline
    hair = P((60,40),(120,0),(170,30),(230,0),(300,25),(360,0),(420,40),(470,10),(500,80),(480,200),(440,300),(100,300),(40,200))
    d.polygon(hair, fill=(255,255,255))
    inner = P((70,48),(122,12),(170,42),(230,12),(300,37),(360,12),(420,50),(468,24),(488,84),(468,198),(430,290),(110,290),(52,198))
    d.polygon(inner, fill=(96,80,76))
    # hair highlight band
    d.polygon(P((120,60),(300,50),(420,70),(300,110),(160,100)), fill=(124,106,100))
    # face
    d.ellipse([x*S for x in (70,60,470,420)], fill=(238,203,184), outline=(20,16,16), width=6*S//2)
    # cel shadow on lower-left of face
    sh = Image.new('L', (w, h), 0); sd_ = ImageDraw.Draw(sh)
    sd_.ellipse([x*S for x in (40,200,330,470)], fill=255)
    face_mask = Image.new('L', (w, h), 0); ImageDraw.Draw(face_mask).ellipse([x*S for x in (70,60,470,420)], fill=255)
    shadow = Image.composite(Image.new('RGB', (w, h), (222,184,166)), im, Image.fromarray(np.minimum(np.asarray(sh), np.asarray(face_mask))))
    im = shadow; d = ImageDraw.Draw(im)
    d.ellipse([x*S for x in (70,60,470,420)], outline=(20,16,16), width=6*S//2)
    # eyes
    for cx in (170, 360):
        d.polygon(P((cx-80,170),(cx-30,140),(cx+30,142),(cx+85,180),(cx+20,196),(cx-40,192)), fill=(246,244,250))
        d.ellipse([(cx-34)*S, 138*S, (cx+30)*S, 190*S], fill=(16,18,18))
        d.line(P((cx-82,172),(cx-30,140),(cx+30,142),(cx+88,184)), fill=(10,10,10), width=6*S//2)
        d.line(P((cx-60,118),(cx-10,106),(cx+50,120)), fill=(92,60,52), width=3*S//2)
    # blush strokes (low contrast)
    for i in range(4):
        x0 = 90 + i*24; d.line(P((x0,225),(x0+14,262)), fill=(222,150,140), width=3*S//2)
        x1 = 350 + i*24; d.line(P((x1,225),(x1+14,262)), fill=(222,150,140), width=3*S//2)
    # nose tick + mouth
    d.line(P((300,225),(302,243)), fill=(40,30,30), width=2*S)
    d.chord([x*S for x in (150,255,380,350)], 0, 180, fill=(238,142,148), outline=(30,20,22), width=3*S)
    # thin hair strands over forehead
    for i in range(6):
        x0 = 150 + i*45; d.line(P((x0,70),(x0+12,110),(x0+4,140)), fill=(70,56,52), width=2*S)
    return im.resize((W, H), Image.LANCZOS)

def degrade(clean, q=30, blur=0.8, scale=0.8, seed=3):
    W, H = clean.size
    im = clean.filter(ImageFilter.GaussianBlur(blur))
    im = im.resize((int(W*scale), int(H*scale)), Image.BILINEAR).resize((W, H), Image.BILINEAR)
    buf = io.BytesIO(); im.save(buf, 'JPEG', quality=q, subsampling=2); buf.seek(0)
    return Image.open(buf).convert('RGB')

def photo(name):
    arr = {'astronaut': sd.astronaut(), 'cat': sd.chelsea(), 'coffee': sd.coffee()}[name]
    im = Image.fromarray(arr).convert('RGB'); im.thumbnail((512, 512), Image.LANCZOS); return im

if __name__ == '__main__':
    out = sys.argv[1] if len(sys.argv) > 1 else 'testset'
    os.makedirs(out, exist_ok=True)
    P = lambda n: os.path.join(out, n)
    c = cartoon(); c.save(P('toon_clean.png'))
    for q in (20, 35, 55):
        degrade(c, q=q).save(P(f'toon_q{q}.png'))
    for n in ('astronaut', 'cat', 'coffee'):
        p = photo(n); p.save(P(f'{n}_clean.png'))
        buf = io.BytesIO(); p.save(buf, 'JPEG', quality=30, subsampling=2); buf.seek(0)
        Image.open(buf).convert('RGB').save(P(f'{n}_q30.png'))
    # high-resolution ground truth and its low-resolution, blurred, JPEG-damaged version, for the 2x / 4x test
    for f, S in ((2, 4), (4, 2)):
        hr = cartoon(512 * f, 585 * f, S); hr.save(P(f'hr_x{f}.png'))
        lr = hr.resize((512, 585), Image.LANCZOS).filter(ImageFilter.GaussianBlur(0.5))
        buf = io.BytesIO(); lr.save(buf, 'JPEG', quality=35, subsampling=2); buf.seek(0)
        Image.open(buf).convert('RGB').save(P(f'lr_x{f}_q35.png'))
    print('wrote test set to', out)
