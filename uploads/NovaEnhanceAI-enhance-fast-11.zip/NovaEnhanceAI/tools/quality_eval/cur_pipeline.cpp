// Dev harness (not shipped in the app): the build-10 1x classical chain, assembled from the SAME native code the app
// runs - 5x5 bilateral (convolution.cpp) -> unsharp-only smartSharpen (push = 0 keeps the build-10 path bit for bit)
// -> saturation. It is the baseline run_eval.py compares the build-11 chain against.
//   cur_pipeline in.raw out.raw noiseReduction sharpness colorRestoration
#include "filters/convolution.h"
#include "filters/upscale.h"
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <vector>
using namespace novaenhance;
int main(int argc, char** argv) {
    if (argc < 6) { std::fprintf(stderr, "usage: cur_pipeline in.raw out.raw noiseReduction sharpness colorRestoration\n"); return 1; }
    FILE* f = std::fopen(argv[1], "rb"); int w, h;
    if (!f || std::fread(&w, 4, 1, f) != 1 || std::fread(&h, 4, 1, f) != 1) return 2;
    std::vector<int32_t> px(static_cast<size_t>(w) * h);
    if (std::fread(px.data(), 4, px.size(), f) != px.size()) return 2;
    std::fclose(f);
    const float nr = static_cast<float>(std::atof(argv[3])), sharp = static_cast<float>(std::atof(argv[4])), color = static_cast<float>(std::atof(argv[5]));
    std::vector<int32_t> r = px;
    if (nr > 0) r = denoiseBilateral(r, w, h, 1.5f, 10.f + nr * 40.f);
    if (sharp > 0) { SharpenParams p; p.amount = sharp * 1.6f; p.sigma = 1.0f; p.overshoot = 0.05f; p.clampRadius = 1; r = smartSharpen(r, w, h, p, 0); }
    if (color > 0) {
        const float boost = 1.f + color;
        for (auto& v : r) {
            const uint32_t p = static_cast<uint32_t>(v); const int R = (p >> 16) & 255, G = (p >> 8) & 255, B = p & 255; const int L = (R * 299 + G * 587 + B * 114) / 1000;
            auto c = [&](int ch) { const int x = static_cast<int>(L + (ch - L) * boost); return x < 0 ? 0 : (x > 255 ? 255 : x); };
            v = static_cast<int32_t>((0xFFu << 24) | (c(R) << 16) | (c(G) << 8) | c(B));
        }
    }
    f = std::fopen(argv[2], "wb"); std::fwrite(&w, 4, 1, f); std::fwrite(&h, 4, 1, f); std::fwrite(r.data(), 4, r.size(), f); std::fclose(f);
    return 0;
}
