// Verification of the native artifact-removal filter (app/src/main/cpp/filters/restore.cpp):
//
//   1. BAND INVARIANCE  - restoreArtifacts on a band that carries restoreReachRows() real context rows gives, for the
//                         band's own rows, exactly (bit-for-bit) what one whole-image call gives; threads=1 and the
//                         pool agree. This is what keeps BandProcessor seams invisible.
//   2. REFERENCE MATCH  - against a deliberately naive double-precision implementation written from the documented
//                         algorithm (clamped accessors, no padded rows, no tables): at most 1 level of difference.
//   3. PROPERTIES       - what the filter exists to do, checked directly: flat stays flat, hard edges and colour
//                         boundaries survive, colour blotches and ringing ripples are removed, alpha is preserved,
//                         disabled inputs are returned untouched.
//   4. TIMING           - 1024x768 on one thread.
//
//   ./run.sh            full
//   ./run.sh --quick    fewer cases
#include "filters/restore.h"
#include "util/thread_pool.h"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <random>
#include <string>
#include <vector>

using namespace novaenhance;

namespace {

std::mt19937 rng(11);
bool g_ok = true;
int g_cases = 0;

double nowMs() {
    return std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now().time_since_epoch()).count();
}

void report(const char* what, int w, int h, int kind, float strength, const std::string& detail) {
    g_ok = false;
    std::printf("  [FAIL] %-22s %dx%d kind=%d strength=%.2f: %s\n", what, w, h, kind, strength, detail.c_str());
}

inline int32_t argb(uint32_t a, uint32_t r, uint32_t g, uint32_t b) { return static_cast<int32_t>((a << 24) | (r << 16) | (g << 8) | b); }
inline int rOf(int32_t p) { return (static_cast<uint32_t>(p) >> 16) & 255; }
inline int gOf(int32_t p) { return (static_cast<uint32_t>(p) >> 8) & 255; }
inline int bOf(int32_t p) { return static_cast<uint32_t>(p) & 255; }

// kind: 0 noise, 1 flat, 2 gradient, 3 hard edges, 4 JPEG-ish (flat colour + blocky chroma offsets + ringing near an edge)
std::vector<int32_t> makeImage(int w, int h, int kind) {
    std::vector<int32_t> px(static_cast<size_t>(w) * h);
    for (int y = 0; y < h; ++y)
        for (int x = 0; x < w; ++x) {
            int r, g, b;
            uint32_t a = 255;
            switch (kind) {
                case 0: r = rng() & 255; g = rng() & 255; b = rng() & 255; a = 40 + (rng() & 127); break;
                case 1: r = 200; g = 150; b = 120; break;
                case 2: r = (x * 255) / std::max(1, w - 1); g = (y * 255) / std::max(1, h - 1); b = 90; break;
                case 3: r = g = b = (((x / 3) + (y / 3)) & 1) ? 235 : 20; break;
                default: {
                    const int block = ((x / 8) * 7 + (y / 8) * 13) % 5 - 2;      // blocky chroma offsets: -2..2
                    r = 225 + 2 * block; g = 190; b = 170 - 2 * block;
                    if (x > w / 2) { r = g = b = 40; }                            // a hard edge
                    else if (x > w / 2 - 6) { const int rip = ((x + y) % 3 - 1) * 4; r += rip; g += rip; b += rip; }  // ringing
                    r = std::min(255, std::max(0, r)); b = std::min(255, std::max(0, b));
                    break;
                }
            }
            px[static_cast<size_t>(y) * w + x] = argb(a, r, g, b);
        }
    return px;
}

// ---- naive reference --------------------------------------------------------------------------------------------
struct Ycc { double y, cb, cr; };

Ycc toYcc(int32_t p) {
    const double r = rOf(p), g = gOf(p), b = bOf(p);
    const double y = 0.299 * r + 0.587 * g + 0.114 * b;
    return {y, (b - y) * 0.564, (r - y) * 0.713};
}

double gauss(int idx, double sigma) { return std::exp(-(static_cast<double>(idx) * idx) / (2.0 * sigma * sigma)); }
int qIdx(double d, int last) { const int i = static_cast<int>(std::floor(std::fabs(d) + 0.5)); return i < last ? i : last; }

// One 1-D pass along an axis over a plane of Ycc, edges replicated.
std::vector<Ycc> refPass(const std::vector<Ycc>& in, int w, int h, bool horizontal, double s) {
    const int R = kRestoreRadius;
    const double sLumaOutLuma = 3.0 + 9.0 * s, sLumaOutChroma = 40.0, sChromaOutLuma = 14.0 + 12.0 * s, sChromaOutChroma = 5.0 + 12.0 * s;
    std::vector<Ycc> out(in.size());
    for (int y = 0; y < h; ++y)
        for (int x = 0; x < w; ++x) {
            const Ycc c = in[static_cast<size_t>(y) * w + x];
            double ly = 0, lw = 0, cb = 0, cr = 0, cw = 0;
            for (int k = -R; k <= R; ++k) {
                const int xx = horizontal ? std::min(w - 1, std::max(0, x + k)) : x;
                const int yy = horizontal ? y : std::min(h - 1, std::max(0, y + k));
                const Ycc q = in[static_cast<size_t>(yy) * w + xx];
                const double sp = std::exp(-(static_cast<double>(k) * k) / (2.0 * (R / 2.0) * (R / 2.0)));
                const int iy = qIdx(q.y - c.y, 255), icb = qIdx(q.cb - c.cb, 319), icr = qIdx(q.cr - c.cr, 319);
                const double wl = sp * gauss(iy, sLumaOutLuma) * gauss(icb, sLumaOutChroma) * gauss(icr, sLumaOutChroma);
                const double wc = sp * gauss(iy, sChromaOutLuma) * gauss(icb, sChromaOutChroma) * gauss(icr, sChromaOutChroma);
                ly += wl * q.y; lw += wl; cb += wc * q.cb; cr += wc * q.cr; cw += wc;
            }
            out[static_cast<size_t>(y) * w + x] = {ly / lw, cb / cw, cr / cw};
        }
    return out;
}

std::vector<int32_t> refRestore(const std::vector<int32_t>& px, int w, int h, double s) {
    std::vector<Ycc> p(px.size());
    for (size_t i = 0; i < px.size(); ++i) p[i] = toYcc(px[i]);
    p = refPass(p, w, h, true, s);
    p = refPass(p, w, h, false, s);
    std::vector<int32_t> out(px.size());
    for (size_t i = 0; i < px.size(); ++i) {
        const double r = p[i].y + p[i].cr / 0.713, b = p[i].y + p[i].cb / 0.564, g = (p[i].y - 0.299 * r - 0.114 * b) / 0.587;
        auto byte = [](double v) { return static_cast<uint32_t>(std::min(255.0, std::max(0.0, std::floor(v + 0.5)))); };
        out[i] = argb((static_cast<uint32_t>(px[i]) >> 24) & 255, byte(r), byte(g), byte(b));
    }
    return out;
}

// ---- checks -------------------------------------------------------------------------------------------------------
int maxChannelDiff(const std::vector<int32_t>& a, const std::vector<int32_t>& b) {
    int m = 0;
    for (size_t i = 0; i < a.size(); ++i)
        m = std::max({m, std::abs(rOf(a[i]) - rOf(b[i])), std::abs(gOf(a[i]) - gOf(b[i])), std::abs(bOf(a[i]) - bOf(b[i]))});
    return m;
}

void checkCase(int w, int h, int kind, float strength) {
    const auto img = makeImage(w, h, kind);
    RestoreParams p;
    p.strength = strength;
    const auto whole = restoreArtifacts(img, w, h, p, 0);
    const auto one = restoreArtifacts(img, w, h, p, 1);
    ++g_cases;
    if (whole != one) report("threads", w, h, kind, strength, "1 thread and pool disagree");
    for (size_t i = 0; i < img.size(); ++i)
        if ((static_cast<uint32_t>(whole[i]) >> 24) != (static_cast<uint32_t>(img[i]) >> 24)) { report("alpha", w, h, kind, strength, "alpha changed"); break; }

    // reference (naive: skip big images)
    if (static_cast<int64_t>(w) * h <= 1500) {
        const int d = maxChannelDiff(whole, refRestore(img, w, h, strength));
        ++g_cases;
        if (d > 1) report("reference", w, h, kind, strength, "differs from the reference by up to " + std::to_string(d) + " levels");
    }

    // band invariance with the context the Kotlin side asks for
    const int reach = restoreReachRows(p);
    ++g_cases;
    if (reach != kRestoreRadius) report("reach", w, h, kind, strength, "restoreReachRows != kRestoreRadius");
    for (int bandRows : {1, 5, std::max(1, h / 2 + 1)}) {
        for (int y0 = 0; y0 < h; y0 += bandRows) {
            const int y1 = std::min(h, y0 + bandRows);
            const int top = std::max(0, y0 - reach), bottom = std::min(h, y1 + reach);
            const std::vector<int32_t> slice(img.begin() + static_cast<size_t>(top) * w, img.begin() + static_cast<size_t>(bottom) * w);
            const auto res = restoreArtifacts(slice, w, bottom - top, p, 0);
            ++g_cases;
            for (int y = y0; y < y1; ++y) {
                const size_t a = static_cast<size_t>(y - top) * w, b = static_cast<size_t>(y) * w;
                if (!std::equal(res.begin() + a, res.begin() + a + w, whole.begin() + b)) {
                    report("bands", w, h, kind, strength, "band rows " + std::to_string(y0) + ".." + std::to_string(y1) + " differ at row " + std::to_string(y));
                    goto nextCase;
                }
            }
        }
    }
nextCase:;
}

double chromaSpread(const std::vector<int32_t>& px, int w, int x0, int x1, int y0, int y1) {
    // standard deviation of (R - B) over a window: a stand-in for Cb/Cr variation
    double s = 0, s2 = 0; int n = 0;
    for (int y = y0; y < y1; ++y) for (int x = x0; x < x1; ++x) { const double v = rOf(px[static_cast<size_t>(y) * w + x]) - bOf(px[static_cast<size_t>(y) * w + x]); s += v; s2 += v * v; ++n; }
    const double m = s / n; return std::sqrt(std::max(0.0, s2 / n - m * m));
}
double lumaSpread(const std::vector<int32_t>& px, int w, int x0, int x1, int y0, int y1) {
    double s = 0, s2 = 0; int n = 0;
    for (int y = y0; y < y1; ++y) for (int x = x0; x < x1; ++x) { const int32_t p = px[static_cast<size_t>(y) * w + x]; const double v = 0.299 * rOf(p) + 0.587 * gOf(p) + 0.114 * bOf(p); s += v; s2 += v * v; ++n; }
    const double m = s / n; return std::sqrt(std::max(0.0, s2 / n - m * m));
}

void properties() {
    RestoreParams on;
    on.strength = 0.5f;

    // (a) Disabled / invalid inputs come back untouched.
    {
        const auto img = makeImage(20, 12, 0);
        RestoreParams off;
        ++g_cases; if (restoreArtifacts(img, 20, 12, off, 0) != img) report("disabled", 20, 12, 0, 0, "strength 0 must return the input");
        off.strength = -1.0f;
        ++g_cases; if (restoreArtifacts(img, 20, 12, off, 0) != img) report("disabled", 20, 12, 0, -1, "negative strength must return the input");
        off.strength = std::nanf("");
        ++g_cases; if (restoreArtifacts(img, 20, 12, off, 0) != img) report("disabled", 20, 12, 0, 0, "NaN strength must return the input");
        ++g_cases; if (restoreArtifacts(img, 21, 12, on, 0) != img) report("size", 21, 12, 0, 0.5f, "a size mismatch must return the input");
        ++g_cases; if (restoreReachRows(off) != 0) report("reach", 20, 12, 0, 0, "disabled filter must need 0 context rows");
        const std::vector<int32_t> empty;
        ++g_cases; if (!restoreArtifacts(empty, 0, 0, on, 0).empty()) report("empty", 0, 0, 0, 0.5f, "empty input must stay empty");
    }
    // (b) Flat colour stays exactly flat, at every strength, including 1xN and Nx1 images.
    for (float s : {0.05f, 0.5f, 1.0f}) for (auto wh : std::vector<std::pair<int, int>>{{31, 17}, {1, 9}, {9, 1}, {1, 1}}) {
        const auto img = makeImage(wh.first, wh.second, 1);
        RestoreParams p; p.strength = s;
        ++g_cases; if (restoreArtifacts(img, wh.first, wh.second, p, 0) != img) report("flat", wh.first, wh.second, 1, s, "flat colour changed");
    }
    // (c) A hard black/white edge survives (every pixel within 1 level), even at full strength.
    {
        const int w = 36, h = 20; std::vector<int32_t> img(static_cast<size_t>(w) * h);
        for (int y = 0; y < h; ++y) for (int x = 0; x < w; ++x) img[static_cast<size_t>(y) * w + x] = x < w / 2 ? argb(255, 15, 15, 15) : argb(255, 240, 240, 240);
        RestoreParams p; p.strength = 1.0f;
        const auto out = restoreArtifacts(img, w, h, p, 0);
        ++g_cases; if (maxChannelDiff(out, img) > 1) report("edge", w, h, 3, 1.0f, "a hard edge was blurred");
    }
    // (d) A colour boundary of equal brightness (red | green) does not bleed.
    {
        const int w = 40, h = 16; std::vector<int32_t> img(static_cast<size_t>(w) * h);
        for (int y = 0; y < h; ++y) for (int x = 0; x < w; ++x) img[static_cast<size_t>(y) * w + x] = x < w / 2 ? argb(255, 200, 60, 60) : argb(255, 20, 140, 20);
        RestoreParams p; p.strength = 1.0f;
        const auto out = restoreArtifacts(img, w, h, p, 0);
        ++g_cases; if (maxChannelDiff(out, img) > 2) report("colour edge", w, h, 3, 1.0f, "colour bled across an equal-brightness boundary");
    }
    // (e) Blocky chroma blotches in a flat area are strongly reduced; the luma ripples next to an edge too.
    {
        const int w = 64, h = 48; const auto img = makeImage(w, h, 4);
        RestoreParams p; p.strength = 0.5f;
        const auto out = restoreArtifacts(img, w, h, p, 0);
        const double before = chromaSpread(img, w, 4, 20, 8, 40), after = chromaSpread(out, w, 4, 20, 8, 40);
        ++g_cases; if (!(after < 0.5 * before)) report("blotches", w, h, 4, 0.5f, "chroma spread " + std::to_string(before) + " -> " + std::to_string(after) + " (want < half)");
        const double lb = lumaSpread(img, w, w / 2 - 5, w / 2 - 1, 8, 40), la = lumaSpread(out, w, w / 2 - 5, w / 2 - 1, 8, 40);
        ++g_cases; if (!(la < 0.5 * lb)) report("ringing", w, h, 4, 0.5f, "luma ripple " + std::to_string(lb) + " -> " + std::to_string(la) + " (want < half)");
        // ...and the edge itself is intact
        ++g_cases; if (std::abs(rOf(out[static_cast<size_t>(20) * w + w / 2 - 1]) - rOf(img[static_cast<size_t>(20) * w + w / 2 - 1])) > 12 ||
                       std::abs(rOf(out[static_cast<size_t>(20) * w + w / 2 + 3]) - 40) > 1) report("edge intact", w, h, 4, 0.5f, "the edge next to the ripples was damaged");
    }
    // (f) Stronger setting smooths at least as much (monotonic in strength) on a noisy flat patch.
    {
        const int w = 48, h = 40; std::vector<int32_t> img(static_cast<size_t>(w) * h);
        for (auto& p : img) { const int n = static_cast<int>(rng() % 17) - 8; p = argb(255, 150 + n, 130 + n / 2, 110 - n); }
        double prev = 1e9;
        for (float s : {0.1f, 0.4f, 0.8f, 1.0f}) {
            RestoreParams p; p.strength = s;
            const double spread = lumaSpread(restoreArtifacts(img, w, h, p, 0), w, 8, 40, 8, 32);
            ++g_cases; if (spread > prev + 1e-6) report("monotonic", w, h, 0, s, "stronger setting smoothed LESS");
            prev = spread;
        }
    }
}

}  // namespace

int main(int argc, char** argv) {
    const bool quick = argc > 1 && std::string(argv[1]) == "--quick";
    std::printf("artifact-removal verification (%s), pool max threads = %d\n", quick ? "quick" : "full", ThreadPool::instance().maxThreads());
    const std::vector<std::pair<int, int>> sizes = quick ? std::vector<std::pair<int, int>>{{1, 1}, {5, 3}, {17, 13}, {40, 31}}
                                                         : std::vector<std::pair<int, int>>{{1, 1}, {1, 20}, {20, 1}, {5, 3}, {17, 13}, {40, 31}, {33, 64}, {64, 33}, {90, 70}};
    for (const auto& s : sizes)
        for (int kind = 0; kind < (quick ? 3 : 5); ++kind)
            for (float strength : {0.05f, 0.5f, 1.0f}) checkCase(s.first, s.second, kind + (quick && kind == 2 ? 2 : 0), strength);
    properties();

    {  // timing
        const int w = 1024, h = 768; const auto img = makeImage(w, h, 4);
        RestoreParams p; p.strength = 0.5f;
        restoreArtifacts(img, w, h, p, 1);
        const double t0 = nowMs();
        restoreArtifacts(img, w, h, p, 1);
        const double t1 = nowMs();
        restoreArtifacts(img, w, h, p, 0);
        const double t2 = nowMs();
        std::printf("  1024x768 (%.2f MP): threads=1 %.0f ms, threads=pool %.0f ms\n", w * h / 1e6, t1 - t0, t2 - t1);
    }
    std::printf("%d checks: %s\n", g_cases, g_ok ? "ALL PASSED" : "FAILURES (see above)");
    return g_ok ? 0 : 1;
}
