#!/usr/bin/env bash
# Builds and runs the artifact-removal check (see restore_check.cpp). Desktop g++ only.
#   ./run.sh            full
#   ./run.sh --quick    fewer cases
#   SAN=1 ./run.sh      additionally build with AddressSanitizer + UndefinedBehaviorSanitizer
set -euo pipefail
cd "$(dirname "$0")"
CPP=../../app/src/main/cpp
OUT=$(mktemp -d)
FLAGS="-std=c++17 -O2 -pthread -I$CPP"
if [ "${SAN:-0}" = "1" ]; then FLAGS="$FLAGS -g -fsanitize=address,undefined -fno-sanitize-recover=undefined"; fi
${CXX:-g++} $FLAGS restore_check.cpp $CPP/filters/restore.cpp $CPP/util/thread_pool.cpp -o "$OUT/restore_check"
"$OUT/restore_check" "$@"
