# What changed in this build (faster + better enhancement, tuned for the Infinix HOT 11 2022)

Full explanation, measurements and honest limitations: README.md -> "Performance and quality work".
Trained models are unaffected: the network architecture and the checkpoint/parameter layout are unchanged,
so every existing checkpoint loads exactly as before.

## Build 11: cleaner, crisper results - artifact removal + a halo-free edge push + ringing-free upscaling
Request: "anyway to improve" (with before/after screenshots of a compressed manga/webtoon panel).
Trained models are unaffected (network, checkpoint layout and the AI pass are unchanged).

**What the screenshots showed.** The "after" was only a little different from the "before": the enhancement is mostly the
*classical* stages (a freshly trained 44K-parameter network is close to an identity), and those had three weak spots on
lossy line art - (1) colour blotches and mosquito noise survived, because a 5x5 bilateral filter is far smaller than the
8-16 px blocks JPEG/WebP leaves; (2) the unsharp mask can only ADD contrast around an edge, so every strong line got a dark
or bright halo (visible as a dark band outside the white head outline); (3) Lanczos-3 rings next to hard edges when
upscaling, and the unsharp mask then sharpened that ringing.

**What changed** (all native, so it works with every existing checkpoint):
- *Artifact removal* (`filters/restore.{h,cpp}`) replaces the 5x5 bilateral behind the **Noise reduction** slider: a
  separable joint-bilateral on YCbCr, 17 taps per axis. Chroma is averaged widely but only across pixels that look alike in
  luma AND colour (blotches melt, colour never bleeds across a line); luma is averaged only with near-identical pixels
  (ringing ripples vanish, real edges are untouched). The old filter stays in the library (`denoiseBilateral`).
- *Edge push* (`edgePush` in `filters/upscale.cpp`, `SharpenParams.push`) runs before the unsharp stage, driven by the
  **Sharpness** slider: it snaps each pixel of a blurred edge ramp towards the flat colour on its own side, so lines get
  steeper without ever leaving the colours already next to them - no overshoot, no halos, no fringes. The unsharp stage
  stays (halo clamp now strict: overshoot 0) for micro-contrast.
- *Anti-ringing Lanczos*: every upscaled sample is clamped to the range of the 2x2 source pixels around it.
- The Sharpness slider now maps to both stages (`EnhancementEngine.sharpenSpecFor1x` / `sharpenSpecForUpscale`).

**Measured** (`tools/quality_eval/run.sh`; synthetic JPEG-damaged line art and photos against the clean original,
Noise reduction 0.3 / Sharpness 0.3, PSNR dB / SSIM): line art 28.21 / 0.9492 -> 29.27 / 0.9618 (halo energy -14%, colour
error -10%); photos 30.77 / 0.8758 -> 30.55 / 0.8803. At 2x/4x (build-10 upscaler vs build 11, measured once with the
build-10 binary, synthetic panel with a high-resolution original): +0.4 to +0.8 dB at the default and mid slider (-0.15 to
+0.17 dB at Sharpness 1.0), SSIM unchanged within +-0.001, halo energy about 14% lower everywhere - so the big gain is at
1x cleaning, and upscaling mainly gets cleaner edges. Sharpness above ~0.6 on *photos* costs PSNR (the push is made for
line art); README -> "Cleaner results (build 11)".

| File | Status | Purpose |
|---|---|---|
| app/src/main/cpp/filters/restore.{h,cpp} | new | artifact removal: chroma deblocking + luma de-ringing, band-exact, 17-tap separable joint bilateral |
| app/src/main/cpp/filters/row_parallel.h | new | `forRowBlocks` / `rowsPerJobFor` shared by upscale.cpp and restore.cpp (were private to upscale.cpp) |
| app/src/main/cpp/filters/upscale.{h,cpp} | modified | edge push stage, `gaussianPlane()` factored out of the unsharp stage, anti-ringing in the Lanczos passes, `SharpenParams.push/pushRadius`, `sharpenReachRows` = push reach + unsharp reach. The unsharp-only 1x path is untouched (bit-identical to build 10) |
| app/src/main/cpp/native-lib.cpp, CMakeLists.txt | modified | JNI: `nativeRestoreArtifacts`, `nativeRestoreReachRows`; push parameters on `nativeSmartSharpen` / `nativeUpscaleBand` / `nativeSharpenReachRows` |
| ai/engine/NativeImageProcessor.kt | modified | `restoreArtifacts`, `restoreReachRows`, push parameters passed through |
| ai/engine/SharpenSpec.kt | modified | `push`, `pushRadius`; enabled by either stage |
| ai/engine/EnhancementEngine.kt | modified | noise reduction = `restoreArtifacts` (reach asked from native); Sharpness mapped to push + unsharp; no more bilateral constants |
| ai/engine/UpscaleStage.kt | modified | band pixel cap 1M -> 700K (the push needs ~44 B/px of scratch instead of ~28) |
| ai/engine/EnhancementOptions.kt, BandProcessor.kt | modified | KDoc only |
| test/.../EnhancementSharpenTest.kt | modified | new slider mapping, push strength curve, enabled-by-either-stage |
| tools/restore_verification/ | new | band exactness, naive double-precision reference, edge/colour-boundary/blotch/ringing properties, ASan+UBSan (`SAN=1`) |
| tools/upscale_verification/upscale_check.cpp | modified | reference now includes anti-ringing and the push; 1x band-reach test; no-overshoot, steepening and noise-immunity properties |
| tools/quality_eval/ | new | the synthetic test set + the build-10 vs build-11 comparison quoted above |
| tools/jni_crosscheck.py | new | checks every Kotlin `external fun` against its C++ `Java_...` (names, parameter and return types) |

Verified on the host with g++: `tools/upscale_verification` 22256 checks, `tools/restore_verification` 4932 checks (both also
under ASan+UBSan), `tools/filter_verification` unchanged and bit-identical, `native-lib.cpp` type-checks against stub JNI
headers, `tools/jni_crosscheck.py` ALL MATCH. Not compiled or run on a device (no Kotlin/NDK toolchain here): expect to
fix a compile error or two on the first CI build; the Kotlin edits are small and mirror existing code.

## Build 10: deep zoom on the enhanced photo + multi-select for auto-generate
Two requests: "add zoom on enhance photo, very zoom" and "add multiple photos select on auto generate dataset".
Trained models are unaffected (network, checkpoint layout and the enhancement pipeline are unchanged).

**Zoom.** Pinch to zoom the before/after preview (up to ~49x on a 12 MP photo, floor 16x, ceiling 80x), drag to pan, double-tap to
step 4x -> 12x -> 32x -> fit, badge to reset. Both images share one transform; the divider stays put on screen and, while zoomed, is
moved by its line/handle only. Zoom survives re-enhancing the same photo (slider tweaks) and resets for a new photo. Deep zoom draws
crisp pixels. The dataset pair preview dialog gets the same zoom (it reuses BeforeAfterSlider). Not zoomed, nothing changes: a drag
anywhere still moves the divider and the picture is drawn exactly as before.

**Auto-generate.** "Auto-Generate" now takes any number of photos (system photo picker, multi-select). One photo at a time, 3 variants
each, progress panel with "photo X of N", Cancel (finishes the photo in progress, keeps everything made), a failed photo is skipped and
counted, and the result line says what was added. The buttons that also add data are disabled while it runs.

| File | Status | Purpose |
|---|---|---|
| ui/components/zoom/ZoomMath.kt | new | pure zoom/pan arithmetic: limits, clamping, pinch-follows-fingers, double-tap steps |
| ui/components/zoom/ZoomPanState.kt | new | zoom + pan state (read in the draw phase only), animated double-tap / reset |
| ui/components/zoom/ZoomGestures.kt | new | `detectZoomGestures`: one loop for pinch, pan, double-tap and "owner may claim a one-finger drag" |
| ui/components/zoom/ZoomBadge.kt | new | "12.4x - tap to reset" pill; recomposes on its own, not the host |
| ui/components/BeforeAfterSlider.kt | modified | zoom transform in the Canvas, gesture loop replaces detectDragGestures, crisp pixels when magnified, badge |
| ui/components/PairPreviewDialog.kt | modified | title mentions zoom |
| ui/screens/EnhanceScreen.kt | modified | one-line hint under the preview |
| training/dataset/DatasetManager.kt | modified | `addSyntheticPairsFromPhotos`; `addSyntheticPairs` split into `createSyntheticPair`, decodes with `decodeUriBitmap` (EXIF-upright, 24 MP cap), JPEG encoded once per photo, files of a failed pair removed |
| ui/viewmodel/GenerationProgress.kt | new | run progress + summary line (pure, tested) |
| ui/viewmodel/DatasetViewModel.kt | modified | `addSyntheticPairsFromPhotos` / `cancelGeneration`, progress in the UI state, messages carry an error flag (a success note is no longer drawn in the error colour) |
| ui/components/RunProgressPanel.kt | new | reusable title + bar + optional Cancel |
| ui/screens/DatasetManagerScreen.kt | modified | multi-select picker, progress panel, buttons disabled during a run |
| test/.../ZoomMathTest.kt, GenerationProgressTest.kt | new | limits, clamping, the fixed-point property of pinching, double-tap steps; progress and summary lines |

Not compiled or run on a device (no Kotlin/NDK toolchain here): expect to fix a compile error or two on the first build. The zoom
arithmetic and the summary strings were checked by running a Python port of the same formulas and test cases.

## Build 9: sharper upscaling + multi-select photos
Two requests: "can you improve the enhance result more" and "a way to multi select photos".
Trained models are unaffected (network and checkpoint layout unchanged); this build changes only the classical stages around
the network and the Enhance screen. Details, measurements and limits: README.md -> "Upscaling and sharpening".

**Quality.** Found by comparing a 512x658 panel with its 4x result: the CNN runs at 1x and the enlargement was bilinear + a
plain unsharp mask, so edges were soft and compression noise was boosted. Now Lanczos-3 + gated, halo-clamped sharpening done
natively at the final resolution; the same sharpen replaces the unsharp mask at 1x. Output size is capped (Android will not
draw a bitmap over 100 MB), photos over 24 MP are decoded at reduced size, and picked photos are now rotated by their EXIF tag.

**Multi-select.** "Select Images" (multi-select photo picker) -> thumbnail strip -> tap one to preview/tune -> "Enhance & save
all": one photo at a time, saved to the Gallery as it finishes, failures skipped, Cancel keeps what is saved.

| File | Status | Purpose |
|---|---|---|
| cpp/filters/upscale.{h,cpp} | new | Lanczos-3 band upscaler + edge-aware sharpener; output identical for any band split |
| cpp/native-lib.cpp, CMakeLists.txt | modified | JNI: nativeSmartSharpen, nativeSharpenReachRows, nativeUpscaleBand (writes bitmap memory directly) |
| tools/upscale_verification/ | new | bit-exact band invariance, naive double-precision reference, padding/edge cases, timing; `SAN=1` for ASan+UBSan |
| ai/engine/UpscaleStage.kt | new | banded native upscale with cancellation + thermal pacing |
| ai/engine/UpscalePlan.kt | new | largest safe factor for a photo (draw-size and memory cap) |
| ai/engine/SharpenSpec.kt | new | the sharpen parameters shared with the native side |
| ai/engine/BandPacer.kt | new | thermal pacing, extracted from BandProcessor so both band stages share it |
| ai/engine/BandProcessor.kt | modified | uses BandPacer (behaviour unchanged) |
| ai/engine/EnhancementEngine.kt | modified | smart sharpen at 1x, UpscaleStage for 2x/4x, sharpening moved after the upscale, factor cap |
| ai/engine/NativeImageProcessor.kt | modified | smartSharpen, sharpenReachRows, upscaleBand |
| ai/engine/BatchEnhancer.kt | new | decode -> enhance -> save -> free, one photo at a time |
| utils/UriBitmapLoader.kt | new | EXIF-aware decode of picked photos, thumbnails, display names |
| ui/viewmodel/EnhanceViewModel.kt | modified | multi-photo selection state, enhanceAndSaveAll / cancelBatch, latest-pick-wins preview loading |
| ui/components/BatchSelection.kt | new | thumbnail strip, status badges, batch run panel |
| ui/components/LabeledSlider.kt | modified | optional `enabled` |
| ui/screens/EnhanceScreen.kt | modified | multi-select picker, strip, batch panel; settings freeze while a batch runs |
| test/.../UpscalePlanTest.kt, EnhancementSharpenTest.kt | new | factor cap and slider->sharpen mapping |

Not compiled or run on a device (no Kotlin/NDK toolchain here): expect to fix a compile error or two on the first build.

## Crash fix: "Canvas: trying to use a recycled bitmap" (build 8)
Found in the in-app crash log (Infinix X675, Android 11): the app died on the first enhancement that REPLACED a result already
on screen (e.g. after moving an option slider), 17 ms after ENHANCE_END. The log showed `retire ...: deferred, hold count 1`,
then `recycled ... on last release`, then the crash inside BeforeAfterSlider's draw. The ViewModel's hold/retire bookkeeping did
its job; the slider let go of the old bitmap too early: it reported "no longer displayed" from its own composition, but its Canvas
sat inside BoxWithConstraints, a separate composition that is updated on its own schedule, so the old bitmap was recycled while
the Canvas still held a draw lambda that captured it. Likely trigger (inferred from the log, not reproduced): a finished
enhancement flips isProcessing, the progress overlay goes away and that layer is re-recorded in the same frame.

| File | Status | Purpose |
|---|---|---|
| ui/components/BeforeAfterSlider.kt | modified | root-cause fix: one plain composition (Box, not BoxWithConstraints) so the new draw lambda is installed before the old bitmap is released; draw-time `isRecycled` guard (skips the frame and logs once instead of crashing); the divider no longer recomposes while dragging |
| utils/ResourceRetirement.kt | new | the hold / retire / dispose bookkeeping, extracted from EnhanceViewModel as a reusable class (identity-based, counted holds, `withHold`) |
| ui/viewmodel/EnhanceViewModel.kt | modified | uses ResourceRetirement; same behaviour, ~90 fewer lines |

## In-app crash log (added after build 6)
Crash diagnosis with no PC/adb/root: Settings -> View Crash Log, and a prompt at launch if the last run ended badly.
It also recovers crashes no in-process code can catch (native/C++ crashes, Android's low-memory kills) on the NEXT launch,
from Android's own exit record (Android 11+: reason, signal number, RAM held) plus an on-disk log of what the app was doing,
band by band, when it died. Copy / Share / Clear buttons; written, NOT compiled or run (no Kotlin toolchain here).

| File | Status | Purpose |
|---|---|---|
| utils/PersistentLog.kt | new | append-only on-disk log that survives the process dying; one file per run + the previous run |
| utils/ProcessExitHistory.kt | new | reads ActivityManager.getHistoricalProcessExitReasons (Android 11+) and explains it in plain English |
| utils/MemoryStats.kt | new | one-line java/native/system memory snapshot used in the breadcrumbs |
| utils/CrashReporter.kt | modified | still writes last_crash.txt on Java crashes; now also checks how the previous run ended and builds the log text |
| utils/NovaLog.kt | modified | every line is also written to PersistentLog; new `breadcrumb()` (disk only) for per-band / per-filter markers |
| ui/screens/CrashLogScreen.kt | new | the screen: Copy / Share / Clear |
| ui/navigation/NovaNavHost.kt, NovaDestinations.kt | modified | route + the "app stopped unexpectedly" prompt |
| ui/screens/SettingsScreen.kt | modified | "View Crash Log" button (screen is now scrollable) |
| ui/viewmodel/EnhanceViewModel.kt, ai/engine/EnhancementEngine.kt, BandProcessor.kt | modified | ENHANCE_BEGIN/END/FAIL/CANCEL markers + per-band and per-filter breadcrumbs with memory use |
| app/proguard-rules.pro | modified | keep names + line numbers (`-dontobfuscate`) so release stack traces are readable on the phone |

## Native (C++)  app/src/main/cpp
| File | Status | Purpose |
|---|---|---|
| nn/simd.h | new | 4-lane SIMD layer: NEON AArch64, NEON ARMv7, portable fallback |
| nn/conv_kernels.{h,cpp} | new | register-blocked 3x3 conv kernels (forward, gated backward-data, weight-gradient) |
| nn/weights.{h,cpp} | new | repack flat params into kernel layouts (checkpoint format untouched) |
| nn/inference.{h,cpp} | new | fused streaming whole-image inference, column strips, seam-free |
| nn/training.{h,cpp} | new | parallel forward/backward over (sample x row-band) jobs |
| util/thread_pool.{h,cpp} | new | persistent worker pool, dynamic job scheduling (big.LITTLE friendly) |
| nn/network.{h,cpp} | modified | slim front door: init + optimizer; delegates to the above. Public API unchanged (trainStep gains a defaulted `threads`) |
| filters/convolution.{h,cpp} | modified | bilateral LUTs, blur fast path, row-parallel; output bit-identical |
| native-lib.cpp | modified | new JNI: nativeInferRegion, threads for train step, workspace release, backend name; image ceiling 4096 -> 16384 |
| CMakeLists.txt, ../../build.gradle.kts | modified | new sources; -O3 in every build type; NEON forced on armeabi-v7a |

## Kotlin  app/src/main/java/com/novaenhance/ai
| File | Status | Purpose |
|---|---|---|
| ai/engine/BandProcessor.kt | new | seam-free band-by-band processing (replaces TileProcessor) |
| ai/engine/TileProcessor.kt | removed | superseded by BandProcessor |
| ai/engine/EnhancementEngine.kt | modified | uses bands + whole-band native inference; same public API |
| ai/engine/NativeNeuralEngine.kt, NovaModelEngine.kt | modified | inferRegion, thread budget, workspace release, backend name |
| ai/engine/PixelBufferOps.kt | modified | cropRect, transformSquare (rotate/mirror augmentation) |
| training/trainer/TrainingPatchLoader.kt | new | background prefetch, 4 augmented patches per decoded crop |
| training/trainer/ModelTrainer.kt, AdaptiveTrainingController.kt | modified | uses the loader and thread budget; frees native workspace after a session |
| utils/ComputeBudget.kt | new | thread counts per workload (8 enhance / 6 train on an 8-core phone) |
| utils/Constants.kt, DiagnosticsReport.kt, ThermalGovernor.kt, ... | modified | new constants, "Native kernels:" line in debug info, doc updates |

## Tests and tooling
- app/src/test: PixelBufferOpsTest (+8 tests), ComputeBudgetTest (new), ResourceRetirementTest (new, 11 tests) - written, NOT run (no Kotlin toolchain here;
  the retirement logic itself was checked by running a Java port of the test cases).
- tools/nn_verification: run_all.sh, kernel_check, equivalence_check, bench, neon_shim.h, reference_network.cpp.
- tools/filter_verification: bit-exact filter check against the original implementation.
