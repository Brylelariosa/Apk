package com.hzcm.duelforge.engine

import com.hzcm.duelforge.model.*

/**
 * BATTLE RULES (v1):
 *  - Attack Position monster attacks an opponent's Attack Position monster: higher ATK
 *    destroys the lower one and the difference is dealt as damage to the loser's
 *    controller. Equal ATK: both destroyed, no damage.
 *  - Attack Position monster attacks an opponent's Defense Position monster: compare
 *    attacker's ATK to defender's DEF. Attacker ATK greater than DEF: defender destroyed,
 *    no damage to either side. Attacker ATK less than DEF: defender survives, attacker
 *    takes the difference as damage (no destruction). Equal: nothing happens.
 *  - Direct attacks (no monsters on the opponent's field) deal the attacker's full ATK
 *    as damage.
 *  - A face-down Defense Position monster that's attacked is flipped face-up first
 *    (triggering any FLIP effect) before damage is calculated.
 */

/** True if [attacker] could declare an attack on [target] (or, if [target] is null, attack directly) right now. */
fun GameEngine.canDeclareAttack(attacker: CardInstance, target: CardInstance?): Boolean {
    if (state.gameOver) return false
    if (state.chain.isNotEmpty() || state.pendingHumanPriority != null) return false
    if (state.phase != Phase.BATTLE) return false
    if (attacker.controller != state.turnPlayer) return false
    if (attacker.location != Location.MONSTER_ZONE || !attacker.faceUp) return false
    if (attacker.battlePosition != BattlePosition.ATTACK) return false
    if (attacker.hasAttackedThisTurn && attacker.extraAttacksAllowed <= 0) return false

    val opponentMonsters = state.field(attacker.controller.opponent()).monsters()
    return if (target == null) {
        opponentMonsters.isEmpty()
    } else {
        target.controller == attacker.controller.opponent() && target.location == Location.MONSTER_ZONE
    }
}

/**
 * Declares an attack. Marks the attacker as having attacked (consuming an "extra attack"
 * grant instead, if one is available), opens a priority window for Quick responses, then
 * resolves combat damage.
 */
fun GameEngine.declareAttack(attacker: CardInstance, target: CardInstance?, onDone: () -> Unit = {}): Boolean {
    if (!canDeclareAttack(attacker, target)) { onDone(); return false }

    state.lastEvent = GameEvent.AttackDeclared(attacker, target)
    val targetText = if (target != null) " ${target.card.name}" else " directly"
    state.addLog("${displayName(attacker.controller)}'s ${attacker.card.name} attacks$targetText!")

    if (attacker.hasAttackedThisTurn) {
        attacker.extraAttacksAllowed = (attacker.extraAttacksAllowed - 1).coerceAtLeast(0)
    } else {
        attacker.hasAttackedThisTurn = true
    }

    openPriorityWindow(attacker.controller) {
        resolveBattleDamage(attacker, target, onDone)
    }
    return true
}

private fun GameEngine.resolveBattleDamage(attacker: CardInstance, target: CardInstance?, onDone: () -> Unit) {
    fun finish() {
        state.currentBattleTargetWasFaceDown = false
        onDone()
    }

    if (state.gameOver) { finish(); return }
    // The attacker may have been removed from the field by a chain response (e.g. destroyed).
    if (attacker.location != Location.MONSTER_ZONE) { finish(); return }

    if (target == null) {
        state.currentBattleTargetWasFaceDown = false
        val dmg = computeAtk(attacker)
        val defenderField = state.field(attacker.controller.opponent())
        defenderField.lifePoints -= dmg
        state.addLog("Direct attack! ${displayName(attacker.controller.opponent())} takes $dmg damage. (LP: ${defenderField.lifePoints})")
        checkWinConditions()
        finish()
        return
    }

    // The target may also have been removed already by a chain response.
    if (target.location != Location.MONSTER_ZONE) { finish(); return }

    val flipNeeded = !target.faceUp
    state.currentBattleTargetWasFaceDown = flipNeeded
    if (flipNeeded) {
        target.faceUp = true
        state.addLog("${target.card.name} is flipped face-up!")
    }

    fun afterFlip(then: () -> Unit) {
        if (flipNeeded) triggerFlipEffects(target, then) else then()
    }

    afterFlip {
        if (state.gameOver) { finish(); return@afterFlip }
        if (attacker.location != Location.MONSTER_ZONE || target.location != Location.MONSTER_ZONE) { finish(); return@afterFlip }

        val attackerAtk = computeAtk(attacker)
        val attackerController = attacker.controller
        val targetController = target.controller

        when (target.battlePosition) {
            BattlePosition.ATTACK -> {
                val targetAtk = computeAtk(target)
                when {
                    attackerAtk > targetAtk -> {
                        val dmg = attackerAtk - targetAtk
                        destroyCard(target, byBattle = true) {
                            if (!state.gameOver) {
                                state.field(targetController).lifePoints -= dmg
                                state.addLog("${displayName(targetController)} takes $dmg damage. (LP: ${state.field(targetController).lifePoints})")
                                checkWinConditions()
                            }
                            finish()
                        }
                    }
                    attackerAtk < targetAtk -> {
                        val dmg = targetAtk - attackerAtk
                        destroyCard(attacker, byBattle = true) {
                            if (!state.gameOver) {
                                state.field(attackerController).lifePoints -= dmg
                                state.addLog("${displayName(attackerController)} takes $dmg damage. (LP: ${state.field(attackerController).lifePoints})")
                                checkWinConditions()
                            }
                            finish()
                        }
                    }
                    else -> {
                        state.addLog("Both monsters are destroyed!")
                        destroyCard(attacker, byBattle = true) {
                            destroyCard(target, byBattle = true, onDone = { finish() })
                        }
                    }
                }
            }
            BattlePosition.DEFENSE -> {
                val targetDef = computeDef(target)
                when {
                    attackerAtk > targetDef -> {
                        destroyCard(target, byBattle = true, onDone = { finish() })
                    }
                    attackerAtk < targetDef -> {
                        val dmg = targetDef - attackerAtk
                        state.field(attackerController).lifePoints -= dmg
                        state.addLog("${attacker.card.name} bounces off ${target.card.name}! ${displayName(attackerController)} takes $dmg damage. (LP: ${state.field(attackerController).lifePoints})")
                        checkWinConditions()
                        finish()
                    }
                    else -> {
                        state.addLog("${attacker.card.name} bounces off ${target.card.name} - no damage either way.")
                        finish()
                    }
                }
            }
        }
    }
}
