package com.hzcm.duelforge.data

import com.hzcm.duelforge.engine.*
import com.hzcm.duelforge.model.*

/**
 * Maps a card's [Card.id] to the [CardEffect]s it has. cards.json stays pure data
 * (name/stats/image); all gameplay logic lives here. To give a card an effect:
 *  1. Set its `monsterCategory` to "EFFECT" (or leave Spells/Traps as-is) in cards.json.
 *  2. Add an entry below keyed by the card's id, with one [CardEffect] per ability.
 *
 * [CardEffect.id] (distinct from the card's id) is only used for once-per-turn tracking
 * via [CardInstance.effectUsedThisTurn] — it just needs to be unique per ability.
 *
 * ── Shared effect factories ──────────────────────────────────────────────────────────────
 * Common behaviors (draw-on-summon, gain-LP-on-flip, continuous stat buffs, etc.) are
 * implemented ONCE as private factory functions below and reused across cards. If you need
 * to fix or extend a shared behavior, change the factory — every card using it updates
 * automatically. To add a new card with "draw 1 on Normal Summon", just write:
 *   "your_card_id" to listOf(drawOnNormalSummon(1))
 */
object EffectRegistry {

    private val registry: Map<String, List<CardEffect>> = mapOf(

        // ── Ironclad Defender: FLIP - gain 1000 LP ─────────────────────────────────────
        "ironclad_defender" to listOf(
            gainLPOnFlip(1000)
        ),

        // ── Stormcaller Falcon: Trigger - draw 1 on Normal Summon ──────────────────────
        "stormcaller_falcon" to listOf(
            drawOnNormalSummon(count = 1)
        ),

        // ── Crimson War Wyrm: Ignition - halve an opponent monster's ATK until EOT ──────
        "crimson_war_wyrm" to listOf(
            CardEffect(
                id = "crimson_war_wyrm_ignition",
                timing = EffectTiming.IGNITION,
                description = "Target 1 monster your opponent controls; halve its ATK until the end of this turn.",
                oncePerTurn = true,
                canActivate = { engine, source ->
                    source.location == Location.MONSTER_ZONE && source.faceUp &&
                        engine.state.field(source.controller.opponent()).monsters().isNotEmpty()
                },
                targetSelector = { engine, source -> engine.state.field(source.controller.opponent()).monsters() },
                resolve = { engine, _, targets ->
                    targets.firstOrNull()?.let { target ->
                        val halved = engine.computeAtk(target) / 2
                        target.atkModifier -= halved
                        engine.state.addLog("${target.card.name}'s ATK is halved until the end of this turn!")
                    }
                }
            )
        ),

        // ── Tactical Reinforcement: Normal Spell - draw 2, discard 1 ───────────────────
        "tactical_reinforcement" to listOf(
            CardEffect(
                id = "tactical_reinforcement_effect",
                timing = EffectTiming.NORMAL,
                description = "Draw 2 cards, then discard 1 card.",
                canActivate = { engine, source -> engine.state.field(source.controller).deck.size >= 2 },
                resolve = { engine, source, _ ->
                    val controller = source.controller
                    engine.drawCards(controller, 2)
                    engine.requestDiscard(controller, 1, "Tactical Reinforcement: choose 1 card to discard") { discarded ->
                        engine.state.addLog("${engine.displayName(controller)} discards ${discarded.joinToString { it.card.name }}.")
                    }
                }
            )
        ),

        // ── Fusion Catalyst: Normal Spell - Fusion Summon from the Extra Deck ───────────
        "fusion_catalyst" to listOf(
            CardEffect(
                id = "fusion_catalyst_effect",
                timing = EffectTiming.NORMAL,
                description = "Fusion Summon 1 Fusion Monster from your Extra Deck using monsters you control as material.",
                canActivate = { engine, source -> engine.canFusionSummon(source.controller) },
                resolve = { engine, source, _ -> engine.performFusionSummon(source.controller) }
            )
        ),

        // ── Battlefield Overgrowth: Field Spell ────────────────────────────────────────
        // The NORMAL entry handles "activating from hand". The CONTINUOUS entry applies the
        // +200 ATK buff via GameEngine.computeAtk() — no engine code changes needed to
        // add future field-spell buffs; just supply an atkBonus lambda here.
        "battlefield_overgrowth" to listOf(
            CardEffect(
                id = "battlefield_overgrowth_activate",
                timing = EffectTiming.NORMAL,
                description = "All EARTH monsters on the field gain 200 ATK.",
                canActivate = { _, _ -> true },
                resolve = { engine, source, _ ->
                    engine.state.addLog("${engine.displayName(source.controller)}'s Field Spell empowers all EARTH monsters!")
                }
            ),
            earthAtkBuff(amount = 200)
        ),

        // ── Rapid Strike: Quick-Play Spell - grant a monster a second attack ─────────────
        "rapid_strike" to listOf(
            CardEffect(
                id = "rapid_strike_effect",
                timing = EffectTiming.QUICK,
                description = "Target 1 of your face-up Attack Position monsters that has already attacked this turn; it can attack again this Battle Phase.",
                canActivate = { engine, source -> engine.state.phase == Phase.BATTLE && rapidStrikeTargets(engine, source).isNotEmpty() },
                targetSelector = { engine, source -> rapidStrikeTargets(engine, source) },
                resolve = { engine, _, targets ->
                    targets.firstOrNull()?.let { target ->
                        target.extraAttacksAllowed += 1
                        engine.state.addLog("${target.card.name} can attack again this Battle Phase!")
                    }
                }
            )
        ),

        // ── Shield Wall: Continuous Trap - once per turn, force attacked monster to Defense
        "shield_wall" to listOf(
            CardEffect(
                id = "shield_wall_activate",
                timing = EffectTiming.QUICK,
                description = "Activate this card.",
                canActivate = { _, source -> !source.faceUp },
                resolve = { engine, source, _ ->
                    engine.state.addLog("${source.card.name} is activated and remains face-up on the field.")
                }
            ),
            CardEffect(
                id = "shield_wall_effect",
                timing = EffectTiming.QUICK,
                description = "Change the attacked monster to Defense Position.",
                oncePerTurn = true,
                canActivate = { engine, source ->
                    source.faceUp && shieldWallTarget(engine, source) != null
                },
                targetSelector = { engine, source -> listOfNotNull(shieldWallTarget(engine, source)) },
                resolve = { engine, _, targets ->
                    targets.firstOrNull()?.let { target ->
                        target.battlePosition = BattlePosition.DEFENSE
                        engine.state.addLog("${target.card.name} is switched to Defense Position!")
                    }
                }
            )
        ),

        // ── Reversal Ambush: Normal Trap - destroy the attacking monster ────────────────
        "reversal_ambush" to listOf(
            CardEffect(
                id = "reversal_ambush_effect",
                timing = EffectTiming.QUICK,
                description = "Destroy the attacking monster.",
                canActivate = { engine, source ->
                    !source.faceUp && attackingMonster(engine, source) != null
                },
                targetSelector = { engine, source -> listOfNotNull(attackingMonster(engine, source)) },
                resolve = { engine, _, targets ->
                    targets.firstOrNull()?.let { target -> engine.destroyCard(target) }
                }
            )
        ),

        // ── Negation Barrier: Counter Trap - negate and destroy a Spell/Monster Effect ──
        "negation_barrier" to listOf(
            CardEffect(
                id = "negation_barrier_effect",
                timing = EffectTiming.QUICK,
                description = "Negate the activation of a Spell Card or Monster Effect, then destroy it.",
                canActivate = { engine, source ->
                    !source.faceUp && engine.state.chain.isNotEmpty() &&
                        engine.state.chain.last().source.card.cardType != CardType.TRAP
                },
                targetSelector = { engine, _ -> listOfNotNull(engine.state.chain.lastOrNull()?.source) },
                resolve = { engine, _, targets ->
                    targets.firstOrNull()?.let { target ->
                        target.isNegated = true
                        engine.state.addLog("${target.card.name}'s activation is negated!")
                        engine.destroyCard(target)
                    }
                }
            )
        ),

        // ── Sentinel of the Sealed Gate: Quick Effect - discard to negate+destroy a Trap
        "sentinel_of_the_sealed_gate" to listOf(
            CardEffect(
                id = "sentinel_quick",
                timing = EffectTiming.QUICK,
                description = "Discard 1 card to negate the activation of a Trap Card, then destroy it.",
                oncePerTurn = true,
                canActivate = { engine, source ->
                    source.location == Location.MONSTER_ZONE && source.faceUp &&
                        engine.state.chain.isNotEmpty() &&
                        engine.state.chain.last().source.card.cardType == CardType.TRAP &&
                        engine.state.field(source.controller).hand.isNotEmpty()
                },
                targetSelector = { engine, _ -> listOfNotNull(engine.state.chain.lastOrNull()?.source) },
                payCost = { engine, source ->
                    val hand = engine.state.field(source.controller).hand
                    if (hand.isEmpty()) {
                        false
                    } else {
                        val discard = hand.last()
                        engine.sendToGraveyard(discard)
                        engine.state.addLog("${engine.displayName(source.controller)} discards ${discard.card.name}.")
                        true
                    }
                },
                resolve = { engine, _, targets ->
                    targets.firstOrNull()?.let { target ->
                        target.isNegated = true
                        engine.state.addLog("${target.card.name}'s activation is negated!")
                        engine.destroyCard(target)
                    }
                }
            )
        ),

        // ── Spark Imp: Ignition - tribute self to inflict 500 damage ───────────────────
        "spark_imp" to listOf(
            inflictDamageOnSelfTribute(damage = 500)
        ),

        // ── 3-Hump Lacooda: Ignition - tribute 2 of 3 Lacoodas to draw 3 ───────────────
        "three_hump_lacooda" to listOf(
            CardEffect(
                id = "three_hump_lacooda_ignition",
                timing = EffectTiming.IGNITION,
                description = "Tribute 2 other 3-Hump Lacoodas to draw 3 cards (need 3 face-up).",
                oncePerTurn = true,
                canActivate = { engine, source ->
                    source.location == Location.MONSTER_ZONE && source.faceUp &&
                        engine.state.field(source.controller).monsters()
                            .count { it.card.id == "three_hump_lacooda" && it.faceUp } >= 3
                },
                payCost = { engine, source ->
                    val tributes = engine.state.field(source.controller).monsters()
                        .filter { it.card.id == "three_hump_lacooda" && it.faceUp && it !== source }
                        .take(2)
                    if (tributes.size < 2) {
                        false
                    } else {
                        tributes.forEach { engine.sendToGraveyard(it) }
                        engine.state.addLog("${engine.displayName(source.controller)} tributes 2 \"3-Hump Lacooda\".")
                        true
                    }
                },
                resolve = { engine, source, _ ->
                    engine.drawCards(source.controller, 3)
                    engine.state.addLog("${engine.displayName(source.controller)} draws 3 cards!")
                }
            )
        ),

        // ── Glacier Hound: Trigger - draw 1 if destroyed by battle ─────────────────────
        "glacier_hound" to listOf(
            drawIfDestroyedByBattle(count = 1)
        ),

        // ── 4-Starred Ladybug of Doom: FLIP - destroy all Level 4 opponent monsters ────
        "four_starred_ladybug_of_doom" to listOf(
            CardEffect(
                id = "four_starred_ladybug_of_doom_flip",
                timing = EffectTiming.FLIP,
                description = "Destroy all Level 4 monsters your opponent controls.",
                canActivate = { _, _ -> true },
                resolve = { engine, source, _ ->
                    val targets = engine.state.field(source.controller.opponent()).monsters().filter { it.card.level == 4 }
                    if (targets.isEmpty()) {
                        engine.state.addLog("${source.card.name} flips up, but there are no Level 4 monsters to destroy.")
                    } else {
                        engine.state.addLog("${engine.displayName(source.controller)} destroys ${targets.size} Level 4 monster(s).")
                        targets.forEach { engine.destroyCard(it) }
                    }
                }
            )
        ),

        // ── 8-Claws Scorpion: self-set + battle boost against face-down monsters ───────
        "eight_claws_scorpion" to listOf(
            CardEffect(
                id = "eight_claws_scorpion_ignition",
                timing = EffectTiming.IGNITION,
                description = "Once per turn, you can flip this card into face-down Defense Position.",
                oncePerTurn = true,
                canActivate = { _, source ->
                    source.location == Location.MONSTER_ZONE && source.faceUp && source.battlePosition == BattlePosition.ATTACK
                },
                resolve = { engine, source, _ ->
                    source.faceUp = false
                    source.battlePosition = BattlePosition.DEFENSE
                    source.positionChangedThisTurn = true
                    engine.state.addLog("${source.card.name} flips itself face-down in Defense Position.")
                }
            ),
            CardEffect(
                id = "eight_claws_scorpion_attack_boost",
                timing = EffectTiming.CONTINUOUS,
                description = "When this card attacks an opponent's face-down Defense Position monster, its ATK becomes 2400 during damage calculation only.",
                canActivate = { _, _ -> false },
                resolve = { _, _, _ -> },
                atkBonus = { engine, source, target ->
                    if (source.card.id == "eight_claws_scorpion" &&
                        target === source &&
                        source.location == Location.MONSTER_ZONE &&
                        source.faceUp &&
                        source.battlePosition == BattlePosition.ATTACK &&
                        engine.state.currentBattleTargetWasFaceDown
                    ) 2100 else 0
                }
            )
        ),

        // ── A Cat of Ill Omen: FLIP - stack a Trap from Deck, or add it with Necrovalley ─
        "a_cat_of_ill_omen" to listOf(
            CardEffect(
                id = "a_cat_of_ill_omen_flip",
                timing = EffectTiming.FLIP,
                description = "Choose 1 Trap from your Deck and place it on top of your Deck, or, if \"Necrovalley\" is on the field, you can add that Trap to your hand instead.",
                canActivate = { engine, source ->
                    source.location == Location.MONSTER_ZONE && source.faceUp &&
                        engine.state.field(source.controller).deck.any { it.card.cardType == CardType.TRAP }
                },
                resolve = { engine, source, _ ->
                    val field = engine.state.field(source.controller)
                    val trap = field.deck.firstOrNull { it.card.cardType == CardType.TRAP }
                    if (trap == null) {
                        engine.state.addLog("${source.card.name} finds no Trap cards in the Deck.")
                    } else if (engine.isNecrovalleyOnField()) {
                        engine.addToHand(trap)
                        engine.state.addLog("${engine.displayName(source.controller)} adds ${trap.card.name} to the hand.")
                    } else {
                        engine.placeOnTopOfDeck(trap)
                        engine.state.addLog("${engine.displayName(source.controller)} places ${trap.card.name} on top of the Deck.")
                    }
                }
            )
        )
    )

    fun effectsFor(cardId: String): List<CardEffect> = registry[cardId] ?: emptyList()

    /** All card IDs that have at least one registered effect. Used by the debug screen. */
    fun allEffectCardIds(): Set<String> = registry.keys

    // ──────────────────────────────────────────────────────────────────────────────────────
    // Shared effect factories
    // Implement each common behavior ONCE here. To add a new card with an existing behavior,
    // call the factory — no other code changes needed.
    // ──────────────────────────────────────────────────────────────────────────────────────

    /** FLIP effect: controller gains [amount] Life Points. */
    private fun gainLPOnFlip(amount: Int) = CardEffect(
        id = "gain_lp_on_flip_$amount",
        timing = EffectTiming.FLIP,
        description = "Gain $amount Life Points.",
        canActivate = { _, _ -> true },
        resolve = { engine, source, _ ->
            val field = engine.state.field(source.controller)
            field.lifePoints += amount
            engine.state.addLog("${engine.displayName(source.controller)} gains $amount Life Points. (LP: ${field.lifePoints})")
        }
    )

    /** TRIGGER effect: draw [count] card(s) when this monster is Normal Summoned. */
    private fun drawOnNormalSummon(count: Int = 1) = CardEffect(
        id = "draw_on_normal_summon_$count",
        timing = EffectTiming.TRIGGER,
        description = if (count == 1) "Draw 1 card." else "Draw $count cards.",
        canActivate = { engine, source ->
            engine.state.lastEvent.let { it is GameEvent.NormalSummon && it.card === source }
        },
        resolve = { engine, source, _ ->
            engine.drawCards(source.controller, count)
            engine.state.addLog("${engine.displayName(source.controller)} draws $count card(s).")
        }
    )

    /** TRIGGER effect: draw [count] card(s) if this monster is destroyed by battle. */
    private fun drawIfDestroyedByBattle(count: Int = 1) = CardEffect(
        id = "draw_if_destroyed_by_battle_$count",
        timing = EffectTiming.TRIGGER,
        description = if (count == 1) "Draw 1 card." else "Draw $count cards.",
        canActivate = { engine, _ -> engine.lastDestructionWasBattle },
        resolve = { engine, source, _ ->
            engine.drawCards(source.controller, count)
            engine.state.addLog("${engine.displayName(source.controller)} draws $count card(s).")
        }
    )

    /**
     * IGNITION effect: tribute this monster to deal [damage] to the opponent.
     * Self-tribute is paid as cost (happens even if the effect is later negated).
     */
    private fun inflictDamageOnSelfTribute(damage: Int) = CardEffect(
        id = "inflict_damage_self_tribute_$damage",
        timing = EffectTiming.IGNITION,
        description = "Tribute this card to inflict $damage damage to your opponent.",
        canActivate = { _, source -> source.location == Location.MONSTER_ZONE && source.faceUp },
        payCost = { engine, source ->
            engine.sendToGraveyard(source)
            true
        },
        resolve = { engine, source, _ ->
            val opponent = source.controller.opponent()
            val field = engine.state.field(opponent)
            field.lifePoints -= damage
            engine.state.addLog("${engine.displayName(opponent)} takes $damage damage! (LP: ${field.lifePoints})")
            engine.checkWinConditions()
        }
    )

    /**
     * CONTINUOUS effect: all EARTH monsters on the field gain [amount] ATK.
     * No engine code changes needed — GameEngine.computeAtk() queries atkBonus automatically.
     */
    private fun earthAtkBuff(amount: Int) = CardEffect(
        id = "earth_atk_buff_continuous_$amount",
        timing = EffectTiming.CONTINUOUS,
        description = "All EARTH monsters on the field gain $amount ATK.",
        canActivate = { _, _ -> false }, // continuous effects are never "activated" via the chain
        resolve = { _, _, _ -> },
        atkBonus = { _, _, target ->
            if (target.card.attribute == Attribute.EARTH && target.location == Location.MONSTER_ZONE) amount else 0
        }
    )

    // ------------------------------------------------------------------
    // Shared target-finding helpers
    // ------------------------------------------------------------------

    /** For Rapid Strike: your face-up Attack Position monsters that attacked but have no extra attack pending. */
    private fun rapidStrikeTargets(engine: GameEngine, source: CardInstance): List<CardInstance> =
        engine.state.field(source.controller).monsters().filter {
            it.faceUp && it.battlePosition == BattlePosition.ATTACK &&
                it.hasAttackedThisTurn && it.extraAttacksAllowed <= 0
        }

    /** For Shield Wall: the monster of [source]'s controller currently being attacked, if any. */
    private fun shieldWallTarget(engine: GameEngine, source: CardInstance): CardInstance? {
        val event = engine.state.lastEvent as? GameEvent.AttackDeclared ?: return null
        val target = event.target ?: return null
        if (target.controller != source.controller) return null
        if (target.battlePosition != BattlePosition.ATTACK) return null
        if (event.attacker.controller == source.controller) return null
        return target
    }

    /** For Reversal Ambush: the opponent's monster that just declared an attack, if any. */
    private fun attackingMonster(engine: GameEngine, source: CardInstance): CardInstance? {
        val event = engine.state.lastEvent as? GameEvent.AttackDeclared ?: return null
        if (event.attacker.controller == source.controller) return null
        return event.attacker
    }
}
