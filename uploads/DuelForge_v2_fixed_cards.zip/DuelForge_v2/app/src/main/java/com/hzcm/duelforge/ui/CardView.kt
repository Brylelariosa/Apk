package com.hzcm.duelforge.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hzcm.duelforge.model.*

/** Card dimensions used throughout the field. Larger = more readable art on screen. */
val CardWidth  = 58.dp
val CardHeight = 80.dp

/**
 * Renders one card zone.
 *
 *  - null instance           → empty zone placeholder
 *  - face-down (not revealed) → full card-back art (assets/card_back.webp)
 *  - defense position monster → rotated 90° sideways (like real YGO), face-up or face-down
 *  - has artwork PNG/JPG/WEBP → artwork fills the entire card; no text overlay
 *  - no artwork file found    → colored placeholder with name + stats text
 *
 * [revealFaceDown] lets the player see their own set / face-down-defense cards.
 */
@Composable
fun CardView(
    instance: CardInstance?,
    modifier: Modifier = Modifier,
    revealFaceDown: Boolean = false,
    selected: Boolean = false,
    onClick: (() -> Unit)? = null,
    cardWidth: Dp = CardWidth,
    cardHeight: Dp = CardHeight
) {
    val isDefense = instance != null &&
        instance.card.isMonster &&
        instance.battlePosition == BattlePosition.DEFENSE

    val outerMod = modifier
        .size(cardWidth, cardHeight)
        .let { m -> if (onClick != null) m.clickable { onClick() } else m }

    if (instance == null) {
        Box(
            modifier = outerMod
                .background(Color(0xFF111111), RoundedCornerShape(6.dp))
                .border(1.dp, Color(0xFF2A2A2A), RoundedCornerShape(6.dp))
        ) {}
        return
    }

    val showFace = instance.faceUp || revealFaceDown
    val rotation  = if (isDefense) 90f else 0f

    Box(modifier = outerMod, contentAlignment = Alignment.Center) {
        Box(
            modifier = Modifier
                .size(cardWidth, cardHeight)
                .graphicsLayer { rotationZ = rotation }
                .clip(RoundedCornerShape(6.dp))
                .border(
                    width  = if (selected) 3.dp else 1.dp,
                    color  = when {
                        selected -> Color(0xFFFFD54F)
                        isDefense && showFace -> Color(0xFF4488FF)
                        else     -> Color(0xFF444444)
                    },
                    shape  = RoundedCornerShape(6.dp)
                )
        ) {
            if (!showFace) {
                CardBack(cardWidth = cardWidth, cardHeight = cardHeight)
            } else {
                val context = LocalContext.current
                val bitmap  = remember(instance.card.imageId) {
                    ImageLoader.loadCardImage(context, instance.card.imageId)
                }

                if (bitmap != null) {
                    // ── Has artwork: fill the whole card with the image, no text overlay ──
                    Image(
                        bitmap           = bitmap.asImageBitmap(),
                        contentDescription = instance.card.name,
                        modifier         = Modifier.fillMaxSize(),
                        contentScale     = ContentScale.Fit
                    )
                    // Subtle darkening for own face-down cards shown via revealFaceDown
                    if (!instance.faceUp) {
                        Box(modifier = Modifier.fillMaxSize().background(Color(0x66000000)))
                    }
                } else {
                    // ── No artwork: colored placeholder with text stats ──
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(cardTypeColor(instance.card))
                    ) {
                        PlaceholderCardContent(instance)
                    }
                }
            }
        }

        // Small "DEF" badge below rotated defense cards
        if (isDefense && showFace) {
            Text(
                "DEF",
                color     = Color(0xFF88BBFF),
                fontSize  = 5.sp,
                fontWeight = FontWeight.Bold,
                modifier  = Modifier.align(Alignment.BottomCenter).offset(y = 2.dp)
            )
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Card back
// ─────────────────────────────────────────────────────────────────────────────

@Composable
fun CardBack(modifier: Modifier = Modifier, cardWidth: Dp = CardWidth, cardHeight: Dp = CardHeight) {
    val context    = LocalContext.current
    val backBitmap = remember { ImageLoader.loadCardBack(context) }
    Box(
        modifier           = modifier.fillMaxSize().background(Color(0xFF2B2D6E)),
        contentAlignment   = Alignment.Center
    ) {
        if (backBitmap != null) {
            Image(
                bitmap             = backBitmap.asImageBitmap(),
                contentDescription = "Card back",
                modifier           = Modifier.fillMaxSize(),
                contentScale       = ContentScale.Fit
            )
        } else {
            Box(
                modifier = Modifier
                    .size(cardWidth - 14.dp, cardHeight - 14.dp)
                    .border(1.dp, Color(0xFF6E72C7), RoundedCornerShape(4.dp))
            )
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Text placeholder (shown only when no artwork file exists)
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun PlaceholderCardContent(instance: CardInstance) {
    val card = instance.card
    Column(
        modifier           = Modifier.fillMaxSize().padding(4.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Card name at top
        Text(
            text       = card.name,
            color      = Color.Black,
            fontSize   = 8.sp,
            fontWeight = FontWeight.Bold,
            lineHeight = 9.sp,
            maxLines   = 3,
            overflow   = TextOverflow.Ellipsis
        )
        // Type / stats at bottom
        Column {
            if (card.isMonster) {
                Text(
                    text     = "${card.attribute?.name ?: ""} ${card.race?.name?.replace('_', ' ') ?: ""}".trim(),
                    color    = Color(0xFF222222),
                    fontSize = 6.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text       = "Lv${card.level ?: 0}  ${card.atk ?: 0}/${card.def ?: 0}",
                    color      = Color.Black,
                    fontSize   = 7.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines   = 1
                )
            } else {
                Text(
                    text       = if (card.isSpell) "SPELL" else "TRAP",
                    color      = Color.Black,
                    fontSize   = 7.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Card type background colours for placeholder view
// ─────────────────────────────────────────────────────────────────────────────

private fun cardTypeColor(card: Card): Color = when (card.cardType) {
    CardType.MONSTER -> when (card.monsterCategory) {
        MonsterCategory.NORMAL -> Color(0xFFE8C77A)
        MonsterCategory.EFFECT -> Color(0xFFE8915A)
        MonsterCategory.FUSION -> Color(0xFFC79BE8)
        null                   -> Color(0xFFE8C77A)
    }
    CardType.SPELL -> Color(0xFF7FBF7F)
    CardType.TRAP  -> Color(0xFFE07FA8)
}
