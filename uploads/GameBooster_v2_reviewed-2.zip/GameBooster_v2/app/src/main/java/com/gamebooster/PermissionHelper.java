package com.gamebooster;

import android.app.AppOpsManager;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Process;
import android.provider.Settings;

/**
 * Utility class for checking and requesting the three special permissions
 * required by GameBooster (Usage Access, DND policy, Write Settings).
 *
 * All three are "special" permissions that cannot be granted via
 * {@code requestPermissions()}; the user must grant them manually in Settings.
 */
public final class PermissionHelper {

    private PermissionHelper() {}

    // ── Usage Access (PACKAGE_USAGE_STATS) ───────────────────────────────────

    /**
     * Returns {@code true} if the app has been granted Usage Access.
     * Required to poll {@code UsageStatsManager} for foreground-app detection.
     */
    public static boolean hasUsageAccess(Context ctx) {
        AppOpsManager aom = (AppOpsManager) ctx.getSystemService(Context.APP_OPS_SERVICE);
        int mode = aom.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            Process.myUid(),
            ctx.getPackageName()
        );
        return mode == AppOpsManager.MODE_ALLOWED;
    }

    /** Intent that opens the Usage Access settings screen. */
    public static Intent usageAccessIntent() {
        return new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
    }

    // ── Notification Policy (Do Not Disturb) ─────────────────────────────────

    /**
     * Returns {@code true} if the app can change the DND interruption filter.
     */
    public static boolean hasNotificationPolicyAccess(Context ctx) {
        NotificationManager nm =
            (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        return nm.isNotificationPolicyAccessGranted();
    }

    /** Intent that opens the Notification Policy / DND access settings screen. */
    public static Intent notificationPolicyIntent() {
        return new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS);
    }

    // ── Write Settings (screen brightness) ───────────────────────────────────

    /**
     * Returns {@code true} if the app can write to {@code Settings.System}
     * (needed to change screen brightness).
     */
    public static boolean canWriteSettings(Context ctx) {
        return Settings.System.canWrite(ctx);
    }

    /** Intent that opens the Modify System Settings page for this app. */
    public static Intent writeSettingsIntent(Context ctx) {
        return new Intent(
            Settings.ACTION_MANAGE_WRITE_SETTINGS,
            Uri.parse("package:" + ctx.getPackageName())
        );
    }
}
