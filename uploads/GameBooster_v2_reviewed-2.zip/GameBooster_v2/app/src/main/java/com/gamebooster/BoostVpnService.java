package com.gamebooster;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.VpnService;
import android.os.ParcelFileDescriptor;
import android.util.Log;

import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import java.io.IOException;

/**
 * Optional VPN-based network isolation service.
 *
 * <h3>Fixes vs original</h3>
 * <ul>
 *   <li><b>H-4 fd leak</b>: {@link #setUp} closes any existing {@code vpnInterface}
 *       before calling {@code establish()} again.</li>
 *   <li><b>H-6 unconditional stop</b>: The main Activity now checks
 *       {@link #isRunning} before sending the stop intent.</li>
 *   <li>State broadcast added so the UI can react without polling a static field.</li>
 * </ul>
 */
public class BoostVpnService extends VpnService {

    private static final String TAG = "BoostVpnService";

    public static final String EXTRA_GAME_PACKAGE = "extra_game_package";
    public static final String ACTION_STOP        = "com.gamebooster.vpn.action.STOP";
    public static final String ACTION_VPN_STATE   = "com.gamebooster.VPN_STATE";
    public static final String EXTRA_VPN_RUNNING  = "vpn_running";

    /** {@code true} while the VPN tunnel is active. Read from any thread. */
    public static volatile boolean isRunning = false;

    private ParcelFileDescriptor vpnInterface;

    // ── Service lifecycle ─────────────────────────────────────────────────────

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            tearDown();
            return START_NOT_STICKY;
        }
        String gamePackage = (intent != null)
            ? intent.getStringExtra(EXTRA_GAME_PACKAGE) : null;
        setUp(gamePackage);
        return START_NOT_STICKY; // Do not restart; boost session controls this.
    }

    @Override
    public void onRevoke() {
        tearDown();
        super.onRevoke();
    }

    @Override
    public void onDestroy() {
        tearDown();
        super.onDestroy();
    }

    // ── VPN setup / teardown ──────────────────────────────────────────────────

    private void setUp(String gamePackage) {
        // FIX H-4: close any existing interface before opening a new one to
        // prevent file-descriptor leaks when setUp() is called more than once.
        closeVpnInterface();

        try {
            Builder builder = new Builder()
                .setSession("GameBooster")
                .setMtu(1500)
                .addAddress("10.99.0.1", 24)
                .addRoute("0.0.0.0", 0)
                .addRoute("::", 0);

            if (gamePackage != null) {
                try {
                    builder.addDisallowedApplication(gamePackage);
                    Log.d(TAG, "Game bypasses VPN: " + gamePackage);
                } catch (PackageManager.NameNotFoundException e) {
                    Log.w(TAG, "Game package not found: " + gamePackage);
                }
            }

            try {
                builder.addDisallowedApplication(getPackageName());
            } catch (PackageManager.NameNotFoundException ignored) {}

            vpnInterface = builder.establish();
            isRunning    = (vpnInterface != null);

            if (isRunning) {
                Log.i(TAG, "VPN tunnel established — game traffic bypasses, others dropped.");
            } else {
                Log.w(TAG, "VPN establish() returned null — another VPN may be active.");
            }
            broadcastVpnState(isRunning);
        } catch (Exception e) {
            Log.e(TAG, "Failed to establish VPN", e);
            isRunning = false;
            broadcastVpnState(false);
        }
    }

    private void tearDown() {
        isRunning = false;
        closeVpnInterface();
        broadcastVpnState(false);
        stopSelf();
    }

    private void closeVpnInterface() {
        if (vpnInterface != null) {
            try {
                vpnInterface.close();
                Log.i(TAG, "VPN tunnel closed.");
            } catch (IOException e) {
                Log.w(TAG, "Error closing VPN interface", e);
            }
            vpnInterface = null;
        }
    }

    private void broadcastVpnState(boolean running) {
        LocalBroadcastManager.getInstance(this)
            .sendBroadcast(new Intent(ACTION_VPN_STATE)
                .putExtra(EXTRA_VPN_RUNNING, running));
    }
}
