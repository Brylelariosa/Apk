package com.gamebooster;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SearchView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Searchable app-picker presented as a Material bottom sheet.
 *
 * <h3>Crash fixes in this revision</h3>
 * <ul>
 *   <li><b>Fix 1 — ClassCastException</b>: {@code tvEmpty} was declared as {@code TextView}
 *       but the matching view ({@code @id/tv_empty}) is a {@code LinearLayout} in XML.
 *       Changed to plain {@code View} — only {@code setVisibility()} is ever called on it.</li>
 *   <li><b>Fix 2 — IllegalStateException on background thread</b>: {@code requireContext()}
 *       was called from background executor tasks. Now the application-level {@code Context}
 *       is captured on the main thread before the task is submitted, so it is always safe.</li>
 *   <li><b>Fix 3 — notifyItemChanged NPE race</b>: Icon-update posts are now skipped when
 *       {@code isAdded()} is false, and the adapter reference is read only inside the lambda
 *       (where it is already null-checked), not captured at submission time.</li>
 * </ul>
 */
public class AppPickerBottomSheet extends BottomSheetDialogFragment {

    public static final String TAG = "AppPickerBottomSheet";

    /** Callback delivered when the user selects an app. */
    public interface OnAppPicked {
        void onAppPicked(AppInfo app);
    }

    // ── UI ─────────────────────────────────────────────────────────────────────
    private RecyclerView rvApps;
    private SearchView   searchView;
    private View         progressBar;
    // FIX 1: was "private TextView tvEmpty" — the XML view is a LinearLayout,
    //         so the cast blew up at runtime. View is sufficient; we only call setVisibility().
    private View         tvEmpty;

    // ── State ───────────────────────────────────────────────────────────────────
    private AppAdapter      adapter;
    private GamePreferences prefs;
    private OnAppPicked     pickedCallback;
    private ExecutorService executor;
    private final Handler   mainHandler = new Handler(Looper.getMainLooper());

    // ── Factory ─────────────────────────────────────────────────────────────────
    public static AppPickerBottomSheet newInstance() {
        return new AppPickerBottomSheet();
    }

    public void setOnAppPicked(OnAppPicked cb) {
        this.pickedCallback = cb;
    }

    // ── Fragment lifecycle ───────────────────────────────────────────────────────

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.bottom_sheet_app_picker, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        rvApps      = view.findViewById(R.id.rv_apps);
        searchView  = view.findViewById(R.id.search_view);
        progressBar = view.findViewById(R.id.progress_loading);
        tvEmpty     = view.findViewById(R.id.tv_empty);  // LinearLayout in XML — fine as View

        prefs    = new GamePreferences(requireContext());
        adapter  = new AppAdapter();
        executor = Executors.newSingleThreadExecutor();

        rvApps.setLayoutManager(new LinearLayoutManager(requireContext()));
        rvApps.setAdapter(adapter);
        rvApps.setHasFixedSize(false);

        adapter.setOnAppSelected(app -> {
            prefs.saveLastGame(app);
            if (pickedCallback != null) pickedCallback.onAppPicked(app);
            dismiss();
        });

        adapter.setOnFavoriteToggle((app, position) -> {
            prefs.toggleFavorite(app.packageName);
            app.isFavorite = prefs.isFavorite(app.packageName);
            adapter.notifyFavoriteChanged(position);
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override public boolean onQueryTextSubmit(String q)  { return false; }
            @Override public boolean onQueryTextChange(String t)  {
                adapter.filter(t);
                return true;
            }
        });

        loadAppsAsync();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (executor != null) {
            executor.shutdownNow();
            executor = null;
        }
        mainHandler.removeCallbacksAndMessages(null);
        adapter = null;   // prevent stale references in pending icon-update posts
    }

    // ── Background app load ──────────────────────────────────────────────────────

    private void loadAppsAsync() {
        showLoading(true);

        // FIX 2: capture application context NOW on the main thread so background tasks
        // never call requireContext() / getContext(), which throw when the fragment detaches.
        final Context appCtx = requireContext().getApplicationContext();

        executor.execute(() -> {
            List<AppInfo> list = buildAppList(appCtx);

            mainHandler.post(() -> {
                // Guard: fragment may have been dismissed while we were scanning
                if (!isAdded() || getView() == null || executor == null) return;

                showLoading(false);
                if (list.isEmpty()) {
                    tvEmpty.setVisibility(View.VISIBLE);
                    rvApps.setVisibility(View.GONE);
                } else {
                    tvEmpty.setVisibility(View.GONE);
                    rvApps.setVisibility(View.VISIBLE);
                    if (adapter != null) adapter.submitList(list);
                    loadIconsAsync(list, appCtx);
                }
            });
        });
    }

    /** Builds the app list on a background thread. Uses the passed {@code Context}. */
    private List<AppInfo> buildAppList(Context appCtx) {
        PackageManager pm       = appCtx.getPackageManager();
        Set<String>    favs     = prefs.getFavorites();
        List<String>   recents  = prefs.getRecentPackages();

        List<AppInfo> list = new ArrayList<>();
        try {
            List<ApplicationInfo> installed =
                pm.getInstalledApplications(PackageManager.GET_META_DATA);

            for (ApplicationInfo info : installed) {
                boolean isSystem  = (info.flags & ApplicationInfo.FLAG_SYSTEM)             != 0;
                boolean isUpdated = (info.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0;
                if (isSystem && !isUpdated) continue;

                String label = pm.getApplicationLabel(info).toString();
                AppInfo app  = new AppInfo(label, info.packageName);
                app.isFavorite    = favs.contains(info.packageName);
                int recentIdx     = recents.indexOf(info.packageName);
                app.lastBoostTime = recentIdx >= 0
                    ? System.currentTimeMillis() - (long) recentIdx * 1_000L
                    : 0L;
                list.add(app);
            }
        } catch (Exception e) {
            android.util.Log.w(TAG, "App scan failed", e);
        }

        Collections.sort(list, (a, b) -> {
            if (a.isFavorite != b.isFavorite) return a.isFavorite ? -1 : 1;
            return a.label.compareToIgnoreCase(b.label);
        });
        return list;
    }

    /**
     * Phase 2: load icons lazily on the executor thread, posting one
     * {@code notifyItemChanged} per icon back to the main thread.
     */
    private void loadIconsAsync(List<AppInfo> list, Context appCtx) {
        if (executor == null) return;
        executor.execute(() -> {
            PackageManager pm = appCtx.getPackageManager();
            for (int i = 0; i < list.size(); i++) {
                if (Thread.currentThread().isInterrupted()) break;
                AppInfo app = list.get(i);
                try {
                    app.icon = pm.getApplicationIcon(app.packageName);
                } catch (PackageManager.NameNotFoundException ignored) {}

                final int pos = i;
                mainHandler.post(() -> {
                    // FIX 3: check fragment still attached and adapter not nulled by onDestroyView
                    if (!isAdded() || adapter == null) return;
                    adapter.notifyItemChanged(pos);
                });

                try { Thread.sleep(4); } catch (InterruptedException e) { break; }
            }
        });
    }

    // ── Helpers ──────────────────────────────────────────────────────────────────

    private void showLoading(boolean loading) {
        progressBar.setVisibility(loading ? View.VISIBLE : View.GONE);
        rvApps.setVisibility(loading ? View.GONE : View.VISIBLE);
    }
}
