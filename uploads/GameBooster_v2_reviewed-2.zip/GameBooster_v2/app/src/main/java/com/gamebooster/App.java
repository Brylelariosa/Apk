package com.gamebooster;

import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;

/**
 * Application subclass — creates the notification channel used by
 * {@link BoostService} before any service is started.
 */
public class App extends Application {

    /** Channel for the persistent foreground-service notification. */
    public static final String BOOST_CHANNEL_ID = "gamebooster_boost_channel";

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    private void createNotificationChannel() {
        NotificationChannel channel = new NotificationChannel(
            BOOST_CHANNEL_ID,
            "Game Boost",
            NotificationManager.IMPORTANCE_LOW   // silent — no sound or vibration
        );
        channel.setDescription("Active while GameBooster is running");
        channel.setShowBadge(false);
        getSystemService(NotificationManager.class).createNotificationChannel(channel);
    }
}
