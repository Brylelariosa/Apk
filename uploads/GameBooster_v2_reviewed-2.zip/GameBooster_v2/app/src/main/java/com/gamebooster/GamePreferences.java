package com.gamebooster;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Type-safe {@link SharedPreferences} wrapper for all persistent GameBooster state.
 *
 * <p>All writes use {@code apply()} (async) — never {@code commit()} — to avoid
 * blocking the calling thread.
 */
public final class GamePreferences {

    private static final String PREFS_NAME   = "game_booster_prefs";

    private static final String KEY_LAST_PKG   = "last_package";
    private static final String KEY_LAST_LABEL = "last_label";
    private static final String KEY_PROFILE    = "boost_profile";
    private static final String KEY_VPN        = "vpn_enabled";
    private static final String KEY_FAVORITES  = "favorites";
    private static final String KEY_RECENTS    = "recents";

    /** Maximum number of entries kept in the Recent Games list. */
    private static final int MAX_RECENTS = 5;

    private final SharedPreferences prefs;

    public GamePreferences(Context ctx) {
        prefs = ctx.getApplicationContext()
                   .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    // ── Last selected game ────────────────────────────────────────────────────

    public void saveLastGame(AppInfo app) {
        prefs.edit()
             .putString(KEY_LAST_PKG,   app.packageName)
             .putString(KEY_LAST_LABEL, app.label)
             .apply();
        addRecent(app.packageName);
    }

    /** @return the package name of the last boosted game, or {@code null}. */
    public String getLastPackage() { return prefs.getString(KEY_LAST_PKG, null); }

    /** @return the app label of the last boosted game, or {@code null}. */
    public String getLastLabel()   { return prefs.getString(KEY_LAST_LABEL, null); }

    // ── Boost profile ─────────────────────────────────────────────────────────

    public void saveProfile(BoostProfile profile) {
        prefs.edit().putString(KEY_PROFILE, profile.name()).apply();
    }

    public BoostProfile getProfile() {
        String name = prefs.getString(KEY_PROFILE, BoostProfile.BALANCED.name());
        try {
            return BoostProfile.valueOf(name);
        } catch (IllegalArgumentException e) {
            return BoostProfile.BALANCED;
        }
    }

    // ── VPN toggle ────────────────────────────────────────────────────────────

    public void saveVpnEnabled(boolean enabled) {
        prefs.edit().putBoolean(KEY_VPN, enabled).apply();
    }

    public boolean isVpnEnabled() {
        return prefs.getBoolean(KEY_VPN, false);
    }

    // ── Favourites ────────────────────────────────────────────────────────────

    public void toggleFavorite(String packageName) {
        Set<String> favs = getMutableFavorites();
        if (favs.contains(packageName)) favs.remove(packageName);
        else                            favs.add(packageName);
        prefs.edit().putStringSet(KEY_FAVORITES, favs).apply();
    }

    public boolean isFavorite(String packageName) {
        return getMutableFavorites().contains(packageName);
    }

    /** Returns a snapshot of favourite package names (insertion-ordered). */
    public Set<String> getFavorites() {
        return getMutableFavorites();
    }

    private Set<String> getMutableFavorites() {
        // putStringSet stores a live reference in some API versions; always copy.
        Set<String> stored = prefs.getStringSet(KEY_FAVORITES, null);
        return stored != null ? new LinkedHashSet<>(stored) : new LinkedHashSet<>();
    }

    // ── Recents ───────────────────────────────────────────────────────────────

    /**
     * Returns package names of recently boosted apps, newest first.
     * Always returns a mutable list.
     */
    public List<String> getRecentPackages() {
        String raw = prefs.getString(KEY_RECENTS, "");
        if (raw.isEmpty()) return new ArrayList<>();
        return new ArrayList<>(Arrays.asList(raw.split(",")));
    }

    private void addRecent(String packageName) {
        List<String> recents = getRecentPackages();
        recents.remove(packageName);        // de-duplicate
        recents.add(0, packageName);        // most recent first
        while (recents.size() > MAX_RECENTS) recents.remove(recents.size() - 1);
        prefs.edit().putString(KEY_RECENTS, String.join(",", recents)).apply();
    }
}
