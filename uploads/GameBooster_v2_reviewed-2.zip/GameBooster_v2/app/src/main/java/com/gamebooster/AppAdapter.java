package com.gamebooster;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

/**
 * RecyclerView adapter for the searchable app-picker bottom sheet.
 *
 * <p>Features:
 * <ul>
 *   <li>Shows cached app icon, label, and package name per row.</li>
 *   <li>Tappable favourite star (calls {@link OnFavoriteToggle}).</li>
 *   <li>Client-side filtering via {@link #filter(String)}.</li>
 *   <li>Efficient {@link DiffUtil} updates to avoid full notifyDataSetChanged.</li>
 * </ul>
 *
 * <p><b>Threading:</b> all methods must be called from the main thread.
 */
public class AppAdapter extends RecyclerView.Adapter<AppAdapter.ViewHolder> {

    /** Notified when the user taps an app row. */
    public interface OnAppSelected {
        void onSelect(AppInfo app);
    }

    /** Notified when the user taps the favourite star on an app row. */
    public interface OnFavoriteToggle {
        void onToggle(AppInfo app, int adapterPosition);
    }

    // ── Data ──────────────────────────────────────────────────────────────────

    /** Full unfiltered list — never mutated after submitList(). */
    private List<AppInfo> allItems = new ArrayList<>();

    /** Currently displayed (possibly filtered) list. */
    private final List<AppInfo> visibleItems = new ArrayList<>();

    // ── Listeners ─────────────────────────────────────────────────────────────

    private OnAppSelected    selectListener;
    private OnFavoriteToggle favoriteListener;

    public void setOnAppSelected(OnAppSelected l)    { selectListener   = l; }
    public void setOnFavoriteToggle(OnFavoriteToggle l) { favoriteListener = l; }

    // ── Public API ────────────────────────────────────────────────────────────

    /**
     * Replaces the full list using {@link DiffUtil} for smooth animation.
     * Call this once after the background app-scan completes.
     */
    public void submitList(@NonNull List<AppInfo> newList) {
        allItems = new ArrayList<>(newList);
        applyDiff(new ArrayList<>(newList));
    }

    /**
     * Filters the displayed list to rows whose label or package name
     * contains {@code query} (case-insensitive).
     * An empty or null query shows all items.
     */
    public void filter(String query) {
        List<AppInfo> filtered;
        if (query == null || query.trim().isEmpty()) {
            filtered = new ArrayList<>(allItems);
        } else {
            String q = query.trim().toLowerCase();
            filtered = new ArrayList<>();
            for (AppInfo a : allItems) {
                if (a.label.toLowerCase().contains(q)
                        || a.packageName.toLowerCase().contains(q)) {
                    filtered.add(a);
                }
            }
        }
        applyDiff(filtered);
    }

    /** Refreshes a single row after a favourite toggle (avoids full rebind). */
    public void notifyFavoriteChanged(int position) {
        notifyItemChanged(position, "fav");
    }

    // ── RecyclerView.Adapter ──────────────────────────────────────────────────

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                               .inflate(R.layout.item_app_picker, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder h, int position) {
        AppInfo app = visibleItems.get(position);
        h.tvLabel.setText(app.label);
        h.tvPackage.setText(app.packageName);

        if (app.icon != null) {
            h.ivIcon.setImageDrawable(app.icon);
        } else {
            h.ivIcon.setImageResource(android.R.drawable.sym_def_app_icon);
        }

        updateFavStar(h.ivFavorite, app.isFavorite);

        h.itemView.setOnClickListener(v -> {
            if (selectListener != null) selectListener.onSelect(app);
        });

        h.ivFavorite.setOnClickListener(v -> {
            if (favoriteListener != null) {
                favoriteListener.onToggle(app, h.getBindingAdapterPosition());
            }
        });
    }

    /**
     * Partial-bind for favourite-only changes (triggered by
     * {@code notifyItemChanged(pos, "fav")}).
     */
    @Override
    public void onBindViewHolder(@NonNull ViewHolder h, int position,
                                 @NonNull List<Object> payloads) {
        if (!payloads.isEmpty() && "fav".equals(payloads.get(0))) {
            updateFavStar(h.ivFavorite, visibleItems.get(position).isFavorite);
        } else {
            super.onBindViewHolder(h, position, payloads);
        }
    }

    @Override
    public int getItemCount() { return visibleItems.size(); }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private void applyDiff(List<AppInfo> newVisible) {
        List<AppInfo> oldVisible = new ArrayList<>(visibleItems);
        DiffUtil.DiffResult result = DiffUtil.calculateDiff(new DiffUtil.Callback() {
            @Override public int getOldListSize() { return oldVisible.size(); }
            @Override public int getNewListSize() { return newVisible.size(); }
            @Override public boolean areItemsTheSame(int o, int n) {
                return oldVisible.get(o).packageName.equals(newVisible.get(n).packageName);
            }
            @Override public boolean areContentsTheSame(int o, int n) {
                AppInfo a = oldVisible.get(o), b = newVisible.get(n);
                return a.label.equals(b.label) && a.isFavorite == b.isFavorite;
            }
        });
        visibleItems.clear();
        visibleItems.addAll(newVisible);
        result.dispatchUpdatesTo(this);
    }

    private void updateFavStar(ImageView iv, boolean isFav) {
        // Use tinted star drawables from the theme rather than hardcoded drawables.
        iv.setImageResource(isFav
            ? R.drawable.ic_star_filled
            : R.drawable.ic_star_outline);
        iv.setContentDescription(isFav ? "Remove from favourites" : "Add to favourites");
    }

    // ── ViewHolder ────────────────────────────────────────────────────────────

    static class ViewHolder extends RecyclerView.ViewHolder {
        final ImageView ivIcon;
        final ImageView ivFavorite;
        final TextView  tvLabel;
        final TextView  tvPackage;

        ViewHolder(View v) {
            super(v);
            ivIcon     = v.findViewById(R.id.iv_app_icon);
            ivFavorite = v.findViewById(R.id.iv_favorite);
            tvLabel    = v.findViewById(R.id.tv_app_label);
            tvPackage  = v.findViewById(R.id.tv_app_package);
        }
    }
}
