package com.gamebooster;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.PowerManager;
import android.provider.Settings;
import android.util.Log;

import androidx.core.app.NotificationCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import java.util.List;

/**
 * Foreground service that applies system-level performance boosts while a game is running.
 *
 * <h3>Fixes applied vs original</h3>
 * <ul>
 *   <li><b>C-1 NPE fix</b>: {@code gamePackage} is null-guarded throughout.</li>
 *   <li><b>C-2 WakeLock timeout</b>: acquired with a max hold time (3 h) to prevent
 *       indefinite battery drain if {@code onDestroy} is never called.</li>
 *   <li><b>H-1 DND restore after OS restart</b>: the saved DND filter and a "was-applied"
 *       flag are persisted to SharedPreferences so they survive {@code START_STICKY}
 *       recreations.</li>
 *   <li><b>H-2 null gamePackage guard</b>: service stops itself if started without
 *       {@code EXTRA_PACKAGE}.</li>
 *   <li><b>H-5 friendly notification</b>: shows the app label, not the package name.</li>
 *   <li><b>M-2 monitor on background thread</b>: uses a {@link HandlerThread} instead of
 *       {@code Handler(Looper.getMainLooper())} so {@code queryUsageStats()} never runs
 *       on the UI thread.</li>
 *   <li><b>M-8 reduced lookback</b>: lookback window tightened to
 *       {@code GAME_INACTIVE_TIMEOUT_MS + 30 s}.</li>
 * </ul>
 *
 * <h3>Local Broadcasts</h3>
 * The service emits {@link #ACTION_STATE_CHANGED} to inform the Activity of state transitions
 * without coupling them via a static field.
 */
public class BoostService extends Service {

    private static final String TAG = "BoostService";

    // Intent extras / actions
    public static final String EXTRA_PACKAGE  = "extra_package_name";
    public static final String EXTRA_LABEL    = "extra_app_label";
    public static final String EXTRA_PROFILE  = "extra_boost_profile";
    public static final String ACTION_STOP    = "com.gamebooster.action.STOP";

    // State broadcast — replaces the fragile public static boolean
    public static final String ACTION_STATE_CHANGED = "com.gamebooster.STATE_CHANGED";
    public static final String EXTRA_IS_RUNNING     = "is_running";

    // Notification
    private static final int NOTIFICATION_ID = 1001;

    // Timing
    private static final long WAKELOCK_MAX_MS        = 3 * 60 * 60 * 1000L; // 3 hours max
    private static final long MONITOR_INTERVAL_MS    = 5_000L;
    private static final long GAME_INACTIVE_TIMEOUT_MS = 120_000L;
    private static final long USAGE_LOOKBACK_MS      = GAME_INACTIVE_TIMEOUT_MS + 30_000L;

    // SharedPreferences keys for DND persistence (survives START_STICKY recreation)
    private static final String PREFS_BOOST = "boost_service_state";
    private static final String KEY_DND_APPLIED = "dnd_applied";
    private static final String KEY_DND_FILTER  = "dnd_saved_filter";

    // ── Fields ────────────────────────────────────────────────────────────────

    private String               gamePackage;
    private String               appLabel;
    private BoostProfile         profile;
    private PowerManager.WakeLock wakeLock;
    private WifiManager.WifiLock  wifiLock;
    private HandlerThread         monitorThread;
    private Handler               monitorHandler;

    private int     savedBrightness   = -1;
    private boolean brightnessApplied = false;

    // ── Service lifecycle ─────────────────────────────────────────────────────

    @Override
    public void onCreate() {
        super.onCreate();
        // Start the dedicated monitor thread immediately — posts from onStartCommand.
        monitorThread = new HandlerThread("GameBoosterMonitor");
        monitorThread.start();
        monitorHandler = new Handler(monitorThread.getLooper());
        broadcastState(true);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // ── Handle "Stop" tap from notification ───────────────────────────────
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }

        // ── Extract extras ────────────────────────────────────────────────────
        gamePackage = (intent != null) ? intent.getStringExtra(EXTRA_PACKAGE) : null;
        appLabel    = (intent != null) ? intent.getStringExtra(EXTRA_LABEL)   : null;

        // FIX H-2: refuse to run without a target package (e.g. OS-restart with null intent)
        if (gamePackage == null || gamePackage.isEmpty()) {
            Log.w(TAG, "Started without EXTRA_PACKAGE — stopping immediately.");
            stopSelf();
            return START_NOT_STICKY;
        }

        if (appLabel == null || appLabel.isEmpty()) {
            // Attempt to resolve label from PackageManager as a fallback
            appLabel = resolveLabel(gamePackage);
        }

        String profileName = (intent != null) ? intent.getStringExtra(EXTRA_PROFILE) : null;
        profile = parseProfile(profileName);

        // Must call startForeground() within ~5 s of startForegroundService() to avoid ANR
        startForeground(NOTIFICATION_ID, buildNotification());

        // Apply boosts according to the selected profile
        if (profile.enableWakeLock)      acquireWakeLock();
        if (profile.enableWifiLock)      acquireWifiLock();
        if (profile.enableDnd)           applyDnd();
        if (profile.enableMaxBrightness) applyMaxBrightness();

        // Schedule the game-exit monitor on the background thread
        monitorHandler.postDelayed(monitorRunnable, MONITOR_INTERVAL_MS);

        Log.i(TAG, "Boost started for: " + gamePackage + " profile=" + profile.name());
        return START_NOT_STICKY; // Don't restart on kill; the UI manages start/stop.
    }

    @Override
    public void onDestroy() {
        broadcastState(false);
        // Cancel all pending monitor posts before quitting the thread
        monitorHandler.removeCallbacksAndMessages(null);
        monitorThread.quitSafely();

        releaseWakeLock();
        releaseWifiLock();
        restoreDnd();
        restoreBrightness();

        Log.i(TAG, "Boost stopped, all settings restored.");
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    // ── Notification ──────────────────────────────────────────────────────────

    private Notification buildNotification() {
        PendingIntent openApp = PendingIntent.getActivity(
            this, 0,
            new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE
        );

        Intent stopIntent = new Intent(this, BoostService.class).setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(
            this, 1, stopIntent,
            PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT
        );

        // FIX H-5: show friendly app label, not raw package name
        String subtitle = "Boosting " + (appLabel != null ? appLabel : gamePackage)
            + " · " + (profile != null ? profile.displayName : "Balanced");

        return new NotificationCompat.Builder(this, App.BOOST_CHANNEL_ID)
            .setContentTitle("GameBooster Active")
            .setContentText(subtitle)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(openApp)
            .addAction(android.R.drawable.ic_media_pause, "Stop", stopPi)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build();
    }

    // ── WakeLock ──────────────────────────────────────────────────────────────

    private void acquireWakeLock() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "GameBooster:boost");
            // FIX C-2: always supply a max hold time so the lock cannot drain
            // the battery forever if onDestroy() is never called by the OS.
            wakeLock.acquire(WAKELOCK_MAX_MS);
            Log.d(TAG, "WakeLock acquired (max " + (WAKELOCK_MAX_MS / 3600_000) + " h)");
        } catch (Exception e) {
            Log.w(TAG, "WakeLock acquire failed", e);
        }
    }

    private void releaseWakeLock() {
        if (wakeLock != null && wakeLock.isHeld()) {
            wakeLock.release();
            Log.d(TAG, "WakeLock released");
        }
        wakeLock = null;
    }

    // ── WifiLock ──────────────────────────────────────────────────────────────

    private void acquireWifiLock() {
        try {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
            wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_LOW_LATENCY, "GameBooster:wifi");
            wifiLock.setReferenceCounted(false);
            wifiLock.acquire();
            Log.d(TAG, "WifiLock (LOW_LATENCY) acquired");
        } catch (Exception e) {
            Log.w(TAG, "WifiLock acquire failed", e);
        }
    }

    private void releaseWifiLock() {
        if (wifiLock != null && wifiLock.isHeld()) {
            wifiLock.release();
            Log.d(TAG, "WifiLock released");
        }
        wifiLock = null;
    }

    // ── Do Not Disturb ────────────────────────────────────────────────────────

    private void applyDnd() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (!nm.isNotificationPolicyAccessGranted()) {
            Log.d(TAG, "DND: policy access not granted — skipping");
            return;
        }
        int current = nm.getCurrentInterruptionFilter();
        // FIX H-1: persist to SharedPreferences so a START_STICKY recreation can restore
        getSharedPreferences(PREFS_BOOST, MODE_PRIVATE).edit()
            .putBoolean(KEY_DND_APPLIED, true)
            .putInt(KEY_DND_FILTER, current)
            .apply();

        nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_NONE);
        Log.d(TAG, "DND: total silence applied (saved filter=" + current + ")");
    }

    private void restoreDnd() {
        android.content.SharedPreferences sp =
            getSharedPreferences(PREFS_BOOST, MODE_PRIVATE);
        boolean applied = sp.getBoolean(KEY_DND_APPLIED, false);
        if (!applied) return;

        int savedFilter = sp.getInt(KEY_DND_FILTER,
            NotificationManager.INTERRUPTION_FILTER_UNKNOWN);
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm.isNotificationPolicyAccessGranted()
                && savedFilter != NotificationManager.INTERRUPTION_FILTER_UNKNOWN) {
            nm.setInterruptionFilter(savedFilter);
            Log.d(TAG, "DND: restored to " + savedFilter);
        }
        // Clear the persisted flag
        sp.edit().remove(KEY_DND_APPLIED).remove(KEY_DND_FILTER).apply();
    }

    // ── Screen brightness ─────────────────────────────────────────────────────

    private void applyMaxBrightness() {
        if (!Settings.System.canWrite(this)) {
            Log.d(TAG, "Brightness: WRITE_SETTINGS not granted — skipping");
            return;
        }
        try {
            savedBrightness = Settings.System.getInt(
                getContentResolver(), Settings.System.SCREEN_BRIGHTNESS);
            Settings.System.putInt(
                getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, 255);
            brightnessApplied = true;
            Log.d(TAG, "Brightness: set to 255 (saved=" + savedBrightness + ")");
        } catch (Settings.SettingNotFoundException e) {
            Log.w(TAG, "Brightness: could not read current value", e);
        }
    }

    private void restoreBrightness() {
        if (!brightnessApplied || savedBrightness < 0) return;
        if (Settings.System.canWrite(this)) {
            Settings.System.putInt(
                getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, savedBrightness);
            Log.d(TAG, "Brightness: restored to " + savedBrightness);
        }
        brightnessApplied = false;
    }

    // ── Game monitor (runs on HandlerThread, NOT main thread) ─────────────────

    private final Runnable monitorRunnable = new Runnable() {
        @Override
        public void run() {
            // FIX C-1: gamePackage is guaranteed non-null here (H-2 guard above)
            if (!isGameRecentlyActive()) {
                Log.i(TAG, gamePackage + " inactive for >" + (GAME_INACTIVE_TIMEOUT_MS / 1000)
                    + " s — stopping boost");
                stopSelf();
                return;
            }
            monitorHandler.postDelayed(this, MONITOR_INTERVAL_MS);
        }
    };

    private boolean isGameRecentlyActive() {
        UsageStatsManager usm = (UsageStatsManager) getSystemService(USAGE_STATS_SERVICE);
        long now = System.currentTimeMillis();
        List<UsageStats> stats = usm.queryUsageStats(
            UsageStatsManager.INTERVAL_DAILY,
            now - USAGE_LOOKBACK_MS,
            now
        );

        if (stats == null || stats.isEmpty()) {
            Log.d(TAG, "UsageStats empty — keeping boost alive");
            return true;
        }

        for (UsageStats s : stats) {
            if (gamePackage.equals(s.getPackageName())) {
                boolean active = (now - s.getLastTimeUsed()) < GAME_INACTIVE_TIMEOUT_MS;
                Log.v(TAG, gamePackage + " last used "
                    + ((now - s.getLastTimeUsed()) / 1000) + " s ago → " + active);
                return active;
            }
        }
        return false;
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    /** Emits a local broadcast so the Activity can update its UI without polling a static field. */
    private void broadcastState(boolean running) {
        Intent intent = new Intent(ACTION_STATE_CHANGED)
            .putExtra(EXTRA_IS_RUNNING, running);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    private String resolveLabel(String pkg) {
        try {
            PackageManager pm = getPackageManager();
            return pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString();
        } catch (Exception e) {
            return pkg;
        }
    }

    private static BoostProfile parseProfile(String name) {
        if (name == null) return BoostProfile.BALANCED;
        try { return BoostProfile.valueOf(name); }
        catch (IllegalArgumentException e) { return BoostProfile.BALANCED; }
    }
}
