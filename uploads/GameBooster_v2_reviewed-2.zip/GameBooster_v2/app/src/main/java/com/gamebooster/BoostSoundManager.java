package com.gamebooster;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.util.Log;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Synthesizes and plays three short sound effects using {@link AudioTrack}
 * with pre-generated PCM buffers — no audio files required.
 *
 * <h3>Sounds</h3>
 * <ul>
 *   <li>{@link #playGameSelected()} — short double-blip confirmation tone (400 → 700 Hz, 120 ms)</li>
 *   <li>{@link #playBoostOn()} — ascending power-up sweep (250 → 1000 Hz, 380 ms)</li>
 *   <li>{@link #playBoostOff()} — descending wind-down sweep (1000 → 250 Hz, 280 ms)</li>
 * </ul>
 *
 * <h3>Threading</h3>
 * All AudioTrack writes happen on a dedicated single-thread executor so the UI
 * thread is never blocked. Sounds requested while another is playing simply queue
 * behind it (the executor serialises them).
 *
 * <h3>Lifecycle</h3>
 * Call {@link #release()} in {@code Activity.onDestroy()} to free the executor.
 */
public final class BoostSoundManager {

    private static final String TAG      = "BoostSoundManager";
    private static final int    SAMPLE_RATE = 44_100;   // Hz
    private static final float  MASTER_VOL  = 0.55f;    // 0..1 — not too loud

    private final Context       ctx;
    private final ExecutorService exec = Executors.newSingleThreadExecutor();

    public BoostSoundManager(Context ctx) {
        this.ctx = ctx.getApplicationContext();
    }

    // ── Public API ────────────────────────────────────────────────────────────

    /** Short two-blip tone played when the user taps a game in the picker. */
    public void playGameSelected() {
        exec.execute(() -> {
            short[] blip1 = sine(400f, 0.07f, 0.4f); // 70 ms at 400 Hz
            short[] blip2 = sine(700f, 0.07f, 0.4f); // 70 ms at 700 Hz
            short[] gap   = silence(0.025f);           // 25 ms gap
            play(concat(blip1, gap, blip2));
        });
    }

    /** Rising power-up sweep played when boost is activated. */
    public void playBoostOn() {
        exec.execute(() -> {
            short[] sweep = sweep(250f, 1000f, 0.30f, 0.55f); // 300 ms up-sweep
            short[] tail  = sine(1000f, 0.08f, 0.45f);        // 80 ms hold at peak
            play(concat(sweep, tail));
        });
    }

    /** Falling wind-down sweep played when boost is stopped. */
    public void playBoostOff() {
        exec.execute(() -> play(sweep(950f, 220f, 0.28f, 0.45f))); // 280 ms down-sweep
    }

    /** Call from {@code Activity.onDestroy()} to shut down the sound thread. */
    public void release() {
        exec.shutdownNow();
    }

    // ── PCM generation helpers ─────────────────────────────────────────────────

    /**
     * Generates a mono sine-wave burst.
     *
     * @param freq     frequency in Hz
     * @param duration duration in seconds
     * @param volume   peak amplitude 0..1
     */
    private short[] sine(float freq, float duration, float volume) {
        int   samples = (int) (SAMPLE_RATE * duration);
        short[] buf   = new short[samples];
        double  twoPiF = 2.0 * Math.PI * freq / SAMPLE_RATE;
        for (int i = 0; i < samples; i++) {
            double env = envelope(i, samples);
            buf[i] = (short) (Short.MAX_VALUE * volume * MASTER_VOL * env * Math.sin(twoPiF * i));
        }
        return buf;
    }

    /**
     * Generates a linear frequency sweep (chirp).
     *
     * @param startHz  starting frequency
     * @param endHz    ending frequency
     * @param duration duration in seconds
     * @param volume   peak amplitude 0..1
     */
    private short[] sweep(float startHz, float endHz, float duration, float volume) {
        int   samples  = (int) (SAMPLE_RATE * duration);
        short[] buf    = new short[samples];
        double  phase  = 0.0;
        double  deltaF = (endHz - startHz) / samples;

        for (int i = 0; i < samples; i++) {
            double freq   = startHz + deltaF * i;
            double env    = envelope(i, samples);
            buf[i]        = (short) (Short.MAX_VALUE * volume * MASTER_VOL * env * Math.sin(phase));
            phase        += 2.0 * Math.PI * freq / SAMPLE_RATE;
        }
        return buf;
    }

    /** Returns {@code durationSecs} of digital silence. */
    private short[] silence(float durationSecs) {
        return new short[(int) (SAMPLE_RATE * durationSecs)];
    }

    /**
     * Simple linear attack/decay envelope.
     * Attack = first 15 % of the buffer; decay = last 20 %.
     */
    private double envelope(int i, int total) {
        double attackEnd = 0.15 * total;
        double decayStart = 0.80 * total;
        if (i < attackEnd) return i / attackEnd;
        if (i > decayStart) return 1.0 - (i - decayStart) / (total - decayStart);
        return 1.0;
    }

    /** Concatenates any number of short[] buffers into one. */
    @SafeVarargs
    private static short[] concat(short[]... parts) {
        int len = 0;
        for (short[] p : parts) len += p.length;
        short[] out = new short[len];
        int pos = 0;
        for (short[] p : parts) {
            System.arraycopy(p, 0, out, pos, p.length);
            pos += p.length;
        }
        return out;
    }

    // ── AudioTrack playback ────────────────────────────────────────────────────

    /**
     * Writes {@code pcm} to a fresh {@link AudioTrack} in {@code MODE_STATIC},
     * plays it to completion, then releases it.
     */
    private void play(short[] pcm) {
        // Respect the user's current media volume; skip if muted.
        AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
        if (am.getStreamVolume(AudioManager.STREAM_MUSIC) == 0) return;

        AudioTrack track = null;
        try {
            AudioAttributes attrs = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();

            AudioFormat format = new AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(SAMPLE_RATE)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .build();

            int minBuf = AudioTrack.getMinBufferSize(
                SAMPLE_RATE,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            );
            int bufBytes = Math.max(minBuf, pcm.length * 2);

            track = new AudioTrack.Builder()
                .setAudioAttributes(attrs)
                .setAudioFormat(format)
                .setBufferSizeInBytes(bufBytes)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build();

            track.write(pcm, 0, pcm.length);
            track.play();

            // Wait for playback to finish before releasing (MODE_STATIC plays asynchronously)
            int durationMs = (int) (pcm.length * 1000L / SAMPLE_RATE) + 30;
            Thread.sleep(durationMs);

        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } catch (Exception e) {
            Log.w(TAG, "Sound playback failed", e);
        } finally {
            if (track != null) {
                try { track.stop(); } catch (Exception ignored) {}
                track.release();
            }
        }
    }
}
