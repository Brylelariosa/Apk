package com.gamebooster;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.drawable.Drawable;
import android.net.VpnService;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.content.ContextCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Premium dashboard Activity for GameBooster.
 *
 * <h3>Fixes in this revision</h3>
 * <ul>
 *   <li><b>Icon load crash</b>: {@code getApplicationIcon()} is now executed on
 *       {@link #iconExecutor} (background), never the main thread.</li>
 *   <li><b>Sounds</b>: {@link BoostSoundManager} plays synthesised tones on
 *       game-select, boost-on, and boost-off.</li>
 * </ul>
 */
public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    private static final String KEY_SELECTED_PKG   = "sel_pkg";
    private static final String KEY_SELECTED_LABEL = "sel_label";

    // ── Views — Hero card ──────────────────────────────────────────────────────
    private ImageView    ivHeroIcon;
    private TextView     tvHeroGameName;
    private TextView     tvHeroStatus;
    private TextView     tvHeroTweaks;

    // ── Views — Permission cards ───────────────────────────────────────────────
    private MaterialCardView cardPermUsage, cardPermDnd, cardPermBrightness;
    private ImageView        ivPermUsage,   ivPermDnd,   ivPermBrightness;
    private TextView         tvPermUsage,   tvPermDnd,   tvPermBrightness;

    // ── Views — Boost profiles ─────────────────────────────────────────────────
    private MaterialCardView cardBattery, cardBalanced, cardMax;

    // ── Views — Live stats ─────────────────────────────────────────────────────
    private View     statsSection;
    private TextView tvStatRam, tvStatCpu, tvStatBattery;

    // ── Views — Options & Action ───────────────────────────────────────────────
    private SwitchCompat   switchVpn;
    private MaterialButton btnBoost;
    private MaterialButton btnPickGame;

    // ── State ──────────────────────────────────────────────────────────────────
    private AppInfo         selectedApp;
    private BoostProfile    selectedProfile;
    private boolean         isBoosting = false;
    private GamePreferences prefs;

    // ── Sound ──────────────────────────────────────────────────────────────────
    private BoostSoundManager soundManager;

    // ── Background executor for icon loading ───────────────────────────────────
    // FIX: icon loading must never happen on the main thread.
    private final ExecutorService iconExecutor = Executors.newSingleThreadExecutor();
    private final Handler         mainHandler  = new Handler(Looper.getMainLooper());

    // ── Stats polling ──────────────────────────────────────────────────────────
    private final Handler statsHandler = new Handler(Looper.getMainLooper());

    // ── Activity result launchers ──────────────────────────────────────────────
    private ActivityResultLauncher<Intent> permLauncher;
    private ActivityResultLauncher<Intent> vpnConsentLauncher;
    private String pendingVpnPackage;

    // ── Local broadcast receiver ───────────────────────────────────────────────
    private final BroadcastReceiver boostStateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context ctx, Intent intent) {
            if (BoostService.ACTION_STATE_CHANGED.equals(intent.getAction())) {
                boolean running = intent.getBooleanExtra(BoostService.EXTRA_IS_RUNNING, false);
                syncBoostUi(running);
            }
        }
    };

    // ── Lifecycle ──────────────────────────────────────────────────────────────

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs        = new GamePreferences(this);
        soundManager = new BoostSoundManager(this);

        bindViews();
        setupActivityResultLaunchers();
        setupProfileCards();
        setupVpnSwitch();
        setupPickGameButton();

        // Restore selected game across rotation
        if (savedInstanceState != null) {
            String pkg   = savedInstanceState.getString(KEY_SELECTED_PKG);
            String label = savedInstanceState.getString(KEY_SELECTED_LABEL);
            if (pkg != null) {
                AppInfo a = new AppInfo(label != null ? label : pkg, pkg);
                a.isFavorite = prefs.isFavorite(pkg);
                onAppSelected(a, /*playSound=*/false);
            }
        } else {
            restoreLastGame();
        }

        selectedProfile = prefs.getProfile();
        switchVpn.setChecked(prefs.isVpnEnabled());
        highlightProfileCard(selectedProfile);
    }

    @Override
    protected void onResume() {
        super.onResume();
        updatePermissionCards();
        LocalBroadcastManager.getInstance(this)
            .registerReceiver(boostStateReceiver,
                new IntentFilter(BoostService.ACTION_STATE_CHANGED));
        syncBoostUi(isBoostServiceRunning());
    }

    @Override
    protected void onPause() {
        super.onPause();
        LocalBroadcastManager.getInstance(this).unregisterReceiver(boostStateReceiver);
        stopStatsPolling();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        soundManager.release();
        iconExecutor.shutdownNow();
        mainHandler.removeCallbacksAndMessages(null);
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        if (selectedApp != null) {
            out.putString(KEY_SELECTED_PKG,   selectedApp.packageName);
            out.putString(KEY_SELECTED_LABEL, selectedApp.label);
        }
    }

    // ── View binding ───────────────────────────────────────────────────────────

    private void bindViews() {
        ivHeroIcon     = findViewById(R.id.iv_hero_icon);
        tvHeroGameName = findViewById(R.id.tv_hero_game_name);
        tvHeroStatus   = findViewById(R.id.tv_hero_status);
        tvHeroTweaks   = findViewById(R.id.tv_hero_tweaks);

        cardPermUsage      = findViewById(R.id.card_perm_usage);
        cardPermDnd        = findViewById(R.id.card_perm_dnd);
        cardPermBrightness = findViewById(R.id.card_perm_brightness);
        ivPermUsage        = findViewById(R.id.iv_perm_usage);
        ivPermDnd          = findViewById(R.id.iv_perm_dnd);
        ivPermBrightness   = findViewById(R.id.iv_perm_brightness);
        tvPermUsage        = findViewById(R.id.tv_perm_usage_label);
        tvPermDnd          = findViewById(R.id.tv_perm_dnd_label);
        tvPermBrightness   = findViewById(R.id.tv_perm_brightness_label);

        cardBattery  = findViewById(R.id.card_profile_battery);
        cardBalanced = findViewById(R.id.card_profile_balanced);
        cardMax      = findViewById(R.id.card_profile_max);

        statsSection  = findViewById(R.id.section_live_stats);
        tvStatRam     = findViewById(R.id.tv_stat_ram);
        tvStatCpu     = findViewById(R.id.tv_stat_cpu);
        tvStatBattery = findViewById(R.id.tv_stat_battery);

        switchVpn   = findViewById(R.id.switch_vpn);
        btnBoost    = findViewById(R.id.btn_boost);
        btnPickGame = findViewById(R.id.btn_pick_game);

        btnBoost.setOnClickListener(v -> onBoostClicked());
    }

    // ── Activity result launchers ──────────────────────────────────────────────

    private void setupActivityResultLaunchers() {
        permLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            r -> updatePermissionCards()
        );
        vpnConsentLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            r -> {
                if (r.getResultCode() == Activity.RESULT_OK && pendingVpnPackage != null) {
                    launchVpnService(pendingVpnPackage);
                }
                pendingVpnPackage = null;
            }
        );
    }

    // ── Profile cards ──────────────────────────────────────────────────────────

    private void setupProfileCards() {
        cardBattery.setOnClickListener(v -> selectProfile(BoostProfile.BATTERY_SAVER));
        cardBalanced.setOnClickListener(v -> selectProfile(BoostProfile.BALANCED));
        cardMax.setOnClickListener(v -> selectProfile(BoostProfile.MAX_PERFORMANCE));
    }

    private void selectProfile(BoostProfile profile) {
        selectedProfile = profile;
        prefs.saveProfile(profile);
        highlightProfileCard(profile);
        updateHeroTweaks();
        if (profile == BoostProfile.MAX_PERFORMANCE && !switchVpn.isChecked()) {
            switchVpn.setChecked(true);
            prefs.saveVpnEnabled(true);
        }
    }

    private void highlightProfileCard(BoostProfile profile) {
        int selectedStroke = ContextCompat.getColor(this, R.color.boost_color);
        int normalStroke   = ContextCompat.getColor(this, R.color.card_stroke);
        int selectedBg     = ContextCompat.getColor(this, R.color.profile_selected_bg);
        int normalBg       = ContextCompat.getColor(this, R.color.bg_card);

        resetProfileCard(cardBattery,  normalStroke, normalBg);
        resetProfileCard(cardBalanced, normalStroke, normalBg);
        resetProfileCard(cardMax,      normalStroke, normalBg);

        MaterialCardView sel = profile == BoostProfile.BATTERY_SAVER ? cardBattery
            : profile == BoostProfile.MAX_PERFORMANCE ? cardMax : cardBalanced;
        sel.setStrokeColor(selectedStroke);
        sel.setStrokeWidth(dpToPx(2));
        sel.setCardBackgroundColor(selectedBg);
    }

    private void resetProfileCard(MaterialCardView c, int stroke, int bg) {
        c.setStrokeColor(stroke);
        c.setStrokeWidth(dpToPx(1));
        c.setCardBackgroundColor(bg);
    }

    // ── VPN switch ─────────────────────────────────────────────────────────────

    private void setupVpnSwitch() {
        switchVpn.setOnCheckedChangeListener((b, checked) -> prefs.saveVpnEnabled(checked));
    }

    // ── App picker ─────────────────────────────────────────────────────────────

    private void setupPickGameButton() {
        btnPickGame.setOnClickListener(v -> openAppPicker());
    }

    private void openAppPicker() {
        AppPickerBottomSheet sheet = AppPickerBottomSheet.newInstance();
        // Sound: play confirmation when user completes selection
        sheet.setOnAppPicked(app -> onAppSelected(app, /*playSound=*/true));
        sheet.show(getSupportFragmentManager(), AppPickerBottomSheet.TAG);
    }

    /**
     * Called when a game is chosen — either from the picker or on restore.
     *
     * @param app       the selected app
     * @param playSound {@code true} to play the selection tone (suppress on restore)
     */
    private void onAppSelected(AppInfo app, boolean playSound) {
        selectedApp = app;
        prefs.saveLastGame(app);

        tvHeroGameName.setText(app.label);
        tvHeroTweaks.setVisibility(View.VISIBLE);
        updateHeroTweaks();

        if (playSound) {
            soundManager.playGameSelected();
        }

        // FIX: load icon off the main thread — getApplicationIcon() does IPC/disk I/O
        if (app.icon != null) {
            ivHeroIcon.setImageDrawable(app.icon);
        } else {
            ivHeroIcon.setImageResource(R.drawable.ic_gamepad); // placeholder immediately
            final String pkg = app.packageName;
            iconExecutor.execute(() -> {
                Drawable icon = null;
                try {
                    icon = getPackageManager().getApplicationIcon(pkg);
                } catch (Exception e) {
                    Log.w(TAG, "Could not load icon for " + pkg, e);
                }
                final Drawable finalIcon = icon;
                mainHandler.post(() -> {
                    // Only update if this is still the selected app
                    if (selectedApp != null && selectedApp.packageName.equals(pkg)) {
                        if (finalIcon != null) {
                            app.icon = finalIcon;
                            ivHeroIcon.setImageDrawable(finalIcon);
                        }
                        // else keep the gamepad placeholder already set above
                    }
                });
            });
        }
    }

    private void restoreLastGame() {
        String pkg   = prefs.getLastPackage();
        String label = prefs.getLastLabel();
        if (pkg != null) {
            AppInfo a = new AppInfo(label != null ? label : pkg, pkg);
            a.isFavorite = prefs.isFavorite(pkg);
            onAppSelected(a, /*playSound=*/false);  // silent restore
        }
    }

    // ── Boost control ──────────────────────────────────────────────────────────

    private void onBoostClicked() {
        if (isBoosting) stopBoosting();
        else            startBoosting();
    }

    private void startBoosting() {
        if (!PermissionHelper.hasUsageAccess(this)) {
            showSettingsDialog(
                "Usage Access Required",
                "GameBooster needs Usage Access to detect when your game exits.\n\n"
                    + "Tap OK → enable GameBooster under Usage access.",
                PermissionHelper.usageAccessIntent()
            );
            return;
        }
        if (selectedApp == null) {
            toast("Tap \"Select Game\" to choose a game first");
            return;
        }
        if (selectedProfile.enableDnd && !PermissionHelper.hasNotificationPolicyAccess(this)) {
            toast("DND access not granted — silence mode will be skipped");
        }
        if (selectedProfile.enableMaxBrightness && !PermissionHelper.canWriteSettings(this)) {
            toast("Write Settings not granted — brightness boost will be skipped");
        }

        Intent svc = new Intent(this, BoostService.class)
            .putExtra(BoostService.EXTRA_PACKAGE, selectedApp.packageName)
            .putExtra(BoostService.EXTRA_LABEL,   selectedApp.label)
            .putExtra(BoostService.EXTRA_PROFILE,  selectedProfile.name());
        startForegroundService(svc);

        if (selectedProfile.enableVpn && switchVpn.isChecked()) {
            requestVpnConsent(selectedApp.packageName);
        }

        syncBoostUi(true);
        soundManager.playBoostOn();                                  // ← SOUND
        toast("⚡ Boost started — " + selectedProfile.displayName);
    }

    private void stopBoosting() {
        stopService(new Intent(this, BoostService.class));

        if (BoostVpnService.isRunning) {
            startService(new Intent(this, BoostVpnService.class)
                .setAction(BoostVpnService.ACTION_STOP));
        }

        syncBoostUi(false);
        soundManager.playBoostOff();                                 // ← SOUND
        toast("Boost stopped");
    }

    // ── VPN consent ────────────────────────────────────────────────────────────

    private void requestVpnConsent(String pkg) {
        Intent prepare = VpnService.prepare(this);
        if (prepare != null) {
            pendingVpnPackage = pkg;
            vpnConsentLauncher.launch(prepare);
        } else {
            launchVpnService(pkg);
        }
    }

    private void launchVpnService(String pkg) {
        startService(new Intent(this, BoostVpnService.class)
            .putExtra(BoostVpnService.EXTRA_GAME_PACKAGE, pkg));
    }

    // ── UI sync ────────────────────────────────────────────────────────────────

    private void syncBoostUi(boolean boosting) {
        isBoosting = boosting;
        if (boosting) {
            btnBoost.setText(R.string.btn_stop);
            btnBoost.setBackgroundTintList(
                ContextCompat.getColorStateList(this, R.color.stop_color));
            tvHeroStatus.setText(R.string.status_active);
            tvHeroStatus.setTextColor(ContextCompat.getColor(this, R.color.perm_ok));
            statsSection.setVisibility(View.VISIBLE);
            startStatsPolling();
        } else {
            btnBoost.setText(R.string.btn_boost);
            btnBoost.setBackgroundTintList(
                ContextCompat.getColorStateList(this, R.color.boost_color));
            tvHeroStatus.setText(selectedApp != null
                ? R.string.status_ready : R.string.status_no_game);
            tvHeroStatus.setTextColor(ContextCompat.getColor(this, R.color.text_secondary));
            statsSection.setVisibility(View.GONE);
            stopStatsPolling();
        }
    }

    // ── Permission cards ───────────────────────────────────────────────────────

    private void updatePermissionCards() {
        setPermCard(cardPermUsage, ivPermUsage, tvPermUsage,
            PermissionHelper.hasUsageAccess(this),
            getString(R.string.perm_usage_short),
            PermissionHelper.usageAccessIntent());
        setPermCard(cardPermDnd, ivPermDnd, tvPermDnd,
            PermissionHelper.hasNotificationPolicyAccess(this),
            getString(R.string.perm_dnd_short),
            PermissionHelper.notificationPolicyIntent());
        setPermCard(cardPermBrightness, ivPermBrightness, tvPermBrightness,
            PermissionHelper.canWriteSettings(this),
            getString(R.string.perm_brightness_short),
            PermissionHelper.writeSettingsIntent(this));
    }

    private void setPermCard(MaterialCardView card, ImageView icon, TextView label,
                              boolean granted, String text, Intent settingsIntent) {
        int okColor    = ContextCompat.getColor(this, R.color.perm_ok);
        int warnColor  = ContextCompat.getColor(this, R.color.perm_warn);
        int okStroke   = ContextCompat.getColor(this, R.color.perm_ok_stroke);
        int warnStroke = ContextCompat.getColor(this, R.color.perm_warn_stroke);
        label.setText(text);
        if (granted) {
            icon.setImageResource(R.drawable.ic_check_circle);
            icon.setColorFilter(okColor);
            card.setStrokeColor(okStroke);
            card.setOnClickListener(null);
        } else {
            icon.setImageResource(R.drawable.ic_warning);
            icon.setColorFilter(warnColor);
            card.setStrokeColor(warnStroke);
            card.setOnClickListener(v -> permLauncher.launch(settingsIntent));
        }
    }

    // ── Hero tweaks count ──────────────────────────────────────────────────────

    private void updateHeroTweaks() {
        if (selectedProfile == null) return;
        int n = selectedProfile.activeTweakCount();
        tvHeroTweaks.setText(n + " optimization" + (n == 1 ? "" : "s") + " active");
    }

    // ── Real-time stats ────────────────────────────────────────────────────────

    private final Runnable statsRunnable = this::refreshStats;

    private void startStatsPolling() {
        statsHandler.removeCallbacks(statsRunnable);
        statsHandler.post(statsRunnable);
    }

    private void stopStatsPolling() {
        statsHandler.removeCallbacks(statsRunnable);
    }

    private void refreshStats() {
        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        long usedMb  = (mi.totalMem - mi.availMem) / (1024 * 1024);
        long totalMb = mi.totalMem / (1024 * 1024);
        tvStatRam.setText(usedMb + " / " + totalMb + " MB");

        IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        Intent bat = registerReceiver(null, ifilter);
        int lvl   = bat != null ? bat.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) : -1;
        int scale = bat != null ? bat.getIntExtra(BatteryManager.EXTRA_SCALE, -1) : -1;
        tvStatBattery.setText((lvl >= 0 && scale > 0)
            ? ((int) (lvl * 100f / scale)) + "%" : "—");

        int pressurePct = (int) (100 - (mi.availMem * 100.0 / mi.totalMem));
        tvStatCpu.setText(pressurePct + "%");

        if (isBoosting) statsHandler.postDelayed(statsRunnable, 2_000L);
    }

    // ── Service state detection ────────────────────────────────────────────────

    @SuppressWarnings("deprecation")
    private boolean isBoostServiceRunning() {
        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo info : am.getRunningServices(Integer.MAX_VALUE)) {
            if (BoostService.class.getName().equals(info.service.getClassName())) return true;
        }
        return false;
    }

    // ── Helpers ────────────────────────────────────────────────────────────────

    private void showSettingsDialog(String title, String msg, Intent intent) {
        new AlertDialog.Builder(this)
            .setTitle(title).setMessage(msg)
            .setPositiveButton("Open Settings", (d, w) -> permLauncher.launch(intent))
            .setNegativeButton("Cancel", null)
            .show();
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }

    private int dpToPx(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density + 0.5f);
    }
}
