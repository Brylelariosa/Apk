package com.gamebooster;

/**
 * Predefined boost profiles that control which system tweaks are applied.
 *
 * <ul>
 *   <li>{@link #BATTERY_SAVER} — minimal tweaks; preserves battery life.</li>
 *   <li>{@link #BALANCED} — recommended default; wake lock + VPN isolation.</li>
 *   <li>{@link #MAX_PERFORMANCE} — all tweaks enabled; best for competitive play.</li>
 * </ul>
 */
public enum BoostProfile {

    BATTERY_SAVER(
        "Battery Saver", "🔋",
        /*wakeLock*/        false,
        /*wifiLock*/        false,
        /*dnd*/             false,
        /*maxBrightness*/   false,
        /*vpn*/             false
    ),

    BALANCED(
        "Balanced", "⚖️",
        /*wakeLock*/        true,
        /*wifiLock*/        true,
        /*dnd*/             false,
        /*maxBrightness*/   false,
        /*vpn*/             false
    ),

    MAX_PERFORMANCE(
        "Max Performance", "🚀",
        /*wakeLock*/        true,
        /*wifiLock*/        true,
        /*dnd*/             true,
        /*maxBrightness*/   true,
        /*vpn*/             true
    );

    public final String displayName;
    public final String emoji;
    public final boolean enableWakeLock;
    public final boolean enableWifiLock;
    public final boolean enableDnd;
    public final boolean enableMaxBrightness;
    public final boolean enableVpn;

    BoostProfile(String displayName, String emoji,
                 boolean enableWakeLock, boolean enableWifiLock,
                 boolean enableDnd, boolean enableMaxBrightness,
                 boolean enableVpn) {
        this.displayName        = displayName;
        this.emoji              = emoji;
        this.enableWakeLock     = enableWakeLock;
        this.enableWifiLock     = enableWifiLock;
        this.enableDnd          = enableDnd;
        this.enableMaxBrightness= enableMaxBrightness;
        this.enableVpn          = enableVpn;
    }

    /** Count of active system tweaks for this profile (shown in the hero card). */
    public int activeTweakCount() {
        int n = 0;
        if (enableWakeLock)      n++;
        if (enableWifiLock)      n++;
        if (enableDnd)           n++;
        if (enableMaxBrightness) n++;
        if (enableVpn)           n++;
        return n;
    }
}
