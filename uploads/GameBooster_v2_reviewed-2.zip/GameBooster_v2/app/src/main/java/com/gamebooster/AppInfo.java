package com.gamebooster;

import android.graphics.drawable.Drawable;

/**
 * Lightweight model representing an installed application that can be boosted.
 *
 * <p>Icons are loaded lazily off the main thread and cached here after first load,
 * so the adapter never triggers a PackageManager icon fetch on the UI thread.
 */
public final class AppInfo {

    /** Human-readable application label (e.g. "PUBG Mobile"). */
    public final String label;

    /** Fully-qualified package name (e.g. "com.tencent.ig"). */
    public final String packageName;

    /**
     * Cached application icon. {@code null} until loaded by the background
     * icon-load pass in {@link AppPickerBottomSheet}.
     */
    public volatile Drawable icon;

    /** {@code true} if the user has starred this app as a favourite. */
    public boolean isFavorite;

    /**
     * Timestamp (ms since epoch) of the last boost session for this app.
     * Used to sort the "Recent" section. {@code 0} means never boosted.
     */
    public long lastBoostTime;

    public AppInfo(String label, String packageName) {
        this.label       = label;
        this.packageName = packageName;
    }

    @Override
    public String toString() {
        // Kept for compatibility with any legacy ArrayAdapter usage.
        return label;
    }
}
