# GameBooster ProGuard rules

# Keep model / data classes that are accessed via reflection or Parcelable
-keep class com.gamebooster.AppInfo { *; }
-keep class com.gamebooster.BoostProfile { *; }

# Keep service classes so the OS can restart them by class name
-keep class com.gamebooster.BoostService { *; }
-keep class com.gamebooster.BoostVpnService { *; }

# Keep all public members of the Application subclass
-keep class com.gamebooster.App { *; }

# AndroidX / Material — strip unused components but keep the ones we use
-keep class androidx.localbroadcastmanager.** { *; }

# Suppress noisy warnings from unused Material stubs
-dontwarn com.google.android.material.**
