# GameBooster — Full Review Report
## UI · UX · Performance · Stability · Code Quality

---

## 1 · Discovered Issues

### 🔴 CRITICAL — Crash / Data-Loss Risk

| # | Location | Issue | Why It Happens |
|---|----------|-------|----------------|
| C-1 | `BoostService.isGameRecentlyActive()` | **NullPointerException** on `gamePackage.equals(…)` | `onStartCommand` may receive a `null` Intent (system restart after `START_STICKY`), so `gamePackage` is null; the null-check only guards scheduling, not the method body. |
| C-2 | `BoostService.acquireWakeLock()` | **WakeLock acquired with no timeout** — can drain the battery indefinitely if `onDestroy` is never called | `wakeLock.acquire()` with no argument holds forever; the OS can kill a foreground service in extreme memory pressure without calling `onDestroy`. |
| C-3 | `MainActivity.loadInstalledAppsAsync()` | **Activity memory leak** — raw `Thread` captures `this` (Activity) via the anonymous `Runnable`/`Handler` closure | If the user rotates the screen or navigates away before the thread finishes, the Activity cannot be garbage-collected. |
| C-4 | `BoostService.isRunning` | **Stale static boolean after process death** — Activity reads `BoostService.isRunning` in `onResume`, but the static field is `false` in the new process even though the OS may have restarted the service | `START_STICKY` causes the OS to recreate the service in a new process; the Activity process is separate and never sees the field set to `true`. |

---

### 🟠 HIGH — Stability / Correctness

| # | Location | Issue | Why It Happens |
|---|----------|-------|----------------|
| H-1 | `BoostService` | **DND not restored after OS-initiated restart** | `dndApplied = false` is the initial value in the new service instance, so `restoreDnd()` exits immediately even though the previous instance may have enabled total-silence DND. There is no persistence of the saved DND state. |
| H-2 | `BoostService.onStartCommand` | **Service starts even when `gamePackage` is null** — the boost tweaks (wake lock, Wi-Fi lock, DND, brightness) are applied with no game to monitor | Missing early-exit guard when the Intent has no `EXTRA_PACKAGE`. |
| H-3 | `MainActivity` | **`pendingVpnPackage` lost on process death** — if the system kills the activity while the VPN consent dialog is open, the package name is gone | `pendingVpnPackage` is a plain instance field; not saved to `onSaveInstanceState`. |
| H-4 | `BoostVpnService.setUp()` | **VPN file descriptor leaked on repeated starts** — if `onStartCommand` is called again while `vpnInterface != null`, the old fd is silently replaced without closing | No null-check / close of existing `vpnInterface` before calling `establish()`. |
| H-5 | `BoostService.buildNotification()` | **Notification shows raw package name** instead of a user-friendly label | `subtitle` is built from `gamePackage` (e.g. `com.example.mygame`) — `PackageManager.getApplicationLabel()` is never called for notifications. |
| H-6 | `MainActivity.stopBoosting()` | **`startService(vpnStop)` is unconditionally called** — if VPN was never started, this creates a new service instance that immediately stops itself, generating unnecessary `onStartCommand` → `tearDown` → `stopSelf` churn | No `BoostVpnService.isRunning` guard before sending the stop intent. |

---

### 🟡 MEDIUM — Code Quality / Performance

| # | Location | Issue | Why It Happens |
|---|----------|-------|----------------|
| M-1 | `MainActivity.loadInstalledAppsAsync()` | **Raw `new Thread()`** — not pooled, not cancellable, not lifecycle-aware | Should use `ExecutorService` + `Handler` or `AsyncTaskLoader`; the thread can outlive the activity. |
| M-2 | `BoostService.monitorRunnable` | **Monitor runs on the main (UI) thread** — `Handler(Looper.getMainLooper())` delivers the runnable there | The `isGameRecentlyActive()` call includes a `UsageStatsManager.queryUsageStats()` which iterates a list; on slow devices this can cause dropped frames. Should use a `HandlerThread`. |
| M-3 | `MainActivity` | **`AppInfo` as a static nested class** — tight coupling, not reusable, serialization impossible | Belongs in its own top-level file. |
| M-4 | `MainActivity` | **No `savedInstanceState` handling** — spinner selection resets on screen rotation | `spinnerGames.getSelectedItemPosition()` is never saved/restored. |
| M-5 | Whole project | **No SharedPreferences** — last-selected game, VPN toggle, and all settings are lost on every app restart | Nothing persists between launches. |
| M-6 | `app/build.gradle` | **`minifyEnabled false` in release** — APK contains all dead code, is larger than necessary, and exposes class names to reverse engineering | Default template value never updated. |
| M-7 | `AndroidManifest.xml` | **No `foregroundServiceType` declared** — mandatory on API 34+ (targetSdk 34) for `startForegroundService()` without a type causes `ForegroundServiceTypeNotAllowedException` | Avoided here by targeting API 33, but any future bump to targetSdk 34 will crash immediately. |
| M-8 | `BoostService` | **`USAGE_LOOKBACK_MS = 600_000` (10 min)** but `GAME_INACTIVE_TIMEOUT_MS = 120_000` (2 min) — discrepancy causes the query window to be 5× larger than needed | Minor waste; the lookback only needs to be slightly larger than the timeout. |
| M-9 | `MainActivity` | **No error handling in `loadInstalledAppsAsync()`** — a `PackageManager` `DeadObjectException` or `SecurityException` will silently crash the thread | No try/catch around the PM call. |
| M-10 | `BoostService` | **`savedDndFilter = INTERRUPTION_FILTER_UNKNOWN` (-1) not guarded robustly** — if `applyDnd()` throws between saving the filter and setting `dndApplied = true`, the flag never sets and DND is never restored | An exception between `savedDndFilter = nm.getCurrent…()` and `nm.setInterruptionFilter(…)` leaves state inconsistent. |

---

### 🔵 LOW — UX / Design

| # | Location | Issue |
|---|----------|-------|
| U-1 | `activity_main.xml` | Plain emoji title instead of proper dashboard hero card. |
| U-2 | `activity_main.xml` | `Spinner` with `toString()` for app display — no icons, no search, no filtering. |
| U-3 | `activity_main.xml` | Permission rows are `TextView` widgets — no card elevation, no icon, no clear visual hierarchy. |
| U-4 | Whole app | No loading state while scanning installed apps (user sees empty spinner). |
| U-5 | Whole app | No empty state when no user apps are found. |
| U-6 | Whole app | No boost profiles (Battery Saver / Balanced / Max Performance). |
| U-7 | Whole app | No favorites or recent games sections. |
| U-8 | Whole app | No real-time monitoring (RAM, CPU, battery, temperature). |
| U-9 | Whole app | No game icon displayed anywhere. |
| U-10 | Whole app | No confirmation feedback when boost starts or stops. |
| U-11 | `spinner_item.xml` | Spinner item is identical to a plain `TextView` — zero differentiation. |
| U-12 | Whole app | VPN switch state not remembered between sessions. |
| U-13 | Whole app | No tablet/landscape layout adaptation. |

---

## 2 · Root-Cause Analysis (selected critical items)

### C-1 — NPE in `isGameRecentlyActive()`
```
// Trigger path:
// 1. OS kills BoostService process.
// 2. OS restarts it (START_STICKY) with a null intent.
// 3. onStartCommand receives null intent → gamePackage = null.
// 4. monitorRunnable fires → isGameRecentlyActive() called.
// 5. gamePackage.equals(…) → NullPointerException.
```

### C-3 — Activity memory leak
```java
// Current code (inner Runnable captures 'this')
new Thread(() -> {
    ...
    new Handler(Looper.getMainLooper()).post(() -> {
        appList.addAll(list);        // 'appList' → 'this' → Activity
        spinnerGames.setAdapter(…); // 'spinnerGames' → 'this' → Activity
    });
}).start();
// If Activity is destroyed before Thread completes, both references
// prevent GC of the old Activity instance.
```

### C-4 — Stale `isRunning` after process death
```java
// Process A (service process): isRunning = true
// User force-closes Activity process → Process B created
// Process B: BoostService.isRunning == false  (new JVM, new statics)
// onResume calls syncBoostUi(false) → button shows "Boost!" even though
// the service is actively running in Process A.
```

---

## 3 · Optimized Implementations

See the accompanying source files in this deliverable for complete,
compilable implementations of every fix and enhancement.

### Fix summary per file

| File | Changes |
|------|---------|
| `App.java` | No changes needed — channel creation is correct. |
| `AppInfo.java` | Extracted to own file; added `icon`, `isFavorite`, `lastBoostTime` fields. |
| `AppAdapter.java` | **New** — `RecyclerView.Adapter` with icons, search, favorites. |
| `AppPickerBottomSheet.java` | **New** — `BottomSheetDialogFragment` with `SearchView` + `RecyclerView`. |
| `BoostProfile.java` | **New** — enum for Battery Saver / Balanced / Max Performance. |
| `GamePreferences.java` | **New** — `SharedPreferences` wrapper for all persistent state. |
| `PermissionHelper.java` | Added `bindingServiceCheck()`; no breaking changes. |
| `BoostService.java` | Fix C-1 (null guard), C-2 (WakeLock timeout), H-1 (persist DND state), H-2 (null gamePackage guard), H-5 (friendly label in notification), M-2 (HandlerThread for monitor), M-8 (reduced lookback window). |
| `BoostVpnService.java` | Fix H-4 (close existing vpnInterface before re-establish), H-6 (isRunning guard). |
| `MainActivity.java` | Complete rewrite — dashboard hero card, app picker bottom sheet, permission cards, boost profiles, real-time stats, SharedPreferences, savedInstanceState, service-state binding via query, ExecutorService app loader. |
| `activity_main.xml` | Complete rewrite — premium dashboard layout. |
| `bottom_sheet_app_picker.xml` | **New** — searchable app picker sheet. |
| `item_app_picker.xml` | **New** — per-app row with icon + label + package + favourite star. |
| `colors.xml` | Extended with stat, profile, and hero gradient colors. |
| `strings.xml` | Extended with all new UI strings. |
| `themes.xml` | Added Material3 overlay and WindowInsets support. |
| `dimens.xml` | **New** — centralised spacing and elevation tokens. |
| `app/build.gradle` | Added RecyclerView dep; `minifyEnabled true` in release; added ProGuard rule for model classes. |
| `AndroidManifest.xml` | Added `foregroundServiceType="specialUse"` on both services; added `tools:targetApi` for lint. |
