package com.jarry.floatnote.data

import androidx.test.core.app.ApplicationProvider
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

/**
 * Lightweight regression coverage for NoteRepository, focused on the
 * behaviors this refactor introduced or changed: conflict-safe content
 * saves, pin/content column isolation, autosave's save-or-delete-if-empty
 * rule, and the "durable" save path floating windows and the editor's
 * onPause() rely on. Each test gets its own in-memory database (see
 * NoteDbHelper's dbName=null) so tests never see each other's data.
 */
@RunWith(RobolectricTestRunner::class)
class NoteRepositoryTest {

    private lateinit var repository: NoteRepository
    private lateinit var dbHelper: NoteDbHelper

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<android.content.Context>()
        dbHelper = NoteDbHelper(context, dbName = null)
        repository = NoteRepository(dbHelper)
    }

    /** Unwraps a [SaveOrDeleteOutcome] for tests whose setup steps only
     *  care about the happy path - fails loudly rather than silently
     *  papering over a setup step that unexpectedly hit a conflict or a
     *  deleted-elsewhere outcome, which would itself mean the test's own
     *  premise is broken. */
    private suspend fun NoteRepository.saveOrDeleteIfEmptyExpectingSaved(note: Note): Note =
        when (val outcome = saveOrDeleteIfEmpty(note)) {
            is SaveOrDeleteOutcome.Saved -> outcome.note
            SaveOrDeleteOutcome.DeletedElsewhere ->
                error("saveOrDeleteIfEmpty($note) unexpectedly reported DeletedElsewhere")
            SaveOrDeleteOutcome.Conflict ->
                error("saveOrDeleteIfEmpty($note) unexpectedly reported Conflict")
        }

    // ---- Basic CRUD -----------------------------------------------------

    @Test
    fun `save inserts a new note and getById returns it`() = runTest {
        val id = repository.save(Note(title = "Groceries", content = "Milk, eggs"))
        val loaded = repository.getById(id)
        assertEquals("Groceries", loaded?.title)
        assertEquals("Milk, eggs", loaded?.content)
    }

    @Test
    fun `delete removes the row`() = runTest {
        val id = repository.save(Note(title = "Temp"))
        repository.delete(id)
        assertNull(repository.getById(id))
    }

    @Test
    fun `getAll filters by title or content and sorts pinned first`() = runTest {
        repository.save(Note(title = "Apple pie recipe"))
        val pinnedId = repository.save(Note(title = "Unrelated", content = "mentions apple once"))
        repository.setPinned(pinnedId, true)
        repository.save(Note(title = "Banana bread"))

        val results = repository.getAll("apple")
        assertEquals(2, results.size)
        // Pinned match sorts first even though it was saved after the other match.
        assertTrue(results.first().isPinned)
    }

    // ---- Autosave / save-or-delete-if-empty ------------------------------

    @Test
    fun `saveOrDeleteIfEmpty inserts non-blank content`() = runTest {
        val saved = repository.saveOrDeleteIfEmptyExpectingSaved(Note(title = "Idea", content = "Ship it"))
        assertNotEquals(0L, saved.id)
        assertEquals(1, saved.version)
    }

    @Test
    fun `saveOrDeleteIfEmpty deletes an existing row when cleared to blank`() = runTest {
        val saved = repository.saveOrDeleteIfEmptyExpectingSaved(Note(title = "Draft", content = "text"))
        val cleared = repository.saveOrDeleteIfEmptyExpectingSaved(saved.copy(title = "", content = ""))
        assertEquals(0L, cleared.id)
        assertNull(repository.getById(saved.id))
    }

    @Test
    fun `saveOrDeleteIfEmpty on a still-blank new note never inserts a row`() = runTest {
        val result = repository.saveOrDeleteIfEmptyExpectingSaved(Note())
        assertEquals(0L, result.id)
    }

    @Test
    fun `saveOrDeleteIfEmpty saves normal edits to an existing note`() = runTest {
        val saved = repository.saveOrDeleteIfEmptyExpectingSaved(Note(title = "Original", content = "v1"))
        val updated = repository.saveOrDeleteIfEmptyExpectingSaved(saved.copy(content = "v2"))

        assertEquals(saved.id, updated.id)
        assertEquals(saved.version + 1, updated.version)
        assertEquals("v2", repository.getById(saved.id)?.content)
    }

    @Test
    fun `repeated autosave calls update the same row instead of inserting duplicates`() = runTest {
        var note = repository.saveOrDeleteIfEmptyExpectingSaved(Note(title = "v1"))
        val firstId = note.id
        note = repository.saveOrDeleteIfEmptyExpectingSaved(note.copy(title = "v2"))
        note = repository.saveOrDeleteIfEmptyExpectingSaved(note.copy(title = "v3"))

        assertEquals(firstId, note.id)
        assertEquals("v3", repository.getById(firstId)?.title)
        assertEquals(1, repository.getAll().size)
    }

    // ---- Conflict resolution and deletion safety --------------------------

    @Test
    fun `saveContentIfUnchanged succeeds and increments version when expectedVersion matches`() = runTest {
        val saved = repository.saveOrDeleteIfEmptyExpectingSaved(Note(title = "a", content = "b"))
        val outcome = repository.saveContentIfUnchanged(saved.copy(title = "a2"), saved.version)
        val result = outcome as SaveOutcome.Saved
        assertEquals(saved.version + 1, result.note.version)
        assertEquals("a2", repository.getById(saved.id)?.title)
    }

    @Test
    fun `saveContentIfUnchanged reports Conflict when the version moved on`() = runTest {
        val saved = repository.saveOrDeleteIfEmptyExpectingSaved(Note(title = "a", content = "b"))
        // Someone else's write lands first (e.g. a different window's autosave).
        repository.saveContentIfUnchanged(saved.copy(content = "elsewhere"), saved.version)

        // This caller is still holding the *original* version number.
        val outcome = repository.saveContentIfUnchanged(saved.copy(title = "stale writer"), saved.version)
        assertEquals(SaveOutcome.Conflict, outcome)
        // The conflicting write must not have been applied.
        assertEquals("elsewhere", repository.getById(saved.id)?.content)
    }

    @Test
    fun `saveContentIfUnchanged reports DeletedElsewhere and never resurrects the row`() = runTest {
        val saved = repository.saveOrDeleteIfEmptyExpectingSaved(Note(title = "a", content = "b"))
        repository.delete(saved.id)

        val outcome = repository.saveContentIfUnchanged(saved.copy(title = "too late"), saved.version)
        assertEquals(SaveOutcome.DeletedElsewhere, outcome)
        assertNull(repository.getById(saved.id))
    }

    @Test
    fun `saveOrDeleteIfEmpty retries through a genuine version conflict and still saves`() = runTest {
        val saved = repository.saveOrDeleteIfEmptyExpectingSaved(Note(title = "a", content = "b"))

        // Someone else's write lands first, moving the row to a version
        // this caller doesn't know about yet.
        repository.saveContentIfUnchanged(saved.copy(content = "someone else"), saved.version)

        // This caller is still holding the *original* version number, same
        // as a floating window whose in-memory copy hasn't resynced - it
        // should re-read and retry rather than give up, and its own
        // in-progress edit should still win over the merely-newer version.
        val outcome = repository.saveOrDeleteIfEmpty(saved.copy(content = "my stale edit"))

        val result = outcome as SaveOrDeleteOutcome.Saved
        assertEquals(saved.id, result.note.id)
        assertEquals("my stale edit", repository.getById(saved.id)?.content)
    }

    @Test
    fun `saveOrDeleteIfEmpty reports DeletedElsewhere and does not resurrect a note deleted elsewhere`() = runTest {
        val saved = repository.saveOrDeleteIfEmptyExpectingSaved(Note(title = "a", content = "b"))
        repository.delete(saved.id)

        // Simulates a floating window's next autosave firing after the main
        // list swiped the note away: the editor still has no way to know
        // its copy is stale.
        val outcome = repository.saveOrDeleteIfEmpty(saved.copy(content = "still typing"))

        assertEquals(SaveOrDeleteOutcome.DeletedElsewhere, outcome)
        assertNull(repository.getById(saved.id))
        // The deleted note's content must not live on anywhere else either
        // - not at the old id, and not resurrected as a "new" note.
        assertEquals(0, repository.getAll().size)
    }

    // ---- Storage exceptions -------------------------------------------

    @Test
    fun `a storage exception during a conflict-checked write reports Conflict, not a deletion or a save`() = runTest {
        val saved = repository.saveOrDeleteIfEmptyExpectingSaved(Note(title = "keep", content = "safe"))

        // Simulates a real storage failure (a corrupt page, a full disk,
        // etc.) on exactly the write saveContentIfUnchanged issues - reads
        // are unaffected, only the UPDATE itself fails.
        dbHelper.writableDatabase.execSQL(
            "CREATE TRIGGER block_updates BEFORE UPDATE ON notes " +
                "BEGIN SELECT RAISE(ABORT, 'simulated storage failure'); END"
        )
        try {
            val outcome = repository.saveContentIfUnchanged(saved.copy(title = "should not land"), saved.version)
            // Fails closed as a Conflict - never mistaken for a successful
            // save, and never mistaken for the row having been deleted.
            assertEquals(SaveOutcome.Conflict, outcome)
        } finally {
            dbHelper.writableDatabase.execSQL("DROP TRIGGER block_updates")
        }

        val reloaded = repository.getById(saved.id)
        assertEquals("keep", reloaded?.title)
        assertEquals(1, reloaded?.version)
    }

    @Test
    fun `saveOrDeleteIfEmpty never overwrites or reinserts a note when every write attempt fails`() = runTest {
        val saved = repository.saveOrDeleteIfEmptyExpectingSaved(Note(title = "keep", content = "safe"))

        dbHelper.writableDatabase.execSQL(
            "CREATE TRIGGER block_updates BEFORE UPDATE ON notes " +
                "BEGIN SELECT RAISE(ABORT, 'simulated storage failure'); END"
        )
        val outcome = try {
            // Every one of the conflict retries hits the same storage
            // failure, exhausting them - this must never fall back to an
            // unconditional overwrite.
            repository.saveOrDeleteIfEmpty(saved.copy(content = "attempted during outage"))
        } finally {
            dbHelper.writableDatabase.execSQL("DROP TRIGGER block_updates")
        }

        assertFalse(
            "a sustained storage failure must never be silently reported as saved",
            outcome is SaveOrDeleteOutcome.Saved
        )
        val reloaded = repository.getById(saved.id)
        // The original content survives untouched...
        assertEquals("safe", reloaded?.content)
        // ...and nothing was inserted as a "new" note either.
        assertEquals(1, repository.getAll().size)
    }

    // ---- Pin / content column isolation -----------------------------------

    @Test
    fun `setPinned never touches title or content`() = runTest {
        val saved = repository.saveOrDeleteIfEmptyExpectingSaved(Note(title = "keep me", content = "keep me too"))
        repository.setPinned(saved.id, true)
        val reloaded = repository.getById(saved.id)
        assertTrue(reloaded!!.isPinned)
        assertEquals("keep me", reloaded.title)
        assertEquals("keep me too", reloaded.content)
    }

    @Test
    fun `a stale content save never clobbers a pin toggled elsewhere`() = runTest {
        val saved = repository.saveOrDeleteIfEmptyExpectingSaved(Note(title = "a", content = "b"))
        // A floating window loaded the note before it was pinned from the list.
        val staleCopy = saved
        repository.setPinned(saved.id, true)

        // The floating window's autosave fires afterward with its
        // (pin-unaware) in-memory copy.
        repository.saveOrDeleteIfEmpty(staleCopy.copy(content = "edited in floating window"))

        val reloaded = repository.getById(saved.id)
        assertTrue("pin toggled from the list must survive a concurrent content save", reloaded!!.isPinned)
        assertEquals("edited in floating window", reloaded.content)
    }

    // ---- Durable persistence (floating note / onPause style) --------------

    @Test
    fun `saveOrDeleteIfEmptyDurable completes even though nothing awaits it immediately`() = runTest {
        val deferred = repository.saveOrDeleteIfEmptyDurable(Note(title = "background save", content = "x"))
        val result = (deferred.await() as SaveOrDeleteOutcome.Saved).note
        assertNotEquals(0L, result.id)
        assertEquals("background save", repository.getById(result.id)?.title)
    }

    @Test
    fun `saveOrDeleteIfEmptyDurable for a brand new note lets a later caller adopt its id`() = runTest {
        // Mirrors NoteEditorActivity's rotation hand-off: onPause() fires a
        // durable save for a still-unsaved note, and the recreated instance
        // awaits the same Deferred instead of racing it with its own insert.
        val deferred = repository.saveOrDeleteIfEmptyDurable(Note(content = "typed just before rotating"))
        val adopted = (deferred.await() as SaveOrDeleteOutcome.Saved).note
        assertFalse(adopted.id == 0L)
    }
}
