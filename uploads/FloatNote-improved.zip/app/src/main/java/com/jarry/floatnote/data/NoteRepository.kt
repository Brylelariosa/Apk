package com.jarry.floatnote.data

import android.content.Context
import android.os.CancellationSignal
import android.os.OperationCanceledException
import android.util.Log
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.job
import kotlinx.coroutines.withContext
import kotlin.coroutines.coroutineContext

/** Outcome of a conflict-aware content write - see [NoteRepository.saveContentIfUnchanged]. */
sealed interface SaveOutcome {
    /** Write succeeded; carries the note as now persisted (fresh id/version/updatedAt). */
    data class Saved(val note: Note) : SaveOutcome

    /** The row's version no longer matched what the caller expected - someone
     *  else's write landed first. Nothing was written. */
    data object Conflict : SaveOutcome

    /** The row this note pointed at no longer exists (deleted elsewhere).
     *  Nothing was written. */
    data object DeletedElsewhere : SaveOutcome
}

/** Outcome of [NoteRepository.saveOrDeleteIfEmpty]. */
sealed interface SaveOrDeleteOutcome {
    /** The note is now correctly reflected in the DB - an ordinary
     *  insert/update landed, a genuine version conflict was retried until
     *  it landed, or [note] was blank and its row (if any) was deleted.
     *  [note] is what the caller should adopt as its new in-memory copy in
     *  every one of those cases. */
    data class Saved(val note: Note) : SaveOrDeleteOutcome

    /** The row this note pointed at had already been deleted elsewhere
     *  (e.g. swiped away from the main list) by the time this write was
     *  attempted. Nothing was written - the caller's in-memory copy is
     *  deliberately left exactly as it handed it in, rather than this
     *  method silently reinserting it as a "new" note. It's up to the
     *  caller to decide what, if anything, to do with content the user may
     *  still be looking at. */
    data object DeletedElsewhere : SaveOrDeleteOutcome

    /** The row still exists, but kept getting written by some other writer
     *  on every retry, so this call never got a chance to land - see
     *  MAX_CONFLICT_RETRIES's call site for why that's pathological and
     *  shouldn't happen in practice. Nothing was written. Unlike the row
     *  actually being gone, this is never silently converted into a
     *  deletion, and unlike a resolvable conflict, it is never forced
     *  through with an unconditional overwrite - either would risk
     *  clobbering whatever that other writer just landed. */
    data object Conflict : SaveOrDeleteOutcome
}

/**
 * Suspend wrapper around [NoteDbHelper] that also centralizes error
 * handling, search cancellation, and multi-writer conflict resolution for
 * the whole app: every DB operation can in principle throw (disk full,
 * corrupt database file, etc.), and callers shouldn't have to guard against
 * that individually. Failures are logged and degraded to a safe fallback (an
 * empty list, a null note, an unchanged id) rather than propagating and
 * crashing whatever screen or floating window triggered them.
 */
class NoteRepository internal constructor(private val dbHelper: NoteDbHelper) {

    /**
     * Scope for saves that must survive the death of whatever Android
     * component (Activity/Service) triggered them - e.g. the final autosave
     * fired from NoteEditorActivity.onPause() or FloatingNoteService.onDestroy()
     * right as that component is torn down. Deliberately NOT a child of
     * lifecycleScope or serviceScope: both of those are cancelled as part of
     * that exact teardown, which would race - and could silently drop - the
     * very save they're meant to guarantee. Because this scope is
     * structurally independent (its own SupervisorJob, not parented to
     * either caller), cancelling lifecycleScope/serviceScope can never
     * reach in and interrupt a write already under way here, without
     * needing NonCancellable guards at every call site.
     *
     * Dispatchers.IO so callers never block their own (often main) thread
     * waiting for this - see saveOrDeleteIfEmptyDurable.
     */
    private val durableScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    suspend fun getAll(query: String = "", sortOrder: NoteSortOrder = NoteSortOrder.RECENTLY_EDITED): List<Note> = withContext(Dispatchers.IO) {
        // Ties this native SQLite query to the coroutine's own cancellation:
        // if the caller (e.g. MainActivity.loadNotes on a newer keystroke)
        // cancels the Job that's running this, signal.cancel() interrupts
        // sqlite3_step() from wherever it currently is instead of letting a
        // large/unindexed LIKE scan grind on to completion for a result
        // nobody wants anymore - see NoteDbHelper.getAll.
        val signal = CancellationSignal()
        coroutineContext.job.invokeOnCompletion { cause ->
            if (cause is CancellationException) signal.cancel()
        }
        try {
            dbHelper.getAll(query, sortOrder, signal)
        } catch (e: OperationCanceledException) {
            throw CancellationException("getAll($query) cancelled", e)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "getAll failed", e)
            emptyList()
        }
    }

    suspend fun getById(id: Long): Note? = withContext(Dispatchers.IO) {
        try {
            dbHelper.getById(id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "getById($id) failed", e)
            null
        }
    }

    /** Unconditional insert-or-update, last-write-wins - kept for simple
     *  callers that can't conflict by construction (a brand-new note being
     *  inserted, or MainActivity's undo-after-delete, which always inserts
     *  a fresh row). Prefer [saveContentIfUnchanged] (via
     *  [saveOrDeleteIfEmpty]) for any writer whose in-memory copy of the
     *  note could have gone stale in the background -
     *  [saveOrDeleteIfEmpty] deliberately never falls back to this method,
     *  since doing so on a real conflict or an external deletion would
     *  silently overwrite or reinsert exactly what that method exists to
     *  prevent. */
    suspend fun save(note: Note): Long = withContext(Dispatchers.IO) {
        val stamped = note.copy(updatedAt = System.currentTimeMillis())
        try {
            if (stamped.id == 0L) {
                dbHelper.insert(stamped)
            } else {
                dbHelper.update(stamped)
                stamped.id
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "save(${note.id}) failed", e)
            // Fall back to whatever id the note already had so the caller's
            // in-memory state stays consistent (a new note stays "unsaved"
            // rather than being mistaken for a successful insert).
            note.id
        }
    }

    suspend fun delete(id: Long) = withContext(Dispatchers.IO) {
        try {
            dbHelper.delete(id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "delete($id) failed", e)
        }
    }

    /** Toggles/sets only the pinned flag - see
     *  [NoteDbHelper.setPinned] for why this is deliberately narrow rather
     *  than routed through [save] with a full-row overwrite: pinning a note
     *  from the main list must never clobber title/content a floating
     *  window or the editor autosaved moments ago that just hasn't made it
     *  into the list's own (debounced, periodically-refreshed) snapshot yet. */
    suspend fun setPinned(id: Long, pinned: Boolean) = withContext(Dispatchers.IO) {
        try {
            dbHelper.setPinned(id, pinned, System.currentTimeMillis())
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "setPinned($id) failed", e)
        }
    }

    /**
     * Version-checked content save - the conflict-aware building block
     * every writer that could go stale in the background (floating note
     * windows; the full editor, for the same reason) should use instead of
     * [save]. Only ever touches title/content/color/updatedAt/version -
     * see [NoteDbHelper.updateContentIfVersionMatches] for why pinned is
     * excluded on purpose.
     *
     * A brand-new, not-yet-persisted note ([note].id == 0) has nothing to
     * conflict with yet, so this always inserts it, same as [save] would.
     */
    suspend fun saveContentIfUnchanged(note: Note, expectedVersion: Int): SaveOutcome =
        withContext(Dispatchers.IO) {
            val stamped = note.copy(updatedAt = System.currentTimeMillis())
            try {
                if (stamped.id == 0L) {
                    val newId = dbHelper.insert(stamped)
                    SaveOutcome.Saved(stamped.copy(id = newId, version = 1))
                } else {
                    val rows = dbHelper.updateContentIfVersionMatches(stamped, expectedVersion)
                    when {
                        rows > 0 -> SaveOutcome.Saved(stamped.copy(version = expectedVersion + 1))
                        dbHelper.getById(stamped.id) == null -> SaveOutcome.DeletedElsewhere
                        else -> SaveOutcome.Conflict
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "saveContentIfUnchanged(${note.id}) failed", e)
                // Fail closed: an unexpected error here means we don't know
                // whether the write landed, so the caller should not trust
                // its in-memory version and should re-sync rather than
                // silently moving on as if nothing happened.
                SaveOutcome.Conflict
            }
        }

    /**
     * Saves [note]'s title/content, or deletes the row if the user cleared
     * both - the "autosave or clean up an emptied note" rule shared by the
     * full-screen editor, a single floating window's own close/dismiss, and
     * the whole-service shutdown path, so all three agree on it instead of
     * three independent copies risking disagreement.
     *
     * Built on [saveContentIfUnchanged], so it inherits that method's
     * conflict-safety: on a genuine version conflict (the row changed since
     * [note] was last read/saved) this re-reads the current version and
     * retries - the caller's own in-progress edit is what the user is
     * looking at right now, so it should still win over a merely-newer
     * version number, just never over an outright deletion. If the row is
     * gone entirely - deleted elsewhere while this caller still held an
     * older copy - this returns [SaveOrDeleteOutcome.DeletedElsewhere]
     * without writing anything: a confirmed external deletion is never
     * silently turned back into a fresh insert of the same (now stale)
     * content. See [SaveOrDeleteOutcome] for how a caller should react to
     * each outcome.
     */
    suspend fun saveOrDeleteIfEmpty(note: Note): SaveOrDeleteOutcome {
        if (note.title.isBlank() && note.content.isBlank()) {
            if (note.id != 0L) delete(note.id)
            return SaveOrDeleteOutcome.Saved(note.copy(id = 0L, version = 0))
        }
        var current = note
        repeat(MAX_CONFLICT_RETRIES) {
            when (val outcome = saveContentIfUnchanged(current, current.version)) {
                is SaveOutcome.Saved -> return SaveOrDeleteOutcome.Saved(outcome.note)
                SaveOutcome.DeletedElsewhere -> return SaveOrDeleteOutcome.DeletedElsewhere
                SaveOutcome.Conflict -> {
                    // Re-read to retry with the row's current version - not
                    // to re-derive whether it's deleted (saveContentIfUnchanged
                    // already made that call above), but a null here means
                    // it was deleted in the gap between that check and this
                    // one, so it gets the same treatment: report it, don't
                    // resurrect it.
                    val fresh = getById(current.id) ?: return SaveOrDeleteOutcome.DeletedElsewhere
                    current = current.copy(version = fresh.version)
                }
            }
        }
        // Retries exhausted while some other writer kept landing first on
        // every single attempt - pathological, and shouldn't happen in
        // practice given this app never has two live writers actively
        // saving the same note id at once (see FloatingNoteService's
        // isNoteFloating/showNote guards). The row is confirmed to still
        // exist (the check above would have returned DeletedElsewhere
        // otherwise), so this is a real, unresolved conflict - it must
        // never be forced through with an unconditional save(), which would
        // silently overwrite whatever that other writer just landed, the
        // exact last-write-wins clobbering this whole method exists to
        // avoid. The caller keeps whatever in-memory copy it already had.
        Log.w(TAG, "saveOrDeleteIfEmpty(${note.id}) exhausted conflict retries without resolving")
        return SaveOrDeleteOutcome.Conflict
    }

    /**
     * Fires [saveOrDeleteIfEmpty] on [durableScope] instead of the caller's
     * own scope, returning a [Deferred] the caller can [Deferred.await]
     * later (from a *different*, still-alive scope/coroutine) if it needs
     * the resulting id/version - e.g. NoteEditorActivity hands this across
     * a rotation via onRetainCustomNonConfigurationInstance so the
     * recreated instance can pick up the id a brand-new note was just
     * assigned. Callers that don't need the result (e.g.
     * FloatingNoteService tearing down a window for good) can simply not
     * await it - the write still completes independently either way.
     *
     * This never blocks the calling thread: it only launches the work and
     * returns immediately, which is what makes it safe to call from
     * onPause()/onDestroy() without freezing the UI.
     */
    fun saveOrDeleteIfEmptyDurable(note: Note): Deferred<SaveOrDeleteOutcome> =
        durableScope.async { saveOrDeleteIfEmpty(note) }

    companion object {
        private const val TAG = "NoteRepository"
        private const val MAX_CONFLICT_RETRIES = 3

        @Volatile private var instance: NoteRepository? = null
        fun getInstance(context: Context): NoteRepository =
            instance ?: synchronized(this) {
                instance ?: NoteRepository(NoteDbHelper(context.applicationContext)).also { instance = it }
            }
    }
}
