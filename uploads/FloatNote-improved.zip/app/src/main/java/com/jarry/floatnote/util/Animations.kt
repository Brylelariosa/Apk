package com.jarry.floatnote.util

import android.view.View
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.Interpolator

/**
 * The app's shared motion vocabulary. Every animation elsewhere (list,
 * editor, settings, floating card/bubble) goes through these helpers and
 * durations, so speed and feel stay consistent and can be tuned in one
 * place instead of per call site.
 */
const val ANIM_FAST_MS = 120L
const val ANIM_MEDIUM_MS = 220L

/**
 * Scales (and by default fades) this view up to its normal state - the
 * "appear" half of the card/bubble pop. Safe to call on a view that hasn't
 * been attached yet (e.g. right before `WindowManager.addView`): the
 * starting state is applied immediately, so there's no one-frame flash at
 * full size, and the animation itself starts once the view is attached.
 *
 * Pass `fade = false` for views whose [View.alpha] is already in use for
 * something else (the bubble icon's alpha is the user's opacity setting -
 * see applyBubbleVisuals) so this never overwrites it, and when using an
 * overshooting [interpolator], which would push a faded alpha past 1.
 */
fun View.popIn(
    startScale: Float = 0.88f,
    durationMs: Long = ANIM_MEDIUM_MS,
    interpolator: Interpolator = DecelerateInterpolator(1.6f),
    fade: Boolean = true
) {
    animate().cancel()
    scaleX = startScale
    scaleY = startScale
    if (fade) alpha = 0f
    val animator = animate().scaleX(1f).scaleY(1f)
    if (fade) animator.alpha(1f)
    animator.setDuration(durationMs).setInterpolator(interpolator).start()
}

/**
 * The "disappear" half: fades and shrinks this view slightly, then runs
 * [onEnd]. [onEnd] runs only if the animation finishes normally - if the
 * view is torn down (or the animation cancelled) mid-way, it is skipped,
 * so callers must cancel with `view.animate().cancel()` when removing the
 * view and must not rely on [onEnd] for cleanup that has to happen anyway.
 */
fun View.popOut(
    durationMs: Long = ANIM_FAST_MS,
    endScale: Float = 0.92f,
    onEnd: () -> Unit
) {
    animate().cancel()
    animate()
        .alpha(0f)
        .scaleX(endScale)
        .scaleY(endScale)
        .setDuration(durationMs)
        .setInterpolator(AccelerateInterpolator())
        .withEndAction(onEnd)
        .start()
}

/**
 * Shows or hides this view with a fade instead of an instant
 * VISIBLE/GONE flip. A no-op when it's already in the requested state, so
 * it's cheap to call on every data refresh.
 */
fun View.fadeTo(visible: Boolean, durationMs: Long = ANIM_MEDIUM_MS) {
    animate().cancel()
    if (visible) {
        if (visibility == View.VISIBLE && alpha == 1f) return
        if (visibility != View.VISIBLE) {
            alpha = 0f
            visibility = View.VISIBLE
        }
        animate().alpha(1f).setDuration(durationMs).start()
    } else {
        if (visibility != View.VISIBLE) return
        animate().alpha(0f).setDuration(durationMs).withEndAction { visibility = View.GONE }.start()
    }
}

/** Fades this view to [target] alpha - for enabled/disabled dimming that
 *  should ease rather than snap. */
fun View.animateAlphaTo(target: Float, durationMs: Long = ANIM_FAST_MS) {
    animate().alpha(target).setDuration(durationMs).start()
}
