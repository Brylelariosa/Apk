package com.jarry.floatnote

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.jarry.floatnote.data.Note
import com.jarry.floatnote.data.NoteRepository
import com.jarry.floatnote.data.SaveOrDeleteOutcome
import com.jarry.floatnote.databinding.ActivityNoteEditorBinding
import com.jarry.floatnote.util.Debouncer
import com.jarry.floatnote.util.OverlayPermission
import com.jarry.floatnote.util.PaperStyles
import com.jarry.floatnote.util.UndoRedoManager
import com.jarry.floatnote.util.applyBottomSystemBarPadding
import com.jarry.floatnote.util.applyContentTextSize
import com.jarry.floatnote.util.applyImeBottomPadding
import com.jarry.floatnote.util.applyTopSystemBarPadding
import com.jarry.floatnote.util.bindCopyButton
import com.jarry.floatnote.util.bindNumberedListButton
import com.jarry.floatnote.util.bindPasteButton
import com.jarry.floatnote.util.bindToButtons
import com.jarry.floatnote.util.clipToRoundedCorners
import com.jarry.floatnote.util.dpToPx
import com.jarry.floatnote.util.expandTouchTarget
import com.jarry.floatnote.util.formatWordAndCharCount
import com.jarry.floatnote.util.showNoteStylePicker
import com.jarry.floatnote.util.simpleWatcher
import com.jarry.floatnote.widget.CornerAccentBar
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class NoteEditorActivity : AppCompatActivity() {

    private lateinit var binding: ActivityNoteEditorBinding
    private lateinit var repository: NoteRepository
    private lateinit var undoRedo: UndoRedoManager
    private lateinit var saveDebouncer: Debouncer
    private var note = Note()

    // The final save fired from onPause() (see there) - retained across a
    // configuration-change recreation via onRetainCustomNonConfigurationInstance
    // so the *new* instance can pick up its result (in particular, the id a
    // brand-new note was just assigned) instead of racing it. Null once
    // nothing is outstanding.
    private var pendingSave: Deferred<SaveOrDeleteOutcome>? = null

    // Set once the user confirms deleting this note. onPause() runs as part
    // of finish(), and without this it would snapshot the still-populated
    // editor and save it again - harmless for a note that already had a row
    // (that write reports DeletedElsewhere), but for a brand-new note that
    // hadn't autosaved yet (no id), it would insert the note the user just
    // deleted.
    private var isDeleting = false

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        binding = ActivityNoteEditorBinding.inflate(layoutInflater)
        setContentView(binding.root)
        repository = NoteRepository.getInstance(this)
        saveDebouncer = Debouncer(lifecycleScope)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }
        applyInsets()

        binding.cardBackground.clipToRoundedCorners(resources.getDimension(R.dimen.card_corner_radius_editor))
        applyEffectiveStyle()
        applyContentTextSize(binding.editContent, this)
        binding.spineAccent.setOnClickListener { showStylePicker() }
        binding.spineAccent.expandTouchTarget(dpToPx(48f))

        undoRedo = UndoRedoManager(binding.editContent, lifecycleScope)
        undoRedo.bindToButtons(binding.buttonUndo, binding.buttonRedo)
        bindNumberedListButton(binding.editContent, binding.buttonNumberedList, this)
        bindCopyButton(binding.editContent, binding.buttonCopy, this)
        bindPasteButton(binding.editContent, binding.buttonPaste, this)

        val watcher = simpleWatcher { scheduleAutoSave() }
        binding.editTitle.addTextChangedListener(watcher)
        binding.editContent.addTextChangedListener(watcher)
        binding.editContent.addTextChangedListener(simpleWatcher { updateWordCount() })

        // A configuration change (rotation, dark mode toggle, multi-window
        // resize, etc.) recreates this Activity with the *original* Intent,
        // whose EXTRA_NOTE_ID is still 0 for a note that was brand new when
        // this screen first opened - even if it has since been assigned a
        // real id by an autosave. Without restoring that id from saved
        // state, the recreated instance would treat the note as new again
        // and the next autosave would INSERT a second, duplicate row
        // instead of updating the first.
        @Suppress("DEPRECATION") // see pendingSave / onRetainCustomNonConfigurationInstance
        val retainedSave = lastCustomNonConfigurationInstance as? Deferred<SaveOrDeleteOutcome>
        val restoredNoteId = savedInstanceState?.getLong(STATE_NOTE_ID, 0L) ?: 0L
        val noteId = if (restoredNoteId != 0L) restoredNoteId else intent.getLongExtra(EXTRA_NOTE_ID, 0L)

        lifecycleScope.launch {
            // If the previous instance's onPause save is still in flight -
            // only possible right after an immediate rotation, since it's
            // otherwise long finished by the time anything reads `note`
            // again - wait for it first (a plain coroutine suspend, not a
            // thread block) so a brand-new note's just-assigned id is
            // picked up here instead of this instance also treating it as
            // unsaved and inserting a duplicate row on its own next
            // autosave. Also covers the ordinary case of resuming an
            // existing note faster than its pause-triggered re-save
            // finished: either way `note` ends up holding the freshest
            // known copy before the reload below runs.
            // A Saved outcome means the previous instance's onPause snapshot
            // is now the source of truth, so it's adopted here. Any other
            // outcome (the note was deleted elsewhere, an unresolved
            // conflict, or the await itself failing) leaves `note` as-is
            // rather than adopting a note that was never actually written -
            // the reload just below will then find nothing to load for a
            // deleted note, same as if it had never been retained at all.
            if (retainedSave != null) {
                val outcome = runCatching { retainedSave.await() }.getOrNull()
                if (outcome is SaveOrDeleteOutcome.Saved) note = outcome.note
            }
            val idToLoad = if (note.id != 0L) note.id else noteId
            if (idToLoad != 0L) {
                repository.getById(idToLoad)?.let {
                    note = it
                    binding.editTitle.setText(it.title)
                    binding.editContent.setText(it.content)
                    undoRedo.reset()
                    applyEffectiveStyle()
                    restoreCursorSelection(savedInstanceState)
                    updateWordCount()
                }
            }
        }

        binding.buttonDelete.setOnClickListener {
            // Unlike the main list, this screen has no undo snackbar, so a
            // single stray tap on a note with real content was permanent.
            // An empty note has nothing to lose, so it skips the prompt.
            val hasContent = binding.editTitle.text?.isNotBlank() == true ||
                binding.editContent.text?.isNotBlank() == true
            if (!hasContent) {
                deleteNoteAndFinish()
                return@setOnClickListener
            }
            MaterialAlertDialogBuilder(this)
                .setTitle(R.string.delete_note_title)
                .setMessage(R.string.delete_note_message)
                .setPositiveButton(R.string.delete) { _, _ -> deleteNoteAndFinish() }
                .setNegativeButton(android.R.string.cancel, null)
                .show()
        }

        binding.buttonPopOut.setOnClickListener {
            if (!OverlayPermission.isGranted(this)) {
                OverlayPermission.request(this, binding.root)
                return@setOnClickListener
            }
            lifecycleScope.launch {
                saveDebouncer.cancel()
                persist()
                val serviceIntent = Intent(this@NoteEditorActivity, FloatingNoteService::class.java)
                    .setAction(FloatingNoteService.ACTION_SHOW_NOTE)
                    .putExtra(FloatingNoteService.EXTRA_NOTE_ID, note.id)
                ContextCompat.startForegroundService(this@NoteEditorActivity, serviceIntent)
                finish()
            }
        }
    }

    private fun deleteNoteAndFinish() {
        isDeleting = true
        saveDebouncer.cancel()
        lifecycleScope.launch {
            if (note.id != 0L) repository.delete(note.id)
            finish()
        }
    }

    // Hands `pendingSave` (if any) to the Activity instance that's about to
    // replace this one across a configuration change, entirely in memory -
    // no Bundle/parcelling involved, which matters here since a Deferred
    // can't be parcelled at all. This API is deprecated in favor of
    // ViewModel-retained state, but remains fully supported; using it here
    // keeps this fix localized to the one piece of state that actually
    // needs to survive recreation, rather than introducing a new
    // ViewModel-based architecture for the rest of this screen.
    @Suppress("DEPRECATION")
    override fun onRetainCustomNonConfigurationInstance(): Any? = pendingSave

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putLong(STATE_NOTE_ID, note.id)
        outState.putInt(STATE_CURSOR_START, binding.editContent.selectionStart)
        outState.putInt(STATE_CURSOR_END, binding.editContent.selectionEnd)
    }

    private fun restoreCursorSelection(savedInstanceState: Bundle?) {
        if (savedInstanceState == null) return
        val start = savedInstanceState.getInt(STATE_CURSOR_START, -1)
        val end = savedInstanceState.getInt(STATE_CURSOR_END, -1)
        val length = binding.editContent.text?.length ?: 0
        if (start in 0..length && end in 0..length) {
            binding.editContent.setSelection(start, end)
        }
    }

    private fun applyInsets() {
        binding.toolbar.applyTopSystemBarPadding()
        binding.bottomBar.applyBottomSystemBarPadding()
        binding.editorRoot.applyImeBottomPadding()
    }

    private fun updateWordCount() {
        binding.textCount.text = formatWordAndCharCount(this, binding.editContent.text ?: "")
    }

    /** This note's own style if it has an override, otherwise the app-wide
     *  one from Settings - see PaperStyles.effective. */
    private fun applyEffectiveStyle() {
        val style = PaperStyles.effective(this, note.styleIndex)
        val color = ContextCompat.getColor(this, style.coverColor)
        binding.spineAccent.setAccent(color, 0f, CornerAccentBar.RoundedCorners.PILL)
        binding.editContent.pattern = style.pattern
    }

    private fun showStylePicker() {
        showNoteStylePicker(binding.spineAccent, note.styleIndex) { picked ->
            note = note.copy(styleIndex = picked)
            applyEffectiveStyle()
            scheduleAutoSave()
        }
    }

    override fun onResume() {
        super.onResume()
        applyEffectiveStyle()
        applyContentTextSize(binding.editContent, this)
        // Guards the same two-editors-one-note conflict as MainActivity.openNote,
        // just from the other direction: if this note became a floating window
        // while this screen was backgrounded (e.g. a stale multi-window/recents
        // instance), defer to that window instead of resuming a second,
        // uncoordinated editor for it.
        if (FloatingNoteService.isNoteFloating(note.id)) {
            finish()
        }
        // Handles rapid pause/resume (no destroy in between, so the
        // onRetainCustomNonConfigurationInstance hand-off never comes into
        // play): adopt onPause's save result once it lands, so if the user
        // resumes and starts typing again before it finishes, the next
        // autosave uses the correct, up-to-date id/version instead of
        // racing it.
        pendingSave?.let { deferred ->
            lifecycleScope.launch {
                runCatching { deferred.await() }.onSuccess { outcome ->
                    if (outcome is SaveOrDeleteOutcome.Saved) note = outcome.note
                }
            }
        }
        pendingSave = null
    }

    private fun scheduleAutoSave() {
        saveDebouncer.schedule { persist() }
    }

    override fun onPause() {
        super.onPause()
        saveDebouncer.cancel()
        if (isDeleting) return
        // Captures the on-screen text synchronously (fast: just reading two
        // EditTexts on the main thread, no I/O) and hands the actual write
        // off to NoteRepository's durable scope, which outlives this
        // Activity - see NoteRepository.saveOrDeleteIfEmptyDurable. This
        // used to be `runBlocking { persist() }`, which blocked the main
        // thread for every single pause (including brief ones, like a
        // permission dialog appearing) to get the same "definitely saved,
        // definitely has an id before onSaveInstanceState runs" guarantee
        // synchronously. That guarantee now comes from `pendingSave` being
        // retained across a configuration change and awaited (non-blocking)
        // by whichever instance needs it next - see onCreate() and
        // onResume() above.
        val snapshot = note.copy(
            title = binding.editTitle.text.toString(),
            content = binding.editContent.text.toString()
        )
        pendingSave = repository.saveOrDeleteIfEmptyDurable(snapshot)
    }

    private suspend fun persist() {
        val title = binding.editTitle.text.toString()
        val content = binding.editContent.text.toString()
        // Only a Saved outcome updates `note` - if the row was deleted
        // elsewhere or a conflict never resolved, nothing was written, so
        // `note` (id/version) is left as-is rather than adopting a note
        // that doesn't actually exist in the DB. The on-screen text is
        // untouched either way; the next autosave will simply try again.
        val outcome = repository.saveOrDeleteIfEmpty(note.copy(title = title, content = content))
        if (outcome is SaveOrDeleteOutcome.Saved) note = outcome.note
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_note_editor, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_share -> shareNote()
            R.id.action_export -> exportLauncher.launch(suggestedExportFileName())
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }

    private fun noteAsPlainText(): String {
        val title = binding.editTitle.text?.toString().orEmpty()
        val content = binding.editContent.text?.toString().orEmpty()
        return if (title.isNotBlank()) "$title\n\n$content" else content
    }

    private fun shareNote() {
        val title = binding.editTitle.text?.toString().orEmpty()
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, noteAsPlainText())
            if (title.isNotBlank()) putExtra(Intent.EXTRA_SUBJECT, title)
        }
        startActivity(Intent.createChooser(intent, getString(R.string.share_note)))
    }

    /** Registered here, in onCreate-reachable field-init time rather than
     *  lazily inside the click handler, because ActivityResultLauncher
     *  requires registration before the Activity reaches STARTED - doing it
     *  any later throws. */
    private val exportLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        uri?.let { exportNoteToUri(it) }
    }

    private fun exportNoteToUri(uri: Uri) {
        val text = noteAsPlainText()
        lifecycleScope.launch {
            val success = withContext(Dispatchers.IO) {
                runCatching {
                    contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray()) }
                        ?: error("contentResolver returned no output stream for $uri")
                }.isSuccess
            }
            Toast.makeText(
                this@NoteEditorActivity,
                if (success) R.string.export_success else R.string.export_failed,
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun suggestedExportFileName(): String {
        val title = binding.editTitle.text?.toString().orEmpty().trim()
        val safe = title.replace(Regex("[\\\\/:*?\"<>|]"), " ").trim().take(64)
        return "${safe.ifBlank { getString(R.string.untitled_note) }}.txt"
    }

    companion object {
        const val EXTRA_NOTE_ID = "extra_note_id"
        private const val STATE_NOTE_ID = "state_note_id"
        private const val STATE_CURSOR_START = "state_cursor_start"
        private const val STATE_CURSOR_END = "state_cursor_end"
    }
}
