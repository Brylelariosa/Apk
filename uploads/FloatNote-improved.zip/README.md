# FloatNote

A lightweight Kotlin notes app for Android. Notes can open full-screen, or pop
out as a floating window (drag, resize, minimize to a bubble) that stays on
top of any other app - similar to Messenger's chat heads, but for notes.
Multiple notes can float at once.

## Features
- Notes list: 2-column staggered grid, pin, search, swipe-to-delete with undo
- **Settings screen** (toolbar overflow menu): pick the one app-wide note style, and whether minimizing a floating note collapses to a bubble or a notification
- "Floating mode" toggle (icon in the toolbar - tinted when on) controls whether tapping a note opens it full-screen or floating
- Long-press a note to start selecting (pin / unpin / delete in bulk from the action bar); back closes an open search field first
- Floating windows: drag the header to move, drag the corner to resize, tap the bubble to expand, tap minimize to collapse per the Settings choice above
- Auto-saves as you type (debounced ~600ms) and again on close, so nothing is lost
- Material 3, dark mode, edge-to-edge, splash screen

## Size optimizations applied
- No Room / Retrofit / Glide - a hand-rolled `SQLiteOpenHelper` keeps the dependency graph (and APK) minimal, and avoids KSP/annotation-processor overhead in CI
- `isMinifyEnabled` + `isShrinkResources` on **both** debug and release build types (R8, full mode) - your workflow builds `assembleDebug` whenever `KEYSTORE_BASE64` isn't set, so debug stays small too. If you'd rather keep debug builds unobfuscated for easier debugging, just delete the `debug { }` override block in `app/build.gradle.kts` (release stays optimized either way)
- Vector drawables for every UI icon. The only raster assets are the three adaptive-launcher-icon PNGs in `drawable-nodpi` (background, foreground, monochrome - about 285 KB together)
- `resourceConfigurations += listOf("en")` strips translated strings AndroidX/Material otherwise ship for every locale
- `buildConfig = false`, unused `META-INF/*` license/notice files excluded from packaging
- Every dependency in `app/build.gradle.kts` is actually used in code (no ConstraintLayout or other unused libraries)
- Crash logs stay readable even though the app is minified: `-keepattributes SourceFile,LineNumberTable` in `proguard-rules.pro` keeps file/line info while still shrinking and renaming everything else

## Versions used
JDK 17, AGP 8.13.0, Gradle 8.13, Kotlin 1.9.24, compileSdk/targetSdk 36 (Android 16), minSdk 26 (Android 8.0+).

Your workflow's "Setup Gradle" step and "Fetch gradle-wrapper.jar" step are both
pinned to Gradle **8.6**, but this project's `gradle-wrapper.properties` points
at Gradle **8.13** (needed for compileSdk 36 support via AGP 8.13). This still
works out of the box - `gradlew` downloads whatever `distributionUrl` its own
properties file says regardless of what the setup-gradle action pre-cached,
and a gradle-wrapper.jar from 8.6 can bootstrap a newer distribution fine.
For a slightly faster first CI run (so the pre-cache actually gets used),
you can optionally bump the two `"8.6"` strings in your workflow to `"8.13"`.

If anything about that version jump ever gives you trouble, the safe fallback
is: AGP `8.4.1`, Gradle `8.6` (matches your workflow exactly), compileSdk/targetSdk `34`.

## Building
Drop `FloatNote.zip` in the `uploads/` folder of your CI repo (or push it with
your ZipApkBuilder app) - your existing Build APK workflow picks it up
automatically, no other changes needed.

## Notes
- The first time "Floating mode" is used, Android will prompt for the
  "display over other apps" permission (required for the overlay windows) and,
  on Android 13+, notification permission (for the small persistent "FloatNote
  is active" notification foreground services require, and now also needed
  if Settings' minimize mode is set to "Notification"). `MainActivity`
  requests it up front on every floating-mode entry point, not just the
  first one, so it's covered either way.
- Notes no longer use a plain color picker, and style is no longer a
  per-note choice living on the editor screen (it used to tint the whole
  editor background, which read as a lot of color for a note-taking app).
  There's now a single app-wide **paper style** (`util/PaperStyle.kt`) - a
  cover color paired with a writing-surface pattern (ruled, grid, dot-grid,
  or blank), drawn by the custom `PatternedEditText` view - picked once in
  the new Settings screen (`SettingsActivity`, stored via
  `PrefsManager.getGlobalStyleIndex`/`setGlobalStyleIndex`) and applied
  everywhere: the list card's spine accent, the editor's spine accent, and
  the floating card's header. The full-screen color tint is gone; the editor
  background is just the normal surface color, with color showing only as a
  thin spine strip on the card (same idea as the list). Six presets ship by
  default (Orange Book, Indigo Ruled, Forest Grid, Charcoal Dot, Kraft Blank,
  Rose Ruled) - add more by appending to `PaperStyles.all`. `Note.styleIndex`
  is still in the DB schema for compatibility but is no longer read for
  rendering.
- **Minimize mode**: also in Settings, choose whether tapping minimize on a
  floating note collapses it to a small draggable bubble or to a regular
  status-bar notification instead (`PrefsManager.getMinimizeMode`/
  `setMinimizeMode`, `MinimizeMode.BUBBLE` / `NOTIFICATION`). Tapping the
  notification re-expands the card; swiping it away closes the note
  (auto-saved), same as closing a bubble. Each minimized-to-notification
  window gets a stable notification ID independent of `note.id` (via an
  `AtomicInteger` counter in `FloatingNoteService`), since a brand new
  unsaved note is still `id == 0L`.
- **Customizable floating bubble**: also in Settings, a "Floating bubble"
  section with a live preview and two sliders - visible size (24-64dp,
  default 36dp) and transparency (20-100% opacity, default 100%) - backed by
  `PrefsManager.getBubbleSizeDp`/`setBubbleSizeDp` and
  `getBubbleOpacityPercent`/`setBubbleOpacityPercent`. `util/BubbleAppearance.kt`
  is the single place both the real bubble and the Settings preview go
  through to render a given size/opacity (`applyBubbleVisuals`), so the two
  can never quietly drift apart from each other. The bubble's *window* (the
  actual draggable/tappable touch target) is always kept at or above
  Android's ~48dp touch-target guidance regardless of how small the visible
  bubble itself is set (`bubbleWindowSizePx`) - opacity only fades the
  visible icon, never below 20%, since a bubble faded to fully invisible
  would still sit there tappable, just impossible to find again. Like the
  app's other global settings, a change here takes effect the next time a
  note is minimized to a bubble, not on one already showing.
- Floating windows are inflated with an explicitly-themed `LayoutInflater`
  (`ContextThemeWrapper` around `Theme.FloatNote`) rather than the Service's
  raw context. A bare Service context doesn't reliably resolve Material3/
  AppCompat theme attributes, which crashed inflation of the AppCompat-based
  views once floating notes got custom widgets. `showCard()`/`collapseToBubble()`
  wrap their entire bodies in try/catch as a second safety net.
- **Undo/redo** (`util/UndoRedoManager.kt`) is debounced - a pause in typing
  (~700ms) creates one undo step, so it doesn't take 40 taps to undo a
  sentence. Wired into the content field in both the full editor and the
  floating card, each with its own independent history.
- **Insert numbered list**: type a range directly on the current line - e.g.
  `1/45` or `1/45gap` (an optional trailing `gap` adds a blank line between
  each entry) - then tap the "123" icon (editor's bottom bar, or the
  floating card's overflow menu) to expand that token in place into
  `1.`...`45.`. Capped at 1000 numbers so a typo like `1/99999999` can't
  freeze the editor. Available in both the editor and the floating card -
  no dialog involved, so there was no extra overlay-window risk to weigh for
  the floating card either.
- **Deleting from the editor** asks for confirmation when the note has any text (the main list has an undo snackbar; the editor doesn't, so a stray tap was permanent). Once deleted, the editor's `onPause` no longer re-saves the note on its way out - previously a brand-new note that hadn't autosaved yet could be re-inserted by that final save.
- **Notification permission (Android 13+)** is now requested *before* the floating note opens, and the note opens from the permission result. Previously the service started and `moveTaskToBack` ran immediately, which could push the system dialog to the background before it was answered. The overlay permission is checked first, so only one permission flow is ever on screen at a time.
- The floating card's resize handle (bottom-right corner) went from a 24dp to
  a 40dp touch target - the old one was below Android's recommended minimum
  and was likely hard to actually grab.

## Motion and navigation
- **Shared motion helpers** live in `util/Animations.kt` (`popIn`, `popOut`, `fadeTo`, `animateAlphaTo`, plus `ANIM_FAST_MS`/`ANIM_MEDIUM_MS`), so speed and feel are tuned in one place instead of per call site.
- **Screen transitions** (list <-> editor <-> settings) are set once through `Animation.FloatNote.Activity` in `themes.xml` (both day and night themes) - a short fade plus slight horizontal slide, mirrored on back. No per-call `overridePendingTransition`.
- **List**: cards cascade in the first time the list has content (`res/anim/layout_fall_down.xml`, not replayed on later refreshes); the empty state fades; the extended FAB collapses to its icon while scrolling down and expands on scroll up / at the top, and hides during selection mode; selected cards sit slightly pressed-in.
- **Navigation**: floating-mode toggle is a visible toolbar icon (a Toast confirms the change - not a Snackbar, which would replace a pending delete "Undo"); long-press starts selection with that note selected (pin/unpin is in the selection action bar - long-press no longer pins directly); back collapses search before leaving.
- **Editor**: a new note opens with the cursor in the body and the keyboard up (first creation only, not after rotation); the title field's keyboard action jumps to the body; undo/redo dimming eases instead of snapping.
- **Settings**: picking a paper style animates the swatch selection in place instead of rebuilding the row.
- **Floating windows**: the card pops in (open, expand from bubble/notification, switch note) and fades out on minimize/close; the bubble pops in with a small overshoot and shrinks slightly under the finger. The minimize/close action still does the real teardown - the fade is cosmetic and is skipped safely if the window is destroyed mid-fade (`isTransitioning` guards against a double-tap creating two bubbles). The bubble's icon alpha (the opacity setting) is never touched by these animations.
