package com.example.eggchase.engine

import android.opengl.GLES20

/**
 * Minimal per-vertex-lit shader: one fixed directional light, a single
 * uniform color per draw call. Enough to make low-poly shapes read as
 * solid 3D objects without the cost of a real lighting system.
 */
class ColorShader {
    private val program: Int = GLES20.glCreateProgram().also { prog ->
        val vertexShader = compile(GLES20.GL_VERTEX_SHADER, VERTEX_SRC)
        val fragmentShader = compile(GLES20.GL_FRAGMENT_SHADER, FRAGMENT_SRC)
        GLES20.glAttachShader(prog, vertexShader)
        GLES20.glAttachShader(prog, fragmentShader)
        GLES20.glLinkProgram(prog)
    }

    val positionHandle: Int = GLES20.glGetAttribLocation(program, "aPosition")
    val normalHandle: Int = GLES20.glGetAttribLocation(program, "aNormal")
    private val mvpHandle = GLES20.glGetUniformLocation(program, "uMVPMatrix")
    private val modelHandle = GLES20.glGetUniformLocation(program, "uModelMatrix")
    private val colorHandle = GLES20.glGetUniformLocation(program, "uColor")

    fun use() = GLES20.glUseProgram(program)

    fun setMatrices(mvpMatrix: FloatArray, modelMatrix: FloatArray) {
        GLES20.glUniformMatrix4fv(mvpHandle, 1, false, mvpMatrix, 0)
        GLES20.glUniformMatrix4fv(modelHandle, 1, false, modelMatrix, 0)
    }

    fun setColor(r: Float, g: Float, b: Float, a: Float) {
        GLES20.glUniform4f(colorHandle, r, g, b, a)
    }

    private fun compile(type: Int, source: String): Int {
        val shader = GLES20.glCreateShader(type)
        GLES20.glShaderSource(shader, source)
        GLES20.glCompileShader(shader)
        return shader
    }

    private companion object {
        const val VERTEX_SRC = """
            uniform mat4 uMVPMatrix;
            uniform mat4 uModelMatrix;
            attribute vec4 aPosition;
            attribute vec3 aNormal;
            varying vec3 vNormal;
            void main() {
                gl_Position = uMVPMatrix * aPosition;
                vNormal = normalize((uModelMatrix * vec4(aNormal, 0.0)).xyz);
            }
        """

        const val FRAGMENT_SRC = """
            precision mediump float;
            uniform vec4 uColor;
            varying vec3 vNormal;
            void main() {
                vec3 lightDir = normalize(vec3(0.5, 1.0, 0.3));
                float diff = max(dot(vNormal, lightDir), 0.0);
                float intensity = 0.45 + diff * 0.55;
                gl_FragColor = vec4(uColor.rgb * intensity, uColor.a);
            }
        """
    }
}
