package com.mangatool.app

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mangatool.app.util.BitmapUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AllPhotosActivity : AppCompatActivity() {

    sealed class GalleryItem {
        data class Header(val title: String, val count: Int) : GalleryItem()
        data class Photo(
            val groupIdx: Int,
            val imageIdx: Int,
            val groupName: String,
            val isMerge: Boolean,
            val sizeKb: Int
        ) : GalleryItem()
    }

    companion object {
        private const val COLS = 4
    }

    private lateinit var recycler: RecyclerView
    private lateinit var titleView: TextView
    private lateinit var countView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_all_photos)

        recycler  = findViewById(R.id.all_photos_grid)
        titleView = findViewById(R.id.all_photos_title)
        countView = findViewById(R.id.all_photos_count)

        findViewById<View>(R.id.btn_back).setOnClickListener { finish() }

        buildGallery()
    }

    private fun buildGallery() {
        val isMerge = AppState.currentMode == AppMode.MERGE
        val items = mutableListOf<GalleryItem>()

        AppState.groups.forEachIndexed { gIdx, group ->
            val images = group.displayImages
            if (images.isNotEmpty()) {
                items.add(GalleryItem.Header(group.groupName, images.size))
                images.forEachIndexed { iIdx, img ->
                    items.add(GalleryItem.Photo(
                        groupIdx  = gIdx,
                        imageIdx  = iIdx,
                        groupName = group.groupName,
                        isMerge   = isMerge,
                        sizeKb    = img.size / 1024
                    ))
                }
            }
        }

        val totalPhotos = items.filterIsInstance<GalleryItem.Photo>().size
        titleView.text = "All Photos"
        countView.text = "$totalPhotos images"

        val spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int) =
                if (items[position] is GalleryItem.Header) COLS else 1
        }

        val lm = GridLayoutManager(this, COLS).apply { this.spanSizeLookup = spanSizeLookup }
        recycler.layoutManager = lm
        recycler.adapter = GalleryAdapter(items)
    }

    // ── Adapter ────────────────────────────────────────────────────────────────
    inner class GalleryAdapter(
        private val items: List<GalleryItem>
    ) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

        private val TYPE_HEADER = 0
        private val TYPE_PHOTO  = 1

        override fun getItemViewType(position: Int) =
            if (items[position] is GalleryItem.Header) TYPE_HEADER else TYPE_PHOTO

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            val inflater = LayoutInflater.from(parent.context)
            return if (viewType == TYPE_HEADER) {
                HeaderVH(inflater.inflate(R.layout.item_gallery_header, parent, false))
            } else {
                PhotoVH(inflater.inflate(R.layout.item_gallery_photo, parent, false))
            }
        }

        override fun getItemCount() = items.size

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
            when (val item = items[position]) {
                is GalleryItem.Header -> (holder as HeaderVH).bind(item)
                is GalleryItem.Photo  -> (holder as PhotoVH).bind(item)
            }
        }

        override fun onViewRecycled(holder: RecyclerView.ViewHolder) {
            if (holder is PhotoVH) holder.loadJob?.cancel()
            super.onViewRecycled(holder)
        }

        inner class HeaderVH(v: View) : RecyclerView.ViewHolder(v) {
            private val title: TextView = v.findViewById(R.id.gallery_header_title)
            private val count: TextView = v.findViewById(R.id.gallery_header_count)
            fun bind(h: GalleryItem.Header) {
                title.text = h.title
                count.text = "${h.count} images"
            }
        }

        inner class PhotoVH(v: View) : RecyclerView.ViewHolder(v) {
            val img:  ImageView = v.findViewById(R.id.gallery_photo_image)
            val num:  TextView  = v.findViewById(R.id.gallery_photo_num)
            val size: TextView  = v.findViewById(R.id.gallery_photo_size)
            var loadJob: Job?   = null

            fun bind(photo: GalleryItem.Photo) {
                val group   = AppState.groups.getOrNull(photo.groupIdx) ?: return
                val imgItem = group.displayImages.getOrNull(photo.imageIdx) ?: return

                num.text  = "${photo.imageIdx + 1}"
                size.text = "${photo.sizeKb}KB"
                img.setImageBitmap(null)
                loadJob?.cancel()

                val cacheKey = "gallery_${photo.groupIdx}_${photo.imageIdx}"
                val cached = AppState.thumbCache.get(cacheKey)
                if (cached != null) {
                    img.setImageBitmap(cached)
                } else {
                    // Use lifecycleScope so loads are cancelled when the Activity is destroyed
                    loadJob = lifecycleScope.launch {
                        val bmp = withContext(Dispatchers.IO) {
                            BitmapUtils.decodeThumbnail(imgItem.filePath, 256)
                        }
                        if (bmp != null) {
                            AppState.thumbCache.put(cacheKey, bmp)
                            img.setImageBitmap(bmp)
                        }
                    }
                }

                itemView.setOnClickListener {
                    val intent = Intent(this@AllPhotosActivity, ImagePreviewActivity::class.java).apply {
                        putExtra(ImagePreviewActivity.EXTRA_GROUP_IDX, photo.groupIdx)
                        putExtra(ImagePreviewActivity.EXTRA_IMAGE_IDX, photo.imageIdx)
                        putExtra(ImagePreviewActivity.EXTRA_IS_MERGE, photo.isMerge)
                    }
                    startActivity(intent)
                }
            }
        }
    }
}
