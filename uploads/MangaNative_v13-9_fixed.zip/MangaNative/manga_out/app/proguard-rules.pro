# ── Readable crash logs ────────────────────────────────────────────────────────
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
-keepattributes *Annotation*

# ── Activities, Services, BroadcastReceivers, ContentProviders ────────────────
# R8 reads AndroidManifest.xml and keeps these automatically, but being
# explicit here costs nothing and prevents accidental removal.
-keep public class com.mangatool.app.MainActivity
-keep public class com.mangatool.app.ImagePreviewActivity
-keep public class com.mangatool.app.AllPhotosActivity
-keep public class com.mangatool.app.MergeImagePickerActivity

# ── Data model classes ────────────────────────────────────────────────────────
# Keep the Kotlin data class generated members (.copy(), .componentN(), etc.)
# that are called from our own code.  R8 full mode can remove these if it
# decides they're unused — being explicit avoids any risk.
-keepclassmembers class com.mangatool.app.model.ImageItem {
    public synthetic ** component*();
    public ** copy(...);
}
-keepclassmembers class com.mangatool.app.model.ImageGroup {
    public synthetic ** component*();
    public ** copy(...);
}

# ── Enum safety ───────────────────────────────────────────────────────────────
-keepclassmembers enum com.mangatool.app.AppMode { *; }

# ── Kotlin & coroutines ───────────────────────────────────────────────────────
-dontwarn kotlin.**
-dontwarn kotlinx.coroutines.**

# ── ViewBinding ───────────────────────────────────────────────────────────────
# AGP generates keep rules for ViewBinding automatically — no extra rules needed.

# ── Material / AndroidX ───────────────────────────────────────────────────────
-dontwarn com.google.android.material.**
-dontwarn androidx.**

