# Known Limitations

No compiler, Android SDK, or physical device is available in this
sandbox for any pass of this project. Every fix is checked by hand-
tracing against documented Android/Kotlin/Compose API behavior, XML
validation, and static balance/reference checks - real, but not a
substitute for an actual build and a real WiFi Direct exchange between
two phones. This file is where that gap is spelled out per-topic,
rather than left as a blanket disclaimer.

## WiFi Direct

- **`thisDevice` (own QR code) on API 26-28.** The fix in BUGS_FIXED.md
  #2 adds an active `requestDeviceInfo()` query, but that API only
  exists from API 29 onward. On API 26-28 specifically, populating the
  Receive screen's QR code still depends entirely on
  `WIFI_P2P_THIS_DEVICE_CHANGED_ACTION` firing, which is the same
  broadcast-only behavior that caused the original bug. Given how rare
  Android 8.0/8.1 devices are at this point, this is an accepted gap
  rather than one worth more code to close - but it's a real, known one,
  not silently assumed fixed everywhere.
- **"WiFi Direct is busy" after a QR scan - now traced to a specific cause.**
  1.0.4's fix addressed `BUSY` generically (retry handling plus a same-call
  redundant-discovery guard) without a confirmed trigger for this exact
  report. The 1.0.5 pass found and closed a concrete one instead: returning
  from the QR scanner recomposes `DiscoverDevicesScreen` from scratch, which
  re-fires its "start discovery" effect at the same instant as its "connect
  to scanned payload" effect - see BUGS_FIXED.md 1.0.5 #1 for the full
  trace. Confidence is meaningfully higher this time (an actual colliding
  pair of commands was identified, not just defended against generically),
  but the standing caveat still applies: hand-traced, not watched on two
  real phones. If "busy" *still* appears after 1.0.5, that means a third,
  different trigger - at that point a logcat capture around the moment it
  happens (`WifiP2pManager`/`WifiP2pService` tags) is worth more than a
  third read-through, since two read-through-driven passes at the same
  message is a sign the remaining cause isn't visible from source alone.
- **Two-device testing.** Every fix in this project so far has been
  checked against one device's code path at a time - the actual
  session handshake, offer/accept, and file streaming between two real
  paired phones has never been observed running. The protocol design
  (see `TransferProtocol.kt`'s own doc comment) is reasoned through
  carefully, but "reasoned through" and "watched two phones actually do
  it" are different confidence levels, worth being honest about.

## Size optimization

- **ML Kit barcode scanning: bundled, not switched to Play-Services-
  unbundled.** `com.google.mlkit:barcode-scanning` ships its model
  inside the APK; a Play-Services-backed unbundled variant
  (`com.google.android.gms:play-services-mlkit-barcode-scanning`) would
  likely cut a further meaningful chunk of size by downloading that
  model on first use instead. Deliberately not switched this pass: it's
  designed to be close to a drop-in API replacement, but "close to" is
  doing real work in that sentence without a compiler here to confirm
  it, it adds a hard Google-Play-Services dependency (a real constraint
  on some device forks) and a network requirement before the *first*
  scan specifically, and this project has already had two build-log-
  driven fix cycles in a row - better to bank the confirmed,
  zero-behavior-change icon-library win this pass than risk a third
  cycle chasing a second, less certain one. Worth revisiting if more
  size reduction is needed and a real build is available to confirm the
  swap compiles and scans correctly before shipping it.
- **Native-library ABI filtering: available, not applied.** ML Kit's
  bundled model is the one dependency here shipping actual native
  (`.so`) code, for all four Android ABIs (arm64-v8a, armeabi-v7a, x86,
  x86_64) inside the single universal APK, since this project
  deliberately isn't using Gradle's ABI-split output (multiple APKs,
  one per architecture). A *single* universal APK can still restrict
  which ABIs it packages via `ndk.abiFilters` in `build.gradle.kts` -
  e.g. dropping `x86`/`x86_64` (real Android phones are effectively all
  arm64-v8a today; those two exist mainly for emulators) would shrink
  that native payload without producing multiple APK files or touching
  any feature. Not applied this pass since it sits close enough to "ABI
  split" in spirit that it seemed better to surface as a choice than
  fold in silently. Applied instead: resource locale filtering
  (`resourceConfigurations` in `defaultConfig`, restricted to `"en"`),
  which drops other-locale string resources bundled by AndroidX/
  Compose/CameraX/ML Kit - safe regardless of whether ABI filtering
  gets taken later, since this app has no translations of its own to
  lose either way.
- **The hand-authored vector icons are not pixel-identical to Google's
  Material Symbols glyphs** they replace - they're clean, simple
  geometric reconstructions of the same concept (an arrow is an arrow,
  a folder is a folder), not a byte-for-byte copy of the original path
  data. Worth a glance once a device/emulator is available, since a
  vector path rendering slightly differently than intended is a
  cosmetic risk this sandbox's XML-validity checks can't catch - the
  icons are syntactically valid and geometrically reasoned through, but
  never actually rendered.

## Foreground service / notification lifecycle

- **`onTaskRemoved()` relies on stock Android behavior.** The 1.0.5 fix
  for the persistent notification is standard, documented `Service`
  API with no OEM-specific assumptions - but several Android OEM skins
  are known to layer extra, non-standard battery-optimization behavior
  around backgrounded or task-removed services on top of stock
  behavior. Nothing about that can be verified from source alone. If
  the notification is ever still seen after 1.0.5, specifically on a
  heavily-customized OEM ROM, that's worth suspecting before another
  read of this code.
- **Dispose-time service stop assumes plain back-stack disposal.** The
  new checks in `DiscoverDevicesScreen`/`ReceiveScreen` stop the
  service when the screen leaves composition without a session having
  reached `Connected` - correct for this project's plain
  `NavHost`/`composable()` usage (no custom enter/exit transitions
  configured, which is what's actually in this codebase today). Worth
  re-checking if animated destination transitions are ever added later,
  since some approaches to those deliberately keep the outgoing
  composable alive slightly longer than instant disposal.
