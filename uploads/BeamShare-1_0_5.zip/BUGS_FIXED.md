# BUGS_FIXED

**No compiler or device is available in this sandbox, for any pass.** Every fix
below was verified by hand-tracing the exact code path against Android's
documented API behavior, and by static checks (brace/paren balance, grep for
orphaned references, XML validation) - not by an actual build or a real WiFi
Direct exchange. Said plainly per fix, not just here, since fixes across
passes carry different levels of confidence.

---

## 1.0.5

Two bugs reported directly, both regressions on top of behavior 1.0.4 had
already touched: "WiFi Direct is busy" still appearing specifically after a
QR scan (1.0.4 addressed BUSY generically but not this exact trigger), and
the "session active" notification outliving the app being closed.

### 1. "WiFi Direct is busy" still appears after scanning a QR code

**Category:** Bug fix (root cause)
**Files modified:** `DiscoverDevicesScreen.kt`, `WifiDirectManager.kt`
**Problem:** The 1.0.4 pass added BUSY retry handling and a same-call
redundant-discovery guard, but this report's actual trigger was different and
more specific. Returning from the QR scanner (`navController.popBackStack()`)
recreates `DiscoverDevicesScreen`'s composition from scratch, since plain
`remember` state doesn't survive a composable leaving and re-entering
composition. That means `hasPermission` re-initializes to `true` (permission
was already granted) and `qrPayloadToConnect` is simultaneously non-null - so
`LaunchedEffect(hasPermission)` (calls `startDiscovery()`) and
`LaunchedEffect(qrPayloadToConnect)` (calls `connectToQrPayload()`, itself
`stopDiscovery()` + `connectToAddress()`) both fire in the same recomposition.
Three P2P commands (`discoverPeers`, `stopPeerDiscovery`, `connect`) landed on
`WifiP2pManager` back-to-back, before the first one's callback could return -
which is exactly what BUSY means ("still processing your last command").
Worse, `startDiscovery()` and `connectToAddress()` both retry on BUSY using
the *same* 1.2s delay, started at the *same* instant, so their retries kept
landing in the same window and re-colliding - explaining why it kept
happening instead of resolving after one retry.
**Solution:** One change per layer. `DiscoverDevicesScreen` now skips
re-arming discovery in that effect when a QR payload is already queued to
connect to - no reason to start general discovery right as a specific connect
is about to happen. As defense in depth for any other call path,
`WifiDirectManager` now funnels every `discoverPeers`/`stopPeerDiscovery`/
`connect`/`removeGroup` call through a single in-flight gate, so a second
command issued while one is still awaiting its callback is queued instead of
dispatched concurrently.
**Reason:** Direct report ("i scan qr code but still say wifi direct is
busy") - the same user-facing message 1.0.4 addressed, from a different,
previously-untraced trigger.
**Expected improvement:** Connecting via QR should no longer produce BUSY
under normal conditions - the redundant discovery call this path used to
issue is gone, and even a future path that races two commands now queues
instead of colliding.
**Side effects:** None to the happy path. A command issued while another is
still in flight now waits for that command's callback (typically well under
a second) instead of firing immediately.
**Verification:** No compiler/device. Traced end to end from
`QrScannerScreen`'s result callback through `BeamNavHost` to
`DiscoverDevicesScreen`'s effects to `DiscoverViewModel` to
`WifiDirectManager` - two effects racing on screen re-entry is a genuine,
reproducible-on-paper gap. Stronger confidence than 1.0.4's fix for this same
message, since it identifies the actual colliding commands rather than
defending against BUSY generically - but per this project's standing caveat,
"reasoned through by reading every line" and "watched it happen on two real
phones" remain different confidence levels.

### 2. "BeamShare session active" notification stays after closing the app

**Category:** Bug fix (root cause)
**Files modified:** `BeamShareService.kt`, `DiscoverDevicesScreen.kt`,
`ReceiveScreen.kt`
**Problem:** `BeamShareService.start()` fires as soon as the Discover or
Receive screen opens, to prepare for a session before one exists. The service
only ever stops itself in response to `SessionState.Disconnected` - but
`Disconnected` is a "was connected, now isn't" state; a session that never
connected in the first place stays at `SessionState.None` forever, which
`observeSession()` doesn't treat as a stop signal. Nothing else in the app
called `BeamShareService.stop()`, and there was no `onTaskRemoved()`
override. So: open Discover or Receive, don't connect, close the app - the
foreground service (and its notification) has no path to ever stop.
**Solution:** Two changes. `BeamShareService` now overrides `onTaskRemoved()`
to call `SessionManager.disconnect()` when the app is removed from Recents -
`disconnect()` already flips `sessionState` to `Disconnected` unconditionally
(safe to call from `None`; it no-ops cleanly on a session that never formed),
and the existing `observeSession()` already stops the service on that
transition, so this reuses that path instead of duplicating it. Separately,
`DiscoverDevicesScreen` and `ReceiveScreen` now stop the service directly
when they leave composition (back button, not full app close) unless a
session actually reached `Connected` - covering backing out to Home without
closing the app, at any point before or during connecting.
**Reason:** Direct report ("even if the app already close it still appear on
my notifications beamshare session active").
**Expected improvement:** The notification should now clear both when
backing out of Discover/Receive without connecting, and when removing the
app from Recents at any point before a session forms.
**Side effects:** None to an active session - `onTaskRemoved()` deliberately
does end an in-progress session too (a WiFi Direct transfer has no good
reason to keep running once the app is fully closed on this end), but a
session already `Connected` and showing in `ConnectedSessionScreen` is
unaffected, since forward navigation into that screen only happens once
`sessionState` has already reached `Connected` - the one case the two
screens' dispose-time check deliberately excludes.
**Verification:** No compiler/device. `stopWithTask` isn't set on the
service's manifest entry, and a started service isn't stopped on task removal
by default without it or an `onTaskRemoved()` override - the latter is the
standard, documented mechanism for exactly this. Confirmed by grepping every
call site of `BeamShareService.start`/`stop` (two starts, zero stops, before
this fix) and every `SessionState` transition in `SessionManager.kt` to
confirm `None` truly has no path to `Disconnected` on its own.

---

## 1.0.4

Three bugs reported directly: QR scanner opening to a black screen, the
Receive screen never showing a QR code to scan, and WiFi Direct
reporting "busy." All three were real, all three were in the WiFi
Direct/camera plumbing rather than anything cosmetic, and none needed a
build log this time - these are runtime/logic bugs a compiler can't
catch, found by reading the actual code paths end to end.

### 1. QR scanner opens to a black screen

**Category:** Bug fix (root cause)
**Files modified:** `QrScannerScreen.kt`
**Problem:** Nothing in the app ever requested `CAMERA` permission.
`QrScannerScreen`'s own doc comment even said "assumes camera permission
is already granted by the caller" - but no caller ever actually granted
it; `DiscoverDevicesScreen`'s "Scan QR code" button navigated straight
here with zero permission handling. Without it, `bindToLifecycle()`
throws, and that throw was going into a bare `runCatching {}` with no
`onFailure` handler at all - silently swallowed, leaving `PreviewView`
with no camera feed and nothing on screen to explain why.
**Solution:** Two changes. `QrScannerScreen` now owns its own permission
check and request flow (rather than trusting a caller that never
actually gated it) - it requests `CAMERA` on first composition, shows a
rationale/retry state if denied, and an "Open settings" fallback if
denied permanently (the system won't show the permission dialog again
after that). Separately, `CameraPreviewWithAnalysis`'s `runCatching`
around the bind call now has an `onFailure` that surfaces a real
"camera couldn't start" message instead of a silent no-op - so even a
*different* bind failure (no back camera, camera already claimed by
another app) is visible instead of another black screen with no
explanation.
**Reason:** Direct report ("the scan is black i think camera doesn't
work on app").
**Expected improvement:** The scanner should now either show a live
camera preview, or a clear reason why it can't - never a silent black
screen either way.
**Side effects:** None to the happy path - once permission is granted,
behavior is unchanged. Denying permission now shows UI instead of
nothing, which is strictly more informative, not a regression.
**Verification:** No compiler/device. Confirmed `PermissionHelper` didn't
already have camera-permission-request wiring anywhere upstream of this
screen (grepped every call site of `Manifest.permission.CAMERA` and
`hasCameraPermission` before this fix - `hasCameraPermission()` existed
in `PermissionHelper` but was never actually called from anywhere, a
half-built check with no request flow attached to it). This is about as
confident as a fix gets without a device: a missing permission request is
a definite gap, not a guess, and `ActivityResultContracts.RequestPermission()`
is the same standard pattern already used for the nearby-devices
permission elsewhere in this app.

---

### 2. Receive screen never shows its own QR code

**Category:** Bug fix (root cause)
**Files modified:** `WifiDirectManager.kt`
**Problem:** `thisDevice` (what the QR code encodes) was populated
*only* by `WIFI_P2P_THIS_DEVICE_CHANGED_ACTION` - a broadcast that fires
on a **change**, not as an on-demand "here's the current state" query.
If WiFi Direct was already active before this app's receiver registered
(WiFi already on, or another app had already initialized P2P earlier),
there may be no subsequent "change" event to fire it at all - leaving
`thisDevice` at its initial `null` forever, and the Receive screen
showing its loading spinner indefinitely instead of a QR code.
**Solution:** Added an active query. `requestDeviceInfo()` (API 29+) is
now called directly after the channel initializes, and again whenever
`WIFI_P2P_STATE_CHANGED_ACTION` confirms P2P just turned on - two real
chances to populate `thisDevice` instead of depending entirely on a
broadcast that may never come. Pre-API 29 has no equivalent direct-query
API and still depends on the broadcast alone; see KNOWN_LIMITATIONS.md.
**Reason:** Direct report ("no qr to scan on receiver").
**Expected improvement:** The QR code should now appear promptly on
devices running API 29+ (Android 10, the large majority of real
devices) regardless of whether WiFi Direct was already active before
the app opened.
**Side effects:** None - this only adds an additional way `thisDevice`
gets populated; the existing broadcast-based path is untouched and
still runs alongside it.
**Verification:** No compiler/device. `requestDeviceInfo()`'s existence
and signature (added API 29, takes a `Channel` and a
`DeviceInfoListener`) checked against the same `WifiP2pManager` API
family the rest of this file already uses correctly (`requestPeers`,
`requestConnectionInfo` - both same shape, both already working code in
this file). The "broadcast fires on change, not on query" distinction is
standard, well-documented Android broadcast-receiver behavior, not
specific to this API - the same reasoning applies to why apps generally
need a "request current state" call *and* a change listener, not one or
the other, for any sticky-feeling state.

---

### 3. "WiFi Direct is busy"

**Category:** Bug fix (robustness / retry handling)
**Files modified:** `WifiDirectManager.kt`
**Problem:** Two contributing gaps. First, nothing prevented
`startDiscovery()` from being called again while a previous call was
still being processed by the framework - a real path to this exists:
last pass's Receive-screen fix re-arms waiting
(`viewModel.startWaiting()`) on `SessionState.Disconnected`, and if that
fires while an earlier `discoverPeers()` call hasn't been acknowledged
yet, the second call can get rejected as `BUSY`. Second, and separately,
`BUSY` was always treated as a terminal error requiring the user to
manually retry - but per Android's own documented behavior, `BUSY`
specifically means "the framework is still finishing your last command,"
which is often true for a very short window and resolves itself, not a
real failure needing user intervention.
**Solution:** `startDiscovery()` now no-ops if a discovery request is
already in flight (`isDiscovering` guard), closing the redundant-call
path directly. Separately, both `startDiscovery()` and
`connectToAddress()` now auto-retry once (up to 3 times, ~1.2s apart)
specifically on `BUSY` before surfacing it as a user-facing error -
transient busy states resolve without ever bothering the user; a
genuinely stuck state still surfaces the existing error/retry UI after
the retry budget is spent.
**Reason:** Direct report ("it say wifi direct is busy").
**Expected improvement:** The busy message should now be rare -
appearing only if the framework is still busy after ~3.6 seconds of
retrying, rather than on the first transient collision.
**Side effects:** A `BUSY` failure now takes up to ~3.6s longer to
surface as a visible error than before (the retry window) - deliberate;
that's strictly better than showing an error for something that would
have resolved on its own a moment later.
**Verification:** No compiler/device. This is the fix I'm least certain
pins the *exact* trigger the report describes, since there's no
attached log for this one (unlike the two build-log-driven passes
before it) - the redundant-discovery-call path is a real, traceable gap
this codebase had (confirmed by reading `ReceiveScreen`'s own
re-arm-on-disconnect logic added last pass), and the BUSY-specific
retry is correct, defensive handling regardless of whether that's the
exact path that produced this specific report. See
KNOWN_LIMITATIONS.md.
