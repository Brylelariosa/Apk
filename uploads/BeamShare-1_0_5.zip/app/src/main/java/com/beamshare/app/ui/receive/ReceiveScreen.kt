package com.beamshare.app.ui.receive

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.beamshare.app.R
import com.beamshare.app.core.model.SessionState
import com.beamshare.app.core.qr.ConnectPayload
import com.beamshare.app.core.qr.QrCodeGenerator
import com.beamshare.app.di.ServiceLocator
import com.beamshare.app.service.BeamShareService
import com.beamshare.app.ui.components.PermissionRationale
import com.beamshare.app.ui.util.beamViewModel
import com.beamshare.app.util.PermissionHelper

@Composable
fun ReceiveScreen(
    onConnected: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val viewModel: ReceiveViewModel = beamViewModel {
        ReceiveViewModel(ServiceLocator.wifiDirectManager, ServiceLocator.sessionManager)
    }
    val context = LocalContext.current
    var hasPermission by remember { mutableStateOf(PermissionHelper.hasNearbyPermission(context)) }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        hasPermission = granted
    }

    LaunchedEffect(hasPermission) {
        if (hasPermission) {
            BeamShareService.start(context)
            viewModel.startWaiting()
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            // BeamShareService was started above to prepare for a session. The only reason to
            // leave it running once this screen is gone is that a session actually connected
            // and we're navigating forward into it (onConnected(), which fires exactly on
            // SessionState.Connected) - every other way of leaving (never started, still
            // waiting/handshaking, an ignored incoming request, or already disconnected) has
            // nothing left for the service to do.
            if (viewModel.sessionState.value !is SessionState.Connected) {
                BeamShareService.stop(context)
            }
        }
    }

    val thisDevice by viewModel.thisDevice.collectAsState()
    val sessionState by viewModel.sessionState.collectAsState()
    val qrPayload = thisDevice?.let { ConnectPayload(it.macAddress, it.name).encode() }

    LaunchedEffect(sessionState) {
        if (sessionState is SessionState.Connected) onConnected()
        if (sessionState is SessionState.Disconnected && hasPermission) viewModel.startWaiting()
    }

    Scaffold(
        modifier = modifier,
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.receive_title)) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(ImageVector.vectorResource(R.drawable.ic_arrow_back), contentDescription = null) }
                }
            )
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            if (!hasPermission) {
                PermissionRationale(
                    title = stringResource(R.string.discover_permission_title),
                    body = stringResource(R.string.discover_permission_body),
                    actionLabel = stringResource(R.string.discover_permission_grant),
                    onGrant = { permissionLauncher.launch(PermissionHelper.nearbyPermission()) },
                    modifier = Modifier.align(Alignment.Center).fillMaxWidth().padding(24.dp)
                )
            } else {
                WaitingContent(
                    deviceName = thisDevice?.name,
                    qrPayload = qrPayload,
                    modifier = Modifier.align(Alignment.Center)
                )
            }

            (sessionState as? SessionState.IncomingRequest)?.let { incoming ->
                IncomingRequestDialog(peerName = incoming.peerName, onAccept = viewModel::accept, onDecline = viewModel::decline)
            }
        }
    }
}

@Composable
private fun WaitingContent(deviceName: String?, qrPayload: String?, modifier: Modifier = Modifier) {
    Column(modifier = modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        if (qrPayload != null) {
            val qrBitmap = remember(qrPayload) { QrCodeGenerator.generate(qrPayload) }
            Surface(
                shape = MaterialTheme.shapes.large,
                color = androidx.compose.ui.graphics.Color.White
            ) {
                Image(
                    bitmap = qrBitmap,
                    contentDescription = null,
                    modifier = Modifier.size(220.dp).padding(16.dp)
                )
            }
            Spacer(Modifier.height(16.dp))
            Text(
                stringResource(R.string.receive_show_qr_hint),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(28.dp))
        } else {
            CircularProgressIndicator()
            Spacer(Modifier.height(28.dp))
        }
        Text(stringResource(R.string.receive_waiting), style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center)
        if (deviceName != null) {
            Spacer(Modifier.height(4.dp))
            Text(deviceName, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun IncomingRequestDialog(peerName: String, onAccept: () -> Unit, onDecline: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDecline,
        title = { Text(stringResource(R.string.receive_incoming_request, peerName)) },
        confirmButton = { TextButton(onClick = onAccept) { Text(stringResource(R.string.receive_accept)) } },
        dismissButton = { TextButton(onClick = onDecline) { Text(stringResource(R.string.receive_decline)) } }
    )
}
