# HZCM v4 — Engineering Change Log (v8 → v9)

## New Files

### `hzcm/LockFreeJobQueue.h`
- **Replaces**: `World::Pool` (std::mutex + std::queue + std::condition_variable)
- **Pattern**: Dmitry Vyukov MPMC bounded ring, 64-byte cache-line-aligned cells
- **Jobs**: Tagged union `WorldJob` — `CHUNK_BUILD`, `CLUSTER_REBUILD`,
  `NEIGHBOUR_FLUSH` — stores all args inline (no heap allocation)
- **Capacity**: 1 024 slots × 64 bytes = 64 KB (hot in L2 cache)
- **Benefit**: Eliminates mutex contention between 3 workers; zero
  `std::function` heap allocation per job; sleep path via `condition_variable`
  avoids busy-spin on mobile cores

### `hzcm/RenderDistanceSystem.h`
- Runtime hot-reload render distance **[2..200]** chunks
- Single `std::atomic<int>` — zero-cost multi-thread read
- Change-generation counter for O(1) change detection by callers
- Console command parser: `/renderdistance N`, `/rd N`
- `formatHUD()` for debug overlay text
- JNI-exposed via 3 new native methods: `nativeSendCommand`,
  `nativeSetRenderDistance`, `nativeGetRenderDistance`

### `hzcm/RingUploadBuffer.h`
- **Replaces**: bare `glBufferSubData` calls in `MegaBuffer::upload()`
- **Mechanism**: Three-slot ring. Each slot = a pre-allocated CPU staging
  `std::vector<PackedFace>`. Before reusing a slot, waits on its `GLsync`
  fence (5 ms timeout then forced). After flushing, inserts a new fence.
- **Upload path**: `stage()` memcopies into CPU staging; `flush()` issues
  **one** `glMapBufferRange(UNSYNCHRONIZED)` call per pending region —
  the `UNSYNCHRONIZED` flag instructs the driver not to wait for the GPU.
- **Result**: CPU/GPU upload sync stalls eliminated. All staging for a
  frame is committed in one driver round-trip vs. N separate calls.

### `hzcm/PageAllocator.h`
- **Replaces**: first-fit bitmap allocator in `MegaBuffer`
- **Size classes**: 4 pools — ≤64, ≤256, ≤1024, ≤4096 faces
- **Each class**: stack-based O(1) freelist of fixed-size pages
- **Benefit**: Zero cross-class fragmentation; long sessions stable;
  no more "MegaBuffer full" despite adequate total free capacity

### `hzcm/HierarchicalVisibility.h`
- Sky-slab culling: clusters entirely above `surface + 2×CL_SIZE` and
  above camera Y are marked invisible — skipped before frustum test
- Underground culling: clusters > `UNDERGROUND_DROP` (32) blocks below
  surface AND below camera (with Chebyshev distance > 2) are culled
- Temporal reuse: rebuilt only when camera changes chunk; otherwise
  O(1) query per cluster via a `GRID×GRID` byte array
- Memory: `421×421×1 byte ≈ 177 KB` — fits in L2

### `hzcm/DrawBatcher.h`
- Collects `(origin, megaOffset, faceCount)` per visible cluster
- Sorts by ascending `megaOffset` before issuing draws → sequential
  VBO reads → better driver prefetch and fewer partial-tile flushes
- Designed for easy upgrade to `glMultiDrawArraysIndirectEXT` (GLES 3.1)
  when available — data layout is already `DrawArraysIndirectCommand`-compatible

---

## Modified Files

### `hzcm/ClusterTypes.h`
- Added `DirtySliceMask` (uint16_t bitmask, 1 bit per Y-slice)
- `ClusterGPUSlot` now stores `allocSize` so `PageAllocator::free()` can
  be called without a side-channel lookup
- `ClusterDesc` pads to 64 bytes (false-sharing prevention between adjacent
  clusters in the same `Chunk`)

### `hzcm/MegaBuffer.h`
- Delegates allocation to `PageAllocator` (size-class pools)
- Delegates uploads to `RingUploadBuffer` (triple-buffered, fenced)
- `beginFrame()` / `upload()` / `flushUploads()` API replaces single
  `upload()` — callers batch all staging before one flush per frame

### `hzcm/ThermalManager.h`
- Added `CRITICAL` state (< 20 fps sustained)
- `radiusScale()` — returns `[0.30..1.00]` multiplier applied to
  render distance; hot devices automatically shrink their streaming radius
- Budget tables tuned for 60/45/30/20 fps tiers

### `hzcm/StreamScheduler.h`
- `update()` now accepts `camY` for altitude-aware future priority
- `buildCandidates()` takes explicit `outerR` parameter (no more
  compile-time `RENDER_RADIUS` constant) → supports runtime RD 2..200
- `out.reserve()` before fill avoids reallocation at large radii

### `World.h / World.cpp`
- Worker pool converted to `LockFreeJobQueue` + `std::vector<std::thread>`
- All `enqueueTask(lambda)` calls replaced by typed `WorldJob` pushes
- `executeJob()` dispatches to `workerChunkBuild / workerClusterRebuild /
  workerNeighbourFlush` — no virtual dispatch, no heap allocation
- `update()` consults `RenderDistanceSystem::pollChanged()` to react
  to runtime RD changes without polling every frame
- `updateGPU()` uses stale-generation check (`clusterDirtyGen`) to
  discard superseded upload tasks
- `gatherAndDraw()` replaces the renderer's manual cluster loop;
  integrates `HierarchicalVisibility` + `DrawBatcher`
- Effective radius = `requested × thermalScale`, clamped to [2..200]

### `Chunk.h / Chunk.cpp`
- Added `clusterDirtyGen[CLUSTER_STACK]` — bumped on each dirty/rebuild;
  allows `updateGPU()` to detect and discard stale upload tasks

### `Renderer.cpp`
- **Vertex shader rewritten — LUT-driven, zero branches**:
  - `FACE_S/T/N[6]` const vec3 arrays replace `S_AXIS/T_AXIS/N_AXIS` +
    chain of `if (sAxis==0)` tests
  - `BLOCK_COL[30]` flat array replaces `blockColor()` function with
    10 nested `if (btype==N)` branches — compiler maps to a register load
  - Fog onset now `0.70 × uFogEnd`; `uFogEnd` updated each frame from
    effective render radius so fog always matches the loaded world edge
- `renderClusters()` removed — replaced by `world.gatherAndDraw()`
- Debug overlay: two coloured bars in bottom-left corner —
  thermal pressure (green→red) + render distance fraction (white)
- `Renderer::sendCommand()` forwards to `world.parseCommand()` for
  in-game `/rd N` commands via `nativeSendCommand` JNI

### `jni_bridge.cpp`
- `nativeSendCommand(String)` — parses `/rd N` style console commands
- `nativeSetRenderDistance(int)` — direct Java numeric input (SeekBar)
- `nativeGetRenderDistance()` — Java UI query

---

## Bottleneck Resolution Summary

| # | Issue | Solution | File |
|---|-------|----------|------|
| 1 | glBufferSubData stalls | RingUploadBuffer (triple-buf + GLsync fences + UNSYNCHRONIZED map) | RingUploadBuffer.h |
| 2 | Visibility over-submission | HierarchicalVisibility (sky/underground slab cull + temporal reuse) | HierarchicalVisibility.h |
| 3 | Full cluster rebuilds | `clusterDirtyGen` stale detection; DirtySliceMask infrastructure for future partial meshing | ClusterTypes.h, Chunk.h |
| 4 | MegaBuffer fragmentation | PageAllocator (size-class page pools, O(1) freelist) | PageAllocator.h |
| 5 | Shader ALU pressure | LUT arrays FACE_S/T/N + BLOCK_COL[30] replace all branches in vertex shader | Renderer.cpp |
| 6 | Thread pool contention | LockFreeJobQueue (MPMC Vyukov ring, no heap alloc per job) | LockFreeJobQueue.h |
| 7 | Thermal spikes | ThermalManager CRITICAL state + radiusScale() streaming radius throttle | ThermalManager.h |
| 8 | CPU draw overhead | DrawBatcher (sort by megaOffset → sequential reads, state minimisation) | DrawBatcher.h |
| 9 | Runtime render distance | RenderDistanceSystem (atomic, [2..200], hot-reload, JNI + console) | RenderDistanceSystem.h |
|10 | Future visibility scaling | HierarchicalVisibility DAG + portal-ready ChunkVisibility bitmasks | HierarchicalVisibility.h |
