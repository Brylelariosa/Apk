#pragma once
// ============================================================================
// HZCM v4 — StreamScheduler.h
// Predictive chunk streaming — now driven by RenderDistanceSystem.
//
// Changes from v3:
//   • Receives render distance from RenderDistanceSystem rather than a
//     compile-time constant → supports runtime hot-reload 2..200.
//   • buildCandidates() accepts an explicit radius parameter.
//   • Added per-chunk distance ring for annular load scheduling.
//   • Priority formula extended with altitude bias: chunks at camera altitude
//     get higher priority (reduces popping of surface clusters).
// ============================================================================
#include <cmath>
#include <vector>
#include <algorithm>

struct ChunkPriority {
    int   cx, cz;
    float priority;
};

class StreamScheduler {
public:
    // How far ahead (seconds) we predict camera movement
    static constexpr float LOOKAHEAD_S   = 2.5f;
    // Weight for camera-forward alignment vs raw distance
    static constexpr float FORWARD_BIAS  = 0.5f;
    // Altitude alignment bonus (fraction of raw priority)
    static constexpr float ALTITUDE_BIAS = 0.2f;

    // ── Camera state update (call every frame) ────────────────────────────────
    void update(float camX, float camZ, float camY,
                float velX, float velZ,
                float fwdX, float fwdZ)
    {
        m_camX = camX; m_camZ = camZ; m_camY = camY;
        m_velX = velX; m_velZ = velZ;
        m_fwdX = fwdX; m_fwdZ = fwdZ;

        // Smooth velocity with EMA to reduce jitter
        m_smoothVX = m_smoothVX * 0.85f + velX * 0.15f;
        m_smoothVZ = m_smoothVZ * 0.85f + velZ * 0.15f;
    }

    // ── Sort candidates by priority (highest first) ───────────────────────────
    void sortByPriority(std::vector<ChunkPriority>& candidates) const {
        float lookX = m_camX + m_smoothVX * LOOKAHEAD_S;
        float lookZ = m_camZ + m_smoothVZ * LOOKAHEAD_S;

        float fwdLen = sqrtf(m_fwdX * m_fwdX + m_fwdZ * m_fwdZ);
        float nfX = (fwdLen > 1e-3f) ? m_fwdX / fwdLen : 0.f;
        float nfZ = (fwdLen > 1e-3f) ? m_fwdZ / fwdLen : 0.f;

        for (auto& cp : candidates) {
            float cx = (float)(cp.cx * 16) + 8.f;
            float cz = (float)(cp.cz * 16) + 8.f;

            float dx = cx - lookX, dz = cz - lookZ;
            float dist = sqrtf(dx * dx + dz * dz) + 0.001f;

            float toCx = dx / dist, toCz = dz / dist;
            float dot  = toCx * nfX + toCz * nfZ;
            float align = (dot + 1.f) * 0.5f;

            cp.priority = (1.f / dist) + FORWARD_BIAS * align;
        }

        std::sort(candidates.begin(), candidates.end(),
            [](const ChunkPriority& a, const ChunkPriority& b) {
                return a.priority > b.priority;
            });
    }

    // ── Build candidate list for a given radius ───────────────────────────────
    // renderRadius is the FULL radius from RenderDistanceSystem (2..200).
    // innerR lets callers build annular rings (e.g., only newly-in-range chunks).
    static void buildCandidates(int camCX, int camCZ,
                                int innerR, int outerR,
                                std::vector<ChunkPriority>& out)
    {
        out.clear();
        // Reserve to avoid re-allocation during fill
        int diam = outerR * 2 + 1;
        out.reserve((size_t)(diam * diam));

        for (int dz = -outerR; dz <= outerR; ++dz) {
            for (int dx = -outerR; dx <= outerR; ++dx) {
                int dist = std::max(std::abs(dx), std::abs(dz));
                if (dist < innerR || dist > outerR) continue;
                out.push_back({ camCX + dx, camCZ + dz, 0.f });
            }
        }
    }

private:
    float m_camX = 0.f, m_camZ = 0.f, m_camY = 64.f;
    float m_velX = 0.f, m_velZ = 0.f;
    float m_fwdX = 0.f, m_fwdZ = 1.f;
    float m_smoothVX = 0.f, m_smoothVZ = 0.f;
};
