#pragma once
// ============================================================================
// HZCM v4 — PageAllocator.h
// Size-class page pool for MegaBuffer face allocations.
//
// Problem solved:
//   The original first-fit bitmap allocator fragments over long sessions.
//   Small cluster allocations fill gaps left by large evictions, making
//   large subsequent allocations fail even with plenty of free faces total.
//
// Solution:
//   Fixed size classes with dedicated page pools.
//   Each size class owns a contiguous region of the MegaBuffer.
//   Within each region, allocations are O(1) slab alloc via freelist.
//   No cross-class contamination → zero fragmentation growth.
//
// Size classes (faces per cluster allocation):
//   Class 0: 1 –   64  → page = 64 faces  (cache-line aligned)
//   Class 1: 65 –  256  → page = 256 faces
//   Class 2: 257 – 1024 → page = 1024 faces
//   Class 3: 1025+      → page = 4096 faces (worst-case greedy mesh)
//
// MegaBuffer layout (total = MEGA_FACE_CAPACITY faces):
//   [  class0_pages  |  class1_pages  |  class2_pages  |  class3_pages  ]
//
// Thread safety: alloc/free called from GL thread only.
// ============================================================================
#include <cstdint>
#include <cstring>
#include <cstdio>
#include <algorithm>
#include <android/log.h>
#include "ClusterTypes.h"   // MEGA_INVALID, MEGA_FACE_CAPACITY

// ── Size class parameters ─────────────────────────────────────────────────────
struct SizeClass {
    uint32_t maxFaces;   // inclusive upper bound for this class
    uint32_t pageSize;   // allocation unit (faces)
    uint32_t numPages;   // pages reserved in MegaBuffer
};

// Tuned for typical greedy-mesh output distributions on 16³ clusters:
//   • Most stone/dirt clusters: 100–400 faces
//   • Surface clusters with terrain variety: 300–800 faces
//   • Dense decorated clusters: 800–2400 faces (rare)
static constexpr SizeClass SIZE_CLASSES[4] = {
    {  64,   64,  200 },   // Class 0: tiny clusters (underground solid)
    { 256,  256,  400 },   // Class 1: small-medium (most common)
    {1024, 1024,  300 },   // Class 2: large surface / complex
    {4096, 4096,  100 },   // Class 3: worst-case decorated
};
static constexpr int NUM_SIZE_CLASSES = 4;

// Total capacity: 200×64 + 400×256 + 300×1024 + 100×4096
//               = 12800 + 102400 + 307200 + 409600 = 832000 faces
// Each face = 8 bytes → 6.72 MB
// (Adjust numPages in SIZE_CLASSES for your VRAM budget)

class PageAllocator {
public:
    PageAllocator() = default;

    // Must be called before any alloc/free. `megaTotalFaces` is the total
    // capacity of the MegaBuffer in PackedFace units.
    // Returns total faces actually used (may differ from MEGA_FACE_CAPACITY).
    uint32_t init(uint32_t megaTotalFaces) {
        // Compute start offset of each class region
        uint32_t offset = 0;
        for (int c = 0; c < NUM_SIZE_CLASSES; ++c) {
            m_regionStart[c] = offset;
            m_pagesFree[c]   = SIZE_CLASSES[c].numPages;
            uint32_t regionFaces = SIZE_CLASSES[c].pageSize * SIZE_CLASSES[c].numPages;

            // Init freelist as a stack: page[i] → free[i]
            for (uint32_t p = 0; p < SIZE_CLASSES[c].numPages; ++p) {
                m_freelists[c][p] = static_cast<uint16_t>(p);
            }
            m_freelistTop[c] = SIZE_CLASSES[c].numPages;

            __android_log_print(ANDROID_LOG_INFO, "PageAlloc",
                "Class %d: %u pages × %u faces = %u faces @ offset %u",
                c, SIZE_CLASSES[c].numPages, SIZE_CLASSES[c].pageSize,
                regionFaces, offset);

            offset += regionFaces;
            if (offset > megaTotalFaces) {
                __android_log_print(ANDROID_LOG_ERROR, "PageAlloc",
                    "MegaBuffer too small for class %d! Need %u, have %u",
                    c, offset, megaTotalFaces);
                // Clamp this class
                m_freelistTop[c] = 0;
                offset -= regionFaces;
            }
        }
        m_totalUsed = 0;
        return offset;
    }

    // Allocate `numFaces` faces. Returns face offset into MegaBuffer, or
    // MEGA_INVALID on failure.
    uint32_t alloc(uint32_t numFaces) {
        if (numFaces == 0) return MEGA_INVALID;

        int c = classFor(numFaces);
        if (c < 0 || m_freelistTop[c] == 0) {
            // Try next larger class
            for (int cc = (c < 0 ? 0 : c + 1); cc < NUM_SIZE_CLASSES; ++cc) {
                if (m_freelistTop[cc] > 0) { c = cc; goto found; }
            }
            __android_log_print(ANDROID_LOG_WARN, "PageAlloc",
                "Out of pages for %u faces", numFaces);
            return MEGA_INVALID;
        }

    found:
        uint32_t pageIdx = m_freelists[c][--m_freelistTop[c]];
        m_pagesFree[c]--;
        m_totalUsed += SIZE_CLASSES[c].pageSize;

        uint32_t offset = m_regionStart[c] + pageIdx * SIZE_CLASSES[c].pageSize;
        return offset;
    }

    // Free a previous allocation. `offset` must be the value returned by alloc.
    // `numFaces` is the original requested count (used to determine class).
    void free(uint32_t offset, uint32_t numFaces) {
        if (offset == MEGA_INVALID) return;

        // Determine class from offset
        int c = classFromOffset(offset);
        if (c < 0) {
            __android_log_print(ANDROID_LOG_ERROR, "PageAlloc",
                "free: invalid offset %u", offset);
            return;
        }

        uint32_t pageIdx = (offset - m_regionStart[c]) / SIZE_CLASSES[c].pageSize;
        m_freelists[c][m_freelistTop[c]++] = static_cast<uint16_t>(pageIdx);
        m_pagesFree[c]++;
        m_totalUsed -= SIZE_CLASSES[c].pageSize;
    }

    // Diagnostics
    uint32_t totalUsedFaces()  const { return m_totalUsed; }
    uint32_t freeInClass(int c) const {
        return (c >= 0 && c < NUM_SIZE_CLASSES) ? m_pagesFree[c] : 0;
    }

    // Return the page size for the class that would serve numFaces.
    // This is the actual allocated capacity (>= numFaces).
    uint32_t pageCapacity(uint32_t numFaces) const {
        int c = classFor(numFaces);
        return (c >= 0) ? SIZE_CLASSES[c].pageSize : 0;
    }

private:
    uint32_t m_regionStart[NUM_SIZE_CLASSES] = {};
    uint32_t m_pagesFree[NUM_SIZE_CLASSES]   = {};
    uint32_t m_totalUsed = 0;

    // Per-class freelist stack (page indices within the class region)
    // Max pages per class = 400 → uint16_t is sufficient
    uint16_t m_freelists[NUM_SIZE_CLASSES][400] = {};
    uint32_t m_freelistTop[NUM_SIZE_CLASSES]     = {};

    static int classFor(uint32_t numFaces) {
        for (int c = 0; c < NUM_SIZE_CLASSES; ++c)
            if (numFaces <= SIZE_CLASSES[c].maxFaces) return c;
        return NUM_SIZE_CLASSES - 1; // largest class
    }

    int classFromOffset(uint32_t offset) const {
        for (int c = NUM_SIZE_CLASSES - 1; c >= 0; --c) {
            if (offset >= m_regionStart[c]) return c;
        }
        return -1;
    }
};
