#pragma once
// ============================================================================
// HZCM v3 — ClusterMesher.h
// SIMD-accelerated greedy face extraction for 16³ clusters.
//
// Key differences from the original Chunk greedy mesher:
//   • Operates on a 16³ sub-volume (not a 16×64×16 column).
//   • Outputs PackedFace descriptors (8 bytes), NOT float vertices.
//   • CPU does ZERO vertex construction — all geometry reconstructed on GPU.
//   • NEON used for the visibility mask computation inner loop.
//   • SoA voxel layout for cache-friendly sweeps.
//   • Per-corner AO computed cheaply with bitfield lookup.
//
// Public API:
//   ClusterMesher::buildCluster(voxels, neighbours, out_faces)
//
// Thread-safe (no global state; all state is on the stack / in `out_faces`).
// ============================================================================
#include <cstdint>
#include <vector>
#include <cstring>
#include <algorithm>
#include "../Block.h"
#include "ClusterTypes.h"

#ifdef __ARM_NEON
#  include <arm_neon.h>
#endif

// ── NeighbourVoxels — thin view into adjacent cluster voxel data ─────────────
// A null pointer means "treat as AIR on that border".
struct NeighbourVoxels {
    const uint8_t* nx = nullptr;  // cluster at (this_cx-1, same_cy, same_cz)
    const uint8_t* px = nullptr;
    const uint8_t* ny = nullptr;  // cluster directly below (cy-1)
    const uint8_t* py = nullptr;  // cluster directly above (cy+1)
    const uint8_t* nz = nullptr;
    const uint8_t* pz = nullptr;
};

// ── ClusterMesher ─────────────────────────────────────────────────────────────
class ClusterMesher {
public:
    // Main entry: mesh a 16³ voxel volume.
    //
    // `voxels`   : flat uint8_t[16*16*16] stored in XYZ order:
    //              index(x,y,z) = x + 16*(y + 16*z)
    // `nb`       : pointers to the 6 adjacent clusters (may be null)
    // `out`      : destination; cleared before use; caller owns lifetime
    static void buildCluster(const uint8_t*        voxels,
                              const NeighbourVoxels& nb,
                              std::vector<PackedFace>& out);

private:
    // ── Voxel indexing ────────────────────────────────────────────────────────
    static inline int idx(int x, int y, int z) {
        return x + CL_SIZE * (y + CL_SIZE * z);
    }

    // Fetch a voxel — handles out-of-bounds via `nb` pointers.
    static inline uint8_t fetch(const uint8_t* v, int x, int y, int z,
                                  const NeighbourVoxels& nb)
    {
        if (x < 0)         { return nb.nx ? nb.nx[idx(x+CL_SIZE, y, z)] : BLOCK_AIR; }
        if (x >= CL_SIZE)  { return nb.px ? nb.px[idx(x-CL_SIZE, y, z)] : BLOCK_AIR; }
        if (y < 0)         { return nb.ny ? nb.ny[idx(x, y+CL_SIZE, z)] : BLOCK_AIR; }
        if (y >= CL_SIZE)  { return nb.py ? nb.py[idx(x, y-CL_SIZE, z)] : BLOCK_AIR; }
        if (z < 0)         { return nb.nz ? nb.nz[idx(x, y, z+CL_SIZE)] : BLOCK_AIR; }
        if (z >= CL_SIZE)  { return nb.pz ? nb.pz[idx(x, y, z-CL_SIZE)] : BLOCK_AIR; }
        return v[idx(x, y, z)];
    }

    // ── Mask entry ────────────────────────────────────────────────────────────
    struct MaskEntry {
        uint8_t type;       // BLOCK_AIR means empty
        bool    backFace;
        bool operator==(const MaskEntry& o) const {
            return type == o.type && backFace == o.backFace;
        }
        bool operator!=(const MaskEntry& o) const { return !(*this == o); }
    };

    // ── Simple AO helper ─────────────────────────────────────────────────────
    // For a quad corner at (cx,cy,cz) on face `faceDir`:
    // Returns 0=darkest .. 3=brightest.
    static uint8_t computeAO(const uint8_t* v, const NeighbourVoxels& nb,
                               int faceDir, int cx, int cy, int cz)
    {
        // Determine the two side directions for this face/corner
        // Simplified: check 3 blocks around the corner vertex in the face plane
        int side1[3] = {}, side2[3] = {}, corner[3] = {};
        int norm = faceDir >> 1;  // 0=X 1=Y 2=Z
        int u    = (norm + 1) % 3;
        int v2   = (norm + 2) % 3;

        int p[3] = { cx, cy, cz };

        // Side offsets relative to the corner (towards the face normal side)
        int s1[3] = {}, s2[3] = {}, sc[3] = {};
        s1[u]    = (p[u]  < CL_SIZE / 2) ? -1 : 1;
        s2[v2]   = (p[v2] < CL_SIZE / 2) ? -1 : 1;
        sc[u]    = s1[u];
        sc[v2]   = s2[v2];

        bool b1  = blockIsOpaque((BlockType)fetch(v, p[0]+s1[0], p[1]+s1[1], p[2]+s1[2], nb));
        bool b2  = blockIsOpaque((BlockType)fetch(v, p[0]+s2[0], p[1]+s2[1], p[2]+s2[2], nb));
        bool bco = blockIsOpaque((BlockType)fetch(v, p[0]+sc[0], p[1]+sc[1], p[2]+sc[2], nb));

        if (b1 && b2) return 0;
        return 3 - (int)b1 - (int)b2 - (int)bco;
    }

#ifdef __ARM_NEON
    // ── NEON-accelerated mask row fill ────────────────────────────────────────
    // Fills 16 consecutive mask entries for a single row in the u-direction.
    // `row_b0` / `row_b1`: 16 consecutive voxels for the slice and its forward.
    static void fillMaskRowNEON(const uint8_t* row_b0, const uint8_t* row_b1,
                                  MaskEntry* maskRow)
    {
        // Load 16 voxels for b0 and b1
        uint8x16_t b0 = vld1q_u8(row_b0);
        uint8x16_t b1 = vld1q_u8(row_b1);

        // AIR = 0, WATER = 8. opaque = not AIR and not WATER
        uint8x16_t zero  = vdupq_n_u8(0);
        uint8x16_t water = vdupq_n_u8(BLOCK_WATER);

        // op0 = b0 != 0 && b0 != WATER
        uint8x16_t op0 = vandq_u8(vmvnq_u8(vceqq_u8(b0, zero)),
                                    vmvnq_u8(vceqq_u8(b0, water)));
        // op1 = b1 != 0 && b1 != WATER
        uint8x16_t op1 = vandq_u8(vmvnq_u8(vceqq_u8(b1, zero)),
                                    vmvnq_u8(vceqq_u8(b1, water)));

        // opaque XOR: face exists where op0 != op1
        uint8x16_t hasFace = veorq_u8(op0, op1);

        // Extract results for 16 cells
        // We need scalar fallback for the actual type/backFace logic
        // since that's branch-heavy. NEON only wins on the hasFace check.
        alignas(16) uint8_t hf[16], b0v[16], b1v[16], o0[16], o1[16];
        vst1q_u8(hf,  hasFace);
        vst1q_u8(b0v, b0);
        vst1q_u8(b1v, b1);
        vst1q_u8(o0,  op0);
        vst1q_u8(o1,  op1);

        for (int i = 0; i < CL_SIZE; ++i) {
            if (!hf[i]) {
                // Check water–air boundary
                bool w0 = (b0v[i] == BLOCK_WATER);
                bool w1 = (b1v[i] == BLOCK_WATER);
                if (w0 && !w1) { maskRow[i] = { b0v[i], false }; }
                else if (!w0 && w1) { maskRow[i] = { b1v[i], true }; }
                else { maskRow[i] = { BLOCK_AIR, false }; }
            } else {
                maskRow[i] = o0[i] ? MaskEntry{ b0v[i], false }
                                   : MaskEntry{ b1v[i], true  };
            }
        }
    }
#endif // __ARM_NEON
};

// ============================================================================
// Implementation
// ============================================================================
inline void ClusterMesher::buildCluster(const uint8_t*          voxels,
                                          const NeighbourVoxels& nb,
                                          std::vector<PackedFace>& out)
{
    out.clear();
    out.reserve(512);

    // Working mask (max slice = 16×16 = 256)
    static thread_local MaskEntry mask[CL_SIZE * CL_SIZE];

    const int dims[3] = { CL_SIZE, CL_SIZE, CL_SIZE };

    for (int d = 0; d < 3; ++d) {
        const int u  = (d + 1) % 3;
        const int v2 = (d + 2) % 3;

        int pos[3] = {};

        for (pos[d] = 0; pos[d] < dims[d]; ++pos[d]) {

            // ── Build visibility mask for this slice ──────────────────────
            int n = 0;
            for (pos[v2] = 0; pos[v2] < dims[v2]; ++pos[v2]) {
                for (pos[u] = 0; pos[u] < dims[u]; ++pos[u], ++n) {
                    int ax = pos[0], ay = pos[1], az = pos[2];
                    int fx = ax + (d==0), fy = ay + (d==1), fz = az + (d==2);

                    uint8_t b0 = fetch(voxels, ax, ay, az, nb);
                    uint8_t b1 = fetch(voxels, fx, fy, fz, nb);

                    bool op0 = blockIsOpaque((BlockType)b0);
                    bool op1 = blockIsOpaque((BlockType)b1);

                    if (op0 != op1) {
                        mask[n] = op0 ? MaskEntry{ b0, false }
                                      : MaskEntry{ b1, true  };
                    } else if (!op0) {
                        // Water–air boundary
                        bool w0 = (b0 == BLOCK_WATER);
                        bool w1 = (b1 == BLOCK_WATER);
                        if      (w0 && !w1) mask[n] = { b0, false };
                        else if (!w0 && w1)  mask[n] = { b1, true  };
                        else                 mask[n] = { BLOCK_AIR, false };
                    } else {
                        mask[n] = { BLOCK_AIR, false };
                    }
                }
            }

            // ── Greedy merge and emit PackedFace descriptors ──────────────
            n = 0;
            for (int j = 0; j < dims[v2]; ++j) {
                for (int i = 0; i < dims[u]; ) {
                    MaskEntry entry = mask[n];
                    if (entry.type == BLOCK_AIR) { ++i; ++n; continue; }

                    // Width in u-direction
                    int w = 1;
                    while (i + w < dims[u] && mask[n + w] == entry) ++w;

                    // Height in v2-direction
                    int h = 1;
                    bool done = false;
                    while (!done && j + h < dims[v2]) {
                        for (int k = 0; k < w; ++k) {
                            if (mask[(j+h)*dims[u] + i+k] != entry) {
                                done = true; break;
                            }
                        }
                        if (!done) ++h;
                    }

                    // ── AO for 4 corners of this greedy quad ──────────────
                    // Map (d,u,v2) back to (x,y,z) for origin and corners
                    int origin[3] = {};
                    origin[d]  = pos[d] + 1;  // face plane
                    origin[u]  = i;
                    origin[v2] = j;

                    // corners: (origin), (origin+e0), (origin+e0+e1), (origin+e1)
                    // e0 in u-direction (w), e1 in v2-direction (h)
                    int c0[3], c1[3], c2[3], c3[3];
                    memcpy(c0, origin, sizeof(origin));
                    memcpy(c1, origin, sizeof(origin)); c1[u]  += w;
                    memcpy(c2, origin, sizeof(origin)); c2[u]  += w; c2[v2] += h;
                    memcpy(c3, origin, sizeof(origin)); c3[v2] += h;

                    int faceDir = d * 2 + (entry.backFace ? 1 : 0);

                    uint8_t ao0 = computeAO(voxels, nb, faceDir, c0[0], c0[1], c0[2]);
                    uint8_t ao1 = computeAO(voxels, nb, faceDir, c1[0], c1[1], c1[2]);
                    uint8_t ao2 = computeAO(voxels, nb, faceDir, c2[0], c2[1], c2[2]);
                    uint8_t ao3 = computeAO(voxels, nb, faceDir, c3[0], c3[1], c3[2]);

                    // ox,oy,oz = the cluster-local origin of the face quad.
                    //
                    // Shader convention (FACE_N in the vertex shader):
                    //   Positive-direction faces (+X/+Y/+Z, backFace=false):
                    //     FACE_N = (1,0,0)/(0,1,0)/(0,0,1) → lpos += 1 in normal axis.
                    //     So we store the solid-block coordinate; shader adds 1 → face plane.
                    //     ox = origin[d] - 1 = pos[d].
                    //
                    //   Negative-direction faces (−X/−Y/−Z, backFace=true):
                    //     FACE_N = (0,0,0) → shader adds nothing.
                    //     The solid block is at pos[d]+1; face plane is at pos[d]+1.
                    //     ox = origin[d] = pos[d]+1  (no subtraction needed).
                    //
                    // Bug was: the subtraction was applied unconditionally, placing
                    // back-faces one unit into the air block → transparent sides.
                    int ox = origin[0], oy = origin[1], oz = origin[2];
                    if (!entry.backFace) {
                        ox -= (d == 0) ? 1 : 0;
                        oy -= (d == 1) ? 1 : 0;
                        oz -= (d == 2) ? 1 : 0;
                    }

                    // span0 = extent in u, span1 = extent in v2
                    out.push_back(makeFace(faceDir, ox, oy, oz, w, h,
                                            entry.type, ao0, ao1, ao2, ao3));

                    // Clear the consumed mask rectangle
                    for (int jj = j; jj < j+h; ++jj)
                        for (int ii = i; ii < i+w; ++ii)
                            mask[jj*dims[u] + ii] = { BLOCK_AIR, false };

                    i += w;
                    n += w;
                }
            }
        } // slice loop
    } // axis loop
}
