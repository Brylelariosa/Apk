package com.novaenhance.ai.ui.viewmodel

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.novaenhance.ai.ai.engine.EnhancementEngine
import com.novaenhance.ai.ai.engine.EnhancementOptions
import com.novaenhance.ai.ai.model.ModelRepository
import com.novaenhance.ai.storage.AppStorage
import com.novaenhance.ai.utils.NovaLog
import com.novaenhance.ai.utils.ThermalGovernor
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private const val TAG = "EnhanceViewModel"

// LabeledSlider reports every drag tick, not just the final value, and a
// full enhancement pass over a real photo is expensive (see TileProcessor).
// Without a debounce, dragging any slider for a second queues up dozens of
// full-image runs; since none were ever cancelled, they'd all keep running
// concurrently, competing for CPU and finishing in whatever order they
// happen to complete in rather than the order they were requested - both a
// performance and a correctness problem (a slow early run could overwrite
// a faster later one's result). This delay is how long the options have to
// stay still before a run actually starts.
private const val ENHANCEMENT_DEBOUNCE_MS = 200L

data class EnhanceUiState(
    val originalBitmap: Bitmap? = null,
    val enhancedBitmap: Bitmap? = null,
    val options: EnhancementOptions = EnhancementOptions(),
    val isProcessing: Boolean = false,
    val progressFraction: Float = 0f,
    val isSaving: Boolean = false,
    val savedUri: Uri? = null,
    val errorMessage: String? = null
)

class EnhanceViewModel(
    private val appContext: Context,
    private val modelRepository: ModelRepository,
    private val storage: AppStorage,
    private val thermalGovernor: ThermalGovernor
) : ViewModel() {

    private val _uiState = MutableStateFlow(EnhanceUiState())
    val uiState: StateFlow<EnhanceUiState> = _uiState.asStateFlow()

    private var enhancementJob: Job? = null

    fun onImageSelected(uri: Uri) {
        viewModelScope.launch {
            val bitmap = withContext(Dispatchers.IO) {
                appContext.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
            }
            if (bitmap == null) {
                _uiState.value = _uiState.value.copy(errorMessage = "Could not open that image")
                return@launch
            }
            _uiState.value = EnhanceUiState(originalBitmap = bitmap, options = _uiState.value.options)
            runEnhancement()
        }
    }

    fun onOptionsChanged(options: EnhancementOptions) {
        _uiState.value = _uiState.value.copy(options = options)
        runEnhancement()
    }

    fun runEnhancement() {
        val original = _uiState.value.originalBitmap ?: return
        enhancementJob?.cancel()
        enhancementJob = viewModelScope.launch {
            delay(ENHANCEMENT_DEBOUNCE_MS) // superseded by a newer call -> cancelled before any real work starts
            _uiState.value = _uiState.value.copy(isProcessing = true, progressFraction = 0f, errorMessage = null)
            try {
                val activeModel = modelRepository.getOrCreateActiveModel()
                val engine = modelRepository.getEngine(activeModel.id)
                val enhancer = EnhancementEngine(engine, thermalGovernor)
                val options = _uiState.value.options

                val startMs = System.currentTimeMillis()
                val result = withContext(Dispatchers.Default) {
                    enhancer.enhance(original, options) { progress ->
                        _uiState.value = _uiState.value.copy(progressFraction = progress.fraction)
                    }
                }
                NovaLog.i(TAG, "Enhanced ${original.width}x${original.height} in ${System.currentTimeMillis() - startMs}ms (options=$options)")
                _uiState.value = _uiState.value.copy(enhancedBitmap = result, isProcessing = false, progressFraction = 1f, savedUri = null)
            } catch (c: CancellationException) {
                throw c // superseded by a newer options change/image pick - not a real failure, don't show an error for it
            } catch (t: Throwable) {
                NovaLog.w(TAG, "Enhancement failed", t)
                _uiState.value = _uiState.value.copy(isProcessing = false, errorMessage = "Enhancement failed: ${t.message}")
            }
        }
    }

    /**
     * Saves the enhanced result into the shared Gallery (via
     * [AppStorage.saveEnhancedPhotoToGallery]) rather than this app's
     * private storage, so it actually shows up somewhere the user can find
     * it - see that function's doc comment for why the old destination was
     * indistinguishable from Save not working at all.
     */
    fun saveResult() {
        val enhanced = _uiState.value.enhancedBitmap ?: return
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isSaving = true, errorMessage = null)
            val uri = withContext(Dispatchers.IO) {
                storage.saveEnhancedPhotoToGallery(enhanced, "enhanced_${System.currentTimeMillis()}.jpg")
            }
            _uiState.value = if (uri != null) {
                _uiState.value.copy(isSaving = false, savedUri = uri)
            } else {
                _uiState.value.copy(isSaving = false, errorMessage = "Couldn't save the photo - please try again")
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        enhancementJob?.cancel()
        _uiState.value.originalBitmap?.recycle()
        _uiState.value.enhancedBitmap?.recycle()
    }
}
