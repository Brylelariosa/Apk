package com.game.topdown;

public class Bomb {
    public float  x, y;
    public float  vx, vy;           // throw velocity (world px/sec)
    public float  spawnX, spawnY;   // where it was thrown from
    public boolean hasLanded;        // true once it stops moving
    public int    ownerId;
    public long   deployTime;
    public long   explodedAt = -1;  // -1 = not yet exploded

    public static final float RADIUS      = 130f;
    public static final int   DAMAGE      = 80;
    public static final long  FUSE_MS     = 2500;   // slightly longer for throw arc
    public static final long  FLASH_MS    = 400;
    public static final float THROW_SPEED = 560f;   // world px/sec
    public static final float THROW_RANGE = 490f;   // max travel distance

    public Bomb(float x, float y, int ownerId) {
        this.x = x;  this.y = y;
        this.spawnX = x; this.spawnY = y;
        this.ownerId = ownerId;
        this.deployTime = System.currentTimeMillis();
    }

    /** Squared distance traveled (used to check max range). */
    public float traveledSq() {
        float dx = x - spawnX, dy = y - spawnY;
        return dx * dx + dy * dy;
    }

    /** True once the fuse has burned down. */
    public boolean shouldExplode() {
        return explodedAt < 0 && System.currentTimeMillis() - deployTime >= FUSE_MS;
    }

    /** True while the explosion flash is still visible. */
    public boolean isFlashing() {
        return explodedAt >= 0 && System.currentTimeMillis() - explodedAt < FLASH_MS;
    }

    /** True when we can safely remove this bomb from the list. */
    public boolean isDone() {
        return explodedAt >= 0 && System.currentTimeMillis() - explodedAt >= FLASH_MS;
    }
}
