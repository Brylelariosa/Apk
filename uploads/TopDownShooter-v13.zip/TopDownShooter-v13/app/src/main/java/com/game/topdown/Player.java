package com.game.topdown;

public class Player {
    public int    id;
    public String name   = "";
    public float  x, y, angle;
    public float  hp     = 100;
    public int    gunIndex;
    public boolean alive = true;
    public Gun[]  guns;
    public Gun currentGun() { return guns[gunIndex]; }

    // Economy & unlock state
    public int       coins        = 0;
    public boolean[] unlockedGuns = {true,false,false,false,false,false,false};

    // Bombs
    public int bombs = 2;   // starting stock; replenishes on respawn
}
