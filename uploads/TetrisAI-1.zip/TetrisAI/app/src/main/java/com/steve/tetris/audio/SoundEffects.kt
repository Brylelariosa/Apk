package com.steve.tetris.audio

import android.media.AudioManager
import android.media.ToneGenerator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * All sound effects are synthesized tones (no bundled audio files) - cheap,
 * zero APK footprint. A single ToneGenerator can only play one tone at a
 * time, so a short single beep for "lock" and another short single beep for
 * "line clear" ended up sounding almost identical and stepping on each
 * other. Line clears now play a short ascending run of distinct notes
 * instead - clearly different from the lock click, and combos add more
 * notes so bigger combos audibly sound bigger.
 */
class SoundEffects {
    private val toneGen: ToneGenerator? = try {
        ToneGenerator(AudioManager.STREAM_MUSIC, 75)
    } catch (e: RuntimeException) {
        null // some emulators/devices without an audio output can fail here
    }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    // Ascending DTMF tones - distinct pitches, clearly different from each other.
    private val arpeggio = intArrayOf(
        ToneGenerator.TONE_DTMF_5,
        ToneGenerator.TONE_DTMF_7,
        ToneGenerator.TONE_DTMF_9,
        ToneGenerator.TONE_DTMF_S,
        ToneGenerator.TONE_DTMF_P
    )

    fun rotate() = play(ToneGenerator.TONE_PROP_ACK, 25)

    fun lock() = play(ToneGenerator.TONE_PROP_NACK, 30)

    /** [combo] is the resulting combo count (1 = first clear, 2 = second in a row, ...). */
    fun lineClear(combo: Int) {
        val noteCount = (1 + combo).coerceIn(2, arpeggio.size)
        scope.launch {
            for (i in 0 until noteCount) {
                play(arpeggio[i], 90)
                delay(70L)
            }
        }
    }

    fun gameOver() = play(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 400)

    private fun play(tone: Int, durationMs: Int) {
        toneGen?.startTone(tone, durationMs)
    }

    fun release() {
        toneGen?.release()
        scope.cancel()
    }
}
