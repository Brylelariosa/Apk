# The native library looks these up by name through JNI.
-keep class com.rustforge.studio.bridge.NativeBridge { *; }
-keepclasseswithmembernames class * {
    native <methods>;
}
