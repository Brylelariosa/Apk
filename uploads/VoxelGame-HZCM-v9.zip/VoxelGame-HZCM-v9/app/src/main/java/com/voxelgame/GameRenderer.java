package com.voxelgame;

import android.opengl.GLSurfaceView;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class GameRenderer implements GLSurfaceView.Renderer {

    static {
        System.loadLibrary("voxelgame");
    }

    // Set before the surface is created to apply a saved render distance.
    volatile int initialRenderDistance = 7;

    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        nativeInit();
        // Apply the saved render distance immediately after init
        nativeSetRenderDistance(initialRenderDistance);
    }

    @Override
    public void onSurfaceChanged(GL10 gl, int width, int height) {
        nativeResize(width, height);
    }

    @Override
    public void onDrawFrame(GL10 gl) {
        nativeRender();
    }

    // ── JNI declarations ──────────────────────────────────────────────────────
    public native void nativeInit();
    public native void nativeResize(int width, int height);
    public native void nativeRender();
    public native void nativeSetRenderDistance(int renderRadius);
}
