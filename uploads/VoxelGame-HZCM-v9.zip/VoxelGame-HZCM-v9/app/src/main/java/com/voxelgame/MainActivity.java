package com.voxelgame;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private static final String PREFS_NAME  = "VoxelGamePrefs";
    private static final String KEY_RENDER  = "render_distance";
    private static final int    DEFAULT_RD  = 7;

    private GameSurfaceView surfaceView;
    private GameRenderer    renderer;      // reference for settings calls

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Keep screen on, fullscreen immersive
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        );

        FrameLayout root = new FrameLayout(this);

        // GL surface — pass saved render distance so it's applied on init
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        int savedRd = prefs.getInt(KEY_RENDER, DEFAULT_RD);
        surfaceView = new GameSurfaceView(this, savedRd);
        root.addView(surfaceView,
                new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT,
                        FrameLayout.LayoutParams.MATCH_PARENT));

        // Transparent joystick overlay
        JoystickOverlay overlay = new JoystickOverlay(this);
        root.addView(overlay,
                new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT,
                        FrameLayout.LayoutParams.MATCH_PARENT));
        surfaceView.setJoystickOverlay(overlay);

        // ── Settings gear button (top-right) ──────────────────────────────────
        Button settingsBtn = new Button(this);
        settingsBtn.setText("⚙");
        settingsBtn.setTextSize(20f);
        settingsBtn.setAlpha(0.65f);
        settingsBtn.setBackground(null);
        settingsBtn.setOnClickListener(v -> showSettingsDialog());

        FrameLayout.LayoutParams gearParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT);
        gearParams.gravity = Gravity.TOP | Gravity.END;
        gearParams.topMargin  = 16;
        gearParams.rightMargin = 16;
        root.addView(settingsBtn, gearParams);

        setContentView(root);
    }

    // ── Settings dialog ───────────────────────────────────────────────────────
    private void showSettingsDialog() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        int currentRd = prefs.getInt(KEY_RENDER, DEFAULT_RD);

        // Build layout
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(60, 40, 60, 20);

        TextView label = new TextView(this);
        label.setText("Render Distance (chunks, 1–32)");
        label.setTextSize(15f);
        layout.addView(label);

        EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        input.setText(String.valueOf(currentRd));
        input.setSelectAllOnFocus(true);
        layout.addView(input);

        new AlertDialog.Builder(this)
                .setTitle("Settings")
                .setView(layout)
                .setPositiveButton("Apply", (dialog, which) -> {
                    String txt = input.getText().toString().trim();
                    if (txt.isEmpty()) return;
                    int rd;
                    try { rd = Integer.parseInt(txt); }
                    catch (NumberFormatException e) {
                        Toast.makeText(this, "Invalid number", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (rd < 1 || rd > 32) {
                        Toast.makeText(this, "Must be 1–32", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    // Save preference
                    prefs.edit().putInt(KEY_RENDER, rd).apply();
                    // Push to native — must run on GL thread
                    final int finalRd = rd;
                    surfaceView.queueEvent(() ->
                            surfaceView.getRenderer().nativeSetRenderDistance(finalRd));
                    Toast.makeText(this, "Render distance set to " + rd, Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        surfaceView.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        surfaceView.onPause();
    }
}
