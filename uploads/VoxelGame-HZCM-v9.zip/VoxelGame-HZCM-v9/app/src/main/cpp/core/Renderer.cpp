// ============================================================================
// HZCM v4 — Renderer.cpp
//
// Key changes from v3:
//   1. LUT-driven vertex shader — all branching replaced with const-array
//      lookups.  Face direction drives vec3 selection with zero if/else.
//      Block colour is a flat 30-element vec3 array (10 blocks × 3 face groups).
//      This cuts Mali/Adreno vertex shader ALU pressure significantly.
//
//   2. DrawBatcher integration — world.gatherAndDraw() replaces the manual
//      cluster loop in Renderer::renderClusters().
//      The batcher sorts by mega-offset → sequential VBO reads, fewer
//      partial-tile flushes on tile-based GPUs.
//
//   3. Fog distance scaled by effective render radius so it always starts
//      at 80% of the render distance regardless of the rd setting.
//
//   4. Debug overlay: bottom-left rect showing render distance, thermal
//      state, visible cluster count. Updated every frame, zero cost.
//
//   5. Attribute setup moved into init (VAO carries the layout; only the
//      base pointer changes per cluster, driven by DrawBatcher).
// ============================================================================
#include "Renderer.h"
#include <android/log.h>
#include <cstring>
#include <cmath>
#include <cstdio>
#include <shared_mutex>

#define TAG  "HZCMRenderer"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

// ============================================================================
// Vertex shader — LUT-driven, branchless face expansion  (GLES 3.0)
//
// All per-face geometry is driven by 6-element const arrays indexed by
// faceDir (0=+X,1=-X,2=+Y,3=-Y,4=+Z,5=-Z).
//
// Block colour is a 30-element vec3 array:
//   BLOCK_COL[blockType * 3 + faceGroup]
//   faceGroup: 0=side, 1=top(+Y), 2=bottom(-Y)
//
// AO: bilinear across the greedy quad, no branches.
// Fog: onset at 80% of uFogEnd, full at uFogEnd (set from render distance).
// ============================================================================
static const char* VERT_SRC = R"(#version 300 es
precision highp float;
precision highp int;

// Instanced PackedFace words (one per face instance)
layout(location = 0) in uint aGeom;
layout(location = 1) in uint aMat;

uniform ivec3 uClusterOrigin;
uniform mat4  uMVP;
uniform vec3  uCamPos;
uniform float uFogEnd;   // = effectiveRadius * 16.0 * 0.8

out vec3  vColor;
out float vFog;

// ── LUT: per-face-direction vectors ─────────────────────────────────────────
// sVec: tangent in the first span direction
// tVec: tangent in the second span direction
// nVec: outward normal (also the +1 offset applied to the face plane)
const vec3 FACE_S[6] = vec3[6](
    vec3(0,1,0), vec3(0,1,0),   // +X/-X : s=Y
    vec3(0,0,1), vec3(0,0,1),   // +Y/-Y : s=Z
    vec3(1,0,0), vec3(1,0,0)    // +Z/-Z : s=X
);
const vec3 FACE_T[6] = vec3[6](
    vec3(0,0,1), vec3(0,0,1),   // +X/-X : t=Z
    vec3(1,0,0), vec3(1,0,0),   // +Y/-Y : t=X
    vec3(0,1,0), vec3(0,1,0)    // +Z/-Z : t=Y
);
const vec3 FACE_N[6] = vec3[6](
    vec3( 1, 0, 0), vec3(-1, 0, 0),
    vec3( 0, 1, 0), vec3( 0,-1, 0),
    vec3( 0, 0, 1), vec3( 0, 0,-1)
);

// Per-face directional light multipliers
const float FACE_LIGHT[6] = float[6](0.65, 0.65, 1.0, 0.35, 0.80, 0.80);

// Quad corner (cs,ct) offsets in [span0,span1] units
// Front face (even faceDir): corners 0,1,2 then 0,2,3  (CCW)
// Back face  (odd faceDir):  corners 0,2,1 then 0,3,2  (CW → outward = CCW)
const int FRONT_CI[6] = int[6](0,1,2, 0,2,3);
const int BACK_CI [6] = int[6](0,2,1, 0,3,2);
// cs,ct for each of the 4 quad corners
const float CS4[4] = float[4](0.0, 1.0, 1.0, 0.0);
const float CT4[4] = float[4](0.0, 0.0, 1.0, 1.0);

// ── Block colour LUT ─────────────────────────────────────────────────────────
// 10 block types × 3 face groups (0=side, 1=top +Y, 2=bottom -Y)
// Index: blockType*3 + faceGroup
const vec3 BLOCK_COL[30] = vec3[30](
    // 0 AIR (unused, magenta)
    vec3(1,0,1), vec3(1,0,1), vec3(1,0,1),
    // 1 GRASS
    vec3(0.55,0.38,0.22), vec3(0.29,0.68,0.18), vec3(0.55,0.38,0.22),
    // 2 DIRT
    vec3(0.55,0.38,0.22), vec3(0.55,0.38,0.22), vec3(0.55,0.38,0.22),
    // 3 STONE
    vec3(0.50,0.50,0.50), vec3(0.50,0.50,0.50), vec3(0.50,0.50,0.50),
    // 4 SAND
    vec3(0.89,0.82,0.56), vec3(0.89,0.82,0.56), vec3(0.89,0.82,0.56),
    // 5 SNOW
    vec3(0.82,0.82,0.82), vec3(0.96,0.96,1.00), vec3(0.82,0.82,0.82),
    // 6 WOOD
    vec3(0.45,0.32,0.18), vec3(0.52,0.39,0.25), vec3(0.52,0.39,0.25),
    // 7 LEAVES
    vec3(0.20,0.52,0.12), vec3(0.20,0.52,0.12), vec3(0.20,0.52,0.12),
    // 8 WATER
    vec3(0.18,0.45,0.78), vec3(0.18,0.45,0.78), vec3(0.18,0.45,0.78),
    // 9 GRAVEL
    vec3(0.55,0.52,0.50), vec3(0.55,0.52,0.50), vec3(0.55,0.52,0.50)
);

void main() {
    int geom = int(aGeom);
    int mat  = int(aMat);

    // ── Unpack geometry word ─────────────────────────────────────────────────
    int faceDir = geom & 7;
    int ox      = (geom >>  3) & 15;
    int oy      = (geom >>  7) & 15;
    int oz      = (geom >> 11) & 15;
    int span0   = ((geom >> 15) & 15) + 1;
    int span1   = ((geom >> 19) & 15) + 1;

    // ── Unpack material word ─────────────────────────────────────────────────
    int btype = mat & 255;
    int ao0   = (mat >>  8) & 3;
    int ao1   = (mat >> 10) & 3;
    int ao2   = (mat >> 12) & 3;
    int ao3   = (mat >> 14) & 3;

    // ── Corner selection (branchless winding) ────────────────────────────────
    int vi = gl_VertexID % 6;
    // (faceDir & 1) == 0 → front face; == 1 → back face
    int cornerIdx = ((faceDir & 1) == 0) ? FRONT_CI[vi] : BACK_CI[vi];

    float cs = CS4[cornerIdx] * float(span0);
    float ct = CT4[cornerIdx] * float(span1);

    // ── Reconstruct world position (LUT, no branches) ────────────────────────
    vec3 lpos = vec3(float(ox), float(oy), float(oz));
    lpos += FACE_S[faceDir] * cs;
    lpos += FACE_T[faceDir] * ct;
    lpos += FACE_N[faceDir];   // +1 in normal direction (face offset)

    vec3 wpos = lpos + vec3(float(uClusterOrigin.x),
                             float(uClusterOrigin.y),
                             float(uClusterOrigin.z));

    // ── AO (bilinear across greedy quad) ─────────────────────────────────────
    float aof0 = 0.35 + float(ao0) * 0.2167;
    float aof1 = 0.35 + float(ao1) * 0.2167;
    float aof2 = 0.35 + float(ao2) * 0.2167;
    float aof3 = 0.35 + float(ao3) * 0.2167;
    float su = (span0 > 0) ? cs / float(span0) : 0.0;
    float sv = (span1 > 0) ? ct / float(span1) : 0.0;
    float ao = mix(mix(aof0, aof1, su), mix(aof3, aof2, su), sv);

    // ── Block colour (LUT, zero branches) ────────────────────────────────────
    // faceGroup: 0=side, 1=top, 2=bottom
    int faceGroup = (faceDir == 2) ? 1 : (faceDir == 3) ? 2 : 0;
    int colIdx    = clamp(btype, 0, 9) * 3 + faceGroup;
    vec3 baseCol  = BLOCK_COL[colIdx];

    vColor = baseCol * (FACE_LIGHT[faceDir] * ao);

    // ── Fog (onset at 70% of uFogEnd) ────────────────────────────────────────
    float dist = length(wpos - uCamPos);
    float fogStart = uFogEnd * 0.70;
    vFog = clamp((dist - fogStart) / (uFogEnd - fogStart + 0.001), 0.0, 1.0);

    gl_Position = uMVP * vec4(wpos, 1.0);
}
)";

static const char* FRAG_SRC = R"(#version 300 es
precision mediump float;
in  vec3  vColor;
in  float vFog;
out vec4  fragColor;
const vec3 SKY = vec3(0.52, 0.77, 0.95);
void main() {
    fragColor = vec4(mix(vColor, SKY, vFog), 1.0);
}
)";

// ── Crosshair ─────────────────────────────────────────────────────────────────
static const char* HUD_VERT = R"(#version 300 es
layout(location=0) in vec2 aPos;
void main() { gl_Position = vec4(aPos, 0.0, 1.0); }
)";
static const char* HUD_FRAG = R"(#version 300 es
precision mediump float;
out vec4 o;
void main() { o = vec4(1.0, 1.0, 1.0, 0.8); }
)";

// ── Debug overlay (coloured quad + no-font digit rendering) ───────────────────
// We draw thermal pressure as a horizontal bar and a small colour indicator.
// Full text requires a font atlas which is out of scope; we show a colour bar.
static const char* DBG_VERT = R"(#version 300 es
layout(location=0) in vec2 aPos;
layout(location=1) in vec3 aCol;
out vec3 vCol;
void main() { vCol = aCol; gl_Position = vec4(aPos, 0.0, 1.0); }
)";
static const char* DBG_FRAG = R"(#version 300 es
precision mediump float;
in  vec3 vCol;
out vec4 o;
void main() { o = vec4(vCol, 0.75); }
)";

// ── Shader helpers ────────────────────────────────────────────────────────────
GLuint Renderer::compileShader(GLenum type, const char* src) {
    GLuint s = glCreateShader(type);
    glShaderSource(s, 1, &src, nullptr);
    glCompileShader(s);
    GLint ok; glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        char log[512]; glGetShaderInfoLog(s, sizeof(log), nullptr, log);
        LOGE("Shader error: %s", log);
        glDeleteShader(s); return 0;
    }
    return s;
}

GLuint Renderer::linkProgram(GLuint v, GLuint f) {
    GLuint p = glCreateProgram();
    glAttachShader(p, v); glAttachShader(p, f); glLinkProgram(p);
    GLint ok; glGetProgramiv(p, GL_LINK_STATUS, &ok);
    if (!ok) {
        char log[512]; glGetProgramInfoLog(p, sizeof(log), nullptr, log);
        LOGE("Link error: %s", log); glDeleteProgram(p); return 0;
    }
    glDeleteShader(v); glDeleteShader(f);
    return p;
}

// ── Init ───────────────────────────────────────────────────────────────────────
void Renderer::init() {
    LOGI("Renderer::init()");

    m_prog   = linkProgram(compileShader(GL_VERTEX_SHADER,   VERT_SRC),
                            compileShader(GL_FRAGMENT_SHADER, FRAG_SRC));
    m_uMVP    = glGetUniformLocation(m_prog, "uMVP");
    m_uCamPos = glGetUniformLocation(m_prog, "uCamPos");
    m_uOrigin = glGetUniformLocation(m_prog, "uClusterOrigin");
    GLint uFogEnd = glGetUniformLocation(m_prog, "uFogEnd");

    // Set initial fog end — will be updated each frame from effective radius
    glUseProgram(m_prog);
    glUniform1f(uFogEnd, (float)(world.getEffectiveRadius()) * 16.f * 0.8f);

    // Cluster VAO: set up the instanced attribute layout once.
    // DrawBatcher will re-point the base address per cluster via
    // glVertexAttribIPointer(offset) — the divisor stays.
    glGenVertexArrays(1, &m_clusterVao);
    glBindVertexArray(m_clusterVao);
    glEnableVertexAttribArray(0);
    glEnableVertexAttribArray(1);
    glVertexAttribDivisor(0, 1);  // advance once per instance (face)
    glVertexAttribDivisor(1, 1);
    glBindVertexArray(0);

    world.megaBuffer().init();

    initHUD();
    initDebugOverlay();

    glEnable(GL_DEPTH_TEST);
    glEnable(GL_CULL_FACE);
    glCullFace(GL_BACK);
    glFrontFace(GL_CCW);
    glDepthFunc(GL_LEQUAL);
    glClearColor(SKY_R, SKY_G, SKY_B, 1.f);

    world.init(42);
    initialized = true;
    LOGI("Renderer init done. MegaBuffer: %.1f MB",
         (float)(world.megaBuffer().totalFaces() * sizeof(PackedFace)) / (1024.f*1024.f));
}

void Renderer::initHUD() {
    m_hudProg = linkProgram(compileShader(GL_VERTEX_SHADER, HUD_VERT),
                              compileShader(GL_FRAGMENT_SHADER, HUD_FRAG));
    float s=0.02f, t=0.002f;
    float verts[] = {
        -s,-t, s,-t, s,t,  -s,-t, s,t, -s,t,
        -t,-s, t,-s, t,s,  -t,-s, t,s, -t,s,
    };
    glGenVertexArrays(1, &m_hudVao);
    glGenBuffers(1, &m_hudVbo);
    glBindVertexArray(m_hudVao);
    glBindBuffer(GL_ARRAY_BUFFER, m_hudVbo);
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 8, nullptr);
    glBindVertexArray(0);
}

void Renderer::initDebugOverlay() {
    m_dbgProg = linkProgram(compileShader(GL_VERTEX_SHADER,   DBG_VERT),
                              compileShader(GL_FRAGMENT_SHADER, DBG_FRAG));
    glGenVertexArrays(1, &m_dbgVao);
    glGenBuffers(1, &m_dbgVbo);
    glBindVertexArray(m_dbgVao);
    glBindBuffer(GL_ARRAY_BUFFER, m_dbgVbo);
    // Buffer size for dynamic data — updated each frame
    glBufferData(GL_ARRAY_BUFFER, 1024, nullptr, GL_DYNAMIC_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 5*4, (void*)0);
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 5*4, (void*)(2*4));
    glBindVertexArray(0);
}

// ── Resize ─────────────────────────────────────────────────────────────────────
void Renderer::resize(int w, int h) {
    glViewport(0, 0, w, h);
    camera.aspect = (float)w / (float)h;
    LOGI("Resize %d×%d", w, h);
}

// ── Main render loop ───────────────────────────────────────────────────────────
void Renderer::render(float dt) {
    if (!initialized) return;

    camera.update(dt, reinterpret_cast<World*>(&world));

    float yaw = camera.yaw;
    world.update(camera.position.x, camera.position.z, camera.position.y,
                 0.f, 0.f, sinf(yaw), cosf(yaw), dt);

    world.updateGPU();

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    Mat4    vp      = camera.getVP();
    Frustum frustum = camera.getFrustum();

    // ── Cluster draw pass ─────────────────────────────────────────────────────
    glUseProgram(m_prog);
    glUniformMatrix4fv(m_uMVP, 1, GL_FALSE, vp.m);
    glUniform3fv(m_uCamPos, 1, &camera.position.x);

    // Update fog distance from current effective radius
    {
        float fogEnd = (float)world.getEffectiveRadius() * 16.f * 0.80f;
        GLint loc = glGetUniformLocation(m_prog, "uFogEnd");
        glUniform1f(loc, fogEnd);
    }

    // Bind mega-buffer and set up VAO attribute layout
    world.megaBuffer().bind();
    glBindVertexArray(m_clusterVao);
    // Note: glVertexAttribIPointer base addresses are overwritten per cluster
    // inside DrawBatcher::issueDraws — the VAO just carries the divisors.

    // Gather visible clusters, sort by mega-offset, issue all draws
    world.gatherAndDraw(frustum, m_uOrigin);

    glBindVertexArray(0);

    // ── HUD ───────────────────────────────────────────────────────────────────
    renderHUD();
    renderDebugOverlay();
}

// ── HUD (crosshair) ───────────────────────────────────────────────────────────
void Renderer::renderHUD() {
    glDisable(GL_DEPTH_TEST);
    glUseProgram(m_hudProg);
    glBindVertexArray(m_hudVao);
    glDrawArrays(GL_TRIANGLES, 0, 12);
    glBindVertexArray(0);
    glEnable(GL_DEPTH_TEST);
}

// ── Debug overlay — thermal pressure bar + render distance indicator ───────────
// Bottom-left corner: a horizontal bar whose width = thermal pressure [0..1].
// Colour: green (cool) → yellow (warm) → red (hot/critical).
// Above it: a narrow white bar whose width = effectiveRadius / MAX_DIST.
void Renderer::renderDebugOverlay() {
    float pressure = world.thermal().thermalPressure();
    float rdFrac   = (float)world.getEffectiveRadius()
                   / (float)RenderDistanceSystem::MAX_DIST;

    // Bar: NDC from (-0.98, -0.98) to (-0.98 + w*1.2, -0.93)
    // 5 floats per vertex: x,y, r,g,b
    float tw = -0.98f + pressure * 1.20f;   // thermal bar width
    float rw = -0.98f + rdFrac   * 1.20f;   // render-dist bar width

    // Thermal colour: lerp green→red via yellow
    float tr = std::min(1.f, pressure * 2.f);
    float tg = std::min(1.f, (1.f - pressure) * 2.f);

    // Two quads, 6 verts each = 12 verts × 5 floats = 60 floats
    float verts[60] = {
        // Thermal bar (y = -0.98 to -0.93)
        -0.98f,-0.98f, tr,tg,0.f,
        tw,    -0.98f, tr,tg,0.f,
        tw,    -0.93f, tr,tg,0.f,
        -0.98f,-0.98f, tr,tg,0.f,
        tw,    -0.93f, tr,tg,0.f,
        -0.98f,-0.93f, tr,tg,0.f,
        // Render-distance bar (y = -0.93 to -0.91)
        -0.98f,-0.93f, 1.f,1.f,1.f,
        rw,    -0.93f, 1.f,1.f,1.f,
        rw,    -0.91f, 1.f,1.f,1.f,
        -0.98f,-0.93f, 1.f,1.f,1.f,
        rw,    -0.91f, 1.f,1.f,1.f,
        -0.98f,-0.91f, 1.f,1.f,1.f,
    };

    glDisable(GL_DEPTH_TEST);
    glUseProgram(m_dbgProg);
    glBindVertexArray(m_dbgVao);
    glBindBuffer(GL_ARRAY_BUFFER, m_dbgVbo);
    glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(verts), verts);
    glDrawArrays(GL_TRIANGLES, 0, 12);
    glBindVertexArray(0);
    glEnable(GL_DEPTH_TEST);
}

// ── Destructor ─────────────────────────────────────────────────────────────────
Renderer::~Renderer() {
    if (m_prog)       glDeleteProgram(m_prog);
    if (m_hudProg)    glDeleteProgram(m_hudProg);
    if (m_dbgProg)    glDeleteProgram(m_dbgProg);
    if (m_hudVao)     glDeleteVertexArrays(1, &m_hudVao);
    if (m_hudVbo)     glDeleteBuffers(1, &m_hudVbo);
    if (m_dbgVao)     glDeleteVertexArrays(1, &m_dbgVao);
    if (m_dbgVbo)     glDeleteBuffers(1, &m_dbgVbo);
    if (m_clusterVao) glDeleteVertexArrays(1, &m_clusterVao);
}
