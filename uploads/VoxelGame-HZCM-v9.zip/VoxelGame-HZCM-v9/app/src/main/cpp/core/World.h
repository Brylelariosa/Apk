#pragma once
// ============================================================================
// HZCM v3 — World.h
// Infinite chunk streaming with cluster-level upload scheduling.
// ============================================================================
#include <unordered_map>
#include <memory>
#include <thread>
#include <vector>
#include <queue>
#include <mutex>
#include <shared_mutex>
#include <functional>
#include <set>
#include <atomic>

#include "Chunk.h"
#include "Noise.h"
#include "Math3D.h"
#include "hzcm/ClusterTypes.h"
#include "hzcm/MegaBuffer.h"
#include "hzcm/ThermalManager.h"
#include <condition_variable>
#include <climits>
#include "hzcm/StreamScheduler.h"

// ── Chunk key / hash (unchanged) ─────────────────────────────────────────────
struct ChunkKey {
    int cx, cz;
    bool operator==(const ChunkKey& o) const { return cx==o.cx && cz==o.cz; }
    bool operator< (const ChunkKey& o) const {
        return cx < o.cx || (cx == o.cx && cz < o.cz);
    }
};
struct ChunkKeyHash {
    size_t operator()(const ChunkKey& k) const {
        return (size_t)((uint32_t)k.cx * 2654435761u ^ (uint32_t)k.cz * 1234567891u);
    }
};

// ── Upload task: one cluster ready to go to GPU ───────────────────────────────
struct UploadTask {
    Chunk* chunk;
    int    ci;      // cluster index [0..CLUSTER_STACK)
};

// ─────────────────────────────────────────────────────────────────────────────
class World {
public:
    // Default render distance; can be changed at runtime via setRenderRadius()
    static constexpr int DEFAULT_RENDER_RADIUS = 7;
    static constexpr int DEFAULT_UNLOAD_RADIUS = 10;

    World();
    ~World();

    void init(int seed = 42);

    // Change render distance on the fly (forces a re-stream on next update).
    // unload radius is automatically set to renderRadius + 3.
    void setRenderRadius(int r);

    // ── GL-thread per-frame calls ────────────────────────────────────────────
    void update(float camX, float camZ, float velX, float velZ,
                float fwdX, float fwdZ, float dt);
    void updateGPU();     // drain upload queue → MegaBuffer
    void render(const Frustum& frustum);

    // ── Accessors ────────────────────────────────────────────────────────────
    uint8_t   getBlock(int wx, int wy, int wz) const;
    Chunk*    getChunk(int cx, int cz) const;  // caller must hold shared lock
    int       getChunkCount() const;
    // ── Renderer-facing chunk iterator ──────────────────────────────────────
    using ChunkMap = std::unordered_map<ChunkKey,
                         std::unique_ptr<Chunk>, ChunkKeyHash>;
    const ChunkMap&   chunksSnapshot() const { return m_chunks; }
    std::shared_mutex& chunksMutex()    const { return m_chunksMtx; }

    int       getVisibleCount() const { return m_lastVisible; }
    MegaBuffer& megaBuffer() { return m_mega; }

    // Exposed for Renderer to call glVertexAttribPointer once after bind
    static constexpr GLsizei FACE_STRIDE = sizeof(PackedFace); // 8 bytes

private:
    Noise           m_noise;
    MegaBuffer      m_mega;
    ThermalManager  m_thermal;
    StreamScheduler m_scheduler;

    mutable std::shared_mutex m_chunksMtx;
    std::unordered_map<ChunkKey, std::unique_ptr<Chunk>, ChunkKeyHash> m_chunks;
    std::set<ChunkKey> m_submitted;

    int m_renderRadius = DEFAULT_RENDER_RADIUS;
    int m_unloadRadius = DEFAULT_UNLOAD_RADIUS;

    int m_lastCamCX = INT_MIN, m_lastCamCZ = INT_MIN;
    mutable int m_lastVisible = 0;

    // ── Upload queue (worker→GL) ──────────────────────────────────────────────
    std::mutex              m_uploadMtx;
    std::vector<UploadTask> m_uploadQueue;

    // ── Worker thread pool ────────────────────────────────────────────────────
    struct Pool {
        std::queue<std::function<void()>> q;
        std::mutex                        mtx;
        std::condition_variable           cv;
        bool                              stop = false;
    } m_pool;

    std::vector<std::thread> m_workers;

    void workerLoop();
    void enqueueTask(std::function<void()> fn);

    void rebuildCluster(Chunk* chunk, int ci);
    void triggerNeighbourRemesh(int cx, int cz, int ci);

    // Release all GPU memory owned by a chunk's clusters
    void evictChunk(Chunk* chunk);
};
