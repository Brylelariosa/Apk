/*
 * link_timing.h — how long the HOST's emulated link transfers last, chosen per game.
 *
 * Why this exists (two-phone capture of 31 Oct 2026: The Legend of Zelda: A Link to the Past & Four Swords)
 * ---------------------------------------------------------------------------------------------------------
 * Smooth link (see SMOOTH LINK in mgba_jni.c) hides the Wi-Fi round trip by letting every cable transfer last
 * about as long as the round trip — roughly 4.5 ms of EMULATED time (LINK_STRETCH_MAX_US) instead of the 0.38 ms
 * a 115,200-baud cable needs. A game that only needs a packet to arrive within some number of frames never
 * notices (the cap was sized for a 16-word packet in ~6 frames: 16 x (4.5 + 0.8) ms = 85 ms = 5 frames).
 *
 * Four Swords' link-up handshake needs something else: how many words fit between two probes. Its master sends
 * the 0xFEFE probe every 2 frames (87-88 link ticks = ~33.4 ms of emulated time, in both captured logs) and the
 * slave re-aligns its receive buffer on each probe it sees, so one round — the probe plus a 12-halfword block —
 * must be complete before the next probe: 13 transfers in 33.4 ms, i.e. at most ~2.57 ms per transfer INCLUDING
 * the ~0.27 ms the ROM itself needs between two transfers. With ~4.5 ms transfers only 7 fit. The child then
 * recognised only every second probe, its receive windows were cut short by a probe arriving mid-block, no block
 * ever passed the game's checksum and the handshake looped until the game's own ~21 s timeout reset the port.
 * (The model "7 words per probe period" predicts all 485 child-side window starts in the capture; the ROM-side
 * protocol itself was decoded from the real cartridge by the Spuds0588/mgba-splitscreen project.)
 *
 * For such a game the cap is therefore lowered to LINK_STRETCH_COMPAT_MAX_US. At 1.5 ms a round is
 * 13 x (1.5 + 0.27) = ~23 ms of the 33.4 ms period (69%), which leaves slack for the ROM's own jitter. The price
 * is speed, not correctness: the host still waits one network round trip per transfer, so while the link is busy
 * the game runs at about (transfer + ROM gap) / round trip — roughly a third of real time on Wi-Fi instead of
 * ~78%. Overlapping the next request with the current wait (pre-sending) is the way to win that back; it is a
 * protocol change and is deliberately not part of this one (see KNOWN_LIMITATIONS.md).
 *
 * Which games: Auto recognises the cartridges listed in link_timing_known_game() by the title in the ROM header
 * (0xA0, 12 bytes). Settings -> Debug -> "Link timing" can force either profile for every game: "Smooth" (the
 * long transfers, as before) or "Compatible" (the short ones). Only the HOST's choice matters — the child
 * follows the host's spacing — and it is read once per link session, at nativeLinkStart().
 *
 * Pure C, no mGBA/JNI types, so it is unit-tested on the host (tools/native-link-test/test_link_timing.c).
 */
#ifndef LINK_TIMING_H
#define LINK_TIMING_H

#include <stddef.h>
#include <stdint.h>
#include <string.h>

/* Cap on the emulated duration of one host transfer, microseconds. */
#define LINK_STRETCH_MAX_US         4500u   /* Smooth: about what a Wi-Fi round trip needs (and 9,600 baud at the slowest) */
#define LINK_STRETCH_COMPAT_MAX_US  1500u   /* Compatible: keeps a 13-transfer round inside the 33.4 ms Four Swords probe period */

/* The user's choice (Settings -> Debug -> "Link timing"). Stored in the preferences and passed over JNI as a
 * plain int by LinkTiming.code (LinkTiming.kt) — the numbers are part of that contract, never renumber. */
enum {
    LINK_TIMING_AUTO   = 0,   /* decide per game from its ROM header */
    LINK_TIMING_SMOOTH = 1,   /* always LINK_STRETCH_MAX_US */
    LINK_TIMING_COMPAT = 2    /* always LINK_STRETCH_COMPAT_MAX_US */
};

/* ROM header: the 12-byte game title starts here (the 4-byte game code follows it). */
#define LINK_ROM_TITLE_OFFSET   0xA0u
#define LINK_ROM_TITLE_LEN      12u

typedef struct {
    int         mode;     /* the mode that was applied (an unknown value has become LINK_TIMING_AUTO) */
    uint32_t    cap_us;   /* the emulated-transfer-time cap for this session */
    const char *game;     /* the known game recognised in the ROM header, or NULL */
} LinkTiming;

/* The name of the known game whose link code needs the Compatible profile, or NULL.
 * [rom] = the cartridge image (only the first LINK_ROM_TITLE_OFFSET + LINK_ROM_TITLE_LEN bytes are read),
 * [rom_size] = how many bytes of it are valid. A title is matched on its leading characters. */
static inline const char *link_timing_known_game(const uint8_t *rom, size_t rom_size)
{
    static const struct { const char *title; const char *name; } k_games[] = {
        /* The Legend of Zelda: A Link to the Past & Four Swords — "GBAZELDA" at 0xA0 in a real USA dump (the
         * Spuds0588/mgba-splitscreen project identifies the cartridge the same way). */
        { "GBAZELDA", "Zelda: A Link to the Past & Four Swords" },
    };
    if (!rom || rom_size < LINK_ROM_TITLE_OFFSET + LINK_ROM_TITLE_LEN) return NULL;
    for (size_t i = 0; i < sizeof k_games / sizeof k_games[0]; i++) {
        if (memcmp(rom + LINK_ROM_TITLE_OFFSET, k_games[i].title, strlen(k_games[i].title)) == 0)
            return k_games[i].name;
    }
    return NULL;
}

/* Decides which cap applies to a link session. Unknown modes act as Auto. */
static inline LinkTiming link_timing_resolve(int mode, const uint8_t *rom, size_t rom_size)
{
    LinkTiming t;
    t.mode = (mode == LINK_TIMING_SMOOTH || mode == LINK_TIMING_COMPAT) ? mode : LINK_TIMING_AUTO;
    t.game = link_timing_known_game(rom, rom_size);
    if (t.mode == LINK_TIMING_SMOOTH)      t.cap_us = LINK_STRETCH_MAX_US;
    else if (t.mode == LINK_TIMING_COMPAT) t.cap_us = LINK_STRETCH_COMPAT_MAX_US;
    else                                   t.cap_us = t.game ? LINK_STRETCH_COMPAT_MAX_US : LINK_STRETCH_MAX_US;
    return t;
}

static inline const char *link_timing_mode_name(int mode)
{
    return mode == LINK_TIMING_SMOOTH ? "smooth" : mode == LINK_TIMING_COMPAT ? "compat" : "auto";
}

/* Copies the ROM's header title into [out] as printable text (anything else becomes '.'), NUL-terminated;
 * "" if the image is too short. For the log: a capture that says which title Auto saw settles any question
 * about why a profile was or was not picked. */
static inline void link_timing_rom_title(const uint8_t *rom, size_t rom_size, char out[LINK_ROM_TITLE_LEN + 1u])
{
    out[0] = '\0';
    if (!rom || rom_size < LINK_ROM_TITLE_OFFSET + LINK_ROM_TITLE_LEN) return;
    size_t n = 0;
    for (size_t i = 0; i < LINK_ROM_TITLE_LEN; i++) {
        const uint8_t c = rom[LINK_ROM_TITLE_OFFSET + i];
        if (c == 0) break;                                   /* NUL padding ends the title */
        out[n++] = (c >= 0x20 && c < 0x7F) ? (char)c : '.';
    }
    out[n] = '\0';
}

#endif /* LINK_TIMING_H */
