package com.mgba.android.link

/**
 * How long the HOST's emulated link transfers last — Settings → Debug → "Link timing".
 *
 * Smooth link hides the Wi-Fi round trip by letting every cable transfer last about as long as the round trip
 * (~4.5 ms of game time). Zelda: Four Swords' link-up counts transfers between its probes instead, and needs them
 * shorter (1.5 ms) — see `app/src/main/cpp/link_timing.h` for the numbers and for what the shorter transfers cost
 * (speed over Wi-Fi, not correctness). [AUTO] picks per game from the ROM header; the other two force one profile
 * for every game, as a safety net in either direction.
 *
 * Only the HOST's choice matters (the child follows the host's spacing), and it is read once per link session, in
 * `onLinkConnected()`, so a change applies from the next connection.
 *
 * The codes are the native `LINK_TIMING_*` constants in `link_timing.h`: they cross JNI as plain ints
 * (`EmulatorEngine.nativeLinkSetTimingMode`) and are what the preference stores, so they never change meaning.
 * `tools/link-timing-test` checks them against the header. Pure — no Android types.
 */
internal enum class LinkTiming(val code: Int, val label: String, val summary: String) {
    AUTO(0, "Auto (recommended)",
        "Short transfers for games that need them (Zelda: Four Swords), the faster long ones for everything else."),
    SMOOTH(1, "Smooth",
        "Always the long transfers: fastest over Wi-Fi, but Zelda: Four Swords cannot link up with them."),
    COMPAT(2, "Compatible",
        "Always the short transfers: links up for more games, but the game runs slower over Wi-Fi.");

    companion object {
        val DEFAULT: LinkTiming = AUTO

        /** The mode a stored or received [code] stands for; an unknown one (a corrupt preference, a value from a
         *  newer build) is [DEFAULT] — it must never stop a link from starting. */
        fun fromCode(code: Int): LinkTiming = values().firstOrNull { it.code == code } ?: DEFAULT
    }
}
