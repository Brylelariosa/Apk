"""Two-phone simulation of the Zelda: A Link to the Past & Four Swords link-up CADENCE through the real link code.

What it checks, and what it cannot: sim_dev.c's "Four Swords" section models the mechanism the 31 Oct 2026
capture showed breaking — the master restarts its round with a 0xFEFE probe every 2 frames, a round is 13 transfers,
and the slave re-aligns only on a probe that follows a complete round. The ROM is a MODEL built from that capture and
the Spuds0588/mgba-splitscreen decode of the cartridge; this shows what the host's transfer timing does to it (the
child's recognition of probes, whether rounds complete and validate), through the real driver / clock-tie / child
delivery code. It cannot say what the real cartridge does in every detail.

Timing argument of sim_dev: 0 = Auto, 1 = Smooth (force the long transfers), 2 = Compatible. In the Four Swords
model the simulated cartridge carries that game's header title, so Auto resolves to the Compatible cap."""
from sim_lib import run, check, finish

SMOOTH, AUTO = 1, 0

def ratio(a, b):
    return int(a) / max(1, int(b))

print("== F1. OLD timing (Smooth forced = 4.5 ms transfers), Wi-Fi-like 3 ms one-way (the capture: ~5.8 ms round trips)")
H, C = run("fs smooth", 10, 3, 1, smooth=1, fs=1, timing=SMOOTH)
if H:
    check(H['cap_us'] == '4500', f"the host's transfers are capped at {H['cap_us']} us (the old behaviour)")
    check(H['detected'] == '0' and H['ok_rounds'] == '0' and C['synced'] == '0', "the link never completes (reproduces the capture's endless handshake)")
    check(int(H['cut_rounds']) >= 50, f"the master's rounds are cut by the next probe ({H['cut_rounds']} times): they need 13 transfers, 7 fit")
    check(0.35 <= ratio(C['probes_recognized'], C['probes']) <= 0.65,
          f"the slave recognises only about every second probe ({C['probes_recognized']} of {C['probes']}) — the pattern in the capture's child log")
    check(C['valid_blocks'] == '0' and int(C['bad_blocks']) > 20, f"no block ever validates ({C['bad_blocks']} windows mixed two rounds)")
    check(55 <= int(H['speed_avg']) <= 100, f"...while the game ran at {H['speed_avg']}% speed (the capture: ~78%): fast, but not linked")

print("== F2. NEW timing (Auto -> Compatible for Four Swords = 1.5 ms transfers), same link")
H, C = run("fs auto", 10, 3, 1, smooth=1, fs=1, timing=AUTO)
if H:
    check(H['cap_us'] == '1500', f"Auto picks the Compatible cap for the Four Swords header ({H['cap_us']} us)")
    check(H['detected'] == '1' and C['synced'] == '1', "both sides link up")
    check(float(H['detected_at']) < 3.0 and float(C['synced_at']) < 3.0, f"...within {H['detected_at']} s (host) / {C['synced_at']} s (child)")
    check(int(H['rounds']) >= 50 and int(H['cut_rounds']) <= 1 and int(H['ok_rounds']) >= int(H['rounds']) - 1,
          f"every round completes before the next probe and the slave answers in the right slots ({H['ok_rounds']} of {H['rounds']}, {H['cut_rounds']} cut)")
    check(int(C['probes_recognized']) >= int(C['probes']) - 1, f"the slave recognises every probe ({C['probes_recognized']} of {C['probes']})")
    check(int(C['bad_blocks']) <= 1 and int(C['valid_blocks']) >= 50, f"and every block validates ({C['valid_blocks']} valid, {C['bad_blocks']} bad)")
    check(int(H['speed_avg']) >= 20, f"the price: the game runs at {H['speed_avg']}% speed while linked over Wi-Fi (one round trip per transfer; was ~71% when it could not link)")

print("== F3. NEW timing on a local link (0.15 ms one-way, both players on one phone): no loss of speed")
H, C = run("fs local", 8, 0.15, 1, smooth=1, fs=1, timing=AUTO)
if H:
    check(H['detected'] == '1' and C['synced'] == '1', "links up")
    check(int(H['ok_rounds']) >= int(H['rounds']) - 1 and H['cut_rounds'] == '0', f"every round completes ({H['ok_rounds']} of {H['rounds']})")
    check(int(H['speed_avg']) >= 80 and int(C['speed_avg']) >= 80, f"and the game keeps its speed: host {H['speed_avg']}%, child {C['speed_avg']}%")

print("== F4. NEW timing over a Bluetooth-like 15 ms one-way delay: links up, but a round trip per transfer makes it slow")
H, C = run("fs bt", 12, 15, 1, smooth=1, fs=1, timing=AUTO)
if H:
    check(H['detected'] == '1' and C['synced'] == '1', "still links up (the cadence is in emulated time, whatever the round trip)")
    check(int(H['cut_rounds']) == 0, f"no round is cut ({H['rounds']} rounds)")
    print(f"      (host speed {H['speed_avg']}% — a transfer costs a full ~31 ms round trip; Wi-Fi is the way to play this)")

finish()
