/* sim_dev — ONE simulated phone (host or child). Run two of them (run_sim.sh does) and they
 * talk over UDP on loopback, with an artificial one-way delay standing in for Wi-Fi/Bluetooth.
 *
 * What is real: the link code itself — link_sio_write_register(), the clock-tie tick, the
 * child's tick-driven delivery and hold, the mailbox, nativeLinkStart/Stop, nativeLinkChildExchange —
 * is the code extracted verbatim from app/src/main/cpp/mgba_jni.c (extract.py).
 * What is modelled:
 *   - the core: a real sorted timing queue, 280,896-cycle frames paced at ~59.7 fps (the audio
 *     clock), the game thread holding g_core_mutex while a frame runs;
 *   - the transport: a C re-implementation of LinkMultiplayer.kt's request/reply + the host's
 *     "stop waiting on a peer that isn't there" fast path;
 *   - the ROMs: a hypothesis, built from the two real captures W sent. The host sends a 16-word
 *     packet (0xFEFE, counter, complement, 0x2002, 0x4921, ...) back to back, polling SIOCNT; the
 *     child answers from an SIO ISR and — like the captured ROM — resets its Multi-Player hardware
 *     if a packet is not complete within 6 frames of ITS OWN clock. Once the child has seen a whole
 *     valid packet it replies with positional ACK words, and the host counts the link as detected
 *     only if all 16 ACKs come back in the right slots (so the per-transfer lock-step is exercised,
 *     not just "something arrived").
 * This does not prove what the real ROM does. It proves the code does what the fix claims, that it
 * cannot deadlock, and that the old behaviour reproduces the captured failure.
 *
 * Second ROM model (argument 12 = 1): the Four Swords link-up CADENCE — see the "Four Swords" section below.
 * It exists for one question: with the host's transfers as long as the Smooth cap makes them, can a handshake
 * round (13 transfers) fit between two of the master's probes (every 2 frames)? */
#define LINK_TEST_LOG
#include "link_test_stubs.h"
#include "../../app/src/main/cpp/link_mailbox.h"
#include "../../app/src/main/cpp/link_timing.h"
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <poll.h>
#include <signal.h>
#include <math.h>

/* ---- clocks / logging ---------------------------------------------------------------------- */
static double now_ms(void) { struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t); return t.tv_sec * 1000.0 + t.tv_nsec / 1e6; }
static double g_t0_ms;
static const char *g_role_name = "?";
static int g_verbose = 0;
#define MAX_SPEED 4096
static struct { double t; int speed; } g_speed[MAX_SPEED]; static int g_nspeed = 0;
void link_test_log(const char *level, const char *fmt, ...) {
    char buf[512]; va_list ap; va_start(ap, fmt); vsnprintf(buf, sizeof buf, fmt, ap); va_end(ap);
    if (!strncmp(buf, "STAT", 4)) {
        const char *p = strstr(buf, "speed=");
        if (p && g_nspeed < MAX_SPEED) { g_speed[g_nspeed].t = (now_ms() - g_t0_ms) / 1000.0; g_speed[g_nspeed].speed = atoi(p + 6); g_nspeed++; }
    }
    if (g_verbose || level[0] != 'I' || !strncmp(buf, "STAT", 4))
        fprintf(stderr, "[%s %7.3f] %s %s\n", g_role_name, (now_ms() - g_t0_ms) / 1000.0, level, buf);
}

/* ---- code under test ----------------------------------------------------------------------- */
#include "extracted_r1.c"
static void link_frame_prologue(JNIEnv *env);
#include "extracted_r2.c"
#include "extracted_r3.c"
#include "extracted_r4.c"

/* ---- the core ------------------------------------------------------------------------------ */
static struct GBA gba;
static int g_run = 1;   /* accessed with __atomic_* (stop flag shared with the child's network thread) */
static int g_irq_seen = 0;
static long g_frames = 0;
static bool g_is_host = false;

static bool multi_now(void) { return (gba.sio.rcnt & 0xC000) == 0 && (gba.sio.siocnt & 0x3000) == 0x2000; }
/* what GBASIOWriteSIOCNT / WriteRCNT do around our driver */
static void rom_write_send(uint16_t v) { if (multi_now()) link_sio_write_register(&g_link_driver.d, 0x12A, v); gba.memory.io[0x12A >> 1] = v; }
static void rom_write_siocnt(uint16_t v) {
    if ((v ^ gba.sio.siocnt) & 0x3000) gba.sio.siocnt = (uint16_t)(v & 0x3000);   /* mode switch happens first */
    uint16_t r = multi_now() ? link_sio_write_register(&g_link_driver.d, 0x128, v) : v;
    gba.sio.siocnt = r; gba.memory.io[0x128 >> 1] = r;
}
static void rom_write_rcnt(uint16_t v) {
    gba.sio.rcnt = v;
    if (multi_now()) link_sio_write_register(&g_link_driver.d, 0x134, v);
}

/* ---- ROM models ---------------------------------------------------------------------------- */
#define PKT_WORDS 16
#define TIMEOUT_FRAMES 6
static uint16_t host_word(int idx, uint16_t cnt) {
    static const uint16_t tail[PKT_WORDS] = { 0xFEFE, 0, 0, 0x2002, 0x4921, 0, 0, 0, 0, 0x0001, 0x0020, 0, 0, 0, 0, 0 };
    if (idx == 1) return (uint16_t)(0x4000 + cnt);
    if (idx == 2) return (uint16_t)(0x96BB - (0x4000 + cnt));
    return tail[idx];
}
static uint16_t ack_word(int k) { return (uint16_t)(0xA500 | k); }

/* host ROM (parent): polls SIOCNT, no IRQ — what the host capture showed (SIOCNT=0x208B, IRQ=0) */
static int  h_state = 0, h_idx = 0, h_cool = 0; static uint16_t h_cnt = 0x11;
static uint16_t h_reply[PKT_WORDS]; static bool h_waiting = false;
static bool g_host_detected = false; static double g_host_detected_at = -1; static long g_host_packets = 0, g_host_ok_packets = 0;
static long g_host_start_frame = 30;
static long h_last_pkt_frame = -1;
static void rom_step_host(void) {
    if (h_state == 0) {
        if (g_frames < g_host_start_frame) return;
        rom_write_rcnt(0x0000); rom_write_siocnt(0x2003);
        h_state = 1; return;
    }
    if (h_cool > 0) { h_cool--; return; }
    /* once the child has been detected the ROM is in its "connected" phase: one packet per frame,
     * started right after VBlank, then idle for the rest of the frame (frame-synchronous traffic) */
    if (g_host_detected && !h_waiting && h_idx == 0 && g_frames == h_last_pkt_frame) return;
    if (h_waiting) {
        if (gba.sio.siocnt & 0x0080) return;                      /* busy: poll */
        h_reply[h_idx++] = gba.memory.io[0x122 >> 1];             /* SIOMULTI1 */
        h_waiting = false; h_cool = 5;                            /* ~320 cycles of ROM code between transfers */
        if (h_idx == PKT_WORDS) {
            bool ok = true; for (int k = 0; k < PKT_WORDS; k++) if (h_reply[k] != ack_word(k)) ok = false;
            g_host_packets++;
            if (ok && !g_host_detected) { g_host_detected = true; g_host_detected_at = (now_ms() - g_t0_ms) / 1000.0; }
            if (ok) g_host_ok_packets++;
            h_idx = 0; h_cnt++;
        }
        return;
    }
    if (h_idx == 0) h_last_pkt_frame = g_frames;
    rom_write_send(host_word(h_idx, h_cnt));
    rom_write_siocnt((uint16_t)(gba.sio.siocnt | 0x0080));        /* read-modify-write, like the capture's 0x200B -> 0x208B */
    h_waiting = true;
}

/* child ROM: IRQ-driven; 6-frame deadline to complete a packet; positional ACKs once synced */
static bool c_enabled = false; static long g_child_enter_frame = 0;
static int c_rx_n = 0; static uint16_t c_rx[PKT_WORDS]; static int c_frames_since = 0;
static bool g_child_synced = false; static double g_child_synced_at = -1; static long g_child_reinits = 0, g_child_valid = 0, g_child_words = 0, g_child_reinits_after_sync = 0;
static void child_init(void) {
    rom_write_rcnt(0x0000);
    rom_write_siocnt(0x2003); rom_write_siocnt(0x2000);
    rom_write_send(0x0000);
    rom_write_siocnt((uint16_t)(gba.sio.siocnt | 0x4003));        /* RMW: enable the SIO IRQ, 115200 baud -> 0x601F once SD/SI/ID are reflected */
    c_rx_n = 0; c_frames_since = 0; g_child_synced = false;
}
static void rom_vblank_child(void) {
    if (!c_enabled) { if (g_frames >= g_child_enter_frame) { c_enabled = true; child_init(); } return; }
    if (c_rx_n > 0 || g_child_synced) c_frames_since++;
    if (c_frames_since > TIMEOUT_FRAMES) { g_child_reinits++; if (g_child_synced_at >= 0) g_child_reinits_after_sync++; child_init(); }
}
static bool packet_valid(void) {
    return c_rx[0] == 0xFEFE && c_rx[2] == (uint16_t)(0x96BB - c_rx[1]) && c_rx[1] >= 0x4000 && c_rx[1] < 0x5000
        && c_rx[3] == 0x2002 && c_rx[4] == 0x4921 && c_rx[9] == 1 && c_rx[10] == 0x20;
}
static void child_isr(void) {
    uint16_t w = gba.memory.io[0x120 >> 1];                        /* SIOMULTI0 = the host's word */
    g_child_words++;
    if (c_rx_n == 0) { if (w == 0xFEFE) { c_rx[c_rx_n++] = w; c_frames_since = 0; } }
    else c_rx[c_rx_n++] = w;
    if (c_rx_n == PKT_WORDS) {
        if (packet_valid()) { g_child_valid++; c_frames_since = 0; if (!g_child_synced) { g_child_synced = true; g_child_synced_at = (now_ms() - g_t0_ms) / 1000.0; } }
        c_rx_n = 0;
    }
    rom_write_send(g_child_synced ? ack_word(c_rx_n) : 0xFEFE);   /* stage the reply for the NEXT transfer */
}
static void rom_step_child(void) {
    if (!c_enabled) return;
    if (g_irq_count != g_irq_seen) { g_irq_seen = g_irq_count; child_isr(); }
}

/* ---- Four Swords link-up model (the 31 Oct 2026 two-phone capture + the Spuds0588/mgba-splitscreen decode of the ROM) ----
 * What this reproduces is the CADENCE, which is what the capture showed breaking:
 *   - the MASTER restarts its round with the 0xFEFE probe every 2 frames (a timer) and then sends the 12 words
 *     of its block back to back, polling SIOCNT, with ~0.27 ms of ROM code between two transfers. A round is
 *     therefore 13 transfers; if the next probe tick arrives first, the round is cut and the next one starts.
 *   - the SLAVE's SIO ISR re-aligns on a probe ONLY if its previous round is complete (recvIdx > 11); a probe
 *     that arrives earlier is stored as ordinary data. It stages sendPtr[sendIdx++] (sendIdx <= 11) as its next
 *     reply, sendIdx restarting at 0 on a recognised probe.
 *   - blocks are 12 halfwords [counter, checksum, 0x0020, 0xFFFF, 8 values] summing to 0xFFF1; the master
 *     accepts a round when the slave's 12 replies after the probe are the slave's block IN ORDER (alignment),
 *     the slave when the 12 words after a recognised probe form a valid block; two accepted rounds in a row =
 *     "linked".
 * With ~4.77 ms per transfer only 7 fit between two probes (the capture: the slave recognised every second
 * probe, every window mixed two rounds, nothing validated). This is a MODEL of that mechanism built from the
 * capture and the decode — it cannot say what the real cartridge does in every detail. */
#define FS_ROUND_WORDS   13          /* the probe + a 12-halfword block */
#define FS_BLOCK_WORDS   12
#define FS_PROBE_FRAMES  2
static int g_fs_model = 0;
static void fs_make_block(uint16_t out[FS_BLOCK_WORDS], uint16_t counter, uint16_t salt) {
    uint32_t sum = 0;
    out[0] = counter; out[2] = 0x0020; out[3] = 0xFFFF;
    for (int i = 0; i < 8; i++) out[4 + i] = (uint16_t)(salt * 0x0101u + (unsigned)i * 0x0111u + 0x0100u);
    for (int i = 0; i < FS_BLOCK_WORDS; i++) if (i != 1) sum += out[i];
    out[1] = (uint16_t)(0xFFF1u - sum);
}
static bool fs_block_valid(const uint16_t *w) {
    uint32_t sum = 0;
    for (int i = 0; i < FS_BLOCK_WORDS; i++) sum += w[i];
    return (uint16_t)sum == 0xFFF1u && w[2] == 0x0020 && w[3] == 0xFFFF;
}
static uint16_t f_cblock[FS_BLOCK_WORDS];                 /* the slave's block, known to both processes (deterministic) */

/* master */
static int f_started = 0, f_idx = FS_ROUND_WORDS, f_cur = 0, f_cool = 0, f_consec = 0;
static bool f_waiting = false, f_ignore = false;
static uint16_t f_reply[FS_ROUND_WORDS], f_cnt = 0x11, f_mblock[FS_BLOCK_WORDS];
static long f_last_tick = -1, f_rounds = 0, f_rounds_ok = 0, f_rounds_cut = 0;
static void fs_master_tick(void) {                         /* the 2-frame probe timer */
    if (f_idx > 0 && f_idx < FS_ROUND_WORDS) f_rounds_cut++;   /* the previous round did not finish before this probe */
    f_idx = 0;
    f_cnt++; fs_make_block(f_mblock, f_cnt, 0x11);
    if (f_waiting) f_ignore = true;                        /* the transfer in flight belongs to the old round */
}
static void rom_step_host_fs(void) {
    if (!f_started) {
        if (g_frames < g_host_start_frame) return;
        fs_make_block(f_cblock, 0x77, 0x33);
        rom_write_rcnt(0x0000); rom_write_siocnt(0x2003);
        f_started = 1; return;
    }
    if (g_frames != f_last_tick && (g_frames % FS_PROBE_FRAMES) == 0) { f_last_tick = g_frames; fs_master_tick(); }
    if (f_cool > 0) { f_cool--; return; }
    if (f_waiting) {
        if (gba.sio.siocnt & 0x0080) return;               /* busy: poll */
        const uint16_t rep = gba.memory.io[0x122 >> 1];    /* SIOMULTI1 */
        f_waiting = false; f_cool = 70;                    /* 70 x 64 cycles = ~0.27 ms of ROM code between transfers */
        if (f_ignore) { f_ignore = false; return; }
        f_reply[f_cur] = rep;
        if (f_cur == FS_ROUND_WORDS - 1) {                 /* the round is over: did the slave answer in the right slots? */
            f_rounds++;
            if (memcmp(&f_reply[1], f_cblock, sizeof f_cblock) == 0) { f_rounds_ok++; f_consec++; } else f_consec = 0;
            if (f_consec >= 2 && !g_host_detected) { g_host_detected = true; g_host_detected_at = (now_ms() - g_t0_ms) / 1000.0; }
        }
        return;
    }
    if (f_idx >= FS_ROUND_WORDS) return;                   /* round complete: idle until the next probe tick */
    f_cur = f_idx;
    rom_write_send(f_idx == 0 ? 0xFEFE : f_mblock[f_idx - 1]);
    f_idx++;
    rom_write_siocnt((uint16_t)(gba.sio.siocnt | 0x0080));
    f_waiting = true;
}

/* slave */
static int c_recv_idx = 12, c_send_idx = 0, c_consec = 0;
static uint16_t c_fs_recv[FS_ROUND_WORDS];
static long g_fs_probes = 0, g_fs_probes_recognized = 0, g_fs_blocks_valid = 0, g_fs_blocks_bad = 0;
static void child_isr_fs(void) {
    const uint16_t w = gba.memory.io[0x120 >> 1];          /* SIOMULTI0 = the master's word */
    g_child_words++;
    if (w == 0xFEFE) {
        g_fs_probes++;
        if (c_recv_idx > 11) { c_recv_idx = -1; c_send_idx = 0; g_fs_probes_recognized++; }   /* recognised only after a complete round */
    }
    if (c_recv_idx < 12) {
        c_fs_recv[++c_recv_idx] = w;
        if (c_recv_idx == 12) {                            /* probe + 12 words stored */
            if (fs_block_valid(&c_fs_recv[1])) {
                g_fs_blocks_valid++;
                if (++c_consec >= 2 && !g_child_synced) { g_child_synced = true; g_child_synced_at = (now_ms() - g_t0_ms) / 1000.0; }
            } else { g_fs_blocks_bad++; c_consec = 0; }
        }
    }
    rom_write_send(f_cblock[c_send_idx <= 11 ? c_send_idx : 11]);   /* stage the reply for the NEXT transfer */
    if (c_send_idx <= 11) c_send_idx++;
}
static void rom_vblank_child_fs(void) {
    if (!c_enabled && g_frames >= g_child_enter_frame) { c_enabled = true; fs_make_block(f_cblock, 0x77, 0x33); child_init(); c_recv_idx = 12; c_send_idx = 0; }
}
static void rom_step_child_fs(void) {
    if (!c_enabled) return;
    if (g_irq_count != g_irq_seen) { g_irq_seen = g_irq_count; child_isr_fs(); }
}

/* ---- transport (models LinkMultiplayer.kt) -------------------------------------------------- */
static int g_sock = -1; static struct sockaddr_in g_peer;
static int g_oneway_us = 3000;
static double g_loss = 0.0;
static uint8_t g_seq = 0;
static bool g_peer_ready = true, g_peer_notmulti = false; static int g_fail = 0; static double g_last_probe_ms = -1e9;
static long g_fast_skips = 0, g_xchg_ok = 0, g_xchg_fail = 0;
static int g_fastpath = 1;
#define NOT_MULTI_REPLY ((jint)(0xFFFFu | (LINK_RF_NOT_MULTI << 16)))

static void send_pkt(uint8_t type, uint8_t seq, uint32_t payload) {
    uint8_t b[8] = { 'G', 'K', type, seq, (uint8_t)payload, (uint8_t)(payload >> 8), (uint8_t)(payload >> 16), (uint8_t)(payload >> 24) };
    if (g_oneway_us) usleep((useconds_t)g_oneway_us);
    if (g_loss > 0.0 && (rand() / (double)RAND_MAX) < g_loss) return;     /* dropped in the air */
    sendto(g_sock, b, 8, 0, (struct sockaddr *)&g_peer, sizeof g_peer);
}
static int recv_pkt(uint8_t *type, uint8_t *seq, uint32_t *payload, int timeout_ms) {
    struct pollfd p = { g_sock, POLLIN, 0 };
    if (poll(&p, 1, timeout_ms) <= 0) return 0;
    uint8_t b[16]; ssize_t n = recvfrom(g_sock, b, sizeof b, 0, NULL, NULL);
    if (n < 8 || b[0] != 'G' || b[1] != 'K') return -1;
    *type = b[2]; *seq = b[3]; *payload = (uint32_t)b[4] | ((uint32_t)b[5] << 8) | ((uint32_t)b[6] << 16) | ((uint32_t)b[7] << 24);
    return 1;
}
static jint wifi_exchange(int data, int stamp) {
    uint8_t seq = ++g_seq;
    uint32_t payload = ((uint32_t)(stamp & 0xFFFF) << 16) | (uint32_t)(data & 0xFFFF);
    double t0 = now_ms(), last_send = -1e9;
    while (now_ms() - t0 < 150.0) {
        if (now_ms() - last_send >= 25.0) { send_pkt(1, seq, payload); last_send = now_ms(); }   /* WIFI_RESEND_MS */
        uint8_t ty, sq; uint32_t pl;
        if (recv_pkt(&ty, &sq, &pl, 5) == 1 && ty == 2 && sq == seq) return (jint)pl;
    }
    return -1;
}
/* LinkMultiplayer.jniExchangeData(): with the fast path for a peer that is absent / not in multi mode */
static jint host_hook(int data, int stamp) {
    if (g_fastpath && !g_peer_ready) {
        double now = now_ms();
        double interval = g_peer_notmulti ? 100.0 : 250.0;
        if (now - g_last_probe_ms < interval) { g_fast_skips++; return g_peer_notmulti ? NOT_MULTI_REPLY : -1; }
        g_last_probe_ms = now;
    }
    jint r = wifi_exchange(data, stamp);
    if (r == -1) { g_xchg_fail++; if (++g_fail >= 3) { g_peer_ready = false; g_peer_notmulti = false; } }
    else {
        g_xchg_ok++; g_fail = 0;
        if (((uint32_t)r >> 16) & LINK_RF_NOT_MULTI) { g_peer_ready = false; g_peer_notmulti = true; }
        else { g_peer_ready = true; g_peer_notmulti = false; }
    }
    return r;
}
/* ---- SMOOTH LINK transport (models LinkMultiplayer.jniExchangeBegin / jniExchangeEnd / jniLastRttUs) ----
 * Begin must NOT block for the one-way delay (a real UDP send returns at once), so outgoing host packets go
 * through a delay line: a thread that holds each packet until its due time. The child's replies keep using
 * send_pkt() (its own thread may sleep). */
typedef struct { double due_ms; uint8_t type, seq; uint32_t payload; int used; } DelayedPkt;
#define DELAYQ 64
static DelayedPkt g_dq[DELAYQ]; static pthread_mutex_t g_dq_mu = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t g_dq_cv = PTHREAD_COND_INITIALIZER; static int g_dq_run = 1;
static void raw_send(uint8_t type, uint8_t seq, uint32_t payload) {
    uint8_t b[8] = { 'G', 'K', type, seq, (uint8_t)payload, (uint8_t)(payload >> 8), (uint8_t)(payload >> 16), (uint8_t)(payload >> 24) };
    if (g_loss > 0.0 && (rand() / (double)RAND_MAX) < g_loss) return;
    sendto(g_sock, b, 8, 0, (struct sockaddr *)&g_peer, sizeof g_peer);
}
static void send_pkt_delayed(uint8_t type, uint8_t seq, uint32_t payload) {
    pthread_mutex_lock(&g_dq_mu);
    for (int i = 0; i < DELAYQ; i++) if (!g_dq[i].used) {
        g_dq[i] = (DelayedPkt){ now_ms() + g_oneway_us / 1000.0, type, seq, payload, 1 };
        break;
    }
    pthread_cond_signal(&g_dq_cv); pthread_mutex_unlock(&g_dq_mu);
}
static void *delay_thread(void *arg) {
    (void)arg;
    pthread_mutex_lock(&g_dq_mu);
    while (g_dq_run) {
        double best = 1e18; int bi = -1;
        for (int i = 0; i < DELAYQ; i++) if (g_dq[i].used && g_dq[i].due_ms < best) { best = g_dq[i].due_ms; bi = i; }
        if (bi < 0) { pthread_cond_wait(&g_dq_cv, &g_dq_mu); continue; }
        double wait = best - now_ms();
        if (wait > 0.05) { pthread_mutex_unlock(&g_dq_mu); usleep((useconds_t)(wait * 1000.0)); pthread_mutex_lock(&g_dq_mu); continue; }
        DelayedPkt d = g_dq[bi]; g_dq[bi].used = 0;
        pthread_mutex_unlock(&g_dq_mu); raw_send(d.type, d.seq, d.payload); pthread_mutex_lock(&g_dq_mu);
    }
    pthread_mutex_unlock(&g_dq_mu);
    return NULL;
}
static uint8_t g_inf_seq; static uint32_t g_inf_payload; static double g_inf_t0 = 0, g_inf_last_send = 0; static int g_inf_resent = 0, g_last_rtt_us = 0;
static jint smooth_begin(int data, int stamp) {
    if (g_fastpath && !g_peer_ready) {
        double now = now_ms();
        double interval = g_peer_notmulti ? 100.0 : 250.0;
        if (now - g_last_probe_ms < interval) { g_fast_skips++; return g_peer_notmulti ? NOT_MULTI_REPLY : -1; }
        g_last_probe_ms = now;
    }
    g_inf_seq = ++g_seq;
    g_inf_payload = ((uint32_t)(stamp & 0xFFFF) << 16) | (uint32_t)(data & 0xFFFF);
    g_inf_t0 = g_inf_last_send = now_ms(); g_inf_resent = 0;
    send_pkt_delayed(1, g_inf_seq, g_inf_payload);
    return (jint)0x80000000;
}
static double g_rtt_smooth_ms = 0.0;
static jint smooth_end(void) {
    jint result = -1;
    /* resend after ~2.5 round trips (8..25 ms): a lost packet should not cost a fixed 25 ms (see wifiEnd) */
    double resend_ms = g_rtt_smooth_ms > 0.0 ? 2.5 * g_rtt_smooth_ms + 3.0 : 25.0;
    if (resend_ms < 8.0) resend_ms = 8.0; if (resend_ms > 25.0) resend_ms = 25.0;
    while (now_ms() - g_inf_t0 < 150.0) {
        if (now_ms() - g_inf_last_send >= resend_ms) { send_pkt_delayed(1, g_inf_seq, g_inf_payload); g_inf_last_send = now_ms(); }
        uint8_t ty, sq; uint32_t pl;
        if (recv_pkt(&ty, &sq, &pl, 5) == 1 && ty == 2 && sq == g_inf_seq) { result = (jint)pl; g_last_rtt_us = (int)((now_ms() - g_inf_t0) * 1000.0);
            { double r = g_last_rtt_us / 1000.0; g_rtt_smooth_ms = g_rtt_smooth_ms > 0.0 ? (g_rtt_smooth_ms * 7.0 + r) / 8.0 : r; } break; }
    }
    if (result == -1) { g_xchg_fail++; if (++g_fail >= 3) { g_peer_ready = false; g_peer_notmulti = false; } }
    else {
        g_xchg_ok++; g_fail = 0;
        if (((uint32_t)result >> 16) & LINK_RF_NOT_MULTI) { g_peer_ready = false; g_peer_notmulti = true; }
        else { g_peer_ready = true; g_peer_notmulti = false; }
    }
    return result;
}
static jint smooth_rtt(void) { return g_last_rtt_us; }

static void *child_net_thread(void *arg) {
    (void)arg;
    uint8_t last_seq = 0; uint32_t last_reply = 0; bool have = false;
    while (__atomic_load_n(&g_run, __ATOMIC_RELAXED)) {
        uint8_t ty, sq; uint32_t pl;
        if (recv_pkt(&ty, &sq, &pl, 100) != 1 || ty != 1) continue;
        if (have && sq == last_seq) { send_pkt(2, sq, last_reply); continue; }
        jint rep = Java_com_mgba_android_EmulatorEngine_nativeLinkChildExchange(&g_env, NULL, (jint)(pl & 0xFFFF), (jint)((pl >> 16) & 0xFFFF));
        if (rep == -1) continue;                                   /* no answer: stay silent, the host times out */
        last_seq = sq; last_reply = (uint32_t)rep; have = true;
        send_pkt(2, sq, last_reply);
    }
    return NULL;
}

/* ---- frame loop ---------------------------------------------------------------------------- */
static void sim_run_frame(void) {
    for (int64_t done = 0; done < 280896; done += 64) {
        timing_advance(&gba, 64);
        if (g_is_host) { if (g_fs_model) rom_step_host_fs(); else rom_step_host(); }
        else           { if (g_fs_model) rom_step_child_fs(); else rom_step_child(); }
    }
    g_frames++;
    if (!g_is_host) { if (g_fs_model) rom_vblank_child_fs(); else rom_vblank_child(); }
}

int main(int argc, char **argv) {
    if (argc < 7) { fprintf(stderr, "usage: %s host|child myport peerport seconds oneway_ms sync(0|1) [child_enter_s] [fastpath 0|1] [verbose] [loss 0..1]"
                                    " [smooth 0|1] [fourswords 0|1] [timing 0=auto|1=smooth|2=compatible]\n", argv[0]); return 2; }
    g_is_host = !strcmp(argv[1], "host"); g_role_name = argv[1];
    int myport = atoi(argv[2]), peerport = atoi(argv[3]); double seconds = atof(argv[4]);
    g_oneway_us = (int)(atof(argv[5]) * 1000.0); int sync = atoi(argv[6]);
    double child_enter_s = argc > 7 ? atof(argv[7]) : 0.0;
    g_fastpath = argc > 8 ? atoi(argv[8]) : 1; g_verbose = argc > 9 ? atoi(argv[9]) : 0;
    g_loss = argc > 10 ? atof(argv[10]) : 0.0; srand((unsigned)(myport * 7919u + 13u));
    int smooth = argc > 11 ? atoi(argv[11]) : 0;
    g_fs_model = argc > 12 ? atoi(argv[12]) : 0;                  /* 1 = the Four Swords link-up model */
    int timing_mode = argc > 13 ? atoi(argv[13]) : LINK_TIMING_AUTO;
    g_child_enter_frame = (long)(child_enter_s * 59.7);
    signal(SIGPIPE, SIG_IGN);

    g_sock = socket(AF_INET, SOCK_DGRAM, 0);
    struct sockaddr_in me = { .sin_family = AF_INET, .sin_port = htons((uint16_t)myport) }; inet_pton(AF_INET, "127.0.0.1", &me.sin_addr);
    if (bind(g_sock, (struct sockaddr *)&me, sizeof me) != 0) { perror("bind"); return 2; }
    g_peer = (struct sockaddr_in){ .sin_family = AF_INET, .sin_port = htons((uint16_t)peerport) }; inet_pton(AF_INET, "127.0.0.1", &g_peer.sin_addr);

    g_t0_ms = now_ms();
    memset(&gba, 0, sizeof gba); gba.sio.rcnt = 0x8000; gba.sio.siocnt = 0;
    g_core_obj.board = &gba;
    g_xchg_hook = host_hook;
    /* the Four Swords model runs a "cartridge" with that game's header title, so Auto timing recognises it */
    static uint32_t fs_rom[64];
    if (g_fs_model) { memcpy((uint8_t *)fs_rom + LINK_ROM_TITLE_OFFSET, "GBAZELDA", 8); gba.memory.rom = fs_rom; gba.memory.romSize = sizeof fs_rom; }
    Java_com_mgba_android_EmulatorEngine_nativeLinkSetTimingMode(&g_env, NULL, timing_mode);
    pthread_t dthr; int have_dthr = 0;
    if (smooth && g_is_host) { g_begin_hook = smooth_begin; g_end_hook = smooth_end; g_rtt_hook = smooth_rtt; pthread_create(&dthr, NULL, delay_thread, NULL); have_dthr = 1; }
    /* let both processes bind before anyone transmits */
    usleep(300 * 1000);
    jboolean ok = Java_com_mgba_android_EmulatorEngine_nativeLinkStart(&g_env, NULL, (jobject)&g_dummy_class, g_is_host ? 1 : 0, (jboolean)sync, (jboolean)smooth);
    if (!ok) { fprintf(stderr, "nativeLinkStart failed\n"); return 2; }
    g_t0_ms = now_ms();

    pthread_t net; if (!g_is_host) pthread_create(&net, NULL, child_net_thread, NULL);

    double frame_ms = 1000.0 / 59.7, next = now_ms();
    double end = now_ms() + seconds * 1000.0;
    long frames_at_detect = 0; double t_at_detect = 0;
    while (now_ms() < end) {
        pthread_mutex_lock(&g_core_mutex);
        link_frame_prologue(&g_env);
        sim_run_frame();
        g_link_driver.env = NULL;
        pthread_mutex_unlock(&g_core_mutex);
        if (g_is_host && g_host_detected && !frames_at_detect) { frames_at_detect = g_frames; t_at_detect = now_ms(); }
        next += frame_ms;                                          /* audio pacing: absolute deadlines, bounded catch-up */
        double n = now_ms();
        if (n > next + 100.0) next = n;
        else if (n < next) usleep((useconds_t)((next - n) * 1000.0));
    }
    double elapsed = (now_ms() - g_t0_ms) / 1000.0;
    __atomic_store_n(&g_run, 0, __ATOMIC_RELAXED);
    Java_com_mgba_android_EmulatorEngine_nativeLinkStop(&g_env, NULL);
    if (have_dthr) { pthread_mutex_lock(&g_dq_mu); g_dq_run = 0; pthread_cond_signal(&g_dq_cv); pthread_mutex_unlock(&g_dq_mu); pthread_join(dthr, NULL); }
    if (!g_is_host) pthread_join(net, NULL);

    /* speed samples taken before the link was detected (the host's lag) */
    double det = g_is_host ? g_host_detected_at : g_child_synced_at; if (det < 0) det = elapsed;
    double sum = 0; int n = 0, minv = 1 << 30;
    for (int i = 0; i < g_nspeed; i++) if (g_speed[i].t > 1.5 && g_speed[i].t < det) { sum += g_speed[i].speed; n++; if (g_speed[i].speed < minv) minv = g_speed[i].speed; }
    if (g_fs_model) {
        double ssum = 0; int sn = 0;
        for (int i = 0; i < g_nspeed; i++) if (g_speed[i].t > 1.5) { ssum += g_speed[i].speed; sn++; }
        if (g_is_host)
            printf("RESULT role=host fs=1 detected=%d detected_at=%.2f rounds=%ld ok_rounds=%ld cut_rounds=%ld frames=%ld fps_avg=%.1f speed_avg=%d xchg_ok=%ld xchg_fail=%ld cap_us=%u\n",
                   g_host_detected, g_host_detected_at, f_rounds, f_rounds_ok, f_rounds_cut, g_frames, g_frames / elapsed, sn ? (int)(ssum / sn) : -1, g_xchg_ok, g_xchg_fail, (unsigned)g_link_stretch_cap_us);
        else
            printf("RESULT role=child fs=1 synced=%d synced_at=%.2f probes=%ld probes_recognized=%ld valid_blocks=%ld bad_blocks=%ld frames=%ld fps_avg=%.1f speed_avg=%d\n",
                   g_child_synced_at >= 0, g_child_synced_at, g_fs_probes, g_fs_probes_recognized, g_fs_blocks_valid, g_fs_blocks_bad, g_frames, g_frames / elapsed, sn ? (int)(ssum / sn) : -1);
        return 0;
    }
    if (g_is_host) {
        double fps_after = frames_at_detect ? (g_frames - frames_at_detect) / ((now_ms() - t_at_detect) / 1000.0) : 0.0;
        double fps_before = frames_at_detect ? frames_at_detect / g_host_detected_at : g_frames / elapsed;
        (void)fps_before;
        printf("RESULT role=host detected=%d detected_at=%.2f packets=%ld ok_packets=%ld frames=%ld fps_avg=%.1f fps_before_detect=%.1f speed_avg_before=%d speed_min_before=%d fps_after_detect=%.1f xchg_ok=%ld xchg_fail=%ld fast_skips=%ld\n",
               g_host_detected, g_host_detected_at, g_host_packets, g_host_ok_packets, g_frames, g_frames / elapsed, fps_before, n ? (int)(sum / n) : -1, n ? minv : -1, fps_after, g_xchg_ok, g_xchg_fail, g_fast_skips);
    } else {
        printf("RESULT role=child synced=%d synced_at=%.2f reinits=%ld reinits_after_sync=%ld valid_packets=%ld words=%ld frames=%ld fps_avg=%.1f speed_avg_before=%d\n",
               g_child_synced_at >= 0, g_child_synced_at, g_child_reinits, g_child_reinits_after_sync, g_child_valid, g_child_words, g_frames, g_frames / elapsed, n ? (int)(sum / n) : -1);
    }
    return 0;
}
