/* Host-side test of app/src/main/cpp/link_timing.h — which cap on the host's emulated transfer time a link
 * session gets (per game, from the ROM header, and from the "Link timing" setting). Pure C: the header is
 * included as it ships. The register-level behaviour (the cap really bounds the transfer in emulated cycles,
 * nativeLinkStart() applies it) is test_sio_regs.c's "LINK TIMING" sections.
 *
 * The numbers marked CAPTURE come from the two-phone log of 31 Oct 2026 (The Legend of Zelda: A Link to the
 * Past & Four Swords; host Infinix X675, child Itel A6610L): the master's FEFE probe every 87-88 link ticks of
 * 0.382 ms, 13 transfers per handshake round, ~4.77 ms per transfer with the old 4.5 ms cap. */
#include <limits.h>
#include <stdio.h>
#include <string.h>
#include "../../app/src/main/cpp/link_timing.h"

static int fails = 0;
#define CHECK(c, msg) do { if (c) printf("PASS  %s\n", msg); else { printf("FAIL  %s\n", msg); fails++; } } while (0)

#define FS_PROBE_PERIOD_US  33400u   /* CAPTURE: the master repeats its probe every 2 frames */
#define FS_ROUND_TRANSFERS  13u      /* CAPTURE / decoded handler: the probe + a 12-halfword block */
#define FS_ROM_GAP_US       270u     /* CAPTURE: the ROM's own time between two transfers */

/* Whole transfers that fit between two probes when each lasts [xfer_us] plus the ROM's own gap. */
static unsigned transfers_per_period(unsigned xfer_us) { return FS_PROBE_PERIOD_US / (xfer_us + FS_ROM_GAP_US); }

/* A cartridge image with a header: [title] at 0xA0, zero elsewhere. */
static void make_rom(uint8_t *rom, size_t size, const char *title)
{
    memset(rom, 0, size);
    if (title) memcpy(rom + LINK_ROM_TITLE_OFFSET, title, strlen(title));
}

int main(void)
{
    static uint8_t rom[0x200];

    printf("== constants: the numbers the Kotlin side and the preferences depend on\n");
    CHECK(LINK_TIMING_AUTO == 0 && LINK_TIMING_SMOOTH == 1 && LINK_TIMING_COMPAT == 2,
          "LINK_TIMING_AUTO/SMOOTH/COMPAT are 0/1/2 (stored in preferences, passed over JNI — never renumber)");
    CHECK(LINK_STRETCH_MAX_US == 4500u, "the Smooth cap is still 4500 us (what every game but Four Swords keeps)");
    CHECK(LINK_STRETCH_COMPAT_MAX_US < LINK_STRETCH_MAX_US, "the Compatible cap is shorter than the Smooth cap");
    CHECK(LINK_ROM_TITLE_OFFSET == 0xA0u && LINK_ROM_TITLE_LEN == 12u, "the ROM header title is 12 bytes at 0xA0");

    printf("== the Four Swords cadence: why the cap differs (the capture's numbers)\n");
    CHECK(transfers_per_period(LINK_STRETCH_MAX_US) == 7u,
          "Smooth cap: only 7 transfers fit between two 0xFEFE probes — the capture's measured cadence");
    CHECK(transfers_per_period(LINK_STRETCH_MAX_US) < FS_ROUND_TRANSFERS,
          "...fewer than the 13 a handshake round needs, so no round can ever complete (the capture: handshake never completed)");
    CHECK(transfers_per_period(LINK_STRETCH_COMPAT_MAX_US) >= FS_ROUND_TRANSFERS,
          "Compatible cap: a whole round fits between two probes");
    CHECK(FS_ROUND_TRANSFERS * (LINK_STRETCH_COMPAT_MAX_US + FS_ROM_GAP_US) * 4u <= FS_PROBE_PERIOD_US * 3u,
          "...using at most 75% of the period, so the ROM's own jitter cannot push a round into the next probe");
    {
        /* the longest cap that still keeps that 25% slack: raising LINK_STRETCH_COMPAT_MAX_US beyond it fails here */
        const unsigned longest = (FS_PROBE_PERIOD_US * 3u / 4u) / FS_ROUND_TRANSFERS - FS_ROM_GAP_US;
        CHECK(LINK_STRETCH_COMPAT_MAX_US <= longest, "the Compatible cap is no longer than the cadence allows (1,656 us with the capture's numbers)");
        printf("      (longest cap with 25%% slack: %u us; Compatible cap: %u us)\n", longest, (unsigned)LINK_STRETCH_COMPAT_MAX_US);
    }

    printf("== link_timing_known_game(): recognised by the ROM header title\n");
    make_rom(rom, sizeof rom, "GBAZELDA");
    CHECK(link_timing_known_game(rom, sizeof rom) != NULL, "\"GBAZELDA\" at 0xA0 is Four Swords");
    CHECK(link_timing_known_game(rom, 0xACu) != NULL, "...with exactly the 12 title bytes present (0xAC bytes) it is still read");
    CHECK(link_timing_known_game(rom, 0xABu) == NULL, "...one byte fewer and the header is not fully there: not recognised");
    CHECK(link_timing_known_game(rom, 0) == NULL && link_timing_known_game(NULL, sizeof rom) == NULL && link_timing_known_game(NULL, 0) == NULL,
          "an empty or missing image is not a known game");
    make_rom(rom, sizeof rom, "GBAZELDA");
    memcpy(rom + 0xA8, "2\0\0\0", 4);
    CHECK(link_timing_known_game(rom, sizeof rom) != NULL, "text after the title (a revision or regional variant) still matches: only the leading characters are compared");
    {
        const char *others[] = { "GBAZELD", "ZELDA", "gbazelda", "GBAZELDX", "POKEMON EMER", "GBAZ", "", "MARIOKART", "ZELDA MC" };
        int any = 0;
        for (size_t i = 0; i < sizeof others / sizeof others[0]; i++) {
            make_rom(rom, sizeof rom, others[i]);
            if (link_timing_known_game(rom, sizeof rom)) { any = 1; printf("      unexpectedly matched \"%s\"\n", others[i]); }
        }
        CHECK(!any, "near-misses and other games are not recognised (no case folding, no 4-letter prefix: a wrong match slows a game's link)");
    }
    make_rom(rom, sizeof rom, NULL);
    memcpy(rom + 0x10, "GBAZELDA", 8);          /* right text, wrong place */
    CHECK(link_timing_known_game(rom, sizeof rom) == NULL, "the title is only looked for at 0xA0");

    printf("== link_timing_resolve(): setting x game -> cap\n");
    {
        static uint8_t fs[0x100], other[0x100];
        make_rom(fs, sizeof fs, "GBAZELDA"); make_rom(other, sizeof other, "POKEMON EMER");
        LinkTiming t;
        t = link_timing_resolve(LINK_TIMING_AUTO, fs, sizeof fs);
        CHECK(t.cap_us == LINK_STRETCH_COMPAT_MAX_US && t.game && t.mode == LINK_TIMING_AUTO, "Auto + Four Swords -> Compatible cap, game named");
        t = link_timing_resolve(LINK_TIMING_AUTO, other, sizeof other);
        CHECK(t.cap_us == LINK_STRETCH_MAX_US && t.game == NULL && t.mode == LINK_TIMING_AUTO, "Auto + another game -> Smooth cap (as before this change)");
        t = link_timing_resolve(LINK_TIMING_AUTO, NULL, 0);
        CHECK(t.cap_us == LINK_STRETCH_MAX_US && t.game == NULL, "Auto + no ROM image -> Smooth cap");
        t = link_timing_resolve(LINK_TIMING_SMOOTH, fs, sizeof fs);
        CHECK(t.cap_us == LINK_STRETCH_MAX_US && t.game != NULL && t.mode == LINK_TIMING_SMOOTH, "Smooth + Four Swords -> Smooth cap (forced); the game is still recognised for the log");
        t = link_timing_resolve(LINK_TIMING_SMOOTH, other, sizeof other);
        CHECK(t.cap_us == LINK_STRETCH_MAX_US, "Smooth + another game -> Smooth cap");
        t = link_timing_resolve(LINK_TIMING_COMPAT, other, sizeof other);
        CHECK(t.cap_us == LINK_STRETCH_COMPAT_MAX_US && t.game == NULL && t.mode == LINK_TIMING_COMPAT, "Compatible + another game -> Compatible cap (forced)");
        t = link_timing_resolve(LINK_TIMING_COMPAT, NULL, 0);
        CHECK(t.cap_us == LINK_STRETCH_COMPAT_MAX_US, "Compatible needs no ROM image at all");
        const int bad[] = { -1, 3, 4, 77, 255, INT_MIN, INT_MAX };
        int ok = 1;
        for (size_t i = 0; i < sizeof bad / sizeof bad[0]; i++) {
            LinkTiming a = link_timing_resolve(bad[i], fs, sizeof fs), b = link_timing_resolve(bad[i], other, sizeof other);
            if (a.mode != LINK_TIMING_AUTO || a.cap_us != LINK_STRETCH_COMPAT_MAX_US || b.mode != LINK_TIMING_AUTO || b.cap_us != LINK_STRETCH_MAX_US) ok = 0;
        }
        CHECK(ok, "an unknown mode value (corrupt preference, newer build) acts as Auto");
    }

    printf("== link_timing_mode_name() / link_timing_rom_title(): the log lines\n");
    CHECK(!strcmp(link_timing_mode_name(LINK_TIMING_AUTO), "auto") && !strcmp(link_timing_mode_name(LINK_TIMING_SMOOTH), "smooth") &&
          !strcmp(link_timing_mode_name(LINK_TIMING_COMPAT), "compat") && !strcmp(link_timing_mode_name(42), "auto"), "mode names (unknown -> auto)");
    {
        char t[LINK_ROM_TITLE_LEN + 1u];
        make_rom(rom, sizeof rom, "GBAZELDA");
        link_timing_rom_title(rom, sizeof rom, t);
        CHECK(!strcmp(t, "GBAZELDA"), "the title is copied up to its NUL padding");
        make_rom(rom, sizeof rom, "ABCDEFGHIJKL");   /* all 12 bytes used, no NUL inside the title field... */
        memcpy(rom + 0xAC, "BPEE", 4);               /* ...and the 4-byte game code right behind it, as in a real header */
        memset(t, 'x', sizeof t);
        link_timing_rom_title(rom, sizeof rom, t);
        CHECK(!strcmp(t, "ABCDEFGHIJKL") && strlen(t) == 12, "a full 12-byte title is terminated inside the 13-byte buffer (ASan would catch an overrun)");
        make_rom(rom, sizeof rom, NULL);
        rom[0xA0] = 'A'; rom[0xA1] = 0x01; rom[0xA2] = 0xFF; rom[0xA3] = 'B';
        link_timing_rom_title(rom, sizeof rom, t);
        CHECK(!strcmp(t, "A..B"), "control and non-ASCII bytes become '.' (a log line must stay printable)");
        memset(t, 'x', sizeof t);
        link_timing_rom_title(rom, 0xABu, t);
        CHECK(t[0] == '\0', "a truncated image gives an empty title");
        memset(t, 'x', sizeof t);
        link_timing_rom_title(NULL, 0, t);
        CHECK(t[0] == '\0', "no image gives an empty title");
    }

    printf("\n%s (%d failure(s))\n", fails ? "FAILED" : "ALL PASSED", fails);
    return fails ? 1 : 0;
}
