# native-link-test

Host-side tests for the multiplayer code in `app/src/main/cpp/` — they need only `gcc` and `python3`.
`extract.py` cuts the **real** functions out of `mgba_jni.c` (so a test can't drift from the shipping code)
and the tests compile them against the tiny JNI/mGBA stand-ins in `link_test_stubs.h`.

| script | what it runs | time |
|---|---|---|
| `run.sh` | `test_mailbox.c` — the child's lock-step mailbox, under ASan+UBSan and ThreadSanitizer (a TSan report is shown in full and fails the script) | ~10 s |
| `run_regs.sh` | `test_sio_regs.c` — SIO register semantics, the clock-tie tick, the child's tick-driven delivery / hold / governor, `nativeLinkStart/Stop`, the per-session transfer-time cap; `test_log.c` — the real log-file code (format, rotation, concurrent writers); `test_link_timing.c` — the per-game link timing policy in `link_timing.h` | ~15 s |
| `run_sim.sh [all\|legacy\|fs]` | `sim_dev.c` ×2 — **two simulated phones** (separate processes running the real link code) joined by UDP with an artificial delay: old behaviour (reproduces the captured failure), new behaviour over Wi-Fi / poor Wi-Fi / Bluetooth-like delay, packet loss, a not-ready child, a frozen child (`run_sim.py`, scenarios 1-14, ~3 min); the Four Swords link-up cadence with the old and the new transfer timing (`run_sim_fs.py`, F1-F4, ~45 s) | ~4 min |

The simulation's ROM is a **model** built from the two real captures (a host that probes with a 16-word packet,
a child whose ROM resets its link hardware if a packet isn't complete within 6 of its own frames). It checks
that the code does what the clock-tie fix claims and cannot deadlock; it cannot say what a particular real ROM does.

## Pass 8 additions (smooth link)
- `link_test_stubs.h` models the split-phase methods (`jniExchangeBegin` / `jniExchangeEnd` /
  `jniLastRttUs`) with hooks (`g_begin_hook`, `g_end_hook`, `g_rtt_hook`); `g_smooth_methods_present = 0`
  reproduces a Kotlin side that lacks them.
- `test_sio_regs.c` — 33 new assertions: the Start write returns at once with Start/Busy set, the answer
  is collected only when the transfer completes, the adaptive transfer time follows the measured round
  trip (grows when a collect had to wait, shortens slowly when it did not, capped, unmoved by a timeout),
  answers given locally (peer absent / not in multi mode), teardown with a request in flight, the
  blocking fallback when the completion event is still queued, and the `nativeLinkStart` variants.
- `sim_dev.c` takes an 11th argument (`smooth`, 0/1) and models Begin/End with a delay line so the
  one-way delay is not paid inside the send; `run_sim.py` scenarios 8-14 compare it with the blocking
  exchange at 2 ms, 0.15 ms (local link), 3 ms and 15 ms one-way, under loss, with a late child and with a
  frozen child. Scenario 6's "0 resets at 1% loss" is statistical — one reset in a single run is noise.
- Run each scenario on its own if your sandbox kills long background jobs (each is 10-40 s).

## Pass 12 (ThreadSanitizer)
- `test_mailbox.c`: the fake game thread and the main thread shared `FakeChild.run` / `isr_count` as plain ints —
  a data race in the test itself (not in `link_mailbox.h`, whose fields are all accessed under its mutex). Both are
  C11 `atomic_int` now; the fake thread's other writes happen before the `atomic_fetch_add` that publishes them.
- `run.sh` used to pipe the TSan run through `tail -4`, which hid every report behind a passing-looking summary; it now
  prints the whole report and exits non-zero when TSan fails.

## Pass 14 (Zelda: A Link to the Past & Four Swords — per-game link timing)
- `link_timing.h` (pure C, in `app/src/main/cpp/`) holds the two caps on the host's emulated transfer time (Smooth 4500 us,
  Compatible 1500 us), the Auto / Smooth / Compatible modes and the rule that picks one (the ROM header title `GBAZELDA`
  at 0xA0 -> Compatible under Auto). `test_link_timing.c` includes it exactly as it ships (30 checks, under ASan/UBSan):
  the constants the Kotlin side depends on, the cadence arithmetic with the capture's numbers, the title match
  (near-misses, other offsets, truncated images), mode x game -> cap, the log helpers (ASan checks the title copy).
- `link_test_stubs.h`: `struct GBA` has `memory.rom` / `memory.romSize` now, because `nativeLinkStart()` reads the header title.
- `test_sio_regs.c` (138 -> 160 checks): the cap a session gets for every setting and ROM; no inheritance between sessions;
  the cap bounds the stretch but not the round-trip measurement; a 1.5 ms transfer is 25,165 cycles with its IRQ at that
  moment. `SMOOTH_ON()` resets the round-trip estimate, so the smooth tests no longer depend on the order they run in.
- `sim_dev.c` has a Four Swords model (argument 12 = the cartridge; argument 13 = the timing setting, 0 Auto / 1 Smooth /
  2 Compatible). **A model, not the cartridge:** the master restarts its round with a 0xFEFE probe every 2 frames, a round is
  13 transfers (the probe and a 12-halfword block whose words add up to 0xFFF1), and the slave re-aligns only on a probe that
  follows a complete round — the mechanism the 31 Oct 2026 capture showed breaking, taken from the two logs and from what the
  Spuds0588/mgba-splitscreen project decoded from the cartridge. It shows what the host's transfer timing does to that
  mechanism through the real driver / clock-tie / child-delivery code; it cannot say what the real cartridge does in every detail.
- `run_sim.py` was split: `sim_lib.py` has the process launcher and the check helpers (`run`, `check`, `finish`);
  `run_sim.py` (scenarios 1-14, unchanged in what it checks) and `run_sim_fs.py` (F1-F4, 18 checks) import it.
  `run_sim.sh` sets `PYTHONDONTWRITEBYTECODE=1` so that importing `sim_lib` leaves no `__pycache__` in the tree.
- Reading F1 / F2: F1 forces the old 4.5 ms transfers — no round completes, the child recognises about every second probe,
  no block validates (the capture's pattern). F2 is Auto with the Four Swords header title -> 1.5 ms transfers: every round
  completes, every probe is recognised, the link is up in under a second. F3 (local link) shows no loss of speed; F4
  (Bluetooth-like delay) links up but runs slowly — the price of one network round trip per transfer.
- The extraction markers in `mgba_jni.c` that `extract.py` cuts at must stay intact; the new `nativeLinkSetTimingMode()` sits
  right before `nativeLinkStart()`, inside the third region.
