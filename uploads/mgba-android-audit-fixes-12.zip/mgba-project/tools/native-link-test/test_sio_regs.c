#include "link_test_stubs.h"
#include "../../app/src/main/cpp/link_mailbox.h"
#include "../../app/src/main/cpp/link_timing.h"

/* ---- code under test, pulled verbatim from mgba_jni.c ---- */
#include "extracted_r1.c"
static void link_frame_prologue(JNIEnv *env);
#include "extracted_r2.c"
#include "extracted_r3.c"
#include "extracted_r4.c"
#include "extracted_r5.c"

static int fails = 0;
#define CHECK(c,msg) do{ if(c) printf("PASS  %s\n",msg); else { printf("FAIL  %s\n",msg); fails++; } }while(0)
static struct GBA gba;

static void reset_world(bool host, uint16_t siocnt, uint16_t rcnt) {
    memset(&gba, 0, sizeof gba);
    gba.sio.siocnt = siocnt; gba.sio.rcnt = rcnt;
    g_link_gba = &gba; g_link_active = true; g_link_is_host = host;
    g_link_obj = (jobject)&g_iface; g_link_xchg_mid = (jmethodID)&g_iface;
    g_link_driver.d.writeRegister = link_sio_write_register;
    g_link_driver.env = &g_env; g_link_driver.localSend = 0xFFFF;
    g_calls = 0; g_irq_count = 0; g_link_pace_window_active = false;
    link_host_deferred_reset(true); g_link_done_event_inited = false; g_link_done_scheduled = false; g_link_done_core = NULL;
    g_double_schedules = 0; g_schedule_calls = 0; timing_clear(&gba);
    /* clock tie: the register tests exercise the legacy one-word-per-frame child path unless a test turns it on */
    g_link_clock_sync = false; g_link_tick = 0; g_link_tick_inited = false; g_link_tick_scheduled = false; g_link_tick_core = NULL;
    g_ch_have_prev = false; g_ch_burst = false; g_ch_hold_ms = 20; g_ch_wait_ewma_us = 5000; g_ch_gov_active = false;
    g_st_have_ts = false; g_last_stamp = -1;
    __atomic_store_n(&g_link_child_multi, link_sio_is_multi(&gba), __ATOMIC_RELAXED);
    lm_close(link_mbox());
}

typedef struct { int hostData; int stamp; jint rc; } ChildCall;
static void *child_call_thread(void *a){ ChildCall *c=a; c->rc = Java_com_mgba_android_EmulatorEngine_nativeLinkChildExchange(&g_env,NULL,c->hostData,c->stamp); return NULL; }


typedef struct { ChildCall *c; int delay_us; } DelayedCall;
static void *delayed_call_thread(void *p){ DelayedCall *d=p; usleep(d->delay_us); child_call_thread(d->c); return NULL; }
static void *delayed_close_thread(void *p){ (void)p; usleep(10000); lm_close(link_mbox()); return NULL; }

/* hooks used by the smooth-link tests */
static jint rtt_500(void) { return 500; }
static jint rtt_3000(void) { return 3000; }
static jint rtt_20000(void) { return 20000; }
static jint slow_end(void) { usleep(3000); return 0x0111; }
static jint very_slow_end(void) { usleep(20000); return 0x0111; }
static jint timeout_end(void) { usleep(2000); return -1; }
static jint skip_begin(int d, int st) { (void)d; (void)st; return -1; }
static jint notmulti_begin(int d, int st) { (void)d; (void)st; return (jint)(0xFFFFu | (LINK_RF_NOT_MULTI << 16)); }

/* Starts a link session for a cartridge image / timing mode, returns the stretch cap the session got (0xFFFFFFFF = start failed), stops it. */
static uint32_t timing_session_cap(bool host, uint32_t *rom, size_t rom_size, int mode) {
    reset_world(host, 0x6003, 0); g_core_obj.board = &gba; g_link_gba = NULL; g_link_active = false;
    gba.memory.rom = rom; gba.memory.romSize = rom_size;
    Java_com_mgba_android_EmulatorEngine_nativeLinkSetTimingMode(&g_env, NULL, mode);
    jboolean ok = Java_com_mgba_android_EmulatorEngine_nativeLinkStart(&g_env, NULL, (jobject)&g_dummy_class, host, 1, 1);
    uint32_t cap = ok ? g_link_stretch_cap_us : 0xFFFFFFFFu;
    Java_com_mgba_android_EmulatorEngine_nativeLinkStop(&g_env, NULL);
    return cap;
}

int main(void) {
    printf("== HOST: SIOCNT Start write (multi mode, IRQ enabled, 115200 baud) — completion is DEFERRED\n");
    reset_world(true, 0x6003, 0);
    gba.memory.io[0x120>>1] = 0x1111; gba.memory.io[0x122>>1] = 0x2222;      /* stale values from an earlier transfer */
    link_sio_write_register(&g_link_driver.d, 0x12A, 0x00AB);          /* ROM stages SIOMLT_SEND */
    g_script_reply = 0x0CD2;
    uint16_t out = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083);
    CHECK(g_calls==1 && g_last_sent==0x00AB,"exchange runs once and sends the staged SIOMLT_SEND");
    CHECK((out & 0x0080)!=0,"write RETURNS with Start/Busy still set (hardware: a transfer takes time)");
    CHECK(g_irq_count==0,"no IRQ inside the write (the ROM's next instruction runs before any ISR)");
    CHECK(gba.memory.io[0x120>>1]==0x1111 && gba.memory.io[0x122>>1]==0x2222,"SIOMULTI registers not updated yet");
    CHECK((out & 0x0008)!=0 && (out & 0x0004)==0 && (out & 0x0030)==0,"SD set, SI clear (parent), ID=0");
    CHECK((out & 0x6000)==0x6000,"mode bits and IRQ-enable preserved");
    gba.sio.siocnt = out;                                              /* mGBA stores what the driver returns */
    timing_advance(&gba, 6409);
    CHECK(g_irq_count==0 && (gba.sio.siocnt & 0x0080)!=0,"still busy one cycle before the 115200-baud transfer time (6410)");
    timing_advance(&gba, 1);
    CHECK((gba.sio.siocnt & 0x0080)==0,"busy clears when the event fires");
    CHECK(gba.memory.io[0x120>>1]==0x00AB && gba.memory.io[0x122>>1]==0x0CD2 && gba.memory.io[0x124>>1]==0xFFFF && gba.memory.io[0x126>>1]==0xFFFF,"SIOMULTI0=host, SIOMULTI1=child, SIOMULTI2/3=0xFFFF delivered at completion");
    CHECK(g_irq_count==1,"SIO IRQ raised exactly once, at completion");
    CHECK((gba.sio.siocnt & 0x0040)==0 && (gba.sio.siocnt & 0x0030)==0 && (gba.sio.siocnt & 0x6000)==0x6000,"no error, ID 0, mode/IRQ bits intact");
    CHECK(gba.memory.io[0x128>>1]==gba.sio.siocnt,"memory.io mirror consistent");

    printf("== HOST: transfer time follows the baud bits\n");
    { int expect[4]={76900,19225,12820,6410};
      for (int baud=0; baud<4; baud++) {
        reset_world(true, 0x6000|baud, 0); g_script_reply=1;
        out = link_sio_write_register(&g_link_driver.d, 0x128, (uint16_t)(0x6080|baud)); gba.sio.siocnt = out;
        timing_advance(&gba, expect[baud]-1); int early = (gba.sio.siocnt & 0x80)!=0;
        timing_advance(&gba, 1); int done = (gba.sio.siocnt & 0x80)==0;
        char m[80]; snprintf(m,sizeof m,"baud bits %d -> completes at exactly %d cycles",baud,expect[baud]); CHECK(early && done,m);
      } }

    printf("== HOST: a second Start (or a clearing write) while busy is ignored\n");
    reset_world(true, 0x6003, 0); g_script_reply = 0x0111;
    out = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083); gba.sio.siocnt = out;
    int callsBefore = g_calls;
    out = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083); gba.sio.siocnt = out;
    CHECK(g_calls==callsBefore && g_schedule_calls==1,"second Start: no second exchange, no second event");
    out = link_sio_write_register(&g_link_driver.d, 0x128, 0x6003); gba.sio.siocnt = out;
    CHECK((out & 0x0080)!=0,"software cannot clear Start/Busy mid-transfer");
    timing_advance(&gba, 7000);
    CHECK(g_irq_count==1 && (gba.sio.siocnt & 0x0080)==0,"still exactly one completion");
    out = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083);
    CHECK(g_calls==callsBefore+1,"a new Start after completion starts a new transfer");

    printf("== HOST: SIO IRQ disabled by the ROM -> no IRQ at completion\n");
    reset_world(true, 0x2003, 0); g_script_reply = 0x1111;
    out = link_sio_write_register(&g_link_driver.d, 0x128, 0x2083); gba.sio.siocnt = out;
    timing_advance(&gba, 7000);
    CHECK(g_calls==1 && g_irq_count==0 && (gba.sio.siocnt & 0x0080)==0,"transfer completes, IRQ NOT raised when SIOCNT bit14=0");

    printf("== HOST: no answer from child -> error flag appears at completion, not before\n");
    reset_world(true, 0x6003, 0); g_script_reply = -1;
    out = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083); gba.sio.siocnt = out;
    CHECK((out & 0x0040)==0,"error flag not set inside the write");
    timing_advance(&gba, 7000);
    CHECK((gba.sio.siocnt & 0x0040)!=0 && gba.memory.io[0x122>>1]==0xFFFF,"timeout -> error bit set, SIOMULTI1=0xFFFF at completion");
    CHECK(g_irq_count==1 && (gba.sio.siocnt & 0x0080)==0,"transfer still completes (busy cleared, IRQ raised)");

    printf("== HOST: teardown while a transfer is in flight\n");
    reset_world(true, 0x6003, 0); g_script_reply = 0x0222;
    out = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083); gba.sio.siocnt = out;
    link_host_deferred_reset(false);                                     /* link stopped; core + queue live on */
    CHECK((gba.sio.siocnt & 0x0080)==0 && !g_link_xfer_pending,"stop mid-transfer clears Start/Busy (no ROM stuck waiting)");
    int sched = g_schedule_calls;
    out = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083); gba.sio.siocnt = out;   /* restarted inside the old event's window */
    CHECK(g_double_schedules==0 && g_schedule_calls==sched,"event still queued -> NOT scheduled twice (queue corruption guard)");
    CHECK((out & 0x0080)==0 && g_irq_count==1,"...falls back to instant completion for that one transfer");
    timing_advance(&gba, 7000);
    CHECK(g_irq_count==1,"the stale event later fires as a harmless no-op");
    out = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083); gba.sio.siocnt = out;
    CHECK(g_schedule_calls==sched+1 && (out & 0x0080)!=0,"after it has fired, deferral works again");
    timing_advance(&gba, 7000);

    printf("== HOST: core swap / save-state load discards the queue\n");
    reset_world(true, 0x6003, 0); g_script_reply = 0x0333;
    out = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083); gba.sio.siocnt = out;
    timing_clear(&gba); link_host_deferred_reset(true);                  /* what GBADeserialize does to the queue + our hook */
    CHECK((gba.sio.siocnt & 0x0080)==0 && !g_link_done_scheduled,"load mid-transfer: busy cleared, nothing considered scheduled");
    sched = g_schedule_calls;
    out = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083); gba.sio.siocnt = out;
    CHECK(g_schedule_calls==sched+1 && g_double_schedules==0 && (out & 0x0080)!=0,"next transfer defers normally (no permanent fallback)");
    timing_advance(&gba, 7000);

    printf("== CHILD role: SIOCNT writes\n");
    reset_world(false, 0x6003, 0);
    out = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083);       /* child ROM writes Start by mistake */
    CHECK(g_calls==0,"child never starts a transfer of its own");
    CHECK((out & 0x0080)==0,"child's Start/Busy write is ignored (read-only for slaves)");
    CHECK((out & 0x000C)==0x000C,"SD and SI (child) set");
    CHECK((out & 0x0030)==0x0010,"ID bits = 01 survive an ordinary SIOCNT write (used to be reset to 0)");
    out = link_sio_write_register(&g_link_driver.d, 0x128, 0x6003 | 0x0030);
    CHECK((out & 0x0030)==0x0010,"ROM can't overwrite the read-only ID bits");

    printf("== CHILD: lock-step delivery through the mailbox\n");
    reset_world(false, 0x6003, 0);
    lm_open(link_mbox());
    g_link_driver.localSend = 0x1234;
    ChildCall cc = { 0x5A5A, 0, 99 }; pthread_t t; pthread_create(&t,NULL,child_call_thread,&cc);
    bool took=false; for(int i=0;i<500 && !took;i++){ usleep(1000); took = link_child_deliver_pending(); }
    CHECK(took,"game thread takes the posted request");
    CHECK(gba.memory.io[0x120>>1]==0x5A5A && gba.memory.io[0x122>>1]==0x1234,"SIOMULTI0=host word, SIOMULTI1=child's own word");
    CHECK(gba.sio.siocnt==0x601F,"REAL gba->sio.siocnt updated: mode/IRQ bits kept, SD+SI set, ID=1, busy clear (0x601F)");
    CHECK(gba.memory.io[0x128>>1]==0x601F,"memory.io mirror kept consistent");
    CHECK(g_irq_count==1,"child SIO IRQ raised once");
    pthread_join(t,NULL);
    CHECK(cc.rc==0x1234,"network thread released at delivery with the child's staged word (0x1234)");
    /* one transfer per frame: a second request must wait for the NEXT frame start */
    g_link_driver.localSend = 0x9999;                       /* "ISR staged the next word during the frame" */
    ChildCall cc2 = { 0x6B6B, 0, 99 }; pthread_t t2; pthread_create(&t2,NULL,child_call_thread,&cc2);
    usleep(30000);
    CHECK(cc2.rc==99 && gba.memory.io[0x120>>1]==0x5A5A,"2nd request is NOT delivered mid-frame (registers still show the 1st)");
    took = link_child_deliver_pending();
    pthread_join(t2,NULL);
    CHECK(took && gba.memory.io[0x120>>1]==0x6B6B && cc2.rc==0x9999,"next frame start delivers it, and the reply reflects the word staged in between");
    CHECK(g_irq_count==2,"one IRQ per delivered transfer");

    printf("== CHILD not in Multi-Player mode: answered at once on the network thread, flagged, registers untouched\n");
    reset_world(false, 0x0000, 0);
    lm_open(link_mbox());
    gba.memory.io[0x120>>1]=0x7777; g_link_driver.localSend = 0x4321;
    cc.hostData=0x1111; cc.stamp=0; cc.rc=99;
    { struct timespec a0,b0; clock_gettime(CLOCK_MONOTONIC,&a0); child_call_thread(&cc); clock_gettime(CLOCK_MONOTONIC,&b0);
      double ms=(b0.tv_sec-a0.tv_sec)*1000.0+(b0.tv_nsec-a0.tv_nsec)/1e6;
      CHECK(ms<20,"no game thread needed: the reply is immediate (no frame wait)"); }
    CHECK(cc.rc==(jint)(0xFFFFu | (LINK_RF_NOT_MULTI<<16)),"reply = 0xFFFF with the NOT_MULTI flag in bits 16-23");
    CHECK(gba.memory.io[0x120>>1]==0x7777 && gba.sio.siocnt==0x0000 && g_irq_count==0,"registers and SIOCNT untouched (SIODATA32 shares those addresses)");
    /* a word posted while the ROM WAS in multi mode, then the ROM left it before the game thread got to it */
    reset_world(false, 0x6003, 0); lm_open(link_mbox());
    cc.hostData=0x1111; cc.rc=99; pthread_create(&t,NULL,child_call_thread,&cc);
    usleep(20000);
    gba.sio.siocnt = 0x0000; gba.memory.io[0x120>>1]=0x7777;
    took = link_child_deliver_pending();
    pthread_join(t,NULL);
    CHECK(took && cc.rc==(jint)(0xFFFFu | (LINK_RF_NOT_MULTI<<16)) && gba.memory.io[0x120>>1]==0x7777 && g_irq_count==0,"left multi mode meanwhile: flagged reply, nothing written");

    printf("== CHILD with SIO IRQ disabled: data lands, no IRQ\n");
    reset_world(false, 0x2003, 0); lm_open(link_mbox()); g_link_driver.localSend = 0x0001;
    cc.hostData=0x2222; pthread_create(&t,NULL,child_call_thread,&cc);
    took=false; for(int i=0;i<500 && !took;i++){ usleep(1000); took = link_child_deliver_pending(); }
    pthread_join(t,NULL);
    CHECK(took && gba.memory.io[0x120>>1]==0x2222 && g_irq_count==0,"no IRQ when SIOCNT bit14=0");

    printf("== link closed / nobody running frames\n");
    lm_close(link_mbox());
    cc.hostData=1; cc.rc=99; child_call_thread(&cc);
    CHECK(cc.rc==-1,"closed link -> -1 (host's 'no answer')");
    reset_world(false, 0x6003, 0); lm_open(link_mbox());
    cc.rc=99; struct timespec a,b; clock_gettime(CLOCK_MONOTONIC,&a); child_call_thread(&cc); clock_gettime(CLOCK_MONOTONIC,&b);
    double ms=(b.tv_sec-a.tv_sec)*1000.0+(b.tv_nsec-a.tv_nsec)/1e6;
    CHECK(cc.rc==-1 && ms>=90 && ms<400,"no game thread: -1 after about LINK_CHILD_WAIT_MS (100 ms)");


    /* ================= CLOCK TIE ================= */
    printf("== CLOCK TIE: the tick event is armed once, ticks every 6410 cycles, and stamps host words\n");
    reset_world(true, 0x6003, 0); g_link_clock_sync = true;
    link_frame_prologue(&g_env);
    CHECK(g_link_tick_scheduled && g_schedule_calls==1,"prologue arms the tick");
    link_frame_prologue(&g_env);
    CHECK(g_schedule_calls==1 && g_double_schedules==0,"calling it every frame does not queue it twice");
    timing_advance(&gba, 6409);  CHECK(g_link_tick==0,"no tick one cycle early");
    timing_advance(&gba, 1);     CHECK(g_link_tick==1,"first tick at exactly 6410 cycles");
    timing_advance(&gba, 6410*10); CHECK(g_link_tick==11 && g_double_schedules==0,"keeps ticking, still one event in the queue");
    g_script_reply = 0x0001;
    link_sio_write_register(&g_link_driver.d, 0x12A, 0x00AB);
    out = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083); gba.sio.siocnt = out;
    CHECK(g_calls==1 && g_last_stamp==11,"host passes its tick count (11) to Kotlin as the stamp");
    timing_advance(&gba, 7000);
    CHECK(g_last_stamp==11 && (gba.sio.siocnt & 0x80)==0,"transfer completion coexists with the tick in one queue");

    printf("== CLOCK TIE: stop lets the tick lapse; restart inside the stale window does not double-queue\n");
    reset_world(true, 0x6003, 0); g_link_clock_sync = true; link_frame_prologue(&g_env);
    timing_advance(&gba, 6410*3);
    g_link_active = false;
    timing_advance(&gba, 6410*5);
    CHECK(g_link_tick==3 && !g_link_tick_scheduled && gba.timing.head==NULL,"after stop the event fires once, does nothing, and is gone");
    reset_world(true, 0x6003, 0); g_link_clock_sync = true; link_frame_prologue(&g_env);
    g_link_active = false; g_link_active = true;
    link_frame_prologue(&g_env);
    CHECK(g_schedule_calls==1 && g_double_schedules==0,"stop+restart before the event fired: not scheduled again");
    timing_advance(&gba, 6410*2);
    CHECK(g_link_tick==2,"...and it simply keeps going");

    printf("== CLOCK TIE: save-state load / core swap discards the queue; the next frame re-arms\n");
    reset_world(true, 0x6003, 0); g_link_clock_sync = true; link_frame_prologue(&g_env);
    timing_clear(&gba); link_tick_reset(true);
    CHECK(!g_link_tick_scheduled,"bookkeeping cleared");
    link_frame_prologue(&g_env);
    CHECK(g_link_tick_scheduled && g_schedule_calls==2 && g_double_schedules==0,"prologue puts the tick back");

    printf("== CLOCK TIE: legacy path (clock sync off) never arms a tick\n");
    reset_world(true, 0x6003, 0); g_link_clock_sync = false; link_frame_prologue(&g_env);
    CHECK(!g_link_tick_scheduled && g_schedule_calls==0,"no tick event when g_link_clock_sync is false");

    printf("== CLOCK TIE: child delivers at the host's spacing, holds mid-burst, runs free when sparse\n");
    reset_world(false, 0x6003, 0); g_link_clock_sync = true; lm_open(link_mbox());
    g_link_driver.localSend = 0x1000; link_frame_prologue(&g_env);
    ChildCall w = { 0xA001, 100, 99 }; pthread_t tw;
    pthread_create(&tw,NULL,child_call_thread,&w); usleep(20000);
    CHECK(w.rc==99,"word 1 (stamp 100) is waiting for a tick, not delivered mid-nothing");
    timing_advance(&gba, 6410);                                           /* tick 1 */
    pthread_join(tw,NULL);
    CHECK(w.rc==0x1000 && gba.memory.io[0x120>>1]==0xA001 && gba.memory.io[0x122>>1]==0x1000 && g_irq_count==1,"no history -> delivered at the first tick; reply = the staged word; one IRQ");
    CHECK(!g_ch_burst,"one word is not yet a burst");
    g_link_driver.localSend = 0x2000;                                     /* the ISR staged the next reply */
    w.hostData=0xA002; w.stamp=101; w.rc=99; pthread_create(&tw,NULL,child_call_thread,&w); usleep(20000);
    timing_advance(&gba, 6410);                                           /* tick 2: gap 1, only 1 tick since delivery -> due */
    pthread_join(tw,NULL);
    CHECK(w.rc==0x2000 && gba.memory.io[0x120>>1]==0xA002 && g_irq_count==2,"word 2 (gap 1) delivered one tick later, reply reflects the word staged in between");
    CHECK(g_ch_burst,"two words 1 tick apart = a burst");

    /* tick 3: nothing posted, burst on -> the child HOLDS. A helper thread posts word 3 ~8 ms into the hold. */
    g_link_driver.localSend = 0x3000;
    { ChildCall w3 = { 0xA003, 102, 99 }; DelayedCall dc = { &w3, 8000 };
      struct timespec a0,b0;
      pthread_t tposter;
      pthread_create(&tposter,NULL,delayed_call_thread,&dc);               /* posts word 3 about 8 ms into the hold */
      clock_gettime(CLOCK_MONOTONIC,&a0);
      timing_advance(&gba, 6410);                                         /* tick 3: holds, wakes on the post, delivers */
      clock_gettime(CLOCK_MONOTONIC,&b0);
      pthread_join(tposter,NULL);
      double ms=(b0.tv_sec-a0.tv_sec)*1000.0+(b0.tv_nsec-a0.tv_nsec)/1e6;
      CHECK(ms>=6 && ms<19,"the child's emulation waited for the next word (hold), then continued as soon as it arrived");
      CHECK(w3.rc==0x3000 && gba.memory.io[0x120>>1]==0xA003 && g_irq_count==3,"word 3 delivered inside the same tick");
      CHECK(g_st_ch_holds==1,"one successful hold counted"); }

    /* word 4 arrives with gap 3: the child must run 3 ticks before delivering */
    g_link_driver.localSend = 0x4000;
    w.hostData=0xA004; w.stamp=105; w.rc=99; pthread_create(&tw,NULL,child_call_thread,&w); usleep(20000);
    timing_advance(&gba, 6410);  CHECK(w.rc==99 && g_irq_count==3,"tick 4: 1 tick since last delivery < gap 3 -> not yet");
    timing_advance(&gba, 6410);  CHECK(w.rc==99 && g_irq_count==3,"tick 5: 2 ticks -> not yet");
    timing_advance(&gba, 6410);  pthread_join(tw,NULL);
    CHECK(w.rc==0x4000 && g_irq_count==4,"tick 6: 3 ticks -> delivered (the host's spacing reproduced)");

    /* word 4b: a frame-periodic host idles ~28 ticks between blocks. The burst must SURVIVE that gap. */
    g_link_driver.localSend = 0x4100;
    w.hostData=0xA0B4; w.stamp=133; w.rc=99; pthread_create(&tw,NULL,child_call_thread,&w); usleep(20000);   /* 105 + 28 */
    { int before = g_irq_count, guard = 0; while (g_irq_count == before && guard++ < 60) timing_advance(&gba, 6410); }
    pthread_join(tw,NULL);
    CHECK(w.rc==0x4100 && g_irq_count==5 && g_ch_burst && (g_link_tick - g_ch_prev_tick)==0,"a 28-tick idle gap between blocks: delivered at the host's spacing and burst mode persists");
    CHECK(g_link_tick == 34,"...exactly 28 ticks after the previous word (tick 6 + 28)");
    g_irq_count = 4;   /* the checks below were written against the earlier count */

    /* the burst has ended: the next tick holds for the hold time, then gives up and runs free */
    { struct timespec a0,b0; int hold = g_ch_hold_ms;
      clock_gettime(CLOCK_MONOTONIC,&a0); timing_advance(&gba, 6410); clock_gettime(CLOCK_MONOTONIC,&b0);
      double ms=(b0.tv_sec-a0.tv_sec)*1000.0+(b0.tv_nsec-a0.tv_nsec)/1e6;
      CHECK(ms>=hold-2 && ms<hold+60,"no next word: the hold times out after about g_ch_hold_ms");
      CHECK(!g_ch_burst && g_st_ch_hold_to==1,"...and the child runs free again (burst cleared)");
      CHECK(g_ch_gov_active,"the free-run governor is armed when the hold gives up");
      clock_gettime(CLOCK_MONOTONIC,&a0); timing_advance(&gba, 6410*100); clock_gettime(CLOCK_MONOTONIC,&b0);
      ms=(b0.tv_sec-a0.tv_sec)*1000.0+(b0.tv_nsec-a0.tv_nsec)/1e6;
      CHECK(ms>=25 && ms<90,"free-run is governed to real time: 100 ticks (38 ms emulated) take ~35 ms, not ~0 (no catch-up burst)"); }

    /* sparse: a word stamped (ticks-run-so-far + 40) host ticks after the previous one is held back until the child has run those ticks too */
    g_ch_prev_tick = g_link_tick; g_ch_gov_active = false;   /* as if a word had just been delivered */
    { uint32_t since0 = g_link_tick - g_ch_prev_tick; unsigned gapw = since0 + 40u;
      CHECK(gapw <= 128u,"setup: the gap is within the spacing window");
      uint16_t st = (uint16_t)(g_ch_prev_h + gapw);
      jint expect = (jint)g_link_driver.localSend;
      w.hostData=0xA005; w.stamp=st; w.rc=99; pthread_create(&tw,NULL,child_call_thread,&w); usleep(20000);
      int need = (int)gapw - (int)(g_link_tick - g_ch_prev_tick); int base = g_irq_count;
      CHECK(need == 40,"setup: the child still has to run 40 more ticks");
      { struct timespec a1,b1; clock_gettime(CLOCK_MONOTONIC,&a1);
        timing_advance(&gba, 6410LL*(need-1));
        clock_gettime(CLOCK_MONOTONIC,&b1);
        double ms1=(b1.tv_sec-a1.tv_sec)*1000.0+(b1.tv_nsec-a1.tv_nsec)/1e6;
        CHECK(ms1<15,"running ticks to reach a POSTED word's slot is not throttled (the host's clock did advance that far)"); }
      CHECK(g_irq_count==base,"one tick before the host's gap has elapsed: still waiting");
      timing_advance(&gba, 6410); pthread_join(tw,NULL);
      CHECK(g_irq_count==base+1 && w.rc==expect,"delivered exactly when the host's gap has elapsed"); }
    /* a gap beyond ~3 frames ends burst mode */
    g_ch_burst = true; g_ch_have_prev = true; g_ch_prev_h = 1000; g_ch_prev_tick = g_link_tick;
    { int base = g_irq_count;
      w.hostData=0xA0C0; w.stamp=(uint16_t)(1000+200); w.rc=99; pthread_create(&tw,NULL,child_call_thread,&w); usleep(20000);
      timing_advance(&gba, 6410); pthread_join(tw,NULL);
      CHECK(g_irq_count==base+1 && !g_ch_burst,"a 200-tick gap ends burst mode (delivered at once, no spacing)"); }
    /* a huge gap (the host sat idle): no spacing is enforced */
    { int base = g_irq_count;
      w.hostData=0xA006; w.stamp=5000; w.rc=99; pthread_create(&tw,NULL,child_call_thread,&w); usleep(20000);
      timing_advance(&gba, 6410); pthread_join(tw,NULL);
      CHECK(g_irq_count==base+1 && !g_ch_burst,"gap > 128 ticks: delivered at the very next tick, not a burst"); }

    printf("== CLOCK TIE: the governor wakes for a word and is released by the delivery\n");
    g_ch_gov_active = true; g_ch_burst = false; g_ch_have_prev = true; g_ch_prev_h = 100; g_ch_prev_tick = g_link_tick;
    clock_gettime(CLOCK_MONOTONIC,&g_ch_gov_ts); g_ch_gov_tick0 = g_link_tick;
    { ChildCall wg = { 0xA0D0, 100+500, 99 }; DelayedCall dcg = { &wg, 10000 };
      int base = g_irq_count; struct timespec a1,b1; pthread_t tg;
      pthread_create(&tg,NULL,delayed_call_thread,&dcg);
      clock_gettime(CLOCK_MONOTONIC,&a1); timing_advance(&gba, 6410*400); clock_gettime(CLOCK_MONOTONIC,&b1);   /* 153 ms emulated */
      pthread_join(tg,NULL);
      double ms1=(b1.tv_sec-a1.tv_sec)*1000.0+(b1.tv_nsec-a1.tv_nsec)/1e6;
      CHECK(g_irq_count==base+1 && !g_ch_gov_active,"a word posted while the child is being governed is delivered during the sleep and releases the governor");
      CHECK(ms1 < 140,"...after which time runs unthrottled again (400 ticks took well under their 153 ms of emulated time)"); }

    printf("== CLOCK TIE: the child's multi-mode flag follows the ROM and short-circuits the network thread\n");
    gba.sio.siocnt = 0x0000; timing_advance(&gba, 6410);
    CHECK(!__atomic_load_n(&g_link_child_multi, __ATOMIC_RELAXED),"ROM left Multi-Player mode: flag cleared on the next tick");
    w.hostData=0xBEEF; w.stamp=1; w.rc=99; child_call_thread(&w);
    CHECK(w.rc==(jint)(0xFFFFu | (LINK_RF_NOT_MULTI<<16)),"network thread answers 'not multi' without a frame");
    gba.sio.siocnt = 0x6003; timing_advance(&gba, 6410);
    CHECK(__atomic_load_n(&g_link_child_multi, __ATOMIC_RELAXED),"back in Multi-Player mode: flag set again");

    printf("== CLOCK TIE: a link stop wakes a holding child immediately\n");
    reset_world(false, 0x6003, 0); g_link_clock_sync = true; lm_open(link_mbox()); link_frame_prologue(&g_env);
    g_ch_burst = true; g_ch_have_prev = true; g_ch_prev_tick = 0; g_ch_hold_ms = 120;
    timing_advance(&gba, 6410);                                           /* tick 1 would hold 120 ms ... */
    { struct timespec a0,b0; g_ch_burst = true; g_ch_prev_tick = 1;
      pthread_t tc; pthread_create(&tc,NULL,delayed_close_thread,NULL);
      clock_gettime(CLOCK_MONOTONIC,&a0); timing_advance(&gba, 6410); clock_gettime(CLOCK_MONOTONIC,&b0);
      pthread_join(tc,NULL);
      double ms=(b0.tv_sec-a0.tv_sec)*1000.0+(b0.tv_nsec-a0.tv_nsec)/1e6;
      CHECK(ms<60,"lm_close() ends the hold at once instead of waiting out 120 ms"); }

    printf("== nativeLinkStart / nativeLinkStop: state is reset, signature matches Kotlin, tick armed by the prologue\n");
    {
      reset_world(true, 0x6003, 0);
      g_core_obj.board = &gba;
      g_link_gba = NULL; g_link_active = false;
      g_link_clock_sync = false; g_link_tick = 77; g_ch_have_prev = true; g_ch_burst = true;
      jboolean ok = Java_com_mgba_android_EmulatorEngine_nativeLinkStart(&g_env, NULL, (jobject)&g_dummy_class, 1, 1, 0);
      CHECK(ok==JNI_TRUE,"nativeLinkStart succeeds");
      CHECK(strcmp(g_method_sig,"(II)I")==0,"looks up jniExchangeData with signature (II)I");
      CHECK(g_link_active && g_link_is_host && g_link_clock_sync && g_link_tick==0 && !g_ch_have_prev && !g_ch_burst,"session state reset; clockSync taken from the argument");
      CHECK(gba.sio.drv==&g_link_driver.d,"driver registered with the SIO subsystem");
      link_frame_prologue(&g_env);
      CHECK(g_link_tick_scheduled,"the first frame arms the tick");
      Java_com_mgba_android_EmulatorEngine_nativeLinkStop(&g_env, NULL);
      CHECK(!g_link_active && gba.sio.drv==NULL && g_link_gba==NULL,"nativeLinkStop tears the link down");
      timing_advance(&gba, 6410*3);
      CHECK(!g_link_tick_scheduled && g_link_tick==0,"the tick lapses after stop");
    }

    printf("== nativeLinkStart: a failed method lookup clears the pending exception and reports failure\n");
    {
      /* A minified build whose keep rule no longer matches jniExchangeData makes GetMethodID fail. That
       * leaves a NoSuchMethodError pending; returning to Kotlin with it pending would throw it there - an
       * uncaught crash on the main thread the moment a link connects - instead of a clean false. */
      reset_world(true, 0x6003, 0);
      g_core_obj.board = &gba;
      g_link_gba = NULL; g_link_active = false;
      g_getmid_fail = 1; g_exc_cleared = 0;
      jboolean ok = Java_com_mgba_android_EmulatorEngine_nativeLinkStart(&g_env, NULL, (jobject)&g_dummy_class, 1, 0, 0);
      g_getmid_fail = 0;
      CHECK(ok==JNI_FALSE,"nativeLinkStart reports failure when jniExchangeData cannot be found");
      CHECK(g_exc_cleared==1,"the pending NoSuchMethodError is cleared before returning to Kotlin");
      CHECK(!g_link_active && gba.sio.drv==NULL,"no link session was started");
    }


    /* ======================= SMOOTH LINK (split-phase, stretched host transfers) ======================= */
#define SMOOTH_ON() do { g_link_begin_mid=(jmethodID)&g_mid_begin; g_link_end_mid=(jmethodID)&g_mid_end; \
                         g_link_rtt_mid=(jmethodID)&g_mid_rtt; g_link_smooth=true; g_link_stretch_us=0; g_link_rtt_ewma_us=0; g_link_stretch_cap_us=LINK_STRETCH_MAX_US; \
                         g_begin_calls=g_end_calls=g_rtt_calls=0; g_begin_hook=NULL; g_end_hook=NULL; g_rtt_hook=NULL; } while(0)
    printf("== SMOOTH: the Start write returns at once; the answer is collected only when the transfer completes\n");
    {
      reset_world(true, 0x6003, 0); SMOOTH_ON();
      gba.memory.io[0x120>>1] = 0x1111; gba.memory.io[0x122>>1] = 0x2222;
      link_sio_write_register(&g_link_driver.d, 0x12A, 0x00AB);
      g_script_reply = 0x0CD2;                                  /* what jniExchangeEnd() will hand back */
      uint16_t o = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083);
      CHECK(g_begin_calls==1 && g_last_sent==0x00AB && g_calls==0,"the request is sent via jniExchangeBegin, not the blocking jniExchangeData");
      CHECK(g_end_calls==0,"nothing waits for the answer inside the write");
      CHECK((o & 0x0080)!=0 && (o & 0x0070)==0 && (o & 0x0008)!=0 && (o & 0x0004)==0,"Start/Busy stays set, ID=0, error clear, SD set / SI clear (parent)");
      CHECK(g_irq_count==0 && gba.memory.io[0x120>>1]==0x1111,"no IRQ and no data registers yet");
      gba.sio.siocnt = o;
      timing_advance(&gba, 6409);
      CHECK((gba.sio.siocnt & 0x0080)!=0 && g_end_calls==0,"still busy, still nothing collected, one cycle before the baud-rate transfer time");
      timing_advance(&gba, 1);
      CHECK(g_end_calls==1,"the answer is collected exactly once, when the transfer completes");
      CHECK(gba.memory.io[0x120>>1]==0x00AB && gba.memory.io[0x122>>1]==0x0CD2 && gba.memory.io[0x124>>1]==0xFFFF && gba.memory.io[0x126>>1]==0xFFFF,"SIOMULTI0/1/2/3 as for a blocking transfer");
      CHECK(g_irq_count==1 && (gba.sio.siocnt & 0x0080)==0 && (gba.sio.siocnt & 0x0040)==0,"SIO IRQ once, busy cleared, no error");
      CHECK(g_double_schedules==0 && g_schedule_calls==1,"exactly one completion event");
    }

    printf("== SMOOTH: waiting for the answer lengthens the next transfer (the adaptive stretch)\n");
    {
      reset_world(true, 0x6003, 0); SMOOTH_ON();
      g_end_hook = slow_end; g_rtt_hook = rtt_3000;
      uint16_t o = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083); gba.sio.siocnt = o;
      timing_advance(&gba, 6410);
      CHECK(g_rtt_calls==1 && g_link_rtt_ewma_us==3000,"the first collect that had to wait seeds the round-trip estimate with Kotlin's measurement");
      CHECK(g_link_stretch_us>=3500 && g_link_stretch_us<=3700,"transfer time = round trip + 12% + 0.2 ms (~3.6 ms)");
      int32_t cyc = link_stretch_cycles();
      CHECK(cyc>6410 && cyc<70000,"stretch converted to emulated cycles (~3 ms = ~50-60k cycles)");
      g_end_calls = 0;
      o = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083); gba.sio.siocnt = o;
      timing_advance(&gba, cyc-1);
      CHECK((gba.sio.siocnt & 0x0080)!=0 && g_end_calls==0,"the next transfer is still busy after the plain 6410 cycles - it takes the stretched time");
      timing_advance(&gba, 1);
      CHECK((gba.sio.siocnt & 0x0080)==0 && g_end_calls==1,"...and completes when the stretch is up");
    }

    printf("== SMOOTH: answers that arrive in time shorten the stretch again, slowly\n");
    {
      reset_world(true, 0x6003, 0); SMOOTH_ON(); g_link_rtt_ewma_us = 4000; g_link_stretch_us = 4500; g_script_reply = 0x0111;
      uint32_t first = 0, last = 0;
      /* 700 transfers are plenty (the estimate falls ~1.6% per transfer). A collect that happens to take > 50 us of real
       * time (a scheduler hiccup under ASan, rare) counts as "had to wait" and re-seeds the estimate by a few us; if that
       * lands in the last transfers the estimate has not reached 0 yet, so allow up to 300 more before judging. */
      for (int i=0; i<1000 && (i<700 || g_link_rtt_ewma_us); i++) {
        uint16_t o = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083); gba.sio.siocnt = o;
        timing_advance(&gba, link_stretch_cycles() > 6410 ? link_stretch_cycles() : 6410);
        if (i==0) first = g_link_rtt_ewma_us; last = g_link_stretch_us;
      }
      CHECK(first<4000 && first>3900,"one transfer without waiting trims the round-trip estimate only a little (<2%)");
      CHECK(last<300 && g_link_rtt_ewma_us==0,"hundreds of transfers without waiting bring it back to the hardware transfer time");
    }

    printf("== SMOOTH: the stretch never exceeds the cap; a timeout does not move it\n");
    {
      reset_world(true, 0x6003, 0); SMOOTH_ON();
      g_end_hook = very_slow_end; g_rtt_hook = rtt_20000;
      uint16_t o = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083); gba.sio.siocnt = o;
      timing_advance(&gba, 6410);
      CHECK(g_link_stretch_us==LINK_STRETCH_MAX_US,"a 20 ms round trip is capped at LINK_STRETCH_MAX_US (the host blocks for the rest)");
      CHECK(g_link_rtt_ewma_us<=2u*LINK_STRETCH_MAX_US,"and one stall cannot drag the round-trip estimate beyond 2x the cap");
      g_link_stretch_us = 1234; g_end_hook = timeout_end;
      o = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083); gba.sio.siocnt = o;
      timing_advance(&gba, 80000);
      CHECK(g_link_stretch_us==1234,"a timed-out exchange says nothing about the round trip: stretch unchanged");
      CHECK((gba.sio.siocnt & 0x0040)!=0 && gba.memory.io[0x122>>1]==0xFFFF && (gba.sio.siocnt & 0x0080)==0,"timeout -> error bit + SIOMULTI1=0xFFFF at completion, transfer still completes");
    }

    printf("== SMOOTH: a transport that answers locally (peer absent / not in multi mode) behaves like the blocking path\n");
    {
      reset_world(true, 0x6003, 0); SMOOTH_ON();
      g_begin_hook = skip_begin;
      uint16_t o = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083); gba.sio.siocnt = o;
      CHECK(g_end_calls==0 && (o & 0x0080)!=0,"no collect call; the transfer is still deferred by the baud-rate time");
      timing_advance(&gba, 6410);
      CHECK((gba.sio.siocnt & 0x0040)!=0 && gba.memory.io[0x122>>1]==0xFFFF && g_irq_count==1,"nobody answered: error bit, 0xFFFF");
      g_begin_hook = notmulti_begin; g_irq_count = 0;
      o = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083); gba.sio.siocnt = o;
      timing_advance(&gba, 6410);
      CHECK(g_end_calls==0 && gba.memory.io[0x122>>1]==0xFFFF && (gba.sio.siocnt & 0x0040)==0 && g_irq_count==1,"not-multi reply: 0xFFFF without an error flag, as before");
    }

    printf("== SMOOTH: teardown with a request in flight\n");
    {
      reset_world(true, 0x6003, 0); SMOOTH_ON();
      uint16_t o = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083); gba.sio.siocnt = o;
      link_host_deferred_reset(false);                          /* link stopped, core and queue live on */
      CHECK((gba.sio.siocnt & 0x0080)==0 && !g_link_xfer_pending && !g_link_inflight,"stop mid-transfer clears Start/Busy and forgets the in-flight request");
      timing_advance(&gba, 7000);
      CHECK(g_end_calls==0 && g_irq_count==0,"the stale event later fires as a harmless no-op (nothing is collected)");
      reset_world(true, 0x6003, 0); SMOOTH_ON();
      o = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083); gba.sio.siocnt = o;
      timing_clear(&gba); link_host_deferred_reset(true);       /* save-state load / ROM swap */
      int sched = g_schedule_calls;
      o = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083); gba.sio.siocnt = o;
      CHECK(g_schedule_calls==sched+1 && g_double_schedules==0 && (o & 0x0080)!=0,"after a queue reset the next transfer is deferred normally");
    }

    printf("== SMOOTH: the event is still queued -> the answer is awaited in place (blocking fallback)\n");
    {
      reset_world(true, 0x6003, 0); SMOOTH_ON(); g_script_reply = 0x0777;
      uint16_t o = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083); gba.sio.siocnt = o;
      link_host_deferred_reset(false);                          /* leaves the old event queued */
      g_end_calls = 0; int sched = g_schedule_calls;
      o = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083); gba.sio.siocnt = o;
      CHECK(g_double_schedules==0 && g_schedule_calls==sched,"no second insert of the queued event");
      CHECK(g_end_calls==1 && (o & 0x0080)==0 && gba.memory.io[0x122>>1]==0x0777 && g_irq_count==1,"collected immediately and completed instantly for that one transfer");
    }

    printf("== nativeLinkStart: smooth link only for a host that asks for it and whose Kotlin side has the methods\n");
    {
      reset_world(true, 0x6003, 0); g_core_obj.board = &gba; g_link_gba = NULL; g_link_active = false; g_smooth_methods_present = 1;
      jboolean ok = Java_com_mgba_android_EmulatorEngine_nativeLinkStart(&g_env, NULL, (jobject)&g_dummy_class, 1, 1, 1);
      CHECK(ok==JNI_TRUE && g_link_smooth && g_link_begin_mid && g_link_end_mid && g_link_rtt_mid && g_link_stretch_us==0,"host + smooth=1 -> smooth link on, stretch reset");
      Java_com_mgba_android_EmulatorEngine_nativeLinkStop(&g_env, NULL);
      CHECK(!g_link_smooth && !g_link_begin_mid && !g_link_end_mid && !g_link_rtt_mid && !g_link_inflight,"nativeLinkStop switches it off and clears the method ids");
      ok = Java_com_mgba_android_EmulatorEngine_nativeLinkStart(&g_env, NULL, (jobject)&g_dummy_class, 1, 1, 0);
      CHECK(ok==JNI_TRUE && !g_link_smooth && !g_link_begin_mid,"smooth=0 -> blocking exchange as before");
      Java_com_mgba_android_EmulatorEngine_nativeLinkStop(&g_env, NULL);
      ok = Java_com_mgba_android_EmulatorEngine_nativeLinkStart(&g_env, NULL, (jobject)&g_dummy_class, 0, 1, 1);
      CHECK(ok==JNI_TRUE && !g_link_smooth,"a child never uses it (its side is unchanged)");
      Java_com_mgba_android_EmulatorEngine_nativeLinkStop(&g_env, NULL);
      g_smooth_methods_present = 0; g_exc_cleared = 0;
      ok = Java_com_mgba_android_EmulatorEngine_nativeLinkStart(&g_env, NULL, (jobject)&g_dummy_class, 1, 1, 1);
      CHECK(ok==JNI_TRUE && !g_link_smooth && g_exc_cleared==3,"missing split-phase methods: link still starts (blocking), each failed lookup's pending exception cleared");
      Java_com_mgba_android_EmulatorEngine_nativeLinkStop(&g_env, NULL);
      g_smooth_methods_present = 1;
    }

    /* ======================= LINK TIMING (per-game cap on the host's emulated transfer time) ======================= */
    printf("== LINK TIMING: the cap a session gets follows the setting and the ROM header title (Auto recognises Four Swords)\n");
    {
      static uint32_t rom_fs[64], rom_other[64], rom_short[8];
      memset(rom_fs, 0, sizeof rom_fs);       memcpy((uint8_t *)rom_fs + 0xA0, "GBAZELDA", 8);
      memset(rom_other, 0, sizeof rom_other); memcpy((uint8_t *)rom_other + 0xA0, "POKEMON EMER", 12);
      memset(rom_short, 0, sizeof rom_short);                       /* 32 bytes: no header title to read */
      const uint32_t MAXC = LINK_STRETCH_MAX_US, COMPAT = LINK_STRETCH_COMPAT_MAX_US;
      CHECK(COMPAT < MAXC,"the Compatible cap is shorter than the Smooth cap");
      CHECK(g_link_timing_mode==LINK_TIMING_AUTO,"the setting defaults to Auto");
      CHECK(timing_session_cap(true, rom_fs, sizeof rom_fs, LINK_TIMING_AUTO)==COMPAT,"Auto + the Four Swords header -> the Compatible cap");
      CHECK(timing_session_cap(true, rom_other, sizeof rom_other, LINK_TIMING_AUTO)==MAXC,"Auto + any other game -> the Smooth cap, exactly as before this change");
      CHECK(timing_session_cap(true, NULL, 0, LINK_TIMING_AUTO)==MAXC && timing_session_cap(true, rom_short, sizeof rom_short, LINK_TIMING_AUTO)==MAXC,
            "Auto + no readable header (no ROM image / a truncated one) -> the Smooth cap");
      CHECK(timing_session_cap(true, rom_fs, sizeof rom_fs, LINK_TIMING_SMOOTH)==MAXC,"Smooth forces the long transfers even for Four Swords");
      CHECK(timing_session_cap(true, rom_other, sizeof rom_other, LINK_TIMING_COMPAT)==COMPAT,"Compatible forces the short transfers for any game");
      CHECK(timing_session_cap(true, rom_fs, sizeof rom_fs, 77)==COMPAT && timing_session_cap(true, rom_other, sizeof rom_other, -1)==MAXC,
            "an unknown mode value acts as Auto (a stale or corrupt preference cannot break the link)");
      CHECK(timing_session_cap(false, rom_fs, sizeof rom_fs, LINK_TIMING_AUTO)==COMPAT,"a child resolves it too (it only matters on the host, but both logs then agree)");
      /* no inheritance between sessions, and a setting change applies at the NEXT start only */
      CHECK(timing_session_cap(true, rom_fs, sizeof rom_fs, LINK_TIMING_AUTO)==COMPAT && timing_session_cap(true, rom_other, sizeof rom_other, LINK_TIMING_AUTO)==MAXC,
            "a Four Swords session's cap is not inherited by the next session");
      reset_world(true, 0x6003, 0); g_core_obj.board = &gba; g_link_gba = NULL; g_link_active = false;
      gba.memory.rom = rom_fs; gba.memory.romSize = sizeof rom_fs;
      Java_com_mgba_android_EmulatorEngine_nativeLinkSetTimingMode(&g_env, NULL, LINK_TIMING_AUTO);
      jboolean ok = Java_com_mgba_android_EmulatorEngine_nativeLinkStart(&g_env, NULL, (jobject)&g_dummy_class, 1, 1, 1);
      Java_com_mgba_android_EmulatorEngine_nativeLinkSetTimingMode(&g_env, NULL, LINK_TIMING_SMOOTH);
      CHECK(ok==JNI_TRUE && g_link_stretch_cap_us==COMPAT,"changing the setting while linked leaves the running session's cap alone");
      Java_com_mgba_android_EmulatorEngine_nativeLinkStop(&g_env, NULL);
      CHECK(timing_session_cap(true, rom_fs, sizeof rom_fs, LINK_TIMING_SMOOTH)==MAXC,"...and the next session uses the new setting");
      Java_com_mgba_android_EmulatorEngine_nativeLinkSetTimingMode(&g_env, NULL, LINK_TIMING_AUTO);   /* leave the global as the app's default */
    }

    printf("== LINK TIMING: the cap bounds the adaptive transfer time; the round-trip measurement and fast links are untouched\n");
    {
      /* the same 3 ms round trip under both caps: only the transfer time differs, the measured round trip is the network's */
      reset_world(true, 0x6003, 0); SMOOTH_ON(); g_link_stretch_cap_us = LINK_STRETCH_COMPAT_MAX_US;
      g_end_hook = slow_end; g_rtt_hook = rtt_3000;
      uint16_t o = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083); gba.sio.siocnt = o;
      timing_advance(&gba, 6410);
      CHECK(g_link_rtt_ewma_us==3000,"Compatible: the round-trip estimate is still the real 3000 us (the cap does not clip the measurement)");
      CHECK(g_link_stretch_us==LINK_STRETCH_COMPAT_MAX_US,"Compatible: a 3 ms round trip (3.6 ms wanted) is cut to the Compatible cap");
      reset_world(true, 0x6003, 0); SMOOTH_ON();                /* default cap */
      g_end_hook = slow_end; g_rtt_hook = rtt_3000;
      o = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083); gba.sio.siocnt = o;
      timing_advance(&gba, 6410);
      CHECK(g_link_rtt_ewma_us==3000 && g_link_stretch_us==3000u+3000u/8u+200u,"Smooth: the same round trip gives 3.575 ms, the unchanged round trip + 12% + 0.2 ms rule");
      /* a fast link (local / good Wi-Fi) is below both caps: Compatible must not slow it down */
      for (int pass = 0; pass < 2; pass++) {
        reset_world(true, 0x6003, 0); SMOOTH_ON(); g_link_stretch_cap_us = pass ? LINK_STRETCH_COMPAT_MAX_US : LINK_STRETCH_MAX_US;
        g_end_hook = slow_end; g_rtt_hook = rtt_500;
        o = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083); gba.sio.siocnt = o;
        timing_advance(&gba, 6410);
        CHECK(g_link_stretch_us==500u+500u/8u+200u,pass?"Compatible: a 0.5 ms round trip still gives 0.762 ms (below the cap, unchanged)":"Smooth: a 0.5 ms round trip gives 0.762 ms");
      }
    }

    printf("== LINK TIMING: with the Compatible cap a host transfer lasts the capped time in EMULATED cycles (what the child sees as word spacing)\n");
    {
      reset_world(true, 0x6003, 0); SMOOTH_ON(); g_link_stretch_cap_us = LINK_STRETCH_COMPAT_MAX_US;
      g_end_hook = very_slow_end; g_rtt_hook = rtt_20000;       /* a slow link: the wanted time is far above either cap */
      uint16_t o = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083); gba.sio.siocnt = o;
      timing_advance(&gba, 6410);
      const int32_t cyc = link_stretch_cycles();
      CHECK(g_link_stretch_us==1500 && cyc==25165,"1.5 ms of emulated time = 25,165 cycles");
      CHECK(cyc < (int32_t)(((uint64_t)LINK_STRETCH_MAX_US * GBA_AUDIO_CLOCK) / 1000000ull),"...well under the 4.5 ms the Smooth cap would give (75,497 cycles)");
      g_end_calls = 0;
      o = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083); gba.sio.siocnt = o;
      timing_advance(&gba, cyc-1);
      CHECK((gba.sio.siocnt & 0x0080)!=0 && g_end_calls==0,"the next transfer is still busy one cycle before the capped time");
      timing_advance(&gba, 1);
      CHECK((gba.sio.siocnt & 0x0080)==0 && g_end_calls==1 && g_irq_count==2,"...and completes exactly then, with its IRQ");
      /* Thirteen back-to-back transfers (one Four Swords round) with a ROM gap of ~0.27 ms (4,530 cycles) between them
       * take 13 x (25,165 + 4,530) cycles = ~23 ms: inside the ~33.4 ms between two of the master's probes. */
      int64_t t0 = gba.timing.now; int done_ok = 1;
      for (int i = 0; i < 13; i++) {
        o = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083); gba.sio.siocnt = o;
        timing_advance(&gba, cyc);
        if (gba.sio.siocnt & 0x0080) done_ok = 0;
        timing_advance(&gba, 4530);                             /* the ROM's own gap */
      }
      const double ms = (double)(gba.timing.now - t0) / GBA_AUDIO_CLOCK * 1000.0;
      CHECK(done_ok && ms < 0.75*33.4,"13 transfers incl. ROM gaps fit in 75% of a 33.4 ms probe period (leaving slack for the ROM's own jitter)");
      printf("      (13 transfers took %.2f ms of emulated time)\n", ms);
    }

    printf("\n%s (%d failure(s))\n", fails?"FAILED":"ALL PASSED", fails);
    return fails?1:0;
}
