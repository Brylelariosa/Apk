#!/usr/bin/env bash
# Two-device simulation of the link: two sim_dev processes (host + child) running the REAL
# link code extracted from mgba_jni.c, joined by UDP on loopback with an artificial one-way delay.
#   run_sim.py     scenarios 1-14: the 16-word packet ROM model. Reproduces the captured failure with the old
#                  one-word-per-frame behaviour, then checks the clock-tie fix and smooth link (and that neither
#                  can deadlock). ~3 minutes.
#   run_sim_fs.py  scenarios F1-F4: the Four Swords link-up cadence model — the old 4.5 ms transfers against the
#                  per-game Compatible timing (link_timing.h). ~45 seconds.
# Usage: ./run_sim.sh [all|legacy|fs]      (default: all)    Needs gcc + python3.
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1   # run_sim*.py import sim_lib from this folder: no __pycache__ left in the tree
WHICH="${1:-all}"
case "$WHICH" in all|legacy|fs) ;; *) echo "usage: $0 [all|legacy|fs]" >&2; exit 2;; esac
python3 extract.py
gcc -std=gnu11 -O1 -Wall -Wextra -Wno-unused-function -Wno-unused-parameter -Wno-unused-variable -g \
    -fsanitize=address,undefined -fno-omit-frame-pointer sim_dev.c -o sim_dev -lpthread -lm
rc=0
if [ "$WHICH" != "fs" ];     then python3 run_sim.py    || rc=1; fi
if [ "$WHICH" != "legacy" ]; then python3 run_sim_fs.py || rc=1; fi
rm -f sim_dev extracted_r*.c
exit $rc
