# Sound FX Maker

An Android app that procedurally generates retro-game sound effects — no
recordings, no samples, no internet. Pick a category (Pickup, Laser,
Explosion, Power-Up, Hit, Jump, Blip, or fully Random), and a native C++ DSP
engine synthesizes a one-shot sound from scratch on every tap. Tweak it,
mutate it, or hand-adjust the waveform, envelope, and filter sliders, then
save the ones you like to a local library as WAV files.

## How a sound is made

1. **Kotlin (`ui`/`data`)** picks a category and randomizes ~23 synthesis
   parameters (waveform shape, pitch, envelope, filters, vibrato, arpeggio,
   etc.) within ranges tuned per category — this is `SfxPresetGenerator`.
2. Those parameters cross a JNI boundary (`NativeSynthEngine`) as a flat
   `FloatArray`.
3. **C++ (`app/src/main/cpp/core`)** renders the actual audio: an oscillator
   (`wave_generator`), an attack/sustain/decay envelope (`envelope`), and a
   chain of filters/phaser (`effects`) are combined sample-by-sample in
   `synth_engine.cpp` into 16-bit PCM.
4. The PCM buffer comes back to Kotlin for live playback (`AudioTrack`) or
   gets written to a `.wav` file (`WavExporter`) when saved.

The split is deliberate: the native side is a pure, allocation-light render
loop (the only place performance matters), while all the "what should this
sound like" business logic stays in Kotlin, where it's easy to iterate on
without a native rebuild.

## Project layout

```
app/src/main/cpp/core/     DSP engine (waveform, envelope, filters, render loop)
app/src/main/cpp/jni_bridge.cpp   Thin JNI marshalling layer only
app/src/main/java/.../core/       SfxParams, WaveType, NativeSynthEngine (JNI contract)
app/src/main/java/.../data/       SfxPresetGenerator (randomization), SoundRepository (I/O)
app/src/main/java/.../audio/      AudioTrack playback, WAV export
app/src/main/java/.../ui/         ViewModel + Jetpack Compose screens
```

## Building

This repo's `.github/workflows/build-apk.yml` builds automatically from a
zip pushed to `uploads/`. To build locally instead: open in Android Studio
(Jellyfish+) or run `./gradlew assembleDebug` with the Android NDK
25.2.9519653 and CMake 3.22.1 installed.

## APK size

A few deliberate choices keep the build small:

- **Two ABIs, not three** — `arm64-v8a` + `armeabi-v7a` only. `x86_64` has no
  real-device audience anymore; add it back in `app/build.gradle.kts` if you
  test on an x86_64 emulator image.
- **Static STL** (`ANDROID_STL=c++_static`) — with only one native library in
  the app, statically linking the C++ runtime avoids also shipping a separate
  `libc++_shared.so` per ABI.
- **R8 + resource shrinking** on release builds (`isMinifyEnabled` /
  `isShrinkResources`), with `android.enableR8.fullMode=true` for the more
  aggressive shrinking pass. `proguard-rules.pro` keeps the one rule this
  actually depends on: native methods must survive renaming, or the JNI
  bridge breaks.
- **Native debug symbols stripped** from the release `.so`
  (`debugSymbolLevel = "NONE"`).
- **No material-icons-extended** — only the small curated icon set bundled
  with `material3` is used, which avoids a multi-megabyte icon dependency.

These are all release-build-only except the ABI/STL changes, which apply
regardless of build type. Worth noting: `build-apk.yml` only builds
`assembleRelease` when `KEYSTORE_BASE64` is configured as a secret — without
it, every CI run produces an unminified debug APK, so most of the size win
above won't show up until signing is set up.

## Not yet built (by design, for now)

Recording your own sounds, importing/downloading external audio, and mixing
multiple sounds together are natural next steps but are intentionally left
out of this pass — the current scope is entirely code-generated audio.
