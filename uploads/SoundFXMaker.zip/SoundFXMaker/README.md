# Sound FX Maker

An Android sound-effects maker with two modes: **Normal**, where you pick
from ready-made preset categories, and **Studio**, where you build a sound
from scratch with full slider control, record your own with the mic, and
edit, trim, combine, or sequence sounds already in your library. A native
C++ DSP engine handles synthesis; everything else — recording, mixing,
trimming, the library — is plain Kotlin working on raw 16-bit PCM.

## How a sound is made

1. **Kotlin (`ui`/`data`)** picks a category and randomizes ~23 synthesis
   parameters (waveform shape, pitch, envelope, filters, vibrato, arpeggio,
   etc.) within ranges tuned per category — this is `SfxPresetGenerator`.
2. Those parameters cross a JNI boundary (`NativeSynthEngine`) as a flat
   `FloatArray`.
3. **C++ (`app/src/main/cpp/core`)** renders the actual audio: an oscillator
   (`wave_generator`), an attack/sustain/decay envelope (`envelope`), and a
   chain of filters/phaser (`effects`) are combined sample-by-sample in
   `synth_engine.cpp` into 16-bit PCM.
4. The PCM buffer comes back to Kotlin for live playback (`AudioTrack`) or
   gets written to a `.wav` file (`WavExporter`) when saved.

The split is deliberate: the native side is a pure, allocation-light render
loop (the only place performance matters), while all the "what should this
sound like" business logic stays in Kotlin, where it's easy to iterate on
without a native rebuild.

Slider drags in Custom mode don't hit this pipeline on every tick — the
displayed values update instantly, but the actual render + playback is
debounced (120ms) in `SoundFxViewModel`, or dragging would spam overlapping
`AudioTrack` instances instead of giving smooth feedback.

Recording, mixing, and trimming all skip the synth engine entirely and stay
in Kotlin:
- `SfxAudioRecorder` captures the mic via `AudioRecord` at the same 16-bit
  PCM mono format the synth engine outputs, so a recording drops straight
  into the same save/play/library pipeline as a generated sound.
- `SoundMixer` combines two saved sounds two ways — `mix()` layers them by
  summing samples (Studio's "Combine"), `concatenate()` plays one after the
  other (Studio's "Continue"). `WavReader` reads them back off disk first,
  since a saved sound only exists as a `.wav` file at that point.
- Trimming reads a saved sound's samples, slices them to the selected
  range, and saves the result as a new entry — non-destructive, the
  original is untouched.

Every saved sound tracks a `SoundSource` (generated / recorded / mixed /
trimmed) and its duration. Only `generated` sounds carry synthesis
parameters, which is what the library's Edit action checks: on a generated
sound it re-opens the sliders; on anything else it opens the trim dialog
instead, since there are no parameters to re-edit.

Playback progress (the bar under the waveform, and under a playing item in
the library) is a simple elapsed-time simulation against the sound's known
duration, not a poll of the actual `AudioTrack`/`MediaPlayer` position —
simpler, and close enough for a visual cue.

## Project layout

```
app/src/main/cpp/core/     DSP engine (waveform, envelope, filters, render loop)
app/src/main/cpp/jni_bridge.cpp   Thin JNI marshalling layer only
app/src/main/java/.../core/       SfxParams, WaveType, NativeSynthEngine (JNI contract)
app/src/main/java/.../data/       SfxPresetGenerator, SoundRepository, SoundSource, SavedSound
app/src/main/java/.../audio/      AudioTrack playback, mic recording, WAV read/write, mixing
app/src/main/java/.../ui/         ViewModel + Jetpack Compose screens
```

## Building

This repo's `.github/workflows/build-apk.yml` builds automatically from a
zip pushed to `uploads/`. To build locally instead: open in Android Studio
(Jellyfish+) or run `./gradlew assembleDebug` with the Android NDK
25.2.9519653 and CMake 3.22.1 installed.

## APK size

A few deliberate choices keep the build small:

- **Two ABIs, not three** — `arm64-v8a` + `armeabi-v7a` only. `x86_64` has no
  real-device audience anymore; add it back in `app/build.gradle.kts` if you
  test on an x86_64 emulator image.
- **Static STL** (`ANDROID_STL=c++_static`) — with only one native library in
  the app, statically linking the C++ runtime avoids also shipping a separate
  `libc++_shared.so` per ABI.
- **R8 + resource shrinking** on release builds (`isMinifyEnabled` /
  `isShrinkResources`), with `android.enableR8.fullMode=true` for the more
  aggressive shrinking pass. `proguard-rules.pro` keeps the one rule this
  actually depends on: native methods must survive renaming, or the JNI
  bridge breaks.
- **Native debug symbols stripped** from the release `.so`
  (`debugSymbolLevel = "NONE"`).
- **No material-icons-extended** — only the small curated icon set bundled
  with `material3` is used, which avoids a multi-megabyte icon dependency.

These are all release-build-only except the ABI/STL changes, which apply
regardless of build type. Worth noting: `build-apk.yml` only builds
`assembleRelease` when `KEYSTORE_BASE64` is configured as a secret — without
it, every CI run produces an unminified debug APK, so most of the size win
above won't show up until signing is set up.

## Not yet built (by design, for now)

Importing/downloading external audio files isn't in this pass — recording,
combining, and trimming cover "bring your own sound" for now. Also still
open: a fade in/out safety guard on every render to rule out clicks from
presets that use a zero attack or decay time, and real (rather than
simulated) playback-position tracking for the progress bars.
