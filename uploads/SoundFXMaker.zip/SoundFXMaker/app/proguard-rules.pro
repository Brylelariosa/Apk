# Release builds run R8 (isMinifyEnabled = true), so this rule is load-bearing:
# native methods must never be renamed or stripped, or the JNI symbol the
# native .so looks up (Java_com_soundfxmaker_app_core_NativeSynthEngine_generate)
# stops matching and the app crashes with UnsatisfiedLinkError at startup.
-keepclasseswithmembernames class * {
    native <methods>;
}

# Everything else here is deliberately empty: Compose and AndroidX ship their
# own consumer ProGuard rules inside their AARs, so R8 already knows what it
# needs to keep for them without us duplicating those rules here.
