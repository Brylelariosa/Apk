package com.soundfxmaker.app.data

import com.soundfxmaker.app.core.SfxCategory
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class SfxPresetGeneratorTest {

    @Test
    fun `every category generates params within their documented ranges`() {
        val random = Random(42)
        SfxCategory.entries.forEach { category ->
            repeat(20) {
                val params = SfxPresetGenerator.generate(category, random)
                assertInRange(category, "baseFreq", params.baseFreq, 0f, 1f)
                assertInRange(category, "freqLimit", params.freqLimit, 0f, 1f)
                assertInRange(category, "freqRamp", params.freqRamp, -1f, 1f)
                assertInRange(category, "dutyCycle", params.dutyCycle, 0f, 1f)
                assertInRange(category, "attackTime", params.attackTime, 0f, 1f)
                assertInRange(category, "sustainTime", params.sustainTime, 0f, 1f)
                assertInRange(category, "decayTime", params.decayTime, 0f, 1f)
                assertInRange(category, "volume", params.volume, 0f, 1f)
            }
        }
    }

    @Test
    fun `mutate keeps jittered fields within their valid ranges`() {
        val random = Random(7)
        val base = SfxPresetGenerator.generate(SfxCategory.LASER_SHOOT, random)
        repeat(50) {
            val mutated = SfxPresetGenerator.mutate(base, random = random)
            assertInRange(SfxCategory.LASER_SHOOT, "baseFreq", mutated.baseFreq, 0f, 1f)
            assertInRange(SfxCategory.LASER_SHOOT, "dutyCycle", mutated.dutyCycle, 0f, 1f)
            assertInRange(SfxCategory.LASER_SHOOT, "vibratoDepth", mutated.vibratoDepth, 0f, 1f)
            assertInRange(SfxCategory.LASER_SHOOT, "attackTime", mutated.attackTime, 0f, 1f)
            assertInRange(SfxCategory.LASER_SHOOT, "sustainTime", mutated.sustainTime, 0f, 1f)
            assertInRange(SfxCategory.LASER_SHOOT, "decayTime", mutated.decayTime, 0f, 1f)
            assertInRange(SfxCategory.LASER_SHOOT, "lpfCutoff", mutated.lpfCutoff, 0f, 1f)
        }
    }

    @Test
    fun `custom mode returns plain defaults, not a randomized preset`() {
        val a = SfxPresetGenerator.generate(SfxCategory.CUSTOM, Random(1))
        val b = SfxPresetGenerator.generate(SfxCategory.CUSTOM, Random(2))
        assertEquals(a, b) // different seeds, same result - custom isn't randomized
    }

    private fun assertInRange(category: SfxCategory, label: String, value: Float, min: Float, max: Float) {
        assertTrue("[$category] $label was $value, expected [$min, $max]", value in min..max)
    }
}
