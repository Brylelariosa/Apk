package com.soundfxmaker.app.audio

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

class WavRoundTripTest {

    @get:Rule
    val tempFolder = TemporaryFolder()

    @Test
    fun `samples written by WavExporter read back identically via WavReader`() {
        val samples = shortArrayOf(0, 1000, -1000, Short.MAX_VALUE, Short.MIN_VALUE, -1, 1)
        val file = tempFolder.newFile("test.wav")

        WavExporter.writeWav(file, samples, sampleRate = 44100)
        val readBack = WavReader.readSamples(file)

        assertArrayEquals(samples, readBack)
    }

    @Test
    fun `empty buffer round-trips to an empty buffer`() {
        val file = tempFolder.newFile("empty.wav")
        WavExporter.writeWav(file, ShortArray(0), sampleRate = 44100)
        val readBack = WavReader.readSamples(file)
        assertEquals(0, readBack.size)
    }

    @Test
    fun `file size is exactly the 44-byte header plus the PCM payload`() {
        val samples = ShortArray(100) { it.toShort() }
        val file = tempFolder.newFile("sized.wav")
        WavExporter.writeWav(file, samples, sampleRate = 44100)
        assertEquals(44 + 100 * 2, file.length().toInt())
    }
}
