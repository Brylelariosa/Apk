package com.soundfxmaker.app.core

import org.junit.Assert.assertEquals
import org.junit.Test

/**
 * [SfxParams.toFloatArray] and native's `SynthParams::FromFloatArray`
 * (app/src/main/cpp/core/synth_engine.cpp) must agree on field count and
 * order — there's no compiler to check that across the JNI boundary, so
 * this is the next best thing. If this test starts failing after adding a
 * field to SfxParams, update FromFloatArray to match before touching this.
 */
class SfxParamsTest {

    @Test
    fun `toFloatArray has exactly 23 elements`() {
        val array = SfxParams().toFloatArray()
        assertEquals(23, array.size)
    }

    @Test
    fun `waveType is always the first element`() {
        val array = SfxParams(waveType = WaveType.NOISE).toFloatArray()
        assertEquals(WaveType.NOISE.nativeValue.toFloat(), array[0])
    }

    @Test
    fun `volume is always the last element`() {
        val array = SfxParams(volume = 0.42f).toFloatArray()
        assertEquals(0.42f, array[array.size - 1], 0.0001f)
    }
}
