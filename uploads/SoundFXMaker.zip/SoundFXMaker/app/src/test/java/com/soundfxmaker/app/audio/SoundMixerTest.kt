package com.soundfxmaker.app.audio

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Test

class SoundMixerTest {

    @Test
    fun `mix sums matching-length buffers`() {
        val a = shortArrayOf(1000, -1000, 500)
        val b = shortArrayOf(2000, 2000, -500)
        val result = SoundMixer.mix(a, b)
        assertEquals(3, result.size)
        assertEquals(3000, result[0].toInt())
        assertEquals(1000, result[1].toInt())
        assertEquals(0, result[2].toInt())
    }

    @Test
    fun `mix clamps to 16-bit range instead of overflowing`() {
        val a = shortArrayOf(30000, -30000)
        val b = shortArrayOf(30000, -30000)
        val result = SoundMixer.mix(a, b)
        assertEquals(Short.MAX_VALUE, result[0])
        assertEquals(Short.MIN_VALUE, result[1])
    }

    @Test
    fun `mix pads the shorter buffer with silence rather than truncating`() {
        val a = shortArrayOf(100, 200, 300, 400)
        val b = shortArrayOf(10, 20)
        val result = SoundMixer.mix(a, b)
        assertEquals(4, result.size)
        assertEquals(110, result[0].toInt())
        assertEquals(220, result[1].toInt())
        assertEquals(300, result[2].toInt()) // b contributes nothing past its own length
        assertEquals(400, result[3].toInt())
    }

    @Test
    fun `concatenate preserves order and total length`() {
        val a = shortArrayOf(1, 2, 3)
        val b = shortArrayOf(4, 5)
        val result = SoundMixer.concatenate(a, b)
        assertArrayEquals(shortArrayOf(1, 2, 3, 4, 5), result)
    }

    @Test
    fun `concatenate with an empty buffer returns the other unchanged`() {
        val a = shortArrayOf(7, 8, 9)
        val result = SoundMixer.concatenate(a, ShortArray(0))
        assertArrayEquals(a, result)
    }
}
