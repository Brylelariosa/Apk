#pragma once

namespace soundfx {

// A simple attack/sustain/decay envelope, in samples. There's no separate
// "release" phase — sound effects are one-shots, not held notes.
struct EnvelopeShape {
    long attackSamples = 0;
    long sustainSamples = 0;
    long decaySamples = 0;
    float sustainPunch = 0.0f;
};

long EnvelopeTotalSamples(const EnvelopeShape& shape);

// Returns the envelope multiplier at the given absolute sample index. Can
// briefly exceed 1.0 when sustainPunch > 0 — that overshoot is intentional
// (it's what gives percussive sounds their snap) and gets clamped later at
// the final PCM conversion step.
float EvaluateEnvelope(const EnvelopeShape& shape, long sampleIndex);

}  // namespace soundfx
