#include "envelope.h"

#include <algorithm>

namespace soundfx {

long EnvelopeTotalSamples(const EnvelopeShape& shape) {
    return shape.attackSamples + shape.sustainSamples + shape.decaySamples;
}

float EvaluateEnvelope(const EnvelopeShape& shape, long sampleIndex) {
    if (sampleIndex < shape.attackSamples) {
        if (shape.attackSamples == 0) return 1.0f;
        return static_cast<float>(sampleIndex) / static_cast<float>(shape.attackSamples);
    }

    long sustainStart = shape.attackSamples;
    long decayStart = shape.attackSamples + shape.sustainSamples;
    long total = EnvelopeTotalSamples(shape);

    if (sampleIndex < decayStart) {
        long into = sampleIndex - sustainStart;
        float progress = shape.sustainSamples > 0
                              ? static_cast<float>(into) / static_cast<float>(shape.sustainSamples)
                              : 1.0f;
        // A decaying "punch" right at the start of sustain instead of a flat
        // plateau — this is what gives coins/hits their percussive snap.
        return 1.0f + shape.sustainPunch * (1.0f - progress);
    }

    if (sampleIndex < total) {
        long into = sampleIndex - decayStart;
        float progress = shape.decaySamples > 0
                              ? static_cast<float>(into) / static_cast<float>(shape.decaySamples)
                              : 1.0f;
        float remaining = 1.0f - progress;
        return std::max(0.0f, remaining * remaining);
    }

    return 0.0f;
}

}  // namespace soundfx
