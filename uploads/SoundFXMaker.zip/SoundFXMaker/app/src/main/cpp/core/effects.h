#pragma once

#include <vector>

namespace soundfx {

// One-pole low-pass filter with a settable normalized cutoff (0..1).
class LowPassFilter {
  public:
    void SetCutoff(float normalizedCutoff);
    float Process(float input);

  private:
    float state_ = 0.0f;
    float cutoff_ = 1.0f;
};

// One-pole high-pass filter with a settable normalized cutoff (0..1).
class HighPassFilter {
  public:
    void SetCutoff(float normalizedCutoff);
    float Process(float input);

  private:
    float prevIn_ = 0.0f;
    float prevOut_ = 0.0f;
    float cutoff_ = 0.0f;
};

// Short circular-buffer comb filter used for the "phaser" effect: mixes the
// input with a delayed copy of itself.
class Phaser {
  public:
    explicit Phaser(int maxDelaySamples = 1200);
    void SetOffsetSamples(int offset);
    float Process(float input);

  private:
    std::vector<float> buffer_;
    int writeIndex_ = 0;
    int offset_ = 0;
};

}  // namespace soundfx
