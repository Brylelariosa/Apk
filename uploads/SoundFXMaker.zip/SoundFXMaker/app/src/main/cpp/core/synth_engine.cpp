#include "synth_engine.h"

#include <algorithm>
#include <cmath>

#include "effects.h"
#include "envelope.h"
#include "wave_generator.h"

namespace soundfx {

namespace {
constexpr double kTwoPi = 6.283185307179586;

float ClampF(float v, float lo, float hi) { return std::max(lo, std::min(hi, v)); }
}  // namespace

SynthParams SynthParams::FromFloatArray(const std::vector<float>& v) {
    SynthParams p;
    if (v.size() < 23) return p;  // malformed input from the JVM side — fall back to safe defaults
    size_t i = 0;
    p.waveType = static_cast<int>(v[i++]);
    p.baseFreq = v[i++];
    p.freqLimit = v[i++];
    p.freqRamp = v[i++];
    p.dutyCycle = v[i++];
    p.dutyRamp = v[i++];
    p.vibratoDepth = v[i++];
    p.vibratoSpeed = v[i++];
    p.attackTime = v[i++];
    p.sustainTime = v[i++];
    p.sustainPunch = v[i++];
    p.decayTime = v[i++];
    p.lpfCutoff = v[i++];
    p.lpfCutoffRamp = v[i++];
    p.lpfResonance = v[i++];
    p.hpfCutoff = v[i++];
    p.hpfCutoffRamp = v[i++];
    p.phaserOffset = v[i++];
    p.phaserRamp = v[i++];
    p.repeatSpeed = v[i++];
    p.arpeggioMod = v[i++];
    p.arpeggioSpeed = v[i++];
    p.volume = v[i++];
    return p;
}

std::vector<int16_t> SynthEngine::Render(const SynthParams& params, int64_t seed, int sampleRate) {
    const long kMaxSamples = static_cast<long>(sampleRate) * 6;  // safety cap: 6 seconds

    // --- Envelope shape drives the overall duration ---
    EnvelopeShape envelope;
    envelope.attackSamples = static_cast<long>(params.attackTime * params.attackTime * sampleRate * 1.0);
    envelope.sustainSamples = std::max<long>(1, static_cast<long>(params.sustainTime * sampleRate * 3.0));
    envelope.decaySamples = static_cast<long>(params.decayTime * params.decayTime * sampleRate * 3.0);
    envelope.sustainPunch = params.sustainPunch;

    long totalSamples = std::min(kMaxSamples, EnvelopeTotalSamples(envelope));
    if (totalSamples <= 0) totalSamples = 1;

    // --- Frequency setup. Squaring the normalized param gives finer control
    // over the (perceptually more useful) low end of the range. ---
    double baseFreqHz = 40.0 + static_cast<double>(params.baseFreq) * params.baseFreq * 4000.0;
    double freqLimitHz = params.freqLimit > 0.0f
                              ? 40.0 + static_cast<double>(params.freqLimit) * params.freqLimit * 4000.0
                              : 0.0;
    double freq = baseFreqHz;
    double freqRampPerSample = params.freqRamp * baseFreqHz * 0.00015;
    // Never let pitch ramp past ~Nyquist — beyond that the waveform aliases
    // into harsh digital noise instead of just sounding "very high pitched".
    const double kMaxFreqHz = sampleRate * 0.45;

    double dutyCycle = ClampF(params.dutyCycle, 0.02f, 0.98f);
    double dutyRampPerSample = params.dutyRamp * 0.00005;

    // --- Vibrato ---
    double vibratoPhase = 0.0;
    double vibratoPhaseStep = kTwoPi * (0.5 + params.vibratoSpeed * 20.0) / sampleRate;

    // --- Arpeggio: a single pitch jump partway through the note ---
    long arpeggioAtSample = params.arpeggioSpeed > 0.0f
                                 ? static_cast<long>(static_cast<double>(totalSamples) * (1.0 - params.arpeggioSpeed))
                                 : -1;
    bool arpeggioApplied = false;
    double arpeggioMultiplier = std::pow(2.0, params.arpeggioMod);

    // --- Repeat / retrigger: restart pitch + phase periodically for a
    // stuttering "laser burst" style effect, while the envelope keeps going. ---
    long repeatIntervalSamples =
        params.repeatSpeed > 0.0f
            ? std::max<long>(sampleRate / 20, static_cast<long>((1.0f - params.repeatSpeed) * sampleRate))
            : 0;

    // --- Filters ---
    LowPassFilter lpf;
    lpf.SetCutoff(0.05f + params.lpfCutoff * params.lpfCutoff * 0.9f);
    HighPassFilter hpf;
    hpf.SetCutoff(params.hpfCutoff * params.hpfCutoff);
    Phaser phaser(1200);
    int basePhaserOffset = static_cast<int>(params.phaserOffset * 400);

    unsigned int noiseState = 0x9e3779b9u ^ static_cast<unsigned int>(seed) ^ static_cast<unsigned int>(seed >> 32);
    double phase = 0.0;

    std::vector<float> floatSamples(static_cast<size_t>(totalSamples));

    for (long n = 0; n < totalSamples; ++n) {
        if (repeatIntervalSamples > 0 && n > 0 && n % repeatIntervalSamples == 0) {
            freq = baseFreqHz;
            phase = 0.0;
            vibratoPhase = 0.0;
            arpeggioApplied = false;
        }

        if (!arpeggioApplied && arpeggioAtSample >= 0 && n >= arpeggioAtSample) {
            freq *= arpeggioMultiplier;
            arpeggioApplied = true;
        }

        double vibrato = params.vibratoDepth > 0.0f ? 1.0 + std::sin(vibratoPhase) * params.vibratoDepth * 0.1 : 1.0;
        vibratoPhase += vibratoPhaseStep;

        double currentFreq = std::max(20.0, freq * vibrato);
        currentFreq = std::min(currentFreq, kMaxFreqHz);
        if (freqLimitHz > 0.0 && currentFreq < freqLimitHz) {
            // Ramping downward and hit the floor: stop shortening the note.
            currentFreq = freqLimitHz;
        }

        phase += currentFreq / sampleRate;
        while (phase >= 1.0) phase -= 1.0;

        dutyCycle = ClampF(static_cast<float>(dutyCycle + dutyRampPerSample), 0.02f, 0.98f);
        freq = std::min(kMaxFreqHz, std::max(20.0, freq + freqRampPerSample));

        float raw = GenerateWaveSample(static_cast<WaveType>(params.waveType), phase, static_cast<float>(dutyCycle),
                                        noiseState);
        float envValue = EvaluateEnvelope(envelope, n);

        float filtered = lpf.Process(raw);
        filtered = hpf.Process(filtered);
        if (basePhaserOffset != 0) {
            phaser.SetOffsetSamples(basePhaserOffset);
            filtered = phaser.Process(filtered);
        }

        floatSamples[static_cast<size_t>(n)] = filtered * envValue * params.volume;
    }

    // --- Safety fade in/out: a handful of presets use zero attack or decay,
    // which can otherwise start or end the buffer at non-zero amplitude —
    // an audible click. This ramps the first/last ~1.5ms regardless of what
    // the envelope itself did, which is short enough to be inaudible as a
    // "fade" but long enough to kill any discontinuity. ---
    const size_t fadeSamples = std::min<size_t>(64, floatSamples.size() / 2);
    for (size_t i = 0; i < fadeSamples; ++i) {
        float ramp = static_cast<float>(i) / static_cast<float>(fadeSamples);
        floatSamples[i] *= ramp;
        floatSamples[floatSamples.size() - 1 - i] *= ramp;
    }

    // --- Convert to 16-bit PCM with a simple hard limiter ---
    std::vector<int16_t> out(floatSamples.size());
    for (size_t i = 0; i < floatSamples.size(); ++i) {
        float v = ClampF(floatSamples[i], -1.0f, 1.0f);
        out[i] = static_cast<int16_t>(v * 32000.0f);
    }
    return out;
}

}  // namespace soundfx
