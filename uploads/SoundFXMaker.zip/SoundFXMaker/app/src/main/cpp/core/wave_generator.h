#pragma once

namespace soundfx {

enum class WaveType : int {
    kSquare = 0,
    kSawtooth = 1,
    kSine = 2,
    kNoise = 3,
    kTriangle = 4
};

// Returns one sample in [-1, 1] for the given wave type at the given phase
// [0, 1). noiseState is advanced in place and only used by kNoise, but is
// always threaded through so callers keep a single PRNG stream per voice.
float GenerateWaveSample(WaveType type, double phase, float dutyCycle, unsigned int& noiseState);

}  // namespace soundfx
