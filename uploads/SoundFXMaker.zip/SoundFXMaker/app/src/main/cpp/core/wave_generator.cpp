#include "wave_generator.h"

#include <cmath>

namespace soundfx {

namespace {
constexpr double kTwoPi = 6.283185307179586;

// xorshift32 — cheap, good enough statistically for audio noise, and fully
// deterministic given a seed (useful if we ever want reproducible previews).
float NextNoiseSample(unsigned int& state) {
    state ^= state << 13;
    state ^= state >> 17;
    state ^= state << 5;
    return (static_cast<float>(state) / 4294967295.0f) * 2.0f - 1.0f;
}
}  // namespace

float GenerateWaveSample(WaveType type, double phase, float dutyCycle, unsigned int& noiseState) {
    switch (type) {
        case WaveType::kSquare:
            return phase < dutyCycle ? 1.0f : -1.0f;
        case WaveType::kSawtooth:
            return static_cast<float>(2.0 * phase - 1.0);
        case WaveType::kSine:
            return static_cast<float>(std::sin(kTwoPi * phase));
        case WaveType::kNoise:
            return NextNoiseSample(noiseState);
        case WaveType::kTriangle: {
            double t = phase < 0.5 ? phase * 2.0 : (1.0 - phase) * 2.0;
            return static_cast<float>(t * 2.0 - 1.0);
        }
    }
    return 0.0f;
}

}  // namespace soundfx
