#pragma once

#include <cstdint>
#include <vector>

namespace soundfx {

// Mirrors SfxParams.kt field-for-field, in the same order — SfxParams.
// toFloatArray() on the Kotlin side and FromFloatArray() here must stay in
// sync, since that flat array is the entire JNI contract.
struct SynthParams {
    int waveType = 0;
    float baseFreq = 0.3f;
    float freqLimit = 0.0f;
    float freqRamp = 0.0f;
    float dutyCycle = 0.5f;
    float dutyRamp = 0.0f;
    float vibratoDepth = 0.0f;
    float vibratoSpeed = 0.0f;
    float attackTime = 0.0f;
    float sustainTime = 0.3f;
    float sustainPunch = 0.0f;
    float decayTime = 0.4f;
    float lpfCutoff = 1.0f;
    float lpfCutoffRamp = 0.0f;
    float lpfResonance = 0.0f;
    float hpfCutoff = 0.0f;
    float hpfCutoffRamp = 0.0f;
    float phaserOffset = 0.0f;
    float phaserRamp = 0.0f;
    float repeatSpeed = 0.0f;
    float arpeggioMod = 0.0f;
    float arpeggioSpeed = 0.0f;
    float volume = 0.5f;

    static SynthParams FromFloatArray(const std::vector<float>& values);
};

class SynthEngine {
  public:
    // Renders params to 16-bit PCM mono samples. Duration is derived entirely
    // from the envelope (attack + sustain + decay), capped at 6 seconds.
    static std::vector<int16_t> Render(const SynthParams& params, int sampleRate = 44100);
};

}  // namespace soundfx
