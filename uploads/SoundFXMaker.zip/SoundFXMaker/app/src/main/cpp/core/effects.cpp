#include "effects.h"

#include <algorithm>

namespace soundfx {

void LowPassFilter::SetCutoff(float normalizedCutoff) {
    cutoff_ = std::clamp(normalizedCutoff, 0.001f, 1.0f);
}

float LowPassFilter::Process(float input) {
    state_ += (input - state_) * cutoff_;
    return state_;
}

void HighPassFilter::SetCutoff(float normalizedCutoff) {
    cutoff_ = std::clamp(normalizedCutoff, 0.0f, 1.0f);
}

float HighPassFilter::Process(float input) {
    float out = cutoff_ * (prevOut_ + input - prevIn_);
    prevIn_ = input;
    prevOut_ = out;
    return out;
}

Phaser::Phaser(int maxDelaySamples) : buffer_(static_cast<size_t>(std::max(1, maxDelaySamples)), 0.0f) {}

void Phaser::SetOffsetSamples(int offset) {
    offset_ = std::clamp(offset, 0, static_cast<int>(buffer_.size()) - 1);
}

float Phaser::Process(float input) {
    buffer_[static_cast<size_t>(writeIndex_)] = input;
    int readIndex = writeIndex_ - offset_;
    if (readIndex < 0) readIndex += static_cast<int>(buffer_.size());
    float delayed = buffer_[static_cast<size_t>(readIndex)];
    writeIndex_ = (writeIndex_ + 1) % static_cast<int>(buffer_.size());
    return (input + delayed) * 0.5f;
}

}  // namespace soundfx
