#include "effects.h"

#include <algorithm>

namespace soundfx {

void LowPassFilter::SetCutoff(float normalizedCutoff) {
    cutoff_ = std::clamp(normalizedCutoff, 0.001f, 1.0f);
}

float LowPassFilter::Process(float input) {
    state_ += (input - state_) * cutoff_;
    return state_;
}

void HighPassFilter::SetCutoff(float normalizedCutoff) {
    // normalizedCutoff is "how much low end to remove": 0 = none, 1 = a lot.
    // But in the recurrence below, alpha scales the WHOLE output, not just
    // the filtered delta — so alpha must be highest (~1, nearly transparent)
    // when normalizedCutoff is 0, and can never reach exactly 0 or every
    // sample becomes silent regardless of input. That's the inverse of how
    // LowPassFilter's cutoff behaves, and mixing the two up here previously
    // caused total silence on every preset that left this at its default.
    float amount = std::clamp(normalizedCutoff, 0.0f, 1.0f);
    cutoff_ = std::clamp(1.0f - amount, 0.02f, 1.0f);
}

float HighPassFilter::Process(float input) {
    float out = cutoff_ * (prevOut_ + input - prevIn_);
    prevIn_ = input;
    prevOut_ = out;
    return out;
}

Phaser::Phaser(int maxDelaySamples) : buffer_(static_cast<size_t>(std::max(1, maxDelaySamples)), 0.0f) {}

void Phaser::SetOffsetSamples(int offset) {
    offset_ = std::clamp(offset, 0, static_cast<int>(buffer_.size()) - 1);
}

float Phaser::Process(float input) {
    buffer_[static_cast<size_t>(writeIndex_)] = input;
    int readIndex = writeIndex_ - offset_;
    if (readIndex < 0) readIndex += static_cast<int>(buffer_.size());
    float delayed = buffer_[static_cast<size_t>(readIndex)];
    writeIndex_ = (writeIndex_ + 1) % static_cast<int>(buffer_.size());
    return (input + delayed) * 0.5f;
}

}  // namespace soundfx
