// Thin JNI boundary. All real logic lives in core/ — this file only
// marshals data across the JVM<->native boundary and must stay that way.
#include <jni.h>

#include <vector>

#include "core/synth_engine.h"

extern "C" JNIEXPORT jshortArray JNICALL
Java_com_soundfxmaker_app_core_NativeSynthEngine_generate(JNIEnv* env, jclass /* clazz */, jfloatArray paramsArray) {
    jsize len = env->GetArrayLength(paramsArray);
    std::vector<float> params(static_cast<size_t>(len));
    env->GetFloatArrayRegion(paramsArray, 0, len, params.data());

    soundfx::SynthParams synthParams = soundfx::SynthParams::FromFloatArray(params);
    std::vector<int16_t> samples = soundfx::SynthEngine::Render(synthParams);

    jshortArray result = env->NewShortArray(static_cast<jsize>(samples.size()));
    if (result != nullptr && !samples.empty()) {
        env->SetShortArrayRegion(result, 0, static_cast<jsize>(samples.size()),
                                  reinterpret_cast<const jshort*>(samples.data()));
    }
    return result;
}
