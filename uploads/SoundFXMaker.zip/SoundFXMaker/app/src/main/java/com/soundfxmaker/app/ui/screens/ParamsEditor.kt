package com.soundfxmaker.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.soundfxmaker.app.core.SfxParams
import com.soundfxmaker.app.core.WaveType

/**
 * Full manual control over every synthesis parameter, grouped the way a
 * hardware synth panel would be. This is what makes Custom mode (and
 * fine-tuning any preset) an actual sound designer rather than just a
 * randomize button — every field here maps directly to one [SfxParams]
 * field, so there's nothing hidden behind a preset you can't reach.
 */
@Composable
fun ParamsEditor(params: SfxParams, onChange: (SfxParams) -> Unit, modifier: Modifier = Modifier) {
    Column(modifier = modifier.fillMaxWidth().padding(top = 8.dp)) {
        WaveTypeSelector(selected = params.waveType, onSelect = { onChange(params.copy(waveType = it)) })

        SectionHeader("Waveform")
        SliderRow("Pitch", params.baseFreq, 0f..1f) { onChange(params.copy(baseFreq = it)) }
        SliderRow("Pitch sweep", params.freqRamp, -1f..1f) { onChange(params.copy(freqRamp = it)) }
        SliderRow("Pitch floor", params.freqLimit, 0f..1f) { onChange(params.copy(freqLimit = it)) }
        SliderRow("Duty cycle", params.dutyCycle, 0.02f..0.98f) { onChange(params.copy(dutyCycle = it)) }
        SliderRow("Duty sweep", params.dutyRamp, -1f..1f) { onChange(params.copy(dutyRamp = it)) }

        SectionHeader("Envelope")
        SliderRow("Attack", params.attackTime, 0f..1f) { onChange(params.copy(attackTime = it)) }
        SliderRow("Sustain", params.sustainTime, 0f..1f) { onChange(params.copy(sustainTime = it)) }
        SliderRow("Punch", params.sustainPunch, 0f..1f) { onChange(params.copy(sustainPunch = it)) }
        SliderRow("Decay", params.decayTime, 0f..1f) { onChange(params.copy(decayTime = it)) }

        SectionHeader("Vibrato")
        SliderRow("Depth", params.vibratoDepth, 0f..1f) { onChange(params.copy(vibratoDepth = it)) }
        SliderRow("Speed", params.vibratoSpeed, 0f..1f) { onChange(params.copy(vibratoSpeed = it)) }

        SectionHeader("Filters")
        SliderRow("Low-pass cutoff", params.lpfCutoff, 0f..1f) { onChange(params.copy(lpfCutoff = it)) }
        SliderRow("Low-pass sweep", params.lpfCutoffRamp, -1f..1f) { onChange(params.copy(lpfCutoffRamp = it)) }
        SliderRow("Resonance", params.lpfResonance, 0f..1f) { onChange(params.copy(lpfResonance = it)) }
        SliderRow("High-pass cutoff", params.hpfCutoff, 0f..1f) { onChange(params.copy(hpfCutoff = it)) }
        SliderRow("High-pass sweep", params.hpfCutoffRamp, -1f..1f) { onChange(params.copy(hpfCutoffRamp = it)) }

        SectionHeader("Effects")
        SliderRow("Phaser", params.phaserOffset, -1f..1f) { onChange(params.copy(phaserOffset = it)) }
        SliderRow("Phaser sweep", params.phaserRamp, -1f..1f) { onChange(params.copy(phaserRamp = it)) }
        SliderRow("Repeat", params.repeatSpeed, 0f..1f) { onChange(params.copy(repeatSpeed = it)) }
        SliderRow("Arpeggio", params.arpeggioMod, -1f..1f) { onChange(params.copy(arpeggioMod = it)) }
        SliderRow("Arpeggio speed", params.arpeggioSpeed, 0f..1f) { onChange(params.copy(arpeggioSpeed = it)) }

        SectionHeader("Output")
        SliderRow("Volume", params.volume, 0f..1f) { onChange(params.copy(volume = it)) }
    }
}

@Composable
private fun SectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(top = 16.dp, bottom = 4.dp)
    )
}

@Composable
private fun SliderRow(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit
) {
    Text(label, style = MaterialTheme.typography.labelLarge)
    Slider(value = value, onValueChange = onChange, valueRange = range)
}

@Composable
private fun WaveTypeSelector(selected: WaveType, onSelect: (WaveType) -> Unit) {
    Text(
        text = "Wave shape",
        style = MaterialTheme.typography.labelLarge,
        modifier = Modifier.padding(bottom = 6.dp)
    )
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
        WaveType.entries.forEach { type ->
            val isSelected = type == selected
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(36.dp)
                    .background(
                        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(10.dp)
                    )
                    .clickable { onSelect(type) },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = type.shortLabel(),
                    color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}

private fun WaveType.shortLabel(): String = when (this) {
    WaveType.SQUARE -> "Square"
    WaveType.SAWTOOTH -> "Saw"
    WaveType.SINE -> "Sine"
    WaveType.NOISE -> "Noise"
    WaveType.TRIANGLE -> "Tri"
}
