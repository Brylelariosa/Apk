package com.soundfxmaker.app.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.soundfxmaker.app.core.SfxParams

private data class SliderSpec(
    val label: String,
    val value: Float,
    val range: ClosedFloatingPointRange<Float>,
    val onChange: (Float) -> Unit
)

/**
 * Manual controls for the parameters that matter most for shaping a sound by
 * ear. The full parameter set (23 fields) lives in [SfxParams] — this editor
 * surfaces the subset a person can meaningfully tweak by hand; everything
 * else stays whatever the preset/mutation set it to.
 */
@Composable
fun ParamsEditor(params: SfxParams, onChange: (SfxParams) -> Unit, modifier: Modifier = Modifier) {
    val specs = listOf(
        SliderSpec("Pitch", params.baseFreq, 0f..1f) { onChange(params.copy(baseFreq = it)) },
        SliderSpec("Pitch sweep", params.freqRamp, -1f..1f) { onChange(params.copy(freqRamp = it)) },
        SliderSpec("Attack", params.attackTime, 0f..1f) { onChange(params.copy(attackTime = it)) },
        SliderSpec("Sustain", params.sustainTime, 0f..1f) { onChange(params.copy(sustainTime = it)) },
        SliderSpec("Decay", params.decayTime, 0f..1f) { onChange(params.copy(decayTime = it)) },
        SliderSpec("Punch", params.sustainPunch, 0f..1f) { onChange(params.copy(sustainPunch = it)) },
        SliderSpec("Vibrato", params.vibratoDepth, 0f..1f) { onChange(params.copy(vibratoDepth = it)) },
        SliderSpec("Filter cutoff", params.lpfCutoff, 0f..1f) { onChange(params.copy(lpfCutoff = it)) },
        SliderSpec("Phaser", params.phaserOffset, -1f..1f) { onChange(params.copy(phaserOffset = it)) },
        SliderSpec("Volume", params.volume, 0f..1f) { onChange(params.copy(volume = it)) }
    )

    Column(modifier = modifier.fillMaxWidth().padding(top = 8.dp)) {
        specs.forEach { spec ->
            Text(spec.label, style = MaterialTheme.typography.labelLarge)
            Slider(value = spec.value, onValueChange = spec.onChange, valueRange = spec.range)
        }
    }
}
