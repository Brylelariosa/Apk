package com.soundfxmaker.app.audio

import java.io.File
import java.io.FileOutputStream

/** Writes raw 16-bit PCM mono samples to a standard 44-byte-header WAV file. */
object WavExporter {

    fun writeWav(file: File, samples: ShortArray, sampleRate: Int = 44100) {
        val dataSize = samples.size * 2
        val byteRate = sampleRate * 2
        FileOutputStream(file).use { out ->
            out.write(riffHeader(dataSize, sampleRate, byteRate))
            val buffer = ByteArray(dataSize)
            for (i in samples.indices) {
                val v = samples[i].toInt()
                buffer[i * 2] = (v and 0xFF).toByte()
                buffer[i * 2 + 1] = ((v shr 8) and 0xFF).toByte()
            }
            out.write(buffer)
        }
    }

    private fun riffHeader(dataSize: Int, sampleRate: Int, byteRate: Int): ByteArray {
        val totalSize = 36 + dataSize
        val header = ByteArray(44)

        fun putStr(offset: Int, s: String) = s.forEachIndexed { i, c -> header[offset + i] = c.code.toByte() }
        fun putInt(offset: Int, v: Int) {
            header[offset] = (v and 0xFF).toByte()
            header[offset + 1] = ((v shr 8) and 0xFF).toByte()
            header[offset + 2] = ((v shr 16) and 0xFF).toByte()
            header[offset + 3] = ((v shr 24) and 0xFF).toByte()
        }
        fun putShort(offset: Int, v: Int) {
            header[offset] = (v and 0xFF).toByte()
            header[offset + 1] = ((v shr 8) and 0xFF).toByte()
        }

        putStr(0, "RIFF"); putInt(4, totalSize); putStr(8, "WAVE")
        putStr(12, "fmt "); putInt(16, 16); putShort(20, 1) // PCM
        putShort(22, 1) // mono
        putInt(24, sampleRate); putInt(28, byteRate)
        putShort(32, 2); putShort(34, 16)
        putStr(36, "data"); putInt(40, dataSize)
        return header
    }
}
