package com.soundfxmaker.app.data

import com.soundfxmaker.app.core.SfxCategory
import com.soundfxmaker.app.core.SfxParams

data class SavedSound(
    val id: String,
    val name: String,
    val category: SfxCategory,
    val source: SoundSource,
    val params: SfxParams?,
    val filePath: String,
    val durationSeconds: Float,
    val createdAtMillis: Long
)
