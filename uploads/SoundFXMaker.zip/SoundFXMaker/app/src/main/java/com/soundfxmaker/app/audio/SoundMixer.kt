package com.soundfxmaker.app.audio

/** Combines two PCM buffers by simple sample-wise addition, hard-clamped to
 *  the 16-bit range. The shorter buffer is padded with silence so both
 *  sounds play in full — a layered sound isn't truncated to the shorter of
 *  the two. */
object SoundMixer {

    fun mix(a: ShortArray, b: ShortArray): ShortArray {
        val length = maxOf(a.size, b.size)
        val result = ShortArray(length)
        for (i in 0 until length) {
            val sampleA = if (i < a.size) a[i] else 0
            val sampleB = if (i < b.size) b[i] else 0
            val sum = sampleA + sampleB
            result[i] = sum.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
        return result
    }
}
