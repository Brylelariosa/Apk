package com.soundfxmaker.app.audio

/** Combines two PCM buffers two different ways:
 *  - [mix]: layers them by sample-wise addition, hard-clamped to the 16-bit
 *    range. The shorter buffer is padded with silence so both sounds play
 *    in full — a layered sound isn't truncated to the shorter of the two.
 *  - [concatenate]: plays one after the other, unchanged. */
object SoundMixer {

    fun mix(a: ShortArray, b: ShortArray): ShortArray {
        val length = maxOf(a.size, b.size)
        val result = ShortArray(length)
        for (i in 0 until length) {
            val sampleA = if (i < a.size) a[i] else 0
            val sampleB = if (i < b.size) b[i] else 0
            val sum = sampleA + sampleB
            result[i] = sum.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
        return result
    }

    fun concatenate(a: ShortArray, b: ShortArray): ShortArray {
        val result = ShortArray(a.size + b.size)
        a.copyInto(result, 0)
        b.copyInto(result, a.size)
        return result
    }
}
