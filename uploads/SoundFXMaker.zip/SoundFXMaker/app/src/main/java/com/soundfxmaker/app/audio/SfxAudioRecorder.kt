package com.soundfxmaker.app.audio

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Captures microphone input as raw 16-bit PCM mono at the same sample rate
 * the rest of the app uses, so a recording drops straight into the same
 * render/play/save pipeline as a generated sound — nothing downstream needs
 * to know or care that it didn't come from the synth engine.
 *
 * Not designed for concurrent callers: [start]/[stop] are meant to be driven
 * from a single ViewModel. [stop] joins the capture coroutine before reading
 * the buffer back, so there's never concurrent access to it.
 */
class SfxAudioRecorder(private val sampleRate: Int = 44100) {

    private var audioRecord: AudioRecord? = null
    private var recordJob: Job? = null
    private val buffer = GrowableShortBuffer()

    val isRecording: Boolean get() = recordJob?.isActive == true

    /** Starts capturing. Returns false (and captures nothing) if the mic
     *  couldn't be initialized — busy hardware, no input device, etc. */
    @SuppressLint("MissingPermission") // caller is required to have already checked RECORD_AUDIO
    fun start(scope: CoroutineScope): Boolean {
        if (isRecording) return true
        buffer.clear()

        val minBufferSize = AudioRecord.getMinBufferSize(
            sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val bufferSize = if (minBufferSize > 0) minBufferSize else sampleRate * 2

        val record = try {
            AudioRecord(
                MediaRecorder.AudioSource.MIC,
                sampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufferSize
            )
        } catch (e: IllegalArgumentException) {
            Log.w(TAG, "Failed to create AudioRecord", e)
            return false
        }

        if (record.state != AudioRecord.STATE_INITIALIZED) {
            Log.w(TAG, "AudioRecord failed to initialize (state=${record.state})")
            record.release()
            return false
        }

        audioRecord = record
        record.startRecording()

        val maxSamples = sampleRate * MAX_RECORDING_SECONDS
        recordJob = scope.launch(Dispatchers.IO) {
            val readBuffer = ShortArray(bufferSize / 2)
            while (isActive && buffer.size < maxSamples) {
                val read = record.read(readBuffer, 0, readBuffer.size)
                if (read > 0) {
                    buffer.append(readBuffer, read)
                } else if (read < 0) {
                    // A negative return is one of AudioRecord.ERROR_* — the
                    // device stopped delivering audio, so stop spinning.
                    Log.w(TAG, "AudioRecord.read returned error code $read")
                    break
                }
            }
        }
        return true
    }

    /** Stops recording and returns everything captured since [start]. */
    suspend fun stop(): ShortArray {
        recordJob?.cancelAndJoin()
        recordJob = null
        releaseRecord()
        return buffer.toShortArray()
    }

    /** Synchronous teardown for when we don't care about the captured audio
     *  anymore (e.g. the ViewModel is being cleared mid-recording). */
    fun release() {
        recordJob?.cancel()
        recordJob = null
        releaseRecord()
    }

    private fun releaseRecord() {
        audioRecord?.apply {
            runCatching { stop() }
            release()
        }
        audioRecord = null
    }

    private companion object {
        const val TAG = "SfxAudioRecorder"
        const val MAX_RECORDING_SECONDS = 120
    }
}

/**
 * A growable primitive short buffer — the recording equivalent of
 * ByteArrayOutputStream. Kotlin's `MutableList<Short>` boxes every element,
 * which turns a multi-second recording (hundreds of thousands of samples)
 * into that many individual heap allocations; this appends in bulk against
 * a plain ShortArray that doubles capacity like ArrayList does internally.
 */
private class GrowableShortBuffer(initialCapacity: Int = 16384) {
    private var array = ShortArray(initialCapacity)
    var size = 0
        private set

    fun append(source: ShortArray, count: Int) {
        ensureCapacity(size + count)
        source.copyInto(array, size, 0, count)
        size += count
    }

    fun clear() {
        size = 0
    }

    fun toShortArray(): ShortArray = array.copyOf(size)

    private fun ensureCapacity(minCapacity: Int) {
        if (minCapacity <= array.size) return
        var newCapacity = array.size * 2
        while (newCapacity < minCapacity) newCapacity *= 2
        array = array.copyOf(newCapacity)
    }
}
