package com.soundfxmaker.app.audio

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Captures microphone input as raw 16-bit PCM mono at the same sample rate
 * the rest of the app uses, so a recording drops straight into the same
 * render/play/save pipeline as a generated sound — nothing downstream needs
 * to know or care that it didn't come from the synth engine.
 *
 * Not designed for concurrent callers: [start]/[stop] are meant to be driven
 * from a single ViewModel. [stop] joins the capture coroutine before reading
 * the buffer back, so there's never concurrent access to it.
 */
class SfxAudioRecorder(private val sampleRate: Int = 44100) {

    private var audioRecord: AudioRecord? = null
    private var recordJob: Job? = null
    private val chunks = mutableListOf<Short>()

    val isRecording: Boolean get() = recordJob?.isActive == true

    @SuppressLint("MissingPermission") // caller is required to have already checked RECORD_AUDIO
    fun start(scope: CoroutineScope) {
        if (isRecording) return
        chunks.clear()

        val minBufferSize = AudioRecord.getMinBufferSize(
            sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val bufferSize = if (minBufferSize > 0) minBufferSize else sampleRate * 2

        val record = AudioRecord(
            MediaRecorder.AudioSource.MIC,
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            bufferSize
        )
        audioRecord = record
        record.startRecording()

        recordJob = scope.launch(Dispatchers.IO) {
            val buffer = ShortArray(bufferSize / 2)
            while (isActive) {
                val read = record.read(buffer, 0, buffer.size)
                if (read > 0) {
                    for (i in 0 until read) chunks.add(buffer[i])
                }
            }
        }
    }

    /** Stops recording and returns everything captured since [start]. */
    suspend fun stop(): ShortArray {
        recordJob?.cancelAndJoin()
        recordJob = null
        releaseRecord()
        return chunks.toShortArray()
    }

    /** Synchronous teardown for when we don't care about the captured audio
     *  anymore (e.g. the ViewModel is being cleared mid-recording). */
    fun release() {
        recordJob?.cancel()
        recordJob = null
        releaseRecord()
    }

    private fun releaseRecord() {
        audioRecord?.apply {
            runCatching { stop() }
            release()
        }
        audioRecord = null
    }
}
