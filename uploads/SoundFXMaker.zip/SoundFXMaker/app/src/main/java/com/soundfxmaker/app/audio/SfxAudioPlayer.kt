package com.soundfxmaker.app.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.MediaPlayer
import android.util.Log

/**
 * Plays sound effects from two sources:
 *  - [play] for an in-memory PCM buffer straight from the synth engine (used
 *    for live preview while generating/tweaking — no file I/O in the way).
 *  - [playFile] for an already-saved WAV file (used by the saved-sounds list).
 */
class SfxAudioPlayer(private val sampleRate: Int = 44100) {

    private var track: AudioTrack? = null
    private var mediaPlayer: MediaPlayer? = null

    fun play(samples: ShortArray) {
        if (samples.isEmpty()) return
        stop()
        val bufferSize = samples.size * Short.SIZE_BYTES
        val newTrack = try {
            AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(bufferSize)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
        } catch (e: UnsupportedOperationException) {
            Log.w(TAG, "Failed to create AudioTrack", e)
            return
        }

        // Construction can succeed but still leave the track uninitialized
        // (busy audio hardware, no output device, etc.) — writing/playing
        // on it in that state throws, so bail out instead.
        if (newTrack.state != AudioTrack.STATE_INITIALIZED) {
            Log.w(TAG, "AudioTrack failed to initialize (state=${newTrack.state})")
            newTrack.release()
            return
        }

        newTrack.write(samples, 0, samples.size)
        newTrack.play()
        track = newTrack
    }

    fun playFile(path: String) {
        stop()
        val player = MediaPlayer()
        mediaPlayer = player
        player.setOnPreparedListener { mp ->
            // Guards against a race: if stop()/another playFile() replaced
            // this player while it was still preparing asynchronously, this
            // (now-stale) instance must not be started.
            if (mp === mediaPlayer) mp.start()
        }
        player.setOnCompletionListener { mp ->
            mp.release()
            if (mp === mediaPlayer) mediaPlayer = null
        }
        player.setOnErrorListener { mp, _, _ ->
            mp.release()
            if (mp === mediaPlayer) mediaPlayer = null
            true
        }
        try {
            player.setDataSource(path)
            player.prepareAsync()
        } catch (e: Exception) {
            Log.w(TAG, "Failed to play $path", e)
            player.release()
            mediaPlayer = null
        }
    }

    fun stop() {
        track?.apply {
            if (playState == AudioTrack.PLAYSTATE_PLAYING) stop()
            release()
        }
        track = null
        mediaPlayer?.release()
        mediaPlayer = null
    }

    private companion object {
        const val TAG = "SfxAudioPlayer"
    }
}
