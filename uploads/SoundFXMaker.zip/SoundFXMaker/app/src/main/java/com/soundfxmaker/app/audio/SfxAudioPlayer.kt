package com.soundfxmaker.app.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.MediaPlayer

/**
 * Plays sound effects from two sources:
 *  - [play] for an in-memory PCM buffer straight from the synth engine (used
 *    for live preview while generating/tweaking — no file I/O in the way).
 *  - [playFile] for an already-saved WAV file (used by the saved-sounds list).
 */
class SfxAudioPlayer(private val sampleRate: Int = 44100) {

    private var track: AudioTrack? = null
    private var mediaPlayer: MediaPlayer? = null

    fun play(samples: ShortArray) {
        if (samples.isEmpty()) return
        stop()
        val bufferSize = samples.size * Short.SIZE_BYTES
        val newTrack = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(bufferSize)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()

        newTrack.write(samples, 0, samples.size)
        newTrack.play()
        track = newTrack
    }

    fun playFile(path: String) {
        stop()
        mediaPlayer = MediaPlayer().apply {
            setDataSource(path)
            setOnPreparedListener { start() }
            setOnCompletionListener { it.release() }
            prepareAsync()
        }
    }

    fun stop() {
        track?.apply {
            if (playState == AudioTrack.PLAYSTATE_PLAYING) stop()
            release()
        }
        track = null
        mediaPlayer?.release()
        mediaPlayer = null
    }
}
