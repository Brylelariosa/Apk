package com.soundfxmaker.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.soundfxmaker.app.data.SavedSound
import com.soundfxmaker.app.data.SoundSource

/**
 * The saved-sound library. Editing, trimming, renaming, sharing, and mix
 * selection are all opt-in via nullable callbacks — the Presets screen
 * passes null for all of them and gets a plain play/delete list; Studio
 * passes everything and gets the full feature set. One component either
 * way, so the row layout only exists once.
 */
@Composable
fun SavedSoundsList(
    sounds: List<SavedSound>,
    selectedForMix: List<String>,
    playingId: String?,
    playingProgress: Float,
    onPlay: (SavedSound) -> Unit,
    onDelete: (SavedSound) -> Unit,
    onEdit: ((SavedSound) -> Unit)? = null,
    onRename: ((SavedSound) -> Unit)? = null,
    onShare: ((SavedSound) -> Unit)? = null,
    onToggleMixSelect: ((SavedSound) -> Unit)? = null,
    onCombineSelected: (() -> Unit)? = null,
    onContinueSelected: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "Saved sounds (${sounds.size})", style = MaterialTheme.typography.titleMedium)
            if (selectedForMix.size == 2) {
                Row {
                    if (onCombineSelected != null) TextButton(onClick = onCombineSelected) { Text("Combine") }
                    if (onContinueSelected != null) TextButton(onClick = onContinueSelected) { Text("Continue") }
                }
            }
        }

        if (sounds.isEmpty()) {
            Text(
                text = "Nothing saved yet — generate, record, or mix a sound to get started.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 8.dp)
            )
            return
        }

        if (onToggleMixSelect != null) {
            Text(
                text = "Tap the checkbox on two sounds, then Combine to layer them or Continue to play one after the other.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 4.dp, bottom = 8.dp)
            )
        }

        sounds.asReversed().forEach { sound ->
            SavedSoundRow(
                sound = sound,
                isSelected = sound.id in selectedForMix,
                isPlaying = sound.id == playingId,
                playingProgress = playingProgress,
                onPlay = onPlay,
                onDelete = onDelete,
                onEdit = onEdit,
                onRename = onRename,
                onShare = onShare,
                onToggleMixSelect = onToggleMixSelect
            )
        }
    }
}

@Composable
private fun SavedSoundRow(
    sound: SavedSound,
    isSelected: Boolean,
    isPlaying: Boolean,
    playingProgress: Float,
    onPlay: (SavedSound) -> Unit,
    onDelete: (SavedSound) -> Unit,
    onEdit: ((SavedSound) -> Unit)?,
    onRename: ((SavedSound) -> Unit)?,
    onShare: ((SavedSound) -> Unit)?,
    onToggleMixSelect: ((SavedSound) -> Unit)?
) {
    var showMenu by remember { mutableStateOf(false) }

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) {
                MaterialTheme.colorScheme.primary.copy(alpha = 0.25f)
            } else {
                MaterialTheme.colorScheme.surfaceVariant
            }
        ),
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
    ) {
        Column(modifier = Modifier.padding(vertical = 2.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = if (onToggleMixSelect != null) 4.dp else 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (onToggleMixSelect != null) {
                        Checkbox(checked = isSelected, onCheckedChange = { onToggleMixSelect(sound) })
                    }
                    Column {
                        Text(sound.name, style = MaterialTheme.typography.bodyLarge)
                        Text(
                            text = sound.sourceLabel(),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Row {
                    if (onRename != null || onShare != null) {
                        Box {
                            IconButton(onClick = { showMenu = true }) {
                                Icon(Icons.Default.MoreVert, contentDescription = "More options for ${sound.name}")
                            }
                            DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                                if (onRename != null) {
                                    DropdownMenuItem(
                                        text = { Text("Rename") },
                                        onClick = { showMenu = false; onRename(sound) }
                                    )
                                }
                                if (onShare != null) {
                                    DropdownMenuItem(
                                        text = { Text("Share") },
                                        onClick = { showMenu = false; onShare(sound) }
                                    )
                                }
                            }
                        }
                    }
                    if (onEdit != null) {
                        IconButton(onClick = { onEdit(sound) }) {
                            Icon(Icons.Default.Edit, contentDescription = "Edit ${sound.name}")
                        }
                    }
                    IconButton(onClick = { onPlay(sound) }) {
                        Icon(Icons.Default.PlayArrow, contentDescription = "Play ${sound.name}")
                    }
                    IconButton(onClick = { onDelete(sound) }) {
                        Icon(Icons.Default.Close, contentDescription = "Delete ${sound.name}")
                    }
                }
            }
            if (isPlaying) {
                LinearProgressIndicator(
                    progress = playingProgress,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)
                )
            }
        }
    }
}

private fun SavedSound.sourceLabel(): String = when (source) {
    SoundSource.GENERATED -> category.displayName
    SoundSource.RECORDED -> "Recording"
    SoundSource.MIXED -> "Mix"
    SoundSource.TRIMMED -> "Trimmed"
}
