package com.soundfxmaker.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.soundfxmaker.app.data.SavedSound
import com.soundfxmaker.app.data.SoundSource

/**
 * The saved-sound library. Editing, trimming, and mix selection are opt-in
 * via nullable callbacks — Normal mode passes null for all of them and gets
 * a plain play/delete list; Studio mode passes everything and gets the full
 * feature set. One component either way, so the row layout only exists once.
 */
@Composable
fun SavedSoundsList(
    sounds: List<SavedSound>,
    selectedForMix: List<String>,
    playingId: String?,
    playingProgress: Float,
    onPlay: (SavedSound) -> Unit,
    onDelete: (SavedSound) -> Unit,
    onEdit: ((SavedSound) -> Unit)? = null,
    onToggleMixSelect: ((SavedSound) -> Unit)? = null,
    onCombineSelected: (() -> Unit)? = null,
    onContinueSelected: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "Saved sounds (${sounds.size})", style = MaterialTheme.typography.titleMedium)
            if (selectedForMix.size == 2) {
                Row {
                    if (onCombineSelected != null) TextButton(onClick = onCombineSelected) { Text("Combine") }
                    if (onContinueSelected != null) TextButton(onClick = onContinueSelected) { Text("Continue") }
                }
            }
        }

        if (sounds.isEmpty()) {
            Text(
                text = "Nothing saved yet — generate, record, or mix a sound to get started.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 8.dp)
            )
            return
        }

        if (onToggleMixSelect != null) {
            Text(
                text = "Tap the checkbox on two sounds, then Combine to layer them or Continue to play one after the other.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 4.dp, bottom = 8.dp)
            )
        }

        sounds.asReversed().forEach { sound ->
            val isSelected = sound.id in selectedForMix
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isSelected) {
                        MaterialTheme.colorScheme.primary.copy(alpha = 0.25f)
                    } else {
                        MaterialTheme.colorScheme.surfaceVariant
                    }
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            ) {
                Column(modifier = Modifier.padding(vertical = 2.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = if (onToggleMixSelect != null) 4.dp else 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (onToggleMixSelect != null) {
                                Checkbox(checked = isSelected, onCheckedChange = { onToggleMixSelect(sound) })
                            }
                            Column {
                                Text(sound.name, style = MaterialTheme.typography.bodyLarge)
                                Text(
                                    text = sound.sourceLabel(),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Row {
                            if (onEdit != null) {
                                IconButton(onClick = { onEdit(sound) }) {
                                    Icon(Icons.Default.Edit, contentDescription = "Edit ${sound.name}")
                                }
                            }
                            IconButton(onClick = { onPlay(sound) }) {
                                Icon(Icons.Default.PlayArrow, contentDescription = "Play ${sound.name}")
                            }
                            IconButton(onClick = { onDelete(sound) }) {
                                Icon(Icons.Default.Close, contentDescription = "Delete ${sound.name}")
                            }
                        }
                    }
                    if (sound.id == playingId) {
                        LinearProgressIndicator(
                            progress = playingProgress,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp)
                        )
                    }
                }
            }
        }
    }
}

private fun SavedSound.sourceLabel(): String = when (source) {
    SoundSource.GENERATED -> category.displayName
    SoundSource.RECORDED -> "Recording"
    SoundSource.MIXED -> "Mix"
    SoundSource.TRIMMED -> "Trimmed"
}
