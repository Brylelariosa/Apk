package com.soundfxmaker.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.soundfxmaker.app.data.SavedSound
import com.soundfxmaker.app.data.SoundSource

@Composable
fun SavedSoundsList(
    sounds: List<SavedSound>,
    selectedForMix: List<String>,
    onPlay: (SavedSound) -> Unit,
    onEdit: (SavedSound) -> Unit,
    onDelete: (SavedSound) -> Unit,
    onToggleMixSelect: (SavedSound) -> Unit,
    onMixSelected: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "Saved sounds (${sounds.size})", style = MaterialTheme.typography.titleMedium)
            if (selectedForMix.size == 2) {
                TextButton(onClick = onMixSelected) { Text("Mix these two") }
            }
        }

        if (sounds.isEmpty()) {
            Text(
                text = "Nothing saved yet — generate, record, or mix a sound to get started.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 8.dp)
            )
            return
        }

        Text(
            text = "Tap the checkbox on two sounds to mix them.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 4.dp, bottom = 8.dp)
        )

        sounds.asReversed().forEach { sound ->
            val isSelected = sound.id in selectedForMix
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isSelected) {
                        MaterialTheme.colorScheme.primary.copy(alpha = 0.25f)
                    } else {
                        MaterialTheme.colorScheme.surfaceVariant
                    }
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = isSelected, onCheckedChange = { onToggleMixSelect(sound) })
                        Column {
                            Text(sound.name, style = MaterialTheme.typography.bodyLarge)
                            Text(
                                text = sound.sourceLabel(),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Row {
                        if (sound.source == SoundSource.GENERATED) {
                            IconButton(onClick = { onEdit(sound) }) {
                                Icon(Icons.Default.Edit, contentDescription = "Edit ${sound.name}")
                            }
                        }
                        IconButton(onClick = { onPlay(sound) }) {
                            Icon(Icons.Default.PlayArrow, contentDescription = "Play ${sound.name}")
                        }
                        IconButton(onClick = { onDelete(sound) }) {
                            Icon(Icons.Default.Close, contentDescription = "Delete ${sound.name}")
                        }
                    }
                }
            }
        }
    }
}

private fun SavedSound.sourceLabel(): String = when (source) {
    SoundSource.GENERATED -> category.displayName
    SoundSource.RECORDED -> "Recording"
    SoundSource.MIXED -> "Mix"
}
