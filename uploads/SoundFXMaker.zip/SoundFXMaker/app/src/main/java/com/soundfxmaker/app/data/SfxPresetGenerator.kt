package com.soundfxmaker.app.data

import com.soundfxmaker.app.core.SfxCategory
import com.soundfxmaker.app.core.SfxParams
import com.soundfxmaker.app.core.WaveType
import kotlin.random.Random

/**
 * Produces [SfxParams] for each [SfxCategory]. Ranges are tuned by ear so
 * each category has a recognizable character while still varying on every
 * generation. This is the only place that should need tuning if a category
 * sounds off — the native engine just renders whatever parameters it's given.
 */
object SfxPresetGenerator {

    fun generate(category: SfxCategory, random: Random = Random.Default): SfxParams = when (category) {
        SfxCategory.CUSTOM -> custom()
        SfxCategory.PICKUP_COIN -> pickupCoin(random)
        SfxCategory.LASER_SHOOT -> laserShoot(random)
        SfxCategory.EXPLOSION -> explosion(random)
        SfxCategory.POWERUP -> powerUp(random)
        SfxCategory.HIT_HURT -> hitHurt(random)
        SfxCategory.JUMP -> jump(random)
        SfxCategory.BLIP_SELECT -> blipSelect(random)
        SfxCategory.RANDOM -> fullyRandom(random)
    }

    /** Nudges every parameter slightly while keeping the sound recognizable. */
    fun mutate(params: SfxParams, amount: Float = 0.08f, random: Random = Random.Default): SfxParams {
        fun jitter(value: Float, range: ClosedFloatingPointRange<Float> = -1f..1f): Float =
            (value + (random.nextFloat() * 2f - 1f) * amount).coerceIn(range.start, range.endInclusive)

        return params.copy(
            baseFreq = jitter(params.baseFreq, 0f..1f),
            freqRamp = jitter(params.freqRamp),
            dutyCycle = jitter(params.dutyCycle, 0f..1f),
            vibratoDepth = jitter(params.vibratoDepth, 0f..1f),
            attackTime = jitter(params.attackTime, 0f..1f),
            sustainTime = jitter(params.sustainTime, 0f..1f),
            decayTime = jitter(params.decayTime, 0f..1f),
            lpfCutoff = jitter(params.lpfCutoff, 0f..1f),
            phaserOffset = jitter(params.phaserOffset)
        )
    }

    private fun Random.range(from: Float, to: Float) = from + nextFloat() * (to - from)

    // Deliberately not randomized: Custom mode is a blank canvas, not
    // another preset. This is just SfxParams()'s own defaults, made
    // explicit here so it reads as an intentional starting point.
    private fun custom(): SfxParams = SfxParams()

    private fun pickupCoin(r: Random) = SfxParams(
        waveType = WaveType.SQUARE,
        baseFreq = r.range(0.4f, 0.6f),
        freqRamp = r.range(0.15f, 0.3f),
        dutyCycle = r.range(0.4f, 0.6f),
        attackTime = 0f,
        sustainTime = r.range(0.05f, 0.15f),
        decayTime = r.range(0.15f, 0.3f),
        sustainPunch = r.range(0.3f, 0.6f),
        arpeggioMod = r.range(0.3f, 0.6f),
        arpeggioSpeed = r.range(0.4f, 0.7f),
        volume = 0.6f
    )

    private fun laserShoot(r: Random) = SfxParams(
        waveType = WaveType.entries.filter { it != WaveType.NOISE }.random(r),
        baseFreq = r.range(0.5f, 0.9f),
        freqLimit = r.range(0.1f, 0.2f),
        freqRamp = r.range(-0.45f, -0.2f),
        dutyCycle = r.range(0f, 1f),
        attackTime = 0f,
        sustainTime = r.range(0.05f, 0.2f),
        decayTime = r.range(0.1f, 0.25f),
        hpfCutoff = r.range(0.05f, 0.2f),
        volume = 0.5f
    )

    private fun explosion(r: Random) = SfxParams(
        waveType = WaveType.NOISE,
        baseFreq = r.range(0.1f, 0.35f),
        freqRamp = r.range(-0.2f, 0f),
        attackTime = 0f,
        sustainTime = r.range(0.1f, 0.3f),
        decayTime = r.range(0.4f, 0.8f),
        sustainPunch = r.range(0.2f, 0.5f),
        lpfCutoff = r.range(0.3f, 0.7f),
        lpfResonance = r.range(0.1f, 0.4f),
        phaserOffset = r.range(0.1f, 0.4f),
        volume = 0.7f
    )

    private fun powerUp(r: Random) = SfxParams(
        waveType = if (r.nextBoolean()) WaveType.SAWTOOTH else WaveType.SQUARE,
        baseFreq = r.range(0.2f, 0.4f),
        freqRamp = r.range(0.2f, 0.4f),
        dutyCycle = r.range(0.3f, 0.7f),
        attackTime = r.range(0f, 0.1f),
        sustainTime = r.range(0.2f, 0.4f),
        decayTime = r.range(0.2f, 0.4f),
        vibratoDepth = r.range(0f, 0.3f),
        vibratoSpeed = r.range(0.3f, 0.6f),
        volume = 0.6f
    )

    private fun hitHurt(r: Random) = SfxParams(
        waveType = WaveType.entries.random(r),
        baseFreq = r.range(0.2f, 0.5f),
        freqRamp = r.range(-0.3f, -0.1f),
        attackTime = 0f,
        sustainTime = r.range(0.02f, 0.1f),
        decayTime = r.range(0.1f, 0.2f),
        hpfCutoff = r.range(0f, 0.1f),
        volume = 0.6f
    )

    private fun jump(r: Random) = SfxParams(
        waveType = WaveType.SQUARE,
        baseFreq = r.range(0.3f, 0.5f),
        freqRamp = r.range(0.25f, 0.45f),
        dutyCycle = r.range(0.4f, 0.6f),
        attackTime = 0f,
        sustainTime = r.range(0.1f, 0.2f),
        decayTime = r.range(0.1f, 0.2f),
        volume = 0.6f
    )

    private fun blipSelect(r: Random) = SfxParams(
        waveType = WaveType.entries.filter { it != WaveType.NOISE }.random(r),
        baseFreq = r.range(0.5f, 0.7f),
        dutyCycle = r.range(0.3f, 0.7f),
        attackTime = 0f,
        sustainTime = r.range(0.03f, 0.08f),
        decayTime = r.range(0.05f, 0.1f),
        volume = 0.5f
    )

    private fun fullyRandom(r: Random) = SfxParams(
        waveType = WaveType.entries.random(r),
        baseFreq = r.range(0f, 1f),
        freqLimit = r.range(0f, 0.3f),
        freqRamp = r.range(-0.5f, 0.5f),
        dutyCycle = r.range(0f, 1f),
        dutyRamp = r.range(-0.2f, 0.2f),
        vibratoDepth = r.range(0f, 0.5f),
        vibratoSpeed = r.range(0f, 1f),
        attackTime = r.range(0f, 0.3f),
        sustainTime = r.range(0f, 0.5f),
        sustainPunch = r.range(0f, 0.5f),
        decayTime = r.range(0f, 0.6f),
        lpfCutoff = r.range(0.3f, 1f),
        lpfResonance = r.range(0f, 0.4f),
        hpfCutoff = r.range(0f, 0.2f),
        phaserOffset = r.range(-0.3f, 0.3f),
        repeatSpeed = r.range(0f, 0.3f),
        arpeggioMod = r.range(-0.4f, 0.4f),
        arpeggioSpeed = r.range(0f, 1f),
        volume = 0.6f
    )
}
