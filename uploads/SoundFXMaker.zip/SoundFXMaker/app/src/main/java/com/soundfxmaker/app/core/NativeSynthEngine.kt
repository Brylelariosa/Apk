package com.soundfxmaker.app.core

import kotlin.random.Random

/**
 * Thin wrapper around the native (C++) DSP engine in app/src/main/cpp. All
 * actual sample rendering happens there — this object exists purely so the
 * rest of the app never has to touch JNI directly.
 */
object NativeSynthEngine {
    init {
        System.loadLibrary("soundfx_core")
    }

    /** Renders [params] to 16-bit PCM mono samples at 44100 Hz. Each call
     *  gets a fresh random seed for the noise oscillator — without this,
     *  two renders within the same wall-clock second would produce
     *  identical noise (audible on Explosion/Hit, which are noise-based). */
    fun render(params: SfxParams): ShortArray = generate(params.toFloatArray(), Random.nextLong())

    @JvmStatic
    private external fun generate(params: FloatArray, seed: Long): ShortArray
}
