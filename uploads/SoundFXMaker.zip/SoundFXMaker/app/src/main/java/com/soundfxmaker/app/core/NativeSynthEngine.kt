package com.soundfxmaker.app.core

/**
 * Thin wrapper around the native (C++) DSP engine in app/src/main/cpp. All
 * actual sample rendering happens there — this object exists purely so the
 * rest of the app never has to touch JNI directly.
 */
object NativeSynthEngine {
    init {
        System.loadLibrary("soundfx_core")
    }

    /** Renders [params] to 16-bit PCM mono samples at 44100 Hz. */
    fun render(params: SfxParams): ShortArray = generate(params.toFloatArray())

    @JvmStatic
    private external fun generate(params: FloatArray): ShortArray
}
