package com.soundfxmaker.app.data

import android.content.Context
import com.soundfxmaker.app.audio.SfxAudioPlayer
import com.soundfxmaker.app.audio.WavExporter
import com.soundfxmaker.app.core.NativeSynthEngine
import com.soundfxmaker.app.core.SfxCategory
import com.soundfxmaker.app.core.SfxParams
import com.soundfxmaker.app.core.WaveType
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/**
 * Single source of truth for generating, playing, saving and loading sound
 * effects. UI/ViewModel code should only ever talk to this class — never
 * directly to [NativeSynthEngine], [SfxAudioPlayer], or the filesystem.
 */
class SoundRepository(context: Context) {

    private val player = SfxAudioPlayer()
    private val soundsDir: File by lazy {
        File(context.getExternalFilesDir(null), "sounds").apply { mkdirs() }
    }
    private val libraryFile: File by lazy { File(soundsDir, "library.json") }

    /** CPU-bound; call from a background dispatcher. */
    fun render(params: SfxParams): ShortArray = NativeSynthEngine.render(params)

    fun play(samples: ShortArray) = player.play(samples)

    fun playFile(path: String) = player.playFile(path)

    fun stop() = player.stop()

    fun save(category: SfxCategory, params: SfxParams, samples: ShortArray, name: String): SavedSound {
        val id = UUID.randomUUID().toString()
        val file = File(soundsDir, "$id.wav")
        WavExporter.writeWav(file, samples)
        val sound = SavedSound(
            id = id,
            name = name,
            category = category,
            params = params,
            filePath = file.absolutePath,
            createdAtMillis = System.currentTimeMillis()
        )
        persistLibrary(loadLibrary() + sound)
        return sound
    }

    fun delete(sound: SavedSound) {
        File(sound.filePath).delete()
        persistLibrary(loadLibrary().filterNot { it.id == sound.id })
    }

    fun loadLibrary(): List<SavedSound> {
        if (!libraryFile.exists()) return emptyList()
        val text = libraryFile.readText()
        if (text.isBlank()) return emptyList()
        val array = JSONArray(text)
        return (0 until array.length()).mapNotNull { i ->
            runCatching { fromJson(array.getJSONObject(i)) }.getOrNull()
        }
    }

    private fun persistLibrary(sounds: List<SavedSound>) {
        val array = JSONArray()
        sounds.forEach { array.put(toJson(it)) }
        libraryFile.writeText(array.toString())
    }

    private fun toJson(s: SavedSound): JSONObject = JSONObject().apply {
        put("id", s.id)
        put("name", s.name)
        put("category", s.category.name)
        put("filePath", s.filePath)
        put("createdAtMillis", s.createdAtMillis)
        put("params", paramsToJson(s.params))
    }

    private fun fromJson(o: JSONObject): SavedSound = SavedSound(
        id = o.getString("id"),
        name = o.getString("name"),
        category = SfxCategory.valueOf(o.getString("category")),
        params = paramsFromJson(o.getJSONObject("params")),
        filePath = o.getString("filePath"),
        createdAtMillis = o.getLong("createdAtMillis")
    )

    private fun paramsToJson(p: SfxParams): JSONObject = JSONObject().apply {
        put("waveType", p.waveType.name)
        put("baseFreq", p.baseFreq); put("freqLimit", p.freqLimit); put("freqRamp", p.freqRamp)
        put("dutyCycle", p.dutyCycle); put("dutyRamp", p.dutyRamp)
        put("vibratoDepth", p.vibratoDepth); put("vibratoSpeed", p.vibratoSpeed)
        put("attackTime", p.attackTime); put("sustainTime", p.sustainTime)
        put("sustainPunch", p.sustainPunch); put("decayTime", p.decayTime)
        put("lpfCutoff", p.lpfCutoff); put("lpfCutoffRamp", p.lpfCutoffRamp); put("lpfResonance", p.lpfResonance)
        put("hpfCutoff", p.hpfCutoff); put("hpfCutoffRamp", p.hpfCutoffRamp)
        put("phaserOffset", p.phaserOffset); put("phaserRamp", p.phaserRamp)
        put("repeatSpeed", p.repeatSpeed)
        put("arpeggioMod", p.arpeggioMod); put("arpeggioSpeed", p.arpeggioSpeed)
        put("volume", p.volume)
    }

    private fun paramsFromJson(o: JSONObject): SfxParams = SfxParams(
        waveType = WaveType.valueOf(o.getString("waveType")),
        baseFreq = o.getDouble("baseFreq").toFloat(),
        freqLimit = o.getDouble("freqLimit").toFloat(),
        freqRamp = o.getDouble("freqRamp").toFloat(),
        dutyCycle = o.getDouble("dutyCycle").toFloat(),
        dutyRamp = o.getDouble("dutyRamp").toFloat(),
        vibratoDepth = o.getDouble("vibratoDepth").toFloat(),
        vibratoSpeed = o.getDouble("vibratoSpeed").toFloat(),
        attackTime = o.getDouble("attackTime").toFloat(),
        sustainTime = o.getDouble("sustainTime").toFloat(),
        sustainPunch = o.getDouble("sustainPunch").toFloat(),
        decayTime = o.getDouble("decayTime").toFloat(),
        lpfCutoff = o.getDouble("lpfCutoff").toFloat(),
        lpfCutoffRamp = o.getDouble("lpfCutoffRamp").toFloat(),
        lpfResonance = o.getDouble("lpfResonance").toFloat(),
        hpfCutoff = o.getDouble("hpfCutoff").toFloat(),
        hpfCutoffRamp = o.getDouble("hpfCutoffRamp").toFloat(),
        phaserOffset = o.getDouble("phaserOffset").toFloat(),
        phaserRamp = o.getDouble("phaserRamp").toFloat(),
        repeatSpeed = o.getDouble("repeatSpeed").toFloat(),
        arpeggioMod = o.getDouble("arpeggioMod").toFloat(),
        arpeggioSpeed = o.getDouble("arpeggioSpeed").toFloat(),
        volume = o.getDouble("volume").toFloat()
    )
}
