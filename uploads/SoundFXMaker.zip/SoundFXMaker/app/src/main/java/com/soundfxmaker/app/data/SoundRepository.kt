package com.soundfxmaker.app.data

import android.content.Context
import com.soundfxmaker.app.audio.SfxAudioPlayer
import com.soundfxmaker.app.audio.SoundMixer
import com.soundfxmaker.app.audio.WavExporter
import com.soundfxmaker.app.audio.WavReader
import com.soundfxmaker.app.core.NativeSynthEngine
import com.soundfxmaker.app.core.SfxCategory
import com.soundfxmaker.app.core.SfxParams
import com.soundfxmaker.app.core.WaveType
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/**
 * Single source of truth for generating, playing, saving and loading sound
 * effects. UI/ViewModel code should only ever talk to this class — never
 * directly to [NativeSynthEngine], [SfxAudioPlayer], or the filesystem.
 */
class SoundRepository(context: Context) {

    companion object {
        const val SAMPLE_RATE = 44100
    }

    private val player = SfxAudioPlayer(SAMPLE_RATE)
    private val soundsDir: File by lazy {
        File(context.getExternalFilesDir(null), "sounds").apply { mkdirs() }
    }
    private val libraryFile: File by lazy { File(soundsDir, "library.json") }

    /** CPU-bound; call from a background dispatcher. */
    fun render(params: SfxParams): ShortArray = NativeSynthEngine.render(params)

    fun play(samples: ShortArray) = player.play(samples)

    fun playFile(path: String) = player.playFile(path)

    fun stop() = player.stop()

    fun save(category: SfxCategory, source: SoundSource, params: SfxParams?, samples: ShortArray, name: String): SavedSound {
        val id = UUID.randomUUID().toString()
        val file = File(soundsDir, "$id.wav")
        WavExporter.writeWav(file, samples, SAMPLE_RATE)
        val sound = SavedSound(
            id = id,
            name = name,
            category = category,
            source = source,
            params = params,
            filePath = file.absolutePath,
            durationSeconds = samples.size / SAMPLE_RATE.toFloat(),
            createdAtMillis = System.currentTimeMillis()
        )
        persistLibrary(loadLibrary() + sound)
        return sound
    }

    /** Convenience wrapper for a freshly-recorded buffer — always Custom
     *  category (there's no preset it belongs to) with no synthesis params. */
    fun saveRecording(samples: ShortArray, name: String): SavedSound =
        save(category = SfxCategory.CUSTOM, source = SoundSource.RECORDED, params = null, samples = samples, name = name)

    /** Layers two saved sounds so they play simultaneously. */
    fun combine(a: SavedSound, b: SavedSound, name: String): SavedSound {
        val mixed = SoundMixer.mix(readSamples(a), readSamples(b))
        return save(category = SfxCategory.CUSTOM, source = SoundSource.MIXED, params = null, samples = mixed, name = name)
    }

    /** Plays two saved sounds one after the other as a single new sound. */
    fun continueWith(a: SavedSound, b: SavedSound, name: String): SavedSound {
        val joined = SoundMixer.concatenate(readSamples(a), readSamples(b))
        return save(category = SfxCategory.CUSTOM, source = SoundSource.MIXED, params = null, samples = joined, name = name)
    }

    /** Returns just the trimmed samples, for previewing before committing. */
    fun previewTrim(sound: SavedSound, startSeconds: Float, endSeconds: Float): ShortArray {
        val samples = readSamples(sound)
        val startSample = (startSeconds * SAMPLE_RATE).toInt().coerceIn(0, samples.size)
        val endSample = (endSeconds * SAMPLE_RATE).toInt().coerceIn(startSample, samples.size)
        return samples.copyOfRange(startSample, endSample)
    }

    /** Cuts a saved sound down to [startSeconds]..[endSeconds] and saves the
     *  result as a new library entry (non-destructive — the original stays). */
    fun trim(sound: SavedSound, startSeconds: Float, endSeconds: Float, name: String): SavedSound {
        val trimmed = previewTrim(sound, startSeconds, endSeconds)
        return save(category = sound.category, source = SoundSource.TRIMMED, params = null, samples = trimmed, name = name)
    }

    fun delete(sound: SavedSound) {
        File(sound.filePath).delete()
        persistLibrary(loadLibrary().filterNot { it.id == sound.id })
    }

    fun loadLibrary(): List<SavedSound> {
        if (!libraryFile.exists()) return emptyList()
        val text = libraryFile.readText()
        if (text.isBlank()) return emptyList()
        val array = JSONArray(text)
        return (0 until array.length()).mapNotNull { i ->
            runCatching { fromJson(array.getJSONObject(i)) }.getOrNull()
        }
    }

    private fun readSamples(sound: SavedSound): ShortArray = WavReader.readSamples(File(sound.filePath))

    private fun persistLibrary(sounds: List<SavedSound>) {
        val array = JSONArray()
        sounds.forEach { array.put(toJson(it)) }
        libraryFile.writeText(array.toString())
    }

    private fun toJson(s: SavedSound): JSONObject = JSONObject().apply {
        put("id", s.id)
        put("name", s.name)
        put("category", s.category.name)
        put("source", s.source.name)
        put("filePath", s.filePath)
        put("durationSeconds", s.durationSeconds)
        put("createdAtMillis", s.createdAtMillis)
        if (s.params != null) put("params", paramsToJson(s.params))
    }

    private fun fromJson(o: JSONObject): SavedSound {
        val filePath = o.getString("filePath")
        return SavedSound(
            id = o.getString("id"),
            name = o.getString("name"),
            category = SfxCategory.valueOf(o.getString("category")),
            // "source"/"durationSeconds" didn't exist in library.json before
            // this version — fall back gracefully for anything saved earlier.
            source = if (o.has("source")) SoundSource.valueOf(o.getString("source")) else SoundSource.GENERATED,
            params = if (o.has("params")) paramsFromJson(o.getJSONObject("params")) else null,
            filePath = filePath,
            durationSeconds = if (o.has("durationSeconds")) {
                o.getDouble("durationSeconds").toFloat()
            } else {
                runCatching { WavReader.readSamples(File(filePath)).size / SAMPLE_RATE.toFloat() }.getOrDefault(0f)
            },
            createdAtMillis = o.getLong("createdAtMillis")
        )
    }

    private fun paramsToJson(p: SfxParams): JSONObject = JSONObject().apply {
        put("waveType", p.waveType.name)
        put("baseFreq", p.baseFreq); put("freqLimit", p.freqLimit); put("freqRamp", p.freqRamp)
        put("dutyCycle", p.dutyCycle); put("dutyRamp", p.dutyRamp)
        put("vibratoDepth", p.vibratoDepth); put("vibratoSpeed", p.vibratoSpeed)
        put("attackTime", p.attackTime); put("sustainTime", p.sustainTime)
        put("sustainPunch", p.sustainPunch); put("decayTime", p.decayTime)
        put("lpfCutoff", p.lpfCutoff); put("lpfCutoffRamp", p.lpfCutoffRamp); put("lpfResonance", p.lpfResonance)
        put("hpfCutoff", p.hpfCutoff); put("hpfCutoffRamp", p.hpfCutoffRamp)
        put("phaserOffset", p.phaserOffset); put("phaserRamp", p.phaserRamp)
        put("repeatSpeed", p.repeatSpeed)
        put("arpeggioMod", p.arpeggioMod); put("arpeggioSpeed", p.arpeggioSpeed)
        put("volume", p.volume)
    }

    private fun paramsFromJson(o: JSONObject): SfxParams = SfxParams(
        waveType = WaveType.valueOf(o.getString("waveType")),
        baseFreq = o.getDouble("baseFreq").toFloat(),
        freqLimit = o.getDouble("freqLimit").toFloat(),
        freqRamp = o.getDouble("freqRamp").toFloat(),
        dutyCycle = o.getDouble("dutyCycle").toFloat(),
        dutyRamp = o.getDouble("dutyRamp").toFloat(),
        vibratoDepth = o.getDouble("vibratoDepth").toFloat(),
        vibratoSpeed = o.getDouble("vibratoSpeed").toFloat(),
        attackTime = o.getDouble("attackTime").toFloat(),
        sustainTime = o.getDouble("sustainTime").toFloat(),
        sustainPunch = o.getDouble("sustainPunch").toFloat(),
        decayTime = o.getDouble("decayTime").toFloat(),
        lpfCutoff = o.getDouble("lpfCutoff").toFloat(),
        lpfCutoffRamp = o.getDouble("lpfCutoffRamp").toFloat(),
        lpfResonance = o.getDouble("lpfResonance").toFloat(),
        hpfCutoff = o.getDouble("hpfCutoff").toFloat(),
        hpfCutoffRamp = o.getDouble("hpfCutoffRamp").toFloat(),
        phaserOffset = o.getDouble("phaserOffset").toFloat(),
        phaserRamp = o.getDouble("phaserRamp").toFloat(),
        repeatSpeed = o.getDouble("repeatSpeed").toFloat(),
        arpeggioMod = o.getDouble("arpeggioMod").toFloat(),
        arpeggioSpeed = o.getDouble("arpeggioSpeed").toFloat(),
        volume = o.getDouble("volume").toFloat()
    )
}
