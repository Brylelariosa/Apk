package com.soundfxmaker.app.audio

import java.io.File

/**
 * Reads a mono 16-bit PCM WAV file back into raw samples — the inverse of
 * [WavExporter]. Only needs to handle files this app itself wrote (every
 * saved sound goes through [WavExporter]), so it assumes the exact 44-byte
 * header layout [WavExporter] always produces rather than doing general
 * RIFF chunk parsing.
 */
object WavReader {

    private const val HEADER_SIZE = 44

    fun readSamples(file: File): ShortArray {
        val bytes = file.readBytes()
        if (bytes.size <= HEADER_SIZE) return ShortArray(0)

        val sampleCount = (bytes.size - HEADER_SIZE) / 2
        val samples = ShortArray(sampleCount)
        for (i in 0 until sampleCount) {
            val lo = bytes[HEADER_SIZE + i * 2].toInt() and 0xFF
            val hi = bytes[HEADER_SIZE + i * 2 + 1].toInt()
            samples[i] = ((hi shl 8) or lo).toShort()
        }
        return samples
    }
}
