package com.soundfxmaker.app.core

/** The classic retro-game sound effect categories, à la sfxr/bfxr, plus a
 *  Custom mode that starts from a blank slate for full manual control. */
enum class SfxCategory(val displayName: String) {
    CUSTOM("Custom"),
    PICKUP_COIN("Pickup / Coin"),
    LASER_SHOOT("Laser / Shoot"),
    EXPLOSION("Explosion"),
    POWERUP("Power-Up"),
    HIT_HURT("Hit / Hurt"),
    JUMP("Jump"),
    BLIP_SELECT("Blip / Select"),
    RANDOM("Random")
}
