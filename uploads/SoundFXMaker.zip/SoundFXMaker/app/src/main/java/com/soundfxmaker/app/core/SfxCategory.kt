package com.soundfxmaker.app.core

/** The classic retro-game sound effect categories, à la sfxr/bfxr. */
enum class SfxCategory(val displayName: String) {
    PICKUP_COIN("Pickup / Coin"),
    LASER_SHOOT("Laser / Shoot"),
    EXPLOSION("Explosion"),
    POWERUP("Power-Up"),
    HIT_HURT("Hit / Hurt"),
    JUMP("Jump"),
    BLIP_SELECT("Blip / Select"),
    RANDOM("Random")
}
