package com.soundfxmaker.app.core

enum class WaveType(val nativeValue: Int) {
    SQUARE(0), SAWTOOTH(1), SINE(2), NOISE(3), TRIANGLE(4)
}

/**
 * Parameters describing a single procedurally generated sound effect.
 *
 * Field order and meaning must stay in sync with `SynthParams` in
 * app/src/main/cpp/core/synth_engine.h — [toFloatArray] passes this struct
 * across the JNI boundary as a flat array, and native code reads it back
 * positionally. If you add a field here, add it in the same position there.
 */
data class SfxParams(
    val waveType: WaveType = WaveType.SQUARE,
    val baseFreq: Float = 0.3f,
    val freqLimit: Float = 0f,
    val freqRamp: Float = 0f,
    val dutyCycle: Float = 0.5f,
    val dutyRamp: Float = 0f,
    val vibratoDepth: Float = 0f,
    val vibratoSpeed: Float = 0f,
    val attackTime: Float = 0f,
    val sustainTime: Float = 0.3f,
    val sustainPunch: Float = 0f,
    val decayTime: Float = 0.4f,
    val lpfCutoff: Float = 1f,
    val lpfCutoffRamp: Float = 0f,
    val lpfResonance: Float = 0f,
    val hpfCutoff: Float = 0f,
    val hpfCutoffRamp: Float = 0f,
    val phaserOffset: Float = 0f,
    val phaserRamp: Float = 0f,
    val repeatSpeed: Float = 0f,
    val arpeggioMod: Float = 0f,
    val arpeggioSpeed: Float = 0f,
    val volume: Float = 0.5f
) {
    fun toFloatArray(): FloatArray = floatArrayOf(
        waveType.nativeValue.toFloat(), baseFreq, freqLimit, freqRamp,
        dutyCycle, dutyRamp, vibratoDepth, vibratoSpeed,
        attackTime, sustainTime, sustainPunch, decayTime,
        lpfCutoff, lpfCutoffRamp, lpfResonance,
        hpfCutoff, hpfCutoffRamp,
        phaserOffset, phaserRamp,
        repeatSpeed, arpeggioMod, arpeggioSpeed,
        volume
    )
}
