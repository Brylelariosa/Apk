package com.soundfxmaker.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.unit.dp
import kotlin.math.max

/** Draws a lightweight downsampled waveform of the currently generated sound. */
@Composable
fun WaveformView(samples: List<Short>, modifier: Modifier = Modifier) {
    val color = MaterialTheme.colorScheme.secondary
    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(96.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
    ) {
        if (samples.isEmpty()) return@Canvas

        val pointCount = 220
        val step = max(1, samples.size / pointCount)
        val midY = size.height / 2f
        val scaleY = midY * 0.9f

        var x = 0f
        val dx = size.width / (samples.size / step).coerceAtLeast(1)
        var previous: Offset? = null

        var i = 0
        while (i < samples.size) {
            val normalized = samples[i] / 32768f
            val point = Offset(x, midY - normalized * scaleY)
            previous?.let { drawLine(color = color, start = it, end = point, strokeWidth = 3f) }
            previous = point
            x += dx
            i += step
        }
    }
}
