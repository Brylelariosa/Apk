package com.soundfxmaker.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import com.soundfxmaker.app.ui.SoundFxViewModel
import com.soundfxmaker.app.ui.screens.MainScreen
import com.soundfxmaker.app.ui.theme.SoundFxMakerTheme

class MainActivity : ComponentActivity() {

    private val viewModel: SoundFxViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SoundFxMakerTheme {
                MainScreen(viewModel)
            }
        }
    }
}
