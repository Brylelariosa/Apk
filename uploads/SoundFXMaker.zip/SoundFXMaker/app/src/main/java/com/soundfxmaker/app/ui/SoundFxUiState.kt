package com.soundfxmaker.app.ui

import com.soundfxmaker.app.core.SfxCategory
import com.soundfxmaker.app.core.SfxParams
import com.soundfxmaker.app.data.SavedSound

data class SoundFxUiState(
    val selectedCategory: SfxCategory = SfxCategory.CUSTOM,
    val currentParams: SfxParams = SfxParams(),
    val currentSamples: List<Short> = emptyList(),
    val isGenerating: Boolean = false,
    val previewProgress: Float = 0f,
    val savedSounds: List<SavedSound> = emptyList(),
    val playingSavedSoundId: String? = null,
    val savedPlaybackProgress: Float = 0f,
    val isRecording: Boolean = false,
    val pendingRecordingSamples: List<Short> = emptyList(),
    val mixSelection: List<String> = emptyList()
)
