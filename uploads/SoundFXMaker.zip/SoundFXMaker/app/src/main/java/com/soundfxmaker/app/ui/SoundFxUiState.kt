package com.soundfxmaker.app.ui

import com.soundfxmaker.app.core.SfxCategory
import com.soundfxmaker.app.core.SfxParams
import com.soundfxmaker.app.data.SavedSound

// currentSamples/pendingRecordingSamples use reference equality (Kotlin data
// classes don't do structural array comparison) — that's fine here, since a
// fresh render or recording always produces a new array anyway, so it never
// causes stale-looking state.
@Suppress("ArrayInDataClass")
data class SoundFxUiState(
    val selectedCategory: SfxCategory = SfxCategory.CUSTOM,
    val currentParams: SfxParams = SfxParams(),
    val currentSamples: ShortArray = ShortArray(0),
    val isGenerating: Boolean = false,
    val previewProgress: Float = 0f,
    val canUndo: Boolean = false,
    val savedSounds: List<SavedSound> = emptyList(),
    val playingSavedSoundId: String? = null,
    val savedPlaybackProgress: Float = 0f,
    val isRecording: Boolean = false,
    val pendingRecordingSamples: ShortArray = ShortArray(0),
    val mixSelection: List<String> = emptyList(),
    val librarySearchQuery: String = ""
)
