package com.soundfxmaker.app.ui

import com.soundfxmaker.app.core.SfxCategory
import com.soundfxmaker.app.core.SfxParams
import com.soundfxmaker.app.data.SavedSound

data class SoundFxUiState(
    val selectedCategory: SfxCategory = SfxCategory.PICKUP_COIN,
    val currentParams: SfxParams = SfxParams(),
    val currentSamples: List<Short> = emptyList(),
    val isGenerating: Boolean = false,
    val savedSounds: List<SavedSound> = emptyList(),
    val showAdvanced: Boolean = false
)
