package com.soundfxmaker.app.data

/**
 * How a saved sound came to exist. Only [GENERATED] sounds carry synthesis
 * parameters, so this is what the UI checks before offering "edit" on a
 * saved sound — you can't re-open a recording's non-existent slider values.
 */
enum class SoundSource { GENERATED, RECORDED, MIXED, TRIMMED }
