package com.soundfxmaker.app.ui.theme

import androidx.compose.ui.graphics.Color

// A dark, synth-lab palette: near-black background, electric violet primary,
// warm amber accent for the "generate" action.
val Background = Color(0xFF0E0B16)
val Surface = Color(0xFF191423)
val SurfaceVariant = Color(0xFF241C33)
val Primary = Color(0xFF8B5CF6)
val PrimaryVariant = Color(0xFF6D28D9)
val Accent = Color(0xFFFFB020)
val OnBackground = Color(0xFFEDE9F5)
val OnSurfaceMuted = Color(0xFFA79FC0)
