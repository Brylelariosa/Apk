package com.soundfxmaker.app.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.soundfxmaker.app.core.SfxCategory
import com.soundfxmaker.app.ui.SoundFxViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: SoundFxViewModel) {
    val state by viewModel.uiState.collectAsState()
    val context = LocalContext.current

    var showSaveDialog by remember { mutableStateOf(false) }
    var showMixDialog by remember { mutableStateOf(false) }
    var hasMicPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        )
    }
    var micPermissionDenied by remember { mutableStateOf(false) }

    val micPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        hasMicPermission = granted
        micPermissionDenied = !granted
        if (granted) viewModel.startRecording()
    }

    val scrollState = rememberScrollState()
    LaunchedEffect(state.selectedCategory) {
        if (state.selectedCategory == SfxCategory.CUSTOM) scrollState.animateScrollTo(0)
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Sound FX Maker") }) }
    ) { padding: PaddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
                .verticalScroll(scrollState)
        ) {
            Text(
                text = "Choose Custom to build a sound from scratch with the sliders below, " +
                    "or pick a preset category as a starting point.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(vertical = 8.dp)
            )

            CategoryGrid(
                selected = state.selectedCategory,
                onSelect = viewModel::selectCategory,
                modifier = Modifier.fillMaxWidth()
            )

            WaveformView(samples = state.currentSamples, modifier = Modifier.padding(top = 16.dp))

            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(onClick = { viewModel.generate() }, modifier = Modifier.weight(1f)) {
                    Text("New")
                }
                OutlinedButton(onClick = viewModel::mutateCurrent, modifier = Modifier.weight(1f)) {
                    Text("Tweak")
                }
                FilledIconButton(
                    onClick = viewModel::play,
                    colors = IconButtonDefaults.filledIconButtonColors(containerColor = MaterialTheme.colorScheme.secondary)
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = "Play")
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(onClick = { showSaveDialog = true }, modifier = Modifier.weight(1f)) {
                    Text("Save to library")
                }
                TextButton(onClick = viewModel::toggleAdvanced) {
                    Text(if (state.showAdvanced) "Hide fine-tuning" else "Fine-tune")
                }
            }

            if (state.showAdvanced) {
                ParamsEditor(params = state.currentParams, onChange = viewModel::updateParams)
            }

            Button(
                onClick = {
                    when {
                        state.isRecording -> viewModel.stopRecording()
                        hasMicPermission -> viewModel.startRecording()
                        else -> micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }
                },
                modifier = Modifier.fillMaxWidth().padding(top = 20.dp)
            ) {
                Text(if (state.isRecording) "Stop recording" else "Record a sound")
            }
            if (micPermissionDenied && !hasMicPermission) {
                Text(
                    text = "Microphone access is needed to record — enable it in system settings.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }

            SavedSoundsList(
                sounds = state.savedSounds,
                selectedForMix = state.mixSelection,
                onPlay = viewModel::playSaved,
                onEdit = viewModel::loadForEditing,
                onDelete = viewModel::deleteSaved,
                onToggleMixSelect = viewModel::toggleMixSelection,
                onMixSelected = { showMixDialog = true },
                modifier = Modifier.padding(top = 24.dp, bottom = 24.dp)
            )
        }
    }

    if (showSaveDialog) {
        NameAndSaveDialog(
            title = "Save sound",
            initialName = state.selectedCategory.displayName,
            onDismiss = { showSaveDialog = false },
            onConfirm = { name ->
                viewModel.saveCurrent(name)
                showSaveDialog = false
            }
        )
    }

    if (state.pendingRecordingSamples.isNotEmpty()) {
        NameAndSaveDialog(
            title = "Save recording",
            initialName = "Recording",
            onDismiss = viewModel::discardRecording,
            onConfirm = { name -> viewModel.saveRecording(name) }
        )
    }

    if (showMixDialog) {
        val names = state.mixSelection.mapNotNull { id -> state.savedSounds.firstOrNull { it.id == id }?.name }
        NameAndSaveDialog(
            title = "Save mix",
            initialName = names.joinToString(" + ").ifBlank { "Mix" },
            onDismiss = { showMixDialog = false },
            onConfirm = { name ->
                viewModel.mixSelected(name)
                showMixDialog = false
            }
        )
    }
}

@Composable
private fun NameAndSaveDialog(
    title: String,
    initialName: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var name by remember(initialName) { mutableStateOf(initialName) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Name") }, singleLine = true)
        },
        confirmButton = { TextButton(onClick = { onConfirm(name) }) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
