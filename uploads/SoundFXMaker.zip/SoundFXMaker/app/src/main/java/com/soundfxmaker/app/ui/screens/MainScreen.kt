package com.soundfxmaker.app.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.soundfxmaker.app.core.SfxCategory
import com.soundfxmaker.app.data.SavedSound
import com.soundfxmaker.app.data.SoundSource
import com.soundfxmaker.app.ui.SoundFxViewModel

private enum class AppMode { NORMAL, STUDIO }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: SoundFxViewModel) {
    val state by viewModel.uiState.collectAsState()
    val context = LocalContext.current

    var mode by remember { mutableStateOf(AppMode.NORMAL) }
    var showSaveDialog by remember { mutableStateOf(false) }
    var showCombineDialog by remember { mutableStateOf(false) }
    var showContinueDialog by remember { mutableStateOf(false) }
    var trimTarget by remember { mutableStateOf<SavedSound?>(null) }

    var hasMicPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        )
    }
    var micPermissionDenied by remember { mutableStateOf(false) }
    val micPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        hasMicPermission = granted
        micPermissionDenied = !granted
        if (granted) viewModel.startRecording()
    }

    val scrollState = rememberScrollState()
    LaunchedEffect(mode) {
        if (mode == AppMode.STUDIO) scrollState.animateScrollTo(0)
    }

    Scaffold(
        topBar = {
            Column {
                TopAppBar(title = { Text("Sound FX Maker") })
                TabRow(selectedTabIndex = mode.ordinal) {
                    Tab(selected = mode == AppMode.NORMAL, onClick = { mode = AppMode.NORMAL }, text = { Text("Normal") })
                    Tab(selected = mode == AppMode.STUDIO, onClick = { mode = AppMode.STUDIO }, text = { Text("Studio") })
                }
            }
        }
    ) { padding: PaddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
                .verticalScroll(scrollState)
        ) {
            when (mode) {
                AppMode.NORMAL -> {
                    Text(
                        text = "Pick a category and generate — every sound is synthesized on the fly.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                    CategoryGrid(
                        selected = state.selectedCategory,
                        onSelect = viewModel::selectCategory,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                AppMode.STUDIO -> {
                    Text(
                        text = "Build a sound from scratch, record your own, or edit and combine sounds from your library.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                }
            }

            WaveformView(samples = state.currentSamples, modifier = Modifier.padding(top = 16.dp))
            LinearProgressIndicator(
                progress = state.previewProgress,
                modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(onClick = { viewModel.generate() }, modifier = Modifier.weight(1f)) {
                    Text("New")
                }
                OutlinedButton(onClick = viewModel::mutateCurrent, modifier = Modifier.weight(1f)) {
                    Text("Tweak")
                }
                FilledIconButton(
                    onClick = viewModel::play,
                    colors = IconButtonDefaults.filledIconButtonColors(containerColor = MaterialTheme.colorScheme.secondary)
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = "Play")
                }
            }

            Button(
                onClick = { showSaveDialog = true },
                modifier = Modifier.fillMaxWidth().padding(top = 10.dp)
            ) {
                Text("Save to library")
            }

            if (mode == AppMode.STUDIO) {
                ParamsEditor(params = state.currentParams, onChange = viewModel::updateParams)

                Button(
                    onClick = {
                        when {
                            state.isRecording -> viewModel.stopRecording()
                            hasMicPermission -> viewModel.startRecording()
                            else -> micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    },
                    modifier = Modifier.fillMaxWidth().padding(top = 20.dp)
                ) {
                    Text(if (state.isRecording) "Stop recording" else "Record a sound")
                }
                if (micPermissionDenied && !hasMicPermission) {
                    Text(
                        text = "Microphone access is needed to record — enable it in system settings.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }

            val studioOnly = mode == AppMode.STUDIO
            val editOrTrim: (SavedSound) -> Unit = { sound ->
                if (sound.source == SoundSource.GENERATED) {
                    viewModel.loadForEditing(sound)
                } else {
                    trimTarget = sound
                }
            }

            SavedSoundsList(
                sounds = state.savedSounds,
                selectedForMix = state.mixSelection,
                playingId = state.playingSavedSoundId,
                playingProgress = state.savedPlaybackProgress,
                onPlay = viewModel::playSaved,
                onDelete = viewModel::deleteSaved,
                onEdit = if (studioOnly) editOrTrim else null,
                onToggleMixSelect = if (studioOnly) viewModel::toggleMixSelection else null,
                onCombineSelected = if (studioOnly) ({ showCombineDialog = true }) else null,
                onContinueSelected = if (studioOnly) ({ showContinueDialog = true }) else null,
                modifier = Modifier.padding(top = 24.dp, bottom = 24.dp)
            )
        }
    }

    if (showSaveDialog) {
        NameAndSaveDialog(
            title = "Save sound",
            initialName = state.selectedCategory.displayName,
            onDismiss = { showSaveDialog = false },
            onConfirm = { name ->
                viewModel.saveCurrent(name)
                showSaveDialog = false
            }
        )
    }

    if (state.pendingRecordingSamples.isNotEmpty()) {
        NameAndSaveDialog(
            title = "Save recording",
            initialName = "Recording",
            onDismiss = viewModel::discardRecording,
            onConfirm = { name -> viewModel.saveRecording(name) }
        )
    }

    if (showCombineDialog) {
        val names = state.mixSelection.mapNotNull { id -> state.savedSounds.firstOrNull { it.id == id }?.name }
        NameAndSaveDialog(
            title = "Combine sounds (layered)",
            initialName = names.joinToString(" + ").ifBlank { "Combined" },
            onDismiss = { showCombineDialog = false },
            onConfirm = { name ->
                viewModel.combineSelected(name)
                showCombineDialog = false
            }
        )
    }

    if (showContinueDialog) {
        val names = state.mixSelection.mapNotNull { id -> state.savedSounds.firstOrNull { it.id == id }?.name }
        NameAndSaveDialog(
            title = "Continue with next sound (sequence)",
            initialName = names.joinToString(" then ").ifBlank { "Sequence" },
            onDismiss = { showContinueDialog = false },
            onConfirm = { name ->
                viewModel.continueSelected(name)
                showContinueDialog = false
            }
        )
    }

    trimTarget?.let { sound ->
        TrimDialog(
            sound = sound,
            onDismiss = { trimTarget = null },
            onPreview = { start, end -> viewModel.previewTrim(sound, start, end) },
            onSave = { start, end, name ->
                viewModel.saveTrim(sound, start, end, name)
                trimTarget = null
            }
        )
    }
}

@Composable
private fun NameAndSaveDialog(
    title: String,
    initialName: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var name by remember(initialName) { mutableStateOf(initialName) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Name") }, singleLine = true)
        },
        confirmButton = { TextButton(onClick = { onConfirm(name) }) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TrimDialog(
    sound: SavedSound,
    onDismiss: () -> Unit,
    onPreview: (Float, Float) -> Unit,
    onSave: (Float, Float, String) -> Unit
) {
    val maxSeconds = sound.durationSeconds.coerceAtLeast(0.1f)
    var range by remember { mutableStateOf(0f..maxSeconds) }
    var name by remember { mutableStateOf("${sound.name} (trimmed)") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Trim \"${sound.name}\"") },
        text = {
            Column {
                Text("%.1fs \u2013 %.1fs of %.1fs".format(range.start, range.endInclusive, maxSeconds))
                RangeSlider(
                    value = range,
                    onValueChange = { range = it },
                    valueRange = 0f..maxSeconds
                )
                TextButton(onClick = { onPreview(range.start, range.endInclusive) }) {
                    Text("Preview")
                }
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Name") },
                    singleLine = true
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(range.start, range.endInclusive, name) }) { Text("Save trimmed") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
