package com.soundfxmaker.app.ui.screens

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.soundfxmaker.app.data.SavedSound
import com.soundfxmaker.app.data.SoundSource
import com.soundfxmaker.app.ui.SoundFxViewModel
import java.io.File

private enum class AppMode(val label: String) { PRESETS("Presets"), STUDIO("Studio") }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: SoundFxViewModel) {
    val state by viewModel.uiState.collectAsState()
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    var mode by remember { mutableStateOf(AppMode.PRESETS) }
    var showSaveDialog by remember { mutableStateOf(false) }
    var showCombineDialog by remember { mutableStateOf(false) }
    var showContinueDialog by remember { mutableStateOf(false) }
    var trimTarget by remember { mutableStateOf<SavedSound?>(null) }
    var renameTarget by remember { mutableStateOf<SavedSound?>(null) }

    var hasMicPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        )
    }
    var micPermissionDenied by remember { mutableStateOf(false) }
    val micPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        hasMicPermission = granted
        micPermissionDenied = !granted
        if (granted) viewModel.startRecording()
    }

    LaunchedEffect(Unit) {
        viewModel.messages.collect { message -> snackbarHostState.showSnackbar(message) }
    }

    val scrollState = rememberScrollState()
    LaunchedEffect(mode) {
        if (mode == AppMode.STUDIO) scrollState.animateScrollTo(0)
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Sound FX Maker") }) },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = mode == AppMode.PRESETS,
                    onClick = { mode = AppMode.PRESETS },
                    icon = { Icon(Icons.Default.List, contentDescription = null) },
                    label = { Text(AppMode.PRESETS.label) }
                )
                NavigationBarItem(
                    selected = mode == AppMode.STUDIO,
                    onClick = { mode = AppMode.STUDIO },
                    icon = { Icon(Icons.Default.Edit, contentDescription = null) },
                    label = { Text(AppMode.STUDIO.label) }
                )
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { padding: PaddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
                .verticalScroll(scrollState)
        ) {
            when (mode) {
                AppMode.PRESETS -> {
                    Text(
                        text = "Pick a category and generate — every sound is synthesized on the fly.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                    CategoryGrid(
                        selected = state.selectedCategory,
                        onSelect = viewModel::selectCategory,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                AppMode.STUDIO -> {
                    Text(
                        text = "Build a sound from scratch, record your own, or edit and combine sounds from your library.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                }
            }

            WaveformView(
                samples = state.currentSamples,
                progress = state.previewProgress,
                modifier = Modifier.padding(top = 16.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(onClick = { viewModel.generate() }, modifier = Modifier.weight(1f)) {
                    Text("New")
                }
                OutlinedButton(onClick = viewModel::mutateCurrent, modifier = Modifier.weight(1f)) {
                    Text("Tweak")
                }
                if (state.canUndo) {
                    TextButton(onClick = viewModel::undo) { Text("Undo") }
                }
                FilledIconButton(
                    onClick = viewModel::play,
                    colors = IconButtonDefaults.filledIconButtonColors(containerColor = MaterialTheme.colorScheme.secondary)
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = "Play")
                }
            }

            Button(
                onClick = { showSaveDialog = true },
                modifier = Modifier.fillMaxWidth().padding(top = 10.dp)
            ) {
                Text("Save to library")
            }

            if (mode == AppMode.STUDIO) {
                ParamsEditor(params = state.currentParams, onChange = viewModel::updateParams)

                Button(
                    onClick = {
                        when {
                            state.isRecording -> viewModel.stopRecording()
                            hasMicPermission -> viewModel.startRecording()
                            else -> micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    },
                    modifier = Modifier.fillMaxWidth().padding(top = 20.dp)
                ) {
                    Text(if (state.isRecording) "Stop recording" else "Record a sound")
                }
                if (micPermissionDenied && !hasMicPermission) {
                    Text(
                        text = "Microphone access is needed to record — enable it in system settings.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }

            if (state.savedSounds.size > 3) {
                OutlinedTextField(
                    value = state.librarySearchQuery,
                    onValueChange = viewModel::setLibrarySearchQuery,
                    label = { Text("Search saved sounds") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(top = 24.dp)
                )
            }

            val studioOnly = mode == AppMode.STUDIO
            val editOrTrim: (SavedSound) -> Unit = { sound ->
                if (sound.source == SoundSource.GENERATED) {
                    viewModel.loadForEditing(sound)
                } else {
                    trimTarget = sound
                }
            }
            val visibleSounds = state.savedSounds.filter {
                it.name.contains(state.librarySearchQuery, ignoreCase = true)
            }

            SavedSoundsList(
                sounds = visibleSounds,
                selectedForMix = state.mixSelection,
                playingId = state.playingSavedSoundId,
                playingProgress = state.savedPlaybackProgress,
                onPlay = viewModel::playSaved,
                onDelete = viewModel::deleteSaved,
                onEdit = if (studioOnly) editOrTrim else null,
                onRename = if (studioOnly) ({ sound -> renameTarget = sound }) else null,
                onShare = if (studioOnly) ({ sound -> shareSound(context, sound) }) else null,
                onToggleMixSelect = if (studioOnly) viewModel::toggleMixSelection else null,
                onCombineSelected = if (studioOnly) ({ showCombineDialog = true }) else null,
                onContinueSelected = if (studioOnly) ({ showContinueDialog = true }) else null,
                modifier = Modifier.padding(top = 16.dp, bottom = 24.dp)
            )
        }
    }

    if (showSaveDialog) {
        NameAndSaveDialog(
            title = "Save sound",
            initialName = state.selectedCategory.displayName,
            confirmLabel = "Save",
            onDismiss = { showSaveDialog = false },
            onConfirm = { name ->
                viewModel.saveCurrent(name)
                showSaveDialog = false
            }
        )
    }

    if (state.pendingRecordingSamples.isNotEmpty()) {
        NameAndSaveDialog(
            title = "Save recording",
            initialName = "Recording",
            confirmLabel = "Save",
            onDismiss = viewModel::discardRecording,
            onConfirm = { name -> viewModel.saveRecording(name) }
        )
    }

    if (showCombineDialog) {
        val names = state.mixSelection.mapNotNull { id -> state.savedSounds.firstOrNull { it.id == id }?.name }
        NameAndSaveDialog(
            title = "Combine sounds (layered)",
            initialName = names.joinToString(" + ").ifBlank { "Combined" },
            confirmLabel = "Save",
            onDismiss = { showCombineDialog = false },
            onConfirm = { name ->
                viewModel.combineSelected(name)
                showCombineDialog = false
            }
        )
    }

    if (showContinueDialog) {
        val names = state.mixSelection.mapNotNull { id -> state.savedSounds.firstOrNull { it.id == id }?.name }
        NameAndSaveDialog(
            title = "Continue with next sound (sequence)",
            initialName = names.joinToString(" then ").ifBlank { "Sequence" },
            confirmLabel = "Save",
            onDismiss = { showContinueDialog = false },
            onConfirm = { name ->
                viewModel.continueSelected(name)
                showContinueDialog = false
            }
        )
    }

    renameTarget?.let { sound ->
        NameAndSaveDialog(
            title = "Rename sound",
            initialName = sound.name,
            confirmLabel = "Rename",
            onDismiss = { renameTarget = null },
            onConfirm = { name ->
                viewModel.renameSaved(sound, name)
                renameTarget = null
            }
        )
    }

    trimTarget?.let { sound ->
        TrimDialog(
            sound = sound,
            onDismiss = { trimTarget = null },
            onPreview = { start, end -> viewModel.previewTrim(sound, start, end) },
            onSave = { start, end, name ->
                viewModel.saveTrim(sound, start, end, name)
                trimTarget = null
            }
        )
    }
}

private fun shareSound(context: Context, sound: SavedSound) {
    val file = File(sound.filePath)
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "audio/wav"
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(intent, "Share ${sound.name}"))
}

@Composable
private fun NameAndSaveDialog(
    title: String,
    initialName: String,
    confirmLabel: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var name by remember(initialName) { mutableStateOf(initialName) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Name") }, singleLine = true)
        },
        confirmButton = { TextButton(onClick = { onConfirm(name) }) { Text(confirmLabel) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TrimDialog(
    sound: SavedSound,
    onDismiss: () -> Unit,
    onPreview: (Float, Float) -> Unit,
    onSave: (Float, Float, String) -> Unit
) {
    val maxSeconds = sound.durationSeconds.coerceAtLeast(0.1f)
    var range by remember { mutableStateOf(0f..maxSeconds) }
    var name by remember { mutableStateOf("${sound.name} (trimmed)") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Trim \"${sound.name}\"") },
        text = {
            Column {
                Text("%.1fs \u2013 %.1fs of %.1fs".format(range.start, range.endInclusive, maxSeconds))
                RangeSlider(
                    value = range,
                    onValueChange = { range = it },
                    valueRange = 0f..maxSeconds
                )
                TextButton(onClick = { onPreview(range.start, range.endInclusive) }) {
                    Text("Preview")
                }
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Name") },
                    singleLine = true
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(range.start, range.endInclusive, name) }) { Text("Save trimmed") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
