package com.soundfxmaker.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.soundfxmaker.app.audio.SfxAudioRecorder
import com.soundfxmaker.app.core.SfxCategory
import com.soundfxmaker.app.core.SfxParams
import com.soundfxmaker.app.data.SavedSound
import com.soundfxmaker.app.data.SfxPresetGenerator
import com.soundfxmaker.app.data.SoundRepository
import com.soundfxmaker.app.data.SoundSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class SoundFxViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = SoundRepository(application)
    private val recorder = SfxAudioRecorder(SoundRepository.SAMPLE_RATE)

    private val _uiState = MutableStateFlow(SoundFxUiState())
    val uiState: StateFlow<SoundFxUiState> = _uiState

    // One-off, non-persistent messages (errors, warnings) for a Snackbar —
    // deliberately not part of SoundFxUiState, since that's re-delivered on
    // every recomposition/config change and would re-show a stale message.
    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 1, onBufferOverflow = BufferOverflow.DROP_OLDEST)
    val messages: SharedFlow<String> = _messages

    // Slider drags call updateParams() many times a second. The slider
    // position / displayed values need to track every tick instantly, but
    // actually re-rendering + replaying audio on every tick is expensive and
    // sounds like a stutter storm — so that part is routed through this flow
    // and debounced instead of running inline in updateParams().
    private val pendingRender = MutableSharedFlow<SfxParams>(extraBufferCapacity = 1, onBufferOverflow = BufferOverflow.DROP_OLDEST)

    private var previewProgressJob: Job? = null
    private var savedProgressJob: Job? = null
    private var renderJob: Job? = null

    // Single-level undo: captures the params in effect just before the
    // current "session" of changes (a New/Tweak tap, or a slider-drag
    // session) started. awaitingFreshSnapshot flips true again every time a
    // render completes, so the *next* change — whatever kind — captures a
    // fresh checkpoint rather than the checkpoint being overwritten mid-drag.
    private var previousParams: SfxParams? = null
    private var awaitingFreshSnapshot = true

    init {
        val loadResult = repository.loadLibrary()
        _uiState.update { it.copy(savedSounds = loadResult.sounds) }
        if (loadResult.droppedCount > 0) {
            _messages.tryEmit("${loadResult.droppedCount} saved sound(s) could not be loaded and were skipped.")
        }
        renderAndPlay(_uiState.value.currentParams)

        viewModelScope.launch {
            pendingRender.debounce(120L).collectLatest { params -> renderAndPlay(params) }
        }
    }

    fun selectCategory(category: SfxCategory) {
        _uiState.update { it.copy(selectedCategory = category) }
        generate(category)
    }

    fun generate(category: SfxCategory = _uiState.value.selectedCategory) {
        checkpointForUndo()
        renderAndPlay(SfxPresetGenerator.generate(category))
    }

    fun mutateCurrent() {
        checkpointForUndo()
        renderAndPlay(SfxPresetGenerator.mutate(_uiState.value.currentParams))
    }

    /** Called on every slider tick: updates what's displayed immediately,
     *  but the actual render + playback is debounced via [pendingRender]. */
    fun updateParams(params: SfxParams) {
        checkpointForUndo()
        _uiState.update { it.copy(currentParams = params) }
        pendingRender.tryEmit(params)
    }

    fun undo() {
        val prev = previousParams ?: return
        previousParams = null
        _uiState.update { it.copy(canUndo = false) }
        renderAndPlay(prev)
    }

    /** Loads a previously-saved generated sound back into Custom mode for
     *  further tweaking. Only valid for sounds that have synthesis params. */
    fun loadForEditing(sound: SavedSound) {
        val params = sound.params ?: return
        checkpointForUndo()
        _uiState.update { it.copy(selectedCategory = SfxCategory.CUSTOM) }
        renderAndPlay(params)
    }

    fun play() {
        val samples = _uiState.value.currentSamples
        repository.play(samples)
        previewProgressJob?.cancel()
        previewProgressJob = trackProgress(
            durationSeconds = samples.size / SoundRepository.SAMPLE_RATE.toFloat(),
            onTick = { p -> _uiState.update { it.copy(previewProgress = p) } },
            onFinished = { _uiState.update { it.copy(previewProgress = 0f) } }
        )
    }

    fun saveCurrent(name: String) {
        val state = _uiState.value
        val trimmed = name.ifBlank { state.selectedCategory.displayName }
        val saved = repository.save(
            category = state.selectedCategory,
            source = SoundSource.GENERATED,
            params = state.currentParams,
            samples = state.currentSamples,
            name = trimmed
        )
        _uiState.update { it.copy(savedSounds = it.savedSounds + saved) }
    }

    fun playSaved(sound: SavedSound) {
        repository.playFile(sound.filePath)
        savedProgressJob?.cancel()
        _uiState.update { it.copy(playingSavedSoundId = sound.id, savedPlaybackProgress = 0f) }
        savedProgressJob = trackProgress(
            durationSeconds = sound.durationSeconds,
            onTick = { p -> _uiState.update { it.copy(savedPlaybackProgress = p) } },
            onFinished = { _uiState.update { it.copy(playingSavedSoundId = null, savedPlaybackProgress = 0f) } }
        )
    }

    fun deleteSaved(sound: SavedSound) {
        repository.delete(sound)
        _uiState.update {
            it.copy(
                savedSounds = it.savedSounds.filterNot { s -> s.id == sound.id },
                // A sound selected for mixing can be deleted from the same
                // list — without this, a dangling id could leave the
                // Combine/Continue buttons visible but silently no-op-ing.
                mixSelection = it.mixSelection - sound.id
            )
        }
    }

    fun renameSaved(sound: SavedSound, newName: String) {
        if (newName.isBlank()) return
        val renamed = repository.rename(sound, newName)
        _uiState.update { state ->
            state.copy(savedSounds = state.savedSounds.map { if (it.id == sound.id) renamed else it })
        }
    }

    fun setLibrarySearchQuery(query: String) {
        _uiState.update { it.copy(librarySearchQuery = query) }
    }

    // --- Recording ---

    fun startRecording() {
        if (recorder.isRecording) return
        val started = recorder.start(viewModelScope)
        if (started) {
            _uiState.update { it.copy(isRecording = true) }
        } else {
            _messages.tryEmit("Couldn't start recording — the microphone may be in use.")
        }
    }

    fun stopRecording() {
        viewModelScope.launch {
            val samples = recorder.stop()
            _uiState.update { it.copy(isRecording = false, pendingRecordingSamples = samples) }
            if (samples.isNotEmpty()) repository.play(samples)
        }
    }

    fun saveRecording(name: String) {
        val samples = _uiState.value.pendingRecordingSamples
        if (samples.isEmpty()) return
        val saved = repository.saveRecording(samples, name.ifBlank { "Recording" })
        _uiState.update { it.copy(savedSounds = it.savedSounds + saved, pendingRecordingSamples = ShortArray(0)) }
    }

    fun discardRecording() {
        _uiState.update { it.copy(pendingRecordingSamples = ShortArray(0)) }
    }

    // --- Combine / continue (mixing two saved sounds) ---

    fun toggleMixSelection(sound: SavedSound) {
        _uiState.update { state ->
            val current = state.mixSelection
            val updated = when {
                sound.id in current -> current - sound.id
                current.size >= 2 -> current.drop(1) + sound.id // drop oldest, keep at most 2
                else -> current + sound.id
            }
            state.copy(mixSelection = updated)
        }
    }

    fun combineSelected(name: String) = withMixSelection("combine") { a, b ->
        repository.combine(a, b, name.ifBlank { "${a.name} + ${b.name}" })
    }

    fun continueSelected(name: String) = withMixSelection("continue") { a, b ->
        repository.continueWith(a, b, name.ifBlank { "${a.name} then ${b.name}" })
    }

    private inline fun withMixSelection(actionName: String, action: (SavedSound, SavedSound) -> SavedSound) {
        val ids = _uiState.value.mixSelection
        if (ids.size != 2) return
        val sounds = _uiState.value.savedSounds
        val a = sounds.firstOrNull { it.id == ids[0] } ?: return
        val b = sounds.firstOrNull { it.id == ids[1] } ?: return
        val result = try {
            action(a, b)
        } catch (e: Exception) {
            _messages.tryEmit("Couldn't $actionName those sounds — one of the files may be missing.")
            return
        }
        _uiState.update { it.copy(savedSounds = it.savedSounds + result, mixSelection = emptyList()) }
        playSaved(result)
    }

    // --- Trim / cut ---

    fun previewTrim(sound: SavedSound, startSeconds: Float, endSeconds: Float) {
        try {
            repository.play(repository.previewTrim(sound, startSeconds, endSeconds))
        } catch (e: Exception) {
            _messages.tryEmit("Couldn't preview that trim — the file may be missing.")
        }
    }

    fun saveTrim(sound: SavedSound, startSeconds: Float, endSeconds: Float, name: String) {
        val trimmed = try {
            repository.trim(sound, startSeconds, endSeconds, name.ifBlank { "${sound.name} (trimmed)" })
        } catch (e: Exception) {
            _messages.tryEmit("Couldn't trim that sound — the file may be missing.")
            return
        }
        _uiState.update { it.copy(savedSounds = it.savedSounds + trimmed) }
    }

    private fun checkpointForUndo() {
        if (!awaitingFreshSnapshot) return
        previousParams = _uiState.value.currentParams
        awaitingFreshSnapshot = false
        _uiState.update { it.copy(canUndo = true) }
    }

    private fun renderAndPlay(params: SfxParams) {
        _uiState.update { it.copy(isGenerating = true, currentParams = params) }
        renderJob?.cancel()
        renderJob = viewModelScope.launch {
            val samples = withContext(Dispatchers.Default) { repository.render(params) }
            _uiState.update { it.copy(currentSamples = samples, isGenerating = false) }
            repository.play(samples)
            awaitingFreshSnapshot = true
            previewProgressJob?.cancel()
            previewProgressJob = trackProgress(
                durationSeconds = samples.size / SoundRepository.SAMPLE_RATE.toFloat(),
                onTick = { p -> _uiState.update { it.copy(previewProgress = p) } },
                onFinished = { _uiState.update { it.copy(previewProgress = 0f) } }
            )
        }
    }

    /** Simulates playback progress from elapsed time against a known
     *  duration — simpler and good enough for a visual cue than polling the
     *  underlying AudioTrack/MediaPlayer for an actual position. */
    private fun trackProgress(durationSeconds: Float, onTick: (Float) -> Unit, onFinished: () -> Unit): Job =
        viewModelScope.launch {
            if (durationSeconds <= 0f) {
                onFinished()
                return@launch
            }
            val stepMs = 50L
            var elapsed = 0f
            onTick(0f)
            while (elapsed < durationSeconds) {
                delay(stepMs)
                elapsed += stepMs / 1000f
                onTick((elapsed / durationSeconds).coerceIn(0f, 1f))
            }
            onFinished()
        }

    override fun onCleared() {
        repository.stop()
        recorder.release()
        super.onCleared()
    }
}
