package com.soundfxmaker.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.soundfxmaker.app.audio.SfxAudioRecorder
import com.soundfxmaker.app.core.SfxCategory
import com.soundfxmaker.app.core.SfxParams
import com.soundfxmaker.app.data.SavedSound
import com.soundfxmaker.app.data.SfxPresetGenerator
import com.soundfxmaker.app.data.SoundRepository
import com.soundfxmaker.app.data.SoundSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class SoundFxViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = SoundRepository(application)
    private val recorder = SfxAudioRecorder(SoundRepository.SAMPLE_RATE)

    private val _uiState = MutableStateFlow(SoundFxUiState())
    val uiState: StateFlow<SoundFxUiState> = _uiState

    // Slider drags call updateParams() many times a second. The slider
    // position / displayed values need to track every tick instantly, but
    // actually re-rendering + replaying audio on every tick is expensive and
    // sounds like a stutter storm — so that part is routed through this flow
    // and debounced instead of running inline in updateParams().
    private val pendingRender = MutableSharedFlow<SfxParams>(extraBufferCapacity = 1, onBufferOverflow = BufferOverflow.DROP_OLDEST)

    private var previewProgressJob: Job? = null
    private var savedProgressJob: Job? = null

    init {
        _uiState.update { it.copy(savedSounds = repository.loadLibrary()) }
        renderAndPlay(_uiState.value.currentParams)

        viewModelScope.launch {
            pendingRender.debounce(120L).collectLatest { params -> renderAndPlay(params) }
        }
    }

    fun selectCategory(category: SfxCategory) {
        _uiState.update { it.copy(selectedCategory = category) }
        generate(category)
    }

    fun generate(category: SfxCategory = _uiState.value.selectedCategory) {
        renderAndPlay(SfxPresetGenerator.generate(category))
    }

    fun mutateCurrent() {
        renderAndPlay(SfxPresetGenerator.mutate(_uiState.value.currentParams))
    }

    /** Called on every slider tick: updates what's displayed immediately,
     *  but the actual render + playback is debounced via [pendingRender]. */
    fun updateParams(params: SfxParams) {
        _uiState.update { it.copy(currentParams = params) }
        pendingRender.tryEmit(params)
    }

    /** Loads a previously-saved generated sound back into Custom mode for
     *  further tweaking. Only valid for sounds that have synthesis params. */
    fun loadForEditing(sound: SavedSound) {
        val params = sound.params ?: return
        _uiState.update { it.copy(selectedCategory = SfxCategory.CUSTOM) }
        renderAndPlay(params)
    }

    fun play() {
        val samples = _uiState.value.currentSamples.toShortArray()
        repository.play(samples)
        previewProgressJob?.cancel()
        previewProgressJob = trackProgress(
            durationSeconds = samples.size / SoundRepository.SAMPLE_RATE.toFloat(),
            onTick = { p -> _uiState.update { it.copy(previewProgress = p) } },
            onFinished = { _uiState.update { it.copy(previewProgress = 0f) } }
        )
    }

    fun saveCurrent(name: String) {
        val state = _uiState.value
        val trimmed = name.ifBlank { state.selectedCategory.displayName }
        val saved = repository.save(
            category = state.selectedCategory,
            source = SoundSource.GENERATED,
            params = state.currentParams,
            samples = state.currentSamples.toShortArray(),
            name = trimmed
        )
        _uiState.update { it.copy(savedSounds = it.savedSounds + saved) }
    }

    fun playSaved(sound: SavedSound) {
        repository.playFile(sound.filePath)
        savedProgressJob?.cancel()
        _uiState.update { it.copy(playingSavedSoundId = sound.id, savedPlaybackProgress = 0f) }
        savedProgressJob = trackProgress(
            durationSeconds = sound.durationSeconds,
            onTick = { p -> _uiState.update { it.copy(savedPlaybackProgress = p) } },
            onFinished = { _uiState.update { it.copy(playingSavedSoundId = null, savedPlaybackProgress = 0f) } }
        )
    }

    fun deleteSaved(sound: SavedSound) {
        repository.delete(sound)
        _uiState.update { it.copy(savedSounds = it.savedSounds.filterNot { s -> s.id == sound.id }) }
    }

    // --- Recording ---

    fun startRecording() {
        if (recorder.isRecording) return
        recorder.start(viewModelScope)
        _uiState.update { it.copy(isRecording = true) }
    }

    fun stopRecording() {
        viewModelScope.launch {
            val samples = recorder.stop()
            _uiState.update { it.copy(isRecording = false, pendingRecordingSamples = samples.toList()) }
            if (samples.isNotEmpty()) repository.play(samples)
        }
    }

    fun saveRecording(name: String) {
        val samples = _uiState.value.pendingRecordingSamples.toShortArray()
        if (samples.isEmpty()) return
        val saved = repository.saveRecording(samples, name.ifBlank { "Recording" })
        _uiState.update { it.copy(savedSounds = it.savedSounds + saved, pendingRecordingSamples = emptyList()) }
    }

    fun discardRecording() {
        _uiState.update { it.copy(pendingRecordingSamples = emptyList()) }
    }

    // --- Combine / continue (mixing two saved sounds) ---

    fun toggleMixSelection(sound: SavedSound) {
        _uiState.update { state ->
            val current = state.mixSelection
            val updated = when {
                sound.id in current -> current - sound.id
                current.size >= 2 -> current.drop(1) + sound.id // drop oldest, keep at most 2
                else -> current + sound.id
            }
            state.copy(mixSelection = updated)
        }
    }

    fun combineSelected(name: String) = withMixSelection { a, b ->
        repository.combine(a, b, name.ifBlank { "${a.name} + ${b.name}" })
    }

    fun continueSelected(name: String) = withMixSelection { a, b ->
        repository.continueWith(a, b, name.ifBlank { "${a.name} then ${b.name}" })
    }

    private inline fun withMixSelection(action: (SavedSound, SavedSound) -> SavedSound) {
        val ids = _uiState.value.mixSelection
        if (ids.size != 2) return
        val sounds = _uiState.value.savedSounds
        val a = sounds.firstOrNull { it.id == ids[0] } ?: return
        val b = sounds.firstOrNull { it.id == ids[1] } ?: return
        val result = action(a, b)
        _uiState.update { it.copy(savedSounds = it.savedSounds + result, mixSelection = emptyList()) }
        repository.playFile(result.filePath)
    }

    // --- Trim / cut ---

    fun previewTrim(sound: SavedSound, startSeconds: Float, endSeconds: Float) {
        repository.play(repository.previewTrim(sound, startSeconds, endSeconds))
    }

    fun saveTrim(sound: SavedSound, startSeconds: Float, endSeconds: Float, name: String) {
        val trimmed = repository.trim(sound, startSeconds, endSeconds, name.ifBlank { "${sound.name} (trimmed)" })
        _uiState.update { it.copy(savedSounds = it.savedSounds + trimmed) }
    }

    private fun renderAndPlay(params: SfxParams) {
        _uiState.update { it.copy(isGenerating = true, currentParams = params) }
        viewModelScope.launch {
            val samples = withContext(Dispatchers.Default) { repository.render(params) }
            _uiState.update { it.copy(currentSamples = samples.toList(), isGenerating = false) }
            repository.play(samples)
            previewProgressJob?.cancel()
            previewProgressJob = trackProgress(
                durationSeconds = samples.size / SoundRepository.SAMPLE_RATE.toFloat(),
                onTick = { p -> _uiState.update { it.copy(previewProgress = p) } },
                onFinished = { _uiState.update { it.copy(previewProgress = 0f) } }
            )
        }
    }

    /** Simulates playback progress from elapsed time against a known
     *  duration — simpler and good enough for a visual cue than polling the
     *  underlying AudioTrack/MediaPlayer for an actual position. */
    private fun trackProgress(durationSeconds: Float, onTick: (Float) -> Unit, onFinished: () -> Unit): Job =
        viewModelScope.launch {
            if (durationSeconds <= 0f) {
                onFinished()
                return@launch
            }
            val stepMs = 50L
            var elapsed = 0f
            onTick(0f)
            while (elapsed < durationSeconds) {
                delay(stepMs)
                elapsed += stepMs / 1000f
                onTick((elapsed / durationSeconds).coerceIn(0f, 1f))
            }
            onFinished()
        }

    override fun onCleared() {
        repository.stop()
        recorder.release()
        super.onCleared()
    }
}
