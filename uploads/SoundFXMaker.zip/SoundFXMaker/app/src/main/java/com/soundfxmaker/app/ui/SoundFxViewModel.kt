package com.soundfxmaker.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.soundfxmaker.app.core.SfxCategory
import com.soundfxmaker.app.core.SfxParams
import com.soundfxmaker.app.data.SfxPresetGenerator
import com.soundfxmaker.app.data.SoundRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class SoundFxViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = SoundRepository(application)

    private val _uiState = MutableStateFlow(SoundFxUiState())
    val uiState: StateFlow<SoundFxUiState> = _uiState

    init {
        _uiState.update { it.copy(savedSounds = repository.loadLibrary()) }
        generate(_uiState.value.selectedCategory)
    }

    fun selectCategory(category: SfxCategory) {
        _uiState.update {
            it.copy(selectedCategory = category, showAdvanced = it.showAdvanced || category == SfxCategory.CUSTOM)
        }
        generate(category)
    }

    fun generate(category: SfxCategory = _uiState.value.selectedCategory) {
        renderAndStore(SfxPresetGenerator.generate(category))
    }

    fun mutateCurrent() {
        renderAndStore(SfxPresetGenerator.mutate(_uiState.value.currentParams))
    }

    fun updateParams(params: SfxParams) {
        renderAndStore(params)
    }

    fun play() {
        repository.play(_uiState.value.currentSamples.toShortArray())
    }

    fun saveCurrent(name: String) {
        val state = _uiState.value
        val trimmed = name.ifBlank { state.selectedCategory.displayName }
        val saved = repository.save(state.selectedCategory, state.currentParams, state.currentSamples.toShortArray(), trimmed)
        _uiState.update { it.copy(savedSounds = it.savedSounds + saved) }
    }

    fun playSaved(filePath: String) {
        repository.playFile(filePath)
    }

    fun deleteSaved(id: String) {
        val sound = _uiState.value.savedSounds.firstOrNull { it.id == id } ?: return
        repository.delete(sound)
        _uiState.update { it.copy(savedSounds = it.savedSounds.filterNot { s -> s.id == id }) }
    }

    fun toggleAdvanced() {
        _uiState.update { it.copy(showAdvanced = !it.showAdvanced) }
    }

    private fun renderAndStore(params: SfxParams) {
        _uiState.update { it.copy(isGenerating = true, currentParams = params) }
        viewModelScope.launch {
            val samples = withContext(Dispatchers.Default) { repository.render(params) }
            _uiState.update { it.copy(currentSamples = samples.toList(), isGenerating = false) }
            repository.play(samples)
        }
    }

    override fun onCleared() {
        repository.stop()
        super.onCleared()
    }
}
