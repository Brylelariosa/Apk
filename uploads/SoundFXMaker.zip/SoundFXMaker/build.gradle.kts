// Top-level build file. Individual module configuration lives in app/build.gradle.kts.
plugins {
    id("com.android.application") version "8.4.0" apply false
    id("org.jetbrains.kotlin.android") version "1.9.23" apply false
}
