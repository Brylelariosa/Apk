package com.mangareader.manager

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import androidx.documentfile.provider.DocumentFile
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.mangareader.data.Chapter
import com.mangareader.data.Series
import com.mangareader.parser.ChapterParser
import com.mangareader.parser.MhtmlParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID
import java.util.zip.ZipInputStream

class LibraryManager(private val context: Context) {

    private val prefs       = context.getSharedPreferences("manga_library", Context.MODE_PRIVATE)
    private val gson        = Gson()
    private val mhtmlParser = MhtmlParser(context)

    /**
     * In-memory series list. Avoids Gson deserialisation on every [getAllSeries]
     * call — which happened once per card during library composition.
     * Invalidated (set to null) whenever the list changes.
     */
    @Volatile private var seriesCache: List<Series>? = null

    // ── Read / Write ──────────────────────────────────────────────────────────

    fun getAllSeries(): List<Series> {
        seriesCache?.let { return it }
        val json = prefs.getString("series_list", "[]") ?: "[]"
        val type = object : TypeToken<List<Series>>() {}.type
        val loaded = runCatching {
            gson.fromJson<List<Series>>(json, type) ?: emptyList()
        }.getOrDefault(emptyList())
        seriesCache = loaded
        return loaded
    }

    fun saveSeries(series: Series) {
        seriesCache = null                      // invalidate before write
        val list = getAllSeries().toMutableList()
        val idx  = list.indexOfFirst { it.id == series.id }
        if (idx >= 0) list[idx] = series else list.add(series)
        prefs.edit().putString("series_list", gson.toJson(list)).apply()
        seriesCache = null                      // invalidate after write too
    }

    fun deleteSeries(seriesId: String) {
        seriesCache = null
        val list = getAllSeries().filter { it.id != seriesId }
        prefs.edit().putString("series_list", gson.toJson(list)).apply()
        seriesCache = null

        // Wipe extracted/cached images
        File(context.cacheDir, "manga/$seriesId").deleteRecursively()
        File(context.filesDir, "zips/$seriesId").deleteRecursively()
        thumbnailFile(seriesId).delete()

        // Release the persistable URI permission for folder-based series so
        // the OS can clean up after us (best-effort; may already be gone).
        getAllSeries()   // re-read so we don't try releasing permissions we never had
    }

    // ── Library cover thumbnails ──────────────────────────────────────────────

    fun thumbnailFile(seriesId: String): File = File(context.cacheDir, "thumbs/$seriesId.jpg")

    /**
     * Returns a cover thumbnail for [series], generating it the first time.
     * Generation decodes only the first usable page of the first chapter at a
     * small downsampled size, so it's cheap even for large libraries.
     */
    suspend fun ensureThumbnail(series: Series): File? = withContext(Dispatchers.IO) {
        val file = thumbnailFile(series.id)
        if (file.exists() && file.length() > 0) return@withContext file

        val firstChapter = series.chapters.firstOrNull() ?: return@withContext null
        val ok = runCatching {
            mhtmlParser.extractFirstPageThumbnail(firstChapter.mhtmlPath, file)
        }.getOrDefault(false)

        if (ok) file else null
    }

    // ── Add from SAF folder ───────────────────────────────────────────────────

    /**
     * Imports one or more series from a folder tree.
     *
     * If the selected folder has sub-folders that each contain .mhtml/.mht
     * files, each sub-folder becomes its own Series (multi-series mode).
     * Otherwise the selected folder itself is treated as a single Series.
     *
     * Re-picking a folder that's already the source of an existing Series
     * (a common way to manually check for new chapters) merges into that
     * Series instead of creating a duplicate — see [addOrRefreshFromDocFile].
     */
    suspend fun addFolder(treeUri: Uri): List<Series> = withContext(Dispatchers.IO) {
        context.contentResolver.takePersistableUriPermission(
            treeUri, Intent.FLAG_GRANT_READ_URI_PERMISSION
        )

        val docFile = DocumentFile.fromTreeUri(context, treeUri)
            ?: error("Cannot open folder: $treeUri")

        val seriesDirs = docFile.listFiles()
            .filter { f ->
                f.isDirectory && f.listFiles().any { sf ->
                    val n = sf.name?.lowercase() ?: ""
                    sf.isFile && (n.endsWith(".mhtml") || n.endsWith(".mht"))
                }
            }
            .sortedBy { it.name }

        if (seriesDirs.isNotEmpty()) {
            seriesDirs.map { dir -> addOrRefreshFromDocFile(dir) }
        } else {
            listOf(addOrRefreshFromDocFile(docFile, sourceFolderUri = treeUri.toString()))
        }
    }

    /**
     * Imports [docFile] as a new Series — unless a Series already has this
     * exact folder as its [Series.sourceFolderUri], in which case the
     * existing Series is updated in place instead: files already known keep
     * their original [Chapter.id] (so reading progress stays valid), and
     * only genuinely new files become new chapters. Nothing is ever
     * re-added or duplicated, no matter how many times the same folder is
     * picked.
     */
    private fun addOrRefreshFromDocFile(
        docFile: DocumentFile,
        sourceFolderUri: String? = null
    ): Series {
        val folderUri = sourceFolderUri ?: docFile.uri.toString()
        val existing   = getAllSeries().find { it.sourceFolderUri == folderUri }
        val seriesId   = existing?.id ?: UUID.randomUUID().toString()

        val mhtmlFiles = docFile.listFiles()
            .filter { f ->
                val name = f.name?.lowercase() ?: ""
                f.isFile && (name.endsWith(".mhtml") || name.endsWith(".mht"))
            }
            .sortedWith(Comparator { a, b ->
                ChapterParser.byNumber.compare(a.name ?: "", b.name ?: "")
            })

        val chapters = mergeChapters(mhtmlFiles, existing?.chapters.orEmpty(), seriesId)

        val series = existing?.copy(chapters = chapters) ?: Series(
            id              = seriesId,
            title           = ChapterParser.extractSeriesName(docFile.name ?: "Manga"),
            sourceFolderUri = folderUri,
            chapters        = chapters
        )
        saveSeries(series)
        return series
    }

    /**
     * Builds a chapter list from [mhtmlFiles]: files whose content URI
     * already appears in [existingChapters] keep that chapter's id (title
     * and number are recomputed in case the filename changed), and any file
     * not already present becomes a brand-new [Chapter]. Files that were
     * previously imported but are no longer present on disk are dropped.
     *
     * Shared by [addOrRefreshFromDocFile] and [refreshSeries] so the two
     * import paths can't drift apart.
     */
    private fun mergeChapters(
        mhtmlFiles: List<DocumentFile>,
        existingChapters: List<Chapter>,
        seriesId: String
    ): List<Chapter> {
        val existingByPath = existingChapters.associateBy { it.mhtmlPath }
        return mhtmlFiles.mapIndexed { i, file ->
            val uriStr = file.uri.toString()
            existingByPath[uriStr]?.copy(
                title  = ChapterParser.formatTitle(file.name ?: "Chapter ${i + 1}"),
                number = ChapterParser.extractNumber(file.name ?: "${i + 1}")
            ) ?: Chapter(
                title     = ChapterParser.formatTitle(file.name ?: "Chapter ${i + 1}"),
                number    = ChapterParser.extractNumber(file.name ?: "${i + 1}"),
                mhtmlPath = uriStr,
                seriesId  = seriesId
            )
        }
    }

    // ── Add from ZIP ──────────────────────────────────────────────────────────

    suspend fun addZip(zipUri: Uri): Series = withContext(Dispatchers.IO) {
        // Persist read access so a later refresh (see refreshFromZip) can
        // still open this exact zip after the app process restarts —
        // without this, access can be revoked once the picker's own
        // transient grant ends.
        runCatching {
            context.contentResolver.takePersistableUriPermission(
                zipUri, Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        }

        // Re-picking a zip already in the library (e.g. after editing it to
        // add or remove chapters) merges into that Series instead of
        // creating a duplicate — force a full scan regardless of the
        // lastModified/size fast path, since the user explicitly asked to
        // (re-)add this exact file right now.
        val zipUriStr = zipUri.toString()
        val existing  = getAllSeries().find { it.sourceZipUri == zipUriStr }
        if (existing != null) {
            return@withContext refreshFromZip(existing, forceFullScan = true)
        }

        val seriesId   = UUID.randomUUID().toString()
        val extractDir = File(context.filesDir, "zips/$seriesId").also { it.mkdirs() }

        val displayName = context.contentResolver.query(
            zipUri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null
        )?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        } ?: "Manga"

        val seriesTitle = ChapterParser.extractSeriesName(displayName)

        // Extract MHTML files; clean up the whole dir if anything goes wrong
        // so we never leave a half-written series on disk.
        val extracted = mutableListOf<File>()
        runCatching {
            context.contentResolver.openInputStream(zipUri)?.use { raw ->
                ZipInputStream(raw).use { zip ->
                    var entry = zip.nextEntry
                    while (entry != null) {
                        val name = entry.name.substringAfterLast("/")
                        if (!entry.isDirectory &&
                            (name.lowercase().endsWith(".mhtml") || name.lowercase().endsWith(".mht"))
                        ) {
                            val out = File(extractDir, name)
                            out.outputStream().use { o -> zip.copyTo(o) }
                            extracted.add(out)
                        }
                        zip.closeEntry()
                        entry = zip.nextEntry
                    }
                }
            }
        }.onFailure { e ->
            extractDir.deleteRecursively()   // clean up partial extraction
            throw e
        }

        if (extracted.isEmpty()) {
            extractDir.deleteRecursively()
            error("No .mhtml or .mht files found in the ZIP")
        }

        val sorted = extracted.sortedWith(Comparator { a, b ->
            ChapterParser.byNumber.compare(a.name, b.name)
        })

        val chapters = sorted.mapIndexed { i, file ->
            Chapter(
                title     = ChapterParser.formatTitle(file.name),
                number    = ChapterParser.extractNumber(file.name),
                mhtmlPath = file.absolutePath,
                seriesId  = seriesId
            )
        }

        val (lastModified, size) = zipMeta(zipUri)
        val series = Series(
            id                    = seriesId,
            title                 = seriesTitle,
            sourceZipUri          = zipUriStr,
            sourceZipLastModified = lastModified,
            sourceZipSize         = size,
            chapters              = chapters
        )
        saveSeries(series)
        series
    }

    /** (lastModified, length) for [zipUri] via a plain metadata read — no stream opened. */
    private fun zipMeta(zipUri: Uri): Pair<Long?, Long?> = runCatching {
        val doc = DocumentFile.fromSingleUri(context, zipUri)
        (doc?.lastModified()?.takeIf { it > 0 }) to (doc?.length()?.takeIf { it >= 0 })
    }.getOrDefault(null to null)

    // ── Refresh (pick up new chapters without re-adding everything) ────────────

    /**
     * Re-scans [series]'s source — folder or ZIP, whichever it has — and
     * merges in any new chapters, preserving existing chapter ids so
     * reading progress stays valid. A no-op for a series with neither.
     * Safe to call on every chapter-list open, not just an explicit manual
     * refresh; see [refreshFromFolder] and [refreshFromZip] for what each
     * actually costs when nothing has changed.
     *
     * [forceFullScan] only affects ZIP-backed series: it skips the
     * lastModified/size fast path in [refreshFromZip] and does a real scan
     * unconditionally. Pass true for anything the user explicitly triggered
     * (a manual "Refresh chapters" tap) — some file managers rewrite a zip
     * in place without updating its reported metadata at all, which would
     * otherwise make even a deliberate refresh look like a no-op. Folder
     * refreshes are always a real listFiles() call regardless, since that
     * has no comparable staleness risk.
     */
    suspend fun refreshSeries(series: Series, forceFullScan: Boolean = false): Series = when {
        series.sourceFolderUri != null -> refreshFromFolder(series)
        series.sourceZipUri    != null -> refreshFromZip(series, forceFullScan)
        else -> series
    }

    /**
     * Re-scans [series]'s source folder via a single SAF listFiles() call
     * and merges in any new chapters via [mergeChapters] — cheap even when
     * nothing changed, since listing a folder's contents never touches the
     * files themselves.
     */
    private suspend fun refreshFromFolder(series: Series): Series = withContext(Dispatchers.IO) {
        val uriStr  = series.sourceFolderUri ?: return@withContext series
        val treeUri = Uri.parse(uriStr)
        val docFile = DocumentFile.fromTreeUri(context, treeUri) ?: return@withContext series

        val mhtmlFiles = docFile.listFiles()
            .filter { f ->
                val name = f.name?.lowercase() ?: ""
                f.isFile && (name.endsWith(".mhtml") || name.endsWith(".mht"))
            }
            .sortedWith(Comparator { a, b ->
                ChapterParser.byNumber.compare(a.name ?: "", b.name ?: "")
            })

        val updated = series.copy(chapters = mergeChapters(mhtmlFiles, series.chapters, series.id))
        saveSeries(updated)
        updated
    }

    /**
     * Re-scans [series]'s source ZIP and merges in any new chapters.
     *
     * Unlike a SAF folder, a ZIP can't be listed without opening it, so as a
     * fast path this first compares the ZIP's own lastModified() AND
     * length() — both plain metadata reads, no stream opened — against what
     * was recorded on the last scan, and skips the scan entirely when
     * neither changed. Checking both, not just lastModified, matters: some
     * file managers rewrite a zip in place without updating its reported
     * modified time, and a changed byte count (e.g. a removed chapter) is
     * on its own a reliable signal that something changed. Pass
     * [forceFullScan] to skip this fast path outright — used when the user
     * explicitly re-adds this exact zip via "Add ZIP".
     *
     * When a scan does run, entries whose filename already matches an
     * existing chapter are skipped via closeEntry() without decompressing
     * or writing anything — only genuinely new .mhtml/.mht entries get
     * extracted. Chapters whose file is no longer present in the zip are
     * dropped from the result, same as a folder-backed series drops
     * chapters that were deleted from disk.
     */
    private suspend fun refreshFromZip(
        series: Series,
        forceFullScan: Boolean = false
    ): Series = withContext(Dispatchers.IO) {
        val uriStr = series.sourceZipUri ?: return@withContext series
        val zipUri = Uri.parse(uriStr)

        val (lastModified, size) = zipMeta(zipUri)

        val unchanged = !forceFullScan &&
            lastModified != null && lastModified == series.sourceZipLastModified &&
            size != null && size == series.sourceZipSize
        if (unchanged) return@withContext series

        val extractDir     = File(context.filesDir, "zips/${series.id}").also { it.mkdirs() }
        val existingByName = series.chapters.associateBy { File(it.mhtmlPath).name }
        val files           = mutableListOf<File>()

        val opened = runCatching {
            context.contentResolver.openInputStream(zipUri)?.use { raw ->
                ZipInputStream(raw).use { zip ->
                    var entry = zip.nextEntry
                    while (entry != null) {
                        val name = entry.name.substringAfterLast("/")
                        if (!entry.isDirectory &&
                            (name.lowercase().endsWith(".mhtml") || name.lowercase().endsWith(".mht"))
                        ) {
                            val already = existingByName[name]
                            if (already != null) {
                                files.add(File(already.mhtmlPath))
                            } else {
                                val out = File(extractDir, name)
                                out.outputStream().use { o -> zip.copyTo(o) }
                                files.add(out)
                            }
                        }
                        zip.closeEntry()
                        entry = zip.nextEntry
                    }
                }
                true
            } ?: false
        }.getOrDefault(false)

        if (!opened || files.isEmpty()) return@withContext series

        val sorted = files.sortedWith(Comparator { a, b ->
            ChapterParser.byNumber.compare(a.name, b.name)
        })

        val chapters = sorted.map { file ->
            existingByName[file.name]?.copy(
                title  = ChapterParser.formatTitle(file.name),
                number = ChapterParser.extractNumber(file.name)
            ) ?: Chapter(
                title     = ChapterParser.formatTitle(file.name),
                number    = ChapterParser.extractNumber(file.name),
                mhtmlPath = file.absolutePath,
                seriesId  = series.id
            )
        }

        val updated = series.copy(
            chapters              = chapters,
            sourceZipLastModified = lastModified ?: series.sourceZipLastModified,
            sourceZipSize         = size ?: series.sourceZipSize
        )
        saveSeries(updated)
        updated
    }
}
