# Volume Tile

A Quick Settings tile that opens a small volume-control panel — built as a
workaround for a broken physical volume button.

## What it does

- Adds a **Volume** tile to the Quick Settings shade (pull down notifications,
  tap edit/pencil icon, drag the tile in).
- Tapping the tile opens a floating panel with sliders for **Media, Ring,
  Notification, and Alarm** volume — no physical buttons needed.
- The app icon on your home screen opens the same panel full-screen, so it
  also works as a standalone volume app.
- The tile subtitle shows the current media volume as a percentage.

## Ring volume note

Android requires "Do Not Disturb access" before an app can move Ring volume
to/through silent. If you drag the Ring slider to 0 and it's blocked, a
**Grant Do Not Disturb access** button appears — tap it once, allow access in
Settings, and it won't ask again.

## Building

Your build log shows this is actually built through your existing
zip-upload pipeline (the `Apk` repo / ZipApkBuilder), not the
`.github/workflows/build.yml` included here — that workflow is just a
ready-to-go alternative if you ever push this as its own standalone repo.

The zip-upload pipeline unzips whatever you upload, finds the project
root, and runs `chmod +x gradlew` unconditionally — so the project now
includes the standard Gradle wrapper (`gradlew`, `gradlew.bat`,
`gradle/wrapper/gradle-wrapper.properties`, pinned to Gradle 8.9) that
was missing before. Just upload this zip the same way you always do.

## Project layout

```
app/src/main/java/com/volumetile/app/
  VolumeTileService.kt      — the Quick Settings tile itself
  VolumeControlActivity.kt  — the slider panel (used both full-screen and as
                               the tile's floating dialog)
app/src/main/res/           — layout, strings, icons
gradlew, gradlew.bat,
gradle/wrapper/              — standard Gradle wrapper, pinned to Gradle 8.9
.github/workflows/build.yml — alternate CI build, only used if pushed as its
                               own repo with Actions enabled
```

## Size optimizations

The release build (what CI produces) is shrunk without dropping any
functionality:

- R8 minification + resource shrinking enabled (was off)
- Removed two dependencies that were pulled in but never actually used
  in the code (Material Components, core-ktx)
- Bundled resources restricted to English, dropping ~70 unused translated
  string sets that AppCompat/CardView ship internally
- Signed with the auto-generated debug key so it stays a one-tap install
  with no keystore to manage

Stack traces from a release-build crash still show real file/line info
(kept explicitly in `proguard-rules.pro`) despite the obfuscation.

If you ever want an unoptimized, fully-debuggable build instead, trigger
`gradle assembleDebug` — the debug build type is unaffected by any of this.

