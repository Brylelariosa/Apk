# Volume Tile

A Quick Settings tile that opens a small volume-control panel — built as a
workaround for a broken physical volume button.

## What it does

- Adds a **Volume** tile to the Quick Settings shade (pull down notifications,
  tap edit/pencil icon, drag the tile in).
- Tapping the tile opens a floating panel with sliders for **Media, Ring,
  Notification, and Alarm** volume — no physical buttons needed.
- The app icon on your home screen opens the same panel full-screen, so it
  also works as a standalone volume app.
- The tile subtitle shows the current media volume as a percentage.

## Ring volume note

Android requires "Do Not Disturb access" before an app can move Ring volume
to/through silent. If you drag the Ring slider to 0 and it's blocked, a
**Grant Do Not Disturb access** button appears — tap it once, allow access in
Settings, and it won't ask again.

## Building via GitHub Actions

1. Push this project to a new GitHub repo (root of the repo = this folder).
2. The included workflow (`.github/workflows/build.yml`) runs automatically
   on push to `main`, or trigger it manually from the **Actions** tab
   ("Run workflow").
3. Once it finishes, open the workflow run → **Artifacts** → download
   `volume-tile-release-apk`.
4. Unzip and install `app-release.apk` on your phone (you'll need "install
   unknown apps" allowed for whichever app you use to open it).

## Project layout

```
app/src/main/java/com/volumetile/app/
  VolumeTileService.kt      — the Quick Settings tile itself
  VolumeControlActivity.kt  — the slider panel (used both full-screen and as
                               the tile's floating dialog)
app/src/main/res/           — layout, strings, icons
.github/workflows/build.yml — CI build
```

## Size optimizations

The release build (what CI produces) is shrunk without dropping any
functionality:

- R8 minification + resource shrinking enabled (was off)
- Removed two dependencies that were pulled in but never actually used
  in the code (Material Components, core-ktx)
- Bundled resources restricted to English, dropping ~70 unused translated
  string sets that AppCompat/CardView ship internally
- Signed with the auto-generated debug key so it stays a one-tap install
  with no keystore to manage

Stack traces from a release-build crash still show real file/line info
(kept explicitly in `proguard-rules.pro`) despite the obfuscation.

If you ever want an unoptimized, fully-debuggable build instead, trigger
`gradle assembleDebug` — the debug build type is unaffected by any of this.

