# Volume Tile

A Quick Settings tile that opens a small volume-control panel — built as a
workaround for a broken physical volume button.

## What it does

- Adds a **Volume** tile to the Quick Settings shade (pull down notifications,
  tap edit/pencil icon, drag the tile in).
- Tapping the tile opens a floating panel with sliders for **Media, Ring,
  Notification, and Alarm** volume — no physical buttons needed.
- The app icon on your home screen opens the same panel full-screen, so it
  also works as a standalone volume app.
- The tile subtitle shows the current media volume as a percentage.

## Extra tiles: Screenshot, Shade shot, Power menu

Built for the same reason as the Volume tile: no working hardware buttons
needed.

| Tile | What it does |
|------|--------------|
| **Screenshot** | Collapses the shade, then takes a normal screenshot of whatever is underneath. Nothing is launched, so a game in the foreground keeps running. |
| **Shade shot** | Takes the screenshot with the notification shade left open, so the notification area is what gets captured. Single frame only, it never scrolls. |
| **Power menu** | Opens the system power menu (Power off / Restart), same as holding the power button. |

Android only lets an app do this through an accessibility service, so there is
a one-time setup:

1. Add the tiles: pull down the shade, tap the edit/pencil icon, drag them in.
2. Tap any of them (or the **Enable accessibility** button in the app). It
   opens Settings > Accessibility; turn on **Volume Tile**.
3. On Android 13+, a sideloaded APK may have that toggle greyed out. Fix: App
   info > ⋮ > **Allow restricted settings**, then try again.

The service subscribes to no events and cannot read window content; it only
performs the action behind the tile you tapped. Screenshot and Shade shot need
Android 9+. Power menu works on every supported version. Until the service is
on, these tiles show greyed out with a "Tap to enable" hint.

## Accessibility button menu (navigation bar)

The person-icon button in the navigation bar opens a small menu of everything this
app can do: **Volume, Screenshot, Shade shot, Power menu**. Tap an entry to run it;
tap outside the card (or **Cancel**) to close it. Tapping the floating bubble (next
section) opens the same menu.

- The menu is kept compact: a narrow card with one slim row per action, so it covers
  as little of the app underneath as possible. Screen readers still announce each
  action's one-line description even though it isn't drawn.
- The menu is an overlay window, not an activity, so a game in the foreground keeps
  running underneath it. It needs no extra permission.
- It rides on the same accessibility service as the Screenshot / Power menu tiles, so
  the one-time setup is the same: turn on **Volume Tile** in Settings > Accessibility.
  After installing an update, check the toggle is still on - some phones switch
  accessibility services off when their app is replaced.
- If another accessibility feature is also assigned to the button, Android shows its own
  list first: pick **Volume Tile**. To change what the button does, open Settings >
  Accessibility > Volume Tile and look for its shortcut setting (wording varies by phone).
- Games that hide the navigation bar hide the button too: swipe to bring the bar back,
  then tap the button.
- From the menu, **Shade shot** pulls the notification shade down by itself and then
  captures it (the tile version expects the shade to be open already - the tile lives in it).
- Volume uses the system volume panel, the same as the Volume tile, so the sliders in the
  app itself are not needed for this.

## Floating bubble (hold and swipe)

A small bubble that floats on top of every app. Switch it on with **Floating bubble** in
the app. It is shown on the right-hand edge at first.

| Gesture | What it does |
|---------|--------------|
| **Hold and swipe** up / down / left / right | Runs the action set for that direction. While the finger is down a small card lists the four directions and highlights the one that will run, and the bubble shows that action's icon. Lift the finger to run it; lift it before the highlight appears (or swipe back) to call it off. |
| **Tap** | Opens the action menu (the same one as the nav-bar button). |
| **Hold still, then drag** | Moves the bubble. Hold until it grows (and buzzes); it then follows the finger, settles against the nearest side of the screen and remembers where you left it. |

Default swipes (change any of them under the switch, or set one to **Nothing**):

| Swipe | Default action |
|-------|----------------|
| ↑ up | Volume (the system volume panel) |
| ↓ down | Shade shot |
| ← left | Screenshot |
| → right | Power menu |

- It is another window of the same accessibility service, so there is nothing extra to
  allow: if the Screenshot / Power tiles work, the bubble works. Turn the switch on first
  and the bubble appears as soon as **Volume Tile** is switched on in Accessibility.
- It hides itself for about a second around a screenshot, so it is not in the picture.
- A swipe needs a little room: normally about 36 dp of finger travel, less when the bubble
  sits against the screen edge and has no room to pull outwards (never under 20 dp, so a tap
  with a wobble can't run anything).
- On phones with gesture navigation the bubble stays clear of the edge-swipe "back" zone
  (and asks the system to leave touches on it alone).
- Like the nav-bar button it lives and dies with the service, so the **Keep the service
  running** checkbox and the battery exemption (next section) keep the bubble alive too.

## If the nav-bar button stops working after a few hours

Symptom: the button (and the Screenshot / Power tiles) work, then hours later do nothing
until **Settings > Accessibility > Volume Tile** is switched off and on again.

Cause: the phone's memory killer, or the maker's battery / memory cleaner (Infinix XOS is
aggressive), cleaned up the idle app process and left the service switched on in Settings but
no longer running. An app can't restart its own accessibility service; only Settings can.

What the app does about it, with no cost while idle (the service subscribes to no events and
nothing runs on a timer, so there is no polling, no wake lock and no wake-ups):

- **Keep-alive.** The service runs as a foreground service, which the system and the cleaners
  leave alone. The price is one silent notification: minimum importance, so no status-bar icon
  and no sound, and hidden on the lock screen. The checkbox **Keep the service running** in the
  app turns it off. (`KeepAlive.kt`)
- **Never crashes its own process.** A process that keeps crashing is marked as misbehaving and
  Android stops restarting its services, which looks exactly like the symptom above. Every
  entry point of the service (button tap, tile action, chooser pick, delayed screenshot) is
  wrapped, and the chooser's layout inflation is inside its try block.
- **Says so when it happens anyway.** The app shows a banner (*Service stopped by Android, tap,
  then switch Volume Tile off and on*), and a tile tapped in that state says the same and jumps
  to Accessibility settings, instead of the old "Service is starting" forever. A freshly
  restarted process gets 8 seconds to be rebound before it counts as stopped.
- **Battery exemption.** The app offers a one-tap *Allow background running* button until it
  is exempt from battery optimisation.

If it still happens, the phone's own cleaner is the likely cause. On Infinix / Tecno (XOS /
HiOS; menu names vary by version): allow Volume Tile under Phone Master > Autostart (or the
app's own Battery / Background settings), and lock it in the Recents screen.

## Ring volume note

Android requires "Do Not Disturb access" before an app can move Ring volume
to/through silent. If you drag the Ring slider to 0 and it's blocked, a
**Grant Do Not Disturb access** button appears — tap it once, allow access in
Settings, and it won't ask again.

## Building

Your build log shows this is actually built through your existing
zip-upload pipeline (the `Apk` repo / ZipApkBuilder), not the
`.github/workflows/build.yml` included here — that workflow is just a
ready-to-go alternative if you ever push this as its own standalone repo.

The pipeline's "Fetch gradle-wrapper.jar" step has been reliably producing
a jar with no `MANIFEST.MF` Main-Class entry (`no main manifest attribute`
when `gradlew` tries `-jar` on it) — reproduced twice with the identical
byte count, so it's not a one-off. `gradlew` here uses `-classpath
gradle-wrapper.jar org.gradle.wrapper.GradleWrapperMain` instead of `-jar`,
which specifies the main class directly and doesn't need a manifest at
all — the same technique your `FloatNote` project's `gradlew` already
uses against this same pipeline. The real, robust fix is still to change
the pipeline's "Build APK" step to call the already-provisioned `gradle`
directly instead of `./gradlew` (see below); this is a workaround for
until that's changed, or if you'd rather not touch the pipeline.

## Known pipeline issue

In the `Brylelariosa/Apk` repo's workflow, the "Build APK" step runs
`./gradlew assembleRelease`/`assembleDebug`. The earlier "Setup Gradle"
step already provisions a working `gradle` binary and puts it on `PATH`
(`gradle/actions/setup-gradle@v3`), so swapping `./gradlew` for `gradle`
in that step removes the dependency on the broken jar-fetch entirely, and
the "Fetch gradle-wrapper.jar" and "Make gradlew executable" steps become
unnecessary.

## Project layout

```
app/src/main/java/com/volumetile/app/
  VolumeTileService.kt      — the Volume Quick Settings tile (name must not
                               change, or its place in the shade is lost)
  VolumeControlActivity.kt  — the slider panel (used both full-screen and as
                               the tile's floating dialog)
  BaseTileService.kt        — shared tile plumbing (state render, collapse+launch)
  ActionTiles.kt            — ActionTileService base + Screenshot / Shade shot /
                               Power menu tiles (one line each)
  SystemAction.kt           — the actions the tiles, the chooser and the bubble can fire
                               (label, hint, icon, min Android version) + where a request
                               came from
  SystemActionService.kt    — accessibility service that performs them, receives the
                               nav-bar accessibility button taps and hosts the floating
                               bubble; guards every entry point and reports connected /
                               stalled state
  KeepAlive.kt              — runs that service as a silent foreground service so the
                               system leaves its process alone (checkbox in the app)
  ActionChooserOverlay.kt   — the compact menu opened by that button or by a tap on the
                               bubble (overlay window)
  FloatingBubble.kt         — the bubble: overlay window + hold / swipe / tap / move gestures
  SwipeLegend.kt            — the card listing the four directions while the bubble is swiped
  SwipeDirection.kt         — up / down / left / right and each one's default action
  BubblePrefs.kt            — saved bubble settings: on/off, position, action per direction
  ContextExt.kt             — Context.toast(), dpToPx() and Context.showSystemVolumePanel()
app/src/main/res/           — layouts (panel, chooser + its rows, bubble pickers), strings,
                               icons, xml/ (accessibility config)
gradlew                     — classpath-style wrapper script (see Building)
gradlew.bat, gradle/wrapper/ — rest of the standard Gradle wrapper, pinned to
                               Gradle 8.9
.github/workflows/build.yml — alternate CI build, only used if pushed as its
                               own repo with Actions enabled
```

## Size optimizations

The release build (what CI produces) is shrunk without dropping any
functionality:

- R8 minification + resource shrinking enabled (was off)
- Removed two dependencies that were pulled in but never actually used
  in the code (Material Components, core-ktx)
- Bundled resources restricted to English, dropping ~70 unused translated
  string sets that AppCompat/CardView ship internally
- Signed by your pipeline's real release keystore (it injects one via
  `-Pandroid.injected.signing.*` properties when the `KEYSTORE_B64` secret is
  set) — the build no longer overrides that with the debug key, so future
  updates install over each other normally instead of needing a reinstall

Stack traces from a release-build crash still show real file/line info
(kept explicitly in `proguard-rules.pro`) despite the obfuscation.

Your pipeline builds `assembleDebug` automatically when no keystore secret
is configured, and `assembleRelease` when one is — nothing to trigger
manually.

