plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.volumetile.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.volumetile.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
        // Only English strings are used; this drops the ~70 bundled translations
        // that AppCompat/CardView ship for their own internal strings.
        // (Using resourceConfigurations, not androidResources.localeFilters -
        // the latter isn't resolvable in AGP 8.6.1, which this project pins.)
        resourceConfigurations += listOf("en")
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            // No signingConfig set here on purpose: your CI pipeline injects a real
            // release keystore via -Pandroid.injected.signing.* properties, and an
            // explicit signingConfig here would silently override that with the
            // debug key instead.
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = false
        buildConfig = false
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.cardview:cardview:1.0.0")
}
