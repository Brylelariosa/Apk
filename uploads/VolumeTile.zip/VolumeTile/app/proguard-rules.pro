# Add project specific ProGuard rules here.

# Keep file/line info so a release-build crash still shows a readable
# stack trace instead of obfuscated frames.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
