package com.volumetile.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.Drawable
import android.os.Build
import android.util.Log
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max

/**
 * A small floating bubble that sits on top of every app and runs an action when it is
 * swiped.
 *
 *  - Hold it and swipe up, down, left or right: runs the action chosen for that direction
 *    ([BubblePrefs.actionFor]). While the finger is down a small legend ([SwipeLegend])
 *    lists the four directions and highlights the one that will run. Letting go before the
 *    finger has travelled far enough does nothing, so a swipe can be called off.
 *  - Tap it: opens the action menu ([onTap]).
 *  - Hold it still until it grows, then drag: moves it. It settles against the nearest
 *    side of the screen and remembers where it was left.
 *
 * Like [ActionChooserOverlay] it is a TYPE_ACCESSIBILITY_OVERLAY window: only an
 * accessibility service may add one, it needs no extra permission, and because it is not
 * focusable a game in the foreground keeps its input focus. The window is only as big as
 * the bubble, so touches anywhere else go straight to the app underneath.
 *
 * @param service the accessibility service. Its own WindowManager must be used: only that
 *   one carries the token allowed to add overlay windows.
 * @param onTap called when the bubble is tapped.
 * @param onSwipe called with the direction when the bubble is released after a swipe that
 *   went far enough, in a direction that has an action.
 */
class FloatingBubble(
    private val service: Context,
    private val onTap: () -> Unit,
    private val onSwipe: (SwipeDirection) -> Unit
) {

    private enum class Touch { IDLE, PRESSED, SWIPING, MOVING }

    private val windowManager = service.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val legend = SwipeLegend(service)
    private val sizePx = service.dpToPx(SIZE_DP)

    // True while the person has the bubble switched on. The window may still be absent
    // for a moment, see [suppressed].
    private var wanted = false

    // Out of sight for a moment (a screenshot is about to be taken) without being switched off.
    private var suppressed = false

    // The window's content. Non-null exactly while the window exists.
    private var view: BubbleView? = null
    private var params: WindowManager.LayoutParams? = null
    private var snapAnimator: ValueAnimator? = null

    // Where the bubble rests: on which side of the screen, and how far down (0 = top, 1 = bottom).
    private var onRight = true
    private var yFraction = 0.35f

    /** True while the bubble is switched on, whether or not it is hidden for a screenshot. */
    val isShowing: Boolean
        get() = wanted

    fun show() {
        if (wanted) return
        wanted = true
        suppressed = false
        onRight = BubblePrefs.isOnRight(service)
        yFraction = BubblePrefs.yFraction(service)
        params = createParams().also { applyRestingPosition(it) }
        attach()
    }

    fun hide() {
        wanted = false
        suppressed = false
        detach()
        params = null
    }

    /**
     * Takes the bubble off the screen (or puts it back) without switching it off. A
     * screenshot would otherwise photograph it, so the service hides it around a capture.
     */
    fun setSuppressed(value: Boolean) {
        if (!wanted || suppressed == value) return
        suppressed = value
        if (value) detach() else attach()
    }

    /** Puts the bubble back where it belongs after the screen size or rotation changed. */
    fun relayout() {
        val lp = params ?: return
        applyRestingPosition(lp)
        pushLayout()
    }

    private fun attach() {
        if (!wanted || suppressed || view != null) return
        val lp = params ?: return
        val created = BubbleView(service)
        try {
            windowManager.addView(created, lp)
            view = created
        } catch (e: RuntimeException) {
            // The system refused the window (BadTokenException, e.g. while the service is
            // being torn down). Nothing was added, and nothing may escape from here: this
            // runs inside the accessibility service's process.
            Log.w(TAG, "Could not show the bubble", e)
            wanted = false
            params = null
            service.toast(R.string.toast_bubble_failed)
        }
    }

    private fun detach() {
        val current = view ?: return
        view = null
        snapAnimator?.cancel()
        snapAnimator = null
        legend.hide()
        try {
            windowManager.removeView(current)
        } catch (e: RuntimeException) {
            // Already gone - the system drops overlay windows when a service stops.
        }
    }

    private fun createParams() = WindowManager.LayoutParams(
        sizePx,
        sizePx,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        // Not focusable, so the app underneath keeps its keyboard/controller focus. Not
        // touch-modal, so a touch outside this small window reaches the app underneath too.
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        // Without this the bubble can't sit in the strip beside a notch/punch-hole in landscape.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }

    private fun screenWidth(): Int = service.resources.displayMetrics.widthPixels

    private fun screenHeight(): Int = service.resources.displayMetrics.heightPixels

    /** Highest the bubble may sit: clear of the status bar. */
    private fun topLimit(): Int = service.dpToPx(TOP_SAFE_DP)

    /** Lowest the bubble may sit: clear of the navigation bar / gesture area. */
    private fun bottomLimit(): Int =
        max(topLimit(), screenHeight() - sizePx - service.dpToPx(BOTTOM_SAFE_DP))

    private fun restingX(right: Boolean): Int {
        val margin = service.dpToPx(EDGE_MARGIN_DP)
        return if (right) screenWidth() - sizePx - margin else margin
    }

    private fun applyRestingPosition(lp: WindowManager.LayoutParams) {
        lp.x = restingX(onRight)
        lp.y = (topLimit() + yFraction * (bottomLimit() - topLimit())).toInt()
    }

    private fun pushLayout() {
        val current = view ?: return
        val lp = params ?: return
        try {
            windowManager.updateViewLayout(current, lp)
        } catch (e: RuntimeException) {
            Log.w(TAG, "Could not move the bubble", e)
        }
    }

    /** Follows the finger while the bubble is being carried. */
    private fun dragTo(x: Int, y: Int) {
        val lp = params ?: return
        lp.x = x.coerceIn(0, max(0, screenWidth() - sizePx))
        lp.y = y.coerceIn(topLimit(), bottomLimit())
        pushLayout()
    }

    /** Lets go of a carried bubble: slides it to the nearest side and remembers the spot. */
    private fun settle() {
        val lp = params ?: return
        onRight = lp.x + sizePx / 2 > screenWidth() / 2
        val span = bottomLimit() - topLimit()
        val toY = lp.y.coerceIn(topLimit(), bottomLimit())
        yFraction = if (span > 0) (toY - topLimit()).toFloat() / span else 0.5f
        BubblePrefs.savePosition(service, onRight, yFraction)

        val fromX = lp.x
        val fromY = lp.y
        val toX = restingX(onRight)
        snapAnimator?.cancel()
        snapAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = SNAP_MS
            interpolator = DecelerateInterpolator()
            addUpdateListener { animator ->
                val t = animator.animatedValue as Float
                lp.x = fromX + ((toX - fromX) * t).toInt()
                lp.y = fromY + ((toY - fromY) * t).toInt()
                pushLayout()
            }
            start()
        }
    }

    private inner class BubbleView(context: Context) : View(context) {

        private val disc = Paint(Paint.ANTI_ALIAS_FLAG)
        private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = context.dpToPx(1.5f).toFloat()
            color = Color.WHITE
        }
        private val accent = context.getColor(R.color.purple_500)
        private val baseRadius = context.dpToPx(RADIUS_DP).toFloat()
        private val slop = ViewConfiguration.get(context).scaledTouchSlop
        private val icons = HashMap<Int, Drawable>()

        private var touch = Touch.IDLE

        // Raw (screen) coordinates, so they stay valid while the window itself moves.
        private var downX = 0f
        private var downY = 0f
        private var lastX = 0f
        private var lastY = 0f

        // Where the window was when it was picked up to be carried.
        private var startWinX = 0
        private var startWinY = 0

        // What each direction does, read when a swipe starts: index = SwipeDirection.ordinal.
        private var mapped: List<SystemAction?> = emptyList()

        // The direction that would run if the finger were lifted now, if any.
        private var armed: SwipeDirection? = null

        // Held still long enough: the bubble grows and from now on follows the finger.
        private val enterMoveMode = Runnable {
            if (touch != Touch.PRESSED) return@Runnable
            touch = Touch.MOVING
            startWinX = params?.x ?: 0
            startWinY = params?.y ?: 0
            downX = lastX
            downY = lastY
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            invalidate()
        }

        init {
            contentDescription = context.getString(R.string.bubble_description)
            isSoundEffectsEnabled = false
        }

        private fun drawableFor(res: Int): Drawable? =
            icons[res] ?: context.getDrawable(res)?.also { icons[res] = it }

        override fun onDraw(canvas: Canvas) {
            val cx = width / 2f
            val cy = height / 2f
            val grow = when (touch) {
                Touch.MOVING -> 1.3f
                Touch.IDLE -> 1f
                Touch.PRESSED, Touch.SWIPING -> 1.12f
            }
            val radius = baseRadius * grow

            disc.color = accent
            disc.alpha = if (touch == Touch.IDLE) IDLE_ALPHA else 255
            canvas.drawCircle(cx, cy, radius, disc)
            ring.alpha = if (armed != null) 255 else 110
            canvas.drawCircle(cx, cy, radius - ring.strokeWidth / 2f, ring)

            // The icon of the action that would run, so the bubble itself confirms the pick.
            val action = armed?.let { mapped.getOrNull(it.ordinal) }
            val glyph = drawableFor(action?.iconRes ?: R.drawable.ic_bubble) ?: return
            val half = (radius * 0.55f).toInt()
            glyph.setBounds(cx.toInt() - half, cy.toInt() - half, cx.toInt() + half, cy.toInt() + half)
            glyph.draw(canvas)
        }

        override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
            super.onSizeChanged(w, h, oldw, oldh)
            // Keep the system's edge "back" swipe from stealing a swipe that starts on the
            // bubble. Best effort: it only exists from Android 10 and the system may ignore it.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                systemGestureExclusionRects = listOf(Rect(0, 0, w, h))
            }
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    snapAnimator?.cancel()
                    touch = Touch.PRESSED
                    downX = event.rawX
                    downY = event.rawY
                    lastX = downX
                    lastY = downY
                    armed = null
                    // Respect the phone's own "touch and hold" delay, but never go below the minimum.
                    postDelayed(
                        enterMoveMode,
                        max(ViewConfiguration.getLongPressTimeout(), MIN_HOLD_TO_MOVE_MS).toLong()
                    )
                    invalidate()
                }
                MotionEvent.ACTION_MOVE -> {
                    lastX = event.rawX
                    lastY = event.rawY
                    when (touch) {
                        Touch.PRESSED -> {
                            if (hypot(lastX - downX, lastY - downY) > slop) {
                                removeCallbacks(enterMoveMode)
                                touch = Touch.SWIPING
                                beginSwipe()
                                updateSwipe()
                                invalidate()
                            }
                        }
                        Touch.SWIPING -> updateSwipe()
                        Touch.MOVING -> dragTo(
                            startWinX + (lastX - downX).toInt(),
                            startWinY + (lastY - downY).toInt()
                        )
                        Touch.IDLE -> Unit
                    }
                }
                MotionEvent.ACTION_UP -> {
                    lastX = event.rawX
                    lastY = event.rawY
                    // A very fast flick can go from DOWN to UP with no MOVE in between.
                    if (touch == Touch.PRESSED && hypot(lastX - downX, lastY - downY) > slop) {
                        removeCallbacks(enterMoveMode)
                        touch = Touch.SWIPING
                        loadMapping()
                    }
                    // Judge the swipe by where the finger actually let go.
                    if (touch == Touch.SWIPING) updateSwipe()
                    finish(cancelled = false)
                }
                MotionEvent.ACTION_CANCEL -> finish(cancelled = true)
            }
            return true
        }

        override fun performClick(): Boolean {
            super.performClick()
            onTap()
            return true
        }

        override fun onDetachedFromWindow() {
            removeCallbacks(enterMoveMode)
            super.onDetachedFromWindow()
        }

        /** Reads what each direction does from the saved settings. */
        private fun loadMapping() {
            mapped = SwipeDirection.values().map { BubblePrefs.actionFor(context, it) }
        }

        private fun beginSwipe() {
            loadMapping()
            val entries = SwipeDirection.values().mapNotNull { direction ->
                mapped[direction.ordinal]?.let { action -> direction to action }
            }
            val lp = params ?: return
            legend.show(entries, lp.x, lp.y, sizePx)
        }

        private fun updateSwipe() {
            val dx = lastX - downX
            val dy = lastY - downY
            val horizontal = abs(dx) >= abs(dy)
            val direction = when {
                horizontal && dx >= 0f -> SwipeDirection.RIGHT
                horizontal -> SwipeDirection.LEFT
                dy >= 0f -> SwipeDirection.DOWN
                else -> SwipeDirection.UP
            }
            val travel = if (horizontal) abs(dx) else abs(dy)
            val hasAction = mapped.getOrNull(direction.ordinal) != null
            val now = if (hasAction && travel >= neededTravel(direction)) direction else null
            if (now == armed) return
            armed = now
            if (now != null) performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            legend.highlight(now)
            invalidate()
        }

        /**
         * How far the finger must travel in [direction] before the swipe counts. Normally
         * [SWIPE_DP], but a bubble resting against a screen edge has little room to pull
         * outwards, so the distance shrinks to what the screen allows - never below
         * [MIN_SWIPE_DP], so an ordinary tap with a little wobble can't run anything.
         */
        private fun neededTravel(direction: SwipeDirection): Float {
            val room = when (direction) {
                SwipeDirection.UP -> downY
                SwipeDirection.DOWN -> screenHeight() - downY
                SwipeDirection.LEFT -> downX
                SwipeDirection.RIGHT -> screenWidth() - downX
            }
            val most = context.dpToPx(SWIPE_DP).toFloat()
            val least = context.dpToPx(MIN_SWIPE_DP).toFloat()
            return (room - context.dpToPx(EDGE_PAD_DP)).coerceIn(least, most)
        }

        /** The finger went up or the system took the touch away. */
        private fun finish(cancelled: Boolean) {
            removeCallbacks(enterMoveMode)
            val was = touch
            val fired = if (was == Touch.SWIPING && !cancelled) armed else null
            touch = Touch.IDLE
            armed = null
            if (was == Touch.SWIPING) legend.hide()
            invalidate()
            when (was) {
                Touch.PRESSED -> if (!cancelled) performClick()
                Touch.MOVING -> settle()
                Touch.SWIPING, Touch.IDLE -> Unit
            }
            // Last, so everything above is finished even if the action hides the bubble.
            if (fired != null) onSwipe(fired)
        }
    }

    private companion object {
        const val TAG = "FloatingBubble"

        /** The bubble's window and touch target. The visible disc is smaller, leaving room to grow. */
        const val SIZE_DP = 48f
        const val RADIUS_DP = 18f

        /** Gap between the bubble and the screen edge it rests against. */
        const val EDGE_MARGIN_DP = 12f
        const val TOP_SAFE_DP = 24f
        const val BOTTOM_SAFE_DP = 56f

        /** Finger travel that counts as a swipe, its floor, and the room kept free at a screen edge. */
        const val SWIPE_DP = 36f
        const val MIN_SWIPE_DP = 20f
        const val EDGE_PAD_DP = 8f

        const val SNAP_MS = 180L

        /** Shortest hold that picks the bubble up to move it. Long enough to leave room for a swipe. */
        const val MIN_HOLD_TO_MOVE_MS = 500

        const val IDLE_ALPHA = 200
    }
}
