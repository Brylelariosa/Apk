package com.volumetile.app

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin

/**
 * Where the icons of the bubble's arc go, and which of them a finger movement points at.
 *
 * The icons sit on a circle around the bubble, but only on the half that faces the middle of
 * the screen, so together they form a "C" (or a backwards "C" when the bubble rests on the
 * left). The first icon is always the top one.
 *
 * Near the top or bottom of the screen, or on a short one, a full-size arc would run off the
 * edge. Then the whole arc is turned, just far enough that every icon stays on screen; and
 * if turning is not enough (a bubble parked in a corner), the icons are packed closer
 * together, a little at a time, until they fit.
 *
 * This is plain geometry with no Android types: [ArcMenu] draws what is decided here and
 * [FloatingBubble] asks it what the finger is pointing at.
 *
 * Angles are in degrees, counter-clockwise, 0 = right, 90 = up, 180 = left, 270 = down.
 * Positions are in screen pixels, y growing downwards.
 */
class ArcLayout private constructor(
    val centerX: Float,
    val centerY: Float,
    /** Distance from the bubble's centre to the centre of each icon. */
    val radius: Float,
    /** Angle between neighbouring icons. */
    val stepDeg: Float,
    /** The direction each icon lies in, in the order they were given. */
    val angles: FloatArray,
    /** The direction of the middle of the arc. */
    val midAngle: Float,
    /** How far the arc reaches either side of [midAngle]. */
    val halfSpan: Float
) {

    val count: Int
        get() = angles.size

    /** The point at [angle] on the arc's circle; [scale] pulls it towards the bubble (0) or leaves it (1). */
    fun pointX(angle: Float, scale: Float = 1f): Float = centerX + radius * scale * cos(angle * DEG_TO_RAD)

    fun pointY(angle: Float, scale: Float = 1f): Float = centerY - radius * scale * sin(angle * DEG_TO_RAD)

    /** Unit vector pointing away from the bubble in direction [angle]. */
    fun directionX(angle: Float): Float = cos(angle * DEG_TO_RAD)

    fun directionY(angle: Float): Float = -sin(angle * DEG_TO_RAD)

    /**
     * Which icon a finger that moved ([dx], [dy]) pixels from where it touched down points
     * at, or null for none: not moved [minDistance] yet, or heading somewhere no icon is
     * (towards the screen edge the bubble rests against), which is how a pick is called off.
     *
     * Only the direction counts, not how far the finger went, so a short flick is enough.
     */
    fun indexAt(dx: Float, dy: Float, minDistance: Float): Int? {
        if (hypot(dx, dy) < minDistance) return null
        val finger = atan2(-dy, dx) / DEG_TO_RAD
        var best = -1
        var bestGap = Float.MAX_VALUE
        for (i in angles.indices) {
            val gap = abs(gapBetween(finger, angles[i]))
            if (gap < bestGap) {
                best = i
                bestGap = gap
            }
        }
        return if (best >= 0 && bestGap <= stepDeg / 2f + END_SLACK_DEG) best else null
    }

    /** One way of placing the icons, and how far it leaves them off the screen. */
    private class Candidate(
        val radius: Float,
        val stepDeg: Float,
        val angles: FloatArray,
        val turn: Float,
        val overflow: Float
    )

    companion object {
        /** Angle between neighbouring icons, from the roomy layout down to the tightest. */
        private val STEPS_DEG = floatArrayOf(50f, 40f, 32f, 26f)

        /** How far past the first and last icon a direction still counts as pointing at it. */
        private const val END_SLACK_DEG = 20f

        /** How finely the arc is turned when it has to avoid a screen edge. */
        private const val TURN_STEP_DEG = 5f

        private val DEG_TO_RAD = (PI / 180.0).toFloat()

        /**
         * Lays out [count] icons for a bubble centred at ([centerX], [centerY]) on a screen of
         * [screenWidth] x [screenHeight] pixels. [radius] is the arc's size when there is room,
         * [margin] the least distance an icon's centre keeps from the screen edges, and
         * [minSpacing] the least distance between the centres of neighbouring icons (the arc
         * grows rather than let tightly packed icons overlap).
         */
        fun create(
            count: Int,
            centerX: Float,
            centerY: Float,
            screenWidth: Float,
            screenHeight: Float,
            radius: Float,
            margin: Float,
            minSpacing: Float
        ): ArcLayout {
            // Face the middle of the screen, and list the icons from the top down on either side.
            val facing = if (centerX > screenWidth / 2f) 180f else 0f

            var best: Candidate? = null
            for (step in STEPS_DEG) {
                val size = max(radius, minSpacing / (2f * sin(step / 2f * DEG_TO_RAD)))
                val candidate = bestTurn(
                    count, centerX, centerY, screenWidth, screenHeight, size, step, margin, facing
                )
                if (best == null || candidate.overflow < best.overflow) best = candidate
                if (candidate.overflow == 0f) break
            }
            val chosen = checkNotNull(best)
            return ArcLayout(
                centerX = centerX,
                centerY = centerY,
                radius = chosen.radius,
                stepDeg = chosen.stepDeg,
                angles = chosen.angles,
                midAngle = normalize(facing + chosen.turn),
                halfSpan = (count - 1) / 2f * chosen.stepDeg
            )
        }

        /**
         * The arc as it is, then turned a little either way, a little more, ... : the first
         * (smallest) turn that leaves every icon on screen, or, when none does, the one that
         * leaves the least off it.
         */
        private fun bestTurn(
            count: Int,
            centerX: Float,
            centerY: Float,
            screenWidth: Float,
            screenHeight: Float,
            radius: Float,
            step: Float,
            margin: Float,
            facing: Float
        ): Candidate {
            val order = if (facing == 180f) 1f else -1f

            fun candidateFor(turn: Float): Candidate {
                val angles = FloatArray(count) { i ->
                    normalize(facing + turn + order * (i - (count - 1) / 2f) * step)
                }
                var overflow = 0f
                for (angle in angles) {
                    val x = centerX + radius * cos(angle * DEG_TO_RAD)
                    val y = centerY - radius * sin(angle * DEG_TO_RAD)
                    overflow += (margin - x).coerceAtLeast(0f) + (x - (screenWidth - margin)).coerceAtLeast(0f)
                    overflow += (margin - y).coerceAtLeast(0f) + (y - (screenHeight - margin)).coerceAtLeast(0f)
                }
                return Candidate(radius, step, angles, turn, overflow)
            }

            var best = candidateFor(0f)
            var turn = TURN_STEP_DEG
            while (best.overflow > 0f && turn <= 180f) {
                for (signedTurn in floatArrayOf(turn, -turn)) {
                    val candidate = candidateFor(signedTurn)
                    if (candidate.overflow < best.overflow) best = candidate
                }
                turn += TURN_STEP_DEG
            }
            return best
        }

        private fun normalize(angle: Float): Float = ((angle % 360f) + 360f) % 360f

        /** Signed difference [a] - [b] folded into -180..180 degrees. */
        private fun gapBetween(a: Float, b: Float): Float = ((a - b + 540f) % 360f) - 180f
    }
}
