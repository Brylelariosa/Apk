package com.volumetile.app

/**
 * The four ways the floating bubble can be swiped. Each direction runs one [SystemAction]
 * (or nothing); [defaultAction] is what it runs until the person picks something else in
 * the app. The declaration order is the order used in the app's pickers and in the legend
 * shown while the bubble is being swiped.
 *
 * The defaults put the most used actions on the easiest swipes for a bubble that rests on
 * the right-hand edge: left (towards the screen) is a screenshot, and the rarely wanted
 * power menu sits on the outward swipe where it is least likely to be triggered by accident.
 */
enum class SwipeDirection(
    val prefKey: String,
    val arrow: String,
    val defaultAction: SystemAction?
) {
    UP("swipe_up", "\u2191", SystemAction.VOLUME_PANEL),
    DOWN("swipe_down", "\u2193", SystemAction.SHADE_SCREENSHOT),
    LEFT("swipe_left", "\u2190", SystemAction.SCREENSHOT),
    RIGHT("swipe_right", "\u2192", SystemAction.POWER_MENU)
}
