package com.volumetile.app

import android.annotation.SuppressLint
import android.app.NotificationManager
import android.content.ActivityNotFoundException
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/**
 * Shows adjustable sliders for Media, Ring, Notification and Alarm volume.
 * Reused two ways (see AndroidManifest): as the full-screen launcher activity,
 * and as a small floating dialog opened from the Quick Settings tile.
 *
 * Also the place that keeps the accessibility service healthy: it shows when the service
 * is off or has been stopped by the system, offers the battery-optimisation exemption, and
 * holds the checkbox for [KeepAlive].
 */
class VolumeControlActivity : AppCompatActivity() {

    private lateinit var audioManager: AudioManager
    private lateinit var rows: List<StreamRow>

    private val handler = Handler(Looper.getMainLooper())

    /**
     * Re-checks the service while it is switched on but not yet connected, so the banner
     * appears if it never comes up and vanishes as soon as it does. Stops by itself once
     * the answer can no longer change, and while the screen isn't showing.
     */
    private val watchService = object : Runnable {
        override fun run() {
            if (updateAccessibilityBanner()) handler.postDelayed(this, SERVICE_RECHECK_MS)
        }
    }

    private data class StreamRow(
        val stream: Int,
        val seekBar: SeekBar,
        val valueText: TextView
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_volume_control)

        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager

        rows = listOf(
            StreamRow(AudioManager.STREAM_MUSIC, findViewById(R.id.seekMedia), findViewById(R.id.valueMedia)),
            StreamRow(AudioManager.STREAM_RING, findViewById(R.id.seekRing), findViewById(R.id.valueRing)),
            StreamRow(
                AudioManager.STREAM_NOTIFICATION,
                findViewById(R.id.seekNotification),
                findViewById(R.id.valueNotification)
            ),
            StreamRow(AudioManager.STREAM_ALARM, findViewById(R.id.seekAlarm), findViewById(R.id.valueAlarm))
        )

        rows.forEach(::setupRow)

        findViewById<View>(R.id.btnGrantDnd).setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        }
        findViewById<View>(R.id.btnEnableAccessibility).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<View>(R.id.btnBatteryUnrestricted).setOnClickListener {
            requestUnrestrictedBattery()
        }
        findViewById<CheckBox>(R.id.checkKeepAlive).apply {
            isChecked = KeepAlive.isEnabled(this@VolumeControlActivity)
            setOnCheckedChangeListener { _, checked ->
                KeepAlive.setEnabled(this@VolumeControlActivity, checked)
                SystemActionService.refreshKeepAlive()
            }
        }
        findViewById<View>(R.id.btnDone).setOnClickListener { finish() }
    }

    override fun onResume() {
        super.onResume()
        // Re-sync sliders in case volume changed elsewhere (e.g. an incoming call)
        rows.forEach { row ->
            val current = audioManager.getStreamVolume(row.stream)
            row.seekBar.progress = current
            row.valueText.text = current.toString()
        }
        updateDndBannerVisibility()
        updateBatteryBannerVisibility()
        handler.removeCallbacks(watchService)
        watchService.run()
    }

    override fun onPause() {
        handler.removeCallbacks(watchService)
        super.onPause()
    }

    private fun setupRow(row: StreamRow) {
        val max = audioManager.getStreamMaxVolume(row.stream)
        val current = audioManager.getStreamVolume(row.stream)
        row.seekBar.max = max
        row.seekBar.progress = current
        row.valueText.text = current.toString()

        row.seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                row.valueText.text = progress.toString()
                if (!fromUser) return
                try {
                    audioManager.setStreamVolume(row.stream, progress, 0)
                } catch (e: SecurityException) {
                    Toast.makeText(
                        this@VolumeControlActivity,
                        getString(R.string.dnd_needed_toast),
                        Toast.LENGTH_SHORT
                    ).show()
                    updateDndBannerVisibility()
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar) {}
            override fun onStopTrackingTouch(seekBar: SeekBar) {}
        })
    }

    private fun updateDndBannerVisibility() {
        val notificationManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val needsAccess = !notificationManager.isNotificationPolicyAccessGranted
        findViewById<View>(R.id.btnGrantDnd).visibility = if (needsAccess) View.VISIBLE else View.GONE
    }

    /**
     * The Screenshot / Shade shot / Power menu tiles and the nav-bar button need the
     * accessibility service running. The banner covers both ways that can be missing:
     * switched off (never enabled, or an app update turned it off), or switched on but
     * stopped by the system - the case where the button just does nothing. Either way the
     * tap leads to Accessibility settings; for the second, flip Volume Tile off and on.
     *
     * @return true while the service is on but not connected yet, i.e. worth checking again.
     */
    private fun updateAccessibilityBanner(): Boolean {
        val button = findViewById<Button>(R.id.btnEnableAccessibility)
        val enabled = SystemActionService.isEnabled(this)
        val connected = SystemActionService.isConnected()
        when {
            !enabled -> {
                button.setText(R.string.enable_accessibility_access)
                button.visibility = View.VISIBLE
            }
            connected -> button.visibility = View.GONE
            SystemActionService.isStalled(this) -> {
                button.setText(R.string.restart_accessibility_service)
                button.visibility = View.VISIBLE
            }
            // Just (re)started: the system is about to bind the service. Say nothing yet.
            else -> button.visibility = View.GONE
        }
        return enabled && !connected
    }

    /** Offered until the app is exempt from battery optimisation; vanishes once it is. */
    private fun updateBatteryBannerVisibility() {
        val powerManager = getSystemService(POWER_SERVICE) as PowerManager
        val restricted = !powerManager.isIgnoringBatteryOptimizations(packageName)
        findViewById<View>(R.id.btnBatteryUnrestricted).visibility =
            if (restricted) View.VISIBLE else View.GONE
    }

    /**
     * Asks to be left out of battery optimisation. The first intent shows a one-tap system
     * dialog; if a phone lacks it, fall back to the full list, then to this app's info page.
     */
    @SuppressLint("BatteryLife")
    private fun requestUnrestrictedBattery() {
        val packageUri = Uri.parse("package:$packageName")
        val attempts = listOf(
            Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, packageUri),
            Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS),
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, packageUri)
        )
        for (intent in attempts) {
            try {
                startActivity(intent)
                return
            } catch (e: ActivityNotFoundException) {
                // This phone doesn't have that screen; try the next one.
            }
        }
    }

    private companion object {
        const val SERVICE_RECHECK_MS = 2_000L
    }
}
