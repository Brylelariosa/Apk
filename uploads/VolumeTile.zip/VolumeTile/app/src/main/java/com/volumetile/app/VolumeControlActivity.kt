package com.volumetile.app

import android.app.NotificationManager
import android.content.Intent
import android.media.AudioManager
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/**
 * Shows adjustable sliders for Media, Ring, Notification and Alarm volume.
 * Reused two ways (see AndroidManifest): as the full-screen launcher activity,
 * and as a small floating dialog opened from the Quick Settings tile.
 */
class VolumeControlActivity : AppCompatActivity() {

    private lateinit var audioManager: AudioManager
    private lateinit var rows: List<StreamRow>

    private data class StreamRow(
        val stream: Int,
        val seekBar: SeekBar,
        val valueText: TextView
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_volume_control)

        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager

        rows = listOf(
            StreamRow(AudioManager.STREAM_MUSIC, findViewById(R.id.seekMedia), findViewById(R.id.valueMedia)),
            StreamRow(AudioManager.STREAM_RING, findViewById(R.id.seekRing), findViewById(R.id.valueRing)),
            StreamRow(
                AudioManager.STREAM_NOTIFICATION,
                findViewById(R.id.seekNotification),
                findViewById(R.id.valueNotification)
            ),
            StreamRow(AudioManager.STREAM_ALARM, findViewById(R.id.seekAlarm), findViewById(R.id.valueAlarm))
        )

        rows.forEach(::setupRow)

        findViewById<View>(R.id.btnGrantDnd).setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        }
        findViewById<View>(R.id.btnDone).setOnClickListener { finish() }
    }

    override fun onResume() {
        super.onResume()
        // Re-sync sliders in case volume changed elsewhere (e.g. an incoming call)
        rows.forEach { row ->
            val current = audioManager.getStreamVolume(row.stream)
            row.seekBar.progress = current
            row.valueText.text = current.toString()
        }
        updateDndBannerVisibility()
    }

    private fun setupRow(row: StreamRow) {
        val max = audioManager.getStreamMaxVolume(row.stream)
        val current = audioManager.getStreamVolume(row.stream)
        row.seekBar.max = max
        row.seekBar.progress = current
        row.valueText.text = current.toString()

        row.seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                row.valueText.text = progress.toString()
                if (!fromUser) return
                try {
                    audioManager.setStreamVolume(row.stream, progress, 0)
                } catch (e: SecurityException) {
                    Toast.makeText(
                        this@VolumeControlActivity,
                        getString(R.string.dnd_needed_toast),
                        Toast.LENGTH_SHORT
                    ).show()
                    updateDndBannerVisibility()
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar) {}
            override fun onStopTrackingTouch(seekBar: SeekBar) {}
        })
    }

    private fun updateDndBannerVisibility() {
        val notificationManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val needsAccess = !notificationManager.isNotificationPolicyAccessGranted
        findViewById<View>(R.id.btnGrantDnd).visibility = if (needsAccess) View.VISIBLE else View.GONE
    }
}
