package com.volumetile.app

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.max

/**
 * The little card that appears beside the [FloatingBubble] while a finger is swiping it.
 * It lists what each direction does and highlights the one that will run if the finger is
 * lifted now, because the bubble itself is hidden under the fingertip.
 *
 * It is a second overlay window that cannot be touched (FLAG_NOT_TOUCHABLE), so it never
 * interferes with the swipe, and it sits on the side of the bubble that faces the middle of
 * the screen, where there is room for it.
 *
 * @param service the accessibility service; its own WindowManager must be used (see
 *   [ActionChooserOverlay]).
 */
class SwipeLegend(private val service: Context) {

    private val windowManager = service.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val cardColor = Color.argb(230, 33, 33, 33)

    private var root: LinearLayout? = null

    // The row of each listed direction, so the active one can be highlighted.
    private val rows = HashMap<SwipeDirection, View>()

    /**
     * Shows the card next to the bubble, whose window is at ([bubbleX], [bubbleY]) and
     * [bubbleSize] pixels square. Directions without an action are left out; with none at
     * all there is nothing to show.
     */
    fun show(
        entries: List<Pair<SwipeDirection, SystemAction>>,
        bubbleX: Int,
        bubbleY: Int,
        bubbleSize: Int
    ) {
        if (root != null || entries.isEmpty()) return
        val card = buildCard(entries)

        // Measure it ourselves: the window must be placed before it is added.
        card.measure(
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val cardW = card.measuredWidth
        val cardH = card.measuredHeight
        val metrics = service.resources.displayMetrics
        val gap = service.dpToPx(10f)
        val inset = service.dpToPx(8f)

        val bubbleOnRight = bubbleX + bubbleSize / 2 > metrics.widthPixels / 2
        val cardLeft = if (bubbleOnRight) bubbleX - gap - cardW else bubbleX + bubbleSize + gap
        val cardTop = (bubbleY + bubbleSize / 2 - cardH / 2)
            .coerceIn(inset, max(inset, metrics.heightPixels - cardH - inset))

        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = cardLeft
            y = cardTop
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        try {
            windowManager.addView(card, lp)
            root = card
        } catch (e: RuntimeException) {
            // Only a hint: if the system refuses the window the swipe still works without it.
            Log.w(TAG, "Could not show the swipe legend", e)
            rows.clear()
        }
    }

    /** Highlights the row of [direction], or none of them when it is null. */
    fun highlight(direction: SwipeDirection?) {
        for ((rowDirection, row) in rows) {
            row.background = if (rowDirection == direction) highlightBackground() else null
        }
    }

    fun hide() {
        val current = root ?: return
        root = null
        rows.clear()
        try {
            windowManager.removeView(current)
        } catch (e: RuntimeException) {
            // Already gone - the system drops overlay windows when a service stops.
        }
    }

    private fun highlightBackground() = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = service.dpToPx(10f).toFloat()
        setColor(service.getColor(R.color.purple_500))
    }

    private fun buildCard(entries: List<Pair<SwipeDirection, SystemAction>>): LinearLayout {
        val pad = service.dpToPx(6f)
        val card = LinearLayout(service).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = service.dpToPx(14f).toFloat()
                setColor(cardColor)
            }
        }
        for ((direction, action) in entries) {
            val row = LinearLayout(service).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                minimumHeight = service.dpToPx(34f)
                setPadding(service.dpToPx(8f), 0, service.dpToPx(12f), 0)
            }
            row.addView(
                TextView(service).apply {
                    text = direction.arrow
                    setTextColor(Color.WHITE)
                    textSize = 16f
                    gravity = Gravity.CENTER
                    minWidth = service.dpToPx(18f)
                }
            )
            row.addView(
                ImageView(service).apply { setImageResource(action.iconRes) },
                LinearLayout.LayoutParams(service.dpToPx(20f), service.dpToPx(20f)).apply {
                    marginStart = service.dpToPx(8f)
                }
            )
            row.addView(
                TextView(service).apply {
                    setText(action.labelRes)
                    setTextColor(Color.WHITE)
                    textSize = 14f
                },
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { marginStart = service.dpToPx(8f) }
            )
            card.addView(row)
            rows[direction] = row
        }
        return card
    }

    private companion object {
        const val TAG = "SwipeLegend"
    }
}
