package com.volumetile.app

import android.os.Build
import androidx.annotation.DrawableRes
import androidx.annotation.StringRes

/**
 * What [SystemActionService] can be asked to do. Three things ask it:
 *  - the extra Quick Settings tiles (one action each),
 *  - the chooser behind the navigation-bar accessibility button (and behind a tap on the
 *    floating bubble), which lists every supported action, and
 *  - the floating bubble, which runs the action chosen for each swipe direction.
 *
 * Label, hint and icon live here so a tile, the chooser and the bubble can never disagree.
 *
 * To add an action: add an entry here and handle it in SystemActionService.perform();
 * it then shows up in the chooser and in the bubble's pickers by itself. For a tile as
 * well, add a one-line subclass in ActionTiles.kt and a <service> in the manifest.
 */
enum class SystemAction(
    private val minSdk: Int,
    @StringRes val labelRes: Int,
    @StringRes val hintRes: Int,
    @DrawableRes val iconRes: Int
) {

    /**
     * Pops up the system volume panel, same as the Volume tile. Needs no global action,
     * so unlike the others it would work without the accessibility service; it is listed
     * here so the chooser can offer it.
     */
    VOLUME_PANEL(
        Build.VERSION_CODES.O,
        R.string.tile_label,
        R.string.hint_volume,
        R.drawable.ic_volume
    ),

    /** Takes a normal screenshot of whatever is underneath, closing the shade first if a tile opened it. */
    SCREENSHOT(
        Build.VERSION_CODES.P,
        R.string.tile_screenshot,
        R.string.hint_screenshot,
        R.drawable.ic_screenshot
    ),

    /** Takes a screenshot with the shade open, so the notification area is what gets captured. */
    SHADE_SCREENSHOT(
        Build.VERSION_CODES.P,
        R.string.tile_shade_screenshot,
        R.string.hint_shade_screenshot,
        R.drawable.ic_screenshot_shade
    ),

    /** Opens the system power menu - what holding the power button does. */
    POWER_MENU(
        Build.VERSION_CODES.O,
        R.string.tile_power,
        R.string.hint_power,
        R.drawable.ic_power
    );

    /** False on Android versions that lack the underlying global action. */
    val isSupported: Boolean
        get() = Build.VERSION.SDK_INT >= minSdk

    companion object {
        /** The actions this Android version can perform, in the order the chooser lists them. */
        fun supported(): List<SystemAction> = values().filter { it.isSupported }
    }
}

/**
 * Where a [SystemAction] request came from. It decides what is on screen when the
 * action runs, which some actions have to account for.
 */
enum class ActionOrigin {
    /** A tile tap: the notification shade is open and the tile's press feedback is showing. */
    QUICK_SETTINGS_TILE,

    /** A chooser pick: the shade is closed and the chooser panel was only just removed. */
    CHOOSER,

    /** A swipe on the floating bubble: the shade is closed and only the bubble is on top of the app. */
    BUBBLE
}
