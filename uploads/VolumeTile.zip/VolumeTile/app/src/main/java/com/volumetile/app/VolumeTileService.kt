package com.volumetile.app

import android.app.PendingIntent
import android.content.ComponentName
import android.content.Intent
import android.media.AudioManager
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/**
 * Quick Settings tile. Tapping it opens [VolumeControlActivity] (via the
 * VolumeTileDialogActivity alias) as a small floating panel over the Quick
 * Settings shade, so volume can be adjusted without physical buttons.
 */
class VolumeTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        updateTile()
    }

    override fun onClick() {
        super.onClick()

        val intent = Intent().apply {
            component = ComponentName(this@VolumeTileService, "com.volumetile.app.VolumeTileDialogActivity")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        if (Build.VERSION.SDK_INT >= 34) {
            val pendingIntent = PendingIntent.getActivity(
                this,
                0,
                intent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            startActivityAndCollapse(pendingIntent)
        } else {
            @Suppress("DEPRECATION")
            startActivityAndCollapse(intent)
        }
    }

    private fun updateTile() {
        val tile = qsTile ?: return
        val audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        val current = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val percent = if (max > 0) (current * 100 / max) else 0

        tile.state = Tile.STATE_ACTIVE
        tile.label = getString(R.string.tile_label)
        tile.subtitle = "$percent%"
        tile.updateTile()
    }
}
