package com.volumetile.app

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.ContextThemeWrapper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ImageView
import android.widget.TextView

/**
 * The "what do you want to do?" panel opened by the navigation-bar accessibility button.
 *
 * It is a window of type TYPE_ACCESSIBILITY_OVERLAY, not an activity, on purpose: an
 * activity would take over the screen and push the foreground app (a game, say) into
 * the background, while an overlay leaves it running underneath. Only an accessibility
 * service may add that window type, and it needs no extra permission.
 *
 * The window is not focusable, so a game keeps its input focus - which also means there
 * is no Back key for the panel. It closes on a tap outside the card, on Cancel, on a
 * pick, and by itself after [AUTO_DISMISS_MS] in case the screen was switched off.
 *
 * @param service the accessibility service. Its own WindowManager must be used: only that
 *   one carries the token allowed to add overlay windows.
 * @param onPick called after the panel has been removed, with the action that was chosen.
 */
class ActionChooserOverlay(
    private val service: Context,
    private val onPick: (SystemAction) -> Unit
) {

    private val windowManager = service.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val autoDismiss = Runnable { dismiss() }

    private var panel: View? = null

    val isShowing: Boolean
        get() = panel != null

    fun toggle(actions: List<SystemAction>) {
        if (isShowing) dismiss() else show(actions)
    }

    fun show(actions: List<SystemAction>) {
        if (isShowing || actions.isEmpty()) return
        val view = try {
            buildPanel(actions).also { windowManager.addView(it, windowParams()) }
        } catch (e: RuntimeException) {
            // Either the layout couldn't be inflated, or the system refused the window
            // (BadTokenException, e.g. while the service is being torn down). Nothing was
            // added, so nothing to clean up - and nothing may escape: this runs inside the
            // accessibility service's process.
            service.toast(R.string.toast_action_failed)
            return
        }
        panel = view
        handler.postDelayed(autoDismiss, AUTO_DISMISS_MS)
    }

    fun dismiss() {
        val view = panel ?: return
        panel = null
        handler.removeCallbacks(autoDismiss)
        try {
            windowManager.removeView(view)
        } catch (e: RuntimeException) {
            // Already gone - the system drops overlay windows when a service stops.
        }
    }

    private fun buildPanel(actions: List<SystemAction>): View {
        // A service context carries no app theme. Borrow the app's so CardView and the text
        // colours follow light/dark mode like the rest of the app.
        val themed = ContextThemeWrapper(service, R.style.Theme_VolumeApp)
        val inflater = LayoutInflater.from(themed)

        val root = inflater.inflate(R.layout.overlay_action_chooser, null)
        root.setOnClickListener { dismiss() } // the dimmed backdrop: a tap outside the card
        root.findViewById<View>(R.id.chooserCancel).setOnClickListener { dismiss() }

        val list = root.findViewById<ViewGroup>(R.id.chooserList)
        actions.forEach { action -> list.addView(buildRow(inflater, list, action)) }
        return root
    }

    private fun buildRow(inflater: LayoutInflater, parent: ViewGroup, action: SystemAction): View {
        val row = inflater.inflate(R.layout.item_action_choice, parent, false)
        row.findViewById<ImageView>(R.id.actionIcon).setImageResource(action.iconRes)
        row.findViewById<TextView>(R.id.actionLabel).setText(action.labelRes)
        row.findViewById<TextView>(R.id.actionHint).setText(action.hintRes)
        row.setOnClickListener {
            dismiss()
            onPick(action)
        }
        return row
    }

    private fun windowParams() = WindowManager.LayoutParams(
        WindowManager.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    ).apply {
        // Without this the backdrop stops short of a notch/punch-hole in landscape.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }

    private companion object {
        /** Safety net so a forgotten panel doesn't sit over the next app for ever. */
        const val AUTO_DISMISS_MS = 15_000L
    }
}
