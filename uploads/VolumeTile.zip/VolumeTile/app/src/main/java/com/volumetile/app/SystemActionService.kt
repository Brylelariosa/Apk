package com.volumetile.app

import android.accessibilityservice.AccessibilityButtonController
import android.accessibilityservice.AccessibilityService
import android.annotation.SuppressLint
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.os.SystemClock
import android.provider.Settings
import android.util.Log
import android.view.accessibility.AccessibilityEvent

/**
 * Presses system buttons on behalf of the Quick Settings tiles, of the accessibility
 * button in the navigation bar and of the floating bubble.
 *
 * Apps can't take screenshots or open the power menu directly; without root the
 * only route is an AccessibilityService, whose performGlobalAction() hands the
 * request to the system. This one subscribes to no events and can't read window
 * content (see res/xml/system_action_service.xml) - it only runs what it is asked,
 * so while idle it costs no CPU and no battery.
 *
 * Requests reach it three ways:
 *  - A tile calls [dispatch]. Tiles live in the same process, so they reach the
 *    running instance through the companion instead of binding to it.
 *  - The person taps the accessibility button. That opens an [ActionChooserOverlay]
 *    and whatever they pick is run with [ActionOrigin.CHOOSER].
 *  - The person uses the floating bubble, if they switched it on in the app. A tap opens
 *    the same chooser; a swipe runs the action set for that direction with
 *    [ActionOrigin.BUBBLE]. The bubble is a window of this service, so it only exists
 *    while the service runs, and [refreshBubble] applies the app's switch right away.
 *
 * Staying alive: the system can leave this service switched on in Settings yet no longer
 * running (its process cleaned up while the phone idled). [KeepAlive] makes that unlikely,
 * [guarded] makes sure this code never crashes the process itself, and [isStalled] lets
 * the tiles and the app notice and say so when it happens anyway.
 */
class SystemActionService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())

    // Created on first use, dropped again in release().
    private var chooser: ActionChooserOverlay? = null
    private var bubble: FloatingBubble? = null
    private var buttonController: AccessibilityButtonController? = null

    private val buttonCallback = object : AccessibilityButtonController.AccessibilityButtonCallback() {
        override fun onClicked(controller: AccessibilityButtonController) {
            guarded { toggleChooser() }
        }
    }

    // The bubble is hidden while a screenshot is on its way (see scheduleScreenshot).
    private val showBubbleTask = Runnable { bubble?.setSuppressed(false) }

    private val screenshotTask = Runnable {
        guarded {
            if (!performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)) {
                toast(R.string.toast_action_failed)
            }
        }
        // Give the capture a moment, then bring the bubble back.
        handler.postDelayed(showBubbleTask, BUBBLE_RESTORE_MS)
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        // The system only shows the button for this service, and only delivers its taps,
        // because res/xml/system_action_service.xml sets flagRequestAccessibilityButton.
        buttonController = accessibilityButtonController.also {
            it.registerAccessibilityButtonCallback(buttonCallback)
        }
        KeepAlive.sync(this)
        guarded { syncBubble() }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // Rotation: the bubble keeps its side and relative height, so put it there again.
        guarded { bubble?.relayout() }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() = Unit

    override fun onUnbind(intent: Intent?): Boolean {
        release()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        release()
        super.onDestroy()
    }

    private fun release() {
        handler.removeCallbacksAndMessages(null)
        buttonController?.unregisterAccessibilityButtonCallback(buttonCallback)
        buttonController = null
        chooser?.dismiss()
        chooser = null
        bubble?.hide()
        bubble = null
        KeepAlive.stop(this)
        if (instance === this) instance = null
    }

    /**
     * Runs [block] and swallows whatever it throws. This process hosts the service, and a
     * process that keeps crashing gets marked as misbehaving: Android then stops restarting
     * the service, and it stays dead until the switch in Settings is flipped by hand. A
     * failed tap is a toast; it must never be a crash.
     */
    private fun guarded(block: () -> Unit) {
        try {
            block()
        } catch (e: Exception) {
            Log.w(TAG, "Action failed", e)
            runCatching { toast(R.string.toast_action_failed) }
        }
    }

    private fun toggleChooser() {
        val overlay = chooser ?: ActionChooserOverlay(this) { action ->
            guarded { perform(action, ActionOrigin.CHOOSER) }
        }.also { chooser = it }
        overlay.toggle(SystemAction.supported())
    }

    /** Shows or hides the floating bubble to match the setting saved by the app. */
    private fun syncBubble() {
        if (!BubblePrefs.isEnabled(this)) {
            bubble?.hide()
            bubble = null
            return
        }
        val existing = bubble
        if (existing != null) {
            existing.show()
            return
        }
        val created = FloatingBubble(
            this,
            onTap = { guarded { toggleChooser() } },
            onSwipe = { direction -> guarded { performSwipe(direction) } }
        )
        bubble = created
        created.show()
    }

    /** Runs whatever the person set for a swipe in [direction] on the floating bubble. */
    private fun performSwipe(direction: SwipeDirection) {
        val action = BubblePrefs.actionFor(this, direction) ?: return
        if (!action.isSupported) {
            toast(R.string.toast_unsupported)
            return
        }
        perform(action, ActionOrigin.BUBBLE)
    }

    private fun perform(action: SystemAction, origin: ActionOrigin) {
        when (action) {
            SystemAction.VOLUME_PANEL -> showSystemVolumePanel()
            SystemAction.SCREENSHOT -> takeScreenshot(origin)
            SystemAction.SHADE_SCREENSHOT -> takeShadeScreenshot(origin)
            SystemAction.POWER_MENU -> {
                if (!performGlobalAction(GLOBAL_ACTION_POWER_DIALOG)) {
                    toast(R.string.toast_action_failed)
                }
            }
        }
    }

    private fun takeScreenshot(origin: ActionOrigin) {
        when (origin) {
            // The shade is open (the tile lives in it): close it and let it finish animating.
            ActionOrigin.QUICK_SETTINGS_TILE -> {
                collapseShade()
                scheduleScreenshot(SHADE_COLLAPSE_SETTLE_MS)
            }
            // Nothing to close; just let the chooser panel (or the bubble's legend) disappear.
            ActionOrigin.CHOOSER, ActionOrigin.BUBBLE -> scheduleScreenshot(TAP_SETTLE_MS)
        }
    }

    private fun takeShadeScreenshot(origin: ActionOrigin) {
        when (origin) {
            // Shade stays open on purpose, so it is part of the capture.
            ActionOrigin.QUICK_SETTINGS_TILE -> scheduleScreenshot(TAP_SETTLE_MS)
            // The shade is closed here, so pull it down first and give it time to open.
            ActionOrigin.CHOOSER, ActionOrigin.BUBBLE -> {
                if (performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)) {
                    scheduleScreenshot(SHADE_EXPAND_SETTLE_MS)
                } else {
                    toast(R.string.toast_action_failed)
                }
            }
        }
    }

    private fun scheduleScreenshot(delayMs: Long) {
        // Cancel any pending capture first so a double tap still yields one screenshot.
        handler.removeCallbacks(screenshotTask)
        // The bubble is a window like any other and would be in the picture: hide it until
        // the capture is done (screenshotTask brings it back).
        handler.removeCallbacks(showBubbleTask)
        bubble?.setSuppressed(true)
        handler.postDelayed(screenshotTask, delayMs)
    }

    /**
     * Closes the notification shade without launching an activity, so a game in
     * the foreground isn't paused. API 31 added a proper global action for this;
     * before that, the close-system-dialogs broadcast does the same job.
     */
    @Suppress("DEPRECATION")
    private fun collapseShade() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            performGlobalAction(GLOBAL_ACTION_DISMISS_NOTIFICATION_SHADE)
        } else {
            sendBroadcast(Intent(Intent.ACTION_CLOSE_SYSTEM_DIALOGS))
        }
    }

    companion object {
        private const val TAG = "SystemActionService"

        /** Time for the shade's collapse animation to finish before we capture. */
        private const val SHADE_COLLAPSE_SETTLE_MS = 500L

        /** Time for the shade's open animation to finish before we capture. */
        private const val SHADE_EXPAND_SETTLE_MS = 800L

        /**
         * Lets whatever was just tapped - a tile's press feedback, or the chooser panel -
         * disappear so it isn't in the capture.
         */
        private const val TAP_SETTLE_MS = 250L

        /** How long after the capture was requested the bubble stays hidden, so it is not in the picture. */
        private const val BUBBLE_RESTORE_MS = 1_000L

        /**
         * How long a freshly started process gets before an unconnected service counts as
         * stalled. After a restart the system needs a moment to bind the service again.
         */
        private const val BIND_GRACE_MS = 8_000L

        // Cleared in release(), so it never outlives the service.
        @SuppressLint("StaticFieldLeak")
        @Volatile
        private var instance: SystemActionService? = null

        /** True when the user has switched the service on in Accessibility settings. */
        fun isEnabled(context: Context): Boolean {
            val resolver = context.contentResolver
            if (Settings.Secure.getInt(resolver, Settings.Secure.ACCESSIBILITY_ENABLED, 0) != 1) {
                return false
            }
            val enabled = Settings.Secure.getString(
                resolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            val self = ComponentName(context, SystemActionService::class.java)
            return enabled.split(':').any { ComponentName.unflattenFromString(it) == self }
        }

        /** True while the system has the service bound, i.e. while taps and tile actions reach it. */
        fun isConnected(): Boolean = instance != null

        /**
         * True when Settings lists the service as on but the system isn't running it: the
         * nav-bar button and the tiles do nothing, and only switching the service off and
         * on again in Accessibility settings brings it back.
         */
        fun isStalled(context: Context): Boolean =
            instance == null && processUptimeMs() > BIND_GRACE_MS && isEnabled(context)

        /** Applies the saved keep-alive setting right away, if the service is running. */
        fun refreshKeepAlive() {
            instance?.let { KeepAlive.sync(it) }
        }

        /** Shows, hides or re-reads the floating bubble right away, if the service is running. */
        fun refreshBubble() {
            instance?.let { service -> service.guarded { service.syncBubble() } }
        }

        /**
         * Runs [action] if the service is connected. Returns false when it isn't -
         * e.g. just after a process restart, before the system has rebound it.
         * Tiles use the default [origin]; the chooser passes its own.
         */
        fun dispatch(
            action: SystemAction,
            origin: ActionOrigin = ActionOrigin.QUICK_SETTINGS_TILE
        ): Boolean {
            val service = instance ?: return false
            service.guarded { service.perform(action, origin) }
            return true
        }

        private fun processUptimeMs(): Long =
            SystemClock.elapsedRealtime() - Process.getStartElapsedRealtime()
    }
}
