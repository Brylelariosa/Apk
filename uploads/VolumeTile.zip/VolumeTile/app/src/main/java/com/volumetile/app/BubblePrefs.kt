package com.volumetile.app

import android.content.Context

/**
 * Saved settings of the floating bubble: whether it is switched on, where it was left, and
 * which action each place on its arc ([ArcSlot]) holds.
 *
 * Plain SharedPreferences, like [KeepAlive]. The accessibility service reads them when it
 * connects and again whenever the app tells it something changed.
 */
object BubblePrefs {

    private const val PREFS = "bubble"
    private const val KEY_ENABLED = "enabled"
    private const val KEY_ON_RIGHT = "on_right"
    private const val KEY_Y_FRACTION = "y_fraction"

    /** Stored for a slot the person set to "Nothing", to tell it apart from "never chosen". */
    private const val NONE = "none"

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** Off until the person switches it on in the app. */
    fun isEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_ENABLED, false)

    fun setEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_ENABLED, enabled).apply()
    }

    /** True when the bubble was last left on the right-hand side of the screen. */
    fun isOnRight(context: Context): Boolean = prefs(context).getBoolean(KEY_ON_RIGHT, true)

    /** How far down the bubble was left: 0 is the top of the usable height, 1 the bottom. */
    fun yFraction(context: Context): Float = prefs(context).getFloat(KEY_Y_FRACTION, 0.35f)

    fun savePosition(context: Context, onRight: Boolean, yFraction: Float) {
        prefs(context).edit()
            .putBoolean(KEY_ON_RIGHT, onRight)
            .putFloat(KEY_Y_FRACTION, yFraction)
            .apply()
    }

    /**
     * The action [slot] holds, or null when it holds nothing. A slot that was never set falls
     * back to what its swipe direction was set to before the arc existed, then to its default.
     */
    fun actionFor(context: Context, slot: ArcSlot): SystemAction? {
        val store = prefs(context)
        val saved = store.getString(slot.prefKey, null)
            ?: store.getString(slot.legacyKey, null)
            ?: return slot.defaultAction
        if (saved == NONE) return null
        return SystemAction.values().firstOrNull { it.name == saved } ?: slot.defaultAction
    }

    fun setAction(context: Context, slot: ArcSlot, action: SystemAction?) {
        prefs(context).edit().putString(slot.prefKey, action?.name ?: NONE).apply()
    }
}
