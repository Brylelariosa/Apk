package com.volumetile.app

/**
 * The four places on the floating bubble's arc, from the top icon to the bottom one. Each
 * holds one [SystemAction] (or nothing); [defaultAction] is what it holds until the person
 * picks something else in the app. The declaration order is the order of the icons on the
 * arc and of the pickers in the app. A slot set to "Nothing" is left out and the icons
 * that remain close up.
 *
 * The defaults are the order the arc was asked for: volume, power menu, screenshot, and the
 * second kind of screenshot (the one with the notification shade open).
 *
 * [legacyKey] is the preference key of the swipe direction this slot replaced, so a choice
 * made before the arc existed still applies.
 */
enum class ArcSlot(
    val prefKey: String,
    val legacyKey: String,
    val defaultAction: SystemAction?
) {
    FIRST("arc_1", "swipe_up", SystemAction.VOLUME_PANEL),
    SECOND("arc_2", "swipe_right", SystemAction.POWER_MENU),
    THIRD("arc_3", "swipe_left", SystemAction.SCREENSHOT),
    FOURTH("arc_4", "swipe_down", SystemAction.SHADE_SCREENSHOT)
}
