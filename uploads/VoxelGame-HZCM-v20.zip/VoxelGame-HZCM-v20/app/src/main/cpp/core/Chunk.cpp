// ============================================================================
// HZCM v4 — Chunk.cpp
// ============================================================================
#include "Chunk.h"
#include <android/log.h>
#include <cstring>
#include <cmath>
#include <algorithm>

#define TAG "HZCMChunk"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)

// ── Constructor ────────────────────────────────────────────────────────────────
Chunk::Chunk(int cx, int cz) : cx(cx), cz(cz) {
    memset(blocks, BLOCK_AIR, sizeof(blocks));
    for (int i = 0; i < CLUSTER_STACK; ++i) {
        clusterState[i].store(ClusterState::EMPTY, std::memory_order_relaxed);
        clusterGPUOffset[i] = MEGA_INVALID;
        clusterFaceCount[i] = 0;
        clusterDirtyGen[i]  = 0;
    }
}

// ── Terrain generation ─────────────────────────────────────────────────────────
//
// v20 layered terrain system:
//
//   Performance: removed redundant mountain-peak warp (saved ~8 noise calls/column).
//   Reduced octave counts: cont 4→3, erosion 3→2, ridge 4→3, detail 3→2.
//   Overall: ~33% fewer noise calls per column → faster generation on mobile.
//
//   Terrain quality:
//   • Mountain height multiplier 26→42 for dramatic peaks.
//   • Valley carve strengthened: wider and deeper river basins.
//   • Detail noise amplitude reduced 3→2 blocks (less high-frequency jitter).
//   • All base frequencies slightly lowered for larger-scale geological features.
//   • Noise dithering (±4%) at biome borders avoids hard straight-line transitions.
//   • Plateau zones: high-erosion + elevated continent → broad flat highlands.
//
//   Block layer changes:
//   • All 16 block types now used correctly (RED_SAND, CLAY, ICE, CACTUS,
//     BASALT, COBBLE are fully supported by the v20 shader LUT).
//
void Chunk::generate(const Noise& noise) {

    // ── Tuning constants ──────────────────────────────────────────────────────
    static constexpr int   SEA_LEVEL    = 26;           // raised 24→26: deeper oceans
    static constexpr float WARP_SCALE   = 80.0f;        // domain warp magnitude (blocks)
    static constexpr float WARP_FREQ    = 0.0012f;      // lowered 0.0015→0.0012: wider organic curves
    static constexpr int   TREE_BORDER  = 3;            // inset from chunk edge for trunks

    for (int lz = 0; lz < CHUNK_D; ++lz) {
        for (int lx = 0; lx < CHUNK_W; ++lx) {
            const float wx = (float)(cx * CHUNK_W + lx);
            const float wz = (float)(cz * CHUNK_D + lz);

            // ── Domain warp — offset coordinates before sampling ───────────
            // Two independent 2-octave fbm samples warp X and Z separately.
            // v20: removed separate mountain-peak warp (pwox/pwoz).  Both the
            // broad landscape AND mountain ridges use the same primary warp,
            // which is geologically more coherent (mountain chains follow the
            // same large-scale curvature as the surrounding terrain) and saves
            // 4 fbm calls (~8 noise2D calls) per column.
            float wox = noise.fbm(wx * WARP_FREQ + 3.7f,
                                  wz * WARP_FREQ + 1.3f, 2, 2.0f, 0.5f);
            float woz = noise.fbm(wx * WARP_FREQ + 8.1f,
                                  wz * WARP_FREQ + 5.9f, 2, 2.0f, 0.5f);
            float swx = wx + wox * WARP_SCALE;
            float swz = wz + woz * WARP_SCALE;

            // ── Layer 1: Continentalness (warped) ─────────────────────────
            // v20: freq 0.0035→0.003 for larger landmasses; octaves 4→3.
            // Low-frequency fbm controls the ocean/continent split.
            float contN = noise.fbm(swx * 0.003f,
                                    swz * 0.003f, 3, 2.0f, 0.5f);
            float contH = 28.0f + contN * 14.0f;   // [14, 42] blocks

            // ── Layer 2: Erosion (warped, separate offset) ─────────────────
            // v20: octaves 3→2 for performance; freq kept at 0.006.
            // High erosion (positive) → flat plains/valleys.
            // Low erosion (negative)  → sharp ridges, cliffs, rugged peaks.
            float erosN   = noise.fbm(swx * 0.006f + 200.0f,
                                      swz * 0.006f + 200.0f, 2, 2.0f, 0.55f);
            float erosion = (erosN + 1.0f) * 0.5f;  // remap [-1,1] → [0,1]

            // ── Layer 3: Peaks & Valleys (warped ridged noise) ─────────────
            // v20: octaves 4→3; freq 0.012→0.010 for wider mountain ranges.
            // Ridge noise uses the primary warp (was: separate peak warp).
            float ridgeN = noise.fbmRidged(swx * 0.010f + 50.0f,
                                           swz * 0.010f + 50.0f, 3, 2.0f, 0.5f);

            // Mountain mask: ridge height only grows where the continent is
            // already elevated AND erosion is low (geologically rugged region).
            // Squaring concentrates peaks in the highest elevated areas.
            float mountMask = std::max(0.0f, contN) * (1.0f - erosion * 0.75f);
            mountMask = mountMask * mountMask;

            // v20: height multiplier 26→42 for dramatic, realistic mountain peaks.
            // Power curve 2.2 keeps broad bases with sharp pointed summits.
            float peakH = powf(ridgeN, 2.2f) * mountMask * 42.0f;

            // ── Layer 4: Valley carving ────────────────────────────────────
            // v20: strengthened threshold 0.55→0.45, multiplier 12→18.
            // High-erosion zones are pushed further downward, carving deeper
            // river basins and broader valleys between mountain ranges.
            float valleyCarve = std::max(0.0f, erosion - 0.45f) * 18.0f;

            // ── Layer 5: Plateau detection ─────────────────────────────────
            // v20: new feature. High erosion + elevated continent → broad flat
            // highlands. Erosion > 0.60 means the landscape has been worn
            // smooth; when the continent is already elevated this produces
            // mesa-like plateaus rather than deep valleys.
            // We clamp the plateau height to a narrow band so it doesn't
            // override the mountain-range logic above it.
            float plateauH = 0.0f;
            if (erosion > 0.60f && contN > 0.05f) {
                float plateauBlend = (erosion - 0.60f) * 2.5f;  // 0..1 ramp
                plateauBlend = std::min(1.0f, plateauBlend);
                // Pull height toward a flat level just above sea level
                float targetH = SEA_LEVEL + 6.0f + contN * 8.0f;
                plateauH = (targetH - (contH + peakH - valleyCarve)) * plateauBlend * 0.45f;
            }

            // ── Layer 6: Fine surface detail ───────────────────────────────
            // v20: octaves 3→2; amplitude 3.0→2.0.  Reduced detail noise
            // eliminates the "random bumpy" appearance that made terrain look
            // procedural/artificial.  Large-scale silhouette now dominates.
            float detailN = noise.fbm(wx * 0.055f + 20.0f,
                                      wz * 0.055f + 20.0f, 2, 2.0f, 0.45f);
            float detailH = detailN * 2.0f;

            // ── Combine all layers ─────────────────────────────────────────
            int h = (int)(contH + peakH - valleyCarve + plateauH + detailH);
            h = std::max(2, std::min(CHUNK_H - 4, h));

            // ── Climate sampling ───────────────────────────────────────────
            // Temperature and humidity sampled at scales independent of terrain
            // so climate decouples from topography (cold valleys + warm peaks
            // are possible, matching real geography).
            float tempN  = noise.noise2D(wx * 0.004f + 500.0f,
                                         wz * 0.004f + 500.0f);
            float humidN = noise.noise2D(wx * 0.005f + 900.0f,
                                         wz * 0.005f + 900.0f);

            // ── Biome dithering ────────────────────────────────────────────
            // v20: add a small per-column noise offset (±0.04) to temperature
            // and humidity thresholds.  This creates a ~3-4 column wide
            // dithered band at biome borders instead of a hard straight line,
            // breaking the grid-aligned appearance of threshold-based biomes.
            unsigned ditherSd = (unsigned)(cx * 7919u + lx * 131u
                                         + cz * 4001u + lz * 37u);
            ditherSd = ditherSd * 1664525u + 1013904223u;
            float dither = ((float)(ditherSd & 0xFF) / 255.0f) * 0.08f - 0.04f;
            float tN = tempN  + dither;   // dithered temperature proxy
            float hN = humidN + dither;   // dithered humidity proxy

            // ── Biome classification ───────────────────────────────────────
            bool isOcean    = (h <  SEA_LEVEL - 3);
            bool isBeach    = (h >= SEA_LEVEL - 3) && (h <= SEA_LEVEL + 2);
            bool isMidMount = (h >= 42);
            bool isHighPeak = (h >= 54);

            // Volcanic: dramatic uplift + active ridge in warm zone
            bool isVolcanic = (contN > 0.52f && ridgeN > 0.68f
                               && mountMask > 0.30f && tN < 0.10f);
            // Glacier: cold + high peak (tN > 0 = cold in this noise convention)
            bool isGlacier  = (isHighPeak && tN > 0.38f);
            // Badlands: warm + dry + moderate erosion (not extreme peaks)
            bool isBadlands = (tN < -0.32f && hN < -0.20f && h < 48);

            uint8_t surfBlock;
            if (isGlacier) {
                surfBlock = BLOCK_ICE;
            } else if (isVolcanic) {
                surfBlock = BLOCK_BASALT;
            } else if (isHighPeak) {
                // Above snow line: stone in warm, snow in cold
                surfBlock = (tN > 0.0f) ? BLOCK_SNOW : BLOCK_COBBLE;
            } else if (isMidMount) {
                // Mid-altitude: cobble in rugged zones, snow in cold
                if (tN > 0.28f)        surfBlock = BLOCK_SNOW;
                else if (erosion < 0.4f) surfBlock = BLOCK_COBBLE;
                else                    surfBlock = BLOCK_STONE;
            } else if (isBeach) {
                // All beaches are plain sand (v20: red sand moved to badlands)
                surfBlock = BLOCK_SAND;
            } else if (isBadlands) {
                // Badlands: warm + arid → red sand or sand depending on aridity
                surfBlock = (hN < -0.42f) ? BLOCK_RED_SAND : BLOCK_SAND;
            } else if (tN > 0.40f) {
                // Cold flat biome
                surfBlock = BLOCK_SNOW;
            } else {
                // Temperate: grass everywhere else (wet/dry variation via tree density)
                surfBlock = BLOCK_GRASS;
            }

            // ── Block fill ─────────────────────────────────────────────────
            bool mountainZone = (h >= 42);
            bool sandSurf     = (surfBlock == BLOCK_SAND || surfBlock == BLOCK_RED_SAND);
            // Clay in humid shores near sea level
            bool hasClay = (humidN > 0.28f
                            && h >= SEA_LEVEL - 2
                            && h <= SEA_LEVEL + 4);

            for (int ly = 0; ly < CHUNK_H; ++ly) {
                uint8_t bt = BLOCK_AIR;

                if (ly == 0) {
                    bt = BLOCK_STONE;
                } else if (ly <= h - 4) {
                    bt = isVolcanic ? BLOCK_BASALT : BLOCK_STONE;
                } else if (ly <= h - 1) {
                    if (sandSurf)          bt = surfBlock;
                    else if (hasClay)      bt = BLOCK_CLAY;
                    else if (mountainZone) bt = BLOCK_STONE;
                    else                   bt = BLOCK_DIRT;
                } else if (ly == h) {
                    bt = surfBlock;
                } else if (ly <= SEA_LEVEL && h < SEA_LEVEL) {
                    // Water or ice: glacial zones and deep cold oceans freeze
                    bt = (isGlacier || (h < SEA_LEVEL - 6 && tN > 0.32f))
                            ? BLOCK_ICE : BLOCK_WATER;
                }
                setBlock(lx, ly, lz, bt);
            }

            // ── Trees (grass biome; trunk must be TREE_BORDER from edge) ──
            if (surfBlock == BLOCK_GRASS
                && h < CHUNK_H - 10
                && lx >= TREE_BORDER && lx < CHUNK_W - TREE_BORDER
                && lz >= TREE_BORDER && lz < CHUNK_D - TREE_BORDER)
            {
                unsigned seed = (unsigned)(cx * 7919 + lx * 131 + cz * 4001 + lz * 37);
                seed = seed * 1664525u + 1013904223u;

                // Tree density: wet biomes denser, cold biomes sparser
                unsigned treeThresh;
                if (humidN > 0.30f && tN < 0.15f) treeThresh = 24u;      // rainforest
                else if (humidN > 0.10f)           treeThresh = 12u;      // temperate
                else                               treeThresh =  6u;      // dry grassland

                if ((seed & 0xFF) < treeThresh) {
                    int treeH = 4 + (int)((seed >> 8) & 3);  // 4–7 blocks

                    // Trunk
                    for (int ty = h + 1; ty <= h + treeH && ty < CHUNK_H; ++ty)
                        setBlock(lx, ty, lz, BLOCK_WOOD);

                    // 5-layer ellipsoidal canopy with probabilistic border thinning
                    static const float LEAF_RSQ[5] = {
                        1.5f,  // dy=-2  lower skirt
                        5.0f,  // dy=-1  lower canopy
                        5.5f,  // dy= 0  widest band
                        4.5f,  // dy=+1  upper canopy
                        1.5f,  // dy=+2  cap
                    };
                    int top = h + treeH;
                    for (int dyIdx = 0; dyIdx < 5; ++dyIdx) {
                        int ly2 = top + (dyIdx - 2);
                        if (ly2 < 0 || ly2 >= CHUNK_H) continue;
                        float maxRsq = LEAF_RSQ[dyIdx];
                        int   maxR   = (int)sqrtf(maxRsq) + 1;
                        for (int dx = -maxR; dx <= maxR; ++dx) {
                            for (int dz2 = -maxR; dz2 <= maxR; ++dz2) {
                                float distSq = (float)(dx * dx + dz2 * dz2);
                                if (distSq > maxRsq + 0.5f) continue;
                                if (distSq > maxRsq - 0.5f) {
                                    unsigned ls = seed
                                        ^ (unsigned)(dx * 37 + dz2 * 53 + (dyIdx - 2) * 97);
                                    ls = ls * 1664525u + 1013904223u;
                                    if ((ls & 3) == 0) continue;
                                }
                                int lx2 = lx + dx, lz3 = lz + dz2;
                                if (lx2 >= 0 && lx2 < CHUNK_W &&
                                    lz3 >= 0 && lz3 < CHUNK_D)
                                    if (getBlock(lx2, ly2, lz3) == BLOCK_AIR)
                                        setBlock(lx2, ly2, lz3, BLOCK_LEAVES);
                            }
                        }
                    }
                }
            }

            // ── Cactus (hot dry biomes, never at chunk edge) ───────────────
            if ((surfBlock == BLOCK_SAND || surfBlock == BLOCK_RED_SAND)
                && h < CHUNK_H - 5
                && lx >= 1 && lx < CHUNK_W - 1
                && lz >= 1 && lz < CHUNK_D - 1)
            {
                unsigned cs = (unsigned)(cx * 3571 + lx * 211 + cz * 6131 + lz * 103);
                cs = cs * 1664525u + 1013904223u;
                if ((cs & 0xFF) < 5u) {
                    int cH = 2 + (int)((cs >> 8) & 1);
                    for (int ty = h + 1; ty <= h + cH && ty < CHUNK_H; ++ty)
                        setBlock(lx, ty, lz, BLOCK_CACTUS);
                }
            }

            // ── Gravel pockets (subsurface) ────────────────────────────────
            {
                unsigned seed2 = (unsigned)(cx * 1231 + lx * 53 + cz * 9973 + lz * 73);
                seed2 = seed2 * 1664525u + 1013904223u;
                if ((seed2 & 0xFF) < 20u) {
                    int gy = 2 + (int)((seed2 >> 8) & 15);
                    if (gy < h - 4) setBlock(lx, gy, lz, BLOCK_GRAVEL);
                }
            }
        }
    }

    generated.store(true, std::memory_order_release);
    for (int ci = 0; ci < CLUSTER_STACK; ++ci) {
        clusterState[ci].store(ClusterState::DIRTY, std::memory_order_release);
        clusterDirtyGen[ci]++;
    }
}

// ── Extract 16³ voxels for cluster ci ─────────────────────────────────────────
void Chunk::extractClusterVoxels(int ci, uint8_t out[CL_VOLUME]) const {
    const int baseY = ci * CL_SIZE;
    for (int z = 0; z < CL_SIZE; ++z) {
        for (int y = 0; y < CL_SIZE; ++y) {
            const uint8_t* src = &blocks[0 + CHUNK_W * ((baseY + y) + CHUNK_H * z)];
            uint8_t*       dst = &out[0 + CL_SIZE * (y + CL_SIZE * z)];
            memcpy(dst, src, CL_SIZE);
        }
    }
}

// ── Build cluster mesh ─────────────────────────────────────────────────────────
void Chunk::buildClusterMesh(int ci,
                               const Chunk* nxC, const Chunk* pxC,
                               const Chunk* nzC, const Chunk* pzC)
{
    static thread_local uint8_t selfVox[CL_VOLUME];
    static thread_local uint8_t nxVox[CL_VOLUME], pxVox[CL_VOLUME];
    static thread_local uint8_t nyVox[CL_VOLUME], pyVox[CL_VOLUME];
    static thread_local uint8_t nzVox[CL_VOLUME], pzVox[CL_VOLUME];

    extractClusterVoxels(ci, selfVox);

    NeighbourVoxels nb;
    if (nxC && nxC->generated.load(std::memory_order_acquire))
        { nxC->extractClusterVoxels(ci, nxVox); nb.nx = nxVox; }
    if (pxC && pxC->generated.load(std::memory_order_acquire))
        { pxC->extractClusterVoxels(ci, pxVox); nb.px = pxVox; }
    if (nzC && nzC->generated.load(std::memory_order_acquire))
        { nzC->extractClusterVoxels(ci, nzVox); nb.nz = nzVox; }
    if (pzC && pzC->generated.load(std::memory_order_acquire))
        { pzC->extractClusterVoxels(ci, pzVox); nb.pz = pzVox; }
    if (ci > 0)               { extractClusterVoxels(ci - 1, nyVox); nb.ny = nyVox; }
    if (ci < CLUSTER_STACK-1) { extractClusterVoxels(ci + 1, pyVox); nb.py = pyVox; }

    std::vector<PackedFace> localFaces;
    ClusterMesher::buildCluster(selfVox, nb, localFaces);

    {
        std::lock_guard<std::mutex> lock(clusterMutex[ci]);
        clusterFaces[ci] = std::move(localFaces);
    }
    clusterState[ci].store(ClusterState::MESHED, std::memory_order_release);
}

// ── AABB ───────────────────────────────────────────────────────────────────────
void Chunk::getAABB(float& mnX, float& mnY, float& mnZ,
                     float& mxX, float& mxY, float& mxZ) const {
    mnX = (float)(cx * CHUNK_W); mnY = 0.f;            mnZ = (float)(cz * CHUNK_D);
    mxX = mnX + CHUNK_W;         mxY = (float)CHUNK_H; mxZ = mnZ + CHUNK_D;
}
