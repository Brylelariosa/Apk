# HZCM VoxelGame — Engineering Change Log (v19 → v20)

---

## v20 Change Summary

Five independent improvement areas, all backward-compatible with the v19 architecture.

---

### 1 · Renderer.cpp — Shader block-colour LUT: 10 → 16 types

**Root cause:** The vertex shader `BLOCK_COL` array had 30 entries (10 block types × 3
face groups). The v19 terrain system introduced six new block types (`RED_SAND=10`,
`CLAY=11`, `ICE=12`, `CACTUS=13`, `BASALT=14`, `COBBLE=15`) but the shader still
used `clamp(btype, 0, 9)` — clamping all new blocks to type 9 (GRAVEL), rendering
badlands, glaciers, volcanic peaks and cactus in uniform grey.

**Fix:** Expand `BLOCK_COL` to 48 entries (16 types × 3). Update clamp:

```glsl
// Before:
const vec3 BLOCK_COL[30] = ...  // 10 types
int colIdx = clamp(btype, 0, 9) * 3 + faceGroup;

// After (v20):
const vec3 BLOCK_COL[48] = ...  // 16 types
int colIdx = clamp(btype, 0, 15) * 3 + faceGroup;
```

New colours: RED_SAND (terracotta), CLAY (pale blue-grey), ICE (bright cyan-white),
CACTUS (vivid green), BASALT (near-black volcanic), COBBLE (warm grey scree).

---

### 2 · World.cpp — Reduce GPU residency thrashing at high render distances

**Root cause A:** `GPU_UNLOAD_MARGIN = 8` meant GPU pages were freed for any chunk
beyond `RD + 8`. At RD=60 the eviction boundary sat inside the player's view frustum
on diagonal axes. Moving diagonally caused a continuous evict → DIRTY → rebuild →
re-upload cycle for chunks that were still visible, producing invisible terrain.

**Fix:** Increase margin 8 → 12. Eviction now fires at `RD + 12`, giving a 12-chunk
wide stable hysteresis band beyond the render edge.

```cpp
// Before:
static constexpr int GPU_UNLOAD_MARGIN = 8;

// After (v20):
static constexpr int GPU_UNLOAD_MARGIN = 12;
```

**Root cause B:** The DIRTY-cluster watchdog ran every 180 frames (~3 s at 60 fps).
The alloc-fail race that strands clusters could happen on any GPU-pressure frame,
leaving invisible terrain visible for up to 3 s before recovery.

**Fix:** Halve watchdog interval 180 → 90 frames (~1.5 s).

```cpp
// Before:
if (m_frameCount % 180 == 7) { ...watchdog... }

// After (v20):
if (m_frameCount % 90 == 7) { ...watchdog... }
```

---

### 3 · Chunk.cpp — Terrain generation: performance + quality

#### 3a Performance (noise call reduction)

The v19 terrain generator ran ~24 `noise2D` calls per column (256 columns per chunk).
The biggest waste was a redundant *mountain-peak warp* (4 separate `fbm` calls for
`pwox/pwoz`) that added only minor geological variation at the cost of ~33% of all
noise work.

Removed the peak warp; ridged noise now uses the same primary warp as the broad
landscape. This is geologically more coherent (mountain chains curl with the same
large-scale deformation as surrounding terrain) and saves ~8 noise calls per column.

Additional octave reductions: continent 4→3, erosion 3→2, ridge 4→3, detail 3→2.

| Noise call | Before | After | Saved |
|---|---|---|---|
| Primary warp (×2) | 4 | 4 | 0 |
| Peak warp (×2) | 4 | 0 | **4** |
| Continent fbm | 4 | 3 | 1 |
| Erosion fbm | 3 | 2 | 1 |
| Ridge fbmRidged | 4 | 3 | 1 |
| Detail fbm | 3 | 2 | 1 |
| Climate (×2) | 2 | 2 | 0 |
| **Total** | **24** | **16** | **8 (33%)** |

#### 3b Terrain quality

| Parameter | Before | After | Effect |
|---|---|---|---|
| Mountain height multiplier | ×26 | ×42 | Dramatic peaks, visible from far |
| Detail noise amplitude | ±3 blocks | ±2 blocks | Less chaotic jitter |
| Valley carve threshold | 0.55 | 0.45 | Wider, deeper river basins |
| Valley carve multiplier | ×12 | ×18 | Stronger valley definition |
| Continent frequency | 0.0035 | 0.003 | Larger landmasses |
| Ridge frequency | 0.012 | 0.010 | Wider mountain ranges |
| Warp frequency | 0.0015 | 0.0012 | Larger organic curves |
| Sea level | 24 | 26 | Slightly deeper oceans |

New: **plateau detection** — high-erosion + elevated-continent zones produce broad
flat highlands, breaking the "every chunk is rolling hills" pattern.

#### 3c Biome improvements

- **Biome border dithering:** each column samples a per-position noise value (±0.04)
  that offsets its temperature/humidity threshold. This creates a 3–4 column wide
  naturally-dithered blend band instead of a hard straight edge at biome boundaries.
- **Beaches always sand** — removed the v19 behaviour where warm beaches were red sand
  (red sand is now exclusively a badlands feature).
- **Badlands classification improved** — now correctly requires warm + arid + not-too-high,
  producing distinct red-sand mesa regions far from beach areas.
- **Glacier fix** — cold peaks now more reliably produce ice; cold threshold lowered
  from 0.45 to 0.38 (accounts for the noise convention where higher values = colder).
- **Tree density tiers** — three density classes: rainforest (24/256), temperate (12/256),
  dry grassland (6/256), driven by humidity + temperature together.

---

### 4 · DebugOverlay.h + jni_bridge.cpp — Freeze / snapshot system

**Root cause:** The debug overlay polled live stats every 250 ms, making values
constantly change and impossible to read carefully or copy completely.

**Fix:** Added a freeze/snapshot mechanism:

- `freezeSnapshot()` atomically captures the current `WorldDebugStats` into a
  separate `m_frozenStats` buffer protected by the existing `m_statsMtx`.
- `getFrozenOrLiveStats()` returns the frozen snapshot when frozen, live stats
  otherwise — Java can use a single code path for both modes.
- `unfreeze()` exits freeze mode; live stats resume immediately.

Four new JNI functions in `jni_bridge.cpp`:

```cpp
nativeFreezeDebugStats()   // capture snapshot
nativeUnfreezeDebugStats() // resume live
nativeIsFrozen()           // query state
nativeGetFrozenStats()     // get formatted frozen report
```

The frozen snapshot contains all engine state at the capture instant: every cluster
state count, queue depths, GPU usage, thermal state, timing averages — identical
format to `nativeGetDebugStats()`, so existing copy/save flows work unchanged.

---

### 5 · MainActivity.java + GameSurfaceView.java — FRZ button

**Root cause:** "copied debug only captures visible text" — users had no way to
freeze the panel before copy, and the constantly-updating text made it impossible
to read mid-scroll.

**Fix:** Added a **FRZ** button immediately left of the DBG button.

- **Tap FRZ (unfrozen):** calls `nativeFreezeDebugStats()`, captures the full report
  to `debugFrozenText`, switches panel to show `"⏸ FROZEN\n<snapshot>"`. Button
  turns amber, label becomes `▶`.
- **Tap FRZ (frozen):** calls `nativeUnfreezeDebugStats()`, clears the snapshot,
  resumes live 250 ms polling. Button returns to dark green.
- **Long-press DBG while frozen:** action menu shows the frozen text for Copy/Save,
  guaranteeing you copy the exact snapshot you captured — not a different live frame.
- **Close panel:** automatically unfreezes so the next open starts fresh.

Layout positions (top-right, NDC offsets from right edge):
- RD button: 12 dp
- DBG button: 106 dp
- FRZ button: 164 dp (new, hidden when panel is closed)

---

## Files changed

| File | Change |
|---|---|
| `Renderer.cpp` | BLOCK_COL LUT 30→48 entries; clamp fix |
| `Chunk.cpp` | generate() rewrite: noise perf + terrain quality |
| `World.cpp` | GPU_UNLOAD_MARGIN 8→12; watchdog 180→90 frames |
| `DebugOverlay.h` | freezeSnapshot / unfreeze / getFrozenOrLiveStats |
| `jni_bridge.cpp` | 4 new freeze JNI functions |
| `GameSurfaceView.java` | 4 new native method declarations |
| `MainActivity.java` | FRZ button; toggleDebugFreeze(); freeze-aware poll |
