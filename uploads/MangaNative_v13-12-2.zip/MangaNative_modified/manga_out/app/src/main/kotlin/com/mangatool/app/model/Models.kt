package com.mangatool.app.model

import java.io.File

/**
 * A single manga image stored as a temp file on disk instead of RAM.
 *
 * Keeping raw ByteArrays in AppState causes severe GC pressure — a 30-image
 * chapter at 300 KB/image = 9 MB of heap permanently. BitmapFactory.decodeFile()
 * streams from disk without allocating a ByteArray at all, so only the decoded
 * Bitmap pixels hit the heap (managed by the LruCache).
 */
data class ImageItem(
    val originalIdx: Int,
    /** Absolute path to the temp file on disk. */
    val filePath: String,
    val ext: String,
    /** File size in bytes — cached so stats don't need a disk read. */
    val size: Int,
    var name: String = "",
    var userDeleted: Boolean = false,
    var forceKeep: Boolean = false,
    var filterReason: String? = null,
    val width: Int = 0,
    val height: Int = 0
) {
    /** Read raw bytes from disk. Prefer filePath-based BitmapUtils APIs where possible. */
    fun readBytes(): ByteArray = File(filePath).readBytes()

    // Reference identity — two ImageItems from different groups can share
    // the same originalIdx and must never compare as equal.
    override fun equals(other: Any?) = this === other
    override fun hashCode() = System.identityHashCode(this)
}

data class ImageGroup(
    val groupName: String,
    val allImages: MutableList<ImageItem> = mutableListOf(),
    var displayImages: List<ImageItem> = emptyList(),
    var filteredImages: List<ImageItem> = emptyList(),
    /** Pair indices where the two images are swapped (right shown on left). */
    val pairSwaps: MutableSet<Int> = mutableSetOf(),
    /** The URI string this group was loaded from (empty for loose images).
     *  Used to un-register from seenUris when the group is removed, so the
     *  same file can be re-imported without triggering a false duplicate. */
    val sourceUri: String = ""
)
