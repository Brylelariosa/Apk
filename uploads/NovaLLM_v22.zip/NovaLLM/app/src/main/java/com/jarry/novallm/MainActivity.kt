package com.jarry.novallm

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    companion object {
        init {
            System.loadLibrary("novallm_core")
        }
    }

    external fun nativeRunMathCoreTest(): String
    external fun nativeRunTokenizerTest(): String
    external fun nativeRunEmbeddingTest(): String
    external fun nativeRunTransformerTest(): String
    external fun nativeRunDecoderTest(): String
    external fun nativeRunRuntimeTest(cacheDir: String): String
    external fun nativeRunTrainingTest(): String
    external fun nativeRunMiniTrainingDemo(): String
    external fun nativeRunFullTrainingDemo(corpusText: String, cacheDir: String): String
    external fun nativeRunScaledTrainingDemo(corpusText: String): String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val resultView = TextView(this).apply {
            text = "NovaLLM \u2014 tap a button to run its on-device tests."
            textSize = 14f
            setPadding(32, 32, 32, 32)
        }

        val mathButton = Button(this).apply {
            text = "Run Math Core Test"
            setOnClickListener {
                resultView.text = try {
                    nativeRunMathCoreTest()
                } catch (e: Throwable) {
                    "Native call failed: ${e.message}"
                }
            }
        }

        val tokenizerButton = Button(this).apply {
            text = "Run Tokenizer Test"
            setOnClickListener {
                resultView.text = try {
                    nativeRunTokenizerTest()
                } catch (e: Throwable) {
                    "Native call failed: ${e.message}"
                }
            }
        }

        val embeddingButton = Button(this).apply {
            text = "Run Embedding Test"
            setOnClickListener {
                resultView.text = try {
                    nativeRunEmbeddingTest()
                } catch (e: Throwable) {
                    "Native call failed: ${e.message}"
                }
            }
        }

        val transformerButton = Button(this).apply {
            text = "Run Transformer Test"
            setOnClickListener {
                resultView.text = try {
                    nativeRunTransformerTest()
                } catch (e: Throwable) {
                    "Native call failed: ${e.message}"
                }
            }
        }

        val decoderButton = Button(this).apply {
            text = "Run Decoder Test"
            setOnClickListener {
                resultView.text = try {
                    nativeRunDecoderTest()
                } catch (e: Throwable) {
                    "Native call failed: ${e.message}"
                }
            }
        }

        val runtimeButton = Button(this).apply {
            text = "Run Runtime Test"
            setOnClickListener {
                resultView.text = try {
                    nativeRunRuntimeTest(cacheDir.absolutePath)
                } catch (e: Throwable) {
                    "Native call failed: ${e.message}"
                }
            }
        }

        val trainingButton = Button(this).apply {
            text = "Run Training Test"
            setOnClickListener {
                resultView.text = try {
                    nativeRunTrainingTest()
                } catch (e: Throwable) {
                    "Native call failed: ${e.message}"
                }
            }
        }

        val miniTrainingButton = Button(this).apply {
            text = "Run Mini Training Demo"
            setOnClickListener {
                resultView.text = "Training... (a few hundred steps, may take a moment)"
                // Genuinely off the main thread, not just deferred a frame -
                // this can run long enough on real hardware to risk an ANR
                // if it blocked the UI thread.
                Thread {
                    val result = try {
                        nativeRunMiniTrainingDemo()
                    } catch (e: Throwable) {
                        "Native call failed: ${e.message}"
                    }
                    runOnUiThread { resultView.text = result }
                }.start()
            }
        }

        val fullTrainingButton = Button(this).apply {
            text = "Run Full Training Demo"
            setOnClickListener {
                resultView.text = "Training on the bundled corpus... may take a few seconds"
                Thread {
                    val result = try {
                        val corpusText = assets.open("training_corpus.txt")
                            .bufferedReader().use { it.readText() }
                        nativeRunFullTrainingDemo(corpusText, cacheDir.absolutePath)
                    } catch (e: Throwable) {
                        "Couldn't read training_corpus.txt from assets, or native call " +
                            "failed: ${e.message}"
                    }
                    runOnUiThread { resultView.text = result }
                }.start()
            }
        }

        val scaledTrainingButton = Button(this).apply {
            text = "Run Scaled Training Demo"
            setOnClickListener {
                resultView.text = "Training a larger model on a larger corpus... this is " +
                    "meaningfully bigger than the other demos and timing varies a lot by " +
                    "device - could take anywhere from under a minute to several minutes"
                Thread {
                    val result = try {
                        val corpusText = assets.open("training_corpus_large.txt")
                            .bufferedReader().use { it.readText() }
                        nativeRunScaledTrainingDemo(corpusText)
                    } catch (e: Throwable) {
                        "Couldn't read training_corpus_large.txt from assets, or native call " +
                            "failed: ${e.message}"
                    }
                    runOnUiThread { resultView.text = result }
                }.start()
            }
        }

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(mathButton)
            addView(tokenizerButton)
            addView(embeddingButton)
            addView(transformerButton)
            addView(decoderButton)
            addView(runtimeButton)
            addView(trainingButton)
            addView(miniTrainingButton)
            addView(fullTrainingButton)
            addView(scaledTrainingButton)
            addView(resultView)
        }

        setContentView(ScrollView(this).apply { addView(layout) })
    }
}
