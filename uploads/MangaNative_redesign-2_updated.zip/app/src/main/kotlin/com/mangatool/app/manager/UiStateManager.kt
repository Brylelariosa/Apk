package com.mangatool.app.manager

import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import android.view.View
import com.bumptech.glide.Glide
import com.mangatool.app.AppMode
import com.mangatool.app.AppState
import com.mangatool.app.R
import com.mangatool.app.databinding.ActivityMainBinding
import com.mangatool.app.util.Prefs

/**
 * Single source of truth for MainActivity's ambient screen-chrome state:
 * progress/loading indicators, tab styling, the settings panel, filter-row
 * enablement, folder labels, and the cached stats that drive the main
 * "N chapters, M images, X MB" summary line.
 *
 * This app doesn't have a grid/list toggle or a search bar — MainActivity's
 * only real "which UI mode are we in" surface is Extract-vs-Merge (tabs) and
 * has-content-vs-empty (drop zone vs chapter list) — both handled here, in
 * one place, instead of being flipped ad hoc wherever a click happened to
 * land.
 */
class UiStateManager(
    private val activity: AppCompatActivity,
    private val b: ActivityMainBinding
) {

    // ── Scroll state ──────────────────────────────────────────────────────────
    // true while RecyclerView is in SCROLL_STATE_SETTLING (active fling).
    //
    // WHY THIS EXISTS:
    //   After extraction, preCacheShareUris() fires at the 10 s mark and runs
    //   N×buildShareUris() calls — each one copies image files to a share-cache
    //   directory. On slow eMMC (common on budget devices), these copy IOs compete
    //   with Glide thumbnail reads on the same storage bus, stalling cover loads
    //   and dropping frames. The effect is the characteristic micro-lag that
    //   "feels like background work competing with scrolling."
    //
    // HOW IT HELPS:
    //   FileManager checks this flag before each background IO burst and
    //   suspends (via awaitScrollIdle()) during flings, releasing the storage
    //   bus to Glide.
    //
    // @Volatile ensures the flag is visible across threads (read from
    // FileManager's background coroutines) without synchronization.
    @Volatile var isScrollingFast: Boolean = false
        private set

    // ── Cached stats ──────────────────────────────────────────────────────────
    // refreshUI() used to run three .sumOf passes over all groups × all images
    // (3 × 50 groups × 30 images = 4 500 iterations) on every call — including
    // on every filter-slider drag tick. These fields are updated once after
    // applyFilters() and reused for all subsequent refreshUI() calls until
    // the next filter change.
    private var cachedTotalImgs:     Int  = 0
    private var cachedTotalFiltered: Int  = 0
    private var cachedTotalKb:       Long = 0L

    fun updateCachedStats() {
        cachedTotalImgs     = AppState.groups.sumOf { it.displayImages.size }
        cachedTotalFiltered = AppState.groups.sumOf { it.filteredImages.size }
        cachedTotalKb       = AppState.groups.sumOf { g -> g.displayImages.sumOf { it.size.toLong() } } / 1024
    }

    // ── Refresh UI ─────────────────────────────────────────────────────────────
    fun refreshUI() {
        val hasGroups = AppState.groups.isNotEmpty()
        val isMerge   = AppState.currentMode == AppMode.MERGE

        b.dropZone.visibility    = if (hasGroups) View.GONE    else View.VISIBLE
        b.chapterList.visibility = if (hasGroups) View.VISIBLE else View.GONE
        b.actionBar.visibility   = if (hasGroups) View.VISIBLE else View.GONE
        b.mergeTip.visibility    = if (isMerge && hasGroups) View.VISIBLE else View.GONE

        if (hasGroups) {
            // Buttons are icon-only now — keep their accessible labels in sync
            // with mode instead of visible text.
            b.btnDownload.contentDescription = if (isMerge) "Save Images" else activity.getString(R.string.btn_save)
            b.btnAddMore.contentDescription  = if (isMerge) activity.getString(R.string.btn_add_images) else activity.getString(R.string.btn_add_more)
        }

        if (isMerge && hasGroups) {
            val total = cachedTotalImgs
            b.mergeImageCount.text = activity.getString(R.string.merge_image_count, total, (total + 1) / 2)
        }

        if (hasGroups) {
            val totalImgs     = cachedTotalImgs
            val totalFiltered = cachedTotalFiltered
            val totalKb       = cachedTotalKb
            val sizeStr       = if (totalKb > 1024) "%.1f MB".format(totalKb / 1024.0) else "${totalKb} KB"
            b.statsText.text = if (isMerge) {
                activity.getString(R.string.stats_merge, AppState.groups.size, totalImgs, (totalImgs + 1) / 2, sizeStr)
            } else if (totalFiltered > 0) {
                activity.getString(R.string.stats_extract_filtered, AppState.groups.size, totalImgs, sizeStr, totalFiltered)
            } else {
                activity.getString(R.string.stats_extract, AppState.groups.size, totalImgs, sizeStr)
            }
        }
    }

    // ── Tabs / settings panel ──────────────────────────────────────────────────
    fun applyTabStyle(mode: AppMode) {
        val active   = 0xFFFFFFFF.toInt()
        val inactive = 0xFF9090B0.toInt()
        if (mode == AppMode.EXTRACT) {
            b.tabExtract.setBackgroundResource(R.drawable.bg_tab_active); b.tabExtract.setTextColor(active)
            b.tabMerge.setBackgroundResource(android.R.color.transparent); b.tabMerge.setTextColor(inactive)
        } else {
            b.tabMerge.setBackgroundResource(R.drawable.bg_tab_active); b.tabMerge.setTextColor(active)
            b.tabExtract.setBackgroundResource(android.R.color.transparent); b.tabExtract.setTextColor(inactive)
        }
    }

    fun hideSettingsPanel() { b.settingsPanel.visibility = View.GONE }

    fun toggleSettingsPanel() {
        b.settingsPanel.visibility =
            if (b.settingsPanel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
    }

    // ── Filters row ────────────────────────────────────────────────────────────
    fun updateSizeLabel() { b.sizeLabel.text = activity.getString(R.string.size_kb, AppState.minSizeKb) }

    /** Dims and disables the min-width/min-height inputs when the dimension filter is off. */
    fun setMinDimsRowEnabled(enabled: Boolean) {
        b.rowMinDims.alpha        = if (enabled) 1f else 0.4f
        b.minWidthInput.isEnabled  = enabled
        b.minHeightInput.isEnabled = enabled
    }

    // ── Folder labels ──────────────────────────────────────────────────────────
    fun updateSettingsFolderLabels() {
        val eName = Prefs.extractFolderName
        b.tvExtractFolderName.text = eName ?: activity.getString(R.string.folder_not_set)
        b.btnClearExtractFolder.visibility = if (eName != null) View.VISIBLE else View.GONE

        val mName = Prefs.mergeFolderName
        b.tvMergeFolderName.text = mName ?: activity.getString(R.string.folder_not_set)
        b.btnClearMergeFolder.visibility = if (mName != null) View.VISIBLE else View.GONE
    }

    // ── PERF: Pause Glide decoding during fling ────────────────────────────
    // ROOT CAUSE of "lag while scrolling" on low-end devices:
    //   During a finger-driven scroll, Glide fires one or more disk-read +
    //   BitmapFactory.decode tasks for each new VH that enters the viewport.
    //   On a device with slow eMMC (budget phones), a single disk read for a
    //   ~5–7 KB WebP thumbnail can take 2–8 ms. If 3 new rows enter view in one
    //   frame (common during a medium-speed fling), Glide issues 3 simultaneous
    //   disk reads on the IO dispatcher. The reads stall each other on the eMMC
    //   bus AND compete with the RecyclerView layout work on the Main thread.
    //   The combined 16 ms frame budget is blown and a frame drop occurs.
    //
    // FIX: During a FLING (SCROLL_STATE_SETTLING), pause Glide.
    //   • pauseRequestsRecursive() — NEW Glide requests are queued, not issued.
    //     In-flight requests already reading from disk complete normally.
    //   • When the list settles (SCROLL_STATE_IDLE), resumeRequestsRecursive()
    //     drains the queue in one burst. By then, the fling physics are resolved
    //     and RecyclerView has a predictable, stable set of visible items.
    //   • Cost to pause: ~0 ms (atomic flag). Cost to resume: 1 batch of reads
    //     against an otherwise idle eMMC bus — fast.
    //
    // During finger drag (SCROLL_STATE_DRAGGING): do NOT pause.
    //   • Dragging is slow and interactive; the user pauses at items they care
    //     about. Pausing would make covers pop in with a jarring delay during
    //     deliberate, slow scrolling. Only fast flings cause the disk contention.
    fun attachScrollPerfListener(recyclerView: RecyclerView) {
        recyclerView.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(rv: RecyclerView, newState: Int) {
                when (newState) {
                    RecyclerView.SCROLL_STATE_SETTLING -> {
                        // Fling started — pause disk reads to protect the frame budget,
                        // and signal background IO jobs to suspend via isScrollingFast.
                        isScrollingFast = true
                        Glide.with(activity).pauseRequestsRecursive()
                    }
                    RecyclerView.SCROLL_STATE_IDLE -> {
                        // List came to rest — drain queued thumbnail requests and allow
                        // background pre-cache work to resume its next IO batch.
                        isScrollingFast = false
                        Glide.with(activity).resumeRequestsRecursive()
                    }
                    RecyclerView.SCROLL_STATE_DRAGGING ->
                        // Finger drag — Glide stays live for responsive cover loading.
                        // Clear the fling flag so precache resumes during slow drags.
                        isScrollingFast = false
                }
            }
        })
    }
}
