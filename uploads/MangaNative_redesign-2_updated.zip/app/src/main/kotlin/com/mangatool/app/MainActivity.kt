package com.mangatool.app

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.mangatool.app.adapter.ChapterAdapter
import com.mangatool.app.adapter.ChapterDragCallback
import com.mangatool.app.databinding.ActivityMainBinding
import com.mangatool.app.manager.FileManager
import com.mangatool.app.manager.NavigationController
import com.mangatool.app.manager.UiStateManager
import com.mangatool.app.model.ImageGroup
import com.mangatool.app.util.ImageSaver
import com.mangatool.app.util.Prefs
import com.mangatool.app.util.ThumbnailWorker
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Collections

/**
 * Coordinator for the Extract/Merge chapter-list screen.
 *
 * MainActivity itself only:
 *   • owns the Activity lifecycle and the chapter-list RecyclerView/adapter,
 *   • wires UI events to the three collaborators below,
 *   • builds ChapterAdapter's callback set (the one place that legitimately
 *     needs both AppState and the adapter reference at once).
 *
 * All the actual business logic lives in:
 *   • [FileManager]          — import, save, share, rename, folder persistence.
 *   • [NavigationController] — activity-result launchers, screen routing, intents.
 *   • [UiStateManager]       — progress/tabs/settings-panel/stats chrome.
 *
 * See each class's KDoc for why the code that used to live here moved there.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private var chapterAdapter: ChapterAdapter? = null
    private var chapterTouchHelper: ItemTouchHelper? = null

    private lateinit var uiState: UiStateManager
    private lateinit var fileManager: FileManager
    private lateinit var navigationController: NavigationController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        Prefs.init(this)
        AppState.minSizeKb    = Prefs.minSizeKb
        AppState.excludeGifs  = Prefs.excludeGifs
        AppState.reverseOrder = Prefs.reverseOrder
        AppState.imgCacheDir  = File(cacheDir, "img_cache")

        // Construction order matters: FileManager and NavigationController both
        // register ActivityResultLaunchers in their init, which must happen
        // unconditionally before this Activity leaves CREATED — doing it here,
        // synchronously in onCreate, satisfies that exactly like the original
        // flat field declarations did. NavigationController depends on
        // FileManager (it routes picked files/folders into it), so it's built
        // last.
        uiState = UiStateManager(this, b)
        fileManager = FileManager(
            activity = this,
            b = b,
            uiState = uiState,
            refreshChapterList = ::refreshChapterList,
            onGroupDimsDecoded = ::onGroupDimsDecoded
        )
        navigationController = NavigationController(
            activity = this,
            fileManager = fileManager,
            uiState = uiState,
            onPreviewClosed = ::applyFiltersAndRefresh
        )

        setupTabs()
        setupControls()
        setupActionBar()
        setupDragToReorder()
        applyMode(AppMode.EXTRACT)
        navigationController.handleIncomingShareIntent(intent)
        fileManager.scheduleStaleCacheCleanup()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        navigationController.handleIncomingShareIntent(intent)
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        Glide.get(this).trimMemory(level) // Glide shrinks bitmap pool + memory cache under pressure
    }

    override fun onDestroy() {
        fileManager.onDestroy()
        super.onDestroy()
    }

    // ── Tabs ───────────────────────────────────────────────────────────────────
    private fun setupTabs() {
        b.tabExtract.setOnClickListener { applyMode(AppMode.EXTRACT) }
        b.tabMerge.setOnClickListener   { applyMode(AppMode.MERGE) }
    }

    private fun applyMode(mode: AppMode) {
        AppState.currentMode = mode
        uiState.applyTabStyle(mode)
        // Close settings when switching mode; destroy adapter so it rebuilds
        // with the correct isMerge flag from AppState.currentMode.
        uiState.hideSettingsPanel()
        chapterAdapter?.destroy(); chapterAdapter = null
        applyFiltersAndRefresh()
    }

    // ── Controls ───────────────────────────────────────────────────────────────
    private fun setupControls() {
        // Settings toggle — one panel, both modes
        b.settingsToggle.setOnClickListener { uiState.toggleSettingsPanel() }

        // Extract folder
        b.btnSetExtractFolder.setOnClickListener { navigationController.launchExtractFolderPicker() }
        b.btnClearExtractFolder.setOnClickListener { fileManager.clearExtractFolder() }

        // Merge folder
        b.btnSetMergeFolder.setOnClickListener { navigationController.launchMergeFolderPicker() }
        b.btnClearMergeFolder.setOnClickListener { fileManager.clearMergeFolder() }

        uiState.updateSettingsFolderLabels()

        // Extract filters
        b.sizeSlider.progress = AppState.minSizeKb
        uiState.updateSizeLabel()
        b.sizeSlider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, v: Int, user: Boolean) {
                AppState.minSizeKb = v; Prefs.minSizeKb = v; uiState.updateSizeLabel()
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) { AppState.invalidateAllFilters(); applyFiltersAndRefresh() }
        })
        b.toggleGifs.isChecked    = AppState.excludeGifs
        b.toggleReverse.isChecked = AppState.reverseOrder
        b.toggleGifs.setOnCheckedChangeListener    { _, c -> AppState.excludeGifs = c;  Prefs.excludeGifs = c;  AppState.invalidateAllFilters(); applyFiltersAndRefresh() }
        b.toggleReverse.setOnCheckedChangeListener { _, c -> AppState.reverseOrder = c; Prefs.reverseOrder = c; AppState.invalidateAllFilters(); applyFiltersAndRefresh() }

        // Min dimensions filter — off by default; user types values and flips the switch.
        AppState.minWidth       = Prefs.minWidth
        AppState.minHeight      = Prefs.minHeight
        AppState.minDimsEnabled = Prefs.minDimsEnabled
        if (AppState.minWidth  > 0) b.minWidthInput.setText(AppState.minWidth.toString())
        if (AppState.minHeight > 0) b.minHeightInput.setText(AppState.minHeight.toString())
        b.toggleMinDims.isChecked = AppState.minDimsEnabled
        uiState.setMinDimsRowEnabled(AppState.minDimsEnabled)

        b.toggleMinDims.setOnCheckedChangeListener { _, c ->
            AppState.minDimsEnabled = c; Prefs.minDimsEnabled = c
            uiState.setMinDimsRowEnabled(c)
            AppState.invalidateAllFilters(); applyFiltersAndRefresh()
        }

        fun commitMinWidth() {
            val v = b.minWidthInput.text.toString().toIntOrNull()?.coerceAtLeast(0) ?: 0
            if (v != AppState.minWidth) {
                AppState.minWidth = v; Prefs.minWidth = v
                AppState.invalidateAllFilters(); applyFiltersAndRefresh()
            }
        }
        fun commitMinHeight() {
            val v = b.minHeightInput.text.toString().toIntOrNull()?.coerceAtLeast(0) ?: 0
            if (v != AppState.minHeight) {
                AppState.minHeight = v; Prefs.minHeight = v
                AppState.invalidateAllFilters(); applyFiltersAndRefresh()
            }
        }
        // Apply on focus-lost (tapping elsewhere) and on IME "Done" — avoids
        // re-filtering on every keystroke while still catching every real edit.
        b.minWidthInput.setOnFocusChangeListener  { _, hasFocus -> if (!hasFocus) commitMinWidth() }
        b.minHeightInput.setOnFocusChangeListener { _, hasFocus -> if (!hasFocus) commitMinHeight() }
        b.minWidthInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) { commitMinWidth(); true } else false
        }
        b.minHeightInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) { commitMinHeight(); true } else false
        }

        b.dropZone.setOnClickListener { navigationController.showFileManagerChooser() }
        val llm = LinearLayoutManager(this)
        llm.initialPrefetchItemCount = 5
        b.chapterList.layoutManager = llm
        b.chapterList.setItemViewCacheSize(20)   // doubled: keeps more VHs warm off-screen
        // Disable overscroll glow — removes a composition layer that causes jank
        b.chapterList.overScrollMode = View.OVER_SCROLL_NEVER
        // Null out the item animator entirely.
        // The previous setting (supportsChangeAnimations = false) only disabled
        // CHANGE animations. INSERT animations were still active: when
        // b.chapterList.adapter = chapterAdapter fires with 50 groups, RecyclerView
        // schedules a ValueAnimator fade for every visible item — each ValueAnimator
        // posts invalidate() every 16 ms until the animation completes (~300 ms).
        // With 5–7 visible chapters that is 5–7 simultaneous ValueAnimators firing
        // on the first scroll, directly competing with Glide thumbnail loads in
        // the same frame budget.
        // null = no DefaultItemAnimator, no alpha/translate, no ValueAnimator overhead.
        b.chapterList.itemAnimator = null

        // Scroll-perf listener (pause Glide during fling) — see UiStateManager
        // for the full rationale; this was previously ~55 lines inline here.
        uiState.attachScrollPerfListener(b.chapterList)
    }

    private fun setupActionBar() {
        b.btnAddMore.setOnClickListener     { navigationController.showFileManagerChooser() }
        b.btnDownload.setOnClickListener    { fileManager.onSaveClicked() }
        b.btnShareDirect.setOnClickListener { fileManager.startShareAll() }
        b.btnViewAll.setOnClickListener     { if (AppState.groups.isNotEmpty()) startActivity(Intent(this, AllPhotosActivity::class.java)) }
        b.btnReset.setOnClickListener {
            fileManager.cancelActiveImport() // stop any in-progress file loading
            chapterAdapter?.destroy(); chapterAdapter = null
            b.chapterList.adapter = null
            AppState.resetAll()  // also deletes cached image temp files
            ThumbnailWorker.clearCache()  // clear worker path cache after reset
            Glide.get(this).clearMemory()
            fileManager.invalidateShareCache()
            ImageSaver.clearShareCache(this)
            uiState.updateCachedStats()
            lifecycleScope.launch { refreshChapterList() }
        }
    }

    private fun setupDragToReorder() {
        val callback = ChapterDragCallback(context = this) { from, to ->
            Collections.swap(AppState.groups, from, to)
            chapterAdapter?.notifyItemMoved(from, to)
        }
        chapterTouchHelper = ItemTouchHelper(callback).also { it.attachToRecyclerView(b.chapterList) }
    }

    // ── Chapter list / filters ───────────────────────────────────────────────────
    /**
     * Run applyFilters on Dispatchers.Default (never block the main thread),
     * then call refreshChapterList() back on Main.
     * All filter toggle/slider/delete callers use this instead of calling
     * applyFilters() inline — eliminates all UI jank on filter changes.
     */
    private fun applyFiltersAndRefresh() {
        lifecycleScope.launch {
            withContext(Dispatchers.Default) { AppState.applyFilters() }
            uiState.updateCachedStats()
            refreshChapterList()
        }
    }

    private suspend fun refreshChapterList() {
        // Reuse the existing adapter (and its coroutine scope + warm thumbnail cache)
        // instead of destroying + recreating it on every small action.
        if (chapterAdapter != null) {
            chapterAdapter?.update()
            uiState.refreshUI()
            return
        }
        chapterAdapter = ChapterAdapter(
            groups           = AppState.groups,
            onImageClick     = { gIdx, iIdx -> navigationController.launchImagePreview(gIdx, iIdx) },
            onGroupRemove    = { idx ->
                val removed = AppState.groups.getOrNull(idx)
                AppState.groups.removeAt(idx)
                removed?.let { group ->
                    chapterAdapter?.destroyGroupAdapters(group.id)
                    if (group.sourceUri.isNotBlank()) AppState.seenUris.remove(group.sourceUri)
                }
                applyFiltersAndRefresh()
            },
            onGroupShare     = { idx -> fileManager.shareGroup(idx) },
            onGroupRename    = { idx -> fileManager.renameGroup(idx) },
            onImageLongClick = { img -> img.userDeleted = true; img.forceKeep = false; AppState.invalidateAllFilters(); applyFiltersAndRefresh() },
            onImageRestore   = { img -> img.forceKeep = true; img.userDeleted = false; AppState.invalidateAllFilters(); applyFiltersAndRefresh() },
            onFilteredPreview = { gIdx, filtIdx -> navigationController.launchFilteredImagePreview(gIdx, filtIdx) },
            onBatchRestore   = { gIdx ->
                AppState.groups.getOrNull(gIdx)?.allImages?.forEach { if (!it.userDeleted) it.forceKeep = true }
                applyFiltersAndRefresh()
                Toast.makeText(this, getString(R.string.toast_restored_all), Toast.LENGTH_SHORT).show()
            },
            // Lazy dims decode: only runs when the user expands a chapter.
            // launchDimsDecodeForGroup() is idempotent (no-op if already decoded).
            onGroupExpand    = { group -> fileManager.launchDimsDecodeForGroup(group) }
        )
        b.chapterList.adapter = chapterAdapter
        chapterAdapter?.touchHelper = chapterTouchHelper
        uiState.refreshUI()
    }

    /** Callback from FileManager once a per-group dims-decode pass finishes:
     *  push the updated image list into the inner adapter (AsyncListDiffer
     *  diffs off Main — no blocking; only items whose dims changed are
     *  rebound) and refresh stats/chapter list. */
    private suspend fun onGroupDimsDecoded(group: ImageGroup) {
        chapterAdapter?.refreshGroupDisplayImages(group)
        uiState.updateCachedStats()
        refreshChapterList()
    }
}
