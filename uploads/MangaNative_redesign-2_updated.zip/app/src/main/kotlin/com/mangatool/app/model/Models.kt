package com.mangatool.app.model

import java.io.File
import java.util.concurrent.atomic.AtomicLong

/**
 * A single manga image stored as a temp file on disk instead of RAM.
 *
 * Keeping raw ByteArrays in AppState causes severe GC pressure — a 30-image
 * chapter at 300 KB/image = 9 MB of heap permanently. BitmapFactory.decodeFile()
 * streams from disk without allocating a ByteArray at all, so only the decoded
 * Bitmap pixels hit the heap (managed by the LruCache).
 *
 * v21: thumbnailPath added — absolute path to the pre-generated WebP thumbnail
 * written by MhtmlParser immediately after extraction. RecyclerView adapters
 * load ONLY the thumbnail file; the original extracted image is never touched
 * during scrolling, eliminating all runtime resize / BitmapFactory cost in lists.
 */
data class ImageItem(
    val originalIdx: Int,
    /** Absolute path to the full-resolution temp file on disk. Never loaded in lists. */
    val filePath: String,
    val ext: String,
    /** File size in bytes — cached so stats don't need a disk read. */
    val size: Int,
    var name: String = "",
    var userDeleted: Boolean = false,
    var forceKeep: Boolean = false,
    var filterReason: String? = null,
    val width: Int = 0,
    val height: Int = 0,
    /**
     * Absolute path to the pre-generated WebP lossy thumbnail
     * (see MhtmlParser.THUMBNAIL_TARGET_PX for the current target resolution).
     * Null only for ImageItems created from loose files / picker imports that
     * bypassed MhtmlParser (e.g. MergeImagePickerActivity). In that case the
     * adapter falls back to filePath with Glide's own resize, which is
     * acceptable because the picker list is small and non-scrolling.
     */
    val thumbnailPath: String? = null
) {
    /** Read raw bytes from disk. Prefer filePath-based BitmapUtils APIs where possible. */
    fun readBytes(): ByteArray = File(filePath).readBytes()

    // Reference identity — two ImageItems from different groups can share
    // the same originalIdx and must never compare as equal.
    override fun equals(other: Any?) = this === other
    override fun hashCode() = System.identityHashCode(this)
}

/**
 * Lightweight descriptor for a merge pair — passed to PreviewPagerAdapter
 * instead of a pre-decoded Bitmap, so full-resolution merge bitmaps are
 * decoded lazily (one page at a time) rather than all at once on startup.
 */
data class MergePairDescriptor(val pair: List<ImageItem>, val swapped: Boolean)

data class ImageGroup(
    var groupName: String,
    val allImages: MutableList<ImageItem> = mutableListOf(),
    var displayImages: List<ImageItem> = emptyList(),
    var filteredImages: List<ImageItem> = emptyList(),
    /** Pair indices where the two images are swapped (right shown on left). */
    val pairSwaps: MutableSet<Int> = mutableSetOf(),
    /** The URI string this group was loaded from (empty for loose images).
     *  Used to un-register from seenUris when the group is removed, so the
     *  same file can be re-imported without triggering a false duplicate. */
    var sourceUri: String = ""
) {
    /**
     * Stable 64-bit identity assigned at construction time.
     *
     * Declared as a body (non-constructor) property so it is excluded from
     * data-class equals / hashCode / copy / toString. Two copies produced by
     * copy() will have different ids, which is intentional: copy() creates a
     * distinct group and should get its own stable id.
     *
     * Used by ChapterAdapter to key thumbAdapters/filteredAdapters by group
     * identity rather than RecyclerView position, so drag-to-reorder never
     * shows the wrong thumbnails.
     */
    val id: Long = idCounter.getAndIncrement()

    companion object {
        private val idCounter = AtomicLong(0L)
    }
}
