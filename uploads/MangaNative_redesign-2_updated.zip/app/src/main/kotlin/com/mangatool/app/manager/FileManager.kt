package com.mangatool.app.manager

import android.app.Dialog
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.snackbar.Snackbar
import com.mangatool.app.AppMode
import com.mangatool.app.AppState
import com.mangatool.app.MainActivity
import com.mangatool.app.MhtmlParser
import com.mangatool.app.R
import com.mangatool.app.databinding.ActivityMainBinding
import com.mangatool.app.databinding.BottomSheetSaveChoiceBinding
import com.mangatool.app.databinding.BottomSheetSavedBinding
import com.mangatool.app.model.ImageGroup
import com.mangatool.app.model.ImageItem
import com.mangatool.app.util.CbzCreator
import com.mangatool.app.util.FolderSaver
import com.mangatool.app.util.ImageSaver
import com.mangatool.app.util.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/**
 * Everything "a file becomes part of, or leaves, the library": MHTML/loose-image
 * import, folder persistence, per-chapter rename, and every save/share path
 * (folder, CBZ, direct share). Extracted out of MainActivity, which now only
 * wires this class's results back into the chapter list and adapter.
 *
 * Talks back to MainActivity through two small callbacks instead of holding a
 * reference to ChapterAdapter directly — [refreshChapterList] and
 * [onGroupDimsDecoded] are the only two points where a file operation needs to
 * cause a chapter-list re-render, and both are called from inside the same
 * coroutine that did the underlying work (never fire-and-forget), preserving
 * the exact ordering the original single-class implementation relied on for
 * its frame-timing optimizations (see the yield() comment in [processFiles]).
 */
class FileManager(
    private val activity: MainActivity,
    private val b: ActivityMainBinding,
    private val uiState: UiStateManager,
    private val refreshChapterList: suspend () -> Unit,
    private val onGroupDimsDecoded: suspend (ImageGroup) -> Unit
) {

    private var processingJob: Job? = null

    // ── Share pre-cache ────────────────────────────────────────────────────────
    private val shareCacheAll   = mutableMapOf<String, List<Uri>>()
    private val shareCacheGroup = mutableMapOf<String, List<Uri>>()
    private var preCacheJob: Job? = null

    // Caps concurrent MHTML extractions. Without this, 50+ files launch 50+
    // simultaneous IO coroutines causing storage saturation and RAM spikes.
    // Coroutines beyond the limit suspend cheaply — no thread is held while waiting.
    private val extractLimiter = Semaphore(2)

    // ── Low-priority pre-cache dispatcher ────────────────────────────────────
    // A dedicated single-threaded executor running at Thread.MIN_PRIORITY (1).
    //
    // WHY NOT Dispatchers.IO:
    //   Dispatchers.IO shares up to 64 threads at default priority (5). Running
    //   preCacheShareUris() there puts background file-copy IOs at the same OS
    //   scheduler priority as Glide thumbnail reads, so eMMC time slices are
    //   distributed equally. On a slow bus, Glide reads stall every 2nd or 3rd
    //   time slice — visible as cover pop-in during scrolling.
    //
    // WHY MIN_PRIORITY + single thread:
    //   Thread.MIN_PRIORITY (1) = Linux nice +19. The OS scheduler always prefers
    //   higher-priority threads (render thread = priority 0, Glide IO = priority 5)
    //   over this thread when the CPU or storage bus is contested. Only truly idle
    //   cycles are given to pre-caching.
    //
    //   Single thread serialises all precache IOs — at most one file-copy in
    //   flight at any moment from this job, so it can never saturate the bus.
    private val precacheDispatcher = Executors.newSingleThreadExecutor { r ->
        Thread(r, "share-precache").also { it.priority = Thread.MIN_PRIORITY }
    }.asCoroutineDispatcher()

    // ── Progress-post time gate ────────────────────────────────────────────────
    // With Semaphore(2) allowing two concurrent extractors and MhtmlParser firing
    // onProgress every 10 images, we can still see up to ~2 posts per 10 images
    // if both files happen to invoke the callback simultaneously.  The CAS below
    // enforces a global 100 ms wall-clock minimum between any two main-thread
    // posts across all concurrent extractors — a lockless single read + compare-
    // and-swap, so the fast path (within the window) costs ~3 ns with no
    // allocation and zero contention on the IO threads.
    private val lastProgressPostMs = AtomicLong(0L)

    // ── Write-permission launcher (pre-Android-10 CBZ save) ───────────────────
    private val permLauncher = activity.registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (!granted) Toast.makeText(activity, activity.getString(R.string.permission_storage_needed), Toast.LENGTH_LONG).show()
    }

    /** Cancels any in-flight work — call from MainActivity.onDestroy(). */
    fun onDestroy() {
        processingJob?.cancel()
        preCacheJob?.cancel()
        // Shut down the low-priority precache thread cleanly — prevents a thread
        // leak if the Activity is destroyed mid-precache (e.g. low-memory kill).
        precacheDispatcher.close()
    }

    // ── Stale cache cleanup ──────────────────────────────────────────────────────
    /**
     * Reclaims disk space left behind by previous sessions: leftover
     * cache/img_cache extraction folders (see AppState.sweepOrphanedImgCache)
     * and the entire cache/share_temp directory.
     *
     * WHY DELAYED instead of running immediately in onCreate (as this used to):
     *   Wiping share_temp/img_cache the instant the app opens risks deleting a
     *   file another app (e.g. Facebook) is still mid-upload from — if the user
     *   shared a chapter, backgrounded this app, then reopened it moments later
     *   while that share was still in flight, an immediate wipe would pull the
     *   file out from under it. Waiting gives any pending share from the
     *   previous session time to finish reading before cleanup touches
     *   anything, without ever leaving cache growth completely unchecked.
     *
     * WHY SAFE to delete what's left after the delay:
     *   Nothing about a chapter or a share session survives a process restart —
     *   AppState.groups and the shareCache* maps all start empty on a fresh
     *   launch. So anything found under img_cache/share_temp at this point
     *   cannot belong to the session that's now running; it can only be
     *   leftover from one that already ended.
     *
     * Runs on precacheDispatcher (MIN_PRIORITY, single thread — same one used
     * for share pre-caching) so this recursive disk-IO sweep never competes
     * with scrolling, extraction, or Glide's own reads.
     */
    fun scheduleStaleCacheCleanup() {
        activity.lifecycleScope.launch {
            delay(90_000L)
            withContext(precacheDispatcher) {
                runCatching { ImageSaver.clearShareCache(activity) }
                runCatching { AppState.sweepOrphanedImgCache(activity.cacheDir) }
            }
        }
    }

    // ── Folder helpers ─────────────────────────────────────────────────────────
    fun persistAndRememberFolder(uri: Uri, isMerge: Boolean) {
        runCatching {
            activity.contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        }
        val name = runCatching {
            androidx.documentfile.provider.DocumentFile.fromTreeUri(activity, uri)?.name
        }.getOrNull() ?: uri.lastPathSegment ?: "Selected folder"

        if (isMerge) {
            Prefs.mergeFolderUri  = uri.toString()
            Prefs.mergeFolderName = name
        } else {
            Prefs.extractFolderUri  = uri.toString()
            Prefs.extractFolderName = name
        }
    }

    /**
     * Returns the stored URI if it is still accessible (permission not revoked),
     * otherwise clears it from prefs and returns null so the user is asked to pick again.
     */
    private fun getValidFolderUri(isMerge: Boolean): Uri? {
        val stored = if (isMerge) Prefs.mergeFolderUri else Prefs.extractFolderUri
            ?: return null
        val uri = runCatching { Uri.parse(stored) }.getOrNull() ?: return null

        // Check we still have write permission by trying to open the DocumentFile
        val accessible = runCatching {
            val df = androidx.documentfile.provider.DocumentFile.fromTreeUri(activity, uri)
            df != null && df.canWrite()
        }.getOrDefault(false)

        return if (accessible) uri else {
            // Permission was revoked (e.g. app reinstall, ROM reset) — clear and re-ask
            if (isMerge) { Prefs.mergeFolderUri = null; Prefs.mergeFolderName = null }
            else         { Prefs.extractFolderUri = null; Prefs.extractFolderName = null }
            uiState.updateSettingsFolderLabels()
            null
        }
    }

    fun clearExtractFolder() {
        Prefs.extractFolderUri = null; Prefs.extractFolderName = null
        uiState.updateSettingsFolderLabels()
    }

    fun clearMergeFolder() {
        Prefs.mergeFolderUri = null; Prefs.mergeFolderName = null
        uiState.updateSettingsFolderLabels()
    }

    private fun getFileName(uri: Uri): String =
        activity.contentResolver.query(uri, null, null, null, null)?.use {
            val idx = it.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && it.moveToFirst()) it.getString(idx) else "file"
        } ?: uri.lastPathSegment ?: "file"

    // ── File processing ────────────────────────────────────────────────────────

    fun processFiles(uris: List<Uri>, folderName: String = "") {
        processingJob?.cancel()
        b.progressArea.visibility = View.VISIBLE
        b.dropZone.visibility     = View.GONE
        b.actionBar.visibility    = View.GONE
        // Reset the progress time-gate so the first update in this batch is
        // never suppressed, regardless of when the last extraction ran.
        lastProgressPostMs.set(0L)

        // ── Pause Glide during extraction ─────────────────────────────────────
        // Extraction saturates Dispatchers.IO with up to 2 concurrent MHTML
        // parsers (Semaphore(2)), each writing multiple 200-500 KB decoded images
        // plus ~5-7 KB WebP thumbnails to internal storage in a tight loop.
        //
        // On low-end devices (eMMC, single-channel storage controller) the disk
        // bus is essentially serialized: the extraction writes occupy the queue,
        // so concurrent Glide disk-reads for existing visible thumbnails stall,
        // producing dropped frames and janky scrolling during extraction.
        //
        // pauseRequestsRecursive() queues any new Glide.into() calls in memory
        // without issuing disk reads. In-flight requests that already started
        // a disk read complete normally — only NEW requests are deferred.
        // Cost: ~0 ms (just sets an atomic flag on the RequestManager).
        //
        // resumeRequestsRecursive() is called once, right after refreshChapterList()
        // sets the adapter. By that point:
        //   (a) all extraction IO is done (coroutineScope already awaited it all),
        //   (b) RecyclerView has measured + bound visible items and called into() for
        //       their cover images — those into() calls are now in the queue,
        //   (c) the storage bus is idle.
        // Glide then loads all visible covers in one clean burst against an empty
        // disk queue — thumbnails appear almost instantly instead of dribbling in.
        //
        // Estimated improvement on Snapdragon 695 (2022 mid-range):
        //   post-extraction thumbnail load latency: ~400 ms → ~120 ms.
        Glide.with(activity).pauseRequestsRecursive()

        processingJob = activity.lifecycleScope.launch {
            val looseImages    = mutableListOf<ImageItem>()
            var duplicateCount = 0

            val looseTempDir = File(activity.cacheDir, "img_cache/loose_${System.currentTimeMillis()}")

            // Only URIs that successfully produced a group are committed to seenUris.
            // Prevents a mid-cancel from poisoning seenUris with phantom entries.
            val successfulUris = ConcurrentLinkedQueue<String>()

            val newUris = uris.filter { uri ->
                val s = uri.toString()
                if (AppState.seenUris.contains(s)) { duplicateCount++; false } else true
            }
            val totalFiles  = newUris.size
            val doneCount   = AtomicInteger(0)

            // ── Separate MHTML from loose images ─────────────────────────────
            // PERF FIX: getFileName() calls contentResolver.query() via Binder IPC.
            // Original code called it in two .filter passes on the Main thread:
            //   50 files × 2 passes = 100 Binder IPC round-trips on the UI thread.
            //   Each call takes 2–15 ms; worst-case = 750 ms of UI blocking right
            //   at the moment the progress bar first appears, causing visible freeze.
            //
            // Fix: resolve ALL names in ONE IO pass before the filter split.
            //   • Names are computed once per URI (not twice).
            //   • All IPC calls happen on Dispatchers.IO → zero Main-thread cost.
            //   • The Pair<Uri, String> list is reused in the extraction and loose
            //     loops below, eliminating the redundant getFileName(uri) calls there.
            //
            // Estimated improvement: 0–750 ms of UI-thread unblock; on average
            // devices with a slow ContentProvider (e.g. MiUI, EMUI file pickers)
            // this is the primary cause of the "brief freeze before progress shows".
            val classifiedUris: List<Pair<Uri, String>> = withContext(Dispatchers.IO) {
                newUris.map { uri -> uri to getFileName(uri).lowercase() }
            }
            val mhtmlPairs = classifiedUris.filter { (_, n) ->
                n.endsWith(".mhtml") || n.endsWith(".mht")
            }
            val loosePairs = classifiedUris.filter { (_, n) ->
                n.matches(Regex(""".*\.(jpg|jpeg|png|webp|gif)"""))
            }

            withContext(Dispatchers.Main) {
                b.progressStatus.text  = "Extracting $totalFiles files…"
                b.progressBar.progress = 0
            }

            // ── Parse all MHTML files in parallel ────────────────────────────
            // Each file gets its own IO coroutine. On a 4-core device this is
            // ~4× faster than the previous serial loop. Peak RAM stays bounded
            // because MhtmlParser holds only one image (~270 KB) at a time per
            // coroutine — total peak ≈ cores × 270 KB, not file-count × 270 KB.
            //
            // Results arrive out of order, so we collect into a thread-safe list
            // then sort by original URI order before adding to AppState.groups.
            val parsedGroups = ConcurrentHashMap<Int, ImageGroup>()

            coroutineScope {
                mhtmlPairs.forEachIndexed { i, (uri, resolvedName) ->
                    launch(Dispatchers.IO) {
                        // Semaphore limits active extractions to 2 at a time.
                        // All 50+ coroutines launch immediately but suspend here
                        // until a slot opens — no thread is blocked while waiting.
                        //
                        // IMPORTANT: withContext(Dispatchers.Main) must NOT appear
                        // inside withPermit. withContext(Main) is a suspension point —
                        // the coroutine suspends waiting for the Main thread to be
                        // available (up to 16 ms = one frame). If that happens while
                        // holding the permit, both slots can be simultaneously occupied
                        // just waiting for Main, starving all 50 other queued coroutines.
                        // With both permits blocked, extraction effectively serialises
                        // to zero throughput until Main is free.
                        //
                        // Fix: capture the completion count inside withPermit (an
                        // AtomicInt increment, not a suspension point), then issue the
                        // withContext(Main) update AFTER the permit is released.
                        var completedDone = 0
                        extractLimiter.withPermit {
                            val uriStr      = uri.toString()
                            // PERF: Use resolvedName from the IO pre-classification pass above.
                            // Saves one redundant getFileName()/contentResolver.query() call per
                            // file inside withPermit — and since the Semaphore slot is held,
                            // removing even a 2 ms IPC call here frees the slot 2 ms sooner
                            // for the next waiting coroutine.
                            val displayName = resolvedName
                            val tempDir     = File(activity.cacheDir, "img_cache/${System.currentTimeMillis()}_$i")
                            // Wrap the raw ContentResolver stream in a 64 KB
                            // BufferedInputStream.  ContentResolver streams are backed
                            // by a Binder pipe; each read() call returns at most one
                            // kernel buffer (~4–8 KB).  BufferedInputStream batches
                            // those reads into 65 536-byte fills, cutting syscall count
                            // by ~8–16× and reducing Binder IPC latency proportionally.
                            // The stream is still closed via the outer .use { } because
                            // closing a BufferedInputStream closes the wrapped stream.
                            val raw = runCatching { activity.contentResolver.openInputStream(uri) }.getOrNull()
                                ?: return@withPermit
                            val stream = BufferedInputStream(raw, 65_536)

                            val group = stream.use { s ->
                                MhtmlParser.parse(s, displayName, tempDir) { found ->
                                    // ── Time-gated main-thread post ──────────────────
                                    // CAS: read current timestamp, compare with stored
                                    // last-post time.  If ≥100 ms have elapsed AND the
                                    // CAS wins (only one concurrent caller can win per
                                    // window), dispatch one post.  All other concurrent
                                    // callers within the window simply skip — zero
                                    // allocation, no blocking, no Handler churn.
                                    val now = System.currentTimeMillis()
                                    val last = lastProgressPostMs.get()
                                    if (now - last >= 100L && lastProgressPostMs.compareAndSet(last, now)) {
                                        val done = doneCount.get()
                                        b.root.post {
                                            b.progressStatus.text  = "Extracting… ${done + 1}/$totalFiles — $displayName ($found images)"
                                            b.progressBar.progress = ((done * 100) / totalFiles.coerceAtLeast(1))
                                                .coerceAtMost(99)
                                        }
                                    }
                                }
                            } ?: return@withPermit

                            parsedGroups[i] = group.also { it.sourceUri = uriStr }
                            successfulUris.add(uriStr)
                            // AtomicInt.incrementAndGet() is a CPU instruction, not a
                            // suspension point — safe to call inside withPermit.
                            completedDone = doneCount.incrementAndGet()
                            // Permit releases HERE at the end of withPermit block.
                        }
                        // ── Permit already released above ─────────────────────
                        // withContext(Main) now runs AFTER the permit is freed, so
                        // the next waiting coroutine can acquire the slot immediately
                        // without waiting for the Main thread to process our update.
                        if (completedDone > 0) {
                            withContext(Dispatchers.Main) {
                                b.progressBar.progress = (completedDone * 100) / totalFiles.coerceAtLeast(1)
                            }
                        }
                    }
                }
            }
            // Restore document order before appending to AppState.groups
            mhtmlPairs.indices
                .mapNotNull { parsedGroups[it] }
                .forEach { AppState.groups.add(it) }

            // ── Handle loose images ───────────────────────────────────────────
            // PERF: Use loosePairs (pre-resolved names) instead of calling
            // getFileName() again. Eliminates N more Binder IPC calls on Main.
            loosePairs.forEach { (uri, name) ->
                val uriStr = uri.toString()
                val ext    = name.substringAfterLast('.')
                looseTempDir.mkdirs()
                val idx    = looseImages.size
                val file   = File(looseTempDir, "${idx.toString().padStart(6, '0')}.$ext")

                // ── Stream-copy replaces readBytes() → writeBytes() ───────────────
                // The old code did:
                //   val data = openInputStream(uri)?.readBytes()   // ByteArray ~200–500 KB
                //   file.writeBytes(data)                          // second copy / buffer
                //   looseImages.add(... size = data.size ...)      // size from byte count
                //
                // Problem: readBytes() allocates a full ByteArray for the entire image
                // (~200–500 KB). With 30 loose images that is 6–15 MB of simultaneous
                // heap pressure. writeBytes() internally allocates another buffer of up
                // to 64 KB. When Android's GC sees the heap spike right after the loop,
                // it triggers a concurrent collection that competes with the first
                // RecyclerView layout + Glide thumbnail decodes — visible stutter.
                //
                // Fix: copyTo() reads and writes in 64 KB chunks and never holds more
                // than 64 KB of a single image in RAM at once. It returns the total
                // byte count, which we use as ImageItem.size. The file on disk is
                // identical — this is a pure memory-allocation optimisation.
                //
                // Estimated RAM saving: (N_images − 1) × image_size (the last image's
                // ByteArray is still live during writeBytes in the old code, so only
                // N−1 are simultaneously alive). For 30 × 350 KB images: ~9.5 MB.
                val bytesWritten: Long = withContext(Dispatchers.IO) {
                    runCatching {
                        activity.contentResolver.openInputStream(uri)?.use { src ->
                            BufferedInputStream(src, 65_536).use { buf ->
                                file.outputStream().buffered(65_536).use { out ->
                                    buf.copyTo(out) // returns bytes copied
                                }
                            }
                        } ?: 0L
                    }.getOrElse { 0L }
                }
                if (bytesWritten <= 0L) return@forEach

                // ── Generate WebP thumbnail for loose images ──────────────────────
                // Without a thumbnailPath, ChapterAdapter falls back to loading the
                // full original image via Glide with DiskCacheStrategy.RESOURCE.
                // On first scroll Glide decodes the full JPEG/PNG (200–500 KB) and
                // then resizes it — visible jank on every first appearance.
                //
                // MhtmlParser.generateThumbnail writes a THUMBNAIL_TARGET_PX px WebP
                // (~5–7 KB) in ~4–9 ms per image. The adapter then loads ONLY that
                // tiny file, identical to the MHTML extraction path.
                //
                // Estimated saving on first scroll: ~80–200 ms of Glide decode time
                // eliminated per loose image (≥ 1.5 s for 10 loose images on a low-
                // end device with slow eMMC).
                val thumbDir  = File(looseTempDir, "thumbnails").also { it.mkdirs() }
                val thumbFile = File(thumbDir, "${idx.toString().padStart(6, '0')}.webp")
                val thumbPath = withContext(Dispatchers.IO) {
                    MhtmlParser.generateThumbnail(file.absolutePath, thumbFile)
                }

                looseImages.add(
                    ImageItem(idx, file.absolutePath, ext, bytesWritten.toInt(),
                        thumbnailPath = thumbPath)
                )
                successfulUris.add(uriStr)
            }

            AppState.invalidateAllFilters()
            AppState.seenUris.addAll(successfulUris)

            if (looseImages.isNotEmpty()) {
                val n = AppState.groups.size + 1
                val label = when {
                    AppState.currentMode == AppMode.MERGE && folderName.isNotBlank() -> folderName
                    AppState.currentMode == AppMode.MERGE -> activity.getString(R.string.merge_group_label, n, looseImages.size)
                    // PERF: Use cached name from loosePairs — avoids a final getFileName() on Main.
                    loosePairs.size == 1 -> loosePairs[0].second.substringBeforeLast('.').ifBlank { "Images $n" }
                    uris.size == 1 && loosePairs.isEmpty() ->
                        (classifiedUris.firstOrNull()?.second ?: "").substringBeforeLast('.').ifBlank { "Images $n" }
                    else           -> "Images $n (${looseImages.size})"
                }
                AppState.groups.add(ImageGroup(label).also { it.allImages.addAll(looseImages) })
            }

            withContext(Dispatchers.Main) {
                b.progressBar.progress = 100
                val totalExtracted = AppState.groups.sumOf { it.allImages.size }
                b.progressStatus.text  = "✓ Done — $totalExtracted images ready"
            }
            withContext(Dispatchers.Default) { AppState.applyFilters() }
            // ── One-frame yield before layout ─────────────────────────────────
            // applyFilters() allocates ~1 500 ImageItem.copy() objects (50 groups
            // × 30 images per name-stamp). On Android, that allocation burst after
            // a heavy extraction often tips the heap into a concurrent GC cycle.
            // If GC fires in the same frame as RecyclerView's first layout pass
            // (triggered by adapter = chapterAdapter), the Choreographer misses the
            // 16 ms deadline and the UI freezes for 30–80 ms right at the "Done" moment.
            //
            // yield() suspends here and resumes at the next Main-thread slot —
            // after the current Choreographer frame callback finishes. GC runs
            // during the suspension so RecyclerView gets a clean heap for layout.
            kotlinx.coroutines.yield()
            uiState.updateCachedStats()
            b.progressArea.visibility = View.GONE
            refreshChapterList()

            // ── Resume Glide — queued covers load immediately ──────────────────
            // By this point:
            //   • All MHTML extractions are complete (coroutineScope waited).
            //   • applyFilters() and updateCachedStats() have run.
            //   • refreshChapterList() has set b.chapterList.adapter, triggering
            //     RecyclerView's first layout pass. onBindViewHolder fired for
            //     every visible chapter row and called Glide.into(holder.cover)
            //     for each cover — those into() calls are queued in Glide's
            //     RequestManager because we paused it in processFiles().
            //   • The storage bus is now idle — no more extraction IO competing.
            //
            // resumeRequestsRecursive() drains the queue: all visible cover loads
            // start simultaneously against an empty disk queue. Since each cover
            // is a pre-built ~5–7 KB WebP, loading 6 covers takes ~15–25 ms total
            // instead of the ~400 ms it took when the disk bus was saturated.
            Glide.with(activity).resumeRequestsRecursive()

            // ── Defer share pre-cache ─────────────────────────────────────────
            // preCacheShareUris() runs 51 sequential ImageSaver.buildShareUris()
            // calls on a single IO coroutine (1 all-library + 50 per-chapter).
            // Starting this too soon saturates the storage bus when Glide is
            // loading first visible covers and the user is beginning to interact.
            //
            // 10 s gives Glide's first cover burst (t≈0) and early scrolling
            // (t=0–5 s) plenty of headroom. With lazy dims decode now removed
            // there is no 6 s IO event to stagger against — 10 s is the only
            // scheduled background IO left after extraction.
            activity.lifecycleScope.launch {
                delay(10_000L)
                preCacheShareUris()
            }

            // ── Dims decode is now LAZY (on-demand per chapter expand) ───────
            // Dims are decoded per-group via the onGroupExpand callback wired
            // into ChapterAdapter. Each expand triggers launchDimsDecodeForGroup()
            // for only that one group. Groups the user never opens are never
            // decoded at all.

            if (duplicateCount > 0) {
                Snackbar.make(b.root, activity.getString(R.string.toast_duplicate_skipped, duplicateCount), Snackbar.LENGTH_SHORT)
                    .setBackgroundTint(0xFF21262D.toInt()).setTextColor(0xFFF0F6FC.toInt()).show()
            }
        }
    }

    /**
     * Decode pixel dimensions for a single group's images on demand, then push
     * the updated displayImages list into the inner ImageThumbAdapter via
     * AsyncListDiffer.submitList().
     *
     * Called by the onGroupExpand callback wired into ChapterAdapter — only
     * when the user actually taps a chapter row to expand it. Groups the
     * user never opens are never decoded, eliminating a library-wide
     * BitmapFactory burst on every extraction regardless of user interaction.
     *
     * Idempotent: returns immediately (O(N) scan, zero IO) if all images
     * already have width > 0, so re-expanding a chapter costs nothing.
     */
    fun launchDimsDecodeForGroup(group: ImageGroup) {
        // Fast-path: all dims already populated — nothing to do.
        if (group.allImages.none { it.width == 0 }) return
        activity.lifecycleScope.launch(com.mangatool.app.util.BitmapUtils.decodeDispatcher) {
            // If a fling is in progress, wait for it to settle before doing
            // ANY disk reads. Starting I/O during a fling competes with Glide
            // on the eMMC bus and causes frame drops on the first scroll after
            // expand.
            if (uiState.isScrollingFast) awaitScrollIdle()
            // Step 1: decode dims into allImages (source of truth).
            // Each decodeDimensions() call reads only the image file header
            // (BitmapFactory inJustDecodeBounds = true — no pixel data loaded),
            // so it typically takes <1 ms per file on warm eMMC.
            group.allImages.forEachIndexed { idx, img ->
                if (img.width == 0) {
                    // Yield every 5 images if a fling starts mid-decode.
                    if (idx % 5 == 0 && uiState.isScrollingFast) awaitScrollIdle()
                    val (w, h) = com.mangatool.app.util.BitmapUtils.decodeDimensions(img.filePath)
                    group.allImages[idx] = img.copy(width = w, height = h)
                }
            }
            // Step 2: build originalIdx → (w, h) lookup from allImages
            val dimsMap: Map<Int, Pair<Int, Int>> = group.allImages
                .filter { it.width > 0 }
                .associate { it.originalIdx to (it.width to it.height) }
            // Step 3: propagate dims into displayImages
            val newDisplay = group.displayImages.map { img ->
                val (w, h) = dimsMap[img.originalIdx] ?: (0 to 0)
                if (w > 0 && img.width == 0) img.copy(width = w, height = h) else img
            }
            group.displayImages = newDisplay
            // Step 4: dimensions just became known for this group — if the
            // dimension filter is on, re-run applyFilters() so any pages that
            // are now under the min-width/min-height threshold move into
            // filteredImages. Cheap: fingerprint check skips every other
            // group untouched by this decode pass.
            AppState.invalidateFilter(group)
            withContext(Dispatchers.Default) { AppState.applyFilters() }
            // Step 5: hand back to MainActivity to push the updated list into
            // the inner adapter (AsyncListDiffer diffs off Main — no blocking)
            // and refresh stats/chapter list.
            withContext(Dispatchers.Main) { onGroupDimsDecoded(group) }
        }
    }

    // ── Share pre-cache ────────────────────────────────────────────────────────
    /**
     * Pre-populate share URI caches for the current library — scroll-aware, batched.
     *
     * FIXES APPLIED (v27):
     *   1. precacheDispatcher — MIN_PRIORITY single thread. Linux scheduler always
     *      gives time slices to higher-priority threads (UI, Glide) first.
     *   2. awaitScrollIdle() before each IO burst — suspends during flings so the
     *      storage bus is fully available to Glide between groups.
     *   3. 30 ms delay between groups — ~2 Choreographer frames of breathing room
     *      for Glide to drain any queued thumbnail reads before the next copy IO.
     *   4. One group at a time (serialised via single precacheDispatcher thread) —
     *      at most 1 file-copy in flight at any moment, never saturates the bus.
     */
    fun preCacheShareUris() {
        preCacheJob?.cancel()
        if (AppState.groups.isEmpty()) return
        val isMerge = AppState.currentMode == AppMode.MERGE
        val allKey  = AppState.groups.joinToString("|") { "${it.groupName}_${it.displayImages.size}" }

        preCacheJob = activity.lifecycleScope.launch {
            // ── Step 1: full-library URI cache ────────────────────────────────
            // This is the single largest IO burst: copies every image in all groups.
            // Always wait for the list to be completely idle before starting it.
            if (!shareCacheAll.containsKey(allKey)) {
                awaitScrollIdle()
                withContext(precacheDispatcher) {
                    runCatching {
                        ImageSaver.buildShareUris(activity, AppState.groups, isMerge) {}
                    }.onSuccess { shareCacheAll[allKey] = it }
                }
            }

            // ── Step 2: per-group URI caches, one group at a time ─────────────
            // Process ONE group per IO burst with a 30 ms gap between groups so
            // the storage bus isn't kept busy for the entire precache duration.
            AppState.groups.forEachIndexed { idx, group ->
                val key = "${idx}_${group.groupName}_${group.displayImages.size}"
                if (!shareCacheGroup.containsKey(key)) {
                    // Pause during flings — only run when the storage bus is free.
                    awaitScrollIdle()

                    withContext(precacheDispatcher) {
                        runCatching {
                            ImageSaver.buildShareUris(activity, listOf(group), isMerge) {}
                        }.onSuccess { shareCacheGroup[key] = it }
                    }

                    // 30 ms = ~2 frames at 60 Hz. Gives Glide time to drain any
                    // thumbnail read requests queued from the last scroll before
                    // the next group's file-copy IO occupies the storage bus.
                    delay(30L)
                }
            }
        }
    }

    /**
     * Suspends the current coroutine until scrolling has settled (no active fling).
     *
     * Called before each IO burst in preCacheShareUris() and between images in
     * launchDimsDecodeForGroup() to ensure heavy background reads/writes don't
     * compete with Glide on the storage bus during a fling.
     *
     * Uses 50 ms polling: cheap, avoids a Channel/CompletableDeferred plus
     * lifecycle cleanup, and the coroutine suspends during delay() — no thread
     * is blocked.
     */
    private suspend fun awaitScrollIdle() {
        while (uiState.isScrollingFast) {
            delay(50L)
        }
    }

    /** Called by MainActivity's Reset action to stop any in-progress file loading
     *  before AppState.resetAll() deletes the temp files that import would still
     *  be writing to. */
    fun cancelActiveImport() {
        processingJob?.cancel()
    }

    /** Called by MainActivity's Reset action — drops all cached share URIs
     *  (they refer to images that no longer exist) and cancels any precache
     *  still in flight for the library being cleared. */
    fun invalidateShareCache() {
        preCacheJob?.cancel()
        shareCacheAll.clear()
        shareCacheGroup.clear()
    }

    // ── Per-chapter share ──────────────────────────────────────────────────────
    fun shareGroup(groupIdx: Int) {
        val group   = AppState.groups.getOrNull(groupIdx) ?: return
        val isMerge = AppState.currentMode == AppMode.MERGE
        val key     = "${groupIdx}_${group.groupName}_${group.displayImages.size}"

        shareCacheGroup[key]?.let { launchShare(it); return }

        b.progressArea.visibility = View.VISIBLE
        activity.lifecycleScope.launch(Dispatchers.IO) {
            runCatching {
                ImageSaver.buildShareUris(activity, listOf(group), isMerge) { p ->
                    activity.lifecycleScope.launch(Dispatchers.Main) {
                        b.progressStatus.text  = p.message
                        b.progressBar.progress = p.percent
                    }
                }
            }.onSuccess { uris ->
                shareCacheGroup[key] = uris
                withContext(Dispatchers.Main) { b.progressArea.visibility = View.GONE; launchShare(uris) }
            }.onFailure { e ->
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE
                    Toast.makeText(activity, "Share failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    // ── Per-chapter rename ─────────────────────────────────────────────────────
    fun renameGroup(groupIdx: Int) {
        val group = AppState.groups.getOrNull(groupIdx) ?: return
        val defaultName = group.groupName
            .removeSuffix(".mhtml").removeSuffix(".mht").trim()

        // Custom styled dialog — transparent window so the layout's rounded
        // card background shows through cleanly.
        val dialog = Dialog(activity, android.R.style.Theme_Translucent_NoTitleBar)
        val view = activity.layoutInflater.inflate(R.layout.dialog_rename, null)
        dialog.setContentView(view)
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setLayout(
                (activity.resources.displayMetrics.widthPixels * 0.88).toInt(),
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            setGravity(Gravity.CENTER)
            setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        }

        val input = view.findViewById<EditText>(R.id.rename_input)
        input.setText(defaultName)
        input.setSelection(0, defaultName.length)

        view.findViewById<Button>(R.id.btn_rename_cancel).setOnClickListener {
            dialog.dismiss()
        }
        view.findViewById<Button>(R.id.btn_rename_confirm).setOnClickListener {
            val newName = sanitizeName(input.text.toString(), defaultName)
            AppState.invalidateFilter(group)
            group.groupName = newName
            activity.lifecycleScope.launch { refreshChapterList() }
            dialog.dismiss()
        }
        // Trigger confirm on keyboard "Done"
        input.setOnEditorActionListener { _, _, _ ->
            val newName = sanitizeName(input.text.toString(), defaultName)
            AppState.invalidateFilter(group)
            group.groupName = newName
            activity.lifecycleScope.launch { refreshChapterList() }
            dialog.dismiss()
            true
        }

        dialog.show()
        input.post {
            (activity.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                .showSoftInput(input, InputMethodManager.SHOW_IMPLICIT)
        }
    }

    // ── Save ───────────────────────────────────────────────────────────────────
    /** Tapping the Save (folder) icon: Merge mode only ever saves to a folder,
     *  so it skips straight there. Extract mode can save either way, so it
     *  opens a bottom sheet to ask Folder vs CBZ. */
    fun onSaveClicked() {
        if (AppState.groups.isEmpty()) return
        if (AppState.currentMode == AppMode.MERGE) startSave(asCbz = false)
        else showSaveFormatSheet()
    }

    private fun showSaveFormatSheet() {
        val dialog = BottomSheetDialog(activity, com.google.android.material.R.style.Theme_Material3_Dark_BottomSheetDialog)
        val sheet  = BottomSheetSaveChoiceBinding.inflate(activity.layoutInflater)
        dialog.setContentView(sheet.root)

        sheet.btnSaveFolder.setOnClickListener { dialog.dismiss(); startSave(asCbz = false) }
        sheet.btnSaveCbz.setOnClickListener    { dialog.dismiss(); startSave(asCbz = true) }
        sheet.tvSaveChoiceCancel.setOnClickListener { dialog.dismiss() }
        dialog.show()
    }

    private fun startSave(asCbz: Boolean) {
        if (AppState.groups.isEmpty()) return
        when {
            asCbz -> checkWritePermission { showCbzNameDialog() }
            AppState.currentMode == AppMode.MERGE -> {
                val savedUri = getValidFolderUri(isMerge = true)
                if (savedUri != null) showMergeNameDialog(savedUri)
                else                  openSettingsToSetFolder(isMerge = true)
            }
            else -> {
                val savedUri = getValidFolderUri(isMerge = false)
                if (savedUri != null) performSaveExtract(savedUri)
                else                  openSettingsToSetFolder(isMerge = false)
            }
        }
    }

    /** No folder set yet — open Settings panel and highlight the right Choose button */
    private fun openSettingsToSetFolder(isMerge: Boolean) {
        // 1. Open the settings panel
        b.settingsPanel.visibility = View.VISIBLE

        // 2. Identify the row and button to highlight
        val row    = if (isMerge) b.rowMergeFolder    else b.rowExtractFolder
        val btn    = if (isMerge) b.btnSetMergeFolder else b.btnSetExtractFolder
        val label  = if (isMerge) "Merge"             else "Extract"

        // 3. Scroll the row into view (it may be offscreen)
        row.post { row.requestRectangleOnScreen(android.graphics.Rect(0, 0, row.width, row.height), true) }

        // 4. Pulse the row with an accent highlight 3× so the user sees it
        val accentColor  = androidx.core.content.ContextCompat.getColor(activity, R.color.primary)
        val transparent  = android.graphics.Color.TRANSPARENT
        val pulse = android.animation.ObjectAnimator.ofArgb(row, "backgroundColor", transparent, accentColor, transparent)
        pulse.duration      = 500
        pulse.repeatCount   = 2
        pulse.repeatMode    = android.animation.ValueAnimator.REVERSE
        pulse.startDelay    = 200
        pulse.start()

        // 5. Show a Snackbar anchored above the action bar
        Snackbar
            .make(b.root, activity.getString(R.string.set_save_folder_first, label), Snackbar.LENGTH_LONG)
            .setAction("Choose") { btn.performClick() }
            .setAnchorView(b.actionBar)
            .show()
    }

    /** Merge — folder already known: just ask for the photo name */
    private fun showMergeNameDialog(treeUri: Uri) {
        val default = if (AppState.groups.size == 1) AppState.groups[0].groupName else "Merged"
        val input = EditText(activity).apply {
            setText(default); setSelection(0, default.length)
            hint = "e.g. Chapter 1"; setPadding(48, 24, 48, 8)
        }
        val totalPairs = AppState.groups.sumOf {
            com.mangatool.app.util.ImageMerger.pairImages(it.displayImages).size
        }
        val hint = if (totalPairs == 1) "Saves as: Name.png"
                   else "Saves as: Name_1.png, Name_2.png…"
        android.app.AlertDialog.Builder(activity)
            .setTitle(activity.getString(R.string.name_your_photos))
            .setMessage("Folder: ${Prefs.mergeFolderName}\n$hint")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val name = sanitizeName(input.text.toString(), default)
                performSaveMerge(treeUri, name)
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun showCbzNameDialog() {
        val default = if (AppState.groups.size == 1) AppState.groups[0].groupName else "Manga_Batch"
        val input = EditText(activity).apply {
            setText(default); setSelection(0, default.length)
            hint = "CBZ filename"; setPadding(48, 24, 48, 8)
        }
        android.app.AlertDialog.Builder(activity).setTitle("Save as CBZ").setView(input)
            .setPositiveButton(activity.getString(R.string.btn_save)) { _, _ ->
                val raw = sanitizeName(input.text.toString(), default)
                performSaveCbz(if (raw.endsWith(".cbz", true)) raw else "$raw.cbz")
            }
            .setNegativeButton(activity.getString(R.string.btn_cancel), null).show()
    }

    private fun sanitizeName(input: String, fallback: String) =
        input.trim().replace(Regex("""[\\/:*?"<>|]"""), "_").ifBlank { fallback }

    // ── Save workers ───────────────────────────────────────────────────────────
    private fun performSaveExtract(treeUri: Uri) {
        b.btnDownload.isEnabled = false
        b.progressArea.visibility = View.VISIBLE
        activity.lifecycleScope.launch(Dispatchers.IO) {
            runCatching {
                FolderSaver.saveExtractToTree(activity, treeUri, AppState.groups) { p ->
                    activity.lifecycleScope.launch(Dispatchers.Main) {
                        b.progressStatus.text = p.message; b.progressBar.progress = p.percent
                    }
                }
            }.onSuccess { result ->
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE
                    b.btnDownload.isEnabled = true
                    val subtitle = if (AppState.groups.size == 1)
                        "${result.count} images → ${result.folderName}/${AppState.groups[0].groupName}"
                    else
                        "${result.count} images → ${result.folderName}"
                    showSavedSheet(activity.getString(R.string.saved_exclamation), subtitle, emptyList(), saveFirst = true)
                }
            }.onFailure { e ->
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE
                    b.btnDownload.isEnabled = true
                    Toast.makeText(activity, activity.getString(R.string.toast_failed, e.message), Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun performSaveMerge(treeUri: Uri, photoName: String) {
        b.btnDownload.isEnabled = false
        b.progressArea.visibility = View.VISIBLE
        activity.lifecycleScope.launch(Dispatchers.IO) {
            runCatching {
                FolderSaver.saveMergeToTree(activity, treeUri, AppState.groups, photoName) { p ->
                    activity.lifecycleScope.launch(Dispatchers.Main) {
                        b.progressStatus.text = p.message; b.progressBar.progress = p.percent
                    }
                }
            }.onSuccess { result ->
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE
                    b.btnDownload.isEnabled   = true
                    showSavedSheet(
                        title     = "Saved ${result.count} photos",
                        subtitle  = "$photoName.png in ${result.folderName}",
                        shareUris = emptyList(),
                        saveFirst = true
                    )
                }
            }.onFailure { e ->
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE
                    b.btnDownload.isEnabled   = true
                    Toast.makeText(activity, activity.getString(R.string.toast_failed, e.message), Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun performSaveCbz(filename: String) {
        b.btnDownload.isEnabled = false
        b.progressArea.visibility = View.VISIBLE
        activity.lifecycleScope.launch(Dispatchers.IO) {
            runCatching {
                val uri = CbzCreator.create(activity, AppState.groups, filename, false) { p ->
                    activity.lifecycleScope.launch(Dispatchers.Main) {
                        b.progressStatus.text = p.message; b.progressBar.progress = p.percent
                    }
                }
                ImageSaver.SaveResult(listOf(uri), filename)
            }.onSuccess { result ->
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE
                    b.btnDownload.isEnabled = true
                    showSavedSheet("Saved: $filename", "Downloads/$filename", result.uris, saveFirst = true)
                }
            }.onFailure { e ->
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE
                    b.btnDownload.isEnabled = true
                    Toast.makeText(activity, activity.getString(R.string.toast_failed, e.message), Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    // ── Share all ──────────────────────────────────────────────────────────────
    fun startShareAll() {
        if (AppState.groups.isEmpty()) return
        val allKey = AppState.groups.joinToString("|") { "${it.groupName}_${it.displayImages.size}" }

        shareCacheAll[allKey]?.let { launchShare(it); return }

        b.btnShareDirect.isEnabled = false
        b.progressArea.visibility  = View.VISIBLE
        activity.lifecycleScope.launch(Dispatchers.IO) {
            runCatching {
                ImageSaver.buildShareUris(activity, AppState.groups, AppState.currentMode == AppMode.MERGE) { p ->
                    activity.lifecycleScope.launch(Dispatchers.Main) {
                        b.progressStatus.text = p.message; b.progressBar.progress = p.percent
                    }
                }
            }.onSuccess { uris ->
                shareCacheAll[allKey] = uris
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE; b.btnShareDirect.isEnabled = true
                    launchShare(uris)
                }
            }.onFailure { e ->
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE; b.btnShareDirect.isEnabled = true
                    Toast.makeText(activity, "Failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    // ── Saved bottom sheet ─────────────────────────────────────────────────────
    private fun showSavedSheet(title: String, subtitle: String, shareUris: List<Uri>, saveFirst: Boolean) {
        val dialog = BottomSheetDialog(activity, com.google.android.material.R.style.Theme_Material3_Dark_BottomSheetDialog)
        val sheet  = BottomSheetSavedBinding.inflate(activity.layoutInflater)
        dialog.setContentView(sheet.root)
        sheet.tvSavedTitle.text    = title
        sheet.tvSavedFilename.text = subtitle

        // Open in reader — only for a single CBZ
        sheet.btnOpenReader.visibility = if (saveFirst && shareUris.size == 1) View.VISIBLE else View.GONE
        sheet.btnOpenReader.setOnClickListener {
            dialog.dismiss()
            runCatching {
                activity.startActivity(Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(shareUris[0], "application/x-cbz")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                })
            }.onFailure { Toast.makeText(activity, activity.getString(R.string.no_cbz_reader), Toast.LENGTH_SHORT).show() }
        }

        // Share button — only when there are URIs (folder saves have none)
        sheet.btnShare.visibility = if (shareUris.isNotEmpty()) View.VISIBLE else View.GONE
        sheet.btnShare.setOnClickListener { dialog.dismiss(); launchShare(shareUris) }

        sheet.btnDone.setOnClickListener { dialog.dismiss() }
        dialog.show()
    }

    // ── Launch share intent ────────────────────────────────────────────────────
    private fun launchShare(uris: List<Uri>) {
        if (uris.isEmpty()) return
        val intent = if (uris.size == 1) {
            Intent(Intent.ACTION_SEND).apply {
                type = "image/*"
                putExtra(Intent.EXTRA_STREAM, uris[0])
            }
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                type = "image/*"
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(uris))
            }
        }
        // clipData is required on Android 10+ so every URI gets read permission,
        // not just the first one in EXTRA_STREAM
        val clip = ClipData.newRawUri("", uris[0])
        for (i in 1 until uris.size) clip.addItem(ClipData.Item(uris[i]))
        intent.clipData = clip
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        activity.startActivity(Intent.createChooser(intent, "Share images via…"))
    }

    private fun checkWritePermission(onGranted: () -> Unit) {
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.Q &&
            androidx.core.content.ContextCompat.checkSelfPermission(activity, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != android.content.pm.PackageManager.PERMISSION_GRANTED)
            permLauncher.launch(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
        else onGranted()
    }
}
