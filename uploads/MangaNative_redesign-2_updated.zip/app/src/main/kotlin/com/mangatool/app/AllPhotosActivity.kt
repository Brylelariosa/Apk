package com.mangatool.app

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DecodeFormat
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.mangatool.app.util.ThumbnailWorker
import java.io.File

class AllPhotosActivity : AppCompatActivity() {

    sealed class GalleryItem {
        data class Header(val title: String, val count: Int) : GalleryItem()
        data class Photo(
            val groupIdx: Int,
            val imageIdx: Int,
            val groupName: String,
            val isMerge: Boolean,
            val sizeKb: Int
        ) : GalleryItem()
    }

    companion object {
        private const val COLS = 4

        /**
         * Placeholder shown while a thumbnail is being generated in the
         * background. Matches the #2A2A2A placeholder already used by
         * ChapterAdapter/ImageThumbAdapter so the gallery doesn't flash a
         * different color than the rest of the app while scrolling.
         */
        private val PLACEHOLDER = ColorDrawable(Color.parseColor("#2A2A2A"))
    }

    private lateinit var recycler: RecyclerView
    private lateinit var titleView: TextView
    private lateinit var countView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_all_photos)

        recycler  = findViewById(R.id.all_photos_grid)
        titleView = findViewById(R.id.all_photos_title)
        countView = findViewById(R.id.all_photos_count)

        findViewById<View>(R.id.btn_back).setOnClickListener { finish() }

        buildGallery()
    }

    private fun buildGallery() {
        val isMerge = AppState.currentMode == AppMode.MERGE
        val items = mutableListOf<GalleryItem>()

        AppState.groups.forEachIndexed { gIdx, group ->
            val images = group.displayImages
            if (images.isNotEmpty()) {
                items.add(GalleryItem.Header(group.groupName, images.size))
                images.forEachIndexed { iIdx, img ->
                    items.add(GalleryItem.Photo(
                        groupIdx  = gIdx,
                        imageIdx  = iIdx,
                        groupName = group.groupName,
                        isMerge   = isMerge,
                        sizeKb    = img.size / 1024
                    ))
                }
            }
        }

        val totalPhotos = items.filterIsInstance<GalleryItem.Photo>().size
        titleView.text = "All Photos"
        countView.text = "$totalPhotos images"

        val spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int) =
                if (items[position] is GalleryItem.Header) COLS else 1
        }

        val lm = GridLayoutManager(this, COLS).apply { this.spanSizeLookup = spanSizeLookup }
        recycler.layoutManager = lm
        recycler.adapter = GalleryAdapter(items)
    }

    // ── Adapter ────────────────────────────────────────────────────────────────
    inner class GalleryAdapter(
        private val items: List<GalleryItem>
    ) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

        private val TYPE_HEADER = 0
        private val TYPE_PHOTO  = 1

        override fun getItemViewType(position: Int) =
            if (items[position] is GalleryItem.Header) TYPE_HEADER else TYPE_PHOTO

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            val inflater = LayoutInflater.from(parent.context)
            return if (viewType == TYPE_HEADER) {
                HeaderVH(inflater.inflate(R.layout.item_gallery_header, parent, false))
            } else {
                PhotoVH(inflater.inflate(R.layout.item_gallery_photo, parent, false))
            }
        }

        override fun getItemCount() = items.size

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
            when (val item = items[position]) {
                is GalleryItem.Header -> (holder as HeaderVH).bind(item)
                is GalleryItem.Photo  -> (holder as PhotoVH).bind(item)
            }
        }

        override fun onViewRecycled(holder: RecyclerView.ViewHolder) {
            if (holder is PhotoVH) Glide.with(holder.img).clear(holder.img)
            super.onViewRecycled(holder)
        }

        /**
         * Load a gallery thumbnail using the same pre-generated-thumbnail-first
         * pattern ChapterAdapter/ImageThumbAdapter already use (v29), instead of
         * decoding the full original page image via Glide.
         *
         * Previous behavior here loaded `File(imgItem.filePath)` (the full
         * extracted page, 200–500 KB) at a stale `.override(140)` on every bind —
         * the same full-decode-on-scroll cost v29 removed elsewhere, since this
         * grid was never migrated to it. Fixed the same way:
         *   1. thumbnailPath != null -> Glide loads the pre-built WebP thumbnail.
         *   2. Else, ThumbnailWorker already generated one for a previous bind of
         *      this filePath -> same fast path via its cache.
         *   3. Else -> #2A2A2A placeholder (zero IO) + ThumbnailWorker.generate()
         *      queued in the background; notifyItemChanged on ready. The full
         *      original is never loaded here.
         *
         * override(MhtmlParser.THUMBNAIL_TARGET_PX) keeps the Glide decode target
         * in sync with the actual generated thumbnail resolution — the same
         * single source of truth ChapterAdapter/ImageThumbAdapter already read.
         */
        private fun loadThumb(holder: PhotoVH, thumbnailPath: String?, fallbackPath: String) {
            val target = holder.img
            val effectivePath = thumbnailPath ?: ThumbnailWorker.getCached(fallbackPath)

            if (effectivePath != null) {
                Glide.with(target)
                    .load(File(effectivePath))
                    .override(MhtmlParser.THUMBNAIL_TARGET_PX)
                    .format(DecodeFormat.PREFER_RGB_565)
                    .diskCacheStrategy(DiskCacheStrategy.NONE)  // thumbnail file IS the cache
                    .skipMemoryCache(false)
                    .dontAnimate()
                    .into(target)
            } else {
                Glide.with(target).clear(target)
                target.setImageDrawable(PLACEHOLDER)
                ThumbnailWorker.generate(fallbackPath) {
                    val pos = holder.bindingAdapterPosition
                    if (pos != RecyclerView.NO_POSITION) notifyItemChanged(pos)
                }
            }
        }

        inner class HeaderVH(v: View) : RecyclerView.ViewHolder(v) {
            private val title: TextView = v.findViewById(R.id.gallery_header_title)
            private val count: TextView = v.findViewById(R.id.gallery_header_count)
            fun bind(h: GalleryItem.Header) {
                title.text = h.title
                count.text = "${h.count} images"
            }
        }

        inner class PhotoVH(v: View) : RecyclerView.ViewHolder(v) {
            val img:  ImageView = v.findViewById(R.id.gallery_photo_image)
            val num:  TextView  = v.findViewById(R.id.gallery_photo_num)
            val size: TextView  = v.findViewById(R.id.gallery_photo_size)
            // No loadJob — Glide manages request lifecycle per ImageView target

            fun bind(photo: GalleryItem.Photo) {
                val group   = AppState.groups.getOrNull(photo.groupIdx) ?: return
                val imgItem = group.displayImages.getOrNull(photo.imageIdx) ?: return

                num.text  = "${photo.imageIdx + 1}"
                size.text = "${photo.sizeKb}KB"

                loadThumb(this, imgItem.thumbnailPath, imgItem.filePath)

                itemView.setOnClickListener {
                    val intent = Intent(this@AllPhotosActivity, ImagePreviewActivity::class.java).apply {
                        putExtra(ImagePreviewActivity.EXTRA_GROUP_IDX, photo.groupIdx)
                        putExtra(ImagePreviewActivity.EXTRA_IMAGE_IDX, photo.imageIdx)
                        putExtra(ImagePreviewActivity.EXTRA_IS_MERGE, photo.isMerge)
                    }
                    startActivity(intent)
                }
            }
        }
    }
}
