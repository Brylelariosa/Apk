// The app module is only a packaging shell: it contains the manifest and icons and bundles the Rust
// library (libvoxelsandbox.so). The `rust-android` plugin (buildSrc/) compiles that library with cargo and the
// NDK's clang into src/main/jniLibs before the APK is packaged. Only rustup/cargo and the NDK have to be
// installed; cargo-ndk is not needed.
plugins {
    id("com.android.application")
    id("rust-android")
}

val minApi = 24
val rustAbis: List<String> =
    (project.findProperty("rustAbis") as String? ?: "arm64-v8a")
        .split(",")
        .map { it.trim() }
        .filter { it.isNotEmpty() }

android {
    namespace = "com.voxelsandbox.game"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.voxelsandbox.game"
        minSdk = minApi
        targetSdk = 34
        versionCode = 27
        versionName = "0.8.0-rust"
        ndk {
            abiFilters += rustAbis
        }
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
        }
        release {
            // Nothing to shrink: there is no Java/Kotlin code. The Rust library is optimised by cargo.
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }

    packaging {
        resources.excludes.add("META-INF/*")
    }
}

// The `buildRust` task comes from the plugin and runs before the APK is packaged.
//   -PrustAbis=arm64-v8a,x86_64   which ABIs to build (default: gradle.properties)
//   -PrustProfile=dev             cargo profile (default: release)
//   -PrustPrebuilt=true           skip building: src/main/jniLibs already holds the libraries
rustAndroid {
    libraryName.set("voxelsandbox")      // [lib] name in Cargo.toml
    abis.set(rustAbis)
    apiLevel.set(minApi)                 // the NDK's clang for this API level links the library
    profile.set((project.findProperty("rustProfile") as String?) ?: "release")
}
