# Voxel Sandbox — Rust edition

A from-scratch Rust rewrite of the Kotlin/OpenGL ES voxel sandbox (v15). The game is one native library
(`libvoxelsandbox.so`) running inside Android's `NativeActivity`; there is no Java or Kotlin code. Gradle only
wraps the library into an APK.

See [`docs/RUST-PORT.md`](docs/RUST-PORT.md) for the architecture, what is ported and what is not yet.

## What is new in 0.8.0

* **A world map, on and off.** The new **MAP** button (under BIOME) turns a map in the top-left corner on and off; it lights up
  while the map is on, and the choice is remembered (Settings > Controls > *MAP IN CORNER* does the same). The map is a top-down
  picture like a world-map screen: ocean that gets darker with depth, rivers and lakes, a colour for every biome, hills shaded
  from the north-west, snow on the high peaks, and an arrow for you that turns as you turn (north is up). **Tap the map to open
  the large one**: drag it to look around, **+ / -** to zoom (2 to 32 blocks to a pixel), **ON YOU / CENTER** to come back, a
  **MINIMAP** switch, **CLOSE** (or Back). The map is made from the seed alone (`src/map`), like the biome finder, so it shows
  ground you have never visited and costs no chunk generation; it is built in 32 x 32 pixel tiles, a few rows a frame
  (2.5 ms at most), and kept in a cache.
* **Forests are forests.** A Forest, Birch Forest, Taiga or Snowy Taiga used to be thick only where a separate noise said so, so
  most of a "Forest" was open grass (0.3 % of its columns had a trunk). Tree density now follows the biome (about 2 % of columns
  have a trunk in a forest, 9 % in a jungle, 15 % in the rainforest, 0.4 % on plains), so the name and the look agree. The far
  terrain uses the same numbers.
* **Biomes look different.** Forests are a darker green, birch forests a light yellow-green, the rainforest darker than the
  jungle (grass and leaves, near and far). Biome borders are calmer: the wobble that cut them into specks of a few blocks was
  slowed down and weakened, so a biome is a patch you can walk through and not a flicker of names.
* **A much bigger Amazon, with rivers.** A very large, slow "basin" pushes the climate to hot and wet, flattens the land into a
  floodplain, removes mountains, and cuts one great river (many blocks wide, winding) with wider streams running into it and
  lakes around them. About a sixth of the world's area is basin; single basins reach 20 to 25 km².
* **Cave biomes, and caves down to the bottom.** Caves now reach y = 2, just above the bedrock (they stopped at 6), with a new
  deep layer of tunnels and bigger, commoner caverns between y 6 and 30. Caves also have biomes, from the surface climate: *Lush*
  (grass, ferns, flowers and hanging vines) under warm wet country, *Frozen* (snow and gravel) under cold, *Sand* (sand and
  sandstone) under hot dry country, and *Deep* (patches of gravel) at y 18 and below. They change only floors and ceilings.
* **Far trees look like trees.** Far forests are dark, species-coloured roofs of crowns (oak, light birch, bluish spruce) whose
  brightness varies from crown to crown, and the thickness of the far forest is the biome's, so it no longer reads as grass.
* Worlds made with an older version will show seams where new chunks meet old ones (the terrain, the trees and the caves changed).
  Start a new world to see everything as designed.

## What was new in 0.7.0

* **No more going through blocks.** Found by simulating the physics in 32-bit floats: whenever the player's head came to rest
  against a block above (a jump under leaves, a branch or an overhang) the next downward step counted that block as one the
  player was inside of, and threw them up *on top of it* (every time, in every test). Collision now only looks at the blocks
  *ahead* of the moving box, with a little slack for the coarse `f32` positions far from the origin (the slack grows with the
  distance, so it holds ten thousand blocks out too). A player who really is inside blocks (an old save, a tree that grew
  around them) climbs out of them instead of being stuck. The Amazon, where you are always jumping under leaves, is where it
  showed most.
* **Amazon trees stand on the ground.** The thick trunks (giants, Brazil-nut trees, figs) and their roots and buttresses started
  at one height whatever the ground under each corner did, so on a slope a corner hung in the air. They are now carried down to
  the ground.
* **Far terrain (LOD) with Distant-Horizons-like detail.**
  * The finest far cells are **4 blocks** wide (they were 8), the next 8, then 16 and so on (ten levels, reaching 131 km). The
    finest levels keep bigger windows of tiles (9 x 9 and 7 x 7 tiles, then 5 x 5), so the strip just beyond the real blocks is
    drawn with fine detail wherever the block world ends, and the far triangle count stays about what it was.
  * **Every far tree has its own round crown** (a dome, or a cone for spruces, as wide as the real tree's leaves), taken from the
    same tree positions the chunks use. A forest is a lumpy roof of crowns with the ground showing between them, not a field of
    poles. The leaves of single trees are lighter than the carpet used for far forests.
  * The columns of the three finest levels are looked at in a few spots and stand no higher than the real blocks at the edge of
    the block world, so there is no rim of far columns standing above the real ground.
  * With the far terrain as good as this, a smaller **real blocks distance** (10 to 16 chunks instead of 28) is the way to a
    smoother game on a phone: most of the cost in the forest is the leaves of the real chunks.

## What was new in 0.6.0

* **Water.** The three crossing sine waves are gone (at a low angle over the sea they folded into a fine woven pattern). The
  water is now a small pixel-art tile in the water colour, read twice, drifting in two directions a texel at a time, so it
  looks like the blocks around it and settles to one calm colour far away.
* **The jungle no longer flickers.** Leaves and plants are see-through textures, and the plain mip-mapping of a sparse texture
  makes it vanish a few blocks away and flicker in and out as you move. The mip levels are now made so that the leaves and
  plants keep the same share of solid texels at every distance.
* **More Amazon.** Researched from how the real rainforest is layered (emergent giants, closed canopy, understory, dark floor):
  * new trees: **palms** with arching fronds, **cecropias** (umbrella crowns on stilt roots), tall **Brazil-nut trees**, **strangler
    figs** (fluted trunks of aerial roots, broad dome, lianas) and understory **shrubs**, next to the jungle trees, rain trees
    and giants of 0.5.0;
  * trunks are dressed: **lianas climb the bark** and **bromeliads and orchids** sit on it high up;
  * the floor is a thicket of **ferns (two kinds), palm saplings, broad-leaved plants and mushrooms**, with **heliconias (red and
    yellow), orchids, bromeliads and hibiscus** growing in clumps; vines sometimes carry orange flowers; water lilies sometimes
    carry a pink bloom; the canopy and some trunks (pale and mossy, like kapok) have a second look so they are not one tone.
* **Far terrain (LOD) like Distant Horizons.** The far forest is built from the real tree positions the chunks use (so it lines up
  with the real forest, and the finest levels now have trees too); rock is as light as the real stone, with strata; slopes are
  shaded less harshly; the foot of every cliff is darker so stairs of columns read as slopes; and a haze starts at the edge of
  the block world, so far mountains fade towards the horizon instead of staying dark and crisp.
* **Performance.** The finest far tiles that real blocks already cover completely are no longer drawn (they were a large share of
  the far triangles, drawn and then thrown away by the depth test).

## What was new in 0.5.0

* **Jungle and Amazon Rainforest biomes.** Hot, wet country is now jungle (tall trees with lumpy crowns and hanging vines, a
  thicket of ferns, tall grass and hibiscus on the ground, deep green grass); where it is hottest and wettest it is the
  **Amazon Rainforest**: dense, with rainforest trees that close the canopy and **giant emergent trees** (26 to 40 blocks, a
  two-block trunk with buttress roots, side branches and a huge flat crown). New blocks: Jungle Wood, Jungle Leaves, Fern,
  Vine, Hibiscus (all in the creative inventory).
* **Biome finder.** The new **BIOME** button under the pause button opens a menu of biomes. Pick one and the game searches
  the world around you (up to 14 km, a few milliseconds of work per frame) for the nearest one and tells you how far it is and
  in which direction; **TELEPORT** takes you there.
* **Water.** The ripples are worked out per pixel instead of per vertex, so large water surfaces no longer show wide diagonal
  streaks, and deeper water is more opaque.
* **Far terrain looks more like the real thing.** Forests are a raised carpet of crowns (jungle and rainforest much taller), slopes
  that face the sun are lit and the others darker, and the jungle has its own deep green.
* **Caves** are wider, there are more big caverns and more entrances at the surface.

## What was new in 0.4.1

* **Render distance up to 5000 chunks (80 km)** and a **detail distance slider up to 500 chunks** (now a logarithmic slider).
  The far terrain has 9 levels instead of 6 and only builds the levels the render distance needs, so nothing changes at 1000
  chunks or below. The real blocks are still limited by memory: the game builds at most **32 chunks** of them (the slider shows
  `32 OF 500 CHUNKS` when you ask for more), and the far terrain covers everything beyond.
* **The frame is drawn in a better order**, with the same picture:
  * the far terrain is drawn *after* the real blocks, nearest tile first, in its own part of the depth buffer, so the GPU throws
    it away wherever blocks cover it (before it was drawn first, in no particular order, and then painted over);
  * the sky and the clouds are drawn *last* and only reach the pixels that nothing else covers (before, the sky and the clouds
    were shaded over the whole screen and then mostly painted over, which is a lot of work for a phone GPU);
  * no more depth clear in the middle of the frame.
* **Chunk meshes use 16-bit indices** (32-bit only for a mesh with more than 65,536 vertices): half the index memory and traffic.

## What was new in 0.4.0

The 0.3.0 log showed the GPU, not the CPU, was the limit (about 1,650 draw calls and 550 k triangles per frame at 24
chunks, a game thread that was busy only 30-55 % of the time). This version cuts exactly that work, and measures it.

* **Far fewer triangles and draw calls** (same test view, 24 chunks): **550 k → 241 k triangles (−56 %)** and
  **1,658 → 1,168 draw calls (−30 %)**. With *greedy meshing* switched off the same view is 818 k triangles, so the switch
  now shows a clear difference (before, the merged part was only a small share of the picture).
  * Merged (greedy) meshes start 6 chunks from the player, whatever the detail distance is.
  * Far chunks no longer build grass, flowers and lily pads (a few pixels of noise at that distance, four triangles each).
  * Flat water (open sea, calm lakes) is merged into big quads in far chunks: a chunk of sea is 1 quad instead of 256.
    The sea was 35 % of all triangles in the test view and is now under 2 %.
* **The clouds work now.** They were computed for every pixel of the sky (four noise octaves, a lot of GPU work) and then
  drawn completely transparent because of a fade-out bug. They now come from one small repeating noise texture
  (`tex/cloud_noise.rs`), cost a texture lookup, drift with the wind, and are visible.
* **Cheaper shaders.** Half-precision (`mediump`) interpolation, fog worked out per vertex instead of per pixel, no
  `discard` in the solid-block shader (so hidden pixels are rejected early), separate solid / leaf / plant / water passes,
  and all shaders compiled at start-up (no stall the first time grass or water is seen).
* **Auto performance** (Settings → Graphics, on by default). When the phone cannot hold about 60 fps the game lowers the
  *detail distance* first (the far terrain takes over beyond it, still blocky), then the resolution a little, and tries to give
  them back after a long stretch of smooth frames, taking a step back if that was too much. Your own settings are only
  ever the maximum. The level it settles on is remembered for the next launch (`quality.txt`), so there is no stuttery
  minute at every start. Switch it off to get exactly your own settings.
* **A paused game no longer redraws the world** behind the pause menu 60 times a second: the picture is drawn once and
  copied (about 16× less work, cooler phone).
* **The debug log knows more.** Every line has the GPU's own time per frame when the phone can measure it
  (`gpu-time 14.2ms/frame`), and the triangles and draw calls of each pass (`far / solid / leaves / plants / water`).
  EVENT lines say what auto performance did and why (`auto performance: 24 chunks at 100% -> 20 chunks at 100% (frames are
  very slow; frames 31.1 ms)`) and which settings you changed (`setting changed: greedy meshing: on -> off`). The FPS
  overlay shows `AUTO: 12 CHUNKS, 85%` while the quality is lowered.

## What was new in 0.3.0

* **Real full-screen.** The navigation bar and the status bar are hidden (immersive mode). Swiping in from the
  edge shows them for a moment and they hide again by themselves. The game draws behind the camera cut-out.
* **Render distance up to 1000 chunks** (16,000 blocks; 5000 since 0.4.1). Settings → Graphics has a slider, `-` / `+` buttons that
  repeat while you hold them (and speed up), and a **MAX** button. Only the *detail distance* (4–24 chunks, default 10)
  is built from real blocks; everything beyond it is **far terrain**: the same world drawn as big blocky
  columns in 6 coarser levels (9 since 0.4.1), so it still looks like a voxel game and costs very little.
* **Optimisations**, all of them switchable or automatic:
  * greedy meshing (chunks away from the player are built from merged quads: about a quarter fewer triangles),
  * frustum culling (chunks and 16-block sections outside the view are not drawn),
  * occlusion culling (sections that are shut off by rock, such as caves, are not drawn; about 13 % fewer triangles),
  * far-terrain LOD (see above), time-sliced mesh uploads, a render-resolution setting.
* **A debug log in the Download folder** that says what the game was doing every second (below).

## The debug log (send me this when the game lags)

Settings → Debug → *DEBUG LOG FILE* (on by default). The file is `VoxelSandbox-log_<date>_<time>.txt`, for example
`VoxelSandbox-log_2026-11-09_1.20pm.txt`.

* **Where:** the phone's **Download** folder (Android 10 and newer: created through MediaStore, no permission needed).
  On Android 7–9 it is written to Download only if you allow *Storage* for the app in the system settings; otherwise it
  goes to `Android/data/com.voxelsandbox.game/files/`. The Settings → Debug screen always shows where the file is.
* **Format:** one line every second, starting with the phone's clock in 12-hour style (`1:20:05pm`), then fps, the
  milliseconds the game thread spent in *input / update (calculation) / render (drawing work) / swap-wait (waiting for the
  GPU)*, CPU use, world and queue sizes, GPU uploads, draw calls and triangles, and at the end the verdict:
  `=> smooth`, `=> LAG: CALCULATION`, `=> LAG: RENDERING (CPU side)`, `=> LAG: GPU/DISPLAY` or `=> LAG: CPU STARVED`,
  with the part that cost the most. Single slow frames get their own `HITCH` line, and every minute ends with a
  `---- 1:20pm summary ----` block. The top of the file explains every column and lists the phone, the GPU and the settings.
* **It does not cost frames.** The game thread only adds a few numbers to counters (a relaxed atomic add) and hands one
  small record per second to a separate lowest-priority thread that formats and writes the text. If that thread is busy
  the record is dropped, never waited for. The file stops growing at 16 MB. Turn the switch off and nothing is measured.
* **To send it:** open a file manager → Download → share the `VoxelSandbox-log_….txt` file (or open it and copy the part
  around the time it lagged).

## Build (GitHub Actions, as before)

Upload the ZIP to `uploads/` like every other project. The build needs nothing from the workflow except what a GitHub
runner already has (Rust with rustup/cargo, and the Android NDK): Gradle's `buildRust` task (the `rust-android` plugin
in `buildSrc/`, see `docs/RUST-PORT.md`) installs the Rust Android target with rustup if it is missing, compiles the
library with cargo and the NDK's clang for the ABIs in `gradle.properties` (`rustAbis=`), puts it into
`app/src/main/jniLibs`, and then Gradle packages the APK. There is no cargo-ndk to install. If a workflow builds the
library in an earlier step, pass `-PrustPrebuilt=true` to Gradle and `buildRust` is skipped.

The Android crates are `android-activity` 0.6.1 or newer 0.6.x and `jni` 0.21.x; cargo fetches them.

If "Build APK" fails with `Downloading ... gradle-8.6-bin.zip failed: timeout`, it is the network, not the code: re-run
the failed job. (The Gradle wrapper waits up to 2 minutes for its download; see `networkTimeout` in
`gradle/wrapper/gradle-wrapper.properties`. The default of 10 seconds is too short on a slow day.)

## Build locally

```
cargo test --lib                      # the logic tests run on any computer
./gradlew assembleDebug               # cargo + the NDK build the Rust library, then the APK
```

Gradle finds the NDK through `ANDROID_NDK_HOME` (or `ANDROID_NDK_ROOT`), `ndk.dir` in `local.properties`, or the newest
`ndk/<version>` folder of the Android SDK. Options: `-PrustAbis=arm64-v8a,x86_64`, `-PrustProfile=dev`, `-PrustPrebuilt=true`.
